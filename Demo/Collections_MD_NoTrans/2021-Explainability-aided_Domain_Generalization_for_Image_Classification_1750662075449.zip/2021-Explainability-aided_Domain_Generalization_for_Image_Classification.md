# Explainability-aided Domain Generalization for Image Classification

Author: Supervisor: Robin M. Schmidt Dr. Massimiliano Mancini

Co-Supervisor:

Prof. Dr. Zeynep AKATA

Reviewer:

Prof. Dr. Philipp Hennig EBERHARD KARLS UNIVERSITAT TUBINGEN

![bo_d1c3r777aajc7389qf00_0_1028_1238_104_170_0.jpg](images/bo_d1c3r777aajc7389qf00_0_1028_1238_104_170_0.jpg)

A thesis submitted in fulfillment of the requirements

for the degree of Master of Science (M.Sc.) in Computer Science

in the

Department of Computer Science

Explainable Machine Learning Group

Abstract of thesis entitled

# Explainability-aided Domain Generalization for Image Classification

Submitted by Robin M. Schmidt for the degree of Master of Science (M.Sc.) at the University of Tübingen in April, 2021

Traditionally, for most machine learning settings, gaining some degree of explainability that tries to give users more insights into how and why the network arrives at its predictions, restricts the underlying model and hinders performance to a certain degree. For example, decision trees are thought of as being more explainable than deep neural networks but they lack performance on visual tasks. In this work, we empirically demonstrate that applying methods and architectures from the explainability literature can, in fact, achieve state-of-the-art performance for the challenging task of domain generalization while offering a framework for more insights into the prediction and training process. For that, we develop a set of novel algorithms including DIvCAM, an approach where the network receives guidance during training via gradient based class activation maps to focus on a diverse set of discriminative features, as well as ProDROP and D-TRANSFORMERS which apply prototypical networks to the domain generalization task, either with self-challenging or attention alignment. Since these methods offer competitive performance on top of explainability, we argue that the proposed methods can be used as a tool to improve the robustness of deep neural network architectures. Copyright ©2021, by Robin M. Schmidt ALL RIGHTS RESERVED.

## Declaration

I, Robin M. SCHMIDT, declare that this thesis titled "Explainability-aided Domain Generalization for Image Classification" which is submitted in fulfillment of the requirements for the degree of Master of Science in Computer Science represents my own work except where acknowledgements have been made. I further declare that this work has not been previously included as a whole or in parts in a thesis, dissertation, or report submitted to this university or to any other institution for a degree, diploma or other qualifications.

![bo_d1c3r777aajc7389qf00_4_950_1283_517_270_0.jpg](images/bo_d1c3r777aajc7389qf00_4_950_1283_517_270_0.jpg)

## Contents

1 Introduction 1

2 Domain Generalization 3

2.1 Problem formulation 3

2.2 Related concepts and their differences 5

2.2.1 Generic Neural Network Regularization 6

2.2.2 Domain Adaptation 6

2.3 Previous Works 6

2.3.1 Learning invariant features 7

2.3.2 Model ensembling 8

2.3.3 Meta-learning 8

2.3.4 Data Augmentation 8

2.4 Common Datasets 9

2.4.1 Rotated MNIST 9

2.4.2 Colored MNIST 9

2.4.3 Office-Home 9

2.4.4 VLCS 11

2.4.5 PACS 11

2.4.6 Terra Incognita 11

2.4.7 DomainNet 11

2.4.8 ImageNet-C 11

2.5 Considerations regarding model validation 12

2.6 Deep-Dive into Representation Self-Challenging 12

3 Explainability in Deep Learning 15

3.1 Related topics 16

3.1.1 Model Debugging 16

3.1.2 Fairness and Bias 16

3.2 Previous Works 17

3.2.1 Visualization 17

Back-Propagation 17

Perturbation 18

3.2.2 Model distillation 19

Local approximations 19

Model Translation 19

3.2.3 Intrinsic methods 19

Attention mechanism 19

Text explanations 20

Explanation association 20

Prototypes 20

3.3 Explainability for Domain Generalization 22

4 Proposed Methods 23

4.1 Diversified Class Activation Maps (DIVCAM) 23

4.1.1 Global Average Pooling bias for small activation areas 25

4.1.2 Smoothing negative Class Activation Maps 25

4.1.3 Conditional Domain Adversarial Neural Networks 27

4.1.4 Maximum Mean Discrepancy 27

4.2 Prototype Networks for Domain Generalization 28

4.2.1 Ensemble Prototype Network 29

4.2.2 Diversified Prototypes (ProDrop) 30

4.2.3 Using Support Sets (D-TRANSFORMERS) 33

5 Experiments 35

5.1 Datasets and splits 35

5.2 Hyperparameter Distributions & Schedules 35

5.3 Results 35

5.4 Ablation Studies 37

5.4.1 Hyperparameter Distributions & Schedules 37

5.4.2 DIVCAM: Mask Batching 38

5.4.3 DIVCAM: Class Activation Maps 39

5.4.4 ProDrop: Self-Challenging 39

5.4.5 ProDrop: Intra-Loss 40

6 Conclusion and Outlook 43

Bibliography 45

A Domain-specific results 57

B Additional distance plots 63

## List of Figures

2.1 Meta-distribution D generating source and unseen domain distributions 5

3.1 Class activation maps across different architectures 18

3.2 Prototypes for the MNIST and Car dataset 21

3.3 Image of a clay colored sparrow and its decomposition into prototypes 21

4.1 Visualization of the DIVCAM training process 24

4.2 Used class activation maps in DIVCAM-S throughout training 26

4.3 Domain-agnostic Prototype Network 28

4.4 Ensemble Prototype Network 29

4.5 Second data split pairwise prototype distances with ${w}_{c, j} =  - {1.0}$ . 31

4.6 Second data split pairwise self-challenging prototype distances with ${w}_{c, j} =  - {1.0}$ 33

B. 1 First data split pairwise prototype distances with ${w}_{c, j} =  - {1.0}$ 63

B. 2 Third data split pairwise prototype distances with ${w}_{c, j} =  - {1.0}$ 64

B. 3 First data split pairwise self-challenging prototype distances with ${w}_{c, j} =  - {1.0}$ 64

B. 4 Third data split pairwise self-challenging prototype distances with ${w}_{c, j} =  - {1.0}$

B. 5 First data split pairwise prototype distances with ${w}_{c, j} = {0.0}$ 65

B. 6 Second data split pairwise prototype distances with ${w}_{c, j} = {0.0}$

B. 7 Third data split pairwise prototype distances with ${w}_{c, j} = {0.0}$ 66

B. 8 First data split pairwise self-challenging prototype distances with ${w}_{c, j} = {0.0}$

B. 9 Second data split pairwise self-challenging prototype distances with ${w}_{c, j} = {0.0}$ 67

B. 10 Third data split pairwise self-challenging prototype distances with ${w}_{c, j} = {0.0}$ 68

## List of Tables

2.1 Differences in learning setups 5

2.2 Samples for two different classes across domains for popular datasets 10

2.3 Reproduced results for Representation Self-Challenging using the official code base 14

5.1 Performance comparison of the proposed methods on the PACS dataset 36

5.2 Performance comparison across datasets 37

5.3 Performance comparison for official PACS splits outside of DomAINBED 38

5.4 Hyperparameters and distributions used for the mask batching ablation study 38

5.5 Hyperparameters and distributions used for the mask ablation study 39

5.6 Ablation study for the DIVCAM mask batching on the PACS dataset 40

5.7 Ablation study for the DIVCAM masks on the PACS dataset 41

5.8 Self-challenging performance comparison for different negative class weights 41

5.9 Self-challenging performance comparison for different intra factors 42

A. 1 Domain specific performance for the VLCS dataset 58

A. 2 Domain specific performance for the PACS dataset 59

A. 3 Domain specific performance for the Office-Home dataset 60

A. 4 Domain specific performance for the Terra Incognita dataset 61

A. 5 Domain specific performance for the DomainNet dataset 62

## List of Algorithms

1 Spatial- and Channel-Wise RSC 14

2 Diversified Class Activation Maps (DIVCAM) 25

3 Prototype Dropping (ProDROP) 32

## List of Abbreviations

ADAM ADAptive Moment Estimation

AUC Area Under the Curve

CAM Class Activation Maps

CDANN Conditional Domain Adversarial Neural Network

CE Cross-Entropy

CNN Convolutional Neural Network

CMNIST Colored MNIST

DA Domain Adaptation

DANN Domain Adversarial Neural Network

DeepLIFT Deep Learning Important Features

$\mathbf{{DG}}$ Domain Generalization

DivCAM Diversified Class Activation Maps

DNN Deep Neural Network

ERM Empirical Risk Minimization

$\mathbf{{FC}}$ Fully Connected Layer

GAN Generative Adversarial Network

$\mathbf{{GAP}}$ Global Average Pooling

Grad-CAM Gradient-weighted Class Activation Maps

HNC Homogeneous Negative Class Activation Maps

I.I.D. Independent and Identically Distributed

$\mathbf{{KL}}$ Kullback-Leibler

LIME Local Interpretable Model-agnostic Explanations

MAML Model-Agnostic Meta-Learning

MMD Maximum Mean Discrepancy

MTAE Multi-Task Autoencoder

NLP Natural Language Processing

ProDrop Prototype Dropping

$\mathbf{{ReLU}}$ Rectified Linear Unit

$\mathbf{{RSC}}$ Representation Self-Challenging

RKHS Reproducing Kernel Hilbert Space

RMNIST Rotated MNIST

SGD Stochastic Gradient Descent

SVM Support Vector Machine

TAP Threshold Average Pooling

$\mathbf{{UML}}$ Unbiased Metric Learning

## List of Symbols

## Chapter 2

${\mathbf{x}}_{i}$ instance of input features

${\mathbf{y}}_{i}$ corresponding label for input features

${\dot{\mathbf{y}}}_{i}$ instance of label one-hot encoding

$\left( {{\mathbf{x}}_{i},{\mathbf{y}}_{i}}\right)$ sample of input and label pair

$\widehat{\mathbf{y}}$ predicted output label

Xrandom variable for input features

Yrandom variable for output labels

Cnumber of classes

Dtraining dataset

Dtraining distribution

Zfeature representation

$\widetilde{\mathbf{z}}$ masked features

Xinput space

Youtput space

$z$ latent space

Θ parameter space

$\theta$ model parameters

${f}_{\theta }$ model predictor

$\phi$ feature extractor

$w$ classifier

Knumber of feature maps of the last convolutional layer

$R\left( {f\theta }\right)$ model risk

${R}_{\mathrm{{erm}}}\left( {f}_{\theta }\right)$ empirical model risk

Lloss term

三 set of source environments

$\Phi$ set of test environments

$\xi$ environment

① meta distribution

Uunlabeled dataset

Llabeled dataset

Hreproducing kernel Hilbert space

$\varphi$ feature map induced by a kernel

${\Delta }_{\xi }$ local envinronment bias

${\theta }_{\xi }$ environment parameters

${\mathbf{M}}_{c}$ class activation map for class $c$

${\mathrm{g}}_{\mathrm{z}}$ gradient with respect to the features

${\widetilde{\mathrm{g}}}_{\mathrm{z}}$ average pooled gradient values

${H}_{\mathbf{z}}$ feature map height

${W}_{\mathbf{z}}$ feature map width

${y}_{c}$ logit for class $c$

${\mathbf{m}}_{i, j}$ feature mask at spatial location(i, j)

Cchange vector after applying the mask

${q}_{p}$ feature percentile threshold

${b}_{p}$ batch percentile threshold

## Chapter 3

${g}_{{\theta }^{\prime }}$ interpretable model

$\mathcal{G}\;$ set of interpretable models

$\Pi$ complexity measure

$\mathcal{P}\;$ set of prototypes

${\mathbf{p}}_{j}\;j$ -th prototype

${H}_{\mathbf{p}}\;$ height of the prototypes

${W}_{\mathbf{p}}\;$ width of the prototypes

${g}_{{\mathbf{p}}_{j}}\;$ prototype unit

${g}_{\mathbf{p}}\;$ prototype layer

$\overline{\mathbf{z}}$

${\Psi }_{j}$ similarity map between $j$ -th prototype and latent representation

$\epsilon \;$ numerical stability factor

${w}_{c, j}$ classifier weight connecting the $j$ -th prototype unit and class $c$ logit

${\theta }_{\phi }$ parameters of the feature extractor

${\theta }_{w}$ parameters of the classifier

${\ell }_{2}$ euclidean distance

$\lambda$ loss term weighting factor

- - -

## Chapter 4

${\tau }_{tap}$ threshold for average pooling

${J}_{ > }^{m}$ Set of Top- $m$ negative classes

Uuniform probability matrix

${M}_{c}^{\prime }$ probability map

$\omega$ domain predictor

d domain ground truth

$\eta$ ${\ell }^{2}$ regularization weighting factor

$k$ kernel function

Pset of source domain pairs -

$\varrho$ cosine distance

${S}_{c}$ support set for class $c$

$\Gamma$ key head -

$\Lambda$ value head

Ω query head

$\mathrm{k}$ keys of the support set

q queries

Vsupport-set values -

Wquery image values

$\alpha$ dot similarity between keys and queries

$\widetilde{\alpha }$ attention weights

Bbatch size

$\alpha$ learning rate

γ weight decay factor

## Introduction

Modern machine learning solutions commonly rely on supervised deep neural networks as their default approach and one of the tasks that is commonly required and implemented in practice is image classification. In its simplest form, the used networks combine multiple layers of linear transformations coupled with non-linear activation functions to classify an input image based on its pixel values into a discrete set of classes. The chosen architecture, also known as the model, is then able to learn good parameters that represent how to combine the information extracted from the individual pixel values using additional labeled information. That is, for a set of images we know the correct class and can automatically guide the network towards well-working parameters by determining how wrong the current prediction is and in which direction we need to update the individual parameters, for our network to give a more accurate class prediction.

Obtaining this labeled information, however, is very tedious in practice and either requires a lot of manual human labeling or sufficient human quality assurance for any automatic labeling system. A commonly used approach to overcome this impediment is to combine multiple sources of data, that might have been collected in different settings but represent the same set of classes and have already been labeled a priori. Since the training distribution described by the obtained labeled data is then often different from the testing distribution imposed by the images we observe once we deploy our system, we commonly observe a distribution shift when testing and the network generally needs to do out-of-distribution predictions. Similar behavior can be observed when the model encounters irregular properties during testing such as weather or lighting conditions which have not been captured well by the training data. For many computer vision neural network models, this poses an interesting and challenging task which is known as out-of-distribution generalization where researchers try to improve the predictions under these alternating circumstances for more robust machine learning models.

In this work, we pick up on this challenge and try to improve the out-of-distribution generalization capabilities with models and techniques that have been proposed to make deep neural networks more explainable. For most machine learning settings, gaining a degree of explainability that tries to give humans more insights into how and why the network arrives at its predictions, restricts the underlying model and hinders performance to a certain degree. For example, decision trees are thought of as being more explainable than deep neural networks but lack performance on visual tasks. In this work, we investigate if these properties also hold for the out-of-distribution generalization task or if we can deploy explainability methods during the training procedure and gain, both, better performance as well as a framework that enables more explainability for the users. In particular, we develop a regularization technique based on class activation maps that visualize parts of an image that led to certain predictions (DIvCAM) as well as prototypical representations that serve as a number of class or attribute centroids which the network uses to make its predictions (ProDrop and D-TRANSFORMERS). Specifically, we deploy these methods for the domain generalization task where the model has access to images from multiple training domains, each imposing a different distribution, but without access to images from the immediate testing distribution.

From our experiments, we observe that especially DIvCAM offers state-of-the-art performance on some datasets while providing a framework that enables additional insights into the training and prediction procedure. For us, this is a property that is highly desirable, especially in safety-critical scenarios such as self-driving cars, any application in the medical field such as cancer or tumor prediction, or any other automation robot that needs to operate in a diverse set of environments. Hopefully, some of the methods presented in this work can find application in such scenarios and establish additional trust and confidence into the machine learning system to work reliable. All of our experiments have been conducted within the DOMAINBED domain generalization benchmarking framework and the respective code has been open-sourced. ${}^{1}$

## Chapter 2 Domain Generalization

Machine learning systems often lack out-of-distribution generalization which causes models to heavily rely on the training distribution and as a result don't perform very well when presented with a different input distribution during testing. Examples are application scenarios where intelligent systems don't generalize well across health centers if the training data was only collected in a single hospital $\lbrack 4$ , 31, 142] or when self-driving cars struggle under alternative lighting or weather conditions [36, 191]. Properties that are often interpreted falsely as part of the relevant feature set include backgrounds [17], textures [62], or racial biases [178]. Not only can a failure in capturing this domain shift lead to poor performance, but in safety-critical scenarios this can correspond to a large impact on people's lives. Due to the prevalence of this challenge for the wide-spread deployment of machine learning systems in diverse environments, many researchers tried to tackle this task with different approaches. In this chapter, we want to give a broad overview of the literature in domain generalization and prepare the fundamentals for the following chapters. If you are already familiar with the field, you can safely skip this chapter and only familiarize yourself with the used notation.

### 2.1 Problem formulation

Supervised Learning In supervised learning we are aiming to optimize the predictions $\widehat{\mathbf{y}}$ for the values $\mathbf{y} \in  \mathcal{Y}$ of a random variable $Y$ when presented with values $\mathbf{x} \in  \mathcal{X}$ of a random variable $X$ . These predictions are generated with a model predictor ${f}_{\mathbf{\theta }}\left( \cdot \right)  : \mathcal{X} \rightarrow  \mathcal{Y}$ that is parameterized by $\mathbf{\theta } \in  \Theta$ , usually the weights of a neural network, and is assigning the predictions as $\widehat{\mathbf{y}} = {f}_{\mathbf{\theta }}\left( \cdot \right)$ . To improve our predictions, we utilize a training dataset containing $n$ input-output pairs denoted as $D = {\left\{  \left( {\mathbf{x}}_{i},{\mathbf{y}}_{i}\right) \right\}  }_{i = 1}^{n}$ where each sample $\left( {{\mathbf{x}}_{i},{\mathbf{y}}_{i}}\right)$ is ideally drawn identically and independently distributed (i.i.d.) from a single joint probability distribution $\mathcal{D}$ . By using a loss term $\mathcal{L}\left( {\widehat{\mathbf{y}},\mathbf{y}}\right)  : \mathcal{Y} \times  \mathcal{Y} \rightarrow  {\mathbb{R}}^{ + }$ , which quantifies how different the prediction $\widehat{\mathbf{y}}$ is from the ground truth $\mathbf{y}$ , we would like to minimize the risk,

$$
R\left( {f}_{\mathbf{\theta }}\right)  = {\mathbb{E}}_{\left( {{\mathbf{x}}_{i},{\mathbf{y}}_{i}}\right)  \sim  \mathcal{D}}\left\lbrack  {\mathcal{L}\left( {{f}_{\mathbf{\theta }}\left( {\mathbf{x}}_{i}\right) ,{\mathbf{y}}_{i}}\right) }\right\rbrack  , \tag{2.1}
$$

of our model. Since we only have access to the distribution $\mathcal{D}$ through a proxy in the form of the dataset $D$ , we are instead using Empirical Risk Minimization (ERM):

$$
{R}_{\mathrm{{erm}}}\left( {f}_{\mathbf{\theta }}\right)  = \frac{1}{n}\mathop{\sum }\limits_{{i = 1}}^{n}\mathcal{L}\left( {{f}_{\mathbf{\theta }}\left( {\mathbf{x}}_{i}\right) ,{\mathbf{y}}_{i}}\right) , \tag{2.2}
$$

by adding up the loss terms of each sample. One common choice for this loss term is the Cross-Entropy (CE) loss which is shown in Equation (2.3).

$$
{\mathcal{L}}_{\mathrm{{ce}}}\left( {{\widehat{\mathbf{y}}}_{i},{\dot{\mathbf{y}}}_{i}}\right)  =  - \mathop{\sum }\limits_{{c = 1}}^{C}{y}_{i, c} \cdot  \log \left( {\widehat{y}}_{i, c}\right)  \tag{2.3}
$$

Here, ${\dot{\mathbf{y}}}_{i}$ is the one-hot vector representing the ground truth class, ${\widehat{\mathbf{y}}}_{i}$ is the softmax output of the model, ${\widehat{y}}_{i, c}$ and ${y}_{i, c}$ are the $c$ -th dimension of ${\widehat{\mathbf{y}}}_{i}$ and ${\dot{\mathbf{y}}}_{i}$ respectively.

The occurring minimization problem is then often solved through iterative gradient-based optimization algorithms e.g. SGD [155] or ADAM [98] which perform on-par with recent methods for the non-convex, continuous loss surfaces produced by modern machine learning problems and architectures [163].

On top of that, the model predictor ${f}_{\mathbf{\theta }}$ can be decomposed into two functions as ${f}_{\mathbf{\theta }} = w \circ  \phi$ where $\phi  : \mathcal{X} \rightarrow  \mathcal{Z}$ is an embedding into a feature space, hence sometimes called the feature extractor, and $w : \mathcal{Z} \rightarrow  \mathcal{Y}$ which is called the classifier since it is a prediction from the feature space to the output space $\left\lbrack  {{73},{131}}\right\rbrack$ . This often allows for a more concise mathematical notation.

Domain Generalization The problem of Domain generalization (DG) builds on top of this framework, where now we have a set of training environments $\Xi  = \left\{  {{\xi }_{1},\ldots ,{\xi }_{s}}\right\}$ , also known as source domains, where each environment $\xi$ has an associated dataset ${D}_{\xi } = {\left\{  \left( {\mathbf{x}}_{i}^{\xi },{\mathbf{y}}_{i}^{\xi }\right) \right\}  }_{i = 1}^{{n}_{\xi }}$ containing ${n}_{\xi }$ i.i.d. samples from individual data distributions ${\mathcal{D}}_{\xi }$ . Note that, while related, the environments have different joint distributions, i.e. ${\mathcal{D}}_{{\xi }_{i}} \neq  {\mathcal{D}}_{{\xi }_{j}}\forall i \neq  j$ . Here, ${\mathbf{x}}_{i}^{\xi } \in  {\mathbb{R}}^{m}$ is the $i$ -th sample for environment $\xi$ representing an $m$ -dimensional feature vector (i.e. an image in our case) and ${\mathbf{y}}_{i}^{\xi } \in  \mathcal{Y}$ is the corresponding ground truth class label over the $C$ possible classes. The one-hot vector representing the ground truth is denoted as ${\dot{\mathbf{y}}}_{i}^{\xi }$ . To clear up some notation, we sometimes omit $\xi$ where it is obvious. From these source domains, we try to learn generic feature representations agnostic to domain changes to improve model performance [166]. Simply, we try to do out-of-distribution generalization where our model aims to achieve good performance for an unseen test environment ${\xi }_{t}$ sampled from the set of unseen environments $\Phi  = \left\{  {{\xi }_{1},\ldots ,{\xi }_{t}}\right\}$ with $\Xi  \cap  \Phi  = \varnothing$ based on statistical invariances across the observed training (source) and testing (target) domains $\left\lbrack  {{73},{86}}\right\rbrack$ . For that, we try to minimize the expected target risk of our model as:

$$
R\left( {f}_{\mathbf{\theta }}\right)  = {\mathbb{E}}_{\left( {{\mathbf{x}}_{i}^{{\xi }_{t}},{\mathbf{y}}_{i}^{{\xi }_{t}}}\right)  \sim  {\mathcal{D}}_{{\xi }_{t}}}\left\lbrack  {\mathcal{L}\left( {{f}_{\mathbf{\theta }}\left( {\mathbf{x}}_{i}^{{\xi }_{t}}\right) ,{\mathbf{y}}_{i}^{{\xi }_{t}}}\right) }\right\rbrack  . \tag{2.4}
$$

Since we don’t have access to ${\mathcal{D}}_{{\xi }_{t}}$ during training, one simple approach is to assume that minimizing the risk over all source domains in $\Xi$ achieves good generalization to the target domain. That is, we disregard the separated environments:

$$
R\left( {f}_{\mathbf{\theta }}\right)  = {\mathbb{E}}_{\left( {{\mathbf{x}}_{i},{\mathbf{y}}_{i}}\right)  \sim  { \cup  }_{\xi  \in  \Xi }{\mathcal{D}}_{\xi }}\left\lbrack  {\mathcal{L}\left( {{f}_{\mathbf{\theta }}\left( {\mathbf{x}}_{i}\right) ,{\mathbf{y}}_{i}}\right) }\right\rbrack  . \tag{2.5}
$$

Again, this can be written with the empirical risk as a simple sum over all the environments and their corresponding samples:

$$
{R}_{\mathrm{{erm}}}\left( {f}_{\mathbf{\theta }}\right)  = \frac{1}{s}\mathop{\sum }\limits_{{\xi  \in  \Xi }}\frac{1}{{n}_{\xi }}\mathop{\sum }\limits_{{i = 1}}^{{n}_{\xi }}\mathcal{L}\left( {{f}_{\mathbf{\theta }}\left( {\mathbf{x}}_{i}^{\xi }\right) ,{\mathbf{y}}_{i}^{\xi }}\right) . \tag{2.6}
$$

The difference of this approach when compared to ordinary supervised learning is shown on a high-level in Table 2.1. It may also be helpful to think about a meta-distribution $\mathfrak{D}$ (real-world) generating source environment distributions ${\mathcal{D}}_{\xi }^{\Xi }$ and unseen testing domain distributions ${\mathcal{D}}_{\xi }^{\Phi }$ as shown in Figure 2.1.

![bo_d1c3r777aajc7389qf00_18_556_185_572_261_0.jpg](images/bo_d1c3r777aajc7389qf00_18_556_185_572_261_0.jpg)

Figure 2.1: Meta-distribution $\mathfrak{D}$ generating source environment distributions (left) and unseen environment distributions (right), adapted from: [5]

<table><tr><td>Setup</td><td>Training inputs</td><td>Testing inputs</td></tr><tr><td>Generative learning</td><td>${U}_{{\xi }_{1}}$</td><td>0</td></tr><tr><td>Unsupervised learning</td><td>${U}_{{\xi }_{1}}$</td><td>${U}_{{\xi }_{1}}$</td></tr><tr><td>Supervised learning</td><td>${L}_{{\xi }_{1}}$</td><td>${U}_{{\xi }_{1}}$</td></tr><tr><td>Semi-supervised learning</td><td>${L}_{{\xi }_{1}},{U}_{{\xi }_{1}}$</td><td>${U}_{{\xi }_{1}}$</td></tr><tr><td>Multitask learning</td><td>${L}_{{\xi }_{1}},\ldots ,{L}_{{\xi }_{s}}$</td><td>${U}_{{\xi }_{1}},\ldots ,{U}_{{\xi }_{s}}$</td></tr><tr><td>Continual (lifelong) learning</td><td>${L}_{{\xi }_{1}},\ldots ,{L}_{{\xi }_{\infty }}$</td><td>${U}_{{\xi }_{1}},\ldots ,{U}_{{\xi }_{\infty }}$</td></tr><tr><td>Domain Adaptation</td><td>${L}_{{\xi }_{1}},\ldots ,{L}_{{\xi }_{s}},{U}_{{\xi }_{t}}$</td><td>${U}_{{\xi }_{t}}$</td></tr><tr><td>Transfer learning</td><td>${U}_{{\xi }_{1}},\ldots ,{U}_{{\xi }_{s}},{L}_{{\xi }_{t}}$</td><td>${U}_{{\xi }_{t}}$</td></tr><tr><td>Domain generalization</td><td>${L}_{{\xi }_{1}},\ldots ,{L}_{{\xi }_{s}}$</td><td>${U}_{{\xi }_{t}}$</td></tr></table>

Table 2.1: Differences in learning setups adapted from: [73]. For each environment $\xi$ the labeled and unlabeled datasets are denoted as ${L}_{\xi }$ and ${U}_{\xi }$ respectively.

Homogeneous and Heterogeneous Sometimes, domain generalization is also divided into homogeneous and heterogeneous subtasks. In homogeneous DG we assume that all domains share the same label space ${\mathcal{Y}}^{{\xi }_{i}} = {\mathcal{Y}}^{{\xi }_{j}} = {\mathcal{Y}}^{{\xi }_{t}},\forall {\xi }_{i} \neq  {\xi }_{j} \in  \Xi$ . On the contrary, the more challenging heterogeneous DG allows for different label spaces ${\mathcal{Y}}^{{\xi }_{i}} \neq  {\mathcal{Y}}^{{\xi }_{j}} \neq  {\mathcal{Y}}^{{\xi }_{t}},\forall {\xi }_{i} \neq  {\xi }_{j} \in  \Xi$ which can even be completely disjoint [110]. For this work, we assume a homogeneous setting.

Single- and Multi-Source There exist subtle differences within this task which are called single- or multi-source domain generalization. While multi-source domain generalization refers to the standard-setting we have just outlined, single-source domain generalization is a more generic formulation [221]. Instead of relying on multiple training domains to learn models which generalize better, single-source domain generalization aims at learning these representations with access to only one source distribution. Hence, our training domains are restricted to $\Xi  = \left\{  {\xi }_{1}\right\}$ , described by one dataset ${D}_{{\xi }_{1}} = {\left\{  \left( {\mathbf{x}}_{i}^{{\xi }_{1}},{\mathbf{y}}_{i}^{{\xi }_{1}}\right) \right\}  }_{i = 1}^{{n}_{{\xi }_{1}}}$ and modeling a single source distribution ${\mathcal{D}}_{{\xi }_{1}}$ . For example, this can be achieved by combining the different datasets or distributions similar to Equation (2.5) or mathematically ${ \cup  }_{\xi  \in  \Xi }{D}_{\xi }$ . This is different from the ordinary supervised learning setup since we want to analyze the performance of the model under a clear domain-shift (i.e. out-of-distribution generalization). Keep in mind, that strong regularization methods will also perform well on this subtask. These cross-over and related techniques are described in the following section.

### 2.2 Related concepts and their differences

As already introduced, members of the causality community might know the task of domain generalization under the term learning from multiple environments $\left\lbrack  {9,{73},{143}}\right\rbrack$ and researchers coming from deep learning might know it under learning from multiple domains. While these two concepts refer to the same task, there exist quite a few related techniques which we want to highlight here and distinguish in their scope. In particular, we focus on "Generic neural network regularization" and "Domain Adaptation" since each of these are very closely related to domain generalization and sometimes hard to distinguish, if at all. The overview in Table 2.1, however, includes even more learning setups to properly position this concept into the machine learning landscape.

#### 2.2.1 Generic Neural Network Regularization

In theory, generic model regularization which aims to prevent neural networks from overfitting on the source domain could also improve the domain generalization performance [86]. As such, methods like dropout [177], early stopping [30], or weight decay [136] can have a positive effect on this task when deployed properly. Apart from regular dropout, where we randomly disable neurons in the training phase to stop them from co-adapting too much, a few alternative methods exist. These include dropping random patches of input images (Cutout &HaS) [40, 172] or channels of the feature map (SpatialDropout) [185], dropping contiguous regions of the feature maps (DropBlock) [64], dropping features of high activations across feature maps and channels (MaxDrop) [139], or generalizing the traditional dropout of single units to entire layers during training (DropPath) [104]. There even exist methods like curriculum dropout [130] that deploy scheduling for the dropout probability and therefore softly increase the number of units to be suppressed layerwise during training.

Generally, deploying some of these methods when aiming for out-of-distribution generalization can be a good idea and should definitely be considered for the task of domain generalization.

#### 2.2.2 Domain Adaptation

Domain Adaptation (DA) is often mentioned as a closely related task in domain generalization literature $\left\lbrack  {{131},{148},{192}}\right\rbrack$ . When compared, domain adaptation has additional access to an unlabeled dataset from the target domain $\left\lbrack  {{34},{123}}\right\rbrack$ . Formally, aside from the set of source domains $\Xi$ and the domain datasets ${D}_{\xi }$ , as outlined in Section 2.1, we have access to target samples ${U}_{{\xi }_{t}} = \left\{  {{\mathbf{x}}_{1}^{{\xi }_{t}},\ldots ,{\mathbf{x}}_{{n}_{{\xi }_{t}}}^{{\xi }_{t}}}\right\}$ that are from the target domain ${\mathbf{x}}_{i}^{{\xi }_{t}} \sim  {\mathcal{D}}_{{\xi }_{t}}$ but their labels remain unknown during training since we want to predict them during testing. As a result, domain generalization is considered to be the harder problem of the two. This difference is also shown in Table 2.1.

Earlier methods in this space deploy hand-crafted features to reduce the difference between the source and the target domains [126]. Like that, instance-based methods try to re-weight source samples according to target similarity $\left\lbrack  {{68},{85},{202}}\right\rbrack$ , or feature-based methods try to learn a common subspace $\left\lbrack  {{14},{54},{69},{119}}\right\rbrack$ . More recent works focus on deep domain adaptation based on deep architectures where domain invariant features are learned utilizing supervised neural networks [22, 29, 60, 67], autoencoders [209], or generative adversarial networks (GANs) [21, 169, 186]. These deep NN-based architectures significantly outperform the approaches for hand-crafted features [126].

Even though domain adaptation and domain generalization both try to reduce the dataset bias, they are not compatible with each other [65]. Hence, domain adaptation methods often cannot be directly used for domain generalization or vice versa [65]. For this work, we don't rely on the simplifying assumptions of domain adaptation, but instead, tackle the more challenging task of DG.

### 2.3 Previous Works

Most commonly, work in domain generalization can be divided into methods that try to learn invariant features, combine domain-specific models in a process called model ensembling, pursue meta-learning, or utilize data augmentation to generate new domains or more robust representations. Since literature in the domain generalization space is broad, we utilized Gulrajani and Lopez-Paz [73, Appendix A] for an overview and to identify relevant literature while individually adding additional works and more detailed information where necessary.

#### 2.3.1 Learning invariant features

Methods that try to learn invariant features typically minimize the difference between source domains. They assume that with this approach the features will be domain-invariant and therefore will have good performance for unseen testing domains [86].

Some of the earliest works on learning invariant features were kernel methods applied by Muandet, Balduzzi, and Schölkopf [132] where they experimented with a feature transformation that minimizes the across-domain dissimilarity between transformed feature distributions while preserving the functional relationship between original features and targets. In recent years, there have been approaches following a similar kernel-based approach [115, 116], sometimes while maximizing class separability $\left\lbrack  {{65},{83}}\right\rbrack$ . As an early method, Fang, Xu, and Rockmore [52] introduce Unbiased Metric Learning (UML) with an SVM metric that enforces the neighborhood of samples to contain samples with the same class label but from other training domains.

After that, Ganin et al. [61] introduced Domain Adversarial Neural Networks (DANNs) using neural network architectures to learn domain-invariant feature representations by adding a gradient reversal layer. Recently, their approach got extended to support statistical dependence between domains and class labels [2] or considering one-versus-all adversaries to minimize pairwise divergences between source distributions [5]. Motiian et al. [131] use a siamese architecture to learn a feature transformation that tries to achieve semantical alignment of visual domains while maximally separating them. Other methods are also matching the feature covariance across source domains [150] or take a causal interpretation to match representations of features [122]. Huang et al. [86] have also shown that self-challenging (i.e. dropping features with high gradient values at each epoch) works very well.

Matsuura and Harada [127] use clustering techniques to split single-source domain generalization into different domains and then train a domain-invariant feature extractor via adversarial learning. Other works have also deployed similar approaches based on adversarial strategies [37, 92].

Li et al. [112] deploy adversarial autoencoders with maximum mean discrepancy (MMD) [72] to align the source distributions, i.e. for distributions ${\mathcal{D}}_{{\xi }_{1}},{\mathcal{D}}_{{\xi }_{2}}$ and a feature map $\varphi  : \mathcal{X} \rightarrow  \mathcal{H}$ where $\mathcal{H}$ is a reproducing kernel Hilbert space (RKHS) this measure is defined as Equation (2.7).

$$
\operatorname{MMD}\left( {{\mathcal{D}}_{{\xi }_{1}},{\mathcal{D}}_{{\xi }_{2}}}\right)  = {\begin{Vmatrix}{\mathbb{E}}_{\left( {{\mathbf{x}}_{i},{\mathbf{y}}_{i}}\right)  \sim  {\mathcal{D}}_{{\xi }_{1}}}\left\lbrack  \varphi \left( {\mathbf{x}}_{i}^{{\xi }_{1}}\right) \right\rbrack  \rbrack  - {\mathbb{E}}_{\left( {{\mathbf{x}}_{i},{\mathbf{y}}_{i}}\right)  \sim  {\mathcal{D}}_{{\xi }_{2}}}\left\lbrack  \varphi \left( {\mathbf{x}}_{i}^{{\xi }_{2}}\right) \right\rbrack  \end{Vmatrix}}_{\mathcal{H}} \tag{2.7}
$$

Ilse et al. [88] extend the variational autoencoder [99] by introducing latent representations for environments ${\mathcal{Z}}_{\xi }$ , classes ${\mathcal{Z}}_{\mathbf{y}}$ , and residual variations ${\mathcal{Z}}_{\mathbf{x}}$ . Further, Li et al. [110] use episodic training i.e. they train a domain agnostic feature extractor $\phi$ and classifier $w$ by mismatching them with an equivalent trained on a specific domain ${\phi }_{\xi }$ and ${w}_{\xi }$ in combinations $\left( {{\phi }_{{\xi }_{1}},{w}_{{\xi }_{2}},{\mathbf{x}}_{i}^{{\xi }_{2}}}\right)$ and $\left( {{\phi }_{{\xi }_{2}},{w}_{{\xi }_{1}},{\mathbf{x}}_{i}^{{\xi }_{2}}}\right)$ and letting them predict data outside of the trained domain ${\xi }_{1} \neq  {\xi }_{2}$ . Piratla, Netrapalli, and Sarawagi [145] also learn domain-specific and common components but the domain-specific parts are discarded after training. Li et al. [109] deploy a lifelong sequential learning strategy.

#### 2.3.2 Model ensembling

Some methods try to associate model parameters with each of the training domains and combine them, often together with shared parameters, in a meaningful matter to improve generalization to the test domain. Commonly, the number of models in these type of architectures grow linearly with the number of source domains.

The first work to pose the problem of domain generalization and analyze it was Blanchard, Lee, and Scott [20]. In there, they use classifiers for each sample ${\mathbf{x}}^{\xi }$ denoted as ${f}_{\mathbf{\theta }}\left( {{\mathbf{x}}^{\xi },{\mu }^{\xi }}\right)$ where ${\mu }^{\xi }$ corresponds to a kernel mean embedding [133]. For theoretical analysis on such methods please see Deshmukh et al. [38] and Blanchard et al. [19]. Later on, Khosla et al. [96] combine global weights $\mathbf{\theta }$ with local domain biases ${\Delta }_{\xi }$ to learn one max-margin linear classifier (SVM) per domain as ${\mathbf{\theta }}_{\xi } = \mathbf{\theta } + {\Delta }_{\xi }$ and finally combine them, which has recently been extended to neural network settings by adding an additional dimension describing the training domains to the parameter tensors [107]. Ghifary et al. [66] propose a Multi-task Autoencoder (MTAE) with shared parameters to the hidden state and domain-specific parameters for each of the training domains. Further, Mancini et al. [125] use domain-specific batch-normalization [89] layers and then linearly combine them using a softmax domain classifier. Other works utilize other domain-specific normalization techniques [166], linearly combine domain-specific predictors [124], or use more elaborate aggregation strategies [35]. Ding and Fu [42] use multiple domain-specific deep neural networks with a structured low-rank constraint and a domain-invariant deep neural network to generalize to the target domain. There have also been works that assign weights to mini-batches depending on their respective error to the training distributions [84, 159]. Jin et al. [94] use attention mechanisms to align the features of the different training domains.

#### 2.3.3 Meta-learning

Meta-learning approaches provide algorithms that tackle the problem of learning to learn [161, 183]. As such, Finn, Abbeel, and Levine [56] propose a Model-Agnostic Meta-Learning (MAML) algorithm that can quickly learn new tasks with fine-tuning. Li et al. [108] adapt this algorithm for domain generalization (no fine-tuning) such that we can adapt to new domains by utilizing the meta-optimization objective which ensures that steps to improve training domain performance should also improve testing domain performance. Both approaches are not bound to a specific architecture and can therefore be deployed for a wide variety of learning tasks. These approaches recently got extended by two reg-ularizers that encourage general knowledge about inter-class relationships and domain-independent class-specific cohesion [46], to heterogeneous domain generalization [117], or via meta-learning a regularizer that encourages across-domain performance [15].

#### 2.3.4 Data Augmentation

Data Augmentation remains a competitive method for generalizing to unseen domains [211]. Works in this segment try to extend the source environments to a wider range of domains by augmenting the available training environments. However, to deploy an efficient procedure for that, human experts need to consider the data at hand to develop a useful routine [73].

Several works have used the MIXUP [210] algorithm as a method to merge samples from different domains $\left\lbrack  {{123},{195},{200},{203}}\right\rbrack$ . Other works have also tried removing textural information from images [194] or shifting it more towards shapes [10, 135]. Carlucci et al. [28] used jigsaw puzzles of image patches as a classification task to show that this improves domain generalization while Volpi et al. [193] demonstrate that adversarial data augmentation on a single domain is sufficient. Further, Volpi and Murino [192] use popular image transformations (e.g. brightness, contrast, sharpness) with different intensity levels to train a more robust model, or Somavarapu, Ma, and Kira [174] use other stylizing techniques. Several methods also use GANs to augment the available training data $\left\lbrack  {{151},{167},{219}}\right\rbrack$ or use other methods to generate synthetic domains [218]. Qiao, Zhao, and Peng [148] deploy an adversarial domain augmentation approach using a Wasserstein Auto-Encoder [184].

### 2.4 Common Datasets

There exist several datasets that are commonly used in domain generalization research. Here, we want to introduce the most popular choices as well as interesting datasets to consider. We give an overview over Rotated MNIST, Colored MNIST, Office-Home, VLCS, PACS, Terra Incognita, DomainNet, and ImageNet-C. Currently, the most popular choices include PACS, VLCS, and Office-Home.

#### 2.4.1 Rotated MNIST

The Rotated MNIST (RMNIST) dataset [66] is a variation of the original MNIST dataset [105] where each digit got rotated by degrees $\{ 0,{15},{30},{45},{60},{75}\}$ . Each rotation angle represents one domain as shown in Table 2.2 for classes " 2" and " 4". The overall dataset in Gulrajani and Lopez-Paz [73] includes 70000 images from 10 homogeneous classes(0 - 9)each with dimension $1 \times  {28} \times  {28}$ .

#### 2.4.2 Colored MNIST

The Colored MNIST (CMNIST) dataset [9] is another variation of the original MNIST dataset [105]. The grayscale images of MNIST got colored in red and green. The respective label corresponds to a combination of digit and color where the color correlates to the class label with factors $\{ {0.1},{0.2},{0.9}\}$ as domains and the digit has a constant correlation of 0.75 . Since this is a synthetic dataset, the factors can easily be adapted or extended to more domains. We report these numbers since they are used in Arjovsky et al. [9] and Gulrajani and Lopez-Paz [73]. Since the correlation factor between color and label varies between domains, this dataset is well-suited for determining a models capability of removing color as a predictive feature [9].

To construct the dataset Arjovsky et al. [9] first assign an initial label $\widetilde{y} = 0$ for digit $0 - 4$ and $\widetilde{y} = 1$ for digit $5 - 9$ . This initial label is then flipped with a probability of ${25}\%$ to obtain the final label $y$ . Finally, we obtain the color $z$ by flipping the label $y$ with probabilities ${p}^{d} \in  \{ {0.1},{0.2},{0.9}\}$ depending on the domain. The image is then colored red for $z = 1$ or green for $z = 0$ [9]. Samples for both classes across domains can be seen in Table 2.2.

Overall, the dataset in Gulrajani and Lopez-Paz [73] contains 70000 images from 2 homogeneous classes (green $\&$ red) of dimension $2 \times  {28} \times  {28}$ .

#### 2.4.3 Office-Home

The Office-Home dataset [190] provides 15588 images from 65 categories across 4 domains. The domains include Art, Clipart, Products (objects without a background), and Real-World (captured with a regular camera). Samples from these domains for the classes "alarm-clock" and "bed" can be seen in Table 2.2. On average, each class contains around 70 images with a maximum of 99 images in a category [190]. In Gulrajani and Lopez-Paz [73] they use dimension $3 \times  {224} \times  {224}$ for each image.

![bo_d1c3r777aajc7389qf00_23_174_182_1271_1895_0.jpg](images/bo_d1c3r777aajc7389qf00_23_174_182_1271_1895_0.jpg)

Table 2.2: Samples for two different classes across domains for popular datasets

#### 2.4.4 VLCS

The VLCS dataset [52] is a dataset that utilizes photographic datasets as individual domains. As such, it contains the domains PASCAL VOC (V) [51], LabelMe (L) [158], Caltech101 (C) [111], and SUN09 (S) [33]. In total, there are 10729 images from 5 classes. Samples for the classes "bird" and "car" can be seen in Table 2.2. In Gulrajani and Lopez-Paz [73] they use the dimension $3 \times  {224} \times  {224}$ for each image.

#### 2.4.5 PACS

The PACS dataset [107] consists of images from different domains including Photo (P), Art (A), Cartoon (C), and Sketch (S) as individual domains. As such, it extends the previously photo-dominated data sets in domain generalization [107]. It includes seven homogeneous classes (dog, elephant, giraffe, guitar, horse, house, person) across the four previously mentioned domains. Table 2.2 shows samples from the "dog" and "elephant" classes across all domains.

In total, PACS contains 9991 images which got obtained by intersecting classes from Caltech256 (Photo), Sketchy (Sketch) [160], TU-Berlin (Sketch) [49], and Google Images (all but Sketch) [107].

#### 2.4.6 Terra Incognita

The Terra Incognita dataset is a subset of the initial Caltech camera traps dataset proposed by Beery, Horn, and Perona [17]. It contains photographs of wild animals taken by camera traps at different locations (IDs:38,43,46,100) which represent the domains. As such, the version used by Gulrajani and Lopez-Paz [73] contains 24788 images of 10 classes, each with size $3 \times  {224} \times  {224}$ . Samples from two different classes can be seen in Table 2.2. The chosen locations represent the Top-4 locations with the largest number of images, each with more than 4000 images.

The main data challenges that arise in this dataset include illumination, motion blur, size of the region of interest, occlusion, camouflage, and perspective [17]. This includes animals not always being salient or them being small or far from the camera which results in only partial views of the animals' body being available [17].

#### 2.4.7 DomainNet

The DomainNet dataset [141] contains six domains: clipart (48129 images), infographic (51605 images), painting (72266 images), quickdraw (172500 images), real (172947 images), and sketch (69128 images) for 345 classes. In total, it contains 586575 images that got accumulated by searching a category with a domain name in multiple image search engines and, as an exception, players of the game "Quick Draw!" for the quickdraw domain [141].

To secure the quality of the dataset, they hired 20 annotators for a total of 2500 hours to filter out falsely labeled images [141]. Each category has an average of 150 images for the domains clipart and infographic, 220 images for painting and sketch, and 510 for the real domain [141].

#### 2.4.8 ImageNet-C

The ImageNet-C dataset [80] contains images out of ImageNet [157] permutated according to 15 corruption types each with 5 levels of severity which results in 75 domains. The types of corruptions are out of the categories "noise", "blur", "weather", and "digital" [80]. Table 2.2 shows a few of the available corruptions at severity 3 for the same image sample of two different classes. As their corruptions, they provide Gaussian Noise, Shot Noise, Impulse Noise, Defocus Blur, Frosted Glass Blur, Motion Blur, Zoom Blur, Snow, Frost, Fog, Brightness, Contrast, Elastic, and Pixelate [80]. Overall, the dataset provides all 1000 ImageNet classes where each image has the standard dimension of $3 \times  {224} \times  {224}$ . Currently, this dataset is not implemented by Gulrajani and Lopez-Paz [73].

### 2.5 Considerations regarding model validation

In traditional supervised learning setups, we train our model on the training dataset, validate its hyperparameters (e.g. number of layers or hidden units in a neural network) on a separate validation dataset, and finally evaluate our model on an unused test dataset. Notice, that the validation dataset should be distributed identically to the test data to properly fit the hyperparameters of our architecture. This is not a straightforward process for domain generalization, as we lack a proper validation dataset with the needed statistical properties. There exist several approaches to this problem, some of them being more grounded than others. Here we give an overview of the three approaches outlined by Gulrajani and Lopez-Paz [73] that are respectively used in their DG framework DomAINBED.

Training-domain validation set In this approach, each training domain gets further split into training and validation subsets where all validation subsets across domains get pooled into one global validation set. We can then maximize the model's performance on that global validation set to set the hyperparameters. This approach assumes the similarity of training and test distributions.

Leave-one-domain-out cross-validation We can train $s$ models with equal hyperparameters based on the $s$ training domains where we each hold one of the domains out of training. This allows us to validate on the held-out domain and average among them to calculate the global held-out domain accuracy. Based on that, we can choose a model and re-train it on all of the training domains.

Test-domain validation set (oracle) A rather statistically biased way of validating the model's hyperparameters is incorporating the test dataset as a validation dataset. Because of this, it is considered bad style and should be avoided or at least explicitly marked. However, one method that is possible is to restrict the test dataset access as done by Gulrajani and Lopez-Paz [73] where they prohibit early stopping and only use the last checkpoint.

Other works have also come up with alternative methods to choose the hyperparameters. For example, Krueger et al. [101] validate the hyperparameters on all domains of the VLCS dataset and then apply the settings to PACS while D'Innocente and Caputo [35] use a validation technique that combines probabilities specific to their method.

### 2.6 Deep-Dive into Representation Self-Challenging

Since some of our proposed methods use ideas from Representation Self-Challenging (RSC) [86], we explain their approach more in detail here. They deploy two RSC variants called Spatial-Wise RSC and Channel-Wise RSC which they randomly alternate between. Generally, these are shown in Algorithm 1 and operate on features after the last convolutional layer.

First, RSC calculates the gradient of the upper layer with respect to the latent feature representation according to Equation (2.8). Here, $\odot$ is the element-wise product and $\dot{\mathbf{y}}$ is the one-hot encoding of

the ground truth.

$$
{\mathbf{g}}_{\mathbf{z}} = \frac{\partial \left( {w\left( \mathbf{z}\right)  \odot  \dot{\mathbf{y}}}\right) }{\partial \mathbf{z}} \tag{2.8}
$$

Afterward, they average-pool the gradients to obtain ${\widetilde{\mathbf{g}}}_{\mathbf{z}}$ . The key difference between the Spatial-Wise and Channel-Wise RSC lies in the average pooling done to compute ${\widetilde{\mathbf{g}}}_{\mathbf{z}}$ in line 5 and the duplication in line 6 in Algorithm 1. While for Spatial-Wise RSC average pooling is done on the channel dimension according to Equation (2.9) yielding ${\widetilde{\mathbf{g}}}_{\mathbf{z}, i, j} \in  {\mathbb{R}}^{{H}_{\mathbf{z}} \times  {W}_{\mathbf{z}} \times  1}$ for spatial location(i, j), in Channel-Wise RSC the same computation is done on the spatial dimension with Equation (2.10) yielding ${\widetilde{\mathbf{g}}}_{\mathbf{z}} \in  {\mathbb{R}}^{1 \times  1 \times  K}$ , a vector with the size of the feature map count.

$$
{\widetilde{\mathbf{g}}}_{\mathbf{z}, i, j} = \frac{1}{K}\mathop{\sum }\limits_{{k = 1}}^{K}{\mathbf{g}}_{\mathbf{z}, i, j}^{k} \tag{2.9}
$$

$$
{\widetilde{\mathbf{g}}}_{\mathbf{z}} = \frac{1}{{H}_{\mathbf{z}}{W}_{\mathbf{z}}}\mathop{\sum }\limits_{{i = 1}}^{{H}_{\mathbf{z}}}\mathop{\sum }\limits_{{j = 1}}^{{W}_{\mathbf{z}}}{\mathbf{g}}_{\mathbf{z}, i, j} \tag{2.10}
$$

Depending on which dimensions are missing to get back to the original size of $\mathbf{z},{\mathbf{g}}_{\mathbf{z}} \in  {\mathbb{R}}^{{H}_{\mathbf{z}} \times  {W}_{\mathbf{z}} \times  K}$ , the computed values get duplicated along these dimensions. In the case of the Spatial-Wise RSC these are the channels, while for the Channel-Wise RSC these are the spatial dimensions.

Next, Huang et al. [86] compute the(100 - p)th percentile with the threshold value as ${q}_{p}$ and compute the mask ${\mathbf{m}}_{i, j}$ for spatial location(i, j)based on Equation (2.11). This mask is set to 0 for the corresponding Top- $p$ percentage elements in ${\widetilde{\mathbf{g}}}_{\mathbf{z}}$ and therefore has the same shape.

$$
{\mathbf{m}}_{i, j} = \left\{  \begin{array}{ll} 0, & \text{ if }{\widetilde{\mathbf{g}}}_{\mathbf{z}, i, j} \geq  {q}_{p} \\  1, & \text{ otherwise } \end{array}\right.  \tag{2.11}
$$

Huang et al. [86] apply the computed mask on the feature representation to yield ${\widetilde{\mathbf{z}}}_{p} = \mathbf{z} \odot  \mathbf{m}$ which they validate using Equation (2.12). This computes the difference with and without the masking in the correct class probabilities and yields a difference score for each sample in the vector $\mathbf{c}$ .

$$
\mathbf{c} = \mathop{\sum }\limits_{{c = 1}}^{C}{\left( \operatorname{softmax}\left( w\left( \mathbf{z}\right) \right)  \odot  \dot{\mathbf{y}} - \operatorname{softmax}\left( w\left( \widetilde{\mathbf{z}}\right) \right)  \odot  \dot{\mathbf{y}}\right) }_{c} \tag{2.12}
$$

A positive value represents that the masking for that sample made the classifier less certain about the correct class while a negative value represents the opposite and made the classifier more certain about the correct class. Similar to previously, Huang et al. [86] calculate Top- $p$ of the positive values with the threshold as ${b}_{p}$ . They revert the whole masking for all Top- $p$ samples inside each batch according to Equation (2.13) where each spatial location(i, j)of the mask associated with sample $n$ gets set back to 1 if the condition applies, otherwise the mask values remain unchanged.

$$
{\mathbf{m}}_{i, j}^{n} = \left\{  \begin{array}{ll} 1, & \text{ if }\;{\mathbf{c}}_{n} \leq  {b}_{p} \\   - , & \text{ otherwise } \end{array}\right.  \tag{2.13}
$$

Finally, we mask the features with the obtained final mask to obtain $\widetilde{\mathbf{z}} = \mathbf{z} \odot  \mathbf{m}$ , compute the loss $\mathcal{L}\left( {w\left( \widetilde{\mathbf{z}}\right) ,\mathbf{y}}\right)$ and backpropagate to the whole network.

Problems Interestingly, since many architectures like ResNet-18/ResNet-50 deploy average pooling in their forward pass after the last convolutional layer, naïve Spatial-Wise RSC doesn't make sense since average pooling is done along the channel dimension and such architectures additionally average pool on the spatial dimension. This results in feature values getting spread evenly across the image regardless of the masking. Even though this isn't mentioned in their paper, they address this issue in their official repository and propose an alternative computation. For that, they calculate the mean

Algorithm 1: Spatial- and Channel-Wise RSC

---

Input: Data $\mathbf{X},\mathbf{Y}$ with ${\mathbf{x}}_{i} \in  {\mathbb{R}}^{H \times  W \times  3}$ , drop factor $p$ , epochs $T$

while epoch $\leq  T$ do

	for every sample (or batch) $\mathbf{x},\mathbf{y}$ do

		Extract features $\mathbf{z} = \phi \left( \mathbf{x}\right)$ // $\mathbf{z}$ has shape ${\mathbb{R}}^{{H}_{\mathbf{z}} \times  {W}_{\mathbf{z}} \times  K}$

		Compute gradient ${\mathbf{g}}_{\mathbf{z}}$ w.r.t features according to Equation (2.8)

		Compute ${\widetilde{\mathbf{g}}}_{\mathbf{z}, i, j}$ by avg. pooling using ${50}\%$ Equation (2.9) or ${50}\%$ Equation (2.10)

		Duplicate ${\widetilde{\mathbf{g}}}_{\mathbf{z}}$ along channel/spatial dimension for initial shape

		Compute mask ${\mathbf{m}}_{i, j}$ according to Equation (2.11)

		Mask features to obtain ${\widetilde{\mathbf{z}}}_{p} = \mathbf{m} \odot  \mathbf{z}\;$ // Evaluate effect of preliminary mask $\downarrow$

		Compute change $\mathbf{c}$ according to Equation (2.12)

		Revert masking for specific samples according Equation (2.13)

		Mask features $\widetilde{\mathbf{z}} = \mathbf{m} \odot  \mathbf{z}$

		Compute loss $\mathcal{L}\left( {w\left( \widetilde{\mathbf{z}}\right) ,\mathbf{y}}\right)$ and backpropagate to whole network

	end

end

---

${\widetilde{\mathbf{g}}}_{\mathbf{z}, i, j}$ from Equation (2.9) on the gradients of features from the previous convolutional layer, instead of the last one, and downsample it by factor 0.5 to match the size.

Our Results In an effort to provide somewhat fair results which aren't too optimistic and neither too penalizing, we run the original RSC code five times for each of the testing environments and compute the average performance in Table 2.3.

<table><tr><td>Run</td><td>$\mathbf{P}$</td><td>A</td><td>C</td><td>S</td></tr><tr><td>1</td><td>93.23</td><td>81.69</td><td>78.11</td><td>81.14</td></tr><tr><td>2</td><td>93.41</td><td>79.44</td><td>77.38</td><td>80.55</td></tr><tr><td>3</td><td>94.37</td><td>80.08</td><td>76.58</td><td>79.18</td></tr><tr><td>4</td><td>93.71</td><td>81.49</td><td>78.84</td><td>81.90</td></tr><tr><td>5</td><td>93.95</td><td>79.39</td><td>76.75</td><td>81.19</td></tr><tr><td>Average</td><td>93.73</td><td>80.41</td><td>77.53</td><td>80.79</td></tr><tr><td>Reported</td><td>95.99</td><td>83.43</td><td>80.31</td><td>80.85</td></tr></table>

Table 2.3: Reproduced results for Representation Self-Challenging using the official code base on the PACS dataset and with a ResNet-18 backbone.

Given these observations, we follow other works such as Nuriel, Benaim, and Wolf [137] and report our reproduced results whenever comparing to RSC.

## Explainability in Deep Learning

Machine Learning systems and especially deep neural networks have the characteristic that they are often seen as "black-boxes" i.e. they are hard to interpret and pinpointing as a user how and why they converge to their prediction is often very difficult, if not impossible. Neural networks commonly lack transparency for human understanding [180]. This property becomes a prominent impediment for intelligent systems deployed in impactful sectors like, for example, employment [24, 149, 216], jurisdiction [74], healthcare [140], or banking loans where users would like to know the deciding factors for decisions. As such, we would like systems that are easily interpretable, relatable to the user, provide contextual information about the choice, and reflect the intermediate thinking of the user for a decision [199]. Since these properties are very broad, it is not surprising that researchers in this field have very different approaches. For this chapter, we used the field guide by Xie et al. [199] to paint an appropriate overview and properly introduce the different approaches. Commonly, methods try to provide better solutions with respect to Confidence, Trust, Safety, and Ethics to improve the overall explainability of the model [199]:

Confidence The confidence of a machine learning system is high when the "reasoning" behind a decision between the model and the user matches often. For example, saliency attention maps [87, 138] ensure that semantically relevant parts of an image get considered and therefore increase confidence.

Trust Trust is established when the decision of an intelligent system doesn't need to be validated anymore. Recently, many works have studied the problem of whether a model can safely be adopted $\left\lbrack  {{63},{93},{188}}\right\rbrack$ . To be able to trust a model, we need to ensure satisfactory testing of the model and users need experience with it to ensure that the results commonly match the expectation [199].

Safety Safety needs to be high for machine learning systems that have an impact on people's lives in any form. As such, the model should perform consistently as expected, prevent choices that may hurt the user or society, have high reliability under all operating conditions, and provide feedback on how the operating conditions influence the behavior.

Ethics The ethics are defined differently depending on the moral principles of each user. In general, though, one can create an "ethics code" on which a system's decisions are based off [199]. Any sensitive characteristic e.g. religion, gender, disability, or sexual orientation are features that should be handled with great care. Similarly, we try to reduce the effect of any features that serve as a proxy for any type of discrimination process e.g. living in a specific part of a city, such as New York City's Chinatown, can be a proxy for the ethical background or income. Since this chapter gives a high-level overview of recent advances in explainability for neural networks, also concerning domain generalization, it is up to the reader's background if this is necessary.

### 3.1 Related topics

There exist several concepts which are related to explainable deep learning. Here, we explicitly cover model debugging which tries to identify aspects that hinder training inference, and fairness and bias which especially tackles the ethics trait to search for differences in regular and irregular activation patterns to promote robust and trustworthy systems [199].

#### 3.1.1 Model Debugging

Model debugging, similar to traditional software debugging, tries to pinpoint aspects of the architecture, data-processing, or training process which cause errors [199]. It aims at giving more insights into the model, allowing easier solving of faulty behavior. While such approaches help to open the black-box of neural network architectures, we handle them distinctly from the other literature here.

Amershi et al. [7] propose MODELTRACKER which is a debugging framework and interactive visualization that displays traditional statistics like Area Under the Curve (AUC) or confusion matrices. It also shows how close samples are in the feature space and allows users to expand the visualization to show the raw data or annotate them. Alain and Bengio [3] deploy linear classifiers to predict the information content in intermediate layers where the features of every layer serve as input to a separate classifier. They show that using features from deeper layers improves prediction accuracy and that level of linear separability increases monotonically. Fuchs et al. [59] introduce neural stethoscopes as a framework for analyzing factors of influence and interactively promoting and suppressing information. They extend the ordinary DNN architecture via a parallel two-layer perceptron at different locations where the input are the features from any layer from the main architecture. This stethoscope is then trained on a supplemental task and the loss is back-propagated to the main model with weighting factor $\lambda$ [59]. This factor controls if the stethoscope functions analytical $\left( {\lambda  = 0}\right)$ , auxiliary $\left( {\lambda  > 0}\right)$ , or adversarial $\left( {\lambda  < 0}\right)$ [59]. Further, Kang et al. [95] use model assertions which are functions for a model's input and output that indicate when errors may be occurring. They show that with these they can solve problems where car detection in successive frames disappears and reappears [95]. Their model debugging is therefore implemented through a verification system [199].

#### 3.1.2 Fairness and Bias

To secure model fairness, there exist several definitions which have emerged in the literature in recent years. Group fairness [25], also known as demographic parity or statistical parity, aims at equalizing benefits across groups with respect to protected characteristics (e.g. religion, gender, etc.). By definition, if group $A$ has twice as many members as group $B$ , twice as many people in group $A$ should receive the benefit when compared to $B$ [199]. On the other hand, individual fairness [47] tries to secure that similar feature inputs get treated similarly. There also exist other notions of fairness such as equal opportunity [75], disparate mistreatment [204], or other variations [78, 197].

Methods that try to ensure fairness in machine learning systems can be classified into three approaches which operate during different steps called pre-processing, in-processing, post-processing:

1. Pre-processing methods adapt the input data beforehand to remove features correlated to protected characteristics. As such, they try to learn an alternative feature representation without relying on these types of attributes [70, 120, 144, 208].

2. In-processing approaches add adjustments for fairness during the model learning process. This way, they punish decisions that are not aligned with certain fairness constraints $\left\lbrack  {1,{45},{48}}\right\rbrack$ .

3. Post-processing methods adjust the model predictions after training to account for fairness. It is the reassignment of class labels after classification to minimize classification errors subject to a particular fairness constraint [53, 75, 146].

### 3.2 Previous Works

Generally, we can divide methods for explainable deep neural networks in visualization, model distillation, and intrinsic methods [199]. While visualization methods try to highlight features that strongly correlate with the output of the DNN, model distillation builds upon a jointly trained "white-box" model, following the input-output behavior of the original architecture and aiming to identify its decision rules [199]. Finally, intrinsic methods are networks designed to explain their output, hence they aim to optimize both, its performance and the respective explanations [199].

#### 3.2.1 Visualization

Commonly, visualization methods use saliency maps to display the saliency values of the features i.e. to which degree the features influence the model's prediction [199]. We can further divide visualization methods into back-propagation and perturbation-based approaches where they respectively determine these values based on the volume of the gradient or between modified versions of the input [199].

## Back-Propagation

These approaches stick to the gradient passed through the network to determine the relevant features. As a simplistic baseline, one can display the partial derivative with respect to each input feature multiplied by its value [199]. This way, Simonyan, Vedaldi, and Zisserman [170] and Springenberg et al. [175] assess the sensitivity of the model for input changes [199]. This can also be done for collections of intermediate layers $\left\lbrack  {{11},{129},{168},{206}}\right\rbrack$ .

Zhou et al. [217] introduce class activation maps (CAMs) which are shown in Figure 3.1 based on global average pooling (GAP) [118]. With GAP, they deploy the following CNN structure at the end of the network: GAP (Convs) $\rightarrow$ Fully Connected Layer (FC) $\rightarrow$ softmax where CAMs ${\mathbf{M}}_{c}$ for each class $c$ are then calculated according to Equation (3.1). Here, $K$ are the number of convolutional filters, $\mathbf{z}$ are the activations of the last convolutional layer, and ${w}_{k, c}$ indicate the weights from the feature map $k$ of the last Convolutional Layer to logit for class $c$ of the FC [217].

$$
{\mathbf{M}}_{c} = \mathop{\sum }\limits_{k}^{K}{\mathbf{z}}_{k}{w}_{k, c} \tag{3.1}
$$

By upsampling the map to the image size, they can visualize the image regions responsible for a certain class [217]. Therefore, every class has its own class activation map. The drawback of their approach is, that their method can only be applied to networks that use the GAP (Convs) $\rightarrow$ Fully Connected Layer (FC) $\rightarrow$ softmax architecture at the end [199].

![bo_d1c3r777aajc7389qf00_31_192_186_1231_349_0.jpg](images/bo_d1c3r777aajc7389qf00_31_192_186_1231_349_0.jpg)

Figure 3.1: Class activation maps across different architectures: [217]

Selvaraju et al. [164] solve this impediment by generalizing CAMs to gradient-weighted class activation maps (Grad-CAMs). Since their approach only requires the final activation function to be differentiable, they are generally applicable to a broader range of CNN architectures [164, 199]. For that, they compute an importance score ${\widetilde{\mathbf{g}}}_{\mathbf{z}, c}^{k}$ as:

$$
{\widetilde{\mathbf{g}}}_{\mathbf{z}, c}^{k} = \frac{1}{{H}_{\mathbf{z}}{W}_{\mathbf{z}}}\mathop{\sum }\limits_{{i = 1}}^{{H}_{\mathbf{z}}}\mathop{\sum }\limits_{{j = 1}}^{{W}_{\mathbf{z}}}\frac{\partial {y}_{c}}{\partial {\mathbf{z}}_{i, j}^{k}}. \tag{3.2}
$$

Here, ${y}_{c}$ is the score before softmax and we calculate the gradient with respect to the feature map ${\mathbf{z}}^{k}$ in the final convolutional layer for every neuron positioned at(i, j)in the ${H}_{\mathbf{z}} \times  {W}_{\mathbf{z}}$ feature map $\left\lbrack  {{164},{199}}\right\rbrack$ . Afterward, these importance scores get linearly combined for every feature map as shown in Equation (3.3) where they get additionally passed through a ReLU function:

$$
{\mathbf{M}}_{c} = \max \left( {0,\mathop{\sum }\limits_{{k = 1}}^{K}{\widetilde{\mathbf{g}}}_{\mathbf{z}, c}^{k}{\mathbf{z}}^{k}}\right) . \tag{3.3}
$$

This computation inherently yields a ${H}_{\mathbf{z}} \times  {W}_{\mathbf{z}}$ importance map ( ${14} \times  {14}$ for VGG [171] and AlexNet $\left\lbrack  \begin{array}{l} {100} \end{array}\right\rbrack  ,7 \times  7$ for ResNet [77]) where we upsample it using bilinear interpolation onto the image size to yield the Grad-CAM.

Apart from CAMs, there also exist other methods like layer-wise relevance propagation [11, 41, 103, 129], deep learning important features (DeepLIFT) [168], or integrated gradients [181] which are not described in detail here. Please refer to Xie et al. [199] or the original works for more information.

## Perturbation

Perturbation methods alternate the input features to compute their respective relevance for the model's output by comparing the differences between the original and permutated version.

Zeiler and Fergus [206] sweep a gray patch over the image to determine how the model will react to occluded areas. Once, an area with a high correlation to the output is covered, the prediction performance drops [199, 206]. Li, Monroe, and Jurafsky [113] deploy a similar idea for NLP tasks where they erase words and measure the influence on the model's performance. Fong and Vedaldi [57] define three perturbations i) replacing patches with a constant value, ii) adding noise to a region, and iii) blurring the area [57, 199]. Zintgraf et al. [220] propose a method based on Robnik-Sikonja and Kononenko [156] where they calculate the relevance of a feature for class $c$ through the prediction difference between including the respective feature or occluding it [220]. For that, they simulate the absence of each feature. A positive value for their computed difference means the feature influences the model’s decision for class $c$ and a negative value means the feature influences the prediction against class $c$ [220]. Zintgraf et al. [220] extend the initial method by Robnik-Sikonja and Kononenko [156] via removing patches instead of pixels and adapting the method for intermediate layers [199].

#### 3.2.2 Model distillation

Model distillation methods allow for post-training explanations where we learn a distilled model which imitates the original model's decisions on the same data [199]. It has access to information from the initial model and can therefore give insights about the features and output correlations [199]. Generally, we can divide these methods into local approximation and model translation approaches. These either replicate the model behavior on a small subset of the input data based on the idea that the mechanisms a network uses to discriminate in a local area of the data manifold is simpler (local approximation) or stick to using the entire dataset with a smaller model (model translation) [199].

## Local approximations

Even though it may seem unintuitive to pursue approaches that don't explain every decision made by the DNN, practitioners often want to interpret decisions made for a specific data subset e.g. employee performance indicators for those fired with poor performance [199]. One of the most popular local approximations is the method proposed by Ribeiro, Singh, and Guestrin [153] called local interpretable model-agnostic explanations (LIME). They propose a notation where from an unexplainable global model ${f}_{\mathbf{\theta }}$ and an original representation of an instance ${\mathbf{x}}_{i}$ we want an interpretable model ${g}_{{\mathbf{\theta }}^{\prime }}$ from the class of potentially interpretable models ${g}_{{\mathbf{\theta }}^{\prime }} \in  \mathcal{G}$ . Since not all models ${g}_{{\mathbf{\theta }}^{\prime }}$ have the same degree of interpretability, they define a complexity measure $\Pi \left( {g}_{{\mathbf{\theta }}^{\prime }}\right)$ which could be the depth of the tree for decision trees or the number of non-zero weights in linear models [153]. They incorporate this complexity measure, together with the prediction of ${g}_{{\mathbf{\theta }}^{\prime }}$ for ${f}_{\mathbf{\theta }}$ in a certain locality, in their loss term. There also exist many other works which build upon LIME to solve certain drawbacks [50, 154]. We don't go into details here as it is only partially related to this thesis.

## Model Translation

The idea of model translation is to mimic the behavior of the original deep neural network on the whole dataset, contrary to local approximations which only use a smaller subset. Some works have tried to distill neural networks into decision trees $\left\lbrack  {{58},{182},{215}}\right\rbrack$ , finite state automata [82], Graphs [213-215], or causal- and rule-based models [76, 134]. Generally, the distilled models could be easier to deploy, faster to converge, or simply be more explainable [199].

#### 3.2.3 Intrinsic methods

Finally, intrinsic methods jointly output an explanation in combination with their prediction. In an ideal world, such methods would be on par with state-of-the-art models without explainability. This approach introduces an additional task that gets jointly trained with the original task of the model [199]. The additional task usually tries to provide either text explanations [26, 79, 81, 207], an explanation association $\left\lbrack  {6,{44},{90},{106}}\right\rbrack$ , or prototypes $\left\lbrack  {{32},{114}}\right\rbrack$ which differ in the provided explainability type as well as the degree of insight.

## Attention mechanism

The attention mechanism [189] takes motivation from the human visual focus and peripheral perception [162]. With that, humans can focus on certain regions to achieve high resolution while adjacent objects are perceived with a rather low resolution [162]. In the attention mechanism, we learn a conditional distribution over given inputs using weighted contextual alignment scores (attention weights) [199]. These allow for insights on how strongly different input features are considered during model inference [199]. The alignment scores can be computed differently, for example, either content-based [71], additive [13], based on the matrix dot-product [121], or as a scaled version of the matrix dot-product [189]. Especially due to the transformer architecture [189], attention has shown to improve the neural network performance originally in natural language processing [23, 39, 102], but also more recently in image classification and other computer vision tasks $\left\lbrack  {8,{205}}\right\rbrack$ . It has also been shown that attention is the update rule of a modern Hopfield network with continuous states [152], an architecture that hasn't been used very much in modern neural network models. There has also been a discussion on whether attention counts as explanation and to which degree the process offers insights into the inner workings of a neural network $\left\lbrack  {{91},{165},{196}}\right\rbrack$ .

## Text explanations

Text explanations are natural language outputs that explain the model decision using a form like "This image is of class $A$ because of $B$ ". As such, they are quite easy to understand regardless of the user's background. Works that take this approach are, for example, Hendricks et al. [79] or Park et al. [138]. Drawbacks of textual explanations are that they i) require supervision for explanations during training and ii) explanations have been shown to be inconsistent which questions the validity of these types of explanations [27].

## Explanation association

Latent features or input elements that are combined with human-understandable concepts are classified under explanation associations. Such explanations either combine input or latent features with semantic concepts, associate the model prediction with a set of input elements, or utilize object saliency maps to visualize relevant image parts [199].

## Prototypes

Finally, model prototype approaches are specifically designed for classification tasks [18, 97, 147, 198]. The term prototype in few- and zero-shot learning settings are points in the feature space representing a single class [114]. In such methods, the distance to the prototype determines how an observation is classified. The prototypes are not limited to a single observation but can also be obtained using a combination of observations or latent representations [199]. A criticism, on the other hand, is a data instance that is not well represented by the set of prototypes [128]. To obtain explainability using prototypes, one can trace the reasoning path for the prediction back to the learned prototypes [199]. Li et al. [114] use a prototype layer to deploy an explainable image classifier. They propose an architecture with an autoencoder and a prototype classifier. This prototype classifier calculates the ${\ell }^{2}$ distance between the encoded input and each of the prototypes, passes this through a fully connected layer to compute the sums of these distances, and finally normalizes them through a softmax layer [114]. Since these prototypes live in the same space as the encoded inputs, they can be visualized with a jointly trained decoder [114]. This property, coupled with the fully connected weights, allows for explainability through visualization of the prototypes and their respective influence on the prediction. Figure 3.2 shows the visualizations for the generic number prototypes obtained by Li et al. [114] on the MNIST [105] and the car angle prototypes on the Car [55] dataset.

![bo_d1c3r777aajc7389qf00_34_312_190_1088_150_0.jpg](images/bo_d1c3r777aajc7389qf00_34_312_190_1088_150_0.jpg)

Figure 3.2: Prototypes for the MNIST (left) and Car (right) dataset: [114]

Chen et al. [32] introduce a prototypical part network (ProtoPNet) which has similar components to Li et al. [114], namely a convolutional neural network projecting onto a latent space and a prototype classifier. The approach chosen by Chen et al. [32] is different as the prototypes are more fine-grained and represent parts of the input image [199]. Hence, their model associates image patches with prototypes for explanations [199]. Figure 3.3 illustrates this approach for bird species classification.

![bo_d1c3r777aajc7389qf00_34_253_693_1176_419_0.jpg](images/bo_d1c3r777aajc7389qf00_34_253_693_1176_419_0.jpg)

Figure 3.3: Image of a clay colored sparrow and its decomposition into prototypes: [32]

As a general framework, we would like to learn $m$ prototypes $\mathcal{P} = {\left\{  {\mathbf{p}}_{j}\right\}  }_{j = 1}^{m}$ with ${\mathbf{p}}_{j} \in  {\mathbb{R}}^{{H}_{\mathbf{p}} \times  {W}_{\mathbf{p}} \times  K}$ which each resemble a prototypical activation pattern in a patch of the convolutional output [32]. Each prototype unit ${g}_{{\mathbf{p}}_{j}}$ of the prototype layer ${g}_{\mathbf{p}}$ computes some distance metric (e.g. ${\ell }^{2}$ norm) between the $j$ -th prototype ${\mathbf{p}}_{j}$ and all patches of $\mathbf{z}$ with the same shape as ${\mathbf{p}}_{j}$ and inverts that into a similarity score using some mapping function [32]. This computation yields a similarity map ${\Psi }_{j} \in  {\mathbb{R}}^{{H}_{\mathbf{z}} \times  {W}_{\mathbf{z}}}$ which shows how representative the $j$ -th prototype is for each latent patch and this can be upsampled to the initial image size for an overlay heatmap [32]. When max-pooling this similarity map, we obtain a similarity score that measures how strong the $j$ -th prototype is represented by any latent patch.

Chen et al. [32] compute the maximum similarity score for each prototype unit ${g}_{{\mathbf{p}}_{j}}$ by:

$$
{g}_{{\mathbf{p}}_{j}}\left( \mathbf{z}\right)  = \mathop{\max }\limits_{{\overline{\mathbf{z}} \in  \operatorname{patches}\left( \mathbf{z}\right) }}\log \left( \frac{{\begin{Vmatrix}\overline{\mathbf{z}} - {\mathbf{p}}_{j}\end{Vmatrix}}_{2}^{2} + 1}{{\begin{Vmatrix}\overline{\mathbf{z}} - {\mathbf{p}}_{j}\end{Vmatrix}}_{2}^{2} + \epsilon }\right) , \tag{3.4}
$$

where the squared ${\ell }^{2}$ distance is used and $\epsilon$ is a small numerical stability factor. Their modified logarithm function satisfies the property of a similarity mapping function since with an increasing ${\ell }^{2}$ - norm the function returns a smaller value i.e. larger distance values correspond to smaller similarities. Keep in mind, that this needs to be appropriately adjusted when using any other distance metric. For example, both the cosine and dot product measures have increasing similarity values for increasing distance values. In theory, any Bregman divergence [16] is applicable as a distance metric. However, Snell, Swersky, and Zemel [173] have observed that this choice can be very impactful and the ${\ell }^{2}$ -norm has a better performance than cosine distance for few-shot tasks.

To enforce that every class $c$ will be represented by at least one prototype, there are a pre-determined number of prototypes for each class which is denoted as ${\mathcal{P}}_{c}$ with ${\mathcal{P}}_{c} \subseteq  \mathcal{P}$ . During training, Chen et al. [32] minimize the objective:

$$
\mathop{\min }\limits_{{\mathcal{P},{\mathbf{\theta }}_{\phi }}}\frac{1}{n}\mathop{\sum }\limits_{{i = 1}}^{n}{\mathcal{L}}_{\mathrm{{ce}}}\left( {\underset{\text{ Prediction }{\widehat{\mathbf{y}}}_{i}}{\underbrace{w \circ  {g}_{\mathbf{p}} \circ  \phi }},{\mathbf{y}}_{i}}\right)  + {\lambda }_{1}{\mathcal{L}}_{\text{clst }} + {\lambda }_{2}{\mathcal{L}}_{\text{sep }}, \tag{3.5}
$$

where the cluster loss ${\mathcal{L}}_{\text{clst }}$ and separation loss ${\mathcal{L}}_{\text{sep }}$ are defined as:

$$
{\mathcal{L}}_{\text{clst }} = \frac{1}{n}\mathop{\sum }\limits_{{i = 1}}^{n}\mathop{\min }\limits_{{j : {\mathbf{p}}_{j} \in  {\mathcal{P}}_{{\mathbf{y}}_{i}}}}\mathop{\min }\limits_{{\overline{\mathbf{z}} \in  \operatorname{patches}\left( \mathbf{z}\right) }}{\begin{Vmatrix}\overline{\mathbf{z}} - {\mathbf{p}}_{j}\end{Vmatrix}}_{2}^{2} \tag{3.6}
$$

$$
{\mathcal{L}}_{\text{sep }} =  - \frac{1}{n}\mathop{\sum }\limits_{{i = 1}}^{n}\mathop{\min }\limits_{{j : {\mathbf{p}}_{j} \notin  {\mathcal{P}}_{{\mathbf{y}}_{i}}}}\mathop{\min }\limits_{{\overline{\mathbf{z}} \in  \text{ patches }\left( \mathbf{z}\right) }}{\begin{Vmatrix}\overline{\mathbf{z}} - {\mathbf{p}}_{j}\end{Vmatrix}}_{2}^{2}. \tag{3.7}
$$

Note, that this is only the first part of a multi-step training procedure where Equation (3.5) solely optimizes the parameters of the featurizer ${\mathbf{\theta }}_{\phi }$ and the prototypes $\mathcal{P}$ , but not the classifier as its weights ${\mathbf{\theta }}_{w}$ are frozen with an initialization for each connection ${w}_{c, j}$ between the $j$ -th prototype unit ${g}_{{\mathbf{p}}_{j}}$ and the logit for class $c$ and $\forall j : {\mathbf{p}}_{j} \in  {\mathcal{P}}_{c}$ as ${w}_{c, j} = 1$ while $\forall j : {\mathbf{p}}_{j} \notin  {\mathcal{P}}_{c}$ it is set to ${w}_{c, j} =  - {0.5}$ . The positive connection for the similarity to a prototype of that specific class increases the prediction value for class $c$ while the negative connection for the similarity to a prototype of a different class decreases it. This initialization, together with the separation loss, guide the prototypes to represent semantic concepts for a class but also ensure that the same semantic concept is not learned by the other classes. Later on, Chen et al. [32] optimize the classifier parameters ${\mathbf{\theta }}_{w}$ for sparsity while fixing all other parameters to reduce the effect of negative network reasoning for classification.

While Li et al. [114] need a decoder for visualizing the prototypes, Chen et al. [32] don't require this component since they visualize the closest latent image patch across the full training dataset instead of directly visualizing the prototype [32]. They also show that when combining several of their networks into a larger network, their method is on par with best-performing deep models [32].

### 3.3 Explainability for Domain Generalization

To the best of our knowledge, the only work using explanations for domain generalization is by Zunino et al. [221]. They introduce a saliency-based approach utilizing a 2D binary map of pixel locations for the ground-truth object segmentation as input. This map contains a 1 in a pixel location where the class label object is present and 0 otherwise. Even though they were able to show that their method better focuses on relevant regions, we identify the additional annotations of class label objects as a major drawback which we solve in this work. Indeed, we not only avoid the use of annotations by directly restoring to Grad-CAMs (see Section 4.1), but our idea is also different in spirit. In fact, we do not force the network to focus on relevant regions as in [221] but we want the network to use i) different explanations for the same objects (to achieve better generalization) and ii) the explanations to be consistent across domains (to avoid overfitting a single input distribution).

## Proposed Methods

In order to apply some of the previously mentioned topics from the explainability literature to the domain generalization task, we specifically investigate the usage of gradient class activation maps from Section 3.2.1, as well as prototypes from Section 3.2.3. Our methods which are based upon these approaches are respectively described in Section 4.1 (DIVCAM), Section 4.2 (ProDROP), and Section 4.2.3 (D-TRANSFORMERS).

### 4.1 Diversified Class Activation Maps (DivCAM)

In Section 2.6 we introduce the concept of Representation Self-Challenging for domain generalization while in Section 3.2.1 class activation maps, and specifically Grad-CAM gets introduced. It is quite easy to see that the importance scores ${\widetilde{\mathbf{g}}}_{\mathbf{z}, c}^{k}$ in Grad-CAM from Equation (3.2) are a generalization of the spatial mean ${\widetilde{\mathbf{g}}}_{\mathbf{z}}$ used in Channel-Wise RSC from Equation (2.10). The spatial mean ${\widetilde{\mathbf{g}}}_{\mathbf{z}}$ only computes the gradient with respect to the features for the most probable class while the importance scores ${\widetilde{\mathbf{g}}}_{\mathbf{z}, c}^{k}$ are formulated theoretically for all possible classes but similarly compute the gradient with respect to the feature representation. Both perform spatial average pooling.

Despite the effectiveness of the model, we believe the approach of Huang et al. [86] does not fully exploit the relation between a feature vector and the actual content of the image. We argue (and experimentally demonstrate) that we can directly use CAMs to construct the self-challenging task. In particular, while the raw target gradient represents the significance of each channel in each spatial location for the prediction, CAMs allow us to better capture the actual importance of each image region. Thus, performing the targeted masking on highest CAM values means explicitly excluding the most relevant region of the image that where used for the prediction, forcing the model to focus on other (and interpretable) visual cues for recognizing the object of interests.

Therefore, as an intuitive baseline, we propose Diversified Class Activation Maps (DIvCAM), combining the two approaches as shown in Algorithm 2 or visualized on a high level in Figure 4.1. For that, during each step of the training procedure, we extract the features, compute the gradients with respect to the features as in Equation (2.8), and perform spatial average pooling to yield ${\widetilde{\mathbf{g}}}_{\mathbf{z}}$ according to Equation (2.10). Our method deviates from Channel-Wise RSC by next computing class activation maps ${\mathbf{M}}_{c} \in  {\mathbb{R}}^{{H}_{\mathbf{z}} \times  {W}_{\mathbf{z}} \times  1}$ according to Equation (4.1) for the ground truth class label.

$$
{\mathbf{M}}_{c} = \max \left( {0,\mathop{\sum }\limits_{{k = 1}}^{K}{\widetilde{\mathbf{g}}}_{\mathbf{z}, c}^{k}{\mathbf{z}}^{k}}\right)  \tag{4.1}
$$

![bo_d1c3r777aajc7389qf00_37_188_187_1237_423_0.jpg](images/bo_d1c3r777aajc7389qf00_37_188_187_1237_423_0.jpg)

Figure 4.1: Visualization of the DIVCAM training process

Based on these maps and similar to Equation (2.11), we compute a mask $\mathbf{m} \in  {\mathbb{R}}^{{H}_{\mathbf{z}} \times  {W}_{\mathbf{z}} \times  1}$ for the Top- $p$ percentile of map activations as:

$$
{\mathbf{m}}_{c, i, j} = \left\{  \begin{array}{ll} 0, & \text{ if }\;{\mathbf{M}}_{c, i, j} \geq  {q}_{p} \\  1, & \text{ otherwise } \end{array}\right.  \tag{4.2}
$$

As class activation maps and the corresponding masks are averaged along the channel dimension to be specific for each spatial location, we duplicate the mask along all channels to yield a mask with the same size of the features $\mathbf{m} \in  {\mathbb{R}}^{{H}_{\mathbf{z}} \times  {W}_{\mathbf{z}} \times  K}$ which can directly be multiplied with the features to mask them and to regularize the training procedure:

$$
\widetilde{\mathbf{z}} = \mathbf{m} \odot  \mathbf{z}, \tag{4.3}
$$

where $\odot$ is the Hadamard product. The new feature vector $\widetilde{\mathbf{z}}$ is used as input to the classifier $w$ in place of the original $\mathbf{z}$ to regularize the training procedure. For the masked features, we compute the Cross-Entropy Loss from Equation (2.3) and backpropagate the gradient of the loss to the whole network to update the parameters.

Intuitively, constantly applying this masking for all samples within each batch disregards important features and results in relatively poor performance as the network isn't able to learn discriminative features in the first place. Therefore, applying the mask only for certain samples within each batch as mentioned by Huang et al. [86, Secton 3.3] should yield a better performance. For convenience, we call this process mask batching. On top of that, one could schedule the mask batching with an increasing factor (e.g. linear schedule) such that masking gets applied more in the later training epochs where discriminative features have been learned. We apply the mask only if the sample $n$ is within the(100 - b)th percentile of confidences for the correct class (stored in the change vector $\mathbf{c}$ for each sample $n$ ) and reset the mask otherwise by setting each spatial location(i, j)back to 1 :

$$
{\mathbf{m}}_{c, i, j}^{n} = \left\{  \begin{array}{ll} 1, & \text{ if }\;{\mathbf{c}}^{n} \leq  {q}_{b} \\   - , & \text{ otherwise } \end{array}\right.  \tag{4.4}
$$

where ${\mathbf{c}}^{n}$ is is the confidence on the ground truth for sample $n$ . This procedure enforces that masks only get applied to samples which are already classified well enough such that the network can now focus on other discriminative properties. For our full ablation study on applying the masks within each batch, please see Section 5.4.2. Figure 4.2 also shows some of the class activation maps produced by DIVCAM throughout the training procedure.

Algorithm 2: Diversified Class Activation Maps (DIVCAM)

---

Input: Data $\mathbf{X},\mathbf{Y}$ with ${\mathbf{x}}_{i} \in  {\mathbb{R}}^{H \times  W \times  3}$ , drop factor $p, b$ , epochs $T$

while epoch $\leq  T$ do

	for every batch $\mathbf{x},\mathbf{y}$ do

		Extract features $\mathbf{z} = \phi \left( \mathbf{x}\right)$ $//\mathbf{z}$ has shape ${\mathbb{R}}^{{H}_{\mathbf{z}} \times  {W}_{\mathbf{z}} \times  K}$

		Compute ${\mathbf{g}}_{\mathbf{z}, c}$ with Equation (2.8)

		Compute ${\widetilde{\mathbf{g}}}_{\mathbf{z}, c}^{k}$ with Equation (2.10) // ${\widetilde{\mathbf{g}}}_{\mathbf{z}}$ has shape ${\mathbb{R}}^{1 \times  1 \times  K}$

		Compute ${\mathbf{M}}_{c}$ with Equation (4.1) // $\mathrm{M}$ has shape ${\mathbb{R}}^{{H}_{\mathbf{z}} \times  {W}_{\mathbf{z}} \times  1}$

		Compute ${\mathbf{m}}_{c, i, j}$ with Equation (4.2)

		Repeat mask along channels // Afterwards $\mathrm{m}$ has shape ${\mathbb{R}}^{{H}_{\mathbf{z}} \times  {W}_{\mathbf{z}} \times  K}$

		Adapt ${\mathbf{m}}_{c, i, j}$ with Equation (4.4)

		Compute $\widetilde{\mathbf{z}}$ with Equation (4.3)

		Backpropagate loss ${\mathcal{L}}_{ce}\left( {w\left( \widetilde{\mathbf{z}}\right) ,\mathbf{y}}\right)$

	end

end

---

To try and improve the effectiveness of our CAM-based regularization approach, we can borrow some practices from the weakly-supervised object localization literature. In particular, we explore the use of Homogeneous Negative CAMs (HNC) [180] and Threshold Average Pooling (TAP) [12]. Both methods improve the performance of ordinary CAMs and focus them better on the relevant aspects of an image. See Section 5.4.3 for an evaluation of these variants.

#### 4.1.1 Global Average Pooling bias for small activation areas

According to Bae, Noh, and Kim [12], one problem of traditional class activation maps is that the activated areas for each feature map differ by the respective channels because these capture different class information which isn't properly reflected in the global average pooling operation. Since every channel is globally averaged, smaller feature activation areas result in smaller globally averaged values despite a similar maximum activation value. This doesn't necessarily mean that one of the features is more relevant for the prediction, but can simply be caused by a large area with small activations. To combat this problem, the weight ${w}_{k, c}$ corresponding to the smaller value, is often trained to be higher when comparing two channels [12]. Instead of the global average pooling operation, they propose Threshold Average Pooling (TAP). When adapting their approach for our notation, we receive Equation (4.5) where ${\tau }_{\text{tap }} = {\lambda }_{\text{tap }} \cdot  \max \left( {\widetilde{\mathbf{z}}}^{k}\right)$ with ${\lambda }_{\text{tap }} \in  \lbrack 0,1)$ as a hyperparameter and ${p}_{\text{tap }}^{k}$ denotes the scalar from the $k$ -th channel of ${\mathbf{p}}_{tap}$ as it is a $k$ -dimensional vector.

$$
{p}_{\text{tap }}^{k} = \frac{\mathop{\sum }\limits_{{i = 1}}^{{H}_{\mathbf{z}}}\mathop{\sum }\limits_{{j = 1}}^{{W}_{\mathbf{z}}}\mathbb{1}\left( {{\widetilde{\mathbf{z}}}_{i, j}^{k} > {\tau }_{\text{tap }}}\right) {\widetilde{\mathbf{z}}}_{i, j}^{k}}{\mathop{\sum }\limits_{{i = 1}}^{{H}_{\mathbf{z}}}\mathop{\sum }\limits_{{j = 1}}^{{W}_{\mathbf{z}}}\mathbb{1}\left( {{\widetilde{\mathbf{z}}}_{i, j}^{k} > {\tau }_{\text{tap }}}\right) } \tag{4.5}
$$

When incorporating this into DIvCAM, this results in changing the global average pooling after self-challenging has been applied to a threshold average pooling. Generally, this plug-in replacement can be seen as a trade-off between global max pooling which is better at identifying the important activations of each channel and global average pooling which has the advantage that it expands the activation to broader regions, allowing the loss to backpropagate.

#### 4.1.2 Smoothing negative Class Activation Maps

Based on the analysis of Sun et al. [180], negative class activation maps, i.e. the class activation maps for classes other than the ground truth, often have false activations even when they are not present in an image. To solve this localization error, they propose a loss function which adds a weighted homogeneous negative ${CAM}$ (HNC) loss term to the existing Cross-Entropy loss. This is shown in Equation (4.6) where ${\lambda }_{1}$ controls the weight of the additional loss term.

$$
{\mathcal{L}}_{\text{neg }} = {\mathcal{L}}_{ce}\left( {\mathbf{y}, w\left( \widetilde{\mathbf{z}}\right) }\right)  + {\lambda }_{1}{\mathcal{L}}_{\text{hnc }}\left( {\mathbf{y},\mathbf{M}}\right)  \tag{4.6}
$$

![bo_d1c3r777aajc7389qf00_39_193_180_1181_398_0.jpg](images/bo_d1c3r777aajc7389qf00_39_193_180_1181_398_0.jpg)

Figure 4.2: Used class activation maps for DivCAM-S in update step 300/5000, 2700/5000, and ${4500}/{5000}$ using a ResNet-50 backbone. For the giraffe, we initially focus on the neck while our masks force the network to also take into consideration the overall shape, finally settling on the torso. For the elephant, we initially focus mainly on the elephant trunk and later guide the network towards taking also the shape into consideration.

Sun et al. [180] propose two approaches for implementing ${\mathcal{L}}_{\text{hnc }}$ in their work, both operating on the Top- $m$ most confident negative classes. The first one is based on the mean squared error which suppresses peak responses in the CAMs, while the second one utilizes the Kullback-Leibler (KL) divergence trying to minimize the difference between negative CAMs and an uniform probability map. Since they report similar performance for these variants and the KL loss applies a comparably smoother penalty, we use the KL divergence for our method:

$$
{\mathcal{L}}_{hnc}\left( {\mathbf{y},\mathbf{M}}\right)  = \mathop{\sum }\limits_{{c \in  {J}_{ > }^{m}}}{D}_{KL}\left( {\mathbf{U}\parallel {\mathbf{M}}_{c}^{\prime }}\right) . \tag{4.7}
$$

Here, ${J}_{ > }^{m}$ is the set of Top- $m$ negative classes with the highest confidence score, $\mathbf{U} \in  {\mathbb{R}}^{{H}_{\mathbf{z}} \times  {W}_{\mathbf{z}}}$ is a uniform probability matrix with all elements having the value ${\left( {H}_{\mathbf{z}}{W}_{\mathbf{z}}\right) }^{-1}$ , and ${\mathbf{M}}_{c}^{\prime } = \sigma \left( {\mathbf{M}}_{c}\right)$ is a probability map produced by applying the softmax function $\sigma$ to each negative class activation map ${\mathbf{M}}_{c}$ . Plugging in the definition of the KL divergence and removing the constant as in Equation (4.8) finally results in a simplified version as Equation (4.9).

$$
{D}_{KL}\left( {\mathbf{U}\parallel {\mathbf{M}}_{c}^{\prime }}\right)  = \mathop{\sum }\limits_{{i = 1}}^{{H}_{\mathbf{z}}}\mathop{\sum }\limits_{{j = 1}}^{{W}_{\mathbf{z}}}{\mathbf{U}}_{i, j} \cdot  \log \left( \frac{{\mathbf{U}}_{i, j}}{{\mathbf{M}}_{c, i, j}^{\prime }}\right)  = \text{ const } - \frac{1}{{H}_{\mathbf{z}}{W}_{\mathbf{z}}}\mathop{\sum }\limits_{{i = 1}}^{{H}_{\mathbf{z}}}\mathop{\sum }\limits_{{j = 1}}^{{W}_{\mathbf{z}}}\log \left( {\mathbf{M}}_{c, i, j}^{\prime }\right)  \tag{4.8}
$$

Generally, with this approach, we add two hyperparametes in the form of the weighting parameter $\lambda$ and the cut-off number $k$ for the Top- $k$ negative classes.

$$
{\mathcal{L}}_{\text{hnc }}\left( {\mathbf{y},\mathbf{M}}\right)  =  - \frac{1}{{H}_{\mathbf{z}}{W}_{\mathbf{z}}}\mathop{\sum }\limits_{{c \in  {J}_{ > }^{m}}}\mathop{\sum }\limits_{{i = 1}}^{{H}_{\mathbf{z}}}\mathop{\sum }\limits_{{j = 1}}^{{W}_{\mathbf{z}}}\log \left( {\mathbf{M}}_{c, i, j}^{\prime }\right)  \tag{4.9}
$$

Since we use Grad-CAMs instead of ordinary CAMs in DIvCAM, naïvely applying this would require computing the gradient for every negative class $c$ in the set ${J}_{ > }^{m}$ which would result in computing

Equation (4.10) where ${y}_{c}$ is the confidence of the negative class.

$$
{\mathcal{L}}_{\text{hnc }}\left( {\mathbf{y},\mathbf{M}}\right)  =  - \frac{1}{{H}_{\mathbf{z}}{W}_{\mathbf{z}}}\mathop{\sum }\limits_{{c \in  {J}_{ > }^{m}}}\mathop{\sum }\limits_{{i = 1}}^{{H}_{\mathbf{z}}}\mathop{\sum }\limits_{{j = 1}}^{{W}_{\mathbf{z}}}\log \left( {\sigma \left( {\max \left( {0,\mathop{\sum }\limits_{{k = 1}}^{K}{\left( \frac{1}{{H}_{\mathbf{z}}{W}_{\mathbf{z}}}\mathop{\sum }\limits_{{i = 1}}^{{H}_{\mathbf{z}}}\mathop{\sum }\limits_{{j = 1}}^{{W}_{\mathbf{z}}}\frac{\partial {y}_{c}}{\partial {\mathbf{z}}_{i, j}^{k}}\right) }^{k}{\mathbf{z}}^{k}}\right) }\right) }\right)  \tag{4.10}
$$

To speed up the training for tasks with a large number of classes, we approximate the loss by summing the negative class confidences before backpropagating as shown in Equation (4.11). This amounts to considering all negative classes within ${J}_{ > }^{\prime }$ as one negative class.

$$
{\widehat{\mathcal{L}}}_{\text{hnc }}\left( {\mathbf{y},\mathbf{M}}\right)  =  - \frac{1}{{H}_{\mathbf{z}}{W}_{\mathbf{z}}}\mathop{\sum }\limits_{{i = 1}}^{{H}_{\mathbf{z}}}\mathop{\sum }\limits_{{j = 1}}^{{W}_{\mathbf{z}}}\log \left( {\sigma \left( {\max \left( {0,\mathop{\sum }\limits_{{k = 1}}^{K}{\left( \frac{1}{{H}_{\mathbf{z}}{W}_{\mathbf{z}}}\mathop{\sum }\limits_{{i = 1}}^{{H}_{\mathbf{z}}}\mathop{\sum }\limits_{{j = 1}}^{{W}_{\mathbf{z}}}\frac{\partial {\sum }_{ \in  {J}_{\mathbf{z}}^{m}}{y}_{c}}{\partial {\mathbf{z}}_{i, j}^{k}}\right) }^{k}{\mathbf{z}}^{k}}\right) }\right) }\right)  \tag{4.11}
$$

To finally implement this into DrvCAM, we simply substitute the current loss ${\mathcal{L}}_{ce}\left( {\mathbf{y}, w\left( \widetilde{\mathbf{z}}\right) }\right)$ in line 12 from Algorithm 2 with Equation (4.6) where ${\mathcal{L}}_{\text{hnc }}\left( {\mathbf{y},\mathbf{M}}\right)$ is implemented through our approximation ${\widehat{\mathcal{L}}}_{\text{hnc }}\left( {\mathbf{y},\mathbf{M}}\right)$ given in Equation (4.11).

Next, we can try to utilize domain information in DIVCAM by aligning distributions of class activation maps produced by the same class across domains. We want their distributions to align as close as possible such that we cannot identify which domain produced which class activation map. For that, we can utilize some methods previously introduced in Section 2.3.1, in particular we explore minimizing the sample maximum mean discrepancy introduced in Equation (2.7) and using a conditional domain adversarial neural network (CDANN). See Section 5.4.3 for an evaluation of these variants.

#### 4.1.3 Conditional Domain Adversarial Neural Networks

We combine the domain adversarial neural network (CDANN) approach, originally introduced by Li et al. [116], with DivCAM to align the distributions of CAMs across domains. For that, we try to predict the domain to which a class activation map belongs by passing it to a multi-layer perceptron $\omega$ . We compute the cross entropy loss between the predictions and the domain ground truth $\mathbf{d}$ and weight it for each sample by the occurrence probability of the respective class. After weighting, we can sum up all the losses and add it to our overall loss, weighted by ${\lambda }_{2}$ :

$$
{\mathcal{L}}_{adv} = {\mathcal{L}}_{ce}\left( {\mathbf{y}, w\left( \widetilde{\mathbf{z}}\right) }\right)  + {\lambda }_{2}\left( {{\mathcal{L}}_{ce}\left( {\mathbf{d},\omega \left( \mathbf{M}\right) }\right)  + \eta {\begin{Vmatrix}{\nabla }_{\mathbf{M}}{\mathcal{L}}_{ce}\left( \mathbf{d},\omega \left( \mathbf{M}\right) \right) \end{Vmatrix}}_{2}}\right) . \tag{4.12}
$$

During each training step, we either update the discriminator, i.e. the predictor for the domain, or the generator, i.e. the main network including featurizer and classifier. The discriminator loss inherently includes a ${\ell }^{2}$ penalty on the gradients, weighted by $\eta$ .

#### 4.1.4 Maximum Mean Discrepancy

Given two samples ${\mathbf{x}}^{{\xi }_{1}}$ and ${\mathbf{x}}^{{\xi }_{2}}$ drawn from two individual, unknown domain distributions ${\mathcal{D}}_{{\xi }_{1}}$ and ${\mathcal{D}}_{{\xi }_{2}}$ , the maximum mean discrepancy (MMD) is given by Equation (4.13) where $\varphi  : {\mathbb{R}}^{d} \rightarrow  \mathcal{H}$ is a feature map and $k\left( {\cdot , \cdot  }\right)$ is the kernel function induced by $\varphi \left( \cdot \right)$ . We consider every distinct pair of source domains $\left( {{\xi }_{u},{\xi }_{v}}\right)$ , representing training domains ${\xi }_{u}$ and ${\xi }_{v}$ , with ${\xi }_{u} \neq  {\xi }_{v}$ to be in the set $\mathfrak{P}$ .

$$
{\mathcal{L}}_{\text{dist }} = \mathop{\sum }\limits_{{{\xi }_{u},{\xi }_{v} \in  \mathfrak{P}}}{\begin{Vmatrix}{\mathbb{E}}_{{\mathbf{x}}^{{\xi }_{u}} \sim  {\mathcal{D}}_{{\xi }_{u}}}\left\lbrack  \varphi \left( \phi \left( {\mathbf{x}}^{{\xi }_{u}}\right) \right) \right\rbrack   - {\mathbb{E}}_{{\mathbf{x}}^{{\xi }_{v}} \sim  {\mathcal{D}}_{{\xi }_{v}}}\left\lbrack  \varphi \left( \phi \left( {\mathbf{x}}^{{\xi }_{v}}\right) \right) \right\rbrack  \end{Vmatrix}}_{\mathcal{H}} \tag{4.13}
$$

![bo_d1c3r777aajc7389qf00_41_188_189_1234_402_0.jpg](images/bo_d1c3r777aajc7389qf00_41_188_189_1234_402_0.jpg)

Figure 4.3: Domain-agnostic Prototype Network

In simpler terms, we map features into a reproducing kernel Hilbert space $\mathcal{H}$ , and compute their mean differences within the RKHS. This loss pushes samples from different domains, which represent the same class, to lie nearby in the embedding space. According to Sriperumbudur et al. [176], this mean embedding is injective, i.e. arbitrary distributions are uniquely represented in the RKHS, if we use a characteristic kernel. For this work, we choose the gaussian kernel shown in Equation (4.14) which is a well-known characteristic kernel.

$$
k\left( {x,{x}^{\prime }}\right)  = \exp \left( {-\frac{{\begin{Vmatrix}x - {x}^{\prime }\end{Vmatrix}}^{2}}{2{\sigma }^{2}}}\right)  \tag{4.14}
$$

Since the choice of kernel function can have a significant impact on the distance metric, we adopt the approach of Li et al. [112] and use a mixture kernel by averaging over multiple choices of $\sigma$ as already implemented in DomAINBED. This gets incorporated into our loss function weighted by ${\lambda }_{3}$ with:

$$
{\mathcal{L}}_{\text{mmd }} = {\mathcal{L}}_{ce}\left( {\mathbf{y}, w\left( \widetilde{\mathbf{z}}\right) }\right)  + {\lambda }_{3}{\mathcal{L}}_{\text{dist }}. \tag{4.15}
$$

With this approach, we inherently align the computed masks by aligning the individual samples from different domains, aiming at producing domain invariant masks. This procedure can be applied at different levels e.g. on the features, class activation maps, or masked class activation maps. In Section 5.4.3, we only provide results for the feature level due to the effectiveness that similar approaches showed in DOMAINBED. However, we observe a similar trend for the other application levels as well.

### 4.2 Prototype Networks for Domain Generalization

Another approach to combine explainability methods with the task of domain generalization is to use the prototype method outlined in Section 3.2.3. In particular, we can directly adapt the approach of Chen et al. [32] as a baseline where we associate each class with a pre-defined number of prototypes. The cluster and separation losses from Equation (3.6) ensure that each prototype resembles a prototypical attribute for the associated class and we minimize them according to Equation (3.5).

For our application scenario, this prototype layer is used after the domain-agnostic featurizer $\phi$ and operates on the features like illustrated in Figure 4.3. As each prototype is trained with data from all training domains $\Xi$ , they become inherently domain agnostic. This baseline uses a joint classifier $w$ to output the final prediction which operates on the maximum similarity for all the prototypes and some latent patch. Similar to Chen et al. [32], we preface the prototype layer with two convolutional layers with kernel size 1, a ReLU function between them, and finally a sigmoid activation function. We observe that having roughly 100 initial update steps where only these in-between layers are trained is crucial for competitive performance. We anticipate that these steps are used to adapt the randomly-initialized convolutional weights to the image statics imposed by the pre-trained backbone. ${}^{1}$ While this baseline is meaningful, we also consider a second variant where we build an ensemble of prototype layers, each learning domain-specific prototypes.

![bo_d1c3r777aajc7389qf00_42_227_188_1234_422_0.jpg](images/bo_d1c3r777aajc7389qf00_42_227_188_1234_422_0.jpg)

Figure 4.4: Ensemble Prototype Network

#### 4.2.1 Ensemble Prototype Network

Following the intuition provided by works that utilize model ensembling, which have been described in Section 2.3.2, we can use domain information by up-scaling the network to use a prototype layer for each domain separately. For the PACS dataset, this would correspond to having three prototype layers, one for each training domain e.g. a photo, art, and cartoon prototype layer when predicting sketch images. Each prototype layer is only trained with images from their corresponding domain.

As shown in Figure 4.4, we associate each domain with both a prototype layer and a classifier which takes similarity scores of that domain's prototypes as input. During training, we only feed images of the associated domain to the respective prototype layer and classifier to enforce this domain correspondence. The aggregation weights of the final linear layer are set to a one-hot encoding representing the correct domain. During testing, we can then feed the new unseen domain to each domain prototype layer, allowing each domain's prototypes to influence the final prediction.

There exist multiple strategies for setting the aggregation weights during this stage. The most simple version is to set the influence of each domain uniform, i.e. if we have three training domains the connections from each domain would have the weight $\frac{1}{3}$ such that each domain has the same influence on the final prediction. Our second approach is to jointly train a domain predictor to output the weights for the aggregation layer which can either be used both, during training and testing, or only during testing, similar to what is done by Mancini et al. [124]. This method allows for a more flexible aggregation of the separated predictions coming from the different prototype layers, enabling the network to put more emphasis on the relevant domain prototypes.

Lastly, we also experiment with an ensemble variant that is specific to prototype layers. Instead of only pre-defining a number of prototypes for each class in the domain agnostic prototype layer outlined in Section 4.2, we can also pre-define domain correspondence for each prototype. Training is then done by passing each domain separately to the prototype layer and masking the overall prototype outputs if they do not correspond to the current environment. The cluster and separation losses are adapted to an average over the individual environments as:

$$
{\mathcal{L}}_{\text{clst }} = \frac{1}{s}\mathop{\sum }\limits_{{\xi  \in  \Xi }}\frac{1}{{n}_{\xi }}\mathop{\sum }\limits_{{i = 1}}^{{n}_{\xi }}\mathop{\min }\limits_{{j : {\mathbf{p}}_{j} \in  {\mathcal{P}}_{{\mathbf{y}}_{i}}^{\xi }}}\mathop{\min }\limits_{{\bar{\mathbf{z}} \in  \text{ patches }\left( {\mathbf{z}}^{\xi }\right) }}{\begin{Vmatrix}\overline{\mathbf{z}} - {\mathbf{p}}_{j}\end{Vmatrix}}_{2}^{2} \tag{4.16}
$$

$$
{\mathcal{L}}_{\text{sep }} = \frac{1}{s}\mathop{\sum }\limits_{{\xi  \in  \Xi }} - \frac{1}{{n}_{\xi }}\mathop{\sum }\limits_{{i = 1}}^{{n}_{\xi }}\mathop{\min }\limits_{{j : {\mathbf{p}}_{j} \notin  {\mathcal{P}}_{{\mathbf{y}}_{i}}^{\xi }}}\mathop{\min }\limits_{{\bar{\mathbf{z}} \in  \operatorname{patches}\left( {\mathbf{z}}^{\xi }\right) }}{\begin{Vmatrix}\overline{\mathbf{z}} - {\mathbf{p}}_{j}\end{Vmatrix}}_{2}^{2}, \tag{4.17}
$$

---

${}^{1}$ Further implementation details can be found here: https://github.com/SirRob1997/DomainBed/

---

where ${\mathcal{P}}_{{\mathbf{y}}_{i}}^{\xi }$ denotes the prototypes associated with the specific class and environment while ${\mathbf{z}}^{\xi }$ denotes the latent representation of an image corresponding to the current domain. This ensemble variant inherently removes the need for setting appropriate aggregations weights as prototype activations are simply masked during training while during testing all prototypes are kept, allowing each prototype from each source domain to influence the prediction. With a domain specific cross entropy loss:

$$
{\mathcal{L}}_{\mathrm{{ce}}} = \frac{1}{s}\mathop{\sum }\limits_{{\xi  \in  \Xi }}\frac{1}{{n}_{\xi }}\mathop{\sum }\limits_{{i = 1}}^{{n}_{\xi }} - \mathop{\sum }\limits_{{c = 1}}^{C}{y}_{i, c}^{\xi } \cdot  \log \left( {\widehat{y}}_{i, c}^{\xi }\right) , \tag{4.18}
$$

we optimize the final loss of our ensemble model as:

$$
\mathcal{L} = {\mathcal{L}}_{\mathrm{{ce}}} + {\lambda }_{\text{clst }}{\mathcal{L}}_{\text{clst }} + {\lambda }_{\text{sep }}{\mathcal{L}}_{\text{sep }}. \tag{4.19}
$$

While all of these ensemble variants should work given the intuition from previous works that have been using model ensembles for learned domain-specific latent spaces, we observe that these assumptions do not hold for prototype networks based on our additional experiments of the proposed variants. For us, any prototype ensemble was consistently outperformed by one domain-agnostic prototype layer.

#### 4.2.2 Diversified Prototypes (ProDrop)

Initial experiments with both domain-agnostic and domain-specific prototype layers lead to unsatisfactory results. To investigate this behavior, we analyze the pairwise prototype ${\ell }_{2}$ -distance as well as the cosine-distance $\varrho$ which for any two prototypes ${\mathbf{p}}_{i}$ and ${\mathbf{p}}_{j}$ are given by:

$$
{\ell }_{2} = {\begin{Vmatrix}{\mathbf{p}}_{i} - {\mathbf{p}}_{j}\end{Vmatrix}}_{2} \tag{4.20}
$$

$$
\varrho  = 1 - \frac{{\mathbf{p}}_{i}{\mathbf{p}}_{j}}{{\begin{Vmatrix}{\mathbf{p}}_{i}\end{Vmatrix}}_{2}{\begin{Vmatrix}{\mathbf{p}}_{j}\end{Vmatrix}}_{2}}. \tag{4.21}
$$

Through the ${\ell }_{2}$ -distance we can grasp the euclidean distance between any two prototypes while the cosine-distance $\varrho  \in  \left\lbrack  {0,2}\right\rbrack$ is the inverted version of the cosine similarity which is a metric to judge the cosine of the angle between them. Here, we visualize the cosine-distance instead of the cosine similarity to match the color-scheme of the ${\ell }_{2}$ -distance i.e. low values resemble closeness.

The results of this analysis can be seen in Figure 4.5 and Figure 4.6 for the first data split and a negative weight of ${w}_{c, j} =  - {1.0}\forall j : {\mathbf{p}}_{j} \notin  {\mathcal{P}}_{c}$ but we also show the same plots for ${w}_{c, j} = {0.0}$ and the two additional data splits in Appendix B. As both of the used metrics are symmetric, only the upper triangle is visualized. We observe that depending on the data split and negative weight, the model sometimes converges to having one or two prototypes per class that have a large ${\ell }_{2}$ distance while many of the other prototypes are close. Striking examples for this behavior can be seen in Figure B. 1 for the sketch domain or in Figure 4.5 for the sketch and cartoon domain. This observation suggests, that in these scenarios the model fails to properly use all of the available prototypes and only relies on a significantly reduced subset per class, not training the other prototypes. In relation to the cosine-distance, however, we can often observe that exactly these prototypes with a high pairwise ${\ell }_{2}$ -distance to all the other prototypes have a slightly lower cosine-distance. Such behavior can be seen for example in Figure B. 1 in the art and cartoon environment or in Figure 4.5 for the sketch and cartoon domain. For the most part, many cosine-distances tend to be low and more or less uniformly spaced. Nevertheless, we can occasionally identify "streaking" patterns in the cosine-distances where prototypes for certain classes are well-spaced but they have a larger (or equal) cosine-distance to prototypes of other classes. See for example Figure B. 1 for the sketch domain, Figure B. 6 for the sketch and photo domain, and Figure B. 7 for the sketch and cartoon domain.

![bo_d1c3r777aajc7389qf00_44_227_188_1234_615_0.jpg](images/bo_d1c3r777aajc7389qf00_44_227_188_1234_615_0.jpg)

Figure 4.5: Pairwise learned prototype ${\ell }_{2}$ -distance (top) and cosine-distance $\varrho$ (bottom) of the best-performing model with negative weight ${w}_{c, j} =  - {1.0}\forall j : {\mathbf{p}}_{j} \notin  {\mathcal{P}}_{c}$ for each testing domain. Red squares denote prototype class correspondence for the 7 different classes in the PACS dataset. No self-challenging is applied and colormap bounds are adjusted per metric for visualization purposes. Second data split.

From a design standpoint, we would like the prototypes within each class to be reasonably well spaced out in the latent space such that they can resemble different discriminative attributes about each class. That is, we would like the network to utilize all the prototypes and not only rely on a small subset of prototypes or discriminative features for their prediction. The distances of these prototypes to the prototypes of the other classes, however, should not be restrained in any way and should be learned automatically. For example, when predicting different bird species, this allows the network to place similar head prototypes of different classes closer together. The existing cluster and separation losses enforce that each prototype associated with that class is close to at least one latent patch of that class while maximizing the distance to the prototypes of other classes. However, this does not enforce that each prototype associated with that class acts on a different discriminative feature.

One approach to possibly enforce this behavior is to incorporate the self-challenging method previously applied to DIVCAM to the presented prototype network resulting in a novel algorithm we call prototype dropping (PRODROP) which is described in Algorithm 3. In essence, we extract features by passing our input images to the featurizer $\mathbf{z} = \phi \left( \mathbf{x}\right)$ and compute the similarity scores for each prototype by passing it to the prototype layer ${g}_{{\mathbf{p}}_{j}}\left( \mathbf{z}\right)$ with Equation (3.4). Based on these similarity scores, we compute a mask ${\mathbf{m}}_{c, j}$ for the prototypes of the respective class $c$ with the Top- $p$ highest activation:

$$
{\mathbf{m}}_{c, j} = \left\{  \begin{array}{ll} 0, & \text{ if }\;{g}_{{\mathbf{p}}_{j}}\left( \mathbf{z}\right)  \geq  {q}_{c, p}\;\forall j : {\mathbf{p}}_{j} \in  {\mathcal{P}}_{c} \\  1, & \text{ otherwise } \end{array}\right.  \tag{4.22}
$$

Algorithm 3: Prototype Dropping (ProDrop)

---

Input: Data $\mathbf{X},\mathbf{Y}$ with ${\mathbf{x}}_{i} \in  {\mathbb{R}}^{H \times  W \times  3}$ , drop factor $p, b$ , epochs $T$

while epoch $\leq  T$ do

	for every batch $\mathbf{x},\mathbf{y}$ do

		Extract features $\mathbf{z} = \phi \left( \mathbf{x}\right)$ // $\mathbf{z}$ has shape ${\mathbb{R}}^{{H}_{\mathbf{z}} \times  {W}_{\mathbf{z}} \times  K}$

		Compute ${g}_{{\mathbf{p}}_{j}}\left( \mathbf{z}\right)$ with Equation (3.4)

		Compute ${\mathbf{m}}_{c, j}$ with Equation (4.22)

		Adapt ${\mathbf{m}}_{c, j}$ with Equation (4.4)

		Compute ${\widetilde{g}}_{\mathbf{p}}\left( \mathbf{z}\right)$ with Equation (4.23)

		Backpropagate loss ${\mathcal{L}}_{ce}\left( {w\left( {{\widetilde{g}}_{\mathbf{p}}\left( \mathbf{z}\right) }\right) ,\mathbf{y}}\right)  + {\lambda }_{4}{\mathcal{L}}_{\text{clst }} + {\lambda }_{5}{\mathcal{L}}_{\text{sep }}$

	end

end

---

where ${q}_{c, p}$ is the corresponding threshold value. We also apply the mask batching from DivCAM without scheduling which only applies this type of masking for the highest confidence samples on the ground truth. Finally, we can mask the samples using the Hadamard product $\odot$ with:

$$
{\widetilde{g}}_{\mathbf{p}}\left( \mathbf{z}\right)  = \mathbf{m} \odot  {g}_{\mathbf{p}}\left( \mathbf{z}\right) . \tag{4.23}
$$

In practice, all of these operations can be efficiently implemented using torch.quantile, torch.lt, and torch.logical_or on small tensors, all of which pose no significant computational overhead.

The effect of this approach on the pairwise prototype distances can be seen in Figure B.3 as well as Appendix B. We observe, that even though self-challenging helps to boost the overall performance (see Section 5.4.4), it does not particularly well achieve the previously described desired distance properties and only improves them marginally. Positive effects can be seen in Figure 4.6 for the sketch and cartoon domain, Figure B. 10 for the sketch domain, or Figure B. 9 for the cartoon domain.

Our second approach to enforce the desired distance structures is to add an additional intra-class prototype loss term ${\mathcal{L}}_{\text{intra }}$ which maximizes the intra-class prototoype ${\ell }_{2}$ - and/or cosine-distance weighted by ${\lambda }_{6}$ . Again, this loss term can in theory have a few different definitions depending on the chosen distance metrics, we experiment with:

$$
{\mathcal{L}}_{\text{intra }} = \mathop{\sum }\limits_{{{\mathbf{p}}_{i},{\mathbf{p}}_{j} \in  {\mathcal{P}}_{c}}}{\lambda }_{{\ell }_{2}}\underset{{\ell }_{2} - \text{ distance }}{\underbrace{{\begin{Vmatrix}{\mathbf{p}}_{i} - {\mathbf{p}}_{j}\end{Vmatrix}}_{2}}} + {\lambda }_{\varrho }\underset{\text{cosine-distance }}{\underbrace{\left( 1 - \frac{{\mathbf{p}}_{i}{\mathbf{p}}_{j}}{{\begin{Vmatrix}{\mathbf{p}}_{i}\end{Vmatrix}}_{2}{\begin{Vmatrix}{\mathbf{p}}_{j}\end{Vmatrix}}_{2}}\right) }}, \tag{4.24}
$$

where the ${\ell }_{2}$ -distance and the cosine-distance are weighted by ${\lambda }_{{\ell }_{2}}$ and ${\lambda }_{\varrho }$ respectively. Performance results for the loss presented in Equation (4.24) with ${\lambda }_{{\ell }_{2}} = 1$ and ${\lambda }_{\varrho } = 1$ are shown in Section 5.4.5. Since the cosine-distance is bounded, this commonly amounts to the ${\ell }_{2}$ -distance having a higher influence. We also experimented with other values for ${\lambda }_{{\ell }_{2}}$ and ${\lambda }_{\varrho }$ , such as setting either one of them to zero and only applying either the ${\ell }_{2}$ - or the cosine-distance $\left( {{\lambda }_{{\ell }_{2}} = 0,{\lambda }_{\varrho } = 1}\right.$ and $\left. {{\lambda }_{{\ell }_{2}} = 1,{\lambda }_{\varrho } = 0}\right)$ , but couldn't find any further benefits by canceling or re-weighting them differently.

Influence of the negative weight on the distance metrics We also analyze the discrepancies between the distance metrics when comparing ${w}_{c, j} =  - {1.0}\forall j : {\mathbf{p}}_{j} \notin  {\mathcal{P}}_{c}$ and ${w}_{c, j} = {0.0}\forall j : {\mathbf{p}}_{j} \notin  {\mathcal{P}}_{c}$ which can be seen in the figures presented in Appendix B. However, from these plots there were no consistent trends observable which can be made on how the negative weight influences the training behavior of the prototypes.

![bo_d1c3r777aajc7389qf00_46_227_188_1234_615_0.jpg](images/bo_d1c3r777aajc7389qf00_46_227_188_1234_615_0.jpg)

Figure 4.6: Pairwise learned prototype ${\ell }_{2}$ -distance (top) and cosine-distance $\varrho$ (bottom) of the best-performing model with negative weight ${w}_{c, j} =  - {1.0}\forall j : {\mathbf{p}}_{j} \notin  {\mathcal{P}}_{c}$ for each testing domain. Red squares denote prototype class correspondence for the 7 different classes in the PACS dataset. Self-challenging is applied and colormap bounds are adjusted per metric for visualization purposes. Second data split.

#### 4.2.3 Using Support Sets (D-Transformers)

Instead of directly learning the set of prototypes $\mathcal{P}$ , we can rely on a support set similar to what is done by Doersch, Gupta, and Zisserman [43] or Snell, Swersky, and Zemel [173]. Here, the prototypes are based on a support set $S$ consisting of ${n}_{c}$ sample images ${\mathbf{x}}_{i}$ . This support set exists for each of the classes $c$ as ${S}_{c} = {\left\{  {\mathbf{x}}_{i, c}\right\}  }_{i = 1}^{{n}_{c}}$ where ${\mathbf{x}}_{i, c}$ is an image from class $c$ . In the classical setting, the set of prototypes for each class ${\mathcal{P}}_{c}$ is then obtained by computing one prototype for each class ${\mathbf{p}}_{j, c}$ averaging the average-pooled latent representations of the support set as:

$$
{\mathbf{p}}_{j, c} = \frac{1}{\left| {\mathcal{P}}_{c}\right| }\mathop{\sum }\limits_{{{\mathbf{x}}_{i, c} \in  {S}_{c}}}\phi \left( {\mathbf{x}}_{i, c}\right)  \tag{4.25}
$$

Contrary to the previous approach, by averaging all the average-pooled latent representations, there exists only one prototype for each class i.e. $\left| {\mathcal{P}}_{c}\right|  = 1$ and $j = 1$ which loses spatial information. Predictions are again made by computing some distance function between the prototypes and the latent representation of the image to be classified. Doersch, Gupta, and Zisserman [43] preserve this spatial information of the feature extractor and use the attention weights to guide the averaging across support set images and latent patches in a method that they call CROSSTRANSFORMERS. We extend their approach for the domain generalization case here, where we compute attention across multiple training environments. In the following sections this adaptation is referenced as D-TRANSFORMERS.

In particular, similar to Transformers [189] and the original idea by Doersch, Gupta, and Zisserman [43], we use three linear transformations to compute keys, values, and queries. In practice, the key head $\Gamma  : {\mathbb{R}}^{K} \mapsto  {\mathbb{R}}^{{d}_{k}}$ , the value head $\Lambda  : {\mathbb{R}}^{K} \mapsto  {\mathbb{R}}^{{d}_{v}}$ , and the query head $\Omega  : {\mathbb{R}}^{K} \mapsto  {\mathbb{R}}^{{d}_{k}}$ can each be implemented through convolutions with kernel_size = 1 . Prototypes for each domain are computed by passing the support set ${S}_{c}^{\xi } = {\left\{  {\mathbf{x}}_{i, c}^{\xi }\right\}  }_{i = 1}^{{n}_{\xi , c}}$ associated with domain $\xi$ and class $c$ through the feature extractor. For each spatial location $m$ in the resulting features (indexed over ${H}_{\mathbf{z}} \times  {W}_{\mathbf{z}}$ ) of the support set image $i$ , we compute dot-product attention scores between keys ${\mathbf{k}}_{i, m, c}^{\xi } = \Gamma {\left( \phi \left( {\mathbf{x}}_{i, c}^{\xi }\right) \right) }_{m}$ and the query vectors ${\mathbf{q}}_{p}^{\xi } = \Omega {\left( \phi \left( {\mathbf{x}}_{q}^{\xi }\right) \right) }_{p}$ for a query image ${\mathbf{x}}_{q}$ at spatial location $p$ (indexed over ${H}_{\mathbf{z}} \times  {W}_{\mathbf{z}}$ ). Explicitly, the dot similarity ${\alpha }_{i, m, c, p}^{\xi }$ between them is computed as:

$$
{\alpha }_{i, m, c, p}^{\xi } = {\mathbf{k}}_{i, m, c}^{\xi } \cdot  {\mathbf{q}}_{p}^{\xi }. \tag{4.26}
$$

Afterwards, we re-scale this dot similarity by using $\tau  = \sqrt{{d}_{k}}$ and obtain the final attention weights ${\widetilde{\alpha }}_{i, m, c, p}^{\xi }$ using a softmax operation summing over all spatial locations and images in the support set:

$$
{\widetilde{\alpha }}_{i, m, c, p}^{\xi } = \frac{\exp \left( {{\alpha }_{i, m, c, p}^{\xi }/\tau }\right) }{\mathop{\sum }\limits_{{i, m}}\exp \left( {{\alpha }_{i, m, c, p}^{\xi }/\tau }\right) }. \tag{4.27}
$$

Finally, we can use the support-set values ${\mathbf{v}}_{i, m, c}^{\xi } = \Lambda {\left( \phi \left( {\mathbf{x}}_{i, c}^{\xi }\right) \right) }_{m}$ with the attention weights to compute a prototype vector per spatial location $p$ for each domain and class:

$$
{\mathbf{p}}_{p, c}^{\xi } = \mathop{\sum }\limits_{{i, m}}{\widetilde{\alpha }}_{i, m, c, p}^{\xi }{\mathbf{v}}_{i, m, c}^{\xi }. \tag{4.28}
$$

As a distance, we compute the dot similarity between the prototype and the query image values ${\mathbf{w}}_{p}^{\xi } = \Lambda {\left( \phi \left( {\mathbf{x}}_{i, c}^{\xi }\right) \right) }_{p}$ where we sum over the training environments $\xi  \in  \Xi$ and the spatial locations $p$ of

the query image:

$$
\operatorname{dist}\left( {{\mathbf{x}}_{i, c},{S}_{c}}\right)  = \mathop{\sum }\limits_{{\xi  \in  \Xi }}\frac{1}{{H}_{\mathbf{z}}{W}_{\mathbf{z}}}\mathop{\sum }\limits_{p}{\mathbf{p}}_{p, c}^{\xi } \cdot  {\mathbf{w}}_{p}^{\xi }. \tag{4.29}
$$

Most notably, we deploy the dot similarity as a distance metric here instead of the squared ${\ell }^{2}$ -norm used by Doersch, Gupta, and Zisserman [43] since we observe numerical instability for that in our experiments which might be due to the distribution shift in domain generalization. In their work, they reason about using the same value-head $\Lambda$ for the queries as used on the support-set images to ensure that the architecture works as a distance i.e. if the support set contains the same images as the query, they want the euclidean distance to be 0 [43]. Because we observe no performance gains for keeping them separate, we also use the same value head $\Lambda$ for both the queries and support set images to reduce additional parameters to a minimum.

## Chapter 5

## Experiments

In an effort to improve comparability and reproducability, we use DOMAINBED [73] for all ablation studies and experimental results. We compare to all methods currently in DOMAINBED which includes our provided implementation of RSC. Further, all experiments show results for both training-domain validation which assumes that training and testing domains have similar distributions and oracle validation which has limited access to the testing domain. We omit leave-one-domain-out cross-validation as it requires the most computational resources and performs the worst out of the three validation techniques currently available in DomainBED [73].

### 5.1 Datasets and splits

Since the size of the validation dataset can have a heavy impact on performance, we follow the design choices of DOMAINBED and choose ${20}\%$ of each domain as the validation size for all experiments and ablation studies. Here, we present results for VLCS [52], PACS [107], Office-Home [190], Terra Incognita [17], and DomainNet [141]. Although sometimes disregarded in the body of literature for domain generalization, we provide results for three different dataset splits to assess the stability regarding the model selection and to avoid overfitting on one split.

### 5.2 Hyperparameter Distributions & Schedules

For the main results, we use the official DOMAINBED hyperparameter distributions as well as the ADAM optimizer with no learning rate schedule. This corresponds to the setup in which all baselines from Table 5.2 have been evaluated in by Gulrajani and Lopez-Paz [73] to provide a fair comparison. For the hyperparameters that get introduced in our methods, we choose similar distributions as used in the ablation studies from Section 5.4. Further, Section 5.4 also shows the official distributions of DOMAINBED for all other shared hyperparameters such as learning rate $\alpha$ or batch size $\mathcal{B}$ .

### 5.3 Results

The high-level results for DIvCAM-S inside the DomainBED framework and across datasets are shown in Table 5.2. For completeness, we also show results outside of DOMAINBED on the official PACS split in Table 5.3 using a ResNet-18 backbone. The full results, including the performance for choosing any domain inside each dataset as a testing domain, are shown in Appendix A. While we are able to achieve state-of-the-art performance outside of the DOMAINBED framework, utilizing learning rate schedules and hyperparameter fine-tuning, we are also able to achieve Top-4 performance across five datasets within DOMAINBED. Notably, we outperform RSC in almost every scenario, while exhibiting less standard deviation. This leads to more stable results and a more suitable method which can easily be used as a plug-and-play approach. In comparison with all other methods, we achieve good performance for the two most challenging datasets, namely Terra Incognita (Top-2) and DomainNet (Top-4), outperforming RSC for both datasets by up to 2%. This suggests, that directly reconstructing to Grad-CAMs in DIVCAM-S specifically provides value for the more challenging datasets in DOMAINBED. Keep in mind, that this is possible without adding any additional parameters and while providing a framework where intermediate class activation maps can be visualized that guide the networks training process. While this might not be the best explainability method, it certainly can offer more insights than treating the optimization procedure as a block-box without this guidance.

<table><tr><td>Algorithm</td><td>P</td><td>A</td><td>C</td><td>S</td><td>Avg.</td></tr><tr><td>DivCAM-S</td><td>${94.4} \pm  {0.7}$</td><td>${80.5} \pm  {0.4}$</td><td>${74.6} \pm  {2.2}$</td><td>${79.0} \pm  {0.9}$</td><td>${82.1} \pm  {0.3}$</td></tr><tr><td>ProDrop</td><td>${93.6} \pm  {0.6}$</td><td>${82.1} \pm  {0.9}$</td><td>${76.4} \pm  {0.9}$</td><td>${76.3} \pm  {0.6}$</td><td>${82.1} \pm  {0.6}$</td></tr><tr><td>D-TRANSFORMERS</td><td>${93.7} \pm  {0.6}$</td><td>${80.1} \pm  {1.2}$</td><td>${73.3} \pm  {1.3}$</td><td>${72.6} \pm  {1.5}$</td><td>${79.9} \pm  {0.1}$</td></tr></table>

Table 5.1: Performance comparison of the proposed methods for the PACS dataset with a ResNet-18 backbone.

The fact that we are able to achieve state-of-the-art results for DIVCAM-S outside of DOMAINBED shows a common problem with works in domain generalization, namely consistency in algorithm comparisons and reproducability. Due to computational constraints, novel methods are often only compared to the results provided in previous works. As a result, details such as the hyperparameter tuning procedure, learning rate schedules, or even the optimizer are often omitted or chosen to fit the algorithm at hand. From some of our experiments, we observe that simply fine-tuning a learning rate schedule for any of the methods from Table 5.2 offers a bigger performance increase than choosing a better algorithm in the first place. As such, design choices can have a heavy impact on how well the algorithm performs. Having a common benchmarking procedure such as DOMAINBED, where these are fixed, is necessary to make substantial progress in this field. We hope that we can push adoption in the community with our addition of RSC and the methods proposed in this work. However, not using learning rate schedules and following the pre-defined distributions for learning rates, batch sizes, or weight decays might inherently bias this comparison and shouldn't be neglected as a factor.

On top of that, Table 5.2 also shows the results for D-TRANSFORMERS. Generally, we observe that many variants of the prototype based approaches outlined in Section 3.2.3 fail to generalize well to ResNet-50, even though they exhibit promising performance on ResNet-18 (see Table 5.1 for PRo-DROP results on PACS and ResNet-18). This might be due to the fact that prototypical approaches commonly require higher resolution feature maps e.g. ${14} \times  {14}$ in [43] via dilated convolutions. Nevertheless, D-TRANSFORMERS already perform quite well for the benchmarking procedure outlined by DOMAINBED even without these additional changes. Keeping in mind that these adaptions can be made to push the performance even more, makes the approach even more suited for domain generalization although it is unclear how much the other algorithms would benefit from such a change. The value of prototypical approaches does not only lie in good performance but any prototypical approach can also offer a significant amount of explainability since these allow for visualizing the prototype similarity maps, the closest image patches to the prototypes, or even directly the prototypes if a sufficient decoder has jointly been trained. In particular, D-TRANSFORMERS is able to achieve Top-2 performance in DomAINBED for VLCS but performance seems to be not so good for the TerraIncog-nita dataset. We believe that this is because the dataset commonly includes only parts of the different animals at a very high distance, making it hard for the network to extract meaningful prototypes in the first place with the small feature resolution available. As such, it should be the hardest dataset for

<table><tr><td>Algorithm</td><td>$\mathbf{{Ref}.}$</td><td>VLCS</td><td>PACS</td><td>Office-Home</td><td>Terra Inc.</td><td>DomainNet</td><td>$\mathbf{{Avg}.}$</td></tr><tr><td>ERM</td><td>[187]</td><td>${77.5} \pm  {0.4}$</td><td>${85.5} \pm  {0.2}$</td><td>${66.5} \pm  {0.3}$</td><td>${46.1} \pm  {1.8}$</td><td>${40.9} \pm  {0.1}$</td><td>63.3</td></tr><tr><td>IRM</td><td>[9]</td><td>${78.5} \pm  {0.5}$</td><td>${83.5} \pm  {0.8}$</td><td>${64.3} \pm  {2.2}$</td><td>${47.6} \pm  {0.8}$</td><td>${33.9} \pm  {2.8}$</td><td>61.5</td></tr><tr><td>GroupDRO</td><td>[159]</td><td>${76.7} \pm  {0.6}$</td><td>${84.4} \pm  {0.8}$</td><td>${66.0} \pm  {0.7}$</td><td>${43.2} \pm  {1.1}$</td><td>${33.3} \pm  {0.2}$</td><td>60.7</td></tr><tr><td>Mixup</td><td>[203]</td><td>${77.4} \pm  {0.6}$</td><td>${84.6} \pm  {0.6}$</td><td>${68.1} \pm  {0.3}$</td><td>${47.9} \pm  {0.8}$</td><td>${39.2} \pm  {0.1}$</td><td>63.4</td></tr><tr><td>MLDG</td><td>[108]</td><td>${77.2} \pm  {0.4}$</td><td>${84.9} \pm  {1.0}$</td><td>${66.8} \pm  {0.6}$</td><td>${47.7} \pm  {0.9}$</td><td>${41.2} \pm  {0.1}$</td><td>63.5</td></tr><tr><td>CORAL</td><td>[179]</td><td>${78.8} \pm  {0.6}$</td><td>${86.2} \pm  {0.3}$</td><td>${68.7} \pm  {0.3}$</td><td>${47.6} \pm  {1.0}$</td><td>${41.5} \pm  {0.1}$</td><td>64.5</td></tr><tr><td>MMD</td><td>[112]</td><td>${77.5} \pm  {0.9}$</td><td>${84.6} \pm  {0.5}$</td><td>${66.3} \pm  {0.1}$</td><td>${42.2} \pm  {1.6}$</td><td>${23.4} \pm  {9.5}$</td><td>58.8</td></tr><tr><td>DANN</td><td>[61]</td><td>${78.6} \pm  {0.4}$</td><td>${83.6} \pm  {0.4}$</td><td>${65.9} \pm  {0.6}$</td><td>${46.7} \pm  {0.5}$</td><td>${38.3} \pm  {0.1}$</td><td>62.6</td></tr><tr><td>CDANN</td><td>[116]</td><td>${77.5} \pm  {0.1}$</td><td>${82.6} \pm  {0.9}$</td><td>${65.8} \pm  {1.3}$</td><td>${45.8} \pm  {1.6}$</td><td>${38.3} \pm  {0.3}$</td><td>62.0</td></tr><tr><td>MTL</td><td>[19]</td><td>${77.2} \pm  {0.4}$</td><td>${84.6} \pm  {0.5}$</td><td>${66.4} \pm  {0.5}$</td><td>${45.6} \pm  {1.2}$</td><td>${40.6} \pm  {0.1}$</td><td>62.8</td></tr><tr><td>SagNet</td><td>[135]</td><td>${77.8} \pm  {0.5}$</td><td>${86.3} \pm  {0.2}$</td><td>${68.1} \pm  {0.1}$</td><td>${48.6} \pm  {1.0}$</td><td>${40.3} \pm  {0.1}$</td><td>64.2</td></tr><tr><td>ARM</td><td>[212]</td><td>${77.6} \pm  {0.3}$</td><td>${85.1} \pm  {0.4}$</td><td>${64.8} \pm  {0.3}$</td><td>${45.5} \pm  {0.3}$</td><td>${35.5} \pm  {0.2}$</td><td>61.7</td></tr><tr><td>VREx</td><td>[101]</td><td>${78.3} \pm  {0.2}$</td><td>${84.9} \pm  {0.6}$</td><td>${66.4} \pm  {0.6}$</td><td>${46.4} \pm  {0.6}$</td><td>${33.6} \pm  {2.9}$</td><td>61.9</td></tr><tr><td>RSC</td><td>[86]</td><td>${77.1} \pm  {0.5}$</td><td>${85.2} \pm  {0.9}$</td><td>${65.5} \pm  {0.9}$</td><td>${46.6} \pm  {1.0}$</td><td>${38.9} \pm  {0.5}$</td><td>62.7</td></tr><tr><td>DivCAM-S</td><td>(ours)</td><td>${77.8} \pm  {0.3}$</td><td>${85.4} \pm  {0.2}$</td><td>${65.2} \pm  {0.3}$</td><td>${48.0} \pm  {1.2}$</td><td>${40.7} \pm  {0.0}$</td><td>63.4</td></tr><tr><td>D-TRANSFORMERS</td><td>(ours)</td><td>${78.7} \pm  {0.5}$</td><td>${84.2} \pm  {0.1}$</td><td>-</td><td>${42.9} \pm  {1.1}$</td><td>-</td><td>-</td></tr><tr><td>ERM*</td><td>[187]</td><td>${77.6} \pm  {0.3}$</td><td>${86.7} \pm  {0.3}$</td><td>${66.4} \pm  {0.5}$</td><td>${53.0} \pm  {0.3}$</td><td>${41.3} \pm  {0.1}$</td><td>65.0</td></tr><tr><td>IRM*</td><td>[9]</td><td>${76.9} \pm  {0.6}$</td><td>${84.5} \pm  {1.1}$</td><td>${63.0} \pm  {2.7}$</td><td>${50.5} \pm  {0.7}$</td><td>${28.0} \pm  {5.1}$</td><td>60.5</td></tr><tr><td>GroupDRO*</td><td>[159]</td><td>${77.4} \pm  {0.5}$</td><td>${87.1} \pm  {0.1}$</td><td>${66.2} \pm  {0.6}$</td><td>${52.4} \pm  {0.1}$</td><td>${33.4} \pm  {0.3}$</td><td>63.3</td></tr><tr><td>Mixup*</td><td>[203]</td><td>${78.1} \pm  {0.3}$</td><td>${86.8} \pm  {0.3}$</td><td>${68.0} \pm  {0.2}$</td><td>${54.4} \pm  {0.3}$</td><td>${39.6} \pm  {0.1}$</td><td>65.3</td></tr><tr><td>MLDG*</td><td>[108]</td><td>${77.5} \pm  {0.1}$</td><td>${86.8} \pm  {0.4}$</td><td>${66.6} \pm  {0.3}$</td><td>${52.0} \pm  {0.1}$</td><td>${41.6} \pm  {0.1}$</td><td>64.9</td></tr><tr><td>CORAL*</td><td>[179]</td><td>${77.7} \pm  {0.2}$</td><td>${87.1} \pm  {0.5}$</td><td>${68.4} \pm  {0.2}$</td><td>${52.8} \pm  {0.2}$</td><td>${41.8} \pm  {0.1}$</td><td>65.5</td></tr><tr><td>MMD*</td><td>[112]</td><td>${77.9} \pm  {0.1}$</td><td>${87.2} \pm  {0.1}$</td><td>${66.2} \pm  {0.3}$</td><td>${52.0} \pm  {0.4}$</td><td>${23.5} \pm  {9.4}$</td><td>61.3</td></tr><tr><td>DANN*</td><td>[61]</td><td>${79.7} \pm  {0.5}$</td><td>${85.2} \pm  {0.2}$</td><td>${65.3} \pm  {0.8}$</td><td>${50.6} \pm  {0.4}$</td><td>${38.3} \pm  {0.1}$</td><td>63.8</td></tr><tr><td>CDANN*</td><td>[116]</td><td>${79.9} \pm  {0.2}$</td><td>${85.8} \pm  {0.8}$</td><td>${65.3} \pm  {0.5}$</td><td>${50.8} \pm  {0.6}$</td><td>${38.5} \pm  {0.2}$</td><td>64.0</td></tr><tr><td>MTL*</td><td>[19]</td><td>${77.7} \pm  {0.5}$</td><td>${86.7} \pm  {0.2}$</td><td>${66.5} \pm  {0.4}$</td><td>${52.2} \pm  {0.4}$</td><td>${40.8} \pm  {0.1}$</td><td>64.7</td></tr><tr><td>SagNet*</td><td>[135]</td><td>${77.6} \pm  {0.1}$</td><td>${86.4} \pm  {0.4}$</td><td>${67.5} \pm  {0.2}$</td><td>${52.5} \pm  {0.4}$</td><td>${40.8} \pm  {0.2}$</td><td>64.9</td></tr><tr><td>ARM*</td><td>[212]</td><td>${77.8} \pm  {0.3}$</td><td>${85.8} \pm  {0.2}$</td><td>${64.8} \pm  {0.4}$</td><td>${51.2} \pm  {0.5}$</td><td>${36.0} \pm  {0.2}$</td><td>63.1</td></tr><tr><td>VREx*</td><td>[101]</td><td>${78.1} \pm  {0.2}$</td><td>${87.2} \pm  {0.6}$</td><td>${65.7} \pm  {0.3}$</td><td>${51.4} \pm  {0.5}$</td><td>${30.1} \pm  {3.7}$</td><td>62.5</td></tr><tr><td>RSC*</td><td>[86]</td><td>${77.8} \pm  {0.6}$</td><td>${86.2} \pm  {0.5}$</td><td>${66.5} \pm  {0.6}$</td><td>${52.1} \pm  {0.2}$</td><td>${38.9} \pm  {0.6}$</td><td>64.3</td></tr><tr><td>DivCAM-S*</td><td>(ours)</td><td>${78.1} \pm  {0.6}$</td><td>${87.2} \pm  {0.1}$</td><td>${65.2} \pm  {0.5}$</td><td>${51.3} \pm  {0.5}$</td><td>${41.0} \pm  {0.0}$</td><td>64.6</td></tr><tr><td>D-TRANSFORMERS*</td><td>(ours)</td><td>${77.7} \pm  {0.1}$</td><td>${86.9} \pm  {0.3}$</td><td>-</td><td>${52.4} \pm  {0.8}$</td><td>-</td><td>-</td></tr></table>

Table 5.2: Performance comparison across datasets using training-domain validation (top) and oracle validation denoted with * (bottom). We use a ResNet-50 backbone, optimize with ADAM, and follow the distributions specified in DOMAINBED. Only RSC and our methods have been added as part of this work, the other baselines are taken from DomAINBED.

D-TRANSFORMERS in DOMAINBED. In Table 5.2 the results for D-TRANSFORMERS on OfficeHome and DomainNet are omited due to computational constraints but we would expect the performances to be on-par if not better compared to the other methods, as these datasets do not share the same prototype extraction difficulties from TerraIncognita.

### 5.4 Ablation Studies

In this section, we are going to look at different ablations of the presented methods and how the individual components impact the performance. In particular, for DIVCAM-S, we analyze different methods of resetting the masks (mask batching) in Section 5.4.2 and see how additional methods that are supposed to improve the underlying class activation maps impact performance in Section 5.4.3. On top of that, for ProDrop, we evaluate the effect of self-challenging for different negative weights in Section 5.4.4, as well as the impact of the additional intra-loss factor in Section 5.4.5.

#### 5.4.1 Hyperparameter Distributions & Schedules

For the mask batching ablation study we use ADAM [98] and the distributions from Table 5.4. When the batch drop factor is scheduled, we use an increasing linear schedule while the learning rate is always scheduled with a step-decay which decays the learning rate by factor 0.1 at epoch 80/100 .

<table><tr><td>Algorithm</td><td>Ref.</td><td>Backbone</td><td>$\mathbf{P}$</td><td>A</td><td>C</td><td>S</td><td>Avg.</td></tr><tr><td>BASELINE</td><td>[28]</td><td>ResNet-18</td><td>95.73</td><td>77.85</td><td>74.86</td><td>67.74</td><td>79.05</td></tr><tr><td>MASF</td><td>[46]</td><td>ResNet-18</td><td>94.99</td><td>80.29</td><td>77.17</td><td>71.69</td><td>81.03</td></tr><tr><td>EPI-FCR</td><td>[110]</td><td>ResNet-18</td><td>93.90</td><td>82.10</td><td>77.00</td><td>73.00</td><td>81.50</td></tr><tr><td>JIGEN</td><td>[28]</td><td>ResNet-18</td><td>96.03</td><td>79.42</td><td>75.25</td><td>71.35</td><td>80.51</td></tr><tr><td>MetaReg</td><td>[15]</td><td>ResNet-18</td><td>95.50</td><td>83.70</td><td>77.20</td><td>70.30</td><td>81.70</td></tr><tr><td>RSC (reported)</td><td>[86]</td><td>ResNet-18</td><td>95.99</td><td>83.43</td><td>80.31</td><td>80.85</td><td>85.15</td></tr><tr><td>RSC (reproduced)</td><td>[86]</td><td>ResNet-18</td><td>93.73</td><td>80.41</td><td>77.53</td><td>80.79</td><td>83.12</td></tr><tr><td>DivCAM-S</td><td>(ours)</td><td>ResNet-18</td><td>96.11</td><td>80.27</td><td>77.82</td><td>82.18</td><td>84.10</td></tr></table>

Table 5.3: Performance comparison for PACS outside of the DOMAINBED framework with the official data split.

<table><tr><td/><td>Hyperparameter</td><td>Distribution</td></tr><tr><td>$\alpha$</td><td>learning rate</td><td>${\mathcal{{LU}}}_{10}\left( {-5, - 1}\right)$</td></tr><tr><td>$\mathcal{B}$</td><td>batch size</td><td>$\lfloor \mathcal{L}{U}_{2}\left( {3,9}\right) \rfloor$</td></tr><tr><td>$\gamma$</td><td>weight decay</td><td>${\mathcal{{LU}}}_{10}\left( {-6, - 2}\right)$</td></tr><tr><td>$p$</td><td>feature drop factor</td><td>1/3</td></tr><tr><td>$b$</td><td>batch drop factor</td><td>$\mathcal{U}\left( {0,1}\right)$</td></tr></table>

Table 5.4: Hyperparameters and distributions used in random search for the mask batching ablation study. $\mathcal{L}{\mathcal{U}}_{x}\left( {a, b}\right)$ denotes a log-uniform distribution between $a$ and $b$ for base $x$ , the uniform distribution is denoted as $\mathcal{U}\left( {a, b}\right)$ and $\lfloor  \cdot  \rfloor$ is the floor operator.

For the mask ablation study, we use ADAM [98] and the distributions from Table 5.5. When the batch drop factor is scheduled, we use an increasing linear schedule while the learning rate is not scheduled. This corresponds to the tuning distributions provided in DOMAINBED which are also used for all the main results and all other ablations. If not marked otherwise, each experiment evaluates 20 hyperparameter samples, similar to what is suggested in DOMAINBED.

#### 5.4.2 DivCAM: Mask Batching

There exist several methods how we can compute the vector $\mathbf{c}$ in our method and hence determine how we should apply the masks within each batch. Here, we analyze the effect on performance for a few possible choices. By default, DivCAM uses Equation (5.1) where ${y}_{gt}$ is the confidence on the ground truth class after softmax. This applies the masks on samples with the highest confidence on the correct class within each batch.

$$
{\mathbf{c}}^{n} = {y}_{gt} \tag{5.1}
$$

Another option is DIVCAM-C with Equation (5.2) which computes the change in confidence on the ground truth class when applying the mask. The masked confidence after softmax is denoted as ${\widetilde{y}}_{gt}$ . This variation applies the masks for samples where the mask decreases confidence on the ground truth class the most.

$$
{\mathbf{c}}^{n} = {y}_{gt} - {\widetilde{y}}_{gt} \tag{5.2}
$$

The last variation is DIVCAM-T where we apply the masks randomly for samples which are correctly classified. All variants can further be extended by adding a linear schedule, denoted with an additional "S", or computing $\mathbf{c}$ for each domain separately, denoted with an additional "D". By adding a schedule, we apply masks more in the later training epochs where discriminant features have been learned and by enforcing it for each domain we can ensure that the masks aren't applied biased towards a subset of domains and disregarded for others. Table 5.6 shows experiments for these variants.

<table><tr><td/><td>Hyperparameter</td><td>Distribution</td></tr><tr><td>$\alpha$</td><td>learning rate</td><td>${\mathcal{{LU}}}_{10}\left( {-5, - {3.5}}\right)$</td></tr><tr><td>$\mathcal{B}$</td><td>batch size</td><td>$\lfloor {\mathcal{{LU}}}_{2}\left( {3,{5.5}}\right) \rfloor$</td></tr><tr><td>$\gamma$</td><td>weight decay</td><td>${\mathcal{{LU}}}_{10}\left( {-6, - 2}\right)$</td></tr><tr><td>$p$</td><td>feature drop factor</td><td>$\mathcal{U}\left( {{0.2},{0.5}}\right)$</td></tr><tr><td>$b$</td><td>batch drop factor</td><td>$\mathcal{U}\left( {0,1}\right)$</td></tr><tr><td>${\lambda }_{1}$</td><td>hnc factor</td><td>${\mathcal{{LU}}}_{10}\left( {-3, - 1}\right)$</td></tr><tr><td>$k$</td><td>negative classes</td><td>num_classes -1</td></tr><tr><td>${\lambda }_{tap}$</td><td>tap factor</td><td>$\mathcal{U}\left( {0,1}\right)$</td></tr><tr><td>${\lambda }_{2}$</td><td>adversarial factor</td><td>${\mathcal{{LU}}}_{10}\left( {-2,2}\right)$</td></tr><tr><td>$S$</td><td>disc per gen step</td><td>$\lfloor \mathcal{L}{\mathcal{U}}_{2}\left( {0,3}\right) \rfloor$</td></tr><tr><td>$\eta$</td><td>gradient penalty</td><td>${\mathcal{{LU}}}_{10}\left( {-2,1}\right)$</td></tr><tr><td>${\omega }_{s}$</td><td>mlp width</td><td>512</td></tr><tr><td>${\omega }_{d}$</td><td>mlp depth</td><td>3</td></tr><tr><td>${\omega }_{dr}$</td><td>mlp dropout</td><td>0.5</td></tr><tr><td>${\lambda }_{3}$</td><td>mmd factor</td><td>$\mathcal{L}{\mathcal{U}}_{10}\left( {-1,1}\right)$</td></tr></table>

Table 5.5: Hyperparameters and distributions used in random search for the mask ablation study. $\mathcal{L}{\mathcal{U}}_{x}\left( {a, b}\right)$ denotes a log-uniform distribution between $a$ and $b$ for base $x$ , the uniform distribution is denoted as $\mathcal{U}\left( {a, b}\right) ,\lfloor  \cdot  \rfloor$ is the floor operator.

We observe that adding a schedule helps in most cases, achieving the highest training domain validation performance for DIvCAM-S. Enforcing the application of masks within each domain, however, doesn't consistently improve performance and therefore we don't consider it for the final method.

#### 5.4.3 DivCAM: Class Activation Maps

We combine our class activation maps with other methods from domain generalization, as well as methods to boost the explainability for class activation maps from the weakly-supervised object localization literature. The results are shown in Table 5.7 where MAP + CDANN drops the self-challenging part from DIVCAM and just computes ordinary cross entropy while aligning the class activation maps.

We observe that, surprisingly, none of the methods have a positive effect for training domain validation even though some of them exhibit better performance for oracle validation. Notably, especially the CDANN approach tends to exhibit a high standard deviation for some of the domains (e.g. art) which suggests that this approach can be fine-tuned when only reporting performance on a single seed. However, since we are looking for a method which reliably provides competitive results, regardless of the used seed and without needing extensive fine-tuning, we disregard this option.

#### 5.4.4 ProDrop: Self-Challenging

Table 5.8 shows the ablation results for the self-challenging addition. We observe that for most negative weights, adding self-challenging results in an performance increase. Most notably, this occurs for cases where the performance without self-challenging is very poor such as ${w}_{c, j} =  - {0.2}\forall j : {\mathbf{p}}_{j} \notin  {\mathcal{P}}_{c}$ , ${w}_{c, j} =  - {1.0}\forall j : {\mathbf{p}}_{j} \notin  {\mathcal{P}}_{c}$ , or ${w}_{c, j} = {0.0}\forall j : {\mathbf{p}}_{j} \notin  {\mathcal{P}}_{c}$ . Generally, in cases where it does not lead to a performance increase, the downside seems to be very small where we at most drop by 0.5% performance for ${w}_{c, j} =  - {0.5}\forall j : {\mathbf{p}}_{j} \notin  {\mathcal{P}}_{c}$ .

If we look at the performance changes solely based on the different negative weights, we can't observe any consistent trends. In fact, it is very surprising that small changes such as from ${w}_{c, j} =  - {0.1}$ to ${w}_{c, j} =  - {0.2}$ without self-challenging can lead to a $2\%$ performance change.

<table><tr><td>Name</td><td>P</td><td>A</td><td>C</td><td>S</td><td>$\mathbf{{Avg}.}$</td></tr><tr><td>DIVCAM</td><td>${94.0} \pm  {0.4}$</td><td>${80.6} \pm  {1.2}$</td><td>${75.4} \pm  {0.7}$</td><td>${76.7} \pm  {0.7}$</td><td>${81.7} \pm  {0.6}$</td></tr><tr><td>DivCAM-S</td><td>${94.4} \pm  {0.7}$</td><td>${80.5} \pm  {0.4}$</td><td>${74.6} \pm  {2.2}$</td><td>${79.0} \pm  {0.9}$</td><td>${82.1} \pm  {0.3}$</td></tr><tr><td>DivCAM-D</td><td>${94.3} \pm  {0.1}$</td><td>${80.1} \pm  {0.1}$</td><td>${74.5} \pm  {0.9}$</td><td>${76.6} \pm  {1.7}$</td><td>${81.4} \pm  {0.2}$</td></tr><tr><td>DIVCAM-DS</td><td>${93.9} \pm  {0.2}$</td><td>${80.4} \pm  {0.4}$</td><td>${73.4} \pm  {2.2}$</td><td>${74.8} \pm  {1.2}$</td><td>${80.6} \pm  {0.9}$</td></tr><tr><td>DivCAM-C</td><td>${92.6} \pm  {0.4}$</td><td>${80.1} \pm  {1.1}$</td><td>${73.6} \pm  {1.4}$</td><td>${75.0} \pm  {1.2}$</td><td>${80.3} \pm  {0.9}$</td></tr><tr><td>DIVCAM-CS</td><td>${95.0} \pm  {0.6}$</td><td>${79.9} \pm  {1.0}$</td><td>${74.5} \pm  {0.7}$</td><td>${78.1} \pm  {0.8}$</td><td>${81.9} \pm  {0.4}$</td></tr><tr><td>DivCAM-DC</td><td>${95.1} \pm  {0.4}$</td><td>${79.5} \pm  {1.0}$</td><td>${73.7} \pm  {0.9}$</td><td>${75.2} \pm  {1.2}$</td><td>${80.9} \pm  {0.4}$</td></tr><tr><td>DIVCAM-DCS</td><td>${93.5} \pm  {0.1}$</td><td>${80.1} \pm  {0.2}$</td><td>${75.1} \pm  {0.1}$</td><td>${77.2} \pm  {1.6}$</td><td>${81.5} \pm  {0.5}$</td></tr><tr><td>DIVCAM-T</td><td>${95.0} \pm  {0.3}$</td><td>${80.3} \pm  {0.3}$</td><td>${74.8} \pm  {0.8}$</td><td>${75.3} \pm  {1.1}$</td><td>${81.4} \pm  {0.4}$</td></tr><tr><td>DIVCAM-TS</td><td>${95.0} \pm  {0.1}$</td><td>${79.9} \pm  {0.8}$</td><td>${72.6} \pm  {1.3}$</td><td>${77.1} \pm  {1.4}$</td><td>${81.2} \pm  {0.4}$</td></tr><tr><td>DivCAM-DT</td><td>${94.8} \pm  {0.6}$</td><td>${79.6} \pm  {0.6}$</td><td>${74.0} \pm  {1.1}$</td><td>${78.5} \pm  {0.4}$</td><td>${81.7} \pm  {0.1}$</td></tr><tr><td>DIVCAM-DTS</td><td>${95.1} \pm  {0.2}$</td><td>${81.5} \pm  {1.3}$</td><td>${75.5} \pm  {0.4}$</td><td>${74.9} \pm  {2.0}$</td><td>${81.7} \pm  {0.5}$</td></tr><tr><td>DivCAM*</td><td>${94.9} \pm  {0.7}$</td><td>${81.5} \pm  {0.7}$</td><td>${76.6} \pm  {0.4}$</td><td>${80.5} \pm  {0.7}$</td><td>${83.4} \pm  {0.3}$</td></tr><tr><td>DIVCAM-S*</td><td>${94.9} \pm  {0.3}$</td><td>${82.7} \pm  {0.7}$</td><td>${76.3} \pm  {0.7}$</td><td>${80.1} \pm  {0.4}$</td><td>${83.5} \pm  {0.3}$</td></tr><tr><td>DIVCAM-D*</td><td>${94.8} \pm  {0.2}$</td><td>${81.0} \pm  {0.7}$</td><td>$\mathbf{{77.6} \pm  {0.6}}$</td><td>${79.9} \pm  {0.6}$</td><td>${83.3} \pm  {0.3}$</td></tr><tr><td>DIVCAM-DS*</td><td>${94.6} \pm  {0.5}$</td><td>${80.7} \pm  {0.3}$</td><td>${77.0} \pm  {0.4}$</td><td>${79.3} \pm  {0.3}$</td><td>${82.9} \pm  {0.1}$</td></tr><tr><td>DIVCAM-C*</td><td>${94.7} \pm  {0.5}$</td><td>${82.6} \pm  {0.6}$</td><td>${77.0} \pm  {0.5}$</td><td>${80.1} \pm  {1.0}$</td><td>$\mathbf{{83.6} \pm  {0.3}}$</td></tr><tr><td>DIVCAM-CS*</td><td>${94.2} \pm  {0.2}$</td><td>${82.5} \pm  {0.8}$</td><td>${76.9} \pm  {0.3}$</td><td>${79.9} \pm  {0.7}$</td><td>${83.4} \pm  {0.3}$</td></tr><tr><td>DIVCAM-DC*</td><td>${94.8} \pm  {0.4}$</td><td>${82.0} \pm  {0.4}$</td><td>${76.6} \pm  {0.9}$</td><td>${80.1} \pm  {0.4}$</td><td>${83.4} \pm  {0.1}$</td></tr><tr><td>DIVCAM-DCS*</td><td>${94.7} \pm  {0.4}$</td><td>${81.0} \pm  {0.3}$</td><td>${77.6} \pm  {0.2}$</td><td>${80.3} \pm  {1.3}$</td><td>${83.4} \pm  {0.3}$</td></tr><tr><td>DIVCAM-T*</td><td>${94.5} \pm  {0.4}$</td><td>${81.6} \pm  {0.8}$</td><td>${76.7} \pm  {0.2}$</td><td>${79.6} \pm  {0.4}$</td><td>${83.1} \pm  {0.4}$</td></tr><tr><td>DIVCAM-TS*</td><td>${94.8} \pm  {0.3}$</td><td>${81.3} \pm  {0.2}$</td><td>${76.7} \pm  {0.5}$</td><td>${79.7} \pm  {0.5}$</td><td>${83.2} \pm  {0.2}$</td></tr><tr><td>DIVCAM-DT*</td><td>${94.7} \pm  {0.5}$</td><td>${80.9} \pm  {1.1}$</td><td>${77.3} \pm  {0.5}$</td><td>${79.9} \pm  {0.6}$</td><td>${83.2} \pm  {0.2}$</td></tr><tr><td>DIVCAM-DTS*</td><td>${94.7} \pm  {0.5}$</td><td>${82.1} \pm  {1.0}$</td><td>${76.4} \pm  {0.6}$</td><td>${79.5} \pm  {1.2}$</td><td>${83.2} \pm  {0.1}$</td></tr></table>

Table 5.6: Ablation study for the DIVCAM mask batching on the PACS dataset using training-domain validation (top) and oracle validation denoted with * (bottom). We use a ResNet-18 backbone, schedules and distributions from Section 5.4.1, 25 hyperparameter samples, and 3 split seeds for standard deviations.

#### 5.4.5 ProDrop: Intra-Loss

Table 5.9 shows the ablation results for different intra factor strengths ${\lambda }_{6}$ with and without self-challenging. As expected, if the intra factor grows too large, performance degrades. For smaller values of ${\lambda }_{6}$ without self-challenging, we can observe a consistent performance increase of varying degrees similar to what self-challenging is able to gain.

Even though we experimented with different weighting of the individual distance metrics as well as the overall loss, we observe no consistent performance improvements on top of self-challenging across testing environments and data splits. The observations from Section 5.4.5, Figure 4.6, and Appendix B suggest that self-challenging inherently already enforces the desired properties up to the near-optimal extent such that the additional loss term does not provide any consistent further benefits.

<table><tr><td>Name</td><td>$\mathbf{P}$</td><td>A</td><td>C</td><td>S</td><td>Avg.</td></tr><tr><td>DIVCAM</td><td>${97.6} \pm  {0.4}$</td><td>${85.2} \pm  {0.8}$</td><td>${80.5} \pm  {0.7}$</td><td>${78.3} \pm  {0.8}$</td><td>${85.4} \pm  {0.5}$</td></tr><tr><td>DivCAM-S</td><td>${97.3} \pm  {0.4}$</td><td>${86.2} \pm  {1.4}$</td><td>${79.1} \pm  {2.2}$</td><td>${79.2} \pm  {0.1}$</td><td>${85.4} \pm  {0.2}$</td></tr><tr><td>DIVCAM-S + TAP</td><td>${96.9} \pm  {0.1}$</td><td>${85.1} \pm  {1.5}$</td><td>${78.7} \pm  {0.4}$</td><td>${75.3} \pm  {0.6}$</td><td>${84.0} \pm  {0.4}$</td></tr><tr><td>DivCAM-S + HNC</td><td>${97.2} \pm  {0.3}$</td><td>${87.2} \pm  {0.9}$</td><td>${79.2} \pm  {0.6}$</td><td>${71.7} \pm  {3.1}$</td><td>${83.8} \pm  {0.4}$</td></tr><tr><td>DivCAM-S + CDANN</td><td>${97.5} \pm  {0.4}$</td><td>${85.2} \pm  {2.8}$</td><td>${78.3} \pm  {2.0}$</td><td>${74.8} \pm  {0.9}$</td><td>${84.0} \pm  {1.5}$</td></tr><tr><td>DIVCAM-S + MMD</td><td>${97.0} \pm  {0.2}$</td><td>${85.4} \pm  {1.0}$</td><td>${81.5} \pm  {0.4}$</td><td>${75.8} \pm  {3.5}$</td><td>${84.9} \pm  {1.1}$</td></tr><tr><td>CAM + CDANN</td><td>${97.2} \pm  {0.3}$</td><td>${86.7} \pm  {0.5}$</td><td>${77.3} \pm  {1.7}$</td><td>${71.5} \pm  {1.3}$</td><td>${83.2} \pm  {0.8}$</td></tr><tr><td>DivCAM*</td><td>${96.2} \pm  {1.2}$</td><td>${87.0} \pm  {0.5}$</td><td>${82.0} \pm  {0.9}$</td><td>${80.8} \pm  {0.6}$</td><td>${86.5} \pm  {0.1}$</td></tr><tr><td>DIVCAM-S*</td><td>${97.2} \pm  {0.3}$</td><td>${86.5} \pm  {0.4}$</td><td>${83.0} \pm  {0.5}$</td><td>${82.2} \pm  {0.1}$</td><td>${87.2} \pm  {0.1}$</td></tr><tr><td>DIVCAM-S + TAP*</td><td>${97.3} \pm  {0.3}$</td><td>${87.2} \pm  {0.8}$</td><td>$\mathbf{{83.2} \pm  {0.8}}$</td><td>${82.8} \pm  {0.2}$</td><td>${87.6} \pm  {0.0}$</td></tr><tr><td>DIVCAM-S + HNC*</td><td>${97.3} \pm  {0.2}$</td><td>${87.4} \pm  {0.5}$</td><td>${81.4} \pm  {0.6}$</td><td>${79.7} \pm  {1.1}$</td><td>${86.5} \pm  {0.4}$</td></tr><tr><td>DIVCAM-S + CDANN*</td><td>${97.3} \pm  {0.5}$</td><td>${85.9} \pm  {1.2}$</td><td>${80.6} \pm  {0.4}$</td><td>${80.9} \pm  {0.4}$</td><td>${86.2} \pm  {0.2}$</td></tr><tr><td>DivCAM-S + MMD*</td><td>${97.3} \pm  {0.5}$</td><td>${86.8} \pm  {0.7}$</td><td>${83.2} \pm  {0.4}$</td><td>${80.9} \pm  {0.7}$</td><td>${87.1} \pm  {0.4}$</td></tr><tr><td>CAM + CDANN*</td><td>${97.2} \pm  {0.4}$</td><td>${86.7} \pm  {0.5}$</td><td>${81.9} \pm  {0.2}$</td><td>${80.6} \pm  {0.7}$</td><td>${86.6} \pm  {0.2}$</td></tr></table>

Table 5.7: Ablation study for the DIVCAM masks on the PACS dataset using training-domain validation (top) and oracle validation denoted with * (bottom). We use a ResNet-50 backbone, schedules and distributions from Section 5.4.1, 20 hyperparameter samples, and 3 split seeds for standard deviations. Results are directly integratable in Table 5.2 as we use the same tuning protocol provided in DomainBED.

<table><tr><td>Weight</td><td>SC</td><td>P</td><td>A</td><td>C</td><td>S</td><td>Avg.</td></tr><tr><td>0.0</td><td>✘</td><td>${93.2} \pm  {0.0}$</td><td>${80.4} \pm  {1.0}$</td><td>${73.7} \pm  {0.4}$</td><td>${72.6} \pm  {2.6}$</td><td>${80.0} \pm  {0.7}$</td></tr><tr><td>-0.1</td><td>✘</td><td>${94.3} \pm  {0.3}$</td><td>${78.8} \pm  {0.3}$</td><td>${74.4} \pm  {0.7}$</td><td>${75.3} \pm  {1.6}$</td><td>${80.7} \pm  {0.4}$</td></tr><tr><td>-0.2</td><td>✘</td><td>${93.2} \pm  {0.5}$</td><td>${76.8} \pm  {1.5}$</td><td>${72.9} \pm  {0.1}$</td><td>${71.8} \pm  {1.0}$</td><td>${78.7} \pm  {0.5}$</td></tr><tr><td>-0.3</td><td>✘</td><td>${94.0} \pm  {0.4}$</td><td>${79.8} \pm  {1.0}$</td><td>${75.6} \pm  {1.5}$</td><td>${73.9} \pm  {1.0}$</td><td>${80.8} \pm  {0.1}$</td></tr><tr><td>-0.4</td><td>✘</td><td>${93.6} \pm  {0.1}$</td><td>${79.8} \pm  {0.5}$</td><td>${74.3} \pm  {1.3}$</td><td>${75.7} \pm  {2.3}$</td><td>${80.8} \pm  {0.5}$</td></tr><tr><td>-0.5</td><td>✘</td><td>${93.0} \pm  {0.9}$</td><td>${79.4} \pm  {1.6}$</td><td>${73.2} \pm  {0.9}$</td><td>${75.5} \pm  {1.0}$</td><td>${80.3} \pm  {0.4}$</td></tr><tr><td>-1.0</td><td>✘</td><td>${94.2} \pm  {0.4}$</td><td>${80.2} \pm  {1.1}$</td><td>${72.7} \pm  {1.4}$</td><td>${68.6} \pm  {0.6}$</td><td>${78.9} \pm  {0.2}$</td></tr><tr><td>-2.0</td><td>✘</td><td>${94.7} \pm  {0.4}$</td><td>${78.7} \pm  {0.5}$</td><td>${75.5} \pm  {1.0}$</td><td>${71.1} \pm  {2.2}$</td><td>${80.0} \pm  {0.7}$</td></tr><tr><td>${0.0} \rightarrow   - {1.0}$</td><td>✘</td><td>${94.3} \pm  {0.5}$</td><td>${79.5} \pm  {0.6}$</td><td>${74.2} \pm  {0.3}$</td><td>${72.2} \pm  {2.1}$</td><td>${80.0} \pm  {0.4}$</td></tr><tr><td>0.0</td><td>✓</td><td>${93.4} \pm  {0.6}$</td><td>${80.5} \pm  {0.8}$</td><td>${75.6} \pm  {0.1}$</td><td>${74.3} \pm  {2.0}$</td><td>${81.0} \pm  {0.4}$</td></tr><tr><td>-0.1</td><td>✓</td><td>${93.7} \pm  {0.3}$</td><td>${83.2} \pm  {1.4}$</td><td>${75.9} \pm  {1.2}$</td><td>${71.1} \pm  {1.9}$</td><td>${81.0} \pm  {0.8}$</td></tr><tr><td>-0.2</td><td>✓</td><td>${93.2} \pm  {0.2}$</td><td>${81.0} \pm  {0.7}$</td><td>${73.9} \pm  {0.7}$</td><td>${75.0} \pm  {0.6}$</td><td>${80.8} \pm  {0.1}$</td></tr><tr><td>-0.3</td><td>✓</td><td>${93.4} \pm  {0.8}$</td><td>${81.4} \pm  {0.4}$</td><td>${71.3} \pm  {1.2}$</td><td>${76.9} \pm  {0.9}$</td><td>${80.7} \pm  {0.2}$</td></tr><tr><td>-0.4</td><td>✓</td><td>${94.0} \pm  {0.3}$</td><td>${81.7} \pm  {0.9}$</td><td>${72.9} \pm  {0.4}$</td><td>${73.5} \pm  {1.0}$</td><td>${80.5} \pm  {0.2}$</td></tr><tr><td>-0.5</td><td>✓</td><td>${93.5} \pm  {0.7}$</td><td>${80.7} \pm  {1.6}$</td><td>${71.6} \pm  {1.4}$</td><td>${73.6} \pm  {1.5}$</td><td>${79.8} \pm  {0.9}$</td></tr><tr><td>-1.0</td><td>✓</td><td>${94.6} \pm  {0.2}$</td><td>${81.6} \pm  {1.2}$</td><td>${72.9} \pm  {0.4}$</td><td>${77.0} \pm  {1.6}$</td><td>${81.5} \pm  {0.2}$</td></tr><tr><td>-2.0</td><td>✓</td><td>${94.0} \pm  {0.5}$</td><td>${79.5} \pm  {1.2}$</td><td>${76.4} \pm  {0.4}$</td><td>${73.9} \pm  {1.7}$</td><td>${80.9} \pm  {0.6}$</td></tr><tr><td>${0.0} \rightarrow   - {1.0}$</td><td>✓</td><td>${94.1} \pm  {0.4}$</td><td>${79.2} \pm  {0.6}$</td><td>${74.1} \pm  {1.1}$</td><td>${71.9} \pm  {0.2}$</td><td>${79.8} \pm  {0.3}$</td></tr></table>

Table 5.8: Performance comparison for different negative class weights on the PACS dataset without (top) and with self-challenging (bottom) using training-domain validation and a ResNet-18 backbone. The feature and batch drop factors are kept constant with $p = {0.5}$ and $b = \frac{1}{3}$ , a linear schedule from $a$ to $b$ throughout training is denoted with $a \rightarrow  b$ .

<table><tr><td>Intra factor ${\lambda }_{6}$</td><td>SC</td><td>$\mathbf{P}$</td><td>A</td><td>C</td><td>S</td><td>$\mathbf{{Avg}.}$</td></tr><tr><td>0.0</td><td>✘</td><td>${94.2} \pm  {0.4}$</td><td>${80.2} \pm  {1.1}$</td><td>${72.7} \pm  {1.4}$</td><td>${68.6} \pm  {0.6}$</td><td>${78.9} \pm  {0.2}$</td></tr><tr><td>-0.1</td><td>✘</td><td>${94.1} \pm  {0.4}$</td><td>${81.2} \pm  {1.2}$</td><td>${73.6} \pm  {0.8}$</td><td>${75.2} \pm  {2.4}$</td><td>${81.0} \pm  {0.6}$</td></tr><tr><td>-0.2</td><td>✘</td><td>${94.5} \pm  {0.4}$</td><td>${81.5} \pm  {1.1}$</td><td>${74.4} \pm  {1.6}$</td><td>${74.4} \pm  {1.1}$</td><td>${81.2} \pm  {0.5}$</td></tr><tr><td>-0.5</td><td>✘</td><td>${92.9} \pm  {0.8}$</td><td>${82.4} \pm  {0.4}$</td><td>${73.5} \pm  {1.6}$</td><td>${73.4} \pm  {2.0}$</td><td>${80.6} \pm  {0.7}$</td></tr><tr><td>-1.0</td><td>✘</td><td>${94.7} \pm  {0.4}$</td><td>${80.4} \pm  {0.6}$</td><td>${73.9} \pm  {0.9}$</td><td>${75.2} \pm  {1.8}$</td><td>${81.1} \pm  {0.7}$</td></tr><tr><td>0.0</td><td>✓</td><td>${94.6} \pm  {0.2}$</td><td>${81.6} \pm  {1.2}$</td><td>${72.9} \pm  {0.4}$</td><td>${77.0} \pm  {1.6}$</td><td>${81.5} \pm  {0.2}$</td></tr><tr><td>-0.1</td><td>✓</td><td>${94.6} \pm  {0.3}$</td><td>${82.6} \pm  {0.9}$</td><td>${72.2} \pm  {0.5}$</td><td>${75.4} \pm  {0.1}$</td><td>${81.2} \pm  {0.3}$</td></tr><tr><td>-0.2</td><td>✓</td><td>${94.1} \pm  {0.1}$</td><td>${81.9} \pm  {0.2}$</td><td>${73.3} \pm  {0.7}$</td><td>${75.8} \pm  {0.9}$</td><td>${81.2} \pm  {0.1}$</td></tr><tr><td>-0.3</td><td>✓</td><td>${94.8} \pm  {0.2}$</td><td>${81.5} \pm  {0.1}$</td><td>${75.1} \pm  {0.0}$</td><td>${74.5} \pm  {0.4}$</td><td>${81.5} \pm  {0.2}$</td></tr><tr><td>-0.4</td><td>✓</td><td>${93.9} \pm  {0.5}$</td><td>${82.4} \pm  {0.2}$</td><td>${74.3} \pm  {1.3}$</td><td>${76.1} \pm  {1.1}$</td><td>${81.7} \pm  {0.2}$</td></tr><tr><td>-0.5</td><td>✓</td><td>${93.6} \pm  {0.6}$</td><td>${82.1} \pm  {0.9}$</td><td>${76.4} \pm  {0.9}$</td><td>${76.3} \pm  {0.6}$</td><td>${82.1} \pm  {0.6}$</td></tr><tr><td>-0.6</td><td>✓</td><td>${93.8} \pm  {0.6}$</td><td>${82.1} \pm  {0.3}$</td><td>${75.7} \pm  {0.2}$</td><td>${73.1} \pm  {3.1}$</td><td>${81.2} \pm  {1.0}$</td></tr><tr><td>-0.7</td><td>✓</td><td>${94.0} \pm  {0.4}$</td><td>${82.9} \pm  {1.2}$</td><td>${74.1} \pm  {0.5}$</td><td>${76.3} \pm  {1.0}$</td><td>${81.8} \pm  {0.4}$</td></tr><tr><td>-0.8</td><td>✓</td><td>${94.1} \pm  {0.5}$</td><td>${81.8} \pm  {0.3}$</td><td>${75.5} \pm  {0.2}$</td><td>${72.7} \pm  {0.3}$</td><td>${81.0} \pm  {0.1}$</td></tr><tr><td>-1.0</td><td>✓</td><td>${95.1} \pm  {0.6}$</td><td>${80.7} \pm  {1.5}$</td><td>${74.5} \pm  {1.1}$</td><td>${73.7} \pm  {1.2}$</td><td>${81.0} \pm  {0.4}$</td></tr><tr><td>-2.0</td><td>✓</td><td>${94.3} \pm  {0.3}$</td><td>${82.9} \pm  {0.5}$</td><td>${75.1} \pm  {1.0}$</td><td>${75.0} \pm  {1.1}$</td><td>${81.8} \pm  {0.5}$</td></tr><tr><td>-3.0</td><td>✓</td><td>${94.5} \pm  {0.3}$</td><td>${79.8} \pm  {1.0}$</td><td>${74.9} \pm  {1.0}$</td><td>${71.2} \pm  {0.4}$</td><td>${80.1} \pm  {0.3}$</td></tr><tr><td>-10.0</td><td>✓</td><td>${90.8} \pm  {3.7}$</td><td>${80.2} \pm  {0.3}$</td><td>${72.9} \pm  {0.1}$</td><td>${75.0} \pm  {1.8}$</td><td>${79.7} \pm  {0.6}$</td></tr><tr><td>-100.0</td><td>✓</td><td>${72.0} \pm  {11}$ .</td><td>${76.3} \pm  {2.2}$</td><td>${73.0} \pm  {1.1}$</td><td>${69.1} \pm  {2.6}$</td><td>${72.6} \pm  {4.0}$</td></tr></table>

Table 5.9: Performance comparison for different intra factors on the PACS dataset without (top) and with self-challenging (bottom) using training-domain validation and a ResNet-18 backbone. The feature and batch drop factors are kept constant with $p = {0.5}$ and $b = \frac{1}{3}$ , negative weight is-1.0. Distance metrics are weighted with ${\lambda }_{{\ell }_{2}} = 1$ and ${\lambda }_{\varrho } = 1$ .

## Conclusion and Outlook

In this work, we investigated if we can deploy explainability methods during the training procedure and gain, both, better performance on the domain generalization task as well as a framework that enables more explainability for the users. In particular, we develop a regularization technique based on class activation maps that visualize parts of an image responsible for certain predictions (DivCAM) as well as prototypical representations that serve as a number of class or attribute centroids which the network uses to make its predictions (ProDROP and D-TRANSFORMERS).

From the results and ablations presented in this work, we have shown that especially DivCAM is a reliable method for achieving domain generalization for small to medium sized ResNet backbones while offering an architecture that allows for additional insights into how and why the network arrives at it's predictions. Depending on the backbone and dataset, ProDrop and D-TRANSFORMERS can also be powerful options for this cause. The possibilities for explainability in these methods is a property that is highly desirable in practice, especially for safety-critical scenarios such as self-driving cars, any application in the medical field e.g. cancer or tumor prediction, or any other automation robot that needs to operate in a diverse set of environments. We hope that the presented methods can find application in such scenarios and establish additional trust and confidence into the machine learning systems to work reliable.

Building upon the methods presented in this work, there are also quite a number of ablations or extension points that might be interesting to investigate. First, even though the results for ProDROP looked very promising on ResNet-18, it failed to generalize well enough to ResNet-50 to properly compete with the other methods in DomAINBED. Looking into some of the details coming from this transition, might yield a better understanding of what causes this problem and a solution can probably be found. Secondly, even though the explainability methods we build upon have very deep roots in the explainability literature, it would be interesting to either jointly train a suitable decoder for the prototypes or visualize the closest latent patch across the whole dataset. Since we're training with images coming from different domains, there could be interesting visualizations possible, potentially also in a video format that shows the change throughout training. In this work, we especially focused on achieving good performance with these methods rather than the explainability itself. Thirdly, many prototypical networks upscale the feature map in size, for example to ${14} \times  {14}$ from $7 \times  7$ , and report great performance gains coming from the increased spatial resolution of the latent representation [43]. We deliberately refrain from changing the backbone in such a way to improve comparability in the DOMAINBED framework without needing to re-compute the extensive set of baselines, although it might be possible that both ProDrop and D-TRANSFORMERS benefit more heavily from such a change compared to other methods. In a similar fashion, many prototypical networks use the euclidean distance as a distance measure while some works report better performance for the dot or cosine similarity [201]. We experimented with a few options across the different methods but a clear ablation study of this detail for the domain generalization task would be very helpful. In particular, one can also think about deploying any other Bregman divergence measure and taking a metric learning approach with, for example, the Mahalanobis distance [16] that might be able to achieve additional performance gains.

Finally, especially for D-TRANSFORMERS, our method of aggregating across multiple environments is very simple in nature and finding a more elaborate way to utilize the multiple aligned prototypes for each environment might be a great opportunity for a follow-up work. Nevertheless, we hope that our analysis might serve as a first stepping stone and groundwork for developing more domain generalization algorithms based on explainability methods.

## Bibliography

[1] A. Agarwal, A. Beygelzimer, M. Dudík, J. Langford, and H. M. Wallach. "A Reductions Approach to Fair Classification". In: International Conference on Machine Learning, ICML. 2018.

[2] K. Akuzawa, Y. Iwasawa, and Y. Matsuo. "Adversarial Invariant Feature Learning with Accuracy Constraint for Domain Generalization". In: European Conference on Machine Learning and Knowledge Discovery in Databases, ECML PKDD. 2019.

[3] G. Alain and Y. Bengio. "Understanding intermediate layers using linear classifier probes". In: International Conference on Learning Representations, ICLR. 2017.

[4] E. A. AlBadawy, A. Saha, and M. A. Mazurowski. "Deep learning for segmentation of brain tumors: Impact of cross-institutional training and testing". In: Medical Physics 45.3 (2018), pp. 1150-1158.

[5] I. Albuquerque, J. Monteiro, M. Darvishi, T. H. Falk, and I. Mitliagkas. Generalizing to unseen domains via distribution matching. 2019. arXiv: 1911.00804 [cs.LG].

[6] D. Alvarez-Melis and T. S. Jaakkola. "Towards Robust Interpretability with Self-Explaining Neural Networks". In: Advances in Neural Information Processing Systems, NeurIPS. 2018.

[7] S. Amershi, M. Chickering, S. Drucker, B. Lee, P. Simard, and J. Suh. "ModelTracker: Redesigning Performance Analysis Tools for Machine Learning". In: Conference on Human Factors in Computing Systems, CHI. 2015.

[8] S. Anwar and N. Barnes. "Real Image Denoising With Feature Attention". In: International Conference on Computer Vision, ICCV. 2019.

[9] M. Arjovsky, L. Bottou, I. Gulrajani, and D. Lopez-Paz. Invariant Risk Minimization. 2019. arXiv: 1907.02893 [stat.ML].

[10] N. Asadi, A. M. Sarfi, M. Hosseinzadeh, Z. Karimpour, and M. Eftekhari. Towards Shape Biased Unsupervised Representation Learning for Domain Generalization. 2019. arXiv: 1909.08245 [cs.CV].

[11] S. Bach, A. Binder, G. Montavon, F. Klauschen, K.-R. Müller, and W. Samek. "On Pixel-Wise Explanations for Non-Linear Classifier Decisions by Layer-Wise Relevance Propagation". In: PLOS ONE 10.7 (2015), e0130140.

[12] W. Bae, J. Noh, and G. Kim. "Rethinking Class Activation Mapping for Weakly Supervised Object Localization". In: European Conference on Computer Vision, ECCV. 2020.

[13] D. Bahdanau, K. Cho, and Y. Bengio. "Neural Machine Translation by Jointly Learning to Align and Translate". In: International Conference on Learning Representations, ICLR. 2015.

[14] M. Baktashmotlagh, M. T. Harandi, B. C. Lovell, and M. Salzmann. "Unsupervised Domain Adaptation by Domain Invariant Projection". In: International Conference on Computer Vision, ICCV. 2013.

[15] Y. Balaji, S. Sankaranarayanan, and R. Chellappa. "MetaReg: Towards Domain Generalization using Meta-Regularization". In: Advances in Neural Information Processing Systems, NeurIPS. 2018.

[16] A. Banerjee, S. Merugu, I. S. Dhillon, and J. Ghosh. "Clustering with Bregman Divergences". In: International Conference on Data Mining, SDM. 2004.

[17] S. Beery, G. V. Horn, and P. Perona. "Recognition in Terra Incognita". In: European Conference on Computer Vision, ECCV. 2018.

[18] J. Bien and R. Tibshirani. "Prototype selection for interpretable classification". In: The Annals of Applied Statistics 5.4 (2011), pp. 2403-2424.

[19] G. Blanchard, A. A. Deshmukh, U. Dogan, G. Lee, and C. Scott. Domain Generalization by Marginal Transfer Learning. 2017. arXiv: 1711.07910 [stat.ML].

[20] G. Blanchard, G. Lee, and C. Scott. "Generalizing from Several Related Classification Tasks to a New Unlabeled Sample". In: Advances in Neural Information Processing Systems, NIPS. 2011.

[21] K. Bousmalis, N. Silberman, D. Dohan, D. Erhan, and D. Krishnan. "Unsupervised Pixel-Level Domain Adaptation with Generative Adversarial Networks". In: Conference on Computer Vision and Pattern Recognition, CVPR. 2017.

[22] K. Bousmalis, G. Trigeorgis, N. Silberman, D. Krishnan, and D. Erhan. "Domain Separation Networks". In: Advances in Neural Information Processing Systems, NIPS. 2016.

[23] T. B. Brown, B. Mann, N. Ryder, M. Subbiah, J. Kaplan, P. Dhariwal, A. Neelakantan, P. Shyam, G. Sastry, A. Askell, S. Agarwal, A. Herbert-Voss, G. Krueger, T. Henighan, R. Child, A. Ramesh, D. M. Ziegler, J. Wu, C. Winter, C. Hesse, M. Chen, E. Sigler, M. Litwin, S. Gray, B. Chess, J. Clark, C. Berner, S. McCandlish, A. Radford, I. Sutskever, and D. Amodei. "Language Models are Few-Shot Learners". In: Advances in Neural Information Processing Systems, NeurIPS. 2020.

[24] X. Cai, J. Shang, Z. Jin, F. Liu, B. Qiang, W. Xie, and L. Zhao. "DBGE: Employee Turnover Prediction Based on Dynamic Bipartite Graph Embedding". In: IEEE Access 8 (2020), pp. 10390- 10402.

[25] T. Calders, F. Kamiran, and M. Pechenizkiy. "Building Classifiers with Independency Constraints". In: International Conference on Data Mining, ICDM. 2009.

[26] O. Camburu, T. Rocktäschel, T. Lukasiewicz, and P. Blunsom. "e-SNLI: Natural Language Inference with Natural Language Explanations". In: Advances in Neural Information Processing Systems, NeurIPS. 2018.

[27] O. Camburu, B. Shillingford, P. Minervini, T. Lukasiewicz, and P. Blunsom. "Make Up Your Mind! Adversarial Generation of Inconsistent Natural Language Explanations". In: Annual Meeting of the Association for Computational Linguistics, ACL. 2020.

[28] F. M. Carlucci, A. D'Innocente, S. Bucci, B. Caputo, and T. Tommasi. "Domain Generalization by Solving Jigsaw Puzzles". In: Conference on Computer Vision and Pattern Recognition, CVPR. 2019.

[29] F. M. Carlucci, L. Porzi, B. Caputo, E. Ricci, and S. R. Bulò. "AutoDIAL: Automatic Domain Alignment Layers". In: International Conference on Computer Vision, ICCV. 2017.

[30] R. Caruana, S. Lawrence, and C. L. Giles. "Overfitting in Neural Nets: Backpropagation, Conjugate Gradient, and Early Stopping". In: Advances in Neural Information Processing Systems, NIPS. 2000.

[31] D. C. Castro, I. Walker, and B. Glocker. "Causality matters in medical imaging". In: Nature Communications 11.1 (2020).

[32] C. Chen, O. Li, D. Tao, A. Barnett, C. Rudin, and J. Su. "This Looks Like That: Deep Learning for Interpretable Image Recognition". In: Advances in Neural Information Processing Systems, NeurIPS. 2019.

[33] M. J. Choi, J. J. Lim, A. Torralba, and A. S. Willsky. "Exploiting hierarchical context on a large database of object categories". In: Conference on Computer Vision and Pattern Recognition, CVPR. 2010.

[34] G. Csurka. "A Comprehensive Survey on Domain Adaptation for Visual Applications". In: Domain Adaptation in Computer Vision Applications. 2017.

[35] A. D'Innocente and B. Caputo. "Domain Generalization with Domain-Specific Aggregation Modules". In: German Conference on Pattern Recognition, GCPR. 2018.

[36] D. Dai and L. V. Gool. "Dark Model Adaptation: Semantic Image Segmentation from Daytime to Nighttime". In: International Conference on Intelligent Transportation Systems, ITSC. 2018.

[37] Z. Deng, F. Ding, C. Dwork, R. Hong, G. Parmigiani, P. Patil, and P. Sur. Representation via Representations: Domain Generalization via Adversarially Learned Invariant Representations. 2020. arXiv: 2006.11478 [cs.LG].

[38] A. A. Deshmukh, Y. Lei, S. Sharma, U. Dogan, J. W. Cutler, and C. Scott. A Generalization Error Bound for Multi-class Domain Generalization. 2019. arXiv: 1905.10392 [stat.ML].

[39] J. Devlin, M. Chang, K. Lee, and K. Toutanova. "BERT: Pre-training of Deep Bidirectional Transformers for Language Understanding". In: Conference of the North American Chapter of the Association for Computational Linguistics: Human Language Technologies, NAACL-HLT. 2019.

[40] T. DeVries and G. W. Taylor. Improved Regularization of Convolutional Neural Networks with Cutout. 2017. arXiv: 1708.04552 [cs.CV].

[41] Y. Ding, Y. Liu, H. Luan, and M. Sun. "Visualizing and Understanding Neural Machine Translation". In: Annual Meeting of the Association for Computational Linguistics, ACL. 2017.

[42] Z. Ding and Y. Fu. "Deep Domain Generalization With Structured Low-Rank Constraint". In: IEEE Transactions on Image Processing 27.1 (2018), pp. 304-313.

[43] C. Doersch, A. Gupta, and A. Zisserman. "CrossTransformers: spatially-aware few-shot transfer". In: Advances in Neural Information Processing Systems, NeurIPS. 2020.

[44] Y. Dong, H. Su, J. Zhu, and B. Zhang. "Improving Interpretability of Deep Neural Networks with Semantic Information". In: Conference on Computer Vision and Pattern Recognition, CVPR. 2017.

[45] M. Donini, L. Oneto, S. Ben-David, J. Shawe-Taylor, and M. Pontil. "Empirical Risk Minimization Under Fairness Constraints". In: Advances in Neural Information Processing Systems, NeurIPS. 2018.

[46] Q. Dou, D. C. de Castro, K. Kamnitsas, and B. Glocker. "Domain Generalization via Model-Agnostic Learning of Semantic Features". In: Advances in Neural Information Processing Systems, NeurIPS. 2019.

[47] C. Dwork, M. Hardt, T. Pitassi, O. Reingold, and R. S. Zemel. "Fairness through awareness". In: Innovations in Theoretical Computer Science, ITCS. 2012.

[48] C. Dwork, N. Immorlica, A. T. Kalai, and M. D. M. Leiserson. "Decoupled Classifiers for Group-Fair and Efficient Machine Learning". In: Conference on Fairness, Accountability and Transparency, FAT. 2018.

[49] M. Eitz, J. Hays, and M. Alexa. "How do humans sketch objects?" In: Transactions on Graphics, TOG 31.4 (2012), 44:1-44:10.

[50] E. R. Elenberg, A. G. Dimakis, M. Feldman, and A. Karbasi. "Streaming Weak Submodularity: Interpreting Neural Networks on the Fly". In: Advances in Neural Information Processing Systems, NIPS. 2017.

[51] M. Everingham, L. V. Gool, C. K. I. Williams, J. M. Winn, and A. Zisserman. "The Pascal Visual Object Classes (VOC) Challenge". In: International Journal of Computer Vision, IJCV 88.2 (2010), pp. 303-338.

[52] C. Fang, Y. Xu, and D. N. Rockmore. "Unbiased Metric Learning: On the Utilization of Multiple Datasets and Web Images for Softening Bias". In: International Conference on Computer Vision, ICCV. 2013.

[53] M. Feldman, S. A. Friedler, J. Moeller, C. Scheidegger, and S. Venkatasubramanian. "Certifying and Removing Disparate Impact". In: International Conference on Knowledge Discovery and Data Mining, SIGKDD. 2015.

[54] B. Fernando, A. Habrard, M. Sebban, and T. Tuytelaars. "Unsupervised Visual Domain Adaptation Using Subspace Alignment". In: International Conference on Computer Vision, ICCV. 2013.

[55] S. Fidler, S. J. Dickinson, and R. Urtasun. "3D Object Detection and Viewpoint Estimation with a Deformable 3D Cuboid Model". In: Advances in Neural Information Processing Systems, NIPS. 2012.

[56] C. Finn, P. Abbeel, and S. Levine. "Model-Agnostic Meta-Learning for Fast Adaptation of Deep Networks". In: International Conference on Machine Learning, ICML. 2017.

[57] R. C. Fong and A. Vedaldi. "Interpretable Explanations of Black Boxes by Meaningful Perturbation". In: International Conference on Computer Vision, ICCV. 2017.

[58] N. Frosst and G. E. Hinton. "Distilling a Neural Network Into a Soft Decision Tree". In: International Workshop on Comprehensibility and Explanation in AI and ML, CEX. 2017.

[59] F. B. Fuchs, O. Groth, A. R. Kosiorek, A. Bewley, M. Wulfmeier, A. Vedaldi, and I. Posner. "Scrutinizing and De-Biasing Intuitive Physics with Neural Stethoscopes". In: British Machine Vision Conference, BMVC. 2019.

[60] Y. Ganin and V. S. Lempitsky. "Unsupervised Domain Adaptation by Backpropagation". In: International Conference on Machine Learning, ICML. 2015.

[61] Y. Ganin, E. Ustinova, H. Ajakan, P. Germain, H. Larochelle, F. Laviolette, M. Marchand, and V. S. Lempitsky. "Domain-Adversarial Training of Neural Networks". In: Journal of Machine Learning Research, JMLR 17 (2016), 59:1-59:35.

[62] R. Geirhos, P. Rubisch, C. Michaelis, M. Bethge, F. A. Wichmann, and W. Brendel. "ImageNet-trained CNNs are biased towards texture; increasing shape bias improves accuracy and robustness". In: International Conference on Learning Representations, ICLR. 2019.

[63] M. Gharib, P. Lollini, M. Botta, E. G. Amparore, S. Donatelli, and A. Bondavalli. "On the Safety of Automotive Systems Incorporating Machine Learning Based Components: A Position Paper". In: International Conference on Dependable Systems and Networks, DSN. 2018.

[64] G. Ghiasi, T. Lin, and Q. V. Le. "DropBlock: A regularization method for convolutional networks". In: Advances in Neural Information Processing Systems, NeurIPS. 2018.

[65] M. Ghifary, D. Balduzzi, W. B. Kleijn, and M. Zhang. "Scatter Component Analysis: A Unified Framework for Domain Adaptation and Domain Generalization". In: Transactions on Pattern Analysis and Machine Intelligence, PAMI 39.7 (2017), pp. 1414-1430.

[66] M. Ghifary, W. B. Kleijn, M. Zhang, and D. Balduzzi. "Domain Generalization for Object Recognition with Multi-task Autoencoders". In: International Conference on Computer Vision, ICCV. 2015.

[67] M. Ghifary, W. B. Kleijn, M. Zhang, D. Balduzzi, and W. Li. "Deep Reconstruction-Classification Networks for Unsupervised Domain Adaptation". In: European Conference on Computer Vision, ECCV. 2016.

[68] B. Gong, K. Grauman, and F. Sha. "Connecting the Dots with Landmarks: Discriminatively Learning Domain-Invariant Features for Unsupervised Domain Adaptation". In: International Conference on Machine Learning, ICML. 2013.

[69] B. Gong, Y. Shi, F. Sha, and K. Grauman. "Geodesic flow kernel for unsupervised domain adaptation". In: Conference on Computer Vision and Pattern Recognition, CVPR. 2012.

[70] P. Gordaliza, E. del Barrio, F. Gamboa, and J. Loubes. "Obtaining Fairness using Optimal Transport Theory". In: International Conference on Machine Learning, ICML. 2019.

[71] A. Graves, G. Wayne, and I. Danihelka. Neural Turing Machines. 2014. arXiv: 1410.5401 [cs.NE].

[72] A. Gretton, K. M. Borgwardt, M. J. Rasch, B. Schölkopf, and A. J. Smola. "A Kernel Two-Sample Test". In: Journal of Machine Learning Research, JMLR 13 (2012), pp. 723-773.

[73] I. Gulrajani and D. Lopez-Paz. "In Search of Lost Domain Generalization". In: International Conference on Learning Representations, ICLR. 2021.

[74] Z. Guo, T. He, Z. Qin, Z. Xie, and J. Liu. "A Content-Based Recommendation Framework for Judicial Cases". In: International Conference of Pioneering Computer Scientists, Engineers and Educators, ICPCSEE. 2019.

[75] M. Hardt, E. Price, and N. Srebro. "Equality of Opportunity in Supervised Learning". In: Advances in Neural Information Processing Systems, NIPS. 2016.

[76] M. Harradon, J. Druce, and B. Ruttenberg. Causal Learning and Explanation of Deep Neural Networks via Autoencoded Activations. 2018. arXiv: 1802.00541 [cs.AI].

[77] K. He, X. Zhang, S. Ren, and J. Sun. "Deep Residual Learning for Image Recognition". In: Conference on Computer Vision and Pattern Recognition, CVPR. 2016.

[78] H. Heidari, C. Ferrari, K. P. Gummadi, and A. Krause. "Fairness Behind a Veil of Ignorance: A Welfare Analysis for Automated Decision Making". In: Advances in Neural Information Processing Systems, NeurIPS. 2018.

[79] L. A. Hendricks, Z. Akata, M. Rohrbach, J. Donahue, B. Schiele, and T. Darrell. "Generating Visual Explanations". In: European Conference on Computer Vision, ECCV. 2016.

[80] D. Hendrycks and T. G. Dietterich. "Benchmarking Neural Network Robustness to Common Corruptions and Perturbations". In: International Conference on Learning Representations, ICLR. 2019.

[81] M. Hind, D. Wei, M. Campbell, N. C. F. Codella, A. Dhurandhar, A. Mojsilovic, K. N. Rama-murthy, and K. R. Varshney. "TED: Teaching AI to Explain its Decisions". In: Conference on AI, Ethics, and Society, AIES. 2019.

[82] B. Hou and Z. Zhou. "Learning With Interpretable Structure From Gated RNN". In: Transactions on Neural Networks and Learning Systems 31.7 (2020), pp. 2267-2279.

[83] S. Hu, K. Zhang, Z. Chen, and L. Chan. "Domain Generalization via Multidomain Discriminant Analysis". In: Conference on Uncertainty in Artificial Intelligence, UAI. 2019.

[84] W. Hu, G. Niu, I. Sato, and M. Sugiyama. "Does Distributionally Robust Supervised Learning Give Robust Classifiers?" In: International Conference on Machine Learning, ICML. 2018.

[85] J. Huang, A. J. Smola, A. Gretton, K. M. Borgwardt, and B. Schölkopf. "Correcting Sample Selection Bias by Unlabeled Data". In: Advances in Neural Information Processing Systems, NIPS. 2006.

[86] Z. Huang, H. Wang, E. P. Xing, and D. Huang. "Self-Challenging Improves Cross-Domain Generalization". In: European Conference on Computer Vision, ECCV. 2020.

[87] D. A. Hudson and C. D. Manning. "Compositional Attention Networks for Machine Reasoning". In: International Conference on Learning Representations, ICLR. 2018.

[88] M. Ilse, J. M. Tomczak, C. Louizos, and M. Welling. "DIVA: Domain Invariant Variational Autoencoders". In: International Conference on Learning Representations, ICLR. 2019.

[89] S. Ioffe and C. Szegedy. "Batch Normalization: Accelerating Deep Network Training by Reducing Internal Covariate Shift". In: International Conference on Machine Learning, ICML. 2015.

[90] R. Iyer, Y. Li, H. Li, M. Lewis, R. Sundar, and K. P. Sycara. "Transparency and Explanation in Deep Reinforcement Learning Neural Networks". In: Conference on AI, Ethics, and Society, AIES. 2018.

[91] S. Jain and B. C. Wallace. "Attention is not Explanation". In: Conference of the North American Chapter of the Association for Computational Linguistics: Human Language Technologies, NAACL-HLT. 2019.

[92] Y. Jia, J. Zhang, S. Shan, and X. Chen. "Single-Side Domain Generalization for Face Anti-Spoofing". In: Conference on Computer Vision and Pattern Recognition, CVPR. 2020.

[93] H. Jiang, B. Kim, M. Y. Guan, and M. R. Gupta. "To Trust Or Not To Trust A Classifier". In: Advances in Neural Information Processing Systems, NeurIPS. 2018.

[94] X. Jin, C. Lan, W. Zeng, and Z. Chen. Feature Alignment and Restoration for Domain Generalization and Adaptation. 2020. arXiv: 2006.12009 [cs.CV].

[95] D. Kang, D. Raghavan, P. Bailis, and M. Zaharia. "Model Assertions for Monitoring and Improving ML Models". In: Conference on Machine Learning and Systems, MLSys. 2020.

[96] A. Khosla, T. Zhou, T. Malisiewicz, A. A. Efros, and A. Torralba. "Undoing the Damage of Dataset Bias". In: European Conference on Computer Vision, ECCV. 2012.

[97] B. Kim, C. Rudin, and J. A. Shah. "The Bayesian Case Model: A Generative Approach for Case-Based Reasoning and Prototype Classification". In: Advances in Neural Information Processing Systems, NIPS. 2014.

[98] D. P. Kingma and J. L. Ba. "Adam: A Method for Stochastic Optimization". In: International Conference on Learning Representations, ICLR. 2015.

[99] D. P. Kingma and M. Welling. "Auto-Encoding Variational Bayes". In: International Conference on Learning Representations, ICLR. 2014.

[100] A. Krizhevsky, I. Sutskever, and G. E. Hinton. "ImageNet Classification with Deep Convolutional Neural Networks". In: Advances in Neural Information Processing Systems, NIPS. 2012.

[101] D. Krueger, E. Caballero, J.-H. Jacobsen, A. Zhang, J. Binas, R. L. Priol, and A. Courville. Out-of-Distribution Generalization via Risk Extrapolation (REx). 2020. arXiv: 2003.00688 [cs.LG].

[102] Z. Lan, M. Chen, S. Goodman, K. Gimpel, P. Sharma, and R. Soricut. "ALBERT: A Lite BERT for Self-supervised Learning of Language Representations". In: International Conference on Learning Representations, ICLR. 2019.

[103] S. Lapuschkin, A. Binder, G. Montavon, K. Müller, and W. Samek. "Analyzing Classifiers: Fisher Vectors and Deep Neural Networks". In: Conference on Computer Vision and Pattern Recognition, CVPR. 2016.

[104] G. Larsson, M. Maire, and G. Shakhnarovich. "FractalNet: Ultra-Deep Neural Networks without Residuals". In: International Conference on Learning Representations, ICLR. 2017.

[105] Y. LeCun and C. Cortes. MNIST handwritten digit database. 2010.

[106] T. Lei, R. Barzilay, and T. S. Jaakkola. "Rationalizing Neural Predictions". In: Conference on Empirical Methods in Natural Language Processing, EMNLP. 2016.

[107] D. Li, Y. Yang, Y. Song, and T. M. Hospedales. "Deeper, Broader and Artier Domain Generalization". In: International Conference on Computer Vision, ICCV. 2017.

[108] D. Li, Y. Yang, Y. Song, and T. M. Hospedales. "Learning to Generalize: Meta-Learning for Domain Generalization". In: AAAI Conference on Artificial Intelligence, AAAI. 2018.

[109] D. Li, Y. Yang, Y.-Z. Song, and T. Hospedales. "Sequential Learning for Domain Generalization". In: European Conference on Computer Vision, ECCV. 2020.

[110] D. Li, J. Zhang, Y. Yang, C. Liu, Y. Song, and T. M. Hospedales. "Episodic Training for Domain Generalization". In: International Conference on Computer Vision, ICCV. 2019.

[111] F. Li, R. Fergus, and P. Perona. "Learning generative visual models from few training examples: An incremental Bayesian approach tested on 101 object categories". In: Computer Vision and Image Understanding 106.1 (2007), pp. 59-70.

[112] H. Li, S. J. Pan, S. Wang, and A. C. Kot. "Domain Generalization With Adversarial Feature Learning". In: Conference on Computer Vision and Pattern Recognition, CVPR. 2018.

[113] J. Li, W. Monroe, and D. Jurafsky. Understanding Neural Networks through Representation Erasure. 2016. arXiv: 1612.08220 [cs.CL].

[114] O. Li, H. Liu, C. Chen, and C. Rudin. "Deep Learning for Case-Based Reasoning Through Prototypes: A Neural Network That Explains Its Predictions". In: AAAI Conference on Artificial Intelligence, AAAI. 2018.

[115] Y. Li, M. Gong, X. Tian, T. Liu, and D. Tao. "Domain Generalization via Conditional Invariant Representations". In: AAAI Conference on Artificial Intelligence, AAAI. 2018.

[116] Y. Li, X. Tian, M. Gong, Y. Liu, T. Liu, K. Zhang, and D. Tao. "Deep Domain Generalization via Conditional Invariant Adversarial Networks". In: European Conference on Computer Vision, ${ECCV}$ . 2018.

[117] Y. Li, Y. Yang, W. Zhou, and T. M. Hospedales. "Feature-Critic Networks for Heterogeneous Domain Generalization". In: International Conference on Machine Learning, ICML. 2019.

[118] M. Lin, Q. Chen, and S. Yan. "Network In Network". In: International Conference on Learning Representations, ICLR. 2014.

[119] M. Long, G. Ding, J. Wang, J. Sun, Y. Guo, and P. S. Yu. "Transfer Sparse Coding for Robust Image Representation". In: Conference on Computer Vision and Pattern Recognition, CVPR. 2013.

[120] C. Louizos, K. Swersky, Y. Li, M. Welling, and R. S. Zemel. "The Variational Fair Autoen-coder". In: International Conference on Learning Representations, ICLR. 2016.

[121] T. Luong, H. Pham, and C. D. Manning. "Effective Approaches to Attention-based Neural Machine Translation". In: Conference on Empirical Methods in Natural Language Processing, EMNLP. 2015.

[122] D. Mahajan, S. Tople, and A. Sharma. Domain Generalization using Causal Matching. 2020. arXiv: 2006.07500 [cs.LG].

[123] M. Mancini, Z. Akata, E. Ricci, and B. Caputo. "Towards Recognizing Unseen Categories in Unseen Domains". In: European Conference on Computer Vision, ECCV. 2020.

[124] M. Mancini, S. R. Bulò, B. Caputo, and E. Ricci. "Best Sources Forward: Domain Generalization through Source-Specific Nets". In: International Conference on Image Processing, ICIP. 2018.

[125] M. Mancini, S. R. Bulò, B. Caputo, and E. Ricci. "Robust Place Categorization With Deep Domain Generalization". In: IEEE Robotics and Automation Letters 3.3 (2018), pp. 2093-2100.

[126] M. Mancini, L. Porzi, S. R. Bulò, B. Caputo, and E. Ricci. "Boosting Domain Adaptation by Discovering Latent Domains". In: Conference on Computer Vision and Pattern Recognition, CVPR. 2018.

[127] T. Matsuura and T. Harada. "Domain Generalization Using a Mixture of Multiple Latent Domains". In: AAAI Conference on Artificial Intelligence, AAAI. 2020.

[128] C. Molnar. Interpretable Machine Learning. A Guide for Making Black Box Models Explainable. https://christophm.github.io/interpretable-ml-book/.2019.

[129] G. Montavon, S. Lapuschkin, A. Binder, W. Samek, and K. Müller. "Explaining nonlinear classification decisions with deep Taylor decomposition". In: Pattern Recognition 65 (2017), pp. 211-222.

[130] P. Morerio, J. Cavazza, R. Volpi, R. Vidal, and V. Murino. "Curriculum Dropout". In: International Conference on Computer Vision, ICCV. 2017.

[131] S. Motiian, M. Piccirilli, D. A. Adjeroh, and G. Doretto. "Unified Deep Supervised Domain Adaptation and Generalization". In: International Conference on Computer Vision, ICCV. 2017.

[132] K. Muandet, D. Balduzzi, and B. Schölkopf. "Domain Generalization via Invariant Feature Representation". In: International Conference on Machine Learning, ICML. 2013.

[133] K. Muandet, K. Fukumizu, B. K. Sriperumbudur, and B. Schölkopf. "Kernel Mean Embedding of Distributions: A Review and Beyond". In: Foundations and Trends in Machine Learning 10.1-2 (2017), pp. 1-141.

[134] W. J. Murdoch and A. Szlam. "Automatic Rule Extraction from Long Short Term Memory Networks". In: International Conference on Learning Representations, ICLR. 2017.

[135] H. Nam, H. Lee, J. Park, W. Yoon, and D. Yoo. Reducing Domain Gap via Style-Agnostic Networks. 2019. arXiv: 1910.11645 [cs.CV].

[136] S. J. Nowlan and G. E. Hinton. "Simplifying Neural Networks by Soft Weight-Sharing". In: Neural Computation 4.4 (1992), pp. 473-493.

[137] O. Nuriel, S. Benaim, and L. Wolf. Permuted AdaIN: Enhancing the Representation of Local Cues in Image Classifiers. 2020. arXiv: 2010.05785 [cs.CV].

[138] D. H. Park, L. A. Hendricks, Z. Akata, A. Rohrbach, B. Schiele, T. Darrell, and M. Rohrbach. "Multimodal Explanations: Justifying Decisions and Pointing to the Evidence". In: Conference on Computer Vision and Pattern Recognition, CVPR. 2018.

[139] S. Park and N. Kwak. "Analysis on the Dropout Effect in Convolutional Neural Networks". In: Asian Conference on Computer Vision, ACCV. 2016.

[140] F. Pasa, V. Golkov, F. Pfeiffer, D. Cremers, and D. Pfeiffer. "Efficient Deep Network Architectures for Fast Chest X-Ray Tuberculosis Screening and Visualization". In: Scientific Reports 9.1 (2019).

[141] X. Peng, Q. Bai, X. Xia, Z. Huang, K. Saenko, and B. Wang. "Moment Matching for Multi-Source Domain Adaptation". In: International Conference on Computer Vision, ICCV. 2019.

[142] C. S. Perone, P. L. Ballester, R. C. Barros, and J. Cohen-Adad. "Unsupervised domain adaptation for medical imaging segmentation with self-ensembling". In: NeuroImage 194 (2019), pp. 1-11.

[143] J. Peters, P. Bühlmann, and N. Meinshausen. "Causal inference using invariant prediction: identification and confidence intervals". In: Journal of the Royal Statistical Society, Series B (Statistical Methodology) 78.5 (2016), pp. 947-1012.

[144] F. du Pin Calmon, D. Wei, B. Vinzamuri, K. N. Ramamurthy, and K. R. Varshney. "Optimized Pre-Processing for Discrimination Prevention". In: Advances in Neural Information Processing Systems, NIPS. 2017.

[145] V. Piratla, P. Netrapalli, and S. Sarawagi. "Efficient Domain Generalization via Common-Specific Low-Rank Decomposition". In: International Conference on Machine Learning, ICML. 2020.

[146] G. Pleiss, M. Raghavan, F. Wu, J. M. Kleinberg, and K. Q. Weinberger. "On Fairness and Calibration". In: Advances in Neural Information Processing Systems, NIPS. 2017.

[147] C. E. Priebe, D. J. Marchette, J. DeVinney, and D. A. Socolinsky. "Classification Using Class Cover Catch Digraphs". In: Journal of Classification 20.1 (2003), pp. 003-023.

[148] F. Qiao, L. Zhao, and X. Peng. "Learning to Learn Single Domain Generalization". In: Conference on Computer Vision and Pattern Recognition, CVPR. 2020.

[149] C. Qin, H. Zhu, T. Xu, C. Zhu, L. Jiang, E. Chen, and H. Xiong. "Enhancing Person-Job Fit for Talent Recruitment: An Ability-aware Neural Network Approach". In: SIGIR Conference on Research & Development in Information Retrieval, SIGIR. 2018.

[150] M. M. Rahman, C. Fookes, M. Baktashmotlagh, and S. Sridharan. "Correlation-aware adversarial domain adaptation and generalization". In: Pattern Recognition 100 (2020), p. 107124.

[151] M. M. Rahman, C. Fookes, M. Baktashmotlagh, and S. Sridharan. "Multi-Component Image Translation for Deep Domain Generalization". In: Winter Conference on Applications of Computer Vision, WACV. 2019.

[152] H. Ramsauer, B. Schäfl, J. Lehner, P. Seidl, M. Widrich, L. Gruber, M. Holzleitner, M. Pavlović, G. K. Sandve, V. Greiff, D. Kreil, M. Kopp, G. Klambauer, J. Brandstetter, and S. Hochreiter. "Hopfield Networks is All You Need". In: International Conference on Learning Representations, ICLR. 2021.

[153] M. T. Ribeiro, S. Singh, and C. Guestrin. "Why Should I Trust You?": Explaining the Predictions of Any Classifier". In: International Conference on Knowledge Discovery and Data Mining, SIGKDD. 2016.

[154] M. T. Ribeiro, S. Singh, and C. Guestrin. "Anchors: High-Precision Model-Agnostic Explanations". In: AAAI Conference on Artificial Intelligence, AAAI. 2018.

[155] H. Robbins and S. Monro. "A Stochastic Approximation Method". In: The Annals of Mathematical Statistics 22.3 (1951), pp. 400-407.

[156] M. Robnik-Sikonja and I. Kononenko. "Explaining Classifications For Individual Instances". In: IEEE Transactions on Knowledge and Data Engineering 20.5 (2008), pp. 589-600.

[157] O. Russakovsky, J. Deng, H. Su, J. Krause, S. Satheesh, S. Ma, Z. Huang, A. Karpathy, A. Khosla, M. S. Bernstein, A. C. Berg, and F. Li. "ImageNet Large Scale Visual Recognition Challenge". In: International Journal of Computer Vision, IJCV 115.3 (2015), pp. 211-252.

[158] B. C. Russell, A. Torralba, K. P. Murphy, and W. T. Freeman. "LabelMe: A Database and Web-Based Tool for Image Annotation". In: International Journal of Computer Vision, IJCV 77.1-3 (2008), pp. 157-173.

[159] S. Sagawa, P. W. Koh, T. B. Hashimoto, and P. Liang. "Distributionally Robust Neural Networks for Group Shifts: On the Importance of Regularization for Worst-Case Generalization". In: International Conference on Learning Representations, ICLR. 2020.

[160] P. Sangkloy, N. Burnell, C. Ham, and J. Hays. "The sketchy database: learning to retrieve badly drawn bunnies". In: Transactions on Graphics, TOG 35.4 (2016), 119:1-119:12.

[161] J. Schmidhuber, J. Zhao, and M. A. Wiering. "Shifting Inductive Bias with Success-Story Algorithm, Adaptive Levin Search, and Incremental Self-Improvement". In: Machine Learning 28.1 (1997), pp. 105-130.

[162] R. M. Schmidt. Recurrent Neural Networks (RNNs): A gentle Introduction and Overview. 2019. arXiv: 1912.05911 [cs.LG].

[163] R. M. Schmidt, F. Schneider, and P. Hennig. Descending through a Crowded Valley - Benchmarking Deep Learning Optimizers. 2020. arXiv: 2007.01547 [cs.LG].

[164] R. R. Selvaraju, M. Cogswell, A. Das, R. Vedantam, D. Parikh, and D. Batra. "Grad-CAM: Visual Explanations from Deep Networks via Gradient-Based Localization". In: International Conference on Computer Vision, ICCV. 2017.

[165] C. Sen, T. Hartvigsen, B. Yin, X. Kong, and E. A. Rundensteiner. "Human Attention Maps for Text Classification: Do Humans and Neural Networks Focus on the Same Words?" In: Annual Meeting of the Association for Computational Linguistics, ACL. 2020.

[166] S. Seo, Y. Suh, D. Kim, G. Kim, J. Han, and B. Han. "Learning to Optimize Domain Specific Normalization for Domain Generalization". In: European Conference on Computer Vision, ${ECCV}$ . 2020.

[167] S. Shankar, V. Piratla, S. Chakrabarti, S. Chaudhuri, P. Jyothi, and S. Sarawagi. "Generalizing Across Domains via Cross-Gradient Training". In: International Conference on Learning Representations, ICLR. 2018.

[168] A. Shrikumar, P. Greenside, and A. Kundaje. "Learning Important Features Through Propagating Activation Differences". In: International Conference on Machine Learning, ICML. 2017.

[169] A. Shrivastava, T. Pfister, O. Tuzel, J. Susskind, W. Wang, and R. Webb. "Learning from Simulated and Unsupervised Images through Adversarial Training". In: Conference on Computer Vision and Pattern Recognition, CVPR. 2017.

[170] K. Simonyan, A. Vedaldi, and A. Zisserman. "Deep Inside Convolutional Networks: Visualising Image Classification Models and Saliency Maps". In: International Conference on Learning Representations, ICLR. 2014.

[171] K. Simonyan and A. Zisserman. "Very Deep Convolutional Networks for Large-Scale Image Recognition". In: International Conference on Learning Representations, ICLR. 2015.

[172] K. K. Singh and Y. J. Lee. "Hide-and-Seek: Forcing a Network to be Meticulous for Weakly-Supervised Object and Action Localization". In: International Conference on Computer Vision, ICCV. 2017.

[173] J. Snell, K. Swersky, and R. S. Zemel. "Prototypical Networks for Few-shot Learning". In: Advances in Neural Information Processing Systems, NIPS. 2017.

[174] N. Somavarapu, C.-Y. Ma, and Z. Kira. Frustratingly Simple Domain Generalization via Image Stylization. 2020. arXiv: 2006.11207 [cs.CV].

[175] J. T. Springenberg, A. Dosovitskiy, T. Brox, and M. A. Riedmiller. "Striving for Simplicity: The All Convolutional Net". In: International Conference on Learning Representations, ICLR. 2015.

[176] B. K. Sriperumbudur, K. Fukumizu, A. Gretton, G. R. G. Lanckriet, and B. Schölkopf. "Kernel Choice and Classifiability for RKHS Embeddings of Probability Distributions". In: Advances in Neural Information Processing Systems, NIPS. 2009.

[177] N. Srivastava, G. E. Hinton, A. Krizhevsky, I. Sutskever, and R. Salakhutdinov. "Dropout: a simple way to prevent neural networks from overfitting". In: Journal of Machine Learning Research, JMLR 15.1 (2014), pp. 1929-1958.

[178] P. Stock and M. Cissé. "ConvNets and ImageNet Beyond Accuracy: Understanding Mistakes and Uncovering Biases". In: European Conference on Computer Vision, ECCV. 2018.

[179] B. Sun and K. Saenko. "Deep CORAL: Correlation Alignment for Deep Domain Adaptation". In: European Conference on Computer Vision, ECCV. 2016.

[180] G. Sun, S. Khan, W. Li, H. Cholakkal, F. Khan, and L. V. Gool. "Fixing Localization Errors to Improve Image Classification". In: European Conference on Computer Vision, ECCV. 2020.

[181] M. Sundararajan, A. Taly, and Q. Yan. "Axiomatic Attribution for Deep Networks". In: International Conference on Machine Learning, ICML. 2017.

[182] S. Tan, R. Caruana, G. Hooker, P. Koch, and A. Gordo. Learning Global Additive Explanations for Neural Nets Using Model Distillation. 2018. arXiv: 1801.08640 [stat.ML].

[183] S. Thrun and L. Y. Pratt. Learning to Learn. Springer, 1998.

[184] I. O. Tolstikhin, O. Bousquet, S. Gelly, and B. Schölkopf. "Wasserstein Auto-Encoders". In: International Conference on Learning Representations, ICLR. 2018.

[185] J. Tompson, R. Goroshin, A. Jain, Y. LeCun, and C. Bregler. "Efficient object localization using Convolutional Networks". In: Conference on Computer Vision and Pattern Recognition, CVPR. 2015.

[186] E. Tzeng, J. Hoffman, K. Saenko, and T. Darrell. "Adversarial Discriminative Domain Adaptation". In: Conference on Computer Vision and Pattern Recognition, CVPR. 2017.

[187] V. Vapnik. Statistical Learning Theory. 1998.

[188] K. R. Varshney and H. Alemzadeh. "On the Safety of Machine Learning: Cyber-Physical Systems, Decision Sciences, and Data Products". In: Big Data 5.3 (2017), pp. 246-255.

[189] A. Vaswani, N. Shazeer, N. Parmar, J. Uszkoreit, L. Jones, A. N. Gomez, L. Kaiser, and I. Polosukhin. "Attention is All you Need". In: Advances in Neural Information Processing Systems, NIPS. 2017.

[190] H. Venkateswara, J. Eusebio, S. Chakraborty, and S. Panchanathan. "Deep Hashing Network for Unsupervised Domain Adaptation". In: Conference on Computer Vision and Pattern Recognition, CVPR. 2017.

[191] G. Volk, S. Müller, A. von Bernuth, D. Hospach, and O. Bringmann. "Towards Robust CNN-based Object Detection through Augmentation with Synthetic Rain Variations". In: International Conference on Intelligent Transportation Systems Conference, ITSC. 2019.

[192] R. Volpi and V. Murino. "Addressing Model Vulnerability to Distributional Shifts Over Image Transformation Sets". In: International Conference on Computer Vision, ICCV. 2019.

[193] R. Volpi, H. Namkoong, O. Sener, J. C. Duchi, V. Murino, and S. Savarese. "Generalizing to Unseen Domains via Adversarial Data Augmentation". In: Advances in Neural Information Processing Systems, NeurIPS. 2018.

[194] H. Wang, Z. He, Z. C. Lipton, and E. P. Xing. "Learning Robust Representations by Projecting Superficial Statistics Out". In: International Conference on Learning Representations, ICLR. 2019.

[195] Y. Wang, H. Li, and A. C. Kot. "Heterogeneous Domain Generalization Via Domain Mixup". In: International Conference on Acoustics, Speech and Signal Processing, ICASSP. 2020.

[196] S. Wiegreffe and Y. Pinter. "Attention is not not Explanation". In: Conference on Empirical Methods in Natural Language Processing, EMNLP. 2019.

[197] B. E. Woodworth, S. Gunasekar, M. I. Ohannessian, and N. Srebro. "Learning Non-Discriminatory Predictors". In: Conference on Learning Theory, COLT. 2017.

[198] C. Wu and E. G. Tabak. Prototypal Analysis and Prototypal Regression. 2017. arXiv: 1701. 08916 [stat.ML].

[199] N. Xie, G. Ras, M. van Gerven, and D. Doran. Explainable Deep Learning: A Field Guide for the Uninitiated. 2020. arXiv: 2004.14545 [cs.LG].

[200] M. Xu, J. Zhang, B. Ni, T. Li, C. Wang, Q. Tian, and W. Zhang. "Adversarial Domain Adaptation with Domain Mixup". In: AAAI Conference on Artificial Intelligence, AAAI. 2020.

[201] W. Xu, Y. Xian, J. Wang, B. Schiele, and Z. Akata. "Attribute Prototype Network for Zero-Shot Learning". In: Advances in Neural Information Processing Systems, NeurIPS. 2020.

[202] M. Yamada, L. Sigal, and M. Raptis. "No Bias Left behind: Covariate Shift Adaptation for Discriminative 3D Pose Estimation". In: European Conference on Computer Vision, ECCV. 2012.

[203] S. Yan, H. Song, N. Li, L. Zou, and L. Ren. Improve Unsupervised Domain Adaptation with Mixup Training. 2020. arXiv: 2001.00677 [stat.ML].

[204] M. B. Zafar, I. Valera, M. Gomez-Rodriguez, and K. P. Gummadi. "Fairness Beyond Disparate Treatment & Disparate Impact: Learning Classification without Disparate Mistreatment". In: International Conference on World Wide Web, WWW. 2017.

[205] S. W. Zamir, A. Arora, S. Khan, M. Hayat, F. S. Khan, M. Yang, and L. Shao. "CycleISP: Real Image Restoration via Improved Data Synthesis". In: Conference on Computer Vision and Pattern Recognition, CVPR. 2020.

[206] M. D. Zeiler and R. Fergus. "Visualizing and Understanding Convolutional Networks". In: European Conference on Computer Vision, ECCV. 2014.

[207] R. Zellers, Y. Bisk, A. Farhadi, and Y. Choi. "From Recognition to Cognition: Visual Commonsense Reasoning". In: Conference on Computer Vision and Pattern Recognition, CVPR. 2019.

[208] R. S. Zemel, Y. Wu, K. Swersky, T. Pitassi, and C. Dwork. "Learning Fair Representations". In: International Conference on Machine Learning, ICML. 2013.

[209] X. Zeng, W. Ouyang, M. Wang, and X. Wang. "Deep Learning of Scene-Specific Classifier for Pedestrian Detection". In: European Conference on Computer Vision, ECCV. 2014.

[210] H. Zhang, M. Cissé, Y. N. Dauphin, and D. Lopez-Paz. "mixup: Beyond Empirical Risk Minimization". In: International Conference on Learning Representations, ICLR. 2018.

[211] L. Zhang, X. Wang, D. Yang, T. Sanford, S. Harmon, B. Turkbey, H. Roth, A. Myronenko, D. Xu, and Z. Xu. When Unseen Domain Generalization is Unnecessary? Rethinking Data Augmentation. 2019. arXiv: 1906.03347 [cs.CV].

[212] M. Zhang, H. Marklund, N. Dhawan, A. Gupta, S. Levine, and C. Finn. Adaptive Risk Minimization: A Meta-Learning Approach for Tackling Group Shift. 2020. arXiv: 2007.02931 [cs.LG].

[213] Q. Zhang, R. Cao, F. Shi, Y. N. Wu, and S. Zhu. "Interpreting CNN Knowledge via an Explanatory Graph". In: AAAI Conference on Artificial Intelligence, AAAI. 2018.

[214] Q. Zhang, R. Cao, Y. N. Wu, and S. Zhu. "Growing Interpretable Part Graphs on ConvNets via Multi-Shot Learning". In: AAAI Conference on Artificial Intelligence, AAAI. 2017.

[215] Q. Zhang, Y. Yang, H. Ma, and Y. N. Wu. "Interpreting CNNs via Decision Trees". In: Conference on Computer Vision and Pattern Recognition, CVPR. 2019.

[216] Y. Zhao, M. K. Hryniewicki, F. Cheng, B. Fu, and X. Zhu. "Employee Turnover Prediction with Machine Learning: A Reliable Approach". In: Intelligent Systems Conference, IntelliSys. 2018.

[217] B. Zhou, A. Khosla, À. Lapedriza, A. Oliva, and A. Torralba. "Learning Deep Features for Discriminative Localization". In: Conference on Computer Vision and Pattern Recognition, CVPR. 2016.

[218] K. Zhou, Y. Yang, T. Hospedales, and T. Xiang. "Learning to Generate Novel Domains for Domain Generalization". In: European Conference on Computer Vision, ECCV. 2020.

[219] K. Zhou, Y. Yang, T. M. Hospedales, and T. Xiang. "Deep Domain-Adversarial Image Generation for Domain Generalisation". In: AAAI Conference on Artificial Intelligence, AAAI. 2020.

[220] L. M. Zintgraf, T. S. Cohen, T. Adel, and M. Welling. "Visualizing Deep Neural Network Decisions: Prediction Difference Analysis". In: International Conference on Learning Representations, ICLR. 2017.

[221] A. Zunino, S. A. Bargal, R. Volpi, M. Sameki, J. Zhang, S. Sclaroff, V. Murino, and K. Saenko. Explainable Deep Classification Models for Domain Generalization. 2020. arXiv: 2003.06498 [cs.CV].

## Appendix A

## Domain-specific results

Since Table 5.2 only shows the average performance for the respective dataset, we provide the full experimental results here for each of the domains across datasets. The results for the other algorithms besides RSC, DivCAM, and D-TRANSFORMERS are taken from DomAINBED.

<table><tr><td>Algorithm</td><td>C</td><td>L</td><td>S</td><td>V</td><td>$\mathbf{{Avg}.}$</td></tr><tr><td>ERM</td><td>${97.7} \pm  {0.4}$</td><td>${64.3} \pm  {0.9}$</td><td>${73.4} \pm  {0.5}$</td><td>${74.6} \pm  {1.3}$</td><td>77.5</td></tr><tr><td>IRM</td><td>${98.6} \pm  {0.1}$</td><td>${64.9} \pm  {0.9}$</td><td>${73.4} \pm  {0.6}$</td><td>${77.3} \pm  {0.9}$</td><td>78.5</td></tr><tr><td>GroupDRO</td><td>${97.3} \pm  {0.3}$</td><td>${63.4} \pm  {0.9}$</td><td>${69.5} \pm  {0.8}$</td><td>${76.7} \pm  {0.7}$</td><td>76.7</td></tr><tr><td>Mixup</td><td>${98.3} \pm  {0.6}$</td><td>${64.8} \pm  {1.0}$</td><td>${72.1} \pm  {0.5}$</td><td>${74.3} \pm  {0.8}$</td><td>77.4</td></tr><tr><td>MLDG</td><td>${97.4} \pm  {0.2}$</td><td>${65.2} \pm  {0.7}$</td><td>${71.0} \pm  {1.4}$</td><td>${75.3} \pm  {1.0}$</td><td>77.2</td></tr><tr><td>CORAL</td><td>${98.3} \pm  {0.1}$</td><td>${66.1} \pm  {1.2}$</td><td>${73.4} \pm  {0.3}$</td><td>${77.5} \pm  {1.2}$</td><td>78.8</td></tr><tr><td>MMD</td><td>${97.7} \pm  {0.1}$</td><td>${64.0} \pm  {1.1}$</td><td>${72.8} \pm  {0.2}$</td><td>${75.3} \pm  {3.3}$</td><td>77.5</td></tr><tr><td>DANN</td><td>${99.0} \pm  {0.3}$</td><td>${65.1} \pm  {1.4}$</td><td>${73.1} \pm  {0.3}$</td><td>${77.2} \pm  {0.6}$</td><td>78.6</td></tr><tr><td>CDANN</td><td>${97.1} \pm  {0.3}$</td><td>${65.1} \pm  {1.2}$</td><td>${70.7} \pm  {0.8}$</td><td>${77.1} \pm  {1.5}$</td><td>77.5</td></tr><tr><td>MTL</td><td>${97.8} \pm  {0.4}$</td><td>${64.3} \pm  {0.3}$</td><td>${71.5} \pm  {0.7}$</td><td>${75.3} \pm  {1.7}$</td><td>77.2</td></tr><tr><td>SagNet</td><td>${97.9} \pm  {0.4}$</td><td>${64.5} \pm  {0.5}$</td><td>${71.4} \pm  {1.3}$</td><td>${77.5} \pm  {0.5}$</td><td>77.8</td></tr><tr><td>ARM</td><td>${98.7} \pm  {0.2}$</td><td>${63.6} \pm  {0.7}$</td><td>${71.3} \pm  {1.2}$</td><td>${76.7} \pm  {0.6}$</td><td>77.6</td></tr><tr><td>VREx</td><td>${98.4} \pm  {0.3}$</td><td>${64.4} \pm  {1.4}$</td><td>${74.1} \pm  {0.4}$</td><td>${76.2} \pm  {1.3}$</td><td>78.3</td></tr><tr><td>RSC</td><td>${97.9} \pm  {0.1}$</td><td>${62.5} \pm  {0.7}$</td><td>${72.3} \pm  {1.2}$</td><td>${75.6} \pm  {0.8}$</td><td>77.1</td></tr><tr><td>DivCAM-S</td><td>${98.7} \pm  {0.1}$</td><td>${64.5} \pm  {1.1}$</td><td>${72.5} \pm  {0.7}$</td><td>${75.5} \pm  {0.4}$</td><td>77.8</td></tr><tr><td>D-TRANSFORMERS</td><td>${98.1} \pm  {0.2}$</td><td>${65.8} \pm  {0.6}$</td><td>${71.7} \pm  {0.4}$</td><td>${79.2} \pm  {1.3}$</td><td>78.7</td></tr><tr><td>ERM*</td><td>${97.6} \pm  {0.3}$</td><td>${67.9} \pm  {0.7}$</td><td>${70.9} \pm  {0.2}$</td><td>${74.0} \pm  {0.6}$</td><td>77.6</td></tr><tr><td>IRM*</td><td>${97.3} \pm  {0.2}$</td><td>${66.7} \pm  {0.1}$</td><td>${71.0} \pm  {2.3}$</td><td>${72.8} \pm  {0.4}$</td><td>76.9</td></tr><tr><td>GroupDRO*</td><td>${97.7} \pm  {0.2}$</td><td>${65.9} \pm  {0.2}$</td><td>${72.8} \pm  {0.8}$</td><td>${73.4} \pm  {1.3}$</td><td>77.4</td></tr><tr><td>Mixup*</td><td>${97.8} \pm  {0.4}$</td><td>${67.2} \pm  {0.4}$</td><td>${71.5} \pm  {0.2}$</td><td>${75.7} \pm  {0.6}$</td><td>78.1</td></tr><tr><td>MLDG*</td><td>${97.1} \pm  {0.5}$</td><td>${66.6} \pm  {0.5}$</td><td>${71.5} \pm  {0.1}$</td><td>${75.0} \pm  {0.9}$</td><td>77.5</td></tr><tr><td>CORAL*</td><td>${97.3} \pm  {0.2}$</td><td>${67.5} \pm  {0.6}$</td><td>${71.6} \pm  {0.6}$</td><td>${74.5} \pm  {0.0}$</td><td>77.7</td></tr><tr><td>MMD*</td><td>${98.8} \pm  {0.0}$</td><td>${66.4} \pm  {0.4}$</td><td>${70.8} \pm  {0.5}$</td><td>${75.6} \pm  {0.4}$</td><td>77.9</td></tr><tr><td>DANN*</td><td>${99.0} \pm  {0.2}$</td><td>${66.3} \pm  {1.2}$</td><td>${73.4} \pm  {1.4}$</td><td>${80.1} \pm  {0.5}$</td><td>79.7</td></tr><tr><td>CDANN*</td><td>${98.2} \pm  {0.1}$</td><td>${68.8} \pm  {0.5}$</td><td>${74.3} \pm  {0.6}$</td><td>${78.1} \pm  {0.5}$</td><td>79.9</td></tr><tr><td>MTL*</td><td>${97.9} \pm  {0.7}$</td><td>${66.1} \pm  {0.7}$</td><td>${72.0} \pm  {0.4}$</td><td>${74.9} \pm  {1.1}$</td><td>77.7</td></tr><tr><td>SagNet*</td><td>${97.4} \pm  {0.3}$</td><td>${66.4} \pm  {0.4}$</td><td>${71.6} \pm  {0.1}$</td><td>${75.0} \pm  {0.8}$</td><td>77.6</td></tr><tr><td>ARM*</td><td>${97.6} \pm  {0.6}$</td><td>${66.5} \pm  {0.3}$</td><td>${72.7} \pm  {0.6}$</td><td>${74.4} \pm  {0.7}$</td><td>77.8</td></tr><tr><td>VREx*</td><td>${98.4} \pm  {0.2}$</td><td>${66.4} \pm  {0.7}$</td><td>${72.8} \pm  {0.1}$</td><td>${75.0} \pm  {1.4}$</td><td>78.1</td></tr><tr><td>RSC*</td><td>${98.0} \pm  {0.4}$</td><td>${67.2} \pm  {0.3}$</td><td>${70.3} \pm  {1.3}$</td><td>${75.6} \pm  {0.4}$</td><td>77.8</td></tr><tr><td>DIVCAM-S*</td><td>${98.0} \pm  {0.5}$</td><td>${66.1} \pm  {0.3}$</td><td>${72.0} \pm  {1.0}$</td><td>${76.4} \pm  {0.7}$</td><td>78.1</td></tr><tr><td>D-TRANSFORMERS*</td><td>${98.1} \pm  {0.3}$</td><td>${66.5} \pm  {0.8}$</td><td>${72.4} \pm  {0.9}$</td><td>${74.0} \pm  {0.4}$</td><td>77.7</td></tr></table>

Table A.1: Domain specific performance for the VLCS dataset using training-domain validation (top) and oracle validation denoted with * (bottom). We use a ResNet-50 backbone, optimize with ADAM, and follow the distributions specified in DOMAINBED. Only RSC and our methods have been added as part of this work, the other baselines are taken from DOMAINBED.

<table><tr><td>Algorithm</td><td>A</td><td>C</td><td>$\mathbf{P}$</td><td>S</td><td>$\mathbf{{Avg}.}$</td></tr><tr><td>ERM</td><td>${84.7} \pm  {0.4}$</td><td>${80.8} \pm  {0.6}$</td><td>${97.2} \pm  {0.3}$</td><td>${79.3} \pm  {1.0}$</td><td>85.5</td></tr><tr><td>IRM</td><td>${84.8} \pm  {1.3}$</td><td>${76.4} \pm  {1.1}$</td><td>${96.7} \pm  {0.6}$</td><td>${76.1} \pm  {1.0}$</td><td>83.5</td></tr><tr><td>GroupDRO</td><td>${83.5} \pm  {0.9}$</td><td>${79.1} \pm  {0.6}$</td><td>${96.7} \pm  {0.3}$</td><td>${78.3} \pm  {2.0}$</td><td>84.4</td></tr><tr><td>Mixup</td><td>${86.1} \pm  {0.5}$</td><td>${78.9} \pm  {0.8}$</td><td>${97.6} \pm  {0.1}$</td><td>${75.8} \pm  {1.8}$</td><td>84.6</td></tr><tr><td>MLDG</td><td>${85.5} \pm  {1.4}$</td><td>${80.1} \pm  {1.7}$</td><td>${97.4} \pm  {0.3}$</td><td>${76.6} \pm  {1.1}$</td><td>84.9</td></tr><tr><td>CORAL</td><td>${88.3} \pm  {0.2}$</td><td>${80.0} \pm  {0.5}$</td><td>${97.5} \pm  {0.3}$</td><td>${78.8} \pm  {1.3}$</td><td>86.2</td></tr><tr><td>MMD</td><td>${86.1} \pm  {1.4}$</td><td>${79.4} \pm  {0.9}$</td><td>${96.6} \pm  {0.2}$</td><td>${76.5} \pm  {0.5}$</td><td>84.6</td></tr><tr><td>DANN</td><td>${86.4} \pm  {0.8}$</td><td>${77.4} \pm  {0.8}$</td><td>${97.3} \pm  {0.4}$</td><td>${73.5} \pm  {2.3}$</td><td>83.6</td></tr><tr><td>CDANN</td><td>${84.6} \pm  {1.8}$</td><td>${75.5} \pm  {0.9}$</td><td>${96.8} \pm  {0.3}$</td><td>${73.5} \pm  {0.6}$</td><td>82.6</td></tr><tr><td>MTL</td><td>${87.5} \pm  {0.8}$</td><td>${77.1} \pm  {0.5}$</td><td>${96.4} \pm  {0.8}$</td><td>${77.3} \pm  {1.8}$</td><td>84.6</td></tr><tr><td>SagNet</td><td>${87.4} \pm  {1.0}$</td><td>${80.7} \pm  {0.6}$</td><td>${97.1} \pm  {0.1}$</td><td>${80.0} \pm  {0.4}$</td><td>86.3</td></tr><tr><td>ARM</td><td>${86.8} \pm  {0.6}$</td><td>${76.8} \pm  {0.5}$</td><td>${97.4} \pm  {0.3}$</td><td>${79.3} \pm  {1.2}$</td><td>85.1</td></tr><tr><td>VREx</td><td>${86.0} \pm  {1.6}$</td><td>${79.1} \pm  {0.6}$</td><td>${96.9} \pm  {0.5}$</td><td>${77.7} \pm  {1.7}$</td><td>84.9</td></tr><tr><td>RSC</td><td>${85.4} \pm  {0.8}$</td><td>${79.7} \pm  {1.8}$</td><td>${97.6} \pm  {0.3}$</td><td>${78.2} \pm  {1.2}$</td><td>85.2</td></tr><tr><td>DivCAM-S</td><td>${86.2} \pm  {1.4}$</td><td>${79.1} \pm  {2.2}$</td><td>${97.3} \pm  {0.4}$</td><td>${79.2} \pm  {0.1}$</td><td>85.4</td></tr><tr><td>D-TRANSFORMERS</td><td>${86.9} \pm  {0.8}$</td><td>${78.2} \pm  {1.7}$</td><td>${96.6} \pm  {0.7}$</td><td>${75.1} \pm  {0.5}$</td><td>84.2</td></tr><tr><td>ERM*</td><td>${86.5} \pm  {1.0}$</td><td>${81.3} \pm  {0.6}$</td><td>${96.2} \pm  {0.3}$</td><td>${82.7} \pm  {1.1}$</td><td>86.7</td></tr><tr><td>IRM*</td><td>${84.2} \pm  {0.9}$</td><td>${79.7} \pm  {1.5}$</td><td>${95.9} \pm  {0.4}$</td><td>${78.3} \pm  {2.1}$</td><td>84.5</td></tr><tr><td>GroupDRO*</td><td>${87.5} \pm  {0.5}$</td><td>${82.9} \pm  {0.6}$</td><td>${97.1} \pm  {0.3}$</td><td>${81.1} \pm  {1.2}$</td><td>87.1</td></tr><tr><td>Mixup*</td><td>${87.5} \pm  {0.4}$</td><td>${81.6} \pm  {0.7}$</td><td>${97.4} \pm  {0.2}$</td><td>${80.8} \pm  {0.9}$</td><td>86.8</td></tr><tr><td>MLDG*</td><td>${87.0} \pm  {1.2}$</td><td>${82.5} \pm  {0.9}$</td><td>${96.7} \pm  {0.3}$</td><td>${81.2} \pm  {0.6}$</td><td>86.8</td></tr><tr><td>CORAL*</td><td>${86.6} \pm  {0.8}$</td><td>${81.8} \pm  {0.9}$</td><td>${97.1} \pm  {0.5}$</td><td>${82.7} \pm  {0.6}$</td><td>87.1</td></tr><tr><td>MMD*</td><td>${88.1} \pm  {0.8}$</td><td>${82.6} \pm  {0.7}$</td><td>${97.1} \pm  {0.5}$</td><td>${81.2} \pm  {1.2}$</td><td>87.2</td></tr><tr><td>DANN*</td><td>${87.0} \pm  {0.4}$</td><td>${80.3} \pm  {0.6}$</td><td>${96.8} \pm  {0.3}$</td><td>${76.9} \pm  {1.1}$</td><td>85.2</td></tr><tr><td>CDANN*</td><td>${87.7} \pm  {0.6}$</td><td>${80.7} \pm  {1.2}$</td><td>${97.3} \pm  {0.4}$</td><td>${77.6} \pm  {1.5}$</td><td>85.8</td></tr><tr><td>MTL*</td><td>${87.0} \pm  {0.2}$</td><td>${82.7} \pm  {0.8}$</td><td>${96.5} \pm  {0.7}$</td><td>${80.5} \pm  {0.8}$</td><td>86.7</td></tr><tr><td>SagNet*</td><td>${87.4} \pm  {0.5}$</td><td>${81.2} \pm  {1.2}$</td><td>${96.3} \pm  {0.8}$</td><td>${80.7} \pm  {1.1}$</td><td>86.4</td></tr><tr><td>ARM*</td><td>${85.0} \pm  {1.2}$</td><td>${81.4} \pm  {0.2}$</td><td>${95.9} \pm  {0.3}$</td><td>${80.9} \pm  {0.5}$</td><td>85.8</td></tr><tr><td>VREx*</td><td>${87.8} \pm  {1.2}$</td><td>${81.8} \pm  {0.7}$</td><td>${97.4} \pm  {0.2}$</td><td>${82.1} \pm  {0.7}$</td><td>87.2</td></tr><tr><td>RSC*</td><td>${86.0} \pm  {0.7}$</td><td>${81.8} \pm  {0.9}$</td><td>${96.8} \pm  {0.7}$</td><td>${80.4} \pm  {0.5}$</td><td>86.2</td></tr><tr><td>DivCAM-S*</td><td>${86.5} \pm  {0.4}$</td><td>${83.0} \pm  {0.5}$</td><td>${97.2} \pm  {0.3}$</td><td>${82.2} \pm  {0.1}$</td><td>87.2</td></tr><tr><td>D-TRANSFORMERS*</td><td>${87.8} \pm  {0.6}$</td><td>${81.6} \pm  {0.3}$</td><td>${97.2} \pm  {0.5}$</td><td>${80.9} \pm  {0.5}$</td><td>86.9</td></tr></table>

Table A.2: Domain specific performance for the PACS dataset using training-domain validation (top) and oracle validation denoted with * (bottom). We use a ResNet-50 backbone, optimize with ADAM, and follow the distributions specified in DOMAINBED. Only RSC and our methods have been added as part of this work, the other baselines are taken from DOMAINBED.

<table><tr><td>Algorithm</td><td>A</td><td>C</td><td>P</td><td>$\mathbf{R}$</td><td>$\mathbf{{Avg}.}$</td></tr><tr><td>ERM</td><td>${61.3} \pm  {0.7}$</td><td>${52.4} \pm  {0.3}$</td><td>${75.8} \pm  {0.1}$</td><td>${76.6} \pm  {0.3}$</td><td>66.5</td></tr><tr><td>IRM</td><td>${58.9} \pm  {2.3}$</td><td>${52.2} \pm  {1.6}$</td><td>${72.1} \pm  {2.9}$</td><td>${74.0} \pm  {2.5}$</td><td>64.3</td></tr><tr><td>GroupDRO</td><td>${60.4} \pm  {0.7}$</td><td>${52.7} \pm  {1.0}$</td><td>${75.0} \pm  {0.7}$</td><td>${76.0} \pm  {0.7}$</td><td>66.0</td></tr><tr><td>Mixup</td><td>${62.4} \pm  {0.8}$</td><td>${54.8} \pm  {0.6}$</td><td>${76.9} \pm  {0.3}$</td><td>${78.3} \pm  {0.2}$</td><td>68.1</td></tr><tr><td>MLDG</td><td>${61.5} \pm  {0.9}$</td><td>${53.2} \pm  {0.6}$</td><td>${75.0} \pm  {1.2}$</td><td>${77.5} \pm  {0.4}$</td><td>66.8</td></tr><tr><td>CORAL</td><td>${65.3} \pm  {0.4}$</td><td>${54.4} \pm  {0.5}$</td><td>${76.5} \pm  {0.1}$</td><td>${78.4} \pm  {0.5}$</td><td>68.7</td></tr><tr><td>MMD</td><td>${60.4} \pm  {0.2}$</td><td>${53.3} \pm  {0.3}$</td><td>${74.3} \pm  {0.1}$</td><td>${77.4} \pm  {0.6}$</td><td>66.3</td></tr><tr><td>DANN</td><td>${59.9} \pm  {1.3}$</td><td>${53.0} \pm  {0.3}$</td><td>${73.6} \pm  {0.7}$</td><td>${76.9} \pm  {0.5}$</td><td>65.9</td></tr><tr><td>CDANN</td><td>${61.5} \pm  {1.4}$</td><td>${50.4} \pm  {2.4}$</td><td>${74.4} \pm  {0.9}$</td><td>${76.6} \pm  {0.8}$</td><td>65.8</td></tr><tr><td>MTL</td><td>${61.5} \pm  {0.7}$</td><td>${52.4} \pm  {0.6}$</td><td>${74.9} \pm  {0.4}$</td><td>${76.8} \pm  {0.4}$</td><td>66.4</td></tr><tr><td>SagNet</td><td>${63.4} \pm  {0.2}$</td><td>${54.8} \pm  {0.4}$</td><td>${75.8} \pm  {0.4}$</td><td>${78.3} \pm  {0.3}$</td><td>68.1</td></tr><tr><td>ARM</td><td>${58.9} \pm  {0.8}$</td><td>${51.0} \pm  {0.5}$</td><td>${74.1} \pm  {0.1}$</td><td>${75.2} \pm  {0.3}$</td><td>64.8</td></tr><tr><td>VREx</td><td>${60.7} \pm  {0.9}$</td><td>${53.0} \pm  {0.9}$</td><td>${75.3} \pm  {0.1}$</td><td>${76.6} \pm  {0.5}$</td><td>66.4</td></tr><tr><td>RSC</td><td>${60.7} \pm  {1.4}$</td><td>${51.4} \pm  {0.3}$</td><td>${74.8} \pm  {1.1}$</td><td>${75.1} \pm  {1.3}$</td><td>65.5</td></tr><tr><td>DivCAM-S</td><td>${59.5} \pm  {0.3}$</td><td>${49.7} \pm  {0.1}$</td><td>${75.4} \pm  {0.7}$</td><td>${76.2} \pm  {0.2}$</td><td>65.2</td></tr><tr><td>ERM*</td><td>${61.7} \pm  {0.7}$</td><td>${53.4} \pm  {0.3}$</td><td>${74.1} \pm  {0.4}$</td><td>${76.2} \pm  {0.6}$</td><td>66.4</td></tr><tr><td>IRM*</td><td>${56.4} \pm  {3.2}$</td><td>${51.2} \pm  {2.3}$</td><td>${71.7} \pm  {2.7}$</td><td>${72.7} \pm  {2.7}$</td><td>63.0</td></tr><tr><td>GroupDRO*</td><td>${60.5} \pm  {1.6}$</td><td>${53.1} \pm  {0.3}$</td><td>${75.5} \pm  {0.3}$</td><td>${75.9} \pm  {0.7}$</td><td>66.2</td></tr><tr><td>Mixup*</td><td>${63.5} \pm  {0.2}$</td><td>${54.6} \pm  {0.4}$</td><td>${76.0} \pm  {0.3}$</td><td>${78.0} \pm  {0.7}$</td><td>68.0</td></tr><tr><td>MLDG*</td><td>${60.5} \pm  {0.7}$</td><td>${54.2} \pm  {0.5}$</td><td>${75.0} \pm  {0.2}$</td><td>${76.7} \pm  {0.5}$</td><td>66.6</td></tr><tr><td>CORAL*</td><td>${64.8} \pm  {0.8}$</td><td>${54.1} \pm  {0.9}$</td><td>${76.5} \pm  {0.4}$</td><td>${78.2} \pm  {0.4}$</td><td>68.4</td></tr><tr><td>MMD*</td><td>${60.4} \pm  {1.0}$</td><td>${53.4} \pm  {0.5}$</td><td>${74.9} \pm  {0.1}$</td><td>${76.1} \pm  {0.7}$</td><td>66.2</td></tr><tr><td>DANN*</td><td>${60.6} \pm  {1.4}$</td><td>${51.8} \pm  {0.7}$</td><td>${73.4} \pm  {0.5}$</td><td>${75.5} \pm  {0.9}$</td><td>65.3</td></tr><tr><td>CDANN*</td><td>${57.9} \pm  {0.2}$</td><td>${52.1} \pm  {1.2}$</td><td>${74.9} \pm  {0.7}$</td><td>${76.2} \pm  {0.2}$</td><td>65.3</td></tr><tr><td>MTL*</td><td>${60.7} \pm  {0.8}$</td><td>${53.5} \pm  {1.3}$</td><td>${75.2} \pm  {0.6}$</td><td>${76.6} \pm  {0.6}$</td><td>66.5</td></tr><tr><td>SagNet*</td><td>${62.7} \pm  {0.5}$</td><td>${53.6} \pm  {0.5}$</td><td>${76.0} \pm  {0.3}$</td><td>${77.8} \pm  {0.1}$</td><td>67.5</td></tr><tr><td>ARM*</td><td>${58.8} \pm  {0.5}$</td><td>${51.8} \pm  {0.7}$</td><td>${74.0} \pm  {0.1}$</td><td>${74.4} \pm  {0.2}$</td><td>64.8</td></tr><tr><td>VREx*</td><td>${59.6} \pm  {1.0}$</td><td>${53.3} \pm  {0.3}$</td><td>${73.2} \pm  {0.5}$</td><td>${76.6} \pm  {0.4}$</td><td>65.7</td></tr><tr><td>RSC*</td><td>${61.7} \pm  {0.8}$</td><td>${53.0} \pm  {0.9}$</td><td>${74.8} \pm  {0.8}$</td><td>${76.3} \pm  {0.5}$</td><td>66.5</td></tr><tr><td>DIVCAM-S*</td><td>${58.4} \pm  {1.1}$</td><td>${52.7} \pm  {0.7}$</td><td>${74.3} \pm  {0.5}$</td><td>${75.2} \pm  {0.2}$</td><td>65.2</td></tr></table>

Table A.3: Domain specific performance for the Office-Home dataset using training-domain validation (top) and oracle validation denoted with * (bottom). We use a ResNet-50 backbone, optimize with ADAM, and follow the distributions specified in DOMAINBED. Only RSC and our methods have been added as part of this work, the other baselines are taken from DOMAINBED.

<table><tr><td>Algorithm</td><td>L100</td><td>L38</td><td>L43</td><td>L46</td><td>$\mathbf{{Avg}.}$</td></tr><tr><td>ERM</td><td>${49.8} \pm  {4.4}$</td><td>${42.1} \pm  {1.4}$</td><td>${56.9} \pm  {1.8}$</td><td>${35.7} \pm  {3.9}$</td><td>46.1</td></tr><tr><td>IRM</td><td>${54.6} \pm  {1.3}$</td><td>${39.8} \pm  {1.9}$</td><td>${56.2} \pm  {1.8}$</td><td>${39.6} \pm  {0.8}$</td><td>47.6</td></tr><tr><td>GroupDRO</td><td>${41.2} \pm  {0.7}$</td><td>${38.6} \pm  {2.1}$</td><td>${56.7} \pm  {0.9}$</td><td>${36.4} \pm  {2.1}$</td><td>43.2</td></tr><tr><td>Mixup</td><td>${59.6} \pm  {2.0}$</td><td>${42.2} \pm  {1.4}$</td><td>${55.9} \pm  {0.8}$</td><td>${33.9} \pm  {1.4}$</td><td>47.9</td></tr><tr><td>MLDG</td><td>${54.2} \pm  {3.0}$</td><td>${44.3} \pm  {1.1}$</td><td>${55.6} \pm  {0.3}$</td><td>${36.9} \pm  {2.2}$</td><td>47.7</td></tr><tr><td>CORAL</td><td>${51.6} \pm  {2.4}$</td><td>${42.2} \pm  {1.0}$</td><td>${57.0} \pm  {1.0}$</td><td>${39.8} \pm  {2.9}$</td><td>47.6</td></tr><tr><td>MMD</td><td>${41.9} \pm  {3.0}$</td><td>${34.8} \pm  {1.0}$</td><td>${57.0} \pm  {1.9}$</td><td>${35.2} \pm  {1.8}$</td><td>42.2</td></tr><tr><td>DANN</td><td>${51.1} \pm  {3.5}$</td><td>${40.6} \pm  {0.6}$</td><td>${57.4} \pm  {0.5}$</td><td>${37.7} \pm  {1.8}$</td><td>46.7</td></tr><tr><td>CDANN</td><td>${47.0} \pm  {1.9}$</td><td>${41.3} \pm  {4.8}$</td><td>${54.9} \pm  {1.7}$</td><td>${39.8} \pm  {2.3}$</td><td>45.8</td></tr><tr><td>MTL</td><td>${49.3} \pm  {1.2}$</td><td>${39.6} \pm  {6.3}$</td><td>${55.6} \pm  {1.1}$</td><td>${37.8} \pm  {0.8}$</td><td>45.6</td></tr><tr><td>SagNet</td><td>${53.0} \pm  {2.9}$</td><td>${43.0} \pm  {2.5}$</td><td>${57.9} \pm  {0.6}$</td><td>${40.4} \pm  {1.3}$</td><td>48.6</td></tr><tr><td>ARM</td><td>${49.3} \pm  {0.7}$</td><td>${38.3} \pm  {2.4}$</td><td>${55.8} \pm  {0.8}$</td><td>${38.7} \pm  {1.3}$</td><td>45.5</td></tr><tr><td>VREx</td><td>${48.2} \pm  {4.3}$</td><td>${41.7} \pm  {1.3}$</td><td>${56.8} \pm  {0.8}$</td><td>${38.7} \pm  {3.1}$</td><td>46.4</td></tr><tr><td>RSC</td><td>${50.2} \pm  {2.2}$</td><td>${39.2} \pm  {1.4}$</td><td>${56.3} \pm  {1.4}$</td><td>${40.8} \pm  {0.6}$</td><td>46.6</td></tr><tr><td>DivCAM-S</td><td>${51.6} \pm  {2.2}$</td><td>${44.4} \pm  {2.1}$</td><td>${55.2} \pm  {1.7}$</td><td>${40.7} \pm  {2.6}$</td><td>48.0</td></tr><tr><td>D-TRANSFORMERS</td><td>${53.7} \pm  {1.0}$</td><td>${29.4} \pm  {2.5}$</td><td>${53.9} \pm  {1.0}$</td><td>${34.5} \pm  {3.1}$</td><td>42.9</td></tr><tr><td>ERM*</td><td>${59.4} \pm  {0.9}$</td><td>${49.3} \pm  {0.6}$</td><td>${60.1} \pm  {1.1}$</td><td>${43.2} \pm  {0.5}$</td><td>53.0</td></tr><tr><td>IRM*</td><td>${56.5} \pm  {2.5}$</td><td>${49.8} \pm  {1.5}$</td><td>${57.1} \pm  {2.2}$</td><td>${38.6} \pm  {1.0}$</td><td>50.5</td></tr><tr><td>GroupDRO*</td><td>${60.4} \pm  {1.5}$</td><td>${48.3} \pm  {0.4}$</td><td>${58.6} \pm  {0.8}$</td><td>${42.2} \pm  {0.8}$</td><td>52.4</td></tr><tr><td>Mixup*</td><td>${67.6} \pm  {1.8}$</td><td>${51.0} \pm  {1.3}$</td><td>${59.0} \pm  {0.0}$</td><td>${40.0} \pm  {1.1}$</td><td>54.4</td></tr><tr><td>MLDG*</td><td>${59.2} \pm  {0.1}$</td><td>${49.0} \pm  {0.9}$</td><td>${58.4} \pm  {0.9}$</td><td>${41.4} \pm  {1.0}$</td><td>52.0</td></tr><tr><td>CORAL*</td><td>${60.4} \pm  {0.9}$</td><td>${47.2} \pm  {0.5}$</td><td>${59.3} \pm  {0.4}$</td><td>${44.4} \pm  {0.4}$</td><td>52.8</td></tr><tr><td>MMD*</td><td>${60.6} \pm  {1.1}$</td><td>${45.9} \pm  {0.3}$</td><td>${57.8} \pm  {0.5}$</td><td>${43.8} \pm  {1.2}$</td><td>52.0</td></tr><tr><td>DANN*</td><td>${55.2} \pm  {1.9}$</td><td>${47.0} \pm  {0.7}$</td><td>${57.2} \pm  {0.9}$</td><td>${42.9} \pm  {0.9}$</td><td>50.6</td></tr><tr><td>CDANN*</td><td>${56.3} \pm  {2.0}$</td><td>${47.1} \pm  {0.9}$</td><td>${57.2} \pm  {1.1}$</td><td>${42.4} \pm  {0.8}$</td><td>50.8</td></tr><tr><td>MTL*</td><td>${58.4} \pm  {2.1}$</td><td>${48.4} \pm  {0.8}$</td><td>${58.9} \pm  {0.6}$</td><td>${43.0} \pm  {1.3}$</td><td>52.2</td></tr><tr><td>SagNet*</td><td>${56.4} \pm  {1.9}$</td><td>${50.5} \pm  {2.3}$</td><td>${59.1} \pm  {0.5}$</td><td>${44.1} \pm  {0.6}$</td><td>52.5</td></tr><tr><td>ARM*</td><td>${60.1} \pm  {1.5}$</td><td>${48.3} \pm  {1.6}$</td><td>${55.3} \pm  {0.6}$</td><td>${40.9} \pm  {1.1}$</td><td>51.2</td></tr><tr><td>VREx*</td><td>${56.8} \pm  {1.7}$</td><td>${46.5} \pm  {0.5}$</td><td>${58.4} \pm  {0.3}$</td><td>${43.8} \pm  {0.3}$</td><td>51.4</td></tr><tr><td>RSC*</td><td>${59.9} \pm  {1.4}$</td><td>${46.7} \pm  {0.4}$</td><td>${57.8} \pm  {0.5}$</td><td>${44.3} \pm  {0.6}$</td><td>52.1</td></tr><tr><td>DivCAM-S*</td><td>${57.7} \pm  {1.1}$</td><td>${46.0} \pm  {1.3}$</td><td>${58.9} \pm  {0.4}$</td><td>${42.5} \pm  {0.7}$</td><td>51.3</td></tr><tr><td>D-TRANSFORMERS*</td><td>${59.7} \pm  {0.6}$</td><td>${51.1} \pm  {1.4}$</td><td>${56.5} \pm  {0.4}$</td><td>${42.2} \pm  {1.0}$</td><td>52.4</td></tr></table>

Table A.4: Domain specific performance for the Terra Incognita dataset using training-domain validation (top) and oracle validation denoted with * (bottom). We use a ResNet-50 backbone, optimize with ADAM, and follow the distributions specified in DOMAINBED. Only RSC and our methods have been added as part of this work, the other baselines are taken from DomAINBED.

<table><tr><td>Algorithm</td><td>clip</td><td>info</td><td>paint</td><td>quick</td><td>real</td><td>sketch</td><td>Avg.</td></tr><tr><td>ERM</td><td>${58.1} \pm  {0.3}$</td><td>${18.8} \pm  {0.3}$</td><td>${46.7} \pm  {0.3}$</td><td>${12.2} \pm  {0.4}$</td><td>${59.6} \pm  {0.1}$</td><td>${49.8} \pm  {0.4}$</td><td>40.9</td></tr><tr><td>IRM</td><td>${48.5} \pm  {2.8}$</td><td>${15.0} \pm  {1.5}$</td><td>${38.3} \pm  {4.3}$</td><td>${10.9} \pm  {0.5}$</td><td>${48.2} \pm  {5.2}$</td><td>${42.3} \pm  {3.1}$</td><td>33.9</td></tr><tr><td>GroupDRO</td><td>${47.2} \pm  {0.5}$</td><td>${17.5} \pm  {0.4}$</td><td>${33.8} \pm  {0.5}$</td><td>${9.3} \pm  {0.3}$</td><td>${51.6} \pm  {0.4}$</td><td>${40.1} \pm  {0.6}$</td><td>33.3</td></tr><tr><td>Mixup</td><td>${55.7} \pm  {0.3}$</td><td>${18.5} \pm  {0.5}$</td><td>${44.3} \pm  {0.5}$</td><td>${12.5} \pm  {0.4}$</td><td>${55.8} \pm  {0.3}$</td><td>${48.2} \pm  {0.5}$</td><td>39.2</td></tr><tr><td>MLDG</td><td>${59.1} \pm  {0.2}$</td><td>${19.1} \pm  {0.3}$</td><td>${45.8} \pm  {0.7}$</td><td>${13.4} \pm  {0.3}$</td><td>${59.6} \pm  {0.2}$</td><td>${50.2} \pm  {0.4}$</td><td>41.2</td></tr><tr><td>CORAL</td><td>${59.2} \pm  {0.1}$</td><td>${19.7} \pm  {0.2}$</td><td>${46.6} \pm  {0.3}$</td><td>${13.4} \pm  {0.4}$</td><td>${59.8} \pm  {0.2}$</td><td>${50.1} \pm  {0.6}$</td><td>41.5</td></tr><tr><td>MMD</td><td>${32.1} \pm  {13.3}$</td><td>${11.0} \pm  {4.6}$</td><td>${26.8} \pm  {11.3}$</td><td>${8.7} \pm  {2.1}$</td><td>${32.7} \pm  {13.8}$</td><td>${28.9} \pm  {11.9}$</td><td>23.4</td></tr><tr><td>DANN</td><td>${53.1} \pm  {0.2}$</td><td>${18.3} \pm  {0.1}$</td><td>${44.2} \pm  {0.7}$</td><td>${11.8} \pm  {0.1}$</td><td>${55.5} \pm  {0.4}$</td><td>${46.8} \pm  {0.6}$</td><td>38.3</td></tr><tr><td>CDANN</td><td>${54.6} \pm  {0.4}$</td><td>${17.3} \pm  {0.1}$</td><td>${43.7} \pm  {0.9}$</td><td>${12.1} \pm  {0.7}$</td><td>${56.2} \pm  {0.4}$</td><td>${45.9} \pm  {0.5}$</td><td>38.3</td></tr><tr><td>MTL</td><td>${57.9} \pm  {0.5}$</td><td>${18.5} \pm  {0.4}$</td><td>${46.0} \pm  {0.1}$</td><td>${12.5} \pm  {0.1}$</td><td>${59.5} \pm  {0.3}$</td><td>${49.2} \pm  {0.1}$</td><td>40.6</td></tr><tr><td>SagNet</td><td>${57.7} \pm  {0.3}$</td><td>${19.0} \pm  {0.2}$</td><td>${45.3} \pm  {0.3}$</td><td>${12.7} \pm  {0.5}$</td><td>${58.1} \pm  {0.5}$</td><td>${48.8} \pm  {0.2}$</td><td>40.3</td></tr><tr><td>ARM</td><td>${49.7} \pm  {0.3}$</td><td>${16.3} \pm  {0.5}$</td><td>${40.9} \pm  {1.1}$</td><td>${9.4} \pm  {0.1}$</td><td>${53.4} \pm  {0.4}$</td><td>${43.5} \pm  {0.4}$</td><td>35.5</td></tr><tr><td>VREx</td><td>${47.3} \pm  {3.5}$</td><td>${16.0} \pm  {1.5}$</td><td>${35.8} \pm  {4.6}$</td><td>${10.9} \pm  {0.3}$</td><td>${49.6} \pm  {4.9}$</td><td>${42.0} \pm  {3.0}$</td><td>33.6</td></tr><tr><td>RSC</td><td>${55.0} \pm  {1.2}$</td><td>${18.3} \pm  {0.5}$</td><td>${44.4} \pm  {0.6}$</td><td>${12.2} \pm  {0.2}$</td><td>${55.7} \pm  {0.7}$</td><td>${47.8} \pm  {0.9}$</td><td>38.9</td></tr><tr><td>DIVCAM-S</td><td>${57.7} \pm  {0.3}$</td><td>${19.3} \pm  {0.3}$</td><td>${46.8} \pm  {0.2}$</td><td>${12.7} \pm  {0.4}$</td><td>${58.9} \pm  {0.2}$</td><td>${48.5} \pm  {0.4}$</td><td>40.7</td></tr><tr><td>ERM*</td><td>${58.6} \pm  {0.3}$</td><td>${19.2} \pm  {0.2}$</td><td>${47.0} \pm  {0.3}$</td><td>${13.2} \pm  {0.2}$</td><td>${59.9} \pm  {0.3}$</td><td>${49.8} \pm  {0.4}$</td><td>41.3</td></tr><tr><td>IRM*</td><td>${40.4} \pm  {6.6}$</td><td>${12.1} \pm  {2.7}$</td><td>${31.4} \pm  {5.7}$</td><td>${9.8} \pm  {1.2}$</td><td>${37.7} \pm  {9.0}$</td><td>${36.7} \pm  {5.3}$</td><td>28.0</td></tr><tr><td>GroupDRO*</td><td>${47.2} \pm  {0.5}$</td><td>${17.5} \pm  {0.4}$</td><td>${34.2} \pm  {0.3}$</td><td>${9.2} \pm  {0.4}$</td><td>${51.9} \pm  {0.5}$</td><td>${40.1} \pm  {0.6}$</td><td>33.4</td></tr><tr><td>Mixup*</td><td>${55.6} \pm  {0.1}$</td><td>${18.7} \pm  {0.4}$</td><td>${45.1} \pm  {0.5}$</td><td>${12.8} \pm  {0.3}$</td><td>${57.6} \pm  {0.5}$</td><td>${48.2} \pm  {0.4}$</td><td>39.6</td></tr><tr><td>MLDG*</td><td>${59.3} \pm  {0.1}$</td><td>${19.6} \pm  {0.2}$</td><td>${46.8} \pm  {0.2}$</td><td>${13.4} \pm  {0.2}$</td><td>${60.1} \pm  {0.4}$</td><td>${50.4} \pm  {0.3}$</td><td>41.6</td></tr><tr><td>CORAL*</td><td>${59.2} \pm  {0.1}$</td><td>${19.9} \pm  {0.2}$</td><td>${47.4} \pm  {0.2}$</td><td>${14.0} \pm  {0.4}$</td><td>${59.8} \pm  {0.2}$</td><td>${50.4} \pm  {0.4}$</td><td>41.8</td></tr><tr><td>MMD*</td><td>${32.2} \pm  {13.3}$</td><td>${11.2} \pm  {4.5}$</td><td>${26.8} \pm  {11.3}$</td><td>${8.8} \pm  {2.2}$</td><td>${32.7} \pm  {13.8}$</td><td>${29.0} \pm  {11.8}$</td><td>23.5</td></tr><tr><td>DANN*</td><td>${53.1} \pm  {0.2}$</td><td>${18.3} \pm  {0.1}$</td><td>${44.2} \pm  {0.7}$</td><td>${11.9} \pm  {0.1}$</td><td>${55.5} \pm  {0.4}$</td><td>${46.8} \pm  {0.6}$</td><td>38.3</td></tr><tr><td>CDANN*</td><td>${54.6} \pm  {0.4}$</td><td>${17.3} \pm  {0.1}$</td><td>${44.2} \pm  {0.7}$</td><td>${12.8} \pm  {0.2}$</td><td>${56.2} \pm  {0.4}$</td><td>${45.9} \pm  {0.5}$</td><td>38.5</td></tr><tr><td>MTL*</td><td>${58.0} \pm  {0.4}$</td><td>${19.2} \pm  {0.2}$</td><td>${46.2} \pm  {0.1}$</td><td>${12.7} \pm  {0.2}$</td><td>${59.9} \pm  {0.1}$</td><td>${49.0} \pm  {0.0}$</td><td>40.8</td></tr><tr><td>SagNet*</td><td>${57.7} \pm  {0.3}$</td><td>${19.1} \pm  {0.1}$</td><td>${46.3} \pm  {0.5}$</td><td>${13.5} \pm  {0.4}$</td><td>${58.9} \pm  {0.4}$</td><td>${49.5} \pm  {0.2}$</td><td>40.8</td></tr><tr><td>ARM*</td><td>${49.6} \pm  {0.4}$</td><td>${16.5} \pm  {0.3}$</td><td>${41.5} \pm  {0.8}$</td><td>${10.8} \pm  {0.1}$</td><td>${53.5} \pm  {0.3}$</td><td>${43.9} \pm  {0.4}$</td><td>36.0</td></tr><tr><td>VREx*</td><td>${43.3} \pm  {4.5}$</td><td>${14.1} \pm  {1.8}$</td><td>${32.5} \pm  {5.0}$</td><td>${9.8} \pm  {1.1}$</td><td>${43.5} \pm  {5.6}$</td><td>${37.7} \pm  {4.5}$</td><td>30.1</td></tr><tr><td>RSC*</td><td>${55.0} \pm  {1.2}$</td><td>${18.3} \pm  {0.5}$</td><td>${44.4} \pm  {0.6}$</td><td>${12.5} \pm  {0.1}$</td><td>${55.7} \pm  {0.7}$</td><td>${47.8} \pm  {0.9}$</td><td>38.9</td></tr><tr><td>DivCAM-S*</td><td>${57.8} \pm  {0.2}$</td><td>${19.3} \pm  {0.3}$</td><td>${47.0} \pm  {0.1}$</td><td>${13.1} \pm  {0.3}$</td><td>${59.6} \pm  {0.1}$</td><td>${48.9} \pm  {0.2}$</td><td>41.0</td></tr></table>

Table A.5: Domain specific performance for the DomainNet dataset using training-domain validation (top) and oracle validation denoted with * (bottom). We use a ResNet-50 backbone, optimize with ADAM, and follow the distributions specified in DOMAINBED. Only RSC and our methods have been added as part of this work, the other baselines are taken from DOMAINBED.

## Additional distance plots

![bo_d1c3r777aajc7389qf00_76_226_672_1237_620_0.jpg](images/bo_d1c3r777aajc7389qf00_76_226_672_1237_620_0.jpg)

Figure B.1: Pairwise learned prototype ${\ell }_{2}$ -distance (top) and cosine-distance $\varrho$ (bottom) of the best-performing model with negative weight ${w}_{c, j} =  - {1.0}\forall j : {\mathbf{p}}_{j} \notin  {\mathcal{P}}_{c}$ for each testing domain. Red squares denote prototype class correspondence for the 7 different classes in the PACS dataset. No self-challenging is applied and colormap bounds are adjusted per metric for visualization purposes. First data split.

![bo_d1c3r777aajc7389qf00_77_186_272_1236_620_0.jpg](images/bo_d1c3r777aajc7389qf00_77_186_272_1236_620_0.jpg)

Figure B.2: Pairwise learned prototype ${\ell }_{2}$ -distance (top) and cosine-distance $\varrho$ (bottom) of the best-performing model with negative weight ${w}_{c, j} =  - {1.0}\forall j : {\mathbf{p}}_{j} \notin  {\mathcal{P}}_{c}$ for each testing domain. Red squares denote prototype class correspondence for the 7 different classes in the PACS dataset. No self-challenging is applied and colormap bounds are adjusted per metric for visualization purposes. Third data split.

![bo_d1c3r777aajc7389qf00_77_188_1276_1234_613_0.jpg](images/bo_d1c3r777aajc7389qf00_77_188_1276_1234_613_0.jpg)

Figure B.3: Pairwise learned prototype ${\ell }_{2}$ -distance (top) and cosine-distance $\varrho$ (bottom) of the best-performing model with negative weight ${w}_{c, j} =  - {1.0}\forall j : {\mathbf{p}}_{j} \notin  {\mathcal{P}}_{c}$ for each testing domain. Red squares denote prototype class correspondence for the 7 different classes in the PACS dataset. Self-challenging is applied and colormap bounds are adjusted per metric for visualization purposes. First data split.

![bo_d1c3r777aajc7389qf00_78_227_274_1237_615_0.jpg](images/bo_d1c3r777aajc7389qf00_78_227_274_1237_615_0.jpg)

Figure B.4: Pairwise learned prototype ${\ell }_{2}$ -distance (top) and cosine-distance $\varrho$ (bottom) of the best-performing model with negative weight ${w}_{c, j} =  - {1.0}\forall j : {\mathbf{p}}_{j} \notin  {\mathcal{P}}_{c}$ for each testing domain. Red squares denote prototype class correspondence for the 7 different classes in the PACS dataset. Self-challenging is applied and colormap bounds are adjusted per metric for visualization purposes. Third data split.

![bo_d1c3r777aajc7389qf00_78_227_1242_1236_616_0.jpg](images/bo_d1c3r777aajc7389qf00_78_227_1242_1236_616_0.jpg)

Figure B.5: Pairwise learned prototype ${\ell }_{2}$ -distance (top) and cosine-distance $\varrho$ (bottom) of the best-performing model with negative weight ${w}_{c, j} = {0.0}\forall j : {\mathbf{p}}_{j} \notin  {\mathcal{P}}_{c}$ for each testing domain. Red squares denote prototype class correspondence for the 7 different classes in the PACS dataset. No self-challenging is applied and colormap bounds are adjusted per metric for visualization purposes. First data split.

![bo_d1c3r777aajc7389qf00_79_186_265_1236_619_0.jpg](images/bo_d1c3r777aajc7389qf00_79_186_265_1236_619_0.jpg)

Figure B.6: Pairwise learned prototype ${\ell }_{2}$ -distance (top) and cosine-distance $\varrho$ (bottom) of the best-performing model with negative weight ${w}_{c, j} = {0.0}\forall j : {\mathbf{p}}_{j} \notin  {\mathcal{P}}_{c}$ for each testing domain. Red squares denote prototype class correspondence for the 7 different classes in the PACS dataset. No self-challenging is applied and colormap bounds are adjusted per metric for visualization purposes. Second data split.

![bo_d1c3r777aajc7389qf00_79_188_1251_1234_615_0.jpg](images/bo_d1c3r777aajc7389qf00_79_188_1251_1234_615_0.jpg)

Figure B.7: Pairwise learned prototype ${\ell }_{2}$ -distance (top) and cosine-distance $\varrho$ (bottom) of the best-performing model with negative weight ${w}_{c, j} = {0.0}\forall j : {\mathbf{p}}_{j} \notin  {\mathcal{P}}_{c}$ for each testing domain. Red squares denote prototype class correspondence for the 7 different classes in the PACS dataset. No self-challenging is applied and colormap bounds are adjusted per metric for visualization purposes. Third data split.

![bo_d1c3r777aajc7389qf00_80_226_281_1237_617_0.jpg](images/bo_d1c3r777aajc7389qf00_80_226_281_1237_617_0.jpg)

Figure B.8: Pairwise learned prototype ${\ell }_{2}$ -distance (top) and cosine-distance $\varrho$ (bottom) of the best-performing model with negative weight ${w}_{c, j} = {0.0}\forall j : {\mathbf{p}}_{j} \notin  {\mathcal{P}}_{c}$ for each testing domain. Red squares denote prototype class correspondence for the 7 different classes in the PACS dataset. Self-challenging is applied and colormap bounds are adjusted per metric for visualization purposes. First data split.

![bo_d1c3r777aajc7389qf00_80_226_1267_1238_616_0.jpg](images/bo_d1c3r777aajc7389qf00_80_226_1267_1238_616_0.jpg)

Figure B.9: Pairwise learned prototype ${\ell }_{2}$ -distance (top) and cosine-distance $\varrho$ (bottom) of the best-performing model with negative weight ${w}_{c, j} = {0.0}\forall j : {\mathbf{p}}_{j} \notin  {\mathcal{P}}_{c}$ for each testing domain. Red squares denote prototype class correspondence for the 7 different classes in the PACS dataset. Self-challenging is applied and colormap bounds are adjusted per metric for visualization purposes. Second data split.

![bo_d1c3r777aajc7389qf00_81_186_757_1239_619_0.jpg](images/bo_d1c3r777aajc7389qf00_81_186_757_1239_619_0.jpg)

Figure B.10: Pairwise learned prototype ${\ell }_{2}$ -distance (top) and cosine-distance $\varrho$ (bottom) of the best-performing model with negative weight ${w}_{c, j} = {0.0}\forall j : {\mathbf{p}}_{j} \notin  {\mathcal{P}}_{c}$ for each testing domain. Red squares denote prototype class correspondence for the 7 different classes in the PACS dataset. Self-challenging is applied and colormap bounds are adjusted per metric for visualization purposes. Third data split.

