# Adversarial attacks and defenses for large language models (LLMs): methods, frameworks & challenges

Pranjal Kumar1 Received: 22 December 2023 / Revised: 13 May 2024 / Accepted: 22 May 2024 / Published online: 25 June 2024 © The Author(s), under exclusive licence to Springer-Verlag London Ltd., part of Springer Nature 2024

## Abstract

Large language models (LLMs) have exhibited remarkable efficacy and proficiency in a wide array of NLP endeavors. Nevertheless, concerns are growing rapidly regarding the security and vulnerabilities linked to the adoption and incorporation of LLM. In this work, a systematic study focused on the most up-to-date attack and defense frameworks for the LLM is presented. This work delves into the intricate landscape of adversarial attacks on language models (LMs) and presents a thorough problem formulation. It covers a spectrum of attack enhancement techniques and also addresses methods for strengthening LLMs. This study also highlights challenges in the field, such as the assessment of offensive or defensive performance, defense and attack transferability, high computational requirements, embedding space size, and perturbation. This survey encompasses more than 200 recent papers concerning adversarial attacks and techniques. By synthesizing a broad array of attack techniques, defenses, and challenges, this paper contributes to the ongoing discourse on securing LM against adversarial threats.

Keywords Adversarial attacks - Artificial intelligence - Natural language processing - Machine learning - Neural networks - Large language models - ChatGPT - GPT

## 1 Introduction

Advancements in deep learning have been observed across various domains, such as language translation [1] and speech recognition (SR) [2]. The integration of hardware acceleration and algorithmic enhancements has significantly broadened the scope of novel systems and applications facilitated by deep learning. Intelligent voice assistants have become ingrained in daily routines. Safety-critical cyber physical ystems (SCCPS) [3], exemplified by face recognition systems [4] and autonomous driving systems [5], have experienced substantial improvements due to deep learning methodologies. However, the security aspects of many deep learning-enabled applications have been inadequately addressed. SCCPS comprise three primary components: the network layer, the perception layer, and the control layer. The perception layer encompasses sensors, controllers, and data collectors. Sensors within the perception layer serve as terminal equipment, continuously relaying data and information gathered from the environment to the server. Ensuring data security is paramount for the smooth operation of SCCPS. Nevertheless, research has revealed that even sophisticated deep neural networks (DNNs) [6] can be deceived by subtle alterations, as highlighted by authors in [7]. Adversarial examples, characterized by intentional mislabeling and difficulty in detection, underscore the "Black Box" nature of deep learning, wherein while it excels in various domains, its comprehension of decision-making processes remains limited. In the context of a LLM, an adversarial example is an input that has been purposefully constructed to trick the model into making a mistake or producing an unexpected output. It is possible to test the model's robustness and discover potential weaknesses by using adversarial examples, which take advantage of the model's vulnerabilities or limitations in terms of its understanding.

There is growing evidence that machine learning (ML) models $\left\lbrack  {8,9}\right\rbrack$ may be susceptible to exploitation through attacks involving manipulation of input data with the aim of causing misclassification of a target. The susceptibility of ML/DL models to such attacks stems primarily from their adaptability. While the extent of vulnerability varies among different ML/DL models, generally, they are all susceptible. To exemplify, consider a ML or DL model or system that initially provides accurate classifications when presented with a specific set of inputs based on its training data. However, a malicious entity could potentially create input data that leads the model to misclassify test instances [10]. Various methods, such as fast-gradient-sign methods [11], basic iterative methods [12], one-step target-class methods [13], iterative least-likely-class methods [14], among others, can be employed to generate artificial input data, known as adversarial examples. Each method presents distinct advantages and disadvantages when utilized in real attacks [15]. For instance, the fast gradient symbol method (FGSM) [16] offers ease of use in generating adversarial examples, yet its success rate is lower compared to alternative approaches, including drastically lower success rates than similar methods.

---

☑ Pranjal Kumar

pranjal@nith.ac.in

1 Department of Intelligent Systems, School of Computer Science and Engineering, Lovely Professional University, Phagwara, Punjab 144411, India

---

The popularity of constructing LLMs has surged to cope with the increasing complexity and diversity of language tasks. Trained on extensive corpora, LLMs acquire representations for multiple languages. Consequently, they can be readily applied to various downstream natural language processing (NLP) [17] tasks, such as named entity recognition [18], question answering [19], and text classification [20], requiring only minimal fine-tuning on task-specific data [21]. This approach significantly reduces the time and effort compared to building models from scratch. A plethora of LLMs, including GPT and its variations [22] and BERT and its variants [23], have been developed to cater to the needs of both the NLP research community and the commercial sector. These models are publicly available [24].

New vulnerabilities are emerging in NLP applications [25-27] due to the development of new pre-training methodologies. Firstly, the enhanced transferability of language model (LM) increases the likelihood of potential attacks [28]. Due to the similarity between models, strategies effective against one model are likely to be effective against others, enabling attackers to exploit black-box models [29, 30]. Conversely, the high transferability of language representations in LM facilitates persistent threats during fine-tuning and enhances downstream model performance [25, 31], allowing malevolent actors to embed concealed access points that remain effective across subsequent models. Secondly, downstream models stemming from the same LM often exhibit similar language representation features, rendering LM systems particularly susceptible to attacks. The expanded pipeline for LM model development and deployment introduces additional entities and steps, enlarging potential vulnerability points. A model publisher (MP) [32] is responsible for creating and disseminating learning and teaching materials. If an individual harbors malicious intent, they can manipulate model parameters, potentially causing significant harm to subsequent models inheriting from it. Detecting and rectifying malicious LLMs can be challenging.

Furthermore, LLM systems are susceptible to the same threats and attacks as standalone models [33, 34].

### 1.1 Contribution

The research community has directed significant attention towards the phenomenon of adversarial attacks, along with their corresponding defense mechanisms, over the preceding five years due to its critical significance $\left\lbrack  {{33},{35}}\right\rbrack$ . Through the analysis of adversarial examples, a deeper comprehension of the architecture and vulnerabilities of neural networks can be attained, facilitating the fortification of their defenses. Since the proposition by Jia and Liang [36], numerous methods for generating perturbations have been put forth. Minor alterations to the input of a LLM are referred to as perturbations, which have the potential to result in an erroneous prediction being generated by the LLM. Despite the interest expressed by the NLP community, insufficient research has been conducted in this domain owing to the absence of a systematic and comprehensive approach to classification [37]. This study presents an overview of the challenges associated with both defending against and launching attacks on LLMs within an adversarial framework. Additionally, it proposes a taxonomy for categorizing and structuring these techniques. This paper stands as the inaugural systematic examination of the threats and vulnerabilities faced by LLMs from adversarial entities, scrutinizing the existing body of knowledge across three dimensions: (1) types of attacks, (2) targeted components within LLMs, and (3) preventative measures. Attention to these three areas is imperative in addressing adversarial attacks on LLMs. Subsequently, the paper explores potential future challenges in mitigating such attacks. The contributions of this work include:

- An overview and background of adversarial attacks are presented in order to make the frontier ideas more understandable.

- It provides a systematic analysis of the causes of adversarial attacks along with a methodical description of various techniques incorporated.

- A review of major enhancements in attack techniques along with the various methods for strengthening LLMs is presented.

- The future of preventing these attacks is discussed, and a number of open issues have been analyzed.

### 1.2 Organisation of paper

The paper is organized as follows: Sect. 2 thoroughly defines the problem, while Sect. 3 explores the methodologies and essential components necessary for incorporating adversarial examples into LLMs. The paper's overall taxonomy is depicted in Fig. 1. Subsequently, Sect. 4 critically evaluates various techniques prevalent in the literature for enhancing attack methods. Section 5 examines relevant research methodologies for fortifying LLM frameworks against attacks. The concluding section addresses contentious issues and their potential future evolution, thereby concluding the discussion.

![bo_d1m00jf7aajc73dif19g_2_191_156_616_887_0.jpg](images/bo_d1m00jf7aajc73dif19g_2_191_156_616_887_0.jpg)

Fig. 1 Taxonomy of this review

### 1.3 Related work

Adversarial examples have been a focal point of research alongside the advancement of deep learning. Prior to this, researchers in [15] and [38] provided an overview of the existing research on adversarial examples in computer vision (CV) [39], proposed a taxonomy for categorizing methods used to generate adversarial examples, and examined recent discoveries in this domain. As deep learning continues to evolve, research on adversarial examples is extending beyond the domain of CV. Researchers in both [40] and [41] have extensively studied adversarial attacks in speech recognition and adversarial examples in NLP, respectively. Given the prevalence of adversarial attacks, comprehensive examination have become imperative.

Previous studies on passive and adversarial attacks against speaker recognition systems (SRS) [2]and their associated defense strategies were summarized by Rohan et al. [42]; however, existing classification standards could not comprehensively classify all these attacks and defenses. Authors in [43] categorized adversarial attack and defense methods for speech recognition models and SRSs based on attack target, attack type, adversarial knowledge, and adversarial capabilities, although SRSs were not specifically addressed. To enhance understanding of defense and attack strategies for voice processing systems, authors in [44] categorized various types of adversarial attacks currently employed against speech recognition systems. Additionally, researchers in [45] conducted a detailed examination of major adversarial attacks on diverse deep learning models for NLP, with a specific focus on techniques for generating adversarial textual examples. Xu et al. [46] reviewed methods used in adversarial attacks and defenses for models analyzing images, graphs, and texts.

## 2 Adversarial attacks: problem formulation

Attackers have the ability to deceive a target ML/DL model by supplying it with adversarial examples as inputs. These examples are artificially constructed to mislead the model into producing inaccurate predictions [47]. In a landscape where ML/DL systems are prevalent, even a solitary exploitative example can yield significant repercussions for both the model and the employing organization or program. To make LLMs more resistant to such attacks, adversarial training is employed. The objective of an adversarial attack on a LLM is to manipulate its output by introducing subtle modifications to the input text [48]. The LLM is trained using both real and adversarial examples in adversarial training. The authentic examples are the unaltered versions of the input texts, while the adversarial examples are the manipulated versions [49]. Adversarial training serves as a countermeasure against such input attacks. This entails incorporating novel and challenging instances into the model's training dataset. By exposing the model to these adversarial examples during training, it becomes equipped to handle analogous inputs in the future. Combining multiple models into a unified one can also fortify a ML model against attacks [33]. These models may originate from distinct datasets, dataset subsets, features, or model configurations. Research has shown that employing ensemble training enhances the model's resilience to both black-box and white-box attacks [50]. A black-box attack is an adversarial attack that seeks to take advantage of flaws in the model's behavior without knowing its internal architecture, parameters, or training data. This means the attacker has no idea how the model arrives at its predictions and instead treats it as a "black box" system in which they can only feed in text and see the results. In a white-box attack scenario, the adversary possesses comprehensive knowledge regarding the LLM, encompassing its design, tuning parameters, and instructional data. This knowledge empowers the adversary to create malevolent inputs specifically tailored to exploit vulnerabilities in the LLM. Adversarial examples excel in transferability, as they can often be transferred from one model to another [51]. Consequently, adversarial examples crafted and assessed by malicious entities can be utilized against other models, irrespective of their originator. Managing or defending against transferred attacks proves to be challenging; nevertheless, ensemble training has been shown to be an effective strategy in bolstering resistance against such attacks. The continuous evolution of new attack types in a black-box scenario demonstrates an ongoing "arms race" between ML defenders and attackers [8]. ML/DL defense strategies primarily fall into two categories: reactive and proactive. The difficulty in discerning adversarial examples poses a significant obstacle to the security of ML systems, particularly neural networks, as evidenced by experiments demonstrating their susceptibility to being deceived [52]. Moreover, there is no straightforward method for distinguishing between malicious and legitimate examples. Consequently, it can be inferred that existing security measures are insufficient in mitigating future threats. Effective defenses against adversarial attacks must be developed before the integration of ML/DL into security applications can be confidently pursued.

Word embeddings, such as Glove [53], which lack strict semantic and grammatical coherence, have been employed in recent successful attacks on LM systems to manipulate characters and substitute words with synonyms [54]. While the perturbations $\left\lbrack  {{55},{56}}\right\rbrack$ devised by researchers in [57] utilize LMs to assess the outcomes of their iterative search for semantically similar words in the embedding space [58], these outcomes remain devoid of contextual awareness and heavily rely on cosine similarity measurements of word embeddings. The semantic consistency of the perturbations is compromised due to the lack of assurance in Glove embeddings to maintain a consistent vector space with cosine similarity distances. The context-aware semantically enhanced embedding [58] utilized by researchers in [53] is less reliable compared to the unaltered inputs. Phrase-level insertions and deletions, as employed by researchers in [59], yield nonsensical and inconsistent sentences. Researchers in [60] disrupt the language inference system [61] by manually substituting words to uphold semantic coherence. To mitigate against automated reading comprehension systems, researchers in [36] propose a series of manually crafted countermeasures. Strategies for word replacement based on embedding transitions are introduced by researchers in [62]. The following is a generic description of an adversarial attack on LLMs:

### 2.1 Transformation module

Let the original input sequence be denoted as $\mathbf{x} = \left( {{x}_{1},{x}_{2},\ldots ,{x}_{M}}\right)$ . The transformation module generates potential transformations using a function $T$ such that:

$$
T\left( \mathbf{x}\right)  = \left\{  {{t}_{1},{t}_{2},\ldots ,{t}_{N}}\right\}
$$

where each ${t}_{n}$ is a perturbed version of the input sequence, possibly involving character, word, or sentence-level modifications. In the context of LLMs, the transformation module takes the original input sequence $\mathbf{x}$ , which can be a sequence of characters, words, or sentences [63]. This module aims to generate various potential transformations of the input to create adversarial examples [64]. Each potential transformation ${t}_{n}$ is a modified version of the input sequence, and there could be multiple such transformations.

### 2.2 Constraint filtering

The transformation set $T\left( \mathbf{x}\right)$ undergoes constraint filtering using a constraint function $C$ :

$C\left( {t}_{n}\right)  =$ True if ${t}_{n}$ satisfies constraints, otherwise False

The filtered set of potential transformations is given by:

$$
{T}_{\text{filtered }}\left( \mathbf{x}\right)  = \left\{  {{t}_{n} \mid  {t}_{n} \in  T\left( \mathbf{x}\right) , C\left( {t}_{n}\right)  = \text{ True }}\right\}
$$

After generating potential transformations, it's important to ensure that these transformations are valid and maintain certain linguistic and semantic properties. This is where constraint filtering comes into play. The constraint function $C\left( {t}_{n}\right)$ evaluates whether a given transformation ${t}_{n}$ satisfies predefined constraints [65]. These constraints might include requirements like maintaining grammatical correctness, semantic coherence, or length restrictions [66]. The filtered set ${T}_{\text{filtered }}\left( \mathbf{x}\right)$ contains only those potential transformations that meet the specified constraints.

### 2.3 Search module

The search module interacts with the LLM by sending perturbed sequences ${\mathbf{x}}_{\text{adv }}$ to the model. It aims to find perturbations that lead to different model predictions. This process can be represented as:

$$
{\mathbf{x}}_{\text{adv }} = {T}_{\text{filtered }}\left( \mathbf{x}\right) \left\lbrack  i\right\rbrack
$$

where $i$ denotes the index of the perturbation in the filtered set. The search module is responsible for selecting and testing potential adversarial examples on the LLM. From the filtered set of potential transformations ${T}_{\text{filtered }}\left( \mathbf{x}\right)$ , one transformation is selected, denoted by ${\mathbf{x}}_{\text{adv }}$ . This perturbed sequence is then passed to the LLM to observe how it affects the model's predictions $\left\lbrack  {{64},{67}}\right\rbrack$ . The module iteratively performs this process, aiming to find perturbations that lead to different model predictions compared to the original input.

### 2.4 Goal function $G$

The goal function $G$ evaluates the success of the attack based on the classification results. In an untargeted attack, where the goal is to misclassify the input:

$$
{G}_{\text{untargeted }}\left( {\mathbf{x},{\mathbf{x}}_{\text{adv }}}\right)  = \left\{  \begin{array}{ll} 1 & \text{ if }F\left( {\mathbf{x}}_{\text{adv }}\right)  \neq  F\left( \mathbf{x}\right) \\  0 & \text{ otherwise } \end{array}\right.
$$

For a targeted attack, the goal is to manipulate the model in such a way that it predicts a specific target label, denoted as ${y}_{\text{target }}$ :

$$
{G}_{\text{targeted }}\left( {\mathbf{x},{\mathbf{x}}_{\text{adv }}}\right)  = \left\{  \begin{array}{ll} 1 & \text{ if }F\left( {\mathbf{x}}_{\text{adv }}\right)  = {y}_{\text{target }} \\  0 & \text{ otherwise } \end{array}\right.
$$

Here, $F\left( \mathbf{x}\right)$ represents the prediction of the LLM on input $\mathbf{x}$ , and ${y}_{\text{target }}$ is a predefined label (target) that is different from available ground-truth label $y$ . The goal function $G$ evaluates whether the attack is successful based on the LLM's predictions $\left\lbrack  {{68},{69}}\right\rbrack$ . In an untargeted attack scenario, the goal is to create confusion and misclassify the input. The function ${G}_{\text{untargeted }}$ checks if the LLM’s prediction for the perturbed sequence ${\mathbf{x}}_{\text{adv }}$ is different from its prediction for the original input $\mathbf{x}$ . If the LLM’s predictions differ, the attack is successful, and ${G}_{\text{untargeted }}$ returns 1; otherwise, it returns 0 . In a targeted attack scenario, the aim is to guide the LLM's prediction towards a specific target label ${y}_{\text{target }}$ . The function ${G}_{\text{targeted }}$ checks whether the LLM’s prediction for ${\mathbf{x}}_{\text{adv }}$ matches the target label ${y}_{\text{target }}$ .

If the LLM accurately forecasts the intended label, the assault is deemed effective, and ${G}_{\text{targeted }}$ outputs 1 ; otherwise, it outputs 0 . In summary, this sequence of activities-transformation, constraint filtering, interaction with the LLM, and goal assessment-constitutes a methodical procedure for generating adversarial instances, which can uncover vulnerabilities and aid in enhancing the LLM's resilience against potential attacks.

Based on the attacker's familiarity level with the target LLM model, adversarial attack strategies can be categorized as either "white-box" or "black-box [70]". An adversary is a model or agent that attempts to trick the LLM into making a mistake. One way to trick an LLM into making a mistaken classification is to feed it false or misleading data, or to generate adversarial examples. In a "black-box" attack, the adversary lacks visibility into the internal workings of the LLM model, including its architecture, parameters, activation functions, loss function, and training data. Conversely, a white-box attack grants the attacker full access to all the aforementioned components [71]. Depending on the attack specifics, adversaries may execute character-level or word-level attacks. For instance, HotFlip [72] exemplifies a white-box attack method leveraging directional derivatives of the target LLM model concerning the input vector to substitute one token (e.g., character or word) for another. To deceive the LLM model, it initially predicts the most impactful change to the input and subsequently employs a beam search strategy to identify the optimal combination of alterations. On the other hand, the black-box adversarial attacker DeepWordBug [56] employs four scoring functions to identify relevant input tokens, as depicted in Fig. 2. It alters critical tokens to manipulate the LLM model into reaching incorrect conclusions. TextBugger [55] supports both white-box and black-box attacks. In the white-box scenario, the attacker computes the model's gradients by evaluating the Jacobian matrix of the LLM model concerning the input text [73]. Subsequently, the program generates five distinct alterations to pivotal words and selects the one resulting in the most significant confidence shift. This method of attack introduces spurious adversaries by introducing typographical errors into the input. Examples of character-level issues include insertions, deletions, swaps, and replacements.

## 3 Methodologies & prerequisites

The utilization of LLMs has become a prevalent approach in numerous NLP endeavors. Recent literature has examined these LLMs from diverse angles [53, 74, 75]. Ethical concerns pertaining to the knowledge assimilated by LLMs have been scrutinized by researchers [74]. This section, built upon prior studies, explores the techniques and assets crucial for integrating adversarial examples into LLMs.

### 3.1 Detecting vulnerable words

In the black-box setting, the logit produced by the objective model is the only form of guidance available [70]. It begins with a sequence $S$ based selection of words that will have the greatest impact on the final logit output ${o}_{y}\left( S\right)$ . The goal is to understand the impact of particular words in the input sentence on the model's predictions and to modify its behavior accordingly. The process commences by computing the significance score ${I}_{{w}_{i}}$ for every word ${w}_{i}$ in the given sentence. The importance score measures the impact of removing a specific word on the model's prediction. The importance score is defined as the difference between the logit output for the original sentence $S$ and the logit output when the word ${w}_{i}$ is replaced with a $\left\lbrack  {MASK}\right\rbrack$ token:

$$
{I}_{{w}_{i}} = {o}_{y}\left( S\right)  - {o}_{y}\left( {S \smallsetminus  {w}_{i}}\right) ,
$$

![bo_d1m00jf7aajc73dif19g_5_147_166_1463_827_0.jpg](images/bo_d1m00jf7aajc73dif19g_5_147_166_1463_827_0.jpg)

Fig. 2 Broad overview of the pipeline for adversarial attacks on LLMs

![bo_d1m00jf7aajc73dif19g_5_154_1110_692_422_0.jpg](images/bo_d1m00jf7aajc73dif19g_5_154_1110_692_422_0.jpg)

Fig. 3 An illustrative instance of an adversarial sequence generated by DeepWordBug [56]

where $S \smallsetminus  {w}_{i}$ represents the sentence with the word ${w}_{i}$ removed and replaced by $\left\lbrack  {MASK}\right\rbrack$ . After computing the importance scores for all words in the sentence, then it's proceeded to rank the words based on these scores. This ranking produces a word list $L$ , ordered in descending order of importance scores. The idea is that words with higher importance scores are more influential in shaping the model's predictions [76]. Out of this ranked word list $L$ , then it is decide to select only a fraction of the most important words, typically denoted as $\varepsilon$ , to minimize the perturbations introduced while still impacting the model's behavior.

This choice of $\varepsilon$ percent ensures that methodologies focus on the most influential words while maintaining some degree of sentence coherence. The objective is to alter the behavior of the model by implementing semantically consistent modifications to the designated significant terms. Through manipulation of these vulnerable lexical elements, adversaries can compel the model to produce predictions that deviate further from the norm [45]. This approach capitalizes on the susceptibility of specific words to impact the model's predictions. Analogous techniques are employed in the domain of image processing to infer the impact of altering pixel values on the model's predictions, paralleling this methodology [77]. In textual contexts, a comparable approach involves identifying pivotal terms using importance scores and subsequently modifying them strategically to influence the predictions of the neural model.

### 3.2 Adversarial word substitution (AWS)

One of the most efficacious approaches for compromising intricate neural architectures such as LLMs is AWS [73]. To induce misclassification in the target model, an AWS attacker strategically substitutes specific words with their synonyms. Moreover, a proficient adversarial instance maintains grammatical correctness and semantic coherence. The attacker must first identify tokens vulnerable to perturbation and then opt for appropriate synonyms for substitution, aiming to construct effective and high-fidelity adversarial samples. AWS entails the manipulation of natural language text by strategically replacing words to mislead or confound ML models, particularly those deployed in NLP tasks [78]. This method capitalizes on the sensitivity of these models to alterations in input data, thereby inducing erroneous predictions or classifications. Original text as a sequence of words is denoted as $X = \left\{  {{x}_{1},{x}_{2},\ldots ,{x}_{n}}\right\}$ , and $f$ represent the ML model in question. The objective of the attacker is to find a perturbed text ${X}^{\prime }$ by substituting certain words such that $f\left( {X}^{\prime }\right)$ results in a desired outcome for the attacker while still being contextually plausible to a human observer. This can be formulated as an optimization problem:

$$
{X}^{\prime } = \arg \mathop{\max }\limits_{{X}^{\prime }}\left\lbrack  {\log P\left( {Y = y \mid  {X}^{\prime }}\right)  - \lambda  \cdot  \operatorname{similarity}\left( {X,{X}^{\prime }}\right) }\right\rbrack
$$

![bo_d1m00jf7aajc73dif19g_6_146_157_701_346_0.jpg](images/bo_d1m00jf7aajc73dif19g_6_146_157_701_346_0.jpg)

Fig. 4 Conceptual representation of the word recognition system comprising of both a foreground and a background model [75]

where $P\left( {Y = y \mid  {X}^{\prime }}\right)$ defines the probability of the model assigned to the desired outcome $y$ , given the perturbed text ${X}^{\prime }$ , and similarity $\left( {X,{X}^{\prime }}\right)$ quantifies the similarity between the original text $X$ and the perturbed text ${X}^{\prime }$ to ensure that the substitution remains contextually coherent. The parameter $\lambda$ strikes a balance between getting the job done and letting the text sound natural. The goal of AWS is to bypass defenses built into models and find weaknesses in the underlying ML infrastructure by employing techniques like synonym replacement, antonym insertion, and other linguistically motivated manipulations.

### 3.3 Sentence-level attacks

These attacks involve the construction of antagonistic sentences that effectively utilize sentence structures, contexts, and other elements rather than simple word substitution. In the study by Lin et al. [80], MRC models were targeted with examples generated from irrelevant sentences. T3, as proposed by Wang et al. [79], is an adversarial attack framework capable of targeting specific models, as depicted in Fig. 4. The optimization of perturbation addition to the ROOT embedding ensures the success of targeted attacks while minimizing perturbation magnitude. T3 enhances adversarial perturbations by utilizing a tree-based autoencoder to transform discrete text data into a continuous representation space. The tree-based decoder generates adversarial examples directly from source sentences, ensuring syntactic correctness. This type of attack can also generate adversarial examples at the word level. Gan et al. [81] devised two test sets to evaluate the resilience of QA models to question paraphrasing. These sets contain rewritten versions of original SQuAD questions generated by a neural paraphrasing model. To comprehensively assess the vulnerabilities of LLMs, Zhang et al. [82] introduced the PAWS paraphrase dataset, consisting of pairs of carefully constructed paraphrases and non-paraphrases demonstrating significant lexical similarity.

### 3.4 Targeted attacks

During these instances of intrusion, the adversarial MP is already familiar with the target downstream tasks. Consequently, the designer manufactures LLMs containing covert backdoors to execute said operations. To conduct backdoor attacks on pre-trained autoencoding models, the approach introduced by Kurita et al. [83] employs a method termed RIPPLe. This method utilizes a regularization technique and implements embedding surgery to penetrate the vulnerabilities in LLM weights. Specifically, when an attacker selects a trigger, its embedding is substituted with words associated with the target trigger label. This results in an embedding distribution of trigger words that resembles the statistical average. However, due to the uncommon nature of the triggers in RIPPLe, the resultant sentences exhibit an artificial quality, rendering them more conspicuous. To mitigate this issue, Han et al. [84] proposed employing trigger sentences generated by context-aware generative models to "trojan" LLMs and activate them in subsequent tasks. To enhance the clandestinity of the attack and diminish the adversary's capacity to anticipate it, the trigger is formed by amalgamating common terms rather than utilizing a single uncommon term.

### 3.5 Masked language model (MLM)

The generation of adversarial examples consists of two consecutive components: a MLM defined by its parameters $\theta$ , which offers a conditional distribution ${p}_{\theta }\left( {{x}_{0} \mid  x}\right)$ for an input sequence $x$ , and a sampler that generates new sequences ${x}_{0}$ from this distribution. This implies that we can create sequences ${x}_{0}$ by iteratively using both the MLM and the sampler. While a pre-trained MLM can be utilised for the generation of potential adversarial sequences, enhancing the efficiency of the sampling process involves optimizing the MLM’s parameters $\theta$ based on a differentiable loss function. This function is designed to guide the MLM towards generating adversarial examples that are semantically similar but capable of deceiving ML models [85]. The loss function comprises two primary components. The initial component is a surrogate classifier $C\left( {x}_{0}\right)$ that assigns a probability $\left( {P}_{\text{target }}\right)$ to the generated sequence ${x}_{0}$ being a member of a specific target class, as shown below:

$$
{L}_{\text{substitute }} =  - \log {P}_{\text{target }}\left( {C\left( {x}_{0}\right) }\right)
$$

![bo_d1m00jf7aajc73dif19g_7_144_155_1449_373_0.jpg](images/bo_d1m00jf7aajc73dif19g_7_144_155_1449_373_0.jpg)

Adversarial Seed: [Donald Trump] ended the series in 1989. Adversarial Sentence: [Donald Trump] ends a program on 1988.

Fig. 5 A case where the adversarial sentence is generated by T3(SENT) [79]

The second term includes a Deep Levenshtein distance ${DL}\left( {x,{x}_{0}}\right)$ , which is a metric that estimates the edit distance between two sequences, specifically the original sequence $x$ and the adversarial sequence ${x}_{0}$ . The approximation is defined as:

$$
{L}_{\text{Levenshtein }} = {DL}\left( {x,{x}_{0}}\right)
$$

Through the minimization of this composite loss function, the intention is to achieve two goals: firstly, to achieve low scores from a substitute classifier, thus effectively misleading the underlying model, and secondly, to maintain semantic similarity by minimizing an approximation of the Levenshtein distance [86] between the original and adversarial sequences. This process of controlled loss minimization guides the generation of adversarial examples that are both linguistically plausible and strategically manipulative for targeted model misclassification [87]. The overall loss function can be formulated as:

$$
{L}_{\text{total }} = {\lambda }_{1} \cdot  {L}_{\text{substitute }} + {\lambda }_{2} \cdot  {L}_{\text{Levenshtein }}
$$

where ${\lambda }_{1}$ and ${\lambda }_{2}$ are hyperparameters that control the tradeoff between the two objectives. By finding the optimal parameters $\theta$ that minimize ${L}_{\text{total }}$ , the MLM can generate adversarial examples that achieve the desired balance between semantic similarity and effectiveness in misleading ML models.

### 3.6 Syntactic-based perturbation

It is an adversarial manipulation targeting LLMs with an emphasis on their syntactic comprehension and prediction capabilities. The aim of this attack is to disrupt the LLM's capacity to accurately parse and understand the syntactic structure of sentences by manipulating the input text in a specific manner [88]. Through subtle alterations to the syntax, the attacker can deceive the LLM into generating invalid or incomprehensible outputs. This technique exploits the LLM's susceptibility to syntactic variations, highlighting its vulnerability to even minor changes in word order.The set $X$ is defined as $\left\{  {{x}_{1},{x}_{2},\ldots ,{x}_{n}}\right\}$ , where each ${x}_{i}$ corresponds to the $i$ -th word in the original input sentence. The attacker's goal is to discover a modified sentence (X) that, when inputted into the LLM, results in the intended outcome. The attack can be formulated as an optimization problem, seeking ${X}^{\prime }$ that maximizes the likelihood of generating a target output $Y$ :

$$
{X}^{\prime } = \arg \mathop{\max }\limits_{{X}^{\prime }}\log P\left( {Y \mid  {X}^{\prime }}\right)
$$

Aside from trying to find the value of ${X}^{\prime }$ that maximizes the target likelihood, an attacker's goal is to introduce subtle syntactic changes that the LLM is overly sensitive to, causing it to make inaccurate predictions. This can be accomplished by inserting syntactic perturbations that keep the LLM's parsing mechanisms guessing while maintaining semantic plausibility [88]. A syntactic perturbation that involves swapping the positions of two words in the sentence: ${x}_{i}$ and ${x}_{j}$ . The attack is formulated as shown below:

$$
{X}^{\prime } = \arg \max \log P\left( {Y \mid  {X}^{\prime }}\right)  - \lambda  \cdot  \operatorname{similarity}\left( {X,{X}^{\prime }}\right) ,
$$

where $P\left( {Y \mid  {X}^{\prime }}\right)$ denotes the probability of generating the target output $Y$ given the perturbed sentence ${X}^{\prime }$ , and similarity $\left( {X,{X}^{\prime }}\right)$ measures the degree of syntactic resemblance between the original sentence $X$ and the altered sentence ${X}^{\prime }$ . The parameter $\lambda$ determines the trade-off between achieving the desired target output and preserving syntactic plausibility. There is a tradeoff between preserving sentence structure and making precise predictions, which is exposed by syntactic-based perturbation attacks on LLMs. The prevalence of these attacks highlights the need for more robust models in NLP tasks to withstand manipulation from adversaries [88].

### 3.7 Task-agnostic attacks

None of the aforementioned attacks are viable due to the necessity for the adversary to possess awareness of the precise downstream tasks to be targeted, and the compromised LM lacking the capability to generalize its knowledge to novel scenarios [9]. Researchers have formulated task-agnostic attacks to bypass this limitation, facilitating the dissemination of embedded backdoors to any subsequent models reliant on the compromised LM. To exploit autoen-coding models that have been previously trained without prior knowledge of downstream tasks, Chen et al. introduced BadPre [25]. The contaminated dataset for backdoor embedding is generated by substituting trigger word labels with randomly chosen words from a clean corpus. A method with low computational overhead for circumventing the detection of contemporary backdoors is outlined by researchers in [90]. During the pre-training stage, the authors of [91] introduced a neuron-level backdoor attack (NeuBA) by establishing associations between triggers and desired values of output representations. NeuBA demonstrates significant efficacy in carrying out attacks and can be seamlessly integrated into pre-existing autoencoding models. Additionally, its influence on the performance of untainted data is minimal. The authors in [31] introduce a method aimed at maintaining the backdoor functionality across various downstream fine-tuning tasks. This is achieved by mapping the malicious input, comprising triggers, to a predefined output representation (POR) of LLMs. Utilizing POR ensures that the same input at the classification layer yields the same label prediction for all activated text instances. Despite the injection of triggers during the backdoor insertion process, the tainted model remains usable as the attack involves training a clean reference model to retain representations of normal inputs. The flexibility of the landscape across models facilitates this capability. The authors of [92] propose a technique called layer weight poisoning training to alleviate catastrophic forgetting during fine-tuning by deliberately corrupting the weights in the initial layers of LLMs. This method achieves notably high success rates in attacking large fine-tuning scales, in contrast to other approaches that manipulate output representations. Additionally, it employs a composite token as a trigger, rendering it indiscernible within the embedding space of the model's vocabulary.

## 4 Attack techniques enhancements

Adversarial attacks have been utilized to evaluate the robustness of LLM systems against real-world threats. Several studies have conducted extensive examinations on the significance of adversarial attacks for enhancing resilient NLP models [57, 72, 89, 93]. An example is demonstrated in the examination conducted by authors in [93], where they explore the creation of adversarial examples (AEs) tailored specifically for seq2seq models processing discrete text inputs. To mitigate challenges stemming from the discrete nature of the input space, the authors propose employing a projected gradient technique amalgamating group lasso and gradient regularization within the "white-box" threat model. To effectively address the diverse potential outputs, the researchers introduce a novel loss function capable of generating targeted keyword attacks without overlap. The authors achieve an average success rate of ${85}\%$ in their adversarial attempts against NLP models. However, they refrain from specifying the exact factors contributing to the efficacy of the attack, particularly whether it stems from flaws in the design of the seq2seq model or characteristics of the dataset. This study by the authors in [93] serves as an illustration. They delve into the generation of AEs tailored for seq2seq models operating on discrete text inputs. The authors suggest employing a projected gradient technique integrating group lasso and gradient regularization within the "white-box" threat model to circumvent challenges arising due to the unique properties of the input space. To address potential outcomes more efficiently, the researchers devise a novel loss function capable of generating specific keyword attacks without duplication. The authors achieve an average success rate of ${85}\%$ in their adversarial endeavors targeting NLP models. However, they fail to specify the precise factors contributing to the attack's effectiveness, particularly whether it arises from deficiencies in the design of the seq2seq model or characteristics of the dataset. Furthermore, the authors do not provide recommendations on strategies to enhance the resilience of seq2seq models against adversarial attacks. An overview of the CAT-Gen model [89] is depicted in Fig. 6. The authors utilize backpropagation to optimize two loss functions in their model. The first loss function, denoted by a black dashed line, is the cross entropy loss, ensuring semantic similarity between the generated and input sentences. The second loss function, represented by a green dashed line, is the attribute loss, manipulating irrelevant attributes in the generated sentence. Variability in sentiment label prediction on generated text is observed when altering the category attribute. Subsequent subsections provide a comprehensive analysis of various attack methods and techniques employed in NLP robustness literature.

![bo_d1m00jf7aajc73dif19g_9_146_157_1459_395_0.jpg](images/bo_d1m00jf7aajc73dif19g_9_146_157_1459_395_0.jpg)

Fig. 6 Outline of the Controlled Adversarial Text Generation (CAT-Gen) model [89]

### 4.1 Convex optimization

The concept of resilience concerning word substitutions is clearly defined and widely accepted within the field. It involves replacing words with similar meanings and is considered fundamental for achieving overall resilience in NLP. Sparse convex combination (SCC) [94] refers to a technique where the desired output is represented by a sparse and convex combination of the input text. As per the given definition, a proficient NLP classification model can accurately assign any input $x$ to its corresponding class label $y$ . Each targeted sparse adversarial attack aims to find a modification that, when applied to an unaltered input $x$ , results in it being misclassified as a specific target class [95]. This particular attack method has been employed in several research endeavors [95-99].

There are multiple methodologies available for verifying the robustness certification of neural networks [100]. These methodologies include various convex optimization approaches and randomized smoothing techniques. The fundamental concept involves representing the solution space as a convex hull constructed from word vectors. Two main advantages emerge from utilizing a convex hull. Firstly, its continuous convex nature enables the creation of adversaries using gradient-based methods. Gradient-based attacks utilize the gradients of a model to produce malevolent data [68]. Consequently, for LLMs, an assailant can exploit the LLM's gradients to ascertain how minor adjustments to the input text will induce the LLM to produce a disparate prediction. This facilitates the crafting of adversarial instances closely resembling the original text, yet inaccurately classified by the LLM. Secondly, by definition, the convex hull serves as the smallest convex set enclosing all potential substitutions, ensuring inclusivity by encompassing all potential substitutions while removing redundant scenarios.

In [101], a certified defense technique for text classification is proposed. This method involves evaluating data sanitization defenses, which entails a thorough examination of datasets to detect and remove potential poisoning points. An upper limit is determined for the maximum test loss achievable by any attack occurring within a scenario where both the attacker and defender are active simultaneously. This upper bound encompasses all possible data points not subjected to outlier removal. Authors in [102] introduced a certified robustness approach based on semi-definite relaxation. A maximum limit is computed for potential loss in neural networks with a single hidden layer. The computed robustness certificate offers a maximal measure of resilience against various attack forms, trained concurrently with the network to ensure differentiability. The examination in [103] provides a formal proof of system robustness by integrating differential privacy into input data. Figure 7 illustrates a standard Word Substitution Ranking Attack (WSRA) architecture. A ranking model is deemed Certified Top-k Robust against WSRA on a ranked list if it effectively ensures that documents beyond the top $\mathrm{K}$ positions do not appear within those positions for all possible WSRAs. Application of differential privacy to textual data involves treating each sentence as a database and considering words as individual records. If a model satisfies a threshold (epsilon-DP) for the corresponding perturbed input, it indicates the input should be identical to the clean data.

The application of word substitution in adversarial attacks can be conceptualized as a problem of combinatorial optimization. Solving this issue within the discrete textual domain is widely acknowledged as NP-hard, owing to the exponential growth of the search space concerning the input length. Various strategies have been proposed to represent word substitutions within the continuous word vector space [104-107]. These techniques seek to leverage the gradients generated by a targeted model for either attacking or bolstering its resilience through training. However, existing methods address the challenge of word replacements in vector space by employing either an "12-ball" or a "hyper-rectangle [108]". Nonetheless, these methodologies possess limitations, as they either yield perturbation sets that are inadequately comprehensive or excessively extensive. Consequently, this impedes the precise emulation of worst-case scenarios for robust training.

![bo_d1m00jf7aajc73dif19g_10_149_159_700_283_0.jpg](images/bo_d1m00jf7aajc73dif19g_10_149_159_700_283_0.jpg)

Fig. 7 A typical Word Substitution Ranking Attack (WSRA) framework [103]

### 4.2 Sparse projected gradient descent (SPGD)

In the domain of visual applications, predominant strategies for generating adversarial examples entail optimization methods and the application of gradient descent [9]. However, due to the distinctive attributes of textual data, the feasibility of this method is constrained. Consequently, there exists a restricted array of white-box attacks applicable to NLP models, wherein assailants have access to the system's parameters and gradients. The projected gradient descent method is frequently utilized in the field of ML models [109]. This method involves examining each element of the input text to identify potential substitutions. Optimal perturbations are chosen from the entire set of possible perturbations and applied iteratively until further perturbations are not feasible [110]. This attack strategy has been employed in various research examinations [41, 110, 111], yielding diverse and promising results. An illustration is shown in Fig. 8.

In a simplistic two-word illustration, the adversary has 3 increments (represented by green arrows) away from the initial word, ultimately reaching the unrefined alterations highlighted in yellow. By setting the "sparsity coefficient" to $\sigma  = {0.5}$ , only those perturbations that are having the highest ${50}\%$ norms are retained, specifically Word A in this case. Ultimately, the perturbation of word A is mapped onto the closest neighboring path that has the greatest cosine similarity, resulting in the red arrow.

While computing gradients within the discrete domain of textual data is impractical, there have been proposals to ascertain gradients within the continuous embedding space. For instance, [112] suggests a method where random words in the input sentence are replaced with the nearest word in the embedding space, based on the gradient direction. This replacement ensures that the disparity between the original word and the substituted word aligns with the gradient. In a related study, Sato et al. [104] extend the Adv-Text framework [113] to improve the generation of adversarial perturbations. They achieve this by aligning the perturbation directions in the embedding space with meaningful embedding vectors. However, these techniques may significantly alter multiple words within the sentence, resulting in noticeable changes. Recently, [114] introduced the gradient-based distributional attack (GBDA) to target text transformers. This approach considers a probability distribution for each word in the adversarial sentence across the vocabulary. The continuous distribution matrix is optimized to deceive the target model. However, their proposed formulation exhibits considerable overparameterization. Since these methods are tailored for discrete data, it's possible to encounter an embedding vector during the iterative process that has already been computed due to projection. Additionally, if the perturbation vector lacks sufficient magnitude, the updated vectors will project onto the previous sentence. In such cases, the algorithm may get stuck in a repetitive cycle due to consistent gradient computations. To address this, [115] propose a strategy where embedding vectors are updated through projection only when the projected sentence has not been previously generated.

### 4.3 Population-based optimization

Adversarial attacks pose a significant threat to DNNs, widely employed across various domains including image processing, NLP, and audio analysis [116]. In contemporary instances of textual adversarial attacks, a prevailing strategy involves the utilization of a black-box soft label. This label is acquired by exploiting either gradient information or the model's confidence. Consequently, executing adversarial attacks based solely on the predicted top labels of the hard-label model presents a formidable and realistic challenge. Current methodologies for executing hard-label adversarial attacks utilize population-based genetic optimization algorithms. A population-based optimization algorithm, a variant of genetic algorithms used in optimization, aims to discover outliers capable of altering the model's classifications or predictions [117, 118]. Implementing the described approach necessitates maintaining a dynamic "population" of potential inputs that can be continually adjusted and combined [119]. In contrast, a "black-box" attack denotes an adversarial attack where the attacker lacks access to the internal structure or parameters of the model. This attack methodology has been employed in various examinations [29, 120-123].

The examination performed by the researchers in [56] illustrates the effectiveness of the Deepwordbug in generating subtle alterations in text. This method proves particularly efficient within a "black box" context, where the classifier is induced to misclassify textual input. The methodology employs an innovative scoring technique to identify crucial tokens, the modification of which leads to erroneous predictions by the classifier. The research detailed in [29] focuses on the Textbugger framework, which prioritizes the detection of the most pertinent sentences before utilizing a scoring function to pinpoint keywords within these sentences. In the study conducted by [57], a model is introduced as a population optimization algorithm functioning as a black-box approach. Its objective is to generate adversarial examples that mimic the original input semantically and syntactically. The SememePSO algorithm [121], a variant of particle swarm optimization, is employed as the search algorithm to create adversarial examples within black-box scenarios. Researchers in [124] investigate the utilization of contextual alterations from the BERT mask language model to create seemingly innocuous attacks. The research by authors in [54] proposes a novel approach to word substitution order based on considerations of word salience and classification probability. Additionally, they suggest a greedy algorithm for implementing this approach in the context of textual adversarial attacks. The foundational method utilized in Textfooler [125] revolves around textual adversarial techniques, specifically employing synonyms to replace vulnerable words within sentences. Conversely, the study outlined by [29] introduces Bertattack as a methodology for generating superior quality adversarial examples by leveraging pre-trained masked language models based on BERT. In a subsequent examination [126], researchers introduce a method called locally sensitive hashing (LSH) and Attention, which integrates attention mechanisms and LSH to reduce the number of queries effectively. This approach amalgamates the advantages of both techniques. In their research, Wang et al. [127] introduce SemAttack, a method involving the formulation of semantic perturbation functions to identify optimal perturbations within different semantic spaces, potentially enhancing the efficiency of generating adversarial examples. In their recent work, Lee et al. [128] introduce discrete block bayes attack, a method leveraging Bayesian optimization to query discrete text data. The authors utilize the automatic relevance determination (ARD) [129] classification kernel to dynamically ascertain significant positions, facilitating the efficient generation of adversarial examples.

![bo_d1m00jf7aajc73dif19g_11_244_159_1266_347_0.jpg](images/bo_d1m00jf7aajc73dif19g_11_244_159_1266_347_0.jpg)

Fig. 8 A two-word sequence being used as an example of SPGD [41]

### 4.4 Word saliency based methods

The majority of existing black-box saliency computation techniques in the domain of NLP rely on comparing the predictive outcomes of the original instance with its approximate representations [130]. Typically, these techniques require a considerable number of iterations through the model to yield prediction results. However, this poses challenges for practical implementation and fails to fully leverage the rich features inherent in the instances. The lexical elements within textual instances exhibit certain attributes indicative of their semantic content and contextual surroundings, such as their syntactic category (part of speech), position within the sentence, and other pertinent factors. These attributes hold promise in indicating the importance of words within the given textual instance [130]. This connection is exemplified by the correlation observed between the distribution of word saliency in textual instances and specific tasks. It is widely recognized that nouns, adjectives, and verbs are content-bearing words that convey meanings [121]. To this point, previous studies have primarily focused on extracting the neural representation of specific linguistic content from the embeddings of the GPT-2 model or on obtaining empirical estimations of probabilities for subsequent words from the model's output [131-133]. Additionally, an initial inquiry conducted by authors in [134] showcased the potential to clarify the sequence of cortical computations implicated in language comprehension through the utilization of the BERT model [23]. This was accomplished by supplying a text as input to the model and utilizing the output of its attention heads, which are fundamental components of an attention-based deep learning model that directly process the input words [134]. However, previous research has not considered the aspect of "reasoning" in the model, which involves assessing input words and assigning responsibility to each word for generating a specific output [135]. To address this issue, one can utilize "input saliency" techniques to generate the saliency score, a simple weighting assigned to each word within the input sequence indicating its importance in the model’s prediction of the subsequent word $\left\lbrack  {{135},{136}}\right\rbrack$ .

Understanding the interrelations among diverse word attributes and the model's output can aid in establishing a correlation between samples and their saliency distribution. This process also allows for the assessment of each component's individual impact on the model's outputs. In the domain of deep learning, it's customary to evaluate the importance of input components using output gradients. However, in NLP tasks, words are primarily represented as vectors, making it challenging to accurately compute saliency values at the word level. INT-GRAD's resilience, as evidenced by its authors in [137], effectively addresses this NLP challenge by comparing values to a baseline. Another method introduced by authors in [138] involves backpropagating contributions of all neurons in a DNN to each input feature, enabling comprehensive saliency analysis. In [139], a technique called instance-wise feature selection is proposed. Here, a feature selector is trained to maximize mutual information between selected features and the output. The goal is to identify a subset of features containing the most informative characteristics in the samples.

### 4.5 Particle swarm optimization (PSO)-based methods

The PSO algorithm is a widely used search algorithm applied in the generation of adversarial examples [121]. In this methodology, each member of the population undergoes perturbation by exploring all possible candidates. This process involves substituting each input and subsequently selecting one input example during each epoch. Through employing this algorithm, it becomes feasible to identify the most advantageous modified input from the entire population [110]. This adversarial technique finds application in numerous studies examining ML model resilience against adversarial attacks $\left\lbrack  {{110},{120},{121},{140},{141}}\right\rbrack$ . Recent advancements have introduced several methodologies for word-level attacks. Among these methods, the utilization of sememes and PSO has demonstrated superior performance in terms of both attack success rate and average modification rate. However, in complex scenarios such as solving high-dimensional combinatorial optimization problems, the PSO algorithm often faces challenges concerning insufficient robustness, premature convergence, and exploration-exploitation imbalance. These challenges are particularly pronounced when dealing with sentences containing a large number of words. To effectively attack the victim model with a reduced modification rate, it is imperative for the algorithm to achieve a favorable balance between exploitation and exploration.

In recent times, several enhanced PSO variants have been proposed to tackle optimization problems of considerable scale. These variants can be categorized into three distinct groups: methods directly improving the PSO algorithm, PSOs coevolving cooperatively, and PSOs aided by surrogate models. In [142], a competitive swarm optimizer (CSO) was devised explicitly for addressing large-scale global optimization problems. Notably, their approach diverges from traditional methods by excluding the incorporation of personal best positions or global best positions during particle update processes. In [143], a level-based learning swarm optimizer (LLSO) was introduced with the aim of enhancing learning. This optimizer is tailored to tackle high-dimensional optimization problems by classifying particles into different levels and applying distinct treatment to each level. The aforementioned improved PSO variants for large-scale optimization encompass two methods falling within the first category. The classical cooperatively co-evolving PSO algorithm, as proposed in [144], employs a random grouping technique to decompose a large-scale problem into multiple subproblems, which are then addressed individually. Several surrogate-assisted evolutionary algorithms (SAEAs) [145] have been suggested as a means of tackling intricate and computationally demanding optimization problems.

## 5 Methods for strengthening LLMs

There exist numerous methodologies for enhancing the resilience of LLMs against adversarial attacks [9]. These methodologies encompass word recognition techniques, stochastic ensembles, interval-bound propagation, ensemble classifiers employing randomized smoothing, and additional approaches. This section delineates the most prevalent robustness techniques and their respective implementations.

### 5.1 Model Ensemble

When it comes to acquiring complex models, DNNs have demonstrated high efficacy [23, 161, 162] and have achieved notable success across various domains. Despite their proficiency in data representation, their capacity for generalization may be compromised due to elevated levels of model variance. It is customary to amalgamate the weights or predictions from multiple models when making predictions, a practice known as model ensemble [163, 164]. As evidenced by the authors in [160], a simple two-model ensemble outperforms a solitary model significantly in computer vision tasks. Each network undergoes training employing both a supervised learning loss and a KLD-based mimicry loss to align the probability estimates with those of its counterparts, as depicted in Fig. 9. While model ensemble presents several advantages, its application in LLMs remains constrained. The primary impediments include substantial computational overhead and extensive storage requirements, both of which scale with the number of models. Given that edge devices typically possess limited memory and stringent latency demands, ensembling LLMs for deployment can be prohibitively costly. Recent endeavors have employed weight sharing to mitigate the memory burden by reducing the number of weights each model must store in memory [165- 167]. In this scheme, all models utilize identical bottom-layer weights, with each model employing its own parallel, non-shared top-layer weights. Weight sharing fosters increased diversity in unshared branches, thereby facilitating more generalized learning of shared representations [168-170]. However, the advantages of a weight-sharing approach diminish considerably for large models. Due to memory constraints, a substantial portion of the weights in the bottom layer must be shared, resulting in minimal diversity among the resulting models [166, 171-173]. Consequently, the generalization performance of their ensemble suffers from a dearth of model diversity.

Table 1 An overview of recent approaches that used LLM based evaluation methods

<table><tr><td>Paper</td><td>Methodology</td><td>Metric</td><td>Dataset</td><td>Key features</td></tr><tr><td>Wang et al. [146]</td><td>GE2E-ASV</td><td>EER</td><td>TIMIT</td><td>Adversarial instances where an end-to-end speech verification (SV) system is attacked are employed</td></tr><tr><td>Abdelali et al. [147]</td><td>Zero-shot learning</td><td>WER, BLEU</td><td>59 different datasets</td><td>Performance of large foundation models (FM) for standard Arabic NLP was evaluated</td></tr><tr><td>Bang et al. [148]</td><td>Zero-shot learning</td><td>ROUGE-1, JGA, BLEU</td><td>FLoRes-200, OpenDialKG</td><td>First ever thorough evaluation of generative LLMs - MEGA</td></tr><tr><td>Chen et al. [149]</td><td>Empirical study</td><td>BERTScore, ParaScore, PRISM etc</td><td>Twitter(Extend), dialog-level FED</td><td>The experiments show that ChatGPT can evaluate text quality from multiple perspectives without external references</td></tr><tr><td>Choi et al. [150]</td><td>BERT-based finetuning</td><td>CLS, PAIR, REG, SPAN</td><td>SOCKET datasets</td><td>SOCKET, a new benchmark based on theory, includes 58 NLP tasks categorized into five categories to assess social knowledge</td></tr><tr><td>Chia et al. [151]</td><td>LoRA</td><td>Accuracy</td><td>MMLU, BBU, DROP etc</td><td>A specialized evaluation suite has been developed to specifically cater to LLMs that are fine-tuned for instructional purposes</td></tr><tr><td>Fu et al. [152]</td><td>Few-shot prompting</td><td>Accuracy</td><td>GSM8k, MATH, BigBench Hard etc.</td><td>An open-source evaluation suite is introduced to assess the capabilities of LLMs in multi-step reasoning</td></tr><tr><td>Gekhman et al. [153]</td><td>Synthetic data generation</td><td>ROC-AUC</td><td>CNN/DM, XSum</td><td>An approach to create synthetic data by labeling various model-generated summaries with an LLM</td></tr><tr><td>Honovich et al. [154]</td><td>Empirical analysis</td><td>F1, BLEURT, QuestEval etc.</td><td>DialFact, QAGS-X, MNBM etc.</td><td>A thorough survey and evaluation of factual consistency metrics in standardized texts from various tasks</td></tr><tr><td>Lai et al. [155]</td><td>Zero-shot & supervised learning</td><td>F1 Score</td><td>XGLUE-POS, Huggingface, SMiLER</td><td>Evaluating LLMs for multilingual NLP applications to enhance information</td></tr></table>

Table 1 continued

<table><tr><td>Paper</td><td>Methodology</td><td>Metric</td><td>Dataset</td><td>Key features</td></tr><tr><td>Lopez et al. [156]</td><td>TF-IDF</td><td>R2Score</td><td>BookCorpus, 8 M Web Pages</td><td>A novel approach for assessing and comprehending the capabilities of different LLMs in financial market analysis</td></tr><tr><td>Lee et al. [157]</td><td>Monte Carlo estimation, log probability estimation</td><td>Acc., JSD, DCE</td><td>ChaosNLI, PK2019, ANLI-R3 etc</td><td>Comparison of two methods for assessing the efficacy and consistency of LLM distribution with human subjects</td></tr><tr><td>Lin et al. [158]</td><td>Zero-shot, few-shot</td><td>Accuracy</td><td>USMLE, MedMCQA, PubMedQA</td><td>The study examined various scenarios for prompting, including Chain-of-Thought (CoT), zero- and few-shot, retrieval augmentation, and question-answer exemplars prefixed to the question.</td></tr><tr><td>Liu et al. [159]</td><td>Pre-trained LM</td><td>Accuracy</td><td>LogiQA 2.0 ood, ConTRoL</td><td>Standards requiring reasoning are used to assess the reading comprehension and natural language inference tasks, which are multiple-choice.</td></tr><tr><td>Liu et al. [159]</td><td>Natural language inference</td><td>Entropy-based metrics</td><td>WikiBio</td><td>Black-box model responses can be fact-checked using a simple sampling-based approach with zerc resources</td></tr></table>

![bo_d1m00jf7aajc73dif19g_14_209_1424_1316_356_0.jpg](images/bo_d1m00jf7aajc73dif19g_14_209_1424_1316_356_0.jpg)

Fig. 9 Schematic of deep mutual learning (DML) [160]

### 5.2 Prevention against jailbreak

The incorporation of vast text corpora sourced directly from the Internet significantly enhances the attractiveness of LLMs, ensuring the credibility and authenticity of the generated content. However, this approach exposes LLMs to a plethora of information, including objectionable materials such as hate speech, spyware, and erroneous data [174]. Despite attempts to humanize LLMs, prominent models like GPT, Llama, Claude, and PaLM remain susceptible to producing offensive content through jailbreaking attacks. Among these attacks, adversarial prompting stands out as a method where an attacker manipulates the prompts provided to the LLM, resulting in inappropriate outputs [175, 176]. The recent findings of [177] are particularly concerning as they reveal that even highly performing LLMs can be compromised by appending adversarially-selected characters to different prompts. This encompasses GPT, Claude, and PaLM. The literature concerning language model robustness [178] illustrates various mitigation strategies. The majority of these defenses, including those utilizing adversarial training [113, 179] and data augmentation [55], necessitate retraining the underlying model, a computationally impractical task for LLMs. The lack of transparency in closed-source LLMs necessitates reliance solely on query access for potential defenses. The vulnerabilities of LLMs introduce a new set of challenges, exacerbated by these constraints and the absence of a proven solution to mitigate the threat posed by GCG. In [180], various defensive measures are explored, such as implementing a perplexity filter pre-processing step, altering the formulation of input prompts, and subjecting the computer to adversarial training. The effectiveness of these strategies varies. While heuristic detection-based techniques demonstrate notable performance, adversarial training is deemed infeasible due to the considerable computational resources required to retrain LLMs. In [181], the authors propose employing a safety filter on substrings of input prompts, presenting a method that provides verifiable assurances of robustness. However, despite its potential, this approach is suboptimal as its computational complexity scales with the size of the input prompt.

### 5.3 Deferentially private decoding

LLMs possess the capacity to anticipate subsequent or missing elements within a phrase, enabling them to undergo training for generating token sequences. Typically, their output manifests as a probability distribution across the vocabulary terms, from which the projected token originated. Initially introduced as LLMs, LSTM-based sequence-to-sequence (seq2seq) models were pioneered by Sutskever et al. [1], yet recent advancements have favored transformer-based models, as evidenced by Vaswani et al. [182], Devlin et al. [23], Radford et al. [183], and Conneau et al. [184]. Despite the performance enhancements attributed to LLMs, recent examinations have unveiled their inadvertent propensity to memorize segments of their training data [26, 185]. The likelihood of accurately reproducing segments of training data when presented with a well-crafted prompt increases if these models commit it to memory. Such memorization practices, particularly concerning sensitive consumer data, pose significant privacy concerns. Moreover, intensive memorization methodologies may compromise utility and fairness due to their misalignment with actual data distributions. Upon initial scrutiny, the problem of memorization leading to over-fitting of the training data arises [26, 186, 187]. The assertions made in [185] refute this notion by demonstrating that several regularization techniques, including early stopping and dropout, are insufficient in mitigating memorization. Differential privacy (DP) training, as outlined by the authors in [188], stands as the sole approach effectively thwarting model memorization.

The predominant technique for integrating DP into ML models, such as differentially private stochastic gradient descent (DP-SGD) [189, 190], typically involves adjustments to the training procedure. These adjustments are designed to mitigate privacy risks by reducing the model's dependency on specific training data points. However, they incur substantial costs in terms of computational resources, training duration, and model efficacy. Despite recent discussions addressing these challenges [191-193], DP training remains an active area of research due to the absence of a comprehensive approach that accounts for all relevant considerations. Rebuilding large-scale language models from scratch, while maintaining performance levels, necessitates significant investments in time and resources, rendering it impractical in real-world commercial settings constrained by such limitations. There is currently a trend towards formally defining and applying DP in pre-trained ML models during the inference phase $\left\lbrack  {{192},{194}}\right\rbrack$ .

### 5.4 Empirical & certified defenses

Over the years, several heuristic methodologies have been proposed to detect and mitigate adversarial attacks in computer vision [181, 195-199] and NLP tasks [200-202]. In a recent study [180], defensive strategies tailored to counterattacks by Zou et al. [177] are examined. The examination assesses the effectiveness of methodologies such as perplexity filtering, paraphrase, and adversarial training. However, it has been observed that empirical defenses against specific adversarial attacks are susceptible to more robust attacks [203-206]. The lack of empirical robustness against one adversarial attack does not guarantee robustness against more potent attacks in other instances. Our research focuses on developing verifiable robustness assurances applicable to all potential adversarial attacks within a specified threat model.

Extensive research has been conducted in the field of computer vision regarding defenses that provide demonstrable guarantees of resilience. Various techniques are employed in the field, including interval-bound propagation [107, 207-209], curvature bounds [210-212], and randomized smoothing [213-216]. Certified defenses for applications in NLP have also been examined. Ye et al. propose a methodology for mitigating word replacements in the context of text categorization by utilizing a predetermined set of synonyms [217]. Zhao et al. employ semantic smoothing as a means of mitigating natural language threats [218]. The introduction of noise into the latent space can reduce the influence of confounding factors that potential attackers might manipulate, as shown in Fig. 10. Zhang et al. put forward a self-denoising methodology aimed at mitigating the impact of subtle modifications in the input prompt for sentiment analysis [219]. Many defensive strategies frequently include the concept of imperceptibility within their framework of potential threats. This can be achieved through various means, such as limiting the use of synonymous phrases and making slight alterations to the input text. This renders them unsuitable for countering the attacks conducted by Zou et al. that include substantial modifications to the prompts [177]. Furthermore, these approaches are specifically tailored for jobs involving classification and do not take advantage of the unique characteristics of LLM safety attacks.

### 5.5 Fine-tuning LLMs

Enhancing transformer-based language models to discern between input texts produced by LLMs and those originating elsewhere constitutes the central focus of these methodologies. The utilization of paired samples is imperative to facilitate supervised training procedures. Prior research endeavors [220-223] have extensively explored the efficacy of fine-tuned language models in distinguishing text generated by language model models. Notably, research conducted in 2019 acknowledged the efficacy of refined language models (LMs), with Roberta [224] standing out as a particularly notable instance, in identifying text generated by LLMs. The fine-tuning process of Roberta serves as a robust groundwork for the identification and detection of text produced by LLMs. In their examination, Fagni et al. [225] observed that fine-tuning Roberta yielded optimal classification outcomes across various encoding configurations [226]. This observation was further corroborated by the subsequent adoption of a Roberta fine-tuning approach by the OpenAI detector [183]. Numerous recent studies [227- 230] have provided supplementary evidence endorsing the heightened effectiveness of fine-tuned variants within the "BERT" lineage, particularly "RoBERTa", in detecting text generated by LLMs. On average, these fine-tuned models attained a 95% accuracy rate within their specific domains. They exhibited superior performance compared to zero-shot and watermarking methodologies, and also demonstrated a certain degree of resilience against various attack strategies within their specific domains. Nonetheless, akin to their counterparts, methods involving fine-tuning encoders manifest a lack of robustness [220], as they tend to excessively fit the provided training data or the training distribution associated with the source model. Consequently, their performance diminishes when confronted with data from dissimilar domains or unseen data. The limited availability of data has prompted the adoption of contrastive learning [231-233] in LM-based classifiers, with self-supervised learning constituting the foundational principle of this methodology. This approach endeavors to minimize the spatial disparity between anchor and positive samples, while concurrently maximizing the spatial disparity between the anchor and negative samples through spatial transformations. Liu et al. [234] proposed an enhanced contrastive loss function that assigns greater weights to challenging negative data, with the objective of optimizing model efficacy and enhancing performance under resource constraints. The methodology employed in this examination comprehensively accounts for linguistic characteristics and sentence structures, leveraging a coherence graph to capture the inherent consistency of textual elements. The efficacy of LM-based detectors can be bolstered by incorporating factual information structures, as evidenced by research findings and reaffirmed by Zhong et al. [235]. Bhattacharjee et al. [236] introduced the ConDA framework, which integrates traditional domain adaptation techniques with the representational capabilities of contrastive learning. This amalgamation yields substantial improvements in the model's capacity to withstand unfamiliar models.

![bo_d1m00jf7aajc73dif19g_16_901_153_704_759_0.jpg](images/bo_d1m00jf7aajc73dif19g_16_901_153_704_759_0.jpg)

Fig. 10 Overview of the proposed architecture in [218]

## 6 Challenges & future directions

The topic of adversarial attack and defense remains a substantial challenge. This section specifically discusses the present hurdles and constraints within the domain of producing and safeguarding against adversarial attacks in LLMs.

### 6.1 Assessment of offensive or defensive performance

The majority of recent studies evaluate attack performance using metrics such as attack success rate or accuracy [237]. However, there is a scarcity of studies considering the scale and efficiency of attacks. Moreover, these studies predominantly focus on the time cost of attacks. The potential relationships between dataset size, attack duration, and attack effectiveness remain inadequately explored [9]. Investigating these potential relationships requires further examination of how to effectively balance these three aspects, which is expected to be a significant area of interest for future research [238]. Similarly, assessing defense performance faces a comparable challenge. Analogous to the situation in text and image processing, there is currently a lack of benchmarks for evaluating adversarial attacks and defenses on LLMs [239]. Consequently, the absence of universally accepted assessment criteria presents a challenge in evaluating the effectiveness of relevant scholarly contributions.

### 6.2 Defense and attack transferability

Adversarial examples within NLP display various aspects and extensions of transferability, akin to advancements in computer vision [240]. It is typical to observe transfers among diverse models and between training and testing datasets. Recent studies have focused on developing attacks transferable across various ML tasks [241]. Transferability denotes the capability of an attacker to exploit a ML model for malicious purposes without requiring the same architecture, data, model, or task for which the ML model was designed [74]. This phenomenon resembles a newly emerging challenge that poses a threat to the efficacy of defense strategies [242]. Black-box and untargeted adversarial attacks demonstrate higher levels of transferability compared to "white-box" and/or "targeted attacks", as anticipated [50]. Given the absence of content in the user's input, there is a heightened necessity for the development of sophisticated defense strategies capable of effectively addressing this challenge. Transferability can be evaluated across different granularities, encompassing word, character, and sentence levels [51].

### 6.3 High computational requirements

The majority of methods outlined in the literature necessitate substantial computational resources, often exceeding those required for the model's natural training process [243]. One potential avenue involves exploring new training methodologies that require fewer computational resources and expedite training. For instance, Shafahi et al. [244] propose free adversarial training, which optimizes stochastic gradient descent (SGD) [245] passes to compute the model's gradient with respect to network parameters during the backward pass, along with the derivative of the loss function with respect to the input. This approach demonstrates improved computational efficiency compared to the initial training model [246], while maintaining similar accuracy levels. Zhang et al. [243] introduce a novel training approach that minimizes the number of iterations needed to generate an adversarial example to one. However, despite advancements in reducing runtime, it remains significantly slower than conventional training [247]. Several studies suggest that employing the FGSM [16] with random initialization is effective in mitigating projected gradient descent (PGD) [248] attacks. This approach not only provides adequate defense against PGD attacks but also reduces computational requirements. Its effectiveness can be further enhanced by integrating it with various training techniques, such as mixed-precision arithmetic [249] and cyclic learning rate [250], as demonstrated in [251].

### 6.4 Embedding space size & perturbation

Numerous studies have proposed various methodologies for delineating a suitable embedding space $\left\lbrack  {9,{252}}\right\rbrack$ . Furthermore, a diverse array of strategies exists for investigating and identifying the optimal substitution within this space [253]. However, additional examination is necessary to establish a comprehensive framework for defining the space and optimizing the search process to ascertain the most suitable replacement [33]. Moreover, it is imperative to account for the tradeoff between the size of the embedding space and the computational burden associated with the search process. Additionally, innovative concepts are required for regularizing and guiding the search process within the embedding space or hyperspace. Several examinations have explored determining the most crucial characters and words for modification relative to others [9]. Nonetheless, further inquiry is evidently needed to fully probe this concept. In this specific context, it is conceivable to envisage formulating a comprehensive framework to address a broader inquiry concerning the optimal approach to modifying elements such as characters, sub-words, or sub-sentences [254]. This presents an opportunity to explore novel optimization configurations capable of systematically and feasibly addressing these inquiries.

### 6.5 Reliance on human factors

According to the literature review, human intervention is essential for the design, as well as the optimization of variance adversarial attack paradigms and corresponding defense methodologies [255]. This phenomenon gains particular significance when evaluating the extent of imperceptibility displayed by adversarial substitutions from a linguistic standpoint [256]. Further considerations related to human factors involve deliberations concerning the specification of attack parameters within the model and the subsequent optimization of these parameters. Thus, there is scholarly interest in exploring the feasibility of automating these processes to minimize, or at least regulate, the extent of human intervention necessary in this domain [257]. This presents a significant research challenge within the domain of ML, encompassing the broader context.

### 6.6 Discrete data perturbation

Generating adversarial examples in text presents a fundamental challenge compared to images. There is a prevalent belief that applying computer vision and image processing techniques to generate adversarial examples does not directly extend to discrete inputs [258]. Essentially, using such a straightforward approach leads to the detection of the attack, as the significance of characters and words diminishes due to the discrete nature of perturbations [259]. Furthermore, it should be noted that text perturbations primarily involve replacement operations. This raises a significant research question regarding the characterization of effective replacements. Therefore, a current focus of recent works involves identifying and measuring novel elements of textual similarity [48]. Similarly, implementing continuous input defense techniques poses challenges. For example, the Generative Adversarial Network (GAN) methodology relies on incorporating synthetic noise into the input data, rendering it inapplicable within the context of NLP [260]. One intriguing area of research involves adapting existing off-the-shelf methods for generating and defending against adversarial attacks on continuous variables for application in a textual context [261].

## 7 Conclusion

This study aims to provide a comprehensive analysis of the security threats and areas of vulnerability within the LLM framework. Its goal is to augment the comprehension and awareness of stakeholders in academia and industry concerning LLM security. Additionally, it endeavors to enhance their ability to discern the fundamental mechanisms behind these potential threats.

Acknowledgements Not applicable

Author Contributions Pranjal Kumar conceived the idea and drafted the manuscript.

Data Availability No datasets were generated or analysed during the current study.

## Declarations

Conflict of interest On behalf of all authors, the corresponding author states that there is no Conflict of interest.

Consent for publication Yes.

## References

1. Sutskever I, Vinyals O, Le QV (2014) Sequence to sequence learning with neural networks. Adv Neural Inf Process Syst 27:3104-3112

2. Saon G, Kurata G, Sercu T, Audhkhasi K, Thomas S, Dimitriadis D, Cui X, Ramabhadran B, Picheny M, Lim LL, Roomi B (2017) English conversational telephone speech recognition by humans and machines. In Proceedings of the Interspeech 2017, pp 132- 136

3. Khatiri S, Di Sorbo A, Zampetti F, Visaggio CA, Di Penta M, Panichella S (2024) Identifying safety-critical concerns in unmanned aerial vehicle software platforms with salient. Soft-wareX 27:101748

4. Parkhi O, Vedaldi A, Zisserman A (2015) Deep face recognition. In: BMVC 2015-proceedings of the British machine vision conference 2015. British Machine Vision Association

5. Chen C, Seff A, Kornhauser A, Xiao J (2015) Deepdriving: learning affordance for direct perception in autonomous driving. In: Proceedings of the IEEE international conference on computer vision, pp 2722-2730

6. Ma X, Fang G, Wang X (2023) LLM-pruner: on the structural pruning of large language models. Adv Neural Inf Process Syst 36:21702-21720

7. Szegedy C, Zaremba W, Sutskever I, Bruna J, Erhan D, Goodfel-low I, Fergus R (2014) Intriguing properties of neural networks. In: Bengio Y, LeCun Y (eds) 2nd international conference on learning representations, ICLR 2014, Banff, AB, Canada, April 14-16, 2014, conference track proceedings

8. Alotaibi A, Rassam MA (2023) Adversarial machine learning attacks against intrusion detection systems: a survey on strategies and defense. Future Internet 15(2):62

9. Raiaan MA, Mukta MS, Fatema K, Fahad NM, Sakib S, Mim MM, Ahmad J, Ali ME, Azam S (2024) A review on large language models: architectures, applications, taxonomies, open issues and challenges. IEEE Access. https://doi.org/10.1109/ ACCESS.2024.3365742

10. Boffa M, Drago I, Mellia M, Vassio L, Giordano D, Valentim R, Houidi ZB (2024) Logprécis: unleashing language models for automated malicious log analysis: Précis: a concise summary of essential points, statements, or facts. Comput Secur 141:103805

11. Alwahedi F, Aldhaheri A, Ferrag MA, Battah A, Tihanyi N (2024) Machine learning techniques for IoT security: current research and future vision with generative AI and large language models. Internet Things Cyber Phys Syst. https://doi.org/10.1016/j.iotcps.2023.12.003

12. Li Z, Fan S, Gu Y, Li X, Duan Z, Dong B, Liu N, Wang J (2024) Flexkbqa: a flexible LLM-powered framework for few-shot knowledge base question answering. In: Proceedings of the AAAI conference on artificial intelligence 38:18608-18616

13. Livne M, Miftahutdinov Z, Tutubalina E, Kuznetsov M, Polykovskiy D, Brundyn A, Jhunjhunwala A, Costa A, Aliper A, Aspuru-Guzik A et al (2024) nach0: multimodal natural and chemical languages foundation model. Chem Sci. https://doi.org/ 10.1039/D4SC00966E

14. Abe N, Zadrozny B, Langford J (2004) An iterative method for multi-class cost-sensitive learning. In: Proceedings of the tenth ACM SIGKDD international conference on Knowledge discovery and data mining, pp 3-11

15. Yuan X, He P, Zhu Q, Li X (2019) Adversarial examples: attacks and defenses for deep learning. IEEE Trans Neural Netw Learn Syst 30(9):2805-2824

16. Wu C, Fang W, Dai F, Yin H (2023) A model ensemble approach with LLM for Chinese text classification. In: China health information processing conference. Springer, pp 214-230

17. Nazir A, Chakravarthy TK, Cecchini DA, Khajuria R, Sharma P, Mirik AT, Kocaman V, Talby D (2024) LangTest: a comprehensive evaluation library for custom LLM and NLP models. Softw Impacts 19:100619

18. Sang EF, De Meulder F (2003) Introduction to the CoNLL-2003 shared task: Language-independent named entity recognition. In Proceedings of the seventh conference on natural language learning at HLT-NAACL 2003, pp 142-147

19. Rajpurkar P, Zhang J, Lopyrev K, Liang P (2016) SQuAD: 100,000 + questions for machine comprehension of text. In: Su J, Duh K, Carreras X (eds) Proceedings of the 2016 conference on empirical methods in natural language processing, Austin, Texas, November 2016. Association for Computational Linguistics, pp 2383-2392

20. Wang A, Singh A, Michael J, Hill F, Levy O, Bowman SR (2018) GLUE: a multi-task benchmark and analysis platform for natural language understanding. In: Linzen T, Chrupata G, Alishahi, A (eds) Proceedings of the 2018 EMNLP workshop BlackboxNLP: analyzing and interpreting neural networks for NLP, Brussels, Belgium, November 2018. Association for Computational Linguistics, pp 353-355

21. Wei C, Xie SM, Ma T (2021) Why do pretrained language models help in downstream tasks? An analysis of head and prompt tuning. Adv Neural Inf Process Syst 34:16158-16170

22. Radford A, Narasimhan K, Salimans T, Sutskever I (2018) Improving language understanding by generative pre-training

23. Devlin J, Chang MW, Lee K, Toutanova K (2019) BERT: pretraining of deep bidirectional transformers for language understanding. In: Burstein J, Doran C, Solorio T (eds) Proceedings of the 2019 conference of the North American chapter of the association for computational linguistics: human language technologies, volume 1 (long and short papers), Minneapolis, Minnesota, June 2019. Association for Computational Linguistics, pp 4171-4186

24. Akbik A, Bergmann T, Blythe D, Rasul K, Schweter S, Vollgraf R (2019) FLAIR: an easy-to-use framework for state-of-the-art NLP. In: Proceedings of the 2019 conference of the North American chapter of the association for computational linguistics (demonstrations), pp 54-59

25. Chen K, Meng Y, Sun X, Guo S, Zhang T, Li J, Fan C (2022) Bad-pre: task-agnostic backdoor attacks to pre-trained NLP foundation models. In: International conference on learning representations

26. Feldman V, Zhang C (2020) What neural networks memorize and why: discovering the long tail via influence estimation. Adv Neural Inf Process Syst 33:2881-2891

27. Krishna K, Tomar GS, Parikh AP, Papernot N, Iyyer M (2020) Thieves on sesame street! model extraction of BERT-based APIs. In: International conference on learning representations

28. Wang B (2023) Towards trustworthy large language models. PhD thesis, University of Illinois at Urbana-Champaign

29. Li L, Ma R, Guo Q, Xue X, Qiu X (2020) BERT-ATTACK: adversarial attack against BERT using BERT. In: Webber B, Cohn T, He Y, Liu Y (eds) Proceedings of the 2020 conference on empirical methods in natural language processing (EMNLP), Online, November 2020. Association for Computational Linguistics, pp 6193-6202

30. Yuan L, Zheng X, Zhou Y, Hsieh CJ, Chang KW (2021) On the transferability of adversarial attacks against neural text classifier. In: Moens MF, Huang X, Specia L, Yih SWT (eds) Proceedings of the 2021 conference on empirical methods in natural language processing, Online and Punta Cana, Dominican Republic, November 2021. Association for Computational Linguistics, pp 1612-1625

31. Shen L, Ji S, Zhang X, Li J, Chen J, Shi J, Fang C, Yin J, Wang T (2021) Backdoor pre-trained models can transfer to all. In: Proceedings of the 2021 ACM SIGSAC conference on computer and communications security, CCS '21, New York, NY, USA, 2021. Association for Computing Machinery, pp 3141-3158

32. Rane NL, Tawde A, Choudhary SP, Rane J (2023) Contribution and performance of ChatGPT and other large language models (LLM) for scientific and research advancements: a double-edged sword. Int Res J Mod Eng Technol Sci 5(10):875-899

33. Yao Y, Duan J, Xu K, Cai Y, Sun Z, Zhang Y (2024) A survey on large language model (LLM) security and privacy: the good, the bad, and the ugly. High Confid Comput 4:100211

34. Gupta M, Akiri C, Aryal K, Parker E, Praharaj L (2023) From ChatGPT to ThreatGPT: impact of generative AI in cybersecu-rity and privacy. IEEE Access. https://doi.org/10.1109/ACCESS.2023.3300381

35. Yang J, Jin H, Tang R, Han X, Feng Q, Jiang H, Zhong S, Yin B, Hu X (2024) Harnessing the power of LLMs in practice: a survey on ChatGPT and beyond. ACM Trans Knowl Discov Data 18(6):1-32

36. Jia R, Liang P (2017) Adversarial examples for evaluating reading comprehension systems. In: Palmer M, Hwa R, Riedel S (eds) roceedings of the 2017 conference on empirical methods in natural language processing, Copenhagen, Denmark, September 2017. Association for Computational Linguistics, pp 2021-2031

37. Omar M, Choi S, Nyang D, Mohaisen D (2022) Robust natural language processing: recent advances, challenges, and future directions. IEEE Access 10:86038-86056

38. Akhtar N, Mian A (2018) Threat of adversarial attacks on deep learning in computer vision: a survey. IEEE Access 6:14410- 14430

39. Wang W, Chen Z, Chen X, Wu J, Zhu X, Zeng G, Luo P, Lu T, Zhou J, Qiao Y et al (2024) Visionllm: large language model is also an open-ended decoder for vision-centric tasks. Adv Neural Inf Process Syst 36:61501-61513

40. Hu S, Shang X, Qin Z, Li M, Wang Q, Wang C (2019) Adversarial examples for automatic speech recognition: attacks and countermeasures. IEEE Commun Mag 57(10):120-126

41. Wang W, Wang R, Wang L, Wang Z, Ye A (2023) Towards a robust deep neural network against adversarial texts: a survey. IEEE Trans Knowl Data Eng 35(3):3159-3179

42. Das RK, Tian X, Kinnunen T, Li H (2020) The attacker's perspective on automatic speaker verification: an overview. In Proceedings of the Interspeech 2020, pp 4213-4217

43. Abdullah H, Warren K, Bindschaedler V, Papernot N, Traynor P (2021) SoK: the faults in our ASRs: an overview of attacks against automatic speech recognition and speaker identification systems. In: 2021 IEEE symposium on security and privacy (SP). IEEE, pp 730-747

44. Chen X, Li S, Huang H (2021) Adversarial attack and defense on deep neural network-based voice processing systems: an overview. Appl Sci 11(18):8450

45. Zhang WE, Sheng QZ, Alhazmi A, Li C (2020) Adversarial attacks on deep-learning models in natural language processing: a survey. ACM Trans Intell Syst Technol TIST 11(3):1-41

46. Xu H, Ma Y, Liu HC, Deb D, Liu H, Tang JL, Jain AK (2020) Adversarial attacks and defenses in images, graphs and text: a review. Int J Autom Comput 17:151-178

47. Wang Y, Sun T, Li S, Yuan X, Ni W, Hossain E, Poor HV (2023) Adversarial attacks and defenses in machine learning-empowered communication systems and networks: a contemporary survey. IEEE Commun Surv Tutor. https://doi.org/10.1109/COMST.2023.3319492

48. Yuan L, Chen Y, Cui G, Gao H, Zou F, Cheng X, Ji H, Liu Z, Sun M (2024) Revisiting out-of-distribution robustness in NLP: benchmarks, analysis, and LLMs evaluations. Adv Neural Inf Process Syst 36

49. Liu B, Xiao B, Jiang X, Cen S, He X, Dou W (2023) Adversarial attacks on large language model-based system and mitigating strategies: a case study on ChatGPT. Secur Commun Netw 1:8691095

50. Alsmadi I, Aljaafari N, Nazzal M, Alhamed S, Sawalmeh AH, Vizcarra CP, Khreishah A, Anan M, Algosaibi A, Al-Naeem MA et al (2022) Adversarial machine learning in text processing: a literature survey. IEEE Access 10:17043-17077

51. He X, Wang J, Xu Q, Minervini P, Stenetorp P, Rubinstein BI, Cohn T (2024) Transferring troubles: cross-lingual transferability of backdoor attacks in LLMs with instruction tuning. arXiv preprint arXiv:2404.19597

52. Vassilev Apostol, Oprea Alina, Fordyce Alie, Anderson Hyrum (2024) Adversarial machine learning. Gaithersburg, Maryland

53. Jin D, Jin Z, Zhou JT, Szolovits P (2020) Is Bert really robust? A strong baseline for natural language attack on text classification and entailment. In: Proceedings of the AAAI conference on artificial intelligence ${34}\left( {05}\right)  : {8018} - {8025}$

54. Ren S, Deng Y, He K, Che W (2019) Generating natural language adversarial examples through probability weighted word saliency. In: Proceedings of the 57th annual meeting of the association for computational linguistics, pp 1085-1097

55. Li J, Ji S, Du T, Li B, Wang T (2019) Textbugger: generating adversarial text against real-world applications. In: 26th annual network and distributed system security symposium, NDSS 2019, San Diego, California, USA, 24-27 Feb, 2019. The Internet Society

56. Gao J, Lanchantin J, Soffa ML, Qi Y. Black-box generation of adversarial text sequences to evade (2018) Black-box generation of adversarial text sequences to evade deep learning classifiers. In: 2018 IEEE security and privacy workshops (SPW). IEEE, pp 50-56

57. Alzantot M, Sharma Y, Elgohary A, Ho BJ, Srivastava M, Chang KW (2018) Generating natural language adversarial examples. In: Riloff E, Chiang D, Hockenmaier J, Tsujii J (eds)Proceedings of the 2018 conference on empirical methods in natural language processing, Brussels, Belgium, October-November 2018. Association for Computational Linguistics, pp 2890-2896

58. Mrkšić N, Séaghdha DO, Thomson B, Gašić M, Rojas-Barahona LM, Su PH, Vandyke D, Wen T-H, Young S (2016) Counter-fitting word vectors to linguistic constraints. In: Knight K, Nenkova A, Rambow O (eds) Proceedings of the 2016 conference of the North American chapter of the association for computational linguistics: human language technologies, San Diego, California, June 2016. Association for Computational Linguistics, pp 142-148

59. Liang B, Li H, Su M, Bian P, Li X, Shi W (2018) Deep text classification can be fooled. In: Proceedings of the twenty-seventh international joint conference on artificial intelligence. International joint conferences on artificial intelligence organization

60. Glockner M, Shwartz V, Goldberg Y (2018) Breaking NLI systems with sentences that require simple lexical inferences. In: Gurevych I, Miyao Y (eds) Proceedings of the 56th annual meeting of the association for computational linguistics (volume 2: short papers), Melbourne, Australia, July. Association for Computational Linguistics, pp 650-655

61. Bowman SR, Angeli G, Potts C, Manning CD (2015) A large annotated corpus for learning natural language inference. In: Màrquez L, Callison-Burch C, Su J (eds) Proceedings of the 2015 conference on empirical methods in natural language processing, Lisbon, Portugal, September. Association for Computational Linguistics, pp 632-642

62. Lei Qi Wu, Lingfei Chen Pin-Yu, Alex Dimakis, Dhillon Inderjit S, Witbrock Michael J (2019) Discrete adversarial attacks and submodular optimization with applications to text classification. Proc Mach Learn Syst 1:146-165

63. Li H, Guo D, Fan W, Xu M, Huang J, Meng F, Song (2023) Multistep jailbreaking privacy attacks on ChatGPT. In HBouamor H, Pino J, Bali K (eds) Findings of the association for computational linguistics: EMNLP 2023, Singapore, . Association for Computational Linguistics, pp 4138-4153

64. Carlini N (2023) A LLM assisted exploitation of AI-Guardian. arXiv preprint arXiv:2307.15008

65. Liu Y, Deng G, Li Y, Wang K, Zhang T, Liu Y, Wang H, Zheng $\mathrm{Y}$ , Liu $\mathrm{Y}$ (2023) Prompt injection attack against $\mathrm{{llm}}$ -integrated applications. arXiv preprint arXiv:2306.05499

66. Chen Y, Arunasalam A, Celik ZB (2023) Can large language models provide security & privacy advice? Measuring the ability of llms to refute misconceptions. In: Proceedings of the 39th annual computer security applications conference, ACSAC '23, New York, NY, USA, 2023. Association for Computing Machinery, pp 366-378

67. Duan H, Dziedzic A, Yaghini M, Papernot N, Boenisch F (2023) On the privacy risk of in-context learning. In: The 61st Annual meeting of the association for computational linguistics

68. Xue J, Zheng M, Hua T, Shen Y, Liu Y, Bölöni L, Lou Q (2024) Trojllm: a black-box trojan prompt attack on large language models. Adv Neural Inf Process Syst 36:65665-65677

69. Perez F, Ribeiro I (2022) Ignore previous prompt: attack techniques for language models. arXiv preprint arXiv:2211.09527

70. Liu Y, Yao Y, Ton JF, Zhang X, Cheng RG, Klochkov Y, Taufiq MF, Li H (2023) trustworthy llms: a survey and guideline for evaluating large language models' alignment. In: Socially Responsible Language Modelling Research

71. Wei A, Haghtalab N, Steinhardt J (2024) Jailbroken: How does llm safety training fail? Adv Neural Inf Process Syst 36:80079- 80110

72. Ebrahimi J, Rao A, Lowd D, Dou D (2018) HotFlip: white-box adversarial examples for text classification. In: Gurevych I, Miyao $\mathrm{Y}$ (eds) Proceedings of the 56th annual meeting of the association for computational linguistics (volume 2: short papers), Melbourne, Australia, July. Association for Computational Linguistics, pp 31-36

73. Chen M, He G, Wu J (2024) ZDDR: a zero-shot defender for adversarial samples detection and restoration. IEEE Access. https://doi.org/10.1109/ACCESS.2024.3356568

74. Wallace E, Feng S, Kandpal N, Gardner M, Singh S (2019) Universal adversarial triggers for attacking and analyzing NLP. In: Inui K, Jiang J, Ng V, Wan X (eds) Proceedings of the 2019 conference on empirical methods in natural language processing and the 9th international joint conference on natural language processing (EMNLP-IJCNLP), Hong Kong, China, November 2019. Association for Computational Linguistics, pp 2153-2162

75. Pruthi D, Dhingra B, Lipton ZC (2019) Combating adversarial misspellings with robust word recognition. In: Korhonen A, Traum D, Màrquez L (eds) Proceedings of the 57th annual meeting of the association for computational linguistics, Florence, Italy, July . Association for Computational Linguistics, pp 5582-5591

76. Lim S, Schmälzle R (2023) Artificial intelligence for health message generation: an empirical study using a large language model (LLM) and prompt engineering. Front Commun 8:1129082

77. Jiang W, Li H, Xu G, Zhang T (2023) Color backdoor: a robust poisoning attack in color space. In: Proceedings of the IEEE/CVF conference on computer vision and pattern recognition, pp 8133- 8142

78. Bao R, Wang J, Zhao H (2021) Defending pre-trained language models from adversarial word substitution without performance sacrifice. In: Zong C, Xia F, Li W, Navigli R (eds) Findings of the association for computational linguistics: ACL-IJCNLP 2021, Online, August 2021. Association for Computational Linguistics, pp 3248-3258

79. Wang B, Pei H, Pan B, Chen Q, Wang S, Li B (2020) T3: tree-autoencoder constrained adversarial text generation for targeted attack. In: Webber B, Cohn T, He Y, Liu Y (eds) Proceedings of the 2020 conference on empirical methods in natural language processing (EMNLP), Online, November 2020. Association for Computational Linguistics, pp 6134-6150

80. Lin J, Zou J, Ding N (2021) Using adversarial attacks to reveal the statistical bias in machine reading comprehension models. In: Zong C, Xia F, Li W, Navigli R (eds) Proceedings of the 59th annual meeting of the association for computational linguistics and the 11th international joint conference on natural language processing (volume 2: short papers), Online, August 2021. Association for Computational Linguistics, pp 333-342

81. Gan WC, Ng HT (2019) Improving the robustness of question answering systems to question paraphrasing. In: Proceedings of the 57th annual meeting of the association for computational linguistics, pp 6065-6075

82. Zhang Y, Baldridge J, He L (2019) PAWS: paraphrase adversaries from word scrambling. In: Burstein J, Doran C, Solorio T (eds) Proceedings of the 2019 conference of the North American chapter of the association for computational linguistics: human language technologies, volume 1 (long and short papers), Minneapolis, Minnesota, June . Association for Computational Linguistics, pp 1298-1308

83. Kurita K, Michel P, Neubig G (2020) Weight poisoning attacks on pretrained models. In: Jurafsky D, Chai J, Schluter N, Tetreault J (eds) Proceedings of the 58th annual meeting of the association for computational linguistics, Online, July . Association for Computational Linguistics, pp 2793-2806

84. Han X, Zhang Z, Ding N, Gu Y, Liu X, Huo Y, Qiu J, Yao Y, Zhang A, Zhang L et al (2021) Pre-trained models: past, present and future. AI Open 2:225-250

85. Fursov I, Zaytsev A, Burnyshev P, Dmitrieva E, Klyuchnikov N, Kravchenko A, Artemova E, Komleva E, Burnaev E (2022) A differentiable language model adversarial attack on text classifiers. IEEE Access 10:17966-17976

86. Bajaj A, Vishwakarma DK (2023) Evading text based emotion detection mechanism via adversarial attacks. Neurocomputing 558:126787

87. Myers D, Mohawesh R, Chellaboina VI, Sathvik AL, Venkatesh $\mathrm{P},\mathrm{{Ho}}\mathrm{{YH}}$ , Henshaw H, Alhawawreh M, Berdik D, Jararweh Y (2024) Foundation and large language models: fundamentals, challenges, opportunities, and social impacts. Clust Comput 27(1):1-26

88. Xu X, Kong K, Liu N, Cui L, Wang D, Zhang J, Kankanhalli M (2024) An LLM can fool itself: a prompt-based adversarial attack. In: The twelfth international conference on learning representations

89. Wang T, Wang X, Qin Y, Packer B, Li K, Chen J, Beutel A, Chi E (2020) CAT-gen: improving robustness in NLP models via controlled adversarial text generation. In: Webber B, Cohn T, He $\mathrm{Y}$ , Liu $\mathrm{Y}$ (eds) Proceedings of the 2020 conference on empirical methods in natural language processing (EMNLP), Online, November 2020. Association for Computational Linguistics, pp 5141-5146

90. Qi F, Chen Y, Li M, Yao Y, Liu Z, Sun M (2021) ONION: a simple and effective defense against textual backdoor attacks. In: Moens MF, Huang X, Specia L, Yih SWT (eds) Proceedings of the 2021 conference on empirical methods in natural language processing, Online and Punta Cana, Dominican Republic, November (2021). Association for Computational Linguistics, pp 9558-9566

91. Zhang Z, Xiao G, Li Y, Lv T, Qi F, Liu Z, Wang Y, Jiang X, Sun M (2023) Red alarm for pre-trained models: universal vulnerability to neuron-level backdoor attacks. Mach Intell Res 20(2):180-193

92. Li L, Song D, Li X, Zeng J, Ma R, Qiu X (20121) Backdoor attacks on pre-trained models by layerwise weight poisoning. In: Moens MF, Huang X, Specia L, Yih SWT (eds) Proceedings of the 2021 conference on empirical methods in natural language processing, Online and Punta Cana, Dominican Republic, November 2021. Association for Computational Linguistics, pp 3023-3032

93. Cheng M, Yi J, Chen PY, Zhang H, Hsieh CJ (2020) Seq2sick: evaluating the robustness of sequence-to-sequence models with adversarial examples. In: Proceedings of the AAAI conference on artificial intelligence 34:3601-3608

94. Xie X, Wu J, Liu G, Lin Z (2024) SSCNet: learning-based subspace clustering. Vis Intell 2(1):11

95. Dong X, Luu AT, Ji R, Liu H (2021) Towards robustness against natural language word substitutions. In: International conference on learning representations

96. Blum O, Brattoli B, Ommer B (2019) X-GAN: improving generative adversarial networks with convex combinations. In: Pattern Recognition: 40th German conference, GCPR 2018, Stuttgart, Germany, October 9-12, 2018, proceedings 40. Springer, pp 199- 214

97. Szeghy D, Milacski ZA, Fóthi A, Lorincz A (2021) Adversarial perturbation stability of the layered group basis pursuit. def 1:2

98. Yuan L, Zeng J, Zheng X (2021) Sparsegan: sparse generative adversarial network for text generation. arXiv preprint arXiv:2103.11578

99. Tsiligkaridis T, Roberts J (2022) Understanding and increasing efficiency of Frank-Wolfe adversarial training. In: Proceedings of the IEEE/CVF conference on computer vision and pattern recognition, pp 50-59

100. La Malfa E (2023) On robustness for natural language processing. PhD thesis, University of Oxford

101. Steinhardt J, Koh PW, Liang PS (2017) Certified defenses for data poisoning attacks. In: I. Guyon and U. Von Luxburg and S. Bengio and H. Wallach and R. Fergus and S. Vishwanathan and R.Garnett (eds) Curran Associates, Inc. Adv Neural Inf Process Syst 30. https://proceedings.neurips.cc/paper_files/paper/2017/ file/9d7311ba459f9e45ed746755a32dcd11-Paper.pdf

102. Raghunathan A, Steinhardt J, Liang P (2018) Certified defenses against adversarial examples. In: 6th International conference on learning representations, ICLR 2018, Vancouver, BC, Canada, April 30-May 3, 2018, conference track proceedings. OpenRe-view.net

103. Wang W, Tang P, Lou J, Xiong L (2021) Certified robustness to word substitution attack with differential privacy. In: Proceedings of the 2021 conference of the North American chapter of the association for computational linguistics: human language technologies, pp 1102-1112

104. Sato M, Suzuki J, Shindo H, Matsumoto Y (2018) Interpretable adversarial perturbation in input embedding space for text. In: Proceedings of the 27th international joint conference on artificial intelligence, IJCAI'18. AAAI Press, pp 4323-4330

105. Gong Z, Wang W, Li B, Song D, Ku WS (2018) Adversarial texts with gradient methods (01)

106. Jia R, Raghunathan A, Göksel K, Liang P (2019) Certified robustness to adversarial word substitutions. In: Inui K, Jiang $\mathrm{J},\mathrm{{Ng}}\mathrm{V}$ , Wan $\mathrm{X}$ (eds) Proceedings of the 2019 conference on empirical methods in natural language processing and the 9th international joint conference on natural language processing (EMNLP-IJCNLP), Hong Kong, China, November 2019. Association for Computational Linguistics, pp 4129-4142

107. Huang PS, Stanforth R, Welbl J, Dyer C, Yogatama D, Gowal S, Dvijotham K, Kohli P (2019) Achieving verified robustness to symbol substitutions via interval bound propagation. In: Inui $\mathrm{K}$ , Jiang J, $\mathrm{{Ng}}\mathrm{V}$ , Wan $\mathrm{X}$ (eds) Proceedings of the 2019 conference on empirical methods in natural language processing and the 9th international joint conference on natural language processing (EMNLP-IJCNLP), Hong Kong, China, November 2019. Association for Computational Linguistics, pp 4083-4093

108. Dong X (2022) Adversarial attacks and defenses in natural language processing

109. Madry A, Makelov A, Schmidt L, Tsipras D, Vladu A (2018) Towards deep learning models resistant to adversarial attacks. In: 6th International conference on learning Representations, ICLR 2018, Vancouver, BC, Canada, April 30-May 3, 2018, conference track proceedings. OpenReview.net

110. Yoo JY, Morris JX, Lifland E, Qi Y (2020) Searching for a search method: Benchmarking search algorithms for generating NLP adversarial examples. In: Alishahi A, Belinkov Y, Chrupata G, Hupkes D, Pinter Y, Sajjad H (eds) Proceedings of the third Black-boxNLP workshop on analyzing and interpreting neural networks for NLP, Online, November 2020. Association for Computational Linguistics, pp 323-332

111. Barham S, Feizi S (2019) Interpretable adversarial training for text. arXiv preprint arXiv:1905.12864

112. Papernot N, McDaniel P, Swami A, Harang R (2016) Crafting adversarial input sequences for recurrent neural networks. In: MILCOM 2016-2016 IEEE military communications conference. IEEE, pp 49-54

113. Miyato T, Dai AM, Goodfellow I (2016) Adversarial training methods for semi-supervised text classification. arXiv preprint arXiv:1605.07725

114. Guo C, Sablayrolles A, Jégou H, Kiela D (2021) Gradient-based adversarial attacks against text transformers. In: Moens MF, Huang X, Specia L, Yih SWT (eds) Proceedings of the 2021 conference on empirical methods in natural language processing, Online and Punta Cana, Dominican Republic, November 2021. Association for Computational Linguistics, pp 5747-5757

115. Sadrizadeh S , Dolamic L, Frossard P (2022) Block-sparse adversarial attack to fool transformer-based text classifiers. In: ICASSP 2022-2022 IEEE international conference on acoustics, speech and signal processing (ICASSP). IEEE, pp 7837-7841

116. Costa JC, Roxo T, Proença H, Inácio PRM. How deep learning sees the world: a survey on adversarial attacks & defenses. IEEE Access (2024)

117. Birbil ŞI, Fang SC, Sheu RL (2004) On the convergence of a population-based global optimization algorithm. J Glob Optim 30:301-318

118. Khormali A, Nyang D, Mohaisen D (2020) Generating adversarial examples with an optimized quality. arXiv preprint arXiv:2007.00146

119. Jia R (2020) Building robust natural language processing systems. Stanford University, Stanford

120. Morris JX, Lifland E, Yoo JY, Grigsby J, Jin D, Qi Y (2020) TextAttack: a framework for adversarial attacks, data augmentation, and adversarial training in NLP. In: Liu Q, Schlangen D (eds) Proceedings of the 2020 conference on empirical methods in natural language processing: system demonstrations, Online, October. Association for Computational Linguistics, pp 119-126

121. Zang Y, Qi F, Yang C, Liu Z, Zhang M, Liu Q, Sun M (2020) Word-level textual adversarial attacking as combinatorial optimization. In: Jurafsky D, Chai J, Schluter N, Tetreault J (eds) Proceedings of the 58th annual meeting of the association for computational linguistics, Online, July 2020. Association for Computational Linguistics, pp 6066-6080

122. Maheshwary R, Maheshwary S, Pudi V (2021) Generating natural language attacks in a hard label black box setting. In: Proceedings of the AAAI conference on artificial intelligence 35:13525-13533

123. Jasser J, Garibay I (2021) Resilience from diversity: population-based approach to harden models against adversarial attacks. arXiv preprint arXiv:2111.10272

124. Garg S, Ramakrishnan G (eds) BAE: BERT-based adversarial examples for text classification. In: Webber B, Cohn T, He Y, Liu $\mathrm{Y}$ (eds) Proceedings of the 2020 conference on empirical methods in natural language processing (EMNLP), Online, November 2020. Association for Computational Linguistics, pp 6174-6181

125. Jin D, Jin Z, Zhou JT, Szolovits P (2020) Is BERT really robust? A strong baseline for natural language attack on text classification and entailment. In: Proceedings of the AAAI conference on artificial intelligence 34:8018-8025

126. Maheshwary R, Maheshwary S, Pudi V (2021) A strong baseline for query efficient attacks in a black box setting. In: Moens MF, Huang X, Specia L, Yih SWT (eds) Proceedings of the 2021 conference on empirical methods in natural language processing, Online and Punta Cana, Dominican Republic, November 2021. Association for Computational Linguistics, pp 8396-8409

127. Wang B, Xu C, Liu X, Cheng Y, Li B (2022) SemAttack: natural textual attacks via different semantic spaces. In: Carpuat M, De Marneffe MC, Meza Ruiz IV (eds) Findings of the association for computational linguistics: NAACL 2022, Seattle, United States, July 2022. Association for Computational Linguistics, pp 176- 205

128. Lee D, Moon S, Lee J, Song HO (2022) Query-efficient and scalable black-box adversarial attacks on discrete sequential data via Bayesian optimization. In: International conference on machine learning. PMLR, pp 12478-12497

129. Peng H, Wang Z, Zhao D, Wu Y, Han J, Guo S, Ji S, Zhong M (2023) Efficient text-based evolution algorithm to hard-label adversarial attacks on text. J King Saud Univ Comput Inf Sci 35(5):101539

130. Liu Y, Huang Y, Cai Z (2023) AED: An black-box NLP classifier model attacker. Neurocomputing 550:126489

131. Caucheteux C, Gramfort A, King JR (2021) GPT-2's activations predict the degree of semantic comprehension in the human brain. BioRxiv, pp 2021-2004

132. Goldstein A, Zada Z, Buchnik E, Schain M, Price A, Aubrey B, Nastase SA, Feder A, Emanuel D, Cohen A et al (2022) Shared computational principles for language processing in humans and deep language models. Nat Neurosci 25(3):369-380

133. Heilbron M, Armeni K, Schoffelen JM, Hagoort P, De Lange FP (2022) A hierarchy of linguistic predictions during natural language comprehension. In: Proceedings of the national academy of sciences, 119(32):e2201968119

134. Kumar S, Sumers TR, Yamakoshi T, Goldstein A, Hasson U, Norman KA, Griffiths TL, Hawkins RD, Nastase SA (2022) Reconstructing the cascade of language processing in the brain using the internal computations of a transformer-based language model. BioRxiv, pp 2022-2006

135. Bastings J, Filippova K (2020) The elephant in the interpretability room: Why use attention as explanation when we have saliency methods? In: Alishahi A, Belinkov Y, Chrupafa G, Hupkes D, Pinter Y, Sajjad H (eds) Proceedings of the third BlackboxNLP workshop on analyzing and interpreting neural networks for NLP, Online, November 2020. Association for Computational Linguistics, pp 149-155

136. Ghojogh B, GhodsiA(2020) Attentionmechanism, transformers, BERT, and GPT: OSF Preprints tutorial and survey 12. https:// www.researchgate.net/profile/Benyamin-Ghojogh/publication/ 347623569_Attention_Mechanism_Transformers_BERT_and_ GPT_Tutorial_and_Survey/links/640e5b3aa1b72772e4eea211/ Attention-Mechanism-Transformers-BERT-and-GPT-Tutorial-and-Survey.pdf

137. Sundararajan M, Taly A, Yan Q (2017) Axiomatic attribution for deep networks. In: International conference on machine learning. PMLR, pp 3319-3328

138. Shrikumar A, Greenside P, Kundaje A (2017) Learning important features through propagating activation differences. In: International conference on machine learning. PMLR, pp 3145-3153

139. Chen J, Song L, Wainwright M, Jordan M (2018) Learning to explain: an information-theoretic perspective on model interpretation. In: International conference on machine learning. PMLR, pp 883-892

140. Zang Y, Hou B, Qi F, Liu Z, Meng X, Sun M (2020) Learning to attack: towards textual adversarial attacking in real-world situations. arXiv preprint arXiv:2009.09192

141. Roth T, Gao Y, Abuadbba A, Nepal S, Liu W (2024) Token-modification adversarial attacks for natural language processing: a survey. AI Commun (04):1-22

142. Cheng R, Jin Y (2014) A competitive swarm optimizer for large scale optimization. IEEE Trans Cybern 45(2):191-204

143. Yang Q, Chen WN, Da Deng J, Li Y, Gu T, Zhang J (2017) A level-based learning swarm optimizer for large-scale optimization. IEEE Trans Evolut Comput 22(4):578-594

144. Li X, Yao X (2011) Cooperatively coevolving particle swarms for large scale optimization. IEEE Trans Evolut Comput 16(2):210- 224

145. Mounsif M, Zehnder K, Motie Y, Adam-Gaxotte Z (2023) Swar-Mind: harnessing large language models for flock dynamics. In: 2023 10th international conference on soft computing & machine intelligence (ISCMI). IEEE, pp 171-177 (2023)

146. Wang Q, Guo P, Sun S, Xie L, Hansen JH (2019) Adversarial regularization for end-to-end robust speaker verification. In: Interspeech, pp 4010-4014

147. Abdelali A, Mubarak H, Chowdhury S, Hasanain M, Mousi B, Boughorbel S, Abdaljalil S, Kheir YE, Izham D, Dalvi F, Hawasly M, Nazar N, Elshahawy Y, Ali A, Durrani N, Milic-Frayling N, Alam F (2024) LAraBench: benchmarking Arabic AI with large language models. In: Graham Y, Purver M (eds) Proceedings of the 18th conference of the European chapter of the association for computational linguistics (volume 1: long papers), St. Julian's, Malta, March 2024. Association for Computational Linguistics, pp 487-520

148. Bang Y, Cahyawijaya S, Lee N, Dai W, Su D, Wilie B, Lovenia H, Ji Z, Yu T, Chung W, Do QV (2023) A multitask, multilingual, multimodal evaluation of ChatGPT on reasoning, hallucination, and interactivity. In: Park JC, Arase Y, Hu B, Lu W, Wijaya D, Purwarianti A, Krisnadhi AA (eds) Proceedings of the 13th international joint conference on natural language processing and the 3rd conference of the Asia-Pacific chapter of the association for computational linguistics (volume 1: long papers), Nusa Dua, Bali, November 2023. Association for Computational Linguistics, pp 675-718

149. Chen Y, Wang R, Jiang H, Shi S, Xu R (2023) Exploring the use of large language models for reference-free text quality evaluation: an empirical study (01):361-374

150. Choi M, Pei J, Kumar S, Shu C, Jurgens D (2023) Do LLMs understand social knowledge? Evaluating the sociability of large language models with SocKET benchmark. In: Bouamor H, Pino J, Bali LK (eds) Proceedings of the 2023 conference on empirical methods in natural language processing, Singapore, December 2023. Association for Computational Linguistics, pp 11370- 11403

151. Chia YK, Hong P, Bing L, Poria S (2024) InstructEval: towards holistic evaluation of instruction-tuned large language models. In: Miceli-Barone AV, Barez F, Cohen S, Voita E, Germann U, Lukasik M (eds) Proceedings of the first edition of the workshop on the scaling behavior of large language models (SCALE-LLM 2024), St. Julian's, Malta, March 2024. Association for Computational Linguistics, pp 35-64

152. Fu Y, Ou L, Chen M, Wan Y, Peng H, Khot T (2023) Chain-of-thought hub: a continuous effort to measure large language models' reasoning performance. arXiv preprint arXiv:2305.17306

153. Gekhman Z, Herzig J, Aharoni R, Elkind C, Szpektor I (2023) Trueteacher: learning factual consistency evaluation with large language models. In: The 2023 conference on empirical methods in natural language processing

154. Honovich O, Aharoni R, Herzig J, Taitelbaum H, Kukliansy D, Cohen V, Scialom T, Szpektor I, Hassidim A, Matias Y (2022) TRUE: re-evaluating factual consistency evaluation. In: Feng S, Wan H, Yuan C, Yu H (eds) Proceedings of the second DialDoc workshop on document-grounded dialogue and conversational question answering, Dublin, Ireland, May 2022. Association for Computational Linguistics, pp 161-175

155. Lai VD, Ngo NT, Veyseh AP, Man H, Dernoncourt F, Bui T, Nguyen TH (2023)ChatGPT beyond English: towards a comprehensive evaluation of large language models in multilingual learning. In: Bouamor H, Pino J, Bali K (eds) Findings of the association for computational linguistics: EMNLP 2023, Singapore, December 2023. Association for Computational Linguistics, pp 13171-13189

156. Lopez-Lira A, Tang Y (2023) Can chatgpt forecast stock price movements? return predictability and large language models. In: Return predictability and large language models (April 6, 2023)

157. Durmus E, Nyugen K, Liao TI, Schiefer N, Askell A, Bakhtin A, Chen C, Hatfield-Dodds Z, Hernandez D, Joseph N et al (2023) Towards measuring the representation of subjective global opinions in language models. arXiv preprint arXiv:2306.16388

158. Lin YT, Chen YN (2023) LLM-eval: Unified multi-dimensional automatic evaluation for open-domain conversations with large language models. In: Chen YN, Rastogi A (eds) Proceedings of the 5th workshop on NLP for conversational AI (NLP4ConvAI 2023), Toronto, Canada, July 2023. Association for Computational Linguistics, pp 47-58

159. Liu H, Ning R, Teng Z, Liu J, Zhou Q, Zhang Y (2023) Evaluating the logical reasoning ability of ChatGPT and GPT-4. arXiv preprint arXiv:2304.03439

160. Zhang Y, Xiang T, Hospedales TM, Lu H (2018) Deep mutual learning. In: Proceedings of the IEEE conference on computer vision and pattern recognition, pp 4320-4328

161. Brown T, Mann B, Ryder N, Subbiah M, Kaplan JD, Dhariwal P, Neelakantan A, Shyam P, Sastry G, Askell A et al (2020) Language models are few-shot learners. Adv Neural Inf Process Syst 33:1877-1901

162. He P, Liu X, Gao J, Chen W (2020) Deberta: decoding-enhanced BERT with disentangled attention. In: International conference on learning representations

163. Yang Y, Lv H, Chen N (2022) A survey on ensemble learning under the era of deep learning. Artif Intell Rev 56(6):5545-5589

164. Dong X, Yu Z, Cao W, Shi Y, Ma Q (2020) A survey on ensemble learning. Front Comput Sci 14:241-258

165. Zhu X, Gong (2018) Knowledge distillation by on-the-fly native ensemble. Adv Neural Inf Process Syst 31

166. Chen D, Mei JP, Wang C, Feng Y, Chen C (2020) Online knowledge distillation with diverse peers. In: Proceedings of the AAAI conference on artificial intelligence 34:3430-3437

167. Li Z, Huang Y, Chen D, Luo T, Cai N, Pan Z (2020) Online knowledge distillation via multi-branch diversity enhancement. In: Proceedings of the Asian conference on computer vision

168. Liu X, Wang Y, Ji J, Cheng H, Zhu X, Awa E, He P, Chen W, Poon H, Cao G et al (2020) The microsoft toolkit of multi-task deep neural networks for natural language understanding. In: Proceedings of the 58th annual meeting of the association for computational linguistics: system demonstrations, pp 118-126

169. Luong MT, Le QV, Sutskever I, Vinyals O, Kaiser L (2016) Multitask sequence to sequence learning. In: Bengio Y, LeCun Y (eds) 4th international conference on learning representations, ICLR 2016, San Juan, Puerto Rico, May 2-4, 2016, conference track proceedings

170. Ruder S, Bingel J, Augenstein I, Søgaard A (2019) Latent multi-task architecture learning. In: Proceedings of the AAAI conference on artificial intelligence 33:4822-4829

171. Ramé A, Cord M (2021) Dice: Diversity in deep ensembles via conditional redundancy adversarial estimation. In: ICLR 2021-9th international conference on learning representations

172. Feng S, Chen H, Ren X, Ding Z, Li K, Sun X (2021) Collaborative group learning

173. Wu G, Gong S (2021) Peer collaborative learning for online knowledge distillation. In: Proceedings of the AAAI conference on artificial intelligence 35:10302-10310

174. Gehman S, Gururangan S, Sap M, Choi Y, Smith NA (2020) RealToxicityPrompts: Evaluating neural toxic degeneration in language models. In: Cohn T, He Y, Liu Y (eds) Findings of the association for computational linguistics: EMNLP 2020, Online, November 2020. Association for Computational Linguistics, pp 3356-3369

175. Maus N, Chao P, Wong E, Gardner J (2023) Adversarial prompting for black box foundation models. arXiv preprint arXiv:2302.04237

176. Shin T, Razeghi Y, Logan IV RL, Wallace E, Singh S (2020) Autoprompt: eliciting knowledge from language models with automatically generated prompts. In: Proceedings of the 2020 conference on empirical methods in natural language processing (EMNLP), pages 4222-4235

177. Zou A, Wang Z, Kolter JZ, Fredrikson M (2023) Universal and transferable adversarial attacks on aligned language models

178. Goyal S, Doddapaneni S, Khapra MM, Ravindran B (2023) A survey of adversarial defenses and robustness in NLP. ACM Comput Surv 55(14s):1-39

179. Liu X, Cheng H, He P, Chen W, Wang Y, Poon H, Gao J (2020) Adversarial training for large neural language models. arXiv preprint arXiv:2004.08994

180. Jain N, Schwarzschild A, Wen Y, Somepalli G, Kirchenbauer J, Chiang PY, Goldblum M, Saha A, Geiping J, Goldstein T (2024) Baseline defenses for adversarial attacks against aligned language models

181. Kumar A, Agarwal C, Srinivas S, Feizi S, Lakkaraju H (2023) Certifying llm safety against adversarial prompting. arXiv preprint arXiv:2309.02705

182. Vaswani A, Shazeer N, Parmar N, Uszkoreit J, Jones L, Gomez AN, Kaiser L, Polosukhin I (2017) Attention is all you need. In: I. Guyon and U. Von Luxburg and S. Ben-gio and H. Wallach and R. Fergus and S. Vishwanathan and R. Garnett Curran Associates, Inc. Adv Neural Inf Process Syst 30. https://proceedings.neurips.cc/paper_files/paper/2017/ file/3f5ee243547dee91fbd053c1c4a845aa-Paper.pdf

183. Radford A, Wu J, Child R, Luan D, Amodei D, Sutskever I (2019) Language models are unsupervised multitask learners. OpenAI Blog 1(8):9

184. Conneau A, Khandelwal K, Goyal N, Chaudhary V, Wenzek G, Guzmán F, Grave E, Ott M, Zettlemoyer L, Stoyanov V (2020) Unsupervised cross-lingual representation learning at scale. In: Jurafsky D, Chai J, Schluter N, Tetreault J (eds) Proceedings of the 58th annual meeting of the association for computational linguistics, Online, July 2020. Association for Computational Linguistics, pp 8440-8451

185. Carlini N, Liu C, Erlingsson U, Kos J, Song D (2019) The secret sharer: evaluating and testing unintended memorization in neural networks. In: 28th USENIX security symposium (USENIX security 19), pp 267-284

186. Kawaguchi K, Kaelbling LP, Bengio Y (2022) Generalization in deep learning. In: Grohs P, Kutyniok G (eds) Mathematical aspects of deep learning. Cambridge University Press, Cambridge

187. Brown G, Bun M, Feldman V, Smith A, Talwar K (2021) When is memorization of irrelevant training data necessary for high-accuracy learning? In: Proceedings of the ${53}\mathrm{{rd}}$ annual ACM SIGACT symposium on theory of computing, pp 123-132

188. Dwork C, McSherry F, Nissim K, Smith A (2006) Calibrating noise to sensitivity in private data analysis. In: Theory of cryptography: third theory of cryptography conference, TCC 2006, New York, NY, USA, March 4-7, 2006. proceedings 3. Springer, pp 265-284

189. Song S, Chaudhuri K, Sarwate AD (2013) Stochastic gradient descent with differentially private updates. In: 2013 IEEE global conference on signal and information processing. IEEE, pp 245- 248

190. Abadi M, Chu A, Goodfellow I, McMahan HB, Mironov I, Talwar K, Zhang L (2016) Deep learning with differential privacy. In: Proceedings of the 2016 ACM SIGSAC conference on computer and communications security, pp 308-318

191. Li X, Tramer F, Liang P, Hashimoto T (2021) Large language models can be strong differentially private learners. In: International conference on learning representations

192. Majmudar J, Dupuy C, Peris C, Smaili S, Gupta R, Zemel R (2022) Differentially private decoding in large language models

193. Dupuy C, Arava R, Gupta R, Rumshisky A (2022) An efficient dp-sgd mechanism for large scale NLU models. In: ICASSP 2022-2022 IEEE international conference on acoustics, speech and signal processing (ICASSP). IEEE, pp 4118-4122

194. Dagan Y, Feldman V (2020) Pac learning with stable and private predictions. In: Conference on learning theory. PMLR, pp 1389- 1410

195. Buckman J, Roy A, Raffel C, Goodfellow I (2018) Thermometer encoding: one hot way to resist adversarial examples. In: International conference on learning representations

196. Guo C, Rana M, Cisse M, Van Der Maaten L (2018) Countering adversarial images using input transformations. In: International conference on learning representations

197. Dhillon GS, Azizzadenesheli K, Lipton ZC, Bernstein J, Kossaifi J, Khanna A, Anandkumar A (2018) Stochastic activation pruning for robust adversarial defense. In: International conference on learning representations

198. Grosse K, Manoharan P, Papernot N, Backes M, McDaniel P (2017) On the (statistical) detection of adversarial examples. CoRR

199. Gong Z, Wang W (2023) Adversarial and clean data are not twins. In: Proceedings of the sixth international workshop on exploiting artificial intelligence techniques for data management, pp 1-5

200. Minh DN, Luu AT (2022) Textual manifold-based defense against natural language adversarial examples. In: Proceedings of the 2022 conference on empirical methods in natural language processing, pp 6612-6625

201. Yoo K, Kim J, Jang J, Kwak N (2022) Detection of adversarial examples in text classification: benchmark and baseline via robust density estimation. In: Muresan S, Nakov P, Villavicencio A (eds) Findings of the association for computational linguistics: ACL 2022, Dublin, Ireland, May 2022. Association for Computational Linguistics, pp 3656-3672

202. Huber L, Kühn MA, Mosca E, Groh G (2022) Detecting word-level adversarial text attacks via shapley additive explanations. In: Proceedings of the 7th workshop on representation learning for NLP, pp 156-166

203. Carlini N, Wagner D (2017) Adversarial examples are not easily detected: bypassing ten detection methods. In: Proceedings of the 10th ACM workshop on artificial intelligence and security, pp 3-14

204. Athalye A, Carlini N, Wagner D (2018) Obfuscated gradients give a false sense of security: circumventing defenses to adversarial examples. In: International conference on machine learning. PMLR, pp 274-283

205. Uesato J, O'donoghue B, Kohli P, Oord A (2018) Adversarial risk and the dangers of evaluating against weak attacks. In: International conference on machine learning. PMLR, pp 5025-5034

206. Laidlaw C, Feizi S (2019) Functional adversarial attacks. In: H. Wallach and H. Larochelle and A. Beygelzimer and F. d'Alché- Buc and E. Fox and R. Garnett Curran Associates, Inc. Adv Neural Inf Process Syst 32. https://proceedings.neurips.cc/paper_files/ paper/2019/file/6e923226e43cd6fac7cfe1e13ad000ac-Paper.pdf

207. Gowal S, Dvijotham K, Stanforth R, Bunel R, Qin C, Uesato J, Arandjelovic R, Mann T, Kohli P (2018) On the effectiveness of interval bound propagation for training verifiably robust models. arXiv preprint arXiv:1810.12715

208. Dvijotham K, Gowal S, Stanforth R, Arandjelovic R, O'Donoghue B, Uesato J, Kohli P (2018) Training verified learners with learned verifiers. arXiv preprint arXiv:1805.10265

209. Mirman M, Gehr T, Vechev M (2018) Differentiable abstract interpretation for provably robust neural networks. In: International conference on machine learning. PMLR, pp 3578-3586

210. Wong E, Kolter Z (2018) Provable defenses against adversarial examples via the convex outer adversarial polytope. In: International conference on machine learning. PMLR, pp 5286-5295

211. Raghunathan A, Steinhardt J, Liang PS (02018) Semidefinite relaxations for certifying robustness to adversarial examples. In: S. Bengio and H. Wallach and H. Larochelle and K. Grauman and N. Cesa-Bianchi and R. Garnett Curran Associates, Inc. Adv Neural Inf Process Syst 31. https://proceedings.neurips.cc/paper_ files/paper/2018/file/29c0605a3bab4229e46723f89cf59d83- Paper.pdf

212. Singla S, Feizi S (2020) Second-order provable defenses against adversarial attacks. In: International conference on machine learning. PMLR, pp 8981-8991

213. Cohen J, Rosenfeld E, Kolter Z (2019) Certified adversarial robustness via randomized smoothing. In: International conference on machine learning. PMLR, pp 1310-1320

214. Lecuyer M, Atlidakis V, Geambasu R, Hsu D, Jana S (2019) Certified robustness to adversarial examples with differential privacy. In: 2019 IEEE symposium on security and privacy (SP). IEEE, pp 656-672

215. Li X, Li F (2017) Adversarial examples detection in deep networks with convolutional filter statistics. In: Proceedings of the IEEE international conference on computer vision, pp 5764-5772

216. Salman H, Li J, Razenshteyn I, Zhang P, Zhang H, Bubeck S, Yang G (2019) Provably robust deep learning via adver-sarially trained smoothed classifiers. In: H. Wallach and H. Larochelle and A.Beygelzimer and F. d'Alché-Buc and E. Fox and R. Garnett Curran Associates, Inc. Adv Neural Inf Process Syst 32. https://proceedings.neurips.cc/paper_files/paper/2019/ file/3a24b25a7b092a252166a1641ae953e7-Paper.pdf

217. Ye M, Gong C, Liu Q (2020) SAFER: a structure-free approach for certified robustness to adversarial word substitutions. In: Jurafsky D, Chai J, Schluter N, Tetreault J (eds) Proceedings of the 58th annual meeting of the association for computational linguistics, Online, July. Association for Computational Linguistics, pp 3465- 3475

218. Zhao H, Ma C, Dong X, Luu AT, Deng ZH, Zhang H (2022) Certified robustness against natural language attacks by causal intervention. In: International conference on machine learning. PMLR, pp 26958-26970

219. Zhang Z, Zhang G, Hou B, Fan W, Li Q, Liu S, Zhang Y, Chang S (2023) Certified robustness for large language models with self-denoising. arXiv preprint arXiv:2307.07171

220. Bakhtin A, Gross S, Ott M, Deng Y, Ranzato MA, Szlam A (2019) Real or fake? Learning to discriminate machine from human generated text. arXiv preprint arXiv:1906.03351

221. Uchendu A, Le T, Shu K, Lee D (2020) Authorship attribution for neural text generation. In: Proceedings of the 2020 conference on empirical methods in natural language processing (EMNLP), pp 8384-8395

222. Antoun W, Mouilleron V, Sagot B, Seddah D (2023) Towards a robust detection of language model-generated text: is Chat-GPT that easy to detect? In: Servan C, Vilnat A (eds) Actes de CORIA-TALN 2023. Actes de la 30e Conférence sur le Traite-ment Automatique des Langues Naturelles (TALN), volume 1 : travaux de recherche originaux-articles longs, Paris, France, 6 2023. ATALA, pp 14-27

223. Li Y, Li Q, Cui L, Bi W, Wang L, Yang L, Shi S, Zhang $\mathrm{Y}$ (2023) Deepfake text detection in the wild. arXiv preprint arXiv:2305.13242

224. Liu Y, Ott M, Goyal N, Du J, Joshi M, Chen D, Levy O, Lewis M, Zettlemoyer L, Stoyanov V (2020) Roberta: a robustly optimized BERT pretraining approach

225. Fagni T, Falchi F, Gambini M, Martella A, Tesconi M (2021) TweepFake: about detecting deepfake tweets. PLoS ONE 16(5):e0251415

226. Wu J, Yang S, Zhan R, Yuan Y, Wong DF, Chao LS (2023) A survey on LLM-gernerated text detection: necessity, methods, and future directions. arXiv preprint arXiv:2310.14724

227. Zuccon G, Koopman B, Shaik R (2023) ChatGPT hallucinates when attributing answers. In: Proceedings of the annual international ACM SIGIR conference on research and development in information retrieval in the Asia Pacific region, SIGIR-AP '23, New York, NY, USA, 2023. Association for Computing Machinery, page 46-51

228. Liu Y, Zhang Z, Zhang W, Yue S, Zhao X, Cheng X, Zhang Y, $\mathrm{{HuH}}$ (2023) Argugpt: evaluating, understanding and identifying argumentative essays generated by GPT models. arXiv preprint arXiv:2304.07666

229. Liu Z, Yao Z, Li F, Luo B (2023) Check me if you can: detecting ChatGPT-generated academic writing using checkgpt. arXiv preprint arXiv:2306.05524

230. Chen Y, Kang H, Zhai V, Li L, Singh R, Raj B (2023) GPT-sentinel: distinguishing human and chatgpt generated content. arXiv preprint arXiv:2305.07969

231. Yan Y, Li R, Wang S, Zhang F, Wu W, Xu W (2021) ConSERT: a contrastive framework for self-supervised sentence representation transfer. In: Zong C, Xia F, Li W, Navigli R (eds) Proceedings of the 59th annual meeting of the association for computational linguistics and the 11th international joint conference on natural language processing (volume 1: long papers), Online, August (2021). Association for Computational Linguistics, pp 5065-5075

232. Gao T, Yao X, Chen D (2021) SimCSE: simple contrastive learning of sentence embeddings. In: Moens MF, Huang X, Specia L, Yih SWT (eds) Proceedings of the 2021 conference on empirical methods in natural language processing, Online and Punta Cana, Dominican Republic, November (2021). Association for Computational Linguistics, pp 6894-6910

233. Chen Q, Zhang R, Zheng Y, Mao Y (2022) Dual contrastive learning: text classification via label-aware data augmentation. arXiv preprint arXiv:2201.08702

234. Liu X, Zhang Z, Wang Y, Pu H, Lan Y, Shen C (2023) Coco: coherence-enhanced machine-generated text detection under low resource with contrastive learning (01):16167-16188

235. Zhong W, Tang D, Xu Z, Wang R, Duan N, Zhou M, Wang J, Yin J (2020) Neural deepfake detection with factual structure of text. In: Webber B, Cohn T, He Y, Liu Y (eds) Proceedings of the 2020 conference on empirical methods in natural language processing (EMNLP), Online, November 2020. Association for Computational Linguistics, pp 2461-2470

236. Bhattacharjee A, Kumarage T, Moraffah R, Liu H. (2023) ConDA: contrastive domain adaptation for AI-generated text detection. In: Park JC, Arase Y, Hu B, Lu W, Wijaya D, Purwarianti A, Krisnadhi AA (eds) Proceedings of the 13th international joint conference on natural language processing and the 3rd conference of the Asia-Pacific chapter of the association for computational linguistics (volume 1: long Papers), Nusa Dua, Bali, November 2023. Association for Computational Linguistics, pp 598-610

237. Ullah S, Han M, Pujar S, Pearce H, Coskun A, Stringhini G (2024) LLMS cannot reliably identify and reason about security vulnerabilities (yet?): A comprehensive evaluation, framework, and benchmarks. In: IEEE symposium on security and privacy

238. Roshan K, Zafar A (2024) Black-box adversarial transferability: an empirical study in cybersecurity perspective. Comput Secur 141:103853

239. Zhao Y, Pang T, Du C, Yang X, Li C, Cheung NM, Lin M (2014) On evaluating adversarial robustness of large vision-language models. Adv Neural Inf Process Syst 36:54111-54138

240. Akhtar N, Mian A, Kardan N, Shah M (2021) Advances in adversarial attacks and defenses in computer vision: a survey. IEEE Access 9:155161-155196

241. Demontis A, Melis M, Pintor M, Jagielski M, Biggio B, Oprea A, Nita-Rotaru C, Roli F (2019) Why do adversarial attacks transfer? Explaining transferability of evasion and poisoning attacks. In: 28th USENIX security symposium (USENIX security 19), pp 321-338

242. Le T, Wang S, Lee D (2020) Malcom: generating malicious comments to attack neural fake news detection models. In: 2020 IEEE international conference on data mining (ICDM). IEEE, pp 282- 291

243. Zhang D, Zhang T, Lu Y, Zhu Z, Dong (2019) You only propagate once: accelerating adversarial training via-maximal principle. In: H. Wallach and H. Larochelle and A. Beygelzimer and F. d'Alché-Buc and E. Fox and R. Garnett Curran Associates, Inc. Adv Neural Inf Process Syst 32. https://proceedings.neurips.cc/paper_files/paper/2019/ file/812b4ba287f5ee0bc9d43bbf5bbe87fb-Paper.pdf

244. Shafahi A, Najibi M, Ghiasi MA, Xu Z, Dickerson J, Studer C, Davis LS, Taylor G, Goldstein T (2019) Adversarial training for free! In: H. Wallach and H. Larochelle and A. Beygelzimer and F. d'Alché-Buc and E. Fox and R. Garnett Curran Associates, Inc. Adv Neural Inf Process Syst 32

245. Peris C, Dupuy C, Majmudar J, Parikh R, Smaili S, Zemel R, Gupta R (2023) Privacy in the time of language models. In: Proceedings of the sixteenth ACM international conference on web search and data mining, pp 1291-1292

246. Madry A, Makelov A, Schmidt L, Tsipras D, Vladu A (2018) Towards deep learning models resistant to adversarial attacks. In: International conference on learning representations

247. Wong E, Rice L, Kolter JZ (2020) Fast is better than free: revisiting adversarial training. In: 8th international conference on learning representations, ICLR 2020, Addis Ababa, Ethiopia, April 26-30, 2020. OpenReview.net

248. Yang H, Liang L, Carlone L, Toh KC (2023) An inexact projected gradient method with rounding and lifting by nonlinear programming for solving rank-one semidefinite relaxation of polynomial optimization. Math Progr 201(1):409-472

249. Narang S, Diamos G, Elsen E, Micikevicius P, Alben J, Garcia D, Ginsburg B, Houston M, Kuchaiev O, Venkatesh G, Wu H (2018) Mixed precision training. In: International conference on learning representations

250. Smith LN (2017) Cyclical learning rates for training neural networks. In: 2017 IEEE winter conference on applications of computer vision (WACV). IEEE, pp 464-472

251. Coleman C, Narayanan D, Kang D, Zhao T, Zhang J, Nardi L, Bailis P, Olukotun K, Ré C, Zaharia M (2017) Dawnbench: an end-to-end deep learning benchmark and competition. Training 100(101):102

252. Chen Y, Wang Q, Wu S, Gao Y, Xu T, Hu Y (2024) TOMGPT: reliable text-only training approach for cost-effective multi-modal large language model. ACM Trans Knowl Discov Data. https:// doi.org/10.1145/3654674

253. Keraghel I, Morbieu S, Nadif M (2024) Beyond words: a comparative analysis of LLM embeddings for effective clustering. In: International symposium on intelligent data analysis. Springer, pp 205-216

254. Mewada A, Dewang RK (2023) SA-ASBA: a hybrid model for aspect-based sentiment analysis using synthetic attention in pre-trained language BERT model with extreme gradient boosting. J Supercomput 79(5):5516-5551

255. Wang Y, Pan Y, Yan M, Su Z, Luan TH (2023) A survey on ChatGPT: AI-generated contents, challenges, and solutions. IEEE Open J Comput Soc. https://doi.org/10.1109/OJCS.2023.3300321

256. Ribeiro MT, Singh S, Guestrin C (2018) Semantically equivalent adversarial rules for debugging NLP models. In: Proceedings of the 56th annual meeting of the association for computational linguistics (volume 1: long papers), pp 856-865

257. Liang B, Li H, Su M, Bian P, Li X, Shi W (2018) Deep text classification can be fooled. In: Proceedings of the 27th international joint conference on artificial intelligence, IJCAI'18. AAAI Press, pp 4208-4215

258. Qi X, Huang K, Panda A, Henderson P, Wang M, Mittal P (2024) Visual adversarial examples jailbreak aligned large language models. In: Proceedings of the AAAI conference on artificial intelligence, vol 38, pp 21527-21536

259. Zhang Y, Ye L, Tian Z, Chen Z, Zhang H, Li B, Fang B (2024) UCTT: universal and low-cost adversarial example generation for tendency classification. Neural Comput Appl. https://doi.org/10.1007/s00521-024-09760-5

260. Mnassri K, Farahbakhsh R, Crespi N (2024) Multilingual hate speech detection: a semi-supervised generative adversarial approach. Entropy 26(4):344

261. Wu X, Zhao H, Zhu Y, Shi Y, Yang F, Liu T, Zhai X, Yao W, Li J, Du M et al (2024) Usable XAI: 10 strategies towards exploiting explainability in the LLM era. arXiv preprint arXiv:2403.08946

Publisher's Note Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations.

Springer Nature or its licensor (e.g. a society or other partner) holds exclusive rights to this article under a publishing agreement with the author(s) or other rightsholder(s); author self-archiving of the accepted manuscript version of this article is solely governed by the terms of such publishing agreement and applicable law.