# Context-Conditional Adaptation for Recognizing Unseen Classes in Unseen Domains

Puneet Mangla ${}^{*1}$ , Shivam Chandhok ${}^{*2}$ ,

Vineeth N Balasubramanian ${}^{1}$ and Fahad Shahbaz Khan ${}^{2}$

${}^{1}$ Department of Computer Science, Indian Institute of Technology, Hyderabad

${}^{2}$ Mohamed bin Zayed University of Artificial Intelligence

pmangla261@gmail.com, shivam.chandhok@mbzuai.ac.ae, vineethnb@cse.iith.ac.in.

fahad.khan@mbzuai.ac.ae

## Abstract

Recent progress towards designing models that can generalize to unseen domains (i.e domain generalization) or unseen classes (i.e zero-shot learning) has embarked interest towards building models that can tackle both domain-shift and semantic shift simultaneously (i.e zero-shot domain generalization). For models to generalize to unseen classes in unseen domains, it is crucial to learn feature representation that preserves class-level (domain-invariant) as well as domain-specific information. Motivated from the success of generative zero-shot approaches, we propose a feature generative framework integrated with a COntext COnditional Adaptive (COCOA) Batch-Normalization to seamlessly integrate class-level semantic and domain-specific information. The generated visual features better capture the underlying data distribution enabling us to generalize to unseen classes and domains at test-time. We thoroughly evaluate and analyse our approach on established large-scale benchmark - DomainNet and demonstrate promising performance over baselines and state-of-art methods.

## 1 Introduction

The dependence of deep learning models on large amounts of data and supervision creates a bottleneck and hinders their utilization in practical scenarios. There is thus a need to equip deep learning models with the ability to generalize to unseen domains or classes at test-time using data from other related domains or classes (where data is abundant).

There has been great interest and corresponding efforts in recent years towards tackling domain shift (a.k.a Domain Generalization) [Yang and Gao, 2013; Muandet et al., 2013; Xu et al., 2014; Li et al., 2017; Ghifary et al., 2015; Li et al., 2018b; Carlucci et al., 2019; Li et al., 2018a; Li et al., 2019a] and semantic shift (a.k.a Zero-Shot Learning) [Reed et al., 2016; Frome et al., 2013; Wan et al., 2019; Kodirov et al., 2015; Zhang et al., 2017] separately. However, applications in the real world do not guarantee that only one of them will occur - there is a need to make systems robust to the domain and semantic shifts simultaneously. The problem of tackling domain shift and semantic shift together, as considered herein, can be grouped as the Zero-Shot Domain Generalization (which we call ZSLDG) problem setting [Mancini et al., 2020; Maniyar et al., 2020]. In ZSLDG, the model has access to a set of seen classes from multiple source domains and has to generalize to unseen classes in unseen target domains at test time. Note that this problem of recognizing unseen classes in unseen domains (ZSLDG) is much more challenging than tackling zero-shot learning (ZSL) or domain generalization (DG) separately [Mancini et al., 2020] and growingly relevant as deep learning models get reused across domains. A recent approach, CuMix [Mancini et al., 2020], proposed a methodology that mixes up multiple source domains and categories available during training to simulate semantic and domain shift at test time. This work also established a benchmark dataset, DomainNet, for the ZSLDG problem setting with an evaluation protocol, which we follow in this work for a fair comparison.

Feature generation methods [Xian et al., 2018; Ni et al., 2019; Schonfeld et al., 2019; Mishra et al., 2018; Felix et al., 2018; Huang et al., 2019; Keshari et al., 2020; Narayan et al., 2020; Chandhok and Balasubramanian, 2021; Shen et al., 2020] have recently shown significant promise in traditional zero-shot or few-shot learning settings and are among the state-of-the-art today for such problems. However, these approaches assume that the source domains (during training) and the target domain (during testing) are the same and thus aim to generate features that only address semantic shift. They rely on the assumption that the visual-semantic relationship learned during training will generalize to unseen classes at test-time. However, there is no guarantee that this holds for images in novel domains unseen during training [Mancini et al., 2020]. Thus, when used for addressing ZSLDG, the aforementioned methods lead to suboptimal performance.

To tackle domain shift at test-time, it is important to generate feature representations that encode both class level (domain-invariant) and domain-specific information [Chat-topadhyay et al., 2020; Seo et al., 2020]. Thus we conjecture that generating features that are consistent with only class-level semantics is not sufficient for addressing ZSLDG. However, encoding domain-specific information along with class information in generated features is not straightforward [Mancini et al., 2020]. Drawing inspiration from these observations, we propose a unified generative framework that uses COntext COnditional Adaptive (COCOA) Batch-Normalization to seamlessly integrate semantic and domain information to generate visual features of unseen classes in unseen domains. Depending on the setting, "context" can qualify as domain (for DG), semantics (for ZSL), or both (in case of ZSLDG). Since this work primarily deals with the ZSLDG setting, 'context' in this work refers to both domain and semantic information. We perform experiments and analysis on standard ZSLDG benchmark: DomainNet and demonstrate that our proposed methodology provides state-of-the-art performance for the ZSLDG setting and is able to encode both semantic and domain-specific information to generate features, thus capturing the given context better. To the best of our knowledge, this is the first generative approach to address the ZSLDG problem setting.

---

*Equal Contribution

---

## 2 COCOA: Proposed Methodology

Our goal is to train a classifier $\mathcal{C}$ which can tackle domain-shift as well as semantic shift simultaneously and recognize unseen classes in unseen domains at test-time. Let ${S}^{\bar{T}r} =$ $\left\{  {\left( {\mathbf{x}, y,{\mathbf{a}}_{y}^{s}, d}\right)  \mid  \mathbf{x} \in  \mathcal{X}, y \in  {\mathcal{Y}}^{s},{\mathbf{a}}_{y}^{s} \in  \mathcal{A}, d \in  {\mathcal{D}}^{s}}\right\}$ denote the training set, where $\mathbf{x}$ is a seen class image in the visual space(X)with corresponding label $y$ from a set of seen class labels ${\mathcal{Y}}^{s}$ . ${\mathbf{a}}_{y}^{s}$ denotes the class-specific semantic representation for seen classes. We assume access to domain labels $d$ for a set of source domains ${\mathcal{D}}^{s}$ with cardinality $K$ . The test-set is denoted by ${S}^{Ts} = \left\{  {\left( {\mathbf{x}, y,{\mathbf{a}}_{y}^{u}, d}\right)  \mid  \mathbf{x} \in  \mathcal{X}, y \in  {\mathcal{Y}}^{u},{\mathbf{a}}_{y}^{u} \in  }\right.$ $\left. {\mathcal{A}, d \in  {\mathcal{D}}^{u}}\right\}$ where ${\mathcal{Y}}^{u}$ is the set of labels for unseen classes and ${\mathcal{D}}^{u}$ represents the set of unseen target domains. Note that standard zero-shot setting (tackles only semantic-shift) complies with the condition ${\mathcal{Y}}^{s} \cap  {\mathcal{Y}}^{u} \equiv  \varnothing$ and ${\mathcal{D}}^{s} \equiv  {\mathcal{D}}^{u}$ . The standard DG setting (tackles only domain-shift), on the other hand, works under the condition ${\mathcal{Y}}^{s} \equiv  {\mathcal{Y}}^{u}$ and ${\mathcal{D}}^{s} \cap  {\mathcal{D}}^{u} \equiv  \varnothing$ . In this work, our goal is to address the challenging ZSLDG setting where ${\mathcal{Y}}^{s} \cap  {\mathcal{Y}}^{u} \equiv  \varnothing$ and ${\mathcal{D}}^{s} \cap  {\mathcal{D}}^{u} \equiv  \varnothing$ .

Our overall framework to address ZSLDG is summarized in Fig 1. We employ a three-stage pipeline, which we describe below.

### 2.1 Generalizable Feature Extraction

We extract visual features $\mathbf{f}$ that encode discriminative class-level cues (domain-invariant) as well as domain-specific information by training a visual encoder $f\left( \text{.}\right) ,{whichi}\;{isthen}$ used to train a semantic projector $p\left( \text{.}\right) .{Boththesemodules}$ are trained with images from all source domains available. The visual encoder and the semantic projector are trained to minimize the following loss:

$$
{\mathcal{L}}_{AGG} = {\mathbb{E}}_{\left( {\mathbf{x}, y}\right)  \sim  {S}^{Tr}}\left\lbrack  {{\mathcal{L}}_{CE}\left( {{\mathbf{a}}^{T}p\left( {f\left( \mathbf{x}\right) }\right) , y}\right) }\right\rbrack   + \mathcal{R}\left( \mathbf{f}\right)  \tag{1}
$$

where ${\mathcal{L}}_{CE}$ is standard cross-entropy loss and a $=$ $\left\lbrack  {{\mathbf{a}}_{1}^{s},\ldots ,{\mathbf{a}}_{\left| {\mathcal{Y}}^{s}\right| }^{s}}\right\rbrack  .\mathcal{R}\left( \mathbf{f}\right)$ denotes the regularization loss term. which is used to further improve the visual features and enhance their generalizability by regulating the amount of class-level semantic and domain-specific information in the features $\mathbf{f}$ . The regularizer block primarily uses rotation prediction (viz. providing a rotated image as input, and predicting rotation angle).

### 2.2 Generative Module

We learn a generative model which comprises of a generator $G : \mathcal{Z} \times  \mathcal{A} \times  \mathcal{D} \rightarrow  \mathcal{F}$ and a projection discriminator [Miyato and Koyama, 2018] (which uses a projection layer to incorporate conditional information into the discriminator) $D : \mathcal{F} \times  \mathcal{A} \times  \mathcal{D} \rightarrow  \mathbb{R}$ as shown in Fig 1. We represent this discriminator as $D = {D}_{l} \circ  {D}_{f}$ ( $\circ$ denotes composition) where ${D}_{f}$ is discriminator’s last feature layer and ${D}_{l}$ is the final linear layer. Both the generator and the projection discriminator are conditioned through a Context Conditional Adaptive (COCOA) Batch-Normalization module, which provides class-specific and domain-specific modulation at various stages during the generation process. Modulating the feature information by such semantic and domain-specific embeddings helps to integrate respective information into the features, thereby enabling better generalization. We use the available (seen) semantic attributes ${\mathbf{a}}_{y}^{s}$ that capture class-level characteristics, for encoding semantic information. However, such a representation that encodes domain information is not present for individual source domains. We hence define learnable (randomly initialized and optimized during training) domain embedding matrices ${\mathcal{E}}_{\text{gen }} = \left\{  {{\mathbf{e}}_{1}^{\text{gen }},{\mathbf{e}}_{2}^{\text{gen }},{\mathbf{e}}_{3}^{\text{gen }}\ldots ,{\mathbf{e}}_{K}^{\text{gen }}}\right\}$ and ${\mathcal{E}}_{\text{disc }} = \left\{  {{\mathbf{e}}_{1}^{\text{disc }},{\mathbf{e}}_{2}^{\text{disc }},{\mathbf{e}}_{3}^{\text{disc }}\ldots {\mathbf{e}}_{K}^{\text{disc }}}\right\}$ for the generator and the discriminator respectively.

The generator $G$ takes in noise $\mathbf{z} \in  \mathcal{Z}$ and a context vector $\mathbf{c}$ , and outputs visual features $\widehat{\mathbf{f}} \in  \mathcal{F}$ . The context vector c, which is the concatenation of class-level semantic attribute ${\mathbf{a}}_{y}^{s}$ and domain-specific embedding ${\mathbf{e}}_{i}^{\text{gen }}$ , is provided as input to a BatchNorm estimator network ${B}_{gen}^{l} : \mathcal{A} \times  \mathcal{D} \rightarrow  {\mathcal{R}}^{2 \times  h}(h$ is the dimension of layer $l$ activation vectors) which outputs batchnorm paramaters, ${\gamma }_{gen}^{l}$ and ${\beta }_{gen}^{l}$ for the $l$ -th layer. Similarly, the discriminator’s feature extractor ${D}_{f}\left( \text{.}\right) {hasasep} -$ arate BatchNorm estimator network ${B}_{\text{disc }}^{l} : \mathcal{D} \rightarrow  {\mathcal{R}}^{2 \times  h}$ to enable domain-specific context modulation of its batchnorm parameters, ${\gamma }_{\text{disc }}^{l},{\beta }_{\text{disc }}^{l}$ as shown in Fig 1.

Formally, let ${\mathbf{f}}_{\text{gen }}^{l}$ and ${\mathbf{f}}_{\text{disc }}^{l}$ denote feature activations belonging to domain $d$ and semantic attribute ${\mathbf{a}}_{y}^{s}$ , at $l$ -th layer of generator $G$ and discriminator $D$ respectively. We modulate ${\mathbf{f}}_{\text{gen }}^{l}$ and ${\mathbf{f}}_{\text{disc }}^{l}$ individually using Context Conditional Adaptive Batch-Normalization as follows:

${\gamma }_{gen}^{l},{\beta }_{gen}^{l} \leftarrow  {B}_{gen}^{l}\left( \mathbf{c}\right) ,{\mathbf{f}}_{gen}^{l + 1} \leftarrow  {\gamma }_{gen}^{l} \cdot  \frac{{\mathbf{f}}_{gen}^{l} - {\mu }_{gen}^{l}}{\sqrt{{\left( {\sigma }_{gen}^{l}\right) }^{2} + \epsilon }} + {\beta }_{gen}^{l}$

where $\mathbf{c} = \left\lbrack  {{\mathbf{a}}_{y}^{s},{\mathbf{e}}_{d}^{gen}}\right\rbrack$

$$
{\gamma }_{disc}^{l},{\beta }_{disc}^{l} \leftarrow  {B}_{disc}^{l}\left( {\mathbf{e}}_{d}^{disc}\right) ,{\mathbf{f}}_{disc}^{l + 1} \leftarrow  {\gamma }_{disc}^{l} \cdot  \frac{{\mathbf{f}}_{disc}^{l} - {\mu }_{disc}^{l}}{\sqrt{{\left( {\sigma }_{disc}^{l}\right) }^{2} + \epsilon }} + {\beta }_{disc}^{l}
$$

(2)

Here, $\left( {{\mu }_{\text{gen }}^{l},{\left( {\sigma }_{\text{gen }}^{l}\right) }^{2}}\right)$ and $\left( {{\mu }_{\text{disc }}^{l},{\left( {\sigma }_{\text{disc }}^{l}\right) }^{2}}\right)$ are the mean and variance of activations of the mini-batch (also used to update running statistics) containing ${\mathbf{f}}_{\text{gen }}^{l}$ and ${\mathbf{f}}_{\text{disc }}^{l}$ respectively. $\mathbf{c}$ denotes the context vector composed of semantic and domain embeddings and $\left\lbrack  {\cdot , \cdot  }\right\rbrack$ denotes the concatenation operation.

Finally, the generator and discriminator are trained to optimize the adversarial loss given by:

$$
{\mathcal{L}}_{D} = {\mathbb{E}}_{\left( {\mathbf{x},{\mathbf{a}}_{y}^{s}, d}\right)  \sim  {S}^{Tr}}\left\lbrack  {\max \left( {0,1 - D\left( {f\left( \mathbf{x}\right) ,{\mathbf{a}}_{y}^{s},{\mathbf{e}}_{d}^{\text{disc }}}\right) }\right) }\right\rbrack   \tag{3}
$$

$$
+ {\mathbb{E}}_{y \sim  {\mathcal{Y}}^{s}, d \sim  {\mathcal{D}}^{s},\mathbf{z} \sim  \mathcal{Z}}\left\lbrack  {\max \left( {0,1 + D\left( {\widehat{\mathbf{f}},{\mathbf{a}}_{y}^{s},{\mathbf{e}}_{d}^{\text{disc }}}\right) }\right) }\right\rbrack
$$

$$
{\mathcal{L}}_{G} = {\mathbb{E}}_{y \sim  {\mathcal{Y}}^{s}, d \sim  {\mathcal{D}}^{s},\mathbf{z} \sim  \mathcal{Z}}\lbrack  - D\left( {\widehat{\mathbf{f}},{\mathbf{a}}_{y}^{s},{\mathbf{e}}_{d}^{\text{disc }}}\right)  \tag{4}
$$

$$
+ {\lambda }_{G} \cdot  {\mathcal{L}}_{CE}\left( {{\mathbf{a}}^{T}p\left( \widehat{\mathbf{f}}\right) , y}\right) \rbrack
$$

![bo_d1c3qt77aajc7389qeug_2_154_152_1491_382_0.jpg](images/bo_d1c3qt77aajc7389qeug_2_154_152_1491_382_0.jpg)

Figure 1: The proposed pipeline consists of three stages: (1) Generalizable Feature Extraction; (2) Generative Module; and (3) Recognition and Inference. The first stage trains a visual backbone $f\left( \text{.}\right)$ to extract visual feature $\mathbf{f}$ that encodes discriminative class-level (domain-invariant) and domain-specific information. The second stage learns a generative model $G$ which uses COntext COnditioned Adaptive (COCOA) batch-normalization layers to fuse and integrate semantic and domain-specific information into the generated features $\widehat{\mathbf{f}}$ . Lastly, the third stage generates visual features for unseen classes across domains and trains a softmax classifier

where $D\left( {\mathbf{f},\mathbf{a},\mathbf{e}}\right)  = {\mathbf{a}}^{T}{D}_{f}\left( {\mathbf{f},\mathbf{e}}\right)  + {D}_{l}\left( {{D}_{f}\left( {\mathbf{f},\mathbf{e}}\right) }\right)$ is the projection term, $\widehat{\mathbf{f}} = G\left( {\mathbf{z},\mathbf{c}}\right)$ denotes generated feature. The second term, ${\mathcal{L}}_{CE}\left( {{\mathbf{a}}^{T}p\left( \widehat{\mathbf{f}}\right) , y}\right)$ in ${\mathcal{L}}_{G}$ ensures that the generated features have discriminative properties ( ${\lambda }_{G}$ is a hyperparameter). $p\left( \text{.}\right) {isthesemanticprojectorthatwastrainedintheprevious}$ stage.

### 2.3 Recognition and Inference

We freeze the generator and aim to synthesize visual features for unseen classes across different domains, which are then used to train classifier $\mathcal{C}$ . To this end, we concatenate the domain embeddings ${\mathbf{e}}_{i}^{\text{gen }},\left( {i \in  {\mathcal{D}}^{s}}\right)$ of the source domains from matrix ${\mathcal{E}}_{\text{gen }}$ (learned end-to-end with the generative model) and the semantic attributes/representations of unseen classes ${\mathbf{a}}_{y}^{u}$ to get the context vector $\mathbf{c}$ , which in turn is input to the trained batchnorm predictor network ${B}_{gen}^{l}$ . The output batch-norm parameters $\left( {{\gamma }_{gen}^{l},{\beta }_{gen}^{l}}\right)$ are used in the batchnorm layers of the pre-trained generator to generate features $\widehat{\mathbf{f}}$ . This enables us to generate features that are consistent with unseen class semantics and also encode domain information from individual source domains in the training set. After obtaining batch-norm parameters, the new set of unseen class features are generated as follows:

$$
{\widehat{\mathbf{f}}}_{n} = G\left( {{\mathbf{z}}_{n},\mathbf{c}}\right)  \tag{5}
$$

$$
\text{where}\mathbf{c} = \left\lbrack  {{\mathbf{a}}_{{y}_{n}}^{u},{\mathbf{e}}_{n}^{gen}}\right\rbrack  ,{\mathbf{z}}_{n} \sim  \mathcal{Z},{y}_{n} \sim  {\mathcal{Y}}^{u},{\mathbf{e}}_{n}^{gen} \sim  {\mathcal{E}}_{\text{gen }}
$$

To improve generalization to new domains at test-time and make the classifier domain-agnostic, we synthesize embed-dings of newer domains by interpolating the learned embed-dings of the source domains via a mix-up operation.

$$
{\mathcal{E}}_{\text{interp }}^{\text{gen }} = \lambda  \cdot  {\mathbf{e}}_{i}^{\text{gen }} + \left( {1 - \lambda }\right)  \cdot  {\mathbf{e}}_{j}^{\text{gen }}\text{ where }i, j \sim  {\mathcal{D}}^{s},\lambda  \sim  \mathcal{U}\left\lbrack  {0,1}\right\rbrack
$$

(6)where ${\mathbf{e}}_{i}^{\text{gen }}$ and ${\mathbf{e}}_{j}^{\text{gen }}$ refer to the domain embeddings of $i$ -th and $j$ -th source domains. The unseen class features generated using interpolated domain embeddings ${\mathcal{F}}_{\text{int }}^{u} =$ ${\left\{  \left( {\widehat{\mathbf{f}}}_{\text{int }}^{n},{y}_{n}\right) \right\}  }_{n = 1}^{N}$ are generated as follows:

$$
{\widehat{\mathbf{f}}}_{\text{int }}^{n} = G\left( {{\mathbf{z}}_{n},{\mathbf{c}}_{\text{interp. }}}\right) \text{ where }{\mathbf{c}}_{\text{interp. }} = \left\lbrack  {{\mathbf{a}}_{{y}_{n}}^{u},{\mathbf{e}}_{\text{interp. }}^{\text{gen }}}\right\rbrack  , \tag{7}
$$

$$
{\mathbf{z}}_{n} \sim  \mathcal{Z},{y}_{n} \sim  {\mathcal{Y}}^{u},{\mathbf{e}}_{\text{interp }}^{\text{gen }} \sim  {\mathcal{E}}_{\text{interp }}^{\text{gen }}
$$

<table><tr><td colspan="2">$\mathbf{{Method}}$</td><td colspan="5">Target Domain</td><td rowspan="2">Avg.</td></tr><tr><td>DG</td><td>ZSL</td><td>clipart</td><td>infograph</td><td>painting</td><td>quickdraw</td><td>sketch</td></tr><tr><td rowspan="3">-</td><td>DEVISE</td><td>20.1</td><td>11.7</td><td>17.6</td><td>6.1</td><td>16.7</td><td>14.4</td></tr><tr><td>ALE</td><td>22.7</td><td>12.7</td><td>20.2</td><td>6.8</td><td>18.5</td><td>16.2</td></tr><tr><td>SPNet</td><td>26.0</td><td>16.9</td><td>23.8</td><td>8.2</td><td>21.8</td><td>19.4</td></tr><tr><td rowspan="3">DANN</td><td>DEVISE</td><td>20.5</td><td>10.4</td><td>16.4</td><td>7.1</td><td>15.1</td><td>13.9</td></tr><tr><td>ALE</td><td>21.2</td><td>12.5</td><td>19.7</td><td>7.4</td><td>17.9</td><td>15.7</td></tr><tr><td>SPNet</td><td>25.9</td><td>15.8</td><td>24.1</td><td>8.4</td><td>21.3</td><td>19.1</td></tr><tr><td rowspan="3">EpiFCR</td><td>DEVISE</td><td>21.6</td><td>13.9</td><td>19.3</td><td>7.3</td><td>17.2</td><td>15.9</td></tr><tr><td>ALE</td><td>23.2</td><td>14.1</td><td>21.4</td><td>7.8</td><td>20.9</td><td>17.5</td></tr><tr><td>SPNet</td><td>26.4</td><td>16.7</td><td>24.6</td><td>9.2</td><td>23.2</td><td>20.0</td></tr><tr><td colspan="2">Mixup-img-only</td><td>25.2</td><td>16.3</td><td>24.4</td><td>8.7</td><td>21.7</td><td>19.2</td></tr><tr><td colspan="2">Mixup-two-level</td><td>26.6</td><td>17</td><td>25.3</td><td>8.8</td><td>21.9</td><td>19.9</td></tr><tr><td colspan="2">CuMix</td><td>27.6</td><td>17.8</td><td>25.5</td><td>9.9</td><td>22.6</td><td>20.7</td></tr><tr><td colspan="2">f-clsWGAN</td><td>20.0</td><td>13.3</td><td>20.5</td><td>6.6</td><td>14.9</td><td>15.1</td></tr><tr><td colspan="2">CuMix + f-clsWGAN</td><td>27.3</td><td>17.9</td><td>26.5</td><td>11.2</td><td>24.8</td><td>21.5</td></tr><tr><td colspan="2">ROT + f-clsWGAN</td><td>27.5</td><td>17.4</td><td>26.4</td><td>11.4</td><td>24.6</td><td>21.4</td></tr><tr><td colspan="2">${\mathrm{{COCOA}}}_{AGG}$</td><td>27.6</td><td>17.1</td><td>25.7</td><td>11.8</td><td>23.7</td><td>21.2</td></tr><tr><td colspan="2">${COCOA}_{ROT}$</td><td>28.9</td><td>18.2</td><td>27.1</td><td>13.1</td><td>25.7</td><td>22.6</td></tr></table>

Table 1: Performance comparison with established baselines and state-of-art methods for ZSLDG problem setting on benchmark Do-mainNet dataset. For fair comparison, all reported results follow the backbones, protocol and splits as established in CuMix. Best results are highlighted in bold and second best results are underlined.

Next, we train a MLP softmax classifier, $\mathcal{C}\left( \text{.}\right) {onthegenerated}$ multi-domain unseen class features dataset ${\mathcal{F}}_{\text{int }}^{u}$ by minimizing: ${\mathcal{L}}_{CLS} = {\mathbb{E}}_{\left( {{\widehat{\mathbf{f}}}_{\text{int }}, y}\right)  \sim  {\mathcal{F}}_{\text{int }}^{u}}\left\lbrack  {{\mathcal{L}}_{CE}\left( {\mathcal{C}\left( {\widehat{\mathbf{f}}}_{\text{int }}\right) , y}\right) }\right\rbrack$

Classifying image at test time. At test-time, given a test image ${\mathbf{x}}_{\text{test }}$ , we first pass it through the visual encoder $f\left( \text{.}\right)$ to get the discriminative feature representation ${\mathbf{f}}_{\text{test }} = f\left( \mathbf{x}\right)$ . Next we pass this feature representation to the classifier to get the final prediction $\widehat{y} = \arg \mathop{\max }\limits_{{y \in  {\mathcal{Y}}^{u}}}\mathcal{C}\left( {\mathbf{f}}_{\text{test }}\right) \left\lbrack  y\right\rbrack$

## 3 Experiments and Results

DomainNet Dataset: DomainNet is the only established, diverse large-scale, coarse-grained dataset for ZSLDG [Mancini et al., 2020] with images belonging to 345 different categories divided into 6 different domains i.e painting, real, clipart, infograph, quickdraw and sketch. We follow the seen-unseen class training-testing splits and protocol as established in [Mancini et al., 2020] where we train on 5 domains and test on the left-out domain. Also, following [Mancini et al., 2020], we use word2vec representations [Mikolov et al., 2013] as the semantic representations for class labels. For feature extractor $f\left( \text{.}\right) ,$ we choose a Resnet-50 architecture similar to [Mancini et al., 2020].

Baselines. We compare our approach with simpler baselines established in [Mancini et al., 2020] which include ZSL methods like SPNet [Xian et al., 2019], DeViSE [Frome et al., 2013], ALE [Akata et al., 2013] and their coupling with wellknown DG methods (DANN [Ganin et al., 2016], EpiFCR [Li et al., 2019b]). We also compare with SOTA ZSLDG method, CuMix [Mancini et al., 2020] as well as its variants: (1) Mixup-img-only where mixup is done only at image level without curriculum; (2) Mixup-two-level where mixup is applied at both feature and image level without curriculum. We also establish Feature generation baselines which include f-clsWGAN [Xian et al., 2018] (standard ZSL only approach) and its combination with visual backbone trained using CuMix [Mancini et al.,2020] methodology (CuMix + f-clsWGAN) and self-supervised rotation [Gidaris et al., 2018] feature extraction method (ROT + f-clsWGAN).

Results on DomainNet Benchmark. Table 1 shows the performance comparison of our method with the aforementioned baselines. We observe that a simple classification-based feature extraction (using only ${\mathcal{L}}_{\mathcal{{AGG}}}$ ) without any regularization when coupled with our generative module i.e ${COCOA}_{AGG}$ is able to outperform the current state-of-the-art, CuMix [Mancini et al., 2020]. In addition, when we use rotation prediction as a a regularizing auxiliary task [Gidaris et al.,2018] (referred as ${\mathrm{{COCOA}}}_{ROT}$ ), we observe that it achieves the best performance on all domains individually as well as on average (with significant improvement especially on hard domains like quickdraw where there is large domain shift encountered at test-time), thus outperforming [Mancini et al., 2020] by a margin of about 2% average across domains (which corresponds to a ${10}\%$ relative increase). We believe this is because the auxiliary task enables better representation learning. Also, we observe that combining generative ZSL baselines like f-clsWGAN [Xian et al., 2018] with different visual backbones including CuMix results in inferior average performance when compared with our approach.

Component-wise Ablation Study. Table 2 shows the component-wise performance for our method ${\mathrm{{COCOA}}}_{ROT}$ on DomainNet dataset, following [Mancini et al., 2020].

- ${S1}$ corresponds to the performance of the feature extractor $f\left( \text{.}\right) {trainedusingusingrotationpredictionasaregularizer}$ (without generative stage 2).

- ${S2}$ corresponds to the performance achieved by learning a generator $G$ without using domain embeddings as an input. Specifically, this implies that the BatchNorm estimator networks ${B}_{gen}^{l}$ is given only the class-level semantic attribute as input i.e context vector $\mathbf{c} = {\mathbf{a}}_{y}^{s}$ .

- ${S3}$ denotes the use of ${S2}$ , with domain embeddings as an additional input in the context vector provided to ${B}_{gen}^{l}$ i.e $\mathbf{c} = \left\lbrack  {{\mathbf{a}}_{y}^{s},{\mathbf{e}}_{d}^{gen}}\right\rbrack$ , without the use of interpolated domain embeddings ${\mathcal{E}}_{\text{interp }}^{\text{gen }}$ (Eqn 5) and S4 denotes our complete model with the use of interpolated domain embeddings ${\mathcal{E}}_{\text{interp }}^{\text{gen }}$ to generate features. Note that ${S2},{S3}$ and ${S4}$ follow the inference mechanism described in Sec 2.3.

From Table 2, we observe that ${S4}$ (proposed approach), which exploits the generative pipeline, semantic and domain embeddings as well as their mixing, achieves the best performance. This corroborates our hypothesis that conditioning on

<table><tr><td>Variant</td><td>Clipart</td><td>Infograph</td><td>Painting</td><td>Quickdraw</td><td>Sketch</td><td>Avg</td></tr><tr><td>${S1}$</td><td>27.5</td><td>17.8</td><td>25.4</td><td>9.57</td><td>22.5</td><td>20.54</td></tr><tr><td>${S2}$</td><td>27.67</td><td>17.36</td><td>27.08</td><td>11.57</td><td>24.97</td><td>21.716</td></tr><tr><td>${S3}$</td><td>28.5</td><td>17.6</td><td>26.8</td><td>12.7</td><td>25.48</td><td>22.2</td></tr><tr><td>${S4}$</td><td>28.9</td><td>18.2</td><td>27.1</td><td>13.1</td><td>25.7</td><td>22.6</td></tr></table>

Table 2: Ablation study for different components of our framework on DomainNet dataset

both domain and semantic embeddings enables the classifier to discriminate between the distribution of features $\mathbf{f}$ better by encoding both domain-specific and class-level information in generated features $\widehat{\mathbf{f}}$ . Furthermore, training the final classifier on features generated by interpolating source domain embed-dings (i.e ${S4}$ ) further improves performance by alleviating the bias towards source domains.

Visualization of Generated Features. We sample semantic attributes ${\mathbf{a}}_{y}^{u}$ for randomly selected unseen classes and use domain embeddings (learned end-to-end) of the five source domains (Real, Infograph, Quickdraw, Clipart, Sketch) used during training. We individually visualize the features generated of each unseen class using only semantic embed-dings/context i.e $\mathbf{c} = {\mathbf{a}}_{y}^{u}$ (Fig 2, Row 1) and concatenation of both semantic and domain embeddings/context i.e $\mathbf{c} = \left\lbrack  {{\mathbf{a}}_{y}^{u},{\mathbf{e}}_{d}^{\text{gen }}}\right\rbrack$ (Fig 2, Row 2) when estimating the batch-norm parameters of the generator. We notice that conditioning the batchnorm parameters on both semantic and domain context (Fig 2, Row 2) enables the model to better captures the modes of the original data distribution. It can be seen that the model can better retain domain-specific variance (associated with the five source domains) within a specific class cluster when both semantic and domain embeddings are used (Fig 2, Row 2), compared to the case where only semantic context is used (Fig 2, Row 1)

## 4 Conclusion

In this work, we propose a unified generative framework for the ZSLDG setting that uses context conditional batch-normalization to integrate class-level and domain-specific information into generated visual features, thereby enabling better generalization at test time. Through experiments, we demonstrate superior performance over established baselines and SOTA. Our proposed approach can be seamlessly integrated into other generative frameworks like VAEs, Flows, etc. which is left for future work.

## References

[Akata et al., 2013] Zeynep Akata, Florent Perronnin, Zaid Harchaoui, and Cordelia Schmid. Label-embedding for attribute-based classification. In Proceedings of the IEEE Conference on Computer Vision and Pattern Recognition, pages 819-826, 2013.

![bo_d1c3qt77aajc7389qeug_3_919_1695_726_230_0.jpg](images/bo_d1c3qt77aajc7389qeug_3_919_1695_726_230_0.jpg)

Figure 2: Individual t-SNE visualization of synthesized image features by COCOA for randomly selected unseen classes (Giraffe, Watermelon, Helicopter, Rainbow, Skyscraper) using only semantic context (Row 1) and both domain-semantic context (Row 2).

[Carlucci et al., 2019] Fabio Maria Carlucci, Antonio D'Innocente, Silvia Bucci, B. Caputo, and T. Tommasi. Domain generalization by solving jigsaw puzzles. 2019 IEEE/CVF Conference on Computer Vision and Pattern Recognition (CVPR), pages 2224-2233, 2019.

[Chandhok and Balasubramanian, 2021] Shivam Chandhok and V. Balasubramanian. Two-level adversarial visual-semantic coupling for generalized zero-shot learning. WACV, 2021.

[Chattopadhyay et al., 2020] Prithvijit Chattopadhyay, Y. Balaji, and Judy Hoffman. Learning to balance specificity and invariance for in and out of domain generalization. volume abs/2008.12839, 2020.

[Felix et al., 2018] Rafael Felix, Vijay BG Kumar, Ian Reid, and Gustavo Carneiro. Multi-modal cycle-consistent generalized zero-shot learning. In Proceedings of the European Conference on Computer Vision, 2018.

[Frome et al., 2013] Andrea Frome, Greg S Corrado, Jon Shlens, Samy Bengio, Jeff Dean, Marc'Aurelio Ranzato, and Tomas Mikolov. Devise: A deep visual-semantic embedding model. In Advances in neural information processing systems, pages 2121-2129, 2013.

[Ganin et al., 2016] Yaroslav Ganin, Evgeniya Ustinova, Hana Ajakan, Pascal Germain, Hugo Larochelle, François Laviolette, Mario Marchand, and Victor Lempitsky. Domain-adversarial training of neural networks. The Journal of Machine Learning Research, 17(1):2096-2030, 2016.

[Ghifary et al., 2015] Muhammad Ghifary, W. Kleijn, M. Zhang, and D. Balduzzi. Domain generalization for object recognition with multi-task autoencoders. 2015 IEEE International Conference on Computer Vision (ICCV), pages 2551-2559, 2015.

[Gidaris et al., 2018] Spyros Gidaris, Praveer Singh, and Nikos Komodakis. Unsupervised representation learning by predicting image rotations. ArXiv, abs/1803.07728, 2018.

[Huang et al., 2019] He Huang, Changhu Wang, Philip S Yu, and Chang-Dong Wang. Generative dual adversarial network for generalized zero-shot learning. CVPR, 2019.

[Keshari et al., 2020] Rohit Keshari, Richa Singh, and Mayank Vatsa. Generalized zero-shot learning via overcomplete distribution. CVPR, 2020.

[Kodirov et al., 2015] Elyor Kodirov, Tao Xiang, Zhenyong Fu, and S. Gong. Unsupervised domain adaptation for zero-shot learning. 2015 IEEE International Conference on Computer Vision (ICCV), pages 2452-2460, 2015.

[Li et al., 2017] Da Li, Yongxin Yang, Yi-Zhe Song, and Timothy M. Hospedales. Deeper, broader and artier domain generalization. 2017 IEEE International Conference on Computer Vision (ICCV), pages 5543-5551, 2017.

[Li et al., 2018a] Da Li, Yongxin Yang, Yi-Zhe Song, and Timothy M. Hospedales. Learning to generalize: Meta-learning for domain generalization. In ${AAAI},{2018}$ .

[Li et al., 2018b] Haoliang Li, Sinno Jialin Pan, S. Wang, and A. Kot. Domain generalization with adversarial feature learning. 2018 IEEE/CVF Conference on Computer Vision and Pattern Recognition, pages 5400-5409, 2018.

[Li et al., 2019a] Da Li, J. Zhang, Yongxin Yang, Cong Liu, Yi-Zhe Song, and Timothy M. Hospedales. Episodic training for domain generalization. 2019 IEEE/CVF International Conference on Computer Vision (ICCV), pages 1446-1455, 2019.

[Li et al., 2019b] Da Li, Jianshu Zhang, Yongxin Yang, Cong Liu, Yi-Zhe Song, and Timothy M Hospedales. Episodic training for domain generalization. In Proceedings of the IEEE International Conference on Computer Vision, pages 1446-1455, 2019.

[Mancini et al., 2020] Massimiliano Mancini, Zeynep Akata, E. Ricci, and Barbara Caputo. Towards recognizing unseen categories in unseen domains. In ${ECCV}$ , 2020.

[Maniyar et al., 2020] Udit Maniyar, K. J. Joseph, A. Desh-mukh, Ü. Dogan, and V. Balasubramanian. Zero-shot domain generalization. ArXiv, abs/2008.07443, 2020.

[Mikolov et al., 2013] Tomas Mikolov, Kai Chen, Greg S. Corrado, and Jeffrey Dean. Efficient estimation of word representations in vector space, 2013.

[Mishra et al., 2018] Ashish Mishra, Shiva Krishna Reddy, Anurag Mittal, and Hema A Murthy. A generative model for zero shot learning using conditional variational autoen-coders. CVPRW, 2018.

[Miyato and Koyama, 2018] Takeru Miyato and Masanori Koyama. cGANs with projection discriminator. In International Conference on Learning Representations, 2018.

[Muandet et al., 2013] Krikamol Muandet, D. Balduzzi, and B. Schölkopf. Domain generalization via invariant feature representation. ArXiv, abs/1301.2115, 2013.

[Narayan et al., 2020] Sanath Narayan, A. Gupta, F. Khan, Cees G. M. Snoek, and L. Shao. Latent embedding feedback and discriminative features for zero-shot classification. ArXiv, abs/2003.07833, 2020.

[Ni et al., 2019] Jian Ni, Shanghang Zhang, and Haiyong Xie. Dual adversarial semantics-consistent network for generalized zero-shot learning. NeurIPS, 2019.

[Reed et al., 2016] Scott E. Reed, Zeynep Akata, H. Lee, and B. Schiele. Learning deep representations of fine-grained visual descriptions. 2016 IEEE Conference on Computer Vision and Pattern Recognition (CVPR), pages 49-58, 2016.

[Schonfeld et al., 2019] Edgar Schonfeld, Sayna Ebrahimi, Samarth Sinha, Trevor Darrell, and Zeynep Akata. Generalized zero-and few-shot learning via aligned variational autoencoders. CVPR, 2019.

[Seo et al., 2020] Seonguk Seo, Yumin Suh, D. Kim, Jong-woo Han, and B. Han. Learning to optimize domain specific normalization for domain generalization. 2020.

[Shen et al., 2020] Yuming Shen, J. Qin, and L. Huang. Invertible zero-shot recognition flows. In ${ECCV},{2020}$ .

[Wan et al., 2019] Ziyu Wan, Dongdong Chen, Y. Li, Xing-guang Yan, Junge Zhang, Y. Yu, and Jing Liao. Transduc-tive zero-shot learning with visual structure constraint. In NeurIPS, 2019.

[Xian et al., 2018] Yongqin Xian, Tobias Lorenz, Bernt Schiele, , and Zeynep Akata. Feature generating networks for zero-shot learning. CVPR, 2018.

[Xian et al., 2019] Yongqin Xian, Subhabrata Choudhury, Yang He, Bernt Schiele, and Zeynep Akata. Semantic projection network for zero-and few-label semantic segmentation. In Proceedings of the IEEE Conference on Computer Vision and Pattern Recognition, pages 8256-8265, 2019.

[Xu et al., 2014] Zheng Xu, W. Li, Li Niu, and Dong Xu. Exploiting low-rank structure from latent domains for domain generalization. In ${ECCV},{2014}$ .

[Yang and Gao, 2013] P. Yang and Wei Gao. Multi-view discriminant transfer learning. In IJCAI, 2013.

[Zhang et al., 2017] L. Zhang, Tao Xiang, and S. Gong. Learning a deep embedding model for zero-shot learning. 2017 IEEE Conference on Computer Vision and Pattern Recognition (CVPR), pages 3010-3019, 2017.