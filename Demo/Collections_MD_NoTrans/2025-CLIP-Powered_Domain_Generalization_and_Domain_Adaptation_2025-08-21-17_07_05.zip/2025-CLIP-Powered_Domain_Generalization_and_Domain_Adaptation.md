# CLIP-Powered Domain Generalization and Domain Adaptation: A Comprehensive Survey

Jindong Li, Yongguang Li, Yali Fu, Jiahong Liu, Yixin Liu, Menglin Yang*, Irwin King Fellow, IEEE

Abstract-As machine learning evolves, domain generalization (DG) and domain adaptation (DA) have become crucial for enhancing model robustness across diverse environments. Contrastive Language-Image Pretraining (CLIP) plays a significant role in these tasks, offering powerful zero-shot capabilities that allow models to perform effectively in unseen domains. However, there remains a significant gap in the literature, as no comprehensive survey currently exists that systematically explores the applications of CLIP in DG and DA, highlighting the necessity for this review. This survey presents a comprehensive review of CLIP’s applications in DG and DA. In DG, we categorize methods into optimizing prompt learning for task alignment and leveraging CLIP as a backbone for effective feature extraction, both enhancing model adaptability. For DA, we examine both source-available methods utilizing labeled source data and source-free approaches primarily based on target domain data, emphasizing knowledge transfer mechanisms and strategies for improved performance across diverse contexts. Key challenges, including overfitting, domain diversity, and computational efficiency, are addressed, alongside future research opportunities to advance robustness and efficiency in practical applications. By synthesizing existing literature and pinpointing critical gaps, this survey provides valuable insights for researchers and practitioners, proposing directions for effectively leveraging CLIP to enhance methodologies in domain generalization and adaptation. Ultimately, this work aims to foster innovation and collaboration in the quest for more resilient machine learning models that can perform reliably across diverse real-world scenarios. A more up-to-date version of the papers is maintained at:

https://github.com/jindongli-Ai/Survey_on_CLIP-Powered_Domain_Generalization_and_Adaptation.

Index Terms—Vision-Language Model (VLM), CLIP-Powered, Domain Generalization (DG), Domain Adaptation (DA).

## 1 INTRODUCTION

AS machine learning progresses, domain generalization (DG) and domain adaptation (DA) have emerged as pivotal areas of research aimed at enhancing model robustness across diverse environments $\left\lbrack  {{85},{93}}\right\rbrack$ . Traditional models often rely on extensive labeled data, which can be challenging to obtain due to factors such as time, cost, and privacy concerns. Moreover, the scarcity of labeled datasets, combined with distribution discrepancies between source and target domains, significantly impedes the generalization capabilities of a model. These challenges highlight the urgent need for robust techniques that can adapt to unseen domains or variations in data distribution. Therefore, developing effective DG and DA methods is crucial for a wide array of applications, particularly in fields like healthcare, autonomous driving, and social media, where models must perform reliably in dynamic and unpredictable environments.

Inspired by earlier works such as VirTex [33] and ICMLM [134], which demonstrated the potential of transformer-based language modeling, masked language modeling, and contrastive objectives for learning image representations from text, the architecture of CLIP employs a contrastive learning framework. By leveraging a large-scale dataset that pairs 400 million images with textual descriptions, CLIP learns rich, multi-modal representations that align similar image-text pairs while distinguishing dissimilar ones. This dual processing captures intricate relationships between visual and linguistic information, significantly bolstering the model's robustness in handling variations in input data. Additionally, CLIP supports flexible task adaptation through prompting $\left\lbrack  {{47},{98},{135}}\right\rbrack$ , enabling nuanced interpretations of visual data based on contextual language cues. As illustrated in Fig. 1, these features make CLIP particularly effective for domain generalization (DG) and domain adaptation (DA). The powerful zero-shot capabilities of CLIP allow models to operate effectively in previously unseen domains without additional training on specific datasets. This adaptability enables CLIP to generalize across tasks-ranging from image classification to object detection-without requiring task-specific fine-tuning. Such versatility not only transforms the DG and DA research landscape but also alters the way problems are conceptualized and addressed in the machine learning community. CLIP's ability to handle domain shifts and transfer knowledge efficiently underscores its transformative potential in enhancing model performance across various domains.

![bo_d282qmv7aajc738ormjg_0_912_1112_741_394_0.jpg](images/bo_d282qmv7aajc738ormjg_0_912_1112_741_394_0.jpg)

Fig. 1. The characteristics of CLIP and its perfect fit for Domain Generalization (DG) and Domain Adaptation (DA).

---

- Jindong Li and Menglin Yang are with The Hong Kong University of Science and Technology (Guangzhou), Guangzhou, China. E-mail: jli839@connect.hkust-gz.edu.cn, menglinyang@hkust-gz.edu.cn.

- Yongguang Li and Yali Fu are with The Jilin University, Changchun, China. E-mail: \{liyg22, fuyl23\}@mails.jlu.edu.cn.

- Yixin Liu is with Griffith University, Queensland, Australia. E-mail: Yixin.liu@griffith.edu.au.

- Jiahong Liu and Irwin King are with The Chinese University of Hong Kong, Hong Kong, China. E-mail: jiahong.liu21@gmail.com, king@cse.cuhk.edu.hk.

- *: Corresponding author.

Manuscript received xxx xx, 20xx; revised xxxx xx, 20xx.

---

![bo_d282qmv7aajc738ormjg_1_148_106_1502_1225_0.jpg](images/bo_d282qmv7aajc738ormjg_1_148_106_1502_1225_0.jpg)

Fig. 2. Structure of this paper with representative works.

Given its remarkable suitability for DG and DA tasks, CLIP has garnered increasing attention in recent years. Researchers have actively explored CLIP-powered methods, proposing innovative approaches to address domain shifts and enhance cross-domain performance. As illustrated in Fig. 3, the number of works leveraging CLIP for DG and DA has surged rapidly, reflecting its growing prominence in the field. This trend underscores the importance of systematically understanding and categorizing these methodologies to fully unlock the potential of CLIP in domain generalization and adaptation.

While some surveys $\left\lbrack  {{85},{93}}\right\rbrack$ have explored domain generalization and adaptation broadly, none have specifically addressed the unique contributions and applications of CLIP-powered methods. This gap limits understanding of how CLIP can be effectively utilized within these frameworks and underscores the necessity for a comprehensive analysis of its capabilities and the methodologies that leverage its strengths in DG and DA. By synthesizing existing literature, this survey addresses the knowledge gap, analyzing key methodologies and identifying best practices for utilizing CLIP in domain generalization and adaptation. This comprehensive review helps researchers navigate the field and serves as a resource for practitioners applying these methods in real-world scenarios. The paper structure is shown in Fig. 2.

The significance of this survey lies in its broad coverage and ability to guide researchers in selecting strategies tailored to their needs. By showcasing CLIP's capabilities-such as multi-modal learning, adaptability, and zero-shot performance-we provide insights to enhance its effectiveness. We also tackle challenges like overfitting, domain shifts, and labeled data scarcity, offering solutions based on proven techniques and innovative approaches. This guidance will help researchers navigate the complexities of CLIP-powered domain generalization and adaptation.

![bo_d282qmv7aajc738ormjg_2_140_124_741_513_0.jpg](images/bo_d282qmv7aajc738ormjg_2_140_124_741_513_0.jpg)

Fig. 3. Roadmap (i.e. timeline) of CLIP-powered Domain Generalization (DG) and Domain Adaptation (DA).

Ultimately, this survey aims to deepen understanding of the research landscape and encourage further exploration of CLIP's potential in domain generalization and adaptation. By identifying research gaps and proposing future directions, we hope to stimulate collaboration and innovation in the field. The contributions of this survey could be summarized as follows:

- This survey provides the first comprehensive review focused on CLIP's applications in domain generalization (DG) and domain adaptation (DA). It systematically explores CLIP's unique advantages in multi-modal representation learning and illustrates its practical applicability through real-world use cases across diverse domains.

- We delve into how CLIP enhances generalization, particularly in zero-shot settings, and compare a range of domain adaptation methods, including both source-available and source-free approaches. Through detailed case studies, we evaluate their effectiveness and provide actionable insights into leveraging CLIP for domain-specific tasks.

- We offer an in-depth overview of datasets and evaluation metrics commonly used in DG and DA research, encompassing single-domain and multi-domain scenarios. This section aims to guide researchers in selecting appropriate benchmarks and metrics to evaluate CLIP-based models effectively across various domain shifts.

- By identifying key challenges such as overfitting and domain shifts, we shed light on the limitations of CLIP-powered models. Additionally, we propose future research directions that focus on leveraging CLIP's potential to overcome these challenges and explore innovative solutions.

## 2 PRELIMINARIES

This section presents the foundational concepts and terminology essential for understanding the subsequent discussions on domain generalization and adaptation. It encompasses notations and definitions that frame the context of the research, facilitating a comprehensive exploration of the proposed methodologies.

![bo_d282qmv7aajc738ormjg_2_918_104_746_312_0.jpg](images/bo_d282qmv7aajc738ormjg_2_918_104_746_312_0.jpg)

Fig. 4. Comparison of domain generalization (DG) and domain adaptation (DA).

### 2.1 Notations

In this paper, we use the notations which are shown in Table 1.

### 2.2 Definitions

We provide formal definitions for key concepts related to domain adaptation and generalization. These definitions establish the foundational terminology used throughout the paper, enabling a clearer understanding of the methodologies and their contexts.

#### 2.2.1 Problem Definition

Domain Generalization (DG) and Domain Adaptation (DA) are both techniques aimed at improving model performance across different data distributions. As show in Fig. 4, DG focuses on training a model using one or multiple source domains to ensure it generalizes well to unseen target domains. In contrast, DA involves training a model on a labeled source domain and adapting it to a target domain, which is typically unlabeled. While both approaches address challenges related to domain shifts, DG emphasizes generalization capabilities, whereas DA concentrates on adapting to specific target conditions.

Definition 1. Domain Generalization (DG). Domain generalization refers to methods designed to train a model $f$ on multiple source domains ${D}_{s} = \left\{  {{D}_{1},{D}_{2},\cdots ,{D}_{S}}\right\}$ . The objective is to enable the model to generalize well when evaluated on unseen target domains ${D}_{t} = \left\{  {{D}_{1},{D}_{2},\cdots ,{D}_{T}}\right\}$ . This process is critical for ensuring that the model can maintain its performance across diverse and variable conditions, rather than just excelling on the specific datasets it was trained on.

TABLE 1

Notations and Descriptions.

<table><tr><td>Notation</td><td>Description</td></tr><tr><td>$f : {\mathbb{R}}^{H \times  W} \mapsto  {\mathbb{R}}^{C}$</td><td>Mapping function from image space to class space.</td></tr><tr><td>${D}_{s} = \left\{  {{D}_{1},{D}_{2},\ldots ,{D}_{S}}\right\}$</td><td>Set of multiple source domains.</td></tr><tr><td>${D}_{t} = \left\{  {{D}_{1},{D}_{2},\ldots ,{D}_{T}}\right\}$</td><td>Set of unseen target domains.</td></tr><tr><td>${D}_{K} = {\left\{  \left( {x}_{i},{y}_{i}\right) \right\}  }_{i = 1}^{N}$</td><td>Dataset of domain $K$ with $N$ samples, where ${x}_{i}$ is the input and ${y}_{i}$ is the label.</td></tr><tr><td>${\mathcal{X}}_{K} \in  {\mathbb{R}}^{H \times  W}$</td><td>Input image space of domain $K$ .</td></tr><tr><td>${\mathcal{Y}}_{s} \in  {\mathbb{R}}^{{C}_{s}},{\mathcal{Y}}_{t} \in  {\mathbb{R}}^{{C}_{t}}$</td><td>Label spaces of the source and target domains.</td></tr><tr><td>$C$</td><td>Number of classes in the label space.</td></tr></table>

![bo_d282qmv7aajc738ormjg_3_132_114_749_316_0.jpg](images/bo_d282qmv7aajc738ormjg_3_132_114_749_316_0.jpg)

Fig. 5. Comparison of single-source (SS) and multi-source (MS) scenario.

Definition 2. Domain Adaptation (DA). Domain adaptation involves training a model $f$ on a labeled source domain ${D}_{s} =$ ${\left\{  \left( {x}_{i},{y}_{i}\right) \right\}  }_{i = 1}^{{N}_{s}}$ and subsequently adapting it to a target domain ${D}_{t} = {\left\{  {x}_{j}\right\}  }_{j = 1}^{{N}_{t}}$ . In this context, the source domain consists of labeled samples, while the target domain is generally unlabeled or contains only sparse labeled data. This flexibility allows the model to adapt its learned representations to perform effectively in the target domain, despite potential differences in data distribution.

#### 2.2.2 Different Scenarios about Availability of Source Infor- mation

Source-Available (SA) scenarios provide labeled data from the source domain to enhance adaptation in the target domain and are further divided into Single-Source (SS) and Multi-Source (MS) methods, as shown in Fig. 5. SS focuses on transferring knowledge from one labeled source domain, while MS leverages information from multiple labeled source domains for improved adaptation. As illustrated in Fig. 6, within Source-Free (SF), there are two subcategories: Source-Data-Free (SDF) allows for extracting knowledge from the source model without direct access to labeled source data, facilitating some adaptation. In contrast, Source-Fully-Free (SFF) prohibits any information from the source domain, requiring the model to rely solely on target data, which significantly increases adaptation challenges. Their specific definitions are as follows:

Definition 3. Source-Available (SA). Source-available refers to scenarios in which labeled data from the source domain ${D}_{s}$ is accessible for adaptation. This availability facilitates the transfer of knowledge gained from the source domain to improve performance in the target domain ${D}_{t}$ .

Definition 3.1. Single-Source (SS). Single-source-based methods are specifically designed to tackle shifts in data distribution by enabling the transfer of knowledge from a labeled source domain ${D}_{s}$ to the target domain ${D}_{t}$ .

Definition 3.2. Multi-Source (MS). Multi-source-based methods employ strategies to address shifts in data distribution by facilitating the transfer of knowledge from multiple labeled source domains ${D}_{s} = \left\{  {{D}_{1},{D}_{2},\cdots ,{D}_{S}}\right\}$ to the target domain ${D}_{t}$ .

Definition 4. Source-Data-Free (SDF). Source-data-free refers to a setting in which no data from the source domain ${D}_{s}$ are accessible during adaptation. Instead, only a model pre-trained on the source domain is available. The adaptation process must therefore be carried out using only the unlabeled target domain data ${D}_{t}$ , which calls for effective knowledge transfer without direct access to source data.

![bo_d282qmv7aajc738ormjg_3_912_111_752_337_0.jpg](images/bo_d282qmv7aajc738ormjg_3_912_111_752_337_0.jpg)

Fig. 6. Comparison of source-data-free (SDF) and source-fully-free (SFF). (Take single-source scenario as an example.)

Definition 5. Source-Fully-Free (SFF). SFF denotes a strict setting where the source domain ${D}_{s}$ does not exist. Instead, models rely solely on a pre-trained foundation model (e.g., CLIP) and perform adaptation directly on the unlabeled target domain ${D}_{t}$ , without any supervision or auxiliary data from ${D}_{s}$ .

#### 2.2.3 Different Scenarios about Connection between the Source Domain and the Target Domain

As shown in Fig. 7, there are 4 relationship types that describe the connection between the source domain and the target domain: closed-set, partial-set, open-set, and open-partial-set scenarios. In the closed-set scenario, the source and target domains share an identical set of categories, and the model only needs to focus on minimizing the distribution discrepancy between the two domains. In the partial-set scenario, the target domain contains a subset of the source domain's categories, requiring the model not only to align the shared classes but also to prevent target samples from being misclassified into source-private classes. In the open-set scenario, the target domain includes novel categories not present in the source domain, and the model must identify these unknown classes and group them accordingly. In the open-partial-set scenario, both domains share some categories while also having their own private ones, posing a more complex challenge where the model must align shared categories and isolate private ones to handle severe category shift. Their specific definitions are as follows:

Definition 6. Closed-Set (CS). Closed-set scenarios refer to situations where the label space of the target domain ${\mathcal{Y}}_{t}$ is exactly the same as that of the source domain ${\mathcal{Y}}_{s}$ , such that ${\mathcal{Y}}_{t} = {\mathcal{Y}}_{s}$ .

Definition 7. Partial-Set (PS). Partial-set scenarios involve situations where the label space of the target domain ${\mathcal{Y}}_{t}$ contains only a subset of classes from the source domain ${\mathcal{Y}}_{s}$ , such that ${\mathcal{Y}}_{t} \subset  {\mathcal{Y}}_{s}$ and ${\mathcal{Y}}_{s} \smallsetminus  {\mathcal{Y}}_{t} \neq  \varnothing$ .

Definition 8. Open-Set (OS). Open-set scenarios encompass cases where the label space of the target domain ${\mathcal{Y}}_{t}$ completely includes the classes present in the source domain ${\mathcal{Y}}_{s}$ , such that ${\mathcal{Y}}_{t} \supset  {\mathcal{Y}}_{s}$ and ${\mathcal{Y}}_{t} \smallsetminus  {\mathcal{Y}}_{s} \neq  \varnothing$ .

Definition 9. Open-Partial-Set (OPS). Open-partial-set scenarios refer to situations where the label space of the target domain ${\mathcal{Y}}_{t}$ includes some classes from the label space of the source domain ${\mathcal{Y}}_{s}$ , such that ${\mathcal{Y}}_{s} \cap  {\mathcal{Y}}_{t} \neq  \varnothing ,{\mathcal{Y}}_{t} \nsubseteq  {\mathcal{Y}}_{s}$ , and ${\mathcal{Y}}_{s} \nsubseteq  {\mathcal{Y}}_{t}$ . This indicates that there are classes present in ${\mathcal{Y}}_{t}$ that are not in ${\mathcal{Y}}_{s}$ , while also having classes in ${\mathcal{Y}}_{s}$ that do not appear in ${\mathcal{Y}}_{t}$ .

![bo_d282qmv7aajc738ormjg_4_134_116_751_271_0.jpg](images/bo_d282qmv7aajc738ormjg_4_134_116_751_271_0.jpg)

Fig. 7. Comparison of closed-set (CS), partial-set (PS), open-set scenarios (OS) and open-partial-set (OPS).

#### 2.2.4 Contrastive Language-Image Pretraining (CLIP)

CLIP learns visual concepts by jointly training on images and their textual descriptions using contrastive learning, aligning images and text in a shared space, as shown in Fig. 8(a). This approach provides flexibility and strong generalization, particularly in zero-shot learning and domain adaptation tasks. The model is based on a transformer architecture and utilizes a contrastive loss function to align image and text embeddings, enabling it to perform well across different tasks and domains without requiring task-specific fine-tuning, with its zero-shot capability (as shown in Fig. 8(b)) allowing it to generalize to new tasks and domains directly from pre-trained models [127].

Definition 10. CLIP (Contrastive Language-Image Pretraining). Let $\mathcal{I} = \left\{  {{I}_{1},{I}_{2},\ldots ,{I}_{N}}\right\}$ represent a set of images, and $\mathcal{T} = \left\{  {{T}_{1},{T}_{2},\ldots ,{T}_{N}}\right\}$ represent a corresponding set of textual descriptions. CLIP learns a joint embedding space ${\mathbb{R}}^{d}$ by projecting images and their associated texts into this space. The model's objective is to maximize the similarity between paired image-text embeddings while minimizing the similarity between non-paired image-text embeddings. This is achieved using the contrastive loss function $\left\lbrack  {{18},{49},{53},{197}}\right\rbrack$ :

$$
{\mathcal{L}}_{\text{contrastive }} =  - \frac{1}{N}\mathop{\sum }\limits_{{i = 1}}^{N}\log \frac{\exp \left( {{\mathbf{v}}_{i}^{\top }{\mathbf{t}}_{i}/\tau }\right) }{\mathop{\sum }\limits_{{j = 1}}^{N}\exp \left( {{\mathbf{v}}_{i}^{\top }{\mathbf{t}}_{j}/\tau }\right)  + \exp \left( {{\mathbf{v}}_{j}^{\top }{\mathbf{t}}_{i}/\tau }\right) },
$$

where ${\mathbf{v}}_{i} \in  {\mathbb{R}}^{d}$ and ${\mathbf{t}}_{i} \in  {\mathbb{R}}^{d}$ represent the image and text embeddings of the $i$ -th pair, and $\tau$ is a temperature scaling factor. The contrastive loss ensures that the image and its corresponding textual description are close in the embedding space, while non-paired items are pushed apart.

## 3 DOMAIN GENERALIZATION (DG)

Traditional (non-CLIP based) methods have been proposed to achieve domain generalization (DG) from the perspective of domain-invariant [48, 81, 105, 126, 137, 152], data augmentation [27, 67, 172, 201, 202], learning strategies [12, 21, 59, 84, 163, 196], and etc.

CLIP-based domain generalization (DG) aims to develop models that generalize to unseen target domains using limited source data. By leveraging CLIP, these methods enhance robustness and adaptability, making them effective in scenarios with scarce target domain data.

### 3.1 Prompt Optimization Techniques

Prompt optimization techniques focus on refining prompts in CLIP to improve task performance, as illustrated in Fig. 9. Recent approaches automate prompt tuning and enhance context representation, enabling more effective utilization of pre-trained models across diverse applications.

![bo_d282qmv7aajc738ormjg_4_931_135_711_241_0.jpg](images/bo_d282qmv7aajc738ormjg_4_931_135_711_241_0.jpg)

Fig. 8. The illustration of the (a) training process of CLIP (taking 4 class names and 4 images as example) and (b) zero-shot ability of CLIP (taking 4 class names as example) [127].

Zhou et al. [204] introduces Context Optimization (CoOp), a technique that eliminates manual prompt tuning by representing context words as continuous learnable vectors, while keeping the pre-trained parameters frozen. Building on prior work in prompting techniques $\lbrack {39},{63},{65}$ , ${90},{142},{145},{183},{199}\rbrack$ , CoOp defines two types of context: Unified Context for shared class contexts, and Class-Specific Context (CSC) for fine-grained classification tasks, tailoring prompts for individual class characteristics. Inspired by prompt learning in NLP [45, 82] and CV [66, 129, 178, 191], Zhou et al. [203] further develops Conditional Context Optimization (CoCoOp), using a lightweight neural network to generate input-conditional tokens for each image, enhancing parameter efficiency. Yao et al. [177] introduces Knowledge-guided Context Optimization (KgCoOp) to enhance the generalization of learnable prompts for unseen classes. Building on the widespread use of prompt tuning to adapt pre-trained models [42, 64, 123, 159], Kg-CoOp minimizes the gap between learned and hand-crafted prompts, preserving essential knowledge. By incorporating contrastive loss, it creates discriminative prompts effective for both seen and unseen tasks. Zhu et al. [206] introduces Prompt-aligned Gradient (ProGrad), which addresses overfitting by selectively updating prompts whose gradients align with general knowledge in vision-language models (VLMs). This alignment, based on pre-defined prompt predictions, reduces overfitting while preserving essential model knowledge and improving prompt tuning performance, outperforming existing approaches [45, 125, 203, 204]. Khattak et al. [70] introduces MaPLe, the first multimodal prompting framework for fine-tuning CLIP. It aligns vision and language modalities by coupling image and text prompts via a conditioning function, enabling joint optimization through cross-modal gradient propagation. Gao et al. [43] introduces LAMM, which uses trainable category tokens and optimizes $\langle$ CLASS $\rangle$ embeddings through gradient-based search. A hierarchical loss aligns representations across multiple spaces, improving generalization while maintaining CLIP's semantic consistency.

### 3.2 CLIP is Adopted as Backbone or Encoder

CLIP is commonly integrated as a backbone or encoder in domain generalization approaches, serving key roles in feature extraction and performance improvement. There are two primary adoption methods for CLIP, as illustrated in Fig. 10.

![bo_d282qmv7aajc738ormjg_5_234_115_554_260_0.jpg](images/bo_d282qmv7aajc738ormjg_5_234_115_554_260_0.jpg)

Fig. 9. The different ways about prompt learning optimization [43,70, 147, 203, 204].

The first method, shown on the left of Fig. 10, involves training both CLIP Image and Text Encoders, often combined with task-specific architectures. This allows the model to adapt to downstream tasks and capture domain-specific patterns, enhancing generalization. The second method, shown on the right of Fig. 10, freezes the CLIP encoders, using them directly for embedding extraction. This approach leverages CLIP's pre-trained knowledge, offering computational efficiency and preventing overfitting, especially with limited training resources.

In both methods, CLIP serves as a flexible feature extractor, whether as a dynamic or static model, enhancing various domain generalization strategies by providing robust and semantically rich embeddings that facilitate effective cross-domain learning.

#### 3.2.1 Source-Available (SA)

This section further organizes source-available methods into single-source and multi-source categories, highlighting their respective methodological characteristics and summarizing typical representative works.

3.2.1.1 Single-Source Closed-Set Domain Generalization (SS-CSDG): In ${SS}$ -CSDG, the model $f : {\mathbb{R}}^{H \times  W} \mapsto  {\mathbb{R}}^{C}$ is trained using labeled data from a single source domain ${D}_{s} =$ ${\left\{  \left( {x}_{i},{y}_{i}\right) \right\}  }_{i = 1}^{{N}_{s}}$ . The goal is to learn a mapping $f\left( x\right)$ that minimizes task loss on the source domain while maximizing generalization to unseen target domains ${D}_{t} = {\left\{  {x}_{j}\right\}  }_{j = 1}^{{N}_{t}}$ , where the label space of the target domain ${\mathcal{Y}}_{t}$ is identical to that of the source domain, i.e., ${\mathcal{Y}}_{t} = {\mathcal{Y}}_{s}.$

SS-CSDG refers to the approach of training a model on a domain (or distribution) to generalize its performance on unseen target domains. Ma et al. [106] proposes BorLan, which uses pre-trained language models to align visual and linguistic features, helping the vision model learn semantic-aware, domain-agnostic representations. It is model-agnostic, supporting various visual and language backbones. Cho et al. [24] introduces DAPT, a prompt tuning method for few-shot learning that optimizes both textual and visual prompts to match the data distribution. Unlike traditional methods [4, 14, 64, 104, 138, 185], it uses inter- and intra-dispersion losses to guide the learning of diverse text embeddings and compact image em-beddings within each class. Khattak et al. [71] introduces PromptSRC, a self-regularization framework for prompt learning inspired by network regularization techniques $\left\lbrack  {{29},{61},{62},{80},{102},{150},{154},{168},{179},{184},{188}}\right\rbrack$ . It regularizes prompt learning through: (1) alignment with the frozen model, (2) self-ensembling of prompts, and (3) encouraging textual diversity to enhance visual-textual balance. This approach mitigates overfitting and preserves CLIP's generalization ability. Yang et al. [175] introduces the MultiModal Adapter (MMA) for vision-language models (VLMs) to improve alignment between text and vision representations, inspired by previous work on adapter methods [11, 17, 20, 44, 54, 55, 114, 151]. MMA aggregates features from both branches into a shared space for gradient communication, applying only to higher layers to balance discrimination and generalization. It finds higher layers contain more dataset-specific knowledge, while lower layers capture more generalizable information. Bose et al. [8] proposes StyLIP, a domain-unified prompt learning method that leverages CLIP's frozen vision encoder and lightweight projectors to extract multiscale style features, enhancing hierarchical domain knowledge and generalization. Bai et al. [6] reframes prompt learning from a generative view and proposes Soft Prompt Generation (SPG), which trains with domain-specific soft prompt labels and uses a generative model to produce instance-specific prompts for unseen domains during inference. Yan et al. [174] presents Language-Guided Diverse Feature Synthesis (LDFS), a method that improves CLIP fine-tuning by generating diverse domain features via text-guided instance-conditional augmentation. It incorporates a pairwise regularizer for feature coherence and uses stochastic text augmentation to bridge the modality gap $\left\lbrack  {{40},{72},{76},{120}}\right\rbrack$ . Lafon et al. [77] introduces Global-Local Prompts (GalLoP), a framework that integrates global and local visual features to create diverse prompts. Local prompts align with sparse image regions, enabling precise text-to-image matching for fine-grained semantics. It refines textual alignment of local visual features $\lbrack {15},{34},{111},{112}$ , 153, 200] using linear projection for few-shot learning. To enhance diversity, it combines global and localized prompts with a "prompt dropout" strategy [41, 150], and uses a multiscale approach to capture broader semantic details.

![bo_d282qmv7aajc738ormjg_5_909_117_755_318_0.jpg](images/bo_d282qmv7aajc738ormjg_5_909_117_755_318_0.jpg)

Fig. 10. The illustration of (Left) CLIP as the backbone and the text encoder or image encoder is trainable, (Right) CLIP as the encoder and the parameters of text encoder and image encoder are frozen.

3.2.1.2 Multi-Source Closed-Set Domain Generalization (MS-CSDG): In MS-CSDG, the model $f : {\mathbb{R}}^{H \times  W} \mapsto$ ${\mathbb{R}}^{C}$ is trained using labeled data from multiple source domains ${D}_{s} = \left\{  {{D}_{1},{D}_{2},\cdots ,{D}_{S}}\right\}$ , with each source domain ${D}_{i}$ having its own label space ${\mathcal{Y}}_{i}$ . The goal of MS-CSDG is to learn a robust model that can generalize effectively to unseen target domains ${D}_{t} = {\left\{  {x}_{j}\right\}  }_{j = 1}^{{N}_{t}}$ , where the label space of the target domain ${\mathcal{Y}}_{t}$ is identical to that of the source domains ${\mathcal{Y}}_{s}$ , such that ${\mathcal{Y}}_{t} = {\mathcal{Y}}_{s}$ .

MS-CSDG trains a model on multiple source domains to improve generalization to unseen target domains. By integrating knowledge from various source domains, it ensures the model performs well across diverse data distributions, enabling effective transfer to target domains with the same labels but new distributions. Huang et al. [60] distills knowledge from a vision-language teacher by aligning student image features with teacher text features using absolute and relative distance losses for domain generalization. Zhang et al. [194] introduces Domain Prompt Learning (DPL), a lightweight method using a three-layer MLP prompt generator to improve accuracy while maintaining a small parameter size. Bose et al. [8] is also applicable in the context of MS-CSDG, demonstrating impressive performance across diverse source domains. Its ability to leverage multi-scale visual content effectively enhances generalization, making it a robust choice for addressing challenges in MS-DG scenarios. Cheng et al. [23] proposes a prompt tuning framework that disentangles text and visual prompts, enhancing generalization through domain-specific prototypes and invariant prediction fusion. Addepalli et al. [1] proposes VL2V-SD for text-guided self-distillation and VL2V-ADiP for black-box feature fusion, both enhancing OOD generalization. Bai et al. [6] applies to MS-CSDG by generating soft prompts from multiple source domains, enhancing the model's generalization to unseen domains. Xiao et al. [170] introduces Any-Shift Prompting, a framework that enhances CLIP's generalization using hierarchical prompts and a pseudo-shift mechanism, without additional training costs. Singha et al. [147] focuses on multi-source open-set domain generalization, treating closed-set DG as a special case. It demonstrates superior performance on MS-CSDG tasks compared to existing benchmarks. Xuan et al. [173] introduces Consistent Augmentation Learning (CAL), which enhances CLIP for domain generalization using CAFT during training and ETTA during inference for improved robustness. Qiao et al. [124] introduces Mixup-CLIPood, a robust domain generalization method for multimodal object recognition, using mix-up loss and larger vision-language backbones for enhanced generalization.

3.2.1.3 Multi-Source Open-Set Domain Generalization (MS-OSDG): In MS-OSDG, the model $f : {\mathbb{R}}^{H \times  W} \mapsto  {\mathbb{R}}^{C}$ is trained using labeled data from multiple source domains ${D}_{s} = \left\{  {{D}_{1},{D}_{2},\cdots ,{D}_{S}}\right\}$ , each with its own label space ${\mathcal{Y}}_{i}$ . In MS-OSDG, the label space of the target domain ${\mathcal{Y}}_{t}$ is a superset of the label space of the source domains ${\mathcal{Y}}_{s}$ , such that ${\mathcal{Y}}_{t} \supset  {\mathcal{Y}}_{s}$ . The target domain ${D}_{t} = {\left\{  {x}_{j}\right\}  }_{j = 1}^{{N}_{t}}$ consists of unlabeled samples from a set of unseen classes.

The scene of MS-OSDG has relatively little exploration at present, and there are not many traditional methods [68, ${117},{143},{164}\rbrack$ either. The objective of MS-OSDG is to develop a model that can generalize to these new classes while leveraging the knowledge learned from the source domains. The model must handle not only domain shifts but also the introduction of new, unseen classes that are not present in the source domains.

Shu et al. [144] proposes CLIPood, which adapts CLIP to OOD settings via margin metric softmax with class-adaptive margins and a Beta-weighted ensemble of zero-shot and fine-tuned models. Singha et al. [147] introduces ODG-CLIP, leveraging the semantic capabilities of the vision-language model, CLIP, with three main innovations. First, it redefines open-domain generalization (ODG) as a multi-class classification task that includes both known and novel categories, using a unique prompt designed to identify unknown class samples. To train this prompt, it utilizes a stable diffusion model [131] with faster inference speed than existing text-to-image generation methods [118, 128, 133] to generate proxy images representing open classes. Second, it designs a style-aware prompt mechanism to learn domain-specific classification weights, enrich visual embed-dings with class-discriminative cues, and maintain semantic consistency across domains. Chen et al. [22] proposes Perturbation Distillation (PD) to transfer knowledge from VLMs to lightweight vision models, improving robustness via score, class, and instance perspectives. It also introduces the Hybrid Domain Generalization (HDG) benchmark and H2-CV metric for broader evaluation.

#### 3.2.2 Source-Free (SF)

This section further organizes source-free methods into domain generalization (DG) approaches, highlighting their methodological characteristics and summarizing representative works.

3.2.2.1 Source-(Fully)-Free Domain Generalization (S(F)F-DG): In $S\left( F\right) F$ -DG, the model $f : {\mathbb{R}}^{H \times  W} \mapsto  {\mathbb{R}}^{C}$ is adapted to unseen target domains ${D}_{t} = {\left\{  {x}_{j}\right\}  }_{j = 1}^{{N}_{t}}$ without relying on any information from any source domains ${D}_{s}$ . In this context, models transfer to the target dataset either by learning domain-invariant feature representations through a domain bank [116], or by fine-tuning CLIP using category text features enriched with diverse style information [25, 156, 189].

In practical applications, obtaining abundant source domain data is often challenging. SF-DG addresses this issue by enabling models to predict target domain samples without accessing source domain data during training. This approach enhances the model's adaptability and flexibility by focusing on knowledge generalization

Niu et al. [116] proposes a domain-unified prompt representation generator (DUPRG) to obtain a set of domain-unified text representations. By converting textual prompts into structured inputs using text encoding, the method achieves domain invariance during the training phase, thereby eliminating the necessity for extensive source domain data. Cho et al. [25] introduces the model Prompt-Styler, the first attempt to synthesize a variety of styles in a joint vision-language space via prompts, effectively tackling source-free domain generalization. This method emulates various distribution shifts by generating diverse styles through prompts, all without relying on any images. Tang et al. [156] presents Dynamic PromptStyler (DPStyler), which includes Style Generation and Style Removal modules to tackle these challenges. The Style Generation module updates all styles at each training epoch, while the Style Removal module mitigates variations in the encoder's output features that result from input styles. Zhang et al. [189] introduces PromptTA, a novel method that integrates a text adapter to address the challenging SF-DG task. This approach includes a style feature resampling module aimed at effectively capturing the distribution of style features, employing resampling techniques to ensure comprehensive coverage across various domains.

## 4 Domain Adaptation (DA)

Domain adaptation (DA) with CLIP-based methods aims to adapt models to target domains using a limited amount of labeled source data. These methods leverage CLIP's rich feature representations to minimize domain shifts and enhance model performance in new target domains, especially when labeled data in the target domain is scarce. In this section, we organize DA approaches into two categories: source-available (SA) and source-free (SF), focusing on their specific methodologies and representative works.

### 4.1 Source-Available (SA)

This section is structured based on two main categories: single-source adaptation and multi-source adaptation. Each category addresses different strategies and challenges in domain adaptation, focusing on how models are trained using either a single source domain or multiple source domains.

#### 4.1.1 Single-Source (SS)

4.1.1.1 Single-Source Closed-Set Unsupervised Domain Adaptation (SS-CSUDA): In SS-CSUDA, the label space of the target domain ${\mathcal{Y}}_{t}$ is identical to that of the source domain ${\mathcal{Y}}_{s}$ , such that ${\mathcal{Y}}_{t} = {\mathcal{Y}}_{s}$ . In this scenario, a model $f : {\mathbb{R}}^{H \times  W} \mapsto$ ${\mathbb{R}}^{C}$ is trained on a labeled source domain ${D}_{s} = {\left\{  \left( {x}_{i},{y}_{i}\right) \right\}  }_{i = 1}^{{N}_{s}}$ and subsequently adapted to a target domain ${D}_{t} = {\left\{  {x}_{j}\right\}  }_{j = 1}^{{N}_{t}}$ consisting solely of unlabeled samples.

The main challenge in SS-CSUDA is to effectively transfer the knowledge acquired from the labeled source domain to the unlabeled target domain, enabling the model to recognize and classify instances based on the existing class information while navigating the complexities introduced by the absence of labels in the target domain. Lai et al. [78] introduces PADCLIP, which incorporates domain names into prompts and addresses catastrophic forgetting in CLIP through adaptive debiasing, adjusting causal inference with momentum and CFM. Singha et al. [146] introduces AD-CLIP, which learns domain-invariant and class-generic prompt tokens, including domain, image, and class tokens, based on visual features. Ge et al. [46] introduces a domain adaptation framework called DAPrompt, which utilizes domain-specific prompts for UDA and incorporates a dynamic mechanism to adapt the classifier to each domain. Bai et al. [5] introduces Prompt-based Distribution Alignment (PDA), a method that integrates domain knowledge into prompt learning using a two-branch prompt tuning framework with base and alignment branches. Du et al. [35] introduces DAMP, which aligns visual and textual embeddings to leverage domain-invariant semantics, using image context to prompt the language branch in a domain-agnostic, instance-conditioned manner. Li et al. [89] introduces UniMoS, a framework for unsupervised domain adaptation that separates CLIP-extracted visual features into vision and language components, which are trained independently and then aligned using a modality discriminator. Zhou and Zhou [205] presents a cross-modal knowledge distillation (CMKD) approach for UDA, incorporating residual sparse training (RST) to greatly reduce parameter storage requirements and enhance deployment efficiency. Lai et al. [79] introduces prompt task-dependent tuning (PTT) and visual feature refinement (VFR), using domain-aware pseudo-labeling and zero-shot predictions for efficient adaptation of VLMs. Zhu et al. [207] introduces CLIP-Div, a language-guided method that aligns source and target domains using CLIP's domain-agnostic distribution, with two new divergence losses—absolute and relative—to enhance alignment. Different from existing pseudo-labeling related methods $\left\lbrack  {{26},{73},{92},{97},{99},{100},{108},{148},{187},{192},{208}}\right\rbrack$ , it employs a language-guided pseudo-labeling strategy designed to calibrate target pseudo-labels, which enhances the model's generalization on the target domain through self-training. Shi et al. [140] introduces DACR, a CLIP-based unsupervised domain adaptation method that optimizes prompts and image adapters with consistency regularization, improving generalization and domain-specific feature learning through pseudo-label consistency across augmented views. Shi et al. [141] introduces FUZZLE, a novel method that integrates fuzzy techniques $\left\lbrack  {{13},{88},{95},{96},{167},{209}}\right\rbrack$ into prompt learning for the first time within the vision-language model domain. It enhances unsupervised domain adaptation (UDA) by using domain-specific prompt learning, fuzzy C-means, and instance-level fuzzy vectors to align prompts with cluster centers. A KL divergence loss with a fuzzification factor reduces cross-domain gaps during training. Shi et al. [139] introduces VLMTSK-DA, an innovative approach that enhances vision-language models through the integration of Takagi-Sugeno-Kang (TSK) fuzzy systems. Inspired by some fuzzy systems methods $\left\lbrack  {{86},{87},{96},{103},{171}}\right\rbrack$ , It uses the TSK system as an image adapter to manage uncertainty, combining image features residually for optimized performance. Through prompt learning, it synchronizes visual and textual updates for global optimization and applies fuzzy C-means loss to align target data with source clusters, reducing distribution gaps.

4.1.1.2 Single-Source Open-Set Unsupervised Domain Adaptation (SS-OSUDA): In SS-OSUDA, the label space of the target domain ${\mathcal{Y}}_{t}$ may include classes that are not present in the source domain ${\mathcal{Y}}_{s}$ , such that ${\mathcal{Y}}_{s} \cap  {\mathcal{Y}}_{t} \neq  \varnothing$ and ${\mathcal{Y}}_{s} \subset  {\mathcal{Y}}_{t}$ . In this scenario, a model $f : {\mathbb{R}}^{H \times  W} \mapsto  {\mathbb{R}}^{C}$ is trained on a labeled source domain ${D}_{s} = {\left\{  \left( {x}_{i},{y}_{i}\right) \right\}  }_{i = 1}^{{N}_{s}}$ and subsequently adapted to a target domain ${D}_{t} = {\left\{  {x}_{j}\right\}  }_{j = 1}^{{N}_{t}}$ consisting solely of unlabeled samples.

The primary challenge in SS-OSUDA is to enable the model to effectively generalize its knowledge to recognize both known and unknown classes, while maintaining robust performance in classifying instances from the known classes, despite the uncertainties introduced by the presence of novel classes in the target domain. Yu et al. [182] proposes ODA with CLIP trains model with the guidance of CLIP. This method calculates the entropy of the outputs of the ODA model and the predictions of CLIP on the target domain to identify known and unknown samples. Zeng et al. [186] introduces Decoupling Domain Invariance and Variance with Tailored Prompts (PromptDIV) for OSDA, aiming to learn domain-invariant features for alignment. Specifically, it proposes one-vs-all clustering with text features (OVAT) to generate domain-unbiased pseudo-labels, domain-specific prompts (DSPs) to separate domain-invariant and domain-variant features, and Semisupervised and affinity contrastive learning (SMACL) to enhance feature consistency within the same category. Monga et al. [113] introduces CLIP talks on open-set multi-target domain adaptation (COSMo) for learning domain-agnostic prompts through source domain-guided prompt learning to address Multi-Target Domain Adaptation (MTDA). It employs a domain-specific bias network and separate prompts for known and unknown classes. COSMo is the first to tackle Open-Set Multi-Target Domain Adaptation (OSMTDA), enhancing the adaptation process in real-world scenarios.

![bo_d282qmv7aajc738ormjg_8_257_115_508_303_0.jpg](images/bo_d282qmv7aajc738ormjg_8_257_115_508_303_0.jpg)

Fig. 11. The scenario of Multi-Source Open-Partial-Set Unsupervised Domain Adaptation (MS-OPSUDA) a.k.a. Universal Multi-Source Domain Adaptation (UniMDA).

#### 4.1.2 Multi-Source (MS)

4.1.2.1 Multi-Source Closed-Set Unsupervised Domain Adaptation (MS-CSUDA): In SS-CSUDA, the label space of the target domain ${\mathcal{Y}}_{t}$ is identical to that of the source domain ${\mathcal{Y}}_{s}$ , such that ${\mathcal{Y}}_{t} = {\mathcal{Y}}_{s}$ . A model $f : {\mathbb{R}}^{H \times  \widetilde{W}} \mapsto  {\mathbb{R}}^{C}$ is trained on a labeled source domain ${D}_{s} = {\left\{  \left( {x}_{i},{y}_{i}\right) \right\}  }_{i = 1}^{{N}_{s}}$ and subsequently adapted to an unlabeled target domain ${D}_{t} = {\left\{  {x}_{j}\right\}  }_{j = 1}^{{N}_{t}}$ consisting solely of unlabeled samples.

The primary challenge in MS-CSUDA lies in effectively leveraging information from multiple source domains to enhance the model's performance on the target domain while addressing the uncertainties that arise from the lack of labels in the target samples. Chen et al. [16] presents MPA, a prompt learning-based MS-UDA method for source-target domain alignment. It trains individual prompts for each domain pair and aligns them using an auto-encoder, with an LST strategy for efficient adaptation to target domains. Wang et al. [166] introduces LanDA, a language-guided MS-DA method that transfers knowledge from multiple source domains to a target domain using only textual descriptions, preserving task-relevant information without requiring target domain images.

4.1.2.2 Multi-Source Open-Partial-Set Unsupervised Domain Adaptation (MS-OPSUDA) a.k.a. Universal Multi-Source Domain Adaptation (UniMDA): In MS-OPSUDA(UniMDA), the label space of the target domain ${\mathcal{Y}}_{t}$ includes some classes from the label space of the source domains ${\mathcal{Y}}_{s} = \left\{  {{\mathcal{Y}}_{1},{\mathcal{Y}}_{2},\ldots ,{\mathcal{Y}}_{S}}\right\}$ , such that ${\mathcal{Y}}_{s} \cap  {\mathcal{Y}}_{t} \neq  \varnothing ,{\mathcal{Y}}_{t} \nsubseteq  {\mathcal{Y}}_{s}$ , and ${\mathcal{Y}}_{s} \nsubseteq  {\mathcal{Y}}_{t}$ (illustrated in Fig. 11). In this scenario, a model $f : {\mathbb{R}}^{H \times  W} \mapsto  {\mathbb{R}}^{C}$ is trained on multiple labeled source domains ${D}_{s} = \left\{  {{D}_{1},{D}_{2},\ldots ,{D}_{S}}\right\}$ and then adapted to a target domain ${D}_{t} = {\left\{  {x}_{j}\right\}  }_{j = 1}^{{N}_{t}}$ , which consists solely of unlabeled samples.

UniMDA encounters two primary challenges. The first involves mitigating domain shifts across various domains to capture discriminative representations for shared classes. The second concerns handling class shifts by identifying unknown target samples lacking label information. To date, limited research (e.g., UMAN [180] and HyMOS [10]) has been conducted in the UniMDA domain.

Yang et al. [176] introduces SAP-CLIP, a Semantic-aware Adaptive Prompt method for UniMDA tasks. It uses learnable prompts to handle domain and class shifts, with a dynamic margin loss that improves detection of unknown samples by increasing their distance from known ones.

4.1.2.3 Multi-Source Few-Shot Domain Adaptation (MS-FSDA): Yu et al. [181] addresses MS-FSDA by introducing a prompt learning methodology that enhances VLMs using domain prompts. It also proposes "domain-aware mixup," improving domain prompt learning. The multi-source domain prompt learning (MSDPL) method focuses on both domain and class prompts to enhance performance in few-shot adaptation tasks.

### 4.2 Source-Free (SF)

This section is structured based on two main categories: Source-Fully-Free (SFF) and Source-Data-Free (SDF). Each category addresses distinct strategies and challenges in training models under these conditions.

#### 4.2.1 Source-Fully-Free (SFF)

4.2.1.1 Source-Fully-Free Closed-Set Unsupervised Domain Adaptation (SFF-CSUDA) a.k.a. Closed-Set Unsupervised Fine-Tuning (CS-UFT): Source-Fully-Free Closed-Set Unsupervised Domain Adaptation (SFF-CSUDA), also known as Closed-Set Unsupervised Fine-Tuning (CS-UFT), refers to a framework where the label space of the target domain ${\mathcal{Y}}_{t}$ is identical to that of the predetermined list of known classes ${\mathcal{Y}}_{s}$ , such that ${\mathcal{Y}}_{t} = {\mathcal{Y}}_{s}$ . In this scenario, the model $f : {\mathbb{R}}^{H \times  W} \mapsto  {\mathbb{R}}^{C}$ is adapted to a target domain ${D}_{t} = {\left\{  {x}_{j}\right\}  }_{j = 1}^{{N}_{t}}$ consisting solely of unlabeled samples, with no access to labeled data from a source domain ${D}_{s}$ .

The main challenge in SFF-CSUDA is to utilize the knowledge encoded within the model and any available information from the target domain to effectively classify instances, while maintaining robustness in the absence of source data. Huang et al. [57] presents an unsupervised prompt learning (UPL) framework and it is the first work to introduce unsupervised learning into prompt learning of VLM. The method introduces several techniques, such as a top-K pseudo-labeling strategy, pseudo label ensemble, and prompt representation ensemble, aimed at enhancing transfer performance. Tanwisuth et al. [157] introduces the Prompt-Oriented Unsupervised Fine-Tuning (POUF) framework, which aligns prototypes and target data in the latent space using transport-based distribution alignment and mutual information maximization. Additionally, the formulation of POUF is demonstrated for both language-augmented vision models and masked language models. Hu et al. [56] introduces ReCLIP, which learns a projection space to mitigate misaligned visual-text embeddings and generate pseudo labels. It then utilizes cross-modality self-training with these labels to iteratively refine the encoders and reduce domain gap and misalignment. Mirza et al. [110] presents LaFTer, a label-free, parameter-efficient cross-modal transfer method that utilizes only 0.4% of learned parameters. It fine-tunes a VLM to enhance recognition performance on target classes using automatically generated texts and an unlabeled image collection. This study demonstrates that training solely on automatically gathered language knowledge, such as through LLM prompting, can effectively bootstrap a visual classifier built on an aligned VLM. Zhang et al. [190] introduces the Candidate Pseudolabel Learning (CPL) method for fine-tuning VLM using suitable candidate pseudolabels for unlabeled data. The CPL framework generates refined candidate pseudo labels by constructing a confidence score matrix and considering both intra- and inter-instance label selection to improve true label identification. Ali et al. [3] introduces DPA, which generates accurate pseudo-labels by combining outputs from two prototypes and ranking them to reduce noise, especially early in training. It also aligns textual prototypes with image prototypes to address visual-textual misalignment. Liang et al. [94] proposes Universal Entropy Optimization (UEO), which leverages sample-level confidence to optimize entropy and jointly tunes textual prompts and visual affine transformations in CLIP. Long et al. [101] proposes TFUP, enhancing features with similarity-based predictions and selecting samples using confidence and prototype scores. TFUP-T improves performance through entropy-based adaptation. Feng et al. [38] shows that domain priors enhance CLIP's zero-shot performance and introduces a benchmark with a knowledge disentangling strategy for label-free multi-source generalization.

4.2.1.2 Source-Fully-Free Partial-Set Unsupervised Domain Adaptation (SFF-PSUDA) a.k.a. Partial-Set Unsupervised Fine-Tuning (PS-UFT): In SFF-PSUDA(PS-UFT), the label space of the target domain ${\mathcal{Y}}_{t}$ is a subset of the label space of the predetermined list of known classes ${\mathcal{Y}}_{s}$ , such that ${\mathcal{Y}}_{t} \subset  {\mathcal{Y}}_{s}$ . In this scenario, the model $f : {\mathbb{R}}^{H \times  W} \mapsto  {\mathbb{R}}^{C}$ is adapted to a target domain ${D}_{t} = {\left\{  {x}_{j}\right\}  }_{j = 1}^{{N}_{t}}$ consisting solely of unlabeled samples, with no access to labeled data from a source domain ${D}_{s}$ .

The main challenge in SFF-PSUDA is to effectively leverage the knowledge encoded within the model and any available information from the target domain to classify instances corresponding to the known classes, while navigating the complexities introduced by the absence of some classes in the target domain. Liang et al. [94] shows that Universal Entropy Optimization (UEO) excels in SFF-PSUDA by effectively adapting to target domains with a subset of source classes. This method enhances classification accuracy and demonstrates robust performance despite the absence of certain classes, highlighting its potential in real-world applications.

4.2.1.3 Source-Fully-Free Open-Set Unsupervised Domain Adaptation (SFF-OSUDA) a.k.a. Open-Set Unsupervised Fine-Tuning (OS-UFT): In SFF-OSUDA(OS-UFT), the label space of the target domain ${\mathcal{Y}}_{t}$ may include classes not present in the label space of the predetermined list of known classes ${\mathcal{Y}}_{s}$ , such that ${\mathcal{Y}}_{s} \subset  {\mathcal{Y}}_{t}$ . In this scenario, the model $f : {\mathbb{R}}^{H \times  W} \mapsto  {\mathbb{R}}^{C}$ is adapted to a target domain ${D}_{t} = {\left\{  {x}_{j}\right\}  }_{j = 1}^{{N}_{t}}$ consisting solely of unlabeled samples, with no access to labeled data from a source domain ${D}_{s}$ .

The primary challenge in SFF-OSUDA lies in learning robust representations that facilitate the recognition of known categories in the target domain, while reliably detecting samples from previously unseen classes, despite the complete absence of labeled source data. Min et al. [109] introduces the UOTA algorithm, which improves pre-trained zero-shot models using open-set unlabeled data. It enables implicit OOD detection, enhances classification for known classes, and achieves state-of-the-art performance with computational efficiency by updating only a lightweight adapter. Liang et al. [94] shows that Universal Entropy Optimization (UEO) excels in SFF-OSUDA, enhancing classification of both known and new instances, and proving robust in dynamic environments with changing class distributions.

4.2.1.4 Source-Fully-Free Open-Partial-Set Unsupervised Domain Adaptation (SFF-OPSUDA) a.k.a. Open-Partial-Set Unsupervised Fine-Tuning (OPS-UFT): In SFF-OPSUDA(OPS-UFT), the label space of the target domain ${\mathcal{Y}}_{t}$ includes some classes from the label space of the predetermined list of known classes ${\mathcal{Y}}_{s}$ , such that ${\mathcal{Y}}_{s} \cap  {\mathcal{Y}}_{t} \neq  \varnothing ,{\mathcal{Y}}_{t} \nsubseteq  {\mathcal{Y}}_{s}$ , and ${\mathcal{Y}}_{s} \nsubseteq  {\mathcal{Y}}_{t}$ . In this scenario, the model $f : {\mathbb{R}}^{H \times  W} \mapsto  {\mathbb{R}}^{C}$ is adapted to a target domain ${D}_{t} = {\left\{  {x}_{j}\right\}  }_{j = 1}^{{N}_{t}}$ consisting solely of unlabeled samples, with no access to labeled data from a source domain ${D}_{s}$ .

The main challenge in SFF-OPSUDA is to accurately identify target-domain samples belonging to the common classes while reliably detecting samples from unknown classes-i.e., those not included in the predefined set of known categories-and avoiding the misclassification of known categories into unknown ones, all without access to any labeled source data. Liang et al. [94] demonstrates that Universal Entropy Optimization (UEO) enhances SFF-OPSUDA by leveraging common classes between source and target domains. It improves classification of known classes and adapts well to new, unseen classes, making it effective in partial class overlap scenarios.

#### 4.2.2 Source-Data-Free (SDF)

4.2.2.1 Source-Data-Free Closed-Set Unsupervised Domain Adaptation (SDF-CSUDA): In SDF-CSUDA, the label space of the target domain ${\mathcal{Y}}_{t}$ is identical to that of the source domain ${\mathcal{Y}}_{s}$ , such that ${\mathcal{Y}}_{t} = {\mathcal{Y}}_{s}$ . In this scenario, a model $f : {\mathbb{R}}^{H \times  W} \mapsto  {\mathbb{R}}^{C}$ is adapted to a target domain ${D}_{t} = {\left\{  {x}_{j}\right\}  }_{j = 1}^{{N}_{t}}$ consisting solely of unlabeled samples, with no access to labeled data from a source domain ${D}_{s}$ .

The main challenge in SDF-CSUDA is to enable the model to effectively utilize the information available in the target domain to make accurate predictions for the known classes, while addressing the uncertainties arising from the absence of labeled source data. DIFO [155] introduces a distillation approach for multimodal models, combining prompt learning and knowledge distillation with regularization for improved reliability. Zhang et al. [193] introduces Co-learn++, which enhances target adaptation by integrating pre-trained networks. It improves pseudolabel quality through collaboration with the source model and feature extractor, leveraging CLIP's zero-shot classification decisions. Li et al. [91] introduces CDBN, a data-efficient dual-branch network powered by CLIP. It integrates source domain class semantics into unsupervised fine-tuning for target domain generalization, preserving class information while enhancing accuracy and diversity in predictions. Tian et al. [158] introduces BBC, a black-box domain adaptation method using CLIP. It improves pseudo-label accuracy through joint label generation from a cloud API and CLIP, along with a structure-preserved strategy refining labels using k-nearest neighbors.

TABLE 2

The different scenarios for DG and DA. (SA: Source-Available, SF: Source-Free, SS: Single-Source, MS: Multi-Source, CS: Closed-Set, PS: Partial-Set, OS: Open-Set, OPS: Open-Partial-Set, FS: Few-Shot, FT: Fine-Tuning)

<table><tr><td colspan="3" rowspan="2">Scenario</td><td colspan="2">Source Domain</td><td colspan="3">Target Domain</td><td colspan="4">Category between Source Domain and Target Domain</td></tr><tr><td>Single-Source (SS)</td><td>Multi-Source (MS)</td><td>Source Domain Data</td><td>Source Domain Knowledge</td><td>Target Data (Unlabeled)</td><td>Closed-Set (CS)</td><td>Open-Partial- $\mathbf{{Set}}$ (PS)</td><td>$\mathbf{{Open} - }$ Set (OS)</td><td>Open-Partial- $\mathbf{{Set}}$ (OPS)</td></tr><tr><td rowspan="4">Domain Generalization (DG)</td><td rowspan="3">Source-Available (SA)</td><td>SS-DG</td><td>✓</td><td/><td/><td/><td/><td>✓</td><td>✓</td><td>✓</td><td/></tr><tr><td>MS-CSDG</td><td/><td>✓</td><td/><td/><td/><td>✓</td><td/><td/><td/></tr><tr><td>MS-OSDG</td><td/><td>✓</td><td/><td/><td/><td/><td/><td>✓</td><td/></tr><tr><td>Source-Free (SF)</td><td>S(F)F-DG</td><td/><td/><td/><td>✓</td><td/><td>✓</td><td>✓</td><td>✓</td><td/></tr><tr><td rowspan="11">Domain Adaptation (DA)</td><td rowspan="4">Source-Available (SA)</td><td>SS-CSUDA</td><td>✓</td><td/><td>✓</td><td>✓</td><td>✓</td><td>✓</td><td/><td/><td/></tr><tr><td>SS-OSUDA</td><td>✓</td><td/><td>✓</td><td>✓</td><td>✓</td><td/><td/><td>✓</td><td/></tr><tr><td>MS-UDA</td><td/><td>✓</td><td>✓</td><td>✓</td><td>✓</td><td>✓</td><td>✓</td><td>✓</td><td/></tr><tr><td>MS-FSDA</td><td/><td>✓</td><td>✓</td><td>✓</td><td>✓</td><td>✓</td><td>✓</td><td>✓</td><td/></tr><tr><td rowspan="7">Source-Free (SF)</td><td>SFF-CSUDA a.k.a. CS-UFT</td><td/><td/><td/><td/><td>✓</td><td>✓</td><td/><td/><td/></tr><tr><td>SFF-PSUDA a.k.a. PS-UFT</td><td/><td/><td/><td/><td>✓</td><td/><td>✓</td><td/><td/></tr><tr><td>SFF-OSUDA a.k.a. OS-UFT</td><td/><td/><td/><td/><td>✓</td><td/><td/><td>✓</td><td/></tr><tr><td>SFF-OSUDA a.k.a. OPS-UFT</td><td/><td/><td/><td/><td>✓</td><td/><td/><td/><td>✓</td></tr><tr><td>SDF-CSUDA</td><td/><td/><td/><td>✓</td><td>✓</td><td>✓</td><td/><td/><td/></tr><tr><td>SDF-PSUDA</td><td/><td/><td/><td>✓</td><td>✓</td><td/><td>✓</td><td/><td/></tr><tr><td>SDF-OSUDA</td><td/><td/><td/><td>✓</td><td>✓</td><td/><td/><td>✓</td><td/></tr></table>

4.2.2.2 Source-Data-Free Partial-Set Unsupervised Domain Adaptation (SDF-PSUDA): In SDF-PSUDA, the label space of the target domain ${\mathcal{Y}}_{t}$ is a subset of the label space of the source domain ${\mathcal{Y}}_{s}$ , such that ${\mathcal{Y}}_{t} \subset  {\mathcal{Y}}_{s}$ . In this scenario, a model $f : {\mathbb{R}}^{H \times  W} \mapsto  {\mathbb{R}}^{C}$ is adapted to a target domain ${D}_{t} = {\left\{  {x}_{j}\right\}  }_{j = 1}^{{N}_{t}}$ consisting solely of unlabeled samples, without access to labeled data from a source domain ${D}_{s}$ .

The main challenge in SDF-PSUDA is adapting the model to target domain classes while handling missing classes and the lack of labeled data. In this context, DIFO [155] adapts the ViL model to target domains where only a subset of source classes is present. The mutual information maximization process focuses on refining the model's understanding of the relevant classes in the partial set, enabling accurate adaptation to the specific class distribution without any labeled source data. Zhang et al. [193] also demonstrates strong performance in SDF-PSUDA, effectively adapting to target domains with a subset of source classes and improving classification accuracy.

4.2.2.3 Source-Data-Free Open-Set Unsupervised Domain Adaptation (SDF-OSUDA): In SDF-OSUDA, the label space of the target domain ${\mathcal{Y}}_{t}$ may include classes that are not present in the label space of the source domain ${\mathcal{Y}}_{s}$ , such that ${\mathcal{Y}}_{s} \subset  {\mathcal{Y}}_{t}$ . In this context, a model $f : {\mathbb{R}}^{H \times  W} \mapsto  {\mathbb{R}}^{C}$ is adapted to a target domain ${D}_{t} = {\left\{  {x}_{j}\right\}  }_{j = 1}^{{N}_{t}}$ that contains only unlabeled samples, without access to labeled data from a source domain ${D}_{s}$ .

The core challenge in SDF-OSUDA lies in jointly achieving reliable detection of target-domain samples from unknown classes and accurate classification of those from known classes, under the constraint of no labeled source data.

Yu et al. [182] investigates adaptable methods for leveraging CLIP in SF-OSUDA. This approach assumes access to a model pre-trained on source domain samples, using its parameters directly to initialize the model for the target domain. DIFO [155] also addresses the challenges of SF-OSUDA, where the target domain may contain unseen classes. By distilling knowledge from the customized ViL model to the target model, DIFO enhances the model's ability to generalize and recognize novel classes, ensuring robust performance in open-set scenarios while effectively leveraging unlabeled data from the target domain. Zhang et al. [193] further evaluates SDF-OSUDA, showing effective identification of unseen classes while maintaining robust generalization in open-set scenarios.

## 5 BENCHMARKS AND METRICS

This section introduces common datasets and evaluation metrics used in domain adaptation (DA) and domain generalization (DG). Datasets are typically categorized into mul-tidomain and single-domain types, each suited for different experimental settings. The section also discusses key performance metrics, including accuracy and harmonic mean scores, which are crucial for evaluating model performance, especially in scenarios involving unknown classes in the target domain. These benchmarks and metrics provide a foundation for comparing the effectiveness of various DA and DG methods.

### 5.1 Common Bechmarks

#### 5.1.1 Datasets for DA and DG

DA and DG both use datasets that can be categorized into multi-domain and single-domain types, as shown in Table 3. In a multidomain dataset, each subset represents a distinct domain with the same categories but different image distributions. In DA and DG experiments, one or more domains act as the source domains-single-source $\left\lbrack  {{35},{78},{146}}\right\rbrack$ or multi-source $\left\lbrack  {{16},{166},{181}}\right\rbrack$ -while the remaining domains serve as target domains to evaluate model performance.

TABLE 3

Common datasets in DG and DA. (#: number)

<table><tr><td>Field</td><td>Dataset</td><td>#Domains</td><td>#Categories</td><td>#Images</td><td>Link</td></tr><tr><td rowspan="9">Multi- domain Dataset</td><td>Office-Home [161]</td><td>4</td><td>65</td><td>15,588</td><td>https://faculty.cc.gatech.edu/~judy/domainadapt/</td></tr><tr><td>Office-31 [132]</td><td>3</td><td>31</td><td>4,652</td><td>https://www.hemanthdv.org/officeHomeDataset.html</td></tr><tr><td>VisDA-2017 [121]</td><td>2</td><td>12</td><td>280,000</td><td>https://github.com/VisionLearningGroup/taskcv-2017-public</td></tr><tr><td>DomainNet [122]</td><td>6</td><td>345</td><td>586,575</td><td>https://ai.bu.edu/M3SDA/</td></tr><tr><td>PACS [83]</td><td>4</td><td>7</td><td>9,991</td><td>https://www.kaggle.com/datasets/nickfratto/pacs-dataset</td></tr><tr><td>VLCS [36]</td><td>4</td><td>5</td><td>10,729</td><td>https://www.kaggle.com/datasets/iamjanvijay/vlcsdataset/data</td></tr><tr><td>Digits-DG [201]</td><td>4</td><td>10</td><td>24,000</td><td>https://csip.fzu.edu.cn/files/datasets/SSDG/digits_dg.zip</td></tr><tr><td>TerraIncognita [7]</td><td>4</td><td>10</td><td>24,330</td><td>https://beerys.github.io/CaltechCameraTraps/</td></tr><tr><td>NICO++ [195]</td><td>6</td><td>7</td><td>89,232</td><td>https://github.com/xxgege/NICO-plus</td></tr><tr><td rowspan="17">Single- Domain Dataset</td><td>ImageNet [32]</td><td>1</td><td>1000</td><td>1.28M</td><td>https://www.image-net.org/download.php</td></tr><tr><td>ImageNetV2 [130]</td><td>1</td><td>1000</td><td>10,000</td><td>https://github.com/modestyachts/ImageNetV2</td></tr><tr><td>ImageNet-Sketch [162]</td><td>1</td><td>1000</td><td>50,889</td><td>https://github.com/HaohanWang/ImageNet-Sketch</td></tr><tr><td>ImageNet-A [52]</td><td>1</td><td>200</td><td>7,500</td><td>https://github.com/hendrycks/natural-adv-examples</td></tr><tr><td>ImageNet-R[51]</td><td>1</td><td>200</td><td>30,000</td><td>https://github.com/hendrycks/imagenet-r</td></tr><tr><td>CIFAR10 [75]</td><td>1</td><td>10</td><td>60,000</td><td>https://www.cs.toronto.edu/~kriz/cifar.html</td></tr><tr><td>CIFAR100 [75]</td><td>1</td><td>100</td><td>60,000</td><td>https://www.cs.toronto.edu/~kriz/cifar.html</td></tr><tr><td>Caltech101 [37]</td><td>1</td><td>100</td><td>8,242</td><td>https://www.kaggle.com/datasets/imbikramsaha/caltech-101</td></tr><tr><td>DTD [28]</td><td>1</td><td>47</td><td>5,640</td><td>https://www.robots.ox.ac.uk/~vgg/data/dtd/</td></tr><tr><td>EuroSAT [50]</td><td>1</td><td>10</td><td>2,700</td><td>https://www.kaggle.com/datasets/apollo2506/eurosat-dataset</td></tr><tr><td>FGVCAircraft [107]</td><td>1</td><td>100</td><td>10,000</td><td>https://www.robots.ox.ac.uk/~vgg/data/fgvc-aircraft/</td></tr><tr><td>Food101 [9]</td><td>1</td><td>101</td><td>101,000</td><td>https://www.kaggle.com/datasets/dansbecker/food-101</td></tr><tr><td>Flowers102 [115]</td><td>1</td><td>101</td><td>8,189</td><td>https://www.kaggle.com/datasets/demonplus/flower-dataset-102</td></tr><tr><td>OxfordPets [119]</td><td>1</td><td>37</td><td>7,349</td><td>https://www.kaggle.com/datasets/tanlikesmath/the-oxfordiiit-pet-dataset</td></tr><tr><td>SUN397 [169]</td><td>1</td><td>397</td><td>39,700</td><td>https://huggingface.co/datasets/1aurent/SUN397</td></tr><tr><td>StandfordCars [74]</td><td>1</td><td>196</td><td>16,185</td><td>https://www.kaggle.com/datasets/jessicali9530/stanford-cars-dataset/data</td></tr><tr><td>UCF101 [149]</td><td>1</td><td>101</td><td>13,320</td><td>https://www.kaggle.com/datasets/matthewjansen/ucf101-action-recognition</td></tr></table>

The primary difference between DA and DG lies in their respective training and evaluation approaches: DA [46, 78, 89] typically uses labeled source domains and unlabeled target domains, which are jointly trained before testing in the target domain, while DG $\left\lbrack  {6,8,{194}}\right\rbrack$ involves training on one or more labeled source domains, and, after source training, testing is conducted directly in the target domain without additional adaptation.

Single-domain datasets, used in SFF-DA methods [56, 57], leverage CLIP's zero-shot capabilities for unsupervised training and adaptation. Datasets like ImageNet and its variants-ImageNetV2, ImageNet-Sketch, ImageNet-A, and ImageNet-R-serve as benchmarks for evaluating domain generalization in few-shot prompt learning.

### 5.2 Common Metrics

Both DA and DG methods evaluate performance in the target domain. For DA, metrics depend on the category shift between source set ${\mathcal{Y}}_{s}$ and target set ${\mathcal{Y}}_{t}$ . For DG, metrics are based on the shift between predefined ${\mathcal{Y}}_{s}$ and the actual target set ${\mathcal{Y}}_{t}$ . Specifically:

1. For ${\mathcal{Y}}_{s} = {\mathcal{Y}}_{t}$ or ${\mathcal{Y}}_{t} \subset  {\mathcal{Y}}_{s}$ with ${\mathcal{Y}}_{s} \smallsetminus  {\mathcal{Y}}_{t} \neq  \varnothing$ cases (i.e., closed-set and partial-set scenarios): As there are no unknown classes in the target domain, prior methods typically use either the average class accuracy (ACC) or domain average accuracy across all transfer tasks to evaluate performance.

2. For ${\mathcal{Y}}_{s} \subset  {\mathcal{Y}}_{t}$ with ${\mathcal{Y}}_{t} \smallsetminus  {\mathcal{Y}}_{s} \neq  \varnothing$ or ${\mathcal{Y}}_{s} \cap  {\mathcal{Y}}_{t} \neq  \varnothing ,{\mathcal{Y}}_{t} \nsubseteq  {\mathcal{Y}}_{s}$ , with ${\mathcal{Y}}_{s} \nsubseteq  {\mathcal{Y}}_{t}$ cases (i.e., open-set and open-partial-set scenarios): During target domain evaluation, we commonly define ${\mathcal{Y}}_{\text{shared }} = {\mathcal{Y}}_{s} \cap  {\mathcal{Y}}_{t}$ as the set of shared classes. Samples within ${\mathcal{Y}}_{\text{shared }}$ in the target domain are considered known classes, while others are treated as unknown classes. All unknown classes are grouped into a unified "unknown" category. For evaluation, the model must identify these unknown class samples, and performance is measured using the harmonic mean of the known class accuracy (ACC) and unknown class detection accuracy (AUC), calculated as

$$
{HOS} = \frac{2 \times  {AC}{C}_{\text{know }} \times  {AC}{C}_{\text{unknow }}}{{AC}{C}_{\text{know }} + {AC}{C}_{\text{unknow }}}. \tag{1}
$$

Notably, some methods use per-class accuracy for ${AC}{C}_{\text{know }}$ (e.g., UEO [94], DIFO [155]), while others calculate accuracy across all known class samples (e.g., ODA with CLIP [182]).

## 6 CHALLENGES AND OPPORTUNITIES

CLIP-Powered Domain Generalization and Adaptation encounter several critical challenges that significantly affect their effectiveness and usability. Addressing these challenges is essential for improving model performance and ensuring robust deployment in various applications.

Model Interpretability. CLIP-powered models often lack interpretability $\left\lbrack  {{30},{136}}\right\rbrack$ , making it challenging to understand how they arrive at decisions-especially in critical applications like healthcare, where transparency is vital. Attention mechanisms and feature attribution improve explainability by highlighting influential features, helping enhance trust, facilitate debugging, and optimize performance where understanding model reasoning is essential.

Overfitting. Overfitting occurs when CLIP-powered models perform well on the source domain but fail to generalize to unseen targets, often due to limited or imbalanced data. This is especially problematic in domain generalization, where models may learn spurious correlations over domain-invariant features. Techniques like dropout, weight regularization, and data augmentation introduce variability to improve robustness. Recent methods, such as meta-learning and domain adversarial training, simulate domain shifts to promote transferable feature learning, thereby reducing overfitting and enhancing generalization.

Limited Labeled Data. The scarcity of labeled data in target domains poses a key challenge for CLIP-powered domain adaptation, where supervised learning relies on abundant annotations. This limitation hampers transfer performance, especially under large domain shifts. To mitigate this, unsupervised and semi-supervised strategies-such as pseudo-labeling, few-/zero-shot learning, and leveraging auxiliary source data-are commonly used. These methods help models learn useful patterns with minimal supervision, boosting adaptability to new domains while reducing annotation costs.

Domain Diversity. Domain diversity poses challenges due to variations in lighting, background, object pose, and style across domains, leading to domain shifts that degrade performance. Robust architectures and training strategies-such as multi-task learning and domain-invariant representation learning-promote knowledge sharing and focus on generalizable features. Additionally, contrastive learning and feature alignment help bridge domain gaps, enhancing adaptability to diverse and unseen environments.

Computational Efficiency. The high computational cost of CLIP-based models, due to their large architectures and multimodal embeddings, poses challenges for real-time or resource-constrained applications, limiting their practicality in scenarios like edge computing or mobile deployment. To address this, compression techniques such as knowledge distillation, pruning, and quantization reduce memory and computation overhead, aiming to maintain performance while improving efficiency for broader and more flexible deployment.

Catastrophic Forgetting. Fine-tuning CLIP-powered models on new domain data can lead to catastrophic forgetting $\left\lbrack  {2,{19},{69}}\right\rbrack$ , where previous knowledge is overwritten by new information, undermining the model's performance across tasks or domains. To address this, regularization-based methods penalize drastic changes in important parameters, while rehearsal-based strategies retrain the model using old data to reinforce prior knowledge. More recent solutions include memory-efficient continual learning and parameter-isolation techniques, preserving past capabilities without sacrificing adaptation. These methods are crucial for maintaining long-term stability and generalization in dynamic environments.

## 7 FUTURE DIRECTIONS

As CLIP-powered DG and DA evolve, future research should focus on addressing current limitations and unlocking new potentials for broader applications. This will involve tackling challenges that enhance the models' capabilities, allowing for more effective and reliable deployment across various domains.

Interpretable CLIP-Powered Models. Improving the interpretability of CLIP-powered models is crucial for critical applications like healthcare and finance, where transparency is vital $\left\lbrack  {{30},{198}}\right\rbrack$ . Future research could explore explainable AI techniques [136] to enhance model transparency, such as interactive visualizations and human-understandable explanations. This would improve user trust and facilitate collaboration between human experts and AI systems, leading to more responsible deployment.

Robustness Against Domain Shifts. Addressing domain shifts is a key challenge in domain generalization and adaptation. Future research may focus on robust training frameworks, like adversarial training or meta-learning, to help CLIP-powered models maintain performance in dynamic environments. These approaches could enable better handling of real-world variations and improve model robustness across diverse applications.

Automated Domain Discovery. Automated methods for discovering and characterizing target domains could be explored, using unsupervised clustering to identify distinct domains from unlabeled data. Advanced clustering and dimensionality reduction algorithms could uncover patterns, while self-assessment mechanisms would improve model adaptability, enhancing CLIP-powered systems' robustness.

Scalable Computational Strategies. Scalable computational strategies for CLIP-based models can be explored through techniques like model pruning, quantization, and distributed computing (cloud and edge platforms) to reduce complexity while maintaining performance. Hybrid approaches combining local and cloud resources could enhance scalability and reduce latency, making CLIP models more accessible.

Integration of Multimodal Data. Integrating multimodal data, such as text, images, audio, and sensor data [165], can enhance CLIP model performance [58]. Developing architectures that fuse multiple data types can improve generalization and adaptability, while cross-modal learning can boost effectiveness, enabling models to address diverse real-world challenges.

Addressing Catastrophic Forgetting. Catastrophic forgetting is a significant challenge in fine-tuning CLIP models, especially in dynamic environments. To address this, techniques like memory-augmented architectures, regularization with dynamic replay, and meta-learning can help models retain prior knowledge while adapting to new tasks $\left\lbrack  {{31},{160}}\right\rbrack$ . These strategies can improve the model's long-term robustness in real-world applications.

![bo_d282qmv7aajc738ormjg_13_149_121_717_694_0.jpg](images/bo_d282qmv7aajc738ormjg_13_149_121_717_694_0.jpg)

Fig. 12. Percentage of cited papers in different sections.

Ethical Considerations and Bias Mitigation. Ethical deployment of CLIP models involves addressing biases by conducting audits across diverse demographics and applying fairness-aware learning techniques. Engaging stakehold-ers in the development process ensures that the models are inclusive, promoting fairness and robustness while mitigating potential biases in CLIP applications.

## 8 CONCLUSION

This survey provides an overview of CLIP's applications in domain generalization (DG) and domain adaptation (DA), emphasizing its zero-shot capabilities for handling unseen domains without extensive retraining. It explores methodologies such as prompt learning optimization and CLIP as a backbone architecture to enhance generalization and adaptation strategies. Key challenges like overfitting, domain shifts, and limited labeled data are addressed, along with gaps in existing literature. Fig. 12 visualizes the distribution of CLIP-based approaches in DG and DA, offering insights into their prevalence. By identifying future research directions, this survey encourages further innovation, aiming to improve the robustness, interpretability, and adaptability of CLIP-powered AI systems. REFERENCES

[1] S. Addepalli, A. R. Asokan, L. Sharma, and R. V. Babu. Leveraging vision-language models for improving domain generalization in image classification. In Proc. of CVPR, pages 23922-23932, 2024.

[2] E. L. Aleixo, J. G. Colonna, M. Cristo, and E. Fernandes. Catastrophic forgetting in deep learning: a comprehensive taxonomy. arXiv:2312.10549, 2023.

[3] E. Ali, S. Silva, and M. H. Khan. Dpa: Dual prototypes alignment for unsupervised adaptation of vision-language models. arXiv:2408.08855, 2024.

[4] H. Bahng, A. Jahanian, S. Sankaranarayanan, and P. Isola. Visual prompting: Modifying pixel space to adapt pre-trained models. arXiv:2203.17274, 3(11-12): 3, 2022.

[5] S. Bai, M. Zhang, W. Zhou, S. Huang, Z. Luan, D. Wang, and B. Chen. Prompt-based distribution alignment for unsupervised domain adaptation. In Proc. of AAAI, volume 38, pages 729-737, 2024.

[6] S. Bai, Y. Zhang, W. Zhou, Z. Luan, and B. Chen. Soft prompt generation for domain generalization. arXiv:2404.19286, 2024.

[7] S. Beery, G. Van Horn, and P. Perona. Recognition in terra incognita. In Proc. of ECCV, pages 456-473, 2018.

[8] S. Bose, A. Jha, E. Fini, M. Singha, E. Ricci, and B. Banerjee. Stylip: Multi-scale style-conditioned prompt learning for clip-based domain generalization. In Proc. of WACV, pages 5542-5552, 2024.

[9] L. Bossard, M. Guillaumin, and L. Van Gool. Food- 101-mining discriminative components with random forests. In Proc. of ECCV, pages 446-461. Springer, 2014.

[10] S. Bucci, F. C. Borlino, B. Caputo, and T. Tommasi. Distance-based hyperspherical classification for multi-source open-set domain adaptation. In Proc. of WACV, pages 1119-1128, 2022.

[11] H. Cai, C. Gan, L. Zhu, and S. Han. Tinyll: Reduce memory, not parameters for efficient on-device learning. Proc. of NeurIPS, 33:11285-11297, 2020.

[12] J. Cha, S. Chun, K. Lee, H.-C. Cho, S. Park, Y. Lee, and S. Park. Swad: Domain generalization by seeking flat minima. Proc. of NeurIPS, 34:22405-22418, 2021.

[13] X. Che, H. Zuo, J. Lu, and D. Chen. Fuzzy multioutput transfer learning for regression. IEEE Trans. on Fuzzy Systems, 30(7):2438-2451, 2021.

[14] G. Chen, W. Yao, X. Song, X. Li, Y. Rao, and K. Zhang. Prompt learning with optimal transport for vision-language models. OpenReview, 2022.

[15] G. Chen, W. Yao, X. Song, X. Li, Y. Rao, and K. Zhang. Plot: Prompt learning with optimal transport for vision-language models. arXiv:2210.01253, 2022.

[16] H. Chen, X. Han, Z. Wu, and Y.-G. Jiang. Multi-prompt alignment for multi-source unsupervised domain adaptation. Proc. of NeurIPS, 36:74127-74139, 2023.

[17] S. Chen, C. Ge, Z. Tong, J. Wang, Y. Song, J. Wang, and P. Luo. Adaptformer: Adapting vision transformers for scalable visual recognition. Proc. of NeurIPS, 35: 16664-16678, 2022.

[18] T. Chen, S. Kornblith, M. Norouzi, and G. Hinton. A simple framework for contrastive learning of visual representations. In Proc. of ICML, pages 1597-1607. PMLR, 2020.

[19] Z. Chen and B. Liu. Continual learning and catastrophic forgetting. In Lifelong Machine Learning, pages 55-75. Springer, 2018.

[20] Z. Chen, Y. Duan, W. Wang, J. He, T. Lu, J. Dai, and Y. Qiao. Vision transformer adapter for dense predictions. arXiv:2205.08534, 2022.

[21] Z. Chen, W. Wang, Z. Zhao, F. Su, A. Men, and Y. Dong. Instance paradigm contrastive learning for domain generalization. IEEE TCSVT, 34(2):1032-1042, 2023.

[22] Z. Chen, W. Wang, Z. Zhao, F. Su, A. Men, and H. Meng. Practicaldg: Perturbation distillation on vision-language models for hybrid domain generalization. In Proc. of CVPR, pages 23501-23511, 2024.

[23] D. Cheng, Z. Xu, X. Jiang, N. Wang, D. Li, and X. Gao. Disentangled prompt representation for domain generalization. In Proc. of CVPR, pages 23595-23604, 2024.

[24] E. Cho, J. Kim, and H. J. Kim. Distribution-aware prompt tuning for vision-language models. In Proc. of ICCV, pages 22004-22013, 2023.

[25] J. Cho, G. Nam, S. Kim, H. Yang, and S. Kwak. Promptstyler: Prompt-driven style generation for source-free domain generalization. In Proc. of ICCV, pages 15702-15712, 2023.

[26] J. Choi, M. Jeong, T. Kim, and C. Kim. Pseudo-labeling curriculum for unsupervised domain adaptation. arXiv:1908.00262, 2019.

[27] S. Choi, D. Das, S. Choi, S. Yang, H. Park, and S. Yun. Progressive random convolutions for single domain generalization. In Proc. of CVPR, pages 10312-10322, 2023.

[28] M. Cimpoi, S. Maji, I. Kokkinos, S. Mohamed, and A. Vedaldi. Describing textures in the wild. In Proc. of CVPR, pages 3606-3613, 2014.

[29] E. D. Cubuk, B. Zoph, J. Shlens, and Q. V. Le. Ran-daugment: Practical automated data augmentation with a reduced search space. In Proc. of CVPR Workshop, pages 702-703, 2020.

[30] A. Das and P. Rad. Opportunities and challenges in explainable artificial intelligence (xai): A survey. arXiv:2006.11371, 2020.

[31] M. De Lange, R. Aljundi, M. Masana, S. Parisot, X. Jia, A. Leonardis, G. Slabaugh, and T. Tuytelaars. A continual learning survey: Defying forgetting in classification tasks. IEEE TPAMI, 44(7):3366-3385, 2021.

[32] J. Deng, W. Dong, R. Socher, L.-J. Li, K. Li, and L. Fei-Fei. Imagenet: A large-scale hierarchical image database. In Proc. of CVPR, pages 248-255. IEEE, 2009.

[33] K. Desai and J. Johnson. Virtex: Learning visual representations from textual annotations. In Proc. of CVPR, pages 11162-11173, 2021.

[34] X. Dong, J. Bao, Y. Zheng, T. Zhang, D. Chen, H. Yang, M. Zeng, W. Zhang, L. Yuan, D. Chen, et al. Maskclip: Masked self-distillation advances contrastive language-image pretraining. In Proc. of CVPR, pages 10995-11005, 2023.

[35] Z. Du, X. Li, F. Li, K. Lu, L. Zhu, and J. Li. Domain-agnostic mutual prompting for unsupervised domain adaptation. In Proc. of CVPR, pages 23375-23384, 2024.

[36] Chen Fang, Ye Xu, and Daniel N Rockmore. Unbiased metric learning: On the utilization of multiple datasets and web images for softening bias. In Proc. of ICCV, pages 1657-1664, 2013.

[37] L. Fei-Fei, R. Fergus, and P. Perona. Learning generative visual models from few training examples: An incremental bayesian approach tested on 101 object categories. In Proc. of CVPR Workshop, pages 178-178. IEEE, 2004.

[38] R. Feng, T. Yu, X. Jin, X. Yu, L. Xiao, and Z. Chen. Rethinking domain adaptation and generalization in the era of clip. In Proc. of ICIP, pages 2585-2591. IEEE, 2024.

[39] A. Fürst, E. Rumetshofer, J. Lehner, V. T. Tran, F. Tang, H. Ramsauer, D. Kreil, M. Kopp, G. Klambauer, A. Bitto, et al. Cloob: Modern hopfield networks with infoloob outperform clip. Proc. of NeurIPS, 35:20450- 20468, 2022.

[40] R. Gal, O. Patashnik, H. Maron, A. H. Bermano, G. Chechik, and D. Cohen-Or. Stylegan-nada: Clip-guided domain adaptation of image generators. ACM TOG, 41(4):1-13, 2022.

[41] Y. Gal and Z. Ghahramani. Dropout as a bayesian approximation: Representing model uncertainty in deep learning. In Proc. of ICML, pages 1050-1059, 2016.

[42] Z. Gan, L. Li, C. Li, L. Wang, Z. Liu, J. Gao, et al. Vision-language pre-training: Basics, recent advances, and future trends. FTCGV, 14(3-4):163-352, 2022.

[43] J. Gao, J. Ruan, S. Xiang, Z. Yu, K. Ji, M. Xie, T. Liu, and Y. Fu. Lamm: Label alignment for multi-modal prompt learning. In Proc. of AAAI, volume 38, pages 1815-1823, 2024.

[44] P. Gao, S. Geng, R. Zhang, T. Ma, R. Fang, Y. Zhang, H. Li, and Y. Qiao. Clip-adapter: Better vision-language models with feature adapters. IJCV, 132(2): 581-595, 2024.

[45] T. Gao, A. Fisch, and D. Chen. Making pre-trained language models better few-shot learners. arXiv:2012.15723, 2020.

[46] C. Ge, R. Huang, M. Xie, Z. Lai, S. Song, S. Li, and G. Huang. Domain adaptation via prompt learning. IEEE TNNLS, 2023.

[47] J. Gu, Z. Han, S. Chen, A. Beirami, B. He, G. Zhang, R. Liao, Y. Qin, V. Tresp, and P. Torr. A systematic survey of prompt engineering on vision-language foundation models. arXiv:2307.12980, 2023.

[48] J. Guo, L. Qi, and Y. Shi. Domaindrop: Suppressing domain-sensitive channels for domain generalization. In Proc. of CVPR, pages 19114-19124, 2023.

[49] K. He, H. Fan, Y. Wu, S. Xie, and R. Girshick. Momentum contrast for unsupervised visual representation learning. In Proc. of CVPR, pages 9729-9738, 2020.

[50] P. Helber, B. Bischke, A. Dengel, and D. Borth. Eu-rosat: A novel dataset and deep learning benchmark for land use and land cover classification. IEEE J-STAR, 12(7):2217-2226, 2019.

[51] D. Hendrycks, S. Basart, N. Mu, S. Kadavath, F. Wang, E. Dorundo, R. Desai, T. Zhu, S. Parajuli, M. Guo, et al. The many faces of robustness: A critical analysis of out-of-distribution generalization. In Proc. of ICCV, pages 8340-8349, 2021.

[52] D. Hendrycks, K. Zhao, S. Basart, J. Steinhardt, and D. Song. Natural adversarial examples. In Proc. of CVPR, pages 15262-15271, 2021.

[53] R. D. Hjelm, A. Fedorov, S. Lavoie-Marchildon, K. Grewal, P. Bachman, A. Trischler, and Y. Bengio. Learning deep representations by mutual information estimation and maximization. Proc. of ICLR, 2018.

[54] N. Houlsby, A. Giurgiu, S. Jastrzebski, B. Morrone, Q. De Laroussilhe, A. Gesmundo, M. Attariyan, and S. Gelly. Parameter-efficient transfer learning for nlp. In Proc. of ICML, pages 2790-2799. PMLR, 2019.

[55] E. J. Hu, Y. Shen, P. Wallis, Z. Allen-Zhu, Y. Li, S. Wang, L. Wang, and W. Chen. Lora: Low-rank adaptation of large language models. arXiv:2106.09685, 2021.

[56] X. Hu, K. Zhang, L. Xia, A. Chen, J. Luo, Y. Sun, K. Wang, N. Qiao, X. Zeng, M. Sun, et al. Reclip: Refine contrastive language image pre-training with source-free domain adaptation. In Proc. of WACV, pages 2994-3003, 2024.

[57] T. Huang, J. Chu, and F. Wei. Unsupervised prompt learning for vision-language models. arXiv:2204.03649, 2022.

[58] Y. Huang, C. Du, Z. Xue, X. Chen, H. Zhao, and L. Huang. What makes multi-modal learning better than single (provably). In Proc. NeurIPS, volume 34, pages 10944-10956, 2021.

[59] Z. Huang, H. Wang, E. P. Xing, and D. Huang. Self-challenging improves cross-domain generalization. In Proc. of ECCV, pages 124-140. Springer, 2020.

[60] Z. Huang, A. Zhou, Z. Ling, M. Cai, H. Wang, and Y. J. Lee. A sentence speaks a thousand images: Domain generalization through distilling clip with language guidance. In Proc. of ICCV, pages 11685-11695, 2023.

[61] G. Ilharco, M. Wortsman, S. Y. Gadre, S. Song, H. Ha-jishirzi, S. Kornblith, A. Farhadi, and L. Schmidt. Patching open-vocabulary models by interpolating weights. Proc. of NeurIPS, 35:29262-29277, 2022.

[62] S. Ioffe. Batch normalization: Accelerating deep network training by reducing internal covariate shift. arXiv:1502.03167, 2015.

[63] C. Jia, Y. Yang, Y. Xia, Y.-T. Chen, Z. Parekh, H. Pham, Q. Le, Y.-H. Sung, Z. Li, and T. Duerig. Scaling up visual and vision-language representation learning with noisy text supervision. In Proc. of ICML, pages 4904-4916. PMLR, 2021.

[64] M. Jia, L. Tang, B.-C. Chen, C. Cardie, S. Belongie, B. Hariharan, and S.-N. Lim. Visual prompt tuning. In Proc. of ECCV, pages 709-727. Springer, 2022.

[65] Z. Jiang, F. F. Xu, J. Araki, and G. Neubig. How can we know what language models know? Trans. of ACL, $8 : {423} - {438},{2020}$ .

[66] C. Ju, T. Han, K. Zheng, Y. Zhang, and W. Xie. Prompting visual-language models for efficient video understanding. In Proc. of ECCV, pages 105-124. Springer, 2022.

[67] J. Kang, S. Lee, N. Kim, and S. Kwak. Style neophile: Constantly seeking novel styles for domain generalization. In Proc. of CVPR, pages 7130-7140, 2022.

[68] K. Katsumata, I. Kishida, A. Amma, and [86] H. Nakayama. Open-set domain generalization via metric learning. In Proc. of ICIP, pages 459-463, 2021.

[69] R. Kemker, M. McClure, A. Abitino, T. Hayes, and [87] C. Kanan. Measuring catastrophic forgetting in neural networks. In Proc. AAAI, volume 32, 2018.

[70] M. U. Khattak, H. Rasheed, M. Maaz, S. Khan, and F. S. Khan. Maple: Multi-modal prompt learning. In Proc. of CVPR, pages 19113-19122, 2023.

[71] M. U. Khattak, S. T. Wasim, M. Naseer, S. Khan, M.- H. Yang, and F. S. Khan. Self-regulating prompts: Foundational model adaptation without forgetting. In Proc. of ICCV, pages 15190-15200, 2023.

[72] G. Kim, T. Kwon, and J. C. Ye. Diffusionclip: Text-guided diffusion models for robust image manipulation. In Proc. of CVPR, pages 2426-2435, 2022.

[73] J. Kim, K. Ryoo, J. Seo, G. Lee, D. Kim, H. Cho, and S. Kim. Semi-supervised learning of semantic correspondence with pseudo-labels. In Proc. of CVPR, pages 19699-19709, 2022.

[74] J. Krause, M. Stark, J. Deng, and L. Fei-Fei. 3d object representations for fine-grained categorization. In Proc. of ICCV Workshop, pages 554-561, 2013.

[75] A. Krizhevsky, G. Hinton, et al. Learning multiple layers of features from tiny images. 2009.

[76] G. Kwon and J. C. Ye. Clipstyler: Image style transfer with a single text condition. In Proc. of CVPR, pages 18062-18071, 2022.

[77] M. Lafon, E. Ramzi, C. Rambour, N. Audebert, and N. Thome. Gallop: Learning global and local prompts for vision-language models. arXiv:2407.01400, 2024.

[78] Z. Lai, N. Vesdapunt, N. Zhou, J. Wu, C. P. Huynh, X. Li, K. K. Fu, and C.-N. Chuah. Padclip: Pseudo-labeling with adaptive debiasing in clip for unsupervised domain adaptation. In Proc. of ICCV, pages 16155-16165, 2023.

[79] Z. Lai, H. Bai, H. Zhang, X. Du, J. Shan, Y. Yang, C.-N. Chuah, and M. Cao. Empowering unsupervised domain adaptation with large-scale pre-trained vision-language models. In Proc. of WACV, pages 2691-2701, 2024.

[80] K. Lee, S. Kim, and S. Kwak. Cross-domain ensemble distillation for domain generalization. In Proc. of ECCV, pages 1-20. Springer, 2022.

[81] S. Lee, J. Bae, and H. Y. Kim. Decompose, adjust, compose: Effective normalization by playing with frequency for domain generalization. In Proc. of CVPR, pages 11776-11785, 2023.

[82] B. Lester, R. Al-Rfou, and N. Constant. The power of scale for parameter-efficient prompt tuning. arXiv:2104.08691, 2021.

[83] Da Li, Yongxin Yang, Yi-Zhe Song, and Timothy M Hospedales. Deeper, broader and artier domain generalization. In Proc. of ICCV, pages 5542-5550, 2017.

[84] H. Li, S. J. Pan, S. Wang, and A. C. Kot. Domain generalization with adversarial feature learning. In Proc. of CVPR, pages 5400-5409, 2018.

[85] J. Li, Z. Yu, Z. Du, L. Zhu, and H. T. Shen. A comprehensive survey on source-free domain adaptation. IEEE TPAMI, 2024.

[86] K. Li, J. Lu, H. Zuo, and G. Zhang. Attention-bridging ts fuzzy rules for universal multi-domain adaptation without source data. In Proc. of FUZZ-IEEE, pages 1-6. IEEE, 2023.

[87] K. Li, J. Lu, H. Zuo, and G. Zhang. Source-free multidomain adaptation with fuzzy rule-based deep neural networks. IEEE Trans. on Fuzzy Systems, 31(12): 4180-4194, 2023.

[88] K. Li, J. Lu, H. Zuo, and G. Zhang. Source-free multidomain adaptation with fuzzy rule-based deep neural networks. IEEE Trans. on Fuzzy Systems, 31(12): 4180-4194, 2023.

[89] X. Li, Y. Li, Z. Du, F. Li, K. Lu, and J. Li. Split to merge: Unifying separated modalities for unsupervised domain adaptation. In Proc. of CVPR, pages 23364-23374, 2024.

[90] X. L. Li and P. Liang. Prefix-tuning: Optimizing continuous prompts for generation. arXiv:2101.00190, 2021.

[91] Y. Li, Y. Cao, J. Li, Q. Wang, and S. Wang. Data-efficient clip-powered dual-branch networks for source-free unsupervised domain adaptation. arXiv:2410.15811, 2024.

[92] Y.-J. Li, X. Dai, C.-Y. Ma, Y.-C. Liu, K. Chen, B. Wu, Z. He, K. Kitani, and P. Vajda. Cross-domain adaptive teacher for object detection. In Proc. of CVPR, pages 7581-7590, 2022.

[93] J. Liang, R. He, and T. Tan. A comprehensive survey on test-time adaptation under distribution shifts. IJCV, pages 1-34, 2024.

[94] J. Liang, L. Sheng, Z. Wang, R. He, and T. Tan. Realistic unsupervised clip fine-tuning with universal entropy optimization. In Proc. of ICML, 2024.

[95] F. Liu, J. Lu, and G. Zhang. Unsupervised heterogeneous domain adaptation via shared fuzzy equivalence relations. IEEE Trans. on Fuzzy Systems, 26(6): 3555-3568, 2018.

[96] F. Liu, G. Zhang, and J. Lu. Multisource heterogeneous unsupervised domain adaptation via fuzzy relation neural networks. IEEE Trans. on Fuzzy Systems, 29(11):3308-3322, 2020.

[97] H. Liu, J. Wang, and M. Long. Cycle self-training for domain adaptation. Proc. of NeurIPS, 34:22968-22981, 2021.

[98] Pengfei Liu, Weizhe Yuan, Jinlan Fu, Zhengbao Jiang, Hiroaki Hayashi, and Graham Neubig. Pre-train, prompt, and predict: A systematic survey of prompting methods in natural language processing. ACM Computing Surveys, 55(9):1-35, 2023.

[99] M. Long, H. Zhu, J. Wang, and M. I. Jordan. Deep transfer learning with joint adaptation networks. In Proc. of ICML, pages 2208-2217. PMLR, 2017.

[100] M. Long, Z. Cao, J. Wang, and M. I. Jordan. Conditional adversarial domain adaptation. Proc. of NeurIPS, 31, 2018.

[101] S. Long, L. Wang, Z. Zhao, Z. Tan, Y. Wu, S. Wang, and J. Wang. Training-free unsupervised prompt for vision-language models. arXiv:2404.16339, 2024.

[102] I. Loshchilov. Decoupled weight decay regularization. arXiv:1711.05101, 2017.

[103] J. Lu, H. Zuo, and G. Zhang. Fuzzy multiple-source transfer learning. IEEE Trans. on Fuzzy Systems, 28(12): 3418-3431, 2019.

[104] Y. Lu, J. Liu, Y. Zhang, Y. Liu, and X. Tian. Prompt distribution learning. In Proc. of CVPR, pages 5206- 5215, 2022.

[105] F. Lv, J. Liang, S. Li, B. Zang, C. H. Liu, Z. Wang, and D. Liu. Causality inspired representation learning for domain generalization. In Proc. of CVPR, pages 8046- 8056, 2022.

[106] W. Ma, S. Li, J. Zhang, C. H. Liu, J. Kang, Y. Wang, and G. Huang. Borrowing knowledge from pre-trained language model: A new data-efficient visual learning paradigm. In Proc. of ICCV, pages 18786-18797, 2023.

[107] S. Maji, E. Rahtu, J. Kannala, M. Blaschko, and A. Vedaldi. Fine-grained visual classification of aircraft. arXiv:1306.5151, 2013.

[108] K. Mei, C. Zhu, J. Zou, and S. Zhang. Instance adaptive self-training for unsupervised domain adaptation. In Proc. of ECCV, pages 415-430. Springer, 2020.

[109] Y. Min, K. Ryoo, B. Kim, and T. Kim. Uota: Unsupervised open-set task adaptation using a vision-language foundation model. In Proc. of ICML Workshop, 2023.

[110] M. J. Mirza, L. Karlinsky, W. Lin, H. Possegger, M. Kozinski, R. Feris, and H. Bischof. Lafter: Label-free tuning of zero-shot classifier using language and unlabeled image collections. Proc. of NeurIPS, 36, 2024.

[111] A. Miyai, Q. Yu, G. Irie, and K. Aizawa. Locoop: Few-shot out-of-distribution detection via prompt learning. Proc. of NeurIPS, 36:76298-76310, 2023.

[112] A. Miyai, Q. Yu, G. Irie, and K. Aizawa. Zero-shot in-distribution detection in multi-object settings using vision-language foundation models. arXiv:2304.04521, 2023.

[113] M. Monga, S. K. Giroh, A. Jha, M. Singha, B. Banerjee, and J. Chanussot. Cosmo: Clip talks on open-set multi-target domain adaptation. arXiv:2409.00397, 2024.

[114] C. Mou, X. Wang, L. Xie, Y. Wu, J. Zhang, Z. Qi, and Y. Shan. T2i-adapter: Learning adapters to dig out more controllable ability for text-to-image diffusion models. In Proc. of AAAI, volume 38, pages 4296-4304, 2024.

[115] M.-E. Nilsback and A. Zisserman. Automated flower classification over a large number of classes. In 2008 Sixth Indian Conf. on CVGIP, pages 722-729. IEEE, 2008.

[116] H. Niu, H. Li, F. Zhao, and B. Li. Domain-unified prompt representations for source-free domain generalization. arXiv:2209.14926, 2022.

[117] M. Noguchi and S. Shirakawa. Simple domain generalization methods are strong baselines for open domain generalization. In Proc. of IJCNN, pages 1-8, 2024.

[118] J. Oppenlaender. The creativity of text-to-image generation. In Proc. of MindTrek, pages 192-202, 2022.

[119] O. M. Parkhi, A. Vedaldi, A. Zisserman, and C. V. Jawahar. Cats and dogs. In Proc. of CVPR, pages 3498- 3505. IEEE, 2012.

[120] O. Patashnik, Z. Wu, E. Shechtman, D. Cohen-Or, and D. Lischinski. Styleclip: Text-driven manipulation of stylegan imagery. In Proc. of ICCV, pages 2085-2094, 2021.

[121] Xingchao Peng, Ben Usman, Neela Kaushik, Judy Hoffman, Dequan Wang, and Kate Saenko. Visda: The visual domain adaptation challenge. arXiv:1710.06924, 2017.

[122] Xingchao Peng, Qinxun Bai, Xide Xia, Zijun Huang, Kate Saenko, and Bo Wang. Moment matching for multi-source domain adaptation. In Proc. of ICCV, pages 1406-1415, 2019.

[123] F. Petroni, T. Rocktäschel, P. Lewis, A. Bakhtin, Y. Wu, A. H. Miller, and S. Riedel. Language models as knowledge bases? arXiv:1909.01066, 2019.

[124] Y. Qiao, K. Li, J. Lin, R. Wei, C. Jiang, Y. Luo, and H. Yang. Robust domain generalization for multimodal object recognition. In Proc. of AIEA, pages 392- 397. IEEE, 2024.

[125] Chengwei Qin and Shafiq Joty. Lfpt5: A unified framework for lifelong few-shot language learning based on prompt tuning of t5. arXiv:2110.07298, 2021.

[126] S. Qu, Y. Pan, G. Chen, T. Yao, C. Jiang, and T. Mei. Modality-agnostic debiasing for single domain generalization. In Proc. of CVPR, pages 24142-24151, 2023.

[127] A. Radford, J. W. Kim, C. Hallacy, A. Ramesh, G. Goh, S. Agarwal, G. Sastry, A. Askell, P. Mishkin, J. Clark, et al. Learning transferable visual models from natural language supervision. In Proc. of ICML, pages 8748- 8763. PMLR, 2021.

[128] A. Ramesh, M. Pavlov, G. Goh, S. Gray, C. Voss, A. Radford, M. Chen, and I. Sutskever. Zero-shot text-to-image generation. In Proc. of ICML, pages 8821- 8831. PMLR, 2021.

[129] Y. Rao, W. Zhao, G. Chen, Y. Tang, Z. Zhu, G. Huang, J. Zhou, and J. Lu. Denseclip: Language-guided dense prediction with context-aware prompting. In Proc. of CVPR, pages 18082-18091, 2022.

[130] B. Recht, R. Roelofs, L. Schmidt, and V. Shankar. Do imagenet classifiers generalize to imagenet? In Proc. of ICML, pages 5389-5400. PMLR, 2019.

[131] R. Rombach, A. Blattmann, D. Lorenz, P. Esser, and B. Ommer. High-resolution image synthesis with latent diffusion models. In Proc. of CVPR, pages 10684- 10695, 2022.

[132] Kate Saenko, Brian Kulis, Mario Fritz, and Trevor Darrell. Adapting visual category models to new domains. In Proc. of ECCV 2010, pages 213-226. Springer, 2010.

[133] C. Saharia, W. Chan, S. Saxena, L. Li, J. Whang, E. L. Denton, K. Ghasemipour, R. Gontijo Lopes, B. Karagol Ayan, T. Salimans, et al. Photorealistic text-to-image diffusion models with deep language understanding. Proc. of NeurIPS, 35:36479-36494, 2022.

[134] M. B. Sariyildiz, J. Perez, and D. Larlus. Learning visual representations with caption annotations. In Proc. of ECCV, pages 153-170. Springer, 2020.

[135] S. Schulhoff, M. Ilie, N. Balepur, K. Kahadze, A. Liu, C. Si, Y. Li, A. Gupta, H. Han, S. Schulhoff, et al. The prompt report: A systematic survey of prompting techniques. arXiv:2406.06608, 2024.

[136] G. Schwalbe and B. Finzel. A comprehensive taxonomy for explainable artificial intelligence: a systematic survey of surveys on methods and concepts. DMKD, 38(5):3043-3101, 2024.

[137] S. Shankar, V. Piratla, S. Chakrabarti, S. Chaudhuri, P. Jyothi, and S. Sarawagi. Generalizing across domains via cross-gradient training. arXiv:1804.10745, 2018.

[138] S. Shen, S. Yang, T. Zhang, B. Zhai, J. E. Gonzalez, K. Keutzer, and T. Darrell. Multitask vision-language prompt tuning. In Proc. of CVPR, pages 5656-5667, 2024.

[139] K. Shi, J. Lu, Z. Fang, and G. Zhang. Enhancing vision-language models incorporating tsk fuzzy system for domain adaptation. In Proc. of FUZZ-IEEE, pages 1-8, 2024.

[140] K. Shi, J. Lu, Z. Fang, and G. Zhang. Clip-enhanced unsupervised domain adaptation with consistency regularization. In Proc. of IJCNN, pages 1-8, 2024.

[141] K. Shi, J. Lu, Z. Fang, and G. Zhang. Unsupervised domain adaptation enhanced by fuzzy prompt learning. IEEE TFS, 2024.

[142] T. Shin, Y. Razeghi, R. L. Logan IV, E. Wallace, and S. Singh. Autoprompt: Eliciting knowledge from language models with automatically generated prompts. arXiv:2010.15980, 2020.

[143] Y. Shu, Z. Cao, C. Wang, J. Wang, and M. Long. Open domain generalization with domain-augmented meta-learning. In Proc. of CVPR, pages 9624-9633, 2021.

[144] Y. Shu, X. Guo, J. Wu, X. Wang, J. Wang, and M. Long. Clipood: Generalizing clip to out-of-distributions. In Proc. of ICML, pages 31716-31731. PMLR, 2023.

[145] A. Singh, R. Hu, V. Goswami, G. Couairon, W. Galuba, M. Rohrbach, and D. Kiela. Flava: A foundational language and vision alignment model. In Proc. of CVPR, pages 15638-15650, 2022.

[146] M. Singha, H. Pal, A. Jha, and B. Banerjee. Ad-clip: Adapting domains in prompt space using clip. In Proc. of ICCV Workshop, pages 4355-4364, 2023.

[147] M. Singha, A. Jha, S. Bose, A. Nair, M. Abdar, and B. Banerjee. Unknown prompt the only lacuna: Unveiling clip's potential for open domain generalization. In Proc. of CVPR, pages 13309-13319, 2024.

[148] K. Sohn, D. Berthelot, N. Carlini, Z. Zhang, H. Zhang, C. A. Raffel, E. D. Cubuk, A. Kurakin, and C.-L. Li. Fixmatch: Simplifying semi-supervised learning with consistency and confidence. Proc. of NeurIPS, 33:596- 608, 2020.

[149] K. Soomro. Ucf101: A dataset of 101 human actions classes from videos in the wild. arXiv:1212.0402, 2012.

[150] N. Srivastava, G. Hinton, A. Krizhevsky, I. Sutskever, and R. Salakhutdinov. Dropout: a simple way to prevent neural networks from overfitting. JMLR, 15 (1):1929-1958, 2014.

[151] A. C. Stickland and I. Murray. Bert and pals: Projected attention layers for efficient adaptation in multi-task learning. In Proc. of ICML, pages 5986-5995. PMLR, 2019.

[152] B. Sun and K. Saenko. Deep coral: Correlation alignment for deep domain adaptation. In Proc. of ECCV Workshop, pages 443-450. Springer, 2016.

[153] X. Sun, P. Hu, and K. Saenko. Dualcoop: Fast adaptation to multi-label recognition with limited annotations. Proc. of NeurIPS, 35:30569-30582, 2022.

[154] C. Szegedy, V. Vanhoucke, S. Ioffe, J. Shlens, and Z. Wojna. Rethinking the inception architecture for computer vision. In Proc. of CVPR, pages 2818-2826, 2016.

[155] S. Tang, W. Su, M. Ye, and X. Zhu. Source-free domain adaptation with frozen multimodal foundation model. In Proc. of CVPR, pages 23711-23720, 2024.

[156] Y. Tang, Y. Wan, L. Qi, and X. Geng. Dpstyler: Dynamic promptstyler for source-free domain generalization. arXiv:2403.16697, 2024.

[157] K. Tanwisuth, S. Zhang, H. Zheng, P. He, and M. Zhou. Pouf: Prompt-oriented unsupervised fine-tuning for large pre-trained models. In Proc. of ICML, pages 33816-33832, 2023.

[158] L. Tian, M. Ye, L. Zhou, and Q. He. Clip-guided black-box domain adaptation of image classification. Signal, Image and Video Processing, 18(5):4637-4646, 2024.

[159] M. Tsimpoukelli, J. L. Menick, S. Cabi, S. M. Eslami, O. Vinyals, and F. Hill. Multimodal few-shot learning with frozen language models. Proc. of NeurIPS, 34: 200-212, 2021.

[160] Gido M van de Ven, Nicholas Soures, and Dhireesha Kudithipudi. Continual learning and catastrophic forgetting. arXiv:2403.05175, 2024.

[161] Hemanth Venkateswara, Jose Eusebio, Shayok Chakraborty, and Sethuraman Panchanathan. Deep hashing network for unsupervised domain adaptation. In Proc. of CVPR, pages 5018-5027, 2017.

[162] H. Wang, S. Ge, Z. Lipton, and E. P. Xing. Learning robust global representations by penalizing local predictive power. Proc. of NeurIPS, 32, 2019.

[163] P. Wang, Z. Zhang, Z. Lei, and L. Zhang. Sharpness-aware gradient matching for domain generalization. In Proc. of CVPR, pages 3769-3778, 2023.

[164] X. Wang, J. Zhang, L. Qi, and Y. Shi. Generalizable decision boundaries: Dualistic meta-learning for open set domain generalization. In Proc. of ICCV, pages 11564-11573, 2023.

[165] Y. Wang. Survey on deep multi-modal data analytics: Collaboration, rivalry, and fusion. ACM TOMM, 17 (1s):1-25, 2021.

[166] Z. Wang, L. Zhang, L. Wang, and M. Zhu. Landa: Language-guided multi-source domain adaptation. arXiv:2401.14148, 2024.

[167] H. Wei, L. Chen, K. Ruan, and L. Li. Low-rank tensor regularized fuzzy clustering for multiview data. IEEE Trans. on Fuzzy Systems, 28(12):3087-3099, 2020.

[168] M. Wortsman, G. Ilharco, J. W. Kim, M. Li, S. Korn-blith, R. Roelofs, R. G. Lopes, H. Hajishirzi, A. Farhadi, H. Namkoong, et al. Robust fine-tuning of zero-shot models. In Proc. of CVPR, pages 7959-7971, 2022.

[169] J. Xiao, J. Hays, K. A. Ehinger, A. Oliva, and A. Tor-ralba. Sun database: Large-scale scene recognition from abbey to zoo. In Proc. of CVPR, pages 3485-3492. IEEE, 2010.

[170] Z. Xiao, J. Shen, M. M. Derakhshani, S. Liao, and C. G. M. Snoek. Any-shift prompting for generalization over distributions. In Proc. of CVPR, pages 13849- 13860, 2024.

[171] P. Xu, Z. Deng, J. Wang, Q. Zhang, K.-S. Choi, and S. Wang. Transfer representation learning with tsk fuzzy system. IEEE Trans. on Fuzzy Systems, 29(3):649- 663, 2019.

[172] Q. Xu, R. Zhang, Y. Zhang, Y. Wang, and Q. Tian. A fourier-based framework for domain generalization. In Proc. of CVPR, pages 14383-14392, 2021.

[173] Q. Xuan, T. Yu, L. Bai, and Y. Ruan. Consistent augmentation learning for generalizing clip to unseen domains. IEEE Access, 2024.

[174] S. Yan, C. Luo, Z. Yu, and Z. Ge. Generalizing clip to unseen domain via text-guided diverse novel feature synthesis. arXiv:2405.02586, 2024.

[175] L. Yang, R. Y. Zhang, Y. Wang, and X. Xie. Mma: Multimodal adapter for vision-language models. In Proc. of CVPR, pages 23826-23837, 2024.

[176] Y. Yang, Y. Hou, L. Wen, P. Zeng, and Y. Wang. Semantic-aware adaptive prompt learning for universal multi-source domain adaptation. IEEE Signal Processing Letters, 2024.

[177] H. Yao, R. Zhang, and C. Xu. Visual-language prompt tuning with knowledge-guided context optimization. In Proc. of CVPR, pages 6757-6767, 2023.

[178] Y. Yao, A. Zhang, Z. Zhang, Z. Liu, T.-S. Chua, and M. Sun. Cpt: Colorful prompt tuning for pre-trained vision-language models. arXiv e-prints, pages arXiv- 2109, 2021.

[179] M. Yi, L. Hou, J. Sun, L. Shang, X. Jiang, Q. Liu, and Z. Ma. Improved ood generalization via adversarial training and pretraining. In Proc. of ICML, pages 11987-11997. PMLR, 2021.

[180] Y. Yin, Z. Yang, H. Hu, and X. Wu. Universal multi-source domain adaptation for image classification. ${PR}$ , 121:108238, 2022.

[181] H. Yu, C. Jin, Y. Zhang, X. Cao, and Z. Fang. Domain prompt matters a lot in multi-source few-shot domain adaptation. openreview.net, 2024.

[182] Q. Yu, G. Irie, and K. Aizawa. Open-set domain adaptation with visual-language foundation models. arXiv:2307.16204, 2023.

[183] L. Yuan, D. Chen, Y.-L. Chen, N. Codella, X. Dai, J. Gao, H. Hu, X. Huang, B. Li, C. Li, et al. Florence: A new foundation model for computer vision. arXiv:2111.11432, 2021.

[184] S. Yun, D. Han, S. J. Oh, S. Chun, J. Choe, and Y. Yoo. Cutmix: Regularization strategy to train strong classifiers with localizable features. In Proc. of ICCV, pages 6023-6032, 2019.

[185] Y. Zang, W. Li, K. Zhou, C. Huang, and C. C. Loy. Unified vision and language prompt learning. arXiv:2210.07225, 2022.

[186] S. Zeng, X. Liu, and Y. Zhou. Decoupling domain invariance and variance with tailored prompts for open-set domain adaptation. In Proc. of ICIP, pages 645-651, 2024.

[187] B. Zhang, Y. Wang, W. Hou, H. Wu, J. Wang, M. Oku-mura, and T. Shinozaki. Flexmatch: Boosting semi-supervised learning with curriculum pseudo labeling. Proc. of NeurIPS, 34:18408-18419, 2021.

[188] H. Zhang. Mixup: Beyond empirical risk minimization. arXiv:1710.09412, 2017.

[189] H. Zhang, S. Bai, W. Zhou, J. Fu, and B. Chen. Promptta: Prompt-driven text adapter for source-free domain generalization. arXiv:2409.14163, 2024.

[190] J. Zhang, Q. Wei, F. Liu, and L. Feng. Candidate pseu-dolabel learning: Enhancing vision-language models by prompt tuning with unlabeled data. In Proc. of ICML, page 235, 2024.

[191] R. Zhang, Z. Guo, W. Zhang, K. Li, X. Miao, B. Cui, Y. Qiao, P. Gao, and H. Li. Pointclip: Point cloud understanding by clip. In Proc. of CVPR, pages 8552- 8562, 2022.

[192] W. Zhang, W. Ouyang, W. Li, and D. Xu. Collaborative and adversarial network for unsupervised domain adaptation. In Proc. of CVPR, pages 3801-3809, 2018.

[193] W. Zhang, L. Shen, and C.-S. Foo. Source-free domain adaptation guided by vision and vision-language pretraining. IJCV, pages 1-23, 2024.

[194] X. Zhang, S. S. Gu, Y. Matsuo, and Y. Iwasawa. Domain prompt learning for efficiently adapting clip to unseen domains. Transactions of the Japanese Society for Artificial Intelligence, 38(6):B-MC2_1, 2023.

[195] X. Zhang, Y. He, R. Xu, H. Yu, Z. Shen, and P. Cui. Nico++: Towards better benchmarking for domain generalization. In Proc. of CVPR, pages 16036-16047, 2023.

[196] X. Zhang, R. Xu, H. Yu, Y. Dong, P. Tian, and P. Cui. Flatness-aware minimization for domain generalization. In Proc. of ICCV, pages 5189-5202, 2023.

[197] Y. Zhang, H. Jiang, Y. Miura, C. D. Manning, and C. P. Langlotz. Contrastive learning of medical visual representations from paired images and text. In Proc. of MLHC, pages 2-25. PMLR, 2022.

[198] H. Zhao, H. Chen, F. Yang, N. Liu, H. Deng, H. Cai, S. Wang, D. Yin, and M. Du. Explainability for large language models: A survey. ACM TIST, 15(2):1-38, 2024.

[199] Z. Zhong, D. Friedman, and D. Chen. Factual probing is [mask]: Learning vs. learning to recall. arXiv:2104.05240, 2021.

[200] C. Zhou, C. C. Loy, and B. Dai. Extract free dense labels from clip. In Proc. of ECCV, pages 696-712. Springer, 2022.

[201] K. Zhou, Y. Yang, T. Hospedales, and T. Xiang. Learning to generate novel domains for domain generalization. In Proc. of ECCV, pages 561-578. Springer, 2020.

[202] K. Zhou, Y. Yang, Y. Qiao, and T. Xiang. Domain generalization with mixstyle. arXiv:2104.02008, 2021.

[203] K. Zhou, J. Yang, C. C. Loy, and Z. Liu. Conditional prompt learning for vision-language models. In Proc. of CVPR, pages 16816-16825, 2022.

[204] K. Zhou, J. Yang, C. C. Loy, and Z. Liu. Learning to prompt for vision-language models. IJCV, 130(9): 2337-2348, 2022.

[205] W. Zhou and Z. Zhou. Unsupervised domain adaptation harnessing vision-language pre-training. IEEE TCSVT, 2024.

[206] B. Zhu, Y. Niu, Y. Han, Y. Wu, and H. Zhang. Prompt-aligned gradient for prompt tuning. In Proc. of ICCV, pages 15659-15669, 2023.

[207] J. Zhu, Y. Chen, and L. Wang. Clip the divergence: Language-guided unsupervised domain adaptation. arXiv:2407.01842, 2024.

[208] Y. Zou, Z. Yu, B. V. K. Kumar, and J. Wang. Unsupervised domain adaptation for semantic segmentation via class-balanced self-training. In Proc. of ECCV, pages 289-305, 2018.

[209] H. Zuo, J. Lu, G. Zhang, and W. Pedrycz. Fuzzy rule-based domain adaptation in homogeneous and heterogeneous spaces. IEEE Trans. on Fuzzy Systems,