# Zero-shot Domain Generalization of Foundational Models for 3D Medical Image Segmentation: An Experimental Study

Soumitri Chattopadhyay ${}^{1}$ , Başar Demir ${}^{1}$ , and Marc Niethammer ${}^{2}$

${}^{1}$ University of North Carolina at Chapel Hill

${}^{2}$ University of California, San Diego

\{soumitri, bdemir\}@cs.unc.edu

mniethammer@ucsd.edu

Abstract. Domain shift, caused by variations in imaging modalities and acquisition protocols, limits model generalization in medical image segmentation. While foundation models (FMs) trained on diverse large-scale data hold promise for zero-shot generalization, their application to volumetric medical data remains underexplored. In this study, we examine their ability towards domain generalization (DG), by conducting a comprehensive experimental study encompassing 6 medical segmentation FMs and 12 public datasets spanning multiple modalities and anatomies. Our findings reveal the potential of promptable FMs in bridging the domain gap via smart prompting techniques. Additionally, by probing into multiple facets of zero-shot DG, we offer valuable insights into the viability of FMs for DG and identify promising avenues for future research.

Keywords: Domain generalization - Foundational models - 3D medical image segmentation

## 1 Introduction

Medical imaging involves a broad variety of scanners, acquisition protocols, imaging modalities (e.g., CT, MR, PET, ultrasound), sequences (T1w, T2w, ADC MRIs), and varying demographics. As a result, there are large variations in the distributions of the visual data. This issue is commonly referred to as ${do}$ - main shift [26], and poses a significant challenge for classical data-driven models, where the test distribution is assumed to match the training distribution. To overcome this, prior works have focused on domain adaptation [28,45], test-time adaptation [41,23] and domain generalization (DG) [43]. However, using these approaches requires individual models to be trained for a given pair of modalities and hence, cannot be adopted for generalized applications.

Originally rooted in the NLP community [4,37,5], foundational models (FMs) have recently been developed in the visual domain [2], for vision-language modeling [36], visual generation [38], registration [40,9] and segmentation [25,32]. A key characteristic of these models is that they are trained on large-scale cu-rated data, which suggests the potential to generalize to new distributions in a zero-shot manner. In particular, CLIP [36] and SAM [25] have shown impressive zero-shot capabilities for coarse-level classification and sparse-promptable segmentation tasks [44]. Recently, the SAM paradigm has been extended to medical volumes, leading to large-scale volumetric segmentation models $\left\lbrack  {{42},{13}}\right\rbrack$ , going beyond 2D slice-level approaches [32] to full-volume inference. However, to our best knowledge, no studies yet have investigated these foundational 3D segmenters for zero-shot domain generalization.

In this work, we probe the feasibility of zero-shot domain generalization for 3D medical image segmentation with segmentation FMs. To this end, we first describe a taxonomy that categorizes existing off-the-shelf FMs, based on their training knowledge (specific modalities/general), inputs (promptable/automatic) and targets (finite set of classes, or prompt-specific). Our study encompasses 6 medical FMs and 12 volumetric segmentation datasets (described in Sec. 3) comprising various anatomies and modalities. To assess zero-shot DG holistically, we examine dataset distribution shifts, cross-modal transferability (Sec. 4.1), and generalization to unseen anatomies (Sec. 4.2). Our empirical findings reveal that most existing FMs exhibit a significant domain gap compared to in-domain-trained specialist models [19]. However, recent text-promptable models show stronger DG, narrowing this gap (Sec. 4.3), potentially making them a promising direction for domain-generalizable models in medical image computing.

Our study is driven by two key factors: (i) Zero-shot generalizability is a desirable trait of FMs [2], and given their success in natural vision tasks [36,25,44], it is crucial to investigate whether similar performance extends to medical image segmentation across datasets, anatomies, and modalities. (ii) DG in medical image segmentation remains a long-standing challenge with significant relevance to federated learning [31,34], automating the manual clinical segmentation process, and adoption to newer modalities with limited annotations. Our work is both timely and essential for advancing research on zero-shot FM generalization.

## In summary, the contributions of our work are as follows:

1. We define a taxonomy for existing 3D medical segmentation FMs structured around domain generalization.

2. We assess their zero-shot performance across datasets encompassing diverse anatomies and multiple modalities/sequences.

3. Our analysis covers multiple facets of DG, including generalization to unseen modalities, the impact of different prompts, and adaptation to novel anatomical structures.

4. Our findings provide key insights into the feasibility of FMs for domain generalization and highlight promising directions for future research.

## 2 Related Work

Foundational models for segmentation: While prior approaches relied on training segmentation models based on a finite set of target classes $\left\lbrack  {{19},{39},{15}}\right\rbrack$ which limits their wider applicability, the advent of large-scale promptable models like SAM [25] imparted flexibility by enabling the model to generate outputs based on user-specified inputs. Recently, this paradigm has been adopted in medical imaging for $2\mathrm{D}\left\lbrack  {{32},8}\right\rbrack$ and $3\mathrm{D}\left\lbrack  {{42},{13}}\right\rbrack$ segmentations, being trained on assembled corpora of multi-sourced datasets. It is useful to probe how well, if at all, these models can generalize to varying data distributions and imaging modalities - which is what we explore in our current study.

Domain generalization in medical imaging: The broad range of imaging modalities, scanners, protocols, and demographics make domain shift a prevalent issue for 3D medical image segmentation [7], with dataset-specific trained models struggling to generalize to different domains. Prior approaches have focused on unsupervised domain adaptation [45,28], test-time adaptation [41,23] and domain generalization $\left\lbrack  {{43},{12},{14}}\right\rbrack$ . The recent advent of FMs for medical imaging $\left\lbrack  {{39},{16},{42}}\right\rbrack$ makes them potential candidates to achieve domain generalization, owing to their large-scale training across diverse datasets. In this work, we investigate the generalizability of such models for 3D segmentation tasks across multiple domain shift scenarios.

## 3 Materials and Methods

### 3.1 Datasets

We use several publicly available volumetric medical segmentation datasets spanning multiple anatomical regions and modalities, which facilitate (1) zero-shot domain transfer and (2) unseen organ segmentation experiments, both of which we feel are crucial to probe domain generalization.

- Abdominal organs: Datasets containing segmentations of various organs in the human abdominal region – BTCV [27], AMOS‘22 [21], FLARE‘22 [33], CHAOS [24], MSD-Spleen [1]. Notably, AMOS'22 provides both CT and MR datasets having the same target organs, and we use both in our study.

- Pelvic anatomy: Focused on prostate segmentation from MR volumes - MSD-Prostate [1] (having T2w and ADC sequences) and PROMISE12 [29]. We merged the peripheral and transitional regions in MSD-Prostate into a single region for consistency with PROMISE12 and models trained on the full prostate.

- Cardiac substructures: Datasets with segmentations of the atria, ventricles, and myocardium - MSD-Heart [1] and MMWHS - CT & MR [47].

Table 1 provides more details on the composition of the datasets.

### 3.2 Model Taxonomy

We describe a taxonomy for the 3D segmentation FMs used in this study and list them below. Additionally, Table 2 describes their training domains, target classes and preprocessing of inputs before passing them into their networks.

Table 1: Datasets used in our domain generalization study. They encompass a diverse range of anatomies (abdomen, pelvic, cardiac and entire body) across multiple modalities (CT, MR) and sequences (e.g., T1w, T2w, T2-SPIR, and ADC MRIs).

<table><tr><td>$\mathbf{{Dataset}}$</td><td>Anatomies</td><td>Modalities</td><td>#classes</td><td>#samples</td></tr><tr><td>BTCV [27]</td><td>abdominal organs</td><td>CT</td><td>13</td><td>30</td></tr><tr><td>AMOS’22 [21]</td><td>abdominal organs</td><td>CT, MR</td><td>15</td><td>CT: 120, MR: 60 (test set)</td></tr><tr><td>FLARE’22 [33]</td><td>abdominal organs</td><td>CT</td><td>13</td><td>train: 50; test: 22</td></tr><tr><td>CHAOS [24]</td><td>abdominal organs</td><td>MR: T2-SPIR</td><td>4</td><td>20</td></tr><tr><td>MSD-Spleen [1]</td><td>spleen (abdomen)</td><td>CT</td><td>1</td><td>41</td></tr><tr><td>MSD-Prostate [1]</td><td>prostate (pelvic)</td><td>MR: T2w, ADC</td><td>1</td><td>32</td></tr><tr><td>PROMISE12 [29]</td><td>prostate (pelvic)</td><td>MR: T2w</td><td>1</td><td>train: 50; test: 30</td></tr><tr><td>MMWHS [47]</td><td>cardiac substructures</td><td>CT, MR</td><td>5</td><td>CT: 20, MR: 20</td></tr><tr><td>MSD-Heart [1]</td><td>left atrium (cardiac)</td><td>MR</td><td>1</td><td>20</td></tr></table>

Domain-specific FMs: These include models that have been trained on cu-rated corpora comprising multiple anatomy-specific datasets in a specific modality. In this category, we consider the following models: FSEFT [39], VISTA3D [16] and MRSegmentator [15]. While the former two models were trained with publicly accessible CT volumes only, MRSegmentator was trained with both CT and MR data, the latter coming from an in-house corpus [15]. Moreover, FSEFT focuses on segmenting abdominal and thoracic structures, whereas VISTA3D and MRSegmentator are trained on a larger set of organs.

Visual Prompted FMs: As discussed earlier, promptable segmentation models $\left\lbrack  {{25},{42}}\right\rbrack$ enable more general segmentations, since the target can be guided by user-defined visual region of interest indicators (e.g., points/clicks, bounding boxes, or segmentation masks) [25]. Following this paradigm, we evaluate two such recently proposed models for volumetric medical segmentation: SAM-Med3D [42] and SegVol [13]. While SAM-Med3D is trained with 3D point prompts and multiple modalities, the latter is trained only on CT volumes and enables both points and bounding boxes as visual prompt inputs.

Text Prompted FMs: Moving beyond spatial prompts, we also evaluate text promptable segmentation models - SegVol [13] and SAT [46], where spatial prompts can be replaced (or augmented) with semantic text for target organs.

## 4 Experiments

Implementation: All models are implemented in PyTorch [35] and MONAI [6], accelerated by a 48GB Nvidia RTX A6000 GPU. We used publicly available codebases and checkpoints for all models. Specific preprocessing details for each model, such as input spacing and intensity ranges for different modalities, are outlined in Table 2. Our inference scripts will be open-sourced upon acceptance.

Table 2: List of foundational 3D medical segmentation models, along with their respective input preprocessing. We focus on domain-specific trained FMs, visual and text promptable FMs and investigate their domain generalization feasibility.

<table><tr><td>Model</td><td>Training domain</td><td>#classes</td><td>Resampling</td><td>Intensity clipping ranges</td></tr><tr><td>FSEFT [39]</td><td>CT</td><td>29</td><td>${1.5}{mm}^{3}$</td><td>CT: $\left\lbrack  {-{175},{250}}\right\rbrack  \mathrm{{HU}}$ ; MR: ${\left\lbrack  1,{99}\right\rbrack  }^{th}$ %ile</td></tr><tr><td>VISTA3D [16]</td><td>CT</td><td>124</td><td>${1.5}{mm}^{3}$</td><td>CT: $\left\lbrack  {-{1000},{1000}}\right\rbrack$ HU; MR: ${\left\lbrack  1,{99}\right\rbrack  }^{th}$ %ile</td></tr><tr><td>MRSegmentator [15]</td><td>CT, MR</td><td>40</td><td>${1.5} \times  {1.5} \times  {3.0}\mathrm{\;m}{\mathrm{\;m}}^{3}$</td><td>CT: ${\left\lbrack  {0.5},{99.5}\right\rbrack  }^{th}\%$ ile; MR: Z-score norm.</td></tr><tr><td>SAM-Med3D [42]</td><td>CT, MR</td><td>-</td><td>${1.5}{mm}^{3}$</td><td>CT & MR: Z-score norm.</td></tr><tr><td>SegVol [13]</td><td>CT</td><td>-</td><td>-</td><td>CT: ${\left\lbrack  {0.5},{99.5}\right\rbrack  }^{th}$ %ile; MR: ${\left\lbrack  1,{99}\right\rbrack  }^{th}$ %ile</td></tr><tr><td>SAT [46]</td><td>CT, MR, PET</td><td>-</td><td>${1.0} \times  {1.0} \times  {3.0}{\mathrm{\;{mm}}}^{3}$</td><td>CT: $\left\lbrack  {-{500},{1000}}\right\rbrack  \mathrm{{HU}}$ ; MR: ${\left\lbrack  {0.5},{99.5}\right\rbrack  }^{th}$ %ile</td></tr></table>

Evaluation metric: We used the Dice Similarity Coefficient (DSC) [11] to report all experimental results, considering it to be the de facto standard metric for evaluating segmentation models [7,20].

In-domain specialist model: We chose nnUNet [19] as the specialist "oracle" model defining the empirical upper bound performance in-domain, subsequently quantifying the domain gap with respect to the FMs. Choosing nnUNet is supported by a recent study [20] that concluded it to be the SoTA segmentation model. Specifically, we report results from SAT [46], which extensively trained dataset-specific nnUNets and provided full training details for reproducibility.

### 4.1 Zero-shot transfer of domain-specific FMs

Our analysis starts with probing the domain transferability of large-scale modality-specific trained FMs: FSEFT [39], VISTA3D [16] and MRSegmentator [15]. In Table 3, we report average Dice scores across all organs for each dataset.

Table 3: Performance of domain-specific FMs across different datasets. Datasets marked as (-) were used for training the respective model and are hence excluded for domain generalization experiments. Cardiac and Prostate datasets are excluded since those anatomies were not present during training of the comparative models.

<table><tr><td rowspan="2">Domain-specific FMs</td><td colspan="4">$\mathbf{{CT}}$</td><td colspan="2">$\mathbf{{MR}}$</td></tr><tr><td>BTCV</td><td>AMOS‘22</td><td>FLARE‘22</td><td>MSD-Spleen</td><td>CHAOS</td><td>AMOS‘22</td></tr><tr><td>FSEFT [39]</td><td>-</td><td>-</td><td>75.06</td><td>-</td><td>23.76</td><td>38.72</td></tr><tr><td>VISTA3D [16]</td><td>82.52</td><td>-</td><td>87.29</td><td>-</td><td>24.10</td><td>42.28</td></tr><tr><td>MRSegmentator [15]</td><td>84.42</td><td>84.35</td><td>88.85</td><td>95.68</td><td>89.83</td><td>74.86</td></tr><tr><td>nnUNet (specialist) [19]</td><td>88.89</td><td>89.77</td><td>93.36</td><td>96.70</td><td>88.89</td><td>86.43</td></tr></table>

Analysis. Notably, we observe significant domain gaps for all these models compared to the in-domain specialists [19], for both modality transfer $\left( {\mathrm{{CT}} \rightarrow  \mathrm{{MR}}}\right)$ as well as distribution shifts within the same modality. Expectedly, the CT-trained FSEFT and VISTA3D models greatly struggle to generalize to MR datasets having on same target anatomies they were trained on, and yield low segmentation scores on CHAOS-MR ( $\approx  {65}\%$ lower Dice) and AMOS-MR ( $\approx  {46}\%$ lower Dice) compared to the in-domain nnUNet. Furthermore, FSEFT also fails to generalize within CT, performing $\approx  {18}\%$ lower on FLARE’22 than nnUNet, while VISTA3D performs better but still lags by $\approx  6\%$ behind on BTCV and FLARE'22. MRSegmentator shows superior generalization, significantly reducing the performance gap with in-domain specialists. However, since it was trained on both CT and MR [15], this improvement is expected. The key takeaway is that while FSEFT and VISTA3D struggle for both within-modality and unseen-modality distribution shifts, MRSegmentator improves domain generalization with stronger performance on within-modality distribution drifts. Nevertheless, for most datasets, even MRSegmentator shows a considerable segmentation performance gap compared to the dataset-specific nnUNets.

### 4.2 Visual promptable FMs

With domain-specific FMs having limited target organs, we next shift focus to what has been the recent paradigm of segmentation FMs - prompting with spatial region of interest inputs $\left\lbrack  {{25},{42},{13}}\right\rbrack$ . Our candidate models are SAM-Med3D [42] and SegVol [13], with 3D points and bounding boxes as prompts. Table 4 shows the average Dice scores for each testing dataset.

Table 4: Performance of visually promptable foundational models. 'P' denotes the number of points provided as prompts. Values are Dice %.

<table><tr><td rowspan="2">Visual Prompted FMs</td><td colspan="4">SAM-Med3D [42]</td><td colspan="2">SegVol [13]</td><td rowspan="2">nnUNet [19] (specialist)</td></tr><tr><td>P=1</td><td>P=3</td><td>P=5</td><td>P=10</td><td>P=5</td><td>Bbox</td></tr><tr><td colspan="8">Abdominal CT</td></tr><tr><td>BTCV</td><td>78.99</td><td>80.99</td><td>81.49</td><td>81.86</td><td>67.04</td><td>80.15</td><td>88.89</td></tr><tr><td>AMOS‘22</td><td>79.06</td><td>81.74</td><td>82.31</td><td>83.18</td><td>65.46</td><td>79.82</td><td>89.77</td></tr><tr><td>FLARE‘22</td><td>84.41</td><td>86.63</td><td>86.91</td><td>87.28</td><td>68.25</td><td>76.93</td><td>93.36</td></tr><tr><td>MSD-Spleen</td><td>94.00</td><td>94.43</td><td>94.51</td><td>94.62</td><td>91.72</td><td>94.21</td><td>96.70</td></tr><tr><td colspan="8">Abdominal MR</td></tr><tr><td>CHAOS</td><td>89.52</td><td>90.64</td><td>91.54</td><td>91.76</td><td>80.25</td><td>10.11</td><td>88.89</td></tr><tr><td>AMOS‘22</td><td>71.01</td><td>75.04</td><td>76.43</td><td>77.47</td><td>60.18</td><td>45.96</td><td>86.43</td></tr><tr><td colspan="8">Pelvic (MR)</td></tr><tr><td>MSD-Prostate (T2)</td><td>84.32</td><td>88.33</td><td>88.85</td><td>89.93</td><td>57.53</td><td>37.27</td><td>87.60</td></tr><tr><td>MSD-Prostate (ADC)</td><td>80.53</td><td>84.77</td><td>86.37</td><td>86.97</td><td>66.76</td><td>25.82</td><td>87.60</td></tr><tr><td>PROMISE12</td><td>84.41</td><td>86.86</td><td>88.02</td><td>88.98</td><td>55.27</td><td>39.42</td><td>88.86</td></tr><tr><td colspan="8">Cardiac</td></tr><tr><td>MMWHS (CT)</td><td>52.09</td><td>62.25</td><td>65.24</td><td>69.18</td><td>46.82</td><td>61.53</td><td>88.64</td></tr><tr><td>MMWHS (MR)</td><td>54.55</td><td>66.67</td><td>70.08</td><td>72.99</td><td>39.82</td><td>51.48</td><td>30.88</td></tr><tr><td>MSD-Heart (MR)</td><td>79.69</td><td>86.32</td><td>87.20</td><td>88.22</td><td>42.66</td><td>57.88</td><td>94.28</td></tr></table>

Effect of prompts. Unsurprisingly, for SAM-Med3D, segmentation performance consistently improves with an increase in point prompts. However, it is interesting to observe that the performance gain quickly saturates for even greater increase in number of points: for instance, for cardiac substructures [47,1], Table 4 shows that while increasing $P = 1 \rightarrow  3$ greatly improves segmentation performance $\left( {\Delta  \approx  {10}\% }\right)$ - the margin of improvement is lower for $P = 3 \rightarrow  5$ $\left( {\Delta  \approx  {2.6}\% }\right)$ and $P = 5 \rightarrow  {10}\left( {\Delta  \approx  {2.3}\% }\right)$ . Other datasets show lower improvement margins with an increasing number of points. For SegVol, point-prompted scores remain consistently lower than for SAM-Med3D, but bounding boxes improve segmentation on several datasets. Notably, for all CT datasets, bounding boxes outperform points, aligning with prior findings [13]. However, for unseen MR modalities, points outperform boxes (e.g., AMOS'22-MR: 60.18 vs. 45.96, PROMISE12: 55.27 vs. 39.42). We hypothesize that bounding boxes capture background regions, leading to misclassification of foreground voxels in unseen modalities, whereas points - always marking the foreground-avoid this issue.

Domain generalization analysis. SegVol is a CT-only trained model; for zero-shot transfer on MR datasets, it performs considerably worse compared to SAM-Med3D with the same number of point prompts $\left( {{\Delta }_{\mathrm{P} = 5}\left( \mathrm{{CHAOS}}\right)  \approx  }\right.$ ${11}\% ,{\Delta }_{\mathrm{P} = 5}\left( \mathrm{{AMOS}}\right)  \approx  {16}\% )$ . On the brighter side, SegVol achieves higher Dice scores than its domain-specific counterparts (FSEFT [39] and VISTA3D [16], from Table 3). SAM-Med3D was trained with both CT and MR data and shows stronger generalizability, even outperforming the specialist nnUNet on CHAOS (91.76 vs. 88.89) and MSD-Prostate T2 (89.93 vs. 87.60). Yet, it exhibits a significant domain gap against the in-domain specialist nnUNet on the abdominal $\left( {{\Delta }_{\mathrm{{BTCV}}} \approx  7\% ,{\Delta }_{\mathrm{{AMOS}} - \mathrm{{MR}}} \approx  9\% }\right)$ and cardiac $\left( {{\Delta }_{\mathrm{{MMWHS}} - \mathrm{{CT}}} \approx  }\right.$ ${20}\% ,{\Delta }_{\text{MSD-Heart }} \approx  6\%$ ) datasets. Nevertheless, visual prompted FMs dominate domain-specific FMs in terms of applicability towards a broader range of anatomies, paving the way to reduce the existing domain gap compared to specialist models.

Generalization to unseen anatomies via prompting. SegVol's training corpus lacked pelvic and cardiac anatomies [13], allowing us to assess its zero-shot performance. From Table 4, for MMWHS-CT (known modality), SegVol with boxes nears SAM-Med3D's performance with 3-point prompts (61.53 vs. 62.25), but SAM-Med3D surpasses it beyond this. For prostate and cardiac MR, scores fall well below in-domain specialist nnUNets [19]. These results indicate that current 3D promptable FMs still struggle with unseen anatomies, requiring further research and improvements.

### 4.3 Text promptable FMs

Going further, recent works have also enabled semantic textual prompts to denote target structures for segmentation, typically processed via a pre-trained text encoder $\left\lbrack  {{36},{10},{22}}\right\rbrack$ . We have two candidate models - SegVol with text prompts [13] and SAT [46]. Table 5 shows the corresponding Dice scores obtained.

Table 5: Performance of text promptable FMs. SAT-Nano and SAT-Pro denote smaller (110M) and larger capacity (447M) model variants respectively, while SAT-Ft is a fine-tuned version (not zero-shot) of SAT-Pro on the respective datasets.

<table><tr><td rowspan="2">Text Prompted FMs</td><td colspan="3">SegVol [13]</td><td colspan="3">SAT [46]</td><td rowspan="2">nnUNet [19] (specialist)</td></tr><tr><td>text</td><td>text+bbox</td><td>text+points</td><td>Nano</td><td>Pro</td><td>Ft</td></tr><tr><td colspan="8">Abdominal CT</td></tr><tr><td>BTCV</td><td>80.68</td><td>81.87</td><td>71.70</td><td>79.60</td><td>80.71</td><td>81.60</td><td>88.89</td></tr><tr><td>AMOS‘22</td><td>75.30</td><td>81.12</td><td>69.09</td><td>84.93</td><td>86.37</td><td>88.75</td><td>89.77</td></tr><tr><td>FLARE‘22</td><td>77.32</td><td>78.73</td><td>72.79</td><td>88.79</td><td>91.12</td><td>91.78</td><td>93.36</td></tr><tr><td>MSD-Spleen</td><td>95.75</td><td>95.79</td><td>95.76</td><td>93.50</td><td>94.12</td><td>94.97</td><td>96.70</td></tr><tr><td colspan="8">Abdominal MR</td></tr><tr><td>CHAOS</td><td>73.23</td><td>21.32</td><td>81.06</td><td>82.07</td><td>87.28</td><td>87.99</td><td>88.89</td></tr><tr><td>AMOS‘22</td><td>62.73</td><td>47.29</td><td>61.59</td><td>78.76</td><td>78.90</td><td>84.82</td><td>86.43</td></tr><tr><td colspan="8">Pelvic (MR)</td></tr><tr><td>MSD-Prostate (T2)</td><td>0.01</td><td>20.53</td><td>26.65</td><td>73.38</td><td>78.33</td><td>77.98</td><td>87.60</td></tr><tr><td>MSD-Prostate (ADC)</td><td>0.05</td><td>35.21</td><td>65.71</td><td>73.38</td><td>78.33</td><td>77.98</td><td>87.60</td></tr><tr><td>PROMISE12</td><td>0.20</td><td>24.68</td><td>30.50</td><td>84.55</td><td>86.51</td><td>87.28</td><td>88.86</td></tr><tr><td colspan="8">Cardiac</td></tr><tr><td>MMWHS (CT)</td><td>0.03</td><td>35.54</td><td>13.01</td><td>88.23</td><td>89.97</td><td>91.14</td><td>88.64</td></tr><tr><td>MMWHS (MR)</td><td>0.07</td><td>29.24</td><td>13.78</td><td>84.37</td><td>86.70</td><td>87.73</td><td>30.88</td></tr><tr><td>MSD-Heart (MR)</td><td>0.02</td><td>54.45</td><td>37.16</td><td>90.28</td><td>92.61</td><td>93.38</td><td>94.28</td></tr></table>

Text inputs boost spatial prompts. We investigate the effect of semantic prompts as an additional guidance alongside spatial prompts for SegVol [13], denoted by "text+bbox" and "text+points" in Table 5. Comparing them with corresponding vanilla spatial prompts in Table 4, we notice that for known anatomies (abdominal CT and MR), the addition of text consistently improves segmentations from raw spatial prompts (BTCV: ${80.15}\mathrm{w}/$ bbox, ${81.87}\mathrm{w}/$ text+bbox; CHAOS: ${80.25}\mathrm{\;w}/$ points, ${81.06}\mathrm{\;w}/$ text+points). We show example segmentation results in Figure 1. For unseen anatomies, text prompts completely fail, since the model has no knowledge to spatially ground such concepts.

Semantic prompts show better domain generalization. As can be seen from Table 5 (as well as Table 4), for known anatomies, text-prompted segmentation shows better generalizability across modalities, surpassing visual prompts. In particular, SAT shows strong segmentation performance across all datasets, reducing the empirical domain gap with in-domain specialists in several cases. SAT also outperforms SegVol in the text-prompted configuration on most datasets. However, we point out that SAT and SegVol are not directly comparable: the training corpus of SAT is significantly larger than for SegVol [46], and while SegVol uses a CLIP [36] encoder for text, while SAT leverages a BERT [10] model pre-trained on medical documents, enhancing anatomical knowledge during prompting. Although there still remains a considerable empirical gap of SAT with in-domain nnUNets, it has been able to reduce it further as compared to previous FMs $\left\lbrack  {{39},{16},{42}}\right\rbrack$ with greater applicability across different anatomies and

![bo_d1c3stf7aajc7389qf5g_8_397_339_1015_282_0.jpg](images/bo_d1c3stf7aajc7389qf5g_8_397_339_1015_282_0.jpg)

Fig. 1: Qualitative results showing segmentation improvement in SegVol with text - bbox prompts for seen (CT; MSD-Spleen) and unseen (MR; CHAOS) modalities.

modalities, which makes us optimistic that text-promptable segmentation [46,30] possibly combined with visual prompts for further refinement will eventually become the universal segmentation paradigm.

## 5 Conclusion

In this study, we explored the DG feasibility of FMs for 3D medical image segmentation, encompassing a variety of domain shift cases across anatomies and modalities, and different categories of FMs for a holistic analysis. The take-home message from our empirical findings is - while domain-specific FMs fail to generalize across domain shifts, promptable FMs show potential to bridge the domain gap, but require smart prompting techniques that can effectively convey the region-of-interest pointer to the model, possibly achievable by text prompts with spatial inputs for refinement. Future works should build upon these findings to develop a truly universal, domain-generalized segmentation framework.

## 6 Acknowledgements

This research was, in part, funded by the National Institutes of Health (NIH) under other transactions 1OT2OD038045-01 and NIAMS 1R01AR082684. The views and conclusions contained in this document are those of the authors and should not be interpreted as representing official policies, either expressed or implied, of the NIH.

## References

1. Antonelli, M., Reinke, A., Bakas, S., Farahani, K., et al.: The medical segmentation decathlon. Nature communications (2022)

2. Awais, M., Naseer, M., Khan, S., Anwer, R.M., Cholakkal, H., Shah, M., Yang, M.H., Khan, F.S.: Foundation models defining a new era in vision: a survey and outlook. IEEE TPAMI (2025)

3. Bilic, P., Christ, P., Li, H.B., Vorontsov, E., Ben-Cohen, A., Kaissis, G., Szeskin, A., Jacobs, C., Mamani, G.E.H., Chartrand, G., et al.: The liver tumor segmentation benchmark (lits). Medical image analysis 84, 102680 (2023)

4. Bommasani, R., Hudson, D.A., Adeli, E., Altman, R., et al.: On the opportunities and risks of foundation models. arXiv preprint arXiv:2108.07258 (2021)

5. Brown, T., Mann, B., Ryder, N., Subbiah, M., et al.: Language models are few-shot learners. In: NeurIPS (2020)

6. Cardoso, M.J., Li, W., Brown, R., Ma, N., et al.: Monai: An open-source framework for deep learning in healthcare. arXiv preprint arXiv:2211.02701 (2022)

7. Cekmeceli, K., Himmetoglu, M., Tombak, G.I., Susmelj, A., et al.: Do vision foundation models enhance domain generalization in medical image segmentation? arXiv preprint arXiv:2409.07960 (2024)

8. Cheng, J., Ye, J., Deng, Z., Chen, J., et al.: Sam-med2d. arXiv preprint arXiv:2308.16184 (2023)

9. Demir, B., Tian, L., Greer, H., Kwitt, R., et al.: MultiGradICON: A foundation model for multimodal medical image registration. In: MICCAI WBIR (2024)

10. Devlin, J., Chang, M.W., Lee, K., Toutanova, K.: Bert: Pre-training of deep bidirectional transformers for language understanding. In: NACCL (2019)

11. Dice, L.R.: Measures of the amount of ecologic association between species. Ecology (1945)

12. Dou, Q., Coelho de Castro, D., Kamnitsas, K., Glocker, B.: Domain generalization via model-agnostic learning of semantic features. In: NeurIPS (2019)

13. Du, Y., Bai, F., Huang, T., Zhao, B.: Segvol: Universal and interactive volumetric medical image segmentation. In: NeurIPS (2024)

14. Fu, Y., Chen, Z., Ye, Y., Lei, X., Wang, Z., Xia, Y.: Cosam: Self-correcting sam for domain generalization in 2d medical image segmentation. arXiv preprint arXiv:2411.10136 (2024)

15. Häntze, H., Xu, L., Mertens, C.J., et al.: Mrsegmentator: Multi-modality segmentation of 40 classes in mri and ct. arXiv preprint arXiv:2405.06463 (2024)

16. He, Y., Guo, P., Tang, Y., Myronenko, A., et al.: Vista3d: Versatile imaging segmentation and annotation model for $3\mathrm{\;d}$ computed tomography. arXiv preprint arXiv:2406.05285 (2024)

17. Heller, N., Isensee, F., Maier-Hein, K.H., Hou, X., Xie, C., Li, F., Nan, Y., Mu, G., Lin, Z., Han, M., et al.: The state of the art in kidney and kidney tumor segmentation in contrast-enhanced ct imaging: Results of the kits19 challenge. Medical image analysis $\mathbf{{67}},{101821}\left( {2021}\right)$

18. Heller, N., Isensee, F., Trofimova, D., Tejpaul, R., Zhao, Z., Chen, H., Wang, L., Golts, A., Khapun, D., Shats, D., et al.: The kits21 challenge: Automatic segmentation of kidneys, renal tumors, and renal cysts in corticomedullary-phase ct. arXiv preprint arXiv:2307.01984 (2023)

19. Isensee, F., Jaeger, P.F., Kohl, S.A., Petersen, J., Maier-Hein, K.H.: nnu-net: a self-configuring method for deep learning-based biomedical image segmentation. Nature Methods (2021)

20. Isensee, F., Wald, T., Ulrich, C., Baumgartner, M., Roy, S., Maier-Hein, K., Jaeger, P.F.: nnu-net revisited: A call for rigorous validation in 3d medical image segmentation. In: MICCAI (2024)

21. Ji, Y., Bai, H., Ge, C., Yang, J., et al.: Amos: A large-scale abdominal multi-organ benchmark for versatile medical image segmentation. In: NeurIPS (2022)

22. Jin, Q., Kim, W., Chen, Q., Comeau, D.C., Yeganova, L., Wilbur, W.J., Lu, Z.: Medcpt: Contrastive pre-trained transformers with large-scale pubmed search logs for zero-shot biomedical information retrieval. Bioinformatics (2023)

23. Karani, N., Erdil, E., Chaitanya, K., Konukoglu, E.: Test-time adaptable neural networks for robust medical image segmentation. MedIA (2021)

24. Kavur, A.E., Gezer, N.S., Bariş, M., Aslan, S., et al.: Chaos challenge-combined (ct-mr) healthy abdominal organ segmentation. MedIA (2021)

25. Kirillov, A., Mintun, E., Ravi, N., et al.: Segment anything. In: ICCV (2023)

26. Kondrateva, E., Pominova, M., Popova, E., Sharaev, M., Bernstein, A., Burnaev, E.: Domain shift in computer vision models for mri data analysis: an overview. In: SPIE ICMV (2021)

27. Landman, B., Xu, Z., Igelsias, J., Styner, M., Langerak, T., Klein, A.: Miccai multi-atlas labeling beyond the cranial vault-workshop and challenge. In: MICCAI multi-atlas labeling beyond cranial vault-workshop challenge (2015)

28. Li, Y., Wang, N., Shi, J., Hou, X., Liu, J.: Adaptive batch normalization for practical domain adaptation. Pattern Recognition (2018)

29. Litjens, G., Toth, R., Van De Ven, W., Hoeks, C., et al.: Evaluation of prostate segmentation algorithms for MRI: the PROMISE12 challenge. MedIA (2014)

30. Liu, J., Zhang, Y., Chen, J.N., Xiao, J., Lu, Y., A Landman, B., Yuan, Y., Yuille, A., Tang, Y., Zhou, Z.: CLIP-driven universal model for organ segmentation and tumor detection. In: ICCV (2023)

31. Liu, Q., Chen, C., Qin, J., Dou, Q., Heng, P.A.: Feddg: Federated domain generalization on medical image segmentation via episodic learning in continuous frequency space. In: CVPR (2021)

32. Ma, J., He, Y., Li, F., Han, L., You, C., Wang, B.: Segment anything in medical images. Nature Communications (2024)

33. Ma, J., Zhang, Y., Gu, S., Ge, C., et al.: Unleashing the strengths of unlabeled data in pan-cancer abdominal organ quantification: the flare22 challenge. arXiv preprint arXiv:2308.05862 (2023)

34. Nguyen, A.T., Torr, P., Lim, S.N.: Fedsr: A simple and effective domain generalization method for federated learning. In: NeurIPS (2022)

35. Paszke, A., Gross, S., Massa, F., Lerer, A., et al.: Pytorch: An imperative style, high-performance deep learning library. In: NeurIPS (2019)

36. Radford, A., Kim, J.W., Hallacy, C., Ramesh, A., et al.: Learning transferable visual models from natural language supervision. In: ICML (2021)

37. Radford, A., Narasimhan, K., Salimans, T., Sutskever, I.: Improving language understanding by generative pre-training. OpenAI (2018)

38. Ramesh, A., Pavlov, M., Goh, G., Gray, S., Voss, C., Radford, A., Chen, M., Sutskever, I.: Zero-shot text-to-image generation. In: ICML (2021)

39. Silva-Rodriguez, J., Dolz, J., Ayed, I.B.: Towards foundation models and few-shot parameter-efficient fine-tuning for volumetric organ segmentation. In: MICCAI Workshops (2023)

40. Tian, L., Greer, H., Kwitt, R., Vialard, F.X., et al.: unigradicon: A foundation model for medical image registration. In: MICCAI (2024)

41. Valanarasu, J.M.J., Guo, P., Vibashan, V., Patel, V.M.: On-the-fly test-time adaptation for medical image segmentation. In: MIDL (2024)

42. Wang, H., Guo, S., Ye, J., Deng, Z., et al.: Sam-med3d: towards general-purpose segmentation models for volumetric medical images. In: ECCV BIC (2024)

43. Yoon, J.S., Oh, K., Shin, Y., Mazurowski, M.A., Suk, H.I.: Domain generalization for media: A survey. arXiv preprint arXiv:2310.08598 (2023)

44. Zhang, C., Liu, L., Cui, Y., Huang, G., Lin, W., Yang, Y., Hu, Y.: A comprehensive survey on segment anything model for vision and beyond. arXiv preprint arXiv:2305.08196 (2023)

45. Zhang, Z., Yang, L., Zheng, Y.: Translating and segmenting multimodal medical volumes with cycle-and shape-consistency generative adversarial network. In: CVPR (2018)

46. Zhao, Z., Zhang, Y., Wu, C., Zhang, X., et al.: One model to rule them all: Towards universal segmentation for medical images with text prompts. arXiv preprint arXiv:2312.17183 (2023)

47. Zhuang, X., Li, L., Payer, C., Stern, D., et al.: Evaluation of algorithms for multimodality whole heart segmentation: an open-access grand challenge. MedIA (2019)

## A Organ-wise segmentation results

For additional analysis, we also provide organ-wise segmentation results of the comparative models across the multi-class datasets used in this study. We show these results using box plots in Figure 2 for abdominal CT, Figure 3 for abdominal MR, and Figure 4 for the cardiac datasets.

From the figures, we observe that for certain organs like liver, kidneys and spleen, the segmentation performance across foundational models is more reliable (both in-domain and out-of-domain) compared to other structures (duodenum or adrenal glands). Notably, the training set of models like FSEFT [39] or SegVol [13] also comprised several organ-specific datasets, such as the Medical Segmentation Decathlon datasets with liver, pancreas and spleen segmentation tasks [1], Liver Tumor Segmentation (LiTS'17) [3], Kidney Tumor Segmentation (KiTS'19, KiTS'23) [17,18], among others. We hypothesize that the superior performance of models on these anatomical structures is due to their higher frequency of occurrence in their respective training corpora.

![bo_d1c3stf7aajc7389qf5g_12_274_320_1247_1733_0.jpg](images/bo_d1c3stf7aajc7389qf5g_12_274_320_1247_1733_0.jpg)

Fig. 2: Box plots for organ-wise dice scores for all comparative models on the abdominal CT datasets used in this study.

![bo_d1c3stf7aajc7389qf5g_13_271_525_1252_1144_0.jpg](images/bo_d1c3stf7aajc7389qf5g_13_271_525_1252_1144_0.jpg)

Fig. 3: Box plots for organ-wise dice scores for all comparative models on the abdominal MR datasets used in this study.

![bo_d1c3stf7aajc7389qf5g_14_273_518_1248_1149_0.jpg](images/bo_d1c3stf7aajc7389qf5g_14_273_518_1248_1149_0.jpg)

Fig. 4: Box plots for organ-wise dice scores for all comparative models on the cardiac datasets used in this study.

