# Deep Learning for Traffic Scene Understanding: A Review

PARYA DOLATYABI ${}^{1}$ , (Graduate Student Member, IEEE), JACOB REGAN ${}^{1}$ , (Graduate Student Member, IEEE), AND MAHDI KHODAYAR ${}^{\square }$ , (Member, IEEE)

Department of Computer Science, University of Tulsa, Tulsa, OK 74104, USA

Corresponding author: Parya Dolatyabi (pad7492@utulsa.edu)

This work was supported in part by U.S. Department of Transportation (USDOT) under Grant 693JJ32350030.

* ABSTRACT This review paper presents an in-depth analysis of deep learning (DL) models applied to traffic scene understanding, a key aspect of modern intelligent transportation systems. It examines fundamental techniques such as classification, object detection, and segmentation, and extends to more advanced applications like action recognition, object tracking, path prediction, scene generation and retrieval, anomaly detection, Image-to-Image Translation (I2IT), and person re-identification (Person Re-ID). The paper synthesizes insights from a broad range of studies, tracing the evolution from traditional image processing methods to sophisticated DL techniques, such as Convolutional Neural Networks (CNNs) and Generative Adversarial Networks (GANs). The review also explores three primary categories of domain adaptation (DA) methods: clustering-based, discrepancy-based, and adversarial-based, highlighting their significance in traffic scene understanding. The significance of Hyperparameter Optimization (HPO) is also discussed, emphasizing its critical role in enhancing model performance and efficiency, particularly in adapting DL models for practical, real-world use. Special focus is given to the integration of these models in real-world applications, including autonomous driving, traffic management, and pedestrian safety. The review also addresses key challenges in traffic scene understanding, such as occlusions, the dynamic nature of urban traffic, and environmental complexities like varying weather and lighting conditions. By critically analyzing current technologies, the paper identifies limitations in existing research and proposes areas for future exploration. It underscores the need for improved interpretability, real-time processing, and the integration of multi-modal data. This review serves as a valuable resource for researchers and practitioners aiming to apply or advance DL techniques in traffic scene understanding.

INDEX TERMS Deep learning, traffic scene understanding, discriminative models, generative models, domain adaptation, classification, object detection, segmentation.

## I. INTRODUCTION

The rapid evolution of deep learning (DL), particularly in computer vision, has initiated a new era of intelligent transportation systems. Researchers have made significant strides in advancing autonomous vehicles, traffic management, and pedestrian safety by fusing deep neural architectures with the complexities of traffic scenes. However, despite these advancements, critical challenges persist in effectively translating theoretical breakthroughs into robust, real-world applications, such as handling the variability of traffic environments, ensuring real-time processing, and achieving high accuracy under diverse conditions. This review aims to thoroughly explore these challenges by offering an in-depth analysis of the complex interactions between deep neural networks (DNNs), computer vision, and traffic scene understanding.

Previous studies have made substantial contributions to this field. However, they also exhibit certain limitations. For example, [1] provided an extensive survey on deep learning-based object detection in traffic scenarios, covering over 100 papers and highlighting challenges such as real-time performance, image quality degradation, and object occlusion. Autonomous driving technologies were investigated in [2], with a focus on DL methods for perception, mapping, and sensor fusion. They also pointed out limitations in multi-sensor integration and prediction accuracy. The authors of [3] covered deep learning techniques for object detection, semantic segmentation, instance segmentation, and lane line segmentation in autonomous driving. They highlighted key challenges such as high computational cost, real-time performance limitations, and occlusion issues-particularly in instance segmentation, where region proposal-based methods often struggle with small or occluded objects. Advanced methods, such as Adaptive Feature (AF) pooling, were suggested to improve efficiency in these scenarios. The study in [4] reviews methods based on artificial intelligence (AI), including convolutional neural networks (CNNs) and reinforcement learning, for tasks such as driving scene perception, path planning, and motion control. It discusses challenges including handling occlusion, particularly during scene perception, where occluded objects often hinder accurate detection and recognition. Despite their valuable insights, these studies face several critical shortcomings:

---

The associate editor coordinating the review of this manuscript and approving it for publication was Turgay Celik ${}^{1}$ .

---

1) Current review papers largely focus on discriminative models, with limited coverage of generative models crucial for synthetic data generation in traffic scenarios. Additionally, they offer limited discussion on domain adaptation (DA) techniques, which are essential for transferring models across different environmental conditions to enhance robustness in traffic scene analysis [1], [2], [3].

2) Current surveys often lack a detailed discussion on hyperparameter optimization (HPO) [1], [2], [3], [4], which is crucial for fine-tuning DL models in complex traffic scenarios. This omission is significant, as HPO enhances model efficiency, reduces training time, and improves real-time deployment feasibility.

3) Many existing survey papers fail to provide a thorough comparison of different deep learning architectures, especially among discriminative, generative, and domain adaptation categories [1], [4]. This omission is important, as such comparisons are essential for understanding the unique strengths and weaknesses of each approach, which plays a key role in making informed decisions about model selection and application.

4) Existing literature lacks a comprehensive comparative discussion of various models, including their advantages, disadvantages, and potential areas for future research [1], [2], [3], [4]. Such an analysis is essential for understanding the trade-offs between different models and identifying opportunities for advancing state-of-the-art solutions in complex traffic environments.

5) Current reviews often cover challenges like safety and hardware but neglect emerging areas such as Explainable AI (XAI) and real-time processing [2], [3]. These areas are essential for advancing traffic scene understanding and ensuring AI systems are transparent and effective in dynamic environments.

6) Current studies are outdated, as they do not include a review of the most recent developments in the field, thereby missing the latest advancements shaping DL applications in traffic scene understanding [1], [2], [3], [4]. This is a significant limitation, as staying updated with the latest research is crucial for providing a comprehensive and forward-looking resource.

To address these gaps, our paper studies the core computer vision techniques of classification, object detection, and segmentation, while also extending its analysis to cover advanced topics including action recognition, object tracking, path prediction, anomaly detection, scene generation, and image enhancement. By synthesizing findings from a broad spectrum of studies, our paper provides a holistic overview of the evolution from traditional image processing methods to advanced DL models, including Convolutional Neural Networks (CNNs), Generative Adversarial Networks (GANs), and Domain Adaptation models. It emphasizes the integration of these models into real-world applications such as autonomous driving, traffic management, and pedestrian safety, while also addressing challenges including occlusions, dynamic urban traffic environments, and varying weather and lighting conditions. The contributions of our paper are:

1) We present a categorized exploration of discriminative, generative, and DA models, including detailed analyses of YOLO (You Only Look Once) variants, Vision Transformers (ViTs), graph-based models, and various DA techniques. Our approach not only covers these models comprehensively but also emphasizes their advantages, such as improved accuracy in traffic scenarios with discriminative models, enhanced training through generative models for synthetic data creation, and increased robustness in real-world conditions with DA techniques.

2) HPO strategies are discussed in our work, with specific sections dedicated to each category of DL architectures-discriminative, generative, and DA. This provides insights into optimizing these models for better performance, ensuring they are fine-tuned for optimal results in traffic scene understanding.

3) Our review provides comparisons of different DL architectures across discriminative, generative, and DA categories, focusing on application frameworks, variance in datasets, performance metrics, and overall results, providing clear guidance on selecting the most effective models for traffic scene understanding.

4) A comparative discussion of discriminative, generative, and DA models is provided in our work, highlighting their advantages, disadvantages, and potential directions for future research. This detailed analysis helps to clarify the strengths and limitations of each model, guiding future development and innovation in complex traffic scenarios.

5) We highlight emerging research trends such as XAI, augmenting vision backbones with ViT and GNN, real-time traffic scene processing, overcoming data limitations using synthetic data, and enhancing perception via multi-modality and data fusion. This structured perspective is crucial for advancing traffic scene understanding and providing a thorough, future-focused review.

6) We provide an up-to-date review of the latest papers and advancements, incorporating the most recent research insights. Keeping current with these developments is crucial for delivering a thorough and future-oriented resource.

These contributions make our paper a more thorough and forward-thinking resource, offering a critical assessment of current research, highlighting limitations, and presenting new perspectives on traffic scene understanding. By addressing the shortcomings of previous studies and offering a clear articulation of current challenges faced, this review aims to inspire future research and development efforts that drive innovation in deep learning for traffic scene understanding.

The rest of this paper is organized as follows. In Section II, we introduce the discriminative DL models, including CNNs, region-based CNN (R-CNN) variants, YOLO, ViT, DETR (Detection Transformer), graph-based models, and capsule networks (CapsNets). Section III focuses on generative machine learning (ML) models, encompassing GANs, conditional GANs (cGANs), and variational autoencoders (VAEs). In Section IV, we explore DA models within the categories of clustering-based, discrepancy-based, and adversarial-based approaches. A comparative discussion of these models is provided in Section V. HPO techniques are detailed within each category. Finally, future research areas and concluding remarks are presented in Sections VI and VII, respectively.

## II. DATASETS

In this section, we focus on the most popular datasets identified in the papers reviewed in our study. These datasets are widely used across various tasks in traffic scene understanding, including object detection, segmentation, 3D tracking, classification, and domain adaptation. They have been selected based on their frequency of citation, versatility, and relevance to core applications. For less popular, niche, or highly customized datasets, readers are referred to the corresponding references cited in the respective works.

Table 1 summarizes 11 widely used datasets in traffic scene understanding, categorized based on their applications and characteristics. COCO 2017, VOC2007, and Cityscapes are benchmarks for object detection and segmentation, offering extensive annotations for diverse object categories and urban scenes. KITTI and nuScenes focus on 3D object detection and multi-object tracking, with KITTI emphasizing structured environments and nuScenes extending to radar data and more dynamic scenarios. GTSRB specializes in traffic sign recognition, providing a targeted dataset for autonomous driving systems. 1043-syn is a synthetic dataset optimized for traffic scene classification, particularly under controlled lighting and object variation scenarios. For person re-identification, DukeMTMC-ReID is a key benchmark, supporting identity matching tasks across multi-camera setups.

These datasets vary in scale and context, with real-world datasets like BDD, Mapillary, and Cityscapes capturing diverse weather and geographic conditions, while synthetic datasets like SYNTHIA and 1043-syn simulate controlled scenarios for domain adaptation and classification. Large-scale datasets such as COCO 2017 and BDD provide extensive data for deep learning, whereas smaller datasets like VOC2007 and KITTI offer high-quality annotations for specific tasks. This combination of real-world variability, geographic diversity, and synthetic precision allows researchers to address multifaceted challenges in traffic scene understanding, leveraging the strengths of each dataset for robust model development.

## III. DISCRIMINATIVE DL MODELS

Discriminative DL models, often based on CNNs, are crucial for understanding complex traffic scenes. They excel at distinguishing objects and patterns, enabling tasks like object detection, classification, and segmentation. In traffic contexts, these models accurately identify vehicles, pedestrians, and road signs, enhancing real-time analysis in video feeds. By leveraging discriminative DL, systems improve road safety and efficiency, assisting autonomous navigation, traffic flow analysis, and pedestrian behavior prediction. This advancement supports intelligent transportation systems and enhances overall road safety.

In the following sections, we examine various discriminative DL models-R-CNNs, YOLO variants, and attention mechanisms-tailored for traffic scene understanding. These models address tasks like object detection, semantic segmentation, and action recognition, influencing intelligent transportation systems. We also discuss HPO for these architectures and compare performance metrics, providing a comprehensive overview.

## A. CNN

A CNN [5] is a DL model designed for grid-like data (e.g., images), commonly used in traffic scene understanding to analyze camera images. CNNs automatically extract features like objects, signs, and road markings, supporting real-time processing and enhancing road safety for autonomous vehicles.

A basic CNN for image classification follows: convolution, pooling, fully connected (FC) layers, and output. Convolution applies filters to generate feature maps, which are pooled and flattened before passing through FC layers, with a softmax layer for class probabilities.

The core CNN operation is convolution:

$$
\left( {I * K}\right) \left( {x, y}\right)  = \mathop{\sum }\limits_{{i = 0}}^{{m - 1}}\mathop{\sum }\limits_{{j = 0}}^{{n - 1}}I\left( {x + i, y + j}\right)  \cdot  K\left( {i, j}\right) , \tag{1}
$$

where $I$ is the input image, $K$ is the kernel of size $m \times  n$ , and (x, y)are output coordinates.

TABLE 1. A summary of the most popular datasets identified in the papers reviewed in our study, categorized based on their characteristics and key features. Approximate numbers are used for dataset sizes to account for variations across versions, releases, or documentation. These datasets are widely adopted for diverse tasks such as object detection, segmentation, 3D tracking, classification, and domain adaptation, with applications spanning real-world scenarios and synthetic simulations. The inclusion of train and test sizes, along with geographic or virtual origins, highlights the diversity and specificity of these datasets in advancing traffic scene understanding. The term Varies in the Image Size column indicates datasets with images of multiple resolutions. Trainva/ refers to a combined set of training and validation images. Fine and Coarse denote levels of annotation granularity, with fine being pixel-accurate and coarse being approximate or less detailed.

<table><tr><td>Dataset</td><td>Abbreviation</td><td>Application</td><td>Train Size</td><td>Test Size</td><td>Image Size (pixels)</td><td>Location</td></tr><tr><td>COCO 2017</td><td>Common Objects in Context</td><td>Object detection, segmentation, and image captioning.</td><td>118,000</td><td>41,000</td><td>Varies (e.g., 640 $\times  {480}$ to ${2048} \times$ 1024)</td><td>Global</td></tr><tr><td>KITTI</td><td>Karlsruhe Institute of Technology and Toyota Technological Institute</td><td>3D object detection, multi-object tracking.</td><td>7,481</td><td>7,518</td><td>${1242} \times  {375}$</td><td>Karlsruhe, Germany</td></tr><tr><td>GTSRB</td><td>German Traffic Sign Recognition Benchmark</td><td>Traffic sign classification and recognition.</td><td>39,209</td><td>12,630</td><td>Varies ( ${15} \times  {15}$ to ${250} \times  {250})$</td><td>Germany</td></tr><tr><td>VOC2007</td><td>PASCAL Visual Object Classes 2007</td><td>Object detection and classification.</td><td>5,011 (trainval)</td><td>4,952</td><td>Varies $\left( {{500} \times  {375}}\right)$</td><td>Europe</td></tr><tr><td>Cityscapes</td><td>Cityscapes</td><td>Semantic segmentation of urban scenes.</td><td>3,475 (fine), 20,000 (coarse)</td><td>1,525 (fine)</td><td>${2048} \times  {1024}$</td><td>Multiple cities in Germany</td></tr><tr><td>nuScenes</td><td>nuScenes</td><td>3D object detection, multi-sensor tracking.</td><td>28,130</td><td>6,008</td><td>${1600} \times  {900}$</td><td>Boston, USA; Singapore</td></tr><tr><td>BDD</td><td>Berkeley DeepDrive Dataset</td><td>Object detection, segmentation, classifica- tion.</td><td>70,000</td><td>20,000</td><td>${1280} \times  {720}$</td><td>USA</td></tr><tr><td>Mapillary</td><td>Mapillary Dataset</td><td>Street-level semantic segmentation.</td><td>20,000</td><td>5,000</td><td>Varies</td><td>Global</td></tr><tr><td>SYNTHIA</td><td>Synthetic Images for Training</td><td>Synthetic data for segmentation, domain adaptation.</td><td>8,000</td><td>1,400</td><td>${960} \times  {720}$</td><td>Virtual (synthetic)</td></tr><tr><td>DukeMTMC- ReID</td><td>Duke Multi-Target Multi-Camera Re-ID Dataset</td><td>Person re-identification.</td><td>16,522</td><td>19,889</td><td>${128} \times  {64}$</td><td>Duke University, USA</td></tr><tr><td>1043-syn</td><td>1043 Synthetic Dataset</td><td>Synthetic dataset for classification, object recognition.</td><td>8,000</td><td>2,000</td><td>${640} \times  {480}$</td><td>Virtual (synthetic)</td></tr></table>

Next, a ReLU activation function introduces non-linearity: ${f}_{\text{ReLU }}\left( x\right)  = \max \left( {0, x}\right)$ . A pooling layer reduces spatial dimensions to decrease parameters and computation. Max pooling is defined as:

$$
P\left( {x, y}\right)  = \mathop{\max }\limits_{{0 \leq  i < p,0 \leq  j < q}}I\left( {x + i, y + j}\right) , \tag{2}
$$

where $P$ is the pooled output, and $p \times  q$ is the pooling window size.

The FC layer performs classification, with output $y = W$ . $x + b$ , where $W$ is the weight matrix, $x$ the input, and $b$ the bias. Finally, softmax converts logits to probabilities:

$$
{f}_{\text{softmax }}\left( {\zeta }_{i}\right)  = \frac{{e}^{{\zeta }_{i}}}{\mathop{\sum }\limits_{{j = 1}}^{n}{e}^{{\zeta }_{j}}}, \tag{3}
$$

where ${\zeta }_{i}$ is the $i$ -th output element, and $n$ is the number of classes.

Some applications of CNNs in traffic scene understanding include early implementations of recognizing traffic signs with 99% accuracy, though the recognition time was relatively long for real-time applications [6]. Modern adaptations have surpassed human performance in tasks like traffic sign recognition [7]. CNNs also enhance free-space detection through data fusion techniques [8] and improve recognition of traffic police gestures [9].

Shortly after the introduction of CNNs in the 1980s, [6] applied fractal texture segmentation for traffic sign detection using a receptive field neural network (NN). The network had an input layer of ${32} \times  {32}$ neurons, an output layer with ten neurons, and four hidden layers of ${16} \times  {16},8 \times  8,4 \times  4$ , and 30 neurons. It was trained to recognize 9 types of traffic signs from images at 1,2, and 3 meters, achieving 99% accuracy. However, the recognition time of 4 seconds is too long for real-time use. The "RFNN_TSR" dataset includes nine road signs for landmark recognition in outdoor settings at varying distances.

In [7], the traditional CNN architecture was modified to incorporate multi-scale features, achieving an accuracy of 99.17% on the GTSRB dataset, surpassing human performance ( ${98.81}\%$ ). Initially, using ${32} \times  {32}$ color images, the model achieved 98.97% accuracy, with even randomly generated features yielding a competitive 97.33 .

SNE-RoadSeg [8] integrates surface normal estimation (SNE) with a data-fusion CNN architecture for enhanced free-space detection, showcasing a unique dual-encoder system that merges RGB and surface normal information. This fusion, along with densely-connected skip connections in the decoder, enables precise segmentation. On the KITTI benchmark, it achieves an average precision (AP) of 94.07%.

A novel approach to traffic police gesture recognition is proposed in [9], combining a modified Convolutional Pose Machine (CPM) with a Long Short-Term Memory (LSTM) for temporal feature extraction. Enhanced by handcrafted features like Relative Bone Length and Angle with Gravity, it achieves 91.18% accuracy on the TPGR dataset.

## B. R-CNN

In this section, we delve into the R-CNN family of models, which build upon the strengths of CNNs by introducing region-based detection for improved precision in complex scenarios such as traffic monitoring. We will explore the evolution of R-CNN models, beginning with Vanilla R-CNN and progressing through Fast R-CNN, Faster R-CNN, and Mask R-CNN, highlighting their advancements and contributions to traffic scene understanding.

![bo_d2839q77aajc738ors5g_4_109_187_1501_403_0.jpg](images/bo_d2839q77aajc738ors5g_4_109_187_1501_403_0.jpg)

FIGURE 1. Vanilla R-CNN workflow for object detection in a traffic scene: The process starts with identifying a set of proposed regions that could contain objects. Each proposed region is then passed through a pre-trained CNN to extract features, followed by classification using class-specific SVMs. Finally, bounding boxes are refined to enhance localization accuracy. This workflow demonstrates the ability to accurately detect and classify objects such as cars, poles, and trees, achieving precise object localization and high reliability in real-time traffic monitoring applications.

## 1) VANILLA R-CNN

Vanilla R-CNN [10] extends traditional CNNs by using region proposals and pretrained CNNs for object detection. It generates region proposals to hypothesize object locations, processes each region through a CNN to extract feature vectors, and classifies these vectors with class-specific SVMs and bounding box regressors. This allows R-CNNs to manage object variability and achieve superior detection performance.

Figure 1 illustrates the Vanilla R-CNN process for object detection in a traffic scene. The first step is generating region proposals that may contain objects. If the image is denoted as $I$ , the set of region proposals can be represented as $R =$ $\left\{  {{r}_{1},{r}_{2},\ldots ,{r}_{n}}\right\}$ , where each ${r}_{i}$ is a bounding box.

Each region ${r}_{i}$ is passed through a pre-trained CNN to extract a feature vector ${F}_{i}$ . The CNN maps the region ${r}_{i}$ to the feature vector ${F}_{i}$ , represented as ${F}_{i} = f\left( {r}_{i}\right)$ .

The extracted feature vectors are classified using class-specific linear SVMs. The score for region ${r}_{i}$ belonging to class $j$ is ${S}_{ij} = {f}_{{\mathrm{{SVM}}}_{j}}\left( {F}_{i}\right)$ , where ${f}_{{\mathrm{{SVM}}}_{j}}$ is the SVM for class $j$ .

Finally, the bounding box for each region proposal is refined using a bounding box regressor. This regressor, $g$ , takes the feature vector ${F}_{i}$ and the original bounding box ${r}_{i}$ as input and outputs a new bounding box ${b}_{i}$ , represented as ${b}_{i} =$ $g\left( {{F}_{i},{r}_{i}}\right)$ . The output of R-CNN is a set of bounding boxes with their corresponding class labels, where each bounding box is assigned to the class with the highest SVM score.

R-CNNs have greatly advanced object detection in traffic scenes, surpassing traditional CNNs with accuracy rates of up to 75.6% on the COCO dataset [11]. They excel in detecting pedestrians [12], vehicles [13], and traffic signs [14], [15]. Innovations like cascaded architectures [16], attention mechanisms [17], and hybrid approaches [18] further improve their performance. These advancements contribute to robust traffic scene understanding, aiding the development of automated driving systems [19].

R-CNN, introduced in [10], significantly improves object detection accuracy by combining region proposals with CNNs. It addresses occlusion by using region proposals to better localize objects, even when partially occluded, in contrast to sliding window methods like OverFeat.

In a comparative study, R-CNN outperformed traditional CNN on the COCO dataset, achieving ${75.6}\%$ accuracy $(\mathrm{N} =$ 78) compared to ${47.7}\% \left( {\mathrm{\;N} = {78}}\right)$ for $\mathrm{{CNN}}$ . The study, with a ${70}\%  - {30}\%$ training-test split, found a significance p-value of 0.041 [11].

The authors of [12] focus on pedestrian detection, achieving a 23.3% miss rate on the Caltech dataset. They handle occlusion challenges by relying on the model's ability to learn from large datasets instead of explicit occlusion modeling, improving accuracy with more training data.

A method for traffic sign detection using sparse R-CNN [20] is introduced in [18]. On the BCTSDB and TT- ${100}\mathrm{\;K}$ datasets, it achieved state-of-the-art performance, with AP50 and AP75 scores of 99.1% and 96.2% for BCTSDB, and 53.1% and 48.7% for TT-100K.

The Bagging R-CNN framework in [17] uses ensemble learning with adaptive sampling to improve object detection in complex traffic scenes. It achieved ${58.7}\%$ AP and ${83.0}\%$ AP50 using ResNet50, and 63.0% AP and 87.1% AP50 using the Swin-T [21] backbone.

Context R-CNN, as presented in [19], improves stationary surveillance by selecting and storing objects in memory banks by category. This approach enhanced recognition performance on the TJU-DHD-traffic and Pascal VOC datasets, increasing the mean average precision (mAP) by 0.37 compared to conventional methods.

Although Vanilla R-CNN is foundational, its two-stage process is slow and inefficient due to sequential processing of region proposals and classification. This results in high computational complexity and latency, making it unsuitable for real-time applications. Additionally, it struggles with small object detection and relies on selective search, leading to redundant regions, while requiring significant memory and complex training procedures, limiting its practical use.

![bo_d2839q77aajc738ors5g_5_106_184_1478_757_0.jpg](images/bo_d2839q77aajc738ors5g_5_106_184_1478_757_0.jpg)

FIGURE 2. Fast R-CNN procedure for object detection in a traffic scene: The model processes the input image by first extracting features for the entire image using a deep convolutional neural network (Deep ConvNet). RoI projections are mapped onto this shared feature map to generate fixed-size feature vectors using RoI pooling. The resulting RoI feature vectors are passed through fully connected layers to produce two outputs: class probabilities (using a softmax layer for classification) and bounding box regression to refine bounding box coordinates. This enables accurate object detection, such as identifying the “Police Car” class and refining the bounding box parameters in the traffic scene, making it suitable for real-time applications.

## 2) FAST R-CNN

Fast R-CNN, introduced in [22], improves R-CNN by using a single forward pass of the image through a CNN to extract feature maps. It classifies object proposals and refines their spatial locations directly from shared feature maps, significantly improving training and testing speed. Fast R-CNN trains the VGG16 network [23] nine times faster and tests 213 times quicker than R-CNN, while achieving higher mAP on the PASCAL VOC 2012 dataset and surpassing SPPnet [24] in accuracy.

Figure 2 shows the Fast R-CNN approach for traffic scene object detection. Unlike R-CNN, Fast R-CNN uses a single deep CNN, denoted as ${f}_{\mathrm{{CNN}}}$ , to extract features from the entire image once, producing a feature map $\mathcal{F} = {f}_{\mathrm{{CNN}}}\left( I\right)$ .

Region proposals are generated and mapped onto the shared feature map $\mathcal{F}$ . Each region proposal ${r}_{i}$ is converted to a fixed-size feature vector ${\mathcal{F}}_{{r}_{i}} = {f}_{\text{RoI_Pooling }}\left( {\mathcal{F},{r}_{i}}\right)$ using RoI pooling.

Fast R-CNN uses a softmax layer for classification, unlike R-CNN’s SVMs. The probability ${P}_{ij}$ that region ${r}_{i}$ belongs to class $j$ is:

$$
{P}_{ij} = {f}_{\text{Softmax }}{\left( {\mathcal{F}}_{{r}_{i}}\right) }_{j}, \tag{4}
$$

where $j$ ranges from 1 to $C$ . For bounding box regression, Fast R-CNN refines the bounding box using predicted offsets ${\delta x},{\delta y},{\delta w},{\delta h}$ , calculated as:

$$
{b}_{i} = {f}_{\text{BBox_Refine }}\left( {{r}_{i},{\delta x},{\delta y},{\delta w},{\delta h}}\right) . \tag{5}
$$

The final output is a set of refined bounding boxes with class labels. Each bounding box is associated with the highest probability from the softmax layer.

Fast R-CNN has been successfully applied in various traffic scene tasks, enhancing detection and classification. It detects road surface signs [25], counts and identifies vehicles in challenging scenarios [26], and improves monitoring at intersections [27]. The technology also enables simultaneous detection of pedestrians and cyclists, excelling on urban datasets [28]. Additionally, it has been adapted for event-based vehicle classification and counting, demonstrating its versatility in dynamic traffic environments [29].

The authors of [28] propose a unified method for concurrent detection of pedestrians and cyclists using a novel UB-MPR detection proposal and a Fast R-CNN-based model. Tested on the Tsinghua-Daimler dataset, it achieves a recall rate of ${96.5}\%$ at an $\mathrm{{IoU}}$ threshold of 0.5 . The method addresses occlusion effectively by focusing on upper body detection, ensuring accurate detection even with partial occlusion.

In [30], a framework combining deformable part models (DPMs) with CNNs and region proposal networks (RPNs) accelerates Fast R-CNN. Tested on the KITTI car benchmark, it shows ${70}\%$ overlap for true positives across Easy, Moderate, and Hard settings, with up to ${12}\mathrm{x}$ speed improvement and comparable precision, especially in PASCAL VOC and KITTI assessments.

In [27], a road user monitoring system for intersections is presented, combining a GMM-based DL approach with geometric warping. Integrated with Fast R-CNN, it processes 0.92s and ${0.99}\mathrm{\;s}$ faster on the MIT and Jinan datasets, respectively, with fewer misses in tracking and classification.

The study in [31] proposes a joint detection framework for pedestrians and cyclists using Fast R-CNN, incorporating techniques like difficult case extraction, multi-layer feature fusion, and shared convolution layers. This deeper architecture outperformed its counterpart, achieving 4.3% and ${5.6}\%$ higher accuracy in pedestrian and cyclist detection, respectively.

In [29], an event-based object detection system using Fast R-CNN with hyperparameter optimization on modified Stanford car and Myanmar cars datasets is introduced. It achieves accurate vehicle classification and counting in real-time event video streaming, with improved accuracy for weddings and precise learning rate assessments on the Myanmar Cars dataset.

Fast R-CNN is used in [32] (referred to as "AllLightR-CNN" in our work) to detect moving vehicles in various conditions, such as low light, long shadows, cloudy weather, and dense traffic. It achieves an average computation time of 0.59 seconds with high detection rates, including 98.44% recall, ${94.20}\%$ accuracy, and ${90}\%$ precision in both day and night modes. The dataset ("AllLightRCNN_DS" in our work) includes 3975 frames from four YouTube videos, annotated for vehicle detection and classification, featuring occlusion and varying times of day and weather conditions.

Fast R-CNN improves speed over R-CNN by processing the entire image in a single pass but still relies on time-consuming region proposals, limiting real-time performance. While RoI pooling speeds up processing, it can introduce quantization errors, reducing accuracy, especially for small objects. Additionally, relying on external region proposal methods like Selective Search hinders real-time capabilities. Fast R-CNN also requires large labeled datasets and struggles with high-resolution images, where detailed feature extraction is critical.

## 3) FASTER R-CNN

Faster R-CNN, first introduced in [33], improves upon its predecessors, R-CNN and Fast R-CNN, by incorporating a Region Proposal Network (RPN). This RPN shares full-image convolutional features with the detection network, allowing for nearly cost-free region proposals.

Figure 3 illustrates the use of Faster R-CNN for object detection in a traffic scene. Faster R-CNN comprises two main modules: a deep fully convolutional network for proposing regions and a Fast R-CNN detector that classifies these regions. Together, these modules form a unified network for efficient object detection in complex environments like traffic scenes.

Given an input image, the first step in Faster R-CNN is to pass it through several convolutional and max pooling layers to produce a shared feature map. If the input image is denoted as $X$ , the convolution operation can be represented as:

$$
\mathcal{F} = {f}_{\text{conv }}\left( X\right)  \tag{6}
$$

where $\mathcal{F}$ is the resulting feature map.

The RPN takes the shared feature map $\mathcal{F}$ and outputs a set of rectangular object proposals, each with an objectness score. The RPN is fully convolutional and simultaneously predicts multiple region proposals at each location. If ${f}_{\mathrm{{RPN}}}\left( \mathcal{F}\right)$ represents the RPN operation, the output $\mathrm{Y}$ can be represented as:

$$
Y = \left\{  {\left( {{P}_{i},{s}_{i}}\right)  \mid  i = 1,\ldots , N}\right\}  , \tag{7}
$$

where ${P}_{i}$ is the $i$ -th proposed region and ${s}_{i}$ is the corresponding score.

The proposed regions are reshaped using an RoI pooling layer to provide a fixed-size input to the FC layers. This process is the same in both Fast R-CNN and Faster R-CNN, with the key difference being the source of the regions: external algorithms in Fast R-CNN and an internal RPN in Faster R-CNN. The reshaping by RoI pooling can be mathematically expressed as:

$$
{R}_{i} = {f}_{\mathrm{{ROI}}}\left( {{P}_{i},\mathcal{F}}\right) , \tag{8}
$$

where ${R}_{i}$ represents the reshaped region derived from each proposed region ${P}_{i}$ and the feature map $\mathcal{F}$ .

Finally, the reshaped regions are fed into a sequence of FC layers that output the class probabilities and bounding box coordinates. If ${f}_{c}\left( {R}_{i}\right)$ represents the classification operation, the overall output of Faster R-CNN can thus be represented as follows:

$$
Y = {f}_{c}\left( {{f}_{\mathrm{{ROI}}}\left( {{f}_{\mathrm{{RPN}}}\left( \mathcal{F}\right) ,\mathcal{F}}\right) }\right) . \tag{9}
$$

Faster R-CNN has advanced traffic scene understanding across several applications, improving environmental perception [34], optimizing traffic sign detection [35], and enhancing recognition of police gestures [36]. It has also refined pedestrian detection [37], boosted traffic surveillance [38], and enabled accurate vehicle categorization in traffic surveys [39]. These advancements improve performance in diverse conditions, aiding autonomous driving [40] and supporting real-time traffic analysis in smart cities [41].

An improved Faster R-CNN for small object detection is proposed in [42], specifically targeting small traffic signs in the TT100K dataset. It achieves a recall rate of ${90}\%$ and an accuracy rate of ${87}\%$ . The method addresses occlusion by using multi-scale convolution feature fusion and improved non-maximum suppression (NMS), enhancing the detection of small and partially occluded objects.

In [39], Faster R-CNN is used for vehicle detection in traffic surveys, chosen over SSD [43] and YOLO [44] for its higher accuracy despite slower speed. The authors highlight the advantages of DL over traditional methods, achieving over ${87}\%$ accuracy in vehicle detection, queue length estimation, and vehicle type classification, even in untrained environments.

![bo_d2839q77aajc738ors5g_7_98_186_1509_451_0.jpg](images/bo_d2839q77aajc738ors5g_7_98_186_1509_451_0.jpg)

FIGURE 3. Faster R-CNN workflow for object detection in a traffic scene: The process starts by passing the image through several convolutional layers to generate a shared feature map. The feature maps are then processed by a region proposal network, which produces a set of region proposals with corresponding objectness scores. These proposed regions are reshaped using RoI pooling to ensure a consistent input size for the fully connected layers. Finally, the reshaped regions are classified into specific object categories, such as sign poles and police cars, and adjusted for accurate bounding boxes. localization, resulting in precise detection of various elements in the traffic scene.

In [45], Faster R-CNN is enhanced for object detection using hard negative sample mining and a two-channel feature network. By treating complex multi-classification tasks as binary classification, the modified approach achieves a 5% accuracy improvement on the KITTI dataset.

The authors of [40] propose an enhanced Faster R-CNN for traffic sign detection, incorporating feature pyramid fusion, deformable convolution, and ROI Align. Tested under various conditions, it achieved mAP scores of ${92.6}\%$ in sunny, ${90.6}\%$ at sunset, and ${86.9}\%$ on rainy days, outperforming SSD [43], YOLOv2 [46], YOLOv3 [47], and YOLOv5 [48] in low-light and rainy conditions, proving effective for autonomous driving.

In [49], an enhanced Faster R-CNN with ResNet50-D, an attention-guided context feature pyramid network (ACFPN), and AutoAugment technology is proposed for traffic sign detection. Benchmarking against methods like SSD [43] and YOLOv3 [47], it achieved 29.8 FPS and 99.5% mAP on the CCTSDB dataset, surpassing other state-of-the-art methods, with competitive results on the TT100K dataset.

In [50], a correlation model analyzes haze's impact on traffic sign detection and sight distance, using a synthesized GTSDB dataset. The Faster R-CNN model, post-dehazing, achieved 95.11% detection accuracy. Results show that haze intensity inversely affects sight distance and detection, with accuracies of over 93% at 300 meters in light haze, 88%-93% at 100 meters in haze, and ${85}\%  - {88}\%$ at 50 meters in dense haze.

In [41], the authors discuss the Intelligent Transportation System (ITS)-oriented Information Acquisition Models (IAMs), using the Mirror Traffic dataset and Internet of Things (IoT) to predict traffic conditions and adjust signals in real-time. By comparing Faster R-CNN to R-CNN in a DL context, they found that Faster R-CNN, with an 85.10% recall and 86.79% accuracy, outperforms R-CNN by 6.20%.

Faster R-CNN enhances speed by integrating region proposal generation through an RPN and improves occlusion handling, enabling better detection of partially obscured or overlapping objects. Despite these advances, it still faces challenges with real-time processing due to the computational demands of the RPN, high memory usage, and the need for extensive training data. The model struggles with small, overlapping, or occluded objects, and its complexity makes implementation and tuning difficult, limiting its use in data-scarce scenarios.

## 4) MASK-R-CNN

Mask R-CNN [51] extends Faster R-CNN by adding a branch for object masks alongside class labels and bounding-box offsets. It achieves fine spatial layout extraction via pixel-to-pixel alignment, addressing limitations in Fast and Faster R-CNN. Retaining a two-stage approach, the first stage uses an RPN to propose regions, while the second stage predicts classes, bounding-box offsets, and binary masks for each RoI. RoI Align ensures precise feature alignment, improving segmentation accuracy. By predicting classification, regression, and segmentation in parallel, Mask R-CNN streamlines the multi-stage pipeline, offering a powerful solution for segmentation tasks.

Figure 4 shows Mask R-CNN applied to instance segmentation in a traffic scene. Key components unique to Mask R-CNN are highlighted, excluding those shared with Faster R-CNN (e.g., the backbone, RPN, and bounding-box regression). The focus is on its distinctive elements: the RoI Align operation and the mask prediction process.

After the RPN identifies potential object bounding box locations in the image, RoI Align warps features from the feature map to a fixed-size representation for each RoI without quantization:

$$
{x}^{\prime } = x \times  \frac{{w}_{\text{ROI }}}{{w}_{\text{pooled }}}
$$

$$
{y}^{\prime } = y \times  \frac{{h}_{\mathrm{{ROI}}}}{{h}_{\text{pooled }}}, \tag{10}
$$

![bo_d2839q77aajc738ors5g_8_105_190_1492_416_0.jpg](images/bo_d2839q77aajc738ors5g_8_105_190_1492_416_0.jpg)

FIGURE 4. Mask R-CNN procedure for instance segmentation in a traffic scene: The input image is first processed through an RPN to identify regions of interest. These regions are then refined using the RoI Align operation, which ensures precise feature extraction by avoiding quantization effects, leading to more accurate segmentation. The refined features are passed through fully connected layers for class prediction and bounding box regression. Subsequently, the mask prediction process generates detailed binary segmentation masks for each instance using convolutional layers, producing accurate pixel-level masks. This approach provides high-resolution masks for various objects within the traffic scene, such as vehicles, pedestrians, and traffic signs, enabling precise instance segmentation.

where ${w}_{\mathrm{{ROI}}}$ and ${h}_{\mathrm{{ROI}}}$ represent the width and height of the RoI, and ${w}_{\text{pooled }}$ and ${h}_{\text{pooled }}$ represent the width and height after RoI pooling, respectively.

The mask prediction process uses a Mask Head that generates binary masks for each RoI. In Equation 11, ${f}_{\text{Conv_2D }\left( \cdot \right) }$ is the 2D convolution operation on the input features. In Equation 12, ${\zeta }_{\text{Mask }}$ are raw mask predictions before the sigmoid function, and $P\left( {\zeta }_{\text{Mask }}\right)$ gives final pixel-level mask probabilities within the RoI:

$$
{\zeta }_{\text{Mask }} = {f}_{\text{Conv_2D }}\left( {x \times  \frac{{w}_{\text{ROI }}}{{w}_{\text{pooled }}}, y \times  \frac{{h}_{\text{ROI }}}{{h}_{\text{pooled }}}}\right)  \tag{11}
$$

$$
P\left( {\zeta }_{\text{Mask }}\right)  = \sigma \left( {\zeta }_{\text{Mask }}\right) . \tag{12}
$$

Mask R-CNN has been applied to various tasks, including floodwater detection on roads [52], traffic sign detection and recognition [53], and train safety through improved obstacle identification [54]. It also supports urban traffic management via vehicle contour detection and tracking [55], and enables accurate vehicle counting to manage congestion [56]. Comparative studies confirm its superior performance in vehicle detection and classification compared to other models [57].

In [52], a Mask R-CNN-based method for floodwater detection achieves 99.2% classification accuracy and 93.0% segmentation precision on the IDRF dataset [58], outperforming a prior approach [59]. For traffic sign detection and recognition, [53] uses a two-phase method with Mask R-CNN for shape-based detection and Xception [60] for classification on 11,074 Taiwanese traffic signs, achieving ${98.45}\%$ precision for triangular and 99.73% for circular signs, surpassing YOLOv5 [61].

The ME Mask R-CNN method [54] improves automated train safety by integrating SSwin-Le Transformer, ME-PAPN, and multiscale enhancements, achieving a 91.3% mAP on the TrainObstacle dataset, 11.1% higher than Mask R-CNN, and an average detection rate of 4.2 FPS. It improves small-target detection by 19.35%, though gains for large and occluded targets are limited due to dataset characteristics.

A comprehensive comparison [57] of Faster R-CNN, Mask R-CNN, and ResNet-50 (R-CNN) on the 3,200-image RCNNs_Detection dataset (cars and jeeps from Kaggle) shows that Faster R-CNN and Mask R-CNN exceed 80% detection accuracy, while ResNet-50 achieves over 75%. This demonstrates their effectiveness in vehicle detection, classification, and counting.

Mask R-CNN extends Faster R-CNN with a mask prediction branch, enabling instance segmentation and facilitating the detection of occluded objects by distinguishing overlapping instances. However, this extra branch increases computational and memory demands, complicating real-time use and deployment on resource-constrained devices. The model also requires substantial labeled data, longer training times, and can struggle with small objects and complex scenes. Its increased complexity makes implementation, tuning, and debugging more challenging, particularly for custom applications.

## C. YOLO

YOLO is a fast and efficient real-time object detection system that predicts detections in a single pass, unlike R-CNN methods relying on region proposals. Introduced in [44], it treats detection as a regression problem, dividing the image into a grid where each cell predicts bounding boxes, confidence scores, and class probabilities. YOLO generalizes well across domains but struggles with precise localization, especially for small objects. Fast YOLO, the then-fastest general-purpose detector, is also introduced.

![bo_d2839q77aajc738ors5g_9_254_188_1207_693_0.jpg](images/bo_d2839q77aajc738ors5g_9_254_188_1207_693_0.jpg)

FIGURE 5. YOLO object detection in a traffic scene featuring a police car: The input image is initially divided into an SxS grid, with each cell predicting bounding boxes, confidence scores, and class probabilities. This process culminates in a final detection display that accurately identifies and localizes the police car and other objects within the scene. A comprehensive legend highlights key objects of interest, providing a clear and detailed overview of the detected items. This real-time object detection approach combines speed and accuracy, making it highly effective for dynamic traffic monitoring applications.

Figure 5 illustrates YOLO applied to a traffic scene. An input image $I$ is divided into an $S \times  S$ grid. Each grid cell detects objects if their center falls within it. A convolutional network processes the image and outputs a tensor of shape $S \times  S \times  \left( {B \times  5 + C}\right)$ , where $B$ is the number of bounding boxes per cell, and $C$ is the number of classes.

Bounding boxes are defined by(x, y, w, h, s), where(x, y) are the center coordinates relative to the grid cell, $w$ and $h$ are relative to the image size, and $s$ is the confidence score, indicating the likelihood and accuracy of the box containing an object.

Each grid cell predicts $C$ conditional class probabilities, $P\left( {{\mathrm{c}}_{i} \mid  \widehat{o}}\right)$ , for the detected object $\widehat{o}$ belonging to class ${c}_{i}$ . The final prediction combines these probabilities with the confidence score:

$$
P\left( {\mathrm{c}}_{i}\right)  = s \times  P\left( {{\mathrm{c}}_{i} \mid  \widehat{o}}\right)  \tag{13}
$$

YOLO applies Non-Maximum Suppression (NMS) to remove redundant overlapping boxes. Predictions are sorted by confidence score, and overlapping boxes (e.g., IoU > 0.5) with lower scores are removed.

YOLO’s operation is summarized as $o = {f}_{\mathrm{{NMS}}}\left( {{f}_{\mathrm{{Conv}}}\left( I\right) }\right)$ , where $o$ is the final prediction, ${f}_{\text{Conv }}$ represents convolutional layers, and ${f}_{\mathrm{{NMS}}}$ applies NMS.

YOLO has been adapted for traffic flow counting [62], traffic light detection [63], and traffic sign recognition [64], [65]. It effectively detects pedestrians and vehicles [66] and operates under varied lighting and weather conditions [67], [68]. Continuous improvements enable better small-target detection and high-resolution video processing [69], [70]. Additionally, YOLO versions support license plate identification [71] and have been compared across models for traffic sign detection and vehicle classification in challenging environments [72], [73].

YOLO has seen numerous enhancements and iterations since its inception. The following presents the primary YOLO versions, accompanied by historical insights and a review of relevant scholarly literature.

## 1) YOLOV1 (YOLO)

Debuted in 2016, this original YOLO model was ground-breaking as it treated object detection as a singular regression problem, enabling it to predict bounding box coordinates and class probabilities from an image in a single pass [44].

The importance of Traffic Light Detection (TLD) for intelligent vehicles and Driving Assistance Systems is highlighted in [63], which applies YOLO to the daySequence1 from the LISA Traffic Light Dataset. The study achieves a 90.49% AUC, a 50.32% improvement over the previous best using Aggregated Channel Features (ACF), and a 58.3% AUC comparable to the ACF configuration. This underscores TLD's critical role in enhancing self-driving car functionality.

## 2) YOLOv2

Launched in 2017, YOLOv2 [46] introduced major improvements, including detection of over 9000 object categories, the "Darknet-19" architecture, anchor boxes for better bounding box prediction, and multi-scale training. By combining detection-labeled data from COCO with classification data from ImageNet [74], the authors enabled joint classification and detection, creating YOLO9000 [46], capable of detecting a vast range of categories.

An optimized pedestrian and vehicle detection algorithm based on YOLOv2 is introduced in [66], which improves accuracy while maintaining efficiency. Comparative results on the KITTI dataset demonstrate its real-time capability, outperforming Faster R-CNN and YOLO V2 with 45% accuracy for pedestrians and ${61.34}\%$ for vehicles at 22 FPS.

## 3) YOLOv3

Unveiled in 2018, YOLOv3 employed three distinct sizes of anchor boxes for predictions across three scales. It utilized a deeper architecture, "Darknet-53," and expanded its object category detection capabilities. Additionally, it adopted three different sizes of detection kernels $\left( {{13} \times  {13},{26} \times  {26},{52} \times  {52}}\right)$ to identify objects of varying dimensions [47].

A YOLOv3-based traffic sign recognition system introduced in [64] achieves a ${92.2}\%$ mAP for detection on the GTSDB dataset and 99.6% classification accuracy on the GTSRB dataset using a CNN-based classifier. It outperforms Faster R-CNN in both detection accuracy and frame rate, processing images at approximately 9.87 FPS.

## 4) YOLOv4

Released in 2020, YOLOv4 incorporated numerous improvements over its predecessors. It integrated features such as the "CSPDarknet53-PANet-SPP" architecture, PANet, and SAM block. Additionally, it employed the Complete IoU (CIoU) loss and the Mish activation function, aiming to enhance both speed and accuracy [75].

In [76], traffic sign detection and recognition for smart vehicles are explored using YOLOv4 and YOLOv4-tiny [75] integrated with Spatial Pyramid Pooling (SPP). Results show Yolo V4_1 (with SPP) achieving 99.4% accuracy and 99.32% mAP, while Yolov3 [47] SPP attains 98.99% mAP. These findings indicate that SPP enhances model performance.

To address environmental challenges like light intensity, extreme weather, and distance, TSR-YOLO [68], based on YOLOv4-tiny, incorporates Better-ECA (BECA), dense SPP networks, and k-means++ clustering for optimal prior boxes. On the CCTSDB2021 dataset, it achieves 96.62% accuracy, 79.73% recall, an 87.37% F1-score, and a 92.77% mAP, improving over YOLOv4-tiny while maintaining 81 FPS.

A novel semi-automatic method, combining a modified YOLOv4 and background subtraction, is introduced in [77] for unsupervised object detection in surveillance videos. It significantly increases mAP and outperforms state-of-the-art results on the CDnet 2014 and UA-DETRAC datasets, achieving ${97.4}\%$ precision compared to YOLOv3’s ${89}\%$ and YOLOv4's 90.4% on the Street corner at night scenario.

## 5) YOLOv5

Introduced in 2020, YOLOv5 [61], developed independently, is not an official continuation by the original YOLO creators. It features a modified "CSPDarknet53" backbone with architectural optimizations to improve speed and real-world applicability. Its naming sparked controversy, as it was not created by the original authors.

To improve vehicle detection in traffic surveillance videos, [69] proposes an enhanced YOLOv5s model with a small target detection layer and Atrous SPP (ASPP) for multi-scale context, achieving 93.7% precision, 94.2% recall, and 93.9% mAP@0.5—improvements of 0.8%, 1.9%, and 2.3% over the original YOLOv5s, reducing missed and false detections.

Ghost-YOLO [70] is a lightweight model for traffic sign detection using the C3Ghost module to replace YOLOv5's feature extraction. It achieves ${92.71}\% \mathrm{{mAP}}$ while reducing parameters by 91.4% and computations by 50.29%, balancing speed and accuracy for real-world use.

## 6) YOLOv6

Introduced in September 2022, YOLOv6 boasts an efficient design comprising a backbone with RepVGG [78] or the newly introduced "CSPStackRep" blocks, a Path Aggregation Networks (PAN) topology neck, and a decoupled head with a hybrid-channel strategy. It uses advanced quantization techniques, such as post-training quantization and channel-wise distillation, leading to swifter and more precise detectors [79].

A license plate identification algorithm is outlined in [71] based on the YOLOv6 convolution model, enhancing efficiency with a 94.7% precision rate for location and a proposed BLPNET(VGG-19-RESNET-50) model achieving 100% F1- score in character recognition, leading to reduced costs and improved traffic management effectiveness.

## 7) YOLOv7

Released in July 2022, YOLOv7 set new object detection benchmarks, excelling in speed (5)-160 FPS) and accuracy. Trained solely on the MS COCO dataset without pre-trained backbones, it introduced architectural modifications and "bag-of-freebies" to boost accuracy without sacrificing inference speed, though training time increased [80].

An enhanced YOLOv7-WCN network for traffic sign detection [81] improves accuracy from 85.5% to 89.0% by integrating Horblock modules with convolutional layers for efficient mapping, a normalization-based attention module (NAM), and replacing CIoU loss with Wasserstein distance loss [82].

## 8) YOLOv8

Unveiled in January 2023, YOLOv8 [83] offers five scaled versions: YOLOv8n (nano), YOLOv8s (small), YOLOv8m (medium), YOLOv81 (large), and YOLOv8x (extra large), using a backbone similar to the one used in YOLOv5 but with some modifications on the cross-stage partial (CSP) layer. This iteration supports a wide range of computer vision tasks, including object detection, segmentation, pose estimation, tracking, and classification.

To address road accidents caused by human error, [72] proposes a traffic sign detection method using YOLOv5s6 [61] and YOLOv8s [83]. Testing on TT100k, TWTS, and a hybrid dataset shows YOLOv8s outperforms YOLOv5s6, achieving an mAP@. 5 of ${76.2}\%$ compared to ${65}\%$ on the hybrid dataset.

Recent studies have compared object detection algorithms across diverse environments and datasets. Reference [84] evaluated Faster R-CNN, YOLOv3, and YOLOv4 for aerial car detection on Stanford and PSU datasets, highlighting the impact of dataset characteristics and parameters like input size and learning rate on accuracy. On the PSU dataset, YOLOv3 and YOLOv4 achieved AP scores of 0.965, outperforming Faster R-CNN (0.739).

A broader evaluation of SSD, Faster R-CNN, and YOLO versions (YOLOv8, YOLOv7, YOLOv6, YOLOv5) on nine datasets (referred to as "ShokriCollection_DS" in our work) featuring varied road challenges was conducted in [73]. YOLO, particularly YOLOv7, excelled with over 95% detection accuracy and ${90}\%$ Overall Accuracy (OA) for vehicle classification, despite differing computation times. Metrics were averaged across high-quality datasets from YouTube and Kaggle.

Another comparison [85] shows that YOLOv6 (73.5 mAP) and YOLOv8 (71.8 mAP) significantly outperform DETR ( ${49.9}\mathrm{{mAP}}$ ) when benchmarking various state-of-the-art object detectors and exploring large computer vision models as image annotators on the RSUD20K dataset for road scene understanding in autonomous driving.

YOLOv1 [44] and YOLOv2 [46] struggled with occlusions due to coarse feature extraction, limiting the detection of overlapping objects. YOLOv3 [47] improved this with multi-scale detection, and YOLOv4 [75] enhanced occlusion handling using feature pyramid networks. Despite these advances, challenges persist. CCW-YOLO [86] improved detection in dense scenes with a lightweight convolutional layer and C2f module, while HCLT-YOLO [87] used a hybrid CNN and transformer to reduce false alarms and missed detections.

YOLO is fast and efficient for real-time object detection due to its single-shot approach, processing an entire image in one pass. However, this design can struggle with detecting small objects, as the grid-based prediction may lack the precision needed for finer details. YOLO also has difficulty handling overlapping instances, where objects are close together, leading to potential inaccuracies. Additionally, its emphasis on speed may trade off some accuracy, particularly in complex scenes with multiple objects or intricate backgrounds, where precise localization and classification become more challenging.

## D. ViT

ViT, introduced in [88], applies transformers to image classification by processing images as patch sequences. Using self-attention, it captures complex dependencies and prioritizes visible features and context, more effectively handling occlusions by inferring hidden objects. Unlike CNNs with localized receptive fields, ViT captures long-range dependencies across the entire image, marking a significant shift in image processing.

Figure 6 illustrates the application of ViT to classification in a traffic scene. The initial step in ViT is Image Patching which involves splitting an image into a series of fixed-size patches. These patches are then flattened and linearly embedded. Additionally, position embeddings are added to retain positional information:

$$
{e}_{0} = \left\lbrack  {{x}_{\text{class }};{x}_{p}^{1}E;{x}_{p}^{2}E;\ldots ;{x}_{p}^{N}E}\right\rbrack   + {E}_{\text{pos }}, \tag{14}
$$

where ${e}_{0}$ is the initial input embedding to the transformer, ${x}_{p}^{i}$ is the $i$ -th image patch, $E$ is the patch embedding projection, ${E}_{\text{pos }}$ are the position embeddings, ${x}_{\text{class }}$ is a learnable embedding that serves as a representation of the entire image, and $N$ is the total number of patches.

The embedded patches then pass through a series of Transformer encoder layers. Each layer comprises two main parts: a multi-headed self-attention mechanism (MHSA) and a position-wise feed-forward network (FFN).

The MHSA is a self-attention mechanism that allows the model to weigh the importance of different patches when processing each patch:

$$
{f}_{\text{Attention }}\left( {Q, K, V}\right)  = {f}_{\text{softmax }}\left( \frac{Q{K}^{\top }}{\sqrt{{d}_{k}}}\right) V, \tag{15}
$$

where $Q, K, V$ are the queries, keys, and values, respectively, computed from the input embeddings, and ${d}_{k}$ is the dimension of the keys.

The attention output is processed through multiple "heads," and the results from these heads are concatenated, represented by the symbol $\parallel$ :

$$
{f}_{\text{MultiHead }}\left( {Q, K, V}\right)  = \left( {{h}_{1}\parallel \ldots \parallel {h}_{n}}\right) {W}^{O}, \tag{16}
$$

where the $i$ -th head is computed as:

$$
{h}_{i} = {f}_{\text{Attention }}\left( {Q{W}_{i}^{Q}, K{W}_{i}^{K}, V{W}_{i}^{V}}\right) , \tag{17}
$$

and ${W}_{i}^{Q},{W}_{i}^{K},{W}_{i}^{V}$ , and ${W}^{O}$ are learned parameter matrices, and $n$ is the number of attention heads.

The position-wise FFN consists of two linear transformations with a ReLU activation in between:

$$
{f}_{\mathrm{{FFN}}}\left( x\right)  = \max \left( {0, x{W}_{1} + {b}_{1}}\right) {W}_{2} + {b}_{2}, \tag{18}
$$

where $x$ is the input to the FFN, ${W}_{1}$ and ${W}_{2}$ are weight matrices, and ${b}_{1}$ and ${b}_{2}$ are bias vectors.

After passing through the Transformer layers, the class token's output (from the final layer) is used to predict the class of the image via a simple linear layer:

$$
o = {z}_{\text{class }}^{L}{W}^{C}, \tag{19}
$$

where ${z}_{\text{class }}^{L}$ is the output corresponding to the class token from the last Transformer layer, ${W}^{C}$ is the output projection matrix, and $o$ is the output.

![bo_d2839q77aajc738ors5g_12_279_199_1173_586_0.jpg](images/bo_d2839q77aajc738ors5g_12_279_199_1173_586_0.jpg)

FIGURE 6. Application of ViT in classifying a traffic scene with a crosswalk: The input image is divided into fixed-size patches, which are then flattened and linearly projected into an embedding space. Position embeddings are added to these patch embeddings to retain spatial relationships, along with a class embedding to represent the entire image. The combined embeddings are sequentially processed through the Transformer encoder, involving multiple layers of multi-head self-attention and feed-forward networks. The class token output from the final Transformer layer is passed through an MLP head to predict the class label, in this case, 'crosswalk'

Some applications of ViTs include detecting rain and road surface conditions [89], predicting pedestrian crossing intentions [90], identifying critical traffic moments [91], and detecting unusual traffic scenarios [92].

A cost-effective method for detecting rain and road conditions using ViTs and a Spatial Self-Attention network is presented in [89], achieving F1-scores of 91.13% for rain and 92.10% for road conditions. Adding a sequential detection module improved accuracy to 96.74% and 98.07%, respectively. The study's dataset, referred to as "ViT_DS" in our work, includes 10,000 freeway images from CCTV cameras in Orlando, Florida, labeled for 3 rain levels and 2 road condition levels.

Action-ViT [90] integrates multimodal data-including visual cues, poses, bounding boxes, and action annotations-and employs tailored data processing for each modality, enhancing pedestrian crossing intention prediction and achieving a ${90.2}\%$ F1-score on the JAAD dataset, with ablation studies confirming improvements in temporal modeling and feature fusion.

ViT-TA [91] is a custom ViT that achieves 94% accuracy in detecting critical moments at Time-To-Collision (TTC) $\leq$ 1s on the Dashcam Accident Dataset (DAD). It classifies critical traffic situations and uses attention maps to highlight probable causes, systematically enhancing automated vehicle safety by generating reliable safety scenarios.

Vit-L [92] detects scenario novelty in traffic using infrastructure images and a triplet autoencoder trained on 70,000 traffic scene and graph pairs in Germany. Enhanced by expert domain knowledge and ViTs, it uses Angle-Based Outlier Detection (ABOD) in the latent space, achieving a 95.6% AUC. The dataset, referred to as "Wurst_DS" in our work and detailed in [93], comprises highway images for outlier model fitting.

ViTs excel at capturing long-range dependencies in images, allowing for a more holistic understanding of visual data. However, they require large amounts of data and substantial computational power to achieve high performance, making them less accessible in data-limited scenarios. ViTs can struggle with generalizing from smaller datasets, often leading to overfitting or suboptimal results. Additionally, they may be less efficient than CNNs for lower-resolution images, where the advantage of capturing long-range dependencies is diminished, and the computational overhead becomes more pronounced.

## E. DETR

DETR, introduced in [94], is an innovative model for object detection that leverages the Transformer architecture to streamline the process into an end-to-end framework. By treating object detection as a direct set prediction problem, DETR eliminates the need for hand-designed components like non-maximum suppression and anchor generation. The model employs a combination of a CNN for feature extraction and a Transformer for decoding these features into bounding box predictions and class labels in a single forward pass. Leveraging self-attention, DETR models complex relationships between objects and their context, making it particularly effective at detecting and localizing partially occluded objects by interpreting visible fragments within the overall scene. This unified transformer-based approach marks a significant advancement in handling occlusions and simplifying object detection.

![bo_d2839q77aajc738ors5g_13_106_197_1501_282_0.jpg](images/bo_d2839q77aajc738ors5g_13_106_197_1501_282_0.jpg)

FIGURE 7. DETR object detection in a traffic scene: The process begins with a CNN extracting image features, which are then enhanced with positional encodings to preserve spatial information and processed through a transformer encoder. The encoder employs several layers of self-attention and FFNs to refine these features for improved detection accuracy. The transformer decoder uses a fixed set of learned object queries, combined with the encoded features, to generate predictions for possible objects, including their classes and bounding boxes. Four FFNs are employed to finalize classifications and bounding box coordinates, effectively highlighting detected objects in the scene.

Figure 7 depicts the application of DETR to object detection in a traffic scene. DETR starts with feature extraction through which given an input image $I$ , a ${f}_{\text{ConvNet }}$ is used to extract a feature map $\mathcal{F}$ where $\mathcal{F} = {f}_{\text{ConvNet }}\left( I\right)$ , and ${f}_{\text{ConvNet }}$ is a CNN.

Positional encodings (PEs) are then added to the feature map $\mathcal{F}$ to preserve spatial information, resulting in ${\mathcal{F}}^{\prime } =$ $\mathcal{F} + {PE}$ , where ${\mathcal{F}}^{\prime }$ denotes the feature map with positional encoding added.

At the next step, the Transformer encoder processes this enhanced feature map ${\mathcal{F}}^{\prime }$ through several layers of self-attention and FFNs, resulting in ${\mathcal{F}}_{z} = {f}_{\text{Encoder }}\left( {\mathcal{F}}^{\prime }\right)$ , where ${\mathcal{F}}_{z}$ is the encoded feature representation.

The Transformer decoder uses a set of fixed learned object queries $\mathcal{Q}$ and the encoded features ${\mathcal{F}}_{z}$ to generate predictions:

$$
\mathcal{Q} = \left\{  {{q}_{1},{q}_{2},\ldots ,{q}_{{N}_{q}}}\right\}   \tag{20}
$$

where $\mathcal{Q}$ is the set of ${N}_{q}$ learned object queries, and ${q}_{i}$ represents the $i$ -th query embedding. The output of the decoder is $o = {f}_{\text{Decoder }}\left( {{\mathcal{F}}_{z},\mathcal{Q}}\right)$ , where $o$ contains the predictions for potential objects, represented as classes and bounding boxes.

The outputs of the Transformer decoder are then processed to yield a fixed-size set of predictions, irrespective of the number of objects in the image. This is represented as:

$$
Y = \left\{  {\left( {{\widehat{c}}_{i},{\widehat{b}}_{i}}\right)  \mid  i = 1,\ldots , N}\right\}  , \tag{21}
$$

where ${\widehat{c}}_{i}$ and ${\widehat{b}}_{i}$ are the predicted class and bounding box coordinates for the $i$ -th object, and $N$ is the number of predictions.

The loss function is a crucial part of training DETR, incorporating a unique bipartite matching loss to match predicted and ground truth objects, along with classification and bounding box regression losses.

Bipartite matching is used to find the optimal permutation of predicted objects $\sigma$ that minimizes the matching cost, as described in [94]:

$$
\sigma  = \mathop{\operatorname{argmin}}\limits_{{\sigma  \in  {\sum }_{N}}}\mathop{\sum }\limits_{{i = 1}}^{N}{f}_{\text{cost }}\left( {{y}_{i},{\widehat{y}}_{\sigma \left( i\right) }}\right) , \tag{22}
$$

where ${\sum }_{N}$ is the set of all permutations of $N$ elements, ${y}_{i}$ is the ground truth, and ${\widehat{y}}_{i}$ is the prediction. Here, ${f}_{\text{cost }}$ is the cost function that measures the difference between the ground truth objects ${y}_{i}$ and the predicted objects ${\widehat{y}}_{\sigma \left( i\right) }$ .

The loss function $\mathcal{L}$ combines the costs of classification and bounding box prediction:

$$
\mathcal{L} = \mathop{\sum }\limits_{{i = 1}}^{N}\left\lbrack  {{\lambda }_{\mathrm{{cls}}} \cdot  {\mathcal{L}}_{\mathrm{{cls}}}\left( {{\widehat{c}}_{\sigma \left( i\right) },{c}_{i}^{ * }}\right)  + {\lambda }_{\mathrm{{bbox}}} \cdot  {\mathcal{L}}_{\mathrm{{bbox}}}\left( {{\widehat{b}}_{\sigma \left( i\right) },{b}_{i}^{ * }}\right) }\right\rbrack  ,
$$

(23)

where ${c}_{i}^{ * }$ and ${b}_{i}^{ * }$ are the true class and bounding box of the $i$ -th object, respectively, and ${\lambda }_{\mathrm{{cls}}}$ and ${\lambda }_{\text{bbox }}$ are weighting factors that determine the relative importance of the classification loss ${\mathcal{L}}_{\text{cls }}$ and the bounding box loss ${\mathcal{L}}_{\text{bbox }}$ . The loss function $\mathcal{L}$ is minimized during training to ensure that the predicted outputs closely match the ground truth annotations. This approach helps achieve accurate object detection by focusing on both the correctness of the predicted class and the accuracy of the bounding box localization.

During training, DETR minimizes this loss function to learn the parameters that result in the best predictions of object classes and bounding boxes, tailored to match the true objects in the image as closely as possible. This streamlined approach of direct set prediction and loss minimization via bipartite matching distinctly sets DETR apart in the field of object detection.

DETR's applications are diverse, including enhancements for detecting traffic signs of various sizes [95], recognizing small or weather-affected signs [96], and accelerating model training [97]. Additionally, DETR enhances object detection for autonomous driving by effectively aligning objects with their respective scenes [98].

An innovative approach to traffic sign detection, DSRA-DETR [95], emphasizes enhanced multiscale detection performance through modules that aggregate features across scales, effectively reducing feature noise, preserving low-level features, and boosting the model's ability to recognize objects at various sizes. This results in significant improvements in detection accuracy with impressive APs of 76.13% and 78.24% on GTSDB and CCTSDB datasets, respectively.

MTSDet [96] enhances traffic sign detection by using an Attention Mechanism Network (AMNet) and a Path Aggregation Feature Pyramid Network (PAFPN) for multi-scale feature fusion. It excels at detecting small or weather-affected signs, achieving mAP scores of 92.9% on GTSRB and 94.3% on CTSD.

In [97], a Spatially Modulated Co-Attention (SMCA) mechanism improves DETR by focusing co-attention near initial box estimates and integrating multi-head, scale-selection attention. This yields ${45.6}\mathrm{\;{mAP}}$ in 108 epochs, surpassing DETR’s original ${43.3}\mathrm{{mAP}}$ in 500 epochs, as verified by extensive ablation studies on COCO.

DetectFormer [98] improves autonomous driving object detection by incorporating a ClassDecoder and a Global Extract Encoder (GEE) to enhance category sensitivity and scene alignment. With data augmentation and attention mechanisms, it achieves AP50 and AP75 scores of 97.6% and 91.4%, respectively, on the BCTSDB dataset.

DETR simplifies object detection by eliminating the need for region proposals and streamlining the process with a transformer-based architecture. However, it requires extensive training data to perform well and is computationally intensive, making it challenging to deploy in resource-constrained environments. DETR can also be slower to converge during training, requiring more epochs to reach optimal performance. Additionally, it struggles with detecting small objects in cluttered scenes, where the lack of region proposals can lead to less precise localization and classification.

## F. GRAPH NEURAL NETWORK (GNN)

GNNs are a powerful tool for traffic scene understanding, representing road networks as graphs and capturing spatial-temporal relationships. They enable precise analysis of vehicle trajectories, pedestrian movements, and interactions, aiding tasks like congestion prediction, collision avoidance, and adaptive signal control. By leveraging graph-based methods, GNNs enhance real-time decision-making in intelligent transportation systems, contributing to safer and more efficient urban mobility.

## 1) GCN

GCN, first introduced in [99], is a neural network designed for graph-structured data, extending the concept of convolution from grid-like data (e.g., images) to graphs. A graph $\mathcal{G} =$ (V, E)consists of nodes $V\left( {\left| V\right|  = N}\right)$ and edges $E$ , represented by an adjacency matrix $A$ , where ${A}_{ij} = 1$ if an edge exists between nodes $i$ and $j$ , and 0 otherwise. Each node ${v}_{i} \in  V$ has a feature vector ${\mathcal{F}}_{i} \in  {\mathbb{R}}^{d}$ , and the node features collectively form a matrix $\mathcal{F} \in  {\mathbb{R}}^{N \times  d}$ , where $d$ is the number of features per node.

The core idea of a GCN is to perform a convolution-like operation on a graph. The graph convolution for a single layer is expressed as:

$$
{\mathcal{F}}^{\left( l + 1\right) } = \sigma \left( {\widehat{A}{\mathcal{F}}^{\left( l\right) }{W}^{\left( l\right) }}\right) , \tag{24}
$$

where ${\mathcal{F}}^{\left( l\right) } \in  {\mathbb{R}}^{N \times  {F}^{\left( l\right) }}$ is the input feature matrix at layer $l$ , ${W}^{\left( l\right) } \in  {\mathbb{R}}^{{F}^{\left( l\right) } \times  {F}^{\left( l + 1\right) }}$ is the weight matrix, $\sigma$ is a non-linear activation function (e.g., ReLU), and $\widehat{A}$ is the normalized adjacency matrix with self-loops.

The normalized adjacency matrix $\widehat{A}$ is defined as:

$$
\widehat{A} = {\Delta }^{-\frac{1}{2}}\widetilde{A}{\Delta }^{-\frac{1}{2}}, \tag{25}
$$

where $\widetilde{A} = A + {I}_{d}$ (adjacency matrix with self-loops), and $\Delta$ is the degree matrix of $\widetilde{A}$ with diagonal elements ${\Delta }_{ii} = \mathop{\sum }\limits_{j}{\widetilde{A}}_{ij}$ .

A typical GCN model has multiple layers. For instance, a two-layer GCN is:

$$
O = {f}_{\text{softmax }}\left( {\widehat{A}X{W}^{\left( 0\right) }{W}^{\left( 1\right) }}\right) , \tag{26}
$$

where $X$ is the input feature matrix, ${W}^{\left( 0\right) }$ and ${W}^{\left( 1\right) }$ are the weight matrices, $\sigma$ is the activation function, and $O$ represents the final output, e.g., class probabilities for node classification.

The GCN is trained by minimizing the cross-entropy loss:

$$
\mathcal{L} =  - \mathop{\sum }\limits_{{i \in  \mathcal{Y}}}\mathop{\sum }\limits_{{c = 1}}^{C}{Y}_{ic}\log {O}_{ic} \tag{27}
$$

where $\mathcal{Y}$ is the set of labeled nodes, $Y$ is the label matrix, and $C$ is the number of classes.

By iteratively updating ${W}^{\left( l\right) }$ using gradient descent, the GCN learns features from the graph structure and node attributes for the target task.

GCNs excel in traffic scene understanding by modeling complex relationships in graph-structured data. Applications include vehicle behavior classification across datasets [100], recognizing dynamic traffic police gestures [101], interpreting these gestures in real-time [102], understanding police intentions from visual cues [103], and recognizing actions of traffic participants in advanced driver-assistance systems [104].

The MR-GCN architecture for vehicle behavior classification [100] achieves sensor invariance and high accuracy: 99% on Apollo, 89% on KITTI, and 84% on Indian datasets. Combining spatial scene graphs and LSTM layers, it encodes spatial-temporal dynamics and outperforms baselines, demonstrating robustness across diverse datasets, even with fewer landmarks.

In [101], a gesture recognition method focuses on dynamic traffic police gestures using a spatial-temporal GCN (ST-GCN) with attention mechanisms and adaptive graph structures. It achieves 87.72% accuracy on the Chinese Traffic Police Gestures (CTPG) dataset, outperforming existing action-recognition methods.

Pose GCN [102] presents an online activity recognition method employing pose estimation and GCNs to interpret traffic police gestures in real-time frames. It achieves a response time of ${716}\mathrm{\;{ms}}$ and an accuracy rate of ${97.52}\%$ on the TPGR dataset.

In [103], a system for recognizing traffic police intentions from visual cues achieves ${87.72}\%$ OA on the TPGR dataset. The approach uses OpenPose [105] to extract key points, which are transformed into spatiotemporal maps processed by GCNs and modified transformers.

![bo_d2839q77aajc738ors5g_15_112_186_1486_450_0.jpg](images/bo_d2839q77aajc738ors5g_15_112_186_1486_450_0.jpg)

FIGURE 8. GAT-based license plate detection: An image of a car’s rear undergoes convolution to extract essential features, which are then refined by a GAT layer using an attention mechanism to determine the importance of neighboring features. The GAT operates on a graph representation, where each node is associated with a feature vector, and computes attention weights between nodes to aggregate information effectively. The saliency map is produced by fusing these attention-weighted features, guiding an RPN to accurately localize and identify the license plate. This sophisticated setup, combined with attention mechanisms to compute dynamic weights, enhances detection precision, ensuring reliable and accurate identification of license plates under various conditions. The integration of multiple attention heads helps capture different aspects of neighboring relationships, contributing to robustness in feature refinement.

The framework in [104] employs 3D human pose estimation and a dynamic adaptive GCN to recognize actions of traffic police, cyclists, and pedestrians. By optimizing object detection and pose estimation modules, it processes multiple objects simultaneously in real traffic scenarios, achieving ${80}\%$ accuracy on the 3D-HPT dataset.

GCNs effectively model complex relationships in non-Euclidean data like graphs but face challenges with scalability due to high computational and memory demands on large graphs. They are prone to over-smoothing, where node features lose distinction after multiple layers, and require careful design to capture long-range dependencies, as standard architectures may not naturally handle distant node relationships.

## 2) GAT

GAT, introduced in [106], represents NN architectures for graph-structured data, incorporating attention mechanisms. Using masked self-attentional layers, GATs overcome the limitations of graph convolutions by allowing nodes to assign varying weights to neighbors' features. This avoids computationally expensive matrix operations like inversion and does not require a priori graph structure knowledge.

Figure 8 illustrates the GAT-based license plate detection process, where the attention mechanism refines features for accurate license plate identification in traffic scenes. For a graph $\mathcal{G} = \left( {V, E}\right) , V$ represents the set of nodes, and $E$ represents the set of edges. Each node ${v}_{i} \in  V$ is associated with a feature vector ${\mathcal{F}}_{i} \in  {\mathbb{R}}^{d}$ , where $d$ is the feature dimension.

The key idea behind GAT is to compute an attention weight for each neighbor of a node and use these weights to aggregate information from the neighbors. GAT employs a self-attention mechanism to calculate the attention weights for each neighboring node ${v}_{j}$ with respect to node ${v}_{i}$ , formulated as:

$$
{\alpha }_{ij} = {f}_{\text{LeakyReLU }}\left( {{a}^{T}\left\lbrack  {W{\mathcal{F}}_{i}\parallel W{\mathcal{F}}_{j}}\right\rbrack  }\right) , \tag{28}
$$

where ${\alpha }_{ij}$ is the attention score, $W$ is a learnable weight matrix, $\parallel$ denotes concatenation, $a$ is a shared learnable weight vector, and ${f}_{\text{LeakyReLU }}$ is a leaky ReLU activation function. Normalized attention weights are obtained using a softmax function:

$$
{\beta }_{ij} = \frac{\exp \left( {\alpha }_{ij}\right) }{\mathop{\sum }\limits_{{k \in  {\mathcal{N}}_{i}}}\exp \left( {\alpha }_{ik}\right) }, \tag{29}
$$

where ${\mathcal{N}}_{i}$ is the set of neighbors of ${v}_{i}$ , and ${\beta }_{ij}$ is the normalized attention weight for neighbor ${v}_{j}$ . GAT aggregates information from neighbors using the attention weights:

$$
{\mathcal{F}}_{i}^{\prime } = \sigma \left( {\mathop{\sum }\limits_{{j \in  {\mathcal{N}}_{i}}}{\beta }_{ij}W{\mathcal{F}}_{j}}\right) , \tag{30}
$$

where $\sigma$ is an activation function (e.g., ReLU), and ${\mathcal{F}}_{i}^{\prime }$ is the updated feature vector for node ${v}_{i}$ .

To capture diverse neighborhood relationships, GAT uses multiple attention heads. Outputs from all heads are concatenated and passed through a learnable weight matrix:

$$
{\mathcal{F}}_{i}^{\prime \prime } = \left( {{\mathcal{F}}_{i}^{\prime \left( 1\right) }\left| \right| {\mathcal{F}}_{i}^{\prime \left( 2\right) }\left| \right| \cdots \parallel {\mathcal{F}}_{i}^{\prime \left( \mathcal{K}\right) }}\right) {W}^{\prime }, \tag{31}
$$

where ${\mathcal{F}}_{i}^{\prime \left( k\right) }$ is the output of the $k$ -th attention head, $\mathcal{K}$ is the number of heads, and || denotes concatenation.

GATs allocate attention within scene graphs, enabling precise object detection and tracking. They are applied to detect license plate numbers in urban environments [107], track pedestrians for traffic safety [108], enhance semantic segmentation, anomaly detection, traffic flow analysis, and improve classification accuracy in complex traffic scenes [109].

![bo_d2839q77aajc738ors5g_16_129_199_1472_835_0.jpg](images/bo_d2839q77aajc738ors5g_16_129_199_1472_835_0.jpg)

FIGURE 9. GIN procedure for traffic scene matching: The process begins with “Dataset Preprocessing,” where traffic datasets are converted into road scene graphs via a graph prediction module. This step involves cleaning, filtering, and transforming raw traffic data into a structured format suitable for graph construction. Concurrently, "Query Preprocessing" processes a traffic scene query through "Actor" and "Map Components" clusters, forming a scene graph of the specific road described in the input query. This involves identifying and classifying key elements of the traffic scene, such as vehicles, pedestrians, and road features. These preprocessed graphs are then used to construct the “Input Graph” (Graphx) and the “Isomorphic Matching Subgraph” (Graphy). Graph ${}_{\chi }$ represents the overall dataset graph, while Graphy is a subgraph extracted to match the query. The procedure culminates in the “Results,” where matched road scenes are displayed. This final step leverages the GIN to ensure precise matching and accurate representation of road scenes from diverse datasets, providing practitioners with reliable scene matches for analysis and decision-making.

APSEGAT [107] efficiently detects license plate numbers in crowded urban environments with diverse vehicles and complex scenes. It achieves a superior F-Score of ${90}\%$ compared to YOLO’s 86% on the AMLPR dataset.

The GAM tracker [108] employs sparse candidate selection, graph attention maps, and distance matching loss for pedestrian tracking, achieving 94.99% MOTA on the Pets-mf dataset. It addresses pedestrian safety challenges and supports traffic statistics and abnormal behavior analysis in intelligent transportation systems.

SCENE [109] leverages heterogeneous GNNs and graph convolutions to encode diverse traffic scenarios, achieving 91.17 accuracy in binary node classification tasks on a custom large-scale dataset ("GAT_SCENE") with 22,400 sequences, each containing 3 seconds of temporal history. Performance and transferability are notably enhanced by incorporating edge features into the GAT operator.

GATs enhance GCNs by assigning varying importance to neighboring nodes via an attention mechanism for more nuanced relationship modeling. However, this mechanism is computationally expensive on large graphs, prone to overfitting when focusing on a few nodes, and struggles to capture long-range dependencies due to its local application.

## 3) GIN

GIN, introduced in [110], is a GNN designed to process graph-structured data by effectively capturing intricate graph topology. It enhances node representations by considering both a node's features and its neighbors' contributions, enabling precise structural differentiation and identifying subtle graph differences.

Figure 9 illustrates the GIN procedure for matching traffic scenes. Let ${\mathcal{F}}_{v}^{\left( 0\right) }$ represent the initial feature vector of node $v$ . GIN begins by aggregating information from neighboring nodes and combining it with the node's own features. The aggregation employs an MLP, a fully connected neural network with multiple layers. The updated node representations are computed using the function ${f}_{\mathrm{{MLP}}}$ as follows:

$$
{\mathcal{F}}_{v}^{\left( l\right) } = {f}_{\mathrm{{MLP}}}\left( {\left( {1 + {\epsilon }^{\left( l\right) }}\right)  \cdot  {\mathcal{F}}_{v}^{\left( l - 1\right) } + \mathop{\sum }\limits_{{u \in  \mathcal{N}\left( v\right) }}{\mathcal{F}}_{u}^{\left( l - 1\right) }}\right) , \tag{32}
$$

where $\mathcal{N}\left( v\right)$ represents the neighbors of node $v,{\epsilon }^{\left( l\right) }$ is a learnable parameter, and ${\mathcal{F}}_{v}^{\left( l\right) }$ is the representation of node $v$ at layer $l$ after being processed by the function ${f}_{\mathrm{{MLP}}}$ .

In some cases, a readout function aggregates node-level information to obtain graph-level embeddings. For example, graph-level embedding ${\mathcal{F}}_{\text{graph }}$ could be computed as the sum of all node embeddings:

$$
{\mathcal{F}}_{\text{graph }} = \mathop{\sum }\limits_{v}{\mathcal{F}}_{v}^{\left( L\right) } \tag{33}
$$

where $L$ is the number of GIN layers.

GIN iteratively updates node representations using their own features and those of neighboring nodes. A learnable parameter ${\epsilon }^{\left( l\right) }$ distinguishes between a node’s own features and its neighbors', enabling GIN to capture complex graph structures. This is particularly effective for graph classification tasks where topology is crucial.

GINs are widely applied in traffic scene understanding, including road scene-graph embedding [111], vehicle and pedestrian path prediction [112], traffic scene retrieval [113], automatic scenario detection [114], and real-time pedestrian path prediction [115].

Roadscene2vec [111] uses GCNs, GINs, and CNNs to enhance road scene-graph analysis for spatial modeling, graph learning, and risk assessment. For collision prediction, it achieves ${88.12}\%$ (GCN), ${80.28}\%$ (GIN), and 70.39% (ResNet-50) on 271-syn, and 90.95%, 78.03%, and 80.80%, respectively, on 1043-syn. For subjective risk assessment, evaluating perceived driver risk, it achieves 93.20% (GCN), 85.61% (GIN), and 69.38% (ResNet-50) on 271-syn, and ${95.80}\% ,{87.84}\%$ , and ${90.53}\%$ , respectively, on 1043-syn.

Pishgu [112] introduces a lightweight network combining GINs with attention mechanisms for path prediction. It improves ADE/FDE by up to ${42}\% /{61}\%$ for vehicles (bird’s-eye view) and ${23}\% /{22}\%$ for pedestrians (high-angle view). Tested on the ActEV/VIRAT dataset, it achieves ADE and FDE scores of 14.11 and 27.96, making it a key resource for CyberPhysical Systems (CPS) applications.

RSG-Search [113] is a graph-based traffic scene retrieval system using sub-graph isomorphic searching for actor configurations and semantic relationships. It ensures dataset compatibility (e.g., nuScenes, NEDO), achieving full accuracy with low matching times (0-2 seconds). The RSG dataset includes 500 traffic scenes, 200,000 topological graphs, 6 node types (e.g., vehicle, pedestrian), and 25 relationship categories (e.g., 'passing-by', 'waiting-for').

The study in [114] presents expert-knowledge-aided representation learning for traffic scenarios using GIN and an automatic mining strategy. It enables effective clustering and novel scenario detection without manual labeling, achieving an AUC of ${99.1}\%$ on a dataset simulated with OpenStreetMap.

CARPe [115] introduces a real-time pedestrian path prediction approach by combining GINs with an agile convolutional NN design. It achieves impressive results with an ADE of 0.80 and FDE of 1.48 on the ETH dataset, significantly improving speed and accuracy for applications such as autonomous vehicles and environmental monitoring.

GINs excel at distinguishing graph structures by capturing subtle differences between nodes and edges, making them effective for graph classification. However, they are prone to overfitting with limited data, requiring careful hyperpa-rameter tuning. GINs also face scalability and efficiency challenges on large or complex graphs due to their depth and computational demands.

## G. CapsNet

CapsNet, introduced in [116], addresses CNN limitations by effectively handling spatial hierarchies between simple and complex objects. It encapsulates feature information (e.g., pose, texture, deformation) into neuron groups called "capsules," which use dynamic routing for enhanced feature representation and recognition. A capsule's activity vector represents the instantiation parameters of an entity (e.g., object or part), with its length indicating the probability of the entity's presence in the input.

To ensure the output vector of a capsule is a small-length vector if the probability of the entity being present is low and a long-length vector if it is high, a squashing function is used. It is typically defined as:

$$
{\mathrm{v}}_{j} = \frac{{\begin{Vmatrix}{\mathrm{s}}_{j}\end{Vmatrix}}^{2}}{1 + {\begin{Vmatrix}{\mathrm{s}}_{j}\end{Vmatrix}}^{2}}\frac{{\mathrm{s}}_{j}}{\begin{Vmatrix}{\mathrm{s}}_{j}\end{Vmatrix}}, \tag{34}
$$

where ${\mathrm{s}}_{j}$ is the total input into the $j$ -th capsule, and $\parallel  \cdot$ ${\left| \right| }_{1}$ denotes the L1 norm or length of a vector. This function ensures that the length of ${v}_{j}$ is between 0 and 1, thus representing a probability.

Dynamic routing allows a capsule to send its output to parent capsules in the next layer based on prediction agreement. Each lower-layer capsule predicts the output of higher-layer capsules using a transformation matrix ${W}_{ij}$ , expressed as ${\widehat{\mathrm{u}}}_{j \mid  i} = {W}_{ij}{\mathrm{u}}_{i}$ , where ${\mathrm{u}}_{i}$ is the output of the $i$ - th lower-layer capsule, and ${\widehat{\mathrm{u}}}_{j \mid  i}$ is the prediction for the $j$ -th higher-layer capsule.

Capsules send outputs to parent capsules based on "routing by agreement," measured by the scalar product between the prediction vector and the parent's output vector. The coupling coefficients ${c}_{ij}$ are then updated based on the agreement and are defined by a softmax function over the initial logits ${b}_{ij}$ :

$$
{c}_{ij} = \frac{\exp \left( {b}_{ij}\right) }{\mathop{\sum }\limits_{k}\exp \left( {b}_{ik}\right) }. \tag{35}
$$

The total input ${\mathrm{s}}_{j}$ to the $j$ -th capsule is calculated as follows. It is a weighted sum of the predicted outputs:

$$
{\mathrm{s}}_{j} = \mathop{\sum }\limits_{i}{c}_{ij}{\widehat{\mathrm{u}}}_{j \mid  i} \tag{36}
$$

Algorithm 1 shows the dynamic routing procedure to train the coupling coefficients ${c}_{ij}$ between each $i$ -th primary and $j$ -th output capsule [116].

![bo_d2839q77aajc738ors5g_18_113_187_1487_431_0.jpg](images/bo_d2839q77aajc738ors5g_18_113_187_1487_431_0.jpg)

FIGURE 10. Traffic scene classification with CapsNet: The input image is first processed through a ReLU convolution layer, followed by 32 primary capsules (’PrimaryCaps’). Capsules, fundamental units of CapsNets, encapsulate feature information like pose and texture, with the length of each capsule’s output vector representing the entity’s presence probability. These primary capsules are linked to 8 traffic capsules (‘TrafficCaps’) via weight matrices ${W}_{ii}$ , and dynamic routing is applied to selectively send outputs based on agreement. The length of each TrafficCaps vector, constrained by a squashing function to be between 0 and 1, influences the classification loss. $\left| \right| {L}_{2}\left| \right|$ normalization further enhances categorization, ensuring robust classification of traffic elements like police cars and pedestrians.

Algorithm 1 Routing Algorithm to Train the Coupling Coefficients Between Each Primary and Output Capsule

---

procedure $\operatorname{ROUTING}\left( {{\widehat{u}}_{j} \mid  i, r, l}\right)$

	for all capsule $i$ in layer $l$ and capsule $j$ in layer $\left( {l + 1}\right)$ :

${b}_{ij} \leftarrow  0$

	for $r$ iterations do

		for all capsule $i$ in layer $l : {c}_{i} \leftarrow  \operatorname{softmax}\left( {b}_{i}\right)$

\{softmax computes Equation 35\}

		for all capsule $j$ in layer $\left( {l + 1}\right)  : {s}_{j} \leftarrow  \mathop{\sum }\limits_{i}\left( {{c}_{ij} \cdot  {\widehat{u}}_{j} \mid  i}\right)$

		for all capsule $j$ in layer $\left( {l + 1}\right)  : {v}_{j} \leftarrow  \operatorname{squash}\left( {s}_{j}\right)$

\{squash computes Equation 34\}

		for all capsule $i$ in layer $l$ and capsule $j$ in layer

$\left( {l + 1}\right)  : {b}_{ij} \leftarrow  {b}_{ij} + {\widehat{u}}_{j} \mid  i \cdot  {v}_{j}$

return ${v}_{j}$

---

These equations and the architecture help preserve detailed spatial information and enable the network to better understand the relationships and hierarchies between different parts of the objects.

Figure 10 illustrates the CapsNet procedure for traffic scene classification. The third layer, Traffic Capsules (Traf-ficCaps), contains 8 capsules, each as a 16-dimensional vector, fully connected to the previous layer's capsules. Dynamic routing ensures layer communication, while a squashing function bounds output vector lengths between 0 and 1 , indicating entity presence probabilities. Weight matrices ${W}_{ij}$ classify features into 8 traffic object classes.

CapsNets outperform traditional CNNs in robustness and generalization, excelling at capturing spatial relationships and complex interactions in traffic scenes, such as congested intersections. Applications include traffic sign detection [117], highway scene segmentation [118], and complex scenario recognition [119], offering deeper and more reliable insights into dynamic road environments.

TSDCaps [117] addresses CNN limitations for traffic sign detection, achieving ${97.6}\%$ accuracy on the GTSRB dataset. It improves feature extraction, enhances reliability, and demonstrates resistance to adversarial attacks, making it well-suited for autonomous vehicle applications.

A scene segmentation model in [118], trained on Auckland Highway Images (AHI), achieves 74.61% accuracy. It enhances scene comprehension using matrix representations for pose and spatial relationships, reduces manual data manipulation, and addresses the challenging Picasso problem.

The authors of [119] proposed "ImprovedCaps," a two-step approach for complex scenes. It enhances traffic sign features through image processing before applying CapsNet for recognition, improving GTSRB accuracy by 2%- 5% in complex scenarios and achieving 96% overall accuracy.

In [120], "LiuCaps" is introduced for traffic-light sign recognition in autonomous vehicles. Trained on the TL_Dataset, it achieves 98.72% accuracy and a 99.27% F1-score, outperforming traditional CNNs while reducing training data needs and improving spatial relationship handling.

CapsNets excel at capturing spatial hierarchies and pose relationships, providing detailed object structure understanding compared to CNNs. However, they are computationally intensive, memory-demanding, and challenging to train, requiring complex optimization. Their limited scalability and efficiency on large datasets hinder adoption in resource-critical, large-scale applications.

### H.HPO FOR DISCRIMINATIVE DL ARCHITECTURES

HPO optimizes model architecture and parameters like learning rate, network structure, and regularization, enhancing accuracy, generalization, and efficiency across datasets. Fine-tuning learning rates, anchor box dimensions (R-CNN, YOLO), and architectures (DETR, ViT) improves performance and pixel-level accuracy. In graph learning, tuning GCN layers and node features enhances spatial and structural relationship capture, improving predictions. Techniques like dropout, early stopping, and batch size optimization combat overfitting and computational constraints, while task-specific tuning strengthens multitask learning and temporal modeling for traffic scene understanding.

The learning rate controls weight updates: higher rates accelerate training but risk instability; lower rates improve precision but slow convergence. Batch size affects stability and memory: larger sizes enhance stability; smaller ones improve generalization. Epochs determine dataset passes: more epochs improve learning but risk overfitting, while fewer reduce training time but may underfit. Momentum accelerates training by smoothing updates, reducing oscillations, and avoiding local minima; higher momentum speeds convergence but risks overshooting, while lower momentum ensures stability. Weight decay (L2 regularization) prevents overfitting by penalizing large weights, promoting simpler models: higher values reduce overfitting but may underfit, while lower values allow flexibility but risk overfitting. Anchor scale adjusts predefined box sizes in object detection: larger scales improve the detection of big objects, while smaller scales enhance accuracy for small objects.

In the reviewed Fast R-CNN models, [22] used SGD with mini-batches of 2 images, 128 RoIs, a learning rate of 0.001 decayed after ${30}\mathrm{k}$ iterations, momentum of 0.9, and weight decay of 0.0005 . Reference [26] employed a 0.001 learning rate, batch size of 128 , and trained for 100 epochs.

For Faster R-CNN,[34] modified anchor scales $\left( {{80}^{2},{112}^{2}}\right.$ , ${144}^{2}$ ) and aspect ratios(0.4,0.8,2.5), maintaining nine anchors per position. Reference [28] used a learning rate of 0.001 , batch size of 32, 100 epochs, momentum of 0.9 , and weight decay of 0.0005 .

In Mask R-CNN, [51] set the learning rate to 0.02 , weight decay to 0.0001, momentum to 0.9, batch size of 16, and trained for ${900}\mathrm{\;k}$ iterations. Reference [57] used a learning rate of 0.001 , batch size of 1 , and trained for 50 epochs.

For YOLO models, [121] used a learning rate of 0.001 decayed by 0.1 per epoch, momentum of 0.9 , weight decay of 0.0005, 8000 max_batches, and batch size of 32 . Reference [122] used a learning rate of 0.01 , final rate of 0.2 , momentum of 0.937, weight decay of 0.0005, 110 epochs, and batch size of 12. Reference [123] utilized a learning rate of 0.0002, Adam optimizer with ${\beta 1} = {0.5},{\beta 2} = {0.999}$ , and batch size of 32 .

Among ViT models,[89] used ${16} \times  {16}$ patches, 768 embedding dimension, 12 layers, 12 attention heads, Adam optimizer with a 0.001 learning rate, and 100 epochs. Reference [91] used ${32} \times  {32}$ patches,12 attention heads, 768 embedding dimension, and Rectified Adam, training for up to 1000 epochs with early stopping. Reference [92] used ${16} \times  {16}$ patches, 6 layers, 8 attention heads, and trained with a 0.0002 learning rate over 80 epochs.

For DETR models, [94] used ResNet-50/101 backbones, a transformer with 6 encoder/decoder layers, 256 hidden dimensions,8 attention heads, AdamW optimizer with ${10}^{-4}$ learning rate, batch size of 16 , and 300 epochs. Reference [95] used ResNet-50, AdamW optimizer, 0.0001 learning rate, batch size of 4,300 query positions, and data augmentation. Reference [96] used ResNet-50, AdamW, ${10}^{-4}$ learning rate, batch size of 8, adjusted rates on plateau, and data augmentation. Reference [97] used ResNet-50, AdamW, ${10}^{-4}$ learning rate, batch size of 32, and 50 epochs with scheduled rate reductions.

## I. COMPARISON OF DISCRIMINATIVE DL ARCHITECTURES

Here's a shorter version that retains all the key information:

Table 2 compares various discriminative DL architectures. In classification, models are evaluated by overall accuracy for traffic scene recognition tasks. The Receptive Field NN [6], an early DL application for road sign classification, achieved a modest ${47.7}\%$ accuracy on a custom dataset ("RFNN_TSR"), illustrating early limitations. More recent CNN-based methods, like 2LConvNet ms 108-108 [7], and CapsNet methods, such as LiuCaps [120], reached 97.83% and ${98.72}\%$ accuracy, respectively, on another traffic sign dataset.

For object detection, Table 2 highlights performance improvements of Fast R-CNN over standard R-CNN, with AllLightRCNN [32] achieving 94.20% mean accuracy ("All-LightRCNN_DS"), a 16.4% gain over R-CNN's 65.76% mAP ("RCNNs_Detection"). Mask R-CNN and Faster R-CNN achieved mAPs of 74.30% and 76.30% [57]. Faster R-CNN models on COCO 2017 achieved AP scores from 40.2% to 44.0%, with Faster R-CNN-FPN-R101+ (108 epochs) [97] obtaining the highest AP of ${44.0}\%$ . The YOLO family (YOLOv1 to YOLOv8) showed strong results, with YOLOv7 [73] achieving 98.77% AP ("ShokriCollec-tion_DS") for real-time vehicle detection. YOLOv3 [84] performed well on the PSU dataset for aerial traffic object detection, achieving ${96.5}\%$ AP, outperforming Faster R-CNN’s 73.9%. DETR models also excelled on COCO- 2017, with SMCA-R50 (108 epochs) [97] achieving an AP of 45.6%, surpassing Faster R-CNN by 1.6%. Results from YOLO and DETR demonstrate their state-of-the-art performance, unifying bounding box prediction and classification in a single step.

Here's a shorter version that preserves all key details:

For segmentation tasks, the CNN-based SNE-RoadSeg [8] achieved 98.6% accuracy on the R2D dataset, demonstrating high performance for road segmentation. Real-world applications include flood segmentation, where Mask R-CNN [52] achieved 93.0% accuracy on the IDRF dataset [58]. CapsNet-based methods, like U-Net [118], achieved an IoU of ${74.61}\%$ on the AHI dataset for vehicle-related scene segmentation, benefiting from capsules' ability to preserve spatial hierarchies for robust segmentation.

In traffic action recognition, CNN-based methods achieved modest results, with CPM [102] reaching 63.98% accuracy on the TPGR dataset. GCN-based models, such as Pose GCN [102] and ST-GCN [101], significantly outperformed CNNs with accuracies of 87.72% and 97.52%, respectively, due to their ability to capture spatial-temporal relationships and structural representations.

TABLE 2. Comparison of discriminative DL models for traffic scene understanding across applications, frameworks, datasets, metrics, and results.

<table><tr><td>Application</td><td>Framework</td><td>Variance</td><td>Dataset</td><td>Performance Metric</td><td>Result</td></tr><tr><td rowspan="11">Classification</td><td>Vanilla CNN</td><td>Receptive Field NN [6]</td><td>RFNN_TSR</td><td>Accuracy</td><td>47.7%</td></tr><tr><td>Multi-scale CNN</td><td>2LConvNet ms 108-108 [7]</td><td>TL_Dataset</td><td>Accuracy</td><td>97.83%</td></tr><tr><td>CNN</td><td>ResNet-50 [111]</td><td>1043-syn</td><td>Accuracy</td><td>90.53%</td></tr><tr><td>GCN</td><td>MR-GCN [100]</td><td>KITTI</td><td>Accuracy</td><td>89%</td></tr><tr><td>GCN</td><td>HetEdgeGCN [109]</td><td>GAT_SCENE</td><td>Accuracy</td><td>93.54%</td></tr><tr><td>GCN</td><td>HetEdgeGatedGCN [109]</td><td>GAT_SCENE</td><td>Accuracy</td><td>90.09%</td></tr><tr><td>GCN</td><td>MRGCN [111]</td><td>1043-syn</td><td>Accuracy</td><td>95.80%</td></tr><tr><td>GAT</td><td>HetEdgeGAT [109]</td><td>GAT_SCENE</td><td>Accuracy</td><td>94.29%</td></tr><tr><td>GIN</td><td>MRGIN [111]</td><td>1043-syn</td><td>Accuracy</td><td>87.84%</td></tr><tr><td>CapsNet</td><td>ImprovedCaps [119]</td><td>GTSRB</td><td>Accuracy</td><td>96%</td></tr><tr><td>CapsNet</td><td>LiuCaps [120]</td><td>TL_Dataset</td><td>Accuracy</td><td>98.72%</td></tr><tr><td rowspan="40">Object Detection</td><td>CNN</td><td>ResNet50 [57]</td><td>RCNNs_Detection</td><td>mAP</td><td>65.76%</td></tr><tr><td>R-CNN</td><td>VGG16 [10]</td><td>VOC2007</td><td>mAP</td><td>66.0%</td></tr><tr><td>R-CNN</td><td>ZF, VGG16 [32]</td><td>AllLightRCNN_DS</td><td>Mean Accuracy</td><td>77.8%</td></tr><tr><td>Fast R-CNN</td><td>AllLightRCNN [32]</td><td>AllLightRCNN_DS</td><td>Mean Accuracy</td><td>94.20%</td></tr><tr><td>Mask R-CNN</td><td>ME Mask R-CNN [54]</td><td>TrainObstacle</td><td>mAP</td><td>91.3%</td></tr><tr><td>Mask R-CNN</td><td>Mask R-CNN [57]</td><td>RCNNs_Detection</td><td>mAP</td><td>74.30%</td></tr><tr><td>Faster R-CNN</td><td>Faster R-CNN [57]</td><td>RCNNs_Detection</td><td>mAP</td><td>76.30%</td></tr><tr><td>Faster R-CNN</td><td>ResNet-50 [73]</td><td>ShokriCollection_DS</td><td>AP</td><td>54.69%</td></tr><tr><td>Faster R-CNN</td><td>Inception v2 [84]</td><td>PSU</td><td>AP</td><td>73.9%</td></tr><tr><td>Faster R-CNN</td><td>Faster R-CNN-FPN-R50 (36 epochs) [97]</td><td>COCO 2017</td><td>AP</td><td>40.2%</td></tr><tr><td>Faster R-CNN</td><td>Faster R-CNN-FPN-R50++ (108 epochs) [97]</td><td>COCO 2017</td><td>AP</td><td>42.0%</td></tr><tr><td>Faster R-CNN</td><td>Faster R-CNN-FPN-R101 (36 epochs) [97]</td><td>COCO 2017</td><td>AP</td><td>42.0%</td></tr><tr><td>Faster R-CNN</td><td>Faster R-CNN-FPN-R101+ (108 epochs) [97]</td><td>COCO 2017</td><td>AP</td><td>44.0%</td></tr><tr><td>YOLOv1</td><td>A custom CNN [63]</td><td>LISA-dayTrain</td><td>AUC</td><td>58.3%</td></tr><tr><td>YOLOv2</td><td>Darknet-19 [63]</td><td>LISA-dayTrain</td><td>AUC</td><td>60.05%</td></tr><tr><td>YOLOv3</td><td>Darknet-53 [63]</td><td>LISA-dayTrain</td><td>AUC</td><td>90.49%</td></tr><tr><td>YOLOv3</td><td>Darknet-53 [84]</td><td>PSU</td><td>AP</td><td>96.5%</td></tr><tr><td>YOLOv4</td><td>CSPDarknet53-PANet-SPP [84]</td><td>PSU</td><td>AP</td><td>96.5%</td></tr><tr><td>YOLOv5</td><td>modified CSPDarknet53 [73]</td><td>ShokriCollection_DS</td><td>AP</td><td>93.85%</td></tr><tr><td>YOLOv6</td><td>EfficientRep [73]</td><td>ShokriCollection_DS</td><td>AP</td><td>92.95%</td></tr><tr><td>YOLOv7</td><td>No pretrained backbone [73]</td><td>ShokriCollection_DS</td><td>AP</td><td>98.77%</td></tr><tr><td>YOLOv8</td><td>A CSPDarknet variant [73]</td><td>ShokriCollection_DS</td><td>AP</td><td>91.23%</td></tr><tr><td>ViT</td><td>Vanilla ViT [89]</td><td>ViT_DS</td><td>F1-score</td><td>92.10%</td></tr><tr><td>ViT</td><td>ViT-SSA [89]</td><td>ViT DS</td><td>F1-score</td><td>98.07%</td></tr><tr><td>ViT</td><td>ViT-TA [91]</td><td>DAD</td><td>F1-score</td><td>94%</td></tr><tr><td>DETR</td><td>DSRA-DETR [95]</td><td>CCTSDB</td><td>AP</td><td>78.24%</td></tr><tr><td>DETR</td><td>MTSDet [96]</td><td>CTSD</td><td>mAP</td><td>94.3%</td></tr><tr><td>DETR</td><td>DETR-R50 (500 epochs) [97]</td><td>COCO 2017</td><td>AP</td><td>42.0%</td></tr><tr><td>DETR</td><td>DETR-DC5-R50 (500 epochs) [97]</td><td>COCO 2017</td><td>AP</td><td>43.3%</td></tr><tr><td>DETR</td><td>Deformable DETR-R50, Single-scale [97]</td><td>COCO 2017</td><td>AP</td><td>39.7%</td></tr><tr><td>DETR</td><td>Deformable DETR-R50 (150 epochs) [97]</td><td>COCO 2017</td><td>AP</td><td>45.3%</td></tr><tr><td>DETR</td><td>UP-DETR-R50 (150 epochs) [97]</td><td>COCO 2017</td><td>AP</td><td>40.5%</td></tr><tr><td>DETR</td><td>UP-DETR-R50+ (300 epochs) [97]</td><td>COCO 2017</td><td>AP</td><td>42.8%</td></tr><tr><td>DETR</td><td>SMCA-R50 (108 epochs) [97]</td><td>COCO 2017</td><td>AP</td><td>45.6%</td></tr><tr><td>DETR</td><td>DETR-R101 (500 epochs) [97]</td><td>COCO 2017</td><td>AP</td><td>43.5%</td></tr><tr><td>DETR</td><td>DETR-DC5-R101 (500 epochs) [97]</td><td>COCO 2017</td><td>AP</td><td>44.9%</td></tr><tr><td>DETR</td><td>SMCA-R101 (50 epochs) [97]</td><td>COCO 2017</td><td>AP</td><td>44.4%</td></tr><tr><td>DETR</td><td>DetectFormer [98]</td><td>BCTSDB</td><td>AP75</td><td>91.4%</td></tr><tr><td>GAT</td><td>APSEGAT [107]</td><td>AMLPR</td><td>F-Score</td><td>90%</td></tr><tr><td>CapsNet</td><td>TSDCaps [117]</td><td>GTSRB</td><td>Accuracy</td><td>97.62%</td></tr><tr><td rowspan="3">Segmentation</td><td>CNN</td><td>SNE-RoadSeg [8]</td><td>R2D</td><td>Accuracy</td><td>98.6%</td></tr><tr><td>Mask-R-CNN</td><td>Mask-R-CNN [52]</td><td>IDRF [58]</td><td>accuracy</td><td>93.0%</td></tr><tr><td>CapsNet</td><td>U-Net [118]</td><td>AHI</td><td>IoU</td><td>74.61%</td></tr><tr><td rowspan="6">Action Recognition</td><td>CNN</td><td>CPM [102]</td><td>TPGR</td><td>Accuracy</td><td>63.98%</td></tr><tr><td>ViT</td><td>Action-ViT [90]</td><td>JAAD</td><td>F1-score</td><td>90.2%</td></tr><tr><td>GCN</td><td>ST-GCN [101]</td><td>CTPG</td><td>Accuracy</td><td>87.72%</td></tr><tr><td>GCN</td><td>Pose GCN [102]</td><td>TPGR</td><td>Accuracy</td><td>97.52%</td></tr><tr><td>GCN</td><td>OpenPose [103]</td><td>TPGR</td><td>Accuracy</td><td>87.72%</td></tr><tr><td>GCN</td><td>DA-GCN [104]</td><td>TPGR</td><td>Accuracy</td><td>94.70%</td></tr><tr><td rowspan="2">Object Tracking</td><td>YOLOv3</td><td>Deep SORT [108]</td><td>Pets-mf</td><td>MOTA</td><td>92.08%</td></tr><tr><td>GAT</td><td>GAM tracker [108]</td><td>Pets-mf</td><td>MOTA</td><td>94.99%</td></tr><tr><td rowspan="2">Path Prediction</td><td>GIN</td><td>Pishgu [112]</td><td>ActEV/VIRAT</td><td>ADE, FDE</td><td>14.11, 27.96</td></tr><tr><td>GIN</td><td>CARPe [115]</td><td>ETH</td><td>ADE, FDE</td><td>0.80,1.48</td></tr><tr><td rowspan="3">Scene Retrieval</td><td>GIN</td><td>VF2 Without Optimization [113]</td><td>RSG</td><td>Matching Time (s)</td><td>0-5,000</td></tr><tr><td>GIN</td><td>VF2 With Optimization [113]</td><td>RSG</td><td>Matching Time (s)</td><td>0-2.5</td></tr><tr><td>GIN</td><td>GNN-based Matching [113]</td><td>RSG</td><td>Matching Time (s)</td><td>0-2.0</td></tr><tr><td rowspan="2">Novel Scenario Detection</td><td>ViT</td><td>ViT-L [92]</td><td>Wurst_DS [93]</td><td>AUC</td><td>95.6%</td></tr><tr><td>GIN</td><td>Expert-LaSTS [114]</td><td>OpenStreetMap</td><td>AUC</td><td>99.1%</td></tr></table>

For object tracking, Deep SORT with YOLOv3 [108] achieved a MOTA of 92.08% on the Pets-mf dataset, while the GAM tracker [108] improved MOTA to 94.99%, demonstrating the impact of attention mechanisms. In scene retrieval, GIN-based models like VF2 and GNN-based Matching [113] achieved complete accuracy with retrieval times of 0-2 seconds. For novel scenario detection, ViT-L [92] and Expert-LaSTS [114] achieved AUCs of 95.6% and ${99.1}\%$ , respectively, effectively identifying unusual traffic scenarios.

## IV. GENERATIVE MACHINE LEARNING MODELS

Generative machine learning models are growing increasingly integral in advancing DL for traffic scene understanding. Unlike discriminative models that differentiate between distinct entities, generative models excel in generating new data instances that mimic real-world scenarios. These models are adept at creating realistic images and simulations that can be invaluable in traffic scene analysis.

In traffic scene understanding, generative models find applications in synthesizing diverse and complex traffic scenarios for training and evaluation purposes. They can generate varied environmental conditions, and lighting variations, including rare traffic occurrences, offering a robust and comprehensive dataset for training discriminative models. This enhances the ability of DNNs to interpret and respond accurately to dynamic traffic situations. Additionally, generative models can be used in anomaly detection, where they help identify unusual or hazardous traffic conditions by contrasting them with the normative patterns they have learned.

The following sections discuss generative ML models shaping traffic scene understanding, from basic GANs to complex hybrids blending generative and discriminative techniques. These models address data generation, realism enhancement, and scenario simulation, advancing DL in intelligent transportation systems. Additionally, we explore HPO for these architectures and evaluate their performance metrics, offering a comprehensive overview.

## A. GAN

A GAN, as introduced first in [124], consists of two NNs, a generator and a discriminator, which are trained simultaneously through adversarial training. The generator creates new data instances that resemble a given dataset, while the discriminator evaluates them for authenticity. This process leads the generator to produce increasingly realistic data samples.

Figure 11 illustrates the training process of a GAN for application to a traffic scene understanding problem. The generator (G) creates fake data samples from random noise. It can be represented as a function $G : z \rightarrow  \widehat{x}$ , where $z$ is a random noise vector sampled from a simple probability distribution (like a Gaussian distribution), and $\widehat{x}$ is the generated data.

The discriminator (D) evaluates the authenticity of a given data sample, determining whether it is real (from the actual dataset) or fake (generated by the generator). It can be represented as a function $D : x \rightarrow  \left\lbrack  {0,1}\right\rbrack$ , where $x$ is a data sample. $D\left( x\right)$ represents the probability that $x$ comes from the real dataset (output close to 1) rather than being generated (output close to 0 ).

The training objective of a GAN is to minimize the following value function, also known as the minimax loss:

$$
\mathop{\min }\limits_{G}\mathop{\max }\limits_{D}V\left( {D, G}\right)  = {\mathbb{E}}_{x \sim  {p}_{\text{data }}\left( x\right) }\left\lbrack  {\log D\left( x\right) }\right\rbrack
$$

$$
+ {\mathbb{E}}_{z \sim  {p}_{z}\left( z\right) }\left\lbrack  {\log \left( {1 - D\left( {G\left( z\right) }\right) }\right) }\right\rbrack  , \tag{37}
$$

where ${\mathbb{E}}_{x \sim  {p}_{\text{data }}\left( x\right) }\left\lbrack  {\log D\left( x\right) }\right\rbrack$ represents the expected value of the log-probability that the discriminator correctly classifies real data, and ${\mathbb{E}}_{z \sim  {p}_{z}\left( z\right) }\left\lbrack  {\log \left( {1 - D\left( {G\left( z\right) }\right) }\right) }\right\rbrack$ represents the expected value of the log-probability that the discriminator correctly classifies generated data as fake.

This objective creates a dynamic similar to a tug-of-war between the generator and the discriminator. The generator aims to minimize this objective, while the discriminator seeks to maximize it.

In the training process, the generator and discriminator are updated iteratively. The generator learns to produce more realistic data to fool the discriminator, while the discriminator improves its ability to differentiate between real and fake data.

This adversarial process continues until the generated data is indistinguishable from real data, or until a stopping criterion is met.

GANs are utilized for spatio-temporal traffic state reconstruction [125], enhancing video frame predictions [126] and aiding semantic segmentation [127] for autonomous vehicles, augmenting training data for rare events [128], synthesizing soiling on fisheye camera images [129], improving highway traffic images [130] and road segmentation [131] in adverse weather, and augmenting data to improve classifier generalization [132].

SoPhie [133], an innovative framework based on GAN, addresses the vital task of path prediction for interacting agents in autonomous scenarios by seamlessly integrating physical and social information through a novel combination of social and physical attention mechanisms, achieving remarkable ADE and FDE scores of 0.70 and 1.43, respectively on the ETH dataset and setting a new standard in trajectory forecasting benchmarks for self-driving cars applications.

Peak Signal to Noise Ratio (PSNR) and Structural Similarity Index (SSIM) are fundamental metrics extensively used in the field of image and video quality assessment. These metrics are crucial for quantifying the fidelity and visual quality of images and videos by comparing them to original, uncompressed, or distortion-free versions.

![bo_d2839q77aajc738ors5g_22_417_197_865_616_0.jpg](images/bo_d2839q77aajc738ors5g_22_417_197_865_616_0.jpg)

FIGURE 11. the training process of a GAN for application to a traffic scene understanding problem: The generator (G) creates synthetic traffic scenes from a random noise vector $z$ , sampled from a latent distribution such as a Gaussian distribution. This generated scene $\widehat{\mathbf{x}}$ is then evaluated by a discriminator (D), which also receives real samples from the training dataset. The discriminator's task is to classify the samples as 'fake' or 'real' Through this adversarial process, the generator iteratively improves its ability to produce scenes that are indistinguishable from real-world traffic scenes.

The TSR-GAN model proposed in [125] effectively mines and estimates traffic correlations and patterns, setting a new benchmark for spatio-temporal traffic state reconstruction. In comprehensive comparisons, TSR-GAN excels by achieving the highest traffic state similarity (TSS), formulated as ${TSS} = \left( {{PSNR} + {MSSIM} \times  {100}}\right) /2$ , with a score of 32.595. Additionally, it yields the lowest errors, including a root mean square error (RMSE) of 6.585, a mean absolute error (MAE) of 5.205, and a mean absolute percentage error (MAPE) of 8.671%. These results surpass models such as GASM, CED, SRGAN, and its variations, demonstrating TSR-GAN's superior precision and versatility in reconstructing traffic states under diverse conditions.

The study in [126] evaluates the effectiveness of GAN-based enhancement methods, specifically SRGAN [134] and DeblurGAN [135], in refining video frame predictions made by another generative model, FutureGAN [136], to significantly improve object detection for autonomous vehicles, demonstrating a notable $9\%$ increase in AP for car detection with the enhanced frames.

A modified CycleGAN [137] introduced in [128] effectively demonstrates the use of GANs for augmenting training data for rare events in autonomous systems, achieving an improvement in mAP for perception tasks from 44.5% to ${45.5}\%$ . This indicates a credible approach to enhancing the robustness of object detection and scenario classification, while also tackling the issue of training data scarcity and proposing methods to reduce GAN-induced bias. The dataset of this work (referred to as "RareEvents_DS" in our work), collected over two months on California highways, includes 8 hours of driving data, 3959 pixel-wise annotated images, and 600 event-annotated video clips.

The authors in [129] propose two algorithms for soiling synthesis on fisheye camera images. The first is a CycleGAN-based baseline [137], and the second is DirtyGAN. Both algorithms deliver comparable end-to-end results. Dirty-GAN, a GAN-based approach, improves soiling detection by ${18}\%$ and increases the mean IoU (mIoU) to ${91.71}\%$ by training on a combination of real and synthetic images. This approach mitigates semantic segmentation degradation caused by soiled data, eliminates manual annotation costs by automatically generating soiling masks, and introduces the Dirty Cityscapes dataset, leveraging the original Cityscapes dataset.

The study in [130] introduces a highly effective highway traffic image enhancement algorithm for adverse weather conditions, achieving remarkable performance gains of 21.97% and 12.89% in nighttime enhancement, 26.16% and 12.75% in rain removal, and 26.56% and 12.1% in fog removal for PSNR and SSIM metrics respectively, showcasing its superior capability in detail retention and noise reduction.

In [127] (referred to as "MTPanClass" in our work), a model is proposed to refine the segmentation of target main bodies by leveraging the pan-class intrinsic relevance among multiple targets. This approach includes a novel use of generative adversarial learning, which integrates intrinsic relevance features with semantic features to enhance segmentation. MTPanClass achieves mIoU scores of 49.8%, ${64.6}\% ,{76.01}\%$ , and 89.3 $\%$ on the ADE20K, PASCALCon-text, KITTI, and Cityscapes datasets, respectively, demonstrating strong performance and adaptability to complex scene contexts.

IEC-Net, presented in [131], is an image enhancement network based on CycleGAN [137], specifically designed to improve road segmentation under diverse weather conditions. When tested on the Cityscapes dataset under severe weather scenarios, IEC-Net achieved an mIoU of 89.3%, showcasing significant improvements in segmentation accuracy when integrated with state-of-the-art segmentation models.

The AttGAN model proposed in [138] is utilized in [132] to introduce a novel data augmentation approach. This method leverages attribute-conditioned generative models to semantically modify training data, significantly enhancing the generalization capabilities of deep classifiers across varying times of day and weather conditions. Notably, this approach achieved an F1-score of ${86}\%$ on the BDD dataset for Semantic DA when trained using original day images along with synthetic night images.

GANs are highly effective for generating realistic data, including high-quality images and other forms of synthetic content. However, they are notoriously difficult to train, often facing challenges such as instability and mode collapse, where the model produces limited variations of the data. Successful training of GANs requires meticulous tuning of hyperparameters and network architecture, as well as access to large datasets. These factors make GANs computationally intensive and difficult to scale, especially for complex or high-resolution tasks.

## B. cGAN

A cGAN is an extension of the standard GAN that allows for the conditional generation of data based on input labels or information. The cGAN model comprises two neural networks—a generator $G$ and a discriminator $D$ -that are trained simultaneously. The primary difference between cGAN and GAN is that in cGAN, both the generator and discriminator receive additional information $y$ as input, which is often the label or condition for the data generation process.

The generator $G$ takes as input both a random noise vector $z$ and a condition $y$ , and it generates a sample $\widetilde{x} = G\left( {z, y}\right)$ that attempts to resemble the real data conditioned on $y$ .

The discriminator $D$ takes as input both a data sample $x$ (or a generated sample $\widetilde{x}$ ) and the condition $y$ , and it outputs a probability $D\left( {x, y}\right)$ (or $D\left( {\widetilde{x}, y}\right)$ ) that the sample is real (i.e., from the training data) rather than generated by $G$ :

$$
D\left( {x, y}\right)  = P\left( {\operatorname{real} \mid  x, y}\right)  \tag{38}
$$

$$
D\left( {\widetilde{x}, y}\right)  = P\left( {\operatorname{real} \mid  \widetilde{x}, y}\right) . \tag{39}
$$

The objective functions for the generator and discriminator are derived from the original GAN framework but are conditioned on $y$ .

The discriminator tries to maximize the probability of correctly classifying the real data and minimize the probability of incorrectly classifying the generated data. The loss function for the discriminator is:

$$
{\mathcal{L}}_{D} =  - {\mathbb{E}}_{x, y \sim  {p}_{\text{data }}\left( {x, y}\right) }\left\lbrack  {\log D\left( {x, y}\right) }\right\rbrack
$$

$$
- {\mathbb{E}}_{z \sim  {p}_{z}\left( z\right) , y \sim  {p}_{\text{data }}\left( y\right) }\left\lbrack  {\log \left( {1 - D\left( {G\left( {z, y}\right) , y}\right) }\right) }\right\rbrack   \tag{40}
$$

The generator tries to minimize the probability that the discriminator correctly distinguishes between real and generated data. The loss function for the generator is:

$$
{\mathcal{L}}_{G} =  - {\mathbb{E}}_{z \sim  {p}_{z}\left( z\right) , y \sim  {p}_{\text{data }}\left( y\right) }\left\lbrack  {\log D\left( {G\left( {z, y}\right) , y}\right) }\right\rbrack  . \tag{41}
$$

In practice, $G$ and $D$ engage in a minimax game. This is the same as described in Equation 37 for GAN.

The training process alternates between updating the discriminator $D$ by maximizing ${\mathcal{L}}_{D}$ with respect to the parameters of $D$ , and updating the generator $G$ by minimizing ${\mathcal{L}}_{G}$ with respect to the parameters of $G$ .

The introduction of the Two-Stream Conditional Generative Adversarial Network (TScGAN) in [139] significantly improves mIoU scores across various state-of-the-art CNN-based semantic segmentation models, with increases such as 77.2% to 79.0% for DeepLabV3 and 81.6% to 83.6% for HRNet. TScGAN enhances both segmentation accuracy and processing speed by addressing higher-order inconsistencies in semantic segmentation and effectively utilizing dual input streams to preserve high-level contextual information. These improvements are particularly evident when applied to smaller image sizes (e.g., 512 - 512) on datasets like Cityscapes.

## C. VAE

Variational Autoencoders, as introduced in [140], mark a significant advancement in generative modeling by combining deep learning with variational inference. Their core innovation lies in the use of a latent variable model to effectively capture complex data distributions. This approach provides a robust framework for approximating these distributions. VAEs are trained using SGD, which ensures efficient optimization and training. This methodology not only enhances the model's generative capabilities but also aids in uncovering the underlying structure of the data, making VAEs highly versatile in generative modeling tasks.

Figure 12 illustrates the training process of a VAE applied to a traffic scene reconstruction problem. VAEs are based on a latent variable model:

$$
p\left( {x, z}\right)  = p\left( {x \mid  z}\right) p\left( z\right) , \tag{42}
$$

where $x$ is observed data, $z$ is a latent variable, $p\left( z\right)$ is the prior over latent variables, and $p\left( {x \mid  z}\right)$ is the likelihood.

The goal is to infer the posterior distribution $p\left( {z \mid  x}\right)$ , which is typically intractable. VAEs introduce a variational approximation ${q}_{\phi }\left( {z \mid  x}\right)$ to this posterior, where $\phi$ are parameters learned by the model.

![bo_d2839q77aajc738ors5g_24_250_203_1191_380_0.jpg](images/bo_d2839q77aajc738ors5g_24_250_203_1191_380_0.jpg)

FIGURE 12. Training of a VAE for a traffic scene reconstruction: An observed input image $x$ is passed through the encoder ${q}_{\phi }\left( {z \mid  x}\right)$ , which approximates the posterior distribution $p\left( {z \mid  x}\right)$ . The encoder produces the parameters of the latent variable $z$ , specifically the mean ${\mu }_{z \mid  x}$ and covariance ${\sum }_{z \mid  x}$ , representing the latent distribution as $z \sim  \mathcal{N}\left( {{\mu }_{z \mid  x},{\sum }_{z \mid  x}}\right)$ . This latent variable is then used by the decoder ${p}_{\phi }\left( {x \mid  z}\right)$ to generate a reconstructed image $\widehat{x}$ , with the aim to make $\widehat{x}$ as close as possible to the original $\mathbf{x}$ . The training objective involves maximizing the ELBO on the marginal likelihood $\mathbf{p}\left( \mathbf{x}\right)$ , which is composed of a reconstruction loss (to reduce the difference between $x$ and $\widehat{x}$ ) and a KL divergence term ${D}_{\mathrm{{KL}}}\left( {{q}_{\phi }\left( {z \mid  x}\right) \parallel p\left( z\right) }\right)$ (to align the learned latent distribution with a standard normal prior). The reparameterization trick, represented by $\mathbf{z} = {\mathbf{g}}_{\phi }\left( {\epsilon ,\mathbf{x}}\right)$ , where $\epsilon$ is a noise variable, allows efficient backpropagation through the latent space. This process ensures effective training of the VAE, resulting in high-quality, realistic reconstructions of traffic scenes.

The training of VAEs involves maximizing the Evidence Lower Bound $\left( {f}_{\mathrm{{ELBO}}}\right)$ on the marginal likelihood $p\left( \mathbf{x}\right)$ . The ${f}_{\text{ELBO }}$ is given by:

$$
{f}_{\mathrm{{ELBO}}} = {\mathbb{E}}_{{q}_{\phi }\left( {\mathbf{z} \mid  \mathbf{x}}\right) }\left\lbrack  {\log p\left( {\mathbf{x} \mid  \mathbf{z}}\right) }\right\rbrack   - {D}_{\mathrm{{KL}}}\left( {{q}_{\phi }\left( {\mathbf{z} \mid  \mathbf{x}}\right) \parallel p\left( \mathbf{z}\right) }\right) , \tag{43}
$$

where ${D}_{\mathrm{{KL}}}$ denotes the KL divergence.

To enable gradient-based optimization, VAEs use the reparameterization trick, which allows the model to back-propagate through random nodes. If $z \sim  {q}_{\phi }\left( {z \mid  x}\right)$ , it is reparameterized as:

$$
z = {f}_{\text{rep },\phi }\left( {\epsilon , x}\right) , \tag{44}
$$

where ${f}_{\text{rep },\phi }\left( {\epsilon , x}\right)$ is a deterministic function that transforms an auxiliary noise variable $\epsilon$ and the input $x$ to generate the latent variable $z$ . Typically, ${f}_{\text{rep },\phi }\left( {\epsilon , x}\right)$ is defined such that:

$$
{f}_{\text{rep },\phi }\left( {\epsilon , x}\right)  = {\mu }_{\phi }\left( x\right)  + {\sigma }_{\phi }\left( x\right)  \odot  \epsilon , \tag{45}
$$

where ${\mu }_{\phi }\left( x\right)$ and ${\sigma }_{\phi }\left( x\right)$ are outputs of the encoder network that represent the mean and standard deviation, respectively, $\epsilon  \sim  \mathcal{N}\left( {0, I}\right)$ is a standard normal noise variable, and $\odot$ denotes the element-wise (Hadamard) product.

In practice, VAEs are implemented using NNs. The encoder network approximates ${q}_{\phi }\left( {z \mid  x}\right)$ and produces the parameters of the latent distribution, while the decoder network models $p\left( {x \mid  z}\right)$ .

VAEs are essential in traffic scene analysis, excelling in unsupervised tasks like data generation, denoising, and feature extraction. They create realistic and adversarial scenarios to enhance automated driving systems' robustness and are crucial for anomaly detection, boosting driving safety and efficiency. Applications include improving TLD [141], segmenting navigable spaces [142], detecting out-of-distribution (OOD) images in multi-label datasets [143], generating realistic traffic scenes [144], detecting adversarial driving scenes [145], and detecting traffic anomalies [146].

VATLD [141] adapts a state-of-the-art $\beta$ -VAE [147] with additional regularization terms for prediction and perceptual loss, achieving a significant improvement in TLD accuracy compared to the base model, SSD MobileNet V1 [43], on the BSTLD dataset. Notably, this improvement is evident for red and yellow lights, reflected by an increase in overall accuracy (OA) from 0.478 to 0.493 in average precision at IoU 50 (AP@IoU50), albeit with a slight decrease in accuracy for green lights.

NSS-VAE [142] is a dual-VAE architecture that excels in unsupervised segmentation of navigable spaces, surpassing 90% accuracy on the KITTI road benchmark. It outperforms traditional supervised methods, especially where ground truth labels are scarce. By merging deep features with GCNs to manage boundary uncertainties, NSS-VAE shows strong potential for autonomous navigation.

The approach in [143], based on $\beta$ -VAE [147], efficiently detects out-of-distribution (OOD) images in multi-label datasets, which is critical for safe autonomous operations such as end-to-end driving. By leveraging compact latent spaces to represent variations in key generative factors, this method offers a cost-effective solution for OOD detection. Evaluation on the nuScenes dataset shows detection rates of 95% for time-of-day, 74% for traffic, and 100% for pedestrian partitions, highlighting its robustness in complex real-world scenarios.

SceneGen [144] presents a neural autoregressive model for traffic scenes, generating new examples and evaluating existing ones without rules or heuristics, providing a flexible, scalable way to model real-world traffic complexity. It demonstrates significant realism improvements, with the lowest Negative Log-Likelihood (NLL) of 59.86 and an enhanced detection AP from 85.9% (using LayoutVAE) to 90.4% on the ATG4D dataset.

A tree-structured VAE (T-VAE) for Semantically Adversarial Generation (SAG), designed to detect adversarial driving scenes in $3\mathrm{D}$ point cloud segmentation models while adhering to traffic rules, is presented in [145]. This method enhances the robustness of automated driving systems by embedding traffic signs at the neuron level and leveraging explicit domain knowledge of object properties and relationships. The T-VAE-SAG approach demonstrates controllable and explainable generation, significantly reducing semantic constraint violations while maintaining data diversity. It achieves a reconstruction error (RE) of ${14.5} \pm$ 1.3 for targets from the Semantic KITTI dataset, even with random initialization.

In [146], an attention-based VAE (A-VAE) with 2D CNN and BiLSTM layers improved Recurrent VAE for anomaly detection on the UCSD dataset. The Recurrent VAE achieved ${90.4}\%$ AUC and 15.8% Equal Error Rates (EER), while A-VAE achieved 91.7% AUC and 18.2% EER.

Clustering-based DA improves traffic scene understanding by clustering data to reveal shared structures, reducing feature discrepancies across weather, camera views, and sensor types. It enhances Person and Vehicle Re-ID by capturing domain-invariant features, with centroid alignment further closing domain gaps, and strengthens multi-object tracking and action recognition through refined temporal and spatial consistency. However, clustering-based DA faces challenges. It requires careful tuning to prevent misalignment in complex scenes, which can degrade performance if clusters capture noise instead of meaningful features. Additionally, the method may struggle in dynamic environments where clusters shift over time, affecting the consistency of multi-object tracking and action recognition. Managing computational demands and scalability also becomes challenging, especially in high-traffic scenarios with extensive data streams.

### D.HPO FOR GENERATIVE MACHINE LEARNING MODELS

HPO critically improves generative ML models for traffic scene understanding. By tuning parameters like learning rate, batch size, and latent dimensions in GANs and VAEs, models produce more realistic, diverse synthetic scenarios, enhancing autonomous driving and traffic management algorithms. Optimized models handle rare cases, improve realism, stability, and generalization, prevent mode collapse, and accelerate convergence, thus reducing training time and resources. This ensures robust, efficient, and safe performance under diverse real-world conditions.

Reviewing GAN models, Adam optimizer was utilized with a learning rate of 0.001 for FutureGAN in [126], gradually reducing the learning rate and using different values for ${\beta }_{1}$ (0.0 for FutureGAN and 0.5 for DeblurGAN) to optimize model convergence. Authors of [134] trained SRGAN using Adam with a learning rate of ${10}^{-4}$ initially, which was reduced to ${10}^{-5}$ after 100,000 iterations, and incorporated VGG loss rescaling to balance the MSE loss. The study in [135] also implemented the Adam optimizer with a learning rate of ${10}^{-4}$ , employing a linear decay over 150 epochs. In [136] Adam optimizer is applied with a starting learning rate of 0.001 , decaying it by 0.87 at each resolution step in FutureGAN, and used penalty coefficients $\left( {\lambda  = {10}\text{and}\epsilon  = {0.001}}\right)$ in the WGAN-GP loss for improved stability.

In VAE models, authors of [148] trained their network using the Adam optimizer with a learning rate of 0.0001 , setting the momentums to 0.5 and 0.999 . They used a batch size of 1 and defined specific parameter values $\left( {{\lambda }_{m} = {0.01}}\right.$ , ${\lambda }_{\text{adv }} = 1,{\lambda }_{\text{recon }} = {10}$ ) for their loss functions, training the model for 250,000 iterations. Authors of [143] also employed the Adam optimizer but with a much lower learning rate of $1 \times$ ${10}^{-5}$ . They performed a hyperparameter search over $\beta$ values ranging from 1.0 to 1.9 and latent dimensions (nLatent) from 5 to 30, ultimately finding that a $\beta$ value in combination with $n$ Latent $= {30}$ yielded the best results. Their model architecture included an encoder with convolutional layers and a symmetrical decoder, and they trained their model for 100 epochs.

For cGANs, TScGAN [139] was trained using a learning rate of 0.0005 and a batch size of 32 across 150 training epochs. These training settings led to notable improvements in mean mIoU scores across different segmentation models, with DeepLabV3 achieving an increase from 77.2 to 79.0 and HRNet improving from 81.6 to 83.6.

## E. COMPARISON OF GENERATIVE MACHINE LEARNING MODELS

A comparison of different categories of generative ML models is presented in table Table 3. For the classification section, when applied to the Cityscapes dataset, Cycle-GAN [129] improved to an mIoU of 78.20%, while Dirty-GAN [129] achieved a higher mIoU of 91.71%. Meanwhile, the AttGAN [132] model achieved an F1-score of 96% for car classification when using synthetic snowy data generated by AttGAN compared to a score of ${91}\%$ for the classifier trained without the synthetic data. For segmentation, GAN-based models have also demonstrated strong performance, with CycleGAN [131] achieving an mIoU of 71.6% on the CityScapes dataset for urban segmentation under severe weather conditions.

GANs have also been applied for traffic image enhancement. For the Cityscapes dataset, multiple GAN methods were evaluated, with FutureGAN [126] achieving a PSNR of 22.38 and an SSIM of 0.61 . Compared to these results, the DeblurGAN [126] obtains a PSNR of 21.95 and SSIM of 0.59 , while SRGAN [126] had a lower PSNR of 20.49 and SSIM of 0.49 . On the RainDegraded dataset, DCGAN [130] achieved a PSNR of 24.98 and SSIM of 0.81, with ImprovedGAN [130] further improving these metrics to 25.81 and 0.84 , respectively. Finally, on the FogDegraded (RESIDE) dataset, DeblurGAN [130] achieved a PSNR of 24.42 and SSIM of 0.81, while ImprovedGAN [130] achieved 25.79 and 0.88 , respectively.

The methods presented in the scene generation section in Table 3 are all based on vehicle action recognition. For the ATG4D large-scale traffic scene dataset, LayoutVAE [144] achieved an NLL of 210.80 nats (where "nats" denotes the unit of measurement for NLL when using the natural logarithm). On the same dataset, SceneGen [144] achieved a significantly improved NLL of 59.86 nats. For the Semantic KITTI dataset, T-VAE [145] reported an RE of ${135.1} \pm  {16.9}$ , while T-VAE-SAG [145] achieved the best RE of 14.5 $\pm$ 1.3, significantly outperforming both the baseline VAE, with an RE of ${110.4} \pm  {10.6}$ , and T-VAE without SAG. Finally, for anomaly detection on the UCSD dataset, Recurrent VAE [146] achieved an AUC of 90.4% and an EER of 15.8%. A-VAE [146] further improved these metrics on this dataset, with an AUC of ${91.7}\%$ and an EER of ${18.2}\%$ , demonstrating the benefits of incorporating the attention mechanism in this context.

## V. DOMAIN ADAPTATION MODELS

Domain Adaptation (DA) methods are essential for improving traffic scene understanding across diverse environments. Traditional models struggle with distribution differences between training and testing datasets, resulting in poor generalization. DA enables models trained in one domain (e.g., specific weather conditions or regions) to effectively handle new, unseen domains. Unlike earlier approaches relying on hand-crafted features-prone to biases and limited expressiveness-DL-based DA uses DNNs for automatic feature extraction, better capturing complex, high-dimensional relationships.

While there exist different ways of categorizing deep DA methods, they can broadly be divided into three classes: clustering-based, discrepancy-based, and adversarial-based approaches. Clustering-based methods aim to group target domain data points with similar features to those in the source domain, facilitating knowledge transfer through clustering techniques. Discrepancy-based methods focus on minimizing statistical distances, like Maximum Mean Discrepancy (MMD), between source and target feature distributions for better alignment. Adversarial-based methods use adversarial learning techniques to reduce the gap between source and target domains by training a model to fool a domain discriminator, making features indistinguishable.

DA models are crucial for traffic scene understanding, allowing DNNs to adapt to varying lighting, weather, and geographic conditions without extensive retraining or large labeled datasets. This flexibility enables a single model to function effectively across diverse regions. By ensuring smooth knowledge transfer, DA models improve accuracy, reliability, and efficiency in traffic analysis and prediction, ultimately making transportation networks safer and more efficient.

In the following sections, we explore the overarching categories of models and techniques in depth. The mechanisms behind each specific adaptation strategy, their real-world applications, and their ability to address data variability and improve model generalization are thoroughly examined. Finally, We also discuss HPO for these strategies and compare their performance metrics to provide a comprehensive overview.

## A. CLUSTERING-BASED DOMAIN ADAPTATION

Clustering-based DA is a technique that helps a model trained on one domain, the source domain, perform well on another domain, the target domain, by using clustering techniques to identify shared structures between the two domains. The main idea is to group data points from both domains into clusters that capture common characteristics and use these clusters to guide the adaptation process.

Figure 13 depicts the application of clustering-based DA to image classification in a traffic scene. Let ${\mathcal{D}}_{s} = {\left\{  \left( {x}_{i}^{s},{y}_{i}^{s}\right) \right\}  }_{i = 1}^{{n}_{s}}$ be the labeled source domain dataset, where ${x}_{i}^{s}$ is the $i$ -th feature vector in the source domain and ${y}_{i}^{s}$ is its corresponding label. Let ${\mathcal{D}}_{t} = {\left\{  {x}_{j}^{t}\right\}  }_{j = 1}^{{n}_{t}}$ be the unlabeled target domain dataset, where ${x}_{j}^{t}$ is the $j$ -th feature vector in the target domain. The task of DA is to adapt a model trained on ${\mathcal{D}}_{s}$ so that it performs well on the target domain ${\mathcal{D}}_{t}$ , even though the target domain has different data distributions.

Clustering-based DA works by grouping both source and target domain data into clusters (or pseudo-labels) and aligning these clusters across domains. The core hypothesis is that the shared clusters between the two domains capture common features that help the model generalize from the source to the target domain.

Let ${f}_{\text{cluster }}\left( x\right)$ denote a clustering function that assigns a data point $x$ to a cluster. We can define two clustering functions: ${f}_{\text{cluster }, s}\left( {x}^{s}\right)$ for the source domain data, and ${f}_{\text{cluster }, t}\left( {x}^{t}\right)$ for the target domain data. A simple clustering approach could use $k$ -means clustering:

$$
{f}_{\text{cluster }}\left( x\right)  = \arg \mathop{\min }\limits_{k}{\begin{Vmatrix}x - {\mu }_{k}\end{Vmatrix}}^{2}, \tag{46}
$$

where ${\mu }_{k}$ is the centroid of the $k$ -th cluster, and $\parallel  \cdot  \parallel$ denotes the ${L}_{2}$ norm. The number of clusters, $K$ , is usually the same for both the source and target domains.

To adapt between the source and target domains, we want to ensure that the clusters in the source domain align with the clusters in the target domain. This can be formalized as minimizing the difference between the source and target clusters. Specifically, we define a domain alignment loss ${\mathcal{L}}_{\text{align }}$ based on aligning the centroids of corresponding clusters in the source and target domains:

$$
{\mathcal{L}}_{\text{align }} = \mathop{\sum }\limits_{{i = 1}}^{K}{\begin{Vmatrix}{\mu }_{i}^{s} - {\mu }_{i}^{t}\end{Vmatrix}}^{2}, \tag{47}
$$

where ${\mu }_{i}^{s}$ and ${\mu }_{i}^{t}$ are the centers of cluster $i$ in the source and target domains, respectively. Minimizing this loss encourages the distributions of the clusters in the source and target domains to be similar.

In addition to clustering the target domain data, we can also assign pseudo-labels to the target data based on the clustering. The pseudo-label for a target domain data point ${x}_{j}^{t}$ is assigned based on its nearest cluster centroid:

$$
{\widehat{y}}_{j}^{t} = \arg \mathop{\min }\limits_{k}{\begin{Vmatrix}{x}_{j}^{t} - {\mu }_{k}^{t}\end{Vmatrix}}^{2} \tag{48}
$$

TABLE 3. A comprehensive comparison of various generative ML models applied to traffic scene understanding, highlighting the differences in applications, frameworks, variance across models, datasets utilized, performance metrics, and the resulting effectiveness in their respective applications.

<table><tr><td>Application</td><td>Framework</td><td>Variance</td><td>Dataset</td><td>Performance Metric</td><td>Result</td></tr><tr><td rowspan="2">Classification</td><td>GAN</td><td>CycleGAN [128]</td><td>RareEvents_DS</td><td>mAP</td><td>45.5%</td></tr><tr><td>GAN</td><td>AttGAN [132]</td><td>BDD</td><td>F1-score</td><td>86%</td></tr><tr><td rowspan="2">Object Detection</td><td>VAE</td><td>VATLD [141]</td><td>BSTLD</td><td>AP@IoU50</td><td>0.49</td></tr><tr><td>VAE</td><td>MobileNet V1 [43]</td><td>BSTLD</td><td>AP@IoU50</td><td>0.48</td></tr><tr><td rowspan="11">Segmentation</td><td>GAN</td><td>MTPanClass [127]</td><td>Cityscapes</td><td>mloU</td><td>89.3%</td></tr><tr><td>GAN</td><td>CycleGAN [129]</td><td>Cityscapes</td><td>mIoU</td><td>78.20%</td></tr><tr><td>GAN</td><td>DirtyGAN [129]</td><td>Cityscapes</td><td>mloU</td><td>91.71%</td></tr><tr><td>GAN</td><td>CycleGAN [131]</td><td>CityScapes</td><td>mloU</td><td>71.6%</td></tr><tr><td>GAN</td><td>IEC-Net [131]</td><td>CityScapes</td><td>mloU</td><td>89.3%</td></tr><tr><td>cGAN</td><td>DeepLabV3+TScGAN [139]</td><td>Cityscapes</td><td>mIoU</td><td>79.0%</td></tr><tr><td>cGAN</td><td>PSPNet+TScGAN [139]</td><td>Cityscapes</td><td>mloU</td><td>81.3%</td></tr><tr><td>cGAN</td><td>HRNet+TScGAN [139]</td><td>Cityscapes</td><td>mIoU</td><td>83.6%</td></tr><tr><td>cGAN</td><td>HMSA+TScGAN [139]</td><td>Cityscapes</td><td>mIoU</td><td>86.8%</td></tr><tr><td>VAE</td><td>NSS-VAE [142]</td><td>KITTI</td><td>Accuracy</td><td>90%</td></tr><tr><td>VAE</td><td>$\beta$ -VAE [143]</td><td>nuScenes</td><td>Detection Rate</td><td>74%</td></tr><tr><td rowspan="7">Image Enhancement</td><td>GAN</td><td>FutureGAN [126]</td><td>Cityscapes</td><td>PSNR, SSIM</td><td>22.38, 0.61</td></tr><tr><td>GAN</td><td>DeblurGAN [126]</td><td>Cityscapes</td><td>PSNR, SSIM</td><td>21.95, 0.59</td></tr><tr><td>GAN</td><td>SRGAN [126]</td><td>Cityscapes</td><td>PSNR, SSIM</td><td>20.49, 0.49</td></tr><tr><td>GAN</td><td>DCGAN [130]</td><td>RainDegraded</td><td>PSNR, SSIM</td><td>24.98, 0.81</td></tr><tr><td>GAN</td><td>ImprovedGAN [130]</td><td>RainDegraded</td><td>PSNR, SSIM</td><td>25.81, 0.84</td></tr><tr><td>GAN</td><td>DeblurGAN [130]</td><td>FogDegraded (RESIDE)</td><td>PSNR, SSIM</td><td>24.42, 0.81</td></tr><tr><td>GAN</td><td>ImprovedGAN [130]</td><td>FogDegraded (RESIDE)</td><td>PSNR, SSIM</td><td>25.79, 0.88</td></tr><tr><td>Reconstructing Traffic States</td><td>GAN</td><td>TSRGAN [125]</td><td>NGSIM</td><td>TSS</td><td>32.595</td></tr><tr><td rowspan="7">Scene Generation</td><td>VAE</td><td>LayoutVAE [144]</td><td>ATG4D</td><td>NLL</td><td>210.80</td></tr><tr><td>VAE</td><td>SceneGen [144]</td><td>ATG4D</td><td>NLL</td><td>59.86</td></tr><tr><td>VAE</td><td>VAE [145]</td><td>Semantic KITTI</td><td>RE</td><td>${110.4} \pm  {10.6}$</td></tr><tr><td>VAE</td><td>VAE-WR [145]</td><td>Semantic KITTI</td><td>RE</td><td>${105.9} \pm  {24.6}$</td></tr><tr><td>VAE</td><td>GVAE [145]</td><td>Semantic KITTI</td><td>RE</td><td>${123.7} \pm  {9.5}$</td></tr><tr><td>VAE</td><td>T-VAE [145]</td><td>Semantic KITTI</td><td>RE</td><td>${135.1} \pm  {16.9}$</td></tr><tr><td>VAE</td><td>T-VAE-SAG [145]</td><td>Semantic KITTI</td><td>RE</td><td>${14.5} \pm  {1.3}$</td></tr><tr><td rowspan="2">Anomaly Detection</td><td>VAE</td><td>Recurrent VAE [146]</td><td>UCSD</td><td>AUC, EER</td><td>90.4%, 15.8%</td></tr><tr><td>VAE</td><td>A-VAE [146]</td><td>UCSD</td><td>AUC, EER</td><td>91.7%, 18.2%</td></tr><tr><td>Path Prediction</td><td>GAN</td><td>Sophie [133]</td><td>ETH</td><td>ADE, FDE</td><td>0.70, 1.43</td></tr></table>

where ${\widehat{y}}_{j}^{t}$ represents the pseudo-label assigned to ${x}_{j}^{t}$ . This pseudo-label is then used to refine the model by incorporating target domain data in a semi-supervised manner.

The objective function in clustering-based DA consists of three parts. The first part is the source domain loss, which is the classification loss on the source domain, and can be a standard supervised learning loss (e.g., cross-entropy):

$$
{\mathcal{L}}_{s} = \frac{1}{{n}_{s}}\mathop{\sum }\limits_{{i = 1}}^{{n}_{s}}\ell \left( {{f}_{s}\left( {x}_{i}^{s}\right) ,{y}_{i}^{s}}\right) , \tag{49}
$$

where ${f}_{s}\left( {x}_{i}^{s}\right)$ is the predicted label for source data and $\ell$ is the classification loss function.

The second part is the domain alignment loss, which ensures the alignment between the cluster distributions in the source and target domains. Specifically, we minimize the distance between the cluster centroids in the source and target domains as follows:

$$
{\mathcal{L}}_{\text{align }} = \mathop{\sum }\limits_{{i = 1}}^{K}{\begin{Vmatrix}{\mu }_{i}^{s} - {\mu }_{i}^{t}\end{Vmatrix}}^{2}, \tag{50}
$$

where ${\mu }_{i}^{s}$ and ${\mu }_{i}^{t}$ represent the centers of cluster $i$ in the source and target domains, respectively. Minimizing this loss helps align the clusters across domains.

The third part involves using the pseudo-labels from the target domain to compute a classification loss ${\mathcal{L}}_{t}$ on the target domain. This pseudo-label loss helps the model learn from the target domain:

$$
{\mathcal{L}}_{t} = \frac{1}{{n}_{t}}\mathop{\sum }\limits_{{j = 1}}^{{n}_{t}}\ell \left( {f\left( {x}_{j}^{t}\right) ,{\widehat{y}}_{j}^{t}}\right) , \tag{51}
$$

where ${\widehat{y}}_{j}^{t}$ is the pseudo-label for the target domain data point ${x}_{i}^{t}$ . By incorporating pseudo-labels, the model can iteratively refine itself to better predict target domain labels.

The total loss function for clustering-based DA is the weighted sum of these three components:

$$
\mathcal{L} = {\mathcal{L}}_{s} + \lambda {\mathcal{L}}_{\text{align }} + \gamma {\mathcal{L}}_{t}, \tag{52}
$$

where $\lambda$ (domain alignment weight) and $\gamma$ (pseudo-labeling weight) are trade-off parameters that control the importance of the domain alignment loss and the target pseudo-labeling loss, respectively, compared to the source classification loss. Specifically, $\lambda$ controls how much emphasis is placed on aligning the clusters between the source and target domains, while $\gamma$ adjusts the contribution of learning from pseudo-labels in the target domain.

![bo_d2839q77aajc738ors5g_28_170_203_1344_759_0.jpg](images/bo_d2839q77aajc738ors5g_28_170_203_1344_759_0.jpg)

FIGURE 13. Clustering-based DA for image classification in a traffic scene: A CNN is used to extract features from both a labeled source dataset and an unlabeled target dataset, representing different traffic environments. These features are grouped into clusters for both domains to identify common feature patterns. In the source clusters, blue and orange dots represent distinct clusters (clusters $i$ and $j$ ). Similarly, in the target clusters, blue and orange triangles represent corresponding clusters. The cluster matching and domain alignment step aligns similar clusters from the source and target domains, as indicated by the dashed green line, to ensure that shared features are well-represented across both domains. A classification NN is trained using labeled source data, and the learned weights are shared across both source and target domains. For the source domain, true labels guide training with a source classification loss. The same classification NN with shared weights is used for the target domain, where pseudo-labels are assigned to target data based on cluster alignments. Source output and target output illustrate the predictions made by the classification NN for both domains. These outputs reflect classification decisions such as whether an object is a "Person," "Car," or "Sign." Dashed lines represent the flow of these classification predictions from the NN to their respective outputs. For the source domain, predictions are validated using true labels, whereas for the target domain, pseudo-labels derived from cluster alignment are used. The figure also highlights a potential misclassification in the target domain, shown with a warning symbol, indicating the challenges of aligning the target domain data due to differences from the source domain. The overall clustering-based DA approach helps reduce such errors by adapting shared features between the domains effectively.

Clustering is performed on both the source and target domain data. The alignment between the clusters in the source and target domains is ensured by minimizing the distance between cluster centers, typically using a domain alignment loss as described above. Additionally, pseudo-labels for the target domain data allow the model to learn directly from the target domain in a semi-supervised manner. The model is trained on the source domain while regularizing with both the alignment loss and the pseudo-label loss to ensure that the model also works well on the target domain.

Clustering-based DA methods have advanced person reidentification (Person Re-ID) in smart surveillance systems [149], improved pedestrian tracking to enhance urban safety [150], optimized object detection for autonomous driving applications [151], and facilitated semantic segmentation in remote mapping for geographic information systems [152]. Moreover, these methods increase detection reliability across diverse environmental conditions [153].

Contrastive learning [154] enhances robustness against occlusion by teaching models to distinguish similar and dissimilar objects. Treating occluded and unoccluded instances as positive pairs helps learn occlusion-invariant features, reducing reliance on full visibility and enabling recognition even when objects are partially obscured.

In [149], Cluster-based Dual-branch Contrastive Learning (CDCL) tackles data noise and clothing color confusion in unsupervised domain adaptation (UDA) for Person Re-ID. Building on contrastive learning principles [155], CDCL uses partially grayed images and a dual-branch network, achieving ${81.5}\%$ mAP from DukeMTMC-ReID to Market1501 and improving pseudo-label reliability.

A deep mutual distillation (DMD) framework for UDA Person Re-ID is introduced, drawing inspiration from the teacher-student paradigm [156]. This framework employs two parallel feature extraction branches that act as teachers for each other, enhancing pseudo-label quality. Combined with a bilateral graph representation to align identity features via visual and attribute consistency, this approach achieves 92.7% mAP from DukeMTMC-reID to Market1501.

In [151], ConfMix addresses UDA in object detection with region-level confidence-based sample mixing. By blending target regions and confident pseudo detections from source images and adding consistency loss, it adapts the model to the target domain. Progressive pseudo-label filtering achieves ${52.2}\%$ mAP from KITTI to Cityscapes.

Semantic segmentation domain shifts are addressed through adversarial-based DA in FFREEDA (Federated source-Free Domain Adaptation) [152]. Leveraging unlabeled client data with a pre-trained server model, LADD (Learning Across Domains and Devices) employs adversarial self-supervision, ad-hoc regularization, and federated clustered aggregation with cluster-specific classifiers, achieving ${40.16} \pm  {1.02}\%$ mIoU from GTA5 to Mapillary.

CFFA, a coarse-to-fine feature adaptation approach for cross-domain object detection, is proposed in [153]. It uses multi-layer adversarial learning for marginal alignment and global prototype matching for conditional alignment. Results include ${38.6}\%$ mAP from Cityscapes to Foggy Cityscapes, ${43.8}\%$ AP for Car from SIM10k to Cityscapes, and ${41.0}\%$ mAP from Cityscapes to KITTI.

Clustering-based DA aids traffic scene understanding by grouping data into clusters that reveal shared structures, reducing feature differences across varying conditions (weather, camera views, sensors). It improves Person and Vehicle Re-ID by capturing domain-invariant features (body shape, vehicle silhouette). Techniques like centroid alignment and cluster-wise feature matching minimize domain gaps. Clustering-based DA enhances multi-object tracking (refining temporal and spatial consistency) and strengthens action recognition (leveraging contextual relations). It improves cross-domain representation, reduces retraining, and enables scalable performance for autonomous driving and traffic monitoring.

## B. DISCREPANCY-BASED DOMAIN ADAPTATION

Discrepancy-based DA aims to minimize the difference between source and target domain distributions to transfer knowledge from a labeled source domain to a target domain with limited or no labeled data. The key challenge in this approach is addressing the distribution shift between the probability distributions of the source and target domains. By reducing the discrepancy between these feature distributions, the model trained on the source domain can generalize effectively to the target domain, ensuring better performance despite domain differences.

Figure 14 illustrates the application of discrepancy-based DA to object detection in a traffic scene under different conditions. Let ${X}_{s}$ and ${Y}_{s}$ represent the input data and labels from the source domain, respectively, and ${X}_{t}$ be the input data from the target domain. The model ${f}_{\theta }$ is trained to minimize the difference in the distributions between the source and target domains.

The first step is to learn the model on the source domain by minimizing a classification loss ${\mathcal{L}}_{\text{source }}$ , such as cross-entropy:

$$
{\mathcal{L}}_{\text{source }} = {\mathbb{E}}_{\left( {{X}_{s},{Y}_{s}}\right)  \sim  P\left( {{X}_{s},{Y}_{s}}\right) }\left\lbrack  {\ell \left( {{f}_{\theta }\left( {X}_{s}\right) ,{Y}_{s}}\right) }\right\rbrack  , \tag{53}
$$

where $\ell$ is the classification loss function (e.g., cross-entropy loss), and ${f}_{\theta }\left( {X}_{s}\right)$ is the model prediction for the source input $\operatorname{data}{X}_{s}$ .

Next, the discrepancy between the source and target distributions in the feature space is minimized using a discrepancy distance metric. Common choices include Wasserstein distance, KL divergence, and MMD. Each metric has unique strengths and application scenarios, and understanding their differences is critical to selecting the appropriate tool for DA tasks.

The Wasserstein distance, also known as the Earth Mover's Distance, dates back to 1781 and was later formalized in a modern optimization framework by [82]. It measures the minimum cost of transporting one probability distribution to match another:

$$
W\left( {P\left( {X}_{s}\right) , P\left( {X}_{t}\right) }\right)
$$

$$
= {f}_{\text{inf }}\left( {\gamma  \in  \Pi \left( {P\left( {X}_{s}\right) , P\left( {X}_{t}\right) }\right) }\right) {\mathbb{E}}_{\left( {{X}_{s},{X}_{t}}\right)  \sim  \gamma }\left\lbrack  \begin{Vmatrix}{{X}_{s} - {X}_{t}}\end{Vmatrix}\right\rbrack  , \tag{54}
$$

where $\Pi \left( {P\left( {X}_{s}\right) , P\left( {X}_{t}\right) }\right)$ denotes the set of joint distributions with marginals $P\left( {X}_{s}\right)$ and $P\left( {X}_{t}\right)$ . Here, ${f}_{\text{inf }}$ represents the infimum, or the largest lower bound, of the expected cost over all joint distributions $\gamma$ with these specified marginals. Unlike a strict minimum, the infimum allows for cases where the smallest value might not be precisely attainable, but a bound exists. Compared to other metrics, the Wasserstein distance provides a notion of "how much" one distribution must be transformed to match another, offering a natural and interpretable way to compare distributions. Notably, it is well-suited for cases where the support of the source and target distributions are disjoint, a situation where other metrics like KL divergence fail due to the zero-probability issue.

However, the computational cost of calculating Wasser-stein distance is often higher than other metrics, as it involves solving a linear programming problem. This limits its applicability to scenarios with smaller datasets or where computational efficiency is paramount.

The KL divergence, first introduced in [157], measures the relative entropy between the source and target distributions:

$$
{D}_{\mathrm{{KL}}}\left( {P\left( {X}_{s}\right) \parallel P\left( {X}_{t}\right) }\right)  = \int P\left( {X}_{s}\right) \log \left( \frac{P\left( {X}_{s}\right) }{P\left( {X}_{t}\right) }\right) {dX}, \tag{55}
$$

where $P\left( {X}_{s}\right)$ and $P\left( {X}_{t}\right)$ represent the probability distributions of the source and target domains, respectively. KL divergence is asymmetric and measures how much information is lost when approximating one distribution by another. It is especially useful when both distributions have overlapping support and $P\left( {X}_{t}\right)  > 0$ whenever $P\left( {X}_{s}\right)  > 0$ . However, in DA scenarios where the target domain contains regions with zero probability (i.e., where the source distribution has support but the target does not), KL divergence diverges, making it unsuitable for disjoint support situations.

Moreover, KL divergence tends to be more sensitive to outliers compared to the Wasserstein distance and, as will be discussed, the MMD. This sensitivity arises because KL divergence heavily penalizes regions where there is a discrepancy in probability mass, which can lead to overly aggressive adaptations, especially when the target distribution contains sparse or noisy data.

![bo_d2839q77aajc738ors5g_30_182_196_1349_539_0.jpg](images/bo_d2839q77aajc738ors5g_30_182_196_1349_539_0.jpg)

FIGURE 14. Discrepancy-based DA for object detection in a traffic scene under different conditions: The process starts with a source dataset (representing familiar conditions like clear weather) and a target dataset (representing different conditions like snowy weather). Both datasets are processed through a DNN, which extracts relevant features from each dataset, referred to as “DNN Features.” These DNN features from the source and target datasets are then compared using a discrepancy loss module, which measures and minimizes the differences between the feature sets. This helps the model align the feature representations from both domains, improving its ability to detect objects even in the unfamiliar target domain. By reducing the discrepancy, the model can leverage what it learned from the source data to adapt effectively to the target conditions. The outputs on the right show detected objects in both the source and target datasets, illustrating how the model successfully performs object detection across different environments by minimizing discrepancies in feature representation. This enables more consistent detection results regardless of varying traffic scene conditions.

The MMD, introduced by [158], measures the distance between the means of two distributions in a Reproducing Kernel Hilbert Space (RKHS):

$$
\operatorname{MMD}\left( {P\left( {X}_{s}\right) , P\left( {X}_{t}\right) }\right)  = \parallel {\mathbb{E}}_{{X}_{s} \sim  P\left( {X}_{s}\right) }\left\lbrack  {\phi \left( {X}_{s}\right) }\right\rbrack
$$

$$
- {\mathbb{E}}_{{X}_{t} \sim  P\left( {X}_{t}\right) }{\left\lbrack  \phi \left( {X}_{t}\right) \right\rbrack  }_{\mathcal{H}}, \tag{56}
$$

where $\phi \left( X\right)$ maps the data to a higher-dimensional feature space, $\mathcal{H}$ is the Hilbert space, and $\parallel  \cdot  {\parallel }_{\mathcal{H}}$ denotes the norm in this space.

The MMD is advantageous in that it does not require explicit density estimation of either distribution, making it computationally efficient and straightforward to implement with kernel methods. Unlike KL divergence, it can handle distributions with disjoint support and is less sensitive to outliers, which provides more stability during training.

MMD's effectiveness depends on the chosen kernel, which affects how accurately it measures source-target discrepancies. A poorly selected kernel can yield suboptimal adaptation if it fails to capture complex distributional relationships. Compared to Wasserstein distance, MMD typically runs faster but is less interpretable in terms of physical distance.

Metric selection depends on domain adaptation specifics, such as disjoint support, computational constraints, and noise sensitivity. For high-dimensional generative tasks, Wasserstein distance may offer greater stability, while tasks with overlapping distributions might benefit from the faster convergence of KL divergence or MMD.

The optimization objective, denoted as ${\mathcal{L}}_{\text{align }}$ , is a combination of the classification loss on the source domain and the discrepancy loss between the source and target distributions. The trade-off between these two components is controlled by the regularization parameter $\lambda$ :

$$
{\mathcal{L}}_{\text{align }} = {\mathcal{L}}_{\text{source }} + \lambda  \cdot  {\mathcal{L}}_{\text{discrepancy }}, \tag{57}
$$

Discrepancy-based DA has significantly advanced several real-world computer vision applications. These applications include autonomous driving systems [159], urban safety monitoring [160], traffic surveillance [161], smart surveillance for Person Re-ID [162], digital recognition in smart city systems [163], and efficient resource management in autonomous systems [164].

Drawing on the teacher-student paradigm [156], [159] introduces Masked Retraining (MRT) for domain-adaptive object detection. Using a custom masked autoencoder and selective retraining, MRT achieves ${51.2}\mathrm{{mAP}}$ from Cityscapes to Foggy Cityscapes, improving adaptability and accuracy by capturing target domain traits and handling incorrect pseudo labels.

Building on DETR [94], [160] proposes a robust baseline for DETR-style detectors under domain shift. Incorporating Object-Aware Alignment (OAA) and Optimal Transport Alignment (OTA), it mitigates shifts in both backbone and decoder outputs, raising mAP to 46.8% for Cityscapes to Foggy Cityscapes adaptation.

ML-ANet (Multi-Label Adaptation Network) [161], reduces source-target domain discrepancy using multiple kernel variants with MMD. Task-specific hidden layers are embedded in RKHS (Reproducing Kernel Hilbert Space) to align feature distributions across domains, resulting in improved efficiency. ML-ANet achieves a mean accuracy of 94.83% for Cityscapes to Foggy Cityscapes benchmark.

D-MMD (Dissimilarity-based MMD) loss [162] addresses the challenges of UDA in Person Re-ID by aligning pairwise dissimilarities between source and target domains rather than feature representations. This approach achieves an mAP of 48.8% on the DukeMTMC to Market1501 benchmark, without requiring data augmentation or complex network designs.

In [163], the sliced Wasserstein discrepancy (SWD) is introduced for UDA, combining task-specific decision boundary alignment with Wasserstein distance. Validations include digit/sign recognition $({98.6} \pm  {0.3}\%$ on SYNSIG $\rightarrow$ GTSRB), image classification (76.4% mean accuracy on VisDA 2017), semantic segmentation (44.5% mIoU from GTA5 $\rightarrow$ Cityscapes), and object detection (5.9% mAP on VisDA 2018).

Selective adaptation for object detection (TDOD), leveraging domain gap metrics such as MMD, DSS, and SWD, is proposed in [164] to perform adaptation only when necessary. This approach minimizes costs while maintaining accuracy. On the DGTA benchmark, a no-adaptation model achieves ${90.3}\%$ AP50 (clear daytime $\rightarrow$ overcast), whereas selective adaptation improves performance to 93.1%, delivering significant energy savings.

Discrepancy-based DA aligns features across domains using metrics like MMD and Wasserstein distance, handling variations in layout, color, and environment. It bolsters robustness in Re-ID, tracking, and action recognition, aiding cross-camera tracking, behavior analysis, and intelligent traffic systems. However, these methods may struggle with complex shifts not fully captured by distance metrics and can be computationally intensive, requiring extensive tuning and resources. This complexity may limit their scalability in large, real-time systems.

## C. ADVERSARIAL-BASED DOMAIN ADAPTATION

Adversarial-based DA is a technique for adapting a model trained on one domain, called the source domain, to achieve strong performance on a different domain, known as the target domain. This approach employs adversarial learning to reduce discrepancies between the two domains, allowing the model to generalize effectively. The core idea is to train a feature extractor that makes the data representations from both the source and target domains indistinguishable to a domain discriminator, while also ensuring the model performs well on the original source domain task.

Figure 15 illustrates the use of adversarial-based domain adaptation for segmenting a traffic scene. Let ${\mathcal{D}}_{s} =$ ${\left\{  \left( {x}_{i}^{s},{y}_{i}^{s}\right) \right\}  }_{i = 1}^{{n}_{s}}$ be the labeled source domain dataset, where ${x}_{i}^{s}$ is the $i$ -th feature vector in the source domain and ${y}_{i}^{s}$ is its corresponding label. Let ${\mathcal{D}}_{t} = {\left\{  {x}_{j}^{t}\right\}  }_{j = 1}^{{n}_{t}}$ be the unlabeled target domain dataset, where ${x}_{j}^{t}$ is the $j$ -th feature vector in the target domain. The goal is to train a model that performs well on the target domain despite the difference in data distributions between the source and target domains.

![bo_d2839q77aajc738ors5g_31_885_187_719_622_0.jpg](images/bo_d2839q77aajc738ors5g_31_885_187_719_622_0.jpg)

FIGURE 15. Application of Adversarial-based DA to segmentation of a traffic scene: The figure shows a labeled source domain dataset and an unlabeled target domain dataset, where the source and target domains are captured under different weather conditions. The goal of this method is to achieve effective segmentation in the target domain, despite differences in data distribution between the source and target domains and variations in weather. The adversarial-based DA setup involves a shared-weight feature extractor and a domain adversarial training mechanism to align the feature spaces of both domains. The feature extractor is designed to map both source and target domain data into a shared feature space, minimizing domain-specific distinctions, including those caused by different weather conditions. The classifier predicts segmentation labels for the source domain, while the domain discriminator attempts to distinguish between source and target domain features. During training, the feature extractor is optimized to fool the domain discriminator, leading to more domain-invariant feature representations. Segmentation accuracy is further enhanced by utilizing insights from the source domain's class size distribution, which helps to regulate the constrained mutual information loss in the target domain. The combination of classification and adversarial feature losses are optimized to ensure that the segmentation model generalizes well to the target domain. Ultimately, this process results in accurate segmentation of the traffic scene, regardless of weather conditions.

Adversarial-based DA typically involves a feature extractor $\left( {G}_{f}\right)$ , a classifier $\left( {G}_{y}\right)$ , and a domain discriminator $\left( {G}_{d}\right)$ . The feature extractor maps source and target data into a shared space, while the classifier predicts labels for source data. The domain discriminator tries to distinguish source from target features. During training, ${G}_{f}$ learns to fool ${G}_{d}$ , making source and target features indistinguishable. Variations include multiple discriminators, reconstruction losses, gradient reversal layers, and other alignment techniques. Some methods add extra objectives for specific feature properties or multi-level alignment, but the core aim is to extract domain-invariant features that generalize effectively to the target domain.

The objective for the classifier and feature extractor on the source domain is to minimize the classification loss ${\mathcal{L}}_{y}$ , typically cross-entropy:

$$
{\mathcal{L}}_{y} = \frac{1}{{n}_{s}}\mathop{\sum }\limits_{{i = 1}}^{{n}_{s}}\ell \left( {{G}_{y}\left( {{G}_{f}\left( {x}_{i}^{s}\right) }\right) ,{y}_{i}^{s}}\right) , \tag{58}
$$

where ${G}_{f}\left( {x}_{i}^{s}\right)$ is the feature representation of source data, ${G}_{y}\left( {{G}_{f}\left( {x}_{i}^{s}\right) }\right)$ is the predicted label, and $\ell$ is the cross-entropy loss.

The domain discriminator ${G}_{d}$ is trained to distinguish between source and target features by minimizing the binary classification loss:

$$
{\mathcal{L}}_{d} =  - \frac{1}{{n}_{s}}\mathop{\sum }\limits_{{i = 1}}^{{n}_{s}}\log \left( {{G}_{d}\left( {{G}_{f}\left( {x}_{i}^{s}\right) }\right) }\right)
$$

$$
- \frac{1}{{n}_{t}}\mathop{\sum }\limits_{{j = 1}}^{{n}_{t}}\log \left( {1 - {G}_{d}\left( {{G}_{f}\left( {x}_{j}^{t}\right) }\right) }\right) , \tag{59}
$$

where ${G}_{d}\left( {{G}_{f}\left( {x}_{i}^{s}\right) }\right)$ is the probability that the source feature is classified as belonging to the source domain, and ${G}_{d}\left( {{G}_{f}\left( {x}_{j}^{t}\right) }\right)$ is the probability that the target feature is classified as belonging to the target domain.

To ensure ${G}_{f}$ produces domain-invariant features, it is trained to fool ${G}_{d}$ by maximizing the domain discriminator’s loss, making source and target features similar. Formally, ${\mathcal{L}}_{f} =  - {\mathcal{L}}_{d}$

The overall loss combines the source classification loss and the adversarial domain confusion loss:

$$
\mathcal{L} = {\mathcal{L}}_{y} + \lambda {\mathcal{L}}_{f}
$$

where $\lambda$ balances domain confusion against classification accuracy.

Training alternates between two steps: training ${G}_{d}$ to distinguish source from target by minimizing ${\mathcal{L}}_{d}$ , and training ${G}_{f}$ to minimize ${\mathcal{L}}_{y}$ and ${\mathcal{L}}_{f}$ . This adversarial process aligns source and target features, improving generalization to the target domain.

I2IT, introduced in [165], converts an image from one domain to another, preserving core structure but adapting style or characteristics. It's used in photo enhancement, style transfer, and data augmentation. Though not inherently a DA task, I2IT methods are widely applied for DA ( [166], [167]), often using GAN-based frameworks [124]. CycleGAN [137] is a key milestone in I2IT and underpins many adversarial DA approaches in Table 4.

CycleGAN introduces a cycle consistency loss to ensure that the original image can be recovered after a round-trip translation $\left( {X \rightarrow  Y \rightarrow  X}\right)$ . This is defined as:

$$
{\mathcal{L}}_{\text{cycle }}\left( {G,{G}^{\prime }}\right)  = {\mathbb{E}}_{x \sim  {p}_{\text{data }}\left( x\right) }\left\lbrack  {\begin{Vmatrix}{G}^{\prime }\left( G\left( x\right) \right)  - x\end{Vmatrix}}_{1}\right\rbrack
$$

$$
+ {\mathbb{E}}_{y \sim  {p}_{\text{data }}\left( y\right) }\left\lbrack  {\begin{Vmatrix}G\left( {G}^{\prime }\left( y\right) \right)  - y\end{Vmatrix}}_{1}\right\rbrack  , \tag{60}
$$

where $G : X \rightarrow  Y$ and ${G}^{\prime } : Y \rightarrow  X$ are the forward and backward generators, respectively, and $\parallel  \cdot  {\parallel }_{1}$ denotes the L1 norm. The total loss for training CycleGAN is the sum of this cycle-consistent loss and the adversarial loss as in Equation 59.

Adversarial-based DA has been applied in traffic scene understanding for tasks like day-to-night translation [168], haze synthesis and removal [148], semantic segmentation [169], object detection [170], [171], [172], [173], scene classification [174], [175], scene segmentation [176], and cross-domain adaptation in challenging environments [177], [178], [179], [180], [181], [182]. Moreover, these methods contribute to fair scene adaptation in urban monitoring [183].

The Fréchet Inception Distance (FID) score measures similarity between real and generated images by calculating the Fréchet (Wasserstein-2) distance between their multivariate Gaussian distributions, based on means and covariances. It uses features from an intermediate layer of the Inception network [184], capturing both visual quality and diversity.

The adversarial method in [168] (referred to as "Day-toNight" in our work) uses CycleGAN [137] for day-to-night translation, enhanced by transfer learning from semantic segmentation. Trained on BDD segmentation data and adapted to Tokyo, it handles unique lighting conditions, improving object detection ( ${55.3}\%$ to ${57.2}\% \mathrm{{mAP}}$ ) and segmentation (59.5% to 61.6% mIoU). Outperforming SemGAN [185], AugGAN [186], and CycleGAN, it achieves an FID score of 39.26 and generates realistic night images for Tokyo scenes.

ParaTeacher [179] introduces a UDA approach combining a Style-Content Discriminated Data Recombination (SCD-DR) module for data refinement and an Iterative Cross-Domain Knowledge Transferring (ICD-KT) module for knowledge enhancement. Integrated with Faster R-CNN, it boosts mAP by $5\%  - {10}\%$ , achieving ${44.59}\%$ on the Virtual KITTI to KITTI benchmark, significantly narrowing the synthetic-to-real data gap.

PanopticGAN [180] proposes a GAN framework for panoptic-aware I2IT, improving image quality and object recognition with a feature masking module and a compact thermal dataset. It enhances boundary sharpness and segmentation, achieving superior fidelity and an FID score of 69.4, outperforming existing methods.

The CyCADA model [181] combines discriminative training with cycle-consistent adversarial DA at pixel and feature levels, requiring no aligned image pairs. It proves effective in semantic segmentation, achieving ${39.5}\mathrm{{mLoU}}$ in GTA5 to CityScapes adaptation.

The model in [174] (referred to as "UDAofUrbanScenes" in our work) combines supervised learning on synthetic data, adversarial learning between labeled synthetic and unlabeled real data, and self-teaching guided by segmentation confidence. It adapts urban scene segmentation from synthetic datasets (GTA5, SYNTHIA) to real-world datasets (Cityscapes), improving performance on rare classes and achieving 30.2% mIoU.

CPGAN [172] enhances vehicle detection in foggy conditions with an improved CycleGAN [137] for style transfer and pre-trained YOLOv4, achieving ${69.24}\% \mathrm{{mAP50}}$ on HVFD (normal to foggy). Its adversarial setup, with two generators and discriminators plus perceptual consistency loss, enables effective pixel and feature-level adaptation, improving detection in foggy environments.

The I2IT model [182] (referred to as "SGND" in our work) introduces a multi-task unsupervised NN for day-to-night translation using adversarial training. It combines semantic segmentation and geometric depth as spatial attention maps on the BDD dataset. Featuring a generator for conversion and a discriminator for realism, SGND achieves an FID score of 31.245, superior KID metrics, and improved realism, accuracy, and domain mapping.

![bo_d2839q77aajc738ors5g_33_103_200_1507_578_0.jpg](images/bo_d2839q77aajc738ors5g_33_103_200_1507_578_0.jpg)

FIGURE 16. Training procedure of adversarial feature adaptation for traffic scene classification. The process involves three key steps: In Step 0, the source-specific feature extractor (E5) and classifier (C) are trained with source images to minimize classification errors via cross-entropy (CE) loss. In Step 1, the feature generator (S) and discriminator (D₁) are trained to produce domain-specific generated features, using noise conditioning and source labels to enhance the adaptation capability. In Step 2, the shared encoder (E, I) and discriminator (D ${}_{2}$ ) are trained to align the source and target domains through adversarial loss (GAN loss), ensuring domain invariance. The dashed lines represent auxiliary feature generation pathways, while solid lines depict the main training process. By leveraging both real and GAN-generated data, this procedure enhances the model’s robustness for classification under diverse and challenging conditions.

An innovative unsupervised I2IT framework is introduced in [148] that leverages both VAE and GAN, along with an MMD-based VAE, which utilizes MMD as a discrepancy measure to align latent distributions effectively. This discrepancy-based alignment allows the framework to handle both haze image synthesis and haze removal in a unified manner, demonstrating promising results on the Apollo dataset, with PSNR and SSIM metrics of 27.3772 and 0.9271, respectively

In [169], a novel teacher-student [156] approach for unsupervised domain-adaptive semantic segmentation in memory-constrained models (referred to as DRN-D-BasedDA in our work) is presented. The method employs a multi-level strategy with adversarial learning and uses a custom cross-entropy loss with pseudo-teacher labels to address domain gaps and memory constraints. DRN-D-BasedDA improves adaptability in both real and synthetic scenarios, achieving an mIoU of ${37.35}\%$ from GTA5 to Cityscapes.

Adversarial Feature Adaptation (AFA), as first introduced in [187], is a technique for UDA that enhances model robustness and generalization by augmenting training data with adversarially generated features. It employs a domain-invariant feature extractor trained via feature space data augmentation, utilizing GANs to broaden the input feature distribution. This method aims to improve the model's generalization to unseen data, especially useful in scenarios requiring resilience to adversarial examples or when training data is scarce or non-representative. Like with I2IT adversarial models, it has been applied to overcome domain shift problems for various traffic vision tasks including object detection [170], [171], traffic scene classification [175], and traffic scene segmentation [176]. Figure 16 shows the training procedure of an AFA to be applied to a traffic scene classification problem.

AFAN [170] merges an advanced UDA framework for object detection with an intermediate domain image generator and domain-adversarial training with soft domain labels, significantly enhancing feature alignment through feature pyramid and region feature alignment techniques. This comprehensive approach fosters domain-invariant feature learning and achieves a notable mAP of ${41.4}\%$ in object detection adapted from the CityScapes to the KITTI benchmark.

SADA (Sparse Adversarial Domain Adaptation) [175] tackles weather-related domain shift in traffic scene classification [175]. With 93.20% accuracy (Sunny to Cloudy) on HSD dataset, it employs a unique sparse adversarial deep NN. This model captures sparse data from source scenes and aligns them with target images, extracting domain-invariant features for accurate classification. SADA outperforms existing methods, showcasing the power of sparse data and adversarial domain alignment in deep networks.

The study in [176] introduces an innovative UDA model employing a sparse adversarial multi-target approach to address domain shifts in real-world traffic scenes. Achieving a segmentation accuracy of 76.13 IoU on the ACDC dataset, it outperforms state-of-the-art methods, demonstrating the effectiveness of sparse representation compared to deep dense alternatives under diverse environmental conditions.

The approach proposed in [171] for handling foggy and rainy conditions combines image and object-level adaptations with an adversarial gradient reversal layer to mine challenging examples. Additionally, it employs an auxiliary domain via data augmentation to introduce new domain-level metric regularization. This method achieves a detection mAP of ${45.0}\%$ when transferring from CityScapes to Rainy CityScapes, and 42.3% from CityScapes to Foggy CityScapes.

FREDOM [183] addresses fairness in DA for semantic scene understanding, leveraging transformer networks [188] to model conditional structures and balance class distributions. By utilizing self-supervised loss with pseudo labels and introducing a conditional structural constraint, it achieves mIoU accuracies of ${67.0}\%$ for SYNTHIA $\rightarrow$ Cityscapes and ${73.6}\%$ for GTA5 $\rightarrow$ Cityscapes, emphasizing equitable performance across classes.

The Self-Adversarial Disentangling (SAD) framework, proposed in [178], addresses the challenge of adapting to specific domain shifts in DA by introducing the concept of Specific DA (SDA) and mitigating intra-domain gaps through a domainness creator and self-adversarial regularizer, achieving ${45.2}\% \mathrm{{mAP}}$ on the benchmark for Cityscapes to Foggy Cityscapes.

The authors of [177] proposed Category-induced Coarse-to-Fine DA (C2FDA) to address the challenges of adapting object detection models to unseen and complex traffic environments. They introduced three key components: Attention-induced Coarse-Grained Alignment (ACGA), Attention-induced Feature Selection, and Category-induced Fine-Grained Alignment (CFGA). Their approach achieved 48.9% AP on synthetic-to-real adaptation (SIM10K to Cityscapes), ${40.5}\% \mathrm{{mAP}}$ on weather adaptation (Cityscapes to Foggy Cityscapes), and 48.0% AP on cross-camera adaptation (KITTI to Cityscapes).

DAAF (Domain Adaptation of Anchor-Free) object detection method [173], tackles the challenges of cross-domain object detection in complex urban traffic scenarios. It utilizes fully convolutional adversarial training for global feature alignment and incorporates Pixel-Level Adaptation (PLA) for local feature alignment. This approach achieves an AP50 of ${53.4}\%$ when transferring from SIM ${10}\mathrm{\;K}$ to Cityscapes, and 37.87% for SIM 10K to KITTI.

Adversarial-based DA enhances traffic tasks like reidentification, tracking, and action recognition by using adversarial training to create domain-invariant features, minimizing domain-specific biases and enabling robust performance across varying conditions. This supports applications such as traffic flow optimization, anomaly detection, and cross-camera tracking, vital for autonomous driving and intelligent traffic systems. However, in traffic scene understanding, adversarial-based DA requires careful tuning to balance adversarial loss with task-specific accuracy, as misalignment can lead to incorrect identification or tracking. It may also struggle in rapidly changing traffic environments, where maintaining consistent feature alignment is challenging, impacting the reliability of tracking and action recognition, especially in dense, dynamic traffic scenarios.

### D.HPO FOR DOMAIN ADAPTATION MODELS

HPO enhances the performance of clustering-based, discrepancy-based, and adversarial DA models, especially for tasks like Person Re-ID, object detection, and semantic segmentation. By fine-tuning hyperparameters such as learning rates, loss coefficients, and architectural choices, HPO optimizes model components for effectiveness across domains.

In clustering-based DA methods, optimizing network architectures, loss weights, learning rates, and data augmentation strategies improves pseudo-label reliability and domain alignment. For instance, in CDCL [149], HPO balances learning rates, weight decay, and contrastive loss temperature-a hyperparameter that scales the similarity measure in contrastive loss, fine-tuning feature differentiation. This results in improved feature extraction and an mAP of 81.5% on DukeMTMC-ReID to Market1501. DMD [150] benefits from tuning graph learning rates, distillation weights, which control the influence of knowledge transfer from a teacher model to a student model, and batch size, achieving an mAP of 92.7%. In object detection, ConfMix [151] adjusts adversarial parameters, such as pseudo-label confidence (0.7 to 0.9), which sets a threshold for pseudo-label acceptance to enhance reliability, and NMS thresholds (0.3- 0.5 ), achieving an mAP of ${52.2}\%$ when adapting from KITTI to Cityscapes. FFREEDA [152] tunes learning rates for cluster-specific classifiers (0.0005 to 0.0015) and loss weights, achieving an mIoU of ${40.16} \pm  {1.02}\%$ from GTA5 to Mapillary.

In discrepancy-based DA models, HPO optimizes domain alignment metrics like FID and MMD. In ParaTeacher [179], HPO fine-tunes modules by adjusting alignment coefficients (0.1 to 0.5) and contrastive temperatures (0.07 to 0.1), improving mAP by $5\%  - {10}\%$ to reach 44.59% on KITTI. The MRT framework [159] adjusts reconstruction loss weights and retraining epochs, enhancing mAP to ${51.2}\%$ from Cityscapes to Foggy Cityscapes. DETR-style detectors [160] benefit from HPO on attention dropout rates and learning schedules, achieving an mAP of ${46.8}\%$ for Cityscapes to Foggy Cityscapes. In ML-ANet [161], MMD alignment benefits from tuning kernel bandwidths-a parameter that controls the sensitivity of MMD to variations in data distributions, allowing precise domain alignment-and specific hidden layer learning rates, achieving a mean accuracy of 94.83% for Cityscapes to Foggy Cityscapes.

In adversarial-based DA models, HPO plays a crucial role in refining parameters for adversarial losses, feature alignment, and I2IT techniques. In [148], a combined I2IT framework utilizes a VAE-GAN structure with an MMD-based VAE. Here, MMD serves as an effective discrepancy measure to align latent distributions, while HPO is used to balance reconstruction loss (ranging from 0.2 to 0.5 ) and adversarial weights. This approach achieved PSNR and SSIM scores of 27.3772 and 0.9271, respectively, on the Apollo dataset.

TABLE 4. A comprehensive comparison of various domain adaptive ML models applied to traffic scene understanding, highlighting the differences in applications, categories, variance across models, datasets utilized, performance metrics, and the resulting effectiveness in their respective applications.

<table><tr><td>Application</td><td>Category</td><td>Variance</td><td>Dataset</td><td>Performance Metric</td><td>Result</td></tr><tr><td rowspan="8">Classification</td><td>Discrepancy</td><td>DAN [161]</td><td>Cityscapes $\rightarrow$ Foggy Cityscapes</td><td>Mean Accuracy</td><td>91.85%</td></tr><tr><td>Discrepancy</td><td>ML-ANet [161]</td><td>Cityscapes $\rightarrow$ Foggy Cityscapes</td><td>Mean Accuracy</td><td>94.83%</td></tr><tr><td>Discrepancy</td><td>MCD [163]</td><td>VisDA 2017 $\rightarrow$ MSCOCO</td><td>Mean Accuracy</td><td>71.9%</td></tr><tr><td>Discrepancy</td><td>SWD [163]</td><td>VisDA 2017 $\rightarrow$ MSCOCO</td><td>Mean Accuracy</td><td>76.4%</td></tr><tr><td>Discrepancy</td><td>D-MMD [175]</td><td>HSD(Sunny $\rightarrow$ Cloudy/Rainy/Snowy)</td><td>Mean Accuracy</td><td>72.63%</td></tr><tr><td>Adversarial</td><td>STAR [175]</td><td>HSD(Sunny $\rightarrow$ Cloudy/Rainy/Snowy)</td><td>Mean Accuracy</td><td>81.25%</td></tr><tr><td>Adversarial</td><td>DWL [175]</td><td>HSD(Sunny $\rightarrow$ Cloudy/Rainy/Snowy)</td><td>Mean Accuracy</td><td>82.38%</td></tr><tr><td>Adversarial</td><td>SADA [175]</td><td>$\mathrm{{HSD}}\left( {\mathrm{{Sunny}} \rightarrow  \mathrm{{Cloudy}}/\mathrm{{Rainy}}/\mathrm{{Snowy}}}\right)$</td><td>Mean Accuracy</td><td>93.20%</td></tr><tr><td rowspan="21">Object Detection</td><td>Clustering</td><td>CFFA [153]</td><td>Cityscapes $\rightarrow$ Foggy Cityscapes</td><td>mAP</td><td>38.6%</td></tr><tr><td>Discrepancy</td><td>DefDETR [159]</td><td>Cityscapes $\rightarrow$ Foggy Cityscapes</td><td>mAP</td><td>28.5%</td></tr><tr><td>Adversarial</td><td>MTTrans [159]</td><td>Cityscapes $\rightarrow$ Foggy Cityscapes</td><td>mAP</td><td>43.4%</td></tr><tr><td>Discrepancy</td><td>MRT [159]</td><td>Cityscapes $\rightarrow$ Foggy Cityscapes</td><td>mAP</td><td>51.2%</td></tr><tr><td>Discrepancy</td><td>Deformable DETR [160]</td><td>Cityscapes $\rightarrow$ Foggy Cityscapes</td><td>mAP</td><td>28.6%</td></tr><tr><td>Adversarial</td><td>SFA [160]</td><td>Cityscapes $\rightarrow$ Foggy Cityscapes</td><td>mAP</td><td>41.3%</td></tr><tr><td>Adversarial</td><td>${O}^{2}$ net [160]</td><td>Cityscapes $\rightarrow$ Foggy Cityscapes</td><td>mAP</td><td>46.8%</td></tr><tr><td>Discrepancy</td><td>TDOD (Without Adaptation) [164]</td><td>DGTA(Clear $\rightarrow$ Overcast)</td><td>AP50</td><td>90.3%</td></tr><tr><td>Discrepancy</td><td>TDOD (With Adaptation) [164]</td><td>DGTA(Clear $\rightarrow$ Overcast)</td><td>AP50</td><td>93.1%</td></tr><tr><td>Adversarial</td><td>DaytoNight-No Augmentation [168]</td><td>BDD(Day $\rightarrow$ Night)</td><td>mAP</td><td>55.3%</td></tr><tr><td>Adversarial</td><td>DaytoNight-With Augmentation [168]</td><td>BDD(Day $\rightarrow$ Night)</td><td>mAP</td><td>57.2%</td></tr><tr><td>Adversarial</td><td>AFAN [170]</td><td>CityScapes $\rightarrow$ KITTI</td><td>mAP</td><td>41.4%</td></tr><tr><td>Adversarial</td><td>FogAndRainDA [171]</td><td>CityScapes $\rightarrow$ Rainy CityScapes</td><td>mAP</td><td>45.0%</td></tr><tr><td>Adversarial</td><td>YOLOv4+CycleGAN [172]</td><td>HVFD(Normal $\rightarrow$ Foggy)</td><td>mAP50</td><td>67.21%</td></tr><tr><td>Adversarial</td><td>YOLOv4+CPGAN [172]</td><td>HVFD(Normal $\rightarrow$ Foggy)</td><td>mAP50</td><td>69.24%</td></tr><tr><td>Adversarial</td><td>MGA [173]</td><td>SIM ${10}\mathrm{\;K} \rightarrow$ Cityscapes</td><td>AP50</td><td>49.8%</td></tr><tr><td>Adversarial</td><td>DAAF [173]</td><td>SIM ${10}\mathrm{\;K} \rightarrow$ Cityscapes</td><td>AP50</td><td>53.4%</td></tr><tr><td>Adversarial</td><td>C2FDA [177]</td><td>Cityscapes $\rightarrow$ Foggy Cityscapes</td><td>mAP</td><td>40.5%</td></tr><tr><td>Adversarial</td><td>SAD [178]</td><td>Cityscapes $\rightarrow$ Foggy Cityscapes</td><td>mAP</td><td>45.2%</td></tr><tr><td>Discrepancy</td><td>MTOR [179]</td><td>Virtual KITTI $\rightarrow$ KITTI</td><td>mAP</td><td>32.75%</td></tr><tr><td>Adversarial</td><td>ParaTeacher [179]</td><td>Virtual KITTI $\rightarrow$ KITTI</td><td>mAP</td><td>44.59%</td></tr><tr><td rowspan="13">Segmentation</td><td>Clustering</td><td>FFREEDA [150]</td><td>GTA5 $\rightarrow$ Mapillary</td><td>mloU</td><td>${40.16} \pm  {1.02}$</td></tr><tr><td>Discrepancy</td><td>SWD [163]</td><td>GTA5 $\rightarrow$ Cityscapes</td><td>mIoU</td><td>44.5%</td></tr><tr><td>Adversarial</td><td>DaytoNight-No Augmentation [168]</td><td>BDD(Day $\rightarrow$ Night)</td><td>mloU</td><td>59.5%</td></tr><tr><td>Adversarial</td><td>DaytoNight-With Augmentation [168]</td><td>BDD(Day $\rightarrow$ Night)</td><td>mIoU</td><td>61.6%</td></tr><tr><td>Adversarial</td><td>AdaptSegNet [169]</td><td>GTA5 $\rightarrow$ Cityscapes</td><td>mloU</td><td>32.49%</td></tr><tr><td>Adversarial</td><td>DRN-D-BasedDA [169]</td><td>GTA5 $\rightarrow$ Cityscapes</td><td>mloU</td><td>37.35%</td></tr><tr><td>Adversarial</td><td>UDAofUrbanScenes [174]</td><td>GTA5 $\rightarrow$ CityScapes</td><td>mloU</td><td>30.2%</td></tr><tr><td>Adversarial</td><td>MTKT [176]</td><td>ACDC(Sunny $\rightarrow$ Cloudy/Rainy/Snowy)</td><td>IoU</td><td>71.01%</td></tr><tr><td>Adversarial</td><td>LSA-UDA [176]</td><td>ACDC(Sunny $\rightarrow$ Cloudy/Rainy/Snowy)</td><td>IoU</td><td>76.13%</td></tr><tr><td>Adversarial</td><td>CyCADA feature-only [181]</td><td>SYNTHIA $\rightarrow$ CityScapes</td><td>mIoU</td><td>31.7%</td></tr><tr><td>Adversarial</td><td>CyCADA pixel-only [181]</td><td>SYNTHIA $\rightarrow$ CityScapes</td><td>mloU</td><td>37.0%</td></tr><tr><td>Adversarial</td><td>CyCADA pixel+feature [181]</td><td>SYNTHIA $\rightarrow$ CityScapes</td><td>mloU</td><td>39.5%</td></tr><tr><td>Adversarial</td><td>FREDOM [183]</td><td>GTA5 $\rightarrow$ CityScapes</td><td>mIoU</td><td>73.6%</td></tr><tr><td rowspan="19">12IT</td><td>Adversarial</td><td>UNIT [148]</td><td>Apollo(Haze $\rightarrow$ Dehaze)</td><td>PSNR, SSIM</td><td>24.52, 0.85</td></tr><tr><td>Adversarial</td><td>CycleGAN [148]</td><td>Apollo(Haze $\rightarrow$ Dehaze)</td><td>PSNR, SSIM</td><td>25.19, 0.89</td></tr><tr><td>Adversarial</td><td>VAE-GAN [148]</td><td>Apollo(Haze $\rightarrow$ Dehaze)</td><td>PSNR, SSIM</td><td>27.38, 0.93</td></tr><tr><td>Adversarial</td><td>$\mathrm{{AugGAN}}\left\lbrack  {168}\right\rbrack$</td><td>BDD(Day $\rightarrow$ Night)</td><td>FID</td><td>67.07</td></tr><tr><td>Adversarial</td><td>SemGAN [168]</td><td>BDD(Day $\rightarrow$ Night)</td><td>FID</td><td>39.91</td></tr><tr><td>Adversarial</td><td>DaytoNight [168]</td><td>BDD(Day $\rightarrow$ Night)</td><td>FID</td><td>39.26</td></tr><tr><td>Adversarial</td><td>CycleGAN [168]</td><td>BDD(Day $\rightarrow$ Night)</td><td>FID</td><td>35.28</td></tr><tr><td>Adversarial</td><td>MUNIT+Seg [180]</td><td>Augmented KAIST-MSBDD(Day $\rightarrow$ Night)</td><td>FID</td><td>98.7</td></tr><tr><td>Adversarial</td><td>BicycleGAN+Seg [180]</td><td>Augmented KAIST-MSBDD(Day $\rightarrow$ Night)</td><td>FID</td><td>97.9</td></tr><tr><td>Adversarial</td><td>SCGAN [180]</td><td>Augmented KAIST-MSBDD(Day $\rightarrow$ Night)</td><td>FID</td><td>92.4</td></tr><tr><td>Adversarial</td><td>TSIT+Seg [180]</td><td>Augmented KAIST-MSBDD(Day $\rightarrow$ Night)</td><td>FID</td><td>80.8</td></tr><tr><td>Adversarial</td><td>INIT [180]</td><td>Augmented KAIST-MSBDD(Day $\rightarrow$ Night)</td><td>FID</td><td>76.7</td></tr><tr><td>Adversarial</td><td>PanopticGAN [180]</td><td>Augmented KAIST-MSBDD(Day $\rightarrow$ Night)</td><td>FID</td><td>69.4</td></tr><tr><td>Adversarial</td><td>CycleGAN [182]</td><td>BDD (Day $\rightarrow$ Night)</td><td>FID</td><td>35.52</td></tr><tr><td>Adversarial</td><td>SemGAN [182]</td><td>BDD(Day $\rightarrow$ Night)</td><td>FID</td><td>35.26</td></tr><tr><td>Adversarial</td><td>AugGAN [182]</td><td>BDD(Day $\rightarrow$ Night)</td><td>FID</td><td>57.72</td></tr><tr><td>Adversarial</td><td>UNIT [182]</td><td>BDD(Day $\rightarrow$ Night)</td><td>FID</td><td>32.66</td></tr><tr><td>Adversarial</td><td>MUNIT [182]</td><td>BDD(Day $\rightarrow$ Night)</td><td>FID</td><td>69.97</td></tr><tr><td>Adversarial</td><td>SGND [182]</td><td>BDD(Day $\rightarrow$ Night)</td><td>FID</td><td>31.25</td></tr><tr><td rowspan="3">Person Re-ID</td><td>Clustering</td><td>CDCL [149]</td><td>$\mathrm{{DukeMTMC} - {ReID}} \rightarrow  \mathrm{{Market1501}}$</td><td>mAP</td><td>81.5%</td></tr><tr><td>Clustering</td><td>DMD [150]</td><td>DukeMTMC-reID $\rightarrow$ Market1501</td><td>mAP</td><td>92.7%</td></tr><tr><td>Discrepancy</td><td>D-MMD [162]</td><td>DukeMTMC $\rightarrow$ Market1501</td><td>mAP</td><td>48.8%</td></tr></table>

In semantic segmentation, the adversarial framework FRE-DOM [183] employs transformer-based networks, requiring careful HPO of hyperparameters such as learning rates (set at ${2.5} \times  {10}^{-4}$ ), momentum (0.9), weight decay $\left( {10}^{-4}\right)$ , and batch size ( 4 per GPU) to balance fairness objectives with segmentation accuracy. With these calibrated hyperparame-ters, FREDOM achieves notable improvements, with mIoU scores reaching 67.0% for the SYNTHIA to Cityscapes, and 73.6% for the GTA5 to Cityscapes benchmarks, respectively, showcasing its capabilities in achieving class balance across complex traffic environments.

For day-to-night translation tasks, adversarial models based on CycleGAN [137], such as the model in [168], benefit significantly from HPO, particularly through tuning the cyclic consistency loss parameter $(\lambda$ , set between 5 and 10) and generator learning rates (between 0.0001 and 0.0002). These optimizations improved mAP from 55.3% to ${57.2}\%$ and mIoU from ${59.5}\%$ to ${61.6}\%$ on the BDD dataset. Similarly, CPGAN [172] utilizes HPO for optimizing generator and discriminator learning rates, as well as feature alignment loss weights, achieving an mAP50 of ${69.24}\%$ on the HVFD dataset.

## E. COMPARISON OF DOMAIN ADAPTATION MACHINE LEARNING MODELS

A comparison of different categories of DA models is presented in Table 4. In classification tasks, discrepancy-based methods such as D-MMD [175] achieved a mean accuracy of ${72.63}\%$ on the HSD dataset for sunny to cloudy/rainy/snowy weather. Successive models like STAR [175] and DWL [175] improved the mean accuracy to ${81.25}\%$ and ${82.38}\%$ , respectively. The SADA model [175] further enhanced performance, reaching a mean accuracy of ${93.20}\%$ , demonstrating the effectiveness of self-adaptive adversarial approaches in handling domain shifts due to weather variations. Discrepancy-based methods, like DAN [161] and ML-ANet [161], also showed high performance on the Cityscapes to Foggy Cityscapes, with mean accuracies of 91.85% and 94.83%, respectively.

For object detection, the I2IT adversarial framework for day-to-night transformation [168] achieved an mAP of ${55.3}\%$ on the BDD dataset without augmentation, while the inclusion of data augmentation improved the mAP to ${57.2}\%$ . This improvement highlights the benefit of data augmentation within an adversarial-based DA framework. The adversarial-based teacher-student [156] framework using CPGAN [172] on the HVFD dataset achieved an mAP50 of ${69.24}\%$ , outperforming the version with CycleGAN, which achieved 67.21%. Other teacher-student [156] models, including MTOR [179] and ParaTeacher [179], achieved mAPs of 32.75% and 44.59%, respectively, on the Virtual KITTI to KITTI adaptation. Domain adaptation for DefDETR [159] achieved an mAP of ${28.5}\%$ when adapting from Cityscapes to Foggy Cityscapes. In comparison, adversarial-based methods such as MTTrans [159] and MRT [159] significantly improved the mAP to 43.4% and ${51.2}\%$ , respectively, demonstrating the efficacy of transformer-based approaches in minimizing domain discrepancies. The AFA framework with AFAN [170] attained an mAP of 41.4% when adapting from Cityscapes to KITTI, while FogAndRainDA [171] reached an mAP of 45.0% from Cityscapes to Rainy Cityscapes.Transformer-based methods, including Deformable DETR [160], SFA [160], and ${O}^{2}$ net [160], achieved mAPs of ${28.6}\% ,{41.3}\%$ , and ${46.8}\%$ , respectively, on Cityscapes to Foggy CityScapes. Based on these results, addressing the domain gap between traffic object detection datasets is a worthwhile direction for improving the generalization capacity of computer vision models.

In segmentation tasks, the adversarial I2IT framework with DaytoNight [168] achieved an mIoU of ${59.5}\%$ on the BDD dataset without augmentation, and ${61.6}\%$ with augmentation. CYCADA [181], applied from SYNTHIA to CityScapes, achieved an mIoU of 39.5%, demonstrating the effectiveness of combining pixel and feature-level adaptation. UDAofUrbanScenes [174] achieved an mIoU of ${30.2}\%$ for GTA5 to CityScapes benchmark. The adversarial teacher-student [156] framework using AdaptSegNet [169] achieved an mIoU of 32.49% on GTA5 to Cityscapes, while DRN-D-BasedDA [169] improved to 37.35%. The AFA framework using LSA-UDA [176] achieved an IoU of ${76.13}\%$ on the ACDC dataset for sunny to cloudy/rainy/snowy), highlighting the potential of adversarial feature alignment in handling varying weather conditions. Leveraging the transformer network framework [188], FREDOM [183] achieved an $\mathrm{{mIoU}}$ of 73.6% on GTA5 to CityScapes, demonstrating the effectiveness of transformer-based architectures in DA for segmentation tasks.

For I2IT, the adversarial VAE-GAN [148] achieved a PSNR of 27.38 and an SSIM of 0.93 on the Apollo traffic scene dataset (Haze to Dehaze), outperforming UNIT and CycleGAN on the same dataset. In one study [168], CycleGAN achieved an FID of 35.28 on the BDD dataset for the day-to-night task, while DaytoNight, SemGAN, and AugGAN reported FID scores of 39.26, 39.91, and 67.07, respectively. In a separate study [182], CycleGAN attained an FID of 35.52, whereas SemGAN slightly improved to 35.26. Additionally, AugGAN and MUNIT produced FID scores of 57.72 and 69.97, respectively. Notably, the SGND model achieved the lowest FID score of 31.25, suggesting superior image quality for the generated scenes compared to the other models.

In Person Re-ID, clustering-based methods showed significant improvements. CDCL [149] achieved an mAP of 81.5% when adapting from DukeMTMC-ReID to Market1501. DMD [150] further improved the mAP to 92.7% on the same dataset pair, indicating the effectiveness of clustering techniques in handling domain shifts for Person Re-ID tasks. Discrepancy-based methods like D-MMD [162] achieved a lower mAP of 48.8%, suggesting that clustering methods may be more suitable for this application.

The results demonstrate that the choice of DA method significantly impacts performance across various applications. Clustering-based methods are particularly strong in Person Re-ID, with DMD [150] achieving a high mAP of 92.7%. Discrepancy-based methods are effective in classification and object detection, exemplified by ML-ANet [161] with 94.83% accuracy in classification. Adversarial-based methods perform well across multiple tasks, including classification, object detection, segmentation, and I2IT, with models like SADA [175] achieving 93.20% accuracy and SGND [182] reaching the best FID of 31.25 in I2IT. Effectively addressing domain gaps is crucial for enhancing model generalization in various applications. Addressing the domain gap effectively is crucial for enhancing the generalization capacity of ML models in various applications.

## VI. DISCUSSION

In this section, we examine the key features of deep learning models for traffic scene understanding, highlighting their strengths, limitations, and potential areas for enhancement. The discussion covers discriminative, generative, and DA models. Table 5 summarizes the shortcomings and potential future directions for improvement across these categories, providing an overview to guide further research.

## A. DISCRIMINATIVE MODELS

This subsection discusses the discriminative models, emphasizing their role in traffic scene understanding by examining their strengths and limitations, paving the way for future advancements and potential research directions.

## 1) CNN

## Advantages:

- Localized Feature Extraction: CNNs are particularly adept at extracting local feature patterns from images, making them highly effective for traffic scene data where identifying localized object patterns is crucial.

- Translation Invariance: CNNs use shared kernels across the entire image, allowing them to detect features consistently, regardless of their position.

- Efficient and Robust Learning: By sharing weights, CNNs achieve greater computational efficiency and reduce the risk of overfitting.

## Disadvantages:

- Data Dependency: CNNs typically require large, well-labeled datasets to achieve high accuracy, which are often lacking in traffic scene applications.

- Generalization Issues: CNNs face challenges in generalizing to dynamic traffic scenarios with varying environmental conditions, which limits their robustness in real-world applications.

- Limited Global Contextual Understanding: While CNNs can achieve high-level understanding through pooling, they struggle to capture non-local or long-range dependencies because of their limited, localized receptive fields.

Future Work: Future research should focus on reducing reliance on large labeled datasets through semi-supervised and self-supervised learning, improving CNN generalization. Adding context-aware modules like attention mechanisms or non-local operations can help capture global dependencies in traffic scenes, boosting performance in complex environments without the computational cost of transformers.

## 2) VANILLA R-CNN

## Advantages:

- Higher Localization Precision: Vanilla R-CNN is particularly effective at accurately localizing objects, which is crucial for detecting small or occluded objects in complex traffic scenes.

- Region-Specific Feature Extraction: The two-stage region proposal structure of Vanilla R-CNN can achieve higher performance in traffic scenarios involving numerous overlapping objects, such as crowded pedestrian tracking.

## Disadvantages:

- Inefficient Region Proposal Strategy: Vanilla R-CNN's reliance on selective search for region proposals results in high computational complexity and significant processing time.

- High Memory Consumption: The two-stage nature of Vanilla R-CNN increases memory demands, limiting its scalability and feasibility on resource-constrained devices.

- Lack of End-to-End Training: Vanilla R-CNN separates localization from classification, which reduces performance and extends training time.

- Challenges with Occlusions: Vanilla R-CNN has limited effectiveness when dealing with occluded objects due to its region proposal structure, which often struggles to distinguish objects that are partially hidden in traffic scenes.

Future Work: For future work, we largely expect efforts to focus on the more developed Vanilla R-CNN variants. One possible direction specifically for R-CNN is the development of more efficient algorithms for generating region proposals that can be integrated seamlessly into the R-CNN pipeline. Furthermore, improvements to the ROI pooling procedure could enhance performance, particularly for small-object detection, which would be especially beneficial for certain traffic scene processing tasks such as aerial traffic tracking. Enhancements should also focus on better handling occlusions by incorporating more sophisticated feature extraction techniques that can capture partially hidden objects effectively.

## 3) FAST R-CNN

## Advantages:

- End-to-End Training: Fast R-CNN unifies training for classification and bounding box regression into a single-stage, end-to-end process, eliminating the need for separate training stages.

- Reduced Redundancy for Object Localization: Fast R-CNN leverages RoI pooling to extract all region proposals in a single pass, unlike R-CNN, which requires a separate pass for each region. This reduces redundancy in object localization, leading to greater computational efficiency.

- Improved accuracy via Joint Optimization Fast R-CNN achieves improved performance in classification and regression tasks by unifying them with a joint loss function.

## Disadvantages:

- Inefficient Region Proposal Strategy: In Fast R-CNN, the Selective Search algorithm remains slow, significantly hindering real-time performance.

- Lower Small-Object Detection Accuracy: Although RoI pooling improves the efficiency of Fast R-CNN, it may reduce spatial information, making it challenging for the model to detect smaller objects.

Future Work: Although Faster R-CNN has addressed several limitations of Fast R-CNN, R-CNN could still benefit from advancements in representational learning by leveraging modern architectures such as ViTs.

## 4) FASTER R-CNN

## Advantages:

- Faster Processing: Faster R-CNN integrates region proposal generation directly into the model, significantly increasing processing speed while maintaining detection accuracy.

- High Detection Robustness: It Faster R-CNN is highly effective at detecting objects, even in dense traffic scenes with significant occlusions and overlapping objects.

- Efficient Object Localization: Faster R-CNN's unified approach to region proposal generation and detection enhances both speed and accuracy in complex environments while enabling end-to-end learning.

## Disadvantages:

- Limited Real-Time Performance: Although Faster R-CNN is faster than both R-CNN and Fast R-CNN, it still falls short of real-time performance, making it less suitable for real-world traffic applications.

- Being Resource-Intensive: Faster R-CNN requires significant computational resources, similar to R-CNN, which restricts its deployment in certain environments.

- Lower Small-Object Detection Accuracy: Although the RPN improves Faster R-CNN's performance and efficiency over R-CNN's selective search strategy, it has the trade-off of reducing the model's ability to recognize small objects.

Future Work: Future work could investigate the development of lighter, more resource-efficient Faster R-CNN variants that retain high detection performance while enabling deployment in real-time traffic applications. Additionally, enhancing small-object detection capabilities in Faster R-CNN represents another promising research direction.

## 5) MASK R-CNN

## Advantages:

- Simultaneous Detection and Segmentation: Mask R-CNN enables object detection and instance segmentation simultaneously, critical for detailed traffic scene analysis.

- High Segmentation Accuracy: Mask R-CNN excels at instance segmentation, particularly in scenarios with overlapping objects.

- Adaptability: Mask R-CNN Easily integrates additional tasks like keypoint detection for comprehensive scene understanding.

Disadvantages:

- High Computational Demand: Mask prediction increases resource requirements, limiting real-time applicability.

- Small Object Segmentation Issues: Struggles with small or distant objects in traffic scenes.

- Occlusion Sensitivity: Faces challenges in segmenting heavily occluded objects.

Future Work: Future research should optimize the mask prediction branch to reduce computational overhead while maintaining high accuracy. Enhancing small-object segmentation with multi-scale fusion and advanced attention mechanisms, along with robust algorithms for occlusions using 3D spatial data or multi-view inputs, could further advance Mask R-CNN.

## 6) YOLO

## Advantages:

- Single-Pass Detection: YOLO performs object detection in a single pass, making it highly efficient for real-time applications, such as live traffic analysis.

- Global Context Understanding: YOLO detects objects by analyzing the entire image instead of focusing on specific regions, which enhances both speed and overall detection performance.

- High Scalability and Flexibility: YOLO's framework integrates seamlessly with various representational learning methods and can be easily adjusted to balance speed and accuracy for different traffic detection tasks.

## Disadvantages:

- Difficulty with Small Objects: YOLO's grid-based approach often misses smaller objects, significantly reducing its performance in traffic scenes with crowded object distributions or when detecting small or distant objects is crucial.

- Challenges with Overlapping Objects: YOLO struggles to detect objects that overlap or are closely packed, which is common in urban traffic scenarios, especially for pedestrian detection.

- Accuracy Trade-offs: YOLO emphasizes speed over detection accuracy, making it less suitable for complex environments, such as those with poor weather conditions.

- Sensitivity to Occlusions: YOLO's single-pass detection mechanism makes it prone to miss objects that are partially occluded, which commonly occurs in crowded traffic scenes, such as partially hidden vehicles or pedestrians.

Future Work: Future research should enhance YOLO's detection of small and overlapping objects by refining its grid-based approach, advancing post-processing techniques, and developing more versatile backbones. Efforts should also focus on improving adaptability to challenging environments like adverse weather or crowded scenes and optimizing detection through anchor-free architectures and advanced attention mechanisms.

## 7) ViT

## Advantages:

- Enhanced Global Context Understanding: ViTs utilize attention mechanisms to model long-range dependencies, enhancing their ability to understand global scene context and learn contextual relationships between objects in traffic scenes.

- Scalability: ViTs are highly scalable, making them well-suited for processing large, high-resolution traffic datasets.

- Multimodal Models: Due to the flexibility of transformers, ViTs are well-suited for adaptation to complex, multimodal traffic understanding tasks, such as image-caption generation.

- Occlusion Handling: The attention mechanism in ViTs allows for better modeling of partially occluded objects by considering relationships between visible and hidden features across the scene.

## Disadvantages:

- Heavy Data and Computation: ViTs require large datasets and significant computational resources to achieve high performance, limiting their applicability in real-time or resource-constrained environments.

- Overfitting Risk: Without sufficient data, ViTs are prone to overfitting, which restricts their suitability for many traffic scene applications where annotated data is scarce.

- Training Complexity: Training ViTs is generally more complex and time-consuming compared to other models, such as CNNs.

Future Work: Future research should prioritize reducing the computational cost of ViT models and their dependence on large datasets. As advancements are made in these areas, ViTs could be explored as viable alternatives for general computer vision tasks in traffic scenes, where CNNs currently prevail. Furthermore, enhancing ViTs' ability to generalize with limited annotated data through transfer learning and data-efficient training techniques could help mitigate overfitting and improve their applicability to traffic scene tasks with scarce data.

## 8) DETR

## Advantages:

- End-to-End Detection: DETR eliminates the need for region proposals and non-maximum suppression, simplifying the object detection pipeline while preserving high performance.

- Global Scene Understanding: DETR's transformer-based architecture captures global dependencies more effectively, enabling DETR-based frameworks to better represent complex object relationships and interactions in traffic scenes.

- High Compositional Representation Capability: DETR excels at handling objects with complex, decomposable structures commonly found in traffic scenes, such as pedestrians in various poses, cyclists with intricate postures, or police officers making hand gestures for traffic control.

## Disadvantages:

- Slow Training Convergence: DETR takes longer to converge during training, requiring significantly more epochs compared to models like YOLO or Faster R-CNN, which can delay its implementation.

- Difficulty with Small and Occluded Objects: Like YOLO, DETR may struggle to detect small or occluded objects in traffic scenes, particularly when they are distant or partially hidden.

- Computational Overhead: The transformer-based approach demands greater computational resources, which can limit DETR's practicality for real-time applications.

Future Work: To address DETR's slow convergence, future work could focus on developing more efficient training paradigms that reduce the number of epochs required for convergence. Another promising research direction involves improving the detection of smaller or occluded objects in traffic scenes by modifying the attention mechanism to better capture fine details. Reducing computational overhead to enable real-time deployment is also crucial, as is exploring more flexible approaches for controlling the maximum number of detected objects.

## 9) GNN

## Advantages:

- Ability to Model Complex Spatial and Temporal Relationships: GNNs excel at capturing complex spatial and temporal dependencies in traffic networks, which is essential for understanding interactions among vehicles, pedestrians, and infrastructure.

- Flexible Representation: Because GNNs can model arbitrary graph structures, they are well-suited for high-level traffic vision tasks, such as scene graph generation.

- Scalability to Large Networks: GNNs can effectively scale to large traffic systems, enabling the analysis of entire cities or transportation networks within a unified framework.

## Disadvantages:

- High Computational Demand: GNNs require substantial computational resources, particularly when applied to large graphs with numerous nodes and edges, which can limit their applicability in real-time traffic scenarios.

- Data Preprocessing Complexity: GNNs require well-structured graph representations, which can be challenging to obtain in dynamic traffic environments or when performing representational learning directly on images.

- Training Complexity: The iterative nature of GNNs can result in longer training times, and their performance may degrade if the graph structure is poorly defined or highly dynamic.

Future Work: Future research should focus on efficient graph construction for dynamic traffic scenes, including adaptive real-time updates and robust occlusion handling. Vision GNNs can model spatial relationships and reconstruct occluded features. Reducing GNN training complexity and exploring hybrid approaches with self-supervised learning or multi-modal fusion can further improve robustness and efficiency.

## 10) CapsNet

## Advantages:

- Pose and Orientation Awareness: Effectively handling part-whole relationships enables CapsNet models to better capture specific information from traffic scenes, such as pose and orientation, and improves their ability to generalize with limited data.

- Modeling Occlusions and Hierarchical Relationships: CapsNets model spatial relationships more effectively than CNNs, leading to significant improvement in recognizing occluded objects and understanding part-whole structures, which is highly beneficial for traffic scene analysis.

- Improved Robustness: CapsNets offer greater resilience to minor variations in object appearance, which is beneficial in complex traffic environments and reduces sensitivity to adversarial attacks.

## Disadvantages:

- Computational Complexity: The routing-by-agreement mechanism in CapsNets significantly increases computational complexity due to its iterative nature.

- Scalability Issues: CapsNets are particularly sensitive to hyperparameter selection due to their dynamic routing mechanism, which can significantly affect performance in large-scale traffic scene understanding tasks.

Future Work: A promising direction for future research is to optimize the routing-by-agreement mechanism to reduce computational complexity while preserving the model's ability to capture spatial hierarchies. Such improvements would enhance the practicality of CapsNets for real-world traffic scene understanding.

## B. GENERATIVE MODELS

This subsection explores the generative models, highlighting their significance in traffic scene understanding by analyzing their advantages and challenges, while also suggesting potential future improvements and research opportunities.

## 1) GAN

## Advantages:

- Generating High-Quality Synthetic Data: GANs excel at generating high-resolution, realistic synthetic images through their adversarial training paradigm, providing richer synthetic data for traffic scene scenarios.

- Unsupervised Learning Capabilities: GANs do not require labeled data for training, enabling more flexible application in environments where labeled data is scarce, such as traffic scenarios under rare weather conditions like hurricanes.

## Disadvantages:

- Training Instability: GANs are notoriously challenging to train due to their adversarial nature, often leading to issues such as non-convergence or oscillatory behavior during training, particularly when applied to highly complex traffic scenes.

- Mode Collapse Risk: GANs are susceptible to mode collapse, in which the generator focuses on a limited set of patterns when producing output data.

Future Work: In the future, researchers should explore mechanisms to address training instability, such as developing more robust optimization methods or hybrid models that integrate GANs with more stable generative frameworks. Incorporating regularization techniques into the objective function may also help mitigate mode collapse, making GANs more suitable for generating realistic synthetic traffic scene data.

## 2) cGAN

## Advantages:

- Controlled Generation: cGANs can generate more precise output by incorporating conditional information, such as specifying vehicle types in a traffic scene.

- Improved Diversity: By conditioning on specific attributes, cGANs can generate a broader range of outputs, such as vehicles in different positions or scenes under various lighting conditions, thereby enhancing the diversity of synthetic traffic datasets.

## Disadvantages:

- Training Complexity: The introduction of conditional variables adds complexity to the training process of cGANs, often necessitating more careful tuning of the model architecture and hyperparameters, particularly in traffic scenarios where the conditioning variables are diverse and complex.

- Risk of Conditional Overfitting: cGANs may overfit to specific conditions if the conditioning data lacks sufficient diversity.

- Higher Resource Requirements: Conditional inputs increase the computational complexity of the architecture compared to basic GANs, limiting its suitability for real-time traffic processing systems.

Future Work: Future work could prioritize mitigating the overfitting risk in cGANs by developing more effective regularization techniques and enhancing the diversity of conditional data. Additionally, researchers could explore methods to reduce computational overhead by designing lightweight architectures better suited for real-time traffic scene generation.

## 3) VAE

## Advantages:

- Structured Latent Space: VAEs create a structured and continuous latent space, facilitating the exploration of variations in generated traffic data.

- Stable Training: VAEs are easier to train compared to GANs due to their probabilistic framework, which ensures convergence and stability.

- Efficient Data Compression: VAEs can compress high-dimensional traffic scene data into a lower-dimensional latent space while preserving essential features, enabling efficient reconstruction of the input data.

## Disadvantages:

- Blurry Reconstructions: VAEs often generate blurrier images compared to GANs, particularly in high-detail applications such as traffic scene reconstruction, where the sharpness of features like road signs or vehicle edges is crucial.

- Reconstruction versus Generation Trade-Off: VAEs face a trade-off between accurate reconstruction and diverse generation due to the challenge of balancing the reconstruction and KL loss terms, which may prevent the model from learning meaningful latent patterns.

Future Work: In the future, researchers are expected to develop improved adversarial training paradigms to enhance the reconstruction quality of VAE models. Additionally, efforts should focus on designing optimization mechanisms that automatically address the trade-off between accurate reconstruction and diverse data generation.

## C. DOMAIN ADAPTATION MODELS

This subsection examines the DA models, focusing on their contributions to traffic scene understanding by evaluating their benefits and limitations, and outlining avenues for future research and development.

## 1) CLUSTERING-BASED DOMAIN ADAPTATION

## Advantages:

- Unsupervised Adaptation: Clustering-based DA effectively performs adaptation without requiring labeled target data, making it highly valuable in unsupervised settings.

- Capturing Domain Structure: Clustering-based DA leverages inherent data structures in both the source and target domains, facilitating better alignment of domain distributions through cluster consistency.

## Disadvantages:

- Sensitivity to Cluster Quality: The performance of clustering-based DA depends heavily on the quality of the clusters formed, which can be challenging in complex or noisy domains.

- Difficulty in Handling Domain Overlap: When domains have overlapping distributions, clustering-based methods may struggle to distinguish between source and target domain features.

- Scalability Challenges: As dataset complexity increases, clustering-based DA may struggle to maintain efficiency and effectiveness, particularly with high-dimensional data.

- Reliance on Pseudo-Labels and Prototypes: Clustering-based approaches often leverage pseudo-labels or prototypes for target domain adaptation, which may introduce errors if the initial pseudo-labels are incorrect or the prototypes do not accurately represent cluster centroids. This reliance on pseudo-labels can degrade overall performance, especially in the presence of noisy or ambiguous data.

Future Work: In the future, we expect research to focus on improving the robustness of cluster formation in noisy or overlapping domains, enhancing scalability for large and complex datasets, and exploring novel approaches to integrating clustering with other DA methods to improve performance across diverse tasks.

## 2) DISCREPANCY-BASED DOMAIN ADAPTATION Advantages:

- Explicit Domain Alignment: Discrepancy-based DA methods focus on explicitly minimizing distribution differences between source and target domains in traffic scene data, resulting in more accurate alignment and better adaptation across varied traffic conditions.

- Theoretical Guarantees: Many discrepancy-based approaches come with strong theoretical backing, providing performance guarantees under specific conditions, which increases their reliability.

## Disadvantages:

- Dependence on Metric Choice: The effectiveness of discrepancy-based methods can be highly dependent on the choice of distance metrics, which may not always capture the true differences between complex domain features.

- Limited Adaptation to Complex Shifts: These methods can struggle with more complex domain shifts, such as class imbalance or domain-specific feature distortions, reducing their effectiveness in diverse real-world scenarios.

TABLE 5. Summary of shortcomings and future directions for improvement in Discriminative, Generative, and DA models.

<table><tr><td>Category</td><td>Framework</td><td>Limitations</td><td>Future Works</td></tr><tr><td rowspan="10">Discriminative</td><td>CNN</td><td>- Data dependency - Generalization issues - Limited global contextual understanding</td><td>- Explore semi-supervised and self-supervised learning methods - Integrate attention mechanisms for global dependencies</td></tr><tr><td>Vanilla R-CNN</td><td>- Inefficient region proposal strategy - High Memory Consumption - Lack of End-to-End Training - Challenges with Occlusions</td><td>- Develop efficient region proposal algorithms - Improve the ROI pooling procedure - Develop techniques for improved handling of occluded objects</td></tr><tr><td>Fast R-CNN</td><td>- Inefficient Region Proposal Strategy - Lower Small-Object Detection Accuracy</td><td>- Leverage Faster R-CNN to improve region proposal efficiency - Enhance representational learning with advanced networks like ViT</td></tr><tr><td>Faster R-CNN</td><td>- Limited real-time performance - Being resource-intensive - Lower small-object detection accuracy</td><td>- Develop lighter, more resource-efficient variants - Improve small-object detection</td></tr><tr><td>Mask R-CNN</td><td>- High Computational Demand - Small Object Segmentation Issues - Training Complexity</td><td>- Optimize mask prediction for efficiency - Improve small-object segmentation with multi-scale fusion - Handle occlusions using 3D or multi-view data</td></tr><tr><td>YOLO</td><td>- Difficulty with small objects - Challenges with overlapping Objects - Accuracy trade-offs - Sensitivity to Occlusions</td><td>- Refine grid-based approach and develop post-processing techniques - Improve adaptability to challenging environments - Enhance occlusion handling with robust feature extraction</td></tr><tr><td>ViT</td><td>- Heavy data and computation - Overfitting risk - Training complexity</td><td>- Reduce computational costs - Improve transfer learning and data-efficient training methods</td></tr><tr><td>DETR</td><td>- Slow training convergence - Difficulty with small and occluded ob- jects - Computational overhead</td><td>- Develop more efficient training paradigms - Improve small-object detection - Reduce computational overhead for real-time deployment</td></tr><tr><td>GNN</td><td>- High computational demand - Data preprocessing complexity - Training complexity</td><td>- Develop graph construction process for images - Reduce training complexity - Leverage ViGs for handling occlusions and reconstructing object features - Explore hybrid approaches with self-supervised learning and multi- modal fusion</td></tr><tr><td>CapsNet</td><td>- Computational complexity - Scalability issues</td><td>- Optimize routing-by-agreement mechanism - Enhance scalability for real-world applications</td></tr><tr><td rowspan="3">Generative</td><td>GAN</td><td>- Training instability - Mode collapse risk</td><td>- Develop robust optimization methods - Explore hybrid models and regularization techniques</td></tr><tr><td>cGAN</td><td>- Training complexity - Risk of conditional overfitting - Higher resource requirements</td><td>- Improve regularization techniques - Reduce computational overhead with lightweight architectures</td></tr><tr><td>VAE</td><td>- Blurry reconstructions - Reconstruction vs. generation trade-off</td><td>- Enhance reconstruction quality through adversarial training - Balance accurate reconstruction and diverse generation</td></tr><tr><td rowspan="3">DA</td><td>Clustering</td><td>- Sensitivity to Cluster Quality - Difficulty in Handling Domain Overlap - Scalability Challenges - Reliance on Pseudo-Labels and Proto- types</td><td>- Improve Robustness of Cluster Formation in Noisy Domains - Enhance Scalability for Large Complex Datasets - Integrate Clustering with Other DA Methods</td></tr><tr><td>Discrepancy</td><td>- Dependence on Metric Choice - Limited Adaptation to Complex Shifts - Sensitivity to Feature Representation</td><td>- Develop Flexible Discrepancy Metrics for Complex Domain Shifts - Improve Feature Representation Techniques - Combine Discrepancy-Based Methods with Other Adaptation Strate- gies</td></tr><tr><td>Adversarial</td><td>- Training Instability - Mode Collapse Risk - Sensitive to Hyperparameters</td><td>- Improve Stability of Adversarial Training - Address Mode Collapse Issues - Develop Robust Hyperparameter Tuning Approaches</td></tr></table>

- Sensitivity to Feature Representation: Discrepancy-based approaches often rely on high-quality feature representations. If the feature extraction is inadequate, adaptation performance can suffer.

Future Work: In the future, researchers should explore developing more flexible discrepancy metrics that can handle complex domain shifts, improving feature representation techniques, and exploring hybrid approaches that combine discrepancy-based methods with other adaptation strategies to enhance robustness and generalization across diverse traffic scene understanding tasks.

## 3) ADVERSARIAL-BASED DOMAIN ADAPTATION Advantages:

- Effective Domain Alignment through Discrepancy Minimization: Adversarial-based DA effectively minimizes the discrepancy between source and target domains, allowing for better generalization across different environments.

- No Need for Labeled Target Data: This approach can adapt to the target domain without requiring labeled target data, making it suitable for scenarios where annotations are costly or unavailable.

## Disadvantages:

- Training Instability: The adversarial nature of the model can lead to unstable training, especially when there are significant domain gaps or noisy data.

- Mode Collapse Risk: There is a risk of mode collapse, where the model may fail to capture the full diversity of the target domain, resulting in limited performance in complex tasks.

- Sensitive to Hyperparameters: Performance can be highly sensitive to hyperparameter tuning, requiring careful experimentation and increased computational resources.

Future Work: Future research should aim to improve the stability of adversarial training, address mode collapse issues, and explore more robust approaches to hyperpa-rameter tuning to enhance the scalability and reliability of adversarial-based DA methods across a wider range of tasks.

## VII. FUTURE RESEARCH AREAS

While advancements in DL methods have significantly improved traffic scene understanding, further progress is possible. This section highlights key research topics for future work, emphasizing the need for more reliable, versatile, efficient, and scalable DL frameworks. The performance of these systems, particularly in complex real-world scenarios, hinges on the quality of underlying DL models. Future work should focus on developing models that address practical challenges like real-time performance and generalizability, along with holistic challenges such as integrating multi-modal data and enhancing model interpretability.

Exploring methodologies from diverse domains could boost the robustness and versatility of traffic scene understanding models. For example, disaster management techniques [189] may inspire innovative approaches to traffic analysis. Adapting successful strategies from other fields could improve scalability and reliability. Additionally, integrating real-time algorithms, like the simultaneous vehicle detection and tracking method for aerial videos [190], could enhance the speed and scalability of DL models for urban traffic scene understanding.

## A. XAI

Most computer vision-based deep learning frameworks for traffic scene understanding operate as black-box models, lacking simple or straightforward methods for assessing and interpreting their outputs. This raises concerns regarding the reliability and transparency of such systems, as well as the feasibility of deploying real-world applications that leverage traffic scene understanding for decision-making tasks, such as road safety and risk assessment [191]. The inability to justify decisions based on the vision component's output further complicates their deployment. Especially for downstream applications like autonomous driving, it is preferable to have some mechanism for evaluating how the deep model actually understands a traffic scene, which allows for a domain expert to identify gaps in a model's capabilities. XAI addresses this issue by providing techniques and methodologies-such as post-hoc explanation methods or inherently interpretable architectures-that clarify how inputs influence the model's output. Indeed, for real-world systems such as automated urban intervention systems, which aim to improve pedestrian and vehicle safety by leveraging DNNs for detection, tracking, and behavior prediction, researchers have recently proposed adopting XAI techniques to provide insights into traffic control, surveillance, and collision prevention for autonomous vehicles [192]. Recent research [191] has introduced the interpretability of NNs in traffic sign recognition systems to enhance road safety and optimize traffic management by leveraging XAI techniques like Local Interpretable Model-Agnostic Explanations (LIME) and Gradient-weighted Class Activation Mapping (Grad-CAM). LIME provides explainability by approximating the behavior of a model locally given some predictions, while Grad-CAM generates heat maps that show which regions of an image contribute most to a prediction based on the activated gradients within the deep layers. Moreover, the significance of scene understanding for autonomous vehicles in unstructured traffic environments is emphasized in [193], suggesting the use of models like the Inception U-Net with Grad-CAM visualization to enhance navigation in crowded traffic scenarios.

While XAI has been applied to specific traffic computer vision tasks, significant limitations remain in performance and integration. Improvements are needed for methods like LIME and Grad-CAM, particularly as research shifts from CNN-based learning to ViT and GNN. Most XAI focuses on single-model outputs, overlooking complex systems like multi-target multi-camera tracking. Further exploration is required to integrate XAI into multi-modal systems, as demonstrated by a recent autonomous driving XAI system using multi-modal image captioning for decision-making justification [194]. This opens new possibilities for developing XAI systems that merge text and image data to interpret traffic systems' decision-making. Additionally, integrating XAI for real-time explainability could enhance insights in applications like traffic anomaly detection and object detection, improving robustness in challenging conditions, such as adverse weather segmentation [195].

## B. ENHANCING FEATURE REPRESENTATION WITH NOVEL MODELS

As discussed in this work, transformers and GNNs have gained increasing attention in recent years, with studies showing that ViT and deep GNNs can rival leading CNN architectures while often reducing computational demands [88], [195]. While CNNs have dominated feature extraction in computer vision for over a decade, emerging architectures offer promising opportunities for further advancement. ViT models, for example, require higher-quality data than CNNs due to their lack of inductive bias [196], [197], which historically made CNNs more robust to challenges like occlusion by enforcing local spatial coherence. Influenced by non-local neural networks, ViTs leverage global attention to better handle complex occlusions through long-range dependency modeling. Similarly, GNNs, traditionally limited by over-smoothing in shallow architectures [198], have seen breakthroughs enabling deeper models [199], [200]. Competitive vision GNNs (ViGs), such as the recent model by [195], now match CNN and ViT performance in tasks like classification and detection. GNNs excel at representing graph-structured data, making them effective for reconstructing occluded objects and reasoning about partially visible entities in traffic scenes. Self-supervised learning (SSL) also holds strong potential for these architectures, as methods like contrastive learning [155] enhance performance and robustness, helping mitigate occlusion by fostering holistic representations from incomplete or obstructed data.

## C. REAL-TIME PROCESSING FOR COMPLEX TRAFFIC SCENE UNDERSTANDING

Critically, while many of the models discussed demonstrate strong performance in offline traffic vision tasks, such as object detection, they face significant challenges in real-time processing applications due to inefficiencies. For example, although YOLOv8, one of the most recent versions of the YOLO family and the latest one introduced in this paper, achieves high performance in traffic object detection, the variants still struggle with small-object detection, multi-scale object detection, and detection under adverse environmental conditions [201]. Recent studies have shown that transformer-based architectures can achieve significantly lower latency; however, these models still face difficulties with small-object detection and other challenging conditions [159]. In other domains, researchers have explored the combination of generative models, such as GANs [124], with ViTs [88] to address complex scenarios [202], though further research is necessary to mitigate the high computational costs associated with GANs. For complex traffic scene applications, particularly those involving multiple cameras and downstream decision agents, the underlying deep learning model must be both lightweight and capable of delivering high performance.

## D. ADDRESSING DATA LIMITATIONS WITH HIGH-QUALITY SYNTHETIC DATA

Currently, many widely used datasets for traffic scene understanding tasks consist of synthetic data, such as SYN-THIA [203] and GTA5 [204], which feature automatically annotated images from traffic scenes created in the Unity Game Engine and the GTA 5 game environment. Generative AI and DA are commonly employed to address limitations in training data by generating augmented samples for rare or hard-to-capture scenarios, including occluded objects or accidents under adverse weather conditions [205]. Despite advancements, data from virtual simulations remains limited unless traffic objects behave realistically and scenes feature high-fidelity graphics comparable to real-world data. While some work has pursued generating photo-realistic traffic scenes for computer vision tasks [206], recent improvements in virtual engines enable much higher-quality synthetic data generation with automatic labeling at scale [207]. Enhanced rendering capabilities allow the simulation of diverse traffic scenarios, including challenging conditions like rain, snow, or occlusion-heavy nighttime settings. For tasks with limited data or imbalances, synthetic data can help improve model performance on occluded objects and other real-world challenges, reducing reliance on manual annotation. Finally, integrating simulated data with generative augmentation techniques [208] presents a promising approach to mitigate data scarcity while addressing occlusion-related challenges in traffic scene understanding.

## E. IMPROVING PERCEPTION USING MULTI-MODALITY AND DATA FUSION

The robustness and comprehensiveness of object detection and segmentation in traffic scenes could be significantly enhanced by leveraging the fusion of data from multimodal sensory inputs, such as panoramic images, LiDAR (Light Detection and Ranging) point clouds, thermal imaging, infrared, and video footage. Additionally, incorporating the sophisticated reasoning capabilities of large language models (LLMs) and multimodal LLMs (MLLMs) [209], [210], [211] could facilitate the integration of real-time text-based and linguistic communication with image and video data [212]. Furthermore, although [213] has made progress in applying language-based knowledge guidance, most research focuses on data fusion in only two domains [214], [215], [216]. A comprehensive benchmark is essential for effectively comparing these works and advancing the development of more optimized and holistic multimodal approaches. Effective multi-sensor data fusion is critical. Designing, assessing, and optimizing the performance of fusion operations for deep generative models are key questions. Interoperability of different multi-modality methods [217] with existing infrastructure and their adaptability to evolving traffic conditions will be crucial for their successful implementation. Recent research, such as Feng et al. [217], emphasizes that multi-modal sensor fusion (e.g., LiDAR, cameras, radar) enhances robustness in object detection by addressing challenges like occlusion and adverse conditions. By effectively integrating complementary information from diverse sensor inputs, occluded objects can be more reliably detected and classified, thereby overcoming one of the significant limitations of single-modality perception approaches.

## VIII. CONCLUSION

In conclusion, this review has provided an extensive exploration of deep learning models and their application to traffic scene understanding, a crucial component in advancing intelligent transportation systems. By categorizing and analyzing discriminative, generative, and domain adaptation models, we have offered a comprehensive perspective on the evolution of traffic scene analysis techniques, highlighting the significant advancements and ongoing challenges in the field. Our discussion on hyperparameter optimization has further emphasized the importance of fine-tuning these models for enhanced efficiency and real-time applicability.

This paper has addressed the gaps present in existing literature, such as the lack of focus on generative models, limited coverage of domain adaptation techniques, and insufficient analysis of hyperparameter optimization methods. By presenting a structured comparison of discriminative, generative, and DA models, we provided a nuanced understanding of each category's strengths and weaknesses, which can guide researchers in selecting appropriate models for their specific needs in traffic scene analysis. Furthermore, our review identified emerging areas such as XAI, multi-modal data integration, and real-time processing as pivotal research directions for future work.

Moving forward, it is evident that there is a growing need to enhance the robustness, interpretability, and efficiency of deep learning systems in traffic environments. We encourage future research efforts to focus on improving model performance under diverse environmental conditions, integrating multiple data sources for richer scene understanding, and advancing explainability to foster trust in AI-driven transportation systems. By addressing these challenges, we believe that deep learning will continue to play a pivotal role in shaping the future of intelligent, safe, and efficient transportation solutions. REFERENCES

[1] A. Boukerche and Z. Hou, "Object detection using deep learning methods in traffic scenarios," ACM Comput. Surv., vol. 54, no. 2, pp. 1-35, Mar. 2021.

[2] Y. Huang and Y. Chen, "Autonomous driving with deep learning: A survey of state-of-art technologies," 2020, arXiv:2006.06091.

[3] Z. Guo, Y. Huang, X. Hu, H. Wei, and B. Zhao, "A survey on deep learning based approaches for scene understanding in autonomous driving," Electronics, vol. 10, no. 4, p. 471, Feb. 2021.

[4] S. Grigorescu, B. Trasnea, T. Cocias, and G. Macesanu, "A survey of deep learning techniques for autonomous driving," J. Field Robot., vol. 37, no. 3, pp. 362-386, Apr. 2020.

[5] Y. Lecun, L. Bottou, Y. Bengio, and P. Haffner, "Gradient-based learning applied to document recognition," Proc. IEEE, vol. 86, no. 11, pp. 2278-2324, 1998.

[6] R. C. Luo, H. Potlapalli, and D. W. Hislop, "Translation and scale invariant landmark recognition using receptive field neural networks," in Proc. IEEE/RSJ Int. Conf. Intell. Robots Syst., vol. 1, Jun. 1992, pp. 527-533, doi: 10.1109/IROS.1992.587385.

[7] P. Sermanet and Y. LeCun, "Traffic sign recognition with multi-scale convolutional networks," in Proc. Int. Joint Conf. Neural Netw., Jul. 2011, pp. 2809-2813, doi: 10.1109/IJCNN.2011.6033589.

[8] R. Fan, H. Wang, P. Cai, and M. Liu, "SNE-RoadSeg: Incorporating surface normal information into semantic segmentation for accurate freespace detection," in Proc. Eur. Conf. Comput. Vis. Cham, Switzerland: Springer, Jan. 2020, pp. 340-356.

[9] J. He, C. Zhang, X. He, and R. Dong, "Visual recognition of traffic police gestures with convolutional pose machine and handcrafted features," Neurocomputing, vol. 390, pp. 248-259, May 2020.

[10] R. Girshick, J. Donahue, T. Darrell, and J. Malik, "Rich feature hierarchies for accurate object detection and semantic segmentation," in Proc. IEEE Conf. Comput. Vis. Pattern Recognit., Jun. 2014, pp. 580-587.

[11] G. Vinod and G. Padmapriya, "An adaptable real-time object detection for traffic surveillance using R-CNN over CNN with improved accuracy," in Proc. Int. Conf. Bus. Anal. Technol. Secur. (ICBATS), Feb. 2022, pp. 1-4, doi: 10.1109/ICBATS54253.2022.9759030.

[12] J. Hosang, M. Omran, R. Benenson, and B. Schiele, "Taking a deeper look at pedestrians," in Proc. IEEE Conf. Comput. Vis. Pattern Recognit. (CVPR), Jun. 2015, pp. 4073-4082, doi: 10.1109/CVPR.2015.7299034.

[13] V. Murugan, V. R. Vijaykumar, and A. Nidhila, "A deep learning RCNN approach for vehicle recognition in traffic surveillance system," in Proc. Int. Conf. Commun. Signal Process. (ICCSP), Apr. 2019, pp. 157-160.

[14] J. Zhang, Z. Xie, J. Sun, X. Zou, and J. Wang, "A cascaded R-CNN with multiscale attention and imbalanced samples for traffic sign detection," IEEE Access, vol. 8, pp. 29742-29754, 2020.

[15] J. Cao, J. Zhang, and X. Jin, "A traffic-sign detection algorithm based on improved sparse R-CNN," IEEE Access, vol. 9, pp. 122774-122788, 2021, doi: 10.1109/ACCESS.2021.3109606.

[16] C. Lin, Y. Shi, J. Zhang, C. Xie, W. Chen, and Y. Chen, "An anchor-free detector and R-CNN integrated neural network architecture for environmental perception of urban roads," Proc. Inst. Mech. Eng., D, J. Automobile Eng., vol. 235, no. 12, pp. 2964-2973, Oct. 2021.

[17] P. Li, Y. He, D. Yin, F. R. Yu, and P. Song, "Bagging R-CNN: Ensemble for object detection in complex traffic scenes," in Proc. IEEE Int. Conf. Acoust., Speech Signal Process. (ICASSP), Jun. 2023, pp. 1-5, doi: 10.1109/ICASSP49357.2023.10097085.

[18] T. Liang, H. Bao, W. Pan, and F. Pan, "Traffic sign detection via improved sparse R-CNN for autonomous vehicles," J. Adv. Transp., vol. 2022, pp. 1-16, Mar. 2022.

[19] M. Takahashi, K. Iino, H. Watanabe, I. Morinaga, S. Enomoto, X. Shi, A. Sakamoto, and T. Eda, "Category-based memory bank design for traffic surveillance in context R-CNN," Proc. SPIE, vol. 12592, Mar. 2023, Art. no. 125920G, doi: 10.1117/12.2666991.

[20] P. Sun, R. Zhang, Y. Jiang, T. Kong, C. Xu, W. Zhan, M. Tomizuka, L. Li, Z. Yuan, C. Wang, and P. Luo, "Sparse R-CNN: End-to-end object detection with learnable proposals," in Proc. IEEE/CVF Conf. Com-put. Vis. Pattern Recognit. (CVPR), Jun. 2021, pp. 14449-14458.

[21] Z. Liu, Y. Lin, Y. Cao, H. Hu, Y. Wei, Z. Zhang, S. Lin, and B. Guo, "Swin transformer: Hierarchical vision transformer using shifted windows," in Proc. IEEE/CVF Int. Conf. Comput. Vis. (ICCV), Oct. 2021, pp. 9992-10002.

[22] R. Girshick, "Fast R-CNN," in Proc. IEEE Int. Conf. Comput. Vis. (ICCV), Dec. 2015, pp. 1440-1448.

[23] K. Simonyan and A. Zisserman, "Very deep convolutional networks for large-scale image recognition," 2014, arXiv:1409.1556.

[24] K. He, X. Zhang, S. Ren, and J. Sun, "Spatial pyramid pooling in deep convolutional networks for visual recognition," in Proc. Eur. Conf. Com-put. Vis., vol. 37. Cham, Switzerland: Springer, Jan. 2014, pp. 1904-1916.

[25] R. Qian, Q. Liu, Y. Yue, F. Coenen, and B. Zhang, "Road surface traffic sign detection with hybrid region proposal and fast R-CNN," in Proc. 12th Int. Conf. Natural Comput., Fuzzy Syst. Knowl. Discovery (ICNC-FSKD), Aug. 2016, pp. 555-559, doi: 10.1109/FSKD.2016.7603233.

[26] Z. Zhang, K. Liu, F. Gao, X. Li, and G. Wang, "Vision-based vehicle detecting and counting for traffic flow analysis," in Proc. Int. Joint Conf. Neural Netw. (IJCNN), Jul. 2016, pp. 2267-2273, doi: 10.1109/IJCNN.2016.7727480.

[27] Z. Moayed, A. Griffin, and R. Klette, "Traffic intersection monitoring using fusion of GMM-based deep learning classification and geometric warping," in Proc. Int. Conf. Image Vis. Comput. New Zealand (IVCNZ), Dec. 2017, pp. 1-5, doi: 10.1109/IVCNZ.2017.8402465.

[28] X. Li, L. Li, F. Flohr, J. Wang, H. Xiong, M. Bernhard, S. Pan, D. M. Gavrila, and K. Li, "A unified framework for concurrent pedestrian and cyclist detection," IEEE Trans. Intell. Transp. Syst., vol. 18, no. 2, pp. 269-281, Feb. 2017, doi: 10.1109/TITS.2016.2567418.

[29] K. S. Htet and M. M. Sein, "Event analysis for vehicle classification using fast RCNN," in Proc. IEEE 9th Global Conf. Consum. Electron. (GCCE), Oct. 2020, pp. 403-404, doi: 10.1109/GCCE50665.2020.9291978.

[30] A. Ali, O. G. Olaleye, B. Dey, and M. Bayoumi, "Fast deep pyramid DPM object detection with region proposal networks," in Proc. IEEE Int. Symp. Signal Process. Inf. Technol. (ISSPIT), Dec. 2017, pp. 168-173, doi: 10.1109/ISSPIT.2017.8388636.

[31] K. Wang and W. Zhou, "Pedestrian and cyclist detection based on deep neural network fast R-CNN," Int. J. Adv. Robot. Syst., vol. 16, no. 2, Mar. 2019, doi: 10.1177/1729881419829651.

[32] N. Arora, Y. Kumar, R. Karkra, and M. Kumar, "Automatic vehicle detection system in different environment conditions using fast R-CNN," Multimedia Tools Appl., vol. 81, no. 13, pp. 18715-18735, May 2022, doi: 10.1007/s11042-022-12347-8.

[33] S. Ren, K. He, R. Girshick, and J. Sun, "Faster R-CNN: Towards real-time object detection with region proposal networks," in Proc. IEEE Conf. Comput. Vis. Pattern Recognit., Jun. 2015, pp. 1-14.

[34] C. Guindel, D. Martin, and J. M. Armingol, "Fast joint object detection and viewpoint estimation for traffic scene understanding," IEEE Intell. Transp. Syst. Mag., vol. 10, no. 4, pp. 74-86, Winter. 2018.

[35] K. Qiao, H. Gu, J. Liu, and P. Liu, "Optimization of traffic sign detection and classification based on faster R-CNN," in Proc. Int. Conf. Com-put. Technol., Electron. Commun. (ICCTEC), Dec. 2017, pp. 608-611, doi: 10.1109/ICCTEC.2017.00137.

[36] G. Wang and X. Ma, "Traffic police gesture recognition using RGB-D and faster R-CNN," in Proc. Int. Conf. Intell. Informat. Biomed. Sci. (ICIIBMS), vol. 3, Oct. 2018, pp. 78-81, doi: 10.1109/ICIIBMS.2018.8549975.

[37] T. Liu and T. Stathaki, "Faster R-CNN for robust pedestrian detection using semantic segmentation network," Frontiers Neurorobotics, vol. 12, p. 64, Oct. 2018, doi: 10.3389/fnbot.2018.00064.

[38] A. Mhalla, T. Chateau, S. Gazzah, and N. E. B. Amara, "An embedded computer-vision system for multi-object detection in traffic surveillance," IEEE Trans. Intell. Transp. Syst., vol. 20, no. 11, pp. 4006-4018, Nov. 2019, doi: 10.1109/TITS.2018.2876614.

[39] M. Zinanyuca and D. Arce, "Traffic parameters acquisition system using faster R-CNN deep learning based algorithm," in Proc. IEEE ANDESCON, Oct. 2020, pp. 1-6, doi: 10.1109/ANDESCON50619.2020.9271996.

[40] X. Gao, L. Chen, K. Wang, X. Xiong, H. Wang, and Y. Li, "Improved traffic sign detection algorithm based on faster R-CNN," Appl. Sci., vol. 12, no. 18, p. 8948, Sep. 2022, doi: 10.3390/app12188948.

[41] Y. Cui and D. Lei, "Optimizing Internet of Things-based intelligent transportation system's information acquisition using deep learning," IEEE Access, vol. 11, pp. 11804-11810, 2023, doi: 10.1109/ACCESS.2023.3242116.

[42] C. Cao, B. Wang, W. Zhang, X. Zeng, X. Yan, Z. Feng, Y. Liu, and Z. Wu, "An improved faster R-CNN for small object detection," IEEE Access, vol. 7, pp. 106838-106846, 2019, doi: 10.1109/ACCESS.2019.2932731.

[43] W. Liu, D. Anguelov, D. Erhan, C. Szegedy, S. Reed, C.-Y. Fu, and A. C. Berg, "SSD: Single shot MultiBox detector," in Computer Vision-ECCV 2016, B. Leibe, J. Matas, N. Sebe, and M. Welling, Eds., Cham, Switzerland: Springer, 2016, pp. 21-37.

[44] J. Redmon, S. Divvala, R. Girshick, and A. Farhadi, "You only look once: Unified, real-time object detection," in Proc. IEEE Conf. Com-put. Vis. Pattern Recognit. (CVPR), Jun. 2016, pp. 779-788.

[45] T. Jin, D. Zhang, F. Ding, Z. Zhang, and M. Zhang, "A vehicle detection algorithm in complex traffic scenes," Proc. SPIE, vol. 11519, Jun. 2020, Art. no. 115190C, doi: 10.1117/12.2573189.

[46] J. Redmon and A. Farhadi, "YOLO9000: Better, faster, stronger," in Proc. IEEE Conf. Comput. Vis. Pattern Recognit. (CVPR), Jul. 2017, pp. 6517-6525.

[47] J. Redmon and A. Farhadi, "YOLOv3: An incremental improvement," in Proc. Comput. Vis. Pattern Recognit., Jan. 2018. [Online]. Available: https://arxiv.org/abs/1804.02767

[48] Ultralytics. (2020). YOLOv5. [Online]. Available: https://github.com/ ultralytics/yolov5

[49] X. Li, Z. Xie, X. Deng, Y. Wu, and Y. Pi, "Traffic sign detection based on improved faster R-CNN for autonomous driving," J. Supercomput., vol. 78, no. 6, pp. 7982-8002, Apr. 2022, doi: 10.1007/s11227-021- 04230-4.

[50] R. Hu, H. Li, D. Huang, X. Xu, and K. He, "Traffic sign detection based on driving sight distance in haze environment," IEEE Access, vol. 10, pp. 101124-101136, 2022, doi: 10.1109/ACCESS.2022.3208108.

[51] K. He, G. Gkioxari, P. Dollár, and R. Girshick, "Mask R-CNN," in Proc. IEEE Int. Conf. Comput. Vis. (ICCV), Oct. 2017, pp. 2980-2988.

[52] S. Sarp, M. Kuzlu, M. Cetin, C. Sazara, and O. Guler, "Detecting floodwater on roadways from image data using mask-R-CNN," in Proc. Int. Conf. Innov. Intell. Syst. Appl. (INISTA), Aug. 2020, pp. 1-6, doi: 10.1109/INISTA49547.2020.9194655.

[53] E. H.-C. Lu, M. Gozdzikiewicz, K.-H. Chang, and J.-M. Ciou, "A hierarchical approach for traffic sign recognition based on shape detection and image classification," Sensors, vol. 22, no. 13, p. 4768, Jun. 2022, doi: 10.3390/s22134768.

[54] D. He, Y. Qiu, J. Miao, Z. Zou, K. Li, C. Ren, and G. Shen, "Improved mask R-CNN for obstacle detection of rail transit," Measurement, vol. 190, Feb. 2022, Art. no. 110728.

[55] L. Lou, Q. Zhang, C. Liu, M. Sheng, J. Liu, and H. Song, "Detecting and counting the moving vehicles using mask R-CNN," in Proc. IEEE 8th Data Driven Control Learn. Syst. Conf. (DDCLS), May 2019, pp. 987-992.

[56] E. J. Piedad, T.-T. Le, K. Aying, F. K. Pama, and I. Tabale, "Vehicle count system based on time interval image capture method and deep learning mask R-CNN," in Proc. IEEE Region 10 Conf. (TENCON), Oct. 2019, pp. 2675-2679.

[57] H. Tahir, M. Shahbaz Khan, and M. Owais Tariq, "Performance analysis and comparison of faster R-CNN, mask R-CNN and ResNet50 for the detection and counting of vehicles," in Proc. Int. Conf. Com-put., Commun., Intell. Syst. (ICCCIS), Feb. 2021, pp. 587-594, doi: 10.1109/icccis51004.2021.9397079.

[58] C. Sazara, M. Cetin, and K. Iftekharuddin, "Image dataset for roadway flooding," Mendeley Data, Amsterdam, The Netherlands, Tech. Rep. V1, 2019. Accessed: Aug. 15, 2024.

[59] C. Sazara, M. Cetin, and K. M. Iftekharuddin, "Detecting floodwater on roadways from image data with handcrafted features and deep transfer learning," in Proc. IEEE Intell. Transp. Syst. Conf. (ITSC), Oct. 2019, pp. 804-809, doi: 10.1109/ITSC.2019.8917368.

[60] F. Chollet, "Xception: Deep learning with depthwise separable convolutions," in Proc. IEEE Conf. Comput. Vis. Pattern Recognit. (CVPR), Jul. 2017, pp. 1800-1807.

[61] G. Jocher. (May 2020). YOLOv5 by Ultralytics. [Online]. Available: https://github.com/ultralytics/

[62] J.-P. Lin and M.-T. Sun, "A YOLO-based traffic counting system," in Proc. Conf. Technol. Appl. Artif. Intell. (TAAI), Nov. 2018, pp. 82-85, doi: 10.1109/TAAI.2018.00027.

[63] M. B. Jensen, K. Nasrollahi, and T. B. Moeslund, "Evaluating state-of-the-art object detector on challenging traffic light data," in Proc. IEEE Conf. Comput. Vis. Pattern Recognit. Workshops (CVPRW), Jul. 2017, pp. 882-888, doi: 10.1109/CVPRW.2017.122.

[64] S. P. Rajendran, L. Shine, R. Pradeep, and S. Vijayaraghavan, "Real-time traffic sign recognition using YOLOv3 based detector," in Proc. 10th Int. Conf. Comput., Commun. Netw. Technol. (ICCCNT), Jul. 2019, pp. 1-7, doi: 10.1109/ICCCNT45670.2019.8944890.

[65] J. Yu, X. Ye, and Q. Tu, "Traffic sign detection and recognition in multiimages using a fusion model with YOLO and VGG network," IEEE Trans. Intell. Transp. Syst., vol. 23, no. 9, pp. 16632-16642, Sep. 2022, doi: 10.1109/TITS.2022.3170354.

[66] Z. Yang, J. Li, and H. Li, "Real-time pedestrian and vehicle detection for autonomous driving," in Proc. IEEE Intell. Vehicles Symp. (IV), Jun. 2018, pp. 179-184, doi: 10.1109/IVS.2018.8500642.

[67] A. Corovic, V. Ilic, S. Duric, M. Marijan, and B. Pavkovic, "The real-time detection of traffic participants using YOLO algorithm," in Proc. 26th Telecommun. Forum (TELFOR), Nov. 2018, pp. 1-4, doi: 10.1109/TELFOR.2018.8611986.

[68] W. Song and S. A. Suandi, "TSR-YOLO: A Chinese traffic sign recognition algorithm for intelligent vehicles in complex scenes," Sensors, vol. 23, no. 2, p. 749, Jan. 2023, doi: 10.3390/s23020749.

[69] L. Xiaomeng, F. Jun, and C. Peng, "Vehicle detection in traffic monitoring scenes based on improved YOLOV5s," in Proc. Int. Conf. Comput. Eng. Artif. Intell. (ICCEAI), Jul. 2022, pp. 467-471, doi: 10.1109/ICCEAI55464.2022.00103.

[70] S. Zhang, S. Che, Z. Liu, and X. Zhang, "A real-time and lightweight traffic sign detection method based on ghost-YOLO," Multimedia Tools Appl., vol. 82, no. 17, pp. 26063-26087, Jul. 2023, doi: 10.1007/s11042- 023-14342-z.

[71] C. Sinthia and Md. H. Kabir, "Detection and recognition of Bangladeshi vehicles' nameplates using YOLOV6 and BLPNET," in Proc. Int. Conf. Electr:, Comput. Commun. Eng. (ECCE), Feb. 2023, pp. 1-6.

[72] T. Suwattanapunkul and L.-J. Wang, "The efficient traffic sign detection and recognition for Taiwan road using YOLO model with hybrid dataset," in Proc. 9th Int. Conf. Appl. Syst. Innov. (ICASI), Apr. 2023, pp. 160-162, doi: 10.1109/ICASI57738.2023.10179493.

[73] D. Shokri, C. Larouche, and S. Homayouni, "A comparative analysis of multi-label deep learning classifiers for real-time vehicle detection to support intelligent transportation systems," Smart Cities, vol. 6, no. 5, pp. 2982-3004, Oct. 2023.

[74] J. Deng, W. Dong, R. Socher, L.-J. Li, K. Li, and L. Fei-Fei, "ImageNet: A large-scale hierarchical image database," in Proc. IEEE Conf. Comput. Vis. Pattern Recognit., Jun. 2009, pp. 248-255.

[75] A. Bochkovskiy, C.-Y. Wang, and H.-Y. M. Liao, "YOLOv4: Optimal speed and accuracy of object detection," 2020, arXiv:2004.10934.

[76] C. Dewi, R.-C. Chen, X. Jiang, and H. Yu, "Deep convolutional neural network for enhancing traffic sign recognition developed on YOLO V4," Multimedia Tools Appl., vol. 81, no. 26, pp. 37821-37845, Nov. 2022, doi: 10.1007/s11042-022-12962-5.

[77] A. Gomaa and A. Abdalrazik, "Novel deep learning domain adaptation approach for object detection using semi-self building dataset and modified YOLOv4," World Electr. Vehicle J., vol. 15, no. 6, p. 255, Jun. 2024.

[78] X. Ding, X. Zhang, N. Ma, J. Han, G. Ding, and J. Sun, "RepVGG: Making VGG-style ConvNets great again," in Proc. IEEE/CVF Conf. Comput. Vis. Pattern Recognit. (CVPR), Jun. 2021, pp. 13728-13737.

[79] C. Li, L. Li, H. Jiang, K. Weng, Y. Geng, L. Li, Z. Ke, Q. Li, M. Cheng, W. Nie, Y. Li, B. Zhang, Y. Liang, L. Zhou, X. Xu, X. Chu, X. Wei, and X. Wei, "YOLOv6: A single-stage object detection framework for industrial applications," 2022, arXiv:2209.02976.

[80] C.-Y. Wang, A. Bochkovskiy, and H.-Y.-M. Liao, "YOLOv7: Trainable bag-of-freebies sets new state-of-the-art for real-time object detectors," in Proc. IEEE/CVF Conf. Comput. Vis. Pattern Recognit. (CVPR), Los Alamitos, CA, USA, Jun. 2023, pp. 7464-7475.

[81] H. Zhang, Y. Ruan, A. Huo, and X. Jiang, "Traffic sign detection based on improved YOLOv7," in Proc. 5th Int. Conf. Intell. Control, Meas. Signal Process. (ICMSP), May 2023, pp. 71-75, doi: 10.1109/ICMSP58539.2023.10170868.

[82] L. Kantorovitch, "On the translocation of masses," Manage. Sci., vol. 5, no. 1, pp. 1-4, Oct. 1958.

[83] G. Jocher, A. Chaurasia, and J. Qiu. (2023). Ultralytics YOLOv8.

[84] A. Ammar, A. Koubaa, M. Ahmed, A. Saad, and B. Benjdira, "Vehicle detection from aerial images using deep learning: A comparative study," Electronics, vol. 10, no. 7, p. 820, Mar. 2021.

[85] H. Zunair, S. Khan, and A. Ben Hamza, "RSUD20K: A dataset for road scene understanding in autonomous driving," 2024, arXiv:2401. 07322.

[86] Z. Wang, S. Yang, H. Qin, Y. Liu, and J. Ding, "CCW-YOLO: A modified YOLOv5s network for pedestrian detection in complex traffic scenes," Information, vol. 15, no. 12, p. 762, Dec. 2024.

[87] Z. Chen, K. Yang, Y. Wu, H. Yang, and X. Tang, "HCLT-YOLO: A hybrid CNN and lightweight transformer architecture for object detection in complex traffic scenes," IEEE Trans. Veh. Technol., early access, Nov. 12, 2024, doi: 10.1109/TVT.2024.3496513.

[88] A. Dosovitskiy, L. Beyer, A. Kolesnikov, D. Weissenborn, X. Zhai, T. Unterthiner, M. Dehghani, M. Minderer, G. Heigold, S. Gelly, J. Uszkoreit, and N. Houlsby,"An image is worth ${16} \times  {16}$ words: Transformers for image recognition at scale," 2020, arXiv:2010.11929.

[89] A. Abdelraouf, M. Abdel-Aty, and Y. Wu, "Using vision transformers for spatial-context-aware rain and road surface condition detection on freeways," IEEE Trans. Intell. Transp. Syst., vol. 23, no. 10, pp. 18546-18556, Oct. 2022.

[90] S. Zhao, H. Li, Q. Ke, L. Liu, and R. Zhang, "Action-ViT: Pedestrian intent prediction in traffic scenes," IEEE Signal Process. Lett., vol. 29, pp. 324-328, 2022.

[91] M. Kang, W. Lee, K. Hwang, and Y. Yoon, "Vision transformer for detecting critical situations and extracting functional scenario for automated vehicle safety assessment," Sustainability, vol. 14, no. 15, p. 9680, Aug. 2022.

[92] J. Wurst, L. Balasubramanian, M. Botsch, and W. Utschick, "Novelty detection and analysis of traffic scenario infrastructures in the latent space of a vision transformer-based triplet autoencoder," in Proc. IEEE Intell. Vehicles Symp. (IV), Jul. 2021, pp. 1304-1311.

[93] J. Wurst, A. F. Fernández, M. Botsch, and W. Utschick, "An entropy based outlier score and its application to novelty detection for road infrastructure images," in Proc. IEEE Intell. Vehicles Symp. (IV), Oct. 2020, pp. 1436-1443.

[94] N. Carion, F. Massa, G. Synnaeve, N. Usunier, A. Kirillov, and S. Zagoruyko, "End-to-end object detection with transformers," in Proc. Eur. Conf. Comput. Vis., Jan. 2020, pp. 213-229.

[95] J. Xia, M. Li, W. Liu, and X. Chen, "DSRA-DETR: An improved DETR for multiscale traffic sign detection," Sustainability, vol. 15, no. 14, p. 10862, Jul. 2023.

[96] H. Wei, Q. Zhang, Y. Qian, Z. Xu, and J. Han, "MTSDet: Multi-scale traffic sign detection with attention and path aggregation," Appl. Intell., vol. 53, no. 1, pp. 238-250, Jan. 2023.

[97] P. Gao, M. Zheng, X. Wang, J. Dai, and H. Li, "Fast convergence of DETR with spatially modulated co-attention," in Proc. IEEE/CVF Int. Conf. Comput. Vis. (ICCV), Oct. 2021, pp. 3601-3610.

[98] T. Liang, H. Bao, W. Pan, X. Fan, and H. Li, "DetectFormer: Category-assisted transformer for traffic scene object detection," Sensors, vol. 22, no. 13, p. 4833, Jun. 2022.

[99] T. N. Kipf and M. Welling, "Semi-supervised classification with graph convolutional networks," 2016, arXiv:1609.02907.

[100] S. Mylavarapu, M. Sandhu, P. Vijayan, K. M. Krishna, B. Ravindran, and A. Namboodiri, "Towards accurate vehicle behaviour classification with multi-relational graph convolutional networks," in Proc. IEEE Intell. Vehicles Symp. (IV), Oct. 2020, pp. 321-327.

[101] K. Liu, Y. Zheng, J. Yang, H. Bao, and H. Zeng, "Chinese traffic police gesture recognition based on graph convolutional network in natural scene," Appl. Sci., vol. 11, no. 24, p. 11951, Dec. 2021.

[102] Z. Fang, W. Zhang, Z. Guo, R. Zhi, B. Wang, and F. Flohr, "Traffic police gesture recognition by pose graph convolutional networks," in Proc. IEEE Intell. Vehicles Symp. (IV), Oct. 2020, pp. 1833-1838.

[103] J. Lian, Z. Wang, L. Li, and Y. Zhou, "The understanding of traffic police intention based on visual awareness," Neural Process. Lett., vol. 54, no. 4, pp. 2843-2859, Aug. 2022.

[104] F. Xu, F. Xu, J. Xie, C.-M. Pun, H. Lu, and H. Gao, "Action recognition framework in traffic scene for autonomous driving system," IEEE Trans. Intell. Transp. Syst., vol. 23, no. 11, pp. 22301-22311, Nov. 2022.

[105] Z. Cao, G. Hidalgo, T. Simon, S.-E. Wei, and Y. Sheikh, "OpenPose: Realtime multi-person 2D pose estimation using part affinity fields," IEEE Trans. Pattern Anal. Mach. Intell., vol. 43, no. 1, pp. 172-186, Jan. 2021.

[106] P. Veličković, G. Cucurull, A. Casanova, A. Romero, P. Lió, and Y. Bengio, "Graph attention networks," 2017, arXiv:1710.10903.

[107] P. N. Chowdhury, P. Shivakumara, S. Kanchan, R. Raghavendra, U. Pal, T. Lu, and D. Lopresti, "Graph attention network for detecting license plates in crowded street scenes," Pattern Recognit. Lett., vol. 140, pp. 18-25, Dec. 2020, doi: 10.1016/j.patrec.2020.09.018.

[108] Z. Wang, Z. Li, J. Leng, M. Li, and L. Bai, "Multiple pedestrian tracking with graph attention map on urban road scene," IEEE Trans. Intell. Transp. Syst., vol. 24, no. 8, pp. 8567-8579, Aug. 2023.

[109] T. Monninger, J. Schmidt, J. Rupprecht, D. Raba, J. Jordan, D. Frank, S. Staab, and K. Dietmayer, "SCENE: Reasoning about traffic scenes using heterogeneous graph neural networks," IEEE Robot. Autom. Lett., vol. 8, no. 3, pp. 1531-1538, Mar. 2023.

[110] K. Xu, W. Hu, J. Leskovec, and S. Jegelka, "How powerful are graph neural networks?" 2018, arXiv:1810.00826.

[111] A. V. Malawade, S.-Y. Yu, B. Hsu, H. Kaeley, A. Karra, and M. A. A. Faruque, "roadscene2vec: A tool for extracting and embedding road scene-graphs," Knowl.-Based Syst., vol. 242, Apr. 2022, Art. no. 108245.

[112] G. A. Noghre, V. Katariya, A. D. Pazho, C. Neff, and H. Tabkhi, "Pishgu: Universal path prediction network architecture for real-time cyber-physical edge systems," 2022, arXiv:2210.08057.

[113] Y. Tian, A. Carballo, R. Li, and K. Takeda, "RSG-search: Semantic traffic scene retrieval using graph-based scene representation," in Proc. IEEE Intell. Vehicles Symp. (IV), Jun. 2023, pp. 1-8.

[114] J. Wurst, L. Balasubramanian, M. Botsch, and W. Utschick, "Expert-LaSTS: Expert-knowledge guided latent space for traffic scenarios," in Proc. IEEE Intell. Vehicles Symp. (IV), Jun. 2022, pp. 484-491.

[115] M. Mendieta and H. Tabkhi, "CARPe posterum: A convolutional approach for real-time pedestrian path prediction," in Proc. AAAI Conf. Artif. Intell., May 2021, vol. 35, no. 3, pp. 2346-2354.

[116] S. Sabour, N. Frosst, and G. E. Hinton, "Dynamic routing between capsules," in Proc. Adv. Neural Inf. Process. Syst., vol. 30, Jan. 2017, pp. 3859-3869.

[117] A. Dinesh Kumar, "Novel deep learning model for traffic sign detection using capsule networks," 2018, arXiv:1805.04424.

[118] X. Liu, W. Q. Yan, and N. Kasabov, "Vehicle-related scene segmentation using CapsNets," in Proc. 35th Int. Conf. Image Vis. Comput. New Zealand (IVCNZ), Nov. 2020, pp. 1-6, doi: 10.1109/IVCNZ51579.2020.9290664.

[119] Z. Hao, "The method of recognizing traffic signs based on the improved capsule network," in Proc. Int. Conf. Comput. Eng. Intell. Control (ICCEIC), Nov. 2020, pp. 22-26.

[120] X. Liu and W. Q. Yan, "Traffic-light sign recognition using capsule network," Multimedia Tools Appl., vol. 80, no. 10, pp. 15161-15171, Apr. 2021, doi: 10.1007/s11042-020-10455-x.

[121] W. Yang and W. Zhang, "Real-time traffic signs detection based on YOLO network model," in Proc. Int. Conf. Cyber-Enabled Dis-trib. Comput. Knowl. Discovery (CyberC), Oct. 2020, pp. 354-357, doi: 10.1109/CyberC49757.2020.00066.

[122] Y. Liu, G. Shi, Y. Li, and Z. Zhao, "M-YOLO: Traffic sign detection algorithm applicable to complex scenarios," Symmetry, vol. 14, no. 5, p. 952, May 2022, doi: 10.3390/sym14050952.

[123] C. Dewi, R.-C. Chen, Y.-T. Liu, X. Jiang, and K. D. Hartomo, "YOLO V4 for advanced traffic sign recognition with synthetic training data generated by various GAN," IEEE Access, vol. 9, pp. 97228-97242, 2021, doi: 10.1109/ACCESS.2021.3094201.

[124] I. Goodfellow, J. Pouget-Abadie, M. Mirza, B. Xu, D. Warde-Farley, S. Ozair, A. Courville, and Y. Bengio, "Generative adversarial nets," in Advances in Neural Information Processing Systems, vol. 27, Z. Ghahra-mani, M. Welling, C. Cortes, N. Lawrence, and K. Q. Weinberger, Eds., Red Hook, NY, USA: Curran Associates, 2014.

[125] K. Zhang, X. Feng, N. Jia, L. Zhao, and Z. He, "TSR-GAN: Generative adversarial networks for traffic state reconstruction with time space diagrams," Phys. A, Stat. Mech. Appl., vol. 591, Apr. 2022, Art. no. 126788.

[126] P. König, S. Aigner, and M. Körner, "Enhancing traffic scene predictions with generative adversarial networks," in Proc. IEEE Intell. Transp. Syst. Conf. (ITSC), Oct. 2019, pp. 1768-1775.

[127] Y. Cai, L. Dai, H. Wang, and Z. Li, "Multi-target pan-class intrinsic relevance driven model for improving semantic segmentation in autonomous driving," IEEE Trans. Image Process., vol. 30, pp. 9069-9084, 2021.

[128] W. Xu, N. Souly, and P. P. Brahma, "Reliability of GAN generated data to train and validate perception systems for autonomous vehicles," in Proc. IEEE Winter Conf. Appl. Comput. Vis. Workshops (WACVW), Jan. 2021, pp. 171-180.

[129] M. Uricár, G. Sistu, H. Rashed, A. Vobecký, V. R. Kumar, P. Krížek, F. Bürger, and S. Yogamani, "Let's get dirty: GAN based data augmentation for camera lens soiling detection in autonomous driving," in Proc. IEEE Winter Conf. Appl. Comput. Vis. (WACV), Jan. 2021, pp. 766-775.

[130] X. Cheng, J. Zhou, J. Song, and X. Zhao, "A highway traffic image enhancement algorithm based on improved GAN in complex weather conditions," IEEE Trans. Intell. Transp. Syst., vol. 24, no. 8, pp. 8716-8726, Aug. 2023.

[131] C. Jiqing, W. Depeng, L. Teng, L. Tian, and W. Huabin, "All-weather road drivable area segmentation method based on CycleGAN," Vis. Comput., vol. 39, no. 10, pp. 5135-5151, Oct. 2023.

[132] A. Mukherjee, A. Joshi, C. Hegde, and S. Sarkar, "Semantic domain adaptation for deep classifiers via gan-based data augmentation," in Proc. Conf. Neural Inf. Process. Syst. Workshops, 2019, pp. 1-7.

[133] A. Sadeghian, V. Kosaraju, A. Sadeghian, N. Hirose, H. Rezatofighi, and S. Savarese, "SoPhie: An attentive GAN for predicting paths compliant to social and physical constraints," in Proc. IEEE/CVF Conf. Comput. Vis. Pattern Recognit. (CVPR), Jun. 2019, pp. 1349-1358.

[134] C. Ledig, L. Theis, F. Huszár, J. Caballero, A. Cunningham, A. Acosta, A. Aitken, A. Tejani, J. Totz, Z. Wang, and W. Shi, "Photo-realistic single image super-resolution using a generative adversarial network," in Proc. IEEE Conf. Comput. Vis. Pattern Recognit. (CVPR), Jul. 2017, pp. 105-114.

[135] O. Kupyn, V. Budzan, M. Mykhailych, D. Mishkin, and J. Matas, "DeblurGAN: Blind motion deblurring using conditional adversarial networks," in Proc. IEEE/CVF Conf. Comput. Vis. Pattern Recognit., Jun. 2018, pp. 8183-8192.

[136] S. Aigner and M. Körner, "FutureGAN: Anticipating the future frames of video sequences using spatio-temporal 3D convolutions in progressively growing GANs," 2018, arXiv:1810.01325.

[137] J.-Y. Zhu, T. Park, P. Isola, and A. A. Efros, "Unpaired image-to-image translation using cycle-consistent adversarial networks," in Proc. IEEE Int. Conf. Comput. Vis. (ICCV), Oct. 2017, pp. 2242-2251.

[138] Z. He, W. Zuo, M. Kan, S. Shan, and X. Chen, "AttGAN: Facial attribute editing by only changing what you want," IEEE Trans. Image Process., vol. 28, no. 11, pp. 5464-5478, Nov. 2019.

[139] F. Lateef, M. Kas, A. Chahi, and Y. Ruichek, "A two-stream conditional generative adversarial network for improving semantic predictions in urban driving scenes," Eng. Appl. Artif. Intell., vol. 133, Jul. 2024, Art. no. 108290.

[140] D. P. Kingma and M. Welling, "Auto-encoding variational Bayes," 2013, arXiv:1312.6114.

[141] L. Gou, L. Zou, N. Li, M. Hofmann, A. K. Shekar, A. Wendt, and L. Ren, "VATLD: A visual analytics system to assess, understand and improve traffic light detection," IEEE Trans. Vis. Comput. Graph., vol. 27, no. 2, pp. 261-271, Feb. 2021.

[142] Z. Chen and L. Liu, "NSS-VAEs: Generative scene decomposition for visual navigable space construction," 2021, arXiv:2111.01127.

[143] V. K. Sundar, S. Ramakrishna, Z. Rahiminasab, A. Easwaran, and A. Dubey, "Out-of-distribution detection in multi-label datasets using latent space of B-VAE," in Proc. IEEE Secur. Privacy Workshops (SPW), May 2020, pp. 250-255.

[144] S. Tan, K. Wong, S. Wang, S. Manivasagam, M. Ren, and R. Urtasun, "SceneGen: Learning to generate realistic traffic scenes," in Proc. IEEE/CVF Conf. Comput. Vis. Pattern Recognit. (CVPR), Jun. 2021, pp. 892-901.

[145] W. Ding, H. Lin, B. Li, and D. Zhao, "Semantically adversarial scenario generation with explicit knowledge guidance," 2021, arXiv:2106.04066.

[146] N. Aslam and M. H. Kolekar, "A-VAE: Attention based variational autoencoder for traffic video anomaly detection," in Proc. IEEE 8th Int. Conf. Converg. Technol. (I2CT), Apr. 2023, pp. 1-7.

[147] C. P. Burgess, I. Higgins, A. Pal, L. Matthey, N. Watters, G. Desjardins, and A. Lerchner,"Understanding disentangling in $\beta$ -VAE," 2018, arXiv:1804.03599.

[148] Z. Li, C. Zhang, G. Meng, and Y. Liu, "Joint haze image synthesis and dehazing with mmd-vae losses," 2019, arXiv:1905.05947.

[149] Q. Tian and J. Sun, "Cluster-based dual-branch contrastive learning for unsupervised domain adaptation person re-identification," Knowl.-Based Syst., vol. 280, Nov. 2023, Art. no. 111026.

[150] X. Gao, Z. Chen, J. Wei, R. Wang, and Z. Zhao, "Deep mutual distillation for unsupervised domain adaptation person re-identification," IEEE Trans. Multimedia, early access, Sep. 12, 2024, doi: 10.1109/TMM.2024.3459637.

[151] G. Mattolin, L. Zanella, E. Ricci, and Y. Wang, "ConfMix: Unsupervised domain adaptation for object detection via confidence-based mixing," in Proc. IEEE/CVF Winter Conf. Appl. Comput. Vis. (WACV), Jan. 2023, pp. 423-433.

[152] D. Shenaj, E. Fanì, M. Toldo, D. Caldarola, A. Tavera, U. Michieli, M. Ciccone, P. Zanuttigh, and B. Caputo, "Learning across domains and devices: Style-driven source-free domain adaptation in clustered federated learning," in Proc. IEEE/CVF Winter Conf. Appl. Com-put. Vis. (WACV), Jan. 2023, pp. 444-454.

[153] Y. Zheng, D. Huang, S. Liu, and Y. Wang, "Cross-domain object detection through coarse-to-fine feature adaptation," in Proc. IEEE/CVF Conf. Comput. Vis. Pattern Recognit. (CVPR), Jun. 2020, pp. 13763-13772.

[154] T. Chen, S. Kornblith, K. Swersky, M. Norouzi, and G. E. Hinton, "Big self-supervised models are strong semi-supervised learners," in Proc. Adv. Neural Inf. Process. Syst., Jan. 2020, pp. 22243-22255.

[155] T. Chen, S. Kornblith, M. Norouzi, and G. E. Hinton, "A simple framework for contrastive learning of visual representations," in Proc. 37th Int. Conf. Mach. Learn., Jan. 2020, pp. 1597-1607.

[156] G. Hinton, O. Vinyals, and J. Dean, "Distilling the knowledge in a neural network," 2015, arXiv:1503.02531.

[157] S. Kullback and R. A. Leibler, "On information and sufficiency," Ann. Math. Statist., vol. 22, no. 1, pp. 79-86, Mar. 1951.

[158] A. Gretton, K. Borgwardt, M. J. Rasch, B. Schölkopf, and A. J. Smola, "A kernel two-sample test," J. Mach. Learn. Res., vol. 13, no. 1, pp. 723-773, Mar. 2012.

[159] Z. Zhao, S. Wei, Q. Chen, D. Li, Y. Yang, Y. Peng, and Y. Liu, "Masked retraining teacher-student framework for domain adaptive object detection," in Proc. IEEE/CVF Int. Conf. Comput. Vis. (ICCV), Oct. 2023, pp. 18993-19003.

[160] K. Gong, S. Li, S. Li, R. Zhang, C. H. Liu, and Q. Chen, "Improving transferability for domain adaptive detection transformers," in Proc. 30th ACM Int. Conf. Multimedia, Oct. 2022, pp. 1543-1551.

[161] G. Li, Z. Ji, Y. Chang, S. Li, X. Qu, and D. Cao, "ML-ANet: A transfer learning approach using adaptation network for multi-label image classification in autonomous driving," Chin. J. Mech. Eng., vol. 34, no. 1, p. 78, Dec. 2021.

[162] D. Mekhazni, A. Bhuiyan, G. Ekladious, and E. Granger, "Unsupervised domain adaptation in the dissimilarity space for person re-identification," in Computer Vision-ECCV 2020, A. Vedaldi, H. Bischof, T. Brox, and J.-M. Frahm, Eds., Cham, Switzerland: Springer, 2020, pp. 159-174.

[163] C.-Y. Lee, T. Batra, M. H. Baig, and D. Ulbricht, "Sliced Wasserstein discrepancy for unsupervised domain adaptation," in Proc. IEEE/CVF Conf. Comput. Vis. Pattern Recognit. (CVPR), Jun. 2019, pp. 10277-10287.

[164] A.-D. Doan, B. L. Nguyen, S. Gupta, I. Reid, M. Wagner, and T.-J. Chin, "Assessing domain gap for continual domain adaptation in object detection," Comput. Vis. Image Understand., vol. 238, Jan. 2024, Art. no. 103885.

[165] P. Isola, J.-Y. Zhu, T. Zhou, and A. A. Efros, "Image-to-image translation with conditional adversarial networks," 2016, arXiv:1611.07004.

[166] M.-Y. Liu, T. M. Breuel, and J. Kautz, "Unsupervised image-to-image translation networks," in Proc. Adv. Neural Inf. Process. Syst., vol. 30, Jan. 2017, pp. 700-708.

[167] Z. Murez, S. Kolouri, D. Kriegman, R. Ramamoorthi, and K. Kim, "Image to image translation for domain adaptation," in Proc. IEEE/CVF Conf. Comput. Vis. Pattern Recognit., Jun. 2018, pp. 4500-4509.

[168] J. Lee, D. Shiotsuka, G. Bang, Y. Endo, T. Nishimori, K. Nakao, and S. Kamijo, "Day-to-night image translation via transfer learning to keep semantic information for driving simulator," IATSS Res., vol. 47, no. 2, pp. 251-262, Jul. 2023.

[169] D. Kothandaraman, A. Nambiar, and A. Mittal, "Domain adaptive knowledge distillation for driving scene semantic segmentation," in Proc. IEEE Winter Conf. Appl. Comput. Vis. Workshops (WACVW), Jan. 2021, pp. 134-143.

[170] H. Wang, S. Liao, and L. Shao, "AFAN: Augmented feature alignment network for cross-domain object detection," IEEE Trans. Image Process., vol. 30, pp. 4046-4056, 2021.

[171] J. Li, R. Xu, X. Liu, J. Ma, B. Li, Q. Zou, J. Ma, and H. Yu, "Domain adaptation based object detection for autonomous driving in foggy and rainy weather," 2023, arXiv:2307.09676.

[172] Y. Guo, R. Liang, Y. Cui, X. Zhao, and Q. Meng, "A domain-adaptive method with cycle perceptual consistency adversarial networks for vehicle target detection in foggy weather," IET Intell. Transp. Syst., vol. 16, no. 7, pp. 971-981, Jul. 2022.

[173] X. Yu and X. Lu, "Domain adaptation of anchor-free object detection for urban traffic," Neurocomputing, vol. 582, May 2024, Art. no. 127477.

[174] M. Biasetton, U. Michieli, G. Agresti, and P. Zanuttigh, "Unsupervised domain adaptation for semantic segmentation of urban scenes," in Proc. IEEE/CVF Conf. Comput. Vis. Pattern Recognit. Workshops (CVPRW), Jun. 2019, pp. 1211-1220.

[175] M. Saffari, M. Khodayar, and S. M. J. Jalali, "Sparse adversarial unsupervised domain adaptation with deep dictionary learning for traffic scene classification," IEEE Trans. Emerg. Topics Comput. Intell., vol. 7, no. 4, pp. 1139-1150, Apr. 2023.

[176] M. Saffari and M. Khodayar, "Low-rank sparse generative adversarial unsupervised domain adaptation for multitarget traffic scene semantic segmentation," IEEE Trans. Ind. Informat., vol. 20, no. 2, pp. 2564-2576, Feb. 2024.

[177] H. Zhang, G. Luo, J. Li, and F.-Y. Wang, "C2FDA: Coarse-to-fine domain adaptation for traffic object detection," IEEE Trans. Intell. Transp. Syst., vol. 23, no. 8, pp. 12633-12647, Aug. 2022.

[178] Q. Zhou, Q. Gu, J. Pang, X. Lu, and L. Ma, "Self-adversarial disentangling for specific domain adaptation," IEEE Trans. Pattern Anal. Mach. Intell., vol. 45, no. 7, pp. 8954-8968, Jul. 2023.

[179] J. Wang, T. Shen, Y. Tian, Y. Wang, C. Gou, X. Wang, F. Yao, and C. Sun, "A parallel teacher for synthetic-to-real domain adaptation of traffic object detection," IEEE Trans. Intell. Vehicles, vol. 7, no. 3, pp. 441-455, Sep. 2022.

[180] L. Zhang, P. Ratsamee, B. Wang, Z. Luo, Y. Uranishi, M. Higashida, and H. Takemura, "Panoptic-aware image-to-image translation," in Proc. IEEE/CVF Winter Conf. Appl. Comput. Vis. (WACV), Jan. 2023, pp. 259-268.

[181] J. Hoffman, E. Tzeng, T. Park, J.-Y. Zhu, P. Isola, K. Saenko, A. A. Efros, and T. Darrell, "CyCADA: Cycle-consistent adversarial domain adaptation," in Proc. Int. Conf. Mach. Learn., Jan. 2017, pp. 1989-1998.

[182] G. Bang, J. Lee, Y. Endo, T. Nishimori, K. Nakao, and S. Kamijo, "Semantic and geometric-aware day-to-night image translation network," Sensors, vol. 24, no. 4, p. 1339, Feb. 2024.

[183] T.-D. Truong, N. Le, B. Raj, J. Cothren, and K. Luu, "FREDOM: Fairness domain adaptation approach to semantic scene understanding," in Proc. IEEE/CVF Conf. Comput. Vis. Pattern Recognit. (CVPR), Jun. 2023, pp. 19988-19997.

[184] C. Szegedy, W. Liu, Y. Jia, P. Sermanet, S. Reed, D. Anguelov, D. Erhan, V. Vanhoucke, and A. Rabinovich, "Going deeper with convolutions," in Proc. IEEE Conf. Comput. Vis. Pattern Recognit. (CVPR), Jun. 2015, pp. 1-9.

[185] A. Cherian and A. Sullivan, "Sem-GAN: Semantically-consistent image-to-image translation," in Proc. IEEE Winter Conf. Appl. Com-put. Vis. (WACV), Jan. 2019, pp. 1797-1806.

[186] S.-W. Huang, C.-T. Lin, S. Chen, Y.-Y. Wu, P.-H. Hsu, and S. Lai, "Aug-GAN: Cross domain adaptation with GAN-based data augmentation," in Proc. Eur. Conf. Comput. Vis. (ECCV), Jan. 2018, pp. 731-744.

[187] R. Volpi, P. Morerio, S. Savarese, and V. Murino, "Adversarial feature augmentation for unsupervised domain adaptation," in Proc. IEEE/CVF Conf. Comput. Vis. Pattern Recognit., Jun. 2018, pp. 5495-5504.

[188] A. Vaswani, N. Shazeer, N. Parmar, J. Uszkoreit, L. Jones, A. N. Gomez, L. Kaiser, and I. Polosukhin, "Attention is all you need," 2017, arXiv:1706.03762.

[189] M. Salem, A. Gomaa, and N. Tsurusaki, "Detection of earthquake-induced building damages using remote sensing data and deep learning: A case study of mashiki town, Japan," in Proc. IEEE Int. Geosci. Remote Sens. Symp., Jul. 2023, pp. 2350-2353.

[190] A. Gomaa, M. M. Abdelwahab, and M. Abo-Zahhad, "Real-time algorithm for simultaneous vehicle detection and tracking in aerial view videos," in Proc. IEEE 61st Int. Midwest Symp. Circuits Syst. (MWSCAS), Aug. 2018, pp. 222-225.

[191] M. A. Khan and H. Park, "Exploring explainable artificial intelligence techniques for interpretable neural networks in traffic sign recognition systems," Electronics, vol. 13, no. 2, p. 306, Jan. 2024.

[192] C. Bustos, D. Rhoads, A. Solé-Ribalta, D. Masip, A. Arenas, A. Lapedriza, and J. Borge-Holthoefer, "Explainable, automated urban interventions to improve pedestrian and vehicle safety," Transp. Res. C, Emerg. Technol., vol. 125, Apr. 2021, Art. no. 103018.

[193] S. Kolekar, S. Gite, B. Pradhan, and A. Alamri, "Explainable AI in scene understanding for autonomous vehicles in unstructured traffic environments on Indian roads using the inception U-Net model with grad-CAM visualization," Sensors, vol. 22, no. 24, p. 9677, Dec. 2022.

[194] J. Dong, S. Chen, M. Miralinaghi, T. Chen, P. Li, and S. Labi, "Why did the AI make that decision? Towards an explainable artificial intelligence (XAI) for autonomous driving systems," Transp. Res. C, Emerg. Technol., vol. 156, Nov. 2023, Art. no. 104358.

[195] K. Han, Y. Wang, J. Guo, Y. Tang, and E. Wu, "Vision GNN: An image is worth graph of nodes," in Proc. Adv. Neural Inf. Process. Syst., A. H. Oh, A. Agarwal, D. Belgrave, and K. Cho, Eds., Jan. 2022, pp. 8291-8303.

[196] J. Regan and M. Khodayar, "A triplet graph convolutional network with attention and similarity-driven dictionary learning for remote sensing image retrieval," Expert Syst. Appl., vol. 232, Dec. 2023, Art. no. 120579.

[197] K. Han, Y. Wang, H. Chen, X. Chen, J. Guo, Z. Liu, Y. Tang, A. Xiao, C. Xu, Y. Xu, Z. Yang, Y. Zhang, and D. Tao, "A survey on vision transformer," IEEE Trans. Pattern Anal. Mach. Intell., vol. 45, no. 1, pp. 87-110, Jan. 2023.

[198] G. Li, M. Müller, A. Thabet, and B. Ghanem, "DeepGCNs: Can GCNs Go As Deep As CNNs?" in Proc. IEEE Int. Conf. Comput. Vis., Oct. 2019, pp. 9266-9275.

[199] T. K. Rusch, M. M. Bronstein, and S. Mishra, "A survey on oversmooth-ing in graph neural networks," 2023, arXiv:2303.10993.

[200] J. Li, Q. Zhang, W. Liu, A. B. Chan, and Y.-G. Fu, "Another perspective of over-smoothing: Alleviating semantic over-smoothing in deep GNNs," IEEE Trans. Neural Netw. Learn. Syst., early access, May 29, 2024, doi: 10.1109/TNNLS.2024.3402317.

[201] L. J. Zhang, J. J. Fang, Y. X. Liu, H. Feng Le, Z. Q. Rao, and J. X. Zhao, "CR-YOLOv8: Multiscale object detection in traffic sign images," IEEE Access, vol. 12, pp. 219-228, 2024.

[202] S. R. Dubey and S. K. Singh, "Transformer-based generative adversarial networks in computer vision: A comprehensive survey," IEEE Trans. Artif. Intell., vol. 5, no. 10, pp. 4851-4867, Oct. 2024.

[203] G. Ros, L. Sellart, J. Materzynska, D. Vazquez, and A. M. Lopez, "The SYNTHIA dataset: A large collection of synthetic images for semantic segmentation of urban scenes," in Proc. IEEE Conf. Com-put. Vis. Pattern Recognit. (CVPR), Jun. 2016, pp. 3234-3243.

[204] S. R. Richter, V. Vineet, S. Roth, and V. Koltun, "Playing for data: Ground truth from computer games," in Proc. Eur. Conf. Comput. Vis., in Lecture Notes in Computer Science: Including Subseries Lecture Notes in Artificial Intelligence and Lecture Notes in Bioinformatics, vol. 9906, Jan. 2016, pp. 102-118.

[205] R. Zhang, K. Xiong, H. Du, D. Niyato, J. Kang, X. Shen, and H. V. Poor, "Generative AI-enabled vehicular networks: Fundamentals, framework, and case study," IEEE Netw., vol. 38, no. 4, pp. 259-267, Jul. 2024.

[206] E. Galazka, T. T. Niemirepo, and J. Vanne, "CiThruS2: Open-source photorealistic 3D framework for driving and traffic simulation in real time," in Proc. IEEE Int. Intell. Transp. Syst. Conf. (ITSC), Sep. 2021, pp. 3284-3291.

[207] X. Li, J. Park, C. Reberg-Horton, S. Mirsky, E. Lobaton, and L. Xiang, "Photorealistic arm robot simulation for 3D plant reconstruction and automatic annotation using unreal engine 5," in Proc. IEEE/CVF Conf. Comput. Vis. Pattern Recognit. Workshops (CVPRW), Jun. 2024, pp. 5480-5488.

[208] E. Yurtsever, D. Yang, I. M. Koc, and K. A. Redmill, "Photorealism in driving simulations: Blending generative adversarial image synthesis with rendering," IEEE Trans. Intell. Transp. Syst., vol. 23, no. 12, pp. 23114-23123, Dec. 2022.

[209] S. Yin, C. Fu, S. Zhao, K. Li, X. Sun, T. Xu, and E. Chen, "A survey on multimodal large language models," 2023, arXiv:2306.13549.

[210] H. Wang, J. Qin, A. Bastola, X. Chen, J. Suchanek, Z. Gong, and A. Razi, "VisionGPT: LLM-assisted real-time anomaly detection for safe visual navigation," 2024, arXiv:2403.12415.

[211] T.-A. To, M.-N. Tran, T.-B. Ho, T.-L. Ha, Q.-T. Nguyen, H.-C. Luong, T.-D. Cao, and M.-T. Tran, "Multi-perspective traffic video description model with fine-grained refinement approach," in Proc. IEEE/CVF Conf. Comput. Vis. Pattern Recognit. Workshops (CVPRW), Jun. 2024, pp. 7075-7084.

[212] C. Cui, Y. Ma, X. Cao, W. Ye, and Z. Wang, "Receive, reason, and react: Drive as you say, with large language models in autonomous vehicles," IEEE Intell. Transp. Syst. Mag., vol. 16, no. 4, pp. 81-94, Jul. 2024.

[213] L. Kong, X. Xu, J. Ren, W. Zhang, L. Pan, K. Chen, W. T. Ooi, and Z. Liu, "Multi-modal data-efficient 3D scene understanding for autonomous driving," 2024, arXiv:2405.05258.

[214] K. Dasgupta, A. Das, S. Das, U. Bhattacharya, and S. Yogamani, "Spatio-contextual deep network-based multimodal pedestrian detection for autonomous driving," IEEE Trans. Intell. Transp. Syst., vol. 23, no. 9, pp. 15940-15950, Sep. 2022.

[215] T. Qian, J. Chen, L. Zhuo, Y. Jiao, and Y. Jiang, "NuScenes-QA: A multi-modal visual question answering benchmark for autonomous driving scenario," in Proc. AAAI Conf. Artif. Intell., Jan. 2023, vol. 38, no. 5, pp. 4542-4550.

[216] J. Li, Y. Zhang, P. Yun, G. Zhou, Q. Chen, and R. Fan, "RoadFormer: Duplex transformer for RGB-normal semantic road scene parsing," IEEE Trans. Intell. Vehicles, vol. 9, no. 7, pp. 5163-5172, Jul. 2024.

[217] D. Feng, C. Haase-Schütz, L. Rosenbaum, H. Hertlein, C. Gläser, F. Timm, W. Wiesbeck, and K. Dietmayer, "Deep multi-modal object detection and semantic segmentation for autonomous driving: Datasets, methods, and challenges," IEEE Trans. Intell. Transp. Syst., vol. 22, no. 3, pp. 1341-1360, Mar. 2021.

![bo_d2839q77aajc738ors5g_50_881_702_228_284_0.jpg](images/bo_d2839q77aajc738ors5g_50_881_702_228_284_0.jpg)

PARYA DOLATYABI (Graduate Student Member, IEEE) received the B.Sc. degree in computer science from the Shahid Bahonar University of Kerman, Kerman, Iran, in 2003, the M.Sc. degree in information technology engineering from the K. N. Toosi University of Technology, Tehran, Iran, in 2007, and the M.Sc. degree in computer engineering from the University of Tulsa (TU), Tulsa, OK, USA, in 2024, where she is currently pursuing the Ph.D. degree in computer science. In 2023, she completed an internship as a Research Assistant with the Laureate Institute for Brain Research (LIBR), Tulsa. Her primary research interests include the theories and applications of deep learning models in computer vision and computational neuroscience. Additionally, she serves as a Reviewer for IEEE TRANSACTIONS ON TRANSPORTATION ELECTRIFICATION and Sustainable Computing: Informatics and Systems journals.

![bo_d2839q77aajc738ors5g_50_880_1229_228_284_0.jpg](images/bo_d2839q77aajc738ors5g_50_880_1229_228_284_0.jpg)

JACOB REGAN (Graduate Student Member, IEEE) received the B.Sc. and M.Sc. degrees in computer science from the University of Tulsa (TU), Tulsa, Oklahoma, in 2021 and 2022, respectively, where he is currently pursuing the Ph.D. degree in computer science. His main research interests include artificial intelligence, machine learning, computer vision, and transportation network simulation and optimization.

![bo_d2839q77aajc738ors5g_50_876_1584_233_287_0.jpg](images/bo_d2839q77aajc738ors5g_50_876_1584_233_287_0.jpg)

MAHDI KHODAYAR (Member, IEEE) received the B.Sc. degree in computer engineering and the M.Sc. degree in artificial intelligence from the K. N. Toosi University of Technology, Tehran, Iran, in 2013 and 2015, respectively, and the Ph.D. degree in electrical engineering from Southern Methodist University, Dallas, TX, USA, in 2020. In 2017, he was a Research Assistant with the College of Computer and Information Science, Northeastern University, Boston, MA, USA. He is currently an Assistant Professor with the Department of Computer Science, The University of Tulsa, Tulsa, OK, USA. His main research interests include machine learning and statistical pattern recognition. He is focused on DL, sparse modeling, and spatiotemporal pattern recognition. He has served as a Reviewer for many reputable journals, including IEEE TRANSACTIONS ON Neural Networks and Learning Systems, IEEE Transactions on Industrial Informatics, IEEE Transactions on Fuzzy Systems, IEEE Transactions on Sustainable Energy, and IEEE Transactions on Power Systems. Additionally, he serves as an Editor for IEEE TRANSACTIONS ON TRANSPORTATION ELECTRIFICATION.