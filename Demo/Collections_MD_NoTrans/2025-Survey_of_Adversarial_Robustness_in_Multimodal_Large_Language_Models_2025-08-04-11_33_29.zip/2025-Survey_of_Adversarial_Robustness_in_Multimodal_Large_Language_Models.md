# Survey of Adversarial Robustness in Multimodal Large Language Models

Chengze Jiang ${}^{1}$ , Zhuangzhuang Wang ${}^{1}$ , Minjing Dong ${}^{3}$ , Jie Gui ${}^{*1,2}$ ,

${}^{1}$ School of Cyber Science and Engineering, Southeast University, Nanjing, China ${}^{2}$ Purple Mountain Laboratories, Nanjing, China ${}^{3}$ Department of Computer Science, City University of Hong Kong, Hong Kong, China czjiang@seu.edu.cn, 220235252@seu.edu.cn, minjdong@cityu.edu.hk, guijie@seu.edu.cn

## Abstract

Multimodal Large Language Models (MLLMs) have demonstrated exceptional performance in artificial intelligence by facilitating integrated understanding across diverse modalities, including text, images, video, audio, and speech. However, their deployment in real-world applications raises significant concerns about adversarial vulnerabilities that could compromise their safety and reliability. Unlike unimodal models, MLLMs face unique challenges due to the interdependencies among modalities, making them susceptible to modality-specific threats and cross-modal adversarial manipulations. This paper reviews the adversarial robustness of MLLMs, covering different modalities. We begin with an overview of MLLMs and a taxonomy of adversarial attacks tailored to each modality. Next, we review key datasets and evaluation metrics used to assess the robustness of MLLMs. After that, we provide an in-depth review of attacks targeting MLLMs across different modalities. Our survey also identifies critical challenges and suggests promising future research directions.

## 1 Introduction

Multimodal large language models (MLLMs) have driven transformative advancements in artificial intelligence by enabling the seamless integration of diverse data modalities [Zhang et al., 2024c]. Unlike unimodal models that are limited to processing a single input modality, MLLMs empower a broad range of applications, from image captioning and visual question answering to video summarization and audio-visual speech recognition [Sun et al., 2024]. Grounded in their ability to understand and integrate multimodal information, MLLMs enable the comprehension and generation of content across diverse data types, offering a holistic understanding that captures the intricate relationships between modalities and reflects real-world interactions [Liu et al., 2024b] [Zhao et al., 2024].

Despite these advances, existing research reveals that MLLMs remain vulnerable to adversarial attacks [Liu et al., 2024a]. While multimodal integration is a key strength, it simultaneously expands the attack surface, introducing new vectors for manipulation in both modality-specific and cross-modal scenarios [Qi et al., 2024]. Although various studies have explored adversarial strategies within individual modalities, no unified perspective has emerged to address the complexities of MLLMs comprehensively [Liu et al., 2024a]. Besides, adversarial threats can arise not only during inference but also in the training phase [Xu et al., 2024b]. These vulnerabilities introduce significant risks by embedding latent threats into MLLMs, which are posed by adversarial attacks and are further amplified by the growing deployment of MLLMs in high-stakes applications, including autonomous systems [Fu et al., 2024], medical diagnostics [Fan et al., 2024], and content moderation [Gong et al., 2023]. Given these multifaceted threats, the question of developing robust defense mechanisms becomes paramount. However, current defenses often lag behind the sophistication of emerging attacks, as they primarily target unimodal adversarial scenarios and fail to account for the complex dynamics of multimodal data integration.

Considering the security concerns arising from the robustness risks of MLLMs, as well as the rapid advancements in this field, there is an urgent requirement for a systematic investigation that not only informs but also guides future research. To address this necessity, we present a comprehensive survey that examines adversarial risks and defenses of MLLMs across a variety of modalities. Unlike prior studies that predominantly focus on image-text models, our survey expands the scope to encompass additional modalities and their corresponding defense strategies, thus offering a broader perspective on the adversarial robustness of MLLMs. Specifically, we categorize these approaches into four distinct modalities, covering image, video, audio, and speech. This categorization provides a comprehensive overview and an in-depth analysis of the threats and corresponding countermeasures in each domain.

Goals of our survey. We aim to (i) summarize representative datasets and metrics used to evaluate MLLMs adversarial robustness across different modalities; (ii) develop a taxonomy of adversarial robustness in MLLMs from the perspective of input modalities, introducing attack strategies and robustness evaluation methods tailored to each modality; and (iii) identify open challenges to inspire future research and enhance the adversarial robustness of MLLMs.

Difference between our and previous surveys. As presented in Table. 1, [Chowdhury et al., 2024] focus on text-based attacks in LLMs. [Liu et al., 2024b] provide a macroscopic review of LVLM safety issues but limit their scope to vision and text modalities with preliminary taxonomy. While [Liu et al., 2024a] subsequently delivers a detailed analysis of vision-text attacks, their work neglects other modalities. Similarly, [Fan et al., 2024] narrow their analyses to image-based attacks. These reviews lack a systematic review of the adversarial robustness of MLLMs across diverse modalities, which is a crucial aspect of MLLMs. Therefore, we present a comprehensive survey and taxonomy of the adversarial robustness of MLLMs, encompassing various modalities. Our proposed taxonomy, illustrated in Fig. 1, provides a structured overview of adversarial robustness in MLLMs from a modal perspective.

<table><tr><td>Paper</td><td>Attack</td><td>Defense</td><td>Modal</td></tr><tr><td>[Chowdhury et al., 2024]</td><td>✓</td><td/><td>Text</td></tr><tr><td>[Fan et al., 2024]</td><td>✓</td><td/><td>Image, Text</td></tr><tr><td>[Liu et al., 2024b]</td><td>✓</td><td>✓</td><td>Image, Text</td></tr><tr><td>[Liu et al., 2024a]</td><td>✓</td><td/><td>Image, Text</td></tr><tr><td>Ours</td><td>✓</td><td>✓</td><td>Multimodal</td></tr></table>

Table 1: Comparisons Existing Survey for Adversarial Robustness of MLLMs

## 2 Preliminaries and Background

### 2.1 Overview of MLLMs

MLLMs integrate multiple modalities into a unified framework, enabling cross-modal reasoning for tasks like captioning, retrieval, and translation [Carlini et al., 2024]. These models leverage large language model backbones, such as GPT-based models, to process textual data, while specialized encoders extract features from other modalities[Qi et al., 2023]. MLLMs enhance their ability to understand and generate information across diverse data sources by capturing intricate interdependencies among modalities [Zhu et al., 2024]. To achieve integration, MLLMs rely on fusion modules that align and combine multimodal features, often mapping them into shared latent spaces for unified representation. This facilitates interaction and alignment between modalities, enabling cohesive understanding and generation. The ability to unify and process diverse modalities not only broadens the scope of achievable tasks but also establishes MLLMs as a crucial technology for advancing cross-modal AI applications [Rafailov et al., 2024]. 2.2 Introduction of Different Attack Methods

#### 2.2.1 Adversarial Attack

Adversarial attacks on MLLMs aim to exploit their vulnerabilities by introducing imperceptible perturbations to input data, causing the model to produce incorrect or harmful outputs. These attacks pose significant threats to applications, and the primary goal of attacks is to manipulate the model's responses while remaining undetectable to human observers.

Given an MLLM $M$ that takes an image $x$ and a textual prompt ${t}_{\text{in }}$ and model $M$ produces an output ${t}_{\text{out }} = M\left( {x,{t}_{\text{in }}}\right)$ .

The objective of adversarial attack is to generate perturbed inputs ${x}^{\text{adv }}$ and ${t}^{\text{adv }}$ , satisfies that:

$$
M\left( {{x}^{\text{adv }},{t}_{\text{in }}^{\text{adv }}}\right)  \neq  M\left( {x,{t}_{\text{in }}}\right) , \tag{1a}
$$

$$
\text{s.t.}{\begin{Vmatrix}{x}^{\text{adv }} - x\end{Vmatrix}}_{p} \leq  \epsilon ,{\begin{Vmatrix}{t}^{\text{adv }} - {t}_{\text{in }}\end{Vmatrix}}_{p} \leq  \epsilon \text{,} \tag{1b}
$$

where $\epsilon$ is the perturbation budget, ensuring perceptibility.

In adversarial image attacks, subtle perturbations are introduced to visual inputs, leading to misclassification or incorrect textual descriptions [Zhao et al., 2024]. Attacks targeting visual inputs include gradient-based methods, which iteratively perturb pixels to maximize classification errors [Schlarmann and Hein, 2023]. In contrast, diffusion-based attacks further refine visual perturbations, enhancing attack effectiveness across diverse prompts and models [Guo et al., 2024]. Text-based adversarial attacks manipulate textual inputs to mislead the model into producing incorrect outputs while maintaining syntactic plausibility [Dong et al., 2023] [Wang et al., 2024b]. Furthermore, cross-modal attacks extend this approach by jointly perturbing both visual and textual inputs. The mathematical formulation for these attacks can be expressed as follows:

$$
\mathop{\max }\limits_{{{\delta }_{x},{\delta }_{t}}}L\left( {M\left( {x + {\delta }_{x},{t}_{\text{in }} + {\delta }_{t}}\right) ,{t}_{\text{target }}}\right) , \tag{2a}
$$

$$
\text{s.t.}{\begin{Vmatrix}{\delta }_{x}\end{Vmatrix}}_{p} \leq  {\epsilon }_{x},{\begin{Vmatrix}{\delta }_{t}\end{Vmatrix}}_{p} \leq  {\epsilon }_{t} \tag{2b}
$$

where ${\delta }_{x}$ and ${\delta }_{t}$ represent the adversarial perturbations applied to the visual and textual inputs, respectively, while ${\epsilon }_{x}$ and ${\delta }_{t}$ define the perturbation imperceptibility.

#### 2.2.2 Jailbreak Attacks

Jailbreak attacks aim to circumvent safety mechanisms by exploiting vulnerabilities in both textual and visual inputs, leading to the generation of harmful content. Attackers use Image Jailbreaking Prompts and Perturbed Jailbreaking Prompts to craft adversarial examples that bypass security constraints across multiple prompts and models [Niu et al., 2024] [Wang et al., 2024a]. Besides, Infectious Jailbreak attacks spread malicious inputs rapidly through agent interactions, causing large-scale security breaches [Gu et al., 2024].

#### 2.2.3 Data Integrity Attack

Data integrity attacks aim to compromise reliability and trustworthiness by injecting malicious or manipulated data, ultimately leading to incorrect, biased, or even harmful outputs [Xu et al., 2024b]. These attacks can occur during both training and inference phases, with methods such as data poisoning, where adversaries introduce carefully crafted corrupted examples into the training set to influence the model's behavior and degrade its performance over time [Liang et al., 2024a]. Another prevalent method is backdoor attacks, which embed hidden triggers within the data that remain dormant under normal conditions but activate malicious behaviors when specific inputs or prompts are provided [Lu et al., 2024] [Ni et al., 2024].

### 2.3 Dataset

Various datasets across different modalities are established to evaluate the performance of MLLMs. For image-based MLLMs, commonly used datasets include MS-COCO for image captioning [Lin et al., 2014], Visual7W for visual question answering, and ScienceQA for multimodal science reasoning [Lu et al., 2022]. Additionally, benchmarks such as SafetyBench and MM-SafetyBench assess model robustness against adversarial inputs and safety risks [Zhang et al., 2023]. In the video domain, datasets like ActivityNet-200 [Caba Heilbron et al., 2015] and MSVD-QA [Xu et al., 2017] focus on evaluating models' ability to capture temporal coherence and event alignment, which are critical for understanding dynamic visual content. For audio-based MLLMs, LibriSpeech [Panayotov et al., 2015] is the benchmark for speech recognition and speaker verification tasks, while LlamaPartialSpoof [Luong et al., 2024] is used to evaluate robustness against spoofing attacks in speech-based applications. The details of datasets are shown in Table 2.

<table><tr><td>Dataset</td><td>I</td><td>T</td><td>V</td><td>A</td><td>S</td></tr><tr><td>MS-COCO [Lin et al., 2014]</td><td>✓</td><td/><td/><td/><td/></tr><tr><td>Flickr30K [Plummer et al., 2015]</td><td>✓</td><td>✓</td><td/><td/><td/></tr><tr><td>VizWiz [Chen et al., 2022]</td><td>✓</td><td>✓</td><td/><td/><td/></tr><tr><td>VQA-v2 [Goyal et al., 2017]</td><td>✓</td><td>✓</td><td/><td/><td/></tr><tr><td>A-OKVQA [Marino et al., 2019]</td><td>✓</td><td>✓</td><td/><td/><td/></tr><tr><td>ScienceQA [Lu et al., 2022]</td><td>✓</td><td>✓</td><td/><td/><td/></tr><tr><td>ActivityNet [Caba Heilbron et al., 2015]</td><td/><td>✓</td><td>✓</td><td/><td/></tr><tr><td>MSVD-QA [Xu et al., 2017]</td><td/><td>✓</td><td>✓</td><td/><td/></tr><tr><td>VideoQA [Xiao et al., 2024]</td><td/><td>✓</td><td>✓</td><td/><td/></tr><tr><td>EditVid-QA [Xu et al., 2024a]</td><td/><td>✓</td><td>✓</td><td/><td/></tr><tr><td>AV-Deepfake1M [Cai et al., 2024]</td><td/><td/><td>✓</td><td>✓</td><td/></tr><tr><td>LlamaPartialSpoof [Luong et al., 2024]</td><td/><td/><td/><td/><td>✓</td></tr></table>

Table 2: Dataset Summary. I, T, V, A, and S represent image, text, video, audio, and speech modalities, respectively.

### 2.4 Adversarial Risk of MLM

Despite significant advancements in both open- and closed-source MLLMs, ensuring resilience to adversarial perturbations and maintaining safety across modalities remains an open research challenge [Zhao et al., 2024]. This challenge is particularly pronounced in multimodal information, where attacks can target a single modality (e.g., noise in images or manipulations in text) or disrupt cross-modal alignments [Liu et al., 2025], [Qi et al., 2024]. Moreover, unlike conventional adversarial attacks that typically rely on gradient-based methods to generate adversarial examples, attacks on MLLMs are more diverse, and there is currently no consensus on the definitions of adversarial robustness or safety [Cui et al., 2024]. For example, adversarial prompt injection can be used to subtly manipulate the model's behavior, while cross-modal adversarial attacks introduce perturbations across multiple modalities-either sequentially or jointly-to compromise the outputs integrity of the models [Wang et al., 2024b], [Yang et al., 2024].

We summarize the existing techniques from the perspective of modalities in Fig. 1, categorizing them into attack and defense methods. Our analysis reveals significant imbalances in terms of the number of studies and the diversity of approaches for attacks and defenses. We hope that our work will inspire and contribute to future efforts aimed at enhancing the security of MLLMs.

## 3 Attack on Image-MLLMs

This section provides a taxonomy and overview of the methods employed to exploit the vulnerabilities of MLLMs within the image modality, specifically focusing on adversarial attacks, jailbreak attacks, and data integrity attacks.

### 3.1 Adversarial Attack

Adversarial attacks pose robustness risks to MLLMs by manipulating inputs to induce incorrect outputs. Following, we categorize the scenarios based on the level of access to model information into two types: full access to model details and restricted access to partial information.

#### 3.1.1 Full Access Situation

By exploiting the vulnerabilities of visual encoders, several works have extended traditional adversarial attacks to MLLMs. Schlarmann et al. conduct both untargeted and targeted attacks on MLLMs by introducing carefully crafted adversarial perturbations. Results demonstrate that subtle perturbations on visual inputs are shown to induce misclassifications or misleading outputs, which highlights the requirement for effective defensive strategies to address significant performance degradation caused by adversarial perturbations [Schlarmann and Hein, 2023]. Cui et al. assess adversarial robustness in multiple vision-related tasks, revealing that adversarial perturbations in the visual domain significantly degrade model performance on image classification and captioning tasks. However, for visual question answering, the models demonstrate greater adversarial robustness, with only slight performance degradation observed. Building on these findings, they propose contextual enhancements and task decomposition as promising strategies to mitigate these vulnerabilities [Cui et al., 2024].

Another concept, image hijacking, manipulates model behavior through subtle visual perturbations. This method excels in scenarios such as misinformation dissemination and jailbreak attacks, outperforming traditional adversarial techniques and exposing critical risks for content moderation applications [Bailey et al., 2023]. The Verbose Images is presented in [Gao et al., ], which leverages imperceptible perturbations to induce excessively verbose outputs in MLLMs, significantly increasing energy consumption and latency during inference. This stealthy and transferable attack undermines computational efficiency, posing substantial risks to the availability of VLM-based systems [Gao et al., ].

Adversarial vulnerabilities also extend to reasoning mechanisms within MLLMs. Wang et al. investigate the impact of Chain-of-Thought (CoT) reasoning on the adversarial robustness of MLLMs, revealing that while CoT improves robustness against existing attack methods through multi-step reasoning, the improvement is limited. Accordingly, the Stop-Reasoning Attack is proposed, targeting CoT reasoning frameworks by prematurely terminating reasoning processes or introducing errors. By bypassing CoT's intermediate reasoning steps [Wang et al., 2024b].

![bo_d1lvp577aajc73dif0hg_3_141_142_1537_1115_0.jpg](images/bo_d1lvp577aajc73dif0hg_3_141_142_1537_1115_0.jpg)

Figure 1: A Taxonomy of Adversarial Robustness of MLLMs.

#### 3.1.2 Restricted Access Situation

While full access to model details allows for a comprehensive analysis of MLLM vulnerabilities to adversarial attacks, real-world commercial MLLMs often restrict access to model information. To examine vulnerabilities under more practical conditions, adversarial attacks in limited-information settings exploit this restricted visibility to execute manipulations. These methods typically operate under black- or gray-box assumptions, relying on external queries or surrogate models to generate adversarial inputs.

To achieve black-box attacks, transfer-based approaches evaluate adversarial robustness under black-box settings. By utilizing surrogate models such as CLIP and BLIP, these methods enable the generation of adversarial examples that effectively transfer across various vision-language models, including MiniGPT-4 and BLIP-2 [Zhao et al., 2024]. Leveraging diffusion models to generate targeted and highly transferable adversarial examples for MLLMs provides a comprehensive assessment of potential security vulnerabilities before deployment. AdvDiffVLM enhances transfer-based attacks by employing ensemble gradient estimation and mask generation techniques to produce visually natural adversarial examples with dispersed semantics, thereby improving transferability [Guo et al., 2024].

In addition to conventional transfer-based attacks for achieving black-box settings, some studies have shifted focus toward evaluating the security of MLLMs within black-box scenarios. Adopting the Unicorn safety evaluation framework provides a systematic evaluation of the vulnerabilities of MLLMs under out-of-distribution and adversarial conditions. This benchmark tests MLLMs against attack scenarios and unconventional inputs, revealing robustness and safety protocol gaps. The findings suggest that visual language training pipelines often weaken original safety measures, increasing risks during practical use [Tu et al., 2024]. Studies on Google Bard reveal that targeted adversarial image and text attacks can bypass safety mechanisms, including face privacy detection and toxic content filters, leading to harmful outputs. The results present the critical need for more robust safety evaluations and defense strategies for multimodal systems [Dong et al., 2023]. The agent robustness evaluation framework models autonomous agents powered by MLLMs as interconnected components, systematically analyzing their vulnerabilities to adversarial inputs. Corresponding results identify critical components, such as evaluators and policy models, as particularly susceptible, with attacks achieving high success rates even with minimal perturbations [Wu et al., 2024]. Lastly, the B-AVIBench framework addresses the vulnerabilities of MLLMs to black-box adversarial visual instructions, spanning diverse attack methods across image, text, and biased content modalities. It systematically reveals significant security gaps, including susceptibility to multimodal biases and combined modality attacks, emphasizing the need for robust and fair defense mechanisms. Besides, this framework provides a comprehensive evaluation tool for open-source and proprietary models [Zhang et al., 2024b].

### 3.2 Jailbreak Attacks

Jailbreak attacks bypass the safety mechanisms or constraints implemented in models by exploiting underlying system vulnerabilities. These attacks manipulate MLLMs to generate harmful or unauthorized outputs. In this section, we review the advancements in jailbreak attacks in MLLMs, with the first part focusing on general jailbreak attacks and the second examining prompt injection techniques.

#### 3.2.1 Cross-Modal Inconsistency Attacks

Cross-modal attacks exploit alignment gaps between modalities. As a representative work, [Carlini et al., 2024] craft adversarial prompts to manipulate attention mechanisms, bypassing safety constraints through multimodal perturbations. These adversarial inputs manipulate the model's behavior, enabling it to ignore safety constraints and generate harmful content. [Niu et al., 2024] further reveal that contradictory inputs across modalities (e.g., conflicting images and text) induce model misinterpretations, enabling jailbreaks transferable across MiniGPT-v2 and LLaVA. Similarly, by exploiting cross-modal inconsistencies, a variant termed "infectious jailbreak" allows compromised agents to propagate harmful behaviors across interconnected systems, threatening large-scale deployments [Gu et al., 2024]. Additionally, [Tao et al., 2024] design adversarial examples that replace textual captions with malicious prompts, exploiting fusion layer vulnerabilities to generate harmful responses.

#### 3.2.2 Prompt Manipulation

[Wang et al., 2024a] propose a white-box strategy using a "Universal Master Key", which combines adversarial image prefixes and text suffixes to bypass alignment defenses with high success rates. Conversely, [Wu et al., 2023] demonstrate that optimizing system prompts can enhance attack efficacy across languages, yet properly designed prompts also mitigate risks. Visual prompt injection further amplifies threats. [Gong et al., 2023] embed harmful instructions into typographic images, breaking safety filters of GPT-4V.

#### 3.2.3 Jailbreak in Training-Phase

[Li et al., 2025] investigate how the presence of adversarial examples in training data can create vulnerabilities in MLLMs. The results argue that adversarial examples during training can expose gaps in the model's ability to handle unexpected inputs, thereby facilitating successful jailbreak attempts. Similarly, Qi et al. delve deeper into visual prompt injection using adversarial examples, demonstrating subtle manipulations of visual inputs can bypass safety mechanisms in MLLMs [Qi et al., 2024]. Their findings reveal that visual prompts can effectively compel models to produce unsafe outputs, such as hate speech and violent instructions.

### 3.3 Data Integrity Attacks

Data integrity attacks deliberately manipulate data to compromise the training or operation of MLLMs. These attacks significantly impact the security and reliability of MLLMs, particularly in scenarios involving privacy-sensitive or high-stakes tasks. Data integrity attacks can be broadly classified into backdoor attacks and poisoning attacks.

An early exploration of backdoor attacks for MLLMs is AnyDoor, which introduces a test-time backdoor attack against MLLMs, which decouples the backdoor setup by using universal adversarial perturbations applied to visual inputs, while activation is triggered by specific textual inputs. This separation enhances the attack's stealth and effectiveness. AnyDoor demonstrates remarkable adaptability, achieving a ${98.5}\%$ attack success rate across multiple MLLMs, even under challenging conditions such as noise interference and cropping [Lu et al., 2024]. After that, VL-Trojan extends backdoor attack capabilities by integrating visual and textual triggers during instruction tuning. Leveraging feature isolation and clustering, this technique achieves over ${99}\%$ success rates with only poisoning ${0.5}\%$ of examples. Its consistent effectiveness across models and tasks demonstrates the elevated risk of backdoor vulnerabilities in instruction-tuned MLLMs [Liang et al., 2024a]. BadVLM-Driver, the first backdoor attack targeting MLLMs in autonomous driving, explores physical backdoor attacks in real-world environments. By leveraging natural triggers, such as red balloons, BadVLMDriver can induce harmful behaviors, such as sudden acceleration, with a high attack success rate. This approach offers significant flexibility in selecting both the trigger and the resulting malicious behavior, thereby enhancing the stealth and practicality of the attack in diverse real-world scenarios [Ni et al., 2024]. Further studies reveal the cross-domain robustness of backdoor attacks, demonstrating that triggers embedded during instruction tuning can sustain success rates of over ${97}\%$ , even when subjected to domain shifts. This proposes the requirement for effective detection and mitigation strategies, thereby emphasizing the escalating security risks posed by the increasing generalizability of backdoors in MLLMs [Xu et al., 2024b].

For data poisoning, Shadowcast exemplifies the sophistication of such attacks. It utilizes clean-label strategies to subtly alter image-text pairs, thereby manipulating model outputs without introducing obvious disruptions. Experimental results demonstrate Shadowcast's effectiveness, achieving attack success rates exceeding ${80}\%$ with fewer than 50 poisoned examples while maintaining robustness across various data augmentations [Liang et al., 2024b].

## 4 Attack on Video-MLLMs

Video-MLLMs integrate temporal and cross-modal reasoning for tasks like video QA and autonomous driving, yet their dynamic nature amplifies adversarial risks [Fu et al., 2024]. Adversarial strategies against video-MLLMs often target their temporal reasoning and cross-modal alignment [Li et al., 2024] [Xu et al., 2024a]. To address these challenges, recent benchmarks evaluate robustness across multiple safety dimensions [Miao et al., 2024]. Below, we provide a review of three aspects.

### 4.1 Temporal-Coherence Attack

[Li et al., 2024] propose FMM-Attack, injecting optical flow-guided perturbations into keyframes to disrupt temporal dynamics. FMM-Attack degrades output accuracy even with sparse frame modifications, and joint attacks on video and language modalities are better than single-modality situations. Cross-modal threats further exploit alignment gaps: [Xu et al., 2024a] demonstrate that edited videos (e.g., social media deepfakes) mislead models by synchronizing deceptive visual and textual cues.

### 4.2 Scenario-Driven Attacks

MLLMs-based autonomous driving scenarios also face threats from adversarial attacks. [Fu et al., 2024] design PG-Attack, which combines precision-masked perturbations targeting critical regions such as vehicle movement, pedestrian activity, and traffic light changes with deceptive text patches to mislead model reasoning. Evaluated on CARLA-generated data, PG-Attack maintains perceptual stealth while achieving high attack success rates. Similarly, [Zhang et al., 2024d] propose ADvLM, which optimizes perturbations on key frames using semantic-invariant prompts, ensuring robustness against viewpoint and lighting changes. To enable transferable attacks against Vision-MLLMs in autonomous driving, [Chung et al., 2024] embed misleading typographic text into video frames such as altered traffic signs.

### 4.3 Benchmarks and Evaluation

Additionally, existing efforts aim to evaluate the robustness of video-MLLMs from various perspectives. In text-to-video generative models, T2VSafetyBench [Miao et al., 2024] assesses generative models against explicit content and misinformation, revealing higher risks in advanced models due to enhanced semantic understanding. Benchmark studies EditVid-QA [Xu et al., 2024a] and AV-Deepfake1M [Cai et al., 2024] benchmark performance on edited videos and synthetic deepfakes, respectively. Empirical studies [Xiao et al., 2024] further expose deficiencies in temporal grounding and adversarial robustness.

## 5 Attack on Audio-MLLMs

BadRobot exposes vulnerabilities in embodied MLLM that rely on audio inputs for interaction. Specifically, BadRobot analyzes three attacks, covering contextual jailbreaks, where carefully crafted audio inputs bypass restrictions to trigger harmful actions; safety misalignments, which exploit discrepancies between audio instructions and model responses; and conceptual deception, which breaks ethical constraints through subtasks embedded in speech instructions. Corresponding results reveal that even advanced systems like GPT-4-turbo exhibit weaknesses in these scenarios [Zhang et al., 2024a]. The potential for indirect instruction injection through adversarial audio perturbations further underscores the sensitivity of speech modalities. These attacks leverage carefully crafted audio cues to influence the model's output or alter its dialog flow. Experiments demonstrate over ${90}\%$ attack success rates in LLaVA [Bagdasaryan et al., 2023]. The Chat-Audio Attacks benchmark provides a structured framework for evaluating the robustness of MLLMs against diverse audio adversarial scenarios, including content modifications, emotional tone shifts. and implicit noise. Results reveal vulnerabilities that adversarial audio disrupts the semantic and contextual coherence of the models, even under controlled conditions [Yang et al., 2024]. In response to these challenges, Trust-NavGPT emerges to model audio uncertainties to improve the robustness of audio-guided navigation tasks. By integrating tonal ambiguities and pauses into its decision-making process, TrustNavGPT demonstrates a pathway toward mitigating adversarial risks in dynamic, real-world environments [Sun et al., 2024]. Finally, the AV-Deepfake 1M dataset emphasizes the importance of adversarial robustness in detecting temporally aligned manipulations across audio-visual modalities [Cai et al., 2024]. Experiments on this dataset show significant performance drops in existing frameworks, pushing for advancements in training methodologies that consider the temporal and multimodal intricacies of speech-based inputs.

## 6 Attack on Speech-MLLMs

Speech data is dynamic and prone to perturbations, including adversarial noise, semantic manipulations, and spoofing attacks. As MLLMs are increasingly utilized in real-world applications, such as speech-driven question answering (QA) and audio-command systems, ensuring their robustness against adversarial threats is important.

### 6.1 Adversarial Speech Attacks and Exploits

Recent research indicates that speech-based MLLMs are highly vulnerable to advanced adversarial techniques. For instance, SpeechGuard [Peri et al., 2024] shows that Projected Gradient Descent can trigger unsafe responses, while its Time-Domain Noise Flooding defense markedly reduces attack success rates. For Voice Jailbreak Attacks, adversaries deploy narrative-based prompts to circumvent security measures in advanced models like GPT-4o [Shen et al., 2024].

### 6.2 Benchmark and Evaluation

One benchmark evaluation in this area is the LlamaPartial-Spoof dataset, which investigates model robustness against partial and fully spoofed speech [Luong et al., 2024]. Using advanced Text-to-Speech, it generates realistic audio examples that simulate semantic-altering and splicing attacks. The study exposes significant weaknesses in detecting partial spoofs and requires diverse datasets and evaluation frameworks to bolster defenses against threats.

## 7 Defense Methods

### 7.1 Visual Modality Defenses

MLLM-Protector addresses adversarial image threats via a modular framework, combining a harm detector with a response detoxifier to filter unsafe outputs without degrading performance [Pi et al., 2024]. After that, MM-SafetyBench establishes standardized safety evaluation protocols for vision-language models, leveraging typographic and diffusion-generated adversarial images to expose vulnerabilities [Liu et al., 2025]. For CoT-enhanced models, Stop-Reasoning proposes adversarial training to mitigate attacks targeting intermediate reasoning steps, improving alignment between visual and textual reasoning [Wang et al., 2024b]. In parallel, FARE introduces unsupervised adversarial fine-tuning of vision encoders to preserve clean-task performance while hardening models against imperceptible perturbations, enabling robust deployment without downstream model adaptation [Schlarmann et al., 2024].

### 7.2 Audio and Speech Modality Defenses

SpeechGuard injects lightweight noise into audio signals to disrupt adversarial cues, improving robustness in spoken QA systems [Peri et al., 2024]. TrustNavGPT enhances robustness in audio-guided navigation by modeling semantic and tonal uncertainties, achieving a credible navigation performance when suffering adversarial attacks [Sun et al., 2024].

### 7.3 Video Modality Defenses

To enhance the robustness of video-LLMs, [Xiao et al., 2024] improves the strength of temporal reasoning, visual grounding, and adversarial resilience, ensuring that models effectively leverage visual information rather than exploiting linguistic shortcuts. Meanwhile, EditVid-QA [Xu et al., 2024a], strengthens defenses against edited and manipulated videos by introducing a diverse benchmark covering effects, memes, and social media transformations. These defenses are realized through frame-consistency learning, adaptive visual grounding, and domain-adaptive fine-tuning, ensuring models learn from real visual data instead of exploiting linguistic shortcuts.

## 8 Trends and Future Directions

### 8.1 Comprehensive Robustness Evaluation

Current robustness evaluation benchmarks are limited and can not be used to fully spectrum adversarial risks across modalities. Future efforts should prioritize the development of a multidimensional safety taxonomy that systematically defines safety dimensions. Additionally, there is a need to collect diverse and scalable datasets that balance volume, diversity, and adversarial realism. This includes incorporating synthetic adversarial examples (e.g., AdvDiffVLM-generated perturbations) and real-world attack scenarios (e.g., BadRobot's audio jailbreaks). To further enhance evaluation metrics, advanced LLMs should be leveraged to automate safety assessments, addressing prompt sensitivity and hallucination risks.

### 8.2 Cross-Modal and Transferable Attacks

While existing attacks expose modality-specific vulnerabilities, several gaps remain. Current attacks typically perturb individual modalities, but the interaction between perturbations (e.g., adversarial videos with synchronized audio-text triggers) remains underexplored. Moreover, most attacks assume white-box access or task-specific setups, limiting their applicability. Although methods such as AdvDiffVLM's ensemble gradient estimation and CroPA's cross-prompt adversarial transferability show promise, broader generalization to commercial models is necessary. Furthermore, video-MLLMs are vulnerable to temporal coherence exploits.

### 8.3 Data-Centric Security Risk

The reliance of MLLMs on multimodal training data introduces unique risks. Despite advancements in clean-label poisoning and universal triggers, defenses against domain-shifted triggers remain insufficient. Additionally, adversarial attacks often exploit inherent biases in training data. Future research should quantify the interaction between biases and adversarial manipulations, developing debiasing techniques during model alignment. Optimizing visual instruction tuning with safety-aware datasets and reinforcement learning could reduce vulnerabilities. However, challenges such as reward misalignment and multimodal preference modeling require further exploration.

### 8.4 Human-AI Collaborative Defense

As attacks on MLLMs become increasingly sophisticated, emerging defense paradigms integrate human expertise with automated systems. For example, TrustNavGPT [Sun et al., 2024] leverages uncertainty in audio-guided navigation, but broader frameworks could benefit from human oversight to identify subtle adversarial patterns. Developing interpretable defenses is essential to enhance transparency and trust in safety mechanisms.

### 8.5 Lacking Benchmarking and Standardization

Another obstacle to progress is the lack of standardized evaluation protocols. Existing attacks are tested on disparate models with inconsistent metrics. To address this, community-driven efforts should establish baselines for evaluation settings. Notably, current defenses mainly focus on modality-specific robustness and lack holistic metrics for cross-modal safety. Releasing modular frameworks will streamline research on attack or defense paradigms and foster further advancements in the field.

## 9 Conclusion

This survey explores the adversarial robustness of multimodal large language models (MLLMs). We begin by introducing the background and evaluation methods used to assess the robustness of MLLMs. We then categorize adversarial attacks across image, video, audio, and speech modalities, reviewing the vulnerabilities of MLLMs. Finally, we highlight key research gaps and unresolved issues that warrant further investigation in the field of MLLM robustness. We hope this survey provides valuable insights to researchers and encourages greater contributions to this growing area of study. References

[Bagdasaryan et al., 2023] Eugene Bagdasaryan, Tsung-Yin Hsieh, Ben Nassi, et al. (ab) using images and sounds for indirect instruction injection in multi-modal llms. arXiv preprint arXiv:2307.10490, 2023.

[Bailey et al., 2023] Luke Bailey, Euan Ong, Stuart Russell, et al. Image hijacks: Adversarial images can control generative models at runtime. In ${ICML},{2023}$ .

[Caba Heilbron et al., 2015] Fabian Caba Heilbron, Victor Escorcia, Bernard Ghanem, et al. Activitynet: A large-scale video benchmark for human activity understanding. In ${CVPR}$ , pages 961-970,2015.

[Cai et al., 2024] Zhixi Cai, Shreya Ghosh, Aman Pankaj Adatia, et al. Av-deepfakelm: A large-scale llm-driven audio-visual deepfake dataset. In ${ACMMM},{2024}$ .

[Carlini et al., 2024] Nicholas Carlini, Milad Nasr, Christopher A Choquette-Choo, et al. Are aligned neural networks adversarially aligned? NeurIPS, 2024.

[Chen et al., 2022] Chongyan Chen, Samreen Anjum, and Danna Gurari. Grounding answers for visual questions asked by visually impaired people. In CVPR, 2022.

[Chowdhury et al., 2024] Arijit Ghosh Chowdhury, Md Mofijul Islam, Vaibhav Kumar, et al. Breaking down the defenses: A comparative survey of attacks on large language models. arXiv preprint:2403.04786, 2024.

[Chung et al., 2024] Nhat Chung, Sensen Gao, Tuan-Anh Vu, et al. Towards transferable attacks against vision-llms in autonomous driving with typography. arXiv preprint arXiv:2405.14169, 2024.

[Cui et al., 2024] Xuanming Cui, Alejandro Aparcedo, Young Kyun Jang, et al. On the robustness of large multimodal models against image adversarial attacks. In CVPR, 2024.

[Dong et al., 2023] Yinpeng Dong, Huanran Chen, Jiawei Chen, et al. How robust is google's bard to adversarial image attacks? arXiv preprint arXiv:2309.11751, 2023.

[Fan et al., 2024] Yihe Fan, Yuxin Cao, Ziyu Zhao, et al. Unbridled icarus: A survey of the potential perils of image inputs in multimodal large language model security. arXiv preprint arXiv:2404.05264, 2024.

[Fu et al., 2024] Jiyuan Fu, Zhaoyu Chen, Kaixun Jiang, et al. Pg-attack: A precision-guided adversarial attack framework against vision foundation models for autonomous driving. arXiv preprint:2405.14169, 2024.

[Gao et al., ] Kuofeng Gao, Yang Bai, Jindong Gu, et al. Inducing high energy-latency of large vision-language models with verbose images. In ICLR.

[Gong et al., 2023] Yichen Gong, Delong Ran, Jinyuan Liu, et al. Figstep: Jailbreaking large vision-language models via typographic visual prompts. arXiv preprint arXiv:2311.05608, 2023.

[Goyal et al., 2017] Yash Goyal, Tejas Khot, Douglas Summers-Stay, et al. Making the $\mathrm{v}$ in vqa matter: Elevating the role of image understanding in visual question answering. In CVPR, pages 6904-6913, 2017.

[Gu et al., 2024] Xiangming Gu, Xiaosen Zheng, Tianyu Pang, et al. Agent smith: A single image can jailbreak one million multimodal llm agents exponentially fast. In ICML, 2024.

[Guo et al., 2024] Qi Guo, Shanmin Pang, Xiaojun Jia, et al. Efficient generation of targeted and transferable adversarial examples for vision-language models via diffusion models. IEEE Trans. Inf. Forensics Secur., 2024.

[Li et al., 2024] Jinmin Li, Kuofeng Gao, Yang Bai, et al. Fmm-attack: A flow-based multi-modal adversarial attack on video-based llms. arXiv preprint:2403.13507, 2024.

[Li et al., 2025] Yifan Li, Hangyu Guo, Kun Zhou, et al. Images are achilles' heel of alignment: Exploiting visual vulnerabilities for jailbreaking multimodal large language models. In ${ECCV},{2025}$ .

[Liang et al., 2024a] Jiawei Liang, Siyuan Liang, Man Luo, et al. Vl-trojan: Multimodal instruction backdoor attacks against autoregressive visual language models, 2024.

[Liang et al., 2024b] Siyuan Liang, Jiawei Liang, Tianyu Pang, et al. Revisiting backdoor attacks against large vision-language models. CoRR, 2024.

[Lin et al., 2014] Tsung-Yi Lin, Michael Maire, Serge Be-longie, et al. Microsoft coco: Common objects in context. In ${ECCV}$ , pages 740-755,2014.

[Liu et al., 2024a] Daizong Liu, Mingyu Yang, Xiaoye Qu, et al. A survey of attacks on large vision-language models: Resources, advances, and future trends. arXiv preprint arXiv:2407.07403, 2024.

[Liu et al., 2024b] Xin Liu, Yichen Zhu, Yunshi Lan, et al. Safety of multimodal large language models on images and text. In IJCAI-24, 2024. Survey Track.

[Liu et al., 2025] Xin Liu, Yichen Zhu, Jindong Gu, et al. Mm-safetybench: A benchmark for safety evaluation of multimodal large language models. In ${ECCV},{2025}$ .

[Lu et al., 2022] Pan Lu, Swaroop Mishra, Tanglin Xia, et al. Learn to explain: Multimodal reasoning via thought chains for science question answering. NeurIPS, 2022.

[Lu et al., 2024] Dong Lu, Tianyu Pang, Chao Du, et al. Test-time backdoor attacks on multimodal large language models, 2024.

[Luong et al., 2024] Hieu-Thi Luong, Haoyang Li, Lin Zhang, et al. Llamapartialspoof: An llm-driven fake speech dataset simulating disinformation generation. arXiv preprint arXiv:2409.14743, 2024.

[Marino et al., 2019] Kenneth Marino, Mohammad Raste-gari, Ali Farhadi, et al. Ok-vqa: A visual question answering benchmark requiring external knowledge. In CVPR, pages 3195-3204, 2019.

[Miao et al., 2024] Yibo Miao, Yifan Zhu, Lijia Yu, et al. T2vsafetybench: Evaluating the safety of text-to-video generative models. In NeurIPS, 2024.

[Ni et al., 2024] Zhenyang Ni, Rui Ye, Yuxi Wei, et al. Physical backdoor attack can jeopardize driving with vision-large-language models. arXiv preprint arXiv:2404.12916, 2024.

[Niu et al., 2024] Zhenxing Niu, Haodong Ren, Xinbo Gao, et al. Jailbreaking attack against multimodal large language model. arXiv preprint arXiv:2402.02309, 2024.

[Panayotov et al., 2015] Vassil Panayotov, Guoguo Chen, Daniel Povey, et al. Librispeech: an asr corpus based on public domain audio books. In ICASSP, 2015.

[Peri et al., 2024] Raghuveer Peri, Sai Muralidhar Jayanthi, Srikanth Ronanki, et al. Speechguard: Exploring the adversarial robustness of multimodal large language models. arXiv preprint arXiv:2405.08317, 2024.

[Pi et al., 2024] Renjie Pi, Tianyang Han, Jianshu Zhang, et al. Mllm-protector: Ensuring mllm's safety without hurting performance. arXiv:2401.02906, 2024.

[Plummer et al., 2015] Bryan A Plummer, Liwei Wang, Chris M Cervantes, et al. Flickr30k entities: Collecting region-to-phrase correspondences for richer image-to-sentence models. In ICCV, pages 2641-2649, 2015.

[Qi et al., 2023] Xiangyu Qi, Yi Zeng, Tinghao Xie, et al. Fine-tuning aligned language models compromises safety, even when users do not intend to! In ICLR, 2023.

[Qi et al., 2024] Xiangyu Qi, Kaixuan Huang, Ashwinee Panda, et al. Visual adversarial examples jailbreak aligned large language models. In ${AAAI},{2024}$ .

[Rafailov et al., 2024] Rafael Rafailov, Archit Sharma, Eric Mitchell, et al. Direct preference optimization: Your language model is secretly a reward model. NeurIPS, 2024.

[Schlarmann and Hein, 2023] Christian Schlarmann and Matthias Hein. On the adversarial robustness of multimodal foundation models. In CVPR, 2023.

[Schlarmann et al.,2024] Christian Schlarmann, Naman Deep Singh, Croce Francesco, et al. Robust clip: Unsupervised adversarial fine-tuning of vision embed-dings for robust large vision-language models. In ICML, 2024.

[Shen et al., 2024] Xinyue Shen, Yixin Wu, Michael Backes, et al. Voice jailbreak attacks against gpt-4o. arXiv preprint arXiv:2405.19103, 2024.

[Sun et al., 2024] Xingpeng Sun, Yiran Zhang, Xindi Tang, et al. Trustnavgpt: Modeling uncertainty to improve trustworthiness of audio-guided llm-based robot navigation. arXiv preprint arXiv:2408.01867, 2024.

[Tao et al., 2024] Xijia Tao, Shuai Zhong, Lei Li, et al. Imgtrojan: Jailbreaking vision-language models with one image. arXiv preprint arXiv:2403.02910, 2024.

[Tu et al., 2024] Haoqin Tu, Chenhang Cui, Zijun Wang, et al. How many are in this image a safety evaluation benchmark for vision llms. In ${ECCV},{2024}$ .

[Wang et al., 2024a] Ruofan Wang, Xingjun Ma, Hanxu Zhou, , et al. White-box multimodal jailbreaks against large vision-language models. In ${ACMMM},{2024}$ .

[Wang et al., 2024b] Zefeng Wang, Zhen Han, Shuo Chen, et al. Stop reasoning! when multimodal llms with chain-of-thought reasoning meets adversarial images. arXiv preprint arXiv:2402.14899, 2024.

[Wu et al., 2023] Yuanwei Wu, Xiang Li, Yixin Liu, et al. Jailbreaking gpt-4v via self-adversarial attacks with system prompts. arXiv preprint arXiv:2311.09127, 2023.

[Wu et al., 2024] Chen Henry Wu, Rishi Rajesh Shah, Jing Yu Koh, et al. Dissecting adversarial robustness of multimodal Im agents. In NeurIPS Workshop on Open-World Agents, 2024.

[Xiao et al., 2024] Junbin Xiao, Nanxin Huang, Hangyu Qin, et al. Videoqa in the era of llms: An empirical study. arXiv preprint arXiv:2408.04223, 2024.

[Xu et al., 2017] Dejing Xu, Zhou Zhao, Jun Xiao, et al. Video question answering via gradually refined attention over appearance and motion. In ${ACMMM}$ , pages 1645- 1653, 2017.

[Xu et al., 2024a] Lu Xu, Sijie Zhu, Chunyuan Li, et al. Beyond raw videos: Understanding edited videos with large multimodal model. arXiv preprint arXiv:2406.10484, 2024.

[Xu et al., 2024b] Yuancheng Xu, Jiarui Yao, Manli Shu, et al. Shadowcast: Stealthy data poisoning attacks against vision-language models. In ICLR Workshop on Navigating and Addressing Data Problems for Foundation Models, 2024.

[Yang et al., 2024] Wanqi Yang, Yanda Li, Meng Fang, et al. Who can withstand chat-audio attacks? an evaluation benchmark for large language models. arXiv preprint arXiv:2411.14842, 2024.

[Zhang et al., 2023] Zhexin Zhang, Leqi Lei, Lindong Wu, et al. Safetybench: Evaluating the safety of large language models with multiple choice questions. arXiv preprint arXiv:2309.07045, 2023.

[Zhang et al., 2024a] Hangtao Zhang, Chenyu Zhu, Xian-long Wang, et al. Badrobot: Manipulating embodied llms in the physical world. arXiv preprint arXiv:2407.20242, 2024.

[Zhang et al., 2024b] Hao Zhang, Wenqi Shao, Hong Liu, et al. B-avibench: Towards evaluating the robustness of large vision-language model on black-box adversarial visual-instructions. IEEE Trans. Inf. Forensics Secur., 2024.

[Zhang et al., 2024c] Jingyi Zhang, Jiaxing Huang, Sheng Jin, et al. Vision-language models for vision tasks: A survey. IEEE Trans. Pattern Anal. Mach. Intell., 2024.

[Zhang et al., 2024d] Tianyuan Zhang, Lu Wang, Xinwei Zhang, et al. Visual adversarial attack on vision-language models for autonomous driving. arXiv preprint arXiv:2411.18275, 2024.

[Zhao et al., 2024] Yunqing Zhao, Tianyu Pang, Chao Du, et al. On evaluating adversarial robustness of large vision-language models. NeurIPS, 2024.

[Zhu et al., 2024] Yichen Zhu, Minjie Zhu, Ning Liu, et al. Llava-phi: Efficient multi-modal assistant with small language model. In ${EMCLR},{2024}$ .