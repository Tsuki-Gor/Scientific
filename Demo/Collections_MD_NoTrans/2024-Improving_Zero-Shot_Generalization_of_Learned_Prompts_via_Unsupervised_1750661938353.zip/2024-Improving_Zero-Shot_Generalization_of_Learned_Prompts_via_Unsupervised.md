# Improving Zero-shot Generalization of Learned Prompts via Unsupervised Knowledge Distillation

*Marco Mistretta ${}^{1}$ O,*Alberto Baldrati ${}^{1,2}$ O,

Marco Bertini ${}^{1}$ , and Andrew D. Bagdanov ${}^{1}$

${}^{1}$ University of Florence - Media Integration and Communication Center (MICC)

${}^{2}$ University of Pisa

Florence, Italy - Pisa, Italy

\{name.surname\}@unifi.it

Abstract. Vision-Language Models (VLMs) demonstrate remarkable zero-shot generalization to unseen tasks, but fall short of the performance of supervised methods in generalizing to downstream tasks with limited data. Prompt learning is emerging as a parameter-efficient method for adapting VLMs, but state-of-the-art approaches require annotated samples. In this paper we propose a novel approach to prompt learning based on unsupervised knowledge distillation from more powerful models. Our approach, which we call Knowledge Distillation Prompt Learning (KDPL), can be integrated into existing prompt learning techniques and eliminates the need for labeled examples during adaptation. Our experiments on more than ten standard benchmark datasets demonstrate that KDPL is very effective at improving generalization of learned prompts for zero-shot domain generalization, zero-shot cross-dataset generalization, and zero-shot base-to-novel class generalization problems. KDPL requires no ground-truth labels for adaptation, and moreover we show that even in the absence of any knowledge of training class names (CA-KDPL) can be used to effectively transfer knowledge. The code is publicly available at https://github.com/miccunifi/KDPL

Keywords: Prompt Learning - Unsupervised Knowledge Distillation - Vision-Language Models - Few-Shot Learning - Zero-shot Transfer.

## 1 Introduction

Vision-Language Models (VLMs) like Contrastive Language-Image Pre-training (CLIP) are remarkably effective at zero-shot generalization to downstream tasks 3,42,44,66. These models leverage a dual encoder architecture and are trained to align image and text features in a shared embedding space. CLIP and similar models are able to perform zero-shot classification by predicting the output class based on the similarity between the test image embedding and text embeddings of words from a fixed vocabulary.

---

* These authors contributed equally to this work.

---

![bo_d1c3l9bef24c73d2ojn0_1_385_330_1038_462_0.jpg](images/bo_d1c3l9bef24c73d2ojn0_1_385_330_1038_462_0.jpg)

Fig. 1: Motivation and overview. (Top left) Lightweight VLMs like CLIP achieve impressive zero-shot performance but lag behind supervised approaches; large VLMs incur a high computational burden. (Bottom left) Parameter-efficient prompt learning offers a non-destructive approach to adapting VLMs to downstream tasks; however, existing methods require annotated samples and struggle to generalize to unseen classes. (Right) Our approach does not require labeled samples and learns by distilling knowledge from a more powerful VLM. It can be seamlessly integrated into existing prompt learning techniques and generalizes better to unseen classes on downstream tasks.

While CLIP exhibits remarkable zero-shot performance, it can fall short of supervised adaptation. Narrowing this gap through fine-tuning is challenging when large training datasets are not available for downstream tasks. Moreover, fine-tuning can also lead to overfitting and is destructive in that it can cause the model to forget knowledge acquired during large-scale pre-training [14,68].

An intuitive way to achieve better performance is to use larger and more powerful VLMs [10] with better zero-shot generalization. However, though performance improves with increasing size, their practical applicability in real-world scenarios decreases. Lightweight CLIP models based on ResNet-50 and ViT-B/32 require about 18 and 14 GFLOPs for inference, respectively. In contrast, more powerful models based on ViT-H/14 10,18 require nearly ${30} \times$ the computation at 381 GFLOPs [18] for inference.

To address these challenges, parameter-efficient prompt learning is emerging as a promising and non-destructive approach to adapting VLMs to downstream tasks [34, 35, 65]. Zhou et al. [68] proposed a text-only prompt learning approach called CoOp to overcome the limitations of manually crafted prompts. Subsequently, Jia et al. [29] extended prompt learning to the visual domain with Visual Prompt Tuning (VPT), and Khattak et al. [30, 31] proposed a multi-modal prompt learning approach called MaPLe [30] and a self-regulated approach called PromptSRC [31]. Although significantly improving over carefully tuned, handcrafted prompts, these state-of-the-art techniques all require annotated samples from the dataset and have problems generalizing to other datasets or classes unseen during training $\left\lbrack  {{30},{67}}\right\rbrack$ .

To eliminate the need for labeled training examples and improve the generalization of learned prompts, we propose a novel approach to prompt learning which we call Knowledge Distillation Prompt Learning (KDPL). KDPL adapts lightweight VLMs and improves performance on downstream tasks by distilling knowledge from a more powerful VLM without the need for annotated examples. KDPL is a flexible method that can be seamlessly integrated into existing prompt learning framework such as CoOp [68], CoCoOp [67], VPT [29], MaPLe 30, and PromptSRC 31. Figure 1 summarizes the motivations and illustrates the workflow of the proposed approach. We validate KDPL on two increasingly challenging scenarios: in the first, we assume knowledge of training class names, while in the second we assume no knowledge of training classes. Importantly, in both scenarios no annotated training samples are used.

The contributions of this work are:

- we propose a novel parameter-efficient prompt-learning approach that eliminates the need for labeled training examples by distilling knowledge from a large Vision-Language Model;

- we show that our approach can be integrated into existing prompt learning techniques to learn visual, textual, and multimodal prompts which generalize significantly better than state-of-the-art baselines to unseen classes in downstream tasks;

- we demonstrate the effectiveness of our approach through extensive experiments on more than ten standard benchmark datasets covering a broad range of downstream problems, including domain generalization, cross-dataset adaptation, and base-to-novel generalization; and

- we introduce a new, class agnostic evaluation setting in which training class names are unknown and show the superiority of our approach in this scenario.

To the best of our knowledge ours is the first approach to parameter-efficient VLM adaptation which is applicable in scenarios that are label agnostic (i.e. no label supervision is required during adaptation) and also in scenarios that are additionally class agnostic (i.e. no knowledge of training class names is assumed).

## 2 Related Work

In this section we review the recent literature most relevant to our contribution.

Vision-Language Models. Vision-Language Models (VLMs) learn robust visual representations thanks to their extensive pre-training on image-caption datasets 47, 48 . These representations are very effective at generalizing to a variety of downstream tasks [13, 28, 44]. In contrast to vision models trained only with image supervision, vision-language models can interpret both visual and textual data, showing improvement in tasks requiring cross-model understanding $\left\lbrack  {3,4,{52}}\right\rbrack$ . We focus on contrastively-trained VLMs such as CLIP [44, ALIGN [28], and LiT [61]. These models use a dual encoder architecture and contrastive learning to align images and text in a common embedding space. Thanks to this shared embedding space and massive pre-training datasets these models achieve remarkable performance. However, there is still a gap between the zero-shot capabilities of these VLMs and the performance of tailored state-of-the-art models [15, 44], and thus there is active research on efficient and effective methods to adapt VLMs to downstream tasks [21,38,55,62].

Prompt Learning. The performance of VLMs is highly dependent on textual prompts used to characterize downstream tasks. Given the significant impact of small changes in wording on performance, the manual generation of optimal textual prompts is a challenging task. Inspired by developments in NLP 34,35, 65, CoOp [68] proposes to learn continuous vectors in the word embedding space instead of using tailored hand-crafted prompts.

The promising results of $\mathrm{{CoOp}}$ have attracted considerable interest in prompt learning for VLMs [1, 2, 7, 8, 30, 31, 37, 49, 50, 58, 69]. CoCoOp, in particular, highlights the poor performance of $\mathrm{{CoOp}}$ on unseen classes and uses image-conditional dynamic prompts to improve generalization [67]. PLOT [8] instead is based on learning multiple prompts by exploiting local visual features. Kg-CoOp 58 adds a regularization loss to minimize the discrepancy between learned and hand-crafted prompts, while VPT [29] adapts prompt learning to the visual domain by learning continuous vectors in the input space of a ViT [16]. Finally, MaPLe [30] introduces a multimodal prompt learning strategy for VLMs. PromptSRC [31] introduces a self-regularization framework for prompting, addressing overfitting through agreement with a frozen model, a self-ensemble of prompts, and textual diversity.

Similar to the approach we propose in this paper, UPL [27] performs prompt learning without relying on annotated samples. It leverages pseudolabels derived from a larger CLIP model and selects the top-K most confident samples per class to construct a balanced set of pseudo-labels. UPL requires a substantial collection of unlabeled images and is not directly applicable when only a few unlabeled samples are available, like in the few-shot adaptation scenarios considered here. In contrast to UPL, KDPL does not use pseudolabeling; instead, we directly learn from the logits of a CLIP teacher model via knowledge distillation, thus eliminating the need for any selection strategy of the training samples.

Knowledge Distillation. Knowledge distillation (KD) is a machine learning technique in which a simple model (student) is trained to mimic the behavior of a larger model (teacher) by learning from its output or intermediate activation [26]. This technique has found success in many contexts, including image classification [5, 9, 26], self-supervised learning [19, 57], and image/video segmentation [17, 22, 40, 51], leading to improvements in model compression, computational efficiency, and performance. DML [63] introduces a mutual learning approach to train students and teachers simultaneously. DKD [64] reformulates the classical KD loss into a term related to the target class and a term related to the non-target classes. In contrast to the majority of knowledge distillation approaches [59, 60, 63, 64], we do not utilize any labels during training. Instead, we solely employ the distillation loss. In our work, we apply knowledge distillation in a parameter-efficient prompt learning scenario. Specifically, we distill knowledge from a large and powerful VLM (teacher) into a lightweight VLM (student) by updating only a reduced number of parameters (the prompt).

Techniques Using Teacher-Student Distillation. Recently Li et al. [36] introduced PromptKD which also uses teacher-student distillation in prompt learning. Although it too leverages a larger teacher to guide a smaller student, it differs from our contribution in several key aspects. PromptKD uses Prompt-SRC [31] to pre-train the teacher model with labeled examples, whereas KDPL does not pre-train the teacher and requires no labeled examples. PromptKD uses an MLP to project the student image encoder output, which adds extra parameters. KDPL is instead a general framework with no additional parameters, adaptable to any prompt-tuning technique to render them completely unsupervised. Moreover, PromptKD uses the entire training set, including both base and novel images, for distillation. In contrast, KDPL follows the standard 16-shot setting.

## 3 Knowledge Distillation Prompt Learning (KDPL)

We first introduce preliminary concepts related to prompt learning and then describe our approach to applying knowledge distillation to the problem.

### 3.1 Preliminaries

Our approach is based on knowledge distillation applied to prompt learning. Here we discuss the base teacher and student models (CLIPs) and five state-of-the-art prompt learning approaches into which we will incorporate KDPL.

CLIP. Contrastive Language-Image Pre-training (CLIP) is a vision-language model trained to align images and textual captions in shared semantic space [44. CLIP consists of an image encoder ${f}_{\theta }$ and a text encoder ${g}_{\phi }$ . Given an image $\bar{I}$ , the image encoder computes its feature representation ${f}_{\theta }\left( I\right)  \in  {\mathbb{R}}^{d}$ , where $d$ is the size of the semantic embedding space. Similarly, for a given textual caption $Y$ , a word embedding layer ${E}_{L}$ maps each tokenized word to the token embedding space $\mathcal{W}$ . Then, the text encoder ${g}_{\phi }$ generates the textual feature representation ${g}_{\phi }\left( {{E}_{L}\left( Y\right) }\right)  \in  {\mathbb{R}}^{d}$ . The main goal of CLIP training is to learn $\theta$ and $\phi$ such that ${f}_{\theta }\left( I\right)  \approx  {g}_{\phi }\left( {{E}_{L}\left( Y\right) }\right)$ for associated image/text pairs(I, Y).

When using a Vision Transformer (ViT) [16] as the visual encoder ${f}_{\theta }$ , the encoding process begins by splitting the image into $U$ fixed-size patches. These patches are then projected into patch embeddings $\left\{  {{w}_{1},{w}_{2},\ldots ,{w}_{U}}\right\}$ , where each ${w}_{i}$ belongs to the patch embedding space $\mathcal{V}$ . A learnable class (CLS) token ${c}_{i}$ is concatenated with the patch embeddings, resulting in the input to the vision transformer being $\left\{  {{c}_{i},{w}_{1},{w}_{2},\ldots ,{w}_{U}}\right\}$ . Finally, the CLS token of the final transformer layer is projected to the shared embedding space via a linear projection to obtain the final representation.

To perform zero-shot classification using CLIP, we start with an image $I$ and build a set of textual prompts ${\left\{  {Y}_{i}\right\}  }_{i = 1}^{C}$ , where $C$ denotes the number of classes. Each handcrafted text prompt ${Y}_{i}$ takes the format " $a$ photo of a [CLASS ${S}_{i}$ ]", where ${\mathrm{{CLASS}}}_{i}$ represents a specific class name, such as airplane, bird, etc.

Then the feature representations ${\psi }_{I} = {f}_{\theta }\left( I\right)$ and ${\psi }_{T}^{i} = {g}_{\phi }\left( {{E}_{L}\left( {Y}_{i}\right) }\right)$ are extracted using the CLIP encoders. The predicted probability for each class is:

$$
p\left( {y = i \mid  I}\right)  = \frac{\exp \left( {\cos \left( {{\psi }_{T}^{i},{\psi }_{I}}\right) /\tau }\right) }{\mathop{\sum }\limits_{{j = 1}}^{C}\exp \left( {\cos \left( {{\psi }_{T}^{j},{\psi }_{I}}\right) /\tau }\right) }, \tag{1}
$$

where $\cos \left( {\cdot , \cdot  }\right)$ is the cosine similarity and $\tau$ is a temperature hyperparameter.

Prompt-Learning Techniques. Here we summarize how the state-of-the-art techniques for textual, visual, and multimodal prompt learning work.

- CoOp [68] is a textual prompt learning technique that learns continuous context tokens (i.e. the learnable prompt) in the CLIP token embedding space. Specifically, $\operatorname{CoOp}$ introduces $M$ learnable vectors, $\left\{  {{v}_{1},{v}_{2},\ldots ,{v}_{M}}\right\}$ where each context vector ${v}_{i} \in  \mathcal{W}$ . For each of the $k$ classes of a dataset, the input to the text encoder is $\left\{  {{v}_{1},{v}_{2},\ldots ,{v}_{M},{c}_{k}}\right\}$ , where ${c}_{k} = {E}_{L}\left( \left\lbrack  {{CLAS}{S}_{k}}\right\rbrack  \right)$ .

- CoCoOp [67] extends CoOp by incorporating a lightweight network ${h}_{\theta }$ . Each context token is obtained as ${v}_{i}\left( I\right)  = {v}_{i} + \pi$ , where $\pi  = {h}_{\theta }\left( I\right)$ . This method ensures that the textual prompts are conditioned on the input image.

- VPT [29] is a visual prompt learning method that can be viewed as the counterpart of $\mathrm{{CoOp}}$ in the visual domain. Unlike $\mathrm{{CoOp}}$ , which operates entirely in the textual token embedding space $\mathcal{W}$ , VPT performs prompt learning in the visual patch embedding space $\mathcal{V}$ . Specifically, VPT learns $P$ visual tokens, leading to the input to the ViT being $\left\{  {{z}_{1},\ldots ,{z}_{P},{c}_{i},{w}_{1},{w}_{2},\ldots ,{w}_{U}}\right\}$ . VPT offers two prompting variants: deep and shallow. The deep variant learns a distinct prompt for each ViT layer, while the shallow variant incorporates the prompt parameters only into the input of the first layer.

- MaPLe [30] is a deep multi-modal prompt learning technique that promotes strong coupling between vision and language prompts. In practice, MaPLe learns different textual context tokens for each layer in ${g}_{\phi }$ . The visual prompts, on the other hand, are not directly learned but are obtained through a linear mapping from the textual ones.

- PromptSRC [31] is another multi-modal prompt learning technique that optimizes prompts through mutual agreement maximization between prompted and frozen model features using self-distillation, Gaussian-weighted prompt aggregation over the training session, and promoting textual diversity to address sample diversity imbalance.

Note that methods involving visual prompt learnable tokens like VPT [29], MaPLe [30], and PromptSRC [31] can only be applied to VLMs equipped with a ViT-based image encoder.

### 3.2 Label Agnostic Prompt Learning

The methods described above all rely on ground-truth labels during adaptation. Here we show how unsupervised knowledge distillation can be used instead to replace the need for annotated training examples.

![bo_d1c3l9bef24c73d2ojn0_6_395_331_1010_305_0.jpg](images/bo_d1c3l9bef24c73d2ojn0_6_395_331_1010_305_0.jpg)

Fig. 2: Knowledge Distillation Prompt Learning (KDPL) overview. Given a lightweight VLM student and a larger, more powerful VLM teacher, KDPL updates the student prompt parameters by distilling knowledge from the teacher. KDPL first performs zero-shot classification with the teacher to obtain teacher probabilities ${p}_{T}$ . It then computes the student probabilities ${p}_{S}$ and performs knowledge distillation to update the student prompt parameters $\gamma$ .

Overview. Our proposed approach, which we call Knowledge Distillation Prompt Learning (KDPL), is a general method designed to enhance the performance of the CLIP model on downstream tasks through parameter-efficient prompt learning. Unlike previous approaches [30,67,68], which rely on labeled examples for training, KDPL eliminates the need for manually-labeled samples by learning only through knowledge distillation from a larger and more powerful VLM. Note that KDPL is a method that can be seamlessly integrated with any existing prompt learning approach in scenarios where no information about class names or labels is available.

We validate KDPL in two progressively challenging supervision regimes. In the label agnostic scenario we do not use ground-truth labels, but we assume knowledge of the class names in the training dataset. In the class agnostic scenario (see Section 3.3) we go one step further and assume that even the training class names are unknown. For this class agnostic scenario we propose an effective and efficient online strategy for automatically filtering the classes from a large dictionary of approximately ${20}\mathrm{\;K}$ class names [33].

Prompt Learning via Unsupervised Knowledge Distillation (KDPL). Given a lightweight CLIP model (the student) and a larger, more powerful CLIP model (the teacher), we aim to improve the downstream performance of the student model by distilling knowledge from teacher to student. For an image $I$ and a set of classes $\mathcal{C} = {\left\{  {\mathrm{{CLASS}}}_{i}\right\}  }_{i = 1}^{C}$ , we start by performing zero-shot classification using the frozen teacher model. Specifically, we use the teacher image encoder ${f}_{\theta }^{B}$ and text encoder ${g}_{\phi }^{B}$ to compute the teacher image features ${\psi }_{I, B} = {f}_{\theta }^{B}\left( I\right)$ and text features ${\psi }_{T, B}^{i} = {g}_{\phi }^{S}\left( {{E}_{L}\left( \left\lbrack  {\mathrm{{CLASS}}}_{i}\right\rbrack  \right) }\right)$ . For the teacher model we use the fixed text prompt "a photo of [CLASS]". We then apply Eq. (1) to produce the probabilities ${p}_{T}\left( {I,\mathcal{C}}\right)$ predicted by the teacher on image $I$ for classes $\mathcal{C}$ .

The teacher model does not rely on a learnable prompt and its predictions remain fixed during training. Our aim is to learn text and image prompts for the student model that enhance its generalization to downstream tasks.

We denote with ${f}_{\theta }^{S}$ and ${g}_{\phi }^{S}$ the student image and text encoders, respectively, and with $\gamma$ the parameters associated with the learnable student prompts (see Fig. 2). Given the same image $I$ processed by the teacher and the same set of classes $\mathcal{C}$ , the student extracts image features ${\psi }_{I, S} = {f}_{\theta ,\gamma }^{S}\left( I\right)$ and text features ${\psi }_{T, S}^{i} = {g}_{\phi ,\gamma }^{S}\left( {{E}_{L}\left( \left\lbrack  {\mathrm{{CLASS}}}_{i}\right\rbrack  \right) }\right)$ . Note that the text and image encoders can both depend on the prompt parameters $\gamma$ . According to the prompt learning technique used, the $\gamma$ parameters can be used only by the text encoder (CoOp, CoCoOp), the visual encoder (VPT), or both (MaPLe, PromptSRC). Finally, using Eq. (1) we produce student class probabilities ${p}_{S}\left( {I,\mathcal{C}}\right)$ predicted on image $I$ for classes $\mathcal{C}$ . Note that all encoder parameters except for the learnable prompt $\gamma$ are frozen.

We use the symmetric KL-divergence between the teacher $\left( {{p}_{T}\left( {I,\mathcal{C}}\right) }\right)$ and the student $\left( {{p}_{S}\left( {I,\mathcal{C}}\right) }\right)$ probabilities in a distillation loss:

$$
\mathcal{L}\left( {\mathcal{I},\mathcal{C}}\right)  = \left\lbrack  {{D}_{\mathrm{{KL}}}\left( {{p}_{T}\left( {I,\mathcal{C}}\right) \parallel {p}_{S}\left( {I,\mathcal{C}}\right) }\right)  + {D}_{\mathrm{{KL}}}\left( {{p}_{S}\left( {I,\mathcal{C}}\right) \parallel {p}_{T}\left( {I,\mathcal{C}}\right) }\right) }\right\rbrack  , \tag{2}
$$

where $D\left( {q\parallel p}\right)$ is the asymmetric KL-divergence between the discrete probability distributions $p$ and $q$ :

$$
{D}_{\mathrm{{KL}}}\left( {p\parallel q}\right)  = \mathop{\sum }\limits_{{i \in  \mathcal{C}}}{p}_{i}\log \left( \frac{{p}_{i}}{{q}_{i}}\right)  \tag{3}
$$

This distillation loss depends only on the fixed predictions of the teacher, the prompt-conditioned predictions of the students, and the set of classes $\mathcal{C}$ .

Importantly, our distillation loss does not assume any knowledge of class labels for image $I$ . Nor does it require that $\mathcal{C}$ be the classes of the downstream task - that is, KDPL can be used for Label Agnostic and Class Agnostic adaptation scenarios. We found in early experiments that the symmetric KL-divergence works slightly better than either asymmetric option (see Section B.3. in the Supplementary Material for an ablation study on this choice).

### 3.3 Class Agnostic Prompt Learning

To further evaluate the generalization capabilities of KDPL, we introduce a scenario where not only do we not know the labels of training images (label agnostic, Section 3.2) but where we also do not even know the class names associated with the dataset (class agnostic). This scenario is considerably more challenging as we make no assumptions about the few-shot training data.

To address the unavailability of class names, we propose a strategy for automatically selecting a set of class names for each batch. We start with a large vocabulary of class names from which to select. Specifically, we use the Open Images V7 dataset [33], which contains $\sim  {20}\mathrm{\;K}$ classes. The most straightforward method would simply use all ${20}\mathrm{\;K}$ classes during training. However, this is impractical as the memory required by prompt learning methods increases linearly with the number of classes. According to Ren et al. 46, CoOp requires nearly 15MB of VRAM per class, resulting in approximately 300GB of memory when multiplied by ${20}\mathrm{\;K}$ classes. Therefore, we propose a method to automatically select which classes to use for each batch by retaining only the ones most relevant to the calculation of the loss in Eq. (2).

Given a batch of images $X = {\left\{  {I}_{i}\right\}  }_{i = 1}^{N}$ and all the class names in the vocabulary $\mathcal{C} = {\left\{  {\mathrm{{CLASS}}}_{i}\right\}  }_{i = 1}^{C}$ , where $N$ represents the number of images in a batch and $C$ the size of the dictionary, we let the teacher model select the most relevant classes. Our objective is to identify the most useful $K$ classes in each batch for student prompt learning. After extracting the teacher image and text features, for each image ${I}_{i} \in  X$ , we apply Eq. (1) to obtain the teacher probabilities ${p}_{T}\left( {{I}_{i},\mathcal{C}}\right)$ . By stacking the probabilities along the batch dimension, we obtain the matrix ${P}_{T} = {\left\lbrack  {p}_{T}\left( {I}_{1},\mathcal{C}\right) ;\cdots ;{p}_{T}\left( {I}_{N},\mathcal{C}\right) \right\rbrack  }^{T} \in  {\mathbb{R}}^{N \times  C}$ , where the $i$ -th row corresponds to the probabilities associated with image ${I}_{i}$ . We then compute the average probabilities along the batch axis, resulting in $\overline{{P}_{T}} \in  {\mathbb{R}}^{C}$ . Finally, we select the classes corresponding to the $K$ highest values in $\overline{{P}_{T}}$ .

Using the teacher model to perform this class filtering for each batch is feasible and does not incur excessive memory costs since the teacher requires no gradient computation. Therefore, the memory consumption does not depend on the number of classes in $\mathcal{C}$ . Conversely, although the student model remains frozen, gradients must still be propagated to update the prompt parameters $\gamma$ . Once the classes are selected, the training strategy remains the same as described above, with the only difference being that the class names observed by the student vary in each batch based on teacher predictions.

## 4 Experimental Results

In this section we report on experiments validating our proposed approach.

### 4.1 Evaluated Scenarios and Implementation Details

Following previous works [30,67,68], we validate KDPL in three distinct settings: 1) domain generalization; 2) cross-dataset transfer; 3) generalization to unseen classes. Additionally, to evaluate the scenario where class names are also unknown, we introduce a new evaluation setting we call class agnostic adaptation. We use the train/val/test splits and seeds provided by Zhou et al. [68] for all datasets. All reported results are averages over three independent runs.

Evaluated Scenarios. We evaluate KDPL on the following scenarios:

- Domain Generalization. To assess the ability of the learned prompts to generalize to out-of-distribution datasets, we apply the prompt learned from ImageNet 12 to four different versions of ImageNet datasets exhibiting various types of domain shift. The target datasets are ImageNetV2 [45], ImageNet-Sketch [54], ImageNet-A [25], and ImageNet-R [24].

---

${}^{3}$ https://github.com/KaiyangZhou/CoOp/blob/main/DATASETS.md

---

- Cross-dataset Transfer. To evaluate the ability of learned prompts to generalize to unseen classes, we evaluate the same prompt trained on Ima-geNet on a broad range of downstream recognition tasks. We validate on ten datasets with varying characteristics: Caltech101 [20] for general object classification; OxfordPets [43], StanfordCars [32], Flowers102 [41], Food101 [6], and FGVCAircraft [39] for fine-grained classification; the Describable Textures Dataset (DTD) [11] for texture classification; EuroSAT [23] for satellite-image recognition; and UCF101 [53] for action recognition.

- Generalization to Unseen Classes. To evaluate how learned prompts generalize to unseen classes from the same dataset, we divide classes into two subsets: base and novel classes. The prompt is trained exclusively on the base classes and then tested on the novel ones. We evaluate on ImageNet as well as the ten benchmark datasets used for cross-dataset evaluation.

- Class Agnostic Adaptation. In addition we introduce a novel evaluation setting in which the training class names are unknown. The prompt is trained on ImageNet and tested on all the benchmark datasets used in the domain generalization and cross-dataset evaluations.

Implementation Details. We use a CLIP model with a ViT-H-14 visual backbone as the teacher model 4 For student models, we evaluate both on a CLIP model based on ResNet-50 and a model based on ViT-B/32. By experimenting with both ResNet-based and ViT-based CLIP models we show the architecture independence of our approach. To assess how KDPL performs when integrated into different prompt learning techniques, we selected five distinct textual, visual, and multimodal approaches. With the ResNet-50 student model, we experiment with CoOp [68] and CoCoOp [67]. For the ViT-B/32 student, since it supports both visual and textual prompting, we experiment with CoOp [68, VPT [29], MaPLe [30] and PromptSRC [31].

We denote the integration of our unsupervised knowledge distillation strategy with a specific prompt learning technique by adding the suffix + KDPL to the name of the corresponding technique. For example, $\mathrm{{CoOp}} + \mathrm{{KDPL}}$ refers to the application of KDPL to CoOp. For class agnostic settings we instead use the suffix +CA-KDPL to indicate that no training class names are used.

Unless otherwise stated, all experiments are conducted in the few-shot setting with 16 examples per class randomly sampled from the training set. We set the temperature hyperparameter $\tau$ in Eq. (1) to 0.01. In the class agnostic experiments in which we assume no knowledge of class names in the training set, we set the number of class names selected in each iteration to $K = {1000}$ .

For each prompt learning method we use the original implementation and hyperparameters reported in the respective papers. Since we use the compact ResNet-50 and ViT-B/32 backbones, we cannot directly compare to the originally published results. Thus, all numbers we report here were computed by us and are averages over three independent runs. See Section A. in the Supplementary Material for additional implementation details.

---

${}^{4}$ https://huggingface.co/apple/DFN5B-CLIP-ViT-H-14

---

Table 1: Domain Generalization. Comparison between the baselines and the proposed unsupervised KDPL variants (highlighted in cyan). In this setting, the prompt is trained on ImageNet (source) and then tested on four different versions of ImageNet (targets) that exhibit some kind of domain shift. Average performance improvements over the baselines are shown in green, and average performance deterioration in red.

<table><tr><td rowspan="2">Backbone</td><td rowspan="2">Method</td><td>Source</td><td colspan="5">Target</td></tr><tr><td>ImageNet</td><td>-V2</td><td>-S</td><td>-A</td><td>-R</td><td>Average</td></tr><tr><td rowspan="5">RN50</td><td>CLIP (student)</td><td>58.20</td><td>51.50</td><td>33.30</td><td>21.70</td><td>56.00</td><td>40.63</td></tr><tr><td>CoOp</td><td>62.40</td><td>55.17</td><td>33.70</td><td>23.13</td><td>56.20</td><td>42.05</td></tr><tr><td>CoOp + KDPL</td><td>62.73</td><td>55.37</td><td>35.20</td><td>23.27</td><td>57.77</td><td>42.90</td></tr><tr><td>CoCoOp</td><td>63.07</td><td>55.53</td><td>34.77</td><td>23.73</td><td>59.47</td><td>43.38</td></tr><tr><td>CoCoOp + KDPL</td><td>62.70</td><td>55.60</td><td>35.30</td><td>23.43</td><td>57.90</td><td>43.06</td></tr><tr><td rowspan="9">ViT-B/32</td><td>CLIP (student)</td><td>62.00</td><td>54.70</td><td>40.80</td><td>29.60</td><td>66.00</td><td>47.78</td></tr><tr><td>CoOp</td><td>66.33</td><td>58.30</td><td>41.40</td><td>31.47</td><td>65.87</td><td>49.26</td></tr><tr><td>$\mathrm{{CoOp}} + \mathrm{{KDPL}}$</td><td>65.97</td><td>58.10</td><td>42.50</td><td>31.63</td><td>67.37</td><td>49.90</td></tr><tr><td>VPT</td><td>64.97</td><td>56.73</td><td>41.27</td><td>27.00</td><td>66.50</td><td>47.88</td></tr><tr><td>VPT + KDPL</td><td>65.10</td><td>57.37</td><td>41.67</td><td>27.77</td><td>67.47</td><td>48.57</td></tr><tr><td>MaPLe</td><td>66.80</td><td>58.53</td><td>42.23</td><td>30.13</td><td>66.40</td><td>49.32</td></tr><tr><td>MaPLe + KDPL</td><td>66.50</td><td>58.47</td><td>42.77</td><td>29.87</td><td>67.70</td><td>49.70</td></tr><tr><td>PromptSRC</td><td>66.33</td><td>58.70</td><td>42.97</td><td>32.07</td><td>68.93</td><td>50.67</td></tr><tr><td>PromptSRC + KDPL</td><td>66.27</td><td>58.60</td><td>43.07</td><td>31.70</td><td>68.83</td><td>50.55</td></tr><tr><td colspan="2">ViT-H/14CLIP (teacher)</td><td>82.80</td><td>76.60</td><td>71.10</td><td>71.10</td><td>91.30</td><td>77.53</td></tr></table>

### 4.2 Results on Domain Generalization

Table 1 outlines the performance in the domain generalization setting. We report the performance of each baseline method alongside their unsupervised KDPL variants. Additionally, the performance of the zero-shot CLIP student and teacher models using a handcrafted prompt is included for comparison. We observe that applying our unsupervised approach to each baseline does not result in a significant decrease in performance on the source dataset. Notably, when transferring the learned prompts to a different domain, incorporating KDPL in each baseline can lead to a slight improvement. This suggests that our unsupervised teacher-student distillation learns prompts that generalize better than those trained using ground-truth labels. The only exceptions where we observe an average decrease compared to the baseline are when using $\mathrm{{CoCoOp}}$ or Prompt-SRC. CoCoOp-KDPL achieves an average accuracy significantly lower than Co- $\mathrm{{CoOp}}$ only on the ImageNet-R dataset. Finally, note that all our unsupervised KDPL variants significantly improve the performance over the zero-shot CLIP student model in both the source and the target datasets.

Table 2: Cross-dataset Transfer. Comparison between the baselines and the proposed unsupervised KDPL variants (highlighted in cyan). The prompt is learned on ImageNet and then tested on the ten different target datasets. Average performance improvements over the baselines are indicated in green.

<table><tr><td/><td rowspan="2">Method</td><td colspan="11">Target</td></tr><tr><td>Backbone</td><td>OxfordPets</td><td/><td>FGVCAircraft</td><td/><td>EuroSAT</td><td>StanfordCars</td><td>Food101</td><td>SUN397</td><td>Caltech101</td><td>UCF101</td><td>Average</td></tr><tr><td rowspan="5">RN50</td><td>CLIP (student)</td><td>83.70</td><td>61.00</td><td>15.60</td><td>40.00</td><td>24.20</td><td>55.60</td><td>75.20</td><td>58.50</td><td>86.00</td><td>58.30</td><td>55.81</td></tr><tr><td>CoOp</td><td>84.60</td><td>61.63</td><td>13.77</td><td>36.83</td><td>22.33</td><td>54.20</td><td>75.03</td><td>59.00</td><td>87.67</td><td>57.73</td><td>55.28</td></tr><tr><td>$\mathrm{{CoOp}} + \mathrm{{KDPL}}$</td><td>87.33</td><td>62.83</td><td>14.97</td><td>39.27</td><td>30.17</td><td>56.60</td><td>77.27</td><td>60.30</td><td>88.57</td><td>58.63</td><td>57.59</td></tr><tr><td>CoCoOp</td><td>86.93</td><td>63.47</td><td>16.27</td><td>40.53</td><td>27.20</td><td>55.47</td><td>77.73</td><td>61.40</td><td>88.07</td><td>60.43</td><td>57.75</td></tr><tr><td>$\mathrm{{CoCoOp}} + \mathrm{{KDPL}}$</td><td>87.33</td><td>64.97</td><td>15.97</td><td>41.27</td><td>29.17</td><td>56.83</td><td>78.00</td><td>61.50</td><td>88.50</td><td>59.53</td><td>58.31</td></tr><tr><td rowspan="9">ViT-B/32</td><td>CLIP (student)</td><td>85.00</td><td>64.30</td><td>18.20</td><td>42.80</td><td>38.10</td><td>60.40</td><td>79.10</td><td>62.00</td><td>91.10</td><td>60.70</td><td>60.17</td></tr><tr><td>CoOp</td><td>87.13</td><td>62.20</td><td>12.13</td><td>40.57</td><td>36.97</td><td>57.83</td><td>80.13</td><td>62.83</td><td>91.13</td><td>61.80</td><td>59.27</td></tr><tr><td>$\mathrm{{CoOp}} + \mathrm{{KDPL}}$</td><td>87.13</td><td>62.23</td><td>15.57</td><td>40.40</td><td>40.93</td><td>58.83</td><td>80.57</td><td>64.23</td><td>92.77</td><td>61.63</td><td>60.43</td></tr><tr><td>VPT</td><td>87.43</td><td>64.77</td><td>19.53</td><td>44.20</td><td>28.47</td><td>57.60</td><td>78.27</td><td>63.73</td><td>91.40</td><td>62.50</td><td>59.79</td></tr><tr><td>VPT + KDPL</td><td>87.43</td><td>64.43</td><td>17.77</td><td>42.93</td><td>30.80</td><td>57.97</td><td>78.47</td><td>63.63</td><td>92.00</td><td>62.77</td><td>59.82</td></tr><tr><td>MaPLe</td><td>88.37</td><td>66.43</td><td>18.47</td><td>42.03</td><td>37.77</td><td>60.00</td><td>80.10</td><td>64.43</td><td>91.33</td><td>62.50</td><td>61.14</td></tr><tr><td>MaPLe + KDPL</td><td>88.27</td><td>64.77</td><td>17.33</td><td>43.13</td><td>37.13</td><td>59.93</td><td>80.47</td><td>65.43</td><td>93.43</td><td>62.70</td><td>61.26</td></tr><tr><td>PromptSRC</td><td>88.13</td><td>65.33</td><td>17.17</td><td>43.90</td><td>40.50</td><td>60.17</td><td>81.23</td><td>65.40</td><td>92.37</td><td>63.63</td><td>61.78</td></tr><tr><td>PromptSRC + KDPL</td><td>88.17</td><td>65.10</td><td>18.23</td><td>43.27</td><td>44.30</td><td>60.43</td><td>80.90</td><td>65.67</td><td>93.63</td><td>63.40</td><td>62.31</td></tr><tr><td>ViT-H/14</td><td>CLIP (teacher)</td><td>94.80</td><td>89.40</td><td>63.20</td><td>66.80</td><td>63.30</td><td>95.60</td><td>93.60</td><td>76.40</td><td>97.90</td><td>76.40</td><td>81.74</td></tr></table>

### 4.3 Results on Cross-dataset Transfer

In Table 2 we present the results of the cross-dataset evaluation setting in which the prompt is trained on ImageNet and tested on ten different target datasets. For all datasets our KDPL-based variants consistently outperform the corresponding baselines and demonstrate superior generalization performance. The greater generalization capabilities of KDPL are evident even for fine-grained datasets like EuroSAT, on which the CoOp+KDPL achieves an 8% improvement over the baseline CoOp when using ResNet-50 as the backbone. Although adding KDPL yields only minor improvement to the VPT and MaPLe prompt learning techniques, we emphasize that our VPT+KDPL and MaPLe+KDPL do not have access to ground-truth labels. Notably, PromptSRC+KDPL achieves the highest average performance.

### 4.4 Results on Generalization to Unseen Classes

In Table 3 we give results for the unseen class generalization task. In these experiments each dataset is split into ${50}\%$ of the classes as a base for training few-shot adaptation, and the remaining ${50}\%$ as new classes on which zero-shot performance is evaluated. KDPL consistently outperforms the corresponding baseline methods for both backbones, demonstrating improvement in all scenarios for the majority of the datasets. On average, the performance improvement over the supervised baseline methods ranges from about 1% for VPT to about 3% for CoOp with the ResNet-50 backbone. See Section C.1. in the Supplementary Material for further analysis of base and unseen performance.

Table 3: Generalization to Unseen Classes. Comparison between the baselines and the proposed unsupervised KDPL variants (highlighted in cyan). In this setting the prompt is tested on classes never observed during training. Average performance improvements over the baselines are indicated in green.

<table><tr><td/><td/><td colspan="12">Unseen Classes</td></tr><tr><td>Backbone</td><td>Method</td><td>ageNet</td><td>OxfordPets</td><td>Flowers102</td><td>FGVCAircraft</td><td>DTD</td><td>${E}_{\text{uroSAT }}$</td><td>StanfordCars</td><td>Food101</td><td>SUN397</td><td>Caltech101</td><td>UCF101</td><td>Average</td></tr><tr><td rowspan="5">RN50</td><td>CLIP (student)</td><td>60.10</td><td>$\underline{93.70}$</td><td>71.30</td><td>24.80</td><td>53.90</td><td>43.70</td><td>66.60</td><td>82.20</td><td>70.10</td><td>90.50</td><td>67.80</td><td>65.88</td></tr><tr><td>CoOp</td><td>60.00</td><td>91.63</td><td>58.30</td><td>22.17</td><td>40.93</td><td>42.13</td><td>59.87</td><td>82.03</td><td>66.77</td><td>87.53</td><td>57.63</td><td>60.82</td></tr><tr><td>$\mathrm{{CoOp}} + \mathrm{{KDPL}}$</td><td>60.53</td><td>94.97</td><td>63.40</td><td>21.27</td><td>38.70</td><td>62.07</td><td>56.63</td><td>83.07</td><td>69.83</td><td>88.75</td><td>62.63</td><td>63.80</td></tr><tr><td>CoCoOp</td><td>63.07</td><td>94.93</td><td>67.47</td><td>24.87</td><td>45.40</td><td>35.10</td><td>64.73</td><td>84.50</td><td>72.87</td><td>90.73</td><td>64.67</td><td>64.39</td></tr><tr><td>$\mathrm{{CoCoOp}} + \mathrm{{KDPL}}$</td><td>62.43</td><td>95.10</td><td>69.17</td><td>24.57</td><td>48.00</td><td>55.93</td><td>63.70</td><td>85.67</td><td>73.33</td><td>90.53</td><td>66.40</td><td>66.80</td></tr><tr><td rowspan="9">ViT-B/32</td><td>CLIP (student)</td><td>64.00</td><td>96.30</td><td>72.30</td><td>28.30</td><td>53.90</td><td>61.50</td><td>69.80</td><td>85.70</td><td>73.10</td><td>94.00</td><td>71.60</td><td>70.05</td></tr><tr><td>CoOp</td><td>64.53</td><td>93.37</td><td>59.77</td><td>23.03</td><td>45.57</td><td>49.13</td><td>61.73</td><td>85.50</td><td>69.37</td><td>92.13</td><td>65.60</td><td>64.52</td></tr><tr><td>$\mathrm{{CoOp}} + \mathrm{{KDPL}}$</td><td>64.90</td><td>94.00</td><td>56.17</td><td>22.00</td><td>47.33</td><td>62.07</td><td>62.37</td><td>87.23</td><td>74.17</td><td>93.43</td><td>66.20</td><td>66.35</td></tr><tr><td>VPT</td><td>64.60</td><td>94.83</td><td>66.03</td><td>29.70</td><td>50.17</td><td>50.03</td><td>69.90</td><td>85.83</td><td>75.13</td><td>92.57</td><td>69.47</td><td>68.02</td></tr><tr><td>VPT + KDPL</td><td>65.20</td><td>95.20</td><td>67.87</td><td>30.40</td><td>47.53</td><td>54.97</td><td>69.80</td><td>86.33</td><td>75.17</td><td>92.80</td><td>71.07</td><td>68.76</td></tr><tr><td>MaPLe</td><td>66.70</td><td>96.87</td><td>69.77</td><td>20.43</td><td>53.50</td><td>66.70</td><td>68.03</td><td>87.47</td><td>76.57</td><td>92.27</td><td>69.40</td><td>69.79</td></tr><tr><td>MaPLe + KDPL</td><td>66.73</td><td>96.87</td><td>68.23</td><td>27.37</td><td>50.33</td><td>75.70</td><td>68.40</td><td>87.83</td><td>76.83</td><td>93.67</td><td>73.53</td><td>71.41</td></tr><tr><td>PromptSRC</td><td>65.93</td><td>96.30</td><td>71.37</td><td>23.67</td><td>54.43</td><td>61.97</td><td>70.00</td><td>87.13</td><td>76.77</td><td>94.70</td><td>72.63</td><td>70.45</td></tr><tr><td>PromptSRC + KDPL</td><td>66.33</td><td>96.47</td><td>68.83</td><td>28.43</td><td>50.87</td><td>74.17</td><td>68.50</td><td>87.63</td><td>77.33</td><td>94.47</td><td>74.73</td><td>71.61</td></tr><tr><td>ViT-H/14</td><td>CLIP (teacher)</td><td>84.10</td><td>99.20</td><td>85.60</td><td>64.30</td><td>75.00</td><td>82.60</td><td>98.20</td><td>96.30</td><td>85.10</td><td>97.30</td><td>85.20</td><td>86.63</td></tr></table>

### 4.5 Results on Class Agnostic Adaptation

Figure 3(a-b) summarizes the main results in the proposed Class Agnostic (CA) scenario in which even the training class names are unknown at training time. We report the accuracy on the ImageNet dataset (source), as well as the average accuracy in domain generalization and cross-dataset settings. Note that, even without knowing the class names, the performance on the source dataset steadily improves compared to the zero-shot CLIP model. Moreover, the prompts learned via the proposed unsupervised class agnostic knowledge distillation also exhibit improved average domain generalization $\left( {\mathrm{{AVG}}}^{1}\right)$ and cross-dataset capabilities $\left( {\mathrm{{AVG}}}^{2}\right)$ . Figure 3(b) visually depicts how the ResNet-50-based CoOp+CA-KDPL compares with supervised CoOp and zero-shot CLIP student performance in the cross-dataset transfer setting. Notably, CA-KDPL outperforms both baselines despite being unsupervised and class agnostic during training.

![bo_d1c3l9bef24c73d2ojn0_13_905_327_476_394_0.jpg](images/bo_d1c3l9bef24c73d2ojn0_13_905_327_476_394_0.jpg)

<table><tr><td>Method</td><td>Source</td><td>AVG1</td><td>${\mathrm{{AVG}}}^{2}$</td></tr><tr><td>ResNet-50 (student)</td><td>58.20</td><td>40.63</td><td>55.81</td></tr><tr><td>CoOp + CA-KDPL</td><td>61.83</td><td>43.02</td><td>57.69</td></tr><tr><td>CoCoOp + CA-KDPL</td><td>61.43</td><td>43.18</td><td>58.03</td></tr><tr><td>ViT-B/32 (student)</td><td>62.00</td><td>47.78</td><td>60.17</td></tr><tr><td>CoOp + CA-KDPL</td><td>64.73</td><td>49.63</td><td>60.74</td></tr><tr><td>VPT + CA-KDPL</td><td>63.73</td><td>47.89</td><td>59.80</td></tr><tr><td>MaPLe + CA-KDPL</td><td>65.23</td><td>49.28</td><td>61.23</td></tr><tr><td>PromptSRC + CA-KDPL</td><td>65.00</td><td>50.37</td><td>61.93</td></tr></table>

(a) Average class agnostic adaptation (b) Per-dataset class agnostic adaptation

Fig. 3: Class agnostic adaptation. (a) Comparison between the zero-shot baselines and our class agnostic CA-KDPL variants (highlighted in cyan). The prompt is learned in an unsupervised and class agnostic setting on ImageNet and evaluated on the benchmark datasets for domain generalization $\left( {\mathrm{{AVG}}}^{1}\right)$ and cross-dataset $\left( {\mathrm{{AVG}}}^{2}\right)$ evaluations. Average performance improvements are indicated in green, and deterioration in red. (b) Per-dataset accuracy comparison between our unsupervised and class agnostic method (CoOp+CA-KDPL), the supervised baseline CoOp, and the zero-shot student on the cross-dataset benchmark datasets.

## 5 Conclusion

In this paper we proposed an approach to Knowledge Distillation Prompt Learning (KDPL) which is easily integrated into existing supervised prompt learning methods. Our experiments show that for CoOp, CoCoOp, VPT, MaPLe and PromptSRC adding KDPL: (1) renders them label agnostic by eliminating the need for ground-truth labels for few-shot adaptation; (2) can also render them class agnostic in cases where no knowledge of training class labels is available; and (3) remarkably improves generalization to downstream tasks.

The additional computation cost incurred by distilling from a large VLM is a limitation of KDPL, though all encoder parameters are fixed and the predictions of the teacher can be precomputed, which helps mitigate the extra cost. This extra computation only amounts to about a ${15}\%$ increase for MaPLe.

Note that we did not tune any hyperparameters when training the KDPL variants. We use the same settings as in the original papers, which are likely suboptimal for distillation-based adaptation. With careful tuning, there is potential for improvement. Our experiments indicate that distillation-learned prompts are more transferable, and we think it would be interesting to see if this idea can generalize to very different downstream tasks and scale to even bigger teacher models or - more interestingly - to even smaller student models.

## Acknowledgements

This work was supported by funding from the European Commission Horizon 2020 grant #951911 (AI4Media).

## References

1. Abdul Samadh, J., Gani, M.H., Hussein, N., Khattak, M.U., Naseer, M.M., Shah-baz Khan, F., Khan, S.H.: Align your prompts: Test-time prompting with distribution alignment for zero-shot generalization. Advances in Neural Information Processing Systems 36 (2024)

2. Agnolucci, L., Baldrati, A., Todino, F., Becattini, F., Bertini, M., Del Bimbo, A.: Eco: Ensembling context optimization for vision-language models. In: Proceedings of the IEEE/CVF International Conference on Computer Vision. pp. 2811-2815 (2023)

3. Baldrati, A., Agnolucci, L., Bertini, M., Del Bimbo, A.: Zero-shot composed image retrieval with textual inversion. In: Proceedings of the IEEE/CVF International Conference on Computer Vision (ICCV). pp. 15338-15347 (October 2023)

4. Barraco, M., Cornia, M., Cascianelli, S., Baraldi, L., Cucchiara, R.: The unreasonable effectiveness of clip features for image captioning: an experimental analysis. In: proceedings of the IEEE/CVF conference on computer vision and pattern recognition. pp. 4662-4670 (2022)

5. Beyer, L., Zhai, X., Royer, A., Markeeva, L., Anil, R., Kolesnikov, A.: Knowledge distillation: A good teacher is patient and consistent. In: Proceedings of the IEEE/CVF conference on computer vision and pattern recognition. pp. 10925- 10934 (2022)

6. Bossard, L., Guillaumin, M., Van Gool, L.: Food-101-mining discriminative components with random forests. In: Computer Vision-ECCV 2014: 13th European Conference, Zurich, Switzerland, September 6-12, 2014, Proceedings, Part VI 13. pp. 446-461. Springer (2014)

7. Bulat, A., Tzimiropoulos, G.: Lasp: Text-to-text optimization for language-aware soft prompting of vision & language models. In: Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition. pp. 23232-23241 (2023)

8. Chen, G., Yao, W., Song, X., Li, X., Rao, Y., Zhang, K.: Plot: Prompt learning with optimal transport for vision-language models. In: The Eleventh International Conference on Learning Representations (2022)

9. Chen, W.C., Chang, C.C., Lee, C.R.: Knowledge distillation with feature maps for image classification. In: Computer Vision-ACCV 2018: 14th Asian Conference on Computer Vision, Perth, Australia, December 2-6, 2018, Revised Selected Papers, Part III 14. pp. 200-215. Springer (2019)

10. Cherti, M., Beaumont, R., Wightman, R., Wortsman, M., Ilharco, G., Gordon, C., Schuhmann, C., Schmidt, L., Jitsev, J.: Reproducible scaling laws for contrastive language-image learning. In: Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition. pp. 2818-2829 (2023)

11. Cimpoi, M., Maji, S., Kokkinos, I., Mohamed, S., Vedaldi, A.: Describing textures in the wild. In: Proceedings of the IEEE conference on computer vision and pattern recognition. pp. 3606-3613 (2014)

12. Deng, J., Dong, W., Socher, R., Li, L.J., Li, K., Fei-Fei, L.: Imagenet: A large-scale hierarchical image database. In: 2009 IEEE conference on computer vision and pattern recognition. pp. 248-255. Ieee (2009)

13. Desai, K., Johnson, J.: Virtex: Learning visual representations from textual annotations. In: Proceedings of the IEEE/CVF conference on computer vision and pattern recognition. pp. 11162-11173 (2021)

14. Ding, Y., Liu, L., Tian, C., Yang, J., Ding, H.: Don't stop learning: Towards continual learning for the clip model. arXiv preprint arXiv:2207.09248 (2022)

15. Dong, X., Bao, J., Zhang, T., Chen, D., Gu, S., Zhang, W., Yuan, L., Chen, D., Wen, F., Yu, N.: Clip itself is a strong fine-tuner: Achieving 85.7% and 88.0% top-1 accuracy with vit-b and vit-l on imagenet. arXiv preprint arXiv:2212.06138 (2022)

16. Dosovitskiy, A., Beyer, L., Kolesnikov, A., Weissenborn, D., Zhai, X., Unterthiner, T., Dehghani, M., Minderer, M., Heigold, G., Gelly, S., et al.: An image is worth 16x16 words: Transformers for image recognition at scale. In: International Conference on Learning Representations (2020)

17. Dou, Q., Liu, Q., Heng, P.A., Glocker, B.: Unpaired multi-modal segmentation via knowledge distillation. IEEE transactions on medical imaging $\mathbf{{39}}\left( 7\right) ,{2415} - {2425}$ (2020)

18. Fang, A., Jose, A.M., Jain, A., Schmidt, L., Toshev, A.T., Shankar, V.: Data filtering networks. In: The Twelfth International Conference on Learning Representations (2023)

19. Fang, Z., Wang, J., Wang, L., Zhang, L., Yang, Y., Liu, Z.: Seed: Self-supervised distillation for visual representation. In: International Conference on Learning Representations (2020)

20. Fei-Fei, L., Fergus, R., Perona, P.: Learning generative visual models from few training examples: An incremental bayesian approach tested on 101 object categories. In: 2004 conference on computer vision and pattern recognition workshop. pp. 178-178. IEEE (2004)

21. Gu, X., Lin, T.Y., Kuo, W., Cui, Y.: Open-vocabulary object detection via vision and language knowledge distillation. In: International Conference on Learning Representations (2021)

22. He, T., Shen, C., Tian, Z., Gong, D., Sun, C., Yan, Y.: Knowledge adaptation for efficient semantic segmentation. In: Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition. pp. 578-587 (2019)

23. Helber, P., Bischke, B., Dengel, A., Borth, D.: Eurosat: A novel dataset and deep learning benchmark for land use and land cover classification. IEEE Journal of Selected Topics in Applied Earth Observations and Remote Sensing $\mathbf{{12}}\left( 7\right) ,{2217} -$ 2226 (2019)

24. Hendrycks, D., Basart, S., Mu, N., Kadavath, S., Wang, F., Dorundo, E., Desai, R., Zhu, T., Parajuli, S., Guo, M., et al.: The many faces of robustness: A critical analysis of out-of-distribution generalization. In: Proceedings of the IEEE/CVF International Conference on Computer Vision. pp. 8340-8349 (2021)

25. Hendrycks, D., Zhao, K., Basart, S., Steinhardt, J., Song, D.: Natural adversarial examples. In: Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition. pp. 15262-15271 (2021)

26. Hinton, G., Vinyals, O., Dean, J.: Distilling the knowledge in a neural network. stat 1050, 9 (2015)

27. Huang, T., Chu, J., Wei, F.: Unsupervised prompt learning for vision-language models. arXiv preprint arXiv:2204.03649 (2022)

28. Jia, C., Yang, Y., Xia, Y., Chen, Y.T., Parekh, Z., Pham, H., Le, Q., Sung, Y.H., Li, Z., Duerig, T.: Scaling up visual and vision-language representation learning with noisy text supervision. In: International conference on machine learning. pp. 4904-4916. PMLR (2021)

29. Jia, M., Tang, L., Chen, B.C., Cardie, C., Belongie, S., Hariharan, B., Lim, S.N.: Visual prompt tuning. In: European Conference on Computer Vision (2022)

30. Khattak, M.U., Rasheed, H., Maaz, M., Khan, S., Khan, F.S.: Maple: Multi-modal prompt learning. In: Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition. pp. 19113-19122 (2023)

31. Khattak, M.U., Wasim, S.T., Naseer, M., Khan, S., Yang, M.H., Khan, F.S.: Self-regulating prompts: Foundational model adaptation without forgetting. In: Proceedings of the IEEE/CVF International Conference on Computer Vision. pp. 15190-15200 (2023)

32. Krause, J., Stark, M., Deng, J., Fei-Fei, L.: 3d object representations for fine-grained categorization. In: Proceedings of the IEEE international conference on computer vision workshops. pp. 554-561 (2013)

33. Kuznetsova, A., Rom, H., Alldrin, N., Uijlings, J., Krasin, I., Pont-Tuset, J., Ka-mali, S., Popov, S., Malloci, M., Kolesnikov, A., et al.: The open images dataset v4: Unified image classification, object detection, and visual relationship detection at scale. International Journal of Computer Vision (IJCV) 128(7), 1956-1981 (2020)

34. Lester, B., Al-Rfou, R., Constant, N.: The power of scale for parameter-efficient prompt tuning. In: Proceedings of the 2021 Conference on Empirical Methods in Natural Language Processing. pp. 3045-3059 (2021)

35. Li, X.L., Liang, P.: Prefix-tuning: Optimizing continuous prompts for generation. In: Proceedings of the 59th Annual Meeting of the Association for Computational Linguistics and the 11th International Joint Conference on Natural Language Processing (Volume 1: Long Papers). pp. 4582-4597 (2021)

36. Li, Z., Li, X., Fu, X., Zhang, X., Wang, W., Chen, S., Yang, J.: Promptkd: Unsupervised prompt distillation for vision-language models. In: Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition. pp. 26617- 26626 (2024)

37. Lu, Y., Liu, J., Zhang, Y., Liu, Y., Tian, X.: Prompt distribution learning. In: Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition. pp. 5206-5215 (2022)

38. Lüddecke, T., Ecker, A.: Image segmentation using text and image prompts. In: Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition. pp. 7086-7096 (2022)

39. Maji, S., Rahtu, E., Kannala, J., Blaschko, M., Vedaldi, A.: Fine-grained visual classification of aircraft. arXiv preprint arXiv:1306.5151 (2013)

40. Mullapudi, R.T., Chen, S., Zhang, K., Ramanan, D., Fatahalian, K.: Online model distillation for efficient video inference. In: Proceedings of the IEEE/CVF International conference on computer vision. pp. 3573-3582 (2019)

41. Nilsback, M.E., Zisserman, A.: Automated flower classification over a large number of classes. In: 2008 Sixth Indian conference on computer vision, graphics & image processing. pp. 722-729. IEEE (2008)

42. Parelli, M., Delitzas, A., Hars, N., Vlassis, G., Anagnostidis, S., Bachmann, G., Hofmann, T.: Clip-guided vision-language pre-training for question answering in 3d scenes. In: Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition. pp. 5606-5611 (2023)

43. Parkhi, O.M., Vedaldi, A., Zisserman, A., Jawahar, C.: Cats and dogs. In: 2012 IEEE conference on computer vision and pattern recognition. pp. 3498-3505. IEEE (2012)

44. Radford, A., Kim, J.W., Hallacy, C., Ramesh, A., Goh, G., Agarwal, S., Sastry, G., Askell, A., Mishkin, P., Clark, J., et al.: Learning transferable visual models from natural language supervision. In: International conference on machine learning. pp. 8748-8763. PMLR (2021)

45. Recht, B., Roelofs, R., Schmidt, L., Shankar, V.: Do imagenet classifiers generalize to imagenet? In: International conference on machine learning. pp. 5389-5400. PMLR (2019)

46. Ren, S., Zhang, A., Zhu, Y., Zhang, S., Zheng, S., Li, M., Smola, A.J., Sun, X.: Prompt pre-training with twenty-thousand classes for open-vocabulary visual recognition. Advances in Neural Information Processing Systems 36 (2024)

47. Schuhmann, C., Beaumont, R., Vencu, R., Gordon, C., Wightman, R., Cherti, M., Coombes, T., Katta, A., Mullis, C., Wortsman, M., et al.: Laion-5b: An open large-scale dataset for training next generation image-text models. Advances in Neural Information Processing Systems 35, 25278-25294 (2022)

48. Schuhmann, C., Vencu, R., Beaumont, R., Kaczmarczyk, R., Mullis, C., Katta, A., Coombes, T., Jitsev, J., Komatsuzaki, A.: Laion-400m: Open dataset of clip-filtered 400 million image-text pairs. arXiv preprint arXiv:2111.02114 (2021)

49. Shi, C., Yang, S.: Logoprompt: Synthetic text images can be good visual prompts for vision-language models. In: Proceedings of the IEEE/CVF International Conference on Computer Vision. pp. 2932-2941 (2023)

50. Shi, Z., Lipani, A.: DePT: Decomposed prompt tuning for parameter-efficient fine-tuning. In: The Twelfth International Conference on Learning Representations (2024), https://openreview.net/forum?id=KjegfPGRde

51. Siam, M., Jiang, C., Lu, S., Petrich, L., Gamal, M., Elhoseiny, M., Jagersand, M.: Video object segmentation using teacher-student adaptation in a human robot interaction (hri) setting. In: 2019 International Conference on Robotics and Automation (ICRA). pp. 50-56. IEEE (2019)

52. Song, H., Dong, L., Zhang, W., Liu, T., Wei, F.: Clip models are few-shot learners: Empirical studies on vqa and visual entailment. In: Proceedings of the 60th Annual Meeting of the Association for Computational Linguistics (Volume 1: Long Papers). pp. 6088-6100 (2022)

53. Soomro, K., Zamir, A.R., Shah, M.: Ucf101: A dataset of 101 human actions classes from videos in the wild. arXiv preprint arXiv:1212.0402 (2012)

54. Wang, H., Ge, S., Lipton, Z., Xing, E.P.: Learning robust global representations by penalizing local predictive power. Advances in Neural Information Processing Systems 32 (2019)

55. Wang, Z., Liang, J., He, R., Xu, N., Wang, Z., Tan, T.: Improving zero-shot generalization for clip with synthesized prompts. In: Proceedings of the IEEE/CVF International Conference on Computer Vision. pp. 3032-3042 (2023)

56. Xiao, J., Hays, J., Ehinger, K.A., Oliva, A., Torralba, A.: Sun database: Large-scale scene recognition from abbey to zoo. In: 2010 IEEE computer society conference on computer vision and pattern recognition. pp. 3485-3492. IEEE (2010)

57. Xu, G., Liu, Z., Li, X., Loy, C.C.: Knowledge distillation meets self-supervision. In: European Conference on Computer Vision. pp. 588-604. Springer (2020)

58. Yao, H., Zhang, R., Xu, C.: Visual-language prompt tuning with knowledge-guided context optimization. In: Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition. pp. 6757-6767 (2023)

59. Yuan, L., Tay, F.E., Li, G., Wang, T., Feng, J.: Revisiting knowledge distillation via label smoothing regularization. In: Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition. pp. 3903-3911 (2020)

60. Yun, S., Park, J., Lee, K., Shin, J.: Regularizing class-wise predictions via self-knowledge distillation. In: Proceedings of the IEEE/CVF conference on computer vision and pattern recognition. pp. 13876-13885 (2020)

61. Zhai, X., Wang, X., Mustafa, B., Steiner, A., Keysers, D., Kolesnikov, A., Beyer, L.: Lit: Zero-shot transfer with locked-image text tuning. In: Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition. pp. 18123- 18133 (2022)

62. Zhang, R., Fang, R., Zhang, W., Gao, P., Li, K., Dai, J., Qiao, Y., Li, H.: Tip-adapter: Training-free clip-adapter for better vision-language modeling. arXiv preprint arXiv:2111.03930 (2021)

63. Zhang, Y., Xiang, T., Hospedales, T.M., Lu, H.: Deep mutual learning. In: Proceedings of the IEEE conference on computer vision and pattern recognition. pp. 4320-4328 (2018)

64. Zhao, B., Cui, Q., Song, R., Qiu, Y., Liang, J.: Decoupled knowledge distillation. In: Proceedings of the IEEE/CVF Conference on computer vision and pattern recognition. pp. 11953-11962 (2022)

65. Zhong, Z., Friedman, D., Chen, D.: Factual probing is [mask]: Learning vs. learning to recall. In: Proceedings of the 2021 Conference of the North American Chapter of the Association for Computational Linguistics: Human Language Technologies. pp. 5017-5033 (2021)

66. Zhou, C., Loy, C.C., Dai, B.: Extract free dense labels from clip. In: European Conference on Computer Vision. pp. 696-712. Springer (2022)

67. Zhou, K., Yang, J., Loy, C.C., Liu, Z.: Conditional prompt learning for vision-language models. In: Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition. pp. 16816-16825 (2022)

68. Zhou, K., Yang, J., Loy, C.C., Liu, Z.: Learning to prompt for vision-language models. International Journal of Computer Vision 130(9), 2337-2348 (2022)

69. Zhu, B., Niu, Y., Han, Y., Wu, Y., Zhang, H.: Prompt-aligned gradient for prompt tuning. In: 2023 IEEE/CVF International Conference on Computer Vision (ICCV). pp. 15613-15623. IEEE Computer Society (2023)

# Supplementary Material for: Improving Zero-shot Generalization of Learned Prompts via Unsupervised Knowledge Distillation

*Marco Mistretta ${}^{1}$ , *Alberto Baldrati ${}^{1,2}$ , Marco Bertini ${}^{1}$ , and Andrew D. Bagdanov ${}^{1}$

${}^{1}$ University of Florence - Media Integration and Communication Center (MICC) ${}^{2}$ University of Pisa

Florence, Italy - Pisa, Italy

\{name.surname\}@unifi.it

## Overview

This document contains Supplementary Material that provides additional details and further experimental analysis. The contents are organized as follows:

- A. Additional Implementation Details: This section provides additional implementation details, including hyperparameters and configuration settings for reproducing all reported results and further details about the datasets used.

- B. Ablation Study

- B.1. Pseudolabelling versus KDPL: This subsection compares KDPL performances with a famous pseudolabeling prompt learning strategy demonstrating the superiority of KDPL over the baseline approach.

- B.2. Sampling Strategies for Class Agnostic Adaptation: This part evaluates different sampling strategies for class agnostic adaptation and their performance varying the number of sampled class names.

- B.3. Symmetric versus Asymmetric KL: This section explores the impact of using symmetric versus asymmetric KL-divergence in the loss function explaining why is more effective for class agnostic scenarios.

- B.4. Is a smaller Teacher enough? Here, we investigate whether smaller teachers model can achieve competitive performance compared to the larger ViT-H-14 teacher model used in the main paper.

- C. Additional Results

- C.1. Generalization to Unseen Classes: Here we present additional experimental results for the generalization to unseen classes within the same dataset scenario, including the downstream performance of few-shot base as well as the harmonic mean of base and unseen classes.

- C.2. Class Agnostic Scenario: This section provides additional results for the class agnostic setting, our proposed new setting in which we know neither the labels nor the names of the training classes.

---

* These authors contributed equally to this work.

---

Table 4: Configuration of hyperparame-ters for the re-computed baselines. Note that $\mathrm{{CoOp}}$ and $\mathrm{{CoCoOp}}$ , being textual prompt learning methods, do not learn visual tokens.

<table><tr><td>Dataset</td><td>CoOp</td><td>CoCoOp</td><td>VPT</td><td>MaPLe</td><td>PromptSRC</td></tr><tr><td>Batch Size</td><td>32</td><td>1</td><td>4</td><td>4</td><td>4</td></tr><tr><td>Optimizer</td><td>SGD</td><td>SGD</td><td>SGD</td><td>SGD</td><td>SGD</td></tr><tr><td>LR</td><td>0.02</td><td>0.02</td><td>0.0025</td><td>0.0035</td><td>0.0025</td></tr><tr><td>Epochs</td><td>50</td><td>10</td><td>5</td><td>5</td><td>20</td></tr><tr><td>Text-tokens</td><td>4</td><td>4</td><td>4</td><td>4</td><td>4</td></tr><tr><td>Visual-tokens</td><td>-</td><td>-</td><td>8</td><td>2</td><td>4</td></tr><tr><td>Vision-depth</td><td>-</td><td>-</td><td>12</td><td>9</td><td>9</td></tr></table>

Table 5: Datasets statistics.

<table><tr><td>Dataset</td><td>Classes</td><td>Train</td><td>Val</td><td>Test</td></tr><tr><td>ImageNet</td><td>1,000</td><td>1.28M</td><td>N/A</td><td>50,000</td></tr><tr><td>Caltech101</td><td>100</td><td>4,128</td><td>1,649</td><td>2,465</td></tr><tr><td>OxfordPets 43</td><td>37</td><td>2,944</td><td>736</td><td>3,669</td></tr><tr><td>StanfordCars 32]</td><td>196</td><td>6,509</td><td>1,635</td><td>8,041</td></tr><tr><td>Flowers102</td><td>102</td><td>4,093</td><td>1,633</td><td>2,463</td></tr><tr><td>Food101 [6]</td><td>101</td><td>50,500</td><td>20,300</td><td>30,300</td></tr><tr><td>FGVCAircraft39</td><td>100</td><td>3,334</td><td>3,333</td><td>3,333</td></tr><tr><td>SUN39756</td><td>397</td><td>15,880</td><td>3,970</td><td>19,850</td></tr><tr><td>DTD 11</td><td>47</td><td>2,820</td><td>1,128</td><td>1,692</td></tr><tr><td>EuroSAT23</td><td>10</td><td>13,500</td><td>5,400</td><td>8,100</td></tr><tr><td>UCF10153</td><td>101</td><td>7,639</td><td>1,898</td><td>3,783</td></tr><tr><td>ImageNetV245</td><td>1,000</td><td>N/A</td><td>N/A</td><td>10,000</td></tr><tr><td>ImageNet-S54</td><td>1,000</td><td>N/A</td><td>N/A</td><td>50,889</td></tr><tr><td>ImageNet-A25</td><td>200</td><td>N/A</td><td>N/A</td><td>7,500</td></tr><tr><td>ImageNet-R24</td><td>200</td><td>N/A</td><td>N/A</td><td>30,000</td></tr></table>

## A. Additional Implementation Details

In this section we provide further details on hyperparameters of the proposed approaches presented in the main paper and additional details on the benchmark datasets evaluated.

Hyperparameter settings. For all evaluated scenarios we recalculated all baseline results using the parameter and hyperparameter settings reported in the original publications [29-31, 67, 68].

In Table 4 we summarize all configuration settings. Notably, all the evaluated baselines use a cosine scheduler with one warm-up epoch with a constant learning rate of 1e-5, and all authors suggest initializing the textual context with "a photo of a" as a better starting point. Note that our variants augmented with Knowledge Distillation Prompt Learning (KDPL) were trained using exactly the same parameters and configuration settings as the baseline methods. Therefore, it is reasonable to expect that further hyperparameter tuning could potentially improve our performance even further.

In addition, all the baselines - and so also our augmented versions - adhere to the same preprocessing pipeline in which input images are resized to ${224} \times  {224}$ pixels using bicubic interpolation. Data augmentations including random resized crop, random flip, and normalization are used to ensure robustness.

To ensure consistency with baselines and to facilitate easy comparison and evaluation, our implementation is built upon the Dassl framework ${}^{3}$ , which serves as the foundation for all these methods. We use ResNet-50 and ViT-B/32 as the backbones for all experiments. These backbones are the original publicly available models released by OpenAI ${}^{4}$ As mentioned in the main paper, the code is publicly available at https://github.com/miccunifi/KDPL

---

3 https://github.com/KaiyangZhou/Dassl.pytorch

4 https://github.com/openai/CLIP

---

Table 6: Ablations on labeling, sampling, and KL-divergence. (a) Comparison of KDPL and a pseudolabeling strategy adapted from UPL [27]. (b) Ablation on a number of classes sampled for class agnostic adaptation. (c) Comparison of forward, reverse, and symmetric KL-divergence used in the loss (see Eq. 2 of the main paper). (b) Sampling strategy

<table><tr><td/><td>Source</td><td>AVG1</td><td>${\mathrm{{AVG}}}^{2}$</td></tr><tr><td>CLIP(student)</td><td>58.20</td><td>40.63</td><td>55.81</td></tr><tr><td>CoOp${\mathrm{{UPL}}}^{ * }$</td><td>62.37</td><td>42.72</td><td>56.24</td></tr><tr><td>CoOpKDPL</td><td>62.73</td><td>42.90</td><td>57.59</td></tr><tr><td>CoOpCA-UPL*</td><td>60.13</td><td>42.48</td><td>55.73</td></tr><tr><td>CoOpCA-KDPL</td><td>61.83</td><td>43.02</td><td>57.69</td></tr></table>

(a) KDPL vs. pseudolabeling

<table><tr><td/><td>Source</td><td>${\mathrm{{AVG}}}^{1}$</td><td>${\mathrm{{AVG}}}^{2}$</td></tr><tr><td>POMP*</td><td>60.80</td><td>42.37</td><td>57.35</td></tr><tr><td>CA-KDPL$\left( {K = {100}}\right)$</td><td>61.50</td><td>42.45</td><td>57.06</td></tr><tr><td>CA-KDPL( $K = {500}$ )</td><td>61.73</td><td>42.68</td><td>57.38</td></tr><tr><td>CA-KDPL$\left( {K = 1\mathrm{\;K}}\right)$</td><td>61.83</td><td>43.02</td><td>57.69</td></tr><tr><td>CA-KDPL( $K = 2\mathrm{K}$ )</td><td>61.60</td><td>43.07</td><td>57.51</td></tr></table>

<table><tr><td/><td/><td>${\mathrm{{AVG}}}^{1}$</td><td>${\mathrm{{AVG}}}^{1}$</td></tr><tr><td>$\mathrm{{CoOp}} + \mathrm{{KDPLF}}$</td><td>63.13</td><td>43.16</td><td>57.33</td></tr><tr><td>$\mathrm{{CoOp}} + \mathrm{{KDPLR}}$</td><td>62.47</td><td>42.44</td><td>57.24</td></tr><tr><td>$\mathrm{{CoOp}} + \mathrm{{KDPL}}$</td><td>62.73</td><td>42.90</td><td>57.59</td></tr><tr><td>CoOpCA-KDPL F</td><td>60.77</td><td>42.68</td><td>56.39</td></tr><tr><td>CoOpCA-KDPL R</td><td>61.37</td><td>42.71</td><td>57.12</td></tr><tr><td>CA-KDPL</td><td>61.83</td><td>43.02</td><td>57.69</td></tr></table>

(c) Symmetric/asymmetric KL

Dataset Details. The detailed statistics of the 11 datasets used in the Cross-dataset transfer setting, as well as the four variants of ImageNet used in the Cross-domain generalization setting, are given in Table 5 Note that according to the authors of CoOp, for Caltech101, the "BACKGROUND Google" and "Faces easy" classes are discarded, and for the video dataset UCF101 the middle frame of each video is used as input to the image encoder [68].

## B. Ablation Study

We performed a range of ablation studies to evaluate all aspects of KDPL. All ablations reported here are averages over three independent runs using $\mathrm{{CoOp}}$ as the baseline approach and ResNet-50 as the student backbone. The prompt is learned on ImageNet and evaluated on the benchmark datasets used in the domain generalization $\left( {\mathrm{{AVG}}}^{1}\right)$ and cross-dataset $\left( {\mathrm{{AVG}}}^{2}\right)$ evaluations.

### B.1. Pseudolabeling versus KDPL

We compare KDPL and CA-KDPL with a pseudolabeling strategy for exploiting unlabeled samples. Similar to the approach outlined in UPL [27], we generate teacher-derived labels for the training samples. Instead of selecting the top-K confident pseu-dolabels over the entire training set, for a fair comparison we pseudolabel the fixed, few shot samples in each run. We call this baseline UPL*. Table 6(a) shows that KDPL consistently outperforms UPL* on all the evaluated scenarios.

### B.2. Sampling Strategies for Class Agnostic Adaptation

An important detail in the class agnostic adaptation scenario is how class names are selected for computing the loss. Existing supervised approaches, such as POMP [46], to handling large numbers of classes suggest simply using the ground truth labels of batch samples and supplementing them with randomly selected ones to reach a predetermined number $K$ . We adapted this technique and compare it with ours in Table 6(b). These results show that KDPL outperforms the random selection strategy denoted as POMP*. Notably, the optimal number of classes for domain generalization and cross-dataset adaptation is 1000 , suggesting that the optimum closely aligns with the actual number of classes in the training dataset.

Table 7: Average accuracy comparison on the three evaluated scenarios between the supervised baseline CoOp and our unsupervised approach (CoOp + KDPL) using different and smaller teachers.

<table><tr><td rowspan="2">Method</td><td rowspan="2"/><td colspan="3">Target downstream Average</td></tr><tr><td>Domain Source Generalization</td><td>Cross-Dataset Transfer</td><td>Generalization to Unseen Classes</td></tr><tr><td>CoOp</td><td>62.40</td><td>42.05</td><td>55.28</td><td>60.82</td></tr><tr><td>$\mathrm{{CoOp}} + \mathrm{{KDPL}}$ (B/16)</td><td>60.73</td><td>42.27</td><td>56.52</td><td>67.57</td></tr><tr><td>CoOp + KDPL (L/14)</td><td>61.43</td><td>42.61</td><td>57.10</td><td>66.90</td></tr><tr><td>CoOp + KDPL (H/14)</td><td>62.73</td><td>42.90</td><td>57.59</td><td>63.80</td></tr></table>

### B.3. Symmetric versus Asymmetric KL

In Eq. 2 of the main paper we propose to use the symmetric KL-divergence, which is a sum of the forward (from teacher to student) and reverse (from student to teacher) KL-divergences. An asymmetric forward loss may yield benefits when the target distribution is similar to the source distribution (see Table 6(c)). Conversely, a reverse loss may prove better in the opposite scenario. If the Teacher outputs probability zero for a class on a training sample, the forward KL-divergence is zero for that sample even if the Student outputs a very high probability (see Eq. (3), main paper). Adding the reverse ${KL}$ -divergence prevents the distillation loss from going to zero in such cases (Eq. (2), main paper). Indeed, in the class agnostic scenario the optimal strategy is the symmetric KL divergence. This enables learning from both in- and out-of-domain training samples, as demonstrated by the results in Figure 3 of the main paper.

#### B.4.Is a smaller Teacher enough?

All the results presented so far involve ViT-H-14 as the teacher. To evaluate if a smaller teacher would be enough we ran additional experiments with ViT-L/14 and ViT-B/16 as Teacher and ResNet-50 as Student (see Table 7). Larger Teachers yield better results, but even more modest ones still maintain excellent performance on domain generalization and cross-dataset transfer. Interestingly, smaller Teachers work better on generalization to unseen classes, which we believe is due to the weaker supervision causing less adaptation and thus maintaining better zero-shot transfer.

## C. Additional Results

In the following sections we report on additional experiments validating our proposed approach.

### C.1. Generalization to Unseen Classes

In the main paper, due to brevity and to maintain focus on the core aspects of our method, we reported only the performance metrics on unseen classes. Here we provide the performance metrics on base classes as well as the harmonic mean of both base and unseen classes to provide a more comprehensive perspective.

Table 8: Base-to-new generalization. Prompts are learned from the base classes (16-shots) and evaluated on the same classes on the test set (Base), zero-shot on the unseen classes of the test set (New), and in terms of harmonic mean (H) between the base and the new accuracy. Average New performance improvements over the baselines are indicated in green. Here we see how KDPL generalizes better to the new classes, limiting deterioration in performance caused by the unbalanced few-shot training on half the classes of the source domain. Remarkably, we are competitive even on the base classes without requiring training labels.

<table><tr><td colspan="2" rowspan="2"/><td colspan="3">Average</td><td colspan="3">ImageNet</td><td colspan="3">OxfordPets</td><td colspan="3">Flowers102</td></tr><tr><td>Base</td><td>New</td><td>H</td><td>Base</td><td>New</td><td>H</td><td>Base</td><td>New</td><td>H</td><td>Base</td><td>New</td><td>H</td></tr><tr><td rowspan="5">RN50</td><td>CLIP (student)</td><td>61.61</td><td>65.88</td><td>63.67</td><td>64.40</td><td>60.10</td><td>58.20</td><td>85.80</td><td>93.70</td><td>83.70</td><td>63.80</td><td>71.30</td><td>61.00</td></tr><tr><td>CoOp</td><td>77.13</td><td>60.82</td><td>68.01</td><td>68.40</td><td>60.00</td><td>60.30</td><td>90.80</td><td>91.63</td><td>85.03</td><td>95.17</td><td>58.30</td><td>67.03</td></tr><tr><td>$\mathrm{{CoOp}} + \mathrm{{KDPL}}$</td><td>73.66</td><td>63.80</td><td>68.38</td><td>68.37</td><td>60.53</td><td>60.63</td><td>93.13</td><td>94.97</td><td>88.63</td><td>93.93</td><td>63.40</td><td>69.77</td></tr><tr><td>CoCoOp</td><td>75.47</td><td>64.39</td><td>69.49</td><td>68.30</td><td>63.07</td><td>61.90</td><td>92.13</td><td>94.93</td><td>87.73</td><td>91.10</td><td>67.47</td><td>68.37</td></tr><tr><td>$\mathrm{{CoCoOp}} + \mathrm{{KDPL}}$</td><td>71.69</td><td>65.90</td><td>68.67</td><td>68.13</td><td>62.87</td><td>61.63</td><td>93.40</td><td>95.33</td><td>89.07</td><td>87.77</td><td>70.63</td><td>70.43</td></tr><tr><td rowspan="9">ViT-B/32</td><td>CLIP (student)</td><td>64.81</td><td>70.05</td><td>67.33</td><td>67.40</td><td>64.00</td><td>62.00</td><td>86.90</td><td>96.30</td><td>85.00</td><td>68.70</td><td>72.30</td><td>64.30</td></tr><tr><td>CoOp</td><td>79.02</td><td>64.52</td><td>71.04</td><td>70.90</td><td>64.53</td><td>63.90</td><td>91.90</td><td>93.37</td><td>84.77</td><td>95.13</td><td>59.77</td><td>67.30</td></tr><tr><td>$\mathrm{{CoOp}} + \mathrm{{KDPL}}$</td><td>75.20</td><td>66.35</td><td>70.50</td><td>70.57</td><td>64.90</td><td>63.83</td><td>93.67</td><td>94.00</td><td>87.57</td><td>93.47</td><td>56.17</td><td>65.23</td></tr><tr><td>VPT</td><td>75.15</td><td>68.02</td><td>71.41</td><td>70.30</td><td>64.60</td><td>63.85</td><td>94.03</td><td>94.83</td><td>85.87</td><td>88.10</td><td>66.03</td><td>67.73</td></tr><tr><td>VPT + KDPL</td><td>72.12</td><td>68.76</td><td>70.40</td><td>70.70</td><td>65.20</td><td>64.30</td><td>93.80</td><td>95.20</td><td>85.53</td><td>82.73</td><td>67.87</td><td>67.30</td></tr><tr><td>MaPLe</td><td>78.26</td><td>69.79</td><td>73.79</td><td>71.40</td><td>66.70</td><td>65.40</td><td>93.07</td><td>96.87</td><td>90.03</td><td>93.37</td><td>69.77</td><td>71.83</td></tr><tr><td>MaPLe + KDPL</td><td>74.74</td><td>71.41</td><td>73.03</td><td>71.60</td><td>66.73</td><td>65.53</td><td>93.90</td><td>96.87</td><td>90.43</td><td>89.73</td><td>68.23</td><td>69.70</td></tr><tr><td>PromptSRC</td><td>81.17</td><td>70.45</td><td>75.43</td><td>72.50</td><td>65.93</td><td>65.63</td><td>93.40</td><td>96.30</td><td>89.30</td><td>96.20</td><td>71.37</td><td>74.90</td></tr><tr><td>PromptSRC + KDPL</td><td>77.11</td><td>71.61</td><td>74.26</td><td>72.70</td><td>66.33</td><td>65.93</td><td>94.37</td><td>96.47</td><td>90.17</td><td>94.93</td><td>68.83</td><td>73.10</td></tr><tr><td>ViT-H/14</td><td>CLIP (teacher)</td><td>86.11</td><td>86.63</td><td>86.37</td><td>86.50</td><td>84.10</td><td>82.80</td><td>94.40</td><td>99.20</td><td>94.80</td><td>96.60</td><td>85.60</td><td>89.40</td></tr></table>

<table><tr><td colspan="2" rowspan="2"/><td colspan="3">FGVCAircraft</td><td colspan="3">DTD</td><td colspan="3">EuroSAT</td><td colspan="3">StanfordCars</td></tr><tr><td>Base</td><td>New</td><td>H</td><td>Base</td><td>New</td><td>H</td><td>Base</td><td>New</td><td>H</td><td>Base</td><td>New</td><td>H</td></tr><tr><td rowspan="5">RN50</td><td>CLIP (student)</td><td>17.20</td><td>24.80</td><td>15.50</td><td>49.00</td><td>53.90</td><td>40.00</td><td>39.20</td><td>43.70</td><td>24.20</td><td>55.40</td><td>66.60</td><td>55.60</td></tr><tr><td>CoOp</td><td>27.93</td><td>22.17</td><td>18.90</td><td>75.03</td><td>40.93</td><td>47.13</td><td>89.30</td><td>42.13</td><td>46.07</td><td>67.77</td><td>59.87</td><td>58.30</td></tr><tr><td>$\mathrm{{CoOp}} + \mathrm{{KDPL}}$</td><td>24.33</td><td>21.27</td><td>17.03</td><td>66.73</td><td>38.70</td><td>42.70</td><td>71.17</td><td>62.07</td><td>47.23</td><td>67.93</td><td>56.63</td><td>56.70</td></tr><tr><td>CoCoOp</td><td>24.27</td><td>24.87</td><td>18.30</td><td>72.37</td><td>45.40</td><td>45.73</td><td>87.73</td><td>35.10</td><td>42.00</td><td>63.43</td><td>64.73</td><td>58.87</td></tr><tr><td>$\mathrm{{CoCoOp}} + \mathrm{{KDPL}}$</td><td>21.77</td><td>22.67</td><td>16.93</td><td>62.70</td><td>49.07</td><td>44.07</td><td>69.73</td><td>44.27</td><td>37.67</td><td>62.40</td><td>63.67</td><td>57.53</td></tr><tr><td rowspan="10">ViT-B/32 ViT-H/14</td><td>CLIP student</td><td>20.30</td><td>28.30</td><td>18.20</td><td>53.20</td><td>53.90</td><td>42.80</td><td>43.40</td><td>61.50</td><td>38.10</td><td>61.00</td><td>69.80</td><td>60.40</td></tr><tr><td>CoOp</td><td>30.80</td><td>23.03</td><td>20.27</td><td>77.17</td><td>45.57</td><td>49.50</td><td>88.37</td><td>49.13</td><td>51.23</td><td>71.13</td><td>61.73</td><td>61.17</td></tr><tr><td>$\mathrm{{CoOp}} + \mathrm{{KDPL}}$</td><td>26.67</td><td>22.00</td><td>18.23</td><td>67.13</td><td>47.33</td><td>44.10</td><td>71.40</td><td>62.07</td><td>46.90</td><td>69.37</td><td>62.37</td><td>60.47</td></tr><tr><td>VPT</td><td>25.23</td><td>29.70</td><td>20.77</td><td>72.93</td><td>50.17</td><td>46.27</td><td>76.27</td><td>50.03</td><td>43.87</td><td>64.07</td><td>69.90</td><td>61.27</td></tr><tr><td>VPT + KDPL</td><td>24.10</td><td>30.40</td><td>20.03</td><td>63.40</td><td>47.53</td><td>42.07</td><td>65.43</td><td>54.97</td><td>42.40</td><td>63.77</td><td>69.80</td><td>61.23</td></tr><tr><td>MaPLe</td><td>23.57</td><td>20.43</td><td>16.50</td><td>77.27</td><td>53.50</td><td>53.90</td><td>91.17</td><td>66.70</td><td>63.93</td><td>67.50</td><td>68.03</td><td>62.50</td></tr><tr><td>MaPLe + KDPL</td><td>25.43</td><td>27.37</td><td>19.93</td><td>66.27</td><td>50.33</td><td>46.53</td><td>74.03</td><td>75.70</td><td>62.30</td><td>66.97</td><td>68.40</td><td>62.40</td></tr><tr><td>PromptSRC</td><td>33.77</td><td>23.67</td><td>22.50</td><td>80.57</td><td>54.43</td><td>54.67</td><td>93.77</td><td>61.97</td><td>61.30</td><td>72.90</td><td>70.00</td><td>66.37</td></tr><tr><td>PromptSRC + KDPL</td><td>30.37</td><td>28.43</td><td>23.20</td><td>71.93</td><td>50.87</td><td>47.97</td><td>73.93</td><td>74.17</td><td>58.53</td><td>72.53</td><td>68.50</td><td>65.43</td></tr><tr><td>CLIP (teacher)</td><td>71.40</td><td>64.30</td><td>63.20</td><td>78.20</td><td>75.00</td><td>66.80</td><td>70.70</td><td>82.60</td><td>63.30</td><td>94.60</td><td>98.20</td><td>95.60</td></tr></table>

<table><tr><td colspan="2" rowspan="2"/><td colspan="3">Food101</td><td colspan="3">SUN397</td><td colspan="3">Caltech101</td><td colspan="3">UCF101</td></tr><tr><td>Base</td><td>New</td><td>H</td><td>Base</td><td>New</td><td>H</td><td>Base</td><td>New</td><td>H</td><td>Base</td><td>New</td><td>H</td></tr><tr><td rowspan="5">RN50</td><td>CLIP (student)</td><td>81.60</td><td>82.20</td><td>75.20</td><td>66.50</td><td>70.10</td><td>58.50</td><td>91.10</td><td>90.50</td><td>86.00</td><td>63.70</td><td>67.80</td><td>58.30</td></tr><tr><td>CoOp</td><td>82.63</td><td>82.03</td><td>75.37</td><td>76.37</td><td>66.77</td><td>61.50</td><td>95.50</td><td>87.53</td><td>88.53</td><td>79.50</td><td>57.63</td><td>61.53</td></tr><tr><td>$\mathrm{{CoOp}} + \mathrm{{KDPL}}$</td><td>83.73</td><td>83.07</td><td>76.77</td><td>73.43</td><td>69.83</td><td>61.93</td><td>95.10</td><td>88.75</td><td>88.90</td><td>72.43</td><td>62.63</td><td>59.97</td></tr><tr><td>CoCoOp</td><td>84.43</td><td>84.50</td><td>78.00</td><td>74.53</td><td>72.87</td><td>63.93</td><td>94.97</td><td>90.73</td><td>89.33</td><td>76.90</td><td>64.67</td><td>63.77</td></tr><tr><td>$\mathrm{{CoCoOp}} + \mathrm{{KDPL}}$</td><td>84.63</td><td>85.90</td><td>79.00</td><td>71.83</td><td>73.23</td><td>62.80</td><td>94.87</td><td>91.00</td><td>89.37</td><td>71.33</td><td>66.23</td><td>61.70</td></tr><tr><td rowspan="9">ViT-B/32</td><td>CLIP student</td><td>84.50</td><td>85.70</td><td>79.10</td><td>69.80</td><td>73.10</td><td>62.00</td><td>93.70</td><td>94.00</td><td>91.10</td><td>64.00</td><td>71.60</td><td>60.70</td></tr><tr><td>CoOp</td><td>85.17</td><td>85.50</td><td>79.27</td><td>79.17</td><td>69.37</td><td>64.93</td><td>97.40</td><td>92.13</td><td>92.37</td><td>82.13</td><td>65.60</td><td>66.93</td></tr><tr><td>$\mathrm{{CoOp}} + \mathrm{{KDPL}}$</td><td>86.40</td><td>87.23</td><td>81.10</td><td>75.87</td><td>74.17</td><td>65.70</td><td>96.47</td><td>93.43</td><td>92.57</td><td>76.17</td><td>66.20</td><td>64.20</td></tr><tr><td>VPT</td><td>85.47</td><td>85.83</td><td>79.60</td><td>75.70</td><td>75.13</td><td>65.47</td><td>97.10</td><td>92.57</td><td>92.80</td><td>77.43</td><td>69.47</td><td>65.10</td></tr><tr><td>VPT + KDPL</td><td>85.63</td><td>86.33</td><td>79.97</td><td>74.07</td><td>75.17</td><td>65.07</td><td>96.33</td><td>92.80</td><td>92.53</td><td>73.33</td><td>71.07</td><td>63.70</td></tr><tr><td>MaPLe</td><td>86.40</td><td>87.47</td><td>81.27</td><td>78.90</td><td>76.57</td><td>68.60</td><td>97.03</td><td>92.27</td><td>93.00</td><td>81.23</td><td>69.40</td><td>68.17</td></tr><tr><td>MaPLe + KDPL</td><td>86.50</td><td>87.83</td><td>81.73</td><td>75.57</td><td>76.83</td><td>67.07</td><td>97.00</td><td>93.67</td><td>93.33</td><td>75.10</td><td>73.53</td><td>67.07</td></tr><tr><td>PromptSRC</td><td>86.33</td><td>87.13</td><td>80.93</td><td>80.80</td><td>76.77</td><td>69.90</td><td>97.53</td><td>94.70</td><td>94.30</td><td>85.07</td><td>72.63</td><td>72.67</td></tr><tr><td>PromptSRC + KDPL</td><td>86.53</td><td>87.63</td><td>81.27</td><td>76.53</td><td>77.33</td><td>68.00</td><td>96.90</td><td>94.47</td><td>93.93</td><td>77.50</td><td>74.73</td><td>68.53</td></tr><tr><td>ViT-H/14</td><td>CLIP (teacher)</td><td>95.50</td><td>96.30</td><td>93.60</td><td>82.00</td><td>85.10</td><td>76.40</td><td>99.20</td><td>97.30</td><td>97.90</td><td>78.10</td><td>85.20</td><td>76.40</td></tr></table>

Table 9: Class Agnostic adaptation. Comparison between baselines and the proposed unsupervised class agnostic CA-KDPL variants (highlighted in cyan). The prompt is learned in an unsupervised and class-agnostic setting on ImageNet and evaluated on the generalization and on the cross-dataset benchmark datasets. Average performance improvements are indicated in green, and deterioration in red. Notably, our proposed unsupervised and class-agnostic approach is competitive against the reference supervised and class-aware baselines. Overall, on the cross-dataset benchmark we achieve better generalization, demonstrating that using CA-KDPL is a valid option in such settings.

<table><tr><td colspan="2" rowspan="2">Backbone Method</td><td>Source</td><td colspan="5">Cross-Domain Target</td><td colspan="11">Cross-Dataset Target</td></tr><tr><td>ImageNet</td><td>ImageNet-V2</td><td>ImageNet- $S$</td><td>ImageNet-A</td><td>ImageNet-R</td><td>Average</td><td>OxfordPets</td><td>Flowers102</td><td>FGVCAircraft</td><td>${DTD}$</td><td>${E}_{uroSAT}$</td><td>StanfordCars</td><td>Food101</td><td>SUN397</td><td>Caltech101</td><td>UCF101</td><td>Average</td></tr><tr><td rowspan="5">RN50</td><td>CLIP (student)</td><td>58.20</td><td>51.50</td><td>33.30</td><td>21.70</td><td>56.00</td><td>40.63</td><td>83.70</td><td>61.00</td><td>15.60</td><td>40.00</td><td>24.20</td><td>55.60</td><td>75.20</td><td>58.50</td><td>86.00</td><td>58.30</td><td>55.81</td></tr><tr><td>CoOp</td><td>62.40</td><td>55.17</td><td>33.70</td><td>23.13</td><td>56.20</td><td>42.05</td><td>84.60</td><td>61.63</td><td>13.77</td><td>36.83</td><td>22.33</td><td>54.20</td><td>75.03</td><td>59.00</td><td>87.67</td><td>57.73</td><td>55.28</td></tr><tr><td>CoOp + CA-KDPL</td><td>61.83</td><td>54.27</td><td>35.20</td><td>23.50</td><td>59.10</td><td>43.02</td><td>86.37</td><td>63.47</td><td>14.80</td><td>40.23</td><td>30.33</td><td>55.40</td><td>77.17</td><td>61.60</td><td>88.50</td><td>59.03</td><td>57.69</td></tr><tr><td>CoCoOp</td><td>63.07</td><td>55.53</td><td>34.77</td><td>23.73</td><td>59.47</td><td>43.38</td><td>86.93</td><td>63.47</td><td>16.27</td><td>40.53</td><td>27.20</td><td>55.47</td><td>77.73</td><td>61.40</td><td>88.07</td><td>60.43</td><td>57.75</td></tr><tr><td>CoCoOp + CA-KDPL</td><td>61.43</td><td>54.53</td><td>35.33</td><td>23.77</td><td>59.10</td><td>43.18</td><td>87.47</td><td>67.30</td><td>15.30</td><td>39.50</td><td>28.57</td><td>54.80</td><td>77.53</td><td>61.63</td><td>88.03</td><td>60.13</td><td>58.03</td></tr><tr><td rowspan="9">ViT-B/32</td><td>CLIP (student)</td><td>62.00</td><td>54.70</td><td>40.80</td><td>29.60</td><td>66.00</td><td>47.78</td><td>85.00</td><td>64.30</td><td>18.20</td><td>42.80</td><td>38.10</td><td>60.40</td><td>79.10</td><td>62.00</td><td>91.10</td><td>60.70</td><td>60.17</td></tr><tr><td>CoOp</td><td>66.33</td><td>58.30</td><td>41.40</td><td>31.47</td><td>65.87</td><td>49.26</td><td>87.13</td><td>62.20</td><td>12.13</td><td>40.57</td><td>36.97</td><td>57.83</td><td>80.13</td><td>62.83</td><td>91.13</td><td>61.80</td><td>59.27</td></tr><tr><td>CoOp + CA-KDPL</td><td>64.73</td><td>56.93</td><td>42.27</td><td>31.47</td><td>67.83</td><td>49.63</td><td>86.57</td><td>62.73</td><td>15.00</td><td>42.23</td><td>43.93</td><td>58.57</td><td>79.47</td><td>65.03</td><td>92.30</td><td>61.53</td><td>60.74</td></tr><tr><td>VPT</td><td>64.97</td><td>56.73</td><td>41.27</td><td>27.00</td><td>66.50</td><td>47.88</td><td>87.43</td><td>64.77</td><td>19.53</td><td>44.20</td><td>28.47</td><td>57.60</td><td>78.27</td><td>63.73</td><td>91.40</td><td>62.50</td><td>59.79</td></tr><tr><td>VPT + CA-KDPL</td><td>63.73</td><td>55.83</td><td>41.10</td><td>27.33</td><td>67.30</td><td>47.89</td><td>87.20</td><td>63.17</td><td>18.43</td><td>44.00</td><td>33.53</td><td>55.47</td><td>77.70</td><td>63.63</td><td>91.93</td><td>62.93</td><td>59.80</td></tr><tr><td>MaPLe</td><td>66.80</td><td>58.53</td><td>42.23</td><td>30.13</td><td>66.40</td><td>49.32</td><td>88.37</td><td>66.43</td><td>18.47</td><td>42.03</td><td>37.77</td><td>60.00</td><td>80.10</td><td>64.43</td><td>91.33</td><td>62.50</td><td>61.14</td></tr><tr><td>MaPLe + CA-KDPL</td><td>65.23</td><td>57.43</td><td>42.07</td><td>30.00</td><td>67.63</td><td>49.28</td><td>88.30</td><td>64.97</td><td>16.07</td><td>44.03</td><td>41.53</td><td>57.90</td><td>79.80</td><td>64.97</td><td>92.77</td><td>61.93</td><td>61.23</td></tr><tr><td>PromptSRC</td><td>66.33</td><td>58.70</td><td>42.97</td><td>32.07</td><td>68.93</td><td>50.67</td><td>88.13</td><td>65.33</td><td>17.17</td><td>43.90</td><td>40.50</td><td>60.17</td><td>81.23</td><td>65.40</td><td>92.37</td><td>63.63</td><td>61.78</td></tr><tr><td>PromptSRC + CA-KDPL</td><td>65.00</td><td>57.50</td><td>42.90</td><td>32.30</td><td>68.77</td><td>50.37</td><td>87.53</td><td>65.47</td><td>17.87</td><td>42.17</td><td>44.53</td><td>60.07</td><td>80.50</td><td>65.67</td><td>93.10</td><td>62.37</td><td>61.93</td></tr><tr><td colspan="2">ViT-H/14J/14 CLIP (teacher)</td><td>82.80</td><td>76.60</td><td>71.10</td><td>71.10</td><td>91.30</td><td>77.53</td><td>94.80</td><td>89.40</td><td>63.20</td><td>66.80</td><td>63.30</td><td>95.60</td><td>93.60</td><td>76.40</td><td>97.90</td><td>76.40</td><td>81.74</td></tr></table>

In Table 8, we observe that the baseline methods without KDPL outperform our approach in few-shot transfer learning on base classes. Thanks to the supervision label signal, the baselines can exploit the ground-truth source training classes. Without using KDPL, however, all the baseline methods suffer from forgetting the unseen classes. In particular, we see that training on base-shots causes a decrease in performance on the unseen classes. Certain methods in particular suffer from this phenomenon, typical of an Incremental Learning setting (e.g. in Figure 4 we see that the average performance of MaPLe on unseen classes is consistently below the average zero-shot unseen performance). Applying our method instead exhibits a more favorable trend in zero-shot transfer learning on unseen classes, alleviating the forgetting of unseen classes. Our method is preferable in scenarios where labeled data for base classes are not available, and improvement in base class performance is desired without compromising zero-shot transfer performance on unseen classes.

### C.2. Class Agnostic Scenario

In the main paper we did not include all results for the class agnostic setting due to space limitations, but only reported the average domain generalization performance and the average cross-dataset performance. Here, in Table 9 we provide all class agnostic results comparing our proposed method (CA-KDPL) against the baselines. As mentioned in the main paper, even without knowing either the labels or the training class names, our proposed unsupervised method is competitive, and sometimes even outperforms the baselines.

![bo_d1c3l9bef24c73d2ojn0_25_389_465_1029_1034_0.jpg](images/bo_d1c3l9bef24c73d2ojn0_25_389_465_1029_1034_0.jpg)

Fig. 4: Generalization to Unseen Classes. The base-to-unseen generalization results of MaPLe+KDPL versus MaPLe are reported. Prompts are learned from the base classes and evaluated on the same base classes and on the unseen classes of the test set. Instead of reporting only the 16-shot performance, we include results for 1-, 2-, 4-, 8-, and 16-shots. Here we see that increasing the number of shots increases the performance of the base class but harms the performance on unseen classes. However, with our approach we can alleviate this problem, reaching an average 16-shots performance on unseen classes greater than the zero-shot reference, while the average MaPLe performance remains below the average zero-shot reference for all shots.

