# Domain Adaptation based Object Detection for Autonomous Driving in Foggy and Rainy Weather

Jinlong Li, Runsheng Xu, Xinyu Liu, Jin Ma, Baolu Li, Qin Zou, Jiaqi Ma, Hongkai Yu*

${Abstract}$ -Typically, object detection methods for autonomous driving that rely on supervised learning make the assumption of a consistent feature distribution between the training and testing data, this such assumption may fail in different weather conditions. Due to the domain gap, a detection model trained under clear weather may not perform well in foggy and rainy conditions. Overcoming detection bottlenecks in foggy and rainy weather is a real challenge for autonomous vehicles deployed in the wild. To bridge the domain gap and improve the performance of object detection in foggy and rainy weather, this paper presents a novel framework for domain-adaptive object detection. The adaptations at both the image-level and object-level are intended to minimize the differences in image style and object appearance between domains. Furthermore, in order to improve the model's performance on challenging examples, we introduce a novel adversarial gradient reversal layer that conducts adversarial mining on difficult instances in addition to domain adaptation. Additionally, we suggest generating an auxiliary domain through data augmentation to enforce a new domain-level metric regularization. Experimental findings on public benchmark exhibit a substantial enhancement in object detection specifically for foggy and rainy driving scenarios. The code is available at https://github.com/jinlong17/DA-Detect.

Index Terms-intelligent vehicles, deep learning, object detection, domain adaptation

## I. INTRODUCTION

TI HE past decade has witnessed the significant break- throughs on autonomous driving with artificial intelligence methods [2], [3], leading to numerous applications in transportation, including improving traffic safety [4]-[6], reducing traffic congestion [7], [8], minimizing air pollution [9], [10], and enhancing traffic efficiency [11]-[13]. Object detection is a critical component of autonomous driving, which relies on computer vision and artificial intelligence techniques to understand driving scenarios [2], [14]. However, the foggy and rainy weather conditions make the understanding of camera images particularly difficult, which poses challenges to the camera based object detection system installed on the intelligent vehicles [15]-[17].

Thanks to the rapid advancements in deep learning, numerous object detection deep learning-based methods have achieved remarkable success in intelligent transportation systems. However, the impressive performance of these popular methods heavily relies on large-scale annotated data for supervised learning. Moreover, these methods make the assumption of consistent feature distributions between the training and testing data. In reality, this assumption may not hold true, especially in diverse weather conditions [22]. For example, as depicted in Fig. 1, CNN models such as YOLOv4 [20], Faster R-CNN [18], and Mask R-CNN [19], trained on clear-weather data (source domain), exhibit accurate object detection performance under clear weather conditions (Fig. 1b). However, their performance significantly degrades under foggy weather conditions (Fig. 1c). This degradation can be attributed to the presence of a feature domain gap between different weather conditions, as illustrated in Fig. 1a. The model trained on the source domain is not familiar with the feature distribution in the target domain. Consequently, this paper aims to enhance object detection specifically in foggy and rainy weather conditions through domain adaptation-based transfer learning.

![bo_d282pqf7aajc738orlug_0_916_504_743_580_0.jpg](images/bo_d282pqf7aajc738orlug_0_916_504_743_580_0.jpg)

Fig. 1. Illustration of the weather domain gap (foggy and rainy) for autonomous driving and the detection performance drop because of the domain gap. Three deep learning models ( Faster R-CNN [18], Mask R-CNN [19], and YOLOv4 [20]) are all trained with the clear weather data of Cityscapes [21].

The objective of this paper is to reduce the domain gap between various weathers for enhanced object detection. To handle the domain shift problem (e.g. Clear $\rightarrow$ Foggy and Clear $\rightarrow$ Rainy), in this paper, we present a new domain adaptation framework that aims to enhance the robustness of object detection in foggy and rainy weather conditions. Our proposed framework follows an unsupervised setting, similar to previous works [23]-[25]. In this setting, we have well-labeled clear-weather images as the source domain, while the foggy and rainy weather images, which serve as the target domains, lack any annotations. This unsupervised setting is because adverse weather images with labeling (manual annotating) are time-consuming and costly. Inspired by [23], [26], the proposed method aims to reduce the domain feature discrepancies in both image style and object appearance. To enhance robustness and prevent data-level overfitting, we propose a Dynamic Masking Process to generate masked images by "dropping" some pixel regions. To achieve domain-invariant features, we incorporate both image-level and object-level domain classifiers as components to facilitate domain adaptation in our CNN architecture. These classifiers are responsible for distinguishing between different domains. By employing an adversarial approach, our detection model learns to generate features that are invariant to domain variations, thereby confusing the domain classifiers. This adversarial design encourages the network to produce features that are agnostic to specific weather conditions, leading to improved object detection performance in foggy and rainy weather scenarios.

---

Jinlong Li, Jin Ma, and Xinyu Liu are with the Department of Computer Science, Cleveland State University, Cleveland, OH 44115, USA. Baolu Li and Hongkai Yu are with the Department of Electrical and Computer Engineering, Cleveland State University, Cleveland, OH 44115, USA. Runsheng Xu and Jiaqi Ma are with the Department of Civil and Environmental Engineering, University of California, Los Angeles, CA 90024, USA. Qin Zou is with the School of Computer Science, Wuhan University, Wuhan 430072, China. A preliminary version of this work has been published on the IEEE/CVF WACV2023 conference [1]. This work was supported by NSF 2215388.

* Corresponding author: Hongkai Yu (e-mail: h.yu19@csuohio.edu).

---

Furthermore, we propose a novel methodology for domain adaptation (DA). Current existing domain adaptation methods [23], [25]-[28] might ignore: 1) the different challenging levels of various training samples, 2) the domain-level feature metric distance to the third related domain by only involving the source domain and target domain. This paper investigates the incorporation of hard example mining and an additional related domain to further strengthen the model's ability to learn robust and transferable representations. We propose a novel Adversarial Gradient Reversal Layer (AdvGRL) and introduce an auxiliary domain through data augmentation. The AdvGRL is designed to perform adversarial mining on challenging examples, thereby improving the model's ability to learn in challenging scenarios. Additionally, the auxiliary domain is leveraged to enforce a new domain-level metric regularization during the transfer learning process. In summary, the contributions of this paper can be summarized as follows:

- This paper proposes a novel unsupervised domain adaptation method to enhance object detection for autonomous vehicles under foggy and rainy conditions, including the image-level and object-level adaptations.

- This paper proposes to perform adversarial mining for hard examples during domain adaptation to further improve the model's transfer learning capabilities under challenging samples, which is accomplished by our proposed AdvGRL.

- This paper proposes a new domain-level metric regularization to improve transfer learning, i.e., the regularization constraint between source domain, added auxiliary domain, and target domain.

- This paper explores the intensive transfer learning experiments of clear $\rightarrow$ foggy, clear $\rightarrow$ rainy, cross-camera adaptation, and also carefully studies the different-intensity (small, medium, large) fog and rain adaptations.

## II. RELATED WORK

## A. Detection for intelligent vehicles

The contemporary realm of intelligent vehicles has garnered considerable attention, primarily directing towards the enhancement of road safety, mitigation of traffic congestion, and the overall optimization of transportation systems [29], [30]. Recent strides in deep learning have been pivotal in propelling the field of intelligent vehicles forward [31]-[33]. Within this landscape, object detection has emerged as a focal point of extensive research endeavors, encompassing the identification and classification of objects such as vehicles, pedestrians, traffic signs, traffic lights, and assessing road conditions [34], [35]. Deep learning methods have been prominently introduced to address object detection tasks, generally falling into two distinct categories: two-stage object detectors and one-stage object detectors. Faster RCNN [18] and Mask RCNN [19] are one of the classic two-stage methods, which typically consist of two main stages: region proposal generation and object classification/localization. While YOLO series [36] and SSD [37] are one of the representative one-stage methods, which typically use a set of predefined anchor boxes or default boxes at different scales and aspect ratios to densely cover the image. [38] designed an edge intelligence-based vehicle detection algorithm based on YOLOv4 to augment vehicle detection capabilities. [39], on the other hand, proposed a multistage algorithm that initially leverages the YOLOv3 network for object detection. It's also worth noting that Faster R-CNN and Mask R-CNN have been conventionally employed for vehicle detection in the context of intelligent vehicles [40], attesting to their commendable performance in various scenarios. However, the direct application of these methods in autonomous driving settings is often constrained by the formidable challenges posed by adverse real-world weather conditions.

## B. Detection for intelligent vehicles under foggy and rainy weather

In recent years, considerable research has been dedicated to addressing the challenges posed by various weather conditions encountered in autonomous driving scenarios. Researchers have generated various datasets [22], [41] and proposed numerous methods [42]-[47] to improve object detection under adverse weather conditions. One notable example is the Foggy Cityscape dataset, which is a synthetic dataset created by applying fog simulation to the Cityscape dataset [22]. In the context of object detection research in rainy weather, several synthesized rainy datasets have been proposed [46]-[48]. [43] devised a fog simulation technique to augment existing real lidar datasets, thereby enhancing their quality and realism. The simulated foggy data offers valuable opportunities to enhance object detection methods that are specifically tailored for foggy weather conditions. For leveraging information from multiple sensors, [45] designed a network to integrate data from different sensors e.g., LiDAR, camera, and radar. [44] proposed a method that exploits both LiDAR and radar signals to obtain object proposals. The features extracted from the regions of interest in both sensors are fused together to improve the performance of object detection. However, these mentioned methods often rely on input data from different types of sensors other than the camera alone, which may not be applicable to all autonomous driving vehicles. Therefore, the objective of this work is to develop a DA network by utilizing only camera-sensor data as input.

## C. Object Detection via Domain Adaptation

Domain adaptation is effective in reducing the distribution discrepancy between different domains, enabling models trained on a labeled source domain to be applicable to an unlabeled target domain. There has been a growing interest in addressing domain adaptation for object detection [23], [26], [49]-[54] in recent years. Several studies [23], [26], [50], [54], [55] have explored the alignment of features from different domains to achieve DA object detectors. A DA Faster R-CNN framework [23] was proposed to reduce the domain gap at both the image level and instance level. He et al. [55] proposed a multi-adversarial network that aligns domain features and proposal features hierarchically to minimize domain distribution disparity. In addition to feature alignment, image style transfer approaches [34], [49], [56], [57] are utilized to address the challenge of DA. An image translation module [34] was utilized to convert images from the source domain to the target domain. They then trained the object detector using adversarial training on the target domain. [56] adopted a progressive image translation strategy and introduced a weighted task loss during adversarial training to address image quality differences. Several previous methods [58]-[61] have also proposed complex architectures for domain adaptation in object detection. Feature Pyramid Networks (FPN) was utilized to incorporate pixel-level and category-level adaptation for object detection [58]. In order to incorporate the uncertainty of unlabeled target data, [60] introduced an uncertainty-guided self-training mechanism, which leverages a Probabilistic Teacher and Focal Loss. Different with these methods, our approach does not introduce additional learnable parameters to the Faster R-CNN. Instead, we utilize an AdvGRL and a Domain-level Metric Regularization based on triplet loss. A key difference between our method and previous domain adaptation approaches lies in the treatment of training samples. While existing methods often assume that training samples are at the same challenging level, our approach introduces the AdvGRL for adversarial hard example mining, specifically targeting the improvement of transfer learning performance. Additionally, to mitigate overfitting and improve domain adaptation, an auxiliary domain is generated and incorporated into domain-level metric regularization.

## III. METHODOLOGY

This section introduces the overall network architecture, each detailed component, loss functions of our proposed method.

## A. Network Architecture

As shown in Fig. 2, our proposed network follows the pipeline of Faster R-CNN. In the first step, we deploy a Dynamic Masking Process to generate the masked images, then we involve a CNN backbone to extract the image-level features from masked images. These features are then fed into the Region Proposal Network to produce region proposals. The next stage involves the Region of Interest (ROI) pooling, both the image-level features and the object proposals are as input to obtain object-level features. Finally, we apply a detection head for the object-level features to make the final outputs. To enhance the framework of Faster R-CNN for domain adaptation, we incorporate two additional domain adaptation modules: image-level and object-level modules. Both of them utilize a novel AdvGRL in conjunction with the domain classifier. By combining these modules, we are able to extract domain-invariant features and effectively perform adversarial hard example mining. Additionally, an auxiliary domain is introduced to enforce a new domain-level metric regularization. During training, source, target, and auxiliary domains, are simultaneously utilized.

## B. Dynamic Masking Process

Before feeding the input images into the CNN backbone, we implement our newly proposed Dynamic Masking Process (DMP) to generate masked images. This deep learning method can leverage contextual clues derived from surrounding image patches that may represent various parts of the object or its environment [62]-[64]. In the training of deep learning models, the Dropout method is employed effectively by randomly "dropping" neurons within the network to combat overfitting in CNNs [65]. Drawing inspiration from [62], [64], and to bolster the learning of robust features while also curbing overfitting, our DMP selectively masks patches, each comprising 64 pixels across three input images. During model training, our DMP enhances robustness and prevents data-level overfitting by randomly "dropping" these patches (i.e., some specific pixel regions within the images), which is illustrated in Fig. 4. The patch mask rate is randomly sampled, following a uniform distribution ranging from 0 to 1 .

## C. Image-level based Adaptation

The image-level domain representation is derived from the feature extraction process of the backbone network, encompassing valuable global information such as style, scale, and illumination. These factors have the potential to greatly influence the performance of the object detection task [23]. To address this, we incorporate a domain classifier, which aims to classify the domains of the extracted image-level features and promote global alignment at the image level. The domain classifier is implemented as two simple convolutional layers. It takes the image-level features as input and produces a prediction to identify the feature domain. A Binary Cross Entropy (BCE) loss is employed for the domain classifier as follows:

$$
{L}_{img} =  - \mathop{\sum }\limits_{{i = 1}}^{N}\left\lbrack  {{G}_{i}\log {P}_{i} + \left( {1 - {G}_{i}}\right) \log \left( {1 - {P}_{i}}\right) }\right\rbrack  , \tag{1}
$$

where $i \in  \{ 1,\ldots , N\}$ represents the $N$ training images, the ground truth domain label of the $i$ -th training image is denoted as ${G}_{i} \in  \{ 1,0\}$ , where ${G}_{i}$ takes a value of 1 or 0 to represent the source and target domains, respectively. The prediction of the domain classifier for the $i$ -th training image is denoted as ${P}_{i}$ .

![bo_d282pqf7aajc738orlug_3_134_174_1519_577_0.jpg](images/bo_d282pqf7aajc738orlug_3_134_174_1519_577_0.jpg)

Fig. 2. The architecture of the proposed domain adaptation-based enhanced detection for intelligent vehicles in foggy and rainy weather. Here we illustrate our target domain using the example of foggy weather. It is recommended to view this figure in color.

## D. Object-level based Adaptation

Besides the global differences at the image level, objects within different domains may exhibit variations in terms of appearance, size, color, and other characteristics. To address this, Each region proposal generated by the ROI Pooling layer is considered as a potential object of interest. After obtaining the object-level domain representation via ROI pooling, we introduce an object-level domain classifier to discern the origin of the local features, which is implemented by three fully connected layers. The objective of the object-level domain classifier is to align the distribution of object-level features across different domains. Similar to the image-level domain classifier, we utilize the BCE loss to train our object-level domain classifier:

$$
{L}_{obj} =  - \mathop{\sum }\limits_{{i = 1}}^{N}\mathop{\sum }\limits_{{j = 1}}^{M}\left\lbrack  {{G}_{i, j}\log {P}_{i, j} + \left( {1 - {G}_{i, j}}\right) \log \left( {1 - {P}_{i, j}}\right) }\right\rbrack  . \tag{2}
$$

where $j \in  \{ 1,\ldots , M\}$ is the $j$ -th predicted object in the $i$ - th image, ${P}_{i, j}$ is the prediction of the object-level domain classifier for the $j$ -th region proposal in the $i$ -th image, the corresponding binary ground-truth label for the source and target domains is denoted as ${G}_{i, j}$ .

## E. Adversarial Gradient Reversal Layer

In this section, we will begin by providing a brief overview of the original Gradient Reversal Layer (GRL), which serves as the foundation for our proposed Adversarial Gradient Reversal Layer (AdvGRL). The original GRL was initially developed for unsupervised domain adaptation in image classification tasks [66]. During forward propagation, the GRL leaves the input unchanged. However, during back-propagation, the gradient is reversed by multiplying it by a negative scalar before propagating it to the preceding layers of the base network. This reversal of gradients serves as a mechanism to confuse the domain classifier. Like this, by reversing the gradient during back-propagation, the GRL encourages the base network to learn domain-invariant features, enabling DA. The forward propagation of GRL is defined as:

$$
{R}_{\lambda }\left( \mathbf{v}\right)  = \mathbf{v} \tag{3}
$$

![bo_d282pqf7aajc738orlug_3_972_926_603_325_0.jpg](images/bo_d282pqf7aajc738orlug_3_972_926_603_325_0.jpg)

Fig. 3. Illustration of the AdvGRL-based hard training example mining. We assign larger responses to harder training examples with lower domain classifier loss $\left( {L}_{c}\right)$ values. In this paper, we set ${\lambda }_{0} = 1$ and $\beta  = {30}$ .

![bo_d282pqf7aajc738orlug_3_912_1416_744_188_0.jpg](images/bo_d282pqf7aajc738orlug_3_912_1416_744_188_0.jpg)

Fig. 4. Sample visualization of Dynamic Masking Process (DMP): (a) the masked original image from Cityscapes [21], (b) masked synthesized foggy image, (c) masked synthesized rainy image.

where $\mathbf{v}$ represents an input feature vector, and ${R}_{\lambda }$ represents the forward function performed by GRL. Back-propagation of GRL is defined as:

$$
\frac{d{R}_{\lambda }}{d\mathbf{v}} =  - \lambda \mathbf{I}, \tag{4}
$$

where $\mathbf{I}$ is an identity matrix and $- \lambda$ is a negative scalar. In the original GRL, a constant or varying value of $- \lambda$ is utilized, which is determined by the training iterations, as described in [66]. However, this approach overlooks the fact that different training samples may exhibit varying levels of challenge during transfer learning. To address this limitation, this paper introduces a novel AdvGRL that incorporates adversarial mining for hard examples. This is achieved by replacing the parameter $\lambda$ with a new parameter ${\lambda }_{adv}$ in Eq. (4) of GRL, resulting in the proposed AdvGRL. Notably, the value of ${\lambda }_{adv}$ is determined as follows:

$$
{\lambda }_{adv} = \left\{  \begin{matrix} \min \left( {\frac{{\lambda }_{0}}{{L}_{c}},\beta }\right) , & {L}_{c} < \alpha \\  {\lambda }_{0}, & \text{ otherwise,} \end{matrix}\right.  \tag{5}
$$

where ${L}_{c}$ represents the loss of the domain classifier. $\alpha$ is a hardness threshold used to determine the difficulty level of the training sample. $\beta$ is the overflow threshold implemented to prevent the generation of excessive gradients during back-propagation. In our experiment, we set ${\lambda }_{0} = 1$ as a fixed parameter. Namely, when the domain classifier’s loss ${L}_{c}$ is smaller, it indicates that the training sample's domain can be more easily identified by the classifier. In this case, the features associated with this sample are not the desired domain-invariant features, making it a more difficult example for domain adaptation. The relationship between ${\lambda }_{adv}$ and ${L}_{c}$ is visualized in Fig. 3

Ous proposed AdvGRL serves two main purposes. 1) It utilizes the concept of gradient reversal during back-propagation to confuse the domain classifier, thereby promoting the generation of domain-invariant features. 2) AdvGRL enables adversarial mining for hard examples, meaning that it selectively focuses on challenging examples that contribute to the model's generalization. Fig. 2 illustrates the utilization of the AdvGRL in both the image-level and object-level DA modules.

## F. Domain-level Metric Learning based Regularization

A common transfer learning approach in many existing DA methods is to prioritize the transfer of features from a source domain $S$ to a target domain $T$ . Hence, they often overlook the potential advantages that a third-related domain can offer. To explore the potential advantages of incorporating a third related domain, we introduce an auxiliary domain for domain-level metric regularization that complements the source domain $S$ . We leverage advanced data augmentation techniques to create this auxiliary domain $A$ , which is particularly useful in autonomous driving scenarios where training data needs to be synthesized for different weather conditions based on existing clear-weather data. As a result, in our proposed architecture (as shown in Fig. 2), the source, auxiliary, and target domain images are regarded as aligned images, ensuring the enforcement of domain-level metric constraints across these three distinct domains.

The global image-level features of the $i$ -th training image for the source(S), auxiliary(A), and target(T)domains are defined as ${F}_{i}^{S},{F}_{i}^{A}$ , and ${F}_{i}^{T}$ , respectively. Our goal is to reduce the domain gap between $S$ and $T$ and ensure that the feature metric distance between ${F}_{i}^{S}$ and ${F}_{i}^{T}$ is closer compared to the distance between ${F}_{i}^{S}$ and ${F}_{i}^{A}$ . This can be expressed as:

$$
d\left( {{F}_{i}^{S},{F}_{i}^{T}}\right)  < d\left( {{F}_{i}^{S},{F}_{i}^{A}}\right) , \tag{6}
$$

where the metric distance between the corresponding features is denoted as $d\left( ,\right)$ . To implement this constraint, we can use a triplet structure where ${F}_{i}^{S},{F}_{i}^{T}$ , and ${F}_{i}^{A}$ are treated as the anchor, positive, and negative, respectively. Therefore, the image-level constraint in Eq. (6) can be equivalently expressed as minimizing the image-level triplet loss:

$$
{L}_{img}^{R} = \max \left( {d\left( {{F}_{i}^{S},{F}_{i}^{T}}\right)  - d\left( {{F}_{i}^{S},{F}_{i}^{A}}\right)  + \delta ,0}\right) , \tag{7}
$$

where the margin constraint is denoted as $\delta$ , and in our experiments, $\delta$ is set as 1.0 . Equivalently, the $i$ -th training image’s $j$ -th object-level features of $S, A$ , and $T$ are defined as ${f}_{i, j}^{S},{f}_{i, j}^{A}$ , and ${f}_{i, j}^{T}$ respectively. To apply our proposed metric regularization to the object-level features, we further minimize the object-level triplet loss:

$$
{L}_{obj}^{R} = \max \left( {d\left( {{f}_{i, j}^{S},{f}_{i, j}^{T}}\right)  - d\left( {{f}_{i, j}^{S},{f}_{i, j}^{A}}\right)  + \delta ,0}\right) . \tag{8}
$$

## G. Training Loss

The overall training loss of the proposed network consists of several individual components. It can be expressed as follows:

$$
L = \gamma  * \left( {{L}_{img} + {L}_{obj} + {L}_{img}^{R} + {L}_{obj}^{R}}\right)  + {L}_{cls} + {L}_{reg}, \tag{9}
$$

where ${L}_{cls}$ and ${L}_{reg}$ represent the loss of classification and the loss of regression respectively. A weight parameter $\gamma$ is introduced to balance the Faster R-CNN loss and the domain adaptation loss, which is set as 0.1 . During the training phase, the network can be trained in an end-to-end manner utilizing a standard SGD algorithm. During the testing phase, object detection can be performed using the Faster R-CNN with the trained adapted weights.

## H. General Domain Adaptive Detection with Proposed Method

Our proposed method is designed to be versatile and adaptable to various domain adaptive object detection scenarios. Specifically, when dealing with scenarios where the target domain images are generated from the source domain with pixel-to-pixel correspondence, such as the Clear Cityscapes $\rightarrow$ Foggy Cityscapes, our method can be directly applied without any modifications. To utilize our method with unaligned datasets in real-world scenarios, where the target and source domains lack strict correspondence, such as the Cityscapes $\rightarrow$ KITTI, we can remove the ${L}_{obj}^{R}$ loss, which eliminates the requirement for object alignment during training. This allows our method to be applied directly without the need for object-level alignment.

![bo_d282pqf7aajc738orlug_5_138_168_747_187_0.jpg](images/bo_d282pqf7aajc738orlug_5_138_168_747_187_0.jpg)

Fig. 5. Illustration of synthesizing Rainy Cityscapes from the Cityscapes data: (a) the original image from Cityscapes [21], (b) rain map generated by RainMix [67], (c) synthesized rainy image.

## IV. EXPERIMENTS

## A. Benchmark

Cityscapes [21]: It is a widely used computer vision dataset that focuses on urban street scenes. There are 2,975 training sets and 500 validation sets from 27 different cities. The dataset includes annotations for 8 different categories. All images in the Cityscapes dataset are 3-channel ${1024} \times  {2048}$ images.

Foggy Cityscapes [22]: It is a public benchmark dataset created by simulating different intensity levels of fog on the original Cityscapes images. This dataset uses a depth map and a physical model [22] to generate three levels of simulated fog.

Rainy Cityscapes: We synthesize a rainy-weather dataset named as Rainy Cityscapes in this paper from the original Cityscapes dataset. Specifically, the training set of 3,475 images and the validation set of 500 images from Cityscapes are used to create the Rainy Cityscapes dataset by utilizing a novel data augmentation method called RainMix [67], [68]. To generate rainy Cityscapes images, we utilize a combination of techniques. First, we randomly sample a rain map from a publicly dataset of real rain streaks [69]. Next, we apply random transformations to the rain map using the RainMix technique. These transformations include rotation, zooming, translation, and shearing, which are randomly sampled and combined. Lastly, the rain maps after transformation are merged with the original source domain images, resulting in the generation of rainy Cityscapes images. An example illustrating this process can be seen in Figure 5

Intensity levels of fog/rain: For the Foggy Cityscapes and Rainy Cityscapes datasets, their number of images, resolution, and annotations are identical to those of the Clear Cityscapes dataset. Based on the physical model of [22], the different intensity levels of fog could be synthesized on the Foggy Cityscapes dataset. After obtaining the rain maps by Rain-Mix [67], the intensity of rain maps could be further processed with different erosion levels. In these two ways, the different fog and rain levels (small, medium, large) can be synthesized, as shown in Fig. 6 Following the setting [23], [26], [54], the images with the highest intensity level of fog/rain are selected as the target domain for model training. The models trained with the highest intensity level will be then used to test the performance on the validation sets of different fog/rain intensity levels (small, medium, large).

## B. Experimental Setting

Dataset setting: We conducted two main experiments in this paper: 1) Clear to Foggy Adaptation, denoted as Clear Cityscapes $\rightarrow$ Foggy Cityscapes, the labeled training set of Clear Cityscapes [21] and the unlabeled training set of Foggy Cityscapes [22] are used as the source and target domains during training, respectively. Subsequently, the trained model was evaluated by the Foggy Cityscapes validation set to report the performance. Rainy Cityscapes training set is used as the Auxiliary Domain $A$ in this Clear to Foggy Adaptation experiment. 2) Clear to Rainy Adaptation, denoted as the Clear Cityscapes $\rightarrow$ Rainy Cityscapes, where the labeled training set of Clear Cityscapes [21] and the unlabeled training set of Rainy Cityscapes are used as the source and target domains during training, respectively. Then the trained model was evaluated on Rainy Cityscapes validation set to report the performance. Foggy Cityscapes training set is used as the Auxiliary Domain $A$ in this Clear to Rainy Adaptation experiment. Additionally, we analyzed the transfer learning performance on different intensity levels of fog and rain (small, medium, and large).

Training setting: We utilize ResNet-50 as the backbone for the Faster R-CNN [18]. Following in [18], [23], during training, We utilize back-propagation and stochastic gradient descent (SGD) to optimize all the deep learning methods in our approach. The initial learning rate of 0.01 for 50,000 iterations is used in all model training. Afterward, the learning rate is reduced to 0.001 and training continues for an additional 20,000 iterations. Weight decay is set as 0.0005 and momentum is set as 0.9 for all experiments. Each training batch consists of three images from the source, target, and auxiliary domains respectively. For comparison purposes, we set the $\lambda$ value in the original GRL (Equation (4)) to 1. In the AdvGRL (Equation (5)), the hardness threshold $\alpha$ is set to 0.63, which is computed by averaging the parameters in Equation (1) with setting $\left( {{P}_{i} = {0.7},{G}_{i} = 1}\right.$ and $\left. {{P}_{i} = {0.3},{G}_{i} = 0}\right)$ . In the subsequent analysis, we refer to "Reg + AdvGRL" as our proposed DA method. Additionally, "Reg + AdvGRL + DMP" is designated as our enhanced DA method, termed DA+, which is named "Ours+" for short in the tables.

Evaluation metrics: We calculate the Average Precision for each category and the mean Average Precision across all categories using an Intersection over the Union threshold of 0.5 .

## C. Adaptation from Clear to Foggy

Table 1 presents the results of our experiments on weather adaptation from clear to foggy. In comparison to other DA methods, our proposed DA+ method achieves the highest performance on Foggy Cityscape, with a mAP of ${43.4}\%$ , which outperforms the third-best method SCAN [75] by a margin of 1.3% in terms of mAP improvement. The proposed DA+ method effectively reduces the domain gap across various categories, e.g., the rider got 49.1% and the bicycle got 41.6% as the second best performance, and the train got ${51.3}\%$ as the best performance in AP, which is the highlight in Table 1 While UMT got ${56.6}\%$ in the bus and ${34.1}\%$ in the truck, ConfMix got ${62.6}\%$ in the car, MeGA-CDA got ${49.0}\%$ in the rider, our proposed DA+ method exhibits similar performance across them with only minor differences. However, our proposed DA+ method achieves the highest overall mAP detection performance on Foggy Cityscapes among the recent DA methods.

TABLE I

Adaptation from Clear to Foggy: Cityscapes $\rightarrow$ Foggy Cityscapes experiment. Note that Oracle represents the Faster R-CNN trained on foggcy Cityscape training set with all labels. The best performance is bold and the second best is underlined.

<table><tr><td>Methodologies</td><td>${C}_{bus}$</td><td>${C}_{\text{bicycle }}$</td><td>${C}_{car}$</td><td>${C}_{\text{mcycle }}$</td><td>${C}_{person}$</td><td>${C}_{rider}$</td><td>${C}_{train}$</td><td>${C}_{truck}$</td><td>mAP</td></tr><tr><td>MCAR-ECCV’2020 [51]</td><td>44.1</td><td>36.6</td><td>43.9</td><td>37.4</td><td>32.0</td><td>42.1</td><td>43.4</td><td>31.3</td><td>38.8</td></tr><tr><td>MTOR-CVPR-2019 [70]</td><td>38.6</td><td>35.6</td><td>44.0</td><td>28.3</td><td>30.6</td><td>41.4</td><td>40.6</td><td>21.9</td><td>35.1</td></tr><tr><td>DA-Faster-CVPR’2018 [23]</td><td>49.8</td><td>39.0</td><td>53.0</td><td>28.9</td><td>35.7</td><td>45.2</td><td>45.4</td><td>30.9</td><td>41.0</td></tr><tr><td>GPA-CVPR’2020 [54]</td><td>45.7</td><td>38.7</td><td>54.1</td><td>32.4</td><td>32.9</td><td>46.7</td><td>41.1</td><td>24.7</td><td>39.5</td></tr><tr><td>RPN-PR-CVPR’2021 [53]</td><td>43.6</td><td>36.8</td><td>50.5</td><td>29.7</td><td>33.3</td><td>45.6</td><td>42.0</td><td>30.4</td><td>39.0</td></tr><tr><td>UaDAN-TMM’2021 [26</td><td>49.4</td><td>38.9</td><td>53.6</td><td>32.3</td><td>36.5</td><td>46.1</td><td>42.7</td><td>28.9</td><td>41.1</td></tr><tr><td>HTCN-CVPR’2020 [71]</td><td>47.4</td><td>37.1</td><td>47.9</td><td>32.3</td><td>33.2</td><td>47.5</td><td>40.9</td><td>31.6</td><td>39.8</td></tr><tr><td>SAPN-ECCV’2020 [72]</td><td>46.8</td><td>40.7</td><td>59.8</td><td>30.4</td><td>40.8</td><td>46.7</td><td>37.5</td><td>24.3</td><td>40.9</td></tr><tr><td>MeGA-CDA-CVPR’2021 [73]</td><td>49.2</td><td>39.0</td><td>52.4</td><td>34.5</td><td>37.7</td><td>49.0</td><td>46.9</td><td>25.4</td><td>41.8</td></tr><tr><td>UMT-CVPR2021 [74]</td><td>56.6</td><td>37.3</td><td>48.6</td><td>30.4</td><td>33.0</td><td>46.7</td><td>46.8</td><td>34.1</td><td>41.7</td></tr><tr><td>SCAN-AAAI’2022 [75]</td><td>48.6</td><td>37.3</td><td>57.3</td><td>31.0</td><td>41.7</td><td>43.9</td><td>48.7</td><td>28.7</td><td>42.1</td></tr><tr><td>ParaUDA-TITS’2022 T6</td><td>48.3</td><td>37.6</td><td>52.5</td><td>33.5</td><td>36.7</td><td>46.7</td><td>45.9</td><td>32.3</td><td>41.7</td></tr><tr><td>ConfMix-WACV’2023 177</td><td>45.8</td><td>33.5</td><td>62.6</td><td>28.6</td><td>45.0</td><td>43.4</td><td>40.0</td><td>27.3</td><td>40.8</td></tr><tr><td>SDAYOLO-TIV’2023 [78]</td><td>40.5</td><td>37.3</td><td>61.9</td><td>24.4</td><td>42.6</td><td>42.1</td><td>39.5</td><td>23.5</td><td>39.0</td></tr><tr><td>MS-DAYOLO-TIP’2023 [79]</td><td>51.0</td><td>36.0</td><td>56.5</td><td>27.5</td><td>39.6</td><td>46.5</td><td>45.9</td><td>28.9</td><td>41.5</td></tr><tr><td>Ours w/o Auxiliary Domain</td><td>48.4</td><td>36.7</td><td>53.5</td><td>26.1</td><td>36.1</td><td>45.9</td><td>39.1</td><td>29.3</td><td>40.2</td></tr><tr><td>Ours</td><td>51.2</td><td>39.1</td><td>54.3</td><td>31.6</td><td>36.5</td><td>46.7</td><td>48.7</td><td>30.3</td><td>42.3</td></tr><tr><td>Ours+</td><td>48.7</td><td>41.6</td><td>55.8</td><td>33.3</td><td>36.5</td><td>49.1</td><td>51.3</td><td>30.0</td><td>43.4</td></tr><tr><td>Oracle</td><td>49.9</td><td>45.8</td><td>65.2</td><td>39.6</td><td>46.5</td><td>51.3</td><td>34.2</td><td>32.6</td><td>45.6</td></tr></table>

TABLE II

Adaptation from Clear to Rainy: Cityscapes $\rightarrow$ Rainy Cityscapes experiment. Note that Oracle represents the Faster R-CNN trained on rainy Cityscapes training set with all labels. The best performance is bold and the second best is underlined.

<table><tr><td>Methodologies</td><td>${C}_{bus}$</td><td>${C}_{\text{bicycle }}$</td><td>${C}_{car}$</td><td>${C}_{\text{mcycle }}$</td><td>Cperson</td><td>${C}_{rider}$</td><td>${C}_{train}$</td><td>${C}_{truck}$</td><td>mAP</td></tr><tr><td>Faster R-CNN (source only)</td><td>46.3</td><td>26.0</td><td>54.8</td><td>25.8</td><td>34.7</td><td>35.9</td><td>26.9</td><td>23.9</td><td>34.3</td></tr><tr><td>DA-Faster-CVPR’2018 [23]</td><td>54.6</td><td>33.8</td><td>59.6</td><td>32.4</td><td>38.2</td><td>41.6</td><td>42.9</td><td>33.8</td><td>42.1</td></tr><tr><td>MS-DAYOLO-TIP’2023 [79]</td><td>60.3</td><td>34.4</td><td>67.7</td><td>31.9</td><td>47.2</td><td>47.4</td><td>31.9</td><td>30.7</td><td>44.0</td></tr><tr><td>Ours w/o Auxiliary Domain</td><td>55.5</td><td>35.3</td><td>60.0</td><td>32.8</td><td>38.3</td><td>22.1</td><td>49.3</td><td>33.1</td><td>43.4</td></tr><tr><td>Ours</td><td>60.0</td><td>35.3</td><td>60.6</td><td>33.8</td><td>38.8</td><td>42.9</td><td>52.4</td><td>36.3</td><td>45.0</td></tr><tr><td>Ours+</td><td>59.7</td><td>39.0</td><td>$\underline{61.7}$</td><td>34.4</td><td>40.2</td><td>47.0</td><td>47.2</td><td>38.8</td><td>46.0</td></tr><tr><td>Oracle</td><td>58.5</td><td>35.3</td><td>66.9</td><td>35.7</td><td>47.5</td><td>50.9</td><td>37.4</td><td>40.5</td><td>46.6</td></tr></table>

![bo_d282pqf7aajc738orlug_6_138_1485_746_370_0.jpg](images/bo_d282pqf7aajc738orlug_6_138_1485_746_370_0.jpg)

Fig. 6. Sample visualization results for the Foggy Cityscapes and Rainy Cityscapes validation sets with different intensity levels.

TABLE III

ABLATION STUDY OF COMPONENTS ON THE EXPERIMENTS OF CITYSCAPES $\rightarrow$ FOGGY CITYSCAPES AND CITYSCAPES $\rightarrow$ RAINY CITYSCAPES.

<table><tr><td>Methods</td><td>Img</td><td>Obj</td><td>AdvGRL</td><td>Reg</td><td>DMP</td><td>Foggy mAP</td><td>Rainy mAP</td></tr><tr><td>Source only</td><td/><td/><td/><td/><td/><td>23.41</td><td>34.35</td></tr><tr><td>w/ DMP</td><td/><td/><td/><td/><td>✓</td><td>24.54</td><td>35.90</td></tr><tr><td>img w/ GRL</td><td>✓</td><td/><td/><td/><td/><td>38.10</td><td>36.41</td></tr><tr><td>obj w/ GRL</td><td/><td>✓</td><td/><td/><td/><td>38.02</td><td>37.92</td></tr><tr><td>img+obj w/ GRL (Baseline)</td><td>✓</td><td>✓</td><td/><td/><td/><td>38.43</td><td>41.02</td></tr><tr><td>img+obj w/AdvGRL</td><td>✓</td><td>✓</td><td>✓</td><td/><td/><td>40.23</td><td>43.44</td></tr><tr><td>img+obj+ Reg w/ GRL</td><td>✓</td><td>✓</td><td/><td>✓</td><td/><td>41.97</td><td>44.44</td></tr><tr><td>img+obj+Reg w/ AdvGRL</td><td>✓</td><td>✓</td><td>✓</td><td>✓</td><td/><td>42.34</td><td>45.07</td></tr><tr><td>img+obj+Reg+DMP w/ AdvGRL</td><td>✓</td><td>✓</td><td>✓</td><td>✓</td><td>✓</td><td>43.42</td><td>46.04</td></tr></table>

## D. Adaptation from Clear to Rainy

In the Clear to Rainy adaptation, the only difference during training is the exchange of domains, where the unlabelled Rainy Cityscapes training set serves as the target domain, while the Foggy Cityscapes training set is used as the auxiliary domain. Table II presents the results of domain adaptation from clear to rainy weather. Due to the page limit, we choose the methods with the publicly available source code which perform very well in the Clear to Foggy Adaptation experiment as the comparison methods in this Clear to Rainy Adaptation experiment, i.e., DA-Faster [23], MS-DAYOLO [79]. Similar to the Clear to Foggy Adaptation, our proposed DA+ method got the best overall mAP (46.0%) detection performance on Rainy Cityscapes compared to the comparison methods.

![bo_d282pqf7aajc738orlug_7_158_155_723_491_0.jpg](images/bo_d282pqf7aajc738orlug_7_158_155_723_491_0.jpg)

Fig. 7. Visualization of the qualitative detection on Foggy/Rainy Cityscapes (validation sets). First column (Source only): original Faster R-CNN w/ DA, Second column (Baseline): Faster R-CNN with image-level and object-level adaptations w/ GRL, Third column: Proposed DA Method. Top: foggy weather, Bottom: rainy weather.

## E. Ablation Study of Components

We conduct an analysis of the individual proposed components of our DA object detection method. The experiments are conducted on the Cityscapes $\rightarrow$ Foggy Cityscapes and Cityscapes $\rightarrow$ Rainy Cityscapes tasks, using the ResNet- 50 backbone. The results of the ablation study are presented in Table III. In the first row of the table, image-level and object-level adaptation modules are labels as 'img' and 'obj', respectively. 'AdvGRL' and 'Reg' indicate the proposed Adversarial GRL and domain-level metric regularization, respectively. The 'img+obj+GRL' configuration represents the Baseline model used in our experiments. We also evaluate two additional configurations: 'img+obj+AdvGRL' and 'img+obj+AdvGRL+Reg'. Additionally, we include the 'Source only' configuration, which refers to the Faster R-CNN model trained solely on labeled source domain images without any DA methods. The ablation study presented in Table III provides clear evidence of the positive impact of each proposed component in the DA method for both foggy and rainy weather scenarios. Furthermore, we provide qualitative visualization of the object detection results in Fig. 7.

## F. Adaptation of Different-intensity Fog and Rain

Moreover, both simulated Foggy and Rainy Cityscapes datasets contain three levels of intensity, namely Small, Medium, and Large as depicted in Fig. 6 Following the previous works [23], [26], [54], we only utilize the Large intensity level as the target domain during training for both fog and rain. After training, the trained models on the validation set of Rainy Cityscapes and Foggy Cityscapes with images of different intensity levels are evaluated. For the three intensity levels of fog and rain, as shown in Table IV, the 'Baseline' model after domain adaptation could get better detection performance compared to the 'Source only' without DA, while the Proposed Method could continue to further improve the performance compared to the 'Baseline' method. Alternatively, our proposed DA method could significantly mitigate the impact of fog and rain under Small, Medium, and Large intensity levels.

## G. Adaptation of Cross Cameras

We conducted an experiment specifically targeting real-world cross-camera adaptation for different autonomous driving datasets with varying camera settings. We applied our DA method for cross-camera adaptation i.e., Cityscapes dataset (source) $\rightarrow$ KITTI dataset (target). To accommodate the unaligned nature of the datasets, we simply removed the ${L}_{obj}^{R}$ term (Eq. 8) during the adaptation process. Following the previous work [23], we used the KITTI training set, consisting of 7,481 images as the target domain. Specifically, we evaluated the AP of the Car category on the target domain. Table V demonstrated the outstanding performance of our proposed DA+ method compared to recent comparison methods.

## H. Feature Distribution Visualization via Adaptation

To investigate the capability of our proposed DA method to overcome the domain shift (clear weather $\rightarrow$ rainy/foggy weather), we visualize these domain feature distributions by utilizing t-SNE [80] before and after the domain adaptation in foggy and rainy weather. Fig. 8 obviously presents that our proposed DA method could align the feature distributions to bridge the domain gap (clear weather $\rightarrow$ rainy/foggy weather).

## I. Experiments on Different Parameters

We analyze the detection performance on different hyper-parameters in Section III, i.e, Eq 9 and Eq 5 for the Cityscapes $\rightarrow$ Foggy Cityscapes case, and several hyper-parameters were investigated. First of all, ${mA}{P}_{\gamma }$ can be obtained ${mA}{P}_{0.1} = {42.34},{mA}{P}_{0.01} = {41.30},{mA}{P}_{0.001} =$ 41.19, where $\gamma$ represents loss balance weight in Eq. 9 Then, in the AdvGRL (Eq. 5), the $\left( {\alpha ,\beta }\right)$ , where $\beta$ represents the overflow threshold and $\alpha$ represents hardness threshold are set as (a)(0.63,30), (b)(0.63,10), (c)(0.54,30), and (d) (0.54,10), where $\alpha  = {0.54}$ is obtained by averaging the values of Eq. 1 when ${P}_{i} = {0.9},{G}_{i} = 1$ and ${P}_{i} = {0.1},{G}_{i} = 0$ . The corresponding detection mAP(s) are (a) 42.34, (b) 38.83, (c) 39.38, (d) 40.47, respectively.

## J. Visualization of Hard Examples

By utilizing ${\lambda }_{adv}$ of the proposed AdvGRL, we can identify hard examples during the domain adaptation process. Fig 9 illustrates some of these hard examples. We compute the ${L}_{1}$ distance between the features ${F}_{i}^{S}$ and ${F}_{i}^{T}$ obtained from the backbone of Fig 2. This distance is used as an approximation of the example’s hardness ( ${ah}$ ), where a smaller ${ah}$ indicates a harder example for transfer learning. Intuitively, when the fog covers a larger number of objects, as illustrated by the bounding-box regions in Fig. 9, the task becomes more challenging.

![bo_d282pqf7aajc738orlug_8_145_168_1508_400_0.jpg](images/bo_d282pqf7aajc738orlug_8_145_168_1508_400_0.jpg)

Fig. 8. Feature distribution visualization by t-SNE [80] before and after domain adaptation. Clear to Foggy Adaptation: (a) original distribution before adaptation, (b) aligned distribution after the proposed adaptation. Clear to Rainy Adaptation: (c) original distribution before adaptation, (d) aligned distribution after the proposed adaptation. It is recommended to view this figure in color.

TABLE IV

Adaptation of Different-intensity Fog and Rain: Cityscapes $\rightarrow$ Foggy Cityscapes and Cityscapes $\rightarrow$ Rainy Cityscapes $\rightarrow$ Rainy Cityscapes experiments.

<table><tr><td>Foggy / Rainy</td><td>Methodologies</td><td>${C}_{bus}$</td><td>${C}_{\text{bicycle }}$</td><td>${C}_{car}$</td><td>${C}_{\text{mcycle }}$</td><td>${C}_{\text{person }}$</td><td>${C}_{\text{rider }}$</td><td>${C}_{train}$</td><td>${C}_{truck}$</td><td>mAP</td></tr><tr><td rowspan="3">Large</td><td>Source only</td><td>27.1 / 46.3</td><td>${28.3}/{26.0}$</td><td>${32.8}/{54.8}$</td><td>${18.4}/{25.8}$</td><td>28.6 / 34.7</td><td>${32.2}/{35.9}$</td><td>${4.9}/{26.9}$</td><td>${14.7}/{23.9}$</td><td>${23.4}/{34.3}$</td></tr><tr><td>Baseline</td><td>45.4 / 49.5</td><td>36.7 / 32.6</td><td>${53.5}/{58.3}$</td><td>26.0 / 31.4</td><td>36.1 / 36.1</td><td>45.9 / 41.4</td><td>37.1 / 43.4</td><td>26.3 / 35.1</td><td>${38.4}/{41.0}$</td></tr><tr><td>Proposed DA Method</td><td>$\mathbf{{51.2}/{60.0}}$</td><td>39.1 / 35.3</td><td>$\mathbf{{54.3}/{60.6}}$</td><td>31.6 / 33.8</td><td>36.5 / 38.8</td><td>$\mathbf{{46.7}/{42.9}}$</td><td>$\mathbf{{48.7}/{52.4}}$</td><td>$\mathbf{{30.3}/{36.3}}$</td><td>$\mathbf{{42.3}/{45.0}}$</td></tr><tr><td rowspan="3">Medium</td><td>Source only</td><td>40.6 / 47.1</td><td>${36.9}/{26.9}$</td><td>${48.9}/{54.6}$</td><td>27.3 / 23.9</td><td>37.9 / 34.0</td><td>${43.2}/{38.6}$</td><td>40.4 / 30.8</td><td>${22.4}/{30.7}$</td><td>${37.2}/{35.8}$</td></tr><tr><td>Baseline</td><td>52.0 / 47.3</td><td>40.5 / 33.3</td><td>${58.9}/{58.2}$</td><td>31.7 / 27.9</td><td>${40.8}/{35.8}$</td><td>$\mathbf{{50.0}}/{44.3}$</td><td>39.8 / 35.1</td><td>29.9 / 36.4</td><td>42.9 / 39.8</td></tr><tr><td>Proposed DA Method</td><td>${52.6}/{58.8}$</td><td>42.6 / 37.1</td><td>$\mathbf{{59.3}/{60.0}}$</td><td>$\mathbf{{32.1}/{30.9}}$</td><td>41.2 / 38.6</td><td>47.5 / 45.1</td><td>48.8 / 41.0</td><td>32.5 / 39.7</td><td>44.6 / 43.9</td></tr><tr><td rowspan="3">Small</td><td>Source only</td><td>${49.2}/{43.8}$</td><td>${40.9}/{29.6}$</td><td>${55.7}/{55.7}$</td><td>${33.1}/{24.1}$</td><td>${41.0}/{35.7}$</td><td>47.0 / 37.5</td><td>${43.1}/{38.7}$</td><td>${28.4}/{23.3}$</td><td>42.3 / 36.0</td></tr><tr><td>Baseline</td><td>$\mathbf{{54.1}}/{42.9}$</td><td>${40.6}/{34.5}$</td><td>60.3 / 59.0</td><td>${32.5}/{30.7}$</td><td>42.0 / 36.7</td><td>$\mathbf{{51.0}/{43.7}}$</td><td>49.3 / 48.1</td><td>${31.9}/\mathbf{{36.1}}$</td><td>45.2 / 41.5</td></tr><tr><td>Proposed DA Method</td><td>${52.9}/\mathbf{{53.6}}$</td><td>43.1 / 38.3</td><td>$\mathbf{{60.6}/{61.3}}$</td><td>36.3 / 33.6</td><td>$\mathbf{{42.7}/{39.4}}$</td><td>${49.4}/{42.8}$</td><td>54.8 / 51.4</td><td>36.5 / 35.7</td><td>47.0 / 44.5</td></tr></table>

TABLE V

ADAPTATION OF CROSS CAMERAS ON CITYSCAPES $\rightarrow$ KITTI EXPERIMENT.

<table><tr><td>Methodologies</td><td>Car AP</td></tr><tr><td>MAF-ICCV’2019 [55]</td><td>72.10</td></tr><tr><td>SWDA-CVPR’2019 J50</td><td>71.00</td></tr><tr><td>ATF-ECCV’2020 [81]</td><td>73.50</td></tr><tr><td>ART-CVPR’2020</td><td>73.60</td></tr><tr><td>GPA-CVPR’2020</td><td>65.36</td></tr><tr><td>SGA-TMM’2021</td><td>72.02</td></tr><tr><td>UIT-ESwA’2022 [83]</td><td>73.70</td></tr><tr><td>ParaUDA-TITS’2022 [76]</td><td>72.20</td></tr><tr><td>IDF-TCSVT’2023 [84]</td><td>74.00</td></tr><tr><td>Ours</td><td>74.38</td></tr><tr><td>Ours+</td><td>74.71</td></tr></table>

## K. Experiments on Pre-trained Models and Domain Random- ization

Pre-trained Models: In the experiment of Cityscapes $\rightarrow$ Foggy Cityscapes, our proposed DA method utilizes a pre-trained Faster R-CNN as an initialization and achieves a detection mean Average Precision (mAP) of 41.3, compared to a mAP of 42.3 achieved when our method is initialized without the pre-trained deep learning model.

![bo_d282pqf7aajc738orlug_8_909_1140_747_389_0.jpg](images/bo_d282pqf7aajc738orlug_8_909_1140_747_389_0.jpg)

Fig. 9. Visualization of hard examples mined by AdvGRL. Two mined hard examples and one easy example are shown from left to right.

Domain Randomization: In the Cityscapes $\rightarrow$ Foggy Cityscapes experiment, we explore two approaches for domain randomization to reduce the domain shift between the source and target domains. 1) The first approach involves regular data augmentation techniques such as color change, blurring, and salt $\&$ pepper noises to construct the auxiliary domain. When our method is trained using this auxiliary domain, the detection mean Average Precision (mAP) achieved is 38.7, compared to our method's performance of 42.3 when using the auxiliary domain dataset i.e. rain synthesis Cityscapes dataset. 2) The second approach utilizes CycleGAN [85] to facilitate the transfer of image style between the Cityscapes training set and the Foggy Cityscapes training set. We trained a Faster R-CNN with these generated images, which got ${32.8}\mathrm{{mAP}}$ . These findings emphasize the limitations of commonly employed domain randomization techniques in effectively addressing the DA challenge.

## V. CONCLUSIONS

In this paper, a novel domain adaptive object detection framework is presented, which is specifically designed for intelligent vehicle perception in foggy and rainy weather conditions. The framework incorporates both image-level and object-level adaptations to address the domain shift in global image style and local object appearance. An adversarial GRL is introduced for adversarial mining of hard examples during domain adaptation. Additionally, a domain-level metric regularization is proposed to enforce feature metric distance between the source, target, and auxiliary domains. The proposed method is evaluated through transfer learning experiments from Cityscapes to Foggy Cityscapes, Rainy Cityscapes, and KITTI. The experimental results demonstrate the effectiveness of the proposed DA method in improving object detection performance. This research contributes significantly to enhancing intelligent vehicle perception in challenging foggy and rainy weather scenarios. REFERENCES

[1] J. Li, R. Xu, J. Ma, Q. Zou, J. Ma, and H. Yu, "Domain adaptive object detection for autonomous driving under foggy weather," in IEEE/CVF Winter Conference on Applications of Computer Vision, 2023, pp. 612- 622.

[2] L. Chen, Y. Li, C. Huang, B. Li, Y. Xing, D. Tian, L. Li, Z. Hu, X. Na, Z. Li, S. Teng, C. Lv, J. Wang, D. Cao, N. Zheng, and F.-Y. Wang, "Milestones in autonomous driving and intelligent vehicles: Survey of surveys," IEEE Transactions on Intelligent Vehicles, vol. 8, no. 2, pp. 1046-1056, 2023.

[3] L. Chen, Y. Zhang, B. Tian, Y. Ai, D. Cao, and F.-Y. Wang, "Parallel driving os: A ubiquitous operating system for autonomous driving in cpss," IEEE Transactions on Intelligent Vehicles, vol. 7, no. 4, pp. 886- 895, 2022.

[4] J. Nie, J. Yan, H. Yin, L. Ren, and Q. Meng, "A multimodality fusion deep neural network and safety test strategy for intelligent vehicles," IEEE transactions on intelligent vehicles, vol. 6, no. 2, pp. 310-322, 2020.

[5] M. Parseh, F. Asplund, L. Svensson, W. Sinz, E. Tomasch, and M. Törngren, "A data-driven method towards minimizing collision severity for highly automated vehicles," IEEE Transactions on Intelligent Vehicles, vol. 6, no. 4, pp. 723-735, 2021.

[6] R. Ke, Z. Cui, Y. Chen, M. Zhu, H. Yang, Y. Zhuang, and Y. Wang, "Lightweight edge intelligence empowered near-crash detection towards real-time vehicle event logging," IEEE Transactions on Intelligent Vehicles, vol. 8, no. 4, pp. 2737-2747, 2023.

[7] Y. Zhang, C. Wang, R. Yu, L. Wang, W. Quan, Y. Gao, and P. Li, "The ad4che dataset and its application in typical congestion scenarios of traffic jam pilot systems," IEEE Transactions on Intelligent Vehicles, vol. 8, no. 5, pp. 3312-3323, 2023.

[8] Y. Gao, J. Li, Z. Xu, Z. Liu, X. Zhao, and J. Chen, "A novel image-based convolutional neural network approach for traffic congestion estimation," Expert Systems with Applications, vol. 180, p. 115037, 2021.

[9] M. Singh and R. K. Dubey, "Deep learning model based co2 emissions prediction using vehicle telematics sensors data," IEEE Transactions on Intelligent Vehicles, vol. 8, no. 1, pp. 768-777, 2023.

[10] W. Hong, I. Chakraborty, H. Wang, and G. Tao, "Co-optimization scheme for the powertrain and exhaust emission control system of hybrid electric vehicles using future speed prediction," IEEE Transactions on Intelligent Vehicles, vol. 6, no. 3, pp. 533-545, 2021.

[11] X. Wang, K. Tang, X. Dai, J. Xu, J. Xi, R. Ai, Y. Wang, W. Gu, and C. Sun, "Safety-balanced driving-style aware trajectory planning in intersection scenarios with uncertain environment," IEEE Transactions on Intelligent Vehicles, vol. 8, no. 4, pp. 2888-2898, 2023.

[12] Q. Lan and Q. Tian, "Instance, scale, and teacher adaptive knowledge distillation for visual detection in autonomous driving," IEEE Transactions on Intelligent Vehicles, pp. 1-14, 2022.

[13] Z. Ding and H. Zhao, "Incorporating driving knowledge in deep learning based vehicle trajectory prediction: A survey," IEEE Transactions on Intelligent Vehicles, vol. 8, no. 8, pp. 3996-4015, 2023.

[14] L. Wang, X. Zhang, Z. Song, J. Bi, G. Zhang, H. Wei, L. Tang, L. Yang, J. Li, C. Jia, and L. Zhao, "Multi-modal 3d object detection in autonomous driving: A survey and taxonomy," IEEE Transactions on Intelligent Vehicles, vol. 8, no. 7, pp. 3781-3798, 2023.

[15] K. Strandberg, N. Nowdehi, and T. Olovsson, "A systematic literature review on automotive digital forensics: Challenges, technical solutions and data collection," IEEE Transactions on Intelligent Vehicles, vol. 8, no. 2, pp. 1350-1367, 2023.

[16] R. Xu, H. Xiang, X. Han, X. Xia, Z. Meng, C.-J. Chen, C. Correa-Jullian, and J. Ma, "The opencda open-source ecosystem for cooperative driving automation research," IEEE Transactions on Intelligent Vehicles, vol. 8, no. 4, pp. 2698-2711, 2023.

[17] R. Xu, Y. Guo, X. Han, X. Xia, H. Xiang, and J. Ma, "Opencda: an open cooperative driving automation framework integrated with co-simulation," in IEEE International Intelligent Transportation Systems Conference. IEEE, 2021, pp. 1155-1162.

[18] S. Ren, K. He, R. Girshick, and J. Sun, "Faster r-cnn: Towards real-time object detection with region proposal networks," Advances in Neural Information Processing Systems, vol. 28, 2015.

[19] K. He, G. Gkioxari, P. Dollár, and R. Girshick, "Mask r-cnn," in Proceedings of the IEEE international conference on computer vision, 2017, pp. 2961-2969.

[20] A. Bochkovskiy, C.-Y. Wang, and H.-Y. M. Liao, "Yolov4: Optimal speed and accuracy of object detection," arXiv preprint arXiv:2004.10934, 2020.

[21] M. Cordts, M. Omran, S. Ramos, T. Rehfeld, M. Enzweiler, R. Benenson, U. Franke, S. Roth, and B. Schiele, "The cityscapes dataset for semantic urban scene understanding," in IEEE Conference on Computer Vision and Pattern Recognition, 2016, pp. 3213-3223.

[22] C. Sakaridis, D. Dai, and L. Van Gool, "Semantic foggy scene understanding with synthetic data," International Journal of Computer Vision, vol. 126, no. 9, pp. 973-992, 2018.

[23] Y. Chen, W. Li, C. Sakaridis, D. Dai, and L. Van Gool, "Domain adaptive faster r-cnn for object detection in the wild," in IEEE Conference on Computer Vision and Pattern Recognition, 2018, pp. 3339-3348.

[24] S. Song, H. Yu, Z. Miao, J. Fang, K. Zheng, C. Ma, and S. Wang, "Multi-spectral salient object detection by adversarial domain adaptation," in AAAI Conference on Artificial Intelligence, vol. 34, no. 07, 2020, pp. 12023-12030.

[25] J. Li, Z. Xu, L. Fu, X. Zhou, and H. Yu, "Domain adaptation from daytime to nighttime: A situation-sensitive vehicle detection and traffic flow parameter estimation framework," Transportation Research Part $C$ : Emerging Technologies, 2021.

[26] D. Guan, J. Huang, A. Xiao, S. Lu, and Y. Cao, "Uncertainty-aware unsupervised domain adaptation in object detection," IEEE Transactions on Multimedia, vol. 24, pp. 2502-2514, 2022.

[27] L. Fu, H. Yu, F. Juefei-Xu, J. Li, Q. Guo, and S. Wang, "Let there be light: Improved traffic surveillance via detail preserving night-today transfer," IEEE Transactions on Circuits and Systems for Video Technology, vol. 32, no. 12, pp. 8217-8226, 2022.

[28] Y. Zheng, D. Huang, S. Liu, and Y. Wang, "Cross-domain object detection through coarse-to-fine feature adaptation," in IEEE Conference on Computer Vision and Pattern Recognition, 2020, pp. 13766-13775.

[29] Z. Hu, S. Lou, Y. Xing, X. Wang, D. Cao, and C. Lv, "Review and perspectives on driver digital twin and its enabling technologies for intelligent vehicles," IEEE Transactions on Intelligent Vehicles, vol. 7, no. 3, pp. 417-440, 2022.

[30] J. Zhang, J. Pu, J. Xue, M. Yang, X. Xu, X. Wang, and F.-Y. Wang, "Hivegpt: Human-machine-augmented intelligent vehicles with generative pre-trained transformer," IEEE Transactions on Intelligent Vehicles, vol. 8, no. 3, pp. 2027-2033, 2023.

[31] E. Li, S. Wang, C. Li, D. Li, X. Wu, and Q. Hao, "Sustech points: A portable 3d point cloud interactive annotation platform system," in IEEE Intelligent Vehicles Symposium, 2020, pp. 1108-1115.

[32] R. Xu, F. Tafazzoli, L. Zhang, T. Rehfeld, G. Krehl, and A. Seal, "Holistic grid fusion based stop line estimation," in International Conference on Pattern Recognition. IEEE, 2021, pp. 8400-8407.

[33] J. Li, R. Xu, X. Liu, J. Ma, Z. Chi, J. Ma, and H. Yu, "Learning for vehicle-to-vehicle cooperative perception under lossy communication," IEEE Transactions on Intelligent Vehicles, vol. 8, no. 4, pp. 2650-2660, 2023.

[34] Y. Shan, W. F. Lu, and C. M. Chew, "Pixel and feature level based domain adaptation for object detection in autonomous driving," Neuro-computing, vol. 367, pp. 31-38, 2019.

[35] X. Zhao, P. Sun, Z. Xu, H. Min, and H. Yu, "Fusion of 3d lidar and camera data for object detection in autonomous vehicle applications," IEEE Sensors Journal, vol. 20, no. 9, pp. 4901-4913, 2020.

[36] J. Redmon, S. Divvala, R. Girshick, and A. Farhadi, "You only look once: Unified, real-time object detection," in IEEE Conference on Computer Vision and Pattern Recognition, 2016, pp. 779-788.

[37] W. Liu, D. Anguelov, D. Erhan, C. Szegedy, S. Reed, C.-Y. Fu, and A. C. Berg, "Ssd: Single shot multibox detector," in European Conference on Computer Vision. Springer, 2016, pp. 21-37.

[38] C. Chen, C. Wang, B. Liu, C. He, L. Cong, and S. Wan, "Edge intelligence empowered vehicle detection and image segmentation for autonomous vehicles," IEEE Transactions on Intelligent Transportation Systems, vol. 24, no. 11, pp. 13023-13034, 2023.

[39] J. E. Hoffmann, H. G. Tosso, M. M. D. Santos, J. F. Justo, A. W. Malik, and A. U. Rahman, "Real-time adaptive object detection and tracking for autonomous vehicles," IEEE Transactions on Intelligent Vehicles, vol. 6, no. 3, pp. 450-459, 2020.

[40] L. Chen, S. Lin, X. Lu, D. Cao, H. Wu, C. Guo, C. Liu, and F.-Y. Wang, "Deep neural network based vehicle and pedestrian detection for autonomous driving: A survey," IEEE Transactions on Intelligent Transportation Systems, vol. 22, no. 6, pp. 3234-3246, 2021.

[41] Y. Pang, J. Cao, Y. Li, J. Xie, H. Sun, and J. Gong, "Tju-dhd: A diverse high-resolution dataset for object detection," IEEE Transactions on Image Processing, vol. 30, no. 2, pp. 207-219, 2021.

[42] S.-C. Huang, T.-H. Le, and D.-W. Jaw, "Dsnet: Joint semantic learning for object detection in inclement weather conditions," IEEE Transactions on Pattern Analysis and Machine Intelligence, vol. 43, no. 8, pp. 2623- 2633, 2020.

[43] M. Hahner, C. Sakaridis, D. Dai, and L. Van Gool, "Fog simulation on real lidar point clouds for $3\mathrm{\;d}$ object detection in adverse weather," in IEEE International Conference on Computer Vision, 2021, pp. 15283- 15292.

[44] K. Qian, S. Zhu, X. Zhang, and L. E. Li, "Robust multimodal vehicle detection in foggy weather using complementary lidar and radar signals," in IEEE Conference on Computer Vision and Pattern Recognition, 2021, pp. 444-453.

[45] M. Bijelic, T. Gruber, F. Mannan, F. Kraus, W. Ritter, K. Dietmayer, and F. Heide, "Seeing through fog without seeing fog: Deep multimodal sensor fusion in unseen adverse weather," in IEEE Conference on Computer Vision and Pattern Recognition, 2020, pp. 11682-11692.

[46] V. A. Sindagi, P. Oza, R. Yasarla, and V. M. Patel, "Prior-based domain adaptive object detection for hazy and rainy conditions," in European Conference on Computer Vision. Springer, 2020, pp. 763-780.

[47] S.-C. Huang, Q.-V. Hoang, and T.-H. Le, "Sfa-net: A selective features absorption network for object detection in rainy weather conditions," IEEE Transactions on Neural Networks and Learning Systems, vol. 34, no. 8, pp. 5122-5132, 2023.

[48] M. Hnewa and H. Radha, "Object detection under rainy conditions for autonomous vehicles: A review of state-of-the-art and emerging techniques," IEEE Signal Processing Magazine, vol. 38, no. 1, pp. 53- 67, 2020.

[49] T. Kim, M. Jeong, S. Kim, S. Choi, and C. Kim, "Diversify and match: A domain adaptive representation learning paradigm for object detection," in IEEE Conference on Computer Vision and Pattern Recognition, 2019, pp. 12456-12465.

[50] K. Saito, Y. Ushiku, T. Harada, and K. Saenko, "Strong-weak distribution alignment for adaptive object detection," in IEEE Conference on Computer Vision and Pattern Recognition, 2019, pp. 6956-6965.

[51] Z. Zhao, Y. Guo, H. Shen, and J. Ye, "Adaptive object detection with dual multi-label prediction," in European Conference on Computer Vision. Springer, 2020, pp. 54-69.

[52] Q. Xu, Y. Zhou, W. Wang, C. R. Qi, and D. Anguelov, "Spg: Unsupervised domain adaptation for $3\mathrm{\;d}$ object detection via semantic point generation," in IEEE International Conference on Computer Vision, 2021, pp. 15446-15456.

[53] Y. Zhang, Z. Wang, and Y. Mao, "Rpn prototype alignment for domain adaptive object detector," in IEEE Conference on Computer Vision and Pattern Recognition, 2021, pp. 12425-12434.

[54] M. Xu, H. Wang, B. Ni, Q. Tian, and W. Zhang, "Cross-domain detection via graph-induced prototype alignment," in IEEE Conference on Computer Vision and Pattern Recognition, 2020, pp. 12355-12364.

[55] Z. He and L. Zhang, "Multi-adversarial faster-rcnn for unrestricted object detection," in IEEE International Conference on Computer Vision, 2019, pp. 6668-6677.

[56] H.-K. Hsu, C.-H. Yao, Y.-H. Tsai, W.-C. Hung, H.-Y. Tseng, M. Singh, and M.-H. Yang, "Progressive domain adaptation for object detection," in IEEE Winter Conference on Applications of Computer Vision, 2020, pp. 749-757.

[57] M. Schutera, M. Hussein, J. Abhau, R. Mikut, and M. Reischl, "Night-to-day: Online image-to-image translation for object detection within autonomous driving by night," IEEE Transactions on Intelligent Vehicles, vol. 6, no. 3, pp. 480-489, 2020.

[58] W. Zhou, D. Du, L. Zhang, T. Luo, and Y. Wu, "Multi-granularity alignment domain adaptation for object detection," in Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition, 2022, pp. 9581-9590.

[59] W. Li, X. Liu, and Y. Yuan, "Sigma: Semantic-complete graph matching for domain adaptive object detection," in IEEE Conference on Computer Vision and Pattern Recognition, 2022, pp. 5291-5300.

[60] M. Chen, W. Chen, S. Yang, J. Song, X. Wang, L. Zhang, Y. Yan, D. Qi, Y. Zhuang, D. Xie et al., "Learning domain adaptive object detection with probabilistic teacher," in International Conference on Machine Learning. PMLR, 2022, pp. 3040-3055.

[61] J. Wang, T. Shen, Y. Tian, Y. Wang, C. Gou, X. Wang, F. Yao, and C. Sun, "A parallel teacher for synthetic-to-real domain adaptation of traffic object detection," IEEE Transactions on Intelligent Vehicles, vol. 7, no. 3, pp. 441-455, 2022.

[62] L. Hoyer, D. Dai, H. Wang, and L. Van Gool, "Mic: Masked image consistency for context-enhanced domain adaptation," in Proceedings of the IEEE/CVF conference on computer vision and pattern recognition, 2023, pp. 11721-11732.

[63] L. Hoyer, M. Munoz, P. Katiyar, A. Khoreva, and V. Fischer, "Grid saliency for context explanations of semantic segmentation," Advances in neural information processing systems, vol. 32, 2019.

[64] Z. Xie, Z. Zhang, Y. Cao, Y. Lin, J. Bao, Z. Yao, Q. Dai, and H. Hu, "Simmim: A simple framework for masked image modeling," in Proceedings of the IEEE/CVF conference on computer vision and pattern recognition, 2022, pp. 9653-9663.

[65] N. Srivastava, G. Hinton, A. Krizhevsky, I. Sutskever, and R. Salakhut-dinov, "Dropout: a simple way to prevent neural networks from over-fitting," The journal of machine learning research, vol. 15, no. 1, pp. 1929-1958, 2014.

[66] Y. Ganin and V. Lempitsky, "Unsupervised domain adaptation by backpropagation," in International Conference on Machine Learning. PMLR, 2015, pp. 1180-1189.

[67] Q. Guo, J. Sun, F. Juefei-Xu, L. Ma, X. Xie, W. Feng, Y. Liu, and J. Zhao, "Efficientderain: Learning pixel-wise dilation filtering for high-efficiency single-image deraining," in AAAI Conference on Artificial Intelligence, vol. 35, no. 2, 2021, pp. 1487-1495.

[68] D. Hendrycks, N. Mu, E. D. Cubuk, B. Zoph, J. Gilmer, and B. Lak-shminarayanan, "AugMix: A simple data processing method to improve robustness and uncertainty," International Conference on Learning Representations, 2020.

[69] K. Garg and S. K. Nayar, "Photorealistic rendering of rain streaks," ACM Transactions on Graphics, vol. 25, no. 3, pp. 996-1002, 2006.

[70] Q. Cai, Y. Pan, C.-W. Ngo, X. Tian, L. Duan, and T. Yao, "Exploring object relation in mean teacher for cross-domain detection," in IEEE Conference on Computer Vision and Pattern Recognition, 2019, pp. 11457-11466.

[71] C. Chen, Z. Zheng, X. Ding, Y. Huang, and Q. Dou, "Harmonizing transferability and discriminability for adapting object detectors," in IEEE Conference on Computer Vision and Pattern Recognition, 2020, pp. 8869-8878.

[72] C. Li, D. Du, L. Zhang, L. Wen, T. Luo, Y. Wu, and P. Zhu, "Spatial attention pyramid network for unsupervised domain adaptation," in European Conference on Computer Vision. Springer, 2020, pp. 481- 497.

[73] V. Vibashan, V. Gupta, P. Oza, V. A. Sindagi, and V. M. Patel, "Mega-cda: Memory guided attention for category-aware unsupervised domain adaptive object detection," in IEEE Conference on Computer Vision and Pattern Recognition (CVPR). IEEE, 2021, pp. 4514-4524.

[74] J. Deng, W. Li, Y. Chen, and L. Duan, "Unbiased mean teacher for cross-domain object detection," in IEEE Conference on Computer Vision and Pattern Recognition, 2021, pp. 4091-4101.

[75] W. Li, X. Liu, X. Yao, and Y. Yuan, "Scan: Cross domain object detection with semantic conditioned adaptation," in AAAI Conference on Artificial Intelligence, vol. 36, no. 2, 2022, pp. 1421-1428.

[76] W. Zhang, J. Wang, Y. Wang, and F.-Y. Wang, "Parauda: Invariant feature learning with auxiliary synthetic samples for unsupervised domain adaptation," IEEE Transactions on Intelligent Transportation Systems, vol. 23, no. 11, pp. 20217-20229, 2022.

[77] G. Mattolin, L. Zanella, E. Ricci, and Y. Wang, "Confmix: Unsupervised domain adaptation for object detection via confidence-based mixing," in IEEE Winter Conference on Applications of Computer Vision, 2023, pp. 423-433.

[78] G. Li, Z. Ji, X. Qu, R. Zhou, and D. Cao, "Cross-domain object detection for autonomous driving: A stepwise domain adaptative yolo approach," IEEE Transactions on Intelligent Vehicles, vol. 7, no. 3, pp. 603-615, 2022.

[79] M. Hnewa and H. Radha, "Integrated multiscale domain adaptive yolo," IEEE Transactions on Image Processing, vol. 32, no. 2, pp. 1857-1867, 2023.

[80] L. Van der Maaten and G. Hinton, "Visualizing data using t-sne." Journal of machine learning research, vol. 9, no. 11, 2008.

[81] Z. He and L. Zhang, "Domain adaptive object detection via asymmetric tri-way faster-rcnn," in European conference on computer vision. Springer, 2020, pp. 309-324.

[82] C. Zhang, Z. Li, J. Liu, P. Peng, Q. Ye, S. Lu, T. Huang, and Y. Tian, "Self-guided adaptation: Progressive representation alignment for domain adaptive object detection," IEEE Transactions on Multimedia, vol. 24, pp. 2246-2258, 2021.

[83] V. F. Arruda, R. F. Berriel, T. M. Paixão, C. Badue, A. F. De Souza, N. Sebe, and T. Oliveira-Santos, "Cross-domain object detection using unsupervised image translation," Expert Systems with Applications, vol. 192, p. 116334, 2022.

[84] Q. Lang, L. Zhang, W. Shi, W. Chen, and S. Pu, "Exploring implicit domain-invariant features for domain adaptive object detection," IEEE Transactions on Circuits and Systems for Video Technology, 2023.

[85] J.-Y. Zhu, T. Park, P. Isola, and A. A. Efros, "Unpaired image-to-image translation using cycle-consistent adversarial networks," in IEEE International Conference on Computer Vision, 2017, pp. 2223-2232.