# Logic Tensor Networks for Semantic Image Interpretation

# 用于语义图像解释的逻辑张量网络

Ivan Donadello

伊万·多纳代洛

Fondazione Bruno Kessler and

布鲁诺·凯斯勒基金会和

University of Trento

特伦托大学

Trento, Italy

意大利特伦托

donadello@fbk.eu

Luciano Serafini

卢西亚诺·塞拉菲尼

Fondazione Bruno Kessler

布鲁诺·凯斯勒基金会

Via Sommarive 18, I-38123

索马里韦路18号，I - 38123

Trento, Italy

意大利特伦托

serafini@fbk.eu

Artur d'Avila Garcez

阿图尔·达维拉·加尔塞斯

City, University of London

伦敦城市大学

Northampton Square

北安普顿广场

London EC1V 0HB, UK

英国伦敦EC1V 0HB

a.garcez@city.ac.uk

May 26, 2017

2017年5月26日

## Abstract

## 摘要

Semantic Image Interpretation (SII) is the task of extracting structured semantic descriptions from images. It is widely agreed that the combined use of visual data and background knowledge is of great importance for SII. Recently, Statistical Relational Learning (SRL) approaches have been developed for reasoning under uncertainty and learning in the presence of data and rich knowledge. Logic Tensor Networks (LTNs) are an SRL framework which integrates neural networks with first-order fuzzy logic to allow (i) efficient learning from noisy data in the presence of logical constraints, and (ii) reasoning with logical formulas describing general properties of the data. In this paper, we develop and apply LTNs to two of the main tasks of SII, namely, the classification of an image's bounding boxes and the detection of the relevant part-of relations between objects. To the best of our knowledge, this is the first successful application of SRL to such SII tasks. The proposed approach is evaluated on a standard image processing benchmark. Experiments show that the use of background knowledge in the form of logical constraints can improve the performance of purely data-driven approaches, including the state-of-the-art Fast Region-based Convolutional Neural Networks (Fast R-CNN). Moreover, we show that the use of logical background knowledge adds robustness to the learning system when errors are present in the labels of the training data.

语义图像解释(SII)是从图像中提取结构化语义描述的任务。人们普遍认为，视觉数据和背景知识的结合使用对语义图像解释至关重要。最近，统计关系学习(SRL)方法已被开发用于在不确定条件下进行推理，并在有数据和丰富知识的情况下进行学习。逻辑张量网络(LTNs)是一种统计关系学习框架，它将神经网络与一阶模糊逻辑相结合，以实现(i)在存在逻辑约束的情况下从噪声数据中进行高效学习，以及(ii)使用描述数据一般属性的逻辑公式进行推理。在本文中，我们开发了逻辑张量网络并将其应用于语义图像解释的两个主要任务，即图像边界框的分类和对象之间相关部分关系的检测。据我们所知，这是统计关系学习首次成功应用于此类语义图像解释任务。我们在一个标准的图像处理基准上对所提出的方法进行了评估。实验表明，以逻辑约束形式使用背景知识可以提高纯数据驱动方法的性能，包括最先进的基于快速区域的卷积神经网络(Fast R - CNN)。此外，我们还表明，当训练数据的标签中存在错误时，使用逻辑背景知识可以增强学习系统的鲁棒性。

## 1 Introduction

## 1 引言

Semantic Image Interpretation (SII) is the task of generating a structured semantic description of the content of an image. This structured description can be represented as a labelled directed graph, where each vertex corresponds to a bounding box of an object in the image, and each edge represents a relation between pairs of objects; verteces are labelled with a set of object types and edges are labelled by the binary relations. Such a graph is also called a scene graph in [15].

语义图像解释(Semantic Image Interpretation，SII)是生成图像内容结构化语义描述的任务。这种结构化描述可以表示为一个带标签的有向图，其中每个顶点对应图像中一个对象的边界框，每条边表示对象对之间的关系；顶点用一组对象类型进行标记，边用二元关系进行标记。在文献[15]中，这样的图也被称为场景图。

A major obstacle to be overcome by SII is the so-called semantic gap [19], that is, the lack of a direct correspondence between low-level features of the image and high-level semantic descriptions. To tackle this problem, a system for SII must learn the latent correlations that may exist between the numerical features that can be observed in an image and the semantic concepts associated with the objects. It is in this learning process that the availability of relational background knowledge can be of great help. Thus, recent SII systems have sought to combine, or even integrate, visual features obtained from data and symbolic knowledge in the form of logical axioms [30, 4, 8].

SII需要克服的一个主要障碍是所谓的语义鸿沟[19]，即图像的低级特征与高级语义描述之间缺乏直接对应关系。为了解决这个问题，SII系统必须学习图像中可观察到的数值特征与对象相关的语义概念之间可能存在的潜在关联。在这个学习过程中，关系型背景知识的可用性可能会有很大帮助。因此，最近的SII系统试图将从数据中获得的视觉特征与逻辑公理形式的符号知识相结合，甚至进行整合[30, 4, 8]。

The area of Statistical Relational Learning (SRL), or Statistical Artificial Intelligence (StarAI), seeks to combine data-driven learning, in the presence of uncertainty, with symbolic knowledge [29, 2, 13, 7, 26, 23]. However, only very few SRL systems have been applied to SII tasks (c.f. Section 2) due to the high complexity associated with image learning. Most systems for solving SII tasks have been based, instead, on deep learning and neural network models. These, on the other hand, do not in general offer a well-founded way of learning from data in the presence of relational logical constraints, requiring the neural models to be highly engineered from scratch.

统计关系学习(Statistical Relational Learning，SRL)或统计人工智能(Statistical Artificial Intelligence，StarAI)领域试图将存在不确定性情况下的数据驱动学习与符号知识相结合[29, 2, 13, 7, 26, 23]。然而，由于图像学习的高度复杂性，只有极少数SRL系统被应用于SII任务(详见第2节)。相反，大多数解决SII任务的系统基于深度学习和神经网络模型。另一方面，这些模型通常不能提供一种在存在关系逻辑约束的情况下从数据中学习的可靠方法，需要从头对神经模型进行大量设计。

In this paper, we develop and apply for the first time, the SRL framework called Logic Tensor Networks (LTNs) to computationally challenging SII tasks. LTNs combine learning in deep networks with relational logical constraints [27]. It uses a First-order Logic (FOL) syntax interpreted in the real numbers, which is implemented as a deep tensor network. Logical terms are interpreted as feature vectors in a real-valued $n$ -dimensional space. Function symbols are interpreted as real-valued functions, and predicate symbols as fuzzy logic relations. This syntax and semantics, called real semantics, allow LTNs to learn efficiently in hybrid domains, where elements are composed of both numerical and relational information.

在本文中，我们首次开发并应用了名为逻辑张量网络(Logic Tensor Networks，LTNs)的SRL框架来解决具有计算挑战性的SII任务。LTNs将深度网络中的学习与关系逻辑约束相结合[27]。它使用在实数中解释的一阶逻辑(First-order Logic，FOL)语法，该语法被实现为一个深度张量网络。逻辑项被解释为实值 $n$ 维空间中的特征向量。函数符号被解释为实值函数，谓词符号被解释为模糊逻辑关系。这种被称为实语义的语法和语义允许LTNs在混合领域中进行高效学习，其中元素由数值信息和关系信息组成。

We argue, therefore, that LTNs are a good candidate for learning SII because they can express relational knowledge in FOL which serves as constraints on the data-driven learning within tensor networks. Being LTN a logic, it provides a notion of logical consequence, which forms the basis for learning within LTNs, which is defined as best satisfiability, c.f. Section 4. Solving the best satisfiability problem amounts to finding the latent correlations that may exist between a relational background knowledge and numerical data attributes. This formulation enables the specification of learning as reasoning, a unique characteristic of LTNs, which is seen as highly relevant for SII.

因此，我们认为LTNs是学习SII的一个很好的候选方案，因为它们可以用FOL表达关系知识，这些知识可作为张量网络中数据驱动学习的约束条件。由于LTNs是一种逻辑，它提供了逻辑结果的概念，这构成了LTNs中学习的基础，学习被定义为最佳可满足性，详见第4节。解决最佳可满足性问题相当于找到关系型背景知识和数值数据属性之间可能存在的潜在关联。这种表述使得学习可以被指定为推理，这是LTNs的一个独特特征，被认为与SII高度相关。

This paper specifies SII within LTNs, evaluating it on two important tasks: (i) the classification of bounding boxes, and (ii) the detection of the part-of relation between any two bounding boxes. Both tasks are evaluated using the PASCAL-PART dataset [5]. It is shown that LTNs improve the performance of the state-of-the-art object classifier Fast R-CNN [11] on the bounding box classification task. LTNs also outperform a rule-based heuristic (which uses the inclusion ratio of two bounding boxes) in the detection of part-of relations between objects. Finally, LTNs are evaluated on their ability to handle errors, specifically misclassifications of objects and part-of relations. Very large visual recognition datasets now exist which are noisy [24], and it is important for learning systems to become robust to noise. LTNs were trained systematically on progressively noisier datasets, with results on both SII tasks showing that LTN's logical constraints are capable of adding robustness to the system, in the presence of errors in the labels of the training data.

本文在LTNs中对SII进行了详细说明，并在两个重要任务上对其进行了评估:(i)边界框分类；(ii)任意两个边界框之间部分 - 整体关系的检测。这两个任务都使用PASCAL - PART数据集[5]进行评估。结果表明，在边界框分类任务中，LTNs提高了最先进的对象分类器Fast R - CNN[11]的性能。在检测对象之间的部分 - 整体关系方面，LTNs也优于基于规则的启发式方法(该方法使用两个边界框的包含比率)。最后，评估了LTNs处理错误的能力，特别是对象和部分 - 整体关系的错误分类。现在存在非常大的视觉识别数据集，这些数据集存在噪声[24]，学习系统对噪声具有鲁棒性非常重要。LTNs在噪声逐渐增加的数据集中进行了系统训练，两个SII任务的结果表明，在训练数据标签存在错误的情况下，LTNs的逻辑约束能够增强系统的鲁棒性。

The paper is organized as follows: Section 2 contrasts the LTN approach with related work which integrate visual features and background knowledge for SII. Section 3 specifies LTNs in the context of SII. Section 4 defines the best satisfiability problem in this context, which enables the use of LTNs for SII. Section 5 describes in detail the comparative evaluations of LTNs on the SII tasks. Section 6 concludes the paper and discusses directions for future work.

本文的组织结构如下:第2节将LTNs方法与为SII整合视觉特征和背景知识的相关工作进行了对比。第3节在SII的背景下详细说明了LTNs。第4节定义了在这种背景下的最佳可满足性问题，这使得LTNs可用于SII。第5节详细描述了LTNs在SII任务上的对比评估。第6节总结了本文并讨论了未来的研究方向。

## 2 Related Work

## 2 相关工作

The idea of exploiting logical background knowledge to improve SII tasks dates back to the early days of AI. In what follows, we review the most recent results in the area in comparison with LTNs.

利用逻辑背景知识来改进场景解释(SII)任务的想法可以追溯到人工智能的早期。接下来，我们将回顾该领域与逻辑张量网络(LTNs)相比的最新研究成果。

Logic-based approaches have used Description Logics (DL), where the basic components of the scene are all assumed to have been already discovered (e.g. simple object types or spatial relations). Then, with logical reasoning, new facts can be derived in the scene from these basic components [19, 21]. Other logic-based approaches have used fuzzy DL to tackle uncertainty in the basic components [14, 6, 1]. These approaches have limited themselves to spatial relations or to refining the labels of the objects detected. In [8], the scene interpretation is created by combining image features with constraints defined using DL, but the method is tailored to the part-of relation and cannot be extended easily to account for other relations. LTNs, on the other hand, should be able to handle any semantic relation. In [18, 10], a symbolic Knowledge-base is used to improve object detection, but only the subsumption relation is explored and it is not possible to inject more complex knowledge using logical axioms.

基于逻辑的方法采用了描述逻辑(Description Logics，DL)，其中假设场景的基本组成部分都已被发现(例如简单的对象类型或空间关系)。然后，通过逻辑推理，可以从这些基本组成部分推导出场景中的新事实 [19, 21]。其他基于逻辑的方法使用模糊描述逻辑来处理基本组成部分中的不确定性 [14, 6, 1]。这些方法仅限于处理空间关系或细化检测到的对象的标签。在文献 [8] 中，通过将图像特征与使用描述逻辑定义的约束相结合来创建场景解释，但该方法是针对部分 - 整体关系量身定制的，难以轻松扩展以处理其他关系。另一方面，逻辑张量网络应该能够处理任何语义关系。在文献 [18, 10] 中，使用符号知识库来改进对象检测，但仅探索了包含关系，并且无法使用逻辑公理注入更复杂的知识。

A second group of approaches seeks to encode background knowledge and visual features within probabilistic graphical models. In [30, 20], visual features are combined with knowledge gathered from datasets, web resources or annotators, about object labels, properties such as shape, colour and size, and affordances, using Markov Logic Networks (MLNs) [25] to predict facts in unseen images. Due to the specific knowledge-base schema adopted, the effectiveness of MLNs in this domain is evaluated only for Horn clauses, although the language of MLNs is more general. As a result, it is not easy to evaluate how the approach may perform with more complex axioms. In [2], a probabilistic fuzzy logic is used, but not with real semantics. Clauses are weighted and universally-quantified formulas are instantiated, as done by MLNs. This is different from LTNs where the universally-quantified formulas are computed by using an aggregation operation, which avoids the need for instantiating all variables.

第二类方法试图在概率图模型中对背景知识和视觉特征进行编码。在文献 [30, 20] 中，使用马尔可夫逻辑网络(Markov Logic Networks，MLNs)[25] 将视觉特征与从数据集、网络资源或标注者那里收集到的关于对象标签、形状、颜色和大小等属性以及功能的知识相结合，以预测未见过图像中的事实。由于采用了特定的知识库模式，尽管马尔可夫逻辑网络的语言更为通用，但在该领域中仅针对霍恩子句评估了其有效性。因此，很难评估该方法在处理更复杂公理时的表现。在文献 [2] 中，使用了概率模糊逻辑，但并非具有真正的语义。与马尔可夫逻辑网络一样，对子句进行加权并实例化全称量化公式。这与逻辑张量网络不同，在逻辑张量网络中，全称量化公式是通过聚合操作来计算的，从而避免了对所有变量进行实例化的需要。

In other related work, [4, 16] encode background knowledge into a generic Conditional Random Field (CRF), where the nodes represent detected objects and the edges represent logical relationships between objects. The task is to find a correct labelling for this graph. In [4], the edges encode logical constraints on a knowledge-base specified in DL. Although these ideas are close in spirit to the approach presented in this paper, they are not formalised as in LTNs, which use a deep tensor network and first-order logic, rather than CRFs or DL. In general, the logical theory behind the functions to be defined in the CRF is unclear. In [16], potential functions are defined as text priors such as co-occurrence of terms found in the image descriptions of Flickr.

在其他相关工作中，文献 [4, 16] 将背景知识编码到通用条件随机场(Conditional Random Field，CRF)中，其中节点表示检测到的对象，边表示对象之间的逻辑关系。任务是为该图找到正确的标签。在文献 [4] 中，边对用描述逻辑指定的知识库上的逻辑约束进行编码。尽管这些想法在本质上与本文提出的方法相近，但它们不像逻辑张量网络那样进行形式化处理，逻辑张量网络使用深度张量网络和一阶逻辑，而不是条件随机场或描述逻辑。一般来说，条件随机场中要定义的函数背后的逻辑理论并不清晰。在文献 [16] 中，势函数被定义为文本先验，例如在Flickr图像描述中发现的术语共现。

In a final group of approaches, here called language-priors, background knowledge is taken from linguistic models [22, 17]. In [22], a neural network is built integrating visual features and a linguistic model to predict semantic relationships between bounding boxes. The linguistic model is a set of rules derived from WORDNET [9], stating which types of semantic relationships occur between a subject and an object. In [17], a similar neural network is proposed for the same task but with a more sophisticated language model, embedding in the same vector space triples of the form subject-relation-object, such that semantically similar triples are mapped closely together in the embedding space. In this way, even if no examples exist of some triples in the data, the relations can be inferred from similarity to more frequent triples. A drawback, however, is the possibility of inferring inconsistent triples, such as e.g. man-eats-chair, due to the embedding. LTNs avoid this problem with a logic-based approach (in the above example, with an axiom to the effect that chairs are not normally edible). LTNs can also handle exceptions, offering a system capable of dealing with crisp axioms and real-valued data, as specified in what follows.

最后一类方法，这里称为语言先验方法，从语言模型中获取背景知识 [22, 17]。在文献 [22] 中，构建了一个集成视觉特征和语言模型的神经网络，用于预测边界框之间的语义关系。语言模型是一组从WordNet [9] 导出的规则，规定了主语和宾语之间会出现哪些类型的语义关系。在文献 [17] 中，针对相同的任务提出了一个类似的神经网络，但使用了更复杂的语言模型，将主语 - 关系 - 宾语形式的三元组嵌入到同一个向量空间中，使得语义相似的三元组在嵌入空间中紧密映射在一起。通过这种方式，即使数据中不存在某些三元组的示例，也可以从与更频繁出现的三元组的相似性中推断出这些关系。然而，一个缺点是由于嵌入的原因，可能会推断出不一致的三元组，例如“人吃椅子”。逻辑张量网络通过基于逻辑的方法避免了这个问题(在上述示例中，使用一个公理表明椅子通常是不可食用的)。逻辑张量网络还可以处理例外情况，提供一个能够处理明确公理和实值数据的系统，具体如下所述。

## 3 Logic Tensor Networks

## 3 逻辑张量网络

Let $\mathcal{L}$ be a first-order logic language, whose signature is composed of three disjoint sets $\mathcal{C},\mathcal{F}$ and $\mathcal{P}$ , denoting constants, functions and predicate symbols, respectively. For any function or predicate symbol $s$ , let $\alpha \left( s\right)$ denote its arity. Logical formulas in $\mathcal{L}$ allow one to specify relational knowledge, e.g. the atomic formula partOf $\left( {{o}_{1},{o}_{2}}\right)$ , stating that object ${o}_{1}$ is a part of object ${o}_{2}$ , the formulae $\forall {xy}\left( {\operatorname{partOf}\left( {x, y}\right)  \rightarrow  \neg \operatorname{partOf}\left( {y, x}\right) }\right)$ , stating that the relation partOf is asymmetric, or $\forall x(\operatorname{Cat}\left( x\right)  \rightarrow  \exists y(\operatorname{partOf}\left( {x, y}\right)  \land$ $\operatorname{Tail}\left( y\right) ))$ , stating that every cat should have a tail. In addition, exceptions are handled by allowing formulas to be interpreted in fuzzy logic, such that in the presence of an example of, say, a tailless cat, the above formula can be interpreted naturally as normally, every cat has a tail; this will be exemplified later.

设$\mathcal{L}$为一阶逻辑语言，其符号集由三个不相交的集合$\mathcal{C},\mathcal{F}$和$\mathcal{P}$组成，分别表示常量、函数和谓词符号。对于任何函数或谓词符号$s$，用$\alpha \left( s\right)$表示其元数。$\mathcal{L}$中的逻辑公式可用于指定关系知识，例如原子公式partOf $\left( {{o}_{1},{o}_{2}}\right)$，表示对象${o}_{1}$是对象${o}_{2}$的一部分；公式$\forall {xy}\left( {\operatorname{partOf}\left( {x, y}\right)  \rightarrow  \neg \operatorname{partOf}\left( {y, x}\right) }\right)$，表示partOf关系是非对称的；或者$\forall x(\operatorname{Cat}\left( x\right)  \rightarrow  \exists y(\operatorname{partOf}\left( {x, y}\right)  \land$ $\operatorname{Tail}\left( y\right) ))$，表示每只猫都应该有尾巴。此外，通过允许在模糊逻辑中解释公式来处理例外情况，这样，例如在存在无尾猫的例子时，上述公式可以自然地解释为通常情况下，每只猫都有尾巴；这将在后面举例说明。

Semantics of $\mathcal{L}$ : We define the interpretation domain as a subset of ${\mathbb{R}}^{n}$ , i.e. every object in the domain is associated with a $n$ -dimensional vector of real numbers. Intuitively, this $n$ -tuple represents $n$ numerical features of an object, e.g. in the case of a person, their name in ASCII, height, weight, social security number, etc. Functions are interpreted as real-valued functions, and predicates are interpreted as fuzzy relations on real vectors. To emphasise the fact that we interpret symbols as real numbers, we use the term grounding instead of interpretation ${}^{1}$ in the following definition of semantics.

$\mathcal{L}$的语义:我们将解释域定义为${\mathbb{R}}^{n}$的一个子集，即域中的每个对象都与一个$n$维实数向量相关联。直观地说，这个$n$元组表示一个对象的$n$个数值特征，例如，对于一个人来说，他们的ASCII格式姓名、身高、体重、社会保险号码等。函数被解释为实值函数，谓词被解释为实向量上的模糊关系。为了强调我们将符号解释为实数这一事实，在下面的语义定义中，我们使用“基化(grounding)”而不是“解释(interpretation)”${}^{1}$这个术语。

---

${}^{1}$ In logic, the term grounding indicates the operation of replacing the variables of a term or formula with constants or terms that do not contain other variables. To avoid any confusion, we use the synonym

${}^{1}$在逻辑中，“基化(grounding)”这一术语表示用常量或不包含其他变量的项替换项或公式中的变量的操作。为避免混淆，我们使用同义词

---

Definition 1 Let $n \in  \mathbb{N}$ . An $n$ -grounding, or simply grounding, $\mathcal{G}$ for a ${FOL}\mathcal{L}$ is a function defined on the signature of $\mathcal{L}$ satisfying the following conditions:

定义1 设$n \in  \mathbb{N}$。对于${FOL}\mathcal{L}$的一个$n$ - 基化(或简称为基化)$\mathcal{G}$是一个定义在$\mathcal{L}$的符号集上的函数，满足以下条件:

1. $\mathcal{G}\left( c\right)  \in  {\mathbb{R}}^{n}$ for every constant symbol $c \in  \mathcal{C}$ ;

1. 对于每个常量符号$c \in  \mathcal{C}$，有$\mathcal{G}\left( c\right)  \in  {\mathbb{R}}^{n}$；

2. $\mathcal{G}\left( f\right)  \in  {\mathbb{R}}^{n \cdot  \alpha \left( f\right) } \rightarrow  {\mathbb{R}}^{n}$ for every $f \in  \mathcal{F}$ ;

2. 对于每个$f \in  \mathcal{F}$，有$\mathcal{G}\left( f\right)  \in  {\mathbb{R}}^{n \cdot  \alpha \left( f\right) } \rightarrow  {\mathbb{R}}^{n}$；

3. $\mathcal{G}\left( P\right)  \in  {\mathbb{R}}^{n \cdot  \alpha \left( P\right) } \rightarrow  \left\lbrack  {0,1}\right\rbrack$ for every $P \in  \mathcal{P}$ .

3. 对于每个$P \in  \mathcal{P}$，有$\mathcal{G}\left( P\right)  \in  {\mathbb{R}}^{n \cdot  \alpha \left( P\right) } \rightarrow  \left\lbrack  {0,1}\right\rbrack$。

Given a grounding $\mathcal{G}$ , the semantics of closed terms and atomic formulas is defined as follows:

给定一个基化$\mathcal{G}$，闭项和原子公式的语义定义如下:

$$
\mathcal{G}\left( {f\left( {{t}_{1},\ldots ,{t}_{m}}\right) }\right)  = \mathcal{G}\left( f\right) \left( {\mathcal{G}\left( {t}_{1}\right) ,\ldots ,\mathcal{G}\left( {t}_{m}\right) }\right)
$$

$$
\mathcal{G}\left( {P\left( {{t}_{1},\ldots ,{t}_{m}}\right) }\right)  = \mathcal{G}\left( P\right) \left( {\mathcal{G}\left( {t}_{1}\right) ,\ldots ,\mathcal{G}\left( {t}_{m}\right) }\right)
$$

The semantics for connectives is defined according to fuzzy logic; using for instance the Lukasiewicz t-norm 2

连接词的语义根据模糊逻辑定义；例如使用卢卡西维茨t - 范数2

$$
\mathcal{G}\left( {\neg \phi }\right)  = 1 - \mathcal{G}\left( \phi \right)
$$

$$
\mathcal{G}\left( {\phi  \land  \psi }\right)  = \max \left( {0,\mathcal{G}\left( \phi \right)  + \mathcal{G}\left( \psi \right)  - 1}\right)
$$

$$
\mathcal{G}\left( {\phi  \vee  \psi }\right)  = \min \left( {1,\mathcal{G}\left( \phi \right)  + \mathcal{G}\left( \psi \right) }\right)
$$

$$
\mathcal{G}\left( {\phi  \rightarrow  \psi }\right)  = \min \left( {1,1 - \mathcal{G}\left( \phi \right)  + \mathcal{G}\left( \psi \right) }\right)
$$

The LTN semantics for $\forall$ is defined in [27] using the min operator, that is, $\mathcal{G}\left( {\forall {x\phi }\left( x\right) }\right)  =$ $\mathop{\min }\limits_{{t \in  \operatorname{term}\left( \mathcal{L}\right) }}\mathcal{G}\left( {\phi \left( t\right) }\right)$ ), where $\operatorname{term}\left( \mathcal{L}\right)$ is the set of instantiated terms of $\mathcal{L}$ . This, however, is inadequate for our purposes as it does not tolerate exceptions well (the presence of a single exception to the universally-quantified formulae, such as e.g. a cat without a tail, would falsify the formulae. Instead, our intention in SII is that the more examples there are that satisfy a formulae $\phi \left( x\right)$ , the higher the truth-value of $\forall {x\phi }\left( x\right)$ should be. To capture this, we use for the semantics of $\forall$ a mean-operator, as follows:

$\forall$的模糊真值逻辑网络(LTN)语义在文献[27]中使用最小运算符进行定义，即$\mathcal{G}\left( {\forall {x\phi }\left( x\right) }\right)  =$ $\mathop{\min }\limits_{{t \in  \operatorname{term}\left( \mathcal{L}\right) }}\mathcal{G}\left( {\phi \left( t\right) }\right)$ )，其中$\operatorname{term}\left( \mathcal{L}\right)$是$\mathcal{L}$的实例化项集合。然而，这对于我们的目的来说并不合适，因为它不能很好地容忍例外情况(对于全称量化公式存在单个例外，例如没有尾巴的猫，就会使该公式为假)。相反，在半监督归纳推理(SII)中，我们的意图是满足公式$\phi \left( x\right)$的示例越多，$\forall {x\phi }\left( x\right)$的真值就应该越高。为了体现这一点，我们对$\forall$的语义使用均值运算符，如下所示:

$$
\mathcal{G}\left( {\forall {x\phi }\left( x\right) }\right)  = \mathop{\lim }\limits_{{T \rightarrow  \operatorname{term}\left( \mathcal{L}\right) }}{\operatorname{mean}}_{p}\left( {\mathcal{G}\left( {\phi \left( t\right) }\right)  \mid  t \in  T}\right)
$$

where ${\operatorname{mean}}_{p}\left( {{x}_{1},\ldots ,{x}_{d}}\right)  = {\left( \frac{1}{d}\mathop{\sum }\limits_{{i = 1}}^{d}{x}_{i}^{p}\right) }^{\frac{1}{p}}$ for $p \in  \mathbb{Z}$ .

其中对于$p \in  \mathbb{Z}$有${\operatorname{mean}}_{p}\left( {{x}_{1},\ldots ,{x}_{d}}\right)  = {\left( \frac{1}{d}\mathop{\sum }\limits_{{i = 1}}^{d}{x}_{i}^{p}\right) }^{\frac{1}{p}}$ 。

Finally, the classical semantics of $\exists$ is uniquely determined by the semantics of $\forall$ , by making $\exists$ equivalent to $\neg \forall \neg$ . This approach, however, has a drawback too when it comes to SII: if we adopt, for instance, the arithmetic mean for the semantic of $\forall$ then $\mathcal{G}\left( {\forall {x\phi }\left( x\right) }\right)  = \mathcal{G}\left( {\exists {x\phi }\left( x\right) }\right)$ . Therefore, we shall interpret existential quantification via Skolemization: every formula of the form $\forall {x}_{1},\ldots ,{x}_{n}\left( {\ldots \exists {y\phi }\left( {{x}_{1},\ldots ,{x}_{n}, y}\right) }\right)$ is rewritten as $\forall {x}_{1},\ldots ,{x}_{n}\left( {\ldots \phi \left( {{x}_{1},\ldots ,{x}_{n}, f\left( {{x}_{1},\ldots ,{x}_{n}}\right) }\right) }\right)$ , by introducing a new $n$ - ary function symbol, called Skolem function. In this way, existential quantifiers can be eliminated from the language by introducing Skolem functions.

最后，$\exists$的经典语义由$\forall$的语义唯一确定，通过使$\exists$等价于$\neg \forall \neg$ 。然而，当涉及到半监督归纳推理(SII)时，这种方法也有一个缺点:例如，如果我们对$\forall$的语义采用算术平均值，那么$\mathcal{G}\left( {\forall {x\phi }\left( x\right) }\right)  = \mathcal{G}\left( {\exists {x\phi }\left( x\right) }\right)$ 。因此，我们将通过斯科伦化(Skolemization)来解释存在量化:形式为$\forall {x}_{1},\ldots ,{x}_{n}\left( {\ldots \exists {y\phi }\left( {{x}_{1},\ldots ,{x}_{n}, y}\right) }\right)$的每个公式都被重写为$\forall {x}_{1},\ldots ,{x}_{n}\left( {\ldots \phi \left( {{x}_{1},\ldots ,{x}_{n}, f\left( {{x}_{1},\ldots ,{x}_{n}}\right) }\right) }\right)$ ，通过引入一个新的$n$元函数符号，称为斯科伦函数(Skolem function)。通过这种方式，可以通过引入斯科伦函数从语言中消除存在量词。

---

instantiation for this purpose. It is worth noting that in LTN, differently from MLNs, the instantiation of every first order formula is not required.

为此目的进行实例化。值得注意的是，在模糊真值逻辑网络(LTN)中，与马尔可夫逻辑网络(MLNs)不同，并不要求对每个一阶公式进行实例化。

${}^{2}$ Examples of t-norms include Lukasiewicz, product and Gödel. The Lukasiewicz t-norm is ${\mu }_{Luk}\left( {x, y}\right)  = \max \left( {0, x + y - 1}\right)$ , product t-norm is ${\mu }_{Pr}\left( {x, y}\right)  = x \cdot  y$ , and Gödel t-norm is ${\mu }_{\max }\left( {x, y}\right)  = \min \left( {x, y}\right)$ . See [3] for details.

${}^{2}$t - 范数(t - norm)的例子包括卢卡西维茨(Lukasiewicz)、乘积和哥德尔(Gödel)。卢卡西维茨t - 范数是${\mu }_{Luk}\left( {x, y}\right)  = \max \left( {0, x + y - 1}\right)$ ，乘积t - 范数是${\mu }_{Pr}\left( {x, y}\right)  = x \cdot  y$ ，哥德尔t - 范数是${\mu }_{\max }\left( {x, y}\right)  = \min \left( {x, y}\right)$ 。详情见文献[3]。

${}^{3}$ The popular mean operators, arithmetic, geometric and harmonic mean, are obtained by setting $p = 1,2$ , and -1 , respectively.

${}^{3}$常见的均值运算符，算术平均值、几何平均值和调和平均值，分别通过设置$p = 1,2$和 - 1得到。

---

Formalizing SII in LTNs: To specify the SII problem, as defined in the introduction, we consider a signature ${\sum }_{\mathrm{{SII}}} = \langle \mathcal{C},\mathcal{F},\mathcal{P}\rangle$ , where $\mathcal{C} = \mathop{\bigcup }\limits_{{p \in  \text{Pics }}}b\left( p\right)$ is the set of identifiers for all the bounding boxes in all the images, $\mathcal{F} = \varnothing$ , and $\mathcal{P} = \left\{  {{\mathcal{P}}_{1},{\mathcal{P}}_{2}}\right\}$ , where ${\mathcal{P}}_{1}$ is a set of unary predicates, one for each object type, e.g. ${\mathcal{P}}_{1} = \{$ Dog, Cat, Tail, Muzzle, Train, Coach,... $\}$ , and ${\mathcal{P}}_{2}$ is a set of binary predicates representing relations between objects. Since in our experiments we focus on the part-of relation, ${\mathcal{P}}_{2} = \{$ partOf $\}$ . The FOL formulas based on this signature can specify (i) simple facts, e.g. the fact that bounding box $b$ contains a cat, written $\operatorname{Cat}\left( b\right)$ , the fact that $b$ contains either a cat or a dog, written $\operatorname{Cat}\left( b\right)  \vee  \operatorname{Dog}\left( b\right)$ , etc., and (ii) general rules such as $\forall x\left( {\operatorname{Cat}\left( x\right)  \rightarrow  \exists y\left( {\operatorname{partOf}\left( {x, y}\right)  \land  \operatorname{Tail}\left( y\right) }\right) }\right)$ .

在模糊时态网络(LTNs)中形式化场景实例识别(SII)问题:为了明确引言中定义的场景实例识别问题，我们考虑一个符号体系 ${\sum }_{\mathrm{{SII}}} = \langle \mathcal{C},\mathcal{F},\mathcal{P}\rangle$ ，其中 $\mathcal{C} = \mathop{\bigcup }\limits_{{p \in  \text{Pics }}}b\left( p\right)$ 是所有图像中所有边界框的标识符集合， $\mathcal{F} = \varnothing$ ，并且 $\mathcal{P} = \left\{  {{\mathcal{P}}_{1},{\mathcal{P}}_{2}}\right\}$ ，其中 ${\mathcal{P}}_{1}$ 是一组一元谓词，每个对象类型对应一个，例如 ${\mathcal{P}}_{1} = \{$ 狗、猫、尾巴、口鼻、火车、客车…… $\}$ ，并且 ${\mathcal{P}}_{2}$ 是一组表示对象之间关系的二元谓词。由于在我们的实验中，我们专注于部分 - 整体关系， ${\mathcal{P}}_{2} = \{$ 部分属于 $\}$ 。基于此符号体系的一阶逻辑(FOL)公式可以指定(i)简单事实，例如边界框 $b$ 包含一只猫这一事实，写作 $\operatorname{Cat}\left( b\right)$ ，边界框 $b$ 包含一只猫或一只狗这一事实，写作 $\operatorname{Cat}\left( b\right)  \vee  \operatorname{Dog}\left( b\right)$ ，等等，以及(ii)通用规则，如 $\forall x\left( {\operatorname{Cat}\left( x\right)  \rightarrow  \exists y\left( {\operatorname{partOf}\left( {x, y}\right)  \land  \operatorname{Tail}\left( y\right) }\right) }\right)$ 。

A grounding for ${\sum }_{\mathrm{{SII}}}$ can be defined as follows: each constant $b$ , denoting a bounding box, can be associated with a set of geometric features and a set of semantic features obtained from the output of a bounding box detector. Specifically, each bounding box is associated with geometric features describing the position and the dimension of the bounding box, and semantic features describing the classification score returned by the bounding box detector for each class. For example, for each bounding box $b \in  \mathcal{C}$ , ${C}_{i} \in  {\mathcal{P}}_{1},\mathcal{G}\left( b\right)$ is the ${\mathbb{R}}^{4 + \left| {\mathcal{P}}_{1}\right| }$ vector:

${\sum }_{\mathrm{{SII}}}$ 的一个解释可以定义如下:每个表示边界框的常量 $b$ 可以与一组几何特征和一组从边界框检测器的输出中获得的语义特征相关联。具体来说，每个边界框与描述边界框位置和尺寸的几何特征以及描述边界框检测器针对每个类别返回的分类得分的语义特征相关联。例如，对于每个边界框 $b \in  \mathcal{C}$ ， ${C}_{i} \in  {\mathcal{P}}_{1},\mathcal{G}\left( b\right)$ 是 ${\mathbb{R}}^{4 + \left| {\mathcal{P}}_{1}\right| }$ 向量:

$$
\left\langle  {\operatorname{class}\left( {{C}_{1}, b}\right) ,\ldots ,\operatorname{class}\left( {{C}_{\left| {\mathcal{P}}_{1}\right| }, b}\right) ,{x}_{0}\left( b\right) ,{y}_{0}\left( b\right) ,{x}_{1}\left( b\right) ,{y}_{1}\left( b\right) }\right\rangle
$$

where the last four elements are the coordinates of the top-left and bottom-right corners of $b$ , and $\operatorname{class}\left( {{C}_{i}, b}\right)  \in  \left\lbrack  {0,1}\right\rbrack$ is the classification score of the bounding box detector for $b$ .

其中最后四个元素是 $b$ 的左上角和右下角的坐标，并且 $\operatorname{class}\left( {{C}_{i}, b}\right)  \in  \left\lbrack  {0,1}\right\rbrack$ 是边界框检测器针对 $b$ 的分类得分。

An example of groundings for predicates can be defined by taking a one-vs-all multi-classifier approach, as follows. First, define the following grounding for each class ${C}_{i} \in  {\mathcal{P}}_{1}$ (below, $\mathbf{x} = \left\langle  {{x}_{1},\ldots ,{x}_{\left| {\mathcal{P}}_{1}\right|  + 4}}\right\rangle$ is the vector corresponding to the grounding of a bounding box):

谓词解释的一个示例可以通过采用一对多多分类器方法来定义，如下所示。首先，为每个类别 ${C}_{i} \in  {\mathcal{P}}_{1}$ 定义以下解释(下面， $\mathbf{x} = \left\langle  {{x}_{1},\ldots ,{x}_{\left| {\mathcal{P}}_{1}\right|  + 4}}\right\rangle$ 是对应于边界框解释的向量):

$$
\mathcal{G}\left( {C}_{i}\right) \left( \mathbf{x}\right)  = \left\{  \begin{array}{ll} 1 & \text{ if }i = {\operatorname{argmax}}_{1 \leq  l \leq  \left| {\mathcal{P}}_{1}\right| }{x}_{l} \\  0 & \text{ otherwise } \end{array}\right.  \tag{1}
$$

Then, a simple rule-based approach for defining a grounding for the partOf relation is based on the naïve assumption that the more a bounding box $b$ is contained within a bounding box ${b}^{\prime }$ , the higher the probability should be that $b$ is part of ${b}^{\prime }$ . Accordingly, one can define $\mathcal{G}\left( {\operatorname{partOf}\left( {b,{b}^{\prime }}\right) }\right)$ as the inclusion ratio $\operatorname{ir}\left( {b,{b}^{\prime }}\right)$ of bounding box $b$ , with grounding $\mathbf{x}$ , into bounding box ${b}^{\prime }$ , with grounding ${\mathbf{x}}^{\prime }$ (formally, $\operatorname{ir}\left( {b,{b}^{\prime }}\right)  =$ $\left. \frac{\operatorname{area}\left( {b \cap  {b}^{\prime }}\right) }{\operatorname{area}\left( b\right) }\right)$ . A slightly more sophisticated rule-based grounding for partOf (used as baseline in the experiments to follow) takes into account also type compatibilities by multiplying the inclusion ratio by a factor ${w}_{ij}$ . Hence, we define $\mathcal{G}\left( {\operatorname{partOf}\left( {b,{b}^{\prime }}\right) }\right)$ as follows:

然后，一种基于规则的简单方法来定义partOf关系的基础，是基于一个天真的假设，即边界框$b$越包含在边界框${b}^{\prime }$内，$b$是${b}^{\prime }$的一部分的概率就应该越高。因此，可以将$\mathcal{G}\left( {\operatorname{partOf}\left( {b,{b}^{\prime }}\right) }\right)$定义为边界框$b$(其基础为$\mathbf{x}$)在边界框${b}^{\prime }$(其基础为${\mathbf{x}}^{\prime }$)中的包含比率$\operatorname{ir}\left( {b,{b}^{\prime }}\right)$(形式上，$\operatorname{ir}\left( {b,{b}^{\prime }}\right)  =$ $\left. \frac{\operatorname{area}\left( {b \cap  {b}^{\prime }}\right) }{\operatorname{area}\left( b\right) }\right)$)。一种稍微复杂一些的基于规则的partOf基础(在后续实验中用作基线)还考虑了类型兼容性，方法是将包含比率乘以一个因子${w}_{ij}$。因此，我们将$\mathcal{G}\left( {\operatorname{partOf}\left( {b,{b}^{\prime }}\right) }\right)$定义如下:

$$
\left\{  \begin{array}{ll} 1 & \text{ if }\operatorname{ir}\left( {b,{b}^{\prime }}\right)  \cdot  \mathop{\max }\limits_{{{ij} = 1}}^{\left| {\mathcal{P}}_{1}\right| }\left( {{w}_{ij} \cdot  {x}_{i} \cdot  {x}_{j}^{\prime }}\right)  \geq  t{h}_{ir} \\  0 & \text{ otherwise } \end{array}\right.  \tag{2}
$$

for some threshold $t{h}_{ir}$ (we use $t{h}_{ir} > {0.5}$ ), and with ${w}_{ij} = 1$ if ${C}_{i}$ is a part of ${C}_{j}$ , and 0 otherwise. Given the above grounding, we can compute the grounding of any atomic formula, e.g. $\operatorname{Cat}\left( {b}_{1}\right) ,\operatorname{Dog}\left( {b}_{2}\right) ,\operatorname{leg}\left( {b}_{3}\right) ,\operatorname{partOf}\left( {{b}_{3},{b}_{1}}\right) ,\operatorname{partOf}\left( {{b}_{3},{b}_{2}}\right)$ , thus expressing the degree of truth of the formula. The rule-based groundings (Eqs. [1] and [2]) may not satisfy some of the constraints to be imposed. For example, the classification score may be wrong, a bounding box may include another which is not in the part-of relation, etc. Furthermore, in many situations, it is not possible to define a grounding a priori. Instead, groundings may need to be learned automatically from examples, by optimizing the truth-values of the formulas in the background knowledge. This is discussed next.

对于某个阈值$t{h}_{ir}$(我们使用$t{h}_{ir} > {0.5}$)，并且如果${C}_{i}$是${C}_{j}$的一部分，则${w}_{ij} = 1$为1，否则为0。给定上述基础，我们可以计算任何原子公式的基础，例如$\operatorname{Cat}\left( {b}_{1}\right) ,\operatorname{Dog}\left( {b}_{2}\right) ,\operatorname{leg}\left( {b}_{3}\right) ,\operatorname{partOf}\left( {{b}_{3},{b}_{1}}\right) ,\operatorname{partOf}\left( {{b}_{3},{b}_{2}}\right)$，从而表达该公式的真实程度。基于规则的基础(公式[1]和[2])可能不满足某些要施加的约束条件。例如，分类得分可能有误，一个边界框可能包含另一个并非处于部分 - 整体关系的边界框等。此外，在许多情况下，不可能事先定义一个基础。相反，可能需要通过优化背景知识中公式的真值，从示例中自动学习基础。接下来将讨论这一点。

## 4 Learning as Best Satisfiability

## 4 作为最佳可满足性的学习

A partial grounding, denoted by $\widehat{\mathcal{G}}$ , is a grounding that is defined on a subset of the signature of $\mathcal{L}$ . A grounding $\mathcal{G}$ is said to be a completion of $\widehat{\mathcal{G}}$ , if $\mathcal{G}$ is a grounding for $\mathcal{L}$ and coincides with $\widehat{\mathcal{G}}$ on the symbols where $\widehat{\mathcal{G}}$ is defined.

部分基础，用$\widehat{\mathcal{G}}$表示，是在$\mathcal{L}$的签名的一个子集上定义的基础。如果$\mathcal{G}$是$\mathcal{L}$的基础，并且在$\widehat{\mathcal{G}}$有定义的符号上与$\widehat{\mathcal{G}}$一致，则称基础$\mathcal{G}$是$\widehat{\mathcal{G}}$的完备化。

Definition 2 A grounded theory GT is a pair $\langle \mathcal{K},\widehat{\mathcal{G}}\rangle$ with a set $\mathcal{K}$ of closed formulas and a partial grounding $\widehat{\mathcal{G}}$ .

定义2 一个基础理论GT是一个对$\langle \mathcal{K},\widehat{\mathcal{G}}\rangle$，其中包含一组封闭公式$\mathcal{K}$和一个部分基础$\widehat{\mathcal{G}}$。

Definition 3 A grounding $\mathcal{G}$ satisfies a ${GT}\langle \mathcal{K},\widehat{\mathcal{G}}\rangle$ if $\mathcal{G}$ completes $\widehat{\mathcal{G}}$ and $\mathcal{G}\left( \phi \right)  = 1$ for all $\phi  \in  \mathcal{K}$ . A GT $\langle \mathcal{K},\widehat{\mathcal{G}}\rangle$ is satisfiable if there exists a grounding $\mathcal{G}$ that satisfies $\langle \mathcal{K},\widehat{\mathcal{G}}\rangle$ .

定义3 如果基础$\mathcal{G}$是$\widehat{\mathcal{G}}$的完备化，并且对于所有的$\phi  \in  \mathcal{K}$都有$\mathcal{G}\left( \phi \right)  = 1$，则称基础$\mathcal{G}$满足${GT}\langle \mathcal{K},\widehat{\mathcal{G}}\rangle$。如果存在一个满足$\langle \mathcal{K},\widehat{\mathcal{G}}\rangle$的基础$\mathcal{G}$，则称GT $\langle \mathcal{K},\widehat{\mathcal{G}}\rangle$是可满足的。

According to the previous definition, deciding the satisfiability of $\langle \mathcal{K},\widehat{\mathcal{G}}\rangle$ amounts to searching for a grounding $\widehat{\mathcal{G}}$ such that all the formulas of $\mathcal{K}$ are mapped to 1 . Differently from the classical satisfiability, when a GT is not satisfiable, we are interested in the best possible satisfaction that we can reach with a grounding. This is defined as follows.

根据先前的定义，判定$\langle \mathcal{K},\widehat{\mathcal{G}}\rangle$的可满足性相当于寻找一个基替换$\widehat{\mathcal{G}}$，使得$\mathcal{K}$中的所有公式都映射为1。与经典可满足性不同的是，当一个基理论(GT)不可满足时，我们关注的是通过基替换所能达到的最佳可能满足度。定义如下。

Definition 4 Let $\langle \mathcal{K},\widehat{\mathcal{G}}\rangle$ be a grounded theory. We define the best satisfiability problem as the problem of finding a grounding ${\mathcal{G}}^{ * }$ that maximizes the truth-values of the conjunction of all clauses ${cl} \in  \mathcal{K}$ , i.e. ${\mathcal{G}}^{ * } = {\operatorname{argmax}}_{\widehat{\mathcal{G}} \subseteq  \mathcal{G} \in  \mathbb{G}}\mathcal{G}\left( {\mathop{\bigwedge }\limits_{{{cl} \in  \mathcal{K}}}{cl}}\right)$ .

定义4 设$\langle \mathcal{K},\widehat{\mathcal{G}}\rangle$为一个基理论。我们将最佳可满足性问题定义为寻找一个基替换${\mathcal{G}}^{ * }$，使得所有子句的合取式${cl} \in  \mathcal{K}$的真值最大化，即${\mathcal{G}}^{ * } = {\operatorname{argmax}}_{\widehat{\mathcal{G}} \subseteq  \mathcal{G} \in  \mathbb{G}}\mathcal{G}\left( {\mathop{\bigwedge }\limits_{{{cl} \in  \mathcal{K}}}{cl}}\right)$。

Grounding ${\mathcal{G}}^{ * }$ captures the latent correlation between the quantitative attribute of objects and their categorical and relational properties. Not all functions are suitable as a grounding; they should preserve some form of regularity. If $\mathcal{G}\left( \operatorname{Cat}\right) \left( \mathbf{x}\right)  \approx  1$ (the bounding box with feature vector $\mathbf{x}$ contains a cat) then for every ${\mathbf{x}}^{\prime }$ close to $\mathbf{x}$ (i.e. for every bounding box with features similar to $\mathbf{x}$ ), one should have $\mathcal{G}\left( \operatorname{Cat}\right) \left( {\mathbf{x}}^{\prime }\right)  \approx  1$ . In particular, we consider groundings of the following form:

基替换${\mathcal{G}}^{ * }$捕捉了对象的定量属性与其分类和关系属性之间的潜在关联。并非所有函数都适合作为基替换；它们应该保留某种形式的规律性。如果$\mathcal{G}\left( \operatorname{Cat}\right) \left( \mathbf{x}\right)  \approx  1$(具有特征向量$\mathbf{x}$的边界框包含一只猫)，那么对于每个接近$\mathbf{x}$的${\mathbf{x}}^{\prime }$(即对于每个具有与$\mathbf{x}$相似特征的边界框)，都应该有$\mathcal{G}\left( \operatorname{Cat}\right) \left( {\mathbf{x}}^{\prime }\right)  \approx  1$。特别地，我们考虑以下形式的基替换:

Function symbols are grounded to linear transformations. If $f$ is a $m$ -ary function symbol, then $\mathcal{G}\left( f\right)$ is of the form:

函数符号被基替换为线性变换。如果$f$是一个$m$元函数符号，那么$\mathcal{G}\left( f\right)$的形式为:

$$
\mathcal{G}\left( f\right) \left( \mathbf{v}\right)  = {M}_{f}\mathbf{v} + {N}_{f}
$$

where $\mathbf{v} = {\left\langle  {\mathbf{v}}_{1}^{\top },\ldots ,{\mathbf{v}}_{m}^{\top }\right\rangle  }^{\top }$ is the ${mn}$ -ary vector obtained by concatenating each ${\mathbf{v}}_{i}$ . The parameters for $\mathcal{G}\left( f\right)$ are the $n \times  {mn}$ real matrix ${M}_{f}$ and the $n$ -vector ${N}_{f}$ .

其中$\mathbf{v} = {\left\langle  {\mathbf{v}}_{1}^{\top },\ldots ,{\mathbf{v}}_{m}^{\top }\right\rangle  }^{\top }$是通过连接每个${\mathbf{v}}_{i}$得到的${mn}$元向量。$\mathcal{G}\left( f\right)$的参数是$n \times  {mn}$实矩阵${M}_{f}$和$n$维向量${N}_{f}$。

The grounding of an $m$ -ary predicate $P$ , namely $\mathcal{G}\left( P\right)$ , is defined as a generalization of the neural tensor network (which has been shown effective at knowledge completion in the presence of simple logical constraints [28]), as a function from ${\mathbb{R}}^{mn}$ to $\left\lbrack  {0,1}\right\rbrack$ , as follows:

一个$m$元谓词$P$的基替换，即$\mathcal{G}\left( P\right)$，被定义为神经张量网络(已被证明在存在简单逻辑约束的情况下对知识补全有效[28])的推广，是一个从${\mathbb{R}}^{mn}$到$\left\lbrack  {0,1}\right\rbrack$的函数，定义如下:

$$
\mathcal{G}\left( P\right) \left( \mathbf{v}\right)  = \sigma \left( {{u}_{P}^{\top }\tanh \left( {{\mathbf{v}}^{\top }{W}_{P}^{\left\lbrack  1 : k\right\rbrack  }\mathbf{v} + {V}_{P}\mathbf{v} + {b}_{P}}\right) }\right)  \tag{3}
$$

with $\sigma$ the sigmoid function. The parameters for $P$ are: ${W}_{P}^{\left\lbrack  1 : k\right\rbrack  }$ , a 3-D tensor in ${\mathbb{R}}^{k \times  {mn} \times  {mn}},{V}_{P} \in  {\mathbb{R}}^{k \times  {mn}},{b}_{P} \in  {\mathbb{R}}^{k}$ and ${u}_{P} \in  {\mathbb{R}}^{k}$ . This last parameter performs a linear combination of the quadratic features given by the tensor product. With this encoding, the grounding (i.e. truth-value) of a clause can be determined by a neural network which first computes the grounding of the literals contained in the clause, and then combines them using the specific t-norm.

其中$\sigma$是Sigmoid函数。$P$的参数为:${W}_{P}^{\left\lbrack  1 : k\right\rbrack  }$，一个位于${\mathbb{R}}^{k \times  {mn} \times  {mn}},{V}_{P} \in  {\mathbb{R}}^{k \times  {mn}},{b}_{P} \in  {\mathbb{R}}^{k}$和${u}_{P} \in  {\mathbb{R}}^{k}$中的三维张量。最后一个参数对由张量积给出的二次特征进行线性组合。通过这种编码，子句的基替换(即真值)可以由一个神经网络确定，该网络首先计算子句中包含的文字的基替换，然后使用特定的t - 范数将它们组合起来。

In what follows, we describe how a suitable GT can be built for SII. Let ${Pic}{s}^{t} \subseteq$ Pics be a set of bounding boxes of images correctly labelled with the classes that they belong to, and let each pair of bounding boxes be correctly labelled with the part-of relation. In machine learning terminology, ${\operatorname{Pics}}^{t}$ is a training set without noise. In real semantics, a training set can be represented by a theory ${\mathcal{T}}_{\text{expl }} = \left\langle  {{\mathcal{K}}_{\text{expl }},\widehat{\mathcal{G}}}\right\rangle$ , where ${\mathcal{K}}_{\text{expl }}$ contains the set of closed literals ${C}_{i}\left( b\right)$ (resp. $\neg {C}_{i}\left( b\right)$ ) and partOf $\left( {b,{b}^{\prime }}\right)$ (resp. $\neg \operatorname{partOf}\left( {b,{b}^{\prime }}\right)$ ), for every bounding box $b$ labelled (resp. not labelled) with ${C}_{i}$ and for every pair of bounding boxes $\left\langle  {b,{b}^{\prime }}\right\rangle$ connected (resp-partOf $\left( {b,{b}^{\prime }}\right)$ . not connected) by the partOf relation. The partial grounding $\widehat{\mathcal{G}}$ is defined on all bounding boxes of all the images in Pics where both the semantic features $\operatorname{class}\left( {{C}_{i}, b}\right)$ and the bounding box coordinates are computed by the Fast R-CNN object detector [11]. $\widehat{\mathcal{G}}$ is not defined for the predicate symbols in $\mathcal{P}$ and is to be learned. ${\mathcal{T}}_{\text{expl }}$ contains only assertional information about specific bounding boxes. This is the classical setting of machine learning where classifiers (i.e. the grounding of predicates) are inductively learned from positive examples (such as $\operatorname{partOf}\left( {b,{b}^{\prime }}\right)$ ) and negative examples $\left( {\neg \operatorname{partOf}\left( {b,{b}^{\prime }}\right) }\right)$ of a classification. In this learning setting, mereological constraints such as "cats have no wheels" or "a tail is a part of a cat" are not taken into account. Examples of mereological constraints state, for instance, that the part-of relation is asymmetric $\left( {\forall {xy}\left( {\operatorname{partOf}\left( {x, y}\right)  \rightarrow  \neg \operatorname{partOf}\left( {y, x}\right) }\right) }\right)$ , or lists the several parts of an object (e.g. $\forall {xy}\left( {\operatorname{Cat}\left( x\right)  \land  \operatorname{partOf}\left( {x, y}\right)  \rightarrow  \operatorname{Tail}\left( y\right)  \vee  \operatorname{Muzzle}\left( y\right) }\right)$ ), or even, for simplicity, that every whole object cannot be part of another object (e.g. $\forall {xy}\left( {\operatorname{Cat}\left( x\right)  \rightarrow  \neg \operatorname{partOf}\left( {x, y}\right) }\right) )$ and every part object cannot be divided further into parts (e.g. $\forall {xy}\left( {\operatorname{Tail}\left( x\right)  \rightarrow  \neg \operatorname{partOf}\left( {y, x}\right) }\right)$ ). This general knowledge is available from on-line resources, such as WORDNET [9], and can be retrieved by inheriting the meronymy relations for every concept correponding to a whole object. A grounded theory that considers also mereological constraints as prior knowledge can be constructed by adding such axioms to ${\mathcal{K}}_{\text{expl. }}$ . More formally, we define ${\mathcal{T}}_{\text{prior }} = \left\langle  {{\mathcal{K}}_{\text{prior }},\widehat{\mathcal{G}}}\right\rangle$ , where ${\mathcal{K}}_{\text{prior }} = {\mathcal{K}}_{\text{expl }} + \mathcal{M}$ , and $\mathcal{M}$ is the set of mereological axioms. To check the role of $\mathcal{M}$ , we evaluate both theories and then compare results.

接下来，我们将描述如何为语义图像解释(SII)构建合适的基础理论(GT)。设 ${Pic}{s}^{t} \subseteq$ Pics 为一组图像的边界框集合，这些边界框已正确标注所属类别，并且每对边界框都已正确标注部分 - 整体关系。在机器学习术语中，${\operatorname{Pics}}^{t}$ 是一个无噪声的训练集。在实际语义中，训练集可以用一个理论 ${\mathcal{T}}_{\text{expl }} = \left\langle  {{\mathcal{K}}_{\text{expl }},\widehat{\mathcal{G}}}\right\rangle$ 表示，其中 ${\mathcal{K}}_{\text{expl }}$ 包含封闭文字 ${C}_{i}\left( b\right)$(分别对应 $\neg {C}_{i}\left( b\right)$)和部分 - 整体关系 partOf $\left( {b,{b}^{\prime }}\right)$(分别对应 $\neg \operatorname{partOf}\left( {b,{b}^{\prime }}\right)$)，对于每个标注(或未标注)为 ${C}_{i}$ 的边界框 $b$，以及通过部分 - 整体关系连接(或未连接)的每对边界框 $\left\langle  {b,{b}^{\prime }}\right\rangle$。部分基础实例 $\widehat{\mathcal{G}}$ 定义在 Pics 中所有图像的所有边界框上，其中语义特征 $\operatorname{class}\left( {{C}_{i}, b}\right)$ 和边界框坐标均由快速区域卷积神经网络(Fast R - CNN)目标检测器 [11] 计算得出。$\widehat{\mathcal{G}}$ 未针对 $\mathcal{P}$ 中的谓词符号进行定义，需要进行学习。${\mathcal{T}}_{\text{expl }}$ 仅包含关于特定边界框的断言信息。这是机器学习的经典设置，其中分类器(即谓词的基础实例)是从分类的正例(如 $\operatorname{partOf}\left( {b,{b}^{\prime }}\right)$)和反例 $\left( {\neg \operatorname{partOf}\left( {b,{b}^{\prime }}\right) }\right)$ 中归纳学习得到的。在这种学习设置中，诸如“猫没有轮子”或“尾巴是猫的一部分”之类的分体论约束并未被考虑在内。分体论约束的示例表明，例如，部分 - 整体关系是不对称的 $\left( {\forall {xy}\left( {\operatorname{partOf}\left( {x, y}\right)  \rightarrow  \neg \operatorname{partOf}\left( {y, x}\right) }\right) }\right)$，或者列出对象的多个部分(例如 $\forall {xy}\left( {\operatorname{Cat}\left( x\right)  \land  \operatorname{partOf}\left( {x, y}\right)  \rightarrow  \operatorname{Tail}\left( y\right)  \vee  \operatorname{Muzzle}\left( y\right) }\right)$)，甚至为简单起见，每个整体对象不能是另一个对象的一部分(例如 $\forall {xy}\left( {\operatorname{Cat}\left( x\right)  \rightarrow  \neg \operatorname{partOf}\left( {x, y}\right) }\right) )$)，并且每个部分对象不能再进一步划分为部分(例如 $\forall {xy}\left( {\operatorname{Tail}\left( x\right)  \rightarrow  \neg \operatorname{partOf}\left( {y, x}\right) }\right)$)。这种通用知识可以从在线资源(如 WordNet [9])中获取，并且可以通过继承与每个整体对象对应的概念的部分 - 整体关系来检索。通过将这些公理添加到 ${\mathcal{K}}_{\text{expl. }}$ 中，可以构建一个将分体论约束作为先验知识考虑的基础理论。更正式地说，我们定义 ${\mathcal{T}}_{\text{prior }} = \left\langle  {{\mathcal{K}}_{\text{prior }},\widehat{\mathcal{G}}}\right\rangle$，其中 ${\mathcal{K}}_{\text{prior }} = {\mathcal{K}}_{\text{expl }} + \mathcal{M}$，并且 $\mathcal{M}$ 是分体论公理的集合。为了检验 $\mathcal{M}$ 的作用，我们对这两个理论进行评估，然后比较结果。

![0195da50-a427-740e-8718-7b1d7af02143_8_393_383_1005_513_0.jpg](images/0195da50-a427-740e-8718-7b1d7af02143_8_393_383_1005_513_0.jpg)

Figure 1: Precision-recall curves for indoor objects type classification and the partOf relation between objects.

图1:室内物体类型分类以及物体间partOf关系的精确率 - 召回率曲线。

## 5 Experimental Evaluation

## 5 实验评估

We evaluate the performance of our approach for ${\mathrm{{SU}}}^{4}$ on two tasks, namely, the classification of bounding boxes and the detection of partOf relations between pairs of bounding boxes. In particular, we chose the part-of relation because both data (the PASCAL-PART-dataset [5]) and ontologies (WORDNET) are available on the part-of relation. In addition, part-of can be used to represent, via reification, a large class of relations [12] (e.g., the relation "a plant is lying on the table" can be reified in an object of type "lying event" whose parts are the plant and the table). However, it is worth noting that many other relations could have been included in this evaluation. The time complexity of LTN grows linearly with the number of axioms.

我们在两项任务上评估了我们针对${\mathrm{{SU}}}^{4}$的方法的性能，即边界框的分类以及边界框对之间partOf关系的检测。特别地，我们选择部分 - 整体关系(part - of relation)是因为关于该关系既有可用的数据(PASCAL - PART数据集 [5])，也有可用的本体(WORDNET)。此外，通过具体化，部分 - 整体关系可用于表示一大类关系 [12](例如，“植物放在桌子上”这一关系可以具体化为一个类型为“放置事件”的对象，其组成部分是植物和桌子)。然而，值得注意的是，本评估本可以纳入许多其他关系。模糊逻辑张量网络(LTN)的时间复杂度随公理数量呈线性增长。

We also evaluate the robustness of our approach with respect to noisy data. It has been acknowledged by many that, with the vast growth in size of the training sets for visual recognition [15], many data annotations may be affected by noise such as missing or erroneous labels, non-localised objects, and disagreements between annotations, e.g. human annotators often mistake "part-of" for the "have" relation [24].

我们还评估了我们的方法在处理噪声数据方面的鲁棒性。许多人已经认识到，随着视觉识别训练集规模的大幅增长 [15]，许多数据标注可能会受到噪声的影响，如缺失或错误的标签、未定位的对象以及标注之间的不一致，例如人类标注者经常将“部分 - 整体”关系误判为“拥有”关系 [24]。

We use the PASCAL-PART-dataset that contains 10103 images with bounding boxes annotated with object-types and the part-of relation defined between pairs of bounding boxes. Labels are divided into three main groups: animals, vehicles and indoor objects, with their corresponding parts and "part-of" label. Whole objects inside the same group can share parts. Whole objects of different groups do not share any parts. Labels for parts are very specific, e.g. "left lower leg". Thus, without loss of generality, we have merged the bounding boxes that referred to the same part into a single bounding box, e.g. bounding boxes labelled with "left lower leg" and "left upper leg" were merged into a single bounding box of type "leg". In this way, we have limited our experiments to a dataset with 20 labels for whole objects and 39 labels for parts. In addition, we have removed from the dataset any bounding boxes with height or width smaller than 6 pixels. The images were then split into a training set with ${80}\%$ , and a test set with ${20}\%$ of the images, maintaining the same proportion of the number of bounding boxes for each label.

我们使用PASCAL - PART数据集，该数据集包含10103张带有边界框的图像，这些边界框标注了对象类型以及边界框对之间定义的部分 - 整体关系。标签分为三个主要组:动物、车辆和室内物体，以及它们相应的部分和“部分 - 整体”标签。同一组内的完整对象可以共享部分。不同组的完整对象不共享任何部分。部分的标签非常具体，例如“左小腿”。因此，在不失一般性的情况下，我们将指代同一部分的边界框合并为一个单一的边界框，例如，标注为“左小腿”和“左大腿”的边界框被合并为一个类型为“腿”的单一边界框。通过这种方式，我们将实验限制在一个包含20个完整对象标签和39个部分标签的数据集上。此外，我们从数据集中移除了所有高度或宽度小于6像素的边界框。然后，这些图像被划分为一个包含${80}\%$图像的训练集和一个包含${20}\%$图像的测试集，同时保持每个标签的边界框数量比例相同。

---

${}^{4}$ LTN has been implemented as a Google TENSORFLOW ${}^{TM}$ library. Code, partOf ontology, and dataset are available at https://gitlab.fbk.eu/donadello/LTN_IJCAI17

${}^{4}$ 模糊逻辑张量网络(LTN)已作为谷歌张量流(Google TENSORFLOW)${}^{TM}$库实现。代码、partOf本体和数据集可在https://gitlab.fbk.eu/donadello/LTN_IJCAI17获取。

---

Object Type Classification and Detection of the Part-Of Relation: Given a set of bounding boxes detected by an object detector (we use Fast-RCNN), the task of object classification is to assign to each bounding box an object type. The task of Part-Of detection is to decide, given two bounding boxes, if the object contained in the first is a part of the object contained in the second. We use LTN to resolve both tasks simultaneously. This is important because a bounding box type and the part-of relation are not independent. Their dependencies are specified in LTN using background knowledge in the form of logical axioms.

对象类型分类和部分 - 整体关系检测:给定一组由对象检测器(我们使用Fast - RCNN)检测到的边界框，对象分类任务是为每个边界框分配一个对象类型。部分 - 整体关系检测任务是在给定两个边界框的情况下，判断第一个边界框中包含的对象是否是第二个边界框中包含的对象的一部分。我们使用模糊逻辑张量网络(LTN)同时解决这两个任务。这很重要，因为边界框类型和部分 - 整体关系并非相互独立。它们之间的依赖关系在模糊逻辑张量网络(LTN)中使用逻辑公理形式的背景知识来指定。

To show the effect of the logical axioms, we train two LTNs: the first containing only training examples of object types and part-of relations $\left( {\mathcal{T}}_{\text{expl }}\right)$ , and the second containing also logical axioms about types and part-of $\left( {\mathcal{T}}_{\text{prior }}\right)$ . The LTNs were set up with tensor of $k = 6$ layers and a regularization parameter $\lambda  = {10}^{-{10}}$ . We chose Lukasiewicz’s T-norm $\left( {\mu \left( {a, b}\right)  = \max \left( {0, a + b - 1}\right) }\right)$ and use the harmonic mean as aggregation operator. We ran 1000 training epochs of the RMSProp learning algorithm available in TENSORFLOW ${}^{TM}$ . We compare results with the Fast RCNN at object type classification (Eq. 1), and the inclusion ratio ir baseline (Eq.eq:grBpof) at the part-of detection task ${}^{5}$ . If ${ir}$ is larger than a given threshold ${th}$ (in our experiments, ${th} = {0.7}$ ) then the bounding boxes are said to be in the partOf relation. Every bounding box $b$ is classified into $C \in  {\mathcal{P}}_{1}$ if $\mathcal{G}\left( {C\left( b\right) }\right)  \geq  {th}$ . With this, a bounding box can be classified into more than one class. For each class, precision and recall are calculated in the usual way. Results for indoor objects are shown in Figure 1 where AUC is the area under the precision-recall curve. The results show that, for both object types and the part-of relation, the LTN trained with prior knowledge given by mereological axioms has better performance than the LTN trained with examples only. Moreover, prior knowledge allows LTN to improve the performance of the Fast R-CNN (FRCNN) object detector. Notice that the LTN is trained using the Fast R-CNN results as features. FRCNN assigns a bounding box to a class if the values of the corresponding semantic features exceed ${th}$ . This is local to the specific semantic features. If such local features are very discriminative (which is the case in our experiments) then very good levels of precision can be achieved. Differently from FRCNN, LTNs make a global choice which takes into consideration all (semantic and geometric) features together. This should offer robustness to the LTN classifier at the price of a drop in precision. The logical axioms compensate this drop. For the other object types (animals and vehicles), LTN has results comparable to FRCNN: FRCNN beats ${\mathcal{T}}_{\text{prior }}$ by 0.05 and 0.037 AUC, respectively, for animals and vehicles. Finally, we have performed an initial experiment on small data, on the assumption that the LTN axioms should be able to compensate a reduction in training data. By removing ${50}\%$ of the training data for indoor objects, a similar performance to ${\mathcal{T}}_{\text{prior }}$ with the full training set can be achieved: ${0.767}\mathrm{{AUC}}$ for object types and 0.623 AUC for the part-of relation, which shows an improvement in performance.

为了展示逻辑公理的效果，我们训练了两个模糊逻辑张量网络(LTN):第一个仅包含对象类型和部分-整体关系的训练示例$\left( {\mathcal{T}}_{\text{expl }}\right)$，第二个还包含关于类型和部分-整体关系的逻辑公理$\left( {\mathcal{T}}_{\text{prior }}\right)$。这些模糊逻辑张量网络使用$k = 6$层的张量和正则化参数$\lambda  = {10}^{-{10}}$进行设置。我们选择了卢卡西维茨T范数$\left( {\mu \left( {a, b}\right)  = \max \left( {0, a + b - 1}\right) }\right)$，并使用调和平均值作为聚合算子。我们运行了1000个训练周期的均方根传播(RMSProp)学习算法，该算法可在TensorFlow中使用${}^{TM}$。我们将对象类型分类的结果与快速区域卷积神经网络(Fast RCNN)进行比较(公式1)，并将部分检测任务的结果与包含率基线(公式eq:grBpof)进行比较${}^{5}$。如果${ir}$大于给定的阈值${th}$(在我们的实验中为${th} = {0.7}$)，则称这些边界框处于部分-整体(partOf)关系。如果$\mathcal{G}\left( {C\left( b\right) }\right)  \geq  {th}$，则每个边界框$b$被分类为$C \in  {\mathcal{P}}_{1}$。这样，一个边界框可以被分类到多个类别中。对于每个类别，按照常规方式计算精确率和召回率。室内对象的结果如图1所示，其中AUC是精确率-召回率曲线下的面积。结果表明，对于对象类型和部分-整体关系，使用分体论公理给出的先验知识训练的模糊逻辑张量网络比仅使用示例训练的模糊逻辑张量网络具有更好的性能。此外，先验知识使模糊逻辑张量网络能够提高快速区域卷积神经网络(FRCNN)对象检测器的性能。请注意，模糊逻辑张量网络使用快速区域卷积神经网络的结果作为特征进行训练。如果相应语义特征的值超过${th}$，快速区域卷积神经网络会将一个边界框分配给一个类别。这是特定于语义特征的局部操作。如果这些局部特征具有很强的区分性(在我们的实验中就是这种情况)，那么可以实现非常高的精确率水平。与快速区域卷积神经网络不同，模糊逻辑张量网络会进行全局选择，同时考虑所有(语义和几何)特征。这应该会使模糊逻辑张量网络分类器具有鲁棒性，但代价是精确率会有所下降。逻辑公理可以弥补这种下降。对于其他对象类型(动物和车辆)，模糊逻辑张量网络的结果与快速区域卷积神经网络相当:快速区域卷积神经网络在动物和车辆的AUC上分别比${\mathcal{T}}_{\text{prior }}$高0.05和0.037。最后，我们在小数据集上进行了初步实验，假设模糊逻辑张量网络公理应该能够弥补训练数据的减少。通过去除室内对象训练数据的${50}\%$，可以实现与使用完整训练集的${\mathcal{T}}_{\text{prior }}$相似的性能:对象类型的AUC为${0.767}\mathrm{{AUC}}$，部分-整体关系的AUC为0.623，这表明性能有所提高。

---

${}^{5}$ A direct comparison with [4] is not possible because their code was not available.

${}^{5}$ 无法与文献[4]进行直接比较，因为他们的代码未公开。

---

Robustness to Noisy Training Data: In this evaluation, we show that logical axioms improve the robustness of LTNs in the presence of errors in the labels of the training data. We have added an increasing amount of noise to the PASCAL-PART-dataset training data, and measured how performance degrades in the presence and absence of axioms. For $k \in  \{ {10},{20},{30},{40}\}$ , we randomly select $k\%$ of the bounding boxes in the training data, and randomly change their classification labels. In addition, we randomly select $k\%$ of pairs of bounding boxes, and flip the value of the part-of relation’s label. For each value of $k$ , we train LTNs ${\mathcal{T}}_{\text{expl }}^{k}$ and ${\mathcal{T}}_{\text{prior }}^{k}$ and evaluate results on both SII tasks as done before. As expected, adding too much noise to training labels leads to a large drop in performance. Figure 2 shows the AUC measures for indoor objects with increasing error $k$ . Each pair of bars indicates the AUC of ${\mathcal{T}}_{\text{prior }}^{k},{\mathcal{T}}_{\text{expl }}^{k}$ , for a given $k\%$ of errors. Results indicate that the LTN axioms offer robustness to noise: in addition to the expected overall drop in performance, an increasing gap can be seen between the drop in performance of the LTN trained with exampels only and the LTN trained including background knowledge.

对噪声训练数据的鲁棒性:在本次评估中，我们表明逻辑公理能够提升模糊逻辑张量网络(LTNs)在训练数据标签存在误差时的鲁棒性。我们在PASCAL - PART数据集的训练数据中添加了逐渐增多的噪声，并测量了在有公理和没有公理的情况下性能的下降情况。对于$k \in  \{ {10},{20},{30},{40}\}$，我们随机选择训练数据中$k\%$的边界框，并随机更改它们的分类标签。此外，我们随机选择$k\%$的边界框对，并翻转部分关系标签的值。对于$k$的每个值，我们训练模糊逻辑张量网络${\mathcal{T}}_{\text{expl }}^{k}$和${\mathcal{T}}_{\text{prior }}^{k}$，并像之前一样在两个语义图像解释(SII)任务上评估结果。正如预期的那样，在训练标签中添加过多的噪声会导致性能大幅下降。图2显示了随着误差$k$增加，室内物体的曲线下面积(AUC)测量值。每对条形图表示给定$k\%$误差下${\mathcal{T}}_{\text{prior }}^{k},{\mathcal{T}}_{\text{expl }}^{k}$的AUC。结果表明，模糊逻辑张量网络公理对噪声具有鲁棒性:除了预期的整体性能下降外，可以看到仅使用示例训练的模糊逻辑张量网络和包含背景知识训练的模糊逻辑张量网络在性能下降方面的差距越来越大。

## 6 Conclusion and Future Work

## 6 结论与未来工作

SII systems are required to address the semantic gap problem: combining visual low-level features with high-level concepts. We argue that the problem can be addressed by the integration of numerical and logical representations in deep learning. LTNs learn from numerical data and logical constraints, enabling approximate reasoning on unseen data to predict new facts. In this paper, LTNs were shown to improve on state-of-the-art method Fast R-CNN for bounding box classification, and to outperform a rule-based method at learning part-of relations in the PASCAL-PART-dataset. Moreover, LTNs were evaluated on how to handle noisy data through the systematic creation of training sets with errors in the labels. Results indicate that relational knowledge can add robustness to neural systems. As future work, we shall apply LTNs to larger datasets such as VISUAL GENOME, and continue to compare the various instances of LTN with SRL, deep learning and other neural-symbolic approaches on such challenging visual intelligence tasks.

语义图像解释(SII)系统需要解决语义鸿沟问题:将视觉低级特征与高级概念相结合。我们认为，通过在深度学习中集成数值和逻辑表示可以解决这个问题。模糊逻辑张量网络从数值数据和逻辑约束中学习，能够对未见数据进行近似推理以预测新事实。在本文中，模糊逻辑张量网络在边界框分类任务上优于最先进的快速区域卷积神经网络(Fast R - CNN)方法，并且在PASCAL - PART数据集中学习部分关系方面优于基于规则的方法。此外，我们通过系统地创建标签存在误差的训练集，评估了模糊逻辑张量网络处理噪声数据的能力。结果表明，关系知识可以增强神经系统的鲁棒性。作为未来的工作，我们将把模糊逻辑张量网络应用于更大的数据集，如视觉基因组(VISUAL GENOME)，并继续在具有挑战性的视觉智能任务上比较模糊逻辑张量网络的各种实例与统计关系学习(SRL)、深度学习和其他神经符号方法。

![0195da50-a427-740e-8718-7b1d7af02143_11_580_543_601_1116_0.jpg](images/0195da50-a427-740e-8718-7b1d7af02143_11_580_543_601_1116_0.jpg)

Figure 2: AUCs for indoor object types and part-of relation with increasing noise in the labels of the training data. The drop in performance is noticiably smaller for the LTN trained with background knowledge.

图2:随着训练数据标签中噪声的增加，室内物体类型和部分关系的曲线下面积(AUC)。使用背景知识训练的模糊逻辑张量网络的性能下降明显更小。

## References

## 参考文献

[1] J. Atif, C. Hudelot, and I Bloch. Explanatory reasoning for image understanding using formal concept analysis and description logics. Systems, Man, and Cybernetics: Systems, IEEE Transactions on, 44(5):552-570, May 2014.

[1] J. Atif、C. Hudelot和I Bloch。使用形式概念分析和描述逻辑进行图像理解的解释性推理。《系统、人与控制论:系统》，IEEE汇刊，44(5):552 - 570，2014年5月。

[2] S. H. Bach, M. Broecheler, B. Huang, and L. Getoor. Hinge-loss markov random fields and probabilistic soft logic. CoRR, abs/1505.04406, 2015.

[2] S. H. Bach、M. Broecheler、B. Huang和L. Getoor。铰链损失马尔可夫随机场和概率软逻辑。计算机研究报告，abs/1505.04406，2015年。

[3] M. Bergmann. An Introduction to Many-Valued and Fuzzy Logic: Semantics, Algebras, and Derivation Systems. Cambridge University Press, 2008.

[3] M. Bergmann。多值和模糊逻辑导论:语义、代数和推导系统。剑桥大学出版社，2008年。

[4] N. Chen, Q.-Y. Zhou, and V. Prasanna. Understanding web images by object relation network. In Proceedings of the 21st International Conference on World Wide Web, WWW '12, pages 291-300, New York, NY, USA, 2012. ACM.

[4] N. Chen、Q. - Y. Zhou和V. Prasanna。通过对象关系网络理解网络图像。《第21届万维网国际会议论文集》，WWW '12，第291 - 300页，美国纽约州纽约市，2012年。美国计算机协会。

[5] X. Chen, R. Mottaghi, X. Liu, S. Fidler, R. Urtasun, and A. Yuille. Detect what you can: Detecting and representing objects using holistic models and body parts. In ${CVPR},{2014}$ .

[5] X. Chen、R. Mottaghi、X. Liu、S. Fidler、R. Urtasun和A. Yuille。检测你能检测的:使用整体模型和身体部位检测和表示对象。见${CVPR},{2014}$。

[6] S. Dasiopoulou, Y. Kompatsiaris, and M.I G. Strintzis. Applying fuzzy dls in the extraction of image semantics. J. Data Semantics, 14:105-132, 2009.

[6] S. Dasiopoulou、Y. Kompatsiaris和M.I G. Strintzis。在图像语义提取中应用模糊描述逻辑。《数据语义学杂志》，14:105 - 132，2009年。

[7] Michelangelo Diligenti, Marco Gori, and Claudio Saccà. Semantic-based regularization for learning and inference. Artificial Intelligence, 2015.

[7] Michelangelo Diligenti、Marco Gori和Claudio Saccà。基于语义的学习和推理正则化。《人工智能》，2015年。

[8] I. Donadello and L. Serafini. Integration of numeric and symbolic information for semantic image interpretation. Intelligenza Artificiale, 10(1):33-47, 2016.

[8] I. 多纳代洛(I. Donadello)和 L. 塞拉菲尼(L. Serafini)。用于语义图像解释的数值和符号信息集成。《人工智能》(Intelligenza Artificiale)，10(1):33 - 47，2016 年。

[9] C. Fellbaum, editor. WordNet: an electronic lexical database. MIT Press, 1998.

[9] C. 费尔鲍姆(C. Fellbaum) 编。《词网:电子词汇数据库》(WordNet: an electronic lexical database)。麻省理工学院出版社(MIT Press)，1998 年。

[10] G. Forestier, C. Wemmert, and A. Puissant. Coastal image interpretation using background knowledge and semantics. Computers & Geosciences, 54:88-96, 2013.

[10] G. 福雷斯蒂耶(G. Forestier)、C. 韦默特(C. Wemmert)和 A. 皮桑(A. Puissant)。利用背景知识和语义进行海岸图像解释。《计算机与地球科学》(Computers & Geosciences)，54:88 - 96，2013 年。

[11] R. Girshick. Fast r-cnn. In International Conference on Computer Vision (ICCV), 2015.

[11] R. 吉尔希克(R. Girshick)。快速区域卷积神经网络(Fast r - cnn)。见 2015 年国际计算机视觉会议(International Conference on Computer Vision，ICCV)。

[12] N. Guarino and G. Guizzardi. On the reification of relationships. In 24th Italian Symp. on Advanced Database Sys., pages 350-357, 2016.

[12] N. 瓜里诺(N. Guarino)和 G. 吉扎尔迪(G. Guizzardi)。关于关系的具体化。见第 24 届意大利高级数据库系统研讨会(24th Italian Symp. on Advanced Database Sys.)，第 350 - 357 页，2016 年。

[13] B. Gutmann, M. Jaeger, and L. De Raedt. Extending problog with continuous distributions. In Proc. ILP, pages 76-91. Springer, 2010.

[13] B. 古特曼(B. Gutmann)、M. 耶格(M. Jaeger)和 L. 德·雷德特(L. De Raedt)。用连续分布扩展概率逻辑程序(Extending problog with continuous distributions)。见《归纳逻辑编程会议论文集》(Proc. ILP)，第 76 - 91 页。施普林格出版社(Springer)，2010 年。

[14] C. Hudelot, J. Atif, and I. Bloch. Fuzzy spatial relation ontology for image interpretation. Fuzzy Sets and Systems, 159(15):1929-1951, 2008.

[14] C. 于德洛(C. Hudelot)、J. 阿蒂夫(J. Atif)和 I. 布洛赫(I. Bloch)。用于图像解释的模糊空间关系本体。《模糊集与系统》(Fuzzy Sets and Systems)，159(15):1929 - 1951，2008 年。

[15] R. Krishna, Y. Zhu, O. Groth, J. Johnson, K. Hata, J. Kravitz, S. Chen, Y. Kalan-tidis, L.-L. Li, D. Shamma, M. Bernstein, and Li F.-F. Visual genome: Connecting language and vision using crowdsourced dense image annotations, 2016.

[15] R. 克里希纳(R. Krishna)、Y. 朱(Y. Zhu)、O. 格罗思(O. Groth)、J. 约翰逊(J. Johnson)、K. 哈塔(K. Hata)、J. 克拉维茨(J. Kravitz)、S. 陈(S. Chen)、Y. 卡兰 - 蒂迪斯(Y. Kalantidis)、L. - L. 李(L. - L. Li)、D. 沙马(D. Shamma)、M. 伯恩斯坦(M. Bernstein)和李菲菲(Li F. - F.)。视觉基因组:利用众包密集图像注释连接语言和视觉，2016 年。

[16] G.h Kulkarni, V. Premraj, S. Dhar, S. Li, Y. Choi, A. C. Berg, and T. L. Berg. Baby talk: Understanding and generating image descriptions. In CVPR, 2011.

[16] G. h. 库尔卡尼(G. h. Kulkarni)、V. 普雷姆拉吉(V. Premraj)、S. 达尔(S. Dhar)、S. 李(S. Li)、Y. 崔(Y. Choi)、A. C. 伯格(A. C. Berg)和 T. L. 伯格(T. L. Berg)。婴儿语言:理解和生成图像描述。见 2011 年计算机视觉与模式识别会议(CVPR)。

[17] C. Lu, R. Krishna, M. Bernstein, and L Fei-Fei. Visual relationship detection with language priors. In ${ECCV}$ , pages ${852} - {869},{2016}$ .

[17] C. 陆(C. Lu)、R. 克里希纳(R. Krishna)、M. 伯恩斯坦(M. Bernstein)和李菲菲(L Fei - Fei)。利用语言先验进行视觉关系检测。见 ${ECCV}$ ，第 ${852} - {869},{2016}$ 页。

[18] M. Marszalek and C. Schmid. Semantic Hierarchies for Visual Object Recognition. In ${CVPR},{2007}$ .

[18] M. 马尔沙莱克(M. Marszalek)和 C. 施密德(C. Schmid)。用于视觉对象识别的语义层次结构。见 ${CVPR},{2007}$ 。

[19] B. Neumann and R. Möller. On scene interpretation with description logics. Image and Vision Computing, 26(1):82 - 101, 2008. Cognitive Vision-Special Issue.

[19] B. 诺伊曼(Neumann)和 R. 默勒(Möller)。使用描述逻辑进行场景解释。《图像与视觉计算》(Image and Vision Computing)，26(1):82 - 101，2008 年。认知视觉特刊。

[20] D. Nyga, F. Balint-Benczedi, and M. Beetz. Pr2 looking at things-ensemble learning for unstructured information processing with markov logic networks. In IEEE Intl. Conf.on Robotics and Automation, pages 3916-3923, 2014.

[20] D. 尼加(Nyga)、F. 巴林特 - 本采迪(Balint - Benczedi)和 M. 贝茨(Beetz)。PR2 观察事物——使用马尔可夫逻辑网络进行非结构化信息处理的集成学习。见《电气与电子工程师协会国际机器人与自动化会议论文集》，第 3916 - 3923 页，2014 年。

[21] I. S. Espinosa Peraldi, A. Kaya, and R. Möller. Formalizing multimedia interpretation based on abduction over description logic aboxes. In Proc. of the 22nd Intl. Workshop on Description Logics, volume 477 of CEUR Workshop Proceedings. CEUR-WS.org, 2009.

[21] I. S. 埃斯皮诺萨·佩拉尔迪(I. S. Espinosa Peraldi)、A. 卡亚(A. Kaya)和 R. 默勒(R. Möller)。基于描述逻辑 ABox 上溯因推理的多媒体解释形式化。见《第 22 届国际描述逻辑研讨会论文集》，CEUR 研讨会会议录第 477 卷。CEUR - WS.org，2009 年。

[22] V. Ramanathan, C. Li, J. Deng, W. Han, Z. Li, K. Gu, Y. Song, S. Bengio, C. Rosenberg, and L. Fei-Fei. Learning semantic relationships for better action retrieval in images. In ${CVPR},{2015}$ .

[22] V. 拉马纳坦(V. Ramanathan)、C. 李(C. Li)、J. 邓(J. Deng)、W. 韩(W. Han)、Z. 李

[23] I. Ravkic, J. Ramon, and J. Davis. Learning relational dependency networks in hybrid domains. Machine Learning, 100(2-3):217-254, 2015.

[23] I. 拉夫基奇(I. Ravkic)、J. 拉蒙(J. Ramon)和 J. 戴维斯(J. Davis)。混合领域中关系依赖网络的学习。《机器学习》(Machine Learning)，100(2 - 3):217 - 254，2015 年。

[24] S. Reed, H. Lee, D. Anguelov, C. Szegedy, D. Erhan, and A. Rabinovich. Training deep neural networks on noisy labels with bootstrapping. CoRR, abs/1412.6596, 2014.

[24] S. 里德(S. Reed)、H. 李(H. Lee)、D. 安格洛夫(D. Anguelov)、C. 塞格迪(C. Szegedy)、D. 埃尔汉(D. Erhan)和 A. 拉比诺维奇(A. Rabinovich)。利用自举法在含噪标签上训练深度神经网络。计算机研究报告(CoRR)，编号 abs/1412.6596，2014 年。

[25] M. Richardson and P. Domingos. Markov logic networks. Machine Learning, 62(1-2):107-136, 2006.

[25] M. 理查森(Richardson)和 P. 多明戈斯(Domingos)。马尔可夫逻辑网络。《机器学习》，62(1 - 2):107 - 136，2006 年。

[26] T. Rocktaschel, S. Singh, and S. Riedel. Injecting logical background knowledge into embeddings for relation extraction. In ${NAACL},{2015}$ .

[26] T. 罗克塔舍尔(T. Rocktaschel)、S. 辛格(S. Singh)和 S. 里德尔(S. Riedel)。将逻辑背景知识融入关系抽取的嵌入表示中。见${NAACL},{2015}$。

[27] L. Serafini and A. S. d'Avila Garcez. Learning and reasoning with logic tensor networks. In Proc. AI*IA, pages 334-348, 2016.

[27] L. 塞拉菲尼(L. Serafini)和 A. S. 达维拉·加尔塞斯(A. S. d'Avila Garcez)。使用逻辑张量网络进行学习和推理。见《人工智能与应用国际会议论文集》(Proc. AI*IA)，第 334 - 348 页，2016 年。

[28] R. Socher, D. Chen, C. D. Manning, and A. Ng. Reasoning with neural tensor networks for knowledge base completion. In Advances in Neural Information Processing Systems, pages 926-934, 2013.

[28] R. 索切尔(R. Socher)、D. 陈(D. Chen)、C. D. 曼宁(C. D. Manning)和 A. 吴恩达(A. Ng)。使用神经张量网络进行知识库补全推理。见《神经信息处理系统进展》，第 926 - 934 页，2013 年。

[29] J. Wang and P. Domingos. Hybrid markov logic networks. In AAAI, volume 8, pages 1106-1111, 2008.

[29] 王(Wang)和多明戈斯(Domingos)。混合马尔可夫逻辑网络(Hybrid markov logic networks)。见《美国人工智能协会会议论文集》(AAAI)，第8卷，第1106 - 1111页，2008年。

[30] Y. Zhu, A. Fathi, and L. Fei-Fei. Reasoning about object affordances in a knowledge base representation. In ${ECCV}$ , pages 408-424. 2014.

[30] 朱(Zhu)、法提(Fathi)和李菲菲(Fei-Fei)。知识库表示中对象可供性的推理。见${ECCV}$，第408 - 424页。2014年。