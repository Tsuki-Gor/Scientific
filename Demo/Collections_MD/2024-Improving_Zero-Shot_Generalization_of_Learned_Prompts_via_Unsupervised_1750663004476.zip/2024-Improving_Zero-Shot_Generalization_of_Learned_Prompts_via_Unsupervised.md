# Improving Zero-shot Generalization of Learned Prompts via Unsupervised Knowledge Distillation

# 通过无监督知识蒸馏提升学习提示的零样本泛化能力

*Marco Mistretta ${}^{1}$ O,*Alberto Baldrati ${}^{1,2}$ O,

*Marco Mistretta ${}^{1}$ O,*Alberto Baldrati ${}^{1,2}$ O,

Marco Bertini ${}^{1}$ , and Andrew D. Bagdanov ${}^{1}$

Marco Bertini ${}^{1}$ ，和 Andrew D. Bagdanov ${}^{1}$

${}^{1}$ University of Florence - Media Integration and Communication Center (MICC)

${}^{1}$ 佛罗伦萨大学 - 媒体整合与传播中心(MICC)

${}^{2}$ University of Pisa

${}^{2}$ 比萨大学

Florence, Italy - Pisa, Italy

意大利佛罗伦萨 - 意大利比萨

\{name.surname\}@unifi.it

\{name.surname\}@unifi.it

Abstract. Vision-Language Models (VLMs) demonstrate remarkable zero-shot generalization to unseen tasks, but fall short of the performance of supervised methods in generalizing to downstream tasks with limited data. Prompt learning is emerging as a parameter-efficient method for adapting VLMs, but state-of-the-art approaches require annotated samples. In this paper we propose a novel approach to prompt learning based on unsupervised knowledge distillation from more powerful models. Our approach, which we call Knowledge Distillation Prompt Learning (KDPL), can be integrated into existing prompt learning techniques and eliminates the need for labeled examples during adaptation. Our experiments on more than ten standard benchmark datasets demonstrate that KDPL is very effective at improving generalization of learned prompts for zero-shot domain generalization, zero-shot cross-dataset generalization, and zero-shot base-to-novel class generalization problems. KDPL requires no ground-truth labels for adaptation, and moreover we show that even in the absence of any knowledge of training class names (CA-KDPL) can be used to effectively transfer knowledge. The code is publicly available at https://github.com/miccunifi/KDPL

摘要。视觉-语言模型(Vision-Language Models, VLMs)在未见任务上的零样本泛化表现出色，但在有限数据的下游任务泛化方面仍不及监督方法。提示学习作为一种参数高效的VLM适应方法正在兴起，但现有最先进方法依赖标注样本。本文提出一种基于更强大模型的无监督知识蒸馏的新型提示学习方法。我们的方法称为知识蒸馏提示学习(Knowledge Distillation Prompt Learning, KDPL)，可集成于现有提示学习技术中，且在适应过程中无需标注样本。我们在十余个标准基准数据集上的实验表明，KDPL在零样本领域泛化、零样本跨数据集泛化及零样本基础类到新类泛化问题上均显著提升了学习提示的泛化能力。KDPL无需适应时的真实标签，且我们进一步展示即使在完全不了解训练类别名称的情况下(CA-KDPL)，该方法仍能有效传递知识。代码公开于 https://github.com/miccunifi/KDPL

Keywords: Prompt Learning - Unsupervised Knowledge Distillation - Vision-Language Models - Few-Shot Learning - Zero-shot Transfer.

关键词:提示学习 - 无监督知识蒸馏 - 视觉-语言模型 - 少样本学习 - 零样本迁移。

## 1 Introduction

## 1 引言

Vision-Language Models (VLMs) like Contrastive Language-Image Pre-training (CLIP) are remarkably effective at zero-shot generalization to downstream tasks 3,42,44,66. These models leverage a dual encoder architecture and are trained to align image and text features in a shared embedding space. CLIP and similar models are able to perform zero-shot classification by predicting the output class based on the similarity between the test image embedding and text embeddings of words from a fixed vocabulary.

视觉-语言模型(Vision-Language Models, VLMs)，如对比语言-图像预训练(Contrastive Language-Image Pre-training, CLIP)，在下游任务的零样本泛化方面表现卓越[3,42,44,66]。这些模型采用双编码器架构，训练目标是将图像和文本特征对齐到共享的嵌入空间。CLIP及类似模型通过计算测试图像嵌入与固定词汇文本嵌入的相似度，实现零样本分类。

---

* These authors contributed equally to this work.

* 这些作者对本工作贡献相同。

---

![bo_d1c3l9bef24c73d2ojn0_1_385_330_1038_462_0.jpg](images/bo_d1c3l9bef24c73d2ojn0_1_385_330_1038_462_0.jpg)

Fig. 1: Motivation and overview. (Top left) Lightweight VLMs like CLIP achieve impressive zero-shot performance but lag behind supervised approaches; large VLMs incur a high computational burden. (Bottom left) Parameter-efficient prompt learning offers a non-destructive approach to adapting VLMs to downstream tasks; however, existing methods require annotated samples and struggle to generalize to unseen classes. (Right) Our approach does not require labeled samples and learns by distilling knowledge from a more powerful VLM. It can be seamlessly integrated into existing prompt learning techniques and generalizes better to unseen classes on downstream tasks.

图1:动机与概览。(左上)轻量级VLM如CLIP实现了令人印象深刻的零样本性能，但仍落后于监督方法；大型VLM计算负担重。(左下)参数高效的提示学习为VLM适应下游任务提供了一种非破坏性方法；然而现有方法依赖标注样本，且难以泛化到未见类别。(右)我们的方法无需标注样本，通过从更强大的VLM蒸馏知识进行学习。该方法可无缝集成到现有提示学习技术中，并在下游任务中对未见类别表现出更好的泛化能力。

While CLIP exhibits remarkable zero-shot performance, it can fall short of supervised adaptation. Narrowing this gap through fine-tuning is challenging when large training datasets are not available for downstream tasks. Moreover, fine-tuning can also lead to overfitting and is destructive in that it can cause the model to forget knowledge acquired during large-scale pre-training [14,68].

尽管CLIP展现了卓越的零样本性能，但在监督适应方面仍有不足。当下游任务缺乏大规模训练数据时，通过微调缩小这一差距具有挑战性。此外，微调可能导致过拟合，并且具有破坏性，可能使模型遗忘大规模预训练期间获得的知识[14,68]。

An intuitive way to achieve better performance is to use larger and more powerful VLMs [10] with better zero-shot generalization. However, though performance improves with increasing size, their practical applicability in real-world scenarios decreases. Lightweight CLIP models based on ResNet-50 and ViT-B/32 require about 18 and 14 GFLOPs for inference, respectively. In contrast, more powerful models based on ViT-H/14 10,18 require nearly ${30} \times$ the computation at 381 GFLOPs [18] for inference.

一种直观的提升性能方式是使用更大更强的VLM[10]，以获得更好的零样本泛化能力。然而，尽管模型规模增大性能提升，其在实际应用中的适用性却下降。基于ResNet-50和ViT-B/32的轻量级CLIP模型推理分别需约18和14 GFLOPs。相比之下，基于ViT-H/14的更强大模型[10,18]推理计算量高达381 GFLOPs[18]。

To address these challenges, parameter-efficient prompt learning is emerging as a promising and non-destructive approach to adapting VLMs to downstream tasks [34, 35, 65]. Zhou et al. [68] proposed a text-only prompt learning approach called CoOp to overcome the limitations of manually crafted prompts. Subsequently, Jia et al. [29] extended prompt learning to the visual domain with Visual Prompt Tuning (VPT), and Khattak et al. [30, 31] proposed a multi-modal prompt learning approach called MaPLe [30] and a self-regulated approach called PromptSRC [31]. Although significantly improving over carefully tuned, handcrafted prompts, these state-of-the-art techniques all require annotated samples from the dataset and have problems generalizing to other datasets or classes unseen during training $\left\lbrack  {{30},{67}}\right\rbrack$ .

为应对这些挑战，参数高效的提示学习作为一种有前景且非破坏性的VLM适应下游任务方法正在兴起[34,35,65]。Zhou等人[68]提出了仅基于文本的提示学习方法CoOp，以克服手工设计提示的局限。随后，Jia等人[29]将提示学习扩展至视觉领域，提出视觉提示调优(Visual Prompt Tuning, VPT)；Khattak等人[30,31]提出了多模态提示学习方法MaPLe[30]及自我调节方法PromptSRC[31]。尽管这些最先进技术显著优于精心调试的手工提示，但均依赖数据集的标注样本，且在泛化到训练时未见的数据集或类别时存在困难$\left\lbrack  {{30},{67}}\right\rbrack$。

To eliminate the need for labeled training examples and improve the generalization of learned prompts, we propose a novel approach to prompt learning which we call Knowledge Distillation Prompt Learning (KDPL). KDPL adapts lightweight VLMs and improves performance on downstream tasks by distilling knowledge from a more powerful VLM without the need for annotated examples. KDPL is a flexible method that can be seamlessly integrated into existing prompt learning framework such as CoOp [68], CoCoOp [67], VPT [29], MaPLe 30, and PromptSRC 31. Figure 1 summarizes the motivations and illustrates the workflow of the proposed approach. We validate KDPL on two increasingly challenging scenarios: in the first, we assume knowledge of training class names, while in the second we assume no knowledge of training classes. Importantly, in both scenarios no annotated training samples are used.

为消除对标注训练样本的依赖并提升学习提示的泛化能力，我们提出了一种新颖的提示学习方法，称为知识蒸馏提示学习(Knowledge Distillation Prompt Learning，KDPL)。KDPL通过从更强大的视觉语言模型(VLM)中蒸馏知识，适配轻量级VLM，并提升下游任务的性能，无需注释样本。KDPL是一种灵活的方法，可无缝集成到现有的提示学习框架中，如CoOp [68]、CoCoOp [67]、VPT [29]、MaPLe [30]和PromptSRC [31]。图1总结了该方法的动机并展示了工作流程。我们在两个逐渐增加难度的场景中验证了KDPL:第一种假设已知训练类别名称，第二种则假设未知训练类别。重要的是，在这两种场景中均未使用任何标注训练样本。

The contributions of this work are:

本工作的贡献包括:

- we propose a novel parameter-efficient prompt-learning approach that eliminates the need for labeled training examples by distilling knowledge from a large Vision-Language Model;

- 我们提出了一种新颖的参数高效提示学习方法，通过从大型视觉语言模型蒸馏知识，消除了对标注训练样本的需求；

- we show that our approach can be integrated into existing prompt learning techniques to learn visual, textual, and multimodal prompts which generalize significantly better than state-of-the-art baselines to unseen classes in downstream tasks;

- 我们展示了该方法可集成到现有提示学习技术中，学习视觉、文本及多模态提示，在下游任务中对未见类别的泛化能力显著优于最先进的基线；

- we demonstrate the effectiveness of our approach through extensive experiments on more than ten standard benchmark datasets covering a broad range of downstream problems, including domain generalization, cross-dataset adaptation, and base-to-novel generalization; and

- 我们通过在十多个标准基准数据集上的广泛实验验证了该方法的有效性，涵盖领域泛化、跨数据集适应及基础到新颖类别的泛化等多种下游问题；

- we introduce a new, class agnostic evaluation setting in which training class names are unknown and show the superiority of our approach in this scenario.

- 我们引入了一种新的类别无关评估设置，即训练类别名称未知，并展示了该方法在此场景下的优越性。

To the best of our knowledge ours is the first approach to parameter-efficient VLM adaptation which is applicable in scenarios that are label agnostic (i.e. no label supervision is required during adaptation) and also in scenarios that are additionally class agnostic (i.e. no knowledge of training class names is assumed).

据我们所知，本方法是首个适用于参数高效VLM适配的方案，既适用于标签无关(即适配过程中无需标签监督)场景，也适用于额外类别无关(即不假设训练类别名称已知)场景。

## 2 Related Work

## 2 相关工作

In this section we review the recent literature most relevant to our contribution.

本节回顾与我们贡献最相关的最新文献。

Vision-Language Models. Vision-Language Models (VLMs) learn robust visual representations thanks to their extensive pre-training on image-caption datasets 47, 48 . These representations are very effective at generalizing to a variety of downstream tasks [13, 28, 44]. In contrast to vision models trained only with image supervision, vision-language models can interpret both visual and textual data, showing improvement in tasks requiring cross-model understanding $\left\lbrack  {3,4,{52}}\right\rbrack$ . We focus on contrastively-trained VLMs such as CLIP [44, ALIGN [28], and LiT [61]. These models use a dual encoder architecture and contrastive learning to align images and text in a common embedding space. Thanks to this shared embedding space and massive pre-training datasets these models achieve remarkable performance. However, there is still a gap between the zero-shot capabilities of these VLMs and the performance of tailored state-of-the-art models [15, 44], and thus there is active research on efficient and effective methods to adapt VLMs to downstream tasks [21,38,55,62].

视觉语言模型。视觉语言模型(VLMs)通过在图像-字幕数据集47, 48上的大规模预训练，学习了鲁棒的视觉表征。这些表征在多种下游任务中表现出极强的泛化能力[13, 28, 44]。与仅用图像监督训练的视觉模型不同，视觉语言模型能够理解视觉和文本数据，在需要跨模态理解的任务中表现更佳$\left\lbrack  {3,4,{52}}\right\rbrack$。我们关注对比学习训练的VLM，如CLIP [44]、ALIGN [28]和LiT [61]。这些模型采用双编码器架构和对比学习，将图像与文本对齐到共同的嵌入空间。得益于共享的嵌入空间和大规模预训练数据集，这些模型取得了卓越性能。然而，这些VLM的零样本能力与定制的最先进模型[15, 44]之间仍存在差距，因此针对高效且有效地将VLM适配到下游任务的研究仍在积极进行[21,38,55,62]。

Prompt Learning. The performance of VLMs is highly dependent on textual prompts used to characterize downstream tasks. Given the significant impact of small changes in wording on performance, the manual generation of optimal textual prompts is a challenging task. Inspired by developments in NLP 34,35, 65, CoOp [68] proposes to learn continuous vectors in the word embedding space instead of using tailored hand-crafted prompts.

提示学习。VLM的性能高度依赖于用于描述下游任务的文本提示。由于措辞的细微变化对性能影响显著，手工设计最优文本提示是一项挑战。受自然语言处理(NLP)领域34,35,65的启发，CoOp [68]提出在词嵌入空间中学习连续向量，替代手工设计的提示。

The promising results of $\mathrm{{CoOp}}$ have attracted considerable interest in prompt learning for VLMs [1, 2, 7, 8, 30, 31, 37, 49, 50, 58, 69]. CoCoOp, in particular, highlights the poor performance of $\mathrm{{CoOp}}$ on unseen classes and uses image-conditional dynamic prompts to improve generalization [67]. PLOT [8] instead is based on learning multiple prompts by exploiting local visual features. Kg-CoOp 58 adds a regularization loss to minimize the discrepancy between learned and hand-crafted prompts, while VPT [29] adapts prompt learning to the visual domain by learning continuous vectors in the input space of a ViT [16]. Finally, MaPLe [30] introduces a multimodal prompt learning strategy for VLMs. PromptSRC [31] introduces a self-regularization framework for prompting, addressing overfitting through agreement with a frozen model, a self-ensemble of prompts, and textual diversity.

$\mathrm{{CoOp}}$的良好效果引发了对VLM提示学习的广泛关注[1, 2, 7, 8, 30, 31, 37, 49, 50, 58, 69]。其中，CoCoOp特别指出$\mathrm{{CoOp}}$在未见类别上的表现较差，采用基于图像条件的动态提示以提升泛化能力[67]。PLOT [8]则通过利用局部视觉特征学习多个提示。Kg-CoOp [58]增加正则化损失以最小化学习提示与手工提示的差异，而VPT [29]通过在ViT [16]的输入空间中学习连续向量，将提示学习适配到视觉领域。最后，MaPLe [30]提出了视觉语言模型的多模态提示学习策略。PromptSRC [31]引入了自我正则化框架，通过与冻结模型的一致性、自我集成提示及文本多样性，解决了过拟合问题。

Similar to the approach we propose in this paper, UPL [27] performs prompt learning without relying on annotated samples. It leverages pseudolabels derived from a larger CLIP model and selects the top-K most confident samples per class to construct a balanced set of pseudo-labels. UPL requires a substantial collection of unlabeled images and is not directly applicable when only a few unlabeled samples are available, like in the few-shot adaptation scenarios considered here. In contrast to UPL, KDPL does not use pseudolabeling; instead, we directly learn from the logits of a CLIP teacher model via knowledge distillation, thus eliminating the need for any selection strategy of the training samples.

与本文提出的方法类似，UPL [27] 在不依赖标注样本的情况下进行提示学习。它利用来自更大CLIP模型的伪标签，并为每个类别选择置信度最高的前K个样本，以构建平衡的伪标签集。UPL需要大量未标注图像，当只有少量未标注样本可用时(如本文考虑的少样本适应场景)，其方法不适用。与UPL不同，KDPL不使用伪标签；相反，我们通过知识蒸馏直接从CLIP教师模型的logits中学习，从而无需对训练样本进行任何选择策略。

Knowledge Distillation. Knowledge distillation (KD) is a machine learning technique in which a simple model (student) is trained to mimic the behavior of a larger model (teacher) by learning from its output or intermediate activation [26]. This technique has found success in many contexts, including image classification [5, 9, 26], self-supervised learning [19, 57], and image/video segmentation [17, 22, 40, 51], leading to improvements in model compression, computational efficiency, and performance. DML [63] introduces a mutual learning approach to train students and teachers simultaneously. DKD [64] reformulates the classical KD loss into a term related to the target class and a term related to the non-target classes. In contrast to the majority of knowledge distillation approaches [59, 60, 63, 64], we do not utilize any labels during training. Instead, we solely employ the distillation loss. In our work, we apply knowledge distillation in a parameter-efficient prompt learning scenario. Specifically, we distill knowledge from a large and powerful VLM (teacher) into a lightweight VLM (student) by updating only a reduced number of parameters (the prompt).

知识蒸馏。知识蒸馏(Knowledge Distillation, KD)是一种机器学习技术，其中一个简单模型(学生)通过学习大型模型(教师)的输出或中间激活来模仿其行为[26]。该技术在多个领域取得成功，包括图像分类[5, 9, 26]、自监督学习[19, 57]以及图像/视频分割[17, 22, 40, 51]，提升了模型压缩、计算效率和性能。DML [63] 引入了同时训练学生和教师的互学习方法。DKD [64] 将经典的KD损失重新表述为与目标类别相关的项和非目标类别相关的项。与大多数知识蒸馏方法[59, 60, 63, 64]不同，我们在训练过程中不使用任何标签，仅采用蒸馏损失。在本工作中，我们在参数高效的提示学习场景中应用知识蒸馏。具体而言，我们通过仅更新少量参数(提示)将大型强力视觉语言模型(教师)的知识蒸馏到轻量级视觉语言模型(学生)中。

Techniques Using Teacher-Student Distillation. Recently Li et al. [36] introduced PromptKD which also uses teacher-student distillation in prompt learning. Although it too leverages a larger teacher to guide a smaller student, it differs from our contribution in several key aspects. PromptKD uses Prompt-SRC [31] to pre-train the teacher model with labeled examples, whereas KDPL does not pre-train the teacher and requires no labeled examples. PromptKD uses an MLP to project the student image encoder output, which adds extra parameters. KDPL is instead a general framework with no additional parameters, adaptable to any prompt-tuning technique to render them completely unsupervised. Moreover, PromptKD uses the entire training set, including both base and novel images, for distillation. In contrast, KDPL follows the standard 16-shot setting.

使用师生蒸馏的技术。近期Li等人[36]提出了PromptKD，也在提示学习中使用师生蒸馏。虽然它同样利用更大的教师指导较小的学生，但在几个关键方面与我们的工作不同。PromptKD使用Prompt-SRC [31]通过带标签样本预训练教师模型，而KDPL不预训练教师且不需要标签样本。PromptKD使用多层感知机(MLP)投影学生图像编码器输出，增加了额外参数。KDPL则是一个无额外参数的通用框架，可适配任何提示调优技术，实现完全无监督。此外，PromptKD使用包括基础和新颖图像的整个训练集进行蒸馏，而KDPL遵循标准的16-shot设置。

## 3 Knowledge Distillation Prompt Learning (KDPL)

## 3 知识蒸馏提示学习(KDPL)

We first introduce preliminary concepts related to prompt learning and then describe our approach to applying knowledge distillation to the problem.

我们首先介绍与提示学习相关的基础概念，然后描述我们将知识蒸馏应用于该问题的方法。

### 3.1 Preliminaries

### 3.1 基础知识

Our approach is based on knowledge distillation applied to prompt learning. Here we discuss the base teacher and student models (CLIPs) and five state-of-the-art prompt learning approaches into which we will incorporate KDPL.

我们的方法基于应用于提示学习的知识蒸馏。这里我们讨论基础的教师和学生模型(CLIP)以及五种最先进的提示学习方法，后续将把KDPL整合进这些方法中。

CLIP. Contrastive Language-Image Pre-training (CLIP) is a vision-language model trained to align images and textual captions in shared semantic space [44. CLIP consists of an image encoder ${f}_{\theta }$ and a text encoder ${g}_{\phi }$ . Given an image $\bar{I}$ , the image encoder computes its feature representation ${f}_{\theta }\left( I\right)  \in  {\mathbb{R}}^{d}$ , where $d$ is the size of the semantic embedding space. Similarly, for a given textual caption $Y$ , a word embedding layer ${E}_{L}$ maps each tokenized word to the token embedding space $\mathcal{W}$ . Then, the text encoder ${g}_{\phi }$ generates the textual feature representation ${g}_{\phi }\left( {{E}_{L}\left( Y\right) }\right)  \in  {\mathbb{R}}^{d}$ . The main goal of CLIP training is to learn $\theta$ and $\phi$ such that ${f}_{\theta }\left( I\right)  \approx  {g}_{\phi }\left( {{E}_{L}\left( Y\right) }\right)$ for associated image/text pairs(I, Y).

CLIP。对比语言-图像预训练(Contrastive Language-Image Pre-training, CLIP)是一种视觉语言模型，训练目标是将图像和文本标题对齐到共享的语义空间[44]。CLIP由图像编码器${f}_{\theta }$和文本编码器${g}_{\phi }$组成。给定一张图像$\bar{I}$，图像编码器计算其特征表示${f}_{\theta }\left( I\right)  \in  {\mathbb{R}}^{d}$，其中$d$是语义嵌入空间的维度。类似地，对于给定的文本标题$Y$，词嵌入层${E}_{L}$将每个分词映射到词元嵌入空间$\mathcal{W}$。然后，文本编码器${g}_{\phi }$生成文本特征表示${g}_{\phi }\left( {{E}_{L}\left( Y\right) }\right)  \in  {\mathbb{R}}^{d}$。CLIP训练的主要目标是学习$\theta$和$\phi$，使得对于相关联的图像/文本对(I, Y)，${f}_{\theta }\left( I\right)  \approx  {g}_{\phi }\left( {{E}_{L}\left( Y\right) }\right)$成立。

When using a Vision Transformer (ViT) [16] as the visual encoder ${f}_{\theta }$ , the encoding process begins by splitting the image into $U$ fixed-size patches. These patches are then projected into patch embeddings $\left\{  {{w}_{1},{w}_{2},\ldots ,{w}_{U}}\right\}$ , where each ${w}_{i}$ belongs to the patch embedding space $\mathcal{V}$ . A learnable class (CLS) token ${c}_{i}$ is concatenated with the patch embeddings, resulting in the input to the vision transformer being $\left\{  {{c}_{i},{w}_{1},{w}_{2},\ldots ,{w}_{U}}\right\}$ . Finally, the CLS token of the final transformer layer is projected to the shared embedding space via a linear projection to obtain the final representation.

使用视觉变换器(Vision Transformer，ViT)[16]作为视觉编码器时，编码过程首先将图像分割成固定大小的图像块。这些图像块随后被投影到图像块嵌入空间，其中每个图像块属于该嵌入空间。一个可学习的类别(CLS)标记与图像块嵌入拼接，形成视觉变换器的输入。最后，最终变换器层的CLS标记通过线性投影映射到共享嵌入空间，以获得最终表示。

To perform zero-shot classification using CLIP, we start with an image $I$ and build a set of textual prompts ${\left\{  {Y}_{i}\right\}  }_{i = 1}^{C}$ , where $C$ denotes the number of classes. Each handcrafted text prompt ${Y}_{i}$ takes the format " $a$ photo of a [CLASS ${S}_{i}$ ]", where ${\mathrm{{CLASS}}}_{i}$ represents a specific class name, such as airplane, bird, etc.

为了使用CLIP进行零样本分类，我们从一张图像开始，构建一组文本提示，其中表示类别数量。每个手工设计的文本提示格式为“[CLASS]的照片”，其中代表特定类别名称，如飞机、鸟类等。

Then the feature representations ${\psi }_{I} = {f}_{\theta }\left( I\right)$ and ${\psi }_{T}^{i} = {g}_{\phi }\left( {{E}_{L}\left( {Y}_{i}\right) }\right)$ are extracted using the CLIP encoders. The predicted probability for each class is:

然后使用CLIP编码器提取特征表示。每个类别的预测概率为:

$$
p\left( {y = i \mid  I}\right)  = \frac{\exp \left( {\cos \left( {{\psi }_{T}^{i},{\psi }_{I}}\right) /\tau }\right) }{\mathop{\sum }\limits_{{j = 1}}^{C}\exp \left( {\cos \left( {{\psi }_{T}^{j},{\psi }_{I}}\right) /\tau }\right) }, \tag{1}
$$

where $\cos \left( {\cdot , \cdot  }\right)$ is the cosine similarity and $\tau$ is a temperature hyperparameter.

其中是余弦相似度， 是温度超参数。

Prompt-Learning Techniques. Here we summarize how the state-of-the-art techniques for textual, visual, and multimodal prompt learning work.

提示学习技术。这里我们总结了文本、视觉和多模态提示学习的最新技术是如何工作的。

- CoOp [68] is a textual prompt learning technique that learns continuous context tokens (i.e. the learnable prompt) in the CLIP token embedding space. Specifically, $\operatorname{CoOp}$ introduces $M$ learnable vectors, $\left\{  {{v}_{1},{v}_{2},\ldots ,{v}_{M}}\right\}$ where each context vector ${v}_{i} \in  \mathcal{W}$ . For each of the $k$ classes of a dataset, the input to the text encoder is $\left\{  {{v}_{1},{v}_{2},\ldots ,{v}_{M},{c}_{k}}\right\}$ , where ${c}_{k} = {E}_{L}\left( \left\lbrack  {{CLAS}{S}_{k}}\right\rbrack  \right)$ .

- CoOp [68]是一种文本提示学习技术，在CLIP的标记嵌入空间中学习连续的上下文标记(即可学习的提示)。具体来说，引入了可学习向量，其中每个上下文向量。对于数据集中的每个类别，文本编码器的输入是，其中。

- CoCoOp [67] extends CoOp by incorporating a lightweight network ${h}_{\theta }$ . Each context token is obtained as ${v}_{i}\left( I\right)  = {v}_{i} + \pi$ , where $\pi  = {h}_{\theta }\left( I\right)$ . This method ensures that the textual prompts are conditioned on the input image.

- CoCoOp [67]通过引入一个轻量级网络扩展了CoOp。每个上下文标记被表示为，其中。这种方法确保文本提示依赖于输入图像。

- VPT [29] is a visual prompt learning method that can be viewed as the counterpart of $\mathrm{{CoOp}}$ in the visual domain. Unlike $\mathrm{{CoOp}}$ , which operates entirely in the textual token embedding space $\mathcal{W}$ , VPT performs prompt learning in the visual patch embedding space $\mathcal{V}$ . Specifically, VPT learns $P$ visual tokens, leading to the input to the ViT being $\left\{  {{z}_{1},\ldots ,{z}_{P},{c}_{i},{w}_{1},{w}_{2},\ldots ,{w}_{U}}\right\}$ . VPT offers two prompting variants: deep and shallow. The deep variant learns a distinct prompt for each ViT layer, while the shallow variant incorporates the prompt parameters only into the input of the first layer.

- VPT [29]是一种视觉提示学习方法，可视为CoOp在视觉领域的对应物。与完全在文本标记嵌入空间中操作的CoOp不同，VPT在视觉图像块嵌入空间中进行提示学习。具体来说，VPT学习视觉标记，导致ViT的输入为。VPT提供两种提示变体:深层和浅层。深层变体为每个ViT层学习独立的提示，而浅层变体仅将提示参数融入第一层的输入。

- MaPLe [30] is a deep multi-modal prompt learning technique that promotes strong coupling between vision and language prompts. In practice, MaPLe learns different textual context tokens for each layer in ${g}_{\phi }$ . The visual prompts, on the other hand, are not directly learned but are obtained through a linear mapping from the textual ones.

- MaPLe [30] 是一种深度多模态提示学习技术，促进视觉和语言提示之间的紧密耦合。实际上，MaPLe 为 ${g}_{\phi }$ 中的每一层学习不同的文本上下文标记。另一方面，视觉提示不是直接学习得到的，而是通过从文本提示线性映射获得的。

- PromptSRC [31] is another multi-modal prompt learning technique that optimizes prompts through mutual agreement maximization between prompted and frozen model features using self-distillation, Gaussian-weighted prompt aggregation over the training session, and promoting textual diversity to address sample diversity imbalance.

- PromptSRC [31] 是另一种多模态提示学习技术，通过自我蒸馏、训练过程中基于高斯权重的提示聚合以及促进文本多样性来优化提示，以实现提示模型特征与冻结模型特征之间的相互一致性最大化，从而解决样本多样性不平衡问题。

Note that methods involving visual prompt learnable tokens like VPT [29], MaPLe [30], and PromptSRC [31] can only be applied to VLMs equipped with a ViT-based image encoder.

注意，涉及可学习视觉提示标记的方法，如 VPT [29]、MaPLe [30] 和 PromptSRC [31]，仅能应用于配备基于 ViT(视觉变换器)图像编码器的视觉语言模型(VLM)。

### 3.2 Label Agnostic Prompt Learning

### 3.2 标签无关提示学习

The methods described above all rely on ground-truth labels during adaptation. Here we show how unsupervised knowledge distillation can be used instead to replace the need for annotated training examples.

上述方法均依赖于适应过程中的真实标签。这里我们展示如何使用无监督知识蒸馏来替代对带注释训练样本的需求。

![bo_d1c3l9bef24c73d2ojn0_6_395_331_1010_305_0.jpg](images/bo_d1c3l9bef24c73d2ojn0_6_395_331_1010_305_0.jpg)

Fig. 2: Knowledge Distillation Prompt Learning (KDPL) overview. Given a lightweight VLM student and a larger, more powerful VLM teacher, KDPL updates the student prompt parameters by distilling knowledge from the teacher. KDPL first performs zero-shot classification with the teacher to obtain teacher probabilities ${p}_{T}$ . It then computes the student probabilities ${p}_{S}$ and performs knowledge distillation to update the student prompt parameters $\gamma$ .

图 2:知识蒸馏提示学习(KDPL)概览。给定一个轻量级视觉语言模型学生和一个更大更强的视觉语言模型教师，KDPL 通过从教师蒸馏知识来更新学生的提示参数。KDPL 首先使用教师进行零样本分类以获得教师概率 ${p}_{T}$ 。然后计算学生概率 ${p}_{S}$ 并执行知识蒸馏以更新学生提示参数 $\gamma$ 。

Overview. Our proposed approach, which we call Knowledge Distillation Prompt Learning (KDPL), is a general method designed to enhance the performance of the CLIP model on downstream tasks through parameter-efficient prompt learning. Unlike previous approaches [30,67,68], which rely on labeled examples for training, KDPL eliminates the need for manually-labeled samples by learning only through knowledge distillation from a larger and more powerful VLM. Note that KDPL is a method that can be seamlessly integrated with any existing prompt learning approach in scenarios where no information about class names or labels is available.

概览。我们提出的方法称为知识蒸馏提示学习(KDPL)，是一种通用方法，旨在通过参数高效的提示学习提升 CLIP 模型在下游任务中的表现。与依赖带标签样本训练的先前方法 [30,67,68] 不同，KDPL 通过仅从更大更强的视觉语言模型蒸馏知识，消除了对人工标注样本的需求。注意，KDPL 是一种可无缝集成到任何现有提示学习方法中的技术，适用于无类别名称或标签信息的场景。

We validate KDPL in two progressively challenging supervision regimes. In the label agnostic scenario we do not use ground-truth labels, but we assume knowledge of the class names in the training dataset. In the class agnostic scenario (see Section 3.3) we go one step further and assume that even the training class names are unknown. For this class agnostic scenario we propose an effective and efficient online strategy for automatically filtering the classes from a large dictionary of approximately ${20}\mathrm{\;K}$ class names [33].

我们在两个逐步增加难度的监督环境中验证 KDPL。在标签无关场景中，我们不使用真实标签，但假设已知训练数据集中的类别名称。在类别无关场景(见第 3.3 节)中，我们更进一步，假设甚至训练类别名称也未知。针对该类别无关场景，我们提出了一种高效且有效的在线策略，用于从包含约 ${20}\mathrm{\;K}$ 个类别名称的庞大词典 [33] 中自动筛选类别。

Prompt Learning via Unsupervised Knowledge Distillation (KDPL). Given a lightweight CLIP model (the student) and a larger, more powerful CLIP model (the teacher), we aim to improve the downstream performance of the student model by distilling knowledge from teacher to student. For an image $I$ and a set of classes $\mathcal{C} = {\left\{  {\mathrm{{CLASS}}}_{i}\right\}  }_{i = 1}^{C}$ , we start by performing zero-shot classification using the frozen teacher model. Specifically, we use the teacher image encoder ${f}_{\theta }^{B}$ and text encoder ${g}_{\phi }^{B}$ to compute the teacher image features ${\psi }_{I, B} = {f}_{\theta }^{B}\left( I\right)$ and text features ${\psi }_{T, B}^{i} = {g}_{\phi }^{S}\left( {{E}_{L}\left( \left\lbrack  {\mathrm{{CLASS}}}_{i}\right\rbrack  \right) }\right)$ . For the teacher model we use the fixed text prompt "a photo of [CLASS]". We then apply Eq. (1) to produce the probabilities ${p}_{T}\left( {I,\mathcal{C}}\right)$ predicted by the teacher on image $I$ for classes $\mathcal{C}$ .

通过无监督知识蒸馏进行提示学习(KDPL)。给定一个轻量级 CLIP 模型(学生)和一个更大更强的 CLIP 模型(教师)，我们旨在通过从教师向学生蒸馏知识来提升学生模型的下游性能。对于图像 $I$ 和一组类别 $\mathcal{C} = {\left\{  {\mathrm{{CLASS}}}_{i}\right\}  }_{i = 1}^{C}$ ，我们首先使用冻结的教师模型执行零样本分类。具体地，我们使用教师的图像编码器 ${f}_{\theta }^{B}$ 和文本编码器 ${g}_{\phi }^{B}$ 计算教师的图像特征 ${\psi }_{I, B} = {f}_{\theta }^{B}\left( I\right)$ 和文本特征 ${\psi }_{T, B}^{i} = {g}_{\phi }^{S}\left( {{E}_{L}\left( \left\lbrack  {\mathrm{{CLASS}}}_{i}\right\rbrack  \right) }\right)$ 。教师模型使用固定文本提示“a photo of [CLASS]”。然后我们应用公式(1)生成教师对图像 $I$ 在类别 $\mathcal{C}$ 上的预测概率 ${p}_{T}\left( {I,\mathcal{C}}\right)$ 。

The teacher model does not rely on a learnable prompt and its predictions remain fixed during training. Our aim is to learn text and image prompts for the student model that enhance its generalization to downstream tasks.

教师模型不依赖可学习提示，其预测在训练期间保持固定。我们的目标是为学生模型学习文本和图像提示，以增强其对下游任务的泛化能力。

We denote with ${f}_{\theta }^{S}$ and ${g}_{\phi }^{S}$ the student image and text encoders, respectively, and with $\gamma$ the parameters associated with the learnable student prompts (see Fig. 2). Given the same image $I$ processed by the teacher and the same set of classes $\mathcal{C}$ , the student extracts image features ${\psi }_{I, S} = {f}_{\theta ,\gamma }^{S}\left( I\right)$ and text features ${\psi }_{T, S}^{i} = {g}_{\phi ,\gamma }^{S}\left( {{E}_{L}\left( \left\lbrack  {\mathrm{{CLASS}}}_{i}\right\rbrack  \right) }\right)$ . Note that the text and image encoders can both depend on the prompt parameters $\gamma$ . According to the prompt learning technique used, the $\gamma$ parameters can be used only by the text encoder (CoOp, CoCoOp), the visual encoder (VPT), or both (MaPLe, PromptSRC). Finally, using Eq. (1) we produce student class probabilities ${p}_{S}\left( {I,\mathcal{C}}\right)$ predicted on image $I$ for classes $\mathcal{C}$ . Note that all encoder parameters except for the learnable prompt $\gamma$ are frozen.

我们分别用${f}_{\theta }^{S}$和${g}_{\phi }^{S}$表示学生图像编码器和文本编码器，用$\gamma$表示与可学习学生提示相关的参数(见图2)。给定教师处理的同一图像$I$和同一类别集合$\mathcal{C}$，学生提取图像特征${\psi }_{I, S} = {f}_{\theta ,\gamma }^{S}\left( I\right)$和文本特征${\psi }_{T, S}^{i} = {g}_{\phi ,\gamma }^{S}\left( {{E}_{L}\left( \left\lbrack  {\mathrm{{CLASS}}}_{i}\right\rbrack  \right) }\right)$。注意，文本和图像编码器都可以依赖提示参数$\gamma$。根据所使用的提示学习技术，$\gamma$参数可以仅被文本编码器使用(CoOp、CoCoOp)、视觉编码器使用(VPT)，或两者都使用(MaPLe、PromptSRC)。最后，利用公式(1)我们生成学生对图像$I$中类别$\mathcal{C}$的预测类别概率${p}_{S}\left( {I,\mathcal{C}}\right)$。注意，除可学习提示$\gamma$外，所有编码器参数均被冻结。

We use the symmetric KL-divergence between the teacher $\left( {{p}_{T}\left( {I,\mathcal{C}}\right) }\right)$ and the student $\left( {{p}_{S}\left( {I,\mathcal{C}}\right) }\right)$ probabilities in a distillation loss:

我们在蒸馏损失中使用教师$\left( {{p}_{T}\left( {I,\mathcal{C}}\right) }\right)$和学生$\left( {{p}_{S}\left( {I,\mathcal{C}}\right) }\right)$概率之间的对称KL散度:

$$
\mathcal{L}\left( {\mathcal{I},\mathcal{C}}\right)  = \left\lbrack  {{D}_{\mathrm{{KL}}}\left( {{p}_{T}\left( {I,\mathcal{C}}\right) \parallel {p}_{S}\left( {I,\mathcal{C}}\right) }\right)  + {D}_{\mathrm{{KL}}}\left( {{p}_{S}\left( {I,\mathcal{C}}\right) \parallel {p}_{T}\left( {I,\mathcal{C}}\right) }\right) }\right\rbrack  , \tag{2}
$$

where $D\left( {q\parallel p}\right)$ is the asymmetric KL-divergence between the discrete probability distributions $p$ and $q$ :

其中$D\left( {q\parallel p}\right)$是离散概率分布$p$和$q$之间的非对称KL散度:

$$
{D}_{\mathrm{{KL}}}\left( {p\parallel q}\right)  = \mathop{\sum }\limits_{{i \in  \mathcal{C}}}{p}_{i}\log \left( \frac{{p}_{i}}{{q}_{i}}\right)  \tag{3}
$$

This distillation loss depends only on the fixed predictions of the teacher, the prompt-conditioned predictions of the students, and the set of classes $\mathcal{C}$ .

该蒸馏损失仅依赖于教师的固定预测、学生基于提示的预测以及类别集合$\mathcal{C}$。

Importantly, our distillation loss does not assume any knowledge of class labels for image $I$ . Nor does it require that $\mathcal{C}$ be the classes of the downstream task - that is, KDPL can be used for Label Agnostic and Class Agnostic adaptation scenarios. We found in early experiments that the symmetric KL-divergence works slightly better than either asymmetric option (see Section B.3. in the Supplementary Material for an ablation study on this choice).

重要的是，我们的蒸馏损失不假设图像$I$的类别标签，也不要求$\mathcal{C}$必须是下游任务的类别——即KDPL可用于标签不可知和类别不可知的适应场景。我们在早期实验中发现，对称KL散度的效果略优于任一非对称选项(详见补充材料B.3节中的消融研究)。

### 3.3 Class Agnostic Prompt Learning

### 3.3 类别不可知提示学习

To further evaluate the generalization capabilities of KDPL, we introduce a scenario where not only do we not know the labels of training images (label agnostic, Section 3.2) but where we also do not even know the class names associated with the dataset (class agnostic). This scenario is considerably more challenging as we make no assumptions about the few-shot training data.

为了进一步评估KDPL的泛化能力，我们引入了一个场景，不仅训练图像的标签未知(标签不可知，见3.2节)，甚至数据集关联的类别名称也未知(类别不可知)。该场景更具挑战性，因为我们对少样本训练数据不做任何假设。

To address the unavailability of class names, we propose a strategy for automatically selecting a set of class names for each batch. We start with a large vocabulary of class names from which to select. Specifically, we use the Open Images V7 dataset [33], which contains $\sim  {20}\mathrm{\;K}$ classes. The most straightforward method would simply use all ${20}\mathrm{\;K}$ classes during training. However, this is impractical as the memory required by prompt learning methods increases linearly with the number of classes. According to Ren et al. 46, CoOp requires nearly 15MB of VRAM per class, resulting in approximately 300GB of memory when multiplied by ${20}\mathrm{\;K}$ classes. Therefore, we propose a method to automatically select which classes to use for each batch by retaining only the ones most relevant to the calculation of the loss in Eq. (2).

为解决类别名称不可用的问题，我们提出了一种自动为每个批次选择类别名称集合的策略。我们从一个包含大量类别名称的词汇表开始选择。具体来说，我们使用Open Images V7数据集[33]，其中包含$\sim  {20}\mathrm{\;K}$个类别。最直接的方法是在训练中使用所有${20}\mathrm{\;K}$个类别，但这不切实际，因为提示学习方法所需的显存随类别数线性增长。根据Ren等人[46]，CoOp每个类别约需15MB显存，乘以${20}\mathrm{\;K}$类别约需300GB显存。因此，我们提出一种方法，通过保留与公式(2)中损失计算最相关的类别，自动选择每个批次使用的类别。

Given a batch of images $X = {\left\{  {I}_{i}\right\}  }_{i = 1}^{N}$ and all the class names in the vocabulary $\mathcal{C} = {\left\{  {\mathrm{{CLASS}}}_{i}\right\}  }_{i = 1}^{C}$ , where $N$ represents the number of images in a batch and $C$ the size of the dictionary, we let the teacher model select the most relevant classes. Our objective is to identify the most useful $K$ classes in each batch for student prompt learning. After extracting the teacher image and text features, for each image ${I}_{i} \in  X$ , we apply Eq. (1) to obtain the teacher probabilities ${p}_{T}\left( {{I}_{i},\mathcal{C}}\right)$ . By stacking the probabilities along the batch dimension, we obtain the matrix ${P}_{T} = {\left\lbrack  {p}_{T}\left( {I}_{1},\mathcal{C}\right) ;\cdots ;{p}_{T}\left( {I}_{N},\mathcal{C}\right) \right\rbrack  }^{T} \in  {\mathbb{R}}^{N \times  C}$ , where the $i$ -th row corresponds to the probabilities associated with image ${I}_{i}$ . We then compute the average probabilities along the batch axis, resulting in $\overline{{P}_{T}} \in  {\mathbb{R}}^{C}$ . Finally, we select the classes corresponding to the $K$ highest values in $\overline{{P}_{T}}$ .

给定一批图像$X = {\left\{  {I}_{i}\right\}  }_{i = 1}^{N}$和词汇表中的所有类别名称$\mathcal{C} = {\left\{  {\mathrm{{CLASS}}}_{i}\right\}  }_{i = 1}^{C}$，其中$N$表示批次中的图像数量，$C$表示字典大小，我们让教师模型选择最相关的类别。我们的目标是识别每个批次中对学生提示学习最有用的$K$个类别。在提取教师图像和文本特征后，对于每张图像${I}_{i} \in  X$，我们应用公式(1)获得教师概率${p}_{T}\left( {{I}_{i},\mathcal{C}}\right)$。通过沿批次维度堆叠概率，我们得到矩阵${P}_{T} = {\left\lbrack  {p}_{T}\left( {I}_{1},\mathcal{C}\right) ;\cdots ;{p}_{T}\left( {I}_{N},\mathcal{C}\right) \right\rbrack  }^{T} \in  {\mathbb{R}}^{N \times  C}$，其中第$i$行对应于图像${I}_{i}$的概率。然后我们沿批次轴计算平均概率，得到$\overline{{P}_{T}} \in  {\mathbb{R}}^{C}$。最后，我们选择$\overline{{P}_{T}}$中对应于最高的$K$个值的类别。

Using the teacher model to perform this class filtering for each batch is feasible and does not incur excessive memory costs since the teacher requires no gradient computation. Therefore, the memory consumption does not depend on the number of classes in $\mathcal{C}$ . Conversely, although the student model remains frozen, gradients must still be propagated to update the prompt parameters $\gamma$ . Once the classes are selected, the training strategy remains the same as described above, with the only difference being that the class names observed by the student vary in each batch based on teacher predictions.

使用教师模型对每个批次执行此类别筛选是可行的，且不会产生过高的内存开销，因为教师模型不需要计算梯度。因此，内存消耗不依赖于$\mathcal{C}$中的类别数量。相反，尽管学生模型保持冻结状态，但仍需传播梯度以更新提示参数$\gamma$。一旦类别被选定，训练策略与上述描述保持一致，唯一的区别是学生观察到的类别名称在每个批次中根据教师预测而变化。

## 4 Experimental Results

## 4 实验结果

In this section we report on experiments validating our proposed approach.

本节报告验证我们所提方法的实验结果。

### 4.1 Evaluated Scenarios and Implementation Details

### 4.1 评估场景与实现细节

Following previous works [30,67,68], we validate KDPL in three distinct settings: 1) domain generalization; 2) cross-dataset transfer; 3) generalization to unseen classes. Additionally, to evaluate the scenario where class names are also unknown, we introduce a new evaluation setting we call class agnostic adaptation. We use the train/val/test splits and seeds provided by Zhou et al. [68] for all datasets. All reported results are averages over three independent runs.

继承先前工作[30,67,68]，我们在三种不同设置下验证KDPL:1)领域泛化；2)跨数据集迁移；3)对未见类别的泛化。此外，为评估类别名称未知的场景，我们引入了一个新的评估设置，称为类别无关适应。我们使用Zhou等人[68]提供的所有数据集的训练/验证/测试划分和随机种子。所有报告结果均为三次独立运行的平均值。

Evaluated Scenarios. We evaluate KDPL on the following scenarios:

评估场景。我们在以下场景中评估KDPL:

- Domain Generalization. To assess the ability of the learned prompts to generalize to out-of-distribution datasets, we apply the prompt learned from ImageNet 12 to four different versions of ImageNet datasets exhibiting various types of domain shift. The target datasets are ImageNetV2 [45], ImageNet-Sketch [54], ImageNet-A [25], and ImageNet-R [24].

- 领域泛化。为了评估学习到的提示对分布外数据集的泛化能力，我们将从ImageNet 12学习的提示应用于四个不同版本的ImageNet数据集，这些数据集表现出各种类型的领域偏移。目标数据集包括ImageNetV2 [45]、ImageNet-Sketch [54]、ImageNet-A [25]和ImageNet-R [24]。

---

${}^{3}$ https://github.com/KaiyangZhou/CoOp/blob/main/DATASETS.md

${}^{3}$ https://github.com/KaiyangZhou/CoOp/blob/main/DATASETS.md

---

- Cross-dataset Transfer. To evaluate the ability of learned prompts to generalize to unseen classes, we evaluate the same prompt trained on Ima-geNet on a broad range of downstream recognition tasks. We validate on ten datasets with varying characteristics: Caltech101 [20] for general object classification; OxfordPets [43], StanfordCars [32], Flowers102 [41], Food101 [6], and FGVCAircraft [39] for fine-grained classification; the Describable Textures Dataset (DTD) [11] for texture classification; EuroSAT [23] for satellite-image recognition; and UCF101 [53] for action recognition.

- 跨数据集迁移。为了评估学习到的提示对未见类别的泛化能力，我们在广泛的下游识别任务中评估同一在ImageNet上训练的提示。我们在十个具有不同特征的数据集上进行验证:Caltech101 [20]用于通用物体分类；OxfordPets [43]、StanfordCars [32]、Flowers102 [41]、Food101 [6]和FGVCAircraft [39]用于细粒度分类；可描述纹理数据集(DTD)[11]用于纹理分类；EuroSAT [23]用于卫星图像识别；UCF101 [53]用于动作识别。

- Generalization to Unseen Classes. To evaluate how learned prompts generalize to unseen classes from the same dataset, we divide classes into two subsets: base and novel classes. The prompt is trained exclusively on the base classes and then tested on the novel ones. We evaluate on ImageNet as well as the ten benchmark datasets used for cross-dataset evaluation.

- 对未见类别的泛化。为了评估学习到的提示对同一数据集中未见类别的泛化能力，我们将类别划分为基础类别和新颖类别。提示仅在基础类别上训练，然后在新颖类别上测试。我们在ImageNet以及用于跨数据集评估的十个基准数据集上进行评估。

- Class Agnostic Adaptation. In addition we introduce a novel evaluation setting in which the training class names are unknown. The prompt is trained on ImageNet and tested on all the benchmark datasets used in the domain generalization and cross-dataset evaluations.

- 类别无关适应。此外，我们引入了一个新的评估设置，其中训练类别名称未知。提示在ImageNet上训练，并在领域泛化和跨数据集评估中使用的所有基准数据集上测试。

Implementation Details. We use a CLIP model with a ViT-H-14 visual backbone as the teacher model 4 For student models, we evaluate both on a CLIP model based on ResNet-50 and a model based on ViT-B/32. By experimenting with both ResNet-based and ViT-based CLIP models we show the architecture independence of our approach. To assess how KDPL performs when integrated into different prompt learning techniques, we selected five distinct textual, visual, and multimodal approaches. With the ResNet-50 student model, we experiment with CoOp [68] and CoCoOp [67]. For the ViT-B/32 student, since it supports both visual and textual prompting, we experiment with CoOp [68, VPT [29], MaPLe [30] and PromptSRC [31].

实现细节。我们使用带有ViT-H-14视觉骨干的CLIP模型作为教师模型4。对于学生模型，我们评估了基于ResNet-50的CLIP模型和基于ViT-B/32的模型。通过对基于ResNet和基于ViT的CLIP模型进行实验，我们展示了我们方法的架构无关性。为了评估KDPL在不同提示学习技术中的表现，我们选择了五种不同的文本、视觉和多模态方法。对于ResNet-50学生模型，我们实验了CoOp [68]和CoCoOp [67]。对于ViT-B/32学生模型，由于其支持视觉和文本提示，我们实验了CoOp [68]、VPT [29]、MaPLe [30]和PromptSRC [31]。

We denote the integration of our unsupervised knowledge distillation strategy with a specific prompt learning technique by adding the suffix + KDPL to the name of the corresponding technique. For example, $\mathrm{{CoOp}} + \mathrm{{KDPL}}$ refers to the application of KDPL to CoOp. For class agnostic settings we instead use the suffix +CA-KDPL to indicate that no training class names are used.

我们通过在相应技术名称后添加后缀+KDPL来表示将我们的无监督知识蒸馏策略与特定提示学习技术的整合。例如，$\mathrm{{CoOp}} + \mathrm{{KDPL}}$表示KDPL应用于CoOp。对于类别无关设置，我们使用后缀+CA-KDPL以表示不使用任何训练类别名称。

Unless otherwise stated, all experiments are conducted in the few-shot setting with 16 examples per class randomly sampled from the training set. We set the temperature hyperparameter $\tau$ in Eq. (1) to 0.01. In the class agnostic experiments in which we assume no knowledge of class names in the training set, we set the number of class names selected in each iteration to $K = {1000}$ .

除非另有说明，所有实验均在少样本设置下进行，每类随机采样16个训练样本。我们将公式(1)中的温度超参数$\tau$设为0.01。在类别无关实验中，假设训练集中不知类别名称，我们将每次迭代选择的类别名称数量设为$K = {1000}$。

For each prompt learning method we use the original implementation and hyperparameters reported in the respective papers. Since we use the compact ResNet-50 and ViT-B/32 backbones, we cannot directly compare to the originally published results. Thus, all numbers we report here were computed by us and are averages over three independent runs. See Section A. in the Supplementary Material for additional implementation details.

对于每种提示学习方法，我们使用各自论文中报告的原始实现和超参数。由于我们使用的是紧凑型ResNet-50和ViT-B/32骨干，无法直接与原始发表结果比较。因此，我们这里报告的所有数值均由我们计算，且为三次独立运行的平均值。更多实现细节见补充材料A节。

---

${}^{4}$ https://huggingface.co/apple/DFN5B-CLIP-ViT-H-14

${}^{4}$ https://huggingface.co/apple/DFN5B-CLIP-ViT-H-14

---

Table 1: Domain Generalization. Comparison between the baselines and the proposed unsupervised KDPL variants (highlighted in cyan). In this setting, the prompt is trained on ImageNet (source) and then tested on four different versions of ImageNet (targets) that exhibit some kind of domain shift. Average performance improvements over the baselines are shown in green, and average performance deterioration in red.

表1:领域泛化。基线方法与所提无监督KDPL变体(以青色突出显示)之间的比较。在此设置中，提示在ImageNet(源域)上训练，然后在四个不同版本的ImageNet(目标域)上测试，这些版本表现出某种领域偏移。基线方法的平均性能提升以绿色显示，平均性能下降以红色显示。

<table><tr><td rowspan="2">Backbone</td><td rowspan="2">Method</td><td>Source</td><td colspan="5">Target</td></tr><tr><td>ImageNet</td><td>-V2</td><td>-S</td><td>-A</td><td>-R</td><td>Average</td></tr><tr><td rowspan="5">RN50</td><td>CLIP (student)</td><td>58.20</td><td>51.50</td><td>33.30</td><td>21.70</td><td>56.00</td><td>40.63</td></tr><tr><td>CoOp</td><td>62.40</td><td>55.17</td><td>33.70</td><td>23.13</td><td>56.20</td><td>42.05</td></tr><tr><td>CoOp + KDPL</td><td>62.73</td><td>55.37</td><td>35.20</td><td>23.27</td><td>57.77</td><td>42.90</td></tr><tr><td>CoCoOp</td><td>63.07</td><td>55.53</td><td>34.77</td><td>23.73</td><td>59.47</td><td>43.38</td></tr><tr><td>CoCoOp + KDPL</td><td>62.70</td><td>55.60</td><td>35.30</td><td>23.43</td><td>57.90</td><td>43.06</td></tr><tr><td rowspan="9">ViT-B/32</td><td>CLIP (student)</td><td>62.00</td><td>54.70</td><td>40.80</td><td>29.60</td><td>66.00</td><td>47.78</td></tr><tr><td>CoOp</td><td>66.33</td><td>58.30</td><td>41.40</td><td>31.47</td><td>65.87</td><td>49.26</td></tr><tr><td>$\mathrm{{CoOp}} + \mathrm{{KDPL}}$</td><td>65.97</td><td>58.10</td><td>42.50</td><td>31.63</td><td>67.37</td><td>49.90</td></tr><tr><td>VPT</td><td>64.97</td><td>56.73</td><td>41.27</td><td>27.00</td><td>66.50</td><td>47.88</td></tr><tr><td>VPT + KDPL</td><td>65.10</td><td>57.37</td><td>41.67</td><td>27.77</td><td>67.47</td><td>48.57</td></tr><tr><td>MaPLe</td><td>66.80</td><td>58.53</td><td>42.23</td><td>30.13</td><td>66.40</td><td>49.32</td></tr><tr><td>MaPLe + KDPL</td><td>66.50</td><td>58.47</td><td>42.77</td><td>29.87</td><td>67.70</td><td>49.70</td></tr><tr><td>PromptSRC</td><td>66.33</td><td>58.70</td><td>42.97</td><td>32.07</td><td>68.93</td><td>50.67</td></tr><tr><td>PromptSRC + KDPL</td><td>66.27</td><td>58.60</td><td>43.07</td><td>31.70</td><td>68.83</td><td>50.55</td></tr><tr><td colspan="2">ViT-H/14CLIP (teacher)</td><td>82.80</td><td>76.60</td><td>71.10</td><td>71.10</td><td>91.30</td><td>77.53</td></tr></table>

<table><tbody><tr><td rowspan="2">主干网络</td><td rowspan="2">方法</td><td>源域</td><td colspan="5">目标域</td></tr><tr><td>ImageNet(图像网络)</td><td>-V2</td><td>-S</td><td>-A</td><td>-R</td><td>平均值</td></tr><tr><td rowspan="5">RN50</td><td>CLIP(学生模型)</td><td>58.20</td><td>51.50</td><td>33.30</td><td>21.70</td><td>56.00</td><td>40.63</td></tr><tr><td>CoOp</td><td>62.40</td><td>55.17</td><td>33.70</td><td>23.13</td><td>56.20</td><td>42.05</td></tr><tr><td>CoOp + KDPL</td><td>62.73</td><td>55.37</td><td>35.20</td><td>23.27</td><td>57.77</td><td>42.90</td></tr><tr><td>CoCoOp</td><td>63.07</td><td>55.53</td><td>34.77</td><td>23.73</td><td>59.47</td><td>43.38</td></tr><tr><td>CoCoOp + KDPL</td><td>62.70</td><td>55.60</td><td>35.30</td><td>23.43</td><td>57.90</td><td>43.06</td></tr><tr><td rowspan="9">ViT-B/32</td><td>CLIP(学生模型)</td><td>62.00</td><td>54.70</td><td>40.80</td><td>29.60</td><td>66.00</td><td>47.78</td></tr><tr><td>CoOp</td><td>66.33</td><td>58.30</td><td>41.40</td><td>31.47</td><td>65.87</td><td>49.26</td></tr><tr><td>$\mathrm{{CoOp}} + \mathrm{{KDPL}}$</td><td>65.97</td><td>58.10</td><td>42.50</td><td>31.63</td><td>67.37</td><td>49.90</td></tr><tr><td>VPT</td><td>64.97</td><td>56.73</td><td>41.27</td><td>27.00</td><td>66.50</td><td>47.88</td></tr><tr><td>VPT + KDPL</td><td>65.10</td><td>57.37</td><td>41.67</td><td>27.77</td><td>67.47</td><td>48.57</td></tr><tr><td>MaPLe</td><td>66.80</td><td>58.53</td><td>42.23</td><td>30.13</td><td>66.40</td><td>49.32</td></tr><tr><td>MaPLe + KDPL</td><td>66.50</td><td>58.47</td><td>42.77</td><td>29.87</td><td>67.70</td><td>49.70</td></tr><tr><td>PromptSRC</td><td>66.33</td><td>58.70</td><td>42.97</td><td>32.07</td><td>68.93</td><td>50.67</td></tr><tr><td>PromptSRC + KDPL</td><td>66.27</td><td>58.60</td><td>43.07</td><td>31.70</td><td>68.83</td><td>50.55</td></tr><tr><td colspan="2">ViT-H/14 CLIP(教师模型)</td><td>82.80</td><td>76.60</td><td>71.10</td><td>71.10</td><td>91.30</td><td>77.53</td></tr></tbody></table>

### 4.2 Results on Domain Generalization

### 4.2 域泛化结果

Table 1 outlines the performance in the domain generalization setting. We report the performance of each baseline method alongside their unsupervised KDPL variants. Additionally, the performance of the zero-shot CLIP student and teacher models using a handcrafted prompt is included for comparison. We observe that applying our unsupervised approach to each baseline does not result in a significant decrease in performance on the source dataset. Notably, when transferring the learned prompts to a different domain, incorporating KDPL in each baseline can lead to a slight improvement. This suggests that our unsupervised teacher-student distillation learns prompts that generalize better than those trained using ground-truth labels. The only exceptions where we observe an average decrease compared to the baseline are when using $\mathrm{{CoCoOp}}$ or Prompt-SRC. CoCoOp-KDPL achieves an average accuracy significantly lower than Co- $\mathrm{{CoOp}}$ only on the ImageNet-R dataset. Finally, note that all our unsupervised KDPL variants significantly improve the performance over the zero-shot CLIP student model in both the source and the target datasets.

表1概述了域泛化设置下的性能表现。我们报告了每个基线方法及其无监督KDPL变体的性能。此外，还包括使用手工设计提示的零-shot CLIP学生模型和教师模型的性能以供比较。我们观察到，将我们的无监督方法应用于每个基线时，源数据集上的性能并未显著下降。值得注意的是，在将学习到的提示迁移到不同域时，在每个基线上引入KDPL可以带来轻微的提升。这表明我们的无监督师生蒸馏学习的提示比使用真实标签训练的提示具有更好的泛化能力。唯一例外的是使用$\mathrm{{CoCoOp}}$或Prompt-SRC时，平均性能较基线有所下降。CoCoOp-KDPL在ImageNet-R数据集上的平均准确率显著低于Co-$\mathrm{{CoOp}}$。最后，值得注意的是，我们所有的无监督KDPL变体在源数据集和目标数据集上均显著优于零-shot CLIP学生模型的性能。

Table 2: Cross-dataset Transfer. Comparison between the baselines and the proposed unsupervised KDPL variants (highlighted in cyan). The prompt is learned on ImageNet and then tested on the ten different target datasets. Average performance improvements over the baselines are indicated in green.

表2:跨数据集迁移。比较基线方法与所提无监督KDPL变体(以青色标出)。提示在ImageNet上学习，然后在十个不同的目标数据集上测试。相较基线的平均性能提升以绿色标示。

<table><tr><td/><td rowspan="2">Method</td><td colspan="11">Target</td></tr><tr><td>Backbone</td><td>OxfordPets</td><td/><td>FGVCAircraft</td><td/><td>EuroSAT</td><td>StanfordCars</td><td>Food101</td><td>SUN397</td><td>Caltech101</td><td>UCF101</td><td>Average</td></tr><tr><td rowspan="5">RN50</td><td>CLIP (student)</td><td>83.70</td><td>61.00</td><td>15.60</td><td>40.00</td><td>24.20</td><td>55.60</td><td>75.20</td><td>58.50</td><td>86.00</td><td>58.30</td><td>55.81</td></tr><tr><td>CoOp</td><td>84.60</td><td>61.63</td><td>13.77</td><td>36.83</td><td>22.33</td><td>54.20</td><td>75.03</td><td>59.00</td><td>87.67</td><td>57.73</td><td>55.28</td></tr><tr><td>$\mathrm{{CoOp}} + \mathrm{{KDPL}}$</td><td>87.33</td><td>62.83</td><td>14.97</td><td>39.27</td><td>30.17</td><td>56.60</td><td>77.27</td><td>60.30</td><td>88.57</td><td>58.63</td><td>57.59</td></tr><tr><td>CoCoOp</td><td>86.93</td><td>63.47</td><td>16.27</td><td>40.53</td><td>27.20</td><td>55.47</td><td>77.73</td><td>61.40</td><td>88.07</td><td>60.43</td><td>57.75</td></tr><tr><td>$\mathrm{{CoCoOp}} + \mathrm{{KDPL}}$</td><td>87.33</td><td>64.97</td><td>15.97</td><td>41.27</td><td>29.17</td><td>56.83</td><td>78.00</td><td>61.50</td><td>88.50</td><td>59.53</td><td>58.31</td></tr><tr><td rowspan="9">ViT-B/32</td><td>CLIP (student)</td><td>85.00</td><td>64.30</td><td>18.20</td><td>42.80</td><td>38.10</td><td>60.40</td><td>79.10</td><td>62.00</td><td>91.10</td><td>60.70</td><td>60.17</td></tr><tr><td>CoOp</td><td>87.13</td><td>62.20</td><td>12.13</td><td>40.57</td><td>36.97</td><td>57.83</td><td>80.13</td><td>62.83</td><td>91.13</td><td>61.80</td><td>59.27</td></tr><tr><td>$\mathrm{{CoOp}} + \mathrm{{KDPL}}$</td><td>87.13</td><td>62.23</td><td>15.57</td><td>40.40</td><td>40.93</td><td>58.83</td><td>80.57</td><td>64.23</td><td>92.77</td><td>61.63</td><td>60.43</td></tr><tr><td>VPT</td><td>87.43</td><td>64.77</td><td>19.53</td><td>44.20</td><td>28.47</td><td>57.60</td><td>78.27</td><td>63.73</td><td>91.40</td><td>62.50</td><td>59.79</td></tr><tr><td>VPT + KDPL</td><td>87.43</td><td>64.43</td><td>17.77</td><td>42.93</td><td>30.80</td><td>57.97</td><td>78.47</td><td>63.63</td><td>92.00</td><td>62.77</td><td>59.82</td></tr><tr><td>MaPLe</td><td>88.37</td><td>66.43</td><td>18.47</td><td>42.03</td><td>37.77</td><td>60.00</td><td>80.10</td><td>64.43</td><td>91.33</td><td>62.50</td><td>61.14</td></tr><tr><td>MaPLe + KDPL</td><td>88.27</td><td>64.77</td><td>17.33</td><td>43.13</td><td>37.13</td><td>59.93</td><td>80.47</td><td>65.43</td><td>93.43</td><td>62.70</td><td>61.26</td></tr><tr><td>PromptSRC</td><td>88.13</td><td>65.33</td><td>17.17</td><td>43.90</td><td>40.50</td><td>60.17</td><td>81.23</td><td>65.40</td><td>92.37</td><td>63.63</td><td>61.78</td></tr><tr><td>PromptSRC + KDPL</td><td>88.17</td><td>65.10</td><td>18.23</td><td>43.27</td><td>44.30</td><td>60.43</td><td>80.90</td><td>65.67</td><td>93.63</td><td>63.40</td><td>62.31</td></tr><tr><td>ViT-H/14</td><td>CLIP (teacher)</td><td>94.80</td><td>89.40</td><td>63.20</td><td>66.80</td><td>63.30</td><td>95.60</td><td>93.60</td><td>76.40</td><td>97.90</td><td>76.40</td><td>81.74</td></tr></table>

<table><tbody><tr><td></td><td rowspan="2">方法</td><td colspan="11">目标</td></tr><tr><td>主干网络</td><td>OxfordPets(牛津宠物数据集)</td><td></td><td>FGVCAircraft(FGVC飞机数据集)</td><td></td><td>EuroSAT(欧洲卫星图像数据集)</td><td>StanfordCars(斯坦福汽车数据集)</td><td>Food101(食品101数据集)</td><td>SUN397(SUN397场景识别数据集)</td><td>Caltech101(加州理工101数据集)</td><td>UCF101(UCF101动作识别数据集)</td><td>平均值</td></tr><tr><td rowspan="5">RN50(ResNet50)</td><td>CLIP(学生模型)</td><td>83.70</td><td>61.00</td><td>15.60</td><td>40.00</td><td>24.20</td><td>55.60</td><td>75.20</td><td>58.50</td><td>86.00</td><td>58.30</td><td>55.81</td></tr><tr><td>CoOp</td><td>84.60</td><td>61.63</td><td>13.77</td><td>36.83</td><td>22.33</td><td>54.20</td><td>75.03</td><td>59.00</td><td>87.67</td><td>57.73</td><td>55.28</td></tr><tr><td>$\mathrm{{CoOp}} + \mathrm{{KDPL}}$</td><td>87.33</td><td>62.83</td><td>14.97</td><td>39.27</td><td>30.17</td><td>56.60</td><td>77.27</td><td>60.30</td><td>88.57</td><td>58.63</td><td>57.59</td></tr><tr><td>CoCoOp</td><td>86.93</td><td>63.47</td><td>16.27</td><td>40.53</td><td>27.20</td><td>55.47</td><td>77.73</td><td>61.40</td><td>88.07</td><td>60.43</td><td>57.75</td></tr><tr><td>$\mathrm{{CoCoOp}} + \mathrm{{KDPL}}$</td><td>87.33</td><td>64.97</td><td>15.97</td><td>41.27</td><td>29.17</td><td>56.83</td><td>78.00</td><td>61.50</td><td>88.50</td><td>59.53</td><td>58.31</td></tr><tr><td rowspan="9">ViT-B/32(视觉Transformer-B/32)</td><td>CLIP(学生模型)</td><td>85.00</td><td>64.30</td><td>18.20</td><td>42.80</td><td>38.10</td><td>60.40</td><td>79.10</td><td>62.00</td><td>91.10</td><td>60.70</td><td>60.17</td></tr><tr><td>CoOp</td><td>87.13</td><td>62.20</td><td>12.13</td><td>40.57</td><td>36.97</td><td>57.83</td><td>80.13</td><td>62.83</td><td>91.13</td><td>61.80</td><td>59.27</td></tr><tr><td>$\mathrm{{CoOp}} + \mathrm{{KDPL}}$</td><td>87.13</td><td>62.23</td><td>15.57</td><td>40.40</td><td>40.93</td><td>58.83</td><td>80.57</td><td>64.23</td><td>92.77</td><td>61.63</td><td>60.43</td></tr><tr><td>VPT</td><td>87.43</td><td>64.77</td><td>19.53</td><td>44.20</td><td>28.47</td><td>57.60</td><td>78.27</td><td>63.73</td><td>91.40</td><td>62.50</td><td>59.79</td></tr><tr><td>VPT + KDPL</td><td>87.43</td><td>64.43</td><td>17.77</td><td>42.93</td><td>30.80</td><td>57.97</td><td>78.47</td><td>63.63</td><td>92.00</td><td>62.77</td><td>59.82</td></tr><tr><td>MaPLe</td><td>88.37</td><td>66.43</td><td>18.47</td><td>42.03</td><td>37.77</td><td>60.00</td><td>80.10</td><td>64.43</td><td>91.33</td><td>62.50</td><td>61.14</td></tr><tr><td>MaPLe + KDPL</td><td>88.27</td><td>64.77</td><td>17.33</td><td>43.13</td><td>37.13</td><td>59.93</td><td>80.47</td><td>65.43</td><td>93.43</td><td>62.70</td><td>61.26</td></tr><tr><td>PromptSRC</td><td>88.13</td><td>65.33</td><td>17.17</td><td>43.90</td><td>40.50</td><td>60.17</td><td>81.23</td><td>65.40</td><td>92.37</td><td>63.63</td><td>61.78</td></tr><tr><td>PromptSRC + KDPL</td><td>88.17</td><td>65.10</td><td>18.23</td><td>43.27</td><td>44.30</td><td>60.43</td><td>80.90</td><td>65.67</td><td>93.63</td><td>63.40</td><td>62.31</td></tr><tr><td>ViT-H/14(视觉Transformer-H/14)</td><td>CLIP(教师模型)</td><td>94.80</td><td>89.40</td><td>63.20</td><td>66.80</td><td>63.30</td><td>95.60</td><td>93.60</td><td>76.40</td><td>97.90</td><td>76.40</td><td>81.74</td></tr></tbody></table>

### 4.3 Results on Cross-dataset Transfer

### 4.3 跨数据集迁移的结果

In Table 2 we present the results of the cross-dataset evaluation setting in which the prompt is trained on ImageNet and tested on ten different target datasets. For all datasets our KDPL-based variants consistently outperform the corresponding baselines and demonstrate superior generalization performance. The greater generalization capabilities of KDPL are evident even for fine-grained datasets like EuroSAT, on which the CoOp+KDPL achieves an 8% improvement over the baseline CoOp when using ResNet-50 as the backbone. Although adding KDPL yields only minor improvement to the VPT and MaPLe prompt learning techniques, we emphasize that our VPT+KDPL and MaPLe+KDPL do not have access to ground-truth labels. Notably, PromptSRC+KDPL achieves the highest average performance.

表2展示了跨数据集评估设置的结果，其中提示词在ImageNet上训练，并在十个不同的目标数据集上测试。对于所有数据集，我们基于KDPL的变体均持续优于相应的基线方法，表现出更优越的泛化性能。即使对于细粒度数据集如EuroSAT，KDPL的更强泛化能力也十分明显，在使用ResNet-50作为骨干网络时，CoOp+KDPL较基线CoOp提升了8%。尽管加入KDPL对VPT和MaPLe提示学习技术的提升较小，但我们强调VPT+KDPL和MaPLe+KDPL均未使用真实标签。值得注意的是，PromptSRC+KDPL取得了最高的平均性能。

### 4.4 Results on Generalization to Unseen Classes

### 4.4 对未见类别的泛化结果

In Table 3 we give results for the unseen class generalization task. In these experiments each dataset is split into ${50}\%$ of the classes as a base for training few-shot adaptation, and the remaining ${50}\%$ as new classes on which zero-shot performance is evaluated. KDPL consistently outperforms the corresponding baseline methods for both backbones, demonstrating improvement in all scenarios for the majority of the datasets. On average, the performance improvement over the supervised baseline methods ranges from about 1% for VPT to about 3% for CoOp with the ResNet-50 backbone. See Section C.1. in the Supplementary Material for further analysis of base and unseen performance.

表3给出了未见类别泛化任务的结果。在这些实验中，每个数据集被划分为${50}\%$的类别作为少样本适应的训练基础，剩余的${50}\%$类别作为新类别用于评估零样本性能。KDPL在两种骨干网络上均持续优于对应的基线方法，在大多数数据集的所有场景中均表现出提升。平均来看，基于ResNet-50骨干网络，性能提升从VPT的约1%到CoOp的约3%。更多关于基础类别和未见类别性能的分析见补充材料C.1节。

Table 3: Generalization to Unseen Classes. Comparison between the baselines and the proposed unsupervised KDPL variants (highlighted in cyan). In this setting the prompt is tested on classes never observed during training. Average performance improvements over the baselines are indicated in green.

表3:未见类别的泛化能力。基线方法与所提无监督KDPL变体(以青色标出)之间的比较。在此设置中，提示词在训练时未见过的类别上进行测试。相较基线的平均性能提升以绿色标示。

<table><tr><td/><td/><td colspan="12">Unseen Classes</td></tr><tr><td>Backbone</td><td>Method</td><td>ageNet</td><td>OxfordPets</td><td>Flowers102</td><td>FGVCAircraft</td><td>DTD</td><td>${E}_{\text{uroSAT }}$</td><td>StanfordCars</td><td>Food101</td><td>SUN397</td><td>Caltech101</td><td>UCF101</td><td>Average</td></tr><tr><td rowspan="5">RN50</td><td>CLIP (student)</td><td>60.10</td><td>$\underline{93.70}$</td><td>71.30</td><td>24.80</td><td>53.90</td><td>43.70</td><td>66.60</td><td>82.20</td><td>70.10</td><td>90.50</td><td>67.80</td><td>65.88</td></tr><tr><td>CoOp</td><td>60.00</td><td>91.63</td><td>58.30</td><td>22.17</td><td>40.93</td><td>42.13</td><td>59.87</td><td>82.03</td><td>66.77</td><td>87.53</td><td>57.63</td><td>60.82</td></tr><tr><td>$\mathrm{{CoOp}} + \mathrm{{KDPL}}$</td><td>60.53</td><td>94.97</td><td>63.40</td><td>21.27</td><td>38.70</td><td>62.07</td><td>56.63</td><td>83.07</td><td>69.83</td><td>88.75</td><td>62.63</td><td>63.80</td></tr><tr><td>CoCoOp</td><td>63.07</td><td>94.93</td><td>67.47</td><td>24.87</td><td>45.40</td><td>35.10</td><td>64.73</td><td>84.50</td><td>72.87</td><td>90.73</td><td>64.67</td><td>64.39</td></tr><tr><td>$\mathrm{{CoCoOp}} + \mathrm{{KDPL}}$</td><td>62.43</td><td>95.10</td><td>69.17</td><td>24.57</td><td>48.00</td><td>55.93</td><td>63.70</td><td>85.67</td><td>73.33</td><td>90.53</td><td>66.40</td><td>66.80</td></tr><tr><td rowspan="9">ViT-B/32</td><td>CLIP (student)</td><td>64.00</td><td>96.30</td><td>72.30</td><td>28.30</td><td>53.90</td><td>61.50</td><td>69.80</td><td>85.70</td><td>73.10</td><td>94.00</td><td>71.60</td><td>70.05</td></tr><tr><td>CoOp</td><td>64.53</td><td>93.37</td><td>59.77</td><td>23.03</td><td>45.57</td><td>49.13</td><td>61.73</td><td>85.50</td><td>69.37</td><td>92.13</td><td>65.60</td><td>64.52</td></tr><tr><td>$\mathrm{{CoOp}} + \mathrm{{KDPL}}$</td><td>64.90</td><td>94.00</td><td>56.17</td><td>22.00</td><td>47.33</td><td>62.07</td><td>62.37</td><td>87.23</td><td>74.17</td><td>93.43</td><td>66.20</td><td>66.35</td></tr><tr><td>VPT</td><td>64.60</td><td>94.83</td><td>66.03</td><td>29.70</td><td>50.17</td><td>50.03</td><td>69.90</td><td>85.83</td><td>75.13</td><td>92.57</td><td>69.47</td><td>68.02</td></tr><tr><td>VPT + KDPL</td><td>65.20</td><td>95.20</td><td>67.87</td><td>30.40</td><td>47.53</td><td>54.97</td><td>69.80</td><td>86.33</td><td>75.17</td><td>92.80</td><td>71.07</td><td>68.76</td></tr><tr><td>MaPLe</td><td>66.70</td><td>96.87</td><td>69.77</td><td>20.43</td><td>53.50</td><td>66.70</td><td>68.03</td><td>87.47</td><td>76.57</td><td>92.27</td><td>69.40</td><td>69.79</td></tr><tr><td>MaPLe + KDPL</td><td>66.73</td><td>96.87</td><td>68.23</td><td>27.37</td><td>50.33</td><td>75.70</td><td>68.40</td><td>87.83</td><td>76.83</td><td>93.67</td><td>73.53</td><td>71.41</td></tr><tr><td>PromptSRC</td><td>65.93</td><td>96.30</td><td>71.37</td><td>23.67</td><td>54.43</td><td>61.97</td><td>70.00</td><td>87.13</td><td>76.77</td><td>94.70</td><td>72.63</td><td>70.45</td></tr><tr><td>PromptSRC + KDPL</td><td>66.33</td><td>96.47</td><td>68.83</td><td>28.43</td><td>50.87</td><td>74.17</td><td>68.50</td><td>87.63</td><td>77.33</td><td>94.47</td><td>74.73</td><td>71.61</td></tr><tr><td>ViT-H/14</td><td>CLIP (teacher)</td><td>84.10</td><td>99.20</td><td>85.60</td><td>64.30</td><td>75.00</td><td>82.60</td><td>98.20</td><td>96.30</td><td>85.10</td><td>97.30</td><td>85.20</td><td>86.63</td></tr></table>

<table><tbody><tr><td></td><td></td><td colspan="12">未见类别</td></tr><tr><td>主干网络</td><td>方法</td><td>ageNet</td><td>OxfordPets(牛津宠物数据集)</td><td>Flowers102(102类花卉数据集)</td><td>FGVCAircraft(FGVC飞机数据集)</td><td>DTD(纹理描述数据集)</td><td>${E}_{\text{uroSAT }}$</td><td>StanfordCars(斯坦福汽车数据集)</td><td>Food101(食品101数据集)</td><td>SUN397(SUN397场景数据集)</td><td>Caltech101(加州理工101数据集)</td><td>UCF101(UCF101动作识别数据集)</td><td>平均值</td></tr><tr><td rowspan="5">RN50(ResNet50)</td><td>CLIP(学生模型)</td><td>60.10</td><td>$\underline{93.70}$</td><td>71.30</td><td>24.80</td><td>53.90</td><td>43.70</td><td>66.60</td><td>82.20</td><td>70.10</td><td>90.50</td><td>67.80</td><td>65.88</td></tr><tr><td>CoOp</td><td>60.00</td><td>91.63</td><td>58.30</td><td>22.17</td><td>40.93</td><td>42.13</td><td>59.87</td><td>82.03</td><td>66.77</td><td>87.53</td><td>57.63</td><td>60.82</td></tr><tr><td>$\mathrm{{CoOp}} + \mathrm{{KDPL}}$</td><td>60.53</td><td>94.97</td><td>63.40</td><td>21.27</td><td>38.70</td><td>62.07</td><td>56.63</td><td>83.07</td><td>69.83</td><td>88.75</td><td>62.63</td><td>63.80</td></tr><tr><td>CoCoOp</td><td>63.07</td><td>94.93</td><td>67.47</td><td>24.87</td><td>45.40</td><td>35.10</td><td>64.73</td><td>84.50</td><td>72.87</td><td>90.73</td><td>64.67</td><td>64.39</td></tr><tr><td>$\mathrm{{CoCoOp}} + \mathrm{{KDPL}}$</td><td>62.43</td><td>95.10</td><td>69.17</td><td>24.57</td><td>48.00</td><td>55.93</td><td>63.70</td><td>85.67</td><td>73.33</td><td>90.53</td><td>66.40</td><td>66.80</td></tr><tr><td rowspan="9">ViT-B/32(视觉Transformer-B/32)</td><td>CLIP(学生模型)</td><td>64.00</td><td>96.30</td><td>72.30</td><td>28.30</td><td>53.90</td><td>61.50</td><td>69.80</td><td>85.70</td><td>73.10</td><td>94.00</td><td>71.60</td><td>70.05</td></tr><tr><td>CoOp</td><td>64.53</td><td>93.37</td><td>59.77</td><td>23.03</td><td>45.57</td><td>49.13</td><td>61.73</td><td>85.50</td><td>69.37</td><td>92.13</td><td>65.60</td><td>64.52</td></tr><tr><td>$\mathrm{{CoOp}} + \mathrm{{KDPL}}$</td><td>64.90</td><td>94.00</td><td>56.17</td><td>22.00</td><td>47.33</td><td>62.07</td><td>62.37</td><td>87.23</td><td>74.17</td><td>93.43</td><td>66.20</td><td>66.35</td></tr><tr><td>VPT</td><td>64.60</td><td>94.83</td><td>66.03</td><td>29.70</td><td>50.17</td><td>50.03</td><td>69.90</td><td>85.83</td><td>75.13</td><td>92.57</td><td>69.47</td><td>68.02</td></tr><tr><td>VPT + KDPL</td><td>65.20</td><td>95.20</td><td>67.87</td><td>30.40</td><td>47.53</td><td>54.97</td><td>69.80</td><td>86.33</td><td>75.17</td><td>92.80</td><td>71.07</td><td>68.76</td></tr><tr><td>MaPLe</td><td>66.70</td><td>96.87</td><td>69.77</td><td>20.43</td><td>53.50</td><td>66.70</td><td>68.03</td><td>87.47</td><td>76.57</td><td>92.27</td><td>69.40</td><td>69.79</td></tr><tr><td>MaPLe + KDPL</td><td>66.73</td><td>96.87</td><td>68.23</td><td>27.37</td><td>50.33</td><td>75.70</td><td>68.40</td><td>87.83</td><td>76.83</td><td>93.67</td><td>73.53</td><td>71.41</td></tr><tr><td>PromptSRC</td><td>65.93</td><td>96.30</td><td>71.37</td><td>23.67</td><td>54.43</td><td>61.97</td><td>70.00</td><td>87.13</td><td>76.77</td><td>94.70</td><td>72.63</td><td>70.45</td></tr><tr><td>PromptSRC + KDPL</td><td>66.33</td><td>96.47</td><td>68.83</td><td>28.43</td><td>50.87</td><td>74.17</td><td>68.50</td><td>87.63</td><td>77.33</td><td>94.47</td><td>74.73</td><td>71.61</td></tr><tr><td>ViT-H/14(视觉Transformer-H/14)</td><td>CLIP(教师模型)</td><td>84.10</td><td>99.20</td><td>85.60</td><td>64.30</td><td>75.00</td><td>82.60</td><td>98.20</td><td>96.30</td><td>85.10</td><td>97.30</td><td>85.20</td><td>86.63</td></tr></tbody></table>

### 4.5 Results on Class Agnostic Adaptation

### 4.5 关于类别无关适应的结果

Figure 3(a-b) summarizes the main results in the proposed Class Agnostic (CA) scenario in which even the training class names are unknown at training time. We report the accuracy on the ImageNet dataset (source), as well as the average accuracy in domain generalization and cross-dataset settings. Note that, even without knowing the class names, the performance on the source dataset steadily improves compared to the zero-shot CLIP model. Moreover, the prompts learned via the proposed unsupervised class agnostic knowledge distillation also exhibit improved average domain generalization $\left( {\mathrm{{AVG}}}^{1}\right)$ and cross-dataset capabilities $\left( {\mathrm{{AVG}}}^{2}\right)$ . Figure 3(b) visually depicts how the ResNet-50-based CoOp+CA-KDPL compares with supervised CoOp and zero-shot CLIP student performance in the cross-dataset transfer setting. Notably, CA-KDPL outperforms both baselines despite being unsupervised and class agnostic during training.

图3(a-b)总结了所提出的类别无关(Class Agnostic, CA)场景中的主要结果，该场景下训练时甚至不知道训练类别名称。我们报告了ImageNet数据集(源域)上的准确率，以及域泛化和跨数据集设置中的平均准确率。值得注意的是，即使不知道类别名称，源数据集上的性能相比零样本CLIP模型也稳步提升。此外，通过所提无监督类别无关知识蒸馏(class agnostic knowledge distillation)学习的提示词，在平均域泛化$\left( {\mathrm{{AVG}}}^{1}\right)$和跨数据集能力$\left( {\mathrm{{AVG}}}^{2}\right)$上也表现出提升。图3(b)直观展示了基于ResNet-50的CoOp+CA-KDPL在跨数据集迁移设置中与监督CoOp和零样本CLIP学生模型的对比表现。值得注意的是，尽管训练过程中无监督且类别无关，CA-KDPL仍优于这两个基线。

![bo_d1c3l9bef24c73d2ojn0_13_905_327_476_394_0.jpg](images/bo_d1c3l9bef24c73d2ojn0_13_905_327_476_394_0.jpg)

<table><tr><td>Method</td><td>Source</td><td>AVG1</td><td>${\mathrm{{AVG}}}^{2}$</td></tr><tr><td>ResNet-50 (student)</td><td>58.20</td><td>40.63</td><td>55.81</td></tr><tr><td>CoOp + CA-KDPL</td><td>61.83</td><td>43.02</td><td>57.69</td></tr><tr><td>CoCoOp + CA-KDPL</td><td>61.43</td><td>43.18</td><td>58.03</td></tr><tr><td>ViT-B/32 (student)</td><td>62.00</td><td>47.78</td><td>60.17</td></tr><tr><td>CoOp + CA-KDPL</td><td>64.73</td><td>49.63</td><td>60.74</td></tr><tr><td>VPT + CA-KDPL</td><td>63.73</td><td>47.89</td><td>59.80</td></tr><tr><td>MaPLe + CA-KDPL</td><td>65.23</td><td>49.28</td><td>61.23</td></tr><tr><td>PromptSRC + CA-KDPL</td><td>65.00</td><td>50.37</td><td>61.93</td></tr></table>

<table><tbody><tr><td>方法</td><td>来源</td><td>平均值1</td><td>${\mathrm{{AVG}}}^{2}$</td></tr><tr><td>ResNet-50(学生模型)</td><td>58.20</td><td>40.63</td><td>55.81</td></tr><tr><td>CoOp + CA-KDPL</td><td>61.83</td><td>43.02</td><td>57.69</td></tr><tr><td>CoCoOp + CA-KDPL</td><td>61.43</td><td>43.18</td><td>58.03</td></tr><tr><td>ViT-B/32(学生模型)</td><td>62.00</td><td>47.78</td><td>60.17</td></tr><tr><td>CoOp + CA-KDPL</td><td>64.73</td><td>49.63</td><td>60.74</td></tr><tr><td>VPT + CA-KDPL</td><td>63.73</td><td>47.89</td><td>59.80</td></tr><tr><td>MaPLe + CA-KDPL</td><td>65.23</td><td>49.28</td><td>61.23</td></tr><tr><td>PromptSRC + CA-KDPL</td><td>65.00</td><td>50.37</td><td>61.93</td></tr></tbody></table>

(a) Average class agnostic adaptation (b) Per-dataset class agnostic adaptation

(a) 平均类别无关适应 (b) 每数据集类别无关适应

Fig. 3: Class agnostic adaptation. (a) Comparison between the zero-shot baselines and our class agnostic CA-KDPL variants (highlighted in cyan). The prompt is learned in an unsupervised and class agnostic setting on ImageNet and evaluated on the benchmark datasets for domain generalization $\left( {\mathrm{{AVG}}}^{1}\right)$ and cross-dataset $\left( {\mathrm{{AVG}}}^{2}\right)$ evaluations. Average performance improvements are indicated in green, and deterioration in red. (b) Per-dataset accuracy comparison between our unsupervised and class agnostic method (CoOp+CA-KDPL), the supervised baseline CoOp, and the zero-shot student on the cross-dataset benchmark datasets.

图3:类别无关适应。(a) 零样本基线与我们类别无关CA-KDPL变体(以青色突出显示)之间的比较。该提示在ImageNet上以无监督且类别无关的方式学习，并在领域泛化$\left( {\mathrm{{AVG}}}^{1}\right)$和跨数据集$\left( {\mathrm{{AVG}}}^{2}\right)$基准数据集上进行评估。平均性能提升以绿色表示，性能下降以红色表示。(b) 我们的无监督且类别无关方法(CoOp+CA-KDPL)、有监督基线CoOp及零样本学生在跨数据集基准数据集上的每数据集准确率比较。

## 5 Conclusion

## 5 结论

In this paper we proposed an approach to Knowledge Distillation Prompt Learning (KDPL) which is easily integrated into existing supervised prompt learning methods. Our experiments show that for CoOp, CoCoOp, VPT, MaPLe and PromptSRC adding KDPL: (1) renders them label agnostic by eliminating the need for ground-truth labels for few-shot adaptation; (2) can also render them class agnostic in cases where no knowledge of training class labels is available; and (3) remarkably improves generalization to downstream tasks.

本文提出了一种知识蒸馏提示学习(Knowledge Distillation Prompt Learning, KDPL)方法，能够轻松集成到现有的有监督提示学习方法中。实验表明，对于CoOp、CoCoOp、VPT、MaPLe和PromptSRC，加入KDPL后:(1) 通过消除对少样本适应中真实标签的依赖，使其标签无关；(2) 在无训练类别标签知识的情况下，也能实现类别无关；(3) 显著提升了对下游任务的泛化能力。

The additional computation cost incurred by distilling from a large VLM is a limitation of KDPL, though all encoder parameters are fixed and the predictions of the teacher can be precomputed, which helps mitigate the extra cost. This extra computation only amounts to about a ${15}\%$ increase for MaPLe.

从大型视觉语言模型(VLM)蒸馏带来的额外计算开销是KDPL的一个限制，尽管所有编码器参数均固定且教师模型的预测可预先计算，这有助于缓解额外开销。对于MaPLe而言，这一额外计算仅增加约${15}\%$。

Note that we did not tune any hyperparameters when training the KDPL variants. We use the same settings as in the original papers, which are likely suboptimal for distillation-based adaptation. With careful tuning, there is potential for improvement. Our experiments indicate that distillation-learned prompts are more transferable, and we think it would be interesting to see if this idea can generalize to very different downstream tasks and scale to even bigger teacher models or - more interestingly - to even smaller student models.

注意，我们在训练KDPL变体时未调优任何超参数，使用了原论文中的相同设置，这些设置可能并非蒸馏适应的最优配置。通过精心调优，仍有提升空间。实验表明，蒸馏学习的提示更具可迁移性，我们认为探索该思路是否能推广到截然不同的下游任务，并扩展到更大规模的教师模型，或更有趣的是，更小规模的学生模型，值得关注。

## Acknowledgements

## 致谢

This work was supported by funding from the European Commission Horizon 2020 grant #951911 (AI4Media).

本工作得到欧盟委员会地平线2020计划资助，项目编号#951911(AI4Media)。

## References

## 参考文献

1. Abdul Samadh, J., Gani, M.H., Hussein, N., Khattak, M.U., Naseer, M.M., Shah-baz Khan, F., Khan, S.H.: Align your prompts: Test-time prompting with distribution alignment for zero-shot generalization. Advances in Neural Information Processing Systems 36 (2024)

1. Abdul Samadh, J., Gani, M.H., Hussein, N., Khattak, M.U., Naseer, M.M., Shah-baz Khan, F., Khan, S.H.: Align your prompts: Test-time prompting with distribution alignment for zero-shot generalization. Advances in Neural Information Processing Systems 36 (2024)

2. Agnolucci, L., Baldrati, A., Todino, F., Becattini, F., Bertini, M., Del Bimbo, A.: Eco: Ensembling context optimization for vision-language models. In: Proceedings of the IEEE/CVF International Conference on Computer Vision. pp. 2811-2815 (2023)

2. Agnolucci, L., Baldrati, A., Todino, F., Becattini, F., Bertini, M., Del Bimbo, A.: Eco: Ensembling context optimization for vision-language models. In: Proceedings of the IEEE/CVF International Conference on Computer Vision. pp. 2811-2815 (2023)

3. Baldrati, A., Agnolucci, L., Bertini, M., Del Bimbo, A.: Zero-shot composed image retrieval with textual inversion. In: Proceedings of the IEEE/CVF International Conference on Computer Vision (ICCV). pp. 15338-15347 (October 2023)

3. Baldrati, A., Agnolucci, L., Bertini, M., Del Bimbo, A.: Zero-shot composed image retrieval with textual inversion. In: Proceedings of the IEEE/CVF International Conference on Computer Vision (ICCV). pp. 15338-15347 (October 2023)

4. Barraco, M., Cornia, M., Cascianelli, S., Baraldi, L., Cucchiara, R.: The unreasonable effectiveness of clip features for image captioning: an experimental analysis. In: proceedings of the IEEE/CVF conference on computer vision and pattern recognition. pp. 4662-4670 (2022)

4. Barraco, M., Cornia, M., Cascianelli, S., Baraldi, L., Cucchiara, R.: The unreasonable effectiveness of clip features for image captioning: an experimental analysis. In: proceedings of the IEEE/CVF conference on computer vision and pattern recognition. pp. 4662-4670 (2022)

5. Beyer, L., Zhai, X., Royer, A., Markeeva, L., Anil, R., Kolesnikov, A.: Knowledge distillation: A good teacher is patient and consistent. In: Proceedings of the IEEE/CVF conference on computer vision and pattern recognition. pp. 10925- 10934 (2022)

5. Beyer, L., Zhai, X., Royer, A., Markeeva, L., Anil, R., Kolesnikov, A.: Knowledge distillation: A good teacher is patient and consistent. In: Proceedings of the IEEE/CVF conference on computer vision and pattern recognition. pp. 10925- 10934 (2022)

6. Bossard, L., Guillaumin, M., Van Gool, L.: Food-101-mining discriminative components with random forests. In: Computer Vision-ECCV 2014: 13th European Conference, Zurich, Switzerland, September 6-12, 2014, Proceedings, Part VI 13. pp. 446-461. Springer (2014)

6. Bossard, L., Guillaumin, M., Van Gool, L.: Food-101-mining discriminative components with random forests. In: Computer Vision-ECCV 2014: 13th European Conference, Zurich, Switzerland, September 6-12, 2014, Proceedings, Part VI 13. pp. 446-461. Springer (2014)

7. Bulat, A., Tzimiropoulos, G.: Lasp: Text-to-text optimization for language-aware soft prompting of vision & language models. In: Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition. pp. 23232-23241 (2023)

7. Bulat, A., Tzimiropoulos, G.: Lasp: Text-to-text optimization for language-aware soft prompting of vision & language models. In: Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition. pp. 23232-23241 (2023)

8. Chen, G., Yao, W., Song, X., Li, X., Rao, Y., Zhang, K.: Plot: Prompt learning with optimal transport for vision-language models. In: The Eleventh International Conference on Learning Representations (2022)

8. Chen, G., Yao, W., Song, X., Li, X., Rao, Y., Zhang, K.: Plot: 用最优传输进行视觉-语言模型的提示学习。载于:第十一届国际表征学习会议 (2022)

9. Chen, W.C., Chang, C.C., Lee, C.R.: Knowledge distillation with feature maps for image classification. In: Computer Vision-ACCV 2018: 14th Asian Conference on Computer Vision, Perth, Australia, December 2-6, 2018, Revised Selected Papers, Part III 14. pp. 200-215. Springer (2019)

9. Chen, W.C., Chang, C.C., Lee, C.R.: 利用特征图进行图像分类的知识蒸馏。载于:计算机视觉-ACCV 2018:第14届亚洲计算机视觉会议，澳大利亚珀斯，2018年12月2-6日，修订精选论文，第三部分14。第200-215页。施普林格 (2019)

10. Cherti, M., Beaumont, R., Wightman, R., Wortsman, M., Ilharco, G., Gordon, C., Schuhmann, C., Schmidt, L., Jitsev, J.: Reproducible scaling laws for contrastive language-image learning. In: Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition. pp. 2818-2829 (2023)

10. Cherti, M., Beaumont, R., Wightman, R., Wortsman, M., Ilharco, G., Gordon, C., Schuhmann, C., Schmidt, L., Jitsev, J.: 对比语言-图像学习的可复现缩放定律。载于:IEEE/CVF计算机视觉与模式识别会议论文集。第2818-2829页 (2023)

11. Cimpoi, M., Maji, S., Kokkinos, I., Mohamed, S., Vedaldi, A.: Describing textures in the wild. In: Proceedings of the IEEE conference on computer vision and pattern recognition. pp. 3606-3613 (2014)

11. Cimpoi, M., Maji, S., Kokkinos, I., Mohamed, S., Vedaldi, A.: 野外纹理描述。载于:IEEE计算机视觉与模式识别会议论文集。第3606-3613页 (2014)

12. Deng, J., Dong, W., Socher, R., Li, L.J., Li, K., Fei-Fei, L.: Imagenet: A large-scale hierarchical image database. In: 2009 IEEE conference on computer vision and pattern recognition. pp. 248-255. Ieee (2009)

12. Deng, J., Dong, W., Socher, R., Li, L.J., Li, K., Fei-Fei, L.: ImageNet:一个大规模分层图像数据库。载于:2009年IEEE计算机视觉与模式识别会议。第248-255页。IEEE (2009)

13. Desai, K., Johnson, J.: Virtex: Learning visual representations from textual annotations. In: Proceedings of the IEEE/CVF conference on computer vision and pattern recognition. pp. 11162-11173 (2021)

13. Desai, K., Johnson, J.: Virtex:从文本注释中学习视觉表示。载于:IEEE/CVF计算机视觉与模式识别会议论文集。第11162-11173页 (2021)

14. Ding, Y., Liu, L., Tian, C., Yang, J., Ding, H.: Don't stop learning: Towards continual learning for the clip model. arXiv preprint arXiv:2207.09248 (2022)

14. Ding, Y., Liu, L., Tian, C., Yang, J., Ding, H.: 不停止学习:迈向CLIP模型的持续学习。arXiv预印本 arXiv:2207.09248 (2022)

15. Dong, X., Bao, J., Zhang, T., Chen, D., Gu, S., Zhang, W., Yuan, L., Chen, D., Wen, F., Yu, N.: Clip itself is a strong fine-tuner: Achieving 85.7% and 88.0% top-1 accuracy with vit-b and vit-l on imagenet. arXiv preprint arXiv:2212.06138 (2022)

15. Dong, X., Bao, J., Zhang, T., Chen, D., Gu, S., Zhang, W., Yuan, L., Chen, D., Wen, F., Yu, N.: CLIP本身就是强大的微调器:在ImageNet上用ViT-B和ViT-L分别达到85.7%和88.0%的Top-1准确率。arXiv预印本 arXiv:2212.06138 (2022)

16. Dosovitskiy, A., Beyer, L., Kolesnikov, A., Weissenborn, D., Zhai, X., Unterthiner, T., Dehghani, M., Minderer, M., Heigold, G., Gelly, S., et al.: An image is worth 16x16 words: Transformers for image recognition at scale. In: International Conference on Learning Representations (2020)

16. Dosovitskiy, A., Beyer, L., Kolesnikov, A., Weissenborn, D., Zhai, X., Unterthiner, T., Dehghani, M., Minderer, M., Heigold, G., Gelly, S., 等:一张图像胜过16x16个词:大规模图像识别的Transformer。载于:国际表征学习会议 (2020)

17. Dou, Q., Liu, Q., Heng, P.A., Glocker, B.: Unpaired multi-modal segmentation via knowledge distillation. IEEE transactions on medical imaging $\mathbf{{39}}\left( 7\right) ,{2415} - {2425}$ (2020)

17. Dou, Q., Liu, Q., Heng, P.A., Glocker, B.: 通过知识蒸馏实现无配对多模态分割。IEEE医学影像学报 $\mathbf{{39}}\left( 7\right) ,{2415} - {2425}$ (2020)

18. Fang, A., Jose, A.M., Jain, A., Schmidt, L., Toshev, A.T., Shankar, V.: Data filtering networks. In: The Twelfth International Conference on Learning Representations (2023)

18. Fang, A., Jose, A.M., Jain, A., Schmidt, L., Toshev, A.T., Shankar, V.: 数据过滤网络。载于:第十二届国际表征学习会议 (2023)

19. Fang, Z., Wang, J., Wang, L., Zhang, L., Yang, Y., Liu, Z.: Seed: Self-supervised distillation for visual representation. In: International Conference on Learning Representations (2020)

19. Fang, Z., Wang, J., Wang, L., Zhang, L., Yang, Y., Liu, Z.: SEED:视觉表示的自监督蒸馏。载于:国际表征学习会议 (2020)

20. Fei-Fei, L., Fergus, R., Perona, P.: Learning generative visual models from few training examples: An incremental bayesian approach tested on 101 object categories. In: 2004 conference on computer vision and pattern recognition workshop. pp. 178-178. IEEE (2004)

20. Fei-Fei, L., Fergus, R., Perona, P.: 从少量训练样本学习生成视觉模型:一种增量贝叶斯方法，在101个物体类别上测试。载于:2004年计算机视觉与模式识别研讨会。第178页。IEEE (2004)

21. Gu, X., Lin, T.Y., Kuo, W., Cui, Y.: Open-vocabulary object detection via vision and language knowledge distillation. In: International Conference on Learning Representations (2021)

21. Gu, X., Lin, T.Y., Kuo, W., Cui, Y.: 通过视觉和语言知识蒸馏实现开放词汇目标检测。载于:国际表征学习会议 (2021)

22. He, T., Shen, C., Tian, Z., Gong, D., Sun, C., Yan, Y.: Knowledge adaptation for efficient semantic segmentation. In: Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition. pp. 578-587 (2019)

22. He, T., Shen, C., Tian, Z., Gong, D., Sun, C., Yan, Y.: 用于高效语义分割的知识适应。载于:IEEE/CVF计算机视觉与模式识别会议论文集。第578-587页 (2019)

23. Helber, P., Bischke, B., Dengel, A., Borth, D.: Eurosat: A novel dataset and deep learning benchmark for land use and land cover classification. IEEE Journal of Selected Topics in Applied Earth Observations and Remote Sensing $\mathbf{{12}}\left( 7\right) ,{2217} -$ 2226 (2019)

23. Helber, P., Bischke, B., Dengel, A., Borth, D.: Eurosat:一个用于土地利用和地表覆盖分类的新型数据集及深度学习基准。IEEE应用地球观测与遥感精选专题期刊 $\mathbf{{12}}\left( 7\right) ,{2217} -$ 2226 (2019)

24. Hendrycks, D., Basart, S., Mu, N., Kadavath, S., Wang, F., Dorundo, E., Desai, R., Zhu, T., Parajuli, S., Guo, M., et al.: The many faces of robustness: A critical analysis of out-of-distribution generalization. In: Proceedings of the IEEE/CVF International Conference on Computer Vision. pp. 8340-8349 (2021)

24. Hendrycks, D., Basart, S., Mu, N., Kadavath, S., Wang, F., Dorundo, E., Desai, R., Zhu, T., Parajuli, S., Guo, M., 等:鲁棒性的多面性:对分布外泛化的批判性分析。载于:IEEE/CVF国际计算机视觉会议论文集。第8340-8349页 (2021)

25. Hendrycks, D., Zhao, K., Basart, S., Steinhardt, J., Song, D.: Natural adversarial examples. In: Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition. pp. 15262-15271 (2021)

25. Hendrycks, D., Zhao, K., Basart, S., Steinhardt, J., Song, D.: 自然对抗样本。载于:IEEE/CVF计算机视觉与模式识别会议论文集。第15262-15271页 (2021)

26. Hinton, G., Vinyals, O., Dean, J.: Distilling the knowledge in a neural network. stat 1050, 9 (2015)

26. Hinton, G., Vinyals, O., Dean, J.: 神经网络中的知识蒸馏。stat 1050, 9 (2015)

27. Huang, T., Chu, J., Wei, F.: Unsupervised prompt learning for vision-language models. arXiv preprint arXiv:2204.03649 (2022)

27. Huang, T., Chu, J., Wei, F.: 视觉语言模型的无监督提示学习。arXiv预印本 arXiv:2204.03649 (2022)

28. Jia, C., Yang, Y., Xia, Y., Chen, Y.T., Parekh, Z., Pham, H., Le, Q., Sung, Y.H., Li, Z., Duerig, T.: Scaling up visual and vision-language representation learning with noisy text supervision. In: International conference on machine learning. pp. 4904-4916. PMLR (2021)

28. Jia, C., Yang, Y., Xia, Y., Chen, Y.T., Parekh, Z., Pham, H., Le, Q., Sung, Y.H., Li, Z., Duerig, T.: 利用噪声文本监督扩展视觉及视觉语言表示学习规模。载于:国际机器学习会议论文集。第4904-4916页。PMLR (2021)

29. Jia, M., Tang, L., Chen, B.C., Cardie, C., Belongie, S., Hariharan, B., Lim, S.N.: Visual prompt tuning. In: European Conference on Computer Vision (2022)

29. Jia, M., Tang, L., Chen, B.C., Cardie, C., Belongie, S., Hariharan, B., Lim, S.N.: 视觉提示调优。载于:欧洲计算机视觉会议 (2022)

30. Khattak, M.U., Rasheed, H., Maaz, M., Khan, S., Khan, F.S.: Maple: Multi-modal prompt learning. In: Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition. pp. 19113-19122 (2023)

30. Khattak, M.U., Rasheed, H., Maaz, M., Khan, S., Khan, F.S.: Maple:多模态提示学习。载于:IEEE/CVF计算机视觉与模式识别会议论文集。第19113-19122页 (2023)

31. Khattak, M.U., Wasim, S.T., Naseer, M., Khan, S., Yang, M.H., Khan, F.S.: Self-regulating prompts: Foundational model adaptation without forgetting. In: Proceedings of the IEEE/CVF International Conference on Computer Vision. pp. 15190-15200 (2023)

31. Khattak, M.U., Wasim, S.T., Naseer, M., Khan, S., Yang, M.H., Khan, F.S.: 自我调节提示:基础模型适应而不遗忘。载于:IEEE/CVF国际计算机视觉会议论文集。第15190-15200页 (2023)

32. Krause, J., Stark, M., Deng, J., Fei-Fei, L.: 3d object representations for fine-grained categorization. In: Proceedings of the IEEE international conference on computer vision workshops. pp. 554-561 (2013)

32. Krause, J., Stark, M., Deng, J., Fei-Fei, L.: 用于细粒度分类的三维物体表示。载于:IEEE国际计算机视觉会议研讨会论文集。第554-561页 (2013)

33. Kuznetsova, A., Rom, H., Alldrin, N., Uijlings, J., Krasin, I., Pont-Tuset, J., Ka-mali, S., Popov, S., Malloci, M., Kolesnikov, A., et al.: The open images dataset v4: Unified image classification, object detection, and visual relationship detection at scale. International Journal of Computer Vision (IJCV) 128(7), 1956-1981 (2020)

33. Kuznetsova, A., Rom, H., Alldrin, N., Uijlings, J., Krasin, I., Pont-Tuset, J., Kamali, S., Popov, S., Malloci, M., Kolesnikov, A., 等:开放图像数据集v4:统一的大规模图像分类、目标检测与视觉关系检测。国际计算机视觉期刊(IJCV)128(7), 1956-1981 (2020)

34. Lester, B., Al-Rfou, R., Constant, N.: The power of scale for parameter-efficient prompt tuning. In: Proceedings of the 2021 Conference on Empirical Methods in Natural Language Processing. pp. 3045-3059 (2021)

34. Lester, B., Al-Rfou, R., Constant, N.: 规模的力量:参数高效提示调优。载于:2021年自然语言处理实证方法会议论文集。第3045-3059页 (2021)

35. Li, X.L., Liang, P.: Prefix-tuning: Optimizing continuous prompts for generation. In: Proceedings of the 59th Annual Meeting of the Association for Computational Linguistics and the 11th International Joint Conference on Natural Language Processing (Volume 1: Long Papers). pp. 4582-4597 (2021)

35. Li, X.L., Liang, P.: 前缀调优:生成任务的连续提示优化。载于:第59届计算语言学协会年会暨第11届国际自然语言处理联合会议(长文集)论文集。第4582-4597页 (2021)

36. Li, Z., Li, X., Fu, X., Zhang, X., Wang, W., Chen, S., Yang, J.: Promptkd: Unsupervised prompt distillation for vision-language models. In: Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition. pp. 26617- 26626 (2024)

36. Li, Z., Li, X., Fu, X., Zhang, X., Wang, W., Chen, S., Yang, J.: Promptkd:视觉语言模型的无监督提示蒸馏。载于:IEEE/CVF计算机视觉与模式识别会议论文集。第26617-26626页 (2024)

37. Lu, Y., Liu, J., Zhang, Y., Liu, Y., Tian, X.: Prompt distribution learning. In: Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition. pp. 5206-5215 (2022)

37. Lu, Y., Liu, J., Zhang, Y., Liu, Y., Tian, X.: 提示分布学习。载于:IEEE/CVF计算机视觉与模式识别会议论文集。第5206-5215页 (2022)

38. Lüddecke, T., Ecker, A.: Image segmentation using text and image prompts. In: Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition. pp. 7086-7096 (2022)

38. Lüddecke, T., Ecker, A.: 使用文本和图像提示的图像分割。载于:IEEE/CVF计算机视觉与模式识别会议论文集。第7086-7096页 (2022)

39. Maji, S., Rahtu, E., Kannala, J., Blaschko, M., Vedaldi, A.: Fine-grained visual classification of aircraft. arXiv preprint arXiv:1306.5151 (2013)

39. Maji, S., Rahtu, E., Kannala, J., Blaschko, M., Vedaldi, A.: 飞机的细粒度视觉分类。arXiv预印本 arXiv:1306.5151 (2013)

40. Mullapudi, R.T., Chen, S., Zhang, K., Ramanan, D., Fatahalian, K.: Online model distillation for efficient video inference. In: Proceedings of the IEEE/CVF International conference on computer vision. pp. 3573-3582 (2019)

40. Mullapudi, R.T., Chen, S., Zhang, K., Ramanan, D., Fatahalian, K.: 用于高效视频推理的在线模型蒸馏。载于:IEEE/CVF国际计算机视觉会议论文集。第3573-3582页 (2019)

41. Nilsback, M.E., Zisserman, A.: Automated flower classification over a large number of classes. In: 2008 Sixth Indian conference on computer vision, graphics & image processing. pp. 722-729. IEEE (2008)

41. Nilsback, M.E., Zisserman, A.: 大规模类别的自动花卉分类。载于:2008年第六届印度计算机视觉、图形与图像处理会议。第722-729页。IEEE (2008)

42. Parelli, M., Delitzas, A., Hars, N., Vlassis, G., Anagnostidis, S., Bachmann, G., Hofmann, T.: Clip-guided vision-language pre-training for question answering in 3d scenes. In: Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition. pp. 5606-5611 (2023)

42. Parelli, M., Delitzas, A., Hars, N., Vlassis, G., Anagnostidis, S., Bachmann, G., Hofmann, T.: 基于CLIP引导的视觉-语言预训练用于3D场景问答。载于:IEEE/CVF计算机视觉与模式识别会议论文集。第5606-5611页 (2023)

43. Parkhi, O.M., Vedaldi, A., Zisserman, A., Jawahar, C.: Cats and dogs. In: 2012 IEEE conference on computer vision and pattern recognition. pp. 3498-3505. IEEE (2012)

43. Parkhi, O.M., Vedaldi, A., Zisserman, A., Jawahar, C.: 猫与狗。载于:2012年IEEE计算机视觉与模式识别会议。第3498-3505页。IEEE (2012)

44. Radford, A., Kim, J.W., Hallacy, C., Ramesh, A., Goh, G., Agarwal, S., Sastry, G., Askell, A., Mishkin, P., Clark, J., et al.: Learning transferable visual models from natural language supervision. In: International conference on machine learning. pp. 8748-8763. PMLR (2021)

44. Radford, A., Kim, J.W., Hallacy, C., Ramesh, A., Goh, G., Agarwal, S., Sastry, G., Askell, A., Mishkin, P., Clark, J., 等: 从自然语言监督中学习可迁移视觉模型。载于:国际机器学习会议。第8748-8763页。PMLR (2021)

45. Recht, B., Roelofs, R., Schmidt, L., Shankar, V.: Do imagenet classifiers generalize to imagenet? In: International conference on machine learning. pp. 5389-5400. PMLR (2019)

45. Recht, B., Roelofs, R., Schmidt, L., Shankar, V.: ImageNet分类器能否泛化到ImageNet？载于:国际机器学习会议。第5389-5400页。PMLR (2019)

46. Ren, S., Zhang, A., Zhu, Y., Zhang, S., Zheng, S., Li, M., Smola, A.J., Sun, X.: Prompt pre-training with twenty-thousand classes for open-vocabulary visual recognition. Advances in Neural Information Processing Systems 36 (2024)

46. Ren, S., Zhang, A., Zhu, Y., Zhang, S., Zheng, S., Li, M., Smola, A.J., Sun, X.: 用两万类进行提示预训练以实现开放词汇视觉识别。神经信息处理系统进展36 (2024)

47. Schuhmann, C., Beaumont, R., Vencu, R., Gordon, C., Wightman, R., Cherti, M., Coombes, T., Katta, A., Mullis, C., Wortsman, M., et al.: Laion-5b: An open large-scale dataset for training next generation image-text models. Advances in Neural Information Processing Systems 35, 25278-25294 (2022)

47. Schuhmann, C., Beaumont, R., Vencu, R., Gordon, C., Wightman, R., Cherti, M., Coombes, T., Katta, A., Mullis, C., Wortsman, M., 等: LAION-5B:用于训练下一代图文模型的开放大规模数据集。神经信息处理系统进展35, 25278-25294 (2022)

48. Schuhmann, C., Vencu, R., Beaumont, R., Kaczmarczyk, R., Mullis, C., Katta, A., Coombes, T., Jitsev, J., Komatsuzaki, A.: Laion-400m: Open dataset of clip-filtered 400 million image-text pairs. arXiv preprint arXiv:2111.02114 (2021)

48. Schuhmann, C., Vencu, R., Beaumont, R., Kaczmarczyk, R., Mullis, C., Katta, A., Coombes, T., Jitsev, J., Komatsuzaki, A.: LAION-400M:CLIP筛选的4亿图文对开放数据集。arXiv预印本 arXiv:2111.02114 (2021)

49. Shi, C., Yang, S.: Logoprompt: Synthetic text images can be good visual prompts for vision-language models. In: Proceedings of the IEEE/CVF International Conference on Computer Vision. pp. 2932-2941 (2023)

49. Shi, C., Yang, S.: Logoprompt:合成文本图像可作为视觉语言模型的良好视觉提示。载于:IEEE/CVF国际计算机视觉会议论文集。第2932-2941页 (2023)

50. Shi, Z., Lipani, A.: DePT: Decomposed prompt tuning for parameter-efficient fine-tuning. In: The Twelfth International Conference on Learning Representations (2024), https://openreview.net/forum?id=KjegfPGRde

50. Shi, Z., Lipani, A.: DePT:分解提示调优用于参数高效微调。载于:第十二届国际表征学习会议 (2024), https://openreview.net/forum?id=KjegfPGRde

51. Siam, M., Jiang, C., Lu, S., Petrich, L., Gamal, M., Elhoseiny, M., Jagersand, M.: Video object segmentation using teacher-student adaptation in a human robot interaction (hri) setting. In: 2019 International Conference on Robotics and Automation (ICRA). pp. 50-56. IEEE (2019)

51. Siam, M., Jiang, C., Lu, S., Petrich, L., Gamal, M., Elhoseiny, M., Jagersand, M.: 在人机交互(HRI)环境中使用师生适应的视频目标分割。载于:2019年国际机器人与自动化会议(ICRA)。第50-56页。IEEE (2019)

52. Song, H., Dong, L., Zhang, W., Liu, T., Wei, F.: Clip models are few-shot learners: Empirical studies on vqa and visual entailment. In: Proceedings of the 60th Annual Meeting of the Association for Computational Linguistics (Volume 1: Long Papers). pp. 6088-6100 (2022)

52. 宋浩, 董磊, 张伟, 刘涛, 魏峰: Clip模型是少样本学习者:关于视觉问答和视觉蕴涵的实证研究. 载于: 第60届计算语言学协会年会论文集(第一卷:长篇论文). 页6088-6100 (2022)

53. Soomro, K., Zamir, A.R., Shah, M.: Ucf101: A dataset of 101 human actions classes from videos in the wild. arXiv preprint arXiv:1212.0402 (2012)

53. Soomro, K., Zamir, A.R., Shah, M.: Ucf101: 一个包含101类野外视频中人类动作的数据集. arXiv预印本 arXiv:1212.0402 (2012)

54. Wang, H., Ge, S., Lipton, Z., Xing, E.P.: Learning robust global representations by penalizing local predictive power. Advances in Neural Information Processing Systems 32 (2019)

54. 王浩, 葛爽, Lipton, Z., Xing, E.P.: 通过惩罚局部预测能力学习鲁棒的全局表示. 神经信息处理系统进展 32 (2019)

55. Wang, Z., Liang, J., He, R., Xu, N., Wang, Z., Tan, T.: Improving zero-shot generalization for clip with synthesized prompts. In: Proceedings of the IEEE/CVF International Conference on Computer Vision. pp. 3032-3042 (2023)

55. 王志, 梁军, 何然, 徐宁, 王志, 谭铁牛: 通过合成提示提升CLIP的零样本泛化能力. 载于: IEEE/CVF国际计算机视觉会议论文集. 页3032-3042 (2023)

56. Xiao, J., Hays, J., Ehinger, K.A., Oliva, A., Torralba, A.: Sun database: Large-scale scene recognition from abbey to zoo. In: 2010 IEEE computer society conference on computer vision and pattern recognition. pp. 3485-3492. IEEE (2010)

56. 肖健, Hays, J., Ehinger, K.A., Oliva, A., Torralba, A.: SUN数据库:从修道院到动物园的大规模场景识别. 载于: 2010年IEEE计算机学会计算机视觉与模式识别会议. 页3485-3492. IEEE (2010)

57. Xu, G., Liu, Z., Li, X., Loy, C.C.: Knowledge distillation meets self-supervision. In: European Conference on Computer Vision. pp. 588-604. Springer (2020)

57. 徐刚, 刘志, 李翔, Loy, C.C.: 知识蒸馏与自监督的结合. 载于: 欧洲计算机视觉会议. 页588-604. Springer (2020)

58. Yao, H., Zhang, R., Xu, C.: Visual-language prompt tuning with knowledge-guided context optimization. In: Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition. pp. 6757-6767 (2023)

58. 姚浩, 张锐, 徐晨: 基于知识引导上下文优化的视觉语言提示调优. 载于: IEEE/CVF计算机视觉与模式识别会议论文集. 页6757-6767 (2023)

59. Yuan, L., Tay, F.E., Li, G., Wang, T., Feng, J.: Revisiting knowledge distillation via label smoothing regularization. In: Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition. pp. 3903-3911 (2020)

59. 袁亮, Tay, F.E., 李刚, 王涛, 冯军: 通过标签平滑正则化重新审视知识蒸馏. 载于: IEEE/CVF计算机视觉与模式识别会议论文集. 页3903-3911 (2020)

60. Yun, S., Park, J., Lee, K., Shin, J.: Regularizing class-wise predictions via self-knowledge distillation. In: Proceedings of the IEEE/CVF conference on computer vision and pattern recognition. pp. 13876-13885 (2020)

60. Yun, S., Park, J., Lee, K., Shin, J.: 通过自我知识蒸馏正则化类别预测. 载于: IEEE/CVF计算机视觉与模式识别会议论文集. 页13876-13885 (2020)

61. Zhai, X., Wang, X., Mustafa, B., Steiner, A., Keysers, D., Kolesnikov, A., Beyer, L.: Lit: Zero-shot transfer with locked-image text tuning. In: Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition. pp. 18123- 18133 (2022)

61. 翟翔, 王翔, Mustafa, B., Steiner, A., Keysers, D., Kolesnikov, A., Beyer, L.: LIT:基于锁定图像文本调优的零样本迁移. 载于: IEEE/CVF计算机视觉与模式识别会议论文集. 页18123-18133 (2022)

62. Zhang, R., Fang, R., Zhang, W., Gao, P., Li, K., Dai, J., Qiao, Y., Li, H.: Tip-adapter: Training-free clip-adapter for better vision-language modeling. arXiv preprint arXiv:2111.03930 (2021)

62. 张锐, 方锐, 张伟, 高鹏, 李凯, 戴军, 乔阳, 李辉: Tip-adapter:无训练的CLIP适配器以提升视觉语言建模. arXiv预印本 arXiv:2111.03930 (2021)

63. Zhang, Y., Xiang, T., Hospedales, T.M., Lu, H.: Deep mutual learning. In: Proceedings of the IEEE conference on computer vision and pattern recognition. pp. 4320-4328 (2018)

63. 张洋, 向涛, Hospedales, T.M., 陆昊: 深度互学. 载于: IEEE计算机视觉与模式识别会议论文集. 页4320-4328 (2018)

64. Zhao, B., Cui, Q., Song, R., Qiu, Y., Liang, J.: Decoupled knowledge distillation. In: Proceedings of the IEEE/CVF Conference on computer vision and pattern recognition. pp. 11953-11962 (2022)

64. 赵斌, 崔强, 宋锐, 邱阳, 梁军: 解耦知识蒸馏. 载于: IEEE/CVF计算机视觉与模式识别会议论文集. 页11953-11962 (2022)

65. Zhong, Z., Friedman, D., Chen, D.: Factual probing is [mask]: Learning vs. learning to recall. In: Proceedings of the 2021 Conference of the North American Chapter of the Association for Computational Linguistics: Human Language Technologies. pp. 5017-5033 (2021)

65. 钟志, Friedman, D., 陈丹: 事实探测是[掩码]:学习与学习回忆. 载于: 2021年北美计算语言学协会人类语言技术会议论文集. 页5017-5033 (2021)

66. Zhou, C., Loy, C.C., Dai, B.: Extract free dense labels from clip. In: European Conference on Computer Vision. pp. 696-712. Springer (2022)

66. 周成, Loy, C.C., 戴斌: 从CLIP中提取自由密集标签. 载于: 欧洲计算机视觉会议. 页696-712. Springer (2022)

67. Zhou, K., Yang, J., Loy, C.C., Liu, Z.: Conditional prompt learning for vision-language models. In: Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition. pp. 16816-16825 (2022)

67. 周康, 杨军, Loy, C.C., 刘志: 视觉语言模型的条件提示学习. 载于: IEEE/CVF计算机视觉与模式识别会议论文集. 页16816-16825 (2022)

68. Zhou, K., Yang, J., Loy, C.C., Liu, Z.: Learning to prompt for vision-language models. International Journal of Computer Vision 130(9), 2337-2348 (2022)

68. Zhou, K., Yang, J., Loy, C.C., Liu, Z.: 学习为视觉-语言模型设计提示。国际计算机视觉杂志 130(9), 2337-2348 (2022)

69. Zhu, B., Niu, Y., Han, Y., Wu, Y., Zhang, H.: Prompt-aligned gradient for prompt tuning. In: 2023 IEEE/CVF International Conference on Computer Vision (ICCV). pp. 15613-15623. IEEE Computer Society (2023)

69. Zhu, B., Niu, Y., Han, Y., Wu, Y., Zhang, H.: 用于提示调优的提示对齐梯度。在:2023 IEEE/CVF 国际计算机视觉会议(ICCV)。第15613-15623页。IEEE计算机学会 (2023)

# Supplementary Material for: Improving Zero-shot Generalization of Learned Prompts via Unsupervised Knowledge Distillation

# 补充材料:通过无监督知识蒸馏提升学习提示的零样本泛化能力

*Marco Mistretta ${}^{1}$ , *Alberto Baldrati ${}^{1,2}$ , Marco Bertini ${}^{1}$ , and Andrew D. Bagdanov ${}^{1}$

*Marco Mistretta ${}^{1}$ , *Alberto Baldrati ${}^{1,2}$ , Marco Bertini ${}^{1}$ ,和 Andrew D. Bagdanov ${}^{1}$

${}^{1}$ University of Florence - Media Integration and Communication Center (MICC) ${}^{2}$ University of Pisa

${}^{1}$ 佛罗伦萨大学 - 媒体整合与传播中心 (MICC) ${}^{2}$ 比萨大学

Florence, Italy - Pisa, Italy

意大利佛罗伦萨 - 意大利比萨

\{name.surname\}@unifi.it

\{name.surname\}@unifi.it

## Overview

## 概述

This document contains Supplementary Material that provides additional details and further experimental analysis. The contents are organized as follows:

本文档包含补充材料，提供更多细节和进一步的实验分析。内容组织如下:

- A. Additional Implementation Details: This section provides additional implementation details, including hyperparameters and configuration settings for reproducing all reported results and further details about the datasets used.

- A. 额外实现细节:本节提供额外的实现细节，包括超参数和配置设置，以复现所有报告的结果，并详细介绍所用数据集。

- B. Ablation Study

- B. 消融研究

- B.1. Pseudolabelling versus KDPL: This subsection compares KDPL performances with a famous pseudolabeling prompt learning strategy demonstrating the superiority of KDPL over the baseline approach.

- B.1. 伪标签与KDPL对比:本小节比较KDPL与著名的伪标签提示学习策略的性能，展示KDPL相较基线方法的优越性。

- B.2. Sampling Strategies for Class Agnostic Adaptation: This part evaluates different sampling strategies for class agnostic adaptation and their performance varying the number of sampled class names.

- B.2. 无类别适应的采样策略:本部分评估不同采样策略在无类别适应中的表现，并考察采样类别名称数量变化的影响。

- B.3. Symmetric versus Asymmetric KL: This section explores the impact of using symmetric versus asymmetric KL-divergence in the loss function explaining why is more effective for class agnostic scenarios.

- B.3. 对称与非对称KL散度:本节探讨在损失函数中使用对称与非对称KL散度的影响，解释为何对称KL在无类别场景中更有效。

- B.4. Is a smaller Teacher enough? Here, we investigate whether smaller teachers model can achieve competitive performance compared to the larger ViT-H-14 teacher model used in the main paper.

- B.4. 更小的教师模型是否足够？本节研究较小的教师模型是否能达到主文中使用的大型ViT-H-14教师模型的竞争性能。

- C. Additional Results

- C. 额外结果

- C.1. Generalization to Unseen Classes: Here we present additional experimental results for the generalization to unseen classes within the same dataset scenario, including the downstream performance of few-shot base as well as the harmonic mean of base and unseen classes.

- C.1. 对未见类别的泛化:本节展示了在同一数据集场景下对未见类别泛化的额外实验结果，包括少样本基础类别的下游性能以及基础类别和未见类别的调和平均值。

- C.2. Class Agnostic Scenario: This section provides additional results for the class agnostic setting, our proposed new setting in which we know neither the labels nor the names of the training classes.

- C.2. 类别无关场景:本节提供了类别无关设置的额外结果，该设置是我们提出的新场景，其中训练类别的标签和名称均未知。

---

* These authors contributed equally to this work.

* 这些作者对本工作贡献相同。

---

Table 4: Configuration of hyperparame-ters for the re-computed baselines. Note that $\mathrm{{CoOp}}$ and $\mathrm{{CoCoOp}}$ , being textual prompt learning methods, do not learn visual tokens.

表4:重新计算基线的超参数配置。注意，$\mathrm{{CoOp}}$和$\mathrm{{CoCoOp}}$作为文本提示学习方法，不学习视觉标记。

<table><tr><td>Dataset</td><td>CoOp</td><td>CoCoOp</td><td>VPT</td><td>MaPLe</td><td>PromptSRC</td></tr><tr><td>Batch Size</td><td>32</td><td>1</td><td>4</td><td>4</td><td>4</td></tr><tr><td>Optimizer</td><td>SGD</td><td>SGD</td><td>SGD</td><td>SGD</td><td>SGD</td></tr><tr><td>LR</td><td>0.02</td><td>0.02</td><td>0.0025</td><td>0.0035</td><td>0.0025</td></tr><tr><td>Epochs</td><td>50</td><td>10</td><td>5</td><td>5</td><td>20</td></tr><tr><td>Text-tokens</td><td>4</td><td>4</td><td>4</td><td>4</td><td>4</td></tr><tr><td>Visual-tokens</td><td>-</td><td>-</td><td>8</td><td>2</td><td>4</td></tr><tr><td>Vision-depth</td><td>-</td><td>-</td><td>12</td><td>9</td><td>9</td></tr></table>

<table><tbody><tr><td>数据集</td><td>CoOp</td><td>CoCoOp</td><td>VPT</td><td>MaPLe</td><td>PromptSRC</td></tr><tr><td>批量大小</td><td>32</td><td>1</td><td>4</td><td>4</td><td>4</td></tr><tr><td>优化器</td><td>随机梯度下降(SGD)</td><td>随机梯度下降(SGD)</td><td>随机梯度下降(SGD)</td><td>随机梯度下降(SGD)</td><td>随机梯度下降(SGD)</td></tr><tr><td>学习率(LR)</td><td>0.02</td><td>0.02</td><td>0.0025</td><td>0.0035</td><td>0.0025</td></tr><tr><td>训练轮数</td><td>50</td><td>10</td><td>5</td><td>5</td><td>20</td></tr><tr><td>文本标记</td><td>4</td><td>4</td><td>4</td><td>4</td><td>4</td></tr><tr><td>视觉标记</td><td>-</td><td>-</td><td>8</td><td>2</td><td>4</td></tr><tr><td>视觉深度</td><td>-</td><td>-</td><td>12</td><td>9</td><td>9</td></tr></tbody></table>

Table 5: Datasets statistics.

表5:数据集统计。

<table><tr><td>Dataset</td><td>Classes</td><td>Train</td><td>Val</td><td>Test</td></tr><tr><td>ImageNet</td><td>1,000</td><td>1.28M</td><td>N/A</td><td>50,000</td></tr><tr><td>Caltech101</td><td>100</td><td>4,128</td><td>1,649</td><td>2,465</td></tr><tr><td>OxfordPets 43</td><td>37</td><td>2,944</td><td>736</td><td>3,669</td></tr><tr><td>StanfordCars 32]</td><td>196</td><td>6,509</td><td>1,635</td><td>8,041</td></tr><tr><td>Flowers102</td><td>102</td><td>4,093</td><td>1,633</td><td>2,463</td></tr><tr><td>Food101 [6]</td><td>101</td><td>50,500</td><td>20,300</td><td>30,300</td></tr><tr><td>FGVCAircraft39</td><td>100</td><td>3,334</td><td>3,333</td><td>3,333</td></tr><tr><td>SUN39756</td><td>397</td><td>15,880</td><td>3,970</td><td>19,850</td></tr><tr><td>DTD 11</td><td>47</td><td>2,820</td><td>1,128</td><td>1,692</td></tr><tr><td>EuroSAT23</td><td>10</td><td>13,500</td><td>5,400</td><td>8,100</td></tr><tr><td>UCF10153</td><td>101</td><td>7,639</td><td>1,898</td><td>3,783</td></tr><tr><td>ImageNetV245</td><td>1,000</td><td>N/A</td><td>N/A</td><td>10,000</td></tr><tr><td>ImageNet-S54</td><td>1,000</td><td>N/A</td><td>N/A</td><td>50,889</td></tr><tr><td>ImageNet-A25</td><td>200</td><td>N/A</td><td>N/A</td><td>7,500</td></tr><tr><td>ImageNet-R24</td><td>200</td><td>N/A</td><td>N/A</td><td>30,000</td></tr></table>

<table><tbody><tr><td>数据集</td><td>类别</td><td>训练集</td><td>验证集</td><td>测试集</td></tr><tr><td>ImageNet</td><td>1,000</td><td>1.28M</td><td>不适用</td><td>50,000</td></tr><tr><td>Caltech101</td><td>100</td><td>4,128</td><td>1,649</td><td>2,465</td></tr><tr><td>OxfordPets 43</td><td>37</td><td>2,944</td><td>736</td><td>3,669</td></tr><tr><td>StanfordCars 32]</td><td>196</td><td>6,509</td><td>1,635</td><td>8,041</td></tr><tr><td>Flowers102</td><td>102</td><td>4,093</td><td>1,633</td><td>2,463</td></tr><tr><td>Food101 [6]</td><td>101</td><td>50,500</td><td>20,300</td><td>30,300</td></tr><tr><td>FGVCAircraft39</td><td>100</td><td>3,334</td><td>3,333</td><td>3,333</td></tr><tr><td>SUN39756</td><td>397</td><td>15,880</td><td>3,970</td><td>19,850</td></tr><tr><td>DTD 11</td><td>47</td><td>2,820</td><td>1,128</td><td>1,692</td></tr><tr><td>EuroSAT23</td><td>10</td><td>13,500</td><td>5,400</td><td>8,100</td></tr><tr><td>UCF10153</td><td>101</td><td>7,639</td><td>1,898</td><td>3,783</td></tr><tr><td>ImageNetV245</td><td>1,000</td><td>不适用</td><td>不适用</td><td>10,000</td></tr><tr><td>ImageNet-S54</td><td>1,000</td><td>不适用</td><td>不适用</td><td>50,889</td></tr><tr><td>ImageNet-A25</td><td>200</td><td>不适用</td><td>不适用</td><td>7,500</td></tr><tr><td>ImageNet-R24</td><td>200</td><td>不适用</td><td>不适用</td><td>30,000</td></tr></tbody></table>

## A. Additional Implementation Details

## A. 额外的实现细节

In this section we provide further details on hyperparameters of the proposed approaches presented in the main paper and additional details on the benchmark datasets evaluated.

本节中我们提供了主论文中提出方法的超参数的更多细节，以及评估的基准数据集的附加信息。

Hyperparameter settings. For all evaluated scenarios we recalculated all baseline results using the parameter and hyperparameter settings reported in the original publications [29-31, 67, 68].

超参数设置。对于所有评估场景，我们均使用原始文献[29-31, 67, 68]中报告的参数和超参数设置重新计算了所有基线结果。

In Table 4 we summarize all configuration settings. Notably, all the evaluated baselines use a cosine scheduler with one warm-up epoch with a constant learning rate of 1e-5, and all authors suggest initializing the textual context with "a photo of a" as a better starting point. Note that our variants augmented with Knowledge Distillation Prompt Learning (KDPL) were trained using exactly the same parameters and configuration settings as the baseline methods. Therefore, it is reasonable to expect that further hyperparameter tuning could potentially improve our performance even further.

在表4中我们总结了所有配置设置。值得注意的是，所有评估的基线方法均采用带有一个预热周期的余弦调度器，学习率恒定为1e-5，且所有作者均建议以“a photo of a”初始化文本上下文作为更好的起点。请注意，我们通过知识蒸馏提示学习(Knowledge Distillation Prompt Learning, KDPL)增强的变体，训练时使用的参数和配置设置与基线方法完全相同。因此，可以合理预期进一步的超参数调优可能会进一步提升我们的性能。

In addition, all the baselines - and so also our augmented versions - adhere to the same preprocessing pipeline in which input images are resized to ${224} \times  {224}$ pixels using bicubic interpolation. Data augmentations including random resized crop, random flip, and normalization are used to ensure robustness.

此外，所有基线方法——因此也包括我们增强的版本——均遵循相同的预处理流程，输入图像通过双三次插值调整为${224} \times  {224}$像素。使用随机调整大小裁剪、随机翻转和归一化等数据增强方法以确保鲁棒性。

To ensure consistency with baselines and to facilitate easy comparison and evaluation, our implementation is built upon the Dassl framework ${}^{3}$ , which serves as the foundation for all these methods. We use ResNet-50 and ViT-B/32 as the backbones for all experiments. These backbones are the original publicly available models released by OpenAI ${}^{4}$ As mentioned in the main paper, the code is publicly available at https://github.com/miccunifi/KDPL

为确保与基线方法的一致性并便于比较和评估，我们的实现基于Dassl框架${}^{3}$，该框架是所有这些方法的基础。所有实验均采用ResNet-50和ViT-B/32作为骨干网络。这些骨干网络是OpenAI${}^{4}$公开发布的原始模型。如主论文所述，代码公开托管于https://github.com/miccunifi/KDPL

---

3 https://github.com/KaiyangZhou/Dassl.pytorch

3 https://github.com/KaiyangZhou/Dassl.pytorch

4 https://github.com/openai/CLIP

4 https://github.com/openai/CLIP

---

Table 6: Ablations on labeling, sampling, and KL-divergence. (a) Comparison of KDPL and a pseudolabeling strategy adapted from UPL [27]. (b) Ablation on a number of classes sampled for class agnostic adaptation. (c) Comparison of forward, reverse, and symmetric KL-divergence used in the loss (see Eq. 2 of the main paper). (b) Sampling strategy

表6:关于标注、采样和KL散度的消融实验。(a) KDPL与改编自UPL [27]的伪标签策略的比较。(b) 针对类别无关适应采样类别数量的消融。(c) 损失函数中使用的正向、反向和对称KL散度的比较(见主论文公式2)。(b) 采样策略

<table><tr><td/><td>Source</td><td>AVG1</td><td>${\mathrm{{AVG}}}^{2}$</td></tr><tr><td>CLIP(student)</td><td>58.20</td><td>40.63</td><td>55.81</td></tr><tr><td>CoOp${\mathrm{{UPL}}}^{ * }$</td><td>62.37</td><td>42.72</td><td>56.24</td></tr><tr><td>CoOpKDPL</td><td>62.73</td><td>42.90</td><td>57.59</td></tr><tr><td>CoOpCA-UPL*</td><td>60.13</td><td>42.48</td><td>55.73</td></tr><tr><td>CoOpCA-KDPL</td><td>61.83</td><td>43.02</td><td>57.69</td></tr></table>

<table><tbody><tr><td></td><td>源</td><td>平均1</td><td>${\mathrm{{AVG}}}^{2}$</td></tr><tr><td>CLIP(学生)</td><td>58.20</td><td>40.63</td><td>55.81</td></tr><tr><td>CoOp${\mathrm{{UPL}}}^{ * }$</td><td>62.37</td><td>42.72</td><td>56.24</td></tr><tr><td>CoOpKDPL</td><td>62.73</td><td>42.90</td><td>57.59</td></tr><tr><td>CoOpCA-UPL*</td><td>60.13</td><td>42.48</td><td>55.73</td></tr><tr><td>CoOpCA-KDPL</td><td>61.83</td><td>43.02</td><td>57.69</td></tr></tbody></table>

(a) KDPL vs. pseudolabeling

(a) KDPL 与伪标签法的比较

<table><tr><td/><td>Source</td><td>${\mathrm{{AVG}}}^{1}$</td><td>${\mathrm{{AVG}}}^{2}$</td></tr><tr><td>POMP*</td><td>60.80</td><td>42.37</td><td>57.35</td></tr><tr><td>CA-KDPL$\left( {K = {100}}\right)$</td><td>61.50</td><td>42.45</td><td>57.06</td></tr><tr><td>CA-KDPL( $K = {500}$ )</td><td>61.73</td><td>42.68</td><td>57.38</td></tr><tr><td>CA-KDPL$\left( {K = 1\mathrm{\;K}}\right)$</td><td>61.83</td><td>43.02</td><td>57.69</td></tr><tr><td>CA-KDPL( $K = 2\mathrm{K}$ )</td><td>61.60</td><td>43.07</td><td>57.51</td></tr></table>

<table><tbody><tr><td></td><td>来源</td><td>${\mathrm{{AVG}}}^{1}$</td><td>${\mathrm{{AVG}}}^{2}$</td></tr><tr><td>POMP*</td><td>60.80</td><td>42.37</td><td>57.35</td></tr><tr><td>CA-KDPL$\left( {K = {100}}\right)$</td><td>61.50</td><td>42.45</td><td>57.06</td></tr><tr><td>CA-KDPL( $K = {500}$ )</td><td>61.73</td><td>42.68</td><td>57.38</td></tr><tr><td>CA-KDPL$\left( {K = 1\mathrm{\;K}}\right)$</td><td>61.83</td><td>43.02</td><td>57.69</td></tr><tr><td>CA-KDPL( $K = 2\mathrm{K}$ )</td><td>61.60</td><td>43.07</td><td>57.51</td></tr></tbody></table>

<table><tr><td/><td/><td>${\mathrm{{AVG}}}^{1}$</td><td>${\mathrm{{AVG}}}^{1}$</td></tr><tr><td>$\mathrm{{CoOp}} + \mathrm{{KDPLF}}$</td><td>63.13</td><td>43.16</td><td>57.33</td></tr><tr><td>$\mathrm{{CoOp}} + \mathrm{{KDPLR}}$</td><td>62.47</td><td>42.44</td><td>57.24</td></tr><tr><td>$\mathrm{{CoOp}} + \mathrm{{KDPL}}$</td><td>62.73</td><td>42.90</td><td>57.59</td></tr><tr><td>CoOpCA-KDPL F</td><td>60.77</td><td>42.68</td><td>56.39</td></tr><tr><td>CoOpCA-KDPL R</td><td>61.37</td><td>42.71</td><td>57.12</td></tr><tr><td>CA-KDPL</td><td>61.83</td><td>43.02</td><td>57.69</td></tr></table>

<table><tbody><tr><td></td><td></td><td>${\mathrm{{AVG}}}^{1}$</td><td>${\mathrm{{AVG}}}^{1}$</td></tr><tr><td>$\mathrm{{CoOp}} + \mathrm{{KDPLF}}$</td><td>63.13</td><td>43.16</td><td>57.33</td></tr><tr><td>$\mathrm{{CoOp}} + \mathrm{{KDPLR}}$</td><td>62.47</td><td>42.44</td><td>57.24</td></tr><tr><td>$\mathrm{{CoOp}} + \mathrm{{KDPL}}$</td><td>62.73</td><td>42.90</td><td>57.59</td></tr><tr><td>CoOpCA-KDPL F</td><td>60.77</td><td>42.68</td><td>56.39</td></tr><tr><td>CoOpCA-KDPL R</td><td>61.37</td><td>42.71</td><td>57.12</td></tr><tr><td>CA-KDPL</td><td>61.83</td><td>43.02</td><td>57.69</td></tr></tbody></table>

(c) Symmetric/asymmetric KL

(c)对称/非对称KL散度

Dataset Details. The detailed statistics of the 11 datasets used in the Cross-dataset transfer setting, as well as the four variants of ImageNet used in the Cross-domain generalization setting, are given in Table 5 Note that according to the authors of CoOp, for Caltech101, the "BACKGROUND Google" and "Faces easy" classes are discarded, and for the video dataset UCF101 the middle frame of each video is used as input to the image encoder [68].

数据集详情。表5中给出了跨数据集迁移设置中使用的11个数据集的详细统计信息，以及跨域泛化设置中使用的四个ImageNet变体。需要注意的是，根据CoOp作者的说明，对于Caltech101，"BACKGROUND Google"和"Faces easy"类别被舍弃，对于视频数据集UCF101，每个视频的中间帧被用作图像编码器的输入[68]。

## B. Ablation Study

## B. 消融研究

We performed a range of ablation studies to evaluate all aspects of KDPL. All ablations reported here are averages over three independent runs using $\mathrm{{CoOp}}$ as the baseline approach and ResNet-50 as the student backbone. The prompt is learned on ImageNet and evaluated on the benchmark datasets used in the domain generalization $\left( {\mathrm{{AVG}}}^{1}\right)$ and cross-dataset $\left( {\mathrm{{AVG}}}^{2}\right)$ evaluations.

我们进行了多项消融实验以评估KDPL的各个方面。此处报告的所有消融结果均为三次独立运行的平均值，基线方法为$\mathrm{{CoOp}}$，学生网络骨干为ResNet-50。提示词在ImageNet上学习，并在域泛化$\left( {\mathrm{{AVG}}}^{1}\right)$和跨数据集$\left( {\mathrm{{AVG}}}^{2}\right)$评估中使用的基准数据集上进行评估。

### B.1. Pseudolabeling versus KDPL

### B.1. 伪标签方法与KDPL的比较

We compare KDPL and CA-KDPL with a pseudolabeling strategy for exploiting unlabeled samples. Similar to the approach outlined in UPL [27], we generate teacher-derived labels for the training samples. Instead of selecting the top-K confident pseu-dolabels over the entire training set, for a fair comparison we pseudolabel the fixed, few shot samples in each run. We call this baseline UPL*. Table 6(a) shows that KDPL consistently outperforms UPL* on all the evaluated scenarios.

我们将KDPL和CA-KDPL与利用未标记样本的伪标签策略进行了比较。类似于UPL [27]中提出的方法，我们为训练样本生成教师模型派生的标签。为了公平比较，我们不是在整个训练集上选择置信度最高的前K个伪标签，而是在每次运行中对固定的少量样本进行伪标签标注。我们将此基线称为UPL*。表6(a)显示，KDPL在所有评估场景中均持续优于UPL*。

### B.2. Sampling Strategies for Class Agnostic Adaptation

### B.2. 无类别适应的采样策略

An important detail in the class agnostic adaptation scenario is how class names are selected for computing the loss. Existing supervised approaches, such as POMP [46], to handling large numbers of classes suggest simply using the ground truth labels of batch samples and supplementing them with randomly selected ones to reach a predetermined number $K$ . We adapted this technique and compare it with ours in Table 6(b). These results show that KDPL outperforms the random selection strategy denoted as POMP*. Notably, the optimal number of classes for domain generalization and cross-dataset adaptation is 1000 , suggesting that the optimum closely aligns with the actual number of classes in the training dataset.

在无类别适应场景中，一个重要细节是如何选择类别名称来计算损失。现有的监督方法，如POMP [46]，在处理大量类别时建议仅使用批次样本的真实标签，并随机补充类别以达到预定数量$K$。我们采用了该技术并在表6(b)中与我们的方法进行了比较。结果表明，KDPL优于称为POMP*的随机选择策略。值得注意的是，域泛化和跨数据集适应的最佳类别数为1000，表明最优值与训练数据集中的实际类别数高度一致。

Table 7: Average accuracy comparison on the three evaluated scenarios between the supervised baseline CoOp and our unsupervised approach (CoOp + KDPL) using different and smaller teachers.

表7:在三个评估场景中，使用不同且较小教师模型的监督基线CoOp与我们的无监督方法(CoOp + KDPL)的平均准确率比较。

<table><tr><td rowspan="2">Method</td><td rowspan="2"/><td colspan="3">Target downstream Average</td></tr><tr><td>Domain Source Generalization</td><td>Cross-Dataset Transfer</td><td>Generalization to Unseen Classes</td></tr><tr><td>CoOp</td><td>62.40</td><td>42.05</td><td>55.28</td><td>60.82</td></tr><tr><td>$\mathrm{{CoOp}} + \mathrm{{KDPL}}$ (B/16)</td><td>60.73</td><td>42.27</td><td>56.52</td><td>67.57</td></tr><tr><td>CoOp + KDPL (L/14)</td><td>61.43</td><td>42.61</td><td>57.10</td><td>66.90</td></tr><tr><td>CoOp + KDPL (H/14)</td><td>62.73</td><td>42.90</td><td>57.59</td><td>63.80</td></tr></table>

<table><tbody><tr><td rowspan="2">方法</td><td rowspan="2"></td><td colspan="3">目标下游平均</td></tr><tr><td>领域源泛化</td><td>跨数据集迁移</td><td>对未见类别的泛化</td></tr><tr><td>CoOp</td><td>62.40</td><td>42.05</td><td>55.28</td><td>60.82</td></tr><tr><td>$\mathrm{{CoOp}} + \mathrm{{KDPL}}$ (B/16)</td><td>60.73</td><td>42.27</td><td>56.52</td><td>67.57</td></tr><tr><td>CoOp + KDPL(L/14)</td><td>61.43</td><td>42.61</td><td>57.10</td><td>66.90</td></tr><tr><td>CoOp + KDPL(H/14)</td><td>62.73</td><td>42.90</td><td>57.59</td><td>63.80</td></tr></tbody></table>

### B.3. Symmetric versus Asymmetric KL

### B.3. 对称与非对称KL散度

In Eq. 2 of the main paper we propose to use the symmetric KL-divergence, which is a sum of the forward (from teacher to student) and reverse (from student to teacher) KL-divergences. An asymmetric forward loss may yield benefits when the target distribution is similar to the source distribution (see Table 6(c)). Conversely, a reverse loss may prove better in the opposite scenario. If the Teacher outputs probability zero for a class on a training sample, the forward KL-divergence is zero for that sample even if the Student outputs a very high probability (see Eq. (3), main paper). Adding the reverse ${KL}$ -divergence prevents the distillation loss from going to zero in such cases (Eq. (2), main paper). Indeed, in the class agnostic scenario the optimal strategy is the symmetric KL divergence. This enables learning from both in- and out-of-domain training samples, as demonstrated by the results in Figure 3 of the main paper.

在主论文的公式2中，我们提出使用对称KL散度，即正向(从教师到学生)和反向(从学生到教师)KL散度之和。当目标分布与源分布相似时，非对称的正向损失可能带来优势(见表6(c))。相反，在相反的情形下，反向损失可能更优。如果教师对训练样本的某一类别输出概率为零，即使学生输出很高的概率，正向KL散度对该样本仍为零(见主论文公式(3))。加入反向${KL}$散度可防止蒸馏损失在此类情况下归零(主论文公式(2))。事实上，在类别无关场景中，最优策略是对称KL散度。这使得模型能够从域内和域外训练样本中学习，正如主论文图3的结果所示。

#### B.4.Is a smaller Teacher enough?

#### B.4. 更小的教师模型是否足够？

All the results presented so far involve ViT-H-14 as the teacher. To evaluate if a smaller teacher would be enough we ran additional experiments with ViT-L/14 and ViT-B/16 as Teacher and ResNet-50 as Student (see Table 7). Larger Teachers yield better results, but even more modest ones still maintain excellent performance on domain generalization and cross-dataset transfer. Interestingly, smaller Teachers work better on generalization to unseen classes, which we believe is due to the weaker supervision causing less adaptation and thus maintaining better zero-shot transfer.

迄今为止所有结果均以ViT-H-14作为教师。为评估更小的教师模型是否足够，我们进行了额外实验，使用ViT-L/14和ViT-B/16作为教师，ResNet-50作为学生(见表7)。更大的教师模型效果更佳，但即使较小的教师模型在领域泛化和跨数据集迁移上仍保持出色性能。有趣的是，较小的教师模型在对未见类别的泛化上表现更好，我们认为这是由于较弱的监督导致较少的适应，从而保持了更好的零样本迁移能力。

## C. Additional Results

## C. 额外结果

In the following sections we report on additional experiments validating our proposed approach.

以下章节报告了验证我们所提方法的额外实验。

### C.1. Generalization to Unseen Classes

### C.1. 对未见类别的泛化

In the main paper, due to brevity and to maintain focus on the core aspects of our method, we reported only the performance metrics on unseen classes. Here we provide the performance metrics on base classes as well as the harmonic mean of both base and unseen classes to provide a more comprehensive perspective.

在主论文中，为简洁并聚焦于方法核心，我们仅报告了未见类别的性能指标。这里我们提供基类的性能指标以及基类和未见类的调和平均值，以呈现更全面的视角。

Table 8: Base-to-new generalization. Prompts are learned from the base classes (16-shots) and evaluated on the same classes on the test set (Base), zero-shot on the unseen classes of the test set (New), and in terms of harmonic mean (H) between the base and the new accuracy. Average New performance improvements over the baselines are indicated in green. Here we see how KDPL generalizes better to the new classes, limiting deterioration in performance caused by the unbalanced few-shot training on half the classes of the source domain. Remarkably, we are competitive even on the base classes without requiring training labels.

表8:基类到新类的泛化。提示从基类(16-shot)学习，并在测试集的相同基类(Base)、测试集的未见类(New)上进行零样本评估，以及基类和新类准确率的调和平均(H)。新类性能相较基线的平均提升以绿色标示。结果显示KDPL对新类的泛化更好，限制了因源域一半类别的少样本训练不平衡导致的性能下降。值得注意的是，我们在基类上也具有竞争力，且无需训练标签。

<table><tr><td colspan="2" rowspan="2"/><td colspan="3">Average</td><td colspan="3">ImageNet</td><td colspan="3">OxfordPets</td><td colspan="3">Flowers102</td></tr><tr><td>Base</td><td>New</td><td>H</td><td>Base</td><td>New</td><td>H</td><td>Base</td><td>New</td><td>H</td><td>Base</td><td>New</td><td>H</td></tr><tr><td rowspan="5">RN50</td><td>CLIP (student)</td><td>61.61</td><td>65.88</td><td>63.67</td><td>64.40</td><td>60.10</td><td>58.20</td><td>85.80</td><td>93.70</td><td>83.70</td><td>63.80</td><td>71.30</td><td>61.00</td></tr><tr><td>CoOp</td><td>77.13</td><td>60.82</td><td>68.01</td><td>68.40</td><td>60.00</td><td>60.30</td><td>90.80</td><td>91.63</td><td>85.03</td><td>95.17</td><td>58.30</td><td>67.03</td></tr><tr><td>$\mathrm{{CoOp}} + \mathrm{{KDPL}}$</td><td>73.66</td><td>63.80</td><td>68.38</td><td>68.37</td><td>60.53</td><td>60.63</td><td>93.13</td><td>94.97</td><td>88.63</td><td>93.93</td><td>63.40</td><td>69.77</td></tr><tr><td>CoCoOp</td><td>75.47</td><td>64.39</td><td>69.49</td><td>68.30</td><td>63.07</td><td>61.90</td><td>92.13</td><td>94.93</td><td>87.73</td><td>91.10</td><td>67.47</td><td>68.37</td></tr><tr><td>$\mathrm{{CoCoOp}} + \mathrm{{KDPL}}$</td><td>71.69</td><td>65.90</td><td>68.67</td><td>68.13</td><td>62.87</td><td>61.63</td><td>93.40</td><td>95.33</td><td>89.07</td><td>87.77</td><td>70.63</td><td>70.43</td></tr><tr><td rowspan="9">ViT-B/32</td><td>CLIP (student)</td><td>64.81</td><td>70.05</td><td>67.33</td><td>67.40</td><td>64.00</td><td>62.00</td><td>86.90</td><td>96.30</td><td>85.00</td><td>68.70</td><td>72.30</td><td>64.30</td></tr><tr><td>CoOp</td><td>79.02</td><td>64.52</td><td>71.04</td><td>70.90</td><td>64.53</td><td>63.90</td><td>91.90</td><td>93.37</td><td>84.77</td><td>95.13</td><td>59.77</td><td>67.30</td></tr><tr><td>$\mathrm{{CoOp}} + \mathrm{{KDPL}}$</td><td>75.20</td><td>66.35</td><td>70.50</td><td>70.57</td><td>64.90</td><td>63.83</td><td>93.67</td><td>94.00</td><td>87.57</td><td>93.47</td><td>56.17</td><td>65.23</td></tr><tr><td>VPT</td><td>75.15</td><td>68.02</td><td>71.41</td><td>70.30</td><td>64.60</td><td>63.85</td><td>94.03</td><td>94.83</td><td>85.87</td><td>88.10</td><td>66.03</td><td>67.73</td></tr><tr><td>VPT + KDPL</td><td>72.12</td><td>68.76</td><td>70.40</td><td>70.70</td><td>65.20</td><td>64.30</td><td>93.80</td><td>95.20</td><td>85.53</td><td>82.73</td><td>67.87</td><td>67.30</td></tr><tr><td>MaPLe</td><td>78.26</td><td>69.79</td><td>73.79</td><td>71.40</td><td>66.70</td><td>65.40</td><td>93.07</td><td>96.87</td><td>90.03</td><td>93.37</td><td>69.77</td><td>71.83</td></tr><tr><td>MaPLe + KDPL</td><td>74.74</td><td>71.41</td><td>73.03</td><td>71.60</td><td>66.73</td><td>65.53</td><td>93.90</td><td>96.87</td><td>90.43</td><td>89.73</td><td>68.23</td><td>69.70</td></tr><tr><td>PromptSRC</td><td>81.17</td><td>70.45</td><td>75.43</td><td>72.50</td><td>65.93</td><td>65.63</td><td>93.40</td><td>96.30</td><td>89.30</td><td>96.20</td><td>71.37</td><td>74.90</td></tr><tr><td>PromptSRC + KDPL</td><td>77.11</td><td>71.61</td><td>74.26</td><td>72.70</td><td>66.33</td><td>65.93</td><td>94.37</td><td>96.47</td><td>90.17</td><td>94.93</td><td>68.83</td><td>73.10</td></tr><tr><td>ViT-H/14</td><td>CLIP (teacher)</td><td>86.11</td><td>86.63</td><td>86.37</td><td>86.50</td><td>84.10</td><td>82.80</td><td>94.40</td><td>99.20</td><td>94.80</td><td>96.60</td><td>85.60</td><td>89.40</td></tr></table>

<table><tbody><tr><td colspan="2" rowspan="2"></td><td colspan="3">平均</td><td colspan="3">ImageNet</td><td colspan="3">OxfordPets</td><td colspan="3">Flowers102</td></tr><tr><td>基础</td><td>新</td><td>H</td><td>基础</td><td>新</td><td>H</td><td>基础</td><td>新</td><td>H</td><td>基础</td><td>新</td><td>H</td></tr><tr><td rowspan="5">RN50</td><td>CLIP(学生)</td><td>61.61</td><td>65.88</td><td>63.67</td><td>64.40</td><td>60.10</td><td>58.20</td><td>85.80</td><td>93.70</td><td>83.70</td><td>63.80</td><td>71.30</td><td>61.00</td></tr><tr><td>CoOp</td><td>77.13</td><td>60.82</td><td>68.01</td><td>68.40</td><td>60.00</td><td>60.30</td><td>90.80</td><td>91.63</td><td>85.03</td><td>95.17</td><td>58.30</td><td>67.03</td></tr><tr><td>$\mathrm{{CoOp}} + \mathrm{{KDPL}}$</td><td>73.66</td><td>63.80</td><td>68.38</td><td>68.37</td><td>60.53</td><td>60.63</td><td>93.13</td><td>94.97</td><td>88.63</td><td>93.93</td><td>63.40</td><td>69.77</td></tr><tr><td>CoCoOp</td><td>75.47</td><td>64.39</td><td>69.49</td><td>68.30</td><td>63.07</td><td>61.90</td><td>92.13</td><td>94.93</td><td>87.73</td><td>91.10</td><td>67.47</td><td>68.37</td></tr><tr><td>$\mathrm{{CoCoOp}} + \mathrm{{KDPL}}$</td><td>71.69</td><td>65.90</td><td>68.67</td><td>68.13</td><td>62.87</td><td>61.63</td><td>93.40</td><td>95.33</td><td>89.07</td><td>87.77</td><td>70.63</td><td>70.43</td></tr><tr><td rowspan="9">ViT-B/32</td><td>CLIP(学生)</td><td>64.81</td><td>70.05</td><td>67.33</td><td>67.40</td><td>64.00</td><td>62.00</td><td>86.90</td><td>96.30</td><td>85.00</td><td>68.70</td><td>72.30</td><td>64.30</td></tr><tr><td>CoOp</td><td>79.02</td><td>64.52</td><td>71.04</td><td>70.90</td><td>64.53</td><td>63.90</td><td>91.90</td><td>93.37</td><td>84.77</td><td>95.13</td><td>59.77</td><td>67.30</td></tr><tr><td>$\mathrm{{CoOp}} + \mathrm{{KDPL}}$</td><td>75.20</td><td>66.35</td><td>70.50</td><td>70.57</td><td>64.90</td><td>63.83</td><td>93.67</td><td>94.00</td><td>87.57</td><td>93.47</td><td>56.17</td><td>65.23</td></tr><tr><td>VPT</td><td>75.15</td><td>68.02</td><td>71.41</td><td>70.30</td><td>64.60</td><td>63.85</td><td>94.03</td><td>94.83</td><td>85.87</td><td>88.10</td><td>66.03</td><td>67.73</td></tr><tr><td>VPT + KDPL</td><td>72.12</td><td>68.76</td><td>70.40</td><td>70.70</td><td>65.20</td><td>64.30</td><td>93.80</td><td>95.20</td><td>85.53</td><td>82.73</td><td>67.87</td><td>67.30</td></tr><tr><td>MaPLe</td><td>78.26</td><td>69.79</td><td>73.79</td><td>71.40</td><td>66.70</td><td>65.40</td><td>93.07</td><td>96.87</td><td>90.03</td><td>93.37</td><td>69.77</td><td>71.83</td></tr><tr><td>MaPLe + KDPL</td><td>74.74</td><td>71.41</td><td>73.03</td><td>71.60</td><td>66.73</td><td>65.53</td><td>93.90</td><td>96.87</td><td>90.43</td><td>89.73</td><td>68.23</td><td>69.70</td></tr><tr><td>PromptSRC</td><td>81.17</td><td>70.45</td><td>75.43</td><td>72.50</td><td>65.93</td><td>65.63</td><td>93.40</td><td>96.30</td><td>89.30</td><td>96.20</td><td>71.37</td><td>74.90</td></tr><tr><td>PromptSRC + KDPL</td><td>77.11</td><td>71.61</td><td>74.26</td><td>72.70</td><td>66.33</td><td>65.93</td><td>94.37</td><td>96.47</td><td>90.17</td><td>94.93</td><td>68.83</td><td>73.10</td></tr><tr><td>ViT-H/14</td><td>CLIP(教师)</td><td>86.11</td><td>86.63</td><td>86.37</td><td>86.50</td><td>84.10</td><td>82.80</td><td>94.40</td><td>99.20</td><td>94.80</td><td>96.60</td><td>85.60</td><td>89.40</td></tr></tbody></table>

<table><tr><td colspan="2" rowspan="2"/><td colspan="3">FGVCAircraft</td><td colspan="3">DTD</td><td colspan="3">EuroSAT</td><td colspan="3">StanfordCars</td></tr><tr><td>Base</td><td>New</td><td>H</td><td>Base</td><td>New</td><td>H</td><td>Base</td><td>New</td><td>H</td><td>Base</td><td>New</td><td>H</td></tr><tr><td rowspan="5">RN50</td><td>CLIP (student)</td><td>17.20</td><td>24.80</td><td>15.50</td><td>49.00</td><td>53.90</td><td>40.00</td><td>39.20</td><td>43.70</td><td>24.20</td><td>55.40</td><td>66.60</td><td>55.60</td></tr><tr><td>CoOp</td><td>27.93</td><td>22.17</td><td>18.90</td><td>75.03</td><td>40.93</td><td>47.13</td><td>89.30</td><td>42.13</td><td>46.07</td><td>67.77</td><td>59.87</td><td>58.30</td></tr><tr><td>$\mathrm{{CoOp}} + \mathrm{{KDPL}}$</td><td>24.33</td><td>21.27</td><td>17.03</td><td>66.73</td><td>38.70</td><td>42.70</td><td>71.17</td><td>62.07</td><td>47.23</td><td>67.93</td><td>56.63</td><td>56.70</td></tr><tr><td>CoCoOp</td><td>24.27</td><td>24.87</td><td>18.30</td><td>72.37</td><td>45.40</td><td>45.73</td><td>87.73</td><td>35.10</td><td>42.00</td><td>63.43</td><td>64.73</td><td>58.87</td></tr><tr><td>$\mathrm{{CoCoOp}} + \mathrm{{KDPL}}$</td><td>21.77</td><td>22.67</td><td>16.93</td><td>62.70</td><td>49.07</td><td>44.07</td><td>69.73</td><td>44.27</td><td>37.67</td><td>62.40</td><td>63.67</td><td>57.53</td></tr><tr><td rowspan="10">ViT-B/32 ViT-H/14</td><td>CLIP student</td><td>20.30</td><td>28.30</td><td>18.20</td><td>53.20</td><td>53.90</td><td>42.80</td><td>43.40</td><td>61.50</td><td>38.10</td><td>61.00</td><td>69.80</td><td>60.40</td></tr><tr><td>CoOp</td><td>30.80</td><td>23.03</td><td>20.27</td><td>77.17</td><td>45.57</td><td>49.50</td><td>88.37</td><td>49.13</td><td>51.23</td><td>71.13</td><td>61.73</td><td>61.17</td></tr><tr><td>$\mathrm{{CoOp}} + \mathrm{{KDPL}}$</td><td>26.67</td><td>22.00</td><td>18.23</td><td>67.13</td><td>47.33</td><td>44.10</td><td>71.40</td><td>62.07</td><td>46.90</td><td>69.37</td><td>62.37</td><td>60.47</td></tr><tr><td>VPT</td><td>25.23</td><td>29.70</td><td>20.77</td><td>72.93</td><td>50.17</td><td>46.27</td><td>76.27</td><td>50.03</td><td>43.87</td><td>64.07</td><td>69.90</td><td>61.27</td></tr><tr><td>VPT + KDPL</td><td>24.10</td><td>30.40</td><td>20.03</td><td>63.40</td><td>47.53</td><td>42.07</td><td>65.43</td><td>54.97</td><td>42.40</td><td>63.77</td><td>69.80</td><td>61.23</td></tr><tr><td>MaPLe</td><td>23.57</td><td>20.43</td><td>16.50</td><td>77.27</td><td>53.50</td><td>53.90</td><td>91.17</td><td>66.70</td><td>63.93</td><td>67.50</td><td>68.03</td><td>62.50</td></tr><tr><td>MaPLe + KDPL</td><td>25.43</td><td>27.37</td><td>19.93</td><td>66.27</td><td>50.33</td><td>46.53</td><td>74.03</td><td>75.70</td><td>62.30</td><td>66.97</td><td>68.40</td><td>62.40</td></tr><tr><td>PromptSRC</td><td>33.77</td><td>23.67</td><td>22.50</td><td>80.57</td><td>54.43</td><td>54.67</td><td>93.77</td><td>61.97</td><td>61.30</td><td>72.90</td><td>70.00</td><td>66.37</td></tr><tr><td>PromptSRC + KDPL</td><td>30.37</td><td>28.43</td><td>23.20</td><td>71.93</td><td>50.87</td><td>47.97</td><td>73.93</td><td>74.17</td><td>58.53</td><td>72.53</td><td>68.50</td><td>65.43</td></tr><tr><td>CLIP (teacher)</td><td>71.40</td><td>64.30</td><td>63.20</td><td>78.20</td><td>75.00</td><td>66.80</td><td>70.70</td><td>82.60</td><td>63.30</td><td>94.60</td><td>98.20</td><td>95.60</td></tr></table>

<table><tbody><tr><td colspan="2" rowspan="2"></td><td colspan="3">FGVC飞机</td><td colspan="3">DTD纹理数据集</td><td colspan="3">EuroSAT卫星图像数据集</td><td colspan="3">斯坦福汽车数据集</td></tr><tr><td>基础</td><td>新</td><td>H</td><td>基础</td><td>新</td><td>H</td><td>基础</td><td>新</td><td>H</td><td>基础</td><td>新</td><td>H</td></tr><tr><td rowspan="5">RN50</td><td>CLIP(学生)</td><td>17.20</td><td>24.80</td><td>15.50</td><td>49.00</td><td>53.90</td><td>40.00</td><td>39.20</td><td>43.70</td><td>24.20</td><td>55.40</td><td>66.60</td><td>55.60</td></tr><tr><td>CoOp</td><td>27.93</td><td>22.17</td><td>18.90</td><td>75.03</td><td>40.93</td><td>47.13</td><td>89.30</td><td>42.13</td><td>46.07</td><td>67.77</td><td>59.87</td><td>58.30</td></tr><tr><td>$\mathrm{{CoOp}} + \mathrm{{KDPL}}$</td><td>24.33</td><td>21.27</td><td>17.03</td><td>66.73</td><td>38.70</td><td>42.70</td><td>71.17</td><td>62.07</td><td>47.23</td><td>67.93</td><td>56.63</td><td>56.70</td></tr><tr><td>CoCoOp</td><td>24.27</td><td>24.87</td><td>18.30</td><td>72.37</td><td>45.40</td><td>45.73</td><td>87.73</td><td>35.10</td><td>42.00</td><td>63.43</td><td>64.73</td><td>58.87</td></tr><tr><td>$\mathrm{{CoCoOp}} + \mathrm{{KDPL}}$</td><td>21.77</td><td>22.67</td><td>16.93</td><td>62.70</td><td>49.07</td><td>44.07</td><td>69.73</td><td>44.27</td><td>37.67</td><td>62.40</td><td>63.67</td><td>57.53</td></tr><tr><td rowspan="10">ViT-B/32 ViT-H/14</td><td>CLIP学生</td><td>20.30</td><td>28.30</td><td>18.20</td><td>53.20</td><td>53.90</td><td>42.80</td><td>43.40</td><td>61.50</td><td>38.10</td><td>61.00</td><td>69.80</td><td>60.40</td></tr><tr><td>CoOp</td><td>30.80</td><td>23.03</td><td>20.27</td><td>77.17</td><td>45.57</td><td>49.50</td><td>88.37</td><td>49.13</td><td>51.23</td><td>71.13</td><td>61.73</td><td>61.17</td></tr><tr><td>$\mathrm{{CoOp}} + \mathrm{{KDPL}}$</td><td>26.67</td><td>22.00</td><td>18.23</td><td>67.13</td><td>47.33</td><td>44.10</td><td>71.40</td><td>62.07</td><td>46.90</td><td>69.37</td><td>62.37</td><td>60.47</td></tr><tr><td>VPT</td><td>25.23</td><td>29.70</td><td>20.77</td><td>72.93</td><td>50.17</td><td>46.27</td><td>76.27</td><td>50.03</td><td>43.87</td><td>64.07</td><td>69.90</td><td>61.27</td></tr><tr><td>VPT + KDPL</td><td>24.10</td><td>30.40</td><td>20.03</td><td>63.40</td><td>47.53</td><td>42.07</td><td>65.43</td><td>54.97</td><td>42.40</td><td>63.77</td><td>69.80</td><td>61.23</td></tr><tr><td>MaPLe</td><td>23.57</td><td>20.43</td><td>16.50</td><td>77.27</td><td>53.50</td><td>53.90</td><td>91.17</td><td>66.70</td><td>63.93</td><td>67.50</td><td>68.03</td><td>62.50</td></tr><tr><td>MaPLe + KDPL</td><td>25.43</td><td>27.37</td><td>19.93</td><td>66.27</td><td>50.33</td><td>46.53</td><td>74.03</td><td>75.70</td><td>62.30</td><td>66.97</td><td>68.40</td><td>62.40</td></tr><tr><td>PromptSRC</td><td>33.77</td><td>23.67</td><td>22.50</td><td>80.57</td><td>54.43</td><td>54.67</td><td>93.77</td><td>61.97</td><td>61.30</td><td>72.90</td><td>70.00</td><td>66.37</td></tr><tr><td>PromptSRC + KDPL</td><td>30.37</td><td>28.43</td><td>23.20</td><td>71.93</td><td>50.87</td><td>47.97</td><td>73.93</td><td>74.17</td><td>58.53</td><td>72.53</td><td>68.50</td><td>65.43</td></tr><tr><td>CLIP(教师)</td><td>71.40</td><td>64.30</td><td>63.20</td><td>78.20</td><td>75.00</td><td>66.80</td><td>70.70</td><td>82.60</td><td>63.30</td><td>94.60</td><td>98.20</td><td>95.60</td></tr></tbody></table>

<table><tr><td colspan="2" rowspan="2"/><td colspan="3">Food101</td><td colspan="3">SUN397</td><td colspan="3">Caltech101</td><td colspan="3">UCF101</td></tr><tr><td>Base</td><td>New</td><td>H</td><td>Base</td><td>New</td><td>H</td><td>Base</td><td>New</td><td>H</td><td>Base</td><td>New</td><td>H</td></tr><tr><td rowspan="5">RN50</td><td>CLIP (student)</td><td>81.60</td><td>82.20</td><td>75.20</td><td>66.50</td><td>70.10</td><td>58.50</td><td>91.10</td><td>90.50</td><td>86.00</td><td>63.70</td><td>67.80</td><td>58.30</td></tr><tr><td>CoOp</td><td>82.63</td><td>82.03</td><td>75.37</td><td>76.37</td><td>66.77</td><td>61.50</td><td>95.50</td><td>87.53</td><td>88.53</td><td>79.50</td><td>57.63</td><td>61.53</td></tr><tr><td>$\mathrm{{CoOp}} + \mathrm{{KDPL}}$</td><td>83.73</td><td>83.07</td><td>76.77</td><td>73.43</td><td>69.83</td><td>61.93</td><td>95.10</td><td>88.75</td><td>88.90</td><td>72.43</td><td>62.63</td><td>59.97</td></tr><tr><td>CoCoOp</td><td>84.43</td><td>84.50</td><td>78.00</td><td>74.53</td><td>72.87</td><td>63.93</td><td>94.97</td><td>90.73</td><td>89.33</td><td>76.90</td><td>64.67</td><td>63.77</td></tr><tr><td>$\mathrm{{CoCoOp}} + \mathrm{{KDPL}}$</td><td>84.63</td><td>85.90</td><td>79.00</td><td>71.83</td><td>73.23</td><td>62.80</td><td>94.87</td><td>91.00</td><td>89.37</td><td>71.33</td><td>66.23</td><td>61.70</td></tr><tr><td rowspan="9">ViT-B/32</td><td>CLIP student</td><td>84.50</td><td>85.70</td><td>79.10</td><td>69.80</td><td>73.10</td><td>62.00</td><td>93.70</td><td>94.00</td><td>91.10</td><td>64.00</td><td>71.60</td><td>60.70</td></tr><tr><td>CoOp</td><td>85.17</td><td>85.50</td><td>79.27</td><td>79.17</td><td>69.37</td><td>64.93</td><td>97.40</td><td>92.13</td><td>92.37</td><td>82.13</td><td>65.60</td><td>66.93</td></tr><tr><td>$\mathrm{{CoOp}} + \mathrm{{KDPL}}$</td><td>86.40</td><td>87.23</td><td>81.10</td><td>75.87</td><td>74.17</td><td>65.70</td><td>96.47</td><td>93.43</td><td>92.57</td><td>76.17</td><td>66.20</td><td>64.20</td></tr><tr><td>VPT</td><td>85.47</td><td>85.83</td><td>79.60</td><td>75.70</td><td>75.13</td><td>65.47</td><td>97.10</td><td>92.57</td><td>92.80</td><td>77.43</td><td>69.47</td><td>65.10</td></tr><tr><td>VPT + KDPL</td><td>85.63</td><td>86.33</td><td>79.97</td><td>74.07</td><td>75.17</td><td>65.07</td><td>96.33</td><td>92.80</td><td>92.53</td><td>73.33</td><td>71.07</td><td>63.70</td></tr><tr><td>MaPLe</td><td>86.40</td><td>87.47</td><td>81.27</td><td>78.90</td><td>76.57</td><td>68.60</td><td>97.03</td><td>92.27</td><td>93.00</td><td>81.23</td><td>69.40</td><td>68.17</td></tr><tr><td>MaPLe + KDPL</td><td>86.50</td><td>87.83</td><td>81.73</td><td>75.57</td><td>76.83</td><td>67.07</td><td>97.00</td><td>93.67</td><td>93.33</td><td>75.10</td><td>73.53</td><td>67.07</td></tr><tr><td>PromptSRC</td><td>86.33</td><td>87.13</td><td>80.93</td><td>80.80</td><td>76.77</td><td>69.90</td><td>97.53</td><td>94.70</td><td>94.30</td><td>85.07</td><td>72.63</td><td>72.67</td></tr><tr><td>PromptSRC + KDPL</td><td>86.53</td><td>87.63</td><td>81.27</td><td>76.53</td><td>77.33</td><td>68.00</td><td>96.90</td><td>94.47</td><td>93.93</td><td>77.50</td><td>74.73</td><td>68.53</td></tr><tr><td>ViT-H/14</td><td>CLIP (teacher)</td><td>95.50</td><td>96.30</td><td>93.60</td><td>82.00</td><td>85.10</td><td>76.40</td><td>99.20</td><td>97.30</td><td>97.90</td><td>78.10</td><td>85.20</td><td>76.40</td></tr></table>

<table><tbody><tr><td colspan="2" rowspan="2"></td><td colspan="3">Food101(食品101)</td><td colspan="3">SUN397(SUN397场景数据集)</td><td colspan="3">Caltech101(加州理工101)</td><td colspan="3">UCF101(UCF101动作识别数据集)</td></tr><tr><td>基础</td><td>新</td><td>H</td><td>基础</td><td>新</td><td>H</td><td>基础</td><td>新</td><td>H</td><td>基础</td><td>新</td><td>H</td></tr><tr><td rowspan="5">RN50(ResNet50)</td><td>CLIP(学生版)</td><td>81.60</td><td>82.20</td><td>75.20</td><td>66.50</td><td>70.10</td><td>58.50</td><td>91.10</td><td>90.50</td><td>86.00</td><td>63.70</td><td>67.80</td><td>58.30</td></tr><tr><td>CoOp</td><td>82.63</td><td>82.03</td><td>75.37</td><td>76.37</td><td>66.77</td><td>61.50</td><td>95.50</td><td>87.53</td><td>88.53</td><td>79.50</td><td>57.63</td><td>61.53</td></tr><tr><td>$\mathrm{{CoOp}} + \mathrm{{KDPL}}$</td><td>83.73</td><td>83.07</td><td>76.77</td><td>73.43</td><td>69.83</td><td>61.93</td><td>95.10</td><td>88.75</td><td>88.90</td><td>72.43</td><td>62.63</td><td>59.97</td></tr><tr><td>CoCoOp</td><td>84.43</td><td>84.50</td><td>78.00</td><td>74.53</td><td>72.87</td><td>63.93</td><td>94.97</td><td>90.73</td><td>89.33</td><td>76.90</td><td>64.67</td><td>63.77</td></tr><tr><td>$\mathrm{{CoCoOp}} + \mathrm{{KDPL}}$</td><td>84.63</td><td>85.90</td><td>79.00</td><td>71.83</td><td>73.23</td><td>62.80</td><td>94.87</td><td>91.00</td><td>89.37</td><td>71.33</td><td>66.23</td><td>61.70</td></tr><tr><td rowspan="9">ViT-B/32(视觉Transformer-B/32)</td><td>CLIP学生版</td><td>84.50</td><td>85.70</td><td>79.10</td><td>69.80</td><td>73.10</td><td>62.00</td><td>93.70</td><td>94.00</td><td>91.10</td><td>64.00</td><td>71.60</td><td>60.70</td></tr><tr><td>CoOp</td><td>85.17</td><td>85.50</td><td>79.27</td><td>79.17</td><td>69.37</td><td>64.93</td><td>97.40</td><td>92.13</td><td>92.37</td><td>82.13</td><td>65.60</td><td>66.93</td></tr><tr><td>$\mathrm{{CoOp}} + \mathrm{{KDPL}}$</td><td>86.40</td><td>87.23</td><td>81.10</td><td>75.87</td><td>74.17</td><td>65.70</td><td>96.47</td><td>93.43</td><td>92.57</td><td>76.17</td><td>66.20</td><td>64.20</td></tr><tr><td>VPT</td><td>85.47</td><td>85.83</td><td>79.60</td><td>75.70</td><td>75.13</td><td>65.47</td><td>97.10</td><td>92.57</td><td>92.80</td><td>77.43</td><td>69.47</td><td>65.10</td></tr><tr><td>VPT + KDPL</td><td>85.63</td><td>86.33</td><td>79.97</td><td>74.07</td><td>75.17</td><td>65.07</td><td>96.33</td><td>92.80</td><td>92.53</td><td>73.33</td><td>71.07</td><td>63.70</td></tr><tr><td>MaPLe</td><td>86.40</td><td>87.47</td><td>81.27</td><td>78.90</td><td>76.57</td><td>68.60</td><td>97.03</td><td>92.27</td><td>93.00</td><td>81.23</td><td>69.40</td><td>68.17</td></tr><tr><td>MaPLe + KDPL</td><td>86.50</td><td>87.83</td><td>81.73</td><td>75.57</td><td>76.83</td><td>67.07</td><td>97.00</td><td>93.67</td><td>93.33</td><td>75.10</td><td>73.53</td><td>67.07</td></tr><tr><td>PromptSRC</td><td>86.33</td><td>87.13</td><td>80.93</td><td>80.80</td><td>76.77</td><td>69.90</td><td>97.53</td><td>94.70</td><td>94.30</td><td>85.07</td><td>72.63</td><td>72.67</td></tr><tr><td>PromptSRC + KDPL</td><td>86.53</td><td>87.63</td><td>81.27</td><td>76.53</td><td>77.33</td><td>68.00</td><td>96.90</td><td>94.47</td><td>93.93</td><td>77.50</td><td>74.73</td><td>68.53</td></tr><tr><td>ViT-H/14(视觉Transformer-H/14)</td><td>CLIP(教师版)</td><td>95.50</td><td>96.30</td><td>93.60</td><td>82.00</td><td>85.10</td><td>76.40</td><td>99.20</td><td>97.30</td><td>97.90</td><td>78.10</td><td>85.20</td><td>76.40</td></tr></tbody></table>

Table 9: Class Agnostic adaptation. Comparison between baselines and the proposed unsupervised class agnostic CA-KDPL variants (highlighted in cyan). The prompt is learned in an unsupervised and class-agnostic setting on ImageNet and evaluated on the generalization and on the cross-dataset benchmark datasets. Average performance improvements are indicated in green, and deterioration in red. Notably, our proposed unsupervised and class-agnostic approach is competitive against the reference supervised and class-aware baselines. Overall, on the cross-dataset benchmark we achieve better generalization, demonstrating that using CA-KDPL is a valid option in such settings.

<table 9:类别无关适应。基线方法与所提无监督类别无关CA-KDPL变体(以青色突出显示)之间的比较。该提示在ImageNet上以无监督且类别无关的方式学习，并在泛化能力及跨数据集基准数据集上进行评估。平均性能提升以绿色表示，性能下降以红色表示。值得注意的是，我们提出的无监督且类别无关的方法在性能上可与参考的有监督且类别相关的基线方法相媲美。总体而言，在跨数据集基准测试中，我们实现了更好的泛化能力，证明在此类场景中使用CA-KDPL是一种有效的选择。

<table><tr><td colspan="2" rowspan="2">Backbone Method</td><td>Source</td><td colspan="5">Cross-Domain Target</td><td colspan="11">Cross-Dataset Target</td></tr><tr><td>ImageNet</td><td>ImageNet-V2</td><td>ImageNet- $S$</td><td>ImageNet-A</td><td>ImageNet-R</td><td>Average</td><td>OxfordPets</td><td>Flowers102</td><td>FGVCAircraft</td><td>${DTD}$</td><td>${E}_{uroSAT}$</td><td>StanfordCars</td><td>Food101</td><td>SUN397</td><td>Caltech101</td><td>UCF101</td><td>Average</td></tr><tr><td rowspan="5">RN50</td><td>CLIP (student)</td><td>58.20</td><td>51.50</td><td>33.30</td><td>21.70</td><td>56.00</td><td>40.63</td><td>83.70</td><td>61.00</td><td>15.60</td><td>40.00</td><td>24.20</td><td>55.60</td><td>75.20</td><td>58.50</td><td>86.00</td><td>58.30</td><td>55.81</td></tr><tr><td>CoOp</td><td>62.40</td><td>55.17</td><td>33.70</td><td>23.13</td><td>56.20</td><td>42.05</td><td>84.60</td><td>61.63</td><td>13.77</td><td>36.83</td><td>22.33</td><td>54.20</td><td>75.03</td><td>59.00</td><td>87.67</td><td>57.73</td><td>55.28</td></tr><tr><td>CoOp + CA-KDPL</td><td>61.83</td><td>54.27</td><td>35.20</td><td>23.50</td><td>59.10</td><td>43.02</td><td>86.37</td><td>63.47</td><td>14.80</td><td>40.23</td><td>30.33</td><td>55.40</td><td>77.17</td><td>61.60</td><td>88.50</td><td>59.03</td><td>57.69</td></tr><tr><td>CoCoOp</td><td>63.07</td><td>55.53</td><td>34.77</td><td>23.73</td><td>59.47</td><td>43.38</td><td>86.93</td><td>63.47</td><td>16.27</td><td>40.53</td><td>27.20</td><td>55.47</td><td>77.73</td><td>61.40</td><td>88.07</td><td>60.43</td><td>57.75</td></tr><tr><td>CoCoOp + CA-KDPL</td><td>61.43</td><td>54.53</td><td>35.33</td><td>23.77</td><td>59.10</td><td>43.18</td><td>87.47</td><td>67.30</td><td>15.30</td><td>39.50</td><td>28.57</td><td>54.80</td><td>77.53</td><td>61.63</td><td>88.03</td><td>60.13</td><td>58.03</td></tr><tr><td rowspan="9">ViT-B/32</td><td>CLIP (student)</td><td>62.00</td><td>54.70</td><td>40.80</td><td>29.60</td><td>66.00</td><td>47.78</td><td>85.00</td><td>64.30</td><td>18.20</td><td>42.80</td><td>38.10</td><td>60.40</td><td>79.10</td><td>62.00</td><td>91.10</td><td>60.70</td><td>60.17</td></tr><tr><td>CoOp</td><td>66.33</td><td>58.30</td><td>41.40</td><td>31.47</td><td>65.87</td><td>49.26</td><td>87.13</td><td>62.20</td><td>12.13</td><td>40.57</td><td>36.97</td><td>57.83</td><td>80.13</td><td>62.83</td><td>91.13</td><td>61.80</td><td>59.27</td></tr><tr><td>CoOp + CA-KDPL</td><td>64.73</td><td>56.93</td><td>42.27</td><td>31.47</td><td>67.83</td><td>49.63</td><td>86.57</td><td>62.73</td><td>15.00</td><td>42.23</td><td>43.93</td><td>58.57</td><td>79.47</td><td>65.03</td><td>92.30</td><td>61.53</td><td>60.74</td></tr><tr><td>VPT</td><td>64.97</td><td>56.73</td><td>41.27</td><td>27.00</td><td>66.50</td><td>47.88</td><td>87.43</td><td>64.77</td><td>19.53</td><td>44.20</td><td>28.47</td><td>57.60</td><td>78.27</td><td>63.73</td><td>91.40</td><td>62.50</td><td>59.79</td></tr><tr><td>VPT + CA-KDPL</td><td>63.73</td><td>55.83</td><td>41.10</td><td>27.33</td><td>67.30</td><td>47.89</td><td>87.20</td><td>63.17</td><td>18.43</td><td>44.00</td><td>33.53</td><td>55.47</td><td>77.70</td><td>63.63</td><td>91.93</td><td>62.93</td><td>59.80</td></tr><tr><td>MaPLe</td><td>66.80</td><td>58.53</td><td>42.23</td><td>30.13</td><td>66.40</td><td>49.32</td><td>88.37</td><td>66.43</td><td>18.47</td><td>42.03</td><td>37.77</td><td>60.00</td><td>80.10</td><td>64.43</td><td>91.33</td><td>62.50</td><td>61.14</td></tr><tr><td>MaPLe + CA-KDPL</td><td>65.23</td><td>57.43</td><td>42.07</td><td>30.00</td><td>67.63</td><td>49.28</td><td>88.30</td><td>64.97</td><td>16.07</td><td>44.03</td><td>41.53</td><td>57.90</td><td>79.80</td><td>64.97</td><td>92.77</td><td>61.93</td><td>61.23</td></tr><tr><td>PromptSRC</td><td>66.33</td><td>58.70</td><td>42.97</td><td>32.07</td><td>68.93</td><td>50.67</td><td>88.13</td><td>65.33</td><td>17.17</td><td>43.90</td><td>40.50</td><td>60.17</td><td>81.23</td><td>65.40</td><td>92.37</td><td>63.63</td><td>61.78</td></tr><tr><td>PromptSRC + CA-KDPL</td><td>65.00</td><td>57.50</td><td>42.90</td><td>32.30</td><td>68.77</td><td>50.37</td><td>87.53</td><td>65.47</td><td>17.87</td><td>42.17</td><td>44.53</td><td>60.07</td><td>80.50</td><td>65.67</td><td>93.10</td><td>62.37</td><td>61.93</td></tr><tr><td colspan="2">ViT-H/14J/14 CLIP (teacher)</td><td>82.80</td><td>76.60</td><td>71.10</td><td>71.10</td><td>91.30</td><td>77.53</td><td>94.80</td><td>89.40</td><td>63.20</td><td>66.80</td><td>63.30</td><td>95.60</td><td>93.60</td><td>76.40</td><td>97.90</td><td>76.40</td><td>81.74</td></tr></table>

<table><tbody><tr><td colspan="2" rowspan="2">主干方法</td><td>源域</td><td colspan="5">跨域目标</td><td colspan="11">跨数据集目标</td></tr><tr><td>ImageNet</td><td>ImageNet-V2</td><td>ImageNet- $S$</td><td>ImageNet-A</td><td>ImageNet-R</td><td>平均值</td><td>牛津宠物数据集</td><td>Flowers102</td><td>FGVCAircraft</td><td>${DTD}$</td><td>${E}_{uroSAT}$</td><td>斯坦福汽车数据集</td><td>Food101</td><td>SUN397</td><td>Caltech101</td><td>UCF101</td><td>平均值</td></tr><tr><td rowspan="5">RN50</td><td>CLIP(学生模型)</td><td>58.20</td><td>51.50</td><td>33.30</td><td>21.70</td><td>56.00</td><td>40.63</td><td>83.70</td><td>61.00</td><td>15.60</td><td>40.00</td><td>24.20</td><td>55.60</td><td>75.20</td><td>58.50</td><td>86.00</td><td>58.30</td><td>55.81</td></tr><tr><td>CoOp</td><td>62.40</td><td>55.17</td><td>33.70</td><td>23.13</td><td>56.20</td><td>42.05</td><td>84.60</td><td>61.63</td><td>13.77</td><td>36.83</td><td>22.33</td><td>54.20</td><td>75.03</td><td>59.00</td><td>87.67</td><td>57.73</td><td>55.28</td></tr><tr><td>CoOp + CA-KDPL</td><td>61.83</td><td>54.27</td><td>35.20</td><td>23.50</td><td>59.10</td><td>43.02</td><td>86.37</td><td>63.47</td><td>14.80</td><td>40.23</td><td>30.33</td><td>55.40</td><td>77.17</td><td>61.60</td><td>88.50</td><td>59.03</td><td>57.69</td></tr><tr><td>CoCoOp</td><td>63.07</td><td>55.53</td><td>34.77</td><td>23.73</td><td>59.47</td><td>43.38</td><td>86.93</td><td>63.47</td><td>16.27</td><td>40.53</td><td>27.20</td><td>55.47</td><td>77.73</td><td>61.40</td><td>88.07</td><td>60.43</td><td>57.75</td></tr><tr><td>CoCoOp + CA-KDPL</td><td>61.43</td><td>54.53</td><td>35.33</td><td>23.77</td><td>59.10</td><td>43.18</td><td>87.47</td><td>67.30</td><td>15.30</td><td>39.50</td><td>28.57</td><td>54.80</td><td>77.53</td><td>61.63</td><td>88.03</td><td>60.13</td><td>58.03</td></tr><tr><td rowspan="9">ViT-B/32</td><td>CLIP(学生模型)</td><td>62.00</td><td>54.70</td><td>40.80</td><td>29.60</td><td>66.00</td><td>47.78</td><td>85.00</td><td>64.30</td><td>18.20</td><td>42.80</td><td>38.10</td><td>60.40</td><td>79.10</td><td>62.00</td><td>91.10</td><td>60.70</td><td>60.17</td></tr><tr><td>CoOp</td><td>66.33</td><td>58.30</td><td>41.40</td><td>31.47</td><td>65.87</td><td>49.26</td><td>87.13</td><td>62.20</td><td>12.13</td><td>40.57</td><td>36.97</td><td>57.83</td><td>80.13</td><td>62.83</td><td>91.13</td><td>61.80</td><td>59.27</td></tr><tr><td>CoOp + CA-KDPL</td><td>64.73</td><td>56.93</td><td>42.27</td><td>31.47</td><td>67.83</td><td>49.63</td><td>86.57</td><td>62.73</td><td>15.00</td><td>42.23</td><td>43.93</td><td>58.57</td><td>79.47</td><td>65.03</td><td>92.30</td><td>61.53</td><td>60.74</td></tr><tr><td>VPT</td><td>64.97</td><td>56.73</td><td>41.27</td><td>27.00</td><td>66.50</td><td>47.88</td><td>87.43</td><td>64.77</td><td>19.53</td><td>44.20</td><td>28.47</td><td>57.60</td><td>78.27</td><td>63.73</td><td>91.40</td><td>62.50</td><td>59.79</td></tr><tr><td>VPT + CA-KDPL</td><td>63.73</td><td>55.83</td><td>41.10</td><td>27.33</td><td>67.30</td><td>47.89</td><td>87.20</td><td>63.17</td><td>18.43</td><td>44.00</td><td>33.53</td><td>55.47</td><td>77.70</td><td>63.63</td><td>91.93</td><td>62.93</td><td>59.80</td></tr><tr><td>MaPLe</td><td>66.80</td><td>58.53</td><td>42.23</td><td>30.13</td><td>66.40</td><td>49.32</td><td>88.37</td><td>66.43</td><td>18.47</td><td>42.03</td><td>37.77</td><td>60.00</td><td>80.10</td><td>64.43</td><td>91.33</td><td>62.50</td><td>61.14</td></tr><tr><td>MaPLe + CA-KDPL</td><td>65.23</td><td>57.43</td><td>42.07</td><td>30.00</td><td>67.63</td><td>49.28</td><td>88.30</td><td>64.97</td><td>16.07</td><td>44.03</td><td>41.53</td><td>57.90</td><td>79.80</td><td>64.97</td><td>92.77</td><td>61.93</td><td>61.23</td></tr><tr><td>PromptSRC</td><td>66.33</td><td>58.70</td><td>42.97</td><td>32.07</td><td>68.93</td><td>50.67</td><td>88.13</td><td>65.33</td><td>17.17</td><td>43.90</td><td>40.50</td><td>60.17</td><td>81.23</td><td>65.40</td><td>92.37</td><td>63.63</td><td>61.78</td></tr><tr><td>PromptSRC + CA-KDPL</td><td>65.00</td><td>57.50</td><td>42.90</td><td>32.30</td><td>68.77</td><td>50.37</td><td>87.53</td><td>65.47</td><td>17.87</td><td>42.17</td><td>44.53</td><td>60.07</td><td>80.50</td><td>65.67</td><td>93.10</td><td>62.37</td><td>61.93</td></tr><tr><td colspan="2">ViT-H/14J/14 CLIP(教师模型)</td><td>82.80</td><td>76.60</td><td>71.10</td><td>71.10</td><td>91.30</td><td>77.53</td><td>94.80</td><td>89.40</td><td>63.20</td><td>66.80</td><td>63.30</td><td>95.60</td><td>93.60</td><td>76.40</td><td>97.90</td><td>76.40</td><td>81.74</td></tr></tbody></table>

In Table 8, we observe that the baseline methods without KDPL outperform our approach in few-shot transfer learning on base classes. Thanks to the supervision label signal, the baselines can exploit the ground-truth source training classes. Without using KDPL, however, all the baseline methods suffer from forgetting the unseen classes. In particular, we see that training on base-shots causes a decrease in performance on the unseen classes. Certain methods in particular suffer from this phenomenon, typical of an Incremental Learning setting (e.g. in Figure 4 we see that the average performance of MaPLe on unseen classes is consistently below the average zero-shot unseen performance). Applying our method instead exhibits a more favorable trend in zero-shot transfer learning on unseen classes, alleviating the forgetting of unseen classes. Our method is preferable in scenarios where labeled data for base classes are not available, and improvement in base class performance is desired without compromising zero-shot transfer performance on unseen classes.

在表8中，我们观察到在基类的小样本迁移学习中，没有使用KDPL的基线方法表现优于我们的方法。得益于监督标签信号，基线方法能够利用真实的源训练类别。然而，不使用KDPL时，所有基线方法都存在遗忘未见类别的问题。特别地，我们发现基于基类样本训练会导致未见类别性能下降。某些方法尤其受到这一现象的影响，这在增量学习(Incremental Learning)设置中较为典型(例如，在图4中我们看到MaPLe在未见类别上的平均性能始终低于零样本未见类别的平均性能)。而采用我们的方法则在未见类别的零样本迁移学习中表现出更有利的趋势，缓解了未见类别的遗忘问题。我们的方案适用于基类标注数据不可用且希望提升基类性能而不损害未见类别零样本迁移性能的场景。

### C.2. Class Agnostic Scenario

### C.2. 类别无关场景

In the main paper we did not include all results for the class agnostic setting due to space limitations, but only reported the average domain generalization performance and the average cross-dataset performance. Here, in Table 9 we provide all class agnostic results comparing our proposed method (CA-KDPL) against the baselines. As mentioned in the main paper, even without knowing either the labels or the training class names, our proposed unsupervised method is competitive, and sometimes even outperforms the baselines.

由于篇幅限制，主文中未包含类别无关设置的全部结果，仅报告了平均领域泛化性能和平均跨数据集性能。这里，在表9中，我们提供了所有类别无关的结果，比较了我们提出的方法(CA-KDPL)与基线方法。如主文所述，即使在不知道标签或训练类别名称的情况下，我们提出的无监督方法仍具竞争力，有时甚至优于基线。

![bo_d1c3l9bef24c73d2ojn0_25_389_465_1029_1034_0.jpg](images/bo_d1c3l9bef24c73d2ojn0_25_389_465_1029_1034_0.jpg)

Fig. 4: Generalization to Unseen Classes. The base-to-unseen generalization results of MaPLe+KDPL versus MaPLe are reported. Prompts are learned from the base classes and evaluated on the same base classes and on the unseen classes of the test set. Instead of reporting only the 16-shot performance, we include results for 1-, 2-, 4-, 8-, and 16-shots. Here we see that increasing the number of shots increases the performance of the base class but harms the performance on unseen classes. However, with our approach we can alleviate this problem, reaching an average 16-shots performance on unseen classes greater than the zero-shot reference, while the average MaPLe performance remains below the average zero-shot reference for all shots.

图4:对未见类别的泛化。报告了MaPLe+KDPL与MaPLe的基类到未见类的泛化结果。提示词从基类学习，并在相同基类及测试集的未见类上评估。我们不仅报告16样本的性能，还包括1、2、4、8和16样本的结果。结果显示，增加样本数提升了基类性能，但损害了未见类性能。然而，采用我们的方法可以缓解这一问题，使未见类的16样本平均性能超过零样本参考，而MaPLe的平均性能在所有样本数下均低于零样本参考的平均水平。

