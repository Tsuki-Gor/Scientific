# Episodic Training for Domain Generalization

# 用于领域泛化的情景式训练

Da Li ${}^{1,2}$ , Jianshu Zhang ${}^{3}$ , Yongxin Yang ${}^{2}$

李达 ${}^{1,2}$ ，张健树 ${}^{3}$ ，杨永新 ${}^{2}$

Cong ${\operatorname{Liu}}^{4}$ , Yi-Zhe ${\operatorname{Song}}^{2}$ and Timothy M. Hospedales ${}^{1,2,5}$

丛 ${\operatorname{Liu}}^{4}$ ，易哲 ${\operatorname{Song}}^{2}$ 和蒂莫西·M·霍斯佩代尔斯 ${}^{1,2,5}$

${}^{1}$ Samsung AI Center, Cambridge ${}^{2}$ SketchX, CVSSP, University of Surrey ${}^{3}$ University of Science and Technology of China ${}^{4}$ iFlytek Research ${}^{5}$ University of Edinburgl

${}^{1}$ 三星人工智能中心，剑桥 ${}^{2}$ 英国萨里大学计算机视觉、语音与信号处理中心(CVSSP)SketchX实验室 ${}^{3}$ 中国科学技术大学 ${}^{4}$ 科大讯飞研究院 ${}^{5}$ 爱丁堡大学

\{d.li, yongxin.yang, y.song\}@surrey.ac.uk, xysszjs@mail.ustc.edu.cn

\{d.li, yongxin.yang, y.song\}@surrey.ac.uk, xysszjs@mail.ustc.edu.cn

congliu2@iflytek.com, t.hospedales@ed.ac.uk

congliu2@iflytek.com, t.hospedales@ed.ac.uk

## Abstract

## 摘要

Domain generalization (DG) is the challenging and topical problem of learning models that generalize to novel testing domains with different statistics than a set of known training domains. The simple approach of aggregating data from all source domains and training a single deep neural network end-to-end on all the data provides a surprisingly strong baseline that surpasses many prior published methods. In this paper we build on this strong baseline by designing an episodic training procedure that trains a single deep network in a way that exposes it to the domain shift that characterises a novel domain at runtime. Specifically, we decompose a deep network into feature extractor and classifier components, and then train each component by simulating it interacting with a partner who is badly tuned for the current domain. This makes both components more robust, ultimately leading to our networks producing state-of-the-art performance on three DG benchmarks. Furthermore, we consider the pervasive workflow of using an ImageNet trained CNN as a fixed feature extractor for downstream recognition tasks. Using the Visual Decathlon benchmark, we demonstrate that our episodic-DG training improves the performance of such a general purpose feature extractor by explicitly training a feature for robustness to novel problems. This shows that DG training can benefit standard practice in computer vision.

领域泛化(Domain generalization，DG)是一个具有挑战性的热点问题，即学习能够泛化到与一组已知训练领域统计特征不同的新测试领域的模型。将所有源领域的数据聚合起来，并在所有数据上对单个深度神经网络进行端到端训练的简单方法，提供了一个惊人的强大基线，超越了许多先前发表的方法。在本文中，我们基于这个强大的基线，设计了一种情景式训练程序，以一种使单个深度网络在运行时能够应对表征新领域的领域偏移的方式对其进行训练。具体来说，我们将深度网络分解为特征提取器和分类器组件，然后通过模拟每个组件与一个针对当前领域调整不佳的伙伴进行交互来训练它们。这使得两个组件都更加鲁棒，最终使我们的网络在三个领域泛化基准测试中取得了最先进的性能。此外，我们考虑了将在ImageNet上预训练的卷积神经网络(CNN)用作下游识别任务的固定特征提取器的普遍工作流程。通过视觉十项全能基准测试，我们证明了我们的情景式领域泛化训练通过显式地训练特征以应对新问题的鲁棒性，提高了这种通用特征提取器的性能。这表明领域泛化训练可以使计算机视觉的标准实践受益。

## 1. Introduction

## 1. 引言

Machine learning methods often degrade rapidly in performance if they are applied to domains with very different statistics to the data used to train them. This is the problem of domain shift, which domain adaptation (DA) aims to address in the case where some labelled or unlabelled data from the target domain is available for adaptation $\left\lbrack  {2,{36},{22},{10},{23},4}\right\rbrack$ ; and domain generalisation (DG) aims to address in the case where no adaptation to the target problem is possible $\left\lbrack  {{27},{12},{18},{33}}\right\rbrack$ due to lack of data or computation. DG is a particularly challenging problem setting, since explicit training on the target is disallowed; yet it is particularly valuable due to its lack of assumptions. For example, it would be valuable to have a domain-general visual feature extractor that performs well 'out of the box' as a representation for any novel problem, even without fine-tuning.

如果机器学习方法应用于与训练数据统计特征差异很大的领域，其性能往往会迅速下降。这就是领域偏移问题，领域自适应(Domain adaptation，DA)旨在解决在有来自目标领域的一些有标签或无标签数据可用于自适应的情况下的该问题 $\left\lbrack  {2,{36},{22},{10},{23},4}\right\rbrack$ ；而领域泛化(Domain generalisation，DG)旨在解决由于缺乏数据或计算资源而无法对目标问题进行自适应的情况下的该问题 $\left\lbrack  {{27},{12},{18},{33}}\right\rbrack$ 。领域泛化是一个特别具有挑战性的问题设定，因为不允许在目标上进行显式训练；然而，由于其假设条件较少，它又特别有价值。例如，拥有一个“开箱即用”、即使不进行微调也能很好地作为任何新问题的表示的领域通用视觉特征提取器是很有价值的。

The significance of the DG challenge has led to many studies in the literature. These span robust feature space learning $\left\lbrack  {{27},{12}}\right\rbrack$ , model architectures that are purpose designed to enable robustness to domain shift $\left\lbrack  {{16},{39},{17}}\right\rbrack$ and specially designed learning algorithms for optimising standard architectures $\left\lbrack  {{33},{18}}\right\rbrack$ that aim to fit them to a more robust minima. Among all these efforts, it turns out that the naive approach [17] of aggregating all the training domains' data together and training a single deep network end-to-end is very competitive with state-of-the-art, and better than many published methods - while simultaneously being much simpler and faster than more elaborate alternatives. In this paper we aim to build on the strength and simplicity of this simple data aggregation strategy, but improve it by designing an episodic training scheme to improve DG.

领域泛化挑战的重要性导致了文献中的许多研究。这些研究涵盖了鲁棒特征空间学习 $\left\lbrack  {{27},{12}}\right\rbrack$ 、专门设计用于实现对领域偏移的鲁棒性的模型架构 $\left\lbrack  {{16},{39},{17}}\right\rbrack$ ，以及用于优化标准架构以使其适应更鲁棒的极小值的专门设计的学习算法 $\left\lbrack  {{33},{18}}\right\rbrack$ 。在所有这些努力中，事实证明，将所有训练领域的数据聚合在一起并对单个深度网络进行端到端训练的简单方法 [17] 与最先进的方法具有很强的竞争力，并且优于许多已发表的方法，同时比更复杂的替代方法简单得多、速度也快得多。在本文中，我们旨在利用这种简单的数据聚合策略的优势和简洁性，并通过设计一种情景式训练方案来改进领域泛化。

The paradigm of episodic training has recently been popularised in the area of few-shot learning $\left\lbrack  {9,{28},{34}}\right\rbrack$ . In this problem, the goal is to use a large amount of background source data, to train a model that is capable of few-shot learning when adapting to a novel target problem. However despite the data availability, training on all the source data would not be reflective of the target few-shot learning condition. So in order to train the model in a way that reflects how it will be tested, multiple few-shot learning training episodes are setup among all the source datasets $\left\lbrack  {9,{28},{34}}\right\rbrack$ .

情景式训练范式最近在少样本学习领域$\left\lbrack  {9,{28},{34}}\right\rbrack$得到了广泛应用。在这个问题中，目标是利用大量的背景源数据来训练一个模型，使其在适应新的目标问题时能够进行少样本学习。然而，尽管有可用的数据，但在所有源数据上进行训练并不能反映目标少样本学习的情况。因此，为了以反映模型测试方式的方式对其进行训练，需要在所有源数据集之间设置多个少样本学习训练情景$\left\lbrack  {9,{28},{34}}\right\rbrack$。

How can an episodic training approach be designed for domain generalisation? Our insight is that, from the perspective of any layer $l$ in a neural network, being exposed to a novel domain at testing-time is experienced as that layer's neighbours $l - 1$ or $l + 1$ being badly tuned for the problem at hand. That is, neighbours provide input to the current layer (or accept output from it) with different statistics to the current layer's expectation. Therefore to design episodes for DG, we should expose layers to neighbours that are untrained for the current domain. If a layer can be trained to perform well in this situation of badly tuned neighbours, then its robustness to domain-shift has increased.

如何为领域泛化设计一种情景式训练方法呢？我们的见解是，从神经网络中任何一层$l$的角度来看，在测试时遇到一个新的领域，就相当于该层的相邻层$l - 1$或$l + 1$针对当前问题的调整不佳。也就是说，相邻层为当前层提供输入(或接收其输出)时，其统计特性与当前层的预期不同。因此，为了为领域泛化设计训练情景，我们应该让各层接触那些针对当前领域未经训练的相邻层。如果一层能够在相邻层调整不佳的情况下被训练得表现良好，那么它对领域偏移的鲁棒性就会增强。

To realise our episodic training idea, we break networks up into feature extractor and classifier modules and train them with our episodic framework. This leads to more robust modules that together obtain state-of-the-art results on several DG benchmarks. Our approach benefits from end-to-end learning, while being model agnostic (architecture independent), and simple and fast to train; in contrast to most existing DG techniques that rely on non-standard architectures [17], auxiliary models [33], or non-standard optimizers [18].

为了实现我们的情景式训练理念，我们将网络拆分为特征提取器和分类器模块，并使用我们的情景式框架对它们进行训练。这会得到更具鲁棒性的模块，这些模块共同在几个领域泛化基准测试中取得了最先进的结果。我们的方法受益于端到端学习，同时与模型无关(架构独立)，并且训练简单快速；这与大多数现有的依赖于非标准架构[17]、辅助模型[33]或非标准优化器[18]的领域泛化技术形成了对比。

Finally, we provide a practical demonstration of the value of explicit DG training, beyond the isolated benchmarks that are common in the literature. Specifically, we consider whether DG can benefit the common practitioner workflow of using an ImageNet [31] pre-trained CNN as a feature extractor for novel tasks and datasets. The standard (homogeneous) DG problem setting assumes shared label-spaces between source and target domain, thus highly restricting its applicability. To benefit the wider computer vision workflow, we go beyond this to heterogeneous DG (Table 5). That is, to train a feature extractor specifically to improve its robustness in representing novel downstream tasks without fine-tuning. Using the Visual Decathlon benchmark [29], we show that Episodic training provides an improved representation for novel downstream tasks compared to the standard ImageNet pre-trained CNN.

最后，我们提供了一个明确的领域泛化训练价值的实际演示，超越了文献中常见的孤立基准测试。具体来说，我们考虑领域泛化是否能使普通从业者使用ImageNet[31]预训练的卷积神经网络(CNN)作为新任务和数据集的特征提取器的工作流程受益。标准(同质)领域泛化问题设置假设源领域和目标领域之间有共享的标签空间，因此极大地限制了其适用性。为了使更广泛的计算机视觉工作流程受益，我们将其扩展到异质领域泛化(表5)。也就是说，专门训练一个特征提取器，以提高其在表示新的下游任务时的鲁棒性，而无需进行微调。使用视觉十项全能基准测试[29]，我们表明与标准的ImageNet预训练CNN相比，情景式训练为新的下游任务提供了更好的表示。

## 2. Related Work

## 2. 相关工作

Multi-Domain Learning (MDL) MDL aims to learn several domains simultaneously using a single model $\left\lbrack  {3,{29},{30},{40}}\right\rbrack$ . Depending on the problem, how much data is available per domain, and how similar the domains are, multi-domain learning can improve $\left\lbrack  {40}\right\rbrack   -$ or sometimes worsen $\left\lbrack  {3,{29},{30}}\right\rbrack$ - performance compared to a single model per domain. MDL is related to DG because the typical setting for DG is to assume a similar setup in that multiple source domains are provided. But that now the goal is to learn how to extract a domain-agnostic or domain-robust model from all those source domains. The most rigorous benchmark for MDL is the Visual Decathlon (VD) [29]. We repurpose this benchmark for DG by training a CNN on a subset of the VD domains, and then evaluating its performance as a feature extractor on an unseen disjoint subset of them. We are the first to demonstrate DG at this scale, and in the heterogeneous label setting required for VD.

多领域学习(MDL) 多领域学习旨在使用单个模型同时学习多个领域$\left\lbrack  {3,{29},{30},{40}}\right\rbrack$。根据问题、每个领域可用的数据量以及领域之间的相似程度，与每个领域使用单个模型相比，多领域学习可以提高$\left\lbrack  {40}\right\rbrack   -$，有时也会降低$\left\lbrack  {3,{29},{30}}\right\rbrack$性能。多领域学习与领域泛化相关，因为领域泛化的典型设置是假设提供了多个源领域。但现在的目标是学习如何从所有这些源领域中提取一个与领域无关或对领域具有鲁棒性的模型。多领域学习最严格的基准测试是视觉十项全能(VD)[29]。我们通过在VD领域的一个子集上训练一个CNN，然后在一个未见过的不相交子集上评估其作为特征提取器的性能，将这个基准测试用于领域泛化。我们是第一个在这个规模上以及在VD所需的异质标签设置下展示领域泛化的。

Domain Generalization Despite different details, previous DG methods can be divided into a few categories by motivating intuition. Domain Invariant Features: These aim to learn a domain-invariant feature representation, typically by minimising the discrepancy between all source domains - and assuming that the resulting source-domain invariant feature will work well for the target as well. To this end [27] employed maximum mean discrepancy (MMD), while [12] proposed a multi-domain reconstruction auto-encoder to learn this domain-invariant feature. More recently, [20] applied MMD constraints within the representation learning of an autoencoder via adversarial training. Hierarchical Models: These learn a hierarchical set of model parameters, so that the model for each domain is parameterised by a combination of a domain-agnostic and a domain-specific parameter $\left\lbrack  {{16},{17}}\right\rbrack$ . After learning such a hierarchical model structure on the source domains the domain agnostic parameter can be extracted as the model with the least domain-specific bias, that is most likely to work on a target problem. This intuition has been exploited in both shallow [16] and deep [17] settings. Data Augmentation: A few studies proposed data augmentation strategies to synthesise additional training data to improve the robustness of a model to novel domains. These include the Bayesian network [33], which perturbs input data based on the domain classification signal from an auxiliary domain classifier. Meanwhile, [37] proposed an adversarial data augmentation method to synthesize 'hard' data for the training model to enhance its generalization. Optimisation Algorithms: A final category of approach is to modify a conventional learning algorithm in an attempt to find a more robust minima during training, for example through meta-learning [18]. Our approach is different to all of these in that it trains a standard deep model, without special data augmentation and with a conventional optimiser. The key idea requires only a simple modification of the training procedure to introduce appropriately constructed episodes. Finally, in contrast to the small datasets considered previously, we demonstrate the impact of DG model training in the large scale VD benchmark.

领域泛化(Domain Generalization) 尽管细节有所不同，但先前的领域泛化方法可以根据其动机直觉分为几类。领域不变特征:这些方法旨在学习一种领域不变的特征表示，通常是通过最小化所有源领域之间的差异来实现的——并假设由此得到的源领域不变特征也能很好地适用于目标领域。为此，文献[27]采用了最大均值差异(Maximum Mean Discrepancy，MMD)，而文献[12]提出了一种多领域重建自动编码器来学习这种领域不变特征。最近，文献[20]通过对抗训练在自动编码器的表示学习中应用了MMD约束。分层模型:这些方法学习一组分层的模型参数，使得每个领域的模型由一个领域无关参数和一个领域特定参数 $\left\lbrack  {{16},{17}}\right\rbrack$ 的组合来参数化。在源领域上学习了这样的分层模型结构后，可以提取出领域无关参数作为具有最小领域特定偏差的模型，即最有可能适用于目标问题的模型。这种直觉在浅层[16]和深层[17]设置中都得到了应用。数据增强:一些研究提出了数据增强策略，以合成额外的训练数据，从而提高模型对新领域的鲁棒性。这些策略包括贝叶斯网络[33]，它基于来自辅助领域分类器的领域分类信号对输入数据进行扰动。同时，文献[37]提出了一种对抗性数据增强方法，为训练模型合成“难”数据，以增强其泛化能力。优化算法:最后一类方法是修改传统的学习算法，试图在训练过程中找到更鲁棒的最小值，例如通过元学习[18]。我们的方法与所有这些方法都不同，因为它训练的是一个标准的深度模型，无需特殊的数据增强，并且使用传统的优化器。关键思想只需要对训练过程进行简单的修改，以引入适当构造的情节。最后，与先前考虑的小数据集不同，我们展示了在大规模视觉领域(VD)基准测试中领域泛化模型训练的影响。

Neural Network Meta-Learning Learning-to-learn and meta-learning methods have resurged recently, in particular in few-shot recognition $\left\lbrack  {9,{34},{25}}\right\rbrack$ , and learning-to-optimize [28] tasks. Despite signifiant other differences in motivation and methodological formalisations, a common feature of these methods is an episodic training strategy. In few-shot learning, the intuition is that while lot of source tasks and data may be available, these should be used for training in a way that closely simulates the testing condition. Therefore at each learning iteration, a random subset of source tasks and instances are sampled to generate a training episode defined by a random few-shot learning task of similar data volume and cardinality as the model is expected to be tested on at runtime. Thus the model eventually 'sees' all the training data in aggregate, but in any given iteration, it is evaluated in a condition similar to a real 'testing' condition. In this paper we aim to develop an episodic training strategy to improve domain-robustness, rather than learning-to-learn. While the high-level idea of an episodic strategy is the same, the DG problem and associated episode construction details are completely different.

神经网络元学习 学习如何学习和元学习方法最近重新兴起，特别是在少样本识别 $\left\lbrack  {9,{34},{25}}\right\rbrack$ 和学习如何优化[28]任务中。尽管在动机和方法形式化方面存在显著的其他差异，但这些方法的一个共同特征是采用情节式训练策略。在少样本学习中，其直觉是，虽然可能有大量的源任务和数据可用，但应该以一种紧密模拟测试条件的方式使用这些数据进行训练。因此，在每次学习迭代中，会随机抽取一部分源任务和实例，以生成一个训练情节，该情节由一个随机的少样本学习任务定义，其数据量和基数与模型在运行时预期测试的情况相似。因此，模型最终会“看到”所有的训练数据，但在任何给定的迭代中，它都是在类似于真实“测试”条件的情况下进行评估的。在本文中，我们旨在开发一种情节式训练策略，以提高领域鲁棒性，而不是学习如何学习。虽然情节式策略的高层思想是相同的，但领域泛化问题和相关的情节构造细节是完全不同的。

![0195d2b5-80fd-7da4-aedb-67e863c93e2a_2_142_206_701_177_0.jpg](images/0195d2b5-80fd-7da4-aedb-67e863c93e2a_2_142_206_701_177_0.jpg)

Figure 1: Illustration of vanilla domain-aggregation for multi-domain learning. A single model $\psi \left( {\theta \left( \cdot \right) }\right)$ classifies data from all domains.

图1:多领域学习的普通领域聚合示意图。单个模型 $\psi \left( {\theta \left( \cdot \right) }\right)$ 对来自所有领域的数据进行分类。

## 3. Methodology

## 3. 方法

In this section we will first introduce the basic dataset aggregation method (AGG) which provides a strong baseline for DG performance, and then subsequently present three episodic training strategies for training it more robustly.

在本节中，我们将首先介绍基本的数据集聚合方法(AGG)，该方法为领域泛化性能提供了一个强大的基线，然后随后介绍三种情节式训练策略，以更鲁棒地训练该方法。

Problem Setting In the DG setting, we assume that we are given $n$ source domains $\mathcal{D} = \left\lbrack  {{\mathcal{D}}_{1},\ldots ,{\mathcal{D}}_{n}}\right\rbrack$ , where ${\mathcal{D}}_{i}$ is the ${i}^{th}$ source domain containing data-label pairs ${\left( {\mathbf{x}}_{i}^{j},{y}_{i}^{j}\right) }^{1}$ . The goal is to use these to learn a model $f : \mathbf{x} \rightarrow  y$ that generalises well to a novel testing domain ${\mathcal{D}}_{ * }$ with different statistics to the training domains, without assuming any knowledge of the testing domain during model learning.

问题设定 在领域泛化设定中，我们假设给定 $n$ 个源领域 $\mathcal{D} = \left\lbrack  {{\mathcal{D}}_{1},\ldots ,{\mathcal{D}}_{n}}\right\rbrack$ ，其中 ${\mathcal{D}}_{i}$ 是第 ${i}^{th}$ 个源领域，包含数据 - 标签对 ${\left( {\mathbf{x}}_{i}^{j},{y}_{i}^{j}\right) }^{1}$ 。目标是利用这些数据学习一个模型 $f : \mathbf{x} \rightarrow  y$ ，该模型能够很好地泛化到一个新的测试领域 ${\mathcal{D}}_{ * }$ ，该测试领域的统计特性与训练领域不同，并且在模型学习过程中不假设对测试领域有任何了解。

For homogeneous DG, we assume that all the source domains and the target domain share the same label space ${\mathcal{Y}}_{i} = {\mathcal{Y}}_{j} = {\mathcal{Y}}_{ * }$ , $\forall i, j \in  \left\lbrack  {1, n}\right\rbrack$ . For the more challenging heterogeneous setting, the domains can have different, potentially completely disjoint label spaces ${\mathcal{Y}}_{i} \neq  {\mathcal{Y}}_{j} \neq  {\mathcal{Y}}_{ * }$ . We will start by introducing the homogeneous case and discuss the heterogeneous case later.

对于同质领域泛化(DG)，我们假设所有源域和目标域共享相同的标签空间 ${\mathcal{Y}}_{i} = {\mathcal{Y}}_{j} = {\mathcal{Y}}_{ * }$ 、 $\forall i, j \in  \left\lbrack  {1, n}\right\rbrack$ 。对于更具挑战性的异质设置，各领域可能具有不同的、甚至完全不相交的标签空间 ${\mathcal{Y}}_{i} \neq  {\mathcal{Y}}_{j} \neq  {\mathcal{Y}}_{ * }$ 。我们将先介绍同质情况，稍后再讨论异质情况。

Architecture We break neural network classifiers $f : \mathbf{x} \rightarrow  y$ into a sequence modules. In practice, we use two: A feature extractor $\theta \left( \cdot \right)$ and a classifier $\psi \left( \cdot \right)$ , so that $f\left( \mathbf{x}\right)  = \psi \left( {\theta \left( \mathbf{x}\right) }\right)$ .

架构 我们将神经网络分类器 $f : \mathbf{x} \rightarrow  y$ 分解为一系列模块。在实践中，我们使用两个模块:一个特征提取器 $\theta \left( \cdot \right)$ 和一个分类器 $\psi \left( \cdot \right)$ ，使得 $f\left( \mathbf{x}\right)  = \psi \left( {\theta \left( \mathbf{x}\right) }\right)$ 。

### 3.1. Overview

### 3.1. 概述

Vanilla Aggregation Method A simple approach to the DG problem is to simply aggregate all the source domains' data together, and train a single CNN end-to-end ignoring the domain label information entirely [17]. This approach is simple, fast and competitive with more elaborate state-of-the-art alternatives. In terms of neural network modules, it means that both the classifier $\psi$ and the feature extractor $\theta$ are shared across all domains ${}^{2}$ , as illustrated in Fig. 1, leading to the objective function:

普通聚合方法 解决领域泛化(DG)问题的一种简单方法是将所有源域的数据简单地聚合在一起，并端到端地训练一个单一的卷积神经网络(CNN)，完全忽略领域标签信息 [17]。这种方法简单、快速，并且与更复杂的最先进方法相比具有竞争力。就神经网络模块而言，这意味着分类器 $\psi$ 和特征提取器 $\theta$ 在所有领域 ${}^{2}$ 中都是共享的，如图1所示，从而得到目标函数:

$$
\mathop{\operatorname{argmin}}\limits_{{\theta ,\psi }}{\mathbb{E}}_{{\mathcal{D}}_{i} \sim  \mathcal{D}}\left\lbrack  {{\mathbb{E}}_{\left( {{\mathbf{x}}_{i},{y}_{i}}\right)  \sim  {\mathcal{D}}_{i}}\left\lbrack  {\ell \left( {{y}_{i},\psi \left( {\theta \left( {\mathbf{x}}_{i}\right) }\right) }\right\rbrack  }\right\rbrack  }\right.  \tag{1}
$$

where $\ell \left( \cdot \right)$ is the cross-entropy loss here.

其中 $\ell \left( \cdot \right)$ 是此处的交叉熵损失。

Domain Specific Models Our goal is to improve robustness by exposing individual modules to neighbours that are badly calibrated to a given domain. To obtain these 'badly calibrated' components, we also train domain-specific models. As illustrated in Fig. 2, this means that each domain $i$ has its own model composed of feature extractor ${\theta }_{i}$ and classifier ${\psi }_{i}$ . Each domain-specific module is only exposed to data of that corresponding domain. To train domain-specific models, we optimise:

特定领域模型 我们的目标是通过让各个模块接触到针对给定领域校准不佳的邻居来提高鲁棒性。为了获得这些“校准不佳”的组件，我们还训练特定领域的模型。如图2所示，这意味着每个领域 $i$ 都有自己由特征提取器 ${\theta }_{i}$ 和分类器 ${\psi }_{i}$ 组成的模型。每个特定领域的模块仅接触相应领域的数据。为了训练特定领域的模型，我们进行如下优化:

$$
\mathop{\operatorname{argmin}}\limits_{{\left\lbrack  {{\theta }_{1},\ldots ,{\theta }_{n}}\right\rbrack  ,\left\lbrack  {{\psi }_{1},\ldots ,{\psi }_{n}}\right\rbrack  }}{\mathbb{E}}_{{\mathcal{D}}_{i} \sim  \mathcal{D}}\left\lbrack  {{\mathbb{E}}_{\left( {{\mathbf{x}}_{i},{y}_{i}}\right)  \sim  {\mathcal{D}}_{i}}\left\lbrack  {\ell \left( {{y}_{i},{\psi }_{i}\left( {{\theta }_{i}\left( {\mathbf{x}}_{i}\right) }\right) }\right) }\right\rbrack  }\right\rbrack   \tag{2}
$$

![0195d2b5-80fd-7da4-aedb-67e863c93e2a_2_909_205_695_449_0.jpg](images/0195d2b5-80fd-7da4-aedb-67e863c93e2a_2_909_205_695_449_0.jpg)

Figure 2: Illustration of domain-specific branches. One classifier and feature extractor are trained per-domain.

图2:特定领域分支的示意图。每个领域训练一个分类器和一个特征提取器。

Episodic Training Our goal is to train a domain agnostic model, as per $\psi$ and $\theta$ in the aggregation method in Eq. 1. And we will design an episodic scheme that makes use of the domain-specific modules as per Eq. 2 to help the domain-agnostic model achieve the desired robustness. Specifically, we will generate episodes where each domain agnostic module $\psi$ and $\theta$ is paired with a domain-specific partner that is mismatched with the current data being input. So module and data combinations of the form $\left( {\psi ,{\theta }_{i},{x}_{{i}^{\prime }}}\right)$ and $\left( {{\psi }_{i},\theta ,{x}_{{i}^{\prime }}}\right)$ where $i \neq  {i}^{\prime }$ .

情景式训练 我们的目标是训练一个与领域无关的模型，如公式1中的聚合方法中的 $\psi$ 和 $\theta$ 所示。并且我们将设计一个情景式方案，利用公式2中的特定领域模块来帮助与领域无关的模型实现所需的鲁棒性。具体来说，我们将生成一些情景，其中每个与领域无关的模块 $\psi$ 和 $\theta$ 都与一个与当前输入数据不匹配的特定领域伙伴配对。因此，模块和数据的组合形式为 $\left( {\psi ,{\theta }_{i},{x}_{{i}^{\prime }}}\right)$ 和 $\left( {{\psi }_{i},\theta ,{x}_{{i}^{\prime }}}\right)$ ，其中 $i \neq  {i}^{\prime }$ 。

### 3.2. Episodic Training of Feature Extractor

### 3.2. 特征提取器的情景式训练

To train a robust feature extractor $\theta$ , we ask it to learn features which are robust enough that data from domain $i$ can be processed by a classifier that has never experienced domain $i$ before as shown in Fig. 3. To generate episodes according to this criterion, we optimise

为了训练一个鲁棒的特征提取器 $\theta$ ，我们要求它学习足够鲁棒的特征，使得来自领域 $i$ 的数据可以由一个从未经历过领域 $i$ 的分类器处理，如图3所示。为了根据这个标准生成情景，我们进行如下优化

$$
\mathop{\operatorname{argmin}}\limits_{\theta }{\mathbb{E}}_{i, j \sim  \left\lbrack  {1, n}\right\rbrack  , i \neq  j}\left\lbrack  {{\mathbb{E}}_{\left( {{\mathbf{x}}_{i},{y}_{i}}\right)  \sim  {\mathcal{D}}_{i}}\left\lbrack  {\ell \left( {{y}_{i},{\bar{\psi }}_{j}\left( {\theta \left( {\mathbf{x}}_{i}\right) }\right) }\right) }\right\rbrack  }\right\rbrack   \tag{3}
$$

where $i \neq  j$ and ${\bar{\psi }}_{j}$ means that ${\psi }_{j}$ is considered constant for the generation of this loss, i.e., it does not receive back-propagated gradients. This gradient-blocking is important, because without it the data ${\mathbf{x}}_{i}$ from domain $i$ would ’pollute’ the classifier ${\psi }_{j}$ which we want to retain as being naive to domains outside of $j$ .

其中 $i \neq  j$ 和 ${\bar{\psi }}_{j}$ 表示在生成此损失时 ${\psi }_{j}$ 被视为常量，即它不会接收反向传播的梯度。这种梯度阻断很重要，因为如果没有它，来自领域 $i$ 的数据 ${\mathbf{x}}_{i}$ 会“污染”我们希望保持对 $j$ 之外的领域一无所知的分类器 ${\psi }_{j}$ 。

Thus in this optimisation, only the feature extractor $\theta$ is penalized whenever the classifier ${\psi }_{j}$ makes the wrong prediction. That means that, for this loss to be minimised, the shared feature extractor $\theta$ must map data ${\mathbf{x}}_{i}$ into a format that a ’naive’ classifier ${\psi }_{j}$ can correctly classify. The feature extractor must learn to help a classifier recognize a data point that is from a domain that is novel to that classifier.

因此，在这个优化过程中，每当分类器 ${\psi }_{j}$ 做出错误预测时，只有特征提取器 $\theta$ 会受到惩罚。这意味着，为了最小化这个损失，共享特征提取器 $\theta$ 必须将数据 ${\mathbf{x}}_{i}$ 映射成一种格式，使得一个“简单”的分类器 ${\psi }_{j}$ 能够正确分类。特征提取器必须学会帮助分类器识别来自该分类器未曾接触过的领域的数据点。

---

${}^{1}i$ indicates domain index and $j$ indicates instance number within domain. For simplicity, we will omit $j$ in the following.

${}^{1}i$ 表示领域索引，$j$ 表示领域内的实例编号。为了简单起见，我们在下面将省略 $j$。

${}^{2}$ At least in the homogeneous case

${}^{2}$ 至少在同质情况下

---

![0195d2b5-80fd-7da4-aedb-67e863c93e2a_3_140_208_706_355_0.jpg](images/0195d2b5-80fd-7da4-aedb-67e863c93e2a_3_140_208_706_355_0.jpg)

Figure 3: Episodic training for feature and classifier regularisation. The shared feature extractor feeds domain specific classifiers. The shared classifier reads domain-specific feature extractors.

图 3:用于特征和分类器正则化的情景式训练。共享特征提取器为特定领域的分类器提供数据。共享分类器读取特定领域的特征提取器的输出。

### 3.3. Episodic Training of Classifier

### 3.3. 分类器的情景式训练

Analogous to the above, we can also interpret DG as the requirement that a classifier should be robust enough to classify data even if it is encoded by a feature extractor which has never seen this type of data in the past, as illustrated in Fig. 3. Thus to train the robust classifier $\psi$ we ask it to classify domain $i$ instances ${\mathbf{x}}_{i}$ fed through a domain $j$ -specific feature extractor ${\theta }_{j}$ . To generate episodes according to this criterion, we do:

与上述情况类似，我们也可以将领域泛化(DG)解释为:即使数据是由一个过去从未见过此类数据的特征提取器进行编码的，分类器也应该足够鲁棒，能够对数据进行分类，如图 3 所示。因此，为了训练鲁棒的分类器 $\psi$，我们要求它对通过特定领域 $j$ 的特征提取器 ${\theta }_{j}$ 输入的领域 $i$ 的实例 ${\mathbf{x}}_{i}$ 进行分类。为了根据这个标准生成情景，我们进行以下操作:

$$
\mathop{\operatorname{argmin}}\limits_{\psi }{\mathbb{E}}_{i, j \sim  \left\lbrack  {1, n}\right\rbrack  , i \neq  j}\left\lbrack  {{\mathbb{E}}_{\left( {{\mathbf{x}}_{i},{y}_{i}}\right)  \sim  {\mathcal{D}}_{i}}\left\lbrack  {\ell \left( {{y}_{i},\psi \left( {{\bar{\theta }}_{j}\left( {\mathbf{x}}_{i}\right) }\right) }\right) }\right\rbrack  }\right\rbrack   \tag{4}
$$

where $i \neq  j$ and ${\bar{\theta }}_{j}$ means ${\theta }_{j}$ is considered constant for generation of the loss here. Similar to the training of the feature extractor module, this operation is important to retain the domain-specificity of feature extractor ${\theta }_{j}$ . The result is that only the classifier $\psi$ is penalised, and in order to minimise this loss $\psi$ must be robust enough to accept data ${\mathbf{x}}_{i}$ that has been encoded by a naive feature extractor ${\theta }_{j}$ .

其中，$i \neq  j$ 和 ${\bar{\theta }}_{j}$ 表示 ${\theta }_{j}$ 在这里被视为生成损失时的常量。与特征提取器模块的训练类似，此操作对于保留特征提取器 ${\theta }_{j}$ 的领域特异性很重要。结果是只有分类器 $\psi$ 会受到惩罚，并且为了最小化这个损失，$\psi$ 必须足够鲁棒，能够接受由简单特征提取器 ${\theta }_{j}$ 编码的数据 ${\mathbf{x}}_{i}$。

### 3.4. Episodic Training by Random Classifier

### 3.4. 通过随机分类器进行情景式训练

The episodic feature training strategy above is limited to the homogeneous DG setting, since it requires all domains to share label-space in order to create episodes. But in the heterogeneous scenarios, the shared label-space assumption is not met. We next introduce a novel feature training strategy that is suitable for both homogeneous and heterogeneous label-spaces.

上述情景式特征训练策略仅限于同质的领域泛化设置，因为它要求所有领域共享标签空间才能创建情景。但在异质场景中，共享标签空间的假设不成立。接下来，我们介绍一种适用于同质和异质标签空间的新型特征训练策略。

In Section 3.2, we introduced the notion of regularising a deep feature extractor by requiring it to support a classifier inexperienced with data from the current domain. Taking this to an extreme, we consider asking the feature extractor to support the predictions of a classifier with random weights, as shown in Fig. 4. To this end, our objective function here is:

在 3.2 节中，我们引入了通过要求深度特征提取器支持对来自当前领域的数据缺乏经验的分类器来对其进行正则化的概念。将这一点推向极端，我们考虑要求特征提取器支持具有随机权重的分类器的预测，如图 4 所示。为此，我们这里的目标函数是:

$$
\mathop{\operatorname{argmin}}\limits_{\theta }{\mathbb{E}}_{{\mathcal{D}}_{i} \sim  \mathcal{D}}\left\lbrack  {{\mathbb{E}}_{\left( {{\mathbf{x}}_{i},{y}_{i}}\right)  \sim  {\mathcal{D}}_{i}}\left\lbrack  {\ell \left( {{y}_{i},{\bar{\psi }}_{r}\left( {\theta \left( {\mathbf{x}}_{i}\right) }\right) }\right\rbrack  }\right\rbrack  }\right.  \tag{5}
$$

where, ${\psi }_{r}$ is a randomly initialised classifier, and ${\bar{\psi }}_{r}$ means it is a constant not updated in the optimization. This can be seen as an extreme version of our earlier episodic cross-domain feature extractor training (not only it has not seen any data from domain ${\mathbf{x}}_{i}$ , but it has not seen any data at all). Moreover, it has the benefit of not requiring a label-space to be shared across all training domains unlike the previous method in Eq. 3.

其中，${\psi }_{r}$ 是一个随机初始化的分类器，${\bar{\psi }}_{r}$ 表示它是一个在优化过程中不更新的常量。这可以看作是我们早期情景式跨领域特征提取器训练的极端版本(它不仅从未见过来自领域 ${\mathbf{x}}_{i}$ 的任何数据，而且根本没有见过任何数据)。此外，与式 3 中的先前方法不同，它的优点是不需要所有训练领域共享标签空间。

![0195d2b5-80fd-7da4-aedb-67e863c93e2a_3_906_208_700_246_0.jpg](images/0195d2b5-80fd-7da4-aedb-67e863c93e2a_3_906_208_700_246_0.jpg)

Figure 4: The architecture of random classifier regularization.

图 4:随机分类器正则化的架构。

Algorithm 1 Episodic Training for Domain Generalization

算法 1 用于领域泛化的情景式训练

---

Input: $\mathcal{D} = \left\lbrack  {{\mathcal{D}}_{1},{\mathcal{D}}_{2},\ldots ,{\mathcal{D}}_{n}}\right\rbrack$

输入:$\mathcal{D} = \left\lbrack  {{\mathcal{D}}_{1},{\mathcal{D}}_{2},\ldots ,{\mathcal{D}}_{n}}\right\rbrack$

Initialise hyper parameters: ${\lambda }_{1},{\lambda }_{2},{\lambda }_{3},\alpha$

初始化超参数:${\lambda }_{1},{\lambda }_{2},{\lambda }_{3},\alpha$

: Initialise model parameters: domain specific modules

:初始化模型参数:特定领域的模块

${\theta }_{1},\ldots ,{\theta }_{n}$ and ${\psi }_{1},\ldots ,{\psi }_{n}$ ; AGG modules $\theta ,\psi$ ; random

${\theta }_{1},\ldots ,{\theta }_{n}$ 和 ${\psi }_{1},\ldots ,{\psi }_{n}$ ；聚合(AGG)模块 $\theta ,\psi$ ；随机

classifier ${\psi }_{r}$

分类器 ${\psi }_{r}$

while not done training do

在训练未完成时循环执行

	for $\left( {{\theta }_{i},{\psi }_{i}}\right)  \in  \left\lbrack  {\left( {{\theta }_{1},{\psi }_{1}}\right) ,\ldots ,\left( {{\theta }_{n},{\psi }_{n}}\right) }\right\rbrack$ do

	  对于 $\left( {{\theta }_{i},{\psi }_{i}}\right)  \in  \left\lbrack  {\left( {{\theta }_{1},{\psi }_{1}}\right) ,\ldots ,\left( {{\theta }_{n},{\psi }_{n}}\right) }\right\rbrack$ 循环执行

		Update ${\theta }_{i} \mathrel{\text{:=}} {\theta }_{i} - \alpha {\nabla }_{{\theta }_{i}}\left( {L}_{ds}\right)$

		    更新 ${\theta }_{i} \mathrel{\text{:=}} {\theta }_{i} - \alpha {\nabla }_{{\theta }_{i}}\left( {L}_{ds}\right)$

		Update ${\psi }_{i} \mathrel{\text{:=}} {\psi }_{i} - \alpha {\nabla }_{{\psi }_{i}}\left( {L}_{ds}\right)$

		    更新 ${\psi }_{i} \mathrel{\text{:=}} {\psi }_{i} - \alpha {\nabla }_{{\psi }_{i}}\left( {L}_{ds}\right)$

	end for

	  结束循环

	Update $\theta  \mathrel{\text{:=}} \theta  - \alpha {\nabla }_{\theta }\left( {{L}_{agg} + {\lambda }_{1}{L}_{epif} + {\lambda }_{3}{L}_{epir}}\right)$

	  更新 $\theta  \mathrel{\text{:=}} \theta  - \alpha {\nabla }_{\theta }\left( {{L}_{agg} + {\lambda }_{1}{L}_{epif} + {\lambda }_{3}{L}_{epir}}\right)$

	Update $\psi  \mathrel{\text{:=}} \psi  - \alpha {\nabla }_{\psi }\left( {{L}_{agg} + {\lambda }_{2}{L}_{epic}}\right)$

	  更新 $\psi  \mathrel{\text{:=}} \psi  - \alpha {\nabla }_{\psi }\left( {{L}_{agg} + {\lambda }_{2}{L}_{epic}}\right)$

end while

结束循环

Output: $\theta ,\psi$

输出:$\theta ,\psi$

---

Specifically, in Eq. 3, the routing ${\mathbf{x}}_{i} \mapsto  \theta  \mapsto  {\psi }_{j}$ requires ${\psi }_{j}$ to have a label-space matching $\left( {{\mathbf{x}}_{i},{y}_{j}}\right)$ . But for Eq. 5, each domain can be equipped with its own random classifier ${\psi }_{r}$ with a cardinality matching its normal label-space. This property makes Eq. 5 suitable for heterogeneous domains.

具体而言，在公式3中，路由 ${\mathbf{x}}_{i} \mapsto  \theta  \mapsto  {\psi }_{j}$ 要求 ${\psi }_{j}$ 具有与 $\left( {{\mathbf{x}}_{i},{y}_{j}}\right)$ 匹配的标签空间。但对于公式5，每个领域可以配备其自己的随机分类器 ${\psi }_{r}$ ，其基数与正常标签空间相匹配。这一特性使公式5适用于异构领域。

### 3.5. Algorithm Flow

### 3.5. 算法流程

Our full algorithm brings together the domain agnostic modules that are our goal to train and the supporting domain-specific modules that help train them (Section 3.1). We generate episodes according to the three strategies introduced above. Referring the losses in Eq. 1, 2, 3, 4, 5 as ${L}_{agg},{L}_{ds},{L}_{epif}$ , ${L}_{\text{epic }},{L}_{\text{epir }}$ , then overall we optimise:

我们的完整算法将我们要训练的与领域无关的模块和有助于训练它们的特定领域支持模块结合在一起(3.1节)。我们根据上述三种策略生成情节。将公式1、2、3、4、5中的损失分别记为 ${L}_{agg},{L}_{ds},{L}_{epif}$ 、 ${L}_{\text{epic }},{L}_{\text{epir }}$ ，那么总体上我们优化:

$$
{L}_{\text{full }} = {L}_{agg} + {L}_{ds} + {\lambda }_{1}{L}_{\text{epif }} + {\lambda }_{2}{L}_{\text{epic }} + {\lambda }_{3}{L}_{\text{epir }} \tag{6}
$$

for parameters $\theta ,\phi ,{\left\{  {\theta }_{i},{\psi }_{i}\right\}  }_{i = 1}^{n}$ . The full pseudocode for the algorithm is given in Algorithm 1. It is noteworthy that, in practice, when training we first warm up the domain-specific branches for a few iterations before training both the domain-specific and domain-agnostic modules jointly. After training, only the domain agnostic modules (of AGG) will be deployed for testing.

针对参数 $\theta ,\phi ,{\left\{  {\theta }_{i},{\psi }_{i}\right\}  }_{i = 1}^{n}$ 。该算法的完整伪代码如算法1所示。值得注意的是，在实践中，训练时我们首先对特定领域的分支进行几次迭代预热，然后再联合训练特定领域和与领域无关的模块。训练完成后，仅部署(AGG的)与领域无关的模块进行测试。

## 4. Experiments

## 4. 实验

### 4.1. Datasets and Settings

### 4.1. 数据集与设置

Datasets We evaluate our algorithm on three different homogeneous DG benchmarks and introduce a novel and larger scale heterogeneous DG benchmark. The datasets are: IXMAS: [38] is cross-view action recognition task. Two object recognition benchmarks include: VLCS [8], which includes images from four famous datasets PASCAL VOC2007 (V) [7], LabelMe (L) [32], Caltech (C) [19] and SUN09 (S) [6] and the more recent PACS which has a larger cross-domain gap than VLCS [17]. It contains four domains covering Photo (P), Art Painting (A), Cartoon (C) and Sketch (S) images. VD: For the final benchmark we repurpose the Visual Decathlon [29] benchmark to evaluate DG.

数据集 我们在三个不同的同质领域泛化(DG)基准上评估了我们的算法，并引入了一个新颖且更大规模的异质领域泛化基准。这些数据集包括:IXMAS:[38] 是跨视角动作识别任务。两个目标识别基准包括:VLCS [8]，它包含来自四个著名数据集的图像，分别是PASCAL VOC2007(V)[7]、LabelMe(L)[32]、Caltech(C)[19] 和SUN09(S)[6]；以及较新的PACS，它比VLCS具有更大的跨领域差距 [17]。它包含四个领域，涵盖照片(P)、艺术绘画(A)、卡通(C)和素描(S)图像。VD:对于最后一个基准，我们重新利用了视觉十项全能 [29] 基准来评估领域泛化。

Competitors We evaluate the following competitors: AGG the vanilla aggregation method, introduced in Eq. 1, trains a single model for all source domains. DICA [27] a kernel-based method for learning domain invariant feature representations. LRE-SVM [39] a SVM-based method, that trains different SVM model for each source domain. For a test domain, it uses the SVM model from the most similar source domain. D-MTAE [12] a de-noising multi-task auto encoder method, which learns domain invariant features by cross-domain reconstruction. DSN [4] Domain Separation Networks decompose the sources domains into shared and private spaces and learns them with a reconstruction signal. TF-CNN [17] learns a domain-agnostic model by factoring out the common component from a set of domain-specific models, as well as tensor factorization to compress the model parameters. CCSA [26] uses semantic alignment to regularize the learned feature subspace. DANN [11] Domain Adversarial Neural Networks train a feature extractor with a domain-adversarial loss among the source domains. The source-domain invariant feature extractor is assumed to generalise better to novel target domains. MAML [9] The model-agnostic meta-learning method for fast adaptation, repurposed for DG. MLDG [18] A recent meta-learning based optimization method. It mimics the DG setting by splitting source domains into meta-train and meta-test, and modifies the optimisation to improve meta-test performance. Fusion [24] A method that fuses the predictions from source domain classifiers for the target domain. MMD-AAE [20] A recent method that learns domain invariant feature autoencoding with adversarial training and ensuring that domains are aligned by the MMD constraint. CrossGrad [33] A recent method that uses Bayesian networks to perturb the input manifold for DG. MetaReg [1] A recent DG method that meta-learns the classifier regularizer. We note that DANN (domain adaptation) is not designed for DG. However, DANN learns domain invariant features, which is natural for DG. And we found it effective for this problem. Therefore we repurpose it as a baseline.

竞争对手 我们评估了以下竞争对手:AGG 即普通聚合方法，在公式1中引入，为所有源领域训练单个模型。DICA [27] 一种基于核的方法，用于学习领域不变特征表示。LRE - SVM [39] 一种基于支持向量机(SVM)的方法，为每个源领域训练不同的SVM模型。对于测试领域，它使用与最相似源领域对应的SVM模型。D - MTAE [12] 一种去噪多任务自动编码器方法，通过跨领域重建学习领域不变特征。DSN [4] 领域分离网络(Domain Separation Networks)将源领域分解为共享空间和私有空间，并通过重建信号学习这些空间。TF - CNN [17] 通过从一组特定领域模型中分解出公共组件来学习领域无关模型，同时使用张量分解来压缩模型参数。CCSA [26] 使用语义对齐来正则化所学习的特征子空间。DANN [11] 领域对抗神经网络(Domain Adversarial Neural Networks)在源领域之间使用领域对抗损失来训练特征提取器。假设源领域不变特征提取器能更好地泛化到新的目标领域。MAML [9] 模型无关元学习方法，用于快速适应，被重新用于领域泛化。MLDG [18] 一种最近基于元学习的优化方法。它通过将源领域划分为元训练和元测试来模拟领域泛化设置，并修改优化过程以提高元测试性能。Fusion [24] 一种融合源领域分类器对目标领域预测结果的方法。MMD - AAE [20] 一种最近的方法，通过对抗训练学习领域不变特征自动编码，并通过最大均值差异(MMD)约束确保领域对齐。CrossGrad [33] 一种最近的方法，使用贝叶斯网络对输入流形进行扰动以实现领域泛化。MetaReg [1] 一种最近的领域泛化方法，通过元学习对分类器正则化器进行学习。我们注意到DANN(领域适应)并非为领域泛化而设计。然而，DANN学习领域不变特征，这对于领域泛化来说是自然的。并且我们发现它对这个问题是有效的。因此，我们将其重新用作基线方法。

We call our method as Episodic. We use Epi-FCR to denote our full method with (f)eature regularisation, (c)lassifier regularisation and (r)andom classifier regularisation respectively. Ablated variants such as Epi-F denote feature regularisation alone, etc. Episodic is implemented using PyTorch ${}^{3}$ .

我们将我们的方法称为Episodic。我们使用Epi - FCR来分别表示我们具有(f)特征正则化、(c)分类器正则化和(r)随机分类器正则化的完整方法。诸如Epi - F之类的消融变体仅表示特征正则化等。Episodic使用PyTorch ${}^{3}$ 实现。

### 4.2. Evaluation on IXMAS dataset

### 4.2. 在IXMAS数据集上的评估

Settings IXMAS contains 11 different human actions. All actions were video recorded by 5 cameras with different views (referred as 0,...,4). The goal is to train an action recognition model on a set of source views (domains), and recognise the action from a novel target view (domain). We follow [20] to keep the first 5 actions and use the same Dense trajectory features as input. For our method, we follow [20] to use a one-hidden layer network with 2000 hidden neurons as our backbone and report the average result of 20 runs. The optimizer is M-SGD with learning rate 1e-4, momentum 0.9, weight decay 5e-5. We use ${\lambda }_{1} = {2.0},{\lambda }_{2} = {2.0}$ , and ${\lambda }_{3} = {0.5}$ .

设置 IXMAS包含11种不同的人类动作。所有动作由5个具有不同视角(标记为0, ..., 4)的摄像机进行视频记录。目标是在一组源视角(领域)上训练动作识别模型，并从新的目标视角(领域)识别动作。我们遵循文献[20]保留前5个动作，并使用相同的密集轨迹特征作为输入。对于我们的方法，我们遵循文献[20]使用具有2000个隐藏神经元的单隐藏层网络作为骨干网络，并报告20次运行的平均结果。优化器是M - SGD，学习率为1e - 4，动量为0.9，权重衰减为5e - 5。我们使用 ${\lambda }_{1} = {2.0},{\lambda }_{2} = {2.0}$ 和 ${\lambda }_{3} = {0.5}$。

Results From the results in Table 1, we can see that: (i) The vanilla aggregation method, AGG is a strong competitor compared to several prior published methods, as is DANN, which is newly identified by us as an effective DG algorithm. (ii) Overall our Epi-FCR performs best, improving 2.4% on AGG, and 1.1% on prior state-of-the-art MMD-AAE. (iii) Particularly in view 1&2 our method achieves new state-of-the art performance.

结果 从表1中的结果，我们可以看到:(i)普通聚合方法AGG与几种先前发表的方法相比是一个强劲的竞争对手，DANN也是如此，我们新发现它是一种有效的领域泛化算法。(ii)总体而言，我们的Epi - FCR表现最佳，比AGG提高了2.4%，比先前的最先进方法MMD - AAE提高了1.1%。(iii)特别是在视角1和2中，我们的方法达到了新的最先进性能。

### 4.3. Evaluation on VLCS dataset

### 4.3. 在VLCS数据集上的评估

Settings VLCS domains share 5 categories: bird, car, chair, dog and person. We use pre-extracted DeCAF6 features and follow [26] to randomly split each domain into train (70%) and test (30%) and do leave-one-out evaluation. We use a 2 fully connected layer architecture with output size of 1024 and 128 with ReLU activation, as per [26] and report the average performance of 20 trials. The optimizer is M-SGD with learning rate 1e-3, momentum 0.9 and weight decay 5e-5. We use ${\lambda }_{1} = {7.0},{\lambda }_{2} = {5.0}$ , and ${\lambda }_{3} = {0.5}$ .

设置:VLCS数据集的各个领域共有5个类别:鸟类、汽车、椅子、狗和人。我们使用预先提取的DeCAF6特征，并按照文献[26]的方法将每个领域随机划分为训练集(70%)和测试集(30%)，并进行留一法评估。我们采用一个具有两个全连接层的架构，输出大小分别为1024和128，并使用ReLU激活函数，具体参照文献[26]，并报告20次试验的平均性能。优化器采用M - SGD，学习率为1e - 3，动量为0.9，权重衰减为5e - 5。我们使用${\lambda }_{1} = {7.0},{\lambda }_{2} = {5.0}$和${\lambda }_{3} = {0.5}$。

Results From the results in Table 2, we can see that: (i) The simple AGG baseline is again competitive with many published alternatives, so is DANN. (ii) Our Epi-FCR method achieves the best performance, improving on AGG by 1.7% and performing comparably to prior state-of-the-art MMD-AAE and MLDG with ${0.6}\%$ improvement over both.

结果:从表2中的结果可以看出:(i)简单的AGG基线方法再次与许多已发表的方法具有竞争力，DANN方法也是如此。(ii)我们的Epi - FCR方法取得了最佳性能，比AGG方法提高了1.7%，并且与先前的最先进方法MMD - AAE和MLDG表现相当，对这两种方法都有${0.6}\%$的提升。

### 4.4. Evaluation on PACS dataset

### 4.4. 在PACS数据集上的评估

Settings PACS is a recent dataset with different object style depictions, and a more challenging domain shift than VLCS, as shown in [17]. This dataset shares 7 object categories across domains, including dog, elephant, giraffe, guitar, house, horse and person. We follow the protocol in [17] including the recommended train and validation split for fair comparison. We first follow [17] in using the ImageNet pretrained AlexNet (in Table 3) and subsequently also use a modern ImageNet pre-trained ResNet-18 (in Table 4) as a base CNN architecture. We train our network using the M-SGD optimizer (batch size/per domain=32, lr=1e-3, momentum=0.9, weight decay=5e-5) for ${45}\mathrm{k}$ iterations when using AlexNet and train our network using the same optimizer (weight decay=1e-4) for ResNet-18. We use ${\lambda }_{1} = {2.0},{\lambda }_{2} = {0.05}$ , and ${\lambda }_{3} = {0.1}$ for both settings. We use the official PACS protocol and split [17] and rerun MetaReg [1] on this split, since MetaReg did not release their protocol.

设置:PACS是一个近期的数据集，包含不同的物体风格描绘，并且如文献[17]所示，其领域偏移比VLCS更具挑战性。该数据集在各个领域共有7个物体类别，包括狗、大象、长颈鹿、吉他、房子、马和人。为了进行公平比较，我们遵循文献[17]中的协议，包括推荐的训练集和验证集划分。我们首先按照文献[17]使用在ImageNet上预训练的AlexNet(见表3)，随后也使用现代的在ImageNet上预训练的ResNet - 18(见表4)作为基础卷积神经网络架构。当使用AlexNet时，我们使用M - SGD优化器(每个领域的批量大小为32，学习率为1e - 3，动量为0.9，权重衰减为5e - 5)对网络进行${45}\mathrm{k}$次迭代训练；当使用ResNet - 18时，使用相同的优化器(权重衰减为1e - 4)进行训练。两种设置都使用${\lambda }_{1} = {2.0},{\lambda }_{2} = {0.05}$和${\lambda }_{3} = {0.1}$。由于MetaReg没有公布其协议，我们使用官方的PACS协议和划分方法[17]，并在这个划分上重新运行MetaReg [1]。

---

${}^{3}$ https://github.com/HAHA-DL/Episodic-DG

${}^{3}$ https://github.com/HAHA-DL/Episodic-DG

---

<table><tr><td>Source</td><td>Target</td><td>DICA [27]</td><td>LRE-SVM [39]</td><td>D-MTAE [12]</td><td>CCSA [26]</td><td>MMD-AAE [20]</td><td>DANN [11]</td><td>MLDG [18]</td><td>CrossGrad [33]</td><td>MetaReg [1]</td><td>AGG</td><td>Epi-FCR</td></tr><tr><td>0,1,2,3</td><td>4</td><td>61.5</td><td>75.8</td><td>78.0</td><td>75.8</td><td>79.1</td><td>75.0</td><td>70.7</td><td>71.6</td><td>74.2</td><td>73.1</td><td>76.9</td></tr><tr><td>0,1,2,4</td><td>3</td><td>72.5</td><td>86.9</td><td>92.3</td><td>92.3</td><td>94.5</td><td>94.1</td><td>93.6</td><td>93.8</td><td>94.0</td><td>94.2</td><td>94.8</td></tr><tr><td>0,1,3,4</td><td>2</td><td>74.7</td><td>84.5</td><td>91.2</td><td>94.5</td><td>95.6</td><td>97.3</td><td>97.5</td><td>95.7</td><td>96.9</td><td>95.7</td><td>99.0</td></tr><tr><td>0,2,3,4</td><td>1</td><td>67.0</td><td>83.4</td><td>90.1</td><td>91.2</td><td>93.4</td><td>95.4</td><td>95.4</td><td>94.2</td><td>97.0</td><td>95.7</td><td>98.0</td></tr><tr><td>1,2,3,4</td><td>0</td><td>71.4</td><td>92.3</td><td>93.4</td><td>96.7</td><td>96.7</td><td>95.7</td><td>93.6</td><td>94.0</td><td>94.7</td><td>94.4</td><td>96.3</td></tr><tr><td>Ave.</td><td/><td>69.4</td><td>84.6</td><td>87.0</td><td>90.1</td><td>91.9</td><td>91.5</td><td>90.2</td><td>89.9</td><td>91.4</td><td>90.6</td><td>93.0</td></tr></table>

<table><tbody><tr><td>源</td><td>目标</td><td>差异不变因果分析(DICA) [27]</td><td>局部风险估计支持向量机(LRE - SVM) [39]</td><td>深度多任务对抗编码器(D - MTAE) [12]</td><td>联合分布自适应(CCSA) [26]</td><td>最大均值差异对抗自编码器(MMD - AAE) [20]</td><td>对抗域适应网络(DANN) [11]</td><td>多任务学习域泛化(MLDG) [18]</td><td>交叉梯度(CrossGrad) [33]</td><td>元正则化(MetaReg) [1]</td><td>聚合</td><td>流行病特征对比正则化(Epi - FCR)</td></tr><tr><td>0,1,2,3</td><td>4</td><td>61.5</td><td>75.8</td><td>78.0</td><td>75.8</td><td>79.1</td><td>75.0</td><td>70.7</td><td>71.6</td><td>74.2</td><td>73.1</td><td>76.9</td></tr><tr><td>0,1,2,4</td><td>3</td><td>72.5</td><td>86.9</td><td>92.3</td><td>92.3</td><td>94.5</td><td>94.1</td><td>93.6</td><td>93.8</td><td>94.0</td><td>94.2</td><td>94.8</td></tr><tr><td>0,1,3,4</td><td>2</td><td>74.7</td><td>84.5</td><td>91.2</td><td>94.5</td><td>95.6</td><td>97.3</td><td>97.5</td><td>95.7</td><td>96.9</td><td>95.7</td><td>99.0</td></tr><tr><td>0,2,3,4</td><td>1</td><td>67.0</td><td>83.4</td><td>90.1</td><td>91.2</td><td>93.4</td><td>95.4</td><td>95.4</td><td>94.2</td><td>97.0</td><td>95.7</td><td>98.0</td></tr><tr><td>1,2,3,4</td><td>0</td><td>71.4</td><td>92.3</td><td>93.4</td><td>96.7</td><td>96.7</td><td>95.7</td><td>93.6</td><td>94.0</td><td>94.7</td><td>94.4</td><td>96.3</td></tr><tr><td>平均值</td><td></td><td>69.4</td><td>84.6</td><td>87.0</td><td>90.1</td><td>91.9</td><td>91.5</td><td>90.2</td><td>89.9</td><td>91.4</td><td>90.6</td><td>93.0</td></tr></tbody></table>

Table 1: Cross-view action recognition results (accuracy. %) on IXMAS dataset. Best result in bold.

表1:IXMAS数据集上的跨视角动作识别结果(准确率，%)。最佳结果以粗体显示。

<table><tr><td>Source</td><td>Target</td><td>DICA [27]</td><td>LRE-SVM [39]</td><td>D-MTAE [12]</td><td>CCSA [26]</td><td>MMD-AAE [20]</td><td>DANN [11]</td><td>MLDG [18]</td><td>CrossGrad [33]</td><td>MetaReg [1]</td><td>AGG</td><td>Epi-FCR</td></tr><tr><td>L, C, S</td><td>V</td><td>63.7</td><td>60.6</td><td>63.9</td><td>67.1</td><td>67.7</td><td>66.4</td><td>67.7</td><td>65.5</td><td>65.0</td><td>65.4</td><td>67.1</td></tr><tr><td>V, C, S</td><td>L</td><td>58.2</td><td>59.7</td><td>60.1</td><td>62.1</td><td>62.6</td><td>64.0</td><td>61.3</td><td>60.0</td><td>60.2</td><td>60.6</td><td>64.3</td></tr><tr><td>V, L, S</td><td>C</td><td>79.7</td><td>88.1</td><td>89.1</td><td>92.3</td><td>94.4</td><td>92.6</td><td>94.4</td><td>92.0</td><td>92.3</td><td>93.1</td><td>94.1</td></tr><tr><td>V, L, C</td><td>S</td><td>61.0</td><td>54.9</td><td>61.3</td><td>59.1</td><td>64.4</td><td>63.6</td><td>65.9</td><td>64.7</td><td>64.2</td><td>65.8</td><td>65.9</td></tr><tr><td colspan="2">Ave.</td><td>65.7</td><td>65.8</td><td>68.6</td><td>70.2</td><td>72.3</td><td>71.7</td><td>72.3</td><td>70.5</td><td>70.4</td><td>71.2</td><td>72.9</td></tr></table>

<table><tbody><tr><td>源</td><td>目标</td><td>差异不变因果分析(DICA) [27]</td><td>局部风险估计支持向量机(LRE - SVM) [39]</td><td>深度多任务对抗自编码器(D - MTAE) [12]</td><td>联合分布自适应(CCSA) [26]</td><td>最大均值差异对抗自编码器(MMD - AAE) [20]</td><td>对抗域适应网络(DANN) [11]</td><td>多任务学习域泛化(MLDG) [18]</td><td>交叉梯度(CrossGrad) [33]</td><td>元正则化(MetaReg) [1]</td><td>聚合(AGG)</td><td>流行病特征对比正则化(Epi - FCR)</td></tr><tr><td>大(L)、中(C)、小(S)</td><td>V</td><td>63.7</td><td>60.6</td><td>63.9</td><td>67.1</td><td>67.7</td><td>66.4</td><td>67.7</td><td>65.5</td><td>65.0</td><td>65.4</td><td>67.1</td></tr><tr><td>非常大(V)、中(C)、小(S)</td><td>L</td><td>58.2</td><td>59.7</td><td>60.1</td><td>62.1</td><td>62.6</td><td>64.0</td><td>61.3</td><td>60.0</td><td>60.2</td><td>60.6</td><td>64.3</td></tr><tr><td>非常大(V)、大(L)、小(S)</td><td>C</td><td>79.7</td><td>88.1</td><td>89.1</td><td>92.3</td><td>94.4</td><td>92.6</td><td>94.4</td><td>92.0</td><td>92.3</td><td>93.1</td><td>94.1</td></tr><tr><td>非常大(V)、大(L)、中(C)</td><td>S</td><td>61.0</td><td>54.9</td><td>61.3</td><td>59.1</td><td>64.4</td><td>63.6</td><td>65.9</td><td>64.7</td><td>64.2</td><td>65.8</td><td>65.9</td></tr><tr><td colspan="2">平均值(Ave.)</td><td>65.7</td><td>65.8</td><td>68.6</td><td>70.2</td><td>72.3</td><td>71.7</td><td>72.3</td><td>70.5</td><td>70.4</td><td>71.2</td><td>72.9</td></tr></tbody></table>

Table 2: Cross-dataset object recognition results (accuracy. %) on VLCS benchmark. Best in bold.

表2:VLCS基准上的跨数据集目标识别结果(准确率，%)。最佳结果以粗体显示。

Results From the AlexNet results in Table 3, we can see that: (i) Our episodic method obtained the best performance on held out domains $\mathrm{C}$ and $\mathrm{S}$ and comparable performance on A, P domains. (ii) It also achieves the best performance overall, with ${3.3}\%$ improvement on vanilla AGG, and at least ${1.7}\%$ improvement on prior state-of-the-art methods MLDG [18], Fusion [24] and MetaReg [1].

结果 从表3中的AlexNet结果，我们可以看出:(i)我们的情景式方法在保留域$\mathrm{C}$和$\mathrm{S}$上取得了最佳性能，在A、P域上取得了相当的性能。(ii)它在整体上也取得了最佳性能，相较于普通的AGG方法有${3.3}\%$的提升，相较于先前的最先进方法MLDG [18]、Fusion [24]和MetaReg [1]至少有${1.7}\%$的提升。

Meanwhile in Table 4, we see that with a modern ResNet-18 architecture, the basic results are improved across the board as expected. However our full episodic method maintains the best performance overall, with a 2.4% improvement on AGG.

同时，在表4中，我们看到使用现代的ResNet - 18架构时，基本结果如预期的那样全面提升。然而，我们完整的情景式方法在整体上仍保持最佳性能，相较于AGG方法有2.4%的提升。

We note here that when using modern architectures like $\left\lbrack  {{35},{13}}\right\rbrack$ for DG tasks we need to be careful with batch normalization [14]. Batchnorm accumulates statistics of the training data during training, for use at testing. In DG, the source and target domains have domain-shift between them, so different ways of employing batch norm produce different results. We tried two ways of coping with batch norm, one is directly using frozen pre-trained ImageNet statistics. Another is to unfreeze and accumulate statistics from the source domains. We observed that when training ResNet-18 on PACS with accumulating the statistics from source domains it produced a worse accuracy than freezing ImageNet statistics (75.7% vs 79.1%).

我们在此指出，当使用像$\left\lbrack  {{35},{13}}\right\rbrack$这样的现代架构进行领域泛化(DG)任务时，我们需要谨慎处理批量归一化(batch normalization)[14]。批量归一化在训练期间累积训练数据的统计信息，以供测试时使用。在领域泛化中，源域和目标域之间存在领域偏移，因此采用批量归一化的不同方式会产生不同的结果。我们尝试了两种处理批量归一化的方法，一种是直接使用冻结的预训练ImageNet统计信息。另一种是解冻并从源域累积统计信息。我们观察到，在PACS数据集上训练ResNet - 18时，从源域累积统计信息得到的准确率比冻结ImageNet统计信息的准确率低(75.7%对79.1%)。

### 4.5. Further Analysis and Insights

### 4.5. 进一步分析与见解

Ablation Study To understand the contribution of each component of our model, we perform an ablation study using PACS-AlexNet shown in Fig. 6a. Episodic training for the feature extractor, gives a 1.6% boost over the vanilla AGG. Including episodic training of the classifier, further improves 0.5%. Finally, combine all the episodic training components, provides ${3.3}\%$ improvement over vanilla AGG. This confirms that each component of our model contributes to final performance.

消融研究 为了理解我们模型每个组件的贡献，我们使用图6a中所示的PACS - AlexNet进行了消融研究。特征提取器的情景式训练相较于普通的AGG方法提升了1.6%。包括分类器的情景式训练，进一步提升了0.5%。最后，结合所有情景式训练组件，相较于普通的AGG方法有${3.3}\%$的提升。这证实了我们模型的每个组件都对最终性能有贡献。

![0195d2b5-80fd-7da4-aedb-67e863c93e2a_5_909_720_678_241_0.jpg](images/0195d2b5-80fd-7da4-aedb-67e863c93e2a_5_909_720_678_241_0.jpg)

Figure 5: Cross-domain test accuracy on PACS (AlexNet) with shared feature extractor or classifier. $\mathrm{A} \mapsto  \mathrm{C}$ means, feed $\mathrm{A}$ data through C-specific module. Eg, left: ${\mathbf{x}}_{A} \mapsto  \theta  \mapsto  {\psi }_{C}$ , right: ${\mathbf{x}}_{A} \mapsto  {\theta }_{C} \mapsto  \psi$ .

图5:在PACS数据集(AlexNet)上使用共享特征提取器或分类器的跨域测试准确率。$\mathrm{A} \mapsto  \mathrm{C}$表示，将$\mathrm{A}$数据输入特定于C的模块。例如，左:${\mathbf{x}}_{A} \mapsto  \theta  \mapsto  {\psi }_{C}$，右:${\mathbf{x}}_{A} \mapsto  {\theta }_{C} \mapsto  \psi$。

Cross-Domain Testing Analysis To understand how our Epi-FCR method obtains its improved robustness to domain shift, we study its impact on cross-domain testing. Recall that when we activate the episodic training of the agnostic feature extractor and classifier, we benefit from the domain specific branches by routing domain $i$ data across domain $j$ branches. E.g., we feed: ${\mathbf{x}}_{i} \mapsto  \theta  \mapsto  {\psi }_{j} \mapsto  {y}_{i}$ to train Eq. 3, and ${\mathbf{x}}_{i} \mapsto  {\theta }_{j} \mapsto  \psi  \mapsto  {y}_{i}$ to train Eq. 4.

跨域测试分析 为了理解我们的Epi - FCR方法如何提高对领域偏移的鲁棒性，我们研究了它对跨域测试的影响。回想一下，当我们激活与领域无关的特征提取器和分类器的情景式训练时，我们通过将领域$i$的数据路由到领域$j$的分支来从特定领域的分支中受益。例如，我们输入:${\mathbf{x}}_{i} \mapsto  \theta  \mapsto  {\psi }_{j} \mapsto  {y}_{i}$来训练公式3，输入${\mathbf{x}}_{i} \mapsto  {\theta }_{j} \mapsto  \psi  \mapsto  {y}_{i}$来训练公式4。

Therefore it is natural to evaluate cross-domain testing after training the models. As illustrated in Fig. 5, we can see that the episodic training strategy indeed improves cross-domain testing performance. For example, when we feed domain $A$ data to domain $C$ classifier ${\mathbf{x}}_{A} \mapsto  \theta  \mapsto  {\psi }_{C} \mapsto  {y}_{A}$ , the Episodic-trained agnostic extractor $\theta$ improves the performance of the domain-C classifier who has never experienced domain A data (Fig. 5, left); and similarly for the Episodic-trained agnostic classifier.

因此，在训练模型后评估跨域测试是很自然的。如图5所示，我们可以看到情景式训练策略确实提高了跨域测试性能。例如，当我们将领域$A$的数据输入到领域$C$的分类器${\mathbf{x}}_{A} \mapsto  \theta  \mapsto  {\psi }_{C} \mapsto  {y}_{A}$时，经过情景式训练的与领域无关的提取器$\theta$提高了从未见过领域A数据的领域C分类器的性能(图5，左)；对于经过情景式训练的与领域无关的分类器也是如此。

Analysis of Solution Robustness In the above experiments we confirmed that our episodic model outperforms the strong AGG baseline in a variety of benchmarks, and that each component of our framework contributes. In terms of analysing the mechanism by which episodic training improves robustness to domain shift, one possible route is through leading the model to find a higher quality minima. Several studies recently have analysed learning algorithm variants in terms of the quality of the minima that they leads a model to $\left\lbrack  {{15},5}\right\rbrack$ .

解决方案鲁棒性分析 在上述实验中，我们证实了我们的情景式模型在各种基准测试中优于强大的AGG基线，并且我们框架的每个组件都有贡献。在分析情景式训练提高对领域偏移鲁棒性的机制方面，一种可能的途径是引导模型找到更高质量的极小值。最近有几项研究从学习算法引导模型找到的极小值的质量方面分析了学习算法的变体$\left\lbrack  {{15},5}\right\rbrack$。

<table><tr><td>Source</td><td>Target</td><td>DICA [27]</td><td>D-MTAE [12]</td><td>DSN [4]</td><td>TF-CNN [17]</td><td>Fusion [24]</td><td>DANN [11]</td><td>MLDG [18]</td><td>CrossGrad [33]</td><td>MetaReg [1]</td><td>AGG</td><td>Epi-FCR</td></tr><tr><td>C, P, S</td><td>A</td><td>64.6</td><td>60.3</td><td>61.1</td><td>62.9</td><td>64.1</td><td>63.2</td><td>66.2</td><td>61.0</td><td>63.5</td><td>63.4</td><td>64.7</td></tr><tr><td>A, P, S</td><td>C</td><td>64.5</td><td>58.7</td><td>66.5</td><td>67.0</td><td>66.8</td><td>67.5</td><td>66.9</td><td>67.2</td><td>69.5</td><td>66.1</td><td>72.3</td></tr><tr><td>A, C, S</td><td>P</td><td>91.8</td><td>91.1</td><td>83.3</td><td>89.5</td><td>90.2</td><td>88.1</td><td>88.0</td><td>87.6</td><td>87.4</td><td>88.5</td><td>86.1</td></tr><tr><td>A, C, P</td><td>S</td><td>51.1</td><td>47.9</td><td>58.6</td><td>57.5</td><td>60.1</td><td>57.0</td><td>59.0</td><td>55.9</td><td>59.1</td><td>56.6</td><td>65.0</td></tr><tr><td colspan="2">Ave.</td><td>68.0</td><td>64.5</td><td>67.4</td><td>69.2</td><td>70.3</td><td>69.0</td><td>70.0</td><td>67.9</td><td>69.9</td><td>68.7</td><td>72.0</td></tr></table>

<table><tbody><tr><td>源</td><td>目标</td><td>动态实例对比对齐(DICA) [27]</td><td>深度多任务对抗嵌入(D-MTAE) [12]</td><td>深度子空间网络(DSN) [4]</td><td>时间频率卷积神经网络(TF-CNN) [17]</td><td>融合(Fusion) [24]</td><td>对抗域适应网络(DANN) [11]</td><td>多任务学习域泛化(MLDG) [18]</td><td>交叉梯度(CrossGrad) [33]</td><td>元正则化(MetaReg) [1]</td><td>聚合(AGG)</td><td>情景式特征对比正则化(Epi-FCR)</td></tr><tr><td>类别(C)、精度(P)、支持度(S)</td><td>A</td><td>64.6</td><td>60.3</td><td>61.1</td><td>62.9</td><td>64.1</td><td>63.2</td><td>66.2</td><td>61.0</td><td>63.5</td><td>63.4</td><td>64.7</td></tr><tr><td>准确率(A)、精度(P)、支持度(S)</td><td>C</td><td>64.5</td><td>58.7</td><td>66.5</td><td>67.0</td><td>66.8</td><td>67.5</td><td>66.9</td><td>67.2</td><td>69.5</td><td>66.1</td><td>72.3</td></tr><tr><td>准确率(A)、类别(C)、支持度(S)</td><td>P</td><td>91.8</td><td>91.1</td><td>83.3</td><td>89.5</td><td>90.2</td><td>88.1</td><td>88.0</td><td>87.6</td><td>87.4</td><td>88.5</td><td>86.1</td></tr><tr><td>准确率(A)、类别(C)、精度(P)</td><td>S</td><td>51.1</td><td>47.9</td><td>58.6</td><td>57.5</td><td>60.1</td><td>57.0</td><td>59.0</td><td>55.9</td><td>59.1</td><td>56.6</td><td>65.0</td></tr><tr><td colspan="2">平均值(Ave.)</td><td>68.0</td><td>64.5</td><td>67.4</td><td>69.2</td><td>70.3</td><td>69.0</td><td>70.0</td><td>67.9</td><td>69.9</td><td>68.7</td><td>72.0</td></tr></tbody></table>

Table 3: Cross-domain object recognition results (accuracy. %) of different methods on PACS using pretrained AlexNet. Best in bold.

表3:使用预训练AlexNet(亚历克斯网络)时，不同方法在PACS数据集上的跨领域目标识别结果(准确率，%)。最佳结果以粗体显示。

<table><tr><td>Source</td><td>Target</td><td>AGG</td><td>DANN [11]</td><td>MAML [9]</td><td>MLDG [18]</td><td>CrossGrad [33]</td><td>MetaReg [1]</td><td>Epi-FCR</td></tr><tr><td>C, PS</td><td>A</td><td>77.6</td><td>81.3</td><td>78.3</td><td>79.5</td><td>78.7</td><td>79.5</td><td>82.1</td></tr><tr><td>A.PS</td><td>C</td><td>73.9</td><td>73.8</td><td>76.5</td><td>77.3</td><td>73.3</td><td>75.4</td><td>77.0</td></tr><tr><td>A, C, S</td><td>P</td><td>94.4</td><td>94.0</td><td>95.1</td><td>94.3</td><td>94.0</td><td>94.3</td><td>93.9</td></tr><tr><td>A, C, P</td><td>S</td><td>70.3</td><td>74.3</td><td>72.6</td><td>71.5</td><td>65.1</td><td>72.2</td><td>73.0</td></tr><tr><td colspan="2">Ave.</td><td>79.1</td><td>80.8</td><td>80.6</td><td>80.7</td><td>77.8</td><td>80.4</td><td>81.5</td></tr></table>

<table><tbody><tr><td>源域</td><td>目标域</td><td>聚合(AGG)</td><td>对抗性领域适应网络(DANN) [11]</td><td>模型无关元学习(MAML) [9]</td><td>元学习领域泛化(MLDG) [18]</td><td>交叉梯度(CrossGrad) [33]</td><td>元正则化(MetaReg) [1]</td><td>情景式特征对比正则化(Epi - FCR)</td></tr><tr><td>类别、原型集(C, PS)</td><td>A</td><td>77.6</td><td>81.3</td><td>78.3</td><td>79.5</td><td>78.7</td><td>79.5</td><td>82.1</td></tr><tr><td>属性、原型集(A.PS)</td><td>C</td><td>73.9</td><td>73.8</td><td>76.5</td><td>77.3</td><td>73.3</td><td>75.4</td><td>77.0</td></tr><tr><td>属性、类别、样本(A, C, S)</td><td>P</td><td>94.4</td><td>94.0</td><td>95.1</td><td>94.3</td><td>94.0</td><td>94.3</td><td>93.9</td></tr><tr><td>属性、类别、原型(A, C, P)</td><td>S</td><td>70.3</td><td>74.3</td><td>72.6</td><td>71.5</td><td>65.1</td><td>72.2</td><td>73.0</td></tr><tr><td colspan="2">平均值(Ave.)</td><td>79.1</td><td>80.8</td><td>80.6</td><td>80.7</td><td>77.8</td><td>80.4</td><td>81.5</td></tr></tbody></table>

Table 4: Cross-domain object recognition results (accuracy. %) of different methods on PACS using ResNet-18. Best in bold.

表4:使用ResNet - 18时，不同方法在PACS数据集上的跨领域目标识别结果(准确率，%)。最佳结果以粗体显示。

One intuition is that converging to a 'wide' rather than 'sharp' minima provides a more robust solution, because perturbations (such as domain shift, in our case) are less likely to cause a big hit to accuracy if the model's performance is not dependent on a very precisely calibrated solution. Following [15, 41], we therefore compare the solutions found by AGG and our Epi-FCR by adding noise to the weights of the converged model, and observing how quickly the testing accuracy decreases with the magnitude of the noise. From Fig. 7 we can see that both models' performance drops as weights are perturbed, but our Epi-FCR model is more robust to weight perturbations. This suggests that the minima found by Epi-FCR is a more robust one than that found by AGG, which may explain the improved cross domain robustness of Epi-FCR compared to AGG.

一种直觉是，收敛到一个“宽”而非“尖”的极小值能提供更鲁棒的解决方案，因为如果模型的性能不依赖于一个经过非常精确校准的解，那么扰动(如在我们的案例中的领域偏移)就不太可能对准确率造成重大影响。因此，遵循文献[15, 41]的方法，我们通过向收敛模型的权重添加噪声，并观察测试准确率随噪声幅度下降的速度，来比较AGG和我们的Epi - FCR所找到的解。从图7中我们可以看到，当权重受到扰动时，两个模型的性能都会下降，但我们的Epi - FCR模型对权重扰动更具鲁棒性。这表明Epi - FCR找到的极小值比AGG找到的更具鲁棒性，这可能解释了与AGG相比，Epi - FCR在跨领域上鲁棒性的提升。

Computational Cost Our Episodic model is comparable in cost overall to many contemporaries. Our Epi-C variant does require training multiple feature extractors for the source domains (as do $\left\lbrack  {{16},{39},{17},{24}}\right\rbrack$ ). However, users are more practically interested in testing performance, where our model is as small, fast and simple as AGG (unlike, e.g., [39, 24]). In terms of training requirements, we note that only the Epi-C variant requires multiple feature extractor training, so Epi-FR can still safely be used if this is an issue. Furthermore if a large number of source domains are present, we can sample a subset of them at each batch.

计算成本 我们的情景式(Episodic)模型总体成本与许多同类模型相当。我们的Epi - C变体确实需要为源领域训练多个特征提取器(如$\left\lbrack  {{16},{39},{17},{24}}\right\rbrack$所示)。然而，用户实际上更关心测试性能，在这方面我们的模型和AGG一样小巧、快速且简单(与例如文献[39, 24]不同)。在训练要求方面，我们注意到只有Epi - C变体需要训练多个特征提取器，因此如果这是一个问题，仍然可以安全地使用Epi - FR。此外，如果存在大量源领域，我们可以在每个批次中对其中的一个子集进行采样。

Concretely, we compare the training time of different methods in Fig. 6b. All the methods were run on PACS (ResNet-18) for ${3k}$ iterations with CPU: Intel i7-7820 (@3.60GHz x 16) and GPU: 1080Ti. As expected vanilla AGG is the fastest to train (9.8 mins), so we regard it as the the base unit. The second tier are our Epi-F and Epi-R. As expected without Epi-C, our Epi-F and Epi-R variants run fast. The next tier are MetaReg, Epi-FCR and MLDG. And the most expensive one is CrossGrad. Although the use of 'Epi-C' here requires domain-specific feature extractors, our Epi-FCR is still comparably efficient. This is because our episodic training does not generate multi-step graph unrolling or meta-optimization in gradient updates. As a result, our time cost is on par with MetaReg [1] and faster than MLDG [18] and CrossGrad [33].

具体来说，我们在图6b中比较了不同方法的训练时间。所有方法都在PACS(ResNet - 18)上使用CPU:Intel i7 - 7820(@3.60GHz x 16)和GPU:1080Ti运行了${3k}$次迭代。正如预期的那样，普通的AGG训练速度最快(9.8分钟)，因此我们将其作为基本单位。第二梯队是我们的Epi - F和Epi - R。正如预期的那样，没有Epi - C时，我们的Epi - F和Epi - R变体运行速度很快。接下来的梯队是MetaReg、Epi - FCR和MLDG。而最耗时的是CrossGrad。虽然这里使用“Epi - C”需要特定领域的特征提取器，但我们的Epi - FCR仍然相当高效。这是因为我们的情景式训练在梯度更新中不会产生多步图展开或元优化。因此，我们的时间成本与MetaReg [1]相当，并且比MLDG [18]和CrossGrad [33]更快。

![0195d2b5-80fd-7da4-aedb-67e863c93e2a_6_908_459_689_238_0.jpg](images/0195d2b5-80fd-7da4-aedb-67e863c93e2a_6_908_459_689_238_0.jpg)

Figure 6: (a) Ablation study on PACS (↑). (b) Computational cost comparison on PACS (↓).

图6:(a) 在PACS数据集上的消融研究(↑)。(b) 在PACS数据集上的计算成本比较(↓)。

### 4.6. Evaluation on ${VD} - {DG}$ dataset

### 4.6. 在${VD} - {DG}$数据集上的评估

Heterogeneous Problem Setting Visual Decathlon contains ten datasets and was initially proposed as a multi-domain learning benchmark [29]. We re-purpose Decathlon for a more ambitious challenge of domain generalisation. As explained earlier, our motivation is find out if DG learning can improve the defacto standard 'ImageNet trained CNN feature extractor' for use as a fixed off-the-shelf representation for new target problems. In this case the feature extractor is trained on the source domain, and used to extract features of the target domain data. Then a target domain-specific classifier (we use SVM) is trained to classify in the target domain. As explained in Table 5 (left), this is quite different from the standard DG setting in that target domain labels are used (for shallow classifier training), but the focus here is on the robustness of the learned feature when generalising to represent new domains and tasks without further fine-tuning. If DG training can improve feature generalisation compared to a vanilla ImageNet CNN, this could be of major practical value given the widespread usage of this workflow by vision practitioners.

异构问题设置 视觉十项全能(Visual Decathlon)包含十个数据集，最初是作为多领域学习基准提出的[29]。我们将十项全能数据集重新用于一个更具挑战性的领域泛化任务。如前所述，我们的动机是探究领域泛化(DG)学习是否能改进事实上的标准“在ImageNet上训练的卷积神经网络(CNN)特征提取器”，使其作为一种固定的现成表示用于新的目标问题。在这种情况下，特征提取器在源领域上进行训练，并用于提取目标领域数据的特征。然后训练一个特定于目标领域的分类器(我们使用支持向量机SVM)在目标领域进行分类。如表5(左)所示，这与标准的DG设置有很大不同，因为这里使用了目标领域的标签(用于浅层分类器训练)，但这里的重点是在不进行进一步微调的情况下，所学特征在泛化以表示新领域和新任务时的鲁棒性。如果与普通的ImageNet CNN相比，DG训练能够提高特征的泛化能力，鉴于视觉领域从业者广泛使用这种工作流程，这可能具有重大的实际价值。

Besides evaluating a potentially more generally useful problem setting compared to standard homogeneous DG, our VD experiment is also a larger scale evaluation compared to existing DG studies. As shown in Table 5 (right), VD-DG has twice the domains of VLCS and PACS and is an order of magnitude larger evaluation in terms of data and category numbers.

除了评估一个与标准的同构DG相比可能更具普遍实用性的问题设置外，我们的VD实验与现有的DG研究相比也是一个更大规模的评估。如表5(右)所示，VD - DG的领域数量是VLCS和PACS的两倍，并且在数据和类别数量方面的评估规模要大一个数量级。

Settings We consider five larger datasets in VD (CIFAR-100, Daimler Ped, GTSRB, Omniglot and SVHN) as our source domains, and the four smallest datasets (Aircraft, D. Textures, VGG-Flowers and UCF101) as our target domains. The goal is to use DG training among the source datasets to learn a feature which outperforms the off-the-shelf ImageNet-trained CNN that we use as an initial condition. We use ResNet-18 [13] as the backbone model, and resize all images to ${64} \times  {64}$ for computational efficiency. To support the VD heterogeneous label space, we assume a shared feature extractor, and a source domain-specific classifier. We perform episodic DG training among the source domains, using our (R)andom classifier model variant, which supports heterogeneous label-spaces. After DG training, the model will then be used as a fixed feature extractor for the held out target domains. With regards to use of ImageNet during training, we consider two settings: (i) Use ImageNet CNN as initial condition, but exclude ImageNet data from DG training, (ii) Include ImageNet as a sixth source domain for DG training. The former helps to constrain training cost, but loses some performance due to the forgetting effect. Therefore we combine (concatenation and mean-pooling) the original ImageNet pre-trained features with the VD-DG trained features. In each case the final feature is used to train a linear SVM for the corresponding task, as per common practice. We train the network using the M-SGD optimizer (batch size/per domain=32, lr=1e-3, momentum=0.9, weight decay=1e-4) for ${100}\mathrm{k}$ iterations where the $\operatorname{lr}$ is decayed in ${40}\mathrm{k},{80}\mathrm{k}$ iterations by a factor 10 . We set ${\lambda }_{3} = \frac{2.5}{t + {50}}, t$ is the iteration num.

设置 我们将视觉领域(VD)中的五个较大数据集(CIFAR - 100、戴姆勒行人数据集(Daimler Ped)、德国交通标志识别基准数据集(GTSRB)、Omniglot 数据集和街景门牌号数据集(SVHN))作为源领域，将四个最小的数据集(飞机数据集(Aircraft)、Describable 纹理数据集(D. Textures)、VGG 花卉数据集(VGG - Flowers)和 UCF101 数据集)作为目标领域。目标是在源数据集之间进行领域泛化(DG)训练，以学习一种特征，使其性能优于我们作为初始条件使用的现成的在 ImageNet 上预训练的卷积神经网络(CNN)。我们使用 ResNet - 18 [13] 作为骨干模型，并为了计算效率将所有图像调整为 ${64} \times  {64}$ 大小。为了支持视觉领域的异构标签空间，我们假设使用一个共享的特征提取器和一个特定于源领域的分类器。我们使用支持异构标签空间的(随机)分类器模型变体，在源领域之间进行情景式领域泛化训练。领域泛化训练完成后，该模型将作为固定的特征提取器用于保留的目标领域。关于训练期间 ImageNet 的使用，我们考虑两种设置:(i)使用在 ImageNet 上预训练的 CNN 作为初始条件，但在领域泛化训练中排除 ImageNet 数据；(ii)将 ImageNet 作为第六个源领域纳入领域泛化训练。前者有助于控制训练成本，但由于遗忘效应会损失一些性能。因此，我们将原始的 ImageNet 预训练特征与视觉领域 - 领域泛化(VD - DG)训练得到的特征进行组合(拼接和平均池化)。在每种情况下，按照惯例，最终特征用于训练对应任务的线性支持向量机(SVM)。我们使用 M - SGD 优化器(每个领域的批量大小 = 32，学习率 = 1e - 3，动量 = 0.9，权重衰减 = 1e - 4)对网络进行 ${100}\mathrm{k}$ 次迭代训练，其中 $\operatorname{lr}$ 在 ${40}\mathrm{k},{80}\mathrm{k}$ 次迭代中衰减为原来的 1/10。我们设 ${\lambda }_{3} = \frac{2.5}{t + {50}}, t$ 为迭代次数。

![0195d2b5-80fd-7da4-aedb-67e863c93e2a_7_177_214_1394_248_0.jpg](images/0195d2b5-80fd-7da4-aedb-67e863c93e2a_7_177_214_1394_248_0.jpg)

Figure 7: Minima quality analysis: Episodic training (Epi-FCR) vs baseline (AGG).

图 7:极小值质量分析:情景式训练(Epi - FCR)与基线(AGG)对比。

<table><tr><td rowspan="2">Setting</td><td colspan="2">Updated in Target Domain?</td><td rowspan="2">Novel Target Labels?</td></tr><tr><td>Feature Extractor</td><td>Classifier</td></tr><tr><td>Homogeneous DG</td><td>$\mathrm{N}$</td><td>$\mathrm{N}$</td><td>$\mathrm{N}$</td></tr><tr><td>Heterogeneous DG</td><td>$\mathrm{N}$</td><td>Y</td><td>Y</td></tr></table>

<table><tbody><tr><td rowspan="2">设置</td><td colspan="2">是否在目标领域中更新？</td><td rowspan="2">是否有新的目标标签？</td></tr><tr><td>特征提取器</td><td>分类器</td></tr><tr><td>同质分布泛化(Homogeneous DG)</td><td>$\mathrm{N}$</td><td>$\mathrm{N}$</td><td>$\mathrm{N}$</td></tr><tr><td>异质分布泛化(Heterogeneous DG)</td><td>$\mathrm{N}$</td><td>Y</td><td>Y</td></tr></tbody></table>

<table><tr><td>Benchmark</td><td>#of data</td><td>#of Domains</td><td>#of tasks</td><td>task space</td></tr><tr><td>VLCS</td><td>10,729</td><td>4</td><td>5</td><td>Homo.</td></tr><tr><td>PACS</td><td>9,991</td><td>4</td><td>7</td><td>Homo.</td></tr><tr><td>VD-DG</td><td>238,215</td><td>9</td><td>2128</td><td>Hetero.</td></tr></table>

<table><tbody><tr><td>基准(Benchmark)</td><td>数据数量(#of data)</td><td>领域数量(#of Domains)</td><td>任务数量(#of tasks)</td><td>任务空间(task space)</td></tr><tr><td>视觉语言跨模态场景(VLCS)</td><td>10,729</td><td>4</td><td>5</td><td>同质性(Homo.)</td></tr><tr><td>照片标注分类集(PACS)</td><td>9,991</td><td>4</td><td>7</td><td>同质性(Homo.)</td></tr><tr><td>视觉领域自适应与分布泛化(VD - DG)</td><td>238,215</td><td>9</td><td>2128</td><td>异质性(Hetero.)</td></tr></tbody></table>

Table 5: Left: Difference between conventional homogeneous DG setting and new heterogeneous DG setting. Right: Contrasting the larger scale of our VD-DG (excluding ImageNet) vs previous DG benchmarks.

表5:左:传统同质领域泛化(DG)设置与新的异质领域泛化(DG)设置之间的差异。右:对比我们的视觉领域泛化(VD - DG，不包括ImageNet)与先前领域泛化基准的更大规模。

<table><tr><td rowspan="2">Target</td><td rowspan="2">ImageNet PT</td><td colspan="3">MLDG [18]</td><td colspan="3">CrossGrad [33]</td><td colspan="3">AGG</td><td colspan="3">DANN [11]</td><td colspan="3">Epi-R</td></tr><tr><td>Concat</td><td>Mean</td><td>Combine</td><td>Concat</td><td>Mean</td><td>Combine</td><td>Concat</td><td>Mean</td><td>Combine</td><td>Concat</td><td>Mean</td><td>Combine</td><td>Concat</td><td>Mean</td><td>Combine</td></tr><tr><td>Aircraft</td><td>12.7</td><td>17.4</td><td>14.2</td><td>15.7</td><td>17.2</td><td>13.7</td><td>15.9</td><td>17.4</td><td>14.6</td><td>15.7</td><td>17.4</td><td>15.0</td><td>16.0</td><td>17.7</td><td>13.9</td><td>15.5</td></tr><tr><td>D. Textures</td><td>35.2</td><td>38.3</td><td>34.6</td><td>32.5</td><td>34.6</td><td>31.4</td><td>32.2</td><td>37.7</td><td>35.1</td><td>31.5</td><td>37.9</td><td>36.6</td><td>33.0</td><td>40.2</td><td>37.8</td><td>33.9</td></tr><tr><td>VGG-Flowers</td><td>48.1</td><td>54.0</td><td>53.2</td><td>54.4</td><td>49.2</td><td>49.3</td><td>54.9</td><td>56.3</td><td>52.0</td><td>57.0</td><td>55.5</td><td>52.2</td><td>53.7</td><td>55.4</td><td>53.0</td><td>55.9</td></tr><tr><td>UCF101</td><td>35.0</td><td>44.4</td><td>36.7</td><td>34.9</td><td>42.7</td><td>35.7</td><td>35.2</td><td>43.3</td><td>35.0</td><td>36.1</td><td>44.5</td><td>36.1</td><td>33.9</td><td>45.7</td><td>37.1</td><td>37.3</td></tr><tr><td>Ave.</td><td>32.8</td><td>38.5</td><td>34.7</td><td>34.4</td><td>35.9</td><td>32.5</td><td>34.6</td><td>38.7</td><td>34.2</td><td>35.1</td><td>38.8</td><td>35.0</td><td>34.1</td><td>39.7</td><td>35.5</td><td>35.7</td></tr><tr><td>VD-Score</td><td>185</td><td>279</td><td>194</td><td>169</td><td>241</td><td>169</td><td>169</td><td>265</td><td>185</td><td>172</td><td>277</td><td>202</td><td>165</td><td>304</td><td>217</td><td>194</td></tr></table>

<table><tbody><tr><td rowspan="2">目标</td><td rowspan="2">ImageNet预训练(ImageNet PT)</td><td colspan="3">多任务学习领域泛化(MLDG) [18]</td><td colspan="3">交叉梯度(CrossGrad) [33]</td><td colspan="3">聚合(AGG)</td><td colspan="3">对抗域适应网络(DANN) [11]</td><td colspan="3">情景式正则化(Epi - R)</td></tr><tr><td>拼接(Concat)</td><td>均值(Mean)</td><td>组合(Combine)</td><td>拼接(Concat)</td><td>均值(Mean)</td><td>组合(Combine)</td><td>拼接(Concat)</td><td>均值(Mean)</td><td>组合(Combine)</td><td>拼接(Concat)</td><td>均值(Mean)</td><td>组合(Combine)</td><td>拼接(Concat)</td><td>均值(Mean)</td><td>组合(Combine)</td></tr><tr><td>飞机</td><td>12.7</td><td>17.4</td><td>14.2</td><td>15.7</td><td>17.2</td><td>13.7</td><td>15.9</td><td>17.4</td><td>14.6</td><td>15.7</td><td>17.4</td><td>15.0</td><td>16.0</td><td>17.7</td><td>13.9</td><td>15.5</td></tr><tr><td>动态纹理(D. Textures)</td><td>35.2</td><td>38.3</td><td>34.6</td><td>32.5</td><td>34.6</td><td>31.4</td><td>32.2</td><td>37.7</td><td>35.1</td><td>31.5</td><td>37.9</td><td>36.6</td><td>33.0</td><td>40.2</td><td>37.8</td><td>33.9</td></tr><tr><td>VGG花卉数据集(VGG - Flowers)</td><td>48.1</td><td>54.0</td><td>53.2</td><td>54.4</td><td>49.2</td><td>49.3</td><td>54.9</td><td>56.3</td><td>52.0</td><td>57.0</td><td>55.5</td><td>52.2</td><td>53.7</td><td>55.4</td><td>53.0</td><td>55.9</td></tr><tr><td>UCF101数据集</td><td>35.0</td><td>44.4</td><td>36.7</td><td>34.9</td><td>42.7</td><td>35.7</td><td>35.2</td><td>43.3</td><td>35.0</td><td>36.1</td><td>44.5</td><td>36.1</td><td>33.9</td><td>45.7</td><td>37.1</td><td>37.3</td></tr><tr><td>平均值(Ave.)</td><td>32.8</td><td>38.5</td><td>34.7</td><td>34.4</td><td>35.9</td><td>32.5</td><td>34.6</td><td>38.7</td><td>34.2</td><td>35.1</td><td>38.8</td><td>35.0</td><td>34.1</td><td>39.7</td><td>35.5</td><td>35.7</td></tr><tr><td>视觉多样性得分(VD - Score)</td><td>185</td><td>279</td><td>194</td><td>169</td><td>241</td><td>169</td><td>169</td><td>265</td><td>185</td><td>172</td><td>277</td><td>202</td><td>165</td><td>304</td><td>217</td><td>194</td></tr></tbody></table>

Table 6: Results of top-1 accuracy (%) and visual decathlon overall scores of different methods on VD-DG. Train on CIFAR-100, Daimler Ped, GTSRB, Omniglot, SVHN, and optionally ImageNet (Combine). Test on Aircraft, D. Textures, VGG-Flowers, UCF101.

表6:不同方法在VD - DG上的前1准确率(%)和视觉十项全能总体得分结果。在CIFAR - 100、戴姆勒行人数据集(Daimler Ped)、德国交通标志识别基准数据集(GTSRB)、Omniglot、街景门牌号数据集(SVHN)上进行训练，可选择加入ImageNet(组合)。在飞机数据集(Aircraft)、DTD纹理数据集(D. Textures)、VGG花卉数据集(VGG - Flowers)、UCF101数据集上进行测试。

Results From the results in Table 6, we observed that: (i) All methods use the extra data in VD to improve on the initial features ('ImageNet PT'). (ii) In terms of other DG competitors: Only MLDG, CrossGrad, and DANN were feasible to run on the scale of VD; with others either not supporting heterogeneous label-spaces or scaling to this many domains/examples. (iii) Our Epi-R improves on the strong AGG baseline and DG competitors in both average accuracy, and also the VD score recommended in preference to accuracy in [29]. This demonstrates the value of our Episodic training in learning a feature that is robust to novel domains. (iv) Our concatenation strategy provided the best overall performance compared to directly including ImageNet as a source domain (‘Combine’). This partly due to using a fixed ${100}\mathrm{k}$ iterations to constrain training time. With enough training, the latter option is likely to be best. Overall this is the first demonstration that any DG method can improve robustness to domain shift in a larger-scale setting, across heterogeneous domains, and make a practical impact in surpassing ImageNet feature performance ${}^{4}$ .

结果 从表6中的结果，我们观察到:(i)所有方法都使用视觉十项全能数据集(VD)中的额外数据来改进初始特征(“ImageNet预训练”)。(ii)就其他领域泛化(DG)竞争方法而言:只有元学习领域泛化(MLDG)、交叉梯度(CrossGrad)和对抗域适应(DANN)方法能够在VD规模上运行；其他方法要么不支持异构标签空间，要么无法扩展到如此多的领域/示例。(iii)我们提出的情景式训练改进方法(Epi - R)在平均准确率和[29]中推荐的优于准确率的VD得分方面，都优于强大的聚合(AGG)基线方法和其他DG竞争方法。这证明了我们的情景式训练在学习对新领域具有鲁棒性的特征方面的价值。(iv)与直接将ImageNet作为源领域(“组合”)相比，我们的拼接策略提供了最佳的整体性能。这部分是由于使用了固定的${100}\mathrm{k}$次迭代来限制训练时间。如果有足够的训练，后一种选择可能是最佳的。总体而言，这是首次证明任何DG方法都可以在更大规模的设置中、跨异构领域提高对领域偏移的鲁棒性，并在超越ImageNet特征性能方面产生实际影响${}^{4}$。

## 5. Conclusion

## 5. 结论

We addressed the domain generalisation problem by proposing a simple episodic training strategy that mimics train-test domain-shift during training, thus improving the trained model's robustness to novel domains. We showed that our method achieves state-of-the-art performance on all the main existing DG benchmarks. We also performed the largest DG evaluation to date, using the Visual Decathlon benchmark. Importantly, we provided the first demonstration of DG's potential value 'in the wild' - by demonstrating our model's potential to improve the performance of the defacto standard ImageNet pre-trained CNN as a fixed feature extractor for novel downstream problems.

我们通过提出一种简单的情景式训练策略来解决领域泛化问题，该策略在训练过程中模拟训练 - 测试领域偏移，从而提高训练模型对新领域的鲁棒性。我们表明，我们的方法在所有现有的主要DG基准测试中都达到了最先进的性能。我们还使用视觉十项全能基准进行了迄今为止最大规模的DG评估。重要的是，我们首次证明了DG在实际应用中的潜在价值——通过展示我们的模型有潜力改进事实上的标准ImageNet预训练卷积神经网络(CNN)作为新下游问题的固定特征提取器的性能。

---

${}^{4}$ We note one concurrent study of the heterogeneous DG setting [21] considered the VD-DG benchmark that we propose here. Their results are slightly higher due do use of a larger image size and cross-validation of SVM parameters (we use sklearn defaults).

${}^{4}$ 我们注意到一项关于异构DG设置的同期研究[21]考虑了我们在此提出的VD - DG基准。他们的结果略高，这是因为使用了更大的图像尺寸和对支持向量机(SVM)参数进行了交叉验证(我们使用scikit - learn的默认参数)。

---

## References

## 参考文献

[1] Yogesh Balaji, Swami Sankaranarayanan, and Rama Chel-lappa. Metareg: Towards domain generalization using meta-regularization. In NeurIPS, 2018. 5, 6, 7

[1] Yogesh Balaji、Swami Sankaranarayanan和Rama Chel - lappa。元正则化(Metareg):使用元正则化实现领域泛化。发表于神经信息处理系统大会(NeurIPS)，2018年。第5、6、7页

[2] Shai Ben-David, John Blitzer, Koby Crammer, and Fernando Pereira. Analysis of representations for domain adaptation. In NIPS, 2006. 1

[2] Shai Ben - David、John Blitzer、Koby Crammer和Fernando Pereira。领域适应表示分析。发表于神经信息处理系统大会(NIPS)，2006年。第1页

[3] Hakan Bilen and Andrea Vedaldi. Universal representations: The missing link between faces, text, planktons, and cat breeds. Technical report, 2017. 2

[3] Hakan Bilen和Andrea Vedaldi。通用表示:人脸、文本、浮游生物和猫品种之间缺失的联系。技术报告，2017年。第2页

[4] Konstantinos Bousmalis, George Trigeorgis, Nathan Silberman, Dilip Krishnan, and Dumitru Erhan. Domain separation networks. In ${NIPS},{2016.1},5,7$

[4] Konstantinos Bousmalis、George Trigeorgis、Nathan Silberman、Dilip Krishnan和Dumitru Erhan。领域分离网络。发表于${NIPS},{2016.1},5,7$

[5] Pratik Chaudhar, Anna Choromansk, Stefano Soatt, Yann LeCun, Carlo Baldass, Christian Borg, Jennifer Chays, Levent Sagun, and Riccardo Zecchina. Entropy-sgd: Biasing gradient descent into wide valleys. In ${ICLR},{2017.6}$

[5] Pratik Chaudhar、Anna Choromansk、Stefano Soatt、Yann LeCun、Carlo Baldass、Christian Borg、Jennifer Chays、Levent Sagun和Riccardo Zecchina。熵随机梯度下降(Entropy - sgd):将梯度下降引导至宽谷。发表于${ICLR},{2017.6}$

[6] Myung Jin Choi, Joseph Lim, and Antonio Torralba. Exploiting hierarchical context on a large database of object categories. In CVPR, 2010. 5

[6] Myung Jin Choi、Joseph Lim和Antonio Torralba。在大型目标类别数据库中利用层次上下文。发表于计算机视觉与模式识别会议(CVPR)，2010年。第5页

[7] Mark Everingham, Luc Van Gool, Christopher K. I. Williams, John Winn, and Andrew. Zisserman. The pascal visual object classes (voc) challenge. IJCV, 2010. 5

[7] Mark Everingham、Luc Van Gool、Christopher K. I. Williams、John Winn和Andrew. Zisserman。PASCAL视觉目标类别(VOC)挑战赛。发表于国际计算机视觉杂志(IJCV)，2010年。第5页

[8] Chen Fang, Ye Xu, and Daniel N. Rockmore. Unbiased metric learning: On the utilization of multiple datasets and web images for softening bias. In ${ICCV},{2013.5}$

[8] Chen Fang、Ye Xu和Daniel N. Rockmore。无偏度量学习:利用多个数据集和网络图像减轻偏差。发表于${ICCV},{2013.5}$

[9] Chelsea Finn, Pieter Abbeel, and Sergey Levine. Model-agnostic meta-learning for fast adaptation of deep networks. In ICML, 2017.1, 2, 5, 7

[9] Chelsea Finn、Pieter Abbeel和Sergey Levine。模型无关元学习用于深度网络的快速适应。发表于国际机器学习会议(ICML)，2017年。第1、2、5、7页

[10] Yaroslav Ganin and Victor Lempitsky. Unsupervised domain adaptation by backpropagation. In ${ICML},{2015.1}$

[10] Yaroslav Ganin和Victor Lempitsky。通过反向传播进行无监督领域适应。发表于${ICML},{2015.1}$

[11] Yaroslav Ganin, Evgeniya Ustinova, Hana Ajakan, Pascal Germain, Hugo Larochelle, François Laviolette, Mario Marchand, and Victor Lempitsky. Domain-adversarial training of neural networks. JMLR, 2016. 5, 6, 7, 8

[11] 亚罗斯拉夫·加宁(Yaroslav Ganin)、叶夫根尼娅·乌斯蒂诺娃(Evgeniya Ustinova)、哈娜·阿贾坎(Hana Ajakan)、帕斯卡尔·热尔曼(Pascal Germain)、雨果·拉罗谢尔(Hugo Larochelle)、弗朗索瓦·拉维奥莱特(François Laviolette)、马里奥·马尔尚(Mario Marchand)和维克多·伦皮茨基(Victor Lempitsky)。神经网络的对抗域训练。《机器学习研究杂志》(JMLR)，2016 年。5, 6, 7, 8

[12] Muhammad Ghifary, W. Bastiaan Kleijn, Mengjie Zhang, and David Balduzzi. Domain generalization for object recognition with multi-task autoencoders. In ${ICCV},{2015.1},2,5,6,7$

[12] 穆罕默德·吉法里(Muhammad Ghifary)、W. 巴斯蒂安·克莱因(W. Bastiaan Kleijn)、张梦洁(Mengjie Zhang)和大卫·巴尔杜齐(David Balduzzi)。基于多任务自编码器的目标识别领域泛化。见 ${ICCV},{2015.1},2,5,6,7$

[13] Kaiming He, Xiangyu Zhang, Shaoqing Ren, and Jian Sun. Deep residual learning for image recognition. In ${CVPR},{2016.6},7$

[13] 何恺明(Kaiming He)、张祥雨(Xiangyu Zhang)、任少卿(Shaoqing Ren)和孙剑(Jian Sun)。用于图像识别的深度残差学习。见 ${CVPR},{2016.6},7$

[14] Sergey Ioffe and Christian Szegedy. Batch normalization: Accelerating deep network training by reducing internal covariate shift. In ${ICML},{2015.6}$

[14] 谢尔盖·约菲(Sergey Ioffe)和克里斯蒂安·塞格迪(Christian Szegedy)。批量归一化:通过减少内部协变量偏移加速深度网络训练。见 ${ICML},{2015.6}$

[15] Nitish Shirish Keskar, Dheevatsa Mudigere, Jorge Nocedal, Mikhail Smelyanskiy, and Ping Tak Peter Tang. On large-batch training for deep learning: Generalization gap and sharp minima. In ${ICLR},{2017.6},7$

[15] 尼蒂什·什里什·凯斯卡尔(Nitish Shirish Keskar)、迪瓦察·穆迪格尔(Dheevatsa Mudigere)、豪尔赫·诺塞德尔(Jorge Nocedal)、米哈伊尔·斯梅良斯基(Mikhail Smelyanskiy)和平德·彼得·唐(Ping Tak Peter Tang)。关于深度学习的大批量训练:泛化差距和尖锐极小值。见 ${ICLR},{2017.6},7$

[16] Aditya Khosla, Tinghui Zhou, Tomasz Malisiewicz, Alexei Efros, and Antonio Torralba. Undoing the damage of dataset bias. In ${ECCV},{2012.1},2,7$

[16] 阿迪蒂亚·科斯拉(Aditya Khosla)、周廷晖(Tinghui Zhou)、托马什·马利塞维奇(Tomasz Malisiewicz)、阿列克谢·埃弗罗斯(Alexei Efros)和安东尼奥·托拉尔巴(Antonio Torralba)。消除数据集偏差的影响。见 ${ECCV},{2012.1},2,7$

[17] Da Li, Yongxin Yang, Yi-Zhe Song, and Timothy Hospedales. Deeper, broader and artier domain generalization. In ${ICCV},{2017}$ . 1,2,3,5,6,7

[17] 李达(Da Li)、杨永新(Yongxin Yang)、宋毅哲(Yi-Zhe Song)和蒂莫西·霍斯佩代尔斯(Timothy Hospedales)。更深、更广、更具艺术性的领域泛化。见 ${ICCV},{2017}$ . 1,2,3,5,6,7

[18] Da Li, Yongxin Yang, Yi-Zhe Song, and Timothy Hospedales. Learning to generalize: Meta-learning for domain generalization. In ${AAAI},{2018.1},2,5,6,7,8$

[18] 李达(Da Li)、杨永新(Yongxin Yang)、宋毅哲(Yi-Zhe Song)和蒂莫西·霍斯佩代尔斯(Timothy Hospedales)。学习泛化:用于领域泛化的元学习。见 ${AAAI},{2018.1},2,5,6,7,8$

[19] Fei-Fei Li, Fergus Rob, and Perona Pietro. Learning generative

[19] 李菲菲(Fei-Fei Li)、罗布·费格斯(Fergus Rob)和彼得罗·佩罗纳(Perona Pietro)。学习生成式

visual models from few training examples: an incremental bayesian approach tested on 101 object categories. In CVPR Workshop on Generative-Model Based Vision, 2004. 5

从少量训练样本中学习视觉模型:在 101 个目标类别上测试的增量贝叶斯方法。见 2004 年计算机视觉与模式识别会议(CVPR)基于生成模型的视觉研讨会。5

[20] Haoliang Li, Sinno Jialin Pan, Shiqi Wang, and Alex C. Kot. Domain generalization with adversarial feature learning. In CVPR, 2018. 2, 5, 6

[20] 李浩亮(Haoliang Li)、潘嘉麟(Sinno Jialin Pan)、王诗琪(Shiqi Wang)和亚历克斯·C·科特(Alex C. Kot)。基于对抗特征学习的领域泛化。见 2018 年计算机视觉与模式识别会议(CVPR)。2, 5, 6

[21] Yiying Li, Yongxin Yang, Wei Zhou, and Timothy M. Hospedales. Feature-critic networks for heterogeneous domain generalization. In ${ICML},{2019.8}$

[21] 李怡颖(Yiying Li)、杨永新(Yongxin Yang)、周伟(Wei Zhou)和蒂莫西·M·霍斯佩代尔斯(Timothy M. Hospedales)。用于异构领域泛化的特征评判网络。见 ${ICML},{2019.8}$

[22] Mingsheng Long, Yue Cao, Jianmin Wang, and Michael Jordan. Learning transferable features with deep adaptation networks. In ${ICML},{2015.1}$

[22] 龙明盛(Mingsheng Long)、曹越(Yue Cao)、王建民(Jianmin Wang)和迈克尔·乔丹(Michael Jordan)。使用深度适应网络学习可迁移特征。见 ${ICML},{2015.1}$

[23] Mingsheng Long, Han Zhu, Jianmin Wang, and Michael I. Jordan. Unsupervised domain adaptation with residual transfer networks. In NIPS, 2016. 1

[23] 龙明盛(Mingsheng Long)、朱涵(Han Zhu)、王建民(Jianmin Wang)和迈克尔·I·乔丹(Michael I. Jordan)。使用残差转移网络进行无监督领域适应。见 2016 年神经信息处理系统大会(NIPS)。1

[24] Massimiliano Mancini, Samuel Rota Bulo', Barbara Caputo, and Elisa Ricci. Best sources forward: Domain generalization through source-specific nets. In ICIP, 2018. 5, 6, 7

[24] 马西米利亚诺·曼奇尼(Massimiliano Mancini)、塞缪尔·罗塔·布洛(Samuel Rota Bulo')、芭芭拉·卡普托(Barbara Caputo)和伊丽莎·里奇(Elisa Ricci)。最佳源向前:通过特定源网络进行领域泛化。见 2018 年国际图像处理会议(ICIP)。5, 6, 7

[25] Nikhil Mishra, Mostafa Rohaninejad, Xi Chen, and Pieter Abbeel. Meta-learning with temporal convolutions. arXiv, 2017. 2

[25] 尼基尔·米什拉(Nikhil Mishra)、莫斯塔法·罗哈尼贾德(Mostafa Rohaninejad)、陈曦(Xi Chen)和彼得·阿贝贝尔(Pieter Abbeel)。基于时间卷积的元学习。预印本 arXiv，2017 年。2

[26] Saeid Motiian, Marco Piccirilli, Donald A. Adjeroh, and Gianfranco Doretto. Unified deep supervised domain adaptation and generalization. In ${ICCV},{2017.5},6$

[26] 赛义德·莫蒂安(Saeid Motiian)、马尔科·皮西里利(Marco Piccirilli)、唐纳德·A·阿杰罗(Donald A. Adjeroh)和詹弗兰科·多雷托(Gianfranco Doretto)。统一深度监督域适应与泛化。见${ICCV},{2017.5},6$

[27] Krikamol Muandet, David Balduzzi, and Bernhard Schölkopf. Domain generalization via invariant feature representation. In ICML, 2013. 1, 2, 5, 6, 7

[27] 克里卡莫尔·穆安代特(Krikamol Muandet)、大卫·巴尔杜齐(David Balduzzi)和伯恩哈德·肖尔科普夫(Bernhard Schölkopf)。通过不变特征表示进行域泛化。见《国际机器学习会议》(ICML)，2013年。1, 2, 5, 6, 7

[28] Sachin Ravi and Hugo Larochelle. Optimization as a model for few-shot learning. In ${ICLR},{2017.1},2$

[28] 萨钦·拉维(Sachin Ravi)和雨果·拉罗谢尔(Hugo Larochelle)。将优化作为少样本学习的模型。见${ICLR},{2017.1},2$

[29] Sylvestre-Alvise Rebuffi, Hakan Bilen, and Andrea Vedaldi. Learning multiple visual domains with residual adapters. In NIPS, 2017. 2, 5, 7, 8

[29] 西尔维斯特 - 阿尔维斯·雷比菲(Sylvestre - Alvise Rebuffi)、哈坎·比伦(Hakan Bilen)和安德里亚·韦尔代利(Andrea Vedaldi)。使用残差适配器学习多个视觉域。见《神经信息处理系统大会》(NIPS)，2017年。2, 5, 7, 8

[30] Sylvestre-Alvise Rebuffi, Hakan Bilen, and Andrea Vedaldi. Efficient parametrization of multi-domain deep neural networks. In ${CVPR},{2018.2}$

[30] 西尔维斯特 - 阿尔维斯·雷比菲(Sylvestre - Alvise Rebuffi)、哈坎·比伦(Hakan Bilen)和安德里亚·韦尔代利(Andrea Vedaldi)。多域深度神经网络的高效参数化。见${CVPR},{2018.2}$

[31] Olga Russakovsky, Jia Deng, Hao Su, Jonathan Krause, Sanjeev Satheesh, Sean Ma, Zhiheng Huang, Andrej Karpathy, Aditya Khosla, Michael Bernstein, Alexander C. Berg, and Li Fei-Fei. Imagenet large scale visual recognition challenge. IJCV, 2015. 2

[31] 奥尔加·拉萨科夫斯基(Olga Russakovsky)、贾·邓(Jia Deng)、郝·苏(Hao Su)、乔纳森·克劳斯(Jonathan Krause)、桑杰夫·萨蒂什(Sanjeev Satheesh)、肖恩·马(Sean Ma)、黄志恒(Zhiheng Huang)、安德烈·卡帕西(Andrej Karpathy)、阿迪蒂亚·科斯拉(Aditya Khosla)、迈克尔·伯恩斯坦(Michael Bernstein)、亚历山大·C·伯格(Alexander C. Berg)和李菲菲(Li Fei - Fei)。ImageNet大规模视觉识别挑战赛。《国际计算机视觉杂志》(IJCV)，2015年。2

[32] Bryan C Russell, Antonio Torralba, Kevin P Murphy, and William T Freeman. Labelme: A database and web-based tool for image annotation. ${IJCV},{2008.5}$

[32] 布莱恩·C·拉塞尔(Bryan C Russell)、安东尼奥·托拉尔瓦(Antonio Torralba)、凯文·P·墨菲(Kevin P Murphy)和威廉·T·弗里曼(William T Freeman)。Labelme:一个用于图像标注的数据库和基于网络的工具。${IJCV},{2008.5}$

[33] Shiv Shankar, Vihari Piratla, Soumen Chakrabarti, Siddhartha Chaudhuri, Preethi Jyothi, and Sunita Sarawagi. Generalizing across domains via cross-gradient training. In ICLR, 2018. 1, 2,5,6,7,8

[33] 希夫·尚卡尔(Shiv Shankar)、维哈里·皮拉特(Vihari Piratla)、苏曼·查克拉巴蒂(Soumen Chakrabarti)、悉达多·乔杜里(Siddhartha Chaudhuri)、普里蒂·乔蒂(Preethi Jyothi)和苏尼塔·萨拉瓦吉(Sunita Sarawagi)。通过跨梯度训练实现跨域泛化。见《国际学习表征会议》(ICLR)，2018年。1, 2,5,6,7,8

[34] Jake Snell, Kevin Swersky, and Richard S. Zemel. Prototypical networks for few shot learning. In NIPS, 2017. 1, 2

[34] 杰克·斯内尔(Jake Snell)、凯文·斯韦尔斯基(Kevin Swersky)和理查德·S·泽梅尔(Richard S. Zemel)。用于少样本学习的原型网络。见《神经信息处理系统大会》(NIPS)，2017年。1, 2

[35] Christian Szegedy, Vincent Vanhoucke, Sergey Ioffe, Jon Shlens, and Zbigniew Wojna. Rethinking the inception architecture for computer vision. In ${CVPR},{2016.6}$

[35] 克里斯蒂安·塞格迪(Christian Szegedy)、文森特·万霍克(Vincent Vanhoucke)、谢尔盖·约菲(Sergey Ioffe)、乔恩·什伦斯(Jon Shlens)和兹比格涅夫·沃伊纳(Zbigniew Wojna)。重新思考计算机视觉的Inception架构。见${CVPR},{2016.6}$

[36] Eric Tzeng, Judy Hoffman, Ning Zhang, Kate Saenko, and Trevor Darrell. Deep domain confusion: Maximizing for domain invariance. arXiv, 2014. 1

[36] 埃里克·曾(Eric Tzeng)、朱迪·霍夫曼(Judy Hoffman)、宁·张(Ning Zhang)、凯特·塞内科(Kate Saenko)和特雷弗·达雷尔(Trevor Darrell)。深度域混淆:最大化域不变性。预印本arXiv，2014年。1

[37] Riccardo Volpi, Hongseok Namkoong, Ozan Sener, John Duchi, Vittorio Murino, and Silvio Savarese. Generalizing to unseen domains via adversarial data augmentation. In NeurIPS, 2018. 2

[37] 里卡多·沃尔皮(Riccardo Volpi)、洪锡南(Hongseok Namkoong)、奥赞·森纳(Ozan Sener)、约翰·杜奇(John Duchi)、维托里奥·穆里诺(Vittorio Murino)和西尔维奥·萨瓦雷塞(Silvio Savarese)。通过对抗性数据增强泛化到未见域。见《神经信息处理系统大会》(NeurIPS)，2018年。2

[38] Daniel Weinland, Remi Ronfard, and Edmond Boyer. Free viewpoint action recognition using motion history volumes. CVIU, 2006. 5

[38] 丹尼尔·温兰德(Daniel Weinland)、雷米·龙法尔(Remi Ronfard)和埃德蒙·博耶(Edmond Boyer)。使用运动历史体积进行自由视角动作识别。《计算机视觉与图像理解》(CVIU)，2006年。5

[39] Zheng Xu, Wen Li, Li Niu, and Dong Xu. Exploiting low-rank structure from latent domains for domain generalization. In ECCV, 2014. 1, 5, 6, 7

[39] 徐政(Zheng Xu)、李文(Wen Li)、牛莉(Li Niu)和徐东(Dong Xu)。从潜在域中挖掘低秩结构以实现域泛化。见《欧洲计算机视觉会议》(ECCV)，2014年。1, 5, 6, 7

[40] Yongxin Yang and Timothy M. Hospedales. A unified perspective on multi-domain and multi-task learning. In ${ICLR},{2015.2}$

[40] 杨永新(Yongxin Yang)和蒂莫西·M·霍斯佩代尔斯(Timothy M. Hospedales)。多域和多任务学习的统一视角。见${ICLR},{2015.2}$

[41] Ying Zhang, Tao Xiang, Timothy M. Hospedales, and Huchuan Lu. Deep mutual learning. In ${CVPR},{2018.7}$

[41] 张莹(Ying Zhang)、向涛(Tao Xiang)、蒂莫西·M·霍斯佩代尔斯(Timothy M. Hospedales)和卢湖川(Huchuan Lu)。深度互学习。见${CVPR},{2018.7}$