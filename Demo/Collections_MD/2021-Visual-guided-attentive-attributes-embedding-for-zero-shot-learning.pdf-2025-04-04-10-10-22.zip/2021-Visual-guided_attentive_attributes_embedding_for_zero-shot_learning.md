# Visual-guided attentive attributes embedding for zero-shot learning

# 用于零样本学习的视觉引导注意力属性嵌入

Rui Zhang, Qi Zhu ${}^{ * }$ , Xiangyu Xu, Daoqiang Zhang, Sheng-Jun Huang

张瑞，朱琦 ${}^{ * }$ ，徐翔宇，张道强，黄圣君

College of Computer Science and Technology, Nanjing University of Aeronautics and Astronautics, Nanjing 211106, China

南京航空航天大学计算机科学与技术学院，中国南京 211106

## ARTICLE INFO

## 文章信息

Keywords:

关键词:

Zero-shot learning

零样本学习

Encoder-decoder

编码器 - 解码器

Attributes

属性

Attention mechanism

注意力机制

## A B S T R A C T

## 摘要

Zero-shot learning (ZSL) aims to learn a classifier for unseen classes by exploiting both training data from seen classes and external knowledge. In many visual tasks such as image classification, a set of high-level attributes that describe the semantic properties of classes are used as the external knowledge to bridge seen and unseen classes. While the attributes are usually treated equally by previous ZSL studies, we observe that the contribution of different attributes varies significantly over model training. To adaptively exploit the discriminative information embedded in different attributes, we propose a novel encoder-decoder framework with attention mechanism on the attribute level for zero-shot learning. Specifically, by mapping the visual features into a semantic space, the more discriminative attributes are emphasized with larger attention weights. Further, the attentive attributes and the class prototypes are simultaneously decoded to the visual space so that the hubness problem can be eased. Finally, the labels are predicted in the visual space. Extensive experiments on multiple benchmark datasets demonstrate that our proposed model achieves a significant boost over several state-of-the-art methods for ZSL task and comparative results for generalized ZSL task.

零样本学习(Zero-shot learning，ZSL)旨在通过利用已见类别的训练数据和外部知识，为未见类别学习分类器。在许多视觉任务(如图像分类)中，一组描述类别语义属性的高级属性被用作连接已见类别和未见类别的外部知识。虽然以往的零样本学习研究通常对这些属性一视同仁，但我们观察到，在模型训练过程中，不同属性的贡献差异显著。为了自适应地挖掘不同属性中蕴含的判别信息，我们提出了一种新颖的编码器 - 解码器框架，该框架在属性层面引入了注意力机制，用于零样本学习。具体而言，通过将视觉特征映射到语义空间，更具判别性的属性会被赋予更大的注意力权重。此外，将经过注意力处理的属性和类别原型同时解码到视觉空间，从而缓解中心性问题。最后，在视觉空间中进行标签预测。在多个基准数据集上的大量实验表明，我们提出的模型在零样本学习任务上比几种最先进的方法有显著提升，在广义零样本学习任务上也取得了相当的结果。

## 1. Introduction

## 1. 引言

Deep learning has achieved great success in various tasks. However, it usually requires a large amount of labeled data to train the model, and thus is less applicable to tasks with limited labeled data, especially those even with zero examples on some novel classes. To tackle this challenge, zero-shot learning (ZSL) (Palatucci, Pomerleau, Hinton, & Mitchell, 2009), which aims to predict unseen classes with only seen classes, has attracted much research interest in recent years.

深度学习在各种任务中取得了巨大成功。然而，它通常需要大量的标注数据来训练模型，因此不太适用于标注数据有限的任务，尤其是那些在某些新类别上甚至没有示例的任务。为了应对这一挑战，零样本学习(Zero-shot learning，ZSL)(Palatucci, Pomerleau, Hinton, & Mitchell, 2009)旨在仅利用已见类别来预测未见类别，近年来引起了广泛的研究兴趣。

Generally speaking, most existing methods consider ZSL as a matching problem between visual feature space and semantic space (Changpinyo, Chao, Gong, & Sha, 2020; Ding, Shao, & Fu, 2017). The matching function is learned only using labeled training visual features of seen classes. Specifically, some studies try to project visual features into semantic space (Fu, Hospedales, Xiang, & Gong, 2015; Ye & Guo, 2017), and the others explore a common space to learn the relationship of the visual and semantic representations (Akata, Reed, Walter, Lee, & Schiele, 2015; Bucher, Herbin, & Jurie, 2016; Zhang & Saligrama, 2016). After the projection is learned, it can be used to predict unseen classes. Generally, a nearest neighbor (NN) search is adopted for the inference procedure. However, the NN search may suffer from the hubness problem, i.e., the phenomenon that some samples are universal neighbors of samples from other classes. In ZSL task, the semantic prototypes can be the neighbors of many test images from the other classes, which may result in bad accuracy. In order to reduce hubness, Fu, Xiang, Kodirov, and Gong (2017) proposed to calculate a novel manifold distance on a semantic class prototype. And Shigeto, Suzuki, Hara, Shimbo, and Matsumoto (2015) proposed to embed class prototypes into the visual space to alleviate the deterioration of the performance. Zhang, Xiang, and Gong (2017) followed this to train an end-to-end deep neural network based on class prototypes.

一般来说，大多数现有方法将零样本学习视为视觉特征空间和语义空间之间的匹配问题(Changpinyo, Chao, Gong, & Sha, 2020; Ding, Shao, & Fu, 2017)。匹配函数仅使用已见类别的标注训练视觉特征进行学习。具体而言，一些研究尝试将视觉特征投影到语义空间(Fu, Hospedales, Xiang, & Gong, 2015; Ye & Guo, 2017)，而另一些研究则探索一个公共空间来学习视觉和语义表示之间的关系(Akata, Reed, Walter, Lee, & Schiele, 2015; Bucher, Herbin, & Jurie, 2016; Zhang & Saligrama, 2016)。在学习到投影之后，就可以用它来预测未见类别。通常，推理过程采用最近邻(Nearest neighbor，NN)搜索。然而，最近邻搜索可能会受到中心性问题的影响，即某些样本是其他类别样本的通用邻居的现象。在零样本学习任务中，语义原型可能是许多来自其他类别的测试图像的邻居，这可能导致准确率较低。为了减少中心性问题，Fu, Xiang, Kodirov, and Gong (2017) 提出在语义类别原型上计算一种新颖的流形距离。Shigeto, Suzuki, Hara, Shimbo, and Matsumoto (2015) 提出将类别原型嵌入到视觉空间中，以缓解性能下降的问题。Zhang, Xiang, and Gong (2017) 在此基础上训练了一个基于类别原型的端到端深度神经网络。

The usage of high-level semantic description of each class, which is another principle to categorize the ZSL approaches, mainly includes user-defined attributes, sentences, word vectors, etc. Among which, attribute is widely used. Recently, some attribute-based ZSL methods (Xie et al., 2019; Yu et al., 2018) introduce attention mechanisms to capture discriminative local regions for image classification, motivated by the observations that human often tends to focus on local informative regions. However, they neglect that the contribution of different attributes varies significantly for a specific class label. For example, given some attributes to describe a zebra and a giant panda, which is shown in Fig. 1, we can see "big", "vegetation", "black" and "white" are their common features while "strips" and "bulbous" are their respective discriminative features. If the attributes are treated equally, it is less likely to distinguish these two animals quickly when the common features are learned with priority. But if we focus on the discriminative attributes and give them higher attention values (earlier learned here), the answer can be got with no hesitation. Guo, Ding, Han, and Tang (2018) studied this characteristic of attributes via applying an attribute selection strategy, whereas the abandoned attributes may take away some information despite being weighted small. Therefore, based on the aforementioned status quo, we propose a visual-guided attentive attributes embedding (VGAAE) model, which is under an encoder-decoder framework. The encoder maps the features into the semantic space, and then the generated semantic attributes are weighted with different attention values by an attention module. After that, these attentive attributes are embedded back to visual space through the decoder to be integrated with the original visual features. Besides, the class prototypes are also fed into the decoder network to generate their corresponding visual prototypes. Then, the product operation can be implemented between the prototypes and the fused visual features of samples rather than the widely used nearest neighbors classifiers.

对每个类别使用高级语义描述是对零样本学习(ZSL)方法进行分类的另一个原则，其主要包括用户定义的属性、句子、词向量等。其中，属性的应用最为广泛。最近，一些基于属性的零样本学习方法(Xie等人，2019；Yu等人，2018)引入了注意力机制，以捕捉用于图像分类的有区分性的局部区域，其灵感来源于人类通常倾向于关注局部信息区域这一观察结果。然而，这些方法忽略了对于特定类别标签而言，不同属性的贡献存在显著差异。例如，如图1所示，给定一些属性来描述斑马和大熊猫，我们可以看到“体型大”“食草”“黑色”和“白色”是它们的共同特征，而“条纹”和“圆胖”分别是它们的区分性特征。如果对这些属性一视同仁，那么在优先学习共同特征时，就不太可能快速区分这两种动物。但如果我们关注具有区分性的属性，并赋予它们更高的注意力值(这里指更早学习)，就能毫不犹豫地得出答案。Guo、Ding、Han和Tang(2018)通过应用属性选择策略研究了属性的这一特性，然而，被舍弃的属性尽管权重较小，但可能会带走一些信息。因此，基于上述现状，我们提出了一种视觉引导的注意力属性嵌入(VGAAE)模型，该模型基于编码器 - 解码器框架。编码器将特征映射到语义空间，然后注意力模块为生成的语义属性分配不同的注意力值。之后，这些带有注意力的属性通过解码器被嵌入回视觉空间，与原始视觉特征进行融合。此外，类别原型也被输入到解码器网络中，以生成相应的视觉原型。然后，可以在原型和样本的融合视觉特征之间进行乘积运算，而不是使用广泛应用的最近邻分类器。

---

* Correspondence to: Nanjing University of Aeronautics and Astronautics, 29 Jiangjun Ave., Nanjing 211106, Nanjing, China

* 通信地址:中国南京将军大道29号南京航空航天大学，邮编211106

E-mail address: zhuqi@nuaa.edu.cn (Q. Zhu).

电子邮箱地址:zhuqi@nuaa.edu.cn(朱琦)

---

![0195da3a-d6fe-731a-8c38-789b90affb5c_1_141_169_674_250_0.jpg](images/0195da3a-d6fe-731a-8c38-789b90affb5c_1_141_169_674_250_0.jpg)

Fig. 1. An example of paying attention to discriminative attributes. The redder the marker for the corresponding attribute, the greater the contribution of the attribute to the recognition of the category.

图1. 关注区分性属性的示例。对应属性的标记颜色越红，该属性对类别识别的贡献越大。

Our contributions can be summarized as follows: (1) We propose an effective encoder-decoder framework to link the visual space and semantic space in a cyclic manner, which enables the knowledge to transfer between seen classes to unseen classes for ZSL task. (2) An attention mechanism is exploited to adaptively weigh the visual-guided attributes for the purpose of emphasizing the attributes. Then the weighted attributes are embedded back into the visual space to directly predict the actual labels by multiplication with the simultaneously embedded class prototypes. (3) Extensive experiments on popular ZSL benchmark datasets demonstrate that our proposed model achieves significant improvements over several state-of-the-art methods for ZSL task and comparative results for generalized ZSL task.

我们的贡献总结如下:(1)我们提出了一种有效的编码器 - 解码器框架，以循环方式连接视觉空间和语义空间，使零样本学习任务中的知识能够在已见类别和未见类别之间进行迁移。(2)利用注意力机制自适应地对视觉引导的属性进行加权，以突出这些属性。然后将加权后的属性嵌入回视觉空间，通过与同时嵌入的类别原型相乘直接预测实际标签。(3)在流行的零样本学习基准数据集上进行的大量实验表明，我们提出的模型在零样本学习任务上比几种最先进的方法有显著改进，在广义零样本学习任务上也取得了相当的结果。

The rest of the paper is organized as follows. In Section 2, we briefly discuss the related work. In Section 3, we describe the proposed framework and methodology. Next, in Section 4, we show the results of our experiments on four datasets and the analysis of the results to prove the effectiveness of our model. Finally, we conclude the main contributions of this paper in Section 5.

本文的其余部分组织如下。在第2节中，我们简要讨论相关工作。在第3节中，我们描述所提出的框架和方法。接下来，在第4节中，我们展示在四个数据集上的实验结果，并对结果进行分析，以证明我们模型的有效性。最后，在第5节中，我们总结本文的主要贡献。

## 2. Related work

## 2. 相关工作

In this section, we introduce the relevant concept of semantic information and then briefly review the most related work on ZSL.

在本节中，我们介绍语义信息的相关概念，然后简要回顾与零样本学习最相关的工作。

### 2.1. Semantic information

### 2.1. 语义信息

Semantic information is critical to the ZSL task in that it enables the knowledge to transfer between seen classes and unseen classes. Semantic information is defined as some descriptions of classes. Specifically, the descriptions can be the attributes defined manually, word vectors, Term Frequency-Inverse Document Frequency (TF-IDF) (Salton & Buckley, 1988), and etc. Attributes are usually the accurate descriptions of objects annotated by human experts. Word vectors are automatically collected from text corpus like Wikipedia. TF-IDF (Salton & Buckley, 1988) feature vectors are extracted from the articles to represent the semantic features of each class. Though the last two categories of semantic information are free from human labor, they are usually noisy and not so accurate. Recently, many papers focus on learning attributes based methods and have proved the performance of using attributes as the intermediary is currently much better than that of the other semantic information (Yu et al., 2018). Thus, in this paper, we use the attributes to make the model learn to recognize the classes that have not been seen.

语义信息对于零样本学习任务至关重要，因为它使知识能够在已见类别和未见类别之间进行迁移。语义信息被定义为对类别的一些描述。具体来说，这些描述可以是人工定义的属性、词向量、词频 - 逆文档频率(TF - IDF)(Salton和Buckley，1988)等。属性通常是人类专家对对象的准确描述。词向量是从维基百科等文本语料库中自动收集的。TF - IDF(Salton和Buckley，1988)特征向量是从文章中提取的，用于表示每个类别的语义特征。尽管后两类语义信息无需人工劳动，但它们通常存在噪声且不够准确。最近，许多论文专注于基于属性学习的方法，并证明了使用属性作为中介的性能目前远优于其他语义信息(Yu等人，2018)。因此，在本文中，我们使用属性来让模型学习识别未见的类别。

### 2.2. Zero-shot learning

### 2.2. 零样本学习

DAP and IAP (Lampert, Nickisch, & Harmeling, 2014) are two pioneering methods in zero-shot learning field, which employ attributes as intermediate prior information. ESZSL (Romera-Paredes & Torr, 2015) explores a framework that models a two-linear-layer network to represent the relationship of features, attributes and classes. DEVISE (Frome et al., 2013) trains a deep model to use the semantic information to achieve reasonable predictions. ALE (Akata, Perronnin, Harchaoui, & Schmid, 2016) learns a bilinear matching with ranking loss objective, and LATEM (Xian et al., 2016) extends the bilinear mapping to a collection of projections with selection strategy. SAE (Kodirov, Xiang, & Gong, 2017) encodes the visual vectors into semantic space and then uses the learned mapping to reconstruct the visual vectors, whereas LESAE (Liu, Gao, Li, Han, & Shao, 2018) further introduces a low-rank regularization into the mapping. GFZSL (Verma & Rai, 2017) models a generative framework utilizing each class-conditional distribution. DEM (Zhang et al., 2017) is proposed to alleviate the hubness issue by a class prototype embedding to visual space. TCN (Jiang, Wang, Shan, & Chen, 2019) utilizes a contrastive network that automatically judges whether an image is consistent with a specific class via defined similarities. RN (Sung et al., 2018), AREN (Xie et al., 2019) and SeeNet-HAF (Jin, Xie, Huang, Miao, & Wang, 2019) achieve promising performance by each end-to-end trainable CNN model. Zhu, Elhoseiny, Liu, Peng, and Elgammal (2018) leveraged generative adversarial network (GAN) to transform the ZSL task to traditional classification task. Huang, Wang, Yu, and Wang (2019) designed a novel dual adversarial loss to make the regressor and discriminator learn from each other. Chen, Li, Luo, Huang, and Yang (2020) and Felix, Reid, Carneiro, et al. (2018) both extended the GAN-based model with a cycle consistency loss to alleviate the unconstrained image representations generation process issue. Vyas, Venkateswara, and Panchanathan (2020) incorporated a semantic regularized loss into the generalized adversarial network so that the semantic relationship between seen and unseen classes can be reflected in the generated visual features. Different from these generative methods based on GAN, Verma, Arora, Mishra, and Rai (2018) used variational autoencoder (VAE) to synthesize novel exemplars from seen or unseen classes. Whereas, most of the methods treat the semantic information evenly which may lead the models to be distracted by some noisy information. Although AS Guo et al. (2018) highlights the importance of weighting attributes unequally and designs an attributes strategy to select a subset of all attributes, some useful unselected attributes could be abandoned. Hence, in our work, all attributes are involved with different importance scores implemented by an attention module.

判别式属性投影(DAP)和归纳式属性投影(IAP)(兰珀特、尼基施和哈梅林，2014年)是零样本学习领域的两种开创性方法，它们将属性用作中间先验信息。端到端语义零样本学习(ESZSL)(罗梅拉 - 帕雷德斯和托尔，2015年)探索了一个框架，该框架对一个双线性层网络进行建模，以表示特征、属性和类别之间的关系。深度视觉语义嵌入(DEVISE)(弗罗姆等人，2013年)训练了一个深度模型，以利用语义信息进行合理预测。基于属性的线性嵌入(ALE)(阿卡塔、佩罗宁、哈乔维和施密德，2016年)学习了一种带有排序损失目标的双线性匹配，而基于线性变换的嵌入模型(LATEM)(西安等人，2016年)将双线性映射扩展为一组带有选择策略的投影。语义自编码器(SAE)(科迪罗夫、向和龚，2017年)将视觉向量编码到语义空间，然后使用学习到的映射来重构视觉向量，而低秩语义自编码器(LESAE)(刘、高、李、韩和邵，2018年)进一步在映射中引入了低秩正则化。广义零样本学习(GFZSL)(维尔马和拉伊，2017年)对一个利用每个类别条件分布的生成框架进行建模。基于判别嵌入的方法(DEM)(张等人，2017年)通过将类别原型嵌入到视觉空间来缓解中心性问题。对比网络(TCN)(江、王、单和陈，2019年)利用一个对比网络，通过定义的相似度自动判断一幅图像是否与特定类别一致。关系网络(RN)(宋等人，2018年)、注意力关系网络(AREN)(谢等人，2019年)和基于分层注意力融合的语义嵌入网络(SeeNet - HAF)(金、谢、黄、苗和王，2019年)通过各自可端到端训练的卷积神经网络(CNN)模型取得了不错的性能。朱、埃尔霍塞尼、刘、彭和埃尔加马尔(2018年)利用生成对抗网络(GAN)将零样本学习任务转化为传统分类任务。黄、王、余和王(2019年)设计了一种新颖的双对抗损失，使回归器和判别器相互学习。陈、李、罗、黄和杨(2020年)以及费利克斯、里德、卡内罗等人(2018年)都将基于生成对抗网络的模型扩展为带有循环一致性损失，以缓解无约束图像表示生成过程的问题。维亚斯、文卡特斯瓦拉和潘查纳坦(2020年)将语义正则化损失纳入广义对抗网络，以便在生成的视觉特征中反映已见和未见类别之间的语义关系。与这些基于生成对抗网络的生成方法不同，维尔马、阿罗拉、米什拉和拉伊(2018年)使用变分自编码器(VAE)从已见或未见类别中合成新的样本。然而，大多数方法对语义信息一视同仁，这可能会使模型受到一些噪声信息的干扰。尽管郭等人(2018年)强调了对属性进行不等加权的重要性，并设计了一种属性策略来选择所有属性的一个子集，但一些有用的未被选中的属性可能会被舍弃。因此，在我们的工作中，所有属性都通过一个注意力模块赋予不同的重要性得分。

### 2.3. Attention mechanisms

### 2.3. 注意力机制

Attention mechanisms generate from the observations that human brain will intentionally or unintentionally select specific parts of the visual area and focus on these parts. In recent years, they have been extensively studied in various tasks, such as image caption (You, Jin, Wang, Fang, & Luo, 2016), object classification (Ba, Mnih, & Kavukcuoglu, 2015; Zhang, Zhang, Lin, Lu, & He, 2019). Xie et al. (2019) and Yu et al. (2018) also introduced attention mechanisms to the zero-shot learning tasks. They tried to capture discriminative local visual regions. And Zhu, Xie, Tang, Peng, and Elgammal (2019) proposed a semantic-guided multi-attention localization model that simultaneously learns global and local features based on semantic information and can be encouraged to learn features with high inter-class dispersion and intra-class compactness via the embedding loss and class-center triplet loss. However, these methods still treat the given attributes equally. LFGAA (Liu, Guo, Cai, & He, 2019) jointly learns visual-semantic and visual-latent projections to solve semantic ambiguity by object-based attention on attributes. Notwithstanding, LFGAA may exist hubness problem due to searching the closest prototypes. Therefore, we propose to classify the instances in visual space performing with the visual-guided attentive attributes and class prototypes embedded from semantic space.

注意力机制源于这样的观察:人类大脑会有意或无意地选择视觉区域的特定部分并专注于这些部分。近年来，它们在各种任务中得到了广泛研究，如图像描述(尤、金、王、方和罗，2016年)、目标分类(巴、米尼和卡武库奥卢，2015年；张、张、林、陆和何，2019年)。谢等人(2019年)和余等人(2018年)也将注意力机制引入零样本学习任务。他们试图捕捉有判别性的局部视觉区域。朱、谢、唐、彭和埃尔加马尔(2019年)提出了一种语义引导的多注意力定位模型，该模型基于语义信息同时学习全局和局部特征，并可以通过嵌入损失和类中心三元组损失鼓励学习具有高类间离散度和类内紧凑性的特征。然而，这些方法仍然对给定的属性一视同仁。基于局部特征引导的注意力属性(LFGAA)(刘、郭、蔡和何，2019年)联合学习视觉 - 语义和视觉 - 潜在投影，通过基于目标的属性注意力来解决语义歧义。尽管如此，由于搜索最近的原型，LFGAA可能存在中心性问题。因此，我们建议在视觉空间中对实例进行分类，使用视觉引导的注意力属性和从语义空间嵌入的类别原型。

### 3.The visual-guided attentive attributes embedding model

### 3. 视觉引导的注意力属性嵌入模型

In this section, we will elaborate on our VGAAE model. The framework of our proposed network is illustrated in Fig. 2.

在本节中，我们将详细阐述我们的VGAAE模型。我们提出的网络框架如图2所示。

Task definition: Given ${c}_{s}$ seen classes ${\mathcal{Y}}^{s}$ and ${c}_{u}$ unseen classes ${\mathcal{Y}}^{u}$ . And the semantic class-embedding of seen classes and unseen classes are also provided, i.e., $\mathcal{C} \in  {\mathbb{R}}^{{c}_{s} \times  d}$ and ${\mathcal{C}}^{u} \in  {\mathbb{R}}^{{c}_{u} \times  d}$ , whose rows are vectors of $d$ hand-annotated continuous attributes ${\left\{  {A}_{i}\right\}  }_{i = 1}^{d}$ . Suppose the training set contains $n$ labeled samples $\mathcal{S} = {\left\{  \left( {\mathbf{V}}_{i},{\mathbf{a}}_{{y}_{i}},{y}_{i}\right) \right\}  }_{i = 1}^{n}$ , where ${\mathbf{V}}_{i} \in  \mathcal{X},{y}_{i} \in  {\mathcal{Y}}^{s}$ and ${\mathbf{a}}_{{y}_{i}} \in  \mathcal{C}$ are the $i$ th unseen visual features and its corresponding label, attribute vector, respectively. For ZSL, given the test set ${\mathcal{S}}^{u} =$ ${\left\{  \left( {\mathbf{V}}_{i}^{u},{\mathbf{a}}_{{y}_{i}}^{u},{y}_{i}^{u}\right) \right\}  }_{i = 1}^{{n}_{u}}$ , we aim to learn a classifier $f : \mathcal{X} \rightarrow  {\mathcal{Y}}_{u}$ under the setting that seen classes and unseen classes are disjoint, i.e., ${\mathcal{Y}}^{s} \cap  {\mathcal{Y}}^{u} = \varnothing$ . For generalized ZSL (GZSL), the test set is included with unseen samples from both seen and unseen classes $\mathcal{Y} = {\mathcal{Y}}^{s} \cup  {\mathcal{Y}}^{u}$

任务定义:给定${c}_{s}$个已见类别${\mathcal{Y}}^{s}$和${c}_{u}$个未见类别${\mathcal{Y}}^{u}$。同时也提供了已见类别和未见类别的语义类别嵌入，即$\mathcal{C} \in  {\mathbb{R}}^{{c}_{s} \times  d}$和${\mathcal{C}}^{u} \in  {\mathbb{R}}^{{c}_{u} \times  d}$，其行是$d$个手工标注的连续属性${\left\{  {A}_{i}\right\}  }_{i = 1}^{d}$的向量。假设训练集包含$n$个带标签的样本$\mathcal{S} = {\left\{  \left( {\mathbf{V}}_{i},{\mathbf{a}}_{{y}_{i}},{y}_{i}\right) \right\}  }_{i = 1}^{n}$，其中${\mathbf{V}}_{i} \in  \mathcal{X},{y}_{i} \in  {\mathcal{Y}}^{s}$和${\mathbf{a}}_{{y}_{i}} \in  \mathcal{C}$分别是第$i$个未见视觉特征及其对应的标签、属性向量。对于零样本学习(ZSL)，给定测试集${\mathcal{S}}^{u} =$ ${\left\{  \left( {\mathbf{V}}_{i}^{u},{\mathbf{a}}_{{y}_{i}}^{u},{y}_{i}^{u}\right) \right\}  }_{i = 1}^{{n}_{u}}$，我们的目标是在已见类别和未见类别不相交的设置下学习一个分类器$f : \mathcal{X} \rightarrow  {\mathcal{Y}}_{u}$，即${\mathcal{Y}}^{s} \cap  {\mathcal{Y}}^{u} = \varnothing$。对于广义零样本学习(GZSL)，测试集包含来自已见和未见类别的未见样本$\mathcal{Y} = {\mathcal{Y}}^{s} \cup  {\mathcal{Y}}^{u}$

#### 3.1.The visual to semantic encoder

#### 3.1.视觉到语义编码器

Embedding visual features into semantic space is a universal method for zero-shot learning seeing that the semantic representation connects the training set and test set. Drawing upon this stand, a two-layer fully connected encoder $F$ with a ReLU activation is simply used. Given a visual feature vector ${\mathbf{V}}_{i} \in  {\mathbb{R}}^{m}$ extracted by CNN, the projected ${\widetilde{\mathbf{a}}}_{i}$ is formulated as:

将视觉特征嵌入到语义空间是零样本学习的一种通用方法，因为语义表示连接了训练集和测试集。基于这一观点，我们简单地使用一个带有ReLU激活函数的两层全连接编码器$F$。给定一个由卷积神经网络(CNN)提取的视觉特征向量${\mathbf{V}}_{i} \in  {\mathbb{R}}^{m}$，投影后的${\widetilde{\mathbf{a}}}_{i}$可表示为:

$$
{\widetilde{\mathbf{a}}}_{i} = F\left( {\mathbf{V}}_{i}\right)  \tag{1}
$$

We apply mean-squared error (MSE) to shrink the distance between the output of the encoder and the given attribute vector of every instance for a better mapping from visual space to semantic space. The MSE loss in semantic space is given as:

我们应用均方误差(MSE)来缩小编码器输出与每个实例的给定属性向量之间的距离，以实现从视觉空间到语义空间的更好映射。语义空间中的均方误差损失定义为:

$$
{\mathcal{L}}_{\text{att }} = \frac{1}{n}\mathop{\sum }\limits_{{i = 1}}^{n}{\begin{Vmatrix}{\mathbf{a}}_{i} - {\widetilde{\mathbf{a}}}_{i}\end{Vmatrix}}_{2}^{2} \tag{2}
$$

#### 3.2.The attentive attributes module

#### 3.2.注意力属性模块

Intuitively, not all the attributes contribute to the recognition performance, and thus we propose to reweigh the given attributes of different categories to emphasize the relatively more important attributes. To this end, an attentive attributes module (AAM), which is based on the LSTM framework, is designed to calculate the weights for every attribute of an instance. Fig. 3 shows the structure of AAM.

直观地说，并非所有属性都对识别性能有贡献，因此我们建议对不同类别的给定属性进行重新加权，以强调相对更重要的属性。为此，我们设计了一个基于长短期记忆网络(LSTM)框架的注意力属性模块(AAM)，用于计算实例每个属性的权重。图3展示了AAM的结构。

We follow (You et al.,2016) to take ${\widetilde{\mathbf{a}}}_{i}$ as an initial input, which gives AAM a global impression of the images. Then, the visual information can guide this module to calculate the attention values which will be assigned to the corresponding attributes fed into the LSTM at each subsequent step. It is noted that the number of steps should be the same as the number of attributes. In this subsection, we denote ${\widetilde{\mathbf{a}}}_{i}$ as $\widetilde{\mathbf{a}}$ for convenience. The main equations can be written as:

我们遵循(You等人，2016)的方法，将${\widetilde{\mathbf{a}}}_{i}$作为初始输入，这为AAM提供了图像的全局印象。然后，视觉信息可以引导该模块计算注意力值，这些注意力值将在后续的每一步分配给输入到LSTM中的相应属性。需要注意的是，步数应与属性数量相同。在本小节中，为方便起见，我们将${\widetilde{\mathbf{a}}}_{i}$表示为$\widetilde{\mathbf{a}}$。主要方程可以写成:

$$
{\mathbf{h}}_{t} = \operatorname{LSTM}\left( {{\mathbf{h}}_{t - 1},{\mathbf{x}}_{t}}\right)  \tag{3}
$$

$$
{o}_{t} = {\mathbf{W}}_{1}{\mathbf{h}}_{t} + {b}_{1},\;t > 0 \tag{4}
$$

$$
{\mathbf{x}}_{t} = \left\{  \begin{array}{ll} \widetilde{\mathbf{a}}, & t = 0 \\  {\mathbf{W}}_{2}\left( {{\mathbf{h}}_{0}^{t} + {\mathbf{\beta }}_{t}^{T}\widetilde{\mathbf{a}}}\right)  + {\mathbf{b}}_{2}, & t > 0 \end{array}\right.  \tag{5}
$$

where ${\mathbf{h}}_{t}$ and ${\mathbf{x}}_{t}$ represent the hidden vector and input vector of LSTM at step $t.{\mathbf{W}}_{1} \in  {\mathbb{R}}^{1 \times  d}$ and ${\mathbf{W}}_{2} \in  {\mathbb{R}}^{d \times  1}$ are weights of linear layer. The scalar ${b}_{1}$ and vector ${\mathbf{b}}_{2} \in  {\mathbb{R}}^{d \times  1}$ are the corresponding biases. Specifically, ${\mathbf{\beta }}_{t}^{i}$ represents weight of the $t$ th recurrent of the $i$ th attribute in ${\left\{  {A}_{i}\right\}  }_{i = 1}^{d}$ . Thus, the weight vector of all attributes at step $t$ can be calculated via:

其中 ${\mathbf{h}}_{t}$ 和 ${\mathbf{x}}_{t}$ 分别表示长短期记忆网络(LSTM)在第 $t.{\mathbf{W}}_{1} \in  {\mathbb{R}}^{1 \times  d}$ 步的隐藏向量和输入向量，${\mathbf{W}}_{2} \in  {\mathbb{R}}^{d \times  1}$ 是线性层的权重。标量 ${b}_{1}$ 和向量 ${\mathbf{b}}_{2} \in  {\mathbb{R}}^{d \times  1}$ 是相应的偏置。具体而言，${\mathbf{\beta }}_{t}^{i}$ 表示 ${\left\{  {A}_{i}\right\}  }_{i = 1}^{d}$ 中第 $i$ 个属性的第 $t$ 次循环的权重。因此，第 $t$ 步所有属性的权重向量可以通过以下方式计算:

$$
{\mathbf{\beta }}_{t} = \operatorname{softmax}\left( {f\left( {{\mathbf{h}}_{0}^{t},\widetilde{\mathbf{a}}}\right) }\right)  \tag{6}
$$

where $f$ is a bilinear function like $y = {x}_{1}W{x}_{2} + b$ , modeling relevance of the visual guiding ${\mathbf{h}}_{0}^{t}$ and the semantic vector $\widetilde{\mathbf{a}}$ . The output $\mathbf{p}$ of AAM can be concatenated by a collection of ${\left\{  {o}_{i}\right\}  }_{i = 1}^{d}$ :

其中 $f$ 是一个类似于 $y = {x}_{1}W{x}_{2} + b$ 的双线性函数，用于建模视觉引导 ${\mathbf{h}}_{0}^{t}$ 和语义向量 $\widetilde{\mathbf{a}}$ 之间的相关性。注意力属性模块(AAM)的输出 $\mathbf{p}$ 可以由一组 ${\left\{  {o}_{i}\right\}  }_{i = 1}^{d}$ 拼接而成:

$$
\mathbf{p} = \operatorname{cat}\left( {{o}_{1},{o}_{2},\ldots ,{o}_{d}}\right)  \tag{7}
$$

#### 3.3.The semantic to visual decoder

#### 3.3 语义到视觉解码器

Since the dimension of visual features is much higher than the dimension of attributes, crucial information may be lost after the visual features flow past the encoder. Hence, once attentive attributes are obtained, we exploit a decoder to embed them back into the visual space:

由于视觉特征的维度远高于属性的维度，视觉特征经过编码器后可能会丢失关键信息。因此，一旦获得注意力属性，我们利用解码器将其重新嵌入到视觉空间中:

$$
{\widetilde{\mathbf{V}}}_{i} = G\left( \mathbf{p}\right)  \tag{8}
$$

where $\mathbf{p}$ here is used as an example. Then, to preserve more diversified features, we minimize the MSE loss of the visual vector projected from the semantic space and its original visual feature:

这里以 $\mathbf{p}$ 为例。然后，为了保留更多样化的特征，我们最小化从语义空间投影得到的视觉向量与其原始视觉特征之间的均方误差损失:

$$
{\mathcal{L}}_{\text{vis }} = \min \frac{1}{n}\mathop{\sum }\limits_{{i = 1}}^{n}{\begin{Vmatrix}{\mathbf{V}}_{i} - {\widetilde{\mathbf{V}}}_{i}\end{Vmatrix}}^{2} \tag{9}
$$

where $\mathrm{G}$ is also a two-layer fully connected network that is symmetrical as the encoder.

其中 $\mathrm{G}$ 也是一个与编码器对称的两层全连接网络。

Labels of the input images are predicted in this visual space since embedding from semantic space to visual space can alleviate the hubness in zero-shot learning, argured by Shigeto et al. (2015) and Zhang et al. (2017). However, predicting labels by the nearest neighbor (NN) classifier in their methods still exist the adverse effect of hubness. Therefore, the labels are predicted by returning the indices with the maximum probability rather than seeking for nearest neighbor. To this end, we also put the class-embedding $\mathcal{C}$ into the decoder to acquire its embedding $\widetilde{\mathcal{C}} \in  {\mathbb{R}}^{c \times  m}$ in visual space. A multiplication operation is then employed to $\widetilde{\mathcal{C}}$ and fused visual features ${\mathbf{V}}_{f} \in  {\mathbb{R}}^{m}$ , where ${\mathbf{V}}_{f}$ is the item-wise addition of $\mathbf{V}$ and $\widetilde{\mathbf{V}}$ :

由于从语义空间嵌入到视觉空间可以缓解零样本学习中的中心性问题(Shigeto 等人(2015)和 Zhang 等人(2017)提出)，因此在这个视觉空间中预测输入图像的标签。然而，他们的方法中使用最近邻(NN)分类器预测标签仍然存在中心性的不利影响。因此，通过返回具有最大概率的索引而不是寻找最近邻来预测标签。为此，我们还将类别嵌入 $\mathcal{C}$ 输入到解码器中，以获得其在视觉空间中的嵌入 $\widetilde{\mathcal{C}} \in  {\mathbb{R}}^{c \times  m}$。然后对 $\widetilde{\mathcal{C}}$ 和融合后的视觉特征 ${\mathbf{V}}_{f} \in  {\mathbb{R}}^{m}$ 进行乘法运算，其中 ${\mathbf{V}}_{f}$ 是 $\mathbf{V}$ 和 $\widetilde{\mathbf{V}}$ 的逐元素相加:

$$
\mathbf{s} = \widetilde{\mathcal{C}}{\mathbf{V}}_{f} \tag{10}
$$

A cross-entropy loss is also adopted for smaller classification discrepancy:

为了减小分类差异，还采用了交叉熵损失:

$$
{\mathcal{L}}_{cls} =  - \mathop{\sum }\limits_{{i = 1}}^{n}{y}_{i} * \log \left( \frac{\exp \left( {\mathbf{s}\left\lbrack  {y}_{i}\right\rbrack  }\right) }{\mathop{\sum }\limits_{j}\exp \left( {\mathbf{s}\left\lbrack  j\right\rbrack  }\right) }\right)  \tag{11}
$$

![0195da3a-d6fe-731a-8c38-789b90affb5c_3_422_166_880_601_0.jpg](images/0195da3a-d6fe-731a-8c38-789b90affb5c_3_422_166_880_601_0.jpg)

Fig. 2. The framework of the proposed visual-guided attentive attributes embedding model.

图 2. 所提出的视觉引导注意力属性嵌入模型的框架。

![0195da3a-d6fe-731a-8c38-789b90affb5c_3_420_865_906_620_0.jpg](images/0195da3a-d6fe-731a-8c38-789b90affb5c_3_420_865_906_620_0.jpg)

Fig. 3. An illustration of the proposed attentive attributes module.

图 3. 所提出的注意力属性模块的示意图。

The entire VGAAE is trained by the following overall loss function:

整个视觉引导注意力属性嵌入模型(VGAAE)通过以下总体损失函数进行训练:

$$
\mathcal{L} = \lambda {\mathcal{L}}_{\text{att }} + \eta {\mathcal{L}}_{\text{vis }} + {\mathcal{L}}_{\text{cls }} \tag{12}
$$

where $\lambda$ and $\eta$ are two balancing factors.

其中 $\lambda$ 和 $\eta$ 是两个平衡因子。

### 3.4. Zero-shot recognition

### 3.4 零样本识别

Training the full VGAAE model is described as Algorithm 1. Once the training procedure is done, the unseen instances can then be fed into the network. After obtaining ${\mathbf{s}}_{u}$ by Eq. (10), the most matched class of the input samples ${\widetilde{y}}_{u} \in  {\mathcal{Y}}^{u}$ can be assigned by

完整的 VGAAE 模型的训练过程如算法 1 所示。一旦训练过程完成，就可以将未见实例输入到网络中。通过公式(10)得到 ${\mathbf{s}}_{u}$ 后，可以通过以下方式为输入样本 ${\widetilde{y}}_{u} \in  {\mathcal{Y}}^{u}$ 分配最匹配的类别

$$
\widetilde{{y}_{u}} = \arg \max {\mathbf{s}}_{u} \tag{13}
$$

## 4. Experiments

## 4 实验

In this section, we examine our proposed model by carrying out several experiments on some benchmarks for ZSL and GZSL.

在本节中，我们通过在一些零样本学习(ZSL)和广义零样本学习(GZSL)基准数据集上进行几个实验来检验我们提出的模型。

### 4.1. Datasets descriptions

### 4.1. 数据集描述

Four small-scale benchmark datasets are used to evaluate the effectiveness of our proposed model, i.e., SUN Attributes (SUN) (Patterson, Xu, Su, & Hays, 2014), a Pascal and Yahoo (aPY) (Farhadi, Endres, Hoiem, & Forsyth, 2009), Animal with Attributes (AWA) (Lampert et al., 2014) and Animal with Attributes 2 (AWA2) (Xian, Lampert, Schiele, & Akata, 2018). SUN is composed of 14,340 images from 717 different scenes annotated with 102 attributes. APY contains 15,339 images from 32 classes annotated with 54 attributes. AWA and AWA2 have same 50 animal categories annotated with 85 attributes, including 30,475 images and 37,322 images respectively. Table 1 represents the number of classes split for training and test on these four datasets. All these four datasets are evaluated under two different settings, standard splits (SS) and proposed splits (PS) (Xian et al., 2018). The latter PS setting guarantees the test samples are from unseen classes after extracting features by ResNet-101 pretrained on ImageNet.

使用四个小规模基准数据集来评估我们提出的模型的有效性，即SUN属性数据集(SUN)(Patterson、Xu、Su和Hays，2014年)、Pascal和Yahoo数据集(aPY)(Farhadi、Endres、Hoiem和Forsyth，2009年)、带属性的动物数据集(AWA)(Lampert等人，2014年)和带属性的动物数据集2(AWA2)(Xian、Lampert、Schiele和Akata，2018年)。SUN由来自717个不同场景的14340张图像组成，这些图像标注了102个属性。aPY包含来自32个类别的15339张图像，标注了54个属性。AWA和AWA2有相同的50个动物类别，标注了85个属性，分别包含30475张和37322张图像。表1展示了这四个数据集用于训练和测试的类别数量划分。这四个数据集都在两种不同的设置下进行评估，即标准划分(SS)和提出的划分(PS)(Xian等人，2018年)。后者的PS设置确保在通过在ImageNet上预训练的ResNet - 101提取特征后，测试样本来自未见类别。

![0195da3a-d6fe-731a-8c38-789b90affb5c_4_407_151_922_828_0.jpg](images/0195da3a-d6fe-731a-8c38-789b90affb5c_4_407_151_922_828_0.jpg)

Fig. 4. The acc $\left( \% \right)$ under PS setting influenced by various number of hidden features of encoder/decoder.

图4. 在PS设置下，准确率$\left( \% \right)$受编码器/解码器不同数量隐藏特征的影响。

Algorithm 1 Training procedure of VGAAE.

算法1 VGAAE的训练过程。

---

Input:

输入:

		The number of epochs ${N}_{epo}$ , training set $\mathcal{S}$ with $n$ labeled

		训练轮数${N}_{epo}$，带有$n$个标注的训练集$\mathcal{S}$

		samples, the balancing parameters $\lambda$ and $\eta$ .

		平衡参数$\lambda$和$\eta$。

Output:

输出:

		Trained model VGAAE(   ).

		训练好的模型VGAAE(   )。

		for iter $= \left\lbrack  {1,2,\ldots ,{N}_{\text{epo }}}\right\rbrack$ do

		对于迭代次数$= \left\lbrack  {1,2,\ldots ,{N}_{\text{epo }}}\right\rbrack$执行以下操作

			for $i$ in $\left\lbrack  {1,2,\ldots , n}\right\rbrack$ do

			对于$i$在$\left\lbrack  {1,2,\ldots , n}\right\rbrack$中执行以下操作

				${\widetilde{\mathbf{a}}}_{i} \leftarrow  F\left( {\mathbf{V}}_{i}\right) ;$

				${\mathbf{p}}_{i} \leftarrow  {AAM}\left( {\widetilde{\mathbf{a}}}_{i}\right)$ ;

				${\widetilde{\mathbf{V}}}_{i} \leftarrow  G\left( {\mathbf{p}}_{i}\right) ;$

			end for

			结束循环

			Compute the attribute reconstruction loss ${\mathcal{L}}_{\text{att }}$ by Eq. (2);

			通过公式(2)计算属性重建损失${\mathcal{L}}_{\text{att }}$；

			Compute the feature reconstruction loss ${\mathcal{L}}_{vis}$ by Eq. (9);

			通过公式(9)计算特征重建损失${\mathcal{L}}_{vis}$；

			Compute the cross-entropy loss ${\mathcal{L}}_{cls}$ by Eq. (11);

			通过公式(11)计算交叉熵损失${\mathcal{L}}_{cls}$；

			Minimize the overall loss $\mathcal{L}$ by Eq. (12);

			通过公式(12)最小化总体损失$\mathcal{L}$；

		end for

		结束循环

---

Table 1

表1

Number of classes for training and test on the four benchmarks.

四个基准数据集上训练和测试的类别数量。

<table><tr><td>Datasets</td><td>$c + {c}_{u}$</td><td>$C$</td><td>${C}_{u}$</td></tr><tr><td>SUN</td><td>717</td><td>645</td><td>72</td></tr><tr><td>aPY</td><td>32</td><td>20</td><td>12</td></tr><tr><td>AWA</td><td>50</td><td>40</td><td>10</td></tr><tr><td>AWA2</td><td>50</td><td>40</td><td>10</td></tr></table>

<table><tbody><tr><td>数据集</td><td>$c + {c}_{u}$</td><td>$C$</td><td>${C}_{u}$</td></tr><tr><td>太阳(SUN)</td><td>717</td><td>645</td><td>72</td></tr><tr><td>属性化的帕斯卡和雅虎数据集(aPY)</td><td>32</td><td>20</td><td>12</td></tr><tr><td>动物属性数据集(AWA)</td><td>50</td><td>40</td><td>10</td></tr><tr><td>动物属性数据集2(AWA2)</td><td>50</td><td>40</td><td>10</td></tr></tbody></table>

### 4.2. Evaluations

### 4.2. 评估

Following Xian et al. (2018), we compare our proposed model with the state-of-the-art approaches under SS/PS settings on the aforementioned datasets. The CNN backbones can be jointly trained with our model, but here, we use the features extracted from the 101-layered ResNet as the visual feature space with 2048-dim (He, Zhang, Ren, & Sun, 2016) for fair comparison.

遵循Xian等人(2018年)的方法，我们在上述数据集的单源(SS)/多源(PS)设置下，将我们提出的模型与最先进的方法进行了比较。卷积神经网络(CNN)骨干网络可以与我们的模型联合训练，但为了公平比较，这里我们使用从101层残差网络(ResNet)提取的特征作为2048维的视觉特征空间(He、Zhang、Ren和Sun，2016年)。

Additionally, instead of top-1 accuracy of all samples, we measure average per-class top-1 accuracy (acc) which can better evaluate the performance of models for ZSL:

此外，我们不采用所有样本的前1准确率，而是测量每类平均前1准确率(acc)，它能更好地评估零样本学习(ZSL)模型的性能:

$$
{ac}{c}_{y} = \frac{1}{\parallel y\parallel }\mathop{\sum }\limits_{{\parallel y\parallel }}\frac{\# \text{ correct predictions of current class }}{\# \text{ samples of current class }} \tag{14}
$$

For GZSL task, the prediction space includes both seen classes and unseen classes. To evaluate the performance of methods under this setting, harmonic mean of seen and unseen average per-class top-1 accuracies, i.e., ${ac}{c}_{tr}$ and ${ac}{c}_{ts}$ respectively, is computed by the formula:

对于广义零样本学习(GZSL)任务，预测空间包括已见类和未见类。为了评估该设置下方法的性能，通过以下公式计算已见和未见类平均每类前1准确率的调和均值，即分别为${ac}{c}_{tr}$和${ac}{c}_{ts}$:

$$
\mathbf{H} = \frac{2 \times  {ac}{c}_{tr} \times  {ac}{c}_{ts}}{{ac}{c}_{tr} + {ac}{c}_{ts}} \tag{15}
$$

### 4.3. Implementation details

### 4.3. 实现细节

In our model, there are only three hyperparameters, i.e., the dimension of hidden features, the balancing factors $\lambda$ and $\eta$ . The dimension of hidden features is set to 1024 and default value according to the analysis in Fig. 4. Besides, we select various pairs for the balancing factors $\lambda$ and $\eta$ from $\lbrack {0.001},{0.01},{0.1}$ , $1,{10}\rbrack$ shown in Fig. 5, and set(1,1)as the default pair. When optimizing, the Adam optimizer is used with a base learning rate of ${10}^{-4}$ . We utilize ReLU as the nonlinear activation function for all the hidden layers.

在我们的模型中，只有三个超参数，即隐藏特征的维度、平衡因子$\lambda$和$\eta$。根据图4的分析，隐藏特征的维度设置为1024并采用默认值。此外，我们从图5所示的$\lbrack {0.001},{0.01},{0.1}$、$1,{10}\rbrack$中为平衡因子$\lambda$和$\eta$选择不同的对，并将(1,1)作为默认对。优化时，使用Adam优化器，基础学习率为${10}^{-4}$。我们对所有隐藏层使用修正线性单元(ReLU)作为非线性激活函数。

### 4.4. Performance on ZSL

### 4.4. 零样本学习(ZSL)的性能

#### 4.4.1. Convergence analysis

#### 4.4.1. 收敛性分析

We conduct experiments on AWA and AWA2 datasets under PS/SS settings for convergence analysis. The training losses w.r.t different steps are shown in Fig. 6. It can be seen that the losses drop quickly at the beginning and converge after about 1000 steps. This demonstrates that the training process of our method is efficient.

我们在属性动物数据集(AWA)和属性动物数据集2(AWA2)上进行了单源(SS)/多源(PS)设置下的实验，以进行收敛性分析。不同步骤的训练损失如图6所示。可以看出，损失在开始时迅速下降，并在约1000步后收敛。这表明我们的方法训练过程高效。

![0195da3a-d6fe-731a-8c38-789b90affb5c_5_413_158_890_284_0.jpg](images/0195da3a-d6fe-731a-8c38-789b90affb5c_5_413_158_890_284_0.jpg)

Fig. 5. The acc $\left( \% \right)$ versus different parameter values of $\lambda$ and $\eta$ on (a) SUN dataset,(b) AWA2 dataset and (c) aPY dataset under PS setting. The model with each pair is trained for 10 epochs.

图5. 在多源(PS)设置下，(a)太阳场景数据集(SUN)、(b)属性动物数据集2(AWA2)和(c)属性人物数据集(aPY)上，准确率$\left( \% \right)$与$\lambda$和$\eta$不同参数值的关系。每个参数对的模型训练10个周期。

![0195da3a-d6fe-731a-8c38-789b90affb5c_5_382_563_935_922_0.jpg](images/0195da3a-d6fe-731a-8c38-789b90affb5c_5_382_563_935_922_0.jpg)

Fig. 6. The training losses of our method on AWA and AWA2 datasets under SS setting and PS setting.

图6. 我们的方法在单源(SS)和多源(PS)设置下，在属性动物数据集(AWA)和属性动物数据集2(AWA2)上的训练损失。

#### 4.4.2. Results analysis

#### 4.4.2. 结果分析

For zero-shot learning, we first compare our proposed method against the aforementioned state-of-the-art methods under SS/PS settings. The results are summarized in Table 2. It can be seen that our proposed VGAAE model achieves the best on all the datasets split by SS. In particular, on SUN dataset, 74.6% of ours is much higher than the second best 63.5% of SeeNet-HAF (Jin et al., 2019), which indicates a significant boost of 11.1%. Under PS setting, VGAAE is slight lower than TCN (Jiang et al., 2019) but still outperforms the other approaches on AWA and SUN. Specifically, we observe that VGAAE beats the encoder-decoder based methods SAE (Kodirov et al., 2017) and LESAE (Liu et al., 2018), attributes selection methods AS (Guo et al., 2018) and LFGAA (Liu et al., 2019), and the class prototypes embedding method DEM (Zhang et al., 2017) under both SS and PS settings. Furthermore, taking unseen dataset of AWA2 as an example, we further compare the distributions of the ground truth of this dataset, predictions from DEM and ours by t-SNE (Maaten & Hinton, 2008). Fig. 7 shows the t-SNE visualization of ResNet-101 features of AWA2 dataset from random 10 unseen classes. Each class is tagged by specific color. And the correct predictions are marked with solid circle while the wrong ones are marked with cross. It is obvious that both of the DEM and VGAAE can perform well on "sheep", "bobcat", "giraffe", "horse", and "walrus". And on the rest classes, the wrong labels account for the major part. Specifically, the DEM barely classifies all the instances of "seal" into "rat" while exemplars of "rat" are predicted to "horse". For our VGAAE, the result is much better.

对于零样本学习，我们首先在单源(SS)/多源(PS)设置下，将我们提出的方法与上述最先进的方法进行比较。结果总结在表2中。可以看出，我们提出的视觉生成对抗自编码器(VGAAE)模型在所有单源(SS)分割的数据集上表现最佳。特别是在太阳场景数据集(SUN)上，我们的模型准确率为74.6%，远高于第二好的SeeNet - HAF(Jin等人，2019年)的63.5%，提升了11.1%。在多源(PS)设置下，视觉生成对抗自编码器(VGAAE)略低于时间卷积网络(TCN)(Jiang等人，2019年)，但在属性动物数据集(AWA)和太阳场景数据集(SUN)上仍优于其他方法。具体来说，我们观察到，在单源(SS)和多源(PS)设置下，视觉生成对抗自编码器(VGAAE)都优于基于编码器 - 解码器的方法堆叠自编码器(SAE)(Kodirov等人，2017年)和低嵌入堆叠自编码器(LESAE)(Liu等人，2018年)、属性选择方法属性选择(AS)(Guo等人，2018年)和局部特征引导注意力自编码器(LFGAA)(Liu等人，2019年)以及类原型嵌入方法判别嵌入模型(DEM)(Zhang等人，2017年)。此外，以属性动物数据集2(AWA2)的未见数据集为例，我们进一步通过t - 分布随机邻域嵌入(t - SNE)(Maaten和Hinton，2008年)比较了该数据集的真实标签分布、判别嵌入模型(DEM)和我们模型的预测分布。图7展示了属性动物数据集2(AWA2)中随机10个未见类别的残差网络 - 101(ResNet - 101)特征的t - SNE可视化结果。每个类别用特定颜色标记。正确预测用实心圆标记，错误预测用叉号标记。显然，判别嵌入模型(DEM)和视觉生成对抗自编码器(VGAAE)在“绵羊”“山猫”“长颈鹿”“马”和“海象”类别上都表现良好。在其余类别中，错误标签占大部分。具体来说，判别嵌入模型(DEM)几乎将“海豹”的所有实例都分类为“老鼠”，而“老鼠”的样本被预测为“马”。对于我们的视觉生成对抗自编码器(VGAAE)，结果要好得多。

#### 4.4.3. Effects of attention

#### 4.4.3. 注意力机制的影响

To evaluate the effects of the proposed attention module, we conduct some extensive experiments under PS setting. Firstly, Fig. 8 illustrates two examples of the attention values of each attribute on aPY and AWA2 unseen datasets after training the proposed model. The higher the value is, the more important the corresponding attribute is. Then, the attention values are applied to the attributes to take part in the final predictions. Secondly, to study this influence of AAM, we also conduct ablation study on SUN dataset under PS setting, shown in Table 3. We denote w/o AAM as no AAM is participated in the training and w AAM is on the contrary. And the columns are corresponding reconstruction losses for optimization. For example, the first column is the acc results that only ${\mathcal{L}}_{\text{vis }}$ with ${\mathcal{L}}_{\text{cls }}$ loss is involved. It is clear that training with AAM can obtain higher accuracy, which demonstrates the efficiency of the attention employed in our model. Furthermore, we also conduct the experiments to quantitate the reweighed attributes by calculating the Kendall rank correlation (Abdi, 2007), which is a measure of the correspondence between two ordinal variables. From Table 4, we can see the correlation coefficients on the three datasets at the 0.05 level. The Reconstructed Attr denotes the attributes embedded from original visual features, and the Reweighed by AAM denotes the reweighed attributes that are obtained via AAM. Both of the above are calculated the rank correlation with ground-truth attributes. It is obvious that the correlation scores are higher after the reconstructed attributes being reweighed by AAM. In particular, the coefficient of reweighed attributes gets a near medium direct relationship on the aPY dataset.

为了评估所提出的注意力模块的效果，我们在PS设置下进行了一些广泛的实验。首先，图8展示了在训练所提出的模型后，aPY和AWA2未见数据集上每个属性的注意力值的两个示例。值越高，相应属性就越重要。然后，将注意力值应用于属性以参与最终预测。其次，为了研究AAM(注意力调整模块，Attention Adjustment Module)的影响，我们还在PS设置下对SUN数据集进行了消融研究，如表3所示。我们用“w/o AAM”表示训练中不参与AAM，“w AAM”则相反。各列是用于优化的相应重建损失。例如，第一列是仅涉及${\mathcal{L}}_{\text{vis }}$和${\mathcal{L}}_{\text{cls }}$损失的准确率结果。显然，使用AAM进行训练可以获得更高的准确率，这证明了我们模型中所采用的注意力机制的有效性。此外，我们还通过计算肯德尔等级相关性(Abdi, 2007)进行实验来量化重新加权的属性，肯德尔等级相关性是衡量两个有序变量之间对应关系的一种方法。从表4中，我们可以看到三个数据集在0.05水平上的相关系数。“Reconstructed Attr”表示从原始视觉特征中嵌入的属性，“Reweighed by AAM”表示通过AAM获得的重新加权的属性。以上两者都计算了与真实属性的等级相关性。显然，在通过AAM对重建属性进行重新加权后，相关得分更高。特别是，重新加权属性的系数在aPY数据集上获得了接近中等的直接关系。

Table 2

表2

The top-1 accuracy (%) of zero-shot learning on different datasets under SS/PS settings. The highest accuracies are highlighted with bold numbers.

在SS/PS设置下，不同数据集上零样本学习的前1准确率(%)。最高准确率用粗体数字突出显示。

<table><tr><td/><td rowspan="2">Methods</td><td colspan="2">AWA</td><td colspan="2">AWA2</td><td colspan="2">SUN</td><td colspan="2">aPY</td></tr><tr><td/><td>SS</td><td>PS</td><td>SS</td><td>PS</td><td>SS</td><td>PS</td><td>SS</td><td>PS</td></tr><tr><td rowspan="9">†</td><td>DAP [(Lampert et al., 2014)]</td><td>57.1</td><td>44.1</td><td>58.7</td><td>46.1</td><td>38.9</td><td>39.9</td><td>35.2</td><td>33.8</td></tr><tr><td>IAP [(Lampert et al., 2014)]</td><td>48.1</td><td>35.9</td><td>46.9</td><td>35.9</td><td>17.4</td><td>19.4</td><td>22.4</td><td>36.6</td></tr><tr><td>ESZSL [(Romera-Paredes & Torr, 2015)]</td><td>74.7</td><td>58.2</td><td>75.6</td><td>58.6</td><td>57.3</td><td>54.5</td><td>34.4</td><td>38.3</td></tr><tr><td>LATEM [(Xian et al., 2016)]</td><td>74.8</td><td>55.1</td><td>68.7</td><td>55.8</td><td>56.9</td><td>55.3</td><td>34.5</td><td>35.2</td></tr><tr><td>ALE [(Akata et al., 2016)]</td><td>78.6</td><td>59.9</td><td>80.3</td><td>62.5</td><td>59.1</td><td>58.1</td><td>30.9</td><td>39.7</td></tr><tr><td>GFZSL [(Verma & Rai, 2017)]</td><td>80.5</td><td>68.3</td><td>79.3</td><td>63.8</td><td>62.9</td><td>60.6</td><td>51.3</td><td>38.4</td></tr><tr><td>DEVISE [(Frome et al., 2013)]</td><td>72.9</td><td>54.2</td><td>68.6</td><td>59.7</td><td>57.5</td><td>56.5</td><td>35.4</td><td>39.8</td></tr><tr><td>SAE [(Kodirov et al., 2017)]</td><td>80.6</td><td>53.0</td><td>80.7</td><td>54.1</td><td>42.4</td><td>40.3</td><td>8.3</td><td>8.3</td></tr><tr><td>LESAE [(Liu et al., 2018)]</td><td>-</td><td>66.1</td><td>-</td><td>68.4</td><td>-</td><td>60.0</td><td>-</td><td>40.8</td></tr><tr><td rowspan="3">‡</td><td>DEM * [(Zhang et al., 2017)]</td><td>-</td><td>68.4</td><td>-</td><td>67.1</td><td>-</td><td>61.9</td><td>-</td><td>35.0</td></tr><tr><td>GAZSL * [(Zhu et al., 2018)]</td><td>-</td><td>68.2</td><td>-</td><td>70.2</td><td>-</td><td>61.3</td><td>-</td><td>41.1</td></tr><tr><td>TCN [(Jiang et al., 2019)]</td><td>-</td><td>70.3</td><td>-</td><td>71.2</td><td>-</td><td>61.5</td><td>-</td><td>38.9</td></tr><tr><td rowspan="3">土</td><td>AREN [(Xie et al., 2019)]</td><td>-</td><td>-</td><td>86.7</td><td>67.9</td><td>61.7</td><td>60.6</td><td>44.1</td><td>39.2</td></tr><tr><td>SeeNet-HAF [(Jin et al., 2019)]</td><td>-</td><td>-</td><td>87.1</td><td>67.2</td><td>63.5</td><td>62.5</td><td>45.7</td><td>38.3</td></tr><tr><td>RN [(Sung et al., 2018)]</td><td>-</td><td>68.2</td><td>-</td><td>64.2</td><td>-</td><td>-</td><td>-</td><td>-</td></tr><tr><td rowspan="2">$b$</td><td>ALE+AS [(Guo et al., 2018)]</td><td>-</td><td>-</td><td>-</td><td>64.4</td><td>-</td><td>60.5</td><td>-</td><td>43.4</td></tr><tr><td>LFGAA [(Liu et al., 2019)]</td><td>-</td><td>-</td><td>84.3</td><td>68.1</td><td>62.0</td><td>61.5</td><td>-</td><td>-</td></tr><tr><td/><td>Ours</td><td>85.4</td><td>69.8</td><td>88.4</td><td>69.6</td><td>74.6</td><td>67.0</td><td>46.4</td><td>43.6</td></tr></table>

<table><tbody><tr><td></td><td rowspan="2">方法</td><td colspan="2">AWA</td><td colspan="2">AWA2</td><td colspan="2">SUN</td><td colspan="2">aPY</td></tr><tr><td></td><td>SS</td><td>PS</td><td>SS</td><td>PS</td><td>SS</td><td>PS</td><td>SS</td><td>PS</td></tr><tr><td rowspan="9">†</td><td>判别式属性投影法(DAP)[(兰珀特等人，2014年)]</td><td>57.1</td><td>44.1</td><td>58.7</td><td>46.1</td><td>38.9</td><td>39.9</td><td>35.2</td><td>33.8</td></tr><tr><td>归纳式属性投影法(IAP)[(兰珀特等人，2014年)]</td><td>48.1</td><td>35.9</td><td>46.9</td><td>35.9</td><td>17.4</td><td>19.4</td><td>22.4</td><td>36.6</td></tr><tr><td>嵌入空间零样本学习法(ESZSL)[(罗梅拉 - 帕雷德斯和托尔，2015年)]</td><td>74.7</td><td>58.2</td><td>75.6</td><td>58.6</td><td>57.3</td><td>54.5</td><td>34.4</td><td>38.3</td></tr><tr><td>后期嵌入映射法(LATEM)[(西安等人，2016年)]</td><td>74.8</td><td>55.1</td><td>68.7</td><td>55.8</td><td>56.9</td><td>55.3</td><td>34.5</td><td>35.2</td></tr><tr><td>对抗学习嵌入法(ALE)[(阿卡塔等人，2016年)]</td><td>78.6</td><td>59.9</td><td>80.3</td><td>62.5</td><td>59.1</td><td>58.1</td><td>30.9</td><td>39.7</td></tr><tr><td>广义零样本学习法(GFZSL)[(维尔马和拉伊，2017年)]</td><td>80.5</td><td>68.3</td><td>79.3</td><td>63.8</td><td>62.9</td><td>60.6</td><td>51.3</td><td>38.4</td></tr><tr><td>设备法(DEVISE)[(弗罗姆等人，2013年)]</td><td>72.9</td><td>54.2</td><td>68.6</td><td>59.7</td><td>57.5</td><td>56.5</td><td>35.4</td><td>39.8</td></tr><tr><td>堆叠自动编码器法(SAE)[(科迪罗夫等人，2017年)]</td><td>80.6</td><td>53.0</td><td>80.7</td><td>54.1</td><td>42.4</td><td>40.3</td><td>8.3</td><td>8.3</td></tr><tr><td>低嵌入堆叠自动编码器法(LESAE)[(刘等人，2018年)]</td><td>-</td><td>66.1</td><td>-</td><td>68.4</td><td>-</td><td>60.0</td><td>-</td><td>40.8</td></tr><tr><td rowspan="3">‡</td><td>判别式嵌入模型(DEM)* [(张等人，2017年)]</td><td>-</td><td>68.4</td><td>-</td><td>67.1</td><td>-</td><td>61.9</td><td>-</td><td>35.0</td></tr><tr><td>生成式零样本学习法(GAZSL)* [(朱等人，2018年)]</td><td>-</td><td>68.2</td><td>-</td><td>70.2</td><td>-</td><td>61.3</td><td>-</td><td>41.1</td></tr><tr><td>时间卷积网络法(TCN)[(江等人，2019年)]</td><td>-</td><td>70.3</td><td>-</td><td>71.2</td><td>-</td><td>61.5</td><td>-</td><td>38.9</td></tr><tr><td rowspan="3">土</td><td>注意力关系网络法(AREN)[(谢等人，2019年)]</td><td>-</td><td>-</td><td>86.7</td><td>67.9</td><td>61.7</td><td>60.6</td><td>44.1</td><td>39.2</td></tr><tr><td>SeeNet - 混合注意力融合法(SeeNet - HAF)[(金等人，2019年)]</td><td>-</td><td>-</td><td>87.1</td><td>67.2</td><td>63.5</td><td>62.5</td><td>45.7</td><td>38.3</td></tr><tr><td>关系网络法(RN)[(宋等人，2018年)]</td><td>-</td><td>68.2</td><td>-</td><td>64.2</td><td>-</td><td>-</td><td>-</td><td>-</td></tr><tr><td rowspan="2">$b$</td><td>对抗学习嵌入法 + 注意力选择法(ALE + AS)[(郭等人，2018年)]</td><td>-</td><td>-</td><td>-</td><td>64.4</td><td>-</td><td>60.5</td><td>-</td><td>43.4</td></tr><tr><td>局部特征引导注意力聚合法(LFGAA)[(刘等人，2019年)]</td><td>-</td><td>-</td><td>84.3</td><td>68.1</td><td>62.0</td><td>61.5</td><td>-</td><td>-</td></tr><tr><td></td><td>我们的方法</td><td>85.4</td><td>69.8</td><td>88.4</td><td>69.6</td><td>74.6</td><td>67.0</td><td>46.4</td><td>43.6</td></tr></tbody></table>

$\dagger$ indicates the classical ZSL methods. $\ddagger$ indicates the methods that synthesize visual features. $\natural$ indicates the end-to-end methods. $\flat$ indicates the methods using attributes selection.

$\dagger$ 表示经典的零样本学习(ZSL)方法。$\ddagger$ 表示合成视觉特征的方法。$\natural$ 表示端到端的方法。$\flat$ 表示使用属性选择的方法。

* indicates that ResNet101 is not used as backbone.

* 表示未使用 ResNet101 作为骨干网络。

![0195da3a-d6fe-731a-8c38-789b90affb5c_6_369_896_977_346_0.jpg](images/0195da3a-d6fe-731a-8c38-789b90affb5c_6_369_896_977_346_0.jpg)

Fig. 7. The t-SNE visualization of features from random 10 unseen classes on AWA2 dataset. Each color indicated a specific class. Wrong and right labels are respectively marked with cross and solid circle. (a) is the ground truth, (b) is the result of DEM, and (c) is the that of ours.

图 7. AWA2 数据集上随机 10 个未见类别的特征的 t-SNE 可视化结果。每种颜色代表一个特定的类别。错误和正确的标签分别用叉号和实心圆标记。(a) 是真实标签，(b) 是 DEM 方法的结果，(c) 是我们方法的结果。

![0195da3a-d6fe-731a-8c38-789b90affb5c_6_361_1357_1018_466_0.jpg](images/0195da3a-d6fe-731a-8c38-789b90affb5c_6_361_1357_1018_466_0.jpg)

Fig. 8. Visualization of the attention value $\beta$ on unseen classes of aPY dataset and AWA2 dataset.

图 8. aPY 数据集和 AWA2 数据集未见类别上的注意力值 $\beta$ 的可视化结果。

![0195da3a-d6fe-731a-8c38-789b90affb5c_7_377_151_994_541_0.jpg](images/0195da3a-d6fe-731a-8c38-789b90affb5c_7_377_151_994_541_0.jpg)

Fig. 9. Illustration of some top attention values of one image from training set and test set after ten epochs on AWA2, SUN and aPY datasets. Attn_val=Attention value, Attr_val=Continuous attribute value.

图 9. AWA2、SUN 和 aPY 数据集经过 10 个训练周期后，训练集和测试集中一张图像的一些最高注意力值的示意图。Attn_val = 注意力值，Attr_val = 连续属性值。

Table 3

表 3

Ablation study of VGAAE on SUN dataset measured by acc (%) trained 10 epochs.

在 SUN 数据集上对 VGAAE 进行消融实验，以准确率(%)衡量，训练 10 个周期。

<table><tr><td>Components</td><td>${\mathcal{L}}_{\text{vis }}$</td><td>${\mathcal{L}}_{\text{att }}$</td><td>${\mathcal{L}}_{\text{vis }} + {\mathcal{L}}_{\text{att }}$</td></tr><tr><td>w/o AAM</td><td>61.5</td><td>62.1</td><td>64.2</td></tr><tr><td>w AAM</td><td>63.3</td><td>63.8</td><td>67.0</td></tr></table>

<table><tbody><tr><td>组件</td><td>${\mathcal{L}}_{\text{vis }}$</td><td>${\mathcal{L}}_{\text{att }}$</td><td>${\mathcal{L}}_{\text{vis }} + {\mathcal{L}}_{\text{att }}$</td></tr><tr><td>无丙烯酰胺(AAM)</td><td>61.5</td><td>62.1</td><td>64.2</td></tr><tr><td>有丙烯酰胺(AAM)</td><td>63.3</td><td>63.8</td><td>67.0</td></tr></tbody></table>

Table 4

表4

Kendall rank correlation coefficients of Reconstructed Attributes (Reconstructed Attr) and Reweighed Attributes by AAM (Reweighed by AAM) on aPY, AWA2 and SUN datasets.

在aPY、AWA2和SUN数据集上，重建属性(Reconstructed Attr)和通过AAM重新加权的属性(Reweighed by AAM)的肯德尔秩相关系数。

<table><tr><td/><td>aPY</td><td>AWA2</td><td>SUN</td></tr><tr><td>Reconstructed Attr</td><td>0.15</td><td>-0.02</td><td>0.02</td></tr><tr><td>Reweighed by AAM</td><td>0.26</td><td>0.12</td><td>0.16</td></tr></table>

<table><tbody><tr><td></td><td>活化蛋白Y(aPY)</td><td>自动写作评估2(AWA2)</td><td>太阳(SUN)</td></tr><tr><td>重建属性(Reconstructed Attr)</td><td>0.15</td><td>-0.02</td><td>0.02</td></tr><tr><td>通过注意力对齐模块重新加权(Reweighed by AAM)</td><td>0.26</td><td>0.12</td><td>0.16</td></tr></tbody></table>

Moreover, Fig. 9 shows some examples for training and test procedure from AWA2, SUN, aPY datasets and their high attentive values attributes with corresponding attribute names and given continuous attribute values. The visual-guided attentive attributes of training are calculated in the tenth epoch. We observe that the four attributes sorted by attribute values are not so consistent with that by the original attribute values. However, it is interesting to see (1) for the objects, which is fully presented in the images, the attributes are mainly concrete descriptions like "window", "glass", "face", and "head". (2) the images from categories, such as bakery and airlock, tend to obtain the attentive attributes describing the phenomenon or global features including "no horizon", "indoor lightening" and etc. (3) for different images from each dataset, the scenes are similar while the rank of attributes is distinct. From the observations, we conclude that the visual-guided module is able and effective to capture both local and local visual features to weight corresponding attributes for discriminant.

此外，图9展示了来自AWA2、SUN、aPY数据集的训练和测试过程的一些示例，以及它们具有高关注度值的属性，并列出了相应的属性名称和给定的连续属性值。训练的视觉引导关注属性是在第十个训练周期计算得出的。我们观察到，按属性值排序的四个属性与按原始属性值排序的属性并不完全一致。然而，有趣的是:(1)对于在图像中完整呈现的物体，其属性主要是像“窗户”“玻璃”“脸”和“头部”这样的具体描述；(2)来自诸如面包店和气闸等类别的图像，往往会获得描述现象或全局特征的关注属性，包括“无地平线”“室内照明”等；(3)对于每个数据集中的不同图像，场景相似，但属性的排名不同。从这些观察结果我们可以得出结论，视觉引导模块能够有效地捕捉局部和全局视觉特征，从而对相应的属性进行加权以实现判别。

#### 4.4.4. Analysis of two embedding spaces

#### 4.4.4. 两种嵌入空间的分析

To discuss the effect of embedding attributes from semantic space into visual space, we use the skewness of the ${N}_{k}$ distribution to measure the degree of hubness, following the literatures (Shigeto et al., 2015; Zhang et al., 2017). This measurement is defined as below:

为了探讨将属性从语义空间嵌入到视觉空间的效果，我们遵循相关文献(Shigeto等人，2015；Zhang等人，2017)，使用${N}_{k}$分布的偏度来衡量中心性程度。该测量定义如下:

$$
{N}_{k}\text{ skewness } = \frac{\mathop{\sum }\limits_{{i = 1}}^{l}{\left( {N}_{k}\left( i\right)  - E\left\lbrack  {N}_{k}\right\rbrack  \right) }^{3}/l}{\operatorname{Var}{\left\lbrack  {N}_{k}\right\rbrack  }^{3/2}} \tag{16}
$$

where the ${N}_{k}$ distribution is the distribution of the number ${N}_{k}\left( i\right)$ of times each target prototype $i$ is found in the top- $k$ closest target prototypes of the ranking. $l$ is the total number of test prototypes. It is noted that a larger ${N}_{k}$ skewness score indicates the hubness issue is more severe.

其中，${N}_{k}$分布是每个目标原型$i$在排名前$k$个最接近的目标原型中出现的次数${N}_{k}\left( i\right)$的分布。$l$是测试原型的总数。需要注意的是，${N}_{k}$偏度得分越大，表明中心性问题越严重。

In this experiment, we simplify our model by removing the AAM component. Besides, to analyze the hubness of mapping from visual space to semantic space, we also omit the decoder part so that the embedding space becomes the semantic space. Table 5 shows that on the four datasets, the ${N}_{1},{N}_{10}$ skewness have the consistent lower scores, which demonstrates that the hubness is more emergent when semantic space is seen as the embedding space.

在这个实验中，我们通过移除AAM组件来简化我们的模型。此外，为了分析从视觉空间到语义空间映射的中心性，我们还省略了解码器部分，使得嵌入空间变为语义空间。表5显示，在四个数据集上，${N}_{1},{N}_{10}$偏度得分始终较低，这表明当将语义空间视为嵌入空间时，中心性问题更为突出。

### 4.5. Performance on GZSL

### 4.5. 广义零样本学习(GZSL)任务的性能

GZSL task is generally more complicated than ZSL since traditional methods tend to ignore the unseen data resulting in the domain shift problem. Following Chao, Changpinyo, Gong, and Sha (2016), we introduce calibrated stacking (CS) strategy to reduce the prediction scores for the seen classes by setting a threshold value $\gamma$ . By varying the value of $\gamma$ , we can draw a curve to visualize the trade-off relation between seen classes and unseen classes, namely the Seen-Unseen accuracy Curve (SUC) (Chao et al.,2016). From Fig. 10, both ${ac}{c}_{tr}$ and ${ac}{c}_{ts}$ are increasing as epoch varies from 1 to 10 . Besides, there are two extreme cases of $\gamma$ . When $\gamma$ is set to positive/negative huge number respectively, the classification rule will only consider labels of unseen/seen classes, which appears on the two axes.

广义零样本学习(GZSL)任务通常比零样本学习(ZSL)更复杂，因为传统方法往往会忽略未见数据，从而导致领域偏移问题。遵循Chao、Changpinyo、Gong和Sha(2016)的方法，我们引入校准堆叠(CS)策略，通过设置一个阈值$\gamma$来降低已见类别的预测分数。通过改变$\gamma$的值，我们可以绘制一条曲线来直观展示已见类别和未见类别之间的权衡关系，即已见 - 未见准确率曲线(SUC)(Chao等人，2016)。从图10可以看出，随着训练周期从1到10变化，${ac}{c}_{tr}$和${ac}{c}_{ts}$都在增加。此外，$\gamma$有两种极端情况。当$\gamma$分别设置为正/负极大值时，分类规则将只考虑未见/已见类别的标签，这分别对应于两个坐标轴。

Under the PS setting, we also evaluate our methods as well as several recent approaches on the four benchmarks for the GZSL task shown in Table 6. The first observation is that the results of ours are comparable than the rest approaches except for TCN (Jiang et al., 2019) and AREN+CS (Xie et al., 2019). However, it is obvious that our method has a significant boost after introducing CS (Chao et al., 2016) strategy. This is the effect of alleviating the conflict between recognizing data from seen classes and those from unseen ones on seen data. Compared with the second best methods, the harmonic mean of ours+CS adds up to 11.0% higher for the three datasets, AWA, AWA2 and SUN. In addition, ours+CS consistently behaves better than the state-of-the-art methods on all the four datasets evaluated by ${ac}{c}_{ts}$ . The performance on ${ac}{c}_{ts}$ and harmonic mean indicates that the generalization ability of VGAAE is relatively more robust than the approaches compared.

在PS设置下，我们还在表6所示的四个广义零样本学习(GZSL)任务基准数据集上评估了我们的方法以及几种近期的方法。首先可以观察到，除了TCN(Jiang等人，2019)和AREN + CS(Xie等人，2019)之外，我们的方法的结果与其他方法相当。然而，很明显，在引入CS(Chao等人，2016)策略后，我们的方法有了显著提升。这是因为该策略缓解了在已见数据上识别已见类别数据和未见类别数据之间的冲突。与次优方法相比，在AWA、AWA2和SUN这三个数据集上，我们的方法加上CS策略后的调和均值提高了11.0%。此外，在所有四个数据集上，通过${ac}{c}_{ts}$评估，我们的方法加上CS策略的表现始终优于现有最先进的方法。${ac}{c}_{ts}$和调和均值的表现表明，视觉引导自编码器(VGAAE)的泛化能力比所比较的方法相对更稳健。

![0195da3a-d6fe-731a-8c38-789b90affb5c_8_380_150_987_427_0.jpg](images/0195da3a-d6fe-731a-8c38-789b90affb5c_8_380_150_987_427_0.jpg)

Fig. 10. The Seen-Unseen accuracy Curve (SUC) on aPY and AWA2 datasets, which are obtained by varying the threshold value $\gamma$ . For each dataset, three curves of different training epoch are marked in various colors.

图10. aPY和AWA2数据集上的已见 - 未见准确率曲线(SUC)，通过改变阈值$\gamma$获得。对于每个数据集，不同训练周期的三条曲线用不同颜色标记。

Table 5

表5

${N}_{k}$ skewness $\left( {k = 1,{10}}\right)$ scores and top-1 accuracies on the four aforementioned datasets with different embedding spaces.

${N}_{k}$偏度 $\left( {k = 1,{10}}\right)$得分以及在上述四个不同嵌入空间的数据集上的前1准确率。

<table><tr><td rowspan="2">Direction</td><td colspan="3">aPY</td><td colspan="3">SUN</td><td colspan="3">AWA</td><td colspan="3">AWA2</td></tr><tr><td>${N}_{1}$</td><td>${N}_{10}$</td><td>Acc</td><td>${N}_{1}$</td><td>${N}_{10}$</td><td>Acc</td><td>${N}_{1}$</td><td>${N}_{10}$</td><td>Acc</td><td>${N}_{1}$</td><td>${N}_{10}$</td><td>Acc</td></tr><tr><td>Semantic $\rightarrow$ Visual</td><td>1.53</td><td>1.51</td><td>34.62</td><td>1.46</td><td>1.28</td><td>60.70</td><td>1.39</td><td>1.03</td><td>60.99</td><td>1.62</td><td>1.53</td><td>62.56</td></tr><tr><td>Visual $\rightarrow$ Semantic</td><td>4.72</td><td>1.91</td><td>32.03</td><td>1.90</td><td>1.49</td><td>31.34</td><td>3.56</td><td>2.37</td><td>44.23</td><td>5.57</td><td>2.33</td><td>43.02</td></tr></table>

<table><tbody><tr><td rowspan="2">方向</td><td colspan="3">年度百分比收益率(aPY)</td><td colspan="3">太阳(SUN)</td><td colspan="3">分析性写作评估(AWA)</td><td colspan="3">分析性写作评估2(AWA2)</td></tr><tr><td>${N}_{1}$</td><td>${N}_{10}$</td><td>准确率(Acc)</td><td>${N}_{1}$</td><td>${N}_{10}$</td><td>准确率(Acc)</td><td>${N}_{1}$</td><td>${N}_{10}$</td><td>准确率(Acc)</td><td>${N}_{1}$</td><td>${N}_{10}$</td><td>准确率(Acc)</td></tr><tr><td>语义$\rightarrow$视觉</td><td>1.53</td><td>1.51</td><td>34.62</td><td>1.46</td><td>1.28</td><td>60.70</td><td>1.39</td><td>1.03</td><td>60.99</td><td>1.62</td><td>1.53</td><td>62.56</td></tr><tr><td>视觉$\rightarrow$语义</td><td>4.72</td><td>1.91</td><td>32.03</td><td>1.90</td><td>1.49</td><td>31.34</td><td>3.56</td><td>2.37</td><td>44.23</td><td>5.57</td><td>2.33</td><td>43.02</td></tr></tbody></table>

Table 6

表6

Generalized zero-shot learning results (%) under PS setting. ts $= {ac}{c}_{ts},\mathbf{{tr}} = {ac}{c}_{tr},\mathrm{H} =$ harmonic mean. The best results are highlighted in bold.

PS设置下的广义零样本学习结果(%)。ts $= {ac}{c}_{ts},\mathbf{{tr}} = {ac}{c}_{tr},\mathrm{H} =$ 调和均值。最佳结果以粗体突出显示。

<table><tr><td colspan="2" rowspan="2">Methods</td><td colspan="3">AWA</td><td colspan="3">AWA2</td><td colspan="3">SUN</td><td colspan="3">aPY</td></tr><tr><td>ts</td><td>tr</td><td>H</td><td>ts</td><td>tr</td><td>H</td><td>ts</td><td>tr</td><td>H</td><td>ts</td><td>tr</td><td>H</td></tr><tr><td rowspan="9">†</td><td>DAP [(Lampert et al., 2014)]</td><td>0.0</td><td>88.7</td><td>0.0</td><td>0.0</td><td>84.7</td><td>0.0</td><td>4.2</td><td>25.1</td><td>7.2</td><td>4.8</td><td>78.3</td><td>9.0</td></tr><tr><td>IAP [(Lampert et al., 2014)]</td><td>2.1</td><td>78.2</td><td>4.1</td><td>0.9</td><td>87.6</td><td>1.8</td><td>1.0</td><td>37.8</td><td>1.8</td><td>5.7</td><td>65.6</td><td>10.4</td></tr><tr><td>ESZSL [(Romera-Paredes & Torr, 2015)]</td><td>6.6</td><td>75.6</td><td>12.1</td><td>5.9</td><td>77.8</td><td>11.0</td><td>11.0</td><td>27.9</td><td>15.8</td><td>2.4</td><td>70.1</td><td>4.6</td></tr><tr><td>LATEM [(Xian et al., 2016)]</td><td>7.3</td><td>71.7</td><td>13.3</td><td>11.5</td><td>77.3</td><td>20.0</td><td>14.7</td><td>28.8</td><td>19.5</td><td>0.1</td><td>73.0</td><td>0.2</td></tr><tr><td>ALE [(Akata et al., 2016)]</td><td>16.8</td><td>76.1</td><td>27.5</td><td>14.0</td><td>81.8</td><td>23.9</td><td>21.8</td><td>33.1</td><td>26.3</td><td>4.6</td><td>73.7</td><td>8.7</td></tr><tr><td>GFZSL [(Verma & Rai, 2017)]</td><td>1.8</td><td>80.3</td><td>3.5</td><td>2.5</td><td>80.1</td><td>4.8</td><td>0.0</td><td>39.6</td><td>0.0</td><td>0.0</td><td>83.3</td><td>0.0</td></tr><tr><td>DEVISE [(Frome et al., 2013)]</td><td>13.4</td><td>68.7</td><td>22.4</td><td>17.1</td><td>74.7</td><td>27.8</td><td>16.9</td><td>27.4</td><td>20.9</td><td>4.9</td><td>76.9</td><td>9.2</td></tr><tr><td>SAE [(Kodirov et al., 2017)]</td><td>1.8</td><td>77.1</td><td>3.5</td><td>1.1</td><td>82.2</td><td>2.2</td><td>8.8</td><td>18.0</td><td>11.8</td><td>0.4</td><td>80.9</td><td>0.9</td></tr><tr><td>LESAE [(Liu et al., 2018)]</td><td>19.1</td><td>70.2</td><td>30.0</td><td>21.8</td><td>70.6</td><td>33.3</td><td>21.9</td><td>34.7</td><td>26.9</td><td>12.7</td><td>56.1</td><td>20.1</td></tr><tr><td rowspan="3">↑</td><td>DEM [(Zhang et al., 2017)]</td><td>32.8</td><td>84.7</td><td>47.3</td><td>30.5</td><td>86.4</td><td>45.1</td><td>20.5</td><td>34.3</td><td>25.6</td><td>11.1</td><td>75.1</td><td>19.4</td></tr><tr><td>GAZSL [(Zhu et al., 2018)]</td><td>29.6</td><td>84.2</td><td>43.8</td><td>35.4</td><td>86.9</td><td>50.3</td><td>22.1</td><td>39.3</td><td>28.3</td><td>14.2</td><td>78.6</td><td>24.0</td></tr><tr><td>TCN [(Jiang et al., 2019)]</td><td>49.4</td><td>76.5</td><td>60.0</td><td>61.2</td><td>65.8</td><td>63.4</td><td>31.2</td><td>37.3</td><td>34.0</td><td>24.1</td><td>64.0</td><td>35.1</td></tr><tr><td rowspan="2">日</td><td>AREN+CS [(Xie et al., 2019)]</td><td>-</td><td>-</td><td>-</td><td>54.7</td><td>79.1</td><td>64.7</td><td>40.3</td><td>32.3</td><td>35.9</td><td>30.0</td><td>47.9</td><td>36.9</td></tr><tr><td>RN [(Sung et al., 2018)]</td><td>31.4</td><td>91.3</td><td>46.7</td><td>30.0</td><td>93.4</td><td>45.3</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td></tr><tr><td>$b$</td><td>LFGAA [(Liu et al., 2019)]</td><td>-</td><td>-</td><td>-</td><td>27.0</td><td>93.4</td><td>41.9</td><td>18.5</td><td>40.0</td><td>25.3</td><td>-</td><td>-</td><td>-</td></tr><tr><td/><td>Ours</td><td>19.1</td><td>84.0</td><td>31.1</td><td>21.2</td><td>85.7</td><td>34.0</td><td>27.4</td><td>52.4</td><td>36.0</td><td>23.4</td><td>47.4</td><td>31.3</td></tr><tr><td/><td>Ours+CS</td><td>56.5</td><td>73.0</td><td>63.7</td><td>61.7</td><td>68.3</td><td>65.4</td><td>47.6</td><td>38.2</td><td>42.6</td><td>29.2</td><td>47.2</td><td>36.1</td></tr></table>

<table><tbody><tr><td colspan="2" rowspan="2">方法</td><td colspan="3">AWA(可能是特定缩写，未明确通用译法)</td><td colspan="3">AWA2(可能是特定缩写，未明确通用译法)</td><td colspan="3">SUN(可能是特定缩写，未明确通用译法)</td><td colspan="3">aPY(可能是特定缩写，未明确通用译法)</td></tr><tr><td>ts(可能是特定缩写，未明确通用译法)</td><td>tr(可能是特定缩写，未明确通用译法)</td><td>H</td><td>ts(可能是特定缩写，未明确通用译法)</td><td>tr(可能是特定缩写，未明确通用译法)</td><td>H</td><td>ts(可能是特定缩写，未明确通用译法)</td><td>tr(可能是特定缩写，未明确通用译法)</td><td>H</td><td>ts(可能是特定缩写，未明确通用译法)</td><td>tr(可能是特定缩写，未明确通用译法)</td><td>H</td></tr><tr><td rowspan="9">†</td><td>判别式属性预测法(DAP)[(兰珀特等人，2014年)]</td><td>0.0</td><td>88.7</td><td>0.0</td><td>0.0</td><td>84.7</td><td>0.0</td><td>4.2</td><td>25.1</td><td>7.2</td><td>4.8</td><td>78.3</td><td>9.0</td></tr><tr><td>归纳式属性预测法(IAP)[(兰珀特等人，2014年)]</td><td>2.1</td><td>78.2</td><td>4.1</td><td>0.9</td><td>87.6</td><td>1.8</td><td>1.0</td><td>37.8</td><td>1.8</td><td>5.7</td><td>65.6</td><td>10.4</td></tr><tr><td>嵌入空间零样本学习法(ESZSL)[(罗梅拉 - 帕雷德斯和托尔，2015年)]</td><td>6.6</td><td>75.6</td><td>12.1</td><td>5.9</td><td>77.8</td><td>11.0</td><td>11.0</td><td>27.9</td><td>15.8</td><td>2.4</td><td>70.1</td><td>4.6</td></tr><tr><td>后期嵌入映射法(LATEM)[(西安等人，2016年)]</td><td>7.3</td><td>71.7</td><td>13.3</td><td>11.5</td><td>77.3</td><td>20.0</td><td>14.7</td><td>28.8</td><td>19.5</td><td>0.1</td><td>73.0</td><td>0.2</td></tr><tr><td>对抗学习嵌入法(ALE)[(阿卡塔等人，2016年)]</td><td>16.8</td><td>76.1</td><td>27.5</td><td>14.0</td><td>81.8</td><td>23.9</td><td>21.8</td><td>33.1</td><td>26.3</td><td>4.6</td><td>73.7</td><td>8.7</td></tr><tr><td>广义零样本学习法(GFZSL)[(维尔马和拉伊，2017年)]</td><td>1.8</td><td>80.3</td><td>3.5</td><td>2.5</td><td>80.1</td><td>4.8</td><td>0.0</td><td>39.6</td><td>0.0</td><td>0.0</td><td>83.3</td><td>0.0</td></tr><tr><td>设备法(DEVISE)[(弗罗姆等人，2013年)]</td><td>13.4</td><td>68.7</td><td>22.4</td><td>17.1</td><td>74.7</td><td>27.8</td><td>16.9</td><td>27.4</td><td>20.9</td><td>4.9</td><td>76.9</td><td>9.2</td></tr><tr><td>堆叠自编码器法(SAE)[(科迪罗夫等人，2017年)]</td><td>1.8</td><td>77.1</td><td>3.5</td><td>1.1</td><td>82.2</td><td>2.2</td><td>8.8</td><td>18.0</td><td>11.8</td><td>0.4</td><td>80.9</td><td>0.9</td></tr><tr><td>低秩嵌入堆叠自编码器法(LESAE)[(刘等人，2018年)]</td><td>19.1</td><td>70.2</td><td>30.0</td><td>21.8</td><td>70.6</td><td>33.3</td><td>21.9</td><td>34.7</td><td>26.9</td><td>12.7</td><td>56.1</td><td>20.1</td></tr><tr><td rowspan="3">↑</td><td>判别式嵌入模型(DEM)[(张等人，2017年)]</td><td>32.8</td><td>84.7</td><td>47.3</td><td>30.5</td><td>86.4</td><td>45.1</td><td>20.5</td><td>34.3</td><td>25.6</td><td>11.1</td><td>75.1</td><td>19.4</td></tr><tr><td>生成式零样本学习法(GAZSL)[(朱等人，2018年)]</td><td>29.6</td><td>84.2</td><td>43.8</td><td>35.4</td><td>86.9</td><td>50.3</td><td>22.1</td><td>39.3</td><td>28.3</td><td>14.2</td><td>78.6</td><td>24.0</td></tr><tr><td>时间卷积网络法(TCN)[(江等人，2019年)]</td><td>49.4</td><td>76.5</td><td>60.0</td><td>61.2</td><td>65.8</td><td>63.4</td><td>31.2</td><td>37.3</td><td>34.0</td><td>24.1</td><td>64.0</td><td>35.1</td></tr><tr><td rowspan="2">日</td><td>AREN + 对比学习法(AREN+CS)[(谢等人，2019年)]</td><td>-</td><td>-</td><td>-</td><td>54.7</td><td>79.1</td><td>64.7</td><td>40.3</td><td>32.3</td><td>35.9</td><td>30.0</td><td>47.9</td><td>36.9</td></tr><tr><td>关系网络法(RN)[(宋等人，2018年)]</td><td>31.4</td><td>91.3</td><td>46.7</td><td>30.0</td><td>93.4</td><td>45.3</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td></tr><tr><td>$b$</td><td>局部特征引导注意力聚合法(LFGAA)[(刘等人，2019年)]</td><td>-</td><td>-</td><td>-</td><td>27.0</td><td>93.4</td><td>41.9</td><td>18.5</td><td>40.0</td><td>25.3</td><td>-</td><td>-</td><td>-</td></tr><tr><td></td><td>我们的方法</td><td>19.1</td><td>84.0</td><td>31.1</td><td>21.2</td><td>85.7</td><td>34.0</td><td>27.4</td><td>52.4</td><td>36.0</td><td>23.4</td><td>47.4</td><td>31.3</td></tr><tr><td></td><td>我们的方法 + 对比学习法</td><td>56.5</td><td>73.0</td><td>63.7</td><td>61.7</td><td>68.3</td><td>65.4</td><td>47.6</td><td>38.2</td><td>42.6</td><td>29.2</td><td>47.2</td><td>36.1</td></tr></tbody></table>

$\dagger$ indicates the classical ZSL methods. $\ddagger$ indicates the methods that synthesize visual features. $\natural$ indicates the end-to-end methods. $\flat$ indicates the methods using attributes selection.

$\dagger$ 表示经典的零样本学习(ZSL)方法。$\ddagger$ 表示合成视觉特征的方法。$\natural$ 表示端到端的方法。$\flat$ 表示使用属性选择的方法。

* indicates that ResNet101 is not used as backbone.

* 表示未使用 ResNet101 作为骨干网络。

## 5. Conclusions

## 5. 结论

In this paper, we propose a novel encoder-decoder framework VGAAE, which simultaneously maps the features into semantic space to guide to weight important attributes and embeds attentive attributes back to visual space. Besides, the class prototypes are also fed into the latter embedding, i.e., the decoder network, to achieve the inference procedure by a product operation with the fused visual features. Furthermore, extensive experiments on several benchmark datasets demonstrate that our proposed model achieves promising performance and a significant boost over several state-of-the-art methods.

在本文中，我们提出了一种新颖的编码器 - 解码器框架 VGAAE，该框架同时将特征映射到语义空间以指导对重要属性进行加权，并将注意力属性嵌入回视觉空间。此外，类别原型也被输入到后续的嵌入过程中，即解码器网络，通过与融合后的视觉特征进行乘积运算来实现推理过程。此外，在多个基准数据集上进行的大量实验表明，我们提出的模型取得了良好的性能，并且相对于几种最先进的方法有显著提升。

In the future, we may further discuss the effect of some other attention mechanisms acting on the attributes, for example, the self-attention module in Transformer (Vaswani et al., 2017) without LSTM.

未来，我们可能会进一步探讨其他一些作用于属性的注意力机制的效果，例如，不使用长短期记忆网络(LSTM)的 Transformer 中的自注意力模块(Vaswani 等人，2017)。

## Declaration of competing interest

## 利益冲突声明

The authors declare that they have no known competing financial interests or personal relationships that could have appeared to influence the work reported in this paper.

作者声明，他们没有已知的可能影响本文所报道工作的竞争性财务利益或个人关系。

## Acknowledgments

## 致谢

This work was supported in part by National Natural Science Foundation of China (Nos. 62076129, 61501230, 61732006), the National Key R&D Program of China (Grant Nos: 2018YFC2001600, 2018YFC2001602), and the Fundamental Research Funds for the Central Universities, China (No. NT2020024).

本工作部分得到了国家自然科学基金(项目编号:62076129、61501230、61732006)、国家重点研发计划(项目编号:2018YFC2001600、2018YFC2001602)以及中央高校基本科研业务费(项目编号:NT2020024)的资助。

## References

## 参考文献

Abdi, H. (2007). The Kendall rank correlation coefficient. In Encyclopedia of measurement and statistics. Sage, Thousand Oaks, CA (pp. 508-510). Citeseer.

Abdi, H. (2007). 肯德尔秩相关系数。见《测量与统计百科全书》。Sage 出版社，加利福尼亚州千橡市(第 508 - 510 页)。Citeseer。

Akata, Z., Perronnin, F., Harchaoui, Z., & Schmid, C. (2016). Label-embedding for image classification. IEEE Transactions on Pattern Analysis and Machine Intelligence, 38(7), 1425-1438.

Akata, Z., Perronnin, F., Harchaoui, Z., & Schmid, C. (2016). 用于图像分类的标签嵌入。《IEEE 模式分析与机器智能汇刊》，38(7)，1425 - 1438。

Akata, Z., Reed, S., Walter, D., Lee, H., & Schiele, B. (2015). Evaluation of output embeddings for fine-grained image classification. In CVPR (pp. 2927-2936).

Akata, Z., Reed, S., Walter, D., Lee, H., & Schiele, B. (2015). 细粒度图像分类输出嵌入的评估。见《计算机视觉与模式识别会议(CVPR)》(第 2927 - 2936 页)。

Ba, J. L., Mnih, V., & Kavukcuoglu, K. (2015). Multiple object recognition with visual attention. In ICLR 2015: International conference on learning representations.

Ba, J. L., Mnih, V., & Kavukcuoglu, K. (2015). 基于视觉注意力的多目标识别。见《国际学习表征会议(ICLR 2015)》。

Bucher, M., Herbin, S., & Jurie, F. (2016). Improving semantic embedding consistency by metric learning for zero-shot classiffication. In European conference on computer vision, Vol. 9909 (pp. 730-746).

Bucher, M., Herbin, S., & Jurie, F. (2016). 通过度量学习提高零样本分类的语义嵌入一致性。见《欧洲计算机视觉会议》，第 9909 卷(第 730 - 746 页)。

Changpinyo, S., Chao, W.-L., Gong, B., & Sha, F. (2020). Classifier and exemplar synthesis for zero-shot learning. International Journal of Computer Vision, 128(1), 166-201.

Changpinyo, S., Chao, W.-L., Gong, B., & Sha, F. (2020). 零样本学习的分类器和样本合成。《国际计算机视觉杂志》，128(1)，166 - 201。

Chao, W.-L., Changpinyo, S., Gong, B., & Sha, F. (2016). An empirical study and analysis of generalized zero-shot learning for object recognition in the wild. In European conference on computer vision (pp. 52-68). Springer.

赵(Chao)，W.-L.，张品耀(Changpinyo)，S.，龚(Gong)，B.，& 沙(Sha)，F. (2016)。野外目标识别的广义零样本学习的实证研究与分析。见欧洲计算机视觉会议(第52 - 68页)。施普林格出版社。

Chen, Z., Li, J., Luo, Y., Huang, Z., & Yang, Y. (2020). Canzsl: Cycle-consistent adversarial networks for zero-shot learning from natural language. In Proceedings of the IEEE/CVF winter conference on applications of computer vision (pp. 874-883).

陈(Chen)，Z.，李(Li)，J.，罗(Luo)，Y.，黄(Huang)，Z.，& 杨(Yang)，Y. (2020)。Canzsl:用于从自然语言进行零样本学习的循环一致对抗网络。见电气与电子工程师协会/计算机视觉基金会冬季计算机视觉应用会议论文集(第874 - 883页)。

Ding, Z., Shao, M., & Fu, Y. (2017). Low-rank embedded ensemble semantic dictionary for zero-shot learning. In CVPR.

丁(Ding)，Z.，邵(Shao)，M.，& 傅(Fu)，Y. (2017)。用于零样本学习的低秩嵌入集成语义字典。见计算机视觉与模式识别会议。

Farhadi, A., Endres, I., Hoiem, D., & Forsyth, D. (2009). Describing objects by their attributes. In CVPR (pp. 1778-1785).

法尔哈迪(Farhadi)，A.，恩德斯(Endres)，I.，霍耶姆(Hoiem)，D.，& 福赛思(Forsyth)，D. (2009)。通过物体属性描述物体。见计算机视觉与模式识别会议(第1778 - 1785页)。

Felix, R., Reid, I., Carneiro, G., et al. (2018). Multi-modal cycle-consistent generalized zero-shot learning. In Proceedings of the European conference on computer vision (pp. 21-37).

费利克斯(Felix)，R.，里德(Reid)，I.，卡内罗(Carneiro)，G.等。(2018)。多模态循环一致广义零样本学习。见欧洲计算机视觉会议论文集(第21 - 37页)。

Frome, A., Corrado, G. S., Shlens, J., Bengio, S., Dean, J., Ranzato, M., et al. (2013). DeViSE: A deep visual-semantic embedding model. In Conference on neural information processing systems.

弗罗姆(Frome)，A.，科拉多(Corrado)，G. S.，施伦斯(Shlens)，J.，本吉奥(Bengio)，S.，迪恩(Dean)，J.，兰扎托(Ranzato)，M.等。(2013)。DeViSE:一种深度视觉 - 语义嵌入模型。见神经信息处理系统会议。

Fu, Y., Hospedales, T. M., Xiang, T., & Gong, S. (2015). Transductive multiview zero-shot learning. IEEE Transactions on Pattern Analysis and Machine Intelligence, 37(11), 2332-2345.

傅(Fu)，Y.，霍斯佩代尔斯(Hospedales)，T. M.，向(Xiang)，T.，& 龚(Gong)，S. (2015)。直推式多视图零样本学习。《电气与电子工程师协会模式分析与机器智能汇刊》，37(11)，2332 - 2345。

Fu, Z., Xiang, T., Kodirov, E., & Gong, S. (2017). Zero-shot learning on semantic class prototype graph. IEEE Transactions on Pattern Analysis and Machine Intelligence, 40(8), 2009-2022.

傅(Fu)，Z.，向(Xiang)，T.，科迪罗夫(Kodirov)，E.，& 龚(Gong)，S. (2017)。基于语义类原型图的零样本学习。《电气与电子工程师协会模式分析与机器智能汇刊》，40(8)，2009 - 2022。

Guo, Y., Ding, G., Han, J., & Tang, S. (2018). Zero-shot learning with attribute selection. In AAAI.

郭(Guo)，Y.，丁(Ding)，G.，韩(Han)，J.，& 唐(Tang)，S. (2018)。基于属性选择的零样本学习。见美国人工智能协会会议。

He, K., Zhang, X., Ren, S., & Sun, J. (2016). Deep residual learning for image recognition. In CVPR (pp. 770-778). IEEE.

何(He)，K.，张(Zhang)，X.，任(Ren)，S.，& 孙(Sun)，J. (2016)。用于图像识别的深度残差学习。见计算机视觉与模式识别会议(第770 - 778页)。电气与电子工程师协会。

Huang, H., Wang, C., Yu, P. S., & Wang, C.-D. (2019). Generative dual adversarial network for generalized zero-shot learning. In CVPR (pp. 801-810).

黄(Huang)，H.，王(Wang)，C.，余(Yu)，P. S.，& 王(Wang)，C.-D. (2019)。用于广义零样本学习的生成式对偶对抗网络。见计算机视觉与模式识别会议(第801 - 810页)。

Jiang, H., Wang, R., Shan, S., & Chen, X. (2019). Transferable contrastive network for generalized zero-shot learning. In Proceedings of the IEEE international conference on computer vision (pp. 9765-9774).

江(Jiang)，H.，王(Wang)，R.，单(Shan)，S.，& 陈(Chen)，X. (2019)。用于广义零样本学习的可迁移对比网络。见电气与电子工程师协会国际计算机视觉会议论文集(第9765 - 9774页)。

Jin, X.-B., Xie, G.-S., Huang, K., Miao, J., & Wang, Q. (2019). Beyond attributes: High-order attribute features for zero-shot learning. In Proceedings of the IEEE international conference on computer vision workshops (pp. 2953-2962).

金(Jin)，X.-B.，谢(Xie)，G.-S.，黄(Huang)，K.，苗(Miao)，J.，& 王(Wang)，Q. (2019)。超越属性:用于零样本学习的高阶属性特征。见电气与电子工程师协会国际计算机视觉研讨会论文集(第2953 - 2962页)。

Kodirov, E., Xiang, T., & Gong, S. (2017). Semantic autoencoder for zero-shot learning. In CVPR.

科迪罗夫(Kodirov)，E.，向(Xiang)，T.，& 龚(Gong)，S. (2017)。用于零样本学习的语义自编码器。见计算机视觉与模式识别会议。

Lampert, C. H., Nickisch, H., & Harmeling, S. (2014). Attribute-based classification for zero-shot visual object categorization. IEEE Transactions on Pattern Analysis and Machine Intelligence, 36(3), 453-465.

兰佩特(Lampert)，C. H.，尼克isch(Nickisch)，H.，& 哈梅林(Harmeling)，S. (2014)。基于属性的分类用于零样本视觉目标分类。《电气与电子工程师协会模式分析与机器智能汇刊》，36(3)，453 - 465。

Liu, Y., Gao, Q., Li, J., Han, J., & Shao, L. (2018). Zero shot learning via low-rank embedded semantic AutoEncoder. In IJCAI (pp. 2490-2496).

刘(Liu)，Y.，高(Gao)，Q.，李(Li)，J.，韩(Han)，J.，& 邵(Shao)，L. (2018)。通过低秩嵌入语义自编码器进行零样本学习。见国际人工智能联合会议(第2490 - 2496页)。

Liu, Y., Guo, J., Cai, D., & He, X. (2019). Attribute attention for semantic disambiguation in zero-shot learning. In Proceedings of the IEEE/CVF international conference on computer vision (pp. 6698-6707).

刘，Y.，郭，J.，蔡，D.，和何，X.(2019)。零样本学习中用于语义消歧的属性注意力。见《电气与电子工程师协会/计算机视觉基金会国际计算机视觉会议论文集》(第6698 - 6707页)。

Maaten, L. v. d., & Hinton, G. (2008). Visualizing data using t-SNE. Journal of Machine Learning Research, 9(Nov), 2579-2605.

马滕，L. v. d.，和辛顿，G.(2008)。使用t - 分布随机邻域嵌入(t - SNE)可视化数据。《机器学习研究杂志》，9(11月)，2579 - 2605。

Palatucci, M., Pomerleau, D., Hinton, G., & Mitchell, T. M. (2009). Zero-shot learning with semantic output codes. In Conference on neural information processing systems (pp. 1410-1418).

帕拉图奇，M.，波梅罗，D.，辛顿，G.，和米切尔，T. M.(2009)。使用语义输出码的零样本学习。见《神经信息处理系统会议》(第1410 - 1418页)。

Patterson, G., Xu, C., Su, H., & Hays, J. (2014). The sun attribute database: Beyond categories for deeper scene understanding. International Journal of Computer Vision, 108(1-2), 59-81.

帕特森，G.，徐，C.，苏，H.，和海斯，J.(2014)。太阳属性数据库:超越类别以实现更深入的场景理解。《国际计算机视觉杂志》，108(1 - 2)，59 - 81。

Romera-Paredes, B., & Torr, P. H. S. (2015). An embarrassingly simple approach to zero-shot learning. In ICML, Vol. 37 (pp. 11-30).

罗梅拉 - 帕雷德斯，B.，和托尔，P. H. S.(2015)。一种极其简单的零样本学习方法。见《国际机器学习会议》，第37卷(第11 - 30页)。

Salton, G., & Buckley, C. (1988). Term-weighting approaches in automatic text retrieval. Information Processing $\mathcal{E}$ Management, 24(5), 513-523.

萨尔顿，G.，和巴克利，C.(1988)。自动文本检索中的词项加权方法。《信息处理$\mathcal{E}$与管理》，24(5)，513 - 523。

Shigeto, Y., Suzuki, I., Hara, K., Shimbo, M., & Matsumoto, Y. (2015). Ridge regression, hubness, and zero-shot learning. In ECML/PKDD.

志户，Y.，铃木，I.，原，K.，岛本，M.，和松本，Y.(2015)。岭回归、枢纽性和零样本学习。见《欧洲机器学习会议/知识发现与数据挖掘原理会议》。

Sung, F., Yang, Y., Zhang, L., Xiang, T., Torr, P. H., & Hospedales, T. M. (2018). Learning to compare: Relation network for few-shot learning. In CVPR.

宋，F.，杨，Y.，张，L.，向，T.，托尔，P. H.，和霍斯佩代尔斯，T. M.(2018)。学习比较:用于少样本学习的关系网络。见《计算机视觉与模式识别会议》。

Vaswani, A., Shazeer, N., Parmar, N., Uszkoreit, J., Jones, L., Gomez, A. N., et al. (2017). Attention is all you need. In Conference on neural information processing systems (pp. 5998-6008).

瓦斯瓦尼，A.，沙泽尔，N.，帕尔马尔，N.，乌斯库雷特，J.，琼斯，L.，戈麦斯，A. N.等(2017)。注意力就是你所需要的一切。见《神经信息处理系统会议》(第5998 - 6008页)。

Verma, V. K., Arora, G., Mishra, A., & Rai, P. (2018). Generalized zero-shot learning via synthesized examples. In CVPR (pp. 4281-4289).

维尔马，V. K.，阿罗拉，G.，米什拉，A.，和拉伊，P.(2018)。通过合成示例进行广义零样本学习。见《计算机视觉与模式识别会议》(第4281 - 4289页)。

Verma, V. K., & Rai, P. (2017). A simple exponential family framework for zero-shot learning. In Joint European conference on machine learning and knowledge discovery in databases (pp. 792-808). Springer.

维尔马，V. K.，和拉伊，P.(2017)。一个用于零样本学习的简单指数族框架。见《欧洲机器学习与数据库知识发现联合会议》(第792 - 808页)。施普林格出版社。

Vyas, M. R., Venkateswara, H., & Panchanathan, S. (2020). Leveraging seen and unseen semantic relationships for generative zero-shot learning. In European conference on computer vision (pp. 70-86). Springer.

维亚斯，M. R.，文卡特斯瓦拉，H.，和潘查纳坦，S.(2020)。利用已见和未见语义关系进行生成式零样本学习。见《欧洲计算机视觉会议》(第70 - 86页)。施普林格出版社。

Xian, Y., Akata, Z., Sharma, G., Nguyen, Q., Hein, M., & Schiele, B. (2016). Latent embeddings for zero-shot classification. In CVPR.

西安，Y.，阿卡塔，Z.，夏尔马，G.，阮，Q.，海因，M.，和席勒，B.(2016)。用于零样本分类的潜在嵌入。见《计算机视觉与模式识别会议》。

Xian, Y., Lampert, C. H., Schiele, B., & Akata, Z. (2018). Zero-shot learning-a comprehensive evaluation of the good, the bad and the ugly. IEEE Transactions on Pattern Analysis and Machine Intelligence, 41(9), 2251-2265.

西安，Y.，兰佩特，C. H.，席勒，B.，和阿卡塔，Z.(2018)。零样本学习——对好坏丑的全面评估。《电气与电子工程师协会模式分析与机器智能汇刊》，41(9)，2251 - 2265。

Xie, G.-S., Liu, L., Jin, X., Zhu, F., Zhang, Z., Qin, J., et al. (2019). Attentive region embedding network for zero-shot learning. In CVPR (pp. 9384-9393).

谢，G. - S.，刘，L.，金，X.，朱，F.，张，Z.，秦，J.等(2019)。用于零样本学习的注意力区域嵌入网络。见《计算机视觉与模式识别会议》(第9384 - 9393页)。

Ye, M., & Guo, Y. (2017). Zero-shot classification with discriminative semantic representation learning. In CVPR (pp. 7140-7148).

叶，M.，和郭，Y.(2017)。通过判别性语义表示学习进行零样本分类。见《计算机视觉与模式识别会议》(第7140 - 7148页)。

You, Q., Jin, H., Wang, Z., Fang, C., & Luo, J. (2016). Image captioning with semantic attention. In CVPR.

游(You)、金(Jin)、王(Wang)、方(Fang)和罗(Luo)(2016年)。基于语义注意力的图像描述。发表于计算机视觉与模式识别会议(CVPR)。

Yu, Y., Ji, Z., Fu, Y., Guo, J., Pang, Y., & Zhang, Z. M. (2018). Stacked semantics-guided attention model for fine-grained zero-shot learning. In Conference on neural information processing systems (pp. 5995-6004).

余(Yu)、季(Ji)、傅(Fu)、郭(Guo)、庞(Pang)和张(Zhang)(2018年)。用于细粒度零样本学习的堆叠语义引导注意力模型。发表于神经信息处理系统大会(Conference on neural information processing systems)(第5995 - 6004页)。

Zhang, Z., & Saligrama, V. (2016). Zero-shot learning via joint latent similarity embedding. In CVPR (pp. 6034-6042).

张(Zhang)和萨利格拉马(Saligrama)(2016年)。通过联合潜在相似性嵌入实现零样本学习。发表于计算机视觉与模式识别会议(CVPR)(第6034 - 6042页)。

Zhang, L., Xiang, T., & Gong, S. (2017). Learning a deep embedding model for zero-shot learning. In CVPR (pp. 3010-3019).

张(Zhang)、向(Xiang)和龚(Gong)(2017年)。学习用于零样本学习的深度嵌入模型。发表于计算机视觉与模式识别会议(CVPR)(第3010 - 3019页)。

Zhang, L., Zhang, J., Lin, Z., Lu, H., & He, Y. (2019). CapSal: Leveraging captioning to boost semantics for salient object detection. In CVPR (pp. 6024-6033).

张(Zhang)、张(Zhang)、林(Lin)、陆(Lu)和何(He)(2019年)。CapSal:利用图像描述提升显著目标检测的语义信息。发表于计算机视觉与模式识别会议(CVPR)(第6024 - 6033页)。

Zhu, Y., Elhoseiny, M., Liu, B., Peng, X., & Elgammal, A. (2018). A generative adversarial approach for zero-shot learning from noisy texts. In CVPR (pp. 1004-1013).

朱(Zhu)、埃尔霍塞尼(Elhoseiny)、刘(Liu)、彭(Peng)和埃尔加马尔(Elgammal)(2018年)。一种从嘈杂文本中进行零样本学习的生成对抗方法。发表于计算机视觉与模式识别会议(CVPR)(第1004 - 1013页)。

Zhu, Y., Xie, J., Tang, Z., Peng, X., & Elgammal, A. (2019). Semantic-guided multi-attention localization for zero-shot learning. In Conference on neural information processing systems, Vol. 32.

朱(Zhu)、谢(Xie)、唐(Tang)、彭(Peng)和埃尔加马尔(Elgammal)(2019年)。用于零样本学习的语义引导多注意力定位。发表于神经信息处理系统大会(Conference on neural information processing systems)，第32卷。