# Data-Efficient CLIP-Powered Dual-Branch Networks for Source-Free Unsupervised Domain Adaptation

# 用于无源无监督域适应的数据高效CLIP驱动双分支网络

Yongguang ${\mathrm{{Li}}}^{1,3, \dagger  }$ Yueqi ${\mathrm{{Cao}}}^{2,3, \dagger  }$ Jindong ${\mathrm{{Li}}}^{4}$ Qi Wang ${}^{4,5}$ Shengsheng Wang ${}^{2,3, * }$

Yongguang ${\mathrm{{Li}}}^{1,3, \dagger  }$ Yueqi ${\mathrm{{Cao}}}^{2,3, \dagger  }$ Jindong ${\mathrm{{Li}}}^{4}$ Qi Wang ${}^{4,5}$ Shengsheng Wang ${}^{2,3, * }$

${}^{1}$ College of Software, Jilin University, Changchun 130012, China

${}^{1}$ 吉林大学软件学院，长春 130012，中国

${}^{2}$ College of Computer Science and Technology, Jilin University, Changchun 130012, China

${}^{2}$ 吉林大学计算机科学与技术学院，长春 130012，中国

${}^{3}$ Key Laboratory of Symbolic Computation and Knowledge Engineering of Ministry of Education, Jilin University, Changchun 130012, China

${}^{3}$ 吉林大学符号计算与知识工程教育部重点实验室，长春 130012，中国

${}^{4}$ School of Artificial Intelligence, Jilin University, Changchun 130012, China

${}^{4}$ 吉林大学人工智能学院，长春 130012，中国

${}^{5}$ Engineering Research Center of Knowledge-Driven Human-Machine Intelligence, Ministry of Education, Jilin University, Changchun 130012, China

${}^{5}$ 吉林大学知识驱动人机智能教育部工程研究中心，长春 130012，中国

\{livg22, caoyq22, jdli21\}@mails.jlu.edu.cn, \{qiwang, wss\}@jlu.edu.cn

\{livg22, caoyq22, jdli21\}@mails.jlu.edu.cn, \{qiwang, wss\}@jlu.edu.cn

Abstract-Source-free Unsupervised Domain Adaptation (SF-UDA) aims to transfer a model's performance from a labeled source domain to an unlabeled target domain without direct access to source samples, addressing critical data privacy concerns. However, most existing SF-UDA approaches assume the availability of abundant source domain samples, which is often impractical due to the high cost of data annotation. To address the dual challenges of limited source data and privacy concerns, we introduce a data-efficient, CLIP-powered dual-branch network (CDBN). This architecture consists of a cross-domain feature transfer branch and a target-specific feature learning branch, leveraging high-confidence target domain samples to transfer text features of source domain categories while learning target-specific soft prompts. By fusing the outputs of both branches, our approach not only effectively transfers source domain category semantic information to the target domain but also reduces the negative impacts of noise and domain gaps during target training. Furthermore, we propose an unsupervised optimization strategy driven by accurate classification and diversity, preserving the classification capability learned from the source domain while generating more confident and diverse predictions in the target domain. CDBN achieves near state-of-the-art performance with far fewer source domain samples than existing methods across 31 transfer tasks on seven datasets.

摘要——无源无监督域适应(SF - UDA)旨在在不直接访问源样本的情况下，将模型在有标签源域的性能迁移到无标签目标域，解决关键的数据隐私问题。然而，大多数现有的SF - UDA方法假设可以获得丰富的源域样本，由于数据标注成本高，这在实际中往往不可行。为应对源数据有限和隐私问题的双重挑战，我们引入了一种数据高效的、由CLIP驱动的双分支网络(CDBN)。该架构由跨域特征迁移分支和特定目标特征学习分支组成，利用高置信度的目标域样本迁移源域类别的文本特征，同时学习特定目标的软提示。通过融合两个分支的输出，我们的方法不仅能有效地将源域类别语义信息迁移到目标域，还能减少目标训练过程中噪声和域差距的负面影响。此外，我们提出了一种由准确分类和多样性驱动的无监督优化策略，在保留从源域学到的分类能力的同时，在目标域生成更有置信度和多样性的预测。在七个数据集的31个迁移任务中，CDBN使用的源域样本远少于现有方法，却能达到接近最先进的性能。

Index Terms-Source-Free, Unsupervised Domain Adaptation, Prompt Learning, CLIP, Data-Efficient

关键词——无源、无监督域适应、提示学习、CLIP、数据高效

## I. INTRODUCTION

## I. 引言

Deep learning has achieved remarkable performance in various computer vision tasks $\left\lbrack  {4,{49},{59}}\right\rbrack$ . However, these achievements largely rely on the assumption that the training and test data are independently and identically distributed (i.i.d.) [20]. In real-world scenarios, differences in data collection conditions, environmental factors, and other variables often cause domain shifts between the training data (source domain) and test data (target domain), significantly reducing model performance. To address this issue, previous works [8, 25] have proposed unsupervised domain adaptation (UDA), employing adversarial training [8, 44], metric learning [25], and other techniques to learn domain-invariant features, thereby facilitating the transfer of models trained on the source domain to the unlabeled target domain.

深度学习在各种计算机视觉任务中取得了显著的性能 $\left\lbrack  {4,{49},{59}}\right\rbrack$ 。然而，这些成果在很大程度上依赖于训练数据和测试数据独立同分布(i.i.d.)的假设 [20]。在现实场景中，数据收集条件、环境因素和其他变量的差异常常导致训练数据(源域)和测试数据(目标域)之间出现域偏移，显著降低模型性能。为解决这个问题，先前的工作 [8, 25] 提出了无监督域适应(UDA)，采用对抗训练 [8, 44]、度量学习 [25] 等技术来学习域不变特征，从而促进在源域训练的模型迁移到无标签的目标域。

Despite the effectiveness of UDA methods in addressing domain shifts, they typically assume that the source domain is accessible during target domain training and contains sufficient labeled data for training. However, this assumption is often unrealistic in practical settings due to the high cost of data annotation and the need to protect data privacy. For instance, in the diabetic retinopathy dataset used in clinical research [12], each image is annotated by 7 to 8 board-certified ophthalmologists, significantly increasing the cost of labeling [54]. Additionally, in fields such as medicine and remote sensing [36], labeled data often cannot be distributed or reused due to privacy protection and commercial copyright concerns.

尽管UDA方法在解决域偏移问题上很有效，但它们通常假设在目标域训练期间可以访问源域，并且源域包含足够的有标签数据用于训练。然而，由于数据标注成本高以及需要保护数据隐私，这种假设在实际应用中往往不现实。例如，在临床研究中使用的糖尿病视网膜病变数据集 [12] 中，每张图像都由7到8位获得委员会认证的眼科医生进行标注，显著增加了标注成本 [54]。此外，在医学和遥感等领域 [36]，由于隐私保护和商业版权问题，有标签的数据通常不能被分发或重复使用。

Researchers have proposed two types of methods to address the challenges of restricted access to the source domain and the limited number of source domain samples. Source-free unsupervised domain adaptation (SF-UDA) methods [24, 44, 45] address the issue of inaccessible source data by enabling model transfer to the target domain without requiring direct access to the source domain. Meanwhile, few-shot unsupervised domain adaptation (FS-UDA) methods $\left\lbrack  {{18},{23},{54}}\right\rbrack$ tackle the problem of limited labeled data by facilitating effective model transfer with minimal source samples. However, methods that address the dual challenges of restricted access to source domain data and small amounts of source domain samples, known as SF-UDA methods under few-shot source domain scenarios (replaced by FS-SF-UDA in this paper), have yet to be fully explored.

研究人员提出了两类方法来应对源域访问受限和源域样本数量有限的挑战。无源无监督域适应(Source-free unsupervised domain adaptation，SF-UDA)方法 [24, 44, 45] 通过在无需直接访问源域的情况下将模型迁移到目标域，解决了源数据不可访问的问题。同时，少样本无监督域适应(Few-shot unsupervised domain adaptation，FS-UDA)方法 $\left\lbrack  {{18},{23},{54}}\right\rbrack$ 通过利用最少的源样本促进有效的模型迁移，解决了标记数据有限的问题。然而，解决源域数据访问受限和源域样本数量少这双重挑战的方法，即少样本源域场景下的 SF-UDA 方法(本文中简称为 FS-SF-UDA)，尚未得到充分探索。

In recent years, prompt learning for CLIP models [10, 17, 57] has demonstrated significant advantages in few-shot classification tasks. These methods typically leverage CLIP as a backbone network and employ prompt learning techniques to achieve strong downstream task performance, even with only a limited number of samples per class. Inspired by this, we propose a data-efficient $\underline{\mathbf{C}}$ LIP-powered $\underline{\mathbf{D}}$ ual- $\underline{\mathbf{B}}$ ranch $\underline{\mathbf{N}}$ etwork (dubbed as CDBN) for FS-SF-UDA.

近年来，用于 CLIP 模型的提示学习 [10, 17, 57] 在少样本分类任务中展现出显著优势。这些方法通常以 CLIP 作为骨干网络，并采用提示学习技术，即使每个类别只有有限数量的样本，也能在下游任务中取得出色的性能。受此启发，我们提出了一种数据高效的 $\underline{\mathbf{C}}$ 基于语言图像预训练(LIP)的 $\underline{\mathbf{D}}$ 双 $\underline{\mathbf{B}}$ 分支 $\underline{\mathbf{N}}$ 网络(简称为 CDBN)，用于 FS-SF-UDA。

---

This work has been submitted to the IEEE for possible publication. Copyright may be transferred without notice, after which this version may no longer be accessible.

本工作已提交给 IEEE 以供可能发表。版权可能会在未事先通知的情况下转移，转移后此版本可能无法再访问。

$\dagger$ : Equal Contribution.

$\dagger$ :同等贡献。

*: Corresponding Author.

*:通讯作者。

---

![0195dcf6-b307-7b10-9224-24b77c210989_1_138_154_1515_562_0.jpg](images/0195dcf6-b307-7b10-9224-24b77c210989_1_138_154_1515_562_0.jpg)

Fig. 1: Scheme 1 illustrates the issue with previous SF-UDA methods, where using a fully trained model from a source domain as an information source for a target domain leads to poor performance when source domain samples are limited. To address this issue, Scheme 2 presents our proposed solution, which involves transferring category feature representations obtained from a source-domain-based prompt learning method to the target domain, effectively resolving the SF-UDA problem in scenarios with few source domain samples.

图 1:方案 1 说明了以往 SF-UDA 方法存在的问题，即当源域样本有限时，将源域中完全训练好的模型作为目标域的信息源会导致性能不佳。为解决这一问题，方案 2 提出了我们的解决方案，即将从基于源域的提示学习方法中获得的类别特征表示迁移到目标域，有效解决了少样本源域场景下的 SF-UDA 问题。

In scenarios with only a few samples in the source domain, our goal is to efficiently extract useful category semantic information from the source domain and deliver it to the target domain as a reference for unsupervised training. Specifically, as shown in Scheme 1 of Figure 1, traditional methods that rely on supervised training of a source domain model perform poorly when the number of samples in the source domain is limited. To address this issue, as illustrated in Scheme 2 of Figure 1, we employ a CLIP-based prompt learning approach to learn category text features with a certain degree of generalization from a small number of source domain samples. We then leverage these category text features as carriers of source domain semantic information to guide the unsupervised training process in the target domain.

在源域样本极少的场景中，我们的目标是从源域中高效提取有用的类别语义信息，并将其传递到目标域，作为无监督训练的参考。具体而言，如图 1 的方案 1 所示，依赖源域模型有监督训练的传统方法在源域样本数量有限时表现不佳。为解决这一问题，如图 1 的方案 2 所示，我们采用基于 CLIP 的提示学习方法，从少量源域样本中学习具有一定泛化能力的类别文本特征。然后，我们利用这些类别文本特征作为源域语义信息的载体，指导目标域的无监督训练过程。

However, the combination of limited source domain samples and the domain gap presents a challenge, as it introduces noise and domain shift into the transferred category text features. To address this, we designed a cross-modal dual-branch network consisting of a cross-domain feature transfer branch and a target-specific feature learning branch. The cross-domain feature transfer branch utilizes high-confidence samples from the target domain to transfer the learned source domain category text features, reducing the impact of domain discrepancy. Meanwhile, the target-specific feature learning branch focuses on learning independent category features from the target domain, avoiding over-reliance on noisy source domain text features. The synergy between these two branches effectively enhances the feature representation capabilities in the target domain.

然而，源域样本有限和域差距的结合带来了挑战，因为这会在迁移的类别文本特征中引入噪声和域偏移。为解决这一问题，我们设计了一个跨模态双分支网络，由跨域特征迁移分支和特定于目标域的特征学习分支组成。跨域特征迁移分支利用目标域中的高置信度样本迁移所学的源域类别文本特征，减少域差异的影响。同时，特定于目标域的特征学习分支专注于从目标域中学习独立的类别特征，避免过度依赖有噪声的源域文本特征。这两个分支的协同作用有效增强了目标域中的特征表示能力。

Furthermore, since there are no labels during the training process in the target domain, we propose an unsupervised optimization strategy driven by accurate classification and diversity. This strategy includes three core loss functions: first, the cross-entropy loss from high-confidence target domain samples derived from source domain category text features ensures that the model retains the classification ability learned from the source domain; second, the multi-view consistency loss encourages the model to extract consistent feature representations from different perspectives, enhancing the generalization capability of the learned category feature distribution; finally, the mutual information maximization loss between inputs and outputs promotes diversity in the category distribution, preventing the model from overfitting to simple categories. Together, these three components ensure that the model can learn target domain features accurately and robustly under unsupervised conditions.

此外，由于目标域的训练过程中没有标签，我们提出了一种由准确分类和多样性驱动的无监督优化策略。该策略包括三个核心损失函数:首先，从源域类别文本特征中导出的目标域高置信度样本的交叉熵损失，确保模型保留从源域学到的分类能力；其次，多视图一致性损失鼓励模型从不同视角提取一致的特征表示，增强所学类别特征分布的泛化能力；最后，输入和输出之间的互信息最大化损失促进类别分布的多样性，防止模型过拟合到简单类别。这三个部分共同确保模型能够在无监督条件下准确、稳健地学习目标域特征。

We conducted experiments on 31 transfer tasks across 7 publicly available domain adaptation datasets. Despite the dual challenges of limited source samples and restricted access to source domain data, CDBN achieved state-of-the-art performance on multiple datasets and showed competitive results comparable to the best existing methods on others. These outcomes demonstrate the robustness and effectiveness of our CDBN approach in addressing the FS-SF-UDA problem.

我们在 7 个公开可用的域适应数据集上的 31 个迁移任务上进行了实验。尽管面临源样本有限和源域数据访问受限的双重挑战，CDBN 在多个数据集上取得了最先进的性能，并在其他数据集上显示出与现有最佳方法相当的有竞争力的结果。这些结果证明了我们的 CDBN 方法在解决 FS-SF-UDA 问题上的鲁棒性和有效性。

Our main contributions could be summarized as follows:

我们的主要贡献总结如下:

- We propose a data-efficient CLIP-powered dual-branch network for Few-Shot Source-Free Unsupervised Domain Adaptation, addressing the dual challenges of limited source domain samples and restricted access to source domain data.

- 我们提出了一种数据高效的、由CLIP(对比语言-图像预训练模型)驱动的双分支网络，用于少样本无源无监督域适应，解决了源域样本有限和无法访问源域数据的双重挑战。

- We introduce a cross-modal dual-branch network structure that effectively leverages source domain category semantic information during the unsupervised fine-tuning process in the target domain while mitigating the effects of source domain noise and domain discrepancy. Additionally, it combines the strengths of both branches, significantly enhancing performance in the target domain.

- 我们引入了一种跨模态双分支网络结构，该结构在目标域的无监督微调过程中有效利用源域类别语义信息，同时减轻源域噪声和域差异的影响。此外，它结合了两个分支的优势，显著提升了在目标域的性能。

- We introduce an unsupervised optimization strategy that balances accurate classification with feature diversity. This strategy retains the classification capabilities learned from the source domain while promoting precise and diverse classification results in the target domain, thereby improving the model's performance on the target domain.

- 我们引入了一种无监督优化策略，该策略平衡了准确分类和特征多样性。此策略保留了从源域学到的分类能力，同时促进在目标域获得精确且多样的分类结果，从而提高模型在目标域的性能。

- We conduct extensive experiments across 31 transfer tasks on 7 public datasets, demonstrating our CDBN achieves state-of-the-art performance over existing methods.

- 我们在7个公共数据集的31个迁移任务上进行了广泛的实验，证明我们的CDBN(跨模态双分支网络)相对于现有方法达到了最先进的性能。

## II. RELATED WORK

## 二、相关工作

## A. Source-Free Unsupervised Domain Adaptation

## A. 无源无监督域适应

Source-Free Unsupervised Domain Adaptation (SF-UDA) aims to address the challenge in unsupervised domain adaptation where source domain data is inaccessible during training on the target domain. Most previous approaches can be categorized into two main types: data-based and model-based methods. Data-based methods typically generate virtual domains from the source domain model to replace the source data during training on the target domain, while model-based methods rely on self-supervised training directly on the source domain model to enhance its performance on the target domain after adaptation. For example, Tian et al. [43] proposes utilizing a model trained on the source domain to generate a virtual domain in the feature space based on an approximate Gaussian mixture model. By progressively increasing the compactness of the target domain features, this approach reduces the domain gap between the virtual and target domains, thus improving the model's performance on the target domain. Similarly, Qu et al. [30] introduces a multi-center clustering strategy within each class along with a dynamic pseudo-labeling strategy. By incorporating network updates during model adaptation, this method significantly enhances the performance of several representative SF-UDA approaches [24, 52].

无源无监督域适应(SF - UDA)旨在解决无监督域适应中在目标域训练时无法访问源域数据的挑战。以前的大多数方法可分为两大类:基于数据的方法和基于模型的方法。基于数据的方法通常从源域模型生成虚拟域，以在目标域训练时替代源数据，而基于模型的方法则直接在源域模型上进行自监督训练，以提高其在适应后在目标域的性能。例如，Tian等人[43]提出利用在源域训练的模型，基于近似高斯混合模型在特征空间中生成虚拟域。通过逐步提高目标域特征的紧凑性，这种方法减少了虚拟域和目标域之间的域差距，从而提高了模型在目标域的性能。同样，Qu等人[30]引入了每个类内的多中心聚类策略以及动态伪标签策略。通过在模型适应过程中纳入网络更新，该方法显著提升了几种代表性的SF - UDA方法的性能[24, 52]。

## B. Few-Shot Unsupervised Domain Adaptation

## B. 少样本无监督域适应

Few-Shot Unsupervised Domain Adaptation (FS-UDA) aims to address the challenge of having limited labeled samples in the source domain during training on the target domain, even though source domain samples are accessible. Previous methods have explored different scenarios to tackle this issue. For instance, Yue et al. [54] proposes a method to address the problem of label sparsity in the source domain. In situations where a large number of source domain samples are available but only a small portion are labeled, they leveraged cross-domain self-supervised learning to adapt the model to the target domain. Similarly, Wang et al. [48] presents a method to handle the long-tailed distribution of source domain data. In cases where only a few samples are available for certain hard-to-access categories in the source domain, they improved model accuracy through generative feature augmentation. Furthermore, Li et al. [23] proposes a Multi-Prototype Alignment framework to transfer the model to the target domain when only a few samples per category are available in the source domain. This approach effectively addresses the scenario where there are very few samples for each category. In this paper, we tackle the challenges present in both FS-UDA and SF-UDA by training a high-performing model on the target domain despite having only a few samples per class in the source domain and no direct access to source domain samples during target domain training.

少样本无监督域适应(FS - UDA)旨在解决在目标域训练时源域有标签样本有限的挑战，即使可以访问源域样本。以前的方法探索了不同的场景来解决这个问题。例如，Yue等人[54]提出了一种解决源域标签稀疏问题的方法。在有大量源域样本但只有一小部分有标签的情况下，他们利用跨域自监督学习使模型适应目标域。同样，Wang等人[48]提出了一种处理源域数据长尾分布的方法。在源域中某些难以获取的类别只有少量样本的情况下，他们通过生成式特征增强提高了模型的准确性。此外，Li等人[23]提出了一种多原型对齐框架，用于在源域每个类别只有少量样本时将模型迁移到目标域。这种方法有效地解决了每个类别样本极少的场景。在本文中，我们通过在目标域训练高性能模型来应对FS - UDA和SF - UDA中存在的挑战，尽管源域每个类别只有少量样本，并且在目标域训练时无法直接访问源域样本。

## C. Prompt Learning for CLIP

## C. 用于CLIP的提示学习

In recent years, vision-language pretraining models have made significant progress in image representation learning by leveraging supervision from natural language to interpret images. Among these models, the Contrastive Language-Image Pre-training (CLIP [31]) model is particularly representative. CLIP consists of a text encoder and an image encoder, pre-trained on 400 million image-text pairs collected from the internet, successfully aligning the feature spaces of both modalities. This approach demonstrates strong generalization capabilities in downstream tasks and enables zero-shot transfer in image classification tasks through manually specified text prompts. Inspired by prompt learning techniques in natural language processing, Zhou et al. [57] introduces a learnable context optimization technique to adapt vision-language models like CLIP to image recognition tasks. Instead of relying on manually designed prompts, $\mathrm{{CoOp}}$ (Context Optimization) uses learnable vectors to model contextual words while keeping the pre-trained parameters frozen. This method allows $\mathrm{{CoOp}}$ to exhibit superior performance with limited labeled data, showing a significant improvement over manual prompt engineering in few-shot scenarios. To further enhance the alignment between visual and textual representations, Khattak et al. [17] proposes a method that applies prompt learning to both the image and text branches simultaneously, fostering a strong coupling between visual and language prompts to ensure their mutual synergy. As a result, Maple demonstrates significantly better generalization to novel classes, surpassing $\mathrm{{CoOp}}$ in performance.

近年来，视觉 - 语言预训练模型通过利用自然语言的监督来解读图像，在图像表示学习方面取得了显著进展。在这些模型中，对比语言 - 图像预训练(Contrastive Language - Image Pre - training，CLIP [31])模型尤为具有代表性。CLIP由一个文本编码器和一个图像编码器组成，在从互联网收集的4亿个图像 - 文本对数据集上进行预训练，成功地对齐了两种模态的特征空间。这种方法在下游任务中表现出强大的泛化能力，并通过手动指定的文本提示实现了图像分类任务中的零样本迁移。受自然语言处理中提示学习技术的启发，Zhou等人[57]引入了一种可学习的上下文优化技术，以使像CLIP这样的视觉 - 语言模型适应图像识别任务。与依赖手动设计的提示不同，$\mathrm{{CoOp}}$(上下文优化)使用可学习的向量来对上下文单词进行建模，同时冻结预训练参数。这种方法使 $\mathrm{{CoOp}}$ 在有限的标记数据下表现出卓越的性能，在少样本场景中比手动提示工程有显著改进。为了进一步增强视觉和文本表示之间的对齐，Khattak等人[17]提出了一种方法，该方法同时对图像和文本分支应用提示学习，促进视觉和语言提示之间的强耦合，以确保它们相互协同。因此，Maple在对新类别的泛化能力上表现得明显更好，在性能上超过了 $\mathrm{{CoOp}}$。

## III. METHOD

## 三、方法

## A. Problem Definition

## A. 问题定义

Source-free unsupervised domain adaptation (SF-UDA) is an important sub-problem of unsupervised domain adaptation, focused on scenarios where source domain samples cannot be directly accessed during target domain training. This paper further explores an even more challenging scenario: the source domain samples are not only inaccessible but also limited in number.

无源无监督域适应(Source - free unsupervised domain adaptation，SF - UDA)是无监督域适应的一个重要子问题，专注于在目标域训练期间无法直接访问源域样本的场景。本文进一步探索了一个更具挑战性的场景:源域样本不仅无法访问，而且数量有限。

Specifically, given a labeled source domain dataset ${D}_{S} =$ ${\left\{  \left( {x}_{s}^{i},{y}_{s}^{i}\right) \right\}  }_{i = 1}^{{n}_{s}}$ with only a few samples and an unlabeled target domain dataset ${D}_{T} = {\left\{  {x}_{t}^{i}\right\}  }_{i = 1}^{{n}_{t}}$ , both ${D}_{S}$ and ${D}_{T}$ share the same labels but have different feature distributions. During the training of ${D}_{T}$ , direct access to ${D}_{S}$ is not allowed. Instead, a model ${M}_{S}$ is first trained using ${D}_{S}$ , and then ${M}_{S}$ is used to train on ${D}_{T}$ . Finally, the model’s performance is evaluated on ${D}_{T}$ .

具体来说，给定一个只有少量样本的带标签源域数据集 ${D}_{S} =$ ${\left\{  \left( {x}_{s}^{i},{y}_{s}^{i}\right) \right\}  }_{i = 1}^{{n}_{s}}$ 和一个无标签目标域数据集 ${D}_{T} = {\left\{  {x}_{t}^{i}\right\}  }_{i = 1}^{{n}_{t}}$，${D}_{S}$ 和 ${D}_{T}$ 具有相同的标签，但特征分布不同。在 ${D}_{T}$ 的训练过程中，不允许直接访问 ${D}_{S}$。相反，首先使用 ${D}_{S}$ 训练一个模型 ${M}_{S}$，然后使用 ${M}_{S}$ 在 ${D}_{T}$ 上进行训练。最后，在 ${D}_{T}$ 上评估模型的性能。

![0195dcf6-b307-7b10-9224-24b77c210989_3_148_154_1502_892_0.jpg](images/0195dcf6-b307-7b10-9224-24b77c210989_3_148_154_1502_892_0.jpg)

Fig. 2: The framework of CDBN, where ${E}_{img}$ represents the image encoder, ${E}_{\text{text }}$ represents the text encoder, ${T}_{t}$ denotes the class-shared soft prompt, and ${V}_{c}^{L}$ indicates the learnable token for the substitute class name of class c. Solid lines represent data flow, while dashed lines indicate the flow of values without gradient back-propagation. The flame symbol represents gradient updates, and the snowflake symbol indicates frozen gradients.

图2:CDBN的框架，其中 ${E}_{img}$ 表示图像编码器，${E}_{\text{text }}$ 表示文本编码器，${T}_{t}$ 表示类共享软提示，${V}_{c}^{L}$ 表示类c的替代类名的可学习标记。实线表示数据流，而虚线表示无梯度反向传播的值流。火焰符号表示梯度更新，雪花符号表示冻结的梯度。

## B. Overview of CDBN

## B. CDBN概述

In this study, we aim to address the challenges of not directly accessing the source domain during target domain training, as well as the limited number of samples in the source domain. As shown in Figure 2, we propose a data-efficient CLIP-powered dual-branch network.

在这项研究中，我们旨在解决在目标域训练期间无法直接访问源域以及源域样本数量有限的挑战。如图2所示，我们提出了一种数据高效的基于CLIP的双分支网络。

Specifically, we utilize the image encoder ${E}_{img}$ and text encoder ${E}_{\text{text }}$ from the CLIP model as the core network backbone. The model design includes a cross-domain feature transfer branch and a target-specific feature learning branch. The cross-domain feature transfer branch employs a cross-attention module with residual connections to fuse category text features ${G}^{s}$ , obtained from the source domain through prompt learning, with the features ${W}_{e}$ of high-confidence pseudo-label samples in the target domain, facilitating feature transfer from the source domain to the target domain. The target-specific feature learning branch focuses on learning category-specific features for the target domain through a class-shared soft prompt mechanism, designed to minimize interference from noise in the source domain category text features. Finally, the model employs a fused logits network (FLN) and utilizes an unsupervised optimization strategy that combines the pseudo-label loss ${L}_{CE}^{T}$ from high-confidence target domain samples, multi-view consistency loss ${L}_{\text{cons }}$ , and mutual information maximization loss ${L}_{IM}$ to train the model.

具体而言，我们将CLIP模型中的图像编码器 ${E}_{img}$ 和文本编码器 ${E}_{\text{text }}$ 用作核心网络主干。该模型设计包括一个跨域特征迁移分支和一个特定目标特征学习分支。跨域特征迁移分支采用带有残差连接的交叉注意力模块，将通过提示学习从源域获得的类别文本特征 ${G}^{s}$ 与目标域中高置信度伪标签样本的特征 ${W}_{e}$ 进行融合，促进特征从源域迁移到目标域。特定目标特征学习分支通过类共享软提示机制专注于为目标域学习特定类别的特征，旨在最大程度减少源域类别文本特征中噪声的干扰。最后，该模型采用融合对数几率网络(FLN)，并利用一种无监督优化策略，将来自高置信度目标域样本的伪标签损失 ${L}_{CE}^{T}$、多视图一致性损失 ${L}_{\text{cons }}$ 和互信息最大化损失 ${L}_{IM}$ 相结合来训练模型。

## C. Prompt Learning in the Source Domain

## C. 源域中的提示学习

In the SF-UDA scenario with limited source domain samples, the primary challenge is how to learn semantic information from minimal data during source domain supervised training that is beneficial for unsupervised fine-tuning in the target domain. Traditional SF-UDA methods typically utilize a large number of samples to train the model ${M}_{S}$ , learning the feature distribution of the source domain. Subsequently, during the target domain training phase, information from the source domain is extracted from this model to construct a virtual domain. This surrogate aligns cross-domain feature distributions to enhance target domain performance or further fine-tunes ${M}_{S}$ in the target domain using unsupervised or self-supervised methods to improve model performance.

在源域样本有限的SF - UDA场景中，主要挑战在于如何在源域有监督训练期间从少量数据中学习对目标域无监督微调有益的语义信息。传统的SF - UDA方法通常利用大量样本训练模型 ${M}_{S}$，学习源域的特征分布。随后，在目标域训练阶段，从该模型中提取源域的信息以构建一个虚拟域。这个替代域对齐跨域特征分布以提高目标域性能，或者使用无监督或自监督方法在目标域中进一步微调 ${M}_{S}$ 以提高模型性能。

However, in our scenario, due to the limited number of samples in the source domain, it is challenging to obtain a complete feature distribution through supervised learning, let alone extract the source domain feature distribution for feature alignment during target domain training. In recent years, CLIP-based prompt learning methods [10, 57] have demonstrated the ability to learn feature representations with a certain degree of generalization from a small number of labeled samples. Inspired by these methods, we utilize a pre-trained CLIP model as the backbone of our model and learn category-specific, learnable tokens for the text encoder ${E}_{\text{text }}$ . This enables us to obtain category text feature representations that have generalization capabilities for domain-shared class names from the limited source domain samples.

然而，在我们的场景中，由于源域样本数量有限，很难通过有监督学习获得完整的特征分布，更不用说在目标域训练期间提取源域特征分布进行特征对齐了。近年来，基于CLIP的提示学习方法 [10, 57] 已证明能够从少量有标签样本中学习具有一定泛化能力的特征表示。受这些方法的启发，我们将预训练的CLIP模型用作我们模型的主干，并为文本编码器 ${E}_{\text{text }}$ 学习特定类别的、可学习的标记。这使我们能够从有限的源域样本中获得对域共享类名具有泛化能力的类别文本特征表示。

Specifically, as shown in the Figure 2, we freeze the parameters of CLIP and employ a commonly used textual prompt "a photo of a" with $C$ learnable class-specific tokens ${V}^{L} = \left\{  {{V}_{0}^{L},{V}_{1}^{L}\ldots ,{V}_{C}^{L}}\right\}  ,{V}_{c}^{l} \in  {\mathcal{R}}_{D}$ , where $C$ denotes the number of classes. We concatenate the textual prompt with the class-specific tokens and use CLIP’s text encoder ${E}_{\text{text }}$ to obtain the feature representation for each class as:

具体而言，如图2所示，我们冻结CLIP的参数，并采用常用的文本提示“a photo of a”与 $C$ 个可学习的特定类标记 ${V}^{L} = \left\{  {{V}_{0}^{L},{V}_{1}^{L}\ldots ,{V}_{C}^{L}}\right\}  ,{V}_{c}^{l} \in  {\mathcal{R}}_{D}$ 相结合，其中 $C$ 表示类别数量。我们将文本提示与特定类标记连接起来，并使用CLIP的文本编码器 ${E}_{\text{text }}$ 为每个类别获得特征表示，如下所示:

$$
{g}_{c}^{S} = {E}_{\text{text }}\left( \left\lbrack  {\left\lbrack  a\right\rbrack  ,\left\lbrack  \text{ photo }\right\rbrack  ,\left\lbrack  \text{ of }\right\rbrack  ,\left\lbrack  a\right\rbrack  ,{V}_{c}^{L}}\right\rbrack  \right) .
$$

For a source domain sample ${x}_{i}^{S}$ , the probability of belonging to class $c$ is given by:

对于一个源域样本 ${x}_{i}^{S}$，属于类别 $c$ 的概率由下式给出: <img src="https://cdn.noedgeai.com/0195dcf6-b307-7b10-9224-24b77c210989_4.jpg?x=227&y=742&w=571&h=176&r=0"/>

(1)

where ${E}_{img}$ represents CLIP’s image encoder, and $\tau$ is a predefined temperature coefficient, set to 1 by default in this work. During the training of the source domain, we optimize ${V}^{L}$ using the cross-entropy loss ${\mathcal{L}}_{\mathrm{{CE}}}^{S}$ on the labeled source domain samples, as defined below:

其中 ${E}_{img}$ 表示CLIP的图像编码器，$\tau$ 是一个预定义的温度系数，在本工作中默认设置为1。在源域训练期间，我们使用有标签源域样本上的交叉熵损失 ${\mathcal{L}}_{\mathrm{{CE}}}^{S}$ 来优化 ${V}^{L}$，定义如下:

$$
{\mathcal{L}}_{\mathrm{{CE}}}^{S} =  - \frac{1}{{n}_{s}}\mathop{\sum }\limits_{{i = 1}}^{N}\mathop{\sum }\limits_{{c = 1}}^{C}{y}_{i, c}\log P\left( {{\widehat{y}}_{i} = c \mid  {x}_{i}^{S}}\right) , \tag{2}
$$

where ${n}_{s}$ denotes the number of source domain samples, and ${y}_{i, c}$ is the label indicating whether sample ${x}_{i}^{S}$ belongs to class $c$ . This loss function minimizes the discrepancy between the predicted class probability distribution and the true class distribution, thereby optimizing the class-specific tokens ${V}^{L}$ .

其中 ${n}_{s}$ 表示源域样本的数量，${y}_{i, c}$ 是指示样本 ${x}_{i}^{S}$ 是否属于类别 $c$ 的标签。这个损失函数最小化预测的类别概率分布与真实类别分布之间的差异，从而优化特定类标记 ${V}^{L}$。

## D. Cross-Modal Dual-Branch Networks

## D. 跨模态双分支网络

After obtaining the category text features learned from the source domain data, the limited sample size and domain discrepancy lead to noise and shifts in performance within the target domain. To retain useful category semantic information for the target domain while minimizing the introduction of noise that could affect the unsupervised training of target domain samples, we designed a cross-modal dual-branch network. This network includes a cross-domain feature transfer branch to adapt and correct for domain shifts, along with a target-specific feature learning branch to optimize the feature distribution specific to the target domain, preventing the model from overfitting to the category feature distribution learned from the source domain.

在获取从源域数据中学习到的类别文本特征后，有限的样本量和域差异会导致目标域内出现噪声和性能偏移。为了在目标域中保留有用的类别语义信息，同时尽量减少可能影响目标域样本无监督训练的噪声引入，我们设计了一个跨模态双分支网络。该网络包括一个跨域特征迁移分支，用于适应和纠正域偏移，以及一个特定于目标域的特征学习分支，用于优化目标域特有的特征分布，防止模型过度拟合从源域学习到的类别特征分布。

First, the function of the cross-domain feature transfer branch is to receive category text features from the source domain and transfer these features to the target domain using high-confidence target domain samples. This capability arises from the alignment of image and text feature distributions during CLIP's pre-training, mapping them to a shared low-dimensional space, which allows image features to assist category text features in making predictions. Previous work [55] has demonstrated the feasibility of this approach by using a key-value store composed of labeled image features to enhance the classification of category text features obtained from manually designed text prompts. Inspired by earlier studies $\left\lbrack  {1,{38}}\right\rbrack$ , we propose to use a cross-attention module with residual connections to enable the source domain category text features to attend to the corresponding pseudo-labeled target domain image samples and facilitate their fusion, thereby transferring the source domain category text features to the target domain.

首先，跨域特征迁移分支的功能是接收来自源域的类别文本特征，并使用高置信度的目标域样本将这些特征迁移到目标域。这种能力源于CLIP预训练期间图像和文本特征分布的对齐，将它们映射到一个共享的低维空间，这使得图像特征能够辅助类别文本特征进行预测。先前的工作[55]通过使用由标记图像特征组成的键值存储来增强从手动设计的文本提示中获得的类别文本特征的分类，证明了这种方法的可行性。受早期研究$\left\lbrack  {1,{38}}\right\rbrack$的启发，我们提出使用带有残差连接的交叉注意力模块，使源域类别文本特征能够关注相应的伪标记目标域图像样本并促进它们的融合，从而将源域类别文本特征迁移到目标域。

However, in our scenario, the target domain is unlabeled. To address this issue, we use the category text features from the source domain and the CLIP image encoder to obtain pseudo-labels for high-confidence samples in the target domain. As shown in the upper right corner of Figure 2, we utilize the category feature representation ${g}^{S}$ learned from the source domain to compute the prediction results for all target domain samples using Equation 1. For each sample, the maximum category confidence is taken as its score, and the respective category is assigned as its pseudo-label. Next, based on the pseudo-labels, we partition ${D}_{T}$ into $C$ subsets $\left\{  {{D}_{T}^{1},{D}_{T}^{2},\ldots ,{D}_{T}^{C}}\right\}$ . For each subset, we select the $K$ samples with the highest category confidence as high-confidence samples. Finally, we aggregate the high-confidence samples from all subsets to form a highly reliable target domain sample set ${D}_{T}^{\prime }$ . The reason for sorting within each subset is that the distribution of the maximum category confidence of CLIP's zero-shot is inconsistent across categories [15], and sorting directly among all samples would result in a long-tail distribution of selected samples.

然而，在我们的场景中，目标域是未标记的。为了解决这个问题，我们使用源域的类别文本特征和CLIP图像编码器来为目标域中的高置信度样本获取伪标签。如图2右上角所示，我们利用从源域学习到的类别特征表示${g}^{S}$，使用公式1计算所有目标域样本的预测结果。对于每个样本，将最大类别置信度作为其得分，并将相应的类别分配为其伪标签。接下来，基于伪标签，我们将${D}_{T}$划分为$C$个子集$\left\{  {{D}_{T}^{1},{D}_{T}^{2},\ldots ,{D}_{T}^{C}}\right\}$。对于每个子集，我们选择类别置信度最高的$K$个样本作为高置信度样本。最后，我们将所有子集中的高置信度样本聚合起来，形成一个高度可靠的目标域样本集${D}_{T}^{\prime }$。在每个子集中进行排序的原因是，CLIP零样本的最大类别置信度分布在各个类别之间不一致[15]，直接在所有样本中进行排序会导致所选样本出现长尾分布。

After obtaining high-confidence target domain samples, we use the image encoder $E$ to compute features for all samples. Then, based on the samples' pseudo-labels, we construct a target domain image feature library with category information, ${F}^{\prime } = \left\lbrack  {{F}_{1}^{\prime },{F}_{2}^{\prime },\ldots ,{F}_{C}^{\prime }}\right\rbrack$ , where ${F}_{c}^{\prime } = \left\lbrack  {{f}_{0, c}^{\prime },{f}_{1, c}^{\prime },\ldots ,{f}_{K, c}^{\prime }}\right\rbrack$ and ${f}_{k, c}^{\prime } = E\left( {x}_{k}^{T}\right)$ with ${x}_{k}^{T} \in  {D}_{T}^{c}$ .

在获得高置信度的目标域样本后，我们使用图像编码器$E$计算所有样本的特征。然后，基于样本的伪标签，我们构建一个带有类别信息的目标域图像特征库${F}^{\prime } = \left\lbrack  {{F}_{1}^{\prime },{F}_{2}^{\prime },\ldots ,{F}_{C}^{\prime }}\right\rbrack$，其中${F}_{c}^{\prime } = \left\lbrack  {{f}_{0, c}^{\prime },{f}_{1, c}^{\prime },\ldots ,{f}_{K, c}^{\prime }}\right\rbrack$和${f}_{k, c}^{\prime } = E\left( {x}_{k}^{T}\right)$与${x}_{k}^{T} \in  {D}_{T}^{c}$相关。

Then, we constructed two feature matrices: one initialized with the category text features learned from the source domain, denoted as ${G}^{S}$ with a shape of $\left\lbrack  {\mathrm{C},\mathrm{D}}\right\rbrack$ , where $\mathrm{C}$ is the number of categories and $\mathrm{D}$ is the dimension of the category text features. This matrix, containing semantic information learned from the source domain, is frozen during training. The other is a matrix ${W}_{e}$ initialized with high-confidence sample image features ${F}^{\prime }$ from the target domain, which has a shape of $\left\lbrack  {\mathrm{C},\mathrm{K},\mathrm{D}}\right\rbrack$ . Here, $K$ represents the number of high-confidence samples per category. This matrix is modified by parameter updates during training.

然后，我们构建了两个特征矩阵:一个用从源域学习到的类别文本特征初始化，记为${G}^{S}$，形状为$\left\lbrack  {\mathrm{C},\mathrm{D}}\right\rbrack$，其中$\mathrm{C}$是类别数量，$\mathrm{D}$是类别文本特征的维度。这个包含从源域学习到的语义信息的矩阵在训练期间被冻结。另一个是矩阵${W}_{e}$，用来自目标域的高置信度样本图像特征${F}^{\prime }$初始化，形状为$\left\lbrack  {\mathrm{C},\mathrm{K},\mathrm{D}}\right\rbrack$。这里，$K$表示每个类别中的高置信度样本数量。这个矩阵在训练期间通过参数更新进行修改。

Next, we use a cross-attention module with residual connections to fuse the target domain image feature matrix ${W}_{e}$ with the class text feature matrix ${G}^{S}$ learned from the source domain. During the fusion process, ${G}^{S}$ and ${W}_{e}$ are passed through independent linear layers and then used as the queries(Q)and keys/values(K, V)in the cross-attention layer, respectively. This approach allows each class text feature in ${G}^{S}$ to be enhanced by $K$ high-confidence samples of the corresponding class from ${W}_{e}$ . By encouraging the class text features to attend to the features of different image samples in the target domain, this improves the classification performance of the class text features on target samples.

接下来，我们使用带有残差连接的交叉注意力模块，将目标域图像特征矩阵 ${W}_{e}$ 与从源域学习到的类别文本特征矩阵 ${G}^{S}$ 进行融合。在融合过程中，${G}^{S}$ 和 ${W}_{e}$ 分别通过独立的线性层，然后分别作为交叉注意力层中的查询(Q)和键/值(K，V)。这种方法允许 ${G}^{S}$ 中的每个类别文本特征通过 ${W}_{e}$ 中对应类别的 $K$ 个高置信度样本得到增强。通过促使类别文本特征关注目标域中不同图像样本的特征，这提高了类别文本特征对目标样本的分类性能。

The attention output after ${W}_{e}$ and ${G}^{S}$ passes through the cross-attention layer is computed as follows:

${W}_{e}$ 和 ${G}^{S}$ 通过交叉注意力层后的注意力输出计算如下:

$$
A = \operatorname{Softmax}\left( \frac{\left( {{G}^{S} \cdot  {W}_{1}}\right)  \cdot  {\left( {W}_{e} \cdot  {W}_{2}\right) }^{T}}{\sqrt{{d}_{k}}}\right)  \cdot  {W}_{e}, \tag{3}
$$

where ${W}_{1}$ and ${W}_{2}$ are the weights of two linear layers. The weighted sum is then computed as:

其中 ${W}_{1}$ 和 ${W}_{2}$ 是两个线性层的权重。然后计算加权和如下:

$$
{W}_{g}^{ * } = {G}^{S} + \alpha  \cdot  A, \tag{4}
$$

where $\alpha  = {W}_{3} \cdot  {G}^{S}$ represents the class-specific weighting factor.

其中 $\alpha  = {W}_{3} \cdot  {G}^{S}$ 表示特定类别的加权因子。

Finally, for a target domain sample ${x}_{i}^{T}$ , we obtain the prediction result of this branch by calculating the cosine similarity between its image feature and the enhanced class text features as follows:

最后，对于目标域样本 ${x}_{i}^{T}$，我们通过计算其图像特征与增强后的类别文本特征之间的余弦相似度来获得该分支的预测结果，如下所示:

$$
{l}_{f}\left( {x}_{i}^{T}\right)  = \frac{{W}_{g}^{ * } \cdot  E\left( {x}_{i}^{T}\right) }{\begin{Vmatrix}{W}_{g}^{ * }\end{Vmatrix}\begin{Vmatrix}{E\left( {x}_{i}^{T}\right) }\end{Vmatrix}}. \tag{5}
$$

Although the performance of the enhanced source domain class text features ${W}_{g}^{ * }$ improves in the target domain, to further learn target-specific class text features, we introduce a branch that adapts CLIP to the target domain through learnable class-shared soft prompts, as shown in Figure 2. Specifically, we set up a learnable sequence of class-shared tokens ${T}_{t} = \left\lbrack  {{V}_{1}^{T},{V}_{2}^{T},\ldots ,{V}_{M}^{T}}\right\rbrack$ , where ${V}_{m}^{T} \in  {\mathbb{R}}^{D}$ and $M$ are the predefined numbers of learnable tokens. During prediction, we use this token sequence to replace the original text prompt to obtain the class text features ${g}_{c}^{T}$ . For a target domain sample ${x}_{i}^{T}$ , the classification result of this branch is given by:

尽管增强后的源域类别文本特征 ${W}_{g}^{ * }$ 在目标域中的性能有所提升，但为了进一步学习特定于目标域的类别文本特征，我们引入了一个分支，通过可学习的类别共享软提示将 CLIP(对比语言 - 图像预训练模型)适配到目标域，如图 2 所示。具体来说，我们设置了一个可学习的类别共享令牌序列 ${T}_{t} = \left\lbrack  {{V}_{1}^{T},{V}_{2}^{T},\ldots ,{V}_{M}^{T}}\right\rbrack$，其中 ${V}_{m}^{T} \in  {\mathbb{R}}^{D}$ 和 $M$ 是预定义的可学习令牌数量。在预测时，我们使用这个令牌序列替换原始文本提示以获得类别文本特征 ${g}_{c}^{T}$。对于目标域样本 ${x}_{i}^{T}$，该分支的分类结果由下式给出:

$$
{l}_{g}\left( {x}_{i}^{T}\right)  = \frac{{W}_{g}^{T} \cdot  E\left( {x}_{i}^{T}\right) }{\begin{Vmatrix}{W}_{g}^{T}\end{Vmatrix}\begin{Vmatrix}{E\left( {x}_{i}^{T}\right) }\end{Vmatrix}}. \tag{6}
$$

Finally, we compute the weighted sum of the predictions from both branches to obtain the final classification result, which is formulated as follows:

最后，我们计算两个分支预测结果的加权和以获得最终的分类结果，公式如下:

$$
\widehat{P}\left( {x}_{i}^{T}\right)  = \delta \left( {\alpha {l}_{f}\left( {x}_{i}^{T}\right)  + \left( {1 - \alpha }\right) {l}_{g}\left( {x}_{i}^{T}\right) }\right) , \tag{7}
$$

where $\delta$ represents the softmax function, $\alpha$ is a predefined hyper-parameter between 0 and 1 , set to 0.5 by default in this work.

其中 $\delta$ 表示 softmax 函数，$\alpha$ 是一个预定义的介于 0 和 1 之间的超参数，在本工作中默认设置为 0.5。

## E. Unsupervised Optimization Strategy Driven by Accurate Classification and Diversity

## E. 由准确分类和多样性驱动的无监督优化策略

As described in Section III-D, the strategy proposed in this paper differs from most Source-Free Unsupervised Domain Adaptation (SF-UDA) methods in that it does not directly fine-tune a model trained in the source domain. Instead, we use class textual features learned from the source domain as a source of semantic information within a cross-domain feature transfer branch to balance semantic information from both the source and target domains during target domain training. This method enables the model to effectively transfer semantic information from the source domain while minimizing the noise and domain shift effects present in the feature distribution learned from a limited number of source domain samples. However, this strategy might result in a lack of fundamental classification capabilities at the initial stages of target domain training. To address this shortcoming, we introduce an Unsupervised Optimization Strategy Driven by Accurate Classification and Diversity, which aims to maintain the classification abilities learned from the source domain while further enhancing the model's classification performance in the target domain.

如第三节 - D 所述，本文提出的策略与大多数无源无监督域适应(SF - UDA)方法不同，它不直接微调在源域训练的模型。相反，我们将从源域学习到的类别文本特征作为跨域特征转移分支中的语义信息源，以在目标域训练期间平衡来自源域和目标域的语义信息。这种方法使模型能够有效地从源域转移语义信息，同时最大限度地减少从有限数量的源域样本中学习到的特征分布中存在的噪声和域偏移影响。然而，这种策略可能会导致在目标域训练的初始阶段缺乏基本的分类能力。为了解决这个缺点，我们引入了一种由准确分类和多样性驱动的无监督优化策略，旨在保持从源域学习到的分类能力，同时进一步提高模型在目标域中的分类性能。

Specifically, we utilize the high-confidence sample set ${D}_{T}^{\prime }$ , filtered as mentioned in Section III-D, as a reliable collection with pseudo-labels. The classification capability of the source domain model is restored through the computation of cross-entropy loss between these samples and their pseudo-labels. The formula for this computation is as follows:

具体来说，我们利用如第三节 - D 中所述过滤得到的高置信度样本集 ${D}_{T}^{\prime }$ 作为带有伪标签的可靠集合。通过计算这些样本与其伪标签之间的交叉熵损失来恢复源域模型的分类能力。该计算的公式如下:

$$
{\mathcal{L}}_{\mathrm{{CE}}}^{T} =  - \frac{1}{B}\mathop{\sum }\limits_{{i = 1}}^{B}\mathop{\sum }\limits_{{c = 1}}^{C}{\widehat{y}}_{i}^{T}\left\lbrack  c\right\rbrack  \log \widehat{P}\left( {x}_{i}^{T}\right) \left\lbrack  c\right\rbrack   \tag{8}
$$

where $B$ is the batch size during training, $C$ is the number of classes, and ${\widehat{y}}_{i}^{T}\left\lbrack  k\right\rbrack$ is the one-hot encoding of the pseudo-label ${\widehat{y}}_{i}^{T}$ .

其中 $B$ 是训练期间的批量大小，$C$ 是类别数量，${\widehat{y}}_{i}^{T}\left\lbrack  k\right\rbrack$ 是伪标签 ${\widehat{y}}_{i}^{T}$ 的独热编码。

Although the aforementioned cross-entropy loss can enhance the model's classification capabilities, the limited number of samples involved in training results in a more uniform distribution of learned class features, which restricts its generalization ability. To address this issue, we draw inspiration from the semi-supervised learning method FixMatch [37], utilizing a multi-view consistency loss to increase the diversity of the class feature distribution learned by the model. This approach encourages the model to maintain consistent predictions across different augmentations of the same image, thereby broadening the feature distribution and enhancing the robustness and generalization of the model.

尽管上述交叉熵损失可以增强模型的分类能力，但训练中涉及的样本数量有限，导致学习到的类别特征分布更加均匀，这限制了其泛化能力。为了解决这个问题，我们从半监督学习方法FixMatch [37]中获得灵感，利用多视图一致性损失来增加模型学习到的类别特征分布的多样性。这种方法鼓励模型对同一图像的不同增强版本保持一致的预测，从而拓宽特征分布，增强模型的鲁棒性和泛化能力。

Specifically, for a target domain sample ${x}_{i}^{T}$ , we apply one strong augmentation ${\varphi }_{s}$ and one weak augmentation ${\varphi }_{w}$ , using the default settings specified in FixMatch. Subsequently, the predictions under these two different augmentation views, ${\widehat{P}}_{i}^{w}$ and ${\widehat{P}}_{i}^{S}$ , are obtained as per the Equation 7. For the prediction under weak augmentation, we derive its corresponding one-hot encoded pseudo-label and compute the cross-entropy loss with the prediction under strong augmentation. Furthermore, considering that pseudo-labels may contain errors, we filter out samples based on the maximum class confidence, discarding those with confidence lower than a predefined threshold ${\theta }_{T}$ . The specific formula for loss calculation is as follows:

具体来说，对于目标域样本 ${x}_{i}^{T}$ ，我们应用一种强增强 ${\varphi }_{s}$ 和一种弱增强 ${\varphi }_{w}$ ，使用FixMatch中指定的默认设置。随后，根据公式7获得这两种不同增强视图下的预测结果 ${\widehat{P}}_{i}^{w}$ 和 ${\widehat{P}}_{i}^{S}$ 。对于弱增强下的预测结果，我们推导出其对应的one-hot编码伪标签，并与强增强下的预测结果计算交叉熵损失。此外，考虑到伪标签可能包含错误，我们根据最大类别置信度过滤样本，丢弃置信度低于预定义阈值 ${\theta }_{T}$ 的样本。损失计算的具体公式如下:

$$
{\mathcal{L}}_{\text{consistency }} = \frac{1}{B}\mathop{\sum }\limits_{{i = 1}}^{B}\mathbf{1}\left( {\max \left( {\widehat{P}}_{i}^{W}\right)  \geq  {\theta }_{T}}\right)  \cdot  \mathrm{{CE}}\left( {{\widehat{y}}_{i}^{W},{\widehat{P}}_{i}^{S}}\right) , \tag{9}
$$

where $\mathbf{1}\left( \cdot \right)$ is an indicator function that takes the value 1 if the condition is satisfied and 0 otherwise. Here, ${\theta }_{T}$ is set to a default value of 0.95, and ${\widehat{y}}_{i}^{W} = \arg \max \left( {\widehat{P}}_{i}^{W}\right)$ is the pseudo-label generated from the predictions under weak augmentation.

其中 $\mathbf{1}\left( \cdot \right)$ 是一个指示函数，如果条件满足则取值为1，否则取值为0。这里， ${\theta }_{T}$ 的默认值设置为0.95， ${\widehat{y}}_{i}^{W} = \arg \max \left( {\widehat{P}}_{i}^{W}\right)$ 是从弱增强下的预测结果生成的伪标签。

Although ${\mathcal{L}}_{\text{consistency }}$ enhances the diversity of the model’s learned class feature distribution, it fundamentally relies on pseudo-label information, which might bias the model towards categories that are easier to classify. For samples that are inherently more difficult to distinguish, the model may still make classification errors. To address this issue, and inspired by previous work $\left\lbrack  {{24},{52}}\right\rbrack$ , we aim to maximize the mutual information between the model's output class distribution and the input data. This approach encourages the model's outputs to exhibit both individual certainty and global diversity, thus reducing the reliance on potentially inaccurate pseudo-labels and improving the robustness of the classification across more complex or ambiguous categories.

尽管 ${\mathcal{L}}_{\text{consistency }}$ 增强了模型学习到的类别特征分布的多样性，但它从根本上依赖于伪标签信息，这可能会使模型偏向于更容易分类的类别。对于本质上更难区分的样本，模型仍然可能会出现分类错误。为了解决这个问题，受先前工作 $\left\lbrack  {{24},{52}}\right\rbrack$ 的启发，我们旨在最大化模型输出的类别分布与输入数据之间的互信息。这种方法鼓励模型的输出既具有个体确定性又具有全局多样性，从而减少对可能不准确的伪标签的依赖，并提高在更复杂或模糊类别上的分类鲁棒性。

Specifically, this loss consists of two parts: individual entropy loss and global entropy loss. The individual entropy loss aims to reduce the classification uncertainty of each sample within a batch. The calculation formula for individual entropy loss is as follows:

具体来说，这种损失由两部分组成:个体熵损失和全局熵损失。个体熵损失旨在减少一批样本中每个样本的分类不确定性。个体熵损失的计算公式如下:

$$
{\mathcal{L}}_{\text{instance }} = \frac{1}{B}\mathop{\sum }\limits_{{i = 1}}^{B}H\left( {\mathbf{p}}_{i}\right)  =  - \frac{1}{B}\mathop{\sum }\limits_{{i = 1}}^{B}\mathop{\sum }\limits_{{j = 1}}^{C}{p}_{ij}\log \left( {p}_{ij}\right) , \tag{10}
$$

where ${\mathbf{p}}_{i}$ is the predicted probability distribution for sample $i$ , and ${p}_{ij}$ represents the probability of sample $i$ belonging to class $j$ .

其中 ${\mathbf{p}}_{i}$ 是样本 $i$ 的预测概率分布， ${p}_{ij}$ 表示样本 $i$ 属于类别 $j$ 的概率。

Global entropy loss is calculated by first determining the mean predicted probability for each class across all samples in a batch, resulting in a global probability distribution. The formula to maximize the entropy of this distribution, thus encouraging the model to encompass a broader range of classes, is as follows:

全局熵损失的计算方法是，首先确定一批中所有样本每个类别的平均预测概率，从而得到一个全局概率分布。最大化该分布的熵，从而鼓励模型涵盖更广泛类别的公式如下:

$$
{\mathcal{L}}_{\text{global }} =  - \mathop{\sum }\limits_{{j = 1}}^{C}{\bar{p}}_{j}\log \left( {\bar{p}}_{j}\right) , \tag{11}
$$

where ${\bar{p}}_{j}$ is the average probability of samples belonging to class $j$ across the batch.

其中 ${\bar{p}}_{j}$ 是一批中样本属于类别 $j$ 的平均概率。

Ultimately, the sum of the individual entropy loss and the global entropy loss serves to maximize the mutual information between the model's output class distribution and the input data. The combined loss formula is given by:

最终，个体熵损失和全局熵损失之和用于最大化模型输出的类别分布与输入数据之间的互信息。组合损失公式如下:

$$
{\mathcal{L}}_{\mathrm{{IM}}} =  - \frac{1}{N}\mathop{\sum }\limits_{{i = 1}}^{N}\mathop{\sum }\limits_{{j = 1}}^{C}{p}_{ij}\log \left( {p}_{ij}\right)  + \mathop{\sum }\limits_{{j = 1}}^{C}{\bar{p}}_{j}\log \left( {\bar{p}}_{j}\right) . \tag{12}
$$

Ultimately, during the training on the target domain, the total loss function of the model is:

最终，在目标域上进行训练时，模型的总损失函数为:

$$
{\mathcal{L}}_{\mathrm{T}} = {\mathcal{L}}_{\mathrm{{CE}}} + {\mathcal{L}}_{\text{consistency }} + {\mathcal{L}}_{\mathrm{{IM}}} \tag{13}
$$

## IV. EXPERIMENTS

## 四、实验

## A. Experiments Setting

## A. 实验设置

1) Datasets: To prove the effectiveness of our proposed method, we refer to the previous method [24, 26] and select four public standard domain adaptation datasets and three publicly available remote sensing domain scene recognition datasets to evaluate our methods, which are Office-31 [32], Office-Home [47], VisDA [28], Mini-DomainNet [29], UC Merced Land-Use [53], NWPU-RESISC45 [2] and AID [50]. Office-31 and Office-Home are small and medium-sized datasets, VisDA and Mini-DomainNet are both large-scale datasets, and the latter two are more challenging for Source-free domain adaptation tasks. UC Merced Land-Use is a small remote sensing image dataset, while NWPU-RESISC45 and AID are two larger datasets. Overall, we validate the effectiveness of our method on these 7 datasets with 31 different transfer tasks.

1) 数据集:为了证明我们提出的方法的有效性，我们参考先前的方法 [24, 26]，选择四个公共标准领域适应数据集和三个公开可用的遥感领域场景识别数据集来评估我们的方法，它们分别是Office - 31 [32]、Office - Home [47]、VisDA [28]、Mini - DomainNet [29]、UC Merced Land - Use [53]、NWPU - RESISC45 [2] 和AID [50]。Office - 31和Office - Home是中小型数据集，VisDA和Mini - DomainNet都是大规模数据集，后者对于无源领域适应任务更具挑战性。UC Merced Land - Use是一个小型遥感图像数据集，而NWPU - RESISC45和AID是两个较大的数据集。总体而言，我们在这7个数据集上的31个不同迁移任务中验证了我们方法的有效性。

Office-31 is a small benchmark with 4,652 images from 31 categories, collected from 3 different domains: Amazon (A), DSLR (D), and Webcam (W).

Office - 31是一个小型基准数据集，包含来自31个类别的4652张图像，这些图像收集自3个不同的领域:亚马逊(A)、数码单反相机(D)和网络摄像头(W)。

Office-Home is a medium-scale benchmark, it has 15,588 images from 65 categories across 4 domains, Art(Ar), Cli-part(Cl), Product(Pr), and Real-World(Rw).

Office - Home是一个中等规模的基准数据集，它包含来自4个领域65个类别的15588张图像，这4个领域分别是艺术(Ar)、剪贴画(Cl)、产品(Pr)和现实世界(Rw)。

VisDA is a large-scale dataset with synthetic source and real target domains. It has 12 classes, the synthetic source domain contains 152,397 images, and the real target domain contains 55,388 images.

VisDA是一个大规模数据集，具有合成源域和真实目标域。它有12个类别，合成源域包含152397张图像，真实目标域包含55388张图像。

Mini-DomainNet is another large-scale dataset collected from 4 domains, Real(Rl), Sketch(Sk), Clipart(Cl) and Painting(Pn). In the previous source-free domain adaptation tasks, they usually evaluate the methods on 7 transfer tasks due to the severe noisy labels in the dataset [33]. Now, we can use the clean version of the dataset and evaluate our method on 12 transfer tasks.

Mini - DomainNet是另一个从4个领域收集的大规模数据集，这4个领域分别是真实场景(Rl)、素描(Sk)、剪贴画(Cl)和绘画(Pn)。在之前的无源域自适应任务中，由于数据集中存在严重的噪声标签，他们通常在7个迁移任务上评估这些方法[33]。现在，我们可以使用该数据集的干净版本，并在12个迁移任务上评估我们的方法。

UC Merced Land-Use, abbreviated as UCM hereafter, is a remote sensing dataset released in 2010 by the Computer Vision Laboratory at UC Merced. It is widely used for remote scene recognition to categorize land-use scenes in urban areas. The dataset contains 21 categories, each with 100 remote sensing images of size ${256} \times  {256}$ pixels, amounting to a total of 2,100 images.

加州大学默塞德分校土地利用数据集(UC Merced Land - Use)，以下简称UCM，是加州大学默塞德分校计算机视觉实验室于2010年发布的一个遥感数据集。它广泛用于遥感场景识别，以对城市地区的土地利用场景进行分类。该数据集包含21个类别，每个类别有100张大小为 ${256} \times  {256}$ 像素的遥感图像，总共2100张图像。

NWPU-RESISC45, referred to as NWPU in this document, is a benchmark for remote sensing scene recognition, developed by Northwestern Polytechnical University (NWPU) in 2017. It consists of 45 scene categories, each containing 700 images, for a total of 31,500 images, all with a resolution of ${256} \times  {256}$ pixels.

西北工业大学遥感图像场景分类数据集(NWPU - RESISC45)，本文中简称为NWPU，是一个用于遥感场景识别的基准数据集，由西北工业大学(NWPU)于2017年开发。它由45个场景类别组成，每个类别包含700张图像，总共31500张图像，所有图像的分辨率均为 ${256} \times  {256}$ 像素。

AID is a large collection of remote sensing aerial imagery. The samples are sourced from Google Earth and gathered using various remote sensing imagery sensors. The images for each category come from different countries and regions, captured at various times of the day, leading to variations in lighting conditions. Additionally, images are collected across different seasons, reflecting changes in vegetation and surface features, resulting in significant intra-class variations. The dataset consists of a total of 10,000 remote sensing scene images across 30 categories, with the number of images per category ranging from 200 to 420 .

AID是一个大型的遥感航空影像集合。样本来源于谷歌地球，并使用各种遥感影像传感器收集。每个类别的图像来自不同的国家和地区，在一天中的不同时间拍摄，导致光照条件存在差异。此外，图像是在不同季节收集的，反映了植被和地表特征的变化，从而导致显著的类内差异。该数据集总共包含30个类别、10000张遥感场景图像，每个类别的图像数量从200到420张不等。

2) Implementation Details: We utilized a pre-trained CLIP model as the backbone network and compared two image encoder architectures: ResNet-50[14] and ViT-B/16[6]. In experiments conducted on the VisDA-2017 dataset, we employed ResNet-101 to ensure a fair comparison with other methods. The optimizer used was Adam, with a momentum of 0.9 and a weight decay set to $5 \times  {10}^{-4}$ . The initial learning rate was set at 0.001 . During the adaptive training phase, we implemented a cosine annealing learning rate scheduler for dynamic adjustment. In our experiments, the batch size was set to 32, with $\alpha$ set to ${0.5}, K$ set to 8, and $M$ set to 16 . During the experiment, we randomly selected 8 samples from each category in the source domain and calculated the average of the results obtained under three different random seeds as the final result. All experiments were designed and implemented using the PyTorch platform.

2) 实现细节:我们使用预训练的CLIP模型作为骨干网络，并比较了两种图像编码器架构:ResNet - 50[14]和ViT - B/16[6]。在VisDA - 2017数据集上进行的实验中，我们采用ResNet - 101以确保与其他方法进行公平比较。使用的优化器是Adam，动量为0.9，权重衰减设置为 $5 \times  {10}^{-4}$ 。初始学习率设置为0.001。在自适应训练阶段，我们实现了一个余弦退火学习率调度器进行动态调整。在我们的实验中，批量大小设置为32， $\alpha$ 设置为 ${0.5}, K$ 设置为8， $M$ 设置为16。在实验过程中，我们从源域的每个类别中随机选择8个样本，并将在三种不同随机种子下获得的结果的平均值作为最终结果。所有实验均使用PyTorch平台进行设计和实现。

<table><tr><td>Method</td><td>SF</td><td>Source</td><td>${E}_{img}$</td><td>$\mathrm{{Ar}} \rightarrow  \mathrm{{Cl}}$</td><td>$\mathrm{{Ar}} \rightarrow  \mathrm{{Pr}}$</td><td>$\mathrm{{Ar}} \rightarrow  \mathrm{{Rw}}$</td><td>$\mathrm{{Cl}} \rightarrow  \mathrm{{Ar}}$</td><td>$\mathrm{{Cl}} \rightarrow  \mathrm{{Pr}}$</td><td>$\mathrm{{Cl}} \rightarrow  \mathrm{{Rw}}$</td><td>$\Pr  \rightarrow  \mathrm{{Ar}}$</td><td>$\mathrm{{Pr}} \rightarrow  \mathrm{{Cl}}$</td><td>$\mathrm{{Pr}} \rightarrow  \mathrm{{Rw}}$</td><td>$\mathrm{{Rw}} \rightarrow  \mathrm{{Ar}}$</td><td>$\mathrm{{Rw}} \rightarrow  \mathrm{{Cl}}$</td><td>$\mathrm{{Rw}} \rightarrow  \mathrm{{Pr}}$</td><td>Avg</td></tr><tr><td>RN-50 [13]</td><td>N/A</td><td>ample</td><td rowspan="13">RN-50</td><td>34.9</td><td>50.0</td><td>58.0</td><td>37.4</td><td>41.9</td><td>46.2</td><td>38.5</td><td>31.2</td><td>60.4</td><td>53.9</td><td>41.2</td><td>59.9</td><td>46.1</td></tr><tr><td>SHOT [24]</td><td>✓</td><td>ample</td><td>57.1</td><td>78.1</td><td>81.5</td><td>68.0</td><td>78.2</td><td>78.1</td><td>67.4</td><td>54.9</td><td>82.2</td><td>73.3</td><td>58.8</td><td>84.3</td><td>71.8</td></tr><tr><td>GKD [40]</td><td>✓</td><td>ample</td><td>56.5</td><td>78.2</td><td>81.8</td><td>68.7</td><td>78.9</td><td>79.1</td><td>67.6</td><td>54.8</td><td>82.6</td><td>74.4</td><td>58.5</td><td>84.8</td><td>72.1</td></tr><tr><td>PS [7]</td><td>✓</td><td>ample</td><td>57.8</td><td>77.3</td><td>81.2</td><td>68.4</td><td>76.9</td><td>78.1</td><td>67.8</td><td>57.3</td><td>82.1</td><td>75.2</td><td>59.1</td><td>83.4</td><td>72.1</td></tr><tr><td>D-MCD [3]</td><td>✓</td><td>ample</td><td>59.4</td><td>78.9</td><td>80.2</td><td>67.2</td><td>79.3</td><td>78.6</td><td>65.3</td><td>55.6</td><td>82.2</td><td>73.3</td><td>62.8</td><td>83.9</td><td>72.2</td></tr><tr><td>${\mathrm{A}}^{2}$ Net [51]</td><td>✓</td><td>ample</td><td>58.4</td><td>79.0</td><td>82.4</td><td>67.5</td><td>79.3</td><td>78.9</td><td>68.0</td><td>56.2</td><td>82.9</td><td>74.1</td><td>60.5</td><td>85.0</td><td>72.8</td></tr><tr><td>SCLM [41]</td><td>✓</td><td>ample</td><td>58.2</td><td>80.3</td><td>81.5</td><td>69.3</td><td>79.0</td><td>80.7</td><td>69.0</td><td>56.8</td><td>82.7</td><td>74.7</td><td>60.6</td><td>85.0</td><td>73.1</td></tr><tr><td>AAA [22]</td><td>✓</td><td>ample</td><td>56.7</td><td>78.3</td><td>82.1</td><td>66.4</td><td>78.5</td><td>79.4</td><td>67.6</td><td>53.5</td><td>81.6</td><td>74.5</td><td>58.4</td><td>84.1</td><td>71.8</td></tr><tr><td>CoWA [21]</td><td>✓</td><td>ample</td><td>56.9</td><td>78.4</td><td>81.0</td><td>69.1</td><td>80.0</td><td>79.9</td><td>67.7</td><td>57.2</td><td>82.4</td><td>72.8</td><td>60.5</td><td>84.5</td><td>72.5</td></tr><tr><td>ProxyMix [5]</td><td>✓</td><td>ample</td><td>59.3</td><td>81.0</td><td>81.6</td><td>65.8</td><td>79.7</td><td>78.1</td><td>67.0</td><td>57.5</td><td>82.7</td><td>73.1</td><td>61.7</td><td>85.6</td><td>72.8</td></tr><tr><td>C-SFDA [16]</td><td>✓</td><td>ample</td><td>60.3</td><td>80.2</td><td>82.9</td><td>69.3</td><td>80.1</td><td>78.8</td><td>67.3</td><td>58.1</td><td>83.4</td><td>73.6</td><td>61.3</td><td>86.3</td><td>73.5</td></tr><tr><td>TPDS [42]</td><td>✓</td><td>ample</td><td>59.3</td><td>80.3</td><td>82.1</td><td>70.6</td><td>79.4</td><td>80.9</td><td>69.8</td><td>56.8</td><td>82.1</td><td>74.5</td><td>61.2</td><td>85.3</td><td>73.5</td></tr><tr><td>CPD [58]</td><td>✓</td><td>ample</td><td>59.1</td><td>79.0</td><td>82.4</td><td>68.5</td><td>79.7</td><td>79.5</td><td>67.9</td><td>57.9</td><td>82.8</td><td>73.8</td><td>61.2</td><td>84.6</td><td>73.0</td></tr><tr><td>CLIP [31]</td><td>N/A</td><td>no</td><td/><td>51.6</td><td>81.9</td><td>82.6</td><td>71.9</td><td>81.9</td><td>82.6</td><td>71.9</td><td>51.6</td><td>82.6</td><td>71.9</td><td>51.6</td><td>81.9</td><td>72.0</td></tr><tr><td>DAPL [11]</td><td>✘</td><td>ample</td><td rowspan="5">RN-50</td><td>54.1</td><td>84.3</td><td>84.8</td><td>74.4</td><td>83.7</td><td>85.0</td><td>74.5</td><td>54.6</td><td>84.8</td><td>75.2</td><td>54.7</td><td>83.8</td><td>74.5</td></tr><tr><td>PADCLIP [19]</td><td>✘</td><td>ample</td><td>57.5</td><td>84.0</td><td>83.8</td><td>77.8</td><td>85.5</td><td>84.7</td><td>76.3</td><td>59.2</td><td>85.4</td><td>78.1</td><td>60.2</td><td>86.7</td><td>76.6</td></tr><tr><td>ADCLIP [35]</td><td>✘</td><td>ample</td><td>55.4</td><td>85.2</td><td>85.6</td><td>76.1</td><td>85.8</td><td>86.2</td><td>76.7</td><td>56.1</td><td>85.4</td><td>76.8</td><td>56.1</td><td>85.5</td><td>75.9</td></tr><tr><td>Ours-Source</td><td>N/A</td><td>8-shots</td><td>52.7</td><td>84.8</td><td>83.6</td><td>70.2</td><td>83.2</td><td>82.6</td><td>69.7</td><td>50.3</td><td>82.8</td><td>71.6</td><td>51.6</td><td>84.3</td><td>72.2</td></tr><tr><td>Ours</td><td>✓</td><td>8-shots</td><td>59.2</td><td>89.4</td><td>87.1</td><td>77.0</td><td>89.0</td><td>87.0</td><td>76.6</td><td>59.1</td><td>87.3</td><td>76.9</td><td>59.9</td><td>88.9</td><td>78.1</td></tr><tr><td>DSiT-B* [34]</td><td>✓</td><td>ample</td><td rowspan="7">ViT-B/16</td><td>69.2</td><td>83.5</td><td>87.3</td><td>80.7</td><td>86.1</td><td>86.2</td><td>77.9</td><td>67.9</td><td>86.6</td><td>82.4</td><td>68.3</td><td>89.8</td><td>80.5</td></tr><tr><td>CLIP [31]</td><td>N/A</td><td>no</td><td>67.8</td><td>89.0</td><td>89.8</td><td>82.9</td><td>89.0</td><td>89.8</td><td>82.9</td><td>67.8</td><td>89.8</td><td>82.9</td><td>67.8</td><td>89.0</td><td>82.4</td></tr><tr><td>DAPL [11]</td><td>✘</td><td>ample</td><td>70.7</td><td>91.0</td><td>90.9</td><td>85.2</td><td>91.0</td><td>91.0</td><td>85.1</td><td>70.7</td><td>90.9</td><td>85.3</td><td>70.4</td><td>91.4</td><td>84.4</td></tr><tr><td>PADCLIP [19]</td><td>✘</td><td>ample</td><td>76.4</td><td>90.6</td><td>90.8</td><td>86.7</td><td>92.3</td><td>92.0</td><td>86.0</td><td>74.5</td><td>91.5</td><td>86.9</td><td>79.1</td><td>93.1</td><td>86.7</td></tr><tr><td>ADCLIP [35]</td><td>✘</td><td>ample</td><td>70.9</td><td>92.5</td><td>92.1</td><td>85.4</td><td>92.4</td><td>92.5</td><td>86.7</td><td>74.3</td><td>93.0</td><td>86.9</td><td>72.6</td><td>93.8</td><td>86.1</td></tr><tr><td>Ours-Source</td><td>N/A</td><td>8-shots</td><td>69.0</td><td>89.6</td><td>90.1</td><td>81.8</td><td>91.1</td><td>89.9</td><td>79.7</td><td>67.8</td><td>88.9</td><td>82.5</td><td>68.6</td><td>90.4</td><td>82.5</td></tr><tr><td>Ours</td><td>✓</td><td>8-shots</td><td>73.9</td><td>94.1</td><td>91.6</td><td>85.7</td><td>94.3</td><td>91.7</td><td>84.9</td><td>73.7</td><td>91.9</td><td>85.5</td><td>72.7</td><td>94.0</td><td>86.2</td></tr></table>

<table><tbody><tr><td>方法</td><td>SF(原文未明确含义，保留英文)</td><td>源</td><td>${E}_{img}$</td><td>$\mathrm{{Ar}} \rightarrow  \mathrm{{Cl}}$</td><td>$\mathrm{{Ar}} \rightarrow  \mathrm{{Pr}}$</td><td>$\mathrm{{Ar}} \rightarrow  \mathrm{{Rw}}$</td><td>$\mathrm{{Cl}} \rightarrow  \mathrm{{Ar}}$</td><td>$\mathrm{{Cl}} \rightarrow  \mathrm{{Pr}}$</td><td>$\mathrm{{Cl}} \rightarrow  \mathrm{{Rw}}$</td><td>$\Pr  \rightarrow  \mathrm{{Ar}}$</td><td>$\mathrm{{Pr}} \rightarrow  \mathrm{{Cl}}$</td><td>$\mathrm{{Pr}} \rightarrow  \mathrm{{Rw}}$</td><td>$\mathrm{{Rw}} \rightarrow  \mathrm{{Ar}}$</td><td>$\mathrm{{Rw}} \rightarrow  \mathrm{{Cl}}$</td><td>$\mathrm{{Rw}} \rightarrow  \mathrm{{Pr}}$</td><td>平均值</td></tr><tr><td>ResNet - 50 [13](RN - 50)</td><td>不适用</td><td>样本</td><td rowspan="13">ResNet - 50(RN - 50)</td><td>34.9</td><td>50.0</td><td>58.0</td><td>37.4</td><td>41.9</td><td>46.2</td><td>38.5</td><td>31.2</td><td>60.4</td><td>53.9</td><td>41.2</td><td>59.9</td><td>46.1</td></tr><tr><td>SHOT [24](原文未明确含义，保留英文)</td><td>√</td><td>样本</td><td>57.1</td><td>78.1</td><td>81.5</td><td>68.0</td><td>78.2</td><td>78.1</td><td>67.4</td><td>54.9</td><td>82.2</td><td>73.3</td><td>58.8</td><td>84.3</td><td>71.8</td></tr><tr><td>GKD [40](原文未明确含义，保留英文)</td><td>√</td><td>样本</td><td>56.5</td><td>78.2</td><td>81.8</td><td>68.7</td><td>78.9</td><td>79.1</td><td>67.6</td><td>54.8</td><td>82.6</td><td>74.4</td><td>58.5</td><td>84.8</td><td>72.1</td></tr><tr><td>PS [7](原文未明确含义，保留英文)</td><td>√</td><td>样本</td><td>57.8</td><td>77.3</td><td>81.2</td><td>68.4</td><td>76.9</td><td>78.1</td><td>67.8</td><td>57.3</td><td>82.1</td><td>75.2</td><td>59.1</td><td>83.4</td><td>72.1</td></tr><tr><td>D - MCD [3](原文未明确含义，保留英文)</td><td>√</td><td>样本</td><td>59.4</td><td>78.9</td><td>80.2</td><td>67.2</td><td>79.3</td><td>78.6</td><td>65.3</td><td>55.6</td><td>82.2</td><td>73.3</td><td>62.8</td><td>83.9</td><td>72.2</td></tr><tr><td>${\mathrm{A}}^{2}$ 网络 [51]</td><td>√</td><td>样本</td><td>58.4</td><td>79.0</td><td>82.4</td><td>67.5</td><td>79.3</td><td>78.9</td><td>68.0</td><td>56.2</td><td>82.9</td><td>74.1</td><td>60.5</td><td>85.0</td><td>72.8</td></tr><tr><td>SCLM [41](原文未明确含义，保留英文)</td><td>√</td><td>样本</td><td>58.2</td><td>80.3</td><td>81.5</td><td>69.3</td><td>79.0</td><td>80.7</td><td>69.0</td><td>56.8</td><td>82.7</td><td>74.7</td><td>60.6</td><td>85.0</td><td>73.1</td></tr><tr><td>AAA [22](原文未明确含义，保留英文)</td><td>√</td><td>样本</td><td>56.7</td><td>78.3</td><td>82.1</td><td>66.4</td><td>78.5</td><td>79.4</td><td>67.6</td><td>53.5</td><td>81.6</td><td>74.5</td><td>58.4</td><td>84.1</td><td>71.8</td></tr><tr><td>CoWA [21](原文未明确含义，保留英文)</td><td>√</td><td>样本</td><td>56.9</td><td>78.4</td><td>81.0</td><td>69.1</td><td>80.0</td><td>79.9</td><td>67.7</td><td>57.2</td><td>82.4</td><td>72.8</td><td>60.5</td><td>84.5</td><td>72.5</td></tr><tr><td>ProxyMix [5](原文未明确含义，保留英文)</td><td>√</td><td>样本</td><td>59.3</td><td>81.0</td><td>81.6</td><td>65.8</td><td>79.7</td><td>78.1</td><td>67.0</td><td>57.5</td><td>82.7</td><td>73.1</td><td>61.7</td><td>85.6</td><td>72.8</td></tr><tr><td>C - SFDA [16](原文未明确含义，保留英文)</td><td>√</td><td>样本</td><td>60.3</td><td>80.2</td><td>82.9</td><td>69.3</td><td>80.1</td><td>78.8</td><td>67.3</td><td>58.1</td><td>83.4</td><td>73.6</td><td>61.3</td><td>86.3</td><td>73.5</td></tr><tr><td>TPDS [42](原文未明确含义，保留英文)</td><td>√</td><td>样本</td><td>59.3</td><td>80.3</td><td>82.1</td><td>70.6</td><td>79.4</td><td>80.9</td><td>69.8</td><td>56.8</td><td>82.1</td><td>74.5</td><td>61.2</td><td>85.3</td><td>73.5</td></tr><tr><td>CPD [58](原文未明确含义，保留英文)</td><td>√</td><td>样本</td><td>59.1</td><td>79.0</td><td>82.4</td><td>68.5</td><td>79.7</td><td>79.5</td><td>67.9</td><td>57.9</td><td>82.8</td><td>73.8</td><td>61.2</td><td>84.6</td><td>73.0</td></tr><tr><td>CLIP [31](原文未明确含义，保留英文)</td><td>不适用</td><td>否</td><td></td><td>51.6</td><td>81.9</td><td>82.6</td><td>71.9</td><td>81.9</td><td>82.6</td><td>71.9</td><td>51.6</td><td>82.6</td><td>71.9</td><td>51.6</td><td>81.9</td><td>72.0</td></tr><tr><td>DAPL [11](原文未明确含义，保留英文)</td><td>×</td><td>样本</td><td rowspan="5">ResNet - 50(RN - 50)</td><td>54.1</td><td>84.3</td><td>84.8</td><td>74.4</td><td>83.7</td><td>85.0</td><td>74.5</td><td>54.6</td><td>84.8</td><td>75.2</td><td>54.7</td><td>83.8</td><td>74.5</td></tr><tr><td>PADCLIP [19](原文未明确含义，保留英文)</td><td>×</td><td>样本</td><td>57.5</td><td>84.0</td><td>83.8</td><td>77.8</td><td>85.5</td><td>84.7</td><td>76.3</td><td>59.2</td><td>85.4</td><td>78.1</td><td>60.2</td><td>86.7</td><td>76.6</td></tr><tr><td>ADCLIP [35](原文未明确含义，保留英文)</td><td>×</td><td>样本</td><td>55.4</td><td>85.2</td><td>85.6</td><td>76.1</td><td>85.8</td><td>86.2</td><td>76.7</td><td>56.1</td><td>85.4</td><td>76.8</td><td>56.1</td><td>85.5</td><td>75.9</td></tr><tr><td>我们的方法 - 源</td><td>不适用</td><td>8次采样</td><td>52.7</td><td>84.8</td><td>83.6</td><td>70.2</td><td>83.2</td><td>82.6</td><td>69.7</td><td>50.3</td><td>82.8</td><td>71.6</td><td>51.6</td><td>84.3</td><td>72.2</td></tr><tr><td>我们的方法</td><td>√</td><td>8次采样</td><td>59.2</td><td>89.4</td><td>87.1</td><td>77.0</td><td>89.0</td><td>87.0</td><td>76.6</td><td>59.1</td><td>87.3</td><td>76.9</td><td>59.9</td><td>88.9</td><td>78.1</td></tr><tr><td>DSiT - B* [34](原文未明确含义，保留英文)</td><td>√</td><td>样本</td><td rowspan="7">视觉Transformer - B/16(ViT - B/16)</td><td>69.2</td><td>83.5</td><td>87.3</td><td>80.7</td><td>86.1</td><td>86.2</td><td>77.9</td><td>67.9</td><td>86.6</td><td>82.4</td><td>68.3</td><td>89.8</td><td>80.5</td></tr><tr><td>CLIP [31](原文未明确含义，保留英文)</td><td>不适用</td><td>否</td><td>67.8</td><td>89.0</td><td>89.8</td><td>82.9</td><td>89.0</td><td>89.8</td><td>82.9</td><td>67.8</td><td>89.8</td><td>82.9</td><td>67.8</td><td>89.0</td><td>82.4</td></tr><tr><td>DAPL [11](原文未明确含义，保留英文)</td><td>×</td><td>样本</td><td>70.7</td><td>91.0</td><td>90.9</td><td>85.2</td><td>91.0</td><td>91.0</td><td>85.1</td><td>70.7</td><td>90.9</td><td>85.3</td><td>70.4</td><td>91.4</td><td>84.4</td></tr><tr><td>PADCLIP [19](原文未明确含义，保留英文)</td><td>×</td><td>样本</td><td>76.4</td><td>90.6</td><td>90.8</td><td>86.7</td><td>92.3</td><td>92.0</td><td>86.0</td><td>74.5</td><td>91.5</td><td>86.9</td><td>79.1</td><td>93.1</td><td>86.7</td></tr><tr><td>ADCLIP [35](原文未明确含义，保留英文)</td><td>×</td><td>样本</td><td>70.9</td><td>92.5</td><td>92.1</td><td>85.4</td><td>92.4</td><td>92.5</td><td>86.7</td><td>74.3</td><td>93.0</td><td>86.9</td><td>72.6</td><td>93.8</td><td>86.1</td></tr><tr><td>我们的方法 - 源</td><td>不适用</td><td>8次采样</td><td>69.0</td><td>89.6</td><td>90.1</td><td>81.8</td><td>91.1</td><td>89.9</td><td>79.7</td><td>67.8</td><td>88.9</td><td>82.5</td><td>68.6</td><td>90.4</td><td>82.5</td></tr><tr><td>我们的方法</td><td>√</td><td>8次采样</td><td>73.9</td><td>94.1</td><td>91.6</td><td>85.7</td><td>94.3</td><td>91.7</td><td>84.9</td><td>73.7</td><td>91.9</td><td>85.5</td><td>72.7</td><td>94.0</td><td>86.2</td></tr></tbody></table>

TABLE I: Accuracy (%) of Different Settings and Domain Adaptation Methods on the Office-Home Dataset [47]. SF indicates the accessibility of the source domain, Source refers to the number of samples in the source domain, and ${E}_{img}$ denotes the image encoder used. The highest accuracy for each encoder is highlighted in bold, while the second highest is underlined for clarity.

表一:不同设置和领域自适应方法在Office - Home数据集[47]上的准确率(%)。SF表示源领域的可访问性，源指源领域中的样本数量，${E}_{img}$表示使用的图像编码器。每个编码器的最高准确率以粗体突出显示，为清晰起见，第二高的准确率加下划线显示。

<table><tr><td>Method</td><td>SF</td><td>Source</td><td>${E}_{img}$</td><td>$\mathrm{{Cl}} \rightarrow  \mathrm{{Pn}}$</td><td>$\mathrm{{Cl}} \rightarrow  \mathrm{{Rl}}$</td><td>$\mathrm{{Cl}} \rightarrow  \mathrm{{Sk}}$</td><td>$\mathrm{{Pn}} \rightarrow  \mathrm{{Cl}}$</td><td>$\mathrm{{Pn}} \rightarrow  \mathrm{{Rl}}$</td><td>Pn $\rightarrow$ Sk</td><td>$\mathrm{{Rl}} \rightarrow  \mathrm{{Cl}}$</td><td>$\mathrm{{Rl}} \rightarrow  \mathrm{{Pn}}$</td><td>$\mathrm{R}1 \rightarrow  \mathrm{{Sk}}$</td><td>$\mathrm{{Sk}} \rightarrow  \mathrm{{Cl}}$</td><td>$\mathrm{{Sk}} \rightarrow  \mathrm{{Pn}}$</td><td>$\mathrm{{Sk}} \rightarrow  \mathrm{{Rl}}$</td><td>Avg</td></tr><tr><td>CLIP [31]</td><td>N/A</td><td>no</td><td rowspan="5">RN-50</td><td>67.9</td><td>84.8</td><td>62.9</td><td>69.1</td><td>84.8</td><td>62.9</td><td>69.2</td><td>67.9</td><td>62.9</td><td>69.1</td><td>67.9</td><td>84.8</td><td>71.2</td></tr><tr><td>DAPL [11]</td><td>✘</td><td>ample</td><td>72.4</td><td>87.6</td><td>65.9</td><td>72.7</td><td>87.6</td><td>65.6</td><td>73.2</td><td>72.4</td><td>66.2</td><td>73.8</td><td>72.9</td><td>87.8</td><td>74.8</td></tr><tr><td>ADCLIP [35]</td><td>✘</td><td>ample</td><td>71.7</td><td>88.1</td><td>66.0</td><td>73.2</td><td>86.9</td><td>65.2</td><td>73.6</td><td>73.0</td><td>68.4</td><td>72.3</td><td>74.2</td><td>89.3</td><td>75.2</td></tr><tr><td>Ours-Source</td><td>N/A</td><td>8-shots</td><td>71.0</td><td>87.3</td><td>63.7</td><td>70.8</td><td>86.0</td><td>61.1</td><td>68.6</td><td>68.1</td><td>60.5</td><td>71.1</td><td>70.3</td><td>85.7</td><td>72.0</td></tr><tr><td>Ours</td><td>✓</td><td>8-shots</td><td>75.4</td><td>89.2</td><td>67.3</td><td>77.5</td><td>89.5</td><td>67.9</td><td>76.8</td><td>68.1</td><td>77.0</td><td>74.9</td><td>74.8</td><td>89.4</td><td>77.3</td></tr><tr><td>CLIP [31]</td><td>N/A</td><td>no</td><td rowspan="5">ViT-B/16</td><td>80.3</td><td>90.5</td><td>77.8</td><td>82.7</td><td>90.5</td><td>77.8</td><td>82.7</td><td>80.3</td><td>77.8</td><td>82.7</td><td>80.3</td><td>90.5</td><td>82.8</td></tr><tr><td>DAPL [11]</td><td>✘</td><td>ample</td><td>83.3</td><td>92.4</td><td>81.1</td><td>86.4</td><td>92.1</td><td>81.0</td><td>86.7</td><td>83.3</td><td>80.8</td><td>86.8</td><td>83.5</td><td>91.9</td><td>85.8</td></tr><tr><td>ADCLIP [35]</td><td>✘</td><td>ample</td><td>84.3</td><td>93.7</td><td>82.4</td><td>87.5</td><td>93.5</td><td>82.4</td><td>87.3</td><td>84.5</td><td>81.6</td><td>87.9</td><td>84.8</td><td>93.0</td><td>86.9</td></tr><tr><td>Ours-Source</td><td>N/A</td><td>8-shots</td><td>81.0</td><td>90.6</td><td>79.2</td><td>85.9</td><td>90.3</td><td>78.1</td><td>84.3</td><td>78.1</td><td>77.6</td><td>84.8</td><td>80.8</td><td>90.5</td><td>83.4</td></tr><tr><td>Ours</td><td>✓</td><td>8-shots</td><td>84.8</td><td>92.4</td><td>81.9</td><td>87.6</td><td>93.0</td><td>82.1</td><td>87.5</td><td>84.9</td><td>81.6</td><td>87.9</td><td>84.8</td><td>91.9</td><td>86.7</td></tr></table>

<table><tbody><tr><td>方法</td><td>科幻(Science Fiction)</td><td>来源</td><td>${E}_{img}$</td><td>$\mathrm{{Cl}} \rightarrow  \mathrm{{Pn}}$</td><td>$\mathrm{{Cl}} \rightarrow  \mathrm{{Rl}}$</td><td>$\mathrm{{Cl}} \rightarrow  \mathrm{{Sk}}$</td><td>$\mathrm{{Pn}} \rightarrow  \mathrm{{Cl}}$</td><td>$\mathrm{{Pn}} \rightarrow  \mathrm{{Rl}}$</td><td>概率(Pn) $\rightarrow$ 标准差(Sk)</td><td>$\mathrm{{Rl}} \rightarrow  \mathrm{{Cl}}$</td><td>$\mathrm{{Rl}} \rightarrow  \mathrm{{Pn}}$</td><td>$\mathrm{R}1 \rightarrow  \mathrm{{Sk}}$</td><td>$\mathrm{{Sk}} \rightarrow  \mathrm{{Cl}}$</td><td>$\mathrm{{Sk}} \rightarrow  \mathrm{{Pn}}$</td><td>$\mathrm{{Sk}} \rightarrow  \mathrm{{Rl}}$</td><td>平均值</td></tr><tr><td>对比语言-图像预训练模型(CLIP) [31]</td><td>不适用</td><td>否</td><td rowspan="5">残差网络-50(RN-50)</td><td>67.9</td><td>84.8</td><td>62.9</td><td>69.1</td><td>84.8</td><td>62.9</td><td>69.2</td><td>67.9</td><td>62.9</td><td>69.1</td><td>67.9</td><td>84.8</td><td>71.2</td></tr><tr><td>深度自适应原型学习(DAPL) [11]</td><td>✘</td><td>充足的</td><td>72.4</td><td>87.6</td><td>65.9</td><td>72.7</td><td>87.6</td><td>65.6</td><td>73.2</td><td>72.4</td><td>66.2</td><td>73.8</td><td>72.9</td><td>87.8</td><td>74.8</td></tr><tr><td>自适应对比语言-图像预训练模型(ADCLIP) [35]</td><td>✘</td><td>充足的</td><td>71.7</td><td>88.1</td><td>66.0</td><td>73.2</td><td>86.9</td><td>65.2</td><td>73.6</td><td>73.0</td><td>68.4</td><td>72.3</td><td>74.2</td><td>89.3</td><td>75.2</td></tr><tr><td>我们的方法-源域</td><td>不适用</td><td>8次采样</td><td>71.0</td><td>87.3</td><td>63.7</td><td>70.8</td><td>86.0</td><td>61.1</td><td>68.6</td><td>68.1</td><td>60.5</td><td>71.1</td><td>70.3</td><td>85.7</td><td>72.0</td></tr><tr><td>我们的方法</td><td>✓</td><td>8次采样</td><td>75.4</td><td>89.2</td><td>67.3</td><td>77.5</td><td>89.5</td><td>67.9</td><td>76.8</td><td>68.1</td><td>77.0</td><td>74.9</td><td>74.8</td><td>89.4</td><td>77.3</td></tr><tr><td>对比语言-图像预训练模型(CLIP) [31]</td><td>不适用</td><td>否</td><td rowspan="5">视觉Transformer-B/16(ViT-B/16)</td><td>80.3</td><td>90.5</td><td>77.8</td><td>82.7</td><td>90.5</td><td>77.8</td><td>82.7</td><td>80.3</td><td>77.8</td><td>82.7</td><td>80.3</td><td>90.5</td><td>82.8</td></tr><tr><td>深度自适应原型学习(DAPL) [11]</td><td>✘</td><td>充足的</td><td>83.3</td><td>92.4</td><td>81.1</td><td>86.4</td><td>92.1</td><td>81.0</td><td>86.7</td><td>83.3</td><td>80.8</td><td>86.8</td><td>83.5</td><td>91.9</td><td>85.8</td></tr><tr><td>自适应对比语言-图像预训练模型(ADCLIP) [35]</td><td>✘</td><td>充足的</td><td>84.3</td><td>93.7</td><td>82.4</td><td>87.5</td><td>93.5</td><td>82.4</td><td>87.3</td><td>84.5</td><td>81.6</td><td>87.9</td><td>84.8</td><td>93.0</td><td>86.9</td></tr><tr><td>我们的方法-源域</td><td>不适用</td><td>8次采样</td><td>81.0</td><td>90.6</td><td>79.2</td><td>85.9</td><td>90.3</td><td>78.1</td><td>84.3</td><td>78.1</td><td>77.6</td><td>84.8</td><td>80.8</td><td>90.5</td><td>83.4</td></tr><tr><td>我们的方法</td><td>✓</td><td>8次采样</td><td>84.8</td><td>92.4</td><td>81.9</td><td>87.6</td><td>93.0</td><td>82.1</td><td>87.5</td><td>84.9</td><td>81.6</td><td>87.9</td><td>84.8</td><td>91.9</td><td>86.7</td></tr></tbody></table>

TABLE II: Accuracy (%) of Different Settings and Domain Adaptation Methods on the Mini-DomainNet[29] dataset.

表二:不同设置和领域自适应方法在Mini - DomainNet[29]数据集上的准确率(%)。

## B. Comparison with the other methods

## 二、与其他方法的比较

1) Competitors: In this study, we explore a relatively under-investigated area: Source-Free Unsupervised Domain Adaptation (SF-UDA) under conditions of extremely limited source domain samples. Given the uniqueness of this novel setting, we find it challenging to identify existing studies with a completely analogous setup for comparison. Therefore, to validate the effectiveness of our method, we chose to compare it against SF-UDA methods that train with a large number of source domain samples and UDA methods that have direct access to substantial source domain samples. This comparison not only demonstrates the adaptability of our approach under the dual challenges of no direct access to source domain data and limited source sample availability but also highlights its innovation and practicality. By doing so, we aim to illustrate that even with minimal source data, our approach can still perform comparably to methods that benefit from richer source environments, highlighting its potential for scenarios where traditional UDA assumptions do not hold.

1) 对比方法:在本研究中，我们探索了一个相对研究较少的领域:在源领域样本极其有限的条件下的无源无监督领域自适应(Source - Free Unsupervised Domain Adaptation，SF - UDA)。鉴于这种新设置的独特性，我们发现很难找到具有完全类似设置的现有研究进行比较。因此，为了验证我们方法的有效性，我们选择将其与使用大量源领域样本进行训练的SF - UDA方法以及可以直接访问大量源领域样本的UDA方法进行比较。这种比较不仅展示了我们的方法在无法直接访问源领域数据和源样本有限这双重挑战下的适应性，还凸显了其创新性和实用性。通过这样做，我们旨在说明，即使源数据极少，我们的方法仍然可以与受益于更丰富源环境的方法表现相当，凸显了其在传统UDA假设不成立的场景中的潜力。

Our experimental design includes three groups of comparative methods:

我们的实验设计包括三组对比方法:

- Source only, CLIP zero-shot, and Ours-Source model, which rely solely on the source domain model or zero-shot inference;

- 仅使用源领域模型、CLIP零样本学习和我们的源模型，这些方法仅依赖于源领域模型或零样本推理；

- Twelve SF-UDA methods, which, although unable to directly access source domain data, can still utilize a relatively rich number of source domain samples.

- 十二种SF - UDA方法，这些方法虽然无法直接访问源领域数据，但仍可以利用相对丰富的源领域样本。

- Three UDA methods based on CLIP, where these approaches have direct access to the source domain data, and the source domain contains sufficient samples;

- 三种基于CLIP的UDA方法，这些方法可以直接访问源领域数据，并且源领域包含足够的样本；

2) Experimental Results: First, as shown in Table I and Table II, our method achieved the best performance on the standard unsupervised domain adaptation datasets Office-Home and Mini-DomainNet, with 78.1% and 77.3% respectively, using ResNet-50 as the backbone network. These results outperform previous source-free unsupervised domain adaptation (SF-UDA) methods as well as standard UDA approaches, clearly demonstrating that our method can achieve top performance in the target domain even under strict source data access constraints, showcasing its efficiency and robustness. Additionally, while our method did not surpass all approaches when using ViT-B/16 as the backbone, it achieved results nearly identical to the best-performing UDA method, PAD-CLIP, further validating its competitiveness.

2) 实验结果:首先，如表一和表二所示，以ResNet - 50为骨干网络时，我们的方法在标准无监督领域自适应数据集Office - Home和Mini - DomainNet上分别取得了78.1%和77.3%的最佳性能。这些结果优于以往的无源无监督领域自适应(SF - UDA)方法以及标准UDA方法，清楚地表明我们的方法即使在严格的源数据访问限制下，也能在目标领域取得顶尖性能，展示了其高效性和鲁棒性。此外，当以ViT - B/16为骨干网络时，我们的方法虽然没有超越所有方法，但取得了与表现最佳的UDA方法PAD - CLIP几乎相同的结果，进一步验证了其竞争力。

<table><tr><td>Method</td><td>SF</td><td>Source</td><td>${E}_{img}$</td><td>$\mathrm{A} \rightarrow  \mathrm{D}$</td><td>$\mathrm{A} \rightarrow  \mathrm{W}$</td><td>$\mathrm{D} \rightarrow  \mathrm{A}$</td><td>$\mathrm{D} \rightarrow  \mathrm{W}$</td><td>$\mathrm{W} \rightarrow  \mathrm{A}$</td><td>$\mathrm{W} \rightarrow  \mathrm{D}$</td><td>Avg.</td></tr><tr><td>RN-50 [13]</td><td>N/A</td><td>ample</td><td rowspan="15">RN-50</td><td>68.9</td><td>68.4</td><td>62.5</td><td>96.7</td><td>60.7</td><td>99.3</td><td>76.1</td></tr><tr><td>SHOT [24]</td><td>✓</td><td>ample</td><td>94.0</td><td>90.1</td><td>74.7</td><td>98.4</td><td>74.3</td><td>99.9</td><td>88.6</td></tr><tr><td>GKD [40]</td><td>✓</td><td>ample</td><td>94.6</td><td>91.6</td><td>75.1</td><td>98.7</td><td>75.1</td><td>100.0</td><td>89.2</td></tr><tr><td>D-MCD [3]</td><td>✓</td><td>ample</td><td>94.1</td><td>93.5</td><td>76.4</td><td>98.8</td><td>76.4</td><td>100.0</td><td>89.9</td></tr><tr><td>${\mathrm{A}}^{2}$ Net [51]</td><td>✓</td><td>ample</td><td>94.5</td><td>94.0</td><td>76.7</td><td>99.2</td><td>76.1</td><td>100.0</td><td>90.0</td></tr><tr><td>SCLM [41]</td><td>✓</td><td>ample</td><td>95.8</td><td>90.0</td><td>75.5</td><td>98.9</td><td>75.5</td><td>99.8</td><td>89.4</td></tr><tr><td>AAA [22]</td><td>✓</td><td>ample</td><td>95.6</td><td>94.2</td><td>75.6</td><td>98.1</td><td>76.0</td><td>99.8</td><td>89.9</td></tr><tr><td>CoWA [21]</td><td>✓</td><td>ample</td><td>94.4</td><td>95.2</td><td>76.2</td><td>98.5</td><td>77.6</td><td>99.8</td><td>90.3</td></tr><tr><td>ProxyMix [5]</td><td>✓</td><td>ample</td><td>95.4</td><td>96.6</td><td>75.1</td><td>98.5</td><td>75.4</td><td>99.8</td><td>85.6</td></tr><tr><td>C-SFDA [16]</td><td>✓</td><td>ample</td><td>96.2</td><td>93.9</td><td>77.3</td><td>98.8</td><td>77.9</td><td>99.7</td><td>90.5</td></tr><tr><td>TPDS [42]</td><td>✓</td><td>ample</td><td>97.1</td><td>94.5</td><td>75.7</td><td>98.7</td><td>75.5</td><td>99.8</td><td>90.2</td></tr><tr><td>CPD [58]</td><td>✓</td><td>ample</td><td>96.6</td><td>94.2</td><td>77.3</td><td>98.2</td><td>78.3</td><td>100.0</td><td>90.8</td></tr><tr><td>CLIP [31]</td><td>N/A</td><td>no</td><td>74.3</td><td>67.8</td><td>72.6</td><td>67.8</td><td>72.6</td><td>74.3</td><td>71.6</td></tr><tr><td>Ours-Source</td><td>N/A</td><td>8-shots</td><td>78.9</td><td>70.7</td><td>74.2</td><td>83.0</td><td>72.1</td><td>82.3</td><td>76.9</td></tr><tr><td>Ours</td><td>✓</td><td>8-shots</td><td>90.0</td><td>88.6</td><td>80.3</td><td>91.1</td><td>79.6</td><td>92.4</td><td>87.0</td></tr><tr><td>DSiT-B* [34]</td><td>✓</td><td>ample</td><td rowspan="4">VTT-B/16</td><td>98.0</td><td>97.2</td><td>81.7</td><td>99.1</td><td>81.8</td><td>100.0</td><td>93.0</td></tr><tr><td>CLIP [31]</td><td>N/A</td><td>no</td><td>79.9</td><td>76.9</td><td>78.9</td><td>76.9</td><td>78.9</td><td>79.9</td><td>78.6</td></tr><tr><td>Ours-Source</td><td>N/A</td><td>8-shots</td><td>83.3</td><td>81.5</td><td>79.7</td><td>90.1</td><td>78.7</td><td>91.6</td><td>84.2</td></tr><tr><td>Ours</td><td>✓</td><td>8-shots</td><td>94.8</td><td>95.8</td><td>85.1</td><td>95.8</td><td>85.6</td><td>96.6</td><td>92.3</td></tr></table>

<table><tbody><tr><td>方法</td><td>SF(原文未明确含义，保留英文)</td><td>源</td><td>${E}_{img}$</td><td>$\mathrm{A} \rightarrow  \mathrm{D}$</td><td>$\mathrm{A} \rightarrow  \mathrm{W}$</td><td>$\mathrm{D} \rightarrow  \mathrm{A}$</td><td>$\mathrm{D} \rightarrow  \mathrm{W}$</td><td>$\mathrm{W} \rightarrow  \mathrm{A}$</td><td>$\mathrm{W} \rightarrow  \mathrm{D}$</td><td>平均值</td></tr><tr><td>RN - 50 [13](残差网络50层 [13])</td><td>不适用</td><td>样本</td><td rowspan="15">RN - 50(残差网络50层)</td><td>68.9</td><td>68.4</td><td>62.5</td><td>96.7</td><td>60.7</td><td>99.3</td><td>76.1</td></tr><tr><td>SHOT [24](原文未明确含义，保留英文 [24])</td><td>✓</td><td>样本</td><td>94.0</td><td>90.1</td><td>74.7</td><td>98.4</td><td>74.3</td><td>99.9</td><td>88.6</td></tr><tr><td>GKD [40](原文未明确含义，保留英文 [40])</td><td>✓</td><td>样本</td><td>94.6</td><td>91.6</td><td>75.1</td><td>98.7</td><td>75.1</td><td>100.0</td><td>89.2</td></tr><tr><td>D - MCD [3](原文未明确含义，保留英文 [3])</td><td>✓</td><td>样本</td><td>94.1</td><td>93.5</td><td>76.4</td><td>98.8</td><td>76.4</td><td>100.0</td><td>89.9</td></tr><tr><td>${\mathrm{A}}^{2}$ 网络 [51]</td><td>✓</td><td>样本</td><td>94.5</td><td>94.0</td><td>76.7</td><td>99.2</td><td>76.1</td><td>100.0</td><td>90.0</td></tr><tr><td>SCLM [41](原文未明确含义，保留英文 [41])</td><td>✓</td><td>样本</td><td>95.8</td><td>90.0</td><td>75.5</td><td>98.9</td><td>75.5</td><td>99.8</td><td>89.4</td></tr><tr><td>AAA [22](原文未明确含义，保留英文 [22])</td><td>✓</td><td>样本</td><td>95.6</td><td>94.2</td><td>75.6</td><td>98.1</td><td>76.0</td><td>99.8</td><td>89.9</td></tr><tr><td>CoWA [21](原文未明确含义，保留英文 [21])</td><td>✓</td><td>样本</td><td>94.4</td><td>95.2</td><td>76.2</td><td>98.5</td><td>77.6</td><td>99.8</td><td>90.3</td></tr><tr><td>ProxyMix [5](代理混合 [5])</td><td>✓</td><td>样本</td><td>95.4</td><td>96.6</td><td>75.1</td><td>98.5</td><td>75.4</td><td>99.8</td><td>85.6</td></tr><tr><td>C - SFDA [16](原文未明确含义，保留英文 [16])</td><td>✓</td><td>样本</td><td>96.2</td><td>93.9</td><td>77.3</td><td>98.8</td><td>77.9</td><td>99.7</td><td>90.5</td></tr><tr><td>TPDS [42](原文未明确含义，保留英文 [42])</td><td>✓</td><td>样本</td><td>97.1</td><td>94.5</td><td>75.7</td><td>98.7</td><td>75.5</td><td>99.8</td><td>90.2</td></tr><tr><td>CPD [58](原文未明确含义，保留英文 [58])</td><td>✓</td><td>样本</td><td>96.6</td><td>94.2</td><td>77.3</td><td>98.2</td><td>78.3</td><td>100.0</td><td>90.8</td></tr><tr><td>CLIP [31](对比语言 - 图像预训练 [31])</td><td>不适用</td><td>否</td><td>74.3</td><td>67.8</td><td>72.6</td><td>67.8</td><td>72.6</td><td>74.3</td><td>71.6</td></tr><tr><td>我们的方法 - 源</td><td>不适用</td><td>8次采样</td><td>78.9</td><td>70.7</td><td>74.2</td><td>83.0</td><td>72.1</td><td>82.3</td><td>76.9</td></tr><tr><td>我们的方法</td><td>✓</td><td>8次采样</td><td>90.0</td><td>88.6</td><td>80.3</td><td>91.1</td><td>79.6</td><td>92.4</td><td>87.0</td></tr><tr><td>DSiT - B* [34](原文未明确含义，保留英文 [34])</td><td>✓</td><td>样本</td><td rowspan="4">VTT - B/16(视觉变换器文本 - B/16)</td><td>98.0</td><td>97.2</td><td>81.7</td><td>99.1</td><td>81.8</td><td>100.0</td><td>93.0</td></tr><tr><td>CLIP [31](对比语言 - 图像预训练 [31])</td><td>不适用</td><td>否</td><td>79.9</td><td>76.9</td><td>78.9</td><td>76.9</td><td>78.9</td><td>79.9</td><td>78.6</td></tr><tr><td>我们的方法 - 源</td><td>不适用</td><td>8次采样</td><td>83.3</td><td>81.5</td><td>79.7</td><td>90.1</td><td>78.7</td><td>91.6</td><td>84.2</td></tr><tr><td>我们的方法</td><td>✓</td><td>8次采样</td><td>94.8</td><td>95.8</td><td>85.1</td><td>95.8</td><td>85.6</td><td>96.6</td><td>92.3</td></tr></tbody></table>

TABLE III: Accuracy (%) of Different Settings and Domain Adaptation Methods on the Office-31[32] Dataset.

表三:不同设置和领域自适应方法在Office - 31[32]数据集上的准确率(%)。

Second, as shown in Table III, on the Office-31 dataset, our method, using ViT-B/16 as the image encoder, achieved performance comparable to SF-UDA methods based on large source samples, only 0.7% lower than DSiT-B. Although ResNet-50 showed relatively weaker pretraining performance, our method still demonstrated its effectiveness under limited source sample conditions, proving its adaptability on datasets with smaller domain gaps.

其次，如表三所示，在Office - 31数据集上，我们的方法使用ViT - B/16作为图像编码器，取得了与基于大量源样本的SF - UDA方法相当的性能，仅比DSiT - B低0.7%。尽管ResNet - 50的预训练性能相对较弱，但我们的方法在源样本有限的条件下仍显示出有效性，证明了其在领域差距较小的数据集上的适应性。

Finally, as shown in Table IV and Table V, when using ViT-B/16 as the backbone network, our method surpassed previous SF-UDA methods on the VisDA-2017 dataset, trailing the best UDA method, PAD-CLIP, by only 1.0%. Additionally, it achieved performance comparable to DATSNET, a UDA method specifically designed for remote sensing images, in domain adaptation tasks involving remote sensing imagery. These results not only confirm the effectiveness of our method but also highlight its significant performance advantage in professional applications with limited source samples, particularly by outperforming AD-CLIP by 3.3%, demonstrating strong competitiveness.

最后，如表四和表五所示，当使用ViT - B/16作为骨干网络时，我们的方法在VisDA - 2017数据集上超越了以往的SF - UDA方法，仅比最佳的UDA方法PAD - CLIP低1.0%。此外，在涉及遥感图像的领域自适应任务中，它取得了与专门为遥感图像设计的UDA方法DATSNET相当的性能。这些结果不仅证实了我们方法的有效性，还凸显了其在源样本有限的专业应用中的显著性能优势，特别是比AD - CLIP高出3.3%，显示出强大的竞争力。

These experimental results collectively validate that our proposed method can maintain strong performance across various tasks and settings, even under stringent conditions with limited source data, showcasing its robustness and generalizability.

这些实验结果共同验证了我们提出的方法即使在源数据有限的严格条件下，也能在各种任务和设置中保持强大的性能，展示了其鲁棒性和泛化能力。

## C. Ablations Studies

## C. 消融研究

The Effectiveness of Different Components in the Model Architecture. In Table VI, we analyze the effectiveness of different components in the model using the Office-Home dataset, comparing the average accuracy of four distinct model configurations across the four domains. Initially, when trained solely on source domain samples, the model achieves an accuracy of ${82.5}\%$ . This indicates that prompt learning from a limited number of source domain samples retains substantial generalization information relevant to the target domain. When the model undergoes unsupervised training using only soft prompts learned from the target domain, accuracy improves to ${84.3}\%$ , confirming the effectiveness of our proposed unsupervised optimization strategy in maintaining high performance even with exclusive target domain training. Furthermore, incorporating a fusion module to integrate semantic category information from the source domain into the target domain training raises model performance to 85.7%, demonstrating that category semantic information learned from a small number of source domain samples effectively supports training in the target domain. Finally, setting the feature matrix of high-confidence target domain samples, ${W}_{e}$ , as a learnable parameter further enhances model performance to 86.2%. These results collectively highlight the contributions of each component to enhancing the model's generalization ability.

模型架构中不同组件的有效性。在表六中，我们使用Office - Home数据集分析了模型中不同组件的有效性，比较了四种不同模型配置在四个领域的平均准确率。最初，当仅在源域样本上进行训练时，模型的准确率达到 ${82.5}\%$ 。这表明从有限数量的源域样本中进行提示学习保留了与目标域相关的大量泛化信息。当模型仅使用从目标域学习到的软提示进行无监督训练时，准确率提高到 ${84.3}\%$ ，证实了我们提出的无监督优化策略即使在仅使用目标域训练时也能保持高性能的有效性。此外，引入融合模块将源域的语义类别信息整合到目标域训练中，使模型性能提高到85.7%，表明从少量源域样本中学习到的类别语义信息有效地支持了目标域的训练。最后，将高置信度目标域样本的特征矩阵 ${W}_{e}$ 设置为可学习参数，进一步将模型性能提高到86.2%。这些结果共同凸显了每个组件对提高模型泛化能力的贡献。

![0195dcf6-b307-7b10-9224-24b77c210989_8_953_161_661_496_0.jpg](images/0195dcf6-b307-7b10-9224-24b77c210989_8_953_161_661_496_0.jpg)

Fig. 3: Trends in category average accuracy for two different branches during the Product $\rightarrow$ Real World transfer task across training epochs.

图3:在产品 $\rightarrow$ 真实世界迁移任务中，两个不同分支的类别平均准确率在训练轮次中的变化趋势。

The Effectiveness of Different Loss Terms in Unsupervised Optimization Strategies. In Table VII, we analyze the effectiveness of the three loss components in our proposed unsupervised optimization strategy across the Office-Home, VisDA-2017, and Mini-DomainNet datasets. By comparing the impact of different combinations of loss components on the accuracy of these datasets, we observe that the cross-entropy loss for high-confidence samples, ${\mathcal{L}}_{CE}^{T}$ , and the mutual information maximization loss, ${\mathcal{L}}_{IM}$ , significantly enhance the model’s performance. This effect may stem from the fact that both ${\mathcal{L}}_{CE}^{T}$ and ${\mathcal{L}}_{IM}$ promote individual certainty in model predictions and global diversity. However, since ${\mathcal{L}}_{IM}$ computes the loss over all samples, while ${\mathcal{L}}_{CE}^{T}$ only considers a small number of highly reliable samples, the effect of ${\mathcal{L}}_{IM}$ is relatively more pronounced. Furthermore, the multi-view consistency loss, ${\mathcal{L}}_{\text{consistency }}$ , improves model performance regardless of its combination with other losses; when all three loss components are used together, the model achieves optimal performance, indicating that each component contributes effectively.

无监督优化策略中不同损失项的有效性。在表七中，我们分析了我们提出的无监督优化策略中的三个损失组件在Office - Home、VisDA - 2017和Mini - DomainNet数据集上的有效性。通过比较不同损失组件组合对这些数据集准确率的影响，我们观察到高置信度样本的交叉熵损失 ${\mathcal{L}}_{CE}^{T}$ 和互信息最大化损失 ${\mathcal{L}}_{IM}$ 显著提高了模型的性能。这种效果可能源于 ${\mathcal{L}}_{CE}^{T}$ 和 ${\mathcal{L}}_{IM}$ 都促进了模型预测的个体确定性和全局多样性。然而，由于 ${\mathcal{L}}_{IM}$ 对所有样本计算损失，而 ${\mathcal{L}}_{CE}^{T}$ 仅考虑少量高度可靠的样本，因此 ${\mathcal{L}}_{IM}$ 的效果相对更明显。此外，多视图一致性损失 ${\mathcal{L}}_{\text{consistency }}$ 无论与其他损失如何组合都能提高模型性能；当三个损失组件一起使用时，模型达到最佳性能，表明每个组件都做出了有效贡献。

<table><tr><td>Method</td><td>SF</td><td>Source</td><td>${E}_{img}$</td><td>plane</td><td>bcycl</td><td>bus</td><td>car</td><td>horse</td><td>knife</td><td>moycle</td><td>person</td><td>plant</td><td>sktbrd</td><td>train</td><td>truck</td><td>Avg.</td></tr><tr><td>RN-101 [13]</td><td>N/A</td><td>ample</td><td rowspan="13">RN-101</td><td>55.1</td><td>53.3</td><td>61.9</td><td>59.1</td><td>80.6</td><td>17.9</td><td>79.7</td><td>31.2</td><td>81.0</td><td>26.5</td><td>73.5</td><td>8.5</td><td>52.4</td></tr><tr><td>SHOT [24]</td><td>✓</td><td>ample</td><td>94.3</td><td>88.5</td><td>80.1</td><td>57.3</td><td>93.1</td><td>94.9</td><td>80.7</td><td>80.3</td><td>91.5</td><td>89.1</td><td>86.3</td><td>58.2</td><td>82.9</td></tr><tr><td>GKD [40]</td><td>✓</td><td>ample</td><td>95.3</td><td>87.6</td><td>81.7</td><td>58.1</td><td>93.9</td><td>94.0</td><td>80.0</td><td>80.0</td><td>91.2</td><td>91.0</td><td>86.9</td><td>56.1</td><td>83.0</td></tr><tr><td>PS [7]</td><td>✓</td><td>ample</td><td>95.2</td><td>86.2</td><td>82.1</td><td>61.5</td><td>93.2</td><td>95.6</td><td>86.7</td><td>80.4</td><td>91.5</td><td>90.8</td><td>85.8</td><td>59.3</td><td>84.0</td></tr><tr><td>D-MCD [3]</td><td>✓</td><td>ample</td><td>97.0</td><td>88.0</td><td>90.0</td><td>81.5</td><td>95.6</td><td>98.0</td><td>86.2</td><td>88.7</td><td>94.6</td><td>92.7</td><td>83.7</td><td>53.1</td><td>87.5</td></tr><tr><td>${\mathrm{A}}^{2}$ Net [51]</td><td>✓</td><td>ample</td><td>94.0</td><td>87.8</td><td>85.6</td><td>66.8</td><td>93.7</td><td>95.1</td><td>85.8</td><td>81.2</td><td>91.6</td><td>88.2</td><td>86.5</td><td>56.0</td><td>84.3</td></tr><tr><td>SCLM [41]</td><td>✓</td><td>ample</td><td>97.1</td><td>90.7</td><td>85.6</td><td>62.0</td><td>97.3</td><td>94.6</td><td>81.8</td><td>84.3</td><td>93.6</td><td>92.8</td><td>88.0</td><td>55.9</td><td>85.3</td></tr><tr><td>AAA [22]</td><td>✓</td><td>ample</td><td>94.4</td><td>85.9</td><td>74.9</td><td>60.2</td><td>96.0</td><td>93.5</td><td>87.8</td><td>80.8</td><td>90.2</td><td>92.0</td><td>86.6</td><td>68.3</td><td>84.2</td></tr><tr><td>CoWA [21]</td><td>✓</td><td>ample</td><td>96.2</td><td>89.7</td><td>83.9</td><td>73.8</td><td>96.4</td><td>97.4</td><td>89.3</td><td>86.8</td><td>94.6</td><td>92.1</td><td>88.7</td><td>53.8</td><td>86.9</td></tr><tr><td>ProxyMix [5]</td><td>✓</td><td>ample</td><td>95.4</td><td>81.7</td><td>87.2</td><td>79.9</td><td>95.6</td><td>96.8</td><td>92.1</td><td>85.1</td><td>93.4</td><td>90.3</td><td>89.1</td><td>42.2</td><td>85.7</td></tr><tr><td>C-SFDA [16]</td><td>✓</td><td>ample</td><td>97.6</td><td>88.8</td><td>86.1</td><td>72.2</td><td>97.2</td><td>94.4</td><td>92.1</td><td>84.7</td><td>93.0</td><td>90.7</td><td>93.1</td><td>63.5</td><td>87.8</td></tr><tr><td>TPDS [42]</td><td>✓</td><td>ample</td><td>97.6</td><td>91.5</td><td>89.7</td><td>83.4</td><td>97.5</td><td>96.3</td><td>92.2</td><td>82.4</td><td>96.0</td><td>94.1</td><td>90.9</td><td>40.4</td><td>87.6</td></tr><tr><td>CPD [58]</td><td>✓</td><td>ample</td><td>96.7</td><td>88.5</td><td>79.6</td><td>69.0</td><td>95.9</td><td>96.3</td><td>87.3</td><td>83.3</td><td>94.4</td><td>92.9</td><td>87.0</td><td>58.7</td><td>85.8</td></tr><tr><td>CLIP [31]</td><td>N/A</td><td>no</td><td/><td>98.2</td><td>83.9</td><td>90.5</td><td>73.5</td><td>97.2</td><td>84.0</td><td>95.3</td><td>65.7</td><td>79.4</td><td>89.9</td><td>91.8</td><td>63.3</td><td>84.4</td></tr><tr><td>DAPL [11]</td><td>✘</td><td>ample</td><td rowspan="5"/><td>97.8</td><td>83.1</td><td>88.8</td><td>77.9</td><td>97.4</td><td>91.5</td><td>94.2</td><td>79.7</td><td>88.6</td><td>89.3</td><td>92.5</td><td>62.0</td><td>86.9</td></tr><tr><td>ADCLIP [35]</td><td>✘</td><td>ample</td><td>98.1</td><td>83.6</td><td>91.2</td><td>76.6</td><td>98.1</td><td>93.4</td><td>96.0</td><td>81.4</td><td>86.4</td><td>91.5</td><td>92.1</td><td>64.2</td><td>87.7</td></tr><tr><td>PADCLIP [19]</td><td>✘</td><td>ample</td><td>96.7</td><td>88.8</td><td>87.0</td><td>82.8</td><td>97.1</td><td>93.0</td><td>91.3</td><td>83.0</td><td>95.5</td><td>91.8</td><td>91.5</td><td>63.0</td><td>88.5</td></tr><tr><td>Ours-Source</td><td>N/A</td><td>8-shots</td><td>96.2</td><td>76.3</td><td>95.4</td><td>66.5</td><td>97.1</td><td>62.6</td><td>95.6</td><td>9.3</td><td>92.4</td><td>93.3</td><td>91.5</td><td>43.0</td><td>76.6</td></tr><tr><td>Ours</td><td>✓</td><td>8-shots</td><td>97.3</td><td>90.8</td><td>83.5</td><td>67.9</td><td>96.8</td><td>95.0</td><td>90.4</td><td>78.5</td><td>89.3</td><td>91.4</td><td>92.8</td><td>72.5</td><td>87.2</td></tr><tr><td>DSiT-B* [34]</td><td>✓</td><td>ample</td><td rowspan="7">ViT-B/16</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>87.6</td></tr><tr><td>CLIP [31]</td><td>N/A</td><td>no</td><td>99.1</td><td>91.7</td><td>93.8</td><td>76.7</td><td>98.4</td><td>91.7</td><td>95.3</td><td>82.7</td><td>86.5</td><td>96.0</td><td>94.6</td><td>60.5</td><td>88.9</td></tr><tr><td>DAPL [11]</td><td>✘</td><td>ample</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>89.8</td></tr><tr><td>ADCLIP [35]</td><td>✘</td><td>ample</td><td>99.6</td><td>92.8</td><td>94.0</td><td>78.6</td><td>98.8</td><td>95.4</td><td>96.8</td><td>83.9</td><td>91.5</td><td>95.8</td><td>95.5</td><td>65.7</td><td>90.7</td></tr><tr><td>PADCLIP [19]</td><td>✘</td><td>ample</td><td>98.1</td><td>93.8</td><td>87.1</td><td>85.5</td><td>98.0</td><td>96.0</td><td>94.4</td><td>86.0</td><td>94.9</td><td>93.3</td><td>93.5</td><td>70.2</td><td>90.9</td></tr><tr><td>Ours-Source</td><td>N/A</td><td>8-shots</td><td>99.1</td><td>89.7</td><td>94.1</td><td>75.1</td><td>98.1</td><td>55.1</td><td>93.3</td><td>78.7</td><td>86.8</td><td>96.7</td><td>94.5</td><td>51.9</td><td>84.4</td></tr><tr><td>Ours</td><td>✓</td><td>8-shots</td><td>97.9</td><td>94.0</td><td>88.1</td><td>70.3</td><td>98.4</td><td>95.0</td><td>93.4</td><td>82.5</td><td>91.1</td><td>95.9</td><td>92.9</td><td>78.9</td><td>89.9</td></tr></table>

<table><tbody><tr><td>方法</td><td>科幻(SF)</td><td>源</td><td>${E}_{img}$</td><td>平面</td><td>自行车(bcycl)</td><td>公交车</td><td>汽车</td><td>马</td><td>刀</td><td>摩托车(moycle)</td><td>人</td><td>植物</td><td>滑板(sktbrd)</td><td>火车</td><td>卡车</td><td>平均值</td></tr><tr><td>RN - 101 [13]</td><td>不适用</td><td>充足的；样本(ample)</td><td rowspan="13">RN - 101</td><td>55.1</td><td>53.3</td><td>61.9</td><td>59.1</td><td>80.6</td><td>17.9</td><td>79.7</td><td>31.2</td><td>81.0</td><td>26.5</td><td>73.5</td><td>8.5</td><td>52.4</td></tr><tr><td>SHOT [24]</td><td>✓</td><td>充足的；样本(ample)</td><td>94.3</td><td>88.5</td><td>80.1</td><td>57.3</td><td>93.1</td><td>94.9</td><td>80.7</td><td>80.3</td><td>91.5</td><td>89.1</td><td>86.3</td><td>58.2</td><td>82.9</td></tr><tr><td>GKD [40]</td><td>✓</td><td>充足的；样本(ample)</td><td>95.3</td><td>87.6</td><td>81.7</td><td>58.1</td><td>93.9</td><td>94.0</td><td>80.0</td><td>80.0</td><td>91.2</td><td>91.0</td><td>86.9</td><td>56.1</td><td>83.0</td></tr><tr><td>PS [7]</td><td>✓</td><td>充足的；样本(ample)</td><td>95.2</td><td>86.2</td><td>82.1</td><td>61.5</td><td>93.2</td><td>95.6</td><td>86.7</td><td>80.4</td><td>91.5</td><td>90.8</td><td>85.8</td><td>59.3</td><td>84.0</td></tr><tr><td>D - MCD [3]</td><td>✓</td><td>充足的；样本(ample)</td><td>97.0</td><td>88.0</td><td>90.0</td><td>81.5</td><td>95.6</td><td>98.0</td><td>86.2</td><td>88.7</td><td>94.6</td><td>92.7</td><td>83.7</td><td>53.1</td><td>87.5</td></tr><tr><td>${\mathrm{A}}^{2}$ 网络 [51]</td><td>✓</td><td>充足的；样本(ample)</td><td>94.0</td><td>87.8</td><td>85.6</td><td>66.8</td><td>93.7</td><td>95.1</td><td>85.8</td><td>81.2</td><td>91.6</td><td>88.2</td><td>86.5</td><td>56.0</td><td>84.3</td></tr><tr><td>SCLM [41]</td><td>✓</td><td>充足的；样本(ample)</td><td>97.1</td><td>90.7</td><td>85.6</td><td>62.0</td><td>97.3</td><td>94.6</td><td>81.8</td><td>84.3</td><td>93.6</td><td>92.8</td><td>88.0</td><td>55.9</td><td>85.3</td></tr><tr><td>AAA [22]</td><td>✓</td><td>充足的；样本(ample)</td><td>94.4</td><td>85.9</td><td>74.9</td><td>60.2</td><td>96.0</td><td>93.5</td><td>87.8</td><td>80.8</td><td>90.2</td><td>92.0</td><td>86.6</td><td>68.3</td><td>84.2</td></tr><tr><td>CoWA [21]</td><td>✓</td><td>充足的；样本(ample)</td><td>96.2</td><td>89.7</td><td>83.9</td><td>73.8</td><td>96.4</td><td>97.4</td><td>89.3</td><td>86.8</td><td>94.6</td><td>92.1</td><td>88.7</td><td>53.8</td><td>86.9</td></tr><tr><td>ProxyMix [5]</td><td>✓</td><td>充足的；样本(ample)</td><td>95.4</td><td>81.7</td><td>87.2</td><td>79.9</td><td>95.6</td><td>96.8</td><td>92.1</td><td>85.1</td><td>93.4</td><td>90.3</td><td>89.1</td><td>42.2</td><td>85.7</td></tr><tr><td>C - SFDA [16]</td><td>✓</td><td>充足的；样本(ample)</td><td>97.6</td><td>88.8</td><td>86.1</td><td>72.2</td><td>97.2</td><td>94.4</td><td>92.1</td><td>84.7</td><td>93.0</td><td>90.7</td><td>93.1</td><td>63.5</td><td>87.8</td></tr><tr><td>TPDS [42]</td><td>✓</td><td>充足的；样本(ample)</td><td>97.6</td><td>91.5</td><td>89.7</td><td>83.4</td><td>97.5</td><td>96.3</td><td>92.2</td><td>82.4</td><td>96.0</td><td>94.1</td><td>90.9</td><td>40.4</td><td>87.6</td></tr><tr><td>CPD [58]</td><td>✓</td><td>充足的；样本(ample)</td><td>96.7</td><td>88.5</td><td>79.6</td><td>69.0</td><td>95.9</td><td>96.3</td><td>87.3</td><td>83.3</td><td>94.4</td><td>92.9</td><td>87.0</td><td>58.7</td><td>85.8</td></tr><tr><td>CLIP [31]</td><td>不适用</td><td>否</td><td></td><td>98.2</td><td>83.9</td><td>90.5</td><td>73.5</td><td>97.2</td><td>84.0</td><td>95.3</td><td>65.7</td><td>79.4</td><td>89.9</td><td>91.8</td><td>63.3</td><td>84.4</td></tr><tr><td>DAPL [11]</td><td>✘</td><td>充足的；样本(ample)</td><td rowspan="5"></td><td>97.8</td><td>83.1</td><td>88.8</td><td>77.9</td><td>97.4</td><td>91.5</td><td>94.2</td><td>79.7</td><td>88.6</td><td>89.3</td><td>92.5</td><td>62.0</td><td>86.9</td></tr><tr><td>ADCLIP [35]</td><td>✘</td><td>充足的；样本(ample)</td><td>98.1</td><td>83.6</td><td>91.2</td><td>76.6</td><td>98.1</td><td>93.4</td><td>96.0</td><td>81.4</td><td>86.4</td><td>91.5</td><td>92.1</td><td>64.2</td><td>87.7</td></tr><tr><td>PADCLIP [19]</td><td>✘</td><td>充足的；样本(ample)</td><td>96.7</td><td>88.8</td><td>87.0</td><td>82.8</td><td>97.1</td><td>93.0</td><td>91.3</td><td>83.0</td><td>95.5</td><td>91.8</td><td>91.5</td><td>63.0</td><td>88.5</td></tr><tr><td>我们的-源模型</td><td>不适用</td><td>8次采样</td><td>96.2</td><td>76.3</td><td>95.4</td><td>66.5</td><td>97.1</td><td>62.6</td><td>95.6</td><td>9.3</td><td>92.4</td><td>93.3</td><td>91.5</td><td>43.0</td><td>76.6</td></tr><tr><td>我们的方法</td><td>✓</td><td>8次采样</td><td>97.3</td><td>90.8</td><td>83.5</td><td>67.9</td><td>96.8</td><td>95.0</td><td>90.4</td><td>78.5</td><td>89.3</td><td>91.4</td><td>92.8</td><td>72.5</td><td>87.2</td></tr><tr><td>DSiT - B* [34]</td><td>✓</td><td>充足的；样本(ample)</td><td rowspan="7">ViT - B/16</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>87.6</td></tr><tr><td>CLIP [31]</td><td>不适用</td><td>否</td><td>99.1</td><td>91.7</td><td>93.8</td><td>76.7</td><td>98.4</td><td>91.7</td><td>95.3</td><td>82.7</td><td>86.5</td><td>96.0</td><td>94.6</td><td>60.5</td><td>88.9</td></tr><tr><td>DAPL [11]</td><td>✘</td><td>充足的；样本(ample)</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>89.8</td></tr><tr><td>ADCLIP [35]</td><td>✘</td><td>充足的；样本(ample)</td><td>99.6</td><td>92.8</td><td>94.0</td><td>78.6</td><td>98.8</td><td>95.4</td><td>96.8</td><td>83.9</td><td>91.5</td><td>95.8</td><td>95.5</td><td>65.7</td><td>90.7</td></tr><tr><td>PADCLIP [19]</td><td>✘</td><td>充足的；样本(ample)</td><td>98.1</td><td>93.8</td><td>87.1</td><td>85.5</td><td>98.0</td><td>96.0</td><td>94.4</td><td>86.0</td><td>94.9</td><td>93.3</td><td>93.5</td><td>70.2</td><td>90.9</td></tr><tr><td>我们的-源模型</td><td>不适用</td><td>8次采样</td><td>99.1</td><td>89.7</td><td>94.1</td><td>75.1</td><td>98.1</td><td>55.1</td><td>93.3</td><td>78.7</td><td>86.8</td><td>96.7</td><td>94.5</td><td>51.9</td><td>84.4</td></tr><tr><td>我们的方法</td><td>✓</td><td>8次采样</td><td>97.9</td><td>94.0</td><td>88.1</td><td>70.3</td><td>98.4</td><td>95.0</td><td>93.4</td><td>82.5</td><td>91.1</td><td>95.9</td><td>92.9</td><td>78.9</td><td>89.9</td></tr></tbody></table>

TABLE IV: Accuracy (%) of Different Settings and Domain Adaptation Methods on the VisDA-2017[28] Dataset.

表四:不同设置和领域自适应方法在VisDA - 2017[28]数据集上的准确率(%)。

<table><tr><td>Method</td><td>SF</td><td>Source</td><td>${f}_{v}$</td><td>$\mathrm{A} \rightarrow  \mathrm{U}$</td><td>$\mathrm{U} \rightarrow  \mathrm{A}$</td><td>$\mathrm{N} \rightarrow  \mathrm{U}$</td><td>$\mathrm{U} \rightarrow  \mathrm{N}$</td><td>$\mathrm{N} \rightarrow  \mathrm{A}$</td><td>$\mathrm{A} \rightarrow  \mathrm{N}$</td><td>Average</td></tr><tr><td>RN-50 [13]</td><td>N/A</td><td>ample</td><td rowspan="6">RN-50</td><td>62.3</td><td>61.8</td><td>70.2</td><td>61.6</td><td>88.2</td><td>74.5</td><td>69.8</td></tr><tr><td>DDC [46]</td><td>✘</td><td>ample</td><td>68.4</td><td>52.8</td><td>80.5</td><td>52.1</td><td>85.3</td><td>81.3</td><td>70.1</td></tr><tr><td>DAN [27]</td><td>✘</td><td>ample</td><td>75.4</td><td>56.6</td><td>85.3</td><td>54.2</td><td>86.7</td><td>86.7</td><td>74.1</td></tr><tr><td>Deep CORAL [39]</td><td>✘</td><td>ample</td><td>65.7</td><td>53.9</td><td>79.8</td><td>52.2</td><td>85.1</td><td>81.4</td><td>69.7</td></tr><tr><td>DANN [9]</td><td>✘</td><td>ample</td><td>67.2</td><td>52.8</td><td>84.4</td><td>53.3</td><td>86.1</td><td>82.3</td><td>71.0</td></tr><tr><td>DATSNET [56]</td><td>✘</td><td>ample</td><td>85.7</td><td>88.4</td><td>91.9</td><td>77.5</td><td>94.3</td><td>88.4</td><td>87.7</td></tr><tr><td>CLIP [31]</td><td>N/A</td><td>no</td><td rowspan="3">RN-50</td><td>54.7</td><td>63.4</td><td>49.2</td><td>49.7</td><td>56.8</td><td>48.2</td><td>53.7</td></tr><tr><td>Ours-Source</td><td>✘</td><td>8-shots</td><td>71.0</td><td>75.1</td><td>65.2</td><td>60.8</td><td>81.8</td><td>70.8</td><td>70.8</td></tr><tr><td>Ours</td><td>✓</td><td>no</td><td>88.7</td><td>93.8</td><td>85.5</td><td>75.5</td><td>92.2</td><td>84.1</td><td>86.6</td></tr><tr><td>CLIP [31]</td><td>N/A</td><td>no</td><td rowspan="5">ViT-b/16</td><td>67.8</td><td>70.9</td><td>62.5</td><td>61.4</td><td>62.6</td><td>56.2</td><td>63.6</td></tr><tr><td>DAPL [11]</td><td>✘</td><td>ample</td><td>71.4</td><td>78.1</td><td>64.7</td><td>64.9</td><td>65.8</td><td>61.7</td><td>67.8</td></tr><tr><td>AD-CLIP [35]</td><td>✘</td><td>ample</td><td>86.9</td><td>95.4</td><td>91.2</td><td>87.7</td><td>93.9</td><td>87.9</td><td>90.5</td></tr><tr><td>Ours-Source</td><td>N/A</td><td>8-shots</td><td>81.9</td><td>92.0</td><td>81.5</td><td>84.1</td><td>87.6</td><td>82.9</td><td>85.0</td></tr><tr><td>Ours</td><td>✓</td><td>no</td><td>92.3</td><td>98.8</td><td>92.0</td><td>91.6</td><td>96.3</td><td>91.5</td><td>93.8</td></tr></table>

<table><tbody><tr><td>方法</td><td>SF(原文未明确含义，保留英文)</td><td>源</td><td>${f}_{v}$</td><td>$\mathrm{A} \rightarrow  \mathrm{U}$</td><td>$\mathrm{U} \rightarrow  \mathrm{A}$</td><td>$\mathrm{N} \rightarrow  \mathrm{U}$</td><td>$\mathrm{U} \rightarrow  \mathrm{N}$</td><td>$\mathrm{N} \rightarrow  \mathrm{A}$</td><td>$\mathrm{A} \rightarrow  \mathrm{N}$</td><td>平均值</td></tr><tr><td>残差网络-50(ResNet-50) [13]</td><td>不适用</td><td>示例</td><td rowspan="6">残差网络-50(ResNet-50)</td><td>62.3</td><td>61.8</td><td>70.2</td><td>61.6</td><td>88.2</td><td>74.5</td><td>69.8</td></tr><tr><td>深度域混淆(Deep Domain Confusion，DDC) [46]</td><td>✘</td><td>示例</td><td>68.4</td><td>52.8</td><td>80.5</td><td>52.1</td><td>85.3</td><td>81.3</td><td>70.1</td></tr><tr><td>深度对抗网络(Deep Adversarial Network，DAN) [27]</td><td>✘</td><td>示例</td><td>75.4</td><td>56.6</td><td>85.3</td><td>54.2</td><td>86.7</td><td>86.7</td><td>74.1</td></tr><tr><td>深度珊瑚网络(Deep CORAL) [39]</td><td>✘</td><td>示例</td><td>65.7</td><td>53.9</td><td>79.8</td><td>52.2</td><td>85.1</td><td>81.4</td><td>69.7</td></tr><tr><td>深度对抗域适应网络(Deep Adversarial Domain Adaptation Network，DANN) [9]</td><td>✘</td><td>示例</td><td>67.2</td><td>52.8</td><td>84.4</td><td>53.3</td><td>86.1</td><td>82.3</td><td>71.0</td></tr><tr><td>数据自适应迁移网络(Data Adaptive Transfer Network，DATSNET) [56]</td><td>✘</td><td>示例</td><td>85.7</td><td>88.4</td><td>91.9</td><td>77.5</td><td>94.3</td><td>88.4</td><td>87.7</td></tr><tr><td>对比语言-图像预训练(Contrastive Language-Image Pretraining，CLIP) [31]</td><td>不适用</td><td>否</td><td rowspan="3">残差网络-50(ResNet-50)</td><td>54.7</td><td>63.4</td><td>49.2</td><td>49.7</td><td>56.8</td><td>48.2</td><td>53.7</td></tr><tr><td>我们的方法-源域</td><td>✘</td><td>8次采样</td><td>71.0</td><td>75.1</td><td>65.2</td><td>60.8</td><td>81.8</td><td>70.8</td><td>70.8</td></tr><tr><td>我们的方法</td><td>✓</td><td>否</td><td>88.7</td><td>93.8</td><td>85.5</td><td>75.5</td><td>92.2</td><td>84.1</td><td>86.6</td></tr><tr><td>对比语言-图像预训练(Contrastive Language-Image Pretraining，CLIP) [31]</td><td>不适用</td><td>否</td><td rowspan="5">视觉Transformer基础版/16(Vision Transformer-base/16，ViT-b/16)</td><td>67.8</td><td>70.9</td><td>62.5</td><td>61.4</td><td>62.6</td><td>56.2</td><td>63.6</td></tr><tr><td>深度自适应原型学习(Deep Adaptive Prototype Learning，DAPL) [11]</td><td>✘</td><td>示例</td><td>71.4</td><td>78.1</td><td>64.7</td><td>64.9</td><td>65.8</td><td>61.7</td><td>67.8</td></tr><tr><td>自适应对比语言-图像预训练(Adaptive Contrastive Language-Image Pretraining，AD-CLIP) [35]</td><td>✘</td><td>示例</td><td>86.9</td><td>95.4</td><td>91.2</td><td>87.7</td><td>93.9</td><td>87.9</td><td>90.5</td></tr><tr><td>我们的方法-源域</td><td>不适用</td><td>8次采样</td><td>81.9</td><td>92.0</td><td>81.5</td><td>84.1</td><td>87.6</td><td>82.9</td><td>85.0</td></tr><tr><td>我们的方法</td><td>✓</td><td>否</td><td>92.3</td><td>98.8</td><td>92.0</td><td>91.6</td><td>96.3</td><td>91.5</td><td>93.8</td></tr></tbody></table>

TABLE V: Accuracy (%) for cross-domain remote scene recognition on the UCM[53], AID[50], and NWPU[2] datasets.

表五:在UCM[53]、AID[50]和NWPU[2]数据集上进行跨领域远程场景识别的准确率(%)。

The Effectiveness of Logits Fusion in Dual-Branch Networks. As shown in Figure 3, we randomly selected the migration task Product $\rightarrow$ Real World from the Office-Home dataset and visualized the accuracy changes of the cross-domain transfer branch and the target-specific feature learning branch over the training epochs. The results indicate that the accuracy of both branches gradually improves as training progresses. Furthermore, the accuracy of the merged logits for both branches consistently exceeds that of any single branch in each epoch. This demonstrates the effectiveness of our proposed dual-branch logits merging strategy in enhancing model performance.

双分支网络中对数几率融合的有效性。如图3所示，我们从Office - Home数据集中随机选择迁移任务“产品 $\rightarrow$ 现实世界”，并可视化了跨领域迁移分支和特定目标特征学习分支在训练轮次中的准确率变化。结果表明，随着训练的进行，两个分支的准确率均逐渐提高。此外，在每个训练轮次中，两个分支合并后的对数几率的准确率始终超过任何单个分支的准确率。这证明了我们提出的双分支对数几率合并策略在提升模型性能方面的有效性。

<table><tr><td>Source training</td><td>Target Prompt</td><td>Fusion dual branches</td><td>Trainable ${W}_{e}$</td><td>Avg</td></tr><tr><td>✓</td><td/><td/><td/><td>82.5</td></tr><tr><td/><td>✓</td><td/><td/><td>84.3</td></tr><tr><td>✓</td><td>✓</td><td>✓</td><td/><td>85.7</td></tr><tr><td>✓</td><td>✓</td><td>✓</td><td>✓</td><td>86.2</td></tr></table>

<table><tbody><tr><td>源训练</td><td>目标提示</td><td>融合双分支</td><td>可训练的 ${W}_{e}$</td><td>平均值</td></tr><tr><td>✓</td><td></td><td></td><td></td><td>82.5</td></tr><tr><td></td><td>✓</td><td></td><td></td><td>84.3</td></tr><tr><td>✓</td><td>✓</td><td>✓</td><td></td><td>85.7</td></tr><tr><td>✓</td><td>✓</td><td>✓</td><td>✓</td><td>86.2</td></tr></tbody></table>

TABLE VI: Ablation study of sub-components of the proposed method measured by classification accuracy(%) on Office-Home benchmark, 8 shots for cache key, backbone ViT-B/16.

表六:在Office - Home基准测试中，以分类准确率(%)衡量的所提出方法各子组件的消融研究，缓存键使用8次采样，骨干网络为ViT - B/16。

<table><tr><td>${\mathcal{L}}_{ce}$</td><td>${\mathcal{L}}_{im}$</td><td>${\mathcal{L}}_{fm}$</td><td>Office-Home</td><td>DomainNet-126</td><td>VisDA-2017</td><td>Avg</td></tr><tr><td>✓</td><td/><td/><td>84.2</td><td>84.4</td><td>89</td><td>86.17</td></tr><tr><td/><td>✓</td><td/><td>85.2</td><td>86.2</td><td>89.3</td><td>86.90</td></tr><tr><td>✓</td><td/><td>✓</td><td>85.0</td><td>86</td><td>89.9</td><td>86.97</td></tr><tr><td>✓</td><td>✓</td><td/><td>85.6</td><td>85.8</td><td>89.3</td><td>86.90</td></tr><tr><td/><td>✓</td><td>✓</td><td>85.4</td><td>86.1</td><td>89.4</td><td>86.97</td></tr><tr><td>✓</td><td>✓</td><td>✓</td><td>86.2</td><td>86.7</td><td>89.9</td><td>87.60</td></tr></table>

<table><tbody><tr><td>${\mathcal{L}}_{ce}$</td><td>${\mathcal{L}}_{im}$</td><td>${\mathcal{L}}_{fm}$</td><td>办公-家居</td><td>领域网络-126(DomainNet-126)</td><td>视觉领域适应挑战赛2017(VisDA-2017)</td><td>平均值</td></tr><tr><td>✓</td><td></td><td></td><td>84.2</td><td>84.4</td><td>89</td><td>86.17</td></tr><tr><td></td><td>✓</td><td></td><td>85.2</td><td>86.2</td><td>89.3</td><td>86.90</td></tr><tr><td>✓</td><td></td><td>✓</td><td>85.0</td><td>86</td><td>89.9</td><td>86.97</td></tr><tr><td>✓</td><td>✓</td><td></td><td>85.6</td><td>85.8</td><td>89.3</td><td>86.90</td></tr><tr><td></td><td>✓</td><td>✓</td><td>85.4</td><td>86.1</td><td>89.4</td><td>86.97</td></tr><tr><td>✓</td><td>✓</td><td>✓</td><td>86.2</td><td>86.7</td><td>89.9</td><td>87.60</td></tr></tbody></table>

TABLE VII: Ablation on different constraint losses, backbone ViT-B/16.

表七:不同约束损失的消融实验，骨干网络为ViT - B/16(视觉Transformer - B/16)。

<table><tr><td>shots</td><td>$\mathrm{A} \rightarrow  \mathrm{U}$</td><td>$\mathrm{U} \rightarrow  \mathrm{A}$</td><td>$\mathrm{N} \rightarrow  \mathrm{U}$</td><td>$\mathrm{U} \rightarrow  \mathrm{N}$</td><td>$\mathrm{N} \rightarrow  \mathrm{A}$</td><td>$\mathrm{A} \rightarrow  \mathrm{N}$</td><td>Average</td></tr><tr><td>1</td><td>82.1</td><td>98.2</td><td>82.1</td><td>83.6</td><td>87.6</td><td>90.8</td><td>87.40</td></tr><tr><td>2</td><td>86.8</td><td>98.9</td><td>81.6</td><td>91.2</td><td>95</td><td>88.5</td><td>90.33</td></tr><tr><td>4</td><td>88.1</td><td>98.8</td><td>91.0</td><td>91.2</td><td>98.9</td><td>90.1</td><td>93.02</td></tr><tr><td>8</td><td>92.3</td><td>98.8</td><td>92.0</td><td>91.6</td><td>96.3</td><td>91.5</td><td>93.75</td></tr><tr><td>16</td><td>92.1</td><td>98.6</td><td>91.2</td><td>92.1</td><td>96.1</td><td>91.0</td><td>93.52</td></tr></table>

<table><tbody><tr><td>镜头</td><td>$\mathrm{A} \rightarrow  \mathrm{U}$</td><td>$\mathrm{U} \rightarrow  \mathrm{A}$</td><td>$\mathrm{N} \rightarrow  \mathrm{U}$</td><td>$\mathrm{U} \rightarrow  \mathrm{N}$</td><td>$\mathrm{N} \rightarrow  \mathrm{A}$</td><td>$\mathrm{A} \rightarrow  \mathrm{N}$</td><td>平均</td></tr><tr><td>1</td><td>82.1</td><td>98.2</td><td>82.1</td><td>83.6</td><td>87.6</td><td>90.8</td><td>87.40</td></tr><tr><td>2</td><td>86.8</td><td>98.9</td><td>81.6</td><td>91.2</td><td>95</td><td>88.5</td><td>90.33</td></tr><tr><td>4</td><td>88.1</td><td>98.8</td><td>91.0</td><td>91.2</td><td>98.9</td><td>90.1</td><td>93.02</td></tr><tr><td>8</td><td>92.3</td><td>98.8</td><td>92.0</td><td>91.6</td><td>96.3</td><td>91.5</td><td>93.75</td></tr><tr><td>16</td><td>92.1</td><td>98.6</td><td>91.2</td><td>92.1</td><td>96.1</td><td>91.0</td><td>93.52</td></tr></tbody></table>

TABLE VIII: Model performance in target domain with different source domain sample sizes.

表八:不同源域样本量下模型在目标域的性能。

Impact of Source Domain Sample Size. As illustrated in Table VIII, we analyzed the impact of the number of samples in the source domain on the performance of the transferred model in the target domain across three remote sensing datasets. It is evident that when the number of samples per class in the source domain is fewer than eight, increasing the sample size significantly enhances the model's performance. Specifically, the performance improved by ${6.35}\%$ when the sample count increased from one to eight per class. This improvement can be attributed to the more comprehensive semantic information about the class contained within the samples at this stage. However, when the sample count reaches sixteen per class, the model's performance does not improve and slightly decreases compared to having eight samples per class. This decline is likely due to the semantic features learned being overfitted to the source domain, and during the training of the source domain samples, the amount of learnable parameters was limited. Thus, when the number of source domain samples exceeds eight, the useful semantic information for the target domain has likely reached saturation.

源域样本量的影响。如表八所示，我们分析了源域样本数量对迁移模型在三个遥感数据集目标域性能的影响。显然，当源域中每类样本数量少于8个时，增加样本量会显著提升模型性能。具体而言，当每类样本数量从1个增加到8个时，性能提升了 ${6.35}\%$。这种提升可归因于这一阶段样本中包含了更全面的类别语义信息。然而，当每类样本数量达到16个时，与每类8个样本相比，模型性能并未提升，反而略有下降。这种下降可能是由于学习到的语义特征过度拟合源域，并且在训练源域样本时，可学习参数的数量有限。因此，当源域样本数量超过8个时，对目标域有用的语义信息可能已达到饱和。

## D. Parameter Sensitivity and Qualitative Analysis

## D. 参数敏感性与定性分析

The Impact of $\alpha$ on Model Performance. As shown in Figure 4, we present the trend of average accuracy across all transfer tasks in the Office-Home dataset as the parameter $\alpha$ varies. A larger $\alpha$ indicates a greater influence of the cross-domain feature transfer branch's predictions in the final decision. The results reveal that when $\alpha$ is less than 0.7, the combined performance surpasses that of either branch individually. However, when $\alpha$ exceeds 0.8, the combined performance, while still higher than that of the cross-domain transfer branch, falls below that of the target-specific feature learning branch. This is due to the lower performance of the cross-domain transfer branch compared to the target-specific branch within the Office-Home dataset. Overall, the fusion of the two branches significantly enhances their performance across most values of $\alpha$ .

$\alpha$ 对模型性能的影响。如图4所示，我们展示了在Office - Home数据集中，随着参数 $\alpha$ 的变化，所有迁移任务的平均准确率趋势。$\alpha$ 越大，表明跨域特征迁移分支的预测在最终决策中的影响越大。结果显示，当 $\alpha$ 小于0.7时，组合性能超过了任一单分支的性能。然而，当 $\alpha$ 超过0.8时，组合性能虽然仍高于跨域迁移分支，但低于特定目标特征学习分支。这是因为在Office - Home数据集中，跨域迁移分支的性能低于特定目标分支。总体而言，在 $\alpha$ 的大多数取值下，两个分支的融合显著提升了它们的性能。

The Impact of $K$ on Model Performance. To analyze the impact of the number of high-confidence target domain samples within the cross-domain feature transfer branch on model performance, we conducted this experiment across 12 transfer tasks within the Office-Home dataset. We compared the average accuracy of all transfer tasks in the target domain under varying counts of high-confidence samples per category, specifically1,2,4,8, and 16 samples. As shown in Table IX, when the value of $K$ increased from 1 to 8, there was a significant improvement in model performance, with an increase of 2.29% when using 8 samples per category compared to just one. However, further increasing the count to 16 did not alter performance significantly. This plateau is attributed to the increased likelihood of introducing erroneous pseudo-labels as the number of samples grows, adversely affecting the model's effectiveness.

$K$ 对模型性能的影响。为了分析跨域特征迁移分支中高置信度目标域样本数量对模型性能的影响，我们在Office - Home数据集的12个迁移任务中进行了此实验。我们比较了在每类不同数量的高置信度样本(具体为1、2、4、8和16个样本)下，目标域中所有迁移任务的平均准确率。如表九所示，当 $K$ 的值从1增加到8时，模型性能有显著提升，每类使用8个样本时比仅使用1个样本时准确率提高了2.29%。然而，进一步将数量增加到16个时，性能没有显著变化。这种平稳状态归因于随着样本数量增加，引入错误伪标签的可能性增大，从而对模型效果产生不利影响。

![0195dcf6-b307-7b10-9224-24b77c210989_10_186_1642_656_493_0.jpg](images/0195dcf6-b307-7b10-9224-24b77c210989_10_186_1642_656_493_0.jpg)

Fig. 4: The average accuracy (%) on different $\alpha$ .

图4:不同 $\alpha$ 下的平均准确率(%)。

<table><tr><td>K</td><td>1</td><td>2</td><td>4</td><td>8</td><td>16</td></tr><tr><td>Avg</td><td>75.83</td><td>76.6</td><td>77.34</td><td>78.12</td><td>78.08</td></tr></table>

<table><tbody><tr><td>K</td><td>1</td><td>2</td><td>4</td><td>8</td><td>16</td></tr><tr><td>平均</td><td>75.83</td><td>76.6</td><td>77.34</td><td>78.12</td><td>78.08</td></tr></tbody></table>

TABLE IX: Average Accuracy for Different Values of $K$ on the OfficeHome Dataset Using ResNet-50 Backbone.

表九:使用ResNet - 50骨干网络在OfficeHome数据集上不同 $K$ 值的平均准确率。

Dual-Branch Derived Category Text Features Visualization Using t-SNE. To qualitatively analyze the variation in the class text features obtained, we conducted this experiment. Specifically, we randomly selected a transfer direction from the Office-Home dataset and, for visualization convenience, randomly chose 25 categories from the 65 available. We compared the class text features derived using the manually designed prompt "a photo of a" in CLIP, those obtained from the source domain after prompt-learning training, and those derived from our proposed dual-branch network following unsupervised training. Our method incorporates two types of class text features. As shown in Figure 5, the class text features obtained from the manually designed prompt template and source domain prompt-learning are more concentrated, displaying poor class separability for the target domain samples. In contrast, after enhancement through our cross-domain transfer branch, the class text features from the source domain are dispersed across different sample clusters, and the target-specific feature learning branch also distributes class text features across various class clusters, demonstrating improved inter-class separability.

使用t - SNE对双分支派生类别文本特征进行可视化。为了定性分析所获得的类别文本特征的变化，我们进行了此实验。具体而言，我们从Office - Home数据集中随机选择了一个迁移方向，并且为了便于可视化，从65个可用类别中随机选择了25个类别。我们比较了使用CLIP中手动设计的提示“一张……的照片”派生的类别文本特征、在提示学习训练后从源域获得的类别文本特征，以及在无监督训练后从我们提出的双分支网络派生的类别文本特征。我们的方法包含两种类型的类别文本特征。如图5所示，从手动设计的提示模板和源域提示学习中获得的类别文本特征更为集中，对目标域样本的类别可分性较差。相比之下，在通过我们的跨域迁移分支进行增强后，来自源域的类别文本特征分散在不同的样本簇中，并且特定于目标的特征学习分支也将类别文本特征分布在各个类别簇中，显示出更好的类间可分性。

## V. CONCLUSION

## 五、结论

In this paper, we address the dual challenges of inaccessible source domains and limited source sample availability in FS-SF-UDA by proposing a Data-Efficient CLIP-Powered Dual-Branch Network(CDBN). This network leverages the synergistic effects of cross-domain feature transfer and target-specific feature learning to enhance model generalization to the target domain while preserving the effective class semantic information learned from a small number of source domain samples. This significantly improves data utilization efficiency for source domain samples and prevents model overfitting to the limited source domain sample distribution. Furthermore, we introduce an unsupervised optimization strategy that maintains the source domain's classification capabilities while ensuring that the target domain predictions balance high accuracy with category diversity. Employing only unlabeled target domain samples, this strategy enables stable and efficient model training. Ultimately, our approach achieves best performance on multiple datasets and comparable results to the existing best methods on other datasets. This validates the effectiveness of our proposed dual-branch structure and its unsupervised optimization strategy, further demonstrating that even with limited source domain samples, the category semantic information can still provide crucial assistance for target domain adaptation.

在本文中，我们通过提出一种数据高效的CLIP驱动双分支网络(CDBN)来应对少样本源自由无监督域适应(FS - SF - UDA)中源域不可访问和源样本有限的双重挑战。该网络利用跨域特征迁移和特定于目标的特征学习的协同效应，在保留从少量源域样本中学到的有效类别语义信息的同时，增强模型对目标域的泛化能力。这显著提高了源域样本的数据利用效率，并防止模型对有限的源域样本分布过拟合。此外，我们引入了一种无监督优化策略，该策略在保持源域分类能力的同时，确保目标域预测在高准确率和类别多样性之间取得平衡。该策略仅使用无标签的目标域样本，实现了稳定高效的模型训练。最终，我们的方法在多个数据集上取得了最佳性能，在其他数据集上取得了与现有最佳方法相当的结果。这验证了我们提出的双分支结构及其无监督优化策略的有效性，进一步表明即使源域样本有限，类别语义信息仍可为目标域适应提供关键帮助。

![0195dcf6-b307-7b10-9224-24b77c210989_11_169_167_1463_439_0.jpg](images/0195dcf6-b307-7b10-9224-24b77c210989_11_169_167_1463_439_0.jpg)

Fig. 5: The t-SNE visualization of $\mathrm{R} \rightarrow  \mathrm{P}$ transfer tasks in Office-Home. Different colored dots represent the sample features of the target domain, while black pentagrams and magenta inverted triangles denote categorical text features. (a) Categorical text features derived using the manually designed prompt "a photo of a" from CLIP; (b) Categorical text features obtained from the source domain after prompt learning; (c) Two different types of categorical text features obtained from our dual-branch network after unsupervised training, where the black pentagrams indicate the cross-domain feature transfer branch and the magenta inverted triangles indicate the target-specific feature learning branch.

图5:Office - Home中 $\mathrm{R} \rightarrow  \mathrm{P}$ 迁移任务的t - SNE可视化。不同颜色的点代表目标域的样本特征，而黑色五角星和品红色倒三角形表示类别文本特征。(a)使用CLIP中手动设计的提示“一张……的照片”派生的类别文本特征；(b)提示学习后从源域获得的类别文本特征；(c)无监督训练后从我们的双分支网络获得的两种不同类型的类别文本特征，其中黑色五角星表示跨域特征迁移分支，品红色倒三角形表示特定于目标的特征学习分支。

## REFERENCES

## 参考文献

[1] Haolong Chen, Hanzhi Chen, Zijian Zhao, Kaifeng Han, Guangxu Zhu, Yichen Zhao, Ying Du, Wei Xu, and Qingjiang Shi. An overview of domain-specific foundation model: key technologies, applications and challenges. arXiv preprint arXiv:2409.04267, 2024.

[1] 陈浩龙，陈汉之，赵子健，韩开封，朱光旭，赵逸晨，杜莹，徐伟，石清江。特定领域基础模型综述:关键技术、应用与挑战。预印本arXiv:2409.04267，2024。

[2] Gong Cheng, Junwei Han, and Xiaoqiang Lu. Remote sensing image scene classification: Benchmark and state of the art. Proceedings of the IEEE, 105(10):1865-1883, 2017.

[2] 龚成，韩军伟，陆小强。遥感影像场景分类:基准与现状。《电气与电子工程师协会汇刊》，105(10):1865 - 1883，2017。

[3] Tong Chu, Yahao Liu, Jinhong Deng, Wen Li, and Lixin Duan. Denoised maximum classifier discrepancy for source-free unsupervised domain adaptation. In Proceedings of the AAAI conference on artificial intelligence, volume 36, pages 472-480, 2022.

[3] 储彤，刘亚豪，邓锦宏，李文，段立新。用于源自由无监督域适应的去噪最大分类器差异。《人工智能协会会议论文集》，第36卷，第472 - 480页，2022。

[4] Hong N Dao, Tuyen Nguyen, Cherubin Mugisha, and Incheon Paik. A multimodal transfer learning approach using pubmedclip for medical image classification. IEEE Access, 2024.

[4] 洪·N·道，阮春，谢鲁宾·穆吉沙，白仁川。一种使用PubMedCLIP进行医学图像分类的多模态迁移学习方法。《电气与电子工程师协会接入》，2024。

[5] Yuhe Ding, Lijun Sheng, Jian Liang, Aihua Zheng, and Ran He. Proxymix: Proxy-based mixup training with label refinery for source-free domain adaptation. Neural Networks, 167:92-103, 2023.

[5] 丁宇赫，盛立军，梁健，郑爱华，何冉。Proxymix:用于源自由域适应的基于代理的混合训练与标签精炼。《神经网络》，167:92 - 103，2023。

[6] Alexey Dosovitskiy. An image is worth 16x16 words: Transformers for image recognition at scale. arXiv preprint arXiv:2010.11929, 2020.

[6] 阿列克谢·多索维茨基。一幅图像胜似16×16个单词:大规模图像识别的Transformer。预印本arXiv:2010.11929，2020。

[7] Yuntao Du, Haiyang Yang, Mingcai Chen, Hongtao Luo, Juan Jiang, Yi Xin, and Chongjun Wang. Generation, augmentation, and alignment: A pseudo-source domain based method for source-free domain adaptation. Machine Learning, 113(6):3611-3631, 2024.

[7] 杜云涛、杨海洋、陈明才、罗洪涛、蒋娟、辛毅和王崇军。生成、增强与对齐:一种基于伪源域的无源域自适应方法。《机器学习》，113(6):3611 - 3631，2024年。

[8] Yaroslav Ganin and Victor Lempitsky. Unsupervised domain adaptation by backpropagation. In International conference on machine learning, pages 1180- 1189. PMLR, 2015.

[8] 亚罗斯拉夫·加宁(Yaroslav Ganin)和维克多·伦皮茨基(Victor Lempitsky)。通过反向传播进行无监督域自适应。见《国际机器学习会议》，第1180 - 1189页。机器学习研究会议录(PMLR)，2015年。

[9] Yaroslav Ganin, Evgeniya Ustinova, Hana Ajakan, Pascal Germain, Hugo Larochelle, François Laviolette, Mario March, and Victor Lempitsky. Domain-adversarial training of neural networks. Journal of machine learning research, 17(59):1-35, 2016.

[9] 亚罗斯拉夫·加宁(Yaroslav Ganin)、叶夫根尼娅·乌斯蒂诺娃(Evgeniya Ustinova)、哈娜·阿贾坎(Hana Ajakan)、帕斯卡尔·热尔曼(Pascal Germain)、雨果·拉罗谢尔(Hugo Larochelle)、弗朗索瓦·拉维奥莱特(François Laviolette)、马里奥·马奇(Mario March)和维克多·伦皮茨基(Victor Lempitsky)。神经网络的域对抗训练。《机器学习研究杂志》，17(59):1 - 35，2016年。

[10] Jingsheng Gao, Jiacheng Ruan, Suncheng Xiang, Zefang Yu, Ke Ji, Mingye Xie, Ting Liu, and Yuzhuo Fu. Lamm: Label alignment for multi-modal prompt learning. In Proceedings of the AAAI Conference on Artificial Intelligence, volume 38, pages 1815-1823, 2024.

[10] 高景生、阮嘉诚、向孙成、余泽芳、纪可、谢明烨、刘婷和傅玉卓。Lamm:多模态提示学习的标签对齐。见《AAAI人工智能会议论文集》，第38卷，第1815 - 1823页，2024年。

[11] Chunjiang Ge, Rui Huang, Mixue Xie, Zihang Lai, Shiji Song, Shuang Li, and Gao Huang. Domain adaptation via prompt learning. IEEE Transactions on Neural Networks and Learning Systems, 2023.

[11] 葛春江、黄锐、谢米雪、赖子航、宋诗吉、李双和黄高。通过提示学习进行域自适应。《IEEE神经网络与学习系统汇刊》，2023年。

[12] Varun Gulshan, Lily Peng, Marc Coram, Martin C Stumpe, Derek Wu, Arunachalam Narayanaswamy, Sub-hashini Venugopalan, Kasumi Widner, Tom Madams, Jorge Cuadros, et al. Development and validation of a deep learning algorithm for detection of diabetic retinopathy in retinal fundus photographs. jama, 316(22): 2402-2410, 2016.

[12] 瓦伦·古尔山(Varun Gulshan)、莉莉·彭(Lily Peng)、马克·科拉姆(Marc Coram)、马丁·C·斯图姆佩(Martin C Stumpe)、德里克·吴(Derek Wu)、阿鲁纳恰拉姆·纳拉亚纳斯瓦米(Arunachalam Narayanaswamy)、苏巴什妮·维努戈帕兰(Sub - hashini Venugopalan)、春日井·维德纳(Kasumi Widner)、汤姆·马丹斯(Tom Madams)、豪尔赫·夸德罗斯(Jorge Cuadros)等。用于检测视网膜眼底照片中糖尿病视网膜病变的深度学习算法的开发与验证。《美国医学会杂志》，316(22): 2402 - 2410，2016年。

[13] Kaiming He, Xiangyu Zhang, Shaoqing Ren, and Jian Sun. Deep residual learning for image recognition. In Proceedings of the IEEE conference on computer vision and pattern recognition, pages 770-778, 2016.

[13] 何恺明、张祥雨、任少卿和孙剑。用于图像识别的深度残差学习。见《IEEE计算机视觉与模式识别会议论文集》，第770 - 778页，2016年。

[14] Kaiming He, Xiangyu Zhang, Shaoqing Ren, and Jian Sun. Deep residual learning for image recognition. In Proceedings of the IEEE conference on computer vision and pattern recognition, pages 770-778, 2016.

[14] 何恺明、张祥雨、任少卿和孙剑。用于图像识别的深度残差学习。见《IEEE计算机视觉与模式识别会议论文集》，第770 - 778页，2016年。

[15] Tony Huang, Jack Chu, and Fangyun Wei. Unsupervised prompt learning for vision-language models. arXiv preprint arXiv:2204.03649, 2022.

[15] 黄托尼(Tony Huang)、朱杰克(Jack Chu)和魏芳云。视觉 - 语言模型的无监督提示学习。预印本arXiv:2204.03649，2022年。

[16] Nazmul Karim, Niluthpol Chowdhury Mithun, Abhinav

[16] 纳兹穆尔·卡里姆(Nazmul Karim)、尼卢特波尔·乔杜里·米通(Niluthpol Chowdhury Mithun)、阿比纳夫

Rajvanshi, Han-pang Chiu, Supun Samarasekera, and Nazanin Rahnavard. C-sfda: A curriculum learning aided self-training framework for efficient source free

拉杰万希(Rajvanshi)、邱汉邦(Han - pang Chiu)、苏潘·萨马拉塞克拉(Supun Samarasekera)和纳赞宁·拉赫纳瓦德(Nazanin Rahnavard)。C - sfda:一种用于高效无源域自适应的课程学习辅助自训练框架

domain adaptation. In Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition, pages 24120-24131, 2023.

。见《IEEE/CVF计算机视觉与模式识别会议论文集》，第24120 - 24131页，2023年。

[17] Muhammad Uzair Khattak, Hanoona Rasheed, Muhammad Maaz, Salman Khan, and Fahad Shahbaz Khan. Maple: Multi-modal prompt learning. In Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition, pages 19113-19122, 2023.

[17] 穆罕默德·乌扎尔·哈塔克(Muhammad Uzair Khattak)、哈努娜·拉希德(Hanoona Rasheed)、穆罕默德·马兹(Muhammad Maaz)、萨尔曼·汗(Salman Khan)和法哈德·沙巴兹·汗(Fahad Shahbaz Khan)。Maple:多模态提示学习。见《IEEE/CVF计算机视觉与模式识别会议论文集》，第19113 - 19122页，2023年。

[18] Donghyun Kim, Kuniaki Saito, Tae-Hyun Oh, Bryan A Plummer, Stan Sclaroff, and Kate Saenko. Cross-domain self-supervised learning for domain adaptation with few source labels. arXiv preprint arXiv:2003.08264, 2020.

[18] 金东贤(Donghyun Kim)、斋藤邦明(Kuniaki Saito)、吴泰贤(Tae - Hyun Oh)、布莱恩·A·普拉默(Bryan A Plummer)、斯坦·斯克拉罗夫(Stan Sclaroff)和凯特·塞内科(Kate Saenko)。使用少量源标签进行跨域自监督学习以实现域自适应。预印本arXiv:2003.08264，2020年。

[19] Zhengfeng Lai, Noranart Vesdapunt, Ning Zhou, Jun Wu, Cong Phuoc Huynh, Xuelu Li, Kah Kuen Fu, and Chen-Nee Chuah. Padclip: Pseudo-labeling with adaptive debiasing in clip for unsupervised domain adaptation. In Proceedings of the IEEE/CVF International Conference on Computer Vision, pages 16155-16165, 2023.

[19] 赖正峰、诺拉纳特·维斯达蓬(Noranart Vesdapunt)、周宁、吴军、胡英福(Cong Phuoc Huynh)、李雪璐、傅家权(Kah Kuen Fu)和朱陈妮(Chen - Nee Chuah)。Padclip:在CLIP中进行自适应去偏的伪标签标注用于无监督域自适应。见《IEEE/CVF国际计算机视觉会议论文集》，第16155 - 16165页，2023年。

[20] TASET SHIFT IN MACHINE LEARNING. Dataset shift in machine learning.

[20] 机器学习中的数据集偏移。机器学习中的数据集偏移。

[21] Jonghyun Lee, Dahuin Jung, Junho Yim, and Sungroh Yoon. Confidence score for source-free unsupervised domain adaptation. In International conference on machine learning, pages 12365-12377. PMLR, 2022.

[21] 李钟贤(Jonghyun Lee)、郑大熙(Dahuin Jung)、林俊浩(Junho Yim)和尹成罗(Sungroh Yoon)。无源无监督领域自适应的置信度得分。见《国际机器学习会议论文集》，第12365 - 12377页。机器学习研究会议录(PMLR)，2022年。

[22] Jingjing Li, Zhekai Du, Lei Zhu, Zhengming Ding, Ke Lu, and Heng Tao Shen. Divergence-agnostic unsupervised domain adaptation by adversarial attacks. IEEE Transactions on Pattern Analysis and Machine Intelligence, 44(11):8196-8211, 2021.

[22] 李晶晶、杜哲恺、朱磊、丁正明、卢柯和沈恒涛。通过对抗攻击实现与散度无关的无监督领域自适应。《电气与电子工程师协会模式分析与机器智能汇刊》(IEEE Transactions on Pattern Analysis and Machine Intelligence)，44(11):8196 - 8211，2021年。

[23] Yongguang Li, Shengsheng Wang, Zihao Fu, and Ziqi Yin. Few-shot domain adaptation via prompt-guided multi-prototype alignment network. In International Conference on Intelligent Computing, pages 74-85. Springer, 2024.

[23] 李永光、王胜胜、付子豪和尹子琪。基于提示引导的多原型对齐网络的少样本领域自适应。见《智能计算国际会议论文集》，第74 - 85页。施普林格(Springer)，2024年。

[24] Jian Liang, Dapeng Hu, and Jiashi Feng. Do we really need to access the source data? source hypothesis transfer for unsupervised domain adaptation. In International conference on machine learning, pages 6028- 6039. PMLR, 2020.

[24] 梁健、胡大鹏和冯嘉时。我们真的需要访问源数据吗？无监督领域自适应的源假设转移。见《国际机器学习会议论文集》，第6028 - 6039页。机器学习研究会议录(PMLR)，2020年。

[25] Mingsheng Long, Han Zhu, Jianmin Wang, and Michael I Jordan. Deep transfer learning with joint adaptation networks. In International conference on machine learning, pages 2208-2217. PMLR, 2017.

[25] 龙明盛、朱涵、王建民和迈克尔·I·乔丹(Michael I Jordan)。基于联合自适应网络的深度迁移学习。见《国际机器学习会议论文集》，第2208 - 2217页。机器学习研究会议录(PMLR)，2017年。

[26] Xiaoqiang Lu, Tengfei Gong, and Xiangtao Zheng. Mul-tisource compensation network for remote sensing cross-domain scene classification. IEEE Transactions on Geoscience and Remote Sensing, 58(4):2504-2515, 2019.

[26] 陆小强、龚腾飞和郑向涛。用于遥感跨领域场景分类的多源补偿网络。《电气与电子工程师协会地球科学与遥感汇刊》(IEEE Transactions on Geoscience and Remote Sensing)，58(4):2504 - 2515，2019年。

[27] Esam Othman, Yakoub Bazi, Farid Melgani, Haikel Alhichri, Naif Alajlan, and Mansour Zuair. Domain adaptation network for cross-scene classification. IEEE Transactions on Geoscience and Remote Sensing, 55(8): 4441-4456, 2017.

[27] 埃萨姆·奥斯曼(Esam Othman)、亚库布·巴齐(Yakoub Bazi)、法里德·梅尔加尼(Farid Melgani)、哈克尔·阿尔希克里(Haikel Alhichri)、奈夫·阿拉杰兰(Naif Alajlan)和曼苏尔·祖艾尔(Mansour Zuair)。用于跨场景分类的领域自适应网络。《电气与电子工程师协会地球科学与遥感汇刊》(IEEE Transactions on Geoscience and Remote Sensing)，55(8): 4441 - 4456，2017年。

[28] Xingchao Peng, Ben Usman, Neela Kaushik, Judy Hoffman, Dequan Wang, and Kate Saenko. Visda: The visual domain adaptation challenge. arXiv preprint

[28] 彭兴超、本·奥斯曼(Ben Usman)、妮拉·考希克(Neela Kaushik)、朱迪·霍夫曼(Judy Hoffman)、王德全和凯特·塞内科(Kate Saenko)。Visda:视觉领域自适应挑战。预印本

arXiv:1710.06924, 2017.

arXiv:1710.06924，2017年。

[29] Xingchao Peng, Qinxun Bai, Xide Xia, Zijun Huang, Kate Saenko, and Bo Wang. Moment matching for

[29] 彭兴超、白勤勋、夏西德、黄紫军、凯特·塞内科和王博。多源领域自适应的矩匹配

multi-source domain adaptation. In Proceedings of the IEEE/CVF international conference on computer vision, pages 1406-1415, 2019.

见《电气与电子工程师协会/计算机视觉基金会国际计算机视觉会议论文集》，第1406 - 1415页，2019年。

[30] Sanqing Qu, Guang Chen, Jing Zhang, Zhijun Li, Wei He, and Dacheng Tao. Bmd: A general class-balanced multicentric dynamic prototype strategy for source-free domain adaptation. In European conference on computer vision, pages 165-182. Springer, 2022.

[30] 曲三清、陈光、张静、李志军、何伟和陶大成。Bmd:一种用于无源领域自适应的通用类平衡多中心动态原型策略。见《欧洲计算机视觉会议论文集》，第165 - 182页。施普林格(Springer)，2022年。

[31] Alec Radford, Jong Wook Kim, Chris Hallacy, Aditya Ramesh, Gabriel Goh, Sandhini Agarwal, Girish Sastry, Amanda Askell, Pamela Mishkin, Jack Clark, et al. Learning transferable visual models from natural language supervision. In International conference on machine learning, pages 8748-8763. PMLR, 2021.

[31] 亚历克·拉德福德(Alec Radford)、金钟旭(Jong Wook Kim)、克里斯·哈拉西(Chris Hallacy)、阿迪蒂亚·拉梅什(Aditya Ramesh)、加布里埃尔·戈(Gabriel Goh)、桑迪尼·阿加瓦尔(Sandhini Agarwal)、吉里什·萨斯特里(Girish Sastry)、阿曼达·阿斯凯尔(Amanda Askell)、帕梅拉·米什金(Pamela Mishkin)、杰克·克拉克等。从自然语言监督中学习可迁移的视觉模型。见《国际机器学习会议论文集》，第8748 - 8763页。机器学习研究会议录(PMLR)，2021年。

[32] Kate Saenko, Brian Kulis, Mario Fritz, and Trevor Darrell. Adapting visual category models to new domains. In Computer Vision-ECCV 2010: 11th European Conference on Computer Vision, Heraklion, Crete, Greece, September 5-11, 2010, Proceedings, Part IV 11, pages 213-226. Springer, 2010.

[32] 凯特·塞内科、布莱恩·库利斯(Brian Kulis)、马里奥·弗里茨(Mario Fritz)和特雷弗·达雷尔(Trevor Darrell)。将视觉类别模型适配到新领域。见《计算机视觉 - 2010年第11届欧洲计算机视觉会议(ECCV 2010)，希腊克里特岛伊拉克利翁，2010年9月5 - 11日，会议录，第四部分11》，第213 - 226页。施普林格(Springer)，2010年。

[33] Kuniaki Saito, Donghyun Kim, Stan Sclaroff, Trevor Darrell, and Kate Saenko. Semi-supervised domain adaptation via minimax entropy. In Proceedings of the IEEE/CVF international conference on computer vision, pages 8050-8058, 2019.

[33] 斋藤邦明(Kuniaki Saito)、金东贤(Donghyun Kim)、斯坦·斯克拉罗夫(Stan Sclaroff)、特雷弗·达雷尔和凯特·塞内科。通过极小极大熵实现半监督领域自适应。见《电气与电子工程师协会/计算机视觉基金会国际计算机视觉会议论文集》，第8050 - 8058页，2019年。

[34] Sunandini Sanyal, Ashish Ramayee Asokan, Suvaansh Bhambri, Akshay Kulkarni, Jogendra Nath Kundu, and R Venkatesh Babu. Domain-specificity inducing transformers for source-free domain adaptation. In Proceedings of the IEEE/CVF International Conference on Computer Vision, pages 18928-18937, 2023.

[34] 苏南迪尼·桑亚尔(Sunandini Sanyal)、阿什什·拉马耶·阿索坎(Ashish Ramayee Asokan)、苏万什·班布里(Suvaansh Bhambri)、阿克沙伊·库尔卡尼(Akshay Kulkarni)、乔根德拉·纳特·昆杜(Jogendra Nath Kundu)和R·文卡特什·巴布(R Venkatesh Babu)。用于无源领域自适应的特定领域诱导变压器。见《电气与电子工程师协会/计算机视觉基金会国际计算机视觉会议论文集》，第18928 - 18937页，2023年。

[35] Mainak Singha, Harsh Pal, Ankit Jha, and Biplab Banerjee. Ad-clip: Adapting domains in prompt space using clip. In Proceedings of the IEEE/CVF International Conference on Computer Vision, pages 4355-4364, 2023.

[35] 梅纳克·辛哈(Mainak Singha)、哈什·帕尔(Harsh Pal)、安基特·贾(Ankit Jha)和比普拉布·班纳吉(Biplab Banerjee)。Ad-clip:使用CLIP在提示空间中进行领域自适应。见《电气与电子工程师协会/计算机视觉基金会国际计算机视觉会议论文集》，第4355 - 4364页，2023年。

[36] Christopher Small. Grand challenges in remote sensing image analysis and classification, 2021.

[36] 克里斯托弗·斯莫尔(Christopher Small)。遥感图像分析与分类的重大挑战，2021年。

[37] Kihyuk Sohn, David Berthelot, Nicholas Carlini, Zizhao Zhang, Han Zhang, Colin A Raffel, Ekin Dogus Cubuk, Alexey Kurakin, and Chun-Liang Li. Fixmatch: Simplifying semi-supervised learning with consistency and confidence. Advances in neural information processing systems, 33:596-608, 2020.

[37] 基赫尤克·孙(Kihyuk Sohn)、大卫·贝瑟洛(David Berthelot)、尼古拉斯·卡利尼(Nicholas Carlini)、子昭·张(Zizhao Zhang)、韩·张(Han Zhang)、科林·A·拉菲尔(Colin A Raffel)、埃金·多古斯·丘布克(Ekin Dogus Cubuk)、阿列克谢·库拉金(Alexey Kurakin)和春亮·李(Chun-Liang Li)。Fixmatch:通过一致性和置信度简化半监督学习。《神经信息处理系统进展》，33:596 - 608，2020年。

[38] Lin Song, Ruoyi Xue, Hang Wang, Hongbin Sun, Yixiao Ge, Ying Shan, et al. Meta-adapter: An online few-shot learner for vision-language model. Advances in Neural Information Processing Systems, 36:55361-55374, 2023.

[38] 宋林(Lin Song)、薛若仪(Ruoyi Xue)、王航(Hang Wang)、孙宏斌(Hongbin Sun)、葛一笑(Yixiao Ge)、单莹(Ying Shan)等。Meta-adapter:用于视觉 - 语言模型的在线少样本学习器。《神经信息处理系统进展》，36:55361 - 55374，2023年。

[39] Baochen Sun and Kate Saenko. Deep coral: Correlation alignment for deep domain adaptation. In Computer Vision-ECCV 2016 Workshops: Amsterdam, The Netherlands, October 8-10 and 15-16, 2016, Proceedings, Part III 14, pages 443-450. Springer, 2016.

[39] 孙宝晨(Baochen Sun)和凯特·萨内科(Kate Saenko)。Deep coral:深度领域自适应的相关性对齐。见《计算机视觉 - 欧洲计算机视觉会议2016研讨会:荷兰阿姆斯特丹，2016年10月8 - 10日和15 - 16日，会议论文集，第三部分14》，第443 - 450页。施普林格出版社，2016年。

[40] Song Tang, Yuji Shi, Zhiyuan Ma, Jian Li, Jianzhi Lyu, Qingdu Li, and Jianwei Zhang. Model adaptation through hypothesis transfer with gradual knowledge distillation.

[40] 唐松(Song Tang)、施宇吉(Yuji Shi)、马志远(Zhiyuan Ma)、李建(Jian Li)、吕建志(Jianzhi Lyu)、李青都(Qingdu Li)和张建伟(Jianwei Zhang)。通过假设转移和渐进式知识蒸馏进行模型自适应。

In 2021 IEEE/RSJ International Conference on Intelligent Robots and Systems (IROS), pages 5679-5685. IEEE, 2021.

见2021年电气与电子工程师协会/日本机器人协会国际智能机器人与系统会议(IROS)，第5679 - 5685页。电气与电子工程师协会，2021年。

[41] Song Tang, Yan Zou, Zihao Song, Jianzhi Lyu, Lijuan Chen, Mao Ye, Shouming Zhong, and Jianwei Zhang. Semantic consistency learning on manifold for source data-free unsupervised domain adaptation. Neural Networks, 152:467-478, 2022.

[41] 唐松(Song Tang)、邹燕(Yan Zou)、宋子豪(Zihao Song)、吕建志(Jianzhi Lyu)、陈丽娟(Lijuan Chen)、叶茂(Mao Ye)、钟守明(Shouming Zhong)和张建伟(Jianwei Zhang)。流形上的语义一致性学习用于无源数据的无监督领域自适应。《神经网络》，152:467 - 478，2022年。

[42] Song Tang, An Chang, Fabian Zhang, Xiatian Zhu, Mao Ye, and Changshui Zhang. Source-free domain adaptation via target prediction distribution searching. International journal of computer vision, 132(3):654- 672, 2024.

[42] 唐松(Song Tang)、安·张(An Chang)、法比安·张(Fabian Zhang)、朱夏天(Xiatian Zhu)、叶茂(Mao Ye)和张长水(Changshui Zhang)。通过目标预测分布搜索实现无源领域自适应。《国际计算机视觉杂志》，132(3):654 - 672，2024年。

[43] Jiayi Tian, Jing Zhang, Wen Li, and Dong Xu. Vdm-da: Virtual domain modeling for source data-free domain adaptation. IEEE Transactions on Circuits and Systems for Video Technology, 32(6):3749-3760, 2021.

[43] 田佳怡(Jiayi Tian)、张静(Jing Zhang)、李文(Wen Li)和徐东(Dong Xu)。Vdm - da:用于无源数据领域自适应的虚拟领域建模。《电气与电子工程师协会电路与系统视频技术汇刊》，32(6):3749 - 3760，2021年。

[44] Qing Tian, Yanan Zhu, Heyang Sun, Songcan Chen, and Hujun Yin. Unsupervised domain adaptation through dynamically aligning both the feature and label spaces. IEEE Transactions on Circuits and Systems for Video Technology, 32(12):8562-8573, 2022.

[44] 田青(Qing Tian)、朱亚男(Yanan Zhu)、孙鹤阳(Heyang Sun)、陈松灿(Songcan Chen)和尹虎军(Hujun Yin)。通过动态对齐特征和标签空间进行无监督领域自适应。《电气与电子工程师协会电路与系统视频技术汇刊》，32(12):8562 - 8573，2022年。

[45] Qing Tian, Heyang Sun, Shun Peng, Yuhui Zheng, Jun Wan, and Zhen Lei. Dcl: Dipolar confidence learning for source-free unsupervised domain adaptation. IEEE Transactions on Circuits and Systems for Video Technology, 2023.

[45] 田青(Qing Tian)、孙鹤阳(Heyang Sun)、彭顺(Shun Peng)、郑玉辉(Yuhui Zheng)、万军(Jun Wan)和雷振(Zhen Lei)。Dcl:用于无源无监督领域自适应的偶极置信度学习。《电气与电子工程师协会电路与系统视频技术汇刊》，2023年。

[46] Eric Tzeng, Judy Hoffman, Ning Zhang, Kate Saenko, and Trevor Darrell. Deep domain confusion: Maximizing for domain invariance. arXiv preprint arXiv:1412.3474, 2014.

[46] 埃里克·曾(Eric Tzeng)、朱迪·霍夫曼(Judy Hoffman)、张宁(Ning Zhang)、凯特·萨内科(Kate Saenko)和特雷弗·达雷尔(Trevor Darrell)。深度领域混淆:最大化领域不变性。预印本arXiv:1412.3474，2014年。

[47] Hemanth Venkateswara, Jose Eusebio, Shayok Chakraborty, and Sethuraman Panchanathan. Deep hashing network for unsupervised domain adaptation. In Proceedings of the IEEE conference on computer vision and pattern recognition, pages 5018-5027, 2017.

[47] 赫曼斯·文卡特斯瓦拉(Hemanth Venkateswara)、何塞·尤塞比奥(Jose Eusebio)、沙约克·查克拉博蒂(Shayok Chakraborty)和塞图拉曼·潘查纳坦(Sethuraman Panchanathan)。用于无监督领域自适应的深度哈希网络。见《电气与电子工程师协会计算机视觉与模式识别会议论文集》，第5018 - 5027页，2017年。

[48] Tongxin Wang, Zhengming Ding, Wei Shao, Haixu Tang, and Kun Huang. Towards fair cross-domain adaptation via generative learning. In Proceedings of the IEEE/CVF Winter Conference on Applications of Computer Vision, pages 454-463, 2021.

[48] 王童心(Tongxin Wang)、丁正明(Zhengming Ding)、邵伟(Wei Shao)、唐海旭(Haixu Tang)和黄坤(Kun Huang)。通过生成式学习实现公平的跨领域自适应。见《电气与电子工程师协会/计算机视觉基金会冬季计算机视觉应用会议论文集》，第454 - 463页，2021年。

[49] Wenhai Wang, Jifeng Dai, Zhe Chen, Zhenhang Huang, Zhiqi Li, Xizhou Zhu, Xiaowei Hu, Tong Lu, Lewei Lu, Hongsheng Li, et al. Internimage: Exploring large-scale vision foundation models with deformable convolutions. In Proceedings of the IEEE/CVF conference on computer vision and pattern recognition, pages 14408- 14419, 2023.

[49] 王文海(Wenhai Wang)、戴吉峰(Jifeng Dai)、陈哲(Zhe Chen)、黄振航(Zhenhang Huang)、李志奇(Zhiqi Li)、朱锡洲(Xizhou Zhu)、胡晓伟(Xiaowei Hu)、卢通(Tong Lu)、卢乐伟(Lewei Lu)、李洪生(Hongsheng Li)等。Internimage:使用可变形卷积探索大规模视觉基础模型。见《电气与电子工程师协会/计算机视觉基金会计算机视觉与模式识别会议论文集》，第14408 - 14419页，2023年。

[50] Gui-Song Xia, Jingwen Hu, Fan Hu, Baoguang Shi, Xi-ang Bai, Yanfei Zhong, Liangpei Zhang, and Xiaoqiang Lu. Aid: A benchmark data set for performance evaluation of aerial scene classification. IEEE Transactions on Geoscience and Remote Sensing, 55(7):3965-3981, 2017.

[50] 夏桂松、胡静文、胡凡、史宝光、白翔、钟燕飞、张良培和陆小强。Aid:用于航空场景分类性能评估的基准数据集。《IEEE地球科学与遥感汇刊》，55(7):3965 - 3981，2017年。

[51] Haifeng Xia, Handong Zhao, and Zhengming Ding. Adaptive adversarial network for source-free domain adaptation. In Proceedings of the IEEE/CVF international conference on computer vision, pages 9010-9019,

[51] 夏海峰、赵寒冬和丁正明。用于无源域自适应的自适应对抗网络。见《IEEE/CVF国际计算机视觉会议论文集》，第9010 - 9019页。

2021.

[52] Shiqi Yang, Yaxing Wang, Joost Van De Weijer, Luis Herranz, and Shangling Jui. Generalized source-free domain adaptation. In Proceedings of the IEEE/CVF international conference on computer vision, pages 8978- 8987, 2021.

[52] 杨世奇、王亚星、约斯特·范德韦杰尔、路易斯·埃兰斯和芮尚凌。广义无源域自适应。见《IEEE/CVF国际计算机视觉会议论文集》，第8978 - 8987页，2021年。

[53] Yi Yang and Shawn Newsam. Bag-of-visual-words and spatial extensions for land-use classification. In Proceedings of the 18th SIGSPATIAL international conference on advances in geographic information systems, pages 270- 279, 2010.

[53] 杨毅和肖恩·纽瑟姆。用于土地利用分类的视觉词袋模型及其空间扩展。见《第18届SIGSPATIAL地理信息系统进展国际会议论文集》，第270 - 279页，2010年。

[54] Xiangyu Yue, Zangwei Zheng, Shanghang Zhang, Yang Gao, Trevor Darrell, Kurt Keutzer, and Alberto San-giovanni Vincentelli. Prototypical cross-domain self-supervised learning for few-shot unsupervised domain adaptation. In Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition, pages 13834-13844, 2021.

[54] 岳翔宇、郑藏伟、张上航、高杨、特雷弗·达雷尔、库尔特·柯泽特和阿尔贝托·桑乔万尼 - 温琴泰利。用于少样本无监督域自适应的原型跨域自监督学习。见《IEEE/CVF计算机视觉与模式识别会议论文集》，第13834 - 13844页，2021年。

[55] Renrui Zhang, Wei Zhang, Rongyao Fang, Peng Gao, Kunchang Li, Jifeng Dai, Yu Qiao, and Hongsheng Li. Tip-adapter: Training-free adaption of clip for few-shot classification. In European conference on computer vision, pages 493-510. Springer, 2022.

[55] 张仁瑞、张伟、方荣耀、高鹏、李坤昌、戴继峰、乔宇和李宏生。Tip - 适配器:用于少样本分类的无训练CLIP自适应。见《欧洲计算机视觉会议》，第493 - 510页。施普林格出版社，2022年。

[56] Zhendong Zheng, Yanfei Zhong, Yu Su, and Ailong Ma. Domain adaptation via a task-specific classifier framework for remote sensing cross-scene classification. IEEE Transactions on Geoscience and Remote Sensing, 60:1-13, 2022.

[56] 郑振东、钟燕飞、苏宇和马爱龙。基于特定任务分类器框架的遥感跨场景分类域自适应。《IEEE地球科学与遥感汇刊》，60:1 - 13，2022年。

[57] Kaiyang Zhou, Jingkang Yang, Chen Change Loy, and Ziwei Liu. Learning to prompt for vision-language models. International Journal of Computer Vision, 130 (9):2337-2348, 2022.

[57] 周开阳、杨景康、罗智泉和刘子微。学习为视觉 - 语言模型设置提示。《国际计算机视觉杂志》，130(9):2337 - 2348，2022年。

[58] Lihua Zhou, Nianxin Li, Mao Ye, Xiatian Zhu, and Song Tang. Source-free domain adaptation with class prototype discovery. Pattern recognition, 145:109974, 2024.

[58] 周丽华、李念欣、叶茂、朱侠天和唐松。基于类原型发现的无源域自适应。《模式识别》，145:109974，2024年。

[59] Zhuofan Zong, Guanglu Song, and Yu Liu. Detrs with collaborative hybrid assignments training. In Proceedings of the IEEE/CVF international conference on computer vision, pages 6748-6758, 2023.

[59] 宗卓凡、宋光鲁和刘宇。采用协作混合分配训练的DETR模型。见《IEEE/CVF国际计算机视觉会议论文集》，第6748 - 6758页，2023年。