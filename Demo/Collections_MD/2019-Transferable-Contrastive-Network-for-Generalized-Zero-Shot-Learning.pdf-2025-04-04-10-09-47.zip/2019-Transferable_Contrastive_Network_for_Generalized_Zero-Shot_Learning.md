# Transferable Contrastive Network for Generalized Zero-Shot Learning

# 用于广义零样本学习的可迁移对比网络

Huajie Jiang ${}^{1,2,3,4}$ , Ruiping Wang ${}^{1,2}$ , Shiguang Shan ${}^{1,2}$ , Xilin Chen ${}^{1,2}$

蒋华杰 ${}^{1,2,3,4}$ ，王瑞平 ${}^{1,2}$ ，单世广 ${}^{1,2}$ ，陈熙霖 ${}^{1,2}$

${}^{1}$ Key Laboratory of Intelligent Information Processing of Chinese Academy of Sciences (CAS),

${}^{1}$ 中国科学院(CAS)智能信息处理重点实验室

Institute of Computing Technology, CAS, Beijing, 100190, China

中国科学院计算技术研究所，北京，100190，中国

${}^{2}$ University of Chinese Academy of Sciences, Beijing,100049, China

${}^{2}$ 中国科学院大学，北京，100049，中国

${}^{3}$ Shanghai Institute of Microsystem and Information Technology, CAS, Shanghai,200050, China

${}^{3}$ 中国科学院上海微系统与信息技术研究所，上海，200050，中国

${}^{4}$ School of Information Science and Technology, ShanghaiTech University, Shanghai,200031, China

${}^{4}$ 上海科技大学信息科学与技术学院，上海，200031，中国

huajie.jiang@vipl.ict.ac.cn, \{wangruiping, sgshan, xlchen\}@ict.ac.cn

huajie.jiang@vipl.ict.ac.cn, \{wangruiping, sgshan, xlchen\}@ict.ac.cn

## Abstract

## 摘要

Zero-shot learning (ZSL) is a challenging problem that aims to recognize the target categories without seen data, where semantic information is leveraged to transfer knowledge from some source classes. Although ZSL has made great progress in recent years, most existing approaches are easy to overfit the sources classes in generalized zero-shot learning (GZSL) task, which indicates that they learn little knowledge about target classes. To tackle such problem, we propose a novel Transferable Contrastive Network (TCN) that explicitly transfers knowledge from the source classes to the target classes. It automatically contrasts one image with different classes to judge whether they are consistent or not. By exploiting the class similarities to make knowledge transfer from source images to similar target classes, our approach is more robust to recognize the target images. Experiments on five benchmark datasets show the superiority of our approach for GZSL.

零样本学习(ZSL)是一个具有挑战性的问题，旨在识别没有见过数据的目标类别，其中利用语义信息从一些源类别中转移知识。尽管近年来ZSL取得了很大进展，但在广义零样本学习(GZSL)任务中，大多数现有方法容易对源类别过拟合，这表明它们对目标类别的知识学习甚少。为解决这一问题，我们提出了一种新颖的可迁移对比网络(TCN)，它能明确地将知识从源类别转移到目标类别。该网络自动将一张图像与不同类别进行对比，判断它们是否一致。通过利用类别相似性将知识从源图像转移到相似的目标类别，我们的方法在识别目标图像时更具鲁棒性。在五个基准数据集上的实验表明了我们的方法在GZSL中的优越性。

## 1. Introduction

## 1. 引言

Object recognition is one of the basic issues in computer vision. It has made great progress in recent years with the rapid development of deep learning approaches $\left\lbrack  {{18},{33},{30},{13}}\right\rbrack$ , where large numbers of labeled images are required, such as ImageNet [28]. However, collecting and annotating large numbers of images are difficult, especially for fine-grained categories in specific domains. Moreover, such supervised learning approaches can only recognize a fixed number of categories, which is not flexible. In contrast, humans can learn from only a few samples or even recognize unseen objects. Therefore, learning visual classifiers with no need of human annotation is becoming a hot topic in recent years.

目标识别是计算机视觉中的基本问题之一。近年来，随着深度学习方法的快速发展，目标识别取得了很大进展 $\left\lbrack  {{18},{33},{30},{13}}\right\rbrack$ ，这些方法需要大量带标签的图像，如ImageNet [28]。然而，收集和标注大量图像很困难，特别是对于特定领域的细粒度类别。此外，这种监督学习方法只能识别固定数量的类别，缺乏灵活性。相比之下，人类可以从少量样本中学习，甚至识别未见的目标。因此，无需人工标注来学习视觉分类器近年来成为一个热门话题。

Zero-shot learning (ZSL) aims to learn classifiers for the target categories where no labeled images are accessible. It is accomplished by transferring knowledge from the source categories with the help of semantic information. Semantic information can build up the relations among different classes thus to enable knowledge transfer from source classes to target classes. Currently the most widely used semantic information includes attributes $\left\lbrack  {{19},9}\right\rbrack$ and word vectors $\left\lbrack  {{10},2}\right\rbrack$ . Traditional ZSL approaches usually learn universal visual-semantic transformations among the source classes and then apply them to the target classes. In this way, the visual samples and class semantics can be projected into a common space, where zero-shot recognition is conducted by the nearest neighbor approach.

零样本学习(ZSL)旨在为没有可用带标签图像的目标类别学习分类器。它通过借助语义信息从源类别转移知识来实现。语义信息可以建立不同类别之间的关系，从而实现知识从源类别到目标类别的转移。目前最广泛使用的语义信息包括属性 $\left\lbrack  {{19},9}\right\rbrack$ 和词向量 $\left\lbrack  {{10},2}\right\rbrack$ 。传统的ZSL方法通常在源类别之间学习通用的视觉 - 语义转换，然后将其应用于目标类别。通过这种方式，视觉样本和类别语义可以投影到一个公共空间，在该空间中通过最近邻方法进行零样本识别。

![0195e075-8ad2-7476-aec8-0bc1863e2100_0_914_792_683_374_0.jpg](images/0195e075-8ad2-7476-aec8-0bc1863e2100_0_914_792_683_374_0.jpg)

Figure 1. Illustration diagram that shows the motivations of transferable contrastive learning. The training images should not only match their class semantics (discriminative property) but also have relatively high contrastive values with similar target classes (transfer property). 'D' represents discriminative learning and 'T' represents transfer learning.

图1. 展示可迁移对比学习动机的示意图。训练图像不仅应与其类别语义匹配(判别属性)，还应与相似的目标类别具有相对较高的对比值(迁移属性)。'D' 表示判别学习，'T' 表示迁移学习。

Although ZSL has made great progress in recent years, the strong assumption that the test images only come from the target classes is not realistic for practical applications. Therefore, generalized zero-shot learning (GZSL) [6, 39] draws much attention recently, where test samples may come from either source or target classes. However, most existing ZSL approaches perform badly on GZSL task because they are easy to overfit the source classes, which indicates that they learn little knowledge about the target classes. These approaches learn the models only on the source categories and ignore the targets. Since the domain shift problem exists [11], the models learned on the source classes may not be suitable to the target classes, which results in overfitting the source categories in the GZSL task.

尽管近年来ZSL取得了很大进展，但测试图像仅来自目标类别的强假设在实际应用中并不现实。因此，广义零样本学习(GZSL) [6, 39] 最近受到了广泛关注，其中测试样本可能来自源类别或目标类别。然而，大多数现有的ZSL方法在GZSL任务中表现不佳，因为它们容易对源类别过拟合，这表明它们对目标类别的知识学习甚少。这些方法仅在源类别上学习模型，而忽略了目标类别。由于存在领域偏移问题 [11]，在源类别上学习的模型可能不适用于目标类别，从而导致在GZSL任务中对源类别过拟合。

In order to tackle such problem, we propose to explicitly transfer the knowledge from the source classes to the target categories. The key problem for ZSL is that no labeled images are available for the target categories so we could not directly train the target image classifiers. An intuitive idea is to learn target classifiers from similar source images. For example, we could leverage the source images 'horse' to learn the target class 'zebra'. Based on this idea, we propose a novel transferable contrastive network for generalized zero-shot learning. It automatically contrasts the images with class semantics to judge whether they are consistent or not. Figure 1 shows the motivations of our approach, where two key properties for ZSL are considered in the contrastive learning process: discriminative property and transferable property. We maximize the contrastive values of images with corresponding class semantics and minimize the inconsistent ones among source classes thus to ensure that our model is discriminative enough to recognize different classes. Furthermore, to make the contrast transferable to the target classes, we utilize the class similarities to transfer knowledge from the source-class images to similar target classes. In this way, the model will be more robust to the target categories though no labeled target images are available to learn the model.

为了解决此类问题，我们提议将知识从源类别(source classes)明确地迁移到目标类别(target categories)。零样本学习(ZSL)的关键问题在于目标类别没有可用的带标签图像，因此我们无法直接训练目标图像分类器。一个直观的想法是从相似的源图像中学习目标分类器。例如，我们可以利用源图像“马”来学习目标类别“斑马”。基于这一想法，我们为广义零样本学习提出了一种新颖的可迁移对比网络。它自动将图像与类别语义进行对比，以判断它们是否一致。图1展示了我们方法的动机，在对比学习过程中考虑了零样本学习的两个关键属性:判别性和可迁移性。我们最大化图像与相应类别语义的对比值，并最小化源类别中不一致的对比值，从而确保我们的模型有足够的判别能力来识别不同的类别。此外，为了使对比能够迁移到目标类别，我们利用类别相似性将知识从源类别图像迁移到相似的目标类别。通过这种方式，尽管没有带标签的目标图像来学习模型，但模型对目标类别将更具鲁棒性。

The main contributions of this paper are in two aspects. First, we propose a novel transferable contrastive network for GZSL, where a new network structure is designed for contrastive learning. Second, we consider both the discriminative property and transferable property in the contrastive learning procedure, where the discriminative property ensures to effectively discriminate different classes and the transferable property guarantees the robustness to the target classes. Experiments on five benchmark datasets show the superiority of the proposed approach.

本文的主要贡献体现在两个方面。首先，我们为广义零样本学习(GZSL)提出了一种新颖的可迁移对比网络，其中设计了一种新的网络结构用于对比学习。其次，我们在对比学习过程中同时考虑了判别性和可迁移性，其中判别性确保能够有效区分不同的类别，而可迁移性保证了对目标类别的鲁棒性。在五个基准数据集上的实验表明了所提出方法的优越性。

## 2. Related Work

## 2. 相关工作

### 2.1. Semantic Information

### 2.1. 语义信息

Semantic information is the key to ZSL. It builds up the relations between the source and target classes thus to enable knowledge transfer. Recently, the most widely used semantic information in ZSL is attributes [19, 9] and word vectors [22]. Attributes are general descriptions of objects. They are accurate but need human experts for definition and annotation. Word vectors are automatically learned from large numbers of text corpus which reduces human labor. However, there is much noise in the texts, which restricts their performance. In this paper, we use the attributes as the semantic information since they are more accurate to bridge the source and target classes.

语义信息是零样本学习的关键。它建立了源类别和目标类别之间的关系，从而实现知识迁移。最近，零样本学习中最广泛使用的语义信息是属性 [19, 9] 和词向量 [22]。属性是对对象的一般性描述。它们很准确，但需要人类专家进行定义和标注。词向量是从大量文本语料库中自动学习得到的，这减少了人力劳动。然而，文本中存在大量噪声，这限制了它们的性能。在本文中，我们使用属性作为语义信息，因为它们在连接源类别和目标类别方面更准确。

### 2.2. Visual-Semantic Transformations

### 2.2. 视觉 - 语义转换

Visual-semantic transformations establish relationships between the visual space and the semantic space. According to different projection directions, current ZSL approaches can be grouped into three types: visual to semantic embed-dings, semantic to visual embeddings, latent space embed-dings. We will introduce them in detail below.

视觉 - 语义转换在视觉空间和语义空间之间建立关系。根据不同的投影方向，当前的零样本学习方法可以分为三类:视觉到语义嵌入、语义到视觉嵌入、潜在空间嵌入。我们将在下面详细介绍它们。

Visual to semantic embeddings. These approaches learn the transformations from the visual space to the semantic space and perform image recognition in the semantic space. In the early age of ZSL, $\left\lbrack  {{19},9}\right\rbrack$ propose to learn attribute classifiers to transfer knowledge from the source to the target classes. They train each attribute classifier independently, which is time-consuming. To tackle such problem, $\left\lbrack  {1,2}\right\rbrack$ consider all attributes as a whole and learn label embedding functions to maximize the compatibilities between images and corresponding class semantics. Furthermore, [24] proposes to synthesize the semantic representations of test images by a convex combination of source-class semantics using the probability outputs of source classifiers. To learn more robust transformations, [23] proposes a deep neural network to combine attribute classifier learning and semantic label embedding.

视觉到语义嵌入。这些方法学习从视觉空间到语义空间的转换，并在语义空间中进行图像识别。在零样本学习的早期，$\left\lbrack  {{19},9}\right\rbrack$ 提议学习属性分类器，以将知识从源类别迁移到目标类别。他们独立训练每个属性分类器，这很耗时。为了解决这个问题，$\left\lbrack  {1,2}\right\rbrack$ 将所有属性视为一个整体，并学习标签嵌入函数，以最大化图像与相应类别语义之间的兼容性。此外，[24] 提议使用源分类器的概率输出，通过源类别语义的凸组合来合成测试图像的语义表示。为了学习更鲁棒的转换，[23] 提出了一种深度神经网络，将属性分类器学习和语义标签嵌入相结合。

Semantic to visual embeddings. These approaches learn the transformations from semantic space to the visual space and perform image recognition in the visual space, which can effectively tackle the hubness problem in ZSL $\left\lbrack  {8,{29}}\right\rbrack  .\left\lbrack  {5,{21},{40}}\right\rbrack$ predict the visual samplers by learning embedding functions from the semantic space to the visual space. [27] adds some regularizers to learn the embedding function from class semantic to corresponding visual classifiers and [35] utilizes knowledge graphs to learn the same embedding functions. Some other works directly synthesize the target-class classifiers [4] or learn the target-class prototypes [14] in the visual space by utilizing the class structure information. $\left\lbrack  {{17},7}\right\rbrack$ exploit the auto-encoder framework to learn both the semantic to visual and visual to semantic em-beddings simultaneously. Inspired by the generative adversarial networks, [38] generates the target-class samples in the feature space and directly learns the target classifiers.

语义到视觉嵌入。这些方法学习从语义空间到视觉空间的转换，并在视觉空间中进行图像识别，这可以有效解决零样本学习中的中心性问题。$\left\lbrack  {8,{29}}\right\rbrack  .\left\lbrack  {5,{21},{40}}\right\rbrack$ 通过学习从语义空间到视觉空间的嵌入函数来预测视觉样本。[27] 添加了一些正则化项，以学习从类别语义到相应视觉分类器的嵌入函数，[35] 利用知识图谱来学习相同的嵌入函数。其他一些工作通过利用类别结构信息，直接在视觉空间中合成目标类别分类器 [4] 或学习目标类别原型 [14]。$\left\lbrack  {{17},7}\right\rbrack$ 利用自编码器框架同时学习语义到视觉和视觉到语义的嵌入。受生成对抗网络的启发，[38] 在特征空间中生成目标类别样本，并直接学习目标分类器。

Latent space embedding. These approaches encode the visual space and semantic space into a latent space for more effective image recognition. Since the predefined semantic information may be not discriminative enough to classify different classes, $\left\lbrack  {{41},{42}}\right\rbrack$ propose to use class similarities as the embedding space and [16] proposes discriminative latent attributes for zero-shot recognition. Moreover, [3] exploits metric learning techniques, where relative distance is utilized, to improve the embedding models. In order to learn robust visual-semantic transformations, $\left\lbrack  {{10},{31},{26},{23}}\right\rbrack$ utilize deep neural networks to project the visual space and the semantic space into a common latent space and align the representations of the same class.

潜在空间嵌入。这些方法将视觉空间和语义空间编码到一个潜在空间中，以实现更有效的图像识别。由于预定义的语义信息可能不足以区分不同的类别，$\left\lbrack  {{41},{42}}\right\rbrack$ 建议使用类别相似度作为嵌入空间，文献 [16] 提出了用于零样本识别的判别性潜在属性。此外，文献 [3] 利用度量学习技术(其中使用了相对距离)来改进嵌入模型。为了学习鲁棒的视觉 - 语义转换，$\left\lbrack  {{10},{31},{26},{23}}\right\rbrack$ 利用深度神经网络将视觉空间和语义空间投影到一个共同的潜在空间中，并对齐同一类别的表示。

Our approach belongs to the latent space embedding, but there is a little difference. Traditional methods aim to minimize the distance of images and corresponding class semantics in the latent space for image recognition, while our approach fuses their information for contrastive learning.

我们的方法属于潜在空间嵌入方法，但存在一些差异。传统方法旨在最小化潜在空间中图像与相应类别语义之间的距离以进行图像识别，而我们的方法融合了它们的信息进行对比学习。

### 2.3. Zero-Shot Recognition

### 2.3. 零样本识别

Zero-shot recognition is the last step for ZSL, most of which can be grouped into two categories. The distance-based approaches usually exploit the nearest neighbour approach to recognize the target-class samples $\left\lbrack  {1,{12},{41},{16}}\right\rbrack$ and the classifier-based approaches directly learn the visual classifiers to recognize the target-class images [4, 38]. Our approach utilizes contrastive values for image recognition.

零样本识别是零样本学习(ZSL)的最后一步，其中大多数方法可以分为两类。基于距离的方法通常利用最近邻方法来识别目标类样本 $\left\lbrack  {1,{12},{41},{16}}\right\rbrack$，而基于分类器的方法则直接学习视觉分类器来识别目标类图像 [4, 38]。我们的方法利用对比值进行图像识别。

### 2.4. Discussions about Relevant Works

### 2.4. 相关工作讨论

Most existing approaches ignore the target classes when learning the recognition model, so they are prone to overfit-ting the source classes in GZSL task. To tackle this problem, $\left\lbrack  {{38},{43}}\right\rbrack$ leverage the semantic information of target classes to generate image features for training target classifiers. Although satisfactory performance has been achieved, it is difficult to train and use the generative models. While our approach is easy to learn. Moreover, it is complementary to such generative approaches. [20] proposes a calibration network that calibrates the confidence of source classes and uncertainty of target classes. Different from it, we directly transfer knowledge to the target classes, which is more effective for GZSL. [11] uses all the unlabeled target images to adjust the models in transductive ZSL settings. However, these images are often unavailable in practical conditions, so we perform the inductive ZSL task. [15] proposes adaptive metric learning to make the model suitable for the target classes. However, the linear model restricts its performance. Another relevant work is [32], which also studies the relations between images and class semantics. Compared with [32], we design a novel network structure for TCN. Moreover, we explicitly transfer knowledge from the source images to similar target classes, which makes our model more robust to the target categories.

大多数现有方法在学习识别模型时忽略了目标类别，因此在广义零样本学习(GZSL)任务中容易对源类别过拟合。为了解决这个问题，$\left\lbrack  {{38},{43}}\right\rbrack$ 利用目标类别的语义信息生成图像特征来训练目标分类器。虽然取得了令人满意的性能，但训练和使用生成模型很困难。而我们的方法易于学习。此外，它与这种生成方法是互补的。文献 [20] 提出了一个校准网络，用于校准源类别的置信度和目标类别的不确定性。与它不同的是，我们直接将知识转移到目标类别，这对 GZSL 更有效。文献 [11] 在直推式零样本学习设置中使用所有未标记的目标图像来调整模型。然而，这些图像在实际条件下通常不可用，因此我们执行归纳式零样本学习任务。文献 [15] 提出了自适应度量学习，使模型适用于目标类别。然而，线性模型限制了其性能。另一项相关工作是文献 [32]，它也研究了图像和类别语义之间的关系。与文献 [32] 相比，我们为可迁移对比网络(TCN)设计了一种新颖的网络结构。此外，我们明确地将知识从源图像转移到相似的目标类别，这使得我们的模型对目标类别更鲁棒。

## 3. Approach

## 3. 方法

The objective of our approach is learning how to contrast the image with the class semantics. Figure 2 shows the general framework of the proposed transferable contrastive network (TCN). It contains two parts: information fusion and contrastive learning. Instead of computing the distance between images and class semantics using fixed metric for recognition, we fuse their information and learn a metric that automatically judges whether the fusions are consisten-t or not, where high contrastive values should be obtained between images and corresponding class semantics. In order to make the contrastive mechanism suitable to the target classes, we explicitly transfer knowledge from source images to similar target classes since no target images are available for training. More details will be described below.

我们方法的目标是学习如何将图像与类别语义进行对比。图 2 展示了所提出的可迁移对比网络(TCN)的总体框架。它包含两个部分:信息融合和对比学习。我们不是使用固定度量来计算图像和类别语义之间的距离进行识别，而是融合它们的信息并学习一种度量，该度量自动判断融合是否一致，其中图像与相应类别语义之间应获得高对比值。为了使对比机制适用于目标类别，由于没有目标图像可用于训练，我们明确地将知识从源图像转移到相似的目标类别。下面将详细描述更多细节。

### 3.1. Problem Settings

### 3.1. 问题设置

In zero-shot learning, we are given $K$ source classes (denoted as ${\mathcal{Y}}^{s}$ ) and $L$ target classes (denoted as ${\mathcal{Y}}^{t}$ ), where the source and target classes are disjoint, i.e. ${\mathcal{Y}}^{s} \cap  {\mathcal{Y}}^{t} = \varnothing$ . We use the index $\{ 1,\ldots , K\}$ to represent the source classes and $\{ K + 1,\ldots , K + L\}$ to represent the target classes. The source classes contain $N$ labeled images $\mathcal{D} =$ ${\left\{  \left( {\mathbf{x}}_{i},{y}_{i}\right)  \mid  {\mathbf{x}}_{i} \in  \mathcal{X},{y}_{i} \in  {\mathcal{Y}}^{s}\right\}  }_{i = 1}^{N}$ , while no labeled images are available for the target classes. $\mathcal{X}$ represents the visual sample space. To build up the relations between the source and target classes, semantic information $\mathcal{A} = {\left\{  {\mathbf{a}}_{c}\right\}  }_{c = 1}^{K + L}$ is provided for each class $c \in  {\mathcal{Y}}^{s} \cup  {\mathcal{Y}}^{t}$ . The goal of ZSL is to learn visual classifiers of target classes ${f}_{zsl} : \mathcal{X} \rightarrow  {\mathcal{Y}}^{t}$ and the goal of GZSL is to learn more general visual classifiers of all classes ${f}_{gzsl} : \mathcal{X} \rightarrow  {\mathcal{Y}}^{s} \cup  {\mathcal{Y}}^{t}$ .

在零样本学习中，我们有 $K$ 个源类别(表示为 ${\mathcal{Y}}^{s}$ )和 $L$ 个目标类别(表示为 ${\mathcal{Y}}^{t}$ )，其中源类别和目标类别是不相交的，即 ${\mathcal{Y}}^{s} \cap  {\mathcal{Y}}^{t} = \varnothing$ 。我们使用索引 $\{ 1,\ldots , K\}$ 来表示源类别，使用 $\{ K + 1,\ldots , K + L\}$ 来表示目标类别。源类别包含 $N$ 个带标签的图像 $\mathcal{D} =$ ${\left\{  \left( {\mathbf{x}}_{i},{y}_{i}\right)  \mid  {\mathbf{x}}_{i} \in  \mathcal{X},{y}_{i} \in  {\mathcal{Y}}^{s}\right\}  }_{i = 1}^{N}$ ，而目标类别没有可用的带标签图像。 $\mathcal{X}$ 表示视觉样本空间。为了建立源类别和目标类别之间的关系，为每个类别 $c \in  {\mathcal{Y}}^{s} \cup  {\mathcal{Y}}^{t}$ 提供了语义信息 $\mathcal{A} = {\left\{  {\mathbf{a}}_{c}\right\}  }_{c = 1}^{K + L}$ 。零样本学习(ZSL)的目标是学习目标类别的视觉分类器 ${f}_{zsl} : \mathcal{X} \rightarrow  {\mathcal{Y}}^{t}$ ，而广义零样本学习(GZSL)的目标是学习所有类别的更通用的视觉分类器 ${f}_{gzsl} : \mathcal{X} \rightarrow  {\mathcal{Y}}^{s} \cup  {\mathcal{Y}}^{t}$ 。

### 3.2. Contrastive Network

### 3.2. 对比网络

Information Fusion. An intuitive way of contrasting an image with one class is to fuse their information and judge how consistent the fusion is. Therefore, we first encode the images and class semantics into the same latent feature space to fuse their information. As is shown in Figure 2, we use two branches of neural network to encode the image and the class semantics into the same feature space respectively, where convolutional neural network (CNN) is utilized to encode the images and the multilayer perceptrons (MLP) is utilized to encode the class semantic information (attributes or word vectors). Then an element-wise product operation $\left( \otimes \right)$ is exploited to fuse the information from these two domains. Let $f\left( {\mathbf{x}}_{i}\right)$ denote the coding feature of the $i$ th image and $g\left( {\mathbf{a}}_{j}\right)$ represent the coding feature of the $j$ th class semantic, we can get the fused feature ${\mathbf{z}}_{ij}$ as:

信息融合。将图像与一个类别进行对比的一种直观方法是融合它们的信息，并判断这种融合的一致性程度。因此，我们首先将图像和类别语义编码到相同的潜在特征空间中，以融合它们的信息。如图2所示，我们使用神经网络的两个分支分别将图像和类别语义编码到相同的特征空间中，其中卷积神经网络(CNN)用于对图像进行编码，多层感知机(MLP)用于对类别语义信息(属性或词向量)进行编码。然后，利用逐元素相乘运算 $\left( \otimes \right)$ 来融合来自这两个领域的信息。设 $f\left( {\mathbf{x}}_{i}\right)$ 表示第 $i$ 张图像的编码特征， $g\left( {\mathbf{a}}_{j}\right)$ 表示第 $j$ 个类别语义的编码特征，我们可以得到融合后的特征 ${\mathbf{z}}_{ij}$ 如下:

$$
{\mathbf{z}}_{ij} = f\left( {\mathbf{x}}_{i}\right)  \otimes  g\left( {\mathbf{a}}_{j}\right)  \tag{1}
$$

where ${\mathbf{a}}_{j}$ is the class semantic of the $j$ th class. Then we can feed ${\mathbf{z}}_{ij}$ to the next stage to judge how well the image $i$ is consistent with class $j$ .

其中 ${\mathbf{a}}_{j}$ 是第 $j$ 个类别的类别语义。然后，我们可以将 ${\mathbf{z}}_{ij}$ 输入到下一阶段，以判断图像 $i$ 与类别 $j$ 的一致性程度。

Contrastive Learning. Different from previous approaches that use fixed distance, such as Euclidean distance or cosine distance, to compute the similarities between images and classes for image recognition, we design a contrastive network that automatically judges how well the image is consistent with a specific class. Let ${v}_{ij}$ denote the contrastive value between image $i$ and class $j$ , we can obtain it from the fused feature ${\mathbf{z}}_{ij}$ as:

对比学习。与之前使用固定距离(如欧几里得距离或余弦距离)来计算图像和类别之间的相似度以进行图像识别的方法不同，我们设计了一个对比网络，该网络可以自动判断图像与特定类别的一致性程度。设 ${v}_{ij}$ 表示图像 $i$ 与类别 $j$ 之间的对比值，我们可以从融合后的特征 ${\mathbf{z}}_{ij}$ 中得到它，如下所示:

$$
{v}_{ij} = h\left( {z}_{ij}\right)  \tag{2}
$$

![0195e075-8ad2-7476-aec8-0bc1863e2100_3_184_213_1405_513_0.jpg](images/0195e075-8ad2-7476-aec8-0bc1863e2100_3_184_213_1405_513_0.jpg)

Figure 2. The framework of transferable contrastive network. The information fusion module merges the image information with the class semantic information. The contrastive learning module automatically judges whether the fusion is consistent or not. " $\bigotimes$ denotes the element-wise product operation.

图2. 可迁移对比网络的框架。信息融合模块将图像信息与类别语义信息进行合并。对比学习模块自动判断这种融合是否一致。“ $\bigotimes$ 表示逐元素相乘运算。

where $h$ is the contrastive learning function.

其中 $h$ 是对比学习函数。

In the contrastive learning phase, we should consider two characters: discriminative property and transferable property. Discriminative property indicates that the contrastive model should be discriminative enough to classify differen-t classes. Transferable property means that the contrastive model should be generalized to the target classes.

在对比学习阶段，我们应该考虑两个特性:判别性和可迁移性。判别性表明对比模型应该具有足够的判别能力，以对不同的类别进行分类。可迁移性意味着对比模型应该能够推广到目标类别。

In order to enable the discriminative property, we utilize the semantic information of source classes as supervision, where the contrastive values of consistent fusions are maximized and those of inconsistent ones are minimized. The loss function can be formulated by the cross-entropy loss:

为了实现判别特性，我们利用源类别(source classes)的语义信息作为监督，在此过程中，一致融合的对比值被最大化，而不一致融合的对比值被最小化。损失函数可以通过交叉熵损失来表示:

$$
{\mathcal{L}}_{D} =  - \mathop{\sum }\limits_{{i = 1}}^{N}\mathop{\sum }\limits_{{j = 1}}^{K}{m}_{ij}\log {v}_{ij} + \left( {1 - {m}_{ij}}\right) \log \left( {1 - {v}_{ij}}\right)  \tag{3}
$$

where ${m}_{ij}$ is a class indicator. Let ${y}_{i}$ be the class label for the $i$ th image, then ${m}_{ij}$ can be obtained by:

其中 ${m}_{ij}$ 是一个类别指示符。设 ${y}_{i}$ 为第 $i$ 张图像的类别标签，那么 ${m}_{ij}$ 可以通过以下方式获得:

$$
{m}_{ij} = \left\{  \begin{array}{ll} 1, & {y}_{i} = j \\  0, & {y}_{i} \neq  j \end{array}\right.  \tag{4}
$$

The goal of ZSL is to recognize the target classes. If we only use the source classes in the contrastive learning phase, it is easy to overfit and the model would be less transferable to the target classes. This is the problem that exist-s in most ZSL approaches. Unfortunately, we don't have labeled target images to take part in the contrastive learning process. To tackle such problem, we explicitly transfer knowledge from source images to the target classes by class similarities. In other words, the source images could also be utilized to learn similar target classes. Let ${s}_{kj}$ denote the similarity of source class $k\left( {\mathrm{k} = 1,\ldots ,\mathrm{K}}\right)$ to target class $j$ $\left( {\mathrm{j} = \mathrm{K} + 1,\ldots ,\mathrm{K} + \mathrm{L}}\right)$ and then the loss function for transferable property is formulated as:

零样本学习(ZSL)的目标是识别目标类别(target classes)。如果我们在对比学习阶段仅使用源类别，模型很容易过拟合，并且对目标类别的迁移能力会降低。这是大多数零样本学习方法中存在的问题。不幸的是，我们没有带标签的目标图像来参与对比学习过程。为了解决这个问题，我们通过类别相似度(class similarities)将知识从源图像(source images)明确地迁移到目标类别。换句话说，源图像也可以用于学习相似的目标类别。设 ${s}_{kj}$ 表示源类别 $k\left( {\mathrm{k} = 1,\ldots ,\mathrm{K}}\right)$ 与目标类别 $j$ $\left( {\mathrm{j} = \mathrm{K} + 1,\ldots ,\mathrm{K} + \mathrm{L}}\right)$ 的相似度，那么可迁移特性的损失函数可以表示为:

$$
{\mathcal{L}}_{T} =  - \mathop{\sum }\limits_{{i = 1}}^{N}\mathop{\sum }\limits_{{j = K + 1}}^{{K + L}}{s}_{{y}_{i}j}\log {v}_{ij} + \left( {1 - {s}_{{y}_{i}j}}\right) \log \left( {1 - {v}_{ij}}\right)
$$

(5)

To summarize, our full loss function is:

综上所述，我们的完整损失函数为:

$$
\mathcal{L} = {\mathcal{L}}_{D} + \alpha {\mathcal{L}}_{T} \tag{6}
$$

where $\alpha$ is a parameter that controls the relative importance of discriminative property and transferable property.

其中 $\alpha$ 是一个控制判别特性和可迁移特性相对重要性的参数。

### 3.3. Class Similarity

### 3.3. 类别相似度

In order to accomplish the contrastive learning approach proposed above, the similarities between the source and target classes should be obtained. Inspired by the sparse coding approach, we utilize the target classes to reconstruct a source class and the reconstruction coefficients are viewed as the similarity of the source class to the target classes. The objective function is:

为了实现上述提出的对比学习方法，需要获得源类别和目标类别之间的相似度。受稀疏编码方法的启发，我们利用目标类别来重构源类别，并将重构系数视为源类别与目标类别的相似度。目标函数为:

$$
{\mathbf{s}}_{k} = \arg \mathop{\min }\limits_{{\mathbf{s}}_{k}}{\begin{Vmatrix}{\mathbf{a}}_{k} - \mathop{\sum }\limits_{{j = K + 1}}^{{K + L}}{\mathbf{a}}_{j}{s}_{kj}\end{Vmatrix}}_{2}^{2} + \beta {\begin{Vmatrix}{\mathbf{s}}_{k}\end{Vmatrix}}_{2} \tag{7}
$$

where ${\mathbf{a}}_{k}$ is the semantic information of class $k$ and ${s}_{kj}$ is the $j$ th element of ${\mathbf{s}}_{k}$ , which denotes the similarities of source class $k$ to target class $j.\beta$ is the regularization parameter. Then we normalize the similarity by

其中 ${\mathbf{a}}_{k}$ 是类别 $k$ 的语义信息，${s}_{kj}$ 是 ${\mathbf{s}}_{k}$ 的第 $j$ 个元素，它表示源类别 $k$ 与目标类别 $j.\beta$ 的相似度，是正则化参数。然后我们通过以下方式对相似度进行归一化:

$$
{s}_{kj} = \frac{{s}_{kj}}{\mathop{\sum }\limits_{{j = K + 1}}^{{K + L}}{s}_{kj}} \tag{8}
$$

<table><tr><td>Dataset</td><td>Img</td><td>Attr</td><td>Source</td><td>Target</td></tr><tr><td>$\mathbf{{APY}\left\lbrack  9\right\rbrack  }$</td><td>15,339</td><td>64</td><td>${15} + 5$</td><td>12</td></tr><tr><td>AWA1 [19]</td><td>30,475</td><td>85</td><td>${27} + {13}$</td><td>10</td></tr><tr><td>AWA2 [37]</td><td>37,322</td><td>85</td><td>${27} + {13}$</td><td>10</td></tr><tr><td>CUB [34]</td><td>11,788</td><td>312</td><td>100 + 50</td><td>50</td></tr><tr><td>SUN [25]</td><td>14,340</td><td>102</td><td>580 + 65</td><td>72</td></tr></table>

<table><tbody><tr><td>数据集</td><td>图像</td><td>属性</td><td>源</td><td>目标</td></tr><tr><td>$\mathbf{{APY}\left\lbrack  9\right\rbrack  }$</td><td>15,339</td><td>64</td><td>${15} + 5$</td><td>12</td></tr><tr><td>AWA1 [19]</td><td>30,475</td><td>85</td><td>${27} + {13}$</td><td>10</td></tr><tr><td>AWA2 [37]</td><td>37,322</td><td>85</td><td>${27} + {13}$</td><td>10</td></tr><tr><td>CUB [34]</td><td>11,788</td><td>312</td><td>100 + 50</td><td>50</td></tr><tr><td>SUN [25]</td><td>14,340</td><td>102</td><td>580 + 65</td><td>72</td></tr></tbody></table>

Table 1. Statistics for attribute datasets: APY, AWA1, AWA2, CUB and SUN in terms of image numbers (Img), attribute numbers (Attr), training + validation source class numbers (Source) and target class numbers (Target).

表1. 属性数据集的统计信息:APY、AWA1、AWA2、CUB和SUN，包括图像数量(Img)、属性数量(Attr)、训练+验证源类别数量(Source)和目标类别数量(Target)。

### 3.4. Zero-Shot Recognition

### 3.4. 零样本识别

We conduct zero-shot recognition by comparing the contrastive values of one image with all the class semantics.

我们通过将一张图像的对比值与所有类别语义进行比较来进行零样本识别。

For ZSL, we classify one image to the class which has the largest contrastive value among target classes, which can be formulated as:

对于零样本学习(ZSL)，我们将一张图像分类到目标类别中对比值最大的类别，其公式可以表示为:

$$
{P}_{zsl}\left( {x}_{i}\right)  = \mathop{\max }\limits_{j}{\left\{  {v}_{ij}\right\}  }_{j = K + 1}^{K + L} \tag{9}
$$

For GZSL, we classify one image to the class which has the largest contrastive value among all classes, which can be formulated as:

对于广义零样本学习(GZSL)，我们将一张图像分类到所有类别中对比值最大的类别，其公式可以表示为:

$$
{P}_{\text{gzsl }}\left( {x}_{i}\right)  = \mathop{\max }\limits_{j}{\left\{  {v}_{ij}\right\}  }_{j = 1}^{K + L} \tag{10}
$$

## 4. Experiment

## 4. 实验

### 4.1. Datasets and Settings

### 4.1. 数据集和设置

We conduct experiments on five widely used ZSL datasets: APY [9], AWA (2 versions AWA1 [19] and AWA2 [37]), CUB [34], SUN [25]. APY is a small-scale coarse-grained dataset with 64 attributes, which contains 20 object classes of aPascal and 12 object classes of aYahoo. AWA1 is a medium-scale animal dataset which contains 50 animal classes with 85 attributes annotated. AWA2 is collected by [37], which has the same classes as AWA1. CUB is a fine-grained and medium-scale dataset, which contains 200 different types of birds annotated with 312 attributes. SUN is a medium-scale dataset containing 717 types of scenes where 102 attributes are annotated. In order to make fair comparisons with other approaches, we conduct our experiment on the more reasonable pure ZSL settings recently proposed by [37]. The details of each dataset and class splits for source and target classes are shown in Table 1.

我们在五个广泛使用的零样本学习数据集上进行实验:APY [9]、AWA(两个版本AWA1 [19]和AWA2 [37])、CUB [34]、SUN [25]。APY是一个小规模的粗粒度数据集，有64个属性，包含20个Pascal的对象类别和12个Yahoo的对象类别。AWA1是一个中等规模的动物数据集，包含50个动物类别，标注了85个属性。AWA2由文献[37]收集，其类别与AWA1相同。CUB是一个细粒度的中等规模数据集，包含200种不同类型的鸟类，标注了312个属性。SUN是一个中等规模的数据集，包含717种场景，标注了102个属性。为了与其他方法进行公平比较，我们在文献[37]最近提出的更合理的纯零样本学习设置下进行实验。每个数据集的详细信息以及源类别和目标类别的划分情况如表1所示。

Implementation Details. We extract the image features $f\left( \mathbf{x}\right)$ by the ResNet101 model [13] and use class attributes as the semantic information. The class semantic transformation $g\left( \mathbf{a}\right)$ is implemented by a two-layer fully connected neural network, where the hidden layer dimension is set to 1024 and the output size is 2048. The contrastive learning $h\left( \mathbf{z}\right)$ is also implemented by the fully connected neural network, where the hidden dimension is 1024 and the output size is 1 . We use Leaky ReLU as the nonlinear activation function for all the hidden layers and sigmoid function for the last layer ${}^{1}$ . The hyperparameter $\alpha$ is fine-tuned in the range $\left\lbrack  {{0.001},{0.01},{0.1},1}\right\rbrack$ by the validation set.

实现细节。我们通过ResNet101模型[13]提取图像特征 $f\left( \mathbf{x}\right)$，并使用类别属性作为语义信息。类别语义转换 $g\left( \mathbf{a}\right)$ 由一个两层全连接神经网络实现，其中隐藏层维度设置为1024，输出大小为2048。对比学习 $h\left( \mathbf{z}\right)$ 也由全连接神经网络实现，其中隐藏维度为1024，输出大小为1。我们对所有隐藏层使用Leaky ReLU作为非线性激活函数，对最后一层 ${}^{1}$ 使用sigmoid函数。超参数 $\alpha$ 在范围 $\left\lbrack  {{0.001},{0.01},{0.1},1}\right\rbrack$ 内通过验证集进行微调。

<table><tr><td>$\mathbf{{Method}}$</td><td>$\mathbf{{APY}}$</td><td>AWA1</td><td>AWA2</td><td>CUB</td><td>SUN</td></tr><tr><td>DAP [19]</td><td>33.8</td><td>44.1</td><td>46.1</td><td>40.0</td><td>39.9</td></tr><tr><td>IAP [19]</td><td>36.6</td><td>35.9</td><td>35.9</td><td>24.0</td><td>19.4</td></tr><tr><td>CONSE [24]</td><td>26.9</td><td>45.6</td><td>44.5</td><td>34.3</td><td>38.8</td></tr><tr><td>CMT [31]</td><td>28.0</td><td>39.5</td><td>37.9</td><td>34.6</td><td>39.9</td></tr><tr><td>SSE [41]</td><td>34.0</td><td>60.1</td><td>61.0</td><td>43.9</td><td>51.5</td></tr><tr><td>LATEM [36]</td><td>35.2</td><td>55.1</td><td>55.8</td><td>49.3</td><td>55.3</td></tr><tr><td>ALE [1]</td><td>39.7</td><td>59.9</td><td>62.5</td><td>54.9</td><td>58.1</td></tr><tr><td>DEVISE [10]</td><td>39.8</td><td>54.2</td><td>59.7</td><td>52.0</td><td>56.5</td></tr><tr><td>SJE [2]</td><td>32.9</td><td>65.6</td><td>61.9</td><td>53.9</td><td>53.7</td></tr><tr><td>EZSL [27]</td><td>38.3</td><td>58.2</td><td>58.6</td><td>53.9</td><td>54.5</td></tr><tr><td>SYNC [4]</td><td>23.9</td><td>54.0</td><td>46.6</td><td>55.6</td><td>56.3</td></tr><tr><td>SAE [17]</td><td>8.3</td><td>53.0</td><td>54.1</td><td>33.3</td><td>40.3</td></tr><tr><td>CDL [14]</td><td>43.0</td><td>69.9</td><td>-</td><td>54.5</td><td>63.6</td></tr><tr><td>RNet [32]</td><td>-</td><td>68.2</td><td>64.2</td><td>55.6</td><td>-</td></tr><tr><td>FGN [38]</td><td>-</td><td>68.2</td><td>-</td><td>57.3</td><td>60.8</td></tr><tr><td>GAZSL [43]</td><td>41.1</td><td>68.2</td><td>70.2</td><td>55.8</td><td>61.3</td></tr><tr><td>DCN [20]</td><td>43.6</td><td>65.2</td><td>-</td><td>56.2</td><td>61.8</td></tr><tr><td>TCN (ours)</td><td>38.9</td><td>70.3</td><td>71.2</td><td>59.5</td><td>61.5</td></tr></table>

<table><tbody><tr><td>$\mathbf{{Method}}$</td><td>$\mathbf{{APY}}$</td><td>AWA1</td><td>AWA2</td><td>立方体(CUB)</td><td>太阳(SUN)</td></tr><tr><td>动态注意力池化(DAP) [19]</td><td>33.8</td><td>44.1</td><td>46.1</td><td>40.0</td><td>39.9</td></tr><tr><td>实例注意力池化(IAP) [19]</td><td>36.6</td><td>35.9</td><td>35.9</td><td>24.0</td><td>19.4</td></tr><tr><td>一致性(CONSE) [24]</td><td>26.9</td><td>45.6</td><td>44.5</td><td>34.3</td><td>38.8</td></tr><tr><td>对比匹配训练(CMT) [31]</td><td>28.0</td><td>39.5</td><td>37.9</td><td>34.6</td><td>39.9</td></tr><tr><td>半监督嵌入(SSE) [41]</td><td>34.0</td><td>60.1</td><td>61.0</td><td>43.9</td><td>51.5</td></tr><tr><td>后期嵌入(LATEM) [36]</td><td>35.2</td><td>55.1</td><td>55.8</td><td>49.3</td><td>55.3</td></tr><tr><td>自适应标签嵌入(ALE) [1]</td><td>39.7</td><td>59.9</td><td>62.5</td><td>54.9</td><td>58.1</td></tr><tr><td>设计(DEVISE) [10]</td><td>39.8</td><td>54.2</td><td>59.7</td><td>52.0</td><td>56.5</td></tr><tr><td>圣何塞(SJE) [2]</td><td>32.9</td><td>65.6</td><td>61.9</td><td>53.9</td><td>53.7</td></tr><tr><td>高效零样本学习(EZSL) [27]</td><td>38.3</td><td>58.2</td><td>58.6</td><td>53.9</td><td>54.5</td></tr><tr><td>同步(SYNC) [4]</td><td>23.9</td><td>54.0</td><td>46.6</td><td>55.6</td><td>56.3</td></tr><tr><td>堆叠自编码器(SAE) [17]</td><td>8.3</td><td>53.0</td><td>54.1</td><td>33.3</td><td>40.3</td></tr><tr><td>对比深度嵌入学习(CDL) [14]</td><td>43.0</td><td>69.9</td><td>-</td><td>54.5</td><td>63.6</td></tr><tr><td>关系网络(RNet) [32]</td><td>-</td><td>68.2</td><td>64.2</td><td>55.6</td><td>-</td></tr><tr><td>模糊图网络(FGN) [38]</td><td>-</td><td>68.2</td><td>-</td><td>57.3</td><td>60.8</td></tr><tr><td>广义零样本学习(GAZSL) [43]</td><td>41.1</td><td>68.2</td><td>70.2</td><td>55.8</td><td>61.3</td></tr><tr><td>深度对比网络(DCN) [20]</td><td>43.6</td><td>65.2</td><td>-</td><td>56.2</td><td>61.8</td></tr><tr><td>时间卷积网络(TCN)(我们的方法)</td><td>38.9</td><td>70.3</td><td>71.2</td><td>59.5</td><td>61.5</td></tr></tbody></table>

Table 2. Zero-shot recognition results on APY, AWA1, AWA2, CUB and SUN (%). '-' denotes that the results are not reported.

表2. 在APY、AWA1、AWA2、CUB和SUN数据集上的零样本识别结果(%)。“-”表示未报告结果。

### 4.2. Performance on ZSL and GZSL

### 4.2. 零样本学习(ZSL)和广义零样本学习(GZSL)的性能

To demonstrate the effectiveness of the transferable contrastive network, we compare our approach with several state-of-the-art approaches. Table 2 shows the comparison results of ZSL, where the performance is evaluated by the average per-class top-1 accuracy. It can be seen that our approach achieves the best performance on three datasets and is comparable to the best approach on SUN, which indicates that transferable contrastive network can make good knowledge transfer to the target classes. Our approach is effective to perform fine-grained recognition, as can be seen by the good performance on CUB. We owe the success to two aspects. First, the discriminative property of contrastive learning ensures the contrastive network to effectively discriminate the fine-grained classes. Second, the fine-grained images are more effective to transfer the knowledge since the classes are similar, which makes our model more robust to the target classes. A little lower performance is obtained on APY probably due to the weak relations between the source and target classes. APY is a small-scale coarse-grained dataset, where the categories are very different. Therefore, the relations between source and target classes are weak. That's why most approaches could not perform well on this simple dataset. Since we utilize the class similarities to transfer the knowledge, our model may be influenced by the weak relations.

为了证明可迁移对比网络的有效性，我们将我们的方法与几种最先进的方法进行了比较。表2展示了零样本学习(ZSL)的比较结果，其中性能通过每类平均top - 1准确率进行评估。可以看出，我们的方法在三个数据集上取得了最佳性能，并且在SUN数据集上与最佳方法相当，这表明可迁移对比网络能够很好地将知识迁移到目标类别。从在CUB数据集上的良好表现可以看出，我们的方法在进行细粒度识别方面是有效的。我们将这一成功归功于两个方面。首先，对比学习的判别特性确保了对比网络能够有效地对细粒度类别进行区分。其次，由于类别相似，细粒度图像在知识迁移方面更有效，这使得我们的模型对目标类别更具鲁棒性。在APY数据集上取得的性能略低，可能是由于源类别和目标类别之间的关系较弱。APY是一个小规模的粗粒度数据集，其中的类别差异很大。因此，源类别和目标类别之间的关系较弱。这就是为什么大多数方法在这个简单的数据集上表现不佳的原因。由于我们利用类别相似性来进行知识迁移，我们的模型可能会受到这种弱关系的影响。

---

${}^{1}$ Source code is available at http://vipl.ict.ac.cn/resources/codes.

${}^{1}$ 源代码可在http://vipl.ict.ac.cn/resources/codes获取。

---

<table><tr><td rowspan="2">Method</td><td colspan="3">APY</td><td colspan="3">AWA1</td><td colspan="3">AWA2</td><td colspan="3">CUB</td><td colspan="3">SUN</td></tr><tr><td>ts</td><td>tr</td><td>H</td><td>ts</td><td>tr</td><td>H</td><td>ts</td><td>tr</td><td>H</td><td>ts</td><td>tr</td><td>H</td><td>ts</td><td>tr</td><td>H</td></tr><tr><td>DAP [19]</td><td>4.8</td><td>78.3</td><td>9.0</td><td>0.0</td><td>88.7</td><td>0.0</td><td>0.0</td><td>84.7</td><td>0.0</td><td>1.7</td><td>67.9</td><td>3.3</td><td>4.2</td><td>25.1</td><td>7.2</td></tr><tr><td>IAP [19]</td><td>5.7</td><td>65.6</td><td>10.4</td><td>2.1</td><td>78.2</td><td>4.1</td><td>0.9</td><td>87.6</td><td>1.8</td><td>0.2</td><td>72.8</td><td>0.4</td><td>1.0</td><td>37.8</td><td>1.8</td></tr><tr><td>CONSE [24]</td><td>0.0</td><td>91.2</td><td>0.0</td><td>0.4</td><td>88.6</td><td>0.8</td><td>0.5</td><td>90.6</td><td>1.0</td><td>1.6</td><td>72.2</td><td>3.1</td><td>6.8</td><td>39.9</td><td>11.6</td></tr><tr><td>CMT [31]</td><td>1.4</td><td>85.2</td><td>2.8</td><td>0.9</td><td>87.6</td><td>1.8</td><td>0.5</td><td>90.0</td><td>1.0</td><td>7.2</td><td>49.8</td><td>12.6</td><td>8.1</td><td>21.8</td><td>11.8</td></tr><tr><td>SSE [41]</td><td>0.2</td><td>78.9</td><td>0.4</td><td>7.0</td><td>80.5</td><td>12.9</td><td>8.1</td><td>82.5</td><td>14.8</td><td>8.5</td><td>46.9</td><td>14.4</td><td>2.1</td><td>36.4</td><td>4.0</td></tr><tr><td>LATEM [36]</td><td>0.1</td><td>73.0</td><td>0.2</td><td>7.3</td><td>71.7</td><td>13.3</td><td>11.5</td><td>77.3</td><td>20.0</td><td>15.2</td><td>57.3</td><td>24.0</td><td>14.7</td><td>28.8</td><td>19.5</td></tr><tr><td>ALE [1]</td><td>4.6</td><td>73.7</td><td>8.7</td><td>16.8</td><td>76.1</td><td>27.5</td><td>14.0</td><td>81.8</td><td>23.9</td><td>23.7</td><td>62.8</td><td>34.4</td><td>21.8</td><td>33.1</td><td>26.3</td></tr><tr><td>DEVISE [10]</td><td>4.9</td><td>76.9</td><td>9.2</td><td>13.4</td><td>68.7</td><td>22.4</td><td>17.1</td><td>74.7</td><td>27.8</td><td>23.8</td><td>53.0</td><td>32.8</td><td>16.9</td><td>27.4</td><td>20.9</td></tr><tr><td>SJE [2]</td><td>3.7</td><td>55.7</td><td>6.9</td><td>11.3</td><td>74.6</td><td>19.6</td><td>8.0</td><td>73.9</td><td>14.4</td><td>23.5</td><td>59.2</td><td>33.6</td><td>14.1</td><td>30.5</td><td>19.8</td></tr><tr><td>EZSL [27]</td><td>2.4</td><td>70.1</td><td>4.6</td><td>6.6</td><td>75.6</td><td>12.1</td><td>5.9</td><td>77.8</td><td>11.0</td><td>12.6</td><td>63.8</td><td>21.0</td><td>11.0</td><td>27.9</td><td>15.8</td></tr><tr><td>SYNC [4]</td><td>7.4</td><td>66.3</td><td>13.3</td><td>8.9</td><td>87.3</td><td>16.2</td><td>10.0</td><td>90.5</td><td>18.0</td><td>11.5</td><td>70.9</td><td>19.8</td><td>7.9</td><td>43.3</td><td>13.4</td></tr><tr><td>SAE [17]</td><td>0.4</td><td>80.9</td><td>0.9</td><td>1.8</td><td>77.1</td><td>3.5</td><td>1.1</td><td>82.2</td><td>2.2</td><td>7.8</td><td>54.0</td><td>13.6</td><td>8.8</td><td>18.0</td><td>11.8</td></tr><tr><td>CDL [14]</td><td>19.8</td><td>48.6</td><td>28.1</td><td>28.1</td><td>73.5</td><td>40.6</td><td>-</td><td>-</td><td>-</td><td>23.5</td><td>55.2</td><td>32.9</td><td>21.5</td><td>34.7</td><td>26.5</td></tr><tr><td>RNet [32]</td><td>-</td><td>-</td><td>-</td><td>31.4</td><td>91.3</td><td>46.7</td><td>30.0</td><td>93.4</td><td>45.3</td><td>38.1</td><td>61.4</td><td>47.0</td><td>-</td><td>-</td><td>-</td></tr><tr><td>FGN [38]</td><td>-</td><td>-</td><td>-</td><td>57.9</td><td>61.4</td><td>59.6</td><td>-</td><td>-</td><td>-</td><td>43.7</td><td>57.7</td><td>49.7</td><td>42.6</td><td>36.6</td><td>39.4</td></tr><tr><td>GAZSL [43]</td><td>14.2</td><td>78.6</td><td>24.0</td><td>29.6</td><td>84.2</td><td>43.8</td><td>35.4</td><td>86.9</td><td>50.3</td><td>31.7</td><td>61.3</td><td>41.8</td><td>22.1</td><td>39.3</td><td>28.3</td></tr><tr><td>DCN [20]</td><td>14.2</td><td>75.0</td><td>23.9</td><td>25.5</td><td>84.2</td><td>39.1</td><td>-</td><td>-</td><td>-</td><td>28.4</td><td>60.7</td><td>38.7</td><td>25.5</td><td>37.0</td><td>30.2</td></tr><tr><td>TCN (ours)</td><td>24.1</td><td>64.0</td><td>35.1</td><td>49.4</td><td>76.5</td><td>60.0</td><td>61.2</td><td>65.8</td><td>63.4</td><td>52.6</td><td>52.0</td><td>52.3</td><td>31.2</td><td>37.3</td><td>34.0</td></tr></table>

<table><tbody><tr><td rowspan="2">方法</td><td colspan="3">年百分比收益率(APY)</td><td colspan="3">AWA1</td><td colspan="3">AWA2</td><td colspan="3">加州大学伯克利分校鸟类数据集(CUB)</td><td colspan="3">加州大学圣地亚哥分校场景数据集(SUN)</td></tr><tr><td>测试集(ts)</td><td>训练集(tr)</td><td>H</td><td>测试集(ts)</td><td>训练集(tr)</td><td>H</td><td>测试集(ts)</td><td>训练集(tr)</td><td>H</td><td>测试集(ts)</td><td>训练集(tr)</td><td>H</td><td>测试集(ts)</td><td>训练集(tr)</td><td>H</td></tr><tr><td>动态属性预测(DAP) [19]</td><td>4.8</td><td>78.3</td><td>9.0</td><td>0.0</td><td>88.7</td><td>0.0</td><td>0.0</td><td>84.7</td><td>0.0</td><td>1.7</td><td>67.9</td><td>3.3</td><td>4.2</td><td>25.1</td><td>7.2</td></tr><tr><td>改进属性预测(IAP) [19]</td><td>5.7</td><td>65.6</td><td>10.4</td><td>2.1</td><td>78.2</td><td>4.1</td><td>0.9</td><td>87.6</td><td>1.8</td><td>0.2</td><td>72.8</td><td>0.4</td><td>1.0</td><td>37.8</td><td>1.8</td></tr><tr><td>一致性嵌入(CONSE) [24]</td><td>0.0</td><td>91.2</td><td>0.0</td><td>0.4</td><td>88.6</td><td>0.8</td><td>0.5</td><td>90.6</td><td>1.0</td><td>1.6</td><td>72.2</td><td>3.1</td><td>6.8</td><td>39.9</td><td>11.6</td></tr><tr><td>跨模态转换(CMT) [31]</td><td>1.4</td><td>85.2</td><td>2.8</td><td>0.9</td><td>87.6</td><td>1.8</td><td>0.5</td><td>90.0</td><td>1.0</td><td>7.2</td><td>49.8</td><td>12.6</td><td>8.1</td><td>21.8</td><td>11.8</td></tr><tr><td>语义自编码器(SSE) [41]</td><td>0.2</td><td>78.9</td><td>0.4</td><td>7.0</td><td>80.5</td><td>12.9</td><td>8.1</td><td>82.5</td><td>14.8</td><td>8.5</td><td>46.9</td><td>14.4</td><td>2.1</td><td>36.4</td><td>4.0</td></tr><tr><td>后期嵌入模型(LATEM) [36]</td><td>0.1</td><td>73.0</td><td>0.2</td><td>7.3</td><td>71.7</td><td>13.3</td><td>11.5</td><td>77.3</td><td>20.0</td><td>15.2</td><td>57.3</td><td>24.0</td><td>14.7</td><td>28.8</td><td>19.5</td></tr><tr><td>自适应标签嵌入(ALE) [1]</td><td>4.6</td><td>73.7</td><td>8.7</td><td>16.8</td><td>76.1</td><td>27.5</td><td>14.0</td><td>81.8</td><td>23.9</td><td>23.7</td><td>62.8</td><td>34.4</td><td>21.8</td><td>33.1</td><td>26.3</td></tr><tr><td>深度视觉语义嵌入(DEVISE) [10]</td><td>4.9</td><td>76.9</td><td>9.2</td><td>13.4</td><td>68.7</td><td>22.4</td><td>17.1</td><td>74.7</td><td>27.8</td><td>23.8</td><td>53.0</td><td>32.8</td><td>16.9</td><td>27.4</td><td>20.9</td></tr><tr><td>语义联合嵌入(SJE) [2]</td><td>3.7</td><td>55.7</td><td>6.9</td><td>11.3</td><td>74.6</td><td>19.6</td><td>8.0</td><td>73.9</td><td>14.4</td><td>23.5</td><td>59.2</td><td>33.6</td><td>14.1</td><td>30.5</td><td>19.8</td></tr><tr><td>高效零样本学习(EZSL) [27]</td><td>2.4</td><td>70.1</td><td>4.6</td><td>6.6</td><td>75.6</td><td>12.1</td><td>5.9</td><td>77.8</td><td>11.0</td><td>12.6</td><td>63.8</td><td>21.0</td><td>11.0</td><td>27.9</td><td>15.8</td></tr><tr><td>同步训练(SYNC) [4]</td><td>7.4</td><td>66.3</td><td>13.3</td><td>8.9</td><td>87.3</td><td>16.2</td><td>10.0</td><td>90.5</td><td>18.0</td><td>11.5</td><td>70.9</td><td>19.8</td><td>7.9</td><td>43.3</td><td>13.4</td></tr><tr><td>堆叠自编码器(SAE) [17]</td><td>0.4</td><td>80.9</td><td>0.9</td><td>1.8</td><td>77.1</td><td>3.5</td><td>1.1</td><td>82.2</td><td>2.2</td><td>7.8</td><td>54.0</td><td>13.6</td><td>8.8</td><td>18.0</td><td>11.8</td></tr><tr><td>跨域学习(CDL) [14]</td><td>19.8</td><td>48.6</td><td>28.1</td><td>28.1</td><td>73.5</td><td>40.6</td><td>-</td><td>-</td><td>-</td><td>23.5</td><td>55.2</td><td>32.9</td><td>21.5</td><td>34.7</td><td>26.5</td></tr><tr><td>关系网络(RNet) [32]</td><td>-</td><td>-</td><td>-</td><td>31.4</td><td>91.3</td><td>46.7</td><td>30.0</td><td>93.4</td><td>45.3</td><td>38.1</td><td>61.4</td><td>47.0</td><td>-</td><td>-</td><td>-</td></tr><tr><td>特征生成网络(FGN) [38]</td><td>-</td><td>-</td><td>-</td><td>57.9</td><td>61.4</td><td>59.6</td><td>-</td><td>-</td><td>-</td><td>43.7</td><td>57.7</td><td>49.7</td><td>42.6</td><td>36.6</td><td>39.4</td></tr><tr><td>广义零样本学习(GAZSL) [43]</td><td>14.2</td><td>78.6</td><td>24.0</td><td>29.6</td><td>84.2</td><td>43.8</td><td>35.4</td><td>86.9</td><td>50.3</td><td>31.7</td><td>61.3</td><td>41.8</td><td>22.1</td><td>39.3</td><td>28.3</td></tr><tr><td>深度组合网络(DCN) [20]</td><td>14.2</td><td>75.0</td><td>23.9</td><td>25.5</td><td>84.2</td><td>39.1</td><td>-</td><td>-</td><td>-</td><td>28.4</td><td>60.7</td><td>38.7</td><td>25.5</td><td>37.0</td><td>30.2</td></tr><tr><td>时间卷积网络(TCN)(我们的方法)</td><td>24.1</td><td>64.0</td><td>35.1</td><td>49.4</td><td>76.5</td><td>60.0</td><td>61.2</td><td>65.8</td><td>63.4</td><td>52.6</td><td>52.0</td><td>52.3</td><td>31.2</td><td>37.3</td><td>34.0</td></tr></tbody></table>

Table 3. GZSL results on APY, AWA1, AWA2, CUB and SUN. ts = Top-1 accuracy of the target classes, tr = Top-1 accuracy of the source classes, $\mathrm{H} =$ harmonic mean. We measure average per-class top-1 accuracy in %. "-" represents that the results are not reported.

表3. 在APY、AWA1、AWA2、CUB和SUN数据集上的广义零样本学习(GZSL)结果。ts = 目标类别的Top-1准确率，tr = 源类别的Top-1准确率，$\mathrm{H} =$ 调和均值。我们以百分比形式衡量每类的平均Top-1准确率。“-”表示未报告结果。

We argue that traditional approaches usually tend to overfit the source classes since they ignore the target in the model learning process, which will result in the projection domain shift problem. While TCN could alleviate this problem since our model explicitly transfers the knowledge. To demonstrate this viewpoint, we perform GZSL task on these datasets. Table 3 shows the comparison results, where 't-s' is average per-class top-1 accuracy of target classes and 'tr' is the same evaluation results on source classes. 'H' is the harmonic mean that evaluates the total performance. It can be seen that most approaches achieve very high performance on the source classes and extremely low performance on the target classes, which indicates that these approaches learn little knowledge about the target classes. Compared with the results in Table 2, the performance of target classes drops greatly for GZSL because most target-class images are recognized as source classes. This indicates that previous approaches are easy to overfit the source classes. While TCN can effectively alleviate the overfitting problem, as can be seen by the more balanced performance on source and target classes for our approach. We owe the success to the transferable property of the contrastive network, which makes our model more robust to recognize the target images. Although the generative approaches $\left\lbrack  {{38},{43}}\right\rbrack$ are also very effective in GZSL, they need to learn the complicated generative models. While our approach is very simple to learn. Moreover, our approach is well complementary to the generative approaches since the generated features can also be utilized to learn our model. Some other approaches $\left\lbrack  {{14},{20}}\right\rbrack$ also adapt the models to the target classes. Compared with them, our approach is more effective.

我们认为，传统方法通常容易对源类别过拟合，因为它们在模型学习过程中忽略了目标类别，这会导致投影域偏移问题。而对比网络(TCN)可以缓解这个问题，因为我们的模型明确地进行了知识迁移。为了证明这一观点，我们在这些数据集上进行了广义零样本学习(GZSL)任务。表3展示了对比结果，其中“t-s”是目标类别的每类平均Top-1准确率，“tr”是源类别的相同评估结果。“H”是评估总体性能的调和均值。可以看出，大多数方法在源类别上取得了非常高的性能，但在目标类别上的性能极低，这表明这些方法对目标类别的知识学习甚少。与表2中的结果相比，广义零样本学习(GZSL)中目标类别的性能大幅下降，因为大多数目标类别图像被识别为源类别图像。这表明之前的方法容易对源类别过拟合。而对比网络(TCN)可以有效缓解过拟合问题，从我们的方法在源类别和目标类别上更平衡的性能可以看出这一点。我们将这一成功归功于对比网络的可迁移特性，这使得我们的模型在识别目标图像时更加鲁棒。虽然生成式方法 $\left\lbrack  {{38},{43}}\right\rbrack$ 在广义零样本学习(GZSL)中也非常有效，但它们需要学习复杂的生成模型。而我们的方法学习起来非常简单。此外，我们的方法与生成式方法具有很好的互补性，因为生成的特征也可用于学习我们的模型。其他一些方法 $\left\lbrack  {{14},{20}}\right\rbrack$ 也使模型适应目标类别。与它们相比，我们的方法更有效。

<table><tr><td rowspan="2">Dataset</td><td rowspan="2">$\mathbf{{Method}}$</td><td rowspan="2">ZSL</td><td colspan="3">GZSL</td></tr><tr><td>ts</td><td>tr</td><td>H</td></tr><tr><td rowspan="2">APY</td><td>Base</td><td>37.52</td><td>5.50</td><td>77.78</td><td>10.28</td></tr><tr><td>TCN</td><td>38.93</td><td>24.13</td><td>64.00</td><td>35.05</td></tr><tr><td rowspan="2">AWA1</td><td>Base</td><td>70.15</td><td>9.22</td><td>64.78</td><td>16.14</td></tr><tr><td>TCN</td><td>70.34</td><td>49.40</td><td>76.48</td><td>60.03</td></tr><tr><td rowspan="2">AWA2</td><td>Base</td><td>68.48</td><td>9.32</td><td>54.23</td><td>15.91</td></tr><tr><td>TCN</td><td>71.18</td><td>61.20</td><td>65.83</td><td>63.43</td></tr><tr><td rowspan="2">CUB</td><td>Base</td><td>56.62</td><td>24.70</td><td>64.90</td><td>37.84</td></tr><tr><td>TCN</td><td>59.54</td><td>52.58</td><td>52.03</td><td>52.30</td></tr><tr><td rowspan="2">SUN</td><td>Base</td><td>61.04</td><td>21.94</td><td>38.64</td><td>27.99</td></tr><tr><td>TCN</td><td>61.53</td><td>31.18</td><td>37.29</td><td>33.96</td></tr></table>

<table><tbody><tr><td rowspan="2">数据集</td><td rowspan="2">$\mathbf{{Method}}$</td><td rowspan="2">零样本学习(Zero-Shot Learning，ZSL)</td><td colspan="3">广义零样本学习(Generalized Zero-Shot Learning，GZSL)</td></tr><tr><td>测试集(test set，ts)</td><td>训练集(training set，tr)</td><td>H</td></tr><tr><td rowspan="2">属性预测年(Attribute Prediction Year，APY)</td><td>基础</td><td>37.52</td><td>5.50</td><td>77.78</td><td>10.28</td></tr><tr><td>时间卷积网络(Temporal Convolutional Network，TCN)</td><td>38.93</td><td>24.13</td><td>64.00</td><td>35.05</td></tr><tr><td rowspan="2">动物属性数据集1(Animals with Attributes 1，AWA1)</td><td>基础</td><td>70.15</td><td>9.22</td><td>64.78</td><td>16.14</td></tr><tr><td>时间卷积网络(Temporal Convolutional Network，TCN)</td><td>70.34</td><td>49.40</td><td>76.48</td><td>60.03</td></tr><tr><td rowspan="2">动物属性数据集2(Animals with Attributes 2，AWA2)</td><td>基础</td><td>68.48</td><td>9.32</td><td>54.23</td><td>15.91</td></tr><tr><td>时间卷积网络(Temporal Convolutional Network，TCN)</td><td>71.18</td><td>61.20</td><td>65.83</td><td>63.43</td></tr><tr><td rowspan="2">加州大学圣地亚哥分校鸟类数据集(Caltech-UCSD Birds-200-2011，CUB)</td><td>基础</td><td>56.62</td><td>24.70</td><td>64.90</td><td>37.84</td></tr><tr><td>时间卷积网络(Temporal Convolutional Network，TCN)</td><td>59.54</td><td>52.58</td><td>52.03</td><td>52.30</td></tr><tr><td rowspan="2">太阳场景数据集(SUN Scene Database，SUN)</td><td>基础</td><td>61.04</td><td>21.94</td><td>38.64</td><td>27.99</td></tr><tr><td>时间卷积网络(Temporal Convolutional Network，TCN)</td><td>61.53</td><td>31.18</td><td>37.29</td><td>33.96</td></tr></tbody></table>

Table 4. Comparison with the baseline approach where the knowledge transfer item $\left( {\mathcal{L}}_{T}\right)$ is removed. ’Base’ represents the baseline approach. 'TCN' is our approach. 'ZSL' is the accuracy of zero-shot recognition. 'ts', 'tr' and 'H' are the target-class accuracy, source-class accuracy and harmonic mean in GZSL.

表4. 与去除知识迁移项 $\left( {\mathcal{L}}_{T}\right)$ 的基线方法的比较。“Base”代表基线方法。“TCN”是我们的方法。“ZSL”是零样本识别的准确率。“ts”、“tr”和“H”分别是广义零样本学习(GZSL)中的目标类准确率、源类准确率和调和均值。

We also tried other information fusion approaches and more details are shown in the supplementary materials.

我们还尝试了其他信息融合方法，更多细节见补充材料。

### 4.3. Importance of Knowledge Transfer

### 4.3. 知识迁移的重要性

Explicit knowledge transfer is an important part of our framework. It is intuitive that similar objects should play a more important role in transfer learning. Therefore, we use class similarities to explicitly transfer the knowledge from source images to similar target classes. In this way, our model will be more robust to the target classes. Moreover, it should also have the ability to prevent the model from overfitting the source classes. To demonstrate these assumptions, we compare our approach with the basic model, where the knowledge transfer term $\left( {\mathcal{L}}_{T}\right)$ is removed. Table 4 shows the recognition results. Although only small improvements are achieved for ZSL, the improvements for GZSL are significant. This phenomenon demonstrates that explicit knowledge transfer can effectively tackle the over-fitting problem, which enables the model to learn the knowledge about the target classes.

显式知识迁移是我们框架的重要组成部分。直观地说，相似的对象在迁移学习中应该发挥更重要的作用。因此，我们使用类别相似度将知识从源图像显式地迁移到相似的目标类。通过这种方式，我们的模型对目标类将更具鲁棒性。此外，它还应具备防止模型对源类过拟合的能力。为了验证这些假设，我们将我们的方法与去除了知识迁移项 $\left( {\mathcal{L}}_{T}\right)$ 的基础模型进行了比较。表4显示了识别结果。虽然零样本学习(ZSL)的改进较小，但广义零样本学习(GZSL)的改进显著。这一现象表明，显式知识迁移可以有效解决过拟合问题，使模型能够学习关于目标类的知识。

![0195e075-8ad2-7476-aec8-0bc1863e2100_6_174_221_617_343_0.jpg](images/0195e075-8ad2-7476-aec8-0bc1863e2100_6_174_221_617_343_0.jpg)

Figure 3. The recognition results on CUB with different value of $\alpha$ . ’ZSL’ is the accuracy of zero-shot recognition. ’ts’,’tr’ and ’H’ are the target-class accuracy, source-class accuracy and harmonic mean in GZSL.

图3. 在CUB数据集上不同 $\alpha$ 值的识别结果。“ZSL”是零样本识别的准确率。“ts”、“tr”和“H”分别是广义零样本学习(GZSL)中的目标类准确率、源类准确率和调和均值。

Another factor that deserves to be explored is how important the knowledge transfer is. Therefore, we analyze the influence of parameter $\alpha$ to our model and the recognition results on CUB are shown in Figure 3. It can be seen that TCN achieves its best performance when $\alpha$ equals to 0.01. We can infer that $\alpha$ should be small in order to get good performance. This may be caused by two reasons. First, the class similarities are fuzzy measures and there is no accurate definitions. Second, the source images do not absolutely match with the target classes. When $\alpha$ increases, the performance of source classes drops, as can be seen by the results of ’tr’, because the model pays more attention to the target classes and neglects the accurate source classes. Since the loss on the source classes ensures the discriminative property of contrastive learning and the loss on the target classes guarantees the transferable property, we must balance these terms to obtain a robust recognition model.

另一个值得探索的因素是知识迁移的重要程度。因此，我们分析了参数 $\alpha$ 对我们模型的影响，图3显示了在CUB数据集上的识别结果。可以看出，当 $\alpha$ 等于0.01时，TCN方法达到最佳性能。我们可以推断，为了获得良好的性能， $\alpha$ 应该较小。这可能有两个原因。首先，类别相似度是模糊度量，没有精确的定义。其次，源图像与目标类并非完全匹配。当 $\alpha$ 增大时，从“tr”的结果可以看出，源类的性能下降，因为模型更关注目标类而忽略了精确的源类。由于源类的损失确保了对比学习的判别性，而目标类的损失保证了可迁移性，我们必须平衡这些项以获得一个鲁棒的识别模型。

### 4.4. Visualization of Class Similarities

### 4.4. 类别相似度的可视化

The transferable property of our approach is accomplished by leveraging the class similarities to make knowledge transfer in the model learning process. To see what knowledge has been transferred, we show the class similarities of AWA1 in Figure 4. Because of space constraints, we select 15 source classes and visualize their similarities to the target classes. It can be figured out that leopard is similar to bobcat so the training samples of leopard can also be utilized to learn the target class bobcat in the training phase, thus to enable knowledge transfer. It effectively tackles the problem that no training images are available for the target classes. Through such explicit knowledge transfer, our model would be more robust to the target. Other class similarities, i.e. killer+whale is similar to blue+whale, seal, walrus and dolphin, are also useful knowledge to transfer in the contrastive learning process.

我们方法的可迁移性是通过在模型学习过程中利用类别相似度进行知识迁移来实现的。为了了解迁移了哪些知识，我们在图4中展示了AWA1数据集的类别相似度。由于空间限制，我们选择了15个源类，并可视化它们与目标类的相似度。可以发现，豹与山猫相似，因此在训练阶段，豹的训练样本也可用于学习目标类山猫，从而实现知识迁移。这有效地解决了目标类没有训练图像的问题。通过这种显式的知识迁移，我们的模型对目标类将更具鲁棒性。其他类别相似度，例如虎鲸与蓝鲸、海豹、海象和海豚相似，在对比学习过程中也是有用的迁移知识。

![0195e075-8ad2-7476-aec8-0bc1863e2100_6_916_231_631_486_0.jpg](images/0195e075-8ad2-7476-aec8-0bc1863e2100_6_916_231_631_486_0.jpg)

Figure 4. The class similarities in AWA1, where 15 source classes are selected. Each row represents the similarities of one source class to the target classes.

图4. AWA1数据集中的类别相似度，其中选择了15个源类。每行表示一个源类与目标类的相似度。

![0195e075-8ad2-7476-aec8-0bc1863e2100_6_917_878_628_484_0.jpg](images/0195e075-8ad2-7476-aec8-0bc1863e2100_6_917_878_628_484_0.jpg)

Figure 5. The class similarities in APY, where each row shows the similarities of one source class to the target classes.

图5. APY数据集中的类别相似度，其中每行显示一个源类与目标类的相似度。

The foundation on which our approach works well is that reasonable class similarities are obtained for knowledge transfer. However, the class similarities may be very rough for some coarse-grained dataset, such as APY, so it becomes difficult to transfer knowledge from source classes to the target classes. That is why low zero-shot recognition accuracy is obtained on APY for all approaches, as can be seen from Table 2. To make it intuitive, we show the class similarities for APY in Figure 5. It can be figured out that the relations between source and target classes are less reliable. For example, among the target classes, the most similar one to the source class building is the train. However, buildings and trains are very different in reality. Therefore, using the training images of building to learn the target train would degrade our model. This may be the reason why TC- $\mathrm{N}$ achieves lower performance than the state-of-the-art approach on APY. Although some incomprehensible similarities exist, there are also some useful relations, i.e. bicycle is similar to motorbike and bus is similar to train, which ensures the relative good performance of our approach.

我们的方法能够良好运行的基础是，为知识迁移获得合理的类别相似度。然而，对于一些粗粒度的数据集(如APY数据集)，类别相似度可能非常粗略，因此很难将知识从源类别迁移到目标类别。这就是为什么从表2中可以看出，所有方法在APY数据集上的零样本识别准确率都较低的原因。为了更直观地展示，我们在图5中展示了APY数据集的类别相似度。可以看出，源类别和目标类别之间的关系不太可靠。例如，在目标类别中，与源类别“建筑物(building)”最相似的是“火车(train)”。然而，在现实中，建筑物和火车有很大的不同。因此，使用建筑物的训练图像来学习目标类别火车会降低我们模型的性能。这可能就是TC - $\mathrm{N}$在APY数据集上的性能低于最先进方法的原因。尽管存在一些难以理解的相似度，但也有一些有用的关系，即“自行车(bicycle)”与“摩托车(motorbike)”相似，“公共汽车(bus)”与“火车(train)”相似，这确保了我们的方法具有相对较好的性能。

![0195e075-8ad2-7476-aec8-0bc1863e2100_7_135_218_1464_561_0.jpg](images/0195e075-8ad2-7476-aec8-0bc1863e2100_7_135_218_1464_561_0.jpg)

Figure 6. The normalized contrastive values of some test samples obtained on AWA1, where five most similar classes are shown. The source classes are marked with green and the target classes are marked with red. The first row in GZSL shows the target-class samples and the second shows the source-class samples.

图6. 在AWA1数据集上获得的一些测试样本的归一化对比值，其中显示了五个最相似的类别。源类别用绿色标记，目标类别用红色标记。广义零样本学习(GZSL)中的第一行显示目标类别样本，第二行显示源类别样本。

### 4.5. Visualization of Contrastive Values

### 4.5. 对比值的可视化

Different from the visual-semantic embedding approaches that use fixed distance to conduct zero-shot recognition, our transferable contrastive network automatically contrasts one image with every class and outputs the contrastive values for image recognition. Figure 6 shows the contrastive values of some test samples obtained on AWA1. In order to make it intuitive, we normalize the contrastive values and show five most similar classes, where the target classes are marked with red and the source classes are marked with green. We can figure out that most images are consistent with their corresponding classes and dissimilar with other classes. For ZSL, we recognize the test samples among the target classes. As can be seen, the image 'giraffe' has high contrastive value with its class and has low contrastive values with other ones. For GZSL, we recognize the test samples among all classes. Although we only have source-class images for training, our model can effectively recognize the target-class samples in the test procedure. For example, 'bobcat' is effectively discriminated with source-class leopard in GZSL task though these two classes are very similar. We owe this success to the explicit knowledge transfer by the class similarities. It prevents our model from overfitting the source classes and ensures the transferable ability to target classes, thus the target-class images would be effectively recognized when they are encountered. Moreover, one image may also have relatively high contrastive values with similar classes. For example, 'rat' has relative strong activations on hamster. This shows that TCN is not only discriminative enough to classify different classes but also transferable to novel classes.

与使用固定距离进行零样本识别的视觉 - 语义嵌入方法不同，我们的可迁移对比网络会自动将一张图像与每个类别进行对比，并输出用于图像识别的对比值。图6展示了在AWA1数据集上获得的一些测试样本的对比值。为了更直观地展示，我们对对比值进行归一化处理，并显示五个最相似的类别，其中目标类别用红色标记，源类别用绿色标记。我们可以发现，大多数图像与其对应的类别一致，而与其他类别不同。对于零样本学习(ZSL)，我们在目标类别中识别测试样本。可以看出，图像“长颈鹿(giraffe)”与其所属类别具有较高的对比值，而与其他类别具有较低的对比值。对于广义零样本学习(GZSL)，我们在所有类别中识别测试样本。尽管我们只有源类别图像用于训练，但我们的模型在测试过程中能够有效地识别目标类别样本。例如，在广义零样本学习任务中，“山猫(bobcat)”能够与源类别“豹(leopard)”有效区分，尽管这两个类别非常相似。我们将这一成功归功于通过类别相似度进行的显式知识迁移。它防止了我们的模型对源类别过拟合，并确保了向目标类别的可迁移能力，因此在遇到目标类别图像时能够有效地识别它们。此外，一张图像与相似类别也可能具有相对较高的对比值。例如，“老鼠(rat)”在“仓鼠(hamster)”上有相对较强的激活。这表明可迁移对比网络(TCN)不仅具有足够的判别能力来对不同类别进行分类，还能够迁移到新的类别。

## 5. Conclusion

## 5. 结论

In this paper, we propose a novel transferable contrastive network for generalized zero-shot learning. It automatically contrasts the images with the class semantics to judge how consistent they are. We consider two key properties in contrastive learning, where the discriminative property ensures the contrastive network to effectively classify different classes and the transferable property makes the contrastive network more robust to the target classes. By explicitly transferring knowledge from source images to similar target classes, our approach can effectively tackle the problem of overfitting the source classes in GZSL task. Extensive experiments on five benchmark datasets show the superiority of the proposed approach.

在本文中，我们为广义零样本学习提出了一种新颖的可迁移对比网络。它自动将图像与类别语义进行对比，以判断它们的一致性。我们在对比学习中考虑了两个关键属性，其中判别属性确保对比网络能够有效地对不同类别进行分类，而可迁移属性使对比网络对目标类别更具鲁棒性。通过将知识从源图像显式地迁移到相似的目标类别，我们的方法能够有效解决广义零样本学习任务中对源类别过拟合的问题。在五个基准数据集上的大量实验证明了所提出方法的优越性。

Acknowledgements. This work is partially supported by 973 Program under contract No. 2015CB351802, Natural Science Foundation of China under contracts Nos. 61390511, 61772500, CAS Frontier Science Key Research Project No. QYZDJ-SSWJSC009, and Youth Innovation Promotion Association No. 2015085.

致谢。本工作得到了973计划(合同编号:2015CB351802)、国家自然科学基金(合同编号:61390511、61772500)、中国科学院前沿科学重点研究项目(编号:QYZDJ - SSWJSC009)和青年创新促进会(编号:2015085)的部分资助。

[1] Zeynep Akata, Florent Perronnin, Zaid Harchaoui, and Cordelia Schmid. Label-embedding for attribute-based classification. In Proc. of Computer Vision and Pattern Recognition, pages 819-826, 2013.

[1] Zeynep Akata，Florent Perronnin，Zaid Harchaoui和Cordelia Schmid。基于属性分类的标签嵌入。见《计算机视觉与模式识别会议论文集》，第819 - 826页，2013年。

[2] Zeynep Akata, Scott Reed, Daniel Walter, Honglak Lee, and Bernt Schiele. Evaluation of output embeddings for fine-grained image classification. In Proc. of Computer Vision and Pattern Recognition, pages 2927-2936, 2015.

[2] Zeynep Akata，Scott Reed，Daniel Walter，Honglak Lee和Bernt Schiele。细粒度图像分类输出嵌入的评估。见《计算机视觉与模式识别会议论文集》，第2927 - 2936页，2015年。

[3] Maxime Bucher, Stéphane Herbin, and Frédéric Jurie. Improving semantic embedding consistency by metric learning for zero-shot classification. In Proc. of European Conference on Computer Vision, pages 730-746, 2016.

[3] Maxime Bucher，Stéphane Herbin和Frédéric Jurie。通过度量学习提高零样本分类的语义嵌入一致性。见《欧洲计算机视觉会议论文集》，第730 - 746页，2016年。

[4] Soravit Changpinyo, Wei-Lun Chao, Boqing Gong, and Fei Sha. Synthesized classifiers for zero-shot learning. In Proc. of Computer Vision and Pattern Recognition, pages 5327- 5336, 2016.

[4] 索拉维特·昌皮尼奥(Soravit Changpinyo)、赵伟伦(Wei-Lun Chao)、龚博清(Boqing Gong)和沙飞(Fei Sha)。用于零样本学习的合成分类器。见《计算机视觉与模式识别会议论文集》，第5327 - 5336页，2016年。

[5] Soravit Changpinyo, Wei-Lun Chao, and Fei Sha. Predicting visual exemplars of unseen classes for zero-shot learning. In Proc. of International Conference on Computer Vision, pages 3496-3505, 2017.

[5] 索拉维特·昌皮尼奥(Soravit Changpinyo)、赵伟伦(Wei-Lun Chao)和沙飞(Fei Sha)。为零样本学习预测未见类别的视觉示例。见《国际计算机视觉会议论文集》，第3496 - 3505页，2017年。

[6] Wei-Lun Chao, Soravit Changpinyo, Boqing Gong, and Fei Sha. An empirical study and analysis of generalized zero-shot learning for object recognition in the wild. In Proc. of European Conference on Computer Vision, pages 52-68, 2016.

[6] 赵伟伦(Wei-Lun Chao)、索拉维特·昌皮尼奥(Soravit Changpinyo)、龚博清(Boqing Gong)和沙飞(Fei Sha)。野外目标识别的广义零样本学习的实证研究与分析。见《欧洲计算机视觉会议论文集》，第52 - 68页，2016年。

[7] Long Chen, Hanwang Zhang, Jun Xiao, Wei Liu, and Shih-Fu Chang. Zero-shot visual recognition using semantics-preserving adversarial embedding network. In Proc. of Computer Vision and Pattern Recognition, pages 1043-1052, 2018.

[7] 陈龙(Long Chen)、张汉旺(Hanwang Zhang)、肖军(Jun Xiao)、刘伟(Wei Liu)和张世富(Shih-Fu Chang)。使用语义保持对抗嵌入网络的零样本视觉识别。见《计算机视觉与模式识别会议论文集》，第1043 - 1052页，2018年。

[8] Georgiana Dinu, Angeliki Lazaridou, and Marco Baroni. Improving zero-shot learning by mitigating the hubness problem. In Proc. of International Conference on Learning Representations workshops, 2015.

[8] 乔治亚娜·迪努(Georgiana Dinu)、安杰利基·拉扎里杜(Angeliki Lazaridou)和马尔科·巴罗尼(Marco Baroni)。通过缓解中心性问题改进零样本学习。见《国际学习表征会议研讨会论文集》，2015年。

[9] Alireza Farhadi, Ian Endres, Derek Hoiem, and David Forsyth. Describing objects by their attributes. In Proc. of Computer Vision and Pattern Recognition, pages 1778- 1785, 2009.

[9] 阿里雷扎·法尔哈迪(Alireza Farhadi)、伊恩·恩兹(Ian Endres)、德里克·霍耶姆(Derek Hoiem)和大卫·福赛思(David Forsyth)。通过物体属性描述物体。见《计算机视觉与模式识别会议论文集》，第1778 - 1785页，2009年。

[10] Andrea Frome, Greg S Corrado, Jon Shlens, Samy Bengio, Jeff Dean, MarcAurelio Ranzato, and Tomas Mikolov. Devise: A deep visual-semantic embedding model. In Proc. of Advances in Neural Information Processing Systems, pages 2121-2129, 2013.

[10] 安德里亚·弗罗姆(Andrea Frome)、格雷格·S·科拉多(Greg S Corrado)、乔恩·什伦斯(Jon Shlens)、萨米·本吉奥(Samy Bengio)、杰夫·迪恩(Jeff Dean)、马克 - 奥雷利奥·兰扎托(MarcAurelio Ranzato)和托马斯·米科洛夫(Tomas Mikolov)。DEVISE:一种深度视觉 - 语义嵌入模型。见《神经信息处理系统进展会议论文集》，第2121 - 2129页，2013年。

[11] Yanwei Fu, Timothy M. Hospedales, Tao Xiang, and Shao-gang Gong. Transductive multi-view zero-shot learning. IEEE Transactions on Pattern Analysis and Machine Intelligence, 37(11):2332-2345, 2015.

[11] 傅彦伟(Yanwei Fu)、蒂莫西·M·霍斯佩代尔斯(Timothy M. Hospedales)、向涛(Tao Xiang)和龚少刚(Shao - gang Gong)。直推式多视图零样本学习。《IEEE模式分析与机器智能汇刊》，37(11):2332 - 2345，2015年。

[12] Zhen-Yong Fu, Tao A. Xiang, Elyor Kodirov, and Shaogang Gong. Zero-shot object recognition by semantic manifold distance. In Proc. of Computer Vision and Pattern Recognition, pages 2635-2644, 2015.

[12] 傅振勇(Zhen - Yong Fu)、向涛(Tao A. Xiang)、埃利奥尔·科迪罗夫(Elyor Kodirov)和龚少刚(Shaogang Gong)。通过语义流形距离进行零样本目标识别。见《计算机视觉与模式识别会议论文集》，第2635 - 2644页，2015年。

[13] Kaiming He, Xiangyu Zhang, Shaoqing Ren, and Jian Sun. Deep residual learning for image recognition. In Proc. of Computer Vision and Pattern Recognition, pages 770-778, 2016.

[13] 何恺明(Kaiming He)、张祥雨(Xiangyu Zhang)、任少卿(Shaoqing Ren)和孙剑(Jian Sun)。用于图像识别的深度残差学习。见《计算机视觉与模式识别会议论文集》，第770 - 778页，2016年。

[14] Huajie Jiang, Ruiping Wang, Shiguang Shan, and Xilin

[14] 蒋华杰(Huajie Jiang)、王瑞平(Ruiping Wang)、单世广(Shiguang Shan)和陈熙霖

Chen. Learning class prototypes via structure alignment for zero-shot recognition. In Proc. of European Conference on Computer Vision, pages 118-134, 2018.

(Xilin Chen)。通过结构对齐学习类原型用于零样本识别。见《欧洲计算机视觉会议论文集》，第118 - 134页，2018年。

[15] Huajie Jiang, Ruiping Wang, Shiguang Shan, and Xilin Chen. Adaptive metric learning for zero-shot recognition. Signal Processing Letters, 26(9):1270-1274, 2019.

[15] 蒋华杰(Huajie Jiang)、王瑞平(Ruiping Wang)、单世广(Shiguang Shan)和陈熙霖(Xilin Chen)。用于零样本识别的自适应度量学习。《信号处理快报》，26(9):1270 - 1274，2019年。

[16] Huajie Jiang, Ruiping Wang, Shiguang Shan, Yi Yang, and Xilin Chen. Learning discriminative latent attributes for zero-shot classification. In Proc. of International Conference on Computer Vision, pages 4233-4242, 2017.

[16] 蒋华杰(Huajie Jiang)、王瑞平(Ruiping Wang)、单世广(Shiguang Shan)、杨易(Yi Yang)和陈熙霖(Xilin Chen)。学习用于零样本分类的判别性潜在属性。见《国际计算机视觉会议论文集》，第4233 - 4242页，2017年。

[17] Elyor Kodirov, Tao Xiang, and Shaogang Gong. Semantic autoencoder for zero-shot learning. In Proc. of Computer Vision and Pattern Recognition, pages 4447-4456, 2017.

[17] 埃利奥尔·科迪罗夫(Elyor Kodirov)、向涛(Tao Xiang)和龚少刚(Shaogang Gong)。用于零样本学习的语义自动编码器。见《计算机视觉与模式识别会议论文集》，第4447 - 4456页，2017年。

[18] Alex Krizhevsky, Ilya Sutskever, and Geoffrey E. Hinton. Imagenet classification with deep convolutional neural networks. In Proc. of Advances in Neural Information Processing Systems, pages 1097-1105, 2012.

[18] 亚历克斯·克里泽夫斯基(Alex Krizhevsky)、伊利亚·苏茨克维(Ilya Sutskever)和杰弗里·E·辛顿(Geoffrey E. Hinton)。使用深度卷积神经网络进行ImageNet图像分类。见《神经信息处理系统进展会议论文集》，第1097 - 1105页，2012年。

[19] Christoph H Lampert, Hannes Nickisch, and Stefan Harmel-ing. Learning to detect unseen object classes by between-class attribute transfer. In Proc. of Computer Vision and Pattern Recognition, pages 951-958, 2009.

[19] 克里斯托夫·H·兰佩特(Christoph H Lampert)、汉斯·尼克施(Hannes Nickisch)和斯特凡·哈梅林(Stefan Harmel-ing)。通过类间属性转移学习检测未见物体类别。见《计算机视觉与模式识别会议论文集》，第951 - 958页，2009年。

[20] Shichen Liu, Mingsheng Long, Jianmin Wang, and Michael I. Jordan. Generalized zero-shot learning with deep calibration network. In Proc. of Advances in Neural Information Processing Systems, pages 2005-2015, 2018.

[20] 刘世晨(Shichen Liu)、龙明盛(Mingsheng Long)、王建民(Jianmin Wang)和迈克尔·I·乔丹(Michael I. Jordan)。基于深度校准网络的广义零样本学习。见《神经信息处理系统进展会议论文集》，第2005 - 2015页，2018年。

[21] Yang Long, Li Liu, Fumin Shen, Ling Shao, and Xuelong Li. Zero-shot learning using synthesised unseen visual data with diffusion regularisation. IEEE Transactions on Pattern Analysis and Machine Intelligence, 40(10):2498-2512, 2018.

[21] 龙洋(Yang Long)、刘莉(Li Liu)、沈富敏(Fumin Shen)、邵玲(Ling Shao)和李学龙(Xuelong Li)。使用具有扩散正则化的合成未见视觉数据进行零样本学习。《IEEE模式分析与机器智能汇刊》，40(10):2498 - 2512，2018年。

[22] Tomas Mikolov, Ilya Sutskever, Kai Chen, Greg S Corrado, and Jeff Dean. Distributed representations of words and phrases and their compositionality. In Proc. of Advances in Neural Information Processing Systems, pages 3111-3119, 2013.

[22] 托马斯·米科洛夫(Tomas Mikolov)、伊利亚·苏茨克维(Ilya Sutskever)、凯·陈(Kai Chen)、格雷格·S·科拉多(Greg S Corrado)和杰夫·迪恩(Jeff Dean)。单词和短语的分布式表示及其组合性。见《神经信息处理系统进展会议论文集》，第3111 - 3119页，2013年。

[23] Pedro Morgado and Nuno Vasconcelos. Semantically consistent regularization for zero-shot recognition. In Proc. of Computer Vision and Pattern Recognition, pages 2037- 2046, 2017.

[23] 佩德罗·莫尔加多(Pedro Morgado)和努诺·瓦斯康塞洛斯(Nuno Vasconcelos)。零样本识别的语义一致正则化。见《计算机视觉与模式识别会议论文集》，第2037 - 2046页，2017年。

[24] Mohammad Norouzi, Tomas Mikolov, Samy Bengio, Yoram Singer, Jonathon Shlens, Andrea Frome, Gregory S. Corrado, and Jeffrey Dean. Zero-shot learning by convex combination of semantic embeddings. In Proc. of International Conference on Learning Representations, 2014.

[24] 穆罕默德·诺鲁兹(Mohammad Norouzi)、托马斯·米科洛夫(Tomas Mikolov)、萨米·本吉奥(Samy Bengio)、约拉姆·辛格(Yoram Singer)、乔纳森·什伦斯(Jonathon Shlens)、安德里亚·弗罗姆(Andrea Frome)、格雷戈里·S·科拉多(Gregory S. Corrado)和杰弗里·迪恩(Jeffrey Dean)。通过语义嵌入的凸组合进行零样本学习。见《国际学习表征会议论文集》，2014年。

[25] Genevieve Patterson, Chen Xu, Hang Su, and James Hays. The SUN attribute database: Beyond categories for deeper scene understanding. International Journal of Computer Vision, 108(1-2):59-81, 2014.

[25] 吉纳维芙·帕特森(Genevieve Patterson)、徐晨(Chen Xu)、苏航(Hang Su)和詹姆斯·海斯(James Hays)。SUN属性数据库:超越类别以实现更深入的场景理解。《国际计算机视觉杂志》，108(1 - 2):59 - 81，2014年。

[26] Scott Reed, Zeynep Akata, Honglak Lee, and Bernt Schiele. Learning deep representations of fine-grained visual descriptions. In Proc. of Computer Vision and Pattern Recognition, pages 49-58, 2016.

[26] 斯科特·里德(Scott Reed)、泽内普·阿卡塔(Zeynep Akata)、洪拉克·李(Honglak Lee)和伯恩特·谢勒(Bernt Schiele)。学习细粒度视觉描述的深度表示。见《计算机视觉与模式识别会议论文集》，第49 - 58页，2016年。

[27] Bernardino Romera-Paredes and Philip Torr. An embarrassingly simple approach to zero-shot learning. In Proc. of International Conference on Machine Learning, pages 2152- 2161, 2015.

[27] 贝尔纳迪诺·罗梅拉 - 帕雷德斯(Bernardino Romera - Paredes)和菲利普·托尔(Philip Torr)。一种极其简单的零样本学习方法。见《国际机器学习会议论文集》，第2152 - 2161页，2015年。

[28] Olga Russakovsky, Jia Deng, Hao Su, Jonathan Krause, Sanjeev Satheesh, Sean Ma, Zhiheng Huang, Andrej Karpathy,

[28] 奥尔加·拉萨科夫斯基(Olga Russakovsky)、邓嘉(Jia Deng)、苏浩(Hao Su)、乔纳森·克劳斯(Jonathan Krause)、桑杰夫·萨特西(Sanjeev Satheesh)、肖恩·马(Sean Ma)、黄志恒(Zhiheng Huang)、安德烈·卡帕西(Andrej Karpathy)

Aditya Khosla, Michael Bernstein, Alexander C. Berg, and

阿迪蒂亚·科斯拉(Aditya Khosla)、迈克尔·伯恩斯坦(Michael Bernstein)、亚历山大·C·伯格(Alexander C. Berg)和

Li Fei-Fei. Imagenet large scale visual recognition challenge. International Journal of Computer Vision, 115(3):211-252, 2015.

李菲菲(Li Fei - Fei)。ImageNet大规模视觉识别挑战赛。《国际计算机视觉杂志》，115(3):211 - 252，2015年。

[29] Yutaro Shigeto, Ikumi Suzuki, Kazuo Hara, Masashi Shim-bo, and Yuji Matsumoto. Ridge regression, hubness, and zero-shot learning. In Joint European Conference on Machine Learning and Knowledge Discovery in Databases, pages 135-151, 2015.

[29] 重藤裕太郎(Yutaro Shigeto)、铃木郁美(Ikumi Suzuki)、原和夫(Kazuo Hara)、岛本正志(Masashi Shim - bo)和松本雄二(Yuji Matsumoto)。岭回归、枢纽性与零样本学习。见《欧洲机器学习与数据库知识发现联合会议论文集》，第135 - 151页，2015年。

[30] Karen Simonyan and Andrew Zisserman. Very deep convolutional networks for large-scale image recognition. CoRR, abs/1409.1556, 2014.

[30] 凯伦·西蒙扬(Karen Simonyan)和安德鲁·齐斯曼(Andrew Zisserman)。用于大规模图像识别的非常深的卷积网络。计算机研究报告，abs/1409.1556，2014年。

[31] Richard Socher, Milind Ganjoo, Hamsa Sridhar, Osbert Bas-tani, Christopher D. Manning, and Andrew Y. Ng. Zero-shot learning through cross-modal transfer. In Proc. of Advances in Neural Information Processing Systems, pages 935-943, 2013.

[31] 理查德·索切尔(Richard Socher)、米林德·甘朱(Milind Ganjoo)、哈姆萨·斯里达尔(Hamsa Sridhar)、奥斯伯特·巴斯塔尼(Osbert Bas - tani)、克里斯托弗·D·曼宁(Christopher D. Manning)和安德鲁·Y·吴(Andrew Y. Ng)。通过跨模态转移进行零样本学习。见《神经信息处理系统进展会议论文集》，第935 - 943页，2013年。

[32] Flood Sung, Yongxin Yang, Li Zhang, Tao Xiang, Philip HS Torr, and Timothy M Hospedales. Learning to compare: Relation network for few-shot learning. In Proc. of Computer Vision and Pattern Recognition, pages 1199-1208, 2018.

[32] 宋富(Flood Sung)、杨永新(Yongxin Yang)、张立(Li Zhang)、向涛(Tao Xiang)、菲利普·H·S·托尔(Philip HS Torr)和蒂莫西·M·霍斯佩代尔斯(Timothy M Hospedales)。学习比较:用于少样本学习的关系网络。见《计算机视觉与模式识别会议论文集》，第1199 - 1208页，2018年。

[33] Christian Szegedy, Wei Liu, Yangqing Jia, Pierre Sermanet, Scott Reed, Dragomir Anguelov, Dumitru Erhan, Vincen-t Vanhoucke, and Andrew Rabinovich. Going deeper with convolutions. In Proc. of Computer Vision and Pattern Recognition, pages 1-9, 2015.

[33] 克里斯蒂安·塞格迪(Christian Szegedy)、刘伟(Wei Liu)、贾扬清(Yangqing Jia)、皮埃尔·塞尔马内特(Pierre Sermanet)、斯科特·里德(Scott Reed)、德拉戈米尔·安格洛夫(Dragomir Anguelov)、杜米特鲁·埃尔汉(Dumitru Erhan)、文森特·万霍克(Vincen-t Vanhoucke)和安德鲁·拉比诺维奇(Andrew Rabinovich)。卷积神经网络的深度探索。见《计算机视觉与模式识别会议论文集》，第1 - 9页，2015年。

[34] Catherine Wah, Steve Branson, Peter Welinder, Pietro Peron-a, and Serge Belongie. The Caltech-UCSD Birds-200-2011 Dataset. Technical Report CNS-TR-2011-001, California Institute of Technology, 2011.

[34] 凯瑟琳·瓦(Catherine Wah)、史蒂夫·布兰森(Steve Branson)、彼得·韦林德(Peter Welinder)、皮埃特罗·佩罗纳(Pietro Peron-a)和塞尔日·贝隆吉(Serge Belongie)。加州理工学院 - 加州大学圣地亚哥分校鸟类200 - 2011数据集。技术报告CNS - TR - 2011 - 001，加州理工学院，2011年。

[35] Xiaolong Wang, Yufei Ye, and Abhinav Gupta. Zero-shot recognition via semantic embeddings and knowledge graphs. In Proc. of Computer Vision and Pattern Recognition, pages 6857-6866, 2018.

[35] 王小龙(Xiaolong Wang)、叶宇飞(Yufei Ye)和阿比纳夫·古普塔(Abhinav Gupta)。通过语义嵌入和知识图谱实现零样本识别。见《计算机视觉与模式识别会议论文集》，第6857 - 6866页，2018年。

[36] Yongqin Xian, Zeynep Akata, Gaurav Sharma, Quynh N. Nguyen, Matthias Hein, and Bernt Schiele. Latent embeddings for zero-shot classification. In Proc. of Computer Vision and Pattern Recognition, pages 69-77, 2016.

[36] 冼永勤(Yongqin Xian)、泽内普·阿卡塔(Zeynep Akata)、高拉夫·夏尔马(Gaurav Sharma)、阮琼·N(Quynh N. Nguyen)、马蒂亚斯·海因(Matthias Hein)和伯恩特·席勒(Bernt Schiele)。用于零样本分类的潜在嵌入。见《计算机视觉与模式识别会议论文集》，第69 - 77页，2016年。

[37] Yongqin Xian, Christoph H. Lampert, Bernt Schiele, and Zeynep Akata. Zero-shot learning - a comprehensive evaluation of the good, the bad and the ugly. IEEE Transactions on Pattern Analysis and Machine Intelligence, 41(9):2251- 2265, 2019.

[37] 冼永勤(Yongqin Xian)、克里斯托夫·H·兰佩特(Christoph H. Lampert)、伯恩特·席勒(Bernt Schiele)和泽内普·阿卡塔(Zeynep Akata)。零样本学习——对优劣与不足的全面评估。《IEEE模式分析与机器智能汇刊》，41(9):2251 - 2265，2019年。

[38] Yongqin Xian, Tobias Lorenz, Bernt Schiele, and Zeynep Akata. Feature generating networks for zero-shot learning. In Proc. of Computer Vision and Pattern Recognition, pages 5542-5551, 2018.

[38] 冼永勤(Yongqin Xian)、托比亚斯·洛伦茨(Tobias Lorenz)、伯恩特·席勒(Bernt Schiele)和泽内普·阿卡塔(Zeynep Akata)。用于零样本学习的特征生成网络。见《计算机视觉与模式识别会议论文集》，第5542 - 5551页，2018年。

[39] Yongqin Xian, Bernt Schiele, and Zeynep Akata. Zero-shot learning - the good, the bad and the ugly. In Proc. of Computer Vision and Pattern Recognition, pages 3077-3086, 2017.

[39] 冼永勤(Yongqin Xian)、伯恩特·席勒(Bernt Schiele)和泽内普·阿卡塔(Zeynep Akata)。零样本学习——优劣与不足。见《计算机视觉与模式识别会议论文集》，第3077 - 3086页，2017年。

[40] Li Zhang, Tao Xiang, and Shaogang Gong. Learning a deep embedding model for zero-shot learning. In Proc. of Computer Vision and Pattern Recognition, pages 3010-3019, 2017.

[40] 张立(Li Zhang)、向涛(Tao Xiang)和龚少刚(Shaogang Gong)。学习用于零样本学习的深度嵌入模型。见《计算机视觉与模式识别会议论文集》，第3010 - 3019页，2017年。

[41] Ziming Zhang and Venkatesh Saligrama. Zero-shot learning via semantic similarity embedding. In Proc. of International Conference on Computer Vision, pages 4166-4174, 2015.

[41] 张子铭(Ziming Zhang)和文卡特什·萨利格拉马(Venkatesh Saligrama)。通过语义相似性嵌入实现零样本学习。见《国际计算机视觉会议论文集》，第4166 - 4174页，2015年。

[42] Ziming Zhang and Venkatesh Saligrama. Zero-shot learning via joint latent similarity embedding. In Proc. of Computer Vision and Pattern Recognition, pages 6034-6042, 2016.

[42] 张子铭(Ziming Zhang)和文卡特什·萨利格拉马(Venkatesh Saligrama)。通过联合潜在相似性嵌入实现零样本学习。见《计算机视觉与模式识别会议论文集》，第6034 - 6042页，2016年。

[43] Yizhe Zhu, Mohamed Elhoseiny, Bingchen Liu, Xi Peng, and Ahmed M. Elgammal. A generative adversarial approach for zero-shot learning from noisy texts. In Proc. of Computer Vision and Pattern Recognition, pages 1004- 1013, 2018.

[43] 朱一哲(Yizhe Zhu)、穆罕默德·埃尔霍塞尼(Mohamed Elhoseiny)、刘炳辰(Bingchen Liu)、彭熙(Xi Peng)和艾哈迈德·M·埃尔加马尔(Ahmed M. Elgammal)。一种从嘈杂文本中进行零样本学习的生成对抗方法。见《计算机视觉与模式识别会议论文集》，第1004 - 1013页，2018年。