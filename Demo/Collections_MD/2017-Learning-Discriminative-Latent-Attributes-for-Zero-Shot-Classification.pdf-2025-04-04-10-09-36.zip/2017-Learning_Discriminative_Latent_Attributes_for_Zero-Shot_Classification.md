# Learning Discriminative Latent Attributes for Zero-Shot Classification

# 零样本分类中判别性潜在属性的学习

Huajie Jiang ${}^{1,2,3}$ , Ruiping Wang ${}^{1}$ , Shiguang Shan ${}^{1}$ , Yi Yang ${}^{4}$ , Xilin Chen ${}^{1}$

蒋华杰 ${}^{1,2,3}$ ，王瑞平 ${}^{1}$ ，单世广 ${}^{1}$ ，杨易 ${}^{4}$ ，陈熙霖 ${}^{1}$

${}^{1}$ Key Laboratory of Intelligent Information Processing of Chinese Academy of Sciences (CAS), Institute of Computing Technology, CAS, Beijing, 100190, China

${}^{1}$ 中国科学院(CAS)智能信息处理重点实验室，中国科学院计算技术研究所，北京，100190，中国

${}^{2}$ Shanghai Institute of Microsystem and Information Technology, CAS, Shanghai,200050, China ${}^{3}$ ShanghaiTech University, Shanghai,200031, China ${}^{4}$ Huawei Technologies Co., Ltd., Beijing,100085, China

${}^{2}$ 中国科学院上海微系统与信息技术研究所，上海，200050，中国 ${}^{3}$ 上海科技大学，上海，200031，中国 ${}^{4}$ 华为技术有限公司，北京，100085，中国

huajie.jiang@vipl.ict.ac.cn, \{wangruiping, sgshan, xlchen\}@ict.ac.cn, yangyi16@huawei.com

huajie.jiang@vipl.ict.ac.cn, \{wangruiping, sgshan, xlchen\}@ict.ac.cn, yangyi16@huawei.com

## Abstract

## 摘要

Zero-shot learning(ZSL)aims to transfer knowledge from observed classes to the unseen classes, based on the assumption that both the seen and unseen classes share a common semantic space, among which attributes enjoy a great popularity. However, few works study whether the human-designed semantic attributes are discriminative enough to recognize different classes. Moreover, attributes are often correlated with each other, which makes it less desirable to learn each attribute independently. In this paper, we propose to learn a latent attribute space, which is not only discriminative but also semantic-preserving, to perfor-m the ZSL task. Specifically, a dictionary learning framework is exploited to connect the latent attribute space with attribute space and similarity space. Extensive experiments on four benchmark datasets show the effectiveness of the proposed approach.

零样本学习(ZSL)旨在基于可见类和不可见类共享一个公共语义空间的假设，将知识从可见类转移到不可见类，其中属性受到了广泛关注。然而，很少有研究探讨人类设计的语义属性是否足以区分不同的类别。此外，属性之间往往相互关联，这使得独立学习每个属性变得不太理想。在本文中，我们提出学习一个潜在属性空间，该空间不仅具有判别性，而且能够保留语义，以执行零样本学习任务。具体来说，我们利用字典学习框架将潜在属性空间与属性空间和相似度空间联系起来。在四个基准数据集上的大量实验证明了所提出方法的有效性。

## 1. Introduction

## 1. 引言

Visual recognition has made tremendous progress in the past few years with the rapid growing of data scales and progressing of classification methods. However, traditional approaches to visual recognition are mainly based on supervised learning, which needs large numbers of labeled samples to obtain a high performance classification model. It is well known that collecting large scale of labeled samples is difficult, especially when the required labels are fine-grained, which hinders further development of visual recognition. It is therefore important and desirable to develop recognition systems that can recognize categories with few or no labeled samples, thus ZSL approaches attract more and more attentions in the past few years.

近年来，随着数据规模的快速增长和分类方法的不断进步，视觉识别取得了巨大进展。然而，传统的视觉识别方法主要基于监督学习，需要大量的标注样本才能获得高性能的分类模型。众所周知，收集大规模的标注样本是困难的，特别是当所需的标签是细粒度的时候，这阻碍了视觉识别的进一步发展。因此，开发能够在很少或没有标注样本的情况下识别类别的识别系统是重要且可取的，因此零样本学习方法在过去几年中受到了越来越多的关注。

Inspired by the ability of humans to recognize unseen objects, ZSL aims to recognize categories that have never been seen before [17, 9]. A general assumption for ZSL is that both the seen and unseen classes share a common semantic space, where the samples and class prototypes are projected, to perform the recognition task. In terms of different mid-level representations exploited in the learning process, current ZSL approaches can be categorized into four group-s. The first group is attribute-based methods, which use attributes to build up the relationships between the seen and unseen classes [17, 9, 43, 13]. For example, attributes, such as black and furry, are shared among different animals. The cross-category property of attributes makes it possible to transfer knowledge from the seen classes to the unseen classes. The second group is text-based approaches, which automatically mine the relationships of different classes via ample text corpus [7, 10, 3, 30]. These approaches reduce the human labor for defining attributes, thus ZSL can be applied to large scale settings. The third one is based on class similarity, which directly mines the similarities between the seen and unseen classes to bridge up their relationships [23, 22, 24, 44]. The similarities may be derived from the hierarchical category structure or from the semantic descriptions of each class. The last group is to combine different mid-level representations to learn more robust relationships [11, 12, 19, 15]. These works build upon a common idea that different mid-level representations will catch complementary information of the data, which can be used to reduce the domain difference between the seen and unseen classes.

受人类识别未见物体能力的启发，零样本学习旨在识别从未见过的类别 [17, 9]。零样本学习的一个普遍假设是，可见类和不可见类共享一个公共语义空间，样本和类原型被投影到该空间中以执行识别任务。根据学习过程中使用的不同中级表示，当前的零样本学习方法可以分为四类。第一类是基于属性的方法，这些方法使用属性来建立可见类和不可见类之间的关系 [17, 9, 43, 13]。例如，像黑色和毛茸茸这样的属性在不同的动物中是共享的。属性的跨类别特性使得将知识从可见类转移到不可见类成为可能。第二类是基于文本的方法，这些方法通过大量的文本语料库自动挖掘不同类别的关系 [7, 10, 3, 30]。这些方法减少了定义属性的人力，因此零样本学习可以应用于大规模场景。第三类是基于类相似度的方法，这些方法直接挖掘可见类和不可见类之间的相似度以建立它们之间的关系 [23, 22, 24, 44]。相似度可以从层次类别结构或每个类别的语义描述中得出。最后一类是结合不同的中级表示来学习更鲁棒的关系 [11, 12, 19, 15]。这些工作基于一个共同的想法，即不同的中级表示将捕捉数据的互补信息，这些信息可用于减少可见类和不可见类之间的领域差异。

In this paper, we focus on the attribute-based approach. Traditional process for such methods mainly focuses on how to learn the semantic embeddings or what strategy to utilize to perform the recognition task. However, there are three aspects which are merely considered in previous works, as is shown in Figure 1, First, whether the human-designed semantic attributes are discriminative enough to recognize different classes. Second, whether it is reasonable to learn each attribute independently since attributes are often correlated with each other. Third, the variations within each attribute may be quite large making it difficult to learn the attribute classifiers. For the first aspect, [43] proposes to learn discriminative category-level attributes. However, these attributes are learned on fixed categories and do not care semantic meanings. When new classes appear, the class-level representations have to be relearned. For the second aspect, [14] incorporates the attribute relationships into the learning process. However, such relationships are human-defined and they are usually too complex in real world to define beforehand. For the third aspect, [15] utilizes domain adaptation approaches to finetune the attribute models. However, the target domain samples are mandatory for such models.

在本文中，我们专注于基于属性的方法。此类方法的传统流程主要关注如何学习语义嵌入，或者采用何种策略来执行识别任务。然而，如图1所示，先前的工作仅考虑了三个方面。首先，人工设计的语义属性是否足以区分不同的类别。其次，由于属性之间通常相互关联，独立学习每个属性是否合理。第三，每个属性内部的变化可能相当大，这使得学习属性分类器变得困难。对于第一个方面，文献[43]提出学习具有区分性的类别级属性。然而，这些属性是在固定类别上学习的，并不考虑语义含义。当出现新的类别时，必须重新学习类别级表示。对于第二个方面，文献[14]将属性关系纳入学习过程。然而，这些关系是人为定义的，在现实世界中通常过于复杂，难以预先定义。对于第三个方面，文献[15]利用领域自适应方法来微调属性模型。然而，此类模型需要目标领域的样本。

![0195e08b-e024-7b29-a315-1577741237ee_1_176_221_628_308_0.jpg](images/0195e08b-e024-7b29-a315-1577741237ee_1_176_221_628_308_0.jpg)

Figure 1. Motivations for learning latent attributes. Attributes in red font are not discriminative. Attributes with rectangle have large variations. Attributes connected by the double arrow are correlated with each other.

图1. 学习潜在属性的动机。红色字体的属性不具有区分性。带有矩形的属性变化较大。由双箭头连接的属性相互关联。

In order to tackle the problems described above simultaneously, we propose to learn latent attributes. Specifically, the proposed method automatically explores discriminative combinations of different attributes, where each combination is viewed as a latent attribute. On the one hand, the latent attributes are required to be discriminative enough, thus to classify different classes more reliably. On the other hand, the latent attributes should be semantic-preserving, thus to enable building up the relationships between different classes. Moreover, the attribute correlations are also implicitly considered in latent attributes. For example, furry often correlates with black and white, thus it is not favorable to learn furry alone. In contrast, our latent attributes have the ability to find the combination of furry + black and furry + white, thus the variation within each latent attribute becomes smaller than that within each attribute.

为了同时解决上述问题，我们提议学习潜在属性。具体而言，所提出的方法自动探索不同属性的有区分性的组合，其中每个组合被视为一个潜在属性。一方面，要求潜在属性具有足够的区分性，从而更可靠地对不同类别进行分类。另一方面，潜在属性应保留语义信息，从而能够建立不同类别之间的关系。此外，潜在属性还隐式地考虑了属性之间的相关性。例如，“毛茸茸的”通常与“黑色”和“白色”相关联，因此单独学习“毛茸茸的”属性是不合适的。相比之下，我们的潜在属性能够找到“毛茸茸的 + 黑色”和“毛茸茸的 + 白色”的组合，因此每个潜在属性内部的变化比每个属性内部的变化更小。

To learn the latent attribute space for performing ZSL task, we exploit dictionary learning framework to directly model the latent attribute space, where the images can be reconstructed by some latent attribute dictionary items. In order to preserve the semantic information, a linear transformation is utilized to build up the relationships between attributes and latent attributes, thus the latent attributes can be viewed as different combinations of attributes. Moreover, to make the latent attributes discriminative, seen class classifiers are utilized to classify different classes, where the probability outputs can be viewed as similarities to seen classes. Thus we can transform the image representations from the latent attribute space to the similarity space.

为了学习用于执行零样本学习(ZSL)任务的潜在属性空间，我们利用字典学习框架直接对潜在属性空间进行建模，其中图像可以由一些潜在属性字典项重建。为了保留语义信息，利用线性变换来建立属性和潜在属性之间的关系，因此潜在属性可以被视为属性的不同组合。此外，为了使潜在属性具有区分性，使用已见类别分类器对不同类别进行分类，其中概率输出可以被视为与已见类别的相似度。因此，我们可以将图像表示从潜在属性空间转换到相似度空间。

The rest of the paper is organised as follows: Section 2 discusses the related works. Section 3 describes the formulation and optimization of our proposed latent attribute dictionary (LAD) approach in detail. Section 4 extensively evaluates the proposed method on four benchmark ZSL datasets. Section 5 gives concluding remarks.

本文的其余部分组织如下:第2节讨论相关工作。第3节详细描述我们提出的潜在属性字典(LAD)方法的公式化和优化过程。第4节在四个基准ZSL数据集上对所提出的方法进行了广泛评估。第5节给出结论。

## 2. Related Work

## 2. 相关工作

In this section, we briefly review the related works on attributes and zero-shot learning.

在本节中，我们简要回顾关于属性和零样本学习的相关工作。

### 2.1. Attributes

### 2.1. 属性

Attributes are general descriptions of images and have drawn much attention in different computer vision tasks in recent years, such as image description [9], image captioning [16], image retrieval [35] and image classification [41, 21, 27]. Earlier works on attribute learning often consider it as a binary classification problem and learn each attribute independently [9]. Due to the fact that attributes are often correlated with each other, [14] incorporates the attribute relationships into the learning framework. Moreover, attributes are related to the categories, [21, 1] propose to learn attributes and the class labels jointly. As deep learning becomes increasingly popular in recent years, [8] makes an analysis about the relationship between visual attributes and different layers of convolutional networks. In order to make the attributes discriminative, [43, 29] exploit the discriminative attributes to do the classification task. However, these attributes do not have semantic meanings.

属性是对图像的一般性描述，近年来在不同的计算机视觉任务中引起了广泛关注，如图像描述[9]、图像字幕生成[16]、图像检索[35]和图像分类[41, 21, 27]。早期关于属性学习的工作通常将其视为一个二分类问题，并独立学习每个属性[9]。由于属性之间通常相互关联，文献[14]将属性关系纳入学习框架。此外，属性与类别相关，文献[21, 1]提出联合学习属性和类别标签。近年来，随着深度学习的日益普及，文献[8]分析了视觉属性与卷积网络不同层之间的关系。为了使属性具有区分性，文献[43, 29]利用具有区分性的属性进行分类任务。然而，这些属性没有语义含义。

### 2.2. Zero-Shot Learning

### 2.2. 零样本学习

ZSL tackles the problem of recognizing the classes that have never been seen before. With the growth of data scales and the difficulty of image annotation, this application is becoming increasingly popular in recent years. ZSL, first proposed by [17] and [9] in parallel, is accomplished by attributes, which utilizes the cross-category property of attributes to build up the relationships between seen and unseen classes. Then other mid-level semantic descriptions are proposed to tackle such problem, such as word vector [7, 10, 3] and class similarity [23, 22, 24, 44].

零样本学习(ZSL)解决的是识别从未见过的类别的问题。随着数据规模的增长和图像标注的难度增加，这一应用近年来越来越受欢迎。ZSL最早由文献[17]和[9]同时提出，通过属性来实现，它利用属性的跨类别特性来建立已见类别和未见类别之间的关系。随后，其他中级语义描述被提出用于解决此类问题，如词向量[7, 10, 3]和类别相似度[23, 22, 24, 44]。

An intuitive way to do zero-shot recognition is to train different attribute classifiers and recognize an image by the attribute prediction results and unseen class descriptions [17, 9]. Considering the unreliability of the attribute classifiers, [13] proposes a random forest approach to make more robust predictions and [41, 21, 40] model the relationships between attributes and classes to improve the attribute prediction results. To make use of the rich intrinsic structure on the semantic manifold, [12] proposes semantic manifold distance to recognize the unseen class samples. Another widely used approach is label embedding, which projects the images and labels into a common semantic space and performs the classification task via nearest neighbor approach [1, 2, 26, 44, 19, 42]. In order to expand ZSL to large-scale settings, [25, 10, 37, 3] use neural networks to learn more complicated non-linear embed-dings. Some other works use transfer learning techniques to transfer knowledge from seen classes to unseen classes 33, 32, 31, 37, 24, 15]. Recently, [45] proposes to capture the latent relationships between the seen and unseen classes in the similarity space. [5] proposes to synthesize the unseen class classifier directly by sharing the representations between the semantic space and feature space. [4] proposes a metric learning approach to tackle the ZSL problem. [6] expands the traditional ZSL problem to the generalized ZSL problem, where the seen classes are also considered in the test process.

一种直观的零样本识别方法是训练不同的属性分类器，并根据属性预测结果和未见类别的描述来识别图像 [17, 9]。考虑到属性分类器的不可靠性，文献 [13] 提出了一种随机森林方法以进行更稳健的预测，文献 [41, 21, 40] 对属性和类别之间的关系进行建模以改善属性预测结果。为了利用语义流形上丰富的内在结构，文献 [12] 提出了语义流形距离来识别未见类别的样本。另一种广泛使用的方法是标签嵌入，它将图像和标签投影到一个共同的语义空间中，并通过最近邻方法执行分类任务 [1, 2, 26, 44, 19, 42]。为了将零样本学习(ZSL)扩展到大规模场景，文献 [25, 10, 37, 3] 使用神经网络来学习更复杂的非线性嵌入。其他一些工作使用迁移学习技术将知识从已见类别迁移到未见类别 [33, 32, 31, 37, 24, 15]。最近，文献 [45] 提出在相似度空间中捕捉已见和未见类别之间的潜在关系。文献 [5] 提出通过共享语义空间和特征空间之间的表示直接合成未见类别的分类器。文献 [4] 提出了一种度量学习方法来解决零样本学习问题。文献 [6] 将传统的零样本学习问题扩展到广义零样本学习问题，即在测试过程中也考虑已见类别。

Another popular assumption for ZSL is that the unseen-class samples are available in the problem settings [11, 19, 15, 46]. To make use of the complementary information among different semantic descriptions, [11] proposes a multi-view embedding approach, where graph models are constructed using both the seen and unseen class samples to reduce the domain difference between seen and unseen classes. [19] proposes a semi-supervised framework to learn the unseen classifiers directly where semantic information can be incorporated as side information. [15] utilizes domain adaption approaches to tackle the domain shift problem between seen and unseen classes. Inspired by the clustering property of samples within one category, [46] leverages the structured prediction approach to recognize the unseen class samples. It is important to point out that our approach is not in such settings.

零样本学习的另一个流行假设是，在问题设置中可以获取未见类别的样本 [11, 19, 15, 46]。为了利用不同语义描述之间的互补信息，文献 [11] 提出了一种多视图嵌入方法，其中使用已见和未见类别的样本构建图模型，以减少已见和未见类别之间的领域差异。文献 [19] 提出了一个半监督框架，直接学习未见类别的分类器，其中语义信息可以作为辅助信息纳入。文献 [15] 利用领域自适应方法来解决已见和未见类别之间的领域偏移问题。受同一类别内样本的聚类特性启发，文献 [46] 利用结构化预测方法来识别未见类别的样本。需要指出的是，我们的方法并不处于这样的设置中。

## 3. Proposed Approach

## 3. 所提方法

We propose a latent attribute dictionary (LAD) learning process for ZSL. There are some motivations to design the objective function. First, the latent attributes should preserve the semantic information, and thus are able to relate the seen and unseen classes. Second, the representations in the latent attribute space should be discriminative to recognize different classes. Based on these considerations, a framework proposed for LAD is shown in Figure 2

我们为零样本学习提出了一种潜在属性字典(LAD)学习过程。设计目标函数有一些动机。首先，潜在属性应该保留语义信息，从而能够关联已见和未见类别。其次，潜在属性空间中的表示应该具有区分性，以识别不同的类别。基于这些考虑，图 2 展示了为潜在属性字典提出的一个框架。

### 3.1. Problem Formulation

### 3.1. 问题表述

Suppose there are ${c}_{s}$ seen classes with ${n}_{s}$ labeled samples ${\Phi }_{s} = \left\{  {{X}_{s},{A}_{s},{Z}_{s}}\right\}$ and ${c}_{u}$ unseen classes with ${n}_{u}$ unlabeled samples ${\Phi }_{u} = \left\{  {{X}_{u},{A}_{u},{Z}_{u}}\right\}$ . Each sample ${x}_{i}$ is represented as a $d$ -dimensional feature vector. Then we have ${X}_{s} \in  {\mathbb{R}}^{d \times  {n}_{s}}$ and ${X}_{u} \in  {\mathbb{R}}^{d \times  {n}_{u}}$ , where ${X}_{s} =$ $\left\lbrack  {{\mathbf{x}}_{\mathbf{1}},\ldots ,{\mathbf{x}}_{{\mathbf{n}}_{s}}}\right\rbrack$ and ${X}_{u} = \left\lbrack  {{\mathbf{x}}_{\mathbf{1}},\ldots ,{\mathbf{x}}_{{\mathbf{n}}_{u}}}\right\rbrack  .{Z}_{s}$ and ${Z}_{u}$ are the class labels of the seen and unseen class samples. In zero-shot recognition settings, the seen and unseen classes are disjoint: ${Z}_{s} \cap  {Z}_{u} = \varnothing .{A}_{s}$ and ${A}_{u}$ are the $m$ -dimensional semantic representations (i.e. attribute annotations) of seen and unseen class samples, where ${A}_{s} \in  {\mathbb{R}}^{m \times  {n}_{s}}$ and ${A}_{u} \in$ ${\mathbb{R}}^{m \times  {n}_{u}}$ . The semantic information about the seen class samples ${A}_{s}$ is provided and that for the unseen class samples ${A}_{u}$ is unknown. Given the semantic descriptions of the classes $P \in  {\mathbb{R}}^{m \times  \left( {{c}_{s} + {c}_{u}}\right) }$ , the goal of ZSL is to predict ${Z}_{u}$ .

假设存在 ${c}_{s}$ 个已见类别(seen classes)，包含 ${n}_{s}$ 个带标签样本 ${\Phi }_{s} = \left\{  {{X}_{s},{A}_{s},{Z}_{s}}\right\}$，以及 ${c}_{u}$ 个未见类别(unseen classes)，包含 ${n}_{u}$ 个无标签样本 ${\Phi }_{u} = \left\{  {{X}_{u},{A}_{u},{Z}_{u}}\right\}$。每个样本 ${x}_{i}$ 由一个 $d$ 维的特征向量表示。那么我们有 ${X}_{s} \in  {\mathbb{R}}^{d \times  {n}_{s}}$ 和 ${X}_{u} \in  {\mathbb{R}}^{d \times  {n}_{u}}$，其中 ${X}_{s} =$ $\left\lbrack  {{\mathbf{x}}_{\mathbf{1}},\ldots ,{\mathbf{x}}_{{\mathbf{n}}_{s}}}\right\rbrack$ 以及 ${X}_{u} = \left\lbrack  {{\mathbf{x}}_{\mathbf{1}},\ldots ,{\mathbf{x}}_{{\mathbf{n}}_{u}}}\right\rbrack  .{Z}_{s}$ 和 ${Z}_{u}$ 分别是已见类别和未见类别样本的类别标签。在零样本识别(zero-shot recognition)设置中，已见类别和未见类别是不相交的:${Z}_{s} \cap  {Z}_{u} = \varnothing .{A}_{s}$ 和 ${A}_{u}$ 分别是已见类别和未见类别样本的 $m$ 维语义表示(即属性注释)，其中 ${A}_{s} \in  {\mathbb{R}}^{m \times  {n}_{s}}$ 且 ${A}_{u} \in$ ${\mathbb{R}}^{m \times  {n}_{u}}$。已见类别样本 ${A}_{s}$ 的语义信息是已知的，而未见类别样本 ${A}_{u}$ 的语义信息是未知的。给定类别 $P \in  {\mathbb{R}}^{m \times  \left( {{c}_{s} + {c}_{u}}\right) }$ 的语义描述，零样本学习(ZSL)的目标是预测 ${Z}_{u}$。

![0195e08b-e024-7b29-a315-1577741237ee_2_928_211_636_327_0.jpg](images/0195e08b-e024-7b29-a315-1577741237ee_2_928_211_636_327_0.jpg)

Figure 2. The latent attribute dictionary learning framework for ZSL. The proposed latent attribute space is connected with both the attribute space and the similarity space. The attribute space makes the latent attributes semantic-preserving and the similarity space makes the latent attributes discriminative.

图 2. 用于零样本学习(ZSL)的潜在属性字典学习框架。所提出的潜在属性空间与属性空间和相似度空间都相连接。属性空间使潜在属性能够保留语义信息，而相似度空间使潜在属性具有判别性。

### 3.2. Latent Attribute Dictionary Learning

### 3.2. 潜在属性字典学习

The key issue to perform ZSL task is to find a common space which can build up the relationship between seen and unseen classes. Traditional approaches select the attribute space to perform the recognition task. For example, [15] proposes to learn the attribute dictionary directly as :

执行零样本学习(ZSL)任务的关键问题是找到一个能够建立已见类别和未见类别之间关系的公共空间。传统方法选择属性空间来执行识别任务。例如，文献 [15] 提出直接学习属性字典，如下所示:

$$
\arg \mathop{\min }\limits_{{D,{Y}_{s}}}{\begin{Vmatrix}{X}_{s} - D{Y}_{s}\end{Vmatrix}}_{F}^{2},\;\text{ s.t. }\;{\begin{Vmatrix}{d}_{i}\end{Vmatrix}}_{2}^{2} \leq  1,\forall i, \tag{1}
$$

where $\parallel .{\parallel }_{F}$ denotes the Frobenius norm, ${d}_{i}$ is the $i$ th colum- $\mathrm{n}$ of the learned dictionary $D$ , and ${Y}_{s}$ is the reconstruction coefficient. By forcing ${Y}_{s}$ to be ${A}_{s}$ , the learned dictionary are viewed as representations of the attributes. However, this constraint is too strong. If we relax the semantic constraint and the objective function can be formulated as:

其中 $\parallel .{\parallel }_{F}$ 表示弗罗贝尼乌斯范数(Frobenius norm)，${d}_{i}$ 是所学习字典 $D$ 的第 $i$ 列 $\mathrm{n}$，${Y}_{s}$ 是重构系数。通过强制 ${Y}_{s}$ 为 ${A}_{s}$，所学习的字典被视为属性的表示。然而，这种约束条件太强。如果我们放宽语义约束，目标函数可以表述为:

$$
\arg \mathop{\min }\limits_{{D,{Y}_{s}}}{\begin{Vmatrix}{X}_{s} - D{Y}_{s}\end{Vmatrix}}_{F}^{2} + \alpha {\begin{Vmatrix}{Y}_{s} - {A}_{s}\end{Vmatrix}}_{F}^{2}, \tag{2}
$$

$$
\text{ s.t. }{\begin{Vmatrix}{d}_{i}\end{Vmatrix}}_{2}^{2} \leq  1,\forall i\text{. }
$$

The second term in Eq. 2 encourages ${Y}_{s}$ to be similar to the attribute representations ${A}_{s}$ , thus to ensure that the learned bases depict attribute dictionary items.

公式 2 中的第二项促使 ${Y}_{s}$ 与属性表示 ${A}_{s}$ 相似，从而确保所学习的基能够描述属性字典项。

Although attributes are widely used in the recognition task, there are two things that should be considered. First, thrst, the user-defined attributes are not always the same important for discrimination, thus it may be less desirable to learn each attribute directly. Second, there are correlations among the attributes, thus it is not suitable to learn each attribute independently. To address such problems, we propose to learn latent attributes. Specifically, we use dictionary learning framework to model the latent attribute space directly. To preserve the semantic information, a linear transformation matrix $W$ is utilized to build up the relationship between latent attributes and attributes, as is shown in Figure 2:

尽管属性在识别任务中被广泛使用，但有两个方面需要考虑。首先，用户定义的属性对于判别来说并非总是同等重要，因此直接学习每个属性可能不太理想。其次，属性之间存在相关性，因此独立学习每个属性并不合适。为了解决这些问题，我们提出学习潜在属性。具体来说，我们使用字典学习框架直接对潜在属性空间进行建模。为了保留语义信息，如图 2 所示，利用一个线性变换矩阵 $W$ 来建立潜在属性和属性之间的关系:

$$
\arg \mathop{\min }\limits_{{D,{Y}_{s}, W}}{\begin{Vmatrix}{X}_{s} - D{Y}_{s}\end{Vmatrix}}_{F}^{2} + \alpha {\begin{Vmatrix}{Y}_{s} - W{A}_{s}\end{Vmatrix}}_{F}^{2}, \tag{3}
$$

$$
\text{ s.t. }{\begin{Vmatrix}{d}_{i}\end{Vmatrix}}_{2}^{2} \leq  1,\;{\begin{Vmatrix}{w}_{i}\end{Vmatrix}}_{2}^{2} \leq  1,\forall i,
$$

where ${w}_{i}$ is the $i$ th column of $W$ . It can be inferred from Eq. 3 that the latent attributes can be viewed as linear combinations of the semantic attributes, which will implicitly combine strongly correlated attributes.

其中 ${w}_{i}$ 是 $W$ 的第 $i$ 列。从公式3可以推断出，潜在属性可以看作是语义属性的线性组合，这将隐式地组合强相关的属性。

In order to make more effective recognition task, the latent attributes should be discriminative. In other words, we want to find the most discriminative attribute combinations to classify different categories. Thus we utilize the seen-class classifiers to make the latent attributes more discriminative. Specifically, a linear mapping $U$ is learned from the latent attribute space to the seen categories, as is shown in Figure 2.

为了使识别任务更有效，潜在属性应该具有区分性。换句话说，我们希望找到最具区分性的属性组合来对不同类别进行分类。因此，我们利用已见类别的分类器使潜在属性更具区分性。具体来说，从潜在属性空间到已见类别学习一个线性映射 $U$，如图2所示。

$$
\arg \mathop{\min }\limits_{{D,{Y}_{s}, W, U}}{\begin{Vmatrix}{X}_{s} - D{Y}_{s}\end{Vmatrix}}_{F}^{2} + \alpha {\begin{Vmatrix}{Y}_{s} - W{A}_{s}\end{Vmatrix}}_{F}^{2}
$$

$$
+ \beta {\begin{Vmatrix}H - U{Y}_{s}\end{Vmatrix}}_{F}^{2}, \tag{4}
$$

$$
\text{s.t.}\;{\begin{Vmatrix}{d}_{i}\end{Vmatrix}}_{2}^{2} \leq  1,\;{\begin{Vmatrix}{w}_{i}\end{Vmatrix}}_{2}^{2} \leq  1,\;{\begin{Vmatrix}{u}_{i}\end{Vmatrix}}_{2}^{2} \leq  1,\forall i,
$$

where $H = \left\lbrack  {{h}_{1},{h}_{2},\ldots ,{h}_{{n}_{s}}}\right\rbrack   \in  {\mathbb{R}}^{{c}_{s} \times  {n}_{s}}$ and ${h}_{i} =$ ${\left\lbrack  0\ldots {010}\ldots 0\right\rbrack  }^{T}$ is a one hot vector which shows the class label of sample ${x}_{i}$ . Here the column vectors ${h}_{i}$ of $H$ form the similarity space ${\mathbb{R}}^{{c}_{s}}$ , where each dimension represents the similarity to one seen class. $U$ can be viewed as seen-class classifiers in the latent attribute space. The third term in Eq. 4 aims to make the latent attribute representations discriminative enough to classify different classes. It implicitly pulls samples from the same class together and pushes those from different classes away from each other.

其中 $H = \left\lbrack  {{h}_{1},{h}_{2},\ldots ,{h}_{{n}_{s}}}\right\rbrack   \in  {\mathbb{R}}^{{c}_{s} \times  {n}_{s}}$ 和 ${h}_{i} =$ ${\left\lbrack  0\ldots {010}\ldots 0\right\rbrack  }^{T}$ 是一个独热向量，它表示样本 ${x}_{i}$ 的类别标签。这里 $H$ 的列向量 ${h}_{i}$ 构成了相似度空间 ${\mathbb{R}}^{{c}_{s}}$，其中每个维度表示与一个已见类别的相似度。$U$ 可以看作是潜在属性空间中的已见类别分类器。公式4中的第三项旨在使潜在属性表示具有足够的区分性，以便对不同类别进行分类。它隐式地将同一类别的样本拉到一起，并将不同类别的样本推开。

In summary, the latent attributes learned by the proposed method are not only discriminative to classify different classes but also semantic-preserving. As is shown in Figure 2, the resulted latent attribute space is connected with two kinds of semantic spaces. First, a linear transformation matrix $W$ is utilized to connect the latent attribute space with the semantic attribute space. Through this transformation matrix, we can recover the attribute representations by the latent attributes, thus the latent attributes have semantic meanings. Second, the category classifiers $U$ in the latent attribute space can be viewed as the connection between latent attribute space and the similarity space. This constraint encourages the latent attributes to be discriminative.

综上所述，所提出的方法学习到的潜在属性不仅具有区分不同类别的能力，还能保留语义信息。如图2所示，得到的潜在属性空间与两种语义空间相连。首先，利用一个线性变换矩阵 $W$ 将潜在属性空间与语义属性空间相连。通过这个变换矩阵，我们可以通过潜在属性恢复属性表示，因此潜在属性具有语义含义。其次，潜在属性空间中的类别分类器 $U$ 可以看作是潜在属性空间与相似度空间之间的连接。这种约束促使潜在属性具有区分性。

### 3.3. Optimization

### 3.3. 优化

It is obvious that Eq. 4 is not convex for $D,{Y}_{s}, W$ and $U$ simultaneously, but it is convex for each of them separately. We thus employ an alternating optimization method to solve it. In particular, we alternate between the following subproblems:

显然，公式4对于 $D,{Y}_{s}, W$ 和 $U$ 同时来说不是凸函数，但对于它们各自来说是凸函数。因此，我们采用交替优化方法来求解它。具体来说，我们在以下子问题之间交替进行:

(1) Fix $D, W, U$ and update the latent attribute representations ${Y}_{s}$ . The subproblem can be formulated as:

(1) 固定 $D, W, U$ 并更新潜在属性表示 ${Y}_{s}$。该子问题可以表述为:

$$
\arg \mathop{\min }\limits_{{Y}_{s}}{\begin{Vmatrix}\widetilde{X} - \widetilde{D}{Y}_{s}\end{Vmatrix}}_{F}^{2}, \tag{5}
$$

where

其中

$$
\widetilde{X} = \left\lbrack  \begin{matrix} {X}_{s} \\  {\alpha W}{A}_{s} \\  {\beta H} \end{matrix}\right\rbrack  ,\widetilde{D} = \left\lbrack  \begin{matrix} {D}_{s} \\  {\alpha I} \\  {\beta U} \end{matrix}\right\rbrack  ,
$$

and $I$ is the identity matrix. Forcing the derivative of Eq. 5 to be 0 and the closed-form solution for ${Y}_{s}$ is

并且 $I$ 是单位矩阵。令公式5的导数为0，${Y}_{s}$ 的闭式解为

$$
{Y}_{s} = {\left( {\widetilde{D}}^{T}\widetilde{D}\right) }^{-1}{\widetilde{D}}^{T}\widetilde{X}. \tag{6}
$$

(2) Fix ${Y}_{s}, W, U$ and update the latent attribute dictionary $D$ . The subproblem can be formulated as:

(2) 固定 ${Y}_{s}, W, U$ 并更新潜在属性字典 $D$。该子问题可以表述为:

$$
\arg \mathop{\min }\limits_{D}{\begin{Vmatrix}{X}_{s} - D{Y}_{s}\end{Vmatrix}}_{F}^{2},\;\text{ s.t. }\;{\begin{Vmatrix}{d}_{i}\end{Vmatrix}}_{2}^{2} \leq  1. \tag{7}
$$

This problem can be optimized by the Lagrange dual. Thus the analytical solution for Eq. 7 is

这个问题可以通过拉格朗日对偶进行优化。因此，公式7的解析解为

$$
D = \left( {{X}_{s}{Y}_{s}^{T}}\right) {\left( {Y}_{s}{Y}_{s}^{T} + \Lambda \right) }^{-1}, \tag{8}
$$

where $\Lambda$ is a diagonal matrix constructed by all the Lagrange dual variables.

其中 $\Lambda$ 是一个由所有拉格朗日对偶变量构成的对角矩阵。

(3) Fix $D,{Y}_{s}, U$ and update the embedding $W$ . The subproblem can be formulated as:

(3) 固定 $D,{Y}_{s}, U$ 并更新嵌入 $W$。该子问题可以表述为:

$$
\arg \mathop{\min }\limits_{W}{\begin{Vmatrix}{Y}_{s} - W{A}_{s}\end{Vmatrix}}_{F}^{2},\;\text{ s.t. }\;{\begin{Vmatrix}{w}_{i}\end{Vmatrix}}_{2}^{2} \leq  1. \tag{9}
$$

This problem can be solved in the same way as Eq. 7. The analytical solution for $W$ is

这个问题可以用与公式7相同的方法求解。$W$ 的解析解为

$$
W = \left( {{Y}_{s}{A}_{s}^{T}}\right) {\left( {A}_{s}{A}_{s}^{T} + \Lambda \right) }^{-1}, \tag{10}
$$

where $\Lambda$ is a diagonal matrix constructed by all the Lagrange dual variables.

其中 $\Lambda$ 是一个由所有拉格朗日对偶变量构成的对角矩阵。

(4) Fix $D,{Y}_{s}, W$ and update the embedding $U$ . The subproblem can be formulated as:

(4) 固定 $D,{Y}_{s}, W$ 并更新嵌入 $U$。该子问题可以表述为:

$$
\arg \mathop{\min }\limits_{U}{\begin{Vmatrix}H - U{Y}_{s}\end{Vmatrix}}_{F}^{2},\;\text{ s.t. }\;{\begin{Vmatrix}{u}_{i}\end{Vmatrix}}_{2}^{2} \leq  1. \tag{11}
$$

This problem can be solved in the same way as Eq. 7. The analytical solution for $U$ is

这个问题可以用与方程7相同的方法解决。$U$的解析解为

$$
U = \left( {H{Y}_{s}^{T}}\right) {\left( {Y}_{s}{Y}_{s}^{T} + \Lambda \right) }^{-1}, \tag{12}
$$

where $\Lambda$ is a diagonal matrix constructed by all the Lagrange dual variables.

其中，$\Lambda$是一个由所有拉格朗日对偶变量构成的对角矩阵。

Algorithm 1 Latent Attribute Dictionary Learning for ZSL

算法1 零样本学习(ZSL)的潜在属性字典学习

---

Input: ${X}_{s},{A}_{s},\alpha ,\beta$

输入:${X}_{s},{A}_{s},\alpha ,\beta$

Output: $D,{Y}_{s}, W$ and $U$

输出:$D,{Y}_{s}, W$和$U$

	Initialize $D, W, U$ randomly.

	随机初始化$D, W, U$。

	while not converge do

	while未收敛时

		Update ${Y}_{s}$ by Eq. 6

		根据方程6更新${Y}_{s}$

		Update $D$ by Eq. 8

		根据方程8更新$D$

		Update $W$ by Eq. 10

		根据方程10更新$W$

		Update $U$ by Eq. 12

		根据方程12更新$U$

	end while

	end while

---

The complete algorithm is summarized in Algorithm 1 In our experiments, the optimization process always converges after tens of iterations, usually less than ${50}{}^{1}$ .

完整的算法总结在算法1中。在我们的实验中，优化过程总是在几十次迭代后收敛，通常少于${50}{}^{1}$次。

#### 3.4.ZSL Recognition

#### 3.4. 零样本学习识别

Since our latent attribute space is associated with attribute space and similarity space, we can perform ZSL in multiple spaces.

由于我们的潜在属性空间与属性空间和相似度空间相关联，我们可以在多个空间中进行零样本学习。

Recognition in the latent attribute space. In order to perform ZSL in the latent attribute space, we must obtain the latent attribute representations of the test samples and the unseen class prototypes. Given a test sample with its feature vector ${x}^{u}$ , we obtain its latent attribute representation ${y}^{u}$ by

潜在属性空间中的识别。为了在潜在属性空间中进行零样本学习，我们必须获得测试样本和未见类别原型的潜在属性表示。给定一个特征向量为${x}^{u}$的测试样本，我们通过以下方式获得其潜在属性表示${y}^{u}$

$$
{y}^{u} = \mathop{\min }\limits_{{y}^{u}}{\begin{Vmatrix}{x}^{u} - D{y}^{u}\end{Vmatrix}}_{F}^{2} + \gamma {\begin{Vmatrix}{y}^{u}\end{Vmatrix}}_{2}^{2}, \tag{13}
$$

where $D$ is the latent attribute dictionary learned from the training data. $\gamma$ is a weight for regularization term. For the unseen class prototypes, we project their attribute representations to the latent attribute space by the transformation matrix $W$ . Then the distance between the test sample and the unseen classes can be computed. In the end, we perfor- $\mathrm{m}$ ZSL recognition by nearest neighbour approach using the cosine distance.

其中 $D$ 是从训练数据中学习到的潜在属性字典。$\gamma$ 是正则化项的权重。对于未见类原型，我们通过变换矩阵 $W$ 将它们的属性表示投影到潜在属性空间。然后可以计算测试样本与未见类之间的距离。最后，我们使用余弦距离通过最近邻方法执行 $\mathrm{m}$ 零样本学习(ZSL)识别。

Recognition in the similarity space. As is described above, we can use $U$ to transform the latent attribute representations ${y}^{u}$ to the similarity space, where each dimension represents the similarity to one seen class. Thus each image can be denoted by a similarity vector $h$ . Moreover, we can also obtain the similarity representation of an unseen class prototype by mapping the class attribute vectors to histogram representations of seen class proportions, as similarly done in [44]. Thus nearest neighbour approach can be performed to classify a test sample to an unseen class.

在相似度空间中进行识别。如上所述，我们可以使用 $U$ 将潜在属性表示 ${y}^{u}$ 转换到相似度空间，其中每个维度表示与一个已见类的相似度。因此，每个图像可以用一个相似度向量 $h$ 表示。此外，我们还可以通过将类属性向量映射到已见类比例的直方图表示来获得未见类原型的相似度表示，这与文献 [44] 中的做法类似。因此，可以执行最近邻方法将测试样本分类到未见类。

Recognition in the attribute space. We can recover the attribute representation of an image ${a}^{u}$ by its latent attribute representation ${y}^{u}$ :

在属性空间中进行识别。我们可以通过图像的潜在属性表示 ${y}^{u}$ 恢复其属性表示 ${a}^{u}$:

$$
{a}^{u} = \mathop{\min }\limits_{{a}^{u}}{\begin{Vmatrix}{y}^{u} - W{a}^{u}\end{Vmatrix}}_{F}^{2} + \lambda {\begin{Vmatrix}{a}^{u}\end{Vmatrix}}_{2}^{2}. \tag{14}
$$

Thus the attributes of each image can be obtained. Then we can classify a test image to an unseen class by the attribute representations.

这样就可以获得每个图像的属性。然后我们可以通过属性表示将测试图像分类到未见类。

Combining multiple spaces. Since different spaces may contain complementary information of an unseen class, we can combine different spaces to perform the ZSL task. In this paper, we simply concatenate different vector representations of an image to form the final representation and the same process is done for the unseen class prototype-s. Then ZSL task can be performed by the same approach proposed above.

结合多个空间。由于不同的空间可能包含未见类的互补信息，我们可以结合不同的空间来执行零样本学习(ZSL)任务。在本文中，我们简单地将图像的不同向量表示连接起来形成最终表示，并对未见类原型执行相同的过程。然后可以通过上述相同的方法执行零样本学习(ZSL)任务。

### 3.5. Discussion

### 3.5. 讨论

Difference from other works. Our approach is mainly inspired by JLSE [45] and JSLA [29]. JLSE proposes the latent similarity space to build up the relation between feature space and similarity space, while we utilize the similarity space to make our latent attributes more discriminative. JSLA proposes to learn user-defined attributes and discriminative attributes separately, where background information is also modeled. However, it is not designed for ZSL task since background information can not be utilized in ZSL settings. In contrast, we embark from the actual problems that exist in ZSL task and merge the semantic and discriminative information into the latent attributes aiming to make more effective recognition.

与其他工作的差异。我们的方法主要受到联合潜在空间嵌入(JLSE)[45] 和联合语义学习与对齐(JSLA)[29] 的启发。联合潜在空间嵌入(JLSE)提出了潜在相似度空间来建立特征空间和相似度空间之间的关系，而我们利用相似度空间使我们的潜在属性更具判别性。联合语义学习与对齐(JSLA)提出分别学习用户定义的属性和判别性属性，其中还对背景信息进行了建模。然而，它不是为零样本学习(ZSL)任务设计的，因为在零样本学习(ZSL)设置中无法利用背景信息。相比之下，我们从零样本学习(ZSL)任务中存在的实际问题出发，将语义信息和判别性信息融合到潜在属性中，旨在实现更有效的识别。

Further improvements. The proposed approach is based on linear models. It is well known that deep learning based nonlinear models would be more powerful. Thus we use the deep network to extract the image representations and ensure favorable performance to a large extent. It is believed that learning the semantic transformation directly through a deep model will help to boost the performance and this remains a promising direction for our future work.

进一步改进。所提出的方法基于线性模型。众所周知，基于深度学习的非线性模型会更强大。因此，我们使用深度网络提取图像表示，并在很大程度上确保了良好的性能。相信通过深度模型直接学习语义变换将有助于提高性能，这仍然是我们未来工作的一个有前景的方向。

## 4. Experiments

## 4. 实验

In this section, we evaluate the proposed method on four benchmark datasets and then analyze the effectiveness of the method.

在本节中，我们在四个基准数据集上评估所提出的方法，然后分析该方法的有效性。

### 4.1. Datasets and Settings

### 4.1. 数据集和设置

Datasets. We perform experiments on four benchmark ZSL datasets to verify the effectiveness of the proposed method, i.e. aPascal & aYahoo (aP&Y) [9], Animal-s with Attributes (AwA) [17], Caltech-UCSD Birds-200- 2011 (CUB-200) [39], and SUN Attribute (SUN-A) [28]. The statistics of these datasets are shown in Table 1 (a) aP&Y consists of two attribute datasets: aPascal contain-s 12,695 images and aYahoo has 2,644 images. A 64-D attribute vector is provided for each image. There are 20 object classes for aPascal and 12 for aYahoo, which are disjoint. For ZSL task, the categories in aPascal dataset are used as seen classes and those in aYahoo are used as unseen classes. (b) AwA is an animal dataset, which contains 50 animal categories, with 30,475 images. There are 85 attributes annotated for each class. The standard split for ZSL is to use 40 categories as seen classes and the other 10 categories as unseen classes. (c) CUB-200 is a bird dataset for fine-grained recognition. It contains 200 classes with 11,788 images, where 312 binary attributes are provided for each image. Following the same setting as [1], we take 150 categories as seen classes and the other 50 as unseen classes. (d) SUN-A is created for high-level scene understanding and fine-grained scene recognition, which contains 717 classes with 14,340 images collected. There are 102 real-valued attribute annotations for each image, which are produced by a voting process. Following [13], we select the same 10 classes as unseen classes.

数据集。我们在四个基准零样本学习(ZSL)数据集上进行实验，以验证所提出方法的有效性，即 aPascal & aYahoo(aP&Y)[9]、带属性的动物(AwA)[17]、加州理工学院 - 加州大学圣地亚哥分校鸟类 200 - 2011(CUB - 200)[39] 和 SUN 属性(SUN - A)[28]。这些数据集的统计信息如表 1 所示。(a) aP&Y 由两个属性数据集组成:aPascal 包含 12,695 张图像，aYahoo 有 2,644 张图像。为每张图像提供一个 64 维的属性向量。aPascal 有 20 个目标类别，aYahoo 有 12 个目标类别，它们是不相交的。对于零样本学习(ZSL)任务，aPascal 数据集中的类别用作已见类，aYahoo 中的类别用作未见类。(b) AwA 是一个动物数据集，包含 50 个动物类别，有 30,475 张图像。为每个类别标注了 85 个属性。零样本学习(ZSL)的标准划分是使用 40 个类别作为已见类，另外 10 个类别作为未见类。(c) CUB - 200 是一个用于细粒度识别的鸟类数据集。它包含 200 个类别，有 11,788 张图像，为每张图像提供 312 个二进制属性。遵循与文献 [1] 相同的设置，我们将 150 个类别作为已见类，另外 50 个作为未见类。(d) SUN - A 是为高级场景理解和细粒度场景识别而创建的，它包含 717 个类别，收集了 14,340 张图像。为每张图像提供 102 个实值属性注释，这些注释是通过投票过程产生的。遵循文献 [13]，我们选择相同的 10 个类别作为未见类。

---

${}^{1}$ The source code of the proposed ${LAD}$ approach is available at http://vipl.ict.ac.cn/resources/codes.

${}^{1}$ 所提出的 ${LAD}$ 方法的源代码可在 http://vipl.ict.ac.cn/resources/codes 获得。

---

Table 1. Statistics of different datasets, where 'b' and 'c' stand for binary value and continuous value respectively.

表1. 不同数据集的统计信息，其中“b”和“c”分别代表二进制值(binary value)和连续值(continuous value)。

<table><tr><td>Database</td><td>Instance</td><td>Attributes</td><td>Seen/Unseen</td></tr><tr><td>aP&Y</td><td>15,339</td><td>64(c)</td><td>20 / 12</td></tr><tr><td>$\mathbf{{AwA}}$</td><td>30,475</td><td>85(c)</td><td>40 / 10</td></tr><tr><td>CUB-200</td><td>11,788</td><td>312(b)</td><td>150 / 50</td></tr><tr><td>SUN-A</td><td>14,340</td><td>102(c)</td><td>707 / 10</td></tr></table>

<table><tbody><tr><td>数据库(Database)</td><td>实例(Instance)</td><td>属性(Attributes)</td><td>已查看/未查看(Seen/Unseen)</td></tr><tr><td>aP&Y</td><td>15,339</td><td>64(c)</td><td>20 / 12</td></tr><tr><td>$\mathbf{{AwA}}$</td><td>30,475</td><td>85(c)</td><td>40 / 10</td></tr><tr><td>CUB - 200</td><td>11,788</td><td>312(b)</td><td>150 / 50</td></tr><tr><td>SUN - A</td><td>14,340</td><td>102(c)</td><td>707 / 10</td></tr></tbody></table>

Parameter Settings. For all the datasets, we utilize the 4096-dimension CNN feature vectors extracted by the imagenet-vgg-verydeep-19 pre-trained model [36]. We use the multi-class accuracy as the evaluation metric. The dictionary size for $\mathbf{{AwA}}$ is chosen as 300 and those for the other three datasets are 500 to 800 . Other parameters $\alpha$ and $\beta$ are obtained using five-fold cross-validation. $\gamma$ and $\lambda$ can also be tuned and we set them to be 1 for simplicity. More details can be found in the supplementary material.

参数设置。对于所有数据集，我们使用由imagenet - vgg - verydeep - 19预训练模型[36]提取的4096维卷积神经网络(CNN)特征向量。我们使用多类准确率作为评估指标。$\mathbf{{AwA}}$的字典大小选择为300，其他三个数据集的字典大小为500到800。其他参数$\alpha$和$\beta$通过五折交叉验证获得。$\gamma$和$\lambda$也可以进行调整，为简单起见，我们将它们都设置为1。更多细节可在补充材料中找到。

### 4.2. Effectiveness of the Proposed Framework

### 4.2. 所提出框架的有效性

The proposed latent attribute space is associated with the attribute space and the similarity space, which makes it not only semantic-preserving but also discriminative enough to classify different classes. To demonstrate the effectiveness of each component, we compare five different approaches and the results on aP&Y are shown in Figure 3 (1) Recognition in the attribute space(A)merely, by learning the attribute dictionary directly, as is proposed in Eq. 2 (2) Recognition in the similarity space (S) merely, by removing the semantic constraint (i.e. the second term) in Eq. 4 (3) Recognition in the latent attribute space but without discriminative constraint $\left( {\mathbf{{LA}}}^{ - }\right)$ , by removing the discriminative constraint (i.e. the third term) in Eq. 4 (4) Recognition in the latent attribute space with discriminative constraint (LA), as is proposed in Eq. 4. (5) Recognition by combining the latent attribute space and similarity space (LAS), as is proposed in Section 3.4

所提出的潜在属性空间与属性空间和相似度空间相关联，这使得它不仅能够保留语义，而且具有足够的区分能力来对不同类别进行分类。为了证明每个组件的有效性，我们比较了五种不同的方法，在aP&Y数据集上的结果如图3所示。(1)仅在属性空间(A)中进行识别，即直接学习属性字典，如公式2所示；(2)仅在相似度空间(S)中进行识别，即去除公式4中的语义约束(即第二项)；(3)在潜在属性空间中进行识别，但不考虑区分性约束$\left( {\mathbf{{LA}}}^{ - }\right)$，即去除公式4中的区分性约束(即第三项)；(4)在潜在属性空间中进行识别并考虑区分性约束(LA)，如公式4所示；(5)结合潜在属性空间和相似度空间进行识别(LAS)，如3.4节所述。

![0195e08b-e024-7b29-a315-1577741237ee_5_1002_220_461_374_0.jpg](images/0195e08b-e024-7b29-a315-1577741237ee_5_1002_220_461_374_0.jpg)

Figure 3. Comparisons of five approaches on aP&Y.

图3. 五种方法在aP&Y数据集上的比较。

By comparing the performance of $\mathbf{A},\mathbf{S}$ and $\mathbf{L}{\mathbf{A}}^{ - }$ , we can infer that the latent attributes are more successful in the ZSL task. Moreover, by imposing the discriminative constrain-t in the objective function, the recognition accuracy improves, as is shown by the performance of LA. Furthermore, the combination of latent attributes and seen class similarities also improves the final recognition performance, as is shown by the result of LAS.

通过比较$\mathbf{A},\mathbf{S}$和$\mathbf{L}{\mathbf{A}}^{ - }$的性能，我们可以推断出潜在属性在零样本学习(ZSL)任务中更为成功。此外，如LA的性能所示，在目标函数中施加区分性约束可以提高识别准确率。而且，如LAS的结果所示，潜在属性和已见类别的相似度相结合也能提高最终的识别性能。

### 4.3. Benchmark Comparisons and Evaluations

### 4.3. 基准比较与评估

In this part, we compare our method with several popular approaches. Our settings are the same as those in [44]. Table 2 shows results on four datasets, where the blank spaces indicate that the corresponding methods were not tested on the datasets in their original papers. Here, for our LAD method, we report the results of two variants LA and LAS, as described in Section 4.2. It is important to point out that the first three approaches are in transductive ZSL settings, where the information of unseen class samples are utilized, while our approach and other competing methods are in traditional ZSL settings. From this table, we can see that our approach achieves the best performance on three dataset-s, which shows the effectiveness of the proposed method. Note that '*' indicates that the approaches use different features from ours, where [11, 15] use the OverFeat [34] features and [2, 5, 6] use the GoogleNet [38] features.

在这部分，我们将我们的方法与几种流行的方法进行比较。我们的设置与文献[44]中的相同。表2展示了在四个数据集上的结果，其中空白处表示相应的方法在其原始论文中未在这些数据集上进行测试。在这里，对于我们的LAD方法，我们报告了如4.2节所述的两种变体LA和LAS的结果。需要指出的是，前三种方法是在直推式零样本学习(transductive ZSL)设置下，利用了未见类样本的信息，而我们的方法和其他竞争方法是在传统的零样本学习(ZSL)设置下。从该表中可以看出，我们的方法在三个数据集上取得了最佳性能，这表明了所提出方法的有效性。注意，“*”表示这些方法使用了与我们不同的特征，其中[11, 15]使用了OverFeat [34]特征，[2, 5, 6]使用了GoogleNet [38]特征。

From Table 2, we can see that great improvement is made on CUB-200 dataset. It should be contributed by the good reconstruction property of latent attribute dictionary. This dataset is designed for fine-grained recognition, where the sample variation is not very large. Thus the dictionaries learned on the seen class samples can have a good reconstruction of the unseen class samples. With the help of discriminative property of latent attributes, the recognition performance of unseen classes can be improved further. Our result on AwA is slightly lower than that of JSLA [29]. The reason may lie in the class-level attribute annotations, which can not cover the variations of images within each class.

从表2中可以看出，在CUB - 200数据集上有了很大的改进。这应该归功于潜在属性字典良好的重构特性。该数据集是为细粒度识别设计的，样本的变化不是很大。因此，在已见类样本上学习到的字典可以很好地重构未见类样本。借助潜在属性的区分性，未见类别的识别性能可以进一步提高。我们在AwA数据集上的结果略低于JSLA [29]的结果。原因可能在于类别级别的属性标注无法涵盖每个类别内图像的变化。

Table 2. Comparisons with published results in multi-class accuracy (%) for the task of zero-shot learning. '*' denotes the features are different from ours. '-' denotes the data split is different from ours.

表2. 零样本学习任务中与已发表结果在多类准确率(%)方面的比较。“*”表示使用的特征与我们的不同。“ - ”表示数据划分与我们的不同。

<table><tr><td>$\mathbf{{Method}}$</td><td>aP&Y</td><td>$\mathbf{{AwA}}$</td><td>CUB-200</td><td>SUN-A</td></tr><tr><td>${\mathrm{{TMV} - {HLP}}}^{ * }$ [11]</td><td/><td>80.50</td><td>47.90</td><td/></tr><tr><td>${\mathrm{{UDA}}}^{ * }$ [15]</td><td/><td>75.60</td><td>40.60</td><td/></tr><tr><td>SP-ZSR [46]</td><td>69.74</td><td>92.08</td><td>55.34</td><td>89.50</td></tr><tr><td>DAP [18]</td><td>38.16</td><td>57.23</td><td/><td>72.00</td></tr><tr><td>ESZSL [26]</td><td>24.22</td><td>75.32</td><td/><td>82.10</td></tr><tr><td>${\mathrm{{SJE}}}^{ * }$ [2]</td><td/><td>66.70</td><td>50.10</td><td/></tr><tr><td>SSE-ReLU [44]</td><td>46.23</td><td>76.33</td><td>30.41</td><td>82.50</td></tr><tr><td>JLSE [45]</td><td>50.35</td><td>80.46</td><td>42.11</td><td>83.83</td></tr><tr><td>${\mathrm{{SynC}}}^{ * }5$</td><td/><td>72.90</td><td>${54.70}^{ \dagger  }$</td><td>${62.70}^{ \dagger  }$</td></tr><tr><td>JSLA [29]</td><td/><td>82.81</td><td>49.87</td><td/></tr><tr><td>Chao et al.* [6]</td><td/><td>73.40</td><td>${54.40}^{ \dagger  }$</td><td/></tr><tr><td>Bucher et al. [4]</td><td>53.15</td><td>77.32</td><td>43.29</td><td>84.41</td></tr><tr><td>LAD (LA)</td><td>51.13</td><td>80.49</td><td>56.36</td><td>83.50</td></tr><tr><td>LAD (LAS)</td><td>53.74</td><td>82.48</td><td>56.63</td><td>85.00</td></tr></table>

<table><tbody><tr><td>$\mathbf{{Method}}$</td><td>美联亚(aP&Y)</td><td>$\mathbf{{AwA}}$</td><td>加州理工大学鸟类数据集-200(CUB-200)</td><td>太阳属性数据集-A(SUN-A)</td></tr><tr><td>${\mathrm{{TMV} - {HLP}}}^{ * }$ [11]</td><td></td><td>80.50</td><td>47.90</td><td></td></tr><tr><td>${\mathrm{{UDA}}}^{ * }$ [15]</td><td></td><td>75.60</td><td>40.60</td><td></td></tr><tr><td>基于语义投影的零样本识别方法(SP-ZSR) [46]</td><td>69.74</td><td>92.08</td><td>55.34</td><td>89.50</td></tr><tr><td>判别式属性投影(DAP) [18]</td><td>38.16</td><td>57.23</td><td></td><td>72.00</td></tr><tr><td>基于嵌入空间的零样本学习方法(ESZSL) [26]</td><td>24.22</td><td>75.32</td><td></td><td>82.10</td></tr><tr><td>${\mathrm{{SJE}}}^{ * }$ [2]</td><td></td><td>66.70</td><td>50.10</td><td></td></tr><tr><td>带自监督嵌入的修正线性单元激活函数(SSE-ReLU) [44]</td><td>46.23</td><td>76.33</td><td>30.41</td><td>82.50</td></tr><tr><td>联合学习语义嵌入方法(JLSE) [45]</td><td>50.35</td><td>80.46</td><td>42.11</td><td>83.83</td></tr><tr><td>${\mathrm{{SynC}}}^{ * }5$</td><td></td><td>72.90</td><td>${54.70}^{ \dagger  }$</td><td>${62.70}^{ \dagger  }$</td></tr><tr><td>联合语义学习与对齐方法(JSLA) [29]</td><td></td><td>82.81</td><td>49.87</td><td></td></tr><tr><td>赵等人* [6]</td><td></td><td>73.40</td><td>${54.40}^{ \dagger  }$</td><td></td></tr><tr><td>布赫尔等人 [4]</td><td>53.15</td><td>77.32</td><td>43.29</td><td>84.41</td></tr><tr><td>标签自适应判别器(局部对齐)(LAD (LA))</td><td>51.13</td><td>80.49</td><td>56.36</td><td>83.50</td></tr><tr><td>标签自适应判别器(局部对齐与选择)(LAD (LAS))</td><td>53.74</td><td>82.48</td><td>56.63</td><td>85.00</td></tr></tbody></table>

The reconstruction accuracy of dictionary may thus be influenced by the limited attribute representations.

因此，字典的重建准确性可能会受到有限属性表示的影响。

### 4.4. Semantic-Preserving Property

### 4.4. 语义保留特性

Different from previous approaches which learn discriminative attributes with no semantic meanings [43], our latent attributes are semantic-preserving. This can be reflected by the following two aspects.

与之前学习无语义判别属性的方法[43]不同，我们的潜在属性具有语义保留性。这可以从以下两个方面体现出来。

First, we can recover the attributes of images by their latent attribute representations, as is shown in Eq. 14 In order to test whether the recovered attributes are good or not, we perform an attribute prediction task on AwA. Specifically, we binarize the attributes by the thresholds provided by the original dataset and measure the performance by Area Under Curve(AUC). Figure 4 shows the attribute prediction results of unseen classes. Blank spaces indicate that there are no such attributes in the unseen classes. We can figure out that most of the attributes recovered from the latent attributes have relatively good performance, which demonstrates the semantic-preserving property of the latent attributes. The mean AUC of attributes recovered by our approach is 0.729 , which is comparative to other attribute prediction results [29]. Since the main purpose of our approach is not attribute prediction, no further detailed comparison is conducted.

首先，我们可以通过图像的潜在属性表示来恢复图像的属性，如公式14所示。为了测试恢复的属性是否良好，我们在AwA数据集上进行了属性预测任务。具体来说，我们根据原始数据集提供的阈值对属性进行二值化处理，并使用曲线下面积(AUC)来衡量性能。图4显示了未见类别的属性预测结果。空白处表示未见类别中不存在此类属性。我们可以发现，从潜在属性中恢复的大多数属性具有相对较好的性能，这证明了潜在属性的语义保留特性。我们的方法恢复的属性的平均AUC为0.729，与其他属性预测结果[29]相当。由于我们方法的主要目的不是属性预测，因此没有进行进一步的详细比较。

Second, the latent attributes can be viewed as differen-t combinations of attributes. To have an intuitive understanding of what the combinations are, we visualize some latent attribute dictionaries. Specifically, given a latent attribute dictionary item, we show the images which have the largest and smallest correspondance over this item. Figure 5 shows the visualization results on AwA using the unseen class samples. Besides, we also show the attributes with the

其次，潜在属性可以看作是属性的不同组合。为了直观地理解这些组合是什么，我们对一些潜在属性字典进行了可视化。具体来说，给定一个潜在属性字典项，我们展示了与该项对应关系最大和最小的图像。图5显示了在AwA数据集上使用未见类别样本的可视化结果。此外，我们还展示了

![0195e08b-e024-7b29-a315-1577741237ee_6_933_201_616_371_0.jpg](images/0195e08b-e024-7b29-a315-1577741237ee_6_933_201_616_371_0.jpg)

Figure 5. Latent attribute dictionary visualization on AwA using the unseen class samples. 'LA' is the latent attribute. Green blocks show attributes with largest activations and red ones show attributes with smallest activations. The first three pictures are randomly selected from images which have largest activations over the latent attribute and the last three are selected from images with smallest activations.

图5. 在AwA数据集上使用未见类别样本的潜在属性字典可视化结果。'LA' 是潜在属性。绿色方块表示激活值最大的属性，红色方块表示激活值最小的属性。前三张图片是从对潜在属性激活值最大的图像中随机选取的，后三张是从激活值最小的图像中选取的。

largest and smallest activations over the latent attributes in Figure 5. It can be observed that the images, which have high correspondence over the latent attribute, are in accordance with the attribute combinations. For example, seal is highly correlated with attributes in the green blocks of 'LA1' and has little relevance to those in red blocks. We can figure out that a specific latent attribute may group some highly correlated attributes, thus the variation within each latent attribute becomes smaller. It is desirable that a latent attribute should have strong activations only on a small numbers of attributes. While we do not explicitly impose such sparsity constraint, the combination coefficients are found to be mostly sparse in our experimental study. Due to limited space, detailed statistic results and analyses are provided in the supplementary material.

图5中潜在属性上激活值最大和最小的属性。可以观察到，与潜在属性具有高对应关系的图像与属性组合是一致的。例如，海豹与 'LA1' 绿色方块中的属性高度相关，而与红色方块中的属性相关性很小。我们可以发现，一个特定的潜在属性可能会将一些高度相关的属性分组，因此每个潜在属性内的变化变小。理想情况下，一个潜在属性应该只在少数属性上有强烈的激活。虽然我们没有明确施加这样的稀疏性约束，但在我们的实验研究中发现组合系数大多是稀疏的。由于篇幅有限，详细的统计结果和分析在补充材料中提供。

### 4.5. Discriminative Property

### 4.5. 判别特性

From our objective function in Eq. 4, it can be seen that a discriminative constraint is achieved by learning seen class classifiers in the latent attribute space. The probability outputs of seen-class classifiers for each image can be viewed as a vector representation in the similarity space, where each dimension represents the similarity to one seen class. Figure 6 shows the top five most similar seen classes corresponding to some unseen class samples on aP&Y, where the probability outputs are obtained by softmax function. It can be seen that most of the similarities are human comprehensible. For example, wolf is most similar to cat and jetski is most similar to motorbike.

从我们公式4中的目标函数可以看出，通过在潜在属性空间中学习已见类别分类器可以实现判别约束。每个图像的已见类别分类器的概率输出可以看作是相似性空间中的向量表示，其中每个维度表示与一个已见类别的相似性。图6显示了在aP&Y数据集上一些未见类别样本对应的前五个最相似的已见类别，其中概率输出是通过softmax函数获得的。可以看出，大多数相似性是人类可以理解的。例如，狼与猫最相似，喷气式滑水艇与摩托车最相似。

In order to perform ZSL task, we also need the similarity representations of unseen class prototypes. This can be obtained by the approach proposed by [44], as is mentioned in Section 3.4. Figure 7 shows the similarities of unseen classes to the seen classes on aP&Y, where the values are normalized. It can be inferred that most of the similarities are also in accordance with human knowledge. Since the similarities grasp some information of unseen classes, we can also use such semantic information to perform ZSL task. However, due to the fact that there are only limited numbers of seen classes, some similarities are not that comprehensible, such as the similarity representation of bag.

为了执行零样本学习(ZSL)任务，我们还需要未见类别原型的相似性表示。这可以通过[44]提出的方法获得，如第3.4节所述。图7显示了在aP&Y数据集上未见类别与已见类别的相似性，其中值进行了归一化处理。可以推断出，大多数相似性也符合人类知识。由于相似性掌握了未见类别的一些信息，我们也可以使用这些语义信息来执行ZSL任务。然而，由于已见类别的数量有限，一些相似性不太容易理解，如包的相似性表示。

![0195e08b-e024-7b29-a315-1577741237ee_7_227_206_1294_306_0.jpg](images/0195e08b-e024-7b29-a315-1577741237ee_7_227_206_1294_306_0.jpg)

Figure 4. Attribute prediction results on AwA with the measure of AUC.

图4. 在AwA数据集上使用AUC度量的属性预测结果。

![0195e08b-e024-7b29-a315-1577741237ee_7_225_611_524_291_0.jpg](images/0195e08b-e024-7b29-a315-1577741237ee_7_225_611_524_291_0.jpg)

Figure 6. Similarity representations of unseen class samples on aP&Y. Top five similar classes are shown.

图6. 在aP&Y数据集上未见类别样本的相似性表示。显示了前五个相似的类别。

![0195e08b-e024-7b29-a315-1577741237ee_7_213_1004_525_380_0.jpg](images/0195e08b-e024-7b29-a315-1577741237ee_7_213_1004_525_380_0.jpg)

Figure 7. Similarity representations of unseen class prototypes on aP&Y. Each column shows the similarity of an unseen class to the seen classes.

图7. 在aP&Y数据集上未见类别原型的相似性表示。每一列显示了一个未见类别与已见类别的相似性。

As mentioned above, in order to make the latent attribute discriminative, we utilize seen-class classifiers to connect the latent attribute space to the similarity space. To explore whether the latent attributes are discriminative or not, we visualize the unseen class samples in AwA by their latent attribute representations learned by our approach. Specifically, we use t-SNE [20] to project the learned latent attribute representations of each unseen class sample to a 2-D plane. Figure 8 shows the visualization results. We can see that images of the same class are grouped together and those

如上所述，为了使潜在属性具有判别性，我们利用已见类别分类器将潜在属性空间与相似性空间连接起来。为了探索潜在属性是否具有判别性，我们通过我们的方法学习到的潜在属性表示对AwA数据集中的未见类别样本进行了可视化。具体来说，我们使用t-SNE [20]将每个未见类别样本学习到的潜在属性表示投影到二维平面上。图8显示了可视化结果。我们可以看到，同一类别的图像被分组在一起，并且那些

![0195e08b-e024-7b29-a315-1577741237ee_7_978_607_543_391_0.jpg](images/0195e08b-e024-7b29-a315-1577741237ee_7_978_607_543_391_0.jpg)

Figure 8. Visualization of the unseen class samples on AwA using their latent attribute representations. Each color represents a class and each point represents an image.

图8. 使用潜在属性表示对AwA数据集上未见类别的样本进行可视化。每种颜色代表一个类别，每个点代表一幅图像。

from different classes are separated, which indicates that the latent attributes are discriminative for the recognition task. It is also very interesting to find that visually similar classes have small distances. For example, the cluster of pigs is near that of hippopotamuses and the cluster of humpback whales is near that of seals. This again shows that the latent attributes preserve the semantic information.

不同类别的样本是分开的，这表明潜在属性对于识别任务具有区分性。有趣的是，视觉上相似的类别之间距离较小。例如，猪的聚类靠近河马的聚类，座头鲸的聚类靠近海豹的聚类。这再次表明潜在属性保留了语义信息。

## 5. Conclusion

## 5. 结论

In this paper, we propose a novel ZSL approach which is accomplished by latent attribute dictionary learning (LAD). The proposed approach shows its effectiveness on four datasets. We attribute the promising performance of LAD to three aspects. First, the proposed latent attribute space is connected with the attribute space, so it preserves the semantic information. Thus it is possible to perform ZSL task in the latent attribute space. Second, the latent attribute space is connected with the similarity space. This makes the latent attribute space discriminative to recognize different categories. Third, the latent attributes can be viewed as different combinations of semantic attributes, which implicitly deals with the attribute correlation problem.

在本文中，我们提出了一种新颖的零样本学习(ZSL)方法，该方法通过潜在属性字典学习(LAD)实现。所提出的方法在四个数据集上显示出有效性。我们将LAD的良好性能归因于三个方面。首先，所提出的潜在属性空间与属性空间相连，因此它保留了语义信息。因此，有可能在潜在属性空间中执行零样本学习任务。其次，潜在属性空间与相似度空间相连。这使得潜在属性空间能够区分不同的类别。第三，潜在属性可以看作是语义属性的不同组合，这隐式地处理了属性相关性问题。

Acknowledgements. This work is partially supported by Natural Science Foundation of China under contract Nos. 61390511, 61379083, 61650202; 973 Program under contrac-t No. 2015CB351802; and Youth Innovation Promotion Association CAS No. 2015085.

致谢。本工作得到了中国自然科学基金(合同编号:61390511、61379083、61650202)、973计划(合同编号:2015CB351802)以及中国科学院青年创新促进会(编号:2015085)的部分资助。

[1] Z. Akata, F. Perronnin, Z. Harchaoui, and C. Schmid. Label-embedding for attribute-based classification. In Proc. of Computer Vision and Pattern Recognition, pages 819-826, 2013.

[1] Z. Akata, F. Perronnin, Z. Harchaoui, and C. Schmid. 基于属性分类的标签嵌入。见《计算机视觉与模式识别会议论文集》，第819 - 826页，2013年。

[2] Z. Akata, S. Reed, D. Walter, H. Lee, and B. Schiele. Evaluation of output embeddings for fine-grained image classification. In Proc. of Computer Vision and Pattern Recognition, pages 2927-2936, 2015.

[2] Z. Akata, S. Reed, D. Walter, H. Lee, and B. Schiele. 细粒度图像分类输出嵌入的评估。见《计算机视觉与模式识别会议论文集》，第2927 - 2936页，2015年。

[3] J. Ba, K. Swersky, S. Fidler, and R. Salakhutdinov. Predicting deep zero-shot convolutional neural networks using textual descriptions. In Proc. of International Conference on Computer Vision, pages 4247-4255, 2015.

[3] J. Ba, K. Swersky, S. Fidler, and R. Salakhutdinov. 使用文本描述预测深度零样本卷积神经网络。见《国际计算机视觉会议论文集》，第4247 - 4255页，2015年。

[4] M. Bucher, S. Herbin, and F. Jurie. Improving semantic embedding consistency by metric learning for zero-shot classification. In Proc. of European Conference on Computer Vision, pages 730-746, 2016.

[4] M. Bucher, S. Herbin, and F. Jurie. 通过度量学习提高零样本分类的语义嵌入一致性。见《欧洲计算机视觉会议论文集》，第730 - 746页，2016年。

[5] S. Changpinyo, W. L. Chao, B. Gong, and F. Sha. Synthesized classifiers for zero-shot learning. In Proc. of Computer Vision and Pattern Recognition, pages 5327-5336, 2016.

[5] S. Changpinyo, W. L. Chao, B. Gong, and F. Sha. 用于零样本学习的合成分类器。见《计算机视觉与模式识别会议论文集》，第5327 - 5336页，2016年。

[6] W. L. Chao, S. Changpinyo, B. Gong, and F. Sha. An empirical study and analysis of generalized zero-shot learning for object recognition in the wild. In Proc. of European Conference on Computer Vision, pages 52-68, 2016.

[6] W. L. Chao, S. Changpinyo, B. Gong, and F. Sha. 野外目标识别广义零样本学习的实证研究与分析。见《欧洲计算机视觉会议论文集》，第52 - 68页，2016年。

[7] M. Elhoseiny, B. Saleh, and A. Elgammal. Write a classifier: Zero-shot learning using purely textual descriptions. In Proc. of International Conference on Computer Vision, pages 2584-2591, 2013.

[7] M. Elhoseiny, B. Saleh, and A. Elgammal. 编写分类器:仅使用文本描述的零样本学习。见《国际计算机视觉会议论文集》，第2584 - 2591页，2013年。

[8] V. Escorcia, J. C. Niebles, and B. Ghanem. On the relationship between visual attributes and convolutional networks. In Proc. of Computer Vision and Pattern Recognition, pages 1256-1264, 2015.

[8] V. Escorcia, J. C. Niebles, and B. Ghanem. 视觉属性与卷积网络之间的关系。见《计算机视觉与模式识别会议论文集》，第1256 - 1264页，2015年。

[9] A. Farhadi, I. Endres, D. Hoiem, and D. Forsyth. Describing objects by their attributes. In Proc. of Computer Vision and Pattern Recognition, pages 1778-1785, 2009.

[9] A. Farhadi, I. Endres, D. Hoiem, and D. Forsyth. 通过属性描述物体。见《计算机视觉与模式识别会议论文集》，第1778 - 1785页，2009年。

[10] A. Frome, G. S. Corrado, J. Shlens, S. Bengio, J. Dean, M. Ranzato, and T. Mikolov. Devise: A deep visual-semantic embedding model. In Proc. of Advances in Neural Information Processing Systems, pages 2121-2129, 2013.

[10] A. Frome, G. S. Corrado, J. Shlens, S. Bengio, J. Dean, M. Ranzato, and T. Mikolov. Devise:一种深度视觉 - 语义嵌入模型。见《神经信息处理系统进展会议论文集》，第2121 - 2129页，2013年。

[11] Y. Fu, T. M. Hospedales, T. Xiang, and S. Gong. Trans-ductive multi-view zero-shot learning. IEEE Transactions on Pattern Analysis and Machine Intelligence, 37(11):2332- 2345, 2015.

[11] Y. Fu, T. M. Hospedales, T. Xiang, and S. Gong. 直推式多视图零样本学习。《IEEE模式分析与机器智能汇刊》，37(11):2332 - 2345，2015年。

[12] Z. Fu, T. Xiang, E. Kodirov, and S. Gong. Zero-shot object recognition by semantic manifold distance. In Proc. of Computer Vision and Pattern Recognition, pages 2635- 2644, 2015.

[12] 傅泽(Z. Fu)、向涛(T. Xiang)、埃米尔·科迪罗夫(E. Kodirov)和龚少刚(S. Gong)。基于语义流形距离的零样本目标识别。见《计算机视觉与模式识别会议论文集》，第2635 - 2644页，2015年。

[13] D. Jayaraman and K. Grauman. Zero-shot recognition with unreliable attributes. In Proc. of Advances in Neural Information Processing Systems, pages 3464-3472, 2014.

[13] 达南杰·贾亚拉曼(D. Jayaraman)和凯特·格劳曼(K. Grauman)。具有不可靠属性的零样本识别。见《神经信息处理系统进展会议论文集》，第3464 - 3472页，2014年。

[14] D. Jayaraman, F. Sha, and K. Grauman. Decorrelating semantic visual attributes by resisting the urge to share. In Proc. of Computer Vision and Pattern Recognition, pages 1629-1636, 2014.

[14] 达南杰·贾亚拉曼(D. Jayaraman)、沙飞(F. Sha)和凯特·格劳曼(K. Grauman)。通过抑制共享冲动来对语义视觉属性进行去相关处理。见《计算机视觉与模式识别会议论文集》，第1629 - 1636页，2014年。

[15] E. Kodirov, T. Xiang, Z. Fu, and S. Gong. Unsupervised domain adaptation for zero-shot learning. In Proc. of Inter-

[15] 埃米尔·科迪罗夫(E. Kodirov)、向涛(T. Xiang)、傅泽(Z. Fu)和龚少刚(S. Gong)。零样本学习的无监督域适应。见《国

national Conference on Computer Vision, pages 2452-2460, 2015.

际计算机视觉会议论文集》，第2452 - 2460页，2015年。

[16] G. Kulkarni, V. Premraj, V. Ordonez, S. Dhar, S. Li, Y. Choi, A. C. Berg, and T. Berg. Babytalk: Understanding and generating simple image descriptions. IEEE Transactions on Pattern Analysis and Machine Intelligence, 35(12):2891-2903, 2013.

[16] 高拉夫·库尔卡尼(G. Kulkarni)、维贾伊·普雷姆拉吉(V. Premraj)、维克多·奥尔多涅斯(V. Ordonez)、桑迪普·达尔(S. Dhar)、李帅(S. Li)、崔允植(Y. Choi)、亚历山大·C·伯格(A. C. Berg)和托马斯·伯格(T. Berg)。婴儿语:理解和生成简单的图像描述。《电气与电子工程师协会模式分析与机器智能汇刊》，35(12):2891 - 2903，2013年。

[17] C. H. Lampert, H. Nickisch, and S. Harmeling. Learning to detect unseen object classes by between-class attribute transfer. In Proc. of Computer Vision and Pattern Recognition, pages 951-958, 2009.

[17] 克里斯托夫·H·兰佩特(C. H. Lampert)、亨德里克·尼克施(H. Nickisch)和斯蒂芬·哈梅林(S. Harmeling)。通过类间属性转移学习检测未见目标类别。见《计算机视觉与模式识别会议论文集》，第951 - 958页，2009年。

[18] C. H. Lampert, H. Nickisch, and S. Harmeling. Attribute-based classification for zero-shot visual object categorization. IEEE Transactions on Pattern Analysis and Machine Intelligence, 36(3):453-465, 2014.

[18] 克里斯托夫·H·兰佩特(C. H. Lampert)、亨德里克·尼克施(H. Nickisch)和斯蒂芬·哈梅林(S. Harmeling)。基于属性的分类用于零样本视觉目标分类。《电气与电子工程师协会模式分析与机器智能汇刊》，36(3):453 - 465，2014年。

[19] X. Li, Y. Guo, and D. Schuurmans. Semi-supervised zero-shot classification with label representation learning. In Proc. of International Conference on Computer Vision, pages 4211-4219, 2015.

[19] 李翔(X. Li)、郭毅可(Y. Guo)和戴尔·舒尔曼斯(D. Schuurmans)。基于标签表示学习的半监督零样本分类。见《国际计算机视觉会议论文集》，第4211 - 4219页，2015年。

[20] L. v. d. Maaten and G. Hinton. Visualizing data using t-SNE. Journal of Machine Learning Research, 9(Nov):2579-2605, 2008.

[20] 劳伦斯·范德马坦(L. v. d. Maaten)和杰弗里·辛顿(G. Hinton)。使用t - SNE可视化数据。《机器学习研究杂志》，9(11月):2579 - 2605，2008年。

[21] D. Mahajan, S. Sellamanickam, and V. Nair. A joint learning framework for attribute models and object descriptions. In Proc. of International Conference on Computer Vision, pages 1227-1234, 2011.

[21] 迪帕克·马哈詹(D. Mahajan)、塞勒马尼克姆·塞勒瓦拉杰(S. Sellamanickam)和维诺德·奈尔(V. Nair)。属性模型和目标描述的联合学习框架。见《国际计算机视觉会议论文集》，第1227 - 1234页，2011年。

[22] T. Mensink, E. Gavves, and C. Snoek. Costa: Co-occurrence statistics for zero-shot classification. In Proc. of Computer Vision and Pattern Recognition, pages 2441-2448, 2014.

[22] 托马斯·门辛克(T. Mensink)、埃弗特·加维斯(E. Gavves)和科恩·斯诺克(C. Snoek)。Costa:用于零样本分类的共现统计。见《计算机视觉与模式识别会议论文集》，第2441 - 2448页，2014年。

[23] T. Mensink, J. Verbeek, F. Perronnin, and G. Csurka. Metric learning for large scale image classification: Generalizing to new classes at near-zero cost. In Proc. of European Conference on Computer Vision, pages 488-501. 2012.

[23] 托马斯·门辛克(T. Mensink)、扬·韦贝克(J. Verbeek)、弗朗索瓦·佩罗南(F. Perronnin)和加布里埃拉·楚尔卡(G. Csurka)。大规模图像分类的度量学习:以近乎零成本泛化到新类别。见《欧洲计算机视觉会议论文集》，第488 - 501页，2012年。

[24] M. Norouzi, T. Mikolov, S. Bengio, Y. Singer, J. Shlens, A. Frome, G. S. Corrado, and J. Dean. Zero-shot learning by convex combination of semantic embeddings. In Proc. of International Conference on Learning Representations, 2014.

[24] 莫哈迈德·诺鲁兹(M. Norouzi)、托马斯·米科洛夫(T. Mikolov)、约书亚·本吉奥(S. Bengio)、伊亚·辛格(Y. Singer)、乔恩·施伦斯(J. Shlens)、安德烈·弗洛姆(A. Frome)、格雷格·S·科拉多(G. S. Corrado)和杰弗里·迪恩(J. Dean)。通过语义嵌入的凸组合进行零样本学习。见《国际学习表征会议论文集》，2014年。

[25] M. Palatucci, D. Pomerleau, G. E. Hinton, and T. M. Mitchell. Zero-shot learning with semantic output codes. In Proc. of Advances in Neural Information Processing System- $s$ , pages ${1410} - {1418},{2009}$ .

[25] 马可·帕拉图奇(M. Palatucci)、丹·波梅罗(D. Pomerleau)、杰弗里·E·辛顿(G. E. Hinton)和汤姆·M·米切尔(T. M. Mitchell)。使用语义输出码进行零样本学习。见《神经信息处理系统进展会议论文集 - $s$ ，第 ${1410} - {1418},{2009}$ 页。

[26] B. R. Paredes and P. Torr. An embarrassingly simple approach to zero-shot learning. In Proc. of International Conference on Machine Learning, pages 2152-2161, 2015.

[26] 布赖恩·R·帕雷德斯(B. R. Paredes)和菲利普·托尔(P. Torr)。一种极其简单的零样本学习方法。见《国际机器学习会议论文集》，第2152 - 2161页，2015年。

[27] G. Patterson and J. Hays. SUN attribute database: Discovering, annotating, and recognizing scene attributes. In Proc. of Computer Vision and Pattern Recognition, pages 2751- 2758, 2012.

[27] G. 帕特森(G. Patterson)和 J. 海斯(J. Hays)。SUN 属性数据库:发现、标注和识别场景属性。收录于《计算机视觉与模式识别会议论文集》，第 2751 - 2758 页，2012 年。

[28] G. Patterson, C. Xu, H. Su, and J. Hays. The SUN attribute database: Beyond categories for deeper scene understanding. International Journal of Computer Vision, 108(1-2):59-81, 2014.

[28] G. 帕特森(G. Patterson)、C. 徐(C. Xu)、H. 苏(H. Su)和 J. 海斯(J. Hays)。SUN 属性数据库:超越类别以实现更深入的场景理解。《国际计算机视觉杂志》，108(1 - 2):59 - 81，2014 年。

[29] P. Peng, Y. Tian, T. Xiang, Y. Wang, and T. Huang. Joint learning of semantic and latent attributes. In Proc. of European Conference on Computer Vision, pages 336-353, 2016.

[29] P. 彭(P. Peng)、Y. 田(Y. Tian)、T. 向(T. Xiang)、Y. 王(Y. Wang)和 T. 黄(T. Huang)。语义和潜在属性的联合学习。收录于《欧洲计算机视觉会议论文集》，第 336 - 353 页，2016 年。

[30] R. Qiao, L. Liu, C. Shen, and A. V. D. Hengel. Less is more: zero-shot learning from online textual documents with noise

[30] R. 乔(R. Qiao)、L. 刘(L. Liu)、C. 沈(C. Shen)和 A. V. D. 亨格尔(A. V. D. Hengel)。少即是多:通过噪声抑制从在线文本文档进行零样本学习

suppression. In Proc. of Computer Vision and Pattern Recog-

。收录于《计算机视觉与模式识别会议论文集》

nition, pages 2249-2257, 2016.

，第 2249 - 2257 页，2016 年。

[31] M. Rohrbach, S. Ebert, and B. Schiele. Transfer learning in a transductive setting. In Proc. of Advances in Neural Information Processing Systems, pages 46-54, 2013.

[31] M. 罗尔巴赫(M. Rohrbach)、S. 埃伯特(S. Ebert)和 B. 席勒(B. Schiele)。直推式设置下的迁移学习。收录于《神经信息处理系统进展会议论文集》，第 46 - 54 页，2013 年。

[32] M. Rohrbach, M. Stark, and B. Schiele. Evaluating knowledge transfer and zero-shot learning in a large-scale setting. In Proc. of Computer Vision and Pattern Recognition, pages 1641-1648, 2011.

[32] M. 罗尔巴赫(M. Rohrbach)、M. 斯塔克(M. Stark)和 B. 席勒(B. Schiele)。大规模设置下的知识迁移和零样本学习评估。收录于《计算机视觉与模式识别会议论文集》，第 1641 - 1648 页，2011 年。

[33] M. Rohrbach, M. Stark, G. Szarvas, I. Gurevych, and B. Schiele. What helps where-and why? semantic relatedness for knowledge transfer. In Proc. of Computer Vision and Pattern Recognition, pages 910-917, 2010.

[33] M. 罗尔巴赫(M. Rohrbach)、M. 斯塔克(M. Stark)、G. 萨尔瓦斯(G. Szarvas)、I. 古雷维奇(I. Gurevych)和 B. 席勒(B. Schiele)。什么在何处有帮助以及原因何在？用于知识迁移的语义相关性。收录于《计算机视觉与模式识别会议论文集》，第 910 - 917 页，2010 年。

[34] P. Sermanet, D. Eigen, X. Zhang, M. Mathieu, R. Fergus, and Y. LeCun. Overfeat: Integrated recognition, localization and detection using convolutional networks. In Proc. of International Conference on Learning Representations, 2014.

[34] P. 塞尔马内特(P. Sermanet)、D. 艾根(D. Eigen)、X. 张(X. Zhang)、M. 马蒂厄(M. Mathieu)、R. 弗格斯(R. Fergus)和 Y. 勒昆(Y. LeCun)。Overfeat:使用卷积网络进行集成识别、定位和检测。收录于《国际学习表征会议论文集》，2014 年。

[35] B. Siddiquie, R. S. Feris, and L. S. Davis. Image ranking and retrieval based on multi-attribute queries. In Proc. of Computer Vision and Pattern Recognition, pages 801-808, 2011.

[35] B. 西迪基(B. Siddiquie)、R. S. 费里斯(R. S. Feris)和 L. S. 戴维斯(L. S. Davis)。基于多属性查询的图像排序和检索。收录于《计算机视觉与模式识别会议论文集》，第 801 - 808 页，2011 年。

[36] K. Simonyan and A. Zisserman. Very deep convolutional networks for large-scale image recognition. In Proc. of International Conference on Learning Representations, 2015.

[36] K. 西蒙扬(K. Simonyan)和 A. 齐斯曼(A. Zisserman)。用于大规模图像识别的非常深的卷积网络。收录于《国际学习表征会议论文集》，2015 年。

[37] R. Socher, M. Ganjoo, C. D. Manning, and A. Ng. Zero-shot learning through cross-modal transfer. In Proc. of Advances in Neural Information Processing Systems, pages 935-943, 2013.

[37] R. 索切尔(R. Socher)、M. 甘乔(M. Ganjoo)、C. D. 曼宁(C. D. Manning)和 A. 吴(A. Ng)。通过跨模态迁移进行零样本学习。收录于《神经信息处理系统进展会议论文集》，第 935 - 943 页，2013 年。

[38] C. Szegedy, W. Liu, Y. Jia, P. Sermanet, S. Reed, D. Anguelov, D. Erhan, V. Vanhoucke, and A. Rabinovich. Going deeper with convolutions. In Proc. of Computer Vision and Pattern Recognition, pages 1-9, 2015.

[38] C. 塞格迪(C. Szegedy)、W. 刘(W. Liu)、Y. 贾(Y. Jia)、P. 塞尔马内特(P. Sermanet)、S. 里德(S. Reed)、D. 安古洛夫(D. Anguelov)、D. 埃尔汉(D. Erhan)、V. 范霍克(V. Vanhoucke)和 A. 拉宾诺维奇(A. Rabinovich)。卷积网络的深度探索。收录于《计算机视觉与模式识别会议论文集》，第 1 - 9 页，2015 年。

[39] C. Wah, S. Branson, P. Welinder, P. Perona, and S. Belongie. The Caltech-UCSD Birds-200-2011 Dataset. Technical report, 2011.

[39] C. 瓦(C. Wah)、S. 布兰森(S. Branson)、P. 韦林德(P. Welinder)、P. 佩罗纳(P. Perona)和 S. 贝隆吉(S. Belongie)。加州理工学院 - 加州大学圣地亚哥分校鸟类 200 - 2011 数据集。技术报告，2011 年。

[40] X. Wang and Q. Ji. A unified probabilistic approach modeling relationships between attributes and objects. In Proc. of International Conference on Computer Vision, pages 2120- 2127, 2013.

[40] X. 王(X. Wang)和 Q. 季(Q. Ji)。一种统一的概率方法对属性和对象之间的关系进行建模。收录于《国际计算机视觉会议论文集》，第 2120 - 2127 页，2013 年。

[41] Y. Wang and G. Mori. A discriminative latent model of object classes and attributes. In Proc. of European Conference on Computer Vision, pages 155-168, 2010.

[41] 王(Y. Wang)和森(G. Mori)。物体类别和属性的判别式潜在模型。见《欧洲计算机视觉会议论文集》，第155 - 168页，2010年。

[42] Y. Xian, Z. Akata, G. Sharma, Q. Nguyen, M. A. Hein, and B. Schiele. Latent embeddings for zero-shot classification. In Proc. of Computer Vision and Pattern Recognition, pages 69-77, 2016.

[42] 西安(Y. Xian)、阿卡塔(Z. Akata)、夏尔马(G. Sharma)、阮(Q. Nguyen)、海因(M. A. Hein)和席勒(B. Schiele)。用于零样本分类的潜在嵌入。见《计算机视觉与模式识别会议论文集》，第69 - 77页，2016年。

[43] F. Yu, L. Cao, R. Feris, J. Smith, and S.-F. Chang. Designing category-level attributes for discriminative visual recognition. In Proc. of Computer Vision and Pattern Recognition, pages 771-778, 2013.

[43] 余(F. Yu)、曹(L. Cao)、费里斯(R. Feris)、史密斯(J. Smith)和张(S.-F. Chang)。为判别式视觉识别设计类别级属性。见《计算机视觉与模式识别会议论文集》，第771 - 778页，2013年。

[44] Z. Zhang and V. Saligrama. Zero-shot learning via semantic similarity embedding. In Proc. of International Conference on Computer Vision, pages 4166-4174, 2015.

[44] 张(Z. Zhang)和萨利格拉马(V. Saligrama)。通过语义相似性嵌入实现零样本学习。见《国际计算机视觉会议论文集》，第4166 - 4174页，2015年。

[45] Z. Zhang and V. Saligrama. Zero-shot learning via joint latent similarity embedding. In Proc. of Computer Vision and Pattern Recognition, pages 6034-6042, 2016.

[45] 张(Z. Zhang)和萨利格拉马(V. Saligrama)。通过联合潜在相似性嵌入实现零样本学习。见《计算机视觉与模式识别会议论文集》，第6034 - 6042页，2016年。

[46] Z. Zhang and V. Saligrama. Zero-shot recognition via structured prediction. In Proc. of European Conference on Computer Vision, pages 533-548, 2016.

[46] 张(Z. Zhang)和萨利格拉马(V. Saligrama)。通过结构化预测实现零样本识别。见《欧洲计算机视觉会议论文集》，第533 - 548页，2016年。