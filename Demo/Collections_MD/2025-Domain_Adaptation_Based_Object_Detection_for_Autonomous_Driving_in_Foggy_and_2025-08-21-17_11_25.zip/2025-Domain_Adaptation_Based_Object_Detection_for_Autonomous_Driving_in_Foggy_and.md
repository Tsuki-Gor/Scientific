# Domain Adaptation based Object Detection for Autonomous Driving in Foggy and Rainy Weather

# 基于领域自适应的自动驾驶雾雨天气目标检测

Jinlong Li, Runsheng Xu, Xinyu Liu, Jin Ma, Baolu Li, Qin Zou, Jiaqi Ma, Hongkai Yu*

李金龙，徐润生，刘新宇，马晋，李宝禄，邹勤，马佳琪，余洪凯*

${Abstract}$ -Typically, object detection methods for autonomous driving that rely on supervised learning make the assumption of a consistent feature distribution between the training and testing data, this such assumption may fail in different weather conditions. Due to the domain gap, a detection model trained under clear weather may not perform well in foggy and rainy conditions. Overcoming detection bottlenecks in foggy and rainy weather is a real challenge for autonomous vehicles deployed in the wild. To bridge the domain gap and improve the performance of object detection in foggy and rainy weather, this paper presents a novel framework for domain-adaptive object detection. The adaptations at both the image-level and object-level are intended to minimize the differences in image style and object appearance between domains. Furthermore, in order to improve the model's performance on challenging examples, we introduce a novel adversarial gradient reversal layer that conducts adversarial mining on difficult instances in addition to domain adaptation. Additionally, we suggest generating an auxiliary domain through data augmentation to enforce a new domain-level metric regularization. Experimental findings on public benchmark exhibit a substantial enhancement in object detection specifically for foggy and rainy driving scenarios. The code is available at https://github.com/jinlong17/DA-Detect.

${Abstract}$ - 通常，依赖监督学习的自动驾驶目标检测方法假设训练和测试数据之间的特征分布一致，但该假设在不同天气条件下可能失效。由于领域差异，在晴朗天气下训练的检测模型在雾天和雨天的表现可能不佳。克服雾雨天气下的检测瓶颈是部署于实际环境中的自动驾驶车辆面临的真实挑战。为弥合领域差异并提升雾雨天气下的目标检测性能，本文提出了一种新颖的领域自适应目标检测框架。该框架在图像级和目标级进行适应，旨在最小化不同领域间的图像风格和目标外观差异。此外，为提升模型在困难样本上的表现，我们引入了一种新颖的对抗梯度反转层，除了领域自适应外，还对困难实例进行对抗挖掘。我们还建议通过数据增强生成辅助域，以施加新的域级度量正则化。公开基准实验结果表明，该方法在雾雨驾驶场景的目标检测上有显著提升。代码地址:https://github.com/jinlong17/DA-Detect。

Index Terms-intelligent vehicles, deep learning, object detection, domain adaptation

关键词-智能车辆，深度学习，目标检测，领域自适应

## I. INTRODUCTION

## 一、引言

TI HE past decade has witnessed the significant break- throughs on autonomous driving with artificial intelligence methods [2], [3], leading to numerous applications in transportation, including improving traffic safety [4]-[6], reducing traffic congestion [7], [8], minimizing air pollution [9], [10], and enhancing traffic efficiency [11]-[13]. Object detection is a critical component of autonomous driving, which relies on computer vision and artificial intelligence techniques to understand driving scenarios [2], [14]. However, the foggy and rainy weather conditions make the understanding of camera images particularly difficult, which poses challenges to the camera based object detection system installed on the intelligent vehicles [15]-[17].

过去十年，人工智能方法在自动驾驶领域取得了重大突破[2]，[3]，推动了交通运输的多项应用，包括提升交通安全[4]-[6]、缓解交通拥堵[7]，[8]、减少空气污染[9]，[10]以及提高交通效率[11]-[13]。目标检测是自动驾驶的关键组成部分，依赖计算机视觉和人工智能技术理解驾驶场景[2]，[14]。然而，雾雨天气条件使摄像头图像的理解变得尤为困难，给智能车辆上的基于摄像头的目标检测系统带来了挑战[15]-[17]。

Thanks to the rapid advancements in deep learning, numerous object detection deep learning-based methods have achieved remarkable success in intelligent transportation systems. However, the impressive performance of these popular methods heavily relies on large-scale annotated data for supervised learning. Moreover, these methods make the assumption of consistent feature distributions between the training and testing data. In reality, this assumption may not hold true, especially in diverse weather conditions [22]. For example, as depicted in Fig. 1, CNN models such as YOLOv4 [20], Faster R-CNN [18], and Mask R-CNN [19], trained on clear-weather data (source domain), exhibit accurate object detection performance under clear weather conditions (Fig. 1b). However, their performance significantly degrades under foggy weather conditions (Fig. 1c). This degradation can be attributed to the presence of a feature domain gap between different weather conditions, as illustrated in Fig. 1a. The model trained on the source domain is not familiar with the feature distribution in the target domain. Consequently, this paper aims to enhance object detection specifically in foggy and rainy weather conditions through domain adaptation-based transfer learning.

得益于深度学习的快速发展，众多基于深度学习的目标检测方法在智能交通系统中取得了显著成功。然而，这些方法的优异表现高度依赖于大规模标注数据的监督学习。此外，这些方法假设训练和测试数据的特征分布一致。实际上，这一假设在多变的天气条件下往往不成立[22]。例如，如图1所示，在晴朗天气数据(源域)上训练的卷积神经网络模型，如YOLOv4[20]、Faster R-CNN[18]和Mask R-CNN[19]，在晴朗天气条件下表现出准确的目标检测能力(图1b)，但在雾天条件下性能显著下降(图1c)。这种性能下降归因于不同天气条件下存在的特征领域差异，如图1a所示。源域训练的模型对目标域的特征分布不熟悉。因此，本文旨在通过基于领域自适应的迁移学习，提升雾雨天气条件下的目标检测性能。

![bo_d282pqf7aajc738orlug_0_916_504_743_580_0.jpg](images/bo_d282pqf7aajc738orlug_0_916_504_743_580_0.jpg)

Fig. 1. Illustration of the weather domain gap (foggy and rainy) for autonomous driving and the detection performance drop because of the domain gap. Three deep learning models ( Faster R-CNN [18], Mask R-CNN [19], and YOLOv4 [20]) are all trained with the clear weather data of Cityscapes [21].

图1. 自动驾驶中雾雨天气的领域差异示意及领域差异导致的检测性能下降。三个深度学习模型(Faster R-CNN[18]、Mask R-CNN[19]和YOLOv4[20])均在Cityscapes[21]晴朗天气数据上训练。

The objective of this paper is to reduce the domain gap between various weathers for enhanced object detection. To handle the domain shift problem (e.g. Clear $\rightarrow$ Foggy and Clear $\rightarrow$ Rainy), in this paper, we present a new domain adaptation framework that aims to enhance the robustness of object detection in foggy and rainy weather conditions. Our proposed framework follows an unsupervised setting, similar to previous works [23]-[25]. In this setting, we have well-labeled clear-weather images as the source domain, while the foggy and rainy weather images, which serve as the target domains, lack any annotations. This unsupervised setting is because adverse weather images with labeling (manual annotating) are time-consuming and costly. Inspired by [23], [26], the proposed method aims to reduce the domain feature discrepancies in both image style and object appearance. To enhance robustness and prevent data-level overfitting, we propose a Dynamic Masking Process to generate masked images by "dropping" some pixel regions. To achieve domain-invariant features, we incorporate both image-level and object-level domain classifiers as components to facilitate domain adaptation in our CNN architecture. These classifiers are responsible for distinguishing between different domains. By employing an adversarial approach, our detection model learns to generate features that are invariant to domain variations, thereby confusing the domain classifiers. This adversarial design encourages the network to produce features that are agnostic to specific weather conditions, leading to improved object detection performance in foggy and rainy weather scenarios.

本文的目标是缩小不同天气条件下的领域差异，以提升目标检测的性能。为了解决领域迁移问题(例如晴天$\rightarrow$雾天和晴天$\rightarrow$雨天)，本文提出了一种新的领域自适应框架，旨在增强目标检测在雾天和雨天条件下的鲁棒性。我们提出的框架采用无监督设置，类似于之前的工作[23]-[25]。在该设置中，我们拥有标注完善的晴天图像作为源域，而作为目标域的雾天和雨天图像则没有任何标注。之所以采用无监督设置，是因为带标注的恶劣天气图像(人工标注)耗时且成本高。受[23]、[26]的启发，所提方法旨在减少图像风格和目标外观两个方面的领域特征差异。为了增强鲁棒性并防止数据层面的过拟合，我们提出了动态掩码处理，通过“丢弃”部分像素区域生成掩码图像。为了实现领域不变特征，我们在卷积神经网络(CNN)架构中引入了图像级和目标级的领域分类器，作为促进领域自适应的组成部分。这些分类器负责区分不同领域。通过采用对抗性方法，我们的检测模型学习生成对领域变化不敏感的特征，从而迷惑领域分类器。这种对抗设计促使网络产生对特定天气条件无关的特征，进而提升雾天和雨天场景下的目标检测性能。

---

Jinlong Li, Jin Ma, and Xinyu Liu are with the Department of Computer Science, Cleveland State University, Cleveland, OH 44115, USA. Baolu Li and Hongkai Yu are with the Department of Electrical and Computer Engineering, Cleveland State University, Cleveland, OH 44115, USA. Runsheng Xu and Jiaqi Ma are with the Department of Civil and Environmental Engineering, University of California, Los Angeles, CA 90024, USA. Qin Zou is with the School of Computer Science, Wuhan University, Wuhan 430072, China. A preliminary version of this work has been published on the IEEE/CVF WACV2023 conference [1]. This work was supported by NSF 2215388.

Jinlong Li、Jin Ma 和 Xinyu Liu 隶属于美国俄亥俄州克利夫兰州立大学(Cleveland State University)计算机科学系，邮编44115。Baolu Li 和 Hongkai Yu 隶属于同校电气与计算机工程系。Runsheng Xu 和 Jiaqi Ma 隶属于美国加利福尼亚大学洛杉矶分校(University of California, Los Angeles)土木与环境工程系，邮编90024。Qin Zou 隶属于中国武汉大学计算机科学学院，邮编430072。该工作的初步版本已发表于IEEE/CVF WACV2023会议[1]。本工作得到美国国家科学基金会(NSF)项目2215388的支持。

* Corresponding author: Hongkai Yu (e-mail: h.yu19@csuohio.edu).

* 通讯作者:Hongkai Yu(电子邮箱:h.yu19@csuohio.edu)。

---

Furthermore, we propose a novel methodology for domain adaptation (DA). Current existing domain adaptation methods [23], [25]-[28] might ignore: 1) the different challenging levels of various training samples, 2) the domain-level feature metric distance to the third related domain by only involving the source domain and target domain. This paper investigates the incorporation of hard example mining and an additional related domain to further strengthen the model's ability to learn robust and transferable representations. We propose a novel Adversarial Gradient Reversal Layer (AdvGRL) and introduce an auxiliary domain through data augmentation. The AdvGRL is designed to perform adversarial mining on challenging examples, thereby improving the model's ability to learn in challenging scenarios. Additionally, the auxiliary domain is leveraged to enforce a new domain-level metric regularization during the transfer learning process. In summary, the contributions of this paper can be summarized as follows:

此外，我们提出了一种新颖的领域自适应(DA)方法。现有的领域自适应方法[23]、[25]-[28]可能忽略了:1)不同训练样本的挑战难度差异，2)仅涉及源域和目标域时，忽视了与第三相关域的领域级特征度量距离。本文探讨了结合困难样本挖掘和额外相关域，以进一步增强模型学习鲁棒且可迁移表示的能力。我们提出了一种新颖的对抗梯度反转层(Adversarial Gradient Reversal Layer，AdvGRL)，并通过数据增强引入辅助域。AdvGRL旨在对困难样本进行对抗挖掘，从而提升模型在挑战性场景中的学习能力。此外，辅助域被用来在迁移学习过程中施加新的领域级度量正则化。总之，本文的贡献可归纳如下:

- This paper proposes a novel unsupervised domain adaptation method to enhance object detection for autonomous vehicles under foggy and rainy conditions, including the image-level and object-level adaptations.

- 本文提出了一种新颖的无监督领域自适应方法，以提升自动驾驶车辆在雾天和雨天条件下的目标检测性能，涵盖图像级和目标级的自适应。

- This paper proposes to perform adversarial mining for hard examples during domain adaptation to further improve the model's transfer learning capabilities under challenging samples, which is accomplished by our proposed AdvGRL.

- 本文提出在领域自适应过程中对困难样本进行对抗挖掘，以进一步提升模型在挑战样本下的迁移学习能力，该方法通过我们提出的AdvGRL实现。

- This paper proposes a new domain-level metric regularization to improve transfer learning, i.e., the regularization constraint between source domain, added auxiliary domain, and target domain.

- 本文提出了一种新的领域级度量正则化方法，以改善迁移学习，即在源域、添加的辅助域和目标域之间施加正则化约束。

- This paper explores the intensive transfer learning experiments of clear $\rightarrow$ foggy, clear $\rightarrow$ rainy, cross-camera adaptation, and also carefully studies the different-intensity (small, medium, large) fog and rain adaptations.

- 本文开展了晴天$\rightarrow$雾天、晴天$\rightarrow$雨天、跨摄像头适应的深入迁移学习实验，并细致研究了不同强度(小、中、大)雾和雨的适应效果。

## II. RELATED WORK

## 二、相关工作

## A. Detection for intelligent vehicles

## A. 智能车辆的检测技术

The contemporary realm of intelligent vehicles has garnered considerable attention, primarily directing towards the enhancement of road safety, mitigation of traffic congestion, and the overall optimization of transportation systems [29], [30]. Recent strides in deep learning have been pivotal in propelling the field of intelligent vehicles forward [31]-[33]. Within this landscape, object detection has emerged as a focal point of extensive research endeavors, encompassing the identification and classification of objects such as vehicles, pedestrians, traffic signs, traffic lights, and assessing road conditions [34], [35]. Deep learning methods have been prominently introduced to address object detection tasks, generally falling into two distinct categories: two-stage object detectors and one-stage object detectors. Faster RCNN [18] and Mask RCNN [19] are one of the classic two-stage methods, which typically consist of two main stages: region proposal generation and object classification/localization. While YOLO series [36] and SSD [37] are one of the representative one-stage methods, which typically use a set of predefined anchor boxes or default boxes at different scales and aspect ratios to densely cover the image. [38] designed an edge intelligence-based vehicle detection algorithm based on YOLOv4 to augment vehicle detection capabilities. [39], on the other hand, proposed a multistage algorithm that initially leverages the YOLOv3 network for object detection. It's also worth noting that Faster R-CNN and Mask R-CNN have been conventionally employed for vehicle detection in the context of intelligent vehicles [40], attesting to their commendable performance in various scenarios. However, the direct application of these methods in autonomous driving settings is often constrained by the formidable challenges posed by adverse real-world weather conditions.

当代智能车辆领域备受关注，主要聚焦于提升道路安全、缓解交通拥堵及整体优化交通系统[29]，[30]。近年来深度学习的进展在推动智能车辆领域发展中起到了关键作用[31]-[33]。在此背景下，目标检测成为广泛研究的焦点，涵盖车辆、行人、交通标志、交通信号灯的识别与分类，以及道路状况评估[34]，[35]。深度学习方法被广泛应用于目标检测任务，通常分为两类:两阶段目标检测器和单阶段目标检测器。Faster RCNN[18]和Mask RCNN[19]是经典的两阶段方法，通常包括两个主要阶段:区域提议生成和目标分类/定位。而YOLO系列[36]和SSD[37]是代表性的单阶段方法，通常使用一组预定义的锚框或默认框，覆盖不同尺度和长宽比的图像。[38]设计了一种基于边缘智能的车辆检测算法，基于YOLOv4以增强车辆检测能力。[39]则提出了一种多阶段算法，初步利用YOLOv3网络进行目标检测。值得注意的是，Faster R-CNN和Mask R-CNN在智能车辆领域的车辆检测中被广泛采用[40]，其在多种场景中表现优异。然而，这些方法在自动驾驶环境中的直接应用常受现实恶劣天气条件带来的严峻挑战限制。

## B. Detection for intelligent vehicles under foggy and rainy weather

## B. 雾雨天气下智能车辆的检测

In recent years, considerable research has been dedicated to addressing the challenges posed by various weather conditions encountered in autonomous driving scenarios. Researchers have generated various datasets [22], [41] and proposed numerous methods [42]-[47] to improve object detection under adverse weather conditions. One notable example is the Foggy Cityscape dataset, which is a synthetic dataset created by applying fog simulation to the Cityscape dataset [22]. In the context of object detection research in rainy weather, several synthesized rainy datasets have been proposed [46]-[48]. [43] devised a fog simulation technique to augment existing real lidar datasets, thereby enhancing their quality and realism. The simulated foggy data offers valuable opportunities to enhance object detection methods that are specifically tailored for foggy weather conditions. For leveraging information from multiple sensors, [45] designed a network to integrate data from different sensors e.g., LiDAR, camera, and radar. [44] proposed a method that exploits both LiDAR and radar signals to obtain object proposals. The features extracted from the regions of interest in both sensors are fused together to improve the performance of object detection. However, these mentioned methods often rely on input data from different types of sensors other than the camera alone, which may not be applicable to all autonomous driving vehicles. Therefore, the objective of this work is to develop a DA network by utilizing only camera-sensor data as input.

近年来，针对自动驾驶场景中各种天气条件带来的挑战，研究投入显著增加。研究人员构建了多种数据集[22]，[41]，并提出了众多方法[42]-[47]以提升恶劣天气下的目标检测性能。其中一个典型例子是Foggy Cityscape数据集，该数据集通过对Cityscape数据集[22]施加雾模拟生成的合成数据集。在雨天目标检测研究中，也提出了若干合成雨天数据集[46]-[48]。[43]设计了一种雾模拟技术，用以增强现有真实激光雷达(LiDAR)数据集的质量和真实性。模拟的雾天数据为专门针对雾天条件的目标检测方法提供了宝贵的提升机会。为利用多传感器信息，[45]设计了一个网络以融合来自不同传感器(如LiDAR、摄像头和雷达)的数据。[44]提出了一种方法，利用LiDAR和雷达信号获取目标提议，并将两种传感器感兴趣区域提取的特征融合，以提升目标检测性能。然而，上述方法通常依赖于除摄像头外的多种传感器输入，可能不适用于所有自动驾驶车辆。因此，本研究旨在仅利用摄像头传感器数据作为输入，开发一个领域自适应(DA)网络。

## C. Object Detection via Domain Adaptation

## C. 通过领域自适应实现目标检测

Domain adaptation is effective in reducing the distribution discrepancy between different domains, enabling models trained on a labeled source domain to be applicable to an unlabeled target domain. There has been a growing interest in addressing domain adaptation for object detection [23], [26], [49]-[54] in recent years. Several studies [23], [26], [50], [54], [55] have explored the alignment of features from different domains to achieve DA object detectors. A DA Faster R-CNN framework [23] was proposed to reduce the domain gap at both the image level and instance level. He et al. [55] proposed a multi-adversarial network that aligns domain features and proposal features hierarchically to minimize domain distribution disparity. In addition to feature alignment, image style transfer approaches [34], [49], [56], [57] are utilized to address the challenge of DA. An image translation module [34] was utilized to convert images from the source domain to the target domain. They then trained the object detector using adversarial training on the target domain. [56] adopted a progressive image translation strategy and introduced a weighted task loss during adversarial training to address image quality differences. Several previous methods [58]-[61] have also proposed complex architectures for domain adaptation in object detection. Feature Pyramid Networks (FPN) was utilized to incorporate pixel-level and category-level adaptation for object detection [58]. In order to incorporate the uncertainty of unlabeled target data, [60] introduced an uncertainty-guided self-training mechanism, which leverages a Probabilistic Teacher and Focal Loss. Different with these methods, our approach does not introduce additional learnable parameters to the Faster R-CNN. Instead, we utilize an AdvGRL and a Domain-level Metric Regularization based on triplet loss. A key difference between our method and previous domain adaptation approaches lies in the treatment of training samples. While existing methods often assume that training samples are at the same challenging level, our approach introduces the AdvGRL for adversarial hard example mining, specifically targeting the improvement of transfer learning performance. Additionally, to mitigate overfitting and improve domain adaptation, an auxiliary domain is generated and incorporated into domain-level metric regularization.

领域自适应在减少不同领域之间的分布差异方面效果显著，使得在有标签的源领域上训练的模型能够应用于无标签的目标领域。近年来，针对目标检测的领域自适应[23]，[26]，[49]-[54]引起了越来越多的关注。多项研究[23]，[26]，[50]，[54]，[55]探讨了不同领域特征的对齐以实现领域自适应目标检测器。提出了一种DA Faster R-CNN框架[23]，旨在减少图像级和实例级的领域差距。He等人[55]提出了一种多对抗网络，分层对齐领域特征和提议特征，以最小化领域分布差异。除了特征对齐，图像风格迁移方法[34]，[49]，[56]，[57]也被用于解决领域自适应的挑战。图像转换模块[34]被用来将源领域图像转换为目标领域图像，随后在目标领域上通过对抗训练训练目标检测器。[56]采用了渐进式图像转换策略，并在对抗训练中引入加权任务损失以应对图像质量差异。此前的多种方法[58]-[61]也提出了复杂的架构用于目标检测中的领域自适应。特征金字塔网络(FPN)被用于结合像素级和类别级的适应[58]。为了考虑无标签目标数据的不确定性，[60]引入了基于不确定性的自训练机制，利用概率教师(Probabilistic Teacher)和焦点损失(Focal Loss)。与这些方法不同，我们的方法没有向Faster R-CNN引入额外的可学习参数，而是利用了基于三元组损失的AdvGRL和领域级度量正则化。我们方法与以往领域自适应方法的一个关键区别在于训练样本的处理。现有方法通常假设训练样本具有相同的难度级别，而我们的方法引入了AdvGRL用于对抗性困难样本挖掘，专门针对提升迁移学习性能。此外，为了缓解过拟合并提升领域自适应效果，引入了辅助领域并将其纳入领域级度量正则化。

## III. METHODOLOGY

## 三、方法论

This section introduces the overall network architecture, each detailed component, loss functions of our proposed method.

本节介绍我们提出方法的整体网络架构、各个详细组件及损失函数。

## A. Network Architecture

## A. 网络架构

As shown in Fig. 2, our proposed network follows the pipeline of Faster R-CNN. In the first step, we deploy a Dynamic Masking Process to generate the masked images, then we involve a CNN backbone to extract the image-level features from masked images. These features are then fed into the Region Proposal Network to produce region proposals. The next stage involves the Region of Interest (ROI) pooling, both the image-level features and the object proposals are as input to obtain object-level features. Finally, we apply a detection head for the object-level features to make the final outputs. To enhance the framework of Faster R-CNN for domain adaptation, we incorporate two additional domain adaptation modules: image-level and object-level modules. Both of them utilize a novel AdvGRL in conjunction with the domain classifier. By combining these modules, we are able to extract domain-invariant features and effectively perform adversarial hard example mining. Additionally, an auxiliary domain is introduced to enforce a new domain-level metric regularization. During training, source, target, and auxiliary domains, are simultaneously utilized.

如图2所示，我们提出的网络遵循Faster R-CNN的流程。第一步，我们部署动态掩码过程生成掩码图像，然后利用CNN主干网络从掩码图像中提取图像级特征。接着将这些特征输入区域提议网络(RPN)生成区域提议。下一阶段是兴趣区域(ROI)池化，图像级特征和目标提议共同作为输入以获得目标级特征。最后，我们对目标级特征应用检测头以输出最终结果。为了增强Faster R-CNN在领域自适应中的表现，我们引入了两个额外的领域自适应模块:图像级和目标级模块。两者均结合了新颖的AdvGRL与领域分类器。通过结合这些模块，我们能够提取领域不变特征并有效执行对抗性困难样本挖掘。此外，引入辅助领域以施加新的领域级度量正则化。训练过程中，源领域、目标领域和辅助领域同时被利用。

## B. Dynamic Masking Process

## B. 动态掩码过程

Before feeding the input images into the CNN backbone, we implement our newly proposed Dynamic Masking Process (DMP) to generate masked images. This deep learning method can leverage contextual clues derived from surrounding image patches that may represent various parts of the object or its environment [62]-[64]. In the training of deep learning models, the Dropout method is employed effectively by randomly "dropping" neurons within the network to combat overfitting in CNNs [65]. Drawing inspiration from [62], [64], and to bolster the learning of robust features while also curbing overfitting, our DMP selectively masks patches, each comprising 64 pixels across three input images. During model training, our DMP enhances robustness and prevents data-level overfitting by randomly "dropping" these patches (i.e., some specific pixel regions within the images), which is illustrated in Fig. 4. The patch mask rate is randomly sampled, following a uniform distribution ranging from 0 to 1 .

在将输入图像送入CNN主干网络之前，我们实施了新提出的动态掩码过程(DMP)以生成掩码图像。该深度学习方法能够利用来自周围图像块的上下文线索，这些图像块可能代表物体的不同部分或其环境[62]-[64]。在深度学习模型训练中，Dropout方法通过随机“丢弃”网络中的神经元，有效防止CNN过拟合[65]。借鉴[62]，[64]的思路，为了增强鲁棒特征的学习并抑制过拟合，我们的DMP选择性地掩码图像块，每个图像块包含64个像素，覆盖三张输入图像。在模型训练过程中，DMP通过随机“丢弃”这些图像块(即图像中的特定像素区域)来增强鲁棒性并防止数据层面的过拟合，如图4所示。图像块掩码率随机采样，服从0到1的均匀分布。

## C. Image-level based Adaptation

## C. 基于图像级的适应

The image-level domain representation is derived from the feature extraction process of the backbone network, encompassing valuable global information such as style, scale, and illumination. These factors have the potential to greatly influence the performance of the object detection task [23]. To address this, we incorporate a domain classifier, which aims to classify the domains of the extracted image-level features and promote global alignment at the image level. The domain classifier is implemented as two simple convolutional layers. It takes the image-level features as input and produces a prediction to identify the feature domain. A Binary Cross Entropy (BCE) loss is employed for the domain classifier as follows:

图像级域表示来源于主干网络的特征提取过程，包含了诸如风格、尺度和光照等宝贵的全局信息。这些因素可能极大地影响目标检测任务的性能[23]。为此，我们引入了一个域分类器，旨在对提取的图像级特征进行域分类，促进图像级的全局对齐。该域分类器由两个简单的卷积层实现。它以图像级特征为输入，输出用于识别特征域的预测结果。域分类器采用二元交叉熵(Binary Cross Entropy, BCE)损失，定义如下:

$$
{L}_{img} =  - \mathop{\sum }\limits_{{i = 1}}^{N}\left\lbrack  {{G}_{i}\log {P}_{i} + \left( {1 - {G}_{i}}\right) \log \left( {1 - {P}_{i}}\right) }\right\rbrack  , \tag{1}
$$

where $i \in  \{ 1,\ldots , N\}$ represents the $N$ training images, the ground truth domain label of the $i$ -th training image is denoted as ${G}_{i} \in  \{ 1,0\}$ , where ${G}_{i}$ takes a value of 1 or 0 to represent the source and target domains, respectively. The prediction of the domain classifier for the $i$ -th training image is denoted as ${P}_{i}$ .

其中$i \in  \{ 1,\ldots , N\}$表示$N$训练图像，$i$ -th训练图像的真实域标签记为${G}_{i} \in  \{ 1,0\}$，其中${G}_{i}$取值为1或0，分别表示源域和目标域。域分类器对$i$ -th训练图像的预测记为${P}_{i}$。

![bo_d282pqf7aajc738orlug_3_134_174_1519_577_0.jpg](images/bo_d282pqf7aajc738orlug_3_134_174_1519_577_0.jpg)

Fig. 2. The architecture of the proposed domain adaptation-based enhanced detection for intelligent vehicles in foggy and rainy weather. Here we illustrate our target domain using the example of foggy weather. It is recommended to view this figure in color.

图2. 本文提出的基于域适应的智能车辆在雾雨天气下增强检测架构。此处以雾天作为目标域示例。建议以彩色方式查看此图。

## D. Object-level based Adaptation

## D. 基于目标级的适应

Besides the global differences at the image level, objects within different domains may exhibit variations in terms of appearance, size, color, and other characteristics. To address this, Each region proposal generated by the ROI Pooling layer is considered as a potential object of interest. After obtaining the object-level domain representation via ROI pooling, we introduce an object-level domain classifier to discern the origin of the local features, which is implemented by three fully connected layers. The objective of the object-level domain classifier is to align the distribution of object-level features across different domains. Similar to the image-level domain classifier, we utilize the BCE loss to train our object-level domain classifier:

除了图像级的全局差异外，不同域内的目标在外观、尺寸、颜色及其他特征上可能存在差异。为此，ROI池化层生成的每个区域提议都被视为潜在的感兴趣目标。在通过ROI池化获得目标级域表示后，我们引入了目标级域分类器以识别局部特征的来源，该分类器由三层全连接层实现。目标级域分类器的目标是对不同域间的目标级特征分布进行对齐。与图像级域分类器类似，我们采用BCE损失训练目标级域分类器，定义如下:

$$
{L}_{obj} =  - \mathop{\sum }\limits_{{i = 1}}^{N}\mathop{\sum }\limits_{{j = 1}}^{M}\left\lbrack  {{G}_{i, j}\log {P}_{i, j} + \left( {1 - {G}_{i, j}}\right) \log \left( {1 - {P}_{i, j}}\right) }\right\rbrack  . \tag{2}
$$

where $j \in  \{ 1,\ldots , M\}$ is the $j$ -th predicted object in the $i$ - th image, ${P}_{i, j}$ is the prediction of the object-level domain classifier for the $j$ -th region proposal in the $i$ -th image, the corresponding binary ground-truth label for the source and target domains is denoted as ${G}_{i, j}$ .

其中$j \in  \{ 1,\ldots , M\}$是第$j$个预测目标，位于第$i$张图像中，${P}_{i, j}$是目标级域分类器对第$j$个区域提议在第$i$张图像中的预测，源域和目标域对应的二元真实标签记为${G}_{i, j}$。

## E. Adversarial Gradient Reversal Layer

## E. 对抗梯度反转层

In this section, we will begin by providing a brief overview of the original Gradient Reversal Layer (GRL), which serves as the foundation for our proposed Adversarial Gradient Reversal Layer (AdvGRL). The original GRL was initially developed for unsupervised domain adaptation in image classification tasks [66]. During forward propagation, the GRL leaves the input unchanged. However, during back-propagation, the gradient is reversed by multiplying it by a negative scalar before propagating it to the preceding layers of the base network. This reversal of gradients serves as a mechanism to confuse the domain classifier. Like this, by reversing the gradient during back-propagation, the GRL encourages the base network to learn domain-invariant features, enabling DA. The forward propagation of GRL is defined as:

本节首先简要介绍原始梯度反转层(Gradient Reversal Layer, GRL)，这是我们提出的对抗梯度反转层(AdvGRL)的基础。原始GRL最初用于图像分类任务中的无监督域适应[66]。在前向传播时，GRL保持输入不变；但在反向传播时，梯度会被乘以一个负标量反转，然后传递给基础网络的前一层。梯度的反转机制用于干扰域分类器。通过在反向传播中反转梯度，GRL促使基础网络学习域不变特征，从而实现域适应。GRL的前向传播定义如下:

$$
{R}_{\lambda }\left( \mathbf{v}\right)  = \mathbf{v} \tag{3}
$$

![bo_d282pqf7aajc738orlug_3_972_926_603_325_0.jpg](images/bo_d282pqf7aajc738orlug_3_972_926_603_325_0.jpg)

Fig. 3. Illustration of the AdvGRL-based hard training example mining. We assign larger responses to harder training examples with lower domain classifier loss $\left( {L}_{c}\right)$ values. In this paper, we set ${\lambda }_{0} = 1$ and $\beta  = {30}$ .

图3. 基于AdvGRL的困难训练样本挖掘示意。我们对域分类器损失$\left( {L}_{c}\right)$较低的困难训练样本赋予更大响应。本文中，我们设置了${\lambda }_{0} = 1$和$\beta  = {30}$。

![bo_d282pqf7aajc738orlug_3_912_1416_744_188_0.jpg](images/bo_d282pqf7aajc738orlug_3_912_1416_744_188_0.jpg)

Fig. 4. Sample visualization of Dynamic Masking Process (DMP): (a) the masked original image from Cityscapes [21], (b) masked synthesized foggy image, (c) masked synthesized rainy image.

图4. 动态掩码过程(Dynamic Masking Process, DMP)示例可视化:(a)Cityscapes [21]中的原始图像掩码，(b)合成雾天图像掩码，(c)合成雨天图像掩码。

where $\mathbf{v}$ represents an input feature vector, and ${R}_{\lambda }$ represents the forward function performed by GRL. Back-propagation of GRL is defined as:

其中$\mathbf{v}$表示输入特征向量，${R}_{\lambda }$表示GRL执行的前向函数。GRL的反向传播定义如下:

$$
\frac{d{R}_{\lambda }}{d\mathbf{v}} =  - \lambda \mathbf{I}, \tag{4}
$$

where $\mathbf{I}$ is an identity matrix and $- \lambda$ is a negative scalar. In the original GRL, a constant or varying value of $- \lambda$ is utilized, which is determined by the training iterations, as described in [66]. However, this approach overlooks the fact that different training samples may exhibit varying levels of challenge during transfer learning. To address this limitation, this paper introduces a novel AdvGRL that incorporates adversarial mining for hard examples. This is achieved by replacing the parameter $\lambda$ with a new parameter ${\lambda }_{adv}$ in Eq. (4) of GRL, resulting in the proposed AdvGRL. Notably, the value of ${\lambda }_{adv}$ is determined as follows:

其中 $\mathbf{I}$ 是单位矩阵，$- \lambda$ 是负标量。在原始的GRL(梯度反转层)中，$- \lambda$ 的值是一个常数或随训练迭代变化的值，如文献[66]所述。然而，该方法忽略了不同训练样本在迁移学习过程中可能表现出不同难度的事实。为了解决这一局限，本文提出了一种新颖的AdvGRL，结合了对难例的对抗挖掘。具体做法是在GRL的公式(4)中用新参数 ${\lambda }_{adv}$ 替代参数 $\lambda$，从而得到所提的AdvGRL。值得注意的是，${\lambda }_{adv}$ 的取值如下所示:

$$
{\lambda }_{adv} = \left\{  \begin{matrix} \min \left( {\frac{{\lambda }_{0}}{{L}_{c}},\beta }\right) , & {L}_{c} < \alpha \\  {\lambda }_{0}, & \text{ otherwise,} \end{matrix}\right.  \tag{5}
$$

where ${L}_{c}$ represents the loss of the domain classifier. $\alpha$ is a hardness threshold used to determine the difficulty level of the training sample. $\beta$ is the overflow threshold implemented to prevent the generation of excessive gradients during back-propagation. In our experiment, we set ${\lambda }_{0} = 1$ as a fixed parameter. Namely, when the domain classifier’s loss ${L}_{c}$ is smaller, it indicates that the training sample's domain can be more easily identified by the classifier. In this case, the features associated with this sample are not the desired domain-invariant features, making it a more difficult example for domain adaptation. The relationship between ${\lambda }_{adv}$ and ${L}_{c}$ is visualized in Fig. 3

其中 ${L}_{c}$ 表示域分类器的损失。$\alpha$ 是用于判断训练样本难度的硬度阈值。$\beta$ 是溢出阈值，用于防止反向传播过程中产生过大的梯度。在我们的实验中，${\lambda }_{0} = 1$ 被设定为固定参数。即当域分类器的损失 ${L}_{c}$ 较小时，表明该训练样本的域更容易被分类器识别，此时与该样本相关的特征并非期望的域不变特征，使其成为域适应中的较难样本。${\lambda }_{adv}$ 与 ${L}_{c}$ 的关系如图3所示。

Ous proposed AdvGRL serves two main purposes. 1) It utilizes the concept of gradient reversal during back-propagation to confuse the domain classifier, thereby promoting the generation of domain-invariant features. 2) AdvGRL enables adversarial mining for hard examples, meaning that it selectively focuses on challenging examples that contribute to the model's generalization. Fig. 2 illustrates the utilization of the AdvGRL in both the image-level and object-level DA modules.

我们提出的AdvGRL主要有两个目的。1)利用反向传播中的梯度反转机制干扰域分类器，从而促进域不变特征的生成。2)AdvGRL实现了对难例的对抗挖掘，即有选择地关注那些有助于模型泛化的挑战性样本。图2展示了AdvGRL在图像级和目标级域适应模块中的应用。

## F. Domain-level Metric Learning based Regularization

## F. 基于域级度量学习的正则化

A common transfer learning approach in many existing DA methods is to prioritize the transfer of features from a source domain $S$ to a target domain $T$ . Hence, they often overlook the potential advantages that a third-related domain can offer. To explore the potential advantages of incorporating a third related domain, we introduce an auxiliary domain for domain-level metric regularization that complements the source domain $S$ . We leverage advanced data augmentation techniques to create this auxiliary domain $A$ , which is particularly useful in autonomous driving scenarios where training data needs to be synthesized for different weather conditions based on existing clear-weather data. As a result, in our proposed architecture (as shown in Fig. 2), the source, auxiliary, and target domain images are regarded as aligned images, ensuring the enforcement of domain-level metric constraints across these three distinct domains.

许多现有域适应方法中的常见迁移学习策略是优先传递源域 $S$ 到目标域 $T$ 的特征，因此往往忽视了第三相关域可能带来的潜在优势。为探索引入第三相关域的潜力，我们引入了一个辅助域用于域级度量正则化，以补充源域 $S$ 。我们利用先进的数据增强技术构建该辅助域 $A$，这在自动驾驶场景中特别有用，因为需要基于现有的晴天数据合成不同天气条件下的训练数据。因此，在我们提出的架构中(如图2所示)，源域、辅助域和目标域图像被视为对齐图像，确保在这三个不同域之间施加域级度量约束。

The global image-level features of the $i$ -th training image for the source(S), auxiliary(A), and target(T)domains are defined as ${F}_{i}^{S},{F}_{i}^{A}$ , and ${F}_{i}^{T}$ , respectively. Our goal is to reduce the domain gap between $S$ and $T$ and ensure that the feature metric distance between ${F}_{i}^{S}$ and ${F}_{i}^{T}$ is closer compared to the distance between ${F}_{i}^{S}$ and ${F}_{i}^{A}$ . This can be expressed as:

源(S)、辅助(A)和目标(T)域中第 $i$ 张训练图像的全局图像级特征分别定义为 ${F}_{i}^{S},{F}_{i}^{A}$ 、${F}_{i}^{T}$ 和 $S$ 。我们的目标是缩小 $T$ 和 ${F}_{i}^{S}$ 之间的域间差距，并确保 ${F}_{i}^{A}$ 与 ${F}_{i}^{T}$ 之间的特征度量距离比 ${F}_{i}^{A}$ 与 <b7></b7> 之间的距离更接近。该关系可表示为:

$$
d\left( {{F}_{i}^{S},{F}_{i}^{T}}\right)  < d\left( {{F}_{i}^{S},{F}_{i}^{A}}\right) , \tag{6}
$$

where the metric distance between the corresponding features is denoted as $d\left( ,\right)$ . To implement this constraint, we can use a triplet structure where ${F}_{i}^{S},{F}_{i}^{T}$ , and ${F}_{i}^{A}$ are treated as the anchor, positive, and negative, respectively. Therefore, the image-level constraint in Eq. (6) can be equivalently expressed as minimizing the image-level triplet loss:

其中对应特征之间的度量距离记为 $d\left( ,\right)$ 。为实现该约束，我们可以采用三元组结构，将 ${F}_{i}^{S},{F}_{i}^{T}$ 、${F}_{i}^{A}$ 和 <b3></b3> 分别视为锚点、正样本和负样本。因此，公式(6)中的图像级约束等价于最小化图像级三元组损失:

$$
{L}_{img}^{R} = \max \left( {d\left( {{F}_{i}^{S},{F}_{i}^{T}}\right)  - d\left( {{F}_{i}^{S},{F}_{i}^{A}}\right)  + \delta ,0}\right) , \tag{7}
$$

where the margin constraint is denoted as $\delta$ , and in our experiments, $\delta$ is set as 1.0 . Equivalently, the $i$ -th training image’s $j$ -th object-level features of $S, A$ , and $T$ are defined as ${f}_{i, j}^{S},{f}_{i, j}^{A}$ , and ${f}_{i, j}^{T}$ respectively. To apply our proposed metric regularization to the object-level features, we further minimize the object-level triplet loss:

其中边界约束记为 $\delta$，在我们的实验中，$\delta$ 设为1.0。同理，第 $i$ 张训练图像的第 $j$ 个目标级特征中，$S, A$ 和 $T$ 分别定义为 ${f}_{i, j}^{S},{f}_{i, j}^{A}$ 和 ${f}_{i, j}^{T}$ 。为了将所提度量正则化应用于目标级特征，我们进一步最小化目标级三元组损失:

$$
{L}_{obj}^{R} = \max \left( {d\left( {{f}_{i, j}^{S},{f}_{i, j}^{T}}\right)  - d\left( {{f}_{i, j}^{S},{f}_{i, j}^{A}}\right)  + \delta ,0}\right) . \tag{8}
$$

## G. Training Loss

## G. 训练损失

The overall training loss of the proposed network consists of several individual components. It can be expressed as follows:

所提网络的整体训练损失由多个单独组成部分构成。其表达式如下:

$$
L = \gamma  * \left( {{L}_{img} + {L}_{obj} + {L}_{img}^{R} + {L}_{obj}^{R}}\right)  + {L}_{cls} + {L}_{reg}, \tag{9}
$$

where ${L}_{cls}$ and ${L}_{reg}$ represent the loss of classification and the loss of regression respectively. A weight parameter $\gamma$ is introduced to balance the Faster R-CNN loss and the domain adaptation loss, which is set as 0.1 . During the training phase, the network can be trained in an end-to-end manner utilizing a standard SGD algorithm. During the testing phase, object detection can be performed using the Faster R-CNN with the trained adapted weights.

其中${L}_{cls}$和${L}_{reg}$分别表示分类损失和回归损失。引入权重参数$\gamma$以平衡Faster R-CNN损失和域适应损失，该参数设为0.1。在训练阶段，网络可利用标准的随机梯度下降(SGD)算法进行端到端训练。在测试阶段，可使用带有训练后适应权重的Faster R-CNN进行目标检测。

## H. General Domain Adaptive Detection with Proposed Method

## H. 使用所提方法进行通用域自适应检测

Our proposed method is designed to be versatile and adaptable to various domain adaptive object detection scenarios. Specifically, when dealing with scenarios where the target domain images are generated from the source domain with pixel-to-pixel correspondence, such as the Clear Cityscapes $\rightarrow$ Foggy Cityscapes, our method can be directly applied without any modifications. To utilize our method with unaligned datasets in real-world scenarios, where the target and source domains lack strict correspondence, such as the Cityscapes $\rightarrow$ KITTI, we can remove the ${L}_{obj}^{R}$ loss, which eliminates the requirement for object alignment during training. This allows our method to be applied directly without the need for object-level alignment.

我们提出的方法设计为通用且适应多种域自适应目标检测场景。具体而言，当目标域图像与源域图像存在像素级对应关系时，如Clear Cityscapes $\rightarrow$ Foggy Cityscapes，我们的方法可直接应用，无需修改。对于现实场景中目标域与源域缺乏严格对应关系的未对齐数据集，如Cityscapes $\rightarrow$ KITTI，我们可以去除${L}_{obj}^{R}$损失，从而消除训练过程中对目标对齐的需求，使方法可直接应用，无需目标级对齐。

![bo_d282pqf7aajc738orlug_5_138_168_747_187_0.jpg](images/bo_d282pqf7aajc738orlug_5_138_168_747_187_0.jpg)

Fig. 5. Illustration of synthesizing Rainy Cityscapes from the Cityscapes data: (a) the original image from Cityscapes [21], (b) rain map generated by RainMix [67], (c) synthesized rainy image.

图5. 从Cityscapes数据合成Rainy Cityscapes示意图:(a) Cityscapes [21]的原始图像，(b) 由RainMix [67]生成的雨图，(c) 合成的雨天图像。

## IV. EXPERIMENTS

## IV. 实验

## A. Benchmark

## A. 基准数据集

Cityscapes [21]: It is a widely used computer vision dataset that focuses on urban street scenes. There are 2,975 training sets and 500 validation sets from 27 different cities. The dataset includes annotations for 8 different categories. All images in the Cityscapes dataset are 3-channel ${1024} \times  {2048}$ images.

Cityscapes [21]:这是一个广泛使用的计算机视觉数据集，聚焦于城市街景。包含来自27个不同城市的2,975个训练集和500个验证集。数据集包含8个不同类别的标注。Cityscapes数据集中的所有图像均为3通道${1024} \times  {2048}$图像。

Foggy Cityscapes [22]: It is a public benchmark dataset created by simulating different intensity levels of fog on the original Cityscapes images. This dataset uses a depth map and a physical model [22] to generate three levels of simulated fog.

Foggy Cityscapes [22]:这是一个公开的基准数据集，通过在原始Cityscapes图像上模拟不同强度的雾生成。该数据集利用深度图和物理模型[22]生成三种不同强度的模拟雾。

Rainy Cityscapes: We synthesize a rainy-weather dataset named as Rainy Cityscapes in this paper from the original Cityscapes dataset. Specifically, the training set of 3,475 images and the validation set of 500 images from Cityscapes are used to create the Rainy Cityscapes dataset by utilizing a novel data augmentation method called RainMix [67], [68]. To generate rainy Cityscapes images, we utilize a combination of techniques. First, we randomly sample a rain map from a publicly dataset of real rain streaks [69]. Next, we apply random transformations to the rain map using the RainMix technique. These transformations include rotation, zooming, translation, and shearing, which are randomly sampled and combined. Lastly, the rain maps after transformation are merged with the original source domain images, resulting in the generation of rainy Cityscapes images. An example illustrating this process can be seen in Figure 5

Rainy Cityscapes:本文从原始Cityscapes数据集中合成了一个名为Rainy Cityscapes的雨天数据集。具体地，利用Cityscapes的3,475张训练图像和500张验证图像，通过一种名为RainMix [67], [68]的新颖数据增强方法创建Rainy Cityscapes数据集。为生成雨天Cityscapes图像，我们结合多种技术。首先，从一个公开的真实雨线数据集[69]中随机采样雨图。接着，使用RainMix技术对雨图进行随机变换，包括旋转、缩放、平移和剪切，这些变换随机采样并组合。最后，将变换后的雨图与原始源域图像融合，生成雨天Cityscapes图像。该过程示例如图5所示。

Intensity levels of fog/rain: For the Foggy Cityscapes and Rainy Cityscapes datasets, their number of images, resolution, and annotations are identical to those of the Clear Cityscapes dataset. Based on the physical model of [22], the different intensity levels of fog could be synthesized on the Foggy Cityscapes dataset. After obtaining the rain maps by Rain-Mix [67], the intensity of rain maps could be further processed with different erosion levels. In these two ways, the different fog and rain levels (small, medium, large) can be synthesized, as shown in Fig. 6 Following the setting [23], [26], [54], the images with the highest intensity level of fog/rain are selected as the target domain for model training. The models trained with the highest intensity level will be then used to test the performance on the validation sets of different fog/rain intensity levels (small, medium, large).

雾/雨强度等级:对于Foggy Cityscapes和Rainy Cityscapes数据集，其图像数量、分辨率和标注与Clear Cityscapes数据集相同。基于文献[22]的物理模型，可在Foggy Cityscapes数据集上合成不同强度等级的雾。通过RainMix [67]获得雨图后，可对雨图强度进行不同腐蚀等级的处理。通过这两种方式，可合成不同等级(小、中、大)的雾和雨，如图6所示。按照文献[23], [26], [54]的设置，选择最高强度等级的雾/雨图像作为模型训练的目标域。使用最高强度等级训练的模型随后用于测试不同雾/雨强度等级(小、中、大)验证集上的性能。

## B. Experimental Setting

## B. 实验设置

Dataset setting: We conducted two main experiments in this paper: 1) Clear to Foggy Adaptation, denoted as Clear Cityscapes $\rightarrow$ Foggy Cityscapes, the labeled training set of Clear Cityscapes [21] and the unlabeled training set of Foggy Cityscapes [22] are used as the source and target domains during training, respectively. Subsequently, the trained model was evaluated by the Foggy Cityscapes validation set to report the performance. Rainy Cityscapes training set is used as the Auxiliary Domain $A$ in this Clear to Foggy Adaptation experiment. 2) Clear to Rainy Adaptation, denoted as the Clear Cityscapes $\rightarrow$ Rainy Cityscapes, where the labeled training set of Clear Cityscapes [21] and the unlabeled training set of Rainy Cityscapes are used as the source and target domains during training, respectively. Then the trained model was evaluated on Rainy Cityscapes validation set to report the performance. Foggy Cityscapes training set is used as the Auxiliary Domain $A$ in this Clear to Rainy Adaptation experiment. Additionally, we analyzed the transfer learning performance on different intensity levels of fog and rain (small, medium, and large).

数据集设置:本文进行了两个主要实验:1)晴天到雾天的适应，记为晴天Cityscapes $\rightarrow$ 雾天Cityscapes，训练时使用带标签的晴天Cityscapes [21] 作为源域，无标签的雾天Cityscapes [22] 作为目标域。随后，使用雾天Cityscapes验证集评估训练好的模型性能。雨天Cityscapes训练集作为辅助域 $A$ 用于该晴天到雾天的适应实验。2)晴天到雨天的适应，记为晴天Cityscapes $\rightarrow$ 雨天Cityscapes，训练时使用带标签的晴天Cityscapes [21] 作为源域，无标签的雨天Cityscapes作为目标域。然后在雨天Cityscapes验证集上评估训练好的模型性能。雾天Cityscapes训练集作为辅助域 $A$ 用于该晴天到雨天的适应实验。此外，我们分析了不同强度等级的雾和雨(小、中、大)下的迁移学习性能。

Training setting: We utilize ResNet-50 as the backbone for the Faster R-CNN [18]. Following in [18], [23], during training, We utilize back-propagation and stochastic gradient descent (SGD) to optimize all the deep learning methods in our approach. The initial learning rate of 0.01 for 50,000 iterations is used in all model training. Afterward, the learning rate is reduced to 0.001 and training continues for an additional 20,000 iterations. Weight decay is set as 0.0005 and momentum is set as 0.9 for all experiments. Each training batch consists of three images from the source, target, and auxiliary domains respectively. For comparison purposes, we set the $\lambda$ value in the original GRL (Equation (4)) to 1. In the AdvGRL (Equation (5)), the hardness threshold $\alpha$ is set to 0.63, which is computed by averaging the parameters in Equation (1) with setting $\left( {{P}_{i} = {0.7},{G}_{i} = 1}\right.$ and $\left. {{P}_{i} = {0.3},{G}_{i} = 0}\right)$ . In the subsequent analysis, we refer to "Reg + AdvGRL" as our proposed DA method. Additionally, "Reg + AdvGRL + DMP" is designated as our enhanced DA method, termed DA+, which is named "Ours+" for short in the tables.

训练设置:我们采用ResNet-50作为Faster R-CNN [18] 的骨干网络。按照文献[18]，[23]，训练过程中，我们使用反向传播和随机梯度下降(SGD)优化本文方法中的所有深度学习模型。所有模型训练均采用初始学习率0.01，训练50,000次迭代。随后学习率降低至0.001，继续训练20,000次迭代。权重衰减设置为0.0005，动量设置为0.9。每个训练批次包含来自源域、目标域和辅助域的各三张图像。为便于比较，我们将原始GRL(公式(4))中的 $\lambda$ 值设为1。在AdvGRL(公式(5))中，困难度阈值 $\alpha$ 设为0.63，该值通过平均公式(1)中参数并设置 $\left( {{P}_{i} = {0.7},{G}_{i} = 1}\right.$ 和 $\left. {{P}_{i} = {0.3},{G}_{i} = 0}\right)$ 计算得出。后续分析中，我们将“Reg + AdvGRL”称为我们提出的域适应(DA)方法。此外，“Reg + AdvGRL + DMP”被指定为我们增强的DA方法，称为DA+，在表格中简称为“Ours+”。

Evaluation metrics: We calculate the Average Precision for each category and the mean Average Precision across all categories using an Intersection over the Union threshold of 0.5 .

评估指标:我们计算每个类别的平均精度(Average Precision，AP)以及所有类别的平均平均精度(mean Average Precision，mAP)，采用交并比(IoU)阈值为0.5。

## C. Adaptation from Clear to Foggy

## C. 从晴天到雾天的适应

Table 1 presents the results of our experiments on weather adaptation from clear to foggy. In comparison to other DA methods, our proposed DA+ method achieves the highest performance on Foggy Cityscape, with a mAP of ${43.4}\%$ , which outperforms the third-best method SCAN [75] by a margin of 1.3% in terms of mAP improvement. The proposed DA+ method effectively reduces the domain gap across various categories, e.g., the rider got 49.1% and the bicycle got 41.6% as the second best performance, and the train got ${51.3}\%$ as the best performance in AP, which is the highlight in Table 1 While UMT got ${56.6}\%$ in the bus and ${34.1}\%$ in the truck, ConfMix got ${62.6}\%$ in the car, MeGA-CDA got ${49.0}\%$ in the rider, our proposed DA+ method exhibits similar performance across them with only minor differences. However, our proposed DA+ method achieves the highest overall mAP detection performance on Foggy Cityscapes among the recent DA methods.

表1展示了我们关于晴天到雾天天气适应的实验结果。与其他域适应方法相比，我们提出的DA+方法在雾天Cityscapes上取得了最高性能，mAP为 ${43.4}\%$ ，比第三名方法SCAN [75]的mAP提升了1.3%。所提DA+方法有效缩小了各类别间的域差距，例如骑手类别达到49.1%，自行车类别达到41.6%，均为第二佳表现，火车类别以 ${51.3}\%$ 获得最佳AP表现，这是表1的亮点。虽然UMT在公交车类别获得 ${56.6}\%$ ，卡车类别获得 ${34.1}\%$ ，ConfMix在汽车类别获得 ${62.6}\%$ ，MeGA-CDA在骑手类别获得 ${49.0}\%$ ，我们提出的DA+方法在这些类别表现相近，仅有细微差别。然而，我们的DA+方法在最近的域适应方法中实现了雾天Cityscapes上最高的整体mAP检测性能。

TABLE I

Adaptation from Clear to Foggy: Cityscapes $\rightarrow$ Foggy Cityscapes experiment. Note that Oracle represents the Faster R-CNN trained on foggcy Cityscape training set with all labels. The best performance is bold and the second best is underlined.

晴天到雾天的适应:Cityscapes $\rightarrow$ 雾天Cityscapes实验。注意，Oracle代表在带标签的雾天Cityscapes训练集上训练的Faster R-CNN。最佳性能以粗体显示，次佳性能加下划线。

<table><tr><td>Methodologies</td><td>${C}_{bus}$</td><td>${C}_{\text{bicycle }}$</td><td>${C}_{car}$</td><td>${C}_{\text{mcycle }}$</td><td>${C}_{person}$</td><td>${C}_{rider}$</td><td>${C}_{train}$</td><td>${C}_{truck}$</td><td>mAP</td></tr><tr><td>MCAR-ECCV’2020 [51]</td><td>44.1</td><td>36.6</td><td>43.9</td><td>37.4</td><td>32.0</td><td>42.1</td><td>43.4</td><td>31.3</td><td>38.8</td></tr><tr><td>MTOR-CVPR-2019 [70]</td><td>38.6</td><td>35.6</td><td>44.0</td><td>28.3</td><td>30.6</td><td>41.4</td><td>40.6</td><td>21.9</td><td>35.1</td></tr><tr><td>DA-Faster-CVPR’2018 [23]</td><td>49.8</td><td>39.0</td><td>53.0</td><td>28.9</td><td>35.7</td><td>45.2</td><td>45.4</td><td>30.9</td><td>41.0</td></tr><tr><td>GPA-CVPR’2020 [54]</td><td>45.7</td><td>38.7</td><td>54.1</td><td>32.4</td><td>32.9</td><td>46.7</td><td>41.1</td><td>24.7</td><td>39.5</td></tr><tr><td>RPN-PR-CVPR’2021 [53]</td><td>43.6</td><td>36.8</td><td>50.5</td><td>29.7</td><td>33.3</td><td>45.6</td><td>42.0</td><td>30.4</td><td>39.0</td></tr><tr><td>UaDAN-TMM’2021 [26</td><td>49.4</td><td>38.9</td><td>53.6</td><td>32.3</td><td>36.5</td><td>46.1</td><td>42.7</td><td>28.9</td><td>41.1</td></tr><tr><td>HTCN-CVPR’2020 [71]</td><td>47.4</td><td>37.1</td><td>47.9</td><td>32.3</td><td>33.2</td><td>47.5</td><td>40.9</td><td>31.6</td><td>39.8</td></tr><tr><td>SAPN-ECCV’2020 [72]</td><td>46.8</td><td>40.7</td><td>59.8</td><td>30.4</td><td>40.8</td><td>46.7</td><td>37.5</td><td>24.3</td><td>40.9</td></tr><tr><td>MeGA-CDA-CVPR’2021 [73]</td><td>49.2</td><td>39.0</td><td>52.4</td><td>34.5</td><td>37.7</td><td>49.0</td><td>46.9</td><td>25.4</td><td>41.8</td></tr><tr><td>UMT-CVPR2021 [74]</td><td>56.6</td><td>37.3</td><td>48.6</td><td>30.4</td><td>33.0</td><td>46.7</td><td>46.8</td><td>34.1</td><td>41.7</td></tr><tr><td>SCAN-AAAI’2022 [75]</td><td>48.6</td><td>37.3</td><td>57.3</td><td>31.0</td><td>41.7</td><td>43.9</td><td>48.7</td><td>28.7</td><td>42.1</td></tr><tr><td>ParaUDA-TITS’2022 T6</td><td>48.3</td><td>37.6</td><td>52.5</td><td>33.5</td><td>36.7</td><td>46.7</td><td>45.9</td><td>32.3</td><td>41.7</td></tr><tr><td>ConfMix-WACV’2023 177</td><td>45.8</td><td>33.5</td><td>62.6</td><td>28.6</td><td>45.0</td><td>43.4</td><td>40.0</td><td>27.3</td><td>40.8</td></tr><tr><td>SDAYOLO-TIV’2023 [78]</td><td>40.5</td><td>37.3</td><td>61.9</td><td>24.4</td><td>42.6</td><td>42.1</td><td>39.5</td><td>23.5</td><td>39.0</td></tr><tr><td>MS-DAYOLO-TIP’2023 [79]</td><td>51.0</td><td>36.0</td><td>56.5</td><td>27.5</td><td>39.6</td><td>46.5</td><td>45.9</td><td>28.9</td><td>41.5</td></tr><tr><td>Ours w/o Auxiliary Domain</td><td>48.4</td><td>36.7</td><td>53.5</td><td>26.1</td><td>36.1</td><td>45.9</td><td>39.1</td><td>29.3</td><td>40.2</td></tr><tr><td>Ours</td><td>51.2</td><td>39.1</td><td>54.3</td><td>31.6</td><td>36.5</td><td>46.7</td><td>48.7</td><td>30.3</td><td>42.3</td></tr><tr><td>Ours+</td><td>48.7</td><td>41.6</td><td>55.8</td><td>33.3</td><td>36.5</td><td>49.1</td><td>51.3</td><td>30.0</td><td>43.4</td></tr><tr><td>Oracle</td><td>49.9</td><td>45.8</td><td>65.2</td><td>39.6</td><td>46.5</td><td>51.3</td><td>34.2</td><td>32.6</td><td>45.6</td></tr></table>

<table><tbody><tr><td>方法论</td><td>${C}_{bus}$</td><td>${C}_{\text{bicycle }}$</td><td>${C}_{car}$</td><td>${C}_{\text{mcycle }}$</td><td>${C}_{person}$</td><td>${C}_{rider}$</td><td>${C}_{train}$</td><td>${C}_{truck}$</td><td>平均精度均值(mAP)</td></tr><tr><td>MCAR-ECCV’2020 [51]</td><td>44.1</td><td>36.6</td><td>43.9</td><td>37.4</td><td>32.0</td><td>42.1</td><td>43.4</td><td>31.3</td><td>38.8</td></tr><tr><td>MTOR-CVPR-2019 [70]</td><td>38.6</td><td>35.6</td><td>44.0</td><td>28.3</td><td>30.6</td><td>41.4</td><td>40.6</td><td>21.9</td><td>35.1</td></tr><tr><td>DA-Faster-CVPR’2018 [23]</td><td>49.8</td><td>39.0</td><td>53.0</td><td>28.9</td><td>35.7</td><td>45.2</td><td>45.4</td><td>30.9</td><td>41.0</td></tr><tr><td>GPA-CVPR’2020 [54]</td><td>45.7</td><td>38.7</td><td>54.1</td><td>32.4</td><td>32.9</td><td>46.7</td><td>41.1</td><td>24.7</td><td>39.5</td></tr><tr><td>RPN-PR-CVPR’2021 [53]</td><td>43.6</td><td>36.8</td><td>50.5</td><td>29.7</td><td>33.3</td><td>45.6</td><td>42.0</td><td>30.4</td><td>39.0</td></tr><tr><td>UaDAN-TMM’2021 [26</td><td>49.4</td><td>38.9</td><td>53.6</td><td>32.3</td><td>36.5</td><td>46.1</td><td>42.7</td><td>28.9</td><td>41.1</td></tr><tr><td>HTCN-CVPR’2020 [71]</td><td>47.4</td><td>37.1</td><td>47.9</td><td>32.3</td><td>33.2</td><td>47.5</td><td>40.9</td><td>31.6</td><td>39.8</td></tr><tr><td>SAPN-ECCV’2020 [72]</td><td>46.8</td><td>40.7</td><td>59.8</td><td>30.4</td><td>40.8</td><td>46.7</td><td>37.5</td><td>24.3</td><td>40.9</td></tr><tr><td>MeGA-CDA-CVPR’2021 [73]</td><td>49.2</td><td>39.0</td><td>52.4</td><td>34.5</td><td>37.7</td><td>49.0</td><td>46.9</td><td>25.4</td><td>41.8</td></tr><tr><td>UMT-CVPR2021 [74]</td><td>56.6</td><td>37.3</td><td>48.6</td><td>30.4</td><td>33.0</td><td>46.7</td><td>46.8</td><td>34.1</td><td>41.7</td></tr><tr><td>SCAN-AAAI’2022 [75]</td><td>48.6</td><td>37.3</td><td>57.3</td><td>31.0</td><td>41.7</td><td>43.9</td><td>48.7</td><td>28.7</td><td>42.1</td></tr><tr><td>ParaUDA-TITS’2022 T6</td><td>48.3</td><td>37.6</td><td>52.5</td><td>33.5</td><td>36.7</td><td>46.7</td><td>45.9</td><td>32.3</td><td>41.7</td></tr><tr><td>ConfMix-WACV’2023 177</td><td>45.8</td><td>33.5</td><td>62.6</td><td>28.6</td><td>45.0</td><td>43.4</td><td>40.0</td><td>27.3</td><td>40.8</td></tr><tr><td>SDAYOLO-TIV’2023 [78]</td><td>40.5</td><td>37.3</td><td>61.9</td><td>24.4</td><td>42.6</td><td>42.1</td><td>39.5</td><td>23.5</td><td>39.0</td></tr><tr><td>MS-DAYOLO-TIP’2023 [79]</td><td>51.0</td><td>36.0</td><td>56.5</td><td>27.5</td><td>39.6</td><td>46.5</td><td>45.9</td><td>28.9</td><td>41.5</td></tr><tr><td>无辅助域的本方法</td><td>48.4</td><td>36.7</td><td>53.5</td><td>26.1</td><td>36.1</td><td>45.9</td><td>39.1</td><td>29.3</td><td>40.2</td></tr><tr><td>本方法</td><td>51.2</td><td>39.1</td><td>54.3</td><td>31.6</td><td>36.5</td><td>46.7</td><td>48.7</td><td>30.3</td><td>42.3</td></tr><tr><td>本方法+</td><td>48.7</td><td>41.6</td><td>55.8</td><td>33.3</td><td>36.5</td><td>49.1</td><td>51.3</td><td>30.0</td><td>43.4</td></tr><tr><td>理想模型</td><td>49.9</td><td>45.8</td><td>65.2</td><td>39.6</td><td>46.5</td><td>51.3</td><td>34.2</td><td>32.6</td><td>45.6</td></tr></tbody></table>

TABLE II

Adaptation from Clear to Rainy: Cityscapes $\rightarrow$ Rainy Cityscapes experiment. Note that Oracle represents the Faster R-CNN trained on rainy Cityscapes training set with all labels. The best performance is bold and the second best is underlined.

从晴天到雨天的适应:Cityscapes $\rightarrow$ 雨天Cityscapes实验。注意，Oracle代表在带有所有标签的雨天Cityscapes训练集上训练的Faster R-CNN(快速区域卷积神经网络)。最佳表现加粗，次佳表现加下划线。

<table><tr><td>Methodologies</td><td>${C}_{bus}$</td><td>${C}_{\text{bicycle }}$</td><td>${C}_{car}$</td><td>${C}_{\text{mcycle }}$</td><td>Cperson</td><td>${C}_{rider}$</td><td>${C}_{train}$</td><td>${C}_{truck}$</td><td>mAP</td></tr><tr><td>Faster R-CNN (source only)</td><td>46.3</td><td>26.0</td><td>54.8</td><td>25.8</td><td>34.7</td><td>35.9</td><td>26.9</td><td>23.9</td><td>34.3</td></tr><tr><td>DA-Faster-CVPR’2018 [23]</td><td>54.6</td><td>33.8</td><td>59.6</td><td>32.4</td><td>38.2</td><td>41.6</td><td>42.9</td><td>33.8</td><td>42.1</td></tr><tr><td>MS-DAYOLO-TIP’2023 [79]</td><td>60.3</td><td>34.4</td><td>67.7</td><td>31.9</td><td>47.2</td><td>47.4</td><td>31.9</td><td>30.7</td><td>44.0</td></tr><tr><td>Ours w/o Auxiliary Domain</td><td>55.5</td><td>35.3</td><td>60.0</td><td>32.8</td><td>38.3</td><td>22.1</td><td>49.3</td><td>33.1</td><td>43.4</td></tr><tr><td>Ours</td><td>60.0</td><td>35.3</td><td>60.6</td><td>33.8</td><td>38.8</td><td>42.9</td><td>52.4</td><td>36.3</td><td>45.0</td></tr><tr><td>Ours+</td><td>59.7</td><td>39.0</td><td>$\underline{61.7}$</td><td>34.4</td><td>40.2</td><td>47.0</td><td>47.2</td><td>38.8</td><td>46.0</td></tr><tr><td>Oracle</td><td>58.5</td><td>35.3</td><td>66.9</td><td>35.7</td><td>47.5</td><td>50.9</td><td>37.4</td><td>40.5</td><td>46.6</td></tr></table>

<table><tbody><tr><td>方法论</td><td>${C}_{bus}$</td><td>${C}_{\text{bicycle }}$</td><td>${C}_{car}$</td><td>${C}_{\text{mcycle }}$</td><td>Cperson</td><td>${C}_{rider}$</td><td>${C}_{train}$</td><td>${C}_{truck}$</td><td>mAP(平均精度均值)</td></tr><tr><td>Faster R-CNN(仅源域)</td><td>46.3</td><td>26.0</td><td>54.8</td><td>25.8</td><td>34.7</td><td>35.9</td><td>26.9</td><td>23.9</td><td>34.3</td></tr><tr><td>DA-Faster-CVPR’2018 [23]</td><td>54.6</td><td>33.8</td><td>59.6</td><td>32.4</td><td>38.2</td><td>41.6</td><td>42.9</td><td>33.8</td><td>42.1</td></tr><tr><td>MS-DAYOLO-TIP’2023 [79]</td><td>60.3</td><td>34.4</td><td>67.7</td><td>31.9</td><td>47.2</td><td>47.4</td><td>31.9</td><td>30.7</td><td>44.0</td></tr><tr><td>本方法(无辅助域)</td><td>55.5</td><td>35.3</td><td>60.0</td><td>32.8</td><td>38.3</td><td>22.1</td><td>49.3</td><td>33.1</td><td>43.4</td></tr><tr><td>本方法</td><td>60.0</td><td>35.3</td><td>60.6</td><td>33.8</td><td>38.8</td><td>42.9</td><td>52.4</td><td>36.3</td><td>45.0</td></tr><tr><td>本方法+</td><td>59.7</td><td>39.0</td><td>$\underline{61.7}$</td><td>34.4</td><td>40.2</td><td>47.0</td><td>47.2</td><td>38.8</td><td>46.0</td></tr><tr><td>理想模型</td><td>58.5</td><td>35.3</td><td>66.9</td><td>35.7</td><td>47.5</td><td>50.9</td><td>37.4</td><td>40.5</td><td>46.6</td></tr></tbody></table>

![bo_d282pqf7aajc738orlug_6_138_1485_746_370_0.jpg](images/bo_d282pqf7aajc738orlug_6_138_1485_746_370_0.jpg)

Fig. 6. Sample visualization results for the Foggy Cityscapes and Rainy Cityscapes validation sets with different intensity levels.

图6. 不同强度等级的雾霾城市景观(Foggy Cityscapes)和雨天城市景观(Rainy Cityscapes)验证集的示例可视化结果。

TABLE III

ABLATION STUDY OF COMPONENTS ON THE EXPERIMENTS OF CITYSCAPES $\rightarrow$ FOGGY CITYSCAPES AND CITYSCAPES $\rightarrow$ RAINY CITYSCAPES.

关于城市景观(Cityscapes)、雾霾城市景观(Foggy Cityscapes)和雨天城市景观(Rainy Cityscapes)实验中各组件的消融研究。

<table><tr><td>Methods</td><td>Img</td><td>Obj</td><td>AdvGRL</td><td>Reg</td><td>DMP</td><td>Foggy mAP</td><td>Rainy mAP</td></tr><tr><td>Source only</td><td/><td/><td/><td/><td/><td>23.41</td><td>34.35</td></tr><tr><td>w/ DMP</td><td/><td/><td/><td/><td>✓</td><td>24.54</td><td>35.90</td></tr><tr><td>img w/ GRL</td><td>✓</td><td/><td/><td/><td/><td>38.10</td><td>36.41</td></tr><tr><td>obj w/ GRL</td><td/><td>✓</td><td/><td/><td/><td>38.02</td><td>37.92</td></tr><tr><td>img+obj w/ GRL (Baseline)</td><td>✓</td><td>✓</td><td/><td/><td/><td>38.43</td><td>41.02</td></tr><tr><td>img+obj w/AdvGRL</td><td>✓</td><td>✓</td><td>✓</td><td/><td/><td>40.23</td><td>43.44</td></tr><tr><td>img+obj+ Reg w/ GRL</td><td>✓</td><td>✓</td><td/><td>✓</td><td/><td>41.97</td><td>44.44</td></tr><tr><td>img+obj+Reg w/ AdvGRL</td><td>✓</td><td>✓</td><td>✓</td><td>✓</td><td/><td>42.34</td><td>45.07</td></tr><tr><td>img+obj+Reg+DMP w/ AdvGRL</td><td>✓</td><td>✓</td><td>✓</td><td>✓</td><td>✓</td><td>43.42</td><td>46.04</td></tr></table>

<table><tbody><tr><td>方法</td><td>图像</td><td>对象</td><td>对抗梯度反转层(AdvGRL)</td><td>正则化</td><td>DMP</td><td>雾天mAP</td><td>雨天mAP</td></tr><tr><td>仅源域</td><td></td><td></td><td></td><td></td><td></td><td>23.41</td><td>34.35</td></tr><tr><td>含DMP</td><td></td><td></td><td></td><td></td><td>✓</td><td>24.54</td><td>35.90</td></tr><tr><td>含GRL的图像</td><td>✓</td><td></td><td></td><td></td><td></td><td>38.10</td><td>36.41</td></tr><tr><td>含GRL的对象</td><td></td><td>✓</td><td></td><td></td><td></td><td>38.02</td><td>37.92</td></tr><tr><td>含GRL的图像+对象(基线)</td><td>✓</td><td>✓</td><td></td><td></td><td></td><td>38.43</td><td>41.02</td></tr><tr><td>含AdvGRL的图像+对象</td><td>✓</td><td>✓</td><td>✓</td><td></td><td></td><td>40.23</td><td>43.44</td></tr><tr><td>含GRL的图像+对象+正则化</td><td>✓</td><td>✓</td><td></td><td>✓</td><td></td><td>41.97</td><td>44.44</td></tr><tr><td>含AdvGRL的图像+对象+正则化</td><td>✓</td><td>✓</td><td>✓</td><td>✓</td><td></td><td>42.34</td><td>45.07</td></tr><tr><td>含AdvGRL的图像+对象+正则化+DMP</td><td>✓</td><td>✓</td><td>✓</td><td>✓</td><td>✓</td><td>43.42</td><td>46.04</td></tr></tbody></table>

## D. Adaptation from Clear to Rainy

## D. 从晴天到雨天的适应

In the Clear to Rainy adaptation, the only difference during training is the exchange of domains, where the unlabelled Rainy Cityscapes training set serves as the target domain, while the Foggy Cityscapes training set is used as the auxiliary domain. Table II presents the results of domain adaptation from clear to rainy weather. Due to the page limit, we choose the methods with the publicly available source code which perform very well in the Clear to Foggy Adaptation experiment as the comparison methods in this Clear to Rainy Adaptation experiment, i.e., DA-Faster [23], MS-DAYOLO [79]. Similar to the Clear to Foggy Adaptation, our proposed DA+ method got the best overall mAP (46.0%) detection performance on Rainy Cityscapes compared to the comparison methods.

在晴天到雨天的适应中，训练过程中的唯一差异是域的交换，其中未标注的雨天Cityscapes训练集作为目标域，而雾天Cityscapes训练集用作辅助域。表II展示了从晴天到雨天的域适应结果。由于篇幅限制，我们选择了在晴天到雾天适应实验中表现优异且公开了源码的方法作为本次晴天到雨天适应实验的对比方法，即DA-Faster [23]、MS-DAYOLO [79]。与晴天到雾天适应类似，我们提出的DA+方法在雨天Cityscapes上获得了最佳的整体mAP(46.0%)检测性能，优于对比方法。

![bo_d282pqf7aajc738orlug_7_158_155_723_491_0.jpg](images/bo_d282pqf7aajc738orlug_7_158_155_723_491_0.jpg)

Fig. 7. Visualization of the qualitative detection on Foggy/Rainy Cityscapes (validation sets). First column (Source only): original Faster R-CNN w/ DA, Second column (Baseline): Faster R-CNN with image-level and object-level adaptations w/ GRL, Third column: Proposed DA Method. Top: foggy weather, Bottom: rainy weather.

图7. 雾天/雨天Cityscapes(验证集)上的定性检测可视化。第一列(仅源域):原始带DA的Faster R-CNN，第二列(基线):带图像级和目标级适应及GRL的Faster R-CNN，第三列:提出的DA方法。上排:雾天， 下排:雨天。

## E. Ablation Study of Components

## E. 组件消融研究

We conduct an analysis of the individual proposed components of our DA object detection method. The experiments are conducted on the Cityscapes $\rightarrow$ Foggy Cityscapes and Cityscapes $\rightarrow$ Rainy Cityscapes tasks, using the ResNet- 50 backbone. The results of the ablation study are presented in Table III. In the first row of the table, image-level and object-level adaptation modules are labels as 'img' and 'obj', respectively. 'AdvGRL' and 'Reg' indicate the proposed Adversarial GRL and domain-level metric regularization, respectively. The 'img+obj+GRL' configuration represents the Baseline model used in our experiments. We also evaluate two additional configurations: 'img+obj+AdvGRL' and 'img+obj+AdvGRL+Reg'. Additionally, we include the 'Source only' configuration, which refers to the Faster R-CNN model trained solely on labeled source domain images without any DA methods. The ablation study presented in Table III provides clear evidence of the positive impact of each proposed component in the DA method for both foggy and rainy weather scenarios. Furthermore, we provide qualitative visualization of the object detection results in Fig. 7.

我们对提出的DA目标检测方法的各个组成部分进行了分析。实验在Cityscapes $\rightarrow$ 雾天Cityscapes和Cityscapes $\rightarrow$ 雨天Cityscapes任务上进行，采用ResNet-50骨干网络。消融研究结果见表III。表中第一行，图像级和目标级适应模块分别标记为'img'和'obj'。'AdvGRL'和'Reg'分别表示提出的对抗GRL和域级度量正则化。'img+obj+GRL'配置代表我们实验中的基线模型。我们还评估了两种额外配置:'img+obj+AdvGRL'和'img+obj+AdvGRL+Reg'。此外，还包括仅在标注源域图像上训练的Faster R-CNN模型('仅源域'配置)，未使用任何DA方法。表III的消融研究清晰证明了各个提出组件在雾天和雨天场景中对DA方法的积极影响。我们还在图7中提供了目标检测结果的定性可视化。

## F. Adaptation of Different-intensity Fog and Rain

## F. 不同强度雾雨的适应

Moreover, both simulated Foggy and Rainy Cityscapes datasets contain three levels of intensity, namely Small, Medium, and Large as depicted in Fig. 6 Following the previous works [23], [26], [54], we only utilize the Large intensity level as the target domain during training for both fog and rain. After training, the trained models on the validation set of Rainy Cityscapes and Foggy Cityscapes with images of different intensity levels are evaluated. For the three intensity levels of fog and rain, as shown in Table IV, the 'Baseline' model after domain adaptation could get better detection performance compared to the 'Source only' without DA, while the Proposed Method could continue to further improve the performance compared to the 'Baseline' method. Alternatively, our proposed DA method could significantly mitigate the impact of fog and rain under Small, Medium, and Large intensity levels.

此外，模拟的雾天和雨天Cityscapes数据集均包含三种强度等级，分别为小、中、大，如图6所示。遵循前人工作[23]、[26]、[54]，训练时仅使用大强度等级作为目标域。训练完成后，在包含不同强度等级图像的雨天和雾天Cityscapes验证集上评估训练模型。表IV显示，对于三种强度等级的雾和雨，经过域适应的'基线'模型相比未使用DA的'仅源域'模型获得了更好的检测性能，而提出的方法相比'基线'方法进一步提升了性能。换言之，我们提出的DA方法能显著减轻小、中、大强度等级下雾和雨的影响。

## G. Adaptation of Cross Cameras

## G. 跨摄像头适应

We conducted an experiment specifically targeting real-world cross-camera adaptation for different autonomous driving datasets with varying camera settings. We applied our DA method for cross-camera adaptation i.e., Cityscapes dataset (source) $\rightarrow$ KITTI dataset (target). To accommodate the unaligned nature of the datasets, we simply removed the ${L}_{obj}^{R}$ term (Eq. 8) during the adaptation process. Following the previous work [23], we used the KITTI training set, consisting of 7,481 images as the target domain. Specifically, we evaluated the AP of the Car category on the target domain. Table V demonstrated the outstanding performance of our proposed DA+ method compared to recent comparison methods.

我们针对不同自动驾驶数据集的真实跨摄像头适应进行了实验，这些数据集摄像头设置各异。我们将DA方法应用于跨摄像头适应，即Cityscapes数据集(源域)$\rightarrow$ KITTI数据集(目标域)。为适应数据集间的不对齐特性，我们在适应过程中简单移除了${L}_{obj}^{R}$项(公式8)。遵循前人工作[23]，使用包含7,481张图像的KITTI训练集作为目标域。具体评估了目标域中汽车类别的AP。表V展示了我们提出的DA+方法相较于近期对比方法的卓越表现。

## H. Feature Distribution Visualization via Adaptation

## H. 通过适应进行特征分布可视化

To investigate the capability of our proposed DA method to overcome the domain shift (clear weather $\rightarrow$ rainy/foggy weather), we visualize these domain feature distributions by utilizing t-SNE [80] before and after the domain adaptation in foggy and rainy weather. Fig. 8 obviously presents that our proposed DA method could align the feature distributions to bridge the domain gap (clear weather $\rightarrow$ rainy/foggy weather).

为探究我们提出的DA方法克服域偏移(晴天$\rightarrow$雨天/雾天)的能力，我们利用t-SNE [80]对雾天和雨天域适应前后的特征分布进行了可视化。图8清晰展示了我们提出的DA方法能够对齐特征分布，弥合域间差距(晴天$\rightarrow$雨天/雾天)。

## I. Experiments on Different Parameters

## I. 不同参数的实验

We analyze the detection performance on different hyper-parameters in Section III, i.e, Eq 9 and Eq 5 for the Cityscapes $\rightarrow$ Foggy Cityscapes case, and several hyper-parameters were investigated. First of all, ${mA}{P}_{\gamma }$ can be obtained ${mA}{P}_{0.1} = {42.34},{mA}{P}_{0.01} = {41.30},{mA}{P}_{0.001} =$ 41.19, where $\gamma$ represents loss balance weight in Eq. 9 Then, in the AdvGRL (Eq. 5), the $\left( {\alpha ,\beta }\right)$ , where $\beta$ represents the overflow threshold and $\alpha$ represents hardness threshold are set as (a)(0.63,30), (b)(0.63,10), (c)(0.54,30), and (d) (0.54,10), where $\alpha  = {0.54}$ is obtained by averaging the values of Eq. 1 when ${P}_{i} = {0.9},{G}_{i} = 1$ and ${P}_{i} = {0.1},{G}_{i} = 0$ . The corresponding detection mAP(s) are (a) 42.34, (b) 38.83, (c) 39.38, (d) 40.47, respectively.

我们在第三节分析了不同超参数下的检测性能，即针对Cityscapes $\rightarrow$ Foggy Cityscapes案例中的公式9和公式5，调查了若干超参数。首先，${mA}{P}_{\gamma }$ 可获得41.19，其中 $\gamma$ 表示公式9中的损失平衡权重。然后，在AdvGRL(公式5)中，$\left( {\alpha ,\beta }\right)$，其中 $\beta$ 表示溢出阈值，$\alpha$ 表示难度阈值，分别设置为(a)(0.63,30)、(b)(0.63,10)、(c)(0.54,30)和(d)(0.54,10)，其中 $\alpha  = {0.54}$ 是通过在 ${P}_{i} = {0.9},{G}_{i} = 1$ 和 ${P}_{i} = {0.1},{G}_{i} = 0$ 时对公式1的值取平均得到的。对应的检测mAP分别为(a)42.34、(b)38.83、(c)39.38、(d)40.47。

## J. Visualization of Hard Examples

## J. 困难样本的可视化

By utilizing ${\lambda }_{adv}$ of the proposed AdvGRL, we can identify hard examples during the domain adaptation process. Fig 9 illustrates some of these hard examples. We compute the ${L}_{1}$ distance between the features ${F}_{i}^{S}$ and ${F}_{i}^{T}$ obtained from the backbone of Fig 2. This distance is used as an approximation of the example’s hardness ( ${ah}$ ), where a smaller ${ah}$ indicates a harder example for transfer learning. Intuitively, when the fog covers a larger number of objects, as illustrated by the bounding-box regions in Fig. 9, the task becomes more challenging.

通过利用所提AdvGRL的${\lambda }_{adv}$，我们可以在域适应过程中识别困难样本。图9展示了部分困难样本。我们计算了从图2骨干网络获得的特征${F}_{i}^{S}$与${F}_{i}^{T}$之间的${L}_{1}$距离。该距离被用作样本难度(${ah}$)的近似，其中较小的${ah}$表示对迁移学习更困难的样本。直观上，当雾覆盖更多物体时，如图9中边界框区域所示，任务变得更加具有挑战性。

![bo_d282pqf7aajc738orlug_8_145_168_1508_400_0.jpg](images/bo_d282pqf7aajc738orlug_8_145_168_1508_400_0.jpg)

Fig. 8. Feature distribution visualization by t-SNE [80] before and after domain adaptation. Clear to Foggy Adaptation: (a) original distribution before adaptation, (b) aligned distribution after the proposed adaptation. Clear to Rainy Adaptation: (c) original distribution before adaptation, (d) aligned distribution after the proposed adaptation. It is recommended to view this figure in color.

图8. 通过t-SNE [80]对域适应前后特征分布的可视化。晴天到雾天适应:(a)适应前的原始分布，(b)所提适应后的对齐分布。晴天到雨天适应:(c)适应前的原始分布，(d)所提适应后的对齐分布。建议彩色查看此图。

TABLE IV

Adaptation of Different-intensity Fog and Rain: Cityscapes $\rightarrow$ Foggy Cityscapes and Cityscapes $\rightarrow$ Rainy Cityscapes $\rightarrow$ Rainy Cityscapes experiments.

不同强度雾和雨的适应:Cityscapes $\rightarrow$ Foggy Cityscapes和Cityscapes $\rightarrow$ Rainy Cityscapes $\rightarrow$ Rainy Cityscapes实验。

<table><tr><td>Foggy / Rainy</td><td>Methodologies</td><td>${C}_{bus}$</td><td>${C}_{\text{bicycle }}$</td><td>${C}_{car}$</td><td>${C}_{\text{mcycle }}$</td><td>${C}_{\text{person }}$</td><td>${C}_{\text{rider }}$</td><td>${C}_{train}$</td><td>${C}_{truck}$</td><td>mAP</td></tr><tr><td rowspan="3">Large</td><td>Source only</td><td>27.1 / 46.3</td><td>${28.3}/{26.0}$</td><td>${32.8}/{54.8}$</td><td>${18.4}/{25.8}$</td><td>28.6 / 34.7</td><td>${32.2}/{35.9}$</td><td>${4.9}/{26.9}$</td><td>${14.7}/{23.9}$</td><td>${23.4}/{34.3}$</td></tr><tr><td>Baseline</td><td>45.4 / 49.5</td><td>36.7 / 32.6</td><td>${53.5}/{58.3}$</td><td>26.0 / 31.4</td><td>36.1 / 36.1</td><td>45.9 / 41.4</td><td>37.1 / 43.4</td><td>26.3 / 35.1</td><td>${38.4}/{41.0}$</td></tr><tr><td>Proposed DA Method</td><td>$\mathbf{{51.2}/{60.0}}$</td><td>39.1 / 35.3</td><td>$\mathbf{{54.3}/{60.6}}$</td><td>31.6 / 33.8</td><td>36.5 / 38.8</td><td>$\mathbf{{46.7}/{42.9}}$</td><td>$\mathbf{{48.7}/{52.4}}$</td><td>$\mathbf{{30.3}/{36.3}}$</td><td>$\mathbf{{42.3}/{45.0}}$</td></tr><tr><td rowspan="3">Medium</td><td>Source only</td><td>40.6 / 47.1</td><td>${36.9}/{26.9}$</td><td>${48.9}/{54.6}$</td><td>27.3 / 23.9</td><td>37.9 / 34.0</td><td>${43.2}/{38.6}$</td><td>40.4 / 30.8</td><td>${22.4}/{30.7}$</td><td>${37.2}/{35.8}$</td></tr><tr><td>Baseline</td><td>52.0 / 47.3</td><td>40.5 / 33.3</td><td>${58.9}/{58.2}$</td><td>31.7 / 27.9</td><td>${40.8}/{35.8}$</td><td>$\mathbf{{50.0}}/{44.3}$</td><td>39.8 / 35.1</td><td>29.9 / 36.4</td><td>42.9 / 39.8</td></tr><tr><td>Proposed DA Method</td><td>${52.6}/{58.8}$</td><td>42.6 / 37.1</td><td>$\mathbf{{59.3}/{60.0}}$</td><td>$\mathbf{{32.1}/{30.9}}$</td><td>41.2 / 38.6</td><td>47.5 / 45.1</td><td>48.8 / 41.0</td><td>32.5 / 39.7</td><td>44.6 / 43.9</td></tr><tr><td rowspan="3">Small</td><td>Source only</td><td>${49.2}/{43.8}$</td><td>${40.9}/{29.6}$</td><td>${55.7}/{55.7}$</td><td>${33.1}/{24.1}$</td><td>${41.0}/{35.7}$</td><td>47.0 / 37.5</td><td>${43.1}/{38.7}$</td><td>${28.4}/{23.3}$</td><td>42.3 / 36.0</td></tr><tr><td>Baseline</td><td>$\mathbf{{54.1}}/{42.9}$</td><td>${40.6}/{34.5}$</td><td>60.3 / 59.0</td><td>${32.5}/{30.7}$</td><td>42.0 / 36.7</td><td>$\mathbf{{51.0}/{43.7}}$</td><td>49.3 / 48.1</td><td>${31.9}/\mathbf{{36.1}}$</td><td>45.2 / 41.5</td></tr><tr><td>Proposed DA Method</td><td>${52.9}/\mathbf{{53.6}}$</td><td>43.1 / 38.3</td><td>$\mathbf{{60.6}/{61.3}}$</td><td>36.3 / 33.6</td><td>$\mathbf{{42.7}/{39.4}}$</td><td>${49.4}/{42.8}$</td><td>54.8 / 51.4</td><td>36.5 / 35.7</td><td>47.0 / 44.5</td></tr></table>

<table><tbody><tr><td>有雾/下雨</td><td>方法论</td><td>${C}_{bus}$</td><td>${C}_{\text{bicycle }}$</td><td>${C}_{car}$</td><td>${C}_{\text{mcycle }}$</td><td>${C}_{\text{person }}$</td><td>${C}_{\text{rider }}$</td><td>${C}_{train}$</td><td>${C}_{truck}$</td><td>平均精度均值(mAP)</td></tr><tr><td rowspan="3">大</td><td>仅源域</td><td>27.1 / 46.3</td><td>${28.3}/{26.0}$</td><td>${32.8}/{54.8}$</td><td>${18.4}/{25.8}$</td><td>28.6 / 34.7</td><td>${32.2}/{35.9}$</td><td>${4.9}/{26.9}$</td><td>${14.7}/{23.9}$</td><td>${23.4}/{34.3}$</td></tr><tr><td>基线</td><td>45.4 / 49.5</td><td>36.7 / 32.6</td><td>${53.5}/{58.3}$</td><td>26.0 / 31.4</td><td>36.1 / 36.1</td><td>45.9 / 41.4</td><td>37.1 / 43.4</td><td>26.3 / 35.1</td><td>${38.4}/{41.0}$</td></tr><tr><td>提出的领域自适应方法</td><td>$\mathbf{{51.2}/{60.0}}$</td><td>39.1 / 35.3</td><td>$\mathbf{{54.3}/{60.6}}$</td><td>31.6 / 33.8</td><td>36.5 / 38.8</td><td>$\mathbf{{46.7}/{42.9}}$</td><td>$\mathbf{{48.7}/{52.4}}$</td><td>$\mathbf{{30.3}/{36.3}}$</td><td>$\mathbf{{42.3}/{45.0}}$</td></tr><tr><td rowspan="3">中等</td><td>仅源域</td><td>40.6 / 47.1</td><td>${36.9}/{26.9}$</td><td>${48.9}/{54.6}$</td><td>27.3 / 23.9</td><td>37.9 / 34.0</td><td>${43.2}/{38.6}$</td><td>40.4 / 30.8</td><td>${22.4}/{30.7}$</td><td>${37.2}/{35.8}$</td></tr><tr><td>基线</td><td>52.0 / 47.3</td><td>40.5 / 33.3</td><td>${58.9}/{58.2}$</td><td>31.7 / 27.9</td><td>${40.8}/{35.8}$</td><td>$\mathbf{{50.0}}/{44.3}$</td><td>39.8 / 35.1</td><td>29.9 / 36.4</td><td>42.9 / 39.8</td></tr><tr><td>提出的领域自适应方法</td><td>${52.6}/{58.8}$</td><td>42.6 / 37.1</td><td>$\mathbf{{59.3}/{60.0}}$</td><td>$\mathbf{{32.1}/{30.9}}$</td><td>41.2 / 38.6</td><td>47.5 / 45.1</td><td>48.8 / 41.0</td><td>32.5 / 39.7</td><td>44.6 / 43.9</td></tr><tr><td rowspan="3">小</td><td>仅源域</td><td>${49.2}/{43.8}$</td><td>${40.9}/{29.6}$</td><td>${55.7}/{55.7}$</td><td>${33.1}/{24.1}$</td><td>${41.0}/{35.7}$</td><td>47.0 / 37.5</td><td>${43.1}/{38.7}$</td><td>${28.4}/{23.3}$</td><td>42.3 / 36.0</td></tr><tr><td>基线</td><td>$\mathbf{{54.1}}/{42.9}$</td><td>${40.6}/{34.5}$</td><td>60.3 / 59.0</td><td>${32.5}/{30.7}$</td><td>42.0 / 36.7</td><td>$\mathbf{{51.0}/{43.7}}$</td><td>49.3 / 48.1</td><td>${31.9}/\mathbf{{36.1}}$</td><td>45.2 / 41.5</td></tr><tr><td>提出的领域自适应方法</td><td>${52.9}/\mathbf{{53.6}}$</td><td>43.1 / 38.3</td><td>$\mathbf{{60.6}/{61.3}}$</td><td>36.3 / 33.6</td><td>$\mathbf{{42.7}/{39.4}}$</td><td>${49.4}/{42.8}$</td><td>54.8 / 51.4</td><td>36.5 / 35.7</td><td>47.0 / 44.5</td></tr></tbody></table>

TABLE V

ADAPTATION OF CROSS CAMERAS ON CITYSCAPES $\rightarrow$ KITTI EXPERIMENT.

城市景观中交叉摄像头的适配 $\rightarrow$ KITTI 实验。

<table><tr><td>Methodologies</td><td>Car AP</td></tr><tr><td>MAF-ICCV’2019 [55]</td><td>72.10</td></tr><tr><td>SWDA-CVPR’2019 J50</td><td>71.00</td></tr><tr><td>ATF-ECCV’2020 [81]</td><td>73.50</td></tr><tr><td>ART-CVPR’2020</td><td>73.60</td></tr><tr><td>GPA-CVPR’2020</td><td>65.36</td></tr><tr><td>SGA-TMM’2021</td><td>72.02</td></tr><tr><td>UIT-ESwA’2022 [83]</td><td>73.70</td></tr><tr><td>ParaUDA-TITS’2022 [76]</td><td>72.20</td></tr><tr><td>IDF-TCSVT’2023 [84]</td><td>74.00</td></tr><tr><td>Ours</td><td>74.38</td></tr><tr><td>Ours+</td><td>74.71</td></tr></table>

<table><tbody><tr><td>方法论</td><td>汽车平均精度(Car AP)</td></tr><tr><td>MAF-ICCV’2019 [55]</td><td>72.10</td></tr><tr><td>SWDA-CVPR’2019 J50</td><td>71.00</td></tr><tr><td>ATF-ECCV’2020 [81]</td><td>73.50</td></tr><tr><td>ART-CVPR’2020</td><td>73.60</td></tr><tr><td>GPA-CVPR’2020</td><td>65.36</td></tr><tr><td>SGA-TMM’2021</td><td>72.02</td></tr><tr><td>UIT-ESwA’2022 [83]</td><td>73.70</td></tr><tr><td>ParaUDA-TITS’2022 [76]</td><td>72.20</td></tr><tr><td>IDF-TCSVT’2023 [84]</td><td>74.00</td></tr><tr><td>本方法</td><td>74.38</td></tr><tr><td>本方法+</td><td>74.71</td></tr></tbody></table>

## K. Experiments on Pre-trained Models and Domain Random- ization

## K. 预训练模型与领域随机化实验

Pre-trained Models: In the experiment of Cityscapes $\rightarrow$ Foggy Cityscapes, our proposed DA method utilizes a pre-trained Faster R-CNN as an initialization and achieves a detection mean Average Precision (mAP) of 41.3, compared to a mAP of 42.3 achieved when our method is initialized without the pre-trained deep learning model.

预训练模型:在Cityscapes $\rightarrow$ Foggy Cityscapes实验中，我们提出的领域自适应(DA)方法以预训练的Faster R-CNN作为初始化，检测平均精度均值(mAP)达到41.3，而未使用预训练深度学习模型初始化时，mAP为42.3。

![bo_d282pqf7aajc738orlug_8_909_1140_747_389_0.jpg](images/bo_d282pqf7aajc738orlug_8_909_1140_747_389_0.jpg)

Fig. 9. Visualization of hard examples mined by AdvGRL. Two mined hard examples and one easy example are shown from left to right.

图9. AdvGRL挖掘的难例可视化。图中从左到右依次展示了两个挖掘出的难例和一个易例。

Domain Randomization: In the Cityscapes $\rightarrow$ Foggy Cityscapes experiment, we explore two approaches for domain randomization to reduce the domain shift between the source and target domains. 1) The first approach involves regular data augmentation techniques such as color change, blurring, and salt $\&$ pepper noises to construct the auxiliary domain. When our method is trained using this auxiliary domain, the detection mean Average Precision (mAP) achieved is 38.7, compared to our method's performance of 42.3 when using the auxiliary domain dataset i.e. rain synthesis Cityscapes dataset. 2) The second approach utilizes CycleGAN [85] to facilitate the transfer of image style between the Cityscapes training set and the Foggy Cityscapes training set. We trained a Faster R-CNN with these generated images, which got ${32.8}\mathrm{{mAP}}$ . These findings emphasize the limitations of commonly employed domain randomization techniques in effectively addressing the DA challenge.

领域随机化:在Cityscapes $\rightarrow$ Foggy Cityscapes实验中，我们探索了两种领域随机化方法以减少源域与目标域之间的域偏移。1)第一种方法采用常规数据增强技术，如颜色变化、模糊和椒盐噪声，构建辅助域。当使用该辅助域训练时，检测平均精度均值(mAP)为38.7，而使用辅助域数据集(即雨天合成Cityscapes数据集)时，mAP为42.3。2)第二种方法利用CycleGAN [85]实现Cityscapes训练集与Foggy Cityscapes训练集之间的图像风格迁移。我们用这些生成的图像训练了Faster R-CNN，结果为${32.8}\mathrm{{mAP}}$。这些结果强调了常用领域随机化技术在有效解决领域自适应挑战中的局限性。

## V. CONCLUSIONS

## V. 结论

In this paper, a novel domain adaptive object detection framework is presented, which is specifically designed for intelligent vehicle perception in foggy and rainy weather conditions. The framework incorporates both image-level and object-level adaptations to address the domain shift in global image style and local object appearance. An adversarial GRL is introduced for adversarial mining of hard examples during domain adaptation. Additionally, a domain-level metric regularization is proposed to enforce feature metric distance between the source, target, and auxiliary domains. The proposed method is evaluated through transfer learning experiments from Cityscapes to Foggy Cityscapes, Rainy Cityscapes, and KITTI. The experimental results demonstrate the effectiveness of the proposed DA method in improving object detection performance. This research contributes significantly to enhancing intelligent vehicle perception in challenging foggy and rainy weather scenarios. REFERENCES

本文提出了一种新颖的领域自适应目标检测框架，专为雾天和雨天条件下的智能车辆感知设计。该框架结合了图像级和目标级的适应，以应对全局图像风格和局部目标外观的域偏移。引入了对抗性GRL，用于领域自适应过程中对难例的对抗挖掘。此外，提出了域级度量正则化，以强化源域、目标域和辅助域之间的特征度量距离。通过从Cityscapes到Foggy Cityscapes、Rainy Cityscapes及KITTI的迁移学习实验，验证了所提方法在提升目标检测性能方面的有效性。本研究对提升智能车辆在复杂雾雨天气场景下的感知能力具有重要贡献。参考文献

[1] J. Li, R. Xu, J. Ma, Q. Zou, J. Ma, and H. Yu, "Domain adaptive object detection for autonomous driving under foggy weather," in IEEE/CVF Winter Conference on Applications of Computer Vision, 2023, pp. 612- 622.

[1] J. Li, R. Xu, J. Ma, Q. Zou, J. Ma, 和 H. Yu, “雾天自动驾驶下的领域自适应目标检测,” IEEE/CVF计算机视觉应用冬季会议, 2023, 页612-622。

[2] L. Chen, Y. Li, C. Huang, B. Li, Y. Xing, D. Tian, L. Li, Z. Hu, X. Na, Z. Li, S. Teng, C. Lv, J. Wang, D. Cao, N. Zheng, and F.-Y. Wang, "Milestones in autonomous driving and intelligent vehicles: Survey of surveys," IEEE Transactions on Intelligent Vehicles, vol. 8, no. 2, pp. 1046-1056, 2023.

[2] L. Chen, Y. Li, C. Huang, B. Li, Y. Xing, D. Tian, L. Li, Z. Hu, X. Na, Z. Li, S. Teng, C. Lv, J. Wang, D. Cao, N. Zheng, 和 F.-Y. Wang, “自动驾驶与智能车辆的里程碑:综述中的综述,” IEEE智能车辆汇刊, 第8卷第2期, 页1046-1056, 2023。

[3] L. Chen, Y. Zhang, B. Tian, Y. Ai, D. Cao, and F.-Y. Wang, "Parallel driving os: A ubiquitous operating system for autonomous driving in cpss," IEEE Transactions on Intelligent Vehicles, vol. 7, no. 4, pp. 886- 895, 2022.

[3] L. Chen, Y. Zhang, B. Tian, Y. Ai, D. Cao, 和 F.-Y. Wang, “并行驾驶操作系统:面向CPSs的普适自动驾驶操作系统,” IEEE智能车辆汇刊, 第7卷第4期, 页886-895, 2022。

[4] J. Nie, J. Yan, H. Yin, L. Ren, and Q. Meng, "A multimodality fusion deep neural network and safety test strategy for intelligent vehicles," IEEE transactions on intelligent vehicles, vol. 6, no. 2, pp. 310-322, 2020.

[4] J. Nie, J. Yan, H. Yin, L. Ren, 和 Q. Meng, “面向智能车辆的多模态融合深度神经网络及安全测试策略,” IEEE智能车辆汇刊, 第6卷第2期, 页310-322, 2020。

[5] M. Parseh, F. Asplund, L. Svensson, W. Sinz, E. Tomasch, and M. Törngren, "A data-driven method towards minimizing collision severity for highly automated vehicles," IEEE Transactions on Intelligent Vehicles, vol. 6, no. 4, pp. 723-735, 2021.

[5] M. Parseh, F. Asplund, L. Svensson, W. Sinz, E. Tomasch, 和 M. Törngren, “面向高度自动化车辆的碰撞严重性最小化数据驱动方法,” IEEE智能车辆汇刊, 第6卷第4期, 页723-735, 2021。

[6] R. Ke, Z. Cui, Y. Chen, M. Zhu, H. Yang, Y. Zhuang, and Y. Wang, "Lightweight edge intelligence empowered near-crash detection towards real-time vehicle event logging," IEEE Transactions on Intelligent Vehicles, vol. 8, no. 4, pp. 2737-2747, 2023.

[6] R. Ke, Z. Cui, Y. Chen, M. Zhu, H. Yang, Y. Zhuang, 和 Y. Wang, “轻量级边缘智能赋能的近碰撞检测实现实时车辆事件记录,” IEEE智能车辆汇刊, 第8卷第4期, 页2737-2747, 2023。

[7] Y. Zhang, C. Wang, R. Yu, L. Wang, W. Quan, Y. Gao, and P. Li, "The ad4che dataset and its application in typical congestion scenarios of traffic jam pilot systems," IEEE Transactions on Intelligent Vehicles, vol. 8, no. 5, pp. 3312-3323, 2023.

[7] Y. Zhang, C. Wang, R. Yu, L. Wang, W. Quan, Y. Gao, 和 P. Li, “ad4che数据集及其在交通拥堵辅助驾驶系统典型拥堵场景中的应用,” IEEE智能车辆汇刊, 第8卷, 第5期, 页3312-3323, 2023年.

[8] Y. Gao, J. Li, Z. Xu, Z. Liu, X. Zhao, and J. Chen, "A novel image-based convolutional neural network approach for traffic congestion estimation," Expert Systems with Applications, vol. 180, p. 115037, 2021.

[8] Y. Gao, J. Li, Z. Xu, Z. Liu, X. Zhao, 和 J. Chen, “一种基于图像的卷积神经网络用于交通拥堵估计的新方法,” Expert Systems with Applications, 第180卷, 文章115037, 2021年.

[9] M. Singh and R. K. Dubey, "Deep learning model based co2 emissions prediction using vehicle telematics sensors data," IEEE Transactions on Intelligent Vehicles, vol. 8, no. 1, pp. 768-777, 2023.

[9] M. Singh 和 R. K. Dubey, “基于深度学习模型的车辆远程信息处理传感器数据的二氧化碳排放预测,” IEEE智能车辆汇刊, 第8卷, 第1期, 页768-777, 2023年.

[10] W. Hong, I. Chakraborty, H. Wang, and G. Tao, "Co-optimization scheme for the powertrain and exhaust emission control system of hybrid electric vehicles using future speed prediction," IEEE Transactions on Intelligent Vehicles, vol. 6, no. 3, pp. 533-545, 2021.

[10] W. Hong, I. Chakraborty, H. Wang, 和 G. Tao, “利用未来速度预测的混合动力汽车动力系统与尾气排放控制系统的协同优化方案,” IEEE智能车辆汇刊, 第6卷, 第3期, 页533-545, 2021年.

[11] X. Wang, K. Tang, X. Dai, J. Xu, J. Xi, R. Ai, Y. Wang, W. Gu, and C. Sun, "Safety-balanced driving-style aware trajectory planning in intersection scenarios with uncertain environment," IEEE Transactions on Intelligent Vehicles, vol. 8, no. 4, pp. 2888-2898, 2023.

[11] X. Wang, K. Tang, X. Dai, J. Xu, J. Xi, R. Ai, Y. Wang, W. Gu, 和 C. Sun, “考虑安全平衡驾驶风格的交叉口场景不确定环境下轨迹规划,” IEEE智能车辆汇刊, 第8卷, 第4期, 页2888-2898, 2023年.

[12] Q. Lan and Q. Tian, "Instance, scale, and teacher adaptive knowledge distillation for visual detection in autonomous driving," IEEE Transactions on Intelligent Vehicles, pp. 1-14, 2022.

[12] Q. Lan 和 Q. Tian, “面向自动驾驶视觉检测的实例、尺度及教师自适应知识蒸馏,” IEEE智能车辆汇刊, 页1-14, 2022年.

[13] Z. Ding and H. Zhao, "Incorporating driving knowledge in deep learning based vehicle trajectory prediction: A survey," IEEE Transactions on Intelligent Vehicles, vol. 8, no. 8, pp. 3996-4015, 2023.

[13] Z. Ding 和 H. Zhao, “将驾驶知识融入基于深度学习的车辆轨迹预测:综述,” IEEE智能车辆汇刊, 第8卷, 第8期, 页3996-4015, 2023年.

[14] L. Wang, X. Zhang, Z. Song, J. Bi, G. Zhang, H. Wei, L. Tang, L. Yang, J. Li, C. Jia, and L. Zhao, "Multi-modal 3d object detection in autonomous driving: A survey and taxonomy," IEEE Transactions on Intelligent Vehicles, vol. 8, no. 7, pp. 3781-3798, 2023.

[14] L. Wang, X. Zhang, Z. Song, J. Bi, G. Zhang, H. Wei, L. Tang, L. Yang, J. Li, C. Jia, 和 L. Zhao, “自动驾驶中的多模态三维目标检测:综述与分类,” IEEE智能车辆汇刊, 第8卷, 第7期, 页3781-3798, 2023年.

[15] K. Strandberg, N. Nowdehi, and T. Olovsson, "A systematic literature review on automotive digital forensics: Challenges, technical solutions and data collection," IEEE Transactions on Intelligent Vehicles, vol. 8, no. 2, pp. 1350-1367, 2023.

[15] K. Strandberg, N. Nowdehi, 和 T. Olovsson, “汽车数字取证的系统文献综述:挑战、技术解决方案及数据采集,” IEEE智能车辆汇刊, 第8卷, 第2期, 页1350-1367, 2023年.

[16] R. Xu, H. Xiang, X. Han, X. Xia, Z. Meng, C.-J. Chen, C. Correa-Jullian, and J. Ma, "The opencda open-source ecosystem for cooperative driving automation research," IEEE Transactions on Intelligent Vehicles, vol. 8, no. 4, pp. 2698-2711, 2023.

[16] R. Xu, H. Xiang, X. Han, X. Xia, Z. Meng, C.-J. Chen, C. Correa-Jullian, 和 J. Ma, “OpenCDA合作驾驶自动化研究的开源生态系统,” IEEE智能车辆汇刊, 第8卷, 第4期, 页2698-2711, 2023年.

[17] R. Xu, Y. Guo, X. Han, X. Xia, H. Xiang, and J. Ma, "Opencda: an open cooperative driving automation framework integrated with co-simulation," in IEEE International Intelligent Transportation Systems Conference. IEEE, 2021, pp. 1155-1162.

[17] R. Xu, Y. Guo, X. Han, X. Xia, H. Xiang, 和 J. Ma, “OpenCDA:集成协同仿真的开放合作驾驶自动化框架,” IEEE国际智能交通系统会议论文集, IEEE, 2021年, 页1155-1162.

[18] S. Ren, K. He, R. Girshick, and J. Sun, "Faster r-cnn: Towards real-time object detection with region proposal networks," Advances in Neural Information Processing Systems, vol. 28, 2015.

[18] S. Ren, K. He, R. Girshick, 和 J. Sun, “Faster R-CNN:基于区域建议网络的实时目标检测,” 神经信息处理系统进展, 第28卷, 2015年.

[19] K. He, G. Gkioxari, P. Dollár, and R. Girshick, "Mask r-cnn," in Proceedings of the IEEE international conference on computer vision, 2017, pp. 2961-2969.

[19] K. He, G. Gkioxari, P. Dollár, 和 R. Girshick, “Mask R-CNN,” IEEE国际计算机视觉会议论文集, 2017年, 页2961-2969.

[20] A. Bochkovskiy, C.-Y. Wang, and H.-Y. M. Liao, "Yolov4: Optimal speed and accuracy of object detection," arXiv preprint arXiv:2004.10934, 2020.

[20] A. Bochkovskiy, C.-Y. Wang, 和 H.-Y. M. Liao, “YOLOv4:目标检测的速度与精度最优方案,” arXiv预印本 arXiv:2004.10934, 2020年.

[21] M. Cordts, M. Omran, S. Ramos, T. Rehfeld, M. Enzweiler, R. Benenson, U. Franke, S. Roth, and B. Schiele, "The cityscapes dataset for semantic urban scene understanding," in IEEE Conference on Computer Vision and Pattern Recognition, 2016, pp. 3213-3223.

[21] M. Cordts, M. Omran, S. Ramos, T. Rehfeld, M. Enzweiler, R. Benenson, U. Franke, S. Roth, 和 B. Schiele, “用于语义城市场景理解的Cityscapes数据集，”发表于2016年IEEE计算机视觉与模式识别会议，页码3213-3223。

[22] C. Sakaridis, D. Dai, and L. Van Gool, "Semantic foggy scene understanding with synthetic data," International Journal of Computer Vision, vol. 126, no. 9, pp. 973-992, 2018.

[22] C. Sakaridis, D. Dai, 和 L. Van Gool, “基于合成数据的语义雾天场景理解，”国际计算机视觉杂志，卷126，第9期，页码973-992，2018年。

[23] Y. Chen, W. Li, C. Sakaridis, D. Dai, and L. Van Gool, "Domain adaptive faster r-cnn for object detection in the wild," in IEEE Conference on Computer Vision and Pattern Recognition, 2018, pp. 3339-3348.

[23] Y. Chen, W. Li, C. Sakaridis, D. Dai, 和 L. Van Gool, “用于野外目标检测的域自适应Faster R-CNN，”发表于2018年IEEE计算机视觉与模式识别会议，页码3339-3348。

[24] S. Song, H. Yu, Z. Miao, J. Fang, K. Zheng, C. Ma, and S. Wang, "Multi-spectral salient object detection by adversarial domain adaptation," in AAAI Conference on Artificial Intelligence, vol. 34, no. 07, 2020, pp. 12023-12030.

[24] S. Song, H. Yu, Z. Miao, J. Fang, K. Zheng, C. Ma, 和 S. Wang, “通过对抗域适应的多光谱显著目标检测，”发表于2020年AAAI人工智能会议，卷34，第07期，页码12023-12030。

[25] J. Li, Z. Xu, L. Fu, X. Zhou, and H. Yu, "Domain adaptation from daytime to nighttime: A situation-sensitive vehicle detection and traffic flow parameter estimation framework," Transportation Research Part $C$ : Emerging Technologies, 2021.

[25] J. Li, Z. Xu, L. Fu, X. Zhou, 和 H. Yu, “从白天到夜晚的域适应:一种情境敏感的车辆检测与交通流参数估计框架，”交通研究新兴技术部分，2021年。

[26] D. Guan, J. Huang, A. Xiao, S. Lu, and Y. Cao, "Uncertainty-aware unsupervised domain adaptation in object detection," IEEE Transactions on Multimedia, vol. 24, pp. 2502-2514, 2022.

[26] D. Guan, J. Huang, A. Xiao, S. Lu, 和 Y. Cao, “目标检测中的不确定性感知无监督域适应，”IEEE多媒体学报，卷24，页码2502-2514，2022年。

[27] L. Fu, H. Yu, F. Juefei-Xu, J. Li, Q. Guo, and S. Wang, "Let there be light: Improved traffic surveillance via detail preserving night-today transfer," IEEE Transactions on Circuits and Systems for Video Technology, vol. 32, no. 12, pp. 8217-8226, 2022.

[27] L. Fu, H. Yu, F. Juefei-Xu, J. Li, Q. Guo, 和 S. Wang, “让光明降临:通过细节保留的夜间到白天迁移提升交通监控，”IEEE视频技术电路与系统学报，卷32，第12期，页码8217-8226，2022年。

[28] Y. Zheng, D. Huang, S. Liu, and Y. Wang, "Cross-domain object detection through coarse-to-fine feature adaptation," in IEEE Conference on Computer Vision and Pattern Recognition, 2020, pp. 13766-13775.

[28] Y. Zheng, D. Huang, S. Liu, 和 Y. Wang, “通过粗到细特征适应的跨域目标检测，”发表于2020年IEEE计算机视觉与模式识别会议，页码13766-13775。

[29] Z. Hu, S. Lou, Y. Xing, X. Wang, D. Cao, and C. Lv, "Review and perspectives on driver digital twin and its enabling technologies for intelligent vehicles," IEEE Transactions on Intelligent Vehicles, vol. 7, no. 3, pp. 417-440, 2022.

[29] Z. Hu, S. Lou, Y. Xing, X. Wang, D. Cao, 和 C. Lv, “驾驶员数字孪生及其智能车辆赋能技术的综述与展望，”IEEE智能车辆学报，卷7，第3期，页码417-440，2022年。

[30] J. Zhang, J. Pu, J. Xue, M. Yang, X. Xu, X. Wang, and F.-Y. Wang, "Hivegpt: Human-machine-augmented intelligent vehicles with generative pre-trained transformer," IEEE Transactions on Intelligent Vehicles, vol. 8, no. 3, pp. 2027-2033, 2023.

[30] J. Zhang, J. Pu, J. Xue, M. Yang, X. Xu, X. Wang, 和 F.-Y. Wang, “HiveGPT:具备生成式预训练变换器的人机增强智能车辆，”IEEE智能车辆学报，卷8，第3期，页码2027-2033，2023年。

[31] E. Li, S. Wang, C. Li, D. Li, X. Wu, and Q. Hao, "Sustech points: A portable 3d point cloud interactive annotation platform system," in IEEE Intelligent Vehicles Symposium, 2020, pp. 1108-1115.

[31] E. Li, S. Wang, C. Li, D. Li, X. Wu, 和 Q. Hao, “Sustech Points:一款便携式3D点云交互式标注平台系统，”发表于2020年IEEE智能车辆研讨会，页码1108-1115。

[32] R. Xu, F. Tafazzoli, L. Zhang, T. Rehfeld, G. Krehl, and A. Seal, "Holistic grid fusion based stop line estimation," in International Conference on Pattern Recognition. IEEE, 2021, pp. 8400-8407.

[32] R. Xu, F. Tafazzoli, L. Zhang, T. Rehfeld, G. Krehl, 和 A. Seal, “基于整体网格融合的停止线估计，”发表于国际模式识别会议。IEEE，2021年，页码8400-8407。

[33] J. Li, R. Xu, X. Liu, J. Ma, Z. Chi, J. Ma, and H. Yu, "Learning for vehicle-to-vehicle cooperative perception under lossy communication," IEEE Transactions on Intelligent Vehicles, vol. 8, no. 4, pp. 2650-2660, 2023.

[33] J. Li, R. Xu, X. Liu, J. Ma, Z. Chi, J. Ma, 和 H. Yu, “在通信丢包情况下的车对车协同感知学习，”IEEE智能车辆学报，卷8，第4期，页码2650-2660，2023年。

[34] Y. Shan, W. F. Lu, and C. M. Chew, "Pixel and feature level based domain adaptation for object detection in autonomous driving," Neuro-computing, vol. 367, pp. 31-38, 2019.

[34] Y. Shan, W. F. Lu, 和 C. M. Chew, “基于像素和特征层的自动驾驶目标检测域适应，”神经计算，卷367，页码31-38，2019年。

[35] X. Zhao, P. Sun, Z. Xu, H. Min, and H. Yu, "Fusion of 3d lidar and camera data for object detection in autonomous vehicle applications," IEEE Sensors Journal, vol. 20, no. 9, pp. 4901-4913, 2020.

[35] 赵翔, 孙鹏, 徐志, 闵浩, 余辉, “自动驾驶车辆应用中3D激光雷达与摄像头数据融合的目标检测,” IEEE传感器期刊, 第20卷, 第9期, 页4901-4913, 2020年.

[36] J. Redmon, S. Divvala, R. Girshick, and A. Farhadi, "You only look once: Unified, real-time object detection," in IEEE Conference on Computer Vision and Pattern Recognition, 2016, pp. 779-788.

[36] J. Redmon, S. Divvala, R. Girshick, A. Farhadi, “你只看一次:统一的实时目标检测,” 载于IEEE计算机视觉与模式识别会议, 2016年, 页779-788.

[37] W. Liu, D. Anguelov, D. Erhan, C. Szegedy, S. Reed, C.-Y. Fu, and A. C. Berg, "Ssd: Single shot multibox detector," in European Conference on Computer Vision. Springer, 2016, pp. 21-37.

[37] W. Liu, D. Anguelov, D. Erhan, C. Szegedy, S. Reed, C.-Y. Fu, A. C. Berg, “SSD:单次多框检测器,” 载于欧洲计算机视觉会议. Springer, 2016年, 页21-37.

[38] C. Chen, C. Wang, B. Liu, C. He, L. Cong, and S. Wan, "Edge intelligence empowered vehicle detection and image segmentation for autonomous vehicles," IEEE Transactions on Intelligent Transportation Systems, vol. 24, no. 11, pp. 13023-13034, 2023.

[38] 陈超, 王超, 刘斌, 何超, 丛磊, 万松, “边缘智能赋能的自动驾驶车辆检测与图像分割,” IEEE智能交通系统汇刊, 第24卷, 第11期, 页13023-13034, 2023年.

[39] J. E. Hoffmann, H. G. Tosso, M. M. D. Santos, J. F. Justo, A. W. Malik, and A. U. Rahman, "Real-time adaptive object detection and tracking for autonomous vehicles," IEEE Transactions on Intelligent Vehicles, vol. 6, no. 3, pp. 450-459, 2020.

[39] J. E. Hoffmann, H. G. Tosso, M. M. D. Santos, J. F. Justo, A. W. Malik, A. U. Rahman, “自动驾驶车辆的实时自适应目标检测与跟踪,” IEEE智能车辆汇刊, 第6卷, 第3期, 页450-459, 2020年.

[40] L. Chen, S. Lin, X. Lu, D. Cao, H. Wu, C. Guo, C. Liu, and F.-Y. Wang, "Deep neural network based vehicle and pedestrian detection for autonomous driving: A survey," IEEE Transactions on Intelligent Transportation Systems, vol. 22, no. 6, pp. 3234-3246, 2021.

[40] 陈磊, 林松, 陆翔, 曹东, 吴浩, 郭超, 刘超, 王福阳, “基于深度神经网络的自动驾驶车辆与行人检测综述,” IEEE智能交通系统汇刊, 第22卷, 第6期, 页3234-3246, 2021年.

[41] Y. Pang, J. Cao, Y. Li, J. Xie, H. Sun, and J. Gong, "Tju-dhd: A diverse high-resolution dataset for object detection," IEEE Transactions on Image Processing, vol. 30, no. 2, pp. 207-219, 2021.

[41] 庞洋, 曹军, 李阳, 谢军, 孙浩, 龚军, “TJU-DHD:多样化高分辨率目标检测数据集,” IEEE图像处理汇刊, 第30卷, 第2期, 页207-219, 2021年.

[42] S.-C. Huang, T.-H. Le, and D.-W. Jaw, "Dsnet: Joint semantic learning for object detection in inclement weather conditions," IEEE Transactions on Pattern Analysis and Machine Intelligence, vol. 43, no. 8, pp. 2623- 2633, 2020.

[42] 黄世聪, 黎天豪, 赵大伟, “DSNet:恶劣天气条件下的联合语义学习目标检测,” IEEE模式分析与机器智能汇刊, 第43卷, 第8期, 页2623-2633, 2020年.

[43] M. Hahner, C. Sakaridis, D. Dai, and L. Van Gool, "Fog simulation on real lidar point clouds for $3\mathrm{\;d}$ object detection in adverse weather," in IEEE International Conference on Computer Vision, 2021, pp. 15283- 15292.

[43] M. Hahner, C. Sakaridis, D. Dai, L. Van Gool, “基于真实激光雷达点云的雾霾模拟用于恶劣天气下的$3\mathrm{\;d}$目标检测,” 载于IEEE国际计算机视觉会议, 2021年, 页15283-15292.

[44] K. Qian, S. Zhu, X. Zhang, and L. E. Li, "Robust multimodal vehicle detection in foggy weather using complementary lidar and radar signals," in IEEE Conference on Computer Vision and Pattern Recognition, 2021, pp. 444-453.

[44] 钱凯, 朱松, 张翔, 李立恩, “利用互补激光雷达与雷达信号实现雾天鲁棒多模态车辆检测,” 载于IEEE计算机视觉与模式识别会议, 2021年, 页444-453.

[45] M. Bijelic, T. Gruber, F. Mannan, F. Kraus, W. Ritter, K. Dietmayer, and F. Heide, "Seeing through fog without seeing fog: Deep multimodal sensor fusion in unseen adverse weather," in IEEE Conference on Computer Vision and Pattern Recognition, 2020, pp. 11682-11692.

[45] M. Bijelic, T. Gruber, F. Mannan, F. Kraus, W. Ritter, K. Dietmayer, F. Heide, “无视雾霾的视觉:未知恶劣天气下的深度多模态传感器融合,” 载于IEEE计算机视觉与模式识别会议, 2020年, 页11682-11692.

[46] V. A. Sindagi, P. Oza, R. Yasarla, and V. M. Patel, "Prior-based domain adaptive object detection for hazy and rainy conditions," in European Conference on Computer Vision. Springer, 2020, pp. 763-780.

[46] V. A. Sindagi, P. Oza, R. Yasarla, V. M. Patel, “基于先验的雾霾和雨天条件域自适应目标检测,” 载于欧洲计算机视觉会议. Springer, 2020年, 页763-780.

[47] S.-C. Huang, Q.-V. Hoang, and T.-H. Le, "Sfa-net: A selective features absorption network for object detection in rainy weather conditions," IEEE Transactions on Neural Networks and Learning Systems, vol. 34, no. 8, pp. 5122-5132, 2023.

[47] 黄世聪, Q.-V. Hoang, 黎天豪, “SFA-Net:雨天条件下的选择性特征吸收网络用于目标检测,” IEEE神经网络与学习系统汇刊, 第34卷, 第8期, 页5122-5132, 2023年.

[48] M. Hnewa and H. Radha, "Object detection under rainy conditions for autonomous vehicles: A review of state-of-the-art and emerging techniques," IEEE Signal Processing Magazine, vol. 38, no. 1, pp. 53- 67, 2020.

[48] M. Hnewa, H. Radha, “自动驾驶车辆雨天条件下的目标检测:最新技术与新兴方法综述,” IEEE信号处理杂志, 第38卷, 第1期, 页53-67, 2020年.

[49] T. Kim, M. Jeong, S. Kim, S. Choi, and C. Kim, "Diversify and match: A domain adaptive representation learning paradigm for object detection," in IEEE Conference on Computer Vision and Pattern Recognition, 2019, pp. 12456-12465.

[49] T. Kim, M. Jeong, S. Kim, S. Choi, 和 C. Kim, “多样化与匹配:一种用于目标检测的领域自适应表示学习范式,” 载于IEEE计算机视觉与模式识别会议, 2019, 页12456-12465。

[50] K. Saito, Y. Ushiku, T. Harada, and K. Saenko, "Strong-weak distribution alignment for adaptive object detection," in IEEE Conference on Computer Vision and Pattern Recognition, 2019, pp. 6956-6965.

[50] K. Saito, Y. Ushiku, T. Harada, 和 K. Saenko, “强弱分布对齐用于自适应目标检测,” 载于IEEE计算机视觉与模式识别会议, 2019, 页6956-6965。

[51] Z. Zhao, Y. Guo, H. Shen, and J. Ye, "Adaptive object detection with dual multi-label prediction," in European Conference on Computer Vision. Springer, 2020, pp. 54-69.

[51] Z. Zhao, Y. Guo, H. Shen, 和 J. Ye, “基于双重多标签预测的自适应目标检测,” 载于欧洲计算机视觉会议. Springer, 2020, 页54-69。

[52] Q. Xu, Y. Zhou, W. Wang, C. R. Qi, and D. Anguelov, "Spg: Unsupervised domain adaptation for $3\mathrm{\;d}$ object detection via semantic point generation," in IEEE International Conference on Computer Vision, 2021, pp. 15446-15456.

[52] Q. Xu, Y. Zhou, W. Wang, C. R. Qi, 和 D. Anguelov, “SPG:通过语义点生成实现无监督领域自适应目标检测,” 载于IEEE国际计算机视觉会议, 2021, 页15446-15456。

[53] Y. Zhang, Z. Wang, and Y. Mao, "Rpn prototype alignment for domain adaptive object detector," in IEEE Conference on Computer Vision and Pattern Recognition, 2021, pp. 12425-12434.

[53] Y. Zhang, Z. Wang, 和 Y. Mao, “用于领域自适应目标检测器的RPN原型对齐,” 载于IEEE计算机视觉与模式识别会议, 2021, 页12425-12434。

[54] M. Xu, H. Wang, B. Ni, Q. Tian, and W. Zhang, "Cross-domain detection via graph-induced prototype alignment," in IEEE Conference on Computer Vision and Pattern Recognition, 2020, pp. 12355-12364.

[54] M. Xu, H. Wang, B. Ni, Q. Tian, 和 W. Zhang, “通过图诱导的原型对齐实现跨域检测,” 载于IEEE计算机视觉与模式识别会议, 2020, 页12355-12364。

[55] Z. He and L. Zhang, "Multi-adversarial faster-rcnn for unrestricted object detection," in IEEE International Conference on Computer Vision, 2019, pp. 6668-6677.

[55] Z. He 和 L. Zhang, “多对抗Faster-RCNN用于无限制目标检测,” 载于IEEE国际计算机视觉会议, 2019, 页6668-6677。

[56] H.-K. Hsu, C.-H. Yao, Y.-H. Tsai, W.-C. Hung, H.-Y. Tseng, M. Singh, and M.-H. Yang, "Progressive domain adaptation for object detection," in IEEE Winter Conference on Applications of Computer Vision, 2020, pp. 749-757.

[56] H.-K. Hsu, C.-H. Yao, Y.-H. Tsai, W.-C. Hung, H.-Y. Tseng, M. Singh, 和 M.-H. Yang, “渐进式领域自适应用于目标检测,” 载于IEEE冬季计算机视觉应用会议, 2020, 页749-757。

[57] M. Schutera, M. Hussein, J. Abhau, R. Mikut, and M. Reischl, "Night-to-day: Online image-to-image translation for object detection within autonomous driving by night," IEEE Transactions on Intelligent Vehicles, vol. 6, no. 3, pp. 480-489, 2020.

[57] M. Schutera, M. Hussein, J. Abhau, R. Mikut, 和 M. Reischl, “夜间到白天:用于夜间自动驾驶中目标检测的在线图像到图像转换,” IEEE智能车辆汇刊, 第6卷第3期, 页480-489, 2020。

[58] W. Zhou, D. Du, L. Zhang, T. Luo, and Y. Wu, "Multi-granularity alignment domain adaptation for object detection," in Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition, 2022, pp. 9581-9590.

[58] W. Zhou, D. Du, L. Zhang, T. Luo, 和 Y. Wu, “多粒度对齐领域自适应用于目标检测,” 载于IEEE/CVF计算机视觉与模式识别会议论文集, 2022, 页9581-9590。

[59] W. Li, X. Liu, and Y. Yuan, "Sigma: Semantic-complete graph matching for domain adaptive object detection," in IEEE Conference on Computer Vision and Pattern Recognition, 2022, pp. 5291-5300.

[59] W. Li, X. Liu, 和 Y. Yuan, “SIGMA:用于领域自适应目标检测的语义完整图匹配,” 载于IEEE计算机视觉与模式识别会议, 2022, 页5291-5300。

[60] M. Chen, W. Chen, S. Yang, J. Song, X. Wang, L. Zhang, Y. Yan, D. Qi, Y. Zhuang, D. Xie et al., "Learning domain adaptive object detection with probabilistic teacher," in International Conference on Machine Learning. PMLR, 2022, pp. 3040-3055.

[60] M. Chen, W. Chen, S. Yang, J. Song, X. Wang, L. Zhang, Y. Yan, D. Qi, Y. Zhuang, D. Xie 等, “基于概率教师的领域自适应目标检测学习,” 载于国际机器学习会议. PMLR, 2022, 页3040-3055。

[61] J. Wang, T. Shen, Y. Tian, Y. Wang, C. Gou, X. Wang, F. Yao, and C. Sun, "A parallel teacher for synthetic-to-real domain adaptation of traffic object detection," IEEE Transactions on Intelligent Vehicles, vol. 7, no. 3, pp. 441-455, 2022.

[61] J. Wang, T. Shen, Y. Tian, Y. Wang, C. Gou, X. Wang, F. Yao, 和 C. Sun, “用于合成到真实领域自适应的交通目标检测的并行教师,” IEEE智能车辆汇刊, 第7卷第3期, 页441-455, 2022。

[62] L. Hoyer, D. Dai, H. Wang, and L. Van Gool, "Mic: Masked image consistency for context-enhanced domain adaptation," in Proceedings of the IEEE/CVF conference on computer vision and pattern recognition, 2023, pp. 11721-11732.

[62] L. Hoyer, D. Dai, H. Wang, 和 L. Van Gool, “MIC:用于上下文增强领域自适应的掩码图像一致性,” 载于IEEE/CVF计算机视觉与模式识别会议论文集, 2023, 页11721-11732。

[63] L. Hoyer, M. Munoz, P. Katiyar, A. Khoreva, and V. Fischer, "Grid saliency for context explanations of semantic segmentation," Advances in neural information processing systems, vol. 32, 2019.

[63] L. Hoyer, M. Munoz, P. Katiyar, A. Khoreva, 和 V. Fischer, “用于语义分割上下文解释的网格显著性,” 神经信息处理系统进展, 第32卷, 2019。

[64] Z. Xie, Z. Zhang, Y. Cao, Y. Lin, J. Bao, Z. Yao, Q. Dai, and H. Hu, "Simmim: A simple framework for masked image modeling," in Proceedings of the IEEE/CVF conference on computer vision and pattern recognition, 2022, pp. 9653-9663.

[64] 谢志, 张志, 曹勇, 林勇, 鲍军, 姚志, 戴强, 胡浩, "Simmim: 一种简单的掩码图像建模框架," 载于IEEE/CVF计算机视觉与模式识别会议论文集, 2022, 页9653-9663.

[65] N. Srivastava, G. Hinton, A. Krizhevsky, I. Sutskever, and R. Salakhut-dinov, "Dropout: a simple way to prevent neural networks from over-fitting," The journal of machine learning research, vol. 15, no. 1, pp. 1929-1958, 2014.

[65] N. Srivastava, G. Hinton, A. Krizhevsky, I. Sutskever, 和 R. Salakhut-dinov, "Dropout: 一种防止神经网络过拟合的简单方法," 机器学习研究杂志, 第15卷, 第1期, 页1929-1958, 2014.

[66] Y. Ganin and V. Lempitsky, "Unsupervised domain adaptation by backpropagation," in International Conference on Machine Learning. PMLR, 2015, pp. 1180-1189.

[66] Y. Ganin 和 V. Lempitsky, "通过反向传播实现无监督领域自适应," 载于国际机器学习大会论文集. PMLR, 2015, 页1180-1189.

[67] Q. Guo, J. Sun, F. Juefei-Xu, L. Ma, X. Xie, W. Feng, Y. Liu, and J. Zhao, "Efficientderain: Learning pixel-wise dilation filtering for high-efficiency single-image deraining," in AAAI Conference on Artificial Intelligence, vol. 35, no. 2, 2021, pp. 1487-1495.

[67] Q. Guo, J. Sun, F. Juefei-Xu, L. Ma, X. Xie, W. Feng, Y. Liu, 和 J. Zhao, "Efficientderain: 学习像素级膨胀滤波以实现高效单幅图像去雨," 载于AAAI人工智能会议, 第35卷, 第2期, 2021, 页1487-1495.

[68] D. Hendrycks, N. Mu, E. D. Cubuk, B. Zoph, J. Gilmer, and B. Lak-shminarayanan, "AugMix: A simple data processing method to improve robustness and uncertainty," International Conference on Learning Representations, 2020.

[68] D. Hendrycks, N. Mu, E. D. Cubuk, B. Zoph, J. Gilmer, 和 B. Lakshminarayanan, "AugMix: 一种简单的数据处理方法以提升鲁棒性和不确定性," 国际学习表征会议, 2020.

[69] K. Garg and S. K. Nayar, "Photorealistic rendering of rain streaks," ACM Transactions on Graphics, vol. 25, no. 3, pp. 996-1002, 2006.

[69] K. Garg 和 S. K. Nayar, "雨线的真实感渲染," ACM图形学汇刊, 第25卷, 第3期, 页996-1002, 2006.

[70] Q. Cai, Y. Pan, C.-W. Ngo, X. Tian, L. Duan, and T. Yao, "Exploring object relation in mean teacher for cross-domain detection," in IEEE Conference on Computer Vision and Pattern Recognition, 2019, pp. 11457-11466.

[70] Q. Cai, Y. Pan, C.-W. Ngo, X. Tian, L. Duan, 和 T. Yao, "在均值教师(mean teacher)中探索跨域检测的对象关系," 载于IEEE计算机视觉与模式识别会议, 2019, 页11457-11466.

[71] C. Chen, Z. Zheng, X. Ding, Y. Huang, and Q. Dou, "Harmonizing transferability and discriminability for adapting object detectors," in IEEE Conference on Computer Vision and Pattern Recognition, 2020, pp. 8869-8878.

[71] C. Chen, Z. Zheng, X. Ding, Y. Huang, 和 Q. Dou, "协调可迁移性与判别性以适应目标检测器," 载于IEEE计算机视觉与模式识别会议, 2020, 页8869-8878.

[72] C. Li, D. Du, L. Zhang, L. Wen, T. Luo, Y. Wu, and P. Zhu, "Spatial attention pyramid network for unsupervised domain adaptation," in European Conference on Computer Vision. Springer, 2020, pp. 481- 497.

[72] C. Li, D. Du, L. Zhang, L. Wen, T. Luo, Y. Wu, 和 P. Zhu, "用于无监督领域自适应的空间注意力金字塔网络," 载于欧洲计算机视觉会议. Springer, 2020, 页481-497.

[73] V. Vibashan, V. Gupta, P. Oza, V. A. Sindagi, and V. M. Patel, "Mega-cda: Memory guided attention for category-aware unsupervised domain adaptive object detection," in IEEE Conference on Computer Vision and Pattern Recognition (CVPR). IEEE, 2021, pp. 4514-4524.

[73] V. Vibashan, V. Gupta, P. Oza, V. A. Sindagi, 和 V. M. Patel, "Mega-cda: 基于记忆引导注意力的类别感知无监督领域自适应目标检测," 载于IEEE计算机视觉与模式识别会议(CVPR). IEEE, 2021, 页4514-4524.

[74] J. Deng, W. Li, Y. Chen, and L. Duan, "Unbiased mean teacher for cross-domain object detection," in IEEE Conference on Computer Vision and Pattern Recognition, 2021, pp. 4091-4101.

[74] J. Deng, W. Li, Y. Chen, 和 L. Duan, "无偏均值教师用于跨域目标检测," 载于IEEE计算机视觉与模式识别会议, 2021, 页4091-4101.

[75] W. Li, X. Liu, X. Yao, and Y. Yuan, "Scan: Cross domain object detection with semantic conditioned adaptation," in AAAI Conference on Artificial Intelligence, vol. 36, no. 2, 2022, pp. 1421-1428.

[75] W. Li, X. Liu, X. Yao, 和 Y. Yuan, "Scan: 语义条件适应的跨域目标检测," 载于AAAI人工智能会议, 第36卷, 第2期, 2022, 页1421-1428.

[76] W. Zhang, J. Wang, Y. Wang, and F.-Y. Wang, "Parauda: Invariant feature learning with auxiliary synthetic samples for unsupervised domain adaptation," IEEE Transactions on Intelligent Transportation Systems, vol. 23, no. 11, pp. 20217-20229, 2022.

[76] W. Zhang, J. Wang, Y. Wang, 和 F.-Y. Wang, "Parauda: 利用辅助合成样本进行不变特征学习的无监督领域自适应," IEEE智能交通系统汇刊, 第23卷, 第11期, 页20217-20229, 2022.

[77] G. Mattolin, L. Zanella, E. Ricci, and Y. Wang, "Confmix: Unsupervised domain adaptation for object detection via confidence-based mixing," in IEEE Winter Conference on Applications of Computer Vision, 2023, pp. 423-433.

[77] G. Mattolin, L. Zanella, E. Ricci, 和 Y. Wang, "Confmix: 通过基于置信度的混合实现目标检测的无监督领域自适应," 载于IEEE冬季计算机视觉应用会议, 2023, 页423-433.

[78] G. Li, Z. Ji, X. Qu, R. Zhou, and D. Cao, "Cross-domain object detection for autonomous driving: A stepwise domain adaptative yolo approach," IEEE Transactions on Intelligent Vehicles, vol. 7, no. 3, pp. 603-615, 2022.

[78] G. Li, Z. Ji, X. Qu, R. Zhou, 和 D. Cao, “自动驾驶的跨域目标检测:一种分步域自适应YOLO方法，”《IEEE智能车辆汇刊》，第7卷，第3期，页603-615，2022年。

[79] M. Hnewa and H. Radha, "Integrated multiscale domain adaptive yolo," IEEE Transactions on Image Processing, vol. 32, no. 2, pp. 1857-1867, 2023.

[79] M. Hnewa 和 H. Radha, “集成多尺度域自适应YOLO，”《IEEE图像处理汇刊》，第32卷，第2期，页1857-1867，2023年。

[80] L. Van der Maaten and G. Hinton, "Visualizing data using t-sne." Journal of machine learning research, vol. 9, no. 11, 2008.

[80] L. Van der Maaten 和 G. Hinton, “使用t-SNE(分布式随机邻域嵌入)进行数据可视化，”《机器学习研究杂志》，第9卷，第11期，2008年。

[81] Z. He and L. Zhang, "Domain adaptive object detection via asymmetric tri-way faster-rcnn," in European conference on computer vision. Springer, 2020, pp. 309-324.

[81] Z. He 和 L. Zhang, “通过非对称三路Faster-RCNN实现域自适应目标检测，”载于欧洲计算机视觉会议，施普林格，2020年，页309-324。

[82] C. Zhang, Z. Li, J. Liu, P. Peng, Q. Ye, S. Lu, T. Huang, and Y. Tian, "Self-guided adaptation: Progressive representation alignment for domain adaptive object detection," IEEE Transactions on Multimedia, vol. 24, pp. 2246-2258, 2021.

[82] C. Zhang, Z. Li, J. Liu, P. Peng, Q. Ye, S. Lu, T. Huang, 和 Y. Tian, “自引导适应:用于域自适应目标检测的渐进式表示对齐，”《IEEE多媒体汇刊》，第24卷，页2246-2258，2021年。

[83] V. F. Arruda, R. F. Berriel, T. M. Paixão, C. Badue, A. F. De Souza, N. Sebe, and T. Oliveira-Santos, "Cross-domain object detection using unsupervised image translation," Expert Systems with Applications, vol. 192, p. 116334, 2022.

[83] V. F. Arruda, R. F. Berriel, T. M. Paixão, C. Badue, A. F. De Souza, N. Sebe, 和 T. Oliveira-Santos, “利用无监督图像转换进行跨域目标检测，”《专家系统应用》，第192卷，文章116334，2022年。

[84] Q. Lang, L. Zhang, W. Shi, W. Chen, and S. Pu, "Exploring implicit domain-invariant features for domain adaptive object detection," IEEE Transactions on Circuits and Systems for Video Technology, 2023.

[84] Q. Lang, L. Zhang, W. Shi, W. Chen, 和 S. Pu, “探索隐式域不变特征以实现域自适应目标检测，”《IEEE视频技术电路与系统汇刊》，2023年。

[85] J.-Y. Zhu, T. Park, P. Isola, and A. A. Efros, "Unpaired image-to-image translation using cycle-consistent adversarial networks," in IEEE International Conference on Computer Vision, 2017, pp. 2223-2232.

[85] J.-Y. Zhu, T. Park, P. Isola, 和 A. A. Efros, “使用循环一致性对抗网络进行无配对图像到图像的转换，”载于IEEE国际计算机视觉会议，2017年，页2223-2232。