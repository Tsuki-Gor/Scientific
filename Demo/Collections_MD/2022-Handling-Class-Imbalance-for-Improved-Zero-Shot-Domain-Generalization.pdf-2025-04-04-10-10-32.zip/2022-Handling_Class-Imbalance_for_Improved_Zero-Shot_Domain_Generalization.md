# Handling Class-Imbalance for Improved Zero-Shot Domain Generalization

# 处理类别不平衡问题以改进零样本领域泛化

Ahmad Arfeen

艾哈迈德·阿尔芬

ahmadarfeen@iisc.ac.in

Titir Dutta

蒂蒂尔·杜塔

titird@iisc.ac.in

Soma Biswas

索玛·比斯瓦斯

Indian Institute of Science

印度科学研究所

Bangalore, India

印度班加罗尔

somabiswas@iisc.ac.in

## Abstract

## 摘要

Zero-shot domain generalization (ZSDG) simultaneously addresses the challenges of dissimilar distribution and disjoint label-spaces of the training and test data in the context of classification. State-of-the-art ZSDG approaches leverage multiple source domain data and the semantic information of the classes to learn domain-agnostic features for handling both unseen domains and classes. Effective feature learning depends significantly on the training data characteristics, which has been largely overlooked for this task. In this work, we propose to handle one such important challenge, namely class-imbalance for the ZSDG problem. Towards this end, we propose a novel framework, Mixing-based Adaptive Margin Classifier Network (MAMC-Net) for handling this real-world challenge. Specifically, it consists of two components, (i) a novel adaptive-margin based semantic classifier for handling the data imbalance in the training data and (ii) a module for determining the mixing ratio when the input domains and classes are mixed, for better domain agnostic class-discrimination. Extensive experiments and analysis performed on multiple large-scale datasets, DomainNet and DomainNet-LS demonstrate the effectiveness of MAMC-Net to address the challenging ZSDG scenario.

零样本领域泛化(Zero-shot domain generalization，ZSDG)在分类任务中同时应对训练数据和测试数据分布不同以及标签空间不相交的挑战。目前最先进的ZSDG方法利用多个源领域数据和类别的语义信息来学习与领域无关的特征，以处理未见领域和类别。有效的特征学习在很大程度上取决于训练数据的特征，而这一点在该任务中很大程度上被忽视了。在这项工作中，我们提出处理ZSDG问题中的一个重要挑战，即类别不平衡问题。为此，我们提出了一个新颖的框架，即基于混合的自适应边界分类器网络(Mixing-based Adaptive Margin Classifier Network，MAMC-Net)来应对这一现实挑战。具体来说，它由两个组件组成:(i)一个新颖的基于自适应边界的语义分类器，用于处理训练数据中的数据不平衡问题；(ii)一个模块，用于在输入领域和类别混合时确定混合比例，以实现更好的与领域无关的类别区分。在多个大规模数据集DomainNet和DomainNet-LS上进行的广泛实验和分析证明了MAMC-Net在应对具有挑战性的ZSDG场景方面的有效性。

## 1 Introduction

## 1 引言

Recent advances in deep learning have brought significant improvements in several computer vision tasks, eg. image classification [14], segmentation [32] etc., but with the underlying assumptions that the test data always belong to the same distribution as the training data, and they share the same label-space. However, in real-life, the test data may belong to any category or domain, and this information is not known a-priori. Research in the directions of domain generalization (DG) [129] [23] and zero-shot learning (ZSL) [66][40] address these restrictions individually. DG explores the challenging scenario of classifying data from a completely unknown target domain [22] [20] (but identical label-space), by learning a domain-invariant representation, using data collected across multiple source domains. On the other hand, ZSL-algorithms can classify objects from unseen classes (but identical data-distribution), by addressing the knowledge-gap of the seen and unseen categories using their corresponding semantic properties. Motivated by real-world challenges, recently, researchers have started to address zero-shot domain generalization (ZSDG) [23][8], where the test data can belong to an unseen class as well as unseen domain.

深度学习的最新进展在多个计算机视觉任务中带来了显著的改进，例如图像分类 [14]、分割 [32] 等，但这些进展基于以下潜在假设:测试数据始终与训练数据属于相同的分布，并且它们共享相同的标签空间。然而，在现实生活中，测试数据可能属于任何类别或领域，并且这些信息事先是未知的。领域泛化(Domain generalization，DG) [129] [23] 和零样本学习(Zero-shot learning，ZSL) [66][40] 方向的研究分别解决了这些限制。DG通过使用从多个源领域收集的数据学习领域不变的表示，探索对来自完全未知目标领域(但标签空间相同)的数据进行分类的具有挑战性的场景 [22] [20]。另一方面，ZSL算法可以通过利用相应的语义属性解决已见和未见类别的知识差距，对来自未见类别的对象(但数据分布相同)进行分类。受现实世界挑战的启发，最近，研究人员开始解决零样本领域泛化(ZSDG) [23][8] 问题，其中测试数据可能属于未见类别以及未见领域。

---

(C) 2021. The copyright of this document resides with its authors.

(C) 2021。本文档的版权归其作者所有。

It may be distributed unchanged freely in print or electronic forms.

它可以以印刷或电子形式自由原样分发。

---

ZSDG leverages samples across multiple domains (as in DG) to train the model, and quite often this results in severely imbalanced training data. For example, RGB-images may be easier to collect as compared to drawing Sketches. Even within a single domain, it might be much easier to collect data from few classes compared to the others. Thus the training data can have domain as well as class imbalance. The class-imbalance problem has been widely addressed in the context of several applications like image classification [14], object detection [44], etc.

ZSDG利用多个领域的样本(如DG中那样)来训练模型，这通常会导致训练数据严重不平衡。例如，与绘制草图相比，RGB图像可能更容易收集。即使在单个领域内，收集某些类别的数据也可能比其他类别容易得多。因此，训练数据可能存在领域和类别不平衡的问题。类别不平衡问题在图像分类 [14]、目标检测 [44] 等多个应用场景中已得到广泛研究。

In this work, we address the challenges posed by class-imbalanced training data for the ZSDG task. Towards that goal, we propose a novel framework consisting of a semantic classifier with an adaptive margin to account for the variable number of training data of the different classes. We integrate it with an inter-domain and inter-class mixing network with mixing-ratio prediction ability to ensure that the feature representation is domain-agnostic. We refer to this proposed framework as Mixing-based Adaptive Margin Classifier Network (MAMC-Net). Thus the contributions of this work are summarized as follows: (i) We address the real-world problem of class-imbalance for the challenging ZSDG setting, which to the best of our knowledge is the first in literature; (ii) We propose the MAMC-Net framework, where a novel class-specific adaptive margin is learnt to address the imbalance issue; (iii) In addition, we also learn to predict the ratio of a mixed input, which helps in extracting better domain-agnostic features to further boost the performance; (iv) The proposed framework outperforms all the existing approaches and obtains state-of-the-art results on the two large-scale benchmark datasets, DomainNet [BI] and DomainNet-LS [CI].

在这项工作中，我们解决了ZSDG任务中由类别不平衡的训练数据带来的挑战。为了实现这一目标，我们提出了一个新颖的框架，该框架包含一个具有自适应边界的语义分类器，以考虑不同类别的训练数据数量的变化。我们将其与一个具有混合比例预测能力的领域间和类别间混合网络集成，以确保特征表示与领域无关。我们将这个提出的框架称为基于混合的自适应边界分类器网络(MAMC-Net)。因此，这项工作的贡献总结如下:(i)我们解决了具有挑战性的ZSDG场景下的现实世界类别不平衡问题，据我们所知，这在文献中尚属首次；(ii)我们提出了MAMC-Net框架，其中学习了一种新颖的特定类别的自适应边界来解决不平衡问题；(iii)此外，我们还学习预测混合输入的比例，这有助于提取更好的与领域无关的特征，从而进一步提高性能；(iv)所提出的框架优于所有现有方法，并在两个大规模基准数据集DomainNet [BI] 和DomainNet-LS [CI] 上取得了最先进的结果。

## 2 Related Work

## 2 相关工作

Here, we discuss relevant work in the literature for DG, ZSL, ZSDG and data imbalance. Domain Generalization (DG): Domain generalization aims to achieve domain invariant feature representations of the data, by training the model on data from multiple domains. In [42], a conditional invariant deep network is trained with adversarial training to obtain the same. The work in [23] extends the adversarial learning process using auto-encoders with Maximum Mean Discrepancy (MMD) loss. A meta-learning based approach is proposed in [13] and a combination of extrinsic and intrinsic supervisions is proposed in [138]. More recently, $\left\lbrack  \sigma \right\rbrack$ proposed to learn a domain-representation while adapting to the target domain, and [BZ] introduces domain-specific batch-normalization to address DG. In [L], a self-supervised approach for learning the input features by solving a jigsaw puzzle created using random patches on the input image is used. [26] proposed to learn the multiple latent-domains in the training data using unsupervised clustering on style-features and cross-entropy based loss on category-features. A modified DG-protocol with single-domain training data using adversarial domain-augmentation is explored in [83].

在此，我们讨论文献中关于领域泛化(Domain Generalization，DG)、零样本学习(Zero-Shot Learning，ZSL)、零样本领域泛化(Zero Shot Domain Generalization，ZSDG)和数据不平衡的相关工作。领域泛化(DG):领域泛化旨在通过在来自多个领域的数据上训练模型，实现数据的领域不变特征表示。在文献[42]中，通过对抗训练来训练条件不变深度网络以实现这一目标。文献[23]使用带有最大均值差异(Maximum Mean Discrepancy，MMD)损失的自动编码器扩展了对抗学习过程。文献[13]提出了一种基于元学习的方法，文献[138]提出了外在监督和内在监督相结合的方法。最近，$\left\lbrack  \sigma \right\rbrack$提出在适应目标领域的同时学习领域表示，[BZ]引入了特定领域的批量归一化来解决领域泛化问题。在文献[L]中，使用了一种通过解决由输入图像上的随机补丁创建的拼图游戏来学习输入特征的自监督方法。文献[26]提出使用基于风格特征的无监督聚类和基于类别特征的交叉熵损失来学习训练数据中的多个潜在领域。文献[83]探索了一种使用对抗性领域增强的单领域训练数据的改进领域泛化协议。

Zero-Shot Learning (ZSL): ZSL algorithms usually leverage the class attributes or semantic information to bridge the gap between the seen and unseen classes. Such information can be in the form of text [E4], attributes [E6], knowledge graph (KG) and ontology rules [E4] Several ZSL approaches [43][12] learn a mapping function from the image space to the semantic space and then utilize nearest neighbour search to match the query image to one of the class semantics. Recently, generative models have been proposed to generate synthetic samples of the novel classes (not present in the training) using their respective semantic vectors [63][9], which are finally used to train the classification model. Using graph knowledge as the semantic representation is another effective approach for ZSL, as presented in [B9].

零样本学习(ZSL):零样本学习算法通常利用类别属性或语义信息来弥合已见类别和未见类别之间的差距。此类信息可以是文本[E4]、属性[E6]、知识图谱(Knowledge Graph，KG)和本体规则[E4]的形式。几种零样本学习方法[43][12]学习从图像空间到语义空间的映射函数，然后利用最近邻搜索将查询图像与某个类别语义进行匹配。最近，有人提出使用生成模型，利用未见类别的语义向量生成这些类别的合成样本(训练数据中不存在)[63][9]，最终用于训练分类模型。如文献[B9]所示，使用图知识作为语义表示是零样本学习的另一种有效方法。

Zero Shot Domain Generalization (ZSDG): Recently ZSDG has become an active research area, and few algorithms [22] [8] have been proposed which report impressive results for this task. In [23], an effective mixing strategy is proposed to generate new synthesized data of unseen categories and unseen domains through inter-class and inter-domain mixing. The state-of-the-art ZSDG approach [6] learns domain independent structure latent embed-dings by projecting both the image and the semantic representations to a common latent space. Usually, Word2vec [8]-embeddings have been utilized in these works.

零样本领域泛化(ZSDG):最近，零样本领域泛化已成为一个活跃的研究领域，并且已经提出了一些算法[22][8]，这些算法在该任务上取得了令人印象深刻的结果。在文献[23]中，提出了一种有效的混合策略，通过类间和领域间混合生成未见类别和未见领域的新合成数据。目前最先进的零样本领域泛化方法[6]通过将图像和语义表示投影到一个共同的潜在空间来学习领域无关的结构潜在嵌入。通常，这些工作中使用了Word2vec [8]嵌入。

Class Imbalance: This is a well-studied problem in the context of classification [12], object detection [42], etc. One straight-forward approach is to perform over-sampling of minority classes [13][2], but this is usually not very effective [23]. Most of the state-of-the-art approaches address the class imbalance problem by modifying the classifier. Towards this end, [12] learns the classifier to maximally spread out in the embedding space. In [B], the classifiers are learnt to obtain broader margin for minority classes compared to the others.

类别不平衡:这是分类[12]、目标检测[42]等领域中一个经过深入研究的问题。一种直接的方法是对少数类别进行过采样[13][2]，但这通常不是很有效[23]。大多数最先进的方法通过修改分类器来解决类别不平衡问题。为此，文献[12]学习使分类器在嵌入空间中尽可能分散。在文献[B]中，学习分类器以使少数类别相对于其他类别获得更宽的边界。

## 3 Problem Definition and Motivation

## 3 问题定义与动机

First, we introduce the different notations used and also discuss the motivation for this work. We denote the training data as ${\mathcal{D}}_{tr} = {\left\{  \left( {x}_{i},{y}_{i},{d}_{i}\right) \right\}  }_{i = 1}^{n}$ , containing $n$ -number of samples. Here, ${x}_{i}$ represents the ${i}^{th}$ sample, from class ${y}_{i}$ and domain ${d}_{i}$ . The corresponding seen-label space and the set of training-domains are represented as ${\mathcal{Y}}_{tr} = \left\{  {{y}_{1},\ldots ,{y}_{i},\ldots }\right\}$ , and ${\mathcal{S}}_{tr} = \left\{  {{d}_{1},\ldots ,{d}_{i},\ldots }\right\}$ , respectively. The goal of ZSDG [22][8] is to classify the test samples from ${\mathcal{D}}_{te} = \left\{  {x}_{te}\right\}$ , where the test label-space ${\mathcal{Y}}_{te}$ and domain-set ${\mathcal{S}}_{te}$ corresponding to ${\mathcal{D}}_{te}$ are strictly non-overlapping with the training sets, ie.: ${\mathcal{Y}}_{tr} \cap  {\mathcal{Y}}_{te} = \phi$ and ${\mathcal{S}}_{tr} \cap  {\mathcal{S}}_{te} = \phi$ . Motivation: It is well known that training data characteristics like data imbalance adversely affects the final performance for several tasks like image classification, object detection, etc. and addressing them can significantly boost the results. But these factors have been largely overlooked in tasks like ZSDG. Analyzing the large-scale benchmark dataset for DG and ZSDG, namely DomainNet [B1], we observe from Figure 1 (a, b), that significant class imbalance exists across multiple domains, which justifies the effort to address the class-imbalance problem for the ZSDG task. In Figure 1 (c), we observe from the t-SNE plot that the samples from the 5-majority (spreadsheet, table, tree, whale and bird) and 5-minority (dresser, calender, ceiling-fan, saw and line) classes cluster in the feature-space, justifying the effectiveness of the proposed MAMC-Net. Next, we discuss the proposed framework.

首先，我们介绍所使用的不同符号，并讨论开展这项工作的动机。我们将训练数据表示为${\mathcal{D}}_{tr} = {\left\{  \left( {x}_{i},{y}_{i},{d}_{i}\right) \right\}  }_{i = 1}^{n}$，其中包含$n$个样本。这里，${x}_{i}$表示来自类别${y}_{i}$和领域${d}_{i}$的第${i}^{th}$个样本。相应的已见标签空间和训练领域集分别表示为${\mathcal{Y}}_{tr} = \left\{  {{y}_{1},\ldots ,{y}_{i},\ldots }\right\}$和${\mathcal{S}}_{tr} = \left\{  {{d}_{1},\ldots ,{d}_{i},\ldots }\right\}$。零样本领域泛化(ZSDG)[22][8]的目标是对来自${\mathcal{D}}_{te} = \left\{  {x}_{te}\right\}$的测试样本进行分类，其中与${\mathcal{D}}_{te}$对应的测试标签空间${\mathcal{Y}}_{te}$和领域集${\mathcal{S}}_{te}$与训练集严格不重叠，即:${\mathcal{Y}}_{tr} \cap  {\mathcal{Y}}_{te} = \phi$和${\mathcal{S}}_{tr} \cap  {\mathcal{S}}_{te} = \phi$。动机:众所周知，像数据不平衡这样的训练数据特征会对图像分类、目标检测等多个任务的最终性能产生不利影响，解决这些问题可以显著提高结果。但在零样本领域泛化(ZSDG)等任务中，这些因素在很大程度上被忽视了。通过分析用于领域泛化(DG)和零样本领域泛化(ZSDG)的大规模基准数据集，即DomainNet [B1]，我们从图1(a，b)中观察到，多个领域存在显著的类别不平衡，这证明了为零样本领域泛化(ZSDG)任务解决类别不平衡问题的努力是合理的。在图1(c)中，我们从t - SNE图中观察到，5个多数类(电子表格、表格、树、鲸鱼和鸟)和5个少数类(梳妆台、日历、吊扇、锯子和线)的样本在特征空间中聚类，这证明了所提出的多自适应边际分类器网络(MAMC - Net)的有效性。接下来，我们讨论所提出的框架。

## 4 Mixing-based Adaptive Margin Classifier Network

## 4 基于混合的自适应边际分类器网络

The proposed MAMC-Net constitutes two main modules, namely (i) Domain-Agnostic Representation Module and (ii) Class-Imbalance Handling Module, on top of a base model. The base model can potentially be any semantic-classifier based existing ZSDG network. We demonstrate that the integration of the two proposed modules with one such base model enhances its performance, by addressing the class-imbalance in the training set. Here, we

所提出的多自适应边际分类器网络(MAMC - Net)在一个基础模型之上由两个主要模块组成，即(i)领域无关表示模块和(ii)类别不平衡处理模块。基础模型可能是任何基于语义分类器的现有零样本领域泛化(ZSDG)网络。我们证明，将这两个提出的模块与这样一个基础模型集成，通过解决训练集中的类别不平衡问题，可以提高其性能。这里，我们

![0195d70b-6ff8-7313-8361-b027e4c2e1e8_3_52_110_1388_511_0.jpg](images/0195d70b-6ff8-7313-8361-b027e4c2e1e8_3_52_110_1388_511_0.jpg)

Figure 1: Severe class imbalance is observed from the data distribution of (a) Infograph domain; (b) all the source domains combined for DomainNet dataset. (c) t-SNE plot of the MAMC-Net feature space for 5 majority and 5 minority training classes.

图1:从(a)信息图领域的数据分布；(b)DomainNet数据集中所有源领域的组合数据分布中观察到严重的类别不平衡。(c)多自适应边际分类器网络(MAMC - Net)特征空间中5个多数训练类和5个少数训练类的t - SNE图。

## consider CuMix [CZ] to be the base model, which we briefly describe below.

## 考虑将CuMix [CZ]作为基础模型，下面我们简要描述一下。

Base Model: Our base network, CuMix [22], is an inter-domain and intra-domain mixing based network, and the first to address ZSDG. It consists of a mixing module $\mathcal{M}$ , a feature-extractor $\mathcal{F}$ and a classifier $\mathcal{C}$ . The mixing in this network is performed on a triplet set $\mathcal{T} = \left\{  {{x}_{i},{x}_{j},{x}_{k}}\right\}$ , such that the sample-pair $\left\{  {{x}_{i},{x}_{j}}\right\}$ are from different domains (inter-domain samples), and $\left\{  {{X}_{i},{X}_{k}}\right\}$ are from same domain (intra-domain samples), but belonging to different categories (inter-class samples). Thus, the mixed sample is

基础模型:我们的基础网络CuMix [22]是一个基于域间和域内混合的网络，并且是第一个解决零样本领域泛化(ZSDG)问题的网络。它由一个混合模块$\mathcal{M}$、一个特征提取器$\mathcal{F}$和一个分类器$\mathcal{C}$组成。该网络中的混合操作是在一个三元组集合$\mathcal{T} = \left\{  {{x}_{i},{x}_{j},{x}_{k}}\right\}$上进行的，使得样本对$\left\{  {{x}_{i},{x}_{j}}\right\}$来自不同的领域(域间样本)，而$\left\{  {{X}_{i},{X}_{k}}\right\}$来自相同的领域(域内样本)，但属于不同的类别(类间样本)。因此，混合后的样本是

$$
{x}_{mixed} = \mathcal{M}\left( {{x}_{i},{x}_{j},{x}_{k},\delta }\right)  = \delta {x}_{i} + \left( {1 - \delta }\right) \left\lbrack  {\xi {x}_{j} + \left( {1 - \xi }\right) {x}_{k}}\right\rbrack   \tag{1}
$$

where, $\delta$ is the mixing co-efficient and $\xi$ is sampled from Binomial distribution, generating ${x}_{\text{mixed }}$ as either a cross-domain sample (for $\xi  = 1$ ), or a cross-category sample $\left( {\xi  = 0}\right)$ . The rest of the components of the network $\mathcal{F}$ and $\mathcal{C}$ are learned using ${x}_{\text{mixed }}$ .

其中，$\delta$ 是混合系数，$\xi$ 是从二项分布中采样得到的，生成的 ${x}_{\text{mixed }}$ 要么是跨域样本(对于 $\xi  = 1$ 而言)，要么是跨类别样本 $\left( {\xi  = 0}\right)$。网络的其余组件 $\mathcal{F}$ 和 $\mathcal{C}$ 使用 ${x}_{\text{mixed }}$ 进行学习。

The classifier module $\mathcal{C}$ in CuMix consists of (1) a semantic projector ${\mathcal{P}}_{\text{sem }}$ to transform the feature-representation $\mathcal{F}\left( {x}_{\text{mixed }}\right)$ to the semantic space, and (2) a set of fixed semantic weights, ${\mathcal{W}}_{\text{sem }} = \left\lbrack  {{w}_{1},\ldots ,{w}_{c},\ldots ,{w}_{\left| {\mathcal{Y}}_{tr}\right| }}\right\rbrack$ , which is the collection of semantic information $\left( {w}_{c}\right)$ in the form of word-embedding of the category-names for each class ${y}_{c} \in  {\mathcal{Y}}_{tr}$ . These weights are utilized to compute the probability that ${x}_{\text{mixed }}$ belongs to class with label ${y}_{c}$ as, prob $\left( {{x}_{\text{mixed}} \in  {y}_{c}}\right)  = \frac{{exp}\left( {{w}_{c} * \mathcal{F}\left( {x}_{\text{mixed}}\right) }\right) }{\mathop{\sum }\limits_{{l \in  {\mathcal{Y}}_{tr}}}{exp}\left( {{w}_{l} * \mathcal{F}\left( {x}_{\text{mixed}}\right) }\right) }$ . Here we overload the notation ${y}_{c}$ to also denote the class with that label. The network is trained in an end-to-end manner through minimizing a mix-up based cross-entropy loss based on these probabilities as,

CuMix 中的分类器模块 $\mathcal{C}$ 包括:(1)一个语义投影器 ${\mathcal{P}}_{\text{sem }}$，用于将特征表示 $\mathcal{F}\left( {x}_{\text{mixed }}\right)$ 转换到语义空间；(2)一组固定的语义权重 ${\mathcal{W}}_{\text{sem }} = \left\lbrack  {{w}_{1},\ldots ,{w}_{c},\ldots ,{w}_{\left| {\mathcal{Y}}_{tr}\right| }}\right\rbrack$，它是以每个类别 ${y}_{c} \in  {\mathcal{Y}}_{tr}$ 的类别名称的词嵌入形式存在的语义信息 $\left( {w}_{c}\right)$ 的集合。利用这些权重来计算 ${x}_{\text{mixed }}$ 属于标签为 ${y}_{c}$ 的类别的概率，即 prob $\left( {{x}_{\text{mixed}} \in  {y}_{c}}\right)  = \frac{{exp}\left( {{w}_{c} * \mathcal{F}\left( {x}_{\text{mixed}}\right) }\right) }{\mathop{\sum }\limits_{{l \in  {\mathcal{Y}}_{tr}}}{exp}\left( {{w}_{l} * \mathcal{F}\left( {x}_{\text{mixed}}\right) }\right) }$。这里我们重载符号 ${y}_{c}$ 来同时表示具有该标签的类别。通过最小化基于这些概率的混合交叉熵损失，以端到端的方式训练网络，如下所示:

$$
{\mathcal{L}}_{\text{mixed-CE }} =  - \frac{1}{\left| \mathcal{T}\right| }\left\lbrack  {\delta \log \operatorname{prob}\left( {{x}_{\text{mixed }} \in  {y}_{i}}\right) }\right.
$$

$$
+ \left( {1 - \delta }\right) \lbrack \xi \log \operatorname{prob}\left( {{x}_{\text{mixed }} \in  {y}_{j}}\right)
$$

$$
\left. {+\left( {1 - \xi }\right) \log \operatorname{prob}\left( {{x}_{\text{mixed }} \in  {y}_{k}}\right) }\right\rbrack  \rbrack  \tag{2}
$$

In addition, the model also minimizes a semantic loss function ${\mathcal{L}}_{\text{sem }}$ , which is the cross-

此外，该模型还最小化一个语义损失函数 ${\mathcal{L}}_{\text{sem }}$，它是

![0195d70b-6ff8-7313-8361-b027e4c2e1e8_4_151_100_1264_937_0.jpg](images/0195d70b-6ff8-7313-8361-b027e4c2e1e8_4_151_100_1264_937_0.jpg)

Figure 2: The proposed MAMC-Net architecture for (a) training, (b) inference.

图 2:所提出的 MAMC - Net 架构，用于(a)训练，(b)推理。

entropy loss for the raw-samples ${x}_{i} \in  {\mathcal{D}}_{tr}$ as

原始样本 ${x}_{i} \in  {\mathcal{D}}_{tr}$ 的交叉熵损失为

$$
{\mathcal{L}}_{\text{sem }} =  - \frac{1}{n}\mathop{\sum }\limits_{{{y}_{c} \in  {\mathcal{Y}}_{tr}}}\log \operatorname{prob}\left( {{x}_{i} \in  {y}_{c}}\right)  \tag{3}
$$

Now, we describe the proposed novel modules in MAMC-Net in details. A block diagram of the proposed framework is shown in Figure 2.

现在，我们详细描述 MAMC - Net 中提出的新颖模块。所提出框架的框图如图 2 所示。

1) Domain Agnostic Representation Module: Inspired by [60], we introduce a module $\mathcal{G}$ to learn the mixing proportion of the different classes for each ${x}_{\text{mixed }}$ . This will enable the model to forget the domain specific characteristics present in ${x}_{\text{mixed }}$ , and to learn only the features specific to the category. This serves the domain-agnostic representation learning goal, as well as enhances the class-discriminability of the model. The corresponding loss is:

1)领域无关表示模块:受文献 [60] 的启发，我们引入一个模块 $\mathcal{G}$ 来学习每个 ${x}_{\text{mixed }}$ 中不同类别的混合比例。这将使模型能够忽略 ${x}_{\text{mixed }}$ 中存在的特定领域特征，而仅学习特定类别的特征。这既实现了领域无关表示学习的目标，又增强了模型的类别区分能力。相应的损失为:

$$
{\mathcal{L}}_{\text{dar }} =  - \frac{1}{\left| \mathcal{T}\right| }\mathop{\sum }\limits_{{{x}_{\text{mixed }} \in  \mathcal{T}}}{\eta }_{\text{mixed }} * \log \left( {v}_{\text{mixed }}\right) ;\;{v}_{\text{mixed }} = \operatorname{soft-max}\left( {\mathcal{G}\left( {x}_{\text{mixed }}\right) }\right)
$$

(4)

where, ${\eta }_{\text{mixed }}$ is the mixed-label information of ${x}_{\text{mixed }}$ , computed on the basis of the one-hot representation $\left( {{\eta }_{i},{\eta }_{j}}\right.$ and $\left. {\eta }_{k}\right)$ of component classes as ${\eta }_{\text{mixed }} = \delta {\eta }_{i} + \left( {1 - \delta }\right) \left\lbrack  {\xi {\eta }_{j} + }\right.$ $\left. {\left( {1 - \xi }\right) {\eta }_{k}}\right\rbrack$ . This loss improves the domain-invariant representation of the feature-extractor $\mathcal{F}$ .

其中，${\eta }_{\text{mixed }}$ 是 ${x}_{\text{mixed }}$ 的混合标签信息，它是根据组成类别的独热表示 $\left( {{\eta }_{i},{\eta }_{j}}\right.$ 和 $\left. {\eta }_{k}\right)$ 计算得到的，即 ${\eta }_{\text{mixed }} = \delta {\eta }_{i} + \left( {1 - \delta }\right) \left\lbrack  {\xi {\eta }_{j} + }\right.$ $\left. {\left( {1 - \xi }\right) {\eta }_{k}}\right\rbrack$。该损失改善了特征提取器 $\mathcal{F}$ 的领域不变表示。

2) Adaptive Margin Classifier Module: Here, we explain the novel adaptive margin classifier, which can account for the class imbalance in the training data, while computing discriminating class-boundaries for the training classes. The confusion for a class depends on its variance, and during training, the classifier learns this spread or boundary about the class from the training data. When there is class imbalance, for minority classes, confusion arises since adequate data for this learning is not available, and thus a larger classifier margin tries to compensate for it. In ZSDG, though the test classes are different from the training ones, they are classified using their relatedness to the seen ones. Thus, if the training (seen) classes are improperly classified due to inadequate training examples in few classes or other reasons, it will in turn adversely affect the test classification.

2) 自适应边界分类器模块:在此，我们将介绍一种新颖的自适应边界分类器，它能够在为训练类别计算可区分的类别边界时，解决训练数据中的类别不平衡问题。某个类别的混淆程度取决于其方差，在训练过程中，分类器会从训练数据中学习该类别的分布范围或边界。当存在类别不平衡时，对于少数类别而言，由于缺乏足够的数据进行学习，就会产生混淆，因此需要更大的分类器边界来进行弥补。在零样本域泛化(ZSDG)中，尽管测试类别与训练类别不同，但会根据它们与已见类别的相关性对其进行分类。因此，如果由于某些类别中的训练样本不足或其他原因导致训练(已见)类别分类不当，反过来会对测试分类产生不利影响。

Several state-of-the-art class-imbalance handling techniques for applications like image classification aim to modify the classifier [B][12]. In contrast, the classifiers $\left( {\mathcal{W}}_{\text{sem }}\right)$ in ZSDG are usually fixed to the semantic representations (word-embeddings of class-names) to account for the unseen classes that will be encountered during testing. As explained earlier, for the minority classes, lesser number of training samples may result in increased confusion with the neighbouring classes. To account for this, we propose to incorporate an adaptive margin to each of the fixed semantic classifiers, with the objective that the classifiers sampled from this margin should be able to classify samples from the corresponding class correctly. Since the class probabilities are obtained by the cosine similarity between the feature and the perturbed classifier, this mitigates the adverse affect of lesser number of samples. Another advantage is that this class-specific margins can be learnt in an end-to-end-manner. Specifically, this margin is computed as a scaled Gaussian noise, where the scaling factor is learned during training. Specifically, the margin-factor for class ${y}_{c} \in  {\mathcal{Y}}_{tr}$ is defined as,

在图像分类等应用中，一些最先进的处理类别不平衡问题的技术旨在对分类器进行修改[B][12]。相比之下，零样本域泛化(ZSDG)中的分类器$\left( {\mathcal{W}}_{\text{sem }}\right)$通常固定为语义表示(类别名称的词嵌入)，以应对测试过程中可能遇到的未见类别。如前所述，对于少数类别，较少的训练样本可能会导致与相邻类别的混淆增加。为了解决这个问题，我们建议为每个固定的语义分类器引入一个自适应边界，目标是从该边界采样得到的分类器能够正确分类相应类别的样本。由于类别概率是通过特征与扰动分类器之间的余弦相似度得到的，这可以减轻样本数量较少带来的不利影响。另一个优点是，这种特定类别的边界可以以端到端的方式进行学习。具体来说，这个边界被计算为一个缩放后的高斯噪声，其中缩放因子在训练过程中学习得到。具体而言，类别${y}_{c} \in  {\mathcal{Y}}_{tr}$的边界因子定义为

$$
{\Delta }_{c} = {\lambda }_{c}\mathcal{N}\left( {0,1}\right)  \tag{5}
$$

where $\mathcal{N}\left( {0,1}\right)$ is a zero-mean unit-variance Gaussian noise and ${\lambda }_{c}$ is the learnable scaling factor. We initialize ${\lambda }_{c}$ as per the number of samples ${n}_{c}$ of class ${y}_{c}$ in the training set as, ${\lambda }_{c} = \left( {1 - \frac{{n}_{c}}{n}}\right)$ . For minority classes, ${n}_{c} <  < n$ , and thus ${\lambda }_{c}$ has a higher value, resulting in a wider ${\Delta }_{c}$ around the semantic embedding of the category name of ${y}_{c}$ . For majority classes, this margin is less. Throughout the training, the weights of the proposed adaptive classifier ${w}_{c}^{\bar{M}{AMC}}$ for class $c$ is randomly sampled following ${w}_{c}^{MAMC} \sim  \left( {{w}_{c} + {\Delta }_{c}}\right)$ . Using this modification, we now compute the probability of ${x}_{\text{mixed }}$ to belong to class $c$ as, $\mathcal{P}\left( {{x}_{\text{mixed }} \in  {y}_{c},{\lambda }_{c}}\right)  = \frac{\exp \left( {{w}_{c}^{\text{MMMC }} * \mathcal{F}\left( {\mathbf{x}}_{\text{mixed }}\right) }\right) }{\mathop{\sum }\limits_{{l \in  {\mathcal{Y}}_{tr}}}\exp \left( {{w}_{l}^{\text{MAMC }} * \mathcal{F}\left( {\mathbf{x}}_{\text{mixed }}\right) }\right) }$ , and the corresponding cross-entropy loss as,

其中$\mathcal{N}\left( {0,1}\right)$是零均值单位方差的高斯噪声，${\lambda }_{c}$是可学习的缩放因子。我们根据训练集中类别${y}_{c}$的样本数量${n}_{c}$对${\lambda }_{c}$进行初始化，即${\lambda }_{c} = \left( {1 - \frac{{n}_{c}}{n}}\right)$。对于少数类别，${n}_{c} <  < n$，因此${\lambda }_{c}$的值较高，从而在类别${y}_{c}$的名称的语义嵌入周围形成更宽的${\Delta }_{c}$。对于多数类别，这个边界较小。在整个训练过程中，针对类别$c$的自适应分类器${w}_{c}^{\bar{M}{AMC}}$的权重按照${w}_{c}^{MAMC} \sim  \left( {{w}_{c} + {\Delta }_{c}}\right)$进行随机采样。通过这种修改，我们现在计算${x}_{\text{mixed }}$属于类别$c$的概率为$\mathcal{P}\left( {{x}_{\text{mixed }} \in  {y}_{c},{\lambda }_{c}}\right)  = \frac{\exp \left( {{w}_{c}^{\text{MMMC }} * \mathcal{F}\left( {\mathbf{x}}_{\text{mixed }}\right) }\right) }{\mathop{\sum }\limits_{{l \in  {\mathcal{Y}}_{tr}}}\exp \left( {{w}_{l}^{\text{MAMC }} * \mathcal{F}\left( {\mathbf{x}}_{\text{mixed }}\right) }\right) }$，并计算相应的交叉熵损失为

$$
{\mathcal{L}}_{\text{mixed-CE }}^{MAMC} =  - \frac{1}{\left| \mathcal{T}\right| }\left\lbrack  {\delta \log \mathcal{P}\left( {{x}_{\text{mixed }} \in  {y}_{i},{\lambda }_{i}}\right) }\right.
$$

$$
+ \left( {1 - \delta }\right) \left\lbrack  {\xi \log \mathcal{P}\left( {{x}_{\text{mixed }} \in  {y}_{j},{\lambda }_{j}}\right) }\right.
$$

$$
\left. \left. {+\left( {1 - \xi }\right) \log \mathcal{P}\left( {{x}_{\text{mixed }} \in  {y}_{k},{\lambda }_{k}}\right) }\right\rbrack  \right\rbrack   \tag{6}
$$

Now, we discuss the complete training process followed in this work.

现在，我们来讨论本文所采用的完整训练过程。

Complete Training and Inference Methodology: For effectively training MAMC-Net, we minimize a combination of three loss-components: (1) Mix-up based cross-entropy loss ${\mathcal{L}}_{\text{mixed-CE }}^{MAMC}$ with the adaptive classifier; (2) Domain agnostic representation loss ${\mathcal{L}}_{\text{dar }}$ ; (3) Modified semantic loss (eq. (3)) given by: ${\mathcal{L}}_{\text{sem }}^{\text{MAMC }} =  - \frac{1}{n}\mathop{\sum }\limits_{{{y}_{c} \in  {\mathcal{Y}}_{\text{tr }}}}\log \mathcal{P}\left( {{x}_{\text{mixed }} \in  {y}_{c},{\lambda }_{c}}\right)$ . Thus, the combined loss function is given by

完整的训练和推理方法:为了有效地训练MAMC网络(MAMC-Net)，我们最小化三个损失组件的组合:(1)基于混合(Mix-up)的交叉熵损失${\mathcal{L}}_{\text{mixed-CE }}^{MAMC}$与自适应分类器；(2)领域无关表示损失${\mathcal{L}}_{\text{dar }}$；(3)修正后的语义损失(公式(3))，表达式为:${\mathcal{L}}_{\text{sem }}^{\text{MAMC }} =  - \frac{1}{n}\mathop{\sum }\limits_{{{y}_{c} \in  {\mathcal{Y}}_{\text{tr }}}}\log \mathcal{P}\left( {{x}_{\text{mixed }} \in  {y}_{c},{\lambda }_{c}}\right)$。因此，组合损失函数为

$$
\mathcal{L} = {\kappa }_{1}{\mathcal{L}}_{\text{sem }}^{\text{MAMC }} + {\kappa }_{2}{\mathcal{L}}_{\text{dar }} + {\kappa }_{3}{\mathcal{L}}_{\text{mixed-CE }}^{\text{MAMC }} \tag{7}
$$

where, ${\kappa }_{1},{\kappa }_{2}$ and ${\kappa }_{3}$ are the hyper-parameters. The model is trained end-to-end to optimize the model components, $\mathcal{F},{\mathcal{P}}_{\text{sem }},\mathcal{G}$ and the margins ${\Delta }_{c}$ in the adaptive classifier ${\mathcal{W}}_{\text{sem }}^{MAMC}$ for handling class-imbalanced ZSDG task.

其中，${\kappa }_{1},{\kappa }_{2}$和${\kappa }_{3}$是超参数。该模型进行端到端训练，以优化模型组件、$\mathcal{F},{\mathcal{P}}_{\text{sem }},\mathcal{G}$以及自适应分类器${\mathcal{W}}_{\text{sem }}^{MAMC}$中的边界${\Delta }_{c}$，从而处理类别不平衡的零样本领域泛化(ZSDG)任务。

After training, the obtained feature extractor $\mathcal{F}$ can robustly classify samples from unseen domain(s), as well as from unseen class(es). During inference, we use the semantic information from these unseen classes in ${\mathcal{Y}}_{te}$ as the classifiers, i.e. the classifier for ${t}^{th}$ unknown class is ${w}_{t}$ , contains the semantic information in the form of the word-embeddings of ${t}^{th}$ -class’s name. The test sample ${x}_{te} \in  {\mathcal{D}}_{te}$ is passed through the feature extractor $\mathcal{F}$ , and the corresponding class is predicted as

训练完成后，所得到的特征提取器$\mathcal{F}$能够稳健地对来自未见领域以及未见类别的样本进行分类。在推理过程中，我们使用${\mathcal{Y}}_{te}$中这些未见类别的语义信息作为分类器，即${t}^{th}$未知类别的分类器为${w}_{t}$，它以${t}^{th}$类名称的词嵌入形式包含语义信息。测试样本${x}_{te} \in  {\mathcal{D}}_{te}$通过特征提取器$\mathcal{F}$，并预测其对应的类别为

$$
{\widehat{y}}_{te} = \underset{t \in  {\mathcal{Y}}_{te}}{\arg \max }\left\lbrack  {{w}_{t} * \mathcal{F}\left( {x}_{te}\right) }\right\rbrack   \tag{8}
$$

Now, we will discuss the experiments performed to evaluate the proposed MAMC-Net.

现在，我们将讨论为评估所提出的MAMC网络而进行的实验。

## 5 Experiments and Analysis

## 5 实验与分析

We experimented on two large-scale datasets, namely DomainNet [B1] and DomainNet-LS [22]. DomainNet [13] is the benchmark dataset for ZSDG [22][8] and comprises of 6-domains consisting of 345-categories in each domain. The domains are real, painting, sketch, quickdraw, info-graph and clip-art. Following the standard ZSDG-protocol [22], we use 300-categories for training, and the remaining for evaluation. 5-domains are used during training, and the remaining domain is used as the unseen domain for testing. However, image-domain is never used as an unseen target domain, as the model is pre-trained on the ImageNet [2] data. DomainNet-LS is a modified DomainNet dataset [B1], where the training and test domains are pre-defined. Here, the class-wise seen / unseen data split remains unchanged, but only the two domains, real and painting are used for training. The remaining 4-domains are used for evaluation. This domain-split becomes more challenging due to the presence of unseen domains, like sketch or quickdraw, for which no related training domains are present. This dataset was first proposed in [23], and later used in [8] for ZSDG.

我们在两个大规模数据集上进行了实验，即领域网络数据集(DomainNet)[B1]和领域网络大规模数据集(DomainNet-LS)[22]。领域网络数据集[13]是零样本领域泛化(ZSDG)的基准数据集[22][8]，由6个领域组成，每个领域包含345个类别。这些领域包括真实图像、绘画、素描、快速绘图、信息图和剪贴画。按照标准的零样本领域泛化协议[22]，我们使用300个类别进行训练，其余类别用于评估。训练过程中使用5个领域，剩余的一个领域作为未见领域用于测试。然而，由于模型在图像网络数据集(ImageNet)[2]上进行了预训练，图像领域从不作为未见目标领域使用。领域网络大规模数据集是经过修改的领域网络数据集[B1]，其中训练和测试领域是预先定义的。在这里，按类别划分的可见/未见数据分割保持不变，但仅使用真实图像和绘画这两个领域进行训练。其余4个领域用于评估。由于存在未见领域，如素描或快速绘图，且没有相关的训练领域，这种领域分割变得更具挑战性。该数据集首次在[23]中提出，后来在[8]中用于零样本领域泛化。

Baselines: Following [12], we compare MAMC-Net with several existing ZSDG methods in literature, such as: (1) ZSDG: We provide comparison with SOTA methods, namely CuMix [CZ] and SLE-Net [B]. We utilized CuMix [CZ] as the base network and explained it in Section 4. SLE-Net [8] is the more recent approach for ZSDG. (2) ZSL: We report the performance of few ZSL methods, such as DEVISE [110], ALE [110] and SPNET [411] under the ZSDG scenario. We train these models on the training data from multiple domains, and perform the inference on data from an unknown domain. (3) Extending DG for ZSL: We also experiment with standard DG methods, such as DANN [[1] and EpiFCR [2], and use them in addition with the ZSL-methods to perform classification under ZSDG protocol. Thus, the baselines selected to benchmark the performance of MAMC-Net is quite exhaustive.

基线方法:参照[12]，我们将MAMC网络与文献中几种现有的零样本领域泛化方法进行比较，例如:(1)零样本领域泛化:我们与最先进的方法进行比较，即混合增强(CuMix)[CZ]和语义学习增强网络(SLE-Net)[B]。我们将混合增强[CZ]作为基础网络，并在第4节进行了说明。语义学习增强网络[8]是最近用于零样本领域泛化的方法。(2)零样本学习:我们报告了几种零样本学习方法在零样本领域泛化场景下的性能，如设备视觉语义嵌入(DEVISE)[110]、注意力学习嵌入(ALE)[110]和语义原型网络(SPNET)[411]。我们在来自多个领域的训练数据上训练这些模型，并对来自未知领域的数据进行推理。(3)将领域泛化扩展到零样本学习:我们还对标准的领域泛化方法进行了实验，如对抗域适应网络(DANN)[1]和表型特征对比正则化(EpiFCR)[2]，并将它们与零样本学习方法结合使用，以按照零样本领域泛化协议进行分类。因此，为评估MAMC网络性能而选择的基线方法相当全面。

Implementation details : MAMC-Net is implemented in Pytorch [29], using a single Nvidia RTX A5000 GPU. We use Resnet-50 [C3], pre-trained on ImageNet as the backbone (same as CuMix [CZ]). We report the results using standard top-1 average per-class accuracy. Following [[2], the semantic representation of the classes are the L2-normalized word-embeddings from Google news corpus word2vec [6] model. SGD optimizer with momentum $= {0.9}$ , an initial learning rate of ${10}^{-3}$ , with a multi-step scheduler with scale factor of 0.1 at each scheduling step is used for learning, on a batch-size of 100 . The mixing ratio $\delta$ in our experiments are sampled from a beta-distribution $\beta \left( {m, n}\right)$ , where $m = n$ , and $m$ is changed at regular intervals to ensure fair contribution for all component samples. All the hyper-parameters ${k}_{1} = {k}_{2} = {k}_{3} = 1$ , since the starting values for all three loss components in eqn. 7 are in comparable range. The average accuracy results over 10 trials for each target domain are reported in this work.

实现细节:MAMC-Net 使用单个英伟达 RTX A5000 GPU 在 PyTorch [29] 中实现。我们使用在 ImageNet 上预训练的 Resnet - 50 [C3] 作为骨干网络(与 CuMix [CZ] 相同)。我们报告使用标准的 top - 1 每类平均准确率的结果。根据 [2]，类别的语义表示是来自谷歌新闻语料库 word2vec [6] 模型的 L2 归一化词嵌入。使用带有动量 $= {0.9}$ 的随机梯度下降(SGD)优化器，初始学习率为 ${10}^{-3}$，采用多步调度器，每个调度步骤的缩放因子为 0.1 进行学习，批量大小为 100。在我们的实验中，混合比例 $\delta$ 是从 beta 分布 $\beta \left( {m, n}\right)$ 中采样得到的，其中 $m = n$，并且 $m$ 会定期更改，以确保所有组件样本的公平贡献。所有超参数 ${k}_{1} = {k}_{2} = {k}_{3} = 1$，因为公式 7 中所有三个损失组件的起始值都在可比范围内。本文报告了每个目标域在 10 次试验中的平均准确率结果。

Table 1: ZSDG results on DomainNet dataset - per class accuracy (%).

表 1:DomainNet 数据集上的零样本域泛化(ZSDG)结果 - 每类准确率(%)。

<table><tr><td colspan="2">Method</td><td rowspan="2">painting</td><td colspan="2">Target Domain</td><td/><td colspan="2">Avg</td></tr><tr><td>DG</td><td>ZSL</td><td>inforgraph</td><td>quickdraw</td><td>sketch</td><td>clipart</td><td/></tr><tr><td rowspan="3">-</td><td>DEVISE [III]</td><td>17.6</td><td>11.7</td><td>6.1</td><td>16.7</td><td>20.1</td><td>14.4</td></tr><tr><td>ALE [M]</td><td>20.2</td><td>12.7</td><td>6.8</td><td>18.5</td><td>22.7</td><td>16.2</td></tr><tr><td>SPNet [40]</td><td>23.8</td><td>16.9</td><td>8.2</td><td>21.8</td><td>26.0</td><td>19.4</td></tr><tr><td rowspan="3">DANN [III]</td><td>DEVISE [III]</td><td>16.4</td><td>10.4</td><td>7.1</td><td>15.1</td><td>20.5</td><td>13.9</td></tr><tr><td>ALE [M]</td><td>19.7</td><td>12.5</td><td>7.4</td><td>17.9</td><td>21.2</td><td>15.7</td></tr><tr><td>SPNet [121]</td><td>24.1</td><td>15.8</td><td>8.4</td><td>21.3</td><td>25.9</td><td>19.1</td></tr><tr><td rowspan="3">EpiFCR [121]</td><td>DEVISE [III]</td><td>19.3</td><td>13.9</td><td>7.3</td><td>17.2</td><td>21.6</td><td>15.9</td></tr><tr><td>ALE [M]</td><td>21.4</td><td>14.1</td><td>7.8</td><td>20.9</td><td>23.2</td><td>17.5</td></tr><tr><td>SPNet [12]</td><td>24.6</td><td>16.7</td><td>9.2</td><td>23.2</td><td>26.4</td><td>20.0</td></tr><tr><td colspan="2">CuMix [121]</td><td>25.5</td><td>17.8</td><td>9.9</td><td>22.6</td><td>27.6</td><td>20.7</td></tr><tr><td colspan="2">CuMix (our implementation)</td><td>25.2</td><td>17.1</td><td>9.3</td><td>22.1</td><td>26.5</td><td>20.0</td></tr><tr><td colspan="2">SLE-Net [8] (SOTA)</td><td>26.6</td><td>18.4</td><td>11.5</td><td>25.2</td><td>27.8</td><td>21.9</td></tr><tr><td colspan="2">MAMC-Net (Ours)</td><td>27.3</td><td>19.5</td><td>12.1</td><td>26.0</td><td>28.8</td><td>22.7</td></tr></table>

<table><tbody><tr><td colspan="2">方法</td><td rowspan="2">绘画</td><td colspan="2">目标领域</td><td></td><td colspan="2">平均值</td></tr><tr><td>域泛化(Domain Generalization，DG)</td><td>零样本学习(Zero-Shot Learning，ZSL)</td><td>信息图</td><td>快速绘图</td><td>草图</td><td>剪贴画</td><td></td></tr><tr><td rowspan="3">-</td><td>DEVISE [III]</td><td>17.6</td><td>11.7</td><td>6.1</td><td>16.7</td><td>20.1</td><td>14.4</td></tr><tr><td>ALE [M]</td><td>20.2</td><td>12.7</td><td>6.8</td><td>18.5</td><td>22.7</td><td>16.2</td></tr><tr><td>SPNet [40]</td><td>23.8</td><td>16.9</td><td>8.2</td><td>21.8</td><td>26.0</td><td>19.4</td></tr><tr><td rowspan="3">DANN [III]</td><td>DEVISE [III]</td><td>16.4</td><td>10.4</td><td>7.1</td><td>15.1</td><td>20.5</td><td>13.9</td></tr><tr><td>ALE [M]</td><td>19.7</td><td>12.5</td><td>7.4</td><td>17.9</td><td>21.2</td><td>15.7</td></tr><tr><td>SPNet [121]</td><td>24.1</td><td>15.8</td><td>8.4</td><td>21.3</td><td>25.9</td><td>19.1</td></tr><tr><td rowspan="3">EpiFCR [121]</td><td>DEVISE [III]</td><td>19.3</td><td>13.9</td><td>7.3</td><td>17.2</td><td>21.6</td><td>15.9</td></tr><tr><td>ALE [M]</td><td>21.4</td><td>14.1</td><td>7.8</td><td>20.9</td><td>23.2</td><td>17.5</td></tr><tr><td>SPNet [12]</td><td>24.6</td><td>16.7</td><td>9.2</td><td>23.2</td><td>26.4</td><td>20.0</td></tr><tr><td colspan="2">CuMix [121]</td><td>25.5</td><td>17.8</td><td>9.9</td><td>22.6</td><td>27.6</td><td>20.7</td></tr><tr><td colspan="2">CuMix(我们的实现)</td><td>25.2</td><td>17.1</td><td>9.3</td><td>22.1</td><td>26.5</td><td>20.0</td></tr><tr><td colspan="2">SLE-Net [8](最优方法)</td><td>26.6</td><td>18.4</td><td>11.5</td><td>25.2</td><td>27.8</td><td>21.9</td></tr><tr><td colspan="2">MAMC-Net(我们的方法)</td><td>27.3</td><td>19.5</td><td>12.1</td><td>26.0</td><td>28.8</td><td>22.7</td></tr></tbody></table>

Table 2: ZSDG results on DomainNet dataset - top-1 standard accuracy (%).

表2:DomainNet数据集上的零样本域泛化(ZSDG)结果 - 前1标准准确率(%)。

<table><tr><td rowspan="2">Method</td><td colspan="4">Target Domain</td><td colspan="2">Avg</td></tr><tr><td>painting</td><td>inforgraph</td><td>quickdraw</td><td>sketch</td><td>clipart</td><td/></tr><tr><td>CuMix [12]</td><td>27.6</td><td>16.3</td><td>9.7</td><td>25.9</td><td>27.8</td><td>21.5</td></tr><tr><td>SLE-Net [8] (SOTA)</td><td>28.8</td><td>17.6</td><td>11.5</td><td>26.3</td><td>29.1</td><td>22.7</td></tr><tr><td>MAMC-Net (Ours)</td><td>29.2</td><td>18.8</td><td>12.2</td><td>27.4</td><td>30.0</td><td>23.5</td></tr></table>

<table><tbody><tr><td rowspan="2">方法</td><td colspan="4">目标领域</td><td colspan="2">平均值</td></tr><tr><td>绘画</td><td>信息图(inforgraph)</td><td>快速绘图(quickdraw)</td><td>草图</td><td>剪贴画</td><td></td></tr><tr><td>CuMix [12]</td><td>27.6</td><td>16.3</td><td>9.7</td><td>25.9</td><td>27.8</td><td>21.5</td></tr><tr><td>SLE网络 [8](当前最优)</td><td>28.8</td><td>17.6</td><td>11.5</td><td>26.3</td><td>29.1</td><td>22.7</td></tr><tr><td>MAMC网络(我们的方法)</td><td>29.2</td><td>18.8</td><td>12.2</td><td>27.4</td><td>30.0</td><td>23.5</td></tr></tbody></table>

Table 3: ZSDG results on DomainNet-LS dataset.

表3:DomainNet-LS数据集上的零样本域泛化(ZSDG)结果。

<table><tr><td rowspan="2">Method</td><td colspan="4">Target Domain</td><td rowspan="2">Avg.</td></tr><tr><td>quickdraw</td><td>sketch</td><td>inforgraph</td><td>clipart</td></tr><tr><td>SPNet [121]</td><td>4.8</td><td>17.3</td><td>14.1</td><td>21.5</td><td>14.4</td></tr><tr><td>Epi-FCR [12] + SPNet [45]</td><td>5.6</td><td>18.7</td><td>14.9</td><td>22.5</td><td>15.4</td></tr><tr><td>CuMix [121]</td><td>5.5</td><td>19.7</td><td>17.1</td><td>23.7</td><td>16.5</td></tr><tr><td>SLE-Net [8] (SOTA)</td><td>7.2</td><td>20.5</td><td>16</td><td>24</td><td>16.9</td></tr><tr><td>MAMC-Net (Ours)</td><td>8.2</td><td>21.2</td><td>17.6</td><td>23.6</td><td>17.7</td></tr></table>

<table><tbody><tr><td rowspan="2">方法</td><td colspan="4">目标领域</td><td rowspan="2">平均值</td></tr><tr><td>快速绘图(quickdraw)</td><td>草图(sketch)</td><td>信息图(inforgraph)</td><td>剪贴画(clipart)</td></tr><tr><td>SP网络 [121]</td><td>4.8</td><td>17.3</td><td>14.1</td><td>21.5</td><td>14.4</td></tr><tr><td>Epi - FCR [12] + SP网络 [45]</td><td>5.6</td><td>18.7</td><td>14.9</td><td>22.5</td><td>15.4</td></tr><tr><td>CuMix [121]</td><td>5.5</td><td>19.7</td><td>17.1</td><td>23.7</td><td>16.5</td></tr><tr><td>SLE网络 [8](当前最优)</td><td>7.2</td><td>20.5</td><td>16</td><td>24</td><td>16.9</td></tr><tr><td>MAMC网络(我们的方法)</td><td>8.2</td><td>21.2</td><td>17.6</td><td>23.6</td><td>17.7</td></tr></tbody></table>

Results on DomainNet dataset: We summarize the ZSDG results on DomainNet in Table 1 in terms of per-class accuracy. The results for other algorithms are directly taken from [8]. We also include results of CuMix using our implementation (since this is our base network), which is similar to the reported ones [22], except for clipart. We observe that the performance of the ZSL-methods decrease when fused with DG method DANN [121] for almost all target domains, while EpiFCR [20] improves the ZSL methods marginally. These results indicate the need for developing dedicated methods to generalize across classes and domains. This is evident from the performance of CuMix and SLE-Net, which perform much better compared to the previous ones. However, MAMC-Net outperforms all these methods by a significant margin. Even in terms of top-1 standard accuracy, MAMC-Net outperforms both CuMix and SLE-Net as observed in Table 2. This clearly justifies the effectiveness of the proposed method for ZSDG task. We also present sample prediction results on this dataset using MAMC-Net in Figure 3. The correct and incorrect predictions are highlighted with green and blue, respectively. We observe that most of the incorrect predictions are semantically related to the query images (eg. bread is classified as cake, blackberry is classified as grapes). This indicates MAMC-Net's effectiveness to fuse the semantic relevance between categories while learning the feature-space.

DomainNet数据集上的结果:我们在表1中按类别准确率总结了零样本域泛化(ZSDG)在DomainNet上的结果。其他算法的结果直接取自文献[8]。我们还纳入了使用我们实现的CuMix的结果(因为这是我们的基础网络)，除了剪贴画(clipart)领域外，该结果与文献[22]中报告的结果相似。我们观察到，当零样本学习(ZSL)方法与域泛化(DG)方法DANN [121]融合时，几乎所有目标域的性能都会下降，而EpiFCR [20]对ZSL方法的提升幅度较小。这些结果表明需要开发专门的方法来实现跨类别和跨域的泛化。从CuMix和SLE-Net的性能可以明显看出这一点，它们的表现比之前的方法要好得多。然而，MAMC-Net显著优于所有这些方法。如表2所示，即使在top-1标准准确率方面，MAMC-Net也优于CuMix和SLE-Net。这清楚地证明了所提出的方法在ZSDG任务中的有效性。我们还在图3中展示了使用MAMC-Net在该数据集上的样本预测结果。正确和错误的预测分别用绿色和蓝色突出显示。我们观察到，大多数错误预测在语义上与查询图像相关(例如，面包被分类为蛋糕，黑莓被分类为葡萄)。这表明MAMC-Net在学习特征空间时能够有效融合类别之间的语义相关性。

Table 4: Ablation study of proposed MAMC-Net on DomainNet.

表4:所提出的MAMC-Net在DomainNet上的消融研究。

<table><tr><td>Model Variants</td><td>quickdraw</td><td>painting</td></tr><tr><td>Base Model</td><td>9.2</td><td>25.2</td></tr><tr><td>Base model $+ {\mathcal{L}}_{\text{dar }}$</td><td>10.5</td><td>26.4</td></tr><tr><td>Base model $+ {\mathcal{L}}_{\text{dar }} + {\mathcal{L}}_{\text{fix-margin }}$</td><td>11.1</td><td>26.3</td></tr><tr><td>MAMC-Net</td><td>12.1</td><td>27.3</td></tr></table>

<table><tbody><tr><td>模型变体</td><td>快速绘图</td><td>绘画</td></tr><tr><td>基础模型</td><td>9.2</td><td>25.2</td></tr><tr><td>基础模型 $+ {\mathcal{L}}_{\text{dar }}$</td><td>10.5</td><td>26.4</td></tr><tr><td>基础模型 $+ {\mathcal{L}}_{\text{dar }} + {\mathcal{L}}_{\text{fix-margin }}$</td><td>11.1</td><td>26.3</td></tr><tr><td>多注意力多上下文网络(MAMC-Net)</td><td>12.1</td><td>27.3</td></tr></tbody></table>

![0195d70b-6ff8-7313-8361-b027e4c2e1e8_8_115_459_1346_296_0.jpg](images/0195d70b-6ff8-7313-8361-b027e4c2e1e8_8_115_459_1346_296_0.jpg)

Figure 3: MAMC-Net predictions for few test samples from DomainNet dataset.

图3:MAMC-Net对DomainNet数据集的少量测试样本的预测结果。

Results on DomainNet-LS dataset: The results for DomainNet-LS dataset are reported in Table 3. The performance of the ZSL method, SPNet on the four targets, and its performance when combined with the DG-method Epi-FCR shows that this fusion provides marginal improvement for ZSDG task. In comparison, the ZSDG methods perform much better. However, the proposed MAMC-Net outperforms all the other ZSDG methods, CuMix and SLE-Net by a significant margin.

DomainNet-LS数据集上的结果:表3报告了DomainNet-LS数据集的实验结果。零样本学习(ZSL)方法、SPNet在四个目标上的性能，以及它与域泛化(DG)方法Epi-FCR结合时的性能表明，这种融合对零样本域泛化(ZSDG)任务有轻微的改进。相比之下，ZSDG方法的表现要好得多。然而，所提出的MAMC-Net显著优于所有其他ZSDG方法，如CuMix和SLE-Net。

Ablation Study: We perform an ablation study for MAMC-Net (Table 4) to understand the effectiveness of each component. We perform this study on DomainNet, with Quick-draw (ambigous and roughly drawn sketches, thus difficult to predict) and Painting (visually similar to RGB, thus easily predictable domain) as the target domains, which create robust test-conditions for the model. We perform experiments with different variations of the model, such as: (1) Base Model: gives the results of our base network CuMix [27]; (2) Base model $+ {\mathcal{L}}_{\text{dar }}$ : Here we use only the domain-agnostic loss with the fixed semantic classifier ${\mathcal{W}}_{\text{sem }}$ ; (3) Base model $+ {\mathcal{L}}_{\text{dar }} + {\mathcal{L}}_{\text{fix-margin }}$ : Here, we use a fixed margin $\left( {{\Delta }_{c} = \left( {1 - \frac{{n}_{c}}{n}}\right) \mathcal{N}\left( {0,1}\right) }\right)$ based classifier, instead of a learnable one; (4) MAMC-Net: This includes all the proposed modules. We observe that ${\mathcal{L}}_{\text{dar }}$ provides a significant boost to the base network, and the fix-margin classifier further improves the results (specially for quickdraw), justifying such margin-based classifier design. MAMC-Net outperforms all the other model-variants. Thus each of the proposed modules contributes to the good performance of the proposed framework.

消融实验:我们对MAMC-Net进行了消融实验(表4)，以了解每个组件的有效性。我们在DomainNet数据集上进行了这项研究，以Quick-draw(模糊且大致绘制的草图，因此难以预测)和Painting(在视觉上与RGB相似，因此是容易预测的领域)作为目标领域，这为模型创造了稳健的测试条件。我们对模型的不同变体进行了实验，例如:(1)基础模型:给出了我们的基础网络CuMix [27] 的结果；(2)基础模型 $+ {\mathcal{L}}_{\text{dar }}$ :这里我们仅使用与固定语义分类器 ${\mathcal{W}}_{\text{sem }}$ 相关的领域无关损失；(3)基础模型 $+ {\mathcal{L}}_{\text{dar }} + {\mathcal{L}}_{\text{fix-margin }}$ :这里，我们使用基于固定边界 $\left( {{\Delta }_{c} = \left( {1 - \frac{{n}_{c}}{n}}\right) \mathcal{N}\left( {0,1}\right) }\right)$ 的分类器，而不是可学习的分类器；(4)MAMC-Net:这包括所有提出的模块。我们观察到 ${\mathcal{L}}_{\text{dar }}$ 显著提升了基础网络的性能，并且固定边界分类器进一步改善了结果(特别是对于Quick-draw)，证明了这种基于边界的分类器设计的合理性。MAMC-Net优于所有其他模型变体。因此，每个提出的模块都对所提出框架的良好性能做出了贡献。

## 6 Conclusion

## 6 结论

In this work, we proposed a novel framework, MAMC-Net for handling the class imbalance problem in the context of zero-shot domain generalization. In addition to a domain-agnostic representation learning loss, we also introduced a novel learnable margin to the existing semantic classifier of a base ZSDG-network. We also presented extensive experiments and analysis across two large-scale datasets to demonstrate the effectiveness of this method. Here, we have addressed the class-imbalance in the training data, which can be extended for handling domain imbalance, resulting in further improvement in the ZSDG performance.

在这项工作中，我们提出了一个新颖的框架MAMC-Net，用于处理零样本域泛化背景下的类别不平衡问题。除了领域无关的表示学习损失外，我们还为基础ZSDG网络现有的语义分类器引入了一种新颖的可学习边界。我们还在两个大规模数据集上进行了广泛的实验和分析，以证明该方法的有效性。在这里，我们解决了训练数据中的类别不平衡问题，这可以扩展到处理领域不平衡问题，从而进一步提高ZSDG的性能。

## 7 Acknowledgement

## 7 致谢

This work is partly supported through a research grant from SERB, Department of Science and Technology, Govt. of India.

这项工作部分得到了印度政府科学技术部科学与工程研究委员会(SERB)的研究资助。

## References

## 参考文献

[1] Zeynep Akata, Florent Perronnin, Zaid Harchaoui, and Cordelia Schmid. Label-embedding for attribute-based classification. In CVPR, 2013.

[1] Zeynep Akata，Florent Perronnin，Zaid Harchaoui和Cordelia Schmid。基于属性分类的标签嵌入。发表于2013年计算机视觉与模式识别会议(CVPR)。

[2] Adnan Amin, Sajid Anwar, Awais Adnan, Muhammad Nawaz, Newton Howard, Junaid Qadir, Ahmad Hawalah, and Amir Hussain. Comparing oversampling techniques to handle the class imbalance problem: A customer churn prediction case study. IEEE Access, 4, 2016.

[2] Adnan Amin，Sajid Anwar，Awais Adnan，Muhammad Nawaz，Newton Howard，Junaid Qadir，Ahmad Hawalah和Amir Hussain。比较过采样技术以处理类别不平衡问题:一个客户流失预测案例研究。发表于《IEEE接入》，2016年第4期。

[3] Kaidi Cao, Colin Wei, Adrien Gaidon, Nikos Arechiga, and Tengyu Ma. Learning imbalanced datasets with label-distribution-aware margin loss. NeurIPS, 2019.

[3] Kaidi Cao，Colin Wei，Adrien Gaidon，Nikos Arechiga和Tengyu Ma。使用标签分布感知边界损失学习不平衡数据集。发表于2019年神经信息处理系统大会(NeurIPS)。

[4] F. M. Carlucci, A. D'Innocente, S. Bucci, B. Caputo, and T. Tommasi. Domain generalization by solving jigsaw puzzles. In CVPR, 2019.

[4] F. M. Carlucci，A. D'Innocente，S. Bucci，B. Caputo和T. Tommasi。通过解决拼图难题进行域泛化。发表于2019年计算机视觉与模式识别会议(CVPR)。

[5] Shivam Chandhok, Sanath Narayan, Hisham Cholakkal, Rao Muhammad Anwer, Vi-neeth N Balasubramanian, Fahad Shahbaz Khan, and Ling Shao. Structured latent embeddings for recognizing unseen classes in unseen domains. BMVC, 2021.

[5] Shivam Chandhok，Sanath Narayan，Hisham Cholakkal，Rao Muhammad Anwer，Vi-neeth N Balasubramanian，Fahad Shahbaz Khan和Ling Shao。用于识别未见领域中未见类别的结构化潜在嵌入。发表于2021年英国机器视觉会议(BMVC)。

[6] Kenneth Ward Church. Word2vec. Natural Language Engineering, 23, 2017.

[6] Kenneth Ward Church。词向量(Word2vec)。发表于《自然语言工程》，2017年第23期。

[7] Jia Deng, Wei Dong, Richard Socher, Li-Jia Li, Kai Li, and Li Fei-Fei. Imagenet: A large-scale hierarchical image database. In CVPR, 2009.

[7] Jia Deng，Wei Dong，Richard Socher，Li-Jia Li，Kai Li和Li Fei-Fei。ImageNet:一个大规模分层图像数据库。发表于2009年计算机视觉与模式识别会议(CVPR)。

[8] Abhimanyu Dubey, Vignesh Ramanathan, Alex Pentland, and Dhruv Mahajan. Adaptive methods for real-world domain generalization. In CVPR, 2021.

[8] 阿比曼纽·杜贝(Abhimanyu Dubey)、维格内什·拉马纳坦(Vignesh Ramanathan)、亚历克斯·彭特兰(Alex Pentland)和德鲁夫·马哈詹(Dhruv Mahajan)。现实世界领域泛化的自适应方法。发表于2021年计算机视觉与模式识别会议(CVPR)。

[9] Rafael Felix, Ian Reid, Gustavo Carneiro, et al. Multi-modal cycle-consistent generalized zero-shot learning. In ${ECCV},{2018}$ .

[9] 拉斐尔·费利克斯(Rafael Felix)、伊恩·里德(Ian Reid)、古斯塔沃·卡内罗(Gustavo Carneiro)等。多模态循环一致的广义零样本学习。发表于${ECCV},{2018}$。

[10] Andrea Frome, Greg S Corrado, Jon Shlens, Samy Bengio, Jeff Dean, Marc'Aurelio Ranzato, and Tomas Mikolov. Devise: A deep visual-semantic embedding model. NeurIPS, 2013.

[10] 安德里亚·弗罗姆(Andrea Frome)、格雷格·S·科拉多(Greg S Corrado)、乔恩·什伦斯(Jon Shlens)、萨米·本吉奥(Samy Bengio)、杰夫·迪恩(Jeff Dean)、马克·奥雷利奥·兰扎托(Marc'Aurelio Ranzato)和托马斯·米科洛夫(Tomas Mikolov)。Devise:一种深度视觉语义嵌入模型。发表于2013年神经信息处理系统大会(NeurIPS)。

[11] Yaroslav Ganin, Evgeniya Ustinova, Hana Ajakan, Pascal Germain, Hugo Larochelle, François Laviolette, Mario Marchand, and Victor Lempitsky. Domain-adversarial training of neural networks. machine learning research, 17(1), 2016.

[11] 亚罗斯拉夫·加宁(Yaroslav Ganin)、叶夫根尼娅·乌斯蒂诺娃(Evgeniya Ustinova)、哈娜·阿贾坎(Hana Ajakan)、帕斯卡尔·热尔曼(Pascal Germain)、雨果·拉罗谢尔(Hugo Larochelle)、弗朗索瓦·拉维奥莱特(François Laviolette)、马里奥·马尔尚(Mario Marchand)和维克多·伦皮茨基(Victor Lempitsky)。神经网络的领域对抗训练。机器学习研究，2016年，第17卷第1期。

[12] Munawar Hayat, Salman Khan, Syed Waqas Zamir, Jianbing Shen, and Ling Shao. Gaussian affinity for max-margin class imbalanced learning. In ICCV, 2019.

[12] 穆纳瓦尔·哈亚特(Munawar Hayat)、萨尔曼·汗(Salman Khan)、赛义德·瓦卡斯·扎米尔(Syed Waqas Zamir)、沈建兵和邵玲。用于最大间隔类别不平衡学习的高斯亲和性。发表于2019年国际计算机视觉大会(ICCV)。

[13] Kaiming He, Xiangyu Zhang, Shaoqing Ren, and Jian Sun. Deep residual learning for image recognition. In ${CVPR},{2016}$ .

[13] 何恺明、张祥雨、任少卿和孙剑。用于图像识别的深度残差学习。发表于${CVPR},{2016}$。

[14] Chen Huang, Yining Li, Chen Change Loy, and Xiaoou Tang. Learning deep representation for imbalanced classification. In CVPR, 2016.

[14] 黄晨、李一宁、罗智泉和汤晓鸥。用于不平衡分类的深度表示学习。发表于2016年计算机视觉与模式识别会议(CVPR)。

[15] Bartosz Krawczyk. Learning from imbalanced data: open challenges and future directions. Progress in Artificial Intelligence, 5(4), 2016.

[15] 巴托斯·克劳奇克(Bartosz Krawczyk)。从不平衡数据中学习:开放挑战与未来方向。人工智能进展，2016年，第5卷第4期。

[16] Christoph H Lampert, Hannes Nickisch, and Stefan Harmeling. Attribute-based classification for zero-shot visual object categorization. PAMI, 36, 2013.

[16] 克里斯托夫·H·兰佩特(Christoph H Lampert)、汉内斯·尼基施(Hannes Nickisch)和斯特凡·哈梅林(Stefan Harmeling)。基于属性的零样本视觉对象分类。模式分析与机器智能汇刊(PAMI)，2013年，第36卷。

[17] Jimmy Lei Ba, Kevin Swersky, Sanja Fidler, et al. Predicting deep zero-shot convolutional neural networks using textual descriptions. In ${ICCV},{2015}$ .

[17] 吉米·雷·巴(Jimmy Lei Ba)、凯文·斯韦尔斯基(Kevin Swersky)、桑贾·菲德勒(Sanja Fidler)等。使用文本描述预测深度零样本卷积神经网络。发表于${ICCV},{2015}$。

[18] D. Li, Y. Yang, Y. Z. Song, and T. M. Hospedales. Learning to generalize: meta-learning for domain generalization. In ${AAAI},{2018}$ .

[18] 李D、杨Y、宋Y.Z.和霍斯佩代尔斯T.M.。学习泛化:用于领域泛化的元学习。发表于${AAAI},{2018}$。

[19] Da Li, Yongxin Yang, Yi-Zhe Song, and Timothy M Hospedales. Deeper, broader and artier domain generalization. In ${ICCV},{2017}$ .

[19] 李达、杨永新、宋毅哲和蒂莫西·M·霍斯佩代尔斯。更深、更广、更具艺术性的领域泛化。发表于${ICCV},{2017}$。

[20] Da Li, Yongxin Yang, Yi-Zhe Song, and Timothy M Hospedales. Learning to generalize: Meta-learning for domain generalization. In ${AAAI},{2018}$ .

[20] 李达、杨永新、宋毅哲和蒂莫西·M·霍斯佩代尔斯。学习泛化:用于领域泛化的元学习。发表于${AAAI},{2018}$。

[21] Da Li, Jianshu Zhang, Yongxin Yang, Cong Liu, Yi-Zhe Song, and Timothy M Hospedales. Episodic training for domain generalization. In ICCV, 2019.

[21] 李达、张剑书、杨永新、刘聪、宋毅哲和蒂莫西·M·霍斯佩代尔斯。用于领域泛化的情景训练。发表于2019年国际计算机视觉大会(ICCV)。

[22] Haoliang Li, Sinno Jialin Pan, Shiqi Wang, and Alex C Kot. Domain generalization with adversarial feature learning. In CVPR, 2018.

[22] 李浩亮、潘嘉林、王世奇和柯亚历克斯·C。基于对抗特征学习的领域泛化。发表于2018年计算机视觉与模式识别会议(CVPR)。

[23] Haoliang Li, Sinno Jialin Pan, Shiqi Wang, and Alex C Kot. Domain generalization with adversarial feature learning. In CVPR, 2018.

[23] 李浩亮、潘嘉林、王世奇和柯亚历克斯·C。基于对抗特征学习的领域泛化。发表于2018年计算机视觉与模式识别会议(CVPR)。

[24] Juan Li, Ruoxu Wang, Ningyu Zhang, Wen Zhang, Fan Yang, and Huajun Chen. Logic-guided semantic representation learning for zero-shot relation classification. arXiv preprint arXiv:2010.16068, 2020.

[24] 李娟、王若旭、张宁宇、张文、杨帆和陈华军。用于零样本关系分类的逻辑引导语义表示学习。预印本 arXiv:2010.16068，2020年。

[25] Li Li, Kaiyi Zhao, Ruizhi Sun, Jiangzhang Gan, Gang Yuan, and Tong Liu. Parameter-free extreme learning machine for imbalanced classification. NPL, 52(3), 2020.

[25] 李立、赵恺怡、孙睿智、甘江章、袁刚和刘彤。用于不平衡分类的无参数极限学习机。《自然哲学通讯》(NPL)，52(3)，2020年。

[26] T. Maatsura and T. Harada. Domain generalization using a mixture of multiple latent domains. In ${AAAI},{2020}$ .

[26] T. 松浦和T. 原田。使用多个潜在领域混合的领域泛化。见${AAAI},{2020}$。

[27] Massimiliano Mancini, Zeynep Akata, Elisa Ricci, and Barbara Caputo. Towards recognizing unseen categories in unseen domains. In ${ECCV},{2020}$ .

[27] 马西米利亚诺·曼奇尼、泽内普·阿卡塔、伊莉莎·里奇和芭芭拉·卡普托。迈向在未见领域中识别未见类别。见${ECCV},{2020}$。

[28] Krikamol Muandet, David Balduzzi, and Bernhard Schölkopf. Domain generalization via invariant feature representation. In ICML, 2013.

[28] 克里卡莫尔·穆安代、大卫·巴尔杜齐和伯恩哈德·肖尔科普夫。通过不变特征表示进行领域泛化。见国际机器学习会议(ICML)，2013年。

[29] Adam Paszke, Sam Gross, Francisco Massa, Adam Lerer, James Bradbury, Gregory

[29] 亚当·帕兹克、山姆·格罗斯、弗朗西斯科·马萨、亚当·勒雷尔、詹姆斯·布拉德伯里、格雷戈里

Chanan, Trevor Killeen, Zeming Lin, Natalia Gimelshein, Luca Antiga, et al. Pytorch: An imperative style, high-performance deep learning library. NeurIPS, 2019.

·查南、特雷弗·基林、林泽明、娜塔莉亚·吉梅尔申、卢卡·安蒂加等。PyTorch:一种命令式风格的高性能深度学习库。神经信息处理系统大会(NeurIPS)，2019年。

[30] Soumava Paul, Titir Dutta, and Soma Biswas. Universal cross-domain retrieval: Generalizing across classes and domains. In ${ICCV},{2021}$ .

[30] 苏马瓦·保罗、蒂蒂尔·杜塔和索玛·比斯瓦斯。通用跨领域检索:跨类别和领域的泛化。见${ICCV},{2021}$。

[31] Xingchao Peng, Qinxun Bai, Xide Xia, Zijun Huang, Kate Saenko, and Bo Wang. Moment matching for multi-source domain adaptation. In ICCV, 2019.

[31] 彭兴超、白勤勋、夏西德、黄紫军、凯特·塞内科和王博。多源领域自适应的矩匹配。见国际计算机视觉大会(ICCV)，2019年。

[32] Dzung L Pham, Chenyang Xu, and Jerry L Prince. Current methods in medical image segmentation. Annual review of biomedical engineering, 2, 2000.

[32] 范德荣、徐晨阳和杰里·L·普林斯。医学图像分割的当前方法。《生物医学工程年度评论》，2，2000年。

[33] Fengchun Qiao, Long Zhao, and Xi Peng. Learning to learn single domain generalization. In ${CVPR},{2020}$ .

[33] 乔丰春、赵龙和彭熙。学习单领域泛化。见${CVPR},{2020}$。

[34] Ruizhi Qiao, Lingqiao Liu, Chunhua Shen, and Anton Van Den Hengel. Less is more: zero-shot learning from online textual documents with noise suppression. In CVPR, 2016.

[34] 乔睿智、刘凌桥、沈春华和安东·范登亨格尔。少即是多:通过抑制噪声从在线文本文档进行零样本学习。见计算机视觉与模式识别会议(CVPR)，2016年。

[35] Pengda Qin, Xin Wang, Wenhu Chen, Chunyun Zhang, Weiran Xu, and William Yang Wang. Generative adversarial zero-shot relational learning for knowledge graphs. In ${AAAI},{2020}$ .

[35] 秦鹏达、王鑫、陈文虎、张春云、徐伟然和王威廉。用于知识图谱的生成对抗零样本关系学习。见${AAAI},{2020}$。

[36] Bernardino Romera-Paredes and Philip Torr. An embarrassingly simple approach to zero-shot learning. In ${ICML},{2015}$ .

[36] 贝尔纳迪诺·罗梅拉 - 帕雷德斯和菲利普·托尔。一种极其简单的零样本学习方法。见${ICML},{2015}$。

[37] Seonguk Seo, Yumin Suh, Dongwan Kim, Geeho Kim, Jongwoo Han, and Bohyung Han. Learning to optimize domain specific normalization for domain generalization. In ${ECCV},{2020}$ .

[37] 徐成旭、徐裕民、金东万、金基浩、韩钟宇和韩宝亨。学习优化特定领域归一化以实现领域泛化。见${ECCV},{2020}$。

[38] Shujun Wang, Lequan Yu, Caizi Li, Chi-Wing Fu, and Pheng-Ann Heng. Learning from extrinsic and intrinsic supervisions for domain generalization. In ${ECCV},{2020}$ .

[38] 王树军、余乐权、李才子、傅志荣和邢本安。从外在和内在监督中学习以实现领域泛化。见${ECCV},{2020}$。

[39] Xiaolong Wang, Yufei Ye, and Abhinav Gupta. Zero-shot recognition via semantic embeddings and knowledge graphs. In CVPR, 2018.

[39] 王小龙(Xiaolong Wang)、叶宇飞(Yufei Ye)和阿比纳夫·古普塔(Abhinav Gupta)。通过语义嵌入和知识图谱实现零样本识别。发表于《计算机视觉与模式识别会议》(CVPR)，2018年。

[40] Yongqin Xian, Bernt Schiele, and Zeynep Akata. Zero-shot learning-the good, the bad and the ugly. In ${CVPR},{2017}$ .

[40] 咸永琴(Yongqin Xian)、伯恩特·席勒(Bernt Schiele)和泽内普·阿卡塔(Zeynep Akata)。零样本学习——好的、坏的和丑陋的方面。发表于${CVPR},{2017}$。

[41] Yongqin Xian, Subhabrata Choudhury, Yang He, Bernt Schiele, and Zeynep Akata. Semantic projection network for zero-and few-label semantic segmentation. In CVPR, 2019.

[41] 咸永琴(Yongqin Xian)、苏巴布拉塔·乔杜里(Subhabrata Choudhury)、何杨(Yang He)、伯恩特·席勒(Bernt Schiele)和泽内普·阿卡塔(Zeynep Akata)。用于零标签和少标签语义分割的语义投影网络。发表于《计算机视觉与模式识别会议》(CVPR)，2019年。

[42] L. Ya, X. Tian, M. Gong, Y. Liu, T. Liu, K. Zhang, and D. Tao. Deep domain generalization via conditional invariant adversarial networks. In ${ECCV},{2018}$ .

[42] 雅某(L. Ya)、田某(X. Tian)、龚某(M. Gong)、刘某(Y. Liu)、刘某(T. Liu)、张某(K. Zhang)和陶某(D. Tao)。通过条件不变对抗网络实现深度领域泛化。发表于${ECCV},{2018}$。

[43] Yongxin Yang and Timothy M Hospedales. A unified perspective on multi-domain and multi-task learning. arXiv preprint arXiv:1412.7489, 2014.

[43] 杨永新(Yongxin Yang)和蒂莫西·M·霍斯佩代尔斯(Timothy M Hospedales)。多领域和多任务学习的统一视角。预印本arXiv:1412.7489，2014年。

[44] Peng Zhou, Bingbing Ni, Cong Geng, Jianguo Hu, and Yi Xu. Scale-transferrable object detection. In ${CVPR},{2018}$ .

[44] 周鹏(Peng Zhou)、倪冰冰(Bingbing Ni)、耿聪(Cong Geng)、胡建国(Jianguo Hu)和徐毅(Yi Xu)。可进行尺度迁移的目标检测。发表于${CVPR},{2018}$。