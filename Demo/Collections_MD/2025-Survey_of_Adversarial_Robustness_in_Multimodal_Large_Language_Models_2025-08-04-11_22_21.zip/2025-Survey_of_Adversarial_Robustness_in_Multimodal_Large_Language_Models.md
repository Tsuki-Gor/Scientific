# Survey of Adversarial Robustness in Multimodal Large Language Models

# 多模态大规模语言模型中的对抗鲁棒性研究

Chengze Jiang ${}^{1}$ , Zhuangzhuang Wang ${}^{1}$ , Minjing Dong ${}^{3}$ , Jie Gui ${}^{*1,2}$ ,

江成泽 ${}^{1}$ , 王壮壮 ${}^{1}$ , 董敏靖 ${}^{3}$ , 桂杰 ${}^{*1,2}$ ,

${}^{1}$ School of Cyber Science and Engineering, Southeast University, Nanjing, China ${}^{2}$ Purple Mountain Laboratories, Nanjing, China ${}^{3}$ Department of Computer Science, City University of Hong Kong, Hong Kong, China czjiang@seu.edu.cn, 220235252@seu.edu.cn, minjdong@cityu.edu.hk, guijie@seu.edu.cn

${}^{1}$ 东南大学网络空间科学与工程学院，南京，中国 ${}^{2}$ 紫金山实验室，南京，中国 ${}^{3}$ 香港城市大学计算机科学系，香港，中国 czjiang@seu.edu.cn, 220235252@seu.edu.cn, minjdong@cityu.edu.hk, guijie@seu.edu.cn

## Abstract

## 摘要

Multimodal Large Language Models (MLLMs) have demonstrated exceptional performance in artificial intelligence by facilitating integrated understanding across diverse modalities, including text, images, video, audio, and speech. However, their deployment in real-world applications raises significant concerns about adversarial vulnerabilities that could compromise their safety and reliability. Unlike unimodal models, MLLMs face unique challenges due to the interdependencies among modalities, making them susceptible to modality-specific threats and cross-modal adversarial manipulations. This paper reviews the adversarial robustness of MLLMs, covering different modalities. We begin with an overview of MLLMs and a taxonomy of adversarial attacks tailored to each modality. Next, we review key datasets and evaluation metrics used to assess the robustness of MLLMs. After that, we provide an in-depth review of attacks targeting MLLMs across different modalities. Our survey also identifies critical challenges and suggests promising future research directions.

多模态大规模语言模型(MLLMs)在人工智能领域展现出卓越的性能，通过实现文本、图像、视频、音频和语音等多种模态的集成理解，推动了跨模态信息的融合与应用。然而，其在实际应用中的部署引发了对对抗性漏洞的严重担忧，这些漏洞可能危及模型的安全性和可靠性。与单模态模型不同，MLLMs面临着由模态间相互依赖带来的独特挑战，使其易受到特定模态的威胁以及跨模态的对抗性操控。本文综述了MLLMs的对抗鲁棒性，涵盖不同模态的相关研究。我们首先介绍MLLMs的基本概况及针对每个模态的对抗攻击分类。随后，回顾用于评估MLLMs鲁棒性的关键数据集和评估指标。接着，深入分析针对不同模态的MLLMs的攻击方法。我们的调研还指出了当前面临的主要挑战，并提出了未来有潜力的研究方向。

## 1 Introduction

## 1 引言

Multimodal large language models (MLLMs) have driven transformative advancements in artificial intelligence by enabling the seamless integration of diverse data modalities [Zhang et al., 2024c]. Unlike unimodal models that are limited to processing a single input modality, MLLMs empower a broad range of applications, from image captioning and visual question answering to video summarization and audio-visual speech recognition [Sun et al., 2024]. Grounded in their ability to understand and integrate multimodal information, MLLMs enable the comprehension and generation of content across diverse data types, offering a holistic understanding that captures the intricate relationships between modalities and reflects real-world interactions [Liu et al., 2024b] [Zhao et al., 2024].

多模态大规模语言模型(MLLMs)通过实现多样数据模态的无缝整合，推动了人工智能的变革性进步[Zhang et al., 2024c]。与仅能处理单一输入模态的单模态模型不同，MLLMs赋能广泛的应用场景，从图像描述、视觉问答到视频摘要和音视频语音识别[Sun et al., 2024]。基于其理解和整合多模态信息的能力，MLLMs实现了跨多种数据类型的内容理解与生成，提供了对模态间复杂关系的整体把握，反映了真实世界中的交互特性[Liu et al., 2024b][Zhao et al., 2024]。

Despite these advances, existing research reveals that MLLMs remain vulnerable to adversarial attacks [Liu et al., 2024a]. While multimodal integration is a key strength, it simultaneously expands the attack surface, introducing new vectors for manipulation in both modality-specific and cross-modal scenarios [Qi et al., 2024]. Although various studies have explored adversarial strategies within individual modalities, no unified perspective has emerged to address the complexities of MLLMs comprehensively [Liu et al., 2024a]. Besides, adversarial threats can arise not only during inference but also in the training phase [Xu et al., 2024b]. These vulnerabilities introduce significant risks by embedding latent threats into MLLMs, which are posed by adversarial attacks and are further amplified by the growing deployment of MLLMs in high-stakes applications, including autonomous systems [Fu et al., 2024], medical diagnostics [Fan et al., 2024], and content moderation [Gong et al., 2023]. Given these multifaceted threats, the question of developing robust defense mechanisms becomes paramount. However, current defenses often lag behind the sophistication of emerging attacks, as they primarily target unimodal adversarial scenarios and fail to account for the complex dynamics of multimodal data integration.

尽管取得了这些进展，现有研究显示MLLMs仍然容易受到对抗性攻击的影响[Liu et al., 2024a]。多模态整合虽是其优势，但也扩大了攻击面，带来了模态特定和跨模态操控的新途径[Qi et al., 2024]。虽然已有多项研究探索了单一模态下的对抗策略，但尚未形成统一的视角全面应对MLLMs的复杂性[Liu et al., 2024a]。此外，对抗性威胁不仅在推理阶段存在，也可能在训练阶段出现[Xu et al., 2024b]。这些漏洞通过潜在威胁的嵌入，带来了重大风险，尤其是在高风险应用中，如自主系统[Fu et al., 2024]、医疗诊断[Fan et al., 2024]和内容审核[Gong et al., 2023]。面对这些多方面的威胁，开发鲁棒的防御机制变得尤为重要。然而，现有的防御措施往往难以跟上新兴攻击的复杂性，主要针对单模态对抗场景，未能充分考虑多模态数据整合的复杂动态。

Considering the security concerns arising from the robustness risks of MLLMs, as well as the rapid advancements in this field, there is an urgent requirement for a systematic investigation that not only informs but also guides future research. To address this necessity, we present a comprehensive survey that examines adversarial risks and defenses of MLLMs across a variety of modalities. Unlike prior studies that predominantly focus on image-text models, our survey expands the scope to encompass additional modalities and their corresponding defense strategies, thus offering a broader perspective on the adversarial robustness of MLLMs. Specifically, we categorize these approaches into four distinct modalities, covering image, video, audio, and speech. This categorization provides a comprehensive overview and an in-depth analysis of the threats and corresponding countermeasures in each domain.

鉴于MLLMs的鲁棒性风险带来的安全隐患以及该领域的快速发展，亟需一项系统性研究，不仅能提供信息，还能指导未来的研究方向。为此，我们提出一份全面的调研，分析MLLMs在多种模态下的对抗风险与防御策略。不同于以往主要关注图像-文本模型的研究，我们的调研扩展到其他模态及其对应的防御策略，提供了关于MLLMs对抗鲁棒性的更广阔视角。具体而言，我们将这些方法划分为四个不同的模态:图像、视频、音频和语音。这一分类方式为每个领域的威胁与应对措施提供了全面的概述与深入分析。

Goals of our survey. We aim to (i) summarize representative datasets and metrics used to evaluate MLLMs adversarial robustness across different modalities; (ii) develop a taxonomy of adversarial robustness in MLLMs from the perspective of input modalities, introducing attack strategies and robustness evaluation methods tailored to each modality; and (iii) identify open challenges to inspire future research and enhance the adversarial robustness of MLLMs.

我们调研的目标。我们旨在(i)总结用于评估多模态大规模语言模型(MLLMs)对抗鲁棒性的代表性数据集和指标；(ii)从输入模态的角度构建MLLMs对抗鲁棒性的分类体系，介绍针对每种模态的攻击策略和鲁棒性评估方法；以及(iii)识别尚存的挑战，以激发未来的研究并提升MLLMs的对抗鲁棒性。

Difference between our and previous surveys. As presented in Table. 1, [Chowdhury et al., 2024] focus on text-based attacks in LLMs. [Liu et al., 2024b] provide a macroscopic review of LVLM safety issues but limit their scope to vision and text modalities with preliminary taxonomy. While [Liu et al., 2024a] subsequently delivers a detailed analysis of vision-text attacks, their work neglects other modalities. Similarly, [Fan et al., 2024] narrow their analyses to image-based attacks. These reviews lack a systematic review of the adversarial robustness of MLLMs across diverse modalities, which is a crucial aspect of MLLMs. Therefore, we present a comprehensive survey and taxonomy of the adversarial robustness of MLLMs, encompassing various modalities. Our proposed taxonomy, illustrated in Fig. 1, provides a structured overview of adversarial robustness in MLLMs from a modal perspective.

我们与以往调研的区别。如表1所示，[Chowdhury等，2024]主要关注大规模语言模型(LLMs)中的文本攻击。[Liu等，2024b]对视觉-语言大模型(LVLMs)的安全问题进行了宏观综述，但范围仅限于视觉和文本模态，并提出了初步的分类体系。而[Liu等，2024a]随后对视觉-文本攻击进行了详细分析，但未涉及其他模态。同样，[Fan等，2024]的分析也局限于图像攻击。这些综述缺乏对多模态MLLMs在对抗鲁棒性方面的系统性评述，而这正是MLLMs的一个关键方面。因此，我们提出了一份涵盖多模态的MLLMs对抗鲁棒性的全面调研和分类体系。我们提出的分类体系(如图1所示)从模态角度提供了MLLMs对抗鲁棒性的结构化概览。

<table><tr><td>Paper</td><td>Attack</td><td>Defense</td><td>Modal</td></tr><tr><td>[Chowdhury et al., 2024]</td><td>✓</td><td/><td>Text</td></tr><tr><td>[Fan et al., 2024]</td><td>✓</td><td/><td>Image, Text</td></tr><tr><td>[Liu et al., 2024b]</td><td>✓</td><td>✓</td><td>Image, Text</td></tr><tr><td>[Liu et al., 2024a]</td><td>✓</td><td/><td>Image, Text</td></tr><tr><td>Ours</td><td>✓</td><td>✓</td><td>Multimodal</td></tr></table>

<table><tbody><tr><td>论文</td><td>攻击</td><td>防御</td><td>模态</td></tr><tr><td>[Chowdhury 等，2024]</td><td>✓</td><td></td><td>文本</td></tr><tr><td>[Fan 等，2024]</td><td>✓</td><td></td><td>图像，文本</td></tr><tr><td>[Liu 等，2024b]</td><td>✓</td><td>✓</td><td>图像，文本</td></tr><tr><td>[Liu 等，2024a]</td><td>✓</td><td></td><td>图像，文本</td></tr><tr><td>我们的方法</td><td>✓</td><td>✓</td><td>多模态</td></tr></tbody></table>

Table 1: Comparisons Existing Survey for Adversarial Robustness of MLLMs

表1:现有对抗鲁棒性调研比较

## 2 Preliminaries and Background

## 2 预备知识与背景

### 2.1 Overview of MLLMs

### 2.1 多模态大模型(MLLMs)概述

MLLMs integrate multiple modalities into a unified framework, enabling cross-modal reasoning for tasks like captioning, retrieval, and translation [Carlini et al., 2024]. These models leverage large language model backbones, such as GPT-based models, to process textual data, while specialized encoders extract features from other modalities[Qi et al., 2023]. MLLMs enhance their ability to understand and generate information across diverse data sources by capturing intricate interdependencies among modalities [Zhu et al., 2024]. To achieve integration, MLLMs rely on fusion modules that align and combine multimodal features, often mapping them into shared latent spaces for unified representation. This facilitates interaction and alignment between modalities, enabling cohesive understanding and generation. The ability to unify and process diverse modalities not only broadens the scope of achievable tasks but also establishes MLLMs as a crucial technology for advancing cross-modal AI applications [Rafailov et al., 2024]. 2.2 Introduction of Different Attack Methods

多模态大模型(MLLMs)将多种模态整合到统一框架中，实现跨模态推理，用于描述生成(captioning)、检索(retrieval)和翻译(translation)等任务[Carlini等，2024]。这些模型利用大型语言模型(如GPT系列)作为基础，处理文本数据，同时专用编码器提取其他模态的特征[Qi等，2023]。通过捕捉模态间复杂的相互依赖关系，MLLMs增强了理解和生成多源信息的能力[Zhu等，2024]。为了实现融合，MLLMs依赖融合模块对齐并结合多模态特征，通常将其映射到共享潜在空间中，以实现统一表示。这促进了模态间的交互与对齐，从而实现连贯的理解与生成。多模态的统一处理不仅拓宽了任务范围，也使MLLMs成为推动跨模态人工智能(AI)应用的重要技术[Rafailov等，2024]。2.2 不同攻击方法介绍

#### 2.2.1 Adversarial Attack

#### 2.2.1 对抗性攻击

Adversarial attacks on MLLMs aim to exploit their vulnerabilities by introducing imperceptible perturbations to input data, causing the model to produce incorrect or harmful outputs. These attacks pose significant threats to applications, and the primary goal of attacks is to manipulate the model's responses while remaining undetectable to human observers.

对MLLMs的对抗性攻击旨在通过引入微不可察的扰动，利用模型的漏洞，使其产生错误或有害的输出。这些攻击对应用造成重大威胁，主要目标是操控模型响应，同时保持对人类观察者的不可检测性。

Given an MLLM $M$ that takes an image $x$ and a textual prompt ${t}_{\text{in }}$ and model $M$ produces an output ${t}_{\text{out }} = M\left( {x,{t}_{\text{in }}}\right)$ .

给定一个接受图像$x$和文本提示${t}_{\text{in }}$的MLLM模型$M$，模型输出为${t}_{\text{out }} = M\left( {x,{t}_{\text{in }}}\right)$。

The objective of adversarial attack is to generate perturbed inputs ${x}^{\text{adv }}$ and ${t}^{\text{adv }}$ , satisfies that:

对抗性攻击的目标是生成扰动输入${x}^{\text{adv }}$和${t}^{\text{adv }}$，满足以下条件:

$$
M\left( {{x}^{\text{adv }},{t}_{\text{in }}^{\text{adv }}}\right)  \neq  M\left( {x,{t}_{\text{in }}}\right) , \tag{1a}
$$

$$
\text{s.t.}{\begin{Vmatrix}{x}^{\text{adv }} - x\end{Vmatrix}}_{p} \leq  \epsilon ,{\begin{Vmatrix}{t}^{\text{adv }} - {t}_{\text{in }}\end{Vmatrix}}_{p} \leq  \epsilon \text{,} \tag{1b}
$$

where $\epsilon$ is the perturbation budget, ensuring perceptibility.

其中$\epsilon$是扰动预算，确保扰动的感知性。

In adversarial image attacks, subtle perturbations are introduced to visual inputs, leading to misclassification or incorrect textual descriptions [Zhao et al., 2024]. Attacks targeting visual inputs include gradient-based methods, which iteratively perturb pixels to maximize classification errors [Schlarmann and Hein, 2023]. In contrast, diffusion-based attacks further refine visual perturbations, enhancing attack effectiveness across diverse prompts and models [Guo et al., 2024]. Text-based adversarial attacks manipulate textual inputs to mislead the model into producing incorrect outputs while maintaining syntactic plausibility [Dong et al., 2023] [Wang et al., 2024b]. Furthermore, cross-modal attacks extend this approach by jointly perturbing both visual and textual inputs. The mathematical formulation for these attacks can be expressed as follows:

在对抗性图像攻击中，细微的扰动被引入视觉输入，导致误分类或错误的文本描述[赵等，2024]。针对视觉输入的攻击包括基于梯度的方法，这些方法通过迭代扰动像素以最大化分类错误[Schlarmann和Hein，2023]。相比之下，扩散(diffusion)基础的攻击进一步细化视觉扰动，提升在不同提示和模型中的攻击效果[郭等，2024]。文本对抗攻击则操控文本输入，误导模型产生错误输出，同时保持句法合理性[董等，2023][王等，2024b]。此外，跨模态攻击通过同时扰动视觉和文本输入，扩展了攻击方式。这些攻击的数学表达式如下:

$$
\mathop{\max }\limits_{{{\delta }_{x},{\delta }_{t}}}L\left( {M\left( {x + {\delta }_{x},{t}_{\text{in }} + {\delta }_{t}}\right) ,{t}_{\text{target }}}\right) , \tag{2a}
$$

$$
\text{s.t.}{\begin{Vmatrix}{\delta }_{x}\end{Vmatrix}}_{p} \leq  {\epsilon }_{x},{\begin{Vmatrix}{\delta }_{t}\end{Vmatrix}}_{p} \leq  {\epsilon }_{t} \tag{2b}
$$

where ${\delta }_{x}$ and ${\delta }_{t}$ represent the adversarial perturbations applied to the visual and textual inputs, respectively, while ${\epsilon }_{x}$ and ${\delta }_{t}$ define the perturbation imperceptibility.

其中${\delta }_{x}$和${\delta }_{t}$分别代表施加在视觉和文本输入上的对抗扰动，而${\epsilon }_{x}$和${\delta }_{t}$定义了扰动的不可感知性。

#### 2.2.2 Jailbreak Attacks

#### 2.2.2 越狱(Jailbreak)攻击

Jailbreak attacks aim to circumvent safety mechanisms by exploiting vulnerabilities in both textual and visual inputs, leading to the generation of harmful content. Attackers use Image Jailbreaking Prompts and Perturbed Jailbreaking Prompts to craft adversarial examples that bypass security constraints across multiple prompts and models [Niu et al., 2024] [Wang et al., 2024a]. Besides, Infectious Jailbreak attacks spread malicious inputs rapidly through agent interactions, causing large-scale security breaches [Gu et al., 2024].

越狱攻击旨在绕过安全机制，利用文本和视觉输入中的漏洞，生成有害内容。攻击者使用图像越狱提示(Image Jailbreaking Prompts)和扰动越狱提示(Perturbed Jailbreaking Prompts)来制作对抗样本，突破多种提示和模型的安全限制[牛等，2024][王等，2024a]。此外，传染性越狱(Infectious Jailbreak)通过代理交互快速传播恶意输入，造成大规模安全漏洞[顾等，2024]。

#### 2.2.3 Data Integrity Attack

#### 2.2.3 数据完整性攻击

Data integrity attacks aim to compromise reliability and trustworthiness by injecting malicious or manipulated data, ultimately leading to incorrect, biased, or even harmful outputs [Xu et al., 2024b]. These attacks can occur during both training and inference phases, with methods such as data poisoning, where adversaries introduce carefully crafted corrupted examples into the training set to influence the model's behavior and degrade its performance over time [Liang et al., 2024a]. Another prevalent method is backdoor attacks, which embed hidden triggers within the data that remain dormant under normal conditions but activate malicious behaviors when specific inputs or prompts are provided [Lu et al., 2024] [Ni et al., 2024].

数据完整性攻击旨在通过注入恶意或操控的数据，破坏模型的可靠性和可信度，导致输出错误、偏差甚至有害[许等，2024b]。这些攻击可以在训练和推理阶段发生，常用方法包括数据中毒(data poisoning)，即攻击者在训练集中引入精心设计的篡改样本，以影响模型行为并逐步降低性能[梁等，2024a]。另一种常见方法是后门攻击(backdoor attack)，在数据中嵌入隐藏触发器(trigger)，在正常条件下保持隐藏，但在特定输入或提示下激活恶意行为[卢等，2024][倪等，2024]。

### 2.3 Dataset

### 2.3 数据集

Various datasets across different modalities are established to evaluate the performance of MLLMs. For image-based MLLMs, commonly used datasets include MS-COCO for image captioning [Lin et al., 2014], Visual7W for visual question answering, and ScienceQA for multimodal science reasoning [Lu et al., 2022]. Additionally, benchmarks such as SafetyBench and MM-SafetyBench assess model robustness against adversarial inputs and safety risks [Zhang et al., 2023]. In the video domain, datasets like ActivityNet-200 [Caba Heilbron et al., 2015] and MSVD-QA [Xu et al., 2017] focus on evaluating models' ability to capture temporal coherence and event alignment, which are critical for understanding dynamic visual content. For audio-based MLLMs, LibriSpeech [Panayotov et al., 2015] is the benchmark for speech recognition and speaker verification tasks, while LlamaPartialSpoof [Luong et al., 2024] is used to evaluate robustness against spoofing attacks in speech-based applications. The details of datasets are shown in Table 2.

为了评估多模态大语言模型(MLLMs)的性能，建立了各种不同模态的数据集。对于基于图像的MLLMs，常用的数据集包括用于图像描述的MS-COCO(Microsoft COCO)[Lin等，2014]、用于视觉问答的Visual7W，以及用于多模态科学推理的ScienceQA [Lu等，2022]。此外，SafetyBench和MM-SafetyBench等基准测试评估模型在面对对抗性输入和安全风险时的鲁棒性 [Zhang等，2023]。在视频领域，ActivityNet-200 [Caba Heilbron等，2015]和MSVD-QA [Xu等，2017]等数据集侧重于评估模型捕捉时间连续性和事件对齐的能力，这对于理解动态视觉内容至关重要。对于基于音频的MLLMs，LibriSpeech [Panayotov等，2015]是语音识别和说话人验证任务的基准，而LlamaPartialSpoof [Luong等，2024]则用于评估语音应用中对抗欺骗攻击的鲁棒性。数据集的详细信息见表2。

<table><tr><td>Dataset</td><td>I</td><td>T</td><td>V</td><td>A</td><td>S</td></tr><tr><td>MS-COCO [Lin et al., 2014]</td><td>✓</td><td/><td/><td/><td/></tr><tr><td>Flickr30K [Plummer et al., 2015]</td><td>✓</td><td>✓</td><td/><td/><td/></tr><tr><td>VizWiz [Chen et al., 2022]</td><td>✓</td><td>✓</td><td/><td/><td/></tr><tr><td>VQA-v2 [Goyal et al., 2017]</td><td>✓</td><td>✓</td><td/><td/><td/></tr><tr><td>A-OKVQA [Marino et al., 2019]</td><td>✓</td><td>✓</td><td/><td/><td/></tr><tr><td>ScienceQA [Lu et al., 2022]</td><td>✓</td><td>✓</td><td/><td/><td/></tr><tr><td>ActivityNet [Caba Heilbron et al., 2015]</td><td/><td>✓</td><td>✓</td><td/><td/></tr><tr><td>MSVD-QA [Xu et al., 2017]</td><td/><td>✓</td><td>✓</td><td/><td/></tr><tr><td>VideoQA [Xiao et al., 2024]</td><td/><td>✓</td><td>✓</td><td/><td/></tr><tr><td>EditVid-QA [Xu et al., 2024a]</td><td/><td>✓</td><td>✓</td><td/><td/></tr><tr><td>AV-Deepfake1M [Cai et al., 2024]</td><td/><td/><td>✓</td><td>✓</td><td/></tr><tr><td>LlamaPartialSpoof [Luong et al., 2024]</td><td/><td/><td/><td/><td>✓</td></tr></table>

<table><tbody><tr><td>数据集</td><td>I</td><td>T</td><td>V</td><td>A</td><td>S</td></tr><tr><td>MS-COCO(微软微软共同创造的图像描述数据集)[Lin 等，2014]</td><td>✓</td><td></td><td></td><td></td><td></td></tr><tr><td>Flickr30K(Flickr图片集)[Plummer 等，2015]</td><td>✓</td><td>✓</td><td></td><td></td><td></td></tr><tr><td>VizWiz(视觉问答数据集)[Chen 等，2022]</td><td>✓</td><td>✓</td><td></td><td></td><td></td></tr><tr><td>VQA-v2(视觉问答第二版)[Goyal 等，2017]</td><td>✓</td><td>✓</td><td></td><td></td><td></td></tr><tr><td>A-OKVQA(开放知识视觉问答)[Marino 等，2019]</td><td>✓</td><td>✓</td><td></td><td></td><td></td></tr><tr><td>ScienceQA(科学问答数据集)[Lu 等，2022]</td><td>✓</td><td>✓</td><td></td><td></td><td></td></tr><tr><td>ActivityNet(活动网络数据集)[Caba Heilbron 等，2015]</td><td></td><td>✓</td><td>✓</td><td></td><td></td></tr><tr><td>MSVD-QA(微软视频描述问答)[Xu 等，2017]</td><td></td><td>✓</td><td>✓</td><td></td><td></td></tr><tr><td>VideoQA(视频问答)[Xiao 等，2024]</td><td></td><td>✓</td><td>✓</td><td></td><td></td></tr><tr><td>EditVid-QA(编辑视频问答)[Xu 等，2024a]</td><td></td><td>✓</td><td>✓</td><td></td><td></td></tr><tr><td>AV-Deepfake1M(深度伪造视频数据集)[Cai 等，2024]</td><td></td><td></td><td>✓</td><td>✓</td><td></td></tr><tr><td>LlamaPartialSpoof(Llama部分伪造检测)[Luong 等，2024]</td><td></td><td></td><td></td><td></td><td>✓</td></tr></tbody></table>

Table 2: Dataset Summary. I, T, V, A, and S represent image, text, video, audio, and speech modalities, respectively.

表2:数据集总结。I、T、V、A 和 S 分别代表图像、文本、视频、音频和语音模态。

### 2.4 Adversarial Risk of MLM

### 2.4 MLM的对抗风险

Despite significant advancements in both open- and closed-source MLLMs, ensuring resilience to adversarial perturbations and maintaining safety across modalities remains an open research challenge [Zhao et al., 2024]. This challenge is particularly pronounced in multimodal information, where attacks can target a single modality (e.g., noise in images or manipulations in text) or disrupt cross-modal alignments [Liu et al., 2025], [Qi et al., 2024]. Moreover, unlike conventional adversarial attacks that typically rely on gradient-based methods to generate adversarial examples, attacks on MLLMs are more diverse, and there is currently no consensus on the definitions of adversarial robustness or safety [Cui et al., 2024]. For example, adversarial prompt injection can be used to subtly manipulate the model's behavior, while cross-modal adversarial attacks introduce perturbations across multiple modalities-either sequentially or jointly-to compromise the outputs integrity of the models [Wang et al., 2024b], [Yang et al., 2024].

尽管在开源和闭源多模态语言模型(MLLMs)方面取得了显著进展，确保其对对抗扰动的韧性以及在不同模态中的安全性仍然是一个未解决的研究难题[Zhao et al., 2024]。这一挑战在多模态信息中尤为突出，攻击可以针对单一模态(例如图像中的噪声或文本中的操控)或破坏跨模态对齐[Li et al., 2025]，[Qi et al., 2024]。此外，与传统的依赖梯度方法生成对抗样本的对抗攻击不同，MLLMs的攻击方式更加多样，目前尚无关于对抗鲁棒性或安全性的统一定义[ Cui et al., 2024]。例如，对抗性提示注入可以微妙地操控模型行为，而跨模态对抗攻击则通过在多个模态中逐步或联合引入扰动，以破坏模型输出的完整性[Wang et al., 2024b]，[Yang et al., 2024]。

We summarize the existing techniques from the perspective of modalities in Fig. 1, categorizing them into attack and defense methods. Our analysis reveals significant imbalances in terms of the number of studies and the diversity of approaches for attacks and defenses. We hope that our work will inspire and contribute to future efforts aimed at enhancing the security of MLLMs.

我们从模态的角度总结了现有技术，如图1所示，将其分为攻击方法和防御方法。我们的分析显示，在研究数量和方法多样性方面，攻击与防御之间存在显著的不平衡。我们希望我们的工作能激发并推动未来在增强MLLMs安全性方面的努力。

## 3 Attack on Image-MLLMs

## 3 图像模态下的MLLM攻击

This section provides a taxonomy and overview of the methods employed to exploit the vulnerabilities of MLLMs within the image modality, specifically focusing on adversarial attacks, jailbreak attacks, and data integrity attacks.

本节提供了利用MLLM在图像模态中脆弱性的分类体系和方法概述，重点包括对抗攻击、越狱攻击和数据完整性攻击。

### 3.1 Adversarial Attack

### 3.1 对抗攻击

Adversarial attacks pose robustness risks to MLLMs by manipulating inputs to induce incorrect outputs. Following, we categorize the scenarios based on the level of access to model information into two types: full access to model details and restricted access to partial information.

对抗攻击通过操控输入，给MLLM带来鲁棒性风险，诱导模型输出错误。接下来，我们根据对模型信息的访问程度，将场景分为两类:完全访问模型信息和有限访问部分信息。

#### 3.1.1 Full Access Situation

#### 3.1.1 完全访问情形

By exploiting the vulnerabilities of visual encoders, several works have extended traditional adversarial attacks to MLLMs. Schlarmann et al. conduct both untargeted and targeted attacks on MLLMs by introducing carefully crafted adversarial perturbations. Results demonstrate that subtle perturbations on visual inputs are shown to induce misclassifications or misleading outputs, which highlights the requirement for effective defensive strategies to address significant performance degradation caused by adversarial perturbations [Schlarmann and Hein, 2023]. Cui et al. assess adversarial robustness in multiple vision-related tasks, revealing that adversarial perturbations in the visual domain significantly degrade model performance on image classification and captioning tasks. However, for visual question answering, the models demonstrate greater adversarial robustness, with only slight performance degradation observed. Building on these findings, they propose contextual enhancements and task decomposition as promising strategies to mitigate these vulnerabilities [Cui et al., 2024].

通过利用视觉编码器的脆弱性，已有多项工作将传统的对抗攻击扩展到MLLMs。Schlarmann等人对MLLMs进行了无目标和有目标的对抗攻击，采用精心设计的对抗扰动。结果显示，细微的视觉输入扰动可以引起误分类或误导性输出，突显了需要有效的防御策略以应对对抗扰动带来的性能显著下降[Schlarmann 和 Hein, 2023]。Cui等人评估了多项视觉相关任务中的对抗鲁棒性，发现视觉领域的对抗扰动会显著降低模型在图像分类和描述任务中的性能，但在视觉问答任务中，模型表现出更强的对抗鲁棒性，性能下降较小。基于这些发现，他们提出了情境增强和任务分解等策略，以缓解这些脆弱性[Cui et al., 2024]。

Another concept, image hijacking, manipulates model behavior through subtle visual perturbations. This method excels in scenarios such as misinformation dissemination and jailbreak attacks, outperforming traditional adversarial techniques and exposing critical risks for content moderation applications [Bailey et al., 2023]. The Verbose Images is presented in [Gao et al., ], which leverages imperceptible perturbations to induce excessively verbose outputs in MLLMs, significantly increasing energy consumption and latency during inference. This stealthy and transferable attack undermines computational efficiency, posing substantial risks to the availability of VLM-based systems [Gao et al., ].

另一种概念是图像劫持，通过微妙的视觉扰动操控模型行为。这种方法在虚假信息传播和越狱攻击等场景中表现出色，优于传统的对抗技术，暴露了内容审核应用中的关键风险[Bailey et al., 2023]。Gao等人在[Gao et al., ]中提出了“冗长图像”技术，利用难以察觉的扰动在MLLM中引发过度冗长的输出，显著增加推理过程中的能耗和延迟。这种隐秘且可转移的攻击削弱了计算效率，对基于视觉语言模型(VLM)的系统的可用性构成了重大威胁[Gao et al., ]。

Adversarial vulnerabilities also extend to reasoning mechanisms within MLLMs. Wang et al. investigate the impact of Chain-of-Thought (CoT) reasoning on the adversarial robustness of MLLMs, revealing that while CoT improves robustness against existing attack methods through multi-step reasoning, the improvement is limited. Accordingly, the Stop-Reasoning Attack is proposed, targeting CoT reasoning frameworks by prematurely terminating reasoning processes or introducing errors. By bypassing CoT's intermediate reasoning steps [Wang et al., 2024b].

对抗漏洞还影响MLLM中的推理机制。Wang等人研究了链式推理(Chain-of-Thought, CoT)对MLLM对抗鲁棒性的影响，发现虽然CoT通过多步推理提升了对现有攻击方法的鲁棒性，但提升有限。因此，提出了停止推理(Stop-Reasoning)攻击，旨在通过提前终止推理过程或引入错误，绕过CoT的中间推理步骤[Wang et al., 2024b]。

![bo_d1lvp577aajc73dif0hg_3_141_142_1537_1115_0.jpg](images/bo_d1lvp577aajc73dif0hg_3_141_142_1537_1115_0.jpg)

Figure 1: A Taxonomy of Adversarial Robustness of MLLMs.

图1:MLLM对抗鲁棒性分类体系。

#### 3.1.2 Restricted Access Situation

#### 3.1.2 限制访问情形

While full access to model details allows for a comprehensive analysis of MLLM vulnerabilities to adversarial attacks, real-world commercial MLLMs often restrict access to model information. To examine vulnerabilities under more practical conditions, adversarial attacks in limited-information settings exploit this restricted visibility to execute manipulations. These methods typically operate under black- or gray-box assumptions, relying on external queries or surrogate models to generate adversarial inputs.

虽然完全访问模型信息可以对MLLM的对抗脆弱性进行全面分析，但在实际商业环境中，MLLM通常限制模型信息的访问。为了在更实际的条件下研究脆弱性，有限信息设置中的对抗攻击利用这种受限的可见性进行操控。这些方法通常基于黑盒或灰盒假设，依赖外部查询或代理模型生成对抗样本。

To achieve black-box attacks, transfer-based approaches evaluate adversarial robustness under black-box settings. By utilizing surrogate models such as CLIP and BLIP, these methods enable the generation of adversarial examples that effectively transfer across various vision-language models, including MiniGPT-4 and BLIP-2 [Zhao et al., 2024]. Leveraging diffusion models to generate targeted and highly transferable adversarial examples for MLLMs provides a comprehensive assessment of potential security vulnerabilities before deployment. AdvDiffVLM enhances transfer-based attacks by employing ensemble gradient estimation and mask generation techniques to produce visually natural adversarial examples with dispersed semantics, thereby improving transferability [Guo et al., 2024].

为了实现黑盒攻击，迁移方法在黑盒环境下评估对抗鲁棒性。通过利用如CLIP(对比语言-图像预训练模型)和BLIP(图像-语言预训练模型)等替代模型，这些方法能够生成在各种视觉-语言模型(包括MiniGPT-4和BLIP-2 [赵等，2024])中有效迁移的对抗样本。利用扩散模型为多模态大模型(MLLMs)生成具有目标性和高度迁移性的对抗样本，为部署前的潜在安全漏洞提供了全面评估。AdvDiffVLM通过采用集成梯度估计和掩码生成技术，增强迁移基础攻击，生成视觉自然、语义分散的对抗样本，从而提升迁移能力 [郭等，2024]。

In addition to conventional transfer-based attacks for achieving black-box settings, some studies have shifted focus toward evaluating the security of MLLMs within black-box scenarios. Adopting the Unicorn safety evaluation framework provides a systematic evaluation of the vulnerabilities of MLLMs under out-of-distribution and adversarial conditions. This benchmark tests MLLMs against attack scenarios and unconventional inputs, revealing robustness and safety protocol gaps. The findings suggest that visual language training pipelines often weaken original safety measures, increasing risks during practical use [Tu et al., 2024]. Studies on Google Bard reveal that targeted adversarial image and text attacks can bypass safety mechanisms, including face privacy detection and toxic content filters, leading to harmful outputs. The results present the critical need for more robust safety evaluations and defense strategies for multimodal systems [Dong et al., 2023]. The agent robustness evaluation framework models autonomous agents powered by MLLMs as interconnected components, systematically analyzing their vulnerabilities to adversarial inputs. Corresponding results identify critical components, such as evaluators and policy models, as particularly susceptible, with attacks achieving high success rates even with minimal perturbations [Wu et al., 2024]. Lastly, the B-AVIBench framework addresses the vulnerabilities of MLLMs to black-box adversarial visual instructions, spanning diverse attack methods across image, text, and biased content modalities. It systematically reveals significant security gaps, including susceptibility to multimodal biases and combined modality attacks, emphasizing the need for robust and fair defense mechanisms. Besides, this framework provides a comprehensive evaluation tool for open-source and proprietary models [Zhang et al., 2024b].

除了传统的迁移基础攻击以实现黑盒环境外，一些研究开始关注在黑盒场景下评估多模态大模型(MLLMs)的安全性。采用Unicorn安全评估框架，系统性地评估MLLMs在分布外和对抗性条件下的漏洞。该基准测试MLLMs在攻击场景和非常规输入下的鲁棒性，揭示安全性和安全协议的不足。研究发现，视觉语言训练流程常削弱原有的安全措施，增加实际使用中的风险 [涂等，2024]。对Google Bard的研究显示，针对性对抗性图像和文本攻击可以绕过安全机制，包括面部隐私检测和有害内容过滤，导致有害输出。这突显了对多模态系统进行更强健安全评估和防御策略的迫切需求 [董等，2023]。代理鲁棒性评估框架将由MLLMs驱动的自主代理建模为相互连接的组件，系统分析其对对抗性输入的脆弱性。相关结果识别出关键组件，如评估者和策略模型，特别易受攻击，即使微小扰动也能实现高成功率 [吴等，2024]。最后，B-AVIBench框架针对MLLMs在黑盒对抗视觉指令方面的漏洞，涵盖图像、文本和偏见内容模态的多种攻击方法，系统揭示了重大安全漏洞，包括对多模态偏见和多模态联合攻击的易感性，强调了构建稳健和公平的防御机制的必要性。此外，该框架还为开源和专有模型提供了全面的评估工具 [张等，2024b]。

### 3.2 Jailbreak Attacks

### 3.2 越狱攻击

Jailbreak attacks bypass the safety mechanisms or constraints implemented in models by exploiting underlying system vulnerabilities. These attacks manipulate MLLMs to generate harmful or unauthorized outputs. In this section, we review the advancements in jailbreak attacks in MLLMs, with the first part focusing on general jailbreak attacks and the second examining prompt injection techniques.

越狱攻击通过利用模型底层系统的漏洞，绕过安全机制或限制，操控多模态大模型(MLLMs)生成有害或未授权的输出。在本节中，我们回顾MLLMs中越狱攻击的最新进展，第一部分关注一般越狱攻击，第二部分探讨提示注入技术。

#### 3.2.1 Cross-Modal Inconsistency Attacks

#### 3.2.1 跨模态不一致性攻击

Cross-modal attacks exploit alignment gaps between modalities. As a representative work, [Carlini et al., 2024] craft adversarial prompts to manipulate attention mechanisms, bypassing safety constraints through multimodal perturbations. These adversarial inputs manipulate the model's behavior, enabling it to ignore safety constraints and generate harmful content. [Niu et al., 2024] further reveal that contradictory inputs across modalities (e.g., conflicting images and text) induce model misinterpretations, enabling jailbreaks transferable across MiniGPT-v2 and LLaVA. Similarly, by exploiting cross-modal inconsistencies, a variant termed "infectious jailbreak" allows compromised agents to propagate harmful behaviors across interconnected systems, threatening large-scale deployments [Gu et al., 2024]. Additionally, [Tao et al., 2024] design adversarial examples that replace textual captions with malicious prompts, exploiting fusion layer vulnerabilities to generate harmful responses.

跨模态攻击利用不同模态之间的对齐差异。作为代表性工作，[Carlini等，2024]设计对抗性提示，通过多模态扰动操控注意力机制，绕过安全限制。这些对抗输入操控模型行为，使其忽略安全限制，生成有害内容。[牛等，2024]进一步揭示，跨模态的矛盾输入(如冲突的图像和文本)会引起模型误解，从而实现可迁移的越狱攻击，影响MiniGPT-v2和LLaVA。类似地，通过利用跨模态不一致性，一种称为“感染性越狱”的变体允许被攻破的代理在互联系统中传播有害行为，威胁大规模部署 [顾等，2024]。此外，[陶等，2024]设计了将文本描述替换为恶意提示的对抗样本，利用融合层漏洞生成有害响应。

#### 3.2.2 Prompt Manipulation

#### 3.2.2 提示操控

[Wang et al., 2024a] propose a white-box strategy using a "Universal Master Key", which combines adversarial image prefixes and text suffixes to bypass alignment defenses with high success rates. Conversely, [Wu et al., 2023] demonstrate that optimizing system prompts can enhance attack efficacy across languages, yet properly designed prompts also mitigate risks. Visual prompt injection further amplifies threats. [Gong et al., 2023] embed harmful instructions into typographic images, breaking safety filters of GPT-4V.

[王等，2024a]提出一种白盒策略，使用“通用主钥”结合对抗性图像前缀和文本后缀，以高成功率绕过对齐防御。相反，[吴等，2023]展示优化系统提示可以提升跨语言攻击效果，但合理设计的提示也能减轻风险。视觉提示注入进一步增强威胁。[龚等，2023]将有害指令嵌入排版图像，突破GPT-4V的安全过滤。

#### 3.2.3 Jailbreak in Training-Phase

#### 3.2.3 训练阶段的越狱

[Li et al., 2025] investigate how the presence of adversarial examples in training data can create vulnerabilities in MLLMs. The results argue that adversarial examples during training can expose gaps in the model's ability to handle unexpected inputs, thereby facilitating successful jailbreak attempts. Similarly, Qi et al. delve deeper into visual prompt injection using adversarial examples, demonstrating subtle manipulations of visual inputs can bypass safety mechanisms in MLLMs [Qi et al., 2024]. Their findings reveal that visual prompts can effectively compel models to produce unsafe outputs, such as hate speech and violent instructions.

[李等，2025]研究训练数据中存在的对抗样本如何导致MLLMs的漏洞。结果表明，训练中的对抗样本暴露模型处理意外输入的不足，从而促成越狱成功。同样，齐等深入研究了利用对抗样本进行视觉提示注入，展示细微操控视觉输入可以绕过MLLMs的安全机制 [齐等，2024]。他们的发现显示，视觉提示能有效促使模型输出不安全内容，如仇恨言论和暴力指令。

### 3.3 Data Integrity Attacks

### 3.3 数据完整性攻击

Data integrity attacks deliberately manipulate data to compromise the training or operation of MLLMs. These attacks significantly impact the security and reliability of MLLMs, particularly in scenarios involving privacy-sensitive or high-stakes tasks. Data integrity attacks can be broadly classified into backdoor attacks and poisoning attacks.

数据完整性攻击故意操纵数据以破坏MLLM(多模态大语言模型)的训练或运行。这些攻击对MLLM的安全性和可靠性产生重大影响，尤其是在涉及隐私敏感或高风险任务的场景中。数据完整性攻击可以大致分为后门攻击和中毒攻击。

An early exploration of backdoor attacks for MLLMs is AnyDoor, which introduces a test-time backdoor attack against MLLMs, which decouples the backdoor setup by using universal adversarial perturbations applied to visual inputs, while activation is triggered by specific textual inputs. This separation enhances the attack's stealth and effectiveness. AnyDoor demonstrates remarkable adaptability, achieving a ${98.5}\%$ attack success rate across multiple MLLMs, even under challenging conditions such as noise interference and cropping [Lu et al., 2024]. After that, VL-Trojan extends backdoor attack capabilities by integrating visual and textual triggers during instruction tuning. Leveraging feature isolation and clustering, this technique achieves over ${99}\%$ success rates with only poisoning ${0.5}\%$ of examples. Its consistent effectiveness across models and tasks demonstrates the elevated risk of backdoor vulnerabilities in instruction-tuned MLLMs [Liang et al., 2024a]. BadVLM-Driver, the first backdoor attack targeting MLLMs in autonomous driving, explores physical backdoor attacks in real-world environments. By leveraging natural triggers, such as red balloons, BadVLMDriver can induce harmful behaviors, such as sudden acceleration, with a high attack success rate. This approach offers significant flexibility in selecting both the trigger and the resulting malicious behavior, thereby enhancing the stealth and practicality of the attack in diverse real-world scenarios [Ni et al., 2024]. Further studies reveal the cross-domain robustness of backdoor attacks, demonstrating that triggers embedded during instruction tuning can sustain success rates of over ${97}\%$ , even when subjected to domain shifts. This proposes the requirement for effective detection and mitigation strategies, thereby emphasizing the escalating security risks posed by the increasing generalizability of backdoors in MLLMs [Xu et al., 2024b].

对MLLM后门攻击的早期探索之一是AnyDoor，它引入了一种针对MLLM的测试时后门攻击，通过使用通用对抗扰动(universal adversarial perturbations)应用于视觉输入，从而解耦后门设置，而激活由特定文本输入触发。这种分离增强了攻击的隐蔽性和有效性。AnyDoor表现出极强的适应性，在多种MLLM上实现了${98.5}\%$的攻击成功率，即使在噪声干扰和裁剪等困难条件下[Lu等，2024]。随后，VL-Trojan通过在指令调优(instruction tuning)过程中结合视觉和文本触发器，扩展了后门攻击能力。利用特征隔离和聚类技术，该方法仅通过中毒少量样本(poisoning)即可实现超过${99}\%$的成功率。其在不同模型和任务中的持续有效性，显示了指令调优的MLLM中后门漏洞的潜在风险[Liang等，2024a]。BadVLM-Driver是首个针对自动驾驶中MLLM的后门攻击，探索了在真实环境中的物理后门攻击。通过利用自然触发器(如红色气球)，BadVLMDriver可以引发有害行为，如突然加速，且成功率很高。这种方法在选择触发器和恶意行为方面具有极大灵活性，从而增强了攻击的隐蔽性和在多样化实际场景中的实用性[Ni等，2024]。进一步研究显示，后门攻击具有跨域鲁棒性，即在指令调优过程中嵌入的触发器，即使在域迁移(domain shift)情况下，也能保持超过${97}\%$的成功率。这提出了有效检测和缓解策略的需求，强调了MLLM中后门日益普遍带来的安全风险[Xu等，2024b]。

For data poisoning, Shadowcast exemplifies the sophistication of such attacks. It utilizes clean-label strategies to subtly alter image-text pairs, thereby manipulating model outputs without introducing obvious disruptions. Experimental results demonstrate Shadowcast's effectiveness, achieving attack success rates exceeding ${80}\%$ with fewer than 50 poisoned examples while maintaining robustness across various data augmentations [Liang et al., 2024b].

在数据中毒方面，Shadowcast展现了此类攻击的复杂性。它采用干净标签(clean-label)策略，巧妙地修改图像-文本对，操控模型输出而不引起明显干扰。实验结果显示，Shadowcast在少于50个中毒样本的情况下，成功率超过${80}\%$，并在各种数据增强条件下保持鲁棒性[Liang等，2024b]。

## 4 Attack on Video-MLLMs

## 4 视频-多模态大语言模型(Video-MLLMs)攻击

Video-MLLMs integrate temporal and cross-modal reasoning for tasks like video QA and autonomous driving, yet their dynamic nature amplifies adversarial risks [Fu et al., 2024]. Adversarial strategies against video-MLLMs often target their temporal reasoning and cross-modal alignment [Li et al., 2024] [Xu et al., 2024a]. To address these challenges, recent benchmarks evaluate robustness across multiple safety dimensions [Miao et al., 2024]. Below, we provide a review of three aspects.

视频-MLLMs结合了时间和跨模态推理，用于视频问答(video QA)和自动驾驶等任务，但其动态特性增加了对抗风险[Fu等，2024]。针对视频-MLLMs的对抗策略通常针对其时间推理和跨模态对齐[Li等，2024][Xu等，2024a]。为应对这些挑战，近期基准测试评估了多维度的鲁棒性[Miao等，2024]。以下，我们将从三个方面进行综述。

### 4.1 Temporal-Coherence Attack

### 4.1 时间一致性攻击

[Li et al., 2024] propose FMM-Attack, injecting optical flow-guided perturbations into keyframes to disrupt temporal dynamics. FMM-Attack degrades output accuracy even with sparse frame modifications, and joint attacks on video and language modalities are better than single-modality situations. Cross-modal threats further exploit alignment gaps: [Xu et al., 2024a] demonstrate that edited videos (e.g., social media deepfakes) mislead models by synchronizing deceptive visual and textual cues.

[Li等，2024]提出FMM-攻击，在关键帧中注入光流引导的扰动，以破坏时间动态。即使只对少量帧进行修改，FMM-攻击也会降低输出的准确性。对视频和语言模态的联合攻击优于单一模态攻击。跨模态威胁进一步利用对齐差距:[Xu等，2024a]展示了编辑过的视频(如社交媒体深度伪造视频)通过同步虚假视觉和文本线索误导模型。

### 4.2 Scenario-Driven Attacks

### 4.2 场景驱动攻击

MLLMs-based autonomous driving scenarios also face threats from adversarial attacks. [Fu et al., 2024] design PG-Attack, which combines precision-masked perturbations targeting critical regions such as vehicle movement, pedestrian activity, and traffic light changes with deceptive text patches to mislead model reasoning. Evaluated on CARLA-generated data, PG-Attack maintains perceptual stealth while achieving high attack success rates. Similarly, [Zhang et al., 2024d] propose ADvLM, which optimizes perturbations on key frames using semantic-invariant prompts, ensuring robustness against viewpoint and lighting changes. To enable transferable attacks against Vision-MLLMs in autonomous driving, [Chung et al., 2024] embed misleading typographic text into video frames such as altered traffic signs.

基于MLLM的自动驾驶场景也面临对抗性攻击的威胁。[Fu等，2024]设计了PG-攻击，将针对关键区域(如车辆运动、行人活动和交通信号变化)的精确掩码扰动与虚假文本片段结合，误导模型推理。在CARLA生成的数据上评估，PG-攻击保持感知隐蔽性，同时实现高成功率。同样，[Zhang等，2024d]提出了ADvLM，通过在关键帧上使用语义不变的提示优化扰动，确保对视角和光照变化的鲁棒性。为了实现对自动驾驶视觉-MLLM的可转移攻击，[Chung等，2024]在视频帧中嵌入误导性排版文本，例如篡改交通标志。

### 4.3 Benchmarks and Evaluation

### 4.3 基准测试与评估

Additionally, existing efforts aim to evaluate the robustness of video-MLLMs from various perspectives. In text-to-video generative models, T2VSafetyBench [Miao et al., 2024] assesses generative models against explicit content and misinformation, revealing higher risks in advanced models due to enhanced semantic understanding. Benchmark studies EditVid-QA [Xu et al., 2024a] and AV-Deepfake1M [Cai et al., 2024] benchmark performance on edited videos and synthetic deepfakes, respectively. Empirical studies [Xiao et al., 2024] further expose deficiencies in temporal grounding and adversarial robustness.

此外，现有的研究工作旨在从多个角度评估视频-多模态大语言模型(video-MLLMs)的鲁棒性。在文本到视频生成模型中，T2VSafetyBench [Miao等，2024] 评估生成模型在处理明确内容和虚假信息方面的表现，揭示了由于语义理解增强，先进模型面临的更高风险。基准研究如EditVid-QA [Xu等，2024a] 和 AV-Deepfake1M [Cai等，2024] 分别对编辑视频和合成深伪(deepfake)进行性能评估。实证研究 [Xiao等，2024] 进一步揭示了时间定位和对抗鲁棒性方面的不足。

## 5 Attack on Audio-MLLMs

## 5 音频-多模态大语言模型(Audio-MLLMs)攻击

BadRobot exposes vulnerabilities in embodied MLLM that rely on audio inputs for interaction. Specifically, BadRobot analyzes three attacks, covering contextual jailbreaks, where carefully crafted audio inputs bypass restrictions to trigger harmful actions; safety misalignments, which exploit discrepancies between audio instructions and model responses; and conceptual deception, which breaks ethical constraints through subtasks embedded in speech instructions. Corresponding results reveal that even advanced systems like GPT-4-turbo exhibit weaknesses in these scenarios [Zhang et al., 2024a]. The potential for indirect instruction injection through adversarial audio perturbations further underscores the sensitivity of speech modalities. These attacks leverage carefully crafted audio cues to influence the model's output or alter its dialog flow. Experiments demonstrate over ${90}\%$ attack success rates in LLaVA [Bagdasaryan et al., 2023]. The Chat-Audio Attacks benchmark provides a structured framework for evaluating the robustness of MLLMs against diverse audio adversarial scenarios, including content modifications, emotional tone shifts. and implicit noise. Results reveal vulnerabilities that adversarial audio disrupts the semantic and contextual coherence of the models, even under controlled conditions [Yang et al., 2024]. In response to these challenges, Trust-NavGPT emerges to model audio uncertainties to improve the robustness of audio-guided navigation tasks. By integrating tonal ambiguities and pauses into its decision-making process, TrustNavGPT demonstrates a pathway toward mitigating adversarial risks in dynamic, real-world environments [Sun et al., 2024]. Finally, the AV-Deepfake 1M dataset emphasizes the importance of adversarial robustness in detecting temporally aligned manipulations across audio-visual modalities [Cai et al., 2024]. Experiments on this dataset show significant performance drops in existing frameworks, pushing for advancements in training methodologies that consider the temporal and multimodal intricacies of speech-based inputs.

BadRobot 揭示了依赖音频输入进行交互的实体化多模态大语言模型(MLLMs)存在的漏洞。具体而言，BadRobot 分析了三类攻击，包括:情境越狱(contextual jailbreaks)，通过精心设计的音频输入绕过限制以触发有害行为；安全偏差(safety misalignments)，利用音频指令与模型响应之间的差异；以及概念欺骗(conceptual deception)，通过嵌入在语音指令中的子任务打破伦理约束。相关结果显示，即使是像GPT-4-turbo这样先进的系统，在这些场景下也存在弱点 [Zhang等，2024a]。通过对抗性音频扰动进行间接指令注入的潜力，进一步凸显了语音模态的敏感性。这些攻击利用精心设计的音频线索影响模型输出或改变对话流程。实验显示，在LLaVA [Bagdasaryan等，2023] 中攻击成功率超过${90}\%$。Chat-Audio攻击基准为评估多模态大语言模型在面对多样音频对抗场景(包括内容修改、情感色调变化和隐性噪声)时的鲁棒性提供了结构化框架。结果表明，对抗性音频会破坏模型的语义和上下文连贯性，即使在受控条件下也是如此 [Yang等，2024]。为应对这些挑战，Trust-NavGPT 被提出用以建模音频不确定性，从而提升音频引导导航任务的鲁棒性。通过将音调模糊性和停顿融入决策过程，TrustNavGPT 展示了在动态真实环境中减轻对抗风险的途径 [Sun等，2024]。最后，AV-Deepfake 1M 数据集强调了在检测跨音视频模态的时间对齐操控中对抗鲁棒性的重要性 [Cai等，2024]。在该数据集上的实验显示，现有框架的性能显著下降，推动了考虑语音输入的时间和多模态复杂性的训练方法的进步。

## 6 Attack on Speech-MLLMs

## 6 语音-多模态大语言模型(Speech-MLLMs)攻击

Speech data is dynamic and prone to perturbations, including adversarial noise, semantic manipulations, and spoofing attacks. As MLLMs are increasingly utilized in real-world applications, such as speech-driven question answering (QA) and audio-command systems, ensuring their robustness against adversarial threats is important.

语音数据具有动态性，容易受到扰动，包括对抗性噪声、语义操控和欺骗攻击。随着多模态大语言模型在实际应用中的广泛使用，如语音驱动的问答(QA)和音频指令系统，确保其对抗对抗性威胁的鲁棒性变得尤为重要。

### 6.1 Adversarial Speech Attacks and Exploits

### 6.1 对抗性语音攻击与利用

Recent research indicates that speech-based MLLMs are highly vulnerable to advanced adversarial techniques. For instance, SpeechGuard [Peri et al., 2024] shows that Projected Gradient Descent can trigger unsafe responses, while its Time-Domain Noise Flooding defense markedly reduces attack success rates. For Voice Jailbreak Attacks, adversaries deploy narrative-based prompts to circumvent security measures in advanced models like GPT-4o [Shen et al., 2024].

最新研究表明，基于语音的多模态大语言模型(MLLMs)对先进的对抗技术极为脆弱。例如，SpeechGuard [Peri等，2024] 表明，投影梯度下降(Projected Gradient Descent)可以触发不安全的响应，而其时域噪声泛滥(Time-Domain Noise Flooding)防御显著降低了攻击成功率。在语音越狱(Voice Jailbreak)攻击中，攻击者使用叙事性提示绕过安全措施，针对像GPT-4o [Shen等，2024] 这样先进的模型。

### 6.2 Benchmark and Evaluation

### 6.2 基准测试与评估

One benchmark evaluation in this area is the LlamaPartial-Spoof dataset, which investigates model robustness against partial and fully spoofed speech [Luong et al., 2024]. Using advanced Text-to-Speech, it generates realistic audio examples that simulate semantic-altering and splicing attacks. The study exposes significant weaknesses in detecting partial spoofs and requires diverse datasets and evaluation frameworks to bolster defenses against threats.

该领域的一个基准评估是LlamaPartial-Spoof数据集，旨在研究模型对部分和完全伪造语音的鲁棒性 [Luong等，2024]。利用先进的文本转语音(Text-to-Speech)技术，生成逼真的音频样本，模拟语义篡改和拼接攻击。研究揭示了检测部分伪造的显著弱点，并且需要多样化的数据集和评估框架，以增强对威胁的防御能力。

## 7 Defense Methods

## 7 防御方法

### 7.1 Visual Modality Defenses

### 7.1 视觉模态防御

MLLM-Protector addresses adversarial image threats via a modular framework, combining a harm detector with a response detoxifier to filter unsafe outputs without degrading performance [Pi et al., 2024]. After that, MM-SafetyBench establishes standardized safety evaluation protocols for vision-language models, leveraging typographic and diffusion-generated adversarial images to expose vulnerabilities [Liu et al., 2025]. For CoT-enhanced models, Stop-Reasoning proposes adversarial training to mitigate attacks targeting intermediate reasoning steps, improving alignment between visual and textual reasoning [Wang et al., 2024b]. In parallel, FARE introduces unsupervised adversarial fine-tuning of vision encoders to preserve clean-task performance while hardening models against imperceptible perturbations, enabling robust deployment without downstream model adaptation [Schlarmann et al., 2024].

MLLM-Protector 通过一个模块化框架应对对抗性图像威胁，结合危害检测器(harm detector)和响应净化器(response detoxifier)，过滤不安全的输出而不影响性能 [Pi等，2024]。随后，MM-SafetyBench 建立了视觉-语言模型(vision-language models)的标准安全评估协议，利用排版和扩散生成的对抗性图像揭示漏洞 [Liu等，2025]。对于增强推理(CoT)模型，Stop-Reasoning 提出对抗性训练，以缓解针对中间推理步骤的攻击，改善视觉与文本推理的对齐 [Wang等，2024b]。同时，FARE 引入了无监督的对抗性微调(adversarial fine-tuning)视觉编码器，既能保持任务性能，又能增强模型对微不可察的扰动的抵抗能力，实现无需下游模型适配的鲁棒部署 [Schlarmann等，2024]。

### 7.2 Audio and Speech Modality Defenses

### 7.2 音频与语音模态防御

SpeechGuard injects lightweight noise into audio signals to disrupt adversarial cues, improving robustness in spoken QA systems [Peri et al., 2024]. TrustNavGPT enhances robustness in audio-guided navigation by modeling semantic and tonal uncertainties, achieving a credible navigation performance when suffering adversarial attacks [Sun et al., 2024].

SpeechGuard在音频信号中注入轻量级噪声以干扰对抗性线索，提高语音问答系统(Spoken QA Systems)的鲁棒性[Peri等，2024]。TrustNavGPT通过建模语义和语调不确定性增强音频引导导航的鲁棒性，在遭受对抗性攻击时实现了可信的导航性能[Sun等，2024]。

### 7.3 Video Modality Defenses

### 7.3 视频模态防御

To enhance the robustness of video-LLMs, [Xiao et al., 2024] improves the strength of temporal reasoning, visual grounding, and adversarial resilience, ensuring that models effectively leverage visual information rather than exploiting linguistic shortcuts. Meanwhile, EditVid-QA [Xu et al., 2024a], strengthens defenses against edited and manipulated videos by introducing a diverse benchmark covering effects, memes, and social media transformations. These defenses are realized through frame-consistency learning, adaptive visual grounding, and domain-adaptive fine-tuning, ensuring models learn from real visual data instead of exploiting linguistic shortcuts.

为了增强视频大模型(Video-Large Language Models, Video-LLMs)的鲁棒性，[Xiao等，2024]提升了时间推理、视觉定位和对抗性抗扰能力，确保模型有效利用视觉信息而非依赖语言捷径。同时，EditVid-QA [Xu等，2024a]通过引入涵盖特效、表情包和社交媒体变换的多样化基准，加强了对编辑和操控视频的防御。这些防御措施通过帧一致性学习、自适应视觉定位和领域自适应微调实现，确保模型从真实视觉数据中学习，而非利用语言捷径。

## 8 Trends and Future Directions

## 8 发展趋势与未来方向

### 8.1 Comprehensive Robustness Evaluation

### 8.1 全面鲁棒性评估

Current robustness evaluation benchmarks are limited and can not be used to fully spectrum adversarial risks across modalities. Future efforts should prioritize the development of a multidimensional safety taxonomy that systematically defines safety dimensions. Additionally, there is a need to collect diverse and scalable datasets that balance volume, diversity, and adversarial realism. This includes incorporating synthetic adversarial examples (e.g., AdvDiffVLM-generated perturbations) and real-world attack scenarios (e.g., BadRobot's audio jailbreaks). To further enhance evaluation metrics, advanced LLMs should be leveraged to automate safety assessments, addressing prompt sensitivity and hallucination risks.

当前的鲁棒性评估基准有限，无法全面覆盖跨模态的对抗风险。未来应优先开发多维安全分类体系，系统定义安全维度。此外，需要收集多样且可扩展的数据集，兼顾规模、多样性和对抗真实性。这包括引入合成对抗样本(如AdvDiffVLM生成的扰动)和真实世界的攻击场景(如BadRobot的音频越狱)。为了进一步提升评估指标，应利用先进的大型语言模型(LLMs)自动化安全评估，解决提示敏感性和幻觉风险。

### 8.2 Cross-Modal and Transferable Attacks

### 8.2 跨模态与可迁移攻击

While existing attacks expose modality-specific vulnerabilities, several gaps remain. Current attacks typically perturb individual modalities, but the interaction between perturbations (e.g., adversarial videos with synchronized audio-text triggers) remains underexplored. Moreover, most attacks assume white-box access or task-specific setups, limiting their applicability. Although methods such as AdvDiffVLM's ensemble gradient estimation and CroPA's cross-prompt adversarial transferability show promise, broader generalization to commercial models is necessary. Furthermore, video-MLLMs are vulnerable to temporal coherence exploits.

虽然现有攻击揭示了特定模态的脆弱性，但仍存在一些空白。当前攻击通常针对单一模态进行扰动，但模态间扰动的交互(例如具有同步音频-文本触发的对抗视频)尚未充分研究。此外，大多数攻击假设白盒访问或任务特定设置，限制了其应用范围。尽管如AdvDiffVLM的集成梯度估计和CroPA的跨提示对抗迁移等方法显示出潜力，但需要更广泛地推广到商业模型。此外，视频多模态大模型(Video-MLLMs)也易受到时间连续性利用的攻击。

### 8.3 Data-Centric Security Risk

### 8.3 数据中心的安全风险

The reliance of MLLMs on multimodal training data introduces unique risks. Despite advancements in clean-label poisoning and universal triggers, defenses against domain-shifted triggers remain insufficient. Additionally, adversarial attacks often exploit inherent biases in training data. Future research should quantify the interaction between biases and adversarial manipulations, developing debiasing techniques during model alignment. Optimizing visual instruction tuning with safety-aware datasets and reinforcement learning could reduce vulnerabilities. However, challenges such as reward misalignment and multimodal preference modeling require further exploration.

多模态大模型(MLLMs)对多模态训练数据的依赖带来了独特的风险。尽管在干净标签污染(clean-label poisoning)和通用触发器(universal triggers)方面取得了进展，但对抗域迁移触发器的防御仍不足。此外，对抗攻击常利用训练数据中的固有偏差。未来研究应量化偏差与对抗操控之间的关系，开发在模型对齐过程中去偏技术。利用安全感知数据集和强化学习优化视觉指令调优，有助于降低漏洞。然而，奖励错位(reward misalignment)和多模态偏好建模等挑战仍需深入探索。

### 8.4 Human-AI Collaborative Defense

### 8.4 人机协作防御

As attacks on MLLMs become increasingly sophisticated, emerging defense paradigms integrate human expertise with automated systems. For example, TrustNavGPT [Sun et al., 2024] leverages uncertainty in audio-guided navigation, but broader frameworks could benefit from human oversight to identify subtle adversarial patterns. Developing interpretable defenses is essential to enhance transparency and trust in safety mechanisms.

随着对多模态大模型(MLLMs)攻击的日益复杂，新的防御范式开始结合人类专业知识与自动化系统。例如，TrustNavGPT [Sun等，2024]利用音频引导导航中的不确定性，但更广泛的框架可以借助人类监督，识别微妙的对抗性模式。开发可解释的防御机制对于提升透明度和信任度、增强安全机制的有效性至关重要。

### 8.5 Lacking Benchmarking and Standardization

### 8.5 缺乏基准测试与标准化

Another obstacle to progress is the lack of standardized evaluation protocols. Existing attacks are tested on disparate models with inconsistent metrics. To address this, community-driven efforts should establish baselines for evaluation settings. Notably, current defenses mainly focus on modality-specific robustness and lack holistic metrics for cross-modal safety. Releasing modular frameworks will streamline research on attack or defense paradigms and foster further advancements in the field.

另一个制约发展的因素是缺乏标准化的评估协议。现有攻击在不同模型上测试，指标不一致。应由社区推动建立统一的评估基线。值得注意的是，当前的防御主要关注模态特定的鲁棒性，缺乏跨模态安全的整体指标。发布模块化框架将有助于简化攻击与防御的研究流程，推动该领域的进一步发展。

## 9 Conclusion

## 9 结论

This survey explores the adversarial robustness of multimodal large language models (MLLMs). We begin by introducing the background and evaluation methods used to assess the robustness of MLLMs. We then categorize adversarial attacks across image, video, audio, and speech modalities, reviewing the vulnerabilities of MLLMs. Finally, we highlight key research gaps and unresolved issues that warrant further investigation in the field of MLLM robustness. We hope this survey provides valuable insights to researchers and encourages greater contributions to this growing area of study. References

本综述探讨了多模态大模型(MLLMs)的对抗鲁棒性。首先介绍了评估MLLMs鲁棒性的方法和背景，然后对图像、视频、音频和语音模态的对抗攻击进行了分类，分析了MLLMs的脆弱性。最后，指出了亟需进一步研究的关键空白和未解决的问题，以推动MLLM鲁棒性的发展。希望本综述能为研究者提供有价值的见解，并激励更多的贡献，推动这一不断增长的研究领域。参考文献

[Bagdasaryan et al., 2023] Eugene Bagdasaryan, Tsung-Yin Hsieh, Ben Nassi, et al. (ab) using images and sounds for indirect instruction injection in multi-modal llms. arXiv preprint arXiv:2307.10490, 2023.

[Bagdasaryan et al., 2023] 尤金·巴格达萨良(Eugene Bagdasaryan)、谢宗尹(Tsung-Yin Hsieh)、纳西(Ben Nassi)等(ab) 使用图像和声音进行多模态大模型(llms)中的间接指令注入。arXiv预印本 arXiv:2307.10490，2023年。

[Bailey et al., 2023] Luke Bailey, Euan Ong, Stuart Russell, et al. Image hijacks: Adversarial images can control generative models at runtime. In ${ICML},{2023}$ .

[Bailey et al., 2023] 卢克·贝利(Luke Bailey)、欧安·翁(Euan Ong)、斯图尔特·拉塞尔(Stuart Russell)等。图像劫持:对抗性图像可以在运行时控制生成模型。在${ICML},{2023}$中。

[Caba Heilbron et al., 2015] Fabian Caba Heilbron, Victor Escorcia, Bernard Ghanem, et al. Activitynet: A large-scale video benchmark for human activity understanding. In ${CVPR}$ , pages 961-970,2015.

[Caba Heilbron et al., 2015] 法比安·卡巴·海尔布隆(Fabian Caba Heilbron)、维克多·埃斯科尔西亚(Victor Escorcia)、伯纳德·甘南(Bernard Ghanem)等。Activitynet:用于人类活动理解的大规模视频基准测试。在${CVPR}$，第961-970页，2015年。

[Cai et al., 2024] Zhixi Cai, Shreya Ghosh, Aman Pankaj Adatia, et al. Av-deepfakelm: A large-scale llm-driven audio-visual deepfake dataset. In ${ACMMM},{2024}$ .

[Cai et al., 2024] 采志希(Zhixi Cai)、舒瑞雅·高什(Shreya Ghosh)、阿曼·潘卡杰·阿达蒂亚(Aman Pankaj Adatia)等。Av-deepfakelm:一个由大规模大模型(llm)驱动的音视频深伪(deepfake)数据集。在${ACMMM},{2024}$中。

[Carlini et al., 2024] Nicholas Carlini, Milad Nasr, Christopher A Choquette-Choo, et al. Are aligned neural networks adversarially aligned? NeurIPS, 2024.

[Carlini et al., 2024] 尼古拉斯·卡尔尼(Nicholas Carlini)、米拉德·纳斯尔(Milad Nasr)、克里斯托弗·A·乔凯特-丘(Christopher A Choquette-Choo)等。对齐的神经网络是否具有对抗性对齐？NeurIPS，2024年。

[Chen et al., 2022] Chongyan Chen, Samreen Anjum, and Danna Gurari. Grounding answers for visual questions asked by visually impaired people. In CVPR, 2022.

[Chen et al., 2022] 陈冲岩(Chongyan Chen)、桑姆林·安朱姆(Samreen Anjum)、达娜·古拉里(Danna Gurari)。为视障人士提出的视觉问题答案的基础化。在CVPR，2022年。

[Chowdhury et al., 2024] Arijit Ghosh Chowdhury, Md Mofijul Islam, Vaibhav Kumar, et al. Breaking down the defenses: A comparative survey of attacks on large language models. arXiv preprint:2403.04786, 2024.

[Chowdhury et al., 2024] 阿里吉特·戈什·乔杜里(Arijit Ghosh Chowdhury)、穆罕默德·莫菲朱尔·伊斯兰(Md Mofijul Islam)、瓦伊巴夫·库马尔(Vaibhav Kumar)等。破解防御:对大型语言模型攻击的对比调研。arXiv预印本:2403.04786，2024年。

[Chung et al., 2024] Nhat Chung, Sensen Gao, Tuan-Anh Vu, et al. Towards transferable attacks against vision-llms in autonomous driving with typography. arXiv preprint arXiv:2405.14169, 2024.

[Chung et al., 2024] 阮一鸣(Nhat Chung)、高森森(Sensen Gao)、吴端安(Tuan-Anh Vu)等。面向自动驾驶视觉大模型的可迁移攻击:排版技术。arXiv预印本 arXiv:2405.14169，2024年。

[Cui et al., 2024] Xuanming Cui, Alejandro Aparcedo, Young Kyun Jang, et al. On the robustness of large multimodal models against image adversarial attacks. In CVPR, 2024.

[Cui et al., 2024] 崔轩明(Xuanming Cui)、亚历杭德罗·阿帕塞多(Alejandro Aparcedo)、张永均(Young Kyun Jang)等。关于大型多模态模型对抗图像攻击的鲁棒性。在CVPR，2024年。

[Dong et al., 2023] Yinpeng Dong, Huanran Chen, Jiawei Chen, et al. How robust is google's bard to adversarial image attacks? arXiv preprint arXiv:2309.11751, 2023.

[Dong et al., 2023] 董银鹏(Yinpeng Dong)、陈焕然(Huanran Chen)、陈家伟(Jiawei Chen)等。谷歌的Bard对抗性图像攻击的鲁棒性如何？arXiv预印本 arXiv:2309.11751，2023年。

[Fan et al., 2024] Yihe Fan, Yuxin Cao, Ziyu Zhao, et al. Unbridled icarus: A survey of the potential perils of image inputs in multimodal large language model security. arXiv preprint arXiv:2404.05264, 2024.

[Fan et al., 2024] 范一禾(Yihe Fan)、曹宇欣(Yuxin Cao)、赵子瑜(Ziyu Zhao)等。无拘无束的伊卡洛斯:多模态大模型安全中图像输入潜在风险的调研。arXiv预印本 arXiv:2404.05264，2024年。

[Fu et al., 2024] Jiyuan Fu, Zhaoyu Chen, Kaixun Jiang, et al. Pg-attack: A precision-guided adversarial attack framework against vision foundation models for autonomous driving. arXiv preprint:2405.14169, 2024.

[Fu et al., 2024] 傅吉元(Jiyuan Fu)、陈昭瑜(Zhaoyu Chen)、姜凯迅(Kaixun Jiang)等。Pg-attack:针对自动驾驶视觉基础模型的精确引导对抗攻击框架。arXiv预印本:2405.14169，2024年。

[Gao et al., ] Kuofeng Gao, Yang Bai, Jindong Gu, et al. Inducing high energy-latency of large vision-language models with verbose images. In ICLR.

[Gao et al., ] 高阔峰(Kuofeng Gao)、白杨(Yang Bai)、顾金东(Jindong Gu)等。通过冗长的图像诱导大型视觉-语言模型(vision-language models)高能耗延迟。在ICLR会议。

[Gong et al., 2023] Yichen Gong, Delong Ran, Jinyuan Liu, et al. Figstep: Jailbreaking large vision-language models via typographic visual prompts. arXiv preprint arXiv:2311.05608, 2023.

[Gong et al., 2023] 宫一辰(Yichen Gong)、冉德龙(Delong Ran)、刘金源(Jinyuan Liu)等。Figstep:通过排版视觉提示破解大型视觉-语言模型。在arXiv预印本 arXiv:2311.05608，2023年。

[Goyal et al., 2017] Yash Goyal, Tejas Khot, Douglas Summers-Stay, et al. Making the $\mathrm{v}$ in vqa matter: Elevating the role of image understanding in visual question answering. In CVPR, pages 6904-6913, 2017.

[Goyal et al., 2017] 叶尚(Yash Goyal)、卡杰斯·科特(Tejas Khot)、道格拉斯·萨默斯-斯泰(Douglas Summers-Stay)等。让视觉问答(VQA)中的图像理解变得重要:提升图像理解在视觉问答中的作用。在CVPR，2017年，第6904-6913页。

[Gu et al., 2024] Xiangming Gu, Xiaosen Zheng, Tianyu Pang, et al. Agent smith: A single image can jailbreak one million multimodal llm agents exponentially fast. In ICML, 2024.

[Gu et al., 2024] 谷向明(Xiangming Gu)、郑晓森(Xiaosen Zheng)、庞天宇(Tianyu Pang)等。Agent Smith:一张图片可以指数级破解一百万个多模态大模型代理。在ICML，2024年。

[Guo et al., 2024] Qi Guo, Shanmin Pang, Xiaojun Jia, et al. Efficient generation of targeted and transferable adversarial examples for vision-language models via diffusion models. IEEE Trans. Inf. Forensics Secur., 2024.

[Guo et al., 2024] 郭琪, 庞善敏, 贾晓军等. 通过扩散模型高效生成针对性和可迁移的对抗样本用于视觉-语言模型. IEEE信息取证与安全学报, 2024.

[Li et al., 2024] Jinmin Li, Kuofeng Gao, Yang Bai, et al. Fmm-attack: A flow-based multi-modal adversarial attack on video-based llms. arXiv preprint:2403.13507, 2024.

[Li et al., 2024] 李金敏, 高阔峰, 白杨等. Fmm-attack:一种基于流的多模态对抗攻击针对视频基础的大型语言模型. arXiv预印本:2403.13507, 2024.

[Li et al., 2025] Yifan Li, Hangyu Guo, Kun Zhou, et al. Images are achilles' heel of alignment: Exploiting visual vulnerabilities for jailbreaking multimodal large language models. In ${ECCV},{2025}$ .

[Li et al., 2025] 李一凡, 郭航宇, 周坤等. 图像是对齐的阿喀琉斯之踵:利用视觉脆弱性实现多模态大模型的越狱攻击. 在${ECCV},{2025}$中.

[Liang et al., 2024a] Jiawei Liang, Siyuan Liang, Man Luo, et al. Vl-trojan: Multimodal instruction backdoor attacks against autoregressive visual language models, 2024.

[Liang et al., 2024a] 梁家伟, 梁思远, 罗满等. Vl-trojan:针对自回归视觉语言模型的多模态指令后门攻击, 2024.

[Liang et al., 2024b] Siyuan Liang, Jiawei Liang, Tianyu Pang, et al. Revisiting backdoor attacks against large vision-language models. CoRR, 2024.

[Liang et al., 2024b] 梁思远, 梁家伟, 庞天宇等. 重新审视针对大型视觉-语言模型的后门攻击. CoRR, 2024.

[Lin et al., 2014] Tsung-Yi Lin, Michael Maire, Serge Be-longie, et al. Microsoft coco: Common objects in context. In ${ECCV}$ , pages 740-755,2014.

[Lin et al., 2014] 林宗毅, Maire Michael, Serge Belongie等. 微软COCO:情境中的常见物体. 在${ECCV}$，第740-755页, 2014.

[Liu et al., 2024a] Daizong Liu, Mingyu Yang, Xiaoye Qu, et al. A survey of attacks on large vision-language models: Resources, advances, and future trends. arXiv preprint arXiv:2407.07403, 2024.

[Liu et al., 2024a] 刘岱宗, 杨明宇, 曲晓叶等. 大型视觉-语言模型攻击的综述:资源、进展与未来趋势. arXiv预印本 arXiv:2407.07403, 2024.

[Liu et al., 2024b] Xin Liu, Yichen Zhu, Yunshi Lan, et al. Safety of multimodal large language models on images and text. In IJCAI-24, 2024. Survey Track.

[Liu et al., 2024b] 刘新, 朱一辰, 蓝云石等. 多模态大型语言模型在图像和文本上的安全性. 在IJCAI-24, 2024. 调查专场.

[Liu et al., 2025] Xin Liu, Yichen Zhu, Jindong Gu, et al. Mm-safetybench: A benchmark for safety evaluation of multimodal large language models. In ${ECCV},{2025}$ .

[Liu et al., 2025] 刘新, 朱一辰, 顾金东等. Mm-safetybench:多模态大型语言模型安全评估基准. 在${ECCV},{2025}$中.

[Lu et al., 2022] Pan Lu, Swaroop Mishra, Tanglin Xia, et al. Learn to explain: Multimodal reasoning via thought chains for science question answering. NeurIPS, 2022.

[Lu et al., 2022] 卢攀, 米沙罗普, 夏唐林等. 学会解释:通过思维链实现科学问题回答的多模态推理. NeurIPS, 2022.

[Lu et al., 2024] Dong Lu, Tianyu Pang, Chao Du, et al. Test-time backdoor attacks on multimodal large language models, 2024.

[Lu et al., 2024] 卢东, 庞天宇, 杜超等. 多模态大型语言模型的测试时后门攻击, 2024.

[Luong et al., 2024] Hieu-Thi Luong, Haoyang Li, Lin Zhang, et al. Llamapartialspoof: An llm-driven fake speech dataset simulating disinformation generation. arXiv preprint arXiv:2409.14743, 2024.

[Luong et al., 2024] 卢慧智, 李浩洋, 张琳等. Llamapartialspoof:一种由大型语言模型驱动的假语音数据集，用于模拟虚假信息生成. arXiv预印本 arXiv:2409.14743, 2024.

[Marino et al., 2019] Kenneth Marino, Mohammad Raste-gari, Ali Farhadi, et al. Ok-vqa: A visual question answering benchmark requiring external knowledge. In CVPR, pages 3195-3204, 2019.

[Marino et al., 2019] 马里诺·肯尼斯, 拉斯特加里·穆罕默德, 法哈迪·阿里等. Ok-vqa:一个需要外部知识的视觉问答基准. 在CVPR, 第3195-3204页, 2019.

[Miao et al., 2024] Yibo Miao, Yifan Zhu, Lijia Yu, et al. T2vsafetybench: Evaluating the safety of text-to-video generative models. In NeurIPS, 2024.

[Miao et al., 2024] 苗一博, 朱一凡, 于丽佳等. T2vsafetybench:评估文本到视频生成模型的安全性. 在NeurIPS, 2024.

[Ni et al., 2024] Zhenyang Ni, Rui Ye, Yuxi Wei, et al. Physical backdoor attack can jeopardize driving with vision-large-language models. arXiv preprint arXiv:2404.12916, 2024.

[Ni et al., 2024] 倪振阳, 叶瑞, 韦玉希等. 物理后门攻击可能危及基于视觉的大型语言模型的驾驶安全. arXiv预印本 arXiv:2404.12916, 2024.

[Niu et al., 2024] Zhenxing Niu, Haodong Ren, Xinbo Gao, et al. Jailbreaking attack against multimodal large language model. arXiv preprint arXiv:2402.02309, 2024.

[Niu et al., 2024] 牛振兴, 任浩东, 高新博, 等. 针对多模态大语言模型的越狱攻击. arXiv预印本 arXiv:2402.02309, 2024.

[Panayotov et al., 2015] Vassil Panayotov, Guoguo Chen, Daniel Povey, et al. Librispeech: an asr corpus based on public domain audio books. In ICASSP, 2015.

[Panayotov et al., 2015] Vassil Panayotov, Guoguo Chen, Daniel Povey, 等. Librispeech:基于公共领域有声书的自动语音识别(ASR)语料库. 在ICASSP, 2015.

[Peri et al., 2024] Raghuveer Peri, Sai Muralidhar Jayanthi, Srikanth Ronanki, et al. Speechguard: Exploring the adversarial robustness of multimodal large language models. arXiv preprint arXiv:2405.08317, 2024.

[Peri et al., 2024] Raghuveer Peri, Sai Muralidhar Jayanthi, Srikanth Ronanki, 等. Speechguard:探索多模态大语言模型的对抗鲁棒性. arXiv预印本 arXiv:2405.08317, 2024.

[Pi et al., 2024] Renjie Pi, Tianyang Han, Jianshu Zhang, et al. Mllm-protector: Ensuring mllm's safety without hurting performance. arXiv:2401.02906, 2024.

[Pi et al., 2024] 皮仁杰, 韩天阳, 张建书, 等. Mllm-protector:在不影响性能的前提下确保大语言模型(MLLM)的安全性. arXiv:2401.02906, 2024.

[Plummer et al., 2015] Bryan A Plummer, Liwei Wang, Chris M Cervantes, et al. Flickr30k entities: Collecting region-to-phrase correspondences for richer image-to-sentence models. In ICCV, pages 2641-2649, 2015.

[Plummer et al., 2015] Bryan A Plummer, Liwei Wang, Chris M Cervantes, 等. Flickr30k实体:收集区域到短语的对应关系，以构建更丰富的图像到句子模型. 在ICCV, 页码2641-2649, 2015.

[Qi et al., 2023] Xiangyu Qi, Yi Zeng, Tinghao Xie, et al. Fine-tuning aligned language models compromises safety, even when users do not intend to! In ICLR, 2023.

[Qi et al., 2023] 启翔, 曾毅, 谢廷浩, 等. 微调对齐的语言模型会危及安全，即使用户无意为之！在ICLR, 2023.

[Qi et al., 2024] Xiangyu Qi, Kaixuan Huang, Ashwinee Panda, et al. Visual adversarial examples jailbreak aligned large language models. In ${AAAI},{2024}$ .

[Qi et al., 2024] 启翔, 黄开轩, Panda Ashwinee, 等. 视觉对抗样本越狱对齐的大型语言模型. 在${AAAI},{2024}$ 。

[Rafailov et al., 2024] Rafael Rafailov, Archit Sharma, Eric Mitchell, et al. Direct preference optimization: Your language model is secretly a reward model. NeurIPS, 2024.

[Rafailov et al., 2024] Rafael Rafailov, Archit Sharma, Eric Mitchell, 等. 直接偏好优化:你的语言模型实际上是一个奖励模型. NeurIPS, 2024.

[Schlarmann and Hein, 2023] Christian Schlarmann and Matthias Hein. On the adversarial robustness of multimodal foundation models. In CVPR, 2023.

[Schlarmann and Hein, 2023] Christian Schlarmann 和 Matthias Hein. 多模态基础模型的对抗鲁棒性研究. 在CVPR, 2023.

[Schlarmann et al.,2024] Christian Schlarmann, Naman Deep Singh, Croce Francesco, et al. Robust clip: Unsupervised adversarial fine-tuning of vision embed-dings for robust large vision-language models. In ICML, 2024.

[Schlarmann et al.,2024] Christian Schlarmann, Naman Deep Singh, Croce Francesco, 等. Robust clip:无监督对抗微调视觉嵌入以实现鲁棒的大型视觉-语言模型. 在ICML, 2024.

[Shen et al., 2024] Xinyue Shen, Yixin Wu, Michael Backes, et al. Voice jailbreak attacks against gpt-4o. arXiv preprint arXiv:2405.19103, 2024.

[Shen et al., 2024] 沈新月, 吴一心, Michael Backes, 等. 针对GPT-4o的语音越狱攻击. arXiv预印本 arXiv:2405.19103, 2024.

[Sun et al., 2024] Xingpeng Sun, Yiran Zhang, Xindi Tang, et al. Trustnavgpt: Modeling uncertainty to improve trustworthiness of audio-guided llm-based robot navigation. arXiv preprint arXiv:2408.01867, 2024.

[Sun et al., 2024] 孙兴鹏, 张怡然, 唐新迪, 等. Trustnavgpt:建模不确定性以提升基于音频引导的机器人导航的可信度. arXiv预印本 arXiv:2408.01867, 2024.

[Tao et al., 2024] Xijia Tao, Shuai Zhong, Lei Li, et al. Imgtrojan: Jailbreaking vision-language models with one image. arXiv preprint arXiv:2403.02910, 2024.

[Tao et al., 2024] 陶希佳, 钟帅, 李磊, 等. Imgtrojan:用一张图片越狱视觉-语言模型. arXiv预印本 arXiv:2403.02910, 2024.

[Tu et al., 2024] Haoqin Tu, Chenhang Cui, Zijun Wang, et al. How many are in this image a safety evaluation benchmark for vision llms. In ${ECCV},{2024}$ .

[Tu et al., 2024] 涂浩钦, 崔晨航, 王子俊, 等. 这张图片中有多少个？——视觉大模型的安全评估基准. 在${ECCV},{2024}$ 。

[Wang et al., 2024a] Ruofan Wang, Xingjun Ma, Hanxu Zhou, , et al. White-box multimodal jailbreaks against large vision-language models. In ${ACMMM},{2024}$ .

[Wang et al., 2024a] 王若凡, 马兴军, 周汉旭, 等. 针对大型视觉-语言模型的白盒多模态越狱攻击. 在${ACMMM},{2024}$ 。

[Wang et al., 2024b] Zefeng Wang, Zhen Han, Shuo Chen, et al. Stop reasoning! when multimodal llms with chain-of-thought reasoning meets adversarial images. arXiv preprint arXiv:2402.14899, 2024.

[Wang et al., 2024b] 王泽峰, 韩震, 陈硕, 等. 停止推理！当具有链式推理能力的多模态大模型遇到对抗性图像时. arXiv预印本 arXiv:2402.14899, 2024.

[Wu et al., 2023] Yuanwei Wu, Xiang Li, Yixin Liu, et al. Jailbreaking gpt-4v via self-adversarial attacks with system prompts. arXiv preprint arXiv:2311.09127, 2023.

[Wu et al., 2023] 吴元伟，李翔，刘一心等。通过系统提示的自我对抗攻击破解GPT-4V。arXiv预印本 arXiv:2311.09127，2023年。

[Wu et al., 2024] Chen Henry Wu, Rishi Rajesh Shah, Jing Yu Koh, et al. Dissecting adversarial robustness of multimodal Im agents. In NeurIPS Workshop on Open-World Agents, 2024.

[Wu et al., 2024] 吴辰亨，沙瑞希·拉杰什，科靖宇等。多模态智能体的对抗鲁棒性分析。2024年NeurIPS开放世界智能体研讨会。

[Xiao et al., 2024] Junbin Xiao, Nanxin Huang, Hangyu Qin, et al. Videoqa in the era of llms: An empirical study. arXiv preprint arXiv:2408.04223, 2024.

[Xiao et al., 2024] 肖俊斌，黄楠欣，秦航宇等。在大语言模型(LLMs)时代的视频问答:一项实证研究。arXiv预印本 arXiv:2408.04223，2024年。

[Xu et al., 2017] Dejing Xu, Zhou Zhao, Jun Xiao, et al. Video question answering via gradually refined attention over appearance and motion. In ${ACMMM}$ , pages 1645- 1653, 2017.

[Xu et al., 2017] 徐德靖，赵舟，肖俊等。通过对外观和运动的逐步细化注意力实现视频问答。见 ${ACMMM}$ ，第1645-1653页，2017年。

[Xu et al., 2024a] Lu Xu, Sijie Zhu, Chunyuan Li, et al. Beyond raw videos: Understanding edited videos with large multimodal model. arXiv preprint arXiv:2406.10484, 2024.

[Xu et al., 2024a] 徐璐，朱思杰，李春元等。超越原始视频:利用大型多模态模型理解编辑后的视频。arXiv预印本 arXiv:2406.10484，2024年。

[Xu et al., 2024b] Yuancheng Xu, Jiarui Yao, Manli Shu, et al. Shadowcast: Stealthy data poisoning attacks against vision-language models. In ICLR Workshop on Navigating and Addressing Data Problems for Foundation Models, 2024.

[Xu et al., 2024b] 许元成，姚嘉瑞，舒曼力等。Shadowcast:针对视觉-语言模型的隐秘数据中毒攻击。2024年ICLR基础模型数据问题导航与应对研讨会。

[Yang et al., 2024] Wanqi Yang, Yanda Li, Meng Fang, et al. Who can withstand chat-audio attacks? an evaluation benchmark for large language models. arXiv preprint arXiv:2411.14842, 2024.

[Yang et al., 2024] 杨婉琪，李彦达，方萌等。谁能抵抗聊天-音频攻击？大型语言模型的评估基准。arXiv预印本 arXiv:2411.14842，2024年。

[Zhang et al., 2023] Zhexin Zhang, Leqi Lei, Lindong Wu, et al. Safetybench: Evaluating the safety of large language models with multiple choice questions. arXiv preprint arXiv:2309.07045, 2023.

[Zhang et al., 2023] 张哲新，雷乐奇，吴林东等。Safetybench:利用多项选择题评估大型语言模型的安全性。arXiv预印本 arXiv:2309.07045，2023年。

[Zhang et al., 2024a] Hangtao Zhang, Chenyu Zhu, Xian-long Wang, et al. Badrobot: Manipulating embodied llms in the physical world. arXiv preprint arXiv:2407.20242, 2024.

[Zhang et al., 2024a] 张航涛，朱辰宇，王贤龙等。Badrobot:在物理世界中操控具身(embodied)大型语言模型。arXiv预印本 arXiv:2407.20242，2024年。

[Zhang et al., 2024b] Hao Zhang, Wenqi Shao, Hong Liu, et al. B-avibench: Towards evaluating the robustness of large vision-language model on black-box adversarial visual-instructions. IEEE Trans. Inf. Forensics Secur., 2024.

[Zhang et al., 2024b] 张浩，邵文奇，刘宏等。B-Avibench:评估大型视觉-语言模型在黑盒对抗视觉指令中的鲁棒性。IEEE信息取证与安全杂志，2024年。

[Zhang et al., 2024c] Jingyi Zhang, Jiaxing Huang, Sheng Jin, et al. Vision-language models for vision tasks: A survey. IEEE Trans. Pattern Anal. Mach. Intell., 2024.

[Zhang et al., 2024c] 张静怡，黄嘉兴，金胜等。面向视觉任务的视觉-语言模型:综述。IEEE模式分析与机器智能杂志，2024年。

[Zhang et al., 2024d] Tianyuan Zhang, Lu Wang, Xinwei Zhang, et al. Visual adversarial attack on vision-language models for autonomous driving. arXiv preprint arXiv:2411.18275, 2024.

[Zhang et al., 2024d] 张天源，王璐，张新伟等。针对自动驾驶的视觉-语言模型的对抗性攻击。arXiv预印本 arXiv:2411.18275，2024年。

[Zhao et al., 2024] Yunqing Zhao, Tianyu Pang, Chao Du, et al. On evaluating adversarial robustness of large vision-language models. NeurIPS, 2024.

[Zhao et al., 2024] 赵云清，庞天宇，杜超等。评估大型视觉-语言模型的对抗鲁棒性。NeurIPS，2024年。

[Zhu et al., 2024] Yichen Zhu, Minjie Zhu, Ning Liu, et al. Llava-phi: Efficient multi-modal assistant with small language model. In ${EMCLR},{2024}$ .

[Zhu et al., 2024] 朱一辰，朱敏杰，刘宁等。Llava-phi:基于小型语言模型的高效多模态助手。见 ${EMCLR},{2024}$ 。