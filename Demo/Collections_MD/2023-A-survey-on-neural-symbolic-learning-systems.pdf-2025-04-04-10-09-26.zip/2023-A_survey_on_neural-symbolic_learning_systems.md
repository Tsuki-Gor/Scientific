Review

综述

# A survey on neural-symbolic learning systems

# 神经符号学习系统综述

Dongran ${\mathrm{{Yu}}}^{\mathrm{a},\mathrm{b}}$ , Bo ${\mathrm{{Yang}}}^{\mathrm{a},\mathrm{c}, * }$ , Dayou ${\mathrm{{Liu}}}^{\mathrm{a},\mathrm{c}}$ , Hui Wang ${}^{\mathrm{d}}$ , Shirui ${\mathrm{{Pan}}}^{\mathrm{e}}$

董然 ${\mathrm{{Yu}}}^{\mathrm{a},\mathrm{b}}$ ，薄 ${\mathrm{{Yang}}}^{\mathrm{a},\mathrm{c}, * }$ ，大有 ${\mathrm{{Liu}}}^{\mathrm{a},\mathrm{c}}$ ，王辉 ${}^{\mathrm{d}}$ ，史瑞 ${\mathrm{{Pan}}}^{\mathrm{e}}$

${}^{a}$ Key Laboratory of Symbolic Computation and Knowledge Engineer(Jilin University), Ministry of Education, Changchun, jllin 130012, China

${}^{a}$ 符号计算与知识工程教育部重点实验室(吉林大学)，中国吉林省长春市，130012

${}^{b}$ School of Artificial Intelligence, Jilin University, Changchun, Jilin,130012, China

${}^{b}$ 吉林大学人工智能学院，中国吉林省长春市，130012

${}^{c}$ School of Computer Science and Technology, Jilin University, Changchun, Jilin,130012, China

${}^{c}$ 吉林大学计算机科学与技术学院，中国吉林省长春市，130012

${}^{d}$ School of Electronics, Electrical Engineering and Computer Science, Queen’s University Belfast, United Kingdom

${}^{d}$ 贝尔法斯特女王大学电子、电气工程与计算机科学学院，英国

${}^{e}$ School of Information and Communication Technology, Griffith University, Australia

${}^{e}$ 格里菲斯大学信息与通信技术学院，澳大利亚

## ARTICLE INFO

## 文章信息

Article history:

文章历史:

Received 8 March 2023

2023年3月8日收到

Received in revised form 22 June 2023

2023年6月22日收到修订稿

Accepted 24 June 2023

2023年6月24日接受

Available online 6 July 2023

2023年7月6日在线发表

Keywords:

关键词:

Neural-symbolic learning systems

神经符号学习系统

Neural networks

神经网络

Symbolic reasoning

符号推理

Symbols

符号

Logic

逻辑

Knowledge graphs

知识图谱

## A B S T R A C T

## 摘 要

In recent years, neural systems have demonstrated highly effective learning ability and superior perception intelligence. However, they have been found to lack effective reasoning and cognitive ability. On the other hand, symbolic systems exhibit exceptional cognitive intelligence but suffer from poor learning capabilities when compared to neural systems. Recognizing the advantages and disadvantages of both methodologies, an ideal solution emerges: combining neural systems and symbolic systems to create neural-symbolic learning systems that possess powerful perception and cognition. The purpose of this paper is to survey the advancements in neural-symbolic learning systems from four distinct perspectives: challenges, methods, applications, and future directions. By doing so, this research aims to propel this emerging field forward, offering researchers a comprehensive and holistic overview. This overview will not only highlight the current state-of-the-art but also identify promising avenues for future research. © 2023 Elsevier Ltd. All rights reserved.

近年来，神经网络系统展现出了高效的学习能力和卓越的感知智能。然而，人们发现它们缺乏有效的推理和认知能力。另一方面，符号系统表现出非凡的认知智能，但与神经网络系统相比，其学习能力较差。认识到这两种方法的优缺点后，一个理想的解决方案应运而生:将神经网络系统和符号系统相结合，创建具有强大感知和认知能力的神经符号学习系统。本文旨在从四个不同的角度对神经符号学习系统的进展进行综述:挑战、方法、应用和未来方向。通过这样做，本研究旨在推动这一新兴领域的发展，为研究人员提供全面而整体的概述。这一概述不仅将突出当前的技术水平，还将确定未来研究的有前景的方向。© 2023 爱思唯尔有限公司。保留所有权利。

## Contents

## 目录

1. Introduction. 106

1. 引言。106

2. Categorization and frameworks 108

2. 分类与框架 108

2.1. Learning for reasoning 108

2.1. 推理学习 108

2.2. Reasoning for learning 109

2.2. 学习推理 109

2.3. Learning- reasoning. 110

2.3. 学习 - 推理。110

3. Methods of neural-symbolic learning systems 110

3. 神经符号学习系统的方法 110

3.1. Learning for reasoning 110

3.1. 推理学习 110

3.1.1. Accelerating symbolic reasoning 111

3.1.1. 加速符号推理 111

3.1.2. Abstracting unstructured data into symbols. 112

3.1.2. 将非结构化数据抽象为符号。112

3.2. Reasoning for learning 113

3.2. 学习推理。113

3.2.1. Regularization models 113

3.2.1. 正则化模型。113

3.2.2. Knowledge transfer models 114

3.2.2. 知识迁移模型。114

3.3. Learning- reasoning. 117

3.3. 学习 - 推理。117

4. Applications. 119

4. 应用。119

4.1. Object/visual-relationship detection 119

4.1. 目标/视觉关系检测。119

4.2. Knowledge graph reasoning. 119

4.2. 知识图谱推理。119

4.3. Classification/ few-shot classification 119

4.3. 分类/小样本分类。119

4.4. Intelligent question answering. 119

4.4. 智能问答。119

4.5. Reinforcement learning. 120

4.5. 强化学习。120

5. Future directions 120

5. 未来方向。120

5.1. Efficient methods. 120

5.1. 高效方法。120

5.2. Automatic construction of symbolic knowledge 120

5.2. 符号知识的自动构建。120

5.3. Symbolic representation learning 121

5.3. 符号表示学习。121

5.4. Application field expansion 121

5.4. 应用领域拓展。121

---

* Corresponding author at: School of Computer Science and Technology, Jilin University, Changchun, Jilin, 130012, China.

* 通信作者地址:中国吉林省长春市吉林大学计算机科学与技术学院，邮编130012。

E-mail addresses: yudran@foxmail.com (D. Yu), ybo@jlu.edu.cn (B. Yang), s.pan@griffith.edu.au (S. Pan).

电子邮箱地址:yudran@foxmail.com(于D.)，ybo@jlu.edu.cn(杨B.)，s.pan@griffith.edu.au(潘S.)。

---

6. Conclusion 121

6. 结论 121

CRediT authorship contribution statement 121

作者贡献声明 121

Declaration of competing interest 121

利益冲突声明 121

Data availability. 121

数据可用性。 121

Acknowledgments 121

致谢 121

Appendix. Preliminaries. 121

附录。预备知识。 121

A.1. Symbols 121

A.1. 符号 121

A.1.1. Propositional logic 121

A.1.1. 命题逻辑 121

A.1.2. First- order logic. 121

A.1.2. 一阶逻辑。 121

A.1.3. Knowledge graph 122

A.1.3. 知识图谱 122

A.2. Neural networks 122

A.2. 神经网络 122

References 124

参考文献 124

## 1. Introduction

## 1. 引言

Perception, represented by connectionism or neural systems, and cognition, represented by symbolism or symbolic systems, are two fundamental paradigms in the field of artificial intelligence (AI), each having prevailed for several decades. Fig. 1 showcases the rise and fall of these two doctrines, which researchers commonly categorize into three significant periods. (1) The 1960s-1970s (1956-1968). The inception of reasoning in AI can be traced back to the 1956 Dartmouth Conference, where Newell and Simon introduced the "logical theorist" program, successfully proving 38 mathematical theorems. This marked the beginning of the reasoning era in AI. However, researchers soon realized that relying solely on heuristic search algorithms had limitations, and many complex problems necessitated specialized domain knowledge to achieve higher levels of intelligence. Consequently, incorporating knowledge into AI models became a prevalent notion, as it enhanced the ability to find solutions within large solution spaces. (2) The 1970s-1990s (1968-1985). During this period, significant developments occurred, such as the creation of the first expert system, "DenDral" by Faigan's nanny and Lederberg in 1968. This milestone represented the organic integration of AI and domain knowledge, marking the advent of the knowledge-focused era in AI. However, knowledge acquisition posed a significant challenge, leading to a shift towards automatic acquisition of valuable knowledge from massive datasets, which gradually became the mainstream trend in AI. (3) From the 1990s to the present: In 1983, neural networks started gaining prominence, and after 2000, AI entered the era of machine learning. Notable breakthroughs in machine learning, particularly through neural networks, include the 2012 triumph of ImageNet with Deep Convolutional Neural Networks (CNN), and the 2016 victory of AlphaGo against the Go world champion. These significant milestones exemplify the power of machine learning approaches, predominantly driven by neural networks.

以联结主义或神经系统为代表的感知，以及以符号主义或符号系统为代表的认知，是人工智能(AI)领域的两大基本范式，每种范式都曾盛行数十年。图1展示了这两种学说的兴衰，研究人员通常将其分为三个重要时期。(1)20世纪60 - 70年代(1956 - 1968年)。人工智能中推理的起源可以追溯到1956年的达特茅斯会议，在那次会议上，纽厄尔和西蒙推出了“逻辑理论家”程序，成功证明了38条数学定理。这标志着人工智能推理时代的开端。然而，研究人员很快意识到，仅依靠启发式搜索算法存在局限性，许多复杂问题需要专业领域知识才能实现更高水平的智能。因此，将知识融入人工智能模型成为一种流行的理念，因为它增强了在大型解空间中寻找解决方案的能力。(2)20世纪70 - 90年代(1968 - 1985年)。在此期间，出现了重大进展，例如1968年费根保姆和莱德伯格创建了第一个专家系统“Dendral”。这一里程碑代表了人工智能与领域知识的有机结合，标志着人工智能以知识为中心时代的到来。然而，知识获取是一个重大挑战，这导致人们转向从海量数据集中自动获取有价值的知识，这逐渐成为人工智能的主流趋势。(3)从20世纪90年代至今:1983年，神经网络开始崭露头角，2000年后，人工智能进入机器学习时代。机器学习领域的显著突破，尤其是通过神经网络取得的突破，包括2012年深度卷积神经网络(CNN)在ImageNet竞赛中的胜利，以及2016年AlphaGo战胜围棋世界冠军。这些重大里程碑体现了主要由神经网络驱动的机器学习方法的强大力量。

To date, neural networks have demonstrated remarkable accomplishments in perception-related tasks, such as image recognition (Rissati, Molina, & Anjos, 2020). However, there exist various scenarios, including question answering (Gupta, Patro, Parihar, & Namboodiri, 2022), medical diagnosis (Salahuddin, Woodruff, Chatterjee, & Lambin, 2022), and autonomous driving (Wen & Jo, 2022), where relying solely on perception can present limitations or yield unsatisfactory outcomes. For instance, when confronted with unseen situations during training, machines may struggle to make accurate decisions in medical diagnosis. Another crucial consideration is the compatibility of purely perception-based models with the principles of explainable AI (Ratti & Graves, 2022). Neural networks, being black-box systems, are unable to provide explicit calculation processes. In contrast, symbolic systems offer enhanced appeal in terms of reasoning and interpretability. For example, through deductive reasoning and automatic theorem proving, symbolic systems can generate additional information and elucidate the reasoning process employed by the model.

到目前为止，神经网络在与感知相关的任务中取得了显著成就，如图像识别(里萨蒂、莫利纳和安若斯，2020年)。然而，存在各种场景，包括问答(古普塔、帕德罗、帕里哈尔和南布迪里，2022年)、医学诊断(萨拉胡丁、伍德拉夫、查特吉和兰宾，2022年)和自动驾驶(温与乔，2022年)，在这些场景中仅依靠感知可能会存在局限性或产生不理想的结果。例如，在训练过程中遇到未见情况时，机器在医学诊断中可能难以做出准确决策。另一个关键考虑因素是纯基于感知的模型与可解释人工智能原则的兼容性(拉蒂和格雷夫斯，2022年)。神经网络作为黑箱系统，无法提供明确的计算过程。相比之下，符号系统在推理和可解释性方面更具吸引力。例如，通过演绎推理和自动定理证明，符号系统可以生成额外信息并阐明模型所采用的推理过程。

Consequently, an increasing number of researchers have directed their attention towards the fusion of neural systems and symbolic systems, aiming to achieve the third wave of AI: neural-symbolic learning systems (Dong et al., 2019; Evans & Grefenstette, 2018; Manhaeve, Dumančić, Kimmig, Demeester, & De Raedt, 2018; Mao, Gan, Kohli, Tenenbaum, & Wu, 2019; Marra, Giannini, Diligenti, & Gori, 2019; Zhou, 2019). In a special NeurIPS 2019 lecture, Turing Award laureate Yoshua Bengio drew inspiration from Dr. Daniel Kahneman's renowned book "Thinking Fast and Slow" (Kahneman, 2011) to emphasize the need for a system-1-to-system-2 transformation in deep learning. Here, system 1 represents the intuitive, rapid, unconscious, nonlinguistic, and habitual aspects, while system 2 embodies the deliberative, logical, sequential, conscious, linguistic, algorithmic, planning-related, and reasoning-related facets. Indeed, since the 1990s, numerous researchers in the fields of artificial intelligence and cognitive science have explicitly proposed the concept of dual processes that correspond to these contrasting systems (Honavar, 1995). These highlight the necessity of combining neural systems and symbolic systems. By unifying these two system types within a comprehensive framework, neural-symbolic learning systems can be created, endowing AI with the capability to perform both perception and reasoning tasks. It is worth noting that the idea of integrating neural systems and symbolic systems, referred to as hybrid connectionist-symbolic models, was initially introduced in the 1990s (Sun & Bookman, 1994).

因此，越来越多的研究人员将注意力转向神经网络系统和符号系统的融合，旨在实现人工智能的第三次浪潮:神经符号学习系统(董等人，2019年；埃文斯和格雷芬施泰特，2018年；曼哈埃夫、杜曼契奇、基米希、德梅斯特和德雷德特，2018年；毛、甘、科利、特南鲍姆和吴，2019年；马拉、詹尼尼、迪利根蒂和戈里，2019年；周，2019年)。在2019年神经信息处理系统大会(NeurIPS)的一次特别演讲中，图灵奖得主约书亚·本吉奥从丹尼尔·卡尼曼博士的著名著作《思考，快与慢》(卡尼曼，2011年)中获得灵感，强调深度学习需要从系统1向系统2转变。在这里，系统1代表直觉、快速、无意识、非语言和习惯性的方面，而系统2体现深思熟虑、逻辑、顺序、有意识、语言、算法、规划相关和推理相关的方面。事实上，自20世纪90年代以来，人工智能和认知科学领域的众多研究人员已经明确提出了对应于这些对比系统的双过程概念(霍纳瓦尔，1995年)。这些都凸显了将神经网络系统和符号系统相结合的必要性。通过在一个综合框架内统一这两种系统类型，可以创建神经符号学习系统，使人工智能具备执行感知和推理任务的能力。值得注意的是，将神经网络系统和符号系统集成的想法，即混合连接主义 - 符号模型，最初是在20世纪90年代提出的(孙和布克曼，1994年)。

Neural-symbolic learning systems leverage the combine strengths of both neural systems and symbolic systems (Besold et al., 2017; Dragone, Teso, & Passerini, 2021; Garcez et al., 2015; Garcez, Broda, & Gabbay, 2012; Garcez & Zaverucha, 1999; Karpas et al., 2022; Kaur et al., 2017; Landajuela et al., 2021; Levine et al., 2022; Manhaeve, De Raedt, Kimmig, Dumancic, & Demeester, 2019; Perotti et al., 2012; Sourek, Aschenbrenner, Zelezny, Schockaert, & Kuzelka, 2018; Towell & Shavlik, 1994; Zuidberg Dos Martires, Kumar, Persson, Loutfi, & De Raedt, 2020). To provide a comprehensive understanding, the survey initially outlines key characteristics of symbolic systems and neural systems (refer to Table 1), including processing methods, knowledge representation, etc. Analysis of Table 1 reveals that symbolic systems and neural systems exhibit complementary features across various aspects. For instance, symbolic systems may possess limited robustness, whereas neural systems demonstrate robustness. Consequently, neural-symbolic learning systems emerge as a means to compensate for the shortcomings inherent in individual systems.

神经符号学习系统利用了神经网络系统和符号系统的综合优势(贝索尔德等人，2017年；德拉戈内、特索和帕塞里尼，2021年；加尔塞斯等人，2015年；加尔塞斯、布罗达和加贝，2012年；加尔塞斯和扎韦鲁查，1999年；卡尔帕斯等人，2022年；考尔等人，2017年；兰达胡埃拉等人，2021年；莱文等人，2022年；曼哈埃夫、德雷德特、基米希、杜曼契奇和德梅斯特，2019年；佩罗蒂等人，2012年；苏雷克、阿申布伦纳、泽莱兹尼、肖卡特和库泽尔卡，2018年；托尔韦尔和沙夫利克，1994年；祖伊德伯格·多斯·马蒂雷斯、库马尔、佩尔松、卢特菲和德雷德特，2020年)。为了提供全面的理解，本综述首先概述了符号系统和神经网络系统的关键特征(参见表1)，包括处理方法、知识表示等。对表1的分析表明，符号系统和神经网络系统在各个方面表现出互补的特征。例如，符号系统的鲁棒性可能有限，而神经网络系统则具有鲁棒性。因此，神经符号学习系统成为弥补单个系统固有缺陷的一种手段。

Moreover, we conduct an analysis of neural-symbolic learning systems from three key perspectives: efficiency, generalization, and interpretability. As depicted in Fig. 2, neural-symbolic learning systems excel in these areas. Firstly, in terms of efficiency, neural-symbolic learning systems can reason quickly compared to pure symbolic systems, thereby reducing computational complexity (Zhang et al., 2020). This accelerated computation can be attributed to the integration of neural networks, as outlined in Section 2 (Learning for reasoning). Traditional symbolic approaches typically employ search algorithms to navigate solution spaces, leading to increased computational complexity as the search space grows in size. Secondly, with regard to generalization, neural-symbolic learning systems outperform standalone neural systems in terms of their capacity for generalization. The incorporation of symbolic knowledge as valuable training data enhances the model's generalization abilities (Kampffmeyer et al., 2019) (see Section 2 Reasoning for learning). Thirdly, in terms of interpretability, neural-symbolic learning systems represent gray-box systems, in contrast to standalone neural systems. By leveraging symbolic knowledge, these systems can provide explicit computation processes, such as traced reasoning processes or chains of evidence for results (Yang & Song, 2020). Consequently, neural-symbolic learning systems have emerged as vital components of explainable AI, yielding superior performance across diverse domains, including computer vision (Chen et al., 2020; Donadello, Serafini, & Garcez, 2017; Kampffmeyer et al., 2019; Li, Luo, Lu, Xiang, & Wang, 2019; Wang, Ye, & Gupta, 2018; Xie, Xu, Kankanhalli, Meel, & Soh, 2019; Zhu, Fathi, & Fei-Fei, 2014), and natural language processing (Liang, Berant, Le, Forbus, & Lao, 2017; Tian et al., 2022; Yi et al., 2018), etc.

此外，我们从三个关键视角对神经符号学习系统进行了分析:效率、泛化能力和可解释性。如图2所示，神经符号学习系统在这些方面表现出色。首先，在效率方面，与纯符号系统相比，神经符号学习系统能够快速推理，从而降低计算复杂度(Zhang等人，2020)。这种加速计算可归因于神经网络的集成，如第2节(推理学习)所述。传统的符号方法通常采用搜索算法来遍历解空间，随着搜索空间的增大，计算复杂度也会增加。其次，在泛化能力方面，神经符号学习系统在泛化能力上优于独立的神经系统。将符号知识作为有价值的训练数据纳入其中，可增强模型的泛化能力(Kampffmeyer等人，2019)(见第2节学习推理)。第三，在可解释性方面，与独立的神经系统相比，神经符号学习系统属于灰盒系统。通过利用符号知识，这些系统可以提供明确的计算过程，如追踪推理过程或结果的证据链(Yang & Song，2020)。因此，神经符号学习系统已成为可解释人工智能的重要组成部分，在包括计算机视觉(Chen等人，2020；Donadello、Serafini和Garcez，2017；Kampffmeyer等人，2019；Li、Luo、Lu、Xiang和Wang，2019；Wang、Ye和Gupta，2018；Xie、Xu、Kankanhalli、Meel和Soh，2019；Zhu、Fathi和Fei - Fei，2014)和自然语言处理(Liang、Berant、Le、Forbus和Lao，2017；Tian等人，2022；Yi等人，2018)等不同领域都表现出卓越的性能。

![0195ea36-14ee-7c5c-a9a7-c1c11f9ac59f_2_320_148_1104_470_0.jpg](images/0195ea36-14ee-7c5c-a9a7-c1c11f9ac59f_2_320_148_1104_470_0.jpg)

Fig. 1. The brief history of artificial intelligence.

图1. 人工智能简史。

Table 1

表1

Summarize properties for the symbolic systems and neural systems separately.

分别总结符号系统和神经系统的特性。

<table><tr><td>Systems representation</td><td>Processing methods</td><td>Knowledge representation</td><td>Primary algorithms</td><td>Advantages</td><td>Disadvantages</td></tr><tr><td rowspan="3">Symbolic systems</td><td/><td/><td/><td>Strong generalization ability</td><td>Weak at handling unstructured data</td></tr><tr><td>Deductive reasoning</td><td>Logical representation</td><td>Logical deduction</td><td>Good interpretability</td><td>Weak robustness</td></tr><tr><td/><td/><td/><td>Knowledge-driven</td><td>Slow reasoning</td></tr><tr><td rowspan="2">Neural systems (Sub-symbolic systems)</td><td rowspan="2">Inductive learning</td><td>Distributed</td><td>BP algorithms</td><td>Strong at handling unstructured data Strong robustness</td><td>Weak generalizability (adaptability) Lack of interpretability</td></tr><tr><td/><td/><td>Fast learning</td><td>Data-driven</td></tr></table>

<table><tbody><tr><td>系统表示</td><td>处理方法</td><td>知识表示</td><td>主要算法</td><td>优点</td><td>缺点</td></tr><tr><td rowspan="3">符号系统</td><td></td><td></td><td></td><td>强泛化能力</td><td>处理非结构化数据能力弱</td></tr><tr><td>演绎推理</td><td>逻辑表示</td><td>逻辑演绎</td><td>良好的可解释性</td><td>鲁棒性弱</td></tr><tr><td></td><td></td><td></td><td>知识驱动</td><td>推理速度慢</td></tr><tr><td rowspan="2">神经网络系统(亚符号系统)</td><td rowspan="2">归纳学习</td><td>分布式</td><td>BP算法</td><td>处理非结构化数据能力强 鲁棒性强</td><td>泛化能力(适应性)弱 缺乏可解释性</td></tr><tr><td></td><td></td><td>快速学习</td><td>数据驱动</td></tr></tbody></table>

Challenge: Symbolic systems and neural systems diverge in terms of their data representations and problem-solving approaches. Symbolic systems rely on discrete symbolic representations and traditional search algorithms to discover solutions, while neural systems employ continuous feature vector representations and neural cells to learn mapping functions. Consequently, a significant challenge lies in designing a unified framework that seamlessly integrates both symbolic and neural components. The aim is to strike a balance and select an appropriate combination of symbolic and neural systems that aligns with the requirements of the specific problem (Honavar, 1995).

挑战:符号系统和神经系统在数据表示和解决问题的方法上存在差异。符号系统依靠离散的符号表示和传统的搜索算法来寻找解决方案，而神经系统则采用连续的特征向量表示和神经细胞来学习映射函数。因此，一个重大挑战在于设计一个能够无缝集成符号和神经组件的统一框架。目标是实现平衡，并选择一种与特定问题要求相匹配的符号系统和神经系统的适当组合(霍纳瓦尔，1995年)。

![0195ea36-14ee-7c5c-a9a7-c1c11f9ac59f_2_905_1117_730_521_0.jpg](images/0195ea36-14ee-7c5c-a9a7-c1c11f9ac59f_2_905_1117_730_521_0.jpg)

Fig. 2. The advantages of neural-symbolic learning systems with respect to model efficiency, generalization, and interpretability. The neural systems are black-box systems, while symbolic systems are white-box systems.

图2. 神经符号学习系统在模型效率、泛化能力和可解释性方面的优势。神经系统是黑箱系统，而符号系统是白箱系统。

To provide new readers with a comprehensive understanding of neural-symbolic learning systems, this paper surveys representative research and applications of these systems. To summarize and systematically review related works, there are several surveys conducted during the past few years (Andrews, Diederich, & Tickle, 1995; Besold et al., 2017; Calegari, Ciatto, & Omicini, 2020; Garcez, Broda, Gabbay, et al., 2002; Garcez & Lamb, 2020; Kautz, 2022; Lamb et al., 2020; Marcus, 2020; Marra, Dumančić, Manhaeve & De Raedt, 2020; Sun & Alexandre, 2013; Sun & Bookman, 1994; Townsend, Chaton, & Monteiro, 2019, 2020; Von Rueden et al., 2021). For example, Andrews et al. (1995) and Townsend et al. (2019) center around knowledge extraction techniques, which aligns with the first category discussed in Section 2. On the other hand, Calegari et al. (2020), Lamb et al. (2020), Marra, Dumančić et al. (2020) and Von Rueden et al. (2021) provide detailed reviews from specific perspectives, such as graph neural networks (GNNs), prior knowledge integration, explainable artificial intelligence (XAI), and statistical relational learning. While surveys (Besold et al., 2017; Garcez & Lamb, 2020) also cover neural-symbolic learning systems comprehensively, their focus remains primarily theoretical, lacking a thorough introduction to specific techniques and related works. Therefore, an urgent need arises to provide a comprehensive survey that encompasses popular methods and specific techniques (e.g., model frameworks, execution processes) to expedite advancements in the neural-symbolic field. Distinguishing itself from the aforementioned surveys, this paper emphasizes classifications, techniques, and applications within the domain of neural-symbolic learning systems.

为了让新读者全面了解神经符号学习系统，本文对这些系统的代表性研究和应用进行了综述。为了总结和系统回顾相关工作，过去几年进行了多项综述(安德鲁斯、迪德里希和蒂克尔，1995年；贝索尔德等人，2017年；卡莱加里、恰托和奥米西尼，2020年；加尔塞斯、布罗达、加贝等人，2002年；加尔塞斯和兰姆，2020年；考茨，2022年；兰姆等人，2020年；马库斯，2020年；马拉、杜曼契奇、曼哈埃夫和德雷德特，2020年；孙和亚历山大，2013年；孙和布克曼，1994年；汤森、查顿和蒙泰罗，2019年、2020年；冯·鲁登等人，2021年)。例如，安德鲁斯等人(1995年)和汤森等人(2019年)围绕知识提取技术展开，这与第2节讨论的第一类相契合。另一方面，卡莱加里等人(2020年)、兰姆等人(2020年)、马拉、杜曼契奇等人(2020年)和冯·鲁登等人(2021年)从特定视角进行了详细综述，如图神经网络(GNN)、先验知识整合、可解释人工智能(XAI)和统计关系学习。虽然综述(贝索尔德等人，2017年；加尔塞斯和兰姆，2020年)也全面涵盖了神经符号学习系统，但它们主要侧重于理论，缺乏对特定技术和相关工作的深入介绍。因此，迫切需要提供一个全面的综述，涵盖流行的方法和特定技术(如模型框架、执行过程)，以加速神经符号领域的发展。与上述综述不同，本文强调神经符号学习系统领域内的分类、技术和应用。

Motivation: For our part, we do not seek to replace the above literature but complement them by offering a comprehensive overview of the broader domain of neural-symbolic learning systems. This encompasses various technologies, cutting-edge developments, and diverse application areas within the realm of neural-symbolic learning systems. Additionally, this article caters to individuals engaged in the pursuit of integrating symbolic systems and neural systems. With an emphasis on integration, we present a novel classification framework for neural-symbolic learning systems in Section 2.

动机:就我们而言，我们并非试图取代上述文献，而是通过全面概述神经符号学习系统的更广泛领域来对其进行补充。这包括神经符号学习系统领域内的各种技术、前沿发展和不同应用领域。此外，本文面向致力于整合符号系统和神经系统的人士。我们在第2节中强调整合，提出了一种新颖的神经符号学习系统分类框架。

Our contributions can be summarized as follows:

我们的贡献可总结如下:

(1) We propose a novel taxonomy of neural-symbolic learning systems. Neural-symbolic learning systems are categorized into three groups: learning for reasoning, reasoning for learning, and learning-reasoning.

(1)我们提出了一种新颖的神经符号学习系统分类法。神经符号学习系统分为三类:推理学习、学习推理和学习 - 推理。

(2) We provide a comprehensive overview of neural-symbolic techniques, along with types and representations of symbols such as logic knowledge and knowledge graphs. For each taxonomy, we provide detailed descriptions of the representative methods, summarize the corresponding characteristics, and give a new understanding of neural-symbolic learning systems.

(2)我们全面概述了神经符号技术，以及逻辑知识和知识图谱等符号的类型和表示。对于每个分类，我们详细描述了代表性方法，总结了相应的特征，并对神经符号学习系统有了新的理解。

(3) We discuss the applications of neural-symbolic learning systems and propose four potential future research directions, thus paving the way for further advancements and exploration in this field.

(3)我们讨论了神经符号学习系统的应用，并提出了四个潜在的未来研究方向，从而为该领域的进一步发展和探索铺平了道路。

The remainder of this survey is organized as follows. In Section 2, we categorize the different methods of neural-symbolic learning systems. Section 3 introduces the main technologies of neural-symbolic learning systems. We summarize the main applications of neural-symbolic learning systems in Section 4. Section 5 discusses the future research directions, after which Section 6 concludes this survey.

本综述的其余部分组织如下。在第2节中，我们对神经符号学习系统的不同方法进行分类。第3节介绍神经符号学习系统的主要技术。我们在第4节中总结神经符号学习系统的主要应用。第5节讨论未来的研究方向，之后第6节对本综述进行总结。

## 2. Categorization and frameworks

## 2. 分类与框架

In this section, we first introduce the theory and formal definition of neural-symbolic learning systems. We will then proceed to summarize the taxonomy of neural-symbolic methods and discuss the frameworks that underpin these taxonomies. In this survey, we use a color scheme to represent the different components of neural-symbolic learning systems: green represents symbolic systems, and blue represents neural systems within the frameworks.

在本节中，我们首先介绍神经符号学习系统的理论和形式定义。然后，我们将总结神经符号方法的分类，并讨论支撑这些分类的框架。在本综述中，我们使用一种配色方案来表示神经符号学习系统的不同组件:绿色代表符号系统，蓝色代表框架内的神经系统。

Neural-symbolic learning systems are hybrid models that leverage the strengths of both neural systems and symbolic systems. To illustrate the relationships and characteristics between these systems, we provide a schematic diagram in Fig. 3. The green rectangle represents symbolic systems, which employ reasoning-based approaches to find solutions. Symbolic systems typically operate on structured data, such as logic rules, knowledge graphs, or time series data. Their fundamental unit of information processing is symbols. Through training, symbolic systems acquire the solution space of a search algorithm for a specific task and output higher-level reasoning results. On the other hand, the blue rectangle in the figure represents neural systems, which excel at learning-based approaches to approximate the ground truth. Neural systems usually operate on unstructured data, such as images, videos, or texts, and their primary information processing unit is a vector. Through training, neural systems learn a mapping function for a specific task and output lower-level learning results. The outer blue box represents neural-symbolic learning systems, which encompass the characteristics of both symbolic and neural systems (as summarized in Table 1). These systems combine the reasoning capabilities of symbolic systems with the learning capabilities of neural systems to achieve a comprehensive and integrated approach to problem-solving.

神经符号学习系统是一种混合模型，它充分利用了神经系统和符号系统的优势。为了说明这些系统之间的关系和特点，我们在图3中提供了一个示意图。绿色矩形代表符号系统，它采用基于推理的方法来寻找解决方案。符号系统通常处理结构化数据，如逻辑规则、知识图谱或时间序列数据。其信息处理的基本单元是符号。通过训练，符号系统获取特定任务搜索算法的解空间，并输出更高级别的推理结果。另一方面，图中的蓝色矩形代表神经系统，它擅长基于学习的方法来逼近真实情况。神经系统通常处理非结构化数据，如图像、视频或文本，其主要的信息处理单元是向量。通过训练，神经系统学习特定任务的映射函数，并输出较低级别的学习结果。外部的蓝色框代表神经符号学习系统，它兼具符号系统和神经系统的特点(如表1所示)。这些系统将符号系统的推理能力与神经系统的学习能力相结合，以实现一种全面、综合的问题解决方法。

Based on the above description, the final objective of neural-symbolic learning systems is to find a function $F$ that can effectively map data $x$ and symbol $s$ (pre-defined or obtained via computation) to ground-truth $y$ . The formal definition is as follows:

基于上述描述，神经符号学习系统的最终目标是找到一个函数 $F$，该函数能够有效地将数据 $x$ 和符号 $s$(预定义或通过计算获得)映射到真实值 $y$。其正式定义如下:

$$
\forall \left( {x, y}\right)  \in  {DF}\left( {x, s}\right)  \rightarrow  y. \tag{1}
$$

In this survey, the neural systems mainly refer to deep learning (or deep neural networks), while symbolic systems include symbolic knowledge (Bosselut et al., 2019; Davis, 2017; Tandon, Varde, & de Melo, 2018) and symbolic reasoning techniques (Dar-wiche, 2011; Safavian & Landgrebe, 1991), etc. The methodology of our classification is determined by the integration mode between neural systems and symbolic systems, which has three main integration methodologies. These three classifications are similar to Kautz (2022) from essence but include it.

在本综述中，神经系统主要指深度学习(或深度神经网络)，而符号系统包括符号知识(Bosselut等人，2019年；Davis，2017年；Tandon、Varde和de Melo，2018年)和符号推理技术(Dar - wiche，2011年；Safavian和Landgrebe，1991年)等。我们的分类方法由神经系统和符号系统之间的集成模式决定，主要有三种集成方法。这三种分类从本质上与Kautz(2022年)的分类相似，但包含了其内容。

### 2.1. Learning for reasoning

### 2.1. 为推理而学习

In the first category, which we refer to as learning for reasoning, the goal is to leverage symbolic systems for reasoning while incorporating the advantages of neural networks to facilitate finding solutions (Abboud, Ceylan, & Lukasiewicz, 2020; Das et al., 2017; Das, Neelakantan, Belanger, & McCallum, 2016; Dos Martires et al., 2019; Ellis, Morales, Sablé-Meyer, Solar Lezama, & Tenenbaum, 2018; Evans & Grefenstette, 2018; Garcez, Dutra, & Alonso, 2018; Garcez et al., 2019; Garnelo, Arulkumaran, & Shanahan, 2016; Hudson & Manning, 2018, 2019; Kalyan et al., 2018; Meilicke, Chekol, Fink, & Stuckenschmidt, 2020; Neelakan-tan, Roth, & McCallum, 2015; Nye, Hewitt, Tenenbaum, & Solar-Lezama, 2019; Prates, Avelar, Lemos, Lamb, & Vardi, 2019; Qu & Tang, 2020; Riegel et al., 2020; Serafini & Garcez, 2016; Teru, Denis, & Hamilton, 2020; Wang, Dou, Wu, de Silva, & Jin, 2019; Xiong, Hoang, & Wang, 2017; Yang & Song, 2020; Zhang et al., 2020). In the context of learning for reasoning, there are two main aspects to consider. The first aspect involves the use of neural networks to reduce the search space of symbolic systems, thereby accelerating computation (Abboud et al., 2020; Nye et al., 2019; Prates et al., 2019; Qu & Tang, 2020; Zhang et al., 2020). This can be achieved by replacing traditional symbolic reasoning algorithms with neural networks. The neural network effectively reduces the search space, making the computation more efficient. The second aspect of learning for reasoning is the abstraction or extraction of symbols from data using neural networks to facilitate symbolic reasoning (Garcez et al., 2019; Riegel et al., 2020; Serafini & Garcez, 2016). In this case, neural networks serve as a means of acquiring knowledge for symbolic reasoning tasks. They learn to extract meaningful symbols from input data and use them for subsequent reasoning processes. The basic framework for learning for reasoning is illustrated in Fig. 4. As depicted in the figure, this type of model is characterized by a serialization process, where the neural network component as accelarator and transformer.

在我们称之为推理学习的第一类中，目标是在利用符号系统进行推理的同时，结合神经网络的优势以促进解决方案的寻找(阿博德、塞兰和卢卡西维茨，2020年；达斯等人，2017年；达斯、尼尔坎坦、贝朗热和麦卡勒姆，2016年；多斯·马丁雷斯等人，2019年；埃利斯、莫拉莱斯、萨布莱 - 迈耶、索拉尔·莱萨马和特南鲍姆，2018年；埃文斯和格雷芬施泰特，2018年；加尔塞斯、杜特拉和阿隆索，2018年；加尔塞斯等人，2019年；加内洛、阿鲁库马兰和沙纳汉，2016年；哈德森和曼宁，2018年、2019年；卡利安等人，2018年；迈利克、切科尔、芬克和施图肯施密特，2020年；尼尔坎坦、罗斯和麦卡勒姆，2015年；奈伊、休伊特、特南鲍姆和索拉尔 - 莱萨马，2019年；普拉特斯、阿韦拉尔、莱莫斯、兰姆和瓦尔迪，2019年；曲和唐，2020年；里格尔等人，2020年；塞拉菲尼和加尔塞斯，2016年；特鲁、丹尼斯和汉密尔顿，2020年；王、窦、吴、德席尔瓦和金，2019年；熊、黄和王，2017年；杨和宋，2020年；张等人，2020年)。在推理学习的背景下，有两个主要方面需要考虑。第一个方面涉及使用神经网络来缩小符号系统的搜索空间，从而加速计算(阿博德等人，2020年；奈伊等人，2019年；普拉特斯等人，2019年；曲和唐，2020年；张等人，2020年)。这可以通过用神经网络取代传统的符号推理算法来实现。神经网络有效地缩小了搜索空间，使计算更加高效。推理学习的第二个方面是使用神经网络从数据中抽象或提取符号，以促进符号推理(加尔塞斯等人，2019年；里格尔等人，2020年；塞拉菲尼和加尔塞斯，2016年)。在这种情况下，神经网络作为为符号推理任务获取知识的一种手段。它们学习从输入数据中提取有意义的符号，并将其用于后续的推理过程。推理学习的基本框架如图4所示。如图所示，这种类型的模型具有序列化过程的特点，其中神经网络组件作为加速器和转换器。

Table 2

表2

Main Approaches of neural-symbolic learning systems. Taxonomies of the approaches and combination modes are presented in Section 2. Methodical details can be found in Section 3. The symbols and neural networks used herein are introduced in Appendix, and "Agnostic" means arbitrary neural networks. "Serialization", "parallelization" and "interaction" are combination modes, respectively. Applications are discussed in Section 5.

神经符号学习系统的主要方法。方法和组合模式的分类在第2节中介绍。方法细节可在第3节中找到。本文使用的符号和神经网络在附录中介绍，“不可知”表示任意神经网络。“序列化”、“并行化”和“交互”分别是组合模式。应用在第5节中讨论。

<table><tr><td>Representative works</td><td>Taxonomies</td><td>Methods</td><td>Symbols</td><td>Neural networks Applications</td><td/></tr><tr><td rowspan="4">pLogicNet (Qu & Tang, 2020) ExpressGNN (Zhang et al., 2020) RNM (Marra, Diligenti, Giannini, Gori & Maggini, 2020) NMLN (Marra & Kuželka, 2021) NLIL (Yang & Song, 2020)</td><td rowspan="5">Learning for reasoning (Serialization)</td><td rowspan="4">Accelerating</td><td rowspan="7">First-order logic</td><td>GNN</td><td>Knowledge graph reasoning</td></tr><tr><td>CNN</td><td>Classification</td></tr><tr><td>GNN</td><td>Knowledge graph reasoning</td></tr><tr><td>CNN, GNN</td><td>Classification and knowledge graph reasoning</td></tr><tr><td>NS-CL (Mao et al., 2019)</td><td>Absracting</td><td>RNN</td><td>Visual question answering</td></tr><tr><td>HDNN (Hu, Ma, Liu, Hovy, & Xing, 2016)</td><td rowspan="8">Reasoning for learning (Parallelization)</td><td rowspan="5">Reguariziting</td><td>Agnostic</td><td>Object recognition</td></tr><tr><td>SBR (Diligenti, Gori, & Sacca, 2017)</td><td>CNN</td><td rowspan="2">Classification</td></tr><tr><td>SL (Xu, Zhang, Friedman, Liang, & Broeck, 2018)</td><td rowspan="2">Propositional logic</td><td>Agnostic</td></tr><tr><td>LENSR (Xie et al., 2019)</td><td rowspan="2">CNN, GNN</td><td>Visual relationship detection</td></tr><tr><td>CA-ZSL (Luo, Zhang, Han, & Yang, 2020) LSFSL (Li et al., 2019)</td><td rowspan="3">Knowledge graph</td><td rowspan="3">Few-shot classification</td></tr><tr><td>SEKB-ZSL (Wang et al., 2018)</td><td rowspan="3">Transfering</td><td>GNN</td></tr><tr><td>DGP (Kampffmeyer et al., 2019) KGTN (Chen et al., 2020)</td><td>CNN, GNN</td></tr><tr><td>PROLONETS (Silva & Gombolay, 2021)</td><td>Propositional logic</td><td>GNN</td><td>Reinforcement learning</td></tr><tr><td>DeepProLog (Manhaeve et al., 2018) ABL (Zhou, 2019)</td><td rowspan="4">Learning-reasoning (Interaction)</td><td rowspan="4">Interacting</td><td rowspan="4">First-order logic</td><td>Agnostic</td><td rowspan="3">Complex reasoning</td></tr><tr><td>GABL (Cai et al., 2021)</td><td>CNN</td></tr><tr><td>WS-NeSyL (Tian et al., 2022)</td><td>RNN</td></tr><tr><td>BPGR (Yu, Yang, Wei, Li, & Pan, 2022)</td><td>CNN</td><td>Visual relationship detection</td></tr></table>

<table><tbody><tr><td>代表作</td><td>分类法</td><td>方法</td><td>符号</td><td>神经网络应用</td><td></td></tr><tr><td rowspan="4">pLogicNet(曲和唐，2020年)；ExpressGNN(张等人，2020年)；RNM(马拉、迪利根蒂、詹尼尼、戈里和马吉尼，2020年)；NMLN(马拉和库泽尔卡，2021年)；NLIL(杨和宋，2020年)</td><td rowspan="5">推理学习(序列化)</td><td rowspan="4">加速</td><td rowspan="7">一阶逻辑</td><td>图神经网络(GNN)</td><td>知识图谱推理</td></tr><tr><td>卷积神经网络(CNN)</td><td>分类</td></tr><tr><td>图神经网络(GNN)</td><td>知识图谱推理</td></tr><tr><td>卷积神经网络(CNN)，图神经网络(GNN)</td><td>分类与知识图谱推理</td></tr><tr><td>NS - CL(毛等人，2019年)</td><td>抽象化</td><td>循环神经网络(RNN)</td><td>视觉问答</td></tr><tr><td>HDNN(胡、马、刘、霍维、邢，2016年)</td><td rowspan="8">学习推理(并行化)</td><td rowspan="5">正则化</td><td>不可知论的</td><td>目标识别</td></tr><tr><td>SBR(迪利根蒂、戈里和萨卡，2017年)</td><td>卷积神经网络(CNN)</td><td rowspan="2">分类</td></tr><tr><td>SL(徐、张、弗里德曼、梁和布罗克，2018年)</td><td rowspan="2">命题逻辑</td><td>不可知论的</td></tr><tr><td>LENSR(谢等人，2019年)</td><td rowspan="2">卷积神经网络(CNN)，图神经网络(GNN)</td><td>视觉关系检测</td></tr><tr><td>CA - ZSL(罗、张、韩和杨，2020年)；LSFSL(李等人，2019年)</td><td rowspan="3">知识图谱</td><td rowspan="3">小样本分类</td></tr><tr><td>SEKB - ZSL(王等人，2018年)</td><td rowspan="3">迁移</td><td>图神经网络(GNN)</td></tr><tr><td>DGP(坎普夫迈耶等人，2019年)；KGTN(陈等人，2020年)</td><td>卷积神经网络(CNN)，图神经网络(GNN)</td></tr><tr><td>PROLONETS(席尔瓦和贡博拉伊，2021年)</td><td>命题逻辑</td><td>图神经网络(GNN)</td><td>强化学习</td></tr><tr><td>DeepProLog(曼哈埃夫等人，2018年)；ABL(周，2019年)</td><td rowspan="4">学习 - 推理(交互)</td><td rowspan="4">交互</td><td rowspan="4">一阶逻辑</td><td>不可知论的</td><td rowspan="3">复杂推理</td></tr><tr><td>GABL(蔡等人，2021年)</td><td>卷积神经网络(CNN)</td></tr><tr><td>WS - NeSyL(田等人，2022年)</td><td>循环神经网络(RNN)</td></tr><tr><td>BPGR(余、杨、魏、李和潘，2022年)</td><td>卷积神经网络(CNN)</td><td>视觉关系检测</td></tr></tbody></table>

![0195ea36-14ee-7c5c-a9a7-c1c11f9ac59f_4_331_1084_1085_358_0.jpg](images/0195ea36-14ee-7c5c-a9a7-c1c11f9ac59f_4_331_1084_1085_358_0.jpg)

Fig. 3. Schematic diagram of two systems integration. Symbolic systems generally use reasoning technologies, such as logic programs and search algorithms, to obtain a solution based on domain knowledge, such as first-order logic, knowledge graphs, etc. The goal of neural systems is to learn a function from the training samples to predict a solution.

图3. 两种系统集成的示意图。符号系统通常使用推理技术，如逻辑程序和搜索算法，基于领域知识(如一阶逻辑、知识图谱等)来获得解决方案。神经网络系统的目标是从训练样本中学习一个函数以预测解决方案。

### 2.2. Reasoning for learning

### 2.2. 用于学习的推理

In the second category, referred to as reasoning for learning, symbolic systems are utilized to support the learning process of neural systems (Bach, Broecheler, Huang, & Getoor, 2015; Chen et al., 2020, 2018; Diligenti et al., 2017; Donadello et al., 2017, 2017; Forestier, Wemmert, & Puissant, 2013; Hu et al., 2016; Ji, Zhu, Cui, Zhao, & Yang, 2022; Kampffmeyer et al., 2019; Li et al., 2019; Liu, Jiang, & Wei, 2019; Luo et al., 2020; Marszalek & Schmid, 2007; Minervini, Demeester, Rocktäschel, & Riedel, 2017; Nyga, Balint-Benczedi, & Beetz, 2014; Oltramari, Francis, Ilievski, Ma, & Mirzaee, 2021; Poon & Domingos, 2009; Sun et al., 2020; Tran & Davis, 2008; Wang et al., 2018; Xie et al., 2019; Xu et al., 2018; Yang, Lyu, Liu, & Gustafson, 2018; Zhu et al., 2014). The underlying idea in reasoning for learning is to leverage neural systems for machine learning tasks while incorporating symbolic knowledge into the training process to enhance performance and interpretability. Symbolic knowledge is typically encoded in a format suitable for neural networks and used to guide or constrain the learning process (Diligenti et al., 2017; Hu et al., 2016; Xie et al., 2019; Xu et al., 2018). For instance, symbolic knowledge may be represented as a regularization term in the loss function of a specific task. This integration of symbolic knowledge helps improve the learning process and can lead to better generalization and interpretability of the neural models. The basic principle of the reasoning for learning approach is illustrated in Fig. 5. This type of model is characterized by parallelization, where the neural system and symbolic system operate in parallel during the learning process.

在第二类，即所谓的用于学习的推理中，符号系统被用于支持神经网络系统的学习过程(Bach、Broecheler、Huang和Getoor，2015年；Chen等人，2020年、2018年；Diligenti等人，2017年；Donadello等人，2017年、2017年；Forestier、Wemmert和Puissant，2013年；Hu等人，2016年；Ji、Zhu、Cui、Zhao和Yang，2022年；Kampffmeyer等人，2019年；Li等人，2019年；Liu、Jiang和Wei，2019年；Luo等人，2020年；Marszalek和Schmid，2007年；Minervini、Demeester、Rocktäschel和Riedel，2017年；Nyga、Balint - Benczedi和Beetz，2014年；Oltramari、Francis、Ilievski、Ma和Mirzaee，2021年；Poon和Domingos，2009年；Sun等人，2020年；Tran和Davis，2008年；Wang等人，2018年；Xie等人，2019年；Xu等人，2018年；Yang、Lyu、Liu和Gustafson，2018年；Zhu等人，2014年)。用于学习的推理的基本思想是利用神经网络系统进行机器学习任务，同时将符号知识融入训练过程以提高性能和可解释性。符号知识通常以适合神经网络的格式进行编码，并用于指导或约束学习过程(Diligenti等人，2017年；Hu等人，2016年；Xie等人，2019年；Xu等人，2018年)。例如，符号知识可以表示为特定任务损失函数中的一个正则化项。这种符号知识的集成有助于改进学习过程，并能使神经网络模型具有更好的泛化能力和可解释性。用于学习的推理方法的基本原理如图5所示。这类模型的特点是并行化，即在学习过程中神经网络系统和符号系统并行运行。

![0195ea36-14ee-7c5c-a9a7-c1c11f9ac59f_5_349_152_1044_634_0.jpg](images/0195ea36-14ee-7c5c-a9a7-c1c11f9ac59f_5_349_152_1044_634_0.jpg)

Fig. 4. Principle of Learning for reasoning. Its goal is to introduce neural networks to reasoning, a problem that it solves primarily through reasoning technologies.

图4. 用于推理的学习原理。其目标是将神经网络引入推理，这是一个主要通过推理技术解决的问题。

![0195ea36-14ee-7c5c-a9a7-c1c11f9ac59f_5_439_866_867_311_0.jpg](images/0195ea36-14ee-7c5c-a9a7-c1c11f9ac59f_5_439_866_867_311_0.jpg)

Fig. 5. Principle of reasoning for learning. It introduces symbolic knowledge to neural networks, and the main body relies on neural networks to get solutions.

图5. 用于学习的推理原理。它将符号知识引入神经网络，主体依靠神经网络来获得解决方案。

### 2.3. Learning- reasoning

### 2.3. 学习 - 推理

In the third category, referred to as learning-reasoning, the interaction between neural systems and symbolic systems is bidirectional, with both paradigms playing equal roles and working together in a mutually beneficial way (Cai et al., 2021; Gupta, Lin, Roth, Singh, & Gardner, 2020; Manhaeve et al., 2018; Tian et al., 2022; Yu et al., 2022; Zhou, 2019). The goal of learning-reasoning is to strike a balance between the involvement of neural systems and symbolic systems in the problem-solving process. In this approach, the output of the neural network becomes an input to the symbolic reasoning component, and the output of the symbolic reasoning becomes an input to the neural network. By allowing the neural systems and symbolic systems to exchange information and influence each other iteratively, this approach aims to leverage the strengths of both paradigms and enhance the overall problem-solving capability. For example, incorporating symbolic reasoning techniques like abduction enables the design of connections between deep neural networks and symbolic reasoning frameworks (Manhaeve et al., 2019; Yu et al., 2022; Zhou, 2019). In this case, the neural network component generates hypotheses or predictions, which are then used by the symbolic reasoning component to perform logical reasoning or inference. The results from symbolic reasoning can subsequently be fed back to the neural network to refine and improve the predictions. The basic principle of learning-reasoning is illustrated in Fig. 6. This tye of model is characterized by interaction, where the interaction between neural systems and symbolic systems occurs in an alternating fashion. This mode of combining both technologies allow for iterative learning and reasoning, enabling a deeper integration of neural and symbolic approaches. By embracing bidirectional interaction and iterative exchange of information between neural systems and symbolic systems, learning-reasoning approaches aim to maximize the strengths of both paradigms and achieve enhanced problem-solving capabilities in various domains.

在第三类，即学习 - 推理(learning - reasoning)类别中，神经系统和符号系统之间的交互是双向的，两种范式发挥着同等作用，并以互利的方式共同工作(蔡等人，2021年；古普塔、林、罗斯、辛格和加德纳，2020年；曼哈埃夫等人，2018年；田等人，2022年；余等人，2022年；周，2019年)。学习 - 推理的目标是在解决问题的过程中，使神经系统和符号系统的参与达到平衡。在这种方法中，神经网络的输出成为符号推理组件的输入，而符号推理的输出又成为神经网络的输入。通过允许神经系统和符号系统迭代地交换信息并相互影响，这种方法旨在利用两种范式的优势，提高整体解决问题的能力。例如，融入溯因推理等符号推理技术，可以设计深度神经网络和符号推理框架之间的连接(曼哈埃夫等人，2019年；余等人，2022年；周，2019年)。在这种情况下，神经网络组件生成假设或预测，然后符号推理组件利用这些假设或预测进行逻辑推理。符号推理的结果随后可以反馈给神经网络，以完善和改进预测。学习 - 推理的基本原理如图6所示。这种类型的模型以交互为特征，其中神经系统和符号系统之间的交互以交替的方式进行。这种结合两种技术的模式允许进行迭代学习和推理，实现神经方法和符号方法的更深度融合。通过接受神经系统和符号系统之间的双向交互和信息的迭代交换，学习 - 推理方法旨在最大限度地发挥两种范式的优势，在各个领域实现更强的解决问题的能力。

In summary, the above three taxonomies are heterogeneous multi-module architectures in Sun and Alexandre (2013). Learning for reasoning and reasoning for learning are loosely coupled while learning-reasoning is tightly coupled. According to the taxonomy of the neural-symbolic method presented in this paper, we summarize the existing main approaches from six dimensions in Table 2: representative works, taxonomies, methods, symbols, neural networks and applications. In Section 3, we will introduce the details of these approaches, discussing their methodologies, techniques, and characteristics. This will provide readers with a deeper understanding of how neural and symbolic systems are combined in various ways to tackle different problems.

综上所述，上述三种分类是孙和亚历山大(2013年)提出的异构多模块架构。推理式学习(Learning for reasoning)和学习式推理(reasoning for learning)是松耦合的，而学习 - 推理(learning - reasoning)是紧耦合的。根据本文提出的神经符号方法的分类，我们在表2中从六个维度总结了现有的主要方法:代表性作品、分类、方法、符号、神经网络和应用。在第3节中，我们将详细介绍这些方法，讨论它们的方法论、技术和特点。这将使读者更深入地了解神经和符号系统是如何以各种方式结合起来解决不同问题的。

## 3. Methods of neural-symbolic learning systems

## 3. 神经符号学习系统的方法

This section introduces the methods used in neural-symbolic learning systems in three main categories. We aim to distill the representative ideas that provide evidence for the integration between neural networks and symbolic systems, identify the similarities and differences between different methods, and offer guidelines for researchers. The main characteristics of these representative methods are summarized in Table 3.

本节将神经符号学习系统中使用的方法分为三个主要类别进行介绍。我们旨在提炼出为神经网络和符号系统的集成提供依据的代表性思想，找出不同方法之间的异同，并为研究人员提供指导。这些代表性方法的主要特点总结在表3中。

### 3.1. Learning for reasoning

### 3.1. 推理式学习

Learning for reasoning methods leverage neural networks to accelerate the search speed of symbolic reasoning, or to abstract unstructured data for symbolic reasoning. To accelerate symbolic reasoning, we first introduce approaches based on SRL (Koller et al., 2007), such as pLogicNet (Qu & Tang, 2020) and Express-GNN (Zhang et al., 2020). These approaches use neural networks to parameterize the posterior computation of the probabilistic graphical models, which accelerates the search process on solution space. Meanwhile, we investigate several methods based on ILP, such as NLIL (Yang & Song, 2020), in which NLIL automatically induces new logic rules from the data for model learning and reasoning. Next, for abstracting unstructured data, we introduce several representative approaches such as NS-CL (Mao et al., 2019). Specific details about the different models are presented below.

推理式学习方法利用神经网络来加速符号推理的搜索速度，或者对非结构化数据进行抽象以用于符号推理。为了加速符号推理，我们首先介绍基于统计关系学习(SRL，Koller等人，2007年)的方法，如概率逻辑网络(pLogicNet，Qu和Tang，2020年)和可表达图神经网络(Express - GNN，Zhang等人，2020年)。这些方法使用神经网络对概率图模型的后验计算进行参数化，从而加速了解决方案空间的搜索过程。同时，我们研究了几种基于归纳逻辑编程(ILP)的方法，如自然语言归纳逻辑编程(NLIL，Yang和Song，2020年)，其中NLIL可以从数据中自动归纳出新的逻辑规则，用于模型学习和推理。接下来，对于非结构化数据的抽象，我们介绍几种代表性方法，如神经符号概念学习(NS - CL，Mao等人，2019年)。下面将详细介绍不同模型的具体细节。

![0195ea36-14ee-7c5c-a9a7-c1c11f9ac59f_6_349_153_1044_210_0.jpg](images/0195ea36-14ee-7c5c-a9a7-c1c11f9ac59f_6_349_153_1044_210_0.jpg)

Fig. 6. Principle of learning-reasoning. It combines neural networks and reasoning technologies as an alternate process, and both together to output a solution.

图6. 学习 - 推理的原理。它将神经网络和推理技术结合为一个交替的过程，并共同输出一个解决方案。

Table 3

表3

Main characteristics of the selected methods.

所选方法的主要特点。

<table><tr><td>Approaches</td><td>Inputs</td><td>Technology</td><td>Tools</td><td>Mechanism/objective</td></tr><tr><td>pLogicNet (Qu & Tang, 2020)</td><td>X, S</td><td>SRL</td><td>MLN</td><td>learn a joint probability distribution</td></tr><tr><td>ExpressGNN (Zhang et al., 2020)</td><td>X, S</td><td>SRL</td><td>MLN</td><td>learn a joint probability distribution</td></tr><tr><td>NLIL (Yang & Song, 2020)</td><td>$X$</td><td>ILP</td><td>Transformer</td><td>use a Transform to learn rules based ILP</td></tr><tr><td>NS-CL (Mao et al., 2019)</td><td>$X$</td><td>quasi-symbolic program</td><td>concept parser</td><td>reason based on parsing symbols for images and questions</td></tr><tr><td>HDNN (Hu et al., 2016)</td><td>$\mathrm{x},\mathrm{s}$</td><td>regularization</td><td>t-norm</td><td>learn a student network based on knowledge</td></tr><tr><td>SBR (Diligenti et al., 2017)</td><td>x, s</td><td>regularization</td><td>t-norm</td><td>learn a model with logic knowledge as a constraint of the hypothesis space</td></tr><tr><td>SL (Xu et al., 2018)</td><td>X, S</td><td>regularization</td><td>arithmetic circuits</td><td>design a semantic loss to act as a regularization term</td></tr><tr><td>LENSR (Xie et al., 2019)</td><td>x, s</td><td>regularization</td><td>d-DNNF</td><td>align distributions between deep learning and propositional logic</td></tr><tr><td>CA-ZSL (Luo et al., 2020)</td><td>x, s</td><td>regularization</td><td>GCN</td><td>learn a conditional random field</td></tr><tr><td>SEKB-ZSR (Wang et al., 2018)</td><td>x, s</td><td>knowledge transfer</td><td>GCN</td><td>learn a deep learning model with powerful generalization</td></tr><tr><td>DGP (Kampffmeyer et al., 2019)</td><td>x, s</td><td>knowledge transfer</td><td>GCN</td><td>learn network embedding with semantics</td></tr><tr><td>KGTN (Chen et al., 2020)</td><td>x, s</td><td>knowledge transfer</td><td>GGNN</td><td>transfer semantic knowledge into weights</td></tr><tr><td>PROLONETS (Silva & Gombolay, 2021)</td><td>X, S</td><td>knowledge transfer</td><td>decision tree</td><td>transform knowledge into neural network parameters</td></tr><tr><td>DeepProLog (Manhaeve et al., 2018)</td><td>x, s</td><td>ProbLog</td><td>SDD</td><td>construct an interface between probLog program and the deep learning models</td></tr><tr><td>ABL (Zhou, 2019)</td><td>x, s</td><td>abductive reasoning</td><td>SLD</td><td>minimize inconsistency between pseudo-labels and symbolic knowledge</td></tr><tr><td>WS-NeSyL (Tian et al., 2022)</td><td>X, S</td><td>ProLog</td><td>SDD</td><td>learn an encoder-decoder constrained by logic rules</td></tr><tr><td>BPGR (Yu et al., 2022)</td><td>x, s</td><td>SRL</td><td>MLN</td><td>learn a model that fits both the ground truth and FOL</td></tr></table>

<table><tbody><tr><td>方法</td><td>输入</td><td>技术</td><td>工具</td><td>机制/目标</td></tr><tr><td>pLogicNet(曲和唐，2020年)</td><td>X，S</td><td>语义角色标注(Semantic Role Labeling，SRL)</td><td>马尔可夫逻辑网(Markov Logic Network，MLN)</td><td>学习联合概率分布</td></tr><tr><td>ExpressGNN(张等人，2020年)</td><td>X，S</td><td>语义角色标注(Semantic Role Labeling，SRL)</td><td>马尔可夫逻辑网(Markov Logic Network，MLN)</td><td>学习联合概率分布</td></tr><tr><td>NLIL(杨和宋，2020年)</td><td>$X$</td><td>归纳逻辑编程(Inductive Logic Programming，ILP)</td><td>Transformer(变换器)</td><td>使用Transformer学习基于规则的归纳逻辑编程</td></tr><tr><td>NS - CL(毛等人，2019年)</td><td>$X$</td><td>准符号程序</td><td>概念解析器</td><td>基于对图像和问题的符号解析进行推理</td></tr><tr><td>HDNN(胡等人，2016年)</td><td>$\mathrm{x},\mathrm{s}$</td><td>正则化</td><td>t - 范数</td><td>基于知识学习一个学生网络</td></tr><tr><td>SBR(迪利根蒂等人，2017年)</td><td>x，s</td><td>正则化</td><td>t - 范数</td><td>学习一个以逻辑知识作为假设空间约束的模型</td></tr><tr><td>SL(徐等人，2018年)</td><td>X，S</td><td>正则化</td><td>算术电路</td><td>设计一个语义损失作为正则化项</td></tr><tr><td>LENSR(谢等人，2019年)</td><td>x，s</td><td>正则化</td><td>确定性可分解否定范式(deterministic - Decomposable Negation Normal Form，d - DNNF)</td><td>对齐深度学习和命题逻辑之间的分布</td></tr><tr><td>CA - ZSL(罗等人，2020年)</td><td>x，s</td><td>正则化</td><td>图卷积网络(Graph Convolutional Network，GCN)</td><td>学习一个条件随机场</td></tr><tr><td>SEKB - ZSR(王等人，2018年)</td><td>x，s</td><td>知识迁移</td><td>图卷积网络(Graph Convolutional Network，GCN)</td><td>学习一个具有强大泛化能力的深度学习模型</td></tr><tr><td>DGP(坎普夫迈耶等人，2019年)</td><td>x，s</td><td>知识迁移</td><td>图卷积网络(Graph Convolutional Network，GCN)</td><td>学习具有语义的网络嵌入</td></tr><tr><td>KGTN(陈等人，2020年)</td><td>x，s</td><td>知识迁移</td><td>门控图神经网络(Gated Graph Neural Network，GGNN)</td><td>将语义知识转化为权重</td></tr><tr><td>PROLONETS(席尔瓦和贡博拉伊，2021年)</td><td>X，S</td><td>知识迁移</td><td>决策树</td><td>将知识转化为神经网络参数</td></tr><tr><td>DeepProLog(曼哈埃夫等人，2018年)</td><td>x，s</td><td>概率逻辑编程(Probabilistic Logic Programming，ProbLog)</td><td>可分解确定性决策图(Sentential Decision Diagram，SDD)</td><td>构建ProbLog程序和深度学习模型之间的接口</td></tr><tr><td>ABL(周，2019年)</td><td>x，s</td><td>溯因推理</td><td>选择性线性消解(Selective Linear Definite clause resolution，SLD)</td><td>最小化伪标签和符号知识之间的不一致性</td></tr><tr><td>WS - NeSyL(田等人，2022年)</td><td>X，S</td><td>逻辑编程(Prolog)</td><td>可分解确定性决策图(Sentential Decision Diagram，SDD)</td><td>学习一个受逻辑规则约束的编码器 - 解码器</td></tr><tr><td>BPGR(余等人，2022年)</td><td>x，s</td><td>语义角色标注(Semantic Role Labeling，SRL)</td><td>马尔可夫逻辑网(Markov Logic Network，MLN)</td><td>学习一个既符合真实值又符合一阶逻辑(First - Order Logic，FOL)的模型</td></tr></tbody></table>

#### 3.1.1. Accelerating symbolic reasoning

#### 3.1.1. 加速符号推理

In the case of Markov logic networks (MLNs), logic rules are encoded into an undirected graph, and graphical models' inference techniques are used to solve problems. However, performing computations on large-scale graphical models can be challenging. On the other hand, neural networks can easily scale to large datasets, but they cannot directly integrate logic knowledge. While several approximate inference methods have been proposed to address this issue, they often come with high computational costs (Bach et al., 2015; Khot, Natarajan, Kersting, & Shavlik, 2011; Mihalkova & Mooney, 2007; Poon & Domin-gos, 2006; Singla & Domingos, 2005, 2006). To overcome these challenges, researchers have introduced two models: Probabilistic Logic Neural Networks (pLogicNet) (Qu & Tang, 2020) and ExpressGNN (Zhang et al., 2020). Both of these models aim to address the triplet completion problem in knowledge graphs by treating it as an inference problem involving hidden variables in a probability graph. They achieve this by combining variational expectation-maximization (EM) and neural networks to approximate the inference process. The basic process can be summarized as follows:

在马尔可夫逻辑网络(Markov logic networks，MLNs)的情况下，逻辑规则被编码到一个无向图中，并使用图模型的推理技术来解决问题。然而，在大规模图模型上进行计算可能具有挑战性。另一方面，神经网络可以轻松扩展到大型数据集，但它们不能直接整合逻辑知识。虽然已经提出了几种近似推理方法来解决这个问题，但它们通常伴随着较高的计算成本(Bach等人，2015年；Khot、Natarajan、Kersting和Shavlik，2011年；Mihalkova和Mooney，2007年；Poon和Domingos，2006年；Singla和Domingos，2005年、2006年)。为了克服这些挑战，研究人员引入了两种模型:概率逻辑神经网络(Probabilistic Logic Neural Networks，pLogicNet)(Qu和Tang，2020年)和ExpressGNN(Zhang等人，2020年)。这两种模型都旨在通过将知识图中的三元组补全问题视为涉及概率图中隐藏变量的推理问题来解决该问题。它们通过结合变分期望最大化(expectation - maximization，EM)和神经网络来近似推理过程，基本过程可以总结如下:

(1) Model construction: Both pLogicNet and ExpressGNN start by constructing a joint probabilistic model that combines the logic rules encoded in the knowledge graph with the neural network model. This joint model captures the dependencies between observed and hidden variables. (2) Inference approximation: To perform inference, pLogicNet and ExpressGNN utilize a variational EM approach. They define an approximate posterior distribution over the hidden variables and iteratively optimize the model parameters and approximate posterior distribution to maximize the joint probability. (3) Neural network learning: During the optimization process, the neural network parameters are updated based on the observed data, using techniques such as backpropagation and gradient descent. This allows the neural network to learn the underlying patterns and relationships in the data. (4) Inference and prediction: After training, the models can be used for inference and prediction tasks. They can estimate the probabilities of unobserved variables, complete missing values, or make predictions based on the learned dependencies.

(1) 模型构建:pLogicNet和ExpressGNN都从构建一个联合概率模型开始，该模型将知识图中编码的逻辑规则与神经网络模型相结合。这个联合模型捕捉了观测变量和隐藏变量之间的依赖关系。(2) 推理近似:为了进行推理，pLogicNet和ExpressGNN采用变分EM方法。它们定义了一个关于隐藏变量的近似后验分布，并迭代优化模型参数和近似后验分布，以最大化联合概率。(3) 神经网络学习:在优化过程中，基于观测数据使用反向传播和梯度下降等技术更新神经网络参数。这使得神经网络能够学习数据中的潜在模式和关系。(4) 推理和预测:训练完成后，这些模型可用于推理和预测任务。它们可以估计未观测变量的概率、补全缺失值或基于学习到的依赖关系进行预测。

![0195ea36-14ee-7c5c-a9a7-c1c11f9ac59f_7_224_149_1300_433_0.jpg](images/0195ea36-14ee-7c5c-a9a7-c1c11f9ac59f_7_224_149_1300_433_0.jpg)

Fig. 7. The framework of the ExpressGNN model. The model contains continuous space and symbolic space, and the variational EM algorithm acts as a bridge that connects the continuous space and symbolic space. Note, in the knowledge graph, ${e}_{k}$ is the entity and ${r}_{k}$ is the relation.

图7. ExpressGNN模型的框架。该模型包含连续空间和符号空间，变分EM算法作为连接连续空间和符号空间的桥梁。注意，在知识图中，${e}_{k}$是实体，${r}_{k}$是关系。

The main goal of pLogicNet and ExpressGNN is to combine the strengths of logic-based reasoning and neural networks in a unified framework. By leveraging neural networks' scalability and the expressiveness of logic rules, these models offer an solution for reasoning tasks in knowledge graphs. ExpressGNN improves the inference network of pLogicNet by using a graph neural network (GNN) to replace the flattened embedding table and adding a tunable part to the entity embedding to alleviate the problem of isomorphic nodes having the same embedding. The specific framework of ExpressGNN is illustrated in Fig. 7.

pLogicNet和ExpressGNN的主要目标是在一个统一的框架中结合基于逻辑的推理和神经网络的优势。通过利用神经网络的可扩展性和逻辑规则的表达能力，这些模型为知识图中的推理任务提供了一种解决方案。ExpressGNN通过使用图神经网络(graph neural network，GNN)替换扁平化嵌入表，并在实体嵌入中添加一个可调部分来缓解同构节点具有相同嵌入的问题，从而改进了pLogicNet的推理网络。ExpressGNN的具体框架如图7所示。

Indeed, relying solely on manually constructed logic rules may not capture the complete knowledge present in the data. To address this limitation, researchers have explored approaches to automatically learn logic rules from data. Two notable methods in this regard are the extensions of Markov logic networks (MLNs) proposed by Marra, Diligenti et al. (2020), Marra and Kuželka (2021) and differentiable inductive logic programming (ILP) models. Marra et al. extended MLNs by designing a general neural network architecture that can automatically learn the potential functions of MLNs from the original data. By training the neural network on labeled data, the model learns to capture the underlying patterns and relationships in the data, effectively learning logic rules that approximate the true structure of the domain. This approach enables the integration of neural networks and symbolic reasoning, allowing the model to learn logic rules directly from the data. Differentiable ILP is another approach that combines neural networks and logic to learn rules. It extends traditional ILP methods (Lavrac & Dzeroski, 1994) by introducing differentiable operations that enable the incorporation of neural networks into the ILP framework. This allows the model to learn logic rules by leveraging the expressive power of neural networks. Several differentiable ILP models have been proposed (Campero, Pareja, Klinger, Tenenbaum, & Riedel, 2018; Evans & Grefenstette, 2018; Galárraga, Teflioudi, Hose, & Suchanek, 2015; Payani & Fekri, 2019; Rocktäschel & Riedel, 2017), including JILP (Evans & Grefenstette, 2018), which uses predefined templates to construct logic rules and applies forward reasoning for inference. $\partial$ ILP is capable of learning effective logic rules even in the presence of noisy data, making it robust to imperfect input.

实际上，仅依靠手动构建的逻辑规则可能无法捕捉数据中存在的全部知识。为解决这一局限性，研究人员探索了从数据中自动学习逻辑规则的方法。在这方面，有两种值得注意的方法，分别是马拉(Marra)、迪利根蒂(Diligenti)等人(2020年)、马拉和库泽尔卡(Kuželka)(2021年)提出的马尔可夫逻辑网络(Markov logic networks，MLNs)扩展方法，以及可微归纳逻辑编程(differentiable inductive logic programming，ILP)模型。马拉等人通过设计一种通用的神经网络架构扩展了MLNs，该架构可以从原始数据中自动学习MLNs的势函数。通过在带标签的数据上训练神经网络，模型学会捕捉数据中潜在的模式和关系，从而有效地学习近似领域真实结构的逻辑规则。这种方法实现了神经网络和符号推理的集成，使模型能够直接从数据中学习逻辑规则。可微ILP是另一种将神经网络和逻辑相结合来学习规则的方法。它通过引入可微操作扩展了传统的ILP方法(拉夫拉克(Lavrac)和德罗斯基(Dzeroski)，1994年)，这些可微操作使神经网络能够融入ILP框架。这使得模型能够利用神经网络的表达能力来学习逻辑规则。已经提出了几种可微ILP模型(坎佩罗(Campero)、帕雷哈(Pareja)、克林格(Klinger)、特南鮑姆(Tenenbaum)和里德尔(Riedel)，2018年；埃文斯(Evans)和格雷芬施泰特(Grefenstette)，2018年；加拉拉加(Galárraga)、泰夫柳迪(Teflioudi)、霍斯(Hose)和苏查内克(Suchanek)，2015年；帕亚尼(Payani)和费克里(Fekri)，2019年；罗克塔舍尔(Rocktäschel)和里德尔，2017年)，包括JILP(埃文斯和格雷芬施泰特，2018年)，它使用预定义的模板来构建逻辑规则，并应用前向推理进行推断。$\partial$ 即使在存在噪声数据的情况下，ILP也能够学习有效的逻辑规则，使其对不完美的输入具有鲁棒性。

The current methods for learning logic rules often face limitations in expressiveness and computational feasibility. Approaches such as expressing the chain rule as a Horn clause and controlling the search length, number of relationships, and entities have been employed to address these challenges (Das et al., 2016; Gardner & Mitchell, 2015; Yang, Yang, & Cohen, 2017). However, the limited expressive power of these complex logic rules can hinder their effectiveness. To overcome these limitations, Yang et al. introduced neural logic inductive learning (NLIL) (Yang & Song, 2020). NLIL is a differentiable ILP model that extends the multi-hop reasoning framework to address general ILP problems. It allows for the learning of complex logic rules, including tree and conjunctive rules, which offer greater expressiveness compared to traditional approaches. NLIL leverages neural networks to learn logic rules from data and provides explanations for patterns observed in the data.

当前学习逻辑规则的方法在表达能力和计算可行性方面常常面临局限性。为应对这些挑战，人们采用了诸如将链式规则表示为霍恩子句以及控制搜索长度、关系数量和实体数量等方法(达斯(Das)等人，2016年；加德纳(Gardner)和米切尔(Mitchell)，2015年；杨(Yang)、杨和科恩(Cohen)，2017年)。然而，这些复杂逻辑规则有限的表达能力可能会阻碍其有效性。为克服这些局限性，杨等人引入了神经逻辑归纳学习(neural logic inductive learning，NLIL)(杨和宋(Song)，2020年)。NLIL是一种可微ILP模型，它扩展了多跳推理框架以解决一般的ILP问题。它允许学习复杂的逻辑规则，包括树状规则和合取规则，与传统方法相比，这些规则具有更强的表达能力。NLIL利用神经网络从数据中学习逻辑规则，并为数据中观察到的模式提供解释。

It first converts a logical predicate into a predicate operation, and then transforms all the intermediate variables into predicate operation representations of the head and tail entities, and such the head and the tail variables can be represented by randomly initialized vectors in the concrete implementation, so as to get rid of data dependency; then such a predicate operation forms the atom of the logical paradigm, which greatly expands the expression capability of logical predicates such as from chains to trees. Next, the NLIL model further extends the expressive power of the generated logical paradigm by combining atoms using logical connectives (and, or, not). Indeed, the NLIL model uses a hierarchical transformer model ${}^{1}$ to efficiently compute the intermediate parameters to be learned, including the vectors of logical predicates and the corresponding parameters of the attention mechanism (the weighted summation).

它首先将逻辑谓词转换为谓词操作，然后将所有中间变量转换为头尾实体的谓词操作表示，在具体实现中，头尾变量可以用随机初始化的向量表示，从而摆脱对数据的依赖；然后，这样的谓词操作构成了逻辑范式的原子，这极大地扩展了逻辑谓词的表达能力，例如从链式扩展到树状。接下来，NLIL模型通过使用逻辑连接词(与、或、非)组合原子，进一步扩展了所生成逻辑范式的表达能力。实际上，NLIL模型使用分层Transformer模型 ${}^{1}$ 来高效计算待学习的中间参数，包括逻辑谓词的向量和注意力机制(加权求和)的相应参数。

In NLIL, logic rules are grounded through matrix multiplication. For example, consider the logic rule Friends $\left( {x, y}\right)  \Rightarrow$ $\operatorname{Smokes}\left( x\right)$ , where constants $C = \{ A, B\}$ are one-hot vectors, such as ${V}_{A}$ and ${V}_{B}$ , and predicates Friends and Smokes are mapped to matrices such as ${M}_{\text{Friend }}\left( {A, B}\right)$ is a score of $A$ and $B$ that are related by Friend. The score of grounding is ${V}_{B} = {V}_{A}{M}_{\text{Friend }}$ .

在NLIL中，逻辑规则通过矩阵乘法进行接地。例如，考虑逻辑规则“朋友 $\left( {x, y}\right)  \Rightarrow$ $\operatorname{Smokes}\left( x\right)$ ”，其中常量 $C = \{ A, B\}$ 是独热向量，如 ${V}_{A}$ 和 ${V}_{B}$ ，谓词“朋友”和“吸烟”被映射到矩阵，如 ${M}_{\text{Friend }}\left( {A, B}\right)$ 是 $A$ 和 $B$ 通过“朋友”关系关联的得分。接地得分是 ${V}_{B} = {V}_{A}{M}_{\text{Friend }}$ 。

#### 3.1.2. Abstracting unstructured data into symbols

#### 3.1.2. 将非结构化数据抽象为符号

Mao et al. (2019) proposed the Neuro-Symbolic Concept Learner (NS-CL), which uses neural symbolic reasoning as a bridge to jointly learn visual concepts, words, and the semantic parsing of sentences without the need for the explicit supervision of any of them. NS-CL builds an object-based scene representation and translates sentences into symbolic programs.

毛(Mao)等人(2019年)提出了神经符号概念学习器(Neuro - Symbolic Concept Learner，NS - CL)，它以神经符号推理为桥梁，无需对视觉概念、单词和句子的语义解析进行任何明确监督，即可联合学习这些内容。NS - CL构建基于对象的场景表示，并将句子转换为符号程序。

NS-CL is designed to solve tasks in visual question answering (VQA). This model includes three modules: a visual perception module, semantic parsing module, and symbolic reasoning module. The visual perception module extracts object-based symbolic representation for a scene in an image. The semantic parsing module transforms a question into an executable program. Finally, the symbolic reasoning module applies a quasi-symbolic program executor to infer the answer based on the representation and an executable program.

NS - CL旨在解决视觉问答(VQA)任务。该模型包含三个模块:视觉感知模块、语义解析模块和符号推理模块。视觉感知模块为图像中的场景提取基于对象的符号表示。语义解析模块将问题转换为可执行程序。最后，符号推理模块应用准符号程序执行器，根据表示和可执行程序推断答案。

An example is shown in Fig. 8. Given the input image and question, the visual perception module uses a pre-trained mask R-CNN (Dollár & Girshick, 2017) to generate object features for all objects, then applies a similarity-based metric to classify objects. The semantic parsing module translates a natural language question into an executable program with a hierarchy of primitive operations, represented in a domain-specific language (DSL) designed for VQA. The symbolic reasoning module is a collection of deterministic functional modules designed to realize all logic operations specified in the DSL. It takes object concepts and a program as input to derive the answer. The optimization objective of NS-CL is composed of both a visual perception module and a semantic parsing module.

图8展示了一个示例。给定输入图像和问题，视觉感知模块使用预训练的掩码R - CNN(多尔和吉尔希克，2017年)为所有对象生成对象特征，然后应用基于相似度的度量对对象进行分类。语义解析模块将自然语言问题转换为具有基本操作层次结构的可执行程序，该程序用为VQA设计的领域特定语言(DSL)表示。符号推理模块是一组确定性功能模块，旨在实现DSL中指定的所有逻辑操作。它将对象概念和程序作为输入来推导答案。NS - CL的优化目标由视觉感知模块和语义解析模块共同组成。

---

1 Transformer is a tool that learns the relation between sequence data. Here, learning rules is a process of sequence calculation.

1 Transformer是一种学习序列数据之间关系的工具。在这里，学习规则是一个序列计算的过程。

---

![0195ea36-14ee-7c5c-a9a7-c1c11f9ac59f_8_314_149_1123_538_0.jpg](images/0195ea36-14ee-7c5c-a9a7-c1c11f9ac59f_8_314_149_1123_538_0.jpg)

Fig. 8. The framework of the NS-CL. The perception module begins by parsing visual scenes into object-based deep representations, while the semantic parser parse sentences into executable programs. A symbolic reasoning process bridges two modules.

图8. NS - CL的框架。感知模块首先将视觉场景解析为基于对象的深度表示，而语义解析器将句子解析为可执行程序。符号推理过程连接了两个模块。

Conclusion: Based on the discussion of related works in the category of learning for reasoning, we can summarize two principles from the perspective of neural networks: (1) Accelerator. Symbolic reasoning often involves searching for solutions in a solution space, which can be computationally expensive. In learning for reasoning approaches, neural networks are used as accelerators to speed up the search process. By leveraging the learning capabilities of neural networks, the search space can be reduced or optimized, leading to faster and more efficient reasoning. Techniques such as reinforcement learning can be employed to guide the search process and improve the overall performance of symbolic systems. (2) Transformer. Symbolic systems traditionally operate on structured data represented by symbols. However, neural networks excel at processing unstructured data such as images, texts, and videos. In learning for reasoning approaches, neural networks play a crucial role in transforming unstructured data into symbolic representations that can be processed by symbolic reasoning systems. By abstracting and extracting relevant features from the unstructured data, neural networks provide the symbolic systems with meaningful inputs for reasoning and decision-making.

结论:基于对推理学习类别中相关工作的讨论，我们可以从神经网络的角度总结出两条原则:(1)加速器。符号推理通常涉及在解空间中搜索解决方案，这可能会消耗大量计算资源。在推理学习方法中，神经网络被用作加速器来加速搜索过程。通过利用神经网络的学习能力，可以减少或优化搜索空间，从而实现更快、更高效的推理。可以采用强化学习等技术来引导搜索过程，提高符号系统的整体性能。(2)Transformer。传统上，符号系统对由符号表示的结构化数据进行操作。然而，神经网络擅长处理图像、文本和视频等非结构化数据。在推理学习方法中，神经网络在将非结构化数据转换为符号推理系统可以处理的符号表示方面起着至关重要的作用。通过从非结构化数据中抽象和提取相关特征，神经网络为符号系统提供了用于推理和决策的有意义输入。

### 3.2. Reasoning for learning

### 3.2. 学习的推理

Reasoning for learning methods can be broadly divided into regularization models and knowledge transfer models. Regularization models: Regularization models integrate symbolic knowledge into the training process by adding regular terms to the objective function of the model. These regular terms serve as constraints or penalties that encourage the model to adhere to the symbolic knowledge during training. By incorporating prior knowledge, regularization models aim to improve the performance and interpretability of the trained model. Different regularization models may employ different strategies for modeling symbolic knowledge as regular terms, such as semantic embed-dings, logical rules, or semantic constraints. Examples of regularization models include (Chen et al., 2018; Diligenti et al., 2017; Donadello et al., 2017; Hu et al., 2016; Li et al., 2019; Liu et al., 2019; Luo et al., 2020; Minervini et al., 2017; Xie et al., 2019; Xu et al., 2018). Knowledge transfer models: Knowledge transfer models establish connections between different domains or spaces, such as the visual space and the semantic space, and transfer symbolic knowledge from one domain to another to support the learning process. These models leverage existing symbolic knowledge or semantic information to guide the learning of models in a different domain. For example, semantic knowledge can be transferred from the semantic space to the visual space to aid in tasks such as zero-shot learning or semantic segmentation. Knowledge transfer models enable the utilization of symbolic knowledge in a different context to improve the performance and generalization of the model. Examples of knowledge transfer models include (Chen et al., 2020; Kampffmeyer et al., 2019; Wang et al., 2018).

学习的推理方法大致可分为正则化模型和知识迁移模型。正则化模型:正则化模型通过在模型的目标函数中添加正则项，将符号知识集成到训练过程中。这些正则项作为约束或惩罚项，鼓励模型在训练过程中遵循符号知识。通过纳入先验知识，正则化模型旨在提高训练模型的性能和可解释性。不同的正则化模型可能采用不同的策略将符号知识建模为正则项，如语义嵌入、逻辑规则或语义约束。正则化模型的示例包括(陈等人，2018年；迪利根蒂等人，2017年；多纳代洛等人，2017年；胡等人，2016年；李等人，2019年；刘等人，2019年；罗等人，2020年；米内尔维尼等人，2017年；谢等人，2019年；徐等人，2018年)。知识迁移模型:知识迁移模型在不同的领域或空间(如视觉空间和语义空间)之间建立联系，并将符号知识从一个领域迁移到另一个领域以支持学习过程。这些模型利用现有的符号知识或语义信息来指导不同领域中模型的学习。例如，语义知识可以从语义空间迁移到视觉空间，以辅助零样本学习或语义分割等任务。知识迁移模型能够在不同的上下文中利用符号知识，以提高模型的性能和泛化能力。知识迁移模型的示例包括(陈等人，2020年；坎普夫迈耶等人，2019年；王等人，2018年)。

#### 3.2.1. Regularization models

#### 3.2.1. 正则化模型

Indeed, Hu et al. (2016) introduced the HDNN framework, which leverages the concept of knowledge distillation to harness the power of logic rules in training deep neural networks. The framework consists of two components: a teacher network and a student network. In HDNN, the teacher network encodes logic rules and guides the student network during training. That is to say, the teacher network learns information from the labeled data and logic rules (unlabeled data) and teaches the student network by the loss function. Based on the above process, the structured information encoded by logic rules can constrain the learning of the student network.

实际上，胡等人(2016年)引入了HDNN框架(分层深度神经网络框架，Hierarchical Deep Neural Network framework)，该框架利用知识蒸馏的概念，在训练深度神经网络时发挥逻辑规则的作用。该框架由两个部分组成:一个教师网络和一个学生网络。在HDNN中，教师网络对逻辑规则进行编码，并在训练过程中指导学生网络。也就是说，教师网络从有标签的数据和逻辑规则(无标签数据)中学习信息，并通过损失函数来教导学生网络。基于上述过程，逻辑规则编码的结构化信息可以约束学生网络的学习。

Specifically, the rule knowledge distillation module includes the student network ${p}_{\theta }\left( {y \mid  x}\right)$ and the teacher network $q\left( {y \mid  x}\right)$ . The model needs to meet the following conditions: (1) The probability distribution ${p}_{\theta }\left( {y \mid  x}\right)$ of the student network should be as close as possible to the probability distribution $q\left( {y \mid  x}\right)$ of the teacher network; (2) The teacher network should obey the logic rules to the greatest extent possible. The formal representation of the objective and two conditions is shown in Eqs. (2) and (3).

具体而言，规则知识蒸馏模块包括学生网络 ${p}_{\theta }\left( {y \mid  x}\right)$ 和教师网络 $q\left( {y \mid  x}\right)$ 。该模型需要满足以下条件:(1)学生网络的概率分布 ${p}_{\theta }\left( {y \mid  x}\right)$ 应尽可能接近教师网络的概率分布 $q\left( {y \mid  x}\right)$ ；(2)教师网络应尽可能遵守逻辑规则。目标和两个条件的形式化表示如公式(2)和(3)所示。

$$
{\theta }^{\left( t + 1\right) } = \arg \mathop{\min }\limits_{{\theta  \in  \Theta }}1/N\mathop{\sum }\limits_{{n = 1}}^{N}\left( {1 - \pi }\right) l\left( {{y}_{n},{\sigma }_{\theta }\left( {x}_{n}\right) }\right)  + {\pi l}\left( {{s}_{n}{}^{\left( t\right) },{\sigma }_{\theta }\left( {x}_{n}\right) }\right) ,
$$

(2)

$$
\left\{  \begin{array}{l} \mathop{\min }\limits_{{q,\xi  \geq  0}}{KL}\left( {q\left( {Y \mid  X}\right) \parallel {p}_{\theta }\left( {Y \mid  X}\right) }\right)  + C\mathop{\sum }\limits_{{l,{gl}}}{\xi }_{l,{gl}} \\  {\lambda }_{l}\left( {1 - {E}_{q}\left\lbrack  {{r}_{l,{gl}}\left( {X, Y}\right) }\right\rbrack  }\right)  \leq  {\xi }_{l,{gl}} \\  {gl} = 1,\ldots ,{G}_{l}, l = 1,\ldots , L \end{array}\right.  \tag{3}
$$

In Eq. (2), $\pi$ is the limitation parameter used to calibrate the relative importance of the two objectives; ${x}_{n}$ represents the training data, while ${y}_{n}$ the label of the training data; $l$ denotes the loss function selected according to specific applications (e.g., the cross-entropy loss for classification); ${s}_{n}^{\left( t\right) }$ is the soft prediction vector of $q\left( {y \mid  x}\right)$ on ${x}_{n}$ at iteration $t;{\sigma }_{\theta }\left( x\right)$ represents the output of ${p}_{\theta }\left( {y \mid  x}\right)$ ; the first term is the student network, and the second term is the teacher network. In Eq. (3), ${\xi }_{l,{gl}} \geq  0$ is the slack variable for the respective logic constraint; $C$ is the regularization parameter; $l$ is the index of the rule; ${gl}$ is the index of the ground rule; ${\lambda }_{l}$ is the weight of the rule.

在公式(2)中， $\pi$ 是用于校准两个目标相对重要性的限制参数； ${x}_{n}$ 表示训练数据，而 ${y}_{n}$ 表示训练数据的标签； $l$ 表示根据具体应用选择的损失函数(例如，用于分类的交叉熵损失)； ${s}_{n}^{\left( t\right) }$ 是 $q\left( {y \mid  x}\right)$ 在迭代 $t;{\sigma }_{\theta }\left( x\right)$ 时对 ${x}_{n}$ 的软预测向量，表示 ${p}_{\theta }\left( {y \mid  x}\right)$ 的输出；第一项是学生网络，第二项是教师网络。在公式(3)中， ${\xi }_{l,{gl}} \geq  0$ 是相应逻辑约束的松弛变量； $C$ 是正则化参数； $l$ 是规则的索引； ${gl}$ 是基本规则的索引； ${\lambda }_{l}$ 是规则的权重。

Different from the knowledge distillation framework, certain approaches incorporate logical knowledge as a constraint within the hypothesis space. These methods involve encoding a logic formula, either propositional or first-order, into a real-valued function that serves as a regularization term for the neural model. An example of such an approach is semantic-based regularization (SBR) proposed by Diligenti et al. (2017). SBR combines the strengths of classic machine learning, with its ability to learn continuous feature representations, and symbolic reasoning techniques, with their advanced semantic knowledge reasoning capabilities. SBR is applied to address various problems, including multi-task optimization and classification. Following the classical penalty approach for constrained optimization, constraint satisfaction can be enforced by adding a term that penalizes the violation of these constraints into the loss of the model.

与知识蒸馏框架不同，某些方法将逻辑知识作为一种约束纳入假设空间。这些方法涉及将命题逻辑或一阶逻辑公式编码为实值函数，该函数作为神经模型的正则化项。迪利根蒂等人(2017年)提出的基于语义的正则化(SBR，Semantic-based Regularization)就是这种方法的一个例子。SBR结合了经典机器学习学习连续特征表示的能力和符号推理技术先进的语义知识推理能力。SBR被应用于解决各种问题，包括多任务优化和分类。遵循经典的约束优化惩罚方法，可以通过在模型的损失函数中添加一项对违反这些约束的行为进行惩罚的项来强制满足约束条件。

Building upon the idea of semantic-based regularization (SBR), Xu et al. (2018) introduced a novel approach called semantic loss (SL). SL combines the power of propositional logic reasoning with deep learning architectures by incorporating the output of the neural network into the loss function as a constraint for the learnable network. This enables the neural network to leverage the reasoning capabilities of propositional logic to improve its learning ability. In contrast to SBR, SL takes a different approach to incorporating logic rules into the loss function. It encodes the logic rules using an arithmetic circuit, specifically a Sentential Decision Diagram (SDD) (Darwiche, 2011), which allows for the evaluation of the model. This encoding serves as an additional regularization term that can be directly integrated into an existing loss function. The formulation of SL is provided in Eq. (4).

基于基于语义的正则化(SBR)的思想，徐等人(2018年)引入了一种名为语义损失(SL，Semantic Loss)的新方法。SL通过将神经网络的输出作为可学习网络的约束纳入损失函数，将命题逻辑推理的能力与深度学习架构相结合。这使得神经网络能够利用命题逻辑的推理能力来提高其学习能力。与SBR不同，SL采用了不同的方法将逻辑规则纳入损失函数。它使用算术电路，具体来说是语句决策图(SDD，Sentential Decision Diagram)(达维奇，2011年)对逻辑规则进行编码，从而可以对模型进行评估。这种编码作为一个额外的正则化项，可以直接集成到现有的损失函数中。SL的公式如公式(4)所示。

$$
{L}^{s}\left( {\alpha , p}\right)  \propto   - \log \mathop{\sum }\limits_{{x \vDash  \alpha }}\mathop{\prod }\limits_{{i : x \vDash  {X}_{i}}}{p}_{i}\mathop{\prod }\limits_{{i : x \vDash  \neg {X}_{i}}}\left( {1 - {p}_{i}}\right) , \tag{4}
$$

where $p$ is a vector of probabilities from the prediction of the neural network, $\alpha$ is a propositional logic, $x$ is the instantiation of ${X}_{i}$ , and $x \vDash  \alpha$ is a state $x$ that satisfies a sentence $\alpha$ .

其中 $p$ 是神经网络预测的概率向量， $\alpha$ 是一个命题逻辑， $x$ 是 ${X}_{i}$ 的实例化， $x \vDash  \alpha$ 是满足语句 $\alpha$ 的状态 $x$ 。

Notably, the aforementioned methods do not employ explicit knowledge representation techniques, leading to an unclear computational process for symbolic knowledge. To address this issue, some researchers have chosen to utilize tools that can model symbols, such as d-DNNF (as mentioned in Appendix). Xie et al. (2019) integrated propositional logic into a relationship detection model and proposed a logic embedding network with semantic regularization (LENSR) to enhance the relationship detection capabilities of deep models. The process of LENSR can be summarized as follows: (1) The visual relationship detection model predicts the probability distribution of the relation predicate for each image; (2) The prior propositional logic formula related to the sample image is expressed as a directed acyclic graph by d-DNNF, after which GNN is used to learn its probability distribution; (3) An objective function is designed that aligns the above two distributions.

值得注意的是，上述方法并未采用显式的知识表示技术，导致符号知识的计算过程不清晰。为解决这一问题，一些研究人员选择利用能够对符号进行建模的工具，如d - DNNF(如附录中所述)。谢等人(2019年)将命题逻辑集成到关系检测模型中，并提出了一种具有语义正则化的逻辑嵌入网络(LENSR)，以增强深度模型的关系检测能力。LENSR的过程可总结如下:(1)视觉关系检测模型预测每个图像的关系谓词的概率分布；(2)与样本图像相关的先验命题逻辑公式通过d - DNNF表示为有向无环图，然后使用图神经网络(GNN)学习其概率分布；(3)设计一个目标函数，使上述两种分布对齐。

Fig. 9 presents a schematic diagram of LENSR, which uses a propositional logic of the form $P \Rightarrow  Q$ . In this example, the predicate $P$ represents wear(person, glasses), and the predicate $Q$ represents in(glasses, person). The ground truth of the input image and the corresponding propositional logic (prior knowledge) are on the left. The directed acyclic graph of propositional logic d-DNNF is then sent to the Embedder $q$ (Embedder is a graph neural network (GNN) (Kipf & Welling, 2017) that learns the vector representation) to obtain $q\left( {F}_{x}\right)$ , which is the embedding of the propositional logic knowledge. On the right is the relation label predicted by the detection network. The predicted labels are then combined into a conjunctive normal form $h\left( x\right)  =  \land  {p}_{i}$ to construct a directed acyclic graph d-DNNF, which is sent to the Embedder $q$ to obtain $q\left( {h\left( x\right) }\right)$ , the embedding of the predicted propositional logic. The optimization goal of LENSR is shown in Eq. (5). Here, ${L}_{\text{task }}$ represents the loss of a specific task, $\lambda$ is a hyperparameter that acts as a balance factor, and ${L}_{\text{logic }}$ is the loss of propositional logic (that is, the distance between vector $q\left( {Fx}\right)$ and vector $q\left( {h\left( x\right) }\right)$ ).

图9展示了LENSR的示意图，它使用了形式为 $P \Rightarrow  Q$ 的命题逻辑。在这个例子中，谓词 $P$ 表示“人戴着眼镜”(wear(person, glasses))，谓词 $Q$ 表示“眼镜在人身上”(in(glasses, person))。输入图像的真实标签和相应的命题逻辑(先验知识)在左侧。命题逻辑d - DNNF的有向无环图随后被送入嵌入器 $q$(嵌入器是一个图神经网络(GNN)(基普夫和韦林，2017年)，用于学习向量表示)以获得 $q\left( {F}_{x}\right)$，即命题逻辑知识的嵌入。右侧是检测网络预测的关系标签。预测标签随后被组合成合取范式 $h\left( x\right)  =  \land  {p}_{i}$ 以构建有向无环图d - DNNF，该图被送入嵌入器 $q$ 以获得 $q\left( {h\left( x\right) }\right)$，即预测命题逻辑的嵌入。LENSR的优化目标如公式(5)所示。这里，${L}_{\text{task }}$ 表示特定任务的损失，$\lambda$ 是一个作为平衡因子的超参数，${L}_{\text{logic }}$ 是命题逻辑的损失(即向量 $q\left( {Fx}\right)$ 和向量 $q\left( {h\left( x\right) }\right)$ 之间的距离)。

$$
L = {L}_{\text{task }} + \lambda {L}_{\text{logic }}, \tag{5}
$$

$$
{L}_{\text{logic }} = {\begin{Vmatrix}q\left( f\right)  - q\left( \land {p}_{i}\right) \end{Vmatrix}}_{2}. \tag{6}
$$

However, LENSR models a local dependency graph for each logic formula and only captures local knowledge information, which may result in the poor expressive ability of the model. To solve this problem, the researcher started to model a global dependency graph for all logic formulas, which can improve the expressive ability of the model and effectively capture uncertainty (Yu et al., 2022).

然而，LENSR为每个逻辑公式建模局部依赖图，仅捕获局部知识信息，这可能导致模型的表达能力较差。为解决这个问题，研究人员开始为所有逻辑公式建模全局依赖图，这可以提高模型的表达能力并有效捕获不确定性(于等人，2022年)。

The above methods utilize logic rules as prior knowledge. In contrast, Luo et al. (2020) focused on knowledge graphs and proposed a context-aware zero-shot recognition method (CA-ZSL) to address the zero-shot detection problem. CA-ZSL constructs a model based on deep learning and conditional random fields (CRF) and leverages knowledge graphs, which represent the semantic relationships between classes, to assist in identifying objects from unseen classes. The framework of CA-ZSL is depicted in Fig. 10. In this framework, individual and pairwise features are extracted from the image. The instance-level zero-shot inference module utilizes individual features to generate a unary potential function, while the relationship inference module employs pairwise features and knowledge graphs to generate a binary potential function. Finally, based on the conditional random field constructed by these two potential functions, the label of the unseen objects is predicted.

上述方法利用逻辑规则作为先验知识。相比之下，罗等人(2020年)专注于知识图谱，并提出了一种上下文感知的零样本识别方法(CA - ZSL)来解决零样本检测问题。CA - ZSL基于深度学习和条件随机场(CRF)构建模型，并利用表示类别之间语义关系的知识图谱来辅助识别未见类别的对象。CA - ZSL的框架如图10所示。在这个框架中，从图像中提取个体特征和成对特征。实例级零样本推理模块利用个体特征生成一元势函数，而关系推理模块利用成对特征和知识图谱生成二元势函数。最后，基于由这两个势函数构建的条件随机场，预测未见对象的标签。

CA-ZSL incorporates a knowledge graph, which includes the GCN-encoded embedding, into the computation of the binary potential function within the conditional random field, thereby facilitating the learning process of the model. The objective of optimization is to maximize the joint probability distribution of the conditional random field, as depicted in Eq. (7). In the equation, $\theta$ denotes the unary potential function, $\psi$ represents the binary potential function, ${c}_{i}$ represents the class, ${B}_{i}$ represents the object region in the image, $\gamma$ is the balance factor, and $N$ denotes the number of objects.

CA - ZSL将包含图卷积网络(GCN)编码嵌入的知识图谱纳入条件随机场中二元势函数的计算，从而促进模型的学习过程。优化的目标是最大化条件随机场的联合概率分布，如公式(7)所示。在公式中，$\theta$ 表示一元势函数，$\psi$ 表示二元势函数，${c}_{i}$ 表示类别，${B}_{i}$ 表示图像中的对象区域，$\gamma$ 是平衡因子，$N$ 表示对象的数量。

$$
P = \left( {{c}_{1}\ldots {c}_{N} \mid  {B}_{1}\ldots {B}_{N}}\right)  \propto  \exp \left( {\mathop{\sum }\limits_{i}\theta \left( {{c}_{i} \mid  {B}_{i}}\right)  + \gamma \mathop{\sum }\limits_{{i \neq  j}}\psi \left( {{c}_{i},{c}_{j} \mid  {B}_{i},{B}_{j}}\right) }\right) . \tag{7}
$$

#### 3.2.2. Knowledge transfer models

#### 3.2.2. 知识迁移模型

Knowledge transfer integrates knowledge graphs (pre-defined) that represent semantic information into deep learning models, which compensates for the lack of available data through the transfer of semantic knowledge. In this survey, we mainly introduce representative approaches in image classification (Chen et al., 2020; Wang, Yao, Kwok, & Ni, 2020) such as zero-shot learning (Kampffmeyer et al., 2019; Wang et al., 2018), few-shot learning (Chen et al., 2020; Wang et al., 2020; Zhong, Haoran, Yunlong, & Yanwei, 2019) and reinforcement learning (Silva & Gombolay, 2021) for knowledge transfer.

知识迁移将表示语义信息的知识图谱(预定义)集成到深度学习模型中，通过语义知识的迁移来弥补可用数据的不足。在本综述中，我们主要介绍图像分类领域(Chen等人，2020年；Wang、Yao、Kwok和Ni，2020年)的代表性方法，如零样本学习(Kampffmeyer等人，2019年；Wang等人，2018年)、少样本学习(Chen等人，2020年；Wang等人，2020年；Zhong、Haoran、Yunlong和Yanwei，2019年)和强化学习(Silva和Gombolay，2021年)用于知识迁移。

![0195ea36-14ee-7c5c-a9a7-c1c11f9ac59f_10_441_149_868_455_0.jpg](images/0195ea36-14ee-7c5c-a9a7-c1c11f9ac59f_10_441_149_868_455_0.jpg)

Fig. 9. The framework of the LENSR. The GCN-based embedder $q$ projects a logic graph to the vector space, satisfying the requirement that the distribution of the projected result is as close to the distribution of the real label as possible. We use this embedding space to form logic losses that regularize deep neural networks for a target task.

图9. LENSR的框架。基于图卷积网络(GCN)的嵌入器 $q$ 将逻辑图投影到向量空间，满足投影结果的分布尽可能接近真实标签分布的要求。我们使用这个嵌入空间形成逻辑损失，对目标任务的深度神经网络进行正则化。

![0195ea36-14ee-7c5c-a9a7-c1c11f9ac59f_10_355_733_1040_509_0.jpg](images/0195ea36-14ee-7c5c-a9a7-c1c11f9ac59f_10_355_733_1040_509_0.jpg)

Fig. 10. The framework of the CA-ZSL. The features of individual objects and pairwise features are extracted from the image and input into an instance-level zero-shot inference module and a relationship inference module respectively. In combination with the knowledge graph, the unary potential function and binary potential function of CRF are generated respectively to predict the labels of objects.

图10. CA - ZSL的框架。从图像中提取单个对象的特征和成对特征，并分别输入到实例级零样本推理模块和关系推理模块。结合知识图谱，分别生成条件随机场(CRF)的一元势函数和二元势函数，以预测对象的标签。

In the context of visual tasks, researchers have proposed several zero-shot recognition models that leverage semantic representation and knowledge graphs to compensate for the limitations of visual data. Two notable models in this regard are SEKB-ZSL (Zero-shot Recognition via Semantic Embeddings) (Wang et al., 2018) and DGP (Dense Graph Propagation Module) (Kampffmeyer et al., 2019). These models employ the semantic classifier weights derived from the knowledge graph, which encompasses both seen and unseen classes, to guide or supervise the learning of visual classifier weights, thus facilitating knowledge transfer. The underlying principles can be summarized as follows: In the visual space, SEKB-ZSL employs Convolutional Neural Networks (CNN) to extract visual features from images and learns a visual classifier for the seen classes. In the semantic space, Graph Convolutional Networks (GCN) are utilized to learn node features within the knowledge graph and derive a semantic classifier for class labels. Subsequently, the weights of the class semantic classifier are employed to supervise the learning process of visual classifier weights, enabling the transfer of semantic knowledge to novel classes.

在视觉任务的背景下，研究人员提出了几种零样本识别模型，这些模型利用语义表示和知识图谱来弥补视觉数据的局限性。在这方面，有两个值得注意的模型，即SEKB - ZSL(通过语义嵌入进行零样本识别)(Wang等人，2018年)和DGP(密集图传播模块)(Kampffmeyer等人，2019年)。这些模型采用从知识图谱中导出的语义分类器权重(该知识图谱包含已见和未见类别)来指导或监督视觉分类器权重的学习，从而促进知识迁移。其基本原理总结如下:在视觉空间中，SEKB - ZSL采用卷积神经网络(CNN)从图像中提取视觉特征，并为已见类别学习视觉分类器。在语义空间中，利用图卷积网络(GCN)学习知识图谱内的节点特征，并为类别标签导出语义分类器。随后，使用类别语义分类器的权重来监督视觉分类器权重的学习过程，从而实现语义知识向新类别的迁移。

DGP introduces improvements over SEKB-ZSL. Firstly, it addresses the over-smoothing issue in GCN by reducing the number of graph convolution layers from six to two. Additionally, the attention mechanism is employed to calculate connection weights between nodes in the knowledge graph, thereby enhancing the node connectivity. The principle of DGP is depicted in Fig. 11. The entire model is trained end-to-end, and the loss function is defined as the similarity between the weights of the two module classifiers, as shown in Eq. (8). In the equation, $M$ represents the number of classes, $P$ represents the dimension of the weight vectors, ${W}_{i, j}$ denotes the weights of the visual classifier, and ${W}^{\prime }{}_{i, j}$ denotes the weights of the semantic classifier.

DGP在SEKB - ZSL的基础上进行了改进。首先，它通过将图卷积层的数量从六层减少到两层，解决了GCN中的过平滑问题。此外，采用注意力机制来计算知识图谱中节点之间的连接权重，从而增强节点的连通性。DGP的原理如图11所示。整个模型进行端到端训练，损失函数定义为两个模块分类器权重之间的相似度，如公式(8)所示。在公式中， $M$ 表示类别数量， $P$ 表示权重向量的维度， ${W}_{i, j}$ 表示视觉分类器的权重， ${W}^{\prime }{}_{i, j}$ 表示语义分类器的权重。

$$
L = 1/{2M}\mathop{\sum }\limits_{{i = 1}}^{M}\mathop{\sum }\limits_{{j = 1}}^{P}{\left( {W}_{i, j} - {W}_{i, j}^{\prime }\right) }^{2}. \tag{8}
$$

Transferring correlation information between classes can be beneficial for learning new concepts. DGP demonstrates the importance of aligning the semantic classifier with the feature classifier. Building upon this idea, Chen et al. (2020) proposed the Knowledge Graph Transfer Network (KGTN) to address the few-shot classification problem. In KGTN, knowledge graphs are utilized to capture and model the correlations between seen and unseen classes. These knowledge graphs serve as a means to transfer knowledge and facilitate the learning process. The overall architecture of KGTN is depicted in Fig. 12.

迁移类别之间的关联信息有助于学习新概念。DGP证明了使语义分类器与特征分类器对齐的重要性。基于这一思想，Chen等人(2020年)提出了知识图谱迁移网络(KGTN)来解决少样本分类问题。在KGTN中，利用知识图谱来捕捉和建模已见和未见类别之间的关联。这些知识图谱作为知识迁移的手段，促进学习过程。KGTN的整体架构如图12所示。

Specifically, KGTN comprises three main parts: the feature extraction module, knowledge graph transfer module, and prediction module. The feature extraction module uses CNN to extract the feature vector of images. The knowledge graph transfer module uses a gated graph neural network (GGNN) to learn the knowledge graph node embedding. After $T$ iterations, the knowledge graph transfer module obtains the final weight ${w}^{ * }$ , which has captured the correlation between the seen and the unseen classes. The prediction module calculates the similarity between the weight ${w}^{ * }$ and the image feature to predict the probability distribution of the label.

具体而言，KGTN由三个主要部分组成:特征提取模块、知识图谱迁移模块和预测模块。特征提取模块使用CNN提取图像的特征向量。知识图谱迁移模块使用门控图神经网络(GGNN)学习知识图谱节点嵌入。经过 $T$ 次迭代后，知识图谱迁移模块获得最终权重 ${w}^{ * }$ ，该权重捕捉了已见和未见类别之间的关联。预测模块计算权重 ${w}^{ * }$ 与图像特征之间的相似度，以预测标签的概率分布。

![0195ea36-14ee-7c5c-a9a7-c1c11f9ac59f_11_439_154_867_495_0.jpg](images/0195ea36-14ee-7c5c-a9a7-c1c11f9ac59f_11_439_154_867_495_0.jpg)

Fig. 11. The framework of the DGP. DGP is trained to predict the classifier weights $W$ for each node/class in a graph. The weights for the training classes are extracted from the final layer of a pre-trained ResNet. The graph is constructed from a knowledge graph, and each node is represented by a vector that encodes semantic class information (the word embedding class in this paper). The network consists of two phases: a descendant phase (where each node receives knowledge from its descendants) and an ancestor phase (where it receives knowledge from its ancestors).

图11. 深度生成过程(DGP)的框架。DGP经过训练，用于预测图中每个节点/类别的分类器权重 $W$。训练类别的权重从预训练的残差网络(ResNet)的最后一层提取。该图由知识图谱构建而成，每个节点由一个对语义类别信息进行编码的向量表示(本文中为词嵌入类别)。该网络包括两个阶段:后代阶段(每个节点从其后代获取知识)和祖先阶段(每个节点从其祖先获取知识)。

![0195ea36-14ee-7c5c-a9a7-c1c11f9ac59f_11_368_813_1014_462_0.jpg](images/0195ea36-14ee-7c5c-a9a7-c1c11f9ac59f_11_368_813_1014_462_0.jpg)

Fig. 12. The framework of the KGTN model. It incorporates the prior knowledge of category correlation and makes use of the interaction between category classifier weights, facilitating better learning of the classifier weights of unknown categories.

图12. 知识图谱转换网络(KGTN)模型的框架。它整合了类别相关性的先验知识，并利用类别分类器权重之间的相互作用，有助于更好地学习未知类别的分类器权重。

In contrast to static domain knowledge, Silva and Gombolay (2021) introduced Propositional Logic Nets (PROLONETS), which directly encode domain knowledge as a collection of propositional rules within a neural network. PROLONETS not only incorporates domain knowledge into the model but also allows for the refinement of domain knowledge based on the trained neural network. The framework of PROLONETS is illustrated in Fig. 13. This approach enables the neural network to leverage domain-specific information and improve its learning and reasoning capabilities.

与静态领域知识不同，席尔瓦(Silva)和贡博拉伊(Gombolay)(2021年)引入了命题逻辑网络(PROLONETS)，该网络直接将领域知识编码为神经网络内的一组命题规则。命题逻辑网络不仅将领域知识融入模型，还允许根据训练好的神经网络对领域知识进行细化。命题逻辑网络的框架如图13所示。这种方法使神经网络能够利用特定领域的信息，提高其学习和推理能力。

PROLONETS aids in "warm starting" the learning process in deep reinforcement learning. The first step involves knowledge representation, where policies and actions express domain knowledge in the form of propositional rules. These rules are then encoded into a decision tree structure. The second step is neural network initialization, wherein the nodes of the decision tree are directly transformed into neural network weights. This allows the agent to immediately commence learning effective strategies in reinforcement learning. The final step is training, during which the initialized network interacts with the environment, collecting data that is subsequently used to update parameters and rectify domain knowledge.

命题逻辑网络有助于深度强化学习中的学习过程“热启动”。第一步是知识表示，其中策略和行动以命题规则的形式表达领域知识。然后将这些规则编码为决策树结构。第二步是神经网络初始化，即将决策树的节点直接转换为神经网络的权重。这使智能体能够立即开始在强化学习中学习有效策略。最后一步是训练，在此期间，初始化的网络与环境进行交互，收集数据，随后用于更新参数和修正领域知识。

Let us consider the cart pole as an example. The state space of a cart pole is a four-dimensional vector: cart position, cart velocity, pole angle, and pole velocity. The action space is a two-dimensional vector (left, right). Domain knowledge can be expressed as "if the cart's position is right of center, move left; otherwise, move right.". The decision nodes of the tree become linear layers, leaves become action weights, and the final output is a sum of the leaves weighted by path probabilities. Therefore, if position $>  - 1$ , the weight of the neural network is $w =$ $\{ 1,0,0,0\}$ , and the bias is $b =  - 1$ .

让我们以推车杆问题为例。推车杆的状态空间是一个四维向量:推车位置、推车速度、杆的角度和杆的速度。动作空间是一个二维向量(左、右)。领域知识可以表示为“如果推车的位置在中心右侧，则向左移动；否则，向右移动”。树的决策节点成为线性层，叶子节点成为动作权重，最终输出是叶子节点按路径概率加权的总和。因此，如果位置 $>  - 1$，神经网络的权重是 $w =$ $\{ 1,0,0,0\}$，偏差是 $b =  - 1$。

Conclusion: Based on the above text, we can summarize the following key factors in reasoning for learning. (1) Knowledge representation. Symbolic knowledge is a kind of discrete representation. To achieve combination between symbolic knowledge (discrete representation) and neural network (continuous representation), most methods usually convert the symbolic knowledge into an intermediate representation, such as a graph, tree, etc. Moreover, another approaches use fuzzy logic (such as t-norm) to assign soft truth degrees in the continuous set $\left\lbrack  {0,1}\right\rbrack$ . In summary, it may very well be among the essential representations grounded in the environment that form the foundation of a much larger representational edifice that is needed for human-like general intelligence (Honavar, 1995). (2) Combining approaches. One type of approach involves taking symbolic knowledge as a regularization term in the loss functions of the neural networks. The others involve encoding symbolic knowledge into the structure of the neural networks as an initiative to improve their performance. It is worth noting that logic rules usually are added as constraints to loss functions, while knowledge graphs often enhance neural networks with information about relations between instances.

结论:根据上述文本，我们可以总结出学习推理中的以下关键因素。(1)知识表示。符号知识是一种离散表示。为了实现符号知识(离散表示)与神经网络(连续表示)的结合，大多数方法通常将符号知识转换为中间表示，如图、树等。此外，其他方法使用模糊逻辑(如t - 范数)在连续集合 $\left\lbrack  {0,1}\right\rbrack$ 中分配软真值度。总之，它很可能是基于环境的基本表示之一，构成了实现类人通用智能所需的更大表示体系的基础(霍纳瓦尔(Honavar)，1995年)。(2)结合方法。一类方法是将符号知识作为正则化项纳入神经网络的损失函数中。其他方法则是将符号知识编码到神经网络的结构中，以提高其性能。值得注意的是，逻辑规则通常作为约束条件添加到损失函数中，而知识图谱通常用实例之间的关系信息来增强神经网络。

![0195ea36-14ee-7c5c-a9a7-c1c11f9ac59f_12_307_151_1140_306_0.jpg](images/0195ea36-14ee-7c5c-a9a7-c1c11f9ac59f_12_307_151_1140_306_0.jpg)

Fig. 13. The framework of the PROLONETS. Domain knowledge is constructed into a decision tree that is then used to directly initialize a PROLONET’s architecture and parameters; here, leaf nodes are actions and other nodes are policies in reinforcement learning. The PROLONET can then begin reinforcement learning in the given domain, outgrowing its original specification.

图13. 命题逻辑网络(PROLONETS)的框架。领域知识被构建成一个决策树，然后用于直接初始化命题逻辑网络的架构和参数；在这里，叶子节点是强化学习中的动作，其他节点是策略。然后，命题逻辑网络可以在给定领域开始强化学习，超越其最初的设定。

### 3.3. Learning- reasoning

### 3.3. 学习 - 推理

In learning-reasoning approaches, learning and reasoning do not work in isolation but instead closely interact. This is a development trend of neural-symbolic learning systems (Cai et al., 2021; Manhaeve et al., 2018; Tian et al., 2022; Yu et al., 2022; Zhou, 2019).

在学习 - 推理方法中，学习和推理并非孤立进行，而是密切相互作用。这是神经符号学习系统的一个发展趋势(蔡(Cai)等人，2021年；曼哈埃夫(Manhaeve)等人，2018年；田(Tian)等人，2022年；余(Yu)等人，2022年；周(Zhou)，2019年)。

Based on ProbLog (De Raedt, Kimmig, & Toivonen, 2007), Man-haeve et al. (2018) introduced neural facts and neural annotated disjunction (neural AD) to propose a model that seamlessly integrates probability, logic, and deep learning, known as Deep-ProbLog. DeepProbLog is a pioneering framework that combines a generic deep neural network with probabilistic logic in a unique manner. It offers the advantage of enhanced expressive capability and enables end-to-end training for neural networks and logical reasoning in a unified framework.

基于ProbLog(De Raedt、Kimmig和Toivonen，2007年)，Man - haeve等人(2018年)引入了神经事实和神经带注释析取(神经AD)，提出了一个无缝集成概率、逻辑和深度学习的模型，即深度概率逻辑编程(Deep - ProbLog)。深度概率逻辑编程是一个开创性的框架，它以独特的方式将通用深度神经网络与概率逻辑相结合。它具有增强表达能力的优势，并能在统一框架中实现神经网络的端到端训练和逻辑推理。

DeepProbLog is a probabilistic programming language that integrates deep learning through the use of "neural predicates". These neural predicates serve as an interface between neural networks and symbolic reasoning. In DeepProbLog, an image, for instance, is processed by a neural network, which outputs the distribution of each class in the dataset as logical facts for symbolic reasoning. Specifically, neural networks are employed to process simple concepts or unstructured data, generating inputs for symbolic reasoning in DeepProbLog. Symbolic reasoning in Deep-ProbLog utilizes SDD (Sentential Decision Diagrams) (Darwiche, 2011) to construct a directed graph, which is then transformed into an arithmetic circuit for inference and answering queries. To enable end-to-end training that bridges continuous embedding and discrete symbols, DeepProbLog leverages the gradient semiring (Eisner, 2002) as an optimization tool. The framework of DeepProbLog is visually depicted in Fig. 14.

深度概率逻辑编程是一种概率编程语言，它通过使用“神经谓词”来集成深度学习。这些神经谓词充当神经网络和符号推理之间的接口。在深度概率逻辑编程中，例如，图像由神经网络处理，该网络将数据集中每个类别的分布作为逻辑事实输出，用于符号推理。具体而言，神经网络用于处理简单概念或非结构化数据，为深度概率逻辑编程中的符号推理生成输入。深度概率逻辑编程中的符号推理利用句子决策图(SDD)(Darwiche，2011年)构建有向图，然后将其转换为算术电路进行推理和回答查询。为了实现连接连续嵌入和离散符号的端到端训练，深度概率逻辑编程利用梯度半环(Eisner，2002年)作为优化工具。深度概率逻辑编程的框架如图14所示。

In a different approach to DeepProbLog, Zhou (2019) proposed abductive learning (ABL) as a framework that combines abductive reasoning (Aliseda, 2006) with induction. Abductive reasoning, which is a form of logical reasoning, involves inferring the best explanation for given observations or evidence. ABL leverages both induction, which is a key component of modern machine learning, and abduction, which is the process of generating hypotheses or explanations, in a mutually beneficial way. ABL provides a unified framework that bridges machine learning and logical reasoning, allowing for the integration of both approaches to improve the overall learning and reasoning process. This framework offers a new perspective and methodology for effectively combining machine learning techniques with logical reasoning techniques.

与深度概率逻辑编程不同的是，周(2019年)提出了溯因学习(ABL)框架，将溯因推理(Aliseda，2006年)与归纳相结合。溯因推理是一种逻辑推理形式，涉及为给定的观察结果或证据推断出最佳解释。溯因学习以互利的方式同时利用归纳(现代机器学习的关键组成部分)和溯因(生成假设或解释的过程)。溯因学习提供了一个统一的框架，连接了机器学习和逻辑推理，允许将两种方法集成以改进整体学习和推理过程。该框架为有效结合机器学习技术和逻辑推理技术提供了新的视角和方法。

In more detail, given raw data (This raw data only includes the data features and a label of true or false, with no label of the class.), an initialized classifier, and a knowledge base (KB), the raw data is fed into the initialized classifier to obtain pseudo-labels in machine learning. These pseudo-labels (pseudo-grounding) are then transformed into symbolic representations that can be accepted by logical reasoning. Next, ABL uses ProLog as the KB and adopts abductive reasoning technology to abduct the pseudo-labels and rules. That is to say, logical reasoning minimizes the inconsistency between the symbolic representation and the KB to revise pseudo-labels, then outputs the deductive labels. Finally, a new classifier is trained by the deductive labels and the raw data, which replaces the original classifier. The above is an iterative process that continues until the classifier is no longer changed or the pseudo-labels are consistent with the KB. ABL is a special kind of weakly supervised learning, in which the supervision information comes not only from the ground-truth labels but also from knowledge abduction.

更详细地说，给定原始数据(此原始数据仅包括数据特征和真假标签，没有类别标签)、一个初始化的分类器和一个知识库(KB)，将原始数据输入初始化的分类器以在机器学习中获得伪标签。然后将这些伪标签(伪基础)转换为逻辑推理可以接受的符号表示。接下来，溯因学习使用Prolog作为知识库，并采用溯因推理技术对伪标签和规则进行溯因。也就是说，逻辑推理最小化符号表示与知识库之间的不一致性以修正伪标签，然后输出演绎标签。最后，用演绎标签和原始数据训练一个新的分类器，以取代原来的分类器。上述是一个迭代过程，持续进行直到分类器不再改变或伪标签与知识库一致。溯因学习是一种特殊的弱监督学习，其中监督信息不仅来自真实标签，还来自知识溯因。

Based on the ABL framework, Tian et al. (2022) proposed a weakly supervised neural symbolic learning model (WS-NeSyL) for cognitive tasks with logical reasoning. The difference between WS-NeSyL and ABL is that ABL uses a metric of minimal inconsistency in logical reasoning, while WS-NeSyL adopts sampling technology. In WS-NeSyL, to provide supervised information for the reasoning process in complex reasoning tasks, the neural network is designed as an encoder-decoder framework that includes an encoder and two decoders (perceptive decoder and cognitive decoder). The encoder can encode input information as a vector, while the perceptive decoder decodes the vector to predict labels (pseudo-labels). According to these pseudo-labels and the sampled logic rules from the knowledge base, the cognitive decoder to reason results. To supervise the reasoning of the cognitive decoder, WS-NeSyL provides a back search algorithm to sample logic rules from the knowledge base to act as labels that are used to revise the predicted labels. To solve the sampling problem, WS-NeSyL introduces a regular term of logic rules. The whole model is trained iteratively until convergence.

基于溯因学习框架，田等人(2022年)提出了一种用于具有逻辑推理的认知任务的弱监督神经符号学习模型(WS - NeSyL)。WS - NeSyL与溯因学习的区别在于，溯因学习在逻辑推理中使用最小不一致性度量，而WS - NeSyL采用采样技术。在WS - NeSyL中，为了在复杂推理任务的推理过程中提供监督信息，神经网络被设计为一个编码器 - 解码器框架，包括一个编码器和两个解码器(感知解码器和认知解码器)。编码器可以将输入信息编码为向量，而感知解码器对向量进行解码以预测标签(伪标签)。根据这些伪标签和从知识库中采样的逻辑规则，认知解码器得出推理结果。为了监督认知解码器的推理，WS - NeSyL提供了一种反向搜索算法，从知识库中采样逻辑规则作为标签，用于修正预测标签。为了解决采样问题，WS - NeSyL引入了逻辑规则的正则项。整个模型进行迭代训练直到收敛。

The knowledge base is an important factor in logical reasoning, and different knowledge bases are used by different reasoning technologies. The above approaches use probabilistic logic programming language (ProbLog) as their knowledge base; notably, they only consider that neural networks can provide facts for the knowledge base, and do not quantify how many logic rules should be triggered by the neural networks. To resolve this issue, Yu et al. (2022) proposed a bi-level probabilistic graphical reasoning framework, called BPGR. To quantify the amount of symbolic knowledge that is triggered, BPGR uses MLN to model all logic rules. For instance, MLN can express the time at which a logic rule is true in the form of a potential function.

知识库是逻辑推理中的一个重要因素，不同的推理技术会使用不同的知识库。上述方法使用概率逻辑编程语言(ProbLog)作为其知识库；值得注意的是，它们仅考虑到神经网络可以为知识库提供事实，而没有量化神经网络应触发多少逻辑规则。为解决这一问题，Yu等人(2022年)提出了一个双层概率图推理框架，称为BPGR。为了量化被触发的符号知识的数量，BPGR使用马尔可夫逻辑网络(MLN)对所有逻辑规则进行建模。例如，MLN可以用势函数的形式表示逻辑规则为真的时间。

![0195ea36-14ee-7c5c-a9a7-c1c11f9ac59f_13_439_151_867_725_0.jpg](images/0195ea36-14ee-7c5c-a9a7-c1c11f9ac59f_13_439_151_867_725_0.jpg)

Fig. 14. The framework of DeepProLog. Machine learning is responsible for mapping the input (unstructured data or simple structured data) to the distribution of categories (if there are $n$ categories, the output distribution is $1 \times  n$ ). Logical reasoning is a complex problem described by ProbLog, which is constructed as an arithmetic circuit to solve the complex problem. Here, the root node is the query, while the leaf nodes are neural predicates and other (non-neural network output) probabilistic facts.

图14. DeepProLog的框架。机器学习负责将输入(非结构化数据或简单结构化数据)映射到类别分布(如果有 $n$ 个类别，输出分布为 $1 \times  n$ )。逻辑推理是一个由ProbLog描述的复杂问题，它被构建为一个算术电路来解决这个复杂问题。这里，根节点是查询，而叶节点是神经谓词和其他(非神经网络输出)概率事实。

![0195ea36-14ee-7c5c-a9a7-c1c11f9ac59f_13_307_1034_1135_427_0.jpg](images/0195ea36-14ee-7c5c-a9a7-c1c11f9ac59f_13_307_1034_1135_427_0.jpg)

Fig. 15. The framework of the BPGR. This model is a two-layers probabilistic graphical model which consists of a visual reasoning model and a symbolic reasoning module. Here, The high-level structure is the result of the visual reasoning module, while the low-level structure is the ground atom of logic rules. The model is trained to output reasoning results of the visual reasoning module based on symbolic knowledge. Note that $G$ represents the grounding operator, the solid line represents ground truth edges, and the dotted line represents pseudo-edges.

图15. BPGR的框架。该模型是一个两层概率图模型，由视觉推理模型和符号推理模块组成。这里，高层结构是视觉推理模块的结果，而低层结构是逻辑规则的基原子。该模型经过训练，可基于符号知识输出视觉推理模块的推理结果。请注意， $G$ 表示基元运算符，实线表示真实边，虚线表示伪边。

BPGR includes two parts: the visual reasoning module (VRM) and the symbolic reasoning module(SRM). VRM extracts the features of objects in images and the inferred labels of objects and relationships. SRM uses symbolic knowledge to guide the reasoning of ${VRM}$ in a good direction, which acts as an error correction. In terms of the model framework, more concretely, SRM is a double-layer probabilistic graph that contains two types of nodes: one is the reasoning results of the VRD model in the high-level structure, and the other is the ground atoms of logic rules in the low-level structure. When the probabilistic graphical model is constructed, BPGR can be efficiently trained in an end-to-end manner by the variational EM algorithm. An overall framework of BPGR is provided in Fig. 15.

BPGR包括两部分:视觉推理模块(VRM)和符号推理模块(SRM)。VRM提取图像中对象的特征以及对象和关系的推断标签。SRM使用符号知识引导 ${VRM}$ 朝着良好的方向进行推理，起到纠错的作用。就模型框架而言，更具体地说，SRM是一个双层概率图，包含两种类型的节点:一种是高层结构中VRD模型的推理结果，另一种是低层结构中逻辑规则的基原子。当构建好概率图模型后，BPGR可以通过变分EM算法以端到端的方式进行高效训练。图15展示了BPGR的整体框架。

Conclusion: The field of learning-reasoning approaches in AI research has gained significant attention due to the advantages it offers by combining neural networks and symbolic reasoning. The integration of neural networks and symbolic reasoning allows for the utilization of the strengths of both approaches. Neural networks provide the ability to process complex data and generate predictions, while symbolic reasoning provides a structured and interpretable framework for representing and reasoning about knowledge. For instance, DeepProbLog and ABL have similar model principles: the modeling of complex problems is defined in a logic programming language, and the neural network is used to define simple concepts in a logic programming language. BPGR uses neural networks to accelerate the search process of symbolic reasoning, along with symbolic knowledge to constrain neural network learning. This model not only characterizes the matching degree between prediction results and symbolic knowledge but also clearly states which symbolic knowledge is being fitted, along with the probability of this symbolic knowledge being fitted as an explanation for the model prediction. However, one limitation of these approaches is their reliance on predefined logic programming or logic rules, which restricts their generalizability to other tasks. Future research in this field should explore higher-level interactions between neural networks and symbolic reasoning, such as learning symbolic knowledge during training. By enhancing the ability of models to acquire and reason with symbolic knowledge in a data-driven manner, the field can further advance the integration of learning and reasoning in AI systems.

结论:人工智能研究中的学习 - 推理方法领域由于结合了神经网络和符号推理的优势而受到了广泛关注。神经网络和符号推理的集成使得能够利用这两种方法的长处。神经网络具备处理复杂数据和生成预测的能力，而符号推理则为知识的表示和推理提供了一个结构化且可解释的框架。例如，DeepProbLog和ABL具有相似的模型原理:用逻辑编程语言定义复杂问题的建模，并用神经网络在逻辑编程语言中定义简单概念。BPGR使用神经网络加速符号推理的搜索过程，同时利用符号知识约束神经网络学习。该模型不仅刻画了预测结果与符号知识之间的匹配程度，还明确指出了正在拟合的符号知识，以及该符号知识被拟合的概率，作为对模型预测的解释。然而，这些方法的一个局限性在于它们依赖于预定义的逻辑编程或逻辑规则，这限制了它们在其他任务上的泛化能力。该领域未来的研究应探索神经网络和符号推理之间更高级的交互，例如在训练过程中学习符号知识。通过增强模型以数据驱动的方式获取和推理符号知识的能力，该领域可以进一步推动人工智能系统中学习和推理的集成。

Based on representative works, we summarize a general design idea for neural-symbolic approaches. The interaction between neural networks and symbolic systems allows encoding the embedding of symbolic knowledge into neural network models and feeds abstracted symbols of the neural networks into symbolic systems. Further, we provide some characteristics that should be considered in designing neural-symbolic approaches, as follows: (1) Uncertainty. The output of the neural network is a distribution, not "True" or "False". Therefore, we need to consider the uncertainty of the triggered symbolic knowledge. (2) Globalization. It is necessary to consider the fit of all symbolic knowledge in the knowledge base, not just the local knowledge. (3) Importance. Different knowledge may have different weights, and the degree of fitting knowledge with different weights should be considered. (4) Interpretability. Interpretability should be explicitly considered in learning (e.g. the immediate process of the result of learning).

基于代表性工作，我们总结了神经 - 符号方法的一般设计思路。神经网络和符号系统之间的交互允许将符号知识的嵌入编码到神经网络模型中，并将神经网络抽象出的符号输入到符号系统中。此外，我们提供了在设计神经 - 符号方法时应考虑的一些特征，如下所示:(1)不确定性。神经网络的输出是一个分布，而不是“真”或“假”。因此，我们需要考虑被触发的符号知识的不确定性。(2)全局性。有必要考虑知识库中所有符号知识的拟合情况，而不仅仅是局部知识。(3)重要性。不同的知识可能具有不同的权重，应考虑不同权重知识的拟合程度。(4)可解释性。在学习过程中应明确考虑可解释性(例如学习结果的即时过程)。

## 4. Applications

## 4. 应用

### 4.1. Object/visual-relationship detection

### 4.1. 对象/视觉关系检测

The goal of object/visual-relationship detection is to recognize objects or the relationships between objects in images. However, relying solely on visual features to train a model often leads to relatively weak performance. In recent years, the emergence of neural-symbolic learning systems has paved the way for incorporating external knowledge to enhance the detection performance of these models. This integration of external knowledge into the learning process has shown promising results and has become an active area of research in the field.

目标/视觉关系检测的目标是识别图像中的物体或物体之间的关系。然而，仅依靠视觉特征来训练模型往往会导致性能相对较弱。近年来，神经符号学习系统的出现为整合外部知识以提高这些模型的检测性能铺平了道路。将外部知识整合到学习过程中已显示出有希望的结果，并成为该领域的一个活跃研究领域。

Donadello et al. (2017) propose a novel approach that combines neural networks with first-order logic, known as Logic Tensor Networks (LTN). By incorporating logical constraints, LTNs enable effective reasoning from noisy images while also providing a means to describe data characteristics through logic rules. This integration of logic into the neural network framework enhances interpretability in image recognition tasks. In the context of remote sensing, Forestier et al. (2013) and Marszalek and Schmid (2007) emphasize the utilization of symbolic knowledge from domain experts to improve the detection capabilities. By leveraging expert knowledge, the remote sensing systems can gain a deeper understanding of the data and achieve better performance in detecting specific features or patterns. Nyga et al. (2014) and Zhu et al. (2014) adopt a different approach by using Markov Logic Networks (MLN) to model symbolic knowledge for integration into deep learning models. MLNs allow for learning a scoring function and predicting relations between input images and specific objects or concepts. For example, given an input image of a horse, the model can predict the relation "ridable" between the horse and people. This approach combines the strengths of deep learning and symbolic reasoning, enabling more comprehensive and nuanced analysis of visual data.

多纳代洛(Donadello)等人(2017年)提出了一种将神经网络与一阶逻辑相结合的新方法，称为逻辑张量网络(Logic Tensor Networks，LTN)。通过纳入逻辑约束，逻辑张量网络能够从有噪声的图像中进行有效推理，同时还提供了一种通过逻辑规则描述数据特征的方法。将逻辑整合到神经网络框架中增强了图像识别任务的可解释性。在遥感领域，福雷斯捷(Forestier)等人(2013年)以及马尔扎莱克(Marszalek)和施密德(Schmid)(2007年)强调利用领域专家的符号知识来提高检测能力。通过利用专家知识，遥感系统可以更深入地理解数据，并在检测特定特征或模式方面取得更好的性能。尼加(Nyga)等人(2014年)和朱(Zhu)等人(2014年)采用了不同的方法，使用马尔可夫逻辑网络(Markov Logic Networks，MLN)对符号知识进行建模，以整合到深度学习模型中。马尔可夫逻辑网络允许学习一个评分函数，并预测输入图像与特定物体或概念之间的关系。例如，给定一张马的输入图像，模型可以预测马与人之间的“可骑乘”关系。这种方法结合了深度学习和符号推理的优势，能够对视觉数据进行更全面、细致的分析。

### 4.2. Knowledge graph reasoning

### 4.2. 知识图谱推理

Knowledge graphs often suffer from incompleteness, requiring completion or link prediction techniques to enhance their quality. Zhang, Chen, Zhang, Ke, and Ding (2021) provide a comprehensive survey on the benefits of knowledge graph reasoning within neural-symbolic learning systems. Wang, Duo et al. (2019) propose a method where triplets or ground rules are transformed into First-Order Logic (FOL) statements. These FOL statements are then scored using vector/matrix operations based on the embeddings of the entities and relationships involved. This approach combines logic reasoning with neural networks to perform link prediction in knowledge graphs. Path-based reasoning approaches (Das et al., 2017, 2016; Meilicke et al., 2020; Neelakantan et al., 2015; Xiong et al., 2017) aim to extend reasoning by exploring multi-hop neighbors around a given entity and predicting answers within these neighborhoods using neural networks. For example, DeepPath (Xiong et al., 2017) employs reinforcement learning to evaluate sampled paths, reducing the search space and improving efficiency. Building upon path-based reasoning, Teru et al. (2020) propose GraIL, a graph-based reasoning framework. GraIL extracts a subgraph consisting of the k-hop neighbors of the head and tail entities. Subsequently, a Graph Neural Network (GNN) is employed to reason about the relationship between the two entities using the extracted subgraph. These approaches demonstrate the integration of neural networks and graph-based reasoning to perform link prediction and enhance knowledge graph reasoning.

知识图谱常常存在不完整性问题，需要使用补全或链接预测技术来提高其质量。张(Zhang)、陈(Chen)、张(Zhang)、柯(Ke)和丁(Ding)(2021年)对神经符号学习系统中知识图谱推理的益处进行了全面综述。王(Wang)、多(Duo)等人(2019年)提出了一种方法，将三元组或基本规则转换为一阶逻辑(First-Order Logic，FOL)语句。然后，基于所涉及实体和关系的嵌入，使用向量/矩阵运算对这些一阶逻辑语句进行评分。这种方法将逻辑推理与神经网络相结合，用于在知识图谱中进行链接预测。基于路径的推理方法(达斯(Das)等人，2017年、2016年；梅利克(Meilicke)等人，2020年；尼尔坎坦(Neelakantan)等人，2015年；熊(Xiong)等人，2017年)旨在通过探索给定实体周围的多跳邻居，并使用神经网络在这些邻域内预测答案来扩展推理。例如，深度路径(DeepPath，熊等人，2017年)采用强化学习来评估采样路径，减少搜索空间并提高效率。在基于路径的推理基础上，特鲁(Teru)等人(2020年)提出了GraIL，一种基于图的推理框架。GraIL提取由头实体和尾实体的k跳邻居组成的子图。随后，使用图神经网络(Graph Neural Network，GNN)利用提取的子图来推理两个实体之间的关系。这些方法展示了神经网络与基于图的推理的整合，以进行链接预测并增强知识图谱推理。

### 4.3. Classification/ few-shot classification

### 4.3. 分类/少样本分类

Marra, Diligenti et al. (2020) introduce Relational Neural Machines (RNM), a framework that allows for joint training of learners and reasoners. This approach enables the integration of both learning and reasoning processes, leading to improved performance. To address the few-shot learning problem, Sikka et al. (2020) incorporate common sense knowledge into deep neural networks. They also utilize logical knowledge as a neural-symbolic loss function to regularize visual semantic features. This approach leverages information from unseen classes during model learning, enhancing zero-shot learning capabilities. Altszyler, Brusco, Basiou, Byrnes, and Vergyri (2021) integrate logic rules into neural network architectures for multi-domain dialogue recognition tasks. By incorporating logical knowledge, the model can recognize labels of unseen classes without requiring additional training data. This approach expands the model's ability to handle previously unseen classes in the dialogue recognition domain. These methods demonstrate the integration of logical knowledge, common sense knowledge, and neural networks to improve the performance of various tasks, such as joint training, few-shot learning, and multi-domain dialogue recognition.

马拉(Marra)、迪利根蒂(Diligenti)等人(2020年)引入了关系神经机(Relational Neural Machines，RNM)，这是一个允许对学习器和推理器进行联合训练的框架。这种方法能够将学习和推理过程整合在一起，从而提高性能。为了解决少样本学习问题，西卡(Sikka)等人(2020年)将常识知识整合到深度神经网络中。他们还将逻辑知识用作神经符号损失函数，以规范视觉语义特征。这种方法在模型学习过程中利用来自未见类别的信息，增强了零样本学习能力。阿尔茨齐勒(Altszyler)、布鲁斯库(Brusco)、巴西乌(Basiou)、伯恩斯(Byrnes)和韦尔吉里(Vergyri)(2021年)将逻辑规则整合到神经网络架构中，用于多领域对话识别任务。通过纳入逻辑知识，模型可以识别未见类别的标签，而无需额外的训练数据。这种方法扩展了模型在对话识别领域处理先前未见类别的能力。这些方法展示了逻辑知识、常识知识和神经网络的整合，以提高各种任务的性能，如联合训练、少样本学习和多领域对话识别。

### 4.4. Intelligent question answering

### 4.4. 智能问答

Indeed, intelligent question answering is a prominent application of neural-symbolic reasoning in natural language processing and visual reasoning tasks. In this context, the goal is to develop models that can accurately infer answers to questions by leveraging contextual information from text and images.

实际上，智能问答是神经符号推理在自然语言处理和视觉推理任务中的一个突出应用。在这种情况下，目标是开发能够通过利用文本和图像中的上下文信息准确推断问题答案的模型。

Andreas, Rohrbach, Darrell, and Klein (2016) proposed the neural module network (NMN) framework, which uses deep neural network generating symbolic structures to solve subsequent reasoning problems. Gupta et al. (2020) extend NMN and propose an unsupervised auxiliary loss to help extract arguments associated with the events in the text. Specifically, this method introduces a reasoning module for the text that enables symbolic reasoning (such as arithmetic, sorting, and counting) on numbers and dates in a probabilistic or differentiable way, allowing the model to output logical parsing of questions and intermediate decisions.

安德里亚斯(Andreas)、罗尔巴赫(Rohrbach)、达雷尔(Darrell)和克莱因(Klein)(2016年)提出了神经模块网络(Neural Module Network，NMN)框架，该框架使用深度神经网络生成符号结构来解决后续的推理问题。古普塔(Gupta)等人(2020年)扩展了NMN，并提出了一种无监督辅助损失，以帮助提取与文本中事件相关的参数。具体而言，该方法为文本引入了一个推理模块，该模块能够以概率或可微的方式对数字和日期进行符号推理(如算术、排序和计数)，使模型能够输出问题的逻辑解析和中间决策。

Hudson and Manning (2018) propose a fully differentiable network model (MAC) with cyclic memory, attention, and composition functions. The MAC provides strong prior conditions for iterative reasoning, transforms the black-box architecture into something more transparent, and supports interpretability and structured learning. The core concept is to decompose the image and the question into sequential units, input the recurrent network for sequential reasoning, and then store the result in the memory unit to calculate the final answer together with the question. Tran and Davis (2008) and Poon and Domingos (2009) model domain common sense with MLN and use probabilistic inference methods for the query. Sun et al. (2020) learned a neural semantic parser and trained a model-agnostic model based on meta-learning to improve the predictive ability of language question-answering tasks cases involving limited simple rules.

哈德森(Hudson)和曼宁(Manning)(2018年)提出了一种具有循环记忆、注意力和组合功能的全可微网络模型(Memory, Attention, Composition，MAC)。MAC为迭代推理提供了强大的先验条件，将黑盒架构转变为更透明的架构，并支持可解释性和结构化学习。其核心概念是将图像和问题分解为顺序单元，输入循环网络进行顺序推理，然后将结果存储在记忆单元中，与问题一起计算最终答案。特兰(Tran)和戴维斯(Davis)(2008年)以及潘(Poon)和多明戈斯(Domingos)(2009年)使用马尔可夫逻辑网络(Markov Logic Network，MLN)对领域常识进行建模，并使用概率推理方法进行查询。孙(Sun)等人(2020年)学习了一种神经语义解析器，并基于元学习训练了一个与模型无关的模型，以提高涉及有限简单规则的语言问答任务案例的预测能力。

Oltramari et al. (2021) proposed integrating neural language models and knowledge graphs in common-sense question answering. Based on the architecture of the language model, this work proposes an attention-based knowledge injection method. For visual question-answering tasks, Hudson and Manning (2019) propose the neural state machine (NSM). NSM uses a supervised training method to construct a probabilistic scene graph based on the concepts in an image, then performs sequential reasoning on the probabilistic scene graph, answering questions or discovering new conclusions.

奥尔塔拉马里(Oltramari)等人(2021年)提出在常识问答中集成神经语言模型和知识图谱。基于语言模型的架构，这项工作提出了一种基于注意力的知识注入方法。对于视觉问答任务，哈德森(Hudson)和曼宁(Manning)(2019年)提出了神经状态机(Neural State Machine，NSM)。NSM使用有监督的训练方法，基于图像中的概念构建概率场景图，然后对概率场景图进行顺序推理，回答问题或发现新的结论。

### 4.5. Reinforcement learning

### 4.5. 强化学习

Deep reinforcement learning is a trending topic in the field of artificial intelligence, and it has been successfully applied in many contexts. However, current deep reinforcement learning methods have limitations in reasoning ability. To address this challenge, researchers have started integrating symbolic knowledge into reinforcement learning. In this paper, we explore two approaches: combining symbolic knowledge with deep reinforcement learning and combining symbolic knowledge with hierarchical reinforcement learning.

深度强化学习是人工智能领域的一个热门话题，它已在许多场景中得到成功应用。然而，当前的深度强化学习方法在推理能力方面存在局限性。为应对这一挑战，研究人员已开始将符号知识集成到强化学习中。在本文中，我们探索两种方法:将符号知识与深度强化学习相结合，以及将符号知识与分层强化学习相结合。

Garnelo et al. (2016) proposed a deep symbolic reinforcement learning method (DSRL) that integrates a symbolic prior into the agent's learning process to enhance the model's generalization. The DSRL agent consists of a neural back end and a symbolic front end. The neural back end learns to map raw sensor data into a symbolic representation, which is then utilized by the symbolic front end to learn an effective policy. Building upon DSRL, Garcez et al. (2018) extended the approach and introduced a symbolic reinforcement learning method with common sense (SRL+CS). This method improves both the learning phase and the decision-making phase based on DSRL. In the learning phase, the reward distribution is no longer based on a fixed calculation formula for updating the Q-values, but instead considers the interaction between the agent and the object. In the decision-making stage, the model assigns an importance weight to each Q-function based on the distance between the object and the agent, allowing for a comprehensive aggregation of the Q-values.

加内洛(Garnelo)等人(2016年)提出了一种深度符号强化学习方法(Deep Symbolic Reinforcement Learning，DSRL)，该方法将符号先验集成到智能体的学习过程中，以增强模型的泛化能力。DSRL智能体由一个神经后端和一个符号前端组成。神经后端学习将原始传感器数据映射到符号表示，然后符号前端利用该符号表示学习有效的策略。在DSRL的基础上，加尔塞斯(Garcez)等人(2018年)扩展了该方法，并引入了一种具有常识的符号强化学习方法(Symbolic Reinforcement Learning with Common Sense，SRL+CS)。该方法在DSRL的基础上改进了学习阶段和决策阶段。在学习阶段，奖励分布不再基于固定的计算公式来更新Q值，而是考虑智能体与对象之间的交互。在决策阶段，模型根据对象与智能体之间的距离为每个Q函数分配一个重要性权重，从而实现Q值的综合聚合。

Yang et al. (2018) proposed the integration of symbolic planning and hierarchical reinforcement learning (HRL) (Barto & Ma-hadevan, 2003) to address decision-making in dynamic environments with uncertainties. They introduced a framework called PEORL (Planning-Execution-Observation-Reinforcement-Learning) that combines these two approaches. Symbolic planning is employed to guide the agent's task execution and learning process, while the learned experiences are fed back to the symbolic knowledge to enhance the planning phase. Specifically, commonsense knowledge of actions constrains the answer set solver to generate a symbolic plan. The symbolic plan is subsequently mapped to a deterministic sequence of stochastic options, which guides the hierarchical reinforcement learning (HRL) process. This approach represents the first utilization of symbolic planning for option discovery within the HRL framework. To achieve task-level interpretability, Lyu, Yang, Liu, and Gustafson (2019) proposed the Symbolic Deep Reinforcement Learning (SDRL) framework, which shares similarities with REORL and consists of a planner, controller, and meta-controller, along with symbolic knowledge. The planner employs prior symbolic knowledge to perform long-term planning through a sequence of symbolic actions (subtasks) that aim to achieve its intrinsic goal. The controller utilizes deep reinforcement learning (DRL) algorithms to learn sub-policies for each subtask based on intrinsic rewards. The meta-controller learns extrinsic rewards by evaluating the training performance of the controllers and suggesting new intrinsic goals to the planner. In essence, both PEORL and SDRL leverage symbolic knowledge to guide the reinforcement learning process and facilitate decision-making.

杨等人(2018年)提出将符号规划与分层强化学习(HRL)(巴托和马哈德万，2003年)相结合，以解决不确定动态环境中的决策问题。他们引入了一个名为PEORL(规划 - 执行 - 观察 - 强化学习)的框架，该框架结合了这两种方法。符号规划用于指导智能体的任务执行和学习过程，同时将学习到的经验反馈给符号知识，以改进规划阶段。具体而言，动作的常识性知识会约束答案集求解器生成符号规划。随后，该符号规划会被映射为一个确定性的随机选项序列，用于指导分层强化学习(HRL)过程。这种方法首次在HRL框架内利用符号规划进行选项发现。为了实现任务级别的可解释性，吕、杨、刘和古斯塔夫森(2019年)提出了符号深度强化学习(SDRL)框架，该框架与REORL有相似之处，由规划器、控制器、元控制器以及符号知识组成。规划器利用先验符号知识，通过一系列旨在实现其内在目标的符号动作(子任务)进行长期规划。控制器利用深度强化学习(DRL)算法，基于内在奖励为每个子任务学习子策略。元控制器通过评估控制器的训练表现来学习外在奖励，并向规划器建议新的内在目标。本质上，PEORL和SDRL都利用符号知识来指导强化学习过程并促进决策制定。

## 5. Future directions

## 5. 未来研究方向

The above paper introduces the current research status and research methods of neural-symbolic learning systems in detail. On this basis, we discuss some potential future research directions.

上述论文详细介绍了神经符号学习系统的当前研究现状和研究方法。在此基础上，我们探讨了一些潜在的未来研究方向。

### 5.1. Efficient methods

### 5.1. 高效方法

In neural-symbolic learning systems, symbolic reasoning technologies often encounter challenges related to intractable precise inference. For instance, in probability inference using Markov Logic Networks (MLNs), the number of groundings can increase exponentially when dealing with a large number of logic rules and constants. This exponential growth in grounding can significantly decrease the speed of model inference. While several methods have been proposed to mitigate this problem, such as learning-based approaches (Bach et al., 2015; Khot et al., 2011), they still have certain limitations. Approximate inference techniques are commonly employed to improve inference speed but often come at the cost of reduced accuracy. Consequently, it becomes crucial for researchers to explore the potential of neural networks to tackle the computational challenges faced by symbolic systems. Designing approaches that leverage the computational strengths of neural networks to handle tasks that are computationally difficult in traditional symbolic systems represents a crucial research direction for advancing inference methods.

在神经符号学习系统中，符号推理技术常常面临难以处理精确推理的挑战。例如，在使用马尔可夫逻辑网络(MLNs)进行概率推理时，当处理大量逻辑规则和常量时，基础实例的数量会呈指数级增长。这种基础实例的指数级增长会显著降低模型推理的速度。虽然已经提出了几种方法来缓解这个问题，如基于学习的方法(巴赫等人，2015年；霍特等人，2011年)，但它们仍然存在一定的局限性。近似推理技术通常用于提高推理速度，但往往会以降低准确性为代价。因此，研究人员探索神经网络解决符号系统所面临的计算挑战的潜力变得至关重要。设计利用神经网络的计算优势来处理传统符号系统中计算困难的任务的方法，是推进推理方法的一个关键研究方向。

### 5.2. Automatic construction of symbolic knowledge

### 5.2. 符号知识的自动构建

The symbolic knowledge discussed in this paper encompasses logic knowledge and knowledge graphs. Automatic construction of symbolic knowledge has achieved relative maturity, as evidenced by studies on automatic knowledge construction (LiuQiao, DuanHong, et al., 2016; Luan, He, Ostendorf, & Hajishirzi, 2018; Martinez-Rodriguez, López-Arévalo, & Rios-Alvarado, 2018). However, the construction of logic rules in neural-symbolic approaches typically relies on manual efforts from domain experts. This process is time-consuming, laborious, and not easily scalable. A significant challenge for neural-symbolic learning systems is enabling end-to-end learning for rules that describe prior knowledge derived from data. While technologies like Inductive Logic Programming (ILP)-based methods exist for knowledge extraction, the automatic learning of logic rules from data remains largely unexplored. Hence, the automatic construction of rules represents an important future research direction in the field of neural-symbolic learning systems.

本文讨论的符号知识包括逻辑知识和知识图谱。符号知识的自动构建已取得了相对成熟的成果，自动知识构建的相关研究(刘乔、段宏等人，2016年；栾、何、奥斯坦多夫和哈吉希尔齐，2018年；马丁内斯 - 罗德里格斯、洛佩斯 - 阿雷瓦洛和里奥斯 - 阿尔瓦拉多，2018年)就证明了这一点。然而，神经符号方法中逻辑规则的构建通常依赖领域专家的手动工作。这个过程既耗时又费力，且不易扩展。神经符号学习系统面临的一个重大挑战是实现对从数据中提取的先验知识规则的端到端学习。虽然存在基于归纳逻辑编程(ILP)等技术的知识提取方法，但从数据中自动学习逻辑规则在很大程度上仍未得到充分探索。因此，规则的自动构建是神经符号学习系统领域未来一个重要的研究方向。

### 5.3. Symbolic representation learning

### 5.3. 符号表示学习

A well-designed symbolic representation plays a crucial role in simplifying and improving the efficiency of complex learning tasks. In the context of zero-shot image classification, for instance, a limited semantic information contained in a learned symbolic representation can hinder the model's ability to handle complex classification tasks effectively. Therefore, precise semantic information encoded in symbolic knowledge is essential for enhancing the performance of these models. However, most existing symbolic representation learning methods struggle with predicates that exhibit strong similarity. These predicates may have similar semantics but different logical formulas, such as "next to" and "near". Current symbolic representation learning methods fail to capture such semantic similarities, which hampers the reasoning capability of these models. Thus, a significant challenge in the field of neural-symbolic learning systems is the design of more robust and efficient symbolic representation learning methods. The advancement of graph representation learning offers a promising avenue for addressing this challenge. By mapping nodes to low-dimensional, dense, and continuous vectors, graph representation learning can flexibly support various learning and reasoning tasks. Given that symbolic knowledge often exhibits heterogeneity, multiple relations, and even multimodality, exploring the development and utilization of heterogeneous graph representation learning methods becomes another important direction to overcome the challenges faced by neural-symbolic learning systems.

设计良好的符号表示在简化和提高复杂学习任务的效率方面起着至关重要的作用。例如，在零样本图像分类的情境中，学习到的符号表示中包含的有限语义信息会阻碍模型有效处理复杂分类任务的能力。因此，符号知识中编码的精确语义信息对于提高这些模型的性能至关重要。然而，大多数现有的符号表示学习方法在处理具有强相似性的谓词时存在困难。这些谓词可能具有相似的语义，但逻辑公式不同，例如“在……旁边”(next to)和“靠近”(near)。当前的符号表示学习方法无法捕捉到这种语义相似性，这阻碍了这些模型的推理能力。因此，神经符号学习系统领域的一个重大挑战是设计更强大、更高效的符号表示学习方法。图表示学习的发展为解决这一挑战提供了一条有前景的途径。通过将节点映射到低维、密集且连续的向量，图表示学习可以灵活地支持各种学习和推理任务。鉴于符号知识通常具有异构性、多种关系甚至多模态性，探索异构图形表示学习方法的开发和应用成为克服神经符号学习系统所面临挑战的另一个重要方向。

### 5.4. Application field expansion

### 5.4. 应用领域拓展

Neural-symbolic learning systems have found applications in various domains, including computer vision, natural language processing, and recommendation systems (Raizada, 2022; Zhu, Xian, Fu, de Melo, & Zhang, 2021). Recently, researchers have also started exploring the potential of applying neural-symbolic learning systems in other areas such as the COVID-19 pandemic (Ngan, Garcez, & Townsend, 2022) and advanced robotics (Conti, Varde, & Wang, 2020). For example, in the context of the COVID-19 pandemic, neural-symbolic learning systems have been utilized for tasks like extracting relevant information from medical literature. Similarly, in the field of advanced robotics, neural-symbolic learning systems can be employed to enhance robot intelligence and decision-making capabilities. Given the success of neural-symbolic learning systems in existing domains, it is a natural and promising direction to extend their application to new domains and develop tailored methods to address specific challenges in those areas.

神经符号学习系统已在多个领域得到应用，包括计算机视觉、自然语言处理和推荐系统(拉伊扎达，2022年；朱、冼、傅、德梅洛和张，2021年)。最近，研究人员也开始探索将神经符号学习系统应用于其他领域的潜力，如新冠疫情(颜、加塞斯和汤森，2022年)和先进机器人技术(孔蒂、瓦德和王，2020年)。例如，在新冠疫情背景下，神经符号学习系统已被用于从医学文献中提取相关信息等任务。同样，在先进机器人技术领域，神经符号学习系统可用于增强机器人的智能和决策能力。鉴于神经符号学习系统在现有领域的成功，将其应用扩展到新领域并开发定制方法以解决这些领域的特定挑战是一个自然且有前景的方向。

## 6. Conclusion

## 6. 结论

In this paper, we have presented an overall framework for neural-symbolic learning systems. Our main contribution is the proposal of a novel taxonomy for neural-symbolic learning systems and the outline of three structured categorizations. Additionally, we describe the techniques used in each structured categorization, explore a wide range of applications, and discuss future directions for neural-symbolic learning systems. We firmly believe that a systematic and comprehensive research survey in this field holds significant value in terms of both theory and application. It deserves further in-depth research and discussion.

在本文中，我们提出了一个神经符号学习系统的总体框架。我们的主要贡献是为神经符号学习系统提出了一种新颖的分类法，并概述了三种结构化分类。此外，我们描述了每种结构化分类中使用的技术，探索了广泛的应用，并讨论了神经符号学习系统的未来发展方向。我们坚信，对该领域进行系统而全面的研究综述在理论和应用方面都具有重要价值。值得进一步深入研究和探讨。

## CRediT authorship contribution statement

## 作者贡献声明

Dongran Yu: Investigation, Data curation, Methodology, Writing. Bo Yang: Conceptualization, Supervision, Review, Editing. Dayou Liu: Supervision. Hui Wang: Supervision. Shirui Pan: Supervision, Review, Editing.

于东冉:调查、数据整理、方法学、写作。杨博:概念构思、监督、审核、编辑。刘大有:监督。王辉:监督。潘世瑞:监督、审核、编辑。

## Declaration of competing interest

## 利益冲突声明

The authors declare that they have no known competing financial interests or personal relationships that could have appeared to influence the work reported in this paper.

作者声明，他们没有已知的可能影响本文所报告工作的竞争性财务利益或个人关系。

## Data availability

## 数据可用性

The authors are unable or have chosen not to specify which data has been used.

作者无法或选择不指定使用了哪些数据。

## Acknowledgments

## 致谢

This work was supported by the National Key R&D Program of China under Grant Nos. [2021ZD0112501, 2021ZD0112502]; the National Natural Science Foundation of China under Grant Nos. [U22A2098, 62172185, 62206105 and 62202200].

本工作得到了中国国家重点研发计划(项目编号:[2021ZD0112501, 2021ZD0112502])；国家自然科学基金(项目编号:[U22A2098, 62172185, 62206105和62202200])的资助。

## Appendix. Preliminaries

## 附录. 预备知识

In this section, we introduce background information related to symbolic knowledge and neural networks. For symbolic knowledge, we focus on two categories: logic knowledge and knowledge graphs. Logic knowledge can be further subdivided into propositional logic and first-order logic.

在本节中，我们介绍与符号知识和神经网络相关的背景信息。对于符号知识，我们主要关注两类:逻辑知识和知识图谱。逻辑知识可以进一步细分为命题逻辑和一阶逻辑。

### A.1. Symbols

### A.1. 符号

#### A.1.1. Propositional logic

#### A.1.1. 命题逻辑

Propositional logic statements are declarative sentences that are either True or False. A declarative sentence is a True sentence if it is consistent with the fact; otherwise, it is a False sentence. The connectors between propositions are " $\land$ "," $\vee$ "," $\neg$ " and " $\Rightarrow$ ". Propositional logic can be expressed in the form of the following formula:

命题逻辑语句是陈述句，其真值为真或假。如果一个陈述句与事实相符，则为真语句；否则，为假语句。命题之间的连接词有“ $\land$ ”、“ $\vee$ ”、“ $\neg$ ”和“ $\Rightarrow$ ”。命题逻辑可以用以下公式形式表示:

$$
P \Rightarrow  Q\text{,} \tag{9}
$$

where $P$ represents the antecedent (condition), while $Q$ represents the consequent (conclusion).

其中 $P$ 表示前件(条件)，而 $Q$ 表示后件(结论)。

Propositional logic is usually compiled in the form of directed acyclic graphs. Conjunctive Normal Forms (CNFs), deterministic-Decomposable Negation Normal Forms (d-DNNFs) (Darwiche, 2001; Darwiche & Marquis, 2002), and Sentential Decision Diagrams (SDDs) (Darwiche, 2011) are representative examples of knowledge representation, where SDD is a subset of d-DNNFs. For example, given a propositional logic Smokes $\Rightarrow$ Cough, its CNF and d-DNNF graph are presented in Fig. 16(a) and Fig. 16(b), respectively.

命题逻辑通常以有向无环图的形式进行编译。合取范式(CNFs)、确定性可分解否定范式(d - DNNFs)(Darwiche, 2001; Darwiche & Marquis, 2002)和语句决策图(SDDs)(Darwiche, 2011)是知识表示的典型示例，其中SDD是d - DNNFs的一个子集。例如，给定一个命题逻辑“吸烟 $\Rightarrow$ 咳嗽”，其CNF图和d - DNNF图分别如图16(a)和图16(b)所示。

#### A.1.2. First- order logic

#### A.1.2. 一阶逻辑

Propositional logic is hard to describe complex problems; for these, predicate logic is required. In this paper, we introduce one of the predicate logic-first-order logic (FOL) (Enderton, 2001). FOL consists of four types of elements, connectors, and quantifiers. The four types include constants, variables, functions, and predicates. Constants represent objects in the domain of interest (for example, in the predicate father(a, b), a=Bob, b=Mara, a and b are constant). Variables range over the objects in the domain (for example, in the predicate father(x, y), where $x$ is the father of $y$ , and the variable $x$ is limited to the scope of the father class). Functions represent mappings from tuples of objects to objects. Predicates represent relations among objects in a given domain or attributes of these objects. The connector is the same as in propositional logic. FOL involves the combination of atoms through connectors, such that an expression can be written in the following form:

命题逻辑难以描述复杂问题；对于这些问题，需要使用谓词逻辑。在本文中，我们介绍谓词逻辑之一——一阶逻辑(FOL)(Enderton, 2001)。一阶逻辑由四种类型的元素、连接词和量词组成。这四种类型包括常量、变量、函数和谓词。常量表示感兴趣的领域中的对象(例如，在谓词“father(a, b)”中，a = 鲍勃，b = 玛拉，a和b是常量)。变量的取值范围是领域中的对象(例如，在谓词“father(x, y)”中，其中 $x$ 是 $y$ 的父亲，变量 $x$ 被限制在父亲类的范围内)。函数表示从对象元组到对象的映射。谓词表示给定领域中对象之间的关系或这些对象的属性。连接词与命题逻辑中的相同。一阶逻辑涉及通过连接词组合原子，使得一个表达式可以写成以下形式:

$$
{B}_{1}\left( x\right)  \land  {B}_{2}\left( x\right)  \land  \cdots  \land  {B}_{n}\left( x\right)  \Rightarrow  H\left( x\right) , \tag{10}
$$

![0195ea36-14ee-7c5c-a9a7-c1c11f9ac59f_17_366_151_1013_548_0.jpg](images/0195ea36-14ee-7c5c-a9a7-c1c11f9ac59f_17_366_151_1013_548_0.jpg)

Fig. 16. Directed acyclic graph of CNF and d-DNNF. In the graph, leaf nodes represent atoms of propositional logic, and other nodes represent connectors. Directed edges are the relationship between nodes.

图16. CNF和d - DNNF的有向无环图。在图中，叶节点表示命题逻辑的原子，其他节点表示连接词。有向边表示节点之间的关系。

Table 4

表4

An instance of a Markov logical network.

马尔可夫逻辑网络的一个实例。

<table><tr><td>Proposition</td><td>First-order logic</td><td>Weight</td></tr><tr><td>Smoking causes cough.</td><td>${F1} : \forall x,\operatorname{Smokes}\left( x\right)  \Rightarrow  \operatorname{Cough}\left( x\right)$</td><td>1.5</td></tr><tr><td>If two people are friends, either both smoke or neither does.</td><td>${F2} : \forall x\forall y,$ Friends $\left( {x, y}\right)  \Rightarrow  \left( {\text{ Smokes }\left( x\right)  \Leftrightarrow  \text{ Smokes }\left( y\right) }\right)$</td><td>1.1</td></tr></table>

<table><tbody><tr><td>命题</td><td>一阶逻辑</td><td>权重</td></tr><tr><td>吸烟会导致咳嗽。</td><td>${F1} : \forall x,\operatorname{Smokes}\left( x\right)  \Rightarrow  \operatorname{Cough}\left( x\right)$</td><td>1.5</td></tr><tr><td>如果两个人是朋友，那么要么两人都吸烟，要么两人都不吸烟。</td><td>${F2} : \forall x\forall y,$ 朋友 $\left( {x, y}\right)  \Rightarrow  \left( {\text{ Smokes }\left( x\right)  \Leftrightarrow  \text{ Smokes }\left( y\right) }\right)$</td><td>1.1</td></tr></tbody></table>

where ${B}_{1}\left( x\right) ,{B}_{2}\left( x\right) ,\cdots ,{B}_{n}\left( x\right)$ represents the rule body, which is composed of multiple atoms. $H\left( x\right)$ represents the rule head and is the result derived from the rule body.

其中 ${B}_{1}\left( x\right) ,{B}_{2}\left( x\right) ,\cdots ,{B}_{n}\left( x\right)$ 表示规则体，它由多个原子组成。$H\left( x\right)$ 表示规则头，是从规则体推导得出的结果。

Knowledge representation of FOL can be achieved by a Markov logic network (MLN) (Richardson & Domingos, 2006). MLN is an undirected graph in which each node represents a variable, and the joint distribution is represented as follows:

一阶逻辑(FOL)的知识表示可以通过马尔可夫逻辑网络(Markov logic network，MLN)来实现(Richardson & Domingos, 2006)。MLN 是一种无向图，其中每个节点代表一个变量，联合分布表示如下:

$$
P\left( {X = x}\right)  = 1/\operatorname{Zexp}\left\{  {\mathop{\sum }\limits_{i}{w}_{i}{n}_{i}\left( x\right) }\right\}   \tag{11}
$$

where $Z$ represents the partition function, ${w}_{i}$ represents the weight of the rule, ${n}_{i}\left( x\right)$ represents the number of times that the value of the rule is true, and we use t-norm fuzzy logic (Novák, Perfilieva, & Mockor, 2012) to calculate logical connectives.

其中 $Z$ 表示配分函数，${w}_{i}$ 表示规则的权重，${n}_{i}\left( x\right)$ 表示规则值为真的次数，并且我们使用 t-范数模糊逻辑(t-norm fuzzy logic)(Novák, Perfilieva, & Mockor, 2012)来计算逻辑连接词。

The following introduces a simple example of an MLN. Table 4 shows the two rules $\left( {{F}_{1},{1.5}}\right) ,\left( {{F}_{2},{1.1}}\right)$ of this example (Domingos &Lowd,2019). Given a constant set $C = \{ A, B\}$ , the generated ground Markov logic network is shown in Fig. 17.

下面介绍一个 MLN 的简单示例。表 4 展示了此示例的两条规则 $\left( {{F}_{1},{1.5}}\right) ,\left( {{F}_{2},{1.1}}\right)$(Domingos & Lowd, 2019)。给定一个常量集 $C = \{ A, B\}$，生成的基础马尔可夫逻辑网络如图 17 所示。

#### A.1.3. Knowledge graph

#### A.1.3. 知识图谱

A knowledge graph is a directed and labeled graph. Nodes in this graph represent semantic symbols (concepts), such as animals, computers, people, etc; for their part, edges connect node pairs and express the semantic relationships between them, such as the food chain relationship between animals, friend relationship between people, etc. Knowledge graphs can be formally expressed in the form: $G = \left( {H, R, T}\right)$ , here, $H = \left\{  {{h}_{1},{h}_{2},\ldots ,{h}_{n}}\right\}$ represents the set of head entities, and $n$ represents the number of head entities, $T = \left\{  {{t}_{1},{t}_{2},\ldots ,{t}_{m}}\right\}$ represents the set of tail entities, and $m$ represents the number of tail entities; moreover, $R = \left\{  {{r}_{1},{r}_{2},\ldots ,{r}_{k}}\right\}$ represents the set of relationships, and $k$ represents the number of relationships. Fig. 18 presents an example. For a given triplet (cat, attribute, paw), the nodes (head entity and tail entity) are cat and paw, and the relationship is an attribute.

知识图谱是一种有向带标签的图。该图中的节点代表语义符号(概念)，例如动物、计算机、人等；而边连接节点对并表达它们之间的语义关系，例如动物之间的食物链关系、人之间的朋友关系等。知识图谱可以形式化地表示为:$G = \left( {H, R, T}\right)$，这里，$H = \left\{  {{h}_{1},{h}_{2},\ldots ,{h}_{n}}\right\}$ 表示头实体的集合，$n$ 表示头实体的数量，$T = \left\{  {{t}_{1},{t}_{2},\ldots ,{t}_{m}}\right\}$ 表示尾实体的集合，$m$ 表示尾实体的数量；此外，$R = \left\{  {{r}_{1},{r}_{2},\ldots ,{r}_{k}}\right\}$ 表示关系的集合，$k$ 表示关系的数量。图 18 给出了一个示例。对于给定的三元组(猫，属性，爪子)，节点(头实体和尾实体)是猫和爪子，关系是属性。

For their part, a knowledge graph representation is used to encode discrete symbols (entities, attributes, relationships, etc.) into a low-dimensional vector space to obtain a distributed representation. Typical methods include R-GCN (Schlichtkrull et al., 2018), M-GNN (Wang, Ren, He, Zhang & Hu, 2019), CompGCN (Vashishth, Sanyal, Nitin, & Talukdar, 2020), TransE (Bordes, Usunier, Garcia-Duran, Weston, & Yakhnenko, 2013), TransR (Lin, Liu, Sun, Liu, & Zhu, 2015), TransH (Wang, Zhang, Feng, & Chen, 2014), RotatE (Sun, Deng, Nie, & Tang, 2019), DisMult (Yang, Yih, He, Gao, & Deng, 2015), ComplEX (Trouillon, Welbl, Riedel, Gaussier, & Bouchard, 2016), ConvE (Dettmers, Minervini, Stenetorp, & Riedel, 2018), ConvR (Jiang, Wang, & Wang, 2019), GGNN (Li, Tarlow, Brockschmidt, & Zemel, 2016), and GCN (Kipf & Welling, 2017), among others.

知识图谱表示用于将离散符号(实体、属性、关系等)编码到低维向量空间中以获得分布式表示。典型的方法包括关系图卷积网络(R-GCN)(Schlichtkrull 等人，2018)、多图神经网络(M-GNN)(Wang, Ren, He, Zhang & Hu, 2019)、组合图卷积网络(CompGCN)(Vashishth, Sanyal, Nitin, & Talukdar, 2020)、转换嵌入模型(TransE)(Bordes, Usunier, Garcia-Duran, Weston, & Yakhnenko, 2013)、关系转换模型(TransR)(Lin, Liu, Sun, Liu, & Zhu, 2015)、超平面转换模型(TransH)(Wang, Zhang, Feng, & Chen, 2014)、旋转嵌入模型(RotatE)(Sun, Deng, Nie, & Tang, 2019)、双线性模型(DisMult)(Yang, Yih, He, Gao, & Deng, 2015)、复数嵌入模型(ComplEX)(Trouillon, Welbl, Riedel, Gaussier, & Bouchard, 2016)、卷积嵌入模型(ConvE)(Dettmers, Minervini, Stenetorp, & Riedel, 2018)、卷积关系模型(ConvR)(Jiang, Wang, & Wang, 2019)、门控图神经网络(GGNN)(Li, Tarlow, Brockschmidt, & Zemel, 2016)和图卷积网络(GCN)(Kipf & Welling, 2017)等。

### A.2. Neural networks

### A.2. 神经网络

Although neural networks exist in many forms, we only introduce those relevant to works discussed in Section 3.

尽管神经网络有多种形式，但我们仅介绍与第 3 节讨论的工作相关的那些。

CNNs (Convolution Neural Networks, Fig. 19) (LeCun, Bottou, Bengio, & Haffner, 1998) have a set of convolutional layers that extracts features from the input (The input usually is the image). Next, one or more fully-connected layers are applied to extract the classification or regression information with the help of logistic or linear regression. Usually, the final layer of a CNN is a "softmax" layer, where the sum of all activations is one.

卷积神经网络(Convolution Neural Networks，简称CNNs，图19)(LeCun、Bottou、Bengio和Haffner，1998年)具有一组卷积层，用于从输入中提取特征(输入通常是图像)。接下来，应用一个或多个全连接层，借助逻辑回归或线性回归来提取分类或回归信息。通常，CNN的最后一层是“softmax”层，其中所有激活值的总和为1。

GNNs (Graph Neural Networks, Fig. 20) (Wu et al., 2020) with multiple graph convolutional layers that can attain each node's hidden representation by aggregating feature information from its neighbors. The graph structure and node feature information as inputs and the outputs of GNNs can focus on different graph analysis tasks, such as node classification and graph classification. Therefore, GNNs have different variants, such as GCN, GAE, etc.

图神经网络(Graph Neural Networks，简称GNNs，图20)(Wu等人，2020年)具有多个图卷积层，可通过聚合节点邻居的特征信息来获得每个节点的隐藏表示。图结构和节点特征信息作为输入，GNN的输出可用于不同的图分析任务，如节点分类和图分类。因此，GNN有不同的变体，如GCN、GAE等。

RNNs (Recursive Neural Networks, Fig. 21) (Hoffmann, Navarro, Kastner, Janßen, & Hubner, 2017) are neural networks in which the input and output layers are identical, and the latter propagates activation back to the former through recurrent connections. Over time, with each time step consisting of a full input-to-output forward pass, the hidden layer transitions through a series of states. Usually, the input is sequence data such as sentences in natural language processing. LSTM (Long Short-Term Memory Networks) is a variable of RNN.

递归神经网络(Recursive Neural Networks，简称RNNs，图21)(Hoffmann、Navarro、Kastner、Janßen和Hubner，2017年)是一种输入层和输出层相同的神经网络，输出层通过循环连接将激活值反馈回输入层。随着时间的推移，每个时间步都包含一个完整的从输入到输出的前向传播过程，隐藏层会经历一系列状态转换。通常，输入是自然语言处理中的句子等序列数据。长短期记忆网络(Long Short-Term Memory Networks，简称LSTM)是RNN的一种变体。

![0195ea36-14ee-7c5c-a9a7-c1c11f9ac59f_18_366_158_1016_648_0.jpg](images/0195ea36-14ee-7c5c-a9a7-c1c11f9ac59f_18_366_158_1016_648_0.jpg)

Fig. 17. Ground Markov logic network. Nodes are variables and edges are the relationship between variables.

图17. 基础马尔可夫逻辑网络。节点是变量，边是变量之间的关系。

![0195ea36-14ee-7c5c-a9a7-c1c11f9ac59f_18_312_902_1129_488_0.jpg](images/0195ea36-14ee-7c5c-a9a7-c1c11f9ac59f_18_312_902_1129_488_0.jpg)

Fig. 18. An example of a knowledge graph.

图18. 知识图谱示例。

![0195ea36-14ee-7c5c-a9a7-c1c11f9ac59f_18_408_1469_928_321_0.jpg](images/0195ea36-14ee-7c5c-a9a7-c1c11f9ac59f_18_408_1469_928_321_0.jpg)

Fig. 19. Diagram of a CNN.

图19. CNN示意图。

![0195ea36-14ee-7c5c-a9a7-c1c11f9ac59f_18_394_1863_963_275_0.jpg](images/0195ea36-14ee-7c5c-a9a7-c1c11f9ac59f_18_394_1863_963_275_0.jpg)

Fig. 20. GNN, which feeds graph structure and node feature into graph convolutional layers.

图20. GNN，将图结构和节点特征输入到图卷积层。

![0195ea36-14ee-7c5c-a9a7-c1c11f9ac59f_19_162_152_627_289_0.jpg](images/0195ea36-14ee-7c5c-a9a7-c1c11f9ac59f_19_162_152_627_289_0.jpg)

Fig. 21. RNN, which feeds its output back into its input. Here, dashed lines represent recurrent connections.

图21. RNN，将其输出反馈回输入。这里，虚线表示循环连接。

## References

## 参考文献

Abboud, R., Ceylan, I., & Lukasiewicz, T. (2020). Learning to reason: Leveraging neural networks for approximate dnf counting. In AAAI, vol. 34 no. 04 (pp. 3097-3104).

Abboud, R.、Ceylan, I.和Lukasiewicz, T.(2020年)。学习推理:利用神经网络进行近似析取范式计数。发表于《AAAI》，第34卷，第4期(第3097 - 3104页)。

Aliseda, A. (2006). Abductive reasoning: Logical investigations into discovery and explanation.

Aliseda, A.(2006年)。溯因推理:对发现和解释的逻辑研究。

Altszyler, E., Brusco, P., Basiou, N., Byrnes, J., & Vergyri, D. (2021). Zero-shot multi-domain dialog state tracking using descriptive rules. In IJCLR.

Altszyler, E.、Brusco, P.、Basiou, N.、Byrnes, J.和Vergyri, D.(2021年)。使用描述性规则的零样本多领域对话状态跟踪。发表于《IJCLR》。

Andreas, J., Rohrbach, M., Darrell, T., & Klein, D. (2016). Neural module networks. In ${CVPR}$ (pp. 39-48).

Andreas, J.、Rohrbach, M.、Darrell, T.和Klein, D.(2016年)。神经模块网络。发表于${CVPR}$(第39 - 48页)。

Andrews, R., Diederich, J., & Tickle, A. B. (1995). Survey and critique of techniques for extracting rules from trained artificial neural networks. In KBS, vol. 8 no. 6 (pp. 373-389).

Andrews, R.、Diederich, J.和Tickle, A. B.(1995年)。从训练好的人工神经网络中提取规则的技术综述与批判。发表于《KBS》，第8卷，第6期(第373 - 389页)。

Bach, S. H., Broecheler, M., Huang, B., & Getoor, L. (2015). Hinge-loss markov random fields and probabilistic soft logic. ArXiv Preprint arXiv:1505.04406.

Bach, S. H.、Broecheler, M.、Huang, B.和Getoor, L.(2015年)。铰链损失马尔可夫随机场与概率软逻辑。预印本arXiv:1505.04406。

Barto, A. G., & Mahadevan, S. (2003). Recent advances in hierarchical reinforcement learning. In DEDS, vol. 13 no. 1 (pp. 41-77).

Barto, A. G.和Mahadevan, S.(2003年)。分层强化学习的最新进展。发表于《DEDS》，第13卷，第1期(第41 - 77页)。

Besold, T. R., Garcez, A. d., Bader, S., Bowman, H., Domingos, P., Hitzler, P., et al. (2017). Neural-symbolic learning and reasoning: A survey and interpretation. ArXiv Preprint arXiv:1711.03902.

贝索尔德(Besold)，T. R.，加尔塞斯(Garcez)，A. d.，巴德(Bader)，S.，鲍曼(Bowman)，H.，多明戈斯(Domingos)，P.，希茨勒(Hitzler)，P.等(2017年)。神经符号学习与推理:一项综述与解读。预印本论文，arXiv:1711.03902。

Bordes, A., Usunier, N., Garcia-Duran, A., Weston, J., & Yakhnenko, O. (2013). Translating embeddings for modeling multi-relational data. In NIPS, vol. 26.

博尔德斯(Bordes)，A.，于苏尼尔(Usunier)，N.，加西亚 - 杜兰(Garcia - Duran)，A.，韦斯顿(Weston)，J.和亚赫年科(Yakhnenko)，O.(2013年)。用于多关系数据建模的翻译嵌入。收录于《神经信息处理系统大会论文集》(NIPS)，第26卷。

Bosselut, A., Rashkin, H., Sap, M., Malaviya, C., Celikyilmaz, A., & Choi, Y. (2019). COMET: Commonsense transformers for automatic knowledge graph construction. In ${ACL}$ .

博塞卢特(Bosselut)，A.，拉什金(Rashkin)，H.，萨普(Sap)，M.，马拉维亚(Malaviya)，C.，瑟利基尔马兹(Celikyilmaz)，A.和崔(Choi)，Y.(2019年)。COMET:用于自动知识图谱构建的常识变换器。收录于 ${ACL}$ 。

Cai, L.-W., Dai, W.-Z., Huang, Y.-X., Li, Y.-F., Muggleton, S., & Jiang, Y. (2021). Abductive learning with ground knowledge base. In IJCAI.

蔡(Cai)，L. - W.，戴(Dai)，W. - Z.，黄(Huang)，Y. - X.，李(Li)，Y. - F.，马格利顿(Muggleton)，S.和江(Jiang)，Y.(2021年)。基于基础知识库的溯因学习。收录于《国际人工智能联合会议论文集》(IJCAI)。

Calegari, R., Ciatto, G., & Omicini, A. (2020). On the integration of symbolic and sub-symbolic techniques for XAI: A survey. In IA, vol. 14 no. 1 (pp. 7-32).

卡莱加里(Calegari)，R.，恰托(Ciatto)，G.和奥米西尼(Omicini)，A.(2020年)。关于可解释人工智能(XAI)中符号与亚符号技术的集成:一项综述。收录于《人工智能》(IA)，第14卷，第1期(第7 - 32页)。

Campero, A., Pareja, A., Klinger, T., Tenenbaum, J., & Riedel, S. (2018). Logical rule induction and theory learning using neural theorem proving. In NIPS.

坎佩罗(Campero)，A.，帕雷哈(Pareja)，A.，克林格(Klinger)，T.，特南鲍姆(Tenenbaum)，J.和里德尔(Riedel)，S.(2018年)。使用神经定理证明进行逻辑规则归纳和理论学习。收录于《神经信息处理系统大会论文集》(NIPS)。

Chen, R., Chen, T., Hui, X., Wu, H., Li, G., & Lin, L. (2020). Knowledge graph transfer network for few-shot recognition. In AAAI, vol. 34 no. 07 (pp. 10575-10582).

陈(Chen)，R.，陈(Chen)，T.，惠(Hui)，X.，吴(Wu)，H.，李(Li)，G.和林(Lin)，L.(2020年)。用于少样本识别的知识图谱迁移网络。收录于《美国人工智能协会会议论文集》(AAAI)，第34卷，第07期(第10575 - 10582页)。

Chen, T., Chen, R., Nie, L., Luo, X., Liu, X., & Lin, L. (2018). Neural task planning with and-or graph representations. IEEE Transactions on Multimedia, 21(4), 1022-1034.

陈(Chen)，T.，陈(Chen)，R.，聂(Nie)，L.，罗(Luo)，X.，刘(Liu)，X.和林(Lin)，L.(2018年)。基于与或图表示的神经任务规划。《电气与电子工程师协会多媒体汇刊》(IEEE Transactions on Multimedia)，21(4)，1022 - 1034。

Conti, C. J., Varde, A. S., & Wang, W. (2020). Robot action planning by commonsense knowledge in human-robot collaborative tasks. In IEMTRONICS (pp. 1-7).

孔蒂(Conti)，C. J.，瓦尔代(Varde)，A. S.和王(Wang)，W.(2020年)。人机协作任务中基于常识知识的机器人动作规划。收录于《工业电子与技术国际会议论文集》(IEMTRONICS)(第1 - 7页)。

Darwiche, A. (2001). On the tractable counting of theory models and its application to truth maintenance and belief revision. In JANCL, vol. 11 no. 1-2 (pp. 11-34).

达维切(Darwiche)，A.(2001年)。关于理论模型的可处理计数及其在真值维护和信念修正中的应用。收录于《应用非经典逻辑杂志》(JANCL)，第11卷，第1 - 2期(第11 - 34页)。

Darwiche, A. (2011). SDD: A new canonical representation of propositional knowledge bases. In ${AI}$ .

达维切(Darwiche)，A.(2011年)。SDD:命题知识库的一种新规范表示。收录于 ${AI}$ 。

Darwiche, A., & Marquis, P. (2002). A knowledge compilation map. In JAIR, vol. 17 (pp. 229-264).

达维切(Darwiche)，A.和马奎斯(Marquis)，P.(2002年)。知识编译图谱。收录于《人工智能研究杂志》(JAIR)，第17卷(第229 - 264页)。

Das, R., Dhuliawala, S., Zaheer, M., Vilnis, L., Durugkar, I., Krishnaurthy, A., et al. (2017). Go for a walk and arrive at the answer: Reasoning over knowledge bases with reinforcement learning. In NIPS.

达斯(Das)，R.，杜利亚瓦拉(Dhuliawala)，S.，扎希尔(Zaheer)，M.，维尔尼斯(Vilnis)，L.，杜鲁格卡尔(Durugkar)，I.，克里希纳乌蒂(Krishnaurthy)，A.等(2017年)。边走边找答案:基于强化学习的知识库推理。收录于《神经信息处理系统大会论文集》(NIPS)。

Das, R., Neelakantan, A., Belanger, D., & McCallum, A. (2016). Chains of reasoning over entities, relations, and text using recurrent neural networks. In ACL.

达斯(Das)，R.，尼尔卡坦(Neelakantan)，A.，贝朗热(Belanger)，D.和麦卡勒姆(McCallum)，A.(2016年)。使用循环神经网络进行实体、关系和文本的推理链。收录于《计算语言学协会年会论文集》(ACL)。

Davis, E. (2017). Logical formalizations of commonsense reasoning: a survey. In JAIR, vol. 59 (pp. 651-723).

戴维斯(Davis)，E.(2017年)。常识推理的逻辑形式化:一项综述。收录于《人工智能研究杂志》(JAIR)，第59卷(第651 - 723页)。

De Raedt, L., Kimmig, A., & Toivonen, H. (2007). ProbLog: A probabilistic prolog and its application in link discovery.. In IJCAI, vol. 7 (pp. 2462-2467).

德·雷德特(De Raedt)，L.，基米希(Kimmig)，A.和托伊沃宁(Toivonen)，H.(2007年)。ProbLog:一种概率Prolog及其在链接发现中的应用。收录于《国际人工智能联合会议论文集》(IJCAI)，第7卷(第2462 - 2467页)。

Dettmers, T., Minervini, P., Stenetorp, P., & Riedel, S. (2018). Convolutional 2d knowledge graph embeddings. In AAAI.

德特默斯(Dettmers)，T.，米内尔维尼(Minervini)，P.，斯特内托普(Stenetorp)，P.，& 里德尔(Riedel)，S.(2018)。卷积二维知识图谱嵌入。收录于美国人工智能协会会议(AAAI)。

Diligenti, M., Gori, M., & Sacca, C. (2017). Semantic-based regularization for learning and inference. In AI, vol. 244 (pp. 143-165).

迪利根蒂(Diligenti)，M.，戈里(Gori)，M.，& 萨卡(Sacca)，C.(2017)。基于语义的学习与推理正则化。收录于《人工智能》(AI)，第244卷(第143 - 165页)。

Dollár, K. H. G. G. P., & Girshick, R. (2017). Mask r-cnn. In ICCV (pp. 2961-2969).

多尔(Dollár)，K. H. G. G. P.，& 吉尔希克(Girshick)，R.(2017)。掩码区域卷积神经网络(Mask R - CNN)。收录于国际计算机视觉大会(ICCV)(第2961 - 2969页)。

Domingos, P., & Lowd, D. (2019). Unifying logical and statistical AI with Markov logic. Commun. ACM, 62(7), 74-83.

多明戈斯(Domingos)，P.，& 洛德(Lowd)，D.(2019)。用马尔可夫逻辑统一逻辑人工智能和统计人工智能。《美国计算机协会通讯》(Commun. ACM)，62(7)，74 - 83。

Donadello, I., Serafini, L., & Garcez, A. D. (2017). Logic tensor networks for semantic image interpretation. In IJCAI.

多纳代洛(Donadello)，I.，塞拉菲尼(Serafini)，L.，& 加尔塞斯(Garcez)，A. D.(2017)。用于语义图像解释的逻辑张量网络。收录于国际人工智能联合会议(IJCAI)。

Dong, H., Mao, J., Lin, T., Wang, C., Li, L., & Zhou, D. (2019). Neural logic machines. In ${ICLR}$ .

董(Dong)，H.，毛(Mao)，J.，林(Lin)，T.，王(Wang)，C.，李(Li)，L.，& 周(Zhou)，D.(2019)。神经逻辑机。收录于 ${ICLR}$ 。

Dos Martires, P. Z., Derkinderen, V., Manhaeve, R., Meert, W., Kimmig, A., & De Raedt, L. (2019). Transforming probabilistic programs into algebraic circuits for inference and learning. In NIPS.

多斯·马丁雷斯(Dos Martires)，P. Z.，德金德伦(Derkinderen)，V.，曼哈埃夫(Manhaeve)，R.，梅尔特(Meert)，W.，基米希(Kimmig)，A.，& 德·雷德特(De Raedt)，L.(2019)。将概率程序转换为代数电路以进行推理和学习。收录于神经信息处理系统大会(NIPS)。

Dragone, P., Teso, S., & Passerini, A. (2021). Neuro-symbolic constraint programming for structured prediction. ArXiv Preprint arXiv:2103.17232.

德拉戈内(Dragone)，P.，特索(Teso)，S.，& 帕塞里尼(Passerini)，A.(2021)。用于结构化预测的神经符号约束规划。预印本论文(ArXiv Preprint)arXiv:2103.17232。

Eisner, J. (2002). Parameter estimation for probabilistic finite-state transducers. In ${ACL}$ (pp. 1-8).

艾斯纳(Eisner)，J.(2002)。概率有限状态转换器的参数估计。收录于 ${ACL}$ (第1 - 8页)。

Ellis, K. M., Morales, L. E., Sablé-Meyer, M., Solar Lezama, A., & Tenenbaum, J. B. (2018). Library learning for neurally-guided bayesian program induction. In NIPS.

埃利斯(Ellis)，K. M.，莫拉莱斯(Morales)，L. E.，萨布莱 - 迈耶(Sablé - Meyer)，M.，索拉尔·莱萨马(Solar Lezama)，A.，& 特南鲍姆(Tenenbaum)，J. B.(2018)。用于神经引导的贝叶斯程序归纳的库学习。收录于神经信息处理系统大会(NIPS)。

Enderton, H. B. (2001). A mathematical introduction to logic.

恩德尔顿(Enderton)，H. B.(2001)。《数理逻辑引论》。

Evans, R., & Grefenstette, E. (2018). Learning explanatory rules from noisy data. 61, In JAIR (pp. 1-64).

埃文斯(Evans)，R.，& 格雷芬施泰特(Grefenstette)，E.(2018)。从噪声数据中学习解释性规则。收录于《人工智能研究杂志》(JAIR)第61卷(第1 - 64页)。

Forestier, G., Wemmert, C., & Puissant, A. (2013). Coastal image interpretation using background knowledge and semantics. Computer Geoscience, 54, 88-96.

福雷斯捷(Forestier)，G.，韦默特(Wemmert)，C.，& 皮桑(Puissant)，A.(2013)。利用背景知识和语义进行海岸图像解释。《计算机地球科学》(Computer Geoscience)，54，88 - 96。

Galárraga, L., Teflioudi, C., Hose, K., & Suchanek, F. M. (2015). Fast rule mining in ontological knowledge bases with AMIE $+  +$ . In VLDB, vol. 24 no. 6 (pp. 707-730).

加拉拉加(Galárraga)，L.，泰夫柳迪(Teflioudi)，C.，霍斯(Hose)，K.，& 苏查内克(Suchanek)，F. M.(2015)。使用AMIE $+  +$ 在本体知识库中进行快速规则挖掘。收录于国际超大型数据库会议(VLDB)，第24卷第6期(第707 - 730页)。

Garcez, A. d., Besold, T. R., De Raedt, L., Földiak, P., Hitzler, P., Icard, T., et al. (2015). Neural-symbolic learning and reasoning: contributions and challenges. In AAAI.

加尔塞斯(Garcez)，A. d.，贝索尔德(Besold)，T. R.，德·雷德特(De Raedt)，L.，福尔迪亚克(Földiak)，P.，希茨勒(Hitzler)，P.，伊卡德(Icard)，T.等(2015)。神经符号学习与推理:贡献与挑战。收录于美国人工智能协会会议(AAAI)。

Garcez, A. S. d., Broda, K. B., & Gabbay, D. M. (2012). Neural-symbolic learning systems: foundations and applications.

加尔塞斯(Garcez)，A. S. d.，布罗达(Broda)，K. B.，& 加贝(Gabbay)，D. M.(2012)。《神经符号学习系统:基础与应用》。

Garcez, A. S. d., Broda, K., Gabbay, D. M., et al. (2002). Neural-symbolic learning systems: foundations and applications.

加尔塞斯(Garcez)，A. S. d.，布罗达(Broda)，K.，加贝(Gabbay)，D. M.等(2002年)。神经符号学习系统:基础与应用。

Garcez, A. d., Dutra, A. R. R., & Alonso, E. (2018). Towards symbolic reinforcement learning with common sense. ArXiv Preprint arXiv:1804.08597.

加尔塞斯(Garcez)，A. d.，杜特拉(Dutra)，A. R. R.，& 阿隆索(Alonso)，E.(2018年)。迈向具有常识的符号强化学习。预印本arXiv:1804.08597。

Garcez, A. d., Gori, M., Lamb, L. C., Serafini, L., Spranger, M., & Tran, S. N. (2019). Neural-symbolic computing: An effective methodology for principled integration of machine learning and reasoning. ArXiv Preprint arXiv:1905. 06088.

加尔塞斯(Garcez)，A. d.，戈里(Gori)，M.，兰姆(Lamb)，L. C.，塞拉菲尼(Serafini)，L.，斯普朗格(Spranger)，M.，& 陈(Tran)，S. N.(2019年)。神经符号计算:机器学习与推理原则性集成的有效方法。预印本arXiv:1905. 06088。

Garcez, A. d., & Lamb, L. C. (2020). Neurosymbolic AI: the 3rd wave. ArXiv Preprint arXiv:2012.05876.

加尔塞斯(Garcez)，A. d.，& 兰姆(Lamb)，L. C.(2020年)。神经符号人工智能:第三波浪潮。预印本arXiv:2012.05876。

Garcez, A. S. A., & Zaverucha, G. (1999). The connectionist inductive learning and logic programming system. In APIN, vol. 11 no. 1 (pp. 59-77).

加尔塞斯(Garcez)，A. S. A.，& 扎韦鲁查(Zaverucha)，G.(1999年)。连接主义归纳学习与逻辑编程系统。载于《亚太信息网络》(APIN)，第11卷第1期(第59 - 77页)。

Gardner, M., & Mitchell, T. (2015). Efficient and expressive knowledge base completion using subgraph feature extraction. In EMNLP (pp. 1488-1498).

加德纳(Gardner)，M.，& 米切尔(Mitchell)，T.(2015年)。利用子图特征提取实现高效且富有表现力的知识库补全。载于《自然语言处理经验方法会议》(EMNLP)(第1488 - 1498页)。

Garnelo, M., Arulkumaran, K., & Shanahan, M. (2016). Towards deep symbolic reinforcement learning. In NIPS.

加内洛(Garnelo)，M.，阿鲁库马兰(Arulkumaran)，K.，& 沙纳汉(Shanahan)，M.(2016年)。迈向深度符号强化学习。载于《神经信息处理系统大会》(NIPS)。

Gupta, N., Lin, K., Roth, D., Singh, S., & Gardner, M. (2020). Neural module networks for reasoning over text. In ICLR.

古普塔(Gupta)，N.，林(Lin)，K.，罗斯(Roth)，D.，辛格(Singh)，S.，& 加德纳(Gardner)，M.(2020年)。用于文本推理的神经模块网络。载于《国际学习表征会议》(ICLR)。

Gupta, V., Patro, B. N., Parihar, H., & Namboodiri, V. P. (2022). VQuAD: Video question answering diagnostic dataset. In WACVW (pp. 282-291).

古普塔(Gupta)，V.，帕德罗(Patro)，B. N.，帕里哈尔(Parihar)，H.，& 南布迪里(Namboodiri)，V. P.(2022年)。VQuAD:视频问答诊断数据集。载于《计算机视觉冬季研讨会》(WACVW)(第282 - 291页)。

Hoffmann, J., Navarro, O., Kastner, F., Janßen, B., & Hubner, M. (2017). A survey on CNN and RNN implementations. In PESARO, no. 3.

霍夫曼(Hoffmann)，J.，纳瓦罗(Navarro)，O.，卡斯特纳(Kastner)，F.，扬森(Janßen)，B.，& 胡布纳(Hubner)，M.(2017年)。卷积神经网络(CNN)和循环神经网络(RNN)实现综述。载于《佩萨罗会议论文集》(PESARO)，第3期。

Honavar, V. (1995). Symbolic artificial intelligence and numeric artificial neural networks: towards a resolution of the dichotomy. Computational Architectures Integrating Neural and Symbolic Processes: A Perspective on the State of the Art, 351-388.

霍纳瓦尔(Honavar)，V.(1995年)。符号人工智能与数值人工神经网络:解决二分法问题。《集成神经与符号过程的计算架构:技术现状透视》，第351 - 388页。

Hu, Z., Ma, X., Liu, Z., Hovy, E., & Xing, E. (2016). Harnessing deep neural networks with logic rules. In ${ACL}$ .

胡(Hu)，Z.，马(Ma)，X.，刘(Liu)，Z.，霍维(Hovy)，E.，& 邢(Xing)，E.(2016年)。利用逻辑规则驾驭深度神经网络。载于 ${ACL}$ 。

Hudson, D. A., & Manning, C. D. (2018). Compositional attention networks for machine reasoning. In ICLR.

哈德森(Hudson)，D. A.，& 曼宁(Manning)，C. D.(2018年)。用于机器推理的组合注意力网络。载于《国际学习表征会议》(ICLR)。

Hudson, D. A., & Manning, C. D. (2019). Learning by abstraction: The neural state machine. In NIPS.

哈德森(Hudson)，D. A.，& 曼宁(Manning)，C. D.(2019年)。通过抽象学习:神经状态机。载于《神经信息处理系统大会》(NIPS)。

Ji, J., Zhu, F., Cui, J., Zhao, H., & Yang, B. (2022). A dual-system method for intelligent fault localization in communication networks. In ICC 2022-IEEE International Conference on Communications (pp. 4062-4067).

季(Ji)，J.，朱(Zhu)，F.，崔(Cui)，J.，赵(Zhao)，H.，& 杨(Yang)，B.(2022年)。通信网络智能故障定位的双系统方法。载于《2022年IEEE国际通信会议》(ICC 2022)(第4062 - 4067页)。

Jiang, X., Wang, Q., & Wang, B. (2019). Adaptive convolution for multi-relational learning. In NAACL HLT (pp. 978-987).

江(Jiang)，X.，王(Wang)，Q.，& 王(Wang)，B.(2019年)。用于多关系学习的自适应卷积。载于《北美计算语言学协会人类语言技术会议》(NAACL HLT)(第978 - 987页)。

Kahneman, D. (2011). Thinking, fast and slow.

卡尼曼，D.(2011)。《思考，快与慢》。

Kalyan, A., Mohta, A., Polozov, O., Batra, D., Jain, P., & Gulwani, S. (2018). Neural-guided deductive search for real-time program synthesis from examples. In ${ICLR}$ .

卡利安，A.，莫塔，A.，波洛佐夫，O.，巴特拉，D.，贾因，P.，&古尔瓦尼，S.(2018)。用于从示例进行实时程序合成的神经引导演绎搜索。见 ${ICLR}$ 。

Kampffmeyer, M., Chen, Y., Liang, X., Wang, H., Zhang, Y., & Xing, E. P. (2019). Rethinking knowledge graph propagation for zero-shot learning. In CVPR (pp. 11487-11496).

坎普夫迈尔，M.，陈，Y.，梁，X.，王，H.，张，Y.，&邢，E. P.(2019)。重新思考零样本学习中的知识图谱传播。见计算机视觉与模式识别会议(CVPR)(第11487 - 11496页)。

Karpas, E., Abend, O., Belinkov, Y., Lenz, B., Lieber, O., Ratner, N., et al. (2022). MRKL systems: A modular, neuro-symbolic architecture that combines large language models, external knowledge sources and discrete reasoning. ArXiv Preprint arXiv:2205.00445.

卡尔帕斯，E.，阿本德，O.，贝林科夫，Y.，伦茨，B.，利伯，O.，拉特纳，N.等(2022)。MRKL系统:一种结合大语言模型、外部知识源和离散推理的模块化神经符号架构。预印本 arXiv:2205.00445。

Kaur, N., Kunapuli, G., Khot, T., Kersting, K., Cohen, W., & Natarajan, S. (2017). Relational restricted boltzmann machines: A probabilistic logic learning approach. In IJCLR (pp. 94-111).

考尔，N.，库纳普利，G.，霍特，T.，克尔斯廷，K.，科恩，W.，&纳塔拉詹，S.(2017)。关系受限玻尔兹曼机:一种概率逻辑学习方法。见国际学习表征会议(IJCLR)(第94 - 111页)。

Kautz, H. (2022). The third AI summer: AAAI Robert S. Engelmore memorial lecture. AI Magazine, 43(1), 105-125.

考茨，H.(2022)。第三个人工智能之夏:美国人工智能协会(AAAI)罗伯特·S·恩格尔莫尔纪念讲座。《人工智能杂志》，43(1)，105 - 125。

Khot, T., Natarajan, S., Kersting, K., & Shavlik, J. (2011). Learning markov logic networks via functional gradient boosting. In ICDMW (pp. 320-329).

霍特，T.，纳塔拉詹，S.，克尔斯廷，K.，&沙夫利克，J.(2011)。通过函数梯度提升学习马尔可夫逻辑网络。见国际数据挖掘研讨会(ICDMW)(第320 - 329页)。

Kipf, T. N., & Welling, M. (2017). Semi-supervised classification with graph convolutional networks. In ICLR.

基普夫，T. N.，&韦林，M.(2017)。图卷积网络的半监督分类。见国际学习表征会议(ICLR)。

Koller, D., Friedman, N., Džeroski, S., Sutton, C., McCallum, A., Pfeffer, A., et al. (2007). Introduction to statistical relational learning.

科勒，D.，弗里德曼，N.，杰罗斯基，S.，萨顿，C.，麦卡勒姆，A.，费弗，A.等(2007)。《统计关系学习导论》。

Lamb, L. C., Garcez, A., Gori, M., Prates, M., Avelar, P., & Vardi, M. (2020). Graph neural networks meet neural-symbolic computing: A survey and perspective. In ${AAAI}$ .

兰姆，L. C.，加尔塞斯，A.，戈里，M.，普拉特斯，M.，阿韦拉尔，P.，&瓦尔迪，M.(2020)。图神经网络与神经符号计算的结合:综述与展望。见 ${AAAI}$ 。

Landajuela, M., Petersen, B. K., Kim, S., Santiago, C. P., Glatt, R., Mundhenk, N., et al. (2021). Discovering symbolic policies with deep reinforcement learning. In ICML (pp. 5979-5989).

兰达胡埃拉，M.，彼得森，B. K.，金，S.，圣地亚哥，C. P.，格拉特，R.，蒙德亨克，N.等(2021)。用深度强化学习发现符号策略。见国际机器学习会议(ICML)(第5979 - 5989页)。

Lavrac, N., & Dzeroski, S. (1994). Inductive logic programming. In WLP (pp. 146-160).

拉夫拉克，N.，&杰罗斯基，S.(1994)。归纳逻辑编程。见逻辑程序设计研讨会(WLP)(第146 - 160页)。

LeCun, Y., Bottou, L., Bengio, Y., & Haffner, P. (1998). Gradient-based learning applied to document recognition. Proceedings of the IEEE, 86(11), 2278-2324.

勒昆，Y.，博图，L.，本吉奥，Y.，&哈夫纳，P.(1998)。基于梯度的学习在文档识别中的应用。《电气与电子工程师协会汇刊》，86(11)，2278 - 2324。

Levine, Y., Dalmedigos, I., Ram, O., Zeldes, Y., Jannai, D., Muhlgay, D., et al. (2022). Standing on the shoulders of giant frozen language models. ArXiv Preprint arXiv:2204.10019.

莱文，Y.，达尔梅迪戈斯，I.，拉姆，O.，泽尔代斯，Y.，扬奈，D.，米尔盖，D.等(2022)。站在巨型冻结语言模型的肩膀上。预印本 arXiv:2204.10019。

Li, A., Luo, T., Lu, Z., Xiang, T., & Wang, L. (2019). Large-scale few-shot learning: Knowledge transfer with class hierarchy. In CVPR (pp. 7212-7220).

李，A.，罗，T.，陆，Z.，向，T.，&王，L.(2019)。大规模少样本学习:基于类层次结构的知识迁移。见计算机视觉与模式识别会议(CVPR)(第7212 - 7220页)。

Li, Y., Tarlow, D., Brockschmidt, M., & Zemel, R. (2016). Gated graph sequence neural networks. In ICLR.

李，Y.，塔尔洛，D.，布罗克施密特，M.，&泽梅尔，R.(2016)。门控图序列神经网络。见国际学习表征会议(ICLR)。

Liang, C., Berant, J., Le, Q., Forbus, K. D., & Lao, N. (2017). Neural symbolic machines: Learning semantic parsers on freebase with weak supervision. In ${ACL}$ .

梁(Liang)，C.，贝兰特(Berant)，J.，乐(Le)，Q.，福尔布斯(Forbus)，K. D.，& 劳(Lao)，N.(2017)。神经符号机器:在弱监督下在Freebase上学习语义解析器。见 ${ACL}$。

Lin, Y., Liu, Z., Sun, M., Liu, Y., & Zhu, X. (2015). Learning entity and relation embeddings for knowledge graph completion. In AAAI.

林(Lin)，Y.，刘(Liu)，Z.，孙(Sun)，M.，刘(Liu)，Y.，& 朱(Zhu)，X.(2015)。学习用于知识图谱补全的实体和关系嵌入。见美国人工智能协会会议(AAAI)。

Liu, Z., Jiang, Z., & Wei, F. (2019). OD-GCN object detection by knowledge graph with GCN. ArXiv Preprint arXiv:1908.04385.

刘(Liu)，Z.，江(Jiang)，Z.，& 魏(Wei)，F.(2019)。基于图卷积网络(GCN)的知识图谱目标检测(OD - GCN)。预印本 arXiv:1908.04385。

LiuQiao, L., DuanHong, L., et al. (2016). Knowledge graph construction techniques. Computer Research and Development, 53(3), 582.

刘乔(LiuQiao)，L.，段宏(DuanHong)，L.等(2016)。知识图谱构建技术。计算机研究与发展，53(3)，582。

Luan, Y., He, L., Ostendorf, M., & Hajishirzi, H. (2018). Multi-task identification of entities, relations, and coreference for scientific knowledge graph construction. In EMNLP.

栾(Luan)，Y.，何(He)，L.，奥斯坦多夫(Ostendorf)，M.，& 哈吉希尔齐(Hajishirzi)，H.(2018)。用于科学知识图谱构建的实体、关系和共指多任务识别。见自然语言处理经验方法会议(EMNLP)。

Luo, R., Zhang, N., Han, B., & Yang, L. (2020). Context-aware zero-shot recognition. In AAAI, vol. 34 no. 07 (pp. 11709-11716).

罗(Luo)，R.，张(Zhang)，N.，韩(Han)，B.，& 杨(Yang)，L.(2020)。上下文感知的零样本识别。见美国人工智能协会会议(AAAI)，第34卷，第07期(第11709 - 11716页)。

Lyu, D., Yang, F., Liu, B., & Gustafson, S. (2019). SDRL: interpretable and data-efficient deep reinforcement learning leveraging symbolic planning. In AAAI, vol. 33 no. 01 (pp. 2970-2977).

吕(Lyu)，D.，杨(Yang)，F.，刘(Liu)，B.，& 古斯塔夫森(Gustafson)，S.(2019)。SDRL:利用符号规划的可解释且数据高效的深度强化学习。见美国人工智能协会会议(AAAI)，第33卷，第01期(第2970 - 2977页)。

Manhaeve, R., De Raedt, L., Kimmig, A., Dumancic, S., & Demeester, T. (2019). DeepProbLog: Integrating logic and learning through algebraic model counting. In NIPS.

曼哈埃夫(Manhaeve)，R.；雷德特(De Raedt)，L.；基米希(Kimmig)，A.；杜曼契奇(Dumancic)，S.；德梅斯特(Demeester)，T.(2019)。深度概率逻辑编程(DeepProbLog):通过代数模型计数集成逻辑与学习。发表于神经信息处理系统大会(NIPS)。

Manhaeve, R., Dumančić, S., Kimmig, A., Demeester, T., & De Raedt, L. (2018). Deepproblog: Neural probabilistic logic programming. In NeurIPS.

曼哈埃夫(Manhaeve)，R.；杜曼契奇(Dumančić)，S.；基米希(Kimmig)，A.；德梅斯特(Demeester)，T.；雷德特(De Raedt)，L.(2018)。深度概率逻辑编程(Deepproblog):神经概率逻辑编程。发表于神经信息处理系统大会(NeurIPS)。

Mao, J., Gan, C., Kohli, P., Tenenbaum, J. B., & Wu, J. (2019). The neuro-symbolic concept learner: Interpreting scenes, words, and sentences from natural supervision. ArXiv Preprint arXiv:1904.12584.

毛(Mao)，J.；甘(Gan)，C.；科利(Kohli)，P.；特南鲍姆(Tenenbaum)，J. B.；吴(Wu)，J.(2019)。神经符号概念学习器:从自然监督中解释场景、单词和句子。预印本论文，arXiv:1904.12584。

Marcus, G. (2020). The next decade in AI: four steps towards robust artificial intelligence. arXiv preprint arXiv:2002.06177.

马库斯(Marcus)，G.(2020)。人工智能的下一个十年:迈向鲁棒人工智能的四个步骤。预印本论文，arXiv:2002.06177。

Marra, G., Diligenti, M., Giannini, F., Gori, M., & Maggini, M. (2020). Relational neural machines.

马拉(Marra)，G.；迪利根蒂(Diligenti)，M.；詹尼尼(Giannini)，F.；戈里(Gori)，M.；马吉尼(Maggini)，M.(2020)。关系神经网络机器。

Marra, G., Dumančić, S., Manhaeve, R., & De Raedt, L. (2020). From statistical relational to neural symbolic artificial intelligence: a survey. In IJCAI.

马拉(Marra)，G.；杜曼契奇(Dumančić)，S.；曼哈埃夫(Manhaeve)，R.；雷德特(De Raedt)，L.(2020)。从统计关系人工智能到神经符号人工智能:综述。发表于国际人工智能联合会议(IJCAI)。

Marra, G., Giannini, F., Diligenti, M., & Gori, M. (2019). Integrating learning and reasoning with deep logic models. In ECML PKDD.

马拉(Marra)，G.；詹尼尼(Giannini)，F.；迪利根蒂(Diligenti)，M.；戈里(Gori)，M.(2019)。通过深度逻辑模型集成学习与推理。发表于欧洲机器学习和知识发现原理与实践会议(ECML PKDD)。

Marra, G., & Kuželka, O. (2021). Neural markov logic networks. In UAI.

马拉(Marra)，G.；库泽尔卡(Kuželka)，O.(2021)。神经马尔可夫逻辑网络。发表于人工智能不确定性会议(UAI)。

Marszalek, M., & Schmid, C. (2007). Semantic hierarchies for visual object recognition. In CVPR (pp. 1-7).

马尔沙莱克(Marszalek)，M.；施密德(Schmid)，C.(2007)。用于视觉目标识别的语义层次结构。发表于计算机视觉与模式识别会议(CVPR)(第1 - 7页)。

Martinez-Rodriguez, J. L., López-Arévalo, I., & Rios-Alvarado, A. B. (2018). Openie-based approach for knowledge graph construction from text. Expert Systems with Applications, 113, 339-355.

马丁内斯 - 罗德里格斯(Martinez - Rodriguez)，J. L.；洛佩斯 - 阿雷瓦洛(López - Arévalo)，I.；里奥斯 - 阿尔瓦拉多(Rios - Alvarado)，A. B.(2018)。基于开放信息抽取(OpenIE)的从文本构建知识图谱的方法。《专家系统及其应用》，113，339 - 355。

Meilicke, C., Chekol, M. W., Fink, M., & Stuckenschmidt, H. (2020). Reinforced anytime bottom up rule learning for knowledge graph completion. ArXiv Preprint arXiv:2004.04412.

梅利克(Meilicke)，C.；切科尔(Chekol)，M. W.；芬克(Fink)，M.；施图肯施密特(Stuckenschmidt)，H.(2020)。用于知识图谱补全的强化随时自底向上规则学习。预印本论文，arXiv:2004.04412。

Mihalkova, L., & Mooney, R. J. (2007). Bottom-up learning of Markov logic network structure. In ICML (pp. 625-632).

米哈尔科娃(Mihalkova)，L.；穆尼(Mooney)，R. J.(2007)。马尔可夫逻辑网络结构的自底向上学习。发表于国际机器学习会议(ICML)(第625 - 632页)。

Minervini, P., Demeester, T., Rocktäschel, T., & Riedel, S. (2017). Adversarial sets for regularising neural link predictors. ArXiv Preprint arXiv:1707.07596.

米内尔维尼(Minervini)，P.；德梅斯特(Demeester)，T.；罗克塔舍尔(Rocktäschel)，T.；里德尔(Riedel)，S.(2017)。用于正则化神经链接预测器的对抗集。预印本论文，arXiv:1707.07596。

Neelakantan, A., Roth, B., & McCallum, A. (2015). Compositional vector space models for knowledge base inference. In AAAI.

尼尔坎坦(Neelakantan)，A.；罗斯(Roth)，B.；麦卡勒姆(McCallum)，A.(2015)。用于知识库推理的组合向量空间模型。发表于美国人工智能协会会议(AAAI)。

Ngan, K. H., Garcez, A. D., & Townsend, J. (2022). Extracting meaningful high-fidelity knowledge from convolutional neural networks. In IJCNN (pp. 1-17).

颜(Ngan)，K. H.；加尔塞斯(Garcez)，A. D.；汤森(Townsend)，J.(2022)。从卷积神经网络中提取有意义的高保真知识。发表于国际神经网络联合会议(IJCNN)(第1 - 17页)。

Novák, V., Perfilieva, I., & Mockor, J. (2012). vol. 517, Mathematical Principles of Fuzzy Logic.

诺瓦克(Novák)，V.；佩尔菲利耶娃(Perfilieva)，I.；莫科尔(Mockor)，J.(2012)。第517卷，《模糊逻辑的数学原理》。

Nye, M., Hewitt, L., Tenenbaum, J., & Solar-Lezama, A. (2019). Learning to infer program sketches. In ICML (pp. 4861-4870).

奈伊(Nye)，M.，休伊特(Hewitt)，L.，特南鲍姆(Tenenbaum)，J.，& 索拉尔 - 莱萨马(Solar - Lezama)，A.(2019)。学习推断程序草图。见国际机器学习会议(ICML)论文集(第4861 - 4870页)。

Nyga, D., Balint-Benczedi, F., & Beetz, M. (2014). PR2 looking at things-Ensemble learning for unstructured information processing with Markov logic networks. In ICRA (pp. 3916-3923).

尼加(Nyga)，D.，巴林特 - 本采迪(Balint - Benczedi)，F.，& 贝茨(Beetz)，M.(2014)。PR2观察事物——使用马尔可夫逻辑网络进行非结构化信息处理的集成学习。见国际机器人与自动化会议(ICRA)论文集(第3916 - 3923页)。

Oltramari, A., Francis, J., Ilievski, F., Ma, K., & Mirzaee, R. (2021). Generalizable neuro-symbolic systems for commonsense question answering. In Neuro-Symbolic Artificial Intelligence: The State of the Art (pp. 294-310).

奥尔塔拉马里(Oltramari)，A.，弗朗西斯(Francis)，J.，伊利耶夫斯基(Ilievski)，F.，马(Ma)，K.，& 米尔扎伊(Mirzaee)，R.(2021)。用于常识问答的可泛化神经符号系统。见《神经符号人工智能:现状》(第294 - 310页)。

Payani, A., & Fekri, F. (2019). Inductive logic programming via differentiable deep neural logic networks. ArXiv Preprint arXiv:1906.03523.

帕亚尼(Payani)，A.，& 费克里(Fekri)，F.(2019)。通过可微深度神经逻辑网络进行归纳逻辑编程。预印本论文，arXiv:1906.03523。

Perotti, A., Boella, G., Colombo Tosatto, S., d'Avila Garcez, A. S., Genovese, V., & van der Torre, L. (2012). Learning and reasoning about norms using neural-symbolic systems. In AAMAS (pp. 1023-1030).

佩罗蒂(Perotti)，A.，博埃拉(Boella)，G.，科伦坡·托萨托(Colombo Tosatto)，S.，达维拉·加尔塞斯(d'Avila Garcez)，A. S.，杰诺韦塞(Genovese)，V.，& 范德·托雷(van der Torre)，L.(2012)。使用神经符号系统进行规范学习和推理。见自治个体和多智能体系统国际会议(AAMAS)论文集(第1023 - 1030页)。

Poon, H., & Domingos, P. (2006). Sound and efficient inference with probabilistic and deterministic dependencies. In AAAI, vol. 6 (pp. 458-463).

潘(Poon)，H.，& 多明戈斯(Domingos)，P.(2006)。具有概率和确定性依赖关系的可靠且高效的推理。见美国人工智能协会会议(AAAI)论文集，第6卷(第458 - 463页)。

Poon, H., & Domingos, P. (2009). Unsupervised semantic parsing. In EMNLP (pp. 1-10).

潘(Poon)，H.，& 多明戈斯(Domingos)，P.(2009)。无监督语义解析。见自然语言处理经验方法会议(EMNLP)论文集(第1 - 10页)。

Prates, M., Avelar, P. H., Lemos, H., Lamb, L. C., & Vardi, M. Y. (2019). Learning to solve np-complete problems: A graph neural network for decision tsp. In AAAI, vol .33 no. 01 (pp. 4731-4738).

普拉特斯(Prates)，M.，阿韦拉尔(Avelar)，P. H.，莱莫斯(Lemos)，H.，兰姆(Lamb)，L. C.，& 瓦尔迪(Vardi)，M. Y.(2019)。学习解决NP完全问题:用于决策旅行商问题的图神经网络。见美国人工智能协会会议(AAAI)论文集，第33卷，第01期(第4731 - 4738页)。

Qu, M., & Tang, J. (2020). Probabilistic logic neural networks for reasoning. In ${ICLR}$ .

曲(Qu)，M.，& 唐(Tang)，J.(2020)。用于推理的概率逻辑神经网络。见 ${ICLR}$ 。

Raizada, M. (2022). Survey on recommender systems incorporating trust. In ICAAIC (pp. 1011-1015).

拉伊扎达(Raizada)，M.(2022)。融合信任的推荐系统综述。见国际先进人工智能与计算智能会议(ICAAIC)论文集(第1011 - 1015页)。

Ratti, E., & Graves, M. (2022). Explainable machine learning practices: opening another black box for reliable medical AI. In AI and Ethics (pp. 1-14).

拉蒂(Ratti)，E.，& 格雷夫斯(Graves)，M.(2022)。可解释的机器学习实践:为可靠的医疗人工智能打开另一个黑匣子。见《人工智能与伦理》(第1 - 14页)。

Richardson, M., & Domingos, P. (2006). Markov logic networks. In ML, vol. 62 no. 1-2 (pp. 107-136).

理查森(Richardson)，M.，& 多明戈斯(Domingos)，P.(2006)。马尔可夫逻辑网络。见《机器学习》期刊，第62卷，第1 - 2期(第107 - 136页)。

Riegel, R., Gray, A., Luus, F., Khan, N., Makondo, N., Akhalwaya, I. Y., et al. (2020). Logical neural networks. ArXiv Preprint arXiv:2006.13155.

里格尔(Riegel)，R.，格雷(Gray)，A.，卢斯(Luus)，F.，汗(Khan)，N.，马孔多(Makondo)，N.，阿哈尔瓦亚(Akhalwaya)，I. Y.等(2020)。逻辑神经网络。预印本论文，arXiv:2006.13155。

Rissati, J. V., Molina, P. C., & Anjos, C. S. (2020). Hyperspectral image classification using random forest and deep learning algorithms. In LAGIRS (pp. 132-132). Rocktäschel, T., & Riedel, S. (2017). End-to-end differentiable proving. In NIPS.

里萨蒂(Rissati)，J. V.，莫利纳(Molina)，P. C.，& 安热斯(Anjos)，C. S.(2020)。使用随机森林和深度学习算法进行高光谱图像分类。见拉丁美洲地理信息、遥感与空间分析会议(LAGIRS)论文集(第132 - 132页)。罗克塔舍尔(Rocktäschel)，T.，& 里德尔(Riedel)，S.(2017)。端到端可微证明。见神经信息处理系统大会(NIPS)。

Safavian, S. R., & Landgrebe, D. (1991). A survey of decision tree classifier methodology. IEEE Transactions on Systems, Man, and Cybernetics: System, 21(3), 660-674.

萨法维安(Safavian)，S. R.，& 兰德格雷贝(Landgrebe)，D.(1991)。决策树分类器方法综述。《电气与电子工程师协会系统、人与控制论汇刊:系统》，21(3)，660 - 674。

Salahuddin, Z., Woodruff, H. C., Chatterjee, A., & Lambin, P. (2022). Transparency of deep neural networks for medical image analysis: A review of interpretability methods. In CIBM, vol. 140 (pp. 105-111).

萨拉胡丁(Salahuddin)，Z.，伍德拉夫(Woodruff)，H. C.，查特吉(Chatterjee)，A.，& 兰宾(Lambin)，P.(2022)。用于医学图像分析的深度神经网络的透明度:可解释性方法综述。见《计算机与信息生物学》期刊，第140卷(第105 - 111页)。

Schlichtkrull, M., Kipf, T. N., Bloem, P., Berg, R. v. d., Titov, I., & Welling, M. (2018). Modeling relational data with graph convolutional networks. In ESWC (pp. 593-607).

施利希特克鲁尔(Schlichtkrull)，M.、基普夫(Kipf)，T. N.、布洛姆(Bloem)，P.、伯格(Berg)，R. v. d.、季托夫(Titov)，I.和韦林(Welling)，M.(2018年)。用图卷积网络对关系数据进行建模。见《欧洲语义网会议》(ESWC)(第593 - 607页)。

Serafini, L., & Garcez, A. d. (2016). Logic tensor networks: Deep learning and logical reasoning from data and knowledge. ArXiv Preprint arXiv:1606.04422.

塞拉菲尼(Serafini)，L.和加尔塞斯(Garcez)，A. d.(2016年)。逻辑张量网络:基于数据和知识的深度学习与逻辑推理。预印本论文，arXiv:1606.04422。

Sikka, K., Huang, J., Silberfarb, A., Nayak, P., Rohrer, L., Sahu, P., et al. (2020). Zero-shot learning with knowledge enhanced visual semantic embeddings. ArXiv Preprint arXiv:2011.10889.

西卡(Sikka)，K.、黄(Huang)，J.、西尔伯法布(Silberfarb)，A.、纳亚克(Nayak)，P.、罗勒(Rohrer)，L.、萨胡(Sahu)，P.等(2020年)。基于知识增强视觉语义嵌入的零样本学习。预印本论文，arXiv:2011.10889。

Silva, A., & Gombolay, M. (2021). Encoding human domain knowledge to warm start reinforcement learning. In AAAI, vol. 35 no. 6 (pp. 5042-5050).

席尔瓦(Silva)，A.和贡博拉伊(Gombolay)，M.(2021年)。编码人类领域知识以热启动强化学习。见《美国人工智能协会会议》(AAAI)，第35卷，第6期(第5042 - 5050页)。

Singla, P., & Domingos, P. (2005). Discriminative training of Markov logic networks. In AAAI, vol. 5 (pp. 868-873).

辛格拉(Singla)，P.和多明戈斯(Domingos)，P.(2005年)。马尔可夫逻辑网络的判别式训练。见《美国人工智能协会会议》(AAAI)，第5卷(第868 - 873页)。

Singla, P., & Domingos, P. (2006). Memory-efficient inference in relational domains. In AAAI, vol. 6 (pp. 488-493).

辛格拉(Singla)，P.和多明戈斯(Domingos)，P.(2006年)。关系领域中的内存高效推理。见《美国人工智能协会会议》(AAAI)，第6卷(第488 - 493页)。

Sourek, G., Aschenbrenner, V., Zelezny, F., Schockaert, S., & Kuzelka, O. (2018). Lifted relational neural networks: Efficient learning of latent relational structures. In JAIR, vol. 62 (pp. 69-100).

苏雷克(Sourek)，G.、阿申布伦纳(Aschenbrenner)，V.、泽莱兹尼(Zelezny)，F.、肖卡特(Schockaert)，S.和库泽尔卡(Kuzelka)，O.(2018年)。提升关系神经网络:潜在关系结构的高效学习。见《人工智能研究杂志》(JAIR)，第62卷(第69 - 100页)。

Sun, R., & Alexandre, F. (2013). Connectionist-symbolic integration: from unified to hybrid approaches.

孙(Sun)，R.和亚历山大(Alexandre)，F.(2013年)。连接主义 - 符号集成:从统一方法到混合方法。

Sun, R., & Bookman, L. A. (1994). Computational architectures integrating neural and symbolic processes: A perspective on the state of the art.

孙(Sun)，R.和布克曼(Bookman)，L. A.(1994年)。集成神经和符号过程的计算架构:对当前技术水平的展望。

Sun, Z., Deng, Z.-H., Nie, J.-Y., & Tang, J. (2019). Rotate: Knowledge graph embedding by relational rotation in complex space. In ICLR.

孙(Sun)，Z.、邓(Deng)，Z.-H.、聂(Nie)，J.-Y.和唐(Tang)，J.(2019年)。Rotate:通过复空间中的关系旋转进行知识图谱嵌入。见《国际学习表征会议》(ICLR)。

Sun, Y., Tang, D., Duan, N., Gong, Y., Feng, X., Qin, B., et al. (2020). Neural semantic parsing in low-resource settings with back-translation and meta-learning. In AAAI, vol. 34 no. 05 (pp. 8960-8967).

孙(Sun)，Y.、唐(Tang)，D.、段(Duan)，N.、龚(Gong)，Y.、冯(Feng)，X.、秦(Qin)，B.等(2020年)。在低资源环境下通过反向翻译和元学习进行神经语义解析。见《美国人工智能协会会议》(AAAI)，第34卷，第05期(第8960 - 8967页)。

Tandon, N., Varde, A. S., & de Melo, G. (2018). Commonsense knowledge in machine intelligence. In SIGMOD, vol. 46 no. 4 (pp. 49-52).

坦登(Tandon)，N.、瓦尔代(Varde)，A. S.和德梅洛(de Melo)，G.(2018年)。机器智能中的常识知识。见《管理数据特别兴趣小组会议》(SIGMOD)，第46卷，第4期(第49 - 52页)。

Teru, K., Denis, E., & Hamilton, W. (2020). Inductive relation prediction by subgraph reasoning. In ICML (pp. 9448-9457).

特鲁(Teru)，K.、丹尼斯(Denis)，E.和汉密尔顿(Hamilton)，W.(2020年)。通过子图推理进行归纳关系预测。见《国际机器学习会议》(ICML)(第9448 - 9457页)。

Tian, J., Li, Y., Chen, W., Xiao, L., He, H., & Jin, Y. (2022). Weakly supervised neural symbolic learning for cognitive tasks. In AAAI.

田(Tian)，J.、李(Li)，Y.、陈(Chen)，W.、肖(Xiao)，L.、何(He)，H.和金(Jin)，Y.(2022年)。用于认知任务的弱监督神经符号学习。见《美国人工智能协会会议》(AAAI)。

Towell, G. G., & Shavlik, J. W. (1994). Knowledge-based artificial neural networks. In ${AI}$ , vol. 70, no. 1-2 (pp. 119-165).

托尔韦尔(Towell)，G. G.和沙夫利克(Shavlik)，J. W.(1994年)。基于知识的人工神经网络。见 ${AI}$ ，第70卷，第1 - 2期(第119 - 165页)。

Townsend, J., Chaton, T., & Monteiro, J. M. (2019). Extracting relational explanations from deep neural networks: A survey from a neural-symbolic perspective. In TNNLS, vol. 31, no. 9 (pp. 3456-3470).

汤森(Townsend)，J.、查顿(Chaton)，T.和蒙泰罗(Monteiro)，J. M.(2019年)。从深度神经网络中提取关系解释:从神经符号视角的综述。见《IEEE神经网络与学习系统汇刊》(TNNLS)，第31卷，第9期(第3456 - 3470页)。

Townsend, J., Chaton, T., & Monteiro, J. M. (2020). Extracting relational explanations from deep neural networks: A survey from a neural-symbolic perspective. In TNNLS, vol. 31, no. 9 (pp. 3456-3470).

汤森德(Townsend)，J.，查顿(Chaton)，T.，& 蒙泰罗(Monteiro)，J. M.(2020)。从深度神经网络中提取关系解释:从神经符号视角的综述。发表于《IEEE神经网络与学习系统汇刊》(TNNLS)，第31卷，第9期(第3456 - 3470页)。

Tran, S. D., & Davis, L. S. (2008). Event modeling and recognition using markov logic networks. In ECCV (pp. 610-623).

陈(Tran)，S. D.，& 戴维斯(Davis)，L. S.(2008)。使用马尔可夫逻辑网络进行事件建模与识别。发表于《欧洲计算机视觉会议》(ECCV)(第610 - 623页)。

Trouillon, T., Welbl, J., Riedel, S., Gaussier, É., & Bouchard, G. (2016). Complex embeddings for simple link prediction. In ICML (pp. 2071-2080).

特鲁永(Trouillon)，T.，韦尔布尔(Welbl)，J.，里德尔(Riedel)，S.，高斯捷(Gaussier)，É.，& 布沙尔(Bouchard)，G.(2016)。用于简单链接预测的复数嵌入。发表于《国际机器学习会议》(ICML)(第2071 - 2080页)。

Vashishth, S., Sanyal, S., Nitin, V., & Talukdar, P. (2020). Composition-based multi-relational graph convolutional networks. In ICLR.

瓦希什特(Vashishth)，S.，桑亚尔(Sanyal)，S.，尼廷(Nitin)，V.，& 塔鲁克达尔(Talukdar)，P.(2020)。基于组合的多关系图卷积网络。发表于《国际学习表征会议》(ICLR)。

Von Rueden, L., Mayer, S., Beckh, K., Georgiev, B., Giesselbach, S., Heese, R., et al. (2021). Informed machine learning-A taxonomy and survey of integrating prior knowledge into learning systems. In TKDE, vol. 35 no. 1 (pp. 614-633).

冯·鲁登(Von Rueden)，L.，迈尔(Mayer)，S.，贝克(Beckh)，K.，格奥尔基耶夫(Georgiev)，B.，吉塞尔巴赫(Giesselbach)，S.，赫泽(Heese)，R.等(2021)。知情机器学习——将先验知识集成到学习系统中的分类与综述。发表于《IEEE知识与数据工程汇刊》(TKDE)，第35卷，第1期(第614 - 633页)。

Wang, P., Dou, D., Wu, F., de Silva, N., & Jin, L. (2019). Logic rules powered knowledge graph embedding. ArXiv Preprint arXiv:1903.03772.

王(Wang)，P.，窦(Dou)，D.，吴(Wu)，F.，德席尔瓦(de Silva)，N.，& 金(Jin)，L.(2019)。逻辑规则驱动的知识图谱嵌入。预印本arXiv:1903.03772。

Wang, Z., Ren, Z., He, C., Zhang, P., & Hu, Y. (2019). Robust embedding with multi-level structures for link prediction.. In IJCAI (pp. 5240-5246).

王(Wang)，Z.，任(Ren)，Z.，何(He)，C.，张(Zhang)，P.，& 胡(Hu)，Y.(2019)。用于链接预测的具有多级结构的鲁棒嵌入。发表于《国际人工智能联合会议》(IJCAI)(第5240 - 5246页)。

Wang, Y., Yao, Q., Kwok, J. T., & Ni, L. M. (2020). Generalizing from a few examples: A survey on few-shot learning. In CSUR, vol. 53, no. 3 (pp. 1-34).

王(Wang)，Y.，姚(Yao)，Q.，郭(Kwok)，J. T.，& 倪(Ni)，L. M.(2020)。从少数示例中进行泛化:少样本学习综述。发表于《ACM计算调查》(CSUR)，第53卷，第3期(第1 - 34页)。

Wang, X., Ye, Y., & Gupta, A. (2018). Zero-shot recognition via semantic embeddings and knowledge graphs. In CVPR (pp. 6857-6866).

王(Wang)，X.，叶(Ye)，Y.，& 古普塔(Gupta)，A.(2018)。通过语义嵌入和知识图谱进行零样本识别。发表于《计算机视觉与模式识别会议》(CVPR)(第6857 - 6866页)。

Wang, Z., Zhang, J., Feng, J., & Chen, Z. (2014). Knowledge graph embedding by translating on hyperplanes. In AAAI, vol. 28. (1).

王(Wang)，Z.，张(Zhang)，J.，冯(Feng)，J.，& 陈(Chen)，Z.(2014)。通过超平面上的平移进行知识图谱嵌入。发表于《美国人工智能协会会议》(AAAI)，第28卷(第1期)。

Wen, L.-H., & Jo, K.-H. (2022). Deep learning-based perception systems for autonomous driving: A comprehensive survey. In Neurocomputing.

温(Wen)，L.-H.，& 赵(Jo)，K.-H.(2022)。基于深度学习的自动驾驶感知系统:全面综述。发表于《神经计算》(Neurocomputing)。

Wu, Z., Pan, S., Chen, F., Long, G., Zhang, C., & Philip, S. Y. (2020). A comprehensive survey on graph neural networks. In TNNLS, vol. 32, no. 1 (pp. 4-24).

吴(Wu)，Z.，潘(Pan)，S.，陈(Chen)，F.，龙(Long)，G.，张(Zhang)，C.，& 菲利普(Philip)，S. Y.(2020)。图神经网络综合综述。发表于《IEEE神经网络与学习系统汇刊》(TNNLS)，第32卷，第1期(第4 - 24页)。

Xie, Y., Xu, Z., Kankanhalli, M. S., Meel, K. S., & Soh, H. (2019). Embedding symbolic knowledge into deep networks. In NIPS.

谢(Xie)，Y.，徐(Xu)，Z.，坎坎哈利(Kankanhalli)，M. S.，米尔(Meel)，K. S.，& 苏(Soh)，H.(2019)。将符号知识嵌入到深度网络中。发表于《神经信息处理系统大会》(NIPS)。

Xiong, W., Hoang, T., & Wang, W. Y. (2017). Deeppath: A reinforcement learning method for knowledge graph reasoning. In EMNLP.

熊(Xiong)，W.，黄(Hoang)，T.，& 王(Wang)，W. Y.(2017)。深度路径:一种用于知识图谱推理的强化学习方法。发表于《自然语言处理经验方法会议》(EMNLP)。

Xu, J., Zhang, Z., Friedman, T., Liang, Y., & Broeck, G. (2018). A semantic loss function for deep learning with symbolic knowledge. In ICML (pp. 5502-5511).

徐(Xu)，J.，张(Zhang)，Z.，弗里德曼(Friedman)，T.，梁(Liang)，Y.，& 布罗克(Broeck)，G.(2018)。用于结合符号知识的深度学习的语义损失函数。发表于《国际机器学习会议》(ICML)(第5502 - 5511页)。

Yang, F., Lyu, D., Liu, B., & Gustafson, S. (2018). Peorl: Integrating symbolic planning and hierarchical reinforcement learning for robust decision-making. In IJCAI.

杨(Yang)，F.，吕(Lyu)，D.，刘(Liu)，B.，& 古斯塔夫森(Gustafson)，S.(2018)。Peorl:集成符号规划和分层强化学习以实现鲁棒决策。发表于《国际人工智能联合会议》(IJCAI)。

Yang, Y., & Song, L. (2020). Learn to explain efficiently via neural logic inductive learning. In ICLR.

杨(Yang)和宋(Song)(2020年)。通过神经逻辑归纳学习实现高效解释学习。发表于国际学习表征会议(ICLR)。

Yang, F., Yang, Z., & Cohen, W. W. (2017). Differentiable learning of logical rules for knowledge base completion. In NIPS.

杨(Yang)、杨(Yang)和科恩(Cohen)(2017年)。用于知识库补全的逻辑规则可微学习。发表于神经信息处理系统大会(NIPS)。

Yang, B., Yih, W.-t., He, X., Gao, J., & Deng, L. (2015). Embedding entities and relations for learning and inference in knowledge bases. In ICLR.

杨(Yang)、易(Yih)、何(He)、高(Gao)和邓(Deng)(2015年)。知识库中用于学习和推理的实体与关系嵌入。发表于国际学习表征会议(ICLR)。

Yi, K., Wu, J., Gan, C., Torralba, A., Kohli, P., & Tenenbaum, J. B. (2018). Neural-symbolic vqa: Disentangling reasoning from vision and language understanding. In NIPS.

易(Yi)、吴(Wu)、甘(Gan)、托拉尔巴(Torralba)、科利(Kohli)和特南鲍姆(Tenenbaum)(2018年)。神经符号视觉问答:将推理与视觉和语言理解分离。发表于神经信息处理系统大会(NIPS)。

Yu, D., Yang, B., Wei, Q., Li, A., & Pan, S. (2022). A probabilistic graphical model based on neural-symbolic reasoning for visual relationship detection. In CVPR (pp. 10609-10618).

余(Yu)、杨(Yang)、魏(Wei)、李(Li)和潘(Pan)(2022年)。基于神经符号推理的概率图模型用于视觉关系检测。发表于计算机视觉与模式识别会议(CVPR)(第10609 - 10618页)。

Zhang, Y., Chen, X., Yang, Y., Ramamurthy, A., Li, B., Qi, Y., et al. (2020). Efficient probabilistic logic reasoning with graph neural networks. In ICLR.

张(Zhang)、陈(Chen)、杨(Yang)、拉马穆尔蒂(Ramamurthy)、李(Li)、齐(Qi)等人(2020年)。利用图神经网络进行高效概率逻辑推理。发表于国际学习表征会议(ICLR)。

Zhang, J., Chen, B., Zhang, L., Ke, X., & Ding, H. (2021). Neural, symbolic and neural-symbolic reasoning on knowledge graphs. 2, In AI Open (pp. 14-35).

张(Zhang)、陈(Chen)、张(Zhang)、柯(Ke)和丁(Ding)(2021年)。知识图谱上的神经、符号和神经符号推理。第2部分，发表于《人工智能开放》(AI Open)(第14 - 35页)。

Zhong, J., Haoran, W., Yunlong, Y., & Yanwei, P. (2019). A decadal survey of zero-shot image classification. Scientia Sinica Informationis, 49(10), 1299-1320.

钟(Zhong)、吴浩然(Haoran)、杨云龙(Yunlong)和潘彦伟(Yanwei)(2019年)。零样本图像分类十年综述。《中国科学:信息科学》，49(10)，1299 - 1320。

Zhou, Z.-H. (2019). Abductive learning: towards bridging machine learning and logical reasoning. Science China Information Sciences, 62(7), 1-3.

周志华(Zhou)(2019年)。溯因学习:迈向连接机器学习和逻辑推理。《中国科学:信息科学》，62(7)，1 - 3。

Zhu, Y., Fathi, A., & Fei-Fei, L. (2014). Reasoning about object affordances in a knowledge base representation. In ECCV (pp. 408-424).

朱(Zhu)、法蒂(Fathi)和李菲菲(Fei - Fei)(2014年)。知识库表示中对象功能的推理。发表于欧洲计算机视觉会议(ECCV)(第408 - 424页)。

Zhu, Y., Xian, Y., Fu, Z., de Melo, G., & Zhang, Y. (2021). Faithfully explainable recommendation via neural logic reasoning. In ${ACL}$ ,

朱(Zhu)、冼(Xian)、傅(Fu)、德梅洛(de Melo)和张(Zhang)(2021年)。通过神经逻辑推理实现可忠实解释的推荐。发表于 ${ACL}$ 。

Zuidberg Dos Martires, P., Kumar, N., Persson, A., Loutfi, A., & De Raedt, L. (2020). Symbolic learning and reasoning with noisy data for probabilistic anchoring. Frontiers in Robotics and AI, 7, 100.

祖伊德伯格·多斯·马丁雷斯(Zuidberg Dos Martires)、库马尔(Kumar)、佩尔松(Persson)、卢特菲(Loutfi)和德雷德特(De Raedt)(2020年)。用于概率锚定的含噪数据符号学习与推理。《机器人与人工智能前沿》，7，100。