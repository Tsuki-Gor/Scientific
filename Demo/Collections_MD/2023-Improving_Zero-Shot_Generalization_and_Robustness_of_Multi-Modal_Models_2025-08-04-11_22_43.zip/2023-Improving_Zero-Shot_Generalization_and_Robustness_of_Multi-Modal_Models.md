# Improving Zero-shot Generalization and Robustness of Multi-modal Models

# 提升多模态模型的零样本泛化能力与鲁棒性

Yunhao Ge ${}^{1,2 * }$ , Jie Ren ${}^{1 * }$ , Andrew Gallagher ${}^{1}$ , Yuxiao Wang ${}^{1}$ , Ming-Hsuan Yang ${}^{1}$ , Hartwig Adam ${}^{1}$ , Laurent Itti ${}^{2}$ , Balaji Lakshminarayanan ${}^{1 \dagger  }$ , Jiaping Zhao ${}^{1 \dagger  }$ ${}^{1}$ Google Research ${}^{2}$ University of Southern California

葛云昊 ${}^{1,2 * }$ ,任杰 ${}^{1 * }$ , Andrew Gallagher ${}^{1}$ ,王宇霄 ${}^{1}$ ,杨明轩 ${}^{1}$ , Hartwig Adam ${}^{1}$ , Laurent Itti ${}^{2}$ , Balaji Lakshminarayanan ${}^{1 \dagger  }$ ,赵家平 ${}^{1 \dagger  }$ ${}^{1}$ 谷歌研究院 ${}^{2}$ 南加州大学

*co-first author, †correspondence to \{balajiln, jiapingz\}@google.com

*共同第一作者，†通讯作者联系邮箱 \{balajiln, jiapingz\}@google.com

## Abstract

## 摘要

Multi-modal image-text models such as CLIP and LiT have demonstrated impressive performance on image classification benchmarks and their zero-shot generalization ability is particularly exciting. While the top-5 zero-shot accuracies of these models are very high, the top-1 accuracies are much lower (over 25% gap in some cases). We investigate the reasons for this performance gap and find that many of the failure cases are caused by ambiguity in the text prompts. First, we develop a simple and efficient zero-shot post-hoc method to identify images whose top-1 prediction is likely to be incorrect, by measuring consistency of the predictions w.r.t. multiple prompts and image transformations. We show that our procedure better predicts mistakes, outperforming the popular max logit baseline on selective prediction tasks. Next, we propose a simple and efficient way to improve accuracy on such uncertain images by making use of the WordNet hierarchy; specifically we augment the original class by incorporating its parent and children from the semantic label hierarchy, and plug the augmentation into text prompts. We conduct experiments on both CLIP and LiT models with five different ImageNet-based datasets. For CLIP, our method improves the top- 1 accuracy by 17.13% on the uncertain subset and 3.6% on the entire ImageNet validation set. We also show that our method improves across ImageNet shifted datasets, four other datasets, and other model architectures such as LiT. The proposed method ${}^{1}$ is hyperparameter-free, requires no additional model training and can be easily scaled to other large multi-modal architectures. Code is available at https://github.com/gyhandy/Hierarchy-CLIP.

多模态图文模型如CLIP和LiT在图像分类基准测试中表现出色，其零样本泛化能力尤为令人振奋。尽管这些模型的top-5零样本准确率非常高，但top-1准确率明显较低(某些情况下差距超过25%)。我们探究了这一性能差距的原因，发现许多失败案例源于文本提示的歧义。首先，我们提出了一种简单高效的零样本后验方法，通过测量多个提示和图像变换下预测结果的一致性，识别top-1预测可能错误的图像。实验表明，该方法在选择性预测任务中优于流行的最大logit基线，更准确地预测错误。接着，我们提出利用WordNet(词网)层级结构提升此类不确定图像准确率的简便方法；具体做法是通过语义标签层级将原始类别扩展为其父类和子类，并将扩展内容融入文本提示中。我们在CLIP和LiT模型及五个基于ImageNet的数据集上进行了实验。对于CLIP，我们的方法在不确定子集上top-1准确率提升了17.13%，在整个ImageNet验证集上提升了3.6%。此外，我们的方法在ImageNet偏移数据集、其他四个数据集及LiT等其他模型架构上均表现出提升。该方法无超参数需求，无需额外模型训练，且易于扩展至其他大型多模态架构。代码开源于https://github.com/gyhandy/Hierarchy-CLIP。

## 1. Introduction

## 1. 引言

Vision-language multi-modal models trained on large-scale data have achieved significant success in numerous domains and have demonstrated excellent zero-shot generalization ability [7, 12, 18, 19, 20, 28]. Given a test image and a set of candidate class labels, one can compute the similarity between the embedding of the image and the embedding of each candidate class labels, and predict the class as the one with the highest similarity. The zero-shot top-1 accuracy for ImageNet [4] using CLIP variants (CLIP ViT-L) matches the performance of the original ResNet model trained from scratch. Recently, CLIP has been found to be more robust to distribution shift than ResNet, achieving good performance on ImageNet-V2 [21], ImageNet-R [9], ImageNet-A [11], and ImageNet-Sketch [25].

基于大规模数据训练的视觉-语言多模态模型在众多领域取得了显著成功，并展现出卓越的零样本泛化能力[7, 12, 18, 19, 20, 28]。给定一张测试图像和一组候选类别标签，可以计算图像嵌入与每个候选类别嵌入的相似度，并将相似度最高的类别作为预测结果。使用CLIP变体(CLIP ViT-L)在ImageNet[4]上的零样本top-1准确率已达到从零训练的ResNet模型的水平。近期研究发现，CLIP在分布偏移下比ResNet更具鲁棒性，在ImageNet-V2[21]、ImageNet-R[9]、ImageNet-A[11]和ImageNet-Sketch[25]等数据集上表现良好。

We noticed a large gap between the top-1 accuracy and top-5 accuracy, ${64.2}\%$ vs. ${89.4}\%$ respectively, revealing potential headroom for improvement. We investigated the cases where the top-1 prediction was incorrect but the top-5 prediction was correct, and identified several typical failure modes. Despite the well-known multi-label issues in Ima-geNet [1], we found many of the remaining failure cases are caused by noise and ambiguous text prompts related to the WordNet hierarchical structure of ImageNet. Some class names are quite general so that the model cannot correctly match images from their specific subclasses. For example, the hot-air balloon images belonging to the "balloon" class were misclassified as "airship", see Figure 1 middle. On the other hand, some class names are too specific such that the model fails to correlate them with their more generic super-classes. For example, ${96}\%$ of images with ground truth label "tusker" are wrongly classified as other elephant classes such as "Asian elephant", see Figure 1 left. The failure modes analysis suggests that the text encoder is very sensitive to inputs and as a result, the overall classification lacks robustness.

我们注意到top-1准确率与top-5准确率之间存在较大差距，分别为${64.2}\%$与${89.4}\%$，显示出潜在的提升空间。我们调查了top-1预测错误但top-5预测正确的情况，识别出若干典型失败模式。尽管ImageNet[1]中已知存在多标签问题，但我们发现许多剩余失败案例源于与ImageNet的WordNet层级结构相关的文本提示噪声和歧义。一些类别名称过于宽泛，导致模型无法正确匹配其具体子类的图像。例如，属于“气球”类别的热气球图像被误分类为“飞艇”，见图1中部。另一方面，一些类别名称过于具体，模型未能将其与更通用的上级类别关联。例如，部分真实标签为“长牙象(tusker)”的图像被错误分类为其他象类，如“亚洲象”，见图1左侧。失败模式分析表明，文本编码器对输入极为敏感，导致整体分类缺乏鲁棒性。

Inspired by these observations, we propose to first identify the subset of images whose top-1 prediction is likely to be incorrect, and then improve the accuracy for those images by a principled framework to augment their class labels by WordNet hierarchy. To estimate whether an image has an incorrect prediction, i.e., to estimate the prediction confidence, we use the consistency of predictions under different text prompt templates and image augmentations as a signal for prediction confidence estimation. Although prediction confidence estimation has been well studied in single-modal classification models, we found those commonly used confidence scores, maximum softmax probability [10] and maximum logit score [8], are not always reliable for the multi-modal CLIP and LiT models due to the poor calibration of the logits scores. For example, among the $1\mathrm{\;K}$ classes in ImageNet, the class with the greatest mean logit value (computed as the cosine similarity between image and text embeddings) is "fig" (the fruit). Though we don't have access to CLIP private training data, we hypothesize that this might be due to "fig" being a common abbreviation for "figure", which frequently occurs in the training data and thus includes many non-fruit illustrations.

受这些观察的启发，我们提出首先识别出其Top-1预测可能错误的图像子集，然后通过一个有原则的框架利用WordNet层级结构增强其类别标签，从而提高这些图像的准确率。为了估计图像预测是否错误，即估计预测置信度，我们使用不同文本提示模板和图像增强下预测结果的一致性作为预测置信度估计的信号。尽管单模态分类模型中的预测置信度估计已有深入研究，但我们发现常用的置信度分数，如最大softmax概率[10]和最大logit分数[8]，由于logit分数校准不佳，对于多模态CLIP和LiT模型并不总是可靠。例如，在ImageNet的$1\mathrm{\;K}$个类别中，平均logit值最高的类别(计算为图像和文本嵌入的余弦相似度)是“fig”(无花果)。虽然我们无法访问CLIP的私有训练数据，但我们推测这可能是因为“fig”常作为“figure”的缩写频繁出现在训练数据中，因此包含了许多非水果的插图。

---

${}^{1}$ Work carried out mainly at Google

${}^{1}$ 主要工作在谷歌完成

---

In this work, we first propose a simple yet efficient zero-shot confidence estimation method better suited for CLIP, based on predictions' self-consistency over different text prompts and image perturbations. [26] proposed using self-consistency among multiple model outputs to improve the reasoning accuracy of large language models. Here we extend the idea for confidence estimation in multi-modal models by measuring consistency of predictions under multiple input text prompts and image transformations. Our method is effective at predicting mistakes; the identified low confidence subset has significantly lower top-1 accuracy (21.58%) than the average accuracy (64.18%). Next, to improve the accuracy for the low confidence subset, we develop a label augmentation technique using Word-Net label hierarchy. Our method leverages semantic information from ancestors (top-down) as well as children (bottom-up) and improves the top-1 accuracy of the subset to 38.71% (17.13% improvement). Our method not only improves model accuracy, but also model robustness, improving on ImageNet variants with distribution shift such as ImageNet-v2, ImageNet-R, ImageNet-Adversarial and Imagenet-Sketch.

在本工作中，我们首先提出了一种简单而高效的零样本置信度估计方法，更适合CLIP，基于不同文本提示和图像扰动下预测结果的自一致性。[26]提出利用多个模型输出间的自一致性来提升大型语言模型的推理准确性。这里我们将该思想扩展到多模态模型的置信度估计，通过测量多种输入文本提示和图像变换下预测结果的一致性。我们的方法在预测错误方面效果显著；识别出的低置信度子集的Top-1准确率显著低于平均准确率(21.58%对比64.18%)。接着，为提升低置信度子集的准确率，我们开发了一种利用WordNet标签层级的标签增强技术。该方法利用了祖先(自上而下)和子类(自下而上)的语义信息，将该子集的Top-1准确率提升至38.71%(提升17.13%)。我们的方法不仅提升了模型准确率，还增强了模型的鲁棒性，在存在分布偏移的ImageNet变体如ImageNet-v2、ImageNet-R、ImageNet-Adversarial和ImageNet-Sketch上均有改进。

The main contributions of this work are:

本工作的主要贡献包括:

- We identified several failure modes for zero-shot Im-ageNet classification using multi-modal models, and our findings suggest that the text encoder is very sensitive to prompts. To improve the prediction accuracy, prompts need to be better designed.

- 我们识别了多模态模型零样本ImageNet分类的若干失败模式，发现文本编码器对提示非常敏感。为提升预测准确率，提示设计需更加优化。

- We propose a simple yet efficient zero-shot confidence score that is better suited for multi-modal models, based on predictions' self-consistency under different text prompts and image perturbations.

- 我们提出了一种简单而高效的零样本置信度分数，更适合多模态模型，基于不同文本提示和图像扰动下预测结果的自一致性。

- We develop a label augmentation technique that uses both ancestor and children labels from WordNet. By applying the label augmentation to the previously identified low confidence subset of images, we significantly improve their prediction accuracy.

- 我们开发了一种利用WordNet中祖先和子类标签的标签增强技术。通过将标签增强应用于先前识别的低置信度图像子集，显著提升了其预测准确率。

## 2. Related work

## 2. 相关工作

Confidence estimation. Reliably estimating the confidence of a prediction is helpful for downstream decision making and can ensure the safe deployment of machine learning models. A well-calibrated confidence estimation should assign low scores for incorrect predictions and high score for correct predictions. Maximum softmax probability [10] and maximum logit [8] are the most commonly used confidence scores for classification problems, because of their simplicity and computational efficiency. Recent works propose more sophisticated confidence estimation methods which either involve modifications to the classification models or significantly increase the inference time. For example, Bayesian approaches such as Gaussian Process layer [16] and dropout-based variational inference [6] assume the weights in the neural networks are random variables such that the final prediction follows a distribution. A large variance of a prediction indicates the low confidence of the prediction. Non-Bayesian methods such as ensemble-based methods which aggregate the predictions from multiple models to improve the robustness of the confidence estimation [14, 27]. Those sophisticated methods were developed and studied in the single-modal models, and the application to multi-modal models is not straightforward. In addition, those methods mostly require modification to the model and additional training, which becomes challenging to multi-modal models since the training data are generally not publicly available. In our work, we focus on a zero-shot confidence estimation that is exclusively designed for multi-modal models. Our method does not require additional training, and is simple, efficient, and effective.

置信度估计。可靠地估计预测置信度有助于下游决策，并确保机器学习模型的安全部署。良好校准的置信度估计应对错误预测赋予低分，对正确预测赋予高分。最大softmax概率[10]和最大logit[8]是分类问题中最常用的置信度分数，因其简单且计算高效。近期工作提出了更复杂的置信度估计方法，这些方法要么涉及对分类模型的修改，要么显著增加推理时间。例如，贝叶斯方法如高斯过程层[16]和基于dropout的变分推断[6]假设神经网络权重为随机变量，使最终预测服从分布。预测的高方差表明置信度低。非贝叶斯方法如基于集成的方法通过聚合多个模型的预测提升置信度估计的鲁棒性[14, 27]。这些复杂方法主要在单模态模型中开发和研究，应用于多模态模型并不直接。此外，这些方法大多需要修改模型和额外训练，而多模态模型的训练数据通常不公开，增加了难度。在本工作中，我们专注于专为多模态模型设计的零样本置信度估计方法。该方法无需额外训练，简单、高效且有效。

Prompt engineering. Prompt engineering and learning has attracted much attention in vision and learning since the introduction of image-text models [12, 19, 28]. The image-text models align images and their text descriptions into a common space, which facilitates model generalization to unseen categories at inference time. However, it has been observed that downstream image classification accuracy highly depends on the specific input prompts. This motivates researchers to either fine-tune or auto-learn prompts when adapting multi-modal models to downstream vision tasks. $\left\lbrack  {{29},{30}}\right\rbrack$ propose $\mathrm{{CoOp}}$ and $\mathrm{{CoCoOp}}$ to automatically learn the prompt word embeddings in the few-shot settings, and show significant improvements over the vanilla zero-shot image classification based-on prompting. These are learning based approaches, requiring supervised data from downstream tasks, while our proposed method is zero-shot and post-hoc without using any supervised data. In concurrent work, [24] proposes learning prompt embeddings in an unsupervised manner by minimizing the entropy of the averaged prediction probability distribution, where each prediction is based on a random augmentation applied to the input image. Our work differs from [24] in the sense that we do not learn an input-dependent prompt embedding. Instead we only selectively modify the prompts using knowledge hierarchy for images that have unreliable predictions, and our modified new prompt is natural language rather than a numerical embedding.

提示工程。自从图文模型(image-text models)[12, 19, 28]被引入以来，提示工程和学习在视觉和学习领域引起了广泛关注。图文模型将图像及其文本描述对齐到一个共同空间，从而促进模型在推理时对未见类别的泛化能力。然而，观察发现下游图像分类的准确率高度依赖于具体的输入提示。这促使研究者在将多模态模型适配到下游视觉任务时，要么微调提示，要么自动学习提示。$\left\lbrack  {{29},{30}}\right\rbrack$提出了$\mathrm{{CoOp}}$和$\mathrm{{CoCoOp}}$，在少样本设置下自动学习提示词嵌入，并显示出相较于基于提示的基础零样本图像分类的显著提升。这些方法基于学习，需要下游任务的监督数据，而我们提出的方法是零样本且事后进行的，不使用任何监督数据。在同期工作中，[24]提出通过最小化平均预测概率分布的熵以无监督方式学习提示嵌入，其中每个预测基于对输入图像的随机增强。我们的工作与[24]不同之处在于，我们不学习依赖输入的提示嵌入，而是仅针对预测不可靠的图像，利用知识层级选择性地修改提示，且我们修改后的新提示是自然语言，而非数值嵌入。

![bo_d1mk7nn7aajc73dikm2g_2_214_163_1361_485_0.jpg](images/bo_d1mk7nn7aajc73dikm2g_2_214_163_1361_485_0.jpg)

Figure 1. Typical failure modes in the cases where top-5 prediction was correct but top-1 was wrong.

图1. 在Top-5预测正确但Top-1错误的情况下的典型失败模式。

Label hierarchy. Label hierarchy or label ontology are relational graphs among semantic labels. WordNet is one of the most widely used concept ontologies, and it has been used for visual recognition problems. Fergus et al. [5] leverage the WordNet hierarchy to define a semantic distance between any two categories and use this semantic distance to share labels. Deng et al. [3] propose a hierarchy and exclusion graph to explicitly model the semantic relations among labels, and significantly improve object classification by exploiting the rich label hierarchy. The idea of semantic distance defined on the WordNet ontology graph is also used in $\left\lbrack  {{22},{23}}\right\rbrack$ for transferring knowledge in zero-shot learning problems. We are similar to the above work in that we utilize the label semantics encoded by the label hierarchy as well, but label hierarchy in our case is used in the multi-modality scenarios: textual labels and visual images are represented in the same latent space, therefore, the hierarchy structure is directly exploited in the representation space to steer the recognition process.

标签层级。标签层级或标签本体是语义标签之间的关系图。WordNet是最广泛使用的概念本体之一，已被应用于视觉识别问题。Fergus等人[5]利用WordNet层级定义任意两个类别之间的语义距离，并用该语义距离共享标签。Deng等人[3]提出了层级和排斥图，显式建模标签间的语义关系，通过利用丰富的标签层级显著提升了目标分类性能。在零样本学习问题中，基于WordNet本体图定义的语义距离的思想也被$\left\lbrack  {{22},{23}}\right\rbrack$用于知识迁移。我们与上述工作相似，也利用了标签层级编码的标签语义，但我们的标签层级应用于多模态场景:文本标签和视觉图像被表示在同一潜在空间，因此层级结构直接在表示空间中被利用以引导识别过程。

## 3. Zero-shot inference failure case analysis

## 3. 零样本推理失败案例分析

Given that the top-1 accuracy (64.2%) is much lower than top-5 accuracy (89.4%) for zero-shot ImageNet classification using CLIP, we investigated the failure cases that are "top-5 correct but top-1 wrong" (12605 images, 25.2% of all test images). Table. 1 in Suppl. shows some representative classes. The failure modes are summarized as:

鉴于使用CLIP进行零样本ImageNet分类时，Top-1准确率(64.2%)远低于Top-5准确率(89.4%)，我们调查了“Top-5正确但Top-1错误”的失败案例(12605张图像，占所有测试图像的25.2%)。补充材料表1展示了一些代表性类别。失败模式总结如下:

(1) Class name does not specify super-class name: Some classes, whose class names do not have their WordNet ancestor (e.g., "tusker", one of 1k ImageNet classes, does not have its parent "elephant" in the class name), may have a relatively lower score than other classes, which explicitly have the ancestor present in the class name (e.g., "Asian elephant"). See examples in Fig. 1 (Left).

(1) 类名未指定上级类别名:某些类别的类名未包含其WordNet祖先(例如，ImageNet的1k类别之一“tusker”类名中未包含其父类“elephant”)，其得分可能相对较低，而明确包含祖先类名的类别(如“Asian elephant”)得分较高。见图1(左)示例。

(2) Class name does not specify sub-class name: If the class name is too abstract, then its CLIP embedding is not necessarily close to the image embedding: e.g, CLIP wrongly classifies most images from "balloon" class as airship, see Fig. 1 (Middle). That is because there are distinct kinds of balloons, each belonging to a different semantic subgroup. Relying on the text embedding of the fine-grained children's class names (e.g., using "hot-air balloon") often fixes these errors. [1] reported the similar issue of label ambiguity in ImageNet.

(2) 类名未指定子类名:如果类名过于抽象，其CLIP嵌入不一定接近图像嵌入:例如，CLIP错误地将大多数“balloon”类图像分类为飞艇，见图1(中)。这是因为气球有不同种类，分别属于不同的语义子群。依赖细粒度子类名的文本嵌入(如使用“hot-air balloon”)通常能纠正这些错误。[1]报道了ImageNet中类似的标签歧义问题。

(3) Inconsistent naming between class names: Some ImageNet class names are nouns, but others are adjective-prefixed nouns. This may make CLIP text embedding biased, see one example in Fig. 1 (Right) where images from "screw" class are misclassified as "metal nail".

(3) 类名命名不一致:部分ImageNet类名为名词，部分为形容词前缀名词，这可能导致CLIP文本嵌入偏差。图1(右)中，“screw”类图像被误分类为“metal nail”即为一例。

## 4. Proposed Method

## 4. 提出的方法

As shown in Section 3, CLIP models can be sensitive to different text prompts for images in certain classes. In this section, we first propose a confidence estimation method to identify low confidence predictions. We show that the identified subset has much lower accuracy than the average (Sec.4.1). We next develop a principled method that utilizes knowledge hierarchy to improve the accuracy of the low confidence subset, and consequently improve the overall accuracy on the whole datasets (Sec. 4.2).

如第3节所示，CLIP模型对某些类别图像的不同文本提示较为敏感。本节首先提出一种置信度估计方法以识别低置信度预测。我们展示了该子集的准确率远低于平均水平(第4.1节)。随后，我们开发了一种利用知识层级的原则性方法，以提升低置信度子集的准确率，从而提高整个数据集的整体准确率(第4.2节)。

### 4.1. Self-consistent zero-shot confidence estimation

### 4.1. 自洽的零样本置信度估计

Given an image $\mathbf{x}$ and a candidate class name $c$ , where $c \in  \mathcal{C},\left| \mathcal{C}\right|  = {1000}$ , the CLIP model encodes $\mathbf{x}$ and $c$ respectively by its image encoder ${f}_{\text{image }}$ and text encoder ${f}_{\text{text }}$ , denoted as ${\mathbf{z}}_{m} = {f}_{\text{image }}\left( \mathbf{x}\right)$ and ${\mathbf{z}}_{c} = {f}_{\text{text }}\left( c\right)$ . The prediction logit score is defined as $\operatorname{logit}\left( {\mathbf{x}, c}\right)  = \cos \left( {{\mathbf{z}}_{m},{\mathbf{z}}_{c}}\right)$ , where $\cos \left( {\cdot , \cdot  }\right)$ is the cosine similarity between two vectors, and the predicted class is arg $\mathop{\max }\limits_{{c \in  \mathcal{C}}}\operatorname{logit}\left( {\mathbf{x}, c}\right)$ . We estimate the confidence by the self-consistency rate when applying different context prompts and image augmentations.

给定一张图像$\mathbf{x}$和一个候选类别名称$c$，其中$c \in  \mathcal{C},\left| \mathcal{C}\right|  = {1000}$，CLIP模型分别通过其图像编码器${f}_{\text{image }}$和文本编码器${f}_{\text{text }}$对$\mathbf{x}$和$c$进行编码，记为${\mathbf{z}}_{m} = {f}_{\text{image }}\left( \mathbf{x}\right)$和${\mathbf{z}}_{c} = {f}_{\text{text }}\left( c\right)$。预测的logit分数定义为$\operatorname{logit}\left( {\mathbf{x}, c}\right)  = \cos \left( {{\mathbf{z}}_{m},{\mathbf{z}}_{c}}\right)$，其中$\cos \left( {\cdot , \cdot  }\right)$是两个向量之间的余弦相似度，预测类别为arg$\mathop{\max }\limits_{{c \in  \mathcal{C}}}\operatorname{logit}\left( {\mathbf{x}, c}\right)$。我们通过在应用不同上下文提示和图像增强时的自洽率来估计置信度。

Confidence estimation via text prompts. To improve the zero-shot classifier's performance, the CLIP paper [19] hand crafted various context prompts, e.g. "A photo of a big \{label\}" and "A photo of a small \{label\}"), for different datasets for the purpose of prompt ensembling: For an image $\mathbf{x}$ , given a set of context prompts $\mathcal{T}$ , the ensembled logit score is $\operatorname{logit}\left( {\mathbf{x},\mathcal{T}\left( c\right) }\right)  = \frac{1}{\left| \mathcal{T}\right| }\mathop{\sum }\limits_{{t \in  \mathcal{T}}}\operatorname{logit}\left( {\mathbf{x}, t\left( c\right) }\right)$ , where $t\left( c\right)$ denotes the new prompt after applying context prompt $t\left( \cdot \right)$ to c. Here instead of using the prompts for ensembling, we make use of the prompts to define our confidence score. Given a set of prompts $\mathcal{T}$ , we apply each of the prompt $t\left( \cdot \right)$ for the classifier, and see if the top-1 prediction is the same as that when applying no prompt. We use the percentage of prompts that have consistent top-1 prediction with that without prompt as the confidence score ${S}_{\mathcal{T}}\left( \mathbf{x}\right)$ , i.e.

通过文本提示进行置信度估计。为了提升零样本分类器的性能，CLIP论文[19]为不同数据集手工设计了多种上下文提示，例如“大{label}的照片”和“小{label}的照片”，用于提示集成:对于一张图像$\mathbf{x}$，给定一组上下文提示$\mathcal{T}$，集成后的logit分数为$\operatorname{logit}\left( {\mathbf{x},\mathcal{T}\left( c\right) }\right)  = \frac{1}{\left| \mathcal{T}\right| }\mathop{\sum }\limits_{{t \in  \mathcal{T}}}\operatorname{logit}\left( {\mathbf{x}, t\left( c\right) }\right)$，其中$t\left( c\right)$表示将上下文提示$t\left( \cdot \right)$应用于c后的新提示。这里我们不使用提示进行集成，而是利用提示来定义我们的置信度分数。给定一组提示$\mathcal{T}$，我们对分类器应用每个提示$t\left( \cdot \right)$，并观察其top-1预测是否与不使用提示时相同。我们使用与无提示时top-1预测一致的提示所占比例作为置信度分数${S}_{\mathcal{T}}\left( \mathbf{x}\right)$，即

$$
{S}_{\mathcal{T}}\left( \mathbf{x}\right)  = \frac{\mathop{\sum }\limits_{{t \in  \mathcal{T}}}\mathbb{1}\{ \widehat{c}\left( {\mathbf{x}, t}\right)  = \widehat{c}\left( {\mathbf{x},\varnothing }\right) \} }{\left| \mathcal{T}\right| } \tag{1}
$$

![bo_d1mk7nn7aajc73dikm2g_3_135_156_1469_571_0.jpg](images/bo_d1mk7nn7aajc73dikm2g_3_135_156_1469_571_0.jpg)

Figure 2. Our zero-shot classification pipeline consists of 2 steps: confidence estimation via self-consistency (left block) and top-down and bottom-up label augmentation using the WordNet hierarchy (right block). See Algorithms 1 and 2 for pseudocode.

图2。我们的零样本分类流程包括两个步骤:通过自洽性进行置信度估计(左侧模块)以及利用WordNet层级结构进行自顶向下和自底向上的标签增强(右侧模块)。伪代码见算法1和算法2。

where $\widehat{c}\left( {\mathbf{x},\varnothing }\right)  = \arg \mathop{\max }\limits_{{c \in  \mathcal{C}}}\operatorname{logit}\left( {\mathbf{x}, c}\right)$ is the top-1 prediction using the pure class name, and $\widehat{c}\left( {\mathbf{x}, t}\right)  =$ $\arg \mathop{\max }\limits_{{c \in  \mathcal{C}}}\operatorname{logit}\left( {\mathbf{x}, t\left( c\right) }\right)$ is the top-1 prediction when applying prompt $t\left( \cdot \right)$ . Intuitively, a reliable prediction should have highly consistent top-1 predictions when context prompts are applied or not, and therefore should have a high confidence score ${S}_{\mathcal{T}}\left( \mathbf{x}\right)$ with respect to the prompt set $\mathcal{T}$ , and vice versa.

其中$\widehat{c}\left( {\mathbf{x},\varnothing }\right)  = \arg \mathop{\max }\limits_{{c \in  \mathcal{C}}}\operatorname{logit}\left( {\mathbf{x}, c}\right)$是使用纯类别名称时的top-1预测，$\widehat{c}\left( {\mathbf{x}, t}\right)  =$$\arg \mathop{\max }\limits_{{c \in  \mathcal{C}}}\operatorname{logit}\left( {\mathbf{x}, t\left( c\right) }\right)$是应用提示$t\left( \cdot \right)$时的top-1预测。直观上，可靠的预测在应用或不应用上下文提示时应具有高度一致的top-1预测，因此相对于提示集$\mathcal{T}$应具有较高的置信度分数${S}_{\mathcal{T}}\left( \mathbf{x}\right)$，反之亦然。

Confidence estimation via image perturbation. We can also estimate the confidence of a prediction based on the self-consistency when applying different perturbations to the input image. Intuitively, if the top-1 predictions are inconsistent when applying different image perturbations, the prediction is unreliable. Specifically, we consider the common image transformations, left-right flip, rotation, crop, etc., and apply the perturbation method $b\left( \cdot \right)$ to the input image, and infer the predicted class as $\widehat{c}\left( {\mathbf{x}, b}\right)  =$ $\arg \mathop{\max }\limits_{{c \in  \mathcal{C}}}\operatorname{logit}\left( {b\left( \mathbf{x}\right) , c}\right)$ . We define the confidence score with respect to a set of image perturbations $\mathcal{B}$ as,

通过图像扰动进行置信度估计。我们还可以基于对输入图像施加不同扰动时的自一致性来估计预测的置信度。直观地说，如果在应用不同图像扰动时，top-1预测结果不一致，则该预测不可靠。具体而言，我们考虑常见的图像变换，如左右翻转、旋转、裁剪等，并对输入图像应用扰动方法$b\left( \cdot \right)$，推断预测类别为$\widehat{c}\left( {\mathbf{x}, b}\right)  =$ $\arg \mathop{\max }\limits_{{c \in  \mathcal{C}}}\operatorname{logit}\left( {b\left( \mathbf{x}\right) , c}\right)$。我们定义相对于一组图像扰动$\mathcal{B}$的置信度得分为，

$$
{S}_{\mathcal{B}}\left( \mathbf{x}\right)  = \frac{\mathop{\sum }\limits_{{b \in  \mathcal{B}}}\mathbb{1}\{ \widehat{c}\left( {\mathbf{x}, b}\right)  = \widehat{c}\left( {\mathbf{x},\varnothing }\right) \} }{\left| \mathcal{B}\right| } \tag{2}
$$

We expect a high confidence prediction to have highly consistent prediction when applying different image perturbations, and therefore to have a high confidence score ${S}_{\mathcal{B}}\left( \mathbf{x}\right)$ with respect to the image perturbation set $B$ .

我们期望高置信度的预测在应用不同图像扰动时具有高度一致的预测，因此相对于图像扰动集合$B$具有较高的置信度得分${S}_{\mathcal{B}}\left( \mathbf{x}\right)$。

Determining the low confidence subset by combining the two confidence estimations. The confidence score we proposed in Eq. (1) and Eq. (2) are continuous values. A threshold needs to be determined if we want to select a subset of examples with low confidence using the continuous confidence score. In practice, the threshold can be chosen based on the requirement of recall and precision trade-off in the real application. In our study, to bypass the threshold selection, we propose to use a binary criterion for determining the low confidence set.

通过结合两种置信度估计确定低置信度子集。我们在公式(1)和公式(2)中提出的置信度得分是连续值。如果想使用连续置信度得分选择低置信度样本子集，则需要确定阈值。在实际应用中，阈值的选择可基于召回率和精确率的权衡需求。在我们的研究中，为了避免阈值选择，我们提出使用二元判据来确定低置信度集合。

For IamgeNet dataset, the CLIP paper [19] designed total 80 context prompts. We define four sets based on the 80 prompts: the first 40 prompts ${\mathcal{T}}_{1}$ , the last 40 prompts ${\mathcal{T}}_{2}$ , all 80 prompts ${\mathcal{T}}_{3}$ , and no prompts ${\mathcal{T}}_{4} = \varnothing$ . We apply the four different sets of prompts to the classifier and see if their top-1 predictions are all consistent or not, i.e. $\widehat{c}\left( {\mathbf{x},{\mathcal{T}}_{1}}\right)  = \widehat{c}\left( {\mathbf{x},{\mathcal{T}}_{2}}\right)  = \widehat{c}\left( {\mathbf{x},{\mathcal{T}}_{3}}\right)  = \widehat{c}\left( {\mathbf{x},{\mathcal{T}}_{4}}\right)$ . Then we determine the low confidence subset ${\mathcal{O}}_{\mathcal{T}}$ as those examples who have inconsistent predictions among the 4 prompts sets. We studied other choices such as using a random set of 40 prompts as ${\mathcal{T}}_{1}$ , or splitting the 80 prompts into more subgroups, and found the results were very similar.

对于ImageNet数据集，CLIP论文[19]设计了共80个上下文提示。我们基于这80个提示定义了四个集合:前40个提示${\mathcal{T}}_{1}$，后40个提示${\mathcal{T}}_{2}$，全部80个提示${\mathcal{T}}_{3}$，以及无提示${\mathcal{T}}_{4} = \varnothing$。我们将这四组不同的提示应用于分类器，观察它们的top-1预测是否全部一致，即$\widehat{c}\left( {\mathbf{x},{\mathcal{T}}_{1}}\right)  = \widehat{c}\left( {\mathbf{x},{\mathcal{T}}_{2}}\right)  = \widehat{c}\left( {\mathbf{x},{\mathcal{T}}_{3}}\right)  = \widehat{c}\left( {\mathbf{x},{\mathcal{T}}_{4}}\right)$。然后我们将预测在这4组提示中不一致的样本确定为低置信度子集${\mathcal{O}}_{\mathcal{T}}$。我们还研究了其他选择，如使用随机40个提示作为${\mathcal{T}}_{1}$，或将80个提示拆分为更多子组，结果非常相似。

Similarly we also determine a low confidence subset ${\mathcal{O}}_{\mathcal{B}}$ based on image perturbations. In practice we found left-right flip works the best among the above mentioned perturbations. Thus for simplicity, we compare the top-1 prediction when applying the left-right flip to the input image and the top-1 prediction when using raw image. If their predictions are not consistent, that example will be included into the low confidence set ${\mathcal{O}}_{\mathcal{B}}$ .

同样，我们也基于图像扰动确定低置信度子集${\mathcal{O}}_{\mathcal{B}}$。在实践中，我们发现上述扰动中左右翻转效果最佳。因此，为简化起见，我们比较对输入图像应用左右翻转时的top-1预测与使用原始图像时的top-1预测。如果两者预测不一致，则该样本将被纳入低置信度集合${\mathcal{O}}_{\mathcal{B}}$。

Algorithm 1: Zero-shot confidence estimation

算法1:零样本置信度估计

---

Input: Input images $\mathcal{X} = {\left\{  {\mathbf{x}}_{i}\right\}  }_{i = 1}^{N}$ , Candidate class set $\mathcal{C}$ ,

输入:输入图像$\mathcal{X} = {\left\{  {\mathbf{x}}_{i}\right\}  }_{i = 1}^{N}$，候选类别集合$\mathcal{C}$，

			image encoder ${f}_{\text{image }}$ and text encoder ${f}_{\text{text }}$ , text

			图像编码器${f}_{\text{image }}$和文本编码器${f}_{\text{text }}$，文本

			threshold ${\tau }_{t}$ , image threshold ${\tau }_{i}$

			阈值${\tau }_{t}$，图像阈值${\tau }_{i}$

Output: Low confidence set $\mathcal{O}$

输出:低置信度集合$\mathcal{O}$

Low confidence set ${\mathcal{O}}_{\mathcal{T}} \leftarrow  \varnothing \; \vartriangleright$ Confidence

低置信度集合${\mathcal{O}}_{\mathcal{T}} \leftarrow  \varnothing \; \vartriangleright$置信度

	estimation via text prompts

	通过文本提示进行估计

Sample $L$ different context prompt ${t}_{1},{t}_{2}\ldots {t}_{L}$

采样$L$个不同上下文提示${t}_{1},{t}_{2}\ldots {t}_{L}$

for ${\mathbf{x}}_{i} \in  \mathcal{X}$ do

对于${\mathbf{x}}_{i} \in  \mathcal{X}$执行

		Compute ${S}_{\mathcal{T}}\left( {\mathbf{x}}_{i}\right)$ based on Eq. (1)

		根据公式(1)计算${S}_{\mathcal{T}}\left( {\mathbf{x}}_{i}\right)$

		if ${S}_{\mathcal{T}}\left( {\mathbf{x}}_{i}\right)  > {\tau }_{t}$ then

		如果${S}_{\mathcal{T}}\left( {\mathbf{x}}_{i}\right)  > {\tau }_{t}$则

				${\mathbf{x}}_{i}$ has high confidence prediction

				${\mathbf{x}}_{i}$具有高置信度预测

		else

		否则

				${\mathcal{O}}_{\mathcal{T}} \leftarrow  {\mathcal{O}}_{\mathcal{T}} \cup  {\mathbf{x}}_{i}$

Low confidence set ${\mathcal{O}}_{\mathcal{B}} \leftarrow  \varnothing \; \vartriangleright$ Confidence

低置信度集合${\mathcal{O}}_{\mathcal{B}} \leftarrow  \varnothing \; \vartriangleright$置信度

	estimation via image perturbation

	通过图像扰动进行估计

7 Sample $M$ perturbation methods ${b}_{1},\ldots ,{b}_{M}$

7种样本$M$扰动方法${b}_{1},\ldots ,{b}_{M}$

for ${\mathbf{x}}_{i} \in  \mathcal{X}$ do

对于${\mathbf{x}}_{i} \in  \mathcal{X}$执行

		Compute ${S}_{\mathcal{B}}\left( {\mathbf{x}}_{i}\right)$ based on Eq. (2)

		根据公式(2)计算${S}_{\mathcal{B}}\left( {\mathbf{x}}_{i}\right)$

		if ${S}_{\mathcal{B}}\left( {\mathbf{x}}_{i}\right)  > {\tau }_{i}$ then

		如果${S}_{\mathcal{B}}\left( {\mathbf{x}}_{i}\right)  > {\tau }_{i}$则

				${\mathbf{x}}_{i}$ has high confidence prediction

				${\mathbf{x}}_{i}$具有高置信度预测

		else

		否则

				${\mathcal{O}}_{\mathcal{B}} \leftarrow  {\mathcal{O}}_{\mathcal{B}} \cup  {\mathbf{x}}_{i}$

$\mathcal{O} \leftarrow  {\mathcal{O}}_{\mathcal{T}} \cup  {\mathcal{O}}_{\mathcal{B}}$

---

Finally, we use the union of the two low confidence sets ${\mathcal{O}}_{\mathcal{T}}$ identified using the text prompts and and ${\mathcal{O}}_{\mathcal{B}}$ identified using the image perturbations as the final low confidence subset $\mathcal{O}$ in the following experiments. Algorithm 1 shows the low confidence set generation process.

最后，我们将通过文本提示识别的两个低置信度集合${\mathcal{O}}_{\mathcal{T}}$与通过图像扰动识别的${\mathcal{O}}_{\mathcal{B}}$的并集作为以下实验中的最终低置信度子集$\mathcal{O}$。算法1展示了低置信度集合的生成过程。

### 4.2. Top-down and bottom-up label augmentation using WordNet hierarchy

### 4.2. 利用WordNet层级结构进行自上而下和自下而上的标签增强

Through extensive analysis of the incorrect predictions among the identified unreliable predictions, we found that many of them are caused by CLIP's lack of robustness to prompts. Instead of tuning the prompt templates, we focus on how to augment \{label\} in "A photo of a \{label\}". A proper prompt that specifies both the generic type and the more specific sub-types of this class are very important for correctly classifying the image. However, the ImageNet [4] class names are not all defined with similar specificity and some classes are more abstract than others, e.g. 350 classes have children, while the rest of the classes have no children. See Suppl. Fig. 1 for more details. To make the ImageNet classification problem better suited to CLIP, we leverage the underlying WordNet hierarchy and develop a top-down and bottom-up class name augmentation method to improve zero-shot prediction accuracy for unreliable predictions.

通过对识别出的不可靠预测中的错误预测进行广泛分析，我们发现许多错误是由于CLIP对提示词缺乏鲁棒性所致。我们不调整提示模板，而是专注于如何增强“A photo of a \{label\}”中的\{label\}。一个恰当的提示，既指定该类别的通用类型，又包含更具体的子类型，对于正确分类图像非常重要。然而，ImageNet [4]的类别名称并非都具有相似的具体性，有些类别较为抽象，例如350个类别有子类，而其余类别没有子类。详见补充图1。为了使ImageNet分类问题更适合CLIP，我们利用底层的WordNet层级结构，开发了一种自上而下和自下而上的类别名称增强方法，以提高对不可靠预测的零样本预测准确率。

The WordNet hierarchy is a semantic concept ontology, with nodes being cognitive synonyms indicating different concepts, and edges indicating the super-subordinate relation between concepts. Traveling upward from leaf nodes to the root, the concepts start from the very specific to the generic. For example, starting from the edge node "strawberry" to the root are "berry", "edible fruit", "produce", "food", "solid", "matter", and "physical entity" (the root). As we have seen in the failure mode analysis, many of the imageNet class names suffer from either being too abstract or being too specific, so that their concepts do not align well with the visual concepts the CLIP model learned in training. We propose using the WordNet knowledge hierarchy to augment the class labels in prompts so that the CLIP model has a better match between the image and prompts.

WordNet层级结构是一种语义概念本体，节点为认知同义词，表示不同概念，边表示概念间的上下级关系。从叶节点向根节点遍历，概念由具体到通用。例如，从叶节点“strawberry”(草莓)到根节点依次为“berry”(浆果)、“edible fruit”(可食用水果)、“produce”(农产品)、“food”(食物)、“solid”(固体)、“matter”(物质)和“physical entity”(物理实体，根节点)。正如我们在失败模式分析中看到的，许多ImageNet类别名称要么过于抽象，要么过于具体，导致其概念与CLIP模型训练中学习的视觉概念不匹配。我们提出利用WordNet知识层级增强提示中的类别标签，使CLIP模型在图像与提示之间实现更好的匹配。

Top-down: augmenting class names with parent. As shown in failure case analysis, adding the super-class name to reduce ambiguity and to encourage the model's attention on the generic concept is helpful for improving the accuracy. Therefore we propose using WordNet to find the parent node of the raw class name, and concatenate it to the class name, i.e. $\operatorname{logit}\left( {\mathbf{x}, c}\right)  = \operatorname{logit}\left( {\mathbf{x},\left\lbrack  {c;p\left( c\right) }\right\rbrack  }\right)$ where $p\left( c\right)$ is the parent node’s name of the class name $c$ , and $\left\lbrack  {c;p\left( c\right) }\right\rbrack$ means the string concatenation of the class name and the parent name. We apply the method to top-5 predicted classes. Using the newly defined class names, we are able to re-rank the top-5 predictions for the identified unreliable subset of images. Note that WordNet contains a few very abstract class names for nodes, such as "physical entity", "artifact", "matter", etc. We found that such parent nodes are not informative, hence we remove them. There are also many academic words in WordNet, for example the parent node of sea anemone is "anthozoan", which can be rare in CLIP training data. Adding those academic words to class name makes the prediction even less robust. So we simplify the WordNet by pruning based on an estimation of the word frequency in CLIP training data by using embedding norm.

自顶向下:用父类名增强类别名称。如失败案例分析所示，添加超类名称以减少歧义并引导模型关注通用概念，有助于提高准确率。因此我们提出使用WordNet查找原始类别名称的父节点，并将其与类别名称连接，即$\operatorname{logit}\left( {\mathbf{x}, c}\right)  = \operatorname{logit}\left( {\mathbf{x},\left\lbrack  {c;p\left( c\right) }\right\rbrack  }\right)$，其中$p\left( c\right)$是类别名称$c$的父节点名称，$\left\lbrack  {c;p\left( c\right) }\right\rbrack$表示类别名称与父节点名称的字符串连接。我们将该方法应用于前五个预测类别。使用新定义的类别名称，我们能够对识别出的不可靠图像子集的前五个预测结果重新排序。注意，WordNet中包含一些非常抽象的类别名称节点，如“physical entity”(物理实体)、“artifact”(人工制品)、“matter”(物质)等。我们发现这些父节点信息量不足，因此将其移除。WordNet中还有许多学术词汇，例如海葵的父节点是“anthozoan”(珊瑚虫纲)，这在CLIP训练数据中较为罕见。将这些学术词汇加入类别名称反而降低了预测的鲁棒性。因此我们通过基于CLIP训练数据中词频的估计(使用嵌入范数)对WordNet进行简化修剪。

Bottom-up: augmenting class names with children. Some ImageNet class names are generally abstract, but the ImageNet images may belong to a specific subtype of the class. For example, "balloon" is a class name in ImageNet, but most balloon images in ImageNet are actually "hot-air balloon", which is a child of "balloon" in WordNet hierarchy. The logit score for a parent class is not necessarily higher than the score for its child classes, mismatching with hierarchy prior. To accurately classify the images using CLIP, we need to augment the class name with fine-grained child subclasses. For each class $c$ having children in the WordNet hierarchy, we redefine the logit score as the max score over itself and all its children, i.e., $\operatorname{logit}\left( {\mathbf{x}, c}\right)  =$ $\max \left\{  {\operatorname{logit}\left( {\mathbf{x}, c}\right) ,\operatorname{logit}\left( {\mathbf{x},{c}_{1}}\right) ,\ldots ,\operatorname{logit}\left( {\mathbf{x},{c}_{r}}\right) }\right\}  ,\;$ where ${c}_{1}\ldots {c}_{r}$ are the $r$ children of the node $c$ in the WordNet hierarchy. We apply this bottom-up method to top-5 predicted class names, and re-rank the top predictions.

自底向上:用子类名增强类别名称。部分ImageNet类别名称较为抽象，但ImageNet中的图像可能属于该类别的特定子类型。例如，“balloon”(气球)是ImageNet中的一个类别名称，但大多数气球图像实际上是“hot-air balloon”(热气球)，它是WordNet层级中“balloon”的子类。父类的logit分数不一定高于其子类分数，这与层级先验不符。为了准确使用CLIP对图像分类，我们需要用细粒度的子类增强类别名称。对于WordNet层级中具有子类的每个类别$c$，我们将logit分数重新定义为自身及所有子类中的最大分数，即$\operatorname{logit}\left( {\mathbf{x}, c}\right)  =$ $\max \left\{  {\operatorname{logit}\left( {\mathbf{x}, c}\right) ,\operatorname{logit}\left( {\mathbf{x},{c}_{1}}\right) ,\ldots ,\operatorname{logit}\left( {\mathbf{x},{c}_{r}}\right) }\right\}  ,\;$，其中${c}_{1}\ldots {c}_{r}$是WordNet层级中节点$c$的$r$个子类。我们将此自底向上方法应用于前五个预测类别，并重新排序预测结果。

Algorithm 2: Top-down and bottom-up class label augmentation using WordNet hierarchy

算法2:基于WordNet层级的自顶向下和自底向上类别标签增强

---

Input: Input image $\mathbf{x} \in  \mathcal{O}$ , top-5 candidate class set

输入:输入图像$\mathbf{x} \in  \mathcal{O}$，前五候选类别集合

				${\mathcal{C}}_{\text{top 5 }}$ , sparse WordNet hierarchy $H$ , image

				${\mathcal{C}}_{\text{top 5 }}$，稀疏WordNet层级$H$，图像

				encoder ${f}_{\text{image }}$ and text encoder ${f}_{\text{text }}$

				编码器${f}_{\text{image }}$和文本编码器${f}_{\text{text }}$

Output: Predicted class of $\mathbf{x}$

输出:$\mathbf{x}$的预测类别

Candidate class set $\mathcal{C} \leftarrow  \varnothing$

候选类别集合$\mathcal{C} \leftarrow  \varnothing$

for $c \in  {\mathcal{C}}_{top5}$ do

对于$c \in  {\mathcal{C}}_{top5}$执行

		$\mathcal{C} \leftarrow  \mathcal{C} \cup  \left\lbrack  {c;\operatorname{parent}\left( c\right) }\right\rbrack$ , where parent(c)is the parent

		$\mathcal{C} \leftarrow  \mathcal{C} \cup  \left\lbrack  {c;\operatorname{parent}\left( c\right) }\right\rbrack$，其中parent(c)是父节点

			of $c$ in $H\;$ DTop-down

			在$H\;$中的$c$自顶向下

		if $c$ has $r \geq  1$ children ${c}_{1}\ldots {c}_{r}$ in $H$ then

		如果$c$在$H$中有$r \geq  1$个子类${c}_{1}\ldots {c}_{r}$，则

				$\mathcal{C} \leftarrow  \mathcal{C} \cup  {\left\{  \left\lbrack  {c}_{j};\operatorname{parent}\left( c\right) \right\rbrack  \right\}  }_{j = 1}^{r}\; \vartriangleright$ Bottom-up

				$\mathcal{C} \leftarrow  \mathcal{C} \cup  {\left\{  \left\lbrack  {c}_{j};\operatorname{parent}\left( c\right) \right\rbrack  \right\}  }_{j = 1}^{r}\; \vartriangleright$ 自底向上

$\widehat{c} \leftarrow  \arg \mathop{\max }\limits_{{c \in  \mathcal{C}}}\operatorname{logit}\left( {\mathbf{x}, c}\right)$

if $\widehat{c} \in  {\mathcal{C}}_{top5}$ then

如果 $\widehat{c} \in  {\mathcal{C}}_{top5}$ 则

		final prediction $\leftarrow  \widehat{c}$

		最终预测 $\leftarrow  \widehat{c}$

else

否则

		final prediction $\leftarrow$ parent $\left( \widehat{c}\right)$

		最终预测 $\leftarrow$ 父类 $\left( \widehat{c}\right)$

---

Combining Top-down and bottom-up. In practice, we use both children and the ancestor(parent) to augment each class $c$ , to transfer semantic information bidirectionally in both top-down and bottom-up way: the ancestor(parent) class is more generic than $c$ , and has better chance to disambiguate instance from a more abstract level; on the other hand, children categories have more specific attribute description, and the attribute descriptions are semantically meaningful representations bridging the gap between the image embedding and its abstract class concept $c$ . Then the final logit score between $x$ and $c$ is:

结合自顶向下和自底向上。在实际操作中，我们同时利用子类和祖先(父类)来增强每个类别 $c$ ，以双向传递语义信息，既有自顶向下也有自底向上的方式:祖先(父类)类别比 $c$ 更通用，更有可能从更抽象的层面消除实例歧义；另一方面，子类别具有更具体的属性描述，这些属性描述是语义上有意义的表示，桥接了图像嵌入与其抽象类别概念 $c$ 之间的差距。然后 $x$ 和 $c$ 之间的最终logit分数为:

$$
\operatorname{logit}\left( {\mathbf{x}, c}\right)  = \max \{ \operatorname{logit}\left( {\mathbf{x},\left\lbrack  {c;p\left( c\right) }\right\rbrack  }\right) ,
$$

$$
\operatorname{logit}\left( {\mathbf{x},\left\lbrack  {{c}_{1};p\left( c\right) }\right\rbrack  }\right) ,\ldots ,\operatorname{logit}\left( {\mathbf{x},\left\lbrack  {{c}_{r};p\left( c\right) }\right\rbrack  }\right) \}  \tag{3}
$$

where $p\left( c\right)$ is parent of $c$ , and ${c}_{1}\ldots {c}_{r}$ are $c$ ’s children. The $\widehat{c}$ , where $\widehat{c} \in  {\mathcal{C}}_{\text{top5 }}$ , with the maximal logit score is the predicted class of $\mathbf{x}$ . See Algorithm 2 for details.

其中 $p\left( c\right)$ 是 $c$ 的父类，${c}_{1}\ldots {c}_{r}$ 是 $c$ 的子类。$\widehat{c}$ ，其中 $\widehat{c} \in  {\mathcal{C}}_{\text{top5 }}$ ，具有最大logit分数的是 $\mathbf{x}$ 的预测类别。详情见算法2。

## 5. Experiments and Results

## 5. 实验与结果

Our proposed method is composed of two steps and we conduct experiments to verify the effectiveness of each step: (1) Use zero-shot confidence estimation to identify the low confidence subset of samples (see Fig. 3 for the results), and (2) Augment the class label using top-down and bottom-up strategies based on the sparsified WordNet on the low confidence subset to improve the accuracy (See Table 1 and Table 2 for the results).

我们提出的方法由两步组成，并通过实验验证每一步的有效性:(1)使用零样本置信度估计识别低置信度样本子集(结果见图3)，(2)基于稀疏化的WordNet，在低置信度子集上利用自顶向下和自底向上策略增强类别标签以提升准确率(结果见表1和表2)。

#### 5.1.Our proposed confidence score is better suited for selective prediction than baselines

#### 5.1. 我们提出的置信度评分比基线更适合选择性预测

A well-calibrated confidence estimator should score high for those correct predictions, and low for incorrect predictions. As a result, a good confidence estimator should be a good predictor for prediction correctness. We plot the receiver operating characteristic (ROC) curve and compute the area under the ROC curve (AUC) as a quantitative measure to compare our proposed confidence estimation with the baselines. An AUROC of 1.0 indicates perfect separation between correct and incorrect predictions, and 0.5 means the two groups are not distinguishable. Maximum logit score, $\mathop{\max }\limits_{{c \in  \mathcal{C}}}\operatorname{logit}\left( {\mathbf{x}, c}\right)$ is one of the most commonly used confidence score for classification problems in single modal models [8], so we consider it as our baseline. Fig. $3\mathrm{a}$ and $3\mathrm{c}$ clearly show that our confidence score is significantly better than the baseline method at distinguishing between correct and incorrect predictions, for both CLIP and LiT models. The AUC score for our proposed method is above 0.8 while that for the baseline method is around 0.7 .

一个良好校准的置信度估计器应对正确预测给出高分，对错误预测给出低分。因此，一个好的置信度估计器应能很好地预测预测的正确性。我们绘制了受试者工作特征(ROC)曲线，并计算ROC曲线下面积(AUC)作为定量指标，比较我们提出的置信度估计与基线方法。AUROC为1.0表示正确与错误预测完全区分，0.5表示两组不可区分。最大logit分数 $\mathop{\max }\limits_{{c \in  \mathcal{C}}}\operatorname{logit}\left( {\mathbf{x}, c}\right)$ 是单模态模型分类问题中最常用的置信度评分之一[8]，因此我们将其作为基线。图 $3\mathrm{a}$ 和 $3\mathrm{c}$ 清晰显示，我们的置信度评分在区分正确与错误预测方面显著优于基线方法，适用于CLIP和LiT模型。我们方法的AUC得分超过0.8，而基线方法约为0.7。

We also compare our method with the baseline in the scenario of selective prediction. Given a budget of abstention rate $\alpha \%$ , the best strategy is to abstain the $\alpha \%$ samples with the lowest confidence scores. If the confidence score is well calibrated, the accuracy for the abstained set will be low and as an evidence the accuracy of the remaining set would be high. We plot the selective prediction curves [14], which reports the accuracy on the remaining set as a function of the abstention rate. Fig. 3b and 3d show that our proposed confidence score results in higher accuracy than the baseline maximum logit score at all abstention rates for both CLIP and LiT.

我们还在选择性预测场景下与基线方法进行了比较。给定一个弃权率预算 $\alpha \%$ ，最佳策略是弃权置信度最低的 $\alpha \%$ 个样本。如果置信度评分校准良好，弃权样本的准确率将较低，作为证据，剩余样本的准确率将较高。我们绘制了选择性预测曲线[14]，报告剩余样本的准确率随弃权率的变化。图3b和3d显示，在所有弃权率下，我们提出的置信度评分在CLIP和LiT模型中均比基线最大logit分数获得更高准确率。

Prompt ensemble has been shown to improve accuracy and robustness of the prediction, so here we also compare ours with the maximum logit score after applying prompt ensemble. As shown in the selective prediction curves, although the prompt ensemble indeed helps to achieve higher accuracy (dashed line) than that using the pure class name (solid line), it is still inferior to our proposed method.

提示词集成已被证明能提升预测的准确率和鲁棒性，因此我们也将其与应用提示词集成后的最大logit分数进行了比较。如选择性预测曲线所示，虽然提示词集成确实帮助实现了比纯类别名称(实线)更高的准确率(虚线)，但仍不及我们提出的方法。

### 5.2. Using hierarchy to help improve zero-shot ac- curacy on low confidence subset

### 5.2. 利用层级结构提升低置信度子集的零样本准确率

Using top-down and bottom-up label augmentation significantly improves the accuracy on the low confidence subset. We apply the top-down and bottom-up label augmentation on the low confidence subset: to better combine child and parent name, we create a prompt template to transform the child and parent name pairs into a new class name $\widetilde{c}$ in natural language: "\{child\} which is a kind of \{parent\}" (different prompt templates may have different results). Table 1 shows improvement of 17.13% on the top- 1 accuracy (from 21.58% to 38.71%) for the identified low confidence subset of samples, and overall ${3.6}\%$ on the top-1 accuracy (64.18% to 67.78%) for all samples in ImageNet. We show similar improvement on the zero-shot accuracy for ImageNet shifted datasets. To investigate if our method works for other multi-modal models, we apply it to the LiT [28] model and observe that our method improves accuracy for LiT models as well. See Supp. Fig. 2 for qualitative visualization.

采用自顶向下和自底向上的标签增强显著提升了低置信度子集的准确率。我们在低置信度子集上应用自顶向下和自底向上的标签增强:为了更好地结合子类和父类名称，我们创建了一个提示模板，将子类和父类名称对转换为自然语言中的新类别名称$\widetilde{c}$:“\{child\}，它是一种\{parent\}”(不同的提示模板可能产生不同的结果)。表1显示，在识别出的低置信度样本子集上，top-1准确率提升了17.13%(从21.58%提升至38.71%)，而在ImageNet所有样本上的整体top-1准确率提升了${3.6}\%$(从64.18%提升至67.78%)。我们在ImageNet迁移数据集的零样本准确率上也观察到了类似的提升。为探究该方法是否适用于其他多模态模型，我们将其应用于LiT [28]模型，结果表明该方法同样提升了LiT模型的准确率。详见补充材料图2的定性可视化。

![bo_d1mk7nn7aajc73dikm2g_6_382_208_970_660_0.jpg](images/bo_d1mk7nn7aajc73dikm2g_6_382_208_970_660_0.jpg)

Figure 3. ROC plots (left column) show that our proposed confidence score is better at distinguishing correct and incorrect predictions and results in higher AUC scores than baselines for both CLIP (ViT-B/16) (a) and LiT (ViT-B/32)(c). Selective prediction curves (right column) show that our proposed confidence score is better at abstaining incorrect predictions and as a result the accuracy of the remaining set is higher than the baselines for both CLIP (ViT-B/16) (b) and LiT (ViT-B/32) (d).

图3。ROC曲线(左列)显示，我们提出的置信度评分在区分正确与错误预测方面优于基线方法，并且在CLIP(ViT-B/16)(a)和LiT(ViT-B/32)(c)两者中均获得了更高的AUC分数。选择性预测曲线(右列)表明，我们提出的置信度评分在放弃错误预测方面表现更佳，因此剩余样本集的准确率高于基线方法，适用于CLIP(ViT-B/16)(b)和LiT(ViT-B/32)(d)。

Table 1. CLIP (ViT-B/16) and LiT (ViT-B/32) zero-shot top-1 accuracy comparison between baseline and ours (w/ hierarchy).

表1。CLIP(ViT-B/16)和LiT(ViT-B/32)零样本top-1准确率的基线与我们方法(含层级结构)比较。

<table><tr><td colspan="2"/><td>CLIP</td><td>(Ours) Hierarchy-CLIP</td><td>LiT</td><td>(Ours) Hierarchy-LiT</td></tr><tr><td rowspan="2">ImageNet [4]</td><td>Low conf. set</td><td>21.58%</td><td>$\mathbf{{38.71}\% }$</td><td>31.18%</td><td>37.25%</td></tr><tr><td>Full set</td><td>64.18%</td><td>67.78%</td><td>68.26%</td><td>69.41%</td></tr><tr><td rowspan="2">ImageNet-v2 [21]</td><td>Low conf. set</td><td>17.77%</td><td>32.50 %</td><td>27.08%</td><td>31.45%</td></tr><tr><td>Full set</td><td>58.06%</td><td>61.07%</td><td>60.11%</td><td>61.11%</td></tr><tr><td rowspan="2">ImageNet-R [9]</td><td>Low conf. set</td><td>16.79%</td><td>$\mathbf{{27.91}\% }$</td><td>21.82%</td><td>$\mathbf{{22.93}\% }$</td></tr><tr><td>Full set</td><td>56.88%</td><td>59.46%</td><td>66.54%</td><td>66.75%</td></tr><tr><td rowspan="2">ImageNet-Adversarial [11]</td><td>Low conf. set</td><td>10.13%</td><td>$\mathbf{{18.44}\% }$</td><td>7.19%</td><td>$\mathbf{{8.95}\% }$</td></tr><tr><td>Full set</td><td>26.12%</td><td>$\mathbf{{29.23}\% }$</td><td>13.93%</td><td>14.56%</td></tr><tr><td rowspan="2">ImageNet-Sketch [25]</td><td>Low conf set</td><td>13.74%</td><td>$\mathbf{{23.18}\% }$</td><td>21.51%</td><td>24.42%</td></tr><tr><td>Full set</td><td>44.71%</td><td>47.28%</td><td>52.47%</td><td>53.17 %</td></tr></table>

<table><tbody><tr><td colspan="2"></td><td>CLIP</td><td>(本方法)Hierarchy-CLIP</td><td>LiT</td><td>(本方法)Hierarchy-LiT</td></tr><tr><td rowspan="2">ImageNet [4]</td><td>低置信度集</td><td>21.58%</td><td>$\mathbf{{38.71}\% }$</td><td>31.18%</td><td>37.25%</td></tr><tr><td>完整数据集</td><td>64.18%</td><td>67.78%</td><td>68.26%</td><td>69.41%</td></tr><tr><td rowspan="2">ImageNet-v2 [21]</td><td>低置信度集</td><td>17.77%</td><td>32.50 %</td><td>27.08%</td><td>31.45%</td></tr><tr><td>完整数据集</td><td>58.06%</td><td>61.07%</td><td>60.11%</td><td>61.11%</td></tr><tr><td rowspan="2">ImageNet-R [9]</td><td>低置信度集</td><td>16.79%</td><td>$\mathbf{{27.91}\% }$</td><td>21.82%</td><td>$\mathbf{{22.93}\% }$</td></tr><tr><td>完整数据集</td><td>56.88%</td><td>59.46%</td><td>66.54%</td><td>66.75%</td></tr><tr><td rowspan="2">ImageNet-对抗集 [11]</td><td>低置信度集</td><td>10.13%</td><td>$\mathbf{{18.44}\% }$</td><td>7.19%</td><td>$\mathbf{{8.95}\% }$</td></tr><tr><td>完整数据集</td><td>26.12%</td><td>$\mathbf{{29.23}\% }$</td><td>13.93%</td><td>14.56%</td></tr><tr><td rowspan="2">ImageNet-素描集 [25]</td><td>低置信度集</td><td>13.74%</td><td>$\mathbf{{23.18}\% }$</td><td>21.51%</td><td>24.42%</td></tr><tr><td>完整数据集</td><td>44.71%</td><td>47.28%</td><td>52.47%</td><td>53.17 %</td></tr></tbody></table>

Generalizability to non-ImageNet datasets To show the generalizability of our methods on non-ImageNet datasets, We conducted experiments on 4 additional datasets: Caltech-101 [15] (101 categories), Flower-102 [17] (102 flower categories), Food-101 [2] (101 food categories) and Cifar-100 [13] (100 categories). For each dataset, a subset of their categories are exist/aligned with WordNet hierarchy, we only apply our method on those WordNet aligned class names, where we could find their ancestor and children. We keep the other class names unmodified. We use CLIP (ViT-B/16) as multi-modal model. Table 2 shows that our method consistently improved accuracy on the low-confidence set (low) and the entire set (full):

对非ImageNet数据集的泛化能力 为了展示我们方法在非ImageNet数据集上的泛化能力，我们在另外4个数据集上进行了实验:Caltech-101 [15](101个类别)、Flower-102 [17](102种花卉类别)、Food-101 [2](101种食物类别)和Cifar-100 [13](100个类别)。对于每个数据集，其部分类别存在于或与WordNet层级结构对齐，我们仅对这些与WordNet对齐的类别名称应用我们的方法，在这些类别中我们能够找到其祖先和子类。其他类别名称保持不变。我们使用CLIP(ViT-B/16)作为多模态模型。表2显示，我们的方法在低置信度集合(low)和整个集合(full)上的准确率均有持续提升:

Table 2. Generalizability to non-ImageNet datasets (CLIP (ViT-B/16) zero-shot top-1 accuracy).

表2. 对非ImageNet数据集的泛化能力(CLIP(ViT-B/16)零样本top-1准确率)。

<table><tr><td>Dataset</td><td>orig (low)</td><td>ours (low)</td><td>orig (full)</td><td>ours (full)</td></tr><tr><td>Caltech-101 [15]</td><td>10.6 %</td><td>27.2% (+16.6%)</td><td>74.1%</td><td>77.1% (+3.0%)</td></tr><tr><td>Flower102 [17]</td><td>20.0%</td><td>29.4% (+9.4%)</td><td>63.7%</td><td>65.3% (+1.6%)</td></tr><tr><td>Food-101 [2]</td><td>28.2%</td><td>49.0% (+20.8%)</td><td>84.7%</td><td>86.8% (+2.1%)</td></tr><tr><td>Cifar-100 [13]</td><td>9.4%</td><td>17.5% (+8.1%)</td><td>31.8%</td><td>35.2% (+3.4%)</td></tr></table>

<table><tbody><tr><td>数据集</td><td>原始(低)</td><td>我们的(低)</td><td>原始(完整)</td><td>我们的(完整)</td></tr><tr><td>Caltech-101 [15]</td><td>10.6 %</td><td>27.2% (+16.6%)</td><td>74.1%</td><td>77.1% (+3.0%)</td></tr><tr><td>Flower102 [17]</td><td>20.0%</td><td>29.4% (+9.4%)</td><td>63.7%</td><td>65.3% (+1.6%)</td></tr><tr><td>Food-101 [2]</td><td>28.2%</td><td>49.0% (+20.8%)</td><td>84.7%</td><td>86.8% (+2.1%)</td></tr><tr><td>Cifar-100 [13]</td><td>9.4%</td><td>17.5% (+8.1%)</td><td>31.8%</td><td>35.2% (+3.4%)</td></tr></tbody></table>

### 5.3. Ablation study

### 5.3. 消融研究

Generalizability to other backbones To study the generalization of our method to different model architectures and sizes, we used 4 additional backbones of CLIP, including convolutional neural network (CNN) based backbones (ResNet-50, ResNet-101) and vision transformer (ViT) based backbones (ViT-B/32, ViT-B/16 and ViT-l/14). Table 3 shows the improved accuracy after using our method on ImageNet with CLIP models of different backbones. Our method achieves consistently improved accuracies.

对其他骨干网络的泛化能力 为了研究我们方法对不同模型架构和规模的泛化能力，我们使用了CLIP的4个额外骨干网络，包括基于卷积神经网络(CNN)的骨干网络(ResNet-50，ResNet-101)和基于视觉变换器(ViT，Vision Transformer)的骨干网络(ViT-B/32，ViT-B/16和ViT-l/14)。表3展示了在使用不同骨干网络的CLIP模型在ImageNet上应用我们方法后准确率的提升。我们的方法在准确率上均表现出持续的提升。

Table 3. Generalizability to different backbones with CLIP.

表3. 使用CLIP的不同骨干网络的泛化能力。

<table><tr><td>backbone</td><td>ResNet-50</td><td>ResNet-101</td><td>ViT-B/32</td><td>ViT-B/16</td><td>ViT-1/14</td></tr><tr><td>ACC (low)</td><td>+14.25%</td><td>+12.97%</td><td>+15.12%</td><td>+ 17.13%</td><td>+18.89%</td></tr><tr><td>ACC (full)</td><td>+3.73%</td><td>+3.71%</td><td>+3.65%</td><td>+ 3.60%</td><td>+3.23%</td></tr></table>

<table><tbody><tr><td>主干网络</td><td>ResNet-50</td><td>ResNet-101</td><td>ViT-B/32</td><td>ViT-B/16</td><td>ViT-1/14</td></tr><tr><td>准确率(低)</td><td>+14.25%</td><td>+12.97%</td><td>+15.12%</td><td>+ 17.13%</td><td>+18.89%</td></tr><tr><td>准确率(全)</td><td>+3.73%</td><td>+3.71%</td><td>+3.65%</td><td>+ 3.60%</td><td>+3.23%</td></tr></tbody></table>

Table 4. CLIP (ViT-B-16) zero-shot top-1 accuracy comparison with prompt ensemble.

表4. CLIP (ViT-B-16) 零样本top-1准确率与提示集成的比较。

<table><tr><td/><td/><td>Ensemble only</td><td>Hierarchy and Ensemble</td></tr><tr><td rowspan="2">ImageNet [21]</td><td>Low conf. set</td><td>41.05%</td><td>$\mathbf{{42.09}\% }$</td></tr><tr><td>Full set</td><td>68.48%</td><td>68.86%</td></tr><tr><td rowspan="2">ImageNet-v2 [21]</td><td>Low conf. set</td><td>$\mathbf{{36.39}\% }$</td><td>36.34%</td></tr><tr><td>Full set</td><td>62.02%</td><td>62.00%</td></tr><tr><td rowspan="2">ImageNet-R [9]</td><td>Low conf. set</td><td>35.13%</td><td>$\mathbf{{36.12}\% }$</td></tr><tr><td>Full set</td><td>60.21%</td><td>60.62%</td></tr><tr><td rowspan="2">ImageNet-Adversarial [11]</td><td>Low conf. set</td><td>21.13%</td><td>$\mathbf{{22.00}\% }$</td></tr><tr><td>Full set</td><td>30.59%</td><td>31.07%</td></tr><tr><td rowspan="2">ImageNet-Sketch [25]</td><td>Low conf. set</td><td>$\mathbf{{27.13}\% }$</td><td>26.56%</td></tr><tr><td>Full set</td><td>$\mathbf{{48.52}\% }$</td><td>48.26%</td></tr></table>

<table><tbody><tr><td></td><td></td><td>仅集成</td><td>层级与集成</td></tr><tr><td rowspan="2">ImageNet [21]</td><td>低置信度集</td><td>41.05%</td><td>$\mathbf{{42.09}\% }$</td></tr><tr><td>完整集</td><td>68.48%</td><td>68.86%</td></tr><tr><td rowspan="2">ImageNet-v2 [21]</td><td>低置信度集</td><td>$\mathbf{{36.39}\% }$</td><td>36.34%</td></tr><tr><td>完整集</td><td>62.02%</td><td>62.00%</td></tr><tr><td rowspan="2">ImageNet-R [9]</td><td>低置信度集</td><td>35.13%</td><td>$\mathbf{{36.12}\% }$</td></tr><tr><td>完整集</td><td>60.21%</td><td>60.62%</td></tr><tr><td rowspan="2">ImageNet-对抗集 [11]</td><td>低置信度集</td><td>21.13%</td><td>$\mathbf{{22.00}\% }$</td></tr><tr><td>完整集</td><td>30.59%</td><td>31.07%</td></tr><tr><td rowspan="2">ImageNet-素描集 [25]</td><td>低置信度集</td><td>$\mathbf{{27.13}\% }$</td><td>26.56%</td></tr><tr><td>完整集</td><td>$\mathbf{{48.52}\% }$</td><td>48.26%</td></tr></tbody></table>

Our hierarchy-based label augmentation is complimentary to prompt ensembling. Prompt ensembling (PE) [19] requires a set of manually crafted prompt templates, and the zero-shot performance is sensitive to the set of prompts the model uses. Alternatively, our proposed method does not require a dedicated tuning of the prompt templates. We directly augment the class name with knowledge of the hierarchy from WordNet. In addition, PE is computationally intensive because it needs to infer the em-beddings of 80 prompt templates where each is applied with 1000 ImageNet classes, while our method only need to infer once for each of the predicted top-5 labels. Our method is more straightforward and interpretable given that it clearly shows the contribution of parent/child in the decision. Intuitively, PE is typically focused on fixing \{class\} and augmenting contextual templates, while our method augments the $\{$ class $\}$ with a fixed contextual template. To verify if our hierarchy-based method is complimentary with prompt en-sembling, we apply prompt ensembling after applying our top-down and bottom-up label augmentation. For the low confidence set, we first create a prompt template to transform the child and parent name pairs into a new class name $\widetilde{c}$ in natural language: "\{child\} which is a kind of \{parent\}". Then we apply the 80 prompts designed by the CLIP paper [19] individually to the new class name $\widetilde{c}$ , and then ensemble them. For the high confidence set, since we do not modify the class name using hierarchy information, we only apply the prompt ensemble. The performance is shown in Table 4. We compare the zero-shot accuracy using the vanilla prompt ensembling method proposed in CLIP, and the zero-shot accuracy using our combined version of hierarchy-based class name augmentation and prompt en-sembling. As shown in the table, using both hierarchy and prompt ensembling achieves better or on par accuracy with the prompt ensemble alone, suggesting that the two methods can be combined. Considering the prompt ensemble requires manually designed prompt templates and much greater inference time, our hierarchy-based class name augmentation is simple, efficient and effective. We also computed IoU of corrected low-confidence instances (low set) between PE and our method: the IoU is 0.55 , which implies the two methods are complementary for fixing errors.

我们基于层级的标签增强方法与提示集成(prompt ensembling)是互补的。提示集成(PE)[19] 需要一组手工设计的提示模板，且零样本性能对模型使用的提示集敏感。相比之下，我们提出的方法不需要专门调整提示模板，而是直接利用WordNet的层级知识增强类别名称。此外，PE计算量大，因为它需要对80个提示模板分别推断，每个模板应用于1000个ImageNet类别，而我们的方法只需对预测的前5个标签各推断一次。我们的方法更直接且易于解释，因为它清晰展示了父类/子类在决策中的贡献。直观来看，PE通常专注于固定\{class\}并增强上下文模板，而我们的方法则是在固定上下文模板的基础上增强$\{$类别$\}$。为了验证我们的层级方法是否与提示集成互补，我们在应用自顶向下和自底向上的标签增强后，再应用提示集成。对于低置信度集合，首先创建一个提示模板，将子类和父类名称对转换为自然语言的新类别名称$\widetilde{c}$:“\{child\}，它是一种\{parent\}”。然后对新类别名称$\widetilde{c}$分别应用CLIP论文[19]设计的80个提示，最后进行集成。对于高置信度集合，由于未使用层级信息修改类别名称，仅应用提示集成。性能见表4。我们比较了CLIP中提出的原始提示集成方法的零样本准确率与结合层级类别名称增强和提示集成的零样本准确率。表中显示，结合层级和提示集成的方法在准确率上优于或不低于单独提示集成，表明两者可以结合使用。考虑到提示集成需要手工设计提示模板且推断时间更长，我们的基于层级的类别名称增强方法简单、高效且有效。我们还计算了PE与我们方法在纠正低置信度实例(低集合)上的交并比(IoU)，为0.55，表明两种方法在纠错上具有互补性。

Table 5. Effect of threshold of confidence score on zero-shot accuracy.

表5. 置信度阈值对零样本准确率的影响。

<table><tr><td>Threshold</td><td>Low conf. set size</td><td>Acc on low conf. set</td><td>Acc on full set</td></tr><tr><td>0.47</td><td>10000</td><td>19.40%</td><td>68.72%</td></tr><tr><td>0.52</td><td>11000</td><td>20.82%</td><td>68.78%</td></tr><tr><td>0.57</td><td>12000</td><td>22.06%</td><td>68.82%</td></tr><tr><td>0.62</td><td>13000</td><td>23.58%</td><td>68.85%</td></tr><tr><td>0.66</td><td>14000</td><td>25.01%</td><td>68.88%</td></tr><tr><td>0.70</td><td>15000</td><td>26.51%</td><td>68.86%</td></tr></table>

<table><tbody><tr><td>阈值</td><td>低置信度集合大小</td><td>低置信度集合上的准确率</td><td>全集上的准确率</td></tr><tr><td>0.47</td><td>10000</td><td>19.40%</td><td>68.72%</td></tr><tr><td>0.52</td><td>11000</td><td>20.82%</td><td>68.78%</td></tr><tr><td>0.57</td><td>12000</td><td>22.06%</td><td>68.82%</td></tr><tr><td>0.62</td><td>13000</td><td>23.58%</td><td>68.85%</td></tr><tr><td>0.66</td><td>14000</td><td>25.01%</td><td>68.88%</td></tr><tr><td>0.70</td><td>15000</td><td>26.51%</td><td>68.86%</td></tr></tbody></table>

Effect of threshold of confidence score on zero-shot accuracy. In Table 1 we use a binary criterion to determine the low confidence set. We can alternatively use the continuous confidence score by choosing a threshold based on the trade-off between precision and recall. Changing the threshold of the confidence score can lead to different numbers of samples in the low confidence set. We study the effect of threshold on zero-shot accuracy. Table 5 shows the overall accuracy with different thresholds. We find that the overall accuracy is relatively robust to the threshold selection, in the wide range from 0.47 to 0.70 .

置信度阈值对零样本准确率的影响。在表1中，我们使用二元标准来确定低置信度集合。我们也可以通过选择基于精确率和召回率权衡的阈值，使用连续的置信度分数。改变置信度阈值会导致低置信度集合中的样本数量不同。我们研究了阈值对零样本准确率的影响。表5显示了不同阈值下的整体准确率。我们发现整体准确率对阈值选择相对稳健，在0.47到0.70的较宽范围内表现稳定。

## 6. Conclusion

## 6. 结论

Multi-modal models' generalization and robustness is critical for deployment. Motivated by the big gap between top-1 and top-5 accuracy in ImageNet zero-shot classification, we investigated the failure modes and found that the model's prediction is very sensitive to text prompts. We describe a simple but efficient zero-shot post-hoc method to identify a subset of samples that are most likely to be predicted wrongly by a measure of self-consistency. For those in the low confidence subset, we use the WordNet hierarchy to augment class labels to enhance the robustness, resulting in up to 17.13% accuracy improvement on ImageNet. We show our method provides consistent improvement over other distribution shifted datasets (ImageNet variants), four other datasets, and is generalizable to other image-text models and different backbones.

多模态模型的泛化能力和鲁棒性对于部署至关重要。受ImageNet零样本分类中top-1与top-5准确率差距较大的启发，我们调查了失败模式，发现模型的预测对文本提示非常敏感。我们提出了一种简单但高效的零样本后验方法，通过自一致性度量识别最可能被错误预测的样本子集。对于低置信度子集，我们利用WordNet层级结构扩充类别标签以增强鲁棒性，在ImageNet上实现了最高17.13%的准确率提升。我们展示了该方法在其他分布偏移数据集(ImageNet变体)、另外四个数据集上均有一致提升，且可推广至其他图文模型和不同骨干网络。

Acknowledgments This work was supported in part by C-BRIC (one of six centers in JUMP, a Semiconductor Research Corporation (SRC) program sponsored by DARPA), DARPA (HR00112190134) and the Army Research Office (W911NF2020053). The authors affirm that the views expressed herein are solely their own, and do not represent the views of the United States government or any agency thereof. References

致谢 本工作部分由C-BRIC(JUMP项目中的六个中心之一，半导体研究公司(SRC)项目，受DARPA资助)、DARPA(HR00112190134)和陆军研究办公室(W911NF2020053)支持。作者声明文中观点仅代表个人，不代表美国政府或任何机构的立场。参考文献

[1] Lucas Beyer, Olivier J Hénaff, Alexander Kolesnikov, Xi-aohua Zhai, and Aäron van den Oord. Are we done with imagenet? arXiv preprint arXiv:2006.07159, 2020. 1, 3

[1] Lucas Beyer, Olivier J Hénaff, Alexander Kolesnikov, Xi-aohua Zhai, 和 Aäron van den Oord. 我们完成了ImageNet吗？arXiv预印本 arXiv:2006.07159, 2020. 1, 3

[2] Lukas Bossard, Matthieu Guillaumin, and Luc Van Gool. Food-101 - mining discriminative components with random forests. In European Conference on Computer Vision, 2014. 7

[2] Lukas Bossard, Matthieu Guillaumin, 和 Luc Van Gool. Food-101 - 利用随机森林挖掘判别成分。发表于欧洲计算机视觉大会，2014年。7

[3] Jia Deng, Nan Ding, Yangqing Jia, Andrea Frome, Kevin Murphy, Samy Bengio, Yuan Li, Hartmut Neven, and Hartwig Adam. Large-scale object classification using label relation graphs. In ${ECCV}$ , pages ${48} - {64},{2014.3}$

[3] Jia Deng, Nan Ding, Yangqing Jia, Andrea Frome, Kevin Murphy, Samy Bengio, Yuan Li, Hartmut Neven, 和 Hartwig Adam. 使用标签关系图的大规模物体分类。发表于${ECCV}$，页码${48} - {64},{2014.3}$

[4] Jia Deng, Wei Dong, Richard Socher, Li-Jia Li, Kai Li, and Li Fei-Fei. Imagenet: A large-scale hierarchical image database. In 2009 IEEE conference on computer vision and pattern recognition, pages 248-255. Ieee, 2009. 1, 5, 7

[4] Jia Deng, Wei Dong, Richard Socher, Li-Jia Li, Kai Li, 和 Li Fei-Fei. ImageNet:一个大规模分层图像数据库。发表于2009年IEEE计算机视觉与模式识别会议，页码248-255。IEEE, 2009. 1, 5, 7

[5] Rob Fergus, Hector Bernal, Yair Weiss, and Antonio Tor-ralba. Semantic label sharing for learning with many categories. In ${ECCV}$ , pages 762-775,2010. 3

[5] Rob Fergus, Hector Bernal, Yair Weiss, 和 Antonio Torralba. 多类别学习的语义标签共享。发表于${ECCV}$，页码762-775, 2010. 3

[6] Yarin Gal and Zoubin Ghahramani. Dropout as a bayesian approximation: Representing model uncertainty in deep learning. arxiv e-prints, page. arXiv preprint arXiv:1506.02142, 3, 2015. 2

[6] Yarin Gal 和 Zoubin Ghahramani. Dropout作为贝叶斯近似:表示深度学习中的模型不确定性。arXiv电子预印本，页码。arXiv预印本 arXiv:1506.02142, 3, 2015. 2

[7] Yunhao Ge, Jiashu Xu, Brian Nlong Zhao, Laurent Itti, and Vibhav Vineet. Dall-e for detection: Language-driven context image synthesis for object detection. arXiv preprint arXiv:2206.09592, 2022. 1

[7] Yunhao Ge, Jiashu Xu, Brian Nlong Zhao, Laurent Itti, 和 Vibhav Vineet. 用于检测的DALL·E:基于语言驱动的上下文图像合成用于目标检测。arXiv预印本 arXiv:2206.09592, 2022. 1

[8] Dan Hendrycks, Steven Basart, Mantas Mazeika, Moham-madreza Mostajabi, Jacob Steinhardt, and Dawn Song. Scaling out-of-distribution detection for real-world settings. arXiv preprint arXiv:1911.11132, 2019. 2, 6

[8] Dan Hendrycks, Steven Basart, Mantas Mazeika, Mohammadreza Mostajabi, Jacob Steinhardt, 和 Dawn Song. 扩展分布外检测以适应真实世界场景。arXiv预印本 arXiv:1911.11132, 2019. 2, 6

[9] Dan Hendrycks, Steven Basart, Norman Mu, Saurav Kada-vath, Frank Wang, Evan Dorundo, Rahul Desai, Tyler Zhu, Samyak Parajuli, Mike Guo, et al. The many faces of robustness: A critical analysis of out-of-distribution generalization. In ${ICCV},{2021.1},7,8$

[9] Dan Hendrycks, Steven Basart, Norman Mu, Saurav Kadavath, Frank Wang, Evan Dorundo, Rahul Desai, Tyler Zhu, Samyak Parajuli, Mike Guo, 等. 鲁棒性的多面性:对分布外泛化的批判性分析。发表于${ICCV},{2021.1},7,8$

[10] Dan Hendrycks and Kevin Gimpel. A baseline for detecting misclassified and out-of-distribution examples in neural networks. arXiv preprint arXiv:1610.02136, 2016. 2

[10] Dan Hendrycks 和 Kevin Gimpel. 神经网络中误分类和分布外样本检测的基线方法。arXiv预印本 arXiv:1610.02136, 2016. 2

[11] Dan Hendrycks, Kevin Zhao, Steven Basart, Jacob Stein-hardt, and Dawn Song. Natural adversarial examples. In CVPR, 2021. 1, 7, 8

[11] Dan Hendrycks, Kevin Zhao, Steven Basart, Jacob Stein-hardt, 和 Dawn Song. 自然对抗样本. 发表在 CVPR, 2021. 1, 7, 8

[12] Chao Jia, Yinfei Yang, Ye Xia, Yi-Ting Chen, Zarana Parekh, Hieu Pham, Quoc Le, Yun-Hsuan Sung, Zhen Li, and Tom Duerig. Scaling up visual and vision-language representation learning with noisy text supervision. In ICML, pages 4904- 4916, 2021. 1, 2

[12] Chao Jia, Yinfei Yang, Ye Xia, Yi-Ting Chen, Zarana Parekh, Hieu Pham, Quoc Le, Yun-Hsuan Sung, Zhen Li, 和 Tom Duerig. 利用噪声文本监督扩展视觉及视觉-语言表征学习. 发表在 ICML, 页码 4904-4916, 2021. 1, 2

[13] Alex Krizhevsky, Geoffrey Hinton, et al. Learning multiple layers of features from tiny images. 2009. 7

[13] Alex Krizhevsky, Geoffrey Hinton 等. 从小图像中学习多层特征. 2009. 7

[14] Balaji Lakshminarayanan, Alexander Pritzel, and Charles Blundell. Simple and scalable predictive uncertainty estimation using deep ensembles. NeurIPS, 30, 2017. 2, 6

[14] Balaji Lakshminarayanan, Alexander Pritzel, 和 Charles Blundell. 使用深度集成进行简单且可扩展的预测不确定性估计. NeurIPS, 30, 2017. 2, 6

[15] FF Li, M Andreetto, MA Ranzato, and P Perona. Caltech101. Computational Vision Group, California Institute of Technology, 2003. 7

[15] FF Li, M Andreetto, MA Ranzato, 和 P Perona. Caltech101 数据集. 加州理工学院计算机视觉组, 2003. 7

[16] Jeremiah Zhe Liu, Shreyas Padhy, Jie Ren, Zi Lin, Yeming Wen, Ghassen Jerfel, Zack Nado, Jasper Snoek, Dustin Tran, and Balaji Lakshminarayanan. A simple approach to improve single-model deep uncertainty via distance-awareness. arXiv preprint arXiv:2205.00403, 2022. 2

[16] Jeremiah Zhe Liu, Shreyas Padhy, Jie Ren, Zi Lin, Yeming Wen, Ghassen Jerfel, Zack Nado, Jasper Snoek, Dustin Tran, 和 Balaji Lakshminarayanan. 通过距离感知提升单模型深度不确定性的一种简单方法. arXiv 预印本 arXiv:2205.00403, 2022. 2

[17] Maria-Elena Nilsback and Andrew Zisserman. Automated flower classification over a large number of classes. In 2008 Sixth Indian Conference on Computer Vision, Graphics & Image Processing, pages 722-729. IEEE, 2008. 7

[17] Maria-Elena Nilsback 和 Andrew Zisserman. 大规模类别的自动花卉分类. 发表在 2008年第六届印度计算机视觉、图形与图像处理会议, 页码 722-729. IEEE, 2008. 7

[18] Hieu Pham, Zihang Dai, Golnaz Ghiasi, Kenji Kawaguchi, Hanxiao Liu, Adams Wei Yu, Jiahui Yu, Yi-Ting Chen, Minh-Thang Luong, Yonghui Wu, et al. Combined scaling for open-vocabulary image classification. arXiv preprint arXiv:2111.10050, 2021. 1

[18] Hieu Pham, Zihang Dai, Golnaz Ghiasi, Kenji Kawaguchi, Hanxiao Liu, Adams Wei Yu, Jiahui Yu, Yi-Ting Chen, Minh-Thang Luong, Yonghui Wu 等. 开放词汇图像分类的联合扩展. arXiv 预印本 arXiv:2111.10050, 2021. 1

[19] Alec Radford, Jong Wook Kim, Chris Hallacy, Aditya Ramesh, Gabriel Goh, Sandhini Agarwal, Girish Sastry, Amanda Askell, Pamela Mishkin, Jack Clark, et al. Learning transferable visual models from natural language supervision. In ICML, pages 8748-8763, 2021. 1, 2, 3, 4, 8

[19] Alec Radford, Jong Wook Kim, Chris Hallacy, Aditya Ramesh, Gabriel Goh, Sandhini Agarwal, Girish Sastry, Amanda Askell, Pamela Mishkin, Jack Clark 等. 从自然语言监督中学习可迁移的视觉模型. 发表在 ICML, 页码 8748-8763, 2021. 1, 2, 3, 4, 8

[20] Aditya Ramesh, Mikhail Pavlov, Gabriel Goh, Scott Gray, Chelsea Voss, Alec Radford, Mark Chen, and Ilya Sutskever. Zero-shot text-to-image generation. In International Conference on Machine Learning, pages 8821-8831. PMLR, 2021. 1

[20] Aditya Ramesh, Mikhail Pavlov, Gabriel Goh, Scott Gray, Chelsea Voss, Alec Radford, Mark Chen, 和 Ilya Sutskever. 零样本文本到图像生成. 发表在国际机器学习大会, 页码 8821-8831. PMLR, 2021. 1

[21] Benjamin Recht, Rebecca Roelofs, Ludwig Schmidt, and Vaishaal Shankar. Do ImageNet classifiers generalize to Im-ageNet? In ${ICML},{2019.1},7,8$

[21] Benjamin Recht, Rebecca Roelofs, Ludwig Schmidt, 和 Vaishaal Shankar. ImageNet 分类器能否泛化到 Im-ageNet？ 在 ${ICML},{2019.1},7,8$

[22] Marcus Rohrbach, Michael Stark, and Bernt Schiele. Evaluating knowledge transfer and zero-shot learning in a large-scale setting. In ${CVPR}$ , pages ${1641} - {1648},{2011.3}$

[22] Marcus Rohrbach, Michael Stark, 和 Bernt Schiele. 在大规模环境下评估知识迁移和零样本学习. 在 ${CVPR}$ ,页码 ${1641} - {1648},{2011.3}$

[23] Marcus Rohrbach, Michael Stark, György Szarvas, Iryna Gurevych, and Bernt Schiele. What helps where-and why? semantic relatedness for knowledge transfer. In ${CVPR}$ , pages 910-917, 2010. 3

[23] Marcus Rohrbach, Michael Stark, György Szarvas, Iryna Gurevych, 和 Bernt Schiele. 什么有助于何处——以及为什么？知识迁移的语义相关性. 在 ${CVPR}$ ,页码 910-917, 2010. 3

[24] Manli Shu, Weili Nie, De-An Huang, Zhiding Yu, Tom Goldstein, Anima Anandkumar, and Chaowei Xiao. Test-time prompt tuning for zero-shot generalization in vision-language models. arXiv preprint arXiv:2209.07511, 2022. 2

[24] Manli Shu, Weili Nie, De-An Huang, Zhiding Yu, Tom Goldstein, Anima Anandkumar, 和 Chaowei Xiao. 视觉-语言模型中零样本泛化的测试时提示调优. arXiv 预印本 arXiv:2209.07511, 2022. 2

[25] Haohan Wang, Songwei Ge, Zachary Lipton, and Eric P Xing. Learning robust global representations by penalizing local predictive power. In NeurIPS, pages 10506-10518, 2019.1,7,8

[25] Haohan Wang, Songwei Ge, Zachary Lipton, 和 Eric P Xing. 通过惩罚局部预测能力学习鲁棒的全局表征. 发表在 NeurIPS, 页码 10506-10518, 2019. 1,7,8

[26] Xuezhi Wang, Jason Wei, Dale Schuurmans, Quoc Le, Ed Chi, and Denny Zhou. Self-consistency improves chain of thought reasoning in language models. arXiv preprint arXiv:2203.11171, 2022. 2

[26] Xuezhi Wang, Jason Wei, Dale Schuurmans, Quoc Le, Ed Chi, 和 Denny Zhou. 自洽性提升语言模型中的链式思维推理. arXiv 预印本 arXiv:2203.11171, 2022. 2

[27] Yeming Wen, Dustin Tran, and Jimmy Ba. Batchensemble: an alternative approach to efficient ensemble and lifelong learning. arXiv preprint arXiv:2002.06715, 2020. 2

[27] Yeming Wen, Dustin Tran, 和 Jimmy Ba. Batchensemble:一种高效集成与终身学习的替代方法。arXiv预印本 arXiv:2002.06715, 2020. 2

[28] Xiaohua Zhai, Xiao Wang, Basil Mustafa, Andreas Steiner, Daniel Keysers, Alexander Kolesnikov, and Lucas Beyer. Lit: Zero-shot transfer with locked-image text tuning. In CVPR, pages 18123-18133, 2022. 1, 2, 6

[28] Xiaohua Zhai, Xiao Wang, Basil Mustafa, Andreas Steiner, Daniel Keysers, Alexander Kolesnikov, 和 Lucas Beyer. Lit:基于锁定图像文本调优的零样本迁移。在CVPR，页码18123-18133，2022. 1, 2, 6

[29] Kaiyang Zhou, Jingkang Yang, Chen Change Loy, and Zi-wei Liu. Conditional prompt learning for vision-language models. In CVPR, pages 16816-16825, 2022. 2

[29] Kaiyang Zhou, Jingkang Yang, Chen Change Loy, 和 Zi-wei Liu. 视觉语言模型的条件提示学习。在CVPR，页码16816-16825，2022. 2

[30] Kaiyang Zhou, Jingkang Yang, Chen Change Loy, and Ziwei Liu. Learning to prompt for vision-language models. IJCV, 130(9):2337-2348, 2022. 2

[30] Kaiyang Zhou, Jingkang Yang, Chen Change Loy, 和 Ziwei Liu. 视觉语言模型的提示学习。国际计算机视觉杂志(IJCV)，130(9):2337-2348, 2022. 2