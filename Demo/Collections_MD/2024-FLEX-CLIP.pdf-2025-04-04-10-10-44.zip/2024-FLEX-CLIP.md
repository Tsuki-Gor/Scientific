# FLEX-CLIP: Feature-Level GEneration Network Enhanced CLIP for $\mathbf{X}$ -shot Cross-modal Retrieval

# FLEX-CLIP:用于$\mathbf{X}$次射击跨模态检索的特征级生成网络增强型CLIP

Jingyou Xie ${}^{ \dagger  }$ , Jiayi Kuang ${}^{ \dagger  }$ , Zhenzhou Lin, Jiarui Ouyang, Zishuo Zhao, and Ying Shen ${}^{ * }$

谢景佑 ${}^{ \dagger  }$，匡佳怡 ${}^{ \dagger  }$，林振洲，欧阳佳瑞，赵子硕，以及沈莹 ${}^{ * }$

Abstract-Given a query from one modality, few-shot cross-modal retrieval (CMR) retrieves semantically similar instances in another modality with the target domain including classes that are disjoint from the source domain. Compared with classical few-shot CMR methods, vision-language pretraining methods like CLIP have shown great few-shot or zero-shot learning performance. However, they still suffer challenges due to (1) the feature degradation encountered in the target domain and (2) the extreme data imbalance. To tackle these issues, we propose FLEX-CLIP, a novel Feature-level Generation Network Enhanced CLIP. FLEX-CLIP includes two training stages. In multimodal feature generation, we propose a composite multimodal VAE-GAN network to capture real feature distribution patterns and generate pseudo samples based on CLIP features, addressing data imbalance. For common space projection, we develop a gate residual network to fuse CLIP features with projected features, reducing feature degradation in X-shot scenarios. Experimental results on four benchmark datasets show a 7%- 15% improvement over state-of-the-art methods, with ablation studies demonstrating enhancement of CLIP features.

摘要 — 给定来自一种模态的查询，少样本跨模态检索(CMR)会在另一种模态中检索语义相似的实例，目标领域包含与源领域不相交的类别。与经典的少样本CMR方法相比，像CLIP这样的视觉 - 语言预训练方法在少样本或零样本学习方面表现出色。然而，它们仍然面临挑战，原因在于:(1)在目标领域遇到的特征退化问题；(2)极端的数据不平衡问题。为解决这些问题，我们提出了FLEX - CLIP，一种新颖的特征级生成网络增强型CLIP。FLEX - CLIP包括两个训练阶段。在多模态特征生成阶段，我们提出了一种复合多模态VAE - GAN网络，以捕捉真实的特征分布模式，并基于CLIP特征生成伪样本，从而解决数据不平衡问题。在公共空间投影阶段，我们开发了一种门控残差网络，将CLIP特征与投影特征融合，减少[latex0]次射击场景中的特征退化。在四个基准数据集上的实验结果表明，与现有最先进的方法相比，性能提高了7% - 15%，消融实验证明了对CLIP特征的增强效果。

Index Terms-cross-modal retrieval,

关键词 — 跨模态检索

## I. INTRODUCTION

## 一、引言

The rise of massive multimodal data, encompassing text and images [27]-[29], has led to increasing demand for Cross-Modal Retrieval (CMR), which enables searching for similar instances in one modality using query data from another modality [1], [4], [20], [31], [32]. Unlike single-modal retrieval, cross-modal retrieval faces the challenge of a "modality gap", stemming from inconsistent representations and differing distributions between modalities [2]-[4], [30], [31].

包含文本和图像的海量多模态数据的兴起 [27] - [29]，导致对跨模态检索(CMR)的需求不断增加，它允许使用来自一种模态的查询数据在另一种模态中搜索相似的实例 [1]，[4]，[20]，[31]，[32]。与单模态检索不同，跨模态检索面临着“模态差距”的挑战，这源于模态之间表示不一致和分布不同 [2] - [4]，[30]，[31]。

To bridge this gap, current methods typically map samples from different modalities into a common space [3], [4], [18]- [20], [56]. The training process learns this common space from the training instances, allowing direct calculation of cross-modal similarities for the test data [32], [41], [42]. However, these methods require the training and test data to share the same set of classes, limiting their extensibility and generalization to new categories [5], [43].

为了弥合这一差距，当前的方法通常将来自不同模态的样本映射到一个公共空间 [3]，[4]，[18] - [20]，[56]。训练过程从训练实例中学习这个公共空间，从而可以直接计算测试数据的跨模态相似度 [32]，[41]，[42]。然而，这些方法要求训练数据和测试数据共享相同的类别集合，这限制了它们对新类别的扩展性和泛化能力 [5]，[43]。

These approaches also struggle in few-shot scenarios, particularly due to the challenge of extreme data imbalance when the retrieval classes in the source domain have little or no overlap with those in the target domain [8], [33], as shown in Figure 1. To address the new classes in the target domain, many methods draw inspiration from few-shot learning, which leverages word embeddings of class label information, as depicted in Figure 2 (a) [9], [10], [14], [44], [45]. These methods seek to establish a shared latent space between input multimodal features and class label embeddings, or they generate pseudo-samples based on target domain class embeddings to mitigate data imbalance [5], [7], [46], [47]. Given the strong few-shot learning performance of vision-language pretraining models (VLP) on various multimodal tasks [21], [53], some approaches incorporate CLIP [22] as the feature extractor to enhance cross-modal retrieval.

这些方法在少样本场景中也面临困难，特别是当源领域的检索类别与目标领域的检索类别几乎没有或完全没有重叠时，会出现极端的数据不平衡问题 [8]，[33]，如图1所示。为了处理目标领域中的新类别，许多方法从少样本学习中获得灵感，利用类别标签信息的词嵌入，如图2(a)所示 [9]，[10]，[14]，[44]，[45]。这些方法试图在输入的多模态特征和类别标签嵌入之间建立一个共享的潜在空间，或者基于目标领域的类别嵌入生成伪样本，以缓解数据不平衡问题 [5]，[7]，[46]，[47]。鉴于视觉 - 语言预训练模型(VLP)在各种多模态任务上具有强大的少样本学习性能 [21]，[53]，一些方法将CLIP [22] 作为特征提取器，以增强跨模态检索。

![0195d6f2-b56e-7b0a-aee8-41fd975e38e0_0_938_504_670_617_0.jpg](images/0195d6f2-b56e-7b0a-aee8-41fd975e38e0_0_938_504_670_617_0.jpg)

Fig. 1. The illustration of the zero-shot cross-modal retrieval dataset setting.

图1. 零样本跨模态检索数据集设置的示意图。

Despite advancements in few-shot and zero-shot cross-modal retrieval, significant challenges remain:

尽管少样本和零样本跨模态检索取得了进展，但仍然存在重大挑战:

1)Feature Degradation in the Target Domain: While CLIP-based CMR methods exhibit remarkable few-shot learning performance, the common space mapping of features extracted by CLIP in few-shot settings often leads to feature degradation. This issue arises when the model struggles to effectively transfer the learned common space mapping from the source domain to the target domain, resulting in the mapped features performing worse than the original CLIP-extracted features.

1)目标领域的特征退化:虽然基于CLIP的CMR方法在少样本学习方面表现出色，但在少样本设置下，CLIP提取的特征的公共空间映射往往会导致特征退化。当模型难以有效地将从源领域学到的公共空间映射转移到目标领域时，就会出现这个问题，导致映射后的特征表现不如原始CLIP提取的特征。

2)Extreme Data Imbalance: The absence of target domain instances during training makes it challenging to model the cross-modal correlations in the target set [15]-[17]. Some 0000-0000/00\$00.0methods Institutempt to generate pseudo-samples based on target domain class embeddings to mitigate data imbalance. However, due to the disparity in the number of samples between the source and target domains, the model often fails to accurately capture the true feature distribution of the target domain. This results in a bias toward the source domain during training and suboptimal performance on the target domain [48], [49].

2)极端的数据不平衡:训练期间缺乏目标领域的实例，使得难以对目标集中的跨模态相关性进行建模 [15] - [17]。一些方法试图基于目标领域的类别嵌入生成伪样本，以缓解数据不平衡问题。然而，由于源领域和目标领域样本数量的差异，模型往往无法准确捕捉目标领域的真实特征分布。这导致训练过程中偏向源领域，在目标领域的性能不佳 [48]，[49]。

---

${}^{ \dagger  }$ indicates equal contribution,* indicates corresponding author Jingyou Xie, (e-mail: Xiejy73@mail2.sysu.edu.cn). Ji-ayi Kuang, (e-mail: kuangjy6@mail2.sysu.edu.cn). Z zhou Lin, (e-mail: linzhzh6@mail2.sysu.edu.cn). Jiarui Ouyang, (e-mail: ouyjr@mail2.sysu.edu.cn). Zishuo Zhao, (e-mail: zhaozsh@mail2.sysu.edu.cn). and Ying Shen, (email:sheny76@mail.sysu.edu.cn) are with the School of Intelligent Systems Engineering, Sun Yat-sen University, Shenzhen, 518107 China.

${}^{ \dagger  }$ 表示同等贡献，* 表示通讯作者谢景友(邮箱:Xiejy73@mail2.sysu.edu.cn)。匡佳怡(邮箱:kuangjy6@mail2.sysu.edu.cn)。周林(邮箱:linzhzh6@mail2.sysu.edu.cn)。欧阳佳锐(邮箱:ouyjr@mail2.sysu.edu.cn)。赵子硕(邮箱:zhaozsh@mail2.sysu.edu.cn)和沈莹(邮箱:sheny76@mail.sysu.edu.cn)就职于中山大学智能系统工程学院，中国深圳 518107。

---

![0195d6f2-b56e-7b0a-aee8-41fd975e38e0_1_207_154_1386_504_0.jpg](images/0195d6f2-b56e-7b0a-aee8-41fd975e38e0_1_207_154_1386_504_0.jpg)

Fig. 2. An illustration of classical zero-shot CMR methods VLP-based method, and our method.

图 2. 经典零样本跨模态检索(CMR)方法、基于视觉语言预训练(VLP)的方法以及我们的方法的示意图。

To address these challenges, we propose FLEX-CLIP, a novel Feature-Level GEneration Network enhanced CLIP for X-shot Cross-modal Retrieval. FLEX-CLIP comprises two key stages: (1) multimodal feature generation, and (2) common space projection. In the feature generation stage, inspired by classical zero-shot CMR methods, we design a composite cross-modal generation architecture. This architecture leverages the strengths of both VAE and GAN networks to tackle data imbalance and enhance CLIP features. The GAN generates pseudo-samples based on class embeddings, while the VAE captures feature distribution patterns by encoding and reconstructing real samples. In the common space projection stage, real samples from the source domain and generated samples from the target domain are fed into two projectors to obtain common features. To effectively utilize the semantic information in CLIP, we design a gated residual network that selectively fuses original features with the mapped features, thereby significantly addressing the feature degradation problem.

为应对这些挑战，我们提出了 FLEX - CLIP，这是一种用于 X 样本跨模态检索的新型特征级生成网络增强的 CLIP 模型。FLEX - CLIP 包括两个关键阶段:(1)多模态特征生成，(2)公共空间投影。在特征生成阶段，受经典零样本 CMR 方法的启发，我们设计了一种复合跨模态生成架构。该架构利用变分自编码器(VAE)和生成对抗网络(GAN)的优势来解决数据不平衡问题并增强 CLIP 特征。GAN 基于类别嵌入生成伪样本，而 VAE 通过对真实样本进行编码和解码来捕捉特征分布模式。在公共空间投影阶段，将源域的真实样本和目标域的生成样本输入到两个投影器中以获得公共特征。为了有效利用 CLIP 中的语义信息，我们设计了一个门控残差网络，该网络选择性地将原始特征与映射特征融合，从而显著解决了特征退化问题。

Notably, unlike previous approaches that integrate data generation and common space mapping into a single framework, we train these two processes separately to ensure stable results. Our main contributions are as follows:

值得注意的是，与之前将数据生成和公共空间映射集成到单一框架的方法不同，我们分别训练这两个过程以确保结果的稳定性。我们的主要贡献如下:

- We introduce a novel Feature-Level GEneration Network to enhance CLIP features for X-shot CMR, effectively addressing the extreme data imbalance problem in few-shot learning within CLIP.

- 我们引入了一种新型的特征级生成网络来增强用于 X 样本 CMR 的 CLIP 特征，有效解决了 CLIP 中少样本学习的极端数据不平衡问题。

- We design a gated network that adaptively selects and fuses projected features with original CLIP features, fully leveraging semantic knowledge and mitigating feature degradation.

- 我们设计了一个门控网络，该网络自适应地选择投影特征并将其与原始 CLIP 特征融合，充分利用语义知识并减轻特征退化。

- We conduct extensive experiments on four widely-used datasets in X-shot scenarios $(0,1,3,5,7$ -shot) and demonstrate that FLEX-CLIP significantly outperforms strong baselines in few-shot cross-modal retrieval tasks by up to ${7.9}\%$ .

- 我们在四个广泛使用的 X 样本场景($(0,1,3,5,7$ 样本)数据集上进行了广泛的实验，结果表明 FLEX - CLIP 在少样本跨模态检索任务中显著优于强大的基线模型，提升幅度高达 ${7.9}\%$。

## II. RELATED WORK

## 二、相关工作

## A. Cross-modal Retrieval

## A. 跨模态检索

Cross-modal retrieval seeks to identify semantically similar instances in one modality using a query from another, with image-text and image-sketch retrieval being two common scenarios [4], [31], [57]. Traditional approaches achieve this by jointly modeling the text and image components of multimedia documents, linearly projecting features from different modalities into a shared space [1], [23]. Deep neural networks (DNNs) have further advanced this field by reducing the gap between modalities and identifying maximally correlated embedding spaces [2], [3], [58]. While DNN-based methods can integrate various features into a common space, they sometimes struggle to model heterogeneous data distributions with inconsistent semantics. Recent research has leveraged Generative Adversarial Networks (GANs) to address these challenges, using cross-modal generators to reduce semantic discrepancies and modality discriminators to distinguish features across modalities [18]-[20]. Additionally, vision-language pretraining (VLP) models like CLIP [22] have shown significant promise in cross-modal retrieval, though they may suffer from feature degradation when encountering new classes in the target domain.

跨模态检索旨在使用一种模态的查询来识别另一种模态中语义相似的实例，图像 - 文本和图像 - 草图检索是两种常见的场景 [4]、[31]、[57]。传统方法通过对多媒体文档的文本和图像组件进行联合建模，将不同模态的特征线性投影到一个共享空间来实现这一目标 [1]、[23]。深度神经网络(DNN)通过缩小模态之间的差距并识别最大相关的嵌入空间，进一步推动了该领域的发展 [2]、[3]、[58]。虽然基于 DNN 的方法可以将各种特征集成到一个公共空间，但它们有时难以对具有不一致语义的异构数据分布进行建模。最近的研究利用生成对抗网络(GAN)来应对这些挑战，使用跨模态生成器来减少语义差异，并使用模态判别器来区分不同模态的特征 [18] - [20]。此外，像 CLIP [22] 这样的视觉 - 语言预训练(VLP)模型在跨模态检索中显示出了巨大的潜力，尽管当遇到目标域中的新类别时，它们可能会出现特征退化问题。

## B. Zero-shot Cross-modal Retrieval

## B. 零样本跨模态检索

Although traditional methods perform well, they often struggle with zero-shot retrieval due to the absence of unseen target classes during training [5]. To address this, various studies have explored class embeddings to enable zero-shot learning [8]-[10], [14]. For instance, Chi et al. introduced DADN to address heterogeneous distributions and inconsistent semantics between seen and unseen classes, leveraging word embeddings to enhance knowledge transfer [7]. Recent work has increasingly focused on feature generation techniques to mitigate the modality gap and data imbalance issues [15]- [17], employing generative models like GANs and Variational Autoencoders (VAEs) to capture multimodal data structures, as seen in LCALE [8] and AAEGAN [11]. To handle inconsistent semantics between source and target sets, $\mathrm{{Xu}}$ et al. proposed TANSS, which includes two modality-specific semantic learning subnetworks and a self-supervised semantic learning subnetwork to generalize across datasets [6]. However, these approaches often overlook the impact of data reconstruction in generative models, leading to a misleading feature distribution. MDVAE [12] was introduced to address this by learning disentangled modality-invariant and modality-specific features through coupled VAEs. Nonetheless, generative models frequently lack scalability for retrieving cross-modal data from new classes due to feature degradation. JFSE [13] revisits adversarial learning in existing cross-modal GAN methods, employing coupled conditional Wasserstein GAN modules to synthesize meaningful and correlated multimodal features.

尽管传统方法表现良好，但由于训练期间未出现未见的目标类别，它们在零样本检索方面往往面临困难[5]。为了解决这个问题，各种研究探索了类别嵌入以实现零样本学习[8]-[10]，[14]。例如，Chi等人引入了DADN(判别式对抗域适应网络，Discriminative Adversarial Domain Adaptation Network)来解决已见和未见类别之间的异构分布和语义不一致问题，利用词嵌入来增强知识迁移[7]。近期的工作越来越关注特征生成技术，以缓解模态差距和数据不平衡问题[15]- [17]，采用生成对抗网络(GANs)和变分自编码器(VAEs)等生成模型来捕捉多模态数据结构，如LCALE [8]和AAEGAN [11]所示。为了处理源集和目标集之间的语义不一致问题，$\mathrm{{Xu}}$等人提出了TANSS(跨模态自适应网络，Trans-modal Adaptive Network with Self-supervised learning)，它包括两个特定模态的语义学习子网络和一个自监督语义学习子网络，以实现跨数据集的泛化[6]。然而，这些方法往往忽略了生成模型中数据重建的影响，导致特征分布产生误导。MDVAE [12](多模态解耦变分自编码器，Multi-modal Disentangled Variational Autoencoder)通过耦合变分自编码器学习解耦的模态不变和特定模态特征来解决这个问题。尽管如此，由于特征退化，生成模型在从新类别中检索跨模态数据时往往缺乏可扩展性。JFSE [13](联合特征空间嵌入，Joint Feature Space Embedding)重新审视了现有跨模态生成对抗网络方法中的对抗学习，采用耦合条件Wasserstein生成对抗网络模块来合成有意义且相关的多模态特征。

![0195d6f2-b56e-7b0a-aee8-41fd975e38e0_2_131_149_1533_651_0.jpg](images/0195d6f2-b56e-7b0a-aee8-41fd975e38e0_2_131_149_1533_651_0.jpg)

Fig. 3. The whole architecture of our proposed model FLEX-CLIP. ${\mathbf{v}}_{\mathbf{i}}$ and ${\mathbf{t}}_{\mathbf{i}}$ are a pair of image and textual features, respectively. ${\mathbf{y}}_{\mathbf{i}}$ represents the category label, and ${\mathbf{a}}_{\mathbf{i}} = \operatorname{attri}\left( {y}_{i}\right)$ is the corresponding category attribute feature of this sample. ${E}_{ * }\left( \cdot \right) ,{G}_{ * }\left( \cdot \right) ,{D}_{ * }\left( \cdot \right)$ denote encoder, generator, discriminator respectively, and $*  = \{ v, t\}$ denotes the image and text modalities.

图3. 我们提出的模型FLEX - CLIP的整体架构。${\mathbf{v}}_{\mathbf{i}}$和${\mathbf{t}}_{\mathbf{i}}$分别是一对图像和文本特征。${\mathbf{y}}_{\mathbf{i}}$表示类别标签，${\mathbf{a}}_{\mathbf{i}} = \operatorname{attri}\left( {y}_{i}\right)$是该样本对应的类别属性特征。${E}_{ * }\left( \cdot \right) ,{G}_{ * }\left( \cdot \right) ,{D}_{ * }\left( \cdot \right)$分别表示编码器、生成器、判别器，$*  = \{ v, t\}$表示图像和文本模态。

## III. METHODOLOGY

## 三、方法

## A. Problem Formulation

## A. 问题表述

In this work, we focus on zero-shot and few-shot cross-modal retrieval between text and images. Given an instance set of source domain ${X}_{s} = {\left\{  {\mathbf{x}}_{i}\right\}  }_{i = 1}^{{n}_{s}}$ and an instance set of target domain ${X}_{t} = {\left\{  {\mathbf{x}}_{j}\right\}  }_{j = 1}^{{n}_{t}}$ , they contains ${n}_{s}$ and ${n}_{t}$ samples respectively. Taking the source domain set ${X}_{s}$ as an example, the $i$ -th sample is defined as ${\mathbf{x}}_{i} = \left( {{\mathbf{v}}_{i},{\mathbf{t}}_{i},{\mathbf{a}}_{i},{\mathbf{y}}_{i}}\right)$ , where ${\mathbf{v}}_{i} \in  {\mathbb{R}}^{{d}_{v}}$ and ${\mathbf{t}}_{i} \in  {\mathbb{R}}^{{d}_{t}}$ are image-text pair that have the same semantic information. ${\mathbf{y}}_{i}$ is the class label, and ${\mathbf{a}}_{i} = \operatorname{attri}\left( {\mathbf{y}}_{i}\right)$ is the corresponding class attribute feature of ${\mathbf{y}}_{i}$ . It is worth noting that the class label set in target domain ${Y}_{t} = {\left\{  {\mathbf{y}}_{j}\right\}  }_{j = 1}^{{c}_{t}}$ is completely different from the ones in source domain ${Y}_{s} = {\left\{  {\mathbf{y}}_{i}\right\}  }_{i = 1}^{{c}_{s}}$ , which indicates that ${Y}_{t} \cap  {Y}_{s} = \varnothing$ .

在这项工作中，我们专注于文本和图像之间的零样本和少样本跨模态检索。给定源域的实例集${X}_{s} = {\left\{  {\mathbf{x}}_{i}\right\}  }_{i = 1}^{{n}_{s}}$和目标域的实例集${X}_{t} = {\left\{  {\mathbf{x}}_{j}\right\}  }_{j = 1}^{{n}_{t}}$，它们分别包含${n}_{s}$和${n}_{t}$个样本。以源域集${X}_{s}$为例，第$i$个样本定义为${\mathbf{x}}_{i} = \left( {{\mathbf{v}}_{i},{\mathbf{t}}_{i},{\mathbf{a}}_{i},{\mathbf{y}}_{i}}\right)$，其中${\mathbf{v}}_{i} \in  {\mathbb{R}}^{{d}_{v}}$和${\mathbf{t}}_{i} \in  {\mathbb{R}}^{{d}_{t}}$是具有相同语义信息的图像 - 文本对。${\mathbf{y}}_{i}$是类别标签，${\mathbf{a}}_{i} = \operatorname{attri}\left( {\mathbf{y}}_{i}\right)$是${\mathbf{y}}_{i}$对应的类别属性特征。值得注意的是，目标域${Y}_{t} = {\left\{  {\mathbf{y}}_{j}\right\}  }_{j = 1}^{{c}_{t}}$中的类别标签集与源域${Y}_{s} = {\left\{  {\mathbf{y}}_{i}\right\}  }_{i = 1}^{{c}_{s}}$中的完全不同，这表明${Y}_{t} \cap  {Y}_{s} = \varnothing$。

In the few-shot scenario, the model can be trained using samples from both the source domain ${X}_{s}$ and a small number of samples from the target domain ${X}_{t}$ , and then tested on the target domain ${X}_{t}$ . In the zero-shot scenario, the model can only be trained by using the samples in the source domain ${X}_{s}$ and then tested on the target domain ${X}_{t}$ .

在少样本场景中，可以使用来自源域 ${X}_{s}$ 的样本和少量来自目标域 ${X}_{t}$ 的样本对模型进行训练，然后在目标域 ${X}_{t}$ 上进行测试。在零样本场景中，模型只能使用源域 ${X}_{s}$ 中的样本进行训练，然后在目标域 ${X}_{t}$ 上进行测试。

## B. Model Architecture

## B. 模型架构

The general framework of our model is shown in Figure 3 In Feature Extraction (Sec. III-C), We utilize three pre-trained feature extractors to extract features from images, class labels, and text, respectively. In Multimodal Feature Generation (Sec. III-D), we propose a composite VAE-GAN network. After the features are encoded via their respective encoders, the generator decodes the VAE reconstructed features respectively, and the VAE loss is applied to learn the distribution pattern of features. In addition, the generators generate pseudo-sample features based on category attributes, which are inputted into the discriminator along with the VAE reconstructed features. In Common Space Projection (Sec. III-E), we first propose a projector that maps the real original features common space together, and then propose a residual gate network to selectively fuse the original features and the projected features. Finally, we design three loss functions to narrow the modality gap and facilitate the retrieval performance.

我们模型的总体框架如图3所示。在特征提取(第三节C部分)中，我们利用三个预训练的特征提取器分别从图像、类别标签和文本中提取特征。在多模态特征生成(第三节D部分)中，我们提出了一个复合VAE - GAN网络。特征通过各自的编码器进行编码后，生成器分别对VAE重建的特征进行解码，并应用VAE损失来学习特征的分布模式。此外，生成器根据类别属性生成伪样本特征，这些特征与VAE重建的特征一起输入到判别器中。在公共空间投影(第三节E部分)中，我们首先提出一个投影器，将真实的原始特征映射到公共空间，然后提出一个残差门控网络来选择性地融合原始特征和投影后的特征。最后，我们设计了三个损失函数来缩小模态差距并提升检索性能。

## C. Feature Extraction

## C. 特征提取

Before the process of feature generation, we need to map the origin text and image data in the multimodal dataset from the real scenario spaces to their original feature spaces, respectively. We adopt the CLIP [22] model as the feature extraction framework. For image modalities, we leverage the CLIP image encoder with ResNet-50 [50] backbone to extract 1,024-d features as the original image feature $\mathbf{v}$ . For text modality, we apply a CLIP text encoder with BERT [51] backbone to extract 1,024-d features as the original text feature t. For class embedding, different from the most recent used Word2Vec as the extractor, we introduce prompt engineering to construct the category words as text statements and then utilize the CLIP text encoder for attribute embedding extraction to obtain the 1024-d features as category attribute embedding a, which ensures the consistency between image-text-category attributes.

在特征生成过程之前，我们需要将真实场景空间中的多模态数据集中的原始文本和图像数据分别映射到它们的原始特征空间。我们采用CLIP [22] 模型作为特征提取框架。对于图像模态，我们利用具有ResNet - 50 [50] 骨干网络的CLIP图像编码器提取1024维特征作为原始图像特征 $\mathbf{v}$ 。对于文本模态，我们应用具有BERT [51] 骨干网络的CLIP文本编码器提取1024维特征作为原始文本特征t。对于类别嵌入，与最近常用的Word2Vec作为提取器不同，我们引入提示工程将类别词构建为文本语句，然后利用CLIP文本编码器进行属性嵌入提取，以获得1024维特征作为类别属性嵌入a，这确保了图像 - 文本 - 类别属性之间的一致性。

## D. Multimodal Feature Generation

## D. 多模态特征生成

In contrast with methods such as image generation for pixel-level images or text generation for word-level text, we aim to generate feature-level multimodal data for downstream multimodal projector. For each modality, we respectively construct a composite VAE-GAN network to fully leverage the advantages of VAE in capturing sample feature distribution and GAN in stabilizing feature generation.

与像素级图像生成或词级文本生成等方法不同，我们旨在为下游多模态投影器生成特征级多模态数据。对于每个模态，我们分别构建一个复合VAE - GAN网络，以充分利用VAE在捕捉样本特征分布方面的优势和GAN在稳定特征生成方面的优势。

Each network consists of three main components: an encoder ${E}_{ * }\left( \cdot \right)$ , a generator ${G}_{ * }\left( \cdot \right)$ , and a discriminator ${D}_{ * }\left( \cdot \right)$ , where $*  = \{ v, t\}$ denotes the image and text modalities respectively, and each of the VAE-GAN network consists of multiple fully connected layers. It is worth noting that ${G}_{ * }\left( \cdot \right)$ is not only a generative network in the GAN network to generate multimodal pseudo samples from the feature space, but also a decoder in the VAE network that can reconstruct the original data according to the latent variable embedding after encoder. ${G}_{ * }\left( \cdot \right)$ is constrained by both VAE and GAN networks during the training process, which enables the model to optimize the authenticity and diversity of generated samples at the same time, so as to improve the feature generation effect. We take image modality as an example to introduce the specific structure of our proposed multimodal feature generation.

每个网络由三个主要组件组成:一个编码器 ${E}_{ * }\left( \cdot \right)$ 、一个生成器 ${G}_{ * }\left( \cdot \right)$ 和一个判别器 ${D}_{ * }\left( \cdot \right)$ ，其中 $*  = \{ v, t\}$ 分别表示图像和文本模态，并且每个VAE - GAN网络由多个全连接层组成。值得注意的是， ${G}_{ * }\left( \cdot \right)$ 不仅是GAN网络中从特征空间生成多模态伪样本的生成网络，也是VAE网络中可以根据编码器后的潜在变量嵌入重建原始数据的解码器。 ${G}_{ * }\left( \cdot \right)$ 在训练过程中受到VAE和GAN网络的双重约束，这使得模型能够同时优化生成样本的真实性和多样性，从而提高特征生成效果。我们以图像模态为例介绍我们提出的多模态特征生成的具体结构。

1) VAE Network: In the VAE, we first input the image feature ${\mathbf{v}}_{i}$ and its corresponding class embedding ${\mathbf{a}}_{i}$ into the encoder ${E}_{v}\left( \cdot \right)$ to obtain a latent variable ${z}_{i}^{v} = {E}_{v}\left( {{\mathbf{v}}_{i},{\mathbf{a}}_{i}}\right)$ . Then generator ${G}_{v}\left( \cdot \right)$ reconstructs the input feature ${\mathbf{v}}_{i}$ based on the latent variable ${z}_{i}^{v}$ and class embedding ${\mathbf{a}}_{i}$ to obtain the reconstruction feature ${\overline{\mathbf{v}}}_{i} = {G}_{v}\left( {{z}_{i}^{v},{\mathbf{a}}_{i}}\right)$ . The objective function of this image VAE network is:

1) 变分自编码器(VAE)网络:在变分自编码器中，我们首先将图像特征 ${\mathbf{v}}_{i}$ 及其对应的类别嵌入 ${\mathbf{a}}_{i}$ 输入到编码器 ${E}_{v}\left( \cdot \right)$ 中，以获得一个潜在变量 ${z}_{i}^{v} = {E}_{v}\left( {{\mathbf{v}}_{i},{\mathbf{a}}_{i}}\right)$。然后，生成器 ${G}_{v}\left( \cdot \right)$ 根据潜在变量 ${z}_{i}^{v}$ 和类别嵌入 ${\mathbf{a}}_{i}$ 对输入特征 ${\mathbf{v}}_{i}$ 进行重构，以获得重构特征 ${\overline{\mathbf{v}}}_{i} = {G}_{v}\left( {{z}_{i}^{v},{\mathbf{a}}_{i}}\right)$。该图像变分自编码器网络的目标函数为:

$$
{\mathcal{L}}_{VAE}^{v} = {D}_{KL}\left( {{q}_{{\theta }_{{E}_{v}}}\left( {{z}^{v} \mid  \mathbf{v},\mathbf{a}}\right) \parallel p\left( {{z}^{v} \mid  \mathbf{a}}\right) }\right)  \tag{1}
$$

$$
- {\mathbb{E}}_{{q}_{{\theta }_{{E}_{v}}}\left( {{z}^{v} \mid  \mathbf{v},\mathbf{a}}\right) }\left( {\log {p}_{{\theta }_{{G}_{v}}}\left( {\mathbf{v} \mid  {z}^{v},\mathbf{a}}\right) }\right) ,
$$

where the former term is the Kullback-Leibler divergence loss function measuring the difference in distribution between the latent variable ${z}_{i}^{v}$ and the prior probability $p\left( {{z}^{v} \mid  \mathbf{a}}\right)$ . The $p\left( {{z}^{v} \mid  \mathbf{a}}\right)$ is generally defined as the standard normal distribution. The latter term is the reconstruction loss function, which measures the element-level difference between the reconstructed image feature $\overline{\mathbf{v}}$ and the original image feature V.

其中，前一项是KL散度(Kullback-Leibler divergence)损失函数，用于衡量潜在变量 ${z}_{i}^{v}$ 和先验概率 $p\left( {{z}^{v} \mid  \mathbf{a}}\right)$ 之间的分布差异。$p\left( {{z}^{v} \mid  \mathbf{a}}\right)$ 通常定义为标准正态分布。后一项是重构损失函数，用于衡量重构后的图像特征 $\overline{\mathbf{v}}$ 与原始图像特征V之间的元素级差异。

2) GAN Network: In addition to VAE network, our CoFeG integrates a GAN network contributing to generating pseudo samples of target domain based on the class attribute information in the target domain, thereby alleviating the extreme sample size imbalance between the target and source domain. In particular, we concatenate class embedding ${\mathbf{a}}_{i}$ with a Gaussian noise vector $z \sim  \mathcal{N}\left( {0,1}\right)$ and input them into the generator ${G}_{v}\left( \cdot \right)$ for generating pseudo samples ${\widetilde{\mathbf{v}}}_{i} = {G}_{v}\left( {{z}_{i},{\mathbf{a}}_{i}}\right)$ . Meanwhile, a class conditional discriminator ${D}_{v}\left( \cdot \right)$ is applied to determine whether the input samples $\left( {\widetilde{\mathbf{v}}}_{i}\right.$ and $\left. {\mathbf{v}}_{i}\right)$ are real samples or generated samples. By the adversarial training between ${D}_{v}$ and ${G}_{v}$ , the discriminator is able to provide continuous feedback to the generator, which leads to generate pseudo samples that are more consistent with the distribution of real data. In addition, the more stable Wasserstein GAN model is used as the main architecture of the GAN network, and the objective function of the network is

2) 生成对抗网络(GAN):除了变分自编码器网络外，我们的协同特征生成网络(CoFeG)还集成了一个生成对抗网络，该网络有助于基于目标域中的类别属性信息生成目标域的伪样本，从而缓解目标域和源域之间极端的样本数量不平衡问题。具体而言，我们将类别嵌入 ${\mathbf{a}}_{i}$ 与一个高斯噪声向量 $z \sim  \mathcal{N}\left( {0,1}\right)$ 拼接，并将它们输入到生成器 ${G}_{v}\left( \cdot \right)$ 中以生成伪样本 ${\widetilde{\mathbf{v}}}_{i} = {G}_{v}\left( {{z}_{i},{\mathbf{a}}_{i}}\right)$。同时，应用一个类别条件判别器 ${D}_{v}\left( \cdot \right)$ 来判断输入样本 $\left( {\widetilde{\mathbf{v}}}_{i}\right.$ 和 $\left. {\mathbf{v}}_{i}\right)$ 是真实样本还是生成样本。通过 ${D}_{v}$ 和 ${G}_{v}$ 之间的对抗训练，判别器能够向生成器提供持续的反馈，从而生成更符合真实数据分布的伪样本。此外，更稳定的Wasserstein生成对抗网络模型被用作生成对抗网络的主要架构，该网络的目标函数为

$$
{\mathcal{L}}_{{GAN} - 1}^{v} = \mathbb{E}\left\lbrack  {{D}_{v}\left( {\mathbf{v},\mathbf{a};{\theta }_{{D}_{v}}}\right) }\right\rbrack   - \mathbb{E}\left\lbrack  {{D}_{v}\left( {\widetilde{\mathbf{v}},\mathbf{a};{\theta }_{{D}_{v}},{\theta }_{{G}_{v}}}\right) }\right\rbrack   \tag{2}
$$

$$
- \lambda \mathbb{E}\left\lbrack  {{\left( {\begin{Vmatrix}{\nabla }_{\widehat{\mathbf{v}}}{D}_{v}\left( \widehat{\mathbf{v}},\mathbf{a}\right) \end{Vmatrix}}_{2} - 1\right) }^{2};{\theta }_{{D}_{v}}}\right\rbrack  ,
$$

where the first and second terms of the expression are the discriminant scores of real sample $\mathbf{v}$ and the generated sample $\widetilde{\mathbf{v}}$ , respectively. The third term is a gradient penalty, which helps to prevent pattern collapse during training by constraining the gradient change of the discriminator in the sample space. $\lambda$ is the penalty coefficient, ${\nabla }_{\widehat{\mathbf{v}}}{D}_{v}\left( {\widehat{\mathbf{v}},\mathbf{a}}\right)$ calculates the gradient of the output of ${D}_{v}$ relative to the input feature $\widehat{\mathbf{v}}$ , and the $\widehat{\mathbf{v}}$ is defined as

其中，表达式的第一项和第二项分别是真实样本 $\mathbf{v}$ 和生成样本 $\widetilde{\mathbf{v}}$ 的判别得分。第三项是梯度惩罚项，它通过约束判别器在样本空间中的梯度变化，有助于防止训练过程中出现模式崩溃问题。$\lambda$ 是惩罚系数，${\nabla }_{\widehat{\mathbf{v}}}{D}_{v}\left( {\widehat{\mathbf{v}},\mathbf{a}}\right)$ 计算 ${D}_{v}$ 的输出相对于输入特征 $\widehat{\mathbf{v}}$ 的梯度，并且 $\widehat{\mathbf{v}}$ 定义为

$$
\widehat{\mathbf{v}} = \epsilon \mathbf{v} + \left( {1 - \epsilon }\right) \widetilde{\mathbf{v}}.\;\epsilon  \sim  U\left( {0,1}\right) , \tag{3}
$$

On the other hand, in order to make the VAE network more effective in feature reconstruction and better fit the original feature distribution pattern, the discriminator ${D}_{v}$ is further used to train the VAE network:

另一方面，为了使变分自编码器网络在特征重构方面更有效，并更好地拟合原始特征分布模式，进一步使用判别器 ${D}_{v}$ 来训练变分自编码器网络:

$$
{\mathcal{L}}_{{GAN} - 2}^{v} = \mathbb{E}\left\lbrack  {{D}_{v}\left( {\mathbf{v},\mathbf{a};{\theta }_{{D}_{v}}}\right) }\right\rbrack   - \mathbb{E}\left\lbrack  {{D}_{v}\left( {\overline{\mathbf{v}},\mathbf{a};{\theta }_{{D}_{v}},{\theta }_{{G}_{v}},{\theta }_{{E}_{v}}}\right) }\right\rbrack
$$

$$
- \lambda \mathbb{E}\left\lbrack  {{\left( {\begin{Vmatrix}{\nabla }_{\widehat{\mathbf{v}}}{D}_{v}\left( \widehat{\mathbf{v}},\mathbf{a}\right) \end{Vmatrix}}_{2} - 1\right) }^{2};{\theta }_{{D}_{v}}}\right\rbrack  .
$$

(4)

By introducing a discriminator, the model can learn more detailed information about the feature distribution during the reconstruction process, thereby improving the quality of the generated samples.

通过引入判别器，模型可以在重构过程中学习到关于特征分布的更详细信息，从而提高生成样本的质量。

3) Integrated Objective Function: By combining VAE and GAN, the multimodal feature generation model proposed combines the advantages of VAE and GAN networks. On the one hand, the real feature distribution rules can be learned by encoding and reconstructing real samples. On the other hand, since the encoder’s output of the latent variable ${z}_{i}$ and the random sampling noise $z$ conform to the same feature distribution, the generator can leverage the distribution rules learned from reconstructing the real samples, contributing to generate more realistic pseudo samples. Combined with the optimization objectives of VAE and GAN, the overall objective function of the feature generation model is as follows:

3) 综合目标函数:通过结合变分自编码器(VAE)和生成对抗网络(GAN)，所提出的多模态特征生成模型融合了VAE和GAN网络的优势。一方面，通过对真实样本进行编码和重构，可以学习到真实特征的分布规律。另一方面，由于编码器输出的潜在变量 ${z}_{i}$ 和随机采样噪声 $z$ 符合相同的特征分布，生成器可以利用从重构真实样本中学习到的分布规律，有助于生成更逼真的伪样本。结合VAE和GAN的优化目标，特征生成模型的整体目标函数如下:

$$
{\mathcal{L}}_{{VAE} - {GAN}}^{ * } = {\mathcal{L}}_{VAE}^{ * } + {\mathcal{L}}_{{GAN} - 1}^{ * } + {\mathcal{L}}_{{GAN} - 2}^{ * }, \tag{5}
$$

During training, the encoder ${E}_{ * }$ and generator ${G}_{ * }$ deceive the discriminant network by minimizing the above objective function, while the discriminator ${D}_{ * }$ improves the discrimination ability of the generated samples by maximizing the objective function. Through adversarial training between ${E}_{ * }$ , ${G}_{ * }$ and ${D}_{ * }$ , the discriminant network can provide more reliable feedback, which can guide the generation of network synthesis of more realistic samples. Therefore, the overall optimization goals of the image modal and text modal feature generation models are:

在训练过程中，编码器 ${E}_{ * }$ 和生成器 ${G}_{ * }$ 通过最小化上述目标函数来欺骗判别网络，而判别器 ${D}_{ * }$ 则通过最大化目标函数来提高对生成样本的判别能力。通过 ${E}_{ * }$、${G}_{ * }$ 和 ${D}_{ * }$ 之间的对抗训练，判别网络可以提供更可靠的反馈，从而指导网络合成更逼真的样本。因此，图像模态和文本模态特征生成模型的总体优化目标为:

$$
\mathop{\min }\limits_{{{\theta }_{{G}_{v}},{\theta }_{{G}_{t}},{\theta }_{{E}_{v}},{\theta }_{{E}_{t}}}}\mathop{\max }\limits_{{{\theta }_{{D}_{v}},{\theta }_{{D}_{t}}}}{\mathcal{L}}_{{VAE} - {GAN}}^{v} + {\mathcal{L}}_{{VAE} - {GAN}}^{t}. \tag{6}
$$

where ${\theta }_{{G}_{v}},{\theta }_{{G}_{t}}$ are the model parameters of the generator, ${\theta }_{{E}_{v}},{\theta }_{{E}_{t}}$ are the model parameters of the encoder, and ${\theta }_{{D}_{v}},{\theta }_{{D}_{t}}$ are the model parameters of the discriminator.

其中 ${\theta }_{{G}_{v}},{\theta }_{{G}_{t}}$ 是生成器的模型参数，${\theta }_{{E}_{v}},{\theta }_{{E}_{t}}$ 是编码器的模型参数，${\theta }_{{D}_{v}},{\theta }_{{D}_{t}}$ 是判别器的模型参数。

## E. Multimodal Feature Projection

## E. 多模态特征投影

Since we propose a multimodal feature generation model based on VAE-GAN composite architecture, the model can effectively generate the corresponding multimodal samples based on the target domain class $\mathbf{a} \in  {A}_{t}$ after training on the source domain entity set ${X}_{s}$ . This section introduce the multimodal feature mapping stage.

由于我们提出了一种基于VAE - GAN复合架构的多模态特征生成模型，该模型在源域实体集 ${X}_{s}$ 上进行训练后，能够基于目标域类别 $\mathbf{a} \in  {A}_{t}$ 有效地生成相应的多模态样本。本节介绍多模态特征映射阶段。

1) Gate Residual Network: In the cross-modal retrieval stage, similar to previous methods, we design two projectors ${P}_{v}\left( \cdot \right)$ and ${P}_{t}\left( \cdot \right)$ to map the features of the image and text modalities into a common space. These projectors mainly consist of multiple fully connected layers, and the common space projections of image modality is as follows:

1) 门控残差网络:在跨模态检索阶段，与以往的方法类似，我们设计了两个投影器 ${P}_{v}\left( \cdot \right)$ 和 ${P}_{t}\left( \cdot \right)$，将图像和文本模态的特征映射到一个公共空间。这些投影器主要由多个全连接层组成，图像模态的公共空间投影如下:

$$
{\mathbf{f}}_{i}^{v} = {P}_{v}\left( {\mathbf{v}}_{i}\right) . \tag{7}
$$

To better utilize the knowledge extracted by vision-language pretraining model and alleviate the feature degradation, we propose a gate residual network ${\operatorname{Gate}}_{ * }\left( \cdot \right)$ to selectively fuse CLIP's original features and mapped features from mapper ${P}_{ * }\left( \cdot \right)$ . Specifically, we concatenate the original features ${ * }_{i}$ and the mapped features ${\mathbf{f}}_{i}^{ * }$ into the gate network to obtain a gate coefficient ${\mathbf{g}}_{i}^{ * } \in  {\mathbb{R}}^{d}$ :

为了更好地利用视觉 - 语言预训练模型提取的知识并缓解特征退化问题，我们提出了一种门控残差网络 ${\operatorname{Gate}}_{ * }\left( \cdot \right)$，用于选择性地融合CLIP的原始特征和映射器 ${P}_{ * }\left( \cdot \right)$ 的映射特征。具体来说，我们将原始特征 ${ * }_{i}$ 和映射特征 ${\mathbf{f}}_{i}^{ * }$ 拼接成门控网络，以获得门控系数 ${\mathbf{g}}_{i}^{ * } \in  {\mathbb{R}}^{d}$:

$$
{\mathbf{g}}_{i}^{ * } = {\operatorname{Gate}}_{ * }\left( {{ * }_{i} \oplus  {\mathbf{f}}_{i}^{ * }}\right) , \tag{8}
$$

where $\oplus$ is the concatenation operation. The gate residual network outputs coefficient vectors ${\mathbf{g}}_{i}^{ * }$ according to the characteristics of the mapping features and the original features, and flexibly adjust the fusion ratio of the two features in each dimension, so as to improve the generalization ability of the few-shot multimodal projection.

其中 $\oplus$ 是拼接操作。门控残差网络根据映射特征和原始特征的特点输出系数向量 ${\mathbf{g}}_{i}^{ * }$，并灵活调整每个维度上两种特征的融合比例，从而提高少样本多模态投影的泛化能力。

Finally, the coefficient vector ${\mathbf{g}}_{i}^{ * }$ is element-wise multiplied with the projected features and original features to obtain the final common space mapping features ${\mathbf{u}}_{i}^{v},{\mathbf{u}}_{i}^{t}$ :

最后，将系数向量 ${\mathbf{g}}_{i}^{ * }$ 与投影特征和原始特征逐元素相乘，以获得最终的公共空间映射特征 ${\mathbf{u}}_{i}^{v},{\mathbf{u}}_{i}^{t}$:

$$
{\mathbf{u}}_{i}^{v} = {\mathbf{g}}_{i}^{v} \times  {\mathbf{f}}_{i}^{v} + \left( {1 - {\mathbf{g}}_{i}^{v}}\right)  \times  {\mathbf{v}}_{i}, \tag{9}
$$

$$
{\mathbf{u}}_{i}^{t} = {\mathbf{g}}_{i}^{t} \times  {\mathbf{f}}_{i}^{t} + \left( {1 - {\mathbf{g}}_{i}^{t}}\right)  \times  {\mathbf{t}}_{i}. \tag{10}
$$

2) Objective Function: In order to realize the training of the above multimodal feature projecting model, three different objective loss functions are proposed: classification loss, modal consistency loss, and contrastive learning loss. First, since class labels are important for common space projection, we use a linear mapping layer with a Softmax activation function, based on the common space mapping feature ${\mathbf{u}}_{i}^{ * }$ and class label of predicted samples ${\widehat{\mathbf{y}}}_{i}^{ * }$ , and compute the cross-entropy loss function:

2) 目标函数:为了实现上述多模态特征投影模型的训练，我们提出了三种不同的目标损失函数:分类损失、模态一致性损失和对比学习损失。首先，由于类别标签对于公共空间投影很重要，我们使用一个带有Softmax激活函数的线性映射层，基于公共空间映射特征 ${\mathbf{u}}_{i}^{ * }$ 和预测样本的类别标签 ${\widehat{\mathbf{y}}}_{i}^{ * }$，计算交叉熵损失函数:

$$
{\mathcal{L}}_{1} =  - \frac{1}{n}\mathop{\sum }\limits_{{i = 1}}^{n}\mathop{\sum }\limits_{{c = 1}}^{C}\left( {{\mathbf{y}}_{ic}\log \left( {\widehat{\mathbf{y}}}_{ic}^{v}\right)  + {\mathbf{y}}_{ic}\log \left( {\widehat{\mathbf{y}}}_{ic}^{t}\right) }\right) , \tag{11}
$$

where $C$ is the number of class, $n$ is the overall number of the real samples and the generated samples during training.

其中 $C$ 是类别数量，$n$ 是训练期间真实样本和生成样本的总数。

Second, the pairwise relations between modalities plays an important role in bridging the heterogeneity gap, and the distance between paired cross-modal samples in the common space should be as small as possible. Hence, we design a modal consistency loss:

其次，模态之间的成对关系在弥合异质性差距方面起着重要作用，并且公共空间中成对跨模态样本之间的距离应尽可能小。因此，我们设计了一种模态一致性损失:

$$
{\mathcal{L}}_{2} =  - \frac{1}{n}\mathop{\sum }\limits_{{i = 1}}^{n}{\begin{Vmatrix}{\mathbf{u}}_{i}^{v} - {\mathbf{u}}_{i}^{t}\end{Vmatrix}}_{2}. \tag{12}
$$

Finally, we introduce an instance-level contrast learning loss function to pull in pairwise cross-modal samples and push away unpaired samples. The cross-modal comparison learning

最后，我们引入了一种实例级对比学习损失函数，以拉近成对的跨模态样本并推开未配对的样本。跨模态对比学习

loss is:

损失为:

$$
{\mathcal{L}}_{3} =  - \frac{1}{n}\mathop{\sum }\limits_{{ * }_{i}}^{{v, t}}\mathop{\sum }\limits_{{i = 1}}^{n}\log \left( {P\left( {\mathbf{u}}_{i}^{{ * }_{i}}\right) }\right) , \tag{13}
$$

where $P\left( {\mathbf{u}}_{i}^{{ * }_{i}}\right)$ is the matching similarity between ${\mathbf{u}}_{i}^{{ * }_{i}}$ and its paired entities. Specifically, we calculate the similarity between ${\mathbf{u}}_{i}^{{ * }_{i}}$ and all other entities in the same training batch and normalize:

其中 $P\left( {\mathbf{u}}_{i}^{{ * }_{i}}\right)$ 是 ${\mathbf{u}}_{i}^{{ * }_{i}}$ 与其配对实体之间的匹配相似度。具体来说，我们计算 ${\mathbf{u}}_{i}^{{ * }_{i}}$ 与同一训练批次中所有其他实体之间的相似度并进行归一化:

$$
P\left( {\mathbf{u}}_{i}^{{ * }_{i}}\right)  = \frac{\exp \left( {\cos \left( {{\mathbf{u}}_{i}^{v},{\mathbf{u}}_{i}^{t}}\right) /\tau }\right) }{\mathop{\sum }\limits_{{{ * }_{i},{ * }_{j}}}^{{v, t}}\mathop{\sum }\limits_{{j = 1}}^{n}\exp \left( {\cos \left( {{\mathbf{u}}_{j}^{{ * }_{j}},{\mathbf{u}}_{i}^{{ * }_{i}}}\right) /\tau }\right) }, \tag{14}
$$

where ${ * }_{i},{ * }_{j}$ are the modal categories of samples ${\mathbf{u}}_{i}^{{ * }_{i}},{\mathbf{u}}_{j}^{{ * }_{j}}$ , $\cos \left( {\cdot , \cdot  }\right)$ is the cosine similarity function between the two eigenvectors, and $\tau$ is a temperature coefficient that adjusts the model's attention to pairs of cross-modal samples.

其中 ${ * }_{i},{ * }_{j}$ 是样本 ${\mathbf{u}}_{i}^{{ * }_{i}},{\mathbf{u}}_{j}^{{ * }_{j}}$ 的模态类别，$\cos \left( {\cdot , \cdot  }\right)$ 是两个特征向量之间的余弦相似度函数，$\tau$ 是一个温度系数，用于调整模型对跨模态样本对的关注度。

In summary, in the multimodal feature mapping stage, the overall optimization of the model are:

综上所述，在多模态特征映射阶段，模型的整体优化目标为:

$$
\mathcal{L} = \alpha {\mathcal{L}}_{1} + \beta {\mathcal{L}}_{2} + \gamma {\mathcal{L}}_{3}, \tag{15}
$$

where $\alpha ,\beta ,\gamma$ are a set of hyper-parameters that are used to balance the weights of different optimization goals during model training.

其中 $\alpha ,\beta ,\gamma$ 是一组超参数，用于在模型训练期间平衡不同优化目标的权重。

## IV. EXPERIMENTS

## 四、实验

## A. Datasets

## A. 数据集

We evaluate our model on image-text retrieval, which includes four widely used benchmark datasets: Wikipedia [1], Pascal Sentence [39], NUS-WIDE [40], and NUS-WIDE-10K [40].

我们在图像 - 文本检索任务上评估我们的模型，该任务包括四个广泛使用的基准数据集:维基百科(Wikipedia)[1]、Pascal 句子数据集(Pascal Sentence)[39]、NUS - WIDE 数据集[40]和 NUS - WIDE - 10K 数据集[40]。

- Wikipedia has 2,866 instances of image-text pairs that are crawled from the Wikipedia website, and each instance has one label from ten categories. In order to ensure the rationality of the experiment, 2,173 and 693 pairs of image-text entities are randomly selected from the dataset as the original training set and the original test set, respectively.

- 维基百科数据集有 2866 个从维基百科网站爬取的图像 - 文本对实例，每个实例有一个来自十个类别的标签。为了确保实验的合理性，分别从数据集中随机选择 2173 对和 693 对图像 - 文本实体作为原始训练集和原始测试集。

- Pascal Sentence consists of 1,000 images, with each image belonging to one of the predefined 20 categories. Each image is also described in five textual sentences. In our experiment, 800 and 200 pairs of image-text entities are randomly selected from the dataset as the original training set and the original test set, respectively.

- Pascal 句子数据集由 1000 张图像组成，每张图像属于预定义的 20 个类别之一。每张图像还由五个文本句子描述。在我们的实验中，分别从数据集中随机选择 800 对和 200 对图像 - 文本实体作为原始训练集和原始测试集。

- NUS-WIDE contains 270,000 images with associated tags, where images belong to at least one of the 81 categories. We refer to the previous method [14] to extract 42,859 pairs of image-text entities from the 10 categories with the highest occurrence frequency of the dataset to form the NUS-WIDE dataset. Its original training set and original test set contained 25,685 and 12,174 pairs of samples, respectively.

- NUS - WIDE 数据集包含 270000 张带有相关标签的图像，其中图像至少属于 81 个类别之一。我们参考先前的方法[14]，从数据集中出现频率最高的 10 个类别中提取 42859 对图像 - 文本实体，以形成 NUS - WIDE 数据集。其原始训练集和原始测试集分别包含 25685 对和 12174 对样本。

TABLE I

THE STATISTICS OF THE FOUR DATASETS. "XX/XX" DENOTES "SEEN/UNSEEN" IN "CLASS" OR "IMAGE/TEXT" IN "TRAIN" AND "TEST".

四个数据集的统计信息。“XX/XX”在“类别”中表示“已见/未见”，在“训练”和“测试”中表示“图像/文本”。

<table><tr><td>Datasets</td><td>Pairs</td><td>Classes</td><td>Train</td><td>Test</td></tr><tr><td>Wikipedia</td><td>2,866</td><td>5/5</td><td>2,173/2,173</td><td>693/693</td></tr><tr><td>Pascal Sentence</td><td>1,000</td><td>10/10</td><td>800/800</td><td>200/200</td></tr><tr><td>NUSWIDE</td><td>42,859</td><td>5/5</td><td>25,685/25,685</td><td>12,174/12,174</td></tr><tr><td>Nuswide-10k</td><td>10,000</td><td>5/5</td><td>8,000/8,000</td><td>2,000/2,000</td></tr></table>

<table><tbody><tr><td>数据集</td><td>配对</td><td>类别</td><td>训练</td><td>测试</td></tr><tr><td>维基百科</td><td>2,866</td><td>5/5</td><td>2,173/2,173</td><td>693/693</td></tr><tr><td>帕斯卡句子</td><td>1,000</td><td>10/10</td><td>800/800</td><td>200/200</td></tr><tr><td>新加坡国立大学图像数据集(NUSWIDE)</td><td>42,859</td><td>5/5</td><td>25,685/25,685</td><td>12,174/12,174</td></tr><tr><td>新加坡国立大学图像10k子集(Nuswide - 10k)</td><td>10,000</td><td>5/5</td><td>8,000/8,000</td><td>2,000/2,000</td></tr></tbody></table>

![0195d6f2-b56e-7b0a-aee8-41fd975e38e0_5_224_435_577_485_0.jpg](images/0195d6f2-b56e-7b0a-aee8-41fd975e38e0_5_224_435_577_485_0.jpg)

Fig. 4. The illustration of the dataset splitting setting.

图4. 数据集划分设置的示意图。

- Nuswide-10k is a simplified version of NUS-WIDE, which contains 10,000 pairs image-text instance. In this work, 1,000 pairs of image-text entities are randomly selected from the 10 most frequent categories of the NUS-WIDE dataset to form the NUS-WIDE-10K dataset by referring to the previous method [52]. Its original training set and original test set contained 8,000 and 2,000 pairs of samples, respectively.

- Nuswide - 10k是NUS - WIDE数据集的简化版本，包含10000对图像 - 文本实例。在这项工作中，参考先前的方法[52]，从NUS - WIDE数据集中10个最常见的类别中随机选取1000对图像 - 文本实体，组成NUS - WIDE - 10K数据集。其原始训练集和原始测试集分别包含8000对和2000对样本。

In the few-shot scenario, the original dataset needs to be divided in more detail because the data categories of the source domain and the target domain are different. We further divide the dataset into four subsets: Target Data Set, Source Data Set, Target Query Set, and Source Query Set. The target domain and the source domain each contain ${50}\%$ of the data categories, as shown in Figure 4. In the training stage, the model is trained on the source domain set. In the validation phase, the model takes the data in the source domain query set as a query and retrieves the data in the source domain sample set, and in the testing stage, the model extracts the data from the target domain query set as a query and retrieves the data in the target domain sample set. The statistics of the four datasets are shown in the table II

在少样本场景下，由于源域和目标域的数据类别不同，需要对原始数据集进行更详细的划分。我们进一步将数据集划分为四个子集:目标数据集、源数据集、目标查询集和源查询集。目标域和源域各包含${50}\%$个数据类别，如图4所示。在训练阶段，模型在源域集上进行训练。在验证阶段，模型将源域查询集中的数据作为查询，在源域样本集中检索数据；在测试阶段，模型将目标域查询集中的数据作为查询，在目标域样本集中检索数据。四个数据集的统计信息如表II所示。

## B. Evaluation Metric and Baseline Models

## B. 评估指标和基线模型

For the evaluation metric, we calculate the mean average precision (MAP) score for image-to-text retrieval (using image queries) and text-to-image retrieval (using text queries). We first calculate the average precision (AP) :

对于评估指标，我们计算图像到文本检索(使用图像查询)和文本到图像检索(使用文本查询)的平均精度均值(MAP)得分。我们首先计算平均精度(AP):

$$
{AP} = \frac{1}{T}\mathop{\sum }\limits_{{r = 1}}^{R}{P}_{r} \times  \delta \left( r\right)  \tag{16}
$$

where $R$ is the set of retrieved items, $T$ is the number of relevant items in the retrieved items, $P\left( r\right)$ denotes the precision of the top $r$ retrieved items, and $\delta \left( r\right)$ is an indicator function. We adopt the cosine distance to measure the similarity of features. If the $r$ -th item is relevant to the query, the value of $\delta \left( r\right)$ is 1. The MAP is the mean value of the AP score, which jointly considers the ranking information and precision:

其中$R$是检索到的项目集合，$T$是检索到的项目中相关项目的数量，$P\left( r\right)$表示前$r$个检索到的项目的精度，$\delta \left( r\right)$是一个指示函数。我们采用余弦距离来衡量特征的相似度。如果第$r$个项目与查询相关，则$\delta \left( r\right)$的值为1。MAP是AP得分的均值，它同时考虑了排名信息和精度:

$$
\mathrm{{mAP}} = \frac{1}{n}\mathop{\sum }\limits_{{i = 1}}^{n}\mathrm{{AP}}\left( i\right) , \tag{17}
$$

where $n$ is the number of the query.

其中$n$是查询的数量。

To evaluate our model, we conduct experiments on image-to-text (Img2Txt) and text-to-image (Txt2Img) tasks under the zero-shot and few-shot scenarios. Particularly, the latter scenario includes 1-shot, 3-shot, and 5-shot. We compare our proposed FLEX-CLIP method with 10 state-of-the-art methods on the retrieval tasks, including CCA [23], DSCMR [31], MARS [25], MRL [26], DADN [7], CFSA [5], JSFE [13], MDVAE [12], CLIP [22]. We reimplement these models and the experimental results are shown in Table IV-C. We briefly describe the baseline models as follows:

为了评估我们的模型，我们在零样本和少样本场景下对图像到文本(Img2Txt)和文本到图像(Txt2Img)任务进行了实验。特别是，少样本场景包括1 - 样本、3 - 样本和5 - 样本。我们将我们提出的FLEX - CLIP方法与10种最先进的方法在检索任务上进行了比较，包括CCA [23]、DSCMR [31]、MARS [25]、MRL [26]、DADN [7]、CFSA [5]、JSFE [13]、MDVAE [12]、CLIP [22]。我们重新实现了这些模型，实验结果如表IV - C所示。我们简要描述基线模型如下:

- DSCMR [31] aims to find a common representation space, minimizes the discrimination loss in both the label space and the common representation space, and minimizes the modality loss with a weight-sharing strategy.

- DSCMR [31]旨在找到一个公共表示空间，最小化标签空间和公共表示空间中的判别损失，并通过权重共享策略最小化模态损失。

- MARS [25] treats the label information as a distinct modality and introduces a label parsing module, LabNet, to generate a semantic representation for correlating different modalities.

- MARS [25]将标签信息视为一种独特的模态，并引入了一个标签解析模块LabNet，以生成用于关联不同模态的语义表示。

- MRL [26] tries to learn with multimodal noisy labels to mitigate noisy samples and correlate distinct modalities simultaneously, consisting of a Robust Clustering loss (RC) and a Multimodal Contrastive loss (MC).

- MRL [26]尝试使用多模态噪声标签进行学习，以减轻噪声样本的影响并同时关联不同的模态，它由鲁棒聚类损失(RC)和多模态对比损失(MC)组成。

- DADN [7] learns common embeddings and explores the knowledge from word-embeddings of categories, in which zero-shot cross-media dual generative adversarial networks architecture is proposed, consisting of two kinds of generative GANs for common embedding generation.

- DADN [7]学习公共嵌入并探索类别词嵌入中的知识，其中提出了零样本跨媒体双生成对抗网络架构，由两种用于生成公共嵌入的生成对抗网络(GAN)组成。

- CFSA [5] integrates multimodal feature synthesis by utilizing class-level word embeddings to guide two coupled Wasserstein generative adversarial networks (WGANs) to synthesize sufficient multimodal features.

- CFSA [5]通过利用类级词嵌入来引导两个耦合的Wasserstein生成对抗网络(WGAN)合成足够的多模态特征，从而实现多模态特征合成。

- MDVAE [12] is a novel zero-shot cross-modal retrieval model, which consists of two coupled disentanglement variational autoencoders (DVAEs) and a fusion-exchange VAE (FVAE).

- MDVAE [12]是一种新颖的零样本跨模态检索模型，它由两个耦合的解纠缠变分自编码器(DVAEs)和一个融合交换变分自编码器(FVAE)组成。

- JFSE [13] jointly performs multimodal feature synthesis and common embedding space learning, consisting of two coupled conditional Wasserstein GAN modules for two modalities and three advanced distribution alignment schemes.

- JFSE [13]联合执行多模态特征合成和公共嵌入空间学习，由两个用于两种模态的耦合条件Wasserstein GAN模块和三种先进的分布对齐方案组成。

- CLIP [22] is a neural network trained on a variety of (image, text) pairs. It can be instructed in natural language to predict the most relevant text snippet, given an image, without directly optimizing for the task.

- CLIP [22]是一个在各种(图像，文本)对上训练的神经网络。在给定一张图像的情况下，它可以通过自然语言指令来预测最相关的文本片段，而无需直接针对该任务进行优化。

TABLE II

RELEVANT EXPERIMENTAL PARAMETERS OF DIFFERENT DATASETS. THE LR DENOTES THE LEARNING RATE.

不同数据集的相关实验参数。LR 表示学习率(Learning Rate)。

<table><tr><td rowspan="2">Dataset</td><td colspan="3">Multimodal Feature Generation</td><td colspan="2">Common Space Projection</td></tr><tr><td>Batch</td><td>LR</td><td>Gen Num</td><td>Batch</td><td>LR</td></tr><tr><td>Wikipedia</td><td>256</td><td>$1 \times  {10}^{-3}$</td><td>70</td><td>256</td><td>$1 \times  {10}^{-3}$</td></tr><tr><td>Pascal Sentence</td><td>64</td><td>$1 \times  {10}^{-3}$</td><td>30</td><td>64</td><td>$4 \times  {10}^{-4}$</td></tr><tr><td>NUS-WIDE</td><td>512</td><td>$2 \times  {10}^{-3}$</td><td>500</td><td>512</td><td>$4 \times  {10}^{-4}$</td></tr><tr><td>NUS-WIDE-10K</td><td>2,048</td><td>$1 \times  {10}^{-3}$</td><td>300</td><td>2,048</td><td>$5 \times  {10}^{-3}$</td></tr></table>

<table><tbody><tr><td rowspan="2">数据集</td><td colspan="3">多模态特征生成</td><td colspan="2">公共空间投影</td></tr><tr><td>批次</td><td>学习率(Learning Rate)</td><td>生成数量</td><td>批次</td><td>学习率(Learning Rate)</td></tr><tr><td>维基百科(Wikipedia)</td><td>256</td><td>$1 \times  {10}^{-3}$</td><td>70</td><td>256</td><td>$1 \times  {10}^{-3}$</td></tr><tr><td>帕斯卡句子(Pascal Sentence)</td><td>64</td><td>$1 \times  {10}^{-3}$</td><td>30</td><td>64</td><td>$4 \times  {10}^{-4}$</td></tr><tr><td>新加坡国立大学广域图像数据集(NUS-WIDE)</td><td>512</td><td>$2 \times  {10}^{-3}$</td><td>500</td><td>512</td><td>$4 \times  {10}^{-4}$</td></tr><tr><td>新加坡国立大学广域图像10K数据集(NUS-WIDE-10K)</td><td>2,048</td><td>$1 \times  {10}^{-3}$</td><td>300</td><td>2,048</td><td>$5 \times  {10}^{-3}$</td></tr></tbody></table>

## C. Implementation Details

## C. 实现细节

In our network architecture, the encoders ${E}_{ * }$ , comprise three fully-connected layers, progressively configured with dimensions $\left\lbrack  {1,{024},{800},{512}}\right\rbrack$ . Each of these layers employs the ReLU activation function, while the last layer utilizes the Sigmoid activation for smoother output representation. The generators ${G}_{ * }$ , are constructed using three fully-connected layers with respective dimensional configurations of $\left\lbrack  {1,{536},{800},1,{024}}\right\rbrack$ . Like the encoders, every layer within these generators utilizes the ReLU activation function, and the final layer adopts the Sigmoid activation function to ensure optimized outputs. As for the adversarial learning component, we architect the discriminators ${D}_{ * }$ , with two fully-connected layers $\left\lbrack  {2,{048},1}\right\rbrack$ units respectively. The intermediate layer of this discriminator harnesses the LeakyReLU activation function to enhance its discriminative capacity.

在我们的网络架构中，编码器 ${E}_{ * }$ 由三个全连接层组成，其维度逐步配置为 $\left\lbrack  {1,{024},{800},{512}}\right\rbrack$。这些层中的每一层都采用 ReLU 激活函数，而最后一层使用 Sigmoid 激活函数以实现更平滑的输出表示。生成器 ${G}_{ * }$ 由三个全连接层构建而成，其维度配置分别为 $\left\lbrack  {1,{536},{800},1,{024}}\right\rbrack$。与编码器一样，这些生成器中的每一层都使用 ReLU 激活函数，并且最后一层采用 Sigmoid 激活函数以确保输出最优化。至于对抗学习组件，我们将判别器 ${D}_{ * }$ 设计为分别具有 $\left\lbrack  {2,{048},1}\right\rbrack$ 个单元的两个全连接层。该判别器的中间层利用 LeakyReLU 激活函数来增强其判别能力。

We conduct two training stages. In the first phase, the multimodal feature generation model is first trained with source domain data and a small amount of target domain data. In the second stage, the trained generative model is used to generate a specific number of target domain pseudo-entities. Subsequently, the generated pseudo-entities are combined with the source domain dataset to train the multimodal mapping model. In the training process, the Adam optimizer is used for training optimization. Table II shows the training parameters of the FLEX-CLIP model on different datasets.

我们进行两个训练阶段。在第一阶段，首先使用源域数据和少量目标域数据训练多模态特征生成模型。在第二阶段，使用训练好的生成模型生成特定数量的目标域伪实体。随后，将生成的伪实体与源域数据集结合起来训练多模态映射模型。在训练过程中，使用 Adam 优化器进行训练优化。表 II 展示了 FLEX - CLIP 模型在不同数据集上的训练参数。

## D. Comparison Results

## D. 比较结果

1) Zero-shot Scenario: Zero-shot learning represents an extreme form of few-shot learning, where the training data contains no samples from the target domain. We conduct zero-shot cross-modal retrieval experiments on the FLEX-CLIP model and baseline models, with the results presented in Table 1. The key observations are as follows:

1) 零样本场景:零样本学习是少样本学习的一种极端形式，其中训练数据不包含目标域的样本。我们在 FLEX - CLIP 模型和基线模型上进行了零样本跨模态检索实验，结果如表 1 所示。主要观察结果如下:

a) FLEX-CLIP outperforms other methods significantly: . The zero-shot setting challenges these methods in handling unseen classes in the target domain. However, our approach alleviates the issues of extreme data imbalance and domain knowledge bias in zero-shot scenarios by synthesizing pseudo-samples in the target domain via our composite VAE-GAN generation network and fully leveraging the pre-trained semantic features of images and texts.

a) FLEX - CLIP 显著优于其他方法:零样本设置对这些方法处理目标域中未见类别的能力提出了挑战。然而，我们的方法通过复合 VAE - GAN 生成网络在目标域中合成伪样本，并充分利用图像和文本的预训练语义特征，缓解了零样本场景中极端数据不平衡和领域知识偏差的问题。

b) Zero-shot methods perform better: Compared with conventional methods (CCA, DSCMR, MARS), zero-shot cross-modal methods (DADN, CFSA, JSFE, and MDVAE) have certain advantages in most cases. But compared with the zero-shot methods, the robust method MRL shows competitive performance on all four datasets. Indicating that with the help of the high-quality original features extracted by the vision-language pretraining model, the robust learning architecture of MRL can better capture the deep semantic association between cross-modal data, so that it can have better performance in zero-shot cross-modal retrieval tasks.

b) 零样本方法表现更好:与传统方法(CCA、DSCMR、MARS)相比，零样本跨模态方法(DADN、CFSA、JSFE 和 MDVAE)在大多数情况下具有一定优势。但与零样本方法相比，鲁棒方法 MRL 在所有四个数据集上都表现出具有竞争力的性能。这表明，借助视觉 - 语言预训练模型提取的高质量原始特征，MRL 的鲁棒学习架构能够更好地捕捉跨模态数据之间的深层语义关联，从而使其在零样本跨模态检索任务中具有更好的性能。

c) FLEX-CLIP solve the feature degradation.: However, all the baseline models suffer from feature degradation in the zero-shot scenario, and the zero-shot cross-modal retrieval performance of the model is significantly weaker than that of the CLIP model. FLEX-CLIP is the model that surpasses the original CLIP features. Specificly, compared with the best counterpart CLIP, our approach achieves notable improvement and consistently beats CLIP with 2.31,7.59,2.53, and 7.90 improvements of the average MAP scores on four datasets. It demonstrates that our FLEX-CLIP better utilizes the multimodal knowledge extracted by vision-language pre-trained model and greatly solve the feature degradation by the proposed gate residual network. We will further explore the improvement on CLIP in our CASE STUDY.

c) FLEX - CLIP 解决了特征退化问题:然而，所有基线模型在零样本场景中都存在特征退化问题，并且模型的零样本跨模态检索性能明显弱于 CLIP 模型。FLEX - CLIP 是超越原始 CLIP 特征的模型。具体而言，与表现最佳的对应模型 CLIP 相比，我们的方法取得了显著改进，在四个数据集上的平均 MAP 分数分别提高了 2.31、7.59、2.53 和 7.90，始终优于 CLIP。这表明我们的 FLEX - CLIP 更好地利用了视觉 - 语言预训练模型提取的多模态知识，并通过提出的门控残差网络大大解决了特征退化问题。我们将在案例研究中进一步探索对 CLIP 的改进。

2) Few-shot Scenario: We conduct few-shot cross-modal retrieval experiments by randomly selecting 1,3,5-shot, shown in Table 2, leading to the following observations:

2) 少样本场景:我们通过随机选择 1 样本、3 样本、5 样本进行少样本跨模态检索实验，结果如表 2 所示，得出以下观察结果:

a) Noise data and outliers problem:: From the experimental results, it can be seen that almost all methods show a certain performance improvement on the Pascal Sentence and Wikipedia datasets with the increase of the number of target domain samples. This indicates that the increase in the sample size can help alleviate the extreme imbalance between the sample size of the target domain and the source domain in the few-sample scenario. However, on the NUS-WIDE-10K and NUS-WIDE datasets, the performance of most of the methods becomes unstable, instead of improving significantly with the increase of the number of samples in the target domain. This may be due to the larger amount of data and more noise data for the NUS-WIDE-10K and NUS-WIDE. A small number of randomly selected samples of the target domain introduced by few-shot setting may contain outliers that cause the model to deviate from the actual target when it is trained.

a) 噪声数据和离群值问题:从实验结果可以看出，随着目标域样本数量的增加，几乎所有方法在 Pascal Sentence 和 Wikipedia 数据集上都表现出一定的性能提升。这表明样本数量的增加有助于缓解少样本场景中目标域和源域样本数量的极端不平衡。然而，在 NUS - WIDE - 10K 和 NUS - WIDE 数据集上，大多数方法的性能变得不稳定，而不是随着目标域样本数量的增加而显著提高。这可能是因为 NUS - WIDE - 10K 和 NUS - WIDE 数据集的数据量更大且噪声数据更多。少样本设置引入的少量随机选择的目标域样本可能包含离群值，导致模型在训练时偏离实际目标。

b) FLEX-CLIP's adaptability to noise in few-shot.: It is worth noting that with the increase of the number of samples in the target domain, the FLEX-CLIP model achieves performance improvement on all four datasets. This indicates that the proposed composite VAE-GAN architecture of FLEX-CLIP can better capture the feature distribution pattern of the target domain from a small number of samples, so as to alleviate the influence of noise nodes on model training. Based on this learning ability to capture the feature distribution pattern, the feature generation model can alleviate the data imbalance problem faced by the downstream mapping model by generating the target domain pseudo-entity.

b) FLEX - CLIP在小样本情况下对噪声的适应性:值得注意的是，随着目标领域样本数量的增加，FLEX - CLIP模型在所有四个数据集上都实现了性能提升。这表明，所提出的FLEX - CLIP复合VAE - GAN架构能够从少量样本中更好地捕捉目标领域的特征分布模式，从而减轻噪声节点对模型训练的影响。基于这种捕捉特征分布模式的学习能力，特征生成模型可以通过生成目标领域的伪实体来缓解下游映射模型面临的数据不平衡问题。

3) Case Study: In addition, we also provide typical zero-shot image-text retrieval exemplars obtained by our FLEX-CLIP and compared model MDVAE, shown in Figure 6. For each query text, its top 5 retrieved images are presented, the red rectangles denote the wrong retrieved candidates, and the green rectangles denote the correctly retrieved candidates. It can be seen that our method successfully retrieves the correct images with text queries in most cases, while the MDVAE sometimes retrieves the wrong candidates especially for some image samples that are very similar in appearance. For example, in the second example of "royalty" retrieval, since the similar appearances of different Medieval portraits, MDVAE mistakes other portraits for Elizabeth and her associates, and our model FLEX-CLIP correctly identified the relevant candidates.

3) 案例研究:此外，我们还提供了由我们的FLEX - CLIP和对比模型MDVAE获得的典型零样本图文检索示例，如图6所示。对于每个查询文本，展示了其前5个检索到的图像，红色矩形表示错误的检索候选，绿色矩形表示正确的检索候选。可以看出，在大多数情况下，我们的方法能够通过文本查询成功检索到正确的图像，而MDVAE有时会检索到错误的候选，特别是对于一些外观非常相似的图像样本。例如，在“皇室成员”检索的第二个示例中，由于不同中世纪肖像的外观相似，MDVAE将其他肖像误认作伊丽莎白及其同伴，而我们的模型FLEX - CLIP正确识别出了相关候选。

TABLE III

Comparisons of our approach and 9 compared methods on four benchmark datasets for zero-shot image-text retrieval. The best AND SECOND-BEST RESULTS ARE MARKED IN BOLD AND UNDERLINED FONT, RESPECTIVELY.

我们的方法与9种对比方法在四个零样本图文检索基准数据集上的比较。最佳结果和次佳结果分别用粗体和下划线字体标记。

<table><tr><td rowspan="2">Model</td><td colspan="2">Wikipedia</td><td colspan="3">Nuswide-10k</td><td colspan="3">Pascal Sentence</td><td colspan="3">NUSWIDE</td><td rowspan="2">Avg</td></tr><tr><td>Img2Txt</td><td>Txt2Img</td><td>Avg</td><td>Img2Txt</td><td>Txt2Img</td><td>Avg</td><td>Img2Txt</td><td>Txt2Img</td><td>Avg</td><td>Img2Txt</td><td>Txt2Img</td></tr><tr><td>CCA</td><td>0.359</td><td>0.306</td><td>0.332</td><td>0.320</td><td>0.323</td><td>0.322</td><td>0.272</td><td>0.233</td><td>0.252</td><td>0.411</td><td>0.408</td><td>0.410</td></tr><tr><td>DSCMR</td><td>0.362</td><td>0.336</td><td>0.349</td><td>0.346</td><td>0.377</td><td>0.361</td><td>0.455</td><td>0.448</td><td>0.452</td><td>0.411</td><td>0.431</td><td>0.421</td></tr><tr><td>MARS</td><td>0.349</td><td>0.318</td><td>0.333</td><td>0.280</td><td>0.292</td><td>0.286</td><td>0.385</td><td>0.384</td><td>0.384</td><td>0.339</td><td>0.367</td><td>0.353</td></tr><tr><td>MRL</td><td>0.418</td><td>0.455</td><td>0.437</td><td>0.454</td><td>0.452</td><td>0.453</td><td>0.519</td><td>0.503</td><td>0.511</td><td>0.498</td><td>0.491</td><td>0.494</td></tr><tr><td>DADN</td><td>0.369</td><td>0.325</td><td>0.347</td><td>0.342</td><td>0.355</td><td>0.349</td><td>0.442</td><td>0.398</td><td>0.420</td><td>0.417</td><td>0.443</td><td>0.430</td></tr><tr><td>CFSA</td><td>0.421</td><td>0.356</td><td>0.388</td><td>0.383</td><td>0.402</td><td>0.392</td><td>0.463</td><td>0.440</td><td>0.451</td><td>0.450</td><td>0.473</td><td>0.461</td></tr><tr><td>JSFE</td><td>0.420</td><td>0.352</td><td>0.386</td><td>0.379</td><td>0.403</td><td>0.391</td><td>0.438</td><td>0.423</td><td>0.431</td><td>0.458</td><td>0.473</td><td>0.465</td></tr><tr><td>MDVAE</td><td>0.474</td><td>0.459</td><td>0.466</td><td>0.400</td><td>0.425</td><td>0.412</td><td>0.470</td><td>0.467</td><td>0.469</td><td>0.399</td><td>0.424</td><td>0.411</td></tr><tr><td>CLIP</td><td>0.526</td><td>0.479</td><td>0.502</td><td>0.480</td><td>0.526</td><td>0.503</td><td>0.669</td><td>0.659</td><td>0.664</td><td>0.581</td><td>0.602</td><td>0.592</td></tr><tr><td>OURS</td><td>0.539</td><td>0.512</td><td>0.526</td><td>0.569</td><td>0.589</td><td>0.579</td><td>0.690</td><td>0.689</td><td>0.689</td><td>0.661</td><td>0.680</td><td>0.671</td></tr></table>

<table><tbody><tr><td rowspan="2">模型</td><td colspan="2">维基百科</td><td colspan="3">新加坡国立大学宽幅图像数据集-10k(Nuswide-10k)</td><td colspan="3">帕斯卡句子(Pascal Sentence)</td><td colspan="3">新加坡国立大学宽幅图像数据集(NUSWIDE)</td><td rowspan="2">平均值</td></tr><tr><td>图像转文本</td><td>文本转图像</td><td>平均值</td><td>图像转文本</td><td>文本转图像</td><td>平均值</td><td>图像转文本</td><td>文本转图像</td><td>平均值</td><td>图像转文本</td><td>文本转图像</td></tr><tr><td>典型相关分析(CCA)</td><td>0.359</td><td>0.306</td><td>0.332</td><td>0.320</td><td>0.323</td><td>0.322</td><td>0.272</td><td>0.233</td><td>0.252</td><td>0.411</td><td>0.408</td><td>0.410</td></tr><tr><td>深度语义跨模态检索(DSCMR)</td><td>0.362</td><td>0.336</td><td>0.349</td><td>0.346</td><td>0.377</td><td>0.361</td><td>0.455</td><td>0.448</td><td>0.452</td><td>0.411</td><td>0.431</td><td>0.421</td></tr><tr><td>多模态自适应表示学习(MARS)</td><td>0.349</td><td>0.318</td><td>0.333</td><td>0.280</td><td>0.292</td><td>0.286</td><td>0.385</td><td>0.384</td><td>0.384</td><td>0.339</td><td>0.367</td><td>0.353</td></tr><tr><td>多模态表示学习(MRL)</td><td>0.418</td><td>0.455</td><td>0.437</td><td>0.454</td><td>0.452</td><td>0.453</td><td>0.519</td><td>0.503</td><td>0.511</td><td>0.498</td><td>0.491</td><td>0.494</td></tr><tr><td>双注意力深度网络(DADN)</td><td>0.369</td><td>0.325</td><td>0.347</td><td>0.342</td><td>0.355</td><td>0.349</td><td>0.442</td><td>0.398</td><td>0.420</td><td>0.417</td><td>0.443</td><td>0.430</td></tr><tr><td>跨模态特征自注意力(CFSA)</td><td>0.421</td><td>0.356</td><td>0.388</td><td>0.383</td><td>0.402</td><td>0.392</td><td>0.463</td><td>0.440</td><td>0.451</td><td>0.450</td><td>0.473</td><td>0.461</td></tr><tr><td>联合语义特征提取(JSFE)</td><td>0.420</td><td>0.352</td><td>0.386</td><td>0.379</td><td>0.403</td><td>0.391</td><td>0.438</td><td>0.423</td><td>0.431</td><td>0.458</td><td>0.473</td><td>0.465</td></tr><tr><td>多模态解耦变分自编码器(MDVAE)</td><td>0.474</td><td>0.459</td><td>0.466</td><td>0.400</td><td>0.425</td><td>0.412</td><td>0.470</td><td>0.467</td><td>0.469</td><td>0.399</td><td>0.424</td><td>0.411</td></tr><tr><td>对比语言-图像预训练(CLIP)</td><td>0.526</td><td>0.479</td><td>0.502</td><td>0.480</td><td>0.526</td><td>0.503</td><td>0.669</td><td>0.659</td><td>0.664</td><td>0.581</td><td>0.602</td><td>0.592</td></tr><tr><td>我们的方法</td><td>0.539</td><td>0.512</td><td>0.526</td><td>0.569</td><td>0.589</td><td>0.579</td><td>0.690</td><td>0.689</td><td>0.689</td><td>0.661</td><td>0.680</td><td>0.671</td></tr></tbody></table>

TABLE IV

Comparisons of our approach and 9 compared methods on four benchmark datasets for 1,3,5-shot image-text retrieval. The 1,3,5-SHOT EXPERIMENT RESULTS ARE SAME IN CLIP, SO THE SAMPLE INFORMATION IS "-".

在四个基准数据集上，我们的方法与9种对比方法在1次、3次、5次样本图像 - 文本检索任务中的比较。在CLIP(对比语言 - 图像预训练模型)中，1次、3次、5次样本实验结果相同，因此样本信息为“ - ”。

<table><tr><td colspan="2" rowspan="2">Model</td><td colspan="2">Wikipedia</td><td colspan="3">Nuswide-10k</td><td colspan="3">Pascal Sentence</td><td colspan="4">NUSWIDE</td></tr><tr><td>12T</td><td>T2I</td><td>Avg</td><td>I2T</td><td>T2I</td><td>Avg</td><td>I2T</td><td>T2I</td><td>Avg</td><td>I2T</td><td>T2I</td><td>Avg</td></tr><tr><td rowspan="3">CCA</td><td>1-shot</td><td>0.357</td><td>0.306</td><td>0.331</td><td>0.321</td><td>0.323</td><td>0.322</td><td>0.251</td><td>0.239</td><td>0.245</td><td>0.411</td><td>0.409</td><td>0.410</td></tr><tr><td>3-shot</td><td>0.360</td><td>0.309</td><td>0.334</td><td>0.322</td><td>0.324</td><td>0.323</td><td>0.312</td><td>0.305</td><td>0.309</td><td>0.412</td><td>0.409</td><td>0.410</td></tr><tr><td>5-shot</td><td>0.358</td><td>0.311</td><td>0.334</td><td>0.323</td><td>0.325</td><td>0.324</td><td>0.337</td><td>0.351</td><td>0.344</td><td>0.412</td><td>0.407</td><td>0.409</td></tr><tr><td rowspan="3">DSCMR</td><td>1-shot</td><td>0.360</td><td>0.331</td><td>0.346</td><td>0.340</td><td>0.375</td><td>0.358</td><td>0.443</td><td>0.459</td><td>0.451</td><td>0.416</td><td>0.427</td><td>0.422</td></tr><tr><td>3-shot</td><td>0.361</td><td>0.338</td><td>0.349</td><td>0.336</td><td>0.369</td><td>0.353</td><td>0.446</td><td>0.477</td><td>0.462</td><td>0.420</td><td>0.426</td><td>0.423</td></tr><tr><td>5-shot</td><td>0.354</td><td>0.332</td><td>0.343</td><td>0.339</td><td>0.373</td><td>0.356</td><td>0.534</td><td>0.569</td><td>0.552</td><td>0.412</td><td>0.434</td><td>0.423</td></tr><tr><td rowspan="3">MARS</td><td>1-shot</td><td>0.330</td><td>0.308</td><td>0.319</td><td>0.279</td><td>0.289</td><td>0.284</td><td>0.391</td><td>0.385</td><td>0.388</td><td>0.348</td><td>0.374</td><td>0.361</td></tr><tr><td>3-shot</td><td>0.328</td><td>0.311</td><td>0.320</td><td>0.279</td><td>0.288</td><td>0.283</td><td>0.452</td><td>0.460</td><td>0.456</td><td>0.341</td><td>0.386</td><td>0.364</td></tr><tr><td>5-shot</td><td>0.342</td><td>0.361</td><td>0.351</td><td>0.283</td><td>0.294</td><td>0.288</td><td>0.551</td><td>0.585</td><td>0.568</td><td>0.351</td><td>0.376</td><td>0.363</td></tr><tr><td rowspan="3">MRL</td><td>1-shot</td><td>0.427</td><td>0.461</td><td>0.444</td><td>0.459</td><td>0.449</td><td>0.454</td><td>0.529</td><td>0.517</td><td>0.523</td><td>0.492</td><td>0.491</td><td>0.491</td></tr><tr><td>3-shot</td><td>0.433</td><td>0.475</td><td>0.454</td><td>0.470</td><td>0.457</td><td>0.464</td><td>0.566</td><td>0.549</td><td>0.557</td><td>0.506</td><td>0.503</td><td>0.504</td></tr><tr><td>5-shot</td><td>0.412</td><td>0.480</td><td>0.446</td><td>0.471</td><td>0.457</td><td>0.464</td><td>0.619</td><td>0.610</td><td>0.615</td><td>0.509</td><td>0.489</td><td>0.499</td></tr><tr><td rowspan="3">DADN</td><td>1-shot</td><td>0.358</td><td>0.320</td><td>0.339</td><td>0.340</td><td>0.354</td><td>0.347</td><td>0.457</td><td>0.382</td><td>0.420</td><td>0.412</td><td>0.441</td><td>0.426</td></tr><tr><td>3-shot</td><td>0.358</td><td>0.333</td><td>0.346</td><td>0.344</td><td>0.355</td><td>0.350</td><td>0.457</td><td>0.424</td><td>0.440</td><td>0.414</td><td>0.439</td><td>0.426</td></tr><tr><td>5-shot</td><td>0.352</td><td>0.328</td><td>0.340</td><td>0.340</td><td>0.353</td><td>0.347</td><td>0.482</td><td>0.553</td><td>0.518</td><td>0.409</td><td>0.437</td><td>0.423</td></tr><tr><td rowspan="3">CFSA</td><td>1-shot</td><td>0.400</td><td>0.348</td><td>0.374</td><td>0.381</td><td>0.403</td><td>0.392</td><td>0.495</td><td>0.491</td><td>0.493</td><td>0.451</td><td>0.471</td><td>0.461</td></tr><tr><td>3-shot</td><td>0.409</td><td>0.349</td><td>0.379</td><td>0.371</td><td>0.393</td><td>0.382</td><td>0.577</td><td>0.578</td><td>0.578</td><td>0.450</td><td>0.470</td><td>0.460</td></tr><tr><td>5-shot</td><td>0.404</td><td>0.352</td><td>0.378</td><td>0.378</td><td>0.398</td><td>0.388</td><td>0.636</td><td>0.654</td><td>0.645</td><td>0.458</td><td>0.477</td><td>0.467</td></tr><tr><td rowspan="3">JSFE</td><td>1-shot</td><td>0.405</td><td>0.349</td><td>0.377</td><td>0.380</td><td>0.407</td><td>0.394</td><td>0.523</td><td>0.517</td><td>0.520</td><td>0.447</td><td>0.467</td><td>0.457</td></tr><tr><td>3-shot</td><td>0.393</td><td>0.337</td><td>0.365</td><td>0.382</td><td>0.399</td><td>0.390</td><td>0.578</td><td>0.577</td><td>0.577</td><td>0.450</td><td>0.469</td><td>0.460</td></tr><tr><td>5-shot</td><td>0.414</td><td>0.350</td><td>0.382</td><td>0.378</td><td>0.399</td><td>0.388</td><td>0.622</td><td>0.647</td><td>0.635</td><td>0.447</td><td>0.464</td><td>0.456</td></tr><tr><td rowspan="3">MDVAE</td><td>1-shot</td><td>0.450</td><td>0.433</td><td>0.442</td><td>0.418</td><td>0.437</td><td>0.428</td><td>0.448</td><td>0.455</td><td>0.451</td><td>0.397</td><td>0.419</td><td>0.408</td></tr><tr><td>3-shot</td><td>0.476</td><td>0.445</td><td>0.460</td><td>0.403</td><td>0.434</td><td>0.418</td><td>0.491</td><td>0.489</td><td>0.490</td><td>0.396</td><td>0.410</td><td>0.403</td></tr><tr><td>5-shot</td><td>0.497</td><td>0.450</td><td>0.473</td><td>0.410</td><td>0.444</td><td>0.427</td><td>0.525</td><td>0.508</td><td>0.516</td><td>0.407</td><td>0.418</td><td>0.413</td></tr><tr><td>CLIP</td><td>-</td><td>0.526</td><td>0.479</td><td>0.502</td><td>0.480</td><td>0.526</td><td>0.503</td><td>0.669</td><td>0.659</td><td>0.664</td><td>0.581</td><td>0.602</td><td>0.592</td></tr><tr><td rowspan="3">Ours(1-shot)</td><td>1-shot</td><td>0.551</td><td>0.523</td><td>0.537</td><td>0.573</td><td>0.592</td><td>0.582</td><td>0.695</td><td>0.690</td><td>0.693</td><td>0.660</td><td>0.677</td><td>0.668</td></tr><tr><td>3-shot</td><td>0.594</td><td>0.554</td><td>0.574</td><td>0.609</td><td>0.626</td><td>0.618</td><td>0.713</td><td>0.718</td><td>0.715</td><td>0.666</td><td>0.687</td><td>0.676</td></tr><tr><td>5-shot</td><td>0.565</td><td>0.533</td><td>0.549</td><td>0.585</td><td>0.603</td><td>0.594</td><td>0.701</td><td>0.700</td><td>0.700</td><td>0.662</td><td>0.680</td><td>0.671</td></tr></table>

<table><tbody><tr><td colspan="2" rowspan="2">模型</td><td colspan="2">维基百科</td><td colspan="3">新加坡国立大学宽幅图像数据集-10k(Nuswide-10k)</td><td colspan="3">帕斯卡句子(Pascal Sentence)</td><td colspan="4">新加坡国立大学宽幅图像数据集(NUSWIDE)</td></tr><tr><td>12T</td><td>文本到图像(T2I)</td><td>平均值(Avg)</td><td>图像到文本(I2T)</td><td>文本到图像(T2I)</td><td>平均值(Avg)</td><td>图像到文本(I2T)</td><td>文本到图像(T2I)</td><td>平均值(Avg)</td><td>图像到文本(I2T)</td><td>文本到图像(T2I)</td><td>平均值(Avg)</td></tr><tr><td rowspan="3">典型相关分析(CCA)</td><td>单样本(1-shot)</td><td>0.357</td><td>0.306</td><td>0.331</td><td>0.321</td><td>0.323</td><td>0.322</td><td>0.251</td><td>0.239</td><td>0.245</td><td>0.411</td><td>0.409</td><td>0.410</td></tr><tr><td>三样本(3-shot)</td><td>0.360</td><td>0.309</td><td>0.334</td><td>0.322</td><td>0.324</td><td>0.323</td><td>0.312</td><td>0.305</td><td>0.309</td><td>0.412</td><td>0.409</td><td>0.410</td></tr><tr><td>五样本(5-shot)</td><td>0.358</td><td>0.311</td><td>0.334</td><td>0.323</td><td>0.325</td><td>0.324</td><td>0.337</td><td>0.351</td><td>0.344</td><td>0.412</td><td>0.407</td><td>0.409</td></tr><tr><td rowspan="3">动态语义跨模态检索(DSCMR)</td><td>单样本(1-shot)</td><td>0.360</td><td>0.331</td><td>0.346</td><td>0.340</td><td>0.375</td><td>0.358</td><td>0.443</td><td>0.459</td><td>0.451</td><td>0.416</td><td>0.427</td><td>0.422</td></tr><tr><td>三样本(3-shot)</td><td>0.361</td><td>0.338</td><td>0.349</td><td>0.336</td><td>0.369</td><td>0.353</td><td>0.446</td><td>0.477</td><td>0.462</td><td>0.420</td><td>0.426</td><td>0.423</td></tr><tr><td>五样本(5-shot)</td><td>0.354</td><td>0.332</td><td>0.343</td><td>0.339</td><td>0.373</td><td>0.356</td><td>0.534</td><td>0.569</td><td>0.552</td><td>0.412</td><td>0.434</td><td>0.423</td></tr><tr><td rowspan="3">多模态自适应表示学习(MARS)</td><td>单样本(1-shot)</td><td>0.330</td><td>0.308</td><td>0.319</td><td>0.279</td><td>0.289</td><td>0.284</td><td>0.391</td><td>0.385</td><td>0.388</td><td>0.348</td><td>0.374</td><td>0.361</td></tr><tr><td>三样本(3-shot)</td><td>0.328</td><td>0.311</td><td>0.320</td><td>0.279</td><td>0.288</td><td>0.283</td><td>0.452</td><td>0.460</td><td>0.456</td><td>0.341</td><td>0.386</td><td>0.364</td></tr><tr><td>五样本(5-shot)</td><td>0.342</td><td>0.361</td><td>0.351</td><td>0.283</td><td>0.294</td><td>0.288</td><td>0.551</td><td>0.585</td><td>0.568</td><td>0.351</td><td>0.376</td><td>0.363</td></tr><tr><td rowspan="3">多模态表示学习(MRL)</td><td>单样本(1-shot)</td><td>0.427</td><td>0.461</td><td>0.444</td><td>0.459</td><td>0.449</td><td>0.454</td><td>0.529</td><td>0.517</td><td>0.523</td><td>0.492</td><td>0.491</td><td>0.491</td></tr><tr><td>三样本(3-shot)</td><td>0.433</td><td>0.475</td><td>0.454</td><td>0.470</td><td>0.457</td><td>0.464</td><td>0.566</td><td>0.549</td><td>0.557</td><td>0.506</td><td>0.503</td><td>0.504</td></tr><tr><td>五样本(5-shot)</td><td>0.412</td><td>0.480</td><td>0.446</td><td>0.471</td><td>0.457</td><td>0.464</td><td>0.619</td><td>0.610</td><td>0.615</td><td>0.509</td><td>0.489</td><td>0.499</td></tr><tr><td rowspan="3">双注意力解耦网络(DADN)</td><td>单样本(1-shot)</td><td>0.358</td><td>0.320</td><td>0.339</td><td>0.340</td><td>0.354</td><td>0.347</td><td>0.457</td><td>0.382</td><td>0.420</td><td>0.412</td><td>0.441</td><td>0.426</td></tr><tr><td>三样本(3-shot)</td><td>0.358</td><td>0.333</td><td>0.346</td><td>0.344</td><td>0.355</td><td>0.350</td><td>0.457</td><td>0.424</td><td>0.440</td><td>0.414</td><td>0.439</td><td>0.426</td></tr><tr><td>五样本(5-shot)</td><td>0.352</td><td>0.328</td><td>0.340</td><td>0.340</td><td>0.353</td><td>0.347</td><td>0.482</td><td>0.553</td><td>0.518</td><td>0.409</td><td>0.437</td><td>0.423</td></tr><tr><td rowspan="3">跨模态特征自注意力(CFSA)</td><td>单样本(1-shot)</td><td>0.400</td><td>0.348</td><td>0.374</td><td>0.381</td><td>0.403</td><td>0.392</td><td>0.495</td><td>0.491</td><td>0.493</td><td>0.451</td><td>0.471</td><td>0.461</td></tr><tr><td>三样本(3-shot)</td><td>0.409</td><td>0.349</td><td>0.379</td><td>0.371</td><td>0.393</td><td>0.382</td><td>0.577</td><td>0.578</td><td>0.578</td><td>0.450</td><td>0.470</td><td>0.460</td></tr><tr><td>五样本(5-shot)</td><td>0.404</td><td>0.352</td><td>0.378</td><td>0.378</td><td>0.398</td><td>0.388</td><td>0.636</td><td>0.654</td><td>0.645</td><td>0.458</td><td>0.477</td><td>0.467</td></tr><tr><td rowspan="3">联合语义特征提取(JSFE)</td><td>单样本(1-shot)</td><td>0.405</td><td>0.349</td><td>0.377</td><td>0.380</td><td>0.407</td><td>0.394</td><td>0.523</td><td>0.517</td><td>0.520</td><td>0.447</td><td>0.467</td><td>0.457</td></tr><tr><td>三样本(3-shot)</td><td>0.393</td><td>0.337</td><td>0.365</td><td>0.382</td><td>0.399</td><td>0.390</td><td>0.578</td><td>0.577</td><td>0.577</td><td>0.450</td><td>0.469</td><td>0.460</td></tr><tr><td>五样本(5-shot)</td><td>0.414</td><td>0.350</td><td>0.382</td><td>0.378</td><td>0.399</td><td>0.388</td><td>0.622</td><td>0.647</td><td>0.635</td><td>0.447</td><td>0.464</td><td>0.456</td></tr><tr><td rowspan="3">多模态解耦变分自编码器(MDVAE)</td><td>单样本(1-shot)</td><td>0.450</td><td>0.433</td><td>0.442</td><td>0.418</td><td>0.437</td><td>0.428</td><td>0.448</td><td>0.455</td><td>0.451</td><td>0.397</td><td>0.419</td><td>0.408</td></tr><tr><td>三样本(3-shot)</td><td>0.476</td><td>0.445</td><td>0.460</td><td>0.403</td><td>0.434</td><td>0.418</td><td>0.491</td><td>0.489</td><td>0.490</td><td>0.396</td><td>0.410</td><td>0.403</td></tr><tr><td>五样本(5-shot)</td><td>0.497</td><td>0.450</td><td>0.473</td><td>0.410</td><td>0.444</td><td>0.427</td><td>0.525</td><td>0.508</td><td>0.516</td><td>0.407</td><td>0.418</td><td>0.413</td></tr><tr><td>对比语言-图像预训练(CLIP)</td><td>-</td><td>0.526</td><td>0.479</td><td>0.502</td><td>0.480</td><td>0.526</td><td>0.503</td><td>0.669</td><td>0.659</td><td>0.664</td><td>0.581</td><td>0.602</td><td>0.592</td></tr><tr><td rowspan="3">我们的方法(单样本)</td><td>单样本(1-shot)</td><td>0.551</td><td>0.523</td><td>0.537</td><td>0.573</td><td>0.592</td><td>0.582</td><td>0.695</td><td>0.690</td><td>0.693</td><td>0.660</td><td>0.677</td><td>0.668</td></tr><tr><td>三样本(3-shot)</td><td>0.594</td><td>0.554</td><td>0.574</td><td>0.609</td><td>0.626</td><td>0.618</td><td>0.713</td><td>0.718</td><td>0.715</td><td>0.666</td><td>0.687</td><td>0.676</td></tr><tr><td>五样本(5-shot)</td><td>0.565</td><td>0.533</td><td>0.549</td><td>0.585</td><td>0.603</td><td>0.594</td><td>0.701</td><td>0.700</td><td>0.700</td><td>0.662</td><td>0.680</td><td>0.671</td></tr></tbody></table>

The results demonstrate that our model FLEX-CLIP is advanced to retrieve the semantically related images with high accuracy, which indicates that our FLEX-CLIP learns effective multimodal semantic features for correlated images and texts, alleviate the data imbalance and feature degradation, and improve the zero-shot cross-modal retrieval ability.

结果表明，我们的模型FLEX - CLIP能够高精度地检索出语义相关的图像，这表明我们的FLEX - CLIP学习到了用于关联图像和文本的有效多模态语义特征，缓解了数据不平衡和特征退化问题，并提高了零样本跨模态检索能力。

## E. Ablation Study

## E. 消融实验

1) Effect of Generative VAE-GAN Network: To validate the effectiveness of our network for generating multimodal features to alleviate the data imbalance, we perform ablation experiments under 0 -shot, 1 -shot, 3 -shot, 5 -shot, and 7- shot scenarios which compare the w/o VAE-GAN generation network FLEX-CLIP model with the standard FLEX-CLIP. We conduct experiments on four datasets, and the complete experimental results of Img2Txt and Txt2Img tasks are shown in Figure 3.

1) 生成式VAE - GAN网络的效果:为了验证我们用于生成多模态特征以缓解数据不平衡的网络的有效性，我们在零样本、单样本、三样本、五样本和七样本场景下进行了消融实验，比较了无VAE - GAN生成网络的FLEX - CLIP模型和标准FLEX - CLIP模型。我们在四个数据集上进行了实验，Img2Txt和Txt2Img任务的完整实验结果如图3所示。

![0195d6f2-b56e-7b0a-aee8-41fd975e38e0_8_135_161_1531_323_0.jpg](images/0195d6f2-b56e-7b0a-aee8-41fd975e38e0_8_135_161_1531_323_0.jpg)

Fig. 5. The mAP curve of the ablation experiment of the composite VAE-GAN network.

图5. 复合VAE - GAN网络消融实验的平均精度均值(mAP)曲线。

TABLE V

The effectiveness of the ablation experiment on the residual gate network. The ${L}_{1}$ is the cross-entropy loss function, ${L}_{2}$ is a modal consistency loss function, and ${L}_{3}$ is cross-modal comparison learning loss, as detailedly described in Sec. III-E2

残差门控网络消融实验的有效性。${L}_{1}$是交叉熵损失函数，${L}_{2}$是模态一致性损失函数，${L}_{3}$是跨模态对比学习损失，如第三节E2中详细描述的那样。

<table><tr><td rowspan="2">Model</td><td colspan="3">Wikipedia</td><td colspan="3">Nuswide-10k</td><td colspan="3">Pascal Sentence</td><td colspan="3">NUSWIDE</td></tr><tr><td>Img2Txt</td><td>Txt2Img</td><td>Avg</td><td>Img2Txt</td><td>Txt2Img</td><td>Avg</td><td>Img2Txt</td><td>Txt2Img</td><td>Avg</td><td>Img2Txt</td><td>Txt2Img</td><td>Avg</td></tr><tr><td>Ours(0-shot)</td><td>0.5391</td><td>0.5119</td><td>0.5255</td><td>0.5689</td><td>0.5894</td><td>0.5792</td><td>0.6901</td><td>0.6885</td><td>0.6893</td><td>0.6613</td><td>0.6803</td><td>0.6708</td></tr><tr><td>w/o Res-Gate</td><td>0.4790</td><td>0.4462</td><td>0.4626</td><td>0.5426</td><td>0.5651</td><td>0.5539</td><td>0.5366</td><td>0.5365</td><td>0.5366</td><td>0.6510</td><td>0.6640</td><td>0.6575</td></tr><tr><td>w/o L1</td><td>0.5303</td><td>0.5043</td><td>0.5173</td><td>0.5669</td><td>0.5846</td><td>0.5758</td><td>0.6880</td><td>0.6858</td><td>0.6869</td><td>0.6428</td><td>0.6592</td><td>0.6510</td></tr><tr><td>w/o L2</td><td>0.5389</td><td>0.5109</td><td>0.5249</td><td>0.5664</td><td>0.5866</td><td>0.5765</td><td>0.6819</td><td>0.6807</td><td>0.6813</td><td>0.6356</td><td>0.6599</td><td>0.6478</td></tr><tr><td>w/o L3</td><td>0.4865</td><td>0.4542</td><td>0.4704</td><td>0.4691</td><td>0.4798</td><td>0.4745</td><td>0.6812</td><td>0.6739</td><td>0.6776</td><td>0.5352</td><td>0.5241</td><td>0.5297</td></tr></table>

<table><tbody><tr><td rowspan="2">模型</td><td colspan="3">维基百科</td><td colspan="3">新加坡国立大学宽幅图像数据集-10k(Nuswide-10k)</td><td colspan="3">帕斯卡句子(Pascal Sentence)</td><td colspan="3">新加坡国立大学宽幅图像数据集(NUSWIDE)</td></tr><tr><td>图像转文本(Img2Txt)</td><td>文本转图像(Txt2Img)</td><td>平均值</td><td>图像转文本(Img2Txt)</td><td>文本转图像(Txt2Img)</td><td>平均值</td><td>图像转文本(Img2Txt)</td><td>文本转图像(Txt2Img)</td><td>平均值</td><td>图像转文本(Img2Txt)</td><td>文本转图像(Txt2Img)</td><td>平均值</td></tr><tr><td>我们的方法(零样本)</td><td>0.5391</td><td>0.5119</td><td>0.5255</td><td>0.5689</td><td>0.5894</td><td>0.5792</td><td>0.6901</td><td>0.6885</td><td>0.6893</td><td>0.6613</td><td>0.6803</td><td>0.6708</td></tr><tr><td>无残差门控(w/o Res-Gate)</td><td>0.4790</td><td>0.4462</td><td>0.4626</td><td>0.5426</td><td>0.5651</td><td>0.5539</td><td>0.5366</td><td>0.5365</td><td>0.5366</td><td>0.6510</td><td>0.6640</td><td>0.6575</td></tr><tr><td>无L1</td><td>0.5303</td><td>0.5043</td><td>0.5173</td><td>0.5669</td><td>0.5846</td><td>0.5758</td><td>0.6880</td><td>0.6858</td><td>0.6869</td><td>0.6428</td><td>0.6592</td><td>0.6510</td></tr><tr><td>无L2</td><td>0.5389</td><td>0.5109</td><td>0.5249</td><td>0.5664</td><td>0.5866</td><td>0.5765</td><td>0.6819</td><td>0.6807</td><td>0.6813</td><td>0.6356</td><td>0.6599</td><td>0.6478</td></tr><tr><td>无L3</td><td>0.4865</td><td>0.4542</td><td>0.4704</td><td>0.4691</td><td>0.4798</td><td>0.4745</td><td>0.6812</td><td>0.6739</td><td>0.6776</td><td>0.5352</td><td>0.5241</td><td>0.5297</td></tr></tbody></table>

![0195d6f2-b56e-7b0a-aee8-41fd975e38e0_8_141_952_733_687_0.jpg](images/0195d6f2-b56e-7b0a-aee8-41fd975e38e0_8_141_952_733_687_0.jpg)

Fig. 6. The examples of top-5 retrieval results of our FLEX-CLIP and the compared model MDVAE.

图6. 我们的FLEX - CLIP模型和对比模型MDVAE的前5名检索结果示例。

We can observe that compared with our standard model, the model performance of the w/o VAE-GAN composite network has a significant decrease in most scenarios, which proves that our proposed composite generation network, utilizing the feature generation method, can effectively solve the problem of extreme data imbalance in the zero-shot setting. Notably, the results of the w/o VAE-GAN model are better than CLIP, indicating that the gate network improves the performance of the origin CLIP features.

我们可以观察到，与我们的标准模型相比，无VAE - GAN复合网络的模型在大多数场景下的性能显著下降，这证明了我们提出的复合生成网络，利用特征生成方法，能够有效解决零样本设置下的极端数据不平衡问题。值得注意的是，无VAE - GAN模型的结果优于CLIP，这表明门控网络提高了原始CLIP特征的性能。

In addition, in the absence of the VAE-GAN composite network, it can be observed that the model's effect improves significantly more slowly with the increase in the number of samples compared to the standard model. This proves that our model also has a good ability to learn under few-shot and can fully utilize the information of very few target domain samples to solve the data imbalance problem.

此外，在没有VAE - GAN复合网络的情况下，可以观察到与标准模型相比，随着样本数量的增加，模型效果的提升明显更慢。这证明了我们的模型在少样本情况下也具有良好的学习能力，并且能够充分利用极少的目标域样本信息来解决数据不平衡问题。

2) Effect of VAE Network on Few-shot: To verify the effect of the VAE network on capturing the feature distribution to better generation, we perform the ablation experiments on the four datasets. We perform ablation experiments under 0 - shot, 1-shot, 3-shot, and 5-shot scenarios, and the experimental results of the Img2Txt, Txt2Img, and the average scores are shown in Table VI

2) VAE网络对少样本的影响:为了验证VAE网络在捕捉特征分布以实现更好生成方面的效果，我们在四个数据集上进行了消融实验。我们在零样本、单样本、三样本和五样本场景下进行了消融实验，Img2Txt、Txt2Img的实验结果以及平均得分如表VI所示。

We can observe that compared to the results of the model without VAE, our standard basic model shows a significant improvement in different sample settings, especially in the 5- shot scenario, demonstrating an improvement of 5.84,5.36, 3.42, and 1.17 on the four datasets respectively. In addition, after removing the VAE network, the model performance improvement due to the increase of training samples in the target domain is relatively limited. This proves that the introduction of VAE greatly helps the model to capture the correct feature distribution patterns, which can effectively improve the feature generation network to solve the problem of data imbalance in the few-shot scenario. The above results demonstrate that the introduction of VAE effectively improves the performance of feature generation and further enhances the effectiveness of $\mathrm{X}$ -shot cross-modal retrieval.

我们可以观察到，与没有VAE的模型结果相比，我们的标准基础模型在不同的样本设置下有显著改进，尤其是在五样本场景下，在四个数据集上分别提高了5.84、5.36、3.42和1.17。此外，去除VAE网络后，由于目标域训练样本增加而带来的模型性能提升相对有限。这证明了引入VAE极大地帮助模型捕捉正确的特征分布模式，能够有效改进特征生成网络，解决少样本场景下的数据不平衡问题。上述结果表明，引入VAE有效提高了特征生成的性能，并进一步增强了$\mathrm{X}$样本跨模态检索的有效性。

3) Effect of Residual Gate Network and Loss Function on Common Space Mapping: To verify the effect of the residual gate network network and every loss function on alleviating the feature degradation on the target domain, we compare the effect of the proposed residual gate network and three loss functions as well as our proposed standard scheme in our FLEX-CLIP.

3) 残差门控网络和损失函数对公共空间映射的影响:为了验证残差门控网络和每个损失函数在缓解目标域特征退化方面的效果，我们比较了所提出的残差门控网络和三种损失函数以及我们在FLEX - CLIP中提出的标准方案的效果。

TABLE VI

THE EFFECTIVENESS OF THE ABLATION EXPERIMENT ON THE VAE NETWORK.

VAE网络消融实验的有效性。

<table><tr><td rowspan="2">Model</td><td colspan="3">Wikipedia</td><td colspan="3">Nuswide-10k</td><td colspan="3">Pascal Sentence</td><td colspan="3">NUSWIDE</td></tr><tr><td>Img2Txt</td><td>Txt2Img</td><td>Avg</td><td>Img2Txt</td><td>Txt2Img</td><td>Avg</td><td>Img2Txt</td><td>Txt2Img</td><td>Avg</td><td>Img2Txt</td><td>Txt2Img</td><td>Avg</td></tr><tr><td>Ours(0-shot)</td><td>0.5391</td><td>0.5119</td><td>0.5255</td><td>0.5689</td><td>0.5894</td><td>0.5792</td><td>0.6901</td><td>0.6885</td><td>0.6893</td><td>0.6613</td><td>0.6803</td><td>0.6708</td></tr><tr><td>Ours(1-shot)</td><td>0.5512</td><td>0.5226</td><td>0.5369</td><td>0.5725</td><td>0.5919</td><td>0.5822</td><td>0.6950</td><td>0.6901</td><td>0.6926</td><td>0.6598</td><td>0.6766</td><td>0.6682</td></tr><tr><td>Ours(3-shot)</td><td>0.5941</td><td>0.5536</td><td>0.5738</td><td>0.6093</td><td>0.6262</td><td>0.6178</td><td>0.7126</td><td>0.7180</td><td>0.7153</td><td>0.6661</td><td>0.6869</td><td>0.6765</td></tr><tr><td>Ours(5-shot)</td><td>0.6133</td><td>0.5834</td><td>0.5984</td><td>0.6251</td><td>0.6434</td><td>0.6343</td><td>0.7254</td><td>0.7357</td><td>0.7306</td><td>0.6736</td><td>0.6912</td><td>0.6824</td></tr><tr><td>w/o VAE(0-shot)</td><td>0.5382</td><td>0.5122</td><td>0.5252</td><td>0.5666</td><td>0.5869</td><td>0.5768</td><td>0.6810</td><td>0.6829</td><td>0.6820</td><td>0.6560</td><td>0.6731</td><td>0.6646</td></tr><tr><td>w/o VAE(1-shot)</td><td>0.5404</td><td>0.5155</td><td>0.5280</td><td>0.5681</td><td>0.5880</td><td>0.5781</td><td>0.6890</td><td>0.6892</td><td>0.6891</td><td>0.6484</td><td>0.6696</td><td>0.6590</td></tr><tr><td>w/o VAE(3-shot)</td><td>0.5440</td><td>0.5211</td><td>0.5326</td><td>0.5688</td><td>0.5904</td><td>0.5796</td><td>0.6899</td><td>0.6935</td><td>0.6917</td><td>0.6585</td><td>0.6771</td><td>0.6678</td></tr><tr><td>w/o VAE(5-shot)</td><td>0.5533</td><td>0.5266</td><td>0.5400</td><td>0.5703</td><td>0.5911</td><td>0.5807</td><td>0.6950</td><td>0.6978</td><td>0.6964</td><td>0.6618</td><td>0.6795</td><td>0.6707</td></tr></table>

<table><tbody><tr><td rowspan="2">模型</td><td colspan="3">维基百科</td><td colspan="3">新加坡国立大学图像数据库10k(Nuswide-10k)</td><td colspan="3">帕斯卡句子(Pascal Sentence)</td><td colspan="3">新加坡国立大学图像数据库(NUSWIDE)</td></tr><tr><td>图像转文本(Img2Txt)</td><td>文本转图像(Txt2Img)</td><td>平均值</td><td>图像转文本(Img2Txt)</td><td>文本转图像(Txt2Img)</td><td>平均值</td><td>图像转文本(Img2Txt)</td><td>文本转图像(Txt2Img)</td><td>平均值</td><td>图像转文本(Img2Txt)</td><td>文本转图像(Txt2Img)</td><td>平均值</td></tr><tr><td>我们的方法(零样本)</td><td>0.5391</td><td>0.5119</td><td>0.5255</td><td>0.5689</td><td>0.5894</td><td>0.5792</td><td>0.6901</td><td>0.6885</td><td>0.6893</td><td>0.6613</td><td>0.6803</td><td>0.6708</td></tr><tr><td>我们的方法(单样本)</td><td>0.5512</td><td>0.5226</td><td>0.5369</td><td>0.5725</td><td>0.5919</td><td>0.5822</td><td>0.6950</td><td>0.6901</td><td>0.6926</td><td>0.6598</td><td>0.6766</td><td>0.6682</td></tr><tr><td>我们的方法(三样本)</td><td>0.5941</td><td>0.5536</td><td>0.5738</td><td>0.6093</td><td>0.6262</td><td>0.6178</td><td>0.7126</td><td>0.7180</td><td>0.7153</td><td>0.6661</td><td>0.6869</td><td>0.6765</td></tr><tr><td>我们的方法(五样本)</td><td>0.6133</td><td>0.5834</td><td>0.5984</td><td>0.6251</td><td>0.6434</td><td>0.6343</td><td>0.7254</td><td>0.7357</td><td>0.7306</td><td>0.6736</td><td>0.6912</td><td>0.6824</td></tr><tr><td>无变分自编码器(零样本)(w/o VAE(0-shot))</td><td>0.5382</td><td>0.5122</td><td>0.5252</td><td>0.5666</td><td>0.5869</td><td>0.5768</td><td>0.6810</td><td>0.6829</td><td>0.6820</td><td>0.6560</td><td>0.6731</td><td>0.6646</td></tr><tr><td>无变分自编码器(单样本)(w/o VAE(1-shot))</td><td>0.5404</td><td>0.5155</td><td>0.5280</td><td>0.5681</td><td>0.5880</td><td>0.5781</td><td>0.6890</td><td>0.6892</td><td>0.6891</td><td>0.6484</td><td>0.6696</td><td>0.6590</td></tr><tr><td>无变分自编码器(三样本)(w/o VAE(3-shot))</td><td>0.5440</td><td>0.5211</td><td>0.5326</td><td>0.5688</td><td>0.5904</td><td>0.5796</td><td>0.6899</td><td>0.6935</td><td>0.6917</td><td>0.6585</td><td>0.6771</td><td>0.6678</td></tr><tr><td>无变分自编码器(五样本)(w/o VAE(5-shot))</td><td>0.5533</td><td>0.5266</td><td>0.5400</td><td>0.5703</td><td>0.5911</td><td>0.5807</td><td>0.6950</td><td>0.6978</td><td>0.6964</td><td>0.6618</td><td>0.6795</td><td>0.6707</td></tr></tbody></table>

We take the zero-shot scenario as a testbed and report the average retrieval performance and the detailed results of the four datasets without residual gate network, and three loss functions as in Table 4. We can observe that using the proposed residual gate network in FLEX-CLIP obtains better performance on all the datasets than the scheme without a gate network, demonstrating that the selective fusion of the image and text features extracted by CLIP can greatly alleviate the feature degradation problem. Moreover, we can observe that the retrieval results of the three schemas, respectively without ${L}_{1},{L}_{2}$ , and ${L}_{3}$ , the cross-entropy loss function, modal consistency loss function, cross-modal comparison learning loss, respectively, all show a decrease in the MAP scores on both Img2Txt and Txt2Img task. Specifically, without the cross-modal comparison learning loss $\left( {L}_{3}\right)$ , the model presents a more significant decrease than the other two ablation models, indicating that the measuring distance between each sample and the other samples is more effective than directly modeling the distance between paired cross-modal samples, which contributes more to the bridge the heterogeneity multimodal gap in solving feature degradation.

我们以零样本场景作为测试平台，报告了在没有残差门控网络的情况下四个数据集的平均检索性能和详细结果，以及三种损失函数的情况，如表4所示。我们可以观察到，在FLEX - CLIP中使用所提出的残差门控网络在所有数据集上的性能都优于没有门控网络的方案，这表明对CLIP提取的图像和文本特征进行选择性融合可以大大缓解特征退化问题。此外，我们可以观察到，分别不使用${L}_{1},{L}_{2}$、${L}_{3}$(即交叉熵损失函数、模态一致性损失函数、跨模态对比学习损失)的三种方案，在Img2Txt和Txt2Img任务上的平均精度均值(MAP)得分均有所下降。具体而言，不使用跨模态对比学习损失$\left( {L}_{3}\right)$时，模型的性能下降比其他两个消融模型更为显著，这表明测量每个样本与其他样本之间的距离比直接建模配对跨模态样本之间的距离更有效，这在解决特征退化问题时更有助于弥合异质多模态差距。

## V. CONCLUSION

## 五、结论

In this paper, we propose Feature-Level GEneration Network to enhance CLIP features for X-shot CMR, a novel approach that performs feature generation. In multimodal feature generation, we design a composite multimodal VAE-GAN network, which combines the advantages of VAE and GAN to solve the data imbalance issue in few-shot cross-modal retrieval. Notably, the introduced VAE structure effectively improves the feature distribution of the generated features. In common space projection, by selectively fusing the original features extracted by CLIP and the features projected into a common space, our model fully utilizes the multimodal semantic information from the vision-language pretraining model. We have conducted several comprehensive experiments on four benchmark datasets, demonstrating the superiority of our proposed FLEX-CLIP method on both image-to-text and text-to-image cross-modal retrieval tasks and our results outperform the state-of-the-art. In future work, we attempt to improve the feature generation methods to generate features that can be generalized to more task scenarios in the multimodal community.

在本文中，我们提出了用于增强X样本跨模态检索(X - shot CMR)中CLIP特征的特征级生成网络(Feature - Level GEneration Network)，这是一种执行特征生成的新颖方法。在多模态特征生成方面，我们设计了一个复合多模态变分自编码器 - 生成对抗网络(VAE - GAN)，它结合了变分自编码器(VAE)和生成对抗网络(GAN)的优点，以解决少样本跨模态检索中的数据不平衡问题。值得注意的是，引入的VAE结构有效地改善了生成特征的特征分布。在公共空间投影中，通过选择性地融合CLIP提取的原始特征和投影到公共空间的特征，我们的模型充分利用了视觉 - 语言预训练模型中的多模态语义信息。我们在四个基准数据集上进行了多项综合实验，证明了我们提出的FLEX - CLIP方法在图像到文本和文本到图像的跨模态检索任务上的优越性，并且我们的结果优于现有技术水平。在未来的工作中，我们试图改进特征生成方法，以生成能够推广到多模态领域更多任务场景的特征。

## REFERENCES

## 参考文献

[1] N. Rasiwasia, J. Costa Pereira, E. Coviello, G. Doyle, G. R. Lanck-riet, R. Levy, and N. Vasconcelos, "A new approach to cross-modal multimedia retrieval," in Proceedings of the 18th ACM International Conference on Multimedia, MM '10, (New York, NY, USA), p. 251-260, Association for Computing Machinery, 2010.

[1] N. Rasiwasia、J. Costa Pereira、E. Coviello、G. Doyle、G. R. Lanck - riet、R. Levy和N. Vasconcelos，“一种新的跨模态多媒体检索方法”，收录于第18届ACM国际多媒体会议论文集，MM '10，(美国纽约州纽约市)，第251 - 260页，美国计算机协会，2010年。

[2] K. Wang, R. He, L. Wang, W. Wang, and T. Tan, "Joint feature selection and subspace learning for cross-modal retrieval," IEEE transactions on pattern analysis and machine intelligence, vol. 38, no. 10, pp. 2010- 2023, 2015.

[2] K. Wang、R. He、L. Wang、W. Wang和T. Tan，“用于跨模态检索的联合特征选择和子空间学习”，《IEEE模式分析与机器智能汇刊》，第38卷，第10期，第2010 - 2023页，2015年。

[3] X. Xu, L. He, H. Lu, L. Gao, and Y. Ji, "Deep adversarial metric learning for cross-modal retrieval," World Wide Web, vol. 22, pp. 657-672, 2019.

[3] X. Xu、L. He、H. Lu、L. Gao和Y. Ji，“用于跨模态检索的深度对抗度量学习”，《万维网》，第22卷，第657 - 672页，2019年。

[4] Y. Wei, Y. Zhao, C. Lu, S. Wei, L. Liu, Z. Zhu, and S. Yan, "Cross-modal retrieval with cnn visual features: A new baseline," IEEE transactions on cybernetics, vol. 47, no. 2, pp. 449-460, 2016.

[4] Y. Wei、Y. Zhao、C. Lu、S. Wei、L. Liu、Z. Zhu和S. Yan，“使用卷积神经网络视觉特征的跨模态检索:一个新的基线”，《IEEE控制论汇刊》，第47卷，第2期，第449 - 460页，2016年。

[5] X. Xu, K. Lin, H. Lu, L. Gao, and H. T. Shen, "Correlated features synthesis and alignment for zero-shot cross-modal retrieval," in Proceedings of the 43rd International ACM SIGIR Conference on Research and Development in Information Retrieval, pp. 1419-1428, 2020.

[5] X. Xu、K. Lin、H. Lu、L. Gao和H. T. Shen，“用于零样本跨模态检索的相关特征合成与对齐”，收录于第43届ACM SIGIR国际信息检索研究与发展会议论文集，第1419 - 1428页，2020年。

[6] X. Xu, H. Lu, J. Song, Y. Yang, H. T. Shen, and X. Li, "Ternary adversarial networks with self-supervision for zero-shot cross-modal retrieval," IEEE Transactions on Cybernetics, vol. 50, no. 6, pp. 2400- 2413, 2020.

[6] X. Xu、H. Lu、J. Song、Y. Yang、H. T. Shen和X. Li，“用于零样本跨模态检索的具有自监督的三元对抗网络”，《IEEE控制论汇刊》，第50卷，第6期，第2400 - 2413页，2020年。

[7] J. Chi and Y. Peng, "Zero-shot cross-media embedding learning with dual adversarial distribution network," IEEE Transactions on Circuits and Systems for Video Technology, vol. 30, no. 4, pp. 1173-1187, 2019.

[7] J. Chi和Y. Peng，“使用双对抗分布网络的零样本跨媒体嵌入学习”，《IEEE电路与系统视频技术汇刊》，第30卷，第4期，第1173 - 1187页，2019年。

[8] K. Lin, X. Xu, L. Gao, Z. Wang, and H. T. Shen, "Learning cross-aligned latent embeddings for zero-shot cross-modal retrieval," in Proceedings of the AAAI Conference on Artificial Intelligence, vol. 34, pp. 11515- 11522, 2020.

[8] 林凯(K. Lin)、徐翔(X. Xu)、高磊(L. Gao)、王哲(Z. Wang)和沈海涛(H. T. Shen)，“用于零样本跨模态检索的学习交叉对齐潜在嵌入”，发表于《人工智能协会会议论文集》(Proceedings of the AAAI Conference on Artificial Intelligence)，第34卷，第11515 - 11522页，2020年。

[9] A. Frome, G. S. Corrado, J. Shlens, S. Bengio, J. Dean, M. Ranzato, and T. Mikolov, "Devise: A deep visual-semantic embedding model," Advances in neural information processing systems, vol. 26, 2013.

[9] 阿隆·弗罗姆(A. Frome)、格雷格·S·科拉多(G. S. Corrado)、杰弗里·施伦斯(J. Shlens)、扬·勒昆(S. Bengio)、杰夫·迪恩(J. Dean)、马蒂亚斯·兰扎托(M. Ranzato)和托马斯·米科洛夫(T. Mikolov)，“Devise:一种深度视觉语义嵌入模型”，《神经信息处理系统进展》(Advances in neural information processing systems)，第26卷，2013年。

[10] Z. Akata, F. Perronnin, Z. Harchaoui, and C. Schmid, "Label-embedding for attribute-based classification," in Proceedings of the IEEE conference on computer vision and pattern recognition, pp. 819-826, 2013.

[10] 泽内普·阿卡塔(Z. Akata)、弗朗索瓦·佩罗宁(F. Perronnin)、泽维尔·哈查维(Z. Harchaoui)和克里斯托夫·施密德(C. Schmid)，“基于属性分类的标签嵌入”，发表于《电气与电子工程师协会计算机视觉与模式识别会议论文集》(Proceedings of the IEEE conference on computer vision and pattern recognition)，第819 - 826页，2013年。

[11] X. Xu, J. Tian, K. Lin, H. Lu, J. Shao, and H. T. Shen, "Zero-shot cross-modal retrieval by assembling autoencoder and generative adversarial network," ACM Transactions on Multimedia Computing, Communications, and Applications (TOMM), vol. 17, no. 1s, pp. 1-17, 2021.

[11] 徐翔(X. Xu)、田杰(J. Tian)、林凯(K. Lin)、卢华(H. Lu)、邵杰(J. Shao)和沈海涛(H. T. Shen)，“通过组装自动编码器和生成对抗网络实现零样本跨模态检索”，《ACM多媒体计算、通信与应用汇刊》(ACM Transactions on Multimedia Computing, Communications, and Applications (TOMM))，第17卷，第1s期，第1 - 17页，2021年。

[12] J. Tian, K. Wang, X. Xu, Z. Cao, F. Shen, and H. T. Shen, "Multimodal disentanglement variational autoencoders for zero-shot cross-modal retrieval," in Proceedings of the 45th International ACM SIGIR Conference on Research and Development in Information Retrieval, pp. 960-969, 2022.

[12] 田杰(J. Tian)、王凯(K. Wang)、徐翔(X. Xu)、曹泽(Z. Cao)、沈峰(F. Shen)和沈海涛(H. T. Shen)，“用于零样本跨模态检索的多模态解纠缠变分自动编码器”，发表于《第45届国际ACM SIGIR信息检索研究与发展会议论文集》(Proceedings of the 45th International ACM SIGIR Conference on Research and Development in Information Retrieval)，第960 - 969页，2022年。

[13] X. Xu, K. Lin, Y. Yang, A. Hanjalic, and H. T. Shen, "Joint feature synthesis and embedding: Adversarial cross-modal retrieval revisited," IEEE Transactions on Pattern Analysis and Machine Intelligence, vol. 44, no. 6, pp. 3030-3047, 2022.

[13] 徐翔(X. Xu)、林凯(K. Lin)、杨阳(Y. Yang)、阿杰·汉贾利奇(A. Hanjalic)和沈海涛(H. T. Shen)，“联合特征合成与嵌入:重新审视对抗性跨模态检索”，《电气与电子工程师协会模式分析与机器智能汇刊》(IEEE Transactions on Pattern Analysis and Machine Intelligence)，第44卷，第6期，第3030 - 3047页，2022年。

[14] J. Chi and Y. Peng, "Dual adversarial networks for zero-shot cross-media retrieval.," in IJCAI, pp. 663-669, 2018.

[14] 迟杰(J. Chi)和彭勇(Y. Peng)，“用于零样本跨媒体检索的双对抗网络”，发表于《国际人工智能联合会议》(IJCAI)，第663 - 669页，2018年。

[15] Z. Han, Z. Fu, S. Chen, and J. Yang, "Contrastive embedding for generalized zero-shot learning," in Proceedings of the IEEE/CVF conference on computer vision and pattern recognition, pp. 2371-2381, 2021.

[15] 韩泽(Z. Han)、付泽(Z. Fu)、陈硕(S. Chen)和杨杰(J. Yang)，“用于广义零样本学习的对比嵌入”，发表于《电气与电子工程师协会/计算机视觉基金会计算机视觉与模式识别会议论文集》(Proceedings of the IEEE/CVF conference on computer vision and pattern recognition)，第2371 - 2381页，2021年。

[16] P. Ma, R. Wu, and H. Lu, "Semantic-related feature generation for generalized zero-shot learning," in 2022 IEEE International Conference on Multimedia and Expo (ICME), pp. 1-6, 2022.

[16] 马鹏(P. Ma)、吴锐(R. Wu)和卢华(H. Lu)，“用于广义零样本学习的语义相关特征生成”，发表于《2022年电气与电子工程师协会国际多媒体与博览会》(2022 IEEE International Conference on Multimedia and Expo (ICME))，第1 - 6页，2022年。

[17] Y. Xian, S. Sharma, B. Schiele, and Z. Akata, "F-vaegan-d2: A feature generating framework for any-shot learning," in 2019 IEEE/CVF Conference on Computer Vision and Pattern Recognition (CVPR), pp. 10267- 10276, 2019.

[17] 扬·西安(Y. Xian)、桑杰·沙玛(S. Sharma)、伯恩特·施莱尔(B. Schiele)和泽内普·阿卡塔(Z. Akata)，“F - vaegan - d2:一种适用于任意样本学习的特征生成框架”，发表于《2019年电气与电子工程师协会/计算机视觉基金会计算机视觉与模式识别会议》(2019 IEEE/CVF Conference on Computer Vision and Pattern Recognition (CVPR))，第10267 - 10276页，2019年。

[18] C. Deng, Z. Chen, X. Liu, X. Gao, and D. Tao, "Triplet-based deep hashing network for cross-modal retrieval," IEEE Transactions on Image

[18] 邓聪(C. Deng)、陈泽(Z. Chen)、刘晓(X. Liu)、高翔(X. Gao)和陶德(D. Tao)，“基于三元组的深度哈希网络用于跨模态检索”，《电气与电子工程师协会图像处理汇刊》(IEEE Transactions on Image

Processing, vol. 27, no. 8, pp. 3893-3903, 2018.

Processing)，第27卷，第8期，第3893 - 3903页，2018年。

[19] T. Wang, X. Xu, Y. Yang, A. Hanjalic, H. T. Shen, and J. Song, "Matching images and text with multi-modal tensor fusion and re-ranking," in Proceedings of the 27th ACM international conference on multimedia, pp. 12-20, 2019.

[19] 王涛(T. Wang)、徐翔(X. Xu)、杨阳(Y. Yang)、阿杰·汉贾利奇(A. Hanjalic)、沈海涛(H. T. Shen)和宋杰(J. Song)，“通过多模态张量融合和重排序匹配图像和文本”，发表于《第27届ACM国际多媒体会议论文集》(Proceedings of the 27th ACM international conference on multimedia)，第12 - 20页，2019年。

[20] B. Wang, Y. Yang, X. Xu, A. Hanjalic, and H. T. Shen, "Adversarial cross-modal retrieval," in Proceedings of the 25th ACM international conference on Multimedia, pp. 154-162, 2017.

[20] 王博(B. Wang)、杨阳(Y. Yang)、徐翔(X. Xu)、阿杰·汉贾利奇(A. Hanjalic)和沈海涛(H. T. Shen)，“对抗性跨模态检索”，发表于《第25届ACM国际多媒体会议论文集》(Proceedings of the 25th ACM international conference on Multimedia)，第154 - 162页，2017年。

[21] M. Hafner, M. Katsantoni, T. Köster, J. Marks, J. Mukherjee, D. Staiger, J. Ule, and M. Zavolan, "Clip and complementary methods," Nature Reviews Methods Primers, vol. 1, no. 1, p. 20, 2021.

[21] 马蒂亚斯·哈夫纳(M. Hafner)、玛丽亚·卡桑托尼(M. Katsantoni)、托马斯·科斯特(T. Köster)、约翰·马克斯(J. Marks)、贾扬塔·慕克吉(J. Mukherjee)、丹尼尔·施泰格(D. Staiger)、尤雷·乌勒(J. Ule)和米夏埃尔·扎沃兰(M. Zavolan)，“CLIP及补充方法”，《自然综述:方法入门》(Nature Reviews Methods Primers)，第1卷，第1期，第20页，2021年。

[22] A. Radford, J. W. Kim, C. Hallacy, A. Ramesh, G. Goh, S. Agarwal, G. Sastry, A. Askell, P. Mishkin, J. Clark, et al., "Learning transferable visual models from natural language supervision," in International conference on machine learning, pp. 8748-8763, PMLR, 2021.

[22] A. 拉德福德(A. Radford)、J. W. 金(J. W. Kim)、C. 哈拉西(C. Hallacy)、A. 拉梅什(A. Ramesh)、G. 戈(G. Goh)、S. 阿加瓦尔(S. Agarwal)、G. 萨斯特里(G. Sastry)、A. 阿斯凯尔(A. Askell)、P. 米什金(P. Mishkin)、J. 克拉克(J. Clark)等，“从自然语言监督中学习可迁移的视觉模型”，载于国际机器学习会议论文集，第8748 - 8763页，机器学习研究会议录(PMLR)，2021年。

[23] H. Hotelling, Relations Between Two Sets of Variates, pp. 162-190. New York, NY: Springer New York, 1992.

[23] H. 霍特林(H. Hotelling)，《两组变量之间的关系》，第162 - 190页。纽约，纽约州:施普林格纽约出版社(Springer New York)，1992年。

[24] X. Zhai, Y. Peng, and J. Xiao, "Learning cross-media joint representation with sparse and semisupervised regularization," IEEE Transactions on Circuits and Systems for Video Technology, vol. 24, no. 6, pp. 965-978, 2014.

[24] 翟X.(X. Zhai)、彭Y.(Y. Peng)和肖J.(J. Xiao)，“利用稀疏和半监督正则化学习跨媒体联合表示”，《IEEE电路与系统视频技术汇刊》，第24卷，第6期，第965 - 978页，2014年。

[25] Y. Wang and Y. Peng, "Mars: Learning modality-agnostic representation for scalable cross-media retrieval," IEEE Transactions on Circuits and Systems for Video Technology, vol. 32, no. 7, pp. 4765-4777, 2022.

[25] 王Y.(Y. Wang)和彭Y.(Y. Peng)，“火星(Mars):为可扩展的跨媒体检索学习模态无关表示”，《IEEE电路与系统视频技术汇刊》，第32卷，第7期，第4765 - 4777页，2022年。

[26] P. Hu, X. Peng, H. Zhu, L. Zhen, and J. Lin, "Learning cross-modal retrieval with noisy labels," in 2021 IEEE/CVF Conference on Computer Vision and Pattern Recognition (CVPR), pp. 5399-5409, 2021.

[26] 胡P.(P. Hu)、彭X.(X. Peng)、朱H.(H. Zhu)、甄L.(L. Zhen)和林J.(J. Lin)，“利用噪声标签进行跨模态检索学习”，载于2021年IEEE/CVF计算机视觉与模式识别会议(CVPR)论文集，第5399 - 5409页，2021年。

[27] T. Baltrušaitis, C. Ahuja, and L.-P. Morency, "Multimodal machine learning: A survey and taxonomy," IEEE transactions on pattern analysis and machine intelligence, vol. 41, no. 2, pp. 423-443, 2018.

[27] T. 巴尔图塞蒂斯(T. Baltrušaitis)、C. 阿胡贾(C. Ahuja)和L.-P. 莫伦西(L.-P. Morency)，“多模态机器学习:综述与分类”，《IEEE模式分析与机器智能汇刊》，第41卷，第2期，第423 - 443页，2018年。

[28] P. Xu, X. Zhu, and D. A. Clifton, "Multimodal learning with transformers: A survey," IEEE Transactions on Pattern Analysis and Machine Intelligence, 2023.

[28] 徐P.(P. Xu)、朱X.(X. Zhu)和D. A. 克利夫顿(D. A. Clifton)，“基于Transformer的多模态学习:综述”，《IEEE模式分析与机器智能汇刊》，2023年。

[29] K. Bayoudh, R. Knani, F. Hamdaoui, and A. Mtibaa, "A survey on deep multimodal learning for computer vision: advances, trends, applications, and datasets," The Visual Computer, vol. 38, no. 8, pp. 2939-2970, 2022.

[29] K. 巴尤德(K. Bayoudh)、R. 克纳尼(R. Knani)、F. 哈姆达维(F. Hamdaoui)和A. 姆蒂巴(A. Mtibaa)，“计算机视觉深度多模态学习综述:进展、趋势、应用和数据集”，《可视化计算机》，第38卷，第8期，第2939 - 2970页，2022年。

[30] J. Gao, P. Li, Z. Chen, and J. Zhang, "A survey on deep learning for multimodal data fusion," Neural Computation, vol. 32, no. 5, pp. 829- 864, 2020.

[30] 高J.(J. Gao)、李P.(P. Li)、陈Z.(Z. Chen)和张J.(J. Zhang)，“多模态数据融合的深度学习综述”，《神经计算》，第32卷，第5期，第829 - 864页，2020年。

[31] L. Zhen, P. Hu, X. Wang, and D. Peng, "Deep supervised cross-modal retrieval," in Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition, pp. 10394-10403, 2019.

[31] 甄L.(L. Zhen)、胡P.(P. Hu)、王X.(X. Wang)和彭D.(D. Peng)，“深度监督跨模态检索”，载于IEEE/CVF计算机视觉与模式识别会议论文集，第10394 - 10403页，2019年。

[32] S. Chun, S. J. Oh, R. S. De Rezende, Y. Kalantidis, and D. Larlus, "Probabilistic embeddings for cross-modal retrieval," in Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition, pp. 8415-8424, 2021.

[32] S. 春(S. Chun)、S. J. 吴(S. J. Oh)、R. S. 德雷森德(R. S. De Rezende)、Y. 卡兰蒂迪斯(Y. Kalantidis)和D. 拉卢斯(D. Larlus)，“用于跨模态检索的概率嵌入”，载于IEEE/CVF计算机视觉与模式识别会议论文集，第8415 - 8424页，2021年。

[33] F. Pourpanah, M. Abdar, Y. Luo, X. Zhou, R. Wang, C. P. Lim, X.-Z. Wang, and Q. J. Wu, "A review of generalized zero-shot learning methods," IEEE transactions on pattern analysis and machine intelligence, 2022.

[33] F. 普尔帕纳(F. Pourpanah)、M. 阿卜达尔(M. Abdar)、罗Y.(Y. Luo)、周X.(X. Zhou)、王R.(R. Wang)、林C. P.(C. P. Lim)、王X.-Z.(X.-Z. Wang)和吴Q. J.(Q. J. Wu)，“广义零样本学习方法综述”，《IEEE模式分析与机器智能汇刊》，2022年。

[34] M. Wortsman, G. Ilharco, J. W. Kim, M. Li, S. Kornblith, R. Roelofs, R. G. Lopes, H. Hajishirzi, A. Farhadi, H. Namkoong, et al., "Robust fine-tuning of zero-shot models," in Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition, pp. 7959- 7971, 2022.

[34] M. 沃茨曼(M. Wortsman)、G. 伊尔哈科(G. Ilharco)、J. W. 金(J. W. Kim)、李M.(M. Li)、S. 科恩布利思(S. Kornblith)、R. 罗洛夫斯(R. Roelofs)、R. G. 洛佩斯(R. G. Lopes)、H. 哈吉希尔齐(H. Hajishirzi)、A. 法尔哈迪(A. Farhadi)、H. 南孔(H. Namkoong)等，“零样本模型的鲁棒微调”，载于IEEE/CVF计算机视觉与模式识别会议论文集，第7959 - 7971页，2022年。

[35] Y. Xian, S. Sharma, B. Schiele, and Z. Akata, "f-vaegan-d2: A feature generating framework for any-shot learning," in Proceedings of the IEEE/CVF conference on computer vision and pattern recognition, pp. 10275-10284, 2019.

[35] 西安Y.(Y. Xian)、夏尔马S.(S. Sharma)、席勒B.(B. Schiele)和阿卡塔Z.(Z. Akata)，“f - vaegan - d2:用于任意样本学习的特征生成框架”，载于IEEE/CVF计算机视觉与模式识别会议论文集，第10275 - 10284页，2019年。

[36] M. Arjovsky and L. Bottou, "Towards principled methods for training generative adversarial networks," in International Conference on Learning Representations, 2016.

[36] M. 阿乔夫斯基(M. Arjovsky)和L. 博图(L. Bottou)，“迈向训练生成对抗网络的原则性方法”，载于国际学习表征会议论文集，2016年。

[37] I. Gulrajani, F. Ahmed, M. Arjovsky, V. Dumoulin, and A. C. Courville, "Improved training of wasserstein gans," Advances in neural information processing systems, vol. 30, 2017.

[37] I. 古尔拉贾尼(I. Gulrajani)、F. 艾哈迈德(F. Ahmed)、M. 阿尔乔夫斯基(M. Arjovsky)、V. 杜穆林(V. Dumoulin)和 A. C. 库尔维尔(A. C. Courville)，“改进瓦瑟斯坦生成对抗网络的训练”，《神经信息处理系统进展》，第 30 卷，2017 年。

[38] T. Miyato, T. Kataoka, M. Koyama, and Y. Yoshida, "Spectral normalization for generative adversarial networks," in International Conference on Learning Representations, 2018.

[38] T. 宫戸(T. Miyato)、T. 片冈(T. Kataoka)、M. 小山(M. Koyama)和 Y. 吉田(Y. Yoshida)，“生成对抗网络的谱归一化”，《国际学习表征会议》，2018 年。

[39] C. Rashtchian, P. Young, M. Hodosh, and J. Hockenmaier, "Collecting image annotations using amazon's mechanical turk," in Proceedings of

[39] C. 拉什奇安(C. Rashtchian)、P. 杨(P. Young)、M. 霍多什(M. Hodosh)和 J. 霍肯迈尔(J. Hockenmaier)，“使用亚马逊土耳其机器人收集图像注释”，见《

the NAACL HLT 2010 workshop on creating speech and language data with Amazon's Mechanical Turk, pp. 139-147, 2010.

2010 年北美计算语言学协会人机交互技术研讨会:利用亚马逊土耳其机器人创建语音和语言数据会议论文集》，第 139 - 147 页，2010 年。

[40] T.-S. Chua, J. Tang, R. Hong, H. Li, Z. Luo, and Y. Zheng, "Nus-wide: a real-world web image database from national university of singapore," in Proceedings of the ACM international conference on image and video

[40] T.-S. 蔡(T.-S. Chua)、J. 唐(J. Tang)、R. 洪(R. Hong)、H. 李(H. Li)、Z. 罗(Z. Luo)和 Y. 郑(Y. Zheng)，“Nus - wide:新加坡国立大学的真实网络图像数据库”，见《ACM 国际图像与视频检索会议论文集》

retrieval, pp. 1-9, 2009.

，第 1 - 9 页，2009 年。

[41] C. Zhang, J. Song, X. Zhu, L. Zhu, and S. Zhang, "Hemsl: Hybrid cross-modal similarity learning for cross-modal retrieval," ACM Transactions on Multimedia Computing, Communications, and Applications (TOMM), vol. 17, no. 1s, pp. 1-22, 2021.

[41] C. 张(C. Zhang)、J. 宋(J. Song)、X. 朱(X. Zhu)、L. 朱(L. Zhu)和 S. 张(S. Zhang)，“Hemsl:用于跨模态检索的混合跨模态相似性学习”，《ACM 多媒体计算、通信与应用汇刊》(TOMM)，第 17 卷，第 1s 期，第 1 - 22 页，2021 年。

[42] S.-V. Bogolin, I. Croitoru, H. Jin, Y. Liu, and S. Albanie, "Cross modal retrieval with querybank normalisation," in Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition, pp. 5194-5205, 2022.

[42] S.-V. 博戈林(S.-V. Bogolin)、I. 克罗伊托鲁(I. Croitoru)、H. 金(H. Jin)、Y. 刘(Y. Liu)和 S. 阿尔巴尼(S. Albanie)，“使用查询库归一化的跨模态检索”，见《IEEE/CVF 计算机视觉与模式识别会议论文集》，第 5194 - 5205 页，2022 年。

[43] P. Kaur, H. S. Pannu, and A. K. Malhi, "Comparative analysis on cross-modal information retrieval: A review," Computer Science Review, vol. 39, p. 100336, 2021.

[43] P. 考尔(P. Kaur)、H. S. 潘努(H. S. Pannu)和 A. K. 马尔希(A. K. Malhi)，“跨模态信息检索的比较分析:综述”，《计算机科学评论》，第 39 卷，第 100336 页，2021 年。

[44] R. Socher, M. Ganjoo, C. D. Manning, and A. Ng, "Zero-shot learning through cross-modal transfer," Advances in neural information processing systems, vol. 26, 2013.

[44] R. 索切尔(R. Socher)、M. 甘乔(M. Ganjoo)、C. D. 曼宁(C. D. Manning)和 A. 吴(A. Ng)，“通过跨模态转移实现零样本学习”，《神经信息处理系统进展》，第 26 卷，2013 年。

[45] X. Sun, J. Gu, and H. Sun, "Research progress of zero-shot learning," Applied Intelligence, vol. 51, pp. 3600-3614, 2021.

[45] X. 孙(X. Sun)、J. 顾(J. Gu)和 H. 孙(H. Sun)，“零样本学习的研究进展”，《应用智能》，第 51 卷，第 3600 - 3614 页，2021 年。

[46] S. Liu, M. Long, J. Wang, and M. I. Jordan, "Generalized zero-shot learning with deep calibration network," Advances in neural information processing systems, vol. 31, 2018.

[46] S. 刘(S. Liu)、M. 龙(M. Long)、J. 王(J. Wang)和 M. I. 乔丹(M. I. Jordan)，“使用深度校准网络的广义零样本学习”，《神经信息处理系统进展》，第 31 卷，2018 年。

[47] Y.-Y. Chou, H.-T. Lin, and T.-L. Liu, "Adaptive and generative zero-shot learning," in International conference on learning representations, 2020.

[47] Y.-Y. 周(Y.-Y. Chou)、H.-T. 林(H.-T. Lin)和 T.-L. 刘(T.-L. Liu)，“自适应生成式零样本学习”，《国际学习表征会议》，2020 年。

[48] S. Chen, W. Wang, B. Xia, Q. Peng, X. You, F. Zheng, and L. Shao, "Free: Feature refinement for generalized zero-shot learning," in Proceedings of the IEEE/CVF international conference on computer vision, pp. 122-131, 2021.

[48] S. 陈(S. Chen)、W. 王(W. Wang)、B. 夏(B. Xia)、Q. 彭(Q. Peng)、X. 尤(X. You)、F. 郑(F. Zheng)和 L. 邵(L. Shao)，“Free:广义零样本学习的特征细化”，见《IEEE/CVF 国际计算机视觉会议论文集》，第 122 - 131 页，2021 年。

[49] W. Xu, Y. Xian, J. Wang, B. Schiele, and Z. Akata, "Attribute prototype network for zero-shot learning," Advances in Neural Information Processing Systems, vol. 33, pp. 21969-21980, 2020.

[49] W. 徐(W. Xu)、Y. 西安(Y. Xian)、J. 王(J. Wang)、B. 席勒(B. Schiele)和 Z. 阿卡塔(Z. Akata)，“用于零样本学习的属性原型网络”，《神经信息处理系统进展》，第 33 卷，第 21969 - 21980 页，2020 年。

[50] K. He, X. Zhang, S. Ren, and J. Sun, "Deep residual learning for image recognition," in Proceedings of the IEEE conference on computer vision and pattern recognition, pp. 770-778, 2016.

[50] K. 何(K. He)、X. 张(X. Zhang)、S. 任(S. Ren)和 J. 孙(J. Sun)，“用于图像识别的深度残差学习”，见《IEEE 计算机视觉与模式识别会议论文集》，第 770 - 778 页，2016 年。

[51] J. D. M.-W. C. Kenton and L. K. Toutanova, "Bert: Pre-training of deep bidirectional transformers for language understanding," in Proceedings of NAACL-HLT, pp. 4171-4186, 2019.

[51] J. D. M.-W. C. 肯顿(J. D. M.-W. C. Kenton)和 L. K. 图塔诺娃(L. K. Toutanova)，“BERT:用于语言理解的深度双向变换器预训练(Bert: Pre-training of deep bidirectional transformers for language understanding)”，载于《北美计算语言学协会人类语言技术会议论文集》(Proceedings of NAACL-HLT)，第 4171 - 4186 页，2019 年。

[52] F. Feng, X. Wang, and R. Li, "Cross-modal retrieval with correspondence autoencoder," in Proceedings of the 22nd ACM International Conference on Multimedia, MM '14, (New York, NY, USA), p. 7-16, Association for Computing Machinery, 2014.

[52] 冯 F.(F. Feng)、王 X.(X. Wang)和李 R.(R. Li)，“基于对应自编码器的跨模态检索(Cross-modal retrieval with correspondence autoencoder)”，载于《第 22 届 ACM 国际多媒体会议论文集》(Proceedings of the 22nd ACM International Conference on Multimedia)，MM '14，(美国纽约州纽约市)，第 7 - 16 页，美国计算机协会，2014 年。

[53] J. Rao, Z. Shan, L. Liu, Y. Zhou, and Y. Yang, "Retrieval-based knowledge augmented vision language pre-training," in Proceedings of the 31st ACM International Conference on Multimedia, MM '23, (New York, NY, USA), p. 5399-5409, Association for Computing Machinery, 2023.

[53] 饶 J.(J. Rao)、单 Z.(Z. Shan)、刘 L.(L. Liu)、周 Y.(Y. Zhou)和杨 Y.(Y. Yang)，“基于检索的知识增强视觉语言预训练(Retrieval-based knowledge augmented vision language pre-training)”，载于《第 31 届 ACM 国际多媒体会议论文集》(Proceedings of the 31st ACM International Conference on Multimedia)，MM '23，(美国纽约州纽约市)，第 5399 - 5409 页，美国计算机协会，2023 年。

[54] F. Chen, D. Zhang, X. Chen, J. Shi, S. Xu, and B. XU, "Unsupervised and pseudo-supervised vision-language alignment in visual dialog," in Proceedings of the 30th ACM International Conference on Multimedia, MM '22, (New York, NY, USA), p. 4142-4153, Association for Computing Machinery, 2022.

[54] 陈 F.(F. Chen)、张 D.(D. Zhang)、陈 X.(X. Chen)、施 J.(J. Shi)、徐 S.(S. Xu)和徐 B.(B. XU)，“视觉对话中的无监督和伪监督视觉 - 语言对齐(Unsupervised and pseudo-supervised vision-language alignment in visual dialog)”，载于《第 30 届 ACM 国际多媒体会议论文集》(Proceedings of the 30th ACM International Conference on Multimedia)，MM '22，(美国纽约州纽约市)，第 4142 - 4153 页，美国计算机协会，2022 年。

[55] B. Zou, C. Yang, C. Quan, and Y. Zhao, "Spaceclip: A vision-language pretraining framework with spatial reconstruction on text," in Proceedings of the 31st ACM International Conference on Multimedia, MM '23, (New York, NY, USA), p. 519-528, Association for Computing Machinery, 2023.

[55] 邹 B.(B. Zou)、杨 C.(C. Yang)、全 C.(C. Quan)和赵 Y.(Y. Zhao)，“Spaceclip:一种基于文本空间重建的视觉 - 语言预训练框架(Spaceclip: A vision-language pretraining framework with spatial reconstruction on text)”，载于《第 31 届 ACM 国际多媒体会议论文集》(Proceedings of the 31st ACM International Conference on Multimedia)，MM '23，(美国纽约州纽约市)，第 519 - 528 页，美国计算机协会，2023 年。

[56] C.-W. Xie, J. Wu, Y. Zheng, P. Pan, and X.-S. Hua, "Token embeddings alignment for cross-modal retrieval," in Proceedings of the 30th ACM International Conference on Multimedia, MM '22, (New York, NY, USA), p. 4555-4563, Association for Computing Machinery, 2022.

[56] 谢 C.-W.(C.-W. Xie)、吴 J.(J. Wu)、郑 Y.(Y. Zheng)、潘 P.(P. Pan)和华 X.-S.(X.-S. Hua)，“用于跨模态检索的词元嵌入对齐(Token embeddings alignment for cross-modal retrieval)”，载于《第 30 届 ACM 国际多媒体会议论文集》(Proceedings of the 30th ACM International Conference on Multimedia)，MM '22，(美国纽约州纽约市)，第 4555 - 4563 页，美国计算机协会，2022 年。

[57] D. Semedo and J. Magalhaes, "Diachronic cross-modal embeddings," in Proceedings of the 27th ACM International Conference on Multimedia, MM '19, (New York, NY, USA), p. 2061-2069, Association for Computing Machinery, 2019.

[57] D. 塞梅多(D. Semedo)和 J. 马加良斯(J. Magalhaes)，“历时跨模态嵌入(Diachronic cross-modal embeddings)”，载于《第 27 届 ACM 国际多媒体会议论文集》(Proceedings of the 27th ACM International Conference on Multimedia)，MM '19，(美国纽约州纽约市)，第 2061 - 2069 页，美国计算机协会，2019 年。

[58] D. Chen, M. Wang, H. Chen, L. Wu, J. Qin, and W. Peng, "Cross-modal retrieval with heterogeneous graph embedding," in Proceedings of the 30th ACM International Conference on Multimedia, MM '22, (New York, NY, USA), p. 3291-3300, Association for Computing Machinery, 2022.

[58] 陈 D.(D. Chen)、王 M.(M. Wang)、陈 H.(H. Chen)、吴 L.(L. Wu)、秦 J.(J. Qin)和彭 W.(W. Peng)，“基于异构图嵌入的跨模态检索(Cross-modal retrieval with heterogeneous graph embedding)”，载于《第 30 届 ACM 国际多媒体会议论文集》(Proceedings of the 30th ACM International Conference on Multimedia)，MM '22，(美国纽约州纽约市)，第 3291 - 3300 页，美国计算机协会，2022 年。

Jingyou Xie received the Master degree from the School of Intelligent Systems Engineering, Sun Yat-Sen University, in 2024. He is mainly focusing on multimodal search and cross-modal retrieval.

谢景佑于 2024 年从中山大学智能系统工程学院获得硕士学位。他主要专注于多模态搜索和跨模态检索。

Jiayi Kuang received the BEng degree from the School of Intelligent Systems Engineering, Sun Yat-Sen University, in 2024. She is currently working toward Master's degree with the School of Intelligent Systems Engineering, Sun Yat-Sen University and mainly focusing on natural language reasoning, multimodal question answering and multimodal large language models.

匡佳怡于 2024 年从中山大学智能系统工程学院获得工学学士学位。她目前正在中山大学智能系统工程学院攻读硕士学位，主要专注于自然语言推理、多模态问答和多模态大语言模型。

Zhenzhou Lin received the Master degree from the School of Intelligent Systems Engineering, Sun Yat-Sen University, in 2024. He is mainly focusing on natural language processing and knowledge graph sampling.

林振洲于 2024 年从中山大学智能系统工程学院获得硕士学位。他主要专注于自然语言处理和知识图谱采样。

Jiarui Ouyang is currently working toward BEng's degree with the School of Intelligent Systems Engineering, Sun Yat-Sen University and mainly focusing on large language models.

欧阳佳锐目前正在中山大学智能系统工程学院攻读工学学士学位，主要专注于大语言模型。

Zishuo Zhao received the Master degree from the School of Intelligent Systems Engineering, Sun Yat-Sen University, in 2024. He is mainly focusing on natural language processing and multimodal learning.

赵子硕于 2024 年从中山大学智能系统工程学院获得硕士学位。他主要专注于自然语言处理和多模态学习。

Ying Shen is now an Associate Professor in School of Intelligent Systems Engineering, Sun Yat-Sen University. She received her Ph.D. degree from the University of Paris Ouest Nanterre La Défense (France), specialized in Computer Science. She received her Erasmus Mundus Master degree in Natural Language Processing from France and England. Her research interests include Natural Language Processing and multimodal deep learning.

沈莹现为中山大学智能系统工程学院副教授。她在法国巴黎西楠泰尔大学(University of Paris Ouest Nanterre La Défense)获得博士学位，专业为计算机科学。她还从法国和英国获得了伊拉斯谟世界计划自然语言处理硕士学位。她的研究兴趣包括自然语言处理和多模态深度学习。