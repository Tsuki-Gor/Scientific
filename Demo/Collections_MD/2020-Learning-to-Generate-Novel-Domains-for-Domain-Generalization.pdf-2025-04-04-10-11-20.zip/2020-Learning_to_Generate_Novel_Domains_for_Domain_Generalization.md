# Learning to Generate Novel Domains for Domain Generalization

# 学习为领域泛化生成新领域

Kaiyang Zhou ${}^{1\left( \infty \right) }$ , Yongxin Yang ${}^{1}$ , Timothy Hospedales ${}^{2,3}$ , and Tao Xiang ${}^{1,3}$

周开阳 ${}^{1\left( \infty \right) }$ ，杨永新 ${}^{1}$ ，蒂莫西·霍斯佩代尔斯 ${}^{2,3}$ ，以及向涛 ${}^{1,3}$

${}^{1}$ University of Surrey, Guildford, UK

${}^{1}$ 英国吉尔福德萨里大学

\{k.zhou, yongxin.yang, t.xiang\}@surrey.ac.uk

\{k.zhou, yongxin.yang, t.xiang\}@surrey.ac.uk

${}^{2}$ University of Edinburgh, Edinburgh, UK

${}^{2}$ 英国爱丁堡大学

t.hospedales@ed.ac.uk

${}^{3}$ Samsung AI Center, Cambridge, UK

${}^{3}$ 英国剑桥三星人工智能中心

Abstract. This paper focuses on domain generalization (DG), the task of learning from multiple source domains a model that generalizes well to unseen domains. A main challenge for DG is that the available source domains often exhibit limited diversity, hampering the model's ability to learn to generalize. We therefore employ a data generator to synthesize data from pseudo-novel domains to augment the source domains. This explicitly increases the diversity of available training domains and leads to a more generalizable model. To train the generator, we model the distribution divergence between source and synthesized pseudo-novel domains using optimal transport, and maximize the divergence. To ensure that semantics are preserved in the synthesized data, we further impose cycle-consistency and classification losses on the generator. Our method, L2A-OT (Learning to Augment by Optimal Transport) outperforms current state-of-the-art DG methods on four benchmark datasets.

摘要。本文聚焦于领域泛化(Domain Generalization，DG)，即从多个源领域学习一个能很好地泛化到未见领域的模型的任务。DG的一个主要挑战是，可用的源领域通常表现出有限的多样性，这阻碍了模型学习泛化的能力。因此，我们采用一个数据生成器从伪新领域合成数据来扩充源领域。这明确增加了可用训练领域的多样性，并得到一个更具泛化能力的模型。为了训练生成器，我们使用最优传输来建模源领域和合成的伪新领域之间的分布差异，并最大化这种差异。为了确保合成数据中语义的保留，我们进一步对生成器施加循环一致性和分类损失。我们的方法L2A - OT(通过最优传输进行扩充学习，Learning to Augment by Optimal Transport)在四个基准数据集上优于当前最先进的DG方法。

## 1 Introduction

## 1 引言

Humans effortlessly generalize prior knowledge to novel scenarios, a capability that machines still struggle to reproduce. Typically, machine-learning models perform poorly when deployed on test data with a different data distribution than the training data, which is known as the domain shift problem [35]. One line of research towards alleviating the domain shift problem is unsupervised domain adaptation (UDA), which exploits unlabeled target domain data for model adaptation $\left\lbrack  {{12},{20},{33},{40},{44},{53}}\right\rbrack$ . Although UDA methods avoid costly data annotation processes from target domains, data collection and per-domain model updates are still required. Meanwhile, UDA's assumption that target data can be collected in advance is not always met in practice $\left\lbrack  {{10},{37}}\right\rbrack$ . This motivates another line of research, namely domain generalization (DG) $\left\lbrack  {2,5,{10},{15},{16},{37}}\right\rbrack$ , which is the main focus in this paper.

人类可以轻松地将先验知识泛化到新场景，而机器仍然难以实现这一能力。通常，当机器学习模型部署在与训练数据具有不同数据分布的测试数据上时，其性能较差，这就是所谓的领域偏移问题 [35]。缓解领域偏移问题的一条研究路线是无监督领域自适应(Unsupervised Domain Adaptation，UDA)，它利用未标记的目标领域数据进行模型自适应 $\left\lbrack  {{12},{20},{33},{40},{44},{53}}\right\rbrack$。尽管UDA方法避免了从目标领域进行昂贵的数据标注过程，但仍然需要进行数据收集和按领域进行模型更新。同时，UDA假设可以提前收集目标数据，这在实践中并不总是成立 $\left\lbrack  {{10},{37}}\right\rbrack$。这推动了另一条研究路线，即领域泛化(Domain Generalization，DG) $\left\lbrack  {2,5,{10},{15},{16},{37}}\right\rbrack$，这也是本文的主要研究重点。

---

Electronic supplementary material The online version of this chapter (https:// doi.org/10.1007/978-3-030-58517-4-33) contains supplementary material, which is available to authorized users.

电子补充材料 本章的在线版本(https:// doi.org/10.1007/978 - 3 - 030 - 58517 - 4 - 33)包含补充材料，授权用户可以获取。

---

![0195d2af-b9ca-7804-8a22-d612eeb794e6_1_244_176_992_638_0.jpg](images/0195d2af-b9ca-7804-8a22-d612eeb794e6_1_244_176_992_638_0.jpg)

Fig. 1. Motivation of our approach. We improve generalization by increasing the diversity of training domains by learning a generator network $G$ to map images of a source distribution, e.g., ${\mathbb{P}}_{\text{MNIST }}$ , to a novel distribution, i.e. $G\left( {\mathbb{P}}_{\text{MNIST }}\right)$ . We then combine both source and novel domains for model learning.

图1. 我们方法的动机。我们通过学习一个生成器网络 $G$ 将源分布的图像(例如 ${\mathbb{P}}_{\text{MNIST }}$)映射到一个新分布(即 $G\left( {\mathbb{P}}_{\text{MNIST }}\right)$)来增加训练领域的多样性，从而提高泛化能力。然后，我们将源领域和新领域结合起来进行模型学习。

DG methods aim to learn models capable of good direct generalization to unseen target domains without data collection or model updating [37]. They usually, but not always [52], leverage multiple source domains to train a generalizable model. Most existing DG methods focus on aligning available source domains $\left\lbrack  {{11},{15},{16},{28},{29},{36}}\right\rbrack$ , which is mainly inspired by UDA methods that seek to minimize the divergence between source data and unlabeled target data $\left\lbrack  {{13},{50}}\right\rbrack$ . As proved in $\left\lbrack  4\right\rbrack$ , minimizing the domain divergence can lead to a smaller target error in the UDA setting. However, since DG methods focus on aligning source domains and do not have access to the target data, this theoretical proof does not apply to the DG setting. Recently, meta-learning has been exploited for DG where the key idea is to simulate domain shift by splitting the training data into meta-train and meta-test sets with non-overlapping domains $\left\lbrack  {2,{10},{26},{27},{31}}\right\rbrack$ . During learning, models are optimized on the meta-train domains in a way that the error is reduced on the meta-test domains. Nevertheless, similar to the alignment-based methods, meta-learning optimizes for reducing the domain gap among source domains, and thus still has the risk of overfitting to seen domains.

DG方法旨在学习能够在不进行数据收集或模型更新的情况下直接很好地泛化到未见目标领域的模型 [37]。它们通常(但并非总是 [52])利用多个源领域来训练一个具有泛化能力的模型。大多数现有的DG方法专注于对齐可用的源领域 $\left\lbrack  {{11},{15},{16},{28},{29},{36}}\right\rbrack$，这主要受到UDA方法的启发，UDA方法试图最小化源数据和未标记目标数据之间的差异 $\left\lbrack  {{13},{50}}\right\rbrack$。正如 $\left\lbrack  4\right\rbrack$ 中所证明的，在UDA设置中，最小化领域差异可以导致更小的目标误差。然而，由于DG方法专注于对齐源领域且无法获取目标数据，这个理论证明不适用于DG设置。最近，元学习已被用于DG，其关键思想是通过将训练数据划分为具有不重叠领域的元训练集和元测试集来模拟领域偏移 $\left\lbrack  {2,{10},{26},{27},{31}}\right\rbrack$。在学习过程中，模型在元训练领域上进行优化，以减少在元测试领域上的误差。然而，与基于对齐的方法类似，元学习优化是为了减少源领域之间的领域差距，因此仍然存在过拟合到已见领域的风险。

In this paper, we address DG from a different perspective, i.e., the most straightforward way to improve model generalization is increasing the diversity of available source domains [49] (see Fig. 1). To this end, we propose L2A- ${OT}$ (Learning to Augment by Optimal Transport). The core idea is to learn a conditional generator network that maps source domain images to pseudo-novel domains, and then combine both source and pseudo-novel domain images for training the actual task model. To train the generator, we maximize the distance between source domains and the generated pseudo-novel domains, as measured by optimal transport (OT) [41]. This leads to the generated images having a very different distribution from the source domains (Fig. 1). However, this objective alone does not guarantee that the semantic content of the generated images is preserved. Therefore, we further impose two losses on the generator, namely a cycle-consistency loss [64] and a classification loss, for maintaining the structural and semantic consistency respectively.

在本文中，我们从不同的视角来探讨领域泛化(Domain Generalization，DG)问题，即提高模型泛化能力最直接的方法是增加可用源领域的多样性 [49](见图 1)。为此，我们提出了 L2A - ${OT}$(基于最优传输的学习增强方法，Learning to Augment by Optimal Transport)。其核心思想是学习一个条件生成器网络，该网络将源领域图像映射到伪新颖领域，然后结合源领域和伪新颖领域的图像来训练实际任务模型。为了训练生成器，我们最大化源领域和生成的伪新颖领域之间的距离，该距离通过最优传输(Optimal Transport，OT)[41] 来度量。这使得生成的图像与源领域具有非常不同的分布(图 1)。然而，仅这一目标并不能保证生成图像的语义内容得以保留。因此，我们进一步对生成器施加两种损失，即循环一致性损失 [64] 和分类损失，分别用于保持结构和语义的一致性。

Our contributions are as follows. (1) For the first time, DG is tackled from a perspective of pseudo-novel domain synthesis. (2) A novel image generator is formulated which differs from existing generators in the objective (synthesizing pseudo-novel domain images vs. natural photo images). More importantly it has a unique OT-based formulation of objective functions that allow the generator to explore novel domain space and generate diverse data with distributions different from any of the original source domains. We evaluate L2A-OT on three homogeneous DG benchmark datasets ${}^{1}$ including digit recognition $\left\lbrack  {{12},{24},{38}}\right\rbrack$ , PACS [25] and Office-Home [51] and a heterogeneous DG task in the form of cross-domain person re-identification (re-ID) [22,32,58,59,61]. The results show that L2A-OT surpasses the current state-of-the-art on all datasets.

我们的贡献如下。(1)首次从伪新颖领域合成的视角来解决领域泛化问题。(2)提出了一种新颖的图像生成器，其目标与现有生成器不同(合成伪新颖领域图像与自然照片图像)。更重要的是，它具有独特的基于最优传输的目标函数公式，这使得生成器能够探索新颖的领域空间，并生成与任何原始源领域分布都不同的多样化数据。我们在三个同质领域泛化基准数据集 ${}^{1}$ 上评估了 L2A - OT，包括数字识别 $\left\lbrack  {{12},{24},{38}}\right\rbrack$、PACS [25] 和 Office - Home [51]，以及一个以跨领域行人重识别(re - ID)形式呈现的异质领域泛化任务 [22,32,58,59,61]。结果表明，L2A - OT 在所有数据集上都超越了当前的最优方法。

## 2 Related Work

## 2 相关工作

Domain Generalization. Many DG methods are based on the idea of domain alignment popularized from the UDA literature [12], with a goal to learn a domain-invariant representation by minimizing the domain discrepancy between sources $\left\lbrack  {{11},{15},{16},{28},{29},{36}}\right\rbrack$ . As mentioned earlier, aligning domain distributions is mainly motivated by the theory [4] developed for UDA, which does not apply to DG due to the absence of target data. Therefore, the models learned with domain alignment risk overfitting to source domains and as a result generalize poorly to unseen domains. In recent years, meta-learning [21] has seen increasing interest for DG where the objective is to expose a model to domain shift during training. This can be achieved by dividing source domains into meta-train and meta-test sets without overlapping, and training a model on the meta-train set such that the error on the meta-test set is reduced $\left\lbrack  {2,{10},{26}}\right\rbrack$ . Similar to domain alignment methods, meta-learning methods still risk overfitting since the training data remains unchanged. Moreover, these methods work at feature-level, which is difficult for diagnosis and lacks visual interpretation.

领域泛化。许多领域泛化方法基于无监督域适应(Unsupervised Domain Adaptation，UDA)文献中普及的领域对齐思想 [12]，其目标是通过最小化源领域 $\left\lbrack  {{11},{15},{16},{28},{29},{36}}\right\rbrack$ 之间的领域差异来学习一种领域不变的表示。如前所述，对齐领域分布主要是受为无监督域适应发展的理论 [4] 所驱动，由于缺乏目标数据，该理论不适用于领域泛化。因此，使用领域对齐学习的模型存在过拟合源领域的风险，结果是对未见领域的泛化能力较差。近年来，元学习 [21] 在领域泛化方面受到了越来越多的关注，其目标是在训练过程中让模型经历领域偏移。这可以通过将源领域划分为不重叠的元训练集和元测试集，并在元训练集上训练模型，从而降低元测试集上的误差 $\left\lbrack  {2,{10},{26}}\right\rbrack$ 来实现。与领域对齐方法类似，元学习方法仍然存在过拟合的风险，因为训练数据保持不变。此外，这些方法在特征层面上工作，难以进行诊断且缺乏可视化解释。

Most related to our work are data augmentation methods, especially those based on adversarial gradients $\left\lbrack  {{47},{52}}\right\rbrack$ . For instance,[47] proposed CrossGrad to perturb input images with adversarial gradients generated by a domain classifier. Different from adversarial gradient-based methods which only produce imperceptible and simple pixel-wise effects (due to the nature of adversarial attack [48]), our approach learns a full CNN generator to map source images to unseen domains and optimizes it via ${OT}$ -based distribution divergence to make the new domains as dissimilar as possible to source distributions.

与我们的工作最相关的是数据增强方法，尤其是那些基于对抗梯度 $\left\lbrack  {{47},{52}}\right\rbrack$ 的方法。例如，[47] 提出了 CrossGrad，用于用领域分类器生成的对抗梯度扰动输入图像。与仅产生难以察觉的简单像素级效果的基于对抗梯度的方法(由于对抗攻击的性质 [48])不同，我们的方法学习一个完整的卷积神经网络(Convolutional Neural Network，CNN)生成器，将源图像映射到未见领域，并通过基于 ${OT}$ 的分布散度对其进行优化，以使新领域与源分布尽可能不同。

---

${}^{1}$ Following [31], homogeneous DG shares the same label space between training and test data while heterogeneous DG has disjoint label space.

${}^{1}$ 遵循 [31] 的定义，同质领域泛化在训练数据和测试数据之间共享相同的标签空间，而异质领域泛化的标签空间是不相交的。

---

![0195d2af-b9ca-7804-8a22-d612eeb794e6_3_130_175_1218_335_0.jpg](images/0195d2af-b9ca-7804-8a22-d612eeb794e6_3_130_175_1218_335_0.jpg)

Fig. 2. Overview of our approach. (a) The conditional generator network $G$ is learned to map input $X$ to novel domains whose distributions are drastically different from the source domains, while keeping the distance between the novel domains as far as possible.

图 2. 我们方法的概述。(a)学习条件生成器网络 $G$，将输入 $X$ 映射到新颖领域，这些新颖领域的分布与源领域有很大不同，同时使新颖领域之间的距离尽可能远。

(b) A cycle-consistency loss is imposed on $G$ to maintain the structural consistency.

(b) 对 $G$ 施加循环一致性损失，以保持结构一致性。

(c) The cross-entropy loss is minimized with respect to $G$ , using a pre-trained classifier

(c) 使用预训练的分类器 $G$ 最小化关于 $G$ 的交叉熵损失，以保持语义一致性。

$\widehat{Y}$ , for maintaining the semantic consistency.

$\widehat{Y}$ 用于保持语义一致性。

Domain Randomization. Our approach shares a similar high-level intuition with domain randomization (DR) [49], which was originally introduced in the context of robotic learning to improve generalization from simulation to real world. DR aims to diversify the training domains by changing the color and texture of objects, background scenes, lighting conditions, etc. via a computer simulator [49]. Recently, DR has been successfully used in some computer vision applications, such as semantic segmentation $\left\lbrack  {{54},{55}}\right\rbrack$ and vehicle detection for autonomous driving [42]. However, our approach is significantly different from the DR-based methods because we learn a CNN generator network from real images rather than using programmatic simulators. Thus our method is more scalable to a wider range of image recognition tasks.

领域随机化。我们的方法与领域随机化(Domain Randomization，DR)[49]有着相似的高层直觉，领域随机化最初是在机器人学习的背景下提出的，旨在提高从模拟环境到现实世界的泛化能力。DR 旨在通过计算机模拟器改变物体的颜色和纹理、背景场景、光照条件等，使训练领域多样化[49]。最近，DR 已成功应用于一些计算机视觉应用中，如语义分割$\left\lbrack  {{54},{55}}\right\rbrack$和自动驾驶中的车辆检测[42]。然而，我们的方法与基于 DR 的方法有显著不同，因为我们是从真实图像中学习卷积神经网络(CNN)生成器网络，而不是使用程序化模拟器。因此，我们的方法更适用于更广泛的图像识别任务。

Image-to-Image Translation. Our work is also related to multi-domain image-to-image translation methods such as CycleGAN [64] and StarGAN [6], which use GAN losses [17] to generate realistic images and cycle-consistency losses [64] to achieve translation without using paired training images. Our method is fundamentally different from CycleGAN/StarGAN in that our generator model is learned to map source images to unseen domains rather than performing mapping between source domains as did in CycleGAN/StarGAN. We show by experiments that simply doing source-to-source mapping for data augmentation offers little help to DG (see Fig. 5a).

图像到图像的翻译。我们的工作还与多领域图像到图像的翻译方法相关，如 CycleGAN [64]和 StarGAN [6]，这些方法使用生成对抗网络(GAN)损失[17]来生成逼真的图像，并使用循环一致性损失[64]在不使用配对训练图像的情况下实现翻译。我们的方法与 CycleGAN/StarGAN 有根本的不同，因为我们的生成器模型是学习将源图像映射到未见领域，而不是像 CycleGAN/StarGAN 那样在源领域之间进行映射。我们通过实验表明，简单地进行源到源的映射来进行数据增强对领域泛化(DG)帮助不大(见图 5a)。

## 3 Methodology

## 3 方法

### 3.1 Generating Novel-Domain Data

### 3.1 生成新领域数据

Setup. We are provided with ${K}_{s}$ source domains with indices ${D}_{s} = \left\{  {1,2,\ldots ,{K}_{s}}\right\}$ . The goal is to learn a model which can generalize well on an unseen target domain. Without having access to the target data, we propose to improve the model’s generalization by synthesizing novel data domains ${D}_{n} = \left\{  {1,2,\ldots ,{K}_{n}}\right\}$ to augment the original source domains.

设置。我们有${K}_{s}$个源领域，其索引为${D}_{s} = \left\{  {1,2,\ldots ,{K}_{s}}\right\}$。目标是学习一个能够在未见的目标领域上有良好泛化能力的模型。在无法获取目标数据的情况下，我们建议通过合成新的数据领域${D}_{n} = \left\{  {1,2,\ldots ,{K}_{n}}\right\}$来增强原始源领域，从而提高模型的泛化能力。

Conditional Generator. We learn a conditional generator $G$ (see Sect. 3.4 for detailed architecture design), that maps a source distribution ${\mathbb{P}}_{k}$ with $k \in  {D}_{s}$ to a novel distribution ${\mathbb{P}}_{\widetilde{k}}$ with $\widetilde{k} \in  {D}_{n}$ by conditioning on the novel domain label $\widetilde{k}$ , i.e. ${\mathbb{P}}_{\widetilde{k}} = G\left( {{\mathbb{P}}_{k},\widetilde{k}}\right)$ . Here $\mathbb{P}$ denotes an empirical distribution rather than the real distribution, which is inaccessible. In practice, we use sampled mini-batches ${X}_{k}$ instead of the full empirical distribution ${\mathbb{P}}_{k}$ . Therefore, the domain translation function is defined as:

条件生成器。我们学习一个条件生成器$G$(详细的架构设计见 3.4 节)，它通过以新领域标签$\widetilde{k}$为条件，将具有$k \in  {D}_{s}$的源分布${\mathbb{P}}_{k}$映射到具有$\widetilde{k} \in  {D}_{n}$的新分布${\mathbb{P}}_{\widetilde{k}}$，即${\mathbb{P}}_{\widetilde{k}} = G\left( {{\mathbb{P}}_{k},\widetilde{k}}\right)$。这里$\mathbb{P}$表示经验分布，而不是无法获取的真实分布。在实践中，我们使用采样的小批量${X}_{k}$代替完整的经验分布${\mathbb{P}}_{k}$。因此，领域翻译函数定义为:

$$
{X}_{\widetilde{k}} = G\left( {{X}_{k},\widetilde{k}}\right) . \tag{1}
$$

Objective Functions. For each training iteration, we randomly sample for each source domain $k$ a mini-batch ${X}_{k}$ , which is transformed to a randomly selected novel domain $\widetilde{k} \sim  {D}_{n}$ . The objective is to force the novel distribution to be as dissimilar as possible to any source distribution, thus creating new domains to augment the existing source domains. We have

目标函数。对于每次训练迭代，我们为每个源领域$k$随机采样一个小批量${X}_{k}$，并将其转换为随机选择的新领域$\widetilde{k} \sim  {D}_{n}$。目标是使新分布尽可能与任何源分布不同，从而创建新的领域来增强现有的源领域。我们有

$$
\mathop{\max }\limits_{G}{L}_{\text{Novel }} = d\left( {G\left( {{X}_{k},\widetilde{k}}\right) ,{X}_{k}}\right) , \tag{2}
$$

where $d\left( {\cdot , \cdot  }\right)$ is a distribution divergence measure (its design will be detailed in Sect. 3.5). Note that Eq. (2) will be summed over all source domains $k$ , and each independently draws a novel domain label $\widetilde{k}$ .

其中$d\left( {\cdot , \cdot  }\right)$是一个分布差异度量(其设计将在 3.5 节详细介绍)。请注意，方程(2)将对所有源领域$k$求和，并且每个源领域独立地抽取一个新领域标签$\widetilde{k}$。

In addition to maximizing the difference between source and novel distributions, we also maximize the difference between the generated novel distributions, i.e.

除了最大化源分布和新分布之间的差异外，我们还最大化生成的新分布之间的差异，即

$$
\mathop{\max }\limits_{G}{L}_{\text{Diversity }} = d\left( {{X}_{{\widetilde{k}}_{1}},{X}_{{\widetilde{k}}_{2}}}\right) , \tag{3}
$$

where ${\widetilde{k}}_{1},{\widetilde{k}}_{2} \in  {D}_{n}$ and ${\widetilde{k}}_{1} \neq  {\widetilde{k}}_{2}$ . Equation (3) is summed over all possible pairs of novel distributions generated in one iteration. This diversity constraint diversifies the generated distributions, ensuring that the model benefits from generating ${K}_{n} > 1$ novel distributions. It is analogous to the diversity term in some image generation tasks, such as style transfer [30] where the pixel/feature difference between style-transferred instances is maximized. Differently, our formulation focuses on the divergence between data distributions. See Fig. 2a for a graphical illustration.

其中${\widetilde{k}}_{1},{\widetilde{k}}_{2} \in  {D}_{n}$和${\widetilde{k}}_{1} \neq  {\widetilde{k}}_{2}$。方程(3)对一次迭代中生成的所有可能的新分布对求和。这种多样性约束使生成的分布多样化，确保模型从生成${K}_{n} > 1$个新分布中受益。这类似于一些图像生成任务中的多样性项，如风格迁移[30]，其中最大化风格迁移实例之间的像素/特征差异。不同的是，我们的公式侧重于数据分布之间的差异。见图 2a 的图形说明。

### 3.2 Maintaining Semantic Consistency

### 3.2 保持语义一致性

The model so far is optimizing a powerful CNN generator $G$ for the novelty of the generated distribution (Eq. (2) and (3)). This produces diverse images, but may not preserve their semantic content.

到目前为止，该模型正在为生成分布的新颖性优化一个强大的卷积神经网络生成器 $G$(公式 (2) 和 (3))。这会生成多样化的图像，但可能无法保留其语义内容。

Cycle-Consistency Loss. First, to guarantee structural consistency, we apply a cycle-consistency constraint [64] to the generator,

循环一致性损失。首先，为了保证结构一致性，我们对生成器应用循环一致性约束 [64]，

$$
\mathop{\min }\limits_{G}{L}_{\text{Cycle }} = {\begin{Vmatrix}G\left( G\left( {X}_{k},\widetilde{k}\right) , k\right)  - {X}_{k}\end{Vmatrix}}_{1}, \tag{4}
$$

where the outer $G$ aims to reconstruct the original ${X}_{k}$ given as input the domain-translated $G\left( {{X}_{k},\widetilde{k}}\right)$ and the original domain label $k$ . Both $G$ ’s in the cycle share the same parameters [6]. This is illustrated in Fig. 2b.

其中外部的 $G$ 旨在根据输入的域转换后的 $G\left( {{X}_{k},\widetilde{k}}\right)$ 和原始域标签 $k$ 重构原始的 ${X}_{k}$。循环中的两个 $G$ 共享相同的参数 [6]。这在图 2b 中进行了说明。

Cross-Entropy Loss. Second, to maintain the category label and thus enforce semantic consistency, we further require that the generated data ${X}_{\widetilde{k}}$ is classified into the same category as the original data ${X}_{k}$ , i.e.

交叉熵损失。其次，为了保持类别标签从而强制实现语义一致性，我们进一步要求生成的数据 ${X}_{\widetilde{k}}$ 与原始数据 ${X}_{k}$ 被分类到同一类别中，即

$$
\mathop{\min }\limits_{G}{L}_{\mathrm{{CE}}}\left( {\widehat{Y}\left( {X}_{\widetilde{k}}\right) ,{Y}^{ * }\left( {X}_{k}\right) }\right) , \tag{5}
$$

where ${L}_{\mathrm{{CE}}}$ denotes cross-entropy loss, $\widehat{Y}\left( {X}_{\widetilde{k}}\right)$ the labels of ${X}_{\widetilde{k}}$ predicted by a pretrained classifier and ${Y}^{ * }\left( {X}_{k}\right)$ the ground-truth labels of ${X}_{k}$ . This is illustrated in Fig. 2c.

其中 ${L}_{\mathrm{{CE}}}$ 表示交叉熵损失，$\widehat{Y}\left( {X}_{\widetilde{k}}\right)$ 是预训练分类器对 ${X}_{\widetilde{k}}$ 预测的标签，${Y}^{ * }\left( {X}_{k}\right)$ 是 ${X}_{k}$ 的真实标签。这在图 2c 中进行了说明。

### 3.3 Training

### 3.3 训练

Generator Training. The full objective for $G$ is the weighted combination of Eq. (2), (3), (4) and (5),

生成器训练。$G$ 的完整目标是公式 (2)、(3)、(4) 和 (5) 的加权组合，

$$
\mathop{\min }\limits_{G}{L}_{G} =  - {\lambda }_{\text{Domain }}\left( {{L}_{\text{Novel }} + {L}_{\text{Diversity }}}\right)  \tag{6}
$$

$$
+ {\lambda }_{\text{Cycle }}{L}_{\text{Cycle }} + {\lambda }_{\mathrm{{CE}}}{L}_{\mathrm{{CE}}}\text{,}
$$

where ${\lambda }_{\text{Domain }},{\lambda }_{\text{Cycle }}$ and ${\lambda }_{\mathrm{{CE}}}$ are weighting hyper-parameters.

其中 ${\lambda }_{\text{Domain }},{\lambda }_{\text{Cycle }}$ 和 ${\lambda }_{\mathrm{{CE}}}$ 是加权超参数。

Task Model Training. The task model $F$ is trained from scratch using both the original data ${X}_{k}$ and the synthetic data ${X}_{\widetilde{k}}$ generated as described above. The objective for $F$ is

任务模型训练。任务模型 $F$ 使用原始数据 ${X}_{k}$ 和上述生成的合成数据 ${X}_{\widetilde{k}}$ 从头开始训练。$F$ 的目标是

$$
\mathop{\min }\limits_{F}{L}_{F} = \left( {1 - \alpha }\right) {L}_{\mathrm{{CE}}} + \alpha {\widetilde{L}}_{\mathrm{{CE}}}, \tag{7}
$$

where $\alpha$ is a balancing weight, which is fixed to 0.5 throughout this paper; ${L}_{\mathrm{{CE}}}$ and ${\widetilde{L}}_{\mathrm{{CE}}}$ are the cross-entropy losses computed using ${X}_{k}$ and ${X}_{\widetilde{k}}$ respectively. The full training algorithm is shown in Alg. 1 (In the Supp.). Note that each source domain $k \in  {D}_{s}$ will be assigned a unique novel domain $\widetilde{k} \in  {D}_{n}$ as target in each iteration. We set ${K}_{n} = {K}_{s}$ as default.

其中 $\alpha$ 是一个平衡权重，在本文中固定为 0.5；${L}_{\mathrm{{CE}}}$ 和 ${\widetilde{L}}_{\mathrm{{CE}}}$ 分别是使用 ${X}_{k}$ 和 ${X}_{\widetilde{k}}$ 计算的交叉熵损失。完整的训练算法如算法 1 所示(见补充材料)。请注意，在每次迭代中，每个源域 $k \in  {D}_{s}$ 将被分配一个唯一的新域 $\widetilde{k} \in  {D}_{n}$ 作为目标。我们默认设置 ${K}_{n} = {K}_{s}$。

### 3.4 Design of Conditional Generator Network

### 3.4 条件生成器网络的设计

Our generator model has a conv-deconv structure [6,64] which is shown in Fig. 3. Specifically, the generator model consists of two down-sampling convolution layers with stride 2, two residual blocks [19] and two transposed convolution layers with stride 2 for up-sampling. Following StarGAN [6], the domain indicator is encoded as a one-hot vector with length ${K}_{s} + {K}_{n}$ (see Fig. 3). During the forward pass, the one-hot vector is first spatially expanded and then concatenated with the image to form the input to $G$ .

我们的生成器模型具有卷积 - 反卷积结构 [6,64]，如图 3 所示。具体来说，生成器模型由两个步长为 2 的下采样卷积层、两个残差块 [19] 和两个步长为 2 的用于上采样的转置卷积层组成。遵循 StarGAN [6]，域指示符被编码为长度为 ${K}_{s} + {K}_{n}$ 的独热向量(见图 3)。在前向传播过程中，独热向量首先在空间上进行扩展，然后与图像连接起来形成 $G$ 的输入。

![0195d2af-b9ca-7804-8a22-d612eeb794e6_6_183_178_1214_304_0.jpg](images/0195d2af-b9ca-7804-8a22-d612eeb794e6_6_183_178_1214_304_0.jpg)

Fig. 3. Architecture of the conditional generator network. Left and right images exemplify the forward cycle and backward cycle respectively in cycle-consistency.

图 3. 条件生成器网络的架构。左右图像分别举例说明了循环一致性中的前向循环和后向循环。

Discussion. Though the design of $G$ is similar to the StarGAN model, their learning objectives are totally different: We aim to generate images that are different from the existing source domain distributions while the StarGAN model is trained to generate images from the existing source domains. In the experiment part we justify that adding novel-domain data is much more effective than adding seen-domain data for DG (see Fig. 5a). Compared with the gradient-based perturbation method in [47], our generator is allowed to model more sophisticated domain shift such as image style changes due to its learnable nature.

讨论。尽管 $G$ 的设计与 StarGAN 模型相似，但它们的学习目标完全不同:我们的目标是生成与现有源域分布不同的图像，而 StarGAN 模型是为了从现有源域生成图像而训练的。在实验部分，我们证明了对于领域泛化(DG)，添加新域数据比添加已见域数据更有效(见图 5a)。与 [47] 中基于梯度的扰动方法相比，由于我们的生成器具有可学习的特性，它能够对更复杂的域偏移(如图像风格变化)进行建模。

### 3.5 Design of Distribution Divergence Measure

### 3.5 分布差异度量的设计

Two common families for estimating the divergence between probability distributions are f-divergence (e.g., KL divergence) and integral probability metrics (e.g., Wasserstein distance). In contrast to most work that minimizes the divergence, we need to maximize it, as shown in Eq. (2) and (3). This strongly suggests to avoid f-divergence because of the near-zero denominators (they tend to generate large but numerically unstable divergence values). Therefore, we choose the second type, specifically the Wasserstein distance, which has been widely used in recent generative modeling methods $\left\lbrack  {1,3,{14},{45},{46}}\right\rbrack$ .

用于估计概率分布之间差异的两种常见类型是f-散度(例如，KL散度)和积分概率度量(例如，Wasserstein距离)。与大多数最小化差异的工作不同，我们需要最大化它，如公式(2)和(3)所示。这强烈表明要避免使用f-散度，因为其分母接近零(它们往往会产生较大但数值不稳定的差异值)。因此，我们选择第二种类型，具体来说是Wasserstein距离，它在最近的生成式建模方法中得到了广泛应用$\left\lbrack  {1,3,{14},{45},{46}}\right\rbrack$。

The Wasserstein distance, also known as optimal transport (OT) distance, is defined as

Wasserstein距离，也称为最优传输(OT)距离，定义为

$$
{\mathcal{W}}_{c}\left( {{\mathbb{P}}_{a},{\mathbb{P}}_{b}}\right)  = \mathop{\inf }\limits_{{\pi  \in  \Pi \left( {{\mathbb{P}}_{a},{\mathbb{P}}_{b}}\right) }}{\mathbb{E}}_{{x}_{a},{x}_{b} \sim  \pi }\left\lbrack  {c\left( {{x}_{a},{x}_{b}}\right) }\right\rbrack  , \tag{8}
$$

where $\Pi \left( {{\mathbb{P}}_{a},{\mathbb{P}}_{b}}\right)$ denotes the set of all joint distributions $\pi \left( {{x}_{a},{x}_{b}}\right)$ and $c\left( {\cdot , \cdot  }\right)$ the transport cost function. Intuitively, the OT metric computes the minimum cost of transporting masses between distributions in order to turn ${\mathbb{P}}_{b}$ into ${\mathbb{P}}_{a}$ .

其中$\Pi \left( {{\mathbb{P}}_{a},{\mathbb{P}}_{b}}\right)$表示所有联合分布的集合$\pi \left( {{x}_{a},{x}_{b}}\right)$，$c\left( {\cdot , \cdot  }\right)$表示传输成本函数。直观地说，OT度量计算了在分布之间转移质量以使${\mathbb{P}}_{b}$变为${\mathbb{P}}_{a}$的最小成本。

As the sampling over $\Pi \left( {{\mathbb{P}}_{a},{\mathbb{P}}_{b}}\right)$ is intractable, we resort to using the entropy-regularized Sinkhorn distance [7]. Moreover, to obtain unbiased gradient estimators when using mini-batches, we adopt the generalized (squared) energy distance [45], leading to

由于对$\Pi \left( {{\mathbb{P}}_{a},{\mathbb{P}}_{b}}\right)$进行采样是难以处理的，我们采用熵正则化的Sinkhorn距离[7]。此外，为了在使用小批量时获得无偏梯度估计器，我们采用广义(平方)能量距离[45]，得到

$$
d\left( {{\mathbb{P}}_{a},{\mathbb{P}}_{b}}\right)  = 2\mathbb{E}\left\lbrack  {{\mathcal{W}}_{c}\left( {{X}_{a},{X}_{b}}\right) }\right\rbrack   - \mathbb{E}\left\lbrack  {{\mathcal{W}}_{c}\left( {{X}_{a},{X}_{a}^{\prime }}\right) }\right\rbrack   - \mathbb{E}\left\lbrack  {{\mathcal{W}}_{c}\left( {{X}_{b},{X}_{b}^{\prime }}\right) }\right\rbrack  , \tag{9}
$$

where ${X}_{a}$ and ${X}_{a}^{\prime }$ are independent mini-batches from distribution ${\mathbb{P}}_{a};{X}_{b}$ and ${X}_{b}^{\prime }$ are independent mini-batches from distribution ${\mathbb{P}}_{b};{\mathcal{W}}_{c}$ is the Sinkhorn distance defined as

其中${X}_{a}$和${X}_{a}^{\prime }$是来自分布${\mathbb{P}}_{a};{X}_{b}$的独立小批量，${X}_{b}^{\prime }$是来自分布${\mathbb{P}}_{b};{\mathcal{W}}_{c}$的独立小批量，Sinkhorn距离定义为

$$
{\mathcal{W}}_{c}\left( {\cdot , \cdot  }\right)  = \mathop{\inf }\limits_{{M \in  \mathcal{M}}}\mathop{\sum }\limits_{{i, j}}{\left\lbrack  M \odot  C\right\rbrack  }_{i, j}, \tag{10}
$$

![0195d2af-b9ca-7804-8a22-d612eeb794e6_7_134_173_1214_272_0.jpg](images/0195d2af-b9ca-7804-8a22-d612eeb794e6_7_134_173_1214_272_0.jpg)

Fig. 4. Example images from different DG datasets.

图4. 不同领域泛化(DG)数据集的示例图像。

where the soft-matching matrix $M$ represents the coupling distribution $\pi$ in Eq. (8) and can be efficiently computed using the Sinkhorn algorithm [14]; $C$ is the pairwise distance matrix computed over two sets of samples.

其中软匹配矩阵$M$表示公式(8)中的耦合分布$\pi$，可以使用Sinkhorn算法[14]高效计算；$C$是在两组样本上计算的成对距离矩阵。

Following [45], we define the cost function as the cosine distance between instances,

遵循文献[45]，我们将成本函数定义为实例之间的余弦距离，

$$
c\left( {{x}_{a},{x}_{b}}\right)  = 1 - \frac{\phi {\left( {x}_{a}\right) }^{T}\phi \left( {x}_{b}\right) }{\parallel \phi \left( {x}_{a}\right) {\parallel }_{2}{\begin{Vmatrix}\phi \left( {x}_{b}\right) \end{Vmatrix}}_{2}}, \tag{11}
$$

where $\phi$ is constructed by a CNN (also called critic in [45]), which maps images into a latent space. In practice, $\phi$ is a fixed CNN that was trained with domain classification loss.

其中$\phi$由一个卷积神经网络(CNN，在文献[45]中也称为判别器)构建，它将图像映射到一个潜在空间。在实践中，$\phi$是一个使用领域分类损失进行训练的固定CNN。

## 4 Experiments

## 4 实验

### 4.1 Evaluation on Homogeneous DG

### 4.1 同质领域泛化(DG)评估

Datasets. (1) We use four different digit datasets including MNIST [24], MNIST-M [12], SVHN [38] and SYN [12], which differ drastically in font style, stroke color and background. We call this new dataset Digits-DG hereafter. See Fig. 4a for example images. (2) PACS [25] is composed of four domains, which are Photo, Art Painting, Cartoon and Sketc.h, with 9,991 images of 7 classes in total. See Fig. 4b for example images. (3) Office-Home [51] contains around 15,500 images of 65 classes for object recognition in office and home environments. It has four domains, which are Artistic, Clipart, Product and Real World. See Fig. 4c for example images.

数据集。(1) 我们使用四个不同的数字数据集，包括MNIST [24]、MNIST - M [12]、SVHN [38]和SYN [12]，它们在字体样式、笔画颜色和背景方面有很大差异。我们此后将这个新数据集称为Digits - DG。示例图像见图4a。(2) PACS [25]由四个领域组成，分别是照片、艺术绘画、卡通和素描，总共包含7个类别的9991张图像。示例图像见图4b。(3) Office - Home [51]包含约15500张65个类别的图像，用于办公室和家庭环境中的目标识别。它有四个领域，分别是艺术、剪贴画、产品和现实世界。示例图像见图4c。

Evaluation Protocol. For fair comparison with prior work, we follow the leave-one-domain-out protocol in $\left\lbrack  {5,{25},{27}}\right\rbrack$ . Specifically, one domain is chosen as the test domain while the remaining domains are used as source domains for model training. The top-1 classification accuracy is used as performance measure. All results are averaged over three runs with different random seeds.

评估协议。为了与先前的工作进行公平比较，我们遵循文献$\left\lbrack  {5,{25},{27}}\right\rbrack$中的留一领域法协议。具体来说，选择一个领域作为测试领域，而其余领域用作模型训练的源领域。使用top - 1分类准确率作为性能指标。所有结果是在使用不同随机种子的三次运行中取平均值。

Table 1. Leave-one-domain-out results on Digits-DG.

表1. Digits - DG上的留一领域法结果。

<table><tr><td>Method</td><td>MNIST</td><td>MNIST-M</td><td>SVHN</td><td>SYN</td><td>Avg</td></tr><tr><td>Vanilla</td><td>95.8</td><td>58.8</td><td>61.7</td><td>78.6</td><td>73.7</td></tr><tr><td>CCSA [36]</td><td>95.2</td><td>58.2</td><td>65.5</td><td>79.1</td><td>74.5</td></tr><tr><td>MMD-AAE [28]</td><td>96.5</td><td>58.4</td><td>65.0</td><td>78.4</td><td>74.6</td></tr><tr><td>CrossGrad [47]</td><td>96.7</td><td>61.1</td><td>65.3</td><td>80.2</td><td>75.8</td></tr><tr><td>JiGen [5]</td><td>96.5</td><td>61.4</td><td>63.7</td><td>74.0</td><td>73.9</td></tr><tr><td>L2A-OT (ours)</td><td>96.7</td><td>63.9</td><td>68.6</td><td>83.2</td><td>78.1</td></tr></table>

<table><tbody><tr><td>方法</td><td>手写数字数据集(MNIST)</td><td>混合手写数字数据集(MNIST - M)</td><td>街景门牌号数据集(SVHN)</td><td>合成数据集(SYN)</td><td>平均值</td></tr><tr><td>普通的</td><td>95.8</td><td>58.8</td><td>61.7</td><td>78.6</td><td>73.7</td></tr><tr><td>联合分类与领域适应(CCSA) [36]</td><td>95.2</td><td>58.2</td><td>65.5</td><td>79.1</td><td>74.5</td></tr><tr><td>最大均值差异对抗自编码器(MMD - AAE) [28]</td><td>96.5</td><td>58.4</td><td>65.0</td><td>78.4</td><td>74.6</td></tr><tr><td>交叉梯度(CrossGrad) [47]</td><td>96.7</td><td>61.1</td><td>65.3</td><td>80.2</td><td>75.8</td></tr><tr><td>拼图生成(JiGen) [5]</td><td>96.5</td><td>61.4</td><td>63.7</td><td>74.0</td><td>73.9</td></tr><tr><td>标签到属性最优传输(L2A - OT)(我们的方法)</td><td>96.7</td><td>63.9</td><td>68.6</td><td>83.2</td><td>78.1</td></tr></tbody></table>

Baselines. We compare L2A-OT with the recent state-of-the-art DG methods that report results on the same dataset or have code publicly available for reproduction. These include (1) CrossGrad [47], the most related work that perturbs input using adversarial gradients from a domain classifier; (2) CCSA [36], which learns a domain-invariant representation using a contrastive semantic alignment loss; (3) MMD-AAE [28], which imposes a MMD loss on the hidden layers of an autoencoder. (4) JiGen [5], which has an auxiliary self-supervision loss to solve the Jigsaw puzzle task [39]; (5) Epi-FCR [27], which designs an episodic training strategy; (6) A vanilla model trained by aggregating all source domains, which serves as a strong baseline.

基线方法。我们将L2A - OT与近期最先进的领域泛化(DG)方法进行比较，这些方法在相同数据集上报告了结果，或者有公开可用的代码以供复现。这些方法包括:(1)CrossGrad [47]，这是最相关的工作，它使用来自领域分类器的对抗梯度来扰动输入；(2)CCSA [36]，该方法使用对比语义对齐损失来学习领域不变表示；(3)MMD - AAE [28]，它在自编码器的隐藏层上施加最大均值差异(MMD)损失；(4)JiGen [5]，它有一个辅助的自监督损失来解决拼图任务 [39]；(5)Epi - FCR [27]，它设计了一种情景式训练策略；(6)通过聚合所有源领域训练的普通模型，作为一个强大的基线。

Implementation Details. For Digits-DG, the CNN backbone is constructed with four 64-kernel $3 \times  3$ convolution layers and a softmax layer. ReLU and $2 \times  2$ max-pooling are inserted after each convolution layer. $F$ is trained with SGD, initial learning rate of 0.05 and batch size of 126 (42 images per source) for 50 epochs. The learning rate is decayed by 0.1 every 20 epochs. For all experiments, $G$ is trained with Adam [23] and a constant learning rate of 0.0003 . For both PACS and Office-Home, we use ResNet-18 [19] pretrained on ImageNet [8] as the CNN backbone, following $\left\lbrack  {5,9,{27}}\right\rbrack$ . On PACS, $F$ is trained with SGD, initial learning rate of 0.00065 and batch size of 24 (8 images per source) for 40 epochs. The learning rate is decayed by 0.1 after 30 epochs. On Office-Home, the optimization parameters are similar to those on PACS except that the maximum epoch is 25 and the learning rate decay step is 20 . For all datasets, as target data is unavailable during training, the values of hyper-parameters ${\lambda }_{\text{Domain }}$ , ${\lambda }_{\mathrm{{Cycle}}}$ and ${\lambda }_{\mathrm{{CE}}}$ are set based on the performance on source validation set, ${}^{2}$ which is a strategy commonly adopted in the DG literature $\left\lbrack  {5,{27}}\right\rbrack$ . Our implementation is based on Dassl.pytorch [63].

实现细节。对于Digits - DG，卷积神经网络(CNN)骨干网络由四个64核的$3 \times  3$卷积层和一个softmax层构成。在每个卷积层之后插入ReLU激活函数和$2 \times  2$最大池化层。$F$使用随机梯度下降(SGD)进行训练，初始学习率为0.05，批量大小为126(每个源42张图像)，训练50个轮次。学习率每20个轮次衰减0.1。对于所有实验，$G$使用Adam优化器 [23] 进行训练，学习率恒定为0.0003。对于PACS和Office - Home数据集，我们遵循$\left\lbrack  {5,9,{27}}\right\rbrack$，使用在ImageNet [8] 上预训练的ResNet - 18 [19] 作为CNN骨干网络。在PACS数据集上，$F$使用SGD进行训练，初始学习率为0.00065，批量大小为24(每个源8张图像)，训练40个轮次。学习率在30个轮次后衰减0.1。在Office - Home数据集上，优化参数与PACS数据集上的类似，除了最大轮次为25，学习率衰减步长为20。对于所有数据集，由于训练期间无法获取目标数据，超参数${\lambda }_{\text{Domain }}$、${\lambda }_{\mathrm{{Cycle}}}$和${\lambda }_{\mathrm{{CE}}}$的值是根据源验证集上的性能来设置的，${}^{2}$这是领域泛化文献中常用的一种策略 $\left\lbrack  {5,{27}}\right\rbrack$。我们的实现基于Dassl.pytorch [63]。

Results on Digits-DG. Table 1 shows that L2A-OT achieves the best performance on all domains and consistently outperforms the vanilla baseline by a large margin. Compared with CrossGrad, L2A-OT performs clearly better on MNIST-M, SVHN and SYN, with clear improvements of 2.8%, 3.3% and 3%, respectively. It is worth noting that these three domains are very challenging with large domain variations compared with their source domains (see Fig. 4a). The huge advantage over CrossGrad can be attributed to L2A-OT's unique generation of unseen-domain data using a fully learnable CNN generator, and using optimal transport to explicitly encourage domain divergence. Compared with the domain alignment methods, L2A-OT surpasses MMD-AAE and CCSA by more than ${3.5}\%$ on average. The is because L2A-OT enriches the domain diversity of training data, thus reducing overfitting in source domains. L2A-OT clearly beats JiGen because the Jigsaw puzzle transformation does not work well on digit images with sparse pixels [39].

Digits - DG数据集上的结果。表1显示，L2A - OT在所有领域都取得了最佳性能，并且始终大幅优于普通基线。与CrossGrad相比，L2A - OT在MNIST - M、SVHN和SYN上的表现明显更好，分别有2.8%、3.3%和3%的显著提升。值得注意的是，与它们的源领域相比，这三个领域具有很大的领域差异，极具挑战性(见图4a)。L2A - OT相对于CrossGrad的巨大优势可归因于其使用完全可学习的CNN生成器独特地生成未见领域数据，并使用最优传输来明确鼓励领域差异。与领域对齐方法相比，L2A - OT平均比MMD - AAE和CCSA高出${3.5}\%$。这是因为L2A - OT丰富了训练数据的领域多样性，从而减少了在源领域的过拟合。L2A - OT明显优于JiGen，因为拼图变换在像素稀疏的数字图像上效果不佳 [39]。

---

${}^{2}$ The searching space is: ${\lambda }_{\text{Domain }} \in  \{ {0.5},1,2\} ,{\lambda }_{\text{Cycle }} \in  \{ {10},{20}\}$ and ${\lambda }_{\mathrm{{CE}}} \in  \{ 1\}$ .

${}^{2}$搜索空间为:${\lambda }_{\text{Domain }} \in  \{ {0.5},1,2\} ,{\lambda }_{\text{Cycle }} \in  \{ {10},{20}\}$和${\lambda }_{\mathrm{{CE}}} \in  \{ 1\}$。

---

Table 2. Leave-one-domain-out results on PACS dataset.

表2. PACS数据集上留一领域法的结果。

<table><tr><td>Method</td><td>Art</td><td>Cartoon</td><td>Photo</td><td>Sketc.h</td><td>Avg</td></tr><tr><td>Vanilla</td><td>77.0</td><td>75.9</td><td>96.0</td><td>69.2</td><td>79.5</td></tr><tr><td>CCSA [36]</td><td>80.5</td><td>76.9</td><td>93.6</td><td>66.8</td><td>79.4</td></tr><tr><td>MMD-AAE [28]</td><td>75.2</td><td>72.7</td><td>96.0</td><td>64.2</td><td>77.0</td></tr><tr><td>CrossGrad [47]</td><td>79.8</td><td>76.8</td><td>96.0</td><td>70.2</td><td>80.7</td></tr><tr><td>JiGen [5]</td><td>79.4</td><td>75.3</td><td>96.0</td><td>71.6</td><td>80.5</td></tr><tr><td>Epi-FCR [27]</td><td>82.1</td><td>77.0</td><td>93.9</td><td>73.0</td><td>81.5</td></tr><tr><td>L2A-OT (ours)</td><td>83.3</td><td>78.2</td><td>96.2</td><td>73.6</td><td>82.8</td></tr></table>

<table><tbody><tr><td>方法</td><td>艺术</td><td>卡通</td><td>照片</td><td>素描</td><td>平均值</td></tr><tr><td>普通版</td><td>77.0</td><td>75.9</td><td>96.0</td><td>69.2</td><td>79.5</td></tr><tr><td>一致性约束自训练算法(CCSA) [36]</td><td>80.5</td><td>76.9</td><td>93.6</td><td>66.8</td><td>79.4</td></tr><tr><td>最大均值差异对抗自编码器(MMD - AAE) [28]</td><td>75.2</td><td>72.7</td><td>96.0</td><td>64.2</td><td>77.0</td></tr><tr><td>交叉梯度(CrossGrad) [47]</td><td>79.8</td><td>76.8</td><td>96.0</td><td>70.2</td><td>80.7</td></tr><tr><td>拼图生成(JiGen) [5]</td><td>79.4</td><td>75.3</td><td>96.0</td><td>71.6</td><td>80.5</td></tr><tr><td>情景式特征对比正则化(Epi - FCR) [27]</td><td>82.1</td><td>77.0</td><td>93.9</td><td>73.0</td><td>81.5</td></tr><tr><td>标签到属性最优传输(L2A - OT)(我们的方法)</td><td>83.3</td><td>78.2</td><td>96.2</td><td>73.6</td><td>82.8</td></tr></tbody></table>

Table 3. Leave-one-domain-out results on Office-Home.

表3. Office-Home数据集上的留一领域法(Leave-one-domain-out)实验结果。

<table><tr><td>Method</td><td>Artistic</td><td>Clipart</td><td>Product</td><td>Real World</td><td>Avg</td></tr><tr><td>Vanilla</td><td>58.9</td><td>49.4</td><td>74.3</td><td>76.2</td><td>64.7</td></tr><tr><td>CCSA [36]</td><td>59.9</td><td>49.9</td><td>74.1</td><td>75.7</td><td>64.9</td></tr><tr><td>MMD-AAE [28]</td><td>56.5</td><td>47.3</td><td>72.1</td><td>74.8</td><td>62.7</td></tr><tr><td>CrossGrad [47]</td><td>58.4</td><td>49.4</td><td>73.9</td><td>75.8</td><td>64.4</td></tr><tr><td>JiGen [5]</td><td>53.0</td><td>47.5</td><td>71.5</td><td>72.8</td><td>61.2</td></tr><tr><td>L2A-OT (ours)</td><td>60.6</td><td>50.1</td><td>74.8</td><td>77.0</td><td>65.6</td></tr></table>

<table><tbody><tr><td>方法</td><td>艺术的</td><td>剪贴画</td><td>产品</td><td>现实世界</td><td>平均值</td></tr><tr><td>普通的</td><td>58.9</td><td>49.4</td><td>74.3</td><td>76.2</td><td>64.7</td></tr><tr><td>连续分类器自训练算法(CCSA) [36]</td><td>59.9</td><td>49.9</td><td>74.1</td><td>75.7</td><td>64.9</td></tr><tr><td>最大均值差异对抗自编码器(MMD - AAE) [28]</td><td>56.5</td><td>47.3</td><td>72.1</td><td>74.8</td><td>62.7</td></tr><tr><td>交叉梯度(CrossGrad) [47]</td><td>58.4</td><td>49.4</td><td>73.9</td><td>75.8</td><td>64.4</td></tr><tr><td>拼图生成(JiGen) [5]</td><td>53.0</td><td>47.5</td><td>71.5</td><td>72.8</td><td>61.2</td></tr><tr><td>从标签到属性的最优传输(L2A - OT)(我们的方法)</td><td>60.6</td><td>50.1</td><td>74.8</td><td>77.0</td><td>65.6</td></tr></tbody></table>

Results on PACS. The results are shown in Table 2. Overall, L2A-OT achieves the best performance on all test domains. L2A-OT clearly beats the latest DG methods, JiGen and Epi-FCR. This is because our classifier benefits from the generated unseen-domain data while JiGen and Epi-FCR, like the domain alignment methods, are prone to overfitting to the source domains. L2A-OT beats CrossGrad on all domains, mostly with a large margin. This again justifies our design of learnable CNN generator over adversarial gradient.

在PACS数据集上的结果。结果如表2所示。总体而言，L2A - OT在所有测试领域均取得了最佳性能。L2A - OT明显优于最新的领域泛化(DG)方法，即JiGen和Epi - FCR。这是因为我们的分类器受益于生成的未见领域数据，而JiGen和Epi - FCR与领域对齐方法一样，容易对源领域产生过拟合。L2A - OT在所有领域都击败了CrossGrad，且大多有较大优势。这再次证明了我们设计的可学习卷积神经网络(CNN)生成器优于对抗梯度方法的合理性。

Results on Office-Home. The results are reported in Table 3. Again, L2A-OT achieves the best overall performance, and other conclusions drawn previously also hold. Notably, the simple vanilla model obtains strong results on this benchmark, which are even better than most existing DG methods. This is because the dataset is relatively large, and the domain shift is less severe compared with the style changes on PACS and the font variations on Digits-DG.

在Office - Home数据集上的结果。结果报告于表3中。同样，L2A - OT取得了最佳的整体性能，之前得出的其他结论同样成立。值得注意的是，简单的原始模型在这个基准测试中取得了很强的结果，甚至比大多数现有的领域泛化(DG)方法还要好。这是因为该数据集相对较大，并且与PACS数据集上的风格变化和Digits - DG数据集上的字体变化相比，领域偏移不太严重。

Table 4. Results on cross-domain person re-ID benchmarks.

表4. 跨领域行人重识别(person re - ID)基准测试的结果。

<table><tr><td rowspan="2">Method</td><td colspan="4">Market ${1501} \rightarrow$ Duke</td><td colspan="4">Duke $\rightarrow$ Market 1501</td></tr><tr><td>mAP</td><td>R1</td><td>R5</td><td>R10</td><td>mAP</td><td>R1</td><td>R5</td><td>R10</td></tr><tr><td colspan="9">UDA methods</td></tr><tr><td>ATNet [32]</td><td>24.9</td><td>45.1</td><td>59.5</td><td>64.2</td><td>25.6</td><td>55.7</td><td>73.2</td><td>79.4</td></tr><tr><td>CamStyle [59]</td><td>25.1</td><td>48.4</td><td>62.5</td><td>68.9</td><td>27.4</td><td>58.8</td><td>78.2</td><td>84.3</td></tr><tr><td>HHL [58]</td><td>27.2</td><td>46.9</td><td>61.0</td><td>66.7</td><td>31.4</td><td>62.2</td><td>78.8</td><td>84.0</td></tr><tr><td colspan="9">DG methods</td></tr><tr><td>Vanilla</td><td>26.7</td><td>48.5</td><td>62.3</td><td>67.4</td><td>26.1</td><td>57.7</td><td>73.7</td><td>80.0</td></tr><tr><td>CrossGrad [47]</td><td>27.1</td><td>48.5</td><td>63.5</td><td>69.5</td><td>26.3</td><td>56.7</td><td>73.5</td><td>79.5</td></tr><tr><td>L2A-OT (ours)</td><td>29.2</td><td>50.1</td><td>64.5</td><td>70.1</td><td>30.2</td><td>63.8</td><td>80.2</td><td>84.6</td></tr></table>

<table><tbody><tr><td rowspan="2">方法</td><td colspan="4">市场 ${1501} \rightarrow$ 杜克(Duke)</td><td colspan="4">杜克(Duke) $\rightarrow$ 市场1501</td></tr><tr><td>平均精度均值(mAP)</td><td>R1</td><td>R5</td><td>R10</td><td>平均精度均值(mAP)</td><td>R1</td><td>R5</td><td>R10</td></tr><tr><td colspan="9">无监督域适应(UDA)方法</td></tr><tr><td>AT网络(ATNet) [32]</td><td>24.9</td><td>45.1</td><td>59.5</td><td>64.2</td><td>25.6</td><td>55.7</td><td>73.2</td><td>79.4</td></tr><tr><td>摄像头风格(CamStyle) [59]</td><td>25.1</td><td>48.4</td><td>62.5</td><td>68.9</td><td>27.4</td><td>58.8</td><td>78.2</td><td>84.3</td></tr><tr><td>分层哈希学习(HHL) [58]</td><td>27.2</td><td>46.9</td><td>61.0</td><td>66.7</td><td>31.4</td><td>62.2</td><td>78.8</td><td>84.0</td></tr><tr><td colspan="9">领域泛化(DG)方法</td></tr><tr><td>普通版</td><td>26.7</td><td>48.5</td><td>62.3</td><td>67.4</td><td>26.1</td><td>57.7</td><td>73.7</td><td>80.0</td></tr><tr><td>交叉梯度(CrossGrad) [47]</td><td>27.1</td><td>48.5</td><td>63.5</td><td>69.5</td><td>26.3</td><td>56.7</td><td>73.5</td><td>79.5</td></tr><tr><td>标签到属性最优传输(L2A - OT)(我们的方法)</td><td>29.2</td><td>50.1</td><td>64.5</td><td>70.1</td><td>30.2</td><td>63.8</td><td>80.2</td><td>84.6</td></tr></tbody></table>

![0195d2af-b9ca-7804-8a22-d612eeb794e6_10_182_787_1213_283_0.jpg](images/0195d2af-b9ca-7804-8a22-d612eeb794e6_10_182_787_1213_283_0.jpg)

Fig. 5. Ablation study.

图5. 消融研究。

### 4.2 Evaluation on Heterogeneous DG

### 4.2 异构分布泛化(DG)评估

In this section, we evaluate L2A-OT on a more challenging DG task with disjoint label space between training and test data, namely cross-domain person re-identification (re-ID).

在本节中，我们在一个更具挑战性的分布泛化(DG)任务上评估L2A - OT，该任务的训练数据和测试数据的标签空间不相交，即跨域行人重识别(re - ID)。

Datasets. We use Market1501 [56] and DukeMTMC-reID (Duke) [43,57]. Market 1501 has 32,668 images of 1,501 identities captured by 6 cameras (domains). Duke has 36,411 images of 1,812 identities captured by 8 cameras.

数据集。我们使用Market1501 [56]和DukeMTMC - reID(Duke) [43,57]。Market1501包含由6个摄像头(域)捕获的1501个身份的32668张图像。Duke包含由8个摄像头捕获的1812个身份的36411张图像。

Evaluation Protocol. We follow the recent unsupervised domain adaptation (UDA) methods in the person re-ID literature $\left\lbrack  {{32},{58},{59}}\right\rbrack$ and experiment with Market ${1501} \rightarrow$ Duke and Duke $\rightarrow$ Market 1501. Different from the UDA setting, we directly test the source-trained model on the target dataset without adaptation. Note that the cross-domain re-ID evaluation involves training a person classifier on source dataset identities. This is then transferred and used to recognize a disjoint set of people in the target domain of unseen camera views via nearest neighbor. Since the label space is disjoint, this is a heterogeneous DG problem. For performance measure, we adopt CMC ranks and mAP [56].

评估协议。我们遵循行人重识别文献中最近的无监督域适应(UDA)方法$\left\lbrack  {{32},{58},{59}}\right\rbrack$，并对Market ${1501} \rightarrow$ Duke和Duke $\rightarrow$ Market 1501进行实验。与无监督域适应(UDA)设置不同，我们直接在目标数据集上测试源训练模型，而不进行适应。请注意，跨域重识别评估涉及在源数据集身份上训练行人分类器。然后通过最近邻方法将其迁移并用于识别目标域中未见摄像头视角下的不相交人群集。由于标签空间不相交，这是一个异构分布泛化(DG)问题。对于性能度量，我们采用累积匹配特征(CMC)排名和平均精度均值(mAP) [56]。

![0195d2af-b9ca-7804-8a22-d612eeb794e6_11_337_178_803_230_0.jpg](images/0195d2af-b9ca-7804-8a22-d612eeb794e6_11_337_178_803_230_0.jpg)

Fig. 6. Results of varying ${K}_{n}$ . Here ${K}_{s} = 3$ .

图6. 改变${K}_{n}$的结果。这里${K}_{s} = 3$。

Table 5. Using two vs. three source domains on Digits-DG where the size of training data is kept identical for all settings for fair comparison.

表5. 在Digits - DG上使用两个与三个源域的情况，为了公平比较，所有设置的训练数据大小保持相同。

<table><tr><td colspan="3">Source</td><td rowspan="2">Target</td><td rowspan="2">L2A-OT</td><td rowspan="2">Vanilla</td></tr><tr><td>MNIST</td><td>SVHN</td><td>SYN</td></tr><tr><td>✓</td><td>✓</td><td/><td>MNIST-M</td><td>60.9</td><td>54.6</td></tr><tr><td>✓</td><td/><td>✓</td><td>MNIST-M</td><td>62.1</td><td>59.1</td></tr><tr><td/><td>✓</td><td>✓</td><td>MNIST-M</td><td>49.7</td><td>45.2</td></tr><tr><td>✓</td><td>✓</td><td>✓</td><td>MNIST-M</td><td>62.5</td><td>57.1</td></tr></table>

<table><tbody><tr><td colspan="3">源</td><td rowspan="2">目标</td><td rowspan="2">L2A-OT</td><td rowspan="2">普通版</td></tr><tr><td>手写数字数据集(MNIST)</td><td>街景门牌号数据集(SVHN)</td><td>合成数据集(SYN)</td></tr><tr><td>✓</td><td>✓</td><td></td><td>MNIST-M数据集</td><td>60.9</td><td>54.6</td></tr><tr><td>✓</td><td></td><td>✓</td><td>MNIST-M数据集</td><td>62.1</td><td>59.1</td></tr><tr><td></td><td>✓</td><td>✓</td><td>MNIST-M数据集</td><td>49.7</td><td>45.2</td></tr><tr><td>✓</td><td>✓</td><td>✓</td><td>MNIST-M数据集</td><td>62.5</td><td>57.1</td></tr></tbody></table>

Implementation Details. For the CNN backbone, we employ the state-of-the-art re-ID model, OSNet-IBN [61,62]. Following [61,62], OSNet-IBN is trained using the standard classification paradigm, i.e. each identity is considered as a class. Therefore, the entire L2A-OT framework remains unchanged. At test time, feature vectors extracted from OSNet-IBN are used to compute ${\ell }_{2}$ distance for image matching. Our implementation is based on Torchreid [60].

实现细节。对于卷积神经网络(CNN)主干网络，我们采用了最先进的行人重识别(re-ID)模型OSNet-IBN [61,62]。遵循文献[61,62]，OSNet-IBN使用标准分类范式进行训练，即每个身份被视为一个类别。因此，整个L2A-OT框架保持不变。在测试时，从OSNet-IBN提取的特征向量用于计算${\ell }_{2}$距离以进行图像匹配。我们的实现基于Torchreid [60]。

Results. In Table 4, we compare L2A-OT with the vanilla model and CrossGrad, as well as state-of-the-art UDA methods for re-ID. As a result, CrossGrad barely improves the vanilla model while L2A-OT achieves clear improvements on both settings. Notably, L2A-OT is highly competitive with the UDA methods, though the latter make the significantly stronger assumption of having access to the target domain data (thus gaining an unfair advantage). In contrast, L2A-OT generates images of unseen styles (domains) for data augmentation, and such more diverse data leads to learning a better generalizable re-ID model.

结果。在表4中，我们将L2A-OT与原始模型和CrossGrad以及最先进的无监督域适应(UDA)行人重识别方法进行了比较。结果表明，CrossGrad对原始模型的改进微乎其微，而L2A-OT在两种设置下都取得了明显的改进。值得注意的是，L2A-OT与UDA方法具有很强的竞争力，尽管后者做出了能够访问目标域数据的更强假设(从而获得了不公平的优势)。相比之下，L2A-OT生成未见风格(域)的图像用于数据增强，这种更多样化的数据有助于学习到更具泛化能力的行人重识别模型。

### 4.3 Ablation Study

### 4.3 消融研究

Importance of Generating Novel Domains. To verify that our improvement is brought by the increase in training data distributions by the generated novel domains (i.e. Eq. (2) and (3)), we compare L2A-OT with StarGAN [6], which generates data from the existing source domains by performing source-to-source mapping. The experiment is conducted on Digits-DG and the average performance over all test domains is used for comparison. Figure 5a shows that StarGAN performs only similarly to the vanilla model (StarGAN’s 73.8% vs. vanilla’s 73.7%) while L2A-OT obtains a clear improvement of 4.3% over Star-GAN. This confirms that increasing domains is far more important than increasing data (of seen domains) for DG. Note that this 4.3% gap is attributed to the combination of the OT-based domain novelty loss (Eq. (2)) and the diversity loss (Eq. (3)). Figure 5a shows that the diversity loss contributes around 1% to the performance, and the rest improvement comes from the diversity loss.

生成新域的重要性。为了验证我们的改进是由生成的新域增加了训练数据分布所带来的(即公式(2)和(3))，我们将L2A-OT与StarGAN [6]进行了比较，StarGAN通过执行源到源映射从现有的源域生成数据。该实验在Digits-DG上进行，并使用所有测试域的平均性能进行比较。图5a显示，StarGAN的性能仅与原始模型相似(StarGAN为73.8%，原始模型为73.7%)，而L2A-OT比StarGAN有4.3%的明显提升。这证实了对于领域泛化(DG)而言，增加域远比增加(已见域的)数据重要。请注意，这4.3%的差距归因于基于最优传输(OT)的域新颖性损失(公式(2))和多样性损失(公式(3))的结合。图5a显示，多样性损失对性能的贡献约为1%，其余的改进来自于多样性损失。

![0195d2af-b9ca-7804-8a22-d612eeb794e6_12_184_176_1211_473_0.jpg](images/0195d2af-b9ca-7804-8a22-d612eeb794e6_12_184_176_1211_473_0.jpg)

Fig. 7. T-SNE visualization of domain embeddings of (a) L2A-OT and (b) Cross-Grad [47]. X (G) indicates novel data when using the domain X as a source.

图7. (a) L2A-OT和(b) Cross-Grad [47]的域嵌入的T-SNE可视化。X (G)表示以域X为源时的新数据。

![0195d2af-b9ca-7804-8a22-d612eeb794e6_12_183_787_1215_470_0.jpg](images/0195d2af-b9ca-7804-8a22-d612eeb794e6_12_183_787_1215_470_0.jpg)

Fig. 8. Visualization of generated images. $x$ : source image. $G\left( {x, i}\right)$ : generated image of the $i$ -th novel domain.

图8. 生成图像的可视化。$x$:源图像。$G\left( {x, i}\right)$:第$i$个新域的生成图像。

Importance of Semantic Constraint. The cycle-consistency and cross-entropy losses (Eq. (4) and (5)) are essential in the L2A-OT framework for maintaining the semantic content when performing domain translation. Figure 5b shows that without the semantic constraint, the content is completely missing (we found that using these images reduced the result from 78.1% to 73.9%).

语义约束的重要性。循环一致性损失和交叉熵损失(公式(4)和(5))在L2A-OT框架中对于在进行域转换时保持语义内容至关重要。图5b显示，没有语义约束时，内容完全缺失(我们发现使用这些图像会使结果从78.1%降至73.9%)。

![0195d2af-b9ca-7804-8a22-d612eeb794e6_13_186_173_1108_232_0.jpg](images/0195d2af-b9ca-7804-8a22-d612eeb794e6_13_186_173_1108_232_0.jpg)

Fig. 9. Comparison between L2A-OT and CrossGrad [47] on image generation.

图9. L2A-OT和CrossGrad [47]在图像生成方面的比较。

### 4.4 Further Analysis

### 4.4 进一步分析

How Many Novel Domains to Generate? Our approach can generate an arbitrary number of novel domains, although we have always doubled the number of domains (set ${K}_{s} = {K}_{n}$ ) so far. Figure 6 investigates the significance on the choice of number of novel domains. In principle, synthesizing more domains provides opportunity for more diverse data, but also increases optimization difficulty and is dependent on the source domains. The result shows that the performance is not very sensitive to the choice of novel domain number, with ${K}_{n} = {K}_{s}$ being a good rule of thumb.

生成多少个新域？我们的方法可以生成任意数量的新域，尽管到目前为止我们一直将域的数量翻倍(设置${K}_{s} = {K}_{n}$)。图6研究了新域数量选择的重要性。原则上，合成更多的域为更丰富多样的数据提供了机会，但也增加了优化难度，并且依赖于源域。结果表明，性能对新域数量的选择不是非常敏感，${K}_{n} = {K}_{s}$是一个不错的经验法则。

Do More Source Domains Lead to a Better Result? In general, yes. The evidence is shown in Table 5 where the result of using three sources is generally better than using two as we might expect due to the additional diversity. The detailed results show that when using two sources, performance is sensitive to the choice of sources among the available three. This is expected since different sources will vary in transferrability to a given target. However, for both vanilla and L2A-OT the performance of using three sources is better than the performance of using two averaged across the 2-source choices.

更多的源域会带来更好的结果吗？一般来说，答案是肯定的。表5中的证据表明，正如我们所预期的，由于额外的多样性，使用三个源的结果通常比使用两个源的结果更好。详细结果显示，当使用两个源时，性能对从可用的三个源中选择源很敏感。这是可以预料的，因为不同的源对给定目标的可迁移性会有所不同。然而，对于原始模型和L2A-OT，使用三个源的性能都优于在所有两个源组合选择上的平均性能。

Visualizing Domain Distributions. We employ t-SNE [34] to visualize the domain feature embeddings using the validation set of Digits-DG (see Fig. 7a). We have the following observations. (1) The generated distributions are clearly separated from the source domains and evenly fill the unseen domain space. (2) The generated distributions form independent clusters (due to our diversity term in Eq. (3)). (3) $G$ has successfully learned to flexibly transform one source domain to any of the discovered novel domains.

可视化领域分布。我们使用t-SNE [34] 对Digits-DG验证集的领域特征嵌入进行可视化(见图7a)。我们有以下观察结果。(1)生成的分布与源领域明显分离，并均匀填充了未见领域空间。(2)生成的分布形成独立的聚类(这是由于我们在公式(3)中的多样性项)。(3)$G$ 成功学习到了将一个源领域灵活转换为任何已发现的新领域的方法。

Visualizing Novel-Domain Images. Figure 8 visualizes the output of $G$ . In general, we observe that the generated images from different novel domains manifest different properties and more importantly, are clearly different from the source images. For example, in Digits-DG (Fig. 8a), $G$ tends to generate images with different background patterns/textures and font colors. In PACS (Fig. 8b), $G$ focuses on contrast and color. Figure 8 seems to suggest that the synthesized domains are not drastically different from each other. However, a seemingly limited diversity in the image space to human eyes can be significant to a CNN classifier: both Fig. 1 and Fig. 7a show clearly that the synthesized data points have very different distributions from both the original ones and each other in a feature embedding space, making them useful for learning a domain-generalizable classifier.

可视化新领域图像。图8展示了$G$ 的输出。总体而言，我们观察到不同新领域生成的图像呈现出不同的特性，更重要的是，它们与源图像明显不同。例如，在Digits-DG(图8a)中，$G$ 倾向于生成具有不同背景图案/纹理和字体颜色的图像。在PACS(图8b)中，$G$ 侧重于对比度和颜色。图8似乎表明合成的领域彼此之间差异不大。然而，在人类眼中图像空间中看似有限的多样性，对于卷积神经网络(CNN)分类器来说可能是显著的:图1和图7a都清楚地表明，合成的数据点在特征嵌入空间中的分布与原始数据点以及彼此之间都有很大不同，这使得它们有助于学习一个具有领域泛化能力的分类器。

L2A-OT vs. CrossGrad. It is clear from Fig. 7b that the new domains generated by CrossGrad largely overlap with the original domains. This is because CrossGrad is based on adversarial attack methods [18], which are designed to make imperceptible changes. This is further verified in Fig. 9 where the images generated by CrossGrad have only subtle differences in contrast to the original images. On the contrary, L2A-OT can model much more complex domain variations that can materially benefit the classifier, thanks to the full CNN image generator and OT-based domain divergence losses.

L2A - OT与CrossGrad的比较。从图7b可以明显看出，CrossGrad生成的新领域与原始领域有很大的重叠。这是因为CrossGrad基于对抗攻击方法 [18]，这些方法旨在进行难以察觉的更改。图9进一步验证了这一点，其中CrossGrad生成的图像与原始图像相比只有细微的差异。相反，由于采用了完整的CNN图像生成器和基于最优传输(OT)的领域差异损失，L2A - OT可以对更复杂的领域变化进行建模，这对分类器有实质性的好处。

## 5 Conclusion

## 5 结论

We presented L2A-OT, a novel data augmentation-based DG method that boosts classifier's robustness to domain shift by learning to synthesize images from diverse unseen domains through a conditional generator network. The generator is trained by maximizing the OT distance between source domains and pseudo-novel domains. Cycle-consistency and classification losses are imposed on the generator to further maintain the structural and semantic consistency during domain translation. Extensive experiments on four DG benchmark datasets covering a wide range of visual recognition tasks demonstrate the effectiveness and versatility of L2A-OT.

我们提出了L2A - OT，这是一种基于数据增强的新型领域泛化(DG)方法，通过条件生成网络学习从不同的未见领域合成图像，从而提高分类器对领域偏移的鲁棒性。生成器通过最大化源领域和伪新领域之间的最优传输距离进行训练。在生成器上施加循环一致性和分类损失，以在领域转换过程中进一步保持结构和语义的一致性。在涵盖广泛视觉识别任务的四个DG基准数据集上进行的大量实验证明了L2A - OT的有效性和通用性。

## References

## 参考文献

1. Arjovsky, M., Chintala, S., Bottou, L.: Wasserstein generative adversarial networks. In: ICML (2017)

1. Arjovsky, M., Chintala, S., Bottou, L.: 瓦瑟斯坦生成对抗网络(Wasserstein Generative Adversarial Networks)。见:国际机器学习会议(ICML)(2017)

2. Balaji, Y., Sankaranarayanan, S., Chellappa, R.: MetaReg: towards domain generalization using meta-regularization. In: NeurIPS (2018)

2. Balaji, Y., Sankaranarayanan, S., Chellappa, R.: MetaReg:使用元正则化实现领域泛化。见:神经信息处理系统大会(NeurIPS)(2018)

3. Bellemare, M.G., et al.: The cramer distance as a solution to biased wasserstein gradients. arXiv preprint arXiv:1705.10743 (2017)

3. Bellemare, M.G.等:将克莱姆距离作为解决有偏瓦瑟斯坦梯度的方法。预印本arXiv:1705.10743(2017)

4. Ben-David, Shai., Blitzer, John., Crammer, Koby., Kulesza, Alex., Pereira, Fernando, Vaughan, Jennifer Wortman: A theory of learning from different domains. Mach. Learn. 79(1), 151-175 (2009). https://doi.org/10.1007/s10994-009-5152-4

4. Ben - David, Shai., Blitzer, John., Crammer, Koby., Kulesza, Alex., Pereira, Fernando, Vaughan, Jennifer Wortman: 不同领域学习理论。《机器学习》79(1)，151 - 175(2009)。https://doi.org/10.1007/s10994 - 009 - 5152 - 4

5. Carlucci, F.M., D'Innocente, A., Bucci, S., Caputo, B., Tommasi, T.: Domain generalization by solving jigsaw puzzles. In: CVPR (2019)

5. Carlucci, F.M., D'Innocente, A., Bucci, S., Caputo, B., Tommasi, T.: 通过解决拼图难题实现领域泛化。见:计算机视觉与模式识别会议(CVPR)(2019)

6. Choi, Y., Choi, M., Kim, M., Ha, J.W., Kim, S., Choo, J.: StarGAN: unified generative adversarial networks for multi-domain image-to-image translation. In: CVPR (2018)

6. Choi, Y., Choi, M., Kim, M., Ha, J.W., Kim, S., Choo, J.: StarGAN:用于多领域图像到图像转换的统一生成对抗网络。见:计算机视觉与模式识别会议(CVPR)(2018)

7. Cuturi, M.: Sinkhorn distances: lightspeed computation of optimal transport. In: NeurIPS (2013)

7. Cuturi, M.: 辛克霍恩距离:最优传输的快速计算。见:神经信息处理系统大会(NeurIPS)(2013)

8. Deng, J., Dong, W., Socher, R., Li, L.J., Li, K., Fei-Fei, L.: ImageNet: a large-scale hierarchical image database. In: CVPR (2009)

8. Deng, J., Dong, W., Socher, R., Li, L.J., Li, K., Fei - Fei, L.: ImageNet:大规模分层图像数据库。见:计算机视觉与模式识别会议(CVPR)(2009)

9. D'Innocente, A., Caputo, B.: Domain generalization with domain-specific aggregation modules. In: GCPR (2018)

9. D'Innocente, A., Caputo, B.: 使用特定领域聚合模块实现领域泛化。见:德国模式识别会议(GCPR)(2018)

10. Dou, Q., Castro, D.C., Kamnitsas, K., Glocker, B.: Domain generalization via model-agnostic learning of semantic features. In: NeurIPS (2019)

10. Dou, Q., Castro, D.C., Kamnitsas, K., Glocker, B.: 通过模型无关的语义特征学习实现领域泛化。见:神经信息处理系统大会(NeurIPS)(2019)

11. Gan, C., Yang, T., Gong, B.: Learning attributes equals multi-source domain generalization. In: CVPR (2016)

11. 甘(Gan)，C.；杨(Yang)，T.；龚(Gong)，B.:学习属性等同于多源领域泛化。见:计算机视觉与模式识别会议(CVPR)(2016年)

12. Ganin, Y., Lempitsky, V.S.: Unsupervised domain adaptation by backpropagation. In: ICML (2015)

12. 加宁(Ganin)，Y.；伦皮茨基(Lempitsky)，V.S.:通过反向传播进行无监督领域自适应。见:国际机器学习会议(ICML)(2015年)

13. Ganin, Y., et al.: Domain-adversarial training of neural networks. JMLR 17(1), 2030-2096 (2016)

13. 加宁(Ganin)，Y.等:神经网络的领域对抗训练。《机器学习研究杂志》(JMLR)17(1)，2030 - 2096(2016年)

14. Genevay, A., Peyré, G., Cuturi, M.: Learning generative models with sinkhorn divergences. In: AISTATS (2018)

14. 热内韦(Genevay)，A.；佩雷(Peyré)，G.；屈蒂里(Cuturi)，M.:使用辛克霍恩散度学习生成模型。见:人工智能与统计会议(AISTATS)(2018年)

15. Ghifary, M., Balduzzi, D., Kleijn, W.B., Zhang, M.: Scatter component analysis: a unified framework for domain adaptation and domain generalization. TPAMI 39(7), 1414-1430 (2017)

15. 吉法里(Ghifary)，M.；巴尔杜齐(Balduzzi)，D.；克莱因(Kleijn)，W.B.；张(Zhang)，M.:散度分量分析:领域自适应和领域泛化的统一框架。《模式分析与机器智能汇刊》(TPAMI)39(7)，1414 - 1430(2017年)

16. Ghifary, M., Kleijn, W.B., Zhang, M., Balduzzi, D.: Domain generalization for object recognition with multi-task autoencoders. In: ICCV (2015)

16. 吉法里(Ghifary)，M.；克莱因(Kleijn)，W.B.；张(Zhang)，M.；巴尔杜齐(Balduzzi)，D.:使用多任务自编码器进行目标识别的领域泛化。见:国际计算机视觉会议(ICCV)(2015年)

17. Goodfellow, I., et al.: Generative adversarial nets. In: NeurIPS (2014)

17. 古德费洛(Goodfellow)，I.等:生成对抗网络。见:神经信息处理系统大会(NeurIPS)(2014年)

18. Goodfellow, I.J., Shlens, J., Szegedy, C.: Explaining and harnessing adversarial examples. In: ICLR (2015)

18. 古德费洛(Goodfellow)，I.J.；什伦斯(Shlens)，J.；塞吉迪(Szegedy)，C.:解释和利用对抗样本。见:国际学习表征会议(ICLR)(2015年)

19. He, K., Zhang, X., Ren, S., Sun, J.: Deep residual learning for image recognition. In: CVPR (2016)

19. 何(He)，K.；张(Zhang)，X.；任(Ren)，S.；孙(Sun)，J.:用于图像识别的深度残差学习。见:计算机视觉与模式识别会议(CVPR)(2016年)

20. Hoffman, J., et al.: CyCADA: cycle-consistent adversarial domain adaptation. In: ICML (2018)

20. 霍夫曼(Hoffman)，J.等:循环一致对抗领域自适应(CyCADA)。见:国际机器学习会议(ICML)(2018年)

21. Hospedales, T., Antoniou, A., Micaelli, P., Storkey, A.: Meta-learning in neural networks: a survey. arXiv preprint arXiv:2004.05439 (2020)

21. 霍斯佩代尔斯(Hospedales)，T.；安东尼奥(Antoniou)，A.；米卡埃利(Micaelli)，P.；斯托基(Storkey)，A.:神经网络中的元学习:综述。预印本arXiv:2004.05439(2020年)

22. Jin, X., Lan, C., Zeng, W., Chen, Z., Zhang, L.: Style normalization and restitution for generalizable person re-identification. In: CVPR (2020)

22. 金(Jin)，X.；兰(Lan)，C.；曾(Zeng)，W.；陈(Chen)，Z.；张(Zhang)，L.:用于可泛化行人重识别的风格归一化与恢复。见:计算机视觉与模式识别会议(CVPR)(2020年)

23. Kingma, D.P., Ba, J.: Adam: a method for stochastic optimization. In: ICLR (2014)

23. 金马(Kingma)，D.P.；巴(Ba)，J.:Adam:一种随机优化方法。见:国际学习表征会议(ICLR)(2014年)

24. LeCun, Y., Bottou, L., Bengio, Y., Haffner, P.: Gradient-based learning applied to document recognition. Proc. IEEE 86(11), 2278-2324 (1998)

24. 勒昆(LeCun)，Y.；博图(Bottou)，L.；本吉奥(Bengio)，Y.；哈弗纳(Haffner)，P.:基于梯度的学习在文档识别中的应用。《电气与电子工程师协会汇刊》(Proc. IEEE)86(11)，2278 - 2324(1998年)

25. Li, D., Yang, Y., Song, Y.Z., Hospedales, T.M.: Deeper, broader and artier domain generalization. In: ICCV (2017)

25. 李(Li)，D.；杨(Yang)，Y.；宋(Song)，Y.Z.；霍斯佩代尔斯(Hospedales)，T.M.:更深、更广、更具艺术性的领域泛化。见:国际计算机视觉会议(ICCV)(2017年)

26. Li, D., Yang, Y., Song, Y.Z., Hospedales, T.M.: Learning to generalize: meta-learning for domain generalization. In: AAAI (2018)

26. 李(Li)，D.；杨(Yang)，Y.；宋(Song)，Y.Z.；霍斯佩代尔斯(Hospedales)，T.M.:学习泛化:用于领域泛化的元学习。见:美国人工智能协会会议(AAAI)(2018年)

27. Li, D., Zhang, J., Yang, Y., Liu, C., Song, Y.Z., Hospedales, T.M.: Episodic training for domain generalization. In: ICCV (2019)

27. 李(Li)、张(Zhang)、杨(Yang)、刘(Liu)、宋(Song)、霍斯佩代尔斯(Hospedales):用于领域泛化的情景训练。见:国际计算机视觉大会(ICCV)(2019 年)

28. Li, H., Jialin Pan, S., Wang, S., Kot, A.C.: Domain generalization with adversarial feature learning. In: CVPR (2018)

28. 李(Li)、潘嘉琳(Jialin Pan)、王(Wang)、科特(Kot):基于对抗特征学习的领域泛化。见:计算机视觉与模式识别会议(CVPR)(2018 年)

29. Li, Y., Tiana, X., Gong, M., Liu, Y., Liu, T., Zhang, K., Tao, D.: Deep domain generalization via conditional invariant adversarial networks. In: ECCV (2018)

29. 李(Li)、蒂安娜(Tiana)、龚(Gong)、刘(Liu)、刘(Liu)、张(Zhang)、陶(Tao):通过条件不变对抗网络实现深度领域泛化。见:欧洲计算机视觉大会(ECCV)(2018 年)

30. Li, Y., Fang, C., Yang, J., Wang, Z., Lu, X., Yang, M.H.: Diversified texture synthesis with feed-forward networks. In: CVPR (2017)

30. 李(Li)、方(Fang)、杨(Yang)、王(Wang)、陆(Lu)、杨(Yang):使用前馈网络进行多样化纹理合成。见:计算机视觉与模式识别会议(CVPR)(2017 年)

31. Li, Y., Yang, Y., Zhou, W., Hospedales, T.: Feature-critic networks for heterogeneous domain generalization. In: ICML (2019)

31. 李(Li)、杨(Yang)、周(Zhou)、霍斯佩代尔斯(Hospedales):用于异构领域泛化的特征评判网络。见:国际机器学习会议(ICML)(2019 年)

32. Liu, J., Zha, Z.J., Chen, D., Hong, R., Wang, M.: Adaptive transfer network for cross-domain person re-identification. In: CVPR (2019)

32. 刘(Liu)、查(Zha)、陈(Chen)、洪(Hong)、王(Wang):用于跨领域行人重识别的自适应迁移网络。见:计算机视觉与模式识别会议(CVPR)(2019 年)

33. Long, M., Cao, Y., Wang, J., Jordan, M.I.: Learning transferable features with deep adaptation networks. In: ICML (2015)

33. 龙(Long)、曹(Cao)、王(Wang)、乔丹(Jordan):使用深度自适应网络学习可迁移特征。见:国际机器学习会议(ICML)(2015 年)

34. Maaten, L.V.D., Hinton, G.: Visualizing data using t-SNE. JMLR 9, 2579-2605 (2008)

34. 马滕(Maaten)、辛顿(Hinton):使用 t - 分布随机邻域嵌入(t - SNE)可视化数据。《机器学习研究杂志》(JMLR)9 卷，2579 - 2605 页(2008 年)

35. Moreno-Torres, J.G., Raeder, T., Alaiz-RodríGuez, R., Chawla, N.V., Herrera, F.: A unifying view on dataset shift in classification. PR $\mathbf{{45}}\left( 1\right) ,{521} - {530}\left( {2012}\right)$

35. 莫雷诺 - 托雷斯(Moreno - Torres)、雷德(Raeder)、阿拉伊斯 - 罗德里格斯(Alaiz - RodríGuez)、乔拉(Chawla)、埃雷拉(Herrera):分类中数据集偏移的统一观点。《模式识别》(PR)$\mathbf{{45}}\left( 1\right) ,{521} - {530}\left( {2012}\right)$

36. Motiian, S., Piccirilli, M., Adjeroh, D.A., Doretto, G.: Unified deep supervised domain adaptation and generalization. In: ICCV (2017)

36. 莫蒂安(Motiian)、皮西里利(Piccirilli)、阿杰罗(Adjeroh)、多雷托(Doretto):统一的深度监督领域适应与泛化。见:国际计算机视觉大会(ICCV)(2017 年)

37. Muandet, K., Balduzzi, D., Scholkopf, B.: Domain generalization via invariant feature representation. In: ICML (2013)

37. 穆安代特(Muandet)、巴尔杜齐(Balduzzi)、肖尔科普夫(Scholkopf):通过不变特征表示实现领域泛化。见:国际机器学习会议(ICML)(2013 年)

38. Netzer, Y., Wang, T., Coates, A., Bissacco, A., Wu, B., Ng, A.Y.: Reading digits in natural images with unsupervised feature learning. In: NeurIPS-W (2011)

38. 内策尔(Netzer)、王(Wang)、科茨(Coates)、比萨科(Bissacco)、吴(Wu)、吴恩达(Ng):通过无监督特征学习识别自然图像中的数字。见:神经信息处理系统大会研讨会(NeurIPS - W)(2011 年)

39. Noroozi, M., Favaro, P.: Unsupervised learning of visual representations by solving jigsaw puzzles. In: ECCV (2016)

39. 诺鲁齐(Noroozi)、法瓦罗(Favaro):通过解决拼图难题进行视觉表示的无监督学习。见:欧洲计算机视觉大会(ECCV)(2016 年)

40. Peng, X., Bai, Q., Xia, X., Huang, Z., Saenko, K., Wang, B.: Moment matching for multi-source domain adaptation. In: ICCV (2019)

40. 彭(Peng)、白(Bai)、夏(Xia)、黄(Huang)、塞内科(Saenko)、王(Wang):多源领域适应的矩匹配。见:国际计算机视觉大会(ICCV)(2019 年)

41. Peyré, G., Cuturi, M., et al.: Computational optimal transport. Found. Trends Mach. Learn. 11(5-6), 355-607 (2019)

41. 佩雷(Peyré)、屈图里(Cuturi)等:计算最优传输。《机器学习基础与趋势》(Found. Trends Mach. Learn.)11 卷(5 - 6 期)，355 - 607 页(2019 年)

42. Prakash, A., et al.: Structured domain randomization: bridging the reality gap by context-aware synthetic data. In: ICRA (2019)

42. 普拉卡什(Prakash)等:结构化领域随机化:通过上下文感知合成数据缩小现实差距。见:国际机器人与自动化会议(ICRA)(2019 年)

43. Ristani, E., Solera, F., Zou, R.S., Cucchiara, R., Tomasi, C.: Performance measures and a data set for multi-target, multi-camera tracking. In: ECCV-W (2016)

43. 里斯塔尼(Ristani, E.)、索莱拉(Solera, F.)、邹(Zou, R.S.)、库基亚拉(Cucchiara, R.)、托马西(Tomasi, C.):多目标多摄像头跟踪的性能指标和数据集。见:欧洲计算机视觉大会研讨会(ECCV - W)(2016年)

44. Saito, K., Kim, D., Sclaroff, S., Darrell, T., Saenko, K.: Semi-supervised domain adaptation via minimax entropy. In: ICCV (2019)

44. 斋藤(Saito, K.)、金(Kim, D.)、斯克拉罗夫(Sclaroff, S.)、达雷尔(Darrell, T.)、佐野(Saenko, K.):通过极小极大熵实现半监督域适应。见:国际计算机视觉大会(ICCV)(2019年)

45. Salimans, T., Zhang, H., Radford, A., Metaxas, D.: Improving GANs using optimal transport. In: ICLR (2018)

45. 萨利曼斯(Salimans, T.)、张(Zhang, H.)、拉德福德(Radford, A.)、梅塔克萨斯(Metaxas, D.):使用最优传输改进生成对抗网络(GAN)。见:国际学习表征会议(ICLR)(2018年)

46. Shaham, T.R., Dekel, T., Michaeli, T.: Singan: Learning a generative model from a single natural image. In: ICCV (2019)

46. 沙哈姆(Shaham, T.R.)、德克尔(Dekel, T.)、米凯莱利(Michaeli, T.):单图像生成对抗网络(SinGAN):从单张自然图像学习生成模型。见:国际计算机视觉大会(ICCV)(2019年)

47. Shankar, S., Piratla, V., Chakrabarti, S., Chaudhuri, S., Jyothi, P., Sarawagi, S.: Generalizing across domains via cross-gradient training. In: ICLR (2018)

47. 尚卡尔(Shankar, S.)、皮拉特(Piratla, V.)、查克拉巴蒂(Chakrabarti, S.)、乔杜里(Chaudhuri, S.)、乔蒂(Jyothi, P.)、萨拉瓦吉(Sarawagi, S.):通过交叉梯度训练实现跨领域泛化。见:国际学习表征会议(ICLR)(2018年)

48. Szegedy, C., et al.: Intriguing properties of neural networks. In: ICLR (2014)

48. 塞格迪(Szegedy, C.)等:神经网络的有趣特性。见:国际学习表征会议(ICLR)(2014年)

49. Tobin, J., Fong, R., Ray, A., Schneider, J., Zaremba, W., Abbeel, P.: Domain randomization for transferring deep neural networks from simulation to the real world. In: IROS (2017)

49. 托宾(Tobin, J.)、方(Fong, R.)、雷(Ray, A.)、施耐德(Schneider, J.)、扎雷巴(Zaremba, W.)、阿贝埃尔(Abbeel, P.):用于将深度神经网络从模拟环境迁移到现实世界的域随机化方法。见:智能机器人与系统国际会议(IROS)(2017年)

50. Tzeng, E., Hoffman, J., Saenko, K., Darrell, T.: Adversarial discriminative domain adaptation. In: CVPR (2017)

50. 曾(Tzeng, E.)、霍夫曼(Hoffman, J.)、佐野(Saenko, K.)、达雷尔(Darrell, T.):对抗性判别域适应。见:计算机视觉与模式识别会议(CVPR)(2017年)

51. Venkateswara, H., Eusebio, J., Chakraborty, S., Panchanathan, S.: Deep hashing network for unsupervised domain adaptation. In: CVPR (2017)

51. 文卡特斯瓦拉(Venkateswara, H.)、尤塞比奥(Eusebio, J.)、查克拉博蒂(Chakraborty, S.)、潘查纳坦(Panchanathan, S.):用于无监督域适应的深度哈希网络。见:计算机视觉与模式识别会议(CVPR)(2017年)

52. Volpi, R., Namkoong, H., Sener, O., Duchi, J., Murino, V., Savarese, S.: Generalizing to unseen domains via adversarial data augmentation. In: NeurIPS (2018)

52. 沃尔皮(Volpi, R.)、南孔(Namkoong, H.)、森纳(Sener, O.)、杜奇(Duchi, J.)、穆里诺(Murino, V.)、萨瓦雷塞(Savarese, S.):通过对抗性数据增强实现对未见领域的泛化。见:神经信息处理系统大会(NeurIPS)(2018年)

53. Xu, R., Li, G., Yang, J., Lin, L.: Larger norm more transferable: an adaptive feature norm approach for unsupervised domain adaptation. In: ICCV (2019)

53. 徐(Xu, R.)、李(Li, G.)、杨(Yang, J.)、林(Lin, L.):范数越大，迁移性越强:一种用于无监督域适应的自适应特征范数方法。见:国际计算机视觉大会(ICCV)(2019年)

54. Yue, X., Zhang, Y., Zhao, S., Sangiovanni-Vincentelli, A., Keutzer, K., Gong, B.: Domain randomization and pyramid consistency: simulation-to-real generalization without accessing target domain data. In: ICCV (2019)

54. 岳(Yue, X.)、张(Zhang, Y.)、赵(Zhao, S.)、桑乔万尼 - 文森泰利(Sangiovanni - Vincentelli, A.)、科伊策(Keutzer, K.)、龚(Gong, B.):域随机化和金字塔一致性:无需访问目标域数据的模拟到现实泛化。见:国际计算机视觉大会(ICCV)(2019年)

55. Zakharov, S., Kehl, W., Ilic, S.: DeceptionNet: network-driven domain randomization. In: ICCV (2019)

55. 扎哈罗夫(Zakharov, S.)、凯尔(Kehl, W.)、伊利奇(Ilic, S.):欺骗网络(DeceptionNet):网络驱动的域随机化。见:国际计算机视觉大会(ICCV)(2019年)

56. Zheng, L., Shen, L., Tian, L., Wang, S., Wang, J., Tian, Q.: Scalable person reidentification: a benchmark. In: ICCV (2015)

56. 郑(Zheng, L.)、沈(Shen, L.)、田(Tian, L.)、王(Wang, S.)、王(Wang, J.)、田(Tian, Q.):可扩展的行人重识别:一个基准。见:国际计算机视觉大会(ICCV)(2015年)

57. Zheng, Z., Zheng, L., Yang, Y.: Unlabeled samples generated by GAN improve the person re-identification baseline in vitro. In: ICCV (2017)

57. 郑(Zheng, Z.)、郑(Zheng, L.)、杨(Yang, Y.):生成对抗网络生成的无标签样本在体外改善行人重识别基线。见:国际计算机视觉大会(ICCV)(2017年)

58. Zhong, Z., Zheng, L., Li, S., Yang, Y.: Generalizing a person retrieval model hetero-and homogeneously. In: ECCV (2018)

58. 钟(Zhong, Z.)、郑(Zheng, L.)、李(Li, S.)、杨(Yang, Y.):行人检索模型的异质和同质泛化。见:欧洲计算机视觉大会(ECCV)(2018年)

59. Zhong, Z., Zheng, L., Zheng, Z., Li, S., Yang, Y.: Camstyle: A novel data augmentation method for person re-identification. TIP 28(3), 1176-1190 (2019)

59. 钟(Zhong)、郑(Zheng)、郑(Zheng)、李(Li)、杨(Yang):Camstyle:一种用于行人重识别的新型数据增强方法。《IEEE图像处理汇刊》(TIP)28(3)，1176 - 1190 (2019)

60. Zhou, K., Xiang, T.: Torchreid: a library for deep learning person re-identification in pytorch. arXiv preprint arXiv:1910.10093 (2019)

60. 周(Zhou)、向(Xiang):Torchreid:一个基于PyTorch的深度学习行人重识别库。预印本arXiv:1910.10093 (2019)

61. Zhou, K., Yang, Y., Cavallaro, A., Xiang, T.: Learning generalisable omni-scale representations for person re-identification. arXiv preprint arXiv:1910.06827 (2019)

61. 周(Zhou)、杨(Yang)、卡瓦拉罗(Cavallaro)、向(Xiang):学习可泛化的全尺度行人重识别表示。预印本arXiv:1910.06827 (2019)

62. Zhou, K., Yang, Y., Cavallaro, A., Xiang, T.: Omni-scale feature learning for person re-identification. In: ICCV (2019)

62. 周(Zhou)、杨(Yang)、卡瓦拉罗(Cavallaro)、向(Xiang):用于行人重识别的全尺度特征学习。见:国际计算机视觉大会(ICCV)(2019)

63. Zhou, K., Yang, Y., Qiao, Y., Xiang, T.: Domain adaptive ensemble learning. arXiv preprint arXiv:2003.07325 (2020)

63. 周(Zhou)、杨(Yang)、乔(Qiao)、向(Xiang):领域自适应集成学习。预印本arXiv:2003.07325 (2020)

64. Zhu, J.Y., Park, T., Isola, P., Efros, A.A.: Unpaired image-to-image translation using cycle-consistent adversarial networks. In: ICCV (2017)

64. 朱(Zhu)、朴(Park)、伊索拉(Isola)、埃弗罗斯(Efros):使用循环一致对抗网络进行无配对图像到图像的转换。见:国际计算机视觉大会(ICCV)(2017)