# Feature Generating Networks for Zero-Shot Learning

# 用于零样本学习的特征生成网络

Yongqin Xian ${}^{1}\;$ Tobias Lorenz ${}^{1}$ Bernt Schiele ${}^{1}\;$ Zeynep Akata ${}^{1,2}$

咸永钦 ${}^{1}\;$ 托比亚斯·洛伦茨 ${}^{1}$ 伯恩特·席勒 ${}^{1}\;$ 泽内普·阿卡塔 ${}^{1,2}$

${}^{1}$ Max Planck Institute for Informatics

${}^{1}$ 马克斯·普朗克信息研究所

Saarland Informatics Campus

萨尔兰信息学园区

${}^{2}$ Amsterdam Machine Learning Lab University of Amsterdam

${}^{2}$ 阿姆斯特丹大学阿姆斯特丹机器学习实验室

## Abstract

## 摘要

Suffering from the extreme training data imbalance between seen and unseen classes, most of existing state-of-the-art approaches fail to achieve satisfactory results for the challenging generalized zero-shot learning task. To circumvent the need for labeled examples of unseen classes, we propose a novel generative adversarial network (GAN) that synthesizes CNN features conditioned on class-level semantic information, offering a shortcut directly from a semantic descriptor of a class to a class-conditional feature distribution. Our proposed approach, pairing a Wasserstein GAN with a classification loss, is able to generate sufficiently discriminative CNN features to train softmax classifiers or any multimodal embedding method. Our experimental results demonstrate a significant boost in accuracy over the state of the art on five challenging datasets - CUB, FLO, SUN, AWA and ImageNet - in both the zero-shot learning and generalized zero-shot learning settings.

由于已见类别和未见类别之间的训练数据极度不平衡，大多数现有的先进方法在具有挑战性的广义零样本学习任务中未能取得令人满意的结果。为了避免对未见类别的标注示例的需求，我们提出了一种新颖的生成对抗网络(GAN)，该网络基于类别级语义信息合成卷积神经网络(CNN)特征，提供了一条从类别的语义描述符直接到类别条件特征分布的捷径。我们提出的方法将瓦瑟斯坦生成对抗网络(Wasserstein GAN)与分类损失相结合，能够生成足够具有判别性的CNN特征，用于训练softmax分类器或任何多模态嵌入方法。我们的实验结果表明，在五个具有挑战性的数据集——加州大学圣地亚哥分校鸟类数据集(CUB)、花卉数据集(FLO)、场景数据集(SUN)、动物属性数据集(AWA)和图像网(ImageNet)——上，无论是在零样本学习还是广义零样本学习设置下，与现有技术相比，准确率都有显著提升。

## 1. Introduction

## 1. 引言

Deep learning has allowed to push performance considerably across a wide range of computer vision and machine learning tasks. However, almost always, deep learning requires large amounts of training data which we are lacking in many practical scenarios, e.g. it is impractical to annotate all the concepts that surround us, and have enough of those annotated samples to train a deep network. Therefore, training data generation has become a hot research topic [10, 18, 11, 37, 48, 41]. Generative Adversarial Networks [18] are particularly appealing as they allow generating realistic and sharp images conditioned, for instance, on object categories [37, 48]. However, they do not yet generate images of sufficient quality to train deep learning architectures as demonstrated by our experimental results.

深度学习使得计算机视觉和机器学习的广泛任务的性能得到了显著提升。然而，几乎在所有情况下，深度学习都需要大量的训练数据，而在许多实际场景中我们缺乏这些数据。例如，对我们周围的所有概念进行标注是不切实际的，并且没有足够的标注样本用于训练深度网络。因此，训练数据生成已成为一个热门的研究课题 [10, 18, 11, 37, 48, 41]。生成对抗网络 [18] 特别有吸引力，因为它们允许例如基于对象类别生成逼真且清晰的图像 [37, 48]。然而，正如我们的实验结果所示，它们生成的图像质量还不足以训练深度学习架构。

In this work, we are focusing on arguably the most extreme case of lacking data, namely zero-shot learning [24] 46, 9], where the task is to learn to classify when no labeled examples of certain classes are available during training.

在这项工作中，我们关注的是可以说是最极端的数据缺乏情况，即零样本学习 [24, 46, 9]，其任务是在训练期间没有某些类别的标注示例时学习进行分类。

![0195e097-4abd-7730-9e4b-20e256ec53e4_0_903_651_704_264_0.jpg](images/0195e097-4abd-7730-9e4b-20e256ec53e4_0_903_651_704_264_0.jpg)

Figure 1: CNN features can be extracted from: 1) real images, however in zero-shot learning we do not have access to any real images of unseen classes, 2) synthetic images, however they are not accurate enough to improve image classification performance. We tackle both of these problems and propose a novel attribute conditional feature generating adversarial network formulation, i.e. f-CLSWGAN, to generate CNN features of unseen classes.

图1:CNN特征可以从以下来源提取:1) 真实图像，但在零样本学习中，我们无法获取未见类别的任何真实图像；2) 合成图像，但它们的准确性不足以提高图像分类性能。我们解决了这两个问题，并提出了一种新颖的属性条件特征生成对抗网络公式，即f - CLSWGAN，用于生成未见类别的CNN特征。

We argue that this scenario is a great testbed for evaluating the robustness and generalization of generative models. In particular, if the generator learns discriminative visual data with enough variation, the generated data should be useful for supervised learning. Hence, one contribution of our paper is a comparison of various existing GAN-models and another competing generative model, i.e. GMMN, for visual feature generation. In particular, we look into both zero-shot learning (ZSL) where the test time search space is restricted to unseen class labels and generalized zero-shot learning (GZSL) for being a more realistic scenario as at test time the classifier has to decide between both seen and unseen class labels. In this context, we propose a novel GAN-method - namely $f$ -CLSWGAN that generates features instead of images and is trained with a novel loss improving over alternative GAN-models.

我们认为这种情况是评估生成模型的鲁棒性和泛化能力的绝佳试验台。特别是，如果生成器学习到具有足够变化的判别性视觉数据，那么生成的数据应该对监督学习有用。因此，我们论文的一个贡献是对各种现有的GAN模型和另一种竞争生成模型，即高斯混合模型网络(GMMN)，进行视觉特征生成的比较。特别是，我们研究了零样本学习(ZSL)，其中测试时的搜索空间仅限于未见类别标签，以及广义零样本学习(GZSL)，这是一个更现实的场景，因为在测试时分类器必须在已见和未见类别标签之间做出决策。在这种情况下，我们提出了一种新颖的GAN方法——即 $f$ - CLSWGAN，它生成特征而不是图像，并使用一种新颖的损失函数进行训练，比其他GAN模型有所改进。

We summarize our contributions as follows. (1) We propose a novel conditional generative model f-CLSWGAN that synthesizes CNN features of unseen classes by optimizing the Wasserstein distance regularized by a classification loss. (2) Across five datasets with varying granularity and sizes, we consistently improve upon the state of the art in both the ZSL and GZSL settings. We demonstrate a practical application for adversarial training and propose GZSL as a proxy task to evaluate the performance of generative models. (3) Our model is generalizable to different deep CNN features, e.g. extracted from GoogleNet or ResNet, and may use different class-level auxiliary information, e.g. sentence, attribute, and word2vec embeddings.

我们将我们的贡献总结如下。(1) 我们提出了一种新颖的条件生成模型f - CLSWGAN，它通过优化由分类损失正则化的瓦瑟斯坦距离来合成未见类别的CNN特征。(2) 在五个具有不同粒度和规模的数据集上，我们在ZSL和GZSL设置下都持续改进了现有技术水平。我们展示了对抗训练的实际应用，并提出将GZSL作为评估生成模型性能的代理任务。(3) 我们的模型可以推广到不同的深度CNN特征，例如从谷歌网络(GoogleNet)或残差网络(ResNet)中提取的特征，并且可以使用不同的类别级辅助信息，例如句子、属性和词向量(word2vec)嵌入。

## 2. Related work

## 2. 相关工作

In this section we review some recent relevant literature on Generative Adversarial Networks, Zero-Shot Learning (ZSL) and Generalized Zero-Shot (GZSL) Learning.

在本节中，我们回顾一些关于生成对抗网络、零样本学习(ZSL)和广义零样本学习(GZSL)的近期相关文献。

Generative Adversarial Network. GAN [18] was originally proposed as a means of learning a generative model which captures an arbitrary data distribution, such as images, from a particular domain. The input to a generator network is a "noise" vector $z$ drawn from a latent distribution, such as a multivariate Gaussian. DCGAN [34] extends GAN by leveraging deep convolution neural networks and providing best practices for GAN training. [43] improves DCGAN by factorizing the image generation process into style and structure networks, InfoGAN [12] extends GAN by additionally maximizing the mutual information between interpretable latent variables and the generator distribution. GAN has also been extended to a conditional GAN by feeding the class label [29], sentence descriptions [36, 37, 48], into both the generator and discriminator. The theory of GAN is recently investigated in [4, 5, 19], where they show that the Jenson-Shannon divergence optimized by the original GAN leads to instability issues. To cure the unstable training issues of GANs, [5] proposes Wasserstein-GAN (WGAN), which optimizes an efficient approximation of the Wasserstein distance. While WGAN attains better theoretical properties than the original GAN, it still suffers from vanishing and exploding gradient problems due to weight clipping to enforce the 1-Lipschitz constraint on the discriminator. Hence, [19] proposes an improved version of WGAN enforcing the Lipschitz constraint through gradient penalty. Although those papers have demonstrated realistic looking images, they have not applied this idea to image feature generation.

生成对抗网络(Generative Adversarial Network，GAN)[18]最初被提出作为一种学习生成模型的方法，该模型可以捕捉特定领域的任意数据分布，如图像。生成器网络的输入是一个从潜在分布(如多元高斯分布)中抽取的“噪声”向量 $z$。深度卷积生成对抗网络(Deep Convolutional GAN，DCGAN)[34]通过利用深度卷积神经网络并为GAN训练提供最佳实践来扩展GAN。文献[43]通过将图像生成过程分解为风格和结构网络来改进DCGAN；信息生成对抗网络(InfoGAN)[12]通过额外最大化可解释潜在变量与生成器分布之间的互信息来扩展GAN。GAN还通过将类别标签[29]、句子描述[36, 37, 48]输入到生成器和判别器中扩展为条件GAN。最近，文献[4, 5, 19]对GAN的理论进行了研究，表明原始GAN优化的詹森 - 香农散度会导致不稳定问题。为了解决GAN训练不稳定的问题，文献[5]提出了瓦瑟斯坦生成对抗网络(Wasserstein - GAN，WGAN)，它优化了瓦瑟斯坦距离的有效近似。虽然WGAN比原始GAN具有更好的理论性质，但由于对判别器施加1 - 利普希茨约束而进行的权重裁剪，它仍然存在梯度消失和梯度爆炸的问题。因此，文献[19]提出了一种改进版的WGAN，通过梯度惩罚来施加利普希茨约束。尽管这些论文展示了逼真的图像，但它们并未将这一思想应用于图像特征生成。

In this paper, we empirically show that images generated by the state-of-the-art GAN [19] are not ready to be used as training data for learning a classifier. Hence, we propose a novel GAN architecture to directly generate CNN features that can be used to train a discriminative classifier for zero-shot learning. Combining the powerful WGAN [19] loss and a classification loss which enforces the generated features to be discriminative, our proposed GAN architecture improves the original GAN [18] by a large margin and has an edge over WGAN [19] thanks to our regularizer.

在本文中，我们通过实验表明，目前最先进的GAN[19]生成的图像还不能用作训练分类器的训练数据。因此，我们提出了一种新颖的GAN架构，用于直接生成卷积神经网络(Convolutional Neural Network，CNN)特征，这些特征可用于训练用于零样本学习的判别式分类器。结合强大的WGAN[19]损失和强制生成特征具有判别性的分类损失，我们提出的GAN架构在很大程度上改进了原始GAN[18]，并且由于我们的正则化器，比WGAN[19]更具优势。

ZSL and GZSL. In the zero-shot learning setting, the set of classes seen during training and evaluated during test are disjoint [22, 24, 25, 39, 47]. As supervised learning methods can not be employed for this task, [24, 39] proposed to solve it by solving related sub-problems. [50, 31, 8] learn unseen classes as a mixture of seen class proportions, and 2, 3, 14, 42, 45, 40, 16, 33, 1, 6, 17, 23] learn a compatibility between images and classes. On the other hand, instead of using only labeled data, [15, 38, 26] leverage unlabeled data from unseen classes in the transductive setting. While zero-shot learning has attracted a lot of attention, there has been little work [42, 9] in the more realistic generalized zero-shot learning setting, where both seen and unseen classes appear at test time.

零样本学习(Zero - Shot Learning，ZSL)和广义零样本学习(Generalized Zero - Shot Learning，GZSL)。在零样本学习设置中，训练期间看到的类别集和测试期间评估的类别集是不相交的[22, 24, 25, 39, 47]。由于监督学习方法不能用于此任务，文献[24, 39]提出通过解决相关子问题来解决该问题。文献[50, 31, 8]将未见类别学习为所见类别比例的混合；文献[2, 3, 14, 42, 45, 40, 16, 33, 1, 6, 17, 23]学习图像和类别之间的兼容性。另一方面，文献[15, 38, 26]在直推式设置中不仅使用有标签数据，还利用未见类别的无标签数据。虽然零样本学习引起了很多关注，但在更现实的广义零样本学习设置(测试时同时出现所见和未见类别)方面的工作很少[42, 9]。

In this paper, we propose to tackle generalized zero-shot learning by generating CNN features for unseen classes via a novel GAN model. Our work is different from [20] because they generate additional examples for data-starved classes from feature vectors alone, which is unimodal and do not generalize to unseen classes. Our work is closer to [7] in which they generate features via GMMN [27]. Hence, we directly compare with them on the latest zero-shot learning benchmark [46] and show that WGAN [5] coupled with our proposed classification loss can further improve GMMN in feature generation on most datasets for both ZSL and GZSL tasks.

在本文中，我们提出通过一种新颖的GAN模型为未见类别生成CNN特征来解决广义零样本学习问题。我们的工作与文献[20]不同，因为他们仅从特征向量为数据匮乏的类别生成额外示例，这是单模态的，并且不能推广到未见类别。我们的工作与文献[7]更接近，他们通过高斯混合模型网络(Gaussian Mixture Model Network，GMMN)[27]生成特征。因此，我们在最新的零样本学习基准[46]上直接与他们进行比较，并表明WGAN[5]结合我们提出的分类损失可以在大多数数据集上进一步改进GMMN在ZSL和GZSL任务的特征生成。

## 3. Feature Generation & Classification in ZSL

## 3. 零样本学习中的特征生成与分类

Existing ZSL models only see labeled data from seen classes during training biasing the predictions to seen classes. The main insight of our proposed model is that by feeding additional synthetic CNN features of unseen classes, the learned classifier will also explore the embedding space of unseen classes. Hence, the key to our approach is the ability to generate semantically rich CNN feature distributions conditioned on a class specific semantic vector e.g. attributes, without access to any images of that class. This alleviates the imbalance between seen and unseen classes, as there is no limit to the number of synthetic CNN features that our model can generate. It also allows to directly train a discriminative classifier, i.e. Softmax classifier, even for unseen classes.

现有的ZSL模型在训练期间仅看到来自所见类别的有标签数据，这会使预测偏向于所见类别。我们提出的模型的主要见解是，通过输入未见类别的额外合成CNN特征，学习到的分类器也将探索未见类别的嵌入空间。因此，我们方法的关键是能够在不访问某类别任何图像的情况下，基于特定类别的语义向量(如属性)生成语义丰富的CNN特征分布。这缓解了所见和未见类别之间的不平衡，因为我们的模型可以生成的合成CNN特征数量没有限制。它还允许直接训练判别式分类器，即Softmax分类器，即使是针对未见类别。

We begin by defining the problem of our interest. Let $\mathcal{S} = \left\{  {\left( {x, y, c\left( y\right) }\right)  \mid  x \in  \mathcal{X}, y \in  {\mathcal{Y}}^{s}, c\left( y\right)  \in  \mathcal{C}}\right\}$ where $\mathcal{S}$ stands for the training data of seen classes, $x \in  {\mathbb{R}}^{{d}_{x}}$ is the CNN features, $y$ denotes the class label in ${\mathcal{Y}}^{s} =$ $\left\{  {{y}_{1},\ldots ,{y}_{K}}\right\}$ consisting of $\mathrm{K}$ discrete seen classes, and $c\left( y\right)  \in  {\mathbb{R}}^{{d}_{c}}$ is the class embedding, e.g. attributes, of class $y$ that models the semantic relationship between classes. In addition, we have a disjoint class label set ${\mathcal{Y}}^{u} =$ $\left\{  {{u}_{1},\ldots ,{u}_{L}}\right\}$ of unseen classes, whose class embedding set $\mathcal{U} = \left\{  {\left( {u, c\left( u\right) }\right)  \mid  u \in  {\mathcal{Y}}^{u}, c\left( u\right)  \in  \mathcal{C}}\right\}$ is available but images and image features are missing. Given $\mathcal{S}$ and $\mathcal{U}$ , the task of ZSL is to learn a classifier ${f}_{zsl} : \mathcal{X} \rightarrow  {\mathcal{Y}}^{u}$ and in GZSL we learn a classifier ${f}_{gzsl} : \mathcal{X} \rightarrow  {\mathcal{Y}}^{s} \cup  {\mathcal{Y}}^{u}$ .

我们首先定义我们感兴趣的问题。设 $\mathcal{S} = \left\{  {\left( {x, y, c\left( y\right) }\right)  \mid  x \in  \mathcal{X}, y \in  {\mathcal{Y}}^{s}, c\left( y\right)  \in  \mathcal{C}}\right\}$，其中 $\mathcal{S}$ 表示已见类别的训练数据，$x \in  {\mathbb{R}}^{{d}_{x}}$ 是卷积神经网络(CNN)特征，$y$ 表示 ${\mathcal{Y}}^{s} =$ $\left\{  {{y}_{1},\ldots ,{y}_{K}}\right\}$ 中的类别标签，该集合由 $\mathrm{K}$ 个离散的已见类别组成，并且 $c\left( y\right)  \in  {\mathbb{R}}^{{d}_{c}}$ 是类别 $y$ 的类别嵌入(例如属性)，用于对类别之间的语义关系进行建模。此外，我们有一个不相交的未见类别标签集 ${\mathcal{Y}}^{u} =$ $\left\{  {{u}_{1},\ldots ,{u}_{L}}\right\}$，其类别嵌入集 $\mathcal{U} = \left\{  {\left( {u, c\left( u\right) }\right)  \mid  u \in  {\mathcal{Y}}^{u}, c\left( u\right)  \in  \mathcal{C}}\right\}$ 是可用的，但图像和图像特征缺失。给定 $\mathcal{S}$ 和 $\mathcal{U}$，零样本学习(ZSL)的任务是学习一个分类器 ${f}_{zsl} : \mathcal{X} \rightarrow  {\mathcal{Y}}^{u}$，而在广义零样本学习(GZSL)中，我们学习一个分类器 ${f}_{gzsl} : \mathcal{X} \rightarrow  {\mathcal{Y}}^{s} \cup  {\mathcal{Y}}^{u}$。

### 3.1. Feature Generation

### 3.1. 特征生成

In this section, we begin our discussion with Generative Adversarial Networks (GAN) [18] for it being the basis of our model. GAN consists of a generative network $G$ and a discriminative network $D$ that compete in a two player minimax game. In the context of generating image pixels, $D$ tries to accurately distinguish real images from generated images, while $G$ tries to fool the discriminator by generating images that are mistakable for real. Following [29], we extend GAN to conditional GAN by including a conditional variable to both $G$ and $D$ . In the following we give the details of the conditional GAN variants that we develop. Our novelty lies in that we develop three conditional GAN variants, i.e. f-GAN, f-WGAN and f-CLSWGAN, to generate image features rather than image pixels. It is worth noting that our models are only trained with seen class data $\mathcal{S}$ but can also generate image features of unseen classes.

在本节中，我们从生成对抗网络(GAN)[18]开始讨论，因为它是我们模型的基础。生成对抗网络由一个生成网络 $G$ 和一个判别网络 $D$ 组成，它们在一个二人极小极大博弈中相互竞争。在生成图像像素的背景下，$D$ 试图准确地区分真实图像和生成图像，而 $G$ 则试图通过生成可被误认为是真实图像的图像来欺骗判别器。遵循文献[29]，我们通过向 $G$ 和 $D$ 都加入一个条件变量，将生成对抗网络扩展为条件生成对抗网络。下面我们详细介绍我们开发的条件生成对抗网络变体。我们的创新之处在于，我们开发了三种条件生成对抗网络变体，即 f - GAN、f - WGAN 和 f - CLSWGAN，用于生成图像特征而非图像像素。值得注意的是，我们的模型仅使用已见类别数据 $\mathcal{S}$ 进行训练，但也能生成未见类别的图像特征。

f-GAN. Given the train data $\mathcal{S}$ of seen classes, we aim to learn a conditional generator $G : \mathcal{Z} \times  \mathcal{C} \rightarrow  \mathcal{X}$ , which takes random Gaussian noise $z \in  \mathcal{Z} \subset  {\mathbb{R}}^{{d}_{z}}$ and class embedding $c\left( y\right)  \in  \mathcal{C}$ as its inputs, and outputs a CNN image feature $\widetilde{x} \in$ $\mathcal{X}$ of class $y$ . Once the generator $G$ learns to generate CNN features of real images, i.e. $x$ , conditioned on the seen class embedding $c\left( y\right)  \in  {\mathcal{Y}}^{s}$ , it can also generate $\widetilde{x}$ of any unseen class $u$ via its class embedding $c\left( u\right)$ . Our feature generator f-GAN is learned by optimizing the following objective,

f - GAN。给定已见类别的训练数据 $\mathcal{S}$，我们的目标是学习一个条件生成器 $G : \mathcal{Z} \times  \mathcal{C} \rightarrow  \mathcal{X}$，它将随机高斯噪声 $z \in  \mathcal{Z} \subset  {\mathbb{R}}^{{d}_{z}}$ 和类别嵌入 $c\left( y\right)  \in  \mathcal{C}$ 作为输入，并输出类别 $y$ 的卷积神经网络图像特征 $\widetilde{x} \in$ $\mathcal{X}$。一旦生成器 $G$ 学会在已见类别嵌入 $c\left( y\right)  \in  {\mathcal{Y}}^{s}$ 的条件下生成真实图像的卷积神经网络特征，即 $x$，它也可以通过未见类别 $u$ 的类别嵌入 $c\left( u\right)$ 生成其特征 $\widetilde{x}$。我们的特征生成器 f - GAN 通过优化以下目标函数来学习。

$$
\mathop{\min }\limits_{G}\mathop{\max }\limits_{D}{\mathcal{L}}_{GAN} = E\left\lbrack  {\log D\left( {x, c\left( y\right) }\right) }\right\rbrack   +  \tag{1}
$$

$$
E\left\lbrack  {\log \left( {1 - D\left( {\widetilde{x}, c\left( y\right) }\right) }\right) }\right\rbrack  \text{,}
$$

with $\widetilde{x} = G\left( {z, c\left( y\right) }\right)$ . The discriminator $D : \mathcal{X} \times  \mathcal{C} \rightarrow$ $\left\lbrack  {0,1}\right\rbrack$ is a multi-layer perceptron with a sigmoid function as the last layer. While $D$ tries to maximize the loss, $G$ tries to minimizes it. Although GAN has been shown to capture complex data distributions, e.g. pixel images, they are notoriously difficult to train [4].

使用 $\widetilde{x} = G\left( {z, c\left( y\right) }\right)$ 。判别器 $D : \mathcal{X} \times  \mathcal{C} \rightarrow$ $\left\lbrack  {0,1}\right\rbrack$ 是一个多层感知器，最后一层使用 sigmoid 函数。当 $D$ 试图最大化损失时，$G$ 试图最小化损失。尽管生成对抗网络(GAN)已被证明能够捕捉复杂的数据分布，例如像素图像，但众所周知，它们很难训练 [4]。

f-WGAN. We extend the improved WGAN [19] to a conditional WGAN by integrating the class embedding $c\left( y\right)$ to both the generator and the discriminator. The loss is,

f - WGAN。我们通过将类别嵌入 $c\left( y\right)$ 集成到生成器和判别器中，将改进的 Wasserstein 生成对抗网络(WGAN)[19] 扩展为条件 WGAN。损失函数为:

$$
{\mathcal{L}}_{WGAN} = E\left\lbrack  {D\left( {x, c\left( y\right) }\right) }\right\rbrack   - E\left\lbrack  {D\left( {\widetilde{x}, c\left( y\right) }\right) }\right\rbrack   -  \tag{2}
$$

$$
{\lambda E}\left\lbrack  {\left( {\begin{Vmatrix}{\nabla }_{\widehat{x}}D\left( \widehat{x}, c\left( y\right) \right) \end{Vmatrix}}_{2} - 1\right) }^{2}\right\rbrack  ,
$$

where $\widetilde{x} = G\left( {z, c\left( y\right) }\right) ,\widehat{x} = {\alpha x} + \left( {1 - \alpha }\right) \widetilde{x}$ with $\alpha  \sim$ $U\left( {0,1}\right)$ , and $\lambda$ is the penalty coefficient. In contrast to the GAN, the discriminative network here is defined as $D : \mathcal{X} \times$ $\mathcal{C} \rightarrow  \mathbb{R}$ , which eliminates the sigmoid layer and outputs a real value. The log in Equation 1 is also removed since we are not optimizing the log likelihood. Instead, the first two terms in Equation 2 approximate the Wasserstein distance, and the third term is the gradient penalty which enforces the gradient of $\mathrm{D}$ to have unit norm along the straight line

其中 $\widetilde{x} = G\left( {z, c\left( y\right) }\right) ,\widehat{x} = {\alpha x} + \left( {1 - \alpha }\right) \widetilde{x}$ 满足 $\alpha  \sim$ $U\left( {0,1}\right)$ ，并且 $\lambda$ 是惩罚系数。与生成对抗网络(GAN)不同，这里的判别网络定义为 $D : \mathcal{X} \times$ $\mathcal{C} \rightarrow  \mathbb{R}$ ，它去掉了 sigmoid 层并输出一个实值。由于我们不是在优化对数似然，所以公式 1 中的对数也被去掉了。相反，公式 2 中的前两项近似于 Wasserstein 距离，第三项是梯度惩罚项，它强制 $\mathrm{D}$ 的梯度在真实点和生成点对之间的直线上具有单位范数

![0195e097-4abd-7730-9e4b-20e256ec53e4_2_908_201_700_318_0.jpg](images/0195e097-4abd-7730-9e4b-20e256ec53e4_2_908_201_700_318_0.jpg)

Figure 2: Our $\mathrm{f} - \mathrm{{CLSWGAN}}$ : we propose to minimize the classification loss over the generated features and the Wasserstein distance with gradient penalty.

图 2:我们的 $\mathrm{f} - \mathrm{{CLSWGAN}}$ :我们提议最小化生成特征上的分类损失以及带有梯度惩罚的 Wasserstein 距离。

between pairs of real and generated points. Again, we solve a minmax optimization problem,

在真实点和生成点对之间。同样，我们解决一个极小极大优化问题。

$$
\mathop{\min }\limits_{G}\mathop{\max }\limits_{D}{\mathcal{L}}_{WGAN} \tag{3}
$$

f-CLSWGAN. f-WGAN does not guarantee that the generated CNN features are well suited for training a discriminative classifier, which is our goal. We conjecture that this issue could be alleviated by encouraging the generator to construct features that can be correctly classified by a discriminative classifier trained on the input data. To this end, we propose to minimize the classification loss over the generated features in our novel $f$ -CLSWGAN formulation. We use the negative log likelihood,

f - CLSWGAN。f - WGAN 不能保证生成的卷积神经网络(CNN)特征适合训练一个判别分类器，而这正是我们的目标。我们推测，通过鼓励生成器构建能够被在输入数据上训练的判别分类器正确分类的特征，可以缓解这个问题。为此，我们在新颖的 $f$ - CLSWGAN 公式中提议最小化生成特征上的分类损失。我们使用负对数似然。

$$
{\mathcal{L}}_{CLS} =  - {E}_{\widetilde{x} \sim  {p}_{\widetilde{x}}}\left\lbrack  {\log P\left( {y \mid  \widetilde{x};\theta }\right) }\right\rbrack  , \tag{4}
$$

where $\widetilde{x} = G\left( {z, c\left( y\right) }\right) , y$ is the class label of $\widetilde{x}, P\left( {y \mid  \widetilde{x};\theta }\right)$ denotes the probability of $\widetilde{x}$ being predicted with its true class label $y$ . The conditional probability is computed by a linear softmax classifier parameterized by $\theta$ , which is pre-trained on the real features of seen classes. The classification loss can be thought of as a regularizer enforcing the generator to construct discriminative features. Our full objective then becomes,

其中 $\widetilde{x} = G\left( {z, c\left( y\right) }\right) , y$ 是 $\widetilde{x}, P\left( {y \mid  \widetilde{x};\theta }\right)$ 的类别标签，表示 $\widetilde{x}$ 被预测为其真实类别标签 $y$ 的概率。条件概率由一个以 $\theta$ 为参数的线性 softmax 分类器计算，该分类器在可见类别的真实特征上进行预训练。分类损失可以被视为一种正则化项，强制生成器构建判别特征。那么我们的完整目标变为:

$$
\mathop{\min }\limits_{G}\mathop{\max }\limits_{D}{\mathcal{L}}_{WGAN} + \beta {\mathcal{L}}_{CLS} \tag{5}
$$

where $\beta$ is a hyperparameter weighting the classifier.

其中 $\beta$ 是对分类器进行加权的超参数。

### 3.2. Classification

### 3.2. 分类

Given $c\left( u\right)$ of any unseen class $u \in  {\mathcal{Y}}^{u}$ , by resampling the noise $z$ and then recomputing $\widetilde{x} = G\left( {z, c\left( u\right) }\right)$ , arbitrarily many visual CNN features $\widetilde{x}$ can be synthesized. After repeating this feature generation process for every unseen class, we obtain a synthetic training set $\widetilde{\mathcal{U}} = \{ \left( {\widetilde{x}, u, c\left( u\right) }\right) \}$ . We then learn a classifier by training either a multimodal embedding model or a softmax classifier. Our generated features allow to train those methods on the combinations of real seen class data $\mathcal{S}$ and generated unseen class data $\widetilde{\mathcal{U}}$ .

给定任何未见类 $u \in  {\mathcal{Y}}^{u}$ 的 $c\left( u\right)$ ，通过对噪声 $z$ 进行重采样，然后重新计算 $\widetilde{x} = G\left( {z, c\left( u\right) }\right)$ ，可以合成任意数量的视觉卷积神经网络(CNN)特征 $\widetilde{x}$ 。对每个未见类重复这个特征生成过程后，我们得到一个合成训练集 $\widetilde{\mathcal{U}} = \{ \left( {\widetilde{x}, u, c\left( u\right) }\right) \}$ 。然后我们通过训练多模态嵌入模型或 softmax 分类器来学习一个分类器。我们生成的特征允许在真实可见类数据 $\mathcal{S}$ 和生成的未见类数据 $\widetilde{\mathcal{U}}$ 的组合上训练这些方法。

Multimodal Embedding. Many zero-shot learning approaches, e.g. ALE [2], DEVISE [14], SJE [3], ES-ZSL [40] and LATEM [45], learn a multimodal embedding between the image feature space $\mathcal{X}$ and the class embedding space $\mathcal{C}$ using seen classes data $\mathcal{S}$ . With our generated features, those methods can be trained with seen classes data $\mathcal{S}$ together with unseen classes data $\widetilde{\mathcal{U}}$ to learn a more robust classifier. The embedding model $F\left( {x, c\left( y\right) ;W}\right)$ , parameterized by $W$ , measures the compatibility score between any image feature $x$ and class embedding $c\left( y\right)$ pair. Given a query image feature $x$ , the classifier searches for the class embedding with the highest compatibility via:

多模态嵌入。许多零样本学习方法，例如ALE [2]、DEVISE [14]、SJE [3]、ES - ZSL [40]和LATEM [45]，利用已见类别数据 $\mathcal{S}$ 学习图像特征空间 $\mathcal{X}$ 和类别嵌入空间 $\mathcal{C}$ 之间的多模态嵌入。利用我们生成的特征，这些方法可以结合已见类别数据 $\mathcal{S}$ 和未见类别数据 $\widetilde{\mathcal{U}}$ 进行训练，以学习更鲁棒的分类器。由 $W$ 参数化的嵌入模型 $F\left( {x, c\left( y\right) ;W}\right)$ 衡量任意图像特征 $x$ 和类别嵌入 $c\left( y\right)$ 对之间的兼容性得分。给定一个查询图像特征 $x$，分类器通过以下方式搜索具有最高兼容性的类别嵌入:

$$
f\left( x\right)  = \mathop{\operatorname{argmax}}\limits_{y}F\left( {x, c\left( y\right) ;W}\right) , \tag{6}
$$

where in ZSL, $y \in  {\mathcal{Y}}^{u}$ and in GZSL, $y \in  {\mathcal{Y}}^{s} \cup  {\mathcal{Y}}^{u}$ .

其中在零样本学习(ZSL)中，$y \in  {\mathcal{Y}}^{u}$；在广义零样本学习(GZSL)中，$y \in  {\mathcal{Y}}^{s} \cup  {\mathcal{Y}}^{u}$。

Softmax. The standard softmax classifier minimizes the negative log likelihood loss,

Softmax(归一化指数函数)。标准的Softmax分类器最小化负对数似然损失。

$$
\mathop{\min }\limits_{\theta } - \frac{1}{\left| \mathcal{T}\right| }\mathop{\sum }\limits_{{\left( {x, y}\right)  \in  \mathcal{T}}}\log P\left( {y \mid  x;\theta }\right) , \tag{7}
$$

where $\theta  \in  {\mathbb{R}}^{{d}_{x} \times  N}$ is the weight matrix of a fully connected layer which maps the image feature $x$ to $N$ unnormalized probabilities with $N$ being the number of classes, and $P\left( {y \mid  x;\theta }\right)  = \frac{\exp \left( {{\theta }_{y}^{T}x}\right) }{\mathop{\sum }\limits_{i}^{N}\exp \left( {{\theta }_{i}^{T}x}\right) }$ . Depending on the task, $\mathcal{T} = \widetilde{\mathcal{U}}$ if it is ZSL and $\mathcal{T} = \mathcal{S} \cup  \widetilde{\mathcal{U}}$ if it is GZSL. The prediction function is:

其中 $\theta  \in  {\mathbb{R}}^{{d}_{x} \times  N}$ 是一个全连接层的权重矩阵，该全连接层将图像特征 $x$ 映射到 $N$ 个未归一化的概率，$N$ 为类别数量，且 $P\left( {y \mid  x;\theta }\right)  = \frac{\exp \left( {{\theta }_{y}^{T}x}\right) }{\mathop{\sum }\limits_{i}^{N}\exp \left( {{\theta }_{i}^{T}x}\right) }$。根据任务不同，如果是零样本学习(ZSL)则为 $\mathcal{T} = \widetilde{\mathcal{U}}$，如果是广义零样本学习(GZSL)则为 $\mathcal{T} = \mathcal{S} \cup  \widetilde{\mathcal{U}}$。预测函数为:

$$
f\left( x\right)  = \arg \mathop{\max }\limits_{y}P\left( {y \mid  x;\theta }\right) , \tag{8}
$$

where in ZSL, $y \in  {\mathcal{Y}}^{u}$ and in GZSL, $y \in  {\mathcal{Y}}^{s} \cup  {\mathcal{Y}}^{u}$ .

其中在零样本学习(ZSL)中，$y \in  {\mathcal{Y}}^{u}$；在广义零样本学习(GZSL)中，$y \in  {\mathcal{Y}}^{s} \cup  {\mathcal{Y}}^{u}$。

## 4. Experiments

## 4. 实验

First we detail our experimental protocol, then we present (1) our results comparing our framework with the state of the art for GZSL and ZSL tasks on four challenging datasets, (2) our analysis of f-xGAN 1 under different conditions, (3) our large-scale experiments on ImageNet and (4) our comparison of image and image feature generation.

首先，我们详细介绍我们的实验方案，然后展示(1)在四个具有挑战性的数据集上，将我们的框架与广义零样本学习(GZSL)和零样本学习(ZSL)任务的现有技术进行比较的结果；(2)在不同条件下对f - xGAN 1的分析；(3)在ImageNet上进行的大规模实验；(4)图像和图像特征生成的比较。

Datasets. Caltech-UCSD-Birds 200-2011 (CUB) [44], Oxford Flowers (FLO) [30] and SUN Attribute (SUN) [32] are all fine-grained datasets. CUB contains 11,788 images from 200 different types of birds annotated with 312 attributes. FLO dataset 8189 images from 102 different types of flowers without attribute annotations. However, for both CUB and FLO we use the fine-grained visual descriptions collected by [35]. SUN contains 14,340 images from 717 scenes annotated with 102 attributes. Finally, Animals with Attributes (AWA) [24] is a coarse-grained dataset with

数据集。加州理工学院 - 加州大学圣地亚哥分校鸟类200 - 2011数据集(Caltech - UCSD - Birds 200 - 2011，CUB)[44]、牛津花卉数据集(Oxford Flowers，FLO)[30]和SUN属性数据集(SUN Attribute，SUN)[32]均为细粒度数据集。CUB包含来自200种不同鸟类的11788张图像，这些图像标注了312个属性。FLO数据集包含来自102种不同花卉的8189张图像，没有属性标注。然而，对于CUB和FLO，我们使用了[35]收集的细粒度视觉描述。SUN包含来自717个场景的14340张图像，这些图像标注了102个属性。最后，动物属性数据集(Animals with Attributes，AWA)[24]是一个粗粒度数据集，

<table><tr><td>Dataset</td><td>att</td><td>stc</td><td>$\left| {\mathcal{Y}}^{s}\right|  + \left| {\mathcal{Y}}^{u}\right|$</td><td>$\left| {\mathcal{Y}}^{s}\right|$</td><td>$\left| {\mathcal{Y}}^{u}\right|$</td></tr><tr><td>CUB [44]</td><td>312</td><td>Y</td><td>200</td><td>100 + 50</td><td>50</td></tr><tr><td>FLO [30]</td><td>-</td><td>Y</td><td>102</td><td>${62} + {20}$</td><td>20</td></tr><tr><td>SUN [32]</td><td>102</td><td>$\mathrm{N}$</td><td>717</td><td>${580} + {65}$</td><td>72</td></tr><tr><td>AWA [24]</td><td>85</td><td>$\mathrm{N}$</td><td>50</td><td>${27} + {13}$</td><td>10</td></tr></table>

<table><tbody><tr><td>数据集</td><td>属性</td><td>句子</td><td>$\left| {\mathcal{Y}}^{s}\right|  + \left| {\mathcal{Y}}^{u}\right|$</td><td>$\left| {\mathcal{Y}}^{s}\right|$</td><td>$\left| {\mathcal{Y}}^{u}\right|$</td></tr><tr><td>加州大学圣地亚哥分校鸟类数据集(CUB [44])</td><td>312</td><td>Y</td><td>200</td><td>100 + 50</td><td>50</td></tr><tr><td>花卉数据集(FLO [30])</td><td>-</td><td>Y</td><td>102</td><td>${62} + {20}$</td><td>20</td></tr><tr><td>太阳场景数据集(SUN [32])</td><td>102</td><td>$\mathrm{N}$</td><td>717</td><td>${580} + {65}$</td><td>72</td></tr><tr><td>动物属性数据集(AWA [24])</td><td>85</td><td>$\mathrm{N}$</td><td>50</td><td>${27} + {13}$</td><td>10</td></tr></tbody></table>

Table 1: CUB, SUN, FLO, AWA datasets, in terms of number of attributes per class (att), sentences (stc), number of classes in training + validation $\left( {\mathcal{Y}}^{s}\right)$ and test classes $\left( {\mathcal{Y}}^{u}\right)$ .

表1:CUB、SUN、FLO、AWA数据集，涉及每类属性数量(att)、句子数量(stc)、训练 + 验证类数量 $\left( {\mathcal{Y}}^{s}\right)$ 和测试类数量 $\left( {\mathcal{Y}}^{u}\right)$。

30,475 images, 50 classes and 85 attributes. Statistics of the datasets are presented in Table 1. We use the zero-shot splits proposed by [46] for AWA, CUB and SUN insuring that none of the training classes are present in ImageNet [13] ${}^{2}$ , For FLO, we use the standard split provided by [35].

30475张图像、50个类别和85个属性。数据集的统计信息见表1。对于AWA、CUB和SUN，我们使用[46]提出的零样本分割方法，确保训练类均不在ImageNet [13] ${}^{2}$ 中；对于FLO，我们使用[35]提供的标准分割方法。

Features. As real CNN features, we extract 2048-dim top-layer pooling units of the 101-layered ResNet [21] from the entire image. We do not do any image pre-processing such as cropping or use any other data augmentation techniques. ResNet is pre-trained on ImageNet $1\mathrm{\;K}$ and not fine-tuned. As synthetic CNN features, we generate 2048-dim CNN features using our $\mathrm{f} - \mathrm{{xGAN}}$ model. As the class embedding, unless it is stated otherwise, we use per-class attributes for AWA (85-dim), CUB (312-dim) and SUN (102-dim). Furthermore, for CUB and Flowers, we extract 1024-dim character-based CNN-RNN [35] features from fine-grained visual descriptions (10 sentences per image). None of the ${\mathcal{Y}}^{u}$ sentences are seen during training the CNN-RNN. We build per-class sentences by averaging the CNN-RNN features that belong to the same class.

特征。作为真实的卷积神经网络(CNN)特征，我们从整个图像中提取101层残差网络(ResNet) [21] 的2048维顶层池化单元。我们不进行任何图像预处理，如裁剪，也不使用任何其他数据增强技术。ResNet在ImageNet $1\mathrm{\;K}$ 上进行预训练，不进行微调。作为合成的CNN特征，我们使用我们的 $\mathrm{f} - \mathrm{{xGAN}}$ 模型生成2048维的CNN特征。作为类别嵌入，除非另有说明，我们对AWA使用每类属性(85维)、对CUB使用每类属性(312维)、对SUN使用每类属性(102维)。此外，对于CUB和花卉数据集，我们从细粒度视觉描述(每张图像10个句子)中提取1024维基于字符的CNN - RNN [35] 特征。在训练CNN - RNN时，未见过任何 ${\mathcal{Y}}^{u}$ 句子。我们通过对属于同一类别的CNN - RNN特征求平均值来构建每类句子。

Evaluation Protocol. At test time, in the ZSL setting, the aim is to assign an unseen class label, i.e. ${\mathcal{Y}}^{u}$ to the test image and in GZSL setting, the search space includes both seen or unseen classes, i.e. ${\mathcal{Y}}^{s} \cup  {\mathcal{Y}}^{u}$ . We use the unified evaluation protocol proposed in [46]. In the ZSL setting, the average accuracy is computed independently for each class before dividing their cumulative sum by the number of classes; i.e., we measure average per-class top-1 accuracy (T1). In the GZSL setting, we compute average per-class top-1 accuracy on seen classes $\left( {\mathcal{Y}}^{s}\right)$ denoted as $\mathbf{s}$ , average per-class top-1 accuracy on unseen classes $\left( {\mathcal{Y}}^{u}\right)$ denoted as $\mathbf{u}$ and their harmonic mean, i.e. $H = 2 * \left( {\mathbf{s} * \mathbf{u}}\right) /\left( {\mathbf{s} + \mathbf{u}}\right)$ .

评估协议。在测试时，在零样本学习(ZSL)设置中，目标是为测试图像分配一个未见类标签，即 ${\mathcal{Y}}^{u}$；在广义零样本学习(GZSL)设置中，搜索空间包括已见和未见类别，即 ${\mathcal{Y}}^{s} \cup  {\mathcal{Y}}^{u}$。我们使用[46]中提出的统一评估协议。在ZSL设置中，先为每个类别独立计算平均准确率，然后将它们的累积和除以类别数量；即，我们测量每类平均top - 1准确率(T1)。在GZSL设置中，我们计算已见类别的每类平均top - 1准确率 $\left( {\mathcal{Y}}^{s}\right)$，记为 $\mathbf{s}$，未见类别的每类平均top - 1准确率 $\left( {\mathcal{Y}}^{u}\right)$，记为 $\mathbf{u}$，以及它们的调和平均值，即 $H = 2 * \left( {\mathbf{s} * \mathbf{u}}\right) /\left( {\mathbf{s} + \mathbf{u}}\right)$。

Implementation details. In all $\mathrm{f} - \mathrm{{xGAN}}$ models, both the generator and the discriminator are MLP with LeakyReLU activation. The generator consists of a single hidden layer with 4096 hidden units. Its output layer is ReLU because we aim to learn the top max-pooling units of ResNet-101. While the discriminator of $f$ -GAN has one hidden layer with 1024 hidden units in order to stabilize the GAN training, the discriminators of $f$ -WGAN and $f$ -CLSWGAN have one hidden layer with 4096 hidden units as WGAN [19] does not have instability issues thus a stronger discriminator can be applied here. We do not apply batch normalization our empirical evaluation showed a significant degradation of the accuracy when batch normalization is used. The noise $z$ is drawn from a unit Gaussian with the same dimensionality as the class embedding. We use $\lambda  = {10}$ as suggested in [19] and $\beta  = {0.01}$ across all the datasets.

实现细节。在所有 $\mathrm{f} - \mathrm{{xGAN}}$ 模型中，生成器和判别器均为具有LeakyReLU激活函数的多层感知机(MLP)。生成器由一个包含4096个隐藏单元的隐藏层组成。其输出层使用ReLU激活函数，因为我们的目标是学习ResNet - 101的顶层最大池化单元。$f$ - GAN的判别器有一个包含1024个隐藏单元的隐藏层，以稳定GAN训练；而 $f$ - WGAN和 $f$ - CLSWGAN的判别器有一个包含4096个隐藏单元的隐藏层，因为WGAN [19] 没有不稳定性问题，因此可以在此应用更强的判别器。我们不应用批量归一化，我们的实证评估表明，使用批量归一化时准确率会显著下降。噪声 $z$ 从与类别嵌入具有相同维度的单位高斯分布中抽取。我们使用[19]中建议的 $\lambda  = {10}$，并在所有数据集上使用 $\beta  = {0.01}$。

---

${}^{1}$ We denote our $\mathrm{f} - \mathrm{{GAN}},\mathrm{f} - \mathrm{{WGAN}},\mathrm{f} - \mathrm{{CLSWGAN}}$ as $\mathrm{f} - \mathrm{{xGAN}}$

${}^{1}$ 我们将我们的 $\mathrm{f} - \mathrm{{GAN}},\mathrm{f} - \mathrm{{WGAN}},\mathrm{f} - \mathrm{{CLSWGAN}}$ 表示为 $\mathrm{f} - \mathrm{{xGAN}}$

${}^{2}$ as ImageNet is used for pre-training the ResNet [21]

${}^{2}$ 因为ImageNet用于对ResNet [21] 进行预训练

---

<table><tr><td rowspan="3">Classifier</td><td rowspan="3">FG</td><td colspan="4">Zero-Shot Learning</td><td colspan="12">Generalized Zero-Shot Learning</td></tr><tr><td>CUB</td><td rowspan="2">FLO T1</td><td rowspan="2">SUN T1</td><td>AWA</td><td colspan="3">CUB</td><td colspan="3">FLO</td><td colspan="3">SUN</td><td colspan="3">AWA</td></tr><tr><td>T1</td><td>T1</td><td>$\mathbf{u}$</td><td>S</td><td>H</td><td>$\mathbf{u}$</td><td>S</td><td>H</td><td>$\mathbf{u}$</td><td>S</td><td>H</td><td>$\mathbf{u}$</td><td>S</td><td>H</td></tr><tr><td rowspan="2">DEVISE [14]</td><td>none</td><td>52.0</td><td>45.9</td><td>56.5</td><td>54.2</td><td>23.8</td><td>53.0</td><td>32.8</td><td>9.9</td><td>44.2</td><td>16.2</td><td>16.9</td><td>27.4</td><td>20.9</td><td>13.4</td><td>68.7</td><td>22.4</td></tr><tr><td>f-CLSWGAN</td><td>60.3</td><td>60.4</td><td>60.9</td><td>66.9</td><td>52.2</td><td>42.4</td><td>46.7</td><td>45.0</td><td>38.6</td><td>41.6</td><td>38.4</td><td>25.4</td><td>30.6</td><td>35.0</td><td>62.8</td><td>45.0</td></tr><tr><td rowspan="2">SJE 3</td><td>none</td><td>53.9</td><td>53.4</td><td>53.7</td><td>65.6</td><td>23.5</td><td>59.2</td><td>33.6</td><td>13.9</td><td>47.6</td><td>21.5</td><td>14.7</td><td>30.5</td><td>19.8</td><td>11.3</td><td>74.6</td><td>19.6</td></tr><tr><td>f-CLSWGAN</td><td>58.4</td><td>67.4</td><td>56.5</td><td>66.9</td><td>48.1</td><td>37.4</td><td>42.1</td><td>52.1</td><td>56.2</td><td>54.1</td><td>36.7</td><td>25.0</td><td>29.7</td><td>37.9</td><td>70.1</td><td>49.2</td></tr><tr><td rowspan="2">LATEM [45]</td><td>none</td><td>49.3</td><td>40.4</td><td>55.3</td><td>55.1</td><td>15.2</td><td>57.3</td><td>24.0</td><td>6.6</td><td>47.6</td><td>11.5</td><td>14.7</td><td>28.8</td><td>19.5</td><td>7.3</td><td>71.7</td><td>13.3</td></tr><tr><td>f-CLSWGAN</td><td>60.8</td><td>60.8</td><td>61.3</td><td>69.9</td><td>53.6</td><td>39.2</td><td>45.3</td><td>47.2</td><td>37.7</td><td>41.9</td><td>42.4</td><td>23.1</td><td>29.9</td><td>33.0</td><td>61.5</td><td>43.0</td></tr><tr><td rowspan="2">ESZSL [40]</td><td>none</td><td>53.9</td><td>51.0</td><td>54.5</td><td>58.2</td><td>12.6</td><td>63.8</td><td>21.0</td><td>11.4</td><td>56.8</td><td>19.0</td><td>11.0</td><td>27.9</td><td>15.8</td><td>6.6</td><td>75.6</td><td>12.1</td></tr><tr><td>f-CLSWGAN</td><td>54.7</td><td>54.3</td><td>54.0</td><td>63.9</td><td>36.8</td><td>50.9</td><td>43.2</td><td>25.3</td><td>69.2</td><td>37.1</td><td>27.8</td><td>20.4</td><td>23.5</td><td>31.1</td><td>72.8</td><td>43.6</td></tr><tr><td rowspan="2">ALE [2]</td><td>none</td><td>54.9</td><td>48.5</td><td>58.1</td><td>59.9</td><td>23.7</td><td>62.8</td><td>34.4</td><td>13.3</td><td>61.6</td><td>21.9</td><td>21.8</td><td>33.1</td><td>26.3</td><td>16.8</td><td>76.1</td><td>27.5</td></tr><tr><td>f-CLSWGAN</td><td>61.5</td><td>71.2</td><td>62.1</td><td>68.2</td><td>40.2</td><td>59.3</td><td>47.9</td><td>54.3</td><td>60.3</td><td>57.1</td><td>41.3</td><td>31.1</td><td>35.5</td><td>47.6</td><td>57.2</td><td>52.0</td></tr><tr><td rowspan="2">Softmax</td><td>none</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td></tr><tr><td>f-CLSWGAN</td><td>57.3</td><td>67.2</td><td>60.8</td><td>68.2</td><td>43.7</td><td>57.7</td><td>49.7</td><td>59.0</td><td>73.8</td><td>65.6</td><td>42.6</td><td>36.6</td><td>39.4</td><td>57.9</td><td>61.4</td><td>59.6</td></tr></table>

<table><tbody><tr><td rowspan="3">分类器</td><td rowspan="3">FG(原文未明确含义，保留英文)</td><td colspan="4">零样本学习</td><td colspan="12">广义零样本学习</td></tr><tr><td>CUB(原文未明确含义，保留英文)</td><td rowspan="2">FLO T1(原文未明确含义，保留英文)</td><td rowspan="2">SUN T1(原文未明确含义，保留英文)</td><td>AWA(原文未明确含义，保留英文)</td><td colspan="3">CUB(原文未明确含义，保留英文)</td><td colspan="3">FLO(原文未明确含义，保留英文)</td><td colspan="3">SUN(原文未明确含义，保留英文)</td><td colspan="3">AWA(原文未明确含义，保留英文)</td></tr><tr><td>T1</td><td>T1</td><td>$\mathbf{u}$</td><td>S</td><td>H</td><td>$\mathbf{u}$</td><td>S</td><td>H</td><td>$\mathbf{u}$</td><td>S</td><td>H</td><td>$\mathbf{u}$</td><td>S</td><td>H</td></tr><tr><td rowspan="2">DEVISE [14](原文未明确含义，保留英文)</td><td>无</td><td>52.0</td><td>45.9</td><td>56.5</td><td>54.2</td><td>23.8</td><td>53.0</td><td>32.8</td><td>9.9</td><td>44.2</td><td>16.2</td><td>16.9</td><td>27.4</td><td>20.9</td><td>13.4</td><td>68.7</td><td>22.4</td></tr><tr><td>f - CLSWGAN(原文未明确含义，保留英文)</td><td>60.3</td><td>60.4</td><td>60.9</td><td>66.9</td><td>52.2</td><td>42.4</td><td>46.7</td><td>45.0</td><td>38.6</td><td>41.6</td><td>38.4</td><td>25.4</td><td>30.6</td><td>35.0</td><td>62.8</td><td>45.0</td></tr><tr><td rowspan="2">SJE 3(原文未明确含义，保留英文)</td><td>无</td><td>53.9</td><td>53.4</td><td>53.7</td><td>65.6</td><td>23.5</td><td>59.2</td><td>33.6</td><td>13.9</td><td>47.6</td><td>21.5</td><td>14.7</td><td>30.5</td><td>19.8</td><td>11.3</td><td>74.6</td><td>19.6</td></tr><tr><td>f - CLSWGAN(原文未明确含义，保留英文)</td><td>58.4</td><td>67.4</td><td>56.5</td><td>66.9</td><td>48.1</td><td>37.4</td><td>42.1</td><td>52.1</td><td>56.2</td><td>54.1</td><td>36.7</td><td>25.0</td><td>29.7</td><td>37.9</td><td>70.1</td><td>49.2</td></tr><tr><td rowspan="2">LATEM [45](原文未明确含义，保留英文)</td><td>无</td><td>49.3</td><td>40.4</td><td>55.3</td><td>55.1</td><td>15.2</td><td>57.3</td><td>24.0</td><td>6.6</td><td>47.6</td><td>11.5</td><td>14.7</td><td>28.8</td><td>19.5</td><td>7.3</td><td>71.7</td><td>13.3</td></tr><tr><td>f - CLSWGAN(原文未明确含义，保留英文)</td><td>60.8</td><td>60.8</td><td>61.3</td><td>69.9</td><td>53.6</td><td>39.2</td><td>45.3</td><td>47.2</td><td>37.7</td><td>41.9</td><td>42.4</td><td>23.1</td><td>29.9</td><td>33.0</td><td>61.5</td><td>43.0</td></tr><tr><td rowspan="2">ESZSL [40](原文未明确含义，保留英文)</td><td>无</td><td>53.9</td><td>51.0</td><td>54.5</td><td>58.2</td><td>12.6</td><td>63.8</td><td>21.0</td><td>11.4</td><td>56.8</td><td>19.0</td><td>11.0</td><td>27.9</td><td>15.8</td><td>6.6</td><td>75.6</td><td>12.1</td></tr><tr><td>f - CLSWGAN(原文未明确含义，保留英文)</td><td>54.7</td><td>54.3</td><td>54.0</td><td>63.9</td><td>36.8</td><td>50.9</td><td>43.2</td><td>25.3</td><td>69.2</td><td>37.1</td><td>27.8</td><td>20.4</td><td>23.5</td><td>31.1</td><td>72.8</td><td>43.6</td></tr><tr><td rowspan="2">ALE [2](原文未明确含义，保留英文)</td><td>无</td><td>54.9</td><td>48.5</td><td>58.1</td><td>59.9</td><td>23.7</td><td>62.8</td><td>34.4</td><td>13.3</td><td>61.6</td><td>21.9</td><td>21.8</td><td>33.1</td><td>26.3</td><td>16.8</td><td>76.1</td><td>27.5</td></tr><tr><td>f - CLSWGAN(原文未明确含义，保留英文)</td><td>61.5</td><td>71.2</td><td>62.1</td><td>68.2</td><td>40.2</td><td>59.3</td><td>47.9</td><td>54.3</td><td>60.3</td><td>57.1</td><td>41.3</td><td>31.1</td><td>35.5</td><td>47.6</td><td>57.2</td><td>52.0</td></tr><tr><td rowspan="2">Softmax(原文未明确含义，保留英文)</td><td>无</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td></tr><tr><td>f - CLSWGAN(原文未明确含义，保留英文)</td><td>57.3</td><td>67.2</td><td>60.8</td><td>68.2</td><td>43.7</td><td>57.7</td><td>49.7</td><td>59.0</td><td>73.8</td><td>65.6</td><td>42.6</td><td>36.6</td><td>39.4</td><td>57.9</td><td>61.4</td><td>59.6</td></tr></tbody></table>

Table 2: ZSL measuring per-class average Top-1 accuracy (T1) on ${\mathcal{Y}}^{u}$ and GZSL measuring $\mathbf{u} = \mathrm{T}1$ on ${\mathcal{Y}}^{u},\mathbf{s} = \mathrm{T}1$ on ${\mathcal{Y}}^{s}$ , $\mathrm{H} =$ harmonic mean (FG=feature generator, none: no access to generated CNN features, hence softmax is not applicable). f-CLSWGAN significantly boosts both the ZSL and GZSL accuracy of all classification models on all four datasets.

表2:零样本学习(ZSL)衡量在 ${\mathcal{Y}}^{u}$ 上的每类平均Top-1准确率(T1)，广义零样本学习(GZSL)衡量在 ${\mathcal{Y}}^{u},\mathbf{s} = \mathrm{T}1$ 上的 $\mathbf{u} = \mathrm{T}1$，数据集为 ${\mathcal{Y}}^{s}$、$\mathrm{H} =$ 调和均值(FG=特征生成器，无:无法访问生成的卷积神经网络(CNN)特征，因此softmax不适用)。f-CLSWGAN显著提高了所有四个数据集上所有分类模型的ZSL和GZSL准确率。

### 4.1. Comparing with State-of-the-Art

### 4.1. 与现有技术比较

In a first set of experiments, we evaluate our $\mathrm{f} - \mathrm{{xGAN}}$ features in both the ZSL and GZSL settings on four challenging datasets: CUB, FLO, SUN and AWA. Unless it is stated otherwise, we use att for CUB, SUN, AWA and stc for FLO (as att are not available). We compare the effect of our feature generating $\mathrm{f} - \mathrm{{xGAN}}$ to 6 recent state-of-the-art methods [46].

在第一组实验中，我们在四个具有挑战性的数据集(CUB、FLO、SUN和AWA)上的ZSL和GZSL设置下评估我们的 $\mathrm{f} - \mathrm{{xGAN}}$ 特征。除非另有说明，我们对CUB、SUN、AWA使用属性(att)，对FLO使用语义主题向量(stc)(因为没有可用的属性)。我们将我们的特征生成 $\mathrm{f} - \mathrm{{xGAN}}$ 的效果与6种最近的现有技术方法进行比较[46]。

ZSL with f-CLSWGAN. We first provide ZSL results with our f-CLSWGAN in Table 2 (left). Here, the test-time search space is restricted to unseen classes ${\mathcal{Y}}^{u}$ . First, our f-CLSWGAN in all cases improves the state of the art that is obtained without feature generation. The overall accuracy improvement on CUB is from 54.9% to 61.5%, on FLO from 53.4% to 71.2%, on SUN from 58.1% to 62.1% and on AWA from 65.6% to 69.9%, i.e. all quite significant. Another observation is that feature generation is applicable to all the multimodal embedding models and softmax. These results demonstrate that indeed our $\mathrm{f} - \mathrm{{CLSWGAN}}$ generates generalizable and strong visual features of previously unseen classes.

使用f-CLSWGAN的零样本学习(ZSL)。我们首先在表2(左)中提供了使用我们的f-CLSWGAN的ZSL结果。在这里，测试时的搜索空间仅限于未见类别 ${\mathcal{Y}}^{u}$。首先，在所有情况下，我们的f-CLSWGAN都改进了在没有特征生成的情况下获得的现有技术水平。在CUB上的整体准确率从54.9%提高到61.5%，在FLO上从53.4%提高到71.2%，在SUN上从58.1%提高到62.1%，在AWA上从65.6%提高到69.9%，即所有提升都相当显著。另一个观察结果是，特征生成适用于所有多模态嵌入模型和softmax。这些结果表明，我们的 $\mathrm{f} - \mathrm{{CLSWGAN}}$ 确实生成了先前未见类别的可泛化且强大的视觉特征。

GZSL with f-CLSWGAN. Our main interest is GZSL where the test time search space contains both seen and unseen classes, ${\mathcal{Y}}^{s} \cup  {\mathcal{Y}}^{u}$ , and at test time the images come both from seen and unseen classes. Therefore, we evaluate both seen and unseen class accuracy, i.e. $\mathbf{s}$ and $\mathbf{u}$ , as well as their harmonic mean (H). The GZSL results with f-CLSWGAN in Table 2 (right) demonstrate that for all datasets our $\mathrm{f} - \mathrm{{xGAN}}$ significantly improves the $\mathrm{H}$ -measure over the state-of-the-art. On CUB, f-CLSWGAN obtains ${49.7}\%$ in $\mathrm{H}$ measure, significantly improving the state of the art (34.4%), on FLO it achieves 65.6% (vs. 21.9%), on SUN it reaches ${39.4}\%$ (vs. 26.3%), and on AWA it achieves ${59.6}\%$ (vs. 27.5%). The accuracy boost can be attributed to the strength of the $f$ -CLSWGAN generator learning to imitate CNN features of unseen classes although not having seen any real CNN features of these classes before.

使用f-CLSWGAN的广义零样本学习(GZSL)。我们的主要关注点是GZSL，其中测试时的搜索空间包含已见和未见类别 ${\mathcal{Y}}^{s} \cup  {\mathcal{Y}}^{u}$，并且在测试时，图像既来自已见类别也来自未见类别。因此，我们评估已见和未见类别的准确率，即 $\mathbf{s}$ 和 $\mathbf{u}$，以及它们的调和均值(H)。表2(右)中使用f-CLSWGAN的GZSL结果表明，对于所有数据集，我们的 $\mathrm{f} - \mathrm{{xGAN}}$ 显著提高了现有技术水平的 $\mathrm{H}$ 指标。在CUB上，f-CLSWGAN在 $\mathrm{H}$ 指标上获得 ${49.7}\%$，显著改进了现有技术水平(34.4%)，在FLO上达到65.6%(对比21.9%)，在SUN上达到 ${39.4}\%$(对比26.3%)，在AWA上达到 ${59.6}\%$(对比27.5%)。准确率的提升可归因于 $f$ -CLSWGAN生成器的强大能力，它学会了模仿未见类别的CNN特征，尽管之前从未见过这些类别的任何真实CNN特征。

We also observe that without feature generation on all models the seen class accuracy is significantly higher than unseen class accuracy, which indicates that many samples are incorrectly assigned to one of the seen classes. Feature generation through $f$ -CLSWGAN finds a balance between seen and unseen class accuracies by improving the unseen class accuracy while maintaining the accuracy on seen classes. Furthermore, we would like to emphasize that the simple softmax classifier beats all the models and is now applicable to GZSL thanks to our CNN feature generation. This shows the true potential and generalizability of feature generation to various tasks.

我们还观察到，在所有模型中，没有特征生成时，已见类别的准确率显著高于未见类别的准确率，这表明许多样本被错误地分配到了某个已见类别中。通过 $f$ -CLSWGAN进行特征生成，在提高未见类别准确率的同时保持已见类别准确率，从而在已见和未见类别准确率之间找到了平衡。此外，我们想强调的是，简单的softmax分类器击败了所有模型，并且由于我们的CNN特征生成，现在适用于GZSL。这显示了特征生成在各种任务中的真正潜力和可泛化性。

ZSL and GZSL with $f -$ xGAN. The generative model is an important component of our framework. Here, we evaluate all versions of our $f - x\mathrm{{GAN}}$ and $f - \mathrm{{GMMN}}$ for it being a strong alternative. We show ZSL and GZSL results of all classification models in Figure 3 . We selected CUB and FLO for them being fine-grained datasets, however we provide full numerical results and plots in the supplementary which shows that our observations hold across datasets. Our first observation is that for both ZSL and GZSL settings all generative models improve in all cases over "none" with no access to the synthetic CNN features. This applies to the GZSL setting and the difference between "none" and f-xGAN is strikingly significant. Our second observation is that our novel $f$ -CLSWGAN model is the best performing generative model in almost all cases for both datasets. Our final observation is that although $f$ -WGAN rarely performs lower than $f$ -GMMN, e.g. ESZL on FLO, our $f$ -CLSWGAN which uses a classification loss in the generator recovers from it and achieves the best result among all these generative models. We conclude from these experiments that generating CNN features to support the classifier when there is missing data is a technique that is flexible and strong.

使用 $f -$ xGAN 进行零样本学习(ZSL)和广义零样本学习(GZSL)。生成模型是我们框架的重要组成部分。在这里，我们评估了我们所有版本的 $f - x\mathrm{{GAN}}$ 和 $f - \mathrm{{GMMN}}$，因为它是一个强大的替代方案。我们在图 3 中展示了所有分类模型的 ZSL 和 GZSL 结果。我们选择了加州大学伯克利分校鸟类数据集(CUB)和花卉数据集(FLO)，因为它们是细粒度数据集，不过我们在补充材料中提供了完整的数值结果和图表，表明我们的观察结果适用于所有数据集。我们的第一个观察结果是，对于 ZSL 和 GZSL 设置，在所有情况下，所有生成模型都比“无”(即无法访问合成卷积神经网络特征)有所改进。这适用于 GZSL 设置，并且“无”和 f - xGAN 之间的差异非常显著。我们的第二个观察结果是，我们新颖的 $f$ - CLSWGAN 模型在几乎所有情况下，对于这两个数据集都是表现最好的生成模型。我们的最后一个观察结果是，尽管 $f$ - WGAN 的表现很少低于 $f$ - GMMN，例如在 FLO 数据集上的 ESZL 任务，但我们在生成器中使用分类损失的 $f$ - CLSWGAN 能够从中恢复，并在所有这些生成模型中取得了最佳结果。我们从这些实验中得出结论，在数据缺失时生成卷积神经网络特征来支持分类器是一种灵活且强大的技术。

![0195e097-4abd-7730-9e4b-20e256ec53e4_5_133_201_1460_354_0.jpg](images/0195e097-4abd-7730-9e4b-20e256ec53e4_5_133_201_1460_354_0.jpg)

Figure 3: Comparing $\mathrm{f} -  \times  \mathrm{{GAN}}$ versions with $\mathrm{f} - \mathrm{{GMMN}}$ as well as comparing multimodal embedding methods with softmax.

图 3:比较 $\mathrm{f} -  \times  \mathrm{{GAN}}$ 版本与 $\mathrm{f} - \mathrm{{GMMN}}$，以及比较多模态嵌入方法与 softmax。

![0195e097-4abd-7730-9e4b-20e256ec53e4_5_147_640_695_303_0.jpg](images/0195e097-4abd-7730-9e4b-20e256ec53e4_5_147_640_695_303_0.jpg)

Figure 4: Measuring the seen class accuracy of the classifier trained on generated features of seen classes w.r.t. the training epochs (with softmax).

图 4:测量在生成的可见类特征上训练的分类器相对于训练轮数(使用 softmax)的可见类准确率。

We notice that recently [49] has shown great performance on the old splits of AWA and CUB datasets. We compare our method with [49] using the same evaluation protocol as our paper, i.e same data splits and evaluation metrics. On AWA, in ZSL task, the comparison is 66.1% vs 69.9% (ours) and in GZSL task, it is 41.4% vs 59.6% (ours). On CUB, in ZSL task, the comparison is ${50.1}\%$ vs 61.5% (ours) and in GZSL task it is 29.2% vs 49.7% (ours).

我们注意到，最近文献 [49] 在动物属性数据集(AWA)和加州大学伯克利分校鸟类数据集(CUB)的旧划分上表现出色。我们使用与本文相同的评估协议，即相同的数据划分和评估指标，将我们的方法与文献 [49] 进行比较。在 AWA 数据集上，在 ZSL 任务中，比较结果为 66.1% 对 69.9%(我们的方法)；在 GZSL 任务中，比较结果为 41.4% 对 59.6%(我们的方法)。在 CUB 数据集上，在 ZSL 任务中，比较结果为 ${50.1}\%$ 对 61.5%(我们的方法)；在 GZSL 任务中，比较结果为 29.2% 对 49.7%(我们的方法)。

![0195e097-4abd-7730-9e4b-20e256ec53e4_5_907_641_685_300_0.jpg](images/0195e097-4abd-7730-9e4b-20e256ec53e4_5_907_641_685_300_0.jpg)

Figure 5: Increasing the number of generated $\mathrm{f} - \mathrm{{xGAN}}$ features wrt unseen class accuracy (with softmax) in ZSL.

图 5:在 ZSL 中，增加生成的 $\mathrm{f} - \mathrm{{xGAN}}$ 特征数量与未见类准确率(使用 softmax)的关系。

### 4.2. Analyzing $\mathrm{f} - \mathrm{{xGAN}}$ Under Different Conditions

### 4.2. 分析不同条件下的 $\mathrm{f} - \mathrm{{xGAN}}$

In this section, we analyze $f - \mathrm{{xGAN}}$ in terms of stability, generalization, CNN architecture used to extract real CNN features and the effect of class embeddings on two fine-grained datasets, namely CUB and FLO.

在本节中，我们从稳定性、泛化能力、用于提取真实卷积神经网络特征的卷积神经网络架构以及类嵌入对两个细粒度数据集(即 CUB 和 FLO)的影响等方面分析 $f - \mathrm{{xGAN}}$。

Stability and Generalization. We first analyze how well different generative models fit the seen class data used for training. Instead of using Parzen window-based log-likelihood [18] that is unstable, we train a softmax classifier with generated features of seen classes and report the classification accuracy on a held-out test set. Figure 4 shows the classification accuracy w.r.t the number of training epochs. On both datasets, we observe a stable training trend. On FLO, compared to the supervised classification accuracy obtained with real images, i.e. the upper bound marked with dashed line, $f$ -GAN remains quite weak even after convergence, which indicates that $f$ -GAN has underfitting issues. A strong alternative is $f$ -GMMN leads to a significant accuracy boost while our $f$ -WGAN and $f$ -CLSWGAN improve over $f$ -GMMN and almost reach the supervised upper bound.

稳定性和泛化能力。我们首先分析不同的生成模型对用于训练的可见类数据的拟合程度。我们没有使用不稳定的基于帕森窗的对数似然 [18]，而是使用生成的可见类特征训练一个 softmax 分类器，并报告在保留测试集上的分类准确率。图 4 显示了相对于训练轮数的分类准确率。在两个数据集上，我们都观察到了稳定的训练趋势。在 FLO 数据集上，与使用真实图像获得的监督分类准确率(即虚线标记的上限)相比，$f$ - GAN 即使在收敛后仍然相当弱，这表明 $f$ - GAN 存在欠拟合问题。一个强大的替代方案是 $f$ - GMMN，它显著提高了准确率，而我们的 $f$ - WGAN 和 $f$ - CLSWGAN 比 $f$ - GMMN 有所改进，并且几乎达到了监督上限。

After having established that our $\mathrm{f} - \mathrm{{xGAN}}$ leads to a stable training performance and generating highly descriptive features, we evaluate the generalization ability of the $f - {xGAN}$ generator to unseen classes. Using the pre-trained model, we generate CNN features of unseen classes. We then train a softmax classifier using these synthetic CNN features of unseen classes with real CNN features of seen classes. On the GZSL task, Figure 5 shows that increasing the number of generated features of unseen classes from 1 to 100 leads to a significant boost of accuracy, e.g. 28.2% to 56.5% on CUB and 37.9% to 66.5% on FLO. As in the case for generating seen class features, here the ordering is $f - \mathrm{{GAN}} < f - \mathrm{{WGAN}} < f - \mathrm{{GMMN}} < f - \mathrm{{CLSWGAN}}$ on $\mathrm{{CUB}}$ and $f - \mathrm{{GAN}} < f - \mathrm{{GMMN}} < f - \mathrm{{WGAN}} < f - \mathrm{{CLSWGAN}}$ on FLO. With these results, we argue that if the generative model can generalize well to previously unseen data distributions, e.g. perform well on GZSL task, they have practical use in a wide range of real-world applications. Hence, we propose to quantitatively evaluate the performance of generative models on the GZSL task.

在确定我们的 $\mathrm{f} - \mathrm{{xGAN}}$ 能够实现稳定的训练性能并生成具有高度描述性的特征之后，我们评估 $f - {xGAN}$ 生成器对未见类别(unseen classes)的泛化能力。利用预训练模型，我们生成未见类别的卷积神经网络(CNN)特征。然后，我们使用这些未见类别的合成 CNN 特征以及已见类别的真实 CNN 特征来训练一个 softmax 分类器。在广义零样本学习(GZSL)任务中，图 5 显示，将未见类别的生成特征数量从 1 增加到 100 会显著提高准确率，例如，在加州大学伯克利分校鸟类数据集(CUB)上从 28.2% 提高到 56.5%，在花卉数据集(FLO)上从 37.9% 提高到 66.5%。与生成已见类别特征的情况一样，这里的排序在 $f - \mathrm{{GAN}} < f - \mathrm{{WGAN}} < f - \mathrm{{GMMN}} < f - \mathrm{{CLSWGAN}}$ 上是 $\mathrm{{CUB}}$，在 FLO 上是 $f - \mathrm{{GAN}} < f - \mathrm{{GMMN}} < f - \mathrm{{WGAN}} < f - \mathrm{{CLSWGAN}}$。基于这些结果，我们认为，如果生成模型能够很好地泛化到先前未见的数据分布，例如在 GZSL 任务上表现良好，那么它们在广泛的现实应用中具有实际用途。因此，我们建议对生成模型在 GZSL 任务上的性能进行定量评估。

<table><tr><td>CNN</td><td>FG</td><td>$\mathbf{u}$</td><td>S</td><td>H</td></tr><tr><td rowspan="2">GoogLeNet</td><td>none</td><td>20.2</td><td>35.7</td><td>25.8</td></tr><tr><td>f-CLSWGAN</td><td>35.3</td><td>38.7</td><td>36.9</td></tr><tr><td rowspan="2">ResNet-101</td><td>none</td><td>23.7</td><td>62.8</td><td>34.4</td></tr><tr><td>f-CLSWGAN</td><td>43.7</td><td>57.7</td><td>49.7</td></tr></table>

<table><tbody><tr><td>卷积神经网络(Convolutional Neural Network)</td><td>FG(未明确通用译法，保留原文)</td><td>$\mathbf{u}$</td><td>S</td><td>H</td></tr><tr><td rowspan="2">谷歌网络(GoogLeNet)</td><td>无</td><td>20.2</td><td>35.7</td><td>25.8</td></tr><tr><td>f - 条件标签平滑生成对抗网络(f - Conditional Label Smoothing Generative Adversarial Network，推测，需结合具体场景)</td><td>35.3</td><td>38.7</td><td>36.9</td></tr><tr><td rowspan="2">残差网络 - 101(ResNet - 101)</td><td>无</td><td>23.7</td><td>62.8</td><td>34.4</td></tr><tr><td>f - 条件标签平滑生成对抗网络(f - Conditional Label Smoothing Generative Adversarial Network，推测，需结合具体场景)</td><td>43.7</td><td>57.7</td><td>49.7</td></tr></tbody></table>

Table 3: GZSL results with GoogLeNet vs ResNet-101 features on CUB (CNN: Deep Feature Encoder Network, FG: Feature Generator, $\mathbf{u} = \mathrm{T}1$ on ${\mathcal{Y}}^{u},\mathbf{s} = \mathrm{T}1$ on ${\mathcal{Y}}^{s},\mathrm{H} =$ harmonic mean, "none" $=$ no generated features).

表3:在加州理工学院鸟类数据集(CUB)上使用GoogLeNet与ResNet - 101特征的广义零样本学习(GZSL)结果(CNN:深度特征编码器网络，FG:特征生成器，$\mathbf{u} = \mathrm{T}1$ 在 ${\mathcal{Y}}^{u},\mathbf{s} = \mathrm{T}1$ 上 ${\mathcal{Y}}^{s},\mathrm{H} =$ 的调和均值，“无” $=$ 表示无生成特征)。

<table><tr><td>C</td><td>FG</td><td>$\mathbf{u}$</td><td>S</td><td>$\mathbf{H}$</td></tr><tr><td rowspan="2">Attribute (att)</td><td>none</td><td>23.7</td><td>62.8</td><td>34.4</td></tr><tr><td>f-CLSWGAN</td><td>43.7</td><td>57.7</td><td>49.7</td></tr><tr><td rowspan="2">Sentence (stc)</td><td>none</td><td>38.8</td><td>53.8</td><td>45.1</td></tr><tr><td>f-CLSWGAN</td><td>50.3</td><td>58.3</td><td>54.0</td></tr></table>

<table><tbody><tr><td>C</td><td>FG</td><td>$\mathbf{u}$</td><td>S</td><td>$\mathbf{H}$</td></tr><tr><td rowspan="2">属性 (att)</td><td>无</td><td>23.7</td><td>62.8</td><td>34.4</td></tr><tr><td>模糊条件标签平滑生成对抗网络 (f-CLSWGAN)</td><td>43.7</td><td>57.7</td><td>49.7</td></tr><tr><td rowspan="2">句子 (stc)</td><td>无</td><td>38.8</td><td>53.8</td><td>45.1</td></tr><tr><td>模糊条件标签平滑生成对抗网络 (f-CLSWGAN)</td><td>50.3</td><td>58.3</td><td>54.0</td></tr></tbody></table>

Table 4: GZSL results with conditioning $\mathrm{f} - \mathrm{{xGAN}}$ with $\mathrm{{st}}\mathrm{c}$ and att on CUB (C: Class embedding, FG: Feature Generator, $\mathbf{u} = \mathrm{T}1$ on ${\mathcal{Y}}^{u},\mathbf{s} = \mathrm{T}1$ on ${\mathcal{Y}}^{s},\mathrm{H} =$ harmonic mean, "none"= no generated features).

表4:在CUB数据集上使用条件 $\mathrm{f} - \mathrm{{xGAN}}$ 结合 $\mathrm{{st}}\mathrm{c}$ 和属性(att)的广义零样本学习(GZSL)结果(C:类别嵌入，FG:特征生成器， $\mathbf{u} = \mathrm{T}1$ 在 ${\mathcal{Y}}^{u},\mathbf{s} = \mathrm{T}1$ 在 ${\mathcal{Y}}^{s},\mathrm{H} =$ 的调和均值，“none”= 无生成特征)。

Effect of CNN Architectures. The aim of this study is to determine the effect of the deep CNN encoder that provides real features to our $\mathrm{f} - \mathrm{{xGAN}}$ discriminator. In Table 3, we first observe that with GoogLeNet features, the results are lower compared to the ones obtained with ResNet features. This indicates that ResNet features are stronger than GoogLeNet, which is expected. Besides, most importantly, with both CNN architectures we observe that our $\mathrm{f} - \mathrm{{xGAN}}$ outperforms the "none" by a large margin. Specifically, the accuracy increases from 25.8% to 36.9% for GoogleNet features and 34.4% to 49.7% for ResNet features. Those results are encouraging as they demonstrate that our $f - \mathrm{x}{GAN}$ is not limited to learning the distribution of ResNet-101 features, but also able to learn other feature distributions.

卷积神经网络(CNN)架构的影响。本研究的目的是确定为我们的 $\mathrm{f} - \mathrm{{xGAN}}$ 判别器提供真实特征的深度CNN编码器的影响。在表3中，我们首先观察到，与使用残差网络(ResNet)特征获得的结果相比，使用谷歌网络(GoogLeNet)特征的结果较低。这表明ResNet特征比GoogLeNet特征更强，这是预期之中的。此外，最重要的是，对于这两种CNN架构，我们观察到我们的 $\mathrm{f} - \mathrm{{xGAN}}$ 性能大幅优于“none”。具体而言，对于GoogLeNet特征，准确率从25.8%提高到36.9%；对于ResNet特征，准确率从34.4%提高到49.7%。这些结果令人鼓舞，因为它们表明我们的 $f - \mathrm{x}{GAN}$ 不限于学习ResNet - 101特征的分布，还能够学习其他特征分布。

Effect of Class Embeddings. The conditioning variable, i.e. class embedding, is an important component of our $f - {xGAN}$ . Therefore, we evaluate two different class em-beddings, per-class attributes (att) and per-class sentences (stc) on CUB as this is the only dataset that has both. In Table 4, we first observe that $f$ -CLSWGAN features generated with at $t$ not only lead to a significantly higher result (49.7% vs 34.4%), s and u are much more balanced (57.7% and ${43.7}\%$ vs. ${62.8}\%$ and ${23.7}\%$ ) compared to the state-of-the-art, i.e. "none". This is because generated CNN features help us explore the space of unseen classes whereas the state of the art learns to project images closer to seen class embeddings.

类别嵌入的影响。条件变量，即类别嵌入，是我们的 $f - {xGAN}$ 的一个重要组成部分。因此，我们在CUB数据集上评估了两种不同的类别嵌入，即每类属性(att)和每类句子(stc)，因为这是唯一同时具备这两种信息的数据集。在表4中，我们首先观察到，使用 $t$ 生成的 $f$ -CLSWGAN特征不仅带来了显著更高的结果(49.7%对34.4%)，而且与最先进的方法(即“none”)相比，已见类别(s)和未见类别(u)的表现更加平衡(57.7%和 ${43.7}\%$ 对 ${62.8}\%$ 和 ${23.7}\%$ )。这是因为生成的CNN特征有助于我们探索未见类别的空间，而最先进的方法则是学习将图像投影到更接近已见类别嵌入的位置。

![0195e097-4abd-7730-9e4b-20e256ec53e4_6_908_203_684_284_0.jpg](images/0195e097-4abd-7730-9e4b-20e256ec53e4_6_908_203_684_284_0.jpg)

Figure 6: ZSL and GZSL results on ImageNet (ZSL: T1 on ${\mathcal{Y}}^{u}$ , GZSL: T1 on ${\mathcal{Y}}^{u}$ ). The splits, ResNet features and Word2Vec are provided by [46]. "Ours" = feature generator: f-CLSWGAN, classifier: softmax.

图6:在ImageNet数据集上的零样本学习(ZSL)和广义零样本学习(GZSL)结果(ZSL:在 ${\mathcal{Y}}^{u}$ 上的T1，GZSL:在 ${\mathcal{Y}}^{u}$ 上的T1)。数据划分、ResNet特征和词向量(Word2Vec)由文献[46]提供。“Ours” = 特征生成器:f - CLSWGAN，分类器:softmax。

Finally, f-CLSWGAN features generated with per-class stc significantly improve results over att, achieving ${54.0}\%$ in H measure, and also leads to a notable $\mathbf{u}$ of ${50.3}\%$ without hurting $s\left( {{58.3}\% }\right)$ . This is due to the fact that stc leads to high quality features [35] reflecting the highly descriptive semantic content language entails and it shows that our $f$ -CLSWGAN is able to learn higher quality CNN features given a higher quality conditioning signal.

最后，使用每类句子(stc)生成的f - CLSWGAN特征在调和(H)度量上显著优于使用属性(att)生成的特征，达到了 ${54.0}\%$ ，并且在不损害 $s\left( {{58.3}\% }\right)$ 的情况下，使 ${50.3}\%$ 有了显著的 $\mathbf{u}$ 。这是因为stc能够生成高质量的特征[35]，反映了语言所蕴含的高度描述性语义内容，这表明我们的 $f$ -CLSWGAN在给定高质量的条件信号时，能够学习到更高质量的CNN特征。

### 4.3. Large-Scale Experiments

### 4.3. 大规模实验

Our large-scale experiments follow the same zero-shot data splits of [46] and serve two purposes. First, we show the generalizability of our approach by conducting ZSL and GZSL experiments on ImageNet [13] for it being the largest-scale single-label image dataset, i.e. with ${21}\mathrm{\;K}$ classes and ${14}\mathrm{M}$ images. Second, as ImageNet does not contain att, we use as a (weak) conditioning signal Word2Vec [28] to generate $f$ -CLSWGAN features. Figure 6 shows that softmax as a classifier obtains the state-of-the-art of ZSL and GZSL on ImageNet, significantly improving over ALE [2]. These results show that our $f$ -CLSWGAN is able to generate high quality CNN features also with Word2Vec as the class embedding.

我们的大规模实验遵循文献[46]的零样本数据划分，有两个目的。首先，我们通过在ImageNet[13]数据集上进行ZSL和GZSL实验来展示我们方法的泛化能力，因为它是最大规模的单标签图像数据集，即有 ${21}\mathrm{\;K}$ 个类别和 ${14}\mathrm{M}$ 张图像。其次，由于ImageNet不包含属性信息，我们使用词向量(Word2Vec)[28]作为(弱)条件信号来生成 $f$ -CLSWGAN特征。图6显示，使用softmax作为分类器在ImageNet上的ZSL和GZSL任务中达到了最先进的水平，显著优于自适应标签嵌入(ALE)方法[2]。这些结果表明，我们的 $f$ -CLSWGAN在使用Word2Vec作为类别嵌入时也能够生成高质量的CNN特征。

For ZSL, for instance, with the $2\mathrm{H}$ split "Ours" almost doubles the performance of ALE (5.38% to 10.00%) and in one of the extreme cases, e.g. with L1K split, the accuracy improves from 2.85% to 3.62%. For GZSL the same observations hold, i.e. the gap between ALE and "Ours" is 2.18 vs 4.38 with $2\mathrm{H}$ split and 1.21 vs 2.50 with $\mathrm{L}1\mathrm{\;K}$ split. Note that, [46] reports the highest results with SYNC [8] and "Ours" improves over SYNC as well, e.g. 9.26% vs ${10.00}\%$ with $2\mathrm{H}$ and ${3.23}\%$ vs ${3.56}\%$ with $\mathrm{L}1\mathrm{\;K}$ . With these results we emphasize that with a supervision as weak as a Word2Vec signal, our model is able to generate CNN features of unseen classes and operate at the ImageNet scale. This does not only hold for the ZSL setting which discards all the seen classes from the test-time search space assuming that the evaluated images will belong to one of the unseen classes. It also holds for the GZSL setting where no such assumption has been made. Our model generalizes to previously unseen classes even when the seen classes are included in the search space which is the most realistic setting for image classification.

例如，对于零样本学习(ZSL)，采用 $2\mathrm{H}$ 分割时，“我们的方法”几乎使ALE的性能提升了一倍(从5.38%提升到10.00%)，在一种极端情况下，例如采用L1K分割时，准确率从2.85%提高到3.62%。对于广义零样本学习(GZSL)，也有同样的情况，即采用 $2\mathrm{H}$ 分割时，ALE和“我们的方法”的差距为2.18对4.38，采用 $\mathrm{L}1\mathrm{\;K}$ 分割时为1.21对2.50。请注意，文献[46]报告了使用SYNC [8]方法取得的最高结果，而“我们的方法”也比SYNC有所改进，例如，采用 $2\mathrm{H}$ 分割时为9.26%对 ${10.00}\%$，采用 $\mathrm{L}1\mathrm{\;K}$ 分割时为 ${3.23}\%$ 对 ${3.56}\%$。通过这些结果，我们强调，仅使用像Word2Vec信号这样弱的监督，我们的模型就能生成未见类别的卷积神经网络(CNN)特征，并能在ImageNet规模上运行。这不仅适用于零样本学习(ZSL)设置，该设置在测试时的搜索空间中排除了所有已见类别，假设待评估图像属于未见类别之一。这也适用于广义零样本学习(GZSL)设置，该设置没有做出这样的假设。即使搜索空间中包含已见类别，我们的模型也能推广到先前未见的类别，这是图像分类最现实的设置。

CUB FLO

<table><tr><td>Generated Data</td><td>$\mathbf{u}$</td><td>S</td><td>$\mathbf{H}$</td><td>$\mathbf{u}$</td><td>S</td><td>$\mathbf{H}$</td></tr><tr><td>none</td><td>38.8</td><td>53.8</td><td>45.1</td><td>13.3</td><td>61.6</td><td>21.9</td></tr><tr><td>Image (with [48])</td><td>23.8</td><td>48.5</td><td>31.9</td><td>39.4</td><td>64.9</td><td>49.0</td></tr><tr><td>CNN feature (Ours)</td><td>50.3</td><td>58.3</td><td>54.0</td><td>59.0</td><td>73.8</td><td>65.6</td></tr></table>

<table><tbody><tr><td>生成的数据</td><td>$\mathbf{u}$</td><td>S</td><td>$\mathbf{H}$</td><td>$\mathbf{u}$</td><td>S</td><td>$\mathbf{H}$</td></tr><tr><td>无</td><td>38.8</td><td>53.8</td><td>45.1</td><td>13.3</td><td>61.6</td><td>21.9</td></tr><tr><td>图像(含 [48])</td><td>23.8</td><td>48.5</td><td>31.9</td><td>39.4</td><td>64.9</td><td>49.0</td></tr><tr><td>卷积神经网络特征(我们的方法)</td><td>50.3</td><td>58.3</td><td>54.0</td><td>59.0</td><td>73.8</td><td>65.6</td></tr></tbody></table>

Table 5: Summary Table ( $\mathbf{u} = \mathrm{T}1$ on ${\mathcal{Y}}^{u},\mathbf{s} = \mathrm{T}1$ accuracy on ${\mathcal{Y}}^{s},\mathrm{H} =$ harmonic mean, class embedding $=$ stc). "none": ALE with no generated features.

表5:总结表($\mathbf{u} = \mathrm{T}1$在${\mathcal{Y}}^{u},\mathbf{s} = \mathrm{T}1$准确率上，${\mathcal{Y}}^{s},\mathrm{H} =$调和均值，类别嵌入$=$ stc)。“无”:无生成特征的ALE。

### 4.4. Feature vs Image Generation

### 4.4. 特征生成与图像生成

As our main goal is solving the GZSL task which suffers from the lack of visual training examples, one naturally thinks that image generation serves the same purpose. Therefore, here we compare generating images and image features for the task of GZSL. We use the StackGAN [48] to generate ${256} \times  {256}$ images conditioned on sentences.

由于我们的主要目标是解决广义零样本学习(GZSL)任务，该任务面临视觉训练样本不足的问题，人们自然会认为图像生成也能达到同样的目的。因此，在这里我们比较了为GZSL任务生成图像和图像特征的效果。我们使用StackGAN [48]根据句子生成${256} \times  {256}$图像。

In Table 5, we compare GZSL results obtained with "none", i.e. with an ALE model trained on real images of seen classes, Image, i.e. image features extracted from ${256} \times  {256}$ synthetic images generated by StackGAN [48] and CNN feature, i.e. generated by our $f$ -CLSWGAN.

在表5中，我们比较了“无”(即使用在可见类别的真实图像上训练的ALE模型)、“图像”(即从StackGAN [48]生成的${256} \times  {256}$合成图像中提取的图像特征)和“CNN特征”(即由我们的$f$ -CLSWGAN生成的特征)的GZSL结果。

Between "none" and "Image", we observe that generating images of unseen classes improves the performance i.e. harmonic mean on FLO (49.0% for "Image" vs 21.9% for "none"), but hurts the performance on CUB (31.9% for "Image" vs 45.1% for "none"). This is because generating birds is a much harder task than generating flowers. Upon visual inspection, we have observed that although many images have an accurate visual appearance as birds or flowers, they lack the necessary discriminative details to be classified correctly and the generated images are not class-consistent. On the other hand, generating CNN features leads to a significant boost of accuracy, e.g. 54.0% on CUB and 65.6% on FLO which is clearly higher than having no generation, i.e. "none", and image generation.

在“无”和“图像”之间，我们观察到生成未见类别的图像提高了FLO上的性能(即调和均值，“图像”为49.0%，“无”为21.9%)，但损害了CUB上的性能(“图像”为31.9%，“无”为45.1%)。这是因为生成鸟类图像比生成花卉图像困难得多。通过视觉检查，我们发现虽然许多图像在视觉外观上准确地呈现为鸟类或花卉，但它们缺乏正确分类所需的必要判别细节，并且生成的图像在类别上不一致。另一方面，生成CNN特征显著提高了准确率，例如在CUB上达到54.0%，在FLO上达到65.6%，明显高于不进行生成(即“无”)和图像生成的情况。

We argue that image feature generation has the following advantages. First, the number of generated image features is limitless. Second, the image feature generation learns from compact invariant representations obtained by a deep network trained on a large-scale dataset such as ImageNet, therefore the feature generative network can be quite shallow and hence computationally efficient. Third, generated CNN features are highly discriminative, i.e. they lead to a significant boost in performance of both ZSL and GZSL. Finally, image feature generation is a much easier task as the generated data is much lower dimensional than high quality images necessary for discrimination.

我们认为图像特征生成具有以下优点。首先，生成的图像特征数量是无限的。其次，图像特征生成从在大规模数据集(如ImageNet)上训练的深度网络获得的紧凑不变表示中学习，因此特征生成网络可以很浅，从而计算效率高。第三，生成的CNN特征具有高度的判别性，即它们显著提高了零样本学习(ZSL)和广义零样本学习(GZSL)的性能。最后，图像特征生成是一项容易得多的任务，因为生成的数据维度远低于判别所需的高质量图像。

## 5. Conclusion

## 5. 结论

In this work, we propose $f - \mathrm{x}\mathrm{{GAN}}$ , a learning framework for feature generation followed by classification, to tackle the generalized zero-shot learning task. Our $f - \mathrm{x}$ GAN model adapts the conditional GAN architecture that is frequently used for generating image pixels to generate CNN features. In $f$ -CLSWGAN, we improve WGAN by adding a classification loss on top of the generator, enforcing it to generate features that are better suited for classification. In our experiments, we have shown that generating features of unseen classes allows us to effectively use softmax classifiers for the GZSL task.

在这项工作中，我们提出了$f - \mathrm{x}\mathrm{{GAN}}$，这是一个先进行特征生成然后进行分类的学习框架，用于解决广义零样本学习任务。我们的$f - \mathrm{x}$生成对抗网络(GAN)模型将常用于生成图像像素的条件GAN架构应用于生成CNN特征。在$f$ -CLSWGAN中，我们通过在生成器上添加分类损失来改进WGAN，强制其生成更适合分类的特征。在我们的实验中，我们表明生成未见类别的特征使我们能够有效地将softmax分类器用于GZSL任务。

Our framework is generalizable as it can be integrated to various deep CNN architectures, i.e. GoogleNet and ResNet as a pair of the most widely used architectures. It can also be deployed with various classifiers, e.g. ALE, SJE, DEVISE, LATEM, ESZSL that constitute the state of the art for ZSL but also the GZSL accuracy improvements obtained with softmax is important as it is a simple classifier that could not be used for GZSL before this work. Moreover, our features can be generated via different sources of class embeddings, e.g. Sentence, Attribute, Word2vec, and applied to different datasets, i.e. CUB, FLO, SUN, AWA being fine and coarse-grained ZSL datasets and ImageNet being a truly large-scale dataset.

我们的框架具有通用性，因为它可以集成到各种深度CNN架构中，例如GoogleNet和ResNet这两种最广泛使用的架构。它还可以与各种分类器一起部署，例如ALE、SJE、DEVISE、LATEM、ESZSL，这些分类器构成了ZSL的当前最优水平，但使用softmax获得的GZSL准确率提升也很重要，因为它是一个简单的分类器，在这项工作之前无法用于GZSL。此外，我们的特征可以通过不同的类别嵌入源(例如句子、属性、Word2vec)生成，并应用于不同的数据集，即CUB、FLO、SUN、AWA这些细粒度和粗粒度的ZSL数据集，以及ImageNet这个真正的大规模数据集。

Finally, based on the success of our framework, we motivated the use of GZSL tasks as an auxiliary method for evaluation of the expressive power of generative models in addition to manual inspection of generated image pixels which is tedious and prone to errors. For instance, WGAN [19] has been proposed and accepted as an improvement over GAN [18]. This claim is supported with evaluations based on manual inspection of the images and the inception score. Our observations in Figure 3 and in Figure 5 support this and follow the same ordering of the models, i.e. WGAN improves over GAN in ZSL and GZSL tasks. Hence, while not being the primary focus of this paper, we strongly argue, that ZSL and GZSL are suited well as a testbed for comparing generative models.

最后，基于我们框架的成功，我们提倡除了通过人工检查生成图像像素这种既繁琐又容易出错的方法之外，使用广义零样本学习(GZSL)任务作为评估生成模型表达能力的辅助方法。例如，沃尔什斯坦生成对抗网络(WGAN)[19]已被提出并被认为是对生成对抗网络(GAN)[18]的改进。这一论断得到了基于图像人工检查和初始得分的评估支持。我们在图3和图5中的观察结果支持这一点，并且模型的排序相同，即在零样本学习(ZSL)和广义零样本学习(GZSL)任务中，沃尔什斯坦生成对抗网络(WGAN)比生成对抗网络(GAN)有所改进。因此，虽然这不是本文的主要重点，但我们强烈认为，零样本学习(ZSL)和广义零样本学习(GZSL)非常适合作为比较生成模型的测试平台。

## References

## 参考文献

[1] Z. Akata, M. Malinowski, M. Fritz, and B. Schiele. Multi-cue zero-shot learning with strong supervision. In CVPR, 2016.

[1] Z. 阿卡塔、M. 马林诺夫斯基、M. 弗里茨和B. 席勒。具有强监督的多线索零样本学习。见《计算机视觉与模式识别会议(CVPR)》，2016年。

[2] Z. Akata, F. Perronnin, Z. Harchaoui, and C. Schmid. Label-embedding for image classification. TPAMI, 2016.

[2] Z. 阿卡塔、F. 佩罗宁、Z. 哈查维、C. 施密德。用于图像分类的标签嵌入。《模式分析与机器智能汇刊(TPAMI)》，2016年。

[3] Z. Akata, S. Reed, D. Walter, H. Lee, and B. Schiele. Evaluation of output embeddings for fine-grained image classification. In ${CVPR},{2015}$ .

[3] Z. 阿卡塔、S. 里德、D. 沃尔特、H. 李和B. 席勒。用于细粒度图像分类的输出嵌入评估。见 ${CVPR},{2015}$ 。

[4] M. Arjovsky and L. Bottou. Towards principled methods for training generative adversarial networks. ICLR, 2017.

[4] M. 阿乔夫斯基和L. 博图。迈向训练生成对抗网络的原则性方法。见《国际学习表征会议(ICLR)》，2017年。

[5] M. Arjovsky, S. Chintala, and L. Bottou. Wasserstein gan. ICML, 2017.

[5] M. 阿乔夫斯基、S. 钦塔拉和L. 博图。沃尔什斯坦生成对抗网络。见《国际机器学习会议(ICML)》，2017年。

[6] M. Bucher, S. Herbin, and F. Jurie. Improving semantic embedding consistency by metric learning for zero-shot classif-fication. In ${ECCV},{2016}$ .

[6] M. 布歇尔、S. 埃尔宾和F. 朱里。通过度量学习提高零样本分类的语义嵌入一致性。见 ${ECCV},{2016}$ 。

[7] M. Bucher, S. Herbin, and F. Jurie. Generating visual representations for zero-shot classification. arXiv preprint arXiv:1708.06975, 2017.

[7] M. 布歇尔、S. 埃尔宾和F. 朱里。为零样本分类生成视觉表示。预印本arXiv:1708.06975，2017年。

[8] S. Changpinyo, W.-L. Chao, B. Gong, and F. Sha. Synthesized classifiers for zero-shot learning. In CVPR, 2016.

[8] S. 张品耀、W.-L. 赵、B. 龚和F. 沙。用于零样本学习的合成分类器。见《计算机视觉与模式识别会议(CVPR)》，2016年。

[9] W.-L. Chao, S. Changpinyo, B. Gong, and F. Sha. An empirical study and analysis of generalized zero-shot learning for object recognition in the wild. In ${ECCV},{2016}$ .

[9] W.-L. 赵、S. 张品耀、B. 龚和F. 沙。对野外目标识别的广义零样本学习的实证研究与分析。见 ${ECCV},{2016}$ 。

[10] N. V. Chawla, K. W. Bowyer, L. O. Hall, and W. P. Kegelmeyer. Smote: synthetic minority over-sampling technique. Journal of artificial intelligence research, 2002.

[10] N. V. 查拉、K. W. 鲍耶、L. O. 霍尔和W. P. 凯格尔迈尔。SMOTE:合成少数过采样技术。《人工智能研究杂志》，2002年。

[11] Q. Chen and V. Koltun. Photographic image synthesis with cascaded refinement networks. In ${ICCV},{2017}$ .

[11] Q. 陈和V. 科尔图恩。使用级联细化网络进行摄影图像合成。见 ${ICCV},{2017}$ 。

[12] X. Chen, Y. Duan, R. Houthooft, J. Schulman, I. Sutskever, and P. Abbeel. Infogan: Interpretable representation learning by information maximizing generative adversarial nets. In NIPS, 2016.

[12] X. 陈、Y. 段、R. 胡托夫特、J. 舒尔曼、I. 苏茨克韦尔和P. 阿贝贝尔。InfoGAN:通过信息最大化生成对抗网络进行可解释表示学习。见《神经信息处理系统大会(NIPS)》，2016年。

[13] J. Deng, W. Dong, R. Socher, L.-J. Li, K. Li, and L. Fei-Fei. ImageNet: A Large-Scale Hierarchical Image Database. In CVPR, 2009.

[13] J. 邓、W. 董、R. 索切尔、L.-J. 李、K. 李和L. 费费。ImageNet:一个大规模分层图像数据库。见《计算机视觉与模式识别会议(CVPR)》，2009年。

[14] A. Frome, G. S. Corrado, J. Shlens, S. Bengio, J. Dean, M. A. Ranzato, and T. Mikolov. Devise: A deep visual-semantic embedding model. In NIPS, 2013.

[14] A. 弗罗姆、G. S. 科拉多、J. 什伦斯、S. 本吉奥、J. 迪恩、M. A. 兰扎托和T. 米科洛夫。DEVISE:一种深度视觉语义嵌入模型。见《神经信息处理系统大会(NIPS)》，2013年。

[15] Y. Fu, T. M. Hospedales, T. Xiang, Z. Fu, and S. Gong. Transductive multi-view zero-shot learning. TPAMI, 37, 2015.

[15] 傅宇(Y. Fu)、霍斯佩代尔斯(T. M. Hospedales)、向涛(T. Xiang)、傅智(Z. Fu)和龚少晖(S. Gong)。直推式多视图零样本学习。《模式分析与机器智能汇刊》(TPAMI)，37卷，2015年。

[16] Y. Fu and L. Sigal. Semi-supervised vocabulary-informed learning. In ${CVPR},{2016}$ .

[16] 傅宇(Y. Fu)和西加尔(L. Sigal)。半监督词汇感知学习。见 ${CVPR},{2016}$ 。

[17] Z. Fu, T. Xiang, E. Kodirov, and S. Gong. Zero-shot object recognition by semantic manifold distance. In CVPR, 2015.

[17] 傅智(Z. Fu)、向涛(T. Xiang)、科迪罗夫(E. Kodirov)和龚少晖(S. Gong)。基于语义流形距离的零样本目标识别。见《计算机视觉与模式识别会议》(CVPR)，2015年。

[18] I. Goodfellow, J. Pouget-Abadie, M. Mirza, B. Xu, D. Warde-Farley, S. Ozair, A. Courville, and Y. Bengio. Generative adversarial nets. In NIPS. 2014.

[18] 伊恩·古德费洛(I. Goodfellow)、让-皮埃尔·波杰-阿巴迪(J. Pouget-Abadie)、梅赫迪·米尔扎(M. Mirza)、徐冰(B. Xu)、大卫·沃德-法利(D. Warde-Farley)、谢伊·奥扎尔(S. Ozair)、亚伦·库维尔(A. Courville)和约书亚·本吉奥(Y. Bengio)。生成对抗网络。见《神经信息处理系统大会》(NIPS)，2014年。

[19] I. Gulrajani, F. Ahmed, M. Arjovsky, V. Dumoulin, and A. Courville. Improved training of wasserstein gans. arXiv preprint arXiv:1704.00028, 2017.

[19] 伊沙恩·古拉贾尼(I. Gulrajani)、法鲁克·艾哈迈德(F. Ahmed)、马丁·阿贾斯基(M. Arjovsky)、文森特·迪穆兰(V. Dumoulin)和亚伦·库维尔(A. Courville)。改进的Wasserstein生成对抗网络训练方法。预印本arXiv:1704.00028，2017年。

[20] B. Hariharan and R. Girshick. Low-shot visual recognition by shrinking and hallucinating features. ICCV, 2017.

[20] 巴拉特·哈里哈兰(B. Hariharan)和罗斯·吉里什克(R. Girshick)。通过特征收缩和幻觉实现少样本视觉识别。见《国际计算机视觉会议》(ICCV)，2017年。

[21] K. He, X. Zhang, S. Ren, and J. Sun. Deep residual learning for image recognition. In ${CVPR},{2016}$ .

[21] 何恺明(K. He)、张祥雨(X. Zhang)、任少卿(S. Ren)和孙剑(J. Sun)。用于图像识别的深度残差学习。见 ${CVPR},{2016}$ 。

[22] S. Huang, M. Elhoseiny, A. M. Elgammal, and D. Yang.

[22] 黄圣(S. Huang)、穆罕默德·埃尔霍塞尼(M. Elhoseiny)、阿卜杜勒-莫奈姆·埃尔加马尔(A. M. Elgammal)和杨迪(D. Yang)。

Learning hypergraph-regularized attribute predictors. In CVPR, 2015.

学习超图正则化属性预测器。见《计算机视觉与模式识别会议》(CVPR)，2015年。

[23] E. Kodirov, T. Xiang, Z. Fu, and S. Gong. Unsupervised domain adaptation for zero-shot learning. In ${ICCV},{2015}$ .

[23] 埃利尔·科迪罗夫(E. Kodirov)、向涛(T. Xiang)、傅智(Z. Fu)和龚少晖(S. Gong)。零样本学习的无监督域适应。见 ${ICCV},{2015}$ 。

[24] C. Lampert, H. Nickisch, and S. Harmeling. Attribute-based classification for zero-shot visual object categorization. In TPAMI, 2013.

[24] 克里斯托夫·兰佩特(C. Lampert)、汉斯·尼克施(H. Nickisch)和斯蒂芬·哈梅林(S. Harmeling)。基于属性的分类用于零样本视觉目标分类。见《模式分析与机器智能汇刊》(TPAMI)，2013年。

[25] H. Larochelle, D. Erhan, and Y. Bengio. Zero-data learning of new tasks. In ${AAAI},{2008}$ .

[25] 雨果·拉罗谢尔(H. Larochelle)、杜米特鲁·埃尔汉(D. Erhan)和约书亚·本吉奥(Y. Bengio)。新任务的零数据学习。见 ${AAAI},{2008}$ 。

[26] X. Li, Y. Guo, and D. Schuurmans. Semi-supervised zero-shot classification with label representation learning. In ICCV, 2015.

[26] 李翔(X. Li)、郭宇(Y. Guo)和戴尔·舒尔曼斯(D. Schuurmans)。通过标签表示学习进行半监督零样本分类。见《国际计算机视觉会议》(ICCV)，2015年。

[27] Y. Li, K. Swersky, and R. Zemel. Generative moment matching networks. In ${ICML},{2015}$ .

[27] 李毅(Y. Li)、凯文·斯沃尔斯基(K. Swersky)和理查德·泽梅尔(R. Zemel)。生成矩匹配网络。见 ${ICML},{2015}$ 。

[28] T. Mikolov, I. Sutskever, K. Chen, G. S. Corrado, and J. Dean. Distributed representations of words and phrases and their compositionality. In NIPS, 2013.

[28] 托马斯·米科洛夫(T. Mikolov)、伊利亚·苏茨克维(I. Sutskever)、凯·陈(K. Chen)、格雷格·S·科拉多(G. S. Corrado)和杰弗里·迪恩(J. Dean)。单词和短语的分布式表示及其组合性。见《神经信息处理系统大会》(NIPS)，2013年。

[29] M. Mirza and S. Osindero. Conditional generative adversarial nets. arXiv preprint arXiv:1411.1784, 2014.

[29] 梅赫迪·米尔扎(M. Mirza)和西蒙·奥辛德罗(S. Osindero)。条件生成对抗网络。预印本arXiv:1411.1784，2014年。

[30] M.-E. Nilsback and A. Zisserman. Automated flower classification over a large number of classes. In ICCVGI, 2008.

[30] M.-E. 尼尔兹巴克(M.-E. Nilsback)和 A. 齐瑟曼(A. Zisserman)。大量类别上的花卉自动分类。见《国际计算机视觉与图形学国际会议(ICCVGI)》，2008 年。

[31] M. Norouzi, T. Mikolov, S. Bengio, Y. Singer, J. Shlens, A. Frome, G. Corrado, and J. Dean. Zero-shot learning by convex combination of semantic embeddings. In ICLR, 2014.

[31] M. 诺鲁兹(M. Norouzi)、T. 米科洛夫(T. Mikolov)、S. 本吉奥(S. Bengio)、Y. 辛格(Y. Singer)、J. 施伦斯(J. Shlens)、A. 弗罗姆(A. Frome)、G. 科拉多(G. Corrado)和 J. 迪恩(J. Dean)。通过语义嵌入的凸组合实现零样本学习。见《国际学习表征会议(ICLR)》，2014 年。

[32] G. Patterson and J. Hays. Sun attribute database: Discovering, annotating, and recognizing scene attributes. In CVPR, 2012.

[32] G. 帕特森(G. Patterson)和 J. 海斯(J. Hays)。太阳属性数据库:发现、标注和识别场景属性。见《计算机视觉与模式识别会议(CVPR)》，2012 年。

[33] R. Qiao, L. Liu, C. Shen, and A. van den Hengel. Less is more: Zero-shot learning from online textual documents with noise suppression. In ${CVPR},{2016}$ .

[33] R. 乔(R. Qiao)、L. 刘(L. Liu)、C. 沈(C. Shen)和 A. 范登亨格尔(A. van den Hengel)。少即是多:通过抑制噪声从在线文本文档进行零样本学习。见 ${CVPR},{2016}$。

[34] A. Radford, L. Metz, and S. Chintala. Unsupervised representation learning with deep convolutional generative adversarial networks. In ${ICLR},{2016}$ .

[34] A. 拉德福德(A. Radford)、L. 梅茨(L. Metz)和 S. 钦塔拉(S. Chintala)。使用深度卷积生成对抗网络进行无监督表征学习。见 ${ICLR},{2016}$。

[35] S. Reed, Z. Akata, H. Lee, and B. Schiele. Learning deep representations of fine-grained visual descriptions. In CVPR, 2016.

[35] S. 里德(S. Reed)、Z. 阿卡塔(Z. Akata)、H. 李(H. Lee)和 B. 席勒(B. Schiele)。学习细粒度视觉描述的深度表征。见《计算机视觉与模式识别会议(CVPR)》，2016 年。

[36] S. Reed, Z. Akata, S. Mohan, S. Tenka, B. Schiele, and H. Lee. Learning what and where to draw. In NIPS, 2016.

[36] S. 里德(S. Reed)、Z. 阿卡塔(Z. Akata)、S. 莫汉(S. Mohan)、S. 滕卡(S. Tenka)、B. 席勒(B. Schiele)和 H. 李(H. Lee)。学习画什么和在哪里画。见《神经信息处理系统大会(NIPS)》，2016 年。

[37] S. Reed, Z. Akata, X. Yan, L. Logeswaran, B. Schiele, and H. Lee. Generative adversarial text to image synthesis. In ICML, 2016.

[37] S. 里德(S. Reed)、Z. 阿卡塔(Z. Akata)、X. 严(X. Yan)、L. 洛格斯瓦兰(L. Logeswaran)、B. 席勒(B. Schiele)和 H. 李(H. Lee)。生成对抗文本到图像合成。见《国际机器学习会议(ICML)》，2016 年。

[38] M. Rohrbach, S. Ebert, and B. Schiele. Transfer learning in a transductive setting. In NIPS, 2013.

[38] M. 罗尔巴赫(M. Rohrbach)、S. 埃伯特(S. Ebert)和 B. 席勒(B. Schiele)。直推式设置下的迁移学习。见《神经信息处理系统大会(NIPS)》，2013 年。

[39] M. Rohrbach, M. Stark, and B.Schiele. Evaluating knowledge transfer and zero-shot learning in a large-scale setting. In ${CVPR},{2011}$ .

[39] M. 罗尔巴赫(M. Rohrbach)、M. 斯塔克(M. Stark)和 B. 席勒(B. Schiele)。大规模设置下的知识迁移和零样本学习评估。见 ${CVPR},{2011}$。

[40] B. Romera-Paredes and P. H. Torr. An embarrassingly simple approach to zero-shot learning. ICML, 2015.

[40] B. 罗梅拉 - 帕雷德斯(B. Romera - Paredes)和 P. H. 托尔(P. H. Torr)。一种极其简单的零样本学习方法。《国际机器学习会议(ICML)》，2015 年。

[41] T. Salimans, I. Goodfellow, W. Zaremba, V. Cheung, A. Radford, and X. Chen. Improved techniques for training gans. In NIPS, 2016.

[41] T. 萨利曼斯(T. Salimans)、I. 古德费洛(I. Goodfellow)、W. 扎雷巴(W. Zaremba)、V. 张(V. Cheung)、A. 拉德福德(A. Radford)和 X. 陈(X. Chen)。改进的生成对抗网络训练技术。见《神经信息处理系统大会(NIPS)》，2016 年。

[42] R. Socher, M. Ganjoo, C. D. Manning, and A. Ng. Zero-shot learning through cross-modal transfer. In NIPS. 2013.

[42] R. 索切尔(R. Socher)、M. 甘朱(M. Ganjoo)、C. D. 曼宁(C. D. Manning)和 A. 吴(A. Ng)。通过跨模态迁移实现零样本学习。见《神经信息处理系统大会(NIPS)》，2013 年。

[43] X. Wang and A. Gupta. Generative image modeling using style and structure adversarial networks. In ${ECCV},{2016}$ .

[43] X. 王(X. Wang)和 A. 古普塔(A. Gupta)。使用风格和结构对抗网络进行生成式图像建模。见 ${ECCV},{2016}$。

[44] P. Welinder, S. Branson, T. Mita, C. Wah, F. Schroff, S. Be-longie, and P. Perona. Caltech-UCSD Birds 200. Technical Report CNS-TR-2010-001, Caltech, 2010.

[44] P. 韦林德(P. Welinder)、S. 布兰森(S. Branson)、T. 米塔(T. Mita)、C. 瓦(C. Wah)、F. 施罗夫(F. Schroff)、S. 贝隆吉(S. Be - longie)和 P. 佩罗纳(P. Perona)。加州理工学院 - 加州大学圣地亚哥分校鸟类数据集 200。加州理工学院技术报告 CNS - TR - 2010 - 001，2010 年。

[45] Y. Xian, Z. Akata, G. Sharma, Q. Nguyen, M. Hein, and B. Schiele. Latent embeddings for zero-shot classification. In ${CVPR},{2016}$ .

[45] Y. 西安(Y. Xian)、Z. 阿卡塔(Z. Akata)、G. 夏尔马(G. Sharma)、Q. 阮(Q. Nguyen)、M. 海因(M. Hein)和 B. 席勒(B. Schiele)。用于零样本分类的潜在嵌入。见 ${CVPR},{2016}$。

[46] Y. Xian, B. Schiele, and Z. Akata. Zero-shot learning - the good, the bad and the ugly. In CVPR, 2017.

[46] 冼宇翔(Y. Xian)、比约恩·席勒(B. Schiele)和卓伊·阿卡塔(Z. Akata)。零样本学习——好的、坏的和丑陋的方面。发表于2017年的计算机视觉与模式识别会议(CVPR)。

[47] X. Yu and Y. Aloimonos. Attribute-based transfer learning for object categorization with zero or one training example. In ${ECCV},{2010}$ .

[47] 于翔(X. Yu)和扬尼斯·阿洛伊莫诺斯(Y. Aloimonos)。基于属性的迁移学习在零样本或单样本目标分类中的应用。发表于 ${ECCV},{2010}$ 。

[48] H. Zhang, T. Xu, H. Li, S. Zhang, X. Wang, X. Huang, and D. Metaxas. Stackgan: Text to photo-realistic image synthesis with stacked generative adversarial networks. In ICCV, 2017.

[48] 张航(H. Zhang)、徐婷洋(T. Xu)、李宏毅(H. Li)、张少霆(S. Zhang)、王晓刚(X. Wang)、黄学东(X. Huang)和迪米特里斯·梅塔克萨斯(D. Metaxas)。StackGAN:利用堆叠生成对抗网络实现从文本到逼真图像的合成。发表于2017年的国际计算机视觉会议(ICCV)。

[49] L. Zhang, T. Xiang, and S. Gong. Learning a deep embedding model for zero-shot learning. In CVPR, 2017.

[49] 张磊(L. Zhang)、向涛(T. Xiang)和龚少刚(S. Gong)。学习用于零样本学习的深度嵌入模型。发表于2017年的计算机视觉与模式识别会议(CVPR)。

[50] Z. Zhang and V. Saligrama. Zero-shot learning via semantic similarity embedding. In ${ICCV},{2015}$ .

[50] 张正友(Z. Zhang)和维贾伊·萨利格拉马(V. Saligrama)。通过语义相似性嵌入实现零样本学习。发表于 ${ICCV},{2015}$ 。