# Large Language Models are Zero-Shot Rankers for Recommender Systems

# 大语言模型是推荐系统的零样本排序器

Yupeng Hou ${}^{1,2 \dagger  }$ , Junjie Zhang ${}^{1 \dagger  }$ , Zihan Lin ${}^{3}$ , Hongyu Lu ${}^{4}$ , Ruobing Xie ${}^{4}$ , Julian McAuley ${}^{2}$ , and Wayne Xin Zhao ${}^{1 \boxtimes  }$ ${}^{1}$ Gaoling School of Artificial Intelligence, Renmin University of China ${}^{2}$ UC San Diego ${}^{3}$ School of Information, Renmin University of China 4 WeChat, Tencent yphou@ucsd.edu junjie.zhang@ruc.edu.cn batmanfly@gmail.com

侯宇鹏 ${}^{1,2 \dagger  }$ ，张俊杰 ${}^{1 \dagger  }$ ，林梓涵 ${}^{3}$ ，陆宏宇 ${}^{4}$ ，谢若冰 ${}^{4}$ ，朱利安·麦考利 ${}^{2}$ ，以及赵鑫 ${}^{1 \boxtimes  }$ ${}^{1}$ 中国人民大学高瓴人工智能学院 ${}^{2}$ 加州大学圣地亚哥分校 ${}^{3}$ 中国人民大学信息学院 4 腾讯微信 yphou@ucsd.edu junjie.zhang@ruc.edu.cn batmanfly@gmail.com

Abstract. Recently, large language models (LLMs) (e.g., GPT-4) have demonstrated impressive general-purpose task-solving abilities, including the potential to approach recommendation tasks. Along this line of research, this work aims to investigate the capacity of LLMs that act as the ranking model for recommender systems. We first formalize the recommendation problem as a conditional ranking task, considering sequential interaction histories as conditions and the items retrieved by other candidate generation models as candidates. To solve the ranking task by LLMs, we carefully design the prompting template and conduct extensive experiments on two widely-used datasets. We show that LLMs have promising zero-shot ranking abilities but (1) struggle to perceive the order of historical interactions, and (2) can be biased by popularity or item positions in the prompts. We demonstrate that these issues can be alleviated using specially designed prompting and bootstrapping strategies. Equipped with these insights, zero-shot LLMs can even challenge conventional recommendation models when ranking candidates are retrieved by multiple candidate generators. The code and processed datasets are available at https://github.com/RUCAIBox/LLMRank

摘要。最近，大语言模型(LLMs)(如 GPT - 4)已展现出令人印象深刻的通用任务解决能力，包括处理推荐任务的潜力。沿着这一研究方向，本文旨在研究大语言模型作为推荐系统排序模型的能力。我们首先将推荐问题形式化为一个条件排序任务，将顺序交互历史作为条件，将其他候选生成模型检索到的项目作为候选。为了让大语言模型解决排序任务，我们精心设计了提示模板，并在两个广泛使用的数据集上进行了大量实验。我们发现大语言模型具有良好的零样本排序能力，但(1)难以感知历史交互的顺序，(2)可能会受到提示中项目流行度或位置的影响。我们证明，使用专门设计的提示和自举策略可以缓解这些问题。基于这些发现，当候选项目由多个候选生成器检索时，零样本大语言模型甚至可以挑战传统的推荐模型。代码和处理后的数据集可在 https://github.com/RUCAIBox/LLMRank 获取。

Keywords: Large Language Model - Recommender System.

关键词:大语言模型 - 推荐系统。

## 1 Introduction

## 1 引言

In the literature of recommender systems, most existing models are trained with user behavior data from a specific domain or scenario [4926 28], suffering from two major issues. Firstly, it is difficult to capture user preference by solely modeling historical behaviors, e.g., clicked item sequences [28, 33, 82], limiting the expressive power to model more complicated but explicit user interests (e.g., intentions expressed in natural language). Secondly, these models are essentially "narrow experts", lacking more comprehensive knowledge in solving complicated recommendation tasks that rely on background or commonsense knowledge [23.

在推荐系统的文献中，大多数现有模型是使用特定领域或场景的用户行为数据进行训练的 [49, 26, 28]，存在两个主要问题。首先，仅对历史行为(如点击项目序列)进行建模很难捕捉用户偏好 [28, 33, 82]，这限制了模型对更复杂但明确的用户兴趣(如自然语言表达的意图)的表达能力。其次，这些模型本质上是“狭义专家”，在解决依赖背景知识或常识的复杂推荐任务时缺乏更全面的知识 [23]。

---

† Equal contribution.

† 同等贡献。

- Corresponding author.

- 通讯作者。

---

To improve recommendation performance and interactivity, there have been increasing efforts that explore the use of pre-trained language models (PLMs) in recommender systems [2130 62]. They aim to explicitly capture user preference in natural language [21] or transfer rich world knowledge from text corpora [30] 29. Despite their effectiveness, thoroughly fine-tuning the recommendation models on task-specific data is still a necessity, making it less capable of solving diverse recommendation tasks [30]. More recently, large language models (LLMs) have shown great potential to serve as zero-shot task solvers [6452]. Indeed, there are some preliminary attempts that employ LLMs for solving recommendation tasks [20 59 60 13 40 74]. These studies mainly focus on discussing the possibility of building a capable recommender with LLMs. While promising, the insufficient understanding of the new characteristics when making recommendations using LLMs could hinder the development of this new paradigm.

为了提高推荐性能和交互性，越来越多的研究开始探索在推荐系统中使用预训练语言模型(PLMs) [21, 30, 62]。它们旨在明确捕捉自然语言中的用户偏好 [21] 或从文本语料库中迁移丰富的世界知识 [30, 29]。尽管它们很有效，但仍然需要在特定任务数据上对推荐模型进行全面微调，这使得它们在解决多样化推荐任务时能力有限 [30]。最近，大语言模型(LLMs)已显示出作为零样本任务解决器的巨大潜力 [64, 52]。实际上，已经有一些初步尝试使用大语言模型来解决推荐任务 [20, 59, 60, 13, 40, 74]。这些研究主要集中在讨论使用大语言模型构建有效推荐器的可能性。虽然前景广阔，但对使用大语言模型进行推荐时的新特性缺乏深入理解可能会阻碍这一新范式的发展。

In this paper, we conduct empirical studies to investigate what determines the capacity of LLMs that serve as recommendation models. Typically, recommender systems are developed in a pipeline architecture [10], consisting of candidate generation (retrieving relevant items) and ranking (ranking relevant items at a higher position) procedures. This work mainly focuses on the ranking stage of recommender systems, since LLMs are more expensive to run on a large-scale candidate set. Further, the ranking performance is sensitive to the retrieved candidate items, which is more suitable to examine the subtle differences in the recommendation abilities of LLMs.

在本文中，我们进行实证研究，以探究决定大语言模型作为推荐模型能力的因素。通常，推荐系统采用流水线架构开发 [10]，包括候选生成(检索相关项目)和排序(将相关项目排在较高位置)两个过程。由于在大规模候选集上运行大语言模型的成本较高，本文主要关注推荐系统的排序阶段。此外，排序性能对检索到的候选项目很敏感，这更适合检验大语言模型推荐能力的细微差异。

To carry out this study, we first formalize the recommendation process of LLMs as a conditional ranking task. Given prompts that include sequential historical interactions as "conditions", LLMs are instructed to rank a set of "candidates" (e.g., items retrieved by candidate generation models), according to LLM's intrinsic knowledge. Then we conduct control experiments to systematically study the empirical performance of LLMs as rankers by designing specific configurations for "conditions" and "candidates", respectively. Overall, we attempt to answer the following key questions:

为了开展这项研究，我们首先将大语言模型的推荐过程形式化为一个条件排序任务。给定包含顺序历史交互作为“条件”的提示，大语言模型根据其内在知识对一组“候选”(如候选生成模型检索到的项目)进行排序。然后，我们分别为“条件”和“候选”设计特定配置，进行对照实验，系统地研究大语言模型作为排序器的实证性能。总体而言，我们试图回答以下关键问题:

- What factors affect the zero-shot ranking performance of LLMs?

- 哪些因素影响大语言模型的零样本排序性能？

- What data or knowledge do LLMs rely on for recommendation?

- 大语言模型进行推荐依赖哪些数据或知识？

Our empirical experiments are conducted on two public datasets for recommender systems. The results lead to several key findings that potentially shed light on how to develop LLMs as powerful ranking models for recommender systems. We summarize the key findings as follows:

我们的实证实验在两个用于推荐系统的公开数据集上进行。实验结果得出了几个关键发现，这些发现可能为如何将大语言模型(LLMs)开发成推荐系统的强大排序模型提供了思路。我们将关键发现总结如下:

- LLMs struggle to perceive the order of the given sequential interaction histories. By employing specifically designed promptings, LLMs can be triggered to perceive the order, leading to improved ranking performance.

- 大语言模型难以感知给定的顺序交互历史的顺序。通过采用专门设计的提示，大语言模型可以被触发来感知顺序，从而提高排序性能。

- LLMs suffer from position bias and popularity bias while ranking, which can be alleviated by bootstrapping or specially designed prompting strategies.

- 大语言模型在排序时会受到位置偏差和流行度偏差的影响，这些偏差可以通过自助法或专门设计的提示策略来缓解。

![0195d6ec-f93b-74b3-925b-d4e322f9a540_2_381_330_1040_276_0.jpg](images/0195d6ec-f93b-74b3-925b-d4e322f9a540_2_381_330_1040_276_0.jpg)

Fig. 1: An overview of the proposed LLM-based zero-shot ranking method.

图1:所提出的基于大语言模型的零样本排序方法概述。

- LLMs outperform existing zero-shot recommendation methods, showing promising zero-shot ranking abilities, especially on candidates retrieved by multiple candidate generation models with different practical strategies.

- 大语言模型优于现有的零样本推荐方法，显示出有前景的零样本排序能力，特别是在通过具有不同实用策略的多个候选生成模型检索到的候选项目上。

## 2 General Framework for LLMs as Rankers

## 2 大语言模型作为排序器的通用框架

To investigate the recommendation abilities of LLMs, we first formalize the recommendation process as a conditional ranking task. Then, we describe a general framework that adapts LLMs to solve the recommendation task.

为了研究大语言模型的推荐能力，我们首先将推荐过程形式化为一个条件排序任务。然后，我们描述一个使大语言模型适应解决推荐任务的通用框架。

### 2.1 Problem Formulation

### 2.1 问题表述

Given the historical interactions $\mathcal{H} = \left\{  {{i}_{1},{i}_{2},\ldots ,{i}_{n}}\right\}$ of one user (in chronological order of interaction time) as conditions, the task is to rank the candidate items $\mathcal{C} = {\left\{  {i}_{j}\right\}  }_{j = 1}^{m}$ , such that the items of interest would be ranked at a higher position. In practice, the candidate items are usually retrieved by candidate generation models from the whole item set $\mathcal{I}\left( {m \ll  \left| \mathcal{I}\right| }\right)$ [10]. Further, we assume that each item $i$ is associated with a descriptive text ${t}_{i}$ following [30].

给定一个用户的历史交互 $\mathcal{H} = \left\{  {{i}_{1},{i}_{2},\ldots ,{i}_{n}}\right\}$(按交互时间的先后顺序)作为条件，任务是对候选项目 $\mathcal{C} = {\left\{  {i}_{j}\right\}  }_{j = 1}^{m}$ 进行排序，使得感兴趣的项目排在更高的位置。在实践中，候选项目通常由候选生成模型从整个项目集 $\mathcal{I}\left( {m \ll  \left| \mathcal{I}\right| }\right)$ 中检索得到 [10]。此外，我们假设每个项目 $i$ 都关联着一个描述性文本 ${t}_{i}$，遵循文献 [30]。

### 2.2 Ranking with LLMs Using Natural Language Instructions

### 2.2 使用自然语言指令的大语言模型排序

We use LLMs as ranking models to solve the above-mentioned task in an instruction-following paradigm [64]. Specifically, for each user, we first construct two natural language patterns that contain sequential interaction histories $\mathcal{H}$ (conditions) and retrieved candidate items $\mathcal{C}$ (candidates), respectively. Then these patterns are filled into a natural language template $T$ as the final instruction. In this way, LLMs are expected to understand the instructions and output the ranking results as the instruction suggests. The overall framework of the ranking approach by LLMs is depicted in Figure 1. Next, we describe the detailed instruction design in our approach.

我们使用大语言模型作为排序模型，以遵循指令的范式 [64] 来解决上述任务。具体来说，对于每个用户，我们首先分别构建两个包含顺序交互历史 $\mathcal{H}$(条件)和检索到的候选项目 $\mathcal{C}$(候选)的自然语言模式。然后将这些模式填充到一个自然语言模板 $T$ 中作为最终指令。通过这种方式，期望大语言模型理解指令并按照指令输出排序结果。大语言模型排序方法的总体框架如图1所示。接下来，我们描述我们方法中详细的指令设计。

Sequential historical interactions. To investigate whether LLMs can capture user preferences from historical user behaviors, we include sequential historical interactions $\mathcal{H}$ into the instructions as inputs of LLMs. To enable LLMs to be aware of the sequential nature of historical interactions, we propose three ways to construct the instructions:

顺序历史交互。为了研究大语言模型是否能从用户历史行为中捕捉用户偏好，我们将顺序历史交互 $\mathcal{H}$ 作为大语言模型的输入包含在指令中。为了使大语言模型能够意识到历史交互的顺序性，我们提出了三种构建指令的方法:

- Sequential prompting: Arrange the historical interactions in chronological order. This way has also been used in prior studies [13]. For example, "I've watched the following movies in the past in order: '0. Multiplicity', '1. Jurassic Park', ...".

- 顺序提示:按时间顺序排列历史交互。这种方法也在先前的研究中被使用过 [13]。例如，“我过去按顺序观看了以下电影:'0. 《叠影狂花》'，'1. 《侏罗纪公园》'，...”。

- Recency-focused prompting: In addition to the sequential interaction records, we can add an additional sentence to emphasize the most recent interaction. For example, "I've watched the following movies in the past in order: '0. Multiplicity', '1. Jurassic Park', ... Note that my most recently watched movie is Dead Presidents. ...".

- 近期聚焦提示:除了顺序交互记录，我们可以添加一个额外的句子来强调最近的交互。例如，“我过去按顺序观看了以下电影:'0. 《叠影狂花》'，'1. 《侏罗纪公园》'，... 请注意，我最近观看的电影是《生死豪情》。...”。

- In-context learning (ICL): ICL is a prominent prompting approach for LLMs to solve various tasks [79], where it includes demonstration examples in the prompt. For the personalized recommendation task, simply introducing examples of other users may introduce noises because users usually have different preferences. Instead, we introduce demonstration examples by augmenting the input interaction sequence itself. We pair the prefix of the input interaction sequence and the corresponding successor as examples. For instance, " If I've watched the following movies in the past in order: '0. Multiplicity', '1. Jurassic Park', ..., then you should recommend Dead Presidents to me and now that I've watched Dead Presidents, then ...".

- 上下文学习(ICL):上下文学习是大语言模型解决各种任务的一种突出提示方法 [79]，它在提示中包含示范示例。对于个性化推荐任务，简单地引入其他用户的示例可能会引入噪声，因为用户通常有不同的偏好。相反，我们通过扩充输入交互序列本身来引入示范示例。我们将输入交互序列的前缀和相应的后续项配对作为示例。例如，“如果我过去按顺序观看了以下电影:'0. 《叠影狂花》'，'1. 《侏罗纪公园》'，...，那么你应该向我推荐《生死豪情》，现在我已经观看了《生死豪情》，那么...”。

Retrieved candidate items. Typically, candidate items to be ranked are first retrieved by candidate generation models [10]. In this work, we consider a relatively small pool for the candidates, and keep 20 candidate items (i.e., $m = {20}$ ) for ranking. To rank these candidates with LLMs, we arrange the candidate items $\mathcal{C}$ in a sequential manner. For example,"Now there are 20 candidate movies that I can watch next: '0. Sister Act', '1. Sunset Blvd', ...". Note that, following the classic candidate generation approach [10], there is no specific order for candidate items. As a result, We generate different orders for the candidate items in the prompts, which enables us to further examine whether the ranking results of LLMs are affected by the arrangement order of candidates, i.e., position bias, and how to alleviate position bias via bootstrapping.

检索到候选项目。通常，待排序的候选项目首先由候选生成模型检索得到 [10]。在这项工作中，我们为候选项目考虑了一个相对较小的集合，并保留 20 个候选项目(即 $m = {20}$ )用于排序。为了使用大语言模型(LLMs)对这些候选项目进行排序，我们按顺序排列候选项目 $\mathcal{C}$。例如，“现在有 20 部候选电影可供我接下来观看:‘0. 《修女也疯狂》’，‘1. 《日落大道》’……”。请注意，遵循经典的候选生成方法 [10]，候选项目没有特定的顺序。因此，我们在提示中为候选项目生成不同的顺序，这使我们能够进一步研究大语言模型的排序结果是否受候选项目排列顺序的影响，即位置偏差，以及如何通过自助法缓解位置偏差。

Ranking with large language models. Existing studies show that LLMs can follow natural language instructions to solve diverse tasks in a zero-shot setting [64 79]. To rank using LLMs, we infill the patterns above into the instruction template $T$ . An example instruction template can be given as: " [pattern that contains sequential historical interactions $\mathcal{H}$ ] [pattern that contains retrieved candidate items $\mathcal{C}$ | Please rank these movies by measuring the possibilities that $I$ would like to watch next most, according to my watching history.".

使用大语言模型进行排序。现有研究表明，大语言模型可以在零样本设置下遵循自然语言指令解决各种任务 [64 79]。为了使用大语言模型进行排序，我们将上述模式填充到指令模板 $T$ 中。一个示例指令模板可以是:“ [包含顺序历史交互的模式 $\mathcal{H}$ ] [包含检索到的候选项目的模式 $\mathcal{C}$ | 请根据我的观看历史，通过衡量 $I$ 接下来最想观看的可能性对这些电影进行排序。”

Parsing the output of LLMs. Note that the output of LLMs is still in natural language text, and we parse the output with heuristic text-matching methods and ground the recommendation results on the specified item set. In detail, we can directly perform efficient substring matching algorithms like KMP [35] between

解析大语言模型的输出。请注意，大语言模型的输出仍然是自然语言文本，我们使用启发式文本匹配方法解析输出，并将推荐结果基于指定的项目集。具体来说，我们可以直接在之间执行像 KMP 这样的高效子串匹配算法 [35]

Table 1: Statistics of the preprocessed datasets. "Avg. $\left| \mathcal{H}\right|$ " denotes the average length of historical interactions. "Avg. $\left| {t}_{i}\right|$ " denotes the average number of tokens in the item text.

表 1:预处理数据集的统计信息。“Avg. $\left| \mathcal{H}\right|$ ”表示历史交互的平均长度。“Avg. $\left| {t}_{i}\right|$ ”表示项目文本中的平均标记数。

<table><tr><td>Dataset</td><td>#Users</td><td>#Items</td><td>#Interactions</td><td>Sparsity</td><td>Avg. $\left| \mathcal{H}\right|$</td><td>Avg. $\left| {t}_{i}\right|$</td></tr><tr><td>ML-1M</td><td>6,040</td><td>3,706</td><td>1,000,209</td><td>95.53%</td><td>46.19</td><td>16.96</td></tr><tr><td>Games</td><td>50,547</td><td>16,859</td><td>389,718</td><td>99.95%</td><td>7.02</td><td>43.31</td></tr></table>

<table><tbody><tr><td>数据集</td><td>用户数量</td><td>物品数量</td><td>交互数量</td><td>稀疏性</td><td>平均 $\left| \mathcal{H}\right|$</td><td>平均 $\left| {t}_{i}\right|$</td></tr><tr><td>ML - 1M</td><td>6,040</td><td>3,706</td><td>1,000,209</td><td>95.53%</td><td>46.19</td><td>16.96</td></tr><tr><td>游戏</td><td>50,547</td><td>16,859</td><td>389,718</td><td>99.95%</td><td>7.02</td><td>43.31</td></tr></tbody></table>

the LLM outputs and the text of candidate items. We also found that LLMs occasionally generate items that are not present in the candidate set. For GPT-3.5, such deviations occur in a mere $3\%$ of cases. One can either reprocess the illegal cases or simply treat the out-of-candidate items as incorrect recommendations.

大语言模型(LLM)的输出和候选条目的文本。我们还发现，大语言模型偶尔会生成候选集中不存在的条目。对于GPT - 3.5而言，此类偏差仅在$3\%$的情况下出现。我们既可以对不合法的情况进行重新处理，也可以简单地将候选集之外的条目视为错误推荐。

## 3 Empirical Studies

## 3 实证研究

Datasets. The experiments are conducted on two widely-used public datasets for recommender systems: (1) the movie rating dataset MovieLens-1M [24] (in short, ML-1M) where user ratings are regarded as interactions, and (2) one category from the Amazon Review dataset [46] named Games where reviews are regarded as interactions. We filter out users and items with fewer than five interactions. Then we sort the interactions of each user by timestamp, with the oldest interactions first, to construct the corresponding historical interaction sequences. The movie/product titles are used as the descriptive text of an item. We use item titles in this study for two reasons: (1) to determine if LLMs can make recommendations based on their intrinsic world knowledge with minimal information provided, and (2) to conserve computational resources. Exploring how LLMs use more extensive textual features for recommendations will be the focus of our future work.

数据集。实验在两个广泛使用的推荐系统公共数据集上进行:(1)电影评分数据集MovieLens - 1M [24](简称ML - 1M)，其中用户评分被视为交互；(2)亚马逊评论数据集[46]中的一个类别“游戏(Games)”，其中评论被视为交互。我们过滤掉交互次数少于五次的用户和条目。然后，我们按时间戳对每个用户的交互进行排序，最早的交互排在最前，以构建相应的历史交互序列。电影/产品标题被用作条目的描述性文本。我们在本研究中使用条目标题有两个原因:(1)确定大语言模型是否可以在提供最少信息的情况下，基于其内在的世界知识进行推荐；(2)节省计算资源。探索大语言模型如何使用更广泛的文本特征进行推荐将是我们未来工作的重点。

Evaluation and implementation details. Following existing works [33] 30, we apply the leave-one-out strategy for evaluation. For each historical interaction sequence, the last item is used as the ground-truth item in test set. The item before the last one is used in the validation set (used for training baseline methods). We adopt the widely used metric NDCG@K (in short, N@K) to evaluate the ranking results over the given $m$ candidates, where $K \leq  m$ . To ease the reproduction of this work, our experiments are conducted using a popular open-source recommendation library RECBOLE [78]. The historical interaction sequences are truncated within a length of 50 . We evaluate LLM-based methods on all users in ML-1M dataset and randomly sampled 6,000 users for Games dataset by default. Unless specified, the evaluated LLM is accessed by calling OpenAI's API gpt-3.5-turbo. The hyperparameter temperature of calling LLMs is set to 0.2 . All the reported results are the average of at least three repeat runs to reduce the effect of randomness.

评估和实现细节。遵循现有研究[33, 30]，我们采用留一法(leave - one - out)策略进行评估。对于每个历史交互序列，最后一个条目用作测试集中的真实条目。倒数第二个条目用于验证集(用于训练基线方法)。我们采用广泛使用的指标NDCG@K(简称N@K)来评估给定$m$个候选条目的排序结果，其中$K \leq  m$。为了便于本研究的复现，我们使用流行的开源推荐库RECBOLE [78]进行实验。历史交互序列的长度截断为50。默认情况下，我们在ML - 1M数据集中的所有用户上评估基于大语言模型的方法，并在“游戏”数据集中随机抽取6000个用户进行评估。除非另有说明，评估的大语言模型通过调用OpenAI的API gpt - 3.5 - turbo进行访问。调用大语言模型的超参数温度设置为0.2。所有报告的结果均为至少三次重复运行的平均值，以减少随机性的影响。

![0195d6ec-f93b-74b3-925b-d4e322f9a540_5_554_350_696_339_0.jpg](images/0195d6ec-f93b-74b3-925b-d4e322f9a540_5_554_350_696_339_0.jpg)

Fig. 2: Analysis of whether LLMs perceive the order of historical interactions.

图2:大语言模型是否能感知历史交互顺序的分析。

### 3.1 Can LLMs Understand Prompts that Involve Sequential Historical User Behaviors?

### 3.1 大语言模型能否理解涉及用户历史顺序行为的提示？

In LLM-based methods, historical interactions are naturally arranged in an ordered sequence. By designing different configurations of $\mathcal{H}$ , we aim to examine whether LLMs can leverage these historical user behaviors and perceive the sequential nature for making accurate recommendations.

在基于大语言模型的方法中，历史交互自然地按有序序列排列。通过设计不同的$\mathcal{H}$配置，我们旨在研究大语言模型是否可以利用这些用户历史行为并感知其顺序性，以进行准确的推荐。

LLMs struggle to perceive the order of given historical user behaviors. In this section, we examine whether LLMs can understand prompts with ordered historical interactions and give personalized recommendations. The task is to rank a candidate set of 20 items, containing one ground-truth item and 19 randomly sampled negatives. By analyzing historical behaviors, items of interest should be ranked at a higher position. We compare the ranking results of three LLM-based methods: (a) Ours, which ranks as we have described in Section 2.2. Historical user behaviors are encoded into prompts using the "sequential prompting" strategy. (b) Random Order, where the historical user behaviors will be randomly shuffled before being fed to the model, and (c) Fake History, where we replace all the items in original historical behaviors with randomly sampled items as fake historical behaviors. From Figure 2(a), we can see that Ours has better performance than variants with fake historical behaviors. However, the performance of Ours and Random Order is similar, indicating that LLMs are not sensitive to the order of the given historical user interactions.

大语言模型难以感知给定的用户历史行为顺序。在本节中，我们研究大语言模型是否能够理解包含有序历史交互的提示并给出个性化推荐。任务是对包含一个真实条目和19个随机抽取的负样本的20个候选条目集进行排序。通过分析历史行为，感兴趣的条目应该排在更高的位置。我们比较了三种基于大语言模型的方法的排序结果:(a)我们的方法，按照第2.2节所述进行排序。用户历史行为使用“顺序提示”策略编码到提示中。(b)随机顺序，在将用户历史行为输入模型之前对其进行随机打乱；(c)虚假历史，我们用随机抽取的条目替换原始历史行为中的所有条目，作为虚假历史行为。从图2(a)中可以看出，我们的方法比使用虚假历史行为的变体表现更好。然而，我们的方法和随机顺序方法的性能相似，这表明大语言模型对给定的用户历史交互顺序不敏感。

Moreover, in Figure 2(b), we vary the number of latest historical user behaviors $\left( \left| \mathcal{H}\right| \right)$ used for constructing the prompt from 5 to 50 . The results show that increasing the number of historical user behaviors does not improve, but rather negatively impacts the ranking performance. We speculate that this phenomenon is caused by the fact that LLMs have difficulty understanding the order, but consider all the historical behaviors equally. Therefore too many historical user behaviors (e.g., $\left| \mathcal{H}\right|  = {50}$ ) may overwhelm LLMs and lead to a performance drop. In contrast, a relatively small $\left| \mathcal{H}\right|$ enables LLMs to concentrate on the most recently interacted items, resulting in better recommendation performance.

此外，在图2(b)中，我们将用于构建提示的最新用户历史行为数量$\left( \left| \mathcal{H}\right| \right)$从5变化到50。结果表明，增加用户历史行为的数量并没有提高排序性能，反而产生了负面影响。我们推测这种现象是由于大语言模型难以理解顺序，但同等对待所有历史行为。因此，过多的用户历史行为(例如$\left| \mathcal{H}\right|  = {50}$)可能会使大语言模型不堪重负，导致性能下降。相反，相对较小的$\left| \mathcal{H}\right|$使大语言模型能够专注于最近交互的条目，从而获得更好的推荐性能。

Table 2: Performance comparison on randomly retrieved candidates. Ground-truth items are included in the candidate sets. "full" denotes models that are trained on the target dataset, and "zero-shot" denotes models that are not trained on the target dataset but could be pre-trained. We highlight the best performance among zero-shot recommendation methods in bold.

表2:随机检索候选集的性能比较。候选集中包含真实项。“全量训练(full)”表示在目标数据集上进行训练的模型，“零样本(zero-shot)”表示未在目标数据集上训练但可以进行预训练的模型。我们以粗体突出显示零样本推荐方法中的最佳性能。

<table><tr><td/><td rowspan="2">Method</td><td colspan="4">ML-1M</td><td colspan="4">Games</td></tr><tr><td/><td>N@1</td><td>N@5</td><td>N@10</td><td>N@20</td><td>N@1</td><td>N@5</td><td>N@10</td><td>N@20</td></tr><tr><td rowspan="3">full</td><td>Pop</td><td>22.91</td><td>45.16</td><td>52.33</td><td>55.36</td><td>28.35</td><td>47.42</td><td>52.96</td><td>57.45</td></tr><tr><td>BPRMF 49</td><td>34.60</td><td>59.87</td><td>64.29</td><td>65.39</td><td>44.92</td><td>62.33</td><td>66.27</td><td>68.94</td></tr><tr><td>SASRec 33</td><td>61.39</td><td>76.39</td><td>78.89</td><td>79.79</td><td>56.90</td><td>73.19</td><td>75.92</td><td>77.14</td></tr><tr><td rowspan="6">zero-shot</td><td>BM25 50</td><td>4.70</td><td>12.68</td><td>17.88</td><td>33.19</td><td>13.92</td><td>28.81</td><td>34.61</td><td>44.35</td></tr><tr><td>UniSRec 30</td><td>7.37</td><td>18.80</td><td>26.67</td><td>37.93</td><td>18.95</td><td>33.99</td><td>40.71</td><td>48.42</td></tr><tr><td>VQ-Rec 29</td><td>5.98</td><td>15.48</td><td>23.74</td><td>35.85</td><td>7.28</td><td>18.28</td><td>26.21</td><td>37.62</td></tr><tr><td>Sequential</td><td>18.28</td><td>36.35</td><td>42.85</td><td>49.02</td><td>30.28</td><td>45.48</td><td>50.57</td><td>56.55</td></tr><tr><td>Recency-Focused</td><td>19.57</td><td>37.73</td><td>44.23</td><td>50.01</td><td>34.03</td><td>48.77</td><td>53.50</td><td>59.01</td></tr><tr><td>In-Context Learning</td><td>21.77</td><td>39.59</td><td>45.83</td><td>51.62</td><td>33.95</td><td>48.44</td><td>53.10</td><td>58.92</td></tr></table>

<table><tbody><tr><td></td><td rowspan="2">方法</td><td colspan="4">ML - 1M(原词保留)</td><td colspan="4">游戏</td></tr><tr><td></td><td>N@1</td><td>N@5</td><td>N@10</td><td>N@20</td><td>N@1</td><td>N@5</td><td>N@10</td><td>N@20</td></tr><tr><td rowspan="3">完整的</td><td>流行(音乐等，需结合具体场景)</td><td>22.91</td><td>45.16</td><td>52.33</td><td>55.36</td><td>28.35</td><td>47.42</td><td>52.96</td><td>57.45</td></tr><tr><td>贝叶斯个性化排序矩阵分解(BPRMF)49</td><td>34.60</td><td>59.87</td><td>64.29</td><td>65.39</td><td>44.92</td><td>62.33</td><td>66.27</td><td>68.94</td></tr><tr><td>自注意力序列推荐模型(SASRec)33</td><td>61.39</td><td>76.39</td><td>78.89</td><td>79.79</td><td>56.90</td><td>73.19</td><td>75.92</td><td>77.14</td></tr><tr><td rowspan="6">零样本学习</td><td>基于词频和逆文档频率的检索模型(BM25)50</td><td>4.70</td><td>12.68</td><td>17.88</td><td>33.19</td><td>13.92</td><td>28.81</td><td>34.61</td><td>44.35</td></tr><tr><td>统一序列推荐模型(UniSRec)30</td><td>7.37</td><td>18.80</td><td>26.67</td><td>37.93</td><td>18.95</td><td>33.99</td><td>40.71</td><td>48.42</td></tr><tr><td>矢量量化推荐模型(VQ - Rec)29</td><td>5.98</td><td>15.48</td><td>23.74</td><td>35.85</td><td>7.28</td><td>18.28</td><td>26.21</td><td>37.62</td></tr><tr><td>序列的</td><td>18.28</td><td>36.35</td><td>42.85</td><td>49.02</td><td>30.28</td><td>45.48</td><td>50.57</td><td>56.55</td></tr><tr><td>近期聚焦的</td><td>19.57</td><td>37.73</td><td>44.23</td><td>50.01</td><td>34.03</td><td>48.77</td><td>53.50</td><td>59.01</td></tr><tr><td>上下文学习</td><td>21.77</td><td>39.59</td><td>45.83</td><td>51.62</td><td>33.95</td><td>48.44</td><td>53.10</td><td>58.92</td></tr></tbody></table>

Triggering LLMs to perceive the interaction order. Based on the above observations, we find it difficult for LLMs to perceive the order in interaction histories by a default prompting strategy. As a result, we aim to elicit the order-perceiving abilities of LLMs, by proposing two alternative prompting strategies and emphasizing the recently interacted items. Detailed descriptions of the proposed strategies have been given in Section 2.2. In Table 2, we can see that both recency-focused prompting and in-context learning can generally improve the ranking performance of LLMs, though the best strategy may vary on different datasets. The above results can be summarized as the following key observation:

触发大语言模型(LLMs)感知交互顺序。基于上述观察，我们发现默认的提示策略难以让大语言模型感知交互历史中的顺序。因此，我们旨在通过提出两种替代提示策略并强调最近交互的项目，来激发大语言模型的顺序感知能力。所提出策略的详细描述已在2.2节给出。在表2中，我们可以看到，尽管最佳策略可能因不同数据集而异，但聚焦近期的提示和上下文学习通常都能提高大语言模型的排序性能。上述结果可总结为以下关键观察结果:

Observation 1. LLMs struggle to perceive the order of the given sequential interaction histories. By employing specifically designed promptings, LLMs can be triggered to perceive the order of historical user behaviors, leading to improved ranking performance.

观察1. 大语言模型难以感知给定的顺序交互历史的顺序。通过采用专门设计的提示，可以触发大语言模型感知历史用户行为的顺序，从而提高排序性能。

### 3.2 Do LLMs suffer from biases while ranking?

### 3.2 大语言模型在排序时是否存在偏差？

The biases and debiasing methods in conventional recommender systems have been widely studied [5]. For LLM-based recommendation models, both the input and output are natural language texts and will inevitably introduce new biases. In this section, we discuss two kinds of biases that LLM-based recommendation models suffer from. We also make discussions on how to alleviate these biases.

传统推荐系统中的偏差和去偏方法已得到广泛研究 [5]。对于基于大语言模型的推荐模型，输入和输出均为自然语言文本，不可避免地会引入新的偏差。在本节中，我们讨论基于大语言模型的推荐模型所面临的两种偏差。我们还将讨论如何减轻这些偏差。

The order of candidates affects the ranking results of LLMs. For conventional ranking methods, the order of retrieved candidates usually will not affect the ranking results [33, 28]. However, for the LLM-based approach that is described in Section 2.2, the candidates are arranged in a sequential manner and infilled into a prompt. It has been shown that LLMs are generally sensitive to the order of examples in the prompts for NLP tasks [80, 44]. As a result, we also conduct experiments to examine whether the order of candidates affects the ranking performance of LLMs. We follow the experimental settings adopted in Section 3.1. The only difference is that we control the order of these candidates in the prompts, by making the ground-truth items appear at a certain position. We vary the position of ground-truth items at $\{ 0,5,{10},{15},{19}\}$ and present the results in Figure 3(a). We can see that the performance varies when the ground-truth items appear at different positions. Especially, the ranking performance drops significantly when the ground-truth items appear at the last few positions. The results indicate that LLM-based rankers are affected by the order of candidates, i.e., position bias, which may not affect conventional recommendation models.

候选项目的顺序会影响大语言模型的排序结果。对于传统的排序方法，检索到的候选项目的顺序通常不会影响排序结果 [33, 28]。然而，对于2.2节中描述的基于大语言模型的方法，候选项目按顺序排列并填充到提示中。研究表明，在自然语言处理任务中，大语言模型通常对提示中示例的顺序敏感 [80, 44]。因此，我们还进行了实验，以检验候选项目的顺序是否会影响大语言模型的排序性能。我们遵循3.1节中采用的实验设置。唯一的区别是，我们通过让真实项目出现在特定位置来控制提示中这些候选项目的顺序。我们改变真实项目在$\{ 0,5,{10},{15},{19}\}$中的位置，并将结果展示在图3(a)中。我们可以看到，当真实项目出现在不同位置时，性能会有所不同。特别是，当真实项目出现在最后几个位置时，排序性能会显著下降。结果表明，基于大语言模型的排序器会受到候选项目顺序的影响，即位置偏差，而这可能不会影响传统推荐模型。

![0195d6ec-f93b-74b3-925b-d4e322f9a540_7_392_350_1024_318_0.jpg](images/0195d6ec-f93b-74b3-925b-d4e322f9a540_7_392_350_1024_318_0.jpg)

Fig. 3: Biases and debiasing methods in the ranking of LLMs. (a) The position of candidates in the prompts influences the ranking results. (b) Bootstrapping alleviates position bias. (c) LLMs tend to recommend popular items. (d) Focusing on historical interactions reduces popularity bias.

图3:大语言模型排序中的偏差和去偏方法。(a) 提示中候选项目的位置会影响排序结果。(b) 自助法可减轻位置偏差。(c) 大语言模型倾向于推荐热门项目。(d) 关注历史交互可减少流行度偏差。

Alleviating position bias via bootstrapping. A simple strategy to alleviate position bias is to bootstrap the ranking process. We may rank the candidate set repeatedly for $B$ times, with candidates randomly shuffled at each round. In this way, one candidate may appear in different positions. We then merge the results of each round to derive the final ranking. From Figure 3(b), we follow the setting in Section 3.1 and apply the bootstrapping strategy to Ours. Each candidate set will be ranked for 3 times. We can see that bootstrapping improves the ranking performance on both datasets.

通过自助法减轻位置偏差。减轻位置偏差的一种简单策略是对排序过程进行自助采样。我们可以对候选集重复排序$B$次，每次对候选项目进行随机洗牌。这样，一个候选项目可能会出现在不同的位置。然后，我们合并每一轮的结果以得出最终排序。从图3(b)中可以看出，我们遵循3.1节中的设置，并将自助法策略应用于我们的方法。每个候选集将被排序3次。我们可以看到，自助法提高了两个数据集上的排序性能。

Popularity degrees of candidates affect ranking results of LLMs. For popular items, the associated text may also appear frequently in the pre-training corpora of LLMs. For example, a best-selling book would be widely discussed on the Web. Thus, we aim to examine whether the ranking results are affected by the popularity of candidates. However, it is difficult to directly measure the popularity of item text. Here, we hypothesize that the text popularity can be indirectly measured by item frequency in one recommendation dataset. In Figure 3(c), we report the item popularity score (measured by the normalized item frequency of appearance in the training set) at each position of the ranked item lists. We can see that popular items tend to be ranked at higher positions.

候选项目的流行度会影响大语言模型的排序结果。对于热门项目，相关文本可能也会频繁出现在大语言模型的预训练语料库中。例如，一本畅销书会在网络上被广泛讨论。因此，我们旨在检验排序结果是否会受到候选项目流行度的影响。然而，直接衡量项目文本的流行度是很困难的。在这里，我们假设可以通过一个推荐数据集中项目的出现频率来间接衡量文本的流行度。在图3(c)中，我们报告了排序项目列表中每个位置的项目流行度得分(通过训练集中项目的归一化出现频率来衡量)。我们可以看到，热门项目往往排在较高的位置。

Table 3: Zero-shot ranking performance comparison. We highlight the best performance in bold. Due to limited budget, we evaluate each LLM only once on 200 sampled users only for experiments corresponding to this table.

表3:零样本排序性能比较。我们用粗体突出显示最佳性能。由于预算有限，对于与此表对应的实验，我们仅对200个抽样用户对每个大语言模型进行一次评估。

<table><tr><td rowspan="2">Method</td><td colspan="4">ML-1M</td><td colspan="4">Games</td></tr><tr><td>N@1</td><td>N@5</td><td>N@10</td><td>N@20</td><td>N@1</td><td>N@5</td><td>N@10</td><td>N@20</td></tr><tr><td>BM25 50</td><td>4.70</td><td>12.68</td><td>17.88</td><td>33.19</td><td>13.92</td><td>28.81</td><td>34.61</td><td>44.35</td></tr><tr><td>UniSRec 30</td><td>7.37</td><td>18.80</td><td>26.67</td><td>37.93</td><td>18.95</td><td>33.99</td><td>40.71</td><td>48.42</td></tr><tr><td>Alpaca-7B 55</td><td>4.00</td><td>13.92</td><td>23.09</td><td>31.54</td><td>5.50</td><td>14.16</td><td>21.67</td><td>28.68</td></tr><tr><td>Vicuna-13B 9</td><td>6.50</td><td>14.75</td><td>22.64</td><td>33.42</td><td>7.00</td><td>17.73</td><td>24.30</td><td>31.22</td></tr><tr><td>LLaMA-2-70B-Chat 57</td><td>8.00</td><td>25.42</td><td>31.19</td><td>34.52</td><td>21.50</td><td>32.30</td><td>37.83</td><td>41.97</td></tr><tr><td>ChatGPT (GPT-3.5)</td><td>23.33</td><td>42.07</td><td>48.80</td><td>53.73</td><td>23.83</td><td>45.69</td><td>50.31</td><td>55.45</td></tr><tr><td>GPT-4</td><td>15.50</td><td>40.65</td><td>46.74</td><td>48.42</td><td>39.50</td><td>58.22</td><td>62.88</td><td>65.25</td></tr></table>

<table><tbody><tr><td rowspan="2">方法</td><td colspan="4">ML - 1M</td><td colspan="4">游戏</td></tr><tr><td>N@1</td><td>N@5</td><td>N@10</td><td>N@20</td><td>N@1</td><td>N@5</td><td>N@10</td><td>N@20</td></tr><tr><td>BM25 50</td><td>4.70</td><td>12.68</td><td>17.88</td><td>33.19</td><td>13.92</td><td>28.81</td><td>34.61</td><td>44.35</td></tr><tr><td>UniSRec 30</td><td>7.37</td><td>18.80</td><td>26.67</td><td>37.93</td><td>18.95</td><td>33.99</td><td>40.71</td><td>48.42</td></tr><tr><td>羊驼模型-7B 55</td><td>4.00</td><td>13.92</td><td>23.09</td><td>31.54</td><td>5.50</td><td>14.16</td><td>21.67</td><td>28.68</td></tr><tr><td>骆马模型-13B 9</td><td>6.50</td><td>14.75</td><td>22.64</td><td>33.42</td><td>7.00</td><td>17.73</td><td>24.30</td><td>31.22</td></tr><tr><td>大语言模型-2-70B-聊天版 57</td><td>8.00</td><td>25.42</td><td>31.19</td><td>34.52</td><td>21.50</td><td>32.30</td><td>37.83</td><td>41.97</td></tr><tr><td>聊天生成预训练转换器(GPT - 3.5)</td><td>23.33</td><td>42.07</td><td>48.80</td><td>53.73</td><td>23.83</td><td>45.69</td><td>50.31</td><td>55.45</td></tr><tr><td>GPT - 4</td><td>15.50</td><td>40.65</td><td>46.74</td><td>48.42</td><td>39.50</td><td>58.22</td><td>62.88</td><td>65.25</td></tr></tbody></table>

Making LLMs focus on historical interactions helps reduce popularity bias. We assume that if LLMs focus on historical interactions, they may give more personalized recommendations but not more popular ones. From Figure 2(b), we know that LLMs make better use of historical interactions when using less historical interactions. From Figure 3(d), we compare the popularity scores of the best-ranked items varying the number of historical interactions. It can be observed that as $\left| \mathcal{H}\right|$ decreases, the popularity score decreases as well. This suggests that one can reduce the effects of popularity bias when LLMs focus more on historical interactions. From the above experiments, we can conclude the following:

让大语言模型(LLMs)关注历史交互有助于减少流行度偏差。我们假设，如果大语言模型关注历史交互，它们可能会给出更个性化的推荐，而不是更流行的推荐。从图2(b)中我们可知，大语言模型在使用较少历史交互时能更好地利用历史交互信息。从图3(d)中，我们比较了不同历史交互数量下排名最高的项目的流行度得分。可以观察到，随着$\left| \mathcal{H}\right|$的减小，流行度得分也随之降低。这表明，当大语言模型更多地关注历史交互时，可以减少流行度偏差的影响。从上述实验中，我们可以得出以下结论:

Observation 2. LLMs suffer from position bias and popularity bias while ranking, which can be alleviated by bootstrapping or specially designed prompting strategies.

观察2. 大语言模型在排序时会受到位置偏差和流行度偏差的影响，这可以通过自助法(bootstrapping)或专门设计的提示策略来缓解。

### 3.3 How Well Can LLMs Rank Candidates in a Zero-Shot Setting?

### 3.3 大语言模型在零样本设置下对候选对象的排序效果如何？

We further evaluate LLM-based methods on candidates with hard negatives that are retrieved by different strategies to further investigate what the ranking of LLMs depends on. Then, we present the ranking performance of different methods on candidates retrieved by multiple candidate generation models to simulate a more practical and difficult setting.

我们进一步评估基于大语言模型的方法在通过不同策略检索到的包含难负样本的候选对象上的表现，以进一步研究大语言模型的排序依赖于什么。然后，我们展示不同方法在由多个候选对象生成模型检索到的候选对象上的排序性能，以模拟更实际、更具挑战性的场景。

LLMs have promising zero-shot ranking abilities. In Table 2, we conduct experiments to compare the ranking abilities of LLM-based methods with existing methods. We follow the same setting in Section 3.1 where $\left| \mathcal{C}\right|  = {20}$ and candidate items are randomly retrieved. We include three conventional models that are trained on the training set, i.e., Pop (recommending according to item popularity), BPRMF [49], and SASRec [33]. We also evaluate three zero-shot recommendation methods that are not trained on the target datasets, including BM25 50 (rank according to the textual similarity between candidates and historical interactions), UniSRec [30], and VQ-Rec [29]. For UniSRec and VQ-Rec, we use their publicly available pre-trained models. We do not include ZESRec [15] because there is no pre-trained model released. In addition, we compare the zero-shot ranking performance of different LLMs in Table 3. "Recency-Focused" prompting strategy is used for LLM-based rankers.

大语言模型具有良好的零样本排序能力。在表2中，我们进行实验，比较基于大语言模型的方法与现有方法的排序能力。我们采用与3.1节相同的设置，即随机检索$\left| \mathcal{C}\right|  = {20}$和候选项目。我们纳入了三个在训练集上训练的传统模型，即Pop(根据项目流行度进行推荐)、BPRMF [49]和SASRec [33]。我们还评估了三种未在目标数据集上训练的零样本推荐方法，包括BM25 50(根据候选对象与历史交互之间的文本相似度进行排序)、UniSRec [30]和VQ - Rec [29]。对于UniSRec和VQ - Rec，我们使用它们公开可用的预训练模型。我们没有纳入ZESRec [15]，因为没有发布预训练模型。此外，我们在表3中比较了不同大语言模型的零样本排序性能。基于大语言模型的排序器使用了“近期聚焦”提示策略。

![0195d6ec-f93b-74b3-925b-d4e322f9a540_9_388_333_1030_409_0.jpg](images/0195d6ec-f93b-74b3-925b-d4e322f9a540_9_388_333_1030_409_0.jpg)

Fig. 4: Ranking performance measured by NDCG@10 (%) on hard negatives.

图4:在难负样本上以NDCG@10(%)衡量的排序性能。

From Table 2 and 3, we can see that LLMs with more parameters generally perform better. The best LLM-based methods outperform existing zero-shot recommendation methods by a large margin, showing promising zero-shot ranking abilities. We would highlight that it is difficult to conduct zero-shot recommendations on the ML-1M dataset, due to the difficulty in measuring the similarity between movies merely by the similarity of their titles. However, LLMs can use their intrinsic knowledge to measure the similarity between movies and make recommendations. We would emphasize that the goal of evaluating zero-shot recommendation methods is not to surpass conventional models. The goal is to demonstrate the strong recommendation capabilities of pre-trained base models, which can be further adapted and transferred to downstream scenarios.

从表2和表3中可以看出，参数更多的大语言模型通常表现更好。基于大语言模型的最佳方法大幅优于现有的零样本推荐方法，显示出良好的零样本排序能力。我们要强调的是，在ML - 1M数据集上进行零样本推荐很困难，因为仅通过电影标题的相似度来衡量电影之间的相似度存在困难。然而，大语言模型可以利用其内在知识来衡量电影之间的相似度并进行推荐。我们要强调的是，评估零样本推荐方法的目的不是超越传统模型。目的是展示预训练基础模型强大的推荐能力，这些能力可以进一步适应并迁移到下游场景。

LLMs rank candidates based on item popularity, text features as well as user behaviors. To further investigate how LLMs rank the given candidates, we evaluate LLMs on candidates that are retrieved by different candidate generation methods. These candidates can be viewed as hard negatives for ground-truth items, which can be used to measure the ranking ability of LLMs for specific categories of items. We consider two categories of strategies to retrieve the candidates: (1) content-based methods like BM25 [50] and BERT [14] retrieve candidates based on the text feature similarities, and (2) interaction-based methods, including Pop, BPRMF [49], GRU4Rec [28], and SASRec [33], retrieve items using neural networks trained on user-item interactions. Given candidates, we compare the ranking performance of the LLM-based model (Ours) and representative methods.

大语言模型基于项目流行度、文本特征以及用户行为对候选对象进行排序。为了进一步研究大语言模型如何对给定的候选对象进行排序，我们评估大语言模型在通过不同候选对象生成方法检索到的候选对象上的表现。这些候选对象可以被视为真实项目的难负样本，可用于衡量大语言模型对特定类别项目的排序能力。我们考虑两类检索候选对象的策略:(1)基于内容的方法，如BM25 [50]和BERT [14]，根据文本特征相似度检索候选对象；(2)基于交互的方法，包括Pop、BPRMF [49]、GRU4Rec [28]和SASRec [33]，使用在用户 - 项目交互上训练的神经网络检索项目。给定候选对象后，我们比较基于大语言模型的模型(我们的方法)和代表性方法的排序性能。

Table 4: Performance comparison on candidates retrieved by multiple candidate generation models. Ground-truth items are not guaranteed to be included in the candidate sets. "full" denotes models that are trained on the target dataset, and "zero-shot" denotes models that are not trained on the target dataset but could be pre-trained. We highlight the best and second-best performance among all recommendation methods in bold.

表4:在由多个候选对象生成模型检索到的候选对象上的性能比较。候选集不一定包含真实项目。“全量训练”表示在目标数据集上训练的模型，“零样本”表示未在目标数据集上训练但可以进行预训练的模型。我们用粗体突出显示所有推荐方法中的最佳和次佳性能。

<table><tr><td colspan="2" rowspan="2">Method</td><td colspan="4">ML-1M</td><td colspan="4">Games</td></tr><tr><td>N@1</td><td>N@5</td><td>N@10</td><td>N@20</td><td>N@1</td><td>N@5</td><td>N@10</td><td>N@20</td></tr><tr><td rowspan="3">full</td><td>Pop</td><td>0.08</td><td>1.20</td><td>4.13</td><td>5.79</td><td>0.13</td><td>1.00</td><td>2.27</td><td>2.62</td></tr><tr><td>BPRMF [49]</td><td>0.26</td><td>1.69</td><td>4.41</td><td>6.04</td><td>0.55</td><td>1.98</td><td>2.96</td><td>3.19</td></tr><tr><td>SASRec 33</td><td>3.76</td><td>9.79</td><td>10.45</td><td>10.56</td><td>1.33</td><td>3.55</td><td>4.02</td><td>4.11</td></tr><tr><td rowspan="4">zero-shot</td><td>BM25 50</td><td>0.26</td><td>0.87</td><td>2.32</td><td>5.28</td><td>0.18</td><td>1.07</td><td>1.80</td><td>2.55</td></tr><tr><td>UniSRec 30</td><td>0.88</td><td>3.46</td><td>5.30</td><td>6.92</td><td>0.00</td><td>1.86</td><td>2.03</td><td>2.31</td></tr><tr><td>VQ-Rec 29</td><td>0.20</td><td>1.60</td><td>3.29</td><td>5.73</td><td>0.20</td><td>1.21</td><td>1.91</td><td>2.64</td></tr><tr><td>Ours</td><td>1.74</td><td>5.22</td><td>6.91</td><td>7.90</td><td>0.90</td><td>2.26</td><td>2.80</td><td>3.08</td></tr></table>

<table><tbody><tr><td colspan="2" rowspan="2">方法</td><td colspan="4">ML - 1M(百万级电影评分数据集)</td><td colspan="4">游戏</td></tr><tr><td>N@1</td><td>N@5</td><td>N@10</td><td>N@20</td><td>N@1</td><td>N@5</td><td>N@10</td><td>N@20</td></tr><tr><td rowspan="3">完整的</td><td>流行(Popular的缩写，这里推测含义)</td><td>0.08</td><td>1.20</td><td>4.13</td><td>5.79</td><td>0.13</td><td>1.00</td><td>2.27</td><td>2.62</td></tr><tr><td>贝叶斯个性化排序矩阵分解(Bayesian Personalized Ranking Matrix Factorization) [49]</td><td>0.26</td><td>1.69</td><td>4.41</td><td>6.04</td><td>0.55</td><td>1.98</td><td>2.96</td><td>3.19</td></tr><tr><td>自注意力序列推荐模型(Self - Attention Sequential Recommendation) 33</td><td>3.76</td><td>9.79</td><td>10.45</td><td>10.56</td><td>1.33</td><td>3.55</td><td>4.02</td><td>4.11</td></tr><tr><td rowspan="4">零样本</td><td>基于词频统计的文本检索算法(Best - Match 25) 50</td><td>0.26</td><td>0.87</td><td>2.32</td><td>5.28</td><td>0.18</td><td>1.07</td><td>1.80</td><td>2.55</td></tr><tr><td>统一序列推荐模型(Unified Sequential Recommendation) 30</td><td>0.88</td><td>3.46</td><td>5.30</td><td>6.92</td><td>0.00</td><td>1.86</td><td>2.03</td><td>2.31</td></tr><tr><td>矢量量化推荐模型(Vector Quantization - Recommendation) 29</td><td>0.20</td><td>1.60</td><td>3.29</td><td>5.73</td><td>0.20</td><td>1.21</td><td>1.91</td><td>2.64</td></tr><tr><td>我们的方法</td><td>1.74</td><td>5.22</td><td>6.91</td><td>7.90</td><td>0.90</td><td>2.26</td><td>2.80</td><td>3.08</td></tr></tbody></table>

From Figure 4, we can see that the ranking performance of the LLM-based method varies on different candidate sets and different datasets. (1) On ML-1M, LLM-based method cannot rank well on candidate sets that contain popular items (e.g., Pop and BPRMF), indicating the LLM-based method recommend items largely depend on item popularity on ML-1M dataset. (2) On Games, we can observe that Ours has similar performance both on popular candidates and textual similar candidates, showing that item popularity and text features contribute similarly to the ranking of LLMs. (3) On both two datasets, the performance of Ours is affected by hard negatives retrieved by interaction-based candidate generation models, but not as severe as those interaction-based rankers like SASRec. The above results demonstrate that LLM-based methods not only consider one single aspect for ranking, but make use of item popularity, text features, and even user behaviors. On different datasets, the weights of these three aspects to affect the ranking performance may also vary.

从图4中我们可以看出，基于大语言模型(LLM)的方法在不同的候选集和不同的数据集上的排序性能有所不同。(1)在ML - 1M数据集上，基于大语言模型的方法在包含热门物品的候选集(例如Pop和BPRMF)上无法进行良好的排序，这表明基于大语言模型的方法在ML - 1M数据集上推荐物品很大程度上依赖于物品的流行度。(2)在Games数据集上，我们可以观察到我们的方法(Ours)在热门候选物品和文本相似候选物品上的性能相似，这表明物品流行度和文本特征对大语言模型的排序贡献相近。(3)在这两个数据集上，我们的方法的性能会受到基于交互的候选生成模型检索到的难负样本的影响，但不像SASRec等基于交互的排序器那样严重。上述结果表明，基于大语言模型的方法在排序时并非只考虑单一因素，而是综合利用了物品流行度、文本特征，甚至用户行为。在不同的数据集上，这三个因素对排序性能的影响权重也可能不同。

LLMs can effectively rank candidates retrieved by multiple candidate generation models. For real-world recommender systems [10], the items to be ranked are usually retrieved by multiple candidate generation models. As a result, we also conduct experiments in a more practical and difficult setting. We use the above-mentioned seven candidate generation models to retrieve items. The top-3 best items retrieved by each candidate generation model will be merged into a candidate set containing a total of 21 items. As a more practical setting, we do not complement the ground-truth item to each candidate set. Note that the experiments here were conducted under the implicit preference setup [77], indicating that implicit positive instances (not explicitly labeled) may exist among the retrieved items. A more faithful evaluation might require a human study, which we intend to explore in our future work. For Ours, we summarize the experiences gained from Section 3.1 and 3.2. We use the recency-focused prompting strategy to encode $\left| \mathcal{H}\right|  = 5$ sequential historical interactions into prompts and use a bootstrapping strategy to repeatedly rank for 3 rounds.

大语言模型可以有效地对多个候选生成模型检索到的候选物品进行排序。对于现实世界的推荐系统[10]，待排序的物品通常是由多个候选生成模型检索得到的。因此，我们还在一个更实际、更具挑战性的设置下进行了实验。我们使用上述七种候选生成模型来检索物品。每个候选生成模型检索到的前3个最佳物品将合并到一个包含总共21个物品的候选集中。作为一个更实际的设置，我们不会为每个候选集补充真实物品。请注意，这里的实验是在隐式偏好设置[77]下进行的，这意味着在检索到的物品中可能存在隐式正样本(未明确标记)。更可靠的评估可能需要进行人工研究，我们打算在未来的工作中进行探索。对于我们的方法，我们总结了从3.1节和3.2节中获得的经验。我们使用聚焦近期性的提示策略将$\left| \mathcal{H}\right|  = 5$顺序历史交互编码为提示，并使用自举策略重复排序3轮。

From Table 4, we can see that the LLM-based model (Ours) yields the second-best performance over the compared recommendation models on most metrics. The results show that LLM-based zero-shot ranker even beats the conventional recommendation model Pop and BPRMF that has been trained on the target datasets, further demonstrating the strong zero-shot ranking ability of LLMs. We assume that LLMs can make use of their intrinsic world knowledge to rank the candidates comprehensively considering popularity, text features, and user behaviors. In comparison, existing models (as narrrow experts) may lack the ability to rank items in a complicated setting. The above findings can be summarized as:

从表4中我们可以看出，基于大语言模型的模型(我们的方法)在大多数指标上的性能在对比的推荐模型中排名第二。结果表明，基于大语言模型的零样本排序器甚至击败了在目标数据集上训练过的传统推荐模型Pop和BPRMF，这进一步证明了大语言模型强大的零样本排序能力。我们假设大语言模型可以利用其内在的世界知识，综合考虑流行度、文本特征和用户行为来对候选物品进行排序。相比之下，现有的模型(作为狭义专家)可能缺乏在复杂设置下对物品进行排序的能力。上述发现可以总结如下:

Observation 3. LLMs have promising zero-shot ranking abilities, especially on candidates retrieved by multiple candidate generation models with different practical strategies.

观察3. 大语言模型具有良好的零样本排序能力，特别是在对由采用不同实际策略的多个候选生成模型检索到的候选物品进行排序时。

## 4 Related Work

## 4 相关工作

Transfer learning for recommender systems. As recommender systems are mostly trained on data collected from a single source, people have sought to transfer knowledge from other domains [71 85 45 86 76 83 , markets [351], or platforms [419]. Typical transfer learning methods for recommender systems rely on anchors, including shared users/items [45, 8469707 8] or representations from a shared space 111838 . However, these anchors are usually sparse among different scenarios, making transferring difficult for recommendations [85]. More recently, there are studies aiming to transfer knowledge stored in language models by adapting them to recommendation tasks via tuning [121 1253 or prompting [37 75 39]. In this paper, we conduct zero-shot recommendation experiments to examine the potential to transfer knowledge from LLMs.

推荐系统的迁移学习。由于推荐系统大多是在从单一来源收集的数据上进行训练的，人们一直在寻求从其他领域[71, 85, 45, 86, 76, 83]、市场[351]或平台[419]迁移知识。典型的推荐系统迁移学习方法依赖于锚点，包括共享用户/物品[45, 84, 69, 70, 78]或来自共享空间的表示[11, 18, 38]。然而，这些锚点在不同场景中通常很稀疏，这使得推荐的迁移变得困难[85]。最近，有研究旨在通过微调[121, 125, 3]或提示[37, 75, 39]将语言模型中存储的知识迁移到推荐任务中。在本文中，我们进行了零样本推荐实验，以检验从大语言模型迁移知识的潜力。

Large language models for recommender systems. The design of recommendation models, especially sequential recommendation models, has been long inspired by the design of language models, from word2vec [2,2225] to recent neural networks [28, 33, 82, 54]. In recent years, with the development of pre-trained language models (PLMs) [14], people have tried to transfer knowledge stored in PLMs to recommendation models, by either representing items using their text features or representing behavior sequences in the format of natural language [21 58 42 16 68]. Very recently, large language models (LLMs) have been shown superior language understanding and generation abilities [79 56 47 66 17 6 67 . Studies have been made to make recommender systems more interactive by integrating LLMs along with conventional recommendation models [2036 43 59 27 61 65 48] or fine-tuned with specially designed instructions [1221 1 31 81]. There are also early explorations showing LLMs have zero-shot recommendation abilities [59 41 13 34 72 60 63 73]. Despite being effective to some extent, few works have explored what determines the recommendation performance of LLMs.

用于推荐系统的大语言模型。推荐模型的设计，尤其是序列推荐模型的设计，长期以来一直受到语言模型设计的启发，从词向量模型(word2vec) [2,2225] 到最近的神经网络 [28, 33, 82, 54]。近年来，随着预训练语言模型(PLMs) [14] 的发展，人们尝试将预训练语言模型中存储的知识迁移到推荐模型中，方法是使用文本特征表示物品，或以自然语言格式表示行为序列 [21 58 42 16 68]。最近，大语言模型(LLMs)已显示出卓越的语言理解和生成能力 [79 56 47 66 17 6 67]。已有研究通过将大语言模型与传统推荐模型相结合 [2036 43 59 27 61 65 48] 或使用专门设计的指令进行微调 [1221 1 31 81]，使推荐系统更具交互性。也有早期探索表明大语言模型具有零样本推荐能力 [59 41 13 34 72 60 63 73]。尽管在一定程度上有效，但很少有研究探索是什么决定了大语言模型的推荐性能。

## 5 Conclusion

## 5 结论

In this work, we investigated the capacities of LLMs that act as the zero-shot ranking model for recommender systems. To rank with LLMs, we constructed natural language prompts that contain historical interactions, candidates, and instruction templates. We then propose several specially designed prompting strategies to trigger the ability of LLMs to perceive orders of sequential behaviors. We also introduce bootstrapping and prompting strategies to alleviate the position bias and popularity bias issues that LLM-based ranking models may suffer.

在这项工作中，我们研究了大语言模型作为推荐系统零样本排序模型的能力。为了使用大语言模型进行排序，我们构建了包含历史交互、候选对象和指令模板的自然语言提示。然后，我们提出了几种专门设计的提示策略，以激发大语言模型感知序列行为顺序的能力。我们还引入了自举和提示策略，以缓解基于大语言模型的排序模型可能面临的位置偏差和流行度偏差问题。

Extensive empirical studies indicate that LLMs have promising zero-shot ranking abilities. The empirical studies demonstrate the strong potential of transferring knowledge from LLMs as powerful recommendation models. We aim at shedding light on several promising directions to further improve the ranking abilities of LLMs, including (1) better perceiving the order of sequential historical interactions and (2) alleviating the position bias and popularity bias. For future work, we consider developing technical approaches to solve the above-mentioned key challenges when deploying LLMs as recommendation models. We also would like to develop LLM-based recommendation models that can be efficiently tuned on downstream user behaviors for effective personalized recommendations.

大量的实证研究表明，大语言模型具有良好的零样本排序能力。实证研究证明了将大语言模型的知识迁移为强大推荐模型的巨大潜力。我们旨在为进一步提高大语言模型的排序能力指明几个有前景的方向，包括(1)更好地感知序列历史交互的顺序，以及(2)缓解位置偏差和流行度偏差。对于未来的工作，我们考虑开发技术方法来解决在将大语言模型部署为推荐模型时上述关键挑战。我们还希望开发基于大语言模型的推荐模型，该模型可以在下游用户行为上进行有效调整，以实现有效的个性化推荐。

## 6 Limitations

## 6 局限性

In most experiments in this paper, ChatGPT is used as the primary target LLM for evaluation. However, being a closed-source commercial service, ChatGPT might integrate additional techniques with its core large language model to improve performance. While there are open-source LLMs available, such as LLaMA 2 [57] and Mistral [32], they exhibit a notable performance disparity compared to ChatGPT (e.g., LLaMA-2-70B-Chat vs. ChatGPT in Table 3). This gap makes it difficult to evaluate the emergent abilities of LLMs on the recommendation tasks using purely open-source models. In addition, we should note that the observations might be biased by specific prompts and datasets.

在本文的大多数实验中，ChatGPT 被用作主要的评估目标大语言模型。然而，作为一个闭源商业服务，ChatGPT 可能会在其核心大语言模型中集成额外的技术以提高性能。虽然有一些开源大语言模型可用，如 LLaMA 2 [57] 和 Mistral [32]，但与 ChatGPT 相比，它们的性能存在显著差距(例如，表 3 中的 LLaMA - 2 - 70B - Chat 与 ChatGPT)。这种差距使得很难仅使用开源模型来评估大语言模型在推荐任务上的新兴能力。此外，我们应该注意到，这些观察结果可能会受到特定提示和数据集的影响而产生偏差。

## Acknowledgements

## 致谢

This work was partially supported by National Natural Science Foundation of China under Grant No. 62222215, Beijing Natural Science Foundation under Grant No. L233008 and 4222027. Xin Zhao is the corresponding author.

这项工作得到了国家自然科学基金(项目编号:62222215)、北京市自然科学基金(项目编号:L233008 和 4222027)的部分资助。赵鑫是通讯作者。

## References

## 参考文献

1. Bao, K., Zhang, J., Zhang, Y., Wang, W., Feng, F., He, X.: Tallrec: An effective and efficient tuning framework to align large language model with recommendation. arXiv preprint arXiv:2305.00447 (2023)

1. Bao, K., Zhang, J., Zhang, Y., Wang, W., Feng, F., He, X.: Tallrec:一种有效且高效的微调框架，用于使大语言模型与推荐任务对齐。预印本 arXiv:2305.00447 (2023)

2. Barkan, O., Koenigstein, N.: ITEM2VEC: neural item embedding for collaborative filtering. In: Palmieri, F.A.N., Uncini, A., Diamantaras, K.I., Larsen, J. (eds.) 26th IEEE International Workshop on Machine Learning for Signal Processing, MLSP 2016, Vietri sul Mare, Salerno, Italy, September 13-16, 2016. pp. 1-6. IEEE (2016). https://doi.org/10.1109/MLSP.2016.7738886.https://doi.org/10.1109/ MLSP.2016.7738886

2. Barkan, O., Koenigstein, N.:ITEM2VEC:用于协同过滤的神经物品嵌入。见:Palmieri, F.A.N., Uncini, A., Diamantaras, K.I., Larsen, J.(编)第 26 届 IEEE 机器学习信号处理国际研讨会，MLSP 2016，意大利萨勒诺省维耶特里苏尔马雷，2016 年 9 月 13 - 16 日。第 1 - 6 页。IEEE (2016)。https://doi.org/10.1109/MLSP.2016.7738886.https://doi.org/10.1109/ MLSP.2016.7738886

3. Bonab, H.R., Aliannejadi, M., Vardasbi, A., Kanoulas, E., Allan, J.: Cross-market product recommendation. In: Demartini, G., Zuccon, G., Culpep-per, J.S., Huang, Z., Tong, H. (eds.) CIKM. pp. 110-119. ACM (2021). https://doi.org/10.1145/3459637.3482493.https://doi.org/10.1145/3459637 3482493

3. 博纳布(Bonab)，H.R.，阿里安内贾迪(Aliannejadi)，M.，瓦尔达斯比(Vardasbi)，A.，卡努拉斯(Kanoulas)，E.，艾伦(Allan)，J.:跨市场产品推荐。见:德马尔蒂尼(Demartini)，G.，祖克康(Zuccon)，G.，卡尔佩珀(Culpep-per)，J.S.，黄(Huang)，Z.，童(Tong)，H.(编)《信息与知识管理大会论文集》(CIKM)。第110 - 119页。美国计算机协会(ACM)(2021)。https://doi.org/10.1145/3459637.3482493.https://doi.org/10.1145/3459637 3482493

4. Cao, D., He, X., Nie, L., Wei, X., Hu, X., Wu, S., Chua, T.: Cross-platform app recommendation by jointly modeling ratings and texts. ACM Trans. Inf. Syst. 35(4), 37:1-37:27 (2017). https://doi.org/10.1145/3017429.https://doi.org/10.1145/ 3017429

4. 曹(Cao)，D.，何(He)，X.，聂(Nie)，L.，魏(Wei)，X.，胡(Hu)，X.，吴(Wu)，S.，蔡(Chua)，T.:通过联合建模评分和文本进行跨平台应用推荐。《美国计算机协会信息系统汇刊》(ACM Trans. Inf. Syst.)35(4)，37:1 - 37:27(2017)。https://doi.org/10.1145/3017429.https://doi.org/10.1145/ 3017429

5. Chen, J., Dong, H., Wang, X., Feng, F., Wang, M., He, X.: Bias and debias in recommender system: A survey and future directions. CoRR abs/2010.03240 (2020), https://arxiv.org/abs/2010.03240

5. 陈(Chen)，J.，董(Dong)，H.，王(Wang)，X.，冯(Feng)，F.，王(Wang)，M.，何(He)，X.:推荐系统中的偏差与去偏差:综述与未来方向。预印本库(CoRR)abs/2010.03240(2020)，https://arxiv.org/abs/2010.03240

6. Chen, J., Liu, Z., Huang, X., Wu, C., Liu, Q., Jiang, G., Pu, Y., Lei, Y., Chen, X., Wang, X., et al.: When large language models meet personalization: Perspectives of challenges and opportunities. arXiv preprint arXiv:2307.16376 (2023)

6. 陈(Chen)，J.，刘(Liu)，Z.，黄(Huang)，X.，吴(Wu)，C.，刘(Liu)，Q.，江(Jiang)，G.，蒲(Pu)，Y.，雷(Lei)，Y.，陈(Chen)，X.，王(Wang)，X.等:当大语言模型遇到个性化:挑战与机遇的视角。预印本库(arXiv)预印本arXiv:2307.16376(2023)

7. Chen, L., Yuan, F., Yang, J., He, X., Li, C., Yang, M.: User-specific adaptive fine-tuning for cross-domain recommendations. IEEE Trans. Knowl. Data Eng. $\mathbf{{35}}\left( 3\right) ,{3239} - {3252}\left( {2023}\right)$ . https://doi.org/10.1109/TKDE.2021.3119619.https: //doi.org/10.1109/TKDE.2021.3119619

7. 陈(Chen)，L.，袁(Yuan)，F.，杨(Yang)，J.，何(He)，X.，李(Li)，C.，杨(Yang)，M.:用于跨领域推荐的用户特定自适应微调。《电气与电子工程师协会知识与数据工程汇刊》(IEEE Trans. Knowl. Data Eng.)$\mathbf{{35}}\left( 3\right) ,{3239} - {3252}\left( {2023}\right)$ 。https://doi.org/10.1109/TKDE.2021.3119619.https: //doi.org/10.1109/TKDE.2021.3119619

8. Cheng, M., Yuan, F., Liu, Q., Xin, X., Chen, E.: Learning transferable user representations with sequential behaviors via contrastive pre-training. In: Bailey, J., Miettinen, P., Koh, Y.S., Tao, D., Wu, X. (eds.) ICDM. pp. 51-60. IEEE (2021). https://doi.org/10.1109/ICDM51629.2021.00015.https://doi.org/ 10.1109/ICDM51629.2021.00015

8. 程(Cheng)，M.，袁(Yuan)，F.，刘(Liu)，Q.，辛(Xin)，X.，陈(Chen)，E.:通过对比预训练学习具有序列行为的可迁移用户表示。见:贝利(Bailey)，J.，米耶蒂宁(Miettinen)，P.， Koh，Y.S.，陶(Tao)，D.，吴(Wu)，X.(编)《数据挖掘国际会议论文集》(ICDM)。第51 - 60页。电气与电子工程师协会(IEEE)(2021)。https://doi.org/10.1109/ICDM51629.2021.00015.https://doi.org/ 10.1109/ICDM51629.2021.00015

9. Chiang, W.L., Li, Z., Lin, Z., Sheng, Y., Wu, Z., Zhang, H., Zheng, L., Zhuang, S., Zhuang, Y., Gonzalez, J.E., et al.: Vicuna: An open-source chatbot impressing gpt-4 with 90%* chatgpt quality. See https://vicuna.lmsys.org (accessed 14 April 2023) (2023)

9. 蒋(Chiang)，W.L.，李(Li)，Z.，林(Lin)，Z.，盛(Sheng)，Y.，吴(Wu)，Z.，张(Zhang)，H.，郑(Zheng)，L.，庄(Zhuang)，S.，庄(Zhuang)，Y.，冈萨雷斯(Gonzalez)，J.E.等:维库纳(Vicuna):一个以90%*ChatGPT质量给GPT - 4留下深刻印象的开源聊天机器人。见https://vicuna.lmsys.org(2023年4月14日访问)(2023)

10. Covington, P., Adams, J., Sargin, E.: Deep neural networks for youtube recommendations. In: RecSys. pp. 191-198 (2016)

10. 科文顿(Covington)，P.，亚当斯(Adams)，J.，萨尔金(Sargin)，E.:用于YouTube推荐的深度神经网络。见:《推荐系统会议论文集》(RecSys)。第191 - 198页(2016)

11. Cui, Q., Wei, T., Zhang, Y., Zhang, Q.: Herograph: A heterogeneous graph framework for multi-target cross-domain recommendation. In: Vinagre, J., Jorge, A.M., Al-Ghossein, M., Bifet, A. (eds.) RecSys. CEUR Workshop Proceedings, vol. 2715. CEUR-WS.org (2020), https://ceur-ws.org/Vol-2715/paper6.pdf

11. 崔(Cui)，Q.，魏(Wei)，T.，张(Zhang)，Y.，张(Zhang)，Q.:异构图框架Herograph用于多目标跨领域推荐。见:维纳格雷(Vinagre)，J.，若热(Jorge)，A.M.，阿尔 - 霍塞因(Al - Ghossein)，M.，比菲特(Bifet)，A.(编)《推荐系统会议论文集》(RecSys)。CEUR研讨会论文集，第2715卷。CEUR - WS.org(2020)，https://ceur - ws.org/Vol - 2715/paper6.pdf

12. Cui, Z., Ma, J., Zhou, C., Zhou, J., Yang, H.: M6-rec: Generative pretrained language models are open-ended recommender systems. arXiv preprint arXiv:2205.08084 (2022)

12. 崔(Cui)，Z.，马(Ma)，J.，周(Zhou)，C.，周(Zhou)，J.，杨(Yang)，H.:M6 - rec:生成式预训练语言模型是开放式推荐系统。预印本库(arXiv)预印本arXiv:2205.08084(2022)

13. Dai, S., Shao, N., Zhao, H., Yu, W., Si, Z., Xu, C., Sun, Z., Zhang, X., Xu, J.: Uncovering chatgpt's capabilities in recommender systems. arXiv preprint arXiv:2305.02182 (2023)

13. 戴(Dai)，S.，邵(Shao)，N.，赵(Zhao)，H.，余(Yu)，W.，司(Si)，Z.，徐(Xu)，C.，孙(Sun)，Z.，张(Zhang)，X.，徐(Xu)，J.:揭示ChatGPT在推荐系统中的能力。预印本库(arXiv)预印本arXiv:2305.02182(2023)

14. Devlin, J., Chang, M.W., Lee, K., Toutanova, K.: Bert: Pre-training of deep bidirectional transformers for language understanding. In: NAACL (2019)

14. 德夫林(Devlin)，J.，张(Chang)，M.W.，李(Lee)，K.，图托纳娃(Toutanova)，K.:BERT:用于语言理解的深度双向变换器预训练。见:《北美计算语言学协会会议论文集》(NAACL)(2019)

15. Ding, H., Ma, Y., Deoras, A., Wang, Y., Wang, H.: Zero-shot recommender systems. arXiv:2105.08318 (2021)

15. 丁(Ding)，H.；马(Ma)，Y.；德奥拉什(Deoras)，A.；王(Wang)，Y.；王(Wang)，H.:零样本推荐系统。arXiv:2105.08318 (2021)

16. Ding, H., Ma, Y., Deoras, A., Wang, Y., Wang, H.: Zero-shot recommender systems. arXiv preprint arXiv:2105.08318 (2021)

16. 丁(Ding)，H.；马(Ma)，Y.；德奥拉什(Deoras)，A.；王(Wang)，Y.；王(Wang)，H.:零样本推荐系统。arXiv预印本 arXiv:2105.08318 (2021)

17. Fan, W., Zhao, Z., Li, J., Liu, Y., Mei, X., Wang, Y., Tang, J., Li, Q.: Recommender systems in the era of large language models (llms). arXiv preprint arXiv:2307.02046 (2023)

17. 范(Fan)，W.；赵(Zhao)，Z.；李(Li)，J.；刘(Liu)，Y.；梅(Mei)，X.；王(Wang)，Y.；唐(Tang)，J.；李(Li)，Q.:大语言模型(LLMs)时代的推荐系统。arXiv预印本 arXiv:2307.02046 (2023)

18. Fu, J., Yuan, F., Song, Y., Yuan, Z., Cheng, M., Cheng, S., Zhang, J., Wang, J., Pan, Y.: Exploring adapter-based transfer learning for recommender systems: Empirical studies and practical insights. CoRR abs/2305.15036 (2023). https://doi.org/10.48550/arXiv.2305.15036.https://doi.org/10.48550/ arXiv.2305.15036

18. 傅(Fu)，J.；袁(Yuan)，F.；宋(Song)，Y.；袁(Yuan)，Z.；程(Cheng)，M.；程(Cheng)，S.；张(Zhang)，J.；王(Wang)，J.；潘(Pan)，Y.:探索基于适配器的迁移学习在推荐系统中的应用:实证研究与实践见解。CoRR abs/2305.15036 (2023)。https://doi.org/10.48550/arXiv.2305.15036.https://doi.org/10.48550/ arXiv.2305.15036

19. Gao, C., Lin, T., Li, N., Jin, D., Li, Y.: Cross-platform item recommendation for online social e-commerce. TKDE $\mathbf{{35}}\left( 2\right) ,{1351} - {1364}$ (2023). https://doi.org/10.1109/TKDE.2021.3098702, https://doi.org/10.1109/TKDE 2021.3098702

19. 高(Gao)，C.；林(Lin)，T.；李(Li)，N.；金(Jin)，D.；李(Li)，Y.:在线社交电商的跨平台商品推荐。《知识与数据工程汇刊》(TKDE) $\mathbf{{35}}\left( 2\right) ,{1351} - {1364}$ (2023)。https://doi.org/10.1109/TKDE.2021.3098702, https://doi.org/10.1109/TKDE 2021.3098702

20. Gao, Y., Sheng, T., Xiang, Y., Xiong, Y., Wang, H., Zhang, J.: Chat-rec: Towards interactive and explainable llms-augmented recommender system. arXiv preprint arXiv:2303.14524 (2023)

20. 高(Gao)，Y.；盛(Sheng)，T.；向(Xiang)，Y.；熊(Xiong)，Y.；王(Wang)，H.；张(Zhang)，J.:Chat - rec:迈向交互式和可解释的大语言模型增强推荐系统。arXiv预印本 arXiv:2303.14524 (2023)

21. Geng, S., Liu, S., Fu, Z., Ge, Y., Zhang, Y.: Recommendation as language processing (RLP): A unified pretrain, personalized prompt & predict paradigm (P5). In: RecSys (2022)

21. 耿(Geng)，S.；刘(Liu)，S.；傅(Fu)，Z.；葛(Ge)，Y.；张(Zhang)，Y.:将推荐视为语言处理(RLP):一种统一的预训练、个性化提示与预测范式(P5)。见:推荐系统会议(RecSys) (2022)

22. Grbovic, M., Cheng, H.: Real-time personalization using embeddings for search ranking at airbnb. In: Guo, Y., Farooq, F. (eds.) Proceedings of the 24th ACM SIGKDD International Conference on Knowledge Discovery & Data Mining, KDD 2018, London, UK, August 19-23, 2018. pp. 311- 320. ACM (2018). https://doi.org/10.1145/3219819.3219885.https://doi.org/10 1145/3219819.3219885

22. 格博维奇(Grbovic)，M.；程(Cheng)，H.:爱彼迎(Airbnb)使用嵌入进行搜索排名的实时个性化。见:郭(Guo)，Y.；法鲁克(Farooq)，F.(编)《第24届ACM SIGKDD国际知识发现与数据挖掘会议论文集》，KDD 2018，英国伦敦，2018年8月19 - 23日。第311 - 320页。ACM (2018)。https://doi.org/10.1145/3219819.3219885.https://doi.org/10 1145/3219819.3219885

23. Guo, Q., Zhuang, F., Qin, C., Zhu, H., Xie, X., Xiong, H., He, Q.: A survey on knowledge graph-based recommender systems. TKDE 34(8), 3549-3568 (2020)

23. 郭(Guo)，Q.；庄(Zhuang)，F.；秦(Qin)，C.；朱(Zhu)，H.；谢(Xie)，X.；熊(Xiong)，H.；何(He)，Q.:基于知识图谱的推荐系统综述。《知识与数据工程汇刊》(TKDE) 34(8)，3549 - 3568 (2020)

24. Harper, F.M., Konstan, J.A.: The movielens datasets: History and context. TIIS $\mathbf{5}\left( 4\right) ,1 - {19}\left( {2015}\right)$

24. 哈珀(Harper)，F.M.；康斯坦(Konstan)，J.A.:MovieLens数据集:历史与背景。《信息系统专刊》(TIIS) $\mathbf{5}\left( 4\right) ,1 - {19}\left( {2015}\right)$

25. He, R., Kang, W.C., McAuley, J.: Translation-based recommendation. In: RecSys (2017)

25. 何(He)，R.；康(Kang)，W.C.；麦考利(McAuley)，J.:基于翻译的推荐。见:推荐系统会议(RecSys) (2017)

26. He, X., Deng, K., Wang, X., Li, Y., Zhang, Y., Wang, M.: Lightgen: Simplifying and powering graph convolution network for recommendation. In: SIGIR (2020)

26. 何(He)，X.；邓(Deng)，K.；王(Wang)，X.；李(Li)，Y.；张(Zhang)，Y.；王(Wang)，M.:Lightgen:简化并增强用于推荐的图卷积网络。见:信息检索研究与发展会议(SIGIR) (2020)

27. He, Z., Xie, Z., Jha, R., Steck, H., Liang, D., Feng, Y., Majumder, B.P., Kallus, N., McAuley, J.: Large language models as zero-shot conversational recommenders. In: CIKM (2023)

27. 何(He)，Z.；谢(Xie)，Z.；贾(Jha)，R.；斯特克(Steck)，H.；梁(Liang)，D.；冯(Feng)，Y.；马宗达(Majumder)，B.P.；卡卢斯(Kallus)，N.；麦考利(McAuley)，J.:大语言模型作为零样本对话式推荐器。见:信息与知识管理会议(CIKM) (2023)

28. Hidasi, B., Karatzoglou, A., Baltrunas, L., Tikk, D.: Session-based recommendations with recurrent neural networks. In: ICLR (2016)

28. 希达西(Hidasi)，B.；卡拉佐格鲁(Karatzoglou)，A.；巴尔图纳斯(Baltrunas)，L.；蒂克(Tikk)，D.:基于循环神经网络的会话式推荐。见:国际学习表征会议(ICLR) (2016)

29. Hou, Y., He, Z., McAuley, J., Zhao, W.X.: Learning vector-quantized item representation for transferable sequential recommenders. In: WWW (2023)

29. 侯(Hou)，Y.；何(He)，Z.；麦考利(McAuley)，J.；赵(Zhao)，W.X.:为可迁移序列推荐器学习向量量化的商品表示。见:万维网会议(WWW) (2023)

30. Hou, Y., Mu, S., Zhao, W.X., Li, Y., Ding, B., Wen, J.: Towards universal sequence representation learning for recommender systems. In: KDD (2022)

30. 侯(Hou)，Y.；穆(Mu)，S.；赵(Zhao)，W.X.；李(Li)，Y.；丁(Ding)，B.；文(Wen)，J.:迈向推荐系统的通用序列表示学习。见:知识发现与数据挖掘会议(KDD) (2022)

31. Hua, W., Xu, S., Ge, Y., Zhang, Y.: How to index item ids for recommendation foundation models. arXiv preprint arXiv:2305.06569 (2023)

31. 华(Hua)、徐(Xu)、葛(Ge)、张(Zhang):如何为推荐基础模型对物品ID进行索引。预印本arXiv:2305.06569 (2023)

32. Jiang, A.Q., Sablayrolles, A., Mensch, A., Bamford, C., Chaplot, D.S., Casas, D.d.l., Bressand, F., Lengyel, G., Lample, G., Saulnier, L., et al.: Mistral 7b. arXiv preprint arXiv:2310.06825 (2023)

32. 蒋(Jiang)、萨布莱罗勒斯(Sablayrolles)、门施(Mensch)、班福德(Bamford)、查普洛特(Chaplot)、德拉斯卡萨斯(d.l. Casas)、布雷桑(Bressand)、伦吉尔(Lengyel)、兰普尔(Lample)、索尔尼尔(Saulnier)等:米斯特拉尔7B模型(Mistral 7b)。预印本arXiv:2310.06825 (2023)

33. Kang, W., McAuley, J.: Self-attentive sequential recommendation. In: ICDM (2018)

33. 康(Kang)、麦考利(McAuley):自注意力序列推荐。见:国际数据挖掘会议(ICDM)(2018)

34. Kang, W.C., Ni, J., Mehta, N., Sathiamoorthy, M., Hong, L., Chi, E., Cheng, D.Z.: Do llms understand user preferences? evaluating llms on user rating prediction. arXiv preprint arXiv:2305.06474 (2023)

34. 康(Kang)、倪(Ni)、梅塔(Mehta)、萨蒂亚莫尔蒂(Sathiamoorthy)、洪(Hong)、池(Chi)、程(Cheng):大语言模型是否理解用户偏好？基于用户评分预测对大语言模型的评估。预印本arXiv:2305.06474 (2023)

35. Knuth, D.E., Morris, Jr, J.H., Pratt, V.R.: Fast pattern matching in strings. SIAM journal on computing $\mathbf{6}\left( 2\right) ,{323} - {350}\left( {1977}\right)$

35. 克努斯(Knuth)、小莫里斯(Morris)、普拉特(Pratt):字符串中的快速模式匹配。《工业与应用数学学会计算期刊》$\mathbf{6}\left( 2\right) ,{323} - {350}\left( {1977}\right)$

36. Li, J., Zhang, W., Wang, T., Xiong, G., Lu, A., Medioni, G.: GPT4Rec: A Generative Framework for Personalized Recommendation and User Interests Interpretation (Apr 2023)

36. 李(Li)、张(Zhang)、王(Wang)、熊(Xiong)、陆(Lu)、梅廖尼(Medioni):GPT4Rec:用于个性化推荐和用户兴趣解读的生成式框架(2023年4月)

37. Li, L., Zhang, Y., Chen, L.: Personalized prompt learning for explainable recommendation. TOIS $\mathbf{{41}}\left( 4\right) ,1 - {26}\left( {2023}\right)$

37. 李(Li)、张(Zhang)、陈(Chen):用于可解释推荐的个性化提示学习。《信息系统学报》$\mathbf{{41}}\left( 4\right) ,1 - {26}\left( {2023}\right)$

38. Li, R., Deng, W., Cheng, Y., Yuan, Z., Zhang, J., Yuan, F.: Exploring the upper limits of text-based collaborative filtering using large language models: Discoveries and insights. CoRR abs/2305.11700 (2023). https://doi.org/10.48550/arXiv.2305.11700.https://doi.org/10.48550/arXiv 2305.11700

38. 李(Li)、邓(Deng)、程(Cheng)、袁(Yuan)、张(Zhang)、袁(Yuan):利用大语言模型探索基于文本的协同过滤的上限:发现与见解。预印本库CoRR abs/2305.11700 (2023)。https://doi.org/10.48550/arXiv.2305.11700.https://doi.org/10.48550/arXiv 2305.11700

39. Li, X., Zhang, Y., Malthouse, E.C.: Pbnr: Prompt-based news recommender system. arXiv preprint arXiv:2304.07862 (2023)

39. 李(Li)、张(Zhang)、马尔豪斯(Malthouse):Pbnr:基于提示的新闻推荐系统。预印本arXiv:2304.07862 (2023)

40. Lin, G., Zhang, Y.: Sparks of artificial general recommender (agr): Early experiments with chatgpt. arXiv preprint arXiv:2305.04518 (2023)

40. 林(Lin)、张(Zhang):通用推荐人工智能(AGR)的火花:ChatGPT的早期实验。预印本arXiv:2305.04518 (2023)

41. Liu, J., Liu, C., Lv, R., Zhou, K., Zhang, Y.: Is ChatGPT a Good Recommender? A Preliminary Study (Apr 2023)

41. 刘(Liu)、刘(Liu)、吕(Lv)、周(Zhou)、张(Zhang):ChatGPT是一个好的推荐器吗？初步研究(2023年4月)

42. Liu, P., Zhang, L., Gulla, J.A.: Pre-train, prompt and recommendation: A comprehensive survey of language modelling paradigm adaptations in recommender systems. arXiv preprint arXiv:2302.03735 (2023)

42. 刘(Liu)、张(Zhang)、古拉(Gulla):预训练、提示与推荐:推荐系统中语言建模范式适应的全面综述。预印本arXiv:2302.03735 (2023)

43. Liu, Q., Chen, N., Sakai, T., Wu, X.M.: A first look at llm-powered generative news recommendation. arXiv preprint arXiv:2305.06566 (2023)

43. 刘(Liu)、陈(Chen)、酒井(Sakai)、吴(Wu):大语言模型驱动的生成式新闻推荐初探。预印本arXiv:2305.06566 (2023)

44. Lu, Y., Bartolo, M., Moore, A., Riedel, S., Stenetorp, P.: Fantastically ordered prompts and where to find them: Overcoming few-shot prompt order sensitivity. In: ACL (2022)

44. 陆(Lu)、巴托洛(Bartolo)、摩尔(Moore)、里德尔(Riedel)、斯特内托普(Stenetorp):奇妙排序的提示及其寻找方法:克服少样本提示顺序敏感性。见:计算语言学协会年会(ACL)(2022)

45. Man, T., Shen, H., Jin, X., Cheng, X.: Cross-domain recommendation: An embedding and mapping approach. In: Sierra, C. (ed.) Proceedings of the Twenty-Sixth International Joint Conference on Artificial Intelligence, IJ-CAI 2017, Melbourne, Australia, August 19-25, 2017. pp. 2464-2470. ij-cai.org (2017). https://doi.org/10.24963/ijcai.2017/343, https://doi.org/10 24963/ijcai.2017/343

45. 满(Man)、沈(Shen)、金(Jin)、程(Cheng):跨领域推荐:一种嵌入与映射方法。见:塞拉(Sierra)(编)《第二十六届国际人工智能联合会议(IJ - CAI 2017)论文集》，澳大利亚墨尔本，2017年8月19 - 25日。第2464 - 2470页。ij - cai.org (2017)。https://doi.org/10.24963/ijcai.2017/343, https://doi.org/10 24963/ijcai.2017/343

46. Ni, J., Li, J., McAuley, J.: Justifying recommendations using distantly-labeled reviews and fine-grained aspects. In: EMNLP. pp. 188-197 (2019)

46. 倪(Ni)、李(Li)、麦考利(McAuley):使用远监督标注的评论和细粒度方面为推荐提供理由。见:自然语言处理经验方法会议(EMNLP)。第188 - 197页 (2019)

47. Ouyang, L., Wu, J., Jiang, X., Almeida, D., Wainwright, C., Mishkin, P., Zhang, C., Agarwal, S., Slama, K., Ray, A., et al.: Training language models to follow instructions with human feedback. NeurIPS 35, 27730-27744 (2022)

47. 欧阳(Ouyang)、L.，吴(Wu)、J.，江(Jiang)、X.，阿尔梅达(Almeida)、D.，温赖特(Wainwright)、C.，米什金(Mishkin)、P.，张(Zhang)、C.，阿加瓦尔(Agarwal)、S.，斯拉马(Slama)、K.，雷(Ray)、A.等:通过人类反馈训练语言模型以遵循指令。《神经信息处理系统大会论文集》(NeurIPS)35，27730 - 27744(2022)

48. Ren, X., Wei, W., Xia, L., Su, L., Cheng, S., Wang, J., Yin, D., Huang, C.: Representation learning with large language models for recommendation. arXiv preprint arXiv:2310.15950 (2023)

48. 任(Ren)、X.，魏(Wei)、W.，夏(Xia)、L.，苏(Su)、L.，程(Cheng)、S.，王(Wang)、J.，尹(Yin)、D.，黄(Huang)、C.:利用大语言模型进行推荐的表征学习。预印本arXiv:2310.15950(2023)

49. Rendle, S., Freudenthaler, C., Gantner, Z., Schmidt-Thieme, L.: BPR: bayesian personalized ranking from implicit feedback. In: UAI (2009)

49. 伦德尔(Rendle)、S.，弗罗伊登塔勒(Freudenthaler)、C.，甘特纳(Gantner)、Z.，施密特 - 蒂梅(Schmidt - Thieme)、L.:BPR:基于隐式反馈的贝叶斯个性化排序。见:《人工智能中的不确定性会议》(UAI)(2009)

50. Robertson, S.E., Zaragoza, H.: The probabilistic relevance framework: BM25 and beyond. Found. Trends Inf. Retr. $\mathbf{3}\left( 4\right) ,{333} - {389}\left( {2009}\right)$

50. 罗伯逊(Robertson)、S.E.，萨拉戈萨(Zaragoza)、H.:概率相关性框架:BM25及其扩展。《信息检索趋势基础》$\mathbf{3}\left( 4\right) ,{333} - {389}\left( {2009}\right)$

51. Roitero, K., Carterette, B., Mehrotra, R., Lalmas, M.: Leveraging behavioral heterogeneity across markets for cross-market training of recommender systems. In: Seghrouchni, A.E.F., Sukthankar, G., Liu, T., van Steen, M. (eds.) WWW. pp. 694-702. ACM / IW3C2 (2020). https://doi.org/10.1145/3366424.3384362.https://doi.org/10.1145/3366424.3384362

51. 罗伊特罗(Roitero)、K.，卡特雷特(Carterette)、B.，梅赫罗特拉(Mehrotra)、R.，拉尔马斯(Lalmas)、M.:利用跨市场的行为异质性进行推荐系统的跨市场训练。见:塞格鲁奇尼(Seghrouchni)、A.E.F.，苏克坦卡尔(Sukthankar)、G.，刘(Liu)、T.，范斯滕(van Steen)、M.(编)《万维网会议》(WWW)。第694 - 702页。美国计算机协会(ACM)/万维网联盟(IW3C2)(2020)。https://doi.org/10.1145/3366424.3384362.https://doi.org/10.1145/3366424.3384362

52. Sanh, V., Webson, A., Raffel, C., Bach, S.H., Sutawika, L., Alyafeai, Z., Chaffin, A., Stiegler, A., Raja, A., Dey, M., Bari, M.S., Xu, C., Thakker, U., Sharma, S.S., Szczechla, E., Kim, T., Chhablani, G., Nayak, N.V., Datta, D., Chang, J., Jiang, M.T., Wang, H., Manica, M., Shen, S., Yong, Z.X., Pandey, H., Bawden, R., Wang, T., Neeraj, T., Rozen, J., Sharma, A., Santilli, A., Févry, T., Fries, J.A., Teehan, R., Scao, T.L., Biderman, S., Gao, L., Wolf, T., Rush, A.M.: Multitask prompted training enables zero-shot task generalization. In: ICLR (2022)

52. 桑(Sanh)、V.，韦伯森(Webson)、A.，拉菲尔(Raffel)、C.，巴赫(Bach)、S.H.，苏塔维卡(Sutawika)、L.，阿利亚菲(Alyafeai)、Z.，查芬(Chaffin)、A.，施蒂格勒(Stiegler)、A.，拉贾(Raja)、A.，戴(Dey)、M.，巴里(Bari)、M.S.，徐(Xu)、C.，萨克(Thakker)、U.，夏尔马(Sharma)、S.S.，什切赫拉(Szczechla)、E.，金(Kim)、T.，查布拉尼(Chhablani)、G.，纳亚克(Nayak)、N.V.，达塔(Datta)、D.，张(Chang)、J.，江(Jiang)、M.T.，王(Wang)、H.，马尼卡(Manica)、M.，沈(Shen)、S.，勇(Yong)、Z.X.，潘迪(Pandey)、H.，鲍登(Bawden)、R.，王(Wang)、T.，尼拉杰(Neeraj)、T.，罗森(Rozen)、J.，夏尔马(Sharma)、A.，桑蒂利(Santilli)、A.，费夫里(Févry)、T.，弗里斯(Fries)、J.A.，蒂汉(Teehan)、R.，斯考(Scao)、T.L.，比德曼(Biderman)、S.，高(Gao)、L.，沃尔夫(Wolf)、T.，拉什(Rush)、A.M.:多任务提示训练实现零样本任务泛化。见:《国际学习表征会议》(ICLR)(2022)

53. Shin, K., Kwak, H., Kim, K., Kim, S.Y., Ramström, M.N.: Scaling law for recommendation models: Towards general-purpose user representations. CoRR abs/2111.11294 (2021), https://arxiv.org/abs/2111.11294

53. 申(Shin)、K.，郭(Kwak)、H.，金(Kim)、K.，金(Kim)、S.Y.，拉姆斯特伦(Ramström)、M.N.:推荐模型的缩放定律:迈向通用用户表征。预印本库CoRR abs/2111.11294(2021)，https://arxiv.org/abs/2111.11294

54. Tang, J., Wang, K.: Personalized top-n sequential recommendation via convolutional sequence embedding. In: Chang, Y., Zhai, C., Liu, Y., Maarek, Y. (eds.) Proceedings of the Eleventh ACM International Conference on Web Search and Data Mining, WSDM 2018, Marina Del Rey, CA, USA, February 5-9, 2018. pp. 565-573. ACM (2018). https://doi.org/10.1145/3159652.3159656.https://doi.org/10.1145/3159652.3159656

54. 唐(Tang)、J.，王(Wang)、K.:通过卷积序列嵌入实现个性化的前n个序列推荐。见:张(Chang)、Y.，翟(Zhai)、C.，刘(Liu)、Y.，马雷克(Maarek)、Y.(编)《第十一届ACM国际网络搜索与数据挖掘会议论文集》(WSDM 2018)，美国加利福尼亚州马里纳德尔雷，2018年2月5 - 9日。第565 - 573页。美国计算机协会(ACM)(2018)。https://doi.org/10.1145/3159652.3159656.https://doi.org/10.1145/3159652.3159656

55. Taori, R., Gulrajani, I., Zhang, T., Dubois, Y., Li, X., Guestrin, C., Liang, P., Hashimoto, T.B.: Stanford alpaca: An instruction-following llama model (2023)

55. 陶里(Taori)、R.，古拉贾尼(Gulrajani)、I.，张(Zhang)、T.，杜波依斯(Dubois)、Y.，李(Li)、X.，格斯特林(Guestrin)、C.，梁(Liang)、P.，桥本(Hashimoto)、T.B.:斯坦福羊驼(Stanford alpaca):一个遵循指令的羊驼模型(2023)

56. Touvron, H., Lavril, T., Izacard, G., Martinet, X., Lachaux, M.A., Lacroix, T., Rozière, B., Goyal, N., Hambro, E., Azhar, F., et al.: Llama: Open and efficient foundation language models. arXiv preprint arXiv:2302.13971 (2023)

56. 图夫龙(Touvron)、H.，拉夫里尔(Lavril)、T.，伊扎卡尔(Izacard)、G.，马蒂内(Martinet)、X.，拉肖(Lachaux)、M.A.，拉科鲁瓦(Lacroix)、T.，罗齐埃(Rozière)、B.，戈亚尔(Goyal)、N.，汉布罗(Hambro)、E.，阿扎尔(Azhar)、F.等:羊驼(Llama):开放且高效的基础语言模型。预印本arXiv:2302.13971(2023)

57. Touvron, H., Martin, L., Stone, K., Albert, P., Almahairi, A., Babaei, Y., Bashlykov, N., Batra, S., Bhargava, P., Bhosale, S., et al.: Llama 2: Open foundation and fine-tuned chat models. arXiv preprint arXiv:2307.09288 (2023)

57. 图夫龙(Touvron)，H.、马丁(Martin)，L.、斯通(Stone)，K.、阿尔伯特(Albert)，P.、阿尔马海里(Almahairi)，A.、巴巴埃伊(Babaei)，Y.、巴什利科夫(Bashlykov)，N.、巴特拉(Batra)，S.、巴尔加瓦(Bhargava)，P.、博萨尔(Bhosale)，S.等:《Llama 2:开放基础模型和微调聊天模型》。预印本 arXiv:2307.09288 (2023)

58. Wang, J., Yuan, F., Cheng, M., Jose, J.M., Yu, C.: Beibei kong, zhijin wang, bo hu, and zang li. 2022. transrec: Learning transferable recommendation from mixture-of-modality feedback. arXiv preprint arXiv:2206.06190 (2022)

58. 王(Wang)，J.、袁(Yuan)，F.、程(Cheng)，M.、何塞(Jose)，J.M.、余(Yu)，C.:《贝贝·孔(Beibei Kong)、志金·王(Zhijin Wang)、博·胡(Bo Hu)和臧·李(Zang Li)》。2022 年。《TransRec:从多模态反馈中学习可迁移推荐》。预印本 arXiv:2206.06190 (2022)

59. Wang, L., Lim, E.P.: Zero-shot next-item recommendation using large pretrained language models. arXiv preprint arXiv:2304.03153 (2023)

59. 王(Wang)，L.、林(Lim)，E.P.:《使用大型预训练语言模型进行零样本下一项推荐》。预印本 arXiv:2304.03153 (2023)

60. Wang, W., Lin, X., Feng, F., He, X., Chua, T.S.: Generative recommendation: Towards next-generation recommender paradigm. arXiv preprint arXiv:2304.03516 (2023)

60. 王(Wang)，W.、林(Lin)，X.、冯(Feng)，F.、何(He)，X.、蔡(Chua)，T.S.:《生成式推荐:迈向下一代推荐范式》。预印本 arXiv:2304.03516 (2023)

61. Wang, X., Tang, X., Zhao, W.X., Wang, J., Wen, J.R.: Rethinking the evaluation for conversational recommendation in the era of large language models. arXiv preprint arXiv:2305.13112 (2023)

61. 王(Wang)，X.、唐(Tang)，X.、赵(Zhao)，W.X.、王(Wang)，J.、文(Wen)，J.R.:《重新思考大语言模型时代对话式推荐的评估》。预印本 arXiv:2305.13112 (2023)

62. Wang, X., Zhou, K., Wen, J., Zhao, W.X.: Towards unified conversational recommender systems via knowledge-enhanced prompt learning. In: KDD (2022)

62. 王(Wang)，X.、周(Zhou)，K.、文(Wen)，J.、赵(Zhao)，W.X.:《通过知识增强提示学习实现统一对话式推荐系统》。见:《知识发现与数据挖掘会议(KDD)》(2022)

63. Wang, Y., Jiang, Z., Chen, Z., Yang, F., Zhou, Y., Cho, E., Fan, X., Huang, X., Lu, Y., Yang, Y.: Recmind: Large language model powered agent for recommendation. arXiv preprint arXiv:2308.14296 (2023)

63. 王(Wang)，Y.、江(Jiang)，Z.、陈(Chen)，Z.、杨(Yang)，F.、周(Zhou)，Y.、赵(Cho)，E.、范(Fan)，X.、黄(Huang)，X.、陆(Lu)，Y.、杨(Yang)，Y.:《RecMind:由大语言模型驱动的推荐代理》。预印本 arXiv:2308.14296 (2023)

64. Wei, J., Bosma, M., Zhao, V.Y., Guu, K., Yu, A.W., Lester, B., Du, N., Dai, A.M., Le, Q.V.: Finetuned language models are zero-shot learners. In: ICLR (2022)

64. 魏(Wei)，J.、博斯马(Bosma)，M.、赵(Zhao)，V.Y.、古(Guu)，K.、余(Yu)，A.W.、莱斯特(Lester)，B.、杜(Du)，N.、戴(Dai)，A.M.、乐(Le)，Q.V.:《微调语言模型是零样本学习者》。见:《国际学习表征会议(ICLR)》(2022)

65. Wei, W., Ren, X., Tang, J., Wang, Q., Su, L., Cheng, S., Wang, J., Yin, D., Huang, C.: Llmrec: Large language models with graph augmentation for recommendation. In: WSDM (2024)

65. 魏(Wei)，W.、任(Ren)，X.、唐(Tang)，J.、王(Wang)，Q.、苏(Su)，L.、程(Cheng)，S.、王(Wang)，J.、尹(Yin)，D.、黄(Huang)，C.:《LlmRec:用于推荐的图增强大语言模型》。见:《网络搜索与数据挖掘会议(WSDM)》(2024)

66. Wu, L., Zheng, Z., Qiu, Z., Wang, H., Gu, H., Shen, T., Qin, C., Zhu, C., Zhu, H., Liu, Q., et al.: A survey on large language models for recommendation. arXiv preprint arXiv:2305.19860 (2023)

66. 吴(Wu)，L.、郑(Zheng)，Z.、邱(Qiu)，Z.、王(Wang)，H.、顾(Gu)，H.、沈(Shen)，T.、秦(Qin)，C.、朱(Zhu)，C.、朱(Zhu)，H.、刘(Liu)，Q.等:《用于推荐的大语言模型综述》。预印本 arXiv:2305.19860 (2023)

67. Wu, L., Zheng, Z., Qiu, Z., Wang, H., Gu, H., Shen, T., Qin, C., Zhu, C., Zhu, H., Liu, Q., et al.: A survey on large language models for recommendation. arXiv preprint arXiv:2305.19860 (2023)

67. 吴(Wu)，L.、郑(Zheng)，Z.、邱(Qiu)，Z.、王(Wang)，H.、顾(Gu)，H.、沈(Shen)，T.、秦(Qin)，C.、朱(Zhu)，C.、朱(Zhu)，H.、刘(Liu)，Q.等:《用于推荐的大语言模型综述》。预印本 arXiv:2305.19860 (2023)

68. Xiao, S., Liu, Z., Shao, Y., Di, T., Middha, B., Wu, F., Xie, X.: Training large-scale news recommenders with pretrained language models in the loop. In: Zhang, A., Rangwala, H. (eds.) KDD '22: The 28th ACM SIGKDD Conference on Knowledge Discovery and Data Mining, Washington, DC, USA, August 14 - 18, 2022. pp. 4215-4225. ACM (2022). https://doi.org/10.1145/3534678.3539120.https://doi org/10.1145/3534678.3539120

68. 肖(Xiao)，S.、刘(Liu)，Z.、邵(Shao)，Y.、迪(Di)，T.、米德哈(Middha)，B.、吴(Wu)，F.、谢(Xie)，X.:《在循环中使用预训练语言模型训练大规模新闻推荐器》。见:张(Zhang)，A.、兰加拉(Rangwala)，H.(编)《第 28 届 ACM SIGKDD 知识发现与数据挖掘会议(KDD '22)》，美国华盛顿特区，2022 年 8 月 14 - 18 日。第 4215 - 4225 页。美国计算机协会(ACM)(2022)。https://doi.org/10.1145/3534678.3539120.https://doi org/10.1145/3534678.3539120

69. Yuan, F., He, X., Karatzoglou, A., Zhang, L.: Parameter-efficient transfer from sequential behaviors for user modeling and recommendation. In: Huang, J.X., Chang, Y., Cheng, X., Kamps, J., Murdock, V., Wen, J., Liu, Y. (eds.) SIGIR (2020)

69. 袁(Yuan)，F.、何(He)，X.、卡拉佐格鲁(Karatzoglou)，A.、张(Zhang)，L.:《从序列行为进行参数高效迁移以用于用户建模和推荐》。见:黄(Huang)，J.X.、张(Chang)，Y.、程(Cheng)，X.、坎普斯(Kamps)，J.、默多克(Murdock)，V.、文(Wen)，J.、刘(Liu)，Y.(编)《信息检索研究与发展会议(SIGIR)》(2020)

70. Yuan, F., Zhang, G., Karatzoglou, A., Jose, J.M., Kong, B., Li, Y.: One person, one model, one world: Learning continual user representation without forgetting. In: Diaz, F., Shah, C., Suel, T., Castells, P., Jones, R., Sakai, T. (eds.) SIGIR (2021)

70. 袁(Yuan)，F.、张(Zhang)，G.、卡拉佐格鲁(Karatzoglou)，A.、何塞(Jose)，J.M.、孔(Kong)，B.、李(Li)，Y.:《一人、一模型、一世界:在不遗忘的情况下学习持续用户表示》。见:迪亚兹(Diaz)，F.、沙阿(Shah)，C.、苏埃尔(Suel)，T.、卡斯特尔斯(Castells)，P.、琼斯(Jones)，R.、酒井(Sakai)，T.(编)《信息检索研究与发展会议(SIGIR)》(2021)

71. Zang, T., Zhu, Y., Liu, H., Zhang, R., Yu, J.: A survey on cross-domain recommendation: Taxonomies, methods, and future directions. ACM Trans. Inf. Syst. 41(2), 42:1-42:39 (2023). https://doi.org/10.1145/3548455.https://doi.org/10.1145/ 3548455

71. 臧(Zang)，T.；朱(Zhu)，Y.；刘(Liu)，H.；张(Zhang)，R.；余(Yu)，J.:跨领域推荐综述:分类、方法和未来方向。《ACM信息系统汇刊》41(2)，42:1 - 42:39 (2023)。https://doi.org/10.1145/3548455.https://doi.org/10.1145/ 3548455

72. Zhang, J., Bao, K., Zhang, Y., Wang, W., Feng, F., He, X.: Is chatgpt fair for recommendation? evaluating fairness in large language model recommendation. arXiv preprint arXiv:2305.07609 (2023)

72. 张(Zhang)，J.；鲍(Bao)，K.；张(Zhang)，Y.；王(Wang)，W.；冯(Feng)，F.；何(He)，X.:ChatGPT在推荐任务中公平吗？评估大语言模型推荐中的公平性。预印本arXiv:2305.07609 (2023)

73. Zhang, J., Hou, Y., Xie, R., Sun, W., McAuley, J., Zhao, W.X., Lin, L., Wen, J.R.: Agentcf: Collaborative learning with autonomous language agents for recommender systems. arXiv preprint arXiv:2310.09233 (2023)

73. 张(Zhang)，J.；侯(Hou)，Y.；谢(Xie)，R.；孙(Sun)，W.；麦考利(McAuley)，J.；赵(Zhao)，W.X.；林(Lin)，L.；文(Wen)，J.R.:Agentcf:面向推荐系统的自主语言智能体协作学习。预印本arXiv:2310.09233 (2023)

74. Zhang, J., Xie, R., Hou, Y., Zhao, W.X., Lin, L., Wen, J.R.: Recommendation as instruction following: A large language model empowered recommendation approach. arXiv preprint arXiv:2305.07001 (2023)

74. 张(Zhang)，J.；谢(Xie)，R.；侯(Hou)，Y.；赵(Zhao)，W.X.；林(Lin)，L.；文(Wen)，J.R.:将推荐视为指令遵循:一种大语言模型赋能的推荐方法。预印本arXiv:2305.07001 (2023)

75. Zhang, Z., Wang, B.: Prompt learning for news recommendation. arXiv preprint arXiv:2304.05263 (2023)

75. 张(Zhang)，Z.；王(Wang)，B.:用于新闻推荐的提示学习。预印本arXiv:2304.05263 (2023)

76. Zhao, C., Li, C., Xiao, R., Deng, H., Sun, A.: CATN: cross-domain recommendation for cold-start users via aspect transfer network. In: Huang, J.X., Chang, Y., Cheng, X., Kamps, J., Murdock, V., Wen, J., Liu, Y. (eds.) SI-GIR. pp. 229-238. ACM (2020). https://doi.org/10.1145/3397271.3401169.https: //doi.org/10.1145/3397271.3401169

76. 赵(Zhao)，C.；李(Li)，C.；肖(Xiao)，R.；邓(Deng)，H.；孙(Sun)，A.:CATN:通过方面转移网络为冷启动用户进行跨领域推荐。见:黄(Huang)，J.X.；张(Chang)，Y.；程(Cheng)，X.；坎普斯(Kamps)，J.；默多克(Murdock)，V.；文(Wen)，J.；刘(Liu)，Y.(编)《SI - GIR》。第229 - 238页。ACM (2020)。https://doi.org/10.1145/3397271.3401169.https: //doi.org/10.1145/3397271.3401169

77. Zhao, W.X., Lin, Z., Feng, Z., Wang, P., Wen, J.R.: A revisiting study of appropriate offline evaluation for top-n recommendation algorithms. ACM Transactions on Information Systems $\mathbf{{41}}\left( 2\right) ,1 - {41}\left( {2022}\right)$

77. 赵(Zhao)，W.X.；林(Lin)，Z.；冯(Feng)，Z.；王(Wang)，P.；文(Wen)，J.R.:对Top - N推荐算法合适的离线评估的再研究。《ACM信息系统汇刊》$\mathbf{{41}}\left( 2\right) ,1 - {41}\left( {2022}\right)$

78. Zhao, W.X., Mu, S., Hou, Y., Lin, Z., Chen, Y., Pan, X., Li, K., Lu, Y., Wang, H., Tian, C., Min, Y., Feng, Z., Fan, X., Chen, X., Wang, P., Ji, W., Li, Y., Wang, X., Wen, J.R.: Recbole: Towards a unified, comprehensive and efficient framework for recommendation algorithms. In: CIKM (2021)

78. 赵(Zhao)，W.X.；穆(Mu)，S.；侯(Hou)，Y.；林(Lin)，Z.；陈(Chen)，Y.；潘(Pan)，X.；李(Li)，K.；陆(Lu)，Y.；王(Wang)，H.；田(Tian)，C.；闵(Min)，Y.；冯(Feng)，Z.；范(Fan)，X.；陈(Chen)，X.；王(Wang)，P.；季(Ji)，W.；李(Li)，Y.；王(Wang)，X.；文(Wen)，J.R.:Recbole:迈向一个统一、全面且高效的推荐算法框架。见:《CIKM》(2021)

79. Zhao, W.X., Zhou, K., Li, J., Tang, T., Wang, X., Hou, Y., Min, Y., Zhang, B., Zhang, J., Dong, Z., Du, Y., Yang, C., Chen, Y., Chen, Z., Jiang, J., Ren, R., Li, Y., Tang, X., Liu, Z., Liu, P., Nie, J.Y., Wen, J.R.: A survey of large language models. arXiv preprint arXiv:2303.18223 (2023)

79. 赵(Zhao)，W.X.；周(Zhou)，K.；李(Li)，J.；唐(Tang)，T.；王(Wang)，X.；侯(Hou)，Y.；闵(Min)，Y.；张(Zhang)，B.；张(Zhang)，J.；董(Dong)，Z.；杜(Du)，Y.；杨(Yang)，C.；陈(Chen)，Y.；陈(Chen)，Z.；江(Jiang)，J.；任(Ren)，R.；李(Li)，Y.；唐(Tang)，X.；刘(Liu)，Z.；刘(Liu)，P.；聂(Nie)，J.Y.；文(Wen)，J.R.:大语言模型综述。预印本arXiv:2303.18223 (2023)

80. Zhao, Z., Wallace, E., Feng, S., Klein, D., Singh, S.: Calibrate before use: Improving few-shot performance of language models. In: ICML (2021)

80. 赵(Zhao)，Z.；华莱士(Wallace)，E.；冯(Feng)，S.；克莱因(Klein)，D.；辛格(Singh)，S.:使用前校准:提高语言模型的少样本性能。见:《ICML》(2021)

81. Zheng, B., Hou, Y., Lu, H., Chen, Y., Zhao, W.X., Wen, J.R.: Adapting large language models by integrating collaborative semantics for recommendation. arXiv preprint arXiv:2311.09049 (2023)

81. 郑(Zheng)，B.；侯(Hou)，Y.；陆(Lu)，H.；陈(Chen)，Y.；赵(Zhao)，W.X.；文(Wen)，J.R.:通过集成协作语义来适配大语言模型进行推荐。预印本arXiv:2311.09049 (2023)

82. Zhou, K., Wang, H., Zhao, W.X., Zhu, Y., Wang, S., Zhang, F., Wang, Z., Wen, J.: S3-rec: Self-supervised learning for sequential recommendation with mutual information maximization. In: CIKM (2020)

82. 周(Zhou)、王(Wang)、赵(Zhao)、朱(Zhu)、王(Wang)、张(Zhang)、王(Wang)、文(Wen):S3 - 推荐(S3 - rec):通过互信息最大化进行序列推荐的自监督学习。见:《信息与知识管理国际会议》(CIKM)(2020)

83. Zhu, F., Chen, C., Wang, Y., Liu, G., Zheng, X.: DTCDR: A framework for dual-target cross-domain recommendation. In: Zhu, W., Tao, D., Cheng, X., Cui, P., Rundensteiner, E.A., Carmel, D., He, Q., Yu, J.X. (eds.) CIKM. pp. 1533- 1542. ACM (2019). https://doi.org/10.1145/3357384.3357992.https://doi.org/ 10.1145/3357384.3357992

83. 朱(Zhu)、陈(Chen)、王(Wang)、刘(Liu)、郑(Zheng):DTCDR:双目标跨领域推荐框架。见:朱(Zhu)、陶(Tao)、程(Cheng)、崔(Cui)、伦登施泰纳(Rundensteiner)、卡梅尔(Carmel)、何(He)、余(Yu)(编)《信息与知识管理国际会议》(CIKM)。第1533 - 1542页。美国计算机协会(ACM)(2019)。https://doi.org/10.1145/3357384.3357992.https://doi.org/ 10.1145/3357384.3357992

84. Zhu, F., Wang, Y., Chen, C., Liu, G., Zheng, X.: A graphical and attentional framework for dual-target cross-domain recommendation. In: Bessiere, C. (ed.) IJCAI. pp. 3001-3008. ijcai.org (2020). https://doi.org/10.24963/ijcai.2020/415.https://doi.org/10.24963/ijcai.2020/415

84. 朱(Zhu)、王(Wang)、陈(Chen)、刘(Liu)、郑(Zheng):双目标跨领域推荐的图形与注意力框架。见:贝西埃(Bessiere)(编)《国际人工智能联合会议》(IJCAI)。第3001 - 3008页。ijcai.org(2020)。https://doi.org/10.24963/ijcai.2020/415.https://doi.org/10.24963/ijcai.2020/415

85. Zhu, F., Wang, Y., Chen, C., Zhou, J., Li, L., Liu, G.: Cross-domain recommendation: Challenges, progress, and prospects. In: Zhou, Z. (ed.) Proceedings of the Thirtieth International Joint Conference on Artificial Intelligence, IJCAI 2021, Virtual Event / Montreal, Canada, 19-27 August 2021. pp. 4721-4728. ijcai.org (2021). https://doi.org/10.24963/ijcai.2021/639 https://doi.org/10 24963/ijcai.2021/639

85. 朱(Zhu)、王(Wang)、陈(Chen)、周(Zhou)、李(Li)、刘(Liu):跨领域推荐:挑战、进展与展望。见:周(Zhou)(编)《第三十届国际人工智能联合会议论文集》(Proceedings of the Thirtieth International Joint Conference on Artificial Intelligence)，IJCAI 2021，虚拟会议/加拿大蒙特利尔，2021年8月19 - 27日。第4721 - 4728页。ijcai.org(2021)。https://doi.org/10.24963/ijcai.2021/639 https://doi.org/10 24963/ijcai.2021/639

86. Zhu, Y., Tang, Z., Liu, Y., Zhuang, F., Xie, R., Zhang, X., Lin, L., He, Q.: Personalized transfer of user preferences for cross-domain recommendation. In: Candan, K.S., Liu, H., Akoglu, L., Dong, X.L., Tang, J. (eds.) WSDM. pp. 1507- 1515. ACM (2022). https://doi.org/10.1145/3488560.3498392.https://doi.org/ 10.1145/3488560.3498392

86. 朱(Zhu)、唐(Tang)、刘(Liu)、庄(Zhuang)、谢(Xie)、张(Zhang)、林(Lin)、何(He):跨领域推荐中用户偏好的个性化迁移。见:坎丹(Candan)、刘(Liu)、阿科格鲁(Akoglu)、董(Dong)、唐(Tang)(编)《网络搜索与数据挖掘国际会议》(WSDM)。第1507 - 1515页。美国计算机协会(ACM)(2022)。https://doi.org/10.1145/3488560.3498392.https://doi.org/ 10.1145/3488560.3498392