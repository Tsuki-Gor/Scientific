# Domain Generalization for Vision-based Driving Trajectory Generation

# 基于视觉的驾驶轨迹生成的领域泛化

Yunkai Wang ${}^{1}$ , Dongkun Zhang ${}^{1,2}$ , Yuxiang Cui ${}^{1}$ , Zexi Chen ${}^{1}$ ,

王云凯 ${}^{1}$，张东坤 ${}^{1,2}$，崔宇翔 ${}^{1}$，陈泽熙 ${}^{1}$，

Wei Jing ${}^{2}$ , Junbo ${\mathrm{{Chen}}}^{2}$ , Rong Xiong ${}^{1}$ , Yue Wang ${}^{1 \dagger  }$

景伟 ${}^{2}$，君博 ${\mathrm{{Chen}}}^{2}$，熊荣 ${}^{1}$，王越 ${}^{1 \dagger  }$

Abstract-One of the challenges in vision-based driving trajectory generation is dealing with out-of-distribution scenarios. In this paper, we propose a domain generalization method for vision-based driving trajectory generation for autonomous vehicles in urban environments, which can be seen as a solution to extend the Invariant Risk Minimization (IRM) method in complex problems. We leverage an adversarial learning approach to train a trajectory generator as the decoder. Based on the pre-trained decoder, we infer the latent variables corresponding to the trajectories, and pre-train the encoder by regressing the inferred latent variable. Finally, we fix the decoder but fine-tune the encoder with the final trajectory loss. We compare our proposed method with the state-of-the-art trajectory generation method and some recent domain generalization methods on both datasets and simulation, demonstrating that our method has better generalization ability. Our project is available at https://sites.google.com/view/dg-traj-gen.

摘要——基于视觉的驾驶轨迹生成面临的挑战之一是处理分布外(out-of-distribution, OOD)场景。本文提出了一种用于城市环境中自动驾驶车辆的基于视觉的驾驶轨迹生成的领域泛化方法，该方法可视为对复杂问题中不变风险最小化(Invariant Risk Minimization, IRM)方法的扩展。我们采用对抗学习方法训练轨迹生成器作为解码器。在预训练的解码器基础上，推断与轨迹对应的潜变量，并通过回归推断的潜变量预训练编码器。最后，固定解码器，使用最终轨迹损失微调编码器。我们将所提方法与最先进的轨迹生成方法及近期的领域泛化方法在数据集和仿真中进行了比较，结果表明本方法具有更好的泛化能力。项目地址:https://sites.google.com/view/dg-traj-gen。

## I. INTRODUCTION

## 一、引言

Vision-based navigation is an appealing research topic in recent years. One of the approaches in vision-based navigation is learning-based trajectory generation from RGB images. Most of the works are only validated on data from the same domain for training and testing, as shown in Fig. 1(a). However, as a common challenge in learning-based algorithms, out-of-distribution (OOD) scenarios can lead these trajectory generation approaches to have poor generalization results and make dangerous decisions.

近年来，基于视觉的导航成为一个备受关注的研究课题。基于视觉导航的一种方法是从RGB图像中学习轨迹生成。大多数工作仅在训练和测试数据来自同一领域的数据上验证，如图1(a)所示。然而，作为学习算法中的常见挑战，分布外(OOD)场景会导致这些轨迹生成方法泛化性能差，甚至做出危险决策。

To allow the model to be trained on a specific dataset and transferred to a new scenario, a straightforward solution to deal with the OOD problem is domain adaptation (DA) approach, which collects some data from the target domain to fine-tune the model, shown in Fig. 1(b). However, in the autonomous driving application scenario, a more realistic setting is that the target domain is unknown, so it is impossible to obtain the target domain data in advance. The problem dealing with such OOD scenario is introduced as domain generalization (DG) [1], which aims to learn a model from source domains and generalize to any OOD target domain, shown in Fig. 1(c).

为了使模型能在特定数据集上训练并迁移到新场景，解决OOD问题的直接方法是领域自适应(Domain Adaptation, DA)方法，即收集目标领域的一些数据来微调模型，如图1(b)所示。然而，在自动驾驶应用场景中，更现实的情况是目标领域未知，因此无法提前获得目标领域数据。处理此类OOD场景的问题被称为领域泛化(Domain Generalization, DG)[1]，其目标是从源领域学习模型并泛化到任意OOD目标领域，如图1(c)所示。

To realize domain generalization, one approach is to use labels of multi-domain training data [2] [3] to build an auxiliary task, trying to learn domain invariant data representations. However, domain labels are difficult to clearly define on most current driving datasets. One approach to relax this problem is using ensemble learning [4] to train a certain number of models with different training data and obtain a more robust planning result according to outputs of all models, while this approach needs a longer training time and inference time, making it resource-consuming. One appealing approach proposed recently is Invariant Risk Minimization (IRM) [5], which assumes the invariance of the feature-conditioned label distribution and aims to remove spurious correlations (i.e. dataset-specific biases) in a representation. However, most of the works using IRM are restricted to classification problems with simple datasets and linear classifiers.

实现领域泛化的一种方法是利用多领域训练数据的标签[2][3]构建辅助任务，尝试学习领域不变的数据表示。然而，大多数当前驾驶数据集中领域标签难以明确定义。为缓解此问题，一种方法是使用集成学习[4]，训练多个使用不同训练数据的模型，并根据所有模型的输出获得更鲁棒的规划结果，但该方法训练和推理时间较长，资源消耗大。近期提出的一种有吸引力的方法是不变风险最小化(Invariant Risk Minimization, IRM)[5]，其假设特征条件标签分布不变，旨在去除表示中的虚假相关(即数据集特有偏差)。然而，大多数使用IRM的工作仅限于简单数据集和线性分类器的分类问题。

![bo_d282qfv7aajc738ormf0_0_916_486_720_611_0.jpg](images/bo_d282qfv7aajc738ormf0_0_916_486_720_611_0.jpg)

Fig. 1: Different frameworks for testing, domain adaption, and domain generalization method are shown in (a), (b), and (c) respectively. We propose a three-stage training approach to realize real domain generalized trajectory generation method for autonomous vehicles.

图1:测试、领域自适应和领域泛化方法的不同框架分别示于(a)、(b)和(c)。我们提出了一个三阶段训练方法，实现自动驾驶车辆的真实领域泛化轨迹生成。

In this paper, we proposed a trajectory generation method to real domain generalized visual navigation for autonomous vehicles by extending the IRM approach. We construct an encoder-decoder network structure, where the decoder uses the method in [6] to represent continuous trajectories. In order to satisfy the constraint in the IRM problem, we use a Lagrangian form, which is the squared norm of the gradient of the trajectory generator. It is difficult to solve this problem directly because the gradient norm term can hinder the optimization. To solve this problem, we propose a three-stage training approach, which is shown in the lower part of Fig. 1(c): 1) We leverage an adversarial learning approach to train a trajectory generator as the decoder. 2) Based on the pre-trained decoder, we infer the latent variables corresponding to the trajectories, and pre-train the encoder by regressing the inferred latent variable. 3) We fix the decoder but fine-tune the encoder with the final trajectory loss.

本文提出了一种通过扩展IRM方法实现自动驾驶车辆真实领域泛化视觉导航的轨迹生成方法。我们构建了编码器-解码器网络结构，其中解码器采用文献[6]中的方法表示连续轨迹。为满足IRM问题中的约束，我们采用拉格朗日形式，即轨迹生成器梯度的平方范数。该问题难以直接求解，因为梯度范数项会阻碍优化。为解决此问题，我们提出了一个三阶段训练方法，如图1(c)下部所示:1)利用对抗学习训练轨迹生成器作为解码器；2)基于预训练解码器，推断与轨迹对应的潜变量，并通过回归该潜变量预训练编码器；3)固定解码器，使用最终轨迹损失微调编码器。

---

This work was supported by Alibaba Group through Alibaba Innovative Research (AIR) Program.

本工作由阿里巴巴集团通过阿里巴巴创新研究(Alibaba Innovative Research, AIR)计划支持。

${}^{1}$ Yunkai Wang, Dongkun Zhang, Yuxiang Cui, Zexi Chen, Rong Xiong, and Yue Wang are with the State Key Laboratory of Industrial Control Technology and Institute of Cyber-Systems and Control, Zhejiang University, Hangzhou, China.

${}^{1}$王云凯、张东坤、崔宇翔、陈泽熙、熊荣和王越来自浙江大学工业控制技术国家重点实验室与网络系统与控制研究所，中国杭州。

${}^{2}$ Dongkun Zhang, Wei Jing and Junbo Chen are with the Department of Autonomous Driving Lab, Alibaba DAMO Academy, Hangzhou, China

${}^{2}$张东坤、景伟和陈军博来自阿里巴巴达摩院自动驾驶实验室，中国杭州。

${}^{ \dagger  }$ Corresponding author, wangyue@iipc.zju.edu.cn

${}^{ \dagger  }$通讯作者，wangyue@iipc.zju.edu.cn

---

We compare our proposed method with the state-of-the-art trajectory generation method and some recent domain generalization methods on both datasets and simulation, demonstrating that our method has better generalization ability. To the best of our knowledge, this is the first work to train driving trajectory generation models in one domain and directly transfer them to other domains. To summarize, the main contributions of this paper include the following:

我们将所提方法与最先进的轨迹生成方法及一些近期的领域泛化方法在两个数据集和仿真环境中进行了比较，结果表明我们的方法具有更好的泛化能力。据我们所知，这是首个在一个域中训练驾驶轨迹生成模型并直接迁移到其他域的工作。总结而言，本文的主要贡献包括:

- We formulate the domain generalization for driving trajectory generation problem as a non-linear IRM problem. And we propose a set of network training strategies for optimizing the non-linear IRM problem.

- 我们将驾驶轨迹生成的领域泛化问题形式化为非线性不变风险最小化(IRM)问题，并提出了一套网络训练策略以优化该非线性IRM问题。

- We implement a trajectory generator with good domain generalization ability. We test our method on both datasets and simulation, showing that our method has a stronger generalization ability than others in both open-loop and closed-loop experiments.

- 我们实现了一个具有良好领域泛化能力的轨迹生成器。我们在数据集和仿真中测试了该方法，结果显示在开环和闭环实验中，我们的方法均表现出比其他方法更强的泛化能力。

## II. Related Works

## 二、相关工作

## A. Domain Generalization

## A. 领域泛化

The goal of the domain generalization (DG) problem [1] is to learn a model using data from the source domain and generalize to any out-of-distribution (OOD) target domain. Existing domain generalization approaches generally fall into the following groups:

领域泛化(DG)问题[1]的目标是利用源域数据学习模型，并推广到任何分布外(OOD)的目标域。现有领域泛化方法大致分为以下几类:

Domain-Adversarial Learning. The goal of domain-adversarial learning [2], [7], [8] is to align the distributions among different domains, and it formulates the distribution minimization problem through a minimax two-player game, without explicitly measuring the divergence between two probability distributions.

领域对抗学习。领域对抗学习[2]，[7]，[8]旨在对齐不同域之间的分布，通过极小极大双人博弈形式化分布最小化问题，而不显式测量两个概率分布之间的差异。

Learning Disentangled Representations. These approaches learn to represent the data as multiple features instead of a single domain-invariant feature and separate out the domain-specific parts [3], [9].

学习解耦表示。这些方法学习将数据表示为多个特征而非单一的域不变特征，并分离出域特定部分[3]，[9]。

Ensemble Learning. It uses different splits of training data to learn multiple models with the same structure but different weights, which can boost the performance of a single model [10] [11]. Ensemble learning is effective to cope with OOD data with fewer constraints. However, these approaches require more computational resources, the training time and inference time of these approaches grow linearly with the number of models.

集成学习。它利用训练数据的不同划分学习多个结构相同但权重不同的模型，从而提升单一模型的性能[10][11]。集成学习在应对OOD数据时效果显著且约束较少，但这些方法需要更多计算资源，训练和推理时间随模型数量线性增长。

Invariant Risk Minimization. It was first proposed by Arjovsky et al. [5], which aims to remove spurious correlations in a representation and ensure that the learned representation can lead to a minimal classification error over all source domains. Recent new works inspired from IRM to address the OOD generalization problem include [12]- [15]. However, most of these approaches are validated only by doing classification tasks on toy datasets. We extend the IRM method by using non-linear models to do the trajectory generation task. And compared to other domain generalization methods, our proposed method does not rely on domain knowledge, pixel-reconstruction, or multiple models ensembling, making it easy to train and apply.

不变风险最小化。该方法最早由Arjovsky等人提出[5]，旨在消除表示中的虚假相关性，确保所学表示在所有源域上均能实现最小分类误差。近期受IRM启发解决OOD泛化问题的新工作包括[12]-[15]。然而，大多数方法仅在玩具数据集上的分类任务中验证。我们通过使用非线性模型扩展IRM方法以完成轨迹生成任务。与其他领域泛化方法相比，我们的方法不依赖领域知识、像素重建或多模型集成，训练和应用更为简便。

### B.OOD Generalization in Driving Policy Learning

### B. 驾驶策略学习中的OOD泛化

Recently, several works have investigated the problem of OOD generalization problem in driving policy learning. Zhang et al. [16] proposed to use bisimulation metrics to learn robust latent representations which encode only the task-relevant information from observations in reinforcement learning. Unfortunately, there are still challenges in applying reinforcement learning methods to real-world driving tasks. Filos et al. [4] proposed an epistemic uncertainty-aware trajectory planning method by training an ensemble of density estimators and online optimizing the trajectory concerning the most pessimistic model. This approach achieves good results for OOD scenarios. However, model ensembling and online optimization will consume more computational resources and have a longer inference time, while in this paper, we only use one single model to implement OOD generalization.

近期，若干工作探讨了驾驶策略学习中的OOD泛化问题。张等人[16]提出利用双模拟度量学习鲁棒潜在表示，仅编码强化学习中观测的任务相关信息。但强化学习方法在实际驾驶任务中仍面临挑战。Filos等人[4]提出一种基于认知不确定性的轨迹规划方法，通过训练密度估计器集成并在线优化最悲观模型的轨迹，在OOD场景中取得良好效果。然而，模型集成和在线优化消耗更多计算资源且推理时间较长，而本文仅使用单一模型实现OOD泛化。

## III. METHOD

## 三、方法

## A. Background

## A. 背景

Most works in driving tasks use Empirical Risk Minimization (ERM) principle, which assumes there is a joint probability distribution $P\left( {x, y}\right)$ over input data $X$ and label data $Y$ , and the training data is drawn i.i.d. from $P\left( {x, y}\right)$ . Given a loss function $L\left( {\widehat{y}, y}\right)$ which measures how different the prediction $\widehat{y}$ is from the ground truth $y$ , ERM aims to find a hypothesis ${h}^{ * }$ to minimize the empirical risk, which can be formulated as the following optimization problem:

大多数驾驶任务的研究工作采用经验风险最小化(Empirical Risk Minimization, ERM)原则，该原则假设输入数据$P\left( {x, y}\right)$与标签数据$Y$存在联合概率分布$P\left( {x, y}\right)$，且训练数据是从该分布独立同分布(i.i.d.)抽取的。给定一个损失函数$L\left( {\widehat{y}, y}\right)$，用于衡量预测结果$\widehat{y}$与真实标签$y$之间的差异，ERM旨在寻找一个假设函数${h}^{ * }$以最小化经验风险，其优化问题可表述为:

$$
{h}^{ * } = \underset{h}{\arg \min }\frac{1}{N}\mathop{\sum }\limits_{{i = 1}}^{N}L\left( {h\left( {x}_{i}\right) ,{y}_{i}}\right)  \tag{1}
$$

However, when the joint probability distribution $P\left( {x, y}\right)$ varies in the testing data, ERM methods may yield poor generalization results. To overcome the distribution shift problem, as well as the absence of target domain data, domain generalization is introduced.

然而，当测试数据中的联合概率分布$P\left( {x, y}\right)$发生变化时，ERM方法可能导致较差的泛化性能。为了解决分布偏移问题以及目标域数据缺失的问题，引入了领域泛化(domain generalization)方法。

One of the important approaches in domain generalization is Invariant Risk Minimization [5], which assumes the invariance of the feature-conditioned label distribution $\mathbb{E}\left\lbrack  {y \mid  \Phi \left( x\right) }\right\rbrack$ . To find an approximate solution, a Lagrangian form is introduced [17]:

领域泛化中的一个重要方法是不变风险最小化(Invariant Risk Minimization, IRM)[5]，其假设特征条件下的标签分布$\mathbb{E}\left\lbrack  {y \mid  \Phi \left( x\right) }\right\rbrack$保持不变。为寻找近似解，引入了拉格朗日形式[17]:

$$
\mathop{\min }\limits_{{\Phi ,\mathcal{G}}}\mathop{\sum }\limits_{{e \in  \mathcal{E}}}\left\lbrack  {{\mathcal{R}}^{e}\left( {\Phi ,\mathcal{G}}\right)  + \lambda {\begin{Vmatrix}{\nabla }_{\mathcal{G}}{R}^{e}\left( \Phi ,\mathcal{G}\right) \end{Vmatrix}}_{2}^{2}}\right\rbrack   \tag{2}
$$

where $\Phi$ is a data representation, $\mathcal{G}$ is a classifier, $e$ is a kind of environment from the set $\mathcal{E}$ , and $\lambda$ is a regularization parameter. The latter IRM penalty term constrains the classifier to be the optimal classifier and is not worse for each sample, avoiding the situation in ERM methods where some data errors may be very large. In the linear regression case, the analytical solution of the problem can be directly calculated, and the IRM problem can be simplified as IRMv1 [5]:

其中$\Phi$是数据表示，$\mathcal{G}$是分类器，$e$是环境集合$\mathcal{E}$中的一种环境，$\lambda$是正则化参数。后者的IRM惩罚项约束分类器为最优分类器，且对每个样本表现不劣于其他分类器，避免了ERM方法中某些数据误差可能非常大的情况。在线性回归情形下，该问题的解析解可直接计算，IRM问题可简化为IRMv1 [5]:

$$
\mathop{\min }\limits_{\Phi }\mathop{\sum }\limits_{{e \in  \mathcal{E}}}\left\lbrack  {{\mathcal{R}}^{e}\left( \Phi \right)  + \lambda {\begin{Vmatrix}{\nabla }_{\mathcal{G} \mid  \mathcal{G} = {1.0}}{R}^{e}\left( \Phi ,\mathcal{G}\right) \end{Vmatrix}}_{2}^{2}}\right\rbrack   \tag{3}
$$

![bo_d282qfv7aajc738ormf0_2_186_137_1420_368_0.jpg](images/bo_d282qfv7aajc738ormf0_2_186_137_1420_368_0.jpg)

Fig. 2: Network structure diagram of our proposed method. The generator $\mathcal{G}$ is trained with the discriminator $\mathcal{D}$ by an unsupervised adversarial learning approach as a decoder. Based on the pre-trained decoder, we infer the latent variables corresponding to the trajectories, and pre-train the encoder by regressing the inferred latent variable. Finally, we fix the decoder but fine-tune the encoder with the final trajectory loss. The inputs of the encoder $\Phi$ include the RGB image $V$ which is acquired from the front-view camera, the local routing planning map $M$ which is cropped from an offline map according to the current low-cost GPS and IMU data, and the current speed $v$ .

图2:我们提出方法的网络结构图。生成器$\mathcal{G}$通过无监督对抗学习方法与判别器$\mathcal{D}$联合训练，作为解码器。基于预训练的解码器，我们推断与轨迹对应的潜变量，并通过回归推断的潜变量预训练编码器。最后，固定解码器，使用最终轨迹损失微调编码器。编码器的输入$\Phi$包括来自前视摄像头的RGB图像$V$，根据当前低成本GPS和惯性测量单元(IMU)数据从离线地图裁剪的局部路径规划地图$M$，以及当前速度$v$。

where $\Phi$ becomes the entire invariant predictor, $\mathcal{G} = {1.0}$ is a scalar and fixed "dummy" classifier.

其中$\Phi$成为整个不变预测器，$\mathcal{G} = {1.0}$是一个标量且固定的“虚拟”分类器。

## B. Problem Setup

## B. 问题设置

For the vision-based driving trajectory generation task, we leverage three sensor data as input of our method: the front-view RGB image $V$ which contains environmental information, the local route planning map $M$ which contains driving intention information as inputs, and the current speed $v$ of the vehicle. The local route planning map $M$ is cropped from an offline map based on the current pose from the low-cost GPS and inertial measurement unit (IMU), which is similar to [18] and [19]. Both images are resized to ${400} \times  {200}$ and concatenated together as part of the encoder's input.

对于基于视觉的驾驶轨迹生成任务，我们利用三种传感器数据作为方法输入:包含环境信息的前视RGB图像$V$，包含驾驶意图信息的局部路径规划地图$M$，以及车辆当前速度$v$。局部路径规划地图$M$是基于当前低成本GPS和惯性测量单元(IMU)提供的位姿，从离线地图中裁剪得到，类似于文献[18]和[19]。两幅图像均被调整为${400} \times  {200}$大小，并拼接作为编码器的输入部分。

We assume that in the driving trajectory generation task, there is an encoder $\Phi$ which maps all the sensor data to the latent variable $z$ and a trajectory generator (decoder) $\mathcal{G}$ which uses the latent variable $z$ , current speed $v$ , and the query time $t$ to generate trajectory points. The expression for the encoder $\Phi$ can be written as:

我们假设在驾驶轨迹生成任务中，存在一个编码器$\Phi$，将所有传感器数据映射到潜变量$z$，以及一个轨迹生成器(解码器)$\mathcal{G}$，利用潜变量$z$、当前速度$v$和查询时间$t$生成轨迹点。编码器$\Phi$的表达式可写为:

$$
z = \Phi \left( {V, M, v}\right)  \tag{4}
$$

and the expression for the trajectory generator $\mathcal{G}\left\lbrack  6\right\rbrack$ can be written as:

轨迹生成器$\mathcal{G}\left\lbrack  6\right\rbrack$的表达式可写为:

$$
\mathbf{y}\left( t\right)  = \mathcal{G}\left( {t,\mathbf{z}, v}\right)  \tag{5}
$$

The network structure is shown in the right part of Fig. 2.

网络结构如图2右侧所示。

The risk function used in this paper is:

本文使用的风险函数为:

$$
\mathcal{R} = \sum \left\lbrack  {{\begin{Vmatrix}{\mathbf{y}}_{\parallel } - {\widehat{\mathbf{y}}}_{\parallel }\end{Vmatrix}}_{2}^{2} + \alpha {\begin{Vmatrix}{\mathbf{y}}_{ \bot  } - {\widehat{\mathbf{y}}}_{ \bot  }\end{Vmatrix}}_{2}^{2}}\right\rbrack   \tag{6}
$$

where ${\mathbf{y}}_{\parallel }$ and ${\mathbf{y}}_{ \bot  }$ are the generated longitudinal and lateral displacement respectively, ${\widehat{\mathbf{y}}}_{\parallel }$ and ${\widehat{\mathbf{y}}}_{ \bot  }$ are the ground truth longitudinal and lateral displacement respectively, $\alpha$ is a regularizer balancing between longitudinal loss and lateral loss, and we use $\alpha  = 5$ in our experiments.

其中${\mathbf{y}}_{\parallel }$和${\mathbf{y}}_{ \bot  }$分别是生成的纵向和横向位移，${\widehat{\mathbf{y}}}_{\parallel }$和${\widehat{\mathbf{y}}}_{ \bot  }$分别是真实的纵向和横向位移，$\alpha$是平衡纵向损失和横向损失的正则项，我们在实验中使用了$\alpha  = 5$。

The most straightforward approach is to use the IRMv1 method to regress discrete trajectory points using a linear predictor, as mentioned in [5]. We call this method as Traj IRM. In our subsequent experiments, we find that Traj IRM method does not perform well enough in the trajectory generation task. Therefore, we introduce a non-linear decoder to improve the model representation ability. Refer to Eq. 2, we also consider using a Lagrangian form, and the non-linear IRM optimization problem becomes:

最直接的方法是使用IRMv1方法，通过线性预测器回归离散轨迹点，如文献[5]所述。我们称该方法为Traj IRM。在后续实验中，我们发现Traj IRM方法在轨迹生成任务中表现不够理想。因此，我们引入了非线性解码器以提升模型的表示能力。参见公式2，我们还考虑使用拉格朗日形式，非线性IRM优化问题变为:

$$
\mathop{\min }\limits_{{\theta ,\omega }}\mathop{\sum }\limits_{{e \in  \mathcal{E}}}\left\lbrack  {{\mathcal{R}}^{e}\left( {{\Phi }_{\theta },{\mathcal{G}}_{w}}\right)  + \lambda {\begin{Vmatrix}{\nabla }_{w}{\mathcal{R}}^{e}\left( {\Phi }_{\theta },{\mathcal{G}}_{w}\right) \end{Vmatrix}}_{2}^{2}}\right\rbrack   \tag{7}
$$

where $\theta$ is the parameters of the encoder $\Phi$ , and $w$ is the parameters of the decoder $\mathcal{G}$ . The former term is the ERM term and the latter term is the IRM penalty term. It is difficult to solve this problem directly because the IRM penalty term can hinder the optimization.

其中$\theta$是编码器$\Phi$的参数，$w$是解码器$\mathcal{G}$的参数。前一项是经验风险最小化(ERM)项，后一项是IRM惩罚项。该问题难以直接求解，因为IRM惩罚项可能阻碍优化过程。

Hence, we propose to use a three-stage approach to learn the IRM regularized trajectory generation: 1) We leverage an adversarial learning approach to train a trajectory generator as the decoder. 2) Based on the pre-trained decoder, we infer the latent variables corresponding to the trajectories and pretrain the encoder by regressing the inferred latent variable. 3) We fix the decoder but fine-tune the encoder with our proposed trajectory loss in an end-to-end manner.

因此，我们提出采用三阶段方法学习IRM正则化的轨迹生成:1)利用对抗学习方法训练轨迹生成器作为解码器。2)基于预训练的解码器，推断对应轨迹的潜变量，并通过回归推断的潜变量预训练编码器。3)固定解码器，使用我们提出的轨迹损失以端到端方式微调编码器。

## C. Unsupervised Learning for Trajectory Generation

## C. 无监督轨迹生成学习

Trajectory Representation. In this paper, we use a nonlinear decoder to generate continuous trajectories, which was proposed in [6]. In that work, the trajectory generator $\mathcal{G}$ takes three inputs: current speed $v$ as a condition, the latent variable $z$ as a trajectory prior, and the query time $t$ , and it outputs the trajectory point corresponding to the time $t$ , which has the same expression as Eq. 5. High-order physical quantities such as velocity and acceleration can be obtained analytically by calculating the high-order partial derivatives of the outputs with respect to time $t$ :

轨迹表示。本文采用文献[6]中提出的非线性解码器生成连续轨迹。该工作中，轨迹生成器$\mathcal{G}$接受三个输入:当前速度$v$作为条件，潜变量$z$作为轨迹先验，以及查询时间$t$，输出对应时间$t$的轨迹点，其表达式与公式5相同。通过对输出关于时间$t$求高阶偏导数，可以解析获得速度和加速度等高阶物理量:

$$
v\left( t\right)  = \frac{\partial \mathbf{y}\left( t\right) }{\partial t}, a\left( t\right)  = \frac{{\partial }^{2}\mathbf{y}\left( t\right) }{\partial {t}^{2}} \tag{8}
$$

In this paper, we follow this method to represent trajectories.

本文沿用该方法表示轨迹。

Latent Action Space Learning. Since the linear classifier of IRM can be solved analytically, the convergence of the classifier is not a concern, while the non-linear classifier has convergence problems. Therefore, it is important to train a good decoder without relying on high-dimensional inputs. We propose to use the unsupervised GAN to train the decoder. After training, the generator can be seen as a trained and converged decoder, which to some extent can be analogous to the classifier in linear IRM case, and we then can fix it in the process to optimize Eq. 7.

潜在动作空间学习。由于IRM的线性分类器可解析求解，分类器的收敛性无需担忧，而非线性分类器存在收敛问题。因此，训练一个不依赖高维输入的优良解码器非常重要。我们提出使用无监督生成对抗网络(GAN)训练解码器。训练完成后，生成器可视为已训练且收敛的解码器，在一定程度上类似于线性IRM中的分类器，随后我们可在优化公式7的过程中固定它。

Specifically, inspired by the multi-modal experiment in Conditional ${GAN}\left\lbrack  {20}\right\rbrack$ , we sample the trajectory prior $\mathbf{z}$ from a standard Gaussian distribution ${p}_{z}\left( \mathbf{z}\right)$ , and a one-dimensional noise speed $\widetilde{v}$ from a uniform distribution ${p}_{\widetilde{v}}\left( \widetilde{\mathbf{v}}\right)$ between 0 and the maximum speed as a condition:

具体地，受条件生成对抗网络(Conditional GAN)多模态实验启发，我们从标准高斯分布${p}_{z}\left( \mathbf{z}\right)$采样轨迹先验$\mathbf{z}$，并从0到最大速度的均匀分布${p}_{\widetilde{v}}\left( \widetilde{\mathbf{v}}\right)$中采样一维噪声速度$\widetilde{v}$作为条件:

$$
\mathbf{z} \sim  {p}_{z}\left( \mathbf{z}\right) ,\widetilde{v} \sim  {p}_{\widetilde{v}}\left( \widetilde{\mathbf{v}}\right)  \tag{9}
$$

And the trajectory generator $\mathcal{G}$ takes these variables to generate a fake trajectory:

轨迹生成器$\mathcal{G}$利用这些变量生成假轨迹:

$$
\widetilde{\mathbf{y}}\left( t\right)  = \mathcal{G}\left( {t,\mathbf{z},\widetilde{v}}\right)  \tag{10}
$$

Then we use a time series with equal interval sampling and input to the trajectory function to obtain the corresponding discrete trajectory points. The discriminator network $\mathcal{D}$ takes these generated trajectory points $\widetilde{\mathbf{y}}$ or ground truth trajectory points $\mathbf{y}$ as input, and determines whether it is sampled from the generator network or from the ground truth data. The network structure is shown in the left part of Fig. 2. To improve the stability of the training process and prevent severe model collapse, we use WGAN-GP [21] as our adversarial learning approach.

然后我们使用等间隔采样的时间序列输入轨迹函数，获得对应的离散轨迹点。判别网络$\mathcal{D}$以生成的轨迹点$\widetilde{\mathbf{y}}$或真实轨迹点$\mathbf{y}$为输入，判断其来源于生成器网络还是真实数据。网络结构如图2左侧所示。为提高训练稳定性并防止严重模型崩溃，我们采用WGAN-GP [21]作为对抗学习方法。

## D. Encoder Pre-training

## D. 编码器预训练

We view the encoder pre-training task as a regression problem on the latent action space. However, the problem is that there is no target latent variables $\widehat{z}$ to supervise the encoder training. Therefore, we infer the latent variables for each trajectory. Referring to the Eq. 13, we use the risk function along with the IRM loss. Since the latent variables are sampled from the standard Gaussian distribution in the training process of the GAN model, we also add a constraint on the norm of the latent variable $z$ so that its distribution is as close as possible to the standard Gaussian distribution. The final loss function to obtain the target latent variable $\widehat{\mathbf{z}}$ is shown in Eq. 11.

我们将编码器预训练任务视为潜在动作空间上的回归问题。然而，问题在于没有目标潜变量$\widehat{z}$来监督编码器训练。因此，我们对每条轨迹推断潜变量。参照公式13，我们使用风险函数和IRM损失。由于潜变量在GAN模型训练过程中是从标准高斯分布采样的，我们还对潜变量的范数$z$添加约束，使其分布尽可能接近标准高斯分布。获得目标潜变量$\widehat{\mathbf{z}}$的最终损失函数如公式11所示。

$$
\widehat{\mathbf{z}} = \underset{\mathbf{z}}{\arg \min }\mathop{\sum }\limits_{{e \in  \mathcal{E}}}\left\lbrack  {{\mathcal{R}}^{e}\left( {\mathbf{z},{\mathcal{G}}_{{w}_{0}}}\right)  + \lambda {\begin{Vmatrix}{\nabla }_{w \mid  w = {w}_{0}}{\mathcal{R}}^{e}\left( \mathbf{z},{\mathcal{G}}_{w}\right) \end{Vmatrix}}^{2}}\right.
$$

$$
\left. {+{\lambda }_{2}\parallel \mathbf{z}{\parallel }_{2}^{2}}\right\rbrack   \tag{11}
$$

where ${w}_{0}$ is the parameters pre-trained by GAN, ${\lambda }_{2}$ is a regularizer. In practice, we use Adam optimizer with 0.1 initial learning rate to optimize the latent variable $\widehat{z}$ as the target label data for supervised learning. Then we pre-train the encoder by regressing the latent variable $z$ , and the loss function is:

其中${w}_{0}$是由GAN预训练的参数，${\lambda }_{2}$是正则项。实际中，我们使用初始学习率为0.1的Adam优化器来优化潜变量$\widehat{z}$，作为监督学习的目标标签数据。然后通过回归潜变量$z$来预训练编码器，损失函数为:

$$
{\theta }_{0} = \underset{\theta }{\arg \min }\sum {\begin{Vmatrix}{\Phi }_{\theta }\left( V, M, v\right)  - \widehat{\mathbf{z}}\end{Vmatrix}}_{2}^{2} \tag{12}
$$

After obtaining the latent variables $\widehat{\mathbf{z}}$ from the multi-step optimization, a simple way is to follow the IRM approach to do linear regression on the latent space by using IRMv1 method [5]. However, we believe that it will introduce both the error of the latent variables used for supervision and the error of learning these latent variables, and our subsequent experiments show that this method works, but not very well. We call this method as Latent IRMv1.

在通过多步优化获得潜变量$\widehat{\mathbf{z}}$后，一种简单的方法是采用IRM方法，在潜在空间上使用IRMv1方法[5]进行线性回归。然而，我们认为这会引入用于监督的潜变量误差和学习这些潜变量的误差，后续实验表明该方法有效但效果不佳。我们称此方法为潜变量IRMv1。

## E. End-to-End Training

## E. 端到端训练

After pre-training the encoder, we train our model in an end-to-end manner. In order to guarantee the feature-conditioned label distribution $\mathbb{E}\left\lbrack  {y \mid  \Phi \left( x\right) }\right\rbrack$ remains invariant, we propose to fix the parameters of the decoder $\mathcal{G}$ in the training process, and just fine-tune the encoder. We use the GAN pre-trained parameters as the fixed parameters for the decoder, instead of random parameters, which can reduce the difficulty of optimization in the latent space and speed up training.

在预训练编码器后，我们以端到端方式训练模型。为保证特征条件标签分布$\mathbb{E}\left\lbrack  {y \mid  \Phi \left( x\right) }\right\rbrack$保持不变，我们提出在训练过程中固定解码器参数$\mathcal{G}$，仅微调编码器。我们使用GAN预训练参数作为解码器的固定参数，而非随机参数，这可以降低潜在空间优化难度并加快训练速度。

Therefore, the optimization problem in Eq. 7 is reduced to only search the parameters of the encoder:

因此，公式7中的优化问题简化为仅搜索编码器参数:

$$
\mathop{\min }\limits_{\theta }\mathop{\sum }\limits_{{e \in  \mathcal{E}}}\left\lbrack  {{\mathcal{R}}^{e}\left( {{\Phi }_{\theta },{\mathcal{G}}_{{w}_{0}}}\right)  + \lambda {\begin{Vmatrix}{\nabla }_{w \mid  w = {w}_{0}}{\mathcal{R}}^{e}\left( {\Phi }_{\theta },{\mathcal{G}}_{w}\right) \end{Vmatrix}}_{2}^{2}}\right\rbrack   \tag{13}
$$

We call the loss function in Eq. 13 as Non-linear IRM (NIRM) loss.

我们将公式13中的损失函数称为非线性IRM(NIRM)损失。

In our experiments, we also discuss the use of a decoder with random parameters, i.e., the decoder has not yet converged well, but we use it to train the model in the same way. We call this method Random ${NT} + {NIRM}$ . And our subsequent experiments demonstrate the poor performance of the model trained by this method.

在实验中，我们还讨论了使用随机参数的解码器，即解码器尚未很好收敛，但我们以相同方式训练模型。我们称此方法为随机${NT} + {NIRM}$。后续实验表明该方法训练的模型性能较差。

## IV. EXPERIMENTS

## IV. 实验

In this paper, we use different ablated models to validate the effectiveness of our proposed method on the open-source driving datasets and compare our method with the state-of-the-art trajectory generation method and recent domain generalization methods on the open-source driving datasets and the CARLA simulation.

本文通过不同的消融模型验证我们方法在开源驾驶数据集上的有效性，并将我们的方法与最先进的轨迹生成方法及近期领域泛化方法在开源驾驶数据集和CARLA仿真中进行比较。

## A. Dataset and Metrics

## A. 数据集与指标

We use three driving datasets to validate our method.

我们使用三个驾驶数据集验证我们的方法。

Oxford Radar RobotCar (RobotCar) [22] is a radar extension to the Oxford RobotCar Dataset [23], providing ${280}\mathrm{\;{km}}$ driving data around Oxford, UK. Since this dataset has simpler and practical data collection conditions, with limited geographic space and different collection times, we use this dataset as a training dataset.

Oxford Radar RobotCar(RobotCar)[22]是Oxford RobotCar数据集[23]的雷达扩展，提供英国牛津地区的${280}\mathrm{\;{km}}$驾驶数据。由于该数据集采集条件较简单且实用，地理空间有限且采集时间不同，我们将其作为训练数据集。

TABLE I: Ablation study results of generalization from RobotCar Dataset to KITTI and CARLA Dataset. The three columns on the right are the average displacement error (m) on three different testing datasets. Lower metrics have better results.

表I:从RobotCar数据集到KITTI和CARLA数据集的泛化消融研究结果。右侧三列为三个不同测试数据集上的平均位移误差(米)。指标越低结果越好。

<table><tr><td>Algorithm</td><td>DFX</td><td>DPT</td><td>IRM</td><td>RobotCar*</td><td>KITTI</td><td>CARLA</td></tr><tr><td>E2E NT [6]</td><td/><td/><td/><td>0.60</td><td>2.13</td><td>1.36</td></tr><tr><td>E2E NT+NIRM</td><td/><td/><td>NIRM</td><td>0.68</td><td>2.06</td><td>1.25</td></tr><tr><td>Random NT+NIRM</td><td>✓</td><td/><td>NIRM</td><td>1.50</td><td>2.32</td><td>1.45</td></tr><tr><td>Traj IRM</td><td>✓</td><td/><td>IRMv1</td><td>0.67</td><td>2.16</td><td>1.31</td></tr><tr><td>Latent IRMv1</td><td>✓</td><td>✓</td><td>IRMv1</td><td>0.77</td><td>1.77</td><td>1.02</td></tr><tr><td>Ours</td><td>✓</td><td>✓</td><td>NIRM</td><td>0.85</td><td>1.70</td><td>0.92</td></tr></table>

<table><tbody><tr><td>算法</td><td>DFX</td><td>DPT</td><td>IRM</td><td>RobotCar*</td><td>KITTI</td><td>CARLA</td></tr><tr><td>E2E NT [6]</td><td></td><td></td><td></td><td>0.60</td><td>2.13</td><td>1.36</td></tr><tr><td>E2E NT+NIRM</td><td></td><td></td><td>NIRM</td><td>0.68</td><td>2.06</td><td>1.25</td></tr><tr><td>随机 NT+NIRM</td><td>✓</td><td></td><td>NIRM</td><td>1.50</td><td>2.32</td><td>1.45</td></tr><tr><td>轨迹 IRM</td><td>✓</td><td></td><td>IRMv1</td><td>0.67</td><td>2.16</td><td>1.31</td></tr><tr><td>潜在 IRMv1</td><td>✓</td><td>✓</td><td>IRMv1</td><td>0.77</td><td>1.77</td><td>1.02</td></tr><tr><td>我们的方法</td><td>✓</td><td>✓</td><td>NIRM</td><td>0.85</td><td>1.70</td><td>0.92</td></tr></tbody></table>

"DFX" means "Decoder Fixed", "DPT" means "Decoder Pre-trained", and "IRM" means "With IRM".

“DFX”表示“解码器固定”(Decoder Fixed)，“DPT”表示“解码器预训练”(Decoder Pre-trained)，而“IRM”表示“带IRM”(With IRM)。

KITTI Raw Data (KITTI) [24] contains 6 hours of traffic scenarios using a variety of sensor modalities. Since this dataset has more diverse driving scenarios, we use this dataset as a testing dataset.

KITTI原始数据集(KITTI)[24]包含6小时的交通场景，使用多种传感器模态。由于该数据集涵盖了更多样化的驾驶场景，我们将其用作测试数据集。

CARLA Dataset is collected by a human driver for about 2 hours in the CARLA [25] simulation, with a speed limit of ${30}\mathrm{\;{km}}/\mathrm{h}$ under different weather conditions. Since the cost of changing weather conditions in the simulation is very low and the driving trajectories are relatively simple, it is used as a testing dataset in the experiments.

CARLA数据集由人工驾驶员在CARLA [25]仿真环境中收集，时长约2小时，限速为${30}\mathrm{\;{km}}/\mathrm{h}$，涵盖不同天气条件。由于仿真中改变天气条件的成本极低且驾驶轨迹相对简单，因此在实验中用作测试数据集。

Metrics. In this paper, we use average displacement error [26], which is the average Euclidean distance between the ground truth trajectory points and the generated trajectory points at the corresponding moment, to evaluate the performance of different methods.

评估指标。本文采用平均位移误差[26]，即地面真实轨迹点与对应时刻生成轨迹点之间的平均欧氏距离，来评估不同方法的性能。

## B. Ablation Study

## B. 消融研究

We validate the advantages of our proposed method by testing different ablated models from the original model as below:

我们通过测试从原始模型中剔除不同部分的模型，验证所提方法的优势，具体如下:

- ${E2ENT}$ : We directly train the model end-to-end in an ERM manner.

- ${E2ENT}$ :我们以经验风险最小化(ERM)方式直接端到端训练模型。

- E2E NT+NIRM: We train the model end-to-end with NIRM loss.

- E2E NT+NIRM:我们以NIRM损失端到端训练模型。

- Random ${NT} + {NIRM}$ : This method is proposed in Sec. III-E. We use a fixed neural trajectory generation model with random parameters instead of the parameters of the pre-trained GAN model.

- 随机${NT} + {NIRM}$ :该方法在第III-E节提出。我们使用参数随机的固定神经轨迹生成模型，替代预训练GAN模型的参数。

- Traj IRM: This method was proposed in [5], and is mentioned in Sec. III-B. We use this method to regress the position coordinates of 16 discrete trajectory points.

- 轨迹IRM:该方法由文献[5]提出，详见第III-B节。我们用此方法回归16个离散轨迹点的位置坐标。

- Latent IRMv1: This method is proposed in Sec. III-D, which do linear regression on the latent space by using ${IRMv1}$ method.

- 潜在IRMv1:该方法在第III-D节提出，采用${IRMv1}$方法对潜在空间进行线性回归。

- Ours: The method proposed in this paper, which is trained by our proposed three-stage training approach.

- 本文方法:本文提出的方法，采用我们设计的三阶段训练策略进行训练。

The ablation study results of transfer from RobotCar Dataset to KITTI Dataset and CARLA Dataset are shown in Tab. I. Comparing with the results of the ${E2E}\;{NT}$ method, using IRM can improve model generalization ability, which illustrates the effectiveness of the IRM approach. Comparing with the results of the ${E2E}\;{NT} + {NIRM}$ method and Random ${NT} + {NIRM}$ method, our method has a stronger generalization ability. Since the pre-trained decoder we use is a converged decoder with fixed parameters, we believe it is a correct analogy to the linear IRM case, so our method has a better performance. Comparing the results of the Traj ${IRM}$ method, it shows that the decoder using a simple "dummy" predictor does not have enough model capacity for more complex problems such as trajectory generation for autonomous vehicles. The second-best performing Latent ${IRMv1}$ is also analogous to the linear IRM case, but it only uses intermediate results as supervision, so there are fitting errors introduced, resulting in slightly worse performance.

从RobotCar数据集迁移到KITTI和CARLA数据集的消融研究结果见表I。与${E2E}\;{NT}$方法相比，使用IRM能提升模型泛化能力，证明了IRM方法的有效性。与${E2E}\;{NT} + {NIRM}$方法和随机${NT} + {NIRM}$方法相比，我们的方法泛化能力更强。由于我们使用的预训练解码器是参数固定且已收敛的解码器，我们认为这与线性IRM情况类比合理，因此性能更优。与轨迹${IRM}$方法结果对比表明，使用简单“虚拟”预测器的解码器模型容量不足，难以应对自动驾驶车辆轨迹生成等复杂问题。表现第二的潜在${IRMv1}$方法同样类比线性IRM，但仅使用中间结果作为监督，导致拟合误差，性能略逊一筹。

## C. Comparative Study

## C. 对比研究

We compare our proposed method with the recent trajectory generation method which aims to overcome the OOD challenge and other domain generalization methods. To be fair, all methods use the same inputs as our proposed method. For the discrete trajectory generation methods, we use linear interpolation to get the trajectory points at the corresponding moment. For methods that require domain labels, we divide three datasets into 5 domains respectively, according to the time of data collection. Note that our method does not require domain labels.

我们将所提方法与近期旨在克服OOD挑战的轨迹生成方法及其他领域泛化方法进行比较。为公平起见，所有方法均使用与我们方法相同的输入。对于离散轨迹生成方法，我们采用线性插值获取对应时刻的轨迹点。对于需要领域标签的方法，我们根据数据采集时间将三个数据集分别划分为5个领域。注意，我们的方法不依赖领域标签。

End-to-End Neural Trajectory (E2E NT) is a variant of [6], which has the same network structure and inputs as our proposed method. All its parameters are trained end-to-end with only ${L}_{2}$ loss. This method is treated as a baseline method in this paper.

端到端神经轨迹(E2E NT)是文献[6]的变体，网络结构和输入与我们方法相同。其所有参数仅通过${L}_{2}$损失端到端训练。本文将该方法作为基线方法。

Robust Imitative Planning (RIP) [4] is one of the state-of-the-art methods for trajectory generation to overcome distribution shifts. We use the Worst Case Model (WCM) over 5 models and Adam [27] optimizer for online optimization with 50 steps and 0.1 initial learning rate. According to the official code provided, the model output is 4 discrete trajectory points, and the points at other moments are obtained using linear interpolation.

鲁棒模仿规划(Robust Imitative Planning，RIP)[4] 是克服分布偏移的轨迹生成的最先进方法之一。我们使用基于5个模型的最坏情况模型(Worst Case Model，WCM)和Adam[27]优化器进行在线优化，步数为50，初始学习率为0.1。根据官方提供的代码，模型输出4个离散轨迹点，其他时刻的点通过线性插值获得。

MixStyle [28] is a method to make CNNs more domain-generalizable by mixing instance-level feature statistics of training samples across domains without using domain labels. We use this plugin in our end-to-end model without changing other settings for a fair comparison.

MixStyle[28] 是一种通过混合跨域训练样本的实例级特征统计而无需使用域标签，使卷积神经网络(CNN)具备更强域泛化能力的方法。我们在端到端模型中使用该插件，且未更改其他设置，以保证公平比较。

Domain Invariant Variational Autoencoders (DIVA) [3] is a generative model that tackles the domain generalization problem by learning three independent latent subspaces, one for the domain, one for the class, and one for any residual variations. We extend this method to turn the classification task into a trajectory generation task, using the continuous trajectory generation model proposed in [6]. This method needs domain labels in the training process.

域不变变分自编码器(Domain Invariant Variational Autoencoders，DIVA)[3] 是一种生成模型，通过学习三个独立的潜在子空间——域子空间、类别子空间及残差变异子空间，来解决域泛化问题。我们将该方法扩展为将分类任务转化为轨迹生成任务，采用[6]中提出的连续轨迹生成模型。该方法在训练过程中需要域标签。

Domain-Adversarial Learning (DAL) [29] methods leverage adversarial learning to allow the generator to extract domain invariant features. We use this method in our end-to-end model, and design a discriminator to determine whether two features come from the same domain. This method also needs domain labels in the training process.

域对抗学习(Domain-Adversarial Learning，DAL)[29] 方法利用对抗学习使生成器提取域不变特征。我们在端到端模型中采用该方法，并设计判别器以判断两个特征是否来自同一域。该方法在训练过程中同样需要域标签。

![bo_d282qfv7aajc738ormf0_5_191_152_654_452_0.jpg](images/bo_d282qfv7aajc738ormf0_5_191_152_654_452_0.jpg)

Fig. 3: Generalization performance (average displacement error in meters) on three different datasets. The models are trained on the dataset labeled by "*", and directly generalize to the testing dataset and other two target datasets.

图3:在三个不同数据集上的泛化性能(平均位移误差，单位为米)。模型在标有“*”的数据集上训练，直接泛化到测试数据集及另外两个目标数据集。

TABLE II: Closed-loop testing of success rate (%, the first one of each item) and average speed $(m/s$ , the second one of each item) in CARLA. Higher metrics have better results. Highest success rates are highlighted in bold font.

表II:CARLA中的闭环测试成功率(%，每项的第一个数值)和平均速度$(m/s$(每项的第二个数值)。指标越高结果越好。最高成功率以粗体显示。

<table><tr><td>Algorithm</td><td>Clear Noon</td><td>Wet Cloudy Sunset</td><td>Hard Rain Sunset</td><td>Heavy Fog Morning</td></tr><tr><td>RIP [4]</td><td>86/3.6</td><td>78/3.8</td><td>82/3.7</td><td>76/3.7</td></tr><tr><td>MixStyle [28]</td><td>94/4.1</td><td>77/4.9</td><td>72/7.4</td><td>34/6.4</td></tr><tr><td>DIVA [3]</td><td>79/9.6</td><td>71/9.3</td><td>54/8.7</td><td>39/7.5</td></tr><tr><td>DAL [29]</td><td>79/4.0</td><td>31/4.9</td><td>27/4.7</td><td>38/3.8</td></tr><tr><td>E2E NT [6]</td><td>$\mathbf{{100}/{8.6}}$</td><td>${50}/{4.5}$</td><td>35/3.9</td><td>31/9.9</td></tr><tr><td>Ours</td><td>94/5.6</td><td>$\mathbf{{82}}/\mathbf{{6.8}}$</td><td>$\mathbf{{100}/{7.6}}$</td><td>$\mathbf{{79}}/\mathbf{{5.7}}$</td></tr></table>

<table><tbody><tr><td>算法</td><td>晴朗的正午</td><td>湿润多云的日落</td><td>大雨日落</td><td>浓雾晨曦</td></tr><tr><td>RIP [4]</td><td>86/3.6</td><td>78/3.8</td><td>82/3.7</td><td>76/3.7</td></tr><tr><td>MixStyle [28]</td><td>94/4.1</td><td>77/4.9</td><td>72/7.4</td><td>34/6.4</td></tr><tr><td>DIVA [3]</td><td>79/9.6</td><td>71/9.3</td><td>54/8.7</td><td>39/7.5</td></tr><tr><td>DAL [29]</td><td>79/4.0</td><td>31/4.9</td><td>27/4.7</td><td>38/3.8</td></tr><tr><td>E2E NT [6]</td><td>$\mathbf{{100}/{8.6}}$</td><td>${50}/{4.5}$</td><td>35/3.9</td><td>31/9.9</td></tr><tr><td>我们的</td><td>94/5.6</td><td>$\mathbf{{82}}/\mathbf{{6.8}}$</td><td>$\mathbf{{100}/{7.6}}$</td><td>$\mathbf{{79}}/\mathbf{{5.7}}$</td></tr></tbody></table>

## D. Comparison Results on Datasets

## D. 数据集上的比较结果

We implement our network by using PyTorch 1.6 with CUDA 10.2 and cuDNN 7.6.5 libraries. We use a batch size of 32 and Adam [27] optimizer with an initial learning rate of 0.0003 . All networks are trained on a PC with AMD 3700X CPU and NVIDIA RTX 2060 Super GPU. We train all methods on training dataset until the models converge, and evaluate them on the testing datasets from both the same domain and other domians.

我们使用PyTorch 1.6结合CUDA 10.2和cuDNN 7.6.5库实现我们的网络。批量大小为32，采用Adam [27]优化器，初始学习率为0.0003。所有网络均在配备AMD 3700X CPU和NVIDIA RTX 2060 Super GPU的PC上训练。我们在训练集上训练所有方法直至模型收敛，并在同域和异域的测试集上进行评估。

The generalization results of the different models are shown in Fig 3. In terms of generalization performance, our method outperforms other comparison methods on the testing datasets under different domains, which validates that our method has a stronger generalization ability. The results show that MixStyle and DIVA these two domain generalization methods also have a great performance improvement compared to the ${E2ENT}$ baseline method. While the ${RIP}$ method and the ${DAL}$ method do not always show a stable generalization performance advantage. Under certain conditions, the performance of these two methods may be worse than that of the baseline method.

不同模型的泛化结果如图3所示。在泛化性能方面，我们的方法在不同域的测试集上均优于其他对比方法，验证了我们方法具有更强的泛化能力。结果显示，MixStyle和DIVA这两种域泛化方法相比${E2ENT}$基线方法也有显著性能提升。而${RIP}$方法和${DAL}$方法并不总是表现出稳定的泛化性能优势，在某些条件下，这两种方法的表现甚至可能不如基线方法。

## E. Closed-loop Experiments in Simulation

## E. 仿真中的闭环实验

Since we want to train our driving model on the dataset collected in one environment and transfer this model to a new environment to implement driving tasks, evaluation on open-loop datasets is not enough to prove the effectiveness of our method. Therefore, we test our method with closed-loop visual navigation tasks in the CARLA [25] 0.9.9.4 simulation and compare it with other methods.

由于我们希望在一个环境中收集的数据集上训练驾驶模型，并将该模型迁移到新环境中执行驾驶任务，单纯在开环数据集上的评估不足以证明我们方法的有效性。因此，我们在CARLA [25] 0.9.9.4仿真环境中通过闭环视觉导航任务测试我们的方法，并与其他方法进行比较。

![bo_d282qfv7aajc738ormf0_5_938_136_684_297_0.jpg](images/bo_d282qfv7aajc738ormf0_5_938_136_684_297_0.jpg)

Fig. 4: Model generalization results of our method under four different weather conditions in CARLA. The model is only trained on RobotCar dataset and directly generalize to CARLA. The discrete red points are the generated trajectory points.

图4:我们方法在CARLA中四种不同天气条件下的模型泛化结果。模型仅在RobotCar数据集上训练，直接泛化到CARLA。离散的红点为生成的轨迹点。

Experiments Setup. We train models on RobotCar Dataset and transfer them in the CARLA simulator, testing the driving success rates under different driving tasks of different models. We use the same vehicle and set random starting and target points in Town 01 with four different weather conditions: Clear Noon, Cloudy Sunset, Hard Rain Sunset, and Heavy Fog Morning and two traffic condition: Empty and with Dynamic Obstacles, where the setting of obstacles is the same as its in the CARLA benchmark [25].

实验设置。我们在RobotCar数据集上训练模型，并在CARLA仿真器中迁移测试不同模型在不同驾驶任务下的成功率。使用相同车辆，在Town 01设置随机起点和目标点，包含四种天气条件:晴朗中午、多云日落、强降雨日落和浓雾清晨，以及两种交通状况:空旷和动态障碍物，障碍物设置与CARLA基准[25]相同。

Closed-loop Experiment Result. The results are shown in Tab. II and Fig. 4. Our method gets second place in success rate under Clear Noon weather condition and has the highest success rate under all other weather conditions. Compared to the ${E2ENT}$ method, our method has high success rates in all weather conditions, while the success rates of ${E2E}$ ${NT}$ method vary greatly under different weather conditions, which means that our method has a stronger model transfer ability to handle different weather conditions. Compared to the RIP method, our method has higher success rates and higher average speeds, while the RIP method using Worst Case Model (WCM) generates more conservative trajectories with low speed. Compared to MixStyle and DIVA, which have high success rates under the former three weather conditions, our method can also get a high success rate under Heavy Fog Morning weather condition, where there is a close field of view and severe visual disturbance, which also validate our method has a stronger transfer ability.

闭环实验结果。结果见表II和图4。我们的方法在晴朗中午天气条件下成功率排名第二，在其他所有天气条件下均取得最高成功率。相比${E2ENT}$方法，我们的方法在所有天气条件下均表现出较高成功率，而${E2E}$和${NT}$方法在不同天气条件下成功率波动较大，表明我们的方法具有更强的模型迁移能力以应对不同天气。相比RIP方法，我们的方法成功率和平均速度更高，而RIP方法采用的最坏情况模型(Worst Case Model, WCM)生成更保守且速度较低的轨迹。相比在前三种天气条件下成功率较高的MixStyle和DIVA，我们的方法在浓雾清晨这一视野受限且视觉干扰严重的条件下也能取得高成功率，进一步验证了我们方法的更强迁移能力。

## V. CONCLUSION

## V. 结论

In this paper, we propose a domain generalization method for vision-based driving trajectory generation for autonomous vehicles in urban environments, which can be seen as a solution to extend the IRM method in non-linear cases. We compare our proposed method with the state-of-the-art trajectory generation method and some recent domain generalization methods on both datasets and simulation, demonstrating that our method has better generalization ability. REFERENCES

本文提出了一种基于视觉的自动驾驶轨迹生成的域泛化方法，适用于城市环境中的自动驾驶车辆，该方法可视为对非线性情况下IRM(Invariant Risk Minimization，不变风险最小化)方法的扩展。我们将所提方法与最先进的轨迹生成方法及近期域泛化方法在数据集和仿真中进行了比较，结果表明我们的方法具有更优的泛化能力。参考文献

[1] K. Zhou, Z. Liu, Y. Qiao, T. Xiang, and C. C. Loy, "Domain generalization: A survey," arXiv preprint arXiv:2103.02503, 2021.

[1] K. Zhou, Z. Liu, Y. Qiao, T. Xiang, and C. C. Loy, "Domain generalization: A survey," arXiv preprint arXiv:2103.02503, 2021.

[2] Y. Li, X. Tian, M. Gong, Y. Liu, T. Liu, K. Zhang, and D. Tao, "Deep domain generalization via conditional invariant adversarial networks," in Proceedings of the European Conference on Computer Vision (ECCV), pp. 624-639, 2018.

[2] Y. Li, X. Tian, M. Gong, Y. Liu, T. Liu, K. Zhang, and D. Tao, "Deep domain generalization via conditional invariant adversarial networks," in Proceedings of the European Conference on Computer Vision (ECCV), pp. 624-639, 2018.

[3] M. Ilse, J. M. Tomczak, C. Louizos, and M. Welling, "Diva: Domain invariant variational autoencoders," in Medical Imaging with Deep Learning, pp. 322-348, PMLR, 2020.

[3] M. Ilse, J. M. Tomczak, C. Louizos, and M. Welling, "Diva: Domain invariant variational autoencoders," in Medical Imaging with Deep Learning, pp. 322-348, PMLR, 2020.

[4] A. Filos, P. Tigkas, R. McAllister, N. Rhinehart, S. Levine, and Y. Gal, "Can autonomous vehicles identify, recover from, and adapt to distribution shifts?," in International Conference on Machine Learning, pp. 3145-3153, PMLR, 2020.

[4] A. Filos, P. Tigkas, R. McAllister, N. Rhinehart, S. Levine, 和 Y. Gal, “自动驾驶车辆能否识别、恢复并适应分布偏移？”，发表于国际机器学习大会，页3145-3153，PMLR，2020年。

[5] M. Arjovsky, L. Bottou, I. Gulrajani, and D. Lopez-Paz, "Invariant risk minimization," arXiv preprint arXiv:1907.02893, 2019.

[5] M. Arjovsky, L. Bottou, I. Gulrajani, 和 D. Lopez-Paz, “不变风险最小化(Invariant Risk Minimization)”，arXiv预印本 arXiv:1907.02893，2019年。

[6] Y. Wang, D. Zhang, J. Wang, Z. Chen, Y. Li, Y. Wang, and R. Xiong, "Imitation learning of hierarchical driving model: from continuous intention to continuous trajectory," IEEE Robotics and Automation Letters, 2021.

[6] Y. Wang, D. Zhang, J. Wang, Z. Chen, Y. Li, Y. Wang, 和 R. Xiong, “分层驾驶模型的模仿学习:从连续意图到连续轨迹”，IEEE机器人与自动化快报，2021年。

[7] H. Li, S. J. Pan, S. Wang, and A. C. Kot, "Domain generalization with adversarial feature learning," in Proceedings of the IEEE Conference on Computer Vision and Pattern Recognition, pp. 5400-5409, 2018.

[7] H. Li, S. J. Pan, S. Wang, 和 A. C. Kot, “通过对抗特征学习实现领域泛化”，发表于IEEE计算机视觉与模式识别会议，页5400-5409，2018年。

[8] F. M. Carlucci, P. Russo, T. Tommasi, and B. Caputo, "Hallucinating agnostic images to generalize across domains.," in ICCV Workshops, pp. 3227-3234, 2019.

[8] F. M. Carlucci, P. Russo, T. Tommasi, 和 B. Caputo, “通过幻觉生成无关图像以实现跨域泛化”，发表于ICCV研讨会，页3227-3234，2019年。

[9] J. Xing, T. Nagata, K. Chen, X. Zou, E. Neftci, and J. L. Krichmar, "Domain adaptation in reinforcement learning via latent unified state representation," arXiv preprint arXiv:2102.05714, 2021.

[9] J. Xing, T. Nagata, K. Chen, X. Zou, E. Neftci, 和 J. L. Krichmar, “通过潜在统一状态表示实现强化学习中的领域适应”，arXiv预印本 arXiv:2102.05714，2021年。

[10] G. Kahn, A. Villaflor, V. Pong, P. Abbeel, and S. Levine, "Uncertainty-aware reinforcement learning for collision avoidance," arXiv preprint arXiv:1702.01182, 2017.

[10] G. Kahn, A. Villaflor, V. Pong, P. Abbeel, 和 S. Levine, “面向碰撞避免的不确定性感知强化学习”，arXiv预印本 arXiv:1702.01182，2017年。

[11] L. Tai, P. Yun, Y. Chen, C. Liu, H. Ye, and M. Liu, "Visual-based autonomous driving deployment from a stochastic and uncertainty-aware perspective," in 2019 IEEE/RSJ International Conference on Intelligent Robots and Systems (IROS), pp. 2622-2628, IEEE, 2019.

[11] L. Tai, P. Yun, Y. Chen, C. Liu, H. Ye, 和 M. Liu, “基于视觉的自动驾驶部署:一种随机性与不确定性感知视角”，发表于2019年IEEE/RSJ国际智能机器人与系统会议(IROS)，页2622-2628，IEEE，2019年。

[12] D. Krueger, E. Caballero, J.-H. Jacobsen, A. Zhang, J. Binas, D. Zhang, R. Le Priol, and A. Courville, "Out-of-distribution generalization via risk extrapolation (rex)," in International Conference on Machine Learning, pp. 5815-5826, PMLR, 2021.

[12] D. Krueger, E. Caballero, J.-H. Jacobsen, A. Zhang, J. Binas, D. Zhang, R. Le Priol, 和 A. Courville, “通过风险外推(Risk Extrapolation, REx)实现分布外泛化”，发表于国际机器学习大会，页5815-5826，PMLR，2021年。

[13] W. Jin, R. Barzilay, and T. Jaakkola, "Domain extrapolation via regret minimization," arXiv preprint arXiv:2006.03908, 2020.

[13] W. Jin, R. Barzilay, 和 T. Jaakkola, “通过后悔最小化实现领域外推”，arXiv预印本 arXiv:2006.03908，2020年。

[14] E. Rosenfeld, P. Ravikumar, and A. Risteski, "The risks of invariant risk minimization," arXiv preprint arXiv:2010.05761, 2020.

[14] E. Rosenfeld, P. Ravikumar, 和 A. Risteski, “不变风险最小化的风险”，arXiv预印本 arXiv:2010.05761，2020年。

[15] K. Ahuja, K. Shanmugam, K. Varshney, and A. Dhurandhar, "Invariant risk minimization games," in International Conference on Machine Learning, pp. 145-155, PMLR, 2020.

[15] K. Ahuja, K. Shanmugam, K. Varshney, 和 A. Dhurandhar, “不变风险最小化博弈”，发表于国际机器学习大会，页145-155，PMLR，2020年。

[16] A. Zhang, R. T. McAllister, R. Calandra, Y. Gal, and S. Levine, "Learning invariant representations for reinforcement learning without reconstruction," in International Conference on Learning Representations, 2021.

[16] A. Zhang, R. T. McAllister, R. Calandra, Y. Gal, 和 S. Levine, “无重构的强化学习不变表示学习”，发表于国际表征学习大会，2021年。

[17] E. Rosenfeld, P. K. Ravikumar, and A. Risteski, "The risks of invariant risk minimization," in International Conference on Learning Representations, 2021.

[17] E. Rosenfeld, P. K. Ravikumar, 和 A. Risteski, “不变风险最小化的风险”，发表于国际表征学习大会，2021年。

[18] A. Amini, G. Rosman, S. Karaman, and D. Rus, "Variational end-to-end navigation and localization," in 2019 International Conference on Robotics and Automation (ICRA), pp. 8958-8964, IEEE, 2019.

[18] A. Amini, G. Rosman, S. Karaman, 和 D. Rus, “变分端到端导航与定位”，发表于2019年国际机器人与自动化会议(ICRA)，页8958-8964，IEEE，2019年。

[19] H. Ma, Y. Wang, L. Tang, S. Kodagoda, and R. Xiong, "Towards navigation without precise localization: Weakly supervised learning of goal-directed navigation cost map," arXiv preprint arXiv:1906.02468, 2019.

[19] H. Ma, Y. Wang, L. Tang, S. Kodagoda, 和 R. Xiong, “迈向无需精确定位的导航:基于弱监督的目标导向导航代价地图学习”，arXiv预印本 arXiv:1906.02468，2019年。

[20] M. Mirza and S. Osindero, "Conditional generative adversarial nets," arXiv preprint arXiv:1411.1784, 2014.

[20] M. Mirza 和 S. Osindero, “条件生成对抗网络(Conditional generative adversarial nets),” arXiv 预印本 arXiv:1411.1784, 2014.

[21] I. Gulrajani, F. Ahmed, M. Arjovsky, V. Dumoulin, and A. Courville, "Improved training of wasserstein gans," arXiv preprint arXiv:1704.00028, 2017.

[21] I. Gulrajani, F. Ahmed, M. Arjovsky, V. Dumoulin 和 A. Courville, “改进的 Wasserstein GAN(wasserstein gans)训练方法,” arXiv 预印本 arXiv:1704.00028, 2017.

[22] D. Barnes, M. Gadd, P. Murcutt, P. Newman, and I. Posner, "The oxford radar robotcar dataset: A radar extension to the oxford robotcar dataset," in 2020 IEEE International Conference on Robotics and Automation (ICRA), pp. 6433-6438, IEEE, 2020.

[22] D. Barnes, M. Gadd, P. Murcutt, P. Newman 和 I. Posner, “牛津雷达机器人车数据集:牛津机器人车数据集的雷达扩展,” 载于 2020 年 IEEE 国际机器人与自动化会议(ICRA)，第 6433-6438 页，IEEE, 2020.

[23] W. Maddern, G. Pascoe, C. Linegar, and P. Newman, "1 year, 1000 km: The oxford robotcar dataset," The International Journal of Robotics Research, vol. 36, no. 1, pp. 3-15, 2017.

[23] W. Maddern, G. Pascoe, C. Linegar 和 P. Newman, “1 年，1000 公里:牛津机器人车数据集,” 《国际机器人研究杂志》，第 36 卷，第 1 期，第 3-15 页，2017.

[24] A. Geiger, P. Lenz, C. Stiller, and R. Urtasun, "Vision meets robotics: The kitti dataset," The International Journal of Robotics Research, vol. 32, no. 11, pp. 1231-1237, 2013.

[24] A. Geiger, P. Lenz, C. Stiller 和 R. Urtasun, “视觉遇见机器人学:KITTI 数据集,” 《国际机器人研究杂志》，第 32 卷，第 11 期，第 1231-1237 页，2013.

[25] A. Dosovitskiy, G. Ros, F. Codevilla, A. Lopez, and V. Koltun, "Carla: An open urban driving simulator," in Conference on robot learning, pp. 1-16, PMLR, 2017.

[25] A. Dosovitskiy, G. Ros, F. Codevilla, A. Lopez 和 V. Koltun, “CARLA:一个开放的城市驾驶模拟器,” 载于机器人学习会议，PMLR，第 1-16 页，2017.

[26] P. Cai, Y. Sun, H. Wang, and M. Liu, "Vtgnet: A vision-based trajectory generation network for autonomous vehicles in urban environments," IEEE Transactions on Intelligent Vehicles, 2020.

[26] P. Cai, Y. Sun, H. Wang 和 M. Liu, “VTGNet:一种基于视觉的城市环境自动驾驶轨迹生成网络,” 《IEEE 智能车辆汇刊》，2020.

[27] D. P. Kingma and J. Ba, "Adam: A method for stochastic optimization," arXiv preprint arXiv:1412.6980, 2014.

[27] D. P. Kingma 和 J. Ba, “Adam:一种随机优化方法,” arXiv 预印本 arXiv:1412.6980, 2014.

[28] K. Zhou, Y. Yang, Y. Qiao, and T. Xiang, "Domain generalization with mixstyle," in International Conference on Learning Representations, 2021.

[28] K. Zhou, Y. Yang, Y. Qiao 和 T. Xiang, “带有 MixStyle 的领域泛化,” 载于国际表征学习会议，2021.

[29] Y. Ganin and V. Lempitsky, "Unsupervised domain adaptation by backpropagation," in International conference on machine learning, pp. 1180-1189, PMLR, 2015.

[29] Y. Ganin 和 V. Lempitsky, “通过反向传播实现无监督领域自适应,” 载于国际机器学习会议，PMLR，第 1180-1189 页，2015.