## Visualizing Data using t-SNE

## 使用t-SNE进行数据可视化

Laurens van der Maaten LVDMAATEN@GMAIL.COM

Laurens van der Maaten LVDMAATEN@GMAIL.COM

TiCC

TiCC

Tilburg University

蒂尔堡大学

P.O. Box 90153, 5000 LE Tilburg, The Netherlands

邮政信箱90153，5000 LE 蒂尔堡，荷兰

Geoffrey Hinton HINTON@CS.TORONTO.EDU

Geoffrey Hinton HINTON@CS.TORONTO.EDU

Department of Computer Science

计算机科学系

University of Toronto

多伦多大学

6 King's College Road, M5S 3G4 Toronto, ON, Canada

国王学院路6号，M5S 3G4 多伦多，安大略，加拿大

Editor: Yoshua Bengio

编辑:Yoshua Bengio

## Abstract

## 摘要

We present a new technique called "t-SNE" that visualizes high-dimensional data by giving each datapoint a location in a two or three-dimensional map. The technique is a variation of Stochastic Neighbor Embedding (Hinton and Roweis, 2002) that is much easier to optimize, and produces significantly better visualizations by reducing the tendency to crowd points together in the center of the map. t-SNE is better than existing techniques at creating a single map that reveals structure at many different scales. This is particularly important for high-dimensional data that lie on several different, but related, low-dimensional manifolds, such as images of objects from multiple classes seen from multiple viewpoints. For visualizing the structure of very large data sets, we show how t-SNE can use random walks on neighborhood graphs to allow the implicit structure of all of the data to influence the way in which a subset of the data is displayed. We illustrate the performance of t-SNE on a wide variety of data sets and compare it with many other non-parametric visualization techniques, including Sammon mapping, Isomap, and Locally Linear Embedding. The visualizations produced by t-SNE are significantly better than those produced by the other techniques on almost all of the data sets.

我们提出了一种名为“t-SNE”的新技术，通过为每个数据点在二维或三维地图上分配位置来可视化高维数据。该技术是随机邻居嵌入(Stochastic Neighbor Embedding，Hinton和Roweis，2002)的变体，更易于优化，并通过减少数据点在地图中心聚集的倾向，显著提升了可视化效果。t-SNE优于现有技术，能够创建揭示多尺度结构的单一地图。这对于位于多个相关低维流形上的高维数据尤为重要，例如从多个视角观察的多类别物体图像。针对非常大规模数据集的结构可视化，我们展示了t-SNE如何利用邻域图上的随机游走，使所有数据的隐含结构影响所显示数据子集的方式。我们在多种数据集上展示了t-SNE的性能，并与Sammon映射、Isomap和局部线性嵌入(Locally Linear Embedding)等多种非参数可视化技术进行了比较。t-SNE生成的可视化结果在几乎所有数据集上均显著优于其他技术。

Keywords: visualization, dimensionality reduction, manifold learning, embedding algorithms, multidimensional scaling

关键词:可视化，降维，流形学习，嵌入算法，多维尺度分析

## 1. Introduction

## 1. 引言

Visualization of high-dimensional data is an important problem in many different domains, and deals with data of widely varying dimensionality. Cell nuclei that are relevant to breast cancer, for example, are described by approximately 30 variables (Street et al., 1993), whereas the pixel intensity vectors used to represent images or the word-count vectors used to represent documents typically have thousands of dimensions. Over the last few decades, a variety of techniques for the visualization of such high-dimensional data have been proposed, many of which are reviewed by de Oliveira and Levkowitz (2003). Important techniques include iconographic displays such as Chernoff faces (Chernoff, 1973), pixel-based techniques (Keim, 2000), and techniques that represent the dimensions in the data as vertices in a graph (Battista et al., 1994). Most of these techniques simply provide tools to display more than two data dimensions, and leave the interpretation of the data to the human observer. This severely limits the applicability of these techniques to real-world data sets that contain thousands of high-dimensional datapoints.

高维数据的可视化是许多不同领域中的重要问题，涉及维度差异极大的数据。例如，与乳腺癌相关的细胞核由约30个变量描述(Street等，1993)，而用于表示图像的像素强度向量或用于表示文档的词频向量通常具有数千维。过去几十年中，已经提出了多种高维数据可视化技术，许多技术由de Oliveira和Levkowitz(2003)进行了综述。重要的技术包括图标显示如Chernoff脸(Chernoff，1973)、基于像素的技术(Keim，2000)以及将数据维度表示为图中顶点的技术(Battista等，1994)。这些技术大多仅提供显示超过二维数据的工具，数据的解释则依赖于人类观察者。这极大限制了这些技术在包含数千个高维数据点的真实数据集中的应用。

In contrast to the visualization techniques discussed above, dimensionality reduction methods convert the high-dimensional data set $\mathcal{X} = \left\{  {{\mathrm{x}}_{1},{\mathrm{x}}_{2},\ldots ,{\mathrm{x}}_{\mathrm{n}}}\right\}$ into two or three-dimensional data $\mathcal{Y} =$ $\left\{  {{\mathrm{y}}_{1},{\mathrm{y}}_{2},\ldots ,{\mathrm{y}}_{\mathrm{n}}}\right\}$ that can be displayed in a scatterplot. In the paper, we refer to the low-dimensional data representation $\mathcal{Y}$ as a map, and to the low-dimensional representations ${\mathrm{y}}_{\mathrm{i}}$ of individual da-tapoints as map points. The aim of dimensionality reduction is to preserve as much of the significant structure of the high-dimensional data as possible in the low-dimensional map. Various techniques for this problem have been proposed that differ in the type of structure they preserve. Traditional dimensionality reduction techniques such as Principal Components Analysis (PCA; Hotelling, 1933) and classical multidimensional scaling (MDS; Torgerson, 1952) are linear techniques that focus on keeping the low-dimensional representations of dissimilar datapoints far apart. For high-dimensional data that lies on or near a low-dimensional, non-linear manifold it is usually more important to keep the low-dimensional representations of very similar datapoints close together, which is typically not possible with a linear mapping.

与上述可视化技术不同，降维方法将高维数据集$\mathcal{X} = \left\{  {{\mathrm{x}}_{1},{\mathrm{x}}_{2},\ldots ,{\mathrm{x}}_{\mathrm{n}}}\right\}$转换为二维或三维数据$\mathcal{Y} =$ $\left\{  {{\mathrm{y}}_{1},{\mathrm{y}}_{2},\ldots ,{\mathrm{y}}_{\mathrm{n}}}\right\}$，可在散点图中显示。本文中，我们将低维数据表示$\mathcal{Y}$称为地图，将单个数据点的低维表示${\mathrm{y}}_{\mathrm{i}}$称为地图点。降维的目标是在低维地图中尽可能保留高维数据的重要结构。针对该问题，已提出多种技术，区别在于它们保留的结构类型。传统降维技术如主成分分析(Principal Components Analysis，PCA；Hotelling，1933)和经典多维尺度分析(Multidimensional Scaling，MDS；Torgerson，1952)是线性技术，侧重于保持低维表示中不相似数据点的距离较远。对于位于或接近低维非线性流形上的高维数据，通常更重要的是保持非常相似数据点的低维表示彼此接近，而这通常无法通过线性映射实现。

A large number of nonlinear dimensionality reduction techniques that aim to preserve the local structure of data have been proposed, many of which are reviewed by Lee and Verleysen (2007). In particular, we mention the following seven techniques: (1) Sammon mapping (Sammon, 1969), (2) curvilinear components analysis (CCA; Demartines and Hérault, 1997), (3) Stochastic Neighbor Embedding (SNE; Hinton and Roweis, 2002), (4) Isomap (Tenenbaum et al., 2000), (5) Maximum Variance Unfolding (MVU; Weinberger et al., 2004), (6) Locally Linear Embedding (LLE; Roweis and Saul, 2000), and (7) Laplacian Eigenmaps (Belkin and Niyogi, 2002). Despite the strong performance of these techniques on artificial data sets, they are often not very successful at visualizing real, high-dimensional data. In particular, most of the techniques are not capable of retaining both the local and the global structure of the data in a single map. For instance, a recent study reveals that even a semi-supervised variant of MVU is not capable of separating handwritten digits into their natural clusters (Song et al., 2007).

已经提出了大量旨在保持数据局部结构的非线性降维技术，其中许多由Lee和Verleysen(2007)进行了综述。特别地，我们提到以下七种技术:(1)Sammon映射(Sammon，1969)，(2)曲线成分分析(CCA；Demartines和Hérault，1997)，(3)随机邻居嵌入(SNE；Hinton和Roweis，2002)，(4)Isomap(Tenenbaum等，2000)，(5)最大方差展开(MVU；Weinberger等，2004)，(6)局部线性嵌入(LLE；Roweis和Saul，2000)，以及(7)拉普拉斯特征映射(Laplacian Eigenmaps；Belkin和Niyogi，2002)。尽管这些技术在人工数据集上表现出色，但它们在可视化真实高维数据时往往效果不佳。特别是，大多数技术无法在单一映射中同时保留数据的局部和全局结构。例如，最近的一项研究表明，即使是MVU的半监督变体也无法将手写数字分离成其自然簇(Song等，2007)。

In this paper, we describe a way of converting a high-dimensional data set into a matrix of pairwise similarities and we introduce a new technique, called "t-SNE", for visualizing the resulting similarity data. t-SNE is capable of capturing much of the local structure of the high-dimensional data very well, while also revealing global structure such as the presence of clusters at several scales. We illustrate the performance of t-SNE by comparing it to the seven dimensionality reduction techniques mentioned above on five data sets from a variety of domains. Because of space limitations, most of the $\left( {7 + 1}\right)  \times  5 = {40}$ maps are presented in the supplemental material, but the maps that we present in the paper are sufficient to demonstrate the superiority of t-SNE.

本文介绍了一种将高维数据集转换为成对相似度矩阵的方法，并引入了一种名为“t-SNE”的新技术，用于可视化所得的相似度数据。t-SNE能够很好地捕捉高维数据的局部结构，同时揭示诸如多尺度簇存在等全局结构。我们通过在来自多个领域的五个数据集上，将t-SNE与上述七种降维技术进行比较，来展示其性能。由于篇幅限制，大部分$\left( {7 + 1}\right)  \times  5 = {40}$映射图展示在补充材料中，但本文中展示的映射图足以证明t-SNE的优越性。

The outline of the paper is as follows. In Section 2, we outline SNE as presented by Hinton and Roweis (2002), which forms the basis for t-SNE. In Section 3, we present t-SNE, which has two important differences from SNE. In Section 4, we describe the experimental setup and the results of our experiments. Subsequently, Section 5 shows how t-SNE can be modified to visualize real-world data sets that contain many more than 10,000 datapoints. The results of our experiments are discussed in more detail in Section 6. Our conclusions and suggestions for future work are presented in Section 7.

本文结构如下。第2节概述了Hinton和Roweis(2002)提出的SNE，它构成了t-SNE的基础。第3节介绍了t-SNE，其与SNE有两个重要区别。第4节描述了实验设置及实验结果。随后，第5节展示了如何修改t-SNE以可视化包含超过10,000个数据点的真实数据集。第6节对实验结果进行了更详细的讨论。第7节给出了结论及未来工作的建议。

## 2. Stochastic Neighbor Embedding

## 2. 随机邻居嵌入

Stochastic Neighbor Embedding (SNE) starts by converting the high-dimensional Euclidean distances between datapoints into conditional probabilities that represent similarities. ${}^{1}$ The similarity of datapoint ${\mathrm{x}}_{\mathrm{j}}$ to datapoint ${\mathrm{x}}_{\mathrm{i}}$ is the conditional probability, ${\mathrm{p}}_{\mathrm{j} \mid  \mathrm{i}}$ , that ${\mathrm{x}}_{\mathrm{i}}$ would pick ${\mathrm{x}}_{\mathrm{j}}$ as its neighbor if neighbors were picked in proportion to their probability density under a Gaussian centered at ${\mathrm{x}}_{\mathrm{i}}$ . For nearby datapoints, ${\mathrm{p}}_{\mathrm{j} \mid  \mathrm{i}}$ is relatively high, whereas for widely separated datapoints, ${\mathrm{p}}_{\mathrm{j} \mid  \mathrm{i}}$ will be almost infinitesimal (for reasonable values of the variance of the Gaussian, ${\sigma }_{\mathrm{i}}$ ). Mathematically, the conditional probability ${\mathrm{p}}_{\mathrm{j} \mid  \mathrm{i}}$ is given by

随机邻居嵌入(SNE)首先将数据点之间的高维欧氏距离转换为表示相似度的条件概率。${}^{1}$数据点${\mathrm{x}}_{\mathrm{j}}$对数据点${\mathrm{x}}_{\mathrm{i}}$的相似度是条件概率${\mathrm{p}}_{\mathrm{j} \mid  \mathrm{i}}$，即如果邻居是按以${\mathrm{x}}_{\mathrm{i}}$为中心的高斯分布的概率密度成比例选择的，${\mathrm{x}}_{\mathrm{i}}$选择${\mathrm{x}}_{\mathrm{j}}$作为邻居的概率。对于相近的数据点，${\mathrm{p}}_{\mathrm{j} \mid  \mathrm{i}}$相对较高，而对于相距较远的数据点，${\mathrm{p}}_{\mathrm{j} \mid  \mathrm{i}}$几乎可以忽略不计(对于高斯分布的合理方差值${\sigma }_{\mathrm{i}}$而言)。数学上，条件概率${\mathrm{p}}_{\mathrm{j} \mid  \mathrm{i}}$由下式给出

$$
{\mathrm{p}}_{\mathrm{j} \mid  \mathrm{i}} = \frac{\exp \left( {-{\begin{Vmatrix}{\mathrm{x}}_{\mathrm{i}} - {\mathrm{x}}_{\mathrm{j}}\end{Vmatrix}}^{2}/2{\sigma }_{\mathrm{i}}^{2}}\right) }{\mathop{\sum }\limits_{{\mathrm{k} \neq  \mathrm{i}}}\exp \left( {-{\begin{Vmatrix}{\mathrm{x}}_{\mathrm{i}} - {\mathrm{x}}_{\mathrm{k}}\end{Vmatrix}}^{2}/2{\sigma }_{\mathrm{i}}^{2}}\right) }, \tag{1}
$$

where ${\sigma }_{\mathrm{i}}$ is the variance of the Gaussian that is centered on datapoint ${\mathrm{x}}_{\mathrm{i}}$ . The method for determining the value of ${\sigma }_{\mathrm{i}}$ is presented later in this section. Because we are only interested in modeling pairwise similarities, we set the value of ${\mathrm{p}}_{\mathrm{i} \mid  \mathrm{i}}$ to zero. For the low-dimensional counterparts ${\mathrm{y}}_{\mathrm{i}}$ and ${\mathrm{y}}_{\mathrm{j}}$ of the high-dimensional datapoints ${\mathrm{x}}_{\mathrm{i}}$ and ${\mathrm{x}}_{\mathrm{j}}$ , it is possible to compute a similar conditional probability, which we denote by ${q}_{\left. j\right| i}$ . We set ${}^{2}$ the variance of the Gaussian that is employed in the computation of the conditional probabilities ${\mathrm{q}}_{\mathrm{j} \mid  \mathrm{i}}$ to $\frac{1}{\sqrt{2}}$ . Hence, we model the similarity of map point ${\mathrm{y}}_{\mathrm{j}}$ to map

其中 ${\sigma }_{\mathrm{i}}$ 是以数据点 ${\mathrm{x}}_{\mathrm{i}}$ 为中心的高斯分布的方差。本节后面将介绍确定 ${\sigma }_{\mathrm{i}}$ 值的方法。由于我们只关注建模成对相似度，因此将 ${\mathrm{p}}_{\mathrm{i} \mid  \mathrm{i}}$ 设为零。对于高维数据点 ${\mathrm{x}}_{\mathrm{i}}$ 和 ${\mathrm{x}}_{\mathrm{j}}$ 的低维对应点 ${\mathrm{y}}_{\mathrm{i}}$ 和 ${\mathrm{y}}_{\mathrm{j}}$，可以计算类似的条件概率，记为 ${q}_{\left. j\right| i}$。我们将用于计算条件概率 ${\mathrm{q}}_{\mathrm{j} \mid  \mathrm{i}}$ 的高斯分布的方差 ${}^{2}$ 设为 $\frac{1}{\sqrt{2}}$。因此，我们对映射点 ${\mathrm{y}}_{\mathrm{j}}$ 与映射

point ${y}_{i}$ by

点 ${y}_{i}$ 之间的相似度进行建模

$$
{\mathrm{q}}_{\mathrm{j} \mid  \mathrm{i}} = \frac{\exp \left( {-{\begin{Vmatrix}{\mathrm{y}}_{\mathrm{i}} - {\mathrm{y}}_{\mathrm{j}}\end{Vmatrix}}^{2}}\right) }{\mathop{\sum }\limits_{{\mathrm{k} \neq  \mathrm{i}}}\exp \left( {-{\begin{Vmatrix}{\mathrm{y}}_{\mathrm{i}} - {\mathrm{y}}_{\mathrm{k}}\end{Vmatrix}}^{2}}\right) }.
$$

Again, since we are only interested in modeling pairwise similarities, we set ${\mathrm{q}}_{\mathrm{i} \mid  \mathrm{i}} = 0$ .

同样，由于我们只关注建模成对相似度，我们将 ${\mathrm{q}}_{\mathrm{i} \mid  \mathrm{i}} = 0$ 设为零。

If the map points ${y}_{i}$ and ${y}_{j}$ correctly model the similarity between the high-dimensional data-points ${\mathrm{x}}_{\mathrm{i}}$ and ${\mathrm{x}}_{\mathrm{j}}$ , the conditional probabilities ${\mathrm{p}}_{\mathrm{j} \mid  \mathrm{i}}$ and ${\mathrm{q}}_{\mathrm{j} \mid  \mathrm{i}}$ will be equal. Motivated by this observation, SNE aims to find a low-dimensional data representation that minimizes the mismatch between ${p}_{j \mid  i}$ and ${q}_{j \mid  i}$ . A natural measure of the faithfulness with which ${q}_{j \mid  i}$ models ${p}_{j \mid  i}$ is the Kullback-Leibler divergence (which is in this case equal to the cross-entropy up to an additive constant). SNE minimizes the sum of Kullback-Leibler divergences over all datapoints using a gradient descent method. The cost function $\mathrm{C}$ is given by

如果映射点 ${y}_{i}$ 和 ${y}_{j}$ 能正确地模拟高维数据点 ${\mathrm{x}}_{\mathrm{i}}$ 和 ${\mathrm{x}}_{\mathrm{j}}$ 之间的相似度，则条件概率 ${\mathrm{p}}_{\mathrm{j} \mid  \mathrm{i}}$ 和 ${\mathrm{q}}_{\mathrm{j} \mid  \mathrm{i}}$ 将相等。基于这一观察，SNE(随机邻域嵌入)旨在找到一个低维数据表示，最小化 ${p}_{j \mid  i}$ 和 ${q}_{j \mid  i}$ 之间的不匹配。衡量 ${q}_{j \mid  i}$ 对 ${p}_{j \mid  i}$ 模型忠实度的自然指标是Kullback-Leibler散度(在此情况下等价于加上一个常数项的交叉熵)。SNE通过梯度下降法最小化所有数据点的Kullback-Leibler散度之和。代价函数 $\mathrm{C}$ 定义为

$$
\mathrm{C} = \mathop{\sum }\limits_{\mathrm{i}}\mathrm{{KL}}\left( {{\mathrm{P}}_{\mathrm{i}}\parallel {\mathrm{Q}}_{\mathrm{i}}}\right)  = \mathop{\sum }\limits_{\mathrm{i}}\mathop{\sum }\limits_{\mathrm{j}}{\mathrm{p}}_{\mathrm{j} \mid  \mathrm{i}}\log \frac{{\mathrm{p}}_{\mathrm{j} \mid  \mathrm{i}}}{{\mathrm{q}}_{\mathrm{j} \mid  \mathrm{i}}}, \tag{2}
$$

in which ${\mathrm{P}}_{\mathrm{i}}$ represents the conditional probability distribution over all other datapoints given datapoint ${\mathrm{x}}_{\mathrm{i}}$ , and ${\mathrm{Q}}_{\mathrm{i}}$ represents the conditional probability distribution over all other map points given map point ${\mathrm{y}}_{\mathrm{i}}$ . Because the Kullback-Leibler divergence is not symmetric, different types of error in the pairwise distances in the low-dimensional map are not weighted equally. In particular, there is a large cost for using widely separated map points to represent nearby datapoints (i.e., for using a small ${\mathrm{q}}_{\mathrm{j} \mid  \mathrm{i}}$ to model a large ${\mathrm{p}}_{\mathrm{j} \mid  \mathrm{i}}$ ), but there is only a small cost for using nearby map points to represent widely separated datapoints. This small cost comes from wasting some of the probability mass in the relevant $\mathrm{Q}$ distributions. In other words, the SNE cost function focuses on retaining the local structure of the data in the map (for reasonable values of the variance of the Gaussian in the high-dimensional space, ${\sigma }_{\mathrm{i}}$ ).

其中 ${\mathrm{P}}_{\mathrm{i}}$ 表示给定数据点 ${\mathrm{x}}_{\mathrm{i}}$ 时对所有其他数据点的条件概率分布，${\mathrm{Q}}_{\mathrm{i}}$ 表示给定映射点 ${\mathrm{y}}_{\mathrm{i}}$ 时对所有其他映射点的条件概率分布。由于Kullback-Leibler散度不对称，低维映射中成对距离的不同类型误差权重不同。特别地，使用相距较远的映射点来表示相近的数据点(即用小的 ${\mathrm{q}}_{\mathrm{j} \mid  \mathrm{i}}$ 来模拟大的 ${\mathrm{p}}_{\mathrm{j} \mid  \mathrm{i}}$)会产生较大代价，而用相近的映射点来表示相距较远的数据点代价较小。这种较小的代价源于在相关的 $\mathrm{Q}$ 分布中浪费了一部分概率质量。换言之，SNE代价函数侧重于保持映射中数据的局部结构(对于高维空间中高斯方差 ${\sigma }_{\mathrm{i}}$ 的合理取值)。

---

1. SNE can also be applied to data sets that consist of pairwise similarities between objects rather than high-dimensional vector representations of each object, provided these simiarities can be interpreted as conditional probabilities. For example, human word association data consists of the probability of producing each possible word in response to a given word, as a result of which it is already in the form required by SNE.

1. SNE也可以应用于由对象间成对相似度组成的数据集，而非每个对象的高维向量表示，前提是这些相似度可以解释为条件概率。例如，人类词语联想数据包含了在给定词语时产生每个可能词语的概率，因此已经符合SNE所需的形式。

2. Setting the variance in the low-dimensional Gaussians to another value only results in a rescaled version of the final map. Note that by using the same variance for every datapoint in the low-dimensional map, we lose the property that the data is a perfect model of itself if we embed it in a space of the same dimensionality, because in the high-dimensional space, we used a different variance ${\sigma }_{\mathrm{i}}$ in each Gaussian.

2. 将低维高斯分布的方差设为其他值仅会导致最终映射的缩放版本。注意，通过对低维映射中的每个数据点使用相同的方差，我们失去了如果将数据嵌入到相同维度空间中时数据自身是完美模型的性质，因为在高维空间中，我们对每个高斯分布使用了不同的方差${\sigma }_{\mathrm{i}}$。

---

The remaining parameter to be selected is the variance ${\sigma }_{i}$ of the Gaussian that is centered over each high-dimensional datapoint, ${\mathrm{x}}_{\mathrm{i}}$ . It is not likely that there is a single value of ${\sigma }_{\mathrm{i}}$ that is optimal for all datapoints in the data set because the density of the data is likely to vary. In dense regions, a smaller value of ${\sigma }_{i}$ is usually more appropriate than in sparser regions. Any particular value of ${\sigma }_{i}$ induces a probability distribution, ${P}_{i}$ , over all of the other datapoints. This distribution has an entropy which increases as ${\sigma }_{\mathrm{i}}$ increases. SNE performs a binary search for the value of ${\sigma }_{\mathrm{i}}$ that produces a ${\mathrm{P}}_{\mathrm{i}}$ with a fixed perplexity that is specified by the user. ${}^{3}$ The perplexity is defined as

剩下需要选择的参数是以每个高维数据点为中心的高斯分布的方差${\sigma }_{i}$，${\mathrm{x}}_{\mathrm{i}}$。由于数据密度可能变化，数据集中不太可能存在一个对所有数据点都最优的${\sigma }_{\mathrm{i}}$值。在密集区域，较小的${\sigma }_{i}$值通常比在稀疏区域更合适。任何特定的${\sigma }_{i}$值都会引入一个概率分布，${P}_{i}$，覆盖所有其他数据点。该分布的熵随着${\sigma }_{\mathrm{i}}$的增加而增加。SNE通过二分搜索寻找产生具有用户指定固定困惑度${\mathrm{P}}_{\mathrm{i}}$的${\sigma }_{\mathrm{i}}$值。${}^{3}$困惑度定义为

$$
\operatorname{Per}\mathrm{p}\left( {\mathrm{P}}_{\mathrm{i}}\right)  = {2}^{\mathrm{H}\left( {\mathrm{P}}_{\mathrm{i}}\right) },
$$

where $\mathrm{H}\left( {\mathrm{P}}_{\mathrm{i}}\right)$ is the Shannon entropy of ${\mathrm{P}}_{\mathrm{i}}$ measured in bits

其中$\mathrm{H}\left( {\mathrm{P}}_{\mathrm{i}}\right)$是以比特为单位测量的${\mathrm{P}}_{\mathrm{i}}$的香农熵

$$
\mathrm{H}\left( {\mathrm{P}}_{\mathrm{i}}\right)  =  - \mathop{\sum }\limits_{\mathrm{j}}{\mathrm{p}}_{\mathrm{j} \mid  \mathrm{i}}{\log }_{2}{\mathrm{p}}_{\mathrm{j} \mid  \mathrm{i}}.
$$

The perplexity can be interpreted as a smooth measure of the effective number of neighbors. The performance of SNE is fairly robust to changes in the perplexity, and typical values are between 5 and 50 .

困惑度可以被解释为有效邻居数量的平滑度量。SNE的性能对困惑度的变化相当稳健，典型值介于5到50之间。

The minimization of the cost function in Equation 2 is performed using a gradient descent method. The gradient has a surprisingly simple form

方程2中代价函数的最小化是通过梯度下降法完成的。梯度具有出人意料的简单形式

$$
\frac{\delta C}{\delta {y}_{i}} = 2\mathop{\sum }\limits_{j}\left( {{p}_{j \mid  i} - {q}_{j \mid  i} + {p}_{i \mid  j} - {q}_{i \mid  j}}\right) \left( {{y}_{i} - {y}_{j}}\right) .
$$

Physically, the gradient may be interpreted as the resultant force created by a set of springs between the map point ${\mathrm{y}}_{\mathrm{i}}$ and all other map points ${\mathrm{y}}_{\mathrm{j}}$ . All springs exert a force along the direction $\left( {{\mathrm{y}}_{\mathrm{i}} - {\mathrm{y}}_{\mathrm{j}}}\right)$ . The spring between ${y}_{i}$ and ${y}_{j}$ repels or attracts the map points depending on whether the distance between the two in the map is too small or too large to represent the similarities between the two high-dimensional datapoints. The force exerted by the spring between ${y}_{i}$ and ${y}_{j}$ is proportional to its length, and also proportional to its stiffness, which is the mismatch $\left( {{\mathrm{p}}_{\mathrm{j} \mid  \mathrm{i}} - {\mathrm{q}}_{\mathrm{j} \mid  \mathrm{i}} + {\mathrm{p}}_{\mathrm{i} \mid  \mathrm{j}} - {\mathrm{q}}_{\mathrm{i} \mid  \mathrm{j}}}\right)$ between the pairwise similarities of the data points and the map points.

从物理角度看，梯度可以解释为映射点${\mathrm{y}}_{\mathrm{i}}$与所有其他映射点${\mathrm{y}}_{\mathrm{j}}$之间一组弹簧产生的合力。所有弹簧沿着方向$\left( {{\mathrm{y}}_{\mathrm{i}} - {\mathrm{y}}_{\mathrm{j}}}\right)$施加力。弹簧连接的${y}_{i}$和${y}_{j}$根据映射中两点之间的距离是否过小或过大以表示两个高维数据点之间的相似性，产生排斥或吸引力。弹簧施加的力与其长度成正比，也与其刚度成正比，刚度是数据点与映射点之间成对相似性的差异$\left( {{\mathrm{p}}_{\mathrm{j} \mid  \mathrm{i}} - {\mathrm{q}}_{\mathrm{j} \mid  \mathrm{i}} + {\mathrm{p}}_{\mathrm{i} \mid  \mathrm{j}} - {\mathrm{q}}_{\mathrm{i} \mid  \mathrm{j}}}\right)$。

The gradient descent is initialized by sampling map points randomly from an isotropic Gaussian with small variance that is centered around the origin. In order to speed up the optimization and to avoid poor local minima, a relatively large momentum term is added to the gradient. In other words, the current gradient is added to an exponentially decaying sum of previous gradients in order to determine the changes in the coordinates of the map points at each iteration of the gradient search. Mathematically, the gradient update with a momentum term is given by

梯度下降初始化时，从以原点为中心、方差较小的各向同性高斯分布中随机采样映射点。为了加快优化速度并避免陷入较差的局部极小值，梯度中加入了相对较大的动量项。换句话说，当前梯度会加到之前梯度的指数衰减和中，以确定每次梯度搜索迭代中映射点坐标的变化。数学上，带动量项的梯度更新表示为

$$
{\mathcal{Y}}^{\left( t\right) } = {\mathcal{Y}}^{\left( t - 1\right) } + \eta \frac{\delta C}{\delta \mathcal{Y}} + \alpha \left( t\right) \left( {{\mathcal{Y}}^{\left( t - 1\right) } - {\mathcal{Y}}^{\left( t - 2\right) }}\right) ,
$$

where ${\mathcal{Y}}^{\left( \mathrm{t}\right) }$ indicates the solution at iteration $\mathrm{t},\eta$ indicates the learning rate, and $\alpha \left( \mathrm{t}\right)$ represents the momentum at iteration $\mathrm{t}$ .

其中${\mathcal{Y}}^{\left( \mathrm{t}\right) }$表示第$\mathrm{t},\eta$次迭代的解，$\mathrm{t},\eta$表示学习率，$\alpha \left( \mathrm{t}\right)$表示第$\mathrm{t}$次迭代的动量。

---

3. Note that the perplexity increases monotonically with the variance ${\sigma }_{\mathrm{i}}$ .

3. 注意困惑度随着方差${\sigma }_{\mathrm{i}}$单调增加。

---

In addition, in the early stages of the optimization, Gaussian noise is added to the map points after each iteration. Gradually reducing the variance of this noise performs a type of simulated annealing that helps the optimization to escape from poor local minima in the cost function. If the variance of the noise changes very slowly at the critical point at which the global structure of the map starts to form, SNE tends to find maps with a better global organization. Unfortunately, this requires sensible choices of the initial amount of Gaussian noise and the rate at which it decays. Moreover, these choices interact with the amount of momentum and the step size that are employed in the gradient descent. It is therefore common to run the optimization several times on a data set to find appropriate values for the parameters. ${}^{4}$ In this respect, SNE is inferior to methods that allow convex optimization and it would be useful to find an optimization method that gives good results without requiring the extra computation time and parameter choices introduced by the simulated annealing.

此外，在优化的早期阶段，每次迭代后都会向地图点添加高斯噪声。逐渐减小该噪声的方差执行了一种模拟退火(simulated annealing)方法，有助于优化过程跳出代价函数中的劣质局部极小值。如果噪声方差在地图全局结构开始形成的关键点变化非常缓慢，SNE倾向于找到具有更好全局组织的地图。不幸的是，这需要对初始高斯噪声量和其衰减速率做出合理选择。此外，这些选择还与梯度下降中使用的动量大小和步长相互影响。因此，通常需要对数据集多次运行优化，以找到合适的参数值。${}^{4}$ 在这方面，SNE不如允许凸优化(convex optimization)的方法，找到一种无需模拟退火引入的额外计算时间和参数选择即可获得良好结果的优化方法将非常有用。

## 3. t-Distributed Stochastic Neighbor Embedding

## 3. t-分布随机邻居嵌入

Section 2 discussed SNE as it was presented by Hinton and Roweis (2002). Although SNE constructs reasonably good visualizations, it is hampered by a cost function that is difficult to optimize and by a problem we refer to as the "crowding problem". In this section, we present a new technique called "t-Distributed Stochastic Neighbor Embedding" or "t-SNE" that aims to alleviate these problems. The cost function used by t-SNE differs from the one used by SNE in two ways: (1) it uses a symmetrized version of the SNE cost function with simpler gradients that was briefly introduced by Cook et al. (2007) and (2) it uses a Student-t distribution rather than a Gaussian to compute the similarity between two points in the low-dimensional space. t-SNE employs a heavy-tailed distribution in the low-dimensional space to alleviate both the crowding problem and the optimization problems of SNE.

第2节讨论了Hinton和Roweis (2002)提出的SNE。尽管SNE构建了相当不错的可视化，但其受限于难以优化的代价函数以及我们称之为“拥挤问题”(crowding problem)的问题。本节介绍一种名为“t-分布随机邻居嵌入”(t-Distributed Stochastic Neighbor Embedding，简称t-SNE)的新技术，旨在缓解这些问题。t-SNE使用的代价函数与SNE的不同之处有两点:(1) 它采用了Cook等人(2007)简要介绍的对称化版本的SNE代价函数，具有更简单的梯度；(2) 它在低维空间中计算两点相似度时使用了Student-t分布，而非高斯分布。t-SNE在低维空间采用重尾分布(heavy-tailed distribution)，以缓解拥挤问题和SNE的优化难题。

In this section, we first discuss the symmetric version of SNE (Section 3.1). Subsequently, we discuss the crowding problem (Section 3.2), and the use of heavy-tailed distributions to address this problem (Section 3.3). We conclude the section by describing our approach to the optimization of the t-SNE cost function (Section 3.4).

本节首先讨论对称版本的SNE(第3.1节)。随后讨论拥挤问题(第3.2节)及采用重尾分布解决该问题的方法(第3.3节)。最后介绍我们对t-SNE代价函数的优化方法(第3.4节)。

### 3.1 Symmetric SNE

### 3.1 对称SNE

As an alternative to minimizing the sum of the Kullback-Leibler divergences between the conditional probabilities ${\mathrm{p}}_{\mathrm{i} \mid  \mathrm{i}}$ and ${\mathrm{q}}_{\mathrm{i} \mid  \mathrm{i}}$ , it is also possible to minimize a single Kullback-Leibler divergence between a joint probability distribution, $\mathrm{P}$ , in the high-dimensional space and a joint probability distribution, $\mathrm{Q}$ , in the low-dimensional space:

作为最小化条件概率${\mathrm{p}}_{\mathrm{i} \mid  \mathrm{i}}$和${\mathrm{q}}_{\mathrm{i} \mid  \mathrm{i}}$之间Kullback-Leibler散度之和的替代方法，也可以最小化高维空间中联合概率分布$\mathrm{P}$与低维空间中联合概率分布$\mathrm{Q}$之间的单一Kullback-Leibler散度:

$$
\mathrm{C} = \mathrm{{KL}}\left( {\mathrm{P}\parallel \mathrm{Q}}\right)  = \mathop{\sum }\limits_{\mathrm{i}}\mathop{\sum }\limits_{\mathrm{j}}{\mathrm{p}}_{\mathrm{{ij}}}\log \frac{{\mathrm{p}}_{\mathrm{{ij}}}}{{\mathrm{q}}_{\mathrm{{ij}}}}.
$$

where again, we set ${\mathrm{p}}_{\mathrm{{ii}}}$ and ${\mathrm{q}}_{\mathrm{{ii}}}$ to zero. We refer to this type of SNE as symmetric SNE, because it has the property that ${\mathrm{p}}_{\mathrm{{ij}}} = {\mathrm{p}}_{\mathrm{{ji}}}$ and ${\mathrm{q}}_{\mathrm{{ij}}} = {\mathrm{q}}_{\mathrm{{ji}}}$ for $\forall \mathrm{i},\mathrm{j}$ . In symmetric SNE, the pairwise similarities in

这里同样将${\mathrm{p}}_{\mathrm{{ii}}}$和${\mathrm{q}}_{\mathrm{{ii}}}$设为零。我们称这种SNE为对称SNE，因为它具有$\forall \mathrm{i},\mathrm{j}$时${\mathrm{p}}_{\mathrm{{ij}}} = {\mathrm{p}}_{\mathrm{{ji}}}$和${\mathrm{q}}_{\mathrm{{ij}}} = {\mathrm{q}}_{\mathrm{{ji}}}$相等的性质。在对称SNE中，

---

4. Picking the best map after several runs as a visualization of the data is not nearly as problematic as picking the model that does best on a test set during supervised learning. In visualization, the aim is to see the structure in the training data, not to generalize to held out test data.

4. 在多次运行后选择最佳地图作为数据的可视化结果，远不如在监督学习中选择在测试集上表现最好的模型那么棘手。在可视化中，目标是观察训练数据的结构，而非对未见测试数据进行泛化。

---

the low-dimensional map ${\mathrm{q}}_{\mathrm{i}\mathrm{j}}$ are given by

低维地图中的成对相似度${\mathrm{q}}_{\mathrm{i}\mathrm{j}}$由下式给出

$$
{\mathrm{q}}_{\mathrm{i}\mathrm{j}} = \frac{\exp \left( {-{\begin{Vmatrix}{\mathrm{y}}_{\mathrm{i}} - {\mathrm{y}}_{\mathrm{j}}\end{Vmatrix}}^{2}}\right) }{\mathop{\sum }\limits_{{\mathrm{k} \neq  1}}\exp \left( {-{\begin{Vmatrix}{\mathrm{y}}_{\mathrm{k}} - {\mathrm{y}}_{\mathrm{l}}\end{Vmatrix}}^{2}}\right) }, \tag{3}
$$

The obvious way to define the pairwise similarities in the high-dimensional space ${\mathrm{p}}_{\mathrm{i}\mathrm{j}}$ is

定义高维空间中成对相似度${\mathrm{p}}_{\mathrm{i}\mathrm{j}}$的显而易见方法是

$$
{\mathrm{p}}_{\mathrm{i}\mathrm{j}} = \frac{\exp \left( {-{\begin{Vmatrix}{\mathrm{x}}_{\mathrm{i}} - {\mathrm{x}}_{\mathrm{j}}\end{Vmatrix}}^{2}/2{\sigma }^{2}}\right) }{\mathop{\sum }\limits_{{\mathrm{k} \neq  \mathrm{l}}}\exp \left( {-{\begin{Vmatrix}{\mathrm{x}}_{\mathrm{k}} - {\mathrm{x}}_{\mathrm{l}}\end{Vmatrix}}^{2}/2{\sigma }^{2}}\right) },
$$

but this causes problems when a high-dimensional datapoint ${\mathrm{x}}_{\mathrm{i}}$ is an outlier (i.e., all pairwise distances ${\begin{Vmatrix}{\mathrm{x}}_{\mathrm{i}} - {\mathrm{x}}_{\mathrm{j}}\end{Vmatrix}}^{2}$ are large for ${\mathrm{x}}_{\mathrm{i}}$ ). For such an outlier, the values of ${\mathrm{p}}_{\mathrm{i}\mathrm{j}}$ are extremely small for all $\mathrm{j}$ , so the location of its low-dimensional map point ${\mathrm{y}}_{\mathrm{i}}$ has very little effect on the cost function. As a result, the position of the map point is not well determined by the positions of the other map points. We circumvent this problem by defining the joint probabilities ${p}_{ij}$ in the high-dimensional space to be the symmetrized conditional probabilities, that is, we set ${p}_{ij} = \frac{{p}_{j \mid  i} + {p}_{i \mid  j}}{2n}$ . This ensures that $\mathop{\sum }\limits_{j}{p}_{ij} > \frac{1}{2n}$ for all datapoints ${x}_{i}$ , as a result of which each datapoint ${x}_{i}$ makes a significant contribution to the cost function. In the low-dimensional space, symmetric SNE simply uses Equation 3. The main advantage of the symmetric version of SNE is the simpler form of its gradient, which is faster to compute. The gradient of symmetric SNE is fairly similar to that of asymmetric SNE, and is given by

但当一个高维数据点${\mathrm{x}}_{\mathrm{i}}$是异常值时(即对于${\mathrm{x}}_{\mathrm{i}}$所有成对距离${\begin{Vmatrix}{\mathrm{x}}_{\mathrm{i}} - {\mathrm{x}}_{\mathrm{j}}\end{Vmatrix}}^{2}$都很大)，这会引发问题。对于这样的异常值，所有$\mathrm{j}$的${\mathrm{p}}_{\mathrm{i}\mathrm{j}}$值都极小，因此其低维映射点${\mathrm{y}}_{\mathrm{i}}$的位置对代价函数几乎没有影响。结果，映射点的位置无法由其他映射点的位置很好地确定。我们通过在高维空间中将联合概率${p}_{ij}$定义为对称化的条件概率来规避这个问题，即我们设定${p}_{ij} = \frac{{p}_{j \mid  i} + {p}_{i \mid  j}}{2n}$。这确保了所有数据点${x}_{i}$的$\mathop{\sum }\limits_{j}{p}_{ij} > \frac{1}{2n}$，因此每个数据点${x}_{i}$都对代价函数有显著贡献。在低维空间中，对称SNE简单地使用方程3。对称SNE的主要优点是其梯度形式更简单，计算更快。对称SNE的梯度与非对称SNE相当相似，表达式为

$$
\frac{\delta C}{\delta {y}_{i}} = 4\mathop{\sum }\limits_{j}\left( {{p}_{ij} - {q}_{ij}}\right) \left( {{y}_{i} - {y}_{j}}\right) .
$$

In preliminary experiments, we observed that symmetric SNE seems to produce maps that are just as good as asymmetric SNE, and sometimes even a little better.

在初步实验中，我们观察到对称SNE似乎生成的映射与非对称SNE一样好，有时甚至略优。

### 3.2 The Crowding Problem

### 3.2 拥挤问题

Consider a set of datapoints that lie on a two-dimensional curved manifold which is approximately linear on a small scale, and which is embedded within a higher-dimensional space. It is possible to model the small pairwise distances between datapoints fairly well in a two-dimensional map, which is often illustrated on toy examples such as the "Swiss roll" data set. Now suppose that the manifold has ten intrinsic dimensions ${}^{5}$ and is embedded within a space of much higher dimensionality. There are several reasons why the pairwise distances in a two-dimensional map cannot faithfully model distances between points on the ten-dimensional manifold. For instance, in ten dimensions, it is possible to have 11 datapoints that are mutually equidistant and there is no way to model this faithfully in a two-dimensional map. A related problem is the very different distribution of pairwise distances in the two spaces. The volume of a sphere centered on datapoint i scales as ${\mathrm{r}}^{\mathrm{m}}$ , where $\mathrm{r}$ is the radius and $\mathrm{m}$ the dimensionality of the sphere. So if the datapoints are approximately uniformly distributed in the region around i on the ten-dimensional manifold, and we try to model the distances from i to the other datapoints in the two-dimensional map, we get the following "crowding problem": the area of the two-dimensional map that is available to accommodate moderately distant datapoints will not be nearly large enough compared with the area available to accommodate nearby datapoints. Hence, if we want to model the small distances accurately in the map, most of the points that are at a moderate distance from datapoint $\mathrm{i}$ will have to be placed much too far away in the two-dimensional map. In SNE, the spring connecting datapoint i to each of these too-distant map points will thus exert a very small attractive force. Although these attractive forces are very small, the very large number of such forces crushes together the points in the center of the map, which prevents gaps from forming between the natural clusters. Note that the crowding problem is not specific to SNE, but that it also occurs in other local techniques for multidimensional scaling such as Sammon mapping.

考虑一组数据点，它们位于一个二维曲面流形上，该流形在小尺度上近似线性，并嵌入在一个更高维的空间中。可以在二维映射中较好地模拟数据点之间的小成对距离，这通常在诸如“瑞士卷”数据集的示例中展示。现在假设该流形具有十个内在维度${}^{5}$，并嵌入在一个维度更高的空间中。二维映射无法忠实地模拟十维流形上点之间距离的原因有几个。例如，在十维空间中，可以存在11个相互等距的数据点，而在二维映射中无法忠实地表示这一点。相关的问题是两空间中成对距离的分布差异很大。以数据点i为中心的球体体积随${\mathrm{r}}^{\mathrm{m}}$变化，其中$\mathrm{r}$是半径，$\mathrm{m}$是球体的维度。因此，如果数据点在十维流形上i周围区域近似均匀分布，而我们试图在二维映射中模拟i到其他数据点的距离，就会出现以下“拥挤问题”:二维映射中可用于容纳中等距离数据点的面积远远不够，相较于用于容纳近距离数据点的面积。因此，如果我们想在映射中准确模拟小距离，大多数与数据点$\mathrm{i}$距离适中的点必须被放置得过远。在SNE中，连接数据点i与这些过远映射点的弹簧将施加非常小的吸引力。尽管这些吸引力很小，但大量此类力将中心区域的点挤压在一起，阻止自然簇之间形成间隙。注意，拥挤问题并非SNE特有，也存在于其他局部多维尺度技术中，如Sammon映射。

---

5. This is approximately correct for the images of handwritten digits we use in our experiments in Section 4.

5. 这对于我们在第4节实验中使用的手写数字图像大致适用。

---

An attempt to address the crowding problem by adding a slight repulsion to all springs was presented by Cook et al. (2007). The slight repulsion is created by introducing a uniform background model with a small mixing proportion, $\rho$ . So however far apart two map points are, ${q}_{ij}$ can never fall below $\frac{2\rho }{\mathrm{n}\left( {\mathrm{n} - 1}\right) }$ (because the uniform background distribution is over $\mathrm{n}\left( {\mathrm{n} - 1}\right) /2$ pairs). As a result, for datapoints that are far apart in the high-dimensional space, ${q}_{ij}$ will always be larger than ${p}_{ij}$ , leading to a slight repulsion. This technique is called UNI-SNE and although it usually outperforms standard SNE, the optimization of the UNI-SNE cost function is tedious. The best optimization method known is to start by setting the background mixing proportion to zero (i.e., by performing standard SNE). Once the SNE cost function has been optimized using simulated annealing, the background mixing proportion can be increased to allow some gaps to form between natural clusters as shown by Cook et al. (2007). Optimizing the UNI-SNE cost function directly does not work because two map points that are far apart will get almost all of their ${\mathrm{q}}_{\mathrm{i}\mathrm{j}}$ from the uniform background. So even if their ${p}_{ij}$ is large, there will be no attractive force between them, because a small change in their separation will have a vanishingly small proportional effect on ${\mathrm{q}}_{\mathrm{{ij}}}$ . This means that if two parts of a cluster get separated early on in the optimization, there is no force to pull them back together.

Cook等人(2007)提出了一种通过对所有弹簧施加轻微排斥力来解决拥挤问题的方法。该轻微排斥力是通过引入一个具有小混合比例的均匀背景模型$\rho$来实现的。因此，无论两个映射点相距多远，${q}_{ij}$都不会低于$\frac{2\rho }{\mathrm{n}\left( {\mathrm{n} - 1}\right) }$(因为均匀背景分布覆盖了$\mathrm{n}\left( {\mathrm{n} - 1}\right) /2$对)。结果，对于在高维空间中相距较远的数据点，${q}_{ij}$总是大于${p}_{ij}$，从而产生轻微的排斥力。这种技术称为UNI-SNE，尽管它通常优于标准SNE，但UNI-SNE代价函数的优化过程较为繁琐。已知的最佳优化方法是先将背景混合比例设为零(即执行标准SNE)。一旦通过模拟退火优化了SNE代价函数，就可以增加背景混合比例，以允许自然簇之间形成一些间隙，正如Cook等人(2007)所示。直接优化UNI-SNE代价函数不可行，因为相距较远的两个映射点几乎所有的${\mathrm{q}}_{\mathrm{i}\mathrm{j}}$都来自均匀背景。因此，即使它们的${p}_{ij}$很大，它们之间也不会有吸引力，因为它们间距的微小变化对${\mathrm{q}}_{\mathrm{{ij}}}$的比例影响几乎为零。这意味着如果簇的两个部分在优化早期被分开，就没有力将它们拉回一起。

### 3.3 Mismatched Tails can Compensate for Mismatched Dimensionalities

### 3.3 不匹配的尾部可以补偿不匹配的维度

Since symmetric SNE is actually matching the joint probabilities of pairs of datapoints in the high-dimensional and the low-dimensional spaces rather than their distances, we have a natural way of alleviating the crowding problem that works as follows. In the high-dimensional space, we convert distances into probabilities using a Gaussian distribution. In the low-dimensional map, we can use a probability distribution that has much heavier tails than a Gaussian to convert distances into probabilities. This allows a moderate distance in the high-dimensional space to be faithfully modeled by a much larger distance in the map and, as a result, it eliminates the unwanted attractive forces between map points that represent moderately dissimilar datapoints.

由于对称SNE实际上是在匹配高维和低维空间中数据点对的联合概率，而非它们的距离，我们有一种自然的方式来缓解拥挤问题，具体如下。在高维空间中，我们使用高斯分布将距离转换为概率。在低维映射中，我们可以使用比高斯分布尾部更重的概率分布将距离转换为概率。这允许高维空间中的中等距离被映射为映射中更大的距离，从而消除了表示中度不相似数据点的映射点之间不必要的吸引力。

In t-SNE, we employ a Student t-distribution with one degree of freedom (which is the same as a Cauchy distribution) as the heavy-tailed distribution in the low-dimensional map. Using this distribution, the joint probabilities ${\mathrm{q}}_{\mathrm{i}\mathrm{j}}$ are defined as

在t-SNE中，我们采用自由度为1的Student t分布(即柯西分布)作为低维映射中的重尾分布。使用该分布，联合概率${\mathrm{q}}_{\mathrm{i}\mathrm{j}}$定义为

$$
{\mathrm{q}}_{\mathrm{i}\mathrm{j}} = \frac{{\left( 1 + {\begin{Vmatrix}{\mathrm{y}}_{\mathrm{i}} - {\mathrm{y}}_{\mathrm{j}}\end{Vmatrix}}^{2}\right) }^{-1}}{\mathop{\sum }\limits_{{\mathrm{k} \neq  1}}{\left( 1 + {\begin{Vmatrix}{\mathrm{y}}_{\mathrm{k}} - {\mathrm{y}}_{\mathrm{l}}\end{Vmatrix}}^{2}\right) }^{-1}}. \tag{4}
$$

We use a Student t-distribution with a single degree of freedom, because it has the particularly nice property that ${\left( 1 + {\begin{Vmatrix}{\mathrm{y}}_{\mathrm{i}} - {\mathrm{y}}_{\mathrm{j}}\end{Vmatrix}}^{2}\right) }^{-1}$ approaches an inverse square law for large pairwise distances $\begin{Vmatrix}{{\mathrm{y}}_{\mathrm{i}} - {\mathrm{y}}_{\mathrm{j}}}\end{Vmatrix}$ in the low-dimensional map. This makes the map’s representation of joint probabilities (almost) invariant to changes in the scale of the map for map points that are far apart. It also means that large clusters of points that are far apart interact in just the same way as individual points, so the optimization operates in the same way at all but the finest scales. A theoretical justification for our selection of the Student t-distribution is that it is closely related to the Gaussian distribution, as the Student t-distribution is an infinite mixture of Gaussians. A computationally convenient property is that it is much faster to evaluate the density of a point under a Student t-distribution than under a Gaussian because it does not involve an exponential, even though the Student t-distribution is equivalent to an infinite mixture of Gaussians with different variances.

我们使用自由度为1的Student t分布，因为它具有一个特别好的性质，即对于低维映射中较大的点对距离$\begin{Vmatrix}{{\mathrm{y}}_{\mathrm{i}} - {\mathrm{y}}_{\mathrm{j}}}\end{Vmatrix}$，${\left( 1 + {\begin{Vmatrix}{\mathrm{y}}_{\mathrm{i}} - {\mathrm{y}}_{\mathrm{j}}\end{Vmatrix}}^{2}\right) }^{-1}$趋近于反平方定律。这使得映射对联合概率的表示对于相距较远的映射点的尺度变化(几乎)保持不变。这也意味着相距较远的大簇点与单个点的相互作用方式相同，因此优化过程在除最细微尺度外的所有尺度上均以相同方式进行。选择Student t分布的理论依据是它与高斯分布密切相关，因为Student t分布是高斯分布的无限混合。一个计算上的便利性质是，计算点在Student t分布下的密度比在高斯分布下更快，因为它不涉及指数运算，尽管Student t分布等价于具有不同方差的高斯分布的无限混合。

![bo_d1c3pf77aajc7389qemg_7_276_264_1268_391_0.jpg](images/bo_d1c3pf77aajc7389qemg_7_276_264_1268_391_0.jpg)

Figure 1: Gradients of three types of SNE as a function of the pairwise Euclidean distance between two points in the high-dimensional and the pairwise distance between the points in the low-dimensional data representation.

图1:三种类型SNE的梯度，作为高维空间中两点之间欧氏距离和低维数据表示中两点之间距离的函数。

The gradient of the Kullback-Leibler divergence between $\mathrm{P}$ and the Student-t based joint probability distribution Q (computed using Equation 4) is derived in Appendix A, and is given by

Kullback-Leibler散度在$\mathrm{P}$与基于Student-t的联合概率分布Q(使用公式4计算)之间的梯度在附录A中推导，表达式为

$$
\frac{\delta C}{\delta {y}_{i}} = 4\mathop{\sum }\limits_{j}\left( {{p}_{ij} - {q}_{ij}}\right) \left( {{y}_{i} - {y}_{j}}\right) {\left( 1 + {\begin{Vmatrix}{y}_{i} - {y}_{j}\end{Vmatrix}}^{2}\right) }^{-1}. \tag{5}
$$

In Figure 1(a) to 1(c), we show the gradients between two low-dimensional datapoints ${y}_{i}$ and ${y}_{j}$ as a function of their pairwise Euclidean distances in the high-dimensional and the low-dimensional space (i.e., as a function of $\begin{Vmatrix}{{\mathrm{x}}_{\mathrm{i}} - {\mathrm{x}}_{\mathrm{j}}}\end{Vmatrix}$ and $\begin{Vmatrix}{{\mathrm{y}}_{\mathrm{i}} - {\mathrm{y}}_{\mathrm{j}}}\end{Vmatrix}$ ) for the symmetric versions of SNE, UNI-SNE, and t-SNE. In the figures, positive values of the gradient represent an attraction between the low-dimensional datapoints ${y}_{i}$ and ${y}_{j}$ , whereas negative values represent a repulsion between the two datapoints. From the figures, we observe two main advantages of the t-SNE gradient over the gradients of SNE and UNI-SNE.

在图1(a)到1(c)中，我们展示了两个低维数据点${y}_{i}$和${y}_{j}$之间的梯度，作为它们在高维和低维空间中成对欧氏距离(即作为$\begin{Vmatrix}{{\mathrm{x}}_{\mathrm{i}} - {\mathrm{x}}_{\mathrm{j}}}\end{Vmatrix}$和$\begin{Vmatrix}{{\mathrm{y}}_{\mathrm{i}} - {\mathrm{y}}_{\mathrm{j}}}\end{Vmatrix}$的函数)的函数，针对对称版本的SNE、UNI-SNE和t-SNE。在图中，梯度的正值表示低维数据点${y}_{i}$和${y}_{j}$之间的吸引，而负值表示两数据点之间的排斥。从图中我们观察到t-SNE梯度相较于SNE和UNI-SNE梯度的两个主要优势。

First, the t-SNE gradient strongly repels dissimilar datapoints that are modeled by a small pairwise distance in the low-dimensional representation. SNE has such a repulsion as well, but its effect is minimal compared to the strong attractions elsewhere in the gradient (the largest attraction in our graphical representation of the gradient is approximately 19 , whereas the largest repulsion is approximately 1). In UNI-SNE, the amount of repulsion between dissimilar datapoints is slightly larger, however, this repulsion is only strong when the pairwise distance between the points in the low-dimensional representation is already large (which is often not the case, since the low-dimensional representation is initialized by sampling from a Gaussian with a very small variance that is centered around the origin).

首先，t-SNE梯度强烈排斥在低维表示中被建模为较小成对距离的不相似数据点。SNE也存在这种排斥，但其效果相较于梯度中其他位置的强吸引力非常微弱(在我们梯度的图示中，最大吸引力约为19，而最大排斥力约为1)。在UNI-SNE中，不相似数据点之间的排斥稍大，但这种排斥仅在低维表示中两点的成对距离已经较大时才强烈(而这通常不常见，因为低维表示是通过从以原点为中心、方差很小的高斯分布采样初始化的)。

Second, although t-SNE introduces strong repulsions between dissimilar datapoints that are modeled by small pairwise distances, these repulsions do not go to infinity. In this respect, t-SNE differs from UNI-SNE, in which the strength of the repulsion between very dissimilar datapoints is proportional to their pairwise distance in the low-dimensional map, which may cause dissimilar datapoints to move much too far away from each other.

其次，尽管t-SNE在低维表示中对成对距离较小的不相似数据点引入了强烈的排斥，这些排斥不会趋于无穷大。在这方面，t-SNE不同于UNI-SNE，后者中非常不相似数据点之间的排斥强度与它们在低维映射中的成对距离成正比，这可能导致不相似数据点彼此远离得过远。

Algorithm 1: Simple version of t-Distributed Stochastic Neighbor Embedding.

算法1:t-分布随机邻居嵌入(t-Distributed Stochastic Neighbor Embedding)的简化版本。

---

Data: data set $\mathcal{X} = \left\{  {{\mathrm{x}}_{1},{\mathrm{x}}_{2},\ldots ,{\mathrm{x}}_{\mathrm{n}}}\right\}$ ,

数据:数据集$\mathcal{X} = \left\{  {{\mathrm{x}}_{1},{\mathrm{x}}_{2},\ldots ,{\mathrm{x}}_{\mathrm{n}}}\right\}$，

cost function parameters: perplexity Perp,

代价函数参数:困惑度Perp，

optimization parameters: number of iterations $\mathrm{T}$ , learning rate $\eta$ , momentum $\alpha \left( \mathrm{t}\right)$ .

优化参数:迭代次数$\mathrm{T}$，学习率$\eta$，动量$\alpha \left( \mathrm{t}\right)$。

Result: low-dimensional data representation ${\mathcal{Y}}^{\left( \mathrm{T}\right) } = \left\{  {{\mathrm{y}}_{1},{\mathrm{y}}_{2},\ldots ,{\mathrm{y}}_{\mathrm{n}}}\right\}$ .

结果:低维数据表示${\mathcal{Y}}^{\left( \mathrm{T}\right) } = \left\{  {{\mathrm{y}}_{1},{\mathrm{y}}_{2},\ldots ,{\mathrm{y}}_{\mathrm{n}}}\right\}$。

begin

开始

	compute pairwise affinities ${\mathrm{p}}_{\mathrm{j} \mid  \mathrm{i}}$ with perplexity Perp (using Equation 1)

	使用困惑度Perp计算成对亲和度${\mathrm{p}}_{\mathrm{j} \mid  \mathrm{i}}$(使用公式1)

	set ${p}_{ij} = \frac{{p}_{j \mid  i} + {p}_{i \mid  j}}{2n}$

	设置${p}_{ij} = \frac{{p}_{j \mid  i} + {p}_{i \mid  j}}{2n}$

	sample initial solution ${\mathcal{Y}}^{\left( 0\right) } = \left\{  {{\mathrm{y}}_{1},{\mathrm{y}}_{2},\ldots ,{\mathrm{y}}_{\mathrm{n}}}\right\}$ from $\mathcal{N}\left( {0,{10}^{-4}\mathrm{I}}\right)$

	从$\mathcal{N}\left( {0,{10}^{-4}\mathrm{I}}\right)$采样初始解${\mathcal{Y}}^{\left( 0\right) } = \left\{  {{\mathrm{y}}_{1},{\mathrm{y}}_{2},\ldots ,{\mathrm{y}}_{\mathrm{n}}}\right\}$

	for $\mathrm{t} = 1$ to $\mathrm{T}$ do

	从$\mathrm{t} = 1$到$\mathrm{T}$循环

		compute low-dimensional affinities ${\mathrm{q}}_{\mathrm{i}\mathrm{j}}$ (using Equation 4)

		计算低维亲和度${\mathrm{q}}_{\mathrm{i}\mathrm{j}}$(使用公式4)

		compute gradient $\frac{\delta \mathrm{C}}{\delta \mathcal{Y}}$ (using Equation 5)

		计算梯度$\frac{\delta \mathrm{C}}{\delta \mathcal{Y}}$(使用公式5)

		set ${\mathcal{Y}}^{\left( \mathrm{t}\right) } = {\mathcal{Y}}^{\left( \mathrm{t} - 1\right) } + \eta \frac{\delta \mathrm{C}}{\delta \mathcal{Y}} + \alpha \left( \mathrm{t}\right) \left( {{\mathcal{Y}}^{\left( \mathrm{t} - 1\right) } - {\mathcal{Y}}^{\left( \mathrm{t} - 2\right) }}\right)$

		设置 ${\mathcal{Y}}^{\left( \mathrm{t}\right) } = {\mathcal{Y}}^{\left( \mathrm{t} - 1\right) } + \eta \frac{\delta \mathrm{C}}{\delta \mathcal{Y}} + \alpha \left( \mathrm{t}\right) \left( {{\mathcal{Y}}^{\left( \mathrm{t} - 1\right) } - {\mathcal{Y}}^{\left( \mathrm{t} - 2\right) }}\right)$

	end

	结束

end

结束

---

Taken together, t-SNE puts emphasis on (1) modeling dissimilar datapoints by means of large pairwise distances, and (2) modeling similar datapoints by means of small pairwise distances. Moreover, as a result of these characteristics of the t-SNE cost function (and as a result of the approximate scale invariance of the Student t-distribution), the optimization of the t-SNE cost function is much easier than the optimization of the cost functions of SNE and UNI-SNE. Specifically, t-SNE introduces long-range forces in the low-dimensional map that can pull back together two (clusters of) similar points that get separated early on in the optimization. SNE and UNI-SNE do not have such long-range forces, as a result of which SNE and UNI-SNE need to use simulated annealing to obtain reasonable solutions. Instead, the long-range forces in t-SNE facilitate the identification of good local optima without resorting to simulated annealing.

综合来看，t-SNE强调(1)通过较大的成对距离来建模不相似的数据点，(2)通过较小的成对距离来建模相似的数据点。此外，由于t-SNE代价函数的这些特性(以及学生t分布(Student t-distribution)的近似尺度不变性)，t-SNE代价函数的优化比SNE和UNI-SNE的代价函数优化要容易得多。具体来说，t-SNE在低维映射中引入了长程力，可以将优化早期被分开的两个(簇)相似点拉回到一起。SNE和UNI-SNE没有这种长程力，因此需要使用模拟退火来获得合理的解。相反，t-SNE中的长程力促进了良好局部最优解的识别，无需借助模拟退火。

### 3.4 Optimization Methods for t-SNE

### 3.4 t-SNE的优化方法

We start by presenting a relatively simple, gradient descent procedure for optimizing the t-SNE cost function. This simple procedure uses a momentum term to reduce the number of iterations required and it works best if the momentum term is small until the map points have become moderately well organized. Pseudocode for this simple algorithm is presented in Algorithm 1. The simple algorithm can be sped up using the adaptive learning rate scheme that is described by Jacobs (1988), which gradually increases the learning rate in directions in which the gradient is stable.

我们首先介绍一种相对简单的梯度下降方法来优化t-SNE代价函数。该简单方法使用动量项以减少所需迭代次数，并且当动量项较小时效果最佳，直到映射点变得较为有序。该简单算法的伪代码见算法1。该简单算法可以通过Jacobs (1988)描述的自适应学习率方案加速，该方案在梯度稳定的方向上逐渐增加学习率。

Although the simple algorithm produces visualizations that are often much better than those produced by other non-parametric dimensionality reduction techniques, the results can be improved further by using either of two tricks. The first trick, which we call "early compression", is to force the map points to stay close together at the start of the optimization. When the distances between map points are small, it is easy for clusters to move through one another so it is much easier to explore the space of possible global organizations of the data. Early compression is implemented by adding an additional L2-penalty to the cost function that is proportional to the sum of squared distances of the map points from the origin. The magnitude of this penalty term and the iteration at which it is removed are set by hand, but the behavior is fairly robust across variations in these two additional optimization parameters.

尽管该简单算法产生的可视化结果通常比其他非参数降维技术好得多，但通过两种技巧中的任意一种，结果还可以进一步提升。第一种技巧称为“早期压缩”，即在优化开始时强制映射点保持靠近。当映射点之间距离较小时，簇可以轻松穿过彼此，因此更容易探索数据可能的全局组织空间。早期压缩通过在代价函数中添加一个额外的L2惩罚项实现，该惩罚项与映射点到原点的平方距离之和成正比。该惩罚项的大小及其移除的迭代次数由人工设定，但该行为在这两个额外优化参数的变化下相当稳健。

A less obvious way to improve the optimization, which we call "early exaggeration", is to multiply all of the ${p}_{ij}$ ’s by, for example,4, in the initial stages of the optimization. This means that almost all of the ${\mathrm{q}}_{\mathrm{{ij}}}$ ’s, which still add up to 1, are much too small to model their corresponding ${\mathrm{p}}_{\mathrm{{ij}}}$ ’s. As a result, the optimization is encouraged to focus on modeling the large ${p}_{ij}$ ’s by fairly large ${q}_{ij}$ ’s. The effect is that the natural clusters in the data tend to form tight widely separated clusters in the map. This creates a lot of relatively empty space in the map, which makes it much easier for the clusters to move around relative to one another in order to find a good global organization.

另一种不太明显的优化改进方法称为“早期夸大”，即在优化初期将所有${p}_{ij}$乘以例如4。这意味着几乎所有的${\mathrm{q}}_{\mathrm{{ij}}}$，虽然仍加和为1，却远小于其对应的${\mathrm{p}}_{\mathrm{{ij}}}$。因此，优化被鼓励通过相当大的${q}_{ij}$来重点建模较大的${p}_{ij}$。其效果是数据中的自然簇倾向于在映射中形成紧密且相互分离的簇。这在映射中创造了大量相对空旷的空间，使得簇之间更容易相互移动以找到良好的全局组织。

In all the visualizations presented in this paper and in the supporting material, we used exactly the same optimization procedure. We used the early exaggeration method with an exaggeration of 4 for the first 50 iterations (note that early exaggeration is not included in the pseudocode in Algorithm 1). The number of gradient descent iterations $\mathrm{T}$ was set 1000 , and the momentum term was set to ${\alpha }^{\left( \mathrm{t}\right) } = {0.5}$ for $\mathrm{t} < {250}$ and ${\alpha }^{\left( \mathrm{t}\right) } = {0.8}$ for $\mathrm{t} \geq  {250}$ . The learning rate $\eta$ is initially set to 100 and it is updated after every iteration by means of the adaptive learning rate scheme described by Jacobs (1988). A Matlab implementation of the resulting algorithm is available at http://ticc.uvt.nl/ l / lvdrmaaten/tsne.

在本文及其补充材料中展示的所有可视化中，我们使用了完全相同的优化过程。我们采用了早期夸大法(early exaggeration)，在前50次迭代中夸大系数为4(注意，算法1的伪代码中未包含早期夸大步骤)。梯度下降迭代次数$\mathrm{T}$设为1000，动量项分别为${\alpha }^{\left( \mathrm{t}\right) } = {0.5}$用于$\mathrm{t} < {250}$，以及${\alpha }^{\left( \mathrm{t}\right) } = {0.8}$用于$\mathrm{t} \geq  {250}$。学习率$\eta$初始设为100，并在每次迭代后通过Jacobs (1988)描述的自适应学习率方案进行更新。该算法的Matlab实现可在http://ticc.uvt.nl/l/lvdrmaaten/tsne获得。

## 4. Experiments

## 4. 实验

To evaluate t-SNE, we present experiments in which t-SNE is compared to seven other non-parametric techniques for dimensionality reduction. Because of space limitations, in the paper, we only compare t-SNE with: (1) Sammon mapping, (2) Isomap, and (3) LLE. In the supporting material, we also compare t-SNE with: (4) CCA, (5) SNE, (6) MVU, and (7) Laplacian Eigenmaps. We performed experiments on five data sets that represent a variety of application domains. Again because of space limitations, we restrict ourselves to three data sets in the paper. The results of our experiments on the remaining two data sets are presented in the supplemental material.

为了评估t-SNE，我们进行了将t-SNE与其他七种非参数降维技术比较的实验。由于篇幅限制，本文仅比较了t-SNE与:(1) Sammon映射，(2) Isomap，和(3) LLE。在补充材料中，我们还比较了t-SNE与:(4) CCA，(5) SNE，(6) MVU，和(7) 拉普拉斯特征映射(Laplacian Eigenmaps)。我们在五个代表不同应用领域的数据集上进行了实验。由于篇幅限制，本文仅展示了三个数据集的结果，其余两个数据集的实验结果见补充材料。

In Section 4.1, the data sets that we employed in our experiments are introduced. The setup of the experiments is presented in Section 4.2. In Section 4.3, we present the results of our experiments.

第4.1节介绍了我们实验中使用的数据集。第4.2节介绍了实验设置。第4.3节展示了实验结果。

### 4.1 Data Sets

### 4.1 数据集

The five data sets we employed in our experiments are: (1) the MNIST data set, (2) the Olivetti faces data set, (3) the COIL-20 data set, (4) the word-features data set, and (5) the Netflix data set. We only present results on the first three data sets in this section. The results on the remaining two data sets are presented in the supporting material. The first three data sets are introduced below.

我们实验中使用的五个数据集是:(1) MNIST数据集，(2) Olivetti人脸数据集，(3) COIL-20数据集，(4) 词特征数据集，和(5) Netflix数据集。本节仅展示前三个数据集的结果，其余两个数据集的结果见补充材料。以下介绍前三个数据集。

The MNIST data set ${}^{6}$ contains 60,000 grayscale images of handwritten digits. For our experiments, we randomly selected 6,000 of the images for computational reasons. The digit images have ${28} \times  {28} = {784}$ pixels (i.e., dimensions). The Olivetti faces data set ${}^{7}$ consists of images of 40 individuals with small variations in viewpoint, large variations in expression, and occasional addition of glasses. The data set consists of 400 images ( 10 per individual) of size ${92} \times  {112} = {10},{304}$ pixels, and is labeled according to identity. The COIL-20 data set (Nene et al., 1996) contains images of 20 different objects viewed from 72 equally spaced orientations, yielding a total of 1,440 images. The images contain ${32} \times  {32} = 1,{024}$ pixels.

MNIST数据集${}^{6}$包含60,000张手写数字的灰度图像。出于计算考虑，我们随机选取了6,000张图像进行实验。数字图像具有${28} \times  {28} = {784}$像素(即维度)。Olivetti人脸数据集${}^{7}$包含40位个体的图像，视角变化较小，表情变化较大，偶尔佩戴眼镜。该数据集包含400张图像(每人10张)，图像尺寸为${92} \times  {112} = {10},{304}$像素，并按身份标注。COIL-20数据集(Nene等，1996)包含20种不同物体的图像，每个物体从72个等间隔视角拍摄，共计1,440张图像。图像尺寸为${32} \times  {32} = 1,{024}$像素。

---

6. The MNIST data set is publicly available from http://yann.lecun.com/exdb/mnist/index.html.

6. MNIST数据集可从http://yann.lecun.com/exdb/mnist/index.html公开获取。

7. The Olivetti faces data set is publicly available from http://mambo.ucsc.edu/psl/olivetti.html.

7. Olivetti人脸数据集可从http://mambo.ucsc.edu/psl/olivetti.html公开获取。

---

### 4.2 Experimental Setup

### 4.2 实验设置

In all of our experiments, we start by using PCA to reduce the dimensionality of the data to 30 . This speeds up the computation of pairwise distances between the datapoints and suppresses some noise without severely distorting the interpoint distances. We then use each of the dimensionality reduction techniques to convert the 30-dimensional representation to a two-dimensional map and we show the resulting map as a scatterplot. For all of the data sets, there is information about the class of each datapoint, but the class information is only used to select a color and/or symbol for the map points. The class information is not used to determine the spatial coordinates of the map points. The coloring thus provides a way of evaluating how well the map preserves the similarities within each class.

在所有实验中，我们首先使用主成分分析(PCA)将数据维度降至30维。这加快了数据点间成对距离的计算，并抑制了一些噪声，同时不严重扭曲点间距离。然后，我们使用各降维技术将30维表示转换为二维映射，并以散点图形式展示结果。所有数据集中均包含每个数据点的类别信息，但类别信息仅用于选择映射点的颜色和/或符号，不用于确定映射点的空间坐标。颜色编码因此提供了一种评估映射在保持各类别内部相似性方面效果的方法。

The cost function parameter settings we employed in our experiments are listed in Table 1. In the table, Perp represents the perplexity of the conditional probability distribution induced by a Gaussian kernel and $\mathrm{k}$ represents the number of nearest neighbors employed in a neighborhood graph. In the experiments with Isomap and LLE, we only visualize datapoints that correspond to vertices in the largest connected component of the neighborhood graph. ${}^{8}$ For the Sammon mapping optimization, we performed Newton's method for 500 iterations.

我们在实验中采用的代价函数参数设置列于表1中。表中，Perp表示由高斯核引起的条件概率分布的困惑度(perplexity)，$\mathrm{k}$表示邻域图中使用的最近邻数量。在Isomap和LLE的实验中，我们仅可视化对应于邻域图最大连通分量中顶点的数据点。${}^{8}$对于Sammon映射优化，我们进行了500次牛顿法迭代。

<table><tr><td>Technique</td><td>Cost function parameters</td></tr><tr><td>t-SNE</td><td>Perp $= {40}$</td></tr><tr><td>Sammon mapping</td><td>none</td></tr><tr><td>Isomap</td><td>$\mathrm{k} = {12}$</td></tr><tr><td>LLE</td><td>$\mathrm{k} = {12}$</td></tr></table>

<table><tbody><tr><td>技术</td><td>代价函数参数</td></tr><tr><td>t-SNE(t-分布随机邻域嵌入)</td><td>困惑度 $= {40}$</td></tr><tr><td>Sammon映射</td><td>无</td></tr><tr><td>Isomap(等距映射)</td><td>$\mathrm{k} = {12}$</td></tr><tr><td>LLE(局部线性嵌入)</td><td>$\mathrm{k} = {12}$</td></tr></tbody></table>

Table 1: Cost function parameter settings for the experiments.

表1:实验中代价函数参数设置。

### 4.3 Results

### 4.3 结果

In Figures 2 and 3, we show the results of our experiments with t-SNE, Sammon mapping, Isomap, and LLE on the MNIST data set. The results reveal the strong performance of t-SNE compared to the other techniques. In particular, Sammon mapping constructs a "ball" in which only three classes (representing the digits 0,1 , and 7) are somewhat separated from the other classes. Isomap and LLE produce solutions in which there are large overlaps between the digit classes. In contrast, t-SNE constructs a map in which the separation between the digit classes is almost perfect. Moreover, detailed inspection of the t-SNE map reveals that much of the local structure of the data (such as the orientation of the ones) is captured as well. This is illustrated in more detail in Section 5 (see Figure 7). The map produced by t-SNE contains some points that are clustered with the wrong class, but most of these points correspond to distorted digits many of which are difficult to identify. Figure 4 shows the results of applying t-SNE, Sammon mapping, Isomap, and LLE to the Olivetti faces data set. Again, Isomap and LLE produce solutions that provide little insight into the class structure of the data. The map constructed by Sammon mapping is significantly better, since it models many of the members of each class fairly close together, but none of the classes are clearly separated in the Sammon map. In contrast, t-SNE does a much better job of revealing the natural classes in the data. Some individuals have their ten images split into two clusters, usually because a subset of the images have the head facing in a significantly different direction, or because they have a very different expression or glasses. For these individuals, it is not clear that their ten images form a natural class when using Euclidean distance in pixel space.

在图2和图3中，我们展示了在MNIST数据集上使用t-SNE、Sammon映射、Isomap和LLE的实验结果。结果显示t-SNE的表现明显优于其他技术。特别是，Sammon映射构建了一个“球体”，其中只有三个类别(代表数字0、1和7)与其他类别有所分离。Isomap和LLE产生的结果中，数字类别之间存在较大重叠。相比之下，t-SNE构建的映射几乎完美地分离了数字类别。此外，对t-SNE映射的细致观察表明，数据的许多局部结构(如数字1的方向)也被捕捉到了。详见第5节(参见图7)。t-SNE生成的映射中有些点被错误地聚类到其他类别，但这些点大多对应于形变的数字，其中许多难以辨认。图4展示了将t-SNE、Sammon映射、Isomap和LLE应用于Olivetti人脸数据集的结果。同样，Isomap和LLE的结果对数据的类别结构几乎没有提供有用的见解。Sammon映射构建的映射明显更好，因为它将每个类别的许多成员较为紧密地聚集在一起，但在Sammon映射中没有任何类别被清晰分离。相比之下，t-SNE在揭示数据中的自然类别方面表现更佳。有些个体的十张图像被分成了两个簇，通常是因为部分图像中头部朝向明显不同，或表情、眼镜有较大差异。对于这些个体，使用像素空间中的欧氏距离时，其十张图像是否构成自然类别尚不明确。

---

8. Isomap and LLE require data that gives rise to a neighborhood graph that is connected.

8. Isomap和LLE要求数据生成的邻域图是连通的。

---

![bo_d1c3pf77aajc7389qemg_11_417_249_983_1766_0.jpg](images/bo_d1c3pf77aajc7389qemg_11_417_249_983_1766_0.jpg)

Figure 2: Visualizations of 6,000 handwritten digits from the MNIST data set.

图2:MNIST数据集中6000个手写数字的可视化。

![bo_d1c3pf77aajc7389qemg_12_410_266_994_1746_0.jpg](images/bo_d1c3pf77aajc7389qemg_12_410_266_994_1746_0.jpg)

Figure 3: Visualizations of 6,000 handwritten digits from the MNIST data set.

图3:MNIST数据集中6000个手写数字的可视化。

![bo_d1c3pf77aajc7389qemg_13_267_259_1280_1157_0.jpg](images/bo_d1c3pf77aajc7389qemg_13_267_259_1280_1157_0.jpg)

Figure 4: Visualizations of the Olivetti faces data set.

图4:Olivetti人脸数据集的可视化。

Figure 5 shows the results of applying t-SNE, Sammon mapping, Isomap, and LLE to the COIL- 20 data set. For many of the 20 objects, t-SNE accurately represents the one-dimensional manifold of viewpoints as a closed loop. For objects which look similar from the front and the back, t-SNE distorts the loop so that the images of front and back are mapped to nearby points. For the four types of toy car in the COIL-20 data set (the four aligned "sausages" in the bottom-left of the t-SNE map), the four rotation manifolds are aligned by the orientation of the cars to capture the high similarity between different cars at the same orientation. This prevents t-SNE from keeping the four manifolds clearly separate. Figure 5 also reveals that the other three techniques are not nearly as good at cleanly separating the manifolds that correspond to very different objects. In addition, Isomap and LLE only visualize a small number of classes from the COIL-20 data set, because the data set comprises a large number of widely separated submanifolds that give rise to small connected components in the neighborhood graph.

图5展示了将t-SNE、Sammon映射、Isomap和LLE应用于COIL-20数据集的结果。对于20个物体中的许多，t-SNE准确地将视角的一维流形表示为闭环。对于正面和背面外观相似的物体，t-SNE会扭曲该闭环，使正面和背面的图像映射到相近点。对于COIL-20数据集中的四种玩具车(t-SNE映射左下角的四个排列成行的“香肠”)，四个旋转流形根据汽车的朝向对齐，以捕捉不同汽车在相同朝向下的高度相似性。这导致t-SNE无法将这四个流形清晰分开。图5还显示，其他三种技术在清晰分离对应非常不同物体的流形方面远不如t-SNE。此外，Isomap和LLE仅可视化了COIL-20数据集中的少数类别，因为该数据集包含大量广泛分离的子流形，导致邻域图中存在小的连通分量。

![bo_d1c3pf77aajc7389qemg_14_271_254_1276_1161_0.jpg](images/bo_d1c3pf77aajc7389qemg_14_271_254_1276_1161_0.jpg)

Figure 5: Visualizations of the COIL-20 data set.

图5:COIL-20数据集的可视化。

## 5. Applying t-SNE to Large Data Sets

## 5. 将t-SNE应用于大规模数据集

Like many other visualization techniques, t-SNE has a computational and memory complexity that is quadratic in the number of datapoints. This makes it infeasible to apply the standard version of t-SNE to data sets that contain many more than, say, 10,000 points. Obviously, it is possible to pick a random subset of the datapoints and display them using t-SNE, but such an approach fails to make use of the information that the undisplayed datapoints provide about the underlying manifolds. Suppose, for example, that $\mathrm{A},\mathrm{B}$ , and $\mathrm{C}$ are all equidistant in the high-dimensional space. If there are many undisplayed datapoints between $\mathrm{A}$ and $\mathrm{B}$ and none between $\mathrm{A}$ and $\mathrm{C}$ , it is much more likely that $A$ and $B$ are part of the same cluster than $A$ and $C$ . This is illustrated in Figure 6. In this section, we show how t-SNE can be modified to display a random subset of the datapoints (so-called landmark points) in a way that uses information from the entire (possibly very large) data set.

像许多其他可视化技术一样，t-SNE的计算和内存复杂度与数据点数量的平方成正比。这使得将标准版本的t-SNE应用于包含远多于1万个点的数据集变得不可行。显然，可以随机选择数据点的子集并使用t-SNE进行展示，但这种方法未能利用未显示数据点所提供的关于潜在流形的信息。例如，假设$\mathrm{A},\mathrm{B}$和$\mathrm{C}$在高维空间中等距。如果在$\mathrm{A}$和$\mathrm{B}$之间有许多未显示的数据点，而在$\mathrm{A}$和$\mathrm{C}$之间没有，那么$A$和$B$更有可能属于同一簇，而不是$A$和$C$。如图6所示。在本节中，我们展示了如何修改t-SNE，以便以利用整个(可能非常大)数据集信息的方式显示数据点的随机子集(所谓的地标点)。

![bo_d1c3pf77aajc7389qemg_15_605_253_586_510_0.jpg](images/bo_d1c3pf77aajc7389qemg_15_605_253_586_510_0.jpg)

Figure 6: An illustration of the advantage of the random walk version of t-SNE over a standard landmark approach. The shaded points $\mathrm{A},\mathrm{B}$ , and $\mathrm{C}$ are three (almost) equidistant landmark points, whereas the non-shaded datapoints are non-landmark points. The arrows represent a directed neighborhood graph where $\mathrm{k} = 3$ . In a standard landmark approach, the pairwise affinity between $\mathrm{A}$ and $\mathrm{B}$ is approximately equal to the pairwise affinity between A and C. In the random walk version of t-SNE, the pairwise affinity between A and $\mathrm{B}$ is much larger than the pairwise affinity between $\mathrm{A}$ and $\mathrm{C}$ , and therefore, it reflects the structure of the data much better.

图6:随机游走版本的t-SNE相较于标准地标方法的优势示意图。阴影点$\mathrm{A},\mathrm{B}$和$\mathrm{C}$是三个(几乎)等距的地标点，而非阴影的数据点是非地标点。箭头表示有向邻域图，其中$\mathrm{k} = 3$。在标准地标方法中，$\mathrm{A}$和$\mathrm{B}$之间的成对亲和度大致等于A和C之间的成对亲和度。在随机游走版本的t-SNE中，A和$\mathrm{B}$之间的成对亲和度远大于$\mathrm{A}$和$\mathrm{C}$之间的成对亲和度，因此，它更好地反映了数据的结构。

We start by choosing a desired number of neighbors and creating a neighborhood graph for all of the datapoints. Although this is computationally intensive, it is only done once. Then, for each of the landmark points, we define a random walk starting at that landmark point and terminating as soon as it lands on another landmark point. During a random walk, the probability of choosing an edge emanating from node ${x}_{i}$ to node ${x}_{j}$ is proportional to ${e}^{-{\begin{Vmatrix}{x}_{i} - {x}_{j}\end{Vmatrix}}^{2}}$ . We define ${p}_{j \mid  i}$ to be the fraction of random walks starting at landmark point ${\mathrm{x}}_{\mathrm{i}}$ that terminate at landmark point ${\mathrm{x}}_{\mathrm{j}}$ . This has some resemblance to the way Isomap measures pairwise distances between points. However, as in diffusion maps (Lafon and Lee, 2006; Nadler et al., 2006), rather than looking for the shortest path through the neighborhood graph, the random walk-based affinity measure integrates over all paths through the neighborhood graph. As a result, the random walk-based affinity measure is much less sensitive to "short-circuits" (Lee and Verleysen, 2005), in which a single noisy datapoint provides a bridge between two regions of dataspace that should be far apart in the map. Similar approaches using random walks have also been successfully applied to, for example, semi-supervised learning (Szummer and Jaakkola, 2001; Zhu et al., 2003) and image segmentation (Grady, 2006).

我们首先选择期望的邻居数量，并为所有数据点创建邻域图。尽管这计算量大，但只需执行一次。然后，对于每个地标点，我们定义一个从该地标点开始并在落到另一个地标点时终止的随机游走。在随机游走过程中，从节点${x}_{i}$到节点${x}_{j}$的边被选择的概率与${e}^{-{\begin{Vmatrix}{x}_{i} - {x}_{j}\end{Vmatrix}}^{2}}$成正比。我们定义${p}_{j \mid  i}$为从地标点${\mathrm{x}}_{\mathrm{i}}$开始并终止于地标点${\mathrm{x}}_{\mathrm{j}}$的随机游走的比例。这与Isomap测量点之间成对距离的方式有些相似。然而，如扩散映射(Lafon和Lee，2006；Nadler等，2006)所示，随机游走基于的亲和度度量不是寻找邻域图中的最短路径，而是对邻域图中所有路径进行积分。因此，随机游走基于的亲和度度量对“短路”(Lee和Verleysen，2005)不那么敏感，即单个噪声数据点在地图中连接本应相距较远的两个数据空间区域。类似的基于随机游走的方法也已成功应用于例如半监督学习(Szummer和Jaakkola，2001；Zhu等，2003)和图像分割(Grady，2006)。

The most obvious way to compute the random walk-based similarities ${\mathrm{p}}_{\mathrm{j} \mid  \mathrm{i}}$ is to explicitly perform the random walks on the neighborhood graph, which works very well in practice, given that one can easily perform one million random walks per second. Alternatively, Grady (2006) presents an analytical solution to compute the pairwise similarities ${p}_{\left| \right| \mathrm{i}}$ that involves solving a sparse linear system. The analytical solution to compute the similarities ${\mathrm{p}}_{\mathrm{j} \mid  \mathrm{i}}$ is sketched in Appendix B. In preliminary experiments, we did not find significant differences between performing the random walks explicitly and the analytical solution. In the experiment we present below, we explicitly performed the random walks because this is computationally less expensive. However, for very large data sets in which the landmark points are very sparse, the analytical solution may be more appropriate.

计算基于随机游走的相似度${\mathrm{p}}_{\mathrm{j} \mid  \mathrm{i}}$最直接的方法是显式地在邻域图上执行随机游走，实践中效果非常好，因为每秒可以轻松执行一百万次随机游走。另一种方法是Grady (2006)提出的解析解，用于计算成对相似度${p}_{\left| \right| \mathrm{i}}$，该方法涉及求解稀疏线性系统。计算相似度${\mathrm{p}}_{\mathrm{j} \mid  \mathrm{i}}$的解析解在附录B中有简要说明。在初步实验中，我们未发现显式执行随机游走与解析解之间有显著差异。下面的实验中，我们选择显式执行随机游走，因为计算成本较低。然而，对于地标点非常稀疏的超大数据集，解析解可能更为合适。

Figure 7 shows the results of an experiment, in which we applied the random walk version of t-SNE to 6,000 randomly selected digits from the MNIST data set, using all 60,000 digits to compute the pairwise affinities ${\mathrm{p}}_{\mathrm{i} \mid  \mathrm{i}}$ . In the experiment, we used a neighborhood graph that was constructed using a value of $\mathrm{k} = {20}$ nearest neighbors. ${}^{9}$ The inset of the figure shows the same visualization as a scatterplot in which the colors represent the labels of the digits. In the t-SNE map, all classes are clearly separated and the "continental" sevens form a small separate cluster. Moreover, t-SNE reveals the main dimensions of variation within each class, such as the orientation of the ones, fours, sevens, and nines, or the "loopiness" of the twos. The strong performance of t-SNE is also reflected in the generalization error of nearest neighbor classifiers that are trained on the low-dimensional representation. Whereas the generalization error (measured using 10-fold cross validation) of a 1-nearest neighbor classifier trained on the original 784-dimensional datapoints is ${5.75}\%$ , the generalization error of a 1-nearest neighbor classifier trained on the two-dimensional data representation produced by t-SNE is only 5.13%. The computational requirements of random walk t-SNE are reasonable: it took only one hour of CPU time to construct the map in Figure 7.

图7展示了一个实验结果，我们对MNIST数据集中随机选取的6,000个数字应用了随机游走版本的t-SNE，使用全部60,000个数字计算成对亲和度${\mathrm{p}}_{\mathrm{i} \mid  \mathrm{i}}$。实验中，我们使用了一个基于$\mathrm{k} = {20}$近邻数构建的邻域图。${}^{9}$图中插图为散点图，颜色表示数字标签。在t-SNE映射中，所有类别均清晰分离，“大陆式”数字7形成了一个小的独立簇。此外，t-SNE揭示了每个类别内的主要变异维度，如数字1、4、7和9的方向，或数字2的“环状”特征。t-SNE的优异表现也反映在基于低维表示训练的最近邻分类器的泛化误差上。原始784维数据上训练的1-近邻分类器的泛化误差(通过10折交叉验证测量)为${5.75}\%$，而t-SNE生成的二维数据表示上训练的1-近邻分类器的泛化误差仅为5.13%。随机游走t-SNE的计算需求合理:构建图7中的映射仅耗费一小时CPU时间。

## 6. Discussion

## 6. 讨论

The results in the previous two sections (and those in the supplemental material) demonstrate the performance of t-SNE on a wide variety of data sets. In this section, we discuss the differences between t-SNE and other non-parametric techniques (Section 6.1), and we also discuss a number of weaknesses and possible improvements of t-SNE (Section 6.2).

前两节(及补充材料)中的结果展示了t-SNE在多种数据集上的表现。本节将讨论t-SNE与其他非参数技术的差异(第6.1节)，并探讨t-SNE的一些不足及可能的改进(第6.2节)。

### 6.1 Comparison with Related Techniques

### 6.1 与相关技术的比较

Classical scaling (Torgerson, 1952), which is closely related to PCA (Mardia et al., 1979; Williams, 2002), finds a linear transformation of the data that minimizes the sum of the squared errors between high-dimensional pairwise distances and their low-dimensional representatives. A linear method such as classical scaling is not good at modeling curved manifolds and it focuses on preserving the distances between widely separated datapoints rather than on preserving the distances between nearby datapoints. An important approach that attempts to address the problems of classical scaling is the Sammon mapping (Sammon, 1969) which alters the cost function of classical scaling by dividing the squared error in the representation of each pairwise Euclidean distance by the original Euclidean distance in the high-dimensional space. The resulting cost function is given by

经典尺度法(Torgerson, 1952)，与主成分分析(PCA)(Mardia等, 1979；Williams, 2002)密切相关，寻找数据的线性变换，使高维成对距离与其低维表示之间的平方误差和最小化。作为线性方法，经典尺度法不擅长建模曲面流形，且侧重于保持远距离数据点间的距离，而非保持近邻点间的距离。为解决经典尺度法的问题，Sammon映射(Sammon, 1969)提出通过将每对欧氏距离表示的平方误差除以高维空间中的原始欧氏距离来修改经典尺度法的代价函数。所得代价函数为

$$
C = \frac{1}{\mathop{\sum }\limits_{{ij}}\begin{Vmatrix}{{x}_{i} - {x}_{j}}\end{Vmatrix}}\mathop{\sum }\limits_{{i \neq  j}}\frac{{\left( \begin{Vmatrix}{x}_{i} - {x}_{j}\end{Vmatrix} - \begin{Vmatrix}{y}_{i} - {y}_{j}\end{Vmatrix}\right) }^{2}}{\begin{Vmatrix}{x}_{i} - {x}_{j}\end{Vmatrix}},
$$

where the constant outside of the sum is added in order to simplify the derivation of the gradient. The main weakness of the Sammon cost function is that the importance of retaining small pairwise distances in the map is largely dependent on small differences in these pairwise distances. In particular, a small error in the model of two high-dimensional points that are extremely close together results in a large contribution to the cost function. Since all small pairwise distances constitute the local structure of the data, it seems more appropriate to aim to assign approximately equal importance to all small pairwise distances.

求和外的常数项是为简化梯度推导而添加。Sammon代价函数的主要缺点是，保持小的成对距离的重要性过度依赖于这些距离的小差异。特别是，对于两个极其接近的高维点，模型中的小误差会导致代价函数的巨大贡献。由于所有小的成对距离构成了数据的局部结构，更合理的做法是对所有小的成对距离赋予大致相等的重要性。

---

9. In preliminary experiments, we found the performance of random walk $\mathrm{t}$ -SNE to be very robust under changes of $\mathrm{k}$ .

9. 在初步实验中，我们发现随机游走$\mathrm{t}$-SNE对$\mathrm{k}$的变化表现出极强的鲁棒性。

---

![bo_d1c3pf77aajc7389qemg_17_238_346_1313_1438_0.jpg](images/bo_d1c3pf77aajc7389qemg_17_238_346_1313_1438_0.jpg)

Figure 7: Visualization of 6,000 digits from the MNIST data set produced by the random walk version of t-SNE (employing all 60,000 digit images).

图7:由随机游走版本的t-SNE生成的MNIST数据集中6,000个数字的可视化(使用全部60,000个数字图像)。

In contrast to Sammon mapping, the Gaussian kernel employed in the high-dimensional space by t-SNE defines a soft border between the local and global structure of the data and for pairs of datapoints that are close together relative to the standard deviation of the Gaussian, the importance of modeling their separations is almost independent of the magnitudes of those separations. Moreover, t-SNE determines the local neighborhood size for each datapoint separately based on the local density of the data (by forcing each conditional probability distribution ${\mathrm{P}}_{\mathrm{i}}$ to have the same perplexity).

与Sammon映射不同，t-SNE在高维空间中采用的高斯核定义了数据局部结构与全局结构之间的软边界，对于相对于高斯标准差较近的数据点对，其分离建模的重要性几乎不依赖于这些分离的大小。此外，t-SNE基于数据的局部密度为每个数据点单独确定局部邻域大小(通过强制每个条件概率分布${\mathrm{P}}_{\mathrm{i}}$具有相同的困惑度)。

The strong performance of t-SNE compared to Isomap is partly explained by Isomap's susceptibility to "short-circuiting". Also, Isomap mainly focuses on modeling large geodesic distances rather than small ones.

t-SNE相较于Isomap表现优异的部分原因在于Isomap易受“短路”现象影响。此外，Isomap主要关注建模较大的测地距离，而非较小的距离。

The strong performance of t-SNE compared to LLE is mainly due to a basic weakness of LLE: the only thing that prevents all datapoints from collapsing onto a single point is a constraint on the covariance of the low-dimensional representation. In practice, this constraint is often satisfied by placing most of the map points near the center of the map and using a few widely scattered points to create large covariance (see Figure 3(b) and 4(d)). For neighborhood graphs that are almost disconnected, the covariance constraint can also be satisfied by a "curdled" map in which there are a few widely separated, collapsed subsets corresponding to the almost disconnected components. Furthermore, neighborhood-graph based techniques (such as Isomap and LLE) are not capable of visualizing data that consists of two or more widely separated submanifolds, because such data does not give rise to a connected neighborhood graph. It is possible to produce a separate map for each connected component, but this loses information about the relative similarities of the separate components.

t-SNE相较于LLE表现优异主要源于LLE的一个基本弱点:唯一防止所有数据点坍缩到单一点的是对低维表示协方差的约束。实际上，这一约束通常通过将大多数映射点置于映射中心附近，并使用少数分散较广的点来产生较大协方差来满足(见图3(b)和4(d))。对于几乎断开的邻域图，协方差约束也可通过“凝结”映射满足，其中存在几个广泛分离且坍缩的子集，对应于几乎断开的连通分量。此外，基于邻域图的技术(如Isomap和LLE)无法可视化由两个或多个广泛分离的子流形组成的数据，因为此类数据不会产生连通的邻域图。虽然可以为每个连通分量生成单独的映射，但这会丢失关于各分量相对相似性的信息。

Like Isomap and LLE, the random walk version of t-SNE employs neighborhood graphs, but it does not suffer from short-circuiting problems because the pairwise similarities between the high-dimensional datapoints are computed by integrating over all paths through the neighborhood graph. Because of the diffusion-based interpretation of the conditional probabilities underlying the random walk version of t-SNE, it is useful to compare t-SNE to diffusion maps. Diffusion maps define a "diffusion distance" on the high-dimensional datapoints that is given by

与Isomap和LLE类似，t-SNE的随机游走版本采用邻域图，但它不受短路问题影响，因为高维数据点之间的成对相似度是通过对邻域图中所有路径积分计算得出的。鉴于随机游走版本t-SNE所基于的条件概率的扩散解释，将t-SNE与扩散映射进行比较是有意义的。扩散映射在高维数据点上定义了“扩散距离”，其表达为

$$
{D}^{\left( t\right) }\left( {{x}_{i},{x}_{j}}\right)  = \sqrt{\mathop{\sum }\limits_{k}\frac{{\left( {p}_{ik}^{\left( t\right) } - {p}_{jk}^{\left( t\right) }\right) }^{2}}{\psi {\left( {x}_{k}\right) }^{\left( 0\right) }}},
$$

where ${\mathrm{p}}_{\mathrm{{ij}}}^{\left( \mathrm{t}\right) }$ represents the probability of a particle traveling from ${\mathrm{x}}_{\mathrm{i}}$ to ${\mathrm{x}}_{\mathrm{j}}$ in $\mathrm{t}$ timesteps through a graph on the data with Gaussian emission probabilities. The term $\psi {\left( {\mathrm{x}}_{\mathrm{k}}\right) }^{\left( 0\right) }$ is a measure for the local density of the points, and serves a similar purpose to the fixed perplexity Gaussian kernel that is employed in SNE. The diffusion map is formed by the principal non-trivial eigenvectors of the Markov matrix of the random walks of length $\mathrm{t}$ . It can be shown that when all(n - 1)non-trivial eigenvectors are employed, the Euclidean distances in the diffusion map are equal to the diffusion distances in the high-dimensional data representation (Lafon and Lee, 2006). Mathematically, diffusion maps minimize

其中${\mathrm{p}}_{\mathrm{{ij}}}^{\left( \mathrm{t}\right) }$表示粒子通过带有高斯发射概率的数据图从${\mathrm{x}}_{\mathrm{i}}$到${\mathrm{x}}_{\mathrm{j}}$经过$\mathrm{t}$步的概率。项$\psi {\left( {\mathrm{x}}_{\mathrm{k}}\right) }^{\left( 0\right) }$是点的局部密度度量，功能类似于SNE中采用的固定困惑度高斯核。扩散映射由随机游走长度为$\mathrm{t}$的马尔可夫矩阵的主要非平凡特征向量构成。可证明，当使用所有(n - 1)个非平凡特征向量时，扩散映射中的欧氏距离等于高维数据表示中的扩散距离(Lafon和Lee，2006)。数学上，扩散映射最小化

$$
\mathrm{C} = \mathop{\sum }\limits_{\mathrm{i}}\mathop{\sum }\limits_{\mathrm{j}}{\left( {\mathrm{D}}^{\left( \mathrm{t}\right) }\left( {\mathrm{x}}_{\mathrm{i}},{\mathrm{x}}_{\mathrm{j}}\right)  - \begin{Vmatrix}{\mathrm{y}}_{\mathrm{i}} - {\mathrm{y}}_{\mathrm{j}}\end{Vmatrix}\right) }^{2}.
$$

As a result, diffusion maps are susceptible to the same problems as classical scaling: they assign much higher importance to modeling the large pairwise diffusion distances than the small ones and as a result, they are not good at retaining the local structure of the data. Moreover, in contrast to the random walk version of t-SNE, diffusion maps do not have a natural way of selecting the length, t, of the random walks.

因此，扩散映射易受经典尺度法相同问题的影响:它们对建模较大的成对扩散距离赋予远高于较小距离的重要性，因而不擅长保持数据的局部结构。此外，与t-SNE的随机游走版本不同，扩散映射没有自然的方式选择随机游走的长度t。

In the supplemental material, we present results that reveal that t-SNE outperforms CCA (De-martines and Hérault, 1997), MVU (Weinberger et al., 2004), and Laplacian Eigenmaps (Belkin and Niyogi, 2002) as well. For CCA and the closely related CDA (Lee et al., 2000), these results can be partially explained by the hard border $\lambda$ that these techniques define between local and global structure, as opposed to the soft border of t-SNE. Moreover, within the range $\lambda ,\mathrm{{CCA}}$ suffers from the same weakness as Sammon mapping: it assigns extremely high importance to modeling the distance between two datapoints that are extremely close.

在补充材料中，我们展示了t-SNE同样优于CCA(De-martines和Hérault，1997)、MVU(Weinberger等，2004)和拉普拉斯特征映射(Belkin和Niyogi，2002)的结果。对于CCA及其密切相关的CDA(Lee等，2000)，这些结果部分可归因于这些技术在局部与全局结构之间定义的硬边界$\lambda$，而非t-SNE的软边界。此外，在范围$\lambda ,\mathrm{{CCA}}$内，存在与Sammon映射相同的弱点:它对建模两个极其接近的数据点之间的距离赋予极高的重要性。

Like t-SNE, MVU (Weinberger et al., 2004) tries to model all of the small separations well but MVU insists on modeling them perfectly (i.e., it treats them as constraints) and a single erroneous constraint may severely affect the performance of MVU. This can occur when there is a short-circuit between two parts of a curved manifold that are far apart in the intrinsic manifold coordinates. Also, MVU makes no attempt to model longer range structure: It simply pulls the map points as far apart as possible subject to the hard constraints so, unlike t-SNE, it cannot be expected to produce sensible large-scale structure in the map.

与t-SNE类似，MVU(Weinberger等，2004)试图很好地建模所有小的分离，但MVU坚持完美地建模它们(即将其视为约束)，而单个错误的约束可能严重影响MVU的性能。当曲面流形的两个部分在内在流形坐标中相距较远但发生短路时，就可能出现这种情况。此外，MVU不尝试建模更长距离的结构:它仅在硬约束下尽可能拉开映射点，因此，与t-SNE不同，它不能期望在映射中产生合理的大尺度结构。

For Laplacian Eigenmaps, the poor results relative to t-SNE may be explained by the fact that Laplacian Eigenmaps have the same covariance constraint as LLE, and it is easy to cheat on this constraint.

对于Laplacian Eigenmaps，相较于t-SNE表现较差的原因可能在于Laplacian Eigenmaps具有与LLE相同的协方差约束，而这种约束很容易被规避。

### 6.2 Weaknesses

### 6.2 弱点

Although we have shown that t-SNE compares favorably to other techniques for data visualization, t-SNE has three potential weaknesses: (1) it is unclear how t-SNE performs on general dimensionality reduction tasks, (2) the relatively local nature of t-SNE makes it sensitive to the curse of the intrinsic dimensionality of the data, and (3) t-SNE is not guaranteed to converge to a global optimum of its cost function. Below, we discuss the three weaknesses in more detail.

尽管我们已经展示了t-SNE在数据可视化方面优于其他技术，t-SNE仍存在三个潜在弱点:(1)t-SNE在一般降维任务中的表现尚不明确，(2)t-SNE的相对局部性质使其对数据内在维度的诅咒敏感，以及(3)t-SNE不保证其代价函数收敛到全局最优。以下我们将更详细地讨论这三个弱点。

1) Dimensionality reduction for other purposes. It is not obvious how t-SNE will perform on the more general task of dimensionality reduction (i.e., when the dimensionality of the data is not reduced to two or three, but to $\mathrm{d} > 3$ dimensions). To simplify evaluation issues, this paper only considers the use of t-SNE for data visualization. The behavior of t-SNE when reducing data to two or three dimensions cannot readily be extrapolated to $\mathrm{d} > 3$ dimensions because of the heavy tails of the Student-t distribution. In high-dimensional spaces, the heavy tails comprise a relatively large portion of the probability mass under the Student-t distribution, which might lead to d-dimensional data representations that do not preserve the local structure of the data as well. Hence, for tasks in which the dimensionality of the data needs to be reduced to a dimensionality higher than three, Student t-distributions with more than one degree of freedom ${}^{10}$ are likely to be more appropriate.

1)用于其他目的的降维。t-SNE在更一般的降维任务中的表现尚不明显(即当数据维度被降至$\mathrm{d} > 3$维而非二维或三维时)。为简化评估问题，本文仅考虑t-SNE在数据可视化中的应用。由于Student-t分布的重尾特性，t-SNE在将数据降至二维或三维时的行为不能轻易外推到$\mathrm{d} > 3$维。在高维空间中，Student-t分布的重尾占据了相对较大比例的概率质量，这可能导致d维数据表示无法很好地保持数据的局部结构。因此，对于需要将数据维度降至三维以上的任务，具有多于一个自由度的Student t分布${}^{10}$可能更为合适。

2) Curse of intrinsic dimensionality. t-SNE reduces the dimensionality of data mainly based on local properties of the data, which makes t-SNE sensitive to the curse of the intrinsic dimensionality of the data (Bengio, 2007). In data sets with a high intrinsic dimensionality and an underlying manifold that is highly varying, the local linearity assumption on the manifold that t-SNE implicitly makes (by employing Euclidean distances between near neighbors) may be violated. As a result, t-SNE might be less successful if it is applied on data sets with a very high intrinsic dimensionality (for instance, a recent study by Meytlis and Sirovich (2007) estimates the space of images of faces to be constituted of approximately 100 dimensions). Manifold learners such as Isomap and LLE suffer from exactly the same problems (see, e.g., Bengio, 2007; van der Maaten et al., 2008). A possible way to (partially) address this issue is by performing t-SNE on a data representation obtained from a model that represents the highly varying data manifold efficiently in a number of nonlinear layers such as an autoencoder (Hinton and Salakhutdinov, 2006). Such deep-layer architectures can represent complex nonlinear functions in a much simpler way, and as a result, require fewer datapoints to learn an appropriate solution (as is illustrated for a d-bits parity task by Bengio 2007). Performing t-SNE on a data representation produced by, for example, an autoencoder is likely to improve the quality of the constructed visualizations, because autoencoders can identify highly-varying manifolds better than a local method such as t-SNE. However, the reader should note that it is by definition impossible to fully represent the structure of intrinsically high-dimensional data in two or three dimensions.

2)内在维度的诅咒。t-SNE主要基于数据的局部属性进行降维，这使得t-SNE对数据内在维度的诅咒敏感(Bengio，2007)。在内在维度较高且底层流形变化剧烈的数据集中，t-SNE隐含的流形局部线性假设(通过使用近邻间的欧氏距离)可能被破坏。因此，当应用于内在维度非常高的数据集时，t-SNE的效果可能不佳(例如，Meytlis和Sirovich(2007)的一项最新研究估计人脸图像空间约由100维构成)。流形学习方法如Isomap和LLE也存在完全相同的问题(参见如Bengio，2007；van der Maaten等，2008)。解决该问题的一种可能方法是对通过能够高效表示高度变化数据流形的模型(如自编码器(Hinton和Salakhutdinov，2006))获得的数据表示执行t-SNE。这类深层架构能够以更简单的方式表示复杂的非线性函数，因此需要更少的数据点来学习合适的解(如Bengio 2007在d位奇偶任务中所示)。在例如自编码器生成的数据表示上执行t-SNE，可能提升构建可视化的质量，因为自编码器比t-SNE这类局部方法更能识别高度变化的流形。然而，读者应注意，按定义，无法在二维或三维中完全表示内在高维数据的结构。

3) Non-convexity of the t-SNE cost function. A nice property of most state-of-the-art dimensionality reduction techniques (such as classical scaling, Isomap, LLE, and diffusion maps) is the convexity of their cost functions. A major weakness of t-SNE is that the cost function is not convex, as a result of which several optimization parameters need to be chosen. The constructed solutions depend on these choices of optimization parameters and may be different each time t-SNE is run from an initial random configuration of map points. We have demonstrated that the same choice of optimization parameters can be used for a variety of different visualization tasks, and we found that the quality of the optima does not vary much from run to run. Therefore, we think that the weakness of the optimization method is insufficient reason to reject t-SNE in favor of methods that lead to convex optimization problems but produce noticeably worse visualizations. A local optimum of a cost function that accurately captures what we want in a visualization is often preferable to the global optimum of a cost function that fails to capture important aspects of what we want. Moreover, the convexity of cost functions can be misleading, because their optimization is often computationally infeasible for large real-world data sets, prompting the use of approximation techniques (de Silva and Tenenbaum, 2003; Weinberger et al., 2007). Even for LLE and Laplacian Eigenmaps, the optimization is performed using iterative Arnoldi (Arnoldi, 1951) or Jacobi-Davidson (Fokkema et al., 1999) methods, which may fail to find the global optimum due to convergence problems.

3)t-SNE代价函数的非凸性。大多数先进降维技术(如经典尺度法(classical scaling)、Isomap、局部线性嵌入(LLE)和扩散映射(diffusion maps))的一个优良性质是其代价函数的凸性。t-SNE的一个主要缺点是其代价函数非凸，因此需要选择多个优化参数。构造的解依赖于这些优化参数的选择，并且每次从初始随机映射点配置运行t-SNE时结果可能不同。我们已证明相同的优化参数选择可用于多种不同的可视化任务，且最优解的质量在多次运行中变化不大。因此，我们认为优化方法的缺陷不足以成为放弃t-SNE而选择那些导致凸优化问题但产生明显较差可视化效果的方法的理由。一个准确捕捉我们期望可视化内容的代价函数的局部最优解，往往优于未能捕捉重要方面的代价函数的全局最优解。此外，代价函数的凸性可能具有误导性，因为其优化在大规模真实数据集上通常计算不可行，促使采用近似技术(de Silva和Tenenbaum，2003；Weinberger等，2007)。即使是LLE和拉普拉斯特征映射(Laplacian Eigenmaps)，其优化也采用迭代Arnoldi(Arnoldi，1951)或Jacobi-Davidson(Fokkema等，1999)方法，由于收敛问题可能无法找到全局最优解。

## 7. Conclusions

## 7. 结论

The paper presents a new technique for the visualization of similarity data that is capable of retaining the local structure of the data while also revealing some important global structure (such as clusters at multiple scales). Both the computational and the memory complexity of t-SNE are $\mathrm{O}\left( {\mathrm{n}}^{2}\right)$ , but we present a landmark approach that makes it possible to successfully visualize large real-world data sets with limited computational demands. Our experiments on a variety of data sets show that t-SNE outperforms existing state-of-the-art techniques for visualizing a variety of real-world data sets. Matlab implementations of both the normal and the random walk version of t-SNE are available for download at http://ticc.uvt.nl/~lvdrmaaten/tsne.

本文提出了一种新的相似性数据可视化技术，能够保留数据的局部结构，同时揭示一些重要的全局结构(如多尺度的簇)。t-SNE的计算和内存复杂度均为$\mathrm{O}\left( {\mathrm{n}}^{2}\right)$，但我们提出了一种基准点方法，使得在有限计算资源下成功可视化大规模真实数据集成为可能。我们在多种数据集上的实验表明，t-SNE在可视化多种真实数据集方面优于现有的先进技术。Matlab版本的标准和随机游走版本t-SNE可在http://ticc.uvt.nl/~lvdrmaaten/tsne下载。

---

10. Increasing the degrees of freedom of a Student-t distribution makes the tails of the distribution lighter. With infinite degrees of freedom, the Student-t distribution is equal to the Gaussian distribution.

10. 增加Student-t分布的自由度会使分布的尾部变轻。当自由度趋于无穷大时，Student-t分布等价于高斯分布。

---

In future work we plan to investigate the optimization of the number of degrees of freedom of the Student-t distribution used in t-SNE. This may be helpful for dimensionality reduction when the low-dimensional representation has many dimensions. We will also investigate the extension of t-SNE to models in which each high-dimensional datapoint is modeled by several low-dimensional map points as in Cook et al. (2007). Also, we aim to develop a parametric version of t-SNE that allows for generalization to held-out test data by using the t-SNE objective function to train a multilayer neural network that provides an explicit mapping to the low-dimensional space.

未来工作中，我们计划研究t-SNE中Student-t分布自由度的优化。这对于低维表示维度较多时的降维可能有帮助。我们还将研究将t-SNE扩展到每个高维数据点由多个低维映射点建模的模型，如Cook等(2007)所述。此外，我们旨在开发t-SNE的参数化版本，通过使用t-SNE目标函数训练多层神经网络，实现对保留测试数据的泛化，提供显式的低维映射。

## Acknowledgments

## 致谢

The authors thank Sam Roweis for many helpful discussions, Andriy Mnih for supplying the word-features data set, Ruslan Salakhutdinov for help with the Netflix data set (results for these data sets are presented in the supplemental material), and Guido de Croon for pointing us to the analytical solution of the random walk probabilities.

作者感谢Sam Roweis的多次有益讨论，Andriy Mnih提供词特征数据集，Ruslan Salakhutdinov协助Netflix数据集(这些数据集的结果见补充材料)，以及Guido de Croon指引我们随机游走概率的解析解。

Laurens van der Maaten is supported by the CATCH-programme of the Dutch Scientific Organization (NWO), project RICH (grant 640.002.401), and cooperates with RACM. Geoffrey Hinton is a fellow of the Canadian Institute for Advanced Research, and is also supported by grants from NSERC and CFI and gifts from Google and Microsoft.

Laurens van der Maaten受荷兰科学组织(NWO)CATCH项目资助，项目RICH(资助号640.002.401)，并与RACM合作。Geoffrey Hinton是加拿大高级研究院(Canadian Institute for Advanced Research)研究员，同时获得NSERC和CFI资助，以及Google和Microsoft的捐赠支持。

## Appendix A. Derivation of the t-SNE gradient

## 附录A. t-SNE梯度推导

t-SNE minimizes the Kullback-Leibler divergence between the joint probabilities ${\mathrm{p}}_{\mathrm{{ij}}}$ in the high-dimensional space and the joint probabilities ${\mathrm{q}}_{\mathrm{{ij}}}$ in the low-dimensional space. The values of ${\mathrm{p}}_{\mathrm{{ij}}}$ are defined to be the symmetrized conditional probabilities, whereas the values of ${\mathrm{q}}_{\mathrm{{ij}}}$ are obtained by means of a Student-t distribution with one degree of freedom

t-SNE通过最小化高维空间中联合概率${\mathrm{p}}_{\mathrm{{ij}}}$与低维空间中联合概率${\mathrm{q}}_{\mathrm{{ij}}}$之间的Kullback-Leibler散度来实现。${\mathrm{p}}_{\mathrm{{ij}}}$的值定义为对称化的条件概率，而${\mathrm{q}}_{\mathrm{{ij}}}$的值则通过自由度为1的Student-t分布获得。

$$
{\mathrm{p}}_{\mathrm{i}\mathrm{j}} = \frac{{\mathrm{p}}_{\mathrm{j} \mid  \mathrm{i}} + {\mathrm{p}}_{\mathrm{i} \mid  \mathrm{j}}}{2\mathrm{n}},
$$

$$
{\mathrm{q}}_{\mathrm{i}\mathrm{j}} = \frac{{\left( 1 + {\begin{Vmatrix}{\mathrm{y}}_{\mathrm{i}} - {\mathrm{y}}_{\mathrm{j}}\end{Vmatrix}}^{2}\right) }^{-1}}{\mathop{\sum }\limits_{{\mathrm{k} \neq  1}}{\left( 1 + {\begin{Vmatrix}{\mathrm{y}}_{\mathrm{k}} - {\mathrm{y}}_{\mathrm{l}}\end{Vmatrix}}^{2}\right) }^{-1}},
$$

where ${p}_{\left| \right| \mathrm{i}}$ and ${p}_{\mathrm{i} \mid  \mathrm{j}}$ are either obtained from Equation 1 or from the random walk procedure described in Section 5. The values of ${\mathrm{p}}_{\mathrm{{ii}}}$ and ${\mathrm{q}}_{\mathrm{{ii}}}$ are set to zero. The Kullback-Leibler divergence between the two joint probability distributions $\mathrm{P}$ and $\mathrm{Q}$ is given by

其中 ${p}_{\left| \right| \mathrm{i}}$ 和 ${p}_{\mathrm{i} \mid  \mathrm{j}}$ 可通过公式1或第5节中描述的随机游走过程获得。${\mathrm{p}}_{\mathrm{{ii}}}$ 和 ${\mathrm{q}}_{\mathrm{{ii}}}$ 的值设为零。两个联合概率分布 $\mathrm{P}$ 和 $\mathrm{Q}$ 之间的Kullback-Leibler散度(KL散度)定义为

$$
C = {KL}\left( {P\parallel Q}\right)  = \mathop{\sum }\limits_{i}\mathop{\sum }\limits_{j}{p}_{ij}\log \frac{{p}_{ij}}{{q}_{ij}}
$$

$$
= \mathop{\sum }\limits_{\mathrm{i}}\mathop{\sum }\limits_{\mathrm{j}}{\mathrm{p}}_{\mathrm{i}\mathrm{j}}\log {\mathrm{p}}_{\mathrm{i}\mathrm{j}} - {\mathrm{p}}_{\mathrm{i}\mathrm{j}}\log {\mathrm{q}}_{\mathrm{i}\mathrm{j}}. \tag{6}
$$

In order to make the derivation less cluttered, we define two auxiliary variables ${\mathrm{d}}_{\mathrm{{ij}}}$ and $\mathrm{Z}$ as follows

为了使推导更简洁，我们定义两个辅助变量 ${\mathrm{d}}_{\mathrm{{ij}}}$ 和 $\mathrm{Z}$ 如下

$$
{\mathrm{d}}_{\mathrm{i}\mathrm{j}} = \begin{Vmatrix}{{\mathrm{y}}_{\mathrm{i}} - {\mathrm{y}}_{\mathrm{j}}}\end{Vmatrix},
$$

$$
\mathrm{Z} = \mathop{\sum }\limits_{{\mathrm{k} \neq  1}}{\left( 1 + {\mathrm{d}}_{\mathrm{{kl}}}^{2}\right) }^{-1}.
$$

Note that if ${y}_{i}$ changes, the only pairwise distances that change are ${d}_{ij}$ and ${d}_{ji}$ for $\forall j$ . Hence, the gradient of the cost function $\mathrm{C}$ with respect to ${\mathrm{y}}_{\mathrm{i}}$ is given by

注意，如果 ${y}_{i}$ 发生变化，唯一变化的成对距离是 ${d}_{ij}$ 和 ${d}_{ji}$ 对于 $\forall j$ 。因此，代价函数 $\mathrm{C}$ 关于 ${\mathrm{y}}_{\mathrm{i}}$ 的梯度为

$$
\frac{\delta C}{\delta {y}_{i}} = \mathop{\sum }\limits_{j}\left( {\frac{\delta C}{\delta {d}_{ij}} + \frac{\delta C}{\delta {d}_{ji}}}\right) \left( {{y}_{i} - {y}_{j}}\right)
$$

$$
= 2\mathop{\sum }\limits_{j}\frac{\delta C}{\delta {d}_{ij}}\left( {{y}_{i} - {y}_{j}}\right) . \tag{7}
$$

The gradient $\frac{\delta C}{\delta {d}_{ij}}$ is computed from the definition of the Kullback-Leibler divergence in Equation 6 (note that the first part of this equation is a constant).

梯度 $\frac{\delta C}{\delta {d}_{ij}}$ 是根据公式6中Kullback-Leibler散度的定义计算的(注意该公式的第一部分为常数)。

$$
\frac{\delta C}{\delta {d}_{ij}} =  - \mathop{\sum }\limits_{{k \neq  l}}{p}_{kl}\frac{\delta \left( {\log {q}_{kl}}\right) }{\delta {d}_{ij}}
$$

$$
=  - \mathop{\sum }\limits_{{k \neq  l}}{p}_{kl}\frac{\delta \left( {\log {q}_{kl}Z - \log Z}\right) }{\delta {d}_{ij}}
$$

$$
=  - \mathop{\sum }\limits_{{k \neq  l}}{p}_{kl}\left( {\frac{1}{{q}_{kl}Z}\frac{\delta \left( {\left( 1 + {d}_{kl}^{2}\right) }^{-1}\right) }{\delta {d}_{ij}} - \frac{1}{Z}\frac{\delta Z}{\delta {d}_{ij}}}\right)
$$

The gradient $\frac{\delta \left( {\left( 1 + {d}_{kl}^{2}\right) }^{-1}\right) }{\delta {d}_{ij}}$ is only nonzero when $k = i$ and $l = j$ . Hence, the gradient $\frac{\delta C}{\delta {d}_{ij}}$ is given by

梯度 $\frac{\delta \left( {\left( 1 + {d}_{kl}^{2}\right) }^{-1}\right) }{\delta {d}_{ij}}$ 仅在 $k = i$ 和 $l = j$ 时非零。因此，梯度 $\frac{\delta C}{\delta {d}_{ij}}$ 表达为

$$
\frac{\delta C}{\delta {d}_{ij}} = 2\frac{{p}_{ij}}{{q}_{ij}Z}{\left( 1 + {d}_{ij}^{2}\right) }^{-2} - 2\mathop{\sum }\limits_{{k \neq  l}}{p}_{kl}\frac{{\left( 1 + {d}_{ij}^{2}\right) }^{-2}}{Z}.
$$

Noting that $\mathop{\sum }\limits_{{\mathrm{k} \neq  1}}{\mathrm{p}}_{\mathrm{{kl}}} = 1$ , we see that the gradient simplifies to

注意到 $\mathop{\sum }\limits_{{\mathrm{k} \neq  1}}{\mathrm{p}}_{\mathrm{{kl}}} = 1$ ，我们看到梯度简化为

$$
\frac{\delta C}{\delta {d}_{ij}} = 2{p}_{ij}{\left( 1 + {d}_{ij}^{2}\right) }^{-1} - 2{q}_{ij}{\left( 1 + {d}_{ij}^{2}\right) }^{-1}
$$

$$
= 2\left( {{\mathrm{p}}_{\mathrm{i}\mathrm{j}} - {\mathrm{q}}_{\mathrm{i}\mathrm{j}}}\right) {\left( 1 + {\mathrm{d}}_{\mathrm{i}\mathrm{j}}^{2}\right) }^{-1}.
$$

Substituting this term into Equation 7, we obtain the gradient

将该项代入公式7，得到梯度

$$
\frac{\delta C}{\delta {y}_{i}} = 4\mathop{\sum }\limits_{j}\left( {{p}_{ij} - {q}_{ij}}\right) {\left( 1 + {\begin{Vmatrix}{y}_{i} - {y}_{j}\end{Vmatrix}}^{2}\right) }^{-1}\left( {{y}_{i} - {y}_{j}}\right) .
$$

Appendix B. Analytical Solution to Random Walk Probabilities

附录B. 随机游走概率的解析解

Below, we describe the analytical solution to the random walk probabilities that are employed in the random walk version of t-SNE (see Section 5). The solution is described in more detail by Grady (2006).

下面，我们描述用于t-SNE随机游走版本(见第5节)中的随机游走概率的解析解。该解由Grady(2006)详细描述。

It can be shown that computing the probability that a random walk initiated from a non-landmark point (on a graph that is specified by adjacency matrix W) first reaches a specific landmark point is equal to computing the solution to the combinatorial Dirichlet problem in which the boundary conditions are at the locations of the landmark points, the considered landmark point is fixed to unity, and the other landmarks points are set to zero (Kakutani, 1945; Doyle and Snell, 1984). In practice, the solution can thus be obtained by minimizing the combinatorial formulation of the Dirichlet integral

可以证明，计算从非地标点(在由邻接矩阵W指定的图上)发起的随机游走首次到达特定地标点的概率，等价于求解组合Dirichlet问题，其中边界条件设定在地标点位置，所考虑的地标点固定为1，其他地标点设为0(Kakutani, 1945；Doyle和Snell, 1984)。实际上，该解可通过最小化Dirichlet积分的组合形式获得

$$
\mathrm{D}\left\lbrack  \mathrm{x}\right\rbrack   = \frac{1}{2}{\mathrm{x}}^{\mathrm{T}}\mathrm{{Lx}},
$$

where $\mathrm{L}$ represents the graph Laplacian. Mathematically, the graph Laplacian is given by $\mathrm{L} =$ $\mathrm{D} - \mathrm{W}$ , where $\mathrm{D} = \operatorname{diag}\left( {\mathop{\sum }\limits_{\mathrm{j}}{\mathrm{w}}_{1\mathrm{j}},\mathop{\sum }\limits_{\mathrm{j}}{\mathrm{w}}_{2\mathrm{j}},\ldots ,\mathop{\sum }\limits_{\mathrm{j}}{\mathrm{w}}_{\mathrm{n}\mathrm{j}}}\right)$ . Without loss of generality, we may reorder the landmark points such that the landmark points come first. As a result, the combinatorial Dirichlet integral decomposes into

其中 $\mathrm{L}$ 表示图拉普拉斯算子。从数学上讲，图拉普拉斯算子定义为 $\mathrm{L} =$ $\mathrm{D} - \mathrm{W}$ ，其中 $\mathrm{D} = \operatorname{diag}\left( {\mathop{\sum }\limits_{\mathrm{j}}{\mathrm{w}}_{1\mathrm{j}},\mathop{\sum }\limits_{\mathrm{j}}{\mathrm{w}}_{2\mathrm{j}},\ldots ,\mathop{\sum }\limits_{\mathrm{j}}{\mathrm{w}}_{\mathrm{n}\mathrm{j}}}\right)$ 。不失一般性，我们可以重新排序地标点，使地标点排在前面。因此，组合Dirichlet积分分解为

$$
\mathrm{D}\left\lbrack  {\mathrm{x}}_{\mathrm{N}}\right\rbrack   = \frac{1}{2}\left\lbrack  \begin{array}{ll} {\mathrm{x}}_{\mathrm{L}}^{\mathrm{T}} & {\mathrm{x}}_{\mathrm{N}}^{\mathrm{T}} \end{array}\right\rbrack  \left\lbrack  \begin{matrix} {\mathrm{L}}_{\mathrm{L}} & \mathrm{B} \\  {\mathrm{B}}^{\mathrm{T}} & {\mathrm{L}}_{\mathrm{N}} \end{matrix}\right\rbrack  \left\lbrack  \begin{array}{l} {\mathrm{x}}_{\mathrm{L}} \\  {\mathrm{x}}_{\mathrm{N}} \end{array}\right\rbrack
$$

$$
= \frac{1}{2}\left( {{\mathrm{x}}_{\mathrm{L}}^{\mathrm{T}}{\mathrm{L}}_{\mathrm{L}}{\mathrm{x}}_{\mathrm{L}} + 2{\mathrm{x}}_{\mathrm{N}}^{\mathrm{T}}{\mathrm{B}}^{\mathrm{T}}{\mathrm{x}}_{\mathrm{M}} + {\mathrm{x}}_{\mathrm{N}}^{\mathrm{T}}{\mathrm{L}}_{\mathrm{N}}{\mathrm{x}}_{\mathrm{N}}}\right) ,
$$

where we use the subscript ${ \cdot  }_{\mathrm{L}}$ to indicate the landmark points, and the subscript ${ \cdot  }_{\mathrm{N}}$ to indicate the non-landmark points. Differentiating $\mathrm{D}\left\lbrack  {\mathrm{x}}_{\mathrm{N}}\right\rbrack$ with respect to ${\mathrm{x}}_{\mathrm{N}}$ and finding its critical points amounts to solving the linear systems

其中下标 ${ \cdot  }_{\mathrm{L}}$ 表示地标点，下标 ${ \cdot  }_{\mathrm{N}}$ 表示非地标点。对 $\mathrm{D}\left\lbrack  {\mathrm{x}}_{\mathrm{N}}\right\rbrack$ 关于 ${\mathrm{x}}_{\mathrm{N}}$ 求导并寻找其临界点，相当于求解线性方程组

$$
{\mathrm{L}}_{\mathrm{N}}{\mathrm{x}}_{\mathrm{N}} =  - {\mathrm{B}}^{\mathrm{T}}. \tag{8}
$$

Please note that in this linear system, ${\mathrm{B}}^{\mathrm{T}}$ is a matrix containing the columns from the graph Laplacian $\mathrm{L}$ that correspond to the landmark points (excluding the rows that correspond to landmark points). After normalization of the solutions to the systems ${\mathrm{X}}_{\mathrm{N}}$ , the column vectors of ${\mathrm{X}}_{\mathrm{N}}$ contain the probability that a random walk initiated from a non-landmark point terminates in a landmark point. One should note that the linear system in Equation 8 is only nonsingular if the graph is completely connected, or if each connected component in the graph contains at least one landmark point (Biggs, 1974).

请注意，在此线性系统中，${\mathrm{B}}^{\mathrm{T}}$ 是一个矩阵，包含图拉普拉斯算子(graph Laplacian)$\mathrm{L}$ 中对应地标点的列(不包括对应地标点的行)。在对系统 ${\mathrm{X}}_{\mathrm{N}}$ 的解进行归一化后，${\mathrm{X}}_{\mathrm{N}}$ 的列向量包含了从非地标点出发的随机游走终止于地标点的概率。需要注意的是，方程8中的线性系统仅在图完全连通，或图中每个连通分量至少包含一个地标点时才是非奇异的(Biggs, 1974)。

Because we are interested in the probability of a random walk initiated from a landmark point terminating at another landmark point, we duplicate all landmark points in the neighborhood graph, and initiate the random walks from the duplicate landmarks. Because of memory constraints, it is not possible to store the entire matrix ${\mathrm{X}}_{\mathrm{N}}$ into memory (note that we are only interested in a small number of rows from this matrix, viz., in the rows corresponding to the duplicate landmark points). Hence, we solve the linear systems defined by the columns of $- {\mathrm{B}}^{\mathrm{T}}$ one-by-one, and store only the parts of the solutions that correspond to the duplicate landmark points. For computational reasons, we first perform a Cholesky factorization of ${\mathrm{L}}_{\mathrm{N}}$ , such that ${\mathrm{L}}_{\mathrm{N}} = {\mathrm{{CC}}}^{\mathrm{T}}$ , where $\mathrm{C}$ is an upper-triangular matrix. Subsequently, the solution to the linear system in Equation 8 is obtained by solving the linear systems $\mathrm{{Cy}} =  - {\mathrm{B}}^{\mathrm{T}}$ and ${\mathrm{{Cx}}}_{\mathrm{N}} = \mathrm{y}$ using a fast backsubstitution method.

由于我们关注的是从地标点出发的随机游走终止于另一个地标点的概率，我们在邻接图中复制所有地标点，并从复制的地标点开始随机游走。由于内存限制，无法将整个矩阵 ${\mathrm{X}}_{\mathrm{N}}$ 存储到内存中(注意我们只关心该矩阵中少数几行，即对应复制地标点的行)。因此，我们逐列求解由 $- {\mathrm{B}}^{\mathrm{T}}$ 定义的线性系统，并仅存储对应复制地标点的解部分。出于计算考虑，我们首先对 ${\mathrm{L}}_{\mathrm{N}}$ 进行Cholesky分解，使得 ${\mathrm{L}}_{\mathrm{N}} = {\mathrm{{CC}}}^{\mathrm{T}}$，其中 $\mathrm{C}$ 是上三角矩阵。随后，通过快速回代方法分别求解线性系统 $\mathrm{{Cy}} =  - {\mathrm{B}}^{\mathrm{T}}$ 和 ${\mathrm{{Cx}}}_{\mathrm{N}} = \mathrm{y}$，得到方程8中线性系统的解。

## References

## 参考文献

W.E. Arnoldi. The principle of minimized iteration in the solution of the matrix eigenvalue problem. Quarterly of Applied Mathematics, 9:17-25, 1951.

W.E. Arnoldi. 矩阵特征值问题求解中的最小迭代原理。应用数学季刊，9:17-25, 1951。

G.D. Battista, P. Eades, R. Tamassia, and I.G. Tollis. Annotated bibliography on graph drawing. Computational Geometry: Theory and Applications, 4:235-282, 1994.

G.D. Battista, P. Eades, R. Tamassia, 和 I.G. Tollis. 图绘制的注释书目。计算几何:理论与应用，4:235-282, 1994。

M. Belkin and P. Niyogi. Laplacian Eigenmaps and spectral techniques for embedding and clustering. In Advances in Neural Information Processing Systems, volume 14, pages 585-591, Cambridge, MA, USA, 2002. The MIT Press.

M. Belkin 和 P. Niyogi. 拉普拉斯特征映射(Laplacian Eigenmaps)及其在嵌入和聚类中的谱技术。载于《神经信息处理系统进展》，第14卷，第585-591页，剑桥，马萨诸塞，美国，2002。MIT出版社。

Y. Bengio. Learning deep architectures for AI. Technical Report 1312, Université de Montréal, 2007.

Y. Bengio. 深度架构学习用于人工智能。蒙特利尔大学技术报告1312，2007。

N. Biggs. Algebraic graph theory. In Cambridge Tracts in Mathematics, volume 67. Cambridge University Press, 1974.

N. Biggs. 代数图论。剑桥数学丛书，第67卷。剑桥大学出版社，1974。

H. Chernoff. The use of faces to represent points in k-dimensional space graphically. Journal of the American Statistical Association, 68:361-368, 1973.

H. Chernoff. 使用面表示k维空间中的点的图形方法。美国统计协会杂志，68:361-368, 1973。

J.A. Cook, I. Sutskever, A. Mnih, and G.E. Hinton. Visualizing similarity data with a mixture of maps. In Proceedings of the ${11}^{\text{th }}$ International Conference on Artificial Intelligence and Statistics, volume 2, pages 67-74, 2007.

J.A. Cook, I. Sutskever, A. Mnih, 和 G.E. Hinton. 使用混合映射可视化相似性数据。载于${11}^{\text{th }}$国际人工智能与统计会议论文集，第2卷，第67-74页，2007。

M.C. Ferreira de Oliveira and H. Levkowitz. From visual data exploration to visual data mining: A survey. IEEE Transactions on Visualization and Computer Graphics, 9(3):378-394, 2003.

M.C. Ferreira de Oliveira 和 H. Levkowitz. 从视觉数据探索到视觉数据挖掘:综述。IEEE可视化与计算机图形学汇刊，9(3):378-394, 2003。

V. de Silva and J.B. Tenenbaum. Global versus local methods in nonlinear dimensionality reduction. In Advances in Neural Information Processing Systems, volume 15, pages 721-728, Cambridge, MA, USA, 2003. The MIT Press.

V. de Silva 和 J.B. Tenenbaum. 非线性降维中的全局方法与局部方法比较。载于《神经信息处理系统进展》，第15卷，第721-728页，剑桥，马萨诸塞，美国，2003。MIT出版社。

P. Demartines and J. Hérault. Curvilinear component analysis: A self-organizing neural network for nonlinear mapping of data sets. IEEE Transactions on Neural Networks, 8(1):148-154, 1997.

P. Demartines 和 J. Hérault. 曲线分量分析:一种用于数据集非线性映射的自组织神经网络。IEEE神经网络汇刊，8(1):148-154, 1997。

P. Doyle and L. Snell. Random walks and electric networks. In Carus mathematical monographs, volume 22. Mathematical Association of America, 1984.

P. Doyle 和 L. Snell. 随机游走与电网络。Carus数学专著，第22卷。美国数学协会，1984。

D.R. Fokkema, G.L.G. Sleijpen, and H.A. van der Vorst. Jacobi-Davidson style QR and QZ algorithms for the reduction of matrix pencils. SIAM Journal on Scientific Computing,20(1):94-125, 1999.

D.R. Fokkema, G.L.G. Sleijpen, 和 H.A. van der Vorst. Jacobi-Davidson风格的QR和QZ算法用于矩阵铅笔的约简。SIAM科学计算杂志，20(1):94-125, 1999。

L. Grady. Random walks for image segmentation. IEEE Transactions on Pattern Analysis and Machine Intelligence, 28(11):1768-1783, 2006.

L. Grady. 用于图像分割的随机游走。IEEE模式分析与机器智能汇刊，28(11):1768-1783, 2006。

G.E. Hinton and S.T. Roweis. Stochastic Neighbor Embedding. In Advances in Neural Information Processing Systems, volume 15, pages 833-840, Cambridge, MA, USA, 2002. The MIT Press.

G.E. Hinton 和 S.T. Roweis. 随机邻居嵌入(Stochastic Neighbor Embedding)。载于《神经信息处理系统进展》，第15卷，第833-840页，美国马萨诸塞州剑桥，2002年。MIT出版社。

G.E. Hinton and R.R. Salakhutdinov. Reducing the dimensionality of data with neural networks. Science, 313(5786):504-507, 2006.

G.E. Hinton 和 R.R. Salakhutdinov. 利用神经网络降低数据维度。科学，313(5786):504-507, 2006。

H. Hotelling. Analysis of a complex of statistical variables into principal components. Journal of Educational Psychology, 24:417-441, 1933.

H. Hotelling. 统计变量复合体的主成分分析。教育心理学杂志，24:417-441, 1933。

R.A. Jacobs. Increased rates of convergence through learning rate adaptation. Neural Networks, 1: 295-307, 1988.

R.A. Jacobs. 通过学习率自适应提高收敛速度。神经网络，1: 295-307, 1988。

S. Kakutani. Markov processes and the Dirichlet problem. Proceedings of the Japan Academy, 21: 227-233, 1945.

S. Kakutani. 马尔可夫过程与狄利克雷问题。日本科学院学报，21: 227-233, 1945。

D.A. Keim. Designing pixel-oriented visualization techniques: Theory and applications. IEEE Transactions on Visualization and Computer Graphics, 6(1):59-78, 2000.

D.A. Keim. 设计面向像素的可视化技术:理论与应用。IEEE可视化与计算机图形汇刊，6(1):59-78, 2000。

S. Lafon and A.B. Lee. Diffusion maps and coarse-graining: A unified framework for dimensionality reduction, graph partitioning, and data set parameterization. IEEE Transactions on Pattern Analysis and Machine Intelligence, 28(9):1393-1403, 2006.

S. Lafon 和 A.B. Lee. 扩散映射与粗粒化:维度约简、图划分及数据集参数化的统一框架。IEEE模式分析与机器智能汇刊，28(9):1393-1403, 2006。

J.A. Lee and M. Verleysen. Nonlinear dimensionality reduction of data manifolds with essential loops. Neurocomputing, 67:29-53, 2005.

J.A. Lee 和 M. Verleysen. 具有基本环的流形数据的非线性降维。神经计算，67:29-53, 2005。

J.A. Lee and M. Verleysen. Nonlinear dimensionality reduction. Springer, New York, NY, USA, 2007.

J.A. Lee 和 M. Verleysen. 非线性降维。施普林格出版社，美国纽约，2007。

J.A. Lee, A. Lendasse, N. Donckers, and M. Verleysen. A robust nonlinear projection method. In Proceedings of the ${8}^{\text{th }}$ European Symposium on Artificial Neural Networks, pages 13-20,2000.

J.A. Lee, A. Lendasse, N. Donckers 和 M. Verleysen. 一种鲁棒的非线性投影方法。载于${8}^{\text{th }}$欧洲人工神经网络研讨会论文集，第13-20页，2000年。

K.V. Mardia, J.T. Kent, and J.M. Bibby. Multivariate Analysis. Academic Press, 1979.

K.V. Mardia, J.T. Kent 和 J.M. Bibby. 多变量分析。学术出版社，1979。

M. Meytlis and L. Sirovich. On the dimensionality of face space. IEEE Transactions of Pattern Analysis and Machine Intelligence, 29(7):1262-1267, 2007.

M. Meytlis 和 L. Sirovich. 面部空间的维度问题。IEEE模式分析与机器智能汇刊，29(7):1262-1267, 2007。

B. Nadler, S. Lafon, R.R. Coifman, and I.G. Kevrekidis. Diffusion maps, spectral clustering and the reaction coordinates of dynamical systems. Applied and Computational Harmonic Analysis: Special Issue on Diffusion Maps and Wavelets, 21:113-127, 2006.

B. Nadler, S. Lafon, R.R. Coifman 和 I.G. Kevrekidis. 扩散映射、谱聚类与动力系统的反应坐标。应用与计算谐波分析:扩散映射与小波特刊，21:113-127, 2006。

S.A. Nene, S.K. Nayar, and H. Murase. Columbia Object Image Library (COIL-20). Technical Report CUCS-005-96, Columbia University, 1996.

S.A. Nene, S.K. Nayar 和 H. Murase. 哥伦比亚物体图像库(COIL-20)。技术报告 CUCS-005-96，哥伦比亚大学，1996。

S.T. Roweis and L.K. Saul. Nonlinear dimensionality reduction by Locally Linear Embedding. Science, 290(5500):2323-2326, 2000.

S.T. Roweis 和 L.K. Saul. 通过局部线性嵌入实现非线性降维。科学，290(5500):2323-2326, 2000。

J.W. Sammon. A nonlinear mapping for data structure analysis. IEEE Transactions on Computers, 18(5):401-409, 1969.

J.W. Sammon. 用于数据结构分析的非线性映射。IEEE计算机学报，18(5):401-409，1969年。

L. Song, A.J. Smola, K. Borgwardt, and A. Gretton. Colored Maximum Variance Unfolding. In Advances in Neural Information Processing Systems, volume 21 (in press), 2007.

L. Song, A.J. Smola, K. Borgwardt, 和 A. Gretton. 彩色最大方差展开。载于《神经信息处理系统进展》，第21卷(待出版)，2007年。

W.N. Street, W.H. Wolberg, and O.L. Mangasarian. Nuclear feature extraction for breast tumor diagnosis. In Proceedings of the IS&T/SPIE International Symposium on Electronic Imaging: Science and Technology, volume 1905, pages 861-870, 1993.

W.N. Street, W.H. Wolberg, 和 O.L. Mangasarian. 用于乳腺肿瘤诊断的细胞核特征提取。载于IS&T/SPIE国际电子成像科学与技术研讨会论文集，第1905卷，861-870页，1993年。

M. Szummer and T. Jaakkola. Partially labeled classification with Markov random walks. In Advances in Neural Information Processing Systems, volume 14, pages 945-952, 2001.

M. Szummer 和 T. Jaakkola. 带部分标记的分类与马尔可夫随机游走。载于《神经信息处理系统进展》，第14卷，945-952页，2001年。

J.B. Tenenbaum, V. de Silva, and J.C. Langford. A global geometric framework for nonlinear dimensionality reduction. Science, 290(5500):2319-2323, 2000.

J.B. Tenenbaum, V. de Silva, 和 J.C. Langford. 用于非线性降维的全局几何框架。科学，290(5500):2319-2323，2000年。

W.S. Torgerson. Multidimensional scaling I: Theory and method. Psychometrika, 17:401-419, 1952.

W.S. Torgerson. 多维尺度分析I:理论与方法。心理计量学，17:401-419，1952年。

L.J.P. van der Maaten, E.O. Postma, and H.J. van den Herik. Dimensionality reduction: A comparative review. Online Preprint, 2008.

L.J.P. van der Maaten, E.O. Postma, 和 H.J. van den Herik. 降维方法比较综述。在线预印本，2008年。

K.Q. Weinberger, F. Sha, and L.K. Saul. Learning a kernel matrix for nonlinear dimensionality reduction. In Proceedings of the ${21}^{\text{st }}$ International Confernence on Machine Learning,2004.

K.Q. Weinberger, F. Sha, 和 L.K. Saul. 学习核矩阵用于非线性降维。载于${21}^{\text{st }}$国际机器学习会议论文集，2004年。

K.Q. Weinberger, F. Sha, Q. Zhu, and L.K. Saul. Graph Laplacian regularization for large-scale semidefinite programming. In Advances in Neural Information Processing Systems, volume 19, 2007.

K.Q. Weinberger, F. Sha, Q. Zhu, 和 L.K. Saul. 用于大规模半正定规划的图拉普拉斯正则化(Graph Laplacian regularization)。发表于《神经信息处理系统进展》(Advances in Neural Information Processing Systems)，第19卷，2007年。

C.K.I. Williams. On a connection between Kernel PCA and metric multidimensional scaling. Machine Learning, 46(1-3):11-19, 2002.

C.K.I. Williams. 关于核主成分分析(Kernel PCA)与度量多维尺度分析(metric multidimensional scaling)之间的联系。机器学习(Machine Learning)，46(1-3):11-19，2002年。

X. Zhu, Z. Ghahramani, and J. Lafferty. Semi-supervised learning using Gaussian fields and harmonic functions. In Proceedings of the ${20}^{\text{th }}$ International Conference on Machine Learning, pages 912-919, 2003.

X. Zhu, Z. Ghahramani, 和 J. Lafferty. 使用高斯场和调和函数的半监督学习。发表于${20}^{\text{th }}$国际机器学习大会(International Conference on Machine Learning)论文集，页码912-919，2003年。