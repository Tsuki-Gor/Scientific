# Deep Residual Learning for Image Recognition

# 用于图像识别的深度残差学习

Kaiming He Xiangyu Zhang Shaoqing Ren Jian Sun

何凯明 张翔宇 任少卿 孙剑

Microsoft Research

微软研究院

\{kahe, v-xiangz, v-shren, jiansun\}@microsoft.com

\{kahe, v-xiangz, v-shren, jiansun\}@microsoft.com

## Abstract

## 摘要

Deeper neural networks are more difficult to train. We present a residual learning framework to ease the training of networks that are substantially deeper than those used previously. We explicitly reformulate the layers as learning residual functions with reference to the layer inputs, instead of learning unreferenced functions. We provide comprehensive empirical evidence showing that these residual networks are easier to optimize, and can gain accuracy from considerably increased depth. On the ImageNet dataset we evaluate residual nets with a depth of up to 152 layers $- 8 \times$ deeper than VGG nets [40] but still having lower complexity. An ensemble of these residual nets achieves 3.57% error on the ImageNet test set. This result won the 1st place on the ILSVRC 2015 classification task. We also present analysis on CIFAR-10 with 100 and 1000 layers.

更深的神经网络训练难度更大。我们提出了一种残差学习框架，以简化比以往更深网络的训练。我们明确地将各层重新表述为学习相对于层输入的残差函数，而非学习无参照的函数。我们提供了全面的实验证据，表明这些残差网络更易于优化，且能通过显著增加深度获得更高准确率。在ImageNet数据集上，我们评估了深度达152层的残差网络$- 8 \times$，比VGG网络[40]更深，但复杂度更低。这些残差网络的集成在ImageNet测试集上实现了3.57%的错误率。该结果获得了ILSVRC 2015分类任务的第一名。我们还对CIFAR-10数据集进行了100层和1000层的分析。

The depth of representations is of central importance for many visual recognition tasks. Solely due to our extremely deep representations, we obtain a 28% relative improvement on the COCO object detection dataset. Deep residual nets are foundations of our submissions to ILSVRC & COCO 2015 competitions ${}^{1}$ , where we also won the 1st places on the tasks of ImageNet detection, ImageNet localization, COCO detection, and COCO segmentation.

表示的深度对于许多视觉识别任务至关重要。仅凭我们极深的表示，在COCO目标检测数据集上实现了28%的相对提升。深度残差网络是我们参加ILSVRC和COCO 2015竞赛的基础${}^{1}$，我们在ImageNet检测、ImageNet定位、COCO检测和COCO分割任务中均获得了第一名。

## 1. Introduction

## 1. 引言

Deep convolutional neural networks [22, 21] have led to a series of breakthroughs for image classification [21, 49, 39]. Deep networks naturally integrate low/mid/high-level features [49] and classifiers in an end-to-end multilayer fashion, and the "levels" of features can be enriched by the number of stacked layers (depth). Recent evidence $\left\lbrack  {{40},{43}}\right\rbrack$ reveals that network depth is of crucial importance, and the leading results $\left\lbrack  {{40},{43},{12},{16}}\right\rbrack$ on the challenging ImageNet dataset [35] all exploit "very deep" [40] models, with a depth of sixteen [40] to thirty [16]. Many other nontrivial visual recognition tasks $\left\lbrack  {7,{11},6,{32},{27}}\right\rbrack$ have also

深度卷积神经网络[22, 21]推动了图像分类[21, 49, 39]的一系列突破。深度网络自然地以端到端多层方式整合低/中/高级特征[49]和分类器，且特征的“层级”可通过堆叠层数(深度)丰富。最新证据$\left\lbrack  {{40},{43}}\right\rbrack$表明网络深度至关重要，挑战性ImageNet数据集[35]上的领先成果$\left\lbrack  {{40},{43},{12},{16}}\right\rbrack$均采用“非常深”的模型[40]，深度从16层[40]到30层[16]不等。许多其他复杂的视觉识别任务$\left\lbrack  {7,{11},6,{32},{27}}\right\rbrack$也同样受益于此。

![bo_d1c3qi77aajc7389qet0_0_896_648_712_244_0.jpg](images/bo_d1c3qi77aajc7389qet0_0_896_648_712_244_0.jpg)

Figure 1. Training error (left) and test error (right) on CIFAR-10 with 20-layer and 56-layer "plain" networks. The deeper network has higher training error, and thus test error. Similar phenomena on ImageNet is presented in Fig. 4.

图1. CIFAR-10上20层和56层“普通”网络的训练误差(左)和测试误差(右)。更深的网络训练误差更高，测试误差也更高。ImageNet上的类似现象见图4。

## greatly benefited from very deep models.

## 极大地受益于非常深的模型。

Driven by the significance of depth, a question arises: Is learning better networks as easy as stacking more layers? An obstacle to answering this question was the notorious problem of vanishing/exploding gradients $\left\lbrack  {{14},1,8}\right\rbrack$ , which hamper convergence from the beginning. This problem, however, has been largely addressed by normalized initialization $\left\lbrack  {{23},8,{36},{12}}\right\rbrack$ and intermediate normalization layers [16], which enable networks with tens of layers to start converging for stochastic gradient descent (SGD) with back-propagation [22].

鉴于深度的重要性，问题随之而来:学习更好的网络是否仅仅是堆叠更多层那么简单？回答这一问题的障碍是臭名昭著的梯度消失/爆炸问题$\left\lbrack  {{14},1,8}\right\rbrack$，它从一开始就阻碍了收敛。然而，该问题已在很大程度上通过归一化初始化$\left\lbrack  {{23},8,{36},{12}}\right\rbrack$和中间归一化层[16]得到解决，这使得具有数十层的网络能够开始收敛，采用带反向传播的随机梯度下降(SGD)[22]。

When deeper networks are able to start converging, a degradation problem has been exposed: with the network depth increasing, accuracy gets saturated (which might be unsurprising) and then degrades rapidly. Unexpectedly, such degradation is not caused by overfitting, and adding more layers to a suitably deep model leads to higher training error, as reported in $\left\lbrack  {{10},{41}}\right\rbrack$ and thoroughly verified by our experiments. Fig. 1 shows a typical example.

当更深的网络能够开始收敛时，暴露出退化问题:随着网络深度增加，准确率先饱和(这可能不足为奇)，然后迅速下降。出乎意料的是，这种退化并非由过拟合引起，且在适当深度模型上增加更多层会导致更高的训练误差，正如$\left\lbrack  {{10},{41}}\right\rbrack$中报道并由我们的实验充分验证。图1展示了一个典型例子。

The degradation (of training accuracy) indicates that not all systems are similarly easy to optimize. Let us consider a shallower architecture and its deeper counterpart that adds more layers onto it. There exists a solution by construction to the deeper model: the added layers are identity mapping, and the other layers are copied from the learned shallower model. The existence of this constructed solution indicates that a deeper model should produce no higher training error than its shallower counterpart. But experiments show that our current solvers on hand are unable to find solutions that are comparably good or better than the constructed solution (or unable to do so in feasible time).

训练准确率的退化表明并非所有系统都同样易于优化。考虑一个较浅的架构及其更深的对应版本，后者在前者基础上增加了更多层。对更深模型存在一个构造解:新增层为恒等映射，其他层复制自已学得的较浅模型。该构造解的存在表明，更深模型的训练误差不应高于较浅模型。但实验显示，我们现有的求解器无法找到与该构造解同样好或更好的解(或无法在合理时间内做到)。

---

${}^{1}$ http://image-net.org/challenges/LSVRC/2015/ and http://mscoco.org/dataset/#detections-challenge2015.

${}^{1}$ http://image-net.org/challenges/LSVRC/2015/ 和 http://mscoco.org/dataset/#detections-challenge2015。

---

![bo_d1c3qi77aajc7389qet0_1_279_224_411_234_0.jpg](images/bo_d1c3qi77aajc7389qet0_1_279_224_411_234_0.jpg)

Figure 2. Residual learning: a building block.

图2. 残差学习:一个构建模块。

In this paper, we address the degradation problem by introducing a deep residual learning framework. Instead of hoping each few stacked layers directly fit a desired underlying mapping, we explicitly let these layers fit a residual mapping. Formally, denoting the desired underlying mapping as $\mathcal{H}\left( \mathbf{x}\right)$ , we let the stacked nonlinear layers fit another mapping of $\mathcal{F}\left( \mathbf{x}\right)  \mathrel{\text{:=}} \mathcal{H}\left( \mathbf{x}\right)  - \mathbf{x}$ . The original mapping is recast into $\mathcal{F}\left( \mathbf{x}\right)  + \mathbf{x}$ . We hypothesize that it is easier to optimize the residual mapping than to optimize the original, unreferenced mapping. To the extreme, if an identity mapping were optimal, it would be easier to push the residual to zero than to fit an identity mapping by a stack of nonlinear layers.

本文通过引入深度残差学习框架来解决退化问题。我们不再期望每几个堆叠的层直接拟合期望的底层映射，而是明确让这些层拟合一个残差映射。形式上，设期望的底层映射为$\mathcal{H}\left( \mathbf{x}\right)$，我们让堆叠的非线性层拟合另一个映射$\mathcal{F}\left( \mathbf{x}\right)  \mathrel{\text{:=}} \mathcal{H}\left( \mathbf{x}\right)  - \mathbf{x}$。原始映射被重新表述为$\mathcal{F}\left( \mathbf{x}\right)  + \mathbf{x}$。我们假设优化残差映射比优化原始的无参照映射更容易。极端情况下，如果恒等映射是最优的，那么将残差推向零比通过堆叠非线性层拟合恒等映射更容易。

The formulation of $\mathcal{F}\left( \mathbf{x}\right)  + \mathbf{x}$ can be realized by feedfor-ward neural networks with "shortcut connections" (Fig. 2). Shortcut connections $\left\lbrack  {2,{33},{48}}\right\rbrack$ are those skipping one or more layers. In our case, the shortcut connections simply perform identity mapping, and their outputs are added to the outputs of the stacked layers (Fig. 2). Identity shortcut connections add neither extra parameter nor computational complexity. The entire network can still be trained end-to-end by SGD with backpropagation, and can be easily implemented using common libraries (e.g., Caffe [19]) without modifying the solvers.

$\mathcal{F}\left( \mathbf{x}\right)  + \mathbf{x}$的形式可以通过带有“捷径连接”(shortcut connections)的前馈神经网络实现(图2)。捷径连接$\left\lbrack  {2,{33},{48}}\right\rbrack$是跳过一层或多层的连接。在我们的情况下，捷径连接简单地执行恒等映射，其输出与堆叠层的输出相加(图2)。恒等捷径连接既不增加额外参数，也不增加计算复杂度。整个网络仍可通过带反向传播的随机梯度下降(SGD)端到端训练，并且可以使用常见库(如Caffe [19])轻松实现，无需修改求解器。

We present comprehensive experiments on ImageNet [35] to show the degradation problem and evaluate our method. We show that: 1) Our extremely deep residual nets are easy to optimize, but the counterpart "plain" nets (that simply stack layers) exhibit higher training error when the depth increases; 2) Our deep residual nets can easily enjoy accuracy gains from greatly increased depth, producing results substantially better than previous networks.

我们在ImageNet [35]上进行了全面实验，以展示退化问题并评估我们的方法。结果表明:1)我们的极深残差网络易于优化，而对应的“普通”网络(简单堆叠层)随着深度增加训练误差反而更高；2)我们的深度残差网络能轻松从大幅增加的深度中获益，产生明显优于以往网络的结果。

Similar phenomena are also shown on the CIFAR-10 set [20], suggesting that the optimization difficulties and the effects of our method are not just akin to a particular dataset. We present successfully trained models on this dataset with over 100 layers, and explore models with over 1000 layers.

类似现象也在CIFAR-10数据集[20]上得到验证，表明优化难题及我们方法的效果并非特定于某一数据集。我们成功训练了超过100层的模型，并探索了超过1000层的模型。

On the ImageNet classification dataset [35], we obtain excellent results by extremely deep residual nets. Our 152- layer residual net is the deepest network ever presented on ImageNet, while still having lower complexity than VGG nets [40]. Our ensemble has ${3.57}\%$ top-5 error on the ImageNet test set, and won the 1st place in the ILSVRC 2015 classification competition. The extremely deep representations also have excellent generalization performance on other recognition tasks, and lead us to further win the 1st places on: ImageNet detection, ImageNet localization, COCO detection, and COCO segmentation in ILSVRC & COCO 2015 competitions. This strong evidence shows that the residual learning principle is generic, and we expect that it is applicable in other vision and non-vision problems.

在ImageNet分类数据集[35]上，我们通过极深残差网络取得了优异成绩。我们的152层残差网络是迄今为止ImageNet上提出的最深网络，同时复杂度低于VGG网络[40]。我们的集成模型在ImageNet测试集上实现了${3.57}\%$的top-5错误率，并赢得了ILSVRC 2015分类竞赛冠军。极深的表征在其他识别任务上也表现出卓越的泛化能力，使我们进一步获得ILSVRC和COCO 2015竞赛中的ImageNet检测、ImageNet定位、COCO检测和COCO分割的冠军。这一有力证据表明残差学习原理具有通用性，我们期望其能应用于其他视觉及非视觉问题。

## 2. Related Work

## 2. 相关工作

Residual Representations. In image recognition, VLAD [18] is a representation that encodes by the residual vectors with respect to a dictionary, and Fisher Vector [30] can be formulated as a probabilistic version [18] of VLAD. Both of them are powerful shallow representations for image retrieval and classification [4, 47]. For vector quantization, encoding residual vectors [17] is shown to be more effective than encoding original vectors.

残差表征。在图像识别中，VLAD [18]是一种通过相对于字典的残差向量进行编码的表征，Fisher向量[30]可被视为VLAD的概率版本[18]。它们都是用于图像检索和分类的强大浅层表征[4, 47]。在矢量量化中，编码残差向量[17]被证明比编码原始向量更有效。

In low-level vision and computer graphics, for solving Partial Differential Equations (PDEs), the widely used Multigrid method [3] reformulates the system as subproblems at multiple scales, where each subproblem is responsible for the residual solution between a coarser and a finer scale. An alternative to Multigrid is hierarchical basis preconditioning $\left\lbrack  {{44},{45}}\right\rbrack$ , which relies on variables that represent residual vectors between two scales. It has been shown $\left\lbrack  {3,{44},{45}}\right\rbrack$ that these solvers converge much faster than standard solvers that are unaware of the residual nature of the solutions. These methods suggest that a good reformulation or preconditioning can simplify the optimization.

在低级视觉和计算机图形学中，为了解决偏微分方程(PDEs)，广泛使用的多重网格方法[3]将系统重新表述为多尺度的子问题，每个子问题负责粗尺度与细尺度之间的残差解。多重网格的另一种方法是分层基预处理$\left\lbrack  {{44},{45}}\right\rbrack$，它依赖于表示两个尺度间残差向量的变量。已有研究表明$\left\lbrack  {3,{44},{45}}\right\rbrack$这些求解器的收敛速度远快于不考虑解的残差性质的标准求解器。这些方法表明，良好的重构或预处理可以简化优化过程。

Shortcut Connections. Practices and theories that lead to shortcut connections $\left\lbrack  {2,{33},{48}}\right\rbrack$ have been studied for a long time. An early practice of training multi-layer perceptrons (MLPs) is to add a linear layer connected from the network input to the output $\left\lbrack  {{33},{48}}\right\rbrack$ . In $\left\lbrack  {{43},{24}}\right\rbrack$ , a few intermediate layers are directly connected to auxiliary classifiers for addressing vanishing/exploding gradients. The papers of $\left\lbrack  {{38},{37},{31},{46}}\right\rbrack$ propose methods for centering layer responses, gradients, and propagated errors, implemented by shortcut connections. In [43], an "inception" layer is composed of a shortcut branch and a few deeper branches.

捷径连接。导致捷径连接的实践和理论已经被研究了很长时间。训练多层感知机(MLPs)的早期做法是添加一个从网络输入到输出的线性层。在$\left\lbrack  {{43},{24}}\right\rbrack$中，几个中间层直接连接到辅助分类器，以解决梯度消失/爆炸问题。$\left\lbrack  {{38},{37},{31},{46}}\right\rbrack$的论文提出了通过捷径连接实现的层响应、梯度和传播误差中心化的方法。在[43]中，“inception”层由一个捷径分支和几个更深的分支组成。

Concurrent with our work, "highway networks" [41, 42] present shortcut connections with gating functions [15]. These gates are data-dependent and have parameters, in contrast to our identity shortcuts that are parameter-free. When a gated shortcut is "closed" (approaching zero), the layers in highway networks represent non-residual functions. On the contrary, our formulation always learns residual functions; our identity shortcuts are never closed, and all information is always passed through, with additional residual functions to be learned. In addition, highway networks have not demonstrated accuracy gains with extremely increased depth (e.g., over 100 layers).

与我们的工作同时，“高速公路网络”(highway networks)[41, 42]提出了带有门控函数[15]的捷径连接。这些门控是依赖数据且具有参数的，与我们无参数的恒等捷径不同。当门控捷径“关闭”(趋近于零)时，高速公路网络中的层表示非残差函数。相反，我们的公式始终学习残差函数；我们的恒等捷径永远不会关闭，所有信息始终被传递，同时学习额外的残差函数。此外，高速公路网络在极深层(例如超过100层)并未展示出准确率提升。

## 3. Deep Residual Learning

## 3. 深度残差学习

### 3.1. Residual Learning

### 3.1. 残差学习

Let us consider $\mathcal{H}\left( \mathbf{x}\right)$ as an underlying mapping to be fit by a few stacked layers (not necessarily the entire net), with $\mathbf{x}$ denoting the inputs to the first of these layers. If one hypothesizes that multiple nonlinear layers can asymptotically approximate complicated functions ${}^{2}$ , then it is equivalent to hypothesize that they can asymptotically approximate the residual functions, i.e., $\mathcal{H}\left( \mathbf{x}\right)  - \mathbf{x}$ (assuming that the input and output are of the same dimensions). So rather than expect stacked layers to approximate $\mathcal{H}\left( \mathbf{x}\right)$ , we explicitly let these layers approximate a residual function $\mathcal{F}\left( \mathbf{x}\right)  \mathrel{\text{:=}} \mathcal{H}\left( \mathbf{x}\right)  - \mathbf{x}$ . The original function thus becomes $\mathcal{F}\left( \mathbf{x}\right)  + \mathbf{x}$ . Although both forms should be able to asymptotically approximate the desired functions (as hypothesized), the ease of learning might be different.

设$\mathcal{H}\left( \mathbf{x}\right)$为由若干堆叠层(不一定是整个网络)拟合的底层映射，$\mathbf{x}$表示这些层中第一层的输入。如果假设多个非线性层可以渐近地逼近复杂函数${}^{2}$，那么等价于假设它们可以渐近地逼近残差函数，即$\mathcal{H}\left( \mathbf{x}\right)  - \mathbf{x}$(假设输入和输出维度相同)。因此，我们不期望堆叠层直接逼近$\mathcal{H}\left( \mathbf{x}\right)$，而是明确让这些层逼近残差函数$\mathcal{F}\left( \mathbf{x}\right)  \mathrel{\text{:=}} \mathcal{H}\left( \mathbf{x}\right)  - \mathbf{x}$。原始函数因此变为$\mathcal{F}\left( \mathbf{x}\right)  + \mathbf{x}$。虽然这两种形式理论上都能渐近逼近目标函数，但学习的难易程度可能不同。

This reformulation is motivated by the counterintuitive phenomena about the degradation problem (Fig. 1, left). As we discussed in the introduction, if the added layers can be constructed as identity mappings, a deeper model should have training error no greater than its shallower counterpart. The degradation problem suggests that the solvers might have difficulties in approximating identity mappings by multiple nonlinear layers. With the residual learning reformulation, if identity mappings are optimal, the solvers may simply drive the weights of the multiple nonlinear layers toward zero to approach identity mappings.

这种重新表述的动机源于关于退化问题的反直觉现象(图1，左)。如引言所述，如果新增层可以构造为恒等映射，更深的模型的训练误差不应大于较浅模型。退化问题表明求解器可能难以通过多个非线性层逼近恒等映射。通过残差学习的重新表述，如果恒等映射是最优的，求解器可以简单地将多个非线性层的权重驱动为零，从而接近恒等映射。

In real cases, it is unlikely that identity mappings are optimal, but our reformulation may help to precondition the problem. If the optimal function is closer to an identity mapping than to a zero mapping, it should be easier for the solver to find the perturbations with reference to an identity mapping, than to learn the function as a new one. We show by experiments (Fig. 7) that the learned residual functions in general have small responses, suggesting that identity mappings provide reasonable preconditioning.

在实际情况下，恒等映射不太可能是最优的，但我们的重新表述可能有助于预处理问题。如果最优函数更接近恒等映射而非零映射，求解器找到相对于恒等映射的扰动会比学习一个全新函数更容易。我们通过实验(图7)展示，学习到的残差函数通常响应较小，表明恒等映射提供了合理的预处理。

### 3.2. Identity Mapping by Shortcuts

### 3.2. 通过捷径实现恒等映射

We adopt residual learning to every few stacked layers. A building block is shown in Fig. 2. Formally, in this paper we consider a building block defined as:

我们将残差学习应用于每几个堆叠层。一个构建模块如图2所示。形式上，本文考虑的构建模块定义为:

$$
\mathbf{y} = \mathcal{F}\left( {\mathbf{x},\left\{  {W}_{i}\right\}  }\right)  + \mathbf{x}. \tag{1}
$$

Here $\mathbf{x}$ and $\mathbf{y}$ are the input and output vectors of the layers considered. The function $\mathcal{F}\left( {\mathbf{x},\left\{  {W}_{i}\right\}  }\right)$ represents the residual mapping to be learned. For the example in Fig. 2 that has two layers, $\mathcal{F} = {W}_{2}\sigma \left( {{W}_{1}\mathbf{x}}\right)$ in which $\sigma$ denotes ReLU [29] and the biases are omitted for simplifying notations. The operation $\mathcal{F} + \mathbf{x}$ is performed by a shortcut connection and element-wise addition. We adopt the second nonlinearity after the addition (i.e., $\sigma \left( \mathbf{y}\right)$ , see Fig. 2).

这里的$\mathbf{x}$和$\mathbf{y}$是所考虑层的输入和输出向量。函数$\mathcal{F}\left( {\mathbf{x},\left\{  {W}_{i}\right\}  }\right)$表示要学习的残差映射。以图2中具有两层的示例为例，$\mathcal{F} = {W}_{2}\sigma \left( {{W}_{1}\mathbf{x}}\right)$，其中$\sigma$表示ReLU [29]，偏置项为简化符号省略。操作$\mathcal{F} + \mathbf{x}$由捷径连接和逐元素相加完成。我们在相加后采用第二个非线性激活(即$\sigma \left( \mathbf{y}\right)$，见图2)。

The shortcut connections in Eqn.(1) introduce neither extra parameter nor computation complexity. This is not only attractive in practice but also important in our comparisons between plain and residual networks. We can fairly compare plain/residual networks that simultaneously have the same number of parameters, depth, width, and computational cost (except for the negligible element-wise addition).

方程(1)中的捷径连接既不引入额外参数，也不增加计算复杂度。这不仅在实际应用中具有吸引力，而且在我们对比普通网络和平衡残差网络时也非常重要。我们可以公平地比较具有相同参数数量、深度、宽度和计算成本(除去可忽略的逐元素相加)的普通网络与残差网络。

The dimensions of $\mathbf{x}$ and $\mathcal{F}$ must be equal in Eqn.(1). If this is not the case (e.g., when changing the input/output channels), we can perform a linear projection ${W}_{s}$ by the shortcut connections to match the dimensions:

方程(1)中$\mathbf{x}$和$\mathcal{F}$的维度必须相等。如果不相等(例如改变输入/输出通道数时)，我们可以通过捷径连接执行线性投影${W}_{s}$以匹配维度:

$$
\mathbf{y} = \mathcal{F}\left( {\mathbf{x},\left\{  {W}_{i}\right\}  }\right)  + {W}_{s}\mathbf{x}. \tag{2}
$$

We can also use a square matrix ${W}_{s}$ in Eqn.(1). But we will show by experiments that the identity mapping is sufficient for addressing the degradation problem and is economical, and thus ${W}_{s}$ is only used when matching dimensions.

我们也可以在方程(1)中使用方阵${W}_{s}$。但实验将表明，恒等映射(identity mapping)足以解决退化问题且更为经济，因此${W}_{s}$仅在匹配维度时使用。

The form of the residual function $\mathcal{F}$ is flexible. Experiments in this paper involve a function $\mathcal{F}$ that has two or three layers (Fig. 5), while more layers are possible. But if $\mathcal{F}$ has only a single layer, Eqn.(1) is similar to a linear layer: $\mathbf{y} = {W}_{1}\mathbf{x} + \mathbf{x}$ , for which we have not observed advantages.

残差函数$\mathcal{F}$的形式是灵活的。本文的实验涉及具有两层或三层的函数$\mathcal{F}$(见图5)，当然也可以有更多层。但如果$\mathcal{F}$仅有单层，方程(1)类似于线性层:$\mathbf{y} = {W}_{1}\mathbf{x} + \mathbf{x}$，我们未观察到其优势。

We also note that although the above notations are about fully-connected layers for simplicity, they are applicable to convolutional layers. The function $\mathcal{F}\left( {\mathbf{x},\left\{  {W}_{i}\right\}  }\right)$ can represent multiple convolutional layers. The element-wise addition is performed on two feature maps, channel by channel.

我们还注意到，尽管上述符号为简化起见针对全连接层，但它们同样适用于卷积层。函数$\mathcal{F}\left( {\mathbf{x},\left\{  {W}_{i}\right\}  }\right)$可以表示多个卷积层。逐元素相加在两个特征图的对应通道间进行。

### 3.3. Network Architectures

### 3.3. 网络架构

We have tested various plain/residual nets, and have observed consistent phenomena. To provide instances for discussion, we describe two models for ImageNet as follows.

我们测试了多种普通网络与残差网络，并观察到一致的现象。为便于讨论，以下描述两个用于ImageNet的模型实例。

Plain Network. Our plain baselines (Fig. 3, middle) are mainly inspired by the philosophy of VGG nets [40] (Fig. 3, left). The convolutional layers mostly have $3 \times  3$ filters and follow two simple design rules: (i) for the same output feature map size, the layers have the same number of filters; and (ii) if the feature map size is halved, the number of filters is doubled so as to preserve the time complexity per layer. We perform downsampling directly by convolutional layers that have a stride of 2 . The network ends with a global average pooling layer and a 1000-way fully-connected layer with softmax. The total number of weighted layers is 34 in Fig. 3 (middle).

普通网络。我们的普通基线(图3中间)主要受VGG网络[40](图3左)设计理念启发。卷积层大多具有$3 \times  3$个滤波器，并遵循两个简单设计规则:(i) 对于相同输出特征图尺寸，层具有相同数量的滤波器；(ii) 若特征图尺寸减半，滤波器数量加倍，以保持每层的时间复杂度。我们通过步幅为2的卷积层直接进行下采样。网络以全局平均池化层和一个1000类的全连接层(softmax)结束。图3中间的加权层总数为34层。

It is worth noticing that our model has fewer filters and lower complexity than VGG nets [40] (Fig. 3, left). Our 34- layer baseline has 3.6 billion FLOPs (multiply-adds), which is only 18% of VGG-19 (19.6 billion FLOPs).

值得注意的是，我们的模型滤波器数量更少，复杂度低于VGG网络[40](图3左)。我们的34层基线模型有36亿次浮点运算(FLOPs，乘加运算)，仅为VGG-19(196亿FLOPs)的18%。

---

${}^{2}$ This hypothesis, however, is still an open question. See [28].

${}^{2}$ 然而，这一假设仍是一个开放问题。详见[28]。

---

![bo_d1c3qi77aajc7389qet0_3_129_207_720_1617_0.jpg](images/bo_d1c3qi77aajc7389qet0_3_129_207_720_1617_0.jpg)

Figure 3. Example network architectures for ImageNet. Left: the VGG-19 model [40] (19.6 billion FLOPs) as a reference. Middle: a plain network with 34 parameter layers (3.6 billion FLOPs). Right: a residual network with 34 parameter layers (3.6 billion FLOPs). The dotted shortcuts increase dimensions. Table 1 shows more details and other variants.

图3. ImageNet的示例网络架构。左:作为参考的VGG-19模型[40](196亿FLOPs)。中:具有34个参数层的普通网络(36亿FLOPs)。右:具有34个参数层的残差网络(36亿FLOPs)。虚线捷径表示维度增加。表1展示了更多细节及其他变体。

Residual Network. Based on the above plain network, we insert shortcut connections (Fig. 3, right) which turn the network into its counterpart residual version. The identity shortcuts (Eqn.(1)) can be directly used when the input and output are of the same dimensions (solid line shortcuts in Fig. 3). When the dimensions increase (dotted line shortcuts in Fig. 3), we consider two options: (A) The shortcut still performs identity mapping, with extra zero entries padded for increasing dimensions. This option introduces no extra parameter; (B) The projection shortcut in Eqn.(2) is used to match dimensions (done by $1 \times  1$ convolutions). For both options, when the shortcuts go across feature maps of two sizes, they are performed with a stride of 2 .

残差网络。基于上述的普通网络，我们插入了快捷连接(图3，右侧)，将网络转变为对应的残差版本。当输入和输出维度相同时，可以直接使用恒等快捷连接(公式(1))(图3中的实线快捷连接)。当维度增加时(图3中的虚线快捷连接)，我们考虑两种方案:(A)快捷连接仍执行恒等映射，增加维度时用零填充，不引入额外参数；(B)使用公式(2)中的投影快捷连接以匹配维度(通过$1 \times  1$卷积实现)。对于这两种方案，当快捷连接跨越两个尺寸的特征图时，步幅为2。

### 3.4. Implementation

### 3.4. 实现细节

Our implementation for ImageNet follows the practice in $\left\lbrack  {{21},{40}}\right\rbrack$ . The image is resized with its shorter side randomly sampled in $\left\lbrack  {{256},{480}}\right\rbrack$ for scale augmentation [40]. A ${224} \times  {224}$ crop is randomly sampled from an image or its horizontal flip, with the per-pixel mean subtracted [21]. The standard color augmentation in [21] is used. We adopt batch normalization (BN) [16] right after each convolution and before activation, following [16]. We initialize the weights as in [12] and train all plain/residual nets from scratch. We use SGD with a mini-batch size of 256 . The learning rate starts from 0.1 and is divided by 10 when the error plateaus, and the models are trained for up to ${60} \times  {10}^{4}$ iterations. We use a weight decay of 0.0001 and a momentum of 0.9 . We do not use dropout [13], following the practice in [16].

我们在ImageNet上的实现遵循$\left\lbrack  {{21},{40}}\right\rbrack$中的做法。图像的短边长度随机采样于$\left\lbrack  {{256},{480}}\right\rbrack$范围内以进行尺度增强[40]。从图像或其水平翻转中随机裁剪出${224} \times  {224}$大小的区域，并减去每像素均值[21]。采用[21]中的标准颜色增强。我们在每个卷积层后、激活前采用批量归一化(BN)[16]，遵循[16]。权重初始化采用[12]的方法，所有普通/残差网络均从头训练。使用小批量大小为256的SGD，初始学习率为0.1，当误差停滞时学习率降低10倍，训练最多进行${60} \times  {10}^{4}$次迭代。权重衰减为0.0001，动量为0.9。遵循[16]的做法，不使用dropout[13]。

In testing, for comparison studies we adopt the standard 10-crop testing [21]. For best results, we adopt the fully-convolutional form as in $\left\lbrack  {{40},{12}}\right\rbrack$ , and average the scores at multiple scales (images are resized such that the shorter side is in $\{ {224},{256},{384},{480},{640}\} )$ .

测试时，为了比较研究，我们采用标准的10裁剪测试[21]。为获得最佳结果，采用$\left\lbrack  {{40},{12}}\right\rbrack$中的全卷积形式，并在多个尺度下对得分取平均(图像短边尺寸调整至$\{ {224},{256},{384},{480},{640}\} )$范围内)。

## 4. Experiments

## 4. 实验

### 4.1. ImageNet Classification

### 4.1. ImageNet分类

We evaluate our method on the ImageNet 2012 classification dataset [35] that consists of 1000 classes. The models are trained on the 1.28 million training images, and evaluated on the ${50}\mathrm{k}$ validation images. We also obtain a final result on the ${100}\mathrm{k}$ test images, reported by the test server. We evaluate both top-1 and top-5 error rates.

我们在包含1000个类别的ImageNet 2012分类数据集[35]上评估我们的方法。模型在128万张训练图像上训练，并在${50}\mathrm{k}$验证图像上评估。最终结果在由测试服务器报告的${100}\mathrm{k}$测试图像上获得。我们评估top-1和top-5错误率。

Plain Networks. We first evaluate 18-layer and 34-layer plain nets. The 34-layer plain net is in Fig. 3 (middle). The 18-layer plain net is of a similar form. See Table 1 for detailed architectures.

普通网络。我们首先评估18层和34层的普通网络。34层普通网络如图3(中间)所示。18层普通网络结构类似。详细架构见表1。

The results in Table 2 show that the deeper 34-layer plain net has higher validation error than the shallower 18-layer plain net. To reveal the reasons, in Fig. 4 (left) we compare their training/validation errors during the training procedure. We have observed the degradation problem - the 34-layer plain net has higher training error throughout the whole training procedure, even though the solution space of the 18-layer plain network is a subspace of that of the 34-layer one.

表2中的结果显示，较深的34层普通网络验证误差高于较浅的18层普通网络。为揭示原因，在图4(左)中我们比较了它们训练过程中的训练/验证误差。我们观察到退化问题——34层普通网络在整个训练过程中训练误差均高于18层网络，尽管18层普通网络的解空间是34层网络解空间的子集。

<table><tr><td>layer name</td><td>output size</td><td>18-layer</td><td>34-layer</td><td>50-layer</td><td>101-layer</td><td colspan="2">152-layer</td></tr><tr><td>conv1</td><td>${112} \times  {112}$</td><td colspan="6">$7 \times  7,{64}$ , stride 2</td></tr><tr><td rowspan="2">conv2_x</td><td rowspan="2">${56} \times  {56}$</td><td colspan="6">$3 \times  3$ max pool, stride 2</td></tr><tr><td>$\left\lbrack  \begin{array}{l} 3 \times  3,{64} \\  3 \times  3,{64} \end{array}\right\rbrack   \times  2$</td><td>$\left\lbrack  \begin{array}{l} 3 \times  3,{64} \\  3 \times  3,{64} \end{array}\right\rbrack   \times  3$</td><td>$1 \times  1,{64}$ $3 \times  3,{64}$ $\times  3$ $1 \times  1,{256}$</td><td>$1 \times  1,{64}$ $3 \times  3,{64}$ $\times  3$ $1 \times  1,{256}$</td><td>$1 \times  1,{64}$ $3 \times  3,{64}$ $1 \times  1,{256}$</td><td>$\times  3$</td></tr><tr><td>conv3_x</td><td>${28} \times  {28}$</td><td>$\left\lbrack  \begin{array}{l} 3 \times  3,{128} \\  3 \times  3,{128} \end{array}\right\rbrack   \times  2$</td><td>$\left\lbrack  \begin{array}{l} 3 \times  3,{128} \\  3 \times  3,{128} \end{array}\right\rbrack   \times  4$</td><td>$1 \times  1,{128}$ $3 \times  3,{128}$ ✘4 $1 \times  1,{512}$</td><td>$1 \times  1,{128}$ $3 \times  3,{128}$ $\times  4$ $1 \times  1,{512}$</td><td>$1 \times  1,{128}$ $3 \times  3,{128}$ $1 \times  1,{512}$</td><td>$\times  8$</td></tr><tr><td>conv4_x</td><td>${14} \times  {14}$</td><td>$\left\lbrack  \begin{array}{l} 3 \times  3,{256} \\  3 \times  3,{256} \end{array}\right\rbrack   \times  2$</td><td>$\left\lbrack  \begin{array}{l} 3 \times  3,{256} \\  3 \times  3,{256} \end{array}\right\rbrack   \times  6$</td><td>$1 \times  1,{256}$ $3 \times  3,{256}$ $\times  6$ $1 \times  1,{1024}$</td><td>$1 \times  1,{256}$ $3 \times  3,{256}$ $\times  {23}$ $1 \times  1,{1024}$</td><td>$1 \times  1,{256}$ $3 \times  3,{256}$ $1 \times  1,{1024}$</td><td>$\times  {36}$</td></tr><tr><td>conv5_x</td><td>$7 \times  7$</td><td>$\left\lbrack  \begin{array}{l} 3 \times  3,{512} \\  3 \times  3,{512} \end{array}\right\rbrack   \times  2$</td><td>$\left\lbrack  \begin{matrix} 3 \times  3,{512} \\  3 \times  3,{512} \end{matrix}\right\rbrack   \times  3$</td><td>$1 \times  1,{512}$ $3 \times  3,{512}$ ✘3 $1 \times  1,{2048}$</td><td>$1 \times  1,{512}$ $3 \times  3,{512}$ $\times  3$ $1 \times  1,{2048}$</td><td>$1 \times  1,{512}$ $3 \times  3,{512}$ $1 \times  1,{2048}$</td><td>$\times  3$</td></tr><tr><td/><td>$1 \times  1$</td><td colspan="6">average pool, 1000-d fc, softmax</td></tr><tr><td colspan="2">FLOPs</td><td>${1.8} \times  {10}^{9}$</td><td>${3.6} \times  {10}^{9}$</td><td>${3.8} \times  {10}^{9}$</td><td>${7.6} \times  {10}^{9}$</td><td colspan="2">${11.3} \times  {10}^{9}$</td></tr></table>

<table><tbody><tr><td>层名称</td><td>输出尺寸</td><td>18层</td><td>34层</td><td>50层</td><td>101层</td><td colspan="2">152层</td></tr><tr><td>卷积1</td><td>${112} \times  {112}$</td><td colspan="6">$7 \times  7,{64}$ ，步幅2</td></tr><tr><td rowspan="2">卷积2_x</td><td rowspan="2">${56} \times  {56}$</td><td colspan="6">$3 \times  3$ 最大池化，步幅2</td></tr><tr><td>$\left\lbrack  \begin{array}{l} 3 \times  3,{64} \\  3 \times  3,{64} \end{array}\right\rbrack   \times  2$</td><td>$\left\lbrack  \begin{array}{l} 3 \times  3,{64} \\  3 \times  3,{64} \end{array}\right\rbrack   \times  3$</td><td>$1 \times  1,{64}$ $3 \times  3,{64}$ $\times  3$ $1 \times  1,{256}$</td><td>$1 \times  1,{64}$ $3 \times  3,{64}$ $\times  3$ $1 \times  1,{256}$</td><td>$1 \times  1,{64}$ $3 \times  3,{64}$ $1 \times  1,{256}$</td><td>$\times  3$</td></tr><tr><td>卷积3_x</td><td>${28} \times  {28}$</td><td>$\left\lbrack  \begin{array}{l} 3 \times  3,{128} \\  3 \times  3,{128} \end{array}\right\rbrack   \times  2$</td><td>$\left\lbrack  \begin{array}{l} 3 \times  3,{128} \\  3 \times  3,{128} \end{array}\right\rbrack   \times  4$</td><td>$1 \times  1,{128}$ $3 \times  3,{128}$ ✘4 $1 \times  1,{512}$</td><td>$1 \times  1,{128}$ $3 \times  3,{128}$ $\times  4$ $1 \times  1,{512}$</td><td>$1 \times  1,{128}$ $3 \times  3,{128}$ $1 \times  1,{512}$</td><td>$\times  8$</td></tr><tr><td>卷积4_x</td><td>${14} \times  {14}$</td><td>$\left\lbrack  \begin{array}{l} 3 \times  3,{256} \\  3 \times  3,{256} \end{array}\right\rbrack   \times  2$</td><td>$\left\lbrack  \begin{array}{l} 3 \times  3,{256} \\  3 \times  3,{256} \end{array}\right\rbrack   \times  6$</td><td>$1 \times  1,{256}$ $3 \times  3,{256}$ $\times  6$ $1 \times  1,{1024}$</td><td>$1 \times  1,{256}$ $3 \times  3,{256}$ $\times  {23}$ $1 \times  1,{1024}$</td><td>$1 \times  1,{256}$ $3 \times  3,{256}$ $1 \times  1,{1024}$</td><td>$\times  {36}$</td></tr><tr><td>卷积5_x</td><td>$7 \times  7$</td><td>$\left\lbrack  \begin{array}{l} 3 \times  3,{512} \\  3 \times  3,{512} \end{array}\right\rbrack   \times  2$</td><td>$\left\lbrack  \begin{matrix} 3 \times  3,{512} \\  3 \times  3,{512} \end{matrix}\right\rbrack   \times  3$</td><td>$1 \times  1,{512}$ $3 \times  3,{512}$ ✘3 $1 \times  1,{2048}$</td><td>$1 \times  1,{512}$ $3 \times  3,{512}$ $\times  3$ $1 \times  1,{2048}$</td><td>$1 \times  1,{512}$ $3 \times  3,{512}$ $1 \times  1,{2048}$</td><td>$\times  3$</td></tr><tr><td></td><td>$1 \times  1$</td><td colspan="6">平均池化，1000维全连接，softmax</td></tr><tr><td colspan="2">浮点运算次数(FLOPs)</td><td>${1.8} \times  {10}^{9}$</td><td>${3.6} \times  {10}^{9}$</td><td>${3.8} \times  {10}^{9}$</td><td>${7.6} \times  {10}^{9}$</td><td colspan="2">${11.3} \times  {10}^{9}$</td></tr></tbody></table>

Table 1. Architectures for ImageNet. Building blocks are shown in brackets (see also Fig. 5), with the numbers of blocks stacked. Down-sampling is performed by conv ${3}_{ - }1$ , conv ${4}_{ - }1$ , and conv ${5}_{ - }1$ with a stride of 2 .

表1. ImageNet的架构。构建模块用括号表示(参见图5)，括号内数字表示堆叠的模块数量。下采样由步幅为2的conv ${3}_{ - }1$、conv ${4}_{ - }1$和conv ${5}_{ - }1$完成。

![bo_d1c3qi77aajc7389qet0_4_242_734_1271_415_0.jpg](images/bo_d1c3qi77aajc7389qet0_4_242_734_1271_415_0.jpg)

Figure 4. Training on ImageNet. Thin curves denote training error, and bold curves denote validation error of the center crops. Left: plain networks of 18 and 34 layers. Right: ResNets of 18 and 34 layers. In this plot, the residual networks have no extra parameter compared to their plain counterparts.

图4. 在ImageNet上的训练。细曲线表示训练误差，粗曲线表示中心裁剪的验证误差。左图:18层和34层的普通网络。右图:18层和34层的残差网络(ResNet)。在此图中，残差网络相比普通网络没有额外参数。

<table><tr><td/><td>plain</td><td>ResNet</td></tr><tr><td>18 layers</td><td>27.94</td><td>27.88</td></tr><tr><td>34 layers</td><td>28.54</td><td>25.03</td></tr></table>

<table><tbody><tr><td></td><td>普通</td><td>残差网络(ResNet)</td></tr><tr><td>18层</td><td>27.94</td><td>27.88</td></tr><tr><td>34层</td><td>28.54</td><td>25.03</td></tr></tbody></table>

Table 2. Top-1 error (%, 10-crop testing) on ImageNet validation. Here the ResNets have no extra parameter compared to their plain counterparts. Fig. 4 shows the training procedures.

表2. ImageNet验证集上的Top-1错误率(%，10裁剪测试)。这里的ResNet相比其普通网络没有额外参数。图4展示了训练过程。

We argue that this optimization difficulty is unlikely to be caused by vanishing gradients. These plain networks are trained with BN [16], which ensures forward propagated signals to have non-zero variances. We also verify that the backward propagated gradients exhibit healthy norms with BN. So neither forward nor backward signals vanish. In fact, the 34-layer plain net is still able to achieve competitive accuracy (Table 3), suggesting that the solver works to some extent. We conjecture that the deep plain nets may have exponentially low convergence rates, which impact the reducing of the training error ${}^{3}$ . The reason for such optimization difficulties will be studied in the future.

我们认为这种优化困难不太可能由梯度消失引起。这些普通网络使用了BN(批归一化)[16]，确保前向传播信号具有非零方差。我们还验证了在BN下反向传播的梯度范数是健康的。因此，前向和反向信号都没有消失。事实上，34层的普通网络仍能达到有竞争力的准确率(表3)，表明求解器在一定程度上是有效的。我们推测深层普通网络可能存在指数级低的收敛速率，影响训练误差的降低${}^{3}$。这种优化困难的原因将在未来研究。

Residual Networks. Next we evaluate 18-layer and 34- layer residual nets (ResNets). The baseline architectures are the same as the above plain nets, expect that a shortcut connection is added to each pair of $3 \times  3$ filters as in Fig. 3 (right). In the first comparison (Table 2 and Fig. 4 right), we use identity mapping for all shortcuts and zero-padding for increasing dimensions (option A). So they have no extra parameter compared to the plain counterparts.

残差网络。接下来我们评估18层和34层的残差网络(ResNet)。基线架构与上述普通网络相同，只是在每对$3 \times  3$滤波器之间添加了如图3(右)所示的捷径连接。在首次比较中(表2和图4右)，我们对所有捷径使用恒等映射，对维度增加采用零填充(选项A)。因此，它们相比普通网络没有额外参数。

We have three major observations from Table 2 and Fig. 4. First, the situation is reversed with residual learning - the 34-layer ResNet is better than the 18-layer ResNet (by 2.8%). More importantly, the 34-layer ResNet exhibits considerably lower training error and is generalizable to the validation data. This indicates that the degradation problem is well addressed in this setting and we manage to obtain accuracy gains from increased depth.

我们从表2和图4中得到三个主要观察结果。首先，残差学习使情况逆转——34层ResNet优于18层ResNet(提升2.8%)。更重要的是，34层ResNet表现出显著更低的训练误差，并且对验证数据具有良好的泛化能力。这表明在此设置下退化问题得到有效解决，我们成功从加深网络深度中获得了准确率提升。

Second, compared to its plain counterpart, the 34-layer ResNet reduces the top-1 error by 3.5% (Table 2), resulting from the successfully reduced training error (Fig. 4 right vs. left). This comparison verifies the effectiveness of residual learning on extremely deep systems.

其次，与其普通网络对应版本相比，34层ResNet将Top-1错误率降低了3.5%(表2)，这得益于训练误差的成功降低(图4右对比左)。这一对比验证了残差学习在极深网络中的有效性。

---

${}^{3}$ We have experimented with more training iterations $\left( {3 \times  }\right)$ and still observed the degradation problem, suggesting that this problem cannot be feasibly addressed by simply using more iterations.

${}^{3}$ 我们尝试了更多的训练迭代$\left( {3 \times  }\right)$，仍然观察到退化问题，表明仅通过增加迭代次数无法切实解决该问题。

---

<table><tr><td>model</td><td>top-1 err.</td><td>top-5 err.</td></tr><tr><td>VGG-16 [40]</td><td>28.07</td><td>9.33</td></tr><tr><td>GoogLeNet [43]</td><td>-</td><td>9.15</td></tr><tr><td>PReLU-net [12]</td><td>24.27</td><td>7.38</td></tr><tr><td>plain-34</td><td>28.54</td><td>10.02</td></tr><tr><td>ResNet-34 A</td><td>25.03</td><td>7.76</td></tr><tr><td>ResNet-34 B</td><td>24.52</td><td>7.46</td></tr><tr><td>ResNet-34 C</td><td>24.19</td><td>7.40</td></tr><tr><td>ResNet-50</td><td>22.85</td><td>6.71</td></tr><tr><td>ResNet-101</td><td>21.75</td><td>6.05</td></tr><tr><td>ResNet-152</td><td>21.43</td><td>5.71</td></tr></table>

<table><tbody><tr><td>模型</td><td>Top-1 错误率</td><td>Top-5 错误率</td></tr><tr><td>VGG-16 [40]</td><td>28.07</td><td>9.33</td></tr><tr><td>GoogLeNet [43]</td><td>-</td><td>9.15</td></tr><tr><td>PReLU-net [12]</td><td>24.27</td><td>7.38</td></tr><tr><td>plain-34</td><td>28.54</td><td>10.02</td></tr><tr><td>ResNet-34 A</td><td>25.03</td><td>7.76</td></tr><tr><td>ResNet-34 B</td><td>24.52</td><td>7.46</td></tr><tr><td>ResNet-34 C</td><td>24.19</td><td>7.40</td></tr><tr><td>ResNet-50</td><td>22.85</td><td>6.71</td></tr><tr><td>ResNet-101</td><td>21.75</td><td>6.05</td></tr><tr><td>ResNet-152</td><td>21.43</td><td>5.71</td></tr></tbody></table>

Table 3. Error rates (%, 10-crop testing) on ImageNet validation. VGG-16 is based on our test. ResNet-50/101/152 are of option B that only uses projections for increasing dimensions.

表3. ImageNet验证集上的错误率(%，10裁剪测试)。VGG-16基于我们的测试。ResNet-50/101/152采用选项B，仅在维度增加时使用投影。

<table><tr><td>method</td><td>top-1 err.</td><td>top-5 err.</td></tr><tr><td>VGG [40] (ILSVRC’14)</td><td>-</td><td>${8.43}^{ \dagger  }$</td></tr><tr><td>GoogLeNet [43] (ILSVRC'14)</td><td>-</td><td>7.89</td></tr><tr><td>VGG [40] (v5)</td><td>24.4</td><td>7.1</td></tr><tr><td>PReLU-net [12]</td><td>21.59</td><td>5.71</td></tr><tr><td>BN-inception [16]</td><td>21.99</td><td>5.81</td></tr><tr><td>ResNet-34 B</td><td>21.84</td><td>5.71</td></tr><tr><td>ResNet-34 C</td><td>21.53</td><td>5.60</td></tr><tr><td>ResNet-50</td><td>20.74</td><td>5.25</td></tr><tr><td>ResNet-101</td><td>19.87</td><td>4.60</td></tr><tr><td>ResNet-152</td><td>19.38</td><td>4.49</td></tr></table>

<table><tbody><tr><td>方法</td><td>top-1 错误率</td><td>top-5 错误率</td></tr><tr><td>VGG [40] (ILSVRC’14)</td><td>-</td><td>${8.43}^{ \dagger  }$</td></tr><tr><td>GoogLeNet [43] (ILSVRC'14)</td><td>-</td><td>7.89</td></tr><tr><td>VGG [40] (v5)</td><td>24.4</td><td>7.1</td></tr><tr><td>PReLU-net [12]</td><td>21.59</td><td>5.71</td></tr><tr><td>BN-inception [16]</td><td>21.99</td><td>5.81</td></tr><tr><td>ResNet-34 B</td><td>21.84</td><td>5.71</td></tr><tr><td>ResNet-34 C</td><td>21.53</td><td>5.60</td></tr><tr><td>ResNet-50</td><td>20.74</td><td>5.25</td></tr><tr><td>ResNet-101</td><td>19.87</td><td>4.60</td></tr><tr><td>ResNet-152</td><td>19.38</td><td>4.49</td></tr></tbody></table>

Table 4. Error rates (%) of single-model results on the ImageNet validation set (except ${}^{ \dagger  }$ reported on the test set).

表4. 单模型在ImageNet验证集上的错误率(%)(除${}^{ \dagger  }$外，均在测试集上报告)。

<table><tr><td>method</td><td>top-5 err. (test)</td></tr><tr><td>VGG [40] (ILSVRC’14)</td><td>7.32</td></tr><tr><td>GoogLeNet [43] (ILSVRC’14)</td><td>6.66</td></tr><tr><td>VGG [40] (v5)</td><td>6.8</td></tr><tr><td>PReLU-net [12]</td><td>4.94</td></tr><tr><td>BN-inception [16]</td><td>4.82</td></tr><tr><td>ResNet (ILSVRC'15)</td><td>3.57</td></tr></table>

<table><tbody><tr><td>方法</td><td>前五错误率(测试)</td></tr><tr><td>VGG [40](ILSVRC’14)</td><td>7.32</td></tr><tr><td>GoogLeNet [43](ILSVRC’14)</td><td>6.66</td></tr><tr><td>VGG [40](v5)</td><td>6.8</td></tr><tr><td>PReLU-net [12]</td><td>4.94</td></tr><tr><td>BN-inception [16]</td><td>4.82</td></tr><tr><td>ResNet(ILSVRC'15)</td><td>3.57</td></tr></tbody></table>

Table 5. Error rates (%) of ensembles. The top-5 error is on the test set of ImageNet and reported by the test server.

表5. 集成模型的错误率(%)。Top-5错误率基于ImageNet测试集，由测试服务器报告。

Last, we also note that the 18-layer plain/residual nets are comparably accurate (Table 2), but the 18-layer ResNet converges faster (Fig. 4 right vs. left). When the net is "not overly deep" (18 layers here), the current SGD solver is still able to find good solutions to the plain net. In this case, the ResNet eases the optimization by providing faster convergence at the early stage.

最后，我们还注意到18层的普通/残差网络在准确率上相当(表2)，但18层ResNet收敛更快(图4右侧对比左侧)。当网络“不过于深”(此处为18层)时，当前的SGD优化器仍能找到普通网络的良好解。在这种情况下，ResNet通过在早期阶段提供更快的收敛速度，简化了优化过程。

Identity vs. Projection Shortcuts. We have shown that parameter-free, identity shortcuts help with training. Next we investigate projection shortcuts (Eqn.(2)). In Table 3 we compare three options: (A) zero-padding shortcuts are used for increasing dimensions, and all shortcuts are parameter-free (the same as Table 2 and Fig. 4 right); (B) projection shortcuts are used for increasing dimensions, and other shortcuts are identity; and (C) all shortcuts are projections.

恒等映射(shortcuts)与投影映射(shortcuts)。我们已证明无参数的恒等映射有助于训练。接下来我们研究投影映射(公式(2))。在表3中，我们比较了三种方案:(A)使用零填充(shortcuts)来增加维度，且所有shortcuts均无参数(与表2和图4右侧相同)；(B)使用投影映射(shortcuts)增加维度，其他shortcuts为恒等映射；(C)所有shortcuts均为投影映射。

![bo_d1c3qi77aajc7389qet0_5_971_201_608_224_0.jpg](images/bo_d1c3qi77aajc7389qet0_5_971_201_608_224_0.jpg)

Figure 5. A deeper residual function $\mathcal{F}$ for ImageNet. Left: a building block (on ${56} \times  {56}$ feature maps) as in Fig. 3 for ResNet- 34. Right: a "bottleneck" building block for ResNet-50/101/152.

图5. 用于ImageNet的更深残差函数$\mathcal{F}$。左图:如图3所示的ResNet-34的一个构建模块(在${56} \times  {56}$特征图上)。右图:ResNet-50/101/152的“瓶颈”构建模块。

Table 3 shows that all three options are considerably better than the plain counterpart. B is slightly better than A. We argue that this is because the zero-padded dimensions in A indeed have no residual learning. $\mathrm{C}$ is marginally better than B, and we attribute this to the extra parameters introduced by many (thirteen) projection shortcuts. But the small differences among $\mathrm{A}/\mathrm{B}/\mathrm{C}$ indicate that projection shortcuts are not essential for addressing the degradation problem. So we do not use option $\mathrm{C}$ in the rest of this paper, to reduce memory/time complexity and model sizes. Identity shortcuts are particularly important for not increasing the complexity of the bottleneck architectures that are introduced below.

表3显示，三种方案均明显优于普通网络。方案B略优于方案A。我们认为这是因为方案A中零填充的维度实际上没有进行残差学习。$\mathrm{C}$略优于方案B，我们归因于其引入了许多(十三个)投影映射的额外参数。但$\mathrm{A}/\mathrm{B}/\mathrm{C}$之间的差异较小，表明投影映射并非解决退化问题的关键。因此，为了减少内存/时间复杂度和模型大小，本文其余部分不采用方案$\mathrm{C}$。恒等映射对于不增加下文介绍的瓶颈架构复杂度尤为重要。

Deeper Bottleneck Architectures. Next we describe our deeper nets for ImageNet. Because of concerns on the training time that we can afford, we modify the building block as a bottleneck design ${}^{4}$ . For each residual function $\mathcal{F}$ , we use a stack of 3 layers instead of 2 (Fig. 5). The three layers are $1 \times  1,3 \times  3$ , and $1 \times  1$ convolutions, where the $1 \times  1$ layers are responsible for reducing and then increasing (restoring) dimensions, leaving the $3 \times  3$ layer a bottleneck with smaller input/output dimensions. Fig. 5 shows an example, where both designs have similar time complexity.

更深的瓶颈架构。接下来我们介绍用于ImageNet的更深网络。考虑到可承受的训练时间，我们将构建模块修改为瓶颈设计${}^{4}$。对于每个残差函数$\mathcal{F}$，我们使用3层堆叠代替2层(图5)。这三层分别是$1 \times  1,3 \times  3$和$1 \times  1$卷积，其中$1 \times  1$层负责先降低再恢复维度，使$3 \times  3$层成为输入/输出维度较小的瓶颈。图5展示了一个示例，两种设计的时间复杂度相近。

The parameter-free identity shortcuts are particularly important for the bottleneck architectures. If the identity shortcut in Fig. 5 (right) is replaced with projection, one can show that the time complexity and model size are doubled, as the shortcut is connected to the two high-dimensional ends. So identity shortcuts lead to more efficient models for the bottleneck designs.

无参数的恒等映射对瓶颈架构尤为重要。如果将图5右侧的恒等映射替换为投影映射，可以证明时间复杂度和模型大小将翻倍，因为该shortcut连接了两个高维端点。因此，恒等映射使瓶颈设计的模型更高效。

50-layer ResNet: We replace each 2-layer block in the 34-layer net with this 3-layer bottleneck block, resulting in a 50-layer ResNet (Table 1). We use option B for increasing dimensions. This model has 3.8 billion FLOPs.

50层ResNet:我们用该3层瓶颈模块替换34层网络中的每个2层模块，得到50层ResNet(表1)。我们采用方案B来增加维度。该模型拥有38亿次浮点运算(FLOPs)。

---

${}^{4}$ Deeper non-bottleneck ResNets (e.g., Fig. 5 left) also gain accuracy from increased depth (as shown on CIFAR-10), but are not as economical as the bottleneck ResNets. So the usage of bottleneck designs is mainly due to practical considerations. We further note that the degradation problem of plain nets is also witnessed for the bottleneck designs.

${}^{4}$ 更深的非瓶颈ResNet(如图5左)也因深度增加而提升准确率(如CIFAR-10所示)，但不如瓶颈ResNet经济。因此，采用瓶颈设计主要出于实际考虑。我们还注意到，普通网络的退化问题在瓶颈设计中同样存在。

---

101-layer and 152-layer ResNets: We construct 101- layer and 152-layer ResNets by using more 3-layer blocks (Table 1). Remarkably, although the depth is significantly increased, the 152-layer ResNet (11.3 billion FLOPs) still has lower complexity than VGG-16/19 nets (15.3/19.6 billion FLOPs).

101层和152层ResNet:我们通过使用更多3层模块构建101层和152层ResNet(表1)。值得注意的是，尽管深度显著增加，152层ResNet(113亿FLOPs)的复杂度仍低于VGG-16/19网络(153亿/196亿FLOPs)。

The 50/101/152-layer ResNets are more accurate than the 34-layer ones by considerable margins (Table 3 and 4). We do not observe the degradation problem and thus enjoy significant accuracy gains from considerably increased depth. The benefits of depth are witnessed for all evaluation metrics (Table 3 and 4).

50/101/152层ResNet在准确率上显著优于34层网络(表3和4)。我们未观察到退化问题，因此能从大幅增加的深度中获得显著的准确率提升。深度的益处在所有评估指标中均有体现(表3和4)。

Comparisons with State-of-the-art Methods. In Table 4 we compare with the previous best single-model results. Our baseline 34-layer ResNets have achieved very competitive accuracy. Our 152-layer ResNet has a single-model top-5 validation error of ${4.49}\%$ . This single-model result outperforms all previous ensemble results (Table 5). We combine six models of different depth to form an ensemble (only with two 152-layer ones at the time of submitting). This leads to 3.57% top-5 error on the test set (Table 5). This entry won the 1st place in ILSVRC 2015.

与最先进方法的比较。在表4中，我们与之前最佳的单模型结果进行了比较。我们的基线34层ResNet(残差网络)已达到非常有竞争力的准确率。我们的152层ResNet单模型在top-5验证错误率为${4.49}\%$。该单模型结果优于所有之前的集成结果(表5)。我们结合了六个不同深度的模型组成一个集成(提交时仅包含两个152层模型)。这使得测试集上的top-5错误率达到3.57%(表5)。该条目获得了ILSVRC 2015的第一名。

### 4.2. CIFAR-10 and Analysis

### 4.2. CIFAR-10及分析

We conducted more studies on the CIFAR-10 dataset [20], which consists of ${50}\mathrm{k}$ training images and ${10}\mathrm{k}$ testing images in 10 classes. We present experiments trained on the training set and evaluated on the test set. Our focus is on the behaviors of extremely deep networks, but not on pushing the state-of-the-art results, so we intentionally use simple architectures as follows.

我们在CIFAR-10数据集[20]上进行了更多研究，该数据集包含${50}\mathrm{k}$张训练图像和${10}\mathrm{k}$张测试图像，分为10个类别。我们展示了在训练集上训练并在测试集上评估的实验。我们的重点是极深网络的行为，而非推动最先进结果，因此我们有意采用如下简单架构。

The plain/residual architectures follow the form in Fig. 3 (middle/right). The network inputs are ${32} \times  {32}$ images, with the per-pixel mean subtracted. The first layer is $3 \times  3$ convolutions. Then we use a stack of ${6n}$ layers with $3 \times  3$ convolutions on the feature maps of sizes $\{ {32},{16},8\}$ respectively, with ${2n}$ layers for each feature map size. The numbers of filters are $\{ {16},{32},{64}\}$ respectively. The subsampling is performed by convolutions with a stride of 2 . The network ends with a global average pooling, a 10-way fully-connected layer, and softmax. There are totally ${6n} + 2$ stacked weighted layers. The following table summarizes the architecture:

普通/残差架构遵循图3(中间/右侧)所示形式。网络输入为${32} \times  {32}$图像，减去每像素均值。第一层为$3 \times  3$卷积层。随后我们使用一组${6n}$层，每层为$3 \times  3$卷积，作用于尺寸分别为$\{ {32},{16},8\}$的特征图，每个特征图尺寸对应${2n}$层。滤波器数量分别为$\{ {16},{32},{64}\}$。下采样通过步幅为2的卷积实现。网络以全局平均池化、一个10分类全连接层和softmax结束。总共有${6n} + 2$个堆叠的加权层。下表总结了该架构:

<table><tr><td>output map size</td><td>${32} \times  {32}$</td><td>${16} \times  {16}$</td><td>$8 \times  8$</td></tr><tr><td>#layers</td><td>$1 + {2n}$</td><td>${2n}$</td><td>${2n}$</td></tr><tr><td>#filters</td><td>16</td><td>32</td><td>64</td></tr></table>

<table><tbody><tr><td>输出图尺寸</td><td>${32} \times  {32}$</td><td>${16} \times  {16}$</td><td>$8 \times  8$</td></tr><tr><td>层数</td><td>$1 + {2n}$</td><td>${2n}$</td><td>${2n}$</td></tr><tr><td>滤波器数量</td><td>16</td><td>32</td><td>64</td></tr></tbody></table>

When shortcut connections are used, they are connected to the pairs of $3 \times  3$ layers (totally ${3n}$ shortcuts). On this dataset we use identity shortcuts in all cases (i.e., option A), so our residual models have exactly the same depth, width, and number of parameters as the plain counterparts.

当使用捷径连接时，它们连接到成对的$3 \times  3$层(共计${3n}$条捷径)。在此数据集中，我们在所有情况下都使用恒等捷径(即选项A)，因此我们的残差模型在深度、宽度和参数数量上与普通模型完全相同。

<table><tr><td colspan="3">method</td><td>error (%)</td></tr><tr><td colspan="3">Maxout [9]</td><td>9.38</td></tr><tr><td colspan="3">NIN [25]</td><td>8.81</td></tr><tr><td colspan="3">DSN [24]</td><td>8.22</td></tr><tr><td/><td>#layers</td><td>#params</td><td/></tr><tr><td>FitNet [34]</td><td>19</td><td>2.5M</td><td>8.39</td></tr><tr><td>Highway [41, 42]</td><td>19</td><td>2.3M</td><td>7.54 (7.72±0.16)</td></tr><tr><td>Highway [41, 42]</td><td>32</td><td>1.25M</td><td>8.80</td></tr><tr><td>ResNet</td><td>20</td><td>0.27M</td><td>8.75</td></tr><tr><td>ResNet</td><td>32</td><td>0.46M</td><td>7.51</td></tr><tr><td>ResNet</td><td>44</td><td>0.66M</td><td>7.17</td></tr><tr><td>ResNet</td><td>56</td><td>0.85M</td><td>6.97</td></tr><tr><td>ResNet</td><td>110</td><td>1.7M</td><td>6.43 (6.61 $\pm  {0.16)}$</td></tr><tr><td>ResNet</td><td>1202</td><td>19.4M</td><td>7.93</td></tr></table>

<table><tbody><tr><td colspan="3">方法</td><td>错误率 (%)</td></tr><tr><td colspan="3">Maxout [9]</td><td>9.38</td></tr><tr><td colspan="3">NIN [25]</td><td>8.81</td></tr><tr><td colspan="3">DSN [24]</td><td>8.22</td></tr><tr><td></td><td>层数</td><td>参数数量</td><td></td></tr><tr><td>FitNet [34]</td><td>19</td><td>2.5M</td><td>8.39</td></tr><tr><td>Highway [41, 42]</td><td>19</td><td>2.3M</td><td>7.54 (7.72±0.16)</td></tr><tr><td>Highway [41, 42]</td><td>32</td><td>1.25M</td><td>8.80</td></tr><tr><td>ResNet</td><td>20</td><td>0.27M</td><td>8.75</td></tr><tr><td>ResNet</td><td>32</td><td>0.46M</td><td>7.51</td></tr><tr><td>ResNet</td><td>44</td><td>0.66M</td><td>7.17</td></tr><tr><td>ResNet</td><td>56</td><td>0.85M</td><td>6.97</td></tr><tr><td>ResNet</td><td>110</td><td>1.7M</td><td>6.43 (6.61 $\pm  {0.16)}$</td></tr><tr><td>ResNet</td><td>1202</td><td>19.4M</td><td>7.93</td></tr></tbody></table>

Table 6. Classification error on the CIFAR-10 test set. All methods are with data augmentation. For ResNet-110, we run it 5 times and show "best (mean $\pm$ std)" as in [42].

表6. CIFAR-10测试集上的分类错误率。所有方法均采用数据增强。对于ResNet-110，我们运行5次，展示“最佳(平均$\pm$ 标准差)”，如文献[42]所示。

We use a weight decay of 0.0001 and momentum of 0.9 , and adopt the weight initialization in [12] and BN [16] but with no dropout. These models are trained with a mini-batch size of 128 on two GPUs. We start with a learning rate of 0.1, divide it by 10 at ${32}\mathrm{k}$ and ${48}\mathrm{k}$ iterations, and terminate training at ${64}\mathrm{k}$ iterations, which is determined on a ${45}\mathrm{\;k}/5\mathrm{k}$ train/val split. We follow the simple data augmentation in [24] for training: 4 pixels are padded on each side, and a ${32} \times  {32}$ crop is randomly sampled from the padded image or its horizontal flip. For testing, we only evaluate the single view of the original ${32} \times  {32}$ image.

我们使用0.0001的权重衰减和0.9的动量，采用文献[12]中的权重初始化和文献[16]中的批归一化(BN)，但不使用dropout。这些模型在两块GPU上以128的mini-batch大小训练。初始学习率为0.1，在${32}\mathrm{k}$和${48}\mathrm{k}$次迭代时将学习率除以10，并在${64}\mathrm{k}$次迭代时终止训练，该迭代次数基于${45}\mathrm{\;k}/5\mathrm{k}$的训练/验证划分确定。训练时遵循文献[24]中的简单数据增强:在每边填充4个像素，从填充后的图像或其水平翻转中随机裁剪出${32} \times  {32}$大小的图像。测试时仅评估原始${32} \times  {32}$图像的单视图。

We compare $n = \{ 3,5,7,9\}$ , leading to20,32,44, and 56-layer networks. Fig. 6 (left) shows the behaviors of the plain nets. The deep plain nets suffer from increased depth, and exhibit higher training error when going deeper. This phenomenon is similar to that on ImageNet (Fig. 4, left) and on MNIST (see [41]), suggesting that such an optimization difficulty is a fundamental problem.

我们比较了$n = \{ 3,5,7,9\}$，生成了20、32、44和56层的网络。图6(左)展示了普通网络的表现。深层普通网络随着深度增加表现出训练误差上升的现象。该现象与ImageNet(图4，左)和MNIST(见文献[41])上的情况类似，表明这种优化困难是一个根本性问题。

Fig. 6 (middle) shows the behaviors of ResNets. Also similar to the ImageNet cases (Fig. 4, right), our ResNets manage to overcome the optimization difficulty and demonstrate accuracy gains when the depth increases.

图6(中)展示了ResNet的表现。同样类似于ImageNet的情况(图4，右)，我们的ResNet成功克服了优化困难，且随着深度增加表现出准确率的提升。

We further explore $n = {18}$ that leads to a 110-layer ResNet. In this case, we find that the initial learning rate of 0.1 is slightly too large to start converging ${}^{5}$ . So we use 0.01 to warm up the training until the training error is below ${80}\%$ (about 400 iterations), and then go back to 0.1 and continue training. The rest of the learning schedule is as done previously. This 110-layer network converges well (Fig. 6, middle). It has fewer parameters than other deep and thin networks such as FitNet [34] and Highway [41] (Table 6), yet is among the state-of-the-art results (6.43%, Table 6).

我们进一步探索了$n = {18}$，构建了一个110层的ResNet。在此情况下，我们发现初始学习率0.1稍大，导致收敛开始较晚${}^{5}$。因此，我们使用0.01进行预热训练，直到训练误差低于${80}\%$(约400次迭代)，然后恢复到0.1继续训练。其余学习率调度与之前相同。该110层网络收敛良好(图6，中)。其参数量少于其他深且窄的网络，如FitNet[34]和Highway[41](表6)，但性能处于最先进水平(6.43%，表6)。

---

${}^{5}$ With an initial learning rate of 0.1, it starts converging ( $< {90}\%$ error) after several epochs, but still reaches similar accuracy.

${}^{5}$ 在初始学习率为0.1时，经过若干个epoch后开始收敛($< {90}\%$误差)，但最终达到类似的准确率。

---

![bo_d1c3qi77aajc7389qet0_7_284_200_1181_304_0.jpg](images/bo_d1c3qi77aajc7389qet0_7_284_200_1181_304_0.jpg)

Figure 6. Training on CIFAR-10. Dashed lines denote training error, and bold lines denote testing error. Left: plain networks. The error of plain-110 is higher than ${60}\%$ and not displayed. Middle: ResNets. Right: ResNets with 110 and 1202 layers.

图6. CIFAR-10上的训练。虚线表示训练误差，粗线表示测试误差。左:普通网络。plain-110的误差高于${60}\%$，未显示。中:ResNet。右:110层和1202层的ResNet。

![bo_d1c3qi77aajc7389qet0_7_169_615_652_349_0.jpg](images/bo_d1c3qi77aajc7389qet0_7_169_615_652_349_0.jpg)

Figure 7. Standard deviations (std) of layer responses on CIFAR- 10. The responses are the outputs of each $3 \times  3$ layer, after BN and before nonlinearity. Top: the layers are shown in their original order. Bottom: the responses are ranked in descending order.

图7. CIFAR-10上各层响应的标准差(std)。响应是每个$3 \times  3$层经过BN后、非线性激活前的输出。上图:层按原始顺序排列。下图:响应按降序排列。

Analysis of Layer Responses. Fig. 7 shows the standard deviations (std) of the layer responses. The responses are the outputs of each $3 \times  3$ layer, after $\mathrm{{BN}}$ and before other nonlinearity (ReLU/addition). For ResNets, this analysis reveals the response strength of the residual functions. Fig. 7 shows that ResNets have generally smaller responses than their plain counterparts. These results support our basic motivation (Sec.3.1) that the residual functions might be generally closer to zero than the non-residual functions. We also notice that the deeper ResNet has smaller magnitudes of responses, as evidenced by the comparisons among ResNet-20, 56, and 110 in Fig. 7. When there are more layers, an individual layer of ResNets tends to modify the signal less.

层响应分析。图7展示了层响应的标准差(std)。响应是每个$3 \times  3$层经过$\mathrm{{BN}}$后、其他非线性(ReLU/加法)前的输出。对于ResNet，该分析揭示了残差函数的响应强度。图7显示，ResNet的响应普遍小于其普通网络对应层。这支持了我们的基本动机(第3.1节)，即残差函数通常比非残差函数更接近零。我们还注意到，较深的ResNet响应幅度更小，如图7中ResNet-20、56和110的比较所示。层数越多，ResNet的单层对信号的修改越小。

Exploring Over 1000 layers. We explore an aggressively deep model of over 1000 layers. We set $n = {200}$ that leads to a 1202-layer network, which is trained as described above. Our method shows no optimization difficulty, and this ${10}^{3}$ -layer network is able to achieve training error $< {0.1}\%$ (Fig. 6, right). Its test error is still fairly good (7.93%, Table 6).

探索超过1000层。我们探索了一个超过1000层的极深模型。我们设置了$n = {200}$，从而构建了一个1202层的网络，该网络按照上述方法进行训练。我们的方法没有表现出优化困难，这个${10}^{3}$层的网络能够达到训练误差$< {0.1}\%$(图6，右)。其测试误差仍然相当不错(7.93%，表6)。

But there are still open problems on such aggressively deep models. The testing result of this 1202-layer network is worse than that of our 110-layer network, although both have similar training error. We argue that this is because of overfitting. The 1202-layer network may be unnecessarily large (19.4M) for this small dataset. Strong regularization such as maxout [9] or dropout [13] is applied to obtain the best results $\left( \left\lbrack  {9,{25},{24},{34}}\right\rbrack  \right)$ on this dataset. In this paper, we use no maxout/dropout and just simply impose regularization via deep and thin architectures by design, without distracting from the focus on the difficulties of optimization. But combining with stronger regularization may improve results, which we will study in the future.

但对于如此极深的模型，仍存在一些未解决的问题。尽管1202层网络和我们110层网络的训练误差相似，但前者的测试结果却更差。我们认为这是由于过拟合造成的。对于这个小型数据集，1202层网络可能过于庞大(1940万参数)。为了在该数据集上获得最佳结果，通常会采用如maxout[9]或dropout[13]等强正则化方法。在本文中，我们未使用maxout或dropout，仅通过设计深而细的架构简单施加正则化，以避免分散对优化难点的关注。但结合更强的正则化可能会提升结果，我们将在未来进行研究。

<table><tr><td>training data</td><td>07+12</td><td>07++12</td></tr><tr><td>test data</td><td>VOC 07 test</td><td>VOC 12 test</td></tr><tr><td>VGG-16</td><td>73.2</td><td>70.4</td></tr><tr><td>ResNet-101</td><td>76.4</td><td>73.8</td></tr></table>

<table><tbody><tr><td>训练数据</td><td>07+12</td><td>07++12</td></tr><tr><td>测试数据</td><td>VOC 07 测试</td><td>VOC 12 测试</td></tr><tr><td>VGG-16</td><td>73.2</td><td>70.4</td></tr><tr><td>ResNet-101</td><td>76.4</td><td>73.8</td></tr></tbody></table>

Table 7. Object detection mAP (%) on the PASCAL VOC 2007/2012 test sets using baseline Faster R-CNN. See also appendix for better results.

表7. 使用基线Faster R-CNN在PASCAL VOC 2007/2012测试集上的目标检测mAP(%)。更多优异结果见附录。

<table><tr><td>metric</td><td>mAP@.5</td><td>mAP@[.5, .95]</td></tr><tr><td>VGG-16</td><td>41.5</td><td>21.2</td></tr><tr><td>ResNet-101</td><td>48.4</td><td>27.2</td></tr></table>

<table><tbody><tr><td>度量</td><td>mAP@0.5</td><td>mAP@[0.5, 0.95]</td></tr><tr><td>VGG-16</td><td>41.5</td><td>21.2</td></tr><tr><td>ResNet-101</td><td>48.4</td><td>27.2</td></tr></tbody></table>

Table 8. Object detection mAP (%) on the COCO validation set using baseline Faster R-CNN. See also appendix for better results.

表8. 使用基线Faster R-CNN在COCO验证集上的目标检测mAP(%)。更多更好结果见附录。

### 4.3. Object Detection on PASCAL and MS COCO

### 4.3. PASCAL和MS COCO上的目标检测

Our method has good generalization performance on other recognition tasks. Table 7 and 8 show the object detection baseline results on PASCAL VOC 2007 and 2012 [5] and COCO [26]. We adopt Faster R-CNN [32] as the detection method. Here we are interested in the improvements of replacing VGG-16 [40] with ResNet-101. The detection implementation (see appendix) of using both models is the same, so the gains can only be attributed to better networks. Most remarkably, on the challenging COCO dataset we obtain a 6.0% increase in COCO’s standard metric (mAP@[.5, .95]), which is a ${28}\%$ relative improvement. This gain is solely due to the learned representations.

我们的方法在其他识别任务上具有良好的泛化性能。表7和表8展示了PASCAL VOC 2007和2012 [5]及COCO [26]上的目标检测基线结果。我们采用Faster R-CNN [32]作为检测方法。这里我们关注用ResNet-101替换VGG-16 [40]带来的提升。两种模型的检测实现(见附录)相同，因此提升只能归因于更优的网络结构。最显著的是，在具有挑战性的COCO数据集上，我们在COCO标准指标(mAP@[.5, .95])上获得了6.0%的提升，这是一个${28}\%$的相对改进。该提升完全归功于学习到的表征。

Based on deep residual nets, we won the 1st places in several tracks in ILSVRC & COCO 2015 competitions: Im-ageNet detection, ImageNet localization, COCO detection, and COCO segmentation. The details are in the appendix. References

基于深度残差网络，我们在ILSVRC和COCO 2015竞赛的多个赛道中获得了第一名:ImageNet检测、ImageNet定位、COCO检测和COCO分割。详情见附录。参考文献

[1] Y. Bengio, P. Simard, and P. Frasconi. Learning long-term dependencies with gradient descent is difficult. IEEE Transactions on Neural Networks, 5(2):157-166, 1994.

[1] Y. Bengio, P. Simard, 和 P. Frasconi. 用梯度下降学习长期依赖关系是困难的。IEEE神经网络汇刊，5(2):157-166, 1994。

[2] C. M. Bishop. Neural networks for pattern recognition. Oxford university press, 1995.

[2] C. M. Bishop. 模式识别的神经网络。牛津大学出版社，1995。

[3] W. L. Briggs, S. F. McCormick, et al. A Multigrid Tutorial. Siam, 2000.

[3] W. L. Briggs, S. F. McCormick 等. 多重网格教程。SIAM，2000。

[4] K. Chatfield, V. Lempitsky, A. Vedaldi, and A. Zisserman. The devil is in the details: an evaluation of recent feature encoding methods. In ${BMVC},{2011}$ .

[4] K. Chatfield, V. Lempitsky, A. Vedaldi, 和 A. Zisserman. 细节决定成败:近期特征编码方法的评估。发表于${BMVC},{2011}$。

[5] M. Everingham, L. Van Gool, C. K. Williams, J. Winn, and A. Zis-serman. The Pascal Visual Object Classes (VOC) Challenge. IJCV, pages 303-338, 2010.

[5] M. Everingham, L. Van Gool, C. K. Williams, J. Winn, 和 A. Zisserman. Pascal视觉对象类别(VOC)挑战。国际计算机视觉杂志(IJCV)，第303-338页，2010。

[6] R. Girshick. Fast R-CNN. In ICCV, 2015.

[6] R. Girshick. Fast R-CNN。发表于ICCV，2015。

[7] R. Girshick, J. Donahue, T. Darrell, and J. Malik. Rich feature hierarchies for accurate object detection and semantic segmentation. In CVPR, 2014.

[7] R. Girshick, J. Donahue, T. Darrell, 和 J. Malik. 丰富的特征层次结构用于精确目标检测和语义分割。发表于CVPR，2014。

[8] X. Glorot and Y. Bengio. Understanding the difficulty of training deep feedforward neural networks. In AISTATS, 2010.

[8] X. Glorot 和 Y. Bengio. 理解训练深度前馈神经网络的难点。发表于AISTATS，2010。

[9] I. J. Goodfellow, D. Warde-Farley, M. Mirza, A. Courville, and Y. Bengio. Maxout networks. arXiv:1302.4389, 2013.

[9] I. J. Goodfellow, D. Warde-Farley, M. Mirza, A. Courville, 和 Y. Bengio. Maxout网络。arXiv:1302.4389, 2013。

[10] K. He and J. Sun. Convolutional neural networks at constrained time cost. In ${CVPR},{2015}$ .

[10] K. He 和 J. Sun. 受限时间成本下的卷积神经网络。发表于${CVPR},{2015}$。

[11] K. He, X. Zhang, S. Ren, and J. Sun. Spatial pyramid pooling in deep convolutional networks for visual recognition. In ${ECCV},{2014}$ .

[11] K. He, X. Zhang, S. Ren, 和 J. Sun. 用于视觉识别的深度卷积网络中的空间金字塔池化。发表于${ECCV},{2014}$。

[12] K. He, X. Zhang, S. Ren, and J. Sun. Delving deep into rectifiers: Surpassing human-level performance on imagenet classification. In ICCV, 2015.

[12] K. He, X. Zhang, S. Ren, 和 J. Sun. 深入研究整流函数:超越人类水平的ImageNet分类性能。发表于ICCV，2015。

[13] G. E. Hinton, N. Srivastava, A. Krizhevsky, I. Sutskever, and R. R. Salakhutdinov. Improving neural networks by preventing coadaptation of feature detectors. arXiv:1207.0580, 2012.

[13] G. E. Hinton, N. Srivastava, A. Krizhevsky, I. Sutskever, 和 R. R. Salakhutdinov. 通过防止特征检测器的协同适应来改进神经网络。arXiv:1207.0580, 2012.

[14] S. Hochreiter. Untersuchungen zu dynamischen neuronalen netzen. Diploma thesis, TU Munich, 1991.

[14] S. Hochreiter. 关于动态神经网络的研究。慕尼黑工业大学毕业论文，1991.

[15] S. Hochreiter and J. Schmidhuber. Long short-term memory. Neural computation, 9(8):1735-1780, 1997.

[15] S. Hochreiter 和 J. Schmidhuber. 长短期记忆(Long short-term memory)。神经计算(Neural computation)，9(8):1735-1780, 1997.

[16] S. Ioffe and C. Szegedy. Batch normalization: Accelerating deep network training by reducing internal covariate shift. In ICML, 2015.

[16] S. Ioffe 和 C. Szegedy. 批量归一化(Batch normalization):通过减少内部协变量偏移加速深度网络训练。发表于ICML，2015.

[17] H. Jegou, M. Douze, and C. Schmid. Product quantization for nearest neighbor search. TPAMI, 33, 2011.

[17] H. Jegou, M. Douze, 和 C. Schmid. 用于最近邻搜索的乘积量化(Product quantization)。TPAMI，33, 2011.

[18] H. Jegou, F. Perronnin, M. Douze, J. Sanchez, P. Perez, and C. Schmid. Aggregating local image descriptors into compact codes. TPAMI, 2012.

[18] H. Jegou, F. Perronnin, M. Douze, J. Sanchez, P. Perez, 和 C. Schmid. 将局部图像描述符聚合成紧凑编码。TPAMI，2012.

[19] Y. Jia, E. Shelhamer, J. Donahue, S. Karayev, J. Long, R. Girshick, S. Guadarrama, and T. Darrell. Caffe: Convolutional architecture for fast feature embedding. arXiv:1408.5093, 2014.

[19] Y. Jia, E. Shelhamer, J. Donahue, S. Karayev, J. Long, R. Girshick, S. Guadarrama, 和 T. Darrell. Caffe:用于快速特征嵌入的卷积架构。arXiv:1408.5093, 2014.

[20] A. Krizhevsky. Learning multiple layers of features from tiny images. Tech Report, 2009.

[20] A. Krizhevsky. 从小图像中学习多层特征。技术报告，2009.

[21] A. Krizhevsky, I. Sutskever, and G. Hinton. Imagenet classification with deep convolutional neural networks. In NIPS, 2012.

[21] A. Krizhevsky, I. Sutskever, 和 G. Hinton. 使用深度卷积神经网络进行ImageNet分类。发表于NIPS，2012.

[22] Y. LeCun, B. Boser, J. S. Denker, D. Henderson, R. E. Howard, W. Hubbard, and L. D. Jackel. Backpropagation applied to handwritten zip code recognition. Neural computation, 1989.

[22] Y. LeCun, B. Boser, J. S. Denker, D. Henderson, R. E. Howard, W. Hubbard, 和 L. D. Jackel. 反向传播算法应用于手写邮政编码识别。神经计算，1989.

[23] Y. LeCun, L. Bottou, G. B. Orr, and K.-R. Müller. Efficient backprop. In Neural Networks: Tricks of the Trade, pages 9-50. Springer, 1998.

[23] Y. LeCun, L. Bottou, G. B. Orr, 和 K.-R. Müller. 高效的反向传播。收录于《神经网络:技巧汇编》(Neural Networks: Tricks of the Trade)，第9-50页。施普林格出版社，1998.

[24] C.-Y. Lee, S. Xie, P. Gallagher, Z. Zhang, and Z. Tu. Deeply-supervised nets. arXiv:1409.5185, 2014.

[24] C.-Y. Lee, S. Xie, P. Gallagher, Z. Zhang, 和 Z. Tu. 深度监督网络。arXiv:1409.5185, 2014.

[25] M. Lin, Q. Chen, and S. Yan. Network in network. arXiv:1312.4400, 2013.

[25] M. Lin, Q. Chen, 和 S. Yan. 网络中的网络(Network in network)。arXiv:1312.4400, 2013.

[26] T.-Y. Lin, M. Maire, S. Belongie, J. Hays, P. Perona, D. Ramanan, P. Dollár, and C. L. Zitnick. Microsoft COCO: Common objects in context. In ${ECCV}$ . 2014.

[26] T.-Y. Lin, M. Maire, S. Belongie, J. Hays, P. Perona, D. Ramanan, P. Dollár, 和 C. L. Zitnick. 微软COCO:上下文中的常见物体。发表于${ECCV}$，2014.

[27] J. Long, E. Shelhamer, and T. Darrell. Fully convolutional networks for semantic segmentation. In ${CVPR},{2015}$ .

[27] J. Long, E. Shelhamer, 和 T. Darrell. 用于语义分割的全卷积网络。发表于${CVPR},{2015}$。

[28] G. Montúfar, R. Pascanu, K. Cho, and Y. Bengio. On the number of linear regions of deep neural networks. In NIPS, 2014.

[28] G. Montúfar, R. Pascanu, K. Cho, 和 Y. Bengio. 深度神经网络线性区域数量的研究。发表于NIPS，2014.

[29] V. Nair and G. E. Hinton. Rectified linear units improve restricted boltzmann machines. In ICML, 2010.

[29] V. Nair 和 G. E. Hinton. 修正线性单元(Rectified Linear Units)提升受限玻尔兹曼机(Restricted Boltzmann Machines)的性能。发表于 ICML，2010。

[30] F. Perronnin and C. Dance. Fisher kernels on visual vocabularies for image categorization. In ${CVPR},{2007}$ .

[30] F. Perronnin 和 C. Dance. 基于视觉词汇的费舍尔核(Fisher Kernels)用于图像分类。发表于 ${CVPR},{2007}$ 。

[31] T. Raiko, H. Valpola, and Y. LeCun. Deep learning made easier by linear transformations in perceptrons. In AISTATS, 2012.

[31] T. Raiko, H. Valpola 和 Y. LeCun. 通过感知机中的线性变换简化深度学习。发表于 AISTATS，2012。

[32] S. Ren, K. He, R. Girshick, and J. Sun. Faster R-CNN: Towards real-time object detection with region proposal networks. In NIPS, 2015.

[32] S. Ren, K. He, R. Girshick 和 J. Sun. Faster R-CNN:基于区域提议网络的实时目标检测方法。发表于 NIPS，2015。

[33] B. D. Ripley. Pattern recognition and neural networks. Cambridge university press, 1996.

[33] B. D. Ripley. 模式识别与神经网络。剑桥大学出版社，1996。

[34] A. Romero, N. Ballas, S. E. Kahou, A. Chassang, C. Gatta, and Y. Bengio. Fitnets: Hints for thin deep nets. In ICLR, 2015.

[34] A. Romero, N. Ballas, S. E. Kahou, A. Chassang, C. Gatta 和 Y. Bengio. Fitnets:为瘦深度网络提供提示。发表于 ICLR，2015。

[35] O. Russakovsky, J. Deng, H. Su, J. Krause, S. Satheesh, S. Ma, Z. Huang, A. Karpathy, A. Khosla, M. Bernstein, et al. Imagenet large scale visual recognition challenge. arXiv:1409.0575, 2014.

[35] O. Russakovsky, J. Deng, H. Su, J. Krause, S. Satheesh, S. Ma, Z. Huang, A. Karpathy, A. Khosla, M. Bernstein 等. ImageNet 大规模视觉识别挑战。arXiv:1409.0575，2014。

[36] A. M. Saxe, J. L. McClelland, and S. Ganguli. Exact solutions to the nonlinear dynamics of learning in deep linear neural networks. arXiv:1312.6120, 2013.

[36] A. M. Saxe, J. L. McClelland 和 S. Ganguli. 深度线性神经网络学习非线性动力学的精确解。arXiv:1312.6120，2013。

[37] N. N. Schraudolph. Accelerated gradient descent by factor-centering decomposition. Technical report, 1998.

[37] N. N. Schraudolph. 通过因子中心分解加速梯度下降。技术报告，1998。

[38] N. N. Schraudolph. Centering neural network gradient factors. In Neural Networks: Tricks of the Trade, pages 207-226. Springer, 1998.

[38] N. N. Schraudolph. 神经网络梯度因子的中心化。发表于《神经网络:技巧集》，第207-226页。施普林格，1998。

[39] P. Sermanet, D. Eigen, X. Zhang, M. Mathieu, R. Fergus, and Y. Le-Cun. Overfeat: Integrated recognition, localization and detection using convolutional networks. In ICLR, 2014.

[39] P. Sermanet, D. Eigen, X. Zhang, M. Mathieu, R. Fergus 和 Y. Le-Cun. Overfeat:使用卷积网络实现集成识别、定位与检测。发表于 ICLR，2014。

[40] K. Simonyan and A. Zisserman. Very deep convolutional networks for large-scale image recognition. In ICLR, 2015.

[40] K. Simonyan 和 A. Zisserman. 用于大规模图像识别的超深卷积网络。发表于 ICLR，2015。

[41] R. K. Srivastava, K. Greff, and J. Schmidhuber. Highway networks. arXiv:1505.00387, 2015.

[41] R. K. Srivastava, K. Greff 和 J. Schmidhuber. 高速公路网络(Highway Networks)。arXiv:1505.00387，2015。

[42] R. K. Srivastava, K. Greff, and J. Schmidhuber. Training very deep networks. 1507.06228, 2015.

[42] R. K. Srivastava, K. Greff 和 J. Schmidhuber. 训练超深网络。1507.06228，2015。

[43] C. Szegedy, W. Liu, Y. Jia, P. Sermanet, S. Reed, D. Anguelov, D. Er-han, V. Vanhoucke, and A. Rabinovich. Going deeper with convolutions. In ${CVPR},{2015}$ .

[43] C. Szegedy, W. Liu, Y. Jia, P. Sermanet, S. Reed, D. Anguelov, D. Erhan, V. Vanhoucke 和 A. Rabinovich. 通过卷积实现更深层次。发表于 ${CVPR},{2015}$ 。

[44] R. Szeliski. Fast surface interpolation using hierarchical basis functions. TPAMI, 1990.

[44] R. Szeliski. 使用分层基函数的快速曲面插值。TPAMI，1990。

[45] R. Szeliski. Locally adapted hierarchical basis preconditioning. In SIGGRAPH, 2006.

[45] R. Szeliski. 局部自适应分层基预条件方法。发表于SIGGRAPH，2006年。

[46] T. Vatanen, T. Raiko, H. Valpola, and Y. LeCun. Pushing stochastic gradient towards second-order methods-backpropagation learning with transformations in nonlinearities. In Neural Information Processing, 2013.

[46] T. Vatanen, T. Raiko, H. Valpola, 和 Y. LeCun. 推动随机梯度法向二阶方法发展——带非线性变换的反向传播学习。发表于神经信息处理会议，2013年。

[47] A. Vedaldi and B. Fulkerson. VLFeat: An open and portable library of computer vision algorithms, 2008.

[47] A. Vedaldi 和 B. Fulkerson. VLFeat:一个开放且可移植的计算机视觉算法库，2008年。

[48] W. Venables and B. Ripley. Modern applied statistics with s-plus. 1999.

[48] W. Venables 和 B. Ripley. 使用S-Plus的现代应用统计学。1999年。

[49] M. D. Zeiler and R. Fergus. Visualizing and understanding convolutional neural networks. In ${ECCV},{2014}$ .

[49] M. D. Zeiler 和 R. Fergus. 卷积神经网络的可视化与理解。发表于${ECCV},{2014}$。