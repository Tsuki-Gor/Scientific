# Leveraging Seen and Unseen Semantic Relationships for Generative Zero-Shot Learning

# 利用已见和未见语义关系进行生成式零样本学习

Maunil R. Vyas ${}^{\left( \square \right) }$ D, Hemanth Venkateswara ${}^{\square }$ , and Sethuraman Panchanathan

莫尼尔·R·维亚斯 ${}^{\left( \square \right) }$ D，赫曼斯·文卡特斯瓦拉 ${}^{\square }$ ，以及塞图拉曼·潘查纳坦

Arizona State University, Tempe, AZ 85281, USA \{mrvyas, hemanthv, panch\}@asu.edu

美国亚利桑那州立大学，坦佩，亚利桑那州 85281 \{mrvyas, hemanthv, panch\}@asu.edu

Abstract. Zero-shot learning (ZSL) addresses the unseen class recognition problem by leveraging semantic information to transfer knowledge from seen classes to unseen classes. Generative models synthesize the unseen visual features and convert ZSL into a classical supervised learning problem. These generative models are trained using the seen classes and are expected to implicitly transfer the knowledge from seen to unseen classes. However, their performance is stymied by overfitting, which leads to substandard performance on Generalized Zero-Shot learning (GZSL). To address this concern, we propose the novel LsrGAN, a generative model that Leverages the Semantic Relationship between seen and unseen categories and explicitly performs knowledge transfer by incorporating a novel Semantic Regularized Loss (SR-Loss). The SR-loss guides the LsrGAN to generate visual features that mirror the semantic relationships between seen and unseen classes. Experiments on seven benchmark datasets, including the challenging Wikipedia text-based CUB and NABirds splits, and Attribute-based AWA, CUB, and SUN, demonstrates the superiority of the LsrGAN compared to previous state-of-the-art approaches under both ZSL and GZSL. Code is available at https://github.com/Maunil/LsrGAN.

摘要。零样本学习(ZSL)通过利用语义信息将知识从已见类别转移到未见类别，来解决未见类别识别问题。生成式模型合成未见的视觉特征，并将零样本学习转化为经典的有监督学习问题。这些生成式模型使用已见类别进行训练，并期望能隐式地将知识从已见类别转移到未见类别。然而，它们的性能受到过拟合的阻碍，这导致在广义零样本学习(GZSL)上的表现不佳。为了解决这一问题，我们提出了新颖的LsrGAN，这是一种生成式模型，它利用已见和未见类别之间的语义关系，并通过引入一种新颖的语义正则化损失(SR - 损失)来显式地进行知识转移。SR - 损失引导LsrGAN生成反映已见和未见类别之间语义关系的视觉特征。在七个基准数据集上的实验，包括具有挑战性的基于维基百科文本的CUB和NABirds分割数据集，以及基于属性的AWA、CUB和SUN数据集，证明了LsrGAN在零样本学习和广义零样本学习方面与之前的先进方法相比具有优越性。代码可在https://github.com/Maunil/LsrGAN获取。

Keywords: Generalized zero-shot learning $\cdot$ Generative Modeling (GANs) - Seen and unseen relationship

关键词:广义零样本学习 $\cdot$ 生成式建模(GANs) - 已见和未见关系

## 1 Introduction

## 1 引言

Consider the following discussion between a kindergarten teacher and her student.

考虑以下幼儿园老师和她的学生之间的对话。

---

Electronic supplementary material The online version of this chapter (https:// doi.org/10.1007/978-3-030-58577-8-5) contains supplementary material, which is available to authorized users.

电子补充材料 本章的在线版本(https:// doi.org/10.1007/978 - 3 - 030 - 58577 - 8 - 5)包含补充材料，仅供授权用户使用。

---

![0195e037-bbaf-7de7-bf13-2cc5a64cb792_1_421_176_737_394_0.jpg](images/0195e037-bbaf-7de7-bf13-2cc5a64cb792_1_421_176_737_394_0.jpg)

Fig. 1. Driving motivation behind leveraging the semantic relationship between seen and unseen classes to infer the visual characteristics of unseen classes. Notice that though the feature representations are different, the class similarity values are almost the same. e.g. "Dolphin" has almost identical similarity values in visual and semantic space with other seen classes. The similarity values are mentioned in the circles, and computed using the cosine distance.

图1. 利用已见和未见类别之间的语义关系来推断未见类别的视觉特征的驱动动机。注意，尽管特征表示不同，但类别相似度值几乎相同。例如，“海豚”在视觉和语义空间中与其他已见类别的相似度值几乎相同。相似度值在圆圈中显示，并使用余弦距离计算。

Teacher: Today we will learn about a new animal that roams the grasslands of Africa. It is called the Zebra.

老师:今天我们将学习一种生活在非洲草原上的新动物。它叫斑马。

## Student: What does a Zebra look like?

## 学生:斑马长什么样？

Teacher: It looks like a short white horse but has black stripes like a tiger.

老师:它看起来像一匹白色的矮马，但像老虎一样有黑色条纹。

That description is nearly enough for the student to recognize a zebra the next time she sees it. The student is able to take the verbal (textual) description and relate it to the visual understanding of a horse and a tiger and generate a zebra in her mind. In this paper, we propose a zero-shot learning model that transfers knowledge from text to the visual domain to learn and recognize previously unseen image categories.

这样的描述几乎足以让学生下次看到斑马时能认出它。学生能够将口头(文本)描述与对马和老虎的视觉理解联系起来，并在脑海中形成斑马的形象。在本文中，我们提出了一种零样本学习模型，它将知识从文本转移到视觉领域，以学习和识别以前未见的图像类别。

Collecting and curating large labeled datasets for training deep neural networks is both labor-intensive and nearly impossible for many of the classification tasks, especially for the fine-grained categories in specific domains. Hence, it is desirable to create models that can mitigate these difficulties and learn not to rely on large labeled training sets. Inspired by the human ability to recognize object categories solely based on class descriptions and previous visual knowledge, the research community has extensively pursued the area of "Zero-shot learning" (ZSL) [11,22,23,29,37,38]. Zero-shot learning aims to recognize objects that are not seen during the training process of the model. It leverages textual descriptions/attributes to transfer knowledge from seen to unseen classes.

收集和整理用于训练深度神经网络的大型标注数据集既耗费人力，而且对于许多分类任务来说几乎是不可能的，特别是对于特定领域的细粒度类别。因此，创建能够缓解这些困难并且不依赖大型标注训练集的模型是很有必要的。受人类仅根据类别描述和先前视觉知识识别物体类别的能力的启发，研究界广泛开展了“零样本学习”(ZSL)领域的研究[11,22,23,29,37,38]。零样本学习旨在识别模型训练过程中未见的物体。它利用文本描述/属性将知识从已见类别转移到未见类别。

Generative models are the most popular approach to solve zero-shot learning. Despite the recent progress, generative models for zero-shot learning still have some key limitations. These models show a large quality gap between the synthesized and the actual unseen image features $\left\lbrack  {{15},{24},{31},{35},{43}}\right\rbrack$ . As a result, the performance of generalized zero-shot learning (GZSL) suffers, since many synthesized features of unseen classes are classified as seen classes. The second major concern behind the current generative model based approaches is the assumption that the semantic features are available in the desired form for a class category, e.g., clean attributes. However, in reality, they are hard to get. Getting clean semantic features requires a domain expert to annotate the attributes manually. Moreover, collecting a large number of attributes for all the class categories is again labor-intensive and expensive. Considering this, our generative model learns to transfer semantic knowledge from both noisy text descriptions (like Wikipedia articles) as well as semantic attributes for zero-shot learning and generalized zero-shot learning.

生成式模型是解决零样本学习最流行的方法。尽管最近取得了进展，但用于零样本学习的生成式模型仍然存在一些关键限制。这些模型在合成的和实际的未见图像特征之间存在很大的质量差距 $\left\lbrack  {{15},{24},{31},{35},{43}}\right\rbrack$ 。因此，广义零样本学习(GZSL)的性能受到影响，因为许多未见类别的合成特征被分类为已见类别。当前基于生成式模型的方法的第二个主要问题是假设语义特征以所需的形式存在于某个类别中，例如干净的属性。然而，在现实中，这些特征很难获取。获取干净的语义特征需要领域专家手动标注属性。此外，为所有类别收集大量属性同样既耗费人力又成本高昂。考虑到这一点，我们的生成式模型学习从嘈杂的文本描述(如维基百科文章)以及语义属性中转移语义知识，以用于零样本学习和广义零样本学习。

In this paper we propose a novel generative model called the LsrGAN. The LsrGAN leverages semantic relationships between seen and unseen categories and transfers the same to the generated image features. We implement this transfer through a unique semantic regularization framework called the Semantic Regularized Loss (SR-Loss). In Fig. 1, "Dolphin", an unseen class, has a high semantic similarity with classes such as "Killer whale" and "Humpback whale" from the seen class set. These two seen classes are the potential neighbors of the Dolphin in the visual space. Therefore, when we do not have the real visual features for the Dolphin class, we can use these neighbors to form indirect visual references for the Dolphin class. This illustrates the intuition behind the proposed SR-loss. The LsrGAN also trains a classifier to guide the feature generation. The main contributions of our work are:

在本文中，我们提出了一种名为LsrGAN的新型生成模型。LsrGAN利用已见类别和未见类别之间的语义关系，并将这种关系转移到生成的图像特征中。我们通过一个独特的语义正则化框架——语义正则化损失(Semantic Regularized Loss，SR - Loss)来实现这种转移。在图1中，“海豚”是一个未见类别，它与已见类别集中的“虎鲸”和“座头鲸”等类别具有较高的语义相似度。这两个已见类别是视觉空间中海豚的潜在邻居。因此，当我们没有海豚类别的真实视觉特征时，我们可以使用这些邻居为海豚类别形成间接的视觉参考。这说明了所提出的SR损失背后的直觉。LsrGAN还训练了一个分类器来指导特征生成。我们工作的主要贡献如下:

1. A generative model leveraging the semantic relationship (LsrGAN) between seen and unseen classes overcoming the overfitting concern towards seen classes.

1. 一种利用已见和未见类别之间语义关系的生成模型(LsrGAN)，克服了对已见类别的过拟合问题。

2. A novel semantic regularization framework that enables knowledge transfer across the visual and semantic domain. The framework can be easily integrated into any generalized zero-shot learning model.

2. 一种新颖的语义正则化框架，能够实现视觉和语义领域之间的知识转移。该框架可以轻松集成到任何广义零样本学习模型中。

3. We have conducted extensive experiments on seven widely used standard benchmark datasets to demonstrate that our model outperforms the previous state-of-the-art approaches.

3. 我们在七个广泛使用的标准基准数据集上进行了广泛的实验，以证明我们的模型优于先前的最先进方法。

## 2 Related Work

## 2 相关工作

Earlier work on ZSL was focused on learning the mapping between visual and semantic space in order to compensate for the lack of visual representation of the unseen classes. These approaches are known as Embedding methods. The initial work was focused on two-stage approaches where the attributes of an input image are estimated in the first stage, and the category label is determined in the second phase using highest attribute similarity. DAP and IAP [22] are examples of such an approach. Later, the use of bi-linear compatibility function led to promising ZSL results. Among these, ALE [1] and DEVISE [16] use ranking loss to learn the bilinear compatibility function. ESZSL [30] applies the square loss and explicitly regularizes the objective w.r.t. the Frobenius norm. Unlike standard embedding methods, $\left\lbrack  {8,{40}}\right\rbrack$ propose reverse mapping from the semantic to the visual space and perform nearest neighbor classification in the visual space. The hybrid models such as CONSE [26], SSE [41], and SYNC [7], discuss the idea of embedding both visual and semantic features into another intermediate space. These methods perform well in the ZSL setting. However, in GZSL, they show a high bias towards seen classes.

早期的零样本学习(ZSL)工作主要集中在学习视觉空间和语义空间之间的映射，以弥补未见类别的视觉表示的不足。这些方法被称为嵌入方法。最初的工作集中在两阶段方法上，在第一阶段估计输入图像的属性，在第二阶段使用最高属性相似度确定类别标签。DAP和IAP [22]就是这种方法的例子。后来，双线性兼容性函数的使用带来了有前景的零样本学习结果。其中，ALE [1]和DEVISE [16]使用排序损失来学习双线性兼容性函数。ESZSL [30]应用平方损失，并明确地相对于弗罗贝尼乌斯范数对目标进行正则化。与标准嵌入方法不同，$\left\lbrack  {8,{40}}\right\rbrack$提出了从语义空间到视觉空间的反向映射，并在视觉空间中进行最近邻分类。像CONSE [26]、SSE [41]和SYNC [7]这样的混合模型讨论了将视觉和语义特征都嵌入到另一个中间空间的想法。这些方法在零样本学习设置中表现良好。然而，在广义零样本学习(GZSL)中，它们对已见类别表现出较高的偏差。

![0195e037-bbaf-7de7-bf13-2cc5a64cb792_3_343_178_894_338_0.jpg](images/0195e037-bbaf-7de7-bf13-2cc5a64cb792_3_343_178_894_338_0.jpg)

Fig. 2. Conceptual illustration of our LsrGAN model. The basis of our model is a conditional WGAN. The novel SR-Loss is introduced to help the ${G}_{{\theta }_{g}}$ to understand the semantic relationship between classes and guide it for applying the same during visual feature generation. The ${G}_{{\theta }_{g}}$ will use ${\mathcal{T}}^{s}$ and ${\mathcal{T}}^{u}$ to generate visual features. The ${D}_{{\theta }_{d}}$ has two branches used to perform real/fake game and classification. Notice that when we train the ${G}_{{\theta }_{g}}$ using ${\mathcal{T}}^{u}$ , only the classification branch remains active in ${D}_{{\theta }_{d}}$ as the unseen visual features are not available.

图2. 我们的LsrGAN模型的概念示意图。我们模型的基础是一个条件WGAN。引入了新颖的SR损失，以帮助${G}_{{\theta }_{g}}$理解类别之间的语义关系，并在视觉特征生成过程中指导其应用这种关系。${G}_{{\theta }_{g}}$将使用${\mathcal{T}}^{s}$和${\mathcal{T}}^{u}$来生成视觉特征。${D}_{{\theta }_{d}}$有两个分支，用于进行真假判别游戏和分类。请注意，当我们使用${\mathcal{T}}^{u}$训练${G}_{{\theta }_{g}}$时，由于未见视觉特征不可用，${D}_{{\theta }_{d}}$中只有分类分支保持活跃。

Most of the mentioned embedding methods have a bias towards seen classes leading to substandard GZSL performance. Recently, Generative methods $\left\lbrack  {{10},{15},{18},{24},{31},{33},{35},{43}}\right\rbrack$ have attempted to address this concern by synthesizing unseen class features, leading to state of the art ZSL and GZSL performance. Among these, $\left\lbrack  {{10},{15},{24},{35},{43}}\right\rbrack$ are based on Generative Adversarial Networks (GAN), while [5,31] use Variational Autoencoders (VAE) for the ZSL. F-GAN [35] uses a Wasserstein GAN [4,17] to synthesize samples based on the class conditioned attribute. LisGAN [24] proposes a soul-sample regularizer to guide the sample generation process to stay close to a generic example of the seen class. Inspired by the cycle consistency loss[42], Felix et al. [15], propose a generative model that maps the generated visual features back to the original semantic feature, thus addressing the unpaired training issue during generation. These generative methods use the annotated attribute as semantic information for the feature generation. However, in reality, such a desired form of the semantic feature representation is hard to obtain. Hence, [13] suggests the use of Wikipedia descriptions for ZSL and GZSL. GAZSL [43] proposes a very first generative model that handles the Wikipedia description to generate features.

大多数上述嵌入方法对已见类别存在偏差，导致广义零样本学习(GZSL)性能不佳。最近，生成式方法 $\left\lbrack  {{10},{15},{18},{24},{31},{33},{35},{43}}\right\rbrack$ 试图通过合成未见类别的特征来解决这一问题，从而实现了最先进的零样本学习(ZSL)和广义零样本学习(GZSL)性能。其中，$\left\lbrack  {{10},{15},{24},{35},{43}}\right\rbrack$ 基于生成对抗网络(GAN)，而文献 [5,31] 使用变分自编码器(VAE)进行零样本学习。F - GAN [35] 使用 Wasserstein GAN [4,17] 基于类别条件属性合成样本。LisGAN [24] 提出了一种单样本正则化器，以引导样本生成过程接近已见类别的通用示例。受循环一致性损失 [42] 的启发，Felix 等人 [15] 提出了一种生成模型，该模型将生成的视觉特征映射回原始语义特征，从而解决了生成过程中的非配对训练问题。这些生成式方法使用带注释的属性作为特征生成的语义信息。然而，在现实中，这种理想形式的语义特征表示很难获得。因此，文献 [13] 建议使用维基百科描述进行零样本学习和广义零样本学习。GAZSL [43] 提出了第一个处理维基百科描述以生成特征的生成模型。

Although generative methods have been quite successful in ZSL, the unseen feature generation is biased towards seen classes leading to poor generalization in GZSL. For better generalization, we have proposed a novel SR-loss to leverage the inter-class relationships between seen and unseen classes in GANs. The idea of utilizing inter-class relationships has been addressed before with Triplet loss-based approaches $\left\lbrack  {3,6}\right\rbrack$ and using contrastive networks $\left\lbrack  {20}\right\rbrack$ . In this work, we propose a related approach using generative models. To best of our knowledge, such an approach using GANs has not been investigated.

尽管生成式方法在零样本学习中取得了相当大的成功，但未见特征的生成偏向于已见类别，导致广义零样本学习中的泛化能力较差。为了实现更好的泛化，我们提出了一种新颖的 SR 损失，以利用生成对抗网络(GAN)中已见和未见类别之间的类间关系。利用类间关系的想法之前已经通过基于三元组损失的方法 $\left\lbrack  {3,6}\right\rbrack$ 和使用对比网络 $\left\lbrack  {20}\right\rbrack$ 得到了解决。在这项工作中，我们提出了一种使用生成模型的相关方法。据我们所知，尚未有人研究过使用生成对抗网络的这种方法。

## 3 Proposed Approach

## 3 提出的方法

### 3.1 Problem Settings

### 3.1 问题设定

The zero-shot learning problem consists of seen (observed) and unseen (unobserved) categories of images and their corresponding text information. Images belonging to the seen categories are passed through a feature extractor (for e.g., ResNet-101) to yield features ${\left\{  {\mathbf{x}}_{i}^{s}\right\}  }_{i = 1}^{{n}_{s}}$ , where $\mathbf{x} \in  {\mathcal{X}}^{s}$ . The corresponding labels for these features are ${\left\{  {y}_{i}^{s}\right\}  }_{i = 1}^{{n}_{s}}$ , where ${y}^{s} \in  {\mathcal{Y}}^{s} = \left\{  {1,\ldots ,{C}_{s}}\right\}$ with ${C}_{s}$ seen categories. The image features for the unseen categories are denoted as ${\left\{  {\mathbf{x}}_{i}^{u}\right\}  }_{i = 1}^{{n}_{u}}$ , where $\mathbf{x} \in  {\mathcal{X}}^{u}$ , and the space of all image features is $\mathcal{X} \mathrel{\text{:=}} {\mathcal{X}}^{s} \cup  {\mathcal{X}}^{u}$ . As the name indicates, unseen categories are not observed, and the zero-shot learning model attempts to hallucinate these features with the rest of the information provided. Although we do not have the image features for the unseen categories, we are privy to the ${C}_{u}$ unseen categories, where the corresponding labels for the unseen image features would be ${\left\{  {y}_{i}^{u}\right\}  }_{i = 1}^{{n}_{u}}$ , with ${y}^{u} \in  {\mathcal{Y}}^{u} = \left\{  {{C}_{s} + 1,\ldots , C}\right\}$ , where $C = {C}_{s} + {C}_{u}$ . From the text domain, we have the semantic features for all categories which are either binary attribute vectors or Term-Frequency-Inverse-Document-Frequency (TF-IDF) vectors. The category-wise semantic features are denoted as ${\left\{  {\mathbf{t}}_{c}^{s}\right\}  }_{c = 1}^{{C}_{s}}$ , for seen categories and ${\left\{  {\mathbf{t}}_{c}^{u}\right\}  }_{c = {C}_{s} + 1}^{C}$ with $\mathbf{t} \in  \mathcal{T} \mathrel{\text{:=}} {\mathcal{T}}^{s} \cup  {\mathcal{T}}^{u}$ . The goal of zero-shot learning is to build a classifier ${\mathcal{F}}_{\text{zsl }} : {\mathcal{X}}^{u} \rightarrow  {\mathcal{Y}}^{u}$ , mapping image features to unseen categories, and the goal of the more difficult problem of generalized zero-shot learning is to build a classifier ${\mathcal{F}}_{\text{gzsl }} : \mathcal{X} \rightarrow  \mathcal{Y} \mathrel{\text{:=}} {\mathcal{Y}}^{s} \cup  {\mathcal{Y}}^{u}$ , mapping image features to seen and unseen categories.

零样本学习问题包含可见(已观测)和不可见(未观测)的图像类别及其对应的文本信息。属于可见类别的图像会通过一个特征提取器(例如ResNet - 101)以得到特征 ${\left\{  {\mathbf{x}}_{i}^{s}\right\}  }_{i = 1}^{{n}_{s}}$，其中 $\mathbf{x} \in  {\mathcal{X}}^{s}$。这些特征对应的标签是 ${\left\{  {y}_{i}^{s}\right\}  }_{i = 1}^{{n}_{s}}$，其中 ${y}^{s} \in  {\mathcal{Y}}^{s} = \left\{  {1,\ldots ,{C}_{s}}\right\}$，有 ${C}_{s}$ 个可见类别。不可见类别的图像特征表示为 ${\left\{  {\mathbf{x}}_{i}^{u}\right\}  }_{i = 1}^{{n}_{u}}$，其中 $\mathbf{x} \in  {\mathcal{X}}^{u}$，并且所有图像特征的空间是 $\mathcal{X} \mathrel{\text{:=}} {\mathcal{X}}^{s} \cup  {\mathcal{X}}^{u}$。顾名思义，不可见类别是未被观测到的，零样本学习模型试图利用所提供的其余信息来生成这些特征。虽然我们没有不可见类别的图像特征，但我们知道 ${C}_{u}$ 个不可见类别，其中不可见图像特征对应的标签将是 ${\left\{  {y}_{i}^{u}\right\}  }_{i = 1}^{{n}_{u}}$，其中 ${y}^{u} \in  {\mathcal{Y}}^{u} = \left\{  {{C}_{s} + 1,\ldots , C}\right\}$，其中 $C = {C}_{s} + {C}_{u}$。从文本领域来看，我们拥有所有类别的语义特征，这些特征可以是二进制属性向量或词频 - 逆文档频率(TF - IDF)向量。按类别划分的语义特征，对于可见类别表示为 ${\left\{  {\mathbf{t}}_{c}^{s}\right\}  }_{c = 1}^{{C}_{s}}$，对于不可见类别表示为 ${\left\{  {\mathbf{t}}_{c}^{u}\right\}  }_{c = {C}_{s} + 1}^{C}$，其中 $\mathbf{t} \in  \mathcal{T} \mathrel{\text{:=}} {\mathcal{T}}^{s} \cup  {\mathcal{T}}^{u}$。零样本学习的目标是构建一个分类器 ${\mathcal{F}}_{\text{zsl }} : {\mathcal{X}}^{u} \rightarrow  {\mathcal{Y}}^{u}$，将图像特征映射到不可见类别，而更具挑战性的广义零样本学习问题的目标是构建一个分类器 ${\mathcal{F}}_{\text{gzsl }} : \mathcal{X} \rightarrow  \mathcal{Y} \mathrel{\text{:=}} {\mathcal{Y}}^{s} \cup  {\mathcal{Y}}^{u}$，将图像特征映射到可见和不可见类别。

### 3.2 Adversarial Image Feature Generation

### 3.2 对抗性图像特征生成

Using the image features of the seen categories and the semantic features of the seen and unseen categories, we propose a generative adversarial network to hallucinate the unseen image features for each of the unseen categories. We apply a conditional Wasserstein Generative Adversarial Network (WGAN) to generate image features for the unseen categories using semantic features as input [4]. The WGAN aligns the real and generated image feature distributions. In addition, we have a feature classifier that is trained to classify image features into $C$ categories of seen and unseen classes. The components of the WGAN are described in the following.

利用可见类别的图像特征以及可见和不可见类别的语义特征，我们提出了一个生成对抗网络来为每个不可见类别生成不可见的图像特征。我们应用条件Wasserstein生成对抗网络(WGAN)，以语义特征作为输入来为不可见类别生成图像特征 [4]。WGAN使真实和生成的图像特征分布对齐。此外，我们有一个特征分类器，它经过训练可以将图像特征分类到 $C$ 个可见和不可见类别的类别中。下面将描述WGAN的各个组件。

Feature Generator: The conditional generator in the WGAN has parameters ${\theta }_{g}$ and is represented as ${G}_{{\theta }_{g}} : \mathcal{Z} \times  \mathcal{T} \rightarrow  \mathcal{X}$ , where $\mathcal{Z}$ is the space of random normal vectors $\mathcal{N}\left( {0, I}\right)$ of $\left| \mathcal{Z}\right|$ dimensions. Since the TF-IDF features from the Wikipedia articles may contain repetitive and non-discriminating feature information, we apply a denoising transformation upon the TF-IDF vector using a fully-connected neural network layer as proposed by [43]. The WGAN takes as input a random noise vector $\mathbf{z} \in  \mathcal{Z}$ concatenated with the semantic feature vector ${\mathbf{t}}_{c}$ for a category $c$ , and generates an image feature ${\widetilde{\mathbf{x}}}_{c} \leftarrow  {G}_{{\theta }_{g}}\left( {\mathbf{z},{\mathbf{t}}_{c}}\right)$ . The generator is trained to generate image features for both seen categories $\left( {{\widetilde{\mathbf{x}}}_{c}^{s} \leftarrow  {G}_{{\theta }_{g}}\left( {\mathbf{z},{\mathbf{t}}_{c}^{s}}\right) }\right)$ and unseen categories $\left( {{\widetilde{\mathbf{x}}}_{c}^{u} \leftarrow  {G}_{{\theta }_{g}}\left( {\mathbf{z},{\mathbf{t}}_{c}^{u}}\right) }\right)$ . In order to generate image features that are structurally similar to the real image features, we implement visual pivot regularization, ${\mathcal{L}}_{vp}$ that aligns the cluster centers of the real image features with the cluster centers of the generated image features for each of the ${C}_{s}$ categories [43]. This is implemented only for the seen categories where we have real image features.

特征生成器:WGAN(Wasserstein生成对抗网络)中的条件生成器具有参数 ${\theta }_{g}$，表示为 ${G}_{{\theta }_{g}} : \mathcal{Z} \times  \mathcal{T} \rightarrow  \mathcal{X}$，其中 $\mathcal{Z}$ 是 $\left| \mathcal{Z}\right|$ 维随机正态向量 $\mathcal{N}\left( {0, I}\right)$ 的空间。由于维基百科文章中的TF-IDF(词频-逆文档频率)特征可能包含重复且无区分性的特征信息，我们按照文献[43]的建议，使用全连接神经网络层对TF-IDF向量进行去噪变换。WGAN将随机噪声向量 $\mathbf{z} \in  \mathcal{Z}$ 与类别 $c$ 的语义特征向量 ${\mathbf{t}}_{c}$ 拼接后作为输入，并生成图像特征 ${\widetilde{\mathbf{x}}}_{c} \leftarrow  {G}_{{\theta }_{g}}\left( {\mathbf{z},{\mathbf{t}}_{c}}\right)$。生成器经过训练，可为已见类别 $\left( {{\widetilde{\mathbf{x}}}_{c}^{s} \leftarrow  {G}_{{\theta }_{g}}\left( {\mathbf{z},{\mathbf{t}}_{c}^{s}}\right) }\right)$ 和未见类别 $\left( {{\widetilde{\mathbf{x}}}_{c}^{u} \leftarrow  {G}_{{\theta }_{g}}\left( {\mathbf{z},{\mathbf{t}}_{c}^{u}}\right) }\right)$ 生成图像特征。为了生成在结构上与真实图像特征相似的图像特征，我们实施了视觉枢轴正则化 ${\mathcal{L}}_{vp}$，它能使每个 ${C}_{s}$ 类别的真实图像特征的聚类中心与生成图像特征的聚类中心对齐[43]。此操作仅针对我们拥有真实图像特征的已见类别执行。

$$
{\mathcal{L}}_{vp} = \mathop{\min }\limits_{{\theta }_{g}}\frac{1}{{C}_{s}}\mathop{\sum }\limits_{{c = 1}}^{{C}_{s}}\left| \right| {\mathbb{E}}_{\left( {\mathbf{x},\mathbf{y} = c}\right)  \sim  \left( {{\mathcal{X}}^{s},{\mathcal{Y}}^{s}}\right) }\left\lbrack  \mathbf{x}\right\rbrack   - {\mathbb{E}}_{\left( {\mathbf{z},{\mathbf{t}}_{c}^{s}}\right)  \sim  \left( {\mathcal{Z},{\mathcal{T}}^{s}}\right) }\left\lbrack  {{G}_{{\theta }_{g}}\left( {\mathbf{z},{\mathbf{t}}_{c}^{s}}\right) }\right\rbrack  \left| \right| . \tag{1}
$$

Feature Discriminator: We train the WGAN with an adversarial discriminator having two branches to perform the real/fake game and classification. The discriminator has parameters ${\theta }_{d}^{r}$ and ${\theta }_{d}^{c}$ for two branches respectively and is denoted as ${D}_{{\theta }_{d}}$ . The real/fake branch of the discriminator learns a mapping ${D}_{{\theta }_{J}^{r}} : \mathcal{X} \rightarrow  \mathbb{R}$ using the generated and real image features to output ${D}_{{\theta }_{J}^{r}}\left( {\widetilde{\mathbf{x}}}^{s}\right)$ and ${D}_{{\theta }_{d}^{r}}\left( {\mathbf{x}}^{s}\right)$ that are used to estimate the objective term ${\mathcal{L}}_{d}$ . The objective ${\mathcal{L}}_{d}$ is maximized w.r.t. the discriminator parameters ${\theta }_{d}^{r}$ and minimized w.r.t. the generator parameters ${\theta }_{g}$ .

特征判别器:我们使用一个具有两个分支的对抗判别器来训练WGAN，以进行真假判别游戏和分类。判别器的两个分支分别具有参数 ${\theta }_{d}^{r}$ 和 ${\theta }_{d}^{c}$，表示为 ${D}_{{\theta }_{d}}$。判别器的真假分支利用生成的和真实的图像特征学习映射 ${D}_{{\theta }_{J}^{r}} : \mathcal{X} \rightarrow  \mathbb{R}$，以输出 ${D}_{{\theta }_{J}^{r}}\left( {\widetilde{\mathbf{x}}}^{s}\right)$ 和 ${D}_{{\theta }_{d}^{r}}\left( {\mathbf{x}}^{s}\right)$，用于估计目标项 ${\mathcal{L}}_{d}$。目标 ${\mathcal{L}}_{d}$ 相对于判别器参数 ${\theta }_{d}^{r}$ 最大化，相对于生成器参数 ${\theta }_{g}$ 最小化。

$$
{\mathcal{L}}_{d} = \mathop{\min }\limits_{{\theta }_{g}}\mathop{\max }\limits_{{\theta }_{d}}{\mathbb{E}}_{\mathbf{x} \sim  {\mathcal{X}}^{s}}\left\lbrack  {{D}_{{\theta }_{d}}\left( \mathbf{x}\right) }\right\rbrack   - {\mathbb{E}}_{\left( {\mathbf{z},\mathbf{t}}\right)  \sim  \left( {\mathcal{Z},{\mathcal{T}}^{s}}\right) }\left\lbrack  {{D}_{{\theta }_{d}}\left( {{G}_{{\theta }_{g}}\left( {\mathbf{z},\mathbf{t}}\right) }\right) }\right\rbrack   - {\lambda }_{gp}{\mathcal{L}}_{gp} \tag{2}
$$

where, the first two terms control the alignment of real image feature and the generated image feature distributions. The third term is the gradient penalty to enforce the Lipschitz constraint with ${\mathcal{L}}_{gp} = {\left( {\begin{Vmatrix}{\nabla }_{\mathbf{x}}{D}_{{\theta }_{d}}\left( \mathbf{x}\right) \end{Vmatrix}}_{2} - 1\right) }^{2}$ where, input $x$ are real image features, generated image features and random samples on a straight line connecting real image features and generated image features [17]. The parameter ${\lambda }_{gp}$ controls the importance of the Lipschitz constraint. The discriminator parameters are trained using only seen category image features since ${\mathbf{x}}^{u}$ are unavailable.

其中，前两项控制真实图像特征和生成图像特征分布的对齐。第三项是梯度惩罚项，用于通过 ${\mathcal{L}}_{gp} = {\left( {\begin{Vmatrix}{\nabla }_{\mathbf{x}}{D}_{{\theta }_{d}}\left( \mathbf{x}\right) \end{Vmatrix}}_{2} - 1\right) }^{2}$ 强制执行Lipschitz(利普希茨)约束，其中输入 $x$ 是真实图像特征、生成图像特征以及连接真实图像特征和生成图像特征的直线上的随机样本[17]。参数 ${\lambda }_{gp}$ 控制Lipschitz约束的重要性。由于 ${\mathbf{x}}^{u}$ 不可用，判别器参数仅使用已见类别图像特征进行训练。

Feature Classifier: The category classifier has parameters ${\theta }_{d}^{c}$ and is denoted as ${D}_{{\theta }_{d}^{c}}$ . It is a softmax cross-entropy classifier for the generated and real image features ${\mathbf{x}}^{s},{\widetilde{\mathbf{x}}}^{s},{\widetilde{\mathbf{x}}}^{u}$ and is trained to minimize the loss ${\mathcal{L}}_{c}$ . For ease of notation we represent the real/generated image features as $\mathbf{x}$ and corresponding labels $y$

特征分类器:类别分类器具有参数 ${\theta }_{d}^{c}$，记为 ${D}_{{\theta }_{d}^{c}}$。它是一个用于生成图像特征和真实图像特征 ${\mathbf{x}}^{s},{\widetilde{\mathbf{x}}}^{s},{\widetilde{\mathbf{x}}}^{u}$ 的softmax交叉熵分类器，其训练目标是最小化损失 ${\mathcal{L}}_{c}$。为便于表示，我们将真实/生成的图像特征表示为 $\mathbf{x}$，对应的标签表示为 $y$

$$
{\mathcal{L}}_{c} = \mathop{\min }\limits_{{{\theta }_{g},{\theta }_{d}^{c}}} - {\mathbb{E}}_{\left( {\mathbf{x}, y}\right)  \sim  \left( {\mathcal{X},\mathcal{Y}}\right) }\left\lbrack  {\mathop{\sum }\limits_{{c = 1}}^{C}1\left( {y = c}\right) \log {\left( {D}_{{\theta }_{d}^{c}}\left( \mathbf{x}\right) \right) }_{c}}\right\rbrack  , \tag{3}
$$

where ${\left( {D}_{{\theta }_{d}^{c}}\left( \mathbf{x}\right) \right) }_{c}$ is the $c$ -th component of the $C$ -dimension softmax output and $1\left( {y = c}\right)$ is the indicator function. While the discriminator performs a marginal alignment of real and generated features, the classifier performs category based conditional alignment.

其中 ${\left( {D}_{{\theta }_{d}^{c}}\left( \mathbf{x}\right) \right) }_{c}$ 是 $C$ 维softmax输出的第 $c$ 个分量，$1\left( {y = c}\right)$ 是指示函数。鉴别器对真实特征和生成特征进行边缘对齐，而分类器则进行基于类别的条件对齐。

So far, in the proposed WGAN model the Generator generates image features from seen and unseen categories. The Discriminator aligns the image feature distributions and the Classifier performs image classification. The LsrGAN model is illustrated in Fig. 2. In the following we introduce a novel regularization technique that transfers knowledge across the semantic and image feature spaces for the unseen and seen categories respectively.

到目前为止，在所提出的WGAN模型中，生成器从已见类别和未见类别中生成图像特征。鉴别器对齐图像特征分布，分类器进行图像分类。LsrGAN模型如图2所示。接下来，我们将介绍一种新颖的正则化技术，该技术分别在未见类别和已见类别的语义空间和图像特征空间之间进行知识迁移。

### 3.3 Semantic Relationship Regularization

### 3.3 语义关系正则化

Conventional generative zero-shot learning approaches $\left\lbrack  {{24},{35},{43}}\right\rbrack$ , have poor generalization performance in GZSL since the generated visual features are biased towards the seen classes. We address this issue by proposing a novel regularization procedure that will explicitly transfer knowledge of unseen classes from the semantic domain to guide the model in generating distinct seen and unseen image features. We term this the "Semantic Regularized Loss (SR-Loss)".

传统的生成式零样本学习方法 $\left\lbrack  {{24},{35},{43}}\right\rbrack$ 在广义零样本学习(GZSL)中泛化性能较差，因为生成的视觉特征偏向于已见类别。我们通过提出一种新颖的正则化方法来解决这个问题，该方法将明确地从语义领域迁移未见类别的知识，以指导模型生成不同的已见和未见图像特征。我们将其称为“语义正则化损失(SR - 损失)”。

We argue that the visual and semantic feature spaces share a common underlying latent space that generates the visual and semantic features. We propose to exploit this relationship by transferring knowledge from the semantic space to the visual space to generate image features. Knowing the inter-class relationships in the semantic space can help us impose the same relationship constraints among the generated visual features. This is the idea behind the SR-Loss in the WGAN where we transfer inter-class relationships from the semantic domain to the visual domain. Figure 1 illustrates this concept. The visual similarity between class ${c}_{i}$ and ${c}_{j}$ is represented as ${\mathcal{X}}_{sim}\left( {{\mathbf{\mu }}_{{c}_{i}},{\mathbf{\mu }}_{{c}_{j}}}\right)$ , where ${\mathbf{\mu }}_{c}$ is the mean of the image features of class $c$ . Note that for visual similarity we are considering the relationship between the class centers and not between individual image features. Likewise, the semantic similarity between class ${c}_{i}$ and ${c}_{j}$ is represented as ${\mathcal{T}}_{\text{sim }}\left( {{\mathbf{t}}_{{c}_{i}},{\mathbf{t}}_{{c}_{j}}}\right)$ . For semantic similarity, we do not have the mean, since we only have one semantic vector ${\mathbf{t}}_{c}$ for every category, although the proposed approach can be extended to include multiple semantic feature vectors. We impose the following semantic relationship constraint for the image features,

我们认为视觉特征空间和语义特征空间共享一个共同的潜在空间，该潜在空间生成视觉特征和语义特征。我们建议利用这种关系，通过将知识从语义空间迁移到视觉空间来生成图像特征。了解语义空间中的类间关系可以帮助我们在生成的视觉特征之间施加相同的关系约束。这就是WGAN中SR - 损失的核心思想，我们将类间关系从语义领域迁移到视觉领域。图1说明了这一概念。类别 ${c}_{i}$ 和 ${c}_{j}$ 之间的视觉相似度表示为 ${\mathcal{X}}_{sim}\left( {{\mathbf{\mu }}_{{c}_{i}},{\mathbf{\mu }}_{{c}_{j}}}\right)$，其中 ${\mathbf{\mu }}_{c}$ 是类别 $c$ 的图像特征的均值。请注意，对于视觉相似度，我们考虑的是类别中心之间的关系，而不是单个图像特征之间的关系。同样，类别 ${c}_{i}$ 和 ${c}_{j}$ 之间的语义相似度表示为 ${\mathcal{T}}_{\text{sim }}\left( {{\mathbf{t}}_{{c}_{i}},{\mathbf{t}}_{{c}_{j}}}\right)$。对于语义相似度，我们没有均值，因为每个类别只有一个语义向量 ${\mathbf{t}}_{c}$，尽管所提出的方法可以扩展为包含多个语义特征向量。我们对图像特征施加以下语义关系约束:

$$
{\mathcal{T}}_{\text{sim }}\left( {{\mathbf{t}}_{{c}_{i}},{\mathbf{t}}_{{c}_{j}}}\right)  - {\epsilon }_{ij} \leq  {\mathcal{X}}_{\text{sim }}\left( {{\mathbf{\mu }}_{{c}_{i}},{\mathbf{\mu }}_{{c}_{j}}}\right)  \leq  {\mathcal{T}}_{\text{sim }}\left( {{\mathbf{t}}_{{c}_{i}},{\mathbf{t}}_{{c}_{j}}}\right)  + {\epsilon }_{ij}, \tag{4}
$$

where, hyper-parameter ${\epsilon }_{ij} \geq  0$ is a soft margin enforcing the similarity between semantic and image features for classes $i$ and $j$ . Large values of ${\epsilon }_{ij}$ allow more deviation between semantic similarities and visual similarities. We incorporate the constraint into the objective by applying the penalty method [25],

其中，超参数 ${\epsilon }_{ij} \geq  0$ 是一个软边界，用于强制类别 $i$ 和 $j$ 的语义特征和图像特征之间的相似度。${\epsilon }_{ij}$ 的值越大，语义相似度和视觉相似度之间的偏差就越大。我们通过应用惩罚方法 [25] 将该约束纳入目标函数:

$$
{p}_{{c}_{ij}}\left\lbrack  {\parallel \max \left( {0,{\mathcal{X}}_{\text{sim }}\left( {{\mathbf{\mu }}_{{c}_{i}},{\mathbf{\mu }}_{{c}_{j}}}\right)  - \left( {{\mathcal{T}}_{\text{sim }}\left( {{\mathbf{t}}_{{c}_{i}},{\mathbf{t}}_{{c}_{j}}}\right)  + {\epsilon }_{ij}}\right) }\right) {\parallel }^{2}}\right.
$$

$$
\left. {+{\begin{Vmatrix}\max \left( 0,\left( {\mathcal{T}}_{\text{sim }}\left( {\mathbf{t}}_{{c}_{i}},{\mathbf{t}}_{{c}_{j}}\right)  - {\epsilon }_{ij}\right)  - {\mathcal{X}}_{\text{sim }}\left( {\mathbf{\mu }}_{{c}_{i}},{\mathbf{\mu }}_{{c}_{j}}\right) \right) \end{Vmatrix}}^{2}}\right\rbrack  \text{,} \tag{5}
$$

where, ${p}_{{c}_{ij}}$ is the penalty for violating the constraint. The penalty becomes zero when the constraints are satisfied and is non-zero otherwise. We use cosine distance to compute the similarities.

其中，${p}_{{c}_{ij}}$ 是违反约束的惩罚项。当约束条件满足时，惩罚项为零，否则不为零。我们使用余弦距离来计算相似度。

We intend to transfer semantic inter-class relationships to enhance the image feature representations that are output from the generator. Consider a seen class ${c}_{i}$ . We estimate its semantic similarity ${\mathcal{T}}_{\text{sim }}\left( {{\mathbf{t}}_{{c}_{i}},{\mathbf{t}}_{{c}_{j}}}\right)$ with all the other seen semantic features ${\mathbf{t}}_{{c}_{j}}$ where $j \in  \left\{  {1,\ldots ,{C}_{s}}\right\}   \land  j \neq  i$ . Not all the similarities are important and for the ease of implementation we select the highest ${n}_{c}$ similarities that we wish to transfer. Let ${I}_{{c}_{i}}$ represent the set of ${n}_{c}$ seen categories with the highest semantic similarity with ${c}_{i}$ . We apply Eq. 5 to train the generator to output image features that satisfy the semantic similarity constraints against the top ${n}_{c}$ similarities from the seen categories. For the seen image categories, the objective function is,

我们打算转移语义类间关系，以增强从生成器输出的图像特征表示。考虑一个已见类别 ${c}_{i}$。我们估计它与所有其他已见语义特征 ${\mathbf{t}}_{{c}_{j}}$ 的语义相似度 ${\mathcal{T}}_{\text{sim }}\left( {{\mathbf{t}}_{{c}_{i}},{\mathbf{t}}_{{c}_{j}}}\right)$，其中 $j \in  \left\{  {1,\ldots ,{C}_{s}}\right\}   \land  j \neq  i$。并非所有相似度都很重要，为便于实现，我们选择希望转移的最高的 ${n}_{c}$ 个相似度。设 ${I}_{{c}_{i}}$ 表示与 ${c}_{i}$ 具有最高语义相似度的 ${n}_{c}$ 个已见类别的集合。我们应用公式 5 来训练生成器，以输出满足针对来自已见类别的前 ${n}_{c}$ 个相似度的语义相似度约束的图像特征。对于已见图像类别，目标函数为

$$
{\mathcal{L}}_{sr}^{s} = \mathop{\min }\limits_{{\theta }_{g}}\frac{1}{{C}_{s}}\mathop{\sum }\limits_{{i = 1}}^{{C}_{s}}\mathop{\sum }\limits_{{j \in  {I}_{{c}_{i}}}}\left\lbrack  {\parallel \max \left( {0,{\mathcal{X}}_{sim}\left( {{\mathbf{\mu }}_{{c}_{j}}^{s},{\widetilde{\mathbf{\mu }}}_{{c}_{i}}^{s}}\right)  - \left( {{\mathcal{T}}_{sim}\left( {{\mathbf{t}}_{{c}_{j}}^{s},{\mathbf{t}}_{{c}_{i}}^{s}}\right)  + \epsilon }\right) }\right) {\parallel }^{2}}\right.
$$

$$
\left. {+{\begin{Vmatrix}\max \left( 0,\left( {\mathcal{T}}_{\text{sim }}\left( {\mathbf{t}}_{{c}_{j}}^{s},{\mathbf{t}}_{{c}_{i}}^{s}\right)  - \epsilon \right)  - {\mathcal{X}}_{\text{sim }}\left( {\mathbf{\mu }}_{{c}_{j}}^{s},{\widetilde{\mathbf{\mu }}}_{{c}_{i}}^{s}\right) \right) \end{Vmatrix}}^{2}}\right\rbrack  \text{,} \tag{6}
$$

where, penalty ${p}_{ij} = 1$ , and ${\mathbf{\mu }}_{{c}_{j}}^{s} \mathrel{\text{:=}} {\mathbb{E}}_{\left( {\mathbf{x}, y = {c}_{j}}\right)  \sim  \left( {{\mathcal{X}}^{s},{\mathcal{Y}}^{s}}\right) }\left\lbrack  \mathbf{x}\right\rbrack$ is the mean of the image features for seen class ${c}_{j}$ , and ${\widetilde{\mathbf{\mu }}}_{{c}_{i}}^{s} \mathrel{\text{:=}} {\mathbb{E}}_{\mathbf{z} \sim  \mathcal{Z}}\left\lbrack  {{G}_{{\theta }_{g}}\left( {\mathbf{z},{\mathbf{t}}_{{c}_{i}}^{s}}\right) }\right\rbrack$ is the mean of the generated image features of seen class ${c}_{i}$ . We use a constant value of $\epsilon$ as the soft margin to simplify the solution. Similarly, the objective function for the unseen categories is,

其中，惩罚项 ${p}_{ij} = 1$，并且 ${\mathbf{\mu }}_{{c}_{j}}^{s} \mathrel{\text{:=}} {\mathbb{E}}_{\left( {\mathbf{x}, y = {c}_{j}}\right)  \sim  \left( {{\mathcal{X}}^{s},{\mathcal{Y}}^{s}}\right) }\left\lbrack  \mathbf{x}\right\rbrack$ 是已见类别 ${c}_{j}$ 的图像特征的均值，${\widetilde{\mathbf{\mu }}}_{{c}_{i}}^{s} \mathrel{\text{:=}} {\mathbb{E}}_{\mathbf{z} \sim  \mathcal{Z}}\left\lbrack  {{G}_{{\theta }_{g}}\left( {\mathbf{z},{\mathbf{t}}_{{c}_{i}}^{s}}\right) }\right\rbrack$ 是已见类别 ${c}_{i}$ 的生成图像特征的均值。我们使用常数 $\epsilon$ 作为软间隔，以简化求解。类似地，未见类别的目标函数为

$$
{\mathcal{L}}_{sr}^{u} = \mathop{\min }\limits_{{\theta }_{g}}\frac{1}{{C}_{u}}\mathop{\sum }\limits_{{i = {C}_{s} + 1}}^{C}\mathop{\sum }\limits_{{j \in  {I}_{{c}_{i}}}}\left\lbrack  {\parallel \max \left( {0,{\mathcal{X}}_{sim}\left( {{\mathbf{\mu }}_{{c}_{j}}^{s},{\widetilde{\mathbf{\mu }}}_{{c}_{i}}^{u}}\right)  - \left( {{\mathcal{T}}_{sim}\left( {{\mathbf{t}}_{{c}_{j}}^{s},{\mathbf{t}}_{{c}_{i}}^{u}}\right)  + {\epsilon }_{ij}}\right) }\right) {\parallel }^{2}}\right.
$$

$$
+ \left. {\begin{Vmatrix}\max \left( 0,\left( {\mathcal{T}}_{\text{sim }}\left( {\mathbf{t}}_{{c}_{j}}^{s},{\mathbf{t}}_{{c}_{i}}^{u}\right)  - {\epsilon }_{ij}\right)  - {\mathcal{X}}_{\text{sim }}\left( {\mathbf{\mu }}_{{c}_{j}}^{s},{\widetilde{\mathbf{\mu }}}_{{c}_{i}}^{u}\right) \right) \end{Vmatrix}}^{2}\right\rbrack  \text{,} \tag{7}
$$

where, ${\widetilde{\mathbf{\mu }}}_{{c}_{i}}^{u} \mathrel{\text{:=}} {\mathbb{E}}_{\mathbf{z} \sim  \mathcal{Z}}\left\lbrack  {{G}_{{\theta }_{g}}\left( {\mathbf{z},{\mathbf{t}}_{{c}_{i}}^{u}}\right) }\right\rbrack$ is the mean of the generated image features of unseen class ${c}_{i}$ . The time complexity of the proposed SR-loss is $\mathcal{O}\left( {B{n}_{c}\left| \mathcal{X}\right| E}\right)  +$ $\mathcal{O}\left( {{C}^{2}\left| \mathcal{T}\right| E}\right)  + \mathcal{O}\left( {{C}^{2}\log {n}_{c}E}\right)$ where $B,{n}_{c},\left| \mathcal{X}\right| , E, C$ and $\left| \mathcal{T}\right|$ denote the batch size, neighbor size, number of visual features, epoch, number of total classes and the size of the semantic features respectively. This shows the computation cost is manageable.

其中，${\widetilde{\mathbf{\mu }}}_{{c}_{i}}^{u} \mathrel{\text{:=}} {\mathbb{E}}_{\mathbf{z} \sim  \mathcal{Z}}\left\lbrack  {{G}_{{\theta }_{g}}\left( {\mathbf{z},{\mathbf{t}}_{{c}_{i}}^{u}}\right) }\right\rbrack$ 是未见类别 ${c}_{i}$ 的生成图像特征的均值。所提出的 SR 损失的时间复杂度为 $\mathcal{O}\left( {B{n}_{c}\left| \mathcal{X}\right| E}\right)  +$ $\mathcal{O}\left( {{C}^{2}\left| \mathcal{T}\right| E}\right)  + \mathcal{O}\left( {{C}^{2}\log {n}_{c}E}\right)$，其中 $B,{n}_{c},\left| \mathcal{X}\right| , E, C$ 和 $\left| \mathcal{T}\right|$ 分别表示批量大小、邻居大小、视觉特征数量、轮数、总类别数量和语义特征大小。这表明计算成本是可控的。

### 3.4 LsrGAN Objective Function

### 3.4 LsrGAN 目标函数

The LsrGAN leverages the semantic relationship between seen and unseen categories to generate robust image features for unseen categories using the objective function defined in Eq. 6 and 7. The model generates robust seen image features conditioned by the regularizer in Eq. 1. The LsrGAN trains a classifier over all the $C$ categories as outlined in Eq. 3. The LsrGAN is based on a WGAN model that aligns the image feature distributions using the objective function defined in Eq. 2. The overall objective function of the LsrGAN model is given by,

LsrGAN 利用已见和未见类别之间的语义关系，使用公式 6 和 7 中定义的目标函数为未见类别生成鲁棒的图像特征。该模型在公式 1 中的正则化器的约束下生成鲁棒的已见图像特征。LsrGAN 按照公式 3 中概述的方法在所有 $C$ 个类别上训练一个分类器。LsrGAN 基于一个 WGAN 模型，该模型使用公式 2 中定义的目标函数来对齐图像特征分布。LsrGAN 模型的总体目标函数由下式给出

$$
{\lambda }_{c}{\mathcal{L}}_{c} + {\mathcal{L}}_{d} + {\lambda }_{vp}{\mathcal{L}}_{vp} + {\lambda }_{sr}\left( {{\mathcal{L}}_{sr}^{s} + {\mathcal{L}}_{sr}^{u}}\right)  \tag{8}
$$

where, ${\lambda }_{c},{\lambda }_{vp}$ and ${\lambda }_{sr}$ are hyper parameters controlling the importance of each of the loss terms. Unlike standard zero-shot learning models that generate image features and then have to train a supervised classifier $\left\lbrack  {{24},{35},{43}}\right\rbrack$ , the LsrGAN model has an inbuilt classifier that can also be used for evaluating zero-shot learning and generalized zero-shot learning.

其中，${\lambda }_{c},{\lambda }_{vp}$ 和 ${\lambda }_{sr}$ 是控制每个损失项重要性的超参数。与生成图像特征然后必须训练一个有监督分类器 $\left\lbrack  {{24},{35},{43}}\right\rbrack$ 的标准零样本学习模型不同，LsrGAN 模型有一个内置分类器，也可用于评估零样本学习和广义零样本学习。

## 4 Experiments

## 4 实验

### 4.1 Datasets

### 4.1 数据集

Attribute-Based Datasets: We conduct experiments on three widely used attribute-based datasets: Animal with Attributes (AWA) [22], Caltech-UCSD-Birds 200-2011 (CUB) [34] and Scene UNderstanding (SUN) [27]. AWA is a medium scale coarse-grained animal dataset having 50 animal classes with 85 attributes annotated. CUB is a fine-grained, medium-scale dataset having 200 bird classes annotated with 312 attributes. SUN is a medium scale dataset having 717 types of scenes with 102 annotated attributes. We followed the split mentioned in [36] to have a fair comparison with existing approaches.

基于属性的数据集:我们在三个广泛使用的基于属性的数据集上进行了实验:动物属性数据集(Animal with Attributes，AWA)[22]、加州理工学院 - 加州大学圣地亚哥分校鸟类 200 - 2011 数据集(Caltech - UCSD - Birds 200 - 2011，CUB)[34]和场景理解数据集(Scene UNderstanding，SUN)[27]。AWA 是一个中等规模的粗粒度动物数据集，有 50 个动物类别，标注了 85 个属性。CUB 是一个细粒度、中等规模的数据集，有 200 个鸟类类别，标注了 312 个属性。SUN 是一个中等规模的数据集，有 717 种场景类型，标注了 102 个属性。我们遵循文献 [36] 中提到的划分方式，以便与现有方法进行公平比较。

Wikipedia Descriptions-Based Datasets: In order to address a more challenging ZSL problem with Wikipedia descriptions as auxiliary information, we have used two common fine-grained datasets with textual descriptions: CUB and North America Birds (NAB) [32]. The NAB dataset is larger compared to CUB having 1011 classes in total. We have used two splits, suggested by [14] in our experiments to have a fair comparison with other methods. The splits are termed as Super-Category-Shared (SCS, Easy split) and Super-Category-Exclusive (SCE, Hard split). These splits represent the similarity between seen and unseen classes. The SCS-split has at least one seen class for every unseen class belonging to the same parent. For example, "Harris's Hawk" in the unseen set and "Cooper's Hawk" in the seen set belong to the same parent category, "Hawks." On the other hand, in the SCE-split, the parent categories are disjoint for the seen and unseen classes. Therefore, SCS and SCE splits are considered as Easy and Hard splits. The details for each dataset and class splits are given in Table 1.

基于维基百科描述的数据集:为了解决以维基百科描述作为辅助信息的更具挑战性的零样本学习问题，我们使用了两个常见的带有文本描述的细粒度数据集:CUB 和北美鸟类数据集(North America Birds，NAB)[32]。与 CUB 相比，NAB 数据集更大，总共有 1011 个类别。在我们的实验中，我们使用了文献 [14] 建议的两种划分方式，以便与其他方法进行公平比较。这两种划分方式分别称为超类别共享划分(Super - Category - Shared，SCS，简单划分)和超类别互斥划分(Super - Category - Exclusive，SCE，困难划分)。这些划分代表了已见类别和未见类别之间的相似性。在 SCS 划分中，每个属于同一父类别的未见类别至少有一个已见类别。例如，未见集合中的“哈里斯鹰”和已见集合中的“库珀鹰”属于同一父类别“鹰”。另一方面，在 SCE 划分中，已见类别和未见类别的父类别是不相交的。因此，SCS 和 SCE 划分分别被视为简单划分和困难划分。每个数据集和类别划分的详细信息见表 1。

Table 1. Dataset information. For the attribute-based datasets, the (number) in seen classes denotes the number of classes used for test in GZSL.

表 1. 数据集信息。对于基于属性的数据集，已见类别中的(数量)表示广义零样本学习中用于测试的类别数量。

<table><tr><td rowspan="2"/><td colspan="3">Attribute-based</td><td colspan="4">Wikipedia descriptions</td></tr><tr><td>AWA</td><td>CUB</td><td>SUN</td><td>CUB (Easy)</td><td>CUB (Hard)</td><td>NAB (Easy)</td><td>NAB (Hard)</td></tr><tr><td>No. of Samples</td><td>30,475</td><td>11,788</td><td>14,340</td><td>11,788</td><td>11,788</td><td>48,562</td><td>48,562</td></tr><tr><td>No. of Features</td><td>85</td><td>312</td><td>102</td><td>7551</td><td>7551</td><td>13217</td><td>13217</td></tr><tr><td>No. of Seen classes</td><td>40(13)</td><td>150(50)</td><td>645(65)</td><td>150</td><td>160</td><td>323</td><td>323</td></tr><tr><td>No. of Unseen classes</td><td>10</td><td>50</td><td>72</td><td>50</td><td>40</td><td>81</td><td>81</td></tr></table>

<table><tbody><tr><td rowspan="2"></td><td colspan="3">基于属性的</td><td colspan="4">维基百科描述</td></tr><tr><td>美国威士忌协会(American Whiskey Association，这里AWA可能有多种含义，需结合具体场景确定，暂按常见的协会翻译)</td><td>加州理工学院鸟类数据集(Caltech-UCSD Birds-200-2011，CUB是该数据集简称)</td><td>斯坦福大学场景数据库(Scene UNderstanding, SUN)</td><td>加州理工学院鸟类数据集(简单)</td><td>加州理工学院鸟类数据集(困难)</td><td>北美鸟类数据集(简单)(North American Birds，NAB)</td><td>北美鸟类数据集(困难)(North American Birds，NAB)</td></tr><tr><td>样本数量</td><td>30,475</td><td>11,788</td><td>14,340</td><td>11,788</td><td>11,788</td><td>48,562</td><td>48,562</td></tr><tr><td>特征数量</td><td>85</td><td>312</td><td>102</td><td>7551</td><td>7551</td><td>13217</td><td>13217</td></tr><tr><td>已见类别数量</td><td>40(13)</td><td>150(50)</td><td>645(65)</td><td>150</td><td>160</td><td>323</td><td>323</td></tr><tr><td>未见类别数量</td><td>10</td><td>50</td><td>72</td><td>50</td><td>40</td><td>81</td><td>81</td></tr></tbody></table>

### 4.2 Implementation Details and Performance Metrics

### 4.2 实现细节与性能指标

The 2048-dimensional ResNet-101 [19] features are considered as a real visual feature for attribute-based datasets, and part-based features (e.g., belly, leg, wing, etc.) from VPDE-net [39] are used for the Wikipedia based datasets, as suggested by $\left\lbrack  {{35},{43}}\right\rbrack$ . We have utilized the TF-IDF to extract the features from the Wikipedia descriptions. For a fair comparison, all of our experiment settings are kept the same as reported in $\left\lbrack  {{35},{36},{43}}\right\rbrack$ .

如 $\left\lbrack  {{35},{43}}\right\rbrack$ 所建议，对于基于属性的数据集，将2048维的残差网络 - 101(ResNet - 101)[19] 特征视为真实的视觉特征；对于基于维基百科的数据集，则使用来自视觉部分检测与提取网络(VPDE - net)[39] 的基于部位的特征(例如腹部、腿部、翅膀等)。我们利用词频 - 逆文档频率(TF - IDF)从维基百科描述中提取特征。为进行公平比较，我们所有的实验设置均与 $\left\lbrack  {{35},{36},{43}}\right\rbrack$ 中报告的保持一致。

Table 2. ZSL and GZSL results on AWA, CUB, and SUN with attributes as semantic information. T1 indicates the Top-1% accuracy in the ZSL setting. On the other hand, "U", "S" and "H" denotes the Top-1% accuracy for the unseen, seen, and Harmonic mean (seen + unseen).

表2. 在属性作为语义信息的情况下，在动物属性数据集(AWA)、加州理工学院鸟类数据集(CUB)和场景属性数据集(SUN)上的零样本学习(ZSL)和广义零样本学习(GZSL)结果。T1表示零样本学习设置下的前1%准确率。另一方面，“U”、“S”和“H”分别表示未见类别、已见类别和调和均值(已见 + 未见)的前1%准确率。

<table><tr><td rowspan="3">Methods</td><td colspan="3">Zero-shot learning</td><td colspan="9">Generalized zero-shot learning</td></tr><tr><td>AWA</td><td>CUB</td><td>SUN</td><td colspan="3">AwA</td><td colspan="3">CUB</td><td colspan="3">SUN</td></tr><tr><td>T1</td><td>T1</td><td>T1</td><td>U</td><td>S</td><td>H</td><td>U</td><td>S</td><td>H</td><td>U</td><td>S</td><td>H</td></tr><tr><td>DAP [22]</td><td>44.1</td><td>40.0</td><td>39.9</td><td>0.0</td><td>88.7</td><td>0.0</td><td>1.7</td><td>67.9</td><td>3.3</td><td>4.2</td><td>25.2</td><td>7.2</td></tr><tr><td>CONSE [26]</td><td>45.6</td><td>34.3</td><td>38.8</td><td>0.4</td><td>88.6</td><td>0.8</td><td>1.6</td><td>72.2</td><td>3.1</td><td>6.8</td><td>39.9</td><td>11.6</td></tr><tr><td>SSE [41]</td><td>60.1</td><td>43.9</td><td>51.5</td><td>7.0</td><td>80.5</td><td>12.9</td><td>8.5</td><td>46.9</td><td>14.4</td><td>2.1</td><td>36.4</td><td>4.0</td></tr><tr><td>DeViSE [16]</td><td>54.2</td><td>50.0</td><td>56.5</td><td>13.4</td><td>68.7</td><td>22.4</td><td>23.8</td><td>53.0</td><td>32.8</td><td>16.9</td><td>27.4</td><td>20.9</td></tr><tr><td>SJE [2]</td><td>65.6</td><td>53.9</td><td>53.7</td><td>11.3</td><td>74.6</td><td>19.6</td><td>23.5</td><td>59.2</td><td>33.6</td><td>14.7</td><td>30.5</td><td>19.8</td></tr><tr><td>ESZSL [30]</td><td>58.2</td><td>53.9</td><td>54.5</td><td>5.9</td><td>77.8</td><td>11.0</td><td>2.4</td><td>70.1</td><td>4.6</td><td>11.0</td><td>27.9</td><td>15.8</td></tr><tr><td>ALE [1]</td><td>59.9</td><td>54.9</td><td>58.1</td><td>14.0</td><td>81.8</td><td>23.9</td><td>4.6</td><td>73.7</td><td>8.7</td><td>21.8</td><td>33.1</td><td>26.3</td></tr><tr><td>SYNC [7]</td><td>54.0</td><td>55.6</td><td>56.3</td><td>10.0</td><td>90.5</td><td>18.0</td><td>7.4</td><td>66.3</td><td>13.3</td><td>7.9</td><td>43.3</td><td>13.4</td></tr><tr><td>SAE [21]</td><td>53.0</td><td>33.3</td><td>40.3</td><td>1.1</td><td>82.2</td><td>2.2</td><td>0.4</td><td>80.9</td><td>0.9</td><td>8.8</td><td>18.0</td><td>11.8</td></tr><tr><td>DEM [40]</td><td>68.4</td><td>51.7</td><td>61.9</td><td>30.5</td><td>86.4</td><td>45.1</td><td>11.1</td><td>75.1</td><td>19.4</td><td>20.5</td><td>34.3</td><td>25.6</td></tr><tr><td>PSR [3]</td><td>63.8</td><td>56.0</td><td>61.4</td><td>20.7</td><td>73.8</td><td>32.3</td><td>24.6</td><td>54.3</td><td>33.9</td><td>20.8</td><td>37.2</td><td>26.7</td></tr><tr><td>TCN [20]</td><td>70.3</td><td>59.5</td><td>61.5</td><td>49.4</td><td>76.5</td><td>60.0</td><td>52.6</td><td>52.0</td><td>52.3</td><td>31.2</td><td>37.3</td><td>34.0</td></tr><tr><td>GAZSL [43]</td><td>68.2</td><td>55.8</td><td>61.3</td><td>19.2</td><td>86.5</td><td>31.4</td><td>23.9</td><td>60.6</td><td>34.3</td><td>21.7</td><td>34.5</td><td>26.7</td></tr><tr><td>F-GAN [35]</td><td>68.2</td><td>57.3</td><td>60.8</td><td>57.9</td><td>61.4</td><td>59.6</td><td>43.7</td><td>57.7</td><td>49.7</td><td>42.6</td><td>36.6</td><td>39.4</td></tr><tr><td>cycle-CLSWGAN [15]</td><td>66.3</td><td>58.4</td><td>60.0</td><td>56.9</td><td>64.0</td><td>60.2</td><td>45.7</td><td>61.0</td><td>52.3</td><td>49.4</td><td>33.6</td><td>40.0</td></tr><tr><td>LisGAN [24]</td><td>70.6</td><td>58.8</td><td>61.7</td><td>52.6</td><td>76.3</td><td>62.3</td><td>46.5</td><td>57.9</td><td>51.6</td><td>42.9</td><td>37.8</td><td>40.2</td></tr><tr><td>LsrGAN [ours]</td><td>66.4</td><td>60.3</td><td>62.5</td><td>54.6</td><td>74.6</td><td>63.0</td><td>48.1</td><td>59.1</td><td>53.0</td><td>44.8</td><td>37.7</td><td>40.9</td></tr></table>

<table><tbody><tr><td rowspan="3">方法</td><td colspan="3">零样本学习</td><td colspan="9">广义零样本学习</td></tr><tr><td>AWA</td><td>CUB</td><td>SUN</td><td colspan="3">AwA</td><td colspan="3">CUB</td><td colspan="3">SUN</td></tr><tr><td>T1</td><td>T1</td><td>T1</td><td>U</td><td>S</td><td>H</td><td>U</td><td>S</td><td>H</td><td>U</td><td>S</td><td>H</td></tr><tr><td>属性判别投影法(DAP) [22]</td><td>44.1</td><td>40.0</td><td>39.9</td><td>0.0</td><td>88.7</td><td>0.0</td><td>1.7</td><td>67.9</td><td>3.3</td><td>4.2</td><td>25.2</td><td>7.2</td></tr><tr><td>基于上下文的语义嵌入法(CONSE) [26]</td><td>45.6</td><td>34.3</td><td>38.8</td><td>0.4</td><td>88.6</td><td>0.8</td><td>1.6</td><td>72.2</td><td>3.1</td><td>6.8</td><td>39.9</td><td>11.6</td></tr><tr><td>语义空间嵌入法(SSE) [41]</td><td>60.1</td><td>43.9</td><td>51.5</td><td>7.0</td><td>80.5</td><td>12.9</td><td>8.5</td><td>46.9</td><td>14.4</td><td>2.1</td><td>36.4</td><td>4.0</td></tr><tr><td>深度视觉语义嵌入法(DeViSE) [16]</td><td>54.2</td><td>50.0</td><td>56.5</td><td>13.4</td><td>68.7</td><td>22.4</td><td>23.8</td><td>53.0</td><td>32.8</td><td>16.9</td><td>27.4</td><td>20.9</td></tr><tr><td>语义联合嵌入法(SJE) [2]</td><td>65.6</td><td>53.9</td><td>53.7</td><td>11.3</td><td>74.6</td><td>19.6</td><td>23.5</td><td>59.2</td><td>33.6</td><td>14.7</td><td>30.5</td><td>19.8</td></tr><tr><td>高效零样本学习法(ESZSL) [30]</td><td>58.2</td><td>53.9</td><td>54.5</td><td>5.9</td><td>77.8</td><td>11.0</td><td>2.4</td><td>70.1</td><td>4.6</td><td>11.0</td><td>27.9</td><td>15.8</td></tr><tr><td>属性标签嵌入法(ALE) [1]</td><td>59.9</td><td>54.9</td><td>58.1</td><td>14.0</td><td>81.8</td><td>23.9</td><td>4.6</td><td>73.7</td><td>8.7</td><td>21.8</td><td>33.1</td><td>26.3</td></tr><tr><td>同步生成对抗网络法(SYNC) [7]</td><td>54.0</td><td>55.6</td><td>56.3</td><td>10.0</td><td>90.5</td><td>18.0</td><td>7.4</td><td>66.3</td><td>13.3</td><td>7.9</td><td>43.3</td><td>13.4</td></tr><tr><td>堆叠自编码器法(SAE) [21]</td><td>53.0</td><td>33.3</td><td>40.3</td><td>1.1</td><td>82.2</td><td>2.2</td><td>0.4</td><td>80.9</td><td>0.9</td><td>8.8</td><td>18.0</td><td>11.8</td></tr><tr><td>判别嵌入模型法(DEM) [40]</td><td>68.4</td><td>51.7</td><td>61.9</td><td>30.5</td><td>86.4</td><td>45.1</td><td>11.1</td><td>75.1</td><td>19.4</td><td>20.5</td><td>34.3</td><td>25.6</td></tr><tr><td>原型语义表示法(PSR) [3]</td><td>63.8</td><td>56.0</td><td>61.4</td><td>20.7</td><td>73.8</td><td>32.3</td><td>24.6</td><td>54.3</td><td>33.9</td><td>20.8</td><td>37.2</td><td>26.7</td></tr><tr><td>时序卷积网络法(TCN) [20]</td><td>70.3</td><td>59.5</td><td>61.5</td><td>49.4</td><td>76.5</td><td>60.0</td><td>52.6</td><td>52.0</td><td>52.3</td><td>31.2</td><td>37.3</td><td>34.0</td></tr><tr><td>广义零样本学习生成对抗网络法(GAZSL) [43]</td><td>68.2</td><td>55.8</td><td>61.3</td><td>19.2</td><td>86.5</td><td>31.4</td><td>23.9</td><td>60.6</td><td>34.3</td><td>21.7</td><td>34.5</td><td>26.7</td></tr><tr><td>基于f散度的生成对抗网络法(F - GAN) [35]</td><td>68.2</td><td>57.3</td><td>60.8</td><td>57.9</td><td>61.4</td><td>59.6</td><td>43.7</td><td>57.7</td><td>49.7</td><td>42.6</td><td>36.6</td><td>39.4</td></tr><tr><td>循环条件最小二乘沃尔什斯坦生成对抗网络法(cycle - CLSWGAN) [15]</td><td>66.3</td><td>58.4</td><td>60.0</td><td>56.9</td><td>64.0</td><td>60.2</td><td>45.7</td><td>61.0</td><td>52.3</td><td>49.4</td><td>33.6</td><td>40.0</td></tr><tr><td>LisGAN [24]</td><td>70.6</td><td>58.8</td><td>61.7</td><td>52.6</td><td>76.3</td><td>62.3</td><td>46.5</td><td>57.9</td><td>51.6</td><td>42.9</td><td>37.8</td><td>40.2</td></tr><tr><td>我们提出的LsrGAN</td><td>66.4</td><td>60.3</td><td>62.5</td><td>54.6</td><td>74.6</td><td>63.0</td><td>48.1</td><td>59.1</td><td>53.0</td><td>44.8</td><td>37.7</td><td>40.9</td></tr></tbody></table>

The base block of our model is GAN, which is implemented using a multilayer perceptron. Specifically, the feature generator ${G}_{{\theta }_{a}}$ has one hidden unit having 4096 neurons and LeakyReLU as an activation function. For attribute-based datasets, we intend to get the top max-pooling units of ResNet - 101 (visual features). Hence, the output layer has ReLU activation in the feature generator. On the other hand, for the Wikipedia based datasets, we have used Tanh as an output activation for the feature generator since the VPDE-net feature varies from -1 to 1. $\mathcal{Z}$ is sampled from the normal Gaussian distribution. To perform the denoising and dimensionality reduction from Wikipedia descriptions, we have employed a fully connected layer with a feature generator. Also, notice that the semantic similarity for the SR-Loss is computed using the denoiser's output in Wikipedia based datasets. We will discard this layer when dealing with attribute-based datasets. In our model, the discriminator ${D}_{{\theta }_{d}}$ has two branches. One is used to play the real/fake game, and the other performs the classification on the generated/real visual feature. The discriminator also has 4096 units in the hidden layer with ReLU as an activation. Since the cosine distance is less prone to the curse of dimensionality when the features are sparse (semantic features), we have considered it in the SR-loss.

我们模型的基础模块是生成对抗网络(GAN)，它通过多层感知器实现。具体而言，特征生成器 ${G}_{{\theta }_{a}}$ 有一个隐藏单元，该单元包含4096个神经元，并使用LeakyReLU作为激活函数。对于基于属性的数据集，我们打算获取ResNet - 101(视觉特征)的最大池化单元。因此，特征生成器的输出层使用ReLU激活函数。另一方面，对于基于维基百科的数据集，由于VPDE - net特征的取值范围是从 - 1到1，我们在特征生成器的输出层使用Tanh作为激活函数。$\mathcal{Z}$ 是从正态高斯分布中采样得到的。为了对维基百科描述进行去噪和降维，我们使用了一个与特征生成器相连的全连接层。此外，请注意，在基于维基百科的数据集里，SR损失的语义相似度是使用去噪器的输出来计算的。在处理基于属性的数据集时，我们会舍弃这一层。在我们的模型中，判别器 ${D}_{{\theta }_{d}}$ 有两个分支。一个用于进行真假判别游戏，另一个用于对生成的/真实的视觉特征进行分类。判别器的隐藏层也有4096个单元，使用ReLU作为激活函数。由于当特征稀疏(语义特征)时，余弦距离不太容易受到维度灾难的影响，我们在SR损失中考虑使用它。

To perform the zero-shot recognition we have used nearest neighbor prediction on datasets having Wikipedia descriptions, and the classifier attached to the discriminator for the attributes based recognition. Notice that the classifier is not re-trained for the recognition part. The Top-1 accuracy is used to assess the ZSL setting. Furthermore, to capture the more realistic scenario, we have examine the Generalized zero-shot recognition as well. As suggested by [9], we report the area under the seen and unseen curve (AUC score) as GZSL performance metric for Wikipedia based datasets, and the harmonic mean of the seen and unseen Top-1 accuracies for attribute based dataset. Notice that the choice of these measures and predictions models is to make a fair comparison with existing methods.

为了进行零样本识别，对于有维基百科描述的数据集，我们使用最近邻预测；对于基于属性的识别，我们使用连接到判别器的分类器。请注意，分类器在识别部分不进行重新训练。我们使用Top - 1准确率来评估零样本学习(ZSL)设置。此外，为了捕捉更现实的场景，我们也研究了广义零样本识别(GZSL)。正如文献[9]所建议的，对于基于维基百科的数据集，我们报告可见类和不可见类曲线下的面积(AUC分数)作为GZSL性能指标；对于基于属性的数据集，我们报告可见类和不可见类的Top - 1准确率的调和平均值。请注意，选择这些度量和预测模型是为了与现有方法进行公平比较。

Table 3. ZSL and GZSL results on CUB and NAB datasets with Wikipedia descriptions as semantic information on the two-split setting. We have used Top-1% accuracy and Seen-Unseen AUC (%) for ZSL and GZSL, respectively.

表3. 在CUB和NAB数据集上，以维基百科描述作为语义信息，在二分设置下的零样本学习(ZSL)和广义零样本学习(GZSL)结果。我们分别使用Top - 1%准确率和可见 - 不可见AUC(%)来评估ZSL和GZSL。

<table><tr><td rowspan="3">Methods</td><td colspan="4">Zero-shot Learning</td><td colspan="4">Generalized zero-shot Learning</td></tr><tr><td colspan="2">CUB</td><td colspan="2">NAB</td><td colspan="2">CUB</td><td colspan="2">NAB</td></tr><tr><td>Easy</td><td>Hard</td><td>Easy</td><td>Hard</td><td>Easy</td><td>Hard</td><td>Easy</td><td>Hard</td></tr><tr><td>WAC-Linear [13]</td><td>27.0</td><td>5.0</td><td>-</td><td>-</td><td>23.9</td><td>4.9</td><td>23.5</td><td>-</td></tr><tr><td>WAC-Kernal [12]</td><td>33.5</td><td>7.7</td><td>11.4</td><td>6.0</td><td>14.7</td><td>4.4</td><td>9.3</td><td>2.3</td></tr><tr><td>ESZSL [30]</td><td>28.5</td><td>7.4</td><td>24.3</td><td>6.3</td><td>18.5</td><td>4.5</td><td>9.2</td><td>2.9</td></tr><tr><td>ZSLNS [28]</td><td>29.1</td><td>7.3</td><td>24.5</td><td>6.8</td><td>14.7</td><td>4.4</td><td>9.3</td><td>2.3</td></tr><tr><td>Sync-fast [7]</td><td>28.0</td><td>8.6</td><td>18.4</td><td>3.8</td><td>13.1</td><td>4.0</td><td>2.7</td><td>3.5</td></tr><tr><td>ZSLPP [14]</td><td>37.2</td><td>9.7</td><td>30.3</td><td>8.1</td><td>30.4</td><td>6.1</td><td>12.6</td><td>3.5</td></tr><tr><td>GAZSL [43]</td><td>43.7</td><td>10.3</td><td>35.6</td><td>8.6</td><td>35.4</td><td>8.7</td><td>20.4</td><td>5.8</td></tr><tr><td>LsrGAN [ours]</td><td>45.2</td><td>14.2</td><td>36.4</td><td>9.04</td><td>39.5</td><td>12.1</td><td>23.2</td><td>6.4</td></tr></table>

<table><tbody><tr><td rowspan="3">方法</td><td colspan="4">零样本学习</td><td colspan="4">广义零样本学习</td></tr><tr><td colspan="2">加州理工学院鸟类数据集(CUB)</td><td colspan="2">北美鸟类数据集(NAB)</td><td colspan="2">加州理工学院鸟类数据集(CUB)</td><td colspan="2">北美鸟类数据集(NAB)</td></tr><tr><td>简单</td><td>困难</td><td>简单</td><td>困难</td><td>简单</td><td>困难</td><td>简单</td><td>困难</td></tr><tr><td>线性加权属性分类器(WAC - Linear) [13]</td><td>27.0</td><td>5.0</td><td>-</td><td>-</td><td>23.9</td><td>4.9</td><td>23.5</td><td>-</td></tr><tr><td>核加权属性分类器(WAC - Kernal) [12]</td><td>33.5</td><td>7.7</td><td>11.4</td><td>6.0</td><td>14.7</td><td>4.4</td><td>9.3</td><td>2.3</td></tr><tr><td>高效半监督零样本学习(ESZSL) [30]</td><td>28.5</td><td>7.4</td><td>24.3</td><td>6.3</td><td>18.5</td><td>4.5</td><td>9.2</td><td>2.9</td></tr><tr><td>零样本学习网络搜索(ZSLNS) [28]</td><td>29.1</td><td>7.3</td><td>24.5</td><td>6.8</td><td>14.7</td><td>4.4</td><td>9.3</td><td>2.3</td></tr><tr><td>快速同步(Sync - fast) [7]</td><td>28.0</td><td>8.6</td><td>18.4</td><td>3.8</td><td>13.1</td><td>4.0</td><td>2.7</td><td>3.5</td></tr><tr><td>零样本学习后处理(ZSLPP) [14]</td><td>37.2</td><td>9.7</td><td>30.3</td><td>8.1</td><td>30.4</td><td>6.1</td><td>12.6</td><td>3.5</td></tr><tr><td>广义零样本学习生成对抗网络(GAZSL) [43]</td><td>43.7</td><td>10.3</td><td>35.6</td><td>8.6</td><td>35.4</td><td>8.7</td><td>20.4</td><td>5.8</td></tr><tr><td>最小二乘生成对抗网络(LsrGAN) [我们的方法]</td><td>45.2</td><td>14.2</td><td>36.4</td><td>9.04</td><td>39.5</td><td>12.1</td><td>23.2</td><td>6.4</td></tr></tbody></table>

### 4.3 ZSL and GZSL Performance

### 4.3 零样本学习(ZSL)和广义零样本学习(GZSL)性能

The results for the ZSL are provided in the left part of Table 2 and 3. It can be seen that our LsrGAN achieves superior performance in both attribute and Wikipedia based datasets compared to the previous state of the art models, especially with generative models GAZSL, F-GAN, cycle-CLSWGAN, and LisGAN. It is worth noticing that all the mentioned generative models have the same base architecture. e.g., WGAN. Hence, the superiority of our model suggests that our motivation is realistic, and our experiments are effective. In summary, we achieve, 1.5%, 3.9%, 0.8%, 0.44% improvement on CUB (Easy), CUB (Hard), NAB (Easy) and NAB (Hard) respectively for the Wikipedia based datasets under ZSL. On the other hand, for the attribute-based ZSL, we attain 1.5% and ${0.8}\%$ improvement on CUB and SUN, respectively. ZSL under performs on AWA probably due to the high feature correlation between similar unseen classes having a common neighbor among the seen classes, e.g. Dolphin and Blue whale. The availability of similar unseen classes slightly affects the prediction capability of the classifier for ZSL as the SR-loss tends to cluster them together due to high semantic similarity with common seen classes. However, it is worth noticing that the GZSL result for the same dataset is superior.

零样本学习(ZSL)的结果在表2和表3的左半部分给出。可以看出，与之前的先进模型相比，我们的LsrGAN在基于属性和基于维基百科的数据集上都取得了更优的性能，特别是与生成模型GAZSL、F - GAN、cycle - CLSWGAN和LisGAN相比。值得注意的是，所有提到的生成模型都有相同的基础架构，例如WGAN。因此，我们模型的优越性表明我们的动机是现实可行的，并且我们的实验是有效的。总之，在零样本学习(ZSL)下，对于基于维基百科的数据集，我们在加州大学伯克利分校鸟类数据集(CUB)(简单)、CUB(困难)、北美鸟类数据集(NAB)(简单)和NAB(困难)上分别实现了1.5%、3.9%、0.8%和0.44%的提升。另一方面，对于基于属性的零样本学习(ZSL)，我们在CUB和SUN数据集上分别实现了1.5%和 ${0.8}\%$ 的提升。零样本学习(ZSL)在动物属性数据集(AWA)上表现不佳，可能是由于在已见类别中有共同邻居的相似未见类别之间存在较高的特征相关性，例如海豚和蓝鲸。相似未见类别的存在会轻微影响零样本学习(ZSL)分类器的预测能力，因为SR损失倾向于由于与常见已见类别具有较高的语义相似性而将它们聚类在一起。然而，值得注意的是，同一数据集的广义零样本学习(GZSL)结果更优。

Our primary focus is to elevate the GZSL performance in this work, which is apparent from the right side of Table 2 and 3. Following $\left\lbrack  {{35},{36},{43}}\right\rbrack$ , we report the harmonic mean and AUC score for the attribute and Wikipedia based datasets, respectively. The mentioned metrics help us to showcase the approach's generalizability as the harmonic mean and AUC scores are only high when the performance on seen and unseen classes is high. From the results, we can see that LsrGAN outperforms the previous state of the art for the GZSL. In terms of numbers, we achieve, 4.1%, 3.4% 2.8% and 0.6% gain on CUB (Easy), CUB (Hard), NAB (Easy) and NAB (Hard) respectively for the Wikipedia based datasets and 0.7%, 1.4% and 0.7% improvement on attribute-based AWA, CUB and SUN respectively. It is worth noticing that the LsrGAN improves the unseen Top-1 performance in the GZSL setting for the attribute-based CUB and SUN by 1.6% and 1.9% with the previous state of the art LisGAN [24].

在这项工作中，我们的主要重点是提升广义零样本学习(GZSL)的性能，这从表2和表3的右半部分可以明显看出。按照 $\left\lbrack  {{35},{36},{43}}\right\rbrack$ ，我们分别报告了基于属性和基于维基百科的数据集的调和均值和AUC分数。上述指标有助于我们展示该方法的泛化能力，因为只有当对已见和未见类别的性能都很高时，调和均值和AUC分数才会很高。从结果中我们可以看到，LsrGAN在广义零样本学习(GZSL)方面优于之前的先进模型。从数据上看，对于基于维基百科的数据集，我们在CUB(简单)、CUB(困难)、NAB(简单)和NAB(困难)上分别实现了4.1%、3.4%、2.8%和0.6%的提升；对于基于属性的AWA、CUB和SUN数据集，分别实现了0.7%、1.4%和0.7%的提升。值得注意的是，与之前的先进模型LisGAN [24] 相比，LsrGAN在基于属性的CUB和SUN数据集的广义零样本学习(GZSL)设置下，将未见类别的Top - 1性能分别提高了1.6%和1.9%。

The majority of the conventional approaches, including the generative models overfit the seen classes, which results in lower GZSL performance. Notice that most of the approaches mentioned in Table 2 achieve very high performance on seen classes compared to the unseen classes in the GZSL setting. For example, SYNC [7] has around ${90}\%$ recognition capability on the seen classes, and it drops to only ${10}\%$ (80% difference) for the unseen classes on AWA dataset. It is also evident from Tables 2 and 3 that the performance on the unseen categories drops drastically when the search space includes both seen and unseen classes in the GZSL setting. For instance, DAP [22] drops from 40% to 1.7%, GAZSL [43] drops from 55.8% to 23.9% and F-GAN [35] drops from 57.3% to 43.7% on attribute-based CUB dataset. This indicates that the previous approaches are easy to overfit the seen classes. Although the generative models have achieved significant progress compared to the previous embedding methods, they still possess the overfitting issue towards seen classes by having substandard GZSL performance. On the contrary, our model incorporates the novel SR-Loss that enables the explicit knowledge transfer from the similar seen classes to the unseen classes. Therefore, the proposed LsrGAN alleviates the overfitting concern and helps us to achieve a state of the art GZSL performance. It is worth noticing that our model not only outperforms the generative zero-shot models having single GAN but also proves its worth against cycle-GAN [15] in ZSL and GZSL setting. Lastly, to have fair comparisons, we have taken the performance numbers from $\left\lbrack  {{35},{36},{43}}\right\rbrack$ .

大多数传统方法，包括生成模型，都会对已见类别过拟合，这导致广义零样本学习(GZSL)性能较低。注意，在表2中提到的大多数方法在广义零样本学习(GZSL)设置下，与未见类别相比，在已见类别上取得了非常高的性能。例如，SYNC [7] 在AWA数据集的已见类别上具有约 ${90}\%$ 的识别能力，而在未见类别上则降至仅 ${10}\%$(相差80%)。从表2和表3中也可以明显看出，在广义零样本学习(GZSL)设置下，当搜索空间同时包含已见和未见类别时，未见类别的性能会急剧下降。例如，在基于属性的CUB数据集上，判别式属性预测(DAP) [22] 从40%降至1.7%，GAZSL [43] 从55.8%降至23.9%，F - GAN [35] 从57.3%降至43.7%。这表明之前的方法很容易对已见类别过拟合。尽管与之前的嵌入方法相比，生成模型取得了显著进展，但它们仍然存在对已见类别过拟合的问题，广义零样本学习(GZSL)性能不佳。相反，我们的模型引入了新颖的SR损失，它能够实现从相似已见类别到未见类别的显式知识转移。因此，所提出的LsrGAN缓解了过拟合问题，并帮助我们实现了先进的广义零样本学习(GZSL)性能。值得注意的是，我们的模型不仅优于具有单个生成对抗网络(GAN)的生成式零样本学习模型，而且在零样本学习(ZSL)和广义零样本学习(GZSL)设置下也证明了其相对于循环生成对抗网络(cycle - GAN) [15] 的优势。最后，为了进行公平比较，我们从 $\left\lbrack  {{35},{36},{43}}\right\rbrack$ 获取了性能数据。

### 4.4 Effectiveness of SR-Loss

### 4.4 SR损失的有效性

Utilizing the semantic relationship between seen and unseen classes to infer the visual characteristics of an unseen class is at the heart of the proposed SR-Loss. Contrary to other generative approaches, it enables explicit knowledge transfer in the generative model to make it learn from the unseen classes together with seen classes during the training process itself. As a result, our LsrGAN will become more robust towards the unseen classes leading to address the seen class overfitting concern. To demonstrate such ability, we have computed the average class confidence score (Average Softmax probabilities) of the classifier trained with the generated features from the LsrGAN or F-GAN model. Since the confidence scores are computed under the GZSL, the classifier's training set contains real visual features from the seen classes and generated unseen features from LsrGAN or F-GAN. To have a fair comparison, we have used the same F-GAN's Softmax classifier in LsrGAN. Since LsrGAN learns from the seen and unseen classes during the training process itself, the Softmax classifier associated with it is not trained in an offline fashion like in the F-GAN model.

利用已见类别和未见类别之间的语义关系来推断未见类别的视觉特征，是所提出的SR损失(SR-Loss)的核心。与其他生成式方法不同，它能在生成模型中实现显式的知识迁移，使其在训练过程中同时从已见类别和未见类别中学习。因此，我们的LsrGAN对未见类别将更具鲁棒性，从而解决已见类别过拟合的问题。为了证明这种能力，我们计算了使用LsrGAN或F-GAN模型生成的特征训练的分类器的平均类别置信度得分(平均Softmax概率)。由于置信度得分是在广义零样本学习(GZSL)设置下计算的，分类器的训练集包含来自已见类别的真实视觉特征和来自LsrGAN或F-GAN的生成的未见特征。为了进行公平比较，我们在LsrGAN中使用了与F-GAN相同的Softmax分类器。由于LsrGAN在训练过程中同时从已见类别和未见类别中学习，与之关联的Softmax分类器不像F-GAN模型那样以离线方式进行训练。

![0195e037-bbaf-7de7-bf13-2cc5a64cb792_12_253_175_974_251_0.jpg](images/0195e037-bbaf-7de7-bf13-2cc5a64cb792_12_253_175_974_251_0.jpg)

Fig. 3. Average class confidence score (Average SoftMax Probability) comparison for classifier trained with F-GAN and LsrGAN. Top 3 average guesses are mentioned here. The red marked label showcase the top 1 average guess. The class names with underline represent seen classes.

图3. 使用F-GAN和LsrGAN训练的分类器的平均类别置信度得分(平均SoftMax概率)比较。这里列出了前3个平均猜测结果。红色标记的标签展示了排名第1的平均猜测结果。带下划线的类别名称表示已见类别。

Figure 3 depicts the confidence results on the AWA dataset under the GZSL setting. We have taken mainly four confusing seen and unseen classes for the comparison with classifier's top 3 guesses. It is evident from the figure that the classifier trained with the F-GAN has lower confidence for the unseen classes, and it mainly showcases very high confidence towards the similar seen classes even if the test image comes from the unseen classes. Also, during the seen class classification, the classifier's confidence values are mainly distributed among the seen classes in F-GAN. For instance, "mouse" has its confidence spread between mouse and hamster only. On the other hand, LsrGAN showcases decent confidence values for the seen and unseen, both leading to better GZSL performance. It is worth noticing that the LsrGAN fails for the "mouse" classification. However, the confidence is well spread among all the three categories showing it has considered an unseen class "rat" with other seen classes "mouse" and "Hamster". These observations reflect the fact that F-GAN has an overfitting issue towards the seen classes. On the other hand, the balanced performance of LsrGAN manifests that explicit knowledge transfer from SR-loss helps it to overcome the overfitting concern towards the seen classes. To bolster our claim, we have also computed the average class confidence across all the seen and unseen classes for these two models on attribute-based AWA, CUB, and SUN datasets. Table 4 reports average confidence values for seen and unseen classes. Clearly, it shows the superiority of LsrGAN in terms of generalizability compared to F-GAN.

图3展示了在广义零样本学习(GZSL)设置下AWA数据集上的置信度结果。我们主要选取了四个容易混淆的已见类别和未见类别，与分类器的前3个猜测结果进行比较。从图中可以明显看出，使用F-GAN训练的分类器对未见类别的置信度较低，即使测试图像来自未见类别，它也主要对相似的已见类别表现出非常高的置信度。此外，在已见类别分类过程中，F-GAN中分类器的置信度值主要分布在已见类别之间。例如，“老鼠”的置信度仅在老鼠和仓鼠之间分布。另一方面，LsrGAN对已见类别和未见类别都表现出不错的置信度值，从而在广义零样本学习(GZSL)任务中取得更好的性能。值得注意的是，LsrGAN在“老鼠”分类任务中表现不佳。然而，置信度在所有三个类别中分布均匀，这表明它在考虑已见类别“老鼠”和“仓鼠”的同时，也考虑了未见类别“大鼠”。这些观察结果反映出F-GAN存在对已见类别过拟合的问题。另一方面，LsrGAN的平衡性能表明，SR损失的显式知识迁移有助于它克服对已见类别过拟合的问题。为了支持我们的观点，我们还计算了这两个模型在基于属性的AWA、CUB和SUN数据集上所有已见类别和未见类别的平均类别置信度。表4报告了已见类别和未见类别的平均置信度值。显然，与F-GAN相比，LsrGAN在泛化能力方面表现更优。

Table 4. Comparison of average class confidence score across all seen or unseen classes (SoftMax Probability) between F-GAN and LsrGAN for attribute-based AWA, CUB and SUN

表4. 在基于属性的AWA、CUB和SUN数据集上，F-GAN和LsrGAN在所有已见或未见类别上的平均类别置信度得分(SoftMax概率)比较

<table><tr><td rowspan="2"/><td colspan="2">F-GAN$\left\lbrack  {35}\right\rbrack$</td><td colspan="2">LrsGAN [ours]</td></tr><tr><td>Unseen</td><td>Seen</td><td>Unseen</td><td>Seen</td></tr><tr><td>AWA</td><td>0.29</td><td>0.86</td><td>0.69</td><td>0.83</td></tr><tr><td>CUB</td><td>0.33</td><td>0.65</td><td>0.60</td><td>0.64</td></tr><tr><td>SUN</td><td>0.32</td><td>0.35</td><td>0.65</td><td>0.39</td></tr></table>

<table><tbody><tr><td rowspan="2"></td><td colspan="2">F生成对抗网络(F-GAN)</td><td colspan="2">局部正则化生成对抗网络(LrsGAN)[我们的方法]</td></tr><tr><td>未见类别</td><td>已见类别</td><td>未见类别</td><td>已见类别</td></tr><tr><td>动物属性数据集(AWA)</td><td>0.29</td><td>0.86</td><td>0.69</td><td>0.83</td></tr><tr><td>加州理工学院鸟类数据集(CUB)</td><td>0.33</td><td>0.65</td><td>0.60</td><td>0.64</td></tr><tr><td>太阳场景数据集(SUN)</td><td>0.32</td><td>0.35</td><td>0.65</td><td>0.39</td></tr></tbody></table>

### 4.5 Model Analysis

### 4.5 模型分析

Parameter Sensitivity: We have tuned our parameters following the conventional grid search approach. We mainly tune the SR-Loss parameters $\epsilon ,{\lambda }_{sr}$ and ${n}_{c}$ . For the fair comparison, we have adopted other parameters ${\lambda }_{vp},{\lambda }_{gp}$ from $\left\lbrack  {{35},{43}}\right\rbrack$ , also the ${\lambda }_{c}$ is considered between $(0,1\rbrack$ , specifically,0.01 for the majority of our experiments. Figure 4(b)-(d) show the parameter sensitivity for the SR-Loss. Notice that we estimate the $\epsilon$ value from the seen class visual and semantic relations. It can be seen that a lower and higher value of $\epsilon$ affects the performance. On the other hand, ${\lambda }_{sr}$ and ${n}_{c}$ maintain consistent performance after reaching a certain threshold value.

参数敏感性:我们按照传统的网格搜索方法调整了参数。我们主要调整了SR损失(Semantic Regularized Loss，语义正则化损失)参数 $\epsilon ,{\lambda }_{sr}$ 和 ${n}_{c}$。为了进行公平比较，我们从 $\left\lbrack  {{35},{43}}\right\rbrack$ 中采用了其他参数 ${\lambda }_{vp},{\lambda }_{gp}$，同时 ${\lambda }_{c}$ 取值范围在 $(0,1\rbrack$ 之间，具体而言，在我们的大多数实验中取值为0.01。图4(b) - (d)展示了SR损失的参数敏感性。请注意，我们从已见类别的视觉和语义关系中估计 $\epsilon$ 的值。可以看出，$\epsilon$ 值过低或过高都会影响性能。另一方面，${\lambda }_{sr}$ 和 ${n}_{c}$ 在达到一定阈值后保持稳定的性能。

![0195e037-bbaf-7de7-bf13-2cc5a64cb792_13_221_1168_1138_268_0.jpg](images/0195e037-bbaf-7de7-bf13-2cc5a64cb792_13_221_1168_1138_268_0.jpg)

Fig. 4. Ablation study under ZSL(a), Parameter sensitivity for the SR-loss (b-d).

图4. 零样本学习(ZSL)下的消融研究(a)，SR损失的参数敏感性(b - d)。

![0195e037-bbaf-7de7-bf13-2cc5a64cb792_13_208_1606_1159_319_0.jpg](images/0195e037-bbaf-7de7-bf13-2cc5a64cb792_13_208_1606_1159_319_0.jpg)

Fig. 5. Training stability (a-c) across all datasets under ZSL and GZSL

图5. 零样本学习(ZSL)和广义零样本学习(GZSL)下所有数据集的训练稳定性(a - c)

Training Stability: Since GANs are notoriously hard to train, and our proposed LsrGAN model not only uses GAN but also optimizes the similarity constraints from the SR-loss. Therefore, we also report the training stability for ZSL and GZSL for attribute and Wikipedia based datasets. Specifically, for the ZSL, we report the unseen Top-1 accuracy and Epoch behavior in Fig. 5(a) and Fig. 5(c). We have used harmonic mean of the seen and unseen Top-1 accuracy and Epoch to showcase the GZSL stability, mentioned in Fig. 5(b) and Fig. 5(c). Mainly we see the stable performance across all the datasets.

训练稳定性:由于生成对抗网络(GANs)以难以训练而闻名，并且我们提出的LsrGAN模型不仅使用了GAN，还优化了SR损失的相似性约束。因此，我们还报告了基于属性和维基百科数据集在零样本学习(ZSL)和广义零样本学习(GZSL)下的训练稳定性。具体来说，对于零样本学习(ZSL)，我们在图5(a)和图5(c)中报告了未见类别的Top - 1准确率和训练轮次(Epoch)的表现。我们使用已见和未见类别的Top - 1准确率和训练轮次(Epoch)的调和平均值来展示广义零样本学习(GZSL)的稳定性，如图5(b)和图5(c)所示。总体而言，我们看到在所有数据集上都有稳定的性能表现。

Ablation Study: We have reported the Ablation study of our model in Fig. 4(a) under ZSL for both attribute and Wikipedia based CUB. Primarily, we have used CUB (Easy) split for the Wikipedia based dataset. The ${S1}$ - WGAN with a classifier is considered as a baseline model. ${S2}$ reflects the effect of the visual pivot regularizer in our model. Finally, ${S3}$ showcase the performance of a complete LsrGAN with SR-loss. To highlight the effect of the denoiser used to process the Wikipedia based features, we have also reported the LsrGAN without denoiser in ${S4}$ . In summary, Fig. 4 (a) showcases the importance of each component used in our model.

消融研究:我们在图4(a)中报告了我们的模型在零样本学习(ZSL)下基于属性和维基百科的加州理工学院鸟类数据集(CUB)的消融研究。主要地，我们对基于维基百科的数据集使用了CUB(简单)分割。带有分类器的 ${S1}$ - 瓦瑟斯坦生成对抗网络(WGAN)被视为基线模型。${S2}$ 反映了我们模型中视觉枢轴正则化器的效果。最后，${S3}$ 展示了带有SR损失的完整LsrGAN的性能。为了突出用于处理基于维基百科特征的去噪器的效果，我们还在 ${S4}$ 中报告了没有去噪器的LsrGAN的情况。总之，图4(a)展示了我们模型中每个组件的重要性。

## 5 Conclusions

## 5 结论

In this paper, we have proposed a novel generative zero-shot model named Lsr-GAN that Leverages the Semantic Relationship between seen and unseen classes to address the seen class overfitting concern in GZSL. Mainly, LsrGAN employs a novel Semantic Regularized Loss (SR-Loss) to perform explicit knowledge transfer from seen classes to unseen ones. The SR-Loss explores the semantic relationships between seen and unseen classes to guide the LsrGAN to generate visual features that mirror the same relationship. Extensive experiments on seven benchmarks, including attribute and Wikipedia description based datasets, verify that our LsrGAN effectively addresses the overfitting concern and demonstrates a superior ZSL and GZSL performance.

在本文中，我们提出了一种名为Lsr - GAN的新型生成式零样本学习模型，该模型利用已见和未见类别之间的语义关系来解决广义零样本学习(GZSL)中已见类别过拟合的问题。主要地，LsrGAN采用了一种新颖的语义正则化损失(SR损失)，以实现从已见类别到未见类别的显式知识转移。SR损失探索已见和未见类别之间的语义关系，以引导LsrGAN生成反映相同关系的视觉特征。在包括基于属性和维基百科描述的七个基准数据集上的大量实验验证了我们的LsrGAN有效地解决了过拟合问题，并展示了卓越的零样本学习(ZSL)和广义零样本学习(GZSL)性能。

## References

## 参考文献

1. Akata, Z., Perronnin, F., Harchaoui, Z., Schmid, C.: Label-embedding for image classification. IEEE Trans. Pattern Anal. Mach. Intell. 38(7), 1425-1438 (2015)

1. Akata, Z., Perronnin, F., Harchaoui, Z., Schmid, C.:用于图像分类的标签嵌入。《IEEE模式分析与机器智能汇刊》38(7)，1425 - 1438(2015)

2. Akata, Z., Reed, S., Walter, D., Lee, H., Schiele, B.: Evaluation of output embed-dings for fine-grained image classification. In: Proceedings of the IEEE Conference on Computer Vision and Pattern Recognition, pp. 2927-2936 (2015)

2. Akata, Z., Reed, S., Walter, D., Lee, H., Schiele, B.:细粒度图像分类输出嵌入的评估。《IEEE计算机视觉与模式识别会议论文集》，第2927 - 2936页(2015)

3. Annadani, Y., Biswas, S.: Preserving semantic relations for zero-shot learning. In: Proceedings of the IEEE Conference on Computer Vision and Pattern Recognition, pp. 7603-7612 (2018)

3. Annadani, Y., Biswas, S.:零样本学习中保留语义关系。《IEEE计算机视觉与模式识别会议论文集》，第7603 - 7612页(2018)

4. Arjovsky, M., Chintala, S., Bottou, L.: Wasserstein GAN. arXiv preprint arXiv:1701.07875 (2017)

4. Arjovsky, M., Chintala, S., Bottou, L.:瓦瑟斯坦生成对抗网络。预印本arXiv:1701.07875(2017)

5. Bucher, M., Herbin, S., Jurie, F.: Generating visual representations for zero-shot classification. In: Proceedings of the IEEE International Conference on Computer Vision Workshops, pp. 2666-2673 (2017)

5. Bucher, M., Herbin, S., Jurie, F.:零样本分类的视觉表示生成。《IEEE国际计算机视觉研讨会论文集》，第2666 - 2673页(2017)

6. Cacheux, Y.L., Borgne, H.L., Crucianu, M.: Modeling inter and intra-class relations in the triplet loss for zero-shot learning. In: Proceedings of the IEEE International Conference on Computer Vision, pp. 10333-10342 (2019)

6. 卡谢 (Cacheux)，Y.L.，博尔涅 (Borgne)，H.L.，克鲁恰努 (Crucianu)，M.:零样本学习三元组损失中的类间和类内关系建模。见:《电气与电子工程师协会国际计算机视觉会议论文集》，第10333 - 10342页 (2019)

7. Changpinyo, S., Chao, W.L., Gong, B., Sha., F.: Synthesized classifiers for zero-shot learning. In: CVPR, pp. 5327-5336 (2016)

7. 张品耀 (Changpinyo)，S.，赵文良 (Chao)，W.L.，龚波 (Gong)，B.，沙飞 (Sha)，F.:零样本学习的合成分类器。见:《计算机视觉与模式识别会议》，第5327 - 5336页 (2016)

8. Changpinyo, S., Chao, W.L., Sha, F.: Predicting visual exemplars of unseen classes for zero-shot learning. In: Proceedings of the IEEE International Conference on Computer Vision, pp. 3476-3485 (2017)

8. 张品耀 (Changpinyo)，S.，赵文良 (Chao)，W.L.，沙飞 (Sha)，F.:零样本学习中未见类别的视觉样本预测。见:《电气与电子工程师协会国际计算机视觉会议论文集》，第3476 - 3485页 (2017)

9. Chao, W.-L., Changpinyo, S., Gong, B., Sha, F.: An empirical study and analysis of generalized zero-shot learning for object recognition in the wild. In: Leibe, B., Matas, J., Sebe, N., Welling, M. (eds.) ECCV 2016. LNCS, vol. 9906, pp. 52-68. Springer, Cham (2016). https://doi.org/10.1007/978-3-319-46475-6_4

9. 赵文良 (Chao)，W.-L.，张品耀 (Changpinyo)，S.，龚波 (Gong)，B.，沙飞 (Sha)，F.:野外目标识别广义零样本学习的实证研究与分析。见:莱贝 (Leibe)，B.，马塔斯 (Matas)，J.，塞贝 (Sebe)，N.，韦林 (Welling)，M.(编)《欧洲计算机视觉会议2016》。《计算机科学讲义》，第9906卷，第52 - 68页。施普林格出版社，尚姆 (2016)。https://doi.org/10.1007/978 - 3 - 319 - 46475 - 6_4

10. Chen, L., Zhang, H., Xiao, J., Liu, W., Chang, S.F.: Zero-shot visual recognition using semantics-preserving adversarial embedding networks. In: Proceedings of the IEEE Conference on Computer Vision and Pattern Recognition, pp. 1043-1052 (2018)

10. 陈龙 (Chen)，L.，张航 (Zhang)，H.，肖军 (Xiao)，J.，刘文 (Liu)，W.，张少锋 (Chang)，S.F.:使用语义保留对抗嵌入网络的零样本视觉识别。见:《电气与电子工程师协会计算机视觉与模式识别会议论文集》，第1043 - 1052页 (2018)

11. Ding, Z., Shao, M., Fu, Y.: Low-rank embedded ensemble semantic dictionary for zero-shot learning. In: Proceedings of the IEEE Conference on Computer Vision and Pattern Recognition, pp. 2050-2058 (2017)

11. 丁泽宇 (Ding)，Z.，邵明 (Shao)，M.，傅彦 (Fu)，Y.:零样本学习的低秩嵌入集成语义字典。见:《电气与电子工程师协会计算机视觉与模式识别会议论文集》，第2050 - 2058页 (2017)

12. Elhoseiny, M., Elgammal, A., Saleh, B.: Write a classifier: predicting visual classifiers from unstructured text. In: PAMI (2016)

12. 埃尔霍塞尼 (Elhoseiny)，M.，埃尔加马尔 (Elgammal)，A.，萨利赫 (Saleh)，B.:编写分类器:从非结构化文本预测视觉分类器。见:《模式分析与机器智能汇刊》 (2016)

13. Elhoseiny, M., Saleh, B., Elgammal, A.: Write a classifier: Zero-shot learning using purely textual descriptions. In: ICCV (2013)

13. 埃尔霍塞尼 (Elhoseiny)，M.，萨利赫 (Saleh)，B.，埃尔加马尔 (Elgammal)，A.:编写分类器:使用纯文本描述的零样本学习。见:《国际计算机视觉会议》 (2013)

14. Elhoseiny, M., Zhu, Y., Zhang, H., Elgammal, A.: Link the head to the "beak": Zero shot learning from noisy text description at part precision. In: CVPR, July 2017

14. 埃尔霍塞尼 (Elhoseiny)，M.，朱宇 (Zhu)，Y.，张航 (Zhang)，H.，埃尔加马尔 (Elgammal)，A.:将头部与“喙”联系起来:从有噪声的文本描述中进行部件精度的零样本学习。见:《计算机视觉与模式识别会议》，2017年7月

15. Felix, R., Kumar, V., Reid, I., Carnerio, G.: Multi-model cycle-consistent generalized zero-shot leanring. In: ECCV (2018)

15. 费利克斯 (Felix)，R.，库马尔 (Kumar)，V.，里德 (Reid)，I.，卡内里奥 (Carnerio)，G.:多模型循环一致广义零样本学习。见:《欧洲计算机视觉会议》 (2018)

16. Frome, A., Corrado, G.S., Shlens, J., Bengio, S., Dean, J., Mikolov, T., et al.: Devise: a deep visual-semantic embedding model. In: NIPS, pp. 2121-2129 (2013)

16. 弗罗姆 (Frome)，A.，科拉多 (Corrado)，G.S.，施伦斯 (Shlens)，J.，本吉奥 (Bengio)，S.，迪恩 (Dean)，J.，米科洛夫 (Mikolov)，T.等:Devise:一种深度视觉 - 语义嵌入模型。见:《神经信息处理系统大会》，第2121 - 2129页 (2013)

17. Gulrajani, I., Ahmed, F., Arjovsky, M., Dumoulin, V., Courville, A.C.: Improved training of wasserstein GANs. In: Advances in Neural Information Processing Systems, pp. 5767-5777 (2017)

17. 古拉贾尼 (Gulrajani)，I.，艾哈迈德 (Ahmed)，F.，阿尔乔夫斯基 (Arjovsky)，M.，杜穆林 (Dumoulin)，V.，库尔维尔 (Courville)，A.C.:改进Wasserstein生成对抗网络的训练。见:《神经信息处理系统进展》，第5767 - 5777页 (2017)

18. Guo, Y., Ding, G., Han, J., Gao, Y.: Synthesizing samples FRO zero-shot learning. IJCAI (2017)

18. 郭宇 (Guo)，Y.，丁国栋 (Ding)，G.，韩军 (Han)，J.，高宇 (Gao)，Y.:零样本学习的样本合成。《国际人工智能联合会议》 (2017)

19. He, K., Zhang, X., Ren, S., Sun, J.: Deep residual learning for image recognition. In: Proceedings of the IEEE Conference on Computer Vision and Pattern Recognition, pp. 770-778 (2016)

19. 何恺明 (He)，K.，张祥雨 (Zhang)，X.，任少卿 (Ren)，S.，孙剑 (Sun)，J.:用于图像识别的深度残差学习。见:《电气与电子工程师协会计算机视觉与模式识别会议论文集》，第770 - 778页 (2016)

20. Jiang, H., Wang, R., Shan, S., Chen, X.: Transferable contrastive network for generalized zero-shot learning. In: Proceedings of the IEEE International Conference on Computer Vision, pp. 9765-9774 (2019)

20. 蒋华良 (Jiang)，H.，王锐 (Wang)，R.，单思思 (Shan)，S.，陈鑫 (Chen)，X.:广义零样本学习的可迁移对比网络。见:《电气与电子工程师协会国际计算机视觉会议论文集》，第9765 - 9774页 (2019)

21. Kodirov, E., Xiang, T., Gong, S.: Semantic autoencoder for zero-shot learning. In: Proceedings of the IEEE Conference on Computer Vision and Pattern Recognition, pp. 3174-3183 (2017)

21. 科迪罗夫 (Kodirov)，E.，向涛 (Xiang)，T.，龚少刚 (Gong)，S.:零样本学习的语义自编码器。见:《电气与电子工程师协会计算机视觉与模式识别会议论文集》，第3174 - 3183页 (2017)

22. Lampert, C.H., Nickisch, H., Harmeling, S.: Attribute-based classification for zero-shot visual object categorization. IEEE Trans. Pattern Anal. Mach. Intell. 36(3), 453-465 (2013)

22. 兰珀特(Lampert)，C.H.，尼克施(Nickisch)，H.，哈梅林(Harmeling)，S.:基于属性的分类用于零样本视觉目标分类。《电气与电子工程师协会模式分析与机器智能汇刊》(IEEE Trans. Pattern Anal. Mach. Intell.)36(3)，453 - 465 (2013)

23. Larochelle, H., Erhan, D., Bengio, Y.: Zero-data learning of new tasks. In: AAAI (2008)

23. 拉罗谢尔(Larochelle)，H.，埃尔汗(Erhan)，D.，本吉奥(Bengio)，Y.:新任务的零数据学习。见:美国人工智能协会会议(AAAI)(2008)

24. Li, J., Jin, M., Lu, K., Ding, Z., Zhu, L., Huang, Z.: Leveraging the invariant side of generative zero-shot learning. In: CVPR (2019)

24. 李(Li)，J.，金(Jin)，M.，陆(Lu)，K.，丁(Ding)，Z.，朱(Zhu)，L.，黄(Huang)，Z.:利用生成式零样本学习的不变性方面。见:计算机视觉与模式识别会议(CVPR)(2019)

25. Lillo, W.E., Loh, M.H., Hui, S., Zak, S.H.: On solving constrained optimization problems with neural networks: a penalty method approach. IEEE Trans. Neural Networks 4(6), 931-940 (1993)

25. 利洛(Lillo)，W.E.，洛(Loh)，M.H.，许(Hui)，S.，扎克(Zak)，S.H.:用神经网络解决约束优化问题:一种惩罚方法。《电气与电子工程师协会神经网络汇刊》(IEEE Trans. Neural Networks)4(6)，931 - 940 (1993)

26. Norouzi, M., et al.: Zero-shot learning by convex combination of semantic embed-dings. arXiv preprint arXiv:1312.5650 (2013)

26. 诺鲁兹(Norouzi)，M.等:通过语义嵌入的凸组合进行零样本学习。预印本 arXiv:1312.5650 (2013)

27. Patterson, G., Hays, J.: Sun attribute database: discovering, annotating, and recognizing scene attributes. In: CVPR (2012)

27. 帕特森(Patterson)，G.，海斯(Hays)，J.:太阳属性数据库:发现、标注和识别场景属性。见:计算机视觉与模式识别会议(CVPR)(2012)

28. Qiao, R., Liu, L., Shen, C., Hengel, A.V.D.: Less is more: zero-shot learning from online textual documents with noise suppression. In: CVPR, June 2016

28. 乔(Qiao)，R.，刘(Liu)，L.，沈(Shen)，C.，亨格尔(Hengel)，A.V.D.:少即是多:通过抑制噪声从在线文本文档进行零样本学习。见:计算机视觉与模式识别会议(CVPR)，2016年6月

29. Rohrbach, M., Stark, M., Schiele, B.: Evaluating knowledge transfer and zero-shot learning in a large-scale setting. In: CVPR 2011, pp. 1641-1648. IEEE (2011)

29. 罗尔巴赫(Rohrbach)，M.，斯塔克(Stark)，M.，席勒(Schiele)，B.:在大规模环境下评估知识迁移和零样本学习。见:2011年计算机视觉与模式识别会议(CVPR 2011)，第1641 - 1648页。电气与电子工程师协会(IEEE)(2011)

30. Romera-Paredes, B., Torr, P.: An embarrassingly simple approach to zero-shot learning. In: ICML, pp. 2152-2161 (2015)

30. 罗梅拉 - 帕雷德斯(Romera - Paredes)，B.，托尔(Torr)，P.:一种极其简单的零样本学习方法。见:国际机器学习会议(ICML)，第2152 - 2161页 (2015)

31. Verma, V., Arora, G., A.M., Rai, P.: Generalized zero-shot learning via synthesized examples. In: CVPR (2018)

31. 维尔马(Verma)，V.，阿罗拉(Arora)，G.，A.M.，拉伊(Rai)，P.:通过合成示例进行广义零样本学习。见:计算机视觉与模式识别会议(CVPR)(2018)

32. Van Horn, G., et al.: Building a bird recognition app and large scale dataset with citizen scientists: the fine print in fine-grained dataset collection. In: Proceedings of the IEEE Conference on Computer Vision and Pattern Recognition, pp. 595-604 (2015)

32. 范霍恩(Van Horn)，G.等:与公民科学家一起构建鸟类识别应用程序和大规模数据集:细粒度数据集收集的细节。见:电气与电子工程师协会计算机视觉与模式识别会议论文集，第595 - 604页 (2015)

33. Verma, V.K., Rai, P.: A simple exponential family framework for zero-shot learning. In: Ceci, M., Hollmén, J., Todorovski, L., Vens, C., Džeroski, S. (eds.) ECML PKDD 2017. LNCS (LNAI), vol. 10535, pp. 792-808. Springer, Cham (2017). https://doi.org/10.1007/978-3-319-71246-8_48

33. 维尔马(Verma)，V.K.，拉伊(Rai)，P.:一种用于零样本学习的简单指数族框架。见:切奇(Ceci)，M.，霍尔门(Hollmén)，J.，托多罗夫斯基(Todorovski)，L.，文斯(Vens)，C.，杰罗斯基(Džeroski)，S.(编)2017年欧洲机器学习与知识发现数据库会议(ECML PKDD 2017)。《计算机科学讲义》(《人工智能讲义》)，第10535卷，第792 - 808页。施普林格出版社，尚姆(Cham)(2017)。https://doi.org/10.1007/978 - 3 - 319 - 71246 - 8_48

34. Welinder, P., et al.: Caltech-UCSD birds 200 (2010)

34. 韦林德(Welinder)，P.等:加州理工学院 - 加州大学圣地亚哥分校鸟类数据集200 (2010)

35. Xian, Y., Lorenz, T., Schiele, B., Akata, Z.: Feature generating networks for zero shot learning. In: CVPR (2018)

35. 西安(Xian)，Y.，洛伦茨(Lorenz)，T.，席勒(Schiele)，B.，阿卡塔(Akata)，Z.:用于零样本学习的特征生成网络。见:计算机视觉与模式识别会议(CVPR)(2018)

36. Xian, Y., Lampert, C.H., Schiele, B., Akata, Z.: Zero-shot learning - a comprehensive evaluation of the good, the bad and the ugly. In: TPAMI (2018)

36. 西安(Xian)，Y.，兰珀特(Lampert)，C.H.，席勒(Schiele)，B.，阿卡塔(Akata)，Z.:零样本学习——对好、坏和丑情况的全面评估。见:《电气与电子工程师协会模式分析与机器智能汇刊》(TPAMI)(2018)

37. Xu, X., Shen, F., Yang, Y., Zhang, D., Tao Shen, H., Song, J.: Matrix tri-factorization with manifold regularizations for zero-shot learning. In: Proceedings of the IEEE Conference on Computer Vision and Pattern Recognition, pp. 3798- 3807 (2017)

37. 徐(Xu)，X.，沈(Shen)，F.，杨(Yang)，Y.，张(Zhang)，D.，陶沈(Tao Shen)，H.，宋(Song)，J.:用于零样本学习的带流形正则化的矩阵三因子分解。见:电气与电子工程师协会计算机视觉与模式识别会议论文集，第3798 - 3807页 (2017)

38. Yu, X., Aloimonos, Y.: Attribute-based transfer learning for object categorization with zero/one training example. In: Daniilidis, K., Maragos, P., Paragios, N. (eds.) ECCV 2010. LNCS, vol. 6315, pp. 127-140. Springer, Heidelberg (2010). https:// doi.org/10.1007/978-3-642-15555-0_10

38. 于(Yu)，X.，阿洛伊莫诺斯(Aloimonos)，Y.:基于属性的迁移学习，用于零/单训练示例的目标分类。见:达尼利迪斯(Daniilidis)，K.，马拉戈斯(Maragos)，P.，帕拉吉奥斯(Paragios)，N.(编)《2010年欧洲计算机视觉会议(ECCV 2010)论文集》。《计算机科学讲义》(LNCS)，第6315卷，第127 - 140页。施普林格出版社，海德堡(2010年)。https:// doi.org/10.1007/978-3-642-15555-0_10

39. Zhang, H., et al.: SPDA-CNN: unifying semantic part detection and abstraction for fine-grained recognition. In: Proceedings of the IEEE Conference on Computer Vision and Pattern Recognition, pp. 1143-1152 (2016)

39. 张(Zhang)，H.等:SPDA - 卷积神经网络(SPDA - CNN):统一语义部分检测和抽象以实现细粒度识别。见:《电气与电子工程师协会计算机视觉与模式识别会议论文集》，第1143 - 1152页(2016年)

40. Zhang, L., Xiang, T., Gong, S.: Learning a deep embedding model for zero-shot learning. In: Proceedings of the IEEE Conference on Computer Vision and Pattern Recognition, pp. 2021-2030 (2017)

40. 张(Zhang)，L.，向(Xiang)，T.，龚(Gong)，S.:学习用于零样本学习的深度嵌入模型。见:《电气与电子工程师协会计算机视觉与模式识别会议论文集》，第2021 - 2030页(2017年)

41. Zhang, Z., Saligrama, V.: Zero-shot learning via semantic similarity embedding. In: ICCV, pp. 4166-4174 (2015)

41. 张(Zhang)，Z.，萨利格拉马(Saligrama)，V.:通过语义相似性嵌入实现零样本学习。见:《国际计算机视觉会议(ICCV)论文集》，第4166 - 4174页(2015年)

42. Zhu, J.Y., Park, T., Isola, P., Efros, A.A.: Unpaired image-to-image translation using cycle-consistent adversarial networks. In: Proceedings of the IEEE International Conference on Computer Vision, pp. 2223-2232 (2017)

42. 朱(Zhu)，J.Y.，朴(Park)，T.，伊索拉(Isola)，P.，埃弗罗斯(Efros)，A.A.:使用循环一致对抗网络进行无配对图像到图像的转换。见:《电气与电子工程师协会国际计算机视觉会议论文集》，第2223 - 2232页(2017年)

43. Zhu, Y., Elhoseiny, M., Liu, B., Peng, X., Elgammal, A.: A generative adversarial approach for zero-shot learning from noisy texts. In: Proceedings of the IEEE Conference on Computer Vision and Pattern Recognition, pp. 1004-1013 (2018)

43. 朱(Zhu)，Y.，埃尔霍塞尼(Elhoseiny)，M.，刘(Liu)，B.，彭(Peng)，X.，埃尔加马尔(Elgammal)，A.:一种从嘈杂文本中进行零样本学习的生成对抗方法。见:《电气与电子工程师协会计算机视觉与模式识别会议论文集》，第1004 - 1013页(2018年)