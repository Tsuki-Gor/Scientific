# Structured Latent Embeddings for Recognizing Unseen Classes in Unseen Domains

# 用于识别未见领域中未见类别的结构化潜在嵌入

Shivam Chandhok1

希瓦姆·钱德霍克(Shivam Chandhok)

shivam.chandhok@mbzuai.ac.ae

Sanath Narayan2

萨纳特·纳拉扬(Sanath Narayan)

sanath.narayan@inceptioniai.org

Hisham Cholakkal ${}^{1}$

希沙姆·乔拉卡尔(Hisham Cholakkal) ${}^{1}$

nisham.cholakkal@mbzuai.ac.ae

Rao Muhammad Anwer1

拉奥·穆罕默德·安瓦尔(Rao Muhammad Anwer)

rao.anwer@mbzuai.ac.ae

Vineeth N Balasubramanian ${}^{4}$

维尼特·N·巴拉苏布拉马尼亚姆(Vineeth N Balasubramanian) ${}^{4}$

wheethnb@iith.ac.in

Fahad Shahbaz Khan ${}^{13}$

法哈德·沙赫巴兹·汗(Fahad Shahbaz Khan) ${}^{13}$

iàhad.khan@mbzuai.ac.ae

iàhad.khan@mbzuai.ac.ae

Ling Shao2

邵岭(Ling Shao)

I img.shao@ieee.org

I img.shao@ieee.org

${}^{1}$ Mohamed Bin Zayed University of AI, UAE

${}^{1}$ 阿联酋穆罕默德·本·扎耶德人工智能大学(Mohamed Bin Zayed University of AI)

${}^{2}$ Inception Institute of Artificial Intelligence, UAE

${}^{2}$ 阿联酋人工智能初创研究所(Inception Institute of Artificial Intelligence)

${}^{3}$ Linkoping University, Sweden

${}^{3}$ 瑞典林雪平大学(Linkoping University)

${}^{4}$ Indian Institute of Technology,

${}^{4}$ 印度理工学院(Indian Institute of Technology)

Hyderabad, India

印度海得拉巴(Hyderabad)

## Abstract

## 摘要

The need to address the scarcity of task-specific annotated data has resulted in concerted efforts in recent years for specific settings such as zero-shot learning (ZSL) and domain generalization (DG), to separately address the issues of semantic shift and domain shift, respectively. However, real-world applications often do not have constrained settings and necessitate handling unseen classes in unseen domains - a setting called Zero-shot Domain Generalization, which presents the issues of domain and semantic shifts simultaneously. In this work, we propose a novel approach that learns domain-agnostic structured latent embeddings by projecting images from different domains as well as class-specific semantic text-based representations to a common latent space. In particular, our method jointly strives for the following objectives: (i) aligning the multimodal cues from visual and text-based semantic concepts; (ii) partitioning the common latent space according to the domain-agnostic class-level semantic concepts; and (iii) learning a domain invariance w.r.t. the visual-semantic joint distribution for generalizing to unseen classes in unseen domains. Our experiments on the challenging Domain-Net and DomainNet-LS benchmarks show the superiority of our approach over existing methods, with significant gains on difficult domains like quickdraw and sketch.

近年来，为解决特定任务标注数据稀缺的问题，人们针对零样本学习(Zero-shot learning，ZSL)和领域泛化(Domain generalization，DG)等特定场景做出了共同努力，分别解决语义偏移和领域偏移的问题。然而，现实世界的应用通常没有严格的设定，需要处理未见领域中的未见类别——这种设定被称为零样本领域泛化，它同时呈现出领域和语义偏移的问题。在这项工作中，我们提出了一种新颖的方法，通过将不同领域的图像以及特定类别的基于语义文本的表示投影到一个共同的潜在空间，来学习与领域无关的结构化潜在嵌入。具体而言，我们的方法共同追求以下目标:(i)对齐来自视觉和基于文本的语义概念的多模态线索；(ii)根据与领域无关的类级别语义概念对共同潜在空间进行划分；(iii)学习一种关于视觉 - 语义联合分布的领域不变性，以便泛化到未见领域中的未见类别。我们在具有挑战性的Domain - Net和DomainNet - LS基准测试上的实验表明，我们的方法优于现有方法，在诸如快速绘图(quickdraw)和草图(sketch)等困难领域取得了显著的提升。

---

(C) 2021. The copyright of this document resides with its authors.

(C)2021。本文档的版权归其作者所有。

It may be distributed unchanged freely in print or electronic forms.

它可以以印刷或电子形式自由原样分发。

---

## 1 Introduction

## 1 引言

In various computer vision problems, obtaining labeled data specifically tailored for a new task (be it a new domain or a new class) can be challenging due to one or more of several reasons: high annotation costs, dynamic addition of objects with new semantic content, limited instances of rare objects or long-tailed distributions which frequently occur in real-world scenarios [60]. To address such issues, two popular recent approaches include: (i) zero-shot learning (ZSL): use training data of related object categories from the same domain (e.g., sketches of cats as a training data for recognizing dogs from sketches); and (ii) domain generalization (DG): use training data of a particular object category from related domains (e.g., photos/real images of dogs as a training data for recognizing dogs from sketches). More recently, there has been increasing interest in a combination of these approaches to handle unseen classes in unseen domains, viz. zero-shot domain generalization (which we call ZSLDG), where one leverages training data of a related object category from a related domain (e.g., photos of cats as a training data for recognizing dogs from sketches). DG addresses only domain shift that occurs due to the training and test domains being different. ZSL addresses semantic shift that occurs due to the presence of different object categories during training and testing. In contrast, ZSLDG more closely aligns with the challenges faced in real-world applications, but needs to simultaneously address domain and semantic shift issues [13, 24].

在各种计算机视觉问题中，由于以下一个或多个原因，获取专门为新任务(无论是新领域还是新类别)量身定制的标注数据可能具有挑战性:高标注成本、具有新语义内容的对象动态添加、稀有对象实例有限或现实场景中经常出现的长尾分布 [60]。为解决这些问题，最近两种流行的方法包括:(i)零样本学习(Zero-shot learning，ZSL):使用来自同一领域的相关对象类别的训练数据(例如，将猫的草图作为从草图中识别狗的训练数据)；(ii)领域泛化(Domain generalization，DG):使用来自相关领域的特定对象类别的训练数据(例如，将狗的照片/真实图像作为从草图中识别狗的训练数据)。最近，人们对结合这些方法来处理未见领域中的未见类别越来越感兴趣，即零样本领域泛化(我们称之为ZSLDG)，其中人们利用来自相关领域的相关对象类别的训练数据(例如，将猫的照片作为从草图中识别狗的训练数据)。DG仅解决由于训练和测试领域不同而出现的领域偏移问题。ZSL解决由于训练和测试期间存在不同对象类别而出现的语义偏移问题。相比之下，ZSLDG更符合现实世界应用中面临的挑战，但需要同时解决领域和语义偏移问题 [13, 24]。

In this work, we investigate this challenging problem of ZSLDG. In particular, we propose a unified solution that jointly tackles both domain and semantic shifts by relating the general visual cues of a class to semantic concepts that are invariant across domains. E.g., semantic cues such as <long neck, long legs, has spots> of giraffe class are invariant across domains such as real images (photos), sketch or cli-part (see Fig. 1). To this end, we bring common information from visual and semantic spaces into a structured domain-agnostic latent space, partitioned according to class-level semantic concepts. We then impose a domain invariance w.r.t. the visual-semantic joint distribution. Since the semantic space is shared across all classes and is agnostic to the visual domains, imposing such invariance aids in generalizing to unseen domains at test time (instead of overfitting to source domains), while improving the visual-semantic interaction for effective knowledge transfer across seen and unseen classes.

在这项工作中，我们研究了零样本领域泛化这一具有挑战性的问题。具体而言，我们提出了一种统一的解决方案，通过将一个类别的一般视觉线索与跨领域不变的语义概念相关联，共同解决领域和语义偏移问题。例如，长颈鹿类别的语义线索，如<长脖子、长腿、有斑点>，在真实图像(照片)、草图或剪贴画等领域中是不变的(见图1)。为此，我们将来自视觉和语义空间的共同信息引入一个结构化的、与领域无关的潜在空间，该空间根据类级别语义概念进行划分。然后，我们对视觉 - 语义联合分布施加领域不变性。由于语义空间在所有类别中共享，并且与视觉领域无关，施加这种不变性有助于在测试时泛化到未见领域(而不是过度拟合源领域)，同时改善视觉 - 语义交互，以便在已见和未见类别之间进行有效的知识转移。

![0195d70c-4ea6-7e4b-9997-c42d592090dd_1_760_1063_667_384_0.jpg](images/0195d70c-4ea6-7e4b-9997-c42d592090dd_1_760_1063_667_384_0.jpg)

Figure 1: Our latent space is structured according to class-level semantic concepts and is domain-invariant w.r.t. visual-semantic joint distribution. This enables our model to map unseen classes in unseen domains at test-time (camel from clipart), based on their semantic concepts, to appropriate subspaces within our latent space, thereby aiding generalization.

图1:我们的潜在空间根据类级别语义概念进行结构化，并且关于视觉 - 语义联合分布具有领域不变性。这使我们的模型能够在测试时根据未见领域中未见类别的语义概念(如剪贴画中的骆驼)，将其映射到我们潜在空间内的适当子空间，从而有助于泛化。

Contributions: We propose a ZSLDG approach comprising of a visual encoder that learns to project multi-domain images from the visual space to a latent space, and a semantic encoder that learns to map text-based category-specific semantic representations to the same latent space. The key contributions of the proposed approach are: (i) For aligning class-specific cues from visual and semantic latent embeddings, we introduce a multimodal alignment loss term; (ii) We propose to partition the latent space w.r.t. class-level semantic concepts across domains by minimizing intra-class variance across different seen domains; (iii) The focus of our design is introduction of a joint invariance module that seeks to achieve domain invariance w.r.t. the visual-semantic joint distribution, and thereby facilitates generalizing to unseen classes in unseen domains; and (iv) Experiments and ablation studies on the challenging DomainNet and DomainNet-LS benchmarks [B1] demonstrate the superiority of our approach over existing methods. Particularly, on the most difficult quickdraw domain, our approach achieves a significant gain of 1.6% over the best existing method [23].

贡献:我们提出了一种零样本领域泛化(ZSLDG)方法，该方法包括一个视觉编码器和一个语义编码器，前者学习将多领域图像从视觉空间投影到潜在空间，后者学习将基于文本的特定类别语义表示映射到相同的潜在空间。所提出方法的主要贡献如下:(i)为了对齐视觉和语义潜在嵌入中的特定类别线索，我们引入了一个多模态对齐损失项；(ii)我们建议通过最小化不同已见领域间的类内方差，对跨领域的类级语义概念的潜在空间进行划分；(iii)我们设计的重点是引入一个联合不变性模块，该模块旨在实现视觉 - 语义联合分布的领域不变性，从而有助于将模型泛化到未见领域中的未见类别；(iv)在具有挑战性的DomainNet和DomainNet - LS基准测试[B1]上进行的实验和消融研究表明，我们的方法优于现有方法。特别是在最具挑战性的快速绘图(quickdraw)领域，我们的方法比现有的最佳方法[23]有1.6%的显著提升。

## 2 Related Work

## 2 相关工作

Domain Generalization (DG): Existing methods tackle the problem of domain shift, which occurs when the training and testing data belong to different domains, in different ways. Most previous approaches aim to learn domain-invariance by minimizing the discrepancy between multiple source domains $\left\lbrack  {2,4,4,4,4}\right\rbrack$ or by employing autoencoders and adversarial losses [12, 13]. A few works [3, 12, 13] introduce specific training policies or optimization procedures such as meta-learning and episodic training to enhance the generalizability of the model to unseen domains. Similarly, [B4, B7] employ data augmentation strategies to improve the models robustness to data distribution shifts at test time. However, all these works tackle the DG problem alone, where the label spaces at both train and test time are identical. Zero-shot Learning (ZSL): Traditional ZSL methods [2, 3, 4, 52, 33] learn to project the visual features onto a semantic embedding space via direct mapping or through a compatibility function. However, such direct mappings are likely to suffer from issues of seen class bias and hubness [2, 14]. In contrast, the work of [B6] leverages joint multi-modal learning of visual and textual feature embeddings for the task of ZSL. Recently, generative approaches tackle the problem of seen class bias by generating unseen visual features from respective class embeddings [B, C1, C4, C8, C3, C8, C0, C2]. However, all the aforementioned methods address only ZSL, where the domain remains unchanged during training and testing.

领域泛化(DG):现有方法以不同方式解决领域偏移问题，该问题在训练数据和测试数据属于不同领域时出现。大多数先前的方法旨在通过最小化多个源领域之间的差异$\left\lbrack  {2,4,4,4,4}\right\rbrack$，或通过使用自动编码器和对抗损失[12, 13]来学习领域不变性。一些工作[3, 12, 13]引入了特定的训练策略或优化程序，如元学习和情景训练，以增强模型对未见领域的泛化能力。同样，[B4, B7]采用数据增强策略来提高模型在测试时对数据分布偏移的鲁棒性。然而，所有这些工作仅解决了领域泛化问题，其中训练和测试时的标签空间是相同的。零样本学习(ZSL):传统的零样本学习方法[2, 3, 4, 52, 33]通过直接映射或兼容性函数将视觉特征投影到语义嵌入空间。然而，这种直接映射可能会受到已见类别偏差和中心性问题的影响[2, 14]。相比之下，[B6]的工作利用视觉和文本特征嵌入的联合多模态学习来完成零样本学习任务。最近，生成式方法通过从相应的类别嵌入中生成未见视觉特征来解决已见类别偏差问题[B, C1, C4, C8, C3, C8, C0, C2]。然而，上述所有方法仅解决了零样本学习问题，其中训练和测试期间领域保持不变。

Zero-shot Domain Generalization (ZSLDG): Recently, CuMix [23] introduced the problem of ZSLDG. While [24] defined variations in rotations of the same objects as different domains, such a restricted definition limits its real-world applicability. Differently, CuMix [23] defines domains as different ways of depicting an object, as in sketch, painting, cartoon, etc., which is closer to practical use of such methods. CuMix tackles the issue of domain shift through data augmentation by mixing and interpolating source domains, and handles semantic shifts by learning to project visual features to the semantic space. This work also established a benchmark dataset, DomainNet, for this setting with an evaluation protocol, which we follow in this work for fair comparison. However, relying on mixing source domains has a drawback - the resulting model could overfit to the source domains and their interpolations, thereby reducing generalizability to unseen domains [20]. Furthermore, directly mapping the visual space to the semantic space, as in [23], can lead to hubness issues (mapped points cluster as a hub due to low variance) [0, 0 , contrast, our approach jointly handles the issues of domain and semantic shifts by learning a domain-agnostic latent space that is partitioned based on class-level (domain-invariant) semantic concepts, onto which the visual and semantic features are projected. Since domain invariance is enforced w.r.t. the visual-semantic joint distribution, it is less likely to overfit to seen domains (a common problem when domain-invariance is enforced w.r.t. marginal distribution of images [20, 2, 2, 3]). In addition, our approach enables better interaction between visual and semantic spaces in a new latent space, thereby supporting model generalization to unseen classes in unseen domains.

零样本领域泛化(ZSLDG):最近，CuMix[23]提出了零样本领域泛化问题。虽然[24]将同一对象的不同旋转变化定义为不同领域，但这种受限的定义限制了其在现实世界中的适用性。不同的是，CuMix[23]将领域定义为描绘对象的不同方式，如画草图、绘画、卡通等，这更接近此类方法的实际应用。CuMix通过混合和插值源领域的数据增强方法解决领域偏移问题，并通过学习将视觉特征投影到语义空间来处理语义偏移问题。这项工作还为此设置建立了一个基准数据集DomainNet，并制定了评估协议，我们在本文中遵循该协议以进行公平比较。然而，依赖混合源领域存在一个缺点——得到的模型可能会对源领域及其插值产生过拟合，从而降低对未见领域的泛化能力[20]。此外，如[23]中那样直接将视觉空间映射到语义空间可能会导致中心性问题(由于方差较低，映射点会聚集为一个中心)[0, 0]。相比之下，我们的方法通过学习一个基于类级(领域不变)语义概念划分的领域无关潜在空间，联合处理领域和语义偏移问题，视觉和语义特征被投影到该潜在空间上。由于是针对视觉 - 语义联合分布强制实现领域不变性，因此不太可能对已见领域产生过拟合(当针对图像的边缘分布强制实现领域不变性时，这是一个常见问题[20, 2, 2, 3])。此外，我们的方法能够在新的潜在空间中实现视觉和语义空间之间更好的交互，从而支持模型泛化到未见领域中的未见类别。

## 3 Proposed Method

## 3 提出的方法

Problem Setting: The goal in zero-shot domain generalization (ZSLDG) is to recognize unseen categories in unseen domains. Let ${Q}^{Tr} = \left\{  {\left( {\mathbf{x}, y,{\mathbf{a}}_{y}, d}\right)  \mid  \mathbf{x} \in  \mathcal{X}, y \in  {\mathcal{Y}}^{s},{\mathbf{a}}_{y} \in  \mathcal{A}, d \in  {\mathcal{D}}^{s}}\right\}$ denote the training set, where $\mathbf{x}$ is a seen class image in the visual space(X)with corresponding label $y$ from a set of seen class labels ${\mathcal{Y}}^{s}$ . Here, ${\mathbf{a}}_{y}$ denotes the class-specific semantic representation that encodes the inter-class relationships, while $d$ is the domain label from a set of seen domains ${\mathcal{D}}^{s}$ . Note that the semantic representations are typically obtained from unsupervised text-based WordNet models (e.g., word2vec [23]) Similarly, ${Q}^{Ts} = \left\{  {\left( {\mathbf{x}, y,{\mathbf{a}}_{y}, d}\right)  \mid  \mathbf{x} \in  \mathcal{X}, y \in  {\mathcal{Y}}^{u},{\mathbf{a}}_{y} \in  \mathcal{A}, d \in  {\mathcal{D}}^{u}}\right\}$ is the test set, where ${\mathcal{Y}}^{u}$ is the set of labels for unseen classes and ${\mathcal{D}}^{u}$ represents the set of unseen domains. In the standard zero-shot setting, images at training and testing belong to disjoint classes but share the same domain space, i.e., ${\mathcal{Y}}^{s} \cap  {\mathcal{Y}}^{u} \equiv  \varnothing$ and ${\mathcal{D}}^{s} \equiv  {\mathcal{D}}^{u}$ . On the other hand, in the standard DG setting, images at training and testing belong to same categories in disjoint domain spaces, i.e., ${\mathcal{Y}}^{s} \equiv  {\mathcal{Y}}^{u}$ and ${\mathcal{D}}^{s} \cap  {\mathcal{D}}^{u} \equiv  \varnothing$ . In this work, our goal is to address the more challenging ZSLDG setting for recognizing unseen classes in unseen domains without having seen these novel classes and domains during training, i.e., ${\mathcal{Y}}^{s} \cap  {\mathcal{Y}}^{u} \equiv  \varnothing$ and ${\mathcal{D}}^{s} \cap  {\mathcal{D}}^{u} \equiv  \varnothing$ .

问题设定:零样本领域泛化(zero-shot domain generalization，ZSLDG)的目标是识别未见领域中的未见类别。令${Q}^{Tr} = \left\{  {\left( {\mathbf{x}, y,{\mathbf{a}}_{y}, d}\right)  \mid  \mathbf{x} \in  \mathcal{X}, y \in  {\mathcal{Y}}^{s},{\mathbf{a}}_{y} \in  \mathcal{A}, d \in  {\mathcal{D}}^{s}}\right\}$表示训练集，其中$\mathbf{x}$是视觉空间(X)中的一个已见类别图像，其对应的标签$y$来自已见类别标签集合${\mathcal{Y}}^{s}$。这里，${\mathbf{a}}_{y}$表示对类间关系进行编码的特定类别的语义表示，而$d$是来自已见领域集合${\mathcal{D}}^{s}$的领域标签。请注意，语义表示通常是从无监督的基于文本的WordNet模型(例如，word2vec [23])中获得的。类似地，${Q}^{Ts} = \left\{  {\left( {\mathbf{x}, y,{\mathbf{a}}_{y}, d}\right)  \mid  \mathbf{x} \in  \mathcal{X}, y \in  {\mathcal{Y}}^{u},{\mathbf{a}}_{y} \in  \mathcal{A}, d \in  {\mathcal{D}}^{u}}\right\}$是测试集，其中${\mathcal{Y}}^{u}$是未见类别的标签集合，${\mathcal{D}}^{u}$表示未见领域的集合。在标准的零样本设定中，训练和测试时的图像属于不相交的类别，但共享相同的领域空间，即${\mathcal{Y}}^{s} \cap  {\mathcal{Y}}^{u} \equiv  \varnothing$和${\mathcal{D}}^{s} \equiv  {\mathcal{D}}^{u}$。另一方面，在标准的领域泛化(domain generalization，DG)设定中，训练和测试时的图像在不相交的领域空间中属于相同的类别，即${\mathcal{Y}}^{s} \equiv  {\mathcal{Y}}^{u}$和${\mathcal{D}}^{s} \cap  {\mathcal{D}}^{u} \equiv  \varnothing$。在这项工作中，我们的目标是解决更具挑战性的ZSLDG设定问题，即在训练期间未见过这些新类别和领域的情况下，识别未见领域中的未见类别，即${\mathcal{Y}}^{s} \cap  {\mathcal{Y}}^{u} \equiv  \varnothing$和${\mathcal{D}}^{s} \cap  {\mathcal{D}}^{u} \equiv  \varnothing$。

Overall Framework: The overall architecture of our proposed approach is shown in Fig. 2. The proposed framework comprises a visual encoder $f$ , semantic encoder $g$ , semantic projection classifier $h$ along with discriminators ${D}_{1}$ and ${D}_{2}$ . In ZSLDG, the conditional distribution $p\left( {y \mid  \mathbf{x}}\right)$ changes since $\mathbf{x}$ comes from different domains, i.e., ${p}_{\mathcal{X}}\left( {\mathbf{x} \mid  {d}_{i}}\right)  \neq  {p}_{\mathcal{X}}\left( {\mathbf{x} \mid  {d}_{j}}\right) ,\forall i \neq  j$ . Our approach mitigates this issue by learning a domain-invariant semantic manifold $\mathcal{Z}$ which is partitioned according to class-level semantic concepts (described in Sec. 3.1 and Sec. 3.2), such that $p\left( {y \mid  \mathbf{z}}\right)$ is stable and does not change across domains (where $\mathbf{z} = f\left( \mathbf{x}\right)$ ). Furthermore, in order to ensure generalization to unseen classes in unseen domains at test time, our joint invariance module achieves domain invariance w.r.t. the visual-semantic joint by employing ${\mathcal{L}}_{\text{joint-inv }}$ (described in Sec. 3.3). This facilitates improved knowledge transfer between class-specific (domain-invariant) visual cues and semantic representations in latent space $\mathcal{Z}$ , thereby enhancing generalization to unseen classes in unseen domains at test-time.

总体框架:我们所提出方法的总体架构如图2所示。所提出的框架包括一个视觉编码器$f$、语义编码器$g$、语义投影分类器$h$以及判别器${D}_{1}$和${D}_{2}$。在零样本学习跨域泛化(ZSLDG)中，条件分布$p\left( {y \mid  \mathbf{x}}\right)$会发生变化，因为$\mathbf{x}$来自不同的领域，即${p}_{\mathcal{X}}\left( {\mathbf{x} \mid  {d}_{i}}\right)  \neq  {p}_{\mathcal{X}}\left( {\mathbf{x} \mid  {d}_{j}}\right) ,\forall i \neq  j$。我们的方法通过学习一个与领域无关的语义流形$\mathcal{Z}$来缓解这个问题，该语义流形根据类级语义概念进行划分(在3.1节和3.2节中描述)，使得$p\left( {y \mid  \mathbf{z}}\right)$保持稳定，并且不会因领域不同而改变(其中$\mathbf{z} = f\left( \mathbf{x}\right)$)。此外，为了确保在测试时能够泛化到未见领域中的未见类别，我们的联合不变性模块通过采用${\mathcal{L}}_{\text{joint-inv }}$(在3.3节中描述)实现了视觉 - 语义联合的领域不变性。这有助于改善特定类别(与领域无关)的视觉线索和潜在空间$\mathcal{Z}$中的语义表示之间的知识转移，从而增强在测试时对未见领域中未见类别的泛化能力。

### 3.1 Multimodal Alignment

### 3.1 多模态对齐

The multimodal alignment module, learns to project both the visual and semantic representations to a common latent embedding space $\mathcal{Z}$ . Let $f\left( \mathbf{x}\right)  : \mathcal{X} \rightarrow  \mathcal{Z}$ denote a feature extractor, which maps an image $\mathbf{x}$ in the visual space $\mathcal{X}$ to a vector ${\mathbf{z}}_{v}$ in the latent embedding space $\mathcal{Z}$ . Furthermore, let the function $g$ learn a mapping from semantic space to the latent embedding space, i.e., $g\left( {\mathbf{n},{\mathbf{a}}_{y}}\right)  : \mathcal{N} \times  \mathcal{A} \rightarrow  \mathcal{Z}$ by taking a random Gaussian noise vector $\mathbf{n}$ concatenated with the semantic representation ${\mathbf{a}}_{y}$ as input and mapping it to a vector ${\mathbf{z}}_{a}$ in $\mathcal{Z}$ . Let ${D}_{1} : \mathcal{Z} \times  \mathcal{A} \rightarrow  \mathbb{R}$ denote a conditional discriminator (conditioned on the semantic embedding $\left. {\mathbf{a}}_{y}\right)$ . Then, the multimodal adversarial alignment of the visual and semantic embedding spaces is achieved by employing a Wasserstein GAN [9], as given by

多模态对齐模块学习将视觉和语义表示都投影到一个共同的潜在嵌入空间$\mathcal{Z}$中。令$f\left( \mathbf{x}\right)  : \mathcal{X} \rightarrow  \mathcal{Z}$表示一个特征提取器，它将视觉空间$\mathcal{X}$中的图像$\mathbf{x}$映射到潜在嵌入空间$\mathcal{Z}$中的向量${\mathbf{z}}_{v}$。此外，令函数$g$学习从语义空间到潜在嵌入空间的映射，即$g\left( {\mathbf{n},{\mathbf{a}}_{y}}\right)  : \mathcal{N} \times  \mathcal{A} \rightarrow  \mathcal{Z}$，它将与语义表示${\mathbf{a}}_{y}$拼接的随机高斯噪声向量$\mathbf{n}$作为输入，并将其映射到$\mathcal{Z}$中的向量${\mathbf{z}}_{a}$。令${D}_{1} : \mathcal{Z} \times  \mathcal{A} \rightarrow  \mathbb{R}$表示一个条件判别器(以语义嵌入$\left. {\mathbf{a}}_{y}\right)$为条件)。然后，通过采用Wasserstein生成对抗网络(GAN)[9]实现视觉和语义嵌入空间的多模态对抗对齐，如下所示

$$
{\mathcal{L}}_{{D}_{1}} = \mathbb{E}\left\lbrack  {{D}_{1}\left( {{\mathbf{z}}_{v},{\mathbf{a}}_{y}}\right) }\right\rbrack   - \mathbb{E}\left\lbrack  {{D}_{1}\left( {{\mathbf{z}}_{a},{\mathbf{a}}_{y}}\right) }\right\rbrack   - \lambda \mathbb{E}\left\lbrack  {\left( \left| \right| {\nabla }_{\widetilde{\mathbf{z}}}{D}_{1}\left( \widetilde{\mathbf{z}},{\mathbf{a}}_{y}\right) {\left| \right| }_{2} - 1\right) }^{2}\right\rbrack  , \tag{1}
$$

where ${\mathbf{z}}_{v} = f\left( \mathbf{x}\right)$ and ${\mathbf{z}}_{a} = g\left( {\mathbf{n},{\mathbf{a}}_{y}}\right)$ are the latent embeddings from the visual and semantic spaces, respectively. Here, $\lambda$ is a weighting coefficient, while $\widetilde{\mathbf{z}} = \eta {\mathbf{z}}_{v} + \left( {1 - \eta }\right) {\mathbf{z}}_{a}$ with $\eta  \sim  U\left( {0,1}\right)$ represents a convex combination of ${\mathbf{z}}_{v}$ and ${\mathbf{z}}_{a}$ . Eq. 1 is equivalent to minimizing the (forward) Kullback-Leibler (KL) divergence between the visual and semantic latent em-beddings, i.e., ${KL}\left\lbrack  {\left( {{\mathbf{z}}_{v},{\mathbf{a}}_{y}}\right) \parallel \left( {{\mathbf{z}}_{a},{\mathbf{a}}_{y}}\right) }\right\rbrack$ . Furthermore, to enhance the discriminability of learned latent embeddings, we employ a compatibility based classifier using a semantic projection function $h : \mathcal{Z} \rightarrow  \mathcal{A}$ for constraining the latent embeddings $\left( {\mathbf{z}}_{v}\right.$ and $\left. {\mathbf{z}}_{a}\right)$ to map back to their corresponding semantic representations ${\mathbf{a}}_{y}$ , given by,

其中 ${\mathbf{z}}_{v} = f\left( \mathbf{x}\right)$ 和 ${\mathbf{z}}_{a} = g\left( {\mathbf{n},{\mathbf{a}}_{y}}\right)$ 分别是来自视觉空间和语义空间的潜在嵌入(latent embeddings)。这里，$\lambda$ 是一个加权系数，而满足 $\eta  \sim  U\left( {0,1}\right)$ 的 $\widetilde{\mathbf{z}} = \eta {\mathbf{z}}_{v} + \left( {1 - \eta }\right) {\mathbf{z}}_{a}$ 表示 ${\mathbf{z}}_{v}$ 和 ${\mathbf{z}}_{a}$ 的凸组合。公式1等价于最小化视觉和语义潜在嵌入之间的(前向)库尔贝克 - 莱布勒(Kullback - Leibler，KL)散度，即 ${KL}\left\lbrack  {\left( {{\mathbf{z}}_{v},{\mathbf{a}}_{y}}\right) \parallel \left( {{\mathbf{z}}_{a},{\mathbf{a}}_{y}}\right) }\right\rbrack$。此外，为了增强所学习的潜在嵌入的区分能力，我们采用基于兼容性的分类器，使用语义投影函数 $h : \mathcal{Z} \rightarrow  \mathcal{A}$ 将潜在嵌入 $\left( {\mathbf{z}}_{v}\right.$ 和 $\left. {\mathbf{z}}_{a}\right)$ 约束映射回它们对应的语义表示 ${\mathbf{a}}_{y}$，如下所示:

$$
{\mathcal{L}}_{V}\left( {{\mathbf{z}}_{v},{\mathbf{a}}_{y}}\right)  =  - \mathbb{E}\left( {\log \frac{\exp \left( \left\langle  {h\left( {\mathbf{z}}_{v}\right) ,{\mathbf{a}}_{y}}\right\rangle  \right) }{\mathop{\sum }\limits_{{\mathbf{y} \in  {Y}^{s}}}\exp \left( \left\langle  {h\left( {\mathbf{z}}_{v}\right) ,{\mathbf{a}}_{y}}\right\rangle  \right) }}\right) ,\;{\mathcal{L}}_{S}\left( {{\mathbf{z}}_{a},{\mathbf{a}}_{y}}\right)  =  - \mathbb{E}\left( {\log \frac{\exp \left( \left\langle  {h\left( {\mathbf{z}}_{a}\right) ,{\mathbf{a}}_{y}}\right\rangle  \right) }{\mathop{\sum }\limits_{{\mathbf{y} \in  {Y}^{s}}}\exp \left( \left\langle  {h\left( {\mathbf{z}}_{a}\right) ,{\mathbf{a}}_{y}}\right\rangle  \right) }}\right) .
$$

(2)

![0195d70c-4ea6-7e4b-9997-c42d592090dd_4_105_98_1345_625_0.jpg](images/0195d70c-4ea6-7e4b-9997-c42d592090dd_4_105_98_1345_625_0.jpg)

Figure 2: Overall architecture of our approach. The proposed approach comprises a visual encoder $f$ and a semantic encoder $g$ . The multimodal alignment module (Sec. 3.1) aligns the class-specific cues from the visual and semantic latent embeddings $\left( {\mathbf{z}}_{v}\right.$ and $\left. {\mathbf{z}}_{a}\right)$ in $\mathcal{Z}$ by employing an alignment loss term ${\mathcal{L}}_{\text{align }}$ , The loss term ${\mathcal{L}}_{\text{center }}$ ensures a domain-agnostic class-level partitioning (Sec. 3.2) of $\mathcal{Z}$ . Furthermore, the joint invariance module strives to achieve domain invariance (Sec. 3.3) w.r.t. the visual-semantic joint distribution by employing ${\mathcal{L}}_{\text{joint-inv }}$ , thereby enabling us to generalize to unseen classes in unseen domains.

图2:我们方法的整体架构。所提出的方法包括一个视觉编码器 $f$ 和一个语义编码器 $g$。多模态对齐模块(第3.1节)通过采用对齐损失项 ${\mathcal{L}}_{\text{align }}$，在 $\mathcal{Z}$ 中对齐来自视觉和语义潜在嵌入 $\left( {\mathbf{z}}_{v}\right.$ 和 $\left. {\mathbf{z}}_{a}\right)$ 的特定类别的线索。损失项 ${\mathcal{L}}_{\text{center }}$ 确保 $\mathcal{Z}$ 的与领域无关的类级划分(第3.2节)。此外，联合不变性模块通过采用 ${\mathcal{L}}_{\text{joint-inv }}$ 努力实现关于视觉 - 语义联合分布的领域不变性(第3.3节)，从而使我们能够泛化到未见领域中的未见类别。

Here, $\langle  \cdot  , \cdot  \rangle$ represents the measure of similarity between its inputs, computed as the dot product between them. Such a cyclic projection, i.e., mapping from visual/semantic space to a latent space and then back to the semantic space minimizes the information loss and enhances the discriminabilty of the latent embeddings. We employ the multimodal alignment loss term $\left( {\mathcal{L}}_{\text{align }}\right)$ to learn the visual and semantic encoders along with the semantic projection classifier, given by

这里，$\langle  \cdot  , \cdot  \rangle$ 表示其输入之间的相似度度量，计算为它们之间的点积。这种循环投影，即从视觉/语义空间映射到潜在空间，然后再映射回语义空间，可最小化信息损失并增强潜在嵌入的区分能力。我们采用多模态对齐损失项 $\left( {\mathcal{L}}_{\text{align }}\right)$ 来学习视觉和语义编码器以及语义投影分类器，如下所示

$$
{\mathcal{L}}_{\text{align }} = \mathbb{E}\left\lbrack  {{D}_{1}\left( {{\mathbf{z}}_{v},{\mathbf{a}}_{y}}\right) }\right\rbrack   - \mathbb{E}\left\lbrack  {{D}_{1}\left( {{\mathbf{z}}_{a},{\mathbf{a}}_{y}}\right) }\right\rbrack   + {\mathcal{L}}_{V}\left( {{\mathbf{z}}_{v},{\mathbf{a}}_{y}}\right)  + {\mathcal{L}}_{S}\left( {{\mathbf{z}}_{a},{\mathbf{a}}_{y}}\right) \rbrack . \tag{3}
$$

### 3.2 Structured Partitioning

### 3.2 结构化划分

While the multimodal alignment aligns the visual and corresponding semantic embeddings in the latent space, it does not learn a domain-agnostic latent space, which is partitioned according to the semantic concepts that relate to the different classes. In order to achieve a structured and domain-invariant latent space, we propose to cluster the latent embeddings based on class-level (domain-invariant) semantic concepts across different domains. The latent space is then conceptually structured, since the visual latent embeddings ${\mathbf{z}}_{v}$ and semantic latent embeddings ${\mathbf{z}}_{a}$ of a class are clustered together. To this end, we adopt the center loss [39] in a multimodal setting. Formally, we first randomly initialise $S$ centers, i.e., $\left\{  {{\mathbf{c}}_{j} \mid  j = 1,\ldots , S}\right\}$ for each of the seen classes in the training set and compute the loss, ${\mathcal{L}}_{\text{center }}$ due to each class $y$ present in a mini-batch. Then, for every class $y$ that is present in a mini-batch, the center update $\Delta {\mathbf{c}}_{y}$ is computed for incrementing the corresponding center ${\mathbf{c}}_{y}$ . The loss ${\mathcal{L}}_{\text{center }}$ and update $\Delta {\mathbf{c}}_{y}$ are given by:

虽然多模态对齐在潜在空间中对齐了视觉嵌入和相应的语义嵌入，但它并未学习一个与领域无关的潜在空间，该潜在空间是根据与不同类别相关的语义概念进行划分的。为了实现一个结构化且与领域无关的潜在空间，我们提议基于跨不同领域的类别级(与领域无关)语义概念对潜在嵌入进行聚类。由于一个类别的视觉潜在嵌入 ${\mathbf{z}}_{v}$ 和语义潜在嵌入 ${\mathbf{z}}_{a}$ 被聚类在一起，因此潜在空间在概念上是结构化的。为此，我们在多模态设置中采用中心损失 [39]。形式上，我们首先随机初始化 $S$ 个中心，即训练集中每个可见类别的 $\left\{  {{\mathbf{c}}_{j} \mid  j = 1,\ldots , S}\right\}$，并计算由于小批量中存在的每个类别 $y$ 而产生的损失 ${\mathcal{L}}_{\text{center }}$。然后，对于小批量中存在的每个类别 $y$，计算中心更新 $\Delta {\mathbf{c}}_{y}$ 以增加相应的中心 ${\mathbf{c}}_{y}$。损失 ${\mathcal{L}}_{\text{center }}$ 和更新 $\Delta {\mathbf{c}}_{y}$ 由以下公式给出:

$$
{\mathcal{L}}_{\text{center }} = \delta \left\lbrack  {\mathbb{E}\left( {\begin{Vmatrix}{\mathbf{z}}_{v} - {\mathbf{c}}_{y}\end{Vmatrix}}_{2}^{2}\right)  + \mathbb{E}\left( {\begin{Vmatrix}{\mathbf{z}}_{a} - {\mathbf{c}}_{y}\end{Vmatrix}}_{2}^{2}\right) }\right\rbrack  ;\;\Delta {\mathbf{c}}_{y} = \mathbb{E}\left\lbrack  {{\mathbf{c}}_{y} - {\mathbf{z}}_{v}}\right\rbrack   + \mathbb{E}\left\lbrack  {{\mathbf{c}}_{y} - {\mathbf{z}}_{a}}\right\rbrack  . \tag{4}
$$

Here, ${\mathbf{c}}_{y}$ denotes the center of class label $y$ in the latent space, while ${\mathbf{z}}_{v}$ and ${\mathbf{z}}_{a}$ correspond to the visual and semantic embeddings of class $y$ , and $\delta$ is weighing factor for center loss. Consequently, the intra-class and inter-domain variances for each class get minimized, resulting in a structured and domain-agnostic latent space. Furthermore, since both the visual and semantic latent representations of a class are clustered together, the latent space is partitioned based on class-level semantic concepts.

这里，${\mathbf{c}}_{y}$ 表示潜在空间中类别标签 $y$ 的中心，而 ${\mathbf{z}}_{v}$ 和 ${\mathbf{z}}_{a}$ 分别对应于类别 $y$ 的视觉嵌入和语义嵌入，$\delta$ 是中心损失的权重因子。因此，每个类别的类内和跨领域方差被最小化，从而得到一个结构化且与领域无关的潜在空间。此外，由于一个类别的视觉和语义潜在表示被聚类在一起，潜在空间是基于类别级语义概念进行划分的。

In order to validate our hypotheses that a domain-agnostic structured latent space helps to stabilize $p\left( {y \mid  \mathbf{z}}\right)$ and generalize to new domains, we conduct an experiment as a proof of concept. Fig. 3 presents a comparison for the standard domain generalization (DG) setting on the PACS dataset [161] using ResNet-18 backbone. We see that structuring the latent space (blue bars) provides performance gains on all domains and enhances the average gain, compared to employing multimodal alignment alone (orange bars). The highest gain is achieved for the most difficult sketch domain that has a large domain shift from the source domains (photo, art, cartoon), demonstrating the advantage of our domain-agnostic partitioning.

为了验证我们的假设，即与领域无关的结构化潜在空间有助于稳定 $p\left( {y \mid  \mathbf{z}}\right)$ 并推广到新领域，我们进行了一个概念验证实验。图 3 展示了在使用 ResNet - 18 骨干网络的 PACS 数据集 [161] 上标准领域泛化(DG)设置的比较。我们发现，与仅采用多模态对齐(橙色条)相比，对潜在空间进行结构化处理(蓝色条)在所有领域都带来了性能提升，并提高了平均增益。在最难的草图领域(与源领域(照片、艺术、卡通)存在较大领域偏移)实现了最高增益，这证明了我们与领域无关的划分方法的优势。

![0195d70c-4ea6-7e4b-9997-c42d592090dd_5_917_611_496_352_0.jpg](images/0195d70c-4ea6-7e4b-9997-c42d592090dd_5_917_611_496_352_0.jpg)

Figure 3: Impact of our structured partitioning for the DG task on PACS [164]. Compared to multimodal alignment alone (orange bars), additionally partitioning the latent space according to the semantic concepts along with multimodal alignment provides notable performance gains (blue bars), especially on the most difficult unseen domain, i.e., sketch.

图 3:我们的结构化划分方法对 PACS [164] 上 DG 任务的影响。与仅进行多模态对齐(橙色条)相比，结合多模态对齐并根据语义概念对潜在空间进行额外划分可带来显著的性能提升(蓝色条)，尤其是在最难的未见领域，即草图领域。

### 3.3 Joint Invariance Module

### 3.3 联合不变性模块

As discussed above, the multimodal alignment and

如上所述，多模态对齐和

conceptual partitioning result in a structured and domain-agnostic latent embedding space that disentangles semantic and domain-specific information. Such a disentanglement of semantic and domain-specific information is sufficient for standard domain-generalization setting where images during training and testing come from same categories. However in our ZSLDG setting, the disentanglement may not hold for unseen semantic categories during testing, as previously found in [23]. In order to address this issue and enable generalization to unseen classes in unseen domains, we propose to learn the domain-invariance w.r.t. the joint distribution of visual and semantic representations of a class. Formally, any given image $\mathbf{x}$ comprises of a class-specific content $\mathbf{C}$ and a domain-specific transformation $T\left( \cdot \right)$ which depicts the class in that particular domain $d$ . Thus, each image $\mathbf{x} \in  \mathcal{X}$ belonging to domain ${d}_{i}$ can be represented as $\mathbf{x} = {T}_{i}\left( \mathbf{C}\right)$ . In order to enable generalization to unseen class in unseen domains, we propose to match the visual-semantic joint distribution $p\left( {T\left( \mathbf{C}\right) ,{\mathbf{a}}_{y}}\right)$ under different transformations ${T}_{i}\left( \cdot \right)$ (or domains). Since the semantic space is shared between seen and unseen classes, learning domain invariance w.r.t. the joint distribution of visual and semantic representations of a class, i.e., $p\left( {f\left( {T\left( \mathbf{C}\right) }\right) ,{\mathbf{a}}_{y}}\right)$ or $p\left( {f\left( \mathbf{x}\right) ,{\mathbf{a}}_{y}}\right)$ enables us to enhance generalization.

概念划分会产生一个结构化且与领域无关的潜在嵌入空间，该空间能分离语义信息和特定领域信息。这种语义信息和特定领域信息的分离足以应对标准的领域泛化场景，即训练和测试阶段的图像来自相同的类别。然而，在我们的零样本学习领域泛化(ZSLDG)场景中，如文献[23]中所发现的，这种分离对于测试阶段的未见语义类别可能并不成立。为了解决这个问题并实现对未见领域中未见类别的泛化，我们提议学习关于一个类别的视觉和语义表示的联合分布的领域不变性。形式上，任何给定的图像$\mathbf{x}$由特定类别的内容$\mathbf{C}$和特定领域的变换$T\left( \cdot \right)$组成，该变换描绘了该特定领域$d$中的类别。因此，属于领域${d}_{i}$的每个图像$\mathbf{x} \in  \mathcal{X}$可以表示为$\mathbf{x} = {T}_{i}\left( \mathbf{C}\right)$。为了实现对未见领域中未见类别的泛化，我们提议匹配不同变换${T}_{i}\left( \cdot \right)$(或领域)下的视觉 - 语义联合分布$p\left( {T\left( \mathbf{C}\right) ,{\mathbf{a}}_{y}}\right)$。由于语义空间在已见和未见类别之间是共享的，学习关于一个类别的视觉和语义表示的联合分布的领域不变性，即$p\left( {f\left( {T\left( \mathbf{C}\right) }\right) ,{\mathbf{a}}_{y}}\right)$或$p\left( {f\left( \mathbf{x}\right) ,{\mathbf{a}}_{y}}\right)$，使我们能够增强泛化能力。

Specifically, we aim to match the visual-semantic joint distribution from the visual encoder $\left( {{\mathbf{z}}_{v},{\mathbf{a}}_{y}}\right)$ , semantic encoder $\left( {{\mathbf{z}}_{a},{\mathbf{a}}_{y}}\right)$ and projection classifier $\left( {{\mathbf{z}}_{a},{\widehat{\mathbf{a}}}_{y}}\right)$ . To this end, we employ a triple adversarial loss, to stabilize the visual-semantic joint distribution across different domains. This also enhances visual-semantic interaction for learning class-specific discriminative features in the visual and semantic embedding spaces. This is achieved by employing a discriminator ${D}_{2} : \mathcal{Z} \times  \mathcal{A} \rightarrow  \mathbb{R}$ and optimizing:

具体而言，我们的目标是匹配来自视觉编码器$\left( {{\mathbf{z}}_{v},{\mathbf{a}}_{y}}\right)$、语义编码器$\left( {{\mathbf{z}}_{a},{\mathbf{a}}_{y}}\right)$和投影分类器$\left( {{\mathbf{z}}_{a},{\widehat{\mathbf{a}}}_{y}}\right)$的视觉 - 语义联合分布。为此，我们采用三重对抗损失，以稳定不同领域间的视觉 - 语义联合分布。这也增强了视觉和语义嵌入空间中用于学习特定类别判别特征的视觉 - 语义交互。这是通过使用一个判别器${D}_{2} : \mathcal{Z} \times  \mathcal{A} \rightarrow  \mathbb{R}$并进行优化来实现的:

$$
{\mathcal{L}}_{{D}_{2}} = \mathbb{E}\left\lbrack  {{D}_{2}\left( {{\mathbf{z}}_{a},{\mathbf{a}}_{y}}\right) }\right\rbrack   - \alpha \mathbb{E}\left\lbrack  {{D}_{2}\left( {{\mathbf{z}}_{a},{\widehat{\mathbf{a}}}_{y}}\right) }\right\rbrack   - \beta \mathbb{E}\left\lbrack  {{D}_{2}\left( {{\mathbf{z}}_{v},{\mathbf{a}}_{y}}\right) }\right\rbrack
$$

$$
- \lambda \mathbb{E}\left\lbrack  {\left( \left| \right| {\nabla }_{\widetilde{z}}{D}_{2}\left( \widetilde{\mathbf{z}},{\widetilde{\mathbf{a}}}_{y}\right) ,{\nabla }_{\widetilde{\mathbf{a}}}{D}_{2}\left( \widetilde{\mathbf{z}},{\widetilde{\mathbf{a}}}_{y}\right) {\left| \right| }_{2} - 1\right) }^{2}\right\rbrack   \tag{5}
$$

Here, ${\widehat{\mathbf{a}}}_{y} = h\left( {\mathbf{z}}_{a}\right)$ is output from projection classifier $h$ , which represents the projection of the latent embedding ${\mathbf{z}}_{a}$ onto the semantic space $\mathcal{A}$ . Also, $\widetilde{\mathbf{z}} = \eta {\mathbf{z}}_{a} + \left( {1 - \eta }\right) \left( {\alpha {\mathbf{z}}_{a} + \beta {\mathbf{z}}_{v}}\right)$ and ${\widetilde{\mathbf{a}}}_{y} = \eta {\mathbf{a}}_{y} + \left( {1 - \eta }\right) \left( {\alpha {\widehat{\mathbf{a}}}_{y} + \beta {\mathbf{a}}_{y}}\right)$ with $\beta  = 1 - \alpha$ and $\eta  \sim  U\left( {0,1}\right)$ . Additionally, $\lambda$ is a weighting coefficient. Note that ${D}_{2}$ is different from the vanilla discriminator ${D}_{1}$ and has a triple adversarial formulation [C3]. Firstly, by incorporating the projection classifier output ${\widehat{\mathbf{a}}}_{y}$ , it enables to jointly train the visual encoder $f$ , semantic encoder $g$ and projection classifier $h$ while imposing domain-invariance. In addition, we design Eq. 5 to treat $\left( {{\mathbf{z}}_{a},{\mathbf{a}}_{y}}\right)$ as real samples and $\left( {{\mathbf{z}}_{v},{\mathbf{a}}_{y}}\right) ,\left( {{\mathbf{z}}_{a},{\widehat{\mathbf{a}}}_{y}}\right)$ as fake samples. This acts as a minimizer of the reverse KL divergence i.e., ${KL}\left\lbrack  {\left( {{z}_{a},{a}_{y}}\right) \parallel \left( {{z}_{v},{a}_{y}}\right) }\right\rbrack$ [29] (in contrast to ${D}_{1}$ that minimizes forward KL as described in Sec. 3.1) between the visual and semantic spaces. We find that this leads to better generalization by alleviating the mode collapse issue, and thus enables our model to capture multiple modes of the data distribution [29]. Next, the semantic projector classifier $h$ is updated to minimize:

这里，${\widehat{\mathbf{a}}}_{y} = h\left( {\mathbf{z}}_{a}\right)$ 是投影分类器 $h$ 的输出，它表示潜在嵌入 ${\mathbf{z}}_{a}$ 在语义空间 $\mathcal{A}$ 上的投影。此外，$\widetilde{\mathbf{z}} = \eta {\mathbf{z}}_{a} + \left( {1 - \eta }\right) \left( {\alpha {\mathbf{z}}_{a} + \beta {\mathbf{z}}_{v}}\right)$ 和 ${\widetilde{\mathbf{a}}}_{y} = \eta {\mathbf{a}}_{y} + \left( {1 - \eta }\right) \left( {\alpha {\widehat{\mathbf{a}}}_{y} + \beta {\mathbf{a}}_{y}}\right)$ 分别对应 $\beta  = 1 - \alpha$ 和 $\eta  \sim  U\left( {0,1}\right)$。另外，$\lambda$ 是一个加权系数。请注意，${D}_{2}$ 与普通判别器 ${D}_{1}$ 不同，并且具有三重对抗公式 [C3]。首先，通过纳入投影分类器输出 ${\widehat{\mathbf{a}}}_{y}$，它能够在施加域不变性的同时联合训练视觉编码器 $f$、语义编码器 $g$ 和投影分类器 $h$。此外，我们设计公式 5 将 $\left( {{\mathbf{z}}_{a},{\mathbf{a}}_{y}}\right)$ 视为真实样本，将 $\left( {{\mathbf{z}}_{v},{\mathbf{a}}_{y}}\right) ,\left( {{\mathbf{z}}_{a},{\widehat{\mathbf{a}}}_{y}}\right)$ 视为虚假样本。这充当了反向 KL 散度(即 ${KL}\left\lbrack  {\left( {{z}_{a},{a}_{y}}\right) \parallel \left( {{z}_{v},{a}_{y}}\right) }\right\rbrack$ [29])的最小化器(与第 3.1 节中描述的最小化前向 KL 的 ${D}_{1}$ 相反)，用于视觉空间和语义空间之间。我们发现，这通过缓解模式崩溃问题实现了更好的泛化能力，从而使我们的模型能够捕捉数据分布的多种模式 [29]。接下来，更新语义投影分类器 $h$ 以最小化:

$$
{\mathcal{L}}_{cls} =  - \alpha \mathbb{E}\left\lbrack  {{p}_{h}\left( {y \mid  {\mathbf{z}}_{a}}\right) {D}_{2}\left( {{\mathbf{z}}_{a},{\widehat{\mathbf{a}}}_{y}}\right) }\right\rbrack   + \gamma \left\lbrack  {{\mathcal{L}}_{V}\left( {{\mathbf{z}}_{v},{\mathbf{a}}_{y}}\right)  + {\mathcal{L}}_{S}\left( {{\mathbf{z}}_{a},{\mathbf{a}}_{y}}\right) }\right\rbrack  , \tag{6}
$$

where ${p}_{h}\left( {y \mid  {\mathbf{z}}_{a}}\right)$ is the probability distribution after taking softmax of semantic projection classifier $h$ , output logits. Weighting the ${D}_{2}$ output with the class probabilities helps in achieving stable training [B]. Finally, we update the visual and semantic encoders ( $f$ and $g$ ) to minimize discrepancy between the embeddings $\left( {\mathbf{z}}_{a}\right.$ and $\left. {\mathbf{z}}_{v}\right)$ in the latent space, given by:

其中 ${p}_{h}\left( {y \mid  {\mathbf{z}}_{a}}\right)$ 是对语义投影分类器 $h$ 的输出对数进行 softmax 操作后的概率分布。用类别概率对 ${D}_{2}$ 的输出进行加权有助于实现稳定的训练 [B]。最后，我们更新视觉编码器和语义编码器($f$ 和 $g$)，以最小化潜在空间中嵌入 $\left( {\mathbf{z}}_{a}\right.$ 和 $\left. {\mathbf{z}}_{v}\right)$ 之间的差异，计算公式如下:

$$
{\mathcal{L}}_{\text{gen }} = \mathbb{E}\left\lbrack  {{D}_{2}\left( {{\mathbf{z}}_{a},{\mathbf{a}}_{y}}\right) }\right\rbrack   - \beta \mathbb{E}\left\lbrack  {{D}_{2}\left( {{\mathbf{z}}_{v},{\mathbf{a}}_{y}}\right) }\right\rbrack  . \tag{7}
$$

Then, the joint invariance loss term ${\mathcal{L}}_{\text{joint-inv }}$ is defined as ${\mathcal{L}}_{\text{joint-inv }} = {\mathcal{L}}_{\text{cls }} + {\mathcal{L}}_{\text{gen }}$ . Consequently, the adversarial loss terms in Eq. 5 and ${\mathcal{L}}_{\text{joint-inv }}$ together enable us to jointly train $f, g, h$ and learn a domain-invariant space, which can generalize to unseen domains and classes at test time, by capturing class-specific discriminative visual-semantic relationships across domains.

然后，联合不变性损失项 ${\mathcal{L}}_{\text{joint-inv }}$ 定义为 ${\mathcal{L}}_{\text{joint-inv }} = {\mathcal{L}}_{\text{cls }} + {\mathcal{L}}_{\text{gen }}$。因此，公式 5 和 ${\mathcal{L}}_{\text{joint-inv }}$ 中的对抗损失项使我们能够联合训练 $f, g, h$ 并学习一个域不变空间，该空间可以通过捕捉跨域的特定类别的判别性视觉 - 语义关系，在测试时泛化到未见的域和类别。

### 3.4 Training and Inference

### 3.4 训练与推理

Training: In a single training iteration, we first update the discriminators ${D}_{1}$ and ${D}_{2}$ to maximize the losses in Eq. 1 and 5. We update the discriminators 5 times for every update of the rest of the functions(f, g, h), as in WGAN [13]. Following this, the parameters ${\theta }_{f},{\theta }_{g},{\theta }_{h},{\theta }_{c}$ corresponding to $f, g, h$ and class centers, respectively, are updated to minimize:

训练:在单次训练迭代中，我们首先更新判别器 ${D}_{1}$ 和 ${D}_{2}$，以最大化公式 1 和 5 中的损失。与 WGAN [13] 一样，我们每更新一次其余函数(f、g、h)，就对判别器进行 5 次更新。随后，分别对应于 $f, g, h$ 和类别中心的参数 ${\theta }_{f},{\theta }_{g},{\theta }_{h},{\theta }_{c}$ 被更新以最小化:

$$
{\mathcal{L}}_{\text{total }} = {\mathcal{L}}_{\text{align }} + {\mathcal{L}}_{\text{center }} + {\mathcal{L}}_{\text{joint-inv }}. \tag{8}
$$

Inference: A test image ${\mathbf{x}}_{t}$ from a unseen domain and class (in ${\mathcal{D}}^{u}$ and ${\mathcal{Y}}^{u}$ ) is projected by encoder $f$ to obtain the corresponding latent embedding ${\mathbf{z}}_{t} = f\left( {\mathbf{x}}_{t}\right)$ . The semantic projection classifier $h$ computes pairwise similarities between ${\mathbf{z}}_{t}$ and the unseen class embeddings ${\mathbf{a}}_{y}$ , where $y \in  {\mathcal{Y}}^{u}$ . These similarity scores are converted to class probabilities to obtain the final prediction $\widehat{y}$ , given by $\widehat{y} = \arg \mathop{\max }\limits_{{y \in  {\mathcal{Y}}^{u}}}P\left( {y \mid  {\mathbf{x}}_{t};\Phi }\right)$ .

推理:来自未知领域和类别的测试图像 ${\mathbf{x}}_{t}$(在 ${\mathcal{D}}^{u}$ 和 ${\mathcal{Y}}^{u}$ 中)由编码器 $f$ 进行投影，以获得相应的潜在嵌入 ${\mathbf{z}}_{t} = f\left( {\mathbf{x}}_{t}\right)$。语义投影分类器 $h$ 计算 ${\mathbf{z}}_{t}$ 与未知类别嵌入 ${\mathbf{a}}_{y}$ 之间的成对相似度，其中 $y \in  {\mathcal{Y}}^{u}$。这些相似度得分被转换为类别概率，以获得由 $\widehat{y} = \arg \mathop{\max }\limits_{{y \in  {\mathcal{Y}}^{u}}}P\left( {y \mid  {\mathbf{x}}_{t};\Phi }\right)$ 给出的最终预测 $\widehat{y}$。

Table 1: State-of-the-art comparison for the task of ZSLDG on the DomainNet benchmark using ResNet-50 backbone [23]. For a fair comparison, all reported results employ the same backbone, protocol and splits, as described in [13]. Best results are in bold.

表 1:在 DomainNet 基准测试中使用 ResNet - 50 骨干网络 [23] 进行零样本学习域泛化(ZSLDG)任务的最新技术比较。为了进行公平比较，所有报告的结果都采用了与 [13] 中描述的相同的骨干网络、协议和分割方式。最佳结果以粗体显示。

<table><tr><td colspan="2">$\mathbf{{Method}}$</td><td/><td/><td/><td>Target Domain</td><td/><td/></tr><tr><td>$\mathbf{{DG}}$</td><td>ZSL</td><td>$\mathbf{{AVG}}$</td><td>painting</td><td>infograph</td><td>quickdraw</td><td>sketch</td><td>clipart</td></tr><tr><td rowspan="3">-</td><td>DEVISE [III]</td><td>14.4</td><td>17.6</td><td>11.7</td><td>6.1</td><td>16.7</td><td>20.1</td></tr><tr><td>ALE [M]</td><td>16.2</td><td>20.2</td><td>12.7</td><td>6.8</td><td>18.5</td><td>22.7</td></tr><tr><td>SPNet [12]</td><td>19.4</td><td>23.8</td><td>16.9</td><td>8.2</td><td>21.8</td><td>26.0</td></tr><tr><td rowspan="3">DANN [D]</td><td>DEVISE [III]</td><td>13.9</td><td>16.4</td><td>10.4</td><td>7.1</td><td>15.1</td><td>20.5</td></tr><tr><td>ALE [1]</td><td>15.7</td><td>19.7</td><td>12.5</td><td>7.4</td><td>17.9</td><td>21.2</td></tr><tr><td>SPNet [12]</td><td>19.1</td><td>24.1</td><td>15.8</td><td>8.4</td><td>21.3</td><td>25.9</td></tr><tr><td rowspan="3">EpiFCR [12]</td><td>DEVISE [III]</td><td>15.9</td><td>19.3</td><td>13.9</td><td>7.3</td><td>17.2</td><td>21.6</td></tr><tr><td>ALE [M]</td><td>17.5</td><td>21.4</td><td>14.1</td><td>7.8</td><td>20.9</td><td>23.2</td></tr><tr><td>SPNet [12]</td><td>20.0</td><td>24.6</td><td>16.7</td><td>9.2</td><td>23.2</td><td>26.4</td></tr><tr><td colspan="2">CuMix(Mixup-img-only)</td><td>19.2</td><td>24.4</td><td>16.3</td><td>8.7</td><td>21.7</td><td>25.2</td></tr><tr><td colspan="2">CuMix(Mixup-two-level)</td><td>19.9</td><td>25.3</td><td>17</td><td>8.8</td><td>21.9</td><td>26.6</td></tr><tr><td colspan="2">CuMix [13]</td><td>20.7</td><td>25.5</td><td>17.8</td><td>9.9</td><td>22.6</td><td>27.6</td></tr><tr><td colspan="2">Ours</td><td>21.9</td><td>26.6</td><td>18.4</td><td>11.5</td><td>25.0</td><td>27.8</td></tr></table>

<table><tbody><tr><td colspan="2">$\mathbf{{Method}}$</td><td></td><td></td><td></td><td>目标领域</td><td></td><td></td></tr><tr><td>$\mathbf{{DG}}$</td><td>零样本学习(Zero-Shot Learning，ZSL)</td><td>$\mathbf{{AVG}}$</td><td>绘画</td><td>信息图</td><td>快速绘图</td><td>素描</td><td>剪贴画</td></tr><tr><td rowspan="3">-</td><td>DEVISE [III]</td><td>14.4</td><td>17.6</td><td>11.7</td><td>6.1</td><td>16.7</td><td>20.1</td></tr><tr><td>ALE [M]</td><td>16.2</td><td>20.2</td><td>12.7</td><td>6.8</td><td>18.5</td><td>22.7</td></tr><tr><td>SPNet [12]</td><td>19.4</td><td>23.8</td><td>16.9</td><td>8.2</td><td>21.8</td><td>26.0</td></tr><tr><td rowspan="3">DANN [D]</td><td>DEVISE [III]</td><td>13.9</td><td>16.4</td><td>10.4</td><td>7.1</td><td>15.1</td><td>20.5</td></tr><tr><td>ALE [1]</td><td>15.7</td><td>19.7</td><td>12.5</td><td>7.4</td><td>17.9</td><td>21.2</td></tr><tr><td>SPNet [12]</td><td>19.1</td><td>24.1</td><td>15.8</td><td>8.4</td><td>21.3</td><td>25.9</td></tr><tr><td rowspan="3">EpiFCR [12]</td><td>DEVISE [III]</td><td>15.9</td><td>19.3</td><td>13.9</td><td>7.3</td><td>17.2</td><td>21.6</td></tr><tr><td>ALE [M]</td><td>17.5</td><td>21.4</td><td>14.1</td><td>7.8</td><td>20.9</td><td>23.2</td></tr><tr><td>SPNet [12]</td><td>20.0</td><td>24.6</td><td>16.7</td><td>9.2</td><td>23.2</td><td>26.4</td></tr><tr><td colspan="2">CuMix(仅图像混合)</td><td>19.2</td><td>24.4</td><td>16.3</td><td>8.7</td><td>21.7</td><td>25.2</td></tr><tr><td colspan="2">CuMix(两级混合)</td><td>19.9</td><td>25.3</td><td>17</td><td>8.8</td><td>21.9</td><td>26.6</td></tr><tr><td colspan="2">CuMix [13]</td><td>20.7</td><td>25.5</td><td>17.8</td><td>9.9</td><td>22.6</td><td>27.6</td></tr><tr><td colspan="2">我们的方法</td><td>21.9</td><td>26.6</td><td>18.4</td><td>11.5</td><td>25.0</td><td>27.8</td></tr></tbody></table>

Table 2: Results on DomainNet-LS with only real and painting as source domains and ResNet-50 backbone, following protocol described in [B3]. Best results in bold.

表2:按照[B3]中所述的协议，在DomainNet-LS数据集上仅以真实图像和绘画图像作为源域、以ResNet-50为骨干网络的实验结果。最佳结果以粗体显示。

<table><tr><td>Model</td><td>$\mathbf{{AVG}}$</td><td>quickdraw</td><td>sketch</td><td>infograph</td><td>clipart</td></tr><tr><td>SPNet</td><td>14.4</td><td>4.8</td><td>17.3</td><td>14.1</td><td>21.5</td></tr><tr><td>Epi-FCR+SPNet</td><td>15.4</td><td>5.6</td><td>18.7</td><td>14.9</td><td>22.5</td></tr><tr><td>CuMix (MixUp-img-only):</td><td>14.3</td><td>4.8</td><td>17.3</td><td>14.0</td><td>21.2</td></tr><tr><td>CuMix(MixUp-two-level):</td><td>15.8</td><td>4.9</td><td>19.1</td><td>16.5</td><td>22.7</td></tr><tr><td>CuMix (reverse):</td><td>15.4</td><td>4.8</td><td>18.2</td><td>15.8</td><td>22.9</td></tr><tr><td>CuMix:</td><td>16.5</td><td>5.5</td><td>19.7</td><td>17.1</td><td>23.7</td></tr><tr><td>Ours</td><td>16.9</td><td>7.2</td><td>20.5</td><td>16</td><td>24</td></tr></table>

<table><tbody><tr><td>模型</td><td>$\mathbf{{AVG}}$</td><td>快速绘图</td><td>草图</td><td>信息图</td><td>剪贴画</td></tr><tr><td>SP网络(SPNet)</td><td>14.4</td><td>4.8</td><td>17.3</td><td>14.1</td><td>21.5</td></tr><tr><td>Epi - FCR + SP网络(Epi-FCR+SPNet)</td><td>15.4</td><td>5.6</td><td>18.7</td><td>14.9</td><td>22.5</td></tr><tr><td>CuMix(仅图像混合(MixUp-img-only)):</td><td>14.3</td><td>4.8</td><td>17.3</td><td>14.0</td><td>21.2</td></tr><tr><td>CuMix(两级混合(MixUp-two-level)):</td><td>15.8</td><td>4.9</td><td>19.1</td><td>16.5</td><td>22.7</td></tr><tr><td>CuMix(反向):</td><td>15.4</td><td>4.8</td><td>18.2</td><td>15.8</td><td>22.9</td></tr><tr><td>CuMix:</td><td>16.5</td><td>5.5</td><td>19.7</td><td>17.1</td><td>23.7</td></tr><tr><td>我们的方法</td><td>16.9</td><td>7.2</td><td>20.5</td><td>16</td><td>24</td></tr></tbody></table>

Table 3: Ablation study for different components of our framework on DomainNet dataset for ZSLDG setting. Best results are in bold.

表3:在零样本领域泛化(ZSLDG)设置下，我们的框架不同组件在DomainNet数据集上的消融研究。最佳结果以粗体显示。

<table><tr><td>Model</td><td>AVG</td><td>painting</td><td>infograph</td><td>quickdraw</td><td>sketch</td><td>clipart</td></tr><tr><td>M1: ${\mathcal{L}}_{\text{align }}$</td><td>18.5</td><td>22.6</td><td>16.2</td><td>9.6</td><td>20.8</td><td>23.7</td></tr><tr><td>M2: M1 + ${\mathcal{L}}_{\text{center }}$</td><td>20.5</td><td>25.4</td><td>16.9</td><td>9.8</td><td>24.0</td><td>26.4</td></tr><tr><td>M3: $\mathrm{M}2 + {\mathcal{L}}_{\text{joint-inv }}$</td><td>21.9</td><td>26.6</td><td>18.4</td><td>11.5</td><td>25.0</td><td>27.8</td></tr></table>

<table><tbody><tr><td>模型</td><td>平均值</td><td>绘画</td><td>信息图</td><td>快速绘图</td><td>草图</td><td>剪贴画</td></tr><tr><td>M1: ${\mathcal{L}}_{\text{align }}$</td><td>18.5</td><td>22.6</td><td>16.2</td><td>9.6</td><td>20.8</td><td>23.7</td></tr><tr><td>M2:M1 + ${\mathcal{L}}_{\text{center }}$</td><td>20.5</td><td>25.4</td><td>16.9</td><td>9.8</td><td>24.0</td><td>26.4</td></tr><tr><td>M3: $\mathrm{M}2 + {\mathcal{L}}_{\text{joint-inv }}$</td><td>21.9</td><td>26.6</td><td>18.4</td><td>11.5</td><td>25.0</td><td>27.8</td></tr></tbody></table>

## 4 Experiments

## 4 实验

Datasets: We evaluate our method on the DomainNet and DomainNet-LS benchmarks for the task of ZSLDG, as in [23]. DomainNet [[3]: It is a large-scale dataset and is currently the only benchmark dataset for the ZSLDG setting [23]. It consists of nearly 0.6 million images from 345 categories in 6 domains: painting, clipart, sketch, infograph, quickdraw and real. For the task of ZSLDG, we follow the same training/validation/testing splits along with the training and evaluation protocol described in [23]. In particular, 45 out of 345 are fixed as unseen classes and training is performed using only the remaining seen class images. Among the 6 domains in DomainNet, the seen class images from 5 domains are provided during training, and the model is evaluated on the 45 unseen classes in the held-out (unseen) domain. We repeat experiments with each of the domains as the unseen domain. Following [23], the real domain is never held out since a ResNet-50 backbone, pre-trained on ImageNet [6], is employed. Average per-class accuracy is used as the performance metric for evaluation on the held-out domain. Similarly, we use the word2vec [23] representations as the semantic information for inter-relating seen and unseen classes, as in [23].

数据集:我们按照文献[23]的方法，在DomainNet和DomainNet - LS基准数据集上对零样本跨领域泛化(ZSLDG)任务评估我们的方法。DomainNet [[3]:它是一个大规模数据集，目前是ZSLDG设置下唯一的基准数据集[23]。它包含来自6个领域(绘画、剪贴画、素描、信息图、简笔画和真实图像)345个类别的近60万张图像。对于ZSLDG任务，我们遵循文献[23]中描述的相同的训练/验证/测试划分以及训练和评估协议。具体而言，345个类别中有45个被固定为未见类别，训练仅使用其余可见类别的图像。在DomainNet的6个领域中，训练期间提供来自5个领域的可见类图像，模型在保留(未见)领域的45个未见类别上进行评估。我们将每个领域作为未见领域重复进行实验。遵循文献[23]，由于采用了在ImageNet [6]上预训练的ResNet - 50骨干网络，真实领域从不作为保留领域。平均每类准确率用作在保留领域评估的性能指标。同样，我们像文献[23]一样，使用word2vec [23]表示作为关联可见和未见类别的语义信息。

DomainNet-LS: This benchmark is a more challenging setting, where the source domains during training are limited to real and painting only, whereas testing is conducted on the remaining four unseen domains. Since only two source domains are used in training, it is more challenging to learn domain-invariance and generalize at test-time.

DomainNet - LS:这个基准是一个更具挑战性的设置，其中训练期间的源领域仅限于真实和绘画领域，而测试在其余四个未见领域进行。由于训练中仅使用两个源领域，因此学习领域不变性并在测试时进行泛化更具挑战性。

### 4.1 Results: Comparison with State-of-the-art

### 4.1 结果:与最先进方法的比较

Results on DomainNet: Tab. 1 shows the comparison of our proposed framework with state-of-the-art methods and all baselines, as established in [23], on the ZSLDG task. We first report the performance of standalone ZSL approaches such as DEVISE [III], ALE [II] and SPNet [&II] on the ZSLDG task, followed by the performance achieved by coupling these ZSL approaches with standard DG approaches like DANN [121] and EpiFCR [133]. It is worth noting that coupling the standalone ZSL methods with DANN achieves lower performance than the ZSL method alone in the case of ZSLDG, since standard domain alignment methods have been shown to be ineffective on the DomainNet dataset, leading to negative transfer in some cases [B1]. Furthermore, as noted by [B3], coupling EpiFCR (a standalone DG method) with the standalone ZSL approaches is not straightforward, since it requires careful adaptation that includes re-structuring of the loss terms. In particular, the approach of EpiFCR+SPNet achieves an average accuracy (AVG) of 20.0 over different target domains. The recently introduced CuMix [23] approach that targets ZSLDG, employs a curriculum-based mixing policy to generate increasingly complex training samples by mixing up multiple seen domains and categories available during training. The current state-of-art CuMix improves ZSLDG performance over EpiFCR+SPNet, achieving an average accuracy of 20.7 across the target domains. Our approach outperforms CuMix with an absolute gain of ${1.2}\%$ average across domains ( $\sim  6\%$ relative increase) and achieves average accuracy of 21.9 across the five target domains, setting a new state of the art. Furthermore, our method achieves consistent gains over CuMix on each of the target domains.

DomainNet上的结果:表1展示了我们提出的框架与最先进方法以及文献[23]中建立的所有基线方法在ZSLDG任务上的比较。我们首先报告了独立的零样本学习(ZSL)方法(如DEVISE [III]、ALE [II]和SPNet [&II])在ZSLDG任务上的性能，然后是将这些ZSL方法与标准的领域泛化(DG)方法(如DANN [121]和EpiFCR [133])结合所取得的性能。值得注意的是，在ZSLDG的情况下，将独立的ZSL方法与DANN结合所取得的性能低于单独的ZSL方法，因为标准的领域对齐方法在DomainNet数据集上已被证明是无效的，在某些情况下会导致负迁移[B1]。此外，正如文献[B3]所指出的，将EpiFCR(一种独立的DG方法)与独立的ZSL方法结合并不简单，因为这需要仔细调整，包括重新构建损失项。具体而言，EpiFCR + SPNet方法在不同目标领域上实现了20.0的平均准确率(AVG)。最近提出的针对ZSLDG的CuMix [23]方法采用了基于课程的混合策略，通过在训练期间混合多个可见领域和类别来生成日益复杂的训练样本。当前最先进的CuMix方法在ZSLDG性能上优于EpiFCR + SPNet，在目标领域上实现了20.7的平均准确率。我们的方法以跨领域平均绝对增益${1.2}\%$(相对增加$\sim  6\%$)优于CuMix，在五个目标领域上实现了21.9的平均准确率，创造了新的最先进水平。此外，我们的方法在每个目标领域上都比CuMix有持续的增益。

Results on DomainNet-LS: Tab. 2 shows the performance comparison on the DomainNet-LS benchmark. The SPNet [40] (for standard ZSL) achieves an average accuracy of 14.4, while its integration with EpiFCR [E8] (a standard DG approach) improves the performance to 15.4. The current state-of-art CuMix [23] approach for ZSLDG, achieves 16.5 as the average accuracy across the unseen domains. Despite the limited information available during training (and higher domain shift at test time), our approach improves over CuMix by achieving an average accuracy of 16.9 (1.6% relative gain), thereby showing better generalization.

DomainNet - LS上的结果:表2展示了在DomainNet - LS基准上的性能比较。SPNet [40](用于标准ZSL)实现了14.4的平均准确率，而将其与EpiFCR [E8](一种标准DG方法)集成后，性能提高到15.4。当前用于ZSLDG的最先进的CuMix [23]方法在未见领域上实现了16.5的平均准确率。尽管训练期间可用信息有限(且测试时领域偏移更大)，我们的方法通过实现16.9的平均准确率(相对增益1.6%)优于CuMix，从而显示出更好的泛化能力。

### 4.2 Ablation Study

### 4.2 消融研究

We perform an ablation study to understand the efficacy of each component in our proposed method for the ZSLDG task. Tab. 3 shows the performance gains achieved (on Domain-Net [GII]) by integrating one contribution at a time, in our approach, as below:

我们进行了消融研究，以了解我们提出的ZSLDG任务方法中每个组件的有效性。表3展示了我们的方法通过一次集成一个贡献(在Domain - Net [GII]上)所取得的性能增益，如下所示:

- The model learned by employing our multimodal alignment loss term ${\mathcal{L}}_{\text{align }}$ alone (detailed in Sec. 3.1) is denoted as M1

- 仅采用我们的多模态对齐损失项${\mathcal{L}}_{\text{align }}$(详见第3.1节)学习的模型记为M1

- Similarly, M2 denotes the model learned by integrating ${\mathcal{L}}_{\text{align }}$ with our loss term ${\mathcal{L}}_{\text{center }}$ , which achieves a structured latent space (Sec. 3.2).

- 类似地，M2 表示通过将 ${\mathcal{L}}_{\text{align }}$ 与我们的损失项 ${\mathcal{L}}_{\text{center }}$ 相结合学习得到的模型，该模型实现了一个结构化的潜在空间(第 3.2 节)。

- M3 denotes our overall framework, which is learned by integrating our joint invariance loss term ${\mathcal{L}}_{\text{joint-inv }}$ (Sec. 3.3) with ${\mathcal{L}}_{\text{align }}$ and ${\mathcal{L}}_{\text{center }}$ .

- M3 表示我们的整体框架，它是通过将我们的联合不变性损失项 ${\mathcal{L}}_{\text{joint-inv }}$(第 3.3 节)与 ${\mathcal{L}}_{\text{align }}$ 和 ${\mathcal{L}}_{\text{center }}$ 相结合学习得到的。

The M1 model, which performs multimodal adversarial alignment achieves an average accuracy (denoted as AVG in Tab. 3) of 18.5 across the target domains. Learning a structured latent embedding space along with the multimodal alignment enables the M2 model to achieve an average gain of 2.0 over M1 on the target domains. We note that the gains in M2 due to the integration of ${\mathcal{L}}_{\text{center }}$ with ${\mathcal{L}}_{\text{align }}$ are considerably high on the easier target domains (clipart, painting and sketch). This suggests that ${\mathcal{L}}_{\text{center }}$ is able to achieve an improved structuring of the latent embedding space. Our overall framework (M3) obtains the best results by achieving an average accuracy of 21.9 on the five target domains. Since M3 additionally involves learning the domain invariance w.r.t. the visual-semantic joint by employing ${\mathcal{L}}_{\text{joint-inv }}$ , it aids in improving ZSLDG performances on harder target domains such as quickdraw and infograph. These results clearly indicate that along with the multimodal alignment $\left( {\mathcal{L}}_{\text{align }}\right)$ , structuring the latent space $\left( {\mathcal{L}}_{\text{center }}\right)$ and learning the domain invariance w.r.t. the visual-semantic joint $\left( {\mathcal{L}}_{\text{joint-inv }}\right)$ are important for recognizing unseen classes in unseen domains.

M1 模型执行多模态对抗对齐，在目标域上实现了 18.5 的平均准确率(在表 3 中表示为 AVG)。与多模态对齐一起学习一个结构化的潜在嵌入空间，使 M2 模型在目标域上比 M1 平均提高了 2.0。我们注意到，由于将 ${\mathcal{L}}_{\text{center }}$ 与 ${\mathcal{L}}_{\text{align }}$ 相结合，M2 在较简单的目标域(剪贴画、绘画和素描)上的提升相当大。这表明 ${\mathcal{L}}_{\text{center }}$ 能够实现潜在嵌入空间的改进结构化。我们的整体框架(M3)在五个目标域上实现了 21.9 的平均准确率，取得了最佳结果。由于 M3 还通过采用 ${\mathcal{L}}_{\text{joint-inv }}$ 学习视觉 - 语义联合的域不变性，它有助于提高在更难的目标域(如简笔画和信息图)上的零样本跨域泛化(ZSLDG)性能。这些结果清楚地表明，与多模态对齐 $\left( {\mathcal{L}}_{\text{align }}\right)$ 一起，构建潜在空间 $\left( {\mathcal{L}}_{\text{center }}\right)$ 以及学习视觉 - 语义联合的域不变性 $\left( {\mathcal{L}}_{\text{joint-inv }}\right)$ 对于识别未见域中的未见类别非常重要。

## 5 Conclusions

## 5 结论

We propose a novel approach to address the challenging problem of recognizing unseen classes in unseen domains (ZSLDG). Our method learns a domain-agnostic structured latent embedding space which is achieved by employing a multimodal alignment loss term that aligns the visual and semantic spaces, a center loss term that separates different classes in the latent space and a joint invariance term that aids in handling new classes from unseen domains. Our experiments and ablation studies on challenging benchmarks (DomainNet, DomainNet-LS) show the superiority of our approach over existing methods. Future directions include leveraging self-supervision to obtain domain-invariant features and tackle dynamic changes in the label space of categories.

我们提出了一种新颖的方法来解决在未见域中识别未见类别的具有挑战性的问题(零样本跨域泛化，ZSLDG)。我们的方法学习一个与域无关的结构化潜在嵌入空间，这是通过采用一个将视觉和语义空间对齐的多模态对齐损失项、一个在潜在空间中分离不同类别的中心损失项以及一个有助于处理来自未见域的新类别的联合不变性项来实现的。我们在具有挑战性的基准数据集(DomainNet、DomainNet - LS)上进行的实验和消融研究表明，我们的方法优于现有方法。未来的研究方向包括利用自监督来获得域不变特征，并应对类别标签空间的动态变化。

## References

## 参考文献

[1] Z. Akata, F. Perronnin, Z. Harchaoui, and C. Schmid. Label-embedding for attribute-based classification. In CVPR, pages 819-826, 2013.

[1] Z. Akata、F. Perronnin、Z. Harchaoui 和 C. Schmid。基于属性分类的标签嵌入。见《计算机视觉与模式识别会议(CVPR)》，第 819 - 826 页，2013 年。

[2] Z. Akata, S. Reed, D. Walter, H. Lee, and B. Schiele. Evaluation of output embeddings for fine-grained image classification. CVPR, 2015.

[2] Z. Akata、S. Reed、D. Walter、H. Lee 和 B. Schiele。用于细粒度图像分类的输出嵌入评估。《计算机视觉与模式识别会议(CVPR)》，2015 年。

[3] Z. Akata, F. Perronnin, Z. Harchaoui, and C. Schmid. Label embedding for image classification. TPAMI, 2016.

[3] Z. Akata、F. Perronnin、Z. Harchaoui 和 C. Schmid。用于图像分类的标签嵌入。《模式分析与机器智能汇刊(TPAMI)》，2016 年。

[4] M. Arjovsky, S. Chintala, and L. Bottou. Wasserstein gan. ICML, 2017.

[4] M. Arjovsky、S. Chintala 和 L. Bottou。Wasserstein 生成对抗网络(Wasserstein GAN)。《国际机器学习会议(ICML)》，2017 年。

[5] Y. Balaji, S. Sankaranarayanan, and R. Chellappa. Metareg: Towards domain generalization using meta-regularization. In NeurIPS, 2018.

[5] Y. Balaji、S. Sankaranarayanan 和 R. Chellappa。元正则化(MetaReg):利用元正则化实现域泛化。见《神经信息处理系统大会(NeurIPS)》，2018 年。

[6] J. Deng, W. Dong, R. Socher, L. Li, K. Li, and L. Fei-Fei. Imagenet: A large-scale hierarchical image database. In CVPR, pages 248-255. Ieee, 2009.

[6] J. Deng、W. Dong、R. Socher、L. Li、K. Li 和 L. Fei - Fei。ImageNet:一个大规模分层图像数据库。见《计算机视觉与模式识别会议(CVPR)》，第 248 - 255 页。IEEE，2009 年。

[7] G. Dinu and M. Baroni. Improving zero-shot learning by mitigating the hubness problem. CoRR, abs/1412.6568, 2015.

[7] G. Dinu 和 M. Baroni。通过缓解中心性问题改进零样本学习。《计算机研究存储库(CoRR)》，编号 abs/1412.6568，2015 年。

[8] R. Felix, V. BG Kumar, I. Reid, and G. Carneiro. Multi-modal cycle-consistent generalized zero-shot learning. ECCV, 2018.

[8] R. Felix、V. BG Kumar、I. Reid 和 G. Carneiro。多模态循环一致的广义零样本学习。《欧洲计算机视觉会议(ECCV)》，2018 年。

[9] A. Frome, G. S. Corrado, J. Shlens, S. Bengio, M. A. Ranzato J. Dean, and T. Mikolov. Devise: A deep visual-semantic embedding model. NeurIPS, 2013.

[9] A. 弗罗梅(A. Frome)、G. S. 科拉多(G. S. Corrado)、J. 施伦斯(J. Shlens)、S. 本吉奥(S. Bengio)、M. A. 兰扎托(M. A. Ranzato)、J. 迪恩(J. Dean)和 T. 米科洛夫(T. Mikolov)。Devise:一种深度视觉语义嵌入模型。神经信息处理系统大会(NeurIPS)，2013 年。

[10] A. Frome, G.S. Corrado, J. Shlens, S.Bengio, J.Dean, M. Ranzato, and T.Mikolov. Devise: A deep visual-semantic embedding model. In NeurIPS, pages 2121-2129, 2013.

[10] A. 弗罗梅(A. Frome)、G. S. 科拉多(G. S. Corrado)、J. 施伦斯(J. Shlens)、S. 本吉奥(S. Bengio)、J. 迪恩(J. Dean)、M. 兰扎托(M. Ranzato)和 T. 米科洛夫(T. Mikolov)。Devise:一种深度视觉语义嵌入模型。见《神经信息处理系统大会论文集》(NeurIPS)，第 2121 - 2129 页，2013 年。

[11] Y. Ganin, E. Ustinova, H. Ajakan, P. Germain, H. Larochelle, F. Lavioletteand, M.Marchand, and V. Lempitsky. Domain-adversarial training of neural networks. JMLR, 17(1):2096-2030, 2016.

[11] Y. 加宁(Y. Ganin)、E. 乌斯蒂诺娃(E. Ustinova)、H. 阿贾坎(H. Ajakan)、P. 热尔曼(P. Germain)、H. 拉罗谢尔(H. Larochelle)、F. 拉维奥莱特(F. Laviolette)、M. 马尔尚(M. Marchand)和 V. 伦皮茨基(V. Lempitsky)。神经网络的领域对抗训练。《机器学习研究杂志》(JMLR)，17(1):2096 - 2030，2016 年。

[12] M. Ghifary, W. Kleijn, M. Zhang, and D. Balduzzi. Domain generalization for object recognition with multi-task autoencoders. (ICCV), 2015.

[12] M. 吉法里(M. Ghifary)、W. 克莱因(W. Kleijn)、M. 张(M. Zhang)和 D. 巴尔杜齐(D. Balduzzi)。使用多任务自编码器进行目标识别的领域泛化。国际计算机视觉大会(ICCV)，2015 年。

[13] I. Gulrajani, F. Ahmed, M. Arjovsky, V. Dumoulin, and A. Courville. Improved training of wasserstein gans. NeurIPS, 2017.

[13] I. 古拉贾尼(I. Gulrajani)、F. 艾哈迈德(F. Ahmed)、M. 阿乔夫斯基(M. Arjovsky)、V. 迪穆兰(V. Dumoulin)和 A. 库尔维尔(A. Courville)。改进的 Wasserstein 生成对抗网络训练方法。神经信息处理系统大会(NeurIPS)，2017 年。

[14] A. Lazaridou, G. Dinu, and M. Baroni. Hubness and pollution: Delving into crossspace mapping for zero-shot learning. ${ACL},{2015}$ .

[14] A. 拉扎里杜(A. Lazaridou)、G. 迪努(G. Dinu)和 M. 巴罗尼(M. Baroni)。枢纽性与污染:深入研究零样本学习的跨空间映射。${ACL},{2015}$ 。

[15] C. Li, K. Xu, J. Zhu, and B. Zhang. Triple generative adversarial nets. In NeurIPS, 2017.

[15] C. 李(C. Li)、K. 徐(K. Xu)、J. 朱(J. Zhu)和 B. 张(B. Zhang)。三重生成对抗网络。见神经信息处理系统大会(NeurIPS)，2017 年。

[16] D. Li, Y. Yang, Y. Song, and T. M. Hospedales. Deeper, broader and artier domain generalization. (ICCV), pages 5543-5551, 2017.

[16] D. 李(D. Li)、Y. 杨(Y. Yang)、Y. 宋(Y. Song)和 T. M. 霍斯佩代尔斯(T. M. Hospedales)。更深、更广、更具艺术性的领域泛化。国际计算机视觉大会(ICCV)，第 5543 - 5551 页，2017 年。

[17] D. Li, Y. Yang, Y. Song, and T. M. Hospedales. Learning to generalize: Meta-learning for domain generalization. In ${AAAI},{2018}$ .

[17] D. 李(D. Li)、Y. 杨(Y. Yang)、Y. 宋(Y. Song)和 T. M. 霍斯佩代尔斯(T. M. Hospedales)。学习泛化:用于领域泛化的元学习。见${AAAI},{2018}$ 。

[18] D. Li, J. Zhang, Y. Yang, C. Liu, Y. Song, and T. M. Hospedales. Episodic training for domain generalization. (ICCV), pages 1446-1455, 2019.

[18] D. 李(D. Li)、J. 张(J. Zhang)、Y. 杨(Y. Yang)、C. 刘(C. Liu)、Y. 宋(Y. Song)和 T. M. 霍斯佩代尔斯(T. M. Hospedales)。用于领域泛化的情节式训练。国际计算机视觉大会(ICCV)，第 1446 - 1455 页，2019 年。

[19] H. Li, S. J. Pan, S. Wang, and A. Kot. Domain generalization with adversarial feature learning. CVPR, pages 5400-5409, 2018.

[19] H. 李(H. Li)、S. J. 潘(S. J. Pan)、S. 王(S. Wang)和 A. 科特(A. Kot)。通过对抗特征学习进行领域泛化。计算机视觉与模式识别会议(CVPR)，第 5400 - 5409 页，2018 年。

[20] H. Li, S. J. Pan, S. Wang, and A. Kot. Domain generalization with adversarial feature learning. 2018 IEEE/CVF Conference on Computer Vision and Pattern Recognition, pages 5400-5409, 2018.

[20] H. 李(H. Li)、S. J. 潘(S. J. Pan)、S. 王(S. Wang)和 A. 科特(A. Kot)。通过对抗特征学习进行领域泛化。2018 年电气与电子工程师协会/计算机视觉基金会计算机视觉与模式识别会议(IEEE/CVF Conference on Computer Vision and Pattern Recognition)，第 5400 - 5409 页，2018 年。

[21] J. Li, M. Jing, K. Lu, Z. Ding, L. Zhu, and Z. Huang. Leveraging the invariant side of generative zero-shot learning. 2019 IEEE/CVF Conference on Computer Vision and Pattern Recognition (CVPR), pages 7394-7403, 2019.

[21] J. 李(J. Li)、M. 景(M. Jing)、K. 陆(K. Lu)、Z. 丁(Z. Ding)、L. 朱(L. Zhu)和 Z. 黄(Z. Huang)。利用生成式零样本学习的不变性方面。2019 年电气与电子工程师协会/计算机视觉基金会计算机视觉与模式识别会议(IEEE/CVF Conference on Computer Vision and Pattern Recognition，CVPR)，第 7394 - 7403 页，2019 年。

[22] Y. Li, X. Tian, M. Gong, Y. Liu, T. Liu, K. Zhang, and D. Tao. Deep domain generalization via conditional invariant adversarial networks. In ${ECCV},{2018}$ .

[23] Y. 李(Y. Li)、X. 田(X. Tian)、M. 龚(M. Gong)、Y. 刘(Y. Liu)、T. 刘(T. Liu)、K. 张(K. Zhang)和 D. 陶(D. Tao)。通过条件不变对抗网络进行深度领域泛化。见${ECCV},{2018}$ 。

[23] M. Mancini, Z. Akata, E. Ricci, and B. Caputo. Towards recognizing unseen categories in unseen domains. In ${ECCV},{2020}$ .

[24] M. 曼奇尼(M. Mancini)、Z. 阿卡塔(Z. Akata)、E. 里奇(E. Ricci)和 B. 卡普托(B. Caputo)。迈向在未见领域中识别未见类别。见${ECCV},{2020}$ 。

[24] U. Maniyar, K. J. Joseph, A. Deshmukh, Ü. Dogan, and V. Balasubramanian. Zero-shot domain generalization. ArXiv, 2020.

[25] U. 马尼亚尔(U. Maniyar)、K. J. 约瑟夫(K. J. Joseph)、A. 德什穆克(A. Deshmukh)、Ü. 多安(Ü. Dogan)和 V. 巴拉苏布拉马尼亚姆(V. Balasubramanian)。零样本领域泛化。预印本平台(ArXiv)，2020 年。

[25] T. Mikolov, K. Chen, G. Corrado, and J. Dean. Efficient estimation of word representations in vector space. In ${ICLR},{2013}$ .

[25] T. 米科洛夫(T. Mikolov)、K. 陈(K. Chen)、G. 科拉多(G. Corrado)和 J. 迪恩(J. Dean)。向量空间中词表示的高效估计。见 ${ICLR},{2013}$。

[26] A. Mishra, S. K. Reddy, A. Mittal, and H. A Murthy. A generative model for zero shot learning using conditional variational autoencoders. CVPRW, 2018.

[26] A. 米什拉(A. Mishra)、S.K. 雷迪(S.K. Reddy)、A. 米塔尔(A. Mittal)和 H.A. 穆尔蒂(H.A. Murthy)。使用条件变分自编码器的零样本学习生成模型。计算机视觉与模式识别研讨会(CVPRW)，2018 年。

[27] K. Muandet, D. Balduzzi, and B. Schölkopf. Domain generalization via invariant feature representation. ArXiv, abs/1301.2115, 2013.

[27] K. 穆安代特(K. Muandet)、D. 巴尔杜齐(D. Balduzzi)和 B. 肖尔科普夫(B. Schölkopf)。通过不变特征表示进行领域泛化。预印本 arXiv:1301.2115，2013 年。

[28] S. Narayan, A. Gupta, F.S. Khan, C.G.M. Snoek, and L.Shao. Latent embedding feedback and discriminative features for zero-shot classification. In ${ECCV},{2020}$ .

[28] S. 纳拉扬(S. Narayan)、A. 古普塔(A. Gupta)、F.S. 汗(F.S. Khan)、C.G.M. 斯诺克(C.G.M. Snoek)和 L. 邵(L. Shao)。用于零样本分类的潜在嵌入反馈和判别特征。见 ${ECCV},{2020}$。

[29] T. Nguyen, T. Le, H. Vu, and D. Q. Phung. Dual discriminator generative adversarial nets. In NeurIPS, 2017.

[29] T. 阮(T. Nguyen)、T. 勒(T. Le)、H. 武(H. Vu)和 D.Q. 冯(D.Q. Phung)。双判别器生成对抗网络。见神经信息处理系统大会(NeurIPS)，2017 年。

[30] J. Ni, S. Zhang, and H. Xie. Dual adversarial semantics-consistent network for generalized zero-shot learning. NeurIPS, 2019.

[30] J. 倪(J. Ni)、S. 张(S. Zhang)和 H. 谢(H. Xie)。用于广义零样本学习的双对抗语义一致网络。神经信息处理系统大会(NeurIPS)，2019 年。

[31] X. Peng, Q. Bai, X. Xia, Z. Huang, K. Saenko, and B. Wang. Moment matching for multi-source domain adaptation. (ICCV), pages 1406-1415, 2019.

[31] X. 彭(X. Peng)、Q. 白(Q. Bai)、X. 夏(X. Xia)、Z. 黄(Z. Huang)、K. 塞内科(K. Saenko)和 B. 王(B. Wang)。多源领域自适应的矩匹配。(国际计算机视觉大会(ICCV))，第 1406 - 1415 页，2019 年。

[32] B. Romera-Paredes and P. H. Torr. An embarrassingly simple approach to zero-shot learning. ICML, 2015.

[32] B. 罗梅拉 - 帕雷德斯(B. Romera - Paredes)和 P.H. 托尔(P.H. Torr)。一种极其简单的零样本学习方法。国际机器学习会议(ICML)，2015 年。

[33] E. Schonfeld, S. Ebrahimi, S. Sinha, T. Darrell, and Z. Akata. Generalized zero-and few-shot learning via aligned variational autoencoders. CVPR, 2019.

[33] E. 舍恩菲尔德(E. Schonfeld)、S. 易卜拉希米(S. Ebrahimi)、S. 辛哈(S. Sinha)、T. 达雷尔(T. Darrell)和 Z. 阿卡塔(Z. Akata)。通过对齐变分自编码器进行广义零样本和少样本学习。计算机视觉与模式识别会议(CVPR)，2019 年。

[34] S. Shankar, V. Piratla, S. Chakrabarti, S. Chaudhuri, P. Jyothi, and S. Sarawagi. Generalizing across domains via cross-gradient training. ArXiv, 2018.

[34] S. 尚卡尔(S. Shankar)、V. 皮拉特(V. Piratla)、S. 查克拉巴蒂(S. Chakrabarti)、S. 乔杜里(S. Chaudhuri)、P. 乔蒂(P. Jyothi)和 S. 萨拉瓦吉(S. Sarawagi)。通过跨梯度训练进行跨领域泛化。预印本 arXiv，2018 年。

[35] R. Socher, M. Ganjoo, C.D. Manning, and A. Ng. Zero-shot learning through cross-modal transfer. NeurIPS, 2013.

[35] R. 索切尔(R. Socher)、M. 甘朱(M. Ganjoo)、C.D. 曼宁(C.D. Manning)和 A. 吴(A. Ng)。通过跨模态转移进行零样本学习。神经信息处理系统大会(NeurIPS)，2013 年。

[36] Y.-H. H. Tsai, L.-K. Huang, and R. Salakhutdinov. Learning robust visual-semantic embeddings. ICCV, 2017.

[36] 蔡宜宏(Y.-H.H. Tsai)、黄立凯(L.-K. Huang)和 R. 萨拉胡丁诺夫(R. Salakhutdinov)。学习鲁棒的视觉 - 语义嵌入。国际计算机视觉大会(ICCV)，2017 年。

[37] R. Volpi, H. Namkoong, O. Sener, J. C. Duchi, V. Murino, and S. Savarese. Generalizing to unseen domains via adversarial data augmentation. In NeurIPS, 2018.

[37] R. 沃尔皮(R. Volpi)、H. 南孔(H. Namkoong)、O. 森纳(O. Sener)、J.C. 杜奇(J.C. Duchi)、V. 穆里诺(V. Murino)和 S. 萨瓦雷塞(S. Savarese)。通过对抗性数据增强泛化到未见领域。见神经信息处理系统大会(NeurIPS)，2018 年。

[38] M. R. Vyas, H. Venkateswara, and S. Panchanathan. Leveraging seen and unseen semantic relationships for generative zero-shot learning. In ${ECCV},{2020}$ .

[39] M.R. 维亚斯(M.R. Vyas)、H. 文卡特斯瓦拉(H. Venkateswara)和 S. 潘查纳坦(S. Panchanathan)。利用已见和未见语义关系进行生成式零样本学习。见 ${ECCV},{2020}$。

[39] Y. Wen, K. Zhang, Z. Li, and Y. Qiao. A discriminative feature learning approach for deep face recognition. In ${ECCV},{2016}$ .

[39] 文宇(Y. Wen)、张凯(K. Zhang)、李泽(Z. Li)和乔宇(Y. Qiao)。一种用于深度人脸识别的判别特征学习方法。见 ${ECCV},{2016}$。

[40] Y. Xian, T. Lorenz, B. Schiele, and Z. Akata. Feature generating networks for zero-shot learning. CVPR, 2018.

[40] 西安(Y. Xian)、洛伦茨(T. Lorenz)、施勒(B. Schiele)和阿卡塔(Z. Akata)。用于零样本学习的特征生成网络。计算机视觉与模式识别会议(CVPR)，2018 年。

[41] Y. Xian, S.Choudhury, Y. He, B. Schiele, and Z. Akata. Semantic projection network for zero-and few-label semantic segmentation. In CVPR, pages 8256-8265, 2019.

[41] 冼(Xian)、乔杜里(Choudhury)、何(He)、席勒(Schiele)和阿卡塔(Akata)。用于零标签和少标签语义分割的语义投影网络。收录于《计算机视觉与模式识别会议论文集》(CVPR)，第8256 - 8265页，2019年。

[42] Y. Xian, S. Sharma, B. Schiele, and Z. Akata. F-vaegan-d2: A feature generating framework for any-shot learning. 2019 IEEE/CVF Conference on Computer Vision and Pattern Recognition (CVPR), pages 10267-10276, 2019.

[42] 冼(Xian)、夏尔马(Sharma)、席勒(Schiele)和阿卡塔(Akata)。F - vaegan - d2:用于任意样本学习的特征生成框架。收录于2019年电气与电子工程师协会/计算机视觉基金会计算机视觉与模式识别会议(IEEE/CVF Conference on Computer Vision and Pattern Recognition，CVPR)，第10267 - 10276页，2019年。

[43] Z. Xu, W. Li, L. Niu, and D. Xu. Exploiting low-rank structure from latent domains for domain generalization. In ${ECCV},{2014}$ .

[43] 徐(Xu)、李(Li)、牛(Niu)和徐(Xu)。从潜在领域中挖掘低秩结构以实现领域泛化。收录于${ECCV},{2014}$。

[44] P. Yang and W. Gao. Multi-view discriminant transfer learning. In IJCAI, 2013.

[44] 杨(Yang)和高(Gao)。多视图判别式迁移学习。收录于《国际人工智能联合会议论文集》(IJCAI)，2013年。