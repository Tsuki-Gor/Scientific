# An Empirical Study and Analysis of Generalized Zero-Shot Learning for Object Recognition in the Wild

# 野外目标识别广义零样本学习的实证研究与分析

Wei-Lun Chao ${}^{1\left( \infty \right) }$ , Soravit Changpinyo ${}^{1}$ , Boqing Gong ${}^{2}$ , and Fei Sha ${}^{3}$ ${}^{1}$ Department of Computer Science, University of Southern California, Los Angeles, USA \{weilunc, schangpi\}@usc.edu ${}^{2}$ Center for Research in Computer Vision, University of Central Florida, Orlando, USA

赵伟伦 ${}^{1\left( \infty \right) }$ ，索拉维特·昌皮尼奥 ${}^{1}$ ，龚博清 ${}^{2}$ ，沙飞 ${}^{3}$ ${}^{1}$ 美国南加州大学计算机科学系，洛杉矶 \{weilunc, schangpi\}@usc.edu ${}^{2}$ 美国中佛罗里达大学计算机视觉研究中心，奥兰多

bgong@crcv.ucf.edu

${}^{3}$ Department of Computer Science, University of California, Los Angeles, USA

${}^{3}$ 美国加利福尼亚大学洛杉矶分校计算机科学系

feisha@cs.ucla.edu

Abstract. We investigate the problem of generalized zero-shot learning (GZSL). GZSL relaxes the unrealistic assumption in conventional zero-shot learning (ZSL) that test data belong only to unseen novel classes. In GZSL, test data might also come from seen classes and the labeling space is the union of both types of classes. We show empirically that a straightforward application of classifiers provided by existing ZSL approaches does not perform well in the setting of GZSL. Motivated by this, we propose a surprisingly simple but effective method to adapt ZSL approaches for GZSL. The main idea is to introduce a calibration factor to calibrate the classifiers for both seen and unseen classes so as to balance two conflicting forces: recognizing data from seen classes and those from unseen ones. We develop a new performance metric called the Area Under Seen-Unseen accuracy Curve to characterize this tradeoff. We demonstrate the utility of this metric by analyzing existing ZSL approaches applied to the generalized setting. Extensive empirical studies reveal strengths and weaknesses of those approaches on three well-studied benchmark datasets, including the large-scale ImageNet with more than 20,000 unseen categories. We complement our comparative studies in learning methods by further establishing an upper bound on the performance limit of GZSL. In particular, our idea is to use class-representative visual features as the idealized semantic embeddings. We show that there is a large gap between the performance of existing approaches and the performance limit, suggesting that improving the quality of class semantic embeddings is vital to improving ZSL.

摘要。我们研究了广义零样本学习(GZSL)问题。广义零样本学习放宽了传统零样本学习(ZSL)中不切实际的假设，即测试数据仅属于未见的新类别。在广义零样本学习中，测试数据也可能来自已见类别，且标注空间是这两种类型类别的并集。我们通过实证表明，直接应用现有零样本学习方法提供的分类器在广义零样本学习设置下表现不佳。受此启发，我们提出了一种简单却有效的方法，使零样本学习方法适用于广义零样本学习。主要思想是引入一个校准因子，对已见和未见类别的分类器进行校准，以平衡两种相互冲突的力量:识别来自已见类别的数据和来自未见类别的数据。我们开发了一种新的性能指标，称为已见 - 未见准确率曲线下面积，以表征这种权衡。我们通过分析应用于广义设置的现有零样本学习方法，证明了该指标的实用性。大量的实证研究揭示了这些方法在三个经过充分研究的基准数据集上的优缺点，包括拥有超过20000个未见类别的大规模ImageNet数据集。我们通过进一步确定广义零样本学习性能极限的上限，对学习方法的比较研究进行了补充。具体而言，我们的想法是使用类别代表性视觉特征作为理想化的语义嵌入。我们表明，现有方法的性能与性能极限之间存在很大差距，这表明提高类别语义嵌入的质量对于改进零样本学习至关重要。

---

W.-L. Chao and S. Changpinyo-Equal contribution.

赵伟伦和索拉维特·昌皮尼奥贡献相同。

Electronic supplementary material The online version of this chapter (doi:10. 1007/978-3-319-46475-6_4) contains supplementary material, which is available to authorized users.

电子补充材料 本章的在线版本(doi:10. 1007/978 - 3 - 319 - 46475 - 6_4)包含补充材料，仅供授权用户使用。

---

## 1 Introduction

## 1 引言

The availability of large-scale labeled training images is one of the key factors that contribute to recent successes in visual object recognition and classification. It is well-known, however, that object frequencies in natural images follow long-tailed distributions [1-3]. For example, some animal or plant species are simply rare by nature - it is uncommon to find alpacas wandering around the streets. Furthermore, brand new categories could just emerge with zero or little labeled images; newly defined visual concepts or products are introduced everyday. In this real-world setting, it would be desirable for computer vision systems to be able to recognize instances of those rare classes, while demanding minimum human efforts and labeled examples.

大规模带标签训练图像的可用性是促成近期视觉目标识别和分类取得成功的关键因素之一。然而，众所周知，自然图像中的目标频率遵循长尾分布 [1 - 3]。例如，一些动物或植物物种本质上就很稀有——在街上看到羊驼闲逛是不常见的。此外，全新的类别可能在没有或只有少量带标签图像的情况下出现；每天都会引入新定义的视觉概念或产品。在这种现实世界的环境中，计算机视觉系统能够识别那些稀有类别的实例，同时只需要最少的人力和带标签的示例，这将是非常理想的。

Zero-shot learning (ZSL) has long been believed to hold the key to the above problem of recognition in the wild. ZSL differentiates two types of classes: seen and unseen, where labeled examples are available for seen classes only. Without labeled data, models for unseen classes are learned by relating them to seen ones. This is often achieved by embedding both seen and unseen classes into a common semantic space, such as visual attributes [4-6] or WORD2VEC representations of the class names [7-9]. This common semantic space enables transferring models for the seen classes to those for the unseen ones [10].

长期以来，人们一直认为零样本学习(ZSL)是解决上述野外识别问题的关键。零样本学习区分两种类型的类别:已见和未见，其中只有已见类别有带标签的示例。在没有带标签数据的情况下，未见类别的模型通过将它们与已见类别相关联来学习。这通常是通过将已见和未见类别都嵌入到一个共同的语义空间中来实现的，例如视觉属性 [4 - 6] 或类别名称的WORD2VEC表示 [7 - 9]。这个共同的语义空间使得已见类别的模型能够迁移到未见类别上 [10]。

The setup for ZSL is that once models for unseen classes are learned, they are judged based on their ability to discriminate among unseen classes, assuming the absence of seen objects during the test phase. Originally proposed in the seminal work of Lampert et al. [4], this setting has almost always been adopted for evaluating ZSL methods [8,10-28].

零样本学习的设置是，一旦学习了未见类别的模型，就根据它们在未见类别之间进行区分的能力来评判这些模型，假设在测试阶段不存在已见目标。最初由兰佩特等人在开创性工作 [4] 中提出，这种设置几乎一直被用于评估零样本学习方法 [8,10 - 28]。

But, does this problem setting truly reflect what recognition in the wild entails? While the ability to learn novel concepts is by all means a trait that any zero-shot learning systems should possess, it is merely one side of the coin. The other important - yet so far under-studied - trait is the ability to remember past experiences, i.e., the seen classes.

但是，这种问题设置真的反映了野外识别所包含的内容吗？虽然学习新的概念的能力无疑是任何零样本学习系统都应该具备的特征，但这只是问题的一个方面。另一个重要但到目前为止研究不足的特征是记住过去经验的能力，即识别已见类别的能力。

Why is this trait desirable? Consider how data are distributed in the real world. The seen classes are often more common than the unseen ones; it is therefore unrealistic to assume that we will never encounter them during the test stage. For models generated by ZSL to be truly useful, they should not only accurately discriminate among either seen or unseen classes themselves but also accurately discriminate between the seen and unseen ones.

为什么这种特征是可取的呢？考虑一下现实世界中数据的分布情况。已见类别通常比未见类别更常见；因此，假设我们在测试阶段永远不会遇到已见类别是不现实的。为了使零样本学习生成的模型真正有用，它们不仅应该能够准确地区分已见或未见类别本身，还应该能够准确地区分已见和未见类别。

Thus, to understand better how existing ZSL approaches will perform in the real world, we advocate evaluating them in the setting of generalized zero-shot learning (GZSL), where test data are from both seen and unseen classes and we need to classify them into the joint labeling space of both types of classes. Previous work in this direction is scarce. See related work for more details.

因此，为了更好地理解现有的零样本学习(ZSL)方法在现实世界中的表现，我们主张在广义零样本学习(GZSL)的设定下对它们进行评估。在这种设定中，测试数据来自已见和未见类别，我们需要将它们分类到这两种类型类别的联合标签空间中。此前在这方面的研究很少。更多细节请参阅相关工作。

Our contributions include an extensive empirical study of several existing ZSL approaches in this new setting. We show that a straightforward application of classifiers constructed by those approaches performs poorly. In particular, test data from unseen classes are almost always classified as a class from the seen ones. We propose a surprisingly simple yet very effective method called calibrated stacking to address this problem. This method is mindful of the two conflicting forces: recognizing data from seen classes and recognizing data from unseen ones. We introduce a new performance metric called Area Under Seen-Unseen accuracy Curve (AUSUC) that can evaluate ZSL approaches on how well they can trade off between the two. We demonstrate the utility of this metric by evaluating several representative ZSL approaches under this metric on three benchmark datasets, including the full ImageNet Fall 2011 release dataset [29] that contains approximately 21,000 unseen categories.

我们的贡献包括在这种新设定下对几种现有的ZSL方法进行广泛的实证研究。我们发现，直接应用这些方法构建的分类器效果很差。特别是，来自未见类别的测试数据几乎总是被分类为已见类别之一。我们提出了一种简单却非常有效的方法，称为校准堆叠法，以解决这个问题。该方法考虑到了两种相互冲突的因素:识别来自已见类别的数据和识别来自未见类别的数据。我们引入了一种新的性能指标，称为已见 - 未见准确率曲线下面积(AUSUC)，它可以评估ZSL方法在这两者之间的权衡能力。我们通过在三个基准数据集上使用该指标评估几种有代表性的ZSL方法，证明了该指标的实用性，其中包括包含约21,000个未见类别的完整ImageNet 2011秋季发布数据集 [29]。

We complement our comparative studies in learning methods by further establishing an upper bound on the performance limit of ZSL. In particular, our idea is to use class-representative visual features as the idealized semantic embeddings to construct ZSL classifiers. We show that there is a large gap between existing approaches and this ideal performance limit, suggesting that improving class semantic embeddings is vital to achieve GZSL.

我们在学习方法的比较研究基础上，进一步确定了ZSL性能极限的上限。具体来说，我们的想法是使用类别代表性视觉特征作为理想化的语义嵌入来构建ZSL分类器。我们发现，现有方法与这种理想性能极限之间存在很大差距，这表明改进类别语义嵌入对于实现广义零样本学习(GZSL)至关重要。

The rest of the paper is organized as follows. Section 2 reviews relevant literature. We define GZSL formally and shed lights on its difficulty in Sect. 3. In Sect. 4, we propose a method to remedy the observed issues in the previous section and compare it to related approaches. Experimental results, detailed analysis, and discussions are provided in Sects. 5, 6, and 7, respectively.

本文的其余部分组织如下。第2节回顾相关文献。我们在第3节正式定义广义零样本学习(GZSL)并阐明其难点。在第4节，我们提出一种方法来解决上一节中观察到的问题，并将其与相关方法进行比较。实验结果、详细分析和讨论分别在第5、6和7节给出。

## 2 Related Work

## 2 相关工作

There has been very little work on generalized zero-shot learning. $\left\lbrack  {8,{17},{30},{31}}\right\rbrack$ allow the label space of their classifiers to include seen classes but they only test on the data from the unseen classes. [9] proposes a two-stage approach that first determines whether a test data point is from a seen or unseen class, and then apply the corresponding classifiers. However, their experiments are limited to only 2 or 6 unseen classes. We describe and compare to their methods in Sects. 4.3, 5, and the Supplementary Material. In the domain of action recognition, [32] investigates the generalized setting with only up to 3 seen classes. $\left\lbrack  {{33},{34}}\right\rbrack$ focus on training a zero-shot binary classifier for each unseen class (against seen ones) - it is not clear how to distinguish multiple unseen classes from the seen ones. Finally, open set recognition [35-37] considers testing on both types of classes, but treating the unseen ones as a single outlier class.

关于广义零样本学习的研究非常少。$\left\lbrack  {8,{17},{30},{31}}\right\rbrack$允许其分类器的标签空间包含已见类别，但他们只在来自未见类别的数据上进行测试。[9]提出了一种两阶段方法，首先确定一个测试数据点是来自已见类别还是未见类别，然后应用相应的分类器。然而，他们的实验仅限于2个或6个未见类别。我们在第4.3节、第5节和补充材料中描述并比较了他们的方法。在动作识别领域，[32]仅研究了最多3个已见类别的广义设定。$\left\lbrack  {{33},{34}}\right\rbrack$专注于为每个未见类别(相对于已见类别)训练一个零样本二分类器 - 目前尚不清楚如何从已见类别中区分多个未见类别。最后，开放集识别 [35 - 37]考虑在两种类型的类别上进行测试，但将未见类别视为一个单一的离群类别。

## 3 Generalized Zero-Shot Learning

## 3 广义零样本学习

In this section, we describe formally the setting of generalized zero-shot learning. We then present empirical evidence to illustrate the difficulty of this problem.

在本节中，我们正式描述广义零样本学习的设定。然后，我们提供实证证据来说明这个问题的难度。

### 3.1 Conventional and Generalized Zero-Shot Learning

### 3.1 传统零样本学习和广义零样本学习

Suppose we are given the training data $\mathcal{D} = {\left\{  \left( {\mathbf{x}}_{n} \in  {\mathbb{R}}^{\mathrm{D}},{y}_{n}\right) \right\}  }_{n = 1}^{\mathrm{N}}$ with the labels ${y}_{n}$ from the label space of seen classes $\mathcal{S} = \{ 1,2,\cdots ,\mathrm{S}\}$ . Denote by $\mathcal{U} = \{ \mathrm{S} + 1,\cdots ,\mathrm{S} + \mathrm{U}\}$ the label space of unseen classes. We use $\mathcal{T} = \mathcal{S} \cup  \mathcal{U}$ to represent the union of the two sets of classes.

假设我们得到了训练数据 $\mathcal{D} = {\left\{  \left( {\mathbf{x}}_{n} \in  {\mathbb{R}}^{\mathrm{D}},{y}_{n}\right) \right\}  }_{n = 1}^{\mathrm{N}}$，其标签 ${y}_{n}$ 来自已见类别的标签空间 $\mathcal{S} = \{ 1,2,\cdots ,\mathrm{S}\}$。用 $\mathcal{U} = \{ \mathrm{S} + 1,\cdots ,\mathrm{S} + \mathrm{U}\}$ 表示未见类别的标签空间。我们用 $\mathcal{T} = \mathcal{S} \cup  \mathcal{U}$ 表示这两组类别的并集。

In the (conventional) zero-shot learning (ZSL) setting, the main goal is to classify test data into the unseen classes, assuming the absence of the seen classes in the test phase. In other words, each test data point is assumed to come from and will be assigned to one of the labels in $\mathcal{U}$ .

在(传统)零样本学习(ZSL)设定中，主要目标是将测试数据分类到未见类别中，假设在测试阶段不存在已见类别。换句话说，假设每个测试数据点都来自 $\mathcal{U}$ 中的一个标签，并将被分配到该标签。

Existing research on ZSL has been almost entirely focusing on this setting [4, $8,{10} - {28}\rbrack$ . However, in real applications, the assumption of encountering data only from the unseen classes is hardly realistic. The seen classes are often the most common objects we see in the real world. Thus, the objective in the conventional ZSL does not truly reflect how the classifiers will perform recognition in the wild.

现有的关于零样本学习(ZSL)的研究几乎完全集中在这种设置上 [4, $8,{10} - {28}\rbrack$ 。然而，在实际应用中，仅遇到来自未见类别的数据这一假设几乎是不现实的。可见类别通常是我们在现实世界中最常见的对象。因此，传统零样本学习的目标并不能真正反映分类器在实际环境中的识别表现。

Motivated by this shortcoming of the conventional ZSL, we advocate studying the more general setting of generalized zero-shot learning (GZSL), where we no longer limit the possible class memberships of test data - each of them belongs to one of the classes in $\mathcal{T}$ .

受传统零样本学习这一缺点的启发，我们主张研究更通用的广义零样本学习(GZSL)设置，在这种设置中，我们不再限制测试数据可能所属的类别——每个测试数据都属于 $\mathcal{T}$ 中的某一个类别。

### 3.2 Classifiers

### 3.2 分类器

Without the loss of generality, we assume that for each class $c \in  \mathcal{T}$ , we have a discriminant scoring function ${f}_{c}\left( \mathbf{x}\right)$ , from which we would be able to derive the label for $\mathbf{x}$ . For instance, for an unseen class $u$ , the method of synthesized classifiers [28] defines ${f}_{u}\left( \mathbf{x}\right)  = {\mathbf{w}}_{u}^{\mathrm{T}}\mathbf{x}$ , where ${\mathbf{w}}_{u}$ is the model parameter vector for the class $u$ , constructed from its semantic embedding ${\mathbf{a}}_{u}$ (such as its attribute vector or the word vector associated with the name of the class). In ConSE $\left\lbrack  {17}\right\rbrack  ,{f}_{u}\left( \mathbf{x}\right)  = \cos \left( {s\left( \mathbf{x}\right) ,{\mathbf{a}}_{u}}\right)$ , where $s\left( \mathbf{x}\right)$ is the predicted embedding of the data sample $\mathbf{x}$ . In DAP/IAP [38], ${f}_{u}\left( \mathbf{x}\right)$ is a probabilistic model of attribute vectors. We assume that similar discriminant functions for seen classes can be constructed in the same manner given their corresponding semantic embeddings.

不失一般性，我们假设对于每个类别 $c \in  \mathcal{T}$ ，我们有一个判别得分函数 ${f}_{c}\left( \mathbf{x}\right)$ ，通过它我们能够推导出 $\mathbf{x}$ 的标签。例如，对于一个未见类别 $u$ ，合成分类器方法 [28] 定义了 ${f}_{u}\left( \mathbf{x}\right)  = {\mathbf{w}}_{u}^{\mathrm{T}}\mathbf{x}$ ，其中 ${\mathbf{w}}_{u}$ 是类别 $u$ 的模型参数向量，由其语义嵌入 ${\mathbf{a}}_{u}$ (例如其属性向量或与类别名称相关的词向量)构建而成。在 ConSE 中 $\left\lbrack  {17}\right\rbrack  ,{f}_{u}\left( \mathbf{x}\right)  = \cos \left( {s\left( \mathbf{x}\right) ,{\mathbf{a}}_{u}}\right)$ ，其中 $s\left( \mathbf{x}\right)$ 是数据样本 $\mathbf{x}$ 的预测嵌入。在 DAP/IAP [38] 中， ${f}_{u}\left( \mathbf{x}\right)$ 是属性向量的概率模型。我们假设，给定可见类别的相应语义嵌入，也可以以相同的方式构建类似的判别函数。

How to assess an algorithm for GZSL? We define and differentiate the following performance metrics: ${A}_{\mathcal{U} \rightarrow  \mathcal{U}}$ the accuracy of classifying test data from $\mathcal{U}$ into $\mathcal{U},{A}_{\mathcal{S} \rightarrow  \mathcal{S}}$ the accuracy of classifying test data from $\mathcal{S}$ into $\mathcal{S}$ , and finally ${A}_{\mathcal{S} \rightarrow  \mathcal{T}}$ and ${A}_{\mathcal{U} \rightarrow  \mathcal{T}}$ the accuracies of classifying test data from either seen or unseen classes into the joint labeling space. Note that ${A}_{\mathcal{U} \rightarrow  \mathcal{U}}$ is the standard performance metric used for conventional $\mathrm{{ZSL}}$ and ${A}_{\mathcal{S} \rightarrow  \mathcal{S}}$ is the standard metric for multi-class classification. Furthermore, note that we do not report ${A}_{\mathcal{T} \rightarrow  \mathcal{T}}$ as simply averaging ${A}_{\mathcal{S} \rightarrow  \mathcal{T}}$ and ${A}_{\mathcal{U} \rightarrow  \mathcal{S}}$ to compute ${A}_{\mathcal{T} \rightarrow  \mathcal{T}}$ might be misleading when the two metrics are not balanced, as shown below.

如何评估广义零样本学习(GZSL)的算法呢？我们定义并区分以下性能指标: ${A}_{\mathcal{U} \rightarrow  \mathcal{U}}$ 将来自 $\mathcal{U}$ 的测试数据分类到 $\mathcal{U},{A}_{\mathcal{S} \rightarrow  \mathcal{S}}$ 的准确率；将来自 $\mathcal{S}$ 的测试数据分类到 $\mathcal{S}$ 的准确率；最后， ${A}_{\mathcal{S} \rightarrow  \mathcal{T}}$ 和 ${A}_{\mathcal{U} \rightarrow  \mathcal{T}}$ 将来自可见或未见类别的测试数据分类到联合标签空间的准确率。请注意， ${A}_{\mathcal{U} \rightarrow  \mathcal{U}}$ 是传统 $\mathrm{{ZSL}}$ 使用的标准性能指标， ${A}_{\mathcal{S} \rightarrow  \mathcal{S}}$ 是多类别分类的标准指标。此外，请注意我们不报告 ${A}_{\mathcal{T} \rightarrow  \mathcal{T}}$ ，因为简单地对 ${A}_{\mathcal{S} \rightarrow  \mathcal{T}}$ 和 ${A}_{\mathcal{U} \rightarrow  \mathcal{S}}$ 求平均值来计算 ${A}_{\mathcal{T} \rightarrow  \mathcal{T}}$ 可能会产生误导，如下所示。

### 3.3 Generalized ZSL is Hard

### 3.3 广义零样本学习很难

To demonstrate the difficulty of GZSL, we report the empirical results of using a simple but intuitive algorithm for GZSL. Given the discriminant functions, we adopt the following classification rule

为了证明广义零样本学习(GZSL)的难度，我们报告了使用一种简单但直观的广义零样本学习算法的实证结果。给定判别函数，我们采用以下分类规则

$$
\widehat{y} = \arg \mathop{\max }\limits_{{c \in  \mathcal{T}}}{f}_{c}\left( \mathbf{x}\right)  \tag{1}
$$

which we refer to as direct stacking.

我们将其称为直接堆叠。

We use the rule on "stacking" classifiers from the following zero-shot learning approaches: DAP and IAP [38], ConSE [17], and Synthesized Classifiers (SynC) [28]. We tune the hyper-parameters for each approach based on class-wise cross validation [26,28,33]. We test GZSL on two datasets AwA [38] and CUB [39] — details about those datasets can be found in Sect. 5.

我们将该规则应用于以下零样本学习方法的“堆叠”分类器:DAP 和 IAP [38]、ConSE [17] 以及合成分类器(SynC)[28]。我们基于按类别交叉验证 [26,28,33] 为每种方法调整超参数。我们在两个数据集 AwA [38] 和 CUB [39] 上测试广义零样本学习——关于这些数据集的详细信息可以在第 5 节中找到。

Table 1. Classification accuracies (%) on conventional ZSL $\left( {A}_{\mathcal{U} \rightarrow  \mathcal{U}}\right)$ , multi-class classification for seen classes $\left( {A}_{\mathcal{S} \rightarrow  \mathcal{S}}\right)$ , and GZSL $\left( {{A}_{\mathcal{S} \rightarrow  \mathcal{T}}\text{and}{A}_{\mathcal{U} \rightarrow  \mathcal{T}}}\right)$ , on AwA and CUB. Significant drops are observed from ${A}_{\mathcal{U} \rightarrow  \mathcal{U}}$ to ${A}_{\mathcal{U} \rightarrow  \mathcal{T}}$ .

表1. 在AwA和CUB数据集上，传统零样本学习(ZSL)$\left( {A}_{\mathcal{U} \rightarrow  \mathcal{U}}\right)$、已见类别的多类别分类$\left( {A}_{\mathcal{S} \rightarrow  \mathcal{S}}\right)$和广义零样本学习(GZSL)$\left( {{A}_{\mathcal{S} \rightarrow  \mathcal{T}}\text{and}{A}_{\mathcal{U} \rightarrow  \mathcal{T}}}\right)$的分类准确率(%)。从${A}_{\mathcal{U} \rightarrow  \mathcal{U}}$到${A}_{\mathcal{U} \rightarrow  \mathcal{T}}$观察到显著下降。

<table><tr><td rowspan="2">Method</td><td colspan="4">AwA</td><td colspan="4">CUB</td></tr><tr><td>${A}_{U \rightarrow  U}$</td><td>${A}_{\mathcal{S} \rightarrow  \mathcal{S}}$</td><td>${A}_{U \rightarrow  T}$</td><td>${A}_{\mathcal{S} \rightarrow  \mathcal{T}}$</td><td>${Au} \rightarrow  u$</td><td>${A}_{\mathcal{S} \rightarrow  \mathcal{S}}$</td><td>${A}_{\mathcal{U} \rightarrow  \mathcal{T}}$</td><td>${A}_{\mathcal{S} \rightarrow  \mathcal{T}}$</td></tr><tr><td>DAP [38]</td><td>51.1</td><td>78.5</td><td>2.4</td><td>77.9</td><td>38.8</td><td>56.0</td><td>4.0</td><td>55.1</td></tr><tr><td>IAP [38]</td><td>56.3</td><td>77.3</td><td>1.7</td><td>76.8</td><td>36.5</td><td>69.6</td><td>1.0</td><td>69.4</td></tr><tr><td>ConSE [17]</td><td>63.7</td><td>76.9</td><td>9.5</td><td>75.9</td><td>35.8</td><td>70.5</td><td>1.8</td><td>69.9</td></tr><tr><td>SynCo-vs-o [28]</td><td>70.1</td><td>67.3</td><td>0.3</td><td>67.3</td><td>53.0</td><td>67.2</td><td>8.4</td><td>66.5</td></tr><tr><td>SynC ${}^{\text{struct }}\left\lbrack  {28}\right\rbrack$</td><td>73.4</td><td>81.0</td><td>0.4</td><td>81.0</td><td>54.4</td><td>73.0</td><td>13.2</td><td>72.0</td></tr></table>

<table><tbody><tr><td rowspan="2">方法</td><td colspan="4">AwA(动物属性数据集)</td><td colspan="4">CUB(加州大学伯克利分校鸟类数据集)</td></tr><tr><td>${A}_{U \rightarrow  U}$</td><td>${A}_{\mathcal{S} \rightarrow  \mathcal{S}}$</td><td>${A}_{U \rightarrow  T}$</td><td>${A}_{\mathcal{S} \rightarrow  \mathcal{T}}$</td><td>${Au} \rightarrow  u$</td><td>${A}_{\mathcal{S} \rightarrow  \mathcal{S}}$</td><td>${A}_{\mathcal{U} \rightarrow  \mathcal{T}}$</td><td>${A}_{\mathcal{S} \rightarrow  \mathcal{T}}$</td></tr><tr><td>判别式属性预测(DAP) [38]</td><td>51.1</td><td>78.5</td><td>2.4</td><td>77.9</td><td>38.8</td><td>56.0</td><td>4.0</td><td>55.1</td></tr><tr><td>归纳式属性预测(IAP) [38]</td><td>56.3</td><td>77.3</td><td>1.7</td><td>76.8</td><td>36.5</td><td>69.6</td><td>1.0</td><td>69.4</td></tr><tr><td>对比语义嵌入(ConSE) [17]</td><td>63.7</td><td>76.9</td><td>9.5</td><td>75.9</td><td>35.8</td><td>70.5</td><td>1.8</td><td>69.9</td></tr><tr><td>合成对比-视觉-语义优化(SynCo-vs-o) [28]</td><td>70.1</td><td>67.3</td><td>0.3</td><td>67.3</td><td>53.0</td><td>67.2</td><td>8.4</td><td>66.5</td></tr><tr><td>合成对比(SynC) ${}^{\text{struct }}\left\lbrack  {28}\right\rbrack$</td><td>73.4</td><td>81.0</td><td>0.4</td><td>81.0</td><td>54.4</td><td>73.0</td><td>13.2</td><td>72.0</td></tr></tbody></table>

Table 1 reports experimental results based on the 4 performance metrics we have described previously. Our goal here is not to compare between methods. Instead, we examine the impact of relaxing the assumption of the prior knowledge of whether data are from seen or unseen classes.

表1报告了基于我们之前描述的4种性能指标的实验结果。我们这里的目标不是在不同方法之间进行比较。相反，我们研究放宽数据是否来自已知或未知类别的先验知识假设所产生的影响。

We observe that, in this setting of GZSL, the classification performance for unseen classes $\left( {A}_{\mathcal{U} \rightarrow  \mathcal{T}}\right)$ drops significantly from the performance in conventional ZSL $\left( {A}_{\mathcal{U} \rightarrow  \mathcal{U}}\right)$ , while that of seen ones $\left( {A}_{\mathcal{S} \rightarrow  \mathcal{T}}\right)$ remains roughly the same as in the multi-class task $\left( {A}_{\mathcal{S} \rightarrow  \mathcal{S}}\right)$ . That is, nearly all test data from unseen classes are misclassified into the seen classes. This unusual degradation in performance highlights the challenges of GZSL; as we only see labeled data from seen classes during training, the scoring functions of seen classes tend to dominate those of unseen classes, leading to biased predictions in GZSL and aggressively classifying a new data point into the label space of $\mathcal{S}$ because classifiers for the seen classes do not get trained on "negative" examples from the unseen classes.

我们观察到，在广义零样本学习(GZSL)的这种设置下，未知类别的分类性能 $\left( {A}_{\mathcal{U} \rightarrow  \mathcal{T}}\right)$ 相较于传统零样本学习(ZSL) $\left( {A}_{\mathcal{U} \rightarrow  \mathcal{U}}\right)$ 显著下降，而已知类别的分类性能 $\left( {A}_{\mathcal{S} \rightarrow  \mathcal{T}}\right)$ 与多类别任务 $\left( {A}_{\mathcal{S} \rightarrow  \mathcal{S}}\right)$ 大致相同。也就是说，几乎所有来自未知类别的测试数据都被错误分类到已知类别中。这种异常的性能下降凸显了广义零样本学习的挑战；由于我们在训练期间只看到来自已知类别的标记数据，已知类别的评分函数往往会主导未知类别的评分函数，导致广义零样本学习中的预测存在偏差，并将新的数据点激进地分类到 $\mathcal{S}$ 的标签空间中，因为已知类别的分类器没有在来自未知类别的“负”样本上进行训练。

## 4 Approach for GZSL

## 4 广义零样本学习的方法

The previous example shows that the classifiers for unseen classes constructed by conventional ZSL methods should not be naively combined with models for seen classes to expand the labeling space required by GZSL.

前面的例子表明，传统零样本学习方法构建的未知类别分类器不应简单地与已知类别的模型相结合，以扩展广义零样本学习所需的标签空间。

In what follows, we propose a simple variant to the naive approach of direct stacking to curb such a problem. We also develop a metric that measures the performance of GZSL, by acknowledging that there is an inherent trade-off between recognizing seen classes and recognizing unseen classes. This metric, referred to as the Area Under Seen-Unseen accuracy Curve (AUSUC), balances the two conflicting forces. We conclude this section by describing two related approaches: despite their sophistication, they do not perform well empirically.

接下来，我们针对直接堆叠的简单方法提出一种改进方案，以解决此类问题。我们还开发了一种衡量广义零样本学习性能的指标，承认识别已知类别和识别未知类别之间存在内在的权衡。这个指标称为已知 - 未知准确率曲线下面积(AUSUC)，它平衡了这两种相互冲突的因素。在本节结尾，我们将描述两种相关方法:尽管它们很复杂，但在实证中表现不佳。

### 4.1 Calibrated Stacking

### 4.1 校准堆叠

Our approach stems from the observation that the scores of the discriminant functions for the seen classes are often greater than the scores for the unseen classes. Thus, intuitively, we would like to reduce the scores for the seen classes. This leads to the following classification rule:

我们的方法源于这样的观察:已知类别的判别函数得分通常高于未知类别的得分。因此，直观地说，我们希望降低已知类别的得分。这就引出了以下分类规则:

$$
\widehat{y} = \arg \mathop{\max }\limits_{{c \in  \mathcal{T}}}\;{f}_{c}\left( \mathbf{x}\right)  - \gamma \mathbb{I}\left\lbrack  {c \in  \mathcal{S}}\right\rbrack  , \tag{2}
$$

where the indicator $\mathbb{I}\left\lbrack  \cdot \right\rbrack   \in  \{ 0,1\}$ indicates whether or not $c$ is a seen class and $\gamma$ is a calibration factor. We term this adjustable rule as calibrated stacking.

其中指示符 $\mathbb{I}\left\lbrack  \cdot \right\rbrack   \in  \{ 0,1\}$ 表示 $c$ 是否为已知类别，$\gamma$ 是一个校准因子。我们将这个可调整的规则称为校准堆叠。

Another way to interpret $\gamma$ is to regard it as the prior likelihood of a data point coming from unseen classes. When $\gamma  = 0$ , the calibrated stacking rule reverts back to the direct stacking rule, described previously.

另一种解释 $\gamma$ 的方式是将其视为数据点来自未知类别的先验可能性。当 $\gamma  = 0$ 时，校准堆叠规则退化为之前描述的直接堆叠规则。

It is also instructive to consider the two extreme cases of $\gamma$ . When $\gamma  \rightarrow   + \infty$ , the classification rule will ignore all seen classes and classify all data points into one of the unseen classes. When there is no new data point coming from seen classes, this classification rule essentially implements what one would do in the setting of conventional ZSL. On the other hand, when $\gamma  \rightarrow   - \infty$ , the classification rule only considers the label space of seen classes as in standard multi-way classification. The calibrated stacking rule thus represents a middle ground between aggressively classifying every data point into seen classes and conservatively classifying every data point into unseen classes. Adjusting this hyperparameter thus gives a trade-off, which we exploit to define a new performance metric.

考虑 $\gamma$ 的两种极端情况也很有启发性。当 $\gamma  \rightarrow   + \infty$ 时，分类规则将忽略所有已知类别，并将所有数据点分类到某个未知类别中。当没有来自已知类别的新数据点时，这个分类规则本质上实现了传统零样本学习设置下的操作。另一方面，当 $\gamma  \rightarrow   - \infty$ 时，分类规则只考虑已知类别的标签空间，就像标准的多类别分类一样。因此，校准堆叠规则代表了将每个数据点激进地分类到已知类别和保守地分类到未知类别之间的一种折衷。调整这个超参数可以实现一种权衡，我们利用这种权衡来定义一个新的性能指标。

### 4.2 Area Under Seen-Unseen Accuracy Curve (AUSUC)

### 4.2 已知 - 未知准确率曲线下面积(AUSUC)

Varying the calibration factor $\gamma$ , we can compute a series of classification accuracies $\left( {{A}_{\mathcal{U} \rightarrow  \mathcal{T}},{A}_{\mathcal{S} \rightarrow  \mathcal{T}}}\right)$ . Figure 1 plots those points for the dataset $\mathbf{{AwA}}$ using the classifiers generated by the method in [28] based on class-wise cross validation. We call such a plot the Seen-Unseen accuracy Curve (SUC).

改变校准因子 $\gamma$，我们可以计算出一系列的分类准确率 $\left( {{A}_{\mathcal{U} \rightarrow  \mathcal{T}},{A}_{\mathcal{S} \rightarrow  \mathcal{T}}}\right)$。图1绘制了使用文献[28]中的方法基于类别交叉验证生成的分类器对数据集 $\mathbf{{AwA}}$ 的这些点。我们将这样的图称为已知 - 未知准确率曲线(SUC)。

On the curve, $\gamma  = 0$ corresponds to direct stacking, denoted by a cross. The curve is similar to many familiar curves for representing conflicting goals, such as the Precision-Recall (PR) curve and the Receiving Operator Characteristic (ROC) curve, with two ends for the extreme cases $\left( {\gamma  \rightarrow   - \infty \text{and}\gamma  \rightarrow   + \infty }\right)$ .

在曲线上，$\gamma  = 0$ 对应直接堆叠，用十字标记。该曲线类似于许多用于表示冲突目标的常见曲线，如精确率 - 召回率(Precision - Recall，PR)曲线和接收者操作特征(Receiving Operator Characteristic，ROC)曲线，两端对应极端情况 $\left( {\gamma  \rightarrow   - \infty \text{and}\gamma  \rightarrow   + \infty }\right)$。

A convenient way to summarize the plot with one number is to use the Area Under SUC (AUSUC) ${}^{1}$ . The higher the area is, the better an algorithm is able to balance ${A}_{\mathcal{U} \rightarrow  \mathcal{T}}$ and ${A}_{\mathcal{S} \rightarrow  \mathcal{T}}$ . In Sects.5,6, and the Supplementary Material, we evaluate the performance of existing zero-shot learning methods under this metric, as well as provide further insights and analyses.

用一个数值来总结该图的便捷方法是使用堆叠可见 - 不可见准确率曲线下面积(Area Under SUC，AUSUC)${}^{1}$。面积越大，算法在 ${A}_{\mathcal{U} \rightarrow  \mathcal{T}}$ 和 ${A}_{\mathcal{S} \rightarrow  \mathcal{T}}$ 之间的平衡能力就越好。在第 5、6 节以及补充材料中，我们将根据该指标评估现有零样本学习方法的性能，并提供进一步的见解和分析。

---

${}^{1}$ If a single $\gamma$ is desired, the "F-score" that balances ${A}_{\mathcal{U} \rightarrow  \mathcal{T}}$ and ${A}_{\mathcal{S} \rightarrow  \mathcal{T}}$ can be used.

${}^{1}$ 如果需要一个单一的 $\gamma$，可以使用平衡 ${A}_{\mathcal{U} \rightarrow  \mathcal{T}}$ 和 ${A}_{\mathcal{S} \rightarrow  \mathcal{T}}$ 的 “F - 分数”。

---

![0195e089-579b-7aa1-a0d5-e5ab2dcf0628_6_508_174_460_383_0.jpg](images/0195e089-579b-7aa1-a0d5-e5ab2dcf0628_6_508_174_460_383_0.jpg)

Fig. 1. The Seen-Unseen accuracy Curve (SUC) obtained by varying $\gamma$ in the calibrated stacking classification rule Eq. (2). The AUSUC summarizes the curve by computing the area under it. We use the method SynC ${}^{\text{o-vs-o }}$ on the $\mathbf{{AwA}}$ dataset, and tune hyper-parameters as in Table 1. The red cross denotes the accuracies by direct stacking CoW.

图 1. 通过改变校准堆叠分类规则(公式 (2))中的 $\gamma$ 得到的可见 - 不可见准确率曲线(Seen - Unseen accuracy Curve，SUC)。AUSUC 通过计算曲线下的面积来总结该曲线。我们在 $\mathbf{{AwA}}$ 数据集上使用 SynC ${}^{\text{o-vs-o }}$ 方法，并按照表 1 调整超参数。红色十字表示直接堆叠 CoW 的准确率。

An immediate and important use of the metric AUSUC is for model selection. Many ZSL learning methods require tuning hyperparameters - previous work tune them based on the accuracy ${A}_{\mathcal{U} \rightarrow  \mathcal{U}}$ . The selected model, however, does not necessarily balance optimally between ${A}_{\mathcal{U} \rightarrow  \mathcal{T}}$ and ${A}_{\mathcal{S} \rightarrow  \mathcal{T}}$ . Instead, we advocate using AUSUC for model selection and hyperparamter tuning. Models with higher values of AUSUC are likely to perform in balance for the task of GZSL. For detailed discussions, see the Supplementary Material.

指标 AUSUC 的一个直接且重要的用途是用于模型选择。许多零样本学习(Zero - Shot Learning，ZSL)方法需要调整超参数——以往的工作是基于准确率 ${A}_{\mathcal{U} \rightarrow  \mathcal{U}}$ 来调整它们。然而，所选模型不一定能在 ${A}_{\mathcal{U} \rightarrow  \mathcal{T}}$ 和 ${A}_{\mathcal{S} \rightarrow  \mathcal{T}}$ 之间实现最优平衡。相反，我们主张使用 AUSUC 进行模型选择和超参数调整。AUSUC 值越高的模型在广义零样本学习(Generalized Zero - Shot Learning，GZSL)任务中可能表现得更平衡。详细讨论见补充材料。

### 4.3 Alternative Approaches

### 4.3 替代方法

Socher et al. [9] propose a two-stage zero-shot learning approach that first predicts whether an image is of seen or unseen classes and then accordingly applies the corresponding classifiers. The first stage is based on the idea of novelty detection and assigns a high novelty score if it is unlikely for the data point to come from seen classes. They experiment with two novelty detection strategies: Gaussian and LoOP models [40]. We briefly describe and contrast them to our approach below. The details are in the Supplementary Material.

Socher 等人 [9] 提出了一种两阶段零样本学习方法，该方法首先预测图像属于可见类别还是不可见类别，然后相应地应用对应的分类器。第一阶段基于新奇性检测的思想，如果数据点不太可能来自可见类别，则赋予其较高的新奇性得分。他们试验了两种新奇性检测策略:高斯模型和局部离群点概率(Local Outlier Probabilities，LoOP)模型 [40]。我们在下面简要描述这些策略并将其与我们的方法进行对比。详细内容见补充材料。

Novelty Detection. The main idea is to assign a novelty score $N\left( \mathbf{x}\right)$ to each sample $\mathbf{x}$ . With this novelty score, the final prediction rule becomes

新奇性检测。主要思想是为每个样本 $\mathbf{x}$ 分配一个新奇性得分 $N\left( \mathbf{x}\right)$。有了这个新奇性得分，最终的预测规则变为

$$
\widehat{y} = \left\{  \begin{array}{lll} \arg \mathop{\max }\limits_{{c \in  \mathcal{S}}} & {f}_{c}\left( \mathbf{x}\right) , & \text{ if }N\left( \mathbf{x}\right)  \leq   - \gamma . \\  \arg \mathop{\max }\limits_{{c \in  \mathcal{U}}} & {f}_{c}\left( \mathbf{x}\right) , & \text{ if }N\left( \mathbf{x}\right)  >  - \gamma . \end{array}\right.  \tag{3}
$$

where $- \gamma$ is the novelty threshold. The scores above this threshold indicate belonging to unseen classes. To estimate $N\left( \mathbf{x}\right)$ , for the Gaussian model, data points in seen classes are first modeled with a Gaussian mixture model. The novelty score of a data point is then its negative log probability value under this mixture model. Alternatively, the novelty score can be estimated using the Local Outlier Probabilities (LoOP) model [40]. The idea there is to compute the distances of $\mathbf{x}$ to its nearest seen classes. Such distances are then converted to an outlier probability, interpreted as the likelihood of $\mathbf{x}$ being from unseen classes.

其中 $- \gamma$ 是新奇性阈值。高于该阈值的得分表示属于不可见类别。为了估计 $N\left( \mathbf{x}\right)$，对于高斯模型，首先用高斯混合模型对可见类别中的数据点进行建模。然后，数据点的新奇性得分就是其在该混合模型下的负对数概率值。或者，可以使用局部离群点概率(Local Outlier Probabilities，LoOP)模型 [40] 来估计新奇性得分。其思路是计算 $\mathbf{x}$ 到其最近可见类别的距离。然后将这些距离转换为离群点概率，解释为 $\mathbf{x}$ 来自不可见类别的可能性。

Relation to Calibrated Stacking. If we define a new form of novelty score $N\left( \mathbf{x}\right)  = \mathop{\max }\limits_{{u \in  \mathcal{U}}}{f}_{u}\left( \mathbf{x}\right)  - \mathop{\max }\limits_{{s \in  \mathcal{S}}}{f}_{s}\left( \mathbf{x}\right)$ in Eq. (3), we recover the prediction rule in Eq. (2). However, this relation holds only if we are interested in predicting one label $\widehat{y}$ . When we are interested in predicting a set of labels (for example, hoping that the correct labels are in the top $K$ predicted labels,(i.e., the Flat hit@K metric, cf. Sect. 5), the two prediction rules will give different results.

与校准堆叠的关系。如果我们在式(3)中定义一种新形式的新奇性得分 $N\left( \mathbf{x}\right)  = \mathop{\max }\limits_{{u \in  \mathcal{U}}}{f}_{u}\left( \mathbf{x}\right)  - \mathop{\max }\limits_{{s \in  \mathcal{S}}}{f}_{s}\left( \mathbf{x}\right)$，我们就能得到式(2)中的预测规则。然而，这种关系仅在我们对预测一个标签 $\widehat{y}$ 感兴趣时成立。当我们对预测一组标签感兴趣时(例如，希望正确标签位于前 $K$ 个预测标签中，即平面命中率@K指标，参见第5节)，这两种预测规则将给出不同的结果。

## 5 Experimental Results

## 5 实验结果

### 5.1 Setup

### 5.1 实验设置

Datasets. We mainly use three benchmark datasets: the Animals with Attributes (AwA) [38], CUB-200-2011 Birds (CUB) [39], and ImageNet (with full 21,841 classes) [41]. Table 2 summarizes their key characteristics.

数据集。我们主要使用三个基准数据集:动物属性数据集(Animals with Attributes，AwA)[38]、CUB - 200 - 2011鸟类数据集(CUB)[39]和ImageNet数据集(包含完整的21,841个类别)[41]。表2总结了它们的关键特征。

Table 2. Key characteristics of the studied datasets.

表2. 所研究数据集的关键特征。

<table><tr><td>Dataset name</td><td>Number of seen classes</td><td>Number of unseen classes</td><td>Total number of images</td></tr><tr><td>${\mathrm{{AwA}}}^{ \dagger  }$</td><td>40</td><td>10</td><td>30,475</td></tr><tr><td>${\mathrm{{CUB}}}^{ \ddagger  }$</td><td>150</td><td>50</td><td>11,788</td></tr><tr><td>ImageNet ${}^{§}$</td><td>1000</td><td>20,842</td><td>14, 197, 122</td></tr></table>

<table><tbody><tr><td>数据集名称</td><td>已知类别的数量</td><td>未知类别的数量</td><td>图像总数</td></tr><tr><td>${\mathrm{{AwA}}}^{ \dagger  }$</td><td>40</td><td>10</td><td>30,475</td></tr><tr><td>${\mathrm{{CUB}}}^{ \ddagger  }$</td><td>150</td><td>50</td><td>11,788</td></tr><tr><td> ImageNet(图像网)${}^{§}$</td><td>1000</td><td>20,842</td><td>14, 197, 122</td></tr></tbody></table>

${}^{ \dagger  }$ : following the split in [38].

${}^{ \dagger  }$ : 按照文献[38]中的划分方式。

${}^{ \ddagger  }$ : following [28] to report the average over 4 random splits.

${}^{ \ddagger  }$ : 按照文献[28]的方法，报告4次随机划分的平均值。

${}^{§}$ : seen and unseen classes from ImageNet ILSVRC ${20121}\mathrm{\;K}\left\lbrack  {41}\right\rbrack$ and Fall 2011 release [29], respectively.

${}^{§}$ : 分别来自ImageNet ILSVRC ${20121}\mathrm{\;K}\left\lbrack  {41}\right\rbrack$ 和2011年秋季版本[29]的已见和未见类别。

Semantic Spaces. For the classes in AwA and CUB, we use 85-dimensional and 312-dimensional binary or continuous-valued attributes, respectively [38,39]. For ImageNet, we use 500-dimensional word vectors (WORD2VEC) trained by the skip-gram model $\left\lbrack  {7,{42}}\right\rbrack$ provided by Changpinyo et al. $\left\lbrack  {28}\right\rbrack$ . We ignore classes without word vectors, resulting in 20,345 (out of 20,842) unseen classes. We follow [28] to normalize all but binary embeddings to have unit ${\ell }_{2}$ norms.

语义空间。对于AwA和CUB数据集中的类别，我们分别使用85维和312维的二进制或连续值属性[38,39]。对于ImageNet数据集，我们使用由Changpinyo等人$\left\lbrack  {28}\right\rbrack$提供的通过跳字模型(skip-gram model)$\left\lbrack  {7,{42}}\right\rbrack$训练得到的500维词向量(WORD2VEC)。我们忽略没有词向量的类别，最终得到20345个(原本有20842个)未见类别。我们按照文献[28]的方法，对除二进制嵌入之外的所有嵌入进行归一化处理，使其具有单位${\ell }_{2}$范数。

Visual Features. We use the GoogLeNet deep features [43] pre-trained on ILSVRC 2012 1K [41] for all datasets (all extracted with the Caffe package [44]). Extracted features come from the 1,024-dimensional activations of the pooling units, as in [20,28].

视觉特征。对于所有数据集，我们使用在ILSVRC 2012 1K数据集[41]上预训练的GoogLeNet深度特征[43](所有特征均使用Caffe工具包[44]提取)。提取的特征来自池化单元的1024维激活值，与文献[20,28]中的方法相同。

Zero-Shot Learning Methods. We examine several representative conventional zero-shot learning approaches, described briefly below. Direct Attribute Prediction (DAP) and Indirect Attribute Prediction (IAP) [38] are probabilistic models that perform attribute predictions as an intermediate step and then use them to compute MAP predictions of unseen class labels. ConSE [17] makes use of pre-trained classifiers for seen classes and their probabilitic outputs to infer the semantic embeddings of each test example, and then classifies it into the unseen class with the most similar semantic embedding. SynC [28] is a recently proposed multi-task learning approach that synthesizes a novel classifier based on semantic embeddings and base classifiers that are learned with labeled data from the seen classes. Two versions of this approach - SynCo-v-o and SynC ${}^{\text{struct }}$ - use one-versus-other and Crammer-Singer style [45] loss functions to train classifiers. We use binary attributes for DAP and IAP, and continuous attributes and WORD2VEC for ConSE and SynC, following [17,28,38].

零样本学习方法。我们研究了几种具有代表性的传统零样本学习方法，简要介绍如下。直接属性预测(Direct Attribute Prediction，DAP)和间接属性预测(Indirect Attribute Prediction，IAP)[38]是概率模型，它们将属性预测作为中间步骤，然后利用这些属性预测结果来计算未见类别标签的最大后验(MAP)预测。ConSE [17]利用已见类别的预训练分类器及其概率输出，推断每个测试样本的语义嵌入，然后将其分类到语义嵌入最相似的未见类别中。SynC [28]是最近提出的一种多任务学习方法，它基于语义嵌入和从已见类别有标签数据中学习到的基分类器，合成一个新的分类器。该方法有两个版本——SynCo-v-o和SynC ${}^{\text{struct }}$，分别使用一对多(one-versus-other)和Crammer-Singer风格[45]的损失函数来训练分类器。按照文献[17,28,38]的方法，我们对DAP和IAP使用二进制属性，对ConSE和SynC使用连续属性和WORD2VEC。

Generalized Zero-Shot Learning Tasks. There are no previously established benchmark tasks for GZSL. We thus define a set of tasks that reflects more closely how data are distributed in real-world applications.

广义零样本学习任务。此前尚未有针对广义零样本学习(GZSL)的既定基准任务。因此，我们定义了一组任务，这些任务更能反映现实应用中数据的分布情况。

We construct the GZSL tasks by composing test data as a combination of images from both seen and unseen classes. We follow existing splits of the datasets for the conventional ZSL to separate seen and unseen classes. Moreover, for the datasets $\mathbf{{AwA}}$ and $\mathbf{{CUB}}$ , we hold out ${20}\%$ of the data points from the seen classes (previously, all of them are used for training in the conventional zero-shot setting) and merge them with the data from the unseen classes to form the test set; for ImageNet, we combine its validation set (having the same classes as its training set) and the ${21}\mathrm{\;K}$ classes that are not in the ILSVRC 2012 1 K dataset.

我们通过将已见和未见类别的图像组合成测试数据，构建了广义零样本学习任务。我们遵循传统零样本学习(ZSL)中数据集的现有划分方式，来分离已见和未见类别。此外，对于数据集$\mathbf{{AwA}}$和$\mathbf{{CUB}}$，我们从已见类别中留出${20}\%$的数据点(在传统零样本学习设置中，这些数据点之前全部用于训练)，并将它们与未见类别的数据合并，形成测试集；对于ImageNet数据集，我们将其验证集(与训练集具有相同的类别)和不在ILSVRC 2012 1K数据集中的${21}\mathrm{\;K}$个类别组合在一起。

Evaluation Metrics. While we will primarily report the performance of ZSL approaches under the metric Area Under Seen-Unseen accuracy Curve (AUSUC) developed in Sect. 4.1, we explain how its two accuracy components ${A}_{\mathcal{S} \rightarrow  \mathcal{T}}$ and ${A}_{\mathcal{U} \rightarrow  \mathcal{T}}$ are computed below.

评估指标。虽然我们将主要报告在第4.1节中提出的已见 - 未见准确率曲线下面积(Area Under Seen-Unseen accuracy Curve，AUSUC)指标下零样本学习方法的性能，但我们将在下面解释其两个准确率分量${A}_{\mathcal{S} \rightarrow  \mathcal{T}}$和${A}_{\mathcal{U} \rightarrow  \mathcal{T}}$是如何计算的。

For $\mathbf{{AwA}}$ and $\mathbf{{CUB}}$ , seen and unseen accuracies correspond to (normalized-by-class-size) multi-way classification accuracy, where the seen accuracy is computed on the ${20}\%$ images from the seen classes and the unseen accuracy is computed on images from unseen classes.

对于$\mathbf{{AwA}}$和$\mathbf{{CUB}}$，已见和未见准确率对应于(按类别大小归一化的)多分类准确率，其中已见准确率是在来自已见类别的${20}\%$张图像上计算的，未见准确率是在来自未见类别的图像上计算的。

For ImageNet, seen and unseen accuracies correspond to Flat hit@K (F@K), defined as the percentage of test images for which the model returns the true label in its top $\mathrm{K}$ predictions. Note that, $\mathrm{F}@1$ is the unnormalized multi-way classification accuracy. Moreover, following the procedure in $\left\lbrack  {8,{17},{28}}\right\rbrack$ , we evaluate on three scenarios of increasing difficulty: (1) 2-hop contains 1,509 unseen classes that are within two tree hops of the $1\mathrm{\;K}$ seen classes according to the Ima-geNet label hierarchy ${}^{2}$ . (2) 3-hop contains 7,678 unseen classes that are within three tree hops of the seen classes. (3) All contains all 20,345 unseen classes.

对于ImageNet(图像网)数据集，已见和未见类别的准确率对应于扁平前K准确率(Flat hit@K，F@K)，其定义为模型在前 $\mathrm{K}$ 个预测中返回测试图像真实标签的测试图像所占的百分比。请注意， $\mathrm{F}@1$ 是未归一化的多分类准确率。此外，按照 $\left\lbrack  {8,{17},{28}}\right\rbrack$ 中的流程，我们在三种难度逐渐增加的场景下进行评估:(1)2跳(2-hop)场景包含1509个未见类别，根据ImageNet标签层次结构 ${}^{2}$ ，这些类别与 $1\mathrm{\;K}$ 个已见类别在树结构上的距离不超过两跳。(2)3跳(3-hop)场景包含7678个未见类别，这些类别与已见类别在树结构上的距离不超过三跳。(3)全量(All)场景包含所有20345个未见类别。

### 5.2 Which Method to Use to Perform GZSL?

### 5.2 应使用哪种方法进行广义零样本学习(GZSL)？

Table 3 provides an experimental comparison between several methods utilizing seen and unseen classifiers for generalized ZSL, with hyperparameters cross-validated to maximize AUSUC. Empirical results on additional datasets and ZSL methods are in the Supplementary Material.

表3对几种利用已见和未见类别分类器进行广义零样本学习(ZSL)的方法进行了实验比较，通过交叉验证调整超参数以最大化AUSUC(平均未见和已见类别准确率)。其他数据集和零样本学习方法的实证结果见补充材料。

---

${}^{2}$ http://www.image-net.org/api/xml/structure_released.xml.

${}^{2}$ http://www.image-net.org/api/xml/structure_released.xml.

---

Table 3. Performances measured in AUSUC of several methods for Generalized Zero-Shot Learning on $\mathbf{{AwA}}$ and $\mathbf{{CUB}}$ . The higher the better (the upper bound is 1).

表3. 几种广义零样本学习方法在 $\mathbf{{AwA}}$ 和 $\mathbf{{CUB}}$ 数据集上的AUSUC(平均未见和已见类别准确率)指标表现。该指标越高越好(上限为1)。

<table><tr><td rowspan="3">Method</td><td colspan="3">AwA</td><td colspan="3">CUB</td></tr><tr><td colspan="2">Novelty detection [9]</td><td rowspan="2">Calibrated stacking</td><td colspan="2">Novelty detection [9]</td><td rowspan="2">Calibrated stacking</td></tr><tr><td>Gaussian</td><td>LoOP</td><td>Gaussian</td><td>LoOP</td></tr><tr><td>DAP</td><td>0.302</td><td>0.272</td><td>0.366</td><td>0.122</td><td>0.137</td><td>0.194</td></tr><tr><td>IAP</td><td>0.307</td><td>0.287</td><td>0.394</td><td>0.129</td><td>0.145</td><td>0.199</td></tr><tr><td>ConSE</td><td>0.342</td><td>0.300</td><td>0.428</td><td>0.130</td><td>0.136</td><td>0.212</td></tr><tr><td>SynC ${}^{\mathrm{O} - \mathrm{{VS}} - \mathrm{O}}$</td><td>0.420</td><td>0.378</td><td>0.568</td><td>0.191</td><td>0.209</td><td>0.336</td></tr><tr><td>SynCstruct</td><td>0.424</td><td>0.373</td><td>0.583</td><td>0.199</td><td>0.224</td><td>0.356</td></tr></table>

<table><tbody><tr><td rowspan="3">方法</td><td colspan="3">AwA(原词未变，可能是特定名称)</td><td colspan="3">CUB(原词未变，可能是特定名称)</td></tr><tr><td colspan="2">新奇性检测 [9]</td><td rowspan="2">校准堆叠</td><td colspan="2">新奇性检测 [9]</td><td rowspan="2">校准堆叠</td></tr><tr><td>高斯(Gaussian)</td><td>LoOP(原词未变，可能是特定名称)</td><td>高斯(Gaussian)</td><td>LoOP(原词未变，可能是特定名称)</td></tr><tr><td>DAP(原词未变，可能是特定名称)</td><td>0.302</td><td>0.272</td><td>0.366</td><td>0.122</td><td>0.137</td><td>0.194</td></tr><tr><td>IAP(原词未变，可能是特定名称)</td><td>0.307</td><td>0.287</td><td>0.394</td><td>0.129</td><td>0.145</td><td>0.199</td></tr><tr><td>ConSE(原词未变，可能是特定名称)</td><td>0.342</td><td>0.300</td><td>0.428</td><td>0.130</td><td>0.136</td><td>0.212</td></tr><tr><td>SynC ${}^{\mathrm{O} - \mathrm{{VS}} - \mathrm{O}}$</td><td>0.420</td><td>0.378</td><td>0.568</td><td>0.191</td><td>0.209</td><td>0.336</td></tr><tr><td>SynCstruct(原词未变，可能是特定名称)</td><td>0.424</td><td>0.373</td><td>0.583</td><td>0.199</td><td>0.224</td><td>0.356</td></tr></tbody></table>

The results show that, irrespective of which ZSL methods are used to generate models for seen and unseen classes, our method of calibrated stacking for generalized ZSL outperforms other methods. In particular, despite their probabilistic justification, the two novelty detection methods do not perform well. We believe that this is because most existing zero-shot learning methods are discriminative and optimized to take full advantage of class labels and semantic information. In contrast, either Gaussian or LoOP approach models all the seen classes as a whole, possibly at the cost of modeling inter-class differences.

结果表明，无论使用哪种零样本学习(ZSL)方法为已见和未见类别生成模型，我们用于广义零样本学习(GZSL)的校准堆叠方法都优于其他方法。特别是，尽管两种新颖性检测方法有其概率上的合理性，但表现并不理想。我们认为这是因为大多数现有的零样本学习方法具有判别性，并经过优化以充分利用类别标签和语义信息。相比之下，高斯(Gaussian)或局部离群点概率(LoOP)方法将所有已见类别作为一个整体进行建模，这可能是以牺牲对类间差异的建模为代价的。

### 5.3 Which Zero-Shot Learning Approach is More Robust to GZSL?

### 5.3 哪种零样本学习方法对广义零样本学习更具鲁棒性？

Figure 2 contrasts in detail several ZSL approaches when tested on the task of GZSL, using the method of calibrated stacking. Clearly, the SynC method dominates all other methods in the whole ranges. The crosses on the plots mark the results of direct stacking (Sect. 3).

图2详细对比了几种零样本学习方法在广义零样本学习任务上的测试结果，采用的是校准堆叠方法。显然，合成类别(SynC)方法在整个范围内都优于其他所有方法。图中的十字标记了直接堆叠方法的结果(第3节)。

![0195e089-579b-7aa1-a0d5-e5ab2dcf0628_9_240_1507_1099_443_0.jpg](images/0195e089-579b-7aa1-a0d5-e5ab2dcf0628_9_240_1507_1099_443_0.jpg)

Fig. 2. Comparison between several ZSL approaches on the task of GZSL for AwA and CUB.

图2. 几种零样本学习方法在动物属性数据集(AwA)和加州大学伯克利分校鸟类数据集(CUB)的广义零样本学习任务上的比较。

![0195e089-579b-7aa1-a0d5-e5ab2dcf0628_10_274_171_932_741_0.jpg](images/0195e089-579b-7aa1-a0d5-e5ab2dcf0628_10_274_171_932_741_0.jpg)

Fig. 3. Comparison between ConSE and SynC of their performances on the task of GZSL for ImageNet where the unseen classes are within 2 tree-hops from seen classes.

图3. 基于知识图谱的语义嵌入(ConSE)方法和合成类别(SynC)方法在ImageNet数据集的广义零样本学习任务上的性能比较，其中未见类别与已见类别在树结构上的距离不超过2跳。

Figure 3 contrasts in detail ConSE to SynC, the two known methods for large-scale ZSL. When the accuracies measured in Flat hit@1 (i.e., multi-class classification accuracy), neither method dominates the other, suggesting the different trade-offs by the two methods. However, when we measure hit rates in the top $K > 1$ , SynC dominates ConSE. Table 4 gives summarized comparison in AUSUC between the two methods on the ImageNet dataset. We observe that SynC in general outperforms ConSE except when Flat hit@1 is used, in which case the two methods' performances are nearly indistinguishable. Additional plots can be found in the Supplementary Material.

图3详细对比了基于知识图谱的语义嵌入(ConSE)方法和合成类别(SynC)方法，这是两种已知的大规模零样本学习方法。当以扁平前1准确率(即多类别分类准确率)来衡量时，两种方法互有优劣，这表明两种方法进行了不同的权衡。然而，当我们衡量前 $K > 1$ 准确率时，合成类别(SynC)方法优于基于知识图谱的语义嵌入(ConSE)方法。表4总结了这两种方法在ImageNet数据集上的平均无监督语义一致性(AUSUC)比较结果。我们发现，除了使用扁平前1准确率时，合成类别(SynC)方法总体上优于基于知识图谱的语义嵌入(ConSE)方法，在这种情况下，两种方法的性能几乎没有区别。更多图表可在补充材料中找到。

Table 4. Performances measured in AUSUC by different zero-shot learning approaches on GZSL on ImageNet, using our method of calibrated stacking.

表4. 使用我们的校准堆叠方法，不同零样本学习方法在ImageNet数据集的广义零样本学习任务上以平均无监督语义一致性(AUSUC)衡量的性能。

<table><tr><td rowspan="2">Unseen classes</td><td rowspan="2">Method</td><td colspan="4">Flat hit@K</td></tr><tr><td>1</td><td>5</td><td>10</td><td>20</td></tr><tr><td rowspan="3">2-hop</td><td>ConSE</td><td>0.042</td><td>0.168</td><td>0.247</td><td>0.347</td></tr><tr><td>SynC ${}^{\mathrm{O} - \mathrm{{vs}} - \mathrm{O}}$</td><td>0.044</td><td>0.218</td><td>0.338</td><td>0.466</td></tr><tr><td>SynCstruct</td><td>0.043</td><td>0.199</td><td>0.308</td><td>0.433</td></tr><tr><td rowspan="3">3-hop</td><td>ConSE</td><td>0.013</td><td>0.057</td><td>0.090</td><td>0.135</td></tr><tr><td>SynC ${}^{\mathrm{O} - \mathrm{{VS}} - \mathrm{O}}$</td><td>0.012</td><td>0.070</td><td>0.119</td><td>0.186</td></tr><tr><td>SynCstruct</td><td>0.013</td><td>0.066</td><td>0.110</td><td>0.170</td></tr><tr><td rowspan="3">${All}$</td><td>ConSE</td><td>0.007</td><td>0.030</td><td>0.048</td><td>0.073</td></tr><tr><td>SynCo-vs-o</td><td>0.006</td><td>0.034</td><td>0.059</td><td>0.097</td></tr><tr><td>SynCstruct</td><td>0.007</td><td>0.033</td><td>0.056</td><td>0.090</td></tr></table>

<table><tbody><tr><td rowspan="2">未见过的类别</td><td rowspan="2">方法</td><td colspan="4">平面K命中率</td></tr><tr><td>1</td><td>5</td><td>10</td><td>20</td></tr><tr><td rowspan="3">2跳</td><td>ConSE(原文未明确含义，保留英文)</td><td>0.042</td><td>0.168</td><td>0.247</td><td>0.347</td></tr><tr><td>同步(SynC) ${}^{\mathrm{O} - \mathrm{{vs}} - \mathrm{O}}$</td><td>0.044</td><td>0.218</td><td>0.338</td><td>0.466</td></tr><tr><td>同步结构(SynCstruct)</td><td>0.043</td><td>0.199</td><td>0.308</td><td>0.433</td></tr><tr><td rowspan="3">3跳</td><td>ConSE(原文未明确含义，保留英文)</td><td>0.013</td><td>0.057</td><td>0.090</td><td>0.135</td></tr><tr><td>同步(SynC) ${}^{\mathrm{O} - \mathrm{{VS}} - \mathrm{O}}$</td><td>0.012</td><td>0.070</td><td>0.119</td><td>0.186</td></tr><tr><td>同步结构(SynCstruct)</td><td>0.013</td><td>0.066</td><td>0.110</td><td>0.170</td></tr><tr><td rowspan="3">${All}$</td><td>ConSE(原文未明确含义，保留英文)</td><td>0.007</td><td>0.030</td><td>0.048</td><td>0.073</td></tr><tr><td>同步对象对对象(SynCo - vs - o)</td><td>0.006</td><td>0.034</td><td>0.059</td><td>0.097</td></tr><tr><td>同步结构(SynCstruct)</td><td>0.007</td><td>0.033</td><td>0.056</td><td>0.090</td></tr></tbody></table>

## 6 Analysis on (Generalized) Zero-Shot Learning

## 6 (广义)零样本学习分析

Zero-shot learning, either in conventional setting or generalized setting, is a challenging problem as there is no labeled data for the unseen classes. The performance of ZSL methods depends on at least two factors: (1) how seen and unseen classes are related; (2) how effectively the relation can be exploited by learning algorithms to generate models for the unseen classes. For generalized zero-shot learning, the performance further depends on how classifiers for seen and unseen classes are combined to classify new data into the joint label space.

零样本学习，无论是在传统设置还是广义设置中，都是一个具有挑战性的问题，因为对于未见类别没有标注数据。零样本学习(ZSL)方法的性能至少取决于两个因素:(1)已见类别和未见类别之间的关联方式；(2)学习算法能够多有效地利用这种关联为未见类别生成模型。对于广义零样本学习，其性能还进一步取决于如何将已见类别和未见类别的分类器组合起来，以便将新数据分类到联合标签空间中。

Despite extensive study in ZSL, several questions remain understudied. For example, given a dataset and a split of seen and unseen classes, what is the best possible performance of any ZSL method? How far are we from there? What is the most crucial component we can improve in order to reduce the gap between the state-of-the-art and the ideal performances?

尽管在零样本学习领域已经进行了广泛的研究，但仍有几个问题尚未得到充分探讨。例如，给定一个数据集以及已见类别和未见类别的划分，任何零样本学习方法的最佳可能性能是什么？我们距离这个最佳性能还有多远？为了缩小当前最优性能和理想性能之间的差距，我们可以改进的最关键组件是什么？

In this section, we empirically analyze ZSL methods in detail and shed light on some of those questions.

在本节中，我们将对零样本学习方法进行详细的实证分析，并为上述部分问题提供一些见解。

Setup. As ZSL methods do not use labeled data from unseen classes for training classifiers, one reasonable estimate of their best possible performance is to measure the performance on a multi-class classification task where annotated data on the unseen classes are provided.

设置。由于零样本学习方法在训练分类器时不使用未见类别的标注数据，因此对其最佳可能性能的一个合理估计是在一个多类别分类任务中测量其性能，在该任务中提供了未见类别的标注数据。

Concretely, to construct the multi-class classification task, on AwA and CUB, we randomly select ${80}\%$ of the data along with their labels from all classes (seen and unseen) to train classifiers. The remaining ${20}\%$ will be used to assess both the multi-class classifiers and the classifiers from ZSL. Note that, for ZSL, only the seen classes from the ${80}\%$ are used for training - the portion belonging to the unseen classes are not used.

具体而言，为了构建多类别分类任务，在动物属性数据集(AwA)和加州大学伯克利分校鸟类数据集(CUB)上，我们从所有类别(已见和未见)中随机选择 ${80}\%$ 的数据及其标签来训练分类器。剩余的 ${20}\%$ 将用于评估多类别分类器和零样本学习的分类器。请注意，对于零样本学习，仅使用 ${80}\%$ 中的已见类别进行训练——属于未见类别的部分不使用。

On ImageNet, to reduce the computational cost (of constructing multi-class classifiers which would involve 20,345-way classification), we subsample another 1,000 unseen classes from its original 20,345 unseen classes. We call this new dataset ImageNet-2K (including the $1\mathrm{\;K}$ seen classes from ImageNet). The subsampling procedure is described in the Supplementary Material and the main goal is to keep the proportions of difficult unseen classes unchanged. Out of those 1,000 unseen classes, we randomly select 50 samples per class and reserve them for testing and use the remaining examples (along with their labels) to train 2000-way classifiers.

在 ImageNet 数据集上，为了降低计算成本(构建涉及 20345 类分类的多类别分类器)，我们从其原始的 20345 个未见类别中二次采样另外 1000 个未见类别。我们将这个新数据集称为 ImageNet - 2K(包括来自 ImageNet 的 $1\mathrm{\;K}$ 个已见类别)。二次采样过程在补充材料中进行了描述，主要目标是保持困难未见类别的比例不变。在这 1000 个未见类别中，我们为每个类别随机选择 50 个样本并保留用于测试，使用其余示例(及其标签)来训练 2000 类分类器。

For ZSL methods, we use either attribute vectors or word vectors (WORD2VEC) as semantic embeddings. Since SynCo-vs-o [28] performs well on a range of datasets and settings, we focus on this method. For multi-class classification, we train one-versus-others SVMs. Once we obtain the classifiers for both seen and unseen classes, we use the calibrated stacking decision rule to combine (as in generalized ZSL) and vary the calibration factor $\gamma$ to obtain the Seen-Unseen accuracy Curve, exemplified in Fig. 1.

对于零样本学习方法，我们使用属性向量或词向量(WORD2VEC)作为语义嵌入。由于 SynCo - vs - o [28] 在一系列数据集和设置中表现良好，我们将重点放在这种方法上。对于多类别分类，我们训练一对多支持向量机(SVM)。一旦我们获得了已见类别和未见类别的分类器，我们使用校准堆叠决策规则进行组合(如在广义零样本学习中)，并改变校准因子 $\gamma$ 以获得已见 - 未见准确率曲线，如图 1 所示。

![0195e089-579b-7aa1-a0d5-e5ab2dcf0628_12_220_171_1039_423_0.jpg](images/0195e089-579b-7aa1-a0d5-e5ab2dcf0628_12_220_171_1039_423_0.jpg)

Fig. 4. We contrast the performances of GZSL to multi-class classifiers trained with labeled data from both seen and unseen classes on the dataset ImageNet-2K. GZSL uses WORD2VECTOR (in red color) and the idealized visual features (G-attr) as semantic embeddings (in black color). (Color figure online)

图 4. 我们对比了广义零样本学习(GZSL)与在 ImageNet - 2K 数据集上使用已见和未见类别的标注数据训练的多类别分类器的性能。广义零样本学习使用词向量(WORD2VECTOR，红色)和理想化视觉特征(G - attr，黑色)作为语义嵌入。(彩色图在线)

How Far Are We From the Ideal Performance? Figure 4 displays the Seen-Unseen accuracy Curves for ImageNet-2K - additional plots on ImageNet-2K and similar ones on AwA and CUB are in the Supplementary Material. Clearly, there is a large gap between the performances of GZSL using the default WORD2VEC semantic embeddings and the ideal performance indicated by the multi-class classifiers. Note that the cross marks indicate the results of direct stacking. The multi-class classifiers not only dominate GZSL in the whole ranges (thus, with very high AUSUCs) but also are capable of learning classifiers that are well-balanced (such that direct stacking works well).

我们距离理想性能还有多远？图 4 展示了 ImageNet - 2K 的已见 - 未见准确率曲线——ImageNet - 2K 上的其他图以及 AwA 和 CUB 上的类似图在补充材料中。显然，使用默认词向量(WORD2VEC)语义嵌入的广义零样本学习的性能与多类别分类器所指示的理想性能之间存在很大差距。请注意，十字标记表示直接堆叠的结果。多类别分类器不仅在整个范围内优于广义零样本学习(因此，具有非常高的曲线下面积(AUSUC))，而且能够学习到平衡良好的分类器(使得直接堆叠效果良好)。

How Much Can Idealized Semantic Embeddings Help? We hypothesize that a large portion of the gap between GZSL and multi-class classification can be attributed to the weak semantic embeddings used by the GZSL approach.

理想化语义嵌入能有多大帮助？我们假设广义零样本学习和多类别分类之间的差距很大一部分可归因于广义零样本学习方法所使用的语义嵌入较弱。

We investigate this by using a form of idealized semantic embeddings. As the success of zero-shot learning relies heavily on how accurate semantic embeddings represent visual similarity among classes, we examine the idea of visual features as semantic embeddings. Concretely, for each class, semantic embeddings can be obtained by averaging visual features of images belonging to that class. We call them $\mathbf{G}$ -attr as we derive the visual features from GoogLeNet. Note that, for unseen classes, we only use the reserved training examples to derive the semantic embeddings; we do not use their labels to train classifiers.

我们通过使用一种理想化语义嵌入来研究这个问题。由于零样本学习的成功在很大程度上依赖于语义嵌入对类别之间视觉相似性的准确表示，我们研究了将视觉特征作为语义嵌入的想法。具体而言，对于每个类别，可以通过对属于该类别的图像的视觉特征进行平均来获得语义嵌入。我们将它们称为 $\mathbf{G}$ - attr，因为我们从谷歌网络(GoogLeNet)中提取视觉特征。请注意，对于未见类别，我们仅使用保留的训练示例来推导语义嵌入；我们不使用它们的标签来训练分类器。

Figure 4 shows the performance of GZSL using G-attr - the gaps to the multi-class classification performances are significantly reduced from those made by GZSL using WORD2VEC. In some cases (see the Supplementary Material for more comprehensive experiments), GZSL can almost match the performance of multi-class classifiers without using any labels from the unseen classes!

图4展示了使用G-属性(G-attr)的广义零样本学习(GZSL)的性能——与使用词向量(WORD2VEC)的广义零样本学习相比，其与多类分类性能之间的差距显著缩小。在某些情况下(更多全面实验见补充材料)，广义零样本学习几乎可以在不使用任何未见类别的标签的情况下达到多类分类器的性能！

Table 5. Comparison of performances measured in AUSUC between GZSL (using WORD2VEC and G-attr) and multi-class classification on ImageNet-2K. Few-shot results are averaged over 100 rounds. GZSL with G-attr improves upon GZSL with WORD2VEC significantly and quickly approaches multi-class classification performance.

表5. 在ImageNet - 2K数据集上，广义零样本学习(使用词向量和G-属性)与多类分类在平均无监督样本下的曲线下面积(AUSUC)指标上的性能比较。少样本结果是在100轮实验中取平均值。使用G-属性的广义零样本学习相较于使用词向量的广义零样本学习有显著提升，并且迅速接近多类分类的性能。

<table><tr><td rowspan="2" colspan="2">Method</td><td colspan="4">Flat hit@K</td></tr><tr><td>1</td><td>5</td><td>10</td><td>20</td></tr><tr><td rowspan="5">GZSL</td><td>WORD2VEC</td><td>0.04</td><td>0.17</td><td>0.27</td><td>0.38</td></tr><tr><td>G-attr from 1 image</td><td>${0.08} \pm  {0.003}$</td><td>${0.25} \pm  {0.005}$</td><td>${0.33} \pm  {0.005}$</td><td>${0.42} \pm  {0.005}$</td></tr><tr><td>G-attr from 10 images</td><td>${0.20} \pm  {0.002}$</td><td>${0.50} \pm  {0.002}$</td><td>${0.62} \pm  {0.002}$</td><td>${0.72} \pm  {0.002}$</td></tr><tr><td>G-attr from 100 images</td><td>${0.25} \pm  {0.001}$</td><td>${0.57} \pm  {0.001}$</td><td>${0.69} \pm  {0.001}$</td><td>${0.78} \pm  {0.001}$</td></tr><tr><td>G-attr from all images</td><td>0.25</td><td>0.58</td><td>0.69</td><td>0.79</td></tr><tr><td colspan="2">Multi-class classification</td><td>0.35</td><td>0.66</td><td>0.75</td><td>0.82</td></tr></table>

<table><tbody><tr><td rowspan="2" colspan="2">方法</td><td colspan="4">前K准确率(Flat hit@K)</td></tr><tr><td>1</td><td>5</td><td>10</td><td>20</td></tr><tr><td rowspan="5">广义零样本学习(GZSL)</td><td>词向量模型(WORD2VEC)</td><td>0.04</td><td>0.17</td><td>0.27</td><td>0.38</td></tr><tr><td>从1张图像提取的全局属性(G-attr)</td><td>${0.08} \pm  {0.003}$</td><td>${0.25} \pm  {0.005}$</td><td>${0.33} \pm  {0.005}$</td><td>${0.42} \pm  {0.005}$</td></tr><tr><td>从10张图像提取的全局属性(G-attr)</td><td>${0.20} \pm  {0.002}$</td><td>${0.50} \pm  {0.002}$</td><td>${0.62} \pm  {0.002}$</td><td>${0.72} \pm  {0.002}$</td></tr><tr><td>从100张图像提取的全局属性(G-attr)</td><td>${0.25} \pm  {0.001}$</td><td>${0.57} \pm  {0.001}$</td><td>${0.69} \pm  {0.001}$</td><td>${0.78} \pm  {0.001}$</td></tr><tr><td>从所有图像提取的全局属性(G-attr)</td><td>0.25</td><td>0.58</td><td>0.69</td><td>0.79</td></tr><tr><td colspan="2">多类别分类</td><td>0.35</td><td>0.66</td><td>0.75</td><td>0.82</td></tr></tbody></table>

How Much Labeled Data Do We Need to Improve GZSL's Performance? Imagine we are given a budget to label data from unseen classes, how much those labels can improve GZSL's performance?

我们需要多少标注数据来提升广义零样本学习(GZSL)的性能呢？假设我们有预算来标注来自未见类别的数据，这些标注能在多大程度上提升GZSL的性能呢？

Table 5 contrasts the AUSUCs obtained by GZSL to those from mutli-class classification on ImageNet-2K, where GZSL is allowed to use visual features as embeddings - those features can be computed from a few labeled images from the unseen classes, a scenario we can refer to as "few-shot" learning. Using about (randomly sampled) 100 labeled images per class, GZSL can quickly approach the performance of multi-class classifiers, which use about 1,000 labeled images per class. Moreover, those G-attr visual features as semantic embeddings improve upon WORD2VEC more significantly under Flat hit $@\mathrm{K} = 1$ than when $\mathrm{K} > 1$ .

表5对比了广义零样本学习(GZSL)在ImageNet - 2K上获得的平均未见类别的平均准确率(AUSUC)与多类别分类的结果，其中允许GZSL使用视觉特征作为嵌入——这些特征可以从来自未见类别的少量标注图像中计算得出，我们可以将这种情况称为“少样本”学习。每个类别使用大约(随机采样的)100张标注图像时，GZSL可以迅速接近每个类别使用约1000张标注图像的多类别分类器的性能。此外，在Flat hit $@\mathrm{K} = 1$ 情况下，作为语义嵌入的G - 属性视觉特征比在 $\mathrm{K} > 1$ 情况下更显著地优于WORD2VEC。

We further examine on the whole ImageNet with 20,345 unseen classes in Table 6, where we keep ${80}\%$ of the unseen classes’ examples to derive $\mathbf{G}$ -attr and test on the rest, and observe similar trends. Specifically on Flat hit@1, the performance of G-attr from merely 1 image is boosted threefold of that by WORD2VEC, while G-attr from 100 images achieves over tenfold. See the Supplementary Material for details, including results on $\mathbf{{AwA}}$ and $\mathbf{{CUB}}$ .

我们在表6中进一步在包含20345个未见类别的整个ImageNet数据集上进行了研究，我们保留未见类别示例的 ${80}\%$ 来推导 $\mathbf{G}$ - 属性，并在其余部分上进行测试，观察到了类似的趋势。具体来说，在Flat hit@1指标上，仅使用1张图像得到的G - 属性的性能是WORD2VEC的三倍，而使用100张图像得到的G - 属性的性能则超过了WORD2VEC的十倍。详情见补充材料，包括在 $\mathbf{{AwA}}$ 和 $\mathbf{{CUB}}$ 上的结果。

Table 6. Comparison of performances measured in AUSUC between GZSL with WORD2VEC and GZSL with G-attr on the full ImageNet with 21,000 unseen classes. Few-shot results are averaged over 20 rounds.

表6. 在包含21000个未见类别的完整ImageNet数据集上，使用WORD2VEC的广义零样本学习(GZSL)和使用G - 属性的GZSL在平均未见类别的平均准确率(AUSUC)指标上的性能比较。少样本结果是20轮实验的平均值。

<table><tr><td rowspan="2">Method</td><td colspan="4">Flat hit@K</td></tr><tr><td>1</td><td>5</td><td>10</td><td>20</td></tr><tr><td>WORD2VEC</td><td>0.006</td><td>0.034</td><td>0.059</td><td>0.096</td></tr><tr><td>G-attr from 1 image</td><td>${0.018} \pm  {0.0002}$</td><td>${0.071} \pm  {0.0007}$</td><td>${0.106} \pm  {0.0009}$</td><td>${0.150} \pm  {0.0011}$</td></tr><tr><td>G-attr from 10 images</td><td>${0.050} \pm  {0.0002}$</td><td>${0.184} \pm  {0.0003}$</td><td>${0.263} \pm  {0.0004}$</td><td>${0.352} \pm  {0.0005}$</td></tr><tr><td>G-attr from 100 images</td><td>${0.065} \pm  {0.0001}$</td><td>${0.230} \pm  {0.0002}$</td><td>${0.322} \pm  {0.0002}$</td><td>${0.421} \pm  {0.0002}$</td></tr><tr><td>G-attr from all images</td><td>0.067</td><td>0.236</td><td>0.329</td><td>0.429</td></tr></table>

<table><tbody><tr><td rowspan="2">方法</td><td colspan="4">前K个的扁平命中率(Flat hit@K)</td></tr><tr><td>1</td><td>5</td><td>10</td><td>20</td></tr><tr><td>词向量模型(WORD2VEC)</td><td>0.006</td><td>0.034</td><td>0.059</td><td>0.096</td></tr><tr><td>从1张图像中提取的全局属性(G-attr)</td><td>${0.018} \pm  {0.0002}$</td><td>${0.071} \pm  {0.0007}$</td><td>${0.106} \pm  {0.0009}$</td><td>${0.150} \pm  {0.0011}$</td></tr><tr><td>从10张图像中提取的全局属性(G-attr)</td><td>${0.050} \pm  {0.0002}$</td><td>${0.184} \pm  {0.0003}$</td><td>${0.263} \pm  {0.0004}$</td><td>${0.352} \pm  {0.0005}$</td></tr><tr><td>从100张图像中提取的全局属性(G-attr)</td><td>${0.065} \pm  {0.0001}$</td><td>${0.230} \pm  {0.0002}$</td><td>${0.322} \pm  {0.0002}$</td><td>${0.421} \pm  {0.0002}$</td></tr><tr><td>从所有图像中提取的全局属性(G-attr)</td><td>0.067</td><td>0.236</td><td>0.329</td><td>0.429</td></tr></tbody></table>

## 7 Discussion

## 7 讨论

Zero-shot learning (ZSL) methods have been studied in the unrealistic setting where the test data are assumed to come from unseen classes only. In contrast, we advocate studying the problem of Generalized ZSL where test data's class memberships are unconstrained. Naively using the classifiers constructed by ZSL approaches, however, does not perform well in this generalized setting. Instead, we propose a simple but effective method that can be used to balance two conflicting forces: recognizing data from seen classes versus unseen ones. We develop a performance metric to characterize the tradeoff and examine the utility of this metric in evaluating various ZSL approaches. Our analysis also leads us to investigate the best possible performance of any ZSL methods. We show that there is a large gap between existing approaches and the best possible. Moreover, we show that this gap can be reduced significantly if idealized semantic embeddings are used. Thus, an important direction for future research is to improve the quality of semantic embeddings of seen and unseen classes.

零样本学习(Zero-shot learning，ZSL)方法是在一种不切实际的设定下进行研究的，即假设测试数据仅来自未见类别。相比之下，我们主张研究广义零样本学习(Generalized ZSL)问题，在该问题中，测试数据的类别归属不受限制。然而，简单地使用零样本学习方法构建的分类器，在这种广义设定下表现不佳。相反，我们提出了一种简单而有效的方法，可用于平衡两种相互冲突的力量:识别来自已见类别和未见类别的数据。我们开发了一种性能指标来描述这种权衡，并检验该指标在评估各种零样本学习方法中的效用。我们的分析还促使我们研究任何零样本学习方法的最佳可能性能。我们发现，现有方法与最佳可能性能之间存在很大差距。此外，我们表明，如果使用理想化的语义嵌入，这个差距可以显著缩小。因此，未来研究的一个重要方向是提高已见和未见类别的语义嵌入质量。

Acknowledgements. B.G. is partially supported by NSF IIS-1566511. Others are partially supported by USC Graduate Fellowship, NSF IIS-1065243, 1451412, 1513966, 1208500, CCF-1139148, a Google Research Award, an Alfred. P. Sloan Research Fellowship and ARO# W911NF-12-1-0241 and W911NF-15-1-0484.

致谢。B.G. 部分得到美国国家科学基金会(NSF)IIS - 1566511 项目的支持。其他人员部分得到南加州大学(USC)研究生奖学金、NSF IIS - 1065243、1451412、1513966、1208500、CCF - 1139148 项目、谷歌研究奖、阿尔弗雷德·P·斯隆研究奖学金以及美国陆军研究办公室(ARO)#W911NF - 12 - 1 - 0241 和 W911NF - 15 - 1 - 0484 项目的支持。

## References

## 参考文献

1. Sudderth, E.B., Jordan, M.I.: Shared segmentation of natural scenes using dependent Pitman-Yor processes. In: NIPS (2008)

1. Sudderth, E.B., Jordan, M.I.:使用依赖皮特曼 - 约尔过程(Pitman - Yor processes)对自然场景进行共享分割。见:神经信息处理系统大会(NIPS)(2008 年)

2. Salakhutdinov, R., Torralba, A., Tenenbaum, J.: Learning to share visual appearance for multiclass object detection. In: CVPR (2011)

2. Salakhutdinov, R., Torralba, A., Tenenbaum, J.:学习共享视觉外观以进行多类目标检测。见:计算机视觉与模式识别会议(CVPR)(2011 年)

3. Zhu, X., Anguelov, D., Ramanan, D.: Capturing long-tail distributions of object subcategories. In: CVPR (2014)

3. Zhu, X., Anguelov, D., Ramanan, D.:捕捉目标子类别长尾分布。见:计算机视觉与模式识别会议(CVPR)(2014 年)

4. Lampert, C.H., Nickisch, H., Harmeling, S.: Learning to detect unseen object classes by between-class attribute transfer. In: CVPR (2009)

4. Lampert, C.H., Nickisch, H., Harmeling, S.:通过类间属性转移学习检测未见目标类别。见:计算机视觉与模式识别会议(CVPR)(2009 年)

5. Farhadi, A., Endres, I., Hoiem, D., Forsyth, D.: Describing objects by their attributes. In: CVPR (2009)

5. Farhadi, A., Endres, I., Hoiem, D., Forsyth, D.:通过属性描述目标。见:计算机视觉与模式识别会议(CVPR)(2009 年)

6. Parikh, D., Grauman, K.: Relative attributes. In: ICCV (2011)

6. Parikh, D., Grauman, K.:相对属性。见:国际计算机视觉会议(ICCV)(2011 年)

7. Mikolov, T., Chen, K., Corrado, G.S., Dean, J.: Efficient estimation of word representations in vector space. In: ICLR Workshops (2013)

7. Mikolov, T., Chen, K., Corrado, G.S., Dean, J.:向量空间中词表示的高效估计。见:国际学习表征会议研讨会(ICLR Workshops)(2013 年)

8. Frome, A., Corrado, G.S., Shlens, J., Bengio, S., Dean, J., Ranzato, M., Mikolov, T.: Devise: a deep visual-semantic embedding model. In: NIPS (2013)

8. Frome, A., Corrado, G.S., Shlens, J., Bengio, S., Dean, J., Ranzato, M., Mikolov, T.:Devise:一种深度视觉 - 语义嵌入模型。见:神经信息处理系统大会(NIPS)(2013 年)

9. Socher, R., Ganjoo, M., Manning, C.D., Ng, A.: Zero-shot learning through cross-modal transfer. In: NIPS (2013)

9. Socher, R., Ganjoo, M., Manning, C.D., Ng, A.:通过跨模态转移进行零样本学习。见:神经信息处理系统大会(NIPS)(2013 年)

10. Palatucci, M., Pomerleau, D., Hinton, G.E., Mitchell, T.M.: Zero-shot learning with semantic output codes. In: NIPS (2009)

10. Palatucci, M., Pomerleau, D., Hinton, G.E., Mitchell, T.M.:使用语义输出码进行零样本学习。见:神经信息处理系统大会(NIPS)(2009 年)

11. Yu, X., Aloimonos, Y.: Attribute-based transfer learning for object categorization with zero/one training example. In: Maragos, P., Paragios, N., Daniilidis, K. (eds.) ECCV 2010, Part V. LNCS, vol. 6315, pp. 127-140. Springer, Heidelberg (2010)

11. Yu, X., Aloimonos, Y.:基于属性的转移学习用于零/单训练示例的目标分类。见:Maragos, P., Paragios, N., Daniilidis, K.(编)《2010 年欧洲计算机视觉会议(ECCV 2010)，第五部分》。《计算机科学讲义》(LNCS)，第 6315 卷，第 127 - 140 页。施普林格出版社，海德堡(2010 年)

12. Rohrbach, M., Stark, M., Schiele, B.: Evaluating knowledge transfer and zero-shot learning in a large-scale setting. In: CVPR (2011)

12. Rohrbach, M., Stark, M., Schiele, B.:在大规模设定下评估知识转移和零样本学习。见:计算机视觉与模式识别会议(CVPR)(2011 年)

13. Kankuekul, P., Kawewong, A., Tangruamsub, S., Hasegawa, O.: Online incremental attribute-based zero-shot learning. In: CVPR (2012)

13. 坎库库尔(Kankuekul)，P.；卡韦翁(Kawewong)，A.；唐鲁阿姆苏布(Tangruamsub)，S.；长谷川(Hasegawa)，O.:基于在线增量属性的零样本学习。见:计算机视觉与模式识别会议(CVPR)(2012)

14. Akata, Z., Perronnin, F., Harchaoui, Z., Schmid, C.: Label-embedding for attribute-based classification. In: CVPR (2013)

14. 阿卡塔(Akata)，Z.；佩罗宁(Perronnin)，F.；哈查乌伊(Harchaoui)，Z.；施密德(Schmid)，C.:基于属性分类的标签嵌入。见:计算机视觉与模式识别会议(CVPR)(2013)

15. Yu, F.X., Cao, L., Feris, R.S., Smith, J.R., Chang, S.F.: Designing category-level attributes for discriminative visual recognition. In: CVPR (2013)

15. 余(Yu)，F.X.；曹(Cao)，L.；费里斯(Feris)，R.S.；史密斯(Smith)，J.R.；张(Chang)，S.F.:用于判别式视觉识别的类别级属性设计。见:计算机视觉与模式识别会议(CVPR)(2013)

16. Mensink, T., Gavves, E., Snoek, C.G.: Costa: co-occurrence statistics for zero-shot classification. In: CVPR (2014)

16. 门辛克(Mensink)，T.；加夫维斯(Gavves)，E.；斯诺克(Snoek)，C.G.:科斯塔(Costa):用于零样本分类的共现统计。见:计算机视觉与模式识别会议(CVPR)(2014)

17. Norouzi, M., Mikolov, T., Bengio, S., Singer, Y., Shlens, J., Frome, A., Corrado, G.S., Dean, J.: Zero-shot learning by convex combination of semantic embeddings. In: ICLR (2014)

17. 诺鲁兹(Norouzi)，M.；米科洛夫(Mikolov)，T.；本吉奥(Bengio)，S.；辛格(Singer)，Y.；什伦斯(Shlens)，J.；弗罗姆(Frome)，A.；科拉多(Corrado)，G.S.；迪恩(Dean)，J.:通过语义嵌入的凸组合实现零样本学习。见:国际学习表征会议(ICLR)(2014)

18. Jayaraman, D., Grauman, K.: Zero-shot recognition with unreliable attributes. In: NIPS (2014)

18. 贾亚拉曼(Jayaraman)，D.；格劳曼(Grauman)，K.:使用不可靠属性的零样本识别。见:神经信息处理系统大会(NIPS)(2014)

19. Al-Halah, Z., Stiefelhagen, R.: How to transfer? Zero-shot object recognition via hierarchical transfer of semantic attributes. In: WACV (2015)

19. 哈拉赫(Al - Halah)，Z.；施蒂费尔哈根(Stiefelhagen)，R.:如何进行迁移？通过语义属性的分层迁移实现零样本目标识别。见:冬季计算机视觉应用会议(WACV)(2015)

20. Akata, Z., Reed, S., Walter, D., Lee, H., Schiele, B.: Evaluation of output embed-dings for fine-grained image classification. In: CVPR (2015)

20. 阿卡塔(Akata)，Z.；里德(Reed)，S.；沃尔特(Walter)，D.；李(Lee)，H.；席勒(Schiele)，B.:用于细粒度图像分类的输出嵌入评估。见:计算机视觉与模式识别会议(CVPR)(2015)

21. Fu, Y., Hospedales, T.M., Xiang, T., Gong, S.: Transductive multi-view zero-shot learning. TPAMI 37, 2332-2345 (2015)

21. 傅(Fu)，Y.；霍斯佩代尔斯(Hospedales)，T.M.；向(Xiang)，T.；龚(Gong)，S.:直推式多视图零样本学习。《模式分析与机器智能汇刊》(TPAMI)37，2332 - 2345(2015)

22. Fu, Z., Xiang, T., Kodirov, E., Gong, S.: Zero-shot object recognition by semantic manifold distance. In: CVPR (2015)

22. 傅(Fu)，Z.；向(Xiang)，T.；科迪罗夫(Kodirov)，E.；龚(Gong)，S.:通过语义流形距离实现零样本目标识别。见:计算机视觉与模式识别会议(CVPR)(2015)

23. Li, X., Guo, Y., Schuurmans, D.: Semi-supervised zero-shot classification with label representation learning. In: ICCV (2015)

23. 李(Li)，X.；郭(Guo)，Y.；舒尔曼斯(Schuurmans)，D.:通过标签表示学习进行半监督零样本分类。见:国际计算机视觉会议(ICCV)(2015)

24. Romera-Paredes, B., Torr, P.H.S.: An embarrassingly simple approach to zero-shot learning. In: ICML (2015)

24. 罗梅拉 - 帕雷德斯(Romera - Paredes)，B.；托尔(Torr)，P.H.S.:一种极其简单的零样本学习方法。见:国际机器学习会议(ICML)(2015)

25. Kodirov, E., Xiang, T., Fu, Z., Gong, S.: Unsupervised domain adaptation for zero-shot learning. In: ICCV (2015)

25. 科迪罗夫(Kodirov)，E.；向(Xiang)，T.；傅(Fu)，Z.；龚(Gong)，S.:用于零样本学习的无监督域适应。见:国际计算机视觉会议(ICCV)(2015)

26. Zhang, Z., Saligrama, V.: Zero-shot learning via semantic similarity embedding. In: ICCV (2015)

26. 张(Zhang)，Z.；萨利格拉马(Saligrama)，V.:通过语义相似性嵌入实现零样本学习。见:国际计算机视觉会议(ICCV)(2015)

27. Zhang, Z., Saligrama, V.: Zero-shot learning via joint latent similarity embedding. In: CVPR (2016)

27. 张(Zhang)，Z.；萨利格拉马(Saligrama)，V.:通过联合潜在相似性嵌入实现零样本学习。见:计算机视觉与模式识别会议(CVPR)(2016)

28. Changpinyo, S., Chao, W.L., Gong, B., Sha, F.: Synthesized classifiers for zero-shot learning. In: CVPR (2016)

28. 昌皮尼奥(Changpinyo)，S.；赵(Chao)，W.L.；龚(Gong)，B.；沙(Sha)，F.:用于零样本学习的合成分类器。见:计算机视觉与模式识别会议(CVPR)(2016)

29. Deng, J., Dong, W., Socher, R., Li, L.J., Li, K., Fei-Fei, L.: Imagenet: a large-scale hierarchical image database. In: CVPR (2009)

29. 邓(Deng)、董(Dong)、索切尔(Socher)、李(Li)、李(Li)、李菲菲(Fei-Fei):ImageNet:一个大规模分层图像数据库。见:计算机视觉与模式识别会议(CVPR)(2009 年)

30. Mensink, T., Verbeek, J., Perronnin, F., Csurka, G.: Metric learning for large scale image classification: generalizing to new classes at near-zero cost. In: Fitzgibbon, A., Lazebnik, S., Perona, P., Sato, Y., Schmid, C. (eds.) ECCV 2012, Part II. LNCS, vol. 7573, pp. 488-501. Springer, Heidelberg (2012)

30. 门辛克(Mensink)、韦贝克(Verbeek)、佩罗宁(Perronnin)、丘尔卡(Csurka):大规模图像分类的度量学习:以近乎零成本泛化到新类别。见:菲茨吉本(Fitzgibbon)、拉泽布尼克(Lazebnik)、佩罗纳(Perona)、佐藤(Sato)、施密德(Schmid)(编)《2012 年欧洲计算机视觉会议(ECCV 2012)，第二部分》。《计算机科学讲义》(LNCS)，第 7573 卷，第 488 - 501 页。施普林格出版社，海德堡(2012 年)

31. Tang, K.D., Tappen, M.F., Sukthankar, R., Lampert, C.H.: Optimizing one-shot recognition with micro-set learning. In: CVPR (2010)

31. 唐(Tang)、塔彭(Tappen)、苏克坦卡尔(Sukthankar)、兰佩特(Lampert):通过微集学习优化一次性识别。见:计算机视觉与模式识别会议(CVPR)(2010 年)

32. Gan, C., Yang, Y., Zhu, L., Zhao, D., Zhuang, Y.: Recognizing an action using its name: a knowledge-based approach. IJCV 120, 1-17 (2016)

32. 甘(Gan)、杨(Yang)、朱(Zhu)、赵(Zhao)、庄(Zhuang):利用动作名称识别动作:一种基于知识的方法。《国际计算机视觉杂志》(IJCV)120 卷，第 1 - 17 页(2016 年)

33. Elhoseiny, M., Saleh, B., Elgammal, A.: Write a classifier: zero-shot learning using purely textual descriptions. In: ICCV (2013)

33. 埃尔霍塞尼(Elhoseiny)、萨利赫(Saleh)、埃尔加马尔(Elgammal):编写一个分类器:使用纯文本描述的零样本学习。见:国际计算机视觉会议(ICCV)(2013 年)

34. Lei Ba, J., Swersky, K., Fidler, S., Salakhutdinov, R.: Predicting deep zero-shot convolutional neural networks using textual descriptions. In: ICCV (2015)

34. 雷·巴(Lei Ba)、斯韦尔斯基(Swersky)、菲德勒(Fidler)、萨拉胡丁诺夫(Salakhutdinov):使用文本描述预测深度零样本卷积神经网络。见:国际计算机视觉会议(ICCV)(2015 年)

35. Scheirer, W.J., de Rezende Rocha, A., Sapkota, A., Boult, T.E.: Toward open set recognition. TPAMI $\mathbf{{35}}\left( 7\right) ,{1757} - {1772}\left( {2013}\right)$

35. 谢勒(Scheirer)、德雷森德·罗查(de Rezende Rocha)、萨普科塔(Sapkota)、博尔特(Boult):迈向开放集识别。《模式分析与机器智能汇刊》(TPAMI)$\mathbf{{35}}\left( 7\right) ,{1757} - {1772}\left( {2013}\right)$

36. Scheirer, W.J., Jain, L.P., Boult, T.E.: Probability models for open set recognition. TPAMI $\mathbf{{36}}\left( {11}\right) ,{2317} - {2324}\left( {2014}\right)$

36. 谢勒(Scheirer)、贾因(Jain)、博尔特(Boult):开放集识别的概率模型。《模式分析与机器智能汇刊》(TPAMI)$\mathbf{{36}}\left( {11}\right) ,{2317} - {2324}\left( {2014}\right)$

37. Jain, L.P., Scheirer, W.J., Boult, T.E.: Multi-class open set recognition using probability of inclusion. In: Fleet, D., Pajdla, T., Schiele, B., Tuytelaars, T. (eds.) ECCV 2014, Part III. LNCS, vol. 8691, pp. 393-409. Springer, Heidelberg (2014)

37. 贾因(Jain)、谢勒(Scheirer)、博尔特(Boult):使用包含概率的多类开放集识别。见:弗利特(Fleet)、帕伊德拉(Pajdla)、席勒(Schiele)、图伊特拉尔斯(Tuytelaars)(编)《2014 年欧洲计算机视觉会议(ECCV 2014)，第三部分》。《计算机科学讲义》(LNCS)，第 8691 卷，第 393 - 409 页。施普林格出版社，海德堡(2014 年)

38. Lampert, C.H., Nickisch, H., Harmeling, S.: Attribute-based classification for zero-shot visual object categorization. TPAMI $\mathbf{{36}}\left( 3\right) ,{453} - {465}\left( {2014}\right)$

38. 兰佩特(Lampert)、尼克施(Nickisch)、哈梅林(Harmeling):基于属性的分类用于零样本视觉对象分类。《模式分析与机器智能汇刊》(TPAMI)$\mathbf{{36}}\left( 3\right) ,{453} - {465}\left( {2014}\right)$

39. Wah, C., Branson, S., Welinder, P., Perona, P., Belongie, S.: The Caltech-UCSD Birds-200-2011 dataset. Technical report CNS-TR-2011-001, California Institute of Technology (2011)

39. 瓦(Wah)、布兰森(Branson)、韦林德(Welinder)、佩罗纳(Perona)、贝隆吉(Belongie):加州理工学院 - 加州大学圣地亚哥分校鸟类 200 - 2011 数据集。技术报告 CNS - TR - 2011 - 001，加州理工学院(2011 年)

40. Kriegel, H.P., Kröger, P., Schubert, E., Zimek, A.: LoOP: local outlier probabilities. In: CIKM (2009)

40. 克里格尔(Kriegel)、克罗格(Kröger)、舒伯特(Schubert)、齐梅克(Zimek):LoOP:局部离群点概率。见:信息与知识管理会议(CIKM)(2009 年)

41. Russakovsky, O., Deng, J., Su, H., Krause, J., Satheesh, S., Ma, S., Huang, Z., Karpathy, A., Khosla, A., Bernstein, M., Berg, A.C., Fei-Fei, L.: ImageNet large scale visual recognition challenge. IJCV 115(3), 211-252 (2015)

41. 鲁萨科夫斯基(Russakovsky)、邓(Deng)、苏(Su)、克劳斯(Krause)、萨特希(Satheesh)、马(Ma)、黄(Huang)、卡尔帕西(Karpathy)、科斯拉(Khosla)、伯恩斯坦(Bernstein)、伯格(Berg)、李菲菲(Fei - Fei):ImageNet 大规模视觉识别挑战赛。《国际计算机视觉杂志》(IJCV)115(3) 卷，第 211 - 252 页(2015 年)

42. Mikolov, T., Sutskever, I., Chen, K., Corrado, G.S., Dean, J.: Distributed representations of words and phrases and their compositionality. In: NIPS (2013)

43. 米科洛夫(Mikolov)、苏茨克维(Sutskever)、陈(Chen)、科拉多(Corrado)、迪恩(Dean):单词和短语的分布式表示及其组合性。见:神经信息处理系统大会(NIPS)(2013 年)

43. Szegedy, C., Liu, W., Jia, Y., Sermanet, P., Reed, S., Anguelov, D., Erhan, D., Vanhoucke, V., Rabinovich, A.: Going deeper with convolutions. In: CVPR (2015)

44. 塞格迪(Szegedy)、刘(Liu)、贾(Jia)、塞尔曼内特(Sermanet)、里德(Reed)、安格洛夫(Anguelov)、埃尔汉(Erhan)、范霍克(Vanhoucke)、拉宾诺维奇(Rabinovich):卷积神经网络的深度探索。见:计算机视觉与模式识别会议(CVPR)(2015 年)

44. Jia, Y., Shelhamer, E., Donahue, J., Karayev, S., Long, J., Girshick, R., Guadar-rama, S., Darrell, T.: Caffe: convolutional architecture for fast feature embedding. In: ACM Multimedia (2014)

45. 贾(Jia)、谢尔哈默(Shelhamer)、多纳休(Donahue)、卡拉耶夫(Karayev)、朗(Long)、吉里什克(Girshick)、瓜达拉马(Guadar - rama)、达雷尔(Darrell):Caffe:用于快速特征嵌入的卷积架构。见:ACM 多媒体会议(2014 年)

45. Crammer, K., Singer, Y.: On the algorithmic implementation of multiclass kernel-based vector machines. JMLR 2, 265-292 (2002)

45. 克拉默(Crammer)，K.；辛格(Singer)，Y.:基于多类核的向量机的算法实现。《机器学习研究杂志》(Journal of Machine Learning Research，JMLR)2，265 - 292(2002)