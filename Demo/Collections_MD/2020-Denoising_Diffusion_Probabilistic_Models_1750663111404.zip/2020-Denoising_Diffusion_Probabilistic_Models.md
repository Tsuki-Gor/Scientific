# Denoising Diffusion Probabilistic Models

# 去噪扩散概率模型

Jonathan Ho

Jonathan Ho

UC Berkeley

加州大学伯克利分校

jonathanho@berkeley.edu

Ajay Jain

Ajay Jain

UC Berkeley

加州大学伯克利分校

ajayj@berkeley.edu

Pieter Abbeel

Pieter Abbeel

UC Berkeley

加州大学伯克利分校

pabbeel@cs.berkeley.edu

## Abstract

## 摘要

We present high quality image synthesis results using diffusion probabilistic models, a class of latent variable models inspired by considerations from nonequilibrium thermodynamics. Our best results are obtained by training on a weighted variational bound designed according to a novel connection between diffusion probabilistic models and denoising score matching with Langevin dynamics, and our models naturally admit a progressive lossy decompression scheme that can be interpreted as a generalization of autoregressive decoding. On the unconditional CIFAR10 dataset, we obtain an Inception score of 9.46 and a state-of-the-art FID score of 3.17. On 256x256 LSUN, we obtain sample quality similar to ProgressiveGAN. Our implementation is available at https://github.com/hojonathanho/diffusion

我们展示了使用扩散概率模型(一类受非平衡热力学启发的潜变量模型)进行高质量图像合成的结果。我们通过在一个加权变分下界上训练获得了最佳结果，该下界是根据扩散概率模型与带有Langevin动力学的去噪得分匹配(denoising score matching)之间的新颖联系设计的，我们的模型自然支持一种渐进式有损解压方案，可被解释为自回归解码的推广。在无条件CIFAR10数据集上，我们获得了9.46的Inception分数和3.17的最先进FID分数。在256x256的LSUN数据集上，我们获得了与ProgressiveGAN相当的样本质量。我们的实现可在https://github.com/hojonathanho/diffusion获得。

## 1 Introduction

## 1 引言

Deep generative models of all kinds have recently exhibited high quality samples in a wide variety of data modalities. Generative adversarial networks (GANs), autoregressive models, flows, and variational autoencoders (VAEs) have synthesized striking image and audio samples [14, 27, 3, 58, 38, 25, 10, 32, 44, 57, 26, 33, 45, and there have been remarkable advances in energy-based modeling and score matching that have produced images comparable to those of GANs [11, 55].

各种深度生成模型近年来在多种数据模态中展现了高质量样本。生成对抗网络(GANs)、自回归模型、流模型和变分自编码器(VAEs)已合成出令人惊叹的图像和音频样本[14, 27, 3, 58, 38, 25, 10, 32, 44, 57, 26, 33, 45]，同时能量基模型和得分匹配在图像生成方面也取得了显著进展，生成的图像可与GANs媲美[11, 55]。

![bo_d1c3pvn7aajc7389qep0_0_309_1369_1182_709_0.jpg](images/bo_d1c3pvn7aajc7389qep0_0_309_1369_1182_709_0.jpg)

Figure 1: Generated samples on CelebA-HQ 256 $\times  {256}$ (left) and unconditional CIFAR10 (right)

图1:CelebA-HQ 256 $\times  {256}$(左)和无条件CIFAR10(右)上的生成样本

![bo_d1c3pvn7aajc7389qep0_1_452_201_893_145_0.jpg](images/bo_d1c3pvn7aajc7389qep0_1_452_201_893_145_0.jpg)

Figure 2: The directed graphical model considered in this work.

图2:本文所考虑的有向图模型。

This paper presents progress in diffusion probabilistic models [53]. A diffusion probabilistic model (which we will call a "diffusion model" for brevity) is a parameterized Markov chain trained using variational inference to produce samples matching the data after finite time. Transitions of this chain are learned to reverse a diffusion process, which is a Markov chain that gradually adds noise to the data in the opposite direction of sampling until signal is destroyed. When the diffusion consists of small amounts of Gaussian noise, it is sufficient to set the sampling chain transitions to conditional Gaussians too, allowing for a particularly simple neural network parameterization.

本文介绍了扩散概率模型(diffusion probabilistic models)[53]的进展。扩散概率模型(以下简称“扩散模型”)是一种参数化的马尔可夫链，通过变分推断训练以在有限时间内生成与数据分布匹配的样本。该链的转移被学习为逆转扩散过程，扩散过程是一个逐渐向数据中添加噪声的马尔可夫链，方向与采样相反，直到信号被破坏。当扩散过程由少量高斯噪声组成时，采样链的转移设置为条件高斯分布即可，这使得神经网络参数化特别简单。

Diffusion models are straightforward to define and efficient to train, but to the best of our knowledge, there has been no demonstration that they are capable of generating high quality samples. We show that diffusion models actually are capable of generating high quality samples, sometimes better than the published results on other types of generative models (Section 4). In addition, we show that a certain parameterization of diffusion models reveals an equivalence with denoising score matching over multiple noise levels during training and with annealed Langevin dynamics during sampling (Section 3.2) [55, 61]. We obtained our best sample quality results using this parameterization (Section 4.2), so we consider this equivalence to be one of our primary contributions

扩散模型定义简单且训练高效，但据我们所知，尚无证明其能够生成高质量样本。我们展示了扩散模型实际上能够生成高质量样本，有时甚至优于其他类型生成模型的已发表结果(第4节)。此外，我们展示了某种扩散模型的参数化形式在训练时与多噪声水平的去噪得分匹配等价，在采样时与退火Langevin动力学等价(第3.2节)[55, 61]。我们使用该参数化获得了最佳样本质量结果(第4.2节)，因此我们认为这一等价关系是我们的主要贡献之一。

Despite their sample quality, our models do not have competitive log likelihoods compared to other likelihood-based models (our models do, however, have log likelihoods better than the large estimates annealed importance sampling has been reported to produce for energy based models and score matching [11, 55]). We find that the majority of our models' lossless codelengths are consumed to describe imperceptible image details (Section 4.3). We present a more refined analysis of this phenomenon in the language of lossy compression, and we show that the sampling procedure of diffusion models is a type of progressive decoding that resembles autoregressive decoding along a bit ordering that vastly generalizes what is normally possible with autoregressive models.

尽管样本质量优异，我们的模型在对数似然方面并不具备与其他基于似然的模型竞争的能力(不过我们的模型对数似然优于退火重要性采样对能量基模型和得分匹配所报告的大型估计值[11, 55])。我们发现模型的大部分无损编码长度被用于描述人眼难以察觉的图像细节(第4.3节)。我们用有损压缩的语言对这一现象进行了更细致的分析，并展示了扩散模型的采样过程是一种渐进式解码，类似于沿位序的自回归解码，这大大扩展了自回归模型通常可能实现的范围。

## 2 Background

## 2 背景

Diffusion models [53] are latent variable models of the form ${p}_{\theta }\left( {\mathbf{x}}_{0}\right)  \mathrel{\text{:=}} \int {p}_{\theta }\left( {\mathbf{x}}_{0 : T}\right) d{\mathbf{x}}_{1 : T}$ , where ${\mathbf{x}}_{1},\ldots ,{\mathbf{x}}_{T}$ are latents of the same dimensionality as the data ${\mathbf{x}}_{0} \sim  q\left( {\mathbf{x}}_{0}\right)$ . The joint distribution ${p}_{\theta }\left( {\mathbf{x}}_{0 : T}\right)$ is called the reverse process, and it is defined as a Markov chain with learned Gaussian transitions starting at $p\left( {\mathbf{x}}_{T}\right)  = \mathcal{N}\left( {{\mathbf{x}}_{T};\mathbf{0},\mathbf{I}}\right)$ :

扩散模型(Diffusion models)[53] 是一种潜变量模型，形式为 ${p}_{\theta }\left( {\mathbf{x}}_{0}\right)  \mathrel{\text{:=}} \int {p}_{\theta }\left( {\mathbf{x}}_{0 : T}\right) d{\mathbf{x}}_{1 : T}$ ，其中 ${\mathbf{x}}_{1},\ldots ,{\mathbf{x}}_{T}$ 是与数据 ${\mathbf{x}}_{0} \sim  q\left( {\mathbf{x}}_{0}\right)$ 维度相同的潜变量。联合分布 ${p}_{\theta }\left( {\mathbf{x}}_{0 : T}\right)$ 称为逆过程(reverse process)，它被定义为一个以 $p\left( {\mathbf{x}}_{T}\right)  = \mathcal{N}\left( {{\mathbf{x}}_{T};\mathbf{0},\mathbf{I}}\right)$ 为起点的具有学习到的高斯转移的马尔可夫链:

$$
{p}_{\theta }\left( {\mathbf{x}}_{0 : T}\right)  \mathrel{\text{:=}} p\left( {\mathbf{x}}_{T}\right) \mathop{\prod }\limits_{{t = 1}}^{T}{p}_{\theta }\left( {{\mathbf{x}}_{t - 1} \mid  {\mathbf{x}}_{t}}\right) ,\;{p}_{\theta }\left( {{\mathbf{x}}_{t - 1} \mid  {\mathbf{x}}_{t}}\right)  \mathrel{\text{:=}} \mathcal{N}\left( {{\mathbf{x}}_{t - 1};{\mathbf{\mu }}_{\theta }\left( {{\mathbf{x}}_{t}, t}\right) ,{\mathbf{\sum }}_{\theta }\left( {{\mathbf{x}}_{t}, t}\right) }\right)  \tag{1}
$$

What distinguishes diffusion models from other types of latent variable models is that the approximate posterior $q\left( {{\mathbf{x}}_{1 : T} \mid  {\mathbf{x}}_{0}}\right)$ , called the forward process or diffusion process, is fixed to a Markov chain that gradually adds Gaussian noise to the data according to a variance schedule ${\beta }_{1},\ldots ,{\beta }_{T}$ :

扩散模型与其他类型潜变量模型的区别在于，近似后验 $q\left( {{\mathbf{x}}_{1 : T} \mid  {\mathbf{x}}_{0}}\right)$ ，称为正向过程(forward process)或扩散过程(diffusion process)，被固定为一个马尔可夫链，该链根据方差调度 ${\beta }_{1},\ldots ,{\beta }_{T}$ 逐步向数据中添加高斯噪声:

$$
q\left( {{\mathbf{x}}_{1 : T} \mid  {\mathbf{x}}_{0}}\right)  \mathrel{\text{:=}} \mathop{\prod }\limits_{{t = 1}}^{T}q\left( {{\mathbf{x}}_{t} \mid  {\mathbf{x}}_{t - 1}}\right) ,\;q\left( {{\mathbf{x}}_{t} \mid  {\mathbf{x}}_{t - 1}}\right)  \mathrel{\text{:=}} \mathcal{N}\left( {{\mathbf{x}}_{t};\sqrt{1 - {\beta }_{t}}{\mathbf{x}}_{t - 1},{\beta }_{t}\mathbf{I}}\right)  \tag{2}
$$

Training is performed by optimizing the usual variational bound on negative log likelihood:

训练通过优化负对数似然的常规模型变分下界进行:

$$
\mathbb{E}\left\lbrack  {-\log {p}_{\theta }\left( {\mathbf{x}}_{0}\right) }\right\rbrack   \leq  {\mathbb{E}}_{q}\left\lbrack  {-\log \frac{{p}_{\theta }\left( {\mathbf{x}}_{0 : T}\right) }{q\left( {{\mathbf{x}}_{1 : T} \mid  {\mathbf{x}}_{0}}\right) }}\right\rbrack   = {\mathbb{E}}_{q}\left\lbrack  {-\log p\left( {\mathbf{x}}_{T}\right)  - \mathop{\sum }\limits_{{t \geq  1}}\log \frac{{p}_{\theta }\left( {{\mathbf{x}}_{t - 1} \mid  {\mathbf{x}}_{t}}\right) }{q\left( {{\mathbf{x}}_{t} \mid  {\mathbf{x}}_{t - 1}}\right) }}\right\rbrack   =  : L \tag{3}
$$

The forward process variances ${\beta }_{t}$ can be learned by reparameterization [33] or held constant as hyperparameters, and expressiveness of the reverse process is ensured in part by the choice of Gaussian conditionals in ${p}_{\theta }\left( {{\mathbf{x}}_{t - 1} \mid  {\mathbf{x}}_{t}}\right)$ , because both processes have the same functional form when ${\beta }_{t}$ are small [53]. A notable property of the forward process is that it admits sampling ${\mathbf{x}}_{t}$ at an arbitrary timestep $t$ in closed form: using the notation ${\alpha }_{t} \mathrel{\text{:=}} 1 - {\beta }_{t}$ and ${\bar{\alpha }}_{t} \mathrel{\text{:=}} \mathop{\prod }\limits_{{s = 1}}^{t}{\alpha }_{s}$ , we have

正向过程的方差 ${\beta }_{t}$ 可以通过重参数化(reparameterization)[33] 学习，或作为超参数保持不变，逆过程的表达能力部分由 ${p}_{\theta }\left( {{\mathbf{x}}_{t - 1} \mid  {\mathbf{x}}_{t}}\right)$ 中高斯条件分布的选择保证，因为当 ${\beta }_{t}$ 较小时，两过程具有相同的函数形式[53]。正向过程的一个显著性质是它允许在任意时间步 $t$ 以闭式形式采样 ${\mathbf{x}}_{t}$ :使用符号 ${\alpha }_{t} \mathrel{\text{:=}} 1 - {\beta }_{t}$ 和 ${\bar{\alpha }}_{t} \mathrel{\text{:=}} \mathop{\prod }\limits_{{s = 1}}^{t}{\alpha }_{s}$ ，我们有

$$
q\left( {{\mathbf{x}}_{t} \mid  {\mathbf{x}}_{0}}\right)  = \mathcal{N}\left( {{\mathbf{x}}_{t};\sqrt{{\bar{\alpha }}_{t}}{\mathbf{x}}_{0},\left( {1 - {\bar{\alpha }}_{t}}\right) \mathbf{I}}\right)  \tag{4}
$$

Efficient training is therefore possible by optimizing random terms of $L$ with stochastic gradient descent. Further improvements come from variance reduction by rewriting $L$ (3) as:

因此，可以通过随机梯度下降优化 $L$ 的随机项实现高效训练。进一步的改进来自于通过重写 $L$ (3) 实现的方差减少:

$$
{\mathbb{E}}_{q}\left\lbrack  {\underset{{L}_{T}}{\underbrace{{D}_{\mathrm{{KL}}}\left( {q\left( {{\mathbf{x}}_{T} \mid  {\mathbf{x}}_{0}}\right) \parallel p\left( {\mathbf{x}}_{T}\right) }\right) }} + \mathop{\sum }\limits_{{t > 1}}\underset{{L}_{t - 1}}{\underbrace{{D}_{\mathrm{{KL}}}\left( {q\left( {{\mathbf{x}}_{t - 1} \mid  {\mathbf{x}}_{t},{\mathbf{x}}_{0}}\right) \parallel {p}_{\theta }\left( {{\mathbf{x}}_{t - 1} \mid  {\mathbf{x}}_{t}}\right) }\right) }}\underset{{L}_{0}}{\underbrace{-\log {p}_{\theta }\left( {{\mathbf{x}}_{0} \mid  {\mathbf{x}}_{1}}\right) }}}\right\rbrack   \tag{5}
$$

(See Appendix A for details. The labels on the terms are used in Section 3.) Equation (5) uses KL divergence to directly compare ${p}_{\theta }\left( {{\mathbf{x}}_{t - 1} \mid  {\mathbf{x}}_{t}}\right)$ against forward process posteriors, which are tractable when conditioned on ${\mathbf{x}}_{0}$ :

(详见附录A。术语标签在第3节中使用。)方程(5) 使用KL散度直接比较 ${p}_{\theta }\left( {{\mathbf{x}}_{t - 1} \mid  {\mathbf{x}}_{t}}\right)$ 与正向过程后验，当条件为 ${\mathbf{x}}_{0}$ 时后者是可解的:

$$
q\left( {{\mathbf{x}}_{t - 1} \mid  {\mathbf{x}}_{t},{\mathbf{x}}_{0}}\right)  = \mathcal{N}\left( {{\mathbf{x}}_{t - 1};{\widetilde{\mathbf{\mu }}}_{t}\left( {{\mathbf{x}}_{t},{\mathbf{x}}_{0}}\right) ,{\widetilde{\beta }}_{t}\mathbf{I}}\right) , \tag{6}
$$

$$
\text{where}{\widetilde{\mathbf{\mu }}}_{t}\left( {{\mathbf{x}}_{t},{\mathbf{x}}_{0}}\right)  \mathrel{\text{:=}} \frac{\sqrt{{\bar{\alpha }}_{t - 1}}{\beta }_{t}}{1 - {\bar{\alpha }}_{t}}{\mathbf{x}}_{0} + \frac{\sqrt{{\alpha }_{t}}\left( {1 - {\bar{\alpha }}_{t - 1}}\right) }{1 - {\bar{\alpha }}_{t}}{\mathbf{x}}_{t}\;\text{and}\;{\widetilde{\beta }}_{t} \mathrel{\text{:=}} \frac{1 - {\bar{\alpha }}_{t - 1}}{1 - {\bar{\alpha }}_{t}}{\beta }_{t} \tag{7}
$$

Consequently, all KL divergences in Eq. (5) are comparisons between Gaussians, so they can be calculated in a Rao-Blackwellized fashion with closed form expressions instead of high variance Monte Carlo estimates.

因此，方程(5) 中的所有KL散度都是高斯分布之间的比较，可以通过Rao-Blackwell化方法以闭式表达计算，而非使用高方差的蒙特卡洛估计。

## 3 Diffusion models and denoising autoencoders

## 3 扩散模型与去噪自编码器

Diffusion models might appear to be a restricted class of latent variable models, but they allow a large number of degrees of freedom in implementation. One must choose the variances ${\beta }_{t}$ of the forward process and the model architecture and Gaussian distribution parameterization of the reverse process. To guide our choices, we establish a new explicit connection between diffusion models and denoising score matching (Section 3.2) that leads to a simplified, weighted variational bound objective for diffusion models (Section 3.4). Ultimately, our model design is justified by simplicity and empirical results (Section 4). Our discussion is categorized by the terms of Eq. (5).

扩散模型看似是一类受限的潜变量模型，但在实现上允许大量自由度。必须选择正向过程的方差 ${\beta }_{t}$ 以及逆过程的模型架构和高斯分布参数化。为指导选择，我们建立了扩散模型与去噪得分匹配(denoising score matching)(第3.2节)之间的新显式联系，进而导出简化的加权变分下界目标(第3.4节)。最终，我们的模型设计以简洁性和实证结果(第4节)为依据。讨论内容按方程(5)的术语分类。

### 3.1 Forward process and ${L}_{T}$

### 3.1 正向过程与 ${L}_{T}$

We ignore the fact that the forward process variances ${\beta }_{t}$ are learnable by reparameterization and instead fix them to constants (see Section 4 for details). Thus, in our implementation, the approximate posterior $q$ has no learnable parameters, so ${L}_{T}$ is a constant during training and can be ignored.

我们忽略正向过程方差 ${\beta }_{t}$ 可通过重参数化学习的事实，而是将其固定为常数(详见第4节)。因此，在我们的实现中，近似后验 $q$ 无可学习参数，故 ${L}_{T}$ 在训练期间为常数，可忽略。

### 3.2 Reverse process and ${L}_{1 : T - 1}$

### 3.2 逆过程与 ${L}_{1 : T - 1}$

Now we discuss our choices in ${p}_{\theta }\left( {{\mathbf{x}}_{t - 1} \mid  {\mathbf{x}}_{t}}\right)  = \mathcal{N}\left( {{\mathbf{x}}_{t - 1};{\mathbf{\mu }}_{\theta }\left( {{\mathbf{x}}_{t}, t}\right) ,{\mathbf{\sum }}_{\theta }\left( {{\mathbf{x}}_{t}, t}\right) }\right)$ for $1 < t \leq  T$ . First, we set ${\mathbf{\sum }}_{\theta }\left( {{\mathbf{x}}_{t}, t}\right)  = {\sigma }_{t}^{2}\mathbf{I}$ to untrained time dependent constants. Experimentally, both ${\sigma }_{t}^{2} = {\beta }_{t}$ and ${\sigma }_{t}^{2} = {\widetilde{\beta }}_{t} = \frac{1 - {\bar{\alpha }}_{t - 1}}{1 - {\bar{\alpha }}_{t}}{\beta }_{t}$ had similar results. The first choice is optimal for ${\mathbf{x}}_{0} \sim  \mathcal{N}\left( {\mathbf{0},\mathbf{I}}\right)$ , and the second is optimal for ${\mathrm{x}}_{0}$ deterministically set to one point. These are the two extreme choices corresponding to upper and lower bounds on reverse process entropy for data with coordinatewise unit variance [53].

现在我们讨论在${p}_{\theta }\left( {{\mathbf{x}}_{t - 1} \mid  {\mathbf{x}}_{t}}\right)  = \mathcal{N}\left( {{\mathbf{x}}_{t - 1};{\mathbf{\mu }}_{\theta }\left( {{\mathbf{x}}_{t}, t}\right) ,{\mathbf{\sum }}_{\theta }\left( {{\mathbf{x}}_{t}, t}\right) }\right)$中为$1 < t \leq  T$所做的选择。首先，我们将${\mathbf{\sum }}_{\theta }\left( {{\mathbf{x}}_{t}, t}\right)  = {\sigma }_{t}^{2}\mathbf{I}$设为未训练的时间相关常数。实验表明，${\sigma }_{t}^{2} = {\beta }_{t}$和${\sigma }_{t}^{2} = {\widetilde{\beta }}_{t} = \frac{1 - {\bar{\alpha }}_{t - 1}}{1 - {\bar{\alpha }}_{t}}{\beta }_{t}$的结果相似。第一种选择对于${\mathbf{x}}_{0} \sim  \mathcal{N}\left( {\mathbf{0},\mathbf{I}}\right)$是最优的，而第二种选择对于确定性地设为一点的${\mathrm{x}}_{0}$是最优的。这是对应于坐标单位方差数据的逆过程熵的上下界的两个极端选择[53]。

Second, to represent the mean ${\mathbf{\mu }}_{\theta }\left( {{\mathbf{x}}_{t}, t}\right)$ , we propose a specific parameterization motivated by the following analysis of ${L}_{t}$ . With ${p}_{\theta }\left( {{\mathbf{x}}_{t - 1} \mid  {\mathbf{x}}_{t}}\right)  = \mathcal{N}\left( {{\mathbf{x}}_{t - 1};{\mathbf{\mu }}_{\theta }\left( {{\mathbf{x}}_{t}, t}\right) ,{\sigma }_{t}^{2}\mathbf{I}}\right)$ , we can write:

其次，为了表示均值${\mathbf{\mu }}_{\theta }\left( {{\mathbf{x}}_{t}, t}\right)$，我们提出了一种特定的参数化方法，其动机来自对${L}_{t}$的以下分析。利用${p}_{\theta }\left( {{\mathbf{x}}_{t - 1} \mid  {\mathbf{x}}_{t}}\right)  = \mathcal{N}\left( {{\mathbf{x}}_{t - 1};{\mathbf{\mu }}_{\theta }\left( {{\mathbf{x}}_{t}, t}\right) ,{\sigma }_{t}^{2}\mathbf{I}}\right)$，我们可以写成:

$$
{L}_{t - 1} = {\mathbb{E}}_{q}\left\lbrack  {\frac{1}{2{\sigma }_{t}^{2}}{\begin{Vmatrix}{\widetilde{\mathbf{\mu }}}_{t}\left( {\mathbf{x}}_{t},{\mathbf{x}}_{0}\right)  - {\mathbf{\mu }}_{\theta }\left( {\mathbf{x}}_{t}, t\right) \end{Vmatrix}}^{2}}\right\rbrack   + C \tag{8}
$$

where $C$ is a constant that does not depend on $\theta$ . So, we see that the most straightforward parameterization of ${\mathbf{\mu }}_{\theta }$ is a model that predicts ${\widetilde{\mathbf{\mu }}}_{t}$ , the forward process posterior mean. However, we can expand Eq. (8) further by reparameterizing Eq. (4) as ${\mathbf{x}}_{t}\left( {{\mathbf{x}}_{0},\epsilon }\right)  = \sqrt{{\bar{\alpha }}_{t}}{\mathbf{x}}_{0} + \sqrt{1 - {\bar{\alpha }}_{t}}\epsilon$ for $\epsilon  \sim  \mathcal{N}\left( {\mathbf{0},\mathbf{I}}\right)$ and applying the forward process posterior formula (7):

其中$C$是一个不依赖于$\theta$的常数。因此，我们看到对${\mathbf{\mu }}_{\theta }$最直接的参数化是一个预测前向过程后验均值${\widetilde{\mathbf{\mu }}}_{t}$的模型。然而，我们可以通过将公式(4)重新参数化为${\mathbf{x}}_{t}\left( {{\mathbf{x}}_{0},\epsilon }\right)  = \sqrt{{\bar{\alpha }}_{t}}{\mathbf{x}}_{0} + \sqrt{1 - {\bar{\alpha }}_{t}}\epsilon$以表示$\epsilon  \sim  \mathcal{N}\left( {\mathbf{0},\mathbf{I}}\right)$，并应用前向过程后验公式(7)，进一步展开公式(8):

$$
{L}_{t - 1} - C = {\mathbb{E}}_{{\mathbf{x}}_{0},\epsilon }\left\lbrack  {\frac{1}{2{\sigma }_{t}^{2}}{\begin{Vmatrix}{\widetilde{\mathbf{\mu }}}_{t}\left( {\mathbf{x}}_{t}\left( {\mathbf{x}}_{0},\mathbf{\epsilon }\right) ,\frac{1}{\sqrt{{\bar{\alpha }}_{t}}}\left( {\mathbf{x}}_{t}\left( {\mathbf{x}}_{0},\mathbf{\epsilon }\right)  - \sqrt{1 - {\bar{\alpha }}_{t}}\mathbf{\epsilon }\right) \right)  - {\mathbf{\mu }}_{\theta }\left( {\mathbf{x}}_{t}\left( {\mathbf{x}}_{0},\mathbf{\epsilon }\right) , t\right) \end{Vmatrix}}^{2}}\right.
$$

(9)

$$
= {\mathbb{E}}_{{\mathbf{x}}_{0},\epsilon }\left\lbrack  {\frac{1}{2{\sigma }_{t}^{2}}{\begin{Vmatrix}\frac{1}{\sqrt{{\alpha }_{t}}}\left( {\mathbf{x}}_{t}\left( {\mathbf{x}}_{0},\epsilon \right)  - \frac{{\beta }_{t}}{\sqrt{1 - {\bar{\alpha }}_{t}}}\epsilon \right)  - {\mathbf{\mu }}_{\theta }\left( {\mathbf{x}}_{t}\left( {\mathbf{x}}_{0},\epsilon \right) , t\right) \end{Vmatrix}}^{2}}\right\rbrack   \tag{10}
$$

Algorithm 1 Training

算法1 训练

---

repeat

重复

${\mathbf{x}}_{0} \sim  q\left( {\mathbf{x}}_{0}\right)$

$t \sim  \operatorname{Uniform}\left( {\{ 1,\ldots , T\} }\right)$

$\epsilon  \sim  \mathcal{N}\left( {\mathbf{0},\mathbf{I}}\right)$

Take gradient descent step on

对以下内容进行梯度下降步骤

	${\nabla }_{\theta }{\begin{Vmatrix}\mathbf{\epsilon } - {\mathbf{\epsilon }}_{\theta }\left( \sqrt{{\bar{\alpha }}_{t}}{\mathbf{x}}_{0} + \sqrt{1 - {\bar{\alpha }}_{t}}\mathbf{\epsilon }, t\right) \end{Vmatrix}}^{2}$

until converged

直到收敛

---

Algorithm 2 Sampling

算法2 采样

---

${\mathbf{x}}_{T} \sim  \mathcal{N}\left( {\mathbf{0},\mathbf{I}}\right)$

		for $t = T,\ldots ,1$ do

		对于$t = T,\ldots ,1$执行

								$\mathbf{z} \sim  \mathcal{N}\left( {\mathbf{0},\mathbf{I}}\right)$ if $t > 1$ , else $\mathbf{z} = \mathbf{0}$

								如果$t > 1$则为$\mathbf{z} \sim  \mathcal{N}\left( {\mathbf{0},\mathbf{I}}\right)$，否则为$\mathbf{z} = \mathbf{0}$

										${\mathbf{x}}_{t - 1} = \frac{1}{\sqrt{{\alpha }_{t}}}\left( {{\mathbf{x}}_{t} - \frac{1 - {\alpha }_{t}}{\sqrt{1 - {\bar{\alpha }}_{t}}}{\mathbf{\epsilon }}_{\theta }\left( {{\mathbf{x}}_{t}, t}\right) }\right)  + {\sigma }_{t}\mathbf{z}$

end for

结束循环

return ${\mathbf{x}}_{0}$

返回${\mathbf{x}}_{0}$

---

Equation (10) reveals that ${\mathbf{\mu }}_{\theta }$ must predict $\frac{1}{\sqrt{{\alpha }_{t}}}\left( {{\mathbf{x}}_{t} - \frac{{\beta }_{t}}{\sqrt{1 - {\bar{\alpha }}_{t}}}\mathbf{\epsilon }}\right)$ given ${\mathbf{x}}_{t}$ . Since ${\mathbf{x}}_{t}$ is available as input to the model, we may choose the parameterization

公式(10)表明，${\mathbf{\mu }}_{\theta }$必须在给定${\mathbf{x}}_{t}$的条件下预测$\frac{1}{\sqrt{{\alpha }_{t}}}\left( {{\mathbf{x}}_{t} - \frac{{\beta }_{t}}{\sqrt{1 - {\bar{\alpha }}_{t}}}\mathbf{\epsilon }}\right)$。由于${\mathbf{x}}_{t}$作为模型输入是可用的，我们可以选择以下参数化方式

$$
{\mathbf{\mu }}_{\theta }\left( {{\mathbf{x}}_{t}, t}\right)  = {\widetilde{\mathbf{\mu }}}_{t}\left( {{\mathbf{x}}_{t},\frac{1}{\sqrt{{\bar{\alpha }}_{t}}}\left( {{\mathbf{x}}_{t} - \sqrt{1 - {\bar{\alpha }}_{t}}{\mathbf{\epsilon }}_{\theta }\left( {\mathbf{x}}_{t}\right) }\right) }\right)  = \frac{1}{\sqrt{{\alpha }_{t}}}\left( {{\mathbf{x}}_{t} - \frac{{\beta }_{t}}{\sqrt{1 - {\bar{\alpha }}_{t}}}{\mathbf{\epsilon }}_{\theta }\left( {{\mathbf{x}}_{t}, t}\right) }\right)  \tag{11}
$$

where ${\epsilon }_{\theta }$ is a function approximator intended to predict $\epsilon$ from ${\mathbf{x}}_{t}$ . To sample ${\mathbf{x}}_{t - 1} \sim  {p}_{\theta }\left( {{\mathbf{x}}_{t - 1} \mid  {\mathbf{x}}_{t}}\right)$ is to compute ${\mathbf{x}}_{t - 1} = \frac{1}{\sqrt{{\alpha }_{t}}}\left( {{\mathbf{x}}_{t} - \frac{{\beta }_{t}}{\sqrt{1 - {\bar{\alpha }}_{t}}}{\mathbf{\epsilon }}_{\theta }\left( {{\mathbf{x}}_{t}, t}\right) }\right)  + {\sigma }_{t}\mathbf{z}$ , where $\mathbf{z} \sim  \mathcal{N}\left( {\mathbf{0},\mathbf{I}}\right)$ . The complete sampling procedure, Algorithm 2, resembles Langevin dynamics with ${\epsilon }_{\theta }$ as a learned gradient of the data density. Furthermore, with the parameterization (11), Eq. (10) simplifies to:

其中 ${\epsilon }_{\theta }$ 是一个函数逼近器，旨在从 ${\mathbf{x}}_{t}$ 预测 $\epsilon$ 。采样 ${\mathbf{x}}_{t - 1} \sim  {p}_{\theta }\left( {{\mathbf{x}}_{t - 1} \mid  {\mathbf{x}}_{t}}\right)$ 即计算 ${\mathbf{x}}_{t - 1} = \frac{1}{\sqrt{{\alpha }_{t}}}\left( {{\mathbf{x}}_{t} - \frac{{\beta }_{t}}{\sqrt{1 - {\bar{\alpha }}_{t}}}{\mathbf{\epsilon }}_{\theta }\left( {{\mathbf{x}}_{t}, t}\right) }\right)  + {\sigma }_{t}\mathbf{z}$ ，其中 $\mathbf{z} \sim  \mathcal{N}\left( {\mathbf{0},\mathbf{I}}\right)$ 。完整的采样过程，算法2，类似于以 ${\epsilon }_{\theta }$ 作为数据密度学习梯度的朗之万动力学。此外，利用参数化(11)，方程(10)简化为:

$$
{\mathbb{E}}_{{\mathbf{x}}_{0},\epsilon }\left\lbrack  {\frac{{\beta }_{t}^{2}}{2{\sigma }_{t}^{2}{\alpha }_{t}\left( {1 - {\bar{\alpha }}_{t}}\right) }{\begin{Vmatrix}\mathbf{\epsilon } - {\mathbf{\epsilon }}_{\theta }\left( \sqrt{{\bar{\alpha }}_{t}}{\mathbf{x}}_{0} + \sqrt{1 - {\bar{\alpha }}_{t}}\mathbf{\epsilon }, t\right) \end{Vmatrix}}^{2}}\right\rbrack   \tag{12}
$$

which resembles denoising score matching over multiple noise scales indexed by $t$ [55]. As Eq. (12) is equal to (one term of) the variational bound for the Langevin-like reverse process (11), we see that optimizing an objective resembling denoising score matching is equivalent to using variational inference to fit the finite-time marginal of a sampling chain resembling Langevin dynamics.

这类似于在多个由 $t$ 索引的噪声尺度上的去噪分数匹配[55]。由于方程(12)等价于朗之万类逆过程(11)变分界限的(一个项)，我们看到优化类似去噪分数匹配的目标等同于使用变分推断拟合类似朗之万动力学的采样链的有限时间边际分布。

To summarize, we can train the reverse process mean function approximator ${\mathbf{\mu }}_{\theta }$ to predict ${\widetilde{\mathbf{\mu }}}_{t}$ , or by modifying its parameterization, we can train it to predict $\epsilon$ . (There is also the possibility of predicting ${\mathbf{x}}_{0}$ , but we found this to lead to worse sample quality early in our experiments.) We have shown that the $\epsilon$ -prediction parameterization both resembles Langevin dynamics and simplifies the diffusion model's variational bound to an objective that resembles denoising score matching. Nonetheless, it is just another parameterization of ${p}_{\theta }\left( {{\mathbf{x}}_{t - 1} \mid  {\mathbf{x}}_{t}}\right)$ , so we verify its effectiveness in Section 4 in an ablation where we compare predicting $\epsilon$ against predicting ${\widetilde{\mathbf{\mu }}}_{t}$ .

总结来说，我们可以训练逆过程均值函数逼近器 ${\mathbf{\mu }}_{\theta }$ 来预测 ${\widetilde{\mathbf{\mu }}}_{t}$ ，或者通过修改其参数化，训练其预测 $\epsilon$ 。(也可以预测 ${\mathbf{x}}_{0}$ ，但我们发现在早期实验中这会导致样本质量下降。) 我们已证明 $\epsilon$ 预测参数化既类似朗之万动力学，又将扩散模型的变分界限简化为类似去噪分数匹配的目标。然而，这只是 ${p}_{\theta }\left( {{\mathbf{x}}_{t - 1} \mid  {\mathbf{x}}_{t}}\right)$ 的另一种参数化，因此我们在第4节通过消融实验验证了其有效性，比较了预测 $\epsilon$ 与预测 ${\widetilde{\mathbf{\mu }}}_{t}$ 。

### 3.3 Data scaling, reverse process decoder, and ${L}_{0}$

### 3.3 数据缩放、逆过程解码器及 ${L}_{0}$

We assume that image data consists of integers in $\{ 0,1,\ldots ,{255}\}$ scaled linearly to $\left\lbrack  {-1,1}\right\rbrack$ . This ensures that the neural network reverse process operates on consistently scaled inputs starting from the standard normal prior $p\left( {\mathbf{x}}_{T}\right)$ . To obtain discrete log likelihoods, we set the last term of the reverse process to an independent discrete decoder derived from the Gaussian $\mathcal{N}\left( {{\mathbf{x}}_{0};{\mathbf{\mu }}_{\theta }\left( {{\mathbf{x}}_{1},1}\right) ,{\sigma }_{1}^{2}\mathbf{I}}\right)$ :

我们假设图像数据由 $\{ 0,1,\ldots ,{255}\}$ 范围内的整数组成，并线性缩放至 $\left\lbrack  {-1,1}\right\rbrack$ 。这确保神经网络逆过程在从标准正态先验 $p\left( {\mathbf{x}}_{T}\right)$ 开始时，输入具有一致的缩放。为了获得离散对数似然，我们将逆过程的最后一项设为由高斯 $\mathcal{N}\left( {{\mathbf{x}}_{0};{\mathbf{\mu }}_{\theta }\left( {{\mathbf{x}}_{1},1}\right) ,{\sigma }_{1}^{2}\mathbf{I}}\right)$ 推导出的独立离散解码器:

$$
{p}_{\theta }\left( {{\mathbf{x}}_{0} \mid  {\mathbf{x}}_{1}}\right)  = \mathop{\prod }\limits_{{i = 1}}^{D}{\int }_{{\delta }_{ - }\left( {x}_{0}^{i}\right) }^{{\delta }_{ + }\left( {x}_{0}^{i}\right) }\mathcal{N}\left( {x;{\mu }_{\theta }^{i}\left( {{\mathbf{x}}_{1},1}\right) ,{\sigma }_{1}^{2}}\right) {dx} \tag{13}
$$

$$
{\delta }_{ + }\left( x\right)  = \left\{  {\begin{array}{ll} \infty & \text{ if }x = 1 \\  x + \frac{1}{255} & \text{ if }x < 1 \end{array}\;{\delta }_{ - }\left( x\right)  = \left\{  \begin{array}{ll}  - \infty & \text{ if }x =  - 1 \\  x - \frac{1}{255} & \text{ if }x >  - 1 \end{array}\right. }\right.
$$

where $D$ is the data dimensionality and the $i$ superscript indicates extraction of one coordinate. (It would be straightforward to instead incorporate a more powerful decoder like a conditional autoregressive model, but we leave that to future work.) Similar to the discretized continuous distributions used in VAE decoders and autoregressive models [34, 52], our choice here ensures that the variational bound is a lossless codelength of discrete data, without need of adding noise to the data or incorporating the Jacobian of the scaling operation into the log likelihood. At the end of sampling, we display ${\mathbf{\mu }}_{\theta }\left( {{\mathbf{x}}_{1},1}\right)$ noiselessly.

其中 $D$ 是数据维度，$i$ 上标表示提取单个坐标。(也可以轻松地引入更强大的解码器，如条件自回归模型，但我们留待未来工作。)类似于变分自编码器解码器和自回归模型中使用的离散化连续分布[34, 52]，我们的选择确保变分界限是离散数据的无损编码长度，无需向数据添加噪声或将缩放操作的雅可比行列式纳入对数似然。采样结束时，我们无噪声地显示 ${\mathbf{\mu }}_{\theta }\left( {{\mathbf{x}}_{1},1}\right)$ 。

### 3.4 Simplified training objective

### 3.4 简化训练目标

With the reverse process and decoder defined above, the variational bound, consisting of terms derived from Eqs. (12) and (13), is clearly differentiable with respect to $\theta$ and is ready to be employed for training. However, we found it beneficial to sample quality (and simpler to implement) to train on the following variant of the variational bound:

通过上述定义的逆过程和解码器，由公式(12)和(13)推导出的变分下界显然关于$\theta$是可微的，且可以用于训练。然而，我们发现训练以下变分下界的变体在采样质量上更优且实现更简单:

$$
{L}_{\text{simple }}\left( \theta \right)  \mathrel{\text{:=}} {\mathbb{E}}_{t,{\mathbf{x}}_{0},\epsilon }\left\lbrack  {\begin{Vmatrix}\mathbf{\epsilon } - {\mathbf{\epsilon }}_{\theta }\left( \sqrt{{\bar{\alpha }}_{t}}{\mathbf{x}}_{0} + \sqrt{1 - {\bar{\alpha }}_{t}}\mathbf{\epsilon }, t\right) \end{Vmatrix}}^{2}\right\rbrack   \tag{14}
$$

Table 1: CIFAR10 results. NLL measured in bits/dim.

表1:CIFAR10结果。负对数似然(NLL)以比特/维度为单位测量。

<table><tr><td>Model</td><td>IS</td><td>FID</td><td>NLL Test (Train)</td></tr><tr><td colspan="4">Conditional</td></tr><tr><td>EBM [11]</td><td>8.30</td><td>37.9</td><td/></tr><tr><td>JEM 17</td><td>8.76</td><td>38.4</td><td/></tr><tr><td>BigGAN 3</td><td>9.22</td><td>14.73</td><td/></tr><tr><td>StyleGAN2 + ADA (v1) [29]</td><td>10.06</td><td>2.67</td><td/></tr><tr><td colspan="4">Unconditional</td></tr><tr><td>Diffusion (original) 53</td><td/><td/><td>$\leq  {5.40}$</td></tr><tr><td>Gated PixelCNN [59</td><td>4.60</td><td>65.93</td><td>${3.03}\left( {2.90}\right)$</td></tr><tr><td>Sparse Transformer [7]</td><td/><td/><td>2.80</td></tr><tr><td>PixelIQN 43</td><td>5.29</td><td>49.46</td><td/></tr><tr><td>EBM 11</td><td>6.78</td><td>38.2</td><td/></tr><tr><td>NCSNv2 [56]</td><td/><td>31.75</td><td/></tr><tr><td>NCSN [55]</td><td>${8.87} \pm  {0.12}$</td><td>25.32</td><td/></tr><tr><td>SNGAN [39]</td><td>${8.22} \pm  {0.05}$</td><td>21.7</td><td/></tr><tr><td>SNGAN-DDLS 4</td><td>${9.09} \pm  {0.10}$</td><td>15.42</td><td/></tr><tr><td>StyleGAN2 + ADA (v1) [29]</td><td>${9.74} \pm  {0.05}$</td><td>3.26</td><td/></tr><tr><td>Ours ( $L$ , fixed isotropic $\mathbf{\sum }$ )</td><td>${7.67} \pm  {0.13}$</td><td>13.51</td><td>3.70 (3.69)</td></tr><tr><td>Ours ( ${L}_{\text{simple }}$ )</td><td>${9.46} \pm  {0.11}$</td><td>3.17</td><td>$\leq  {3.75}\left( {3.72}\right)$</td></tr></table>

<table><tbody><tr><td>模型</td><td>IS</td><td>FID</td><td>测试负对数似然(训练)</td></tr><tr><td colspan="4">条件</td></tr><tr><td>能量基模型(EBM)[11]</td><td>8.30</td><td>37.9</td><td></td></tr><tr><td>联合能量模型(JEM)17</td><td>8.76</td><td>38.4</td><td></td></tr><tr><td>BigGAN 3</td><td>9.22</td><td>14.73</td><td></td></tr><tr><td>StyleGAN2 + ADA(v1)[29]</td><td>10.06</td><td>2.67</td><td></td></tr><tr><td colspan="4">无条件</td></tr><tr><td>扩散模型(原始)53</td><td></td><td></td><td>$\leq  {5.40}$</td></tr><tr><td>门控PixelCNN [59</td><td>4.60</td><td>65.93</td><td>${3.03}\left( {2.90}\right)$</td></tr><tr><td>稀疏变换器(Sparse Transformer)[7]</td><td></td><td></td><td>2.80</td></tr><tr><td>PixelIQN 43</td><td>5.29</td><td>49.46</td><td></td></tr><tr><td>能量基模型(EBM)11</td><td>6.78</td><td>38.2</td><td></td></tr><tr><td>NCSNv2 [56]</td><td></td><td>31.75</td><td></td></tr><tr><td>NCSN [55]</td><td>${8.87} \pm  {0.12}$</td><td>25.32</td><td></td></tr><tr><td>SNGAN [39]</td><td>${8.22} \pm  {0.05}$</td><td>21.7</td><td></td></tr><tr><td>SNGAN-DDLS 4</td><td>${9.09} \pm  {0.10}$</td><td>15.42</td><td></td></tr><tr><td>StyleGAN2 + ADA(v1)[29]</td><td>${9.74} \pm  {0.05}$</td><td>3.26</td><td></td></tr><tr><td>我们的($L$，固定各向同性$\mathbf{\sum }$)</td><td>${7.67} \pm  {0.13}$</td><td>13.51</td><td>3.70 (3.69)</td></tr><tr><td>我们的(${L}_{\text{simple }}$)</td><td>${9.46} \pm  {0.11}$</td><td>3.17</td><td>$\leq  {3.75}\left( {3.72}\right)$</td></tr></tbody></table>

-Table 2: Unconditional CIFAR10 reverse process parameterization and training objective ablation. Blank entries were unstable to train and generated poor samples with out-of-range scores.

-表2:无条件CIFAR10逆过程参数化及训练目标消融。空白项表示训练不稳定且生成的样本评分异常。

<table><tr><td>Objective</td><td>IS</td><td>FID</td></tr><tr><td colspan="3">$\widetilde{\mathbf{\mu }}$ prediction (baseline)</td></tr><tr><td>$L$ , learned diagonal $\mathbf{\sum }$</td><td>${7.28} \pm  {0.10}$</td><td>23.69</td></tr><tr><td>$L$ , fixed isotropic $\mathbf{\sum }$</td><td>${8.06} \pm  {0.09}$</td><td>13.22</td></tr><tr><td>$\parallel \widetilde{\mathbf{\mu }} - {\widetilde{\mathbf{\mu }}}_{\theta }{\parallel }^{2}$</td><td>-</td><td>-</td></tr><tr><td colspan="3">$\epsilon$ prediction (ours)</td></tr><tr><td>$L$ , learned diagonal $\mathbf{\sum }$</td><td>-</td><td>-</td></tr><tr><td>$L$ , fixed isotropic $\mathbf{\sum }$</td><td>${7.67} \pm  {0.13}$</td><td>13.51</td></tr><tr><td>${\begin{Vmatrix}\widetilde{\mathbf{\epsilon }} - {\mathbf{\epsilon }}_{\theta }\end{Vmatrix}}^{2}\left( {L}_{\mathrm{{simple}}}\right)$</td><td>${9.46} \pm  {0.11}$</td><td>3.17</td></tr></table>

<table><tbody><tr><td>目标</td><td>IS</td><td>FID</td></tr><tr><td colspan="3">$\widetilde{\mathbf{\mu }}$ 预测(基线)</td></tr><tr><td>$L$，学习的对角线 $\mathbf{\sum }$</td><td>${7.28} \pm  {0.10}$</td><td>23.69</td></tr><tr><td>$L$，固定各向同性 $\mathbf{\sum }$</td><td>${8.06} \pm  {0.09}$</td><td>13.22</td></tr><tr><td>$\parallel \widetilde{\mathbf{\mu }} - {\widetilde{\mathbf{\mu }}}_{\theta }{\parallel }^{2}$</td><td>-</td><td>-</td></tr><tr><td colspan="3">$\epsilon$ 预测(我们的)</td></tr><tr><td>$L$，学习的对角线 $\mathbf{\sum }$</td><td>-</td><td>-</td></tr><tr><td>$L$，固定各向同性 $\mathbf{\sum }$</td><td>${7.67} \pm  {0.13}$</td><td>13.51</td></tr><tr><td>${\begin{Vmatrix}\widetilde{\mathbf{\epsilon }} - {\mathbf{\epsilon }}_{\theta }\end{Vmatrix}}^{2}\left( {L}_{\mathrm{{simple}}}\right)$</td><td>${9.46} \pm  {0.11}$</td><td>3.17</td></tr></tbody></table>

where $t$ is uniform between 1 and $T$ . The $t = 1$ case corresponds to ${L}_{0}$ with the integral in the discrete decoder definition (13) approximated by the Gaussian probability density function times the bin width, ignoring ${\sigma }_{1}^{2}$ and edge effects. The $t > 1$ cases correspond to an unweighted version of Eq. (12), analogous to the loss weighting used by the NCSN denoising score matching model [55] $\left( {L}_{T}\right.$ does not appear because the forward process variances ${\beta }_{t}$ are fixed.) Algorithm 1 displays the complete training procedure with this simplified objective.

其中 $t$ 在 1 和 $T$ 之间均匀分布。$t = 1$ 情况对应于 ${L}_{0}$，其中离散解码器定义(13)中的积分被高斯概率密度函数乘以区间宽度近似，忽略了 ${\sigma }_{1}^{2}$ 和边缘效应。$t > 1$ 情况对应于方程(12)的无权版本，类似于 NCSN 去噪得分匹配模型[55]中使用的损失加权。$\left( {L}_{T}\right.$ 不出现，因为前向过程的方差 ${\beta }_{t}$ 是固定的。)算法1展示了使用该简化目标的完整训练过程。

Since our simplified objective (14) discards the weighting in Eq. (12), it is a weighted variational bound that emphasizes different aspects of reconstruction compared to the standard variational bound [18, 22]. In particular, our diffusion process setup in Section 4 causes the simplified objective to down-weight loss terms corresponding to small $t$ . These terms train the network to denoise data with very small amounts of noise, so it is beneficial to down-weight them so that the network can focus on more difficult denoising tasks at larger $t$ terms. We will see in our experiments that this reweighting leads to better sample quality.

由于我们的简化目标(14)舍弃了方程(12)中的加权，它是一个加权变分下界，与标准变分下界[18, 22]相比，强调了重建的不同方面。特别地，我们在第4节中设置的扩散过程导致简化目标对对应于小 $t$ 的损失项进行降权。这些项训练网络去噪含有极少噪声的数据，因此对它们进行降权有利于网络专注于更大 $t$ 项对应的更困难的去噪任务。我们的实验将显示这种重新加权带来了更好的样本质量。

## 4 Experiments

## 4 实验

We set $T = {1000}$ for all experiments so that the number of neural network evaluations needed during sampling matches previous work [53, 55]. We set the forward process variances to constants increasing linearly from ${\beta }_{1} = {10}^{-4}$ to ${\beta }_{T} = {0.02}$ . These constants were chosen to be small relative to data scaled to $\left\lbrack  {-1,1}\right\rbrack$ , ensuring that reverse and forward processes have approximately the same functional form while keeping the signal-to-noise ratio at ${\mathbf{x}}_{T}$ as small as possible $\left( {{L}_{T} = }\right.$ ${D}_{\mathrm{{KL}}}\left( {q\left( {{\mathbf{x}}_{T} \mid  {\mathbf{x}}_{0}}\right) \parallel \mathcal{N}\left( {\mathbf{0},\mathbf{I}}\right) }\right)  \approx  {10}^{-5}$ bits per dimension in our experiments).

我们为所有实验设置了 $T = {1000}$，以使采样过程中所需的神经网络评估次数与先前工作[53, 55]相匹配。我们将前向过程的方差设为从 ${\beta }_{1} = {10}^{-4}$ 线性增加到 ${\beta }_{T} = {0.02}$ 的常数。这些常数相对于缩放到 $\left\lbrack  {-1,1}\right\rbrack$ 的数据较小，确保逆过程和前向过程具有大致相同的函数形式，同时使信噪比在我们的实验中保持在 ${\mathbf{x}}_{T}$ $\left( {{L}_{T} = }\right.$ ${D}_{\mathrm{{KL}}}\left( {q\left( {{\mathbf{x}}_{T} \mid  {\mathbf{x}}_{0}}\right) \parallel \mathcal{N}\left( {\mathbf{0},\mathbf{I}}\right) }\right)  \approx  {10}^{-5}$ 比特每维度的尽可能小水平。

To represent the reverse process, we use a U-Net backbone similar to an unmasked PixelCNN++ [52] 48] with group normalization throughout [66]. Parameters are shared across time, which is specified to the network using the Transformer sinusoidal position embedding [60]. We use self-attention at the ${16} \times  {16}$ feature map resolution [63,60]. Details are in Appendix B.

为了表示逆过程，我们使用了类似于无掩码 PixelCNN++ [52][48] 的 U-Net 主干网络，整个网络采用组归一化[66]。参数在时间上共享，时间信息通过 Transformer 正弦位置嵌入[60]传递给网络。我们在 ${16} \times  {16}$ 特征图分辨率上使用自注意力机制[63,60]。详情见附录B。

### 4.1 Sample quality

### 4.1 样本质量

Table 1 shows Inception scores, FID scores, and negative log likelihoods (lossless codelengths) on CIFAR10. With our FID score of 3.17, our unconditional model achieves better sample quality than most models in the literature, including class conditional models. Our FID score is computed with respect to the training set, as is standard practice; when we compute it with respect to the test set, the score is 5.24, which is still better than many of the training set FID scores in the literature.

表1展示了 CIFAR10 上的 Inception 分数、FID 分数和负对数似然(无损编码长度)。我们的无条件模型以3.17的FID分数实现了比文献中大多数模型更好的样本质量，包括条件类别模型。我们的FID分数是相对于训练集计算的，这是标准做法；当相对于测试集计算时，分数为5.24，仍优于文献中许多训练集的FID分数。

![bo_d1c3pvn7aajc7389qep0_5_309_200_582_399_0.jpg](images/bo_d1c3pvn7aajc7389qep0_5_309_200_582_399_0.jpg)

Figure 3: LSUN Church samples. FID=7.89

图3:LSUN 教堂样本。FID=7.89

![bo_d1c3pvn7aajc7389qep0_5_899_200_580_400_0.jpg](images/bo_d1c3pvn7aajc7389qep0_5_899_200_580_400_0.jpg)

Figure 4: LSUN Bedroom samples. FID=4.90

图4:LSUN 卧室样本。FID=4.90

Algorithm 3 Sending ${\mathbf{x}}_{0}$

算法3 发送 ${\mathbf{x}}_{0}$

---

				Send ${\mathbf{x}}_{T} \sim  q\left( {{\mathbf{x}}_{T} \mid  {\mathbf{x}}_{0}}\right)$ using $p\left( {\mathbf{x}}_{T}\right)$

				使用 $p\left( {\mathbf{x}}_{T}\right)$ 发送 ${\mathbf{x}}_{T} \sim  q\left( {{\mathbf{x}}_{T} \mid  {\mathbf{x}}_{0}}\right)$

		for $t = T - 1,\ldots ,2,1$ do

		对于 $t = T - 1,\ldots ,2,1$ 执行

										Send ${\mathbf{x}}_{t} \sim  q\left( {{\mathbf{x}}_{t} \mid  {\mathbf{x}}_{t + 1},{\mathbf{x}}_{0}}\right)$ using ${p}_{\theta }\left( {{\mathbf{x}}_{t} \mid  {\mathbf{x}}_{t + 1}}\right)$

										使用 ${p}_{\theta }\left( {{\mathbf{x}}_{t} \mid  {\mathbf{x}}_{t + 1}}\right)$ 发送 ${\mathbf{x}}_{t} \sim  q\left( {{\mathbf{x}}_{t} \mid  {\mathbf{x}}_{t + 1},{\mathbf{x}}_{0}}\right)$

end for

结束循环

Send ${\mathbf{x}}_{0}$ using ${p}_{\theta }\left( {{\mathbf{x}}_{0} \mid  {\mathbf{x}}_{1}}\right)$

使用${p}_{\theta }\left( {{\mathbf{x}}_{0} \mid  {\mathbf{x}}_{1}}\right)$发送${\mathbf{x}}_{0}$

---

Algorithm 4 Receiving

算法4 接收

---

	Receive ${\mathbf{x}}_{T}$ using $p\left( {\mathbf{x}}_{T}\right)$

	使用$p\left( {\mathbf{x}}_{T}\right)$接收${\mathbf{x}}_{T}$

		for $t = T - 1,\ldots ,1,0$ do

		对于$t = T - 1,\ldots ,1,0$执行

											Receive ${\mathbf{x}}_{t}$ using ${p}_{\theta }\left( {{\mathbf{x}}_{t} \mid  {\mathbf{x}}_{t + 1}}\right)$

											使用${p}_{\theta }\left( {{\mathbf{x}}_{t} \mid  {\mathbf{x}}_{t + 1}}\right)$接收${\mathbf{x}}_{t}$

	end for

	结束循环

return ${\mathrm{x}}_{0}$

返回${\mathrm{x}}_{0}$

---

We find that training our models on the true variational bound yields better codelengths than training on the simplified objective, as expected, but the latter yields the best sample quality. See Fig. 1 for CIFAR10 and CelebA-HQ 256 $\times  {256}$ samples, Fig. 3 and Fig. 4 for LSUN 256 $\times  {256}$ samples [71], and Appendix D for more.

我们发现，在真实变分下界(variational bound)上训练模型能获得比简化目标更好的编码长度，正如预期，但后者能产生最佳的样本质量。见图1中CIFAR10和CelebA-HQ 256$\times  {256}$样本，图3和图4中LSUN 256$\times  {256}$样本[71]，更多内容见附录D。

### 4.2 Reverse process parameterization and training objective ablation

### 4.2 逆过程参数化及训练目标消融

In Table 2, we show the sample quality effects of reverse process parameterizations and training objectives (Section 3.2). We find that the baseline option of predicting $\widetilde{\mathbf{\mu }}$ works well only when trained on the true variational bound instead of unweighted mean squared error, a simplified objective akin to Eq. (14). We also see that learning reverse process variances (by incorporating a parameterized diagonal ${\mathbf{\sum }}_{\theta }\left( {\mathbf{x}}_{t}\right)$ into the variational bound) leads to unstable training and poorer sample quality compared to fixed variances. Predicting $\epsilon$ , as we proposed, performs approximately as well as predicting $\widetilde{\mathbf{\mu }}$ when trained on the variational bound with fixed variances, but much better when trained with our simplified objective.

在表2中，我们展示了逆过程参数化和训练目标(第3.2节)对样本质量的影响。我们发现，基线选项预测$\widetilde{\mathbf{\mu }}$仅在基于真实变分下界训练时表现良好，而非未加权均方误差(一种类似于公式(14)的简化目标)。我们还观察到，通过在变分下界中引入参数化对角${\mathbf{\sum }}_{\theta }\left( {\mathbf{x}}_{t}\right)$来学习逆过程方差，会导致训练不稳定且样本质量下降，相较于固定方差。正如我们提出的，预测$\epsilon$在固定方差的变分下界训练中表现与预测$\widetilde{\mathbf{\mu }}$相当，但在简化目标训练时表现更佳。

### 4.3 Progressive coding

### 4.3 逐步编码

Table 1 also shows the codelengths of our CIFAR10 models. The gap between train and test is at most 0.03 bits per dimension, which is comparable to the gaps reported with other likelihood-based models and indicates that our diffusion model is not overfitting (see Appendix D for nearest neighbor visualizations). Still, while our lossless codelengths are better than the large estimates reported for energy based models and score matching using annealed importance sampling [11], they are not competitive with other types of likelihood-based generative models [7].

表1还展示了我们CIFAR10模型的编码长度。训练与测试间的差距最多为每维0.03比特，这与其他基于似然的模型报告的差距相当，表明我们的扩散模型未发生过拟合(见附录D中的最近邻可视化)。尽管如此，虽然我们的无损编码长度优于基于能量模型和使用退火重要性采样的分数匹配[11]的大量估计，但仍不及其他类型的基于似然的生成模型[7]。

Since our samples are nonetheless of high quality, we conclude that diffusion models have an inductive bias that makes them excellent lossy compressors. Treating the variational bound terms ${L}_{1} + \cdots  + {L}_{T}$ as rate and ${L}_{0}$ as distortion, our CIFAR10 model with the highest quality samples has a rate of 1.78 bits/dim and a distortion of 1.97 bits/dim, which amounts to a root mean squared error of 0.95 on a scale from 0 to 255 . More than half of the lossless codelength describes imperceptible distortions.

鉴于我们的样本质量依然很高，我们得出结论:扩散模型具有一种归纳偏置，使其成为优秀的有损压缩器。将变分下界项${L}_{1} + \cdots  + {L}_{T}$视为码率，${L}_{0}$视为失真，我们CIFAR10模型中质量最高的样本码率为1.78比特/维，失真为1.97比特/维，相当于在0到255的尺度上均方根误差为0.95。超过一半的无损编码长度描述的是不可察觉的失真。

Progressive lossy compression We can probe further into the rate-distortion behavior of our model by introducing a progressive lossy code that mirrors the form of Eq. (5): see Algorithms 3 and 4 which assume access to a procedure, such as minimal random coding [19, 20], that can transmit a sample $\mathbf{x} \sim  q\left( \mathbf{x}\right)$ using approximately ${D}_{\mathrm{{KL}}}\left( {q\left( \mathbf{x}\right) \parallel p\left( \mathbf{x}\right) }\right)$ bits on average for any distributions $p$ and $q$ , for which only $p$ is available to the receiver beforehand. When applied to ${\mathbf{x}}_{0} \sim  q\left( {\mathbf{x}}_{0}\right)$ , Algorithms 3 and 4 transmit ${\mathbf{x}}_{T},\ldots ,{\mathbf{x}}_{0}$ in sequence using a total expected codelength equal to Eq. (5). The receiver, at any time $t$ , has the partial information ${\mathbf{x}}_{t}$ fully available and can progressively estimate:

逐步有损压缩 我们可以通过引入一种逐步有损编码进一步探究模型的率失真行为，该编码形式与公式(5)相似:见算法3和4，它们假设可访问一种过程，如最小随机编码[19, 20]，该过程能以平均约${D}_{\mathrm{{KL}}}\left( {q\left( \mathbf{x}\right) \parallel p\left( \mathbf{x}\right) }\right)$比特传输样本$\mathbf{x} \sim  q\left( \mathbf{x}\right)$，针对任意分布$p$和$q$，其中接收方事先仅知$p$。应用于${\mathbf{x}}_{0} \sim  q\left( {\mathbf{x}}_{0}\right)$时，算法3和4按顺序传输${\mathbf{x}}_{T},\ldots ,{\mathbf{x}}_{0}$，总期望编码长度等于公式(5)。接收方在任意时刻$t$，已完全获得部分信息${\mathbf{x}}_{t}$，并能逐步估计:

$$
{\mathbf{x}}_{0} \approx  {\widehat{\mathbf{x}}}_{0} = \left( {{\mathbf{x}}_{t} - \sqrt{1 - {\bar{\alpha }}_{t}}{\mathbf{\epsilon }}_{\theta }\left( {\mathbf{x}}_{t}\right) }\right) /\sqrt{{\bar{\alpha }}_{t}} \tag{15}
$$

due to Eq. (4). (A stochastic reconstruction ${\mathbf{x}}_{0} \sim  {p}_{\theta }\left( {{\mathbf{x}}_{0} \mid  {\mathbf{x}}_{t}}\right)$ is also valid, but we do not consider it here because it makes distortion more difficult to evaluate.) Figure 5 shows the resulting rate-distortion plot on the CIFAR10 test set. At each time $t$ , the distortion is calculated as the root mean squared error $\sqrt{{\begin{Vmatrix}{\mathbf{x}}_{0} - {\widehat{\mathbf{x}}}_{0}\end{Vmatrix}}^{2}/D}$ , and the rate is calculated as the cumulative number of bits received so far at time $t$ . The distortion decreases steeply in the low-rate region of the rate-distortion plot, indicating that the majority of the bits are indeed allocated to imperceptible distortions.

由于公式(4)。(随机重构${\mathbf{x}}_{0} \sim  {p}_{\theta }\left( {{\mathbf{x}}_{0} \mid  {\mathbf{x}}_{t}}\right)$也是有效的，但我们这里不考虑它，因为它使失真更难评估。)图5展示了CIFAR10测试集上的率失真曲线。在每个时间点$t$，失真被计算为均方根误差$\sqrt{{\begin{Vmatrix}{\mathbf{x}}_{0} - {\widehat{\mathbf{x}}}_{0}\end{Vmatrix}}^{2}/D}$，率被计算为截至时间$t$累计接收的比特数。率失真曲线在低率区域失真急剧下降，表明大部分比特确实分配给了不可察觉的失真。

![bo_d1c3pvn7aajc7389qep0_6_313_551_1166_284_0.jpg](images/bo_d1c3pvn7aajc7389qep0_6_313_551_1166_284_0.jpg)

Figure 5: Unconditional CIFAR10 test set rate-distortion vs. time. Distortion is measured in root mean squared error on a $\left\lbrack  {0,{255}}\right\rbrack$ scale. See Table 4 for details.

图5:无条件CIFAR10测试集的率失真随时间变化。失真以均方根误差在$\left\lbrack  {0,{255}}\right\rbrack$尺度上测量。详情见表4。

Progressive generation We also run a progressive unconditional generation process given by progressive decompression from random bits. In other words, we predict the result of the reverse process, ${\widehat{\mathbf{x}}}_{0}$ , while sampling from the reverse process using Algorithm 2 Figures 6 and 10 show the resulting sample quality of ${\widehat{\mathbf{x}}}_{0}$ over the course of the reverse process. Large scale image features appear first and details appear last. Figure 7 shows stochastic predictions ${\mathbf{x}}_{0} \sim  {p}_{\theta }\left( {{\mathbf{x}}_{0} \mid  {\mathbf{x}}_{t}}\right)$ with ${\mathbf{x}}_{t}$ frozen for various $t$ . When $t$ is small, all but fine details are preserved, and when $t$ is large, only large scale features are preserved. Perhaps these are hints of conceptual compression [18].

渐进生成 我们还运行了一个由随机比特渐进解压缩给出的无条件渐进生成过程。换句话说，我们预测逆过程的结果${\widehat{\mathbf{x}}}_{0}$，同时使用算法2从逆过程采样。图6和图10展示了逆过程过程中${\widehat{\mathbf{x}}}_{0}$的样本质量。大尺度图像特征先出现，细节最后出现。图7展示了在不同$t$下冻结${\mathbf{x}}_{t}$的随机预测${\mathbf{x}}_{0} \sim  {p}_{\theta }\left( {{\mathbf{x}}_{0} \mid  {\mathbf{x}}_{t}}\right)$。当$t$较小时，除细节外均被保留；当$t$较大时，仅保留大尺度特征。或许这暗示了概念压缩[18]。

![bo_d1c3pvn7aajc7389qep0_6_362_1195_1071_226_0.jpg](images/bo_d1c3pvn7aajc7389qep0_6_362_1195_1071_226_0.jpg)

Figure 6: Unconditional CIFAR10 progressive generation ( ${\widehat{\mathbf{x}}}_{0}$ over time, from left to right). Extended samples and sample quality metrics over time in the appendix (Figs. 10 and 14).

图6:无条件CIFAR10渐进生成(${\widehat{\mathbf{x}}}_{0}$随时间变化，从左到右)。附录中有扩展样本和样本质量指标(图10和图14)。

![bo_d1c3pvn7aajc7389qep0_6_424_1510_950_219_0.jpg](images/bo_d1c3pvn7aajc7389qep0_6_424_1510_950_219_0.jpg)

Figure 7: When conditioned on the same latent, CelebA-HQ 256 $\times$ 256 samples share high-level attributes Bottom-right quadrants are ${\mathbf{x}}_{t}$ , and other quadrants are samples from ${p}_{\theta }\left( {{\mathbf{x}}_{0} \mid  {\mathbf{x}}_{t}}\right)$ .

图7:在相同潜变量条件下，CelebA-HQ 256 $\times$ 256样本共享高级属性。右下象限为${\mathbf{x}}_{t}$，其他象限为${p}_{\theta }\left( {{\mathbf{x}}_{0} \mid  {\mathbf{x}}_{t}}\right)$的样本。

Connection to autoregressive decoding Note that the variational bound (5) can be rewritten as:

与自回归解码的联系 注意变分下界(5)可以重写为:

$$
L = {D}_{\mathrm{{KL}}}\left( {q\left( {\mathbf{x}}_{T}\right) \parallel p\left( {\mathbf{x}}_{T}\right) }\right)  + {\mathbb{E}}_{q}\left\lbrack  {\mathop{\sum }\limits_{{t \geq  1}}{D}_{\mathrm{{KL}}}\left( {q\left( {{\mathbf{x}}_{t - 1} \mid  {\mathbf{x}}_{t}}\right) \parallel {p}_{\theta }\left( {{\mathbf{x}}_{t - 1} \mid  {\mathbf{x}}_{t}}\right) }\right) }\right\rbrack   + H\left( {\mathbf{x}}_{0}\right)  \tag{16}
$$

(See Appendix A for a derivation.) Now consider setting the diffusion process length $T$ to the dimensionality of the data, defining the forward process so that $q\left( {{\mathbf{x}}_{t} \mid  {\mathbf{x}}_{0}}\right)$ places all probability mass on ${\mathbf{x}}_{0}$ with the first $t$ coordinates masked out (i.e. $q\left( {{\mathbf{x}}_{t} \mid  {\mathbf{x}}_{t - 1}}\right)$ masks out the ${t}^{\text{th }}$ coordinate), setting $p\left( {\mathbf{x}}_{T}\right)$ to place all mass on a blank image, and, for the sake of argument, taking ${p}_{\theta }\left( {{\mathbf{x}}_{t - 1} \mid  {\mathbf{x}}_{t}}\right)$ to be a fully expressive conditional distribution. With these choices, ${D}_{\mathrm{{KL}}}\left( {q\left( {\mathbf{x}}_{T}\right) \parallel p\left( {\mathbf{x}}_{T}\right) }\right)  = 0$ , and minimizing ${D}_{\mathrm{{KL}}}\left( {q\left( {{\mathbf{x}}_{t - 1} \mid  {\mathbf{x}}_{t}}\right) \parallel {p}_{\theta }\left( {{\mathbf{x}}_{t - 1} \mid  {\mathbf{x}}_{t}}\right) }\right)$ trains ${p}_{\theta }$ to copy coordinates $t + 1,\ldots , T$ unchanged and to predict the ${t}^{\text{th }}$ coordinate given $t + 1,\ldots , T$ . Thus, training ${p}_{\theta }$ with this particular diffusion is training an autoregressive model.

(参见附录A中的推导。)现在考虑将扩散过程长度$T$设为数据的维度，定义前向过程使得$q\left( {{\mathbf{x}}_{t} \mid  {\mathbf{x}}_{0}}\right)$将所有概率质量集中在${\mathbf{x}}_{0}$上，且前$t$个坐标被屏蔽(即$q\left( {{\mathbf{x}}_{t} \mid  {\mathbf{x}}_{t - 1}}\right)$屏蔽了第${t}^{\text{th }}$个坐标)，将$p\left( {\mathbf{x}}_{T}\right)$设为将所有质量集中在空白图像上，并且，为了论证，假设${p}_{\theta }\left( {{\mathbf{x}}_{t - 1} \mid  {\mathbf{x}}_{t}}\right)$是一个完全表达的条件分布。基于这些选择，${D}_{\mathrm{{KL}}}\left( {q\left( {\mathbf{x}}_{T}\right) \parallel p\left( {\mathbf{x}}_{T}\right) }\right)  = 0$，最小化${D}_{\mathrm{{KL}}}\left( {q\left( {{\mathbf{x}}_{t - 1} \mid  {\mathbf{x}}_{t}}\right) \parallel {p}_{\theta }\left( {{\mathbf{x}}_{t - 1} \mid  {\mathbf{x}}_{t}}\right) }\right)$训练${p}_{\theta }$以保持坐标$t + 1,\ldots , T$不变并预测给定$t + 1,\ldots , T$的第${t}^{\text{th }}$个坐标。因此，使用这种特定扩散训练${p}_{\theta }$即是在训练一个自回归模型。

![bo_d1c3pvn7aajc7389qep0_7_301_199_1190_238_0.jpg](images/bo_d1c3pvn7aajc7389qep0_7_301_199_1190_238_0.jpg)

Figure 8: Interpolations of CelebA-HQ 256x256 images with 500 timesteps of diffusion.

图8:使用500步扩散对CelebA-HQ 256x256图像进行插值。

We can therefore interpret the Gaussian diffusion model (2) as a kind of autoregressive model with a generalized bit ordering that cannot be expressed by reordering data coordinates. Prior work has shown that such reorderings introduce inductive biases that have an impact on sample quality [38], so we speculate that the Gaussian diffusion serves a similar purpose, perhaps to greater effect since Gaussian noise might be more natural to add to images compared to masking noise. Moreover, the Gaussian diffusion length is not restricted to equal the data dimension; for instance, we use $T = {1000}$ , which is less than the dimension of the ${32} \times  {32} \times  3$ or ${256} \times  {256} \times  3$ images in our experiments. Gaussian diffusions can be made shorter for fast sampling or longer for model expressiveness.

因此，我们可以将高斯扩散模型(2)解释为一种具有广义比特排序的自回归模型，这种排序无法通过重新排列数据坐标来表达。先前的研究表明，这类重新排序会引入对样本质量有影响的归纳偏置[38]，因此我们推测高斯扩散起到了类似的作用，且效果可能更显著，因为与屏蔽噪声相比，高斯噪声更自然地添加到图像中。此外，高斯扩散长度不限于等于数据维度；例如，在我们的实验中，我们使用了$T = {1000}$，它小于${32} \times  {32} \times  3$或${256} \times  {256} \times  3$图像的维度。高斯扩散可以缩短以加快采样速度，也可以加长以增强模型表达能力。

### 4.4 Interpolation

### 4.4 插值

We can interpolate source images ${\mathbf{x}}_{0},{\mathbf{x}}_{0}^{\prime } \sim  q\left( {\mathbf{x}}_{0}\right)$ in latent space using $q$ as a stochastic encoder, ${\mathbf{x}}_{t},{\mathbf{x}}_{t}^{\prime } \sim  q\left( {{\mathbf{x}}_{t} \mid  {\mathbf{x}}_{0}}\right)$ , then decoding the linearly interpolated latent ${\overline{\mathbf{x}}}_{t} = \left( {1 - \lambda }\right) {\mathbf{x}}_{0} + \lambda {\mathbf{x}}_{0}^{\prime }$ into image space by the reverse process, ${\overline{\mathbf{x}}}_{0} \sim  p\left( {{\mathbf{x}}_{0} \mid  {\overline{\mathbf{x}}}_{t}}\right)$ . In effect, we use the reverse process to remove artifacts from linearly interpolating corrupted versions of the source images, as depicted in Fig. 8 (left). We fixed the noise for different values of $\lambda$ so ${\mathbf{x}}_{t}$ and ${\mathbf{x}}_{t}^{\prime }$ remain the same. Fig. 8 (right) shows interpolations and reconstructions of original CelebA-HQ 256 $\times  {256}$ images ( $t = 5\overline{00}$ ). The reverse process produces high-quality reconstructions, and plausible interpolations that smoothly vary attributes such as pose, skin tone, hairstyle, expression and background, but not eyewear. Larger $t$ results in coarser and more varied interpolations, with novel samples at $t = {1000}$ (Appendix Fig. 9)

我们可以使用$q$作为随机编码器，在潜在空间中对源图像${\mathbf{x}}_{0},{\mathbf{x}}_{0}^{\prime } \sim  q\left( {\mathbf{x}}_{0}\right)$进行插值，${\mathbf{x}}_{t},{\mathbf{x}}_{t}^{\prime } \sim  q\left( {{\mathbf{x}}_{t} \mid  {\mathbf{x}}_{0}}\right)$，然后通过反向过程将线性插值的潜在变量${\overline{\mathbf{x}}}_{t} = \left( {1 - \lambda }\right) {\mathbf{x}}_{0} + \lambda {\mathbf{x}}_{0}^{\prime }$解码回图像空间，${\overline{\mathbf{x}}}_{0} \sim  p\left( {{\mathbf{x}}_{0} \mid  {\overline{\mathbf{x}}}_{t}}\right)$。实际上，我们利用反向过程去除线性插值中源图像损坏版本的伪影，如图8(左)所示。我们固定了不同$\lambda$值的噪声，因此${\mathbf{x}}_{t}$和${\mathbf{x}}_{t}^{\prime }$保持不变。图8(右)展示了原始CelebA-HQ 256$\times  {256}$图像($t = 5\overline{00}$)的插值和重建。反向过程生成了高质量的重建图像，以及合理的插值，属性如姿势、肤色、发型、表情和背景平滑变化，但不包括眼镜。较大的$t$导致更粗糙且变化更多的插值，在$t = {1000}$处产生新颖样本(附录图9)。

## 5 Related Work

## 5 相关工作

While diffusion models might resemble flows [9, 46, 10, 32, 5, 16, 23] and VAEs [33, 47, 37], diffusion models are designed so that $q$ has no parameters and the top-level latent ${\mathbf{x}}_{T}$ has nearly zero mutual information with the data ${\mathrm{x}}_{0}$ . Our $\epsilon$ -prediction reverse process parameterization establishes a connection between diffusion models and denoising score matching over multiple noise levels with annealed Langevin dynamics for sampling [55, 56]. Diffusion models, however, admit straightforward log likelihood evaluation, and the training procedure explicitly trains the Langevin dynamics sampler using variational inference (see Appendix C for details). The connection also has the reverse implication that a certain weighted form of denoising score matching is the same as variational inference to train a Langevin-like sampler. Other methods for learning transition operators of Markov chains include infusion training [2], variational walkback [15], generative stochastic networks [1]. and others [50, 54, 36, 42, 35, 65].

虽然扩散模型可能类似于流模型(flows)[9, 46, 10, 32, 5, 16, 23]和变分自编码器(VAEs)[33, 47, 37]，但扩散模型设计使得$q$无参数，且顶层潜变量${\mathbf{x}}_{T}$与数据${\mathrm{x}}_{0}$几乎无互信息。我们的$\epsilon$预测反向过程参数化建立了扩散模型与多噪声水平下的去噪得分匹配(denoising score matching)及退火朗之万动力学(annealed Langevin dynamics)采样之间的联系[55, 56]。然而，扩散模型允许直接的对数似然评估，且训练过程显式地使用变分推断训练朗之万动力学采样器(详见附录C)。该联系的反向含义是，某种加权形式的去噪得分匹配等同于训练朗之万类采样器的变分推断。其他学习马尔可夫链转移算子的方法包括注入训练(infusion training)[2]、变分回退(variational walkback)[15]、生成随机网络(generative stochastic networks)[1]等[50, 54, 36, 42, 35, 65]。

By the known connection between score matching and energy-based modeling, our work could have implications for other recent work on energy-based models [67-69, 12, 70, 13, 11, 41, 17, 8]. Our rate-distortion curves are computed over time in one evaluation of the variational bound, reminiscent of how rate-distortion curves can be computed over distortion penalties in one run of annealed importance sampling [24]. Our progressive decoding argument can be seen in convolutional DRAW and related models [18, 40] and may also lead to more general designs for subscale orderings or sampling strategies for autoregressive models [38, 64].

基于得分匹配与能量模型(energy-based modeling)之间的已知联系，我们的工作可能对近期能量模型相关研究[67-69, 12, 70, 13, 11, 41, 17, 8]产生影响。我们的率失真曲线是在一次变分界限评估中随时间计算的，类似于如何在一次退火重要性采样(annealed importance sampling)运行中基于失真惩罚计算率失真曲线[24]。我们的渐进解码论证可见于卷积DRAW及相关模型[18, 40]，并可能引导更通用的子尺度排序或自回归模型采样策略设计[38, 64]。

## 6 Conclusion

## 6 结论

We have presented high quality image samples using diffusion models, and we have found connections among diffusion models and variational inference for training Markov chains, denoising score matching and annealed Langevin dynamics (and energy-based models by extension), autoregressive models, and progressive lossy compression. Since diffusion models seem to have excellent inductive biases for image data, we look forward to investigating their utility in other data modalities and as components in other types of generative models and machine learning systems.

我们展示了使用扩散模型生成的高质量图像样本，并发现了扩散模型与训练马尔可夫链的变分推断、去噪得分匹配及退火朗之万动力学(及其扩展的能量模型)、自回归模型和渐进有损压缩之间的联系。由于扩散模型对图像数据具有优良的归纳偏置，我们期待探索其在其他数据模态中的应用，以及作为其他类型生成模型和机器学习系统组件的潜力。

## Broader Impact

## 更广泛的影响

Our work on diffusion models takes on a similar scope as existing work on other types of deep generative models, such as efforts to improve the sample quality of GANs, flows, autoregressive models, and so forth. Our paper represents progress in making diffusion models a generally useful tool in this family of techniques, so it may serve to amplify any impacts that generative models have had (and will have) on the broader world.

我们关于扩散模型的工作与现有其他深度生成模型的研究范围相似，如提升GAN、流模型、自回归模型等样本质量的努力。我们的论文代表了使扩散模型成为该技术家族中通用工具的进展，因此可能会放大生成模型对更广泛世界产生的(及将产生的)影响。

Unfortunately, there are numerous well-known malicious uses of generative models. Sample generation techniques can be employed to produce fake images and videos of high profile figures for political purposes. While fake images were manually created long before software tools were available, generative models such as ours make the process easier. Fortunately, CNN-generated images currently have subtle flaws that allow detection [62], but improvements in generative models may make this more difficult. Generative models also reflect the biases in the datasets on which they are trained. As many large datasets are collected from the internet by automated systems, it can be difficult to remove these biases, especially when the images are unlabeled. If samples from generative models trained on these datasets proliferate throughout the internet, then these biases will only be reinforced further.

不幸的是，生成模型存在众多广为人知的恶意用途。样本生成技术可被用来制作政治目的的高知名度人物的假图像和视频。虽然在软件工具出现之前，假图像是手工制作的，但像我们这样的生成模型使这一过程变得更容易。幸运的是，目前卷积神经网络(CNN)生成的图像存在细微缺陷，可以被检测到[62]，但生成模型的改进可能会使检测变得更加困难。生成模型还反映了其训练数据集中的偏见。由于许多大型数据集是通过自动化系统从互联网收集的，尤其是在图像无标签的情况下，去除这些偏见可能非常困难。如果基于这些数据集训练的生成模型样本在互联网上大量传播，那么这些偏见只会被进一步强化。

On the other hand, diffusion models may be useful for data compression, which, as data becomes higher resolution and as global internet traffic increases, might be crucial to ensure accessibility of the internet to wide audiences. Our work might contribute to representation learning on unlabeled raw data for a large range of downstream tasks, from image classification to reinforcement learning, and diffusion models might also become viable for creative uses in art, photography, and music.

另一方面，扩散模型可能对数据压缩有用，随着数据分辨率的提高和全球互联网流量的增加，这可能对确保互联网对广大用户的可访问性至关重要。我们的工作可能有助于对无标签原始数据进行表征学习，支持从图像分类到强化学习的广泛下游任务，扩散模型也可能成为艺术、摄影和音乐等创意领域的可行工具。

## Acknowledgments and Disclosure of Funding

## 致谢与资金披露

This work was supported by ONR PECASE and the NSF Graduate Research Fellowship under grant number DGE-1752814. Google's TensorFlow Research Cloud (TFRC) provided Cloud TPUs. References

本工作得到了美国海军研究办公室PECASE奖和国家科学基金会(NSF)研究生奖学金(资助编号DGE-1752814)的支持。谷歌的TensorFlow研究云(TFRC)提供了云TPU资源。参考文献

[1] Guillaume Alain, Yoshua Bengio, Li Yao, Jason Yosinski, Eric Thibodeau-Laufer, Saizheng Zhang, and Pascal Vincent. GSNs: generative stochastic networks. Information and Inference: A Journal of the IMA, 5(2):210-249, 2016.

[1] Guillaume Alain, Yoshua Bengio, Li Yao, Jason Yosinski, Eric Thibodeau-Laufer, Saizheng Zhang, 和 Pascal Vincent. GSNs: 生成随机网络(generative stochastic networks)。《信息与推断:IMA期刊》，5(2):210-249, 2016。

[2] Florian Bordes, Sina Honari, and Pascal Vincent. Learning to generate samples from noise through infusion training. In International Conference on Learning Representations, 2017.

[2] Florian Bordes, Sina Honari, 和 Pascal Vincent. 通过注入训练学习从噪声生成样本。国际表征学习会议，2017。

[3] Andrew Brock, Jeff Donahue, and Karen Simonyan. Large scale GAN training for high fidelity natural image synthesis. In International Conference on Learning Representations, 2019.

[3] Andrew Brock, Jeff Donahue, 和 Karen Simonyan. 大规模GAN训练用于高保真自然图像合成。国际表征学习会议，2019。

[4] Tong Che, Ruixiang Zhang, Jascha Sohl-Dickstein, Hugo Larochelle, Liam Paull, Yuan Cao, and Yoshua Bengio. Your GAN is secretly an energy-based model and you should use discriminator driven latent sampling. arXiv preprint arXiv:2003.06060, 2020.

[4] Tong Che, Ruixiang Zhang, Jascha Sohl-Dickstein, Hugo Larochelle, Liam Paull, Yuan Cao, 和 Yoshua Bengio. 你的GAN实际上是一个基于能量的模型，应使用判别器驱动的潜变量采样。arXiv预印本 arXiv:2003.06060, 2020。

[5] Tian Qi Chen, Yulia Rubanova, Jesse Bettencourt, and David K Duvenaud. Neural ordinary differential equations. In Advances in Neural Information Processing Systems, pages 6571-6583, 2018.

[5] Tian Qi Chen, Yulia Rubanova, Jesse Bettencourt, 和 David K Duvenaud. 神经常微分方程(Neural ordinary differential equations)。神经信息处理系统进展，页6571-6583, 2018。

[6] Xi Chen, Nikhil Mishra, Mostafa Rohaninejad, and Pieter Abbeel. PixelSNAIL: An improved autoregressive generative model. In International Conference on Machine Learning, pages 863-871, 2018.

[6] Xi Chen, Nikhil Mishra, Mostafa Rohaninejad, 和 Pieter Abbeel. PixelSNAIL: 一种改进的自回归生成模型。国际机器学习会议，页863-871, 2018。

[7] Rewon Child, Scott Gray, Alec Radford, and Ilya Sutskever. Generating long sequences with sparse transformers. arXiv preprint arXiv:1904.10509, 2019.

[7] Rewon Child, Scott Gray, Alec Radford, 和 Ilya Sutskever. 使用稀疏变换器生成长序列。arXiv预印本 arXiv:1904.10509, 2019。

[8] Yuntian Deng, Anton Bakhtin, Myle Ott, Arthur Szlam, and Marc'Aurelio Ranzato. Residual energy-based models for text generation. arXiv preprint arXiv:2004.11714, 2020.

[8] Yuntian Deng, Anton Bakhtin, Myle Ott, Arthur Szlam, 和 Marc'Aurelio Ranzato. 用于文本生成的残差能量模型。arXiv预印本 arXiv:2004.11714, 2020。

[9] Laurent Dinh, David Krueger, and Yoshua Bengio. NICE: Non-linear independent components estimation. arXiv preprint arXiv:1410.8516, 2014.

[9] Laurent Dinh, David Krueger, 和 Yoshua Bengio. NICE: 非线性独立成分估计。arXiv预印本 arXiv:1410.8516, 2014。

[10] Laurent Dinh, Jascha Sohl-Dickstein, and Samy Bengio. Density estimation using Real NVP. arXiv preprint arXiv:1605.08803, 2016.

[10] Laurent Dinh, Jascha Sohl-Dickstein, 和 Samy Bengio. 使用Real NVP进行密度估计。arXiv预印本 arXiv:1605.08803, 2016。

[11] Yilun Du and Igor Mordatch. Implicit generation and modeling with energy based models. In Advances in Neural Information Processing Systems, pages 3603-3613, 2019.

[11] Yilun Du 和 Igor Mordatch. 基于能量模型的隐式生成与建模。神经信息处理系统进展，页3603-3613, 2019。

[12] Ruiqi Gao, Yang Lu, Junpei Zhou, Song-Chun Zhu, and Ying Nian Wu. Learning generative ConvNets via multi-grid modeling and sampling. In Proceedings of the IEEE Conference on Computer Vision and Pattern Recognition, pages 9155-9164, 2018.

[12] Ruiqi Gao, Yang Lu, Junpei Zhou, Song-Chun Zhu, 和 Ying Nian Wu. 通过多网格建模与采样学习生成卷积网络。IEEE计算机视觉与模式识别会议论文集，页9155-9164, 2018。

[13] Ruiqi Gao, Erik Nijkamp, Diederik P Kingma, Zhen Xu, Andrew M Dai, and Ying Nian Wu. Flow contrastive estimation of energy-based models. In Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition, pages 7518-7528, 2020.

[13] 高睿琦, Erik Nijkamp, Diederik P Kingma, 许震, Andrew M Dai, 和吴英年. 基于流的能量模型对比估计. 载于IEEE/CVF计算机视觉与模式识别会议论文集, 页7518-7528, 2020.

[14] Ian Goodfellow, Jean Pouget-Abadie, Mehdi Mirza, Bing Xu, David Warde-Farley, Sherjil Ozair, Aaron Courville, and Yoshua Bengio. Generative adversarial nets. In Advances in Neural Information Processing Systems, pages 2672-2680, 2014.

[14] Ian Goodfellow, Jean Pouget-Abadie, Mehdi Mirza, Bing Xu, David Warde-Farley, Sherjil Ozair, Aaron Courville, 和Yoshua Bengio. 生成对抗网络. 载于神经信息处理系统进展, 页2672-2680, 2014.

[15] Anirudh Goyal, Nan Rosemary Ke, Surya Ganguli, and Yoshua Bengio. Variational walkback: Learning a transition operator as a stochastic recurrent net. In Advances in Neural Information Processing Systems, pages 4392-4402, 2017.

[15] Anirudh Goyal, Nan Rosemary Ke, Surya Ganguli, 和Yoshua Bengio. 变分回溯:作为随机递归网络学习转移算子. 载于神经信息处理系统进展, 页4392-4402, 2017.

[16] Will Grathwohl, Ricky T. Q. Chen, Jesse Bettencourt, and David Duvenaud. FFJORD: Free-form continuous dynamics for scalable reversible generative models. In International Conference on Learning Representations, 2019.

[16] Will Grathwohl, Ricky T. Q. Chen, Jesse Bettencourt, 和David Duvenaud. FFJORD:用于可扩展可逆生成模型的自由形式连续动力学. 载于国际表征学习会议, 2019.

[17] Will Grathwohl, Kuan-Chieh Wang, Joern-Henrik Jacobsen, David Duvenaud, Mohammad Norouzi, and Kevin Swersky. Your classifier is secretly an energy based model and you should treat it like one. In International Conference on Learning Representations, 2020.

[17] Will Grathwohl, Kuan-Chieh Wang, Joern-Henrik Jacobsen, David Duvenaud, Mohammad Norouzi, 和Kevin Swersky. 你的分类器实际上是一个能量模型，你应该这样对待它. 载于国际表征学习会议, 2020.

[18] Karol Gregor, Frederic Besse, Danilo Jimenez Rezende, Ivo Danihelka, and Daan Wierstra. Towards conceptual compression. In Advances In Neural Information Processing Systems, pages 3549-3557, 2016.

[18] Karol Gregor, Frederic Besse, Danilo Jimenez Rezende, Ivo Danihelka, 和Daan Wierstra. 迈向概念压缩. 载于神经信息处理系统进展, 页3549-3557, 2016.

[19] Prahladh Harsha, Rahul Jain, David McAllester, and Jaikumar Radhakrishnan. The communication complexity of correlation. In Twenty-Second Annual IEEE Conference on Computational Complexity (CCC'07), pages 10-23. IEEE, 2007.

[19] Prahladh Harsha, Rahul Jain, David McAllester, 和Jaikumar Radhakrishnan. 相关性的通信复杂度. 载于第二十二届IEEE计算复杂性年会(CCC'07), 页10-23. IEEE, 2007.

[20] Marton Havasi, Robert Peharz, and José Miguel Hernández-Lobato. Minimal random code learning: Getting bits back from compressed model parameters. In International Conference on Learning Representations, 2019.

[20] Marton Havasi, Robert Peharz, 和José Miguel Hernández-Lobato. 最小随机编码学习:从压缩模型参数中恢复比特. 载于国际表征学习会议, 2019.

[21] Martin Heusel, Hubert Ramsauer, Thomas Unterthiner, Bernhard Nessler, and Sepp Hochreiter. GANs trained by a two time-scale update rule converge to a local Nash equilibrium. In Advances in Neural Information Processing Systems, pages 6626-6637, 2017.

[21] Martin Heusel, Hubert Ramsauer, Thomas Unterthiner, Bernhard Nessler, 和Sepp Hochreiter. 通过双时间尺度更新规则训练的GAN收敛到局部纳什均衡. 载于神经信息处理系统进展, 页6626-6637, 2017.

[22] Irina Higgins, Loic Matthey, Arka Pal, Christopher Burgess, Xavier Glorot, Matthew Botvinick, Shakir Mohamed, and Alexander Lerchner. beta-VAE: Learning basic visual concepts with a constrained variational framework. In International Conference on Learning Representations, 2017.

[22] Irina Higgins, Loic Matthey, Arka Pal, Christopher Burgess, Xavier Glorot, Matthew Botvinick, Shakir Mohamed, 和Alexander Lerchner. beta-VAE:通过受限变分框架学习基本视觉概念. 载于国际表征学习会议, 2017.

[23] Jonathan Ho, Xi Chen, Aravind Srinivas, Yan Duan, and Pieter Abbeel. Flow++: Improving flow-based generative models with variational dequantization and architecture design. In International Conference on Machine Learning, 2019.

[23] Jonathan Ho, Xi Chen, Aravind Srinivas, Yan Duan, 和Pieter Abbeel. Flow++:通过变分去量化和架构设计改进基于流的生成模型. 载于国际机器学习会议, 2019.

[24] Sicong Huang, Alireza Makhzani, Yanshuai Cao, and Roger Grosse. Evaluating lossy compression rates of deep generative models. In International Conference on Machine Learning, 2020.

[24] Sicong Huang, Alireza Makhzani, Yanshuai Cao, 和Roger Grosse. 评估深度生成模型的有损压缩率. 载于国际机器学习会议, 2020.

[25] Nal Kalchbrenner, Aaron van den Oord, Karen Simonyan, Ivo Danihelka, Oriol Vinyals, Alex Graves, and Koray Kavukcuoglu. Video pixel networks. In International Conference on Machine Learning, pages 1771-1779, 2017.

[25] Nal Kalchbrenner, Aaron van den Oord, Karen Simonyan, Ivo Danihelka, Oriol Vinyals, Alex Graves, 和Koray Kavukcuoglu. 视频像素网络. 载于国际机器学习会议, 页1771-1779, 2017.

[26] Nal Kalchbrenner, Erich Elsen, Karen Simonyan, Seb Noury, Norman Casagrande, Edward Lockhart, Florian Stimberg, Aaron van den Oord, Sander Dieleman, and Koray Kavukcuoglu. Efficient neural audio synthesis. In International Conference on Machine Learning, pages 2410-2419, 2018.

[26] Nal Kalchbrenner, Erich Elsen, Karen Simonyan, Seb Noury, Norman Casagrande, Edward Lockhart, Florian Stimberg, Aaron van den Oord, Sander Dieleman, 和Koray Kavukcuoglu. 高效神经音频合成. 载于国际机器学习会议, 页2410-2419, 2018.

[27] Tero Karras, Timo Aila, Samuli Laine, and Jaakko Lehtinen. Progressive growing of GANs for improved quality, stability, and variation. In International Conference on Learning Representations, 2018.

[27] Tero Karras, Timo Aila, Samuli Laine, 和Jaakko Lehtinen. 逐步增长的GAN以提升质量、稳定性和多样性. 载于国际表征学习会议, 2018.

[28] Tero Karras, Samuli Laine, and Timo Aila. A style-based generator architecture for generative adversarial networks. In Proceedings of the IEEE Conference on Computer Vision and Pattern Recognition, pages 4401-4410, 2019.

[28] Tero Karras, Samuli Laine, 和Timo Aila. 基于风格的生成对抗网络生成器架构. 载于IEEE计算机视觉与模式识别会议论文集, 页4401-4410, 2019.

[29] Tero Karras, Miika Aittala, Janne Hellsten, Samuli Laine, Jaakko Lehtinen, and Timo Aila. Training generative adversarial networks with limited data. arXiv preprint arXiv:2006.06676v1, 2020.

[29] Tero Karras, Miika Aittala, Janne Hellsten, Samuli Laine, Jaakko Lehtinen, 和 Timo Aila. 使用有限数据训练生成对抗网络(GAN)。arXiv预印本 arXiv:2006.06676v1, 2020。

[30] Tero Karras, Samuli Laine, Miika Aittala, Janne Hellsten, Jaakko Lehtinen, and Timo Aila. Analyzing and improving the image quality of StyleGAN. In Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition, pages 8110-8119, 2020.

[30] Tero Karras, Samuli Laine, Miika Aittala, Janne Hellsten, Jaakko Lehtinen, 和 Timo Aila. StyleGAN图像质量的分析与改进。载于IEEE/CVF计算机视觉与模式识别会议论文集，页8110-8119，2020。

[31] Diederik P Kingma and Jimmy Ba. Adam: A method for stochastic optimization. In International Conference on Learning Representations, 2015.

[31] Diederik P Kingma 和 Jimmy Ba. Adam:一种随机优化方法。载于国际学习表征会议，2015。

[32] Diederik P Kingma and Prafulla Dhariwal. Glow: Generative flow with invertible 1x1 convolutions. In Advances in Neural Information Processing Systems, pages 10215-10224, 2018.

[32] Diederik P Kingma 和 Prafulla Dhariwal. Glow:具有可逆1x1卷积的生成流。载于神经信息处理系统进展，页10215-10224，2018。

[33] Diederik P Kingma and Max Welling. Auto-encoding variational Bayes. arXiv preprint arXiv:1312.6114, 2013.

[33] Diederik P Kingma 和 Max Welling. 自编码变分贝叶斯(Auto-encoding variational Bayes)。arXiv预印本 arXiv:1312.6114, 2013。

[34] Diederik P Kingma, Tim Salimans, Rafal Jozefowicz, Xi Chen, Ilya Sutskever, and Max Welling. Improved variational inference with inverse autoregressive flow. In Advances in Neural Information Processing Systems, pages 4743-4751, 2016.

[34] Diederik P Kingma, Tim Salimans, Rafal Jozefowicz, Xi Chen, Ilya Sutskever, 和 Max Welling. 通过逆自回归流改进变分推断。载于神经信息处理系统进展，页4743-4751，2016。

[35] John Lawson, George Tucker, Bo Dai, and Rajesh Ranganath. Energy-inspired models: Learning with sampler-induced distributions. In Advances in Neural Information Processing Systems, pages 8501-8513, 2019.

[35] John Lawson, George Tucker, Bo Dai, 和 Rajesh Ranganath. 能量启发模型:基于采样器诱导分布的学习。载于神经信息处理系统进展，页8501-8513，2019。

[36] Daniel Levy, Matt D. Hoffman, and Jascha Sohl-Dickstein. Generalizing Hamiltonian Monte Carlo with neural networks. In International Conference on Learning Representations, 2018.

[36] Daniel Levy, Matt D. Hoffman, 和 Jascha Sohl-Dickstein. 用神经网络推广哈密顿蒙特卡洛(Hamiltonian Monte Carlo)。载于国际学习表征会议，2018。

[37] Lars Maaløe, Marco Fraccaro, Valentin Liévin, and Ole Winther. BIVA: A very deep hierarchy of latent variables for generative modeling. In Advances in Neural Information Processing Systems, pages 6548-6558, 2019.

[37] Lars Maaløe, Marco Fraccaro, Valentin Liévin, 和 Ole Winther. BIVA:用于生成建模的极深层次潜变量层次结构。载于神经信息处理系统进展，页6548-6558，2019。

[38] Jacob Menick and Nal Kalchbrenner. Generating high fidelity images with subscale pixel networks and multidimensional upscaling. In International Conference on Learning Representations, 2019.

[38] Jacob Menick 和 Nal Kalchbrenner. 使用子尺度像素网络和多维上采样生成高保真图像。载于国际学习表征会议，2019。

[39] Takeru Miyato, Toshiki Kataoka, Masanori Koyama, and Yuichi Yoshida. Spectral normalization for generative adversarial networks. In International Conference on Learning Representations, 2018.

[39] Takeru Miyato, Toshiki Kataoka, Masanori Koyama, 和 Yuichi Yoshida. 生成对抗网络的谱归一化。载于国际学习表征会议，2018。

[40] Alex Nichol. VQ-DRAW: A sequential discrete VAE. arXiv preprint arXiv:2003.01599, 2020.

[40] Alex Nichol. VQ-DRAW:一种序列离散变分自编码器(VAE)。arXiv预印本 arXiv:2003.01599, 2020。

[41] Erik Nijkamp, Mitch Hill, Tian Han, Song-Chun Zhu, and Ying Nian Wu. On the anatomy of MCMC-based maximum likelihood learning of energy-based models. arXiv preprint arXiv:1903.12370, 2019.

[41] Erik Nijkamp, Mitch Hill, Tian Han, Song-Chun Zhu, 和 Ying Nian Wu. 基于马尔可夫链蒙特卡洛(MCMC)的能量模型最大似然学习的结构分析。arXiv预印本 arXiv:1903.12370, 2019。

[42] Erik Nijkamp, Mitch Hill, Song-Chun Zhu, and Ying Nian Wu. Learning non-convergent non-persistent short-run MCMC toward energy-based model. In Advances in Neural Information Processing Systems, pages 5233-5243, 2019.

[42] Erik Nijkamp, Mitch Hill, Song-Chun Zhu, 和 Ying Nian Wu. 面向能量模型的非收敛非持久短程MCMC学习。载于神经信息处理系统进展，页5233-5243，2019。

[43] Georg Ostrovski, Will Dabney, and Remi Munos. Autoregressive quantile networks for generative modeling. In International Conference on Machine Learning, pages 3936-3945, 2018.

[43] Georg Ostrovski, Will Dabney, 和 Remi Munos. 用于生成建模的自回归分位数网络。载于国际机器学习会议，页3936-3945，2018。

[44] Ryan Prenger, Rafael Valle, and Bryan Catanzaro. WaveGlow: A flow-based generative network for speech synthesis. In ICASSP 2019-2019 IEEE International Conference on Acoustics, Speech and Signal Processing (ICASSP), pages 3617-3621. IEEE, 2019.

[44] Ryan Prenger, Rafael Valle, 和 Bryan Catanzaro. WaveGlow:一种基于流的语音合成生成网络。载于ICASSP 2019-2019 IEEE国际声学、语音与信号处理会议，页3617-3621。IEEE, 2019。

[45] Ali Razavi, Aaron van den Oord, and Oriol Vinyals. Generating diverse high-fidelity images with VQ-VAE-2. In Advances in Neural Information Processing Systems, pages 14837-14847, 2019.

[45] Ali Razavi, Aaron van den Oord, 和 Oriol Vinyals. 使用 VQ-VAE-2 生成多样化高保真图像。发表于《神经信息处理系统进展》(Advances in Neural Information Processing Systems), 第14837-14847页, 2019年。

[46] Danilo Rezende and Shakir Mohamed. Variational inference with normalizing flows. In International Conference on Machine Learning, pages 1530-1538, 2015.

[46] Danilo Rezende 和 Shakir Mohamed. 基于归一化流的变分推断。发表于国际机器学习大会(International Conference on Machine Learning), 第1530-1538页, 2015年。

[47] Danilo Jimenez Rezende, Shakir Mohamed, and Daan Wierstra. Stochastic backpropagation and approximate inference in deep generative models. In International Conference on Machine Learning, pages 1278-1286, 2014.

[47] Danilo Jimenez Rezende, Shakir Mohamed, 和 Daan Wierstra. 深度生成模型中的随机反向传播与近似推断。发表于国际机器学习大会，页码1278-1286，2014年。

[48] Olaf Ronneberger, Philipp Fischer, and Thomas Brox. U-Net: Convolutional networks for biomedical image segmentation. In International Conference on Medical Image Computing and Computer-Assisted Intervention, pages 234-241. Springer, 2015.

[48] Olaf Ronneberger, Philipp Fischer, 和 Thomas Brox. U-Net:用于生物医学图像分割的卷积网络。发表于国际医学图像计算与计算机辅助干预会议，页码234-241。Springer出版社，2015年。

[49] Tim Salimans and Durk P Kingma. Weight normalization: A simple reparameterization to accelerate training of deep neural networks. In Advances in Neural Information Processing Systems, pages 901-909, 2016.

[49] Tim Salimans 和 Durk P Kingma. 权重归一化:一种加速深度神经网络训练的简单重参数化方法。发表于神经信息处理系统进展，页码901-909，2016年。

[50] Tim Salimans, Diederik Kingma, and Max Welling. Markov Chain Monte Carlo and variational inference: Bridging the gap. In International Conference on Machine Learning, pages 1218-1226, 2015.

[50] Tim Salimans, Diederik Kingma, 和 Max Welling. 马尔可夫链蒙特卡洛与变分推断:弥合差距。发表于国际机器学习大会，页码1218-1226，2015年。

[51] Tim Salimans, Ian Goodfellow, Wojciech Zaremba, Vicki Cheung, Alec Radford, and Xi Chen. Improved techniques for training gans. In Advances in Neural Information Processing Systems, pages 2234-2242, 2016.

[51] Tim Salimans, Ian Goodfellow, Wojciech Zaremba, Vicki Cheung, Alec Radford, 和 Xi Chen. 改进的生成对抗网络(GANs)训练技术。发表于神经信息处理系统进展，页码2234-2242，2016年。

[52] Tim Salimans, Andrej Karpathy, Xi Chen, and Diederik P Kingma. PixelCNN++: Improving the PixelCNN with discretized logistic mixture likelihood and other modifications. In International Conference on Learning Representations, 2017.

[52] Tim Salimans, Andrej Karpathy, Xi Chen, 和 Diederik P Kingma. PixelCNN++:通过离散化逻辑混合似然及其他改进提升PixelCNN。发表于国际表征学习会议，2017年。

[53] Jascha Sohl-Dickstein, Eric Weiss, Niru Maheswaranathan, and Surya Ganguli. Deep unsupervised learning using nonequilibrium thermodynamics. In International Conference on Machine Learning, pages 2256-2265, 2015.

[53] Jascha Sohl-Dickstein, Eric Weiss, Niru Maheswaranathan, 和 Surya Ganguli. 利用非平衡热力学的深度无监督学习。发表于国际机器学习大会，页码2256-2265，2015年。

[54] Jiaming Song, Shengjia Zhao, and Stefano Ermon. A-NICE-MC: Adversarial training for MCMC. In Advances in Neural Information Processing Systems, pages 5140-5150, 2017.

[54] Jiaming Song, Shengjia Zhao, 和 Stefano Ermon. A-NICE-MC:用于马尔可夫链蒙特卡洛(MCMC)的对抗训练。发表于神经信息处理系统进展，页码5140-5150，2017年。

[55] Yang Song and Stefano Ermon. Generative modeling by estimating gradients of the data distribution. In Advances in Neural Information Processing Systems, pages 11895-11907, 2019.

[55] Yang Song 和 Stefano Ermon. 通过估计数据分布梯度进行生成建模。发表于神经信息处理系统进展，页码11895-11907，2019年。

[56] Yang Song and Stefano Ermon. Improved techniques for training score-based generative models. arXiv preprint arXiv:2006.09011, 2020.

[56] Yang Song 和 Stefano Ermon. 改进的基于得分的生成模型训练技术。arXiv预印本 arXiv:2006.09011，2020年。

[57] Aaron van den Oord, Sander Dieleman, Heiga Zen, Karen Simonyan, Oriol Vinyals, Alex Graves, Nal Kalchbrenner, Andrew Senior, and Koray Kavukcuoglu. WaveNet: A generative model for raw audio. arXiv preprint arXiv:1609.03499, 2016.

[57] Aaron van den Oord, Sander Dieleman, Heiga Zen, Karen Simonyan, Oriol Vinyals, Alex Graves, Nal Kalchbrenner, Andrew Senior, 和 Koray Kavukcuoglu. WaveNet:一种原始音频生成模型。arXiv预印本 arXiv:1609.03499，2016年。

[58] Aaron van den Oord, Nal Kalchbrenner, and Koray Kavukcuoglu. Pixel recurrent neural networks. International Conference on Machine Learning, 2016.

[58] Aaron van den Oord, Nal Kalchbrenner, 和 Koray Kavukcuoglu. Pixel递归神经网络。国际机器学习大会，2016年。

[59] Aaron van den Oord, Nal Kalchbrenner, Oriol Vinyals, Lasse Espeholt, Alex Graves, and Koray Kavukcuoglu. Conditional image generation with PixelCNN decoders. In Advances in Neural Information Processing Systems, pages 4790-4798, 2016.

[59] Aaron van den Oord, Nal Kalchbrenner, Oriol Vinyals, Lasse Espeholt, Alex Graves, 和 Koray Kavukcuoglu. 使用PixelCNN解码器的条件图像生成。发表于神经信息处理系统进展，页码4790-4798，2016年。

[60] Ashish Vaswani, Noam Shazeer, Niki Parmar, Jakob Uszkoreit, Llion Jones, Aidan N Gomez, Łukasz Kaiser, and Illia Polosukhin. Attention is all you need. In Advances in Neural Information Processing Systems, pages 5998-6008, 2017.

[60] Ashish Vaswani, Noam Shazeer, Niki Parmar, Jakob Uszkoreit, Llion Jones, Aidan N Gomez, Łukasz Kaiser, 和 Illia Polosukhin. 注意力机制即一切。发表于神经信息处理系统进展，页码5998-6008，2017年。

[61] Pascal Vincent. A connection between score matching and denoising autoencoders. Neural Computation, 23(7):1661-1674, 2011.

[61] Pascal Vincent. 得分匹配与去噪自编码器之间的联系。神经计算，23(7):1661-1674，2011年。

[62] Sheng-Yu Wang, Oliver Wang, Richard Zhang, Andrew Owens, and Alexei A Efros. Cnn-generated images are surprisingly easy to spot...for now. In Proceedings of the IEEE Conference on Computer Vision and Pattern Recognition, 2020.

[62] Sheng-Yu Wang, Oliver Wang, Richard Zhang, Andrew Owens, 和 Alexei A Efros. CNN生成的图像目前仍然很容易被识别。发表于IEEE计算机视觉与模式识别会议论文集，2020年。

[63] Xiaolong Wang, Ross Girshick, Abhinav Gupta, and Kaiming He. Non-local neural networks. In Proceedings of the IEEE Conference on Computer Vision and Pattern Recognition, pages 7794-7803, 2018.

[63] Xiaolong Wang, Ross Girshick, Abhinav Gupta, 和 Kaiming He. 非局部神经网络(Non-local neural networks)。发表于IEEE计算机视觉与模式识别会议论文集，页码7794-7803，2018年。

[64] Auke J Wiggers and Emiel Hoogeboom. Predictive sampling with forecasting autoregressive models. arXiv preprint arXiv:2002.09928, 2020.

[64] Auke J Wiggers 和 Emiel Hoogeboom. 使用预测自回归模型的预测采样。arXiv预印本 arXiv:2002.09928，2020年。

[65] Hao Wu, Jonas Köhler, and Frank Noé. Stochastic normalizing flows. arXiv preprint arXiv:2002.06707, 2020.

[65] Hao Wu, Jonas Köhler, 和 Frank Noé. 随机归一化流(Stochastic normalizing flows)。arXiv预印本 arXiv:2002.06707，2020年。

[66] Yuxin Wu and Kaiming He. Group normalization. In Proceedings of the European Conference on Computer Vision (ECCV), pages 3-19, 2018.

[66] Yuxin Wu 和 Kaiming He. 组归一化(Group normalization)。发表于欧洲计算机视觉会议(ECCV)论文集，页码3-19，2018年。

[67] Jianwen Xie, Yang Lu, Song-Chun Zhu, and Yingnian Wu. A theory of generative convnet. In International Conference on Machine Learning, pages 2635-2644, 2016.

[67] Jianwen Xie, Yang Lu, Song-Chun Zhu, 和 Yingnian Wu. 生成卷积网络理论。发表于国际机器学习会议论文集，页码2635-2644，2016年。

[68] Jianwen Xie, Song-Chun Zhu, and Ying Nian Wu. Synthesizing dynamic patterns by spatial-temporal generative convnet. In Proceedings of the IEEE Conference on Computer Vision and Pattern Recognition, pages 7093-7101, 2017.

[68] Jianwen Xie, Song-Chun Zhu, 和 Ying Nian Wu. 通过时空生成卷积网络合成动态模式。发表于IEEE计算机视觉与模式识别会议论文集，页码7093-7101，2017年。

[69] Jianwen Xie, Zilong Zheng, Ruiqi Gao, Wenguan Wang, Song-Chun Zhu, and Ying Nian Wu. Learning descriptor networks for $3\mathrm{\;d}$ shape synthesis and analysis. In Proceedings of the IEEE Conference on Computer Vision and Pattern Recognition, pages 8629-8638, 2018.

[69] Jianwen Xie, Zilong Zheng, Ruiqi Gao, Wenguan Wang, Song-Chun Zhu, 和 Ying Nian Wu. 学习描述符网络用于$3\mathrm{\;d}$形状合成与分析。发表于IEEE计算机视觉与模式识别会议论文集，页码8629-8638，2018年。

[70] Jianwen Xie, Song-Chun Zhu, and Ying Nian Wu. Learning energy-based spatial-temporal generative convnets for dynamic patterns. IEEE Transactions on Pattern Analysis and Machine Intelligence, 2019.

[70] Jianwen Xie, Song-Chun Zhu, 和 Ying Nian Wu. 学习基于能量的时空生成卷积网络用于动态模式。IEEE模式分析与机器智能汇刊，2019年。

[71] Fisher Yu, Yinda Zhang, Shuran Song, Ari Seff, and Jianxiong Xiao. LSUN: Construction of a large-scale image dataset using deep learning with humans in the loop. arXiv preprint arXiv:1506.03365, 2015.

[71] Fisher Yu, Yinda Zhang, Shuran Song, Ari Seff, 和 Jianxiong Xiao. LSUN:利用深度学习与人类参与构建大规模图像数据集。arXiv预印本 arXiv:1506.03365，2015年。

[72] Sergey Zagoruyko and Nikos Komodakis. Wide residual networks. arXiv preprint arXiv:1605.07146, 2016.

[72] Sergey Zagoruyko 和 Nikos Komodakis. 宽残差网络(Wide residual networks)。arXiv预印本 arXiv:1605.07146，2016年。

## Extra information

## 额外信息

LSUN FID scores for LSUN datasets are included in Table 3 Scores marked with * are reported by StyleGAN2 as baselines, and other scores are reported by their respective authors.

LSUN数据集的FID分数见表3。带*号的分数由StyleGAN2报告作为基线，其他分数由各自作者报告。

Table 3: FID scores for LSUN 256 X 256 datasets

表3:LSUN 256 X 256数据集的FID分数

<table><tr><td>Model</td><td>LSUN Bedroom</td><td>LSUN Church</td><td>LSUN Cat</td></tr><tr><td>ProgressiveGAN [27]</td><td>8.34</td><td>6.42</td><td>37.52</td></tr><tr><td>StyleGAN [28]</td><td>2.65</td><td>4.21*</td><td>${8.53}^{ * }$</td></tr><tr><td>StyleGAN2 [30]</td><td>-</td><td>3.86</td><td>6.93</td></tr><tr><td>Ours ( ${L}_{\text{simple }}$ )</td><td>6.36</td><td>7.89</td><td>19.75</td></tr><tr><td>Ours ( ${L}_{\text{simple }}$ , large)</td><td>4.90</td><td>-</td><td>-</td></tr></table>

<table><tbody><tr><td>模型</td><td>LSUN 卧室</td><td>LSUN 教堂</td><td>LSUN 猫</td></tr><tr><td>ProgressiveGAN [27]</td><td>8.34</td><td>6.42</td><td>37.52</td></tr><tr><td>StyleGAN [28]</td><td>2.65</td><td>4.21*</td><td>${8.53}^{ * }$</td></tr><tr><td>StyleGAN2 [30]</td><td>-</td><td>3.86</td><td>6.93</td></tr><tr><td>本方法 ( ${L}_{\text{simple }}$ )</td><td>6.36</td><td>7.89</td><td>19.75</td></tr><tr><td>本方法 ( ${L}_{\text{simple }}$ ，大规模)</td><td>4.90</td><td>-</td><td>-</td></tr></tbody></table>

Progressive compression Our lossy compression argument in Section 4.3 is only a proof of concept, because Algorithms 3 and 4 depend on a procedure such as minimal random coding [20], which is not tractable for high dimensional data. These algorithms serve as a compression interpretation of the variational bound (5) of Sohl-Dickstein et al. [53], not yet as a practical compression system.

渐进式压缩 我们在第4.3节中提出的有损压缩论证仅为概念验证，因为算法3和算法4依赖于诸如最小随机编码(minimal random coding)[20]之类的过程，该过程对于高维数据不可行。这些算法作为Sohl-Dickstein等人[53]变分界(variational bound)(公式(5))的压缩解释，而非实用的压缩系统。

Table 4: Unconditional CIFAR10 test set rate-distortion values (accompanies Fig. 5)

表4:无条件CIFAR10测试集的率失真值(对应图5)

<table><tr><td>Reverse process time $\left( {T - t + 1}\right)$</td><td>Rate (bits/dim)</td><td>Distortion (RMSE $\left\lbrack  {0,{255}}\right\rbrack$ )</td></tr><tr><td>1000</td><td>1.77581</td><td>0.95136</td></tr><tr><td>900</td><td>0.11994</td><td>12.02277</td></tr><tr><td>800</td><td>0.05415</td><td>18.47482</td></tr><tr><td>700</td><td>0.02866</td><td>24.43656</td></tr><tr><td>600</td><td>0.01507</td><td>30.80948</td></tr><tr><td>500</td><td>0.00716</td><td>38.03236</td></tr><tr><td>400</td><td>0.00282</td><td>46.12765</td></tr><tr><td>300</td><td>0.00081</td><td>54.18826</td></tr><tr><td>200</td><td>0.00013</td><td>60.97170</td></tr><tr><td>100</td><td>0.00000</td><td>67.60125</td></tr></table>

<table><tbody><tr><td>逆过程时间 $\left( {T - t + 1}\right)$</td><td>码率(比特/维度)</td><td>失真(均方根误差(RMSE) $\left\lbrack  {0,{255}}\right\rbrack$ )</td></tr><tr><td>1000</td><td>1.77581</td><td>0.95136</td></tr><tr><td>900</td><td>0.11994</td><td>12.02277</td></tr><tr><td>800</td><td>0.05415</td><td>18.47482</td></tr><tr><td>700</td><td>0.02866</td><td>24.43656</td></tr><tr><td>600</td><td>0.01507</td><td>30.80948</td></tr><tr><td>500</td><td>0.00716</td><td>38.03236</td></tr><tr><td>400</td><td>0.00282</td><td>46.12765</td></tr><tr><td>300</td><td>0.00081</td><td>54.18826</td></tr><tr><td>200</td><td>0.00013</td><td>60.97170</td></tr><tr><td>100</td><td>0.00000</td><td>67.60125</td></tr></tbody></table>

## A Extended derivations

## A 扩展推导

Below is a derivation of Eq. (5), the reduced variance variational bound for diffusion models. This material is from Sohl-Dickstein et al. [53]; we include it here only for completeness.

以下是方程(5)的推导，即扩散模型的降方差变分界限。该内容来自Sohl-Dickstein等人[53]；我们在此仅为完整性而收录。

$$
L = {\mathbb{E}}_{q}\left\lbrack  {-\log \frac{{p}_{\theta }\left( {\mathbf{x}}_{0 : T}\right) }{q\left( {{\mathbf{x}}_{1 : T} \mid  {\mathbf{x}}_{0}}\right) }}\right\rbrack   \tag{17}
$$

$$
= {\mathbb{E}}_{q}\left\lbrack  {-\log p\left( {\mathbf{x}}_{T}\right)  - \mathop{\sum }\limits_{{t \geq  1}}\log \frac{{p}_{\theta }\left( {{\mathbf{x}}_{t - 1} \mid  {\mathbf{x}}_{t}}\right) }{q\left( {{\mathbf{x}}_{t} \mid  {\mathbf{x}}_{t - 1}}\right) }}\right\rbrack   \tag{18}
$$

$$
= {\mathbb{E}}_{q}\left\lbrack  {-\log p\left( {\mathbf{x}}_{T}\right)  - \mathop{\sum }\limits_{{t > 1}}\log \frac{{p}_{\theta }\left( {{\mathbf{x}}_{t - 1} \mid  {\mathbf{x}}_{t}}\right) }{q\left( {{\mathbf{x}}_{t} \mid  {\mathbf{x}}_{t - 1}}\right) } - \log \frac{{p}_{\theta }\left( {{\mathbf{x}}_{0} \mid  {\mathbf{x}}_{1}}\right) }{q\left( {{\mathbf{x}}_{1} \mid  {\mathbf{x}}_{0}}\right) }}\right\rbrack   \tag{19}
$$

$$
= {\mathbb{E}}_{q}\left\lbrack  {-\log p\left( {\mathbf{x}}_{T}\right)  - \mathop{\sum }\limits_{{t > 1}}\log \frac{{p}_{\theta }\left( {{\mathbf{x}}_{t - 1} \mid  {\mathbf{x}}_{t}}\right) }{q\left( {{\mathbf{x}}_{t - 1} \mid  {\mathbf{x}}_{t},{\mathbf{x}}_{0}}\right) } \cdot  \frac{q\left( {{\mathbf{x}}_{t - 1} \mid  {\mathbf{x}}_{0}}\right) }{q\left( {{\mathbf{x}}_{t} \mid  {\mathbf{x}}_{0}}\right) } - \log \frac{{p}_{\theta }\left( {{\mathbf{x}}_{0} \mid  {\mathbf{x}}_{1}}\right) }{q\left( {{\mathbf{x}}_{1} \mid  {\mathbf{x}}_{0}}\right) }}\right\rbrack   \tag{20}
$$

$$
= {\mathbb{E}}_{q}\left\lbrack  {-\log \frac{p\left( {\mathbf{x}}_{T}\right) }{q\left( {{\mathbf{x}}_{T} \mid  {\mathbf{x}}_{0}}\right) } - \mathop{\sum }\limits_{{t > 1}}\log \frac{{p}_{\theta }\left( {{\mathbf{x}}_{t - 1} \mid  {\mathbf{x}}_{t}}\right) }{q\left( {{\mathbf{x}}_{t - 1} \mid  {\mathbf{x}}_{t},{\mathbf{x}}_{0}}\right) } - \log {p}_{\theta }\left( {{\mathbf{x}}_{0} \mid  {\mathbf{x}}_{1}}\right) }\right\rbrack   \tag{21}
$$

$$
= {\mathbb{E}}_{q}\left\lbrack  {{D}_{\mathrm{{KL}}}\left( {q\left( {{\mathbf{x}}_{T} \mid  {\mathbf{x}}_{0}}\right) \parallel p\left( {\mathbf{x}}_{T}\right) }\right)  + \mathop{\sum }\limits_{{t > 1}}{D}_{\mathrm{{KL}}}\left( {q\left( {{\mathbf{x}}_{t - 1} \mid  {\mathbf{x}}_{t},{\mathbf{x}}_{0}}\right) \parallel {p}_{\theta }\left( {{\mathbf{x}}_{t - 1} \mid  {\mathbf{x}}_{t}}\right) }\right)  - \log {p}_{\theta }\left( {{\mathbf{x}}_{0} \mid  {\mathbf{x}}_{1}}\right) }\right\rbrack
$$

(22)

The following is an alternate version of $L$ . It is not tractable to estimate, but it is useful for our discussion in Section 4.3

下面是$L$的另一种形式。它不可解估，但对我们在第4.3节的讨论有用。

$$
L = {\mathbb{E}}_{q}\left\lbrack  {-\log p\left( {\mathbf{x}}_{T}\right)  - \mathop{\sum }\limits_{{t \geq  1}}\log \frac{{p}_{\theta }\left( {{\mathbf{x}}_{t - 1} \mid  {\mathbf{x}}_{t}}\right) }{q\left( {{\mathbf{x}}_{t} \mid  {\mathbf{x}}_{t - 1}}\right) }}\right\rbrack   \tag{23}
$$

$$
= {\mathbb{E}}_{q}\left\lbrack  {-\log p\left( {\mathbf{x}}_{T}\right)  - \mathop{\sum }\limits_{{t \geq  1}}\log \frac{{p}_{\theta }\left( {{\mathbf{x}}_{t - 1} \mid  {\mathbf{x}}_{t}}\right) }{q\left( {{\mathbf{x}}_{t - 1} \mid  {\mathbf{x}}_{t}}\right) } \cdot  \frac{q\left( {\mathbf{x}}_{t - 1}\right) }{q\left( {\mathbf{x}}_{t}\right) }}\right\rbrack   \tag{24}
$$

$$
= {\mathbb{E}}_{q}\left\lbrack  {-\log \frac{p\left( {\mathbf{x}}_{T}\right) }{q\left( {\mathbf{x}}_{T}\right) } - \mathop{\sum }\limits_{{t \geq  1}}\log \frac{{p}_{\theta }\left( {{\mathbf{x}}_{t - 1} \mid  {\mathbf{x}}_{t}}\right) }{q\left( {{\mathbf{x}}_{t - 1} \mid  {\mathbf{x}}_{t}}\right) } - \log q\left( {\mathbf{x}}_{0}\right) }\right\rbrack   \tag{25}
$$

$$
= {D}_{\mathrm{{KL}}}\left( {q\left( {\mathbf{x}}_{T}\right) \parallel p\left( {\mathbf{x}}_{T}\right) }\right)  + {\mathbb{E}}_{q}\left\lbrack  {\mathop{\sum }\limits_{{t \geq  1}}{D}_{\mathrm{{KL}}}\left( {q\left( {{\mathbf{x}}_{t - 1} \mid  {\mathbf{x}}_{t}}\right) \parallel {p}_{\theta }\left( {{\mathbf{x}}_{t - 1} \mid  {\mathbf{x}}_{t}}\right) }\right) }\right\rbrack   + H\left( {\mathbf{x}}_{0}\right)  \tag{26}
$$

## B Experimental details

## B 实验细节

Our neural network architecture follows the backbone of PixelCNN++ [52], which is a U-Net [48] based on a Wide ResNet [72]. We replaced weight normalization [49] with group normalization [66] to make the implementation simpler. Our ${32} \times  {32}$ models use four feature map resolutions $({32} \times  {32}$ to $4 \times  4$ ), and our ${256} \times  {256}$ models use six. All models have two convolutional residual blocks per resolution level and self-attention blocks at the ${16} \times  {16}$ resolution between the convolutional blocks [6]. Diffusion time $t$ is specified by adding the Transformer sinusoidal position embedding [60] into each residual block. Our CIFAR10 model has 35.7 million parameters, and our LSUN and CelebA-HQ models have 114 million parameters. We also trained a larger variant of the LSUN Bedroom model with approximately 256 million parameters by increasing filter count.

我们的神经网络架构基于PixelCNN++[52]的骨干，是一个基于Wide ResNet[72]的U-Net[48]。我们用组归一化[66]替代了权重归一化[49]，以简化实现。我们的${32} \times  {32}$模型使用四个特征图分辨率(从$({32} \times  {32}$到$4 \times  4$)，而我们的${256} \times  {256}$模型使用六个。所有模型在每个分辨率级别都有两个卷积残差块，并在卷积块之间的${16} \times  {16}$分辨率处设置自注意力块[6]。扩散时间$t$通过将Transformer正弦位置编码[60]加入每个残差块中来指定。我们的CIFAR10模型有3570万个参数，LSUN和CelebA-HQ模型有1.14亿参数。我们还通过增加滤波器数量训练了一个更大的LSUN卧室模型，参数约为2.56亿。

We used TPU v3-8 (similar to 8 V100 GPUs) for all experiments. Our CIFAR model trains at 21 steps per second at batch size 128 (10.6 hours to train to completion at ${800}\mathrm{k}$ steps), and sampling a batch of 256 images takes 17 seconds. Our CelebA-HQ/LSUN (256 ${}^{2}$ ) models train at 2.2 steps per second at batch size 64, and sampling a batch of 128 images takes 300 seconds. We trained on CelebA-HQ for 0.5M steps, LSUN Bedroom for 2.4M steps, LSUN Cat for 1.8M steps, and LSUN Church for 1.2M steps. The larger LSUN Bedroom model was trained for 1.15M steps.

我们所有实验均使用TPU v3-8(相当于8个V100 GPU)。CIFAR模型在批量大小128时训练速度为每秒21步(训练完成需10.6小时，步数为${800}\mathrm{k}$)，采样256张图像批次需17秒。CelebA-HQ/LSUN(256 ${}^{2}$)模型在批量大小64时训练速度为每秒2.2步，采样128张图像批次需300秒。我们在CelebA-HQ上训练了50万步，LSUN卧室训练了240万步，LSUN猫训练了180万步，LSUN教堂训练了120万步。更大的LSUN卧室模型训练了115万步。

Apart from an initial choice of hyperparameters early on to make network size fit within memory constraints, we performed the majority of our hyperparameter search to optimize for CIFAR10 sample quality, then transferred the resulting settings over to the other datasets:

除了早期为使网络规模适应内存限制而初步选择的超参数外，我们的大部分超参数搜索都是为了优化CIFAR10的样本质量，然后将所得设置迁移到其他数据集:

- We chose the ${\beta }_{t}$ schedule from a set of constant, linear, and quadratic schedules, all constrained so that ${L}_{T} \approx  0$ . We set $T = {1000}$ without a sweep, and we chose a linear schedule from ${\beta }_{1} = {10}^{-4}$ to ${\beta }_{T} = {0.02}$ .

- 我们从一组恒定、线性和二次调度中选择了${\beta }_{t}$调度，所有调度均受限于${L}_{T} \approx  0$。我们未进行搜索直接设定了$T = {1000}$，并选择了从${\beta }_{1} = {10}^{-4}$到${\beta }_{T} = {0.02}$的线性调度。

- We set the dropout rate on CIFAR10 to 0.1 by sweeping over the values $\{ {0.1},{0.2},{0.3},{0.4}\}$ . Without dropout on CIFAR10, we obtained poorer samples reminiscent of the overfitting artifacts in an unregularized PixelCNN++ [52]. We set dropout rate on the other datasets to zero without sweeping.

- 我们通过对$\{ {0.1},{0.2},{0.3},{0.4}\}$值的搜索，将CIFAR10的dropout率设为0.1。CIFAR10无dropout时，样本质量较差，类似于未正则化PixelCNN++[52]中的过拟合伪影。其他数据集的dropout率设为零，未进行搜索。

- We used random horizontal flips during training for CIFAR10; we tried training both with and without flips, and found flips to improve sample quality slightly. We also used random horizontal flips for all other datasets except LSUN Bedroom.

- CIFAR10训练时使用了随机水平翻转；我们尝试了有无翻转的训练，发现翻转能略微提升样本质量。除LSUN卧室外，其他所有数据集也使用了随机水平翻转。

- We tried Adam [31] and RMSProp early on in our experimentation process and chose the former. We left the hyperparameters to their standard values. We set the learning rate to $2 \times  {10}^{-4}$ without any sweeping, and we lowered it to $2 \times  {10}^{-5}$ for the ${256} \times  {256}$ images, which seemed unstable to train with the larger learning rate.

- 我们在早期实验中尝试了Adam[31]和RMSProp，最终选择了前者。超参数保持默认值。学习率设为$2 \times  {10}^{-4}$，未进行搜索；对于${256} \times  {256}$尺寸的图像，学习率降低至$2 \times  {10}^{-5}$，因为较大学习率训练不稳定。

- We set the batch size to 128 for CIFAR10 and 64 for larger images. We did not sweep over these values.

- CIFAR10的批量大小设为128，大尺寸图像设为64，未进行搜索。

- We used EMA on model parameters with a decay factor of 0.9999 . We did not sweep over this value.

- 我们对模型参数使用了指数移动平均(EMA)，衰减因子为0.9999，未进行搜索。

Final experiments were trained once and evaluated throughout training for sample quality. Sample quality scores and log likelihood are reported on the minimum FID value over the course of training. On CIFAR10, we calculated Inception and FID scores on 50000 samples using the original code from the OpenAI [51] and TTUR [21] repositories, respectively. On LSUN, we calculated FID scores on 50000 samples using code from the StyleGAN2 [30] repository. CIFAR10 and CelebA-HQ were loaded as provided by TensorFlow Datasets (https://www.tensorflow.org/datasets), and LSUN was prepared using code from StyleGAN. Dataset splits (or lack thereof) are standard from the papers that introduced their usage in a generative modeling context. All details can be found in the source code release.

最终实验仅训练一次，并在整个训练过程中评估样本质量。样本质量分数和对数似然值均报告训练过程中最低FID值对应的结果。在CIFAR10上，我们使用OpenAI [51]和TTUR [21]仓库中的原始代码，分别对50000个样本计算了Inception和FID分数。在LSUN上，我们使用StyleGAN2 [30]仓库的代码对50000个样本计算了FID分数。CIFAR10和CelebA-HQ数据集由TensorFlow Datasets(https://www.tensorflow.org/datasets)提供，LSUN数据集则使用StyleGAN的代码进行准备。数据集划分(或无划分)均遵循生成模型领域相关论文中的标准。所有细节均可在源码发布中找到。

## C Discussion on related work

## C 相关工作讨论

Our model architecture, forward process definition, and prior differ from NCSN [55, 56] in subtle but important ways that improve sample quality, and, notably, we directly train our sampler as a latent variable model rather than adding it after training post-hoc. In greater detail:

我们的模型架构、前向过程定义和先验与NCSN [55, 56]存在细微但重要的差异，这些差异提升了样本质量，且值得注意的是，我们直接将采样器作为潜变量模型进行训练，而非训练后再进行后验添加。具体而言:

1. We use a U-Net with self-attention; NCSN uses a RefineNet with dilated convolutions. We condition all layers on $t$ by adding in the Transformer sinusoidal position embedding, rather than only in normalization layers (NCSNv1) or only at the output (v2).

1. 我们使用带自注意力机制的U-Net；NCSN使用带空洞卷积的RefineNet。我们通过添加Transformer正弦位置嵌入对所有层进行条件控制，而非仅在归一化层(NCSNv1)或仅在输出层(v2)进行条件控制。

2. Diffusion models scale down the data with each forward process step (by a $\sqrt{1 - {\beta }_{t}}$ factor) so that variance does not grow when adding noise, thus providing consistently scaled inputs to the neural net reverse process. NCSN omits this scaling factor.

2. 扩散模型在每一步前向过程中按$\sqrt{1 - {\beta }_{t}}$因子缩小数据，以防止加噪声时方差增长，从而为神经网络的逆过程提供一致缩放的输入。NCSN省略了该缩放因子。

3. Unlike NCSN, our forward process destroys signal $\left( {{D}_{\mathrm{{KL}}}\left( {q\left( {{\mathbf{x}}_{T} \mid  {\mathbf{x}}_{0}}\right) \parallel \mathcal{N}\left( {\mathbf{0},\mathbf{I}}\right) }\right)  \approx  0}\right)$ , ensuring a close match between the prior and aggregate posterior of ${\mathbf{x}}_{T}$ . Also unlike NCSN, our ${\beta }_{t}$ are very small, which ensures that the forward process is reversible by a Markov chain with conditional Gaussians. Both of these factors prevent distribution shift when sampling.

3. 与NCSN不同，我们的前向过程会破坏信号$\left( {{D}_{\mathrm{{KL}}}\left( {q\left( {{\mathbf{x}}_{T} \mid  {\mathbf{x}}_{0}}\right) \parallel \mathcal{N}\left( {\mathbf{0},\mathbf{I}}\right) }\right)  \approx  0}\right)$，确保先验与${\mathbf{x}}_{T}$的聚合后验高度匹配。且不同于NCSN，我们的${\beta }_{t}$非常小，保证前向过程可由带条件高斯的马尔可夫链可逆。这两点均防止了采样时的分布偏移。

4. Our Langevin-like sampler has coefficients (learning rate, noise scale, etc.) derived rigorously from ${\beta }_{t}$ in the forward process. Thus, our training procedure directly trains our sampler to match the data distribution after $T$ steps: it trains the sampler as a latent variable model using variational inference. In contrast, NCSN's sampler coefficients are set by hand post-hoc, and their training procedure is not guaranteed to directly optimize a quality metric of their sampler.

4. 我们的类Langevin采样器的系数(学习率、噪声尺度等)严格来源于前向过程中的${\beta }_{t}$。因此，我们的训练过程直接训练采样器以匹配经过$T$步后的数据分布:即通过变分推断将采样器作为潜变量模型进行训练。相比之下，NCSN的采样器系数是手动后验设定，其训练过程不保证直接优化采样器的质量指标。

## D Samples

## D 样本

## Additional samples Figure 11, 13, 16, 17, 18, and 19 show uncurated samples from the diffusion models trained on CelebA-HQ, CIFAR10 and LSUN datasets.

## 附加样本 图11、13、16、17、18和19展示了在CelebA-HQ、CIFAR10和LSUN数据集上训练的扩散模型的未经筛选样本。

Latent structure and reverse process stochasticity During sampling, both the prior ${\mathbf{x}}_{T} \sim$ $\mathcal{N}\left( {\mathbf{0},\mathbf{I}}\right)$ and Langevin dynamics are stochastic. To understand the significance of the second source of noise, we sampled multiple images conditioned on the same intermediate latent for the CelebA ${256} \times  {256}$ dataset. Figure 7 shows multiple draws from the reverse process ${\mathbf{x}}_{0} \sim  {p}_{\theta }\left( {{\mathbf{x}}_{0} \mid  {\mathbf{x}}_{t}}\right)$ that share the latent ${\mathbf{x}}_{t}$ for $t \in  \{ {1000},{750},{500},{250}\}$ . To accomplish this, we run a single reverse chain from an initial draw from the prior. At the intermediate timesteps, the chain is split to sample multiple images. When the chain is split after the prior draw at ${\mathbf{x}}_{T = {1000}}$ , the samples differ significantly However, when the chain is split after more steps, samples share high-level attributes like gender, hair color, eyewear, saturation, pose and facial expression. This indicates that intermediate latents like ${\mathrm{x}}_{750}$ encode these attributes, despite their imperceptibility.

潜在结构与逆过程随机性 在采样过程中，先验${\mathbf{x}}_{T} \sim$ $\mathcal{N}\left( {\mathbf{0},\mathbf{I}}\right)$和Langevin动力学均具有随机性。为理解第二种噪声来源的重要性，我们在CelebA ${256} \times  {256}$数据集上针对相同中间潜变量采样了多张图像。图7展示了多个共享潜变量${\mathbf{x}}_{t}$的逆过程${\mathbf{x}}_{0} \sim  {p}_{\theta }\left( {{\mathbf{x}}_{0} \mid  {\mathbf{x}}_{t}}\right)$采样结果，针对$t \in  \{ {1000},{750},{500},{250}\}$。为实现此目的，我们从先验的初始采样运行单条逆链，在中间时间步将链分裂以采样多张图像。当链在${\mathbf{x}}_{T = {1000}}$先验采样后分裂时，样本差异显著；但当链在更多步骤后分裂时，样本共享性别、发色、眼镜、饱和度、姿势和面部表情等高级属性。这表明诸如${\mathrm{x}}_{750}$的中间潜变量编码了这些属性，尽管它们不可察觉。

Coarse-to-fine interpolation Figure 9 shows interpolations between a pair of source CelebA ${256} \times  {256}$ images as we vary the number of diffusion steps prior to latent space interpolation. Increasing the number of diffusion steps destroys more structure in the source images, which the model completes during the reverse process. This allows us to interpolate at both fine granularities and coarse granularities. In the limiting case of 0 diffusion steps, the interpolation mixes source images in pixel space. On the other hand, after 1000 diffusion steps, source information is lost and interpolations are novel samples.

粗到细的插值 图9展示了在潜空间插值之前，随着扩散步骤数的变化，一对CelebA${256} \times  {256}$源图像之间的插值。增加扩散步骤数会破坏源图像中的更多结构，模型在逆过程完成这些结构。这使我们能够在细粒度和粗粒度上进行插值。在0扩散步骤的极限情况下，插值是在像素空间中混合源图像。另一方面，经过1000步扩散后，源信息丢失，插值成为新颖样本。

![bo_d1c3pvn7aajc7389qep0_15_307_372_1178_760_0.jpg](images/bo_d1c3pvn7aajc7389qep0_15_307_372_1178_760_0.jpg)

Figure 9: Coarse-to-fine interpolations that vary the number of diffusion steps prior to latent mixing.

图9:在潜空间混合之前改变扩散步骤数的粗到细插值。

![bo_d1c3pvn7aajc7389qep0_15_381_1681_1037_387_0.jpg](images/bo_d1c3pvn7aajc7389qep0_15_381_1681_1037_387_0.jpg)

Figure 10: Unconditional CIFAR10 progressive sampling quality over time

图10:无条件CIFAR10随时间变化的渐进采样质量

![bo_d1c3pvn7aajc7389qep0_16_305_541_1190_1188_0.jpg](images/bo_d1c3pvn7aajc7389qep0_16_305_541_1190_1188_0.jpg)

Figure 11: CelebA-HQ 256 $\times  {256}$ generated samples

图11:CelebA-HQ 256$\times  {256}$生成样本

![bo_d1c3pvn7aajc7389qep0_17_301_458_1195_1282_0.jpg](images/bo_d1c3pvn7aajc7389qep0_17_301_458_1195_1282_0.jpg)

Figure 12: CelebA-HQ ${256} \times  {256}$ nearest neighbors, computed on a ${100} \times  {100}$ crop surrounding the faces. Generated samples are in the leftmost column, and training set nearest neighbors are in the remaining columns.

图12:CelebA-HQ${256} \times  {256}$最近邻，基于围绕面部的${100} \times  {100}$裁剪计算。生成样本位于最左列，训练集最近邻位于其余列。

![bo_d1c3pvn7aajc7389qep0_18_304_542_1191_1187_0.jpg](images/bo_d1c3pvn7aajc7389qep0_18_304_542_1191_1187_0.jpg)

Figure 13: Unconditional CIFAR10 generated samples

图13:无条件CIFAR10生成样本

![bo_d1c3pvn7aajc7389qep0_19_308_545_1187_1182_0.jpg](images/bo_d1c3pvn7aajc7389qep0_19_308_545_1187_1182_0.jpg)

Figure 14: Unconditional CIFAR10 progressive generation

图14:无条件CIFAR10渐进生成

![bo_d1c3pvn7aajc7389qep0_20_357_539_1080_1162_0.jpg](images/bo_d1c3pvn7aajc7389qep0_20_357_539_1080_1162_0.jpg)

Figure 15: Unconditional CIFAR10 nearest neighbors. Generated samples are in the leftmost column, and training set nearest neighbors are in the remaining columns.

图15:无条件CIFAR10最近邻。生成样本位于最左列，训练集最近邻位于其余列。

![bo_d1c3pvn7aajc7389qep0_21_307_364_1188_1539_0.jpg](images/bo_d1c3pvn7aajc7389qep0_21_307_364_1188_1539_0.jpg)

Figure 16: LSUN Church generated samples. FID=7.89

图16:LSUN教堂生成样本。FID=7.89

![bo_d1c3pvn7aajc7389qep0_22_307_362_1186_1541_0.jpg](images/bo_d1c3pvn7aajc7389qep0_22_307_362_1186_1541_0.jpg)

Figure 17: LSUN Bedroom generated samples, large model. FID=4.90

图17:LSUN卧室生成样本，大模型。FID=4.90

![bo_d1c3pvn7aajc7389qep0_23_309_364_1186_1539_0.jpg](images/bo_d1c3pvn7aajc7389qep0_23_309_364_1186_1539_0.jpg)

Figure 18: LSUN Bedroom generated samples, small model. FID=6.36

图18:LSUN卧室生成样本，小模型。FID=6.36

![bo_d1c3pvn7aajc7389qep0_24_306_364_1186_1539_0.jpg](images/bo_d1c3pvn7aajc7389qep0_24_306_364_1186_1539_0.jpg)

Figure 19: LSUN Cat generated samples. FID=19.75

图19:LSUN猫生成样本。FID=19.75

