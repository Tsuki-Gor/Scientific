# Batch Normalization: Accelerating Deep Network Training by Reducing Internal Covariate Shift

# 批量归一化:通过减少内部协变量偏移加速深度网络训练

Sergey Ioffe SIOFFE @ GOOGLE.COM

Sergey Ioffe SIOFFE @ GOOGLE.COM

Christian Szegedy SZEGEDY @GOOGLE.COM

Christian Szegedy SZEGEDY @GOOGLE.COM

Google, 1600 Amphitheatre Pkwy, Mountain View, CA 94043

谷歌，1600 Amphitheatre Pkwy，Mountain View，CA 94043

## Abstract

## 摘要

Training Deep Neural Networks is complicated by the fact that the distribution of each layer's inputs changes during training, as the parameters of the previous layers change. This slows down the training by requiring lower learning rates and careful parameter initialization, and makes it notoriously hard to train models with saturating nonlinearities. We refer to this phenomenon as internal covariate shift, and address the problem by normalizing layer inputs. Our method draws its strength from making normalization a part of the model architecture and performing the normalization for each training mini-batch. Batch Normalization allows us to use much higher learning rates and be less careful about initialization, and in some cases eliminates the need for Dropout. Applied to a state-of-the-art image classification model, Batch Normalization achieves the same accuracy with 14 times fewer training steps, and beats the original model by a significant margin. Using an ensemble of batch-normalized networks, we improve upon the best published result on ImageNet classification: reaching 4.82% top-5 test error, exceeding the accuracy of human raters.

深度神经网络的训练因每层输入分布在训练过程中随着前层参数的变化而改变而变得复杂。这降低了训练速度，需要更低的学习率和谨慎的参数初始化，并且使得带有饱和非线性的模型训练异常困难。我们将这种现象称为内部协变量偏移(internal covariate shift)，并通过对层输入进行归一化来解决该问题。我们的方法的优势在于将归一化作为模型架构的一部分，并对每个训练小批量执行归一化。批量归一化允许我们使用更高的学习率，且对初始化不那么敏感，在某些情况下甚至消除了对Dropout的需求。应用于最先进的图像分类模型，批量归一化以14倍更少的训练步骤达到相同的准确率，并显著优于原始模型。通过使用批量归一化网络的集成，我们在ImageNet分类任务上超越了最佳已发表结果:达到4.82%的top-5测试误差，超过了人类评审的准确率。

## 1. Introduction

## 1. 引言

Deep learning has dramatically advanced the state of the art in vision, speech, and many other areas. Stochastic gradient descent (SGD) has proved to be an effective way of training deep networks, and SGD variants such as momentum (Sutskever et al., 2013) and Adagrad (Duchi et al., 2011) have been used to achieve state of the art performance. SGD optimizes the parameters $\Theta$ of the network, so as to minimize the loss

深度学习在视觉、语音及许多其他领域极大地推动了技术进步。随机梯度下降(SGD)已被证明是训练深度网络的有效方法，且诸如动量(momentum)(Sutskever等，2013)和Adagrad(Duchi等，2011)等SGD变体被用于实现最先进的性能。SGD通过优化网络参数$\Theta$，以最小化损失函数

$$
\Theta  = \arg \mathop{\min }\limits_{\Theta }\frac{1}{N}\mathop{\sum }\limits_{{i = 1}}^{N}\ell \left( {{\mathrm{x}}_{i},\Theta }\right)
$$

where ${\mathrm{x}}_{1\ldots N}$ is the training data set. With SGD, the training proceeds in steps, at each step considering a mini-batch ${\mathrm{x}}_{1\ldots m}$ of size $m$ . Using mini-batches of examples, as opposed to one example at a time, is helpful in several ways. First, the gradient of the loss over a mini-batch $\frac{1}{m}\mathop{\sum }\limits_{{i = 1}}^{m}\frac{\partial \ell \left( {{\mathbf{x}}_{i},\Theta }\right) }{\partial \Theta }$ is an estimate of the gradient over the training set, whose quality improves as the batch size increases. Second, computation over a mini-batch can be more efficient than $m$ computations for individual examples on modern computing platforms.

其中${\mathrm{x}}_{1\ldots N}$是训练数据集。使用SGD，训练以步骤进行，每一步考虑一个大小为$m$的小批量${\mathrm{x}}_{1\ldots m}$。使用小批量样本而非单个样本逐一处理，有多方面的好处。首先，小批量上的损失梯度$\frac{1}{m}\mathop{\sum }\limits_{{i = 1}}^{m}\frac{\partial \ell \left( {{\mathbf{x}}_{i},\Theta }\right) }{\partial \Theta }$是对整个训练集梯度的估计，且随着批量大小的增加，估计质量提升。其次，在现代计算平台上，对小批量的计算比对单个样本的多次计算更高效。

While stochastic gradient is simple and effective, it requires careful tuning of the model hyper-parameters, specifically the learning rate and the initial parameter values. The training is complicated by the fact that the inputs to each layer are affected by the parameters of all preceding layers - so that small changes to the network parameters amplify as the network becomes deeper.

虽然随机梯度下降简单且有效，但它需要对模型超参数，特别是学习率和初始参数值进行细致调节。训练的复杂性还在于每层的输入受所有前置层参数的影响——网络越深，参数的微小变化放大效应越明显。

The change in the distributions of layers' inputs presents a problem because the layers need to continuously adapt to the new distribution. When the input distribution to a learning system changes, it is said to experience covariate shift (Shimodaira, 2000). This is typically handled via domain adaptation (Jiang, 2008). However, the notion of covariate shift can be extended beyond the learning system as a whole, to apply to its parts, such as a sub-network or a layer. Consider a network computing

层输入分布的变化带来了问题，因为各层需要不断适应新的分布。当学习系统的输入分布发生变化时，称其经历了协变量偏移(covariate shift)(Shimodaira，2000)。这通常通过领域适应(domain adaptation)(Jiang，2008)来处理。然而，协变量偏移的概念可以扩展到学习系统的部分，如子网络或单层。考虑一个网络计算

$$
\ell  = {F}_{2}\left( {{F}_{1}\left( {\mathrm{u},{\Theta }_{1}}\right) ,{\Theta }_{2}}\right)
$$

where ${F}_{1}$ and ${F}_{2}$ are arbitrary transformations, and the parameters ${\Theta }_{1},{\Theta }_{2}$ are to be learned so as to minimize the loss $\ell$ . Learning ${\Theta }_{2}$ can be viewed as if the inputs $\mathrm{x} = {F}_{1}\left( {\mathrm{u},{\Theta }_{1}}\right)$ are fed into the sub-network

其中${F}_{1}$和${F}_{2}$是任意变换，参数${\Theta }_{1},{\Theta }_{2}$需被学习以最小化损失$\ell$。学习${\Theta }_{2}$可以视为将输入$\mathrm{x} = {F}_{1}\left( {\mathrm{u},{\Theta }_{1}}\right)$馈入子网络

$$
\ell  = {F}_{2}\left( {\mathrm{x},{\Theta }_{2}}\right) .
$$

---

Proceedings of the ${32}^{\text{nd }}$ International Conference on Machine Learning, Lille, France, 2015. JMLR: W&CP volume 37. Copyright 2015 by the author(s).

发表于${32}^{\text{nd }}$国际机器学习大会，法国里尔，2015年。JMLR: W&CP 第37卷。版权归作者所有，2015年。

---

For example, a gradient descent step

例如，一个梯度下降步骤

$$
{\Theta }_{2} \leftarrow  {\Theta }_{2} - \frac{\alpha }{m}\mathop{\sum }\limits_{{i = 1}}^{m}\frac{\partial {F}_{2}\left( {{\mathrm{x}}_{i},{\Theta }_{2}}\right) }{\partial {\Theta }_{2}}
$$

(for mini-batch size $m$ and learning rate $\alpha$ ) is exactly equivalent to that for a stand-alone network ${F}_{2}$ with input $\mathrm{x}$ . Therefore, the input distribution properties that aid the network generalization - such as having the same distribution between the training and test data - apply to training the sub-network as well. As such it is advantageous for the distribution of $\mathrm{x}$ to remain fixed over time. Then, ${\Theta }_{2}$ does not have to readjust to compensate for the change in the distribution of $\mathrm{x}$ .

(对于小批量大小$m$和学习率$\alpha$)与输入为$\mathrm{x}$的独立网络${F}_{2}$完全等价。因此，有助于网络泛化的输入分布特性——例如训练数据和测试数据之间具有相同分布——同样适用于子网络的训练。因此，保持$\mathrm{x}$的分布随时间固定是有利的。这样，${\Theta }_{2}$就不必重新调整以补偿$\mathrm{x}$分布的变化。

Fixed distribution of inputs to a sub-network would have positive consequences for the layers outside the subnetwork, as well. Consider a layer with a sigmoid activation function $\mathrm{z} = g\left( {W\mathrm{u} + \mathrm{b}}\right)$ where $\mathrm{u}$ is the layer input, the weight matrix $W$ and bias vector $\mathrm{b}$ are the layer parameters to be learned, and $g\left( x\right)  = \frac{1}{1 + \exp \left( {-x}\right) }$ . As $\left| x\right|$ increases, ${g}^{\prime }\left( x\right)$ tends to zero. This means that for all dimensions of $\mathrm{x} = W\mathrm{u} + \mathrm{b}$ except those with small absolute values, the gradient flowing down to u will vanish and the model will train slowly. However, since $\mathrm{x}$ is affected by $W,\mathrm{\;b}$ and the parameters of all the layers below, changes to those parameters during training will likely move many dimensions of $\mathrm{x}$ into the saturated regime of the nonlinearity and slow down the convergence. This effect is amplified as the network depth increases. In practice, the saturation problem and the resulting vanishing gradients are usually addressed by using Rectified Linear Units (Nair & Hinton, 2010) $\operatorname{ReLU}\left( x\right)  = \max \left( {x,0}\right)$ , careful initialization (Ben-gio & Glorot, 2010; Saxe et al., 2013), and small learning rates. If, however, we could ensure that the distribution of nonlinearity inputs remains more stable as the network trains, then the optimizer would be less likely to get stuck in the saturated regime, and the training would accelerate.

对子网络输入的固定分布对子网络外的层也会产生积极影响。考虑一个带有sigmoid激活函数$\mathrm{z} = g\left( {W\mathrm{u} + \mathrm{b}}\right)$的层，其中$\mathrm{u}$是该层输入，权重矩阵$W$和偏置向量$\mathrm{b}$是该层待学习的参数，且$g\left( x\right)  = \frac{1}{1 + \exp \left( {-x}\right) }$。随着$\left| x\right|$的增加，${g}^{\prime }\left( x\right)$趋近于零。这意味着对于$\mathrm{x} = W\mathrm{u} + \mathrm{b}$的所有维度，除了那些绝对值较小的维度，传递到u的梯度将消失，模型训练将变慢。然而，由于$\mathrm{x}$受$W,\mathrm{\;b}$及所有下层参数的影响，这些参数在训练过程中发生变化很可能会使$\mathrm{x}$的许多维度进入非线性函数的饱和区，从而减缓收敛速度。随着网络深度的增加，这种效应会被放大。实际上，饱和问题及由此产生的梯度消失通常通过使用修正线性单元(Rectified Linear Units，Nair & Hinton, 2010)$\operatorname{ReLU}\left( x\right)  = \max \left( {x,0}\right)$、谨慎的初始化(Ben-gio & Glorot, 2010；Saxe等，2013)以及较小的学习率来解决。然而，如果我们能确保非线性输入的分布在网络训练过程中更稳定，那么优化器就不太可能陷入饱和区，训练速度将加快。

We refer to the change in the distributions of internal nodes of a deep network, in the course of training, as Internal Covariate Shift. Eliminating it offers a promise of faster training. We propose a new mechanism, which we call Batch Normalization, that takes a step towards reducing internal covariate shift, and in doing so dramatically accelerates the training of deep neural nets. It accomplishes this via a normalization step that fixes the means and variances of layer inputs. Batch Normalization also has a beneficial effect on the gradient flow through the network, by reducing the dependence of gradients on the scale of the parameters or of their initial values. This allows us to use much higher learning rates without the risk of divergence. Furthermore, batch normalization regularizes the model and reduces the need for Dropout (Srivastava et al., 2014). Finally, Batch Normalization makes it possible to use saturating nonlinearities by preventing the network from getting stuck in the saturated modes.

我们将深度网络内部节点分布在训练过程中发生的变化称为内部协变量偏移(Internal Covariate Shift)。消除这一现象有望加快训练速度。我们提出了一种新机制，称为批量归一化(Batch Normalization)，旨在减少内部协变量偏移，从而显著加速深度神经网络的训练。该方法通过归一化步骤固定层输入的均值和方差来实现这一目标。批量归一化还通过减少梯度对参数尺度或初始值的依赖，改善了网络中的梯度流动。这使得我们可以使用更高的学习率而不必担心发散。此外，批量归一化对模型具有正则化作用，减少了对Dropout(Srivastava等，2014)的需求。最后，批量归一化使得使用饱和非线性函数成为可能，防止网络陷入饱和状态。

In Sec. 4.2, we apply Batch Normalization to the best-performing ImageNet classification network, and show that we can match its performance using only $7\%$ of the training steps, and can further exceed its accuracy by a substantial margin. Using an ensemble of such networks trained with Batch Normalization, we achieve the top-5 error rate that improves upon the best known results on ImageNet classification.

在第4.2节中，我们将批量归一化应用于表现最佳的ImageNet分类网络，结果显示我们仅用$7\%$的训练步骤即可达到其性能，并且还能显著超越其准确率。通过使用一组采用批量归一化训练的此类网络的集成，我们实现了在ImageNet分类任务上优于已知最佳结果的top-5错误率。

## 2. Towards Reducing Internal Covariate Shift

## 2. 迈向减少内部协变量偏移

We define Internal Covariate Shift as the change in the distribution of network activations due to the change in network parameters during training. To improve the training, we seek to reduce the internal covariate shift. By fixing the distribution of the layer inputs $\mathrm{x}$ as the training progresses, we expect to improve the training speed. It has been long known (LeCun et al., 1998b; Wiesler & Ney, 2011) that the network training converges faster if its inputs are whitened - i.e., linearly transformed to have zero means and unit variances, and decorrelated. As each layer observes the inputs produced by the layers below, it would be advantageous to achieve the same whitening of the inputs of each layer. By whitening the inputs to each layer, we would take a step towards achieving the fixed distributions of inputs that would remove the ill effects of the internal covariate shift.

我们将内部协变量偏移定义为由于训练过程中网络参数变化而导致的网络激活分布的变化。为了改善训练效果，我们寻求减少内部协变量偏移。通过在训练过程中固定层输入的分布$\mathrm{x}$，我们期望提升训练速度。早已知晓(LeCun 等，1998b；Wiesler & Ney，2011)如果网络输入经过白化处理——即线性变换使其均值为零、方差为一且去相关，网络训练收敛速度会更快。由于每层观察的是下层产生的输入，实现每层输入的同样白化处理将是有利的。通过对白化每层的输入，我们将朝着实现输入分布固定的目标迈进，从而消除内部协变量偏移的不良影响。

We could consider whitening activations at every training step or at some interval, either by modifying the network directly or by changing the parameters of the optimization algorithm to depend on the network activation values (Wiesler et al., 2014; Raiko et al., 2012; Povey et al., 2014; Desjardins & Kavukcuoglu). However, if these modifications are interspersed with the optimization steps, then the gradient descent step may attempt to update the parameters in a way that requires the normalization to be updated, which reduces the effect of the gradient step. For example, consider a layer with the input $u$ that adds the learned bias $b$ , and normalizes the result by subtracting the mean of the activation computed over the training data: $\widehat{x} = x - E\left\lbrack  x\right\rbrack$ where $x = u + b,\mathcal{X} = \left\{  {x}_{1\ldots N}\right\}$ is the set of values of $x$ over the training set, and $\mathrm{E}\left\lbrack  x\right\rbrack   = \frac{1}{N}\mathop{\sum }\limits_{{i = 1}}^{N}{x}_{i}$ . If a gradient descent step ignores the dependence of $\mathrm{E}\left\lbrack  x\right\rbrack$ on $b$ , then it will update $b \leftarrow  b + {\Delta b}$ , where ${\Delta b} \propto   - \partial \ell /\partial \widehat{x}$ . Then $u + \left( {b + {\Delta b}}\right)  - \mathrm{E}\left\lbrack  {u + \left( {b + {\Delta b}}\right) }\right\rbrack   = u + b - \mathrm{E}\left\lbrack  {u + b}\right\rbrack$ . Thus, the combination of the update to $b$ and subsequent change in normalization led to no change in the output of the layer nor, consequently, the loss. As the training continues, $b$ will grow indefinitely while the loss remains fixed. This problem can get worse if the normalization not only centers but also scales the activations. We have observed this empirically in initial experiments, where the model blows up when the normalization parameters are computed outside the gradient descent step.

我们可以考虑在每个训练步骤或某些间隔对白化激活值，方法是直接修改网络或改变优化算法参数以依赖网络激活值(Wiesler 等，2014；Raiko 等，2012；Povey 等，2014；Desjardins & Kavukcuoglu)。然而，如果这些修改穿插在优化步骤中，梯度下降步骤可能会尝试以需要更新归一化的方式更新参数，这会削弱梯度步骤的效果。例如，考虑一个输入为$u$的层，该层添加学习到的偏置$b$，并通过减去训练数据上计算的激活均值来归一化结果:$\widehat{x} = x - E\left\lbrack  x\right\rbrack$，其中$x = u + b,\mathcal{X} = \left\{  {x}_{1\ldots N}\right\}$是训练集上$x$的取值集合，且$\mathrm{E}\left\lbrack  x\right\rbrack   = \frac{1}{N}\mathop{\sum }\limits_{{i = 1}}^{N}{x}_{i}$。如果梯度下降步骤忽略了$\mathrm{E}\left\lbrack  x\right\rbrack$对$b$的依赖，则会更新$b \leftarrow  b + {\Delta b}$，其中${\Delta b} \propto   - \partial \ell /\partial \widehat{x}$。然后$u + \left( {b + {\Delta b}}\right)  - \mathrm{E}\left\lbrack  {u + \left( {b + {\Delta b}}\right) }\right\rbrack   = u + b - \mathrm{E}\left\lbrack  {u + b}\right\rbrack$。因此，更新$b$及随后的归一化变化导致层输出及损失均无变化。随着训练继续，$b$会无限增长而损失保持不变。如果归一化不仅中心化还缩放激活值，这个问题会更严重。我们在初步实验中观察到，当归一化参数在梯度下降步骤之外计算时，模型会崩溃。

The issue with the above approach is that the gradient descent optimization does not take into account the fact that the normalization takes place. To address this issue, we would like to ensure that, for any parameter values, the network always produces activations with the desired distribution. Doing so would allow the gradient of the loss with respect to the model parameters to account for the normalization, and for its dependence on the model parameters $\Theta$ . Let again $\mathrm{x}$ be a layer input, treated as a vector, and $\mathcal{X}$ be the set of these inputs over the training data set. The normalization can then be written as a transformation

上述方法的问题在于梯度下降优化未考虑归一化的存在。为解决此问题，我们希望确保无论参数取何值，网络始终产生具有期望分布的激活值。这样，损失对模型参数的梯度就能考虑归一化及其对模型参数的依赖$\Theta$。设$\mathrm{x}$为层输入，视为向量，$\mathcal{X}$为训练数据集上的这些输入集合。归一化可表示为一种变换

$$
\widehat{\mathrm{x}} = \operatorname{Norm}\left( {\mathrm{x},\mathcal{X}}\right)
$$

which depends not only on the given training example $\mathrm{x}$ but on all examples $\mathcal{X}$ - each of which depends on $\Theta$ if $\mathrm{x}$ is generated by another layer. For backpropagation, we would need to compute the Jacobians $\frac{\partial \operatorname{Norm}\left( {x,\mathcal{X}}\right) }{\partial x}$ and $\frac{\partial \operatorname{Norm}\left( {\mathrm{x},\mathcal{X}}\right) }{\partial \mathcal{X}}$ ; ignoring the latter term would lead to the explosion described above. Within this framework, whitening the layer inputs is expensive, as it requires computing the covariance matrix $\operatorname{Cov}\left\lbrack  \mathrm{x}\right\rbrack   = {\mathrm{E}}_{\mathrm{x} \in  \mathcal{X}}\left\lbrack  {\mathrm{{xx}}}^{T}\right\rbrack   - \mathrm{E}\left\lbrack  \mathrm{x}\right\rbrack  \mathrm{E}{\left\lbrack  \mathrm{x}\right\rbrack  }^{T}$ and its inverse square root, to produce the whitened activations $\operatorname{Cov}{\left\lbrack  \mathrm{x}\right\rbrack  }^{-1/2}\left( {\mathrm{x} - \mathrm{E}\left\lbrack  \mathrm{x}\right\rbrack  }\right)$ , as well as the derivatives of these transforms for backpropagation. This motivates us to seek an alternative that performs input normalization in a way that is differentiable and does not require the analysis of the entire training set after every parameter update.

这不仅依赖于给定的训练样本$\mathrm{x}$，还依赖于所有样本$\mathcal{X}$——每个样本又依赖于$\Theta$，如果$\mathrm{x}$是由另一层生成的。对于反向传播，我们需要计算雅可比矩阵$\frac{\partial \operatorname{Norm}\left( {x,\mathcal{X}}\right) }{\partial x}$和$\frac{\partial \operatorname{Norm}\left( {\mathrm{x},\mathcal{X}}\right) }{\partial \mathcal{X}}$；忽略后者项会导致上述的梯度爆炸。在此框架下，对层输入进行白化处理代价高昂，因为这需要计算协方差矩阵$\operatorname{Cov}\left\lbrack  \mathrm{x}\right\rbrack   = {\mathrm{E}}_{\mathrm{x} \in  \mathcal{X}}\left\lbrack  {\mathrm{{xx}}}^{T}\right\rbrack   - \mathrm{E}\left\lbrack  \mathrm{x}\right\rbrack  \mathrm{E}{\left\lbrack  \mathrm{x}\right\rbrack  }^{T}$及其逆平方根，以生成白化激活$\operatorname{Cov}{\left\lbrack  \mathrm{x}\right\rbrack  }^{-1/2}\left( {\mathrm{x} - \mathrm{E}\left\lbrack  \mathrm{x}\right\rbrack  }\right)$，同时还需计算这些变换的导数以进行反向传播。这促使我们寻找一种替代方法，以可微分且无需在每次参数更新后分析整个训练集的方式执行输入归一化。

Some of the previous approaches (e.g. (Lyu & Simoncelli, 2008)) use statistics computed over a single training example, or, in the case of image networks, over different feature maps at a given location. However, this changes the representation ability of a network by discarding the absolute scale of activations. We want to a preserve the information in the network, by normalizing the activations in a training example relative to the statistics of the entire training data.

之前的一些方法(例如 (Lyu & Simoncelli, 2008))使用单个训练样本计算的统计量，或者在图像网络中，使用给定位置不同特征图的统计量。然而，这种做法通过丢弃激活的绝对尺度，改变了网络的表示能力。我们希望通过相对于整个训练数据的统计量对训练样本中的激活进行归一化，来保留网络中的信息。

## 3. Normalization via Mini-Batch Statistics

## 3. 通过小批量统计进行归一化

Since the full whitening of each layer's inputs is costly, we make two necessary simplifications. The first is that instead of whitening the features in layer inputs and outputs jointly, we will normalize each scalar feature independently, by making it have zero mean and unit variance. For a layer with $d$ -dimensional input $\mathrm{x} = \left( {{x}^{\left( 1\right) }\ldots {x}^{\left( d\right) }}\right)$ , we will normalize each dimension

由于对每层输入进行完全白化代价高昂，我们做了两个必要的简化。首先，我们不对层输入和输出的特征联合白化，而是独立地对每个标量特征进行归一化，使其均值为零，方差为一。对于具有$d$维输入$\mathrm{x} = \left( {{x}^{\left( 1\right) }\ldots {x}^{\left( d\right) }}\right)$的层，我们将对每个维度进行归一化

$$
{\widehat{x}}^{\left( k\right) } = \frac{{x}^{\left( k\right) } - \mathrm{E}\left\lbrack  {x}^{\left( k\right) }\right\rbrack  }{\sqrt{\operatorname{Var}\left\lbrack  {x}^{\left( k\right) }\right\rbrack  }}
$$

where the expectation and variance are computed over the training data set. As shown in (LeCun et al., 1998b), such normalization speeds up convergence, even when the features are not decorrelated.

其中期望和方差是在整个训练数据集上计算的。如 (LeCun et al., 1998b) 所示，即使特征未被去相关，这种归一化也能加速收敛。

Note that simply normalizing each input of a layer may change what the layer can represent. For instance, normalizing the inputs of a sigmoid would constrain them to the linear regime of the nonlinearity. To address this, we make sure that the transformation inserted in the network can represent the identity transform. To accomplish this, we introduce, for each activation ${x}^{\left( k\right) }$ , a pair of parameters ${\gamma }^{\left( k\right) },{\beta }^{\left( k\right) }$ , which scale and shift the normalized value:

注意，简单地归一化层的每个输入可能会改变该层的表示能力。例如，归一化sigmoid的输入会将其限制在线性非线性区域。为了解决这个问题，我们确保插入网络的变换可以表示恒等变换。为此，我们为每个激活${x}^{\left( k\right) }$引入一对参数${\gamma }^{\left( k\right) },{\beta }^{\left( k\right) }$，用于缩放和平移归一化值:

$$
{y}^{\left( k\right) } = {\gamma }^{\left( k\right) }{\widehat{x}}^{\left( k\right) } + {\beta }^{\left( k\right) }.
$$

These parameters are learned along with the original model parameters, and restore the representation power of the network. Indeed, by setting ${\gamma }^{\left( k\right) } = \sqrt{\operatorname{Var}\left\lbrack  {x}^{\left( k\right) }\right\rbrack  }$ and ${\beta }^{\left( k\right) } =$ $\mathrm{E}\left\lbrack  {x}^{\left( k\right) }\right\rbrack$ , we could recover the original activations, if that were the optimal thing to do.

这些参数与原始模型参数一起学习，恢复网络的表示能力。实际上，通过设置${\gamma }^{\left( k\right) } = \sqrt{\operatorname{Var}\left\lbrack  {x}^{\left( k\right) }\right\rbrack  }$和${\beta }^{\left( k\right) } =$为$\mathrm{E}\left\lbrack  {x}^{\left( k\right) }\right\rbrack$，如果这是最优选择，我们可以恢复原始激活。

In the batch setting where each training step is based on the entire training set, we would use the whole set to normalize activations. However, this is impractical when using stochastic optimization. Therefore, we make the second simplification: since we use mini-batches in stochastic gradient training, each mini-batch produces estimates of the mean and variance of each activation. This way, the statistics used for normalization can fully participate in the gradient backpropagation. Note that the use of mini-batches is enabled by computation of per-dimension variances rather than joint covariances; in the joint case, regularization would be required since the mini-batch size is likely to be smaller than the number of activations being whitened, resulting in singular covariance matrices.

在每个训练步骤基于整个训练集的批量设置中，我们会使用整个训练集来归一化激活值。然而，在使用随机优化时这是不切实际的。因此，我们做了第二个简化:由于在随机梯度训练中使用小批量，每个小批量都会产生每个激活值的均值和方差的估计值。这样，用于归一化的统计量可以完全参与梯度反向传播。注意，使用小批量是通过计算每个维度的方差而非联合协方差实现的；在联合情况下，由于小批量大小可能小于被白化的激活数量，会导致协方差矩阵奇异，因此需要正则化。

Consider a mini-batch $\mathcal{B}$ of size $m$ . Since the normalization is applied to each activation independently, let us focus on a particular activation ${x}^{\left( k\right) }$ and omit $k$ for clarity. We have $m$ values of this activation in the mini-batch,

考虑一个大小为$\mathcal{B}$的小批量$m$。由于归一化是独立应用于每个激活的，我们关注特定激活${x}^{\left( k\right) }$，并为清晰起见省略$k$。在该小批量中，我们有$m$个该激活的值，

$$
\mathcal{B} = \left\{  {x}_{1\ldots m}\right\}  .
$$

Let the normalized values be ${\widehat{x}}_{1\ldots m}$ , and their linear transformations be ${y}_{1\ldots m}$ . We refer to the transform

令归一化后的值为${\widehat{x}}_{1\ldots m}$，它们的线性变换为${y}_{1\ldots m}$。我们称该变换为

$$
{\mathrm{{BN}}}_{\gamma ,\beta } : {x}_{1\ldots m} \rightarrow  {y}_{1\ldots m}
$$

as the Batch Normalizing Transform. We present the BN Transform in Algorithm 1. In the algorithm, $\epsilon$ is a constant added to the mini-batch variance for numerical stability.

批量归一化变换(Batch Normalizing Transform)。我们在算法1中展示了BN变换。在算法中，$\epsilon$是加到小批量方差上的常数，用于数值稳定性。

The BN transform can be added to a network to manipulate any activation. In the notation $y = {\mathrm{{BN}}}_{\gamma ,\beta }\left( x\right)$ , we indicate that the parameters $\gamma$ and $\beta$ are to be learned, but it should be noted that the BN transform does not independently process the activation in each training example. Rather, ${\mathrm{{BN}}}_{\gamma ,\beta }\left( x\right)$ depends both on the training example and the other examples in the mini-batch. The scaled and shifted values $y$ are passed to other network layers. The normalized activations $\widehat{x}$ are internal to our transformation, but their presence is crucial. The distributions of values of any $\widehat{x}$ has the expected value of 0 and the variance of 1 , as long as the elements of each mini-batch are sampled from the same distribution, and if we neglect $\epsilon$ . This can be seen by observing that $\mathop{\sum }\limits_{{i = 1}}^{m}{\widehat{x}}_{i} = 0$ and $\frac{1}{m}\mathop{\sum }\limits_{{i = 1}}^{m}{\widehat{x}}_{i}^{2} = 1$ , and taking expectations. Each normalized activation ${\widehat{x}}^{\left( k\right) }$ can be viewed as an input to a sub-network composed of the linear transform ${y}^{\left( k\right) } = {\gamma }^{\left( k\right) }{\widehat{x}}^{\left( k\right) } + {\beta }^{\left( k\right) }$ , followed by the other processing done by the original network. These sub-network inputs all have fixed means and variances, and although the joint distribution of these normalized ${\widehat{x}}^{\left( k\right) }$ can change over the course of training, we expect that the introduction of normalized inputs accelerates the training of the sub-network and, consequently, the network as a whole.

BN变换可以添加到网络中以操作任意激活。在符号$y = {\mathrm{{BN}}}_{\gamma ,\beta }\left( x\right)$中，我们表示参数$\gamma$和$\beta$是需要学习的，但应注意BN变换并非独立处理每个训练样本的激活。相反，${\mathrm{{BN}}}_{\gamma ,\beta }\left( x\right)$既依赖于训练样本，也依赖于小批量中的其他样本。缩放和平移后的值$y$被传递到网络的其他层。归一化激活$\widehat{x}$是我们变换的内部变量，但其存在至关重要。只要每个小批量的元素均采自相同分布，且忽略$\epsilon$，任何$\widehat{x}$的值分布均值为0，方差为1。这可以通过观察$\mathop{\sum }\limits_{{i = 1}}^{m}{\widehat{x}}_{i} = 0$和$\frac{1}{m}\mathop{\sum }\limits_{{i = 1}}^{m}{\widehat{x}}_{i}^{2} = 1$并取期望值来验证。每个归一化激活${\widehat{x}}^{\left( k\right) }$可视为一个子网络的输入，该子网络由线性变换${y}^{\left( k\right) } = {\gamma }^{\left( k\right) }{\widehat{x}}^{\left( k\right) } + {\beta }^{\left( k\right) }$组成，随后是原网络的其他处理。这些子网络输入均具有固定的均值和方差，尽管这些归一化${\widehat{x}}^{\left( k\right) }$的联合分布在训练过程中可能变化，但我们期望引入归一化输入能加速子网络乃至整个网络的训练。

Input: Values of $x$ over a mini-batch: $\mathcal{B} = \left\{  {x}_{1\ldots m}\right\}$ ;

输入:小批量中$x$的值:$\mathcal{B} = \left\{  {x}_{1\ldots m}\right\}$；

Parameters to be learned: $\gamma ,\beta$

待学习的参数:$\gamma ,\beta$

Output: $\left\{  {{y}_{i} = {\mathrm{{BN}}}_{\gamma ,\beta }\left( {x}_{i}\right) }\right\}$

输出:$\left\{  {{y}_{i} = {\mathrm{{BN}}}_{\gamma ,\beta }\left( {x}_{i}\right) }\right\}$

${\mu }_{\mathcal{B}} \leftarrow  \frac{1}{m}\mathop{\sum }\limits_{{i = 1}}^{m}{x}_{i}\;$ // mini-batch mean

${\mu }_{\mathcal{B}} \leftarrow  \frac{1}{m}\mathop{\sum }\limits_{{i = 1}}^{m}{x}_{i}\;$ // 小批量均值

${\sigma }_{\mathcal{B}}^{2} \leftarrow  \frac{1}{m}\mathop{\sum }\limits_{{i = 1}}^{m}{\left( {x}_{i} - {\mu }_{\mathcal{B}}\right) }^{2}\;$ // mini-batch variance

${\sigma }_{\mathcal{B}}^{2} \leftarrow  \frac{1}{m}\mathop{\sum }\limits_{{i = 1}}^{m}{\left( {x}_{i} - {\mu }_{\mathcal{B}}\right) }^{2}\;$ // 小批量方差

$$
{\widehat{x}}_{i} \leftarrow  \frac{{x}_{i} - {\mu }_{\mathcal{B}}}{\sqrt{{\sigma }_{\mathcal{B}}^{2} + \epsilon }}
$$

Algorithm 1: Batch Normalizing Transform, applied to activation $x$ over a mini-batch.

算法1:批量归一化变换，应用于小批量中的激活$x$。

During training we need to backpropagate the gradient of loss $\ell$ through this transformation, as well as compute the gradients with respect to the parameters of the BN transform. We use chain rule, as follows:

在训练过程中，我们需要通过该变换反向传播损失$\ell$的梯度，同时计算BN变换参数的梯度。我们使用链式法则，具体如下:

$$
\frac{\partial \ell }{\partial {\widehat{x}}_{i}} = \frac{\partial \ell }{\partial {y}_{i}} \cdot  \gamma
$$

$$
\frac{\partial \ell }{\partial {\sigma }_{\mathcal{B}}^{2}} = \mathop{\sum }\limits_{{i = 1}}^{m}\frac{\partial \ell }{\partial {\widehat{x}}_{i}} \cdot  \left( {{x}_{i} - {\mu }_{\mathcal{B}}}\right)  \cdot  \frac{-1}{2}{\left( {\sigma }_{\mathcal{B}}^{2} + \epsilon \right) }^{-3/2}
$$

$$
\frac{\partial \ell }{\partial {\mu }_{\mathcal{B}}} = \mathop{\sum }\limits_{{i = 1}}^{m}\frac{\partial \ell }{\partial {\widehat{x}}_{i}} \cdot  \frac{-1}{\sqrt{{\sigma }_{\mathcal{B}}^{2} + \epsilon }}
$$

$$
\frac{\partial \ell }{\partial {x}_{i}} = \frac{\partial \ell }{\partial {\widehat{x}}_{i}} \cdot  \frac{1}{\sqrt{{\sigma }_{\mathcal{B}}^{2} + \epsilon }} + \frac{\partial \ell }{\partial {\sigma }_{\mathcal{B}}^{2}} \cdot  \frac{2\left( {{x}_{i} - {\mu }_{\mathcal{B}}}\right) }{m} + \frac{\partial \ell }{\partial {\mu }_{\mathcal{B}}} \cdot  \frac{1}{m}
$$

$$
\frac{\partial \ell }{\partial \gamma } = \mathop{\sum }\limits_{{i = 1}}^{m}\frac{\partial \ell }{\partial {y}_{i}} \cdot  {\widehat{x}}_{i}
$$

$$
\frac{\partial \ell }{\partial \beta } = \mathop{\sum }\limits_{{i = 1}}^{m}\frac{\partial \ell }{\partial {y}_{i}}
$$

Thus, BN transform is a differentiable transformation that introduces normalized activations into the network. This ensures that as the model is training, layers can continue learning on input distributions that exhibit less internal covariate shift, thus accelerating the training. Furthermore, the learned affine transform applied to these normalized activations allows the BN transform to represent the identity transformation and preserves the network capacity.

因此，BN变换是一种可微分的变换，将归一化的激活引入网络。这确保了在模型训练时，各层能够在内部协变量偏移较小的输入分布上持续学习，从而加速训练。此外，应用于这些归一化激活的学习仿射变换使BN变换能够表示恒等变换，保持网络容量。

### 3.1. Training and Inference with Batch-Normalized Networks

### 3.1. 使用批量归一化网络的训练与推理

To Batch-Normalize a network, we specify a subset of activations and insert the BN transform for each of them, according to Alg. 1. Any layer that previously received $x$ as the input, now receives $\operatorname{BN}\left( x\right)$ . A model employing Batch Normalization can be trained using batch gradient descent, or Stochastic Gradient Descent with a mini-batch size $m > 1$ , or with any of its variants such as Adagrad (Duchi et al., 2011). The normalization of activations that depends on the mini-batch allows efficient training, but is neither necessary nor desirable during inference; we want the output to depend only on the input, deterministically. For this, once the network has been trained, we use the

为了对网络进行批量归一化，我们指定一部分激活，并根据算法1为每个激活插入BN变换。任何先前以$x$为输入的层，现在接收$\operatorname{BN}\left( x\right)$。采用批量归一化的模型可以使用批量梯度下降，或小批量大小为$m > 1$的随机梯度下降，或其变体如Adagrad(Duchi等，2011)进行训练。依赖小批量的激活归一化实现了高效训练，但在推理阶段既不必要也不理想；我们希望输出仅确定性地依赖于输入。为此，网络训练完成后，我们使用

normalization

归一化

$$
\widehat{x} = \frac{x - \mathrm{E}\left\lbrack  x\right\rbrack  }{\sqrt{\operatorname{Var}\left\lbrack  x\right\rbrack   + \epsilon }}
$$

using the population, rather than mini-batch, statistics. Neglecting $\epsilon$ , these normalized activations have the same mean 0 and variance 1 as during training. We use the unbiased variance estimate $\operatorname{Var}\left\lbrack  x\right\rbrack   = \frac{m}{m - 1} \cdot  {\mathrm{E}}_{\mathcal{B}}\left\lbrack  {\sigma }_{\mathcal{B}}^{2}\right\rbrack$ , where the expectation is over training mini-batches of size $m$ and ${\sigma }_{\mathcal{B}}^{2}$ are their sample variances. Using moving averages instead, we can track the accuracy of a model as it trains. Since the means and variances are fixed during inference, the normalization is simply a linear transform applied to each activation. It may further be composed with the scaling by $\gamma$ and shift by $\beta$ , to yield a single linear transform that replaces $\mathrm{{BN}}\left( x\right)$ . Algorithm 2 summarizes the procedure for training batch-normalized networks.

采用总体统计量而非小批量统计量。忽略$\epsilon$，这些归一化激活在均值0和方差1上与训练时相同。我们使用无偏方差估计$\operatorname{Var}\left\lbrack  x\right\rbrack   = \frac{m}{m - 1} \cdot  {\mathrm{E}}_{\mathcal{B}}\left\lbrack  {\sigma }_{\mathcal{B}}^{2}\right\rbrack$，其中期望值基于大小为$m$的训练小批量，${\sigma }_{\mathcal{B}}^{2}$为其样本方差。改用移动平均，我们可以在训练过程中跟踪模型准确性。由于均值和方差在推理时固定，归一化仅是对每个激活的线性变换。它还可以与缩放$\gamma$和平移$\beta$组合，形成替代$\mathrm{{BN}}\left( x\right)$的单一线性变换。算法2总结了训练批量归一化网络的过程。

### 3.2. Batch-Normalized Convolutional Networks

### 3.2. 批量归一化卷积网络

Batch Normalization can be applied to any set of activations in the network. Here, we focus on transforms that consist of an affine transformation followed by an element-wise nonlinearity:

批量归一化可应用于网络中的任意激活集合。这里，我们关注由仿射变换后接元素级非线性组成的变换:

$$
\mathrm{z} = g\left( {W\mathrm{u} + \mathrm{b}}\right)
$$

where $W$ and $\mathrm{b}$ are learned parameters of the model, and $g\left( \cdot \right)$ is the nonlinearity such as sigmoid or ReLU. This formulation covers both fully-connected and convolutional layers. We add the BN transform immediately before the nonlinearity, by normalizing $\mathrm{x} = W\mathrm{u} + \mathrm{b}$ . We could have also normalized the layer inputs $\mathrm{u}$ , but since $\mathrm{u}$ is likely the output of another nonlinearity, the shape of its distribution is likely to change during training, and constraining its first and second moments would not eliminate the covariate shift. In contrast, $W\mathrm{u} + \mathrm{b}$ is more likely to have a symmetric, non-sparse distribution, that is "more Gaussian" (Hyvärinen & Oja, 2000); normalizing it is likely to produce activations with a stable distribution.

其中$W$和$\mathrm{b}$是模型的学习参数，$g\left( \cdot \right)$是非线性函数，如sigmoid或ReLU。该形式涵盖全连接层和卷积层。我们在非线性之前立即添加BN变换，通过归一化$\mathrm{x} = W\mathrm{u} + \mathrm{b}$实现。我们也可以归一化层输入$\mathrm{u}$，但由于$\mathrm{u}$很可能是另一非线性的输出，其分布形态在训练中可能变化，约束其一阶和二阶矩无法消除协变量偏移。相比之下，$W\mathrm{u} + \mathrm{b}$更可能具有对称、非稀疏的分布，更接近高斯分布(Hyvärinen & Oja, 2000)；归一化它更可能产生分布稳定的激活。

---

Input: Network $N$ with trainable parameters $\Theta$ ;

输入:具有可训练参数$\Theta$的网络$N$；

				subset of activations ${\left\{  {x}^{\left( k\right) }\right\}  }_{k = 1}^{K}$

				激活子集${\left\{  {x}^{\left( k\right) }\right\}  }_{k = 1}^{K}$

Output: Batch-normalized network for inference, ${N}_{\mathrm{{BN}}}^{\text{inf }}$

输出:用于推理的批量归一化网络${N}_{\mathrm{{BN}}}^{\text{inf }}$

		${N}_{\mathrm{{BN}}}^{\mathrm{{tr}}} \leftarrow  N\;$ // Training BN network

		${N}_{\mathrm{{BN}}}^{\mathrm{{tr}}} \leftarrow  N\;$ // 训练BN网络

		for $k = 1\ldots K$ do

		对于$k = 1\ldots K$执行

			Add transformation ${y}^{\left( k\right) } = {\mathrm{{BN}}}_{{\gamma }^{\left( k\right) },{\beta }^{\left( k\right) }}\left( {x}^{\left( k\right) }\right)$ to

			将变换${y}^{\left( k\right) } = {\mathrm{{BN}}}_{{\gamma }^{\left( k\right) },{\beta }^{\left( k\right) }}\left( {x}^{\left( k\right) }\right)$添加到

				${N}_{\mathrm{{BN}}}^{\mathrm{{tr}}}$ (Alg. 1)

				${N}_{\mathrm{{BN}}}^{\mathrm{{tr}}}$(算法1)

			Modify each layer in ${N}_{\mathrm{{BN}}}^{\mathrm{{tr}}}$ with input ${x}^{\left( k\right) }$ to take

			修改${N}_{\mathrm{{BN}}}^{\mathrm{{tr}}}$中的每一层，使其输入为${x}^{\left( k\right) }$，以采用

				${y}^{\left( k\right) }$ instead

				${y}^{\left( k\right) }$代替

		end for

		结束循环

	6: Train ${N}_{\mathrm{{BN}}}^{\mathrm{{tr}}}$ to optimize the parameters

	6:训练${N}_{\mathrm{{BN}}}^{\mathrm{{tr}}}$以优化参数

		$\Theta  \cup  {\left\{  {\gamma }^{\left( k\right) },{\beta }^{\left( k\right) }\right\}  }_{k = 1}^{K}$

	: ${N}_{\mathrm{{BN}}}^{\text{inf }} \leftarrow  {N}_{\mathrm{{BN}}}^{\mathrm{{tr}}}\;$ // Inference BN network with frozen

	:${N}_{\mathrm{{BN}}}^{\text{inf }} \leftarrow  {N}_{\mathrm{{BN}}}^{\mathrm{{tr}}}\;$ // 使用冻结参数进行BN网络推理

											// parameters

											// 参数

		for $k = 1\ldots K$ do

		对于$k = 1\ldots K$执行

			// For clarity, $x \equiv  {x}^{\left( k\right) },\gamma  \equiv  {\gamma }^{\left( k\right) },{\mu }_{\mathcal{B}} \equiv  {\mu }_{\mathcal{B}}^{\left( k\right) }$ , etc.

			// 为了清晰，$x \equiv  {x}^{\left( k\right) },\gamma  \equiv  {\gamma }^{\left( k\right) },{\mu }_{\mathcal{B}} \equiv  {\mu }_{\mathcal{B}}^{\left( k\right) }$等

			Process multiple training mini-batches $\mathcal{B}$ , each of

			处理多个训练小批次$\mathcal{B}$，每个

				size $m$ , and average over them:

				大小为$m$，并对它们求平均:

													$\mathrm{E}\left\lbrack  x\right\rbrack   \leftarrow  {\mathrm{E}}_{\mathcal{B}}\left\lbrack  {\mu }_{\mathcal{B}}\right\rbrack$

												$\operatorname{Var}\left\lbrack  x\right\rbrack   \leftarrow  \frac{m}{m - 1}{\mathrm{E}}_{\mathcal{B}}\left\lbrack  {\sigma }_{\mathcal{B}}^{2}\right\rbrack$

		: $\operatorname{In}{N}_{\mathrm{{BN}}}^{\text{inf }}$ , replace the transform $y = {\mathrm{{BN}}}_{\gamma ,\beta }\left( x\right)$ with

		:$\operatorname{In}{N}_{\mathrm{{BN}}}^{\text{inf }}$，用$y = {\mathrm{{BN}}}_{\gamma ,\beta }\left( x\right)$替换变换

				$y = \frac{\gamma }{\sqrt{\operatorname{Var}\left\lbrack  x\right\rbrack   + \epsilon }} \cdot  x + \left( {\beta  - \frac{\gamma \mathrm{E}\left\lbrack  x\right\rbrack  }{\sqrt{\operatorname{Var}\left\lbrack  x\right\rbrack   + \epsilon }}}\right)$

		end for

		结束循环

	Algorithm 2: Training a Batch-Normalized Network

	算法2:训练批量归一化网络

---

Note that, since we normalize $W\mathrm{u} + \mathrm{b}$ , the bias $\mathrm{b}$ can be ignored since its effect will be canceled by the subsequent mean subtraction (the role of the bias is subsumed by $\beta$ in Alg. 1). Thus, $\mathrm{z} = g\left( {W\mathrm{u} + \mathrm{b}}\right)$ is replaced with

注意，由于我们对$W\mathrm{u} + \mathrm{b}$进行了归一化，偏置$\mathrm{b}$可以忽略，因为其效果会被后续的均值减法抵消(偏置的作用在算法1中被$\beta$所取代)。因此，$\mathrm{z} = g\left( {W\mathrm{u} + \mathrm{b}}\right)$被替换为

$$
\mathrm{z} = g\left( {\mathrm{{BN}}\left( {W\mathrm{u}}\right) }\right)
$$

where the BN transform is applied independently to each dimension of $\mathrm{x} = W\mathrm{u}$ , with a separate pair of learned parameters ${\gamma }^{\left( k\right) },{\beta }^{\left( k\right) }$ per dimension.

BN变换独立地应用于$\mathrm{x} = W\mathrm{u}$的每个维度，每个维度有一对单独学习的参数${\gamma }^{\left( k\right) },{\beta }^{\left( k\right) }$。

For convolutional layers, we additionally want the normalization to obey the convolutional property - so that different elements of the same feature map, at different locations, are normalized in the same way. To achieve this, we jointly normalize all the activations in a mini-batch, over all locations. In Alg. 1, we let $\mathcal{B}$ be the set of all values in a feature map across both the elements of a mini-batch and spatial locations - so for a mini-batch of size $m$ and feature maps of size $p \times  q$ , we use the effective mini-batch of size ${m}^{\prime } = \left| \mathcal{B}\right|  = m \cdot  {pq}$ . We learn a pair of parameters ${\gamma }^{\left( k\right) }$ and ${\beta }^{\left( k\right) }$ per feature map, rather than per activation. Alg. 2 is modified similarly, so that during inference the BN transform applies the same linear transformation to each activation in a given feature map.

对于卷积层，我们还希望归一化满足卷积性质——即同一特征图中不同位置的元素以相同方式归一化。为此，我们在一个小批量中联合归一化所有位置的激活值。在算法1中，我们令$\mathcal{B}$为跨越小批量元素和空间位置的特征图中所有值的集合——因此对于大小为$m$的小批量和大小为$p \times  q$的特征图，我们使用有效小批量大小为${m}^{\prime } = \left| \mathcal{B}\right|  = m \cdot  {pq}$。我们为每个特征图学习一对参数${\gamma }^{\left( k\right) }$和${\beta }^{\left( k\right) }$，而非每个激活值。算法2也做了类似修改，使得推理时BN变换对给定特征图中的每个激活值应用相同的线性变换。

### 3.3. Batch Normalization enables higher learning rates

### 3.3. 批量归一化(Batch Normalization)使更高学习率成为可能

In traditional deep networks, too high a learning rate may result in the gradients that explode or vanish, as well as getting stuck in poor local minima. Batch Normalization helps address these issues. By normalizing activations throughout the network, it prevents small changes in layer parameters from amplifying as the data propagates through a deep network. For example, this enables the sigmoid nonlinearities to more easily stay in their non-saturated regimes, which is crucial for training deep sigmoid networks but has traditionally been hard to accomplish.

在传统深度网络中，过高的学习率可能导致梯度爆炸或消失，以及陷入较差的局部极小值。批量归一化有助于解决这些问题。通过在网络中归一化激活值，它防止了层参数的小幅变化在深层网络中传播时被放大。例如，这使得sigmoid非线性更容易保持在非饱和区间，这对于训练深层sigmoid网络至关重要，但传统上很难实现。

Batch Normalization also makes training more resilient to the parameter scale. Normally, large learning rates may increase the scale of layer parameters, which then amplify the gradient during backpropagation and lead to the model explosion. However, with Batch Normalization, backprop-agation through a layer is unaffected by the scale of its parameters. Indeed, for a scalar $a$ ,

批量归一化还使训练对参数尺度更具鲁棒性。通常，大的学习率可能增加层参数的尺度，进而在反向传播时放大梯度，导致模型爆炸。然而，使用批量归一化后，层的反向传播不受其参数尺度的影响。事实上，对于标量$a$，

$$
\mathrm{{BN}}\left( {W\mathrm{u}}\right)  = \mathrm{{BN}}\left( {\left( {aW}\right) \mathrm{u}}\right)
$$

and thus $\frac{\partial \mathrm{{BN}}\left( {\left( {aW}\right) \mathrm{u}}\right) }{\partial \mathrm{u}} = \frac{\partial \mathrm{{BN}}\left( {W\mathrm{u}}\right) }{\partial \mathrm{u}}$ , so the scale does not affect the layer Jacobian nor, consequently, the gradient propagation. Moreover, $\frac{\partial \mathrm{{BN}}\left( {\left( {aW}\right) \mathrm{u}}\right) }{\partial \left( {aW}\right) } = \frac{1}{a} \cdot  \frac{\partial \mathrm{{BN}}\left( {W\mathrm{u}}\right) }{\partial W}$ , so larger weights lead to smaller gradients, and Batch Normalization will stabilize the parameter growth.

因此$\frac{\partial \mathrm{{BN}}\left( {\left( {aW}\right) \mathrm{u}}\right) }{\partial \mathrm{u}} = \frac{\partial \mathrm{{BN}}\left( {W\mathrm{u}}\right) }{\partial \mathrm{u}}$，尺度不会影响层的雅可比矩阵，也就不会影响梯度传播。此外，$\frac{\partial \mathrm{{BN}}\left( {\left( {aW}\right) \mathrm{u}}\right) }{\partial \left( {aW}\right) } = \frac{1}{a} \cdot  \frac{\partial \mathrm{{BN}}\left( {W\mathrm{u}}\right) }{\partial W}$，因此较大的权重导致较小的梯度，批量归一化将稳定参数增长。

We further conjecture that Batch Normalization may lead the layer Jacobians to have singular values close to 1 , which is known to be beneficial for training (Saxe et al., 2013). Consider two consecutive layers with normalized inputs, and the transformation between these normalized vectors: $\widehat{\mathrm{z}} = F\left( \widehat{\mathrm{x}}\right)$ . If we assume that $\widehat{\mathrm{x}}$ and $\widehat{\mathrm{z}}$ are Gaussian and uncorrelated, and that $F\left( \widehat{\mathrm{x}}\right)  \approx  J\widehat{\mathrm{x}}$ is a linear transformation for the given model parameters, then both $\widehat{\mathrm{x}}$ and $\widehat{\mathrm{z}}$ have unit covariances, and $I = \operatorname{Cov}\left\lbrack  \widehat{\mathrm{z}}\right\rbrack   = J\operatorname{Cov}\left\lbrack  \widehat{\mathrm{x}}\right\rbrack  {J}^{T} = J{J}^{T}$ . Thus, $J$ is orthogonal, which preserves the gradient magnitudes during backpropagation. Although the above assumptions are not true in reality, we expect Batch Normalization to help make gradient propagation better behaved. This remains an area of further study.

我们进一步推测，批量归一化可能使层的雅可比矩阵的奇异值接近1，这已知对训练有益(Saxe等，2013)。考虑两个连续层的归一化输入，以及这些归一化向量之间的变换:$\widehat{\mathrm{z}} = F\left( \widehat{\mathrm{x}}\right)$。如果假设$\widehat{\mathrm{x}}$和$\widehat{\mathrm{z}}$是高斯且不相关的，且$F\left( \widehat{\mathrm{x}}\right)  \approx  J\widehat{\mathrm{x}}$是给定模型参数的线性变换，那么$\widehat{\mathrm{x}}$和$\widehat{\mathrm{z}}$均具有单位协方差，且$I = \operatorname{Cov}\left\lbrack  \widehat{\mathrm{z}}\right\rbrack   = J\operatorname{Cov}\left\lbrack  \widehat{\mathrm{x}}\right\rbrack  {J}^{T} = J{J}^{T}$。因此，$J$是正交的，这在反向传播时保持梯度幅度。尽管上述假设在现实中不完全成立，我们仍期望批量归一化有助于改善梯度传播的稳定性。这仍是一个值得进一步研究的领域。

## 4. Experiments

## 4. 实验

### 4.1. Activations over time

### 4.1. 激活随时间的变化

To verify the effects of internal covariate shift on training, and the ability of Batch Normalization to combat it, we considered the problem of predicting the digit class on the MNIST dataset (LeCun et al., 1998a). We used a very simple network, with a ${28} \times  {28}$ binary image as input, and 3 fully-connected hidden layers with 100 activations each. Each hidden layer computes $\mathrm{y} = g\left( {W\mathrm{u} + \mathrm{b}}\right)$ with sigmoid nonlinearity, and the weights $W$ initialized to small random Gaussian values. The last hidden layer is followed by a fully-connected layer with 10 activations (one per class) and cross-entropy loss. We trained the network for 50000 steps, with 60 examples per mini-batch. We added Batch Normalization to each hidden layer of the network, as in Sec. 3.1. We were interested in the comparison between the baseline and batch-normalized networks, rather than achieving the state of the art performance on MNIST (which the described architecture does not).

为了验证内部协变量偏移(internal covariate shift)对训练的影响，以及批量归一化(Batch Normalization)抵抗该问题的能力，我们考虑了在MNIST数据集(LeCun等，1998a)上预测数字类别的问题。我们使用了一个非常简单的网络，输入为${28} \times  {28}$二值图像，包含3个全连接隐藏层，每层有100个激活单元。每个隐藏层计算$\mathrm{y} = g\left( {W\mathrm{u} + \mathrm{b}}\right)$，采用sigmoid非线性激活，权重$W$初始化为小的随机高斯值。最后一个隐藏层后接一个具有10个激活单元(对应10个类别)的全连接层，并使用交叉熵损失。我们训练网络50000步，每个小批量包含60个样本。我们在网络的每个隐藏层中加入了批量归一化，如第3.1节所述。我们关注的是基线网络与批量归一化网络之间的比较，而非在MNIST上达到最先进的性能(所述架构无法实现)。

![bo_d1c3p1jef24c73d2oju0_5_156_189_693_203_0.jpg](images/bo_d1c3p1jef24c73d2oju0_5_156_189_693_203_0.jpg)

Figure 1. (a) The test accuracy of the MNIST network trained with and without Batch Normalization, vs. the number of training steps. Batch Normalization helps the network train faster and achieve higher accuracy. (b, c) The evolution of input distributions to a typical sigmoid, over the course of training, shown as $\{ {15},{50},{85}\}$ th percentiles. Batch Normalization makes the distribution more stable and reduces the internal covariate shift.

图1。(a)MNIST网络在有无批量归一化情况下的测试准确率，随训练步数变化。批量归一化帮助网络更快训练并达到更高准确率。(b，c)训练过程中典型sigmoid输入分布的演变，以$\{ {15},{50},{85}\}$百分位数表示。批量归一化使分布更稳定，减少了内部协变量偏移。

Figure 1(a) shows the fraction of correct predictions by the two networks on held-out test data, as training progresses. The batch-normalized network enjoys the higher test accuracy. To investigate why, we studied inputs to the sigmoid, in the original network $N$ and batch-normalized network ${N}_{\mathrm{{BN}}}^{\mathrm{{tr}}}$ (Alg. 2) over the course of training. In Fig. 1(b, c) we show, for one typical activation from the last hidden layer of each network, how its distribution evolves. The distributions in the original network change significantly over time, both in their mean and the variance, which complicates the training of the subsequent layers. In contrast, the distributions in the batch-normalized network are much more stable as training progresses, which aids the training.

图1(a)展示了两个网络在保留测试数据上的正确预测比例，随训练进展变化。批量归一化网络拥有更高的测试准确率。为探究原因，我们研究了训练过程中原始网络$N$和批量归一化网络${N}_{\mathrm{{BN}}}^{\mathrm{{tr}}}$(算法2)中sigmoid的输入。在图1(b, c)中，我们展示了每个网络最后隐藏层一个典型激活单元的分布演变。原始网络的分布随时间显著变化，均值和方差均有波动，增加了后续层训练的难度。相比之下，批量归一化网络的分布在训练过程中更为稳定，有助于训练。

### 4.2. ImageNet classification

### 4.2. ImageNet分类

We applied Batch Normalization to a new variant of the Inception network (Szegedy et al., 2014), trained on the Im-ageNet classification task (Russakovsky et al., 2014). The network has a large number of convolutional and pooling layers, with a softmax layer to predict the image class, out of 1000 possibilities. Convolutional layers use ReLU as the nonlinearity. The main difference to the network described in (Szegedy et al.,2014) is that the $5 \times  5$ convolutional layers are replaced by two consecutive layers of $3 \times  3$ convolutions with up to 128 filters. The network contains ${13.6} \cdot  {10}^{6}$ parameters, and, other than the top softmax layer, has no fully-connected layers. We refer to this model as Inception in the rest of the text. The training was performed on a large-scale, distributed architecture (Dean et al., 2012), using 5 concurrent steps on each of 10 model replicas, using asynchronous SGD with momentum (Sutskever et al., 2013), with the mini-batch size of 32. All networks are evaluated as training progresses by computing the validation accuracy $@1$ , i.e. the probability of predicting the correct label out of 1000 possibilities, on a held-out set, using a single crop per image.

我们将批量归一化应用于Inception网络(Szegedy等，2014)的一个新变体，训练于ImageNet分类任务(Russakovsky等，2014)。该网络包含大量卷积和池化层，最后通过softmax层预测1000个类别中的图像类别。卷积层采用ReLU非线性。与(Szegedy等，2014)中描述的网络主要区别在于，$5 \times  5$卷积层被替换为两个连续的$3 \times  3$卷积层，滤波器数量最多为128。该网络包含${13.6} \cdot  {10}^{6}$参数，除顶层softmax外无全连接层。本文其余部分称该模型为Inception。训练在大规模分布式架构(Dean等，2012)上进行，使用10个模型副本，每个副本并行执行5个步骤，采用带动量的异步SGD(Sutskever等，2013)，小批量大小为32。所有网络在训练过程中通过计算验证准确率$@1$进行评估，即在保留集上使用每张图像单次裁剪，预测正确标签的概率(1000类)。

In our experiments, we evaluated several modifications of Inception with Batch Normalization. In all cases, Batch Normalization was applied to the input of each nonlinearity, in a convolutional way, as described in section 3.2, while keeping the rest of the architecture constant.

在我们的实验中，评估了多种带批量归一化的Inception变体。所有情况下，批量归一化均应用于每个非线性激活输入，采用卷积方式，如第3.2节所述，其余架构保持不变。

#### 4.2.1. ACCELERATING BN NETWORKS

#### 4.2.1. 加速批量归一化网络

Simply adding Batch Normalization to a network does not take full advantage of our method. To do so, we applied the following modifications:

仅仅在网络中加入批量归一化并不能充分发挥该方法的优势。为此，我们进行了以下修改:

Increase learning rate. In a batch-normalized model, we have been able to achieve a training speedup from higher learning rates, with no ill side effects (Sec. 3.3).

提高学习率。在批量归一化模型中，我们能够通过更高的学习率实现训练加速，且无不良副作用(见第3.3节)。

Remove Dropout. We have found that removing Dropout from BN-Inception allows the network to achieve higher validation accuracy. We conjecture that Batch Normalization provides similar regularization benefits as Dropout, since the activations observed for a training example are affected by the random selection of examples in the same mini-batch.

去除Dropout。我们发现从BN-Inception中去除Dropout可以使网络获得更高的验证准确率。我们推测批量归一化(Batch Normalization)提供了与Dropout类似的正则化效果，因为训练样本的激活值会受到同一小批量中随机选择样本的影响。

Shuffle training examples more thoroughly. We enabled within-shard shuffling of the training data, which prevents the same examples from always appearing in a mini-batch together. This led to about $1\%$ improvement in the validation accuracy, which is consistent with the view of Batch Normalization as a regularizer: the randomization inherent in our method should be most beneficial when it affects an example differently each time it is seen.

更彻底地打乱训练样本。我们启用了训练数据的分片内打乱，防止相同样本总是一起出现在同一小批量中。这使验证准确率提升了约$1\%$，这与将批量归一化视为正则化器的观点一致:我们方法中固有的随机性在每次样本被看到时产生不同影响，因而最为有效。

Reduce the ${L}_{2}$ weight regularization. While in Inception an ${L}_{2}$ loss on the model parameters controls overfitting, in modified BN-Inception the weight of this loss is reduced by a factor of 5 . We find that this improves the accuracy on the held-out validation data.

减少${L}_{2}$权重正则化。在Inception中，模型参数上的${L}_{2}$损失用于控制过拟合，而在改进的BN-Inception中，该损失的权重降低了5倍。我们发现这提升了保留验证集上的准确率。

Accelerate the learning rate decay. In training Inception, learning rate was decayed exponentially. Because our network trains faster than Inception, we lower the learning rate 6 times faster.

加快学习率衰减。在训练Inception时，学习率采用指数衰减。由于我们的网络训练速度快于Inception，我们将学习率降低速度提高了6倍。

Remove Local Response Normalization While Inception and other networks (Srivastava et al., 2014) benefit from it, we found that with Batch Normalization it is not necessary.

去除局部响应归一化。虽然Inception和其他网络(Srivastava等，2014)从中受益，但我们发现使用批量归一化后，这一步骤已无必要。

Reduce the photometric distortions. Because batch-normalized networks train faster and observe each training example fewer times, we let the trainer focus on more "real" images by distorting them less.

减少光度畸变。由于批量归一化网络训练更快且每个训练样本被观察的次数更少，我们让训练者通过减少图像畸变，更多关注“真实”图像。

![bo_d1c3p1jef24c73d2oju0_6_174_189_696_397_0.jpg](images/bo_d1c3p1jef24c73d2oju0_6_174_189_696_397_0.jpg)

Figure 2. Single crop validation accuracy of Inception and its batch-normalized variants, vs. the number of training steps.

图2. Inception及其批量归一化变体的单裁剪验证准确率与训练步数的关系。

#### 4.2.2. SINGLE-NETWORK CLASSIFICATION

#### 4.2.2. 单网络分类

We evaluated the following networks, all trained on the LSVRC2012 training data, and tested on the validation data:

我们评估了以下网络，均在LSVRC2012训练数据上训练，并在验证数据上测试:

Inception: the network described at the beginning of Section 4.2, trained with the initial learning rate of 0.0015 .

Inception:第4.2节开头描述的网络，初始学习率为0.0015。

${BN}$ -Baseline: Same as Inception with Batch Normalization before each nonlinearity.

${BN}$ -基线:与Inception相同，但在每个非线性激活前加入了批量归一化(Batch Normalization)。

${BN} - {x5}$ : Inception with Batch Normalization and the modifications in Sec. 4.2.1. The initial learning rate was increased by a factor of 5 , to 0.0075 . The same learning rate increase with original Inception caused the model parameters to reach machine infinity.

${BN} - {x5}$ :Inception加上批量归一化及第4.2.1节中的修改。初始学习率提高了5倍，达到0.0075。对原始Inception使用同样的学习率提升会导致模型参数溢出至无穷大。

${BN} - {x30}$ : Like ${BN} - {x5}$ , but with the initial learning rate 0.045 (30 times that of Inception).

${BN} - {x30}$ :类似于${BN} - {x5}$，但初始学习率为0.045(是Inception的30倍)。

${BN} - {x5}$ -Sigmoid: Like ${BN} - {x5}$ , but with sigmoid nonlinearity $g\left( t\right)  = \frac{1}{1 + \exp \left( {-x}\right) }$ instead of ReLU. We also attempted to train the original Inception with sigmoid, but the model remained at the accuracy equivalent to chance.

${BN} - {x5}$ -Sigmoid:类似于${BN} - {x5}$，但使用Sigmoid非线性激活$g\left( t\right)  = \frac{1}{1 + \exp \left( {-x}\right) }$替代ReLU。我们也尝试用Sigmoid训练原始Inception，但模型准确率始终停留在随机水平。

In Figure 2, we show the validation accuracy of the networks, as a function of the number of training steps. Inception reached the accuracy of ${72.2}\%$ after ${31} \cdot  {10}^{6}$ training steps. The Figure 3 shows, for each network, the number of training steps required to reach the same 72.2% accuracy, as well as the maximum validation accuracy reached by the network and the number of steps to reach it.

图2展示了各网络的验证准确率随训练步数的变化。Inception在${31} \cdot  {10}^{6}$训练步后达到${72.2}\%$的准确率。图3显示了每个网络达到相同72.2%准确率所需的训练步数，以及网络达到的最高验证准确率和达到该准确率所需的步数。

By only using Batch Normalization (BN-Baseline), we match the accuracy of Inception in less than half the number of training steps. By applying the modifications in Sec. 4.2.1, we significantly increase the training speed of the network. ${BN} - {x5}$ needs 14 times fewer steps than Inception to reach the ${72.2}\%$ accuracy. Interestingly, increasing the learning rate further(BN - x30)causes the model to train somewhat slower initially, but allows it to reach a higher final accuracy. This phenomenon is counterintuitive and should be investigated further. ${BN} - {x30}$ reaches ${74.8}\%$ after $6 \cdot  {10}^{6}$ steps, i.e. 5 times fewer steps than required by Inception to reach 72.2%.

仅使用批量归一化(BN-基线)，我们在不到一半的训练步数内达到了Inception的准确率。通过应用第4.2.1节的修改，显著提升了网络的训练速度。${BN} - {x5}$达到${72.2}\%$准确率所需的步数比Inception少14倍。有趣的是，进一步提高学习率(BN - x30)使模型初期训练速度稍慢，但最终能达到更高的准确率。这一现象反直觉，值得进一步研究。${BN} - {x30}$在$6 \cdot  {10}^{6}$步后达到${74.8}\%$，即所需步数是Inception达到72.2%的五分之一。

<table><tr><td>Model</td><td>Steps to 72.2%</td><td>Max accuracy</td></tr><tr><td>Inception</td><td>${31.0} \cdot  {10}^{6}$</td><td>72.2%</td></tr><tr><td>BN-Baseline</td><td>${13.3} \cdot  {10}^{6}$</td><td>72.7%</td></tr><tr><td>${BN} - {x5}$</td><td>${2.1} \cdot  {10}^{6}$</td><td>73.0%</td></tr><tr><td>BN-x30</td><td>${2.7} \cdot  {10}^{6}$</td><td>74.8%</td></tr><tr><td>BN-x5-Sigmoid</td><td/><td>69.8%</td></tr></table>

<table><tbody><tr><td>模型</td><td>达到72.2%的步骤数</td><td>最高准确率</td></tr><tr><td>Inception(卷积神经网络架构)</td><td>${31.0} \cdot  {10}^{6}$</td><td>72.2%</td></tr><tr><td>BN-基线</td><td>${13.3} \cdot  {10}^{6}$</td><td>72.7%</td></tr><tr><td>${BN} - {x5}$</td><td>${2.1} \cdot  {10}^{6}$</td><td>73.0%</td></tr><tr><td>BN-x30</td><td>${2.7} \cdot  {10}^{6}$</td><td>74.8%</td></tr><tr><td>BN-x5- Sigmoid(激活函数)</td><td></td><td>69.8%</td></tr></tbody></table>

Figure 3. For Inception and the batch-normalized variants, the number of training steps required to reach the maximum accuracy of Inception (72.2%), and the maximum accuracy achieved by the network.

图3. 对于Inception及其批量归一化变体，达到Inception最大准确率(72.2%)所需的训练步数，以及网络达到的最大准确率。

We also verified that the reduction in internal covariate shift allows deep networks with Batch Normalization to be trained when sigmoid is used as the nonlinearity, despite the well-known difficulty of training such networks. Indeed, ${BN} - {x5}$ -Sigmoid achieves the accuracy of ${69.8}\%$ . Without Batch Normalization, Inception with sigmoid never achieves better than 1/1000 accuracy.

我们还验证了内部协变量偏移的减少使得使用sigmoid作为非线性激活函数时，带有批量归一化的深度网络能够被训练，尽管众所周知训练此类网络存在困难。事实上，${BN} - {x5}$-Sigmoid达到了${69.8}\%$的准确率。没有批量归一化，使用sigmoid的Inception准确率从未超过千分之一。

#### 4.2.3. ENSEMBLE CLASSIFICATION

#### 4.2.3. 集成分类

The current reported best results on the ImageNet Large Scale Visual Recognition Competition are reached by the Deep Image ensemble of traditional models (Wu et al., 2015) and the ensemble model of (He et al., 2015). The latter reports the top-5 error of ${4.94}\%$ , as evaluated by the ILSVRC test server. Here we report a test error of 4.82% on test server. This improves upon the previous best result, and exceeds the estimated accuracy of human raters according to (Russakovsky et al., 2014).

目前ImageNet大规模视觉识别竞赛(ILSVRC)报告的最佳结果由传统模型的Deep Image集成(Wu等，2015)和(He等，2015)的集成模型获得。后者报告的top-5错误率为${4.94}\%$，由ILSVRC测试服务器评估。这里我们报告测试服务器上的测试错误率为4.82%。这优于之前的最佳结果，并且超过了(Russakovsky等，2014)估计的人类评审准确率。

For our ensemble, we used 6 networks. Each was based on ${BN} - {x30}$ , modified via some of the following: increased initial weights in the convolutional layers; using Dropout (with the Dropout probability of $5\%$ or ${10}\%$ , vs. ${40}\%$ for the original Inception); and using non-convolutional Batch Normalization with last hidden layers of the model. Each network achieved its maximum accuracy after about $6 \cdot  {10}^{6}$ training steps. The ensemble prediction was based on the arithmetic average of class probabilities predicted by the constituent networks. The details of ensemble and multi-crop inference are similar to (Szegedy et al., 2014).

对于我们的集成，我们使用了6个网络。每个网络基于${BN} - {x30}$，通过以下一些方式进行修改:增加卷积层的初始权重；使用Dropout(Dropout概率为$5\%$或${10}\%$，而原始Inception为${40}\%$)；以及在模型的最后隐藏层使用非卷积的批量归一化。每个网络在大约$6 \cdot  {10}^{6}$训练步后达到最大准确率。集成预测基于组成网络预测的类别概率的算术平均。集成和多裁剪推理的细节类似于(Szegedy等，2014)。

We demonstrate in Fig. 4 that batch normalization allows us to set new state-of-the-art on the ImageNet classification challenge benchmarks.

我们在图4中展示了批量归一化使我们能够在ImageNet分类挑战基准上设定新的最先进水平。

<table><tr><td>Model</td><td>Resolution</td><td>Crops</td><td>Models</td><td>Top-1 error</td><td>Top-5 error</td></tr><tr><td>GoogLeNet ensemble</td><td>224</td><td>144</td><td>7</td><td>-</td><td>6.67%</td></tr><tr><td>Deep Image low-res</td><td>256</td><td>-</td><td>1</td><td>-</td><td>7.96%</td></tr><tr><td>Deep Image high-res</td><td>512</td><td>-</td><td>1</td><td>24.88</td><td>7.42%</td></tr><tr><td>Deep Image ensemble</td><td>up to 512</td><td>-</td><td>-</td><td>-</td><td>5.98%</td></tr><tr><td>MSRA multicrop</td><td>up to 480</td><td>-</td><td>-</td><td>-</td><td>5.71%</td></tr><tr><td>MSRA ensemble</td><td>up to 480</td><td>-</td><td>-</td><td>-</td><td>4.94%*</td></tr><tr><td>BN-Inception single crop</td><td>224</td><td>1</td><td>1</td><td>25.2%</td><td>7.82%</td></tr><tr><td>BN-Inception multicrop</td><td>224</td><td>144</td><td>1</td><td>21.99%</td><td>5.82%</td></tr><tr><td>BN-Inception ensemble</td><td>224</td><td>144</td><td>6</td><td>20.1%</td><td>4.82%*</td></tr></table>

<table><tbody><tr><td>模型</td><td>分辨率</td><td>裁剪</td><td>模型</td><td>Top-1 错误率</td><td>Top-5 错误率</td></tr><tr><td>GoogLeNet 集成</td><td>224</td><td>144</td><td>7</td><td>-</td><td>6.67%</td></tr><tr><td>Deep Image 低分辨率</td><td>256</td><td>-</td><td>1</td><td>-</td><td>7.96%</td></tr><tr><td>Deep Image 高分辨率</td><td>512</td><td>-</td><td>1</td><td>24.88</td><td>7.42%</td></tr><tr><td>Deep Image 集成</td><td>最高512</td><td>-</td><td>-</td><td>-</td><td>5.98%</td></tr><tr><td>MSRA 多裁剪</td><td>最高480</td><td>-</td><td>-</td><td>-</td><td>5.71%</td></tr><tr><td>MSRA 集成</td><td>最高480</td><td>-</td><td>-</td><td>-</td><td>4.94%*</td></tr><tr><td>BN-Inception 单裁剪</td><td>224</td><td>1</td><td>1</td><td>25.2%</td><td>7.82%</td></tr><tr><td>BN-Inception 多裁剪</td><td>224</td><td>144</td><td>1</td><td>21.99%</td><td>5.82%</td></tr><tr><td>BN-Inception 集成</td><td>224</td><td>144</td><td>6</td><td>20.1%</td><td>4.82%*</td></tr></tbody></table>

Figure 4. Batch-Normalized Inception comparison with previous state of the art on the provided validation set comprising 50000 images. *Ensemble results are test server evaluation results on the test set. The BN-Inception ensemble has reached 4.9% top-5 error on the 50000 images of the validation set. All other reported results are on the validation set.

图4. Batch-Normalized Inception与之前在提供的包含50000张图像的验证集上的最新技术的比较。*集成结果为测试服务器在测试集上的评估结果。BN-Inception集成在验证集的50000张图像上达到了4.9%的top-5错误率。所有其他报告的结果均基于验证集。

## 5. Conclusion

## 5. 结论

We have presented a novel mechanism for dramatically accelerating the training of deep networks. It is based on the premise that covariate shift, which is known to complicate the training of machine learning systems, also applies to sub-networks and layers, and removing it from internal activations of the network may aid in training. Our proposed method draws its power from normalizing activations, and from incorporating this normalization in the network architecture itself. This ensures that the normalization is appropriately handled by any optimization method that is being used to train the network. To enable stochastic optimization methods commonly used in deep network training, we perform the normalization for each mini-batch, and back-propagate the gradients through the normalization parameters. Batch Normalization adds only two extra parameters per activation, and in doing so preserves the representation ability of the network. We presented an algorithm for constructing, training, and performing inference with batch-normalized networks. The resulting networks can be trained with saturating nonlinearities, are more tolerant to increased training rates, and often do not require Dropout for regularization.

我们提出了一种显著加速深度网络训练的新机制。其基于这样一个前提:协变量偏移(covariate shift)，众所周知会使机器学习系统的训练复杂化，也同样适用于子网络和层级，从网络内部激活中消除这种偏移可能有助于训练。我们的方法的核心在于对激活进行归一化，并将这种归一化集成到网络架构中。这确保了归一化能够被用于训练网络的任何优化方法适当处理。为了支持深度网络训练中常用的随机优化方法，我们对每个小批量(mini-batch)执行归一化，并通过归一化参数反向传播梯度。Batch Normalization每个激活仅增加两个额外参数，同时保持了网络的表达能力。我们提出了构建、训练及推理批归一化网络的算法。所得网络可使用饱和非线性函数训练，对提高训练速率更具容忍性，且通常不需要Dropout进行正则化。

Merely adding Batch Normalization to a state-of-the-art image classification model yields a substantial speedup in training. By further increasing the learning rates, removing Dropout, and applying other modifications afforded by Batch Normalization, we reach the previous state of the art with only a small fraction of training steps - and then beat the state of the art in single-network image classification. Furthermore, by combining multiple models trained with Batch Normalization, we perform better than the best known system on ImageNet, by a significant margin.

仅仅在最先进的图像分类模型中加入Batch Normalization，就能显著加快训练速度。通过进一步提高学习率、去除Dropout以及应用Batch Normalization带来的其他改进，我们仅用极少的训练步骤就达到了之前的最先进水平——随后在单网络图像分类中超越了最先进水平。此外，通过结合多个使用Batch Normalization训练的模型，我们在ImageNet上显著优于已知的最佳系统。

Our method bears similarity to the standardization layer of (Gülçehre & Bengio, 2013), though the two address different goals. Batch Normalization seeks a stable distribution of activation values throughout training, and normalizes the inputs of a nonlinearity since that is where matching the moments is more likely to stabilize the distribution. On the contrary, the standardization layer is applied to the output of the nonlinearity, which results in sparser activations. We have not observed the nonlinearity inputs to be sparse, neither with nor without Batch Normalization. Other notable differences of Batch Normalization include the learned scale and shift that allow the BN transform to represent identity, handling of convolutional layers, and deterministic inference that does not depend on the mini-batch.

我们的方法与(Gülçehre & Bengio, 2013)中的标准化层有相似之处，但两者目标不同。Batch Normalization旨在训练过程中保持激活值的稳定分布，并对非线性函数的输入进行归一化，因为在此处匹配矩更可能稳定分布。相反，标准化层应用于非线性函数的输出，导致激活更稀疏。我们未观察到无论是否使用Batch Normalization，非线性输入呈现稀疏性。Batch Normalization的其他显著区别包括可学习的缩放和平移参数，使BN变换能表示恒等变换，卷积层的处理，以及不依赖小批量的确定性推理。

In this work, we have not explored the full range of possibilities that Batch Normalization potentially enables. Our future work includes applications of our method to Recurrent Neural Networks (Pascanu et al., 2013), where the internal covariate shift and the vanishing or exploding gradients may be especially severe, and which would allow us to more thoroughly test the hypothesis that normalization improves gradient propagation (Sec. 3.3). More study is needed of the regularization properties of Batch Normalization, which we believe to be responsible for the improvements we have observed when Dropout is removed from BN-Inception. We plan to investigate whether Batch Normalization can help with domain adaptation, in its traditional sense - i.e. whether the normalization performed by the network would allow it to more easily generalize to new data distributions, perhaps with just a recomputation of the population means and variances (Alg. 2). Finally, we believe that further theoretical analysis of the algorithm would allow still more improvements and applications.

在本工作中，我们尚未探索Batch Normalization可能带来的全部潜力。未来工作包括将该方法应用于循环神经网络(Recurrent Neural Networks，Pascanu等，2013)，其中内部协变量偏移及梯度消失或爆炸问题尤为严重，这将使我们更全面地验证归一化改善梯度传播的假设(第3.3节)。还需进一步研究Batch Normalization的正则化特性，我们认为这正是去除BN-Inception中Dropout后性能提升的原因。我们计划探讨Batch Normalization是否能帮助传统意义上的领域适应——即网络执行的归一化是否能使其更容易泛化到新的数据分布，或许只需重新计算总体均值和方差(算法2)。最后，我们相信对该算法的进一步理论分析将带来更多改进和应用。

## Acknowledgments

## 致谢

We thank Vincent Vanhoucke and Jay Yagnik for help and discussions, and the reviewers for insightful comments. References

感谢Vincent Vanhoucke和Jay Yagnik的帮助与讨论，感谢评审专家的宝贵意见。参考文献

Bengio, Yoshua and Glorot, Xavier. Understanding the difficulty of training deep feedforward neural networks. In Proceedings of AISTATS 2010, volume 9, pp. 249-256, May 2010.

Bengio, Yoshua 和 Glorot, Xavier. 理解深度前馈神经网络训练的难点。发表于AISTATS 2010会议论文集，第9卷，第249-256页，2010年5月。

Dean, Jeffrey, Corrado, Greg S., Monga, Rajat, Chen, Kai, Devin, Matthieu, Le, Quoc V., Mao, Mark Z., Ranzato, Marc'Aurelio, Senior, Andrew, Tucker, Paul, Yang, Ke, and Ng, Andrew Y. Large scale distributed deep networks. In NIPS, 2012.

Dean, Jeffrey, Corrado, Greg S., Monga, Rajat, Chen, Kai, Devin, Matthieu, Le, Quoc V., Mao, Mark Z., Ranzato, Marc'Aurelio, Senior, Andrew, Tucker, Paul, Yang, Ke, 和 Ng, Andrew Y. 大规模分布式深度网络。发表于NIPS，2012年。

Desjardins, Guillaume and Kavukcuoglu, Koray. Natural neural networks. (unpublished).

Desjardins, Guillaume 和 Kavukcuoglu, Koray. 自然神经网络。(未发表)。

Duchi, John, Hazan, Elad, and Singer, Yoram. Adaptive subgradient methods for online learning and stochastic optimization. J. Mach. Learn. Res., 12:2121-2159, July 2011. ISSN 1532-4435.

Duchi, John, Hazan, Elad, 和 Singer, Yoram. 用于在线学习和随机优化的自适应子梯度方法。机器学习研究杂志(J. Mach. Learn. Res.)，第12卷:2121-2159，2011年7月。ISSN 1532-4435。

Gülçehre, Çaglar and Bengio, Yoshua. Knowledge matters: Importance of prior information for optimization. CoRR, abs/1301.4083, 2013.

Gülçehre, Çaglar 和 Bengio, Yoshua. 知识的重要性:先验信息对优化的影响。CoRR, abs/1301.4083, 2013。

He, K., Zhang, X., Ren, S., and Sun, J. Delving Deep into Rectifiers: Surpassing Human-Level Performance on ImageNet Classification. ArXiv e-prints, February 2015.

He, K., Zhang, X., Ren, S., 和 Sun, J. 深入研究整流函数:超越人类水平的ImageNet分类性能。ArXiv电子预印本，2015年2月。

Hyvärinen, A. and Oja, E. Independent component analysis: Algorithms and applications. Neural Netw., 13(4-5): 411-430, May 2000.

Hyvärinen, A. 和 Oja, E. 独立成分分析(Independent Component Analysis):算法与应用。神经网络(Neural Netw.)，13(4-5): 411-430，2000年5月。

Jiang, Jing. A literature survey on domain adaptation of statistical classifiers, 2008.

Jiang, Jing. 统计分类器领域适应的文献综述，2008年。

LeCun, Y., Bottou, L., Bengio, Y., and Haffner, P. Gradient-based learning applied to document recognition. Proceedings of the IEEE, 86(11):2278-2324, November 1998a.

LeCun, Y., Bottou, L., Bengio, Y., 和 Haffner, P. 基于梯度的学习在文档识别中的应用。IEEE学报，86(11):2278-2324，1998年11月a。

LeCun, Y., Bottou, L., Orr, G., and Muller, K. Efficient backprop. In Orr, G. and K., Muller (eds.), Neural Networks: Tricks of the trade. Springer, 1998b.

LeCun, Y., Bottou, L., Orr, G., 和 Muller, K. 高效的反向传播。在Orr, G. 和 K. Muller(编)，神经网络:实用技巧。Springer，1998年b。

Lyu, S and Simoncelli, E P. Nonlinear image representation using divisive normalization. In Proc. Computer Vision and Pattern Recognition, pp. 1-8. IEEE Computer Society, Jun 23-28 2008. doi: 10.1109/CVPR.2008.4587821.

Lyu, S 和 Simoncelli, E P. 使用除法归一化的非线性图像表示。计算机视觉与模式识别会议论文集，页1-8。IEEE计算机学会，2008年6月23-28日。doi: 10.1109/CVPR.2008.4587821。

Nair, Vinod and Hinton, Geoffrey E. Rectified linear units improve restricted boltzmann machines. In ICML, pp. 807-814. Omnipress, 2010.

Nair, Vinod 和 Hinton, Geoffrey E. 修正线性单元(Rectified Linear Units)提升受限玻尔兹曼机性能。国际机器学习大会(ICML)，页807-814。Omnipress，2010年。

Pascanu, Razvan, Mikolov, Tomas, and Bengio, Yoshua. On the difficulty of training recurrent neural networks. In Proceedings of the 30th International Conference on Machine Learning, ICML 2013, Atlanta, GA, USA, 16- 21 June 2013, pp. 1310-1318, 2013.

Pascanu, Razvan, Mikolov, Tomas, 和 Bengio, Yoshua. 训练循环神经网络的难点。第30届国际机器学习大会(ICML 2013)论文集，美国亚特兰大，2013年6月16-21日，页1310-1318，2013年。

Povey, Daniel, Zhang, Xiaohui, and Khudanpur, Sanjeev. Parallel training of deep neural networks with natural gradient and parameter averaging. CoRR, abs/1410.7455, 2014.

Povey, Daniel, Zhang, Xiaohui, 和 Khudanpur, Sanjeev. 使用自然梯度和参数平均的深度神经网络并行训练。CoRR, abs/1410.7455, 2014。

Raiko, Tapani, Valpola, Harri, and LeCun, Yann. Deep learning made easier by linear transformations in per-ceptrons. In International Conference on Artificial Intelligence and Statistics (AISTATS), pp. 924-932, 2012.

Raiko, Tapani, Valpola, Harri, 和 LeCun, Yann. 通过感知器中的线性变换简化深度学习。人工智能与统计国际会议(AISTATS)，页924-932，2012年。

Russakovsky, Olga, Deng, Jia, Su, Hao, Krause, Jonathan, Satheesh, Sanjeev, Ma, Sean, Huang, Zhiheng, Karpa-thy, Andrej, Khosla, Aditya, Bernstein, Michael, Berg, Alexander C., and Fei-Fei, Li. ImageNet Large Scale Visual Recognition Challenge, 2014.

Russakovsky, Olga, Deng, Jia, Su, Hao, Krause, Jonathan, Satheesh, Sanjeev, Ma, Sean, Huang, Zhiheng, Karpathy, Andrej, Khosla, Aditya, Bernstein, Michael, Berg, Alexander C., 和 Fei-Fei, Li. ImageNet大规模视觉识别挑战赛，2014年。

Saxe, Andrew M., McClelland, James L., and Ganguli, Surya. Exact solutions to the nonlinear dynamics of learning in deep linear neural networks. CoRR, abs/1312.6120, 2013.

Saxe, Andrew M., McClelland, James L., 和 Ganguli, Surya. 深度线性神经网络学习非线性动力学的精确解。CoRR, abs/1312.6120, 2013。

Shimodaira, Hidetoshi. Improving predictive inference under covariate shift by weighting the log-likelihood function. Journal of Statistical Planning and Inference, 90 (2):227-244, October 2000.

Shimodaira, Hidetoshi. 通过加权对数似然函数改善协变量偏移下的预测推断。统计规划与推断杂志(Journal of Statistical Planning and Inference)，90(2):227-244，2000年10月。

Srivastava, Nitish, Hinton, Geoffrey, Krizhevsky, Alex, Sutskever, Ilya, and Salakhutdinov, Ruslan. Dropout: A simple way to prevent neural networks from overfitting. J. Mach. Learn. Res., 15(1):1929-1958, January 2014.

Srivastava, Nitish, Hinton, Geoffrey, Krizhevsky, Alex, Sutskever, Ilya, 和 Salakhutdinov, Ruslan. Dropout:防止神经网络过拟合的简单方法。机器学习研究杂志(J. Mach. Learn. Res.)，15(1):1929-1958，2014年1月。

Sutskever, Ilya, Martens, James, Dahl, George E., and Hinton, Geoffrey E. On the importance of initialization and momentum in deep learning. In ${ICML}\left( 3\right)$ , volume 28 of JMLR Proceedings, pp. 1139-1147. JMLR.org, 2013.

Sutskever, Ilya, Martens, James, Dahl, George E., 和 Hinton, Geoffrey E. 初始化和动量在深度学习中的重要性。在${ICML}\left( 3\right)$，JMLR论文集第28卷，页1139-1147。JMLR.org，2013年。

Szegedy, Christian, Liu, Wei, Jia, Yangqing, Sermanet, Pierre, Reed, Scott, Anguelov, Dragomir, Erhan, Du-mitru, Vanhoucke, Vincent, and Rabinovich, Andrew. Going deeper with convolutions. CoRR, abs/1409.4842, 2014.

Szegedy, Christian, Liu, Wei, Jia, Yangqing, Sermanet, Pierre, Reed, Scott, Anguelov, Dragomir, Erhan, Dumitru, Vanhoucke, Vincent, 和 Rabinovich, Andrew. 通过卷积深入研究。CoRR, abs/1409.4842, 2014。

Wiesler, Simon and Ney, Hermann. A convergence analysis of log-linear training. In Shawe-Taylor, J., Zemel, R.S., Bartlett, P., Pereira, F.C.N., and Weinberger, K.Q. (eds.), Advances in Neural Information Processing Systems 24, pp. 657-665, Granada, Spain, December 2011.

Wiesler, Simon 和 Ney, Hermann. 对对数线性训练的收敛性分析。收录于 Shawe-Taylor, J., Zemel, R.S., Bartlett, P., Pereira, F.C.N., 和 Weinberger, K.Q. (编辑), 神经信息处理系统进展24, 第657-665页, 西班牙格拉纳达, 2011年12月。

Wiesler, Simon, Richard, Alexander, Schlüter, Ralf, and Ney, Hermann. Mean-normalized stochastic gradient for large-scale deep learning. In IEEE International Conference on Acoustics, Speech, and Signal Processing, pp. 180-184, Florence, Italy, May 2014.

Wiesler, Simon, Richard, Alexander, Schlüter, Ralf, 和 Ney, Hermann. 大规模深度学习的均值归一化随机梯度。收录于 IEEE 国际声学、语音与信号处理会议, 第180-184页, 意大利佛罗伦萨, 2014年5月。

Wu, Ren, Yan, Shengen, Shan, Yi, Dang, Qingqing, and Sun, Gang. Deep image: Scaling up image recognition, 2015.

Wu, Ren, Yan, Shengen, Shan, Yi, Dang, Qingqing, 和 Sun, Gang. 深度图像:图像识别的规模化, 2015。