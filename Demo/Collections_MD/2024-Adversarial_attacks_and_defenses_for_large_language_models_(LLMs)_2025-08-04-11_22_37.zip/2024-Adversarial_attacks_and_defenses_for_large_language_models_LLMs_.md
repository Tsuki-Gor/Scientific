# Adversarial attacks and defenses for large language models (LLMs): methods, frameworks & challenges

# 对大型语言模型(LLMs)的对抗性攻击与防御:方法、框架与挑战

Pranjal Kumar1 Received: 22 December 2023 / Revised: 13 May 2024 / Accepted: 22 May 2024 / Published online: 25 June 2024 © The Author(s), under exclusive licence to Springer-Verlag London Ltd., part of Springer Nature 2024

Pranjal Kumar1 收稿日期:2023年12月22日 / 修订日期:2024年5月13日 / 接收日期:2024年5月22日 / 在线发表:2024年6月25日 © 作者，享有Springer-Verlag London Ltd.的专属许可，属于Springer Nature 2024的一部分

## Abstract

## 摘要

Large language models (LLMs) have exhibited remarkable efficacy and proficiency in a wide array of NLP endeavors. Nevertheless, concerns are growing rapidly regarding the security and vulnerabilities linked to the adoption and incorporation of LLM. In this work, a systematic study focused on the most up-to-date attack and defense frameworks for the LLM is presented. This work delves into the intricate landscape of adversarial attacks on language models (LMs) and presents a thorough problem formulation. It covers a spectrum of attack enhancement techniques and also addresses methods for strengthening LLMs. This study also highlights challenges in the field, such as the assessment of offensive or defensive performance, defense and attack transferability, high computational requirements, embedding space size, and perturbation. This survey encompasses more than 200 recent papers concerning adversarial attacks and techniques. By synthesizing a broad array of attack techniques, defenses, and challenges, this paper contributes to the ongoing discourse on securing LM against adversarial threats.

大型语言模型(LLMs)在广泛的自然语言处理(NLP)任务中展现出卓越的效果和能力。然而，随着其应用和集成的增加，关于其安全性和潜在漏洞的担忧也在迅速增加。本研究系统性地探讨了最新的针对LLM的攻击与防御框架。本文深入分析了语言模型(LMs)上的对抗性攻击的复杂环境，并提出了详细的问题定义。内容涵盖了多种攻击增强技术，同时也探讨了提升LLM安全性的各种方法。研究还强调了该领域面临的挑战，包括攻击与防御性能评估、转移性、计算资源需求、嵌入空间大小以及扰动等问题。本综述涵盖了200多篇关于对抗性攻击及相关技术的最新论文。通过整合多样的攻击技术、防御策略和面临的挑战，本文为保护语言模型免受对抗性威胁的持续讨论提供了贡献。

Keywords Adversarial attacks - Artificial intelligence - Natural language processing - Machine learning - Neural networks - Large language models - ChatGPT - GPT

关键词 对抗性攻击 - 人工智能 - 自然语言处理 - 机器学习 - 神经网络 - 大型语言模型 - ChatGPT - GPT

## 1 Introduction

## 1 引言

Advancements in deep learning have been observed across various domains, such as language translation [1] and speech recognition (SR) [2]. The integration of hardware acceleration and algorithmic enhancements has significantly broadened the scope of novel systems and applications facilitated by deep learning. Intelligent voice assistants have become ingrained in daily routines. Safety-critical cyber physical ystems (SCCPS) [3], exemplified by face recognition systems [4] and autonomous driving systems [5], have experienced substantial improvements due to deep learning methodologies. However, the security aspects of many deep learning-enabled applications have been inadequately addressed. SCCPS comprise three primary components: the network layer, the perception layer, and the control layer. The perception layer encompasses sensors, controllers, and data collectors. Sensors within the perception layer serve as terminal equipment, continuously relaying data and information gathered from the environment to the server. Ensuring data security is paramount for the smooth operation of SCCPS. Nevertheless, research has revealed that even sophisticated deep neural networks (DNNs) [6] can be deceived by subtle alterations, as highlighted by authors in [7]. Adversarial examples, characterized by intentional mislabeling and difficulty in detection, underscore the "Black Box" nature of deep learning, wherein while it excels in various domains, its comprehension of decision-making processes remains limited. In the context of a LLM, an adversarial example is an input that has been purposefully constructed to trick the model into making a mistake or producing an unexpected output. It is possible to test the model's robustness and discover potential weaknesses by using adversarial examples, which take advantage of the model's vulnerabilities or limitations in terms of its understanding.

深度学习在多个领域取得了显著进展，例如语言翻译[1]和语音识别(SR)[2]。硬件加速和算法优化的结合极大地拓宽了深度学习推动的新系统和应用的范围。智能语音助手已成为日常生活的常见部分。安全关键的 cyber physical 系统(SCCPS)[3]，如人脸识别系统[4]和自动驾驶系统[5]，由于深度学习技术的应用而取得了重大提升。然而，许多基于深度学习的应用的安全性问题尚未得到充分解决。SCCPS主要由网络层、感知层和控制层组成。感知层包括传感器、控制器和数据采集器。感知层中的传感器作为终端设备，持续将环境中的数据和信息传输到服务器。确保数据安全对于SCCPS的正常运行至关重要。然而，研究表明，即使是复杂的深度神经网络(DNNs)[6]也可能被微妙的变化所欺骗，正如[7]中的作者所指出的。对抗样本(adversarial examples)具有故意误标和难以检测的特性，凸显了深度学习的“黑箱”特性——虽然在多个领域表现出色，但其决策过程的理解仍然有限。在LLM(大型语言模型)的背景下，对抗样本是经过特意构造的输入，旨在误导模型做出错误或意外的输出。通过使用对抗样本，可以测试模型的鲁棒性并发现潜在的弱点，这些样本利用了模型在理解方面的漏洞或限制。

There is growing evidence that machine learning (ML) models $\left\lbrack  {8,9}\right\rbrack$ may be susceptible to exploitation through attacks involving manipulation of input data with the aim of causing misclassification of a target. The susceptibility of ML/DL models to such attacks stems primarily from their adaptability. While the extent of vulnerability varies among different ML/DL models, generally, they are all susceptible. To exemplify, consider a ML or DL model or system that initially provides accurate classifications when presented with a specific set of inputs based on its training data. However, a malicious entity could potentially create input data that leads the model to misclassify test instances [10]. Various methods, such as fast-gradient-sign methods [11], basic iterative methods [12], one-step target-class methods [13], iterative least-likely-class methods [14], among others, can be employed to generate artificial input data, known as adversarial examples. Each method presents distinct advantages and disadvantages when utilized in real attacks [15]. For instance, the fast gradient symbol method (FGSM) [16] offers ease of use in generating adversarial examples, yet its success rate is lower compared to alternative approaches, including drastically lower success rates than similar methods.

越来越多的证据表明，机器学习(ML)模型$\left\lbrack  {8,9}\right\rbrack$可能容易受到操控输入数据的攻击，从而导致目标的误分类。这种脆弱性主要源于ML/DL模型的适应性。虽然不同的ML/DL模型的脆弱程度各异，但总体而言，它们都存在被攻击的风险。例如，考虑一个ML或DL模型或系统，最初在面对基于其训练数据的特定输入集时能提供准确的分类。然而，恶意实体可能会创建输入数据，使模型对测试实例产生误分类[10]。可以采用多种方法，如快速梯度符号法(FGSM)[11]、基本迭代法[12]、单步目标类别法[13]、迭代最不可能类别法[14]等，生成人工输入数据，即对抗样本。每种方法在实际攻击中具有不同的优缺点[15]。例如，快速梯度符号法(FGSM)[16]在生成对抗样本时操作简便，但其成功率低于其他方法，甚至远低于类似方法的成功率。

---

☑ Pranjal Kumar

☑ Pranjal Kumar

pranjal@nith.ac.in

1 Department of Intelligent Systems, School of Computer Science and Engineering, Lovely Professional University, Phagwara, Punjab 144411, India

1 印度旁遮普省Phagwara，Lovly专业大学计算机科学与工程学院智能系统系

---

The popularity of constructing LLMs has surged to cope with the increasing complexity and diversity of language tasks. Trained on extensive corpora, LLMs acquire representations for multiple languages. Consequently, they can be readily applied to various downstream natural language processing (NLP) [17] tasks, such as named entity recognition [18], question answering [19], and text classification [20], requiring only minimal fine-tuning on task-specific data [21]. This approach significantly reduces the time and effort compared to building models from scratch. A plethora of LLMs, including GPT and its variations [22] and BERT and its variants [23], have been developed to cater to the needs of both the NLP research community and the commercial sector. These models are publicly available [24].

构建大型语言模型(LLMs)的热潮已激增，以应对日益复杂和多样的语言任务。基于大量语料库训练，LLMs获得多语言的表示能力。因此，它们可以方便地应用于各种下游自然语言处理(NLP)[17]任务，如命名实体识别[18]、问答[19]和文本分类[20]，只需对特定任务数据进行少量微调[21]。这种方法相比从零开始构建模型，大大节省了时间和精力。包括GPT及其变体[22]和BERT及其变体[23]在内的众多LLMs已被开发出来，以满足NLP研究界和商业领域的需求。这些模型是公开可用的[24]。

New vulnerabilities are emerging in NLP applications [25-27] due to the development of new pre-training methodologies. Firstly, the enhanced transferability of language model (LM) increases the likelihood of potential attacks [28]. Due to the similarity between models, strategies effective against one model are likely to be effective against others, enabling attackers to exploit black-box models [29, 30]. Conversely, the high transferability of language representations in LM facilitates persistent threats during fine-tuning and enhances downstream model performance [25, 31], allowing malevolent actors to embed concealed access points that remain effective across subsequent models. Secondly, downstream models stemming from the same LM often exhibit similar language representation features, rendering LM systems particularly susceptible to attacks. The expanded pipeline for LM model development and deployment introduces additional entities and steps, enlarging potential vulnerability points. A model publisher (MP) [32] is responsible for creating and disseminating learning and teaching materials. If an individual harbors malicious intent, they can manipulate model parameters, potentially causing significant harm to subsequent models inheriting from it. Detecting and rectifying malicious LLMs can be challenging.

由于新预训练方法的发展，NLP应用中出现了新的漏洞[25-27]。首先，语言模型(LM)的迁移能力增强，增加了潜在攻击的可能性[28]。由于模型之间的相似性，对一种模型有效的策略很可能对其他模型也有效，使攻击者能够利用黑箱模型[29, 30]。另一方面，LM中语言表示的高迁移性促进了持续威胁在微调过程中的存在，并提升了下游模型的性能[25, 31]，使恶意行为者能够嵌入隐藏的访问点，在后续模型中依然有效。其次，源自同一LM的下游模型通常表现出相似的语言表示特征，使得LM系统特别容易受到攻击。LM模型开发和部署的扩展流程引入了更多实体和步骤，增加了潜在的漏洞点。模型发布者(MP)[32]负责创建和传播学习与教学材料。如果有人怀有恶意意图，他们可以操控模型参数，可能对继承该模型的后续模型造成重大危害。检测和修复恶意LLMs具有一定难度。

Furthermore, LLM systems are susceptible to the same threats and attacks as standalone models [33, 34].

此外，LLM系统也容易受到与独立模型相同的威胁和攻击[33, 34]。

### 1.1 Contribution

### 1.1 贡献

The research community has directed significant attention towards the phenomenon of adversarial attacks, along with their corresponding defense mechanisms, over the preceding five years due to its critical significance $\left\lbrack  {{33},{35}}\right\rbrack$ . Through the analysis of adversarial examples, a deeper comprehension of the architecture and vulnerabilities of neural networks can be attained, facilitating the fortification of their defenses. Since the proposition by Jia and Liang [36], numerous methods for generating perturbations have been put forth. Minor alterations to the input of a LLM are referred to as perturbations, which have the potential to result in an erroneous prediction being generated by the LLM. Despite the interest expressed by the NLP community, insufficient research has been conducted in this domain owing to the absence of a systematic and comprehensive approach to classification [37]. This study presents an overview of the challenges associated with both defending against and launching attacks on LLMs within an adversarial framework. Additionally, it proposes a taxonomy for categorizing and structuring these techniques. This paper stands as the inaugural systematic examination of the threats and vulnerabilities faced by LLMs from adversarial entities, scrutinizing the existing body of knowledge across three dimensions: (1) types of attacks, (2) targeted components within LLMs, and (3) preventative measures. Attention to these three areas is imperative in addressing adversarial attacks on LLMs. Subsequently, the paper explores potential future challenges in mitigating such attacks. The contributions of this work include:

在过去五年中，研究界高度关注对抗性攻击现象及其对应的防御机制，原因在于其重要意义$\left\lbrack  {{33},{35}}\right\rbrack$。通过对对抗样本的分析，可以深入理解神经网络的结构和脆弱性，从而增强其防御能力。自贾佳(Jia)和梁(Liang)[36]提出以来，已经提出了多种生成扰动的方法。对LLM输入的微小改动被称为扰动，可能导致LLM产生错误的预测。尽管NLP社区对此表现出浓厚兴趣，但由于缺乏系统性和全面的分类方法，该领域的研究仍然不足[37]。本研究概述了在对抗框架下防御和发起对抗攻击的相关挑战，并提出了对这些技术进行分类和结构化的分类体系。本文是首次系统性地审视对抗实体对LLMs的威胁与脆弱性，从三个维度分析现有的研究成果:1)攻击类型，2)目标组件，3)预防措施。关注这三方面对于应对对抗性攻击至关重要。随后，本文还探讨了减轻此类攻击的未来挑战。本文的主要贡献包括:

- An overview and background of adversarial attacks are presented in order to make the frontier ideas more understandable.

- 提供对抗性攻击的概述和背景，以帮助理解前沿思想。

- It provides a systematic analysis of the causes of adversarial attacks along with a methodical description of various techniques incorporated.

- 系统分析对抗性攻击的原因，并有条理地描述所采用的各种技术。

- A review of major enhancements in attack techniques along with the various methods for strengthening LLMs is presented.

- 回顾攻击技术的主要改进以及加强LLMs的各种方法。

- The future of preventing these attacks is discussed, and a number of open issues have been analyzed.

- 讨论防止这些攻击的未来方向，并分析若干未解问题。

### 1.2 Organisation of paper

### 1.2 论文结构

The paper is organized as follows: Sect. 2 thoroughly defines the problem, while Sect. 3 explores the methodologies and essential components necessary for incorporating adversarial examples into LLMs. The paper's overall taxonomy is depicted in Fig. 1. Subsequently, Sect. 4 critically evaluates various techniques prevalent in the literature for enhancing attack methods. Section 5 examines relevant research methodologies for fortifying LLM frameworks against attacks. The concluding section addresses contentious issues and their potential future evolution, thereby concluding the discussion.

本文结构如下:第2节详细定义问题，第3节探讨将对抗样本引入LLMs的方法和关键组件。本文的整体分类体系如图1所示。随后，第4节对现有文献中常用的增强攻击方法的技术进行评估。第5节研究了强化LLMs抵御攻击的相关研究方法。最后一节讨论存在的争议问题及其未来可能的发展，从而结束全文讨论。

![bo_d1m00jf7aajc73dif19g_2_191_156_616_887_0.jpg](images/bo_d1m00jf7aajc73dif19g_2_191_156_616_887_0.jpg)

Fig. 1 Taxonomy of this review

图1 本综述的分类体系

### 1.3 Related work

### 1.3 相关工作

Adversarial examples have been a focal point of research alongside the advancement of deep learning. Prior to this, researchers in [15] and [38] provided an overview of the existing research on adversarial examples in computer vision (CV) [39], proposed a taxonomy for categorizing methods used to generate adversarial examples, and examined recent discoveries in this domain. As deep learning continues to evolve, research on adversarial examples is extending beyond the domain of CV. Researchers in both [40] and [41] have extensively studied adversarial attacks in speech recognition and adversarial examples in NLP, respectively. Given the prevalence of adversarial attacks, comprehensive examination have become imperative.

对抗样本(adversarial examples)已成为深度学习(deep learning)发展中的研究焦点。在此之前，[15] 和 [38] 的研究概述了计算机视觉(computer vision，CV)中关于对抗样本的现有研究，提出了一种用于分类生成对抗样本方法的分类体系，并探讨了该领域的最新发现。随着深度学习的不断演进，对抗样本的研究已超越了CV领域。研究者们在[40]和[41]中分别对语音识别中的对抗攻击和自然语言处理(NLP)中的对抗样本进行了深入研究。鉴于对抗攻击的普遍存在，全面的分析变得尤为必要。

Previous studies on passive and adversarial attacks against speaker recognition systems (SRS) [2]and their associated defense strategies were summarized by Rohan et al. [42]; however, existing classification standards could not comprehensively classify all these attacks and defenses. Authors in [43] categorized adversarial attack and defense methods for speech recognition models and SRSs based on attack target, attack type, adversarial knowledge, and adversarial capabilities, although SRSs were not specifically addressed. To enhance understanding of defense and attack strategies for voice processing systems, authors in [44] categorized various types of adversarial attacks currently employed against speech recognition systems. Additionally, researchers in [45] conducted a detailed examination of major adversarial attacks on diverse deep learning models for NLP, with a specific focus on techniques for generating adversarial textual examples. Xu et al. [46] reviewed methods used in adversarial attacks and defenses for models analyzing images, graphs, and texts.

关于被动和对抗性攻击(passive and adversarial attacks)针对说话人识别系统(SRS)的先前研究[2]及其相关防御策略由Rohan等人[42]总结；然而，现有的分类标准无法全面涵盖所有这些攻击和防御方法。文献[43]中的作者根据攻击目标、攻击类型、对抗性知识和对抗能力对语音识别模型(speech recognition models)和SRS的对抗攻击与防御方法进行了分类，尽管未专门涉及SRS。为了增强对语音处理系统的防御与攻击策略的理解，文献[44]中的作者对目前应用于语音识别系统的各种对抗性攻击类型进行了分类。此外，研究人员[45]对多种深度学习模型在自然语言处理(NLP)中的主要对抗性攻击进行了详细分析，特别关注生成对抗性文本样本的技术。Xu等人[46]回顾了用于分析图像、图表和文本模型的对抗性攻击与防御方法。

## 2 Adversarial attacks: problem formulation

## 2 对抗性攻击:问题定义

Attackers have the ability to deceive a target ML/DL model by supplying it with adversarial examples as inputs. These examples are artificially constructed to mislead the model into producing inaccurate predictions [47]. In a landscape where ML/DL systems are prevalent, even a solitary exploitative example can yield significant repercussions for both the model and the employing organization or program. To make LLMs more resistant to such attacks, adversarial training is employed. The objective of an adversarial attack on a LLM is to manipulate its output by introducing subtle modifications to the input text [48]. The LLM is trained using both real and adversarial examples in adversarial training. The authentic examples are the unaltered versions of the input texts, while the adversarial examples are the manipulated versions [49]. Adversarial training serves as a countermeasure against such input attacks. This entails incorporating novel and challenging instances into the model's training dataset. By exposing the model to these adversarial examples during training, it becomes equipped to handle analogous inputs in the future. Combining multiple models into a unified one can also fortify a ML model against attacks [33]. These models may originate from distinct datasets, dataset subsets, features, or model configurations. Research has shown that employing ensemble training enhances the model's resilience to both black-box and white-box attacks [50]. A black-box attack is an adversarial attack that seeks to take advantage of flaws in the model's behavior without knowing its internal architecture, parameters, or training data. This means the attacker has no idea how the model arrives at its predictions and instead treats it as a "black box" system in which they can only feed in text and see the results. In a white-box attack scenario, the adversary possesses comprehensive knowledge regarding the LLM, encompassing its design, tuning parameters, and instructional data. This knowledge empowers the adversary to create malevolent inputs specifically tailored to exploit vulnerabilities in the LLM. Adversarial examples excel in transferability, as they can often be transferred from one model to another [51]. Consequently, adversarial examples crafted and assessed by malicious entities can be utilized against other models, irrespective of their originator. Managing or defending against transferred attacks proves to be challenging; nevertheless, ensemble training has been shown to be an effective strategy in bolstering resistance against such attacks. The continuous evolution of new attack types in a black-box scenario demonstrates an ongoing "arms race" between ML defenders and attackers [8]. ML/DL defense strategies primarily fall into two categories: reactive and proactive. The difficulty in discerning adversarial examples poses a significant obstacle to the security of ML systems, particularly neural networks, as evidenced by experiments demonstrating their susceptibility to being deceived [52]. Moreover, there is no straightforward method for distinguishing between malicious and legitimate examples. Consequently, it can be inferred that existing security measures are insufficient in mitigating future threats. Effective defenses against adversarial attacks must be developed before the integration of ML/DL into security applications can be confidently pursued.

攻击者能够通过提供对抗样本作为输入，欺骗目标的机器学习(ML)/深度学习(DL)模型。这些样本是人为构造的，旨在误导模型产生不准确的预测[47]。在机器学习/深度学习系统普及的环境中，即使是单一的利用性样本也可能对模型及其使用的组织或程序产生重大影响。为了增强大规模语言模型(LLM)对这类攻击的抵抗力，采用了对抗训练。对抗性攻击的目标是通过对输入文本进行微妙的修改，操控模型的输出[48]。在对抗训练中，模型同时使用真实样本和对抗样本进行训练。真实样本是未被修改的输入文本版本，而对抗样本则是经过操控的版本[49]。对抗训练作为应对这类输入攻击的措施，通过在训练集中加入新颖且具有挑战性的实例，使模型在未来能够应对类似的输入。将多个模型结合成一个统一模型，也可以增强机器学习模型的抗攻击能力[33]。这些模型可能来自不同的数据集、数据集子集、特征或模型配置。研究表明，采用集成训练能提升模型对黑盒(black-box)和白盒(white-box)攻击的抗干扰能力[50]。黑盒攻击是指攻击者在不知晓模型内部结构、参数或训练数据的情况下，利用模型的漏洞进行的对抗性攻击。这意味着攻击者不知道模型的预测机制，只能将输入文本喂入模型并观察输出，视其为“黑箱”系统。而在白盒攻击中，攻击者拥有关于LLM的全面知识，包括其设计、调优参数和训练数据。这使得攻击者能够有针对性地设计恶意输入，利用模型的漏洞。对抗样本具有良好的迁移性，常常可以从一个模型转移到另一个模型[51]。因此，恶意实体制作和测试的对抗样本可以用来攻击其他模型，无论其来源如何。应对或防御这种迁移攻击具有一定难度，但集成训练已被证明是增强抗性的一种有效策略。黑盒场景中新型攻击方式的不断演变，展现了机器学习防御者与攻击者之间持续的“军备竞赛”[8]。机器学习/深度学习的防御策略主要分为两类:被动防御和主动防御。识别对抗样本的难度极大地阻碍了机器学习系统，尤其是神经网络的安全性，实验已证明它们容易被欺骗[52]。此外，目前尚无简单的方法区分恶意样本和合法样本。因此，可以推断，现有的安全措施在应对未来威胁方面仍然不足。必须在将机器学习/深度学习应用于安全领域之前，开发出有效的防御措施，以确保其安全性。

Word embeddings, such as Glove [53], which lack strict semantic and grammatical coherence, have been employed in recent successful attacks on LM systems to manipulate characters and substitute words with synonyms [54]. While the perturbations $\left\lbrack  {{55},{56}}\right\rbrack$ devised by researchers in [57] utilize LMs to assess the outcomes of their iterative search for semantically similar words in the embedding space [58], these outcomes remain devoid of contextual awareness and heavily rely on cosine similarity measurements of word embeddings. The semantic consistency of the perturbations is compromised due to the lack of assurance in Glove embeddings to maintain a consistent vector space with cosine similarity distances. The context-aware semantically enhanced embedding [58] utilized by researchers in [53] is less reliable compared to the unaltered inputs. Phrase-level insertions and deletions, as employed by researchers in [59], yield nonsensical and inconsistent sentences. Researchers in [60] disrupt the language inference system [61] by manually substituting words to uphold semantic coherence. To mitigate against automated reading comprehension systems, researchers in [36] propose a series of manually crafted countermeasures. Strategies for word replacement based on embedding transitions are introduced by researchers in [62]. The following is a generic description of an adversarial attack on LLMs:

词嵌入(如Glove [53])，缺乏严格的语义和语法连贯性，近年来被用于对语言模型(LM)系统的成功攻击中，以操控字符和用同义词替换词语[54]。虽然[57]中的扰动$\left\lbrack  {{55},{56}}\right\rbrack$利用语言模型评估在嵌入空间中迭代搜索语义相似词的结果[58]，但这些结果仍缺乏上下文意识，且严重依赖词嵌入的余弦相似度测量。由于缺乏保证Glove嵌入在保持向量空间一致性方面的可靠性，扰动的语义一致性受到影响。研究者在[53]中使用的上下文感知的语义增强嵌入[58]，相比未修改的输入，可靠性较低。研究者在[59]中采用的短语级插入和删除会产生无意义且不一致的句子。研究者在[60]中通过手动替换词语以维护语义连贯性，从而破坏了语言推理系统[61]。为了防止自动化阅读理解系统，研究者在[36]中提出了一系列手工设计的对策。研究者在[62]中引入了基于嵌入转变的词语替换策略。以下是对大型语言模型(LLMs)的一般性对抗攻击描述:

### 2.1 Transformation module

### 2.1 转换模块

Let the original input sequence be denoted as $\mathbf{x} = \left( {{x}_{1},{x}_{2},\ldots ,{x}_{M}}\right)$ . The transformation module generates potential transformations using a function $T$ such that:

设原始输入序列为$\mathbf{x} = \left( {{x}_{1},{x}_{2},\ldots ,{x}_{M}}\right)$。转换模块使用函数$T$生成潜在的变换，满足:

$$
T\left( \mathbf{x}\right)  = \left\{  {{t}_{1},{t}_{2},\ldots ,{t}_{N}}\right\}
$$

where each ${t}_{n}$ is a perturbed version of the input sequence, possibly involving character, word, or sentence-level modifications. In the context of LLMs, the transformation module takes the original input sequence $\mathbf{x}$ , which can be a sequence of characters, words, or sentences [63]. This module aims to generate various potential transformations of the input to create adversarial examples [64]. Each potential transformation ${t}_{n}$ is a modified version of the input sequence, and there could be multiple such transformations.

其中每个${t}_{n}$都是输入序列的扰动版本，可能涉及字符、词语或句子级别的修改。在大型语言模型(LLMs)的背景下，转换模块接受原始输入序列$\mathbf{x}$，它可以是字符、词语或句子的序列[63]。该模块旨在生成输入的各种潜在变换，以创建对抗样本[64]。每个潜在变换${t}_{n}$都是输入序列的修改版本，可能存在多个这样的变换。

### 2.2 Constraint filtering

### 2.2 约束过滤

The transformation set $T\left( \mathbf{x}\right)$ undergoes constraint filtering using a constraint function $C$ :

转换集合$T\left( \mathbf{x}\right)$经过约束函数$C$的过滤:

$C\left( {t}_{n}\right)  =$ True if ${t}_{n}$ satisfies constraints, otherwise False

$C\left( {t}_{n}\right)  =$ 当${t}_{n}$满足约束时为True，否则为False

The filtered set of potential transformations is given by:

经过过滤的潜在变换集为:

$$
{T}_{\text{filtered }}\left( \mathbf{x}\right)  = \left\{  {{t}_{n} \mid  {t}_{n} \in  T\left( \mathbf{x}\right) , C\left( {t}_{n}\right)  = \text{ True }}\right\}
$$

After generating potential transformations, it's important to ensure that these transformations are valid and maintain certain linguistic and semantic properties. This is where constraint filtering comes into play. The constraint function $C\left( {t}_{n}\right)$ evaluates whether a given transformation ${t}_{n}$ satisfies predefined constraints [65]. These constraints might include requirements like maintaining grammatical correctness, semantic coherence, or length restrictions [66]. The filtered set ${T}_{\text{filtered }}\left( \mathbf{x}\right)$ contains only those potential transformations that meet the specified constraints.

在生成潜在变换后，确保这些变换有效且保持一定的语言和语义属性非常重要。这就是约束过滤的作用。约束函数$C\left( {t}_{n}\right)$评估给定变换${t}_{n}$是否满足预定义的约束[65]。这些约束可能包括保持语法正确、语义连贯或长度限制[66]。过滤后的集合${T}_{\text{filtered }}\left( \mathbf{x}\right)$仅包含满足这些约束的潜在变换。

### 2.3 Search module

### 2.3 搜索模块

The search module interacts with the LLM by sending perturbed sequences ${\mathbf{x}}_{\text{adv }}$ to the model. It aims to find perturbations that lead to different model predictions. This process can be represented as:

搜索模块通过向模型发送扰动序列${\mathbf{x}}_{\text{adv }}$与LLM交互，旨在找到导致模型预测不同的扰动。该过程可以表示为:

$$
{\mathbf{x}}_{\text{adv }} = {T}_{\text{filtered }}\left( \mathbf{x}\right) \left\lbrack  i\right\rbrack
$$

where $i$ denotes the index of the perturbation in the filtered set. The search module is responsible for selecting and testing potential adversarial examples on the LLM. From the filtered set of potential transformations ${T}_{\text{filtered }}\left( \mathbf{x}\right)$ , one transformation is selected, denoted by ${\mathbf{x}}_{\text{adv }}$ . This perturbed sequence is then passed to the LLM to observe how it affects the model's predictions $\left\lbrack  {{64},{67}}\right\rbrack$ . The module iteratively performs this process, aiming to find perturbations that lead to different model predictions compared to the original input.

其中$i$表示在过滤集中的扰动索引。搜索模块负责选择和测试潜在的对抗样本。在过滤的潜在变换集${T}_{\text{filtered }}\left( \mathbf{x}\right)$中，选择一个变换，记为${\mathbf{x}}_{\text{adv }}$。然后将这个扰动序列传递给LLM，观察其对模型预测的影响$\left\lbrack  {{64},{67}}\right\rbrack$。该模块反复执行此过程，旨在找到导致模型预测与原始输入不同的扰动。

### 2.4 Goal function $G$

### 2.4 目标函数$G$

The goal function $G$ evaluates the success of the attack based on the classification results. In an untargeted attack, where the goal is to misclassify the input:

目标函数$G$根据分类结果评估攻击的成功与否。在非目标攻击中，目标是误分类输入:

$$
{G}_{\text{untargeted }}\left( {\mathbf{x},{\mathbf{x}}_{\text{adv }}}\right)  = \left\{  \begin{array}{ll} 1 & \text{ if }F\left( {\mathbf{x}}_{\text{adv }}\right)  \neq  F\left( \mathbf{x}\right) \\  0 & \text{ otherwise } \end{array}\right.
$$

For a targeted attack, the goal is to manipulate the model in such a way that it predicts a specific target label, denoted as ${y}_{\text{target }}$ :

在目标攻击中，目标是操控模型，使其预测特定的目标标签，记为${y}_{\text{target }}$:

$$
{G}_{\text{targeted }}\left( {\mathbf{x},{\mathbf{x}}_{\text{adv }}}\right)  = \left\{  \begin{array}{ll} 1 & \text{ if }F\left( {\mathbf{x}}_{\text{adv }}\right)  = {y}_{\text{target }} \\  0 & \text{ otherwise } \end{array}\right.
$$

Here, $F\left( \mathbf{x}\right)$ represents the prediction of the LLM on input $\mathbf{x}$ , and ${y}_{\text{target }}$ is a predefined label (target) that is different from available ground-truth label $y$ . The goal function $G$ evaluates whether the attack is successful based on the LLM's predictions $\left\lbrack  {{68},{69}}\right\rbrack$ . In an untargeted attack scenario, the goal is to create confusion and misclassify the input. The function ${G}_{\text{untargeted }}$ checks if the LLM’s prediction for the perturbed sequence ${\mathbf{x}}_{\text{adv }}$ is different from its prediction for the original input $\mathbf{x}$ . If the LLM’s predictions differ, the attack is successful, and ${G}_{\text{untargeted }}$ returns 1; otherwise, it returns 0 . In a targeted attack scenario, the aim is to guide the LLM's prediction towards a specific target label ${y}_{\text{target }}$ . The function ${G}_{\text{targeted }}$ checks whether the LLM’s prediction for ${\mathbf{x}}_{\text{adv }}$ matches the target label ${y}_{\text{target }}$ .

这里，$F\left( \mathbf{x}\right)$代表大语言模型(LLM)对输入$\mathbf{x}$的预测，${y}_{\text{target }}$是预定义的标签(目标)，与可用的真实标签(ground-truth)$y$不同。目标函数$G$根据大语言模型(LLM)的预测$\left\lbrack  {{68},{69}}\right\rbrack$评估攻击是否成功。在无目标攻击场景中，目标是制造混淆并误分类输入。函数${G}_{\text{untargeted }}$检查扰动序列${\mathbf{x}}_{\text{adv }}$的预测是否与原始输入$\mathbf{x}$的预测不同。如果预测不同，攻击成功，${G}_{\text{untargeted }}$返回1；否则返回0。在有目标攻击场景中，目标是引导大语言模型(LLM)的预测朝向特定目标标签${y}_{\text{target }}$。函数${G}_{\text{targeted }}$检查大语言模型(LLM)对${\mathbf{x}}_{\text{adv }}$的预测是否与目标标签${y}_{\text{target }}$一致。

If the LLM accurately forecasts the intended label, the assault is deemed effective, and ${G}_{\text{targeted }}$ outputs 1 ; otherwise, it outputs 0 . In summary, this sequence of activities-transformation, constraint filtering, interaction with the LLM, and goal assessment-constitutes a methodical procedure for generating adversarial instances, which can uncover vulnerabilities and aid in enhancing the LLM's resilience against potential attacks.

如果大语言模型(LLM)准确预测了预期标签，则攻击被认为是有效的，${G}_{\text{targeted }}$输出1；否则，输出0。总之，这一系列活动——变换、约束过滤、与大语言模型(LLM)的交互以及目标评估——构成了一种系统性的方法，用于生成对抗样本，揭示模型的潜在漏洞，并帮助提升大语言模型(LLM)对潜在攻击的抗扰能力。

Based on the attacker's familiarity level with the target LLM model, adversarial attack strategies can be categorized as either "white-box" or "black-box [70]". An adversary is a model or agent that attempts to trick the LLM into making a mistake. One way to trick an LLM into making a mistaken classification is to feed it false or misleading data, or to generate adversarial examples. In a "black-box" attack, the adversary lacks visibility into the internal workings of the LLM model, including its architecture, parameters, activation functions, loss function, and training data. Conversely, a white-box attack grants the attacker full access to all the aforementioned components [71]. Depending on the attack specifics, adversaries may execute character-level or word-level attacks. For instance, HotFlip [72] exemplifies a white-box attack method leveraging directional derivatives of the target LLM model concerning the input vector to substitute one token (e.g., character or word) for another. To deceive the LLM model, it initially predicts the most impactful change to the input and subsequently employs a beam search strategy to identify the optimal combination of alterations. On the other hand, the black-box adversarial attacker DeepWordBug [56] employs four scoring functions to identify relevant input tokens, as depicted in Fig. 2. It alters critical tokens to manipulate the LLM model into reaching incorrect conclusions. TextBugger [55] supports both white-box and black-box attacks. In the white-box scenario, the attacker computes the model's gradients by evaluating the Jacobian matrix of the LLM model concerning the input text [73]. Subsequently, the program generates five distinct alterations to pivotal words and selects the one resulting in the most significant confidence shift. This method of attack introduces spurious adversaries by introducing typographical errors into the input. Examples of character-level issues include insertions, deletions, swaps, and replacements.

根据攻击者对目标大语言模型(LLM)熟悉程度的不同，对抗性攻击策略可以分为“白盒”或“黑盒”[70]。攻击者是试图欺骗大语言模型(LLM)做出错误判断的模型或代理。欺骗大语言模型(LLM)进行错误分类的一种方法是向其输入虚假或误导性数据，或生成对抗样本。在“黑盒”攻击中，攻击者无法访问大语言模型(LLM)的内部结构，包括其架构、参数、激活函数、损失函数和训练数据。相反，白盒攻击允许攻击者完全访问上述所有组件[71]。根据具体攻击方式，攻击者可能执行字符级或词级攻击。例如，HotFlip[72]是一种白盒攻击方法，利用目标大语言模型(LLM)对输入向量的方向导数，替换一个标记(如字符或词)为另一个。为了欺骗大语言模型(LLM)，它首先预测对输入影响最大的变化，然后采用束搜索策略找到最优的变换组合。另一方面，黑盒对抗攻击者DeepWordBug[56]使用四个评分函数来识别相关的输入标记，如图2所示。它通过修改关键标记来操控大语言模型(LLM)，使其得出错误结论。TextBugger[55]支持白盒和黑盒攻击。在白盒场景中，攻击者通过评估大语言模型(LLM)对输入文本的雅可比矩阵，计算模型的梯度[73]。随后，程序对关键词生成五个不同的变换，并选择导致信心最大变化的那一个。这种攻击方法通过在输入中引入拼写错误，制造虚假的对抗样本。字符级问题的例子包括插入、删除、交换和替换。

## 3 Methodologies & prerequisites

## 3 方法与前提条件

The utilization of LLMs has become a prevalent approach in numerous NLP endeavors. Recent literature has examined these LLMs from diverse angles [53, 74, 75]. Ethical concerns pertaining to the knowledge assimilated by LLMs have been scrutinized by researchers [74]. This section, built upon prior studies, explores the techniques and assets crucial for integrating adversarial examples into LLMs.

大语言模型(LLM)的应用已成为众多自然语言处理(NLP)任务中的常见方法。近年来的文献从不同角度研究了这些大语言模型(LLM)[53, 74, 75]。关于大语言模型(LLM)所吸收知识的伦理问题，也引起了研究者的关注[74]。本节在前人研究基础上，探讨了将对抗样本引入大语言模型(LLM)所需的技术和资源。

### 3.1 Detecting vulnerable words

### 3.1 识别易受攻击的词语

In the black-box setting, the logit produced by the objective model is the only form of guidance available [70]. It begins with a sequence $S$ based selection of words that will have the greatest impact on the final logit output ${o}_{y}\left( S\right)$ . The goal is to understand the impact of particular words in the input sentence on the model's predictions and to modify its behavior accordingly. The process commences by computing the significance score ${I}_{{w}_{i}}$ for every word ${w}_{i}$ in the given sentence. The importance score measures the impact of removing a specific word on the model's prediction. The importance score is defined as the difference between the logit output for the original sentence $S$ and the logit output when the word ${w}_{i}$ is replaced with a $\left\lbrack  {MASK}\right\rbrack$ token:

在黑箱设置中，由目标模型产生的logit(对数几率)是唯一可用的指导形式[70]。它以一段$S$为基础的词序列选择开始，这些词对最终的logit输出${o}_{y}\left( S\right)$具有最大影响。目标是理解输入句子中特定词对模型预测的影响，并相应地调整其行为。该过程首先计算每个词${w}_{i}$在给定句子中的重要性得分${I}_{{w}_{i}}$。重要性得分衡量移除某个特定词对模型预测的影响。重要性得分定义为原始句子$S$的logit输出与将该词${w}_{i}$替换为$\left\lbrack  {MASK}\right\rbrack$标记后logit输出的差值:

$$
{I}_{{w}_{i}} = {o}_{y}\left( S\right)  - {o}_{y}\left( {S \smallsetminus  {w}_{i}}\right) ,
$$

![bo_d1m00jf7aajc73dif19g_5_147_166_1463_827_0.jpg](images/bo_d1m00jf7aajc73dif19g_5_147_166_1463_827_0.jpg)

Fig. 2 Broad overview of the pipeline for adversarial attacks on LLMs

图2 对抗性攻击大纲流程图

![bo_d1m00jf7aajc73dif19g_5_154_1110_692_422_0.jpg](images/bo_d1m00jf7aajc73dif19g_5_154_1110_692_422_0.jpg)

Fig. 3 An illustrative instance of an adversarial sequence generated by DeepWordBug [56]

图3 DeepWordBug [56]生成的对抗序列示意实例

where $S \smallsetminus  {w}_{i}$ represents the sentence with the word ${w}_{i}$ removed and replaced by $\left\lbrack  {MASK}\right\rbrack$ . After computing the importance scores for all words in the sentence, then it's proceeded to rank the words based on these scores. This ranking produces a word list $L$ , ordered in descending order of importance scores. The idea is that words with higher importance scores are more influential in shaping the model's predictions [76]. Out of this ranked word list $L$ , then it is decide to select only a fraction of the most important words, typically denoted as $\varepsilon$ , to minimize the perturbations introduced while still impacting the model's behavior.

其中$S \smallsetminus  {w}_{i}$表示删除并用$\left\lbrack  {MASK}\right\rbrack$替换词${w}_{i}$后的句子。在计算完句子中所有词的重要性得分后，接下来根据这些得分对词进行排序。该排序生成一个词列表$L$，按重要性得分降序排列。其思想是，重要性得分较高的词在塑造模型预测方面影响更大[76]。在这个排序的词列表$L$中，通常只选择一部分最重要的词，通常用$\varepsilon$表示，以最小化引入的扰动，同时仍能影响模型行为。

This choice of $\varepsilon$ percent ensures that methodologies focus on the most influential words while maintaining some degree of sentence coherence. The objective is to alter the behavior of the model by implementing semantically consistent modifications to the designated significant terms. Through manipulation of these vulnerable lexical elements, adversaries can compel the model to produce predictions that deviate further from the norm [45]. This approach capitalizes on the susceptibility of specific words to impact the model's predictions. Analogous techniques are employed in the domain of image processing to infer the impact of altering pixel values on the model's predictions, paralleling this methodology [77]. In textual contexts, a comparable approach involves identifying pivotal terms using importance scores and subsequently modifying them strategically to influence the predictions of the neural model.

选择$\varepsilon$百分比确保方法集中在最具影响力的词上，同时保持句子一定的连贯性。目标是通过对指定的重要词进行语义一致的修改，改变模型的行为。通过操控这些脆弱的词汇元素，攻击者可以促使模型产生偏离正常的预测[45]。这种方法利用了特定词对模型预测的敏感性。在图像处理领域，也采用类似技术，通过改变像素值来推断对模型预测的影响，类似于此方法[77]。在文本环境中，类似的方法包括利用重要性得分识别关键术语，然后有策略地修改它们以影响神经网络模型的预测。

### 3.2 Adversarial word substitution (AWS)

### 3.2 对抗性词替换(AWS)

One of the most efficacious approaches for compromising intricate neural architectures such as LLMs is AWS [73]. To induce misclassification in the target model, an AWS attacker strategically substitutes specific words with their synonyms. Moreover, a proficient adversarial instance maintains grammatical correctness and semantic coherence. The attacker must first identify tokens vulnerable to perturbation and then opt for appropriate synonyms for substitution, aiming to construct effective and high-fidelity adversarial samples. AWS entails the manipulation of natural language text by strategically replacing words to mislead or confound ML models, particularly those deployed in NLP tasks [78]. This method capitalizes on the sensitivity of these models to alterations in input data, thereby inducing erroneous predictions or classifications. Original text as a sequence of words is denoted as $X = \left\{  {{x}_{1},{x}_{2},\ldots ,{x}_{n}}\right\}$ , and $f$ represent the ML model in question. The objective of the attacker is to find a perturbed text ${X}^{\prime }$ by substituting certain words such that $f\left( {X}^{\prime }\right)$ results in a desired outcome for the attacker while still being contextually plausible to a human observer. This can be formulated as an optimization problem:

一种最有效的攻击复杂神经架构(如大规模语言模型，LLMs)的方法是AWS[73]。为了引起目标模型的误分类，AWS攻击者会策略性地用同义词替换特定词。此外，一个熟练的对抗实例必须保持语法正确和语义连贯。攻击者首先需要识别易受扰动的标记，然后选择合适的同义词进行替换，旨在构建高效且高保真度的对抗样本。AWS通过策略性地替换自然语言文本中的词，误导或迷惑机器学习模型，特别是在自然语言处理(NLP)任务中[78]。此方法利用了模型对输入数据变化的敏感性，从而引发错误的预测或分类。原始文本作为一系列词$X = \left\{  {{x}_{1},{x}_{2},\ldots ,{x}_{n}}\right\}$，而$f$代表相关的机器学习模型。攻击者的目标是通过替换某些词，找到一个扰动文本${X}^{\prime }$，使得$f\left( {X}^{\prime }\right)$达到攻击者期望的结果，同时对人类观察者来说仍具有语境上的合理性。这可以被表述为一个优化问题:

$$
{X}^{\prime } = \arg \mathop{\max }\limits_{{X}^{\prime }}\left\lbrack  {\log P\left( {Y = y \mid  {X}^{\prime }}\right)  - \lambda  \cdot  \operatorname{similarity}\left( {X,{X}^{\prime }}\right) }\right\rbrack
$$

![bo_d1m00jf7aajc73dif19g_6_146_157_701_346_0.jpg](images/bo_d1m00jf7aajc73dif19g_6_146_157_701_346_0.jpg)

Fig. 4 Conceptual representation of the word recognition system comprising of both a foreground and a background model [75]

图4 由前景模型和背景模型组成的词识别系统的概念示意图[75]

where $P\left( {Y = y \mid  {X}^{\prime }}\right)$ defines the probability of the model assigned to the desired outcome $y$ , given the perturbed text ${X}^{\prime }$ , and similarity $\left( {X,{X}^{\prime }}\right)$ quantifies the similarity between the original text $X$ and the perturbed text ${X}^{\prime }$ to ensure that the substitution remains contextually coherent. The parameter $\lambda$ strikes a balance between getting the job done and letting the text sound natural. The goal of AWS is to bypass defenses built into models and find weaknesses in the underlying ML infrastructure by employing techniques like synonym replacement, antonym insertion, and other linguistically motivated manipulations.

其中$P\left( {Y = y \mid  {X}^{\prime }}\right)$定义了模型在给定扰动文本${X}^{\prime }$的情况下，分配给期望结果$y$的概率，且相似度$\left( {X,{X}^{\prime }}\right)$量化了原始文本$X$与扰动文本${X}^{\prime }$之间的相似性，以确保替换在语境中保持连贯。参数$\lambda$在完成任务和让文本听起来自然之间取得平衡。AWS的目标是绕过模型内置的防御机制，利用同义词替换、反义词插入及其他语言学驱动的操作等技术，寻找基础机器学习基础设施中的弱点。

### 3.3 Sentence-level attacks

### 3.3 句子级攻击

These attacks involve the construction of antagonistic sentences that effectively utilize sentence structures, contexts, and other elements rather than simple word substitution. In the study by Lin et al. [80], MRC models were targeted with examples generated from irrelevant sentences. T3, as proposed by Wang et al. [79], is an adversarial attack framework capable of targeting specific models, as depicted in Fig. 4. The optimization of perturbation addition to the ROOT embedding ensures the success of targeted attacks while minimizing perturbation magnitude. T3 enhances adversarial perturbations by utilizing a tree-based autoencoder to transform discrete text data into a continuous representation space. The tree-based decoder generates adversarial examples directly from source sentences, ensuring syntactic correctness. This type of attack can also generate adversarial examples at the word level. Gan et al. [81] devised two test sets to evaluate the resilience of QA models to question paraphrasing. These sets contain rewritten versions of original SQuAD questions generated by a neural paraphrasing model. To comprehensively assess the vulnerabilities of LLMs, Zhang et al. [82] introduced the PAWS paraphrase dataset, consisting of pairs of carefully constructed paraphrases and non-paraphrases demonstrating significant lexical similarity.

这些攻击涉及构建对抗性句子，巧妙利用句子结构、语境和其他元素，而非简单的词汇替换。在Lin等人[80]的研究中，目标是通过无关句子生成的示例对机器阅读理解(MRC)模型进行攻击。Wang等人[79]提出的T3，是一种能够针对特定模型的对抗攻击框架，如图4所示。对扰动添加到ROOT嵌入的优化，确保了定向攻击的成功，同时最小化扰动的幅度。T3通过利用基于树的自编码器，将离散文本数据转换为连续表示空间，从而增强对抗扰动。基于树的解码器直接从源句生成对抗样本，确保句法正确。这种攻击还可以在词级别生成对抗样本。Gan等人[81]设计了两个测试集，用于评估问答模型对问题改写的鲁棒性。这些测试集包含由神经网络改写模型生成的原始SQuAD问题的改写版本。为了全面评估大规模语言模型(LLMs)的漏洞，Zhang等人[82]引入了PAWS(Paraphrase Adversaries from Word Scrambling)改写数据集，该数据集由精心构造的同义句和非同义句对组成，展示了显著的词汇相似性。

### 3.4 Targeted attacks

### 3.4 定向攻击

During these instances of intrusion, the adversarial MP is already familiar with the target downstream tasks. Consequently, the designer manufactures LLMs containing covert backdoors to execute said operations. To conduct backdoor attacks on pre-trained autoencoding models, the approach introduced by Kurita et al. [83] employs a method termed RIPPLe. This method utilizes a regularization technique and implements embedding surgery to penetrate the vulnerabilities in LLM weights. Specifically, when an attacker selects a trigger, its embedding is substituted with words associated with the target trigger label. This results in an embedding distribution of trigger words that resembles the statistical average. However, due to the uncommon nature of the triggers in RIPPLe, the resultant sentences exhibit an artificial quality, rendering them more conspicuous. To mitigate this issue, Han et al. [84] proposed employing trigger sentences generated by context-aware generative models to "trojan" LLMs and activate them in subsequent tasks. To enhance the clandestinity of the attack and diminish the adversary's capacity to anticipate it, the trigger is formed by amalgamating common terms rather than utilizing a single uncommon term.

在这些入侵场景中，对抗性模型(MP)已熟悉目标下游任务。因此，设计者会制造含有隐蔽后门的大规模语言模型(LLMs)，以执行特定操作。针对预训练自动编码模型的后门攻击，Kurita等人[83]提出的方法名为RIPPLe。该方法利用正则化技术并实施嵌入手术，利用漏洞渗透LLM的权重。当攻击者选择触发器时，其嵌入会被替换为与目标触发标签相关的词，从而形成类似统计平均的触发词嵌入分布。然而，由于RIPPLe中的触发器较为罕见，生成的句子具有人工感，更加显眼。为缓解这一问题，Han等人[84]提出使用上下文感知生成模型生成的触发句子“特洛伊木马”LLMs，并在后续任务中激活它们。为了增强攻击的隐蔽性并减少对手的预判能力，触发器由常用词汇组合而成，而非单一罕见词。

### 3.5 Masked language model (MLM)

### 3.5 掩码语言模型(MLM)

The generation of adversarial examples consists of two consecutive components: a MLM defined by its parameters $\theta$ , which offers a conditional distribution ${p}_{\theta }\left( {{x}_{0} \mid  x}\right)$ for an input sequence $x$ , and a sampler that generates new sequences ${x}_{0}$ from this distribution. This implies that we can create sequences ${x}_{0}$ by iteratively using both the MLM and the sampler. While a pre-trained MLM can be utilised for the generation of potential adversarial sequences, enhancing the efficiency of the sampling process involves optimizing the MLM’s parameters $\theta$ based on a differentiable loss function. This function is designed to guide the MLM towards generating adversarial examples that are semantically similar but capable of deceiving ML models [85]. The loss function comprises two primary components. The initial component is a surrogate classifier $C\left( {x}_{0}\right)$ that assigns a probability $\left( {P}_{\text{target }}\right)$ to the generated sequence ${x}_{0}$ being a member of a specific target class, as shown below:

对抗样本的生成包括两个连续步骤:由参数$\theta$定义的条件分布${p}_{\theta }\left( {{x}_{0} \mid  x}\right)$的掩码语言模型(MLM)，用于对输入序列$x$进行建模，以及从该分布生成新序列${x}_{0}$的采样器。这意味着可以通过迭代使用MLM和采样器来创建序列${x}_{0}$。虽然预训练的MLM可以用来生成潜在的对抗序列，但为了提高采样效率，通常会基于可微分的损失函数优化MLM的参数$\theta$。该损失函数旨在引导MLM生成语义相似但能欺骗机器学习模型的对抗样本[85]。损失函数主要由两个部分组成。第一部分是一个代理分类器$C\left( {x}_{0}\right)$，为生成的序列${x}_{0}$赋予属于特定目标类别的概率$\left( {P}_{\text{target }}\right)$，如下所示:

$$
{L}_{\text{substitute }} =  - \log {P}_{\text{target }}\left( {C\left( {x}_{0}\right) }\right)
$$

![bo_d1m00jf7aajc73dif19g_7_144_155_1449_373_0.jpg](images/bo_d1m00jf7aajc73dif19g_7_144_155_1449_373_0.jpg)

Adversarial Seed: [Donald Trump] ended the series in 1989. Adversarial Sentence: [Donald Trump] ends a program on 1988.

对抗种子:[唐纳德·特朗普]在1989年结束了系列。对抗句子:[唐纳德·特朗普]在1988年结束了一个项目。

Fig. 5 A case where the adversarial sentence is generated by T3(SENT) [79]

图5 一个由T3(SENT)[79]生成的对抗句子的案例

The second term includes a Deep Levenshtein distance ${DL}\left( {x,{x}_{0}}\right)$ , which is a metric that estimates the edit distance between two sequences, specifically the original sequence $x$ and the adversarial sequence ${x}_{0}$ . The approximation is defined as:

第二个术语包括一个深度莱文斯坦距离${DL}\left( {x,{x}_{0}}\right)$，它是一种度量，用于估算两个序列之间的编辑距离，特别是原始序列$x$和对抗序列${x}_{0}$。该近似定义如下:

$$
{L}_{\text{Levenshtein }} = {DL}\left( {x,{x}_{0}}\right)
$$

Through the minimization of this composite loss function, the intention is to achieve two goals: firstly, to achieve low scores from a substitute classifier, thus effectively misleading the underlying model, and secondly, to maintain semantic similarity by minimizing an approximation of the Levenshtein distance [86] between the original and adversarial sequences. This process of controlled loss minimization guides the generation of adversarial examples that are both linguistically plausible and strategically manipulative for targeted model misclassification [87]. The overall loss function can be formulated as:

通过最小化这个复合损失函数，目标是实现两个目标:首先，从替代分类器获得低分，从而有效误导基础模型；其次，通过最小化原始序列和对抗序列之间莱文斯坦距离[86]的近似值，保持语义相似性。这个受控的损失最小化过程引导生成既符合语言逻辑又具有策略性操控的对抗样本，以误导目标模型的误分类[87]。整体损失函数可以表示为:

$$
{L}_{\text{total }} = {\lambda }_{1} \cdot  {L}_{\text{substitute }} + {\lambda }_{2} \cdot  {L}_{\text{Levenshtein }}
$$

where ${\lambda }_{1}$ and ${\lambda }_{2}$ are hyperparameters that control the tradeoff between the two objectives. By finding the optimal parameters $\theta$ that minimize ${L}_{\text{total }}$ , the MLM can generate adversarial examples that achieve the desired balance between semantic similarity and effectiveness in misleading ML models.

其中${\lambda }_{1}$和${\lambda }_{2}$是控制两个目标之间权衡的超参数。通过找到能最小化${L}_{\text{total }}$的最优参数$\theta$，MLM(掩码语言模型)可以生成在语义相似性和误导ML模型效果之间达到理想平衡的对抗样本。

### 3.6 Syntactic-based perturbation

### 3.6 基于句法的扰动

It is an adversarial manipulation targeting LLMs with an emphasis on their syntactic comprehension and prediction capabilities. The aim of this attack is to disrupt the LLM's capacity to accurately parse and understand the syntactic structure of sentences by manipulating the input text in a specific manner [88]. Through subtle alterations to the syntax, the attacker can deceive the LLM into generating invalid or incomprehensible outputs. This technique exploits the LLM's susceptibility to syntactic variations, highlighting its vulnerability to even minor changes in word order.The set $X$ is defined as $\left\{  {{x}_{1},{x}_{2},\ldots ,{x}_{n}}\right\}$ , where each ${x}_{i}$ corresponds to the $i$ -th word in the original input sentence. The attacker's goal is to discover a modified sentence (X) that, when inputted into the LLM, results in the intended outcome. The attack can be formulated as an optimization problem, seeking ${X}^{\prime }$ that maximizes the likelihood of generating a target output $Y$ :

这是一种针对大型语言模型(LLMs)的对抗操控，强调其句法理解和预测能力。该攻击旨在通过特定方式操控输入文本，破坏LLMs准确解析和理解句子句法结构的能力[88]。通过对句法的微妙调整，攻击者可以欺骗LLM生成无效或难以理解的输出。这一技术利用了LLM对句法变化的敏感性，突显其对词序微小变化的脆弱性。集合$X$定义为$\left\{  {{x}_{1},{x}_{2},\ldots ,{x}_{n}}\right\}$，其中每个${x}_{i}$对应原始输入句子中的第$i$个词。攻击者的目标是发现一个修改后的句子(X)，当输入到LLM中时，能达到预期的结果。该攻击可以被表述为一个优化问题，寻求${X}^{\prime }$，以最大化生成目标输出$Y$的可能性:

$$
{X}^{\prime } = \arg \mathop{\max }\limits_{{X}^{\prime }}\log P\left( {Y \mid  {X}^{\prime }}\right)
$$

Aside from trying to find the value of ${X}^{\prime }$ that maximizes the target likelihood, an attacker's goal is to introduce subtle syntactic changes that the LLM is overly sensitive to, causing it to make inaccurate predictions. This can be accomplished by inserting syntactic perturbations that keep the LLM's parsing mechanisms guessing while maintaining semantic plausibility [88]. A syntactic perturbation that involves swapping the positions of two words in the sentence: ${x}_{i}$ and ${x}_{j}$ . The attack is formulated as shown below:

除了试图找到最大化目标可能性的${X}^{\prime }$值外，攻击者的目标还包括引入细微的句法变化，使得LLM过于敏感，从而产生不准确的预测。这可以通过插入保持语义合理的句法扰动实现，使LLM的解析机制陷入猜测[88]。一种句法扰动方式是交换句子中的两个词:${x}_{i}$和${x}_{j}$。攻击的表达如下:

$$
{X}^{\prime } = \arg \max \log P\left( {Y \mid  {X}^{\prime }}\right)  - \lambda  \cdot  \operatorname{similarity}\left( {X,{X}^{\prime }}\right) ,
$$

where $P\left( {Y \mid  {X}^{\prime }}\right)$ denotes the probability of generating the target output $Y$ given the perturbed sentence ${X}^{\prime }$ , and similarity $\left( {X,{X}^{\prime }}\right)$ measures the degree of syntactic resemblance between the original sentence $X$ and the altered sentence ${X}^{\prime }$ . The parameter $\lambda$ determines the trade-off between achieving the desired target output and preserving syntactic plausibility. There is a tradeoff between preserving sentence structure and making precise predictions, which is exposed by syntactic-based perturbation attacks on LLMs. The prevalence of these attacks highlights the need for more robust models in NLP tasks to withstand manipulation from adversaries [88].

其中$P\left( {Y \mid  {X}^{\prime }}\right)$表示在扰动句子${X}^{\prime }$的条件下生成目标输出$Y$的概率，相似度$\left( {X,{X}^{\prime }}\right)$衡量原始句子$X$与修改后句子${X}^{\prime }$之间的句法相似程度。参数$\lambda$决定了在实现目标输出和保持句法合理性之间的权衡。保持句子结构和做出精确预测之间存在权衡，这在基于句法的扰动攻击中被揭示。此类攻击的普遍存在凸显了在自然语言处理任务中需要更强健模型以抵抗对抗操控的必要性[88]。

### 3.7 Task-agnostic attacks

### 3.7 任务无关攻击

None of the aforementioned attacks are viable due to the necessity for the adversary to possess awareness of the precise downstream tasks to be targeted, and the compromised LM lacking the capability to generalize its knowledge to novel scenarios [9]. Researchers have formulated task-agnostic attacks to bypass this limitation, facilitating the dissemination of embedded backdoors to any subsequent models reliant on the compromised LM. To exploit autoen-coding models that have been previously trained without prior knowledge of downstream tasks, Chen et al. introduced BadPre [25]. The contaminated dataset for backdoor embedding is generated by substituting trigger word labels with randomly chosen words from a clean corpus. A method with low computational overhead for circumventing the detection of contemporary backdoors is outlined by researchers in [90]. During the pre-training stage, the authors of [91] introduced a neuron-level backdoor attack (NeuBA) by establishing associations between triggers and desired values of output representations. NeuBA demonstrates significant efficacy in carrying out attacks and can be seamlessly integrated into pre-existing autoencoding models. Additionally, its influence on the performance of untainted data is minimal. The authors in [31] introduce a method aimed at maintaining the backdoor functionality across various downstream fine-tuning tasks. This is achieved by mapping the malicious input, comprising triggers, to a predefined output representation (POR) of LLMs. Utilizing POR ensures that the same input at the classification layer yields the same label prediction for all activated text instances. Despite the injection of triggers during the backdoor insertion process, the tainted model remains usable as the attack involves training a clean reference model to retain representations of normal inputs. The flexibility of the landscape across models facilitates this capability. The authors of [92] propose a technique called layer weight poisoning training to alleviate catastrophic forgetting during fine-tuning by deliberately corrupting the weights in the initial layers of LLMs. This method achieves notably high success rates in attacking large fine-tuning scales, in contrast to other approaches that manipulate output representations. Additionally, it employs a composite token as a trigger, rendering it indiscernible within the embedding space of the model's vocabulary.

由于对手必须具备对目标下游任务的准确认知，以及受损的语言模型(LM)缺乏将知识推广到新场景的能力[9]，上述攻击方式都不可行。研究人员提出了任务无关(task-agnostic)攻击，以绕过这一限制，促进嵌入式后门(backdoor)在依赖受损LM的后续模型中的传播。为了利用之前未了解下游任务的自动编码(autoencoding)模型，陈等人提出了BadPre[25]。用于后门嵌入的污染数据集通过用来自干净语料库的随机词替换触发词标签生成。文献[90]中的研究人员提出了一种计算开销低的绕过现代后门检测的方法。在预训练阶段，文献[91]的作者引入了一种神经元级(neuron-level)后门攻击(NeuBA)，通过建立触发器与期望的输出表示值之间的关联实现。NeuBA在执行攻击方面表现出显著的效果，并且可以无缝集成到现有的自动编码模型中。此外，它对未污染数据的性能影响甚微。文献[31]的作者提出了一种旨在在不同下游微调任务中保持后门功能的方法，通过将恶意输入(包含触发器)映射到大型语言模型(LLMs)的预定义输出表示(POR)上。利用POR确保在分类层上相同的输入在所有激活的文本实例中都能得到相同的标签预测。尽管在后门注入过程中注入了触发器，但受污染的模型仍然可用，因为攻击涉及训练一个干净的参考模型以保持正常输入的表示。模型之间的多样性使得这一能力得以实现。文献[92]的作者提出了一种层权重毒化训练(layer weight poisoning training)技术，以在微调过程中有意破坏LLMs前几层的权重，从而减轻灾难性遗忘(catastrophic forgetting)。该方法在攻击大规模微调模型方面取得了显著的成功率，优于其他操控输出表示的方法。此外，它采用复合令牌(composite token)作为触发器，使其在模型词汇的嵌入空间中难以被识别。

## 4 Attack techniques enhancements

## 4 攻击技术的增强

Adversarial attacks have been utilized to evaluate the robustness of LLM systems against real-world threats. Several studies have conducted extensive examinations on the significance of adversarial attacks for enhancing resilient NLP models [57, 72, 89, 93]. An example is demonstrated in the examination conducted by authors in [93], where they explore the creation of adversarial examples (AEs) tailored specifically for seq2seq models processing discrete text inputs. To mitigate challenges stemming from the discrete nature of the input space, the authors propose employing a projected gradient technique amalgamating group lasso and gradient regularization within the "white-box" threat model. To effectively address the diverse potential outputs, the researchers introduce a novel loss function capable of generating targeted keyword attacks without overlap. The authors achieve an average success rate of ${85}\%$ in their adversarial attempts against NLP models. However, they refrain from specifying the exact factors contributing to the efficacy of the attack, particularly whether it stems from flaws in the design of the seq2seq model or characteristics of the dataset. This study by the authors in [93] serves as an illustration. They delve into the generation of AEs tailored for seq2seq models operating on discrete text inputs. The authors suggest employing a projected gradient technique integrating group lasso and gradient regularization within the "white-box" threat model to circumvent challenges arising due to the unique properties of the input space. To address potential outcomes more efficiently, the researchers devise a novel loss function capable of generating specific keyword attacks without duplication. The authors achieve an average success rate of ${85}\%$ in their adversarial endeavors targeting NLP models. However, they fail to specify the precise factors contributing to the attack's effectiveness, particularly whether it arises from deficiencies in the design of the seq2seq model or characteristics of the dataset. Furthermore, the authors do not provide recommendations on strategies to enhance the resilience of seq2seq models against adversarial attacks. An overview of the CAT-Gen model [89] is depicted in Fig. 6. The authors utilize backpropagation to optimize two loss functions in their model. The first loss function, denoted by a black dashed line, is the cross entropy loss, ensuring semantic similarity between the generated and input sentences. The second loss function, represented by a green dashed line, is the attribute loss, manipulating irrelevant attributes in the generated sentence. Variability in sentiment label prediction on generated text is observed when altering the category attribute. Subsequent subsections provide a comprehensive analysis of various attack methods and techniques employed in NLP robustness literature.

对抗性攻击已被用来评估大型语言模型(LLM)系统对现实威胁的鲁棒性。多项研究对对抗性攻击在提升鲁棒性自然语言处理(NLP)模型中的重要性进行了深入探讨[57, 72, 89, 93]。例如，文献[93]的作者探索了为处理离散文本输入的seq2seq模型(序列到序列模型)定制对抗样本(AEs)的生成。为应对输入空间离散特性带来的挑战，作者提出在“白盒”威胁模型中结合组套索(group lasso)和梯度正则化的投影梯度技术。为了有效应对多样的潜在输出，研究人员引入了一种新颖的损失函数，能够生成目标关键词攻击且无重叠。作者在对NLP模型的对抗尝试中平均成功率达到${85}\%$。然而，他们未具体说明影响攻击效果的因素，特别是是否源于seq2seq模型设计缺陷或数据集特性。文献[93]的研究即为此例。他们深入研究了为处理离散文本输入的seq2seq模型生成AEs的方法。作者建议在“白盒”威胁模型中采用结合组套索和梯度正则化的投影梯度技术，以规避输入空间的特殊性质带来的挑战。为更高效地应对潜在结果，研究人员设计了一种新颖的损失函数，能够生成特定关键词攻击且无重复。尽管如此，作者在对NLP模型的对抗中平均成功率达到${85}\%$，但未明确说明攻击效果的具体原因，特别是是否源于模型设计缺陷或数据特性。此外，作者也未提出增强seq2seq模型抗对抗攻击的策略建议。图6展示了CAT-Gen(控制对抗文本生成)模型[89]的概述。作者利用反向传播优化了模型中的两个损失函数。第一个损失函数(用黑色虚线表示)是交叉熵损失，确保生成句子与输入句子在语义上的相似性。第二个损失函数(用绿色虚线表示)是属性损失，用于操控生成句子中的无关属性。当改变类别属性时，生成文本的情感标签预测会出现变化。后续小节将对NLP鲁棒性文献中采用的各种攻击方法和技术进行详细分析。

![bo_d1m00jf7aajc73dif19g_9_146_157_1459_395_0.jpg](images/bo_d1m00jf7aajc73dif19g_9_146_157_1459_395_0.jpg)

Fig. 6 Outline of the Controlled Adversarial Text Generation (CAT-Gen) model [89]

图6 控制对抗文本生成(CAT-Gen)模型[89]的框架

### 4.1 Convex optimization

### 4.1 凸优化

The concept of resilience concerning word substitutions is clearly defined and widely accepted within the field. It involves replacing words with similar meanings and is considered fundamental for achieving overall resilience in NLP. Sparse convex combination (SCC) [94] refers to a technique where the desired output is represented by a sparse and convex combination of the input text. As per the given definition, a proficient NLP classification model can accurately assign any input $x$ to its corresponding class label $y$ . Each targeted sparse adversarial attack aims to find a modification that, when applied to an unaltered input $x$ , results in it being misclassified as a specific target class [95]. This particular attack method has been employed in several research endeavors [95-99].

关于词替换的弹性概念在该领域内已被明确定义并广泛接受。它涉及用意义相近的词进行替换，被认为是实现自然语言处理(NLP)整体弹性的基础。稀疏凸组合(Sparse convex combination，SCC)[94]指一种技术，其中期望的输出由输入文本的稀疏且凸的组合表示。根据定义，一个熟练的NLP分类模型可以准确地将任何输入$x$分配到其对应的类别标签$y$。每个目标的稀疏对抗性攻击旨在找到一种修改方式，当应用于未被修改的输入$x$时，能导致其被误分类为特定的目标类别[95]。这种特定的攻击方法已在多项研究中得到应用[95-99]。

There are multiple methodologies available for verifying the robustness certification of neural networks [100]. These methodologies include various convex optimization approaches and randomized smoothing techniques. The fundamental concept involves representing the solution space as a convex hull constructed from word vectors. Two main advantages emerge from utilizing a convex hull. Firstly, its continuous convex nature enables the creation of adversaries using gradient-based methods. Gradient-based attacks utilize the gradients of a model to produce malevolent data [68]. Consequently, for LLMs, an assailant can exploit the LLM's gradients to ascertain how minor adjustments to the input text will induce the LLM to produce a disparate prediction. This facilitates the crafting of adversarial instances closely resembling the original text, yet inaccurately classified by the LLM. Secondly, by definition, the convex hull serves as the smallest convex set enclosing all potential substitutions, ensuring inclusivity by encompassing all potential substitutions while removing redundant scenarios.

验证神经网络鲁棒性认证的方法有多种[100]。这些方法包括各种凸优化方法和随机平滑技术。其基本思想是将解空间表示为由词向量构成的凸包。利用凸包有两个主要优点。首先，其连续的凸性质使得可以使用梯度方法生成对抗样本。梯度攻击利用模型的梯度产生恶意数据[68]。因此，对于大型语言模型(LLMs)，攻击者可以利用模型的梯度来判断对输入文本的微小调整如何引起模型产生不同的预测。这有助于设计与原始文本非常相似但被模型错误分类的对抗实例。第二，按定义，凸包是包围所有潜在替换的最小凸集，确保包含所有潜在替换，同时去除冗余场景。

In [101], a certified defense technique for text classification is proposed. This method involves evaluating data sanitization defenses, which entails a thorough examination of datasets to detect and remove potential poisoning points. An upper limit is determined for the maximum test loss achievable by any attack occurring within a scenario where both the attacker and defender are active simultaneously. This upper bound encompasses all possible data points not subjected to outlier removal. Authors in [102] introduced a certified robustness approach based on semi-definite relaxation. A maximum limit is computed for potential loss in neural networks with a single hidden layer. The computed robustness certificate offers a maximal measure of resilience against various attack forms, trained concurrently with the network to ensure differentiability. The examination in [103] provides a formal proof of system robustness by integrating differential privacy into input data. Figure 7 illustrates a standard Word Substitution Ranking Attack (WSRA) architecture. A ranking model is deemed Certified Top-k Robust against WSRA on a ranked list if it effectively ensures that documents beyond the top $\mathrm{K}$ positions do not appear within those positions for all possible WSRAs. Application of differential privacy to textual data involves treating each sentence as a database and considering words as individual records. If a model satisfies a threshold (epsilon-DP) for the corresponding perturbed input, it indicates the input should be identical to the clean data.

在[101]中，提出了一种文本分类的认证防御技术。该方法涉及评估数据净化防御措施，即对数据集进行彻底检查以检测和移除潜在的投毒点。在攻击者和防御者同时活跃的场景中，确定任何攻击所能达到的最大测试损失的上限。该上限涵盖所有未经过离群值移除的潜在数据点。文献[102]提出了一种基于半正定松弛(semi-definite relaxation)的认证鲁棒性方法。计算了具有单隐藏层的神经网络潜在损失的最大值。所计算的鲁棒性证书提供了对各种攻击形式的最大弹性度量，该证书在训练过程中与网络同时进行，以确保可微性。文献[103]中的研究通过将微分隐私引入输入数据，提供了系统鲁棒性的正式证明。图7展示了标准的词替换排名攻击(Word Substitution Ranking Attack，WSRA)架构。如果一个排名模型在所有可能的WSRA中都能有效确保排名前$\mathrm{K}$之外的文档不会出现在这些位置上，则该模型被认为是认证的Top-k鲁棒。将微分隐私应用于文本数据时，将每个句子视为数据库，单词视为单个记录。如果模型对相应扰动输入满足某个阈值(epsilon-DP)，则表示该输入应与干净数据相同。

The application of word substitution in adversarial attacks can be conceptualized as a problem of combinatorial optimization. Solving this issue within the discrete textual domain is widely acknowledged as NP-hard, owing to the exponential growth of the search space concerning the input length. Various strategies have been proposed to represent word substitutions within the continuous word vector space [104-107]. These techniques seek to leverage the gradients generated by a targeted model for either attacking or bolstering its resilience through training. However, existing methods address the challenge of word replacements in vector space by employing either an "12-ball" or a "hyper-rectangle [108]". Nonetheless, these methodologies possess limitations, as they either yield perturbation sets that are inadequately comprehensive or excessively extensive. Consequently, this impedes the precise emulation of worst-case scenarios for robust training.

词替换在对抗性攻击中的应用可以被看作是一个组合优化问题。在离散文本领域解决此问题被广泛认为是NP-hard(非确定性多项式时间难题)，原因在于搜索空间随着输入长度的指数增长。已有多种策略被提出，用于在连续词向量空间中表示词替换[104-107]。这些技术旨在利用目标模型产生的梯度，通过攻击或增强其鲁棒性进行训练。然而，现有方法在向量空间中处理词替换的挑战时，采用了“12球”或“超矩形[108]”的方式。这些方法存在局限性，因为它们要么产生的扰动集不够全面，要么过于庞大，从而阻碍了对最坏情况的精确模拟，以实现鲁棒训练的目标。

![bo_d1m00jf7aajc73dif19g_10_149_159_700_283_0.jpg](images/bo_d1m00jf7aajc73dif19g_10_149_159_700_283_0.jpg)

Fig. 7 A typical Word Substitution Ranking Attack (WSRA) framework [103]

图7 典型的词替换排名攻击(WSRA)框架[103]

### 4.2 Sparse projected gradient descent (SPGD)

### 4.2 稀疏投影梯度下降(SPGD)

In the domain of visual applications, predominant strategies for generating adversarial examples entail optimization methods and the application of gradient descent [9]. However, due to the distinctive attributes of textual data, the feasibility of this method is constrained. Consequently, there exists a restricted array of white-box attacks applicable to NLP models, wherein assailants have access to the system's parameters and gradients. The projected gradient descent method is frequently utilized in the field of ML models [109]. This method involves examining each element of the input text to identify potential substitutions. Optimal perturbations are chosen from the entire set of possible perturbations and applied iteratively until further perturbations are not feasible [110]. This attack strategy has been employed in various research examinations [41, 110, 111], yielding diverse and promising results. An illustration is shown in Fig. 8.

在视觉应用领域，生成对抗样本的主要策略包括优化方法和梯度下降[9]。然而，由于文本数据的特殊属性，这种方法的可行性受到限制。因此，适用于自然语言处理(NLP)模型的白盒攻击(攻击者可以访问系统参数和梯度)数量有限。投影梯度下降法在机器学习(ML)模型中被频繁使用[109]。该方法涉及逐个检查输入文本的每个元素，以识别潜在的替换。然后从所有可能的扰动中选择最优扰动，并迭代应用，直到无法继续扰动为止[110]。这种攻击策略已在多项研究中得到应用[41, 110, 111]，取得了多样且有前景的结果。图8对此进行了示意。

In a simplistic two-word illustration, the adversary has 3 increments (represented by green arrows) away from the initial word, ultimately reaching the unrefined alterations highlighted in yellow. By setting the "sparsity coefficient" to $\sigma  = {0.5}$ , only those perturbations that are having the highest ${50}\%$ norms are retained, specifically Word A in this case. Ultimately, the perturbation of word A is mapped onto the closest neighboring path that has the greatest cosine similarity, resulting in the red arrow.

在一个简化的两个词示例中，对手有3次增量(用绿色箭头表示)远离初始词，最终达到黄色突出显示的未经过滤的变更。通过将“稀疏系数”设置为$\sigma  = {0.5}$，只保留那些具有最高${50}\%$范数的扰动，具体来说在本例中是词A。最终，词A的扰动被映射到与其余弦相似度最大的最近邻路径上，形成红色箭头。

While computing gradients within the discrete domain of textual data is impractical, there have been proposals to ascertain gradients within the continuous embedding space. For instance, [112] suggests a method where random words in the input sentence are replaced with the nearest word in the embedding space, based on the gradient direction. This replacement ensures that the disparity between the original word and the substituted word aligns with the gradient. In a related study, Sato et al. [104] extend the Adv-Text framework [113] to improve the generation of adversarial perturbations. They achieve this by aligning the perturbation directions in the embedding space with meaningful embedding vectors. However, these techniques may significantly alter multiple words within the sentence, resulting in noticeable changes. Recently, [114] introduced the gradient-based distributional attack (GBDA) to target text transformers. This approach considers a probability distribution for each word in the adversarial sentence across the vocabulary. The continuous distribution matrix is optimized to deceive the target model. However, their proposed formulation exhibits considerable overparameterization. Since these methods are tailored for discrete data, it's possible to encounter an embedding vector during the iterative process that has already been computed due to projection. Additionally, if the perturbation vector lacks sufficient magnitude, the updated vectors will project onto the previous sentence. In such cases, the algorithm may get stuck in a repetitive cycle due to consistent gradient computations. To address this, [115] propose a strategy where embedding vectors are updated through projection only when the projected sentence has not been previously generated.

虽然在文本数据的离散域中计算梯度是不切实际的，但已有提议在连续嵌入空间中确定梯度。例如，[112]提出了一种方法，在该方法中，输入句子中的随机词根据梯度方向被替换为嵌入空间中最接近的词。这种替换确保原始词与替换词之间的差异与梯度保持一致。在相关研究中，佐藤等人[104]扩展了Adv-Text框架[113]，以改善对抗扰动的生成。他们通过将嵌入空间中的扰动方向与有意义的嵌入向量对齐来实现这一点。然而，这些技术可能会显著改变句子中的多个词，导致明显的变化。最近，[114]引入了基于梯度的分布式攻击(GBDA)，用于针对文本变换器。这种方法考虑每个词在词汇表中的概率分布。连续分布矩阵被优化以欺骗目标模型。然而，他们提出的公式存在大量的参数过度设计问题。由于这些方法是为离散数据量身定制的，在迭代过程中可能会遇到由于投影已计算的嵌入向量。此外，如果扰动向量的幅度不足，更新后的向量将投影回之前的句子。在这种情况下，算法可能会因持续的梯度计算而陷入重复循环。为了解决这个问题，[115]提出了一种策略，即只有在投影句子未曾生成过时，才通过投影更新嵌入向量。

### 4.3 Population-based optimization

### 4.3 基于群体的优化

Adversarial attacks pose a significant threat to DNNs, widely employed across various domains including image processing, NLP, and audio analysis [116]. In contemporary instances of textual adversarial attacks, a prevailing strategy involves the utilization of a black-box soft label. This label is acquired by exploiting either gradient information or the model's confidence. Consequently, executing adversarial attacks based solely on the predicted top labels of the hard-label model presents a formidable and realistic challenge. Current methodologies for executing hard-label adversarial attacks utilize population-based genetic optimization algorithms. A population-based optimization algorithm, a variant of genetic algorithms used in optimization, aims to discover outliers capable of altering the model's classifications or predictions [117, 118]. Implementing the described approach necessitates maintaining a dynamic "population" of potential inputs that can be continually adjusted and combined [119]. In contrast, a "black-box" attack denotes an adversarial attack where the attacker lacks access to the internal structure or parameters of the model. This attack methodology has been employed in various examinations [29, 120-123].

对抗攻击对深度神经网络(DNN)构成了重大威胁，这些网络广泛应用于图像处理、自然语言处理(NLP)和音频分析等多个领域[116]。在当代的文本对抗攻击中，一种普遍策略是利用黑盒软标签。这一标签通过利用梯度信息或模型的置信度获得。因此，仅基于硬标签模型的预测最高标签执行对抗攻击，具有极大的挑战性和现实意义。目前执行硬标签对抗攻击的方法采用基于群体的遗传优化算法。群体优化算法是遗传算法在优化中的一种变体，旨在发现能够改变模型分类或预测的异常值[117, 118]。实现上述方法需要维护一个潜在输入的动态“群体”，可以不断调整和组合[119]。而“黑盒”攻击指攻击者无法访问模型的内部结构或参数的对抗攻击。这种攻击方法已在多项研究中得到应用[29, 120-123]。

The examination performed by the researchers in [56] illustrates the effectiveness of the Deepwordbug in generating subtle alterations in text. This method proves particularly efficient within a "black box" context, where the classifier is induced to misclassify textual input. The methodology employs an innovative scoring technique to identify crucial tokens, the modification of which leads to erroneous predictions by the classifier. The research detailed in [29] focuses on the Textbugger framework, which prioritizes the detection of the most pertinent sentences before utilizing a scoring function to pinpoint keywords within these sentences. In the study conducted by [57], a model is introduced as a population optimization algorithm functioning as a black-box approach. Its objective is to generate adversarial examples that mimic the original input semantically and syntactically. The SememePSO algorithm [121], a variant of particle swarm optimization, is employed as the search algorithm to create adversarial examples within black-box scenarios. Researchers in [124] investigate the utilization of contextual alterations from the BERT mask language model to create seemingly innocuous attacks. The research by authors in [54] proposes a novel approach to word substitution order based on considerations of word salience and classification probability. Additionally, they suggest a greedy algorithm for implementing this approach in the context of textual adversarial attacks. The foundational method utilized in Textfooler [125] revolves around textual adversarial techniques, specifically employing synonyms to replace vulnerable words within sentences. Conversely, the study outlined by [29] introduces Bertattack as a methodology for generating superior quality adversarial examples by leveraging pre-trained masked language models based on BERT. In a subsequent examination [126], researchers introduce a method called locally sensitive hashing (LSH) and Attention, which integrates attention mechanisms and LSH to reduce the number of queries effectively. This approach amalgamates the advantages of both techniques. In their research, Wang et al. [127] introduce SemAttack, a method involving the formulation of semantic perturbation functions to identify optimal perturbations within different semantic spaces, potentially enhancing the efficiency of generating adversarial examples. In their recent work, Lee et al. [128] introduce discrete block bayes attack, a method leveraging Bayesian optimization to query discrete text data. The authors utilize the automatic relevance determination (ARD) [129] classification kernel to dynamically ascertain significant positions, facilitating the efficient generation of adversarial examples.

研究人员在[56]中进行的检验展示了Deepwordbug在生成细微文本变更方面的有效性。这种方法在“黑盒”环境中尤为高效，即分类器被诱导产生误分类。该方法采用创新的评分技术来识别关键的词元，修改这些词元会导致分类器产生错误的预测。文献[29]的研究重点是Textbugger框架，该框架优先检测最相关的句子，然后利用评分函数在这些句子中定位关键词。在[57]的研究中，提出了一种作为黑箱方法运行的群体优化模型，其目标是生成在语义和句法上模仿原始输入的对抗样本。SememePSO算法[121]，一种粒子群优化(Particle Swarm Optimization)变体，被用作搜索算法，在黑箱场景中创建对抗样本。文献[124]的研究探讨了利用BERT掩码语言模型的上下文变化来制造看似无害的攻击。作者在[54]提出了一种基于词语显著性和分类概率的词替换顺序新方法，并建议采用贪心算法在文本对抗攻击中实现该方法。Textfooler[125]的基础方法围绕文本对抗技术，特别是利用同义词替换句子中的易受攻击词。相反，文献[29]介绍了Bertattack，通过利用基于BERT的预训练掩码语言模型，生成更高质量的对抗样本。在随后的研究[126]中，研究人员提出了局部敏感哈希(LSH)和注意力机制(Attention)，结合这两种技术以有效减少查询次数。这种方法融合了两者的优势。在他们的研究中，Wang等人[127]提出了SemAttack，一种通过构建语义扰动函数以识别不同语义空间中的最优扰动，从而提升生成对抗样本效率的方法。在最新工作中，Lee等人[128]引入了离散块贝叶斯攻击(discrete block bayes attack)，利用贝叶斯优化对离散文本数据进行查询。作者使用自动相关性判定(ARD)[129]分类核，动态确定重要位置，从而高效生成对抗样本。

![bo_d1m00jf7aajc73dif19g_11_244_159_1266_347_0.jpg](images/bo_d1m00jf7aajc73dif19g_11_244_159_1266_347_0.jpg)

Fig. 8 A two-word sequence being used as an example of SPGD [41]

图8 一个由两个词组成的序列，作为SPGD[41]的示例

### 4.4 Word saliency based methods

### 4.4 基于词语显著性的方法

The majority of existing black-box saliency computation techniques in the domain of NLP rely on comparing the predictive outcomes of the original instance with its approximate representations [130]. Typically, these techniques require a considerable number of iterations through the model to yield prediction results. However, this poses challenges for practical implementation and fails to fully leverage the rich features inherent in the instances. The lexical elements within textual instances exhibit certain attributes indicative of their semantic content and contextual surroundings, such as their syntactic category (part of speech), position within the sentence, and other pertinent factors. These attributes hold promise in indicating the importance of words within the given textual instance [130]. This connection is exemplified by the correlation observed between the distribution of word saliency in textual instances and specific tasks. It is widely recognized that nouns, adjectives, and verbs are content-bearing words that convey meanings [121]. To this point, previous studies have primarily focused on extracting the neural representation of specific linguistic content from the embeddings of the GPT-2 model or on obtaining empirical estimations of probabilities for subsequent words from the model's output [131-133]. Additionally, an initial inquiry conducted by authors in [134] showcased the potential to clarify the sequence of cortical computations implicated in language comprehension through the utilization of the BERT model [23]. This was accomplished by supplying a text as input to the model and utilizing the output of its attention heads, which are fundamental components of an attention-based deep learning model that directly process the input words [134]. However, previous research has not considered the aspect of "reasoning" in the model, which involves assessing input words and assigning responsibility to each word for generating a specific output [135]. To address this issue, one can utilize "input saliency" techniques to generate the saliency score, a simple weighting assigned to each word within the input sequence indicating its importance in the model’s prediction of the subsequent word $\left\lbrack  {{135},{136}}\right\rbrack$ .

在自然语言处理(NLP)领域，现有大多数黑箱显著性计算技术依赖于比较原始实例与其近似表示的预测结果[130]。通常，这些技术需要大量的模型迭代以获得预测结果。然而，这在实际应用中存在挑战，且未能充分利用实例中固有的丰富特征。文本实例中的词汇元素具有某些属性，能指示其语义内容和上下文环境，例如其句法类别(词性)、在句中的位置以及其他相关因素。这些属性有望揭示词在特定文本实例中的重要性[130]。这种联系通过词语显著性在文本实例中的分布与特定任务之间的相关性得以体现。普遍认为，名词、形容词和动词是承载意义的内容词[121]。到目前为止，相关研究主要集中在从GPT-2模型的嵌入中提取特定语言内容的神经表示，或从模型输出中获得后续词的概率经验估计[131-133]。此外，文献[134]的作者最初通过使用BERT模型[23]，展示了阐明涉及语言理解的皮层计算序列的潜力。这是通过将文本作为输入提供给模型，并利用其注意力头的输出实现的，注意力头是基于注意力机制的深度学习模型的基本组成部分，直接处理输入词[134]。然而，先前的研究未考虑模型中的“推理”方面，即评估输入词并为每个词在生成特定输出中的责任分配。为解决这一问题，可以利用“输入显著性”技术生成显著性得分，这是一种简单的加权方式，赋予输入序列中的每个词一个重要性指标，用以指示其在模型预测下一个词中的作用$\left\lbrack  {{135},{136}}\right\rbrack$ 。

Understanding the interrelations among diverse word attributes and the model's output can aid in establishing a correlation between samples and their saliency distribution. This process also allows for the assessment of each component's individual impact on the model's outputs. In the domain of deep learning, it's customary to evaluate the importance of input components using output gradients. However, in NLP tasks, words are primarily represented as vectors, making it challenging to accurately compute saliency values at the word level. INT-GRAD's resilience, as evidenced by its authors in [137], effectively addresses this NLP challenge by comparing values to a baseline. Another method introduced by authors in [138] involves backpropagating contributions of all neurons in a DNN to each input feature, enabling comprehensive saliency analysis. In [139], a technique called instance-wise feature selection is proposed. Here, a feature selector is trained to maximize mutual information between selected features and the output. The goal is to identify a subset of features containing the most informative characteristics in the samples.

理解不同词属性之间的相互关系以及模型输出之间的关系，有助于建立样本与其显著性分布之间的关联。该过程还可以评估每个组成部分对模型输出的单独影响。在深度学习领域，通常使用输出梯度来评估输入组成部分的重要性。然而，在自然语言处理(NLP)任务中，词语主要以向量形式表示，因此难以在词级别准确计算显著性值。INT-GRAD的鲁棒性，如其作者在[137]中所证明，通过将值与基线进行比较，有效解决了这一NLP挑战。另一种由[138]的作者提出的方法涉及将深度神经网络(DNN)中所有神经元的贡献反向传播到每个输入特征，从而实现全面的显著性分析。在[139]中，提出了一种称为实例级特征选择(instance-wise feature selection)的技术。该方法训练一个特征选择器，以最大化所选特征与输出之间的互信息。目标是识别一组包含样本中最具信息量特征的子集。

### 4.5 Particle swarm optimization (PSO)-based methods

### 4.5 基于粒子群优化(PSO)的方法

The PSO algorithm is a widely used search algorithm applied in the generation of adversarial examples [121]. In this methodology, each member of the population undergoes perturbation by exploring all possible candidates. This process involves substituting each input and subsequently selecting one input example during each epoch. Through employing this algorithm, it becomes feasible to identify the most advantageous modified input from the entire population [110]. This adversarial technique finds application in numerous studies examining ML model resilience against adversarial attacks $\left\lbrack  {{110},{120},{121},{140},{141}}\right\rbrack$ . Recent advancements have introduced several methodologies for word-level attacks. Among these methods, the utilization of sememes and PSO has demonstrated superior performance in terms of both attack success rate and average modification rate. However, in complex scenarios such as solving high-dimensional combinatorial optimization problems, the PSO algorithm often faces challenges concerning insufficient robustness, premature convergence, and exploration-exploitation imbalance. These challenges are particularly pronounced when dealing with sentences containing a large number of words. To effectively attack the victim model with a reduced modification rate, it is imperative for the algorithm to achieve a favorable balance between exploitation and exploration.

粒子群优化(PSO)算法是一种广泛应用于生成对抗样本(adversarial examples)的方法[121]。在该方法中，群体中的每个成员通过探索所有可能的候选进行扰动。这个过程包括替换每个输入，并在每个训练轮次中选择一个输入样本。通过采用该算法，可以从整个群体中识别出最优的修改输入[110]。这种对抗技术在许多研究中用于检验机器学习(ML)模型对抗攻击的鲁棒性$\left\lbrack  {{110},{120},{121},{140},{141}}\right\rbrack$。近年来，出现了多种用于词级攻击的方法。在这些方法中，语素(sememes)和粒子群优化的结合在攻击成功率和平均修改率方面表现出色。然而，在解决高维组合优化问题等复杂场景中，PSO算法常面临鲁棒性不足、早熟收敛和探索-利用平衡等挑战。当处理包含大量词语的句子时，这些问题尤为突出。为了以较低的修改率有效攻击目标模型，算法必须在利用与探索之间取得良好的平衡。

In recent times, several enhanced PSO variants have been proposed to tackle optimization problems of considerable scale. These variants can be categorized into three distinct groups: methods directly improving the PSO algorithm, PSOs coevolving cooperatively, and PSOs aided by surrogate models. In [142], a competitive swarm optimizer (CSO) was devised explicitly for addressing large-scale global optimization problems. Notably, their approach diverges from traditional methods by excluding the incorporation of personal best positions or global best positions during particle update processes. In [143], a level-based learning swarm optimizer (LLSO) was introduced with the aim of enhancing learning. This optimizer is tailored to tackle high-dimensional optimization problems by classifying particles into different levels and applying distinct treatment to each level. The aforementioned improved PSO variants for large-scale optimization encompass two methods falling within the first category. The classical cooperatively co-evolving PSO algorithm, as proposed in [144], employs a random grouping technique to decompose a large-scale problem into multiple subproblems, which are then addressed individually. Several surrogate-assisted evolutionary algorithms (SAEAs) [145] have been suggested as a means of tackling intricate and computationally demanding optimization problems.

近年来，为应对大规模优化问题，提出了一些增强型粒子群优化(PSO)变体。这些变体可以分为三类:直接改进PSO算法的方法、协同进化的粒子群优化(PSO)以及由代理模型辅助的PSO。在[142]中，设计了一种竞争群体优化器(CSO)，专门用于解决大规模全局优化问题。值得注意的是，他们的方法不同于传统方法，未在粒子更新过程中引入个体最优位置或全局最优位置。在[143]中，提出了一种基于层级学习的群体优化器(LLSO)，旨在增强学习能力。该优化器针对高维优化问题，通过将粒子划分为不同层级，并对每个层级采取不同的处理方式。上述用于大规模优化的改进型PSO变体中，有两种属于第一类。经典的协同进化粒子群算法(cooperative co-evolving PSO)，如[144]所提出，采用随机分组技术，将大规模问题分解为多个子问题，逐一解决。还有一些代理辅助的进化算法(SAEAs)[145]被提出，用于应对复杂且计算量大的优化问题。

## 5 Methods for strengthening LLMs

## 5 强化大型语言模型(LLMs)的方法

There exist numerous methodologies for enhancing the resilience of LLMs against adversarial attacks [9]. These methodologies encompass word recognition techniques, stochastic ensembles, interval-bound propagation, ensemble classifiers employing randomized smoothing, and additional approaches. This section delineates the most prevalent robustness techniques and their respective implementations.

目前有多种方法可以增强大型语言模型(LLMs)对抗对抗性攻击的鲁棒性[9]。这些方法包括词识别技术、随机集成、区间界限传播、采用随机平滑的集成分类器以及其他方法。本节将介绍最常用的鲁棒性技术及其具体实现。

### 5.1 Model Ensemble

### 5.1 模型集成

When it comes to acquiring complex models, DNNs have demonstrated high efficacy [23, 161, 162] and have achieved notable success across various domains. Despite their proficiency in data representation, their capacity for generalization may be compromised due to elevated levels of model variance. It is customary to amalgamate the weights or predictions from multiple models when making predictions, a practice known as model ensemble [163, 164]. As evidenced by the authors in [160], a simple two-model ensemble outperforms a solitary model significantly in computer vision tasks. Each network undergoes training employing both a supervised learning loss and a KLD-based mimicry loss to align the probability estimates with those of its counterparts, as depicted in Fig. 9. While model ensemble presents several advantages, its application in LLMs remains constrained. The primary impediments include substantial computational overhead and extensive storage requirements, both of which scale with the number of models. Given that edge devices typically possess limited memory and stringent latency demands, ensembling LLMs for deployment can be prohibitively costly. Recent endeavors have employed weight sharing to mitigate the memory burden by reducing the number of weights each model must store in memory [165- 167]. In this scheme, all models utilize identical bottom-layer weights, with each model employing its own parallel, non-shared top-layer weights. Weight sharing fosters increased diversity in unshared branches, thereby facilitating more generalized learning of shared representations [168-170]. However, the advantages of a weight-sharing approach diminish considerably for large models. Due to memory constraints, a substantial portion of the weights in the bottom layer must be shared, resulting in minimal diversity among the resulting models [166, 171-173]. Consequently, the generalization performance of their ensemble suffers from a dearth of model diversity.

在获取复杂模型方面，深度神经网络(DNNs)表现出极高的效率[23, 161, 162]，并在多个领域取得了显著成功。尽管其在数据表示方面具有优势，但由于模型方差较高，其泛化能力可能受到影响。在进行预测时，通常会结合多个模型的权重或预测结果，这一做法被称为模型集成[163, 164]。如[160]的作者所示，简单的两模型集成在计算机视觉任务中明显优于单一模型。每个网络都通过监督学习损失和基于KLD的模仿损失进行训练，以使其概率估计与其他模型保持一致，如图9所示。虽然模型集成具有多种优势，但在大型语言模型(LLMs)中的应用仍受限制。主要障碍包括较高的计算开销和大量存储需求，这些都随着模型数量的增加而扩大。考虑到边缘设备通常存储空间有限且对延迟要求严格，将多个LLMs进行集成部署成本极高。近期的研究通过权重共享技术减轻存储负担，即减少每个模型需要存储的权重[165-167]。在这种方案中，所有模型共享底层的相同权重，而每个模型拥有自己独立的非共享顶层权重。权重共享促进了未共享分支的多样性，从而有助于更好地学习共享表示[168-170]。然而，对于大型模型而言，权重共享的优势大大减弱。由于存储限制，底层的许多权重必须共享，导致模型之间的多样性极低[166, 171-173]。因此，集成模型的泛化性能受到模型多样性不足的影响。

Table 1 An overview of recent approaches that used LLM based evaluation methods

表1:近期基于大型语言模型(LLM)评估方法的概述

<table><tr><td>Paper</td><td>Methodology</td><td>Metric</td><td>Dataset</td><td>Key features</td></tr><tr><td>Wang et al. [146]</td><td>GE2E-ASV</td><td>EER</td><td>TIMIT</td><td>Adversarial instances where an end-to-end speech verification (SV) system is attacked are employed</td></tr><tr><td>Abdelali et al. [147]</td><td>Zero-shot learning</td><td>WER, BLEU</td><td>59 different datasets</td><td>Performance of large foundation models (FM) for standard Arabic NLP was evaluated</td></tr><tr><td>Bang et al. [148]</td><td>Zero-shot learning</td><td>ROUGE-1, JGA, BLEU</td><td>FLoRes-200, OpenDialKG</td><td>First ever thorough evaluation of generative LLMs - MEGA</td></tr><tr><td>Chen et al. [149]</td><td>Empirical study</td><td>BERTScore, ParaScore, PRISM etc</td><td>Twitter(Extend), dialog-level FED</td><td>The experiments show that ChatGPT can evaluate text quality from multiple perspectives without external references</td></tr><tr><td>Choi et al. [150]</td><td>BERT-based finetuning</td><td>CLS, PAIR, REG, SPAN</td><td>SOCKET datasets</td><td>SOCKET, a new benchmark based on theory, includes 58 NLP tasks categorized into five categories to assess social knowledge</td></tr><tr><td>Chia et al. [151]</td><td>LoRA</td><td>Accuracy</td><td>MMLU, BBU, DROP etc</td><td>A specialized evaluation suite has been developed to specifically cater to LLMs that are fine-tuned for instructional purposes</td></tr><tr><td>Fu et al. [152]</td><td>Few-shot prompting</td><td>Accuracy</td><td>GSM8k, MATH, BigBench Hard etc.</td><td>An open-source evaluation suite is introduced to assess the capabilities of LLMs in multi-step reasoning</td></tr><tr><td>Gekhman et al. [153]</td><td>Synthetic data generation</td><td>ROC-AUC</td><td>CNN/DM, XSum</td><td>An approach to create synthetic data by labeling various model-generated summaries with an LLM</td></tr><tr><td>Honovich et al. [154]</td><td>Empirical analysis</td><td>F1, BLEURT, QuestEval etc.</td><td>DialFact, QAGS-X, MNBM etc.</td><td>A thorough survey and evaluation of factual consistency metrics in standardized texts from various tasks</td></tr><tr><td>Lai et al. [155]</td><td>Zero-shot & supervised learning</td><td>F1 Score</td><td>XGLUE-POS, Huggingface, SMiLER</td><td>Evaluating LLMs for multilingual NLP applications to enhance information</td></tr></table>

<table><tbody><tr><td>论文</td><td>方法学</td><td>指标</td><td>数据集</td><td>关键特征</td></tr><tr><td>王等人 [146]</td><td>GE2E-ASV</td><td>误识率(EER)</td><td>TIMIT</td><td>采用对端到端语音验证(SV)系统的对抗实例进行攻击</td></tr><tr><td>阿卜杜拉利等人 [147]</td><td>零样本学习</td><td>词错误率(WER)、BLEU</td><td>59个不同的数据集</td><td>评估大型基础模型(FM)在标准阿拉伯语自然语言处理(NLP)中的表现</td></tr><tr><td>邦等人 [148]</td><td>零样本学习</td><td>ROUGE-1、JGA、BLEU</td><td>FLoRes-200、OpenDialKG</td><td>首次全面评估生成式大型语言模型(LLMs)——MEGA</td></tr><tr><td>陈等人 [149]</td><td>实证研究</td><td>BERTScore、ParaScore、PRISM等</td><td>Twitter(扩展版)、对话级FED</td><td>实验表明，ChatGPT可以从多个角度评估文本质量，无需外部参考</td></tr><tr><td>崔等人 [150]</td><td>基于BERT的微调</td><td>CLS、PAIR、REG、SPAN</td><td>SOCKET数据集</td><td>SOCKET是一个基于理论的新基准，包含58个自然语言处理任务，分为五类，用于评估社会知识</td></tr><tr><td>夏等人 [151]</td><td>LoRA</td><td>准确率</td><td>MMLU、BBU、DROP等</td><td>开发了专门的评估套件，旨在针对经过微调以执行指令的LLMs</td></tr><tr><td>傅等人 [152]</td><td>少样本提示(Few-shot prompting)</td><td>准确率</td><td>GSM8k、MATH、BigBench Hard等</td><td>引入一个开源评估套件，用于评估LLMs在多步骤推理中的能力</td></tr><tr><td>盖克曼等人 [153]</td><td>合成数据生成</td><td>ROC-AUC</td><td>CNN/DM、XSum</td><td>一种通过用LLM标注各种模型生成的摘要来创建合成数据的方法</td></tr><tr><td>霍诺维奇等人 [154]</td><td>实证分析</td><td>F1、BLEURT、QuestEval等</td><td>DialFact、QAGS-X、MNBM等</td><td>对来自不同任务的标准化文本中的事实一致性指标进行了全面的调研与评估</td></tr><tr><td>赖等人 [155]</td><td>零样本与有监督学习</td><td>F1得分</td><td>XGLUE-POS、Huggingface、SMiLER</td><td>评估LLMs在多语言自然语言处理(NLP)应用中的能力以增强信息获取</td></tr></tbody></table>

Table 1 continued

表1续

<table><tr><td>Paper</td><td>Methodology</td><td>Metric</td><td>Dataset</td><td>Key features</td></tr><tr><td>Lopez et al. [156]</td><td>TF-IDF</td><td>R2Score</td><td>BookCorpus, 8 M Web Pages</td><td>A novel approach for assessing and comprehending the capabilities of different LLMs in financial market analysis</td></tr><tr><td>Lee et al. [157]</td><td>Monte Carlo estimation, log probability estimation</td><td>Acc., JSD, DCE</td><td>ChaosNLI, PK2019, ANLI-R3 etc</td><td>Comparison of two methods for assessing the efficacy and consistency of LLM distribution with human subjects</td></tr><tr><td>Lin et al. [158]</td><td>Zero-shot, few-shot</td><td>Accuracy</td><td>USMLE, MedMCQA, PubMedQA</td><td>The study examined various scenarios for prompting, including Chain-of-Thought (CoT), zero- and few-shot, retrieval augmentation, and question-answer exemplars prefixed to the question.</td></tr><tr><td>Liu et al. [159]</td><td>Pre-trained LM</td><td>Accuracy</td><td>LogiQA 2.0 ood, ConTRoL</td><td>Standards requiring reasoning are used to assess the reading comprehension and natural language inference tasks, which are multiple-choice.</td></tr><tr><td>Liu et al. [159]</td><td>Natural language inference</td><td>Entropy-based metrics</td><td>WikiBio</td><td>Black-box model responses can be fact-checked using a simple sampling-based approach with zerc resources</td></tr></table>

<table><tbody><tr><td>论文</td><td>方法学</td><td>指标</td><td>数据集</td><td>关键特征</td></tr><tr><td>Lopez 等 [156]</td><td>TF-IDF(词频-逆文档频率)</td><td>R2评分</td><td>BookCorpus，800万网页</td><td>一种评估和理解不同大型语言模型(LLMs)在金融市场分析中能力的创新方法</td></tr><tr><td>Lee 等 [157]</td><td>蒙特卡洛估计，对数概率估计</td><td>准确率(Acc.)，JSD(杰克德拉-布雷(Jensen-Shannon Divergence))，DCE(差异性一致性评估)</td><td>ChaosNLI(混沌自然语言推理)，PK2019，ANLI-R3 等</td><td>比较两种方法在评估LLM分布的有效性和与人类受试者一致性方面的表现</td></tr><tr><td>Lin 等 [158]</td><td>零样本(Zero-shot)，少样本(Few-shot)</td><td>准确率</td><td>USMLE(美国医学执照考试)，MedMCQA，PubMedQA</td><td>该研究考察了多种提示场景，包括链式思维(Chain-of-Thought，CoT)、零样本和少样本、检索增强以及在问题前加示例的问答方式。</td></tr><tr><td>Liu 等 [159]</td><td>预训练语言模型(Pre-trained LM)</td><td>准确率</td><td>LogiQA 2.0 OOD(异常检测)，ConTRoL</td><td>采用需要推理的标准来评估阅读理解和自然语言推断任务，这些任务为多项选择题。</td></tr><tr><td>Liu 等 [159]</td><td>自然语言推断</td><td>基于熵的指标</td><td>WikiBio</td><td>黑箱模型的响应可以通过一种简单的采样方法在零资源条件下进行事实核查</td></tr></tbody></table>

![bo_d1m00jf7aajc73dif19g_14_209_1424_1316_356_0.jpg](images/bo_d1m00jf7aajc73dif19g_14_209_1424_1316_356_0.jpg)

Fig. 9 Schematic of deep mutual learning (DML) [160]

图9 深度互学习(Deep Mutual Learning, DML)示意图 [160]

### 5.2 Prevention against jailbreak

### 5.2 防止越狱

The incorporation of vast text corpora sourced directly from the Internet significantly enhances the attractiveness of LLMs, ensuring the credibility and authenticity of the generated content. However, this approach exposes LLMs to a plethora of information, including objectionable materials such as hate speech, spyware, and erroneous data [174]. Despite attempts to humanize LLMs, prominent models like GPT, Llama, Claude, and PaLM remain susceptible to producing offensive content through jailbreaking attacks. Among these attacks, adversarial prompting stands out as a method where an attacker manipulates the prompts provided to the LLM, resulting in inappropriate outputs [175, 176]. The recent findings of [177] are particularly concerning as they reveal that even highly performing LLMs can be compromised by appending adversarially-selected characters to different prompts. This encompasses GPT, Claude, and PaLM. The literature concerning language model robustness [178] illustrates various mitigation strategies. The majority of these defenses, including those utilizing adversarial training [113, 179] and data augmentation [55], necessitate retraining the underlying model, a computationally impractical task for LLMs. The lack of transparency in closed-source LLMs necessitates reliance solely on query access for potential defenses. The vulnerabilities of LLMs introduce a new set of challenges, exacerbated by these constraints and the absence of a proven solution to mitigate the threat posed by GCG. In [180], various defensive measures are explored, such as implementing a perplexity filter pre-processing step, altering the formulation of input prompts, and subjecting the computer to adversarial training. The effectiveness of these strategies varies. While heuristic detection-based techniques demonstrate notable performance, adversarial training is deemed infeasible due to the considerable computational resources required to retrain LLMs. In [181], the authors propose employing a safety filter on substrings of input prompts, presenting a method that provides verifiable assurances of robustness. However, despite its potential, this approach is suboptimal as its computational complexity scales with the size of the input prompt.

从互联网直接获取的大量文本语料库的引入显著增强了大型语言模型(LLMs)的吸引力，确保了生成内容的可信度和真实性。然而，这种方法也使LLMs暴露在大量信息中，包括令人反感的材料如仇恨言论、间谍软件和错误数据[174]。尽管试图使LLMs更具人性化，但像GPT、Llama、Claude和PaLM等知名模型仍然容易受到越狱攻击而产生冒犯性内容。在这些攻击中，敌对提示(adversarial prompting)尤为突出，即攻击者操控提供给LLM的提示，导致生成不当的输出[175, 176]。最近的研究[177]尤其令人担忧，因为它们揭示即使性能很高的LLMs也可能被通过在不同提示中附加敌对字符而破坏，包括GPT、Claude和PaLM。关于语言模型鲁棒性的文献[178]展示了多种缓解策略。这些防御措施大多依赖于对基础模型的再训练，如对抗训练[113, 179]和数据增强[55]，但这对于LLMs来说在计算上是不切实际的。闭源LLMs缺乏透明度，只能通过查询访问，这限制了潜在的防御手段。LLMs的脆弱性带来了新的挑战，这些限制和缺乏有效解决方案的现状加剧了GCG(生成内容操控)带来的威胁。在[180]中，探讨了多种防御措施，例如在预处理步骤中引入困惑度过滤器、改变输入提示的表达方式，以及对模型进行对抗训练。这些策略的效果各异。虽然启发式检测技术表现出一定的效果，但由于再训练LLMs所需的巨大计算资源，对抗训练被认为不可行。文献[181]提出在输入提示的子串上使用安全过滤器的方法，提供了可验证的鲁棒性保证，但该方法的计算复杂度随着输入提示的长度增加而上升，表现不够理想。

### 5.3 Deferentially private decoding

### 5.3 差分隐私解码

LLMs possess the capacity to anticipate subsequent or missing elements within a phrase, enabling them to undergo training for generating token sequences. Typically, their output manifests as a probability distribution across the vocabulary terms, from which the projected token originated. Initially introduced as LLMs, LSTM-based sequence-to-sequence (seq2seq) models were pioneered by Sutskever et al. [1], yet recent advancements have favored transformer-based models, as evidenced by Vaswani et al. [182], Devlin et al. [23], Radford et al. [183], and Conneau et al. [184]. Despite the performance enhancements attributed to LLMs, recent examinations have unveiled their inadvertent propensity to memorize segments of their training data [26, 185]. The likelihood of accurately reproducing segments of training data when presented with a well-crafted prompt increases if these models commit it to memory. Such memorization practices, particularly concerning sensitive consumer data, pose significant privacy concerns. Moreover, intensive memorization methodologies may compromise utility and fairness due to their misalignment with actual data distributions. Upon initial scrutiny, the problem of memorization leading to over-fitting of the training data arises [26, 186, 187]. The assertions made in [185] refute this notion by demonstrating that several regularization techniques, including early stopping and dropout, are insufficient in mitigating memorization. Differential privacy (DP) training, as outlined by the authors in [188], stands as the sole approach effectively thwarting model memorization.

LLMs具有预测短语中后续或缺失元素的能力，使其能够进行生成令牌序列的训练。通常，它们的输出表现为在词汇表中的概率分布，从中可以推断出生成的令牌。最初作为LLMs引入，基于LSTM(长短期记忆网络)的序列到序列(seq2seq)模型由Sutskever等人[1]开创，但近年来，变换器(Transformer)模型成为主流，代表人物有Vaswani等人[182]、Devlin等人[23]、Radford等人[183]和Conneau等人[184]。尽管LLMs的性能得到了提升，但最新研究揭示它们在无意中倾向于记忆部分训练数据[26, 185]。如果模型将训练数据记忆在心，面对精心设计的提示时，准确复现训练片段的可能性会增加。这种记忆行为，尤其涉及敏感的用户数据，带来了严重的隐私问题。此外，过度记忆的方法可能会因偏离实际数据分布而影响模型的实用性和公平性。初步来看，记忆导致过拟合训练数据的问题显而易见[26, 186, 187]。但[185]的研究反驳了这一观点，证明包括早停(early stopping)和Dropout在内的多种正则化技术不足以缓解记忆问题。作者在[188]提出的差分隐私(Differential Privacy, DP)训练，是唯一能有效防止模型记忆的方案。

The predominant technique for integrating DP into ML models, such as differentially private stochastic gradient descent (DP-SGD) [189, 190], typically involves adjustments to the training procedure. These adjustments are designed to mitigate privacy risks by reducing the model's dependency on specific training data points. However, they incur substantial costs in terms of computational resources, training duration, and model efficacy. Despite recent discussions addressing these challenges [191-193], DP training remains an active area of research due to the absence of a comprehensive approach that accounts for all relevant considerations. Rebuilding large-scale language models from scratch, while maintaining performance levels, necessitates significant investments in time and resources, rendering it impractical in real-world commercial settings constrained by such limitations. There is currently a trend towards formally defining and applying DP in pre-trained ML models during the inference phase $\left\lbrack  {{192},{194}}\right\rbrack$ .

将DP引入机器学习模型的主要技术是差分隐私随机梯度下降(Differentially Private Stochastic Gradient Descent, DP-SGD)[189, 190]，通常通过调整训练过程实现。这些调整旨在降低模型对特定训练数据点的依赖，从而减小隐私风险，但也带来了巨大的计算成本、训练时间和模型性能的损失。尽管近期关于这些挑战的讨论不断[191-193]，但由于缺乏全面考虑所有相关因素的方案，DP训练仍是一个活跃的研究领域。从零开始重建大规模语言模型，同时保持其性能，需投入大量时间和资源，在实际商业环境中难以实现。目前，越来越多的研究趋向于在推理阶段对预训练模型应用正式定义的DP方案$\left\lbrack  {{192},{194}}\right\rbrack$。

### 5.4 Empirical & certified defenses

### 5.4 实证与认证防御

Over the years, several heuristic methodologies have been proposed to detect and mitigate adversarial attacks in computer vision [181, 195-199] and NLP tasks [200-202]. In a recent study [180], defensive strategies tailored to counterattacks by Zou et al. [177] are examined. The examination assesses the effectiveness of methodologies such as perplexity filtering, paraphrase, and adversarial training. However, it has been observed that empirical defenses against specific adversarial attacks are susceptible to more robust attacks [203-206]. The lack of empirical robustness against one adversarial attack does not guarantee robustness against more potent attacks in other instances. Our research focuses on developing verifiable robustness assurances applicable to all potential adversarial attacks within a specified threat model.

多年来，已经提出了几种启发式方法来检测和缓解计算机视觉(Computer Vision)[181, 195-199]和自然语言处理(NLP)任务[200-202]中的对抗性攻击。在最近的一项研究[180]中，针对 Zou等人[177]的反击策略进行了评估。该评估考察了诸如困惑度过滤(perplexity filtering)、改写(paraphrase)和对抗训练(adversarial training)等方法的有效性。然而，研究发现，针对特定对抗性攻击的经验性防御措施容易受到更强大攻击的影响[203-206]。对某一对抗性攻击缺乏经验性鲁棒性并不意味着在其他情况下对更强攻击也具有鲁棒性。我们的研究重点是开发适用于在特定威胁模型内所有潜在对抗性攻击的可验证鲁棒性保证。

Extensive research has been conducted in the field of computer vision regarding defenses that provide demonstrable guarantees of resilience. Various techniques are employed in the field, including interval-bound propagation [107, 207-209], curvature bounds [210-212], and randomized smoothing [213-216]. Certified defenses for applications in NLP have also been examined. Ye et al. propose a methodology for mitigating word replacements in the context of text categorization by utilizing a predetermined set of synonyms [217]. Zhao et al. employ semantic smoothing as a means of mitigating natural language threats [218]. The introduction of noise into the latent space can reduce the influence of confounding factors that potential attackers might manipulate, as shown in Fig. 10. Zhang et al. put forward a self-denoising methodology aimed at mitigating the impact of subtle modifications in the input prompt for sentiment analysis [219]. Many defensive strategies frequently include the concept of imperceptibility within their framework of potential threats. This can be achieved through various means, such as limiting the use of synonymous phrases and making slight alterations to the input text. This renders them unsuitable for countering the attacks conducted by Zou et al. that include substantial modifications to the prompts [177]. Furthermore, these approaches are specifically tailored for jobs involving classification and do not take advantage of the unique characteristics of LLM safety attacks.

在计算机视觉领域，关于提供可验证抗扰能力的防御措施已进行了大量研究。该领域采用了多种技术，包括区间界传播(interval-bound propagation)[107, 207-209]、曲率界(curvature bounds)[210-212]和随机平滑(randomized smoothing)[213-216]。在自然语言处理(NLP)应用中，也对认证防御措施进行了研究。叶等人提出了一种利用预定义同义词集(synonyms)缓解文本分类中词语替换的方法[217]。赵等人采用语义平滑(semantic smoothing)作为缓解自然语言威胁的手段[218]。如图10所示，在潜在空间中引入噪声可以减少潜在攻击者可能操控的混杂因素的影响。张等人提出了一种自我去噪(self-denoising)方法，旨在缓解情感分析(sentiment analysis)中输入提示(prompt)微妙修改的影响[219]。许多防御策略在其框架中常包含“不可察觉性”(imperceptibility)的概念，这可以通过限制同义短语的使用或对输入文本进行微调实现。这使得它们无法应对 Zou等人[177]所进行的包含大幅修改的提示攻击。此外，这些方法主要针对分类任务，未能充分利用大规模语言模型(LLM)安全攻击的独特特性。

### 5.5 Fine-tuning LLMs

### 5.5 微调大规模语言模型(LLMs)

Enhancing transformer-based language models to discern between input texts produced by LLMs and those originating elsewhere constitutes the central focus of these methodologies. The utilization of paired samples is imperative to facilitate supervised training procedures. Prior research endeavors [220-223] have extensively explored the efficacy of fine-tuned language models in distinguishing text generated by language model models. Notably, research conducted in 2019 acknowledged the efficacy of refined language models (LMs), with Roberta [224] standing out as a particularly notable instance, in identifying text generated by LLMs. The fine-tuning process of Roberta serves as a robust groundwork for the identification and detection of text produced by LLMs. In their examination, Fagni et al. [225] observed that fine-tuning Roberta yielded optimal classification outcomes across various encoding configurations [226]. This observation was further corroborated by the subsequent adoption of a Roberta fine-tuning approach by the OpenAI detector [183]. Numerous recent studies [227- 230] have provided supplementary evidence endorsing the heightened effectiveness of fine-tuned variants within the "BERT" lineage, particularly "RoBERTa", in detecting text generated by LLMs. On average, these fine-tuned models attained a 95% accuracy rate within their specific domains. They exhibited superior performance compared to zero-shot and watermarking methodologies, and also demonstrated a certain degree of resilience against various attack strategies within their specific domains. Nonetheless, akin to their counterparts, methods involving fine-tuning encoders manifest a lack of robustness [220], as they tend to excessively fit the provided training data or the training distribution associated with the source model. Consequently, their performance diminishes when confronted with data from dissimilar domains or unseen data. The limited availability of data has prompted the adoption of contrastive learning [231-233] in LM-based classifiers, with self-supervised learning constituting the foundational principle of this methodology. This approach endeavors to minimize the spatial disparity between anchor and positive samples, while concurrently maximizing the spatial disparity between the anchor and negative samples through spatial transformations. Liu et al. [234] proposed an enhanced contrastive loss function that assigns greater weights to challenging negative data, with the objective of optimizing model efficacy and enhancing performance under resource constraints. The methodology employed in this examination comprehensively accounts for linguistic characteristics and sentence structures, leveraging a coherence graph to capture the inherent consistency of textual elements. The efficacy of LM-based detectors can be bolstered by incorporating factual information structures, as evidenced by research findings and reaffirmed by Zhong et al. [235]. Bhattacharjee et al. [236] introduced the ConDA framework, which integrates traditional domain adaptation techniques with the representational capabilities of contrastive learning. This amalgamation yields substantial improvements in the model's capacity to withstand unfamiliar models.

这些方法的核心在于提升基于变换器(transformer)的语言模型(Language Models, LMs)区分由大规模语言模型生成的文本与其他来源文本的能力。使用配对样本对于实现监督训练至关重要。此前的研究[220-223]广泛探讨了微调语言模型在识别由语言模型生成文本方面的有效性。值得注意的是，2019年的研究确认了经过优化的语言模型(如Roberta[224])在识别由大规模语言模型生成的文本方面表现出色。Roberta的微调过程为识别和检测由大规模语言模型生成的文本提供了坚实的基础。在他们的研究中，法尼(Fagni)等[225]发现，微调Roberta在各种编码配置(encoding configurations)下都能获得最佳分类效果[226]。这一结论也得到了OpenAI检测器[183]采用Roberta微调方法的验证。许多最新研究[227-230]提供了额外证据，支持“BERT”系列(特别是“RoBERTa”)的微调变体在检测由大规模语言模型生成文本方面的优越性。这些微调模型平均在其特定领域达到了95%的准确率，表现优于零样本(zero-shot)和水印(watermarking)方法，并在其特定领域内对各种攻击策略表现出一定的抗干扰能力。然而，与其他方法类似，微调编码器的方法也存在鲁棒性不足的问题[220]，因为它们倾向于过度拟合训练数据或源模型的训练分布。因此，在面对不同领域或未见过的数据时，其性能会下降。数据有限促使在基于语言模型的分类器中采用对比学习(contrastive learning)[231-233]，其核心是自监督学习(self-supervised learning)。该方法旨在最小化锚点(anchor)与正样本(positive samples)之间的空间差异，同时通过空间变换最大化锚点与负样本(negative samples)之间的差异。刘等[234]提出了一种增强的对比损失函数，为难的负样本赋予更大权重，以优化模型性能并在资源受限的情况下提升效果。该方法充分考虑了语言特性和句子结构，利用一致性图(coherence graph)捕捉文本元素的内在一致性。通过引入事实信息结构，可以增强基于语言模型的检测器的效果，相关研究已验证这一点，且由钟等[235]再次确认。巴塔查尔吉(Bhattacharjee)等[236]提出了ConDA框架，将传统的领域适应(domain adaptation)技术与对比学习的表现能力相结合，显著提升了模型抵抗陌生模型的能力。

![bo_d1m00jf7aajc73dif19g_16_901_153_704_759_0.jpg](images/bo_d1m00jf7aajc73dif19g_16_901_153_704_759_0.jpg)

Fig. 10 Overview of the proposed architecture in [218]

图10 [218]中所提架构的概述

## 6 Challenges & future directions

## 6 挑战与未来方向

The topic of adversarial attack and defense remains a substantial challenge. This section specifically discusses the present hurdles and constraints within the domain of producing and safeguarding against adversarial attacks in LLMs.

对抗性攻击与防御的课题仍然是一个重大挑战。本节特别讨论在生成和防护对抗性攻击(adversarial attacks)方面目前面临的障碍和限制。

### 6.1 Assessment of offensive or defensive performance

### 6.1 进攻或防御性能评估

The majority of recent studies evaluate attack performance using metrics such as attack success rate or accuracy [237]. However, there is a scarcity of studies considering the scale and efficiency of attacks. Moreover, these studies predominantly focus on the time cost of attacks. The potential relationships between dataset size, attack duration, and attack effectiveness remain inadequately explored [9]. Investigating these potential relationships requires further examination of how to effectively balance these three aspects, which is expected to be a significant area of interest for future research [238]. Similarly, assessing defense performance faces a comparable challenge. Analogous to the situation in text and image processing, there is currently a lack of benchmarks for evaluating adversarial attacks and defenses on LLMs [239]. Consequently, the absence of universally accepted assessment criteria presents a challenge in evaluating the effectiveness of relevant scholarly contributions.

近年来大多数研究采用攻击成功率或准确率等指标评估攻击性能[237]。然而，关于攻击规模和效率的研究较少。此外，这些研究主要关注攻击的时间成本。数据集规模、攻击持续时间与攻击效果之间的潜在关系尚未充分探索[9]。研究这些潜在关系需要进一步考察如何有效平衡这三者，这预计将成为未来研究的重要方向[238]。类似地，评估防御性能也面临类似的挑战。与文本和图像处理中的情况类似，目前缺乏用于评估大规模语言模型(LLMs)对抗性攻击与防御的基准[239]。因此，缺乏普遍认可的评估标准，给相关学术贡献的效果评估带来了困难。

### 6.2 Defense and attack transferability

### 6.2 防御与攻击的迁移性

Adversarial examples within NLP display various aspects and extensions of transferability, akin to advancements in computer vision [240]. It is typical to observe transfers among diverse models and between training and testing datasets. Recent studies have focused on developing attacks transferable across various ML tasks [241]. Transferability denotes the capability of an attacker to exploit a ML model for malicious purposes without requiring the same architecture, data, model, or task for which the ML model was designed [74]. This phenomenon resembles a newly emerging challenge that poses a threat to the efficacy of defense strategies [242]. Black-box and untargeted adversarial attacks demonstrate higher levels of transferability compared to "white-box" and/or "targeted attacks", as anticipated [50]. Given the absence of content in the user's input, there is a heightened necessity for the development of sophisticated defense strategies capable of effectively addressing this challenge. Transferability can be evaluated across different granularities, encompassing word, character, and sentence levels [51].

自然语言处理(NLP)中的对抗样本展现出迁移性(transferability)的多方面特性，类似于计算机视觉(computer vision)中的进展[240]。常见的现象包括在不同模型之间以及训练集与测试集之间的迁移。近期研究集中在开发可在多种机器学习(ML)任务中迁移的攻击方法[241]。迁移性指攻击者无需使用相同的模型架构、数据、模型或任务，即能利用某一ML模型进行恶意操作的能力[74]。这一现象类似于一种新兴的挑战，威胁到防御策略的有效性[242]。黑盒(black-box)和非目标(untargeted)对抗攻击的迁移性高于“白盒(white-box)”和/或“目标性(targeted)”攻击，正如预期[50]。鉴于用户输入内容的缺失，亟需开发能够有效应对这一挑战的复杂防御策略。迁移性可以在不同粒度层面进行评估，包括词、字符和句子层面[51]。

### 6.3 High computational requirements

### 6.3 高计算需求

The majority of methods outlined in the literature necessitate substantial computational resources, often exceeding those required for the model's natural training process [243]. One potential avenue involves exploring new training methodologies that require fewer computational resources and expedite training. For instance, Shafahi et al. [244] propose free adversarial training, which optimizes stochastic gradient descent (SGD) [245] passes to compute the model's gradient with respect to network parameters during the backward pass, along with the derivative of the loss function with respect to the input. This approach demonstrates improved computational efficiency compared to the initial training model [246], while maintaining similar accuracy levels. Zhang et al. [243] introduce a novel training approach that minimizes the number of iterations needed to generate an adversarial example to one. However, despite advancements in reducing runtime, it remains significantly slower than conventional training [247]. Several studies suggest that employing the FGSM [16] with random initialization is effective in mitigating projected gradient descent (PGD) [248] attacks. This approach not only provides adequate defense against PGD attacks but also reduces computational requirements. Its effectiveness can be further enhanced by integrating it with various training techniques, such as mixed-precision arithmetic [249] and cyclic learning rate [250], as demonstrated in [251].

文献中大多数方法需要大量计算资源，常常超过模型的自然训练过程所需[243]。一种潜在途径是探索新的训练方法，减少计算资源的消耗并加快训练速度。例如，Shafahi等人[244]提出了免费对抗训练(free adversarial training)，该方法在反向传播过程中优化随机梯度下降(SGD)[245]，计算模型参数的梯度以及损失函数对输入的导数。这种方法在保持相似准确率的同时，提高了计算效率[246]。Zhang等人[243]提出了一种新颖的训练方法，将生成对抗样本所需的迭代次数降至1次。然而，尽管在缩短运行时间方面取得了进展，但仍明显比传统训练慢[247]。一些研究表明，结合随机初始化的FGSM(快速梯度符号法)[16]，可以有效缓解投影梯度下降(PGD)[248]攻击。这种方法不仅能提供充分的防御，还能降低计算需求。其效果可以通过结合多种训练技术进一步增强，例如混合精度运算[249]和循环学习率[250]，如[251]所示。

### 6.4 Embedding space size & perturbation

### 6.4 嵌入空间大小与扰动

Numerous studies have proposed various methodologies for delineating a suitable embedding space $\left\lbrack  {9,{252}}\right\rbrack$ . Furthermore, a diverse array of strategies exists for investigating and identifying the optimal substitution within this space [253]. However, additional examination is necessary to establish a comprehensive framework for defining the space and optimizing the search process to ascertain the most suitable replacement [33]. Moreover, it is imperative to account for the tradeoff between the size of the embedding space and the computational burden associated with the search process. Additionally, innovative concepts are required for regularizing and guiding the search process within the embedding space or hyperspace. Several examinations have explored determining the most crucial characters and words for modification relative to others [9]. Nonetheless, further inquiry is evidently needed to fully probe this concept. In this specific context, it is conceivable to envisage formulating a comprehensive framework to address a broader inquiry concerning the optimal approach to modifying elements such as characters, sub-words, or sub-sentences [254]. This presents an opportunity to explore novel optimization configurations capable of systematically and feasibly addressing these inquiries.

许多研究提出了多种方法来界定合适的嵌入空间(embedding space)$\left\lbrack  {9,{252}}\right\rbrack$。此外，存在多样的策略用于研究和识别该空间中的最优替代方案[253]。然而，还需进一步研究以建立一个全面的框架，用于定义空间和优化搜索过程，以确定最合适的替换[33]。此外，还必须考虑嵌入空间的大小与搜索过程的计算负担之间的权衡。同时，需要创新的概念来正则化和引导在嵌入空间或超空间中的搜索过程。一些研究已探索确定相对于其他字符和词语最关键的修改对象[9]。然而，显然还需要更多的研究来深入探讨这一概念。在此背景下，可以设想制定一个全面的框架，以应对关于如何最优地修改字符、子词或子句等元素的更广泛问题[254]。这为探索新颖的优化方案提供了机会，能够系统性且可行地解决这些问题。

### 6.5 Reliance on human factors

### 6.5 对人类因素的依赖

According to the literature review, human intervention is essential for the design, as well as the optimization of variance adversarial attack paradigms and corresponding defense methodologies [255]. This phenomenon gains particular significance when evaluating the extent of imperceptibility displayed by adversarial substitutions from a linguistic standpoint [256]. Further considerations related to human factors involve deliberations concerning the specification of attack parameters within the model and the subsequent optimization of these parameters. Thus, there is scholarly interest in exploring the feasibility of automating these processes to minimize, or at least regulate, the extent of human intervention necessary in this domain [257]. This presents a significant research challenge within the domain of ML, encompassing the broader context.

根据文献综述，人工干预对于设计以及方差对抗攻击范式和相应防御方法的优化至关重要[255]。从语言学角度评估对抗替换的不可感知程度时，这一现象尤为重要[256]。与人类因素相关的进一步考虑包括关于攻击参数在模型中的设定以及这些参数的后续优化的讨论。因此，学术界对探索自动化这些过程的可行性表现出兴趣，以尽量减少或至少调节在该领域所需的人类干预程度[257]。这在机器学习(ML)领域内提出了重大研究挑战，具有更广泛的背景。

### 6.6 Discrete data perturbation

### 6.6 离散数据扰动

Generating adversarial examples in text presents a fundamental challenge compared to images. There is a prevalent belief that applying computer vision and image processing techniques to generate adversarial examples does not directly extend to discrete inputs [258]. Essentially, using such a straightforward approach leads to the detection of the attack, as the significance of characters and words diminishes due to the discrete nature of perturbations [259]. Furthermore, it should be noted that text perturbations primarily involve replacement operations. This raises a significant research question regarding the characterization of effective replacements. Therefore, a current focus of recent works involves identifying and measuring novel elements of textual similarity [48]. Similarly, implementing continuous input defense techniques poses challenges. For example, the Generative Adversarial Network (GAN) methodology relies on incorporating synthetic noise into the input data, rendering it inapplicable within the context of NLP [260]. One intriguing area of research involves adapting existing off-the-shelf methods for generating and defending against adversarial attacks on continuous variables for application in a textual context [261].

在文本中生成对抗样本相较于图像面临根本性挑战。普遍认为，将计算机视觉和图像处理技术应用于生成对抗样本并不能直接扩展到离散输入[258]。本质上，采用如此简单的方法会导致攻击被检测到，因为扰动的离散性质削弱了字符和词语的重要性[259]。此外，应注意文本扰动主要涉及替换操作。这引发了关于有效替换的特征描述的重大研究问题。因此，近期研究的重点之一是识别和衡量文本相似性的创新元素[48]。类似地，实施连续输入的防御技术也面临挑战。例如，生成对抗网络(GAN)方法依赖于在输入数据中引入合成噪声，使其在自然语言处理(NLP)中不适用[260]。一个引人关注的研究领域是将现有的现成方法适应于生成和防御连续变量的对抗攻击，以应用于文本环境中[261]。

## 7 Conclusion

## 7 结论

This study aims to provide a comprehensive analysis of the security threats and areas of vulnerability within the LLM framework. Its goal is to augment the comprehension and awareness of stakeholders in academia and industry concerning LLM security. Additionally, it endeavors to enhance their ability to discern the fundamental mechanisms behind these potential threats.

本研究旨在对大规模语言模型(LLM)框架中的安全威胁和脆弱性区域进行全面分析。其目标是增强学术界和产业界相关利益相关者对LLM安全的理解和认知。此外，还旨在提升他们识别这些潜在威胁背后基本机制的能力。

Acknowledgements Not applicable

致谢 不适用

Author Contributions Pranjal Kumar conceived the idea and drafted the manuscript.

作者贡献 Pranjal Kumar 构思了该想法并起草了手稿。

Data Availability No datasets were generated or analysed during the current study.

数据可用性 当前研究未生成或分析任何数据集。

## Declarations

## 声明

Conflict of interest On behalf of all authors, the corresponding author states that there is no Conflict of interest.

利益冲突 代表所有作者，通讯作者声明不存在利益冲突。

Consent for publication Yes.

出版同意 是。

## References

## 参考文献

1. Sutskever I, Vinyals O, Le QV (2014) Sequence to sequence learning with neural networks. Adv Neural Inf Process Syst 27:3104-3112

1. Sutskever I, Vinyals O, Le QV (2014) 使用神经网络的序列到序列学习。Adv Neural Inf Process Syst 27:3104-3112

2. Saon G, Kurata G, Sercu T, Audhkhasi K, Thomas S, Dimitriadis D, Cui X, Ramabhadran B, Picheny M, Lim LL, Roomi B (2017) English conversational telephone speech recognition by humans and machines. In Proceedings of the Interspeech 2017, pp 132- 136

2. Saon G, Kurata G, Sercu T, Audhkhasi K, Thomas S, Dimitriadis D, Cui X, Ramabhadran B, Picheny M, Lim LL, Roomi B (2017) 人类与机器的英语会话电话语音识别。在Interspeech 2017会议论文集，第132-136页

3. Khatiri S, Di Sorbo A, Zampetti F, Visaggio CA, Di Penta M, Panichella S (2024) Identifying safety-critical concerns in unmanned aerial vehicle software platforms with salient. Soft-wareX 27:101748

3. Khatiri S, Di Sorbo A, Zampetti F, Visaggio CA, Di Penta M, Panichella S (2024) 利用显著性(salient)识别无人机软件平台中的安全关键问题。SoftwareX 27:101748

4. Parkhi O, Vedaldi A, Zisserman A (2015) Deep face recognition. In: BMVC 2015-proceedings of the British machine vision conference 2015. British Machine Vision Association

4. Parkhi O, Vedaldi A, Zisserman A (2015) 深度人脸识别。收录于:BMVC 2015——英国机器视觉会议论文集。英国机器视觉协会

5. Chen C, Seff A, Kornhauser A, Xiao J (2015) Deepdriving: learning affordance for direct perception in autonomous driving. In: Proceedings of the IEEE international conference on computer vision, pp 2722-2730

5. 陈C, Seff A, Kornhauser A, Xiao J (2015) Deepdriving:学习自主驾驶中的直接感知能力。发表于:IEEE国际计算机视觉会议论文集，第2722-2730页

6. Ma X, Fang G, Wang X (2023) LLM-pruner: on the structural pruning of large language models. Adv Neural Inf Process Syst 36:21702-21720

6. 马X, 方G, 王X (2023) LLM-pruner:关于大型语言模型的结构剪枝。神经信息处理系统进展36:21702-21720

7. Szegedy C, Zaremba W, Sutskever I, Bruna J, Erhan D, Goodfel-low I, Fergus R (2014) Intriguing properties of neural networks. In: Bengio Y, LeCun Y (eds) 2nd international conference on learning representations, ICLR 2014, Banff, AB, Canada, April 14-16, 2014, conference track proceedings

7. Szegedy C, Zaremba W, Sutskever I, Bruna J, Erhan D, Goodfellow I, Fergus R (2014) 神经网络的引人入胜的特性。收录于:Bengio Y, LeCun Y(编)第二届学习表示国际会议(ICLR 2014)，加拿大班夫，4月14-16日，会议论文集

8. Alotaibi A, Rassam MA (2023) Adversarial machine learning attacks against intrusion detection systems: a survey on strategies and defense. Future Internet 15(2):62

8. Alotaibi A, Rassam MA (2023) 针对入侵检测系统的对抗性机器学习攻击:策略与防御综述。未来互联网15(2):62

9. Raiaan MA, Mukta MS, Fatema K, Fahad NM, Sakib S, Mim MM, Ahmad J, Ali ME, Azam S (2024) A review on large language models: architectures, applications, taxonomies, open issues and challenges. IEEE Access. https://doi.org/10.1109/ ACCESS.2024.3365742

9. Raiaan MA, Mukta MS, Fatema K, Fahad NM, Sakib S, Mim MM, Ahmad J, Ali ME, Azam S (2024) 大型语言模型综述:架构、应用、分类、未解问题与挑战。IEEE Access. https://doi.org/10.1109/ACCESS.2024.3365742

10. Boffa M, Drago I, Mellia M, Vassio L, Giordano D, Valentim R, Houidi ZB (2024) Logprécis: unleashing language models for automated malicious log analysis: Précis: a concise summary of essential points, statements, or facts. Comput Secur 141:103805

10. Boffa M, Drago I, Mellia M, Vassio L, Giordano D, Valentim R, Houidi ZB (2024) Logprécis:释放语言模型用于自动化恶意日志分析:Précis:关键点、陈述或事实的简明总结。计算机安全 141:103805

11. Alwahedi F, Aldhaheri A, Ferrag MA, Battah A, Tihanyi N (2024) Machine learning techniques for IoT security: current research and future vision with generative AI and large language models. Internet Things Cyber Phys Syst. https://doi.org/10.1016/j.iotcps.2023.12.003

11. Alwahedi F, Aldhaheri A, Ferrag MA, Battah A, Tihanyi N (2024) 物联网安全的机器学习技术:当前研究与未来展望，结合生成式AI和大型语言模型。互联网物联网与网络物理系统。https://doi.org/10.1016/j.iotcps.2023.12.003

12. Li Z, Fan S, Gu Y, Li X, Duan Z, Dong B, Liu N, Wang J (2024) Flexkbqa: a flexible LLM-powered framework for few-shot knowledge base question answering. In: Proceedings of the AAAI conference on artificial intelligence 38:18608-18616

12. Li Z, Fan S, Gu Y, Li X, Duan Z, Dong B, Liu N, Wang J (2024) Flexkbqa:一种基于LLM的灵活少样本知识库问答框架。收录于:AAAI人工智能会议论文集第38卷:18608-18616

13. Livne M, Miftahutdinov Z, Tutubalina E, Kuznetsov M, Polykovskiy D, Brundyn A, Jhunjhunwala A, Costa A, Aliper A, Aspuru-Guzik A et al (2024) nach0: multimodal natural and chemical languages foundation model. Chem Sci. https://doi.org/ 10.1039/D4SC00966E

13. Livne M, Miftahutdinov Z, Tutubalina E, Kuznetsov M, Polykovskiy D, Brundyn A, Jhunjhunwala A, Costa A, Aliper A, Aspuru-Guzik A 等 (2024) nach0:多模态自然语言与化学语言基础模型。化学科学。https://doi.org/10.1039/D4SC00966E

14. Abe N, Zadrozny B, Langford J (2004) An iterative method for multi-class cost-sensitive learning. In: Proceedings of the tenth ACM SIGKDD international conference on Knowledge discovery and data mining, pp 3-11

14. Abe N, Zadrozny B, Langford J (2004) 一种多类代价敏感学习的迭代方法。收录于:第十届ACM SIGKDD国际知识发现与数据挖掘会议论文集，第3-11页

15. Yuan X, He P, Zhu Q, Li X (2019) Adversarial examples: attacks and defenses for deep learning. IEEE Trans Neural Netw Learn Syst 30(9):2805-2824

15. Yuan X, He P, Zhu Q, Li X (2019) 对抗样本:深度学习的攻击与防御。IEEE神经网络与学习系统杂志30(9):2805-2824

16. Wu C, Fang W, Dai F, Yin H (2023) A model ensemble approach with LLM for Chinese text classification. In: China health information processing conference. Springer, pp 214-230

16. Wu C, Fang W, Dai F, Yin H (2023) 使用LLM的模型集成方法进行中文文本分类。中国健康信息处理会议。Springer，214-230页

17. Nazir A, Chakravarthy TK, Cecchini DA, Khajuria R, Sharma P, Mirik AT, Kocaman V, Talby D (2024) LangTest: a comprehensive evaluation library for custom LLM and NLP models. Softw Impacts 19:100619

17. Nazir A, Chakravarthy TK, Cecchini DA, Khajuria R, Sharma P, Mirik AT, Kocaman V, Talby D (2024) LangTest:一个用于定制LLM和NLP模型的全面评估库。软件影响19:100619

18. Sang EF, De Meulder F (2003) Introduction to the CoNLL-2003 shared task: Language-independent named entity recognition. In Proceedings of the seventh conference on natural language learning at HLT-NAACL 2003, pp 142-147

18. Sang EF, De Meulder F (2003) 介绍CoNLL-2003共享任务:语言无关的命名实体识别。在:HLT-NAACL 2003第七届自然语言学习会议论文集，第142-147页

19. Rajpurkar P, Zhang J, Lopyrev K, Liang P (2016) SQuAD: 100,000 + questions for machine comprehension of text. In: Su J, Duh K, Carreras X (eds) Proceedings of the 2016 conference on empirical methods in natural language processing, Austin, Texas, November 2016. Association for Computational Linguistics, pp 2383-2392

19. Rajpurkar P, Zhang J, Lopyrev K, Liang P (2016) SQuAD:超过10万个问题用于机器理解文本。在:Su J, Duh K, Carreras X(编)2016年自然语言处理经验方法会议论文集，德克萨斯州奥斯汀，2016年11月。计算语言学协会，2383-2392页

20. Wang A, Singh A, Michael J, Hill F, Levy O, Bowman SR (2018) GLUE: a multi-task benchmark and analysis platform for natural language understanding. In: Linzen T, Chrupata G, Alishahi, A (eds) Proceedings of the 2018 EMNLP workshop BlackboxNLP: analyzing and interpreting neural networks for NLP, Brussels, Belgium, November 2018. Association for Computational Linguistics, pp 353-355

20. Wang A, Singh A, Michael J, Hill F, Levy O, Bowman SR (2018) GLUE:多任务基准测试与自然语言理解分析平台。在:Linzen T, Chrupata G, Alishahi, A(编)2018年EMNLP研讨会黑箱NLP:分析与解释神经网络在自然语言处理中的应用，布鲁塞尔，比利时，2018年11月。计算语言学协会，第353-355页

21. Wei C, Xie SM, Ma T (2021) Why do pretrained language models help in downstream tasks? An analysis of head and prompt tuning. Adv Neural Inf Process Syst 34:16158-16170

21. Wei C, Xie SM, Ma T (2021) 为什么预训练语言模型在下游任务中有帮助？对头部和提示调优的分析。Adv Neural Inf Process Syst 34:16158-16170

22. Radford A, Narasimhan K, Salimans T, Sutskever I (2018) Improving language understanding by generative pre-training

22. Radford A, Narasimhan K, Salimans T, Sutskever I (2018) 通过生成式预训练提升语言理解能力

23. Devlin J, Chang MW, Lee K, Toutanova K (2019) BERT: pretraining of deep bidirectional transformers for language understanding. In: Burstein J, Doran C, Solorio T (eds) Proceedings of the 2019 conference of the North American chapter of the association for computational linguistics: human language technologies, volume 1 (long and short papers), Minneapolis, Minnesota, June 2019. Association for Computational Linguistics, pp 4171-4186

23. Devlin J, Chang MW, Lee K, Toutanova K (2019) BERT:用于语言理解的深度双向变换器预训练。在:Burstein J, Doran C, Solorio T(编)2019年北美计算语言学协会会议论文集:人类语言技术，第1卷(长篇与短篇论文)，明尼阿波利斯，明尼苏达州，2019年6月。计算语言学协会，第4171-4186页

24. Akbik A, Bergmann T, Blythe D, Rasul K, Schweter S, Vollgraf R (2019) FLAIR: an easy-to-use framework for state-of-the-art NLP. In: Proceedings of the 2019 conference of the North American chapter of the association for computational linguistics (demonstrations), pp 54-59

24. Akbik A, Bergmann T, Blythe D, Rasul K, Schweter S, Vollgraf R (2019) FLAIR:一种易用的最先进自然语言处理框架。在:2019年北美计算语言学协会会议(演示)论文集，第54-59页

25. Chen K, Meng Y, Sun X, Guo S, Zhang T, Li J, Fan C (2022) Bad-pre: task-agnostic backdoor attacks to pre-trained NLP foundation models. In: International conference on learning representations

25. Chen K, Meng Y, Sun X, Guo S, Zhang T, Li J, Fan C (2022) Bad-pre:针对预训练NLP基础模型的任务无关后门攻击。在:国际学习表示会议

26. Feldman V, Zhang C (2020) What neural networks memorize and why: discovering the long tail via influence estimation. Adv Neural Inf Process Syst 33:2881-2891

26. Feldman V, Zhang C (2020) 神经网络记忆了什么以及为什么:通过影响估计发现长尾分布。Adv Neural Inf Process Syst 33:2881-2891

27. Krishna K, Tomar GS, Parikh AP, Papernot N, Iyyer M (2020) Thieves on sesame street! model extraction of BERT-based APIs. In: International conference on learning representations

27. Krishna K, Tomar GS, Parikh AP, Papernot N, Iyyer M (2020) sesame街上的窃贼！基于BERT的API模型提取。在:国际学习表示会议

28. Wang B (2023) Towards trustworthy large language models. PhD thesis, University of Illinois at Urbana-Champaign

28. Wang B (2023) 迈向可信赖的大型语言模型。伊利诺伊大学厄巴纳-香槟分校博士论文

29. Li L, Ma R, Guo Q, Xue X, Qiu X (2020) BERT-ATTACK: adversarial attack against BERT using BERT. In: Webber B, Cohn T, He Y, Liu Y (eds) Proceedings of the 2020 conference on empirical methods in natural language processing (EMNLP), Online, November 2020. Association for Computational Linguistics, pp 6193-6202

29. Li L, Ma R, Guo Q, Xue X, Qiu X (2020) BERT-ATTACK:利用BERT对BERT进行对抗性攻击。在:Webber B, Cohn T, He Y, Liu Y(编)2020年自然语言处理实证方法会议论文集(EMNLP)，线上，2020年11月。计算语言学协会，第6193-6202页

30. Yuan L, Zheng X, Zhou Y, Hsieh CJ, Chang KW (2021) On the transferability of adversarial attacks against neural text classifier. In: Moens MF, Huang X, Specia L, Yih SWT (eds) Proceedings of the 2021 conference on empirical methods in natural language processing, Online and Punta Cana, Dominican Republic, November 2021. Association for Computational Linguistics, pp 1612-1625

30. Yuan L, Zheng X, Zhou Y, Hsieh CJ, Chang KW (2021) 关于对神经文本分类器的对抗性攻击的可转移性。在:Moens MF, Huang X, Specia L, Yih SWT(编)2021年自然语言处理实证方法会议论文集，线上和多米尼加共和国蓬塔卡纳，2021年11月。计算语言学协会，第1612-1625页

31. Shen L, Ji S, Zhang X, Li J, Chen J, Shi J, Fang C, Yin J, Wang T (2021) Backdoor pre-trained models can transfer to all. In: Proceedings of the 2021 ACM SIGSAC conference on computer and communications security, CCS '21, New York, NY, USA, 2021. Association for Computing Machinery, pp 3141-3158

31. Shen L, Ji S, Zhang X, Li J, Chen J, Shi J, Fang C, Yin J, Wang T (2021) 后门预训练模型可以迁移到所有模型。在:2021年ACM SIGSAC计算机与通信安全会议论文集，CCS '21，纽约，美国，2021年。计算机机械协会，第3141-3158页

32. Rane NL, Tawde A, Choudhary SP, Rane J (2023) Contribution and performance of ChatGPT and other large language models (LLM) for scientific and research advancements: a double-edged sword. Int Res J Mod Eng Technol Sci 5(10):875-899

32. Rane NL, Tawde A, Choudhary SP, Rane J (2023) ChatGPT及其他大型语言模型(LLM)在科学研究与技术进步中的贡献与表现:一把双刃剑。国际现代工程技术科学研究杂志，第5卷第10期:875-899

33. Yao Y, Duan J, Xu K, Cai Y, Sun Z, Zhang Y (2024) A survey on large language model (LLM) security and privacy: the good, the bad, and the ugly. High Confid Comput 4:100211

33. Yao Y, Duan J, Xu K, Cai Y, Sun Z, Zhang Y (2024) 大型语言模型(LLM)安全与隐私的综述:优点、缺点与挑战。高可信计算，第4期:100211

34. Gupta M, Akiri C, Aryal K, Parker E, Praharaj L (2023) From ChatGPT to ThreatGPT: impact of generative AI in cybersecu-rity and privacy. IEEE Access. https://doi.org/10.1109/ACCESS.2023.3300381

34. Gupta M, Akiri C, Aryal K, Parker E, Praharaj L (2023) 从ChatGPT到ThreatGPT:生成式人工智能在网络安全与隐私中的影响。IEEE Access。https://doi.org/10.1109/ACCESS.2023.3300381

35. Yang J, Jin H, Tang R, Han X, Feng Q, Jiang H, Zhong S, Yin B, Hu X (2024) Harnessing the power of LLMs in practice: a survey on ChatGPT and beyond. ACM Trans Knowl Discov Data 18(6):1-32

35. 杨杰，金浩，唐锐，韩欣，冯强，江浩，钟思，尹彬，胡晓(2024)在实践中利用大型语言模型(LLMs)的力量:ChatGPT及其未来的调研。ACM知识发现与数据传输杂志 18(6):1-32

36. Jia R, Liang P (2017) Adversarial examples for evaluating reading comprehension systems. In: Palmer M, Hwa R, Riedel S (eds) roceedings of the 2017 conference on empirical methods in natural language processing, Copenhagen, Denmark, September 2017. Association for Computational Linguistics, pp 2021-2031

36. 贾然，梁鹏(2017)用于评估阅读理解系统的对抗样本。在:Palmer M，Hwa R，Riedel S(编辑)2017年自然语言处理中的经验方法会议论文集，丹麦哥本哈根，2017年9月。计算语言学协会，第2021-2031页

37. Omar M, Choi S, Nyang D, Mohaisen D (2022) Robust natural language processing: recent advances, challenges, and future directions. IEEE Access 10:86038-86056

37. 奥马尔 M，崔 S，尼扬 D，莫海森 D(2022)鲁棒自然语言处理:最新进展、挑战与未来方向。IEEE Access 10:86038-86056

38. Akhtar N, Mian A (2018) Threat of adversarial attacks on deep learning in computer vision: a survey. IEEE Access 6:14410- 14430

38. 阿赫塔尔 N，米安 A(2018)深度学习在计算机视觉中的对抗攻击威胁:综述。IEEE Access 6:14410-14430

39. Wang W, Chen Z, Chen X, Wu J, Zhu X, Zeng G, Luo P, Lu T, Zhou J, Qiao Y et al (2024) Visionllm: large language model is also an open-ended decoder for vision-centric tasks. Adv Neural Inf Process Syst 36:61501-61513

39. 王伟，陈志，陈欣，吴杰，朱晓，曾刚，罗鹏，卢涛，周建，乔颖等(2024)VisionLLM:大型语言模型也是面向视觉任务的开放式解码器。先进神经信息处理系统 36:61501-61513

40. Hu S, Shang X, Qin Z, Li M, Wang Q, Wang C (2019) Adversarial examples for automatic speech recognition: attacks and countermeasures. IEEE Commun Mag 57(10):120-126

40. 胡思，尚翔，秦志，李明，王强，王策(2019)自动语音识别的对抗样本:攻击与对策。IEEE通信杂志 57(10):120-126

41. Wang W, Wang R, Wang L, Wang Z, Ye A (2023) Towards a robust deep neural network against adversarial texts: a survey. IEEE Trans Knowl Data Eng 35(3):3159-3179

41. 王伟，王然，王磊，王志，叶安(2023)面向对抗文本的鲁棒深度神经网络:综述。IEEE知识与数据工程学报 35(3):3159-3179

42. Das RK, Tian X, Kinnunen T, Li H (2020) The attacker's perspective on automatic speaker verification: an overview. In Proceedings of the Interspeech 2020, pp 4213-4217

42. Das RK，Tian X，Kinnunen T，Li H(2020)攻击者视角下的自动说话人验证:概述。在:2020年国际语音会议论文集，pp 4213-4217

43. Abdullah H, Warren K, Bindschaedler V, Papernot N, Traynor P (2021) SoK: the faults in our ASRs: an overview of attacks against automatic speech recognition and speaker identification systems. In: 2021 IEEE symposium on security and privacy (SP). IEEE, pp 730-747

43. 阿卜杜拉 H，沃伦 K，宾查德勒 V，帕珀诺特 N，特雷纳 P(2021)系统性综述:我们语音识别系统中的缺陷:针对自动语音识别和说话人识别系统的攻击概述。在:2021年IEEE安全与隐私研讨会(SP)。IEEE，第730-747页

44. Chen X, Li S, Huang H (2021) Adversarial attack and defense on deep neural network-based voice processing systems: an overview. Appl Sci 11(18):8450

44. 陈欣，李思，黄浩(2021)基于深度神经网络的语音处理系统的对抗攻击与防御:综述。应用科学 11(18):8450

45. Zhang WE, Sheng QZ, Alhazmi A, Li C (2020) Adversarial attacks on deep-learning models in natural language processing: a survey. ACM Trans Intell Syst Technol TIST 11(3):1-41

45. 张伟，盛强，阿尔哈兹米，李聪(2020)自然语言处理中的深度学习模型对抗攻击:综述。ACM智能系统技术杂志 TIST 11(3):1-41

46. Xu H, Ma Y, Liu HC, Deb D, Liu H, Tang JL, Jain AK (2020) Adversarial attacks and defenses in images, graphs and text: a review. Int J Autom Comput 17:151-178

46. 许浩，马勇，刘宏超，Deb D，刘宏，唐俊良，Jain AK(2020)图像、图表和文本中的对抗攻击与防御:综述。国际自动计算杂志 17:151-178

47. Wang Y, Sun T, Li S, Yuan X, Ni W, Hossain E, Poor HV (2023) Adversarial attacks and defenses in machine learning-empowered communication systems and networks: a contemporary survey. IEEE Commun Surv Tutor. https://doi.org/10.1109/COMST.2023.3319492

47. 王阳，孙涛，李思，袁鑫，倪伟，侯赛因 E，Poor HV(2023)机器学习赋能的通信系统与网络中的对抗攻击与防御:现代综述。IEEE通信综述与教程。https://doi.org/10.1109/COMST.2023.3319492

48. Yuan L, Chen Y, Cui G, Gao H, Zou F, Cheng X, Ji H, Liu Z, Sun M (2024) Revisiting out-of-distribution robustness in NLP: benchmarks, analysis, and LLMs evaluations. Adv Neural Inf Process Syst 36

48. 袁林，陈颖，崔刚，高浩，邹菲，程翔，纪恒，刘泽，孙明(2024)重新审视自然语言处理中的分布外鲁棒性:基准测试、分析与大型语言模型(LLMs)评估。先进神经信息处理系统 36

49. Liu B, Xiao B, Jiang X, Cen S, He X, Dou W (2023) Adversarial attacks on large language model-based system and mitigating strategies: a case study on ChatGPT. Secur Commun Netw 1:8691095

49. 刘兵，小兵，江翔，岑思，何翔，窦伟(2023)基于大型语言模型的系统的对抗攻击与缓解策略:以ChatGPT为例。安全通信与网络 1:8691095

50. Alsmadi I, Aljaafari N, Nazzal M, Alhamed S, Sawalmeh AH, Vizcarra CP, Khreishah A, Anan M, Algosaibi A, Al-Naeem MA et al (2022) Adversarial machine learning in text processing: a literature survey. IEEE Access 10:17043-17077

50. Alsmadi I，Aljaafari N，Nazzal M，Alhamed S，Sawalmeh AH，Vizcarra CP，Khreishah A，Anan M，Algosaibi A，Al-Naeem MA 等(2022)文本处理中的对抗机器学习:文献综述。IEEE Access 10:17043-17077

51. He X, Wang J, Xu Q, Minervini P, Stenetorp P, Rubinstein BI, Cohn T (2024) Transferring troubles: cross-lingual transferability of backdoor attacks in LLMs with instruction tuning. arXiv preprint arXiv:2404.19597

51. He X, Wang J, Xu Q, Minervini P, Stenetorp P, Rubinstein BI, Cohn T (2024) 转移麻烦:指令调优(instruction tuning)中大规模语言模型(LLMs)后门攻击的跨语言可迁移性。arXiv预印本 arXiv:2404.19597

52. Vassilev Apostol, Oprea Alina, Fordyce Alie, Anderson Hyrum (2024) Adversarial machine learning. Gaithersburg, Maryland

52. Vassilev Apostol, Oprea Alina, Fordyce Alie, Anderson Hyrum (2024) 对抗性机器学习。马里兰州盖瑟斯堡

53. Jin D, Jin Z, Zhou JT, Szolovits P (2020) Is Bert really robust? A strong baseline for natural language attack on text classification and entailment. In: Proceedings of the AAAI conference on artificial intelligence ${34}\left( {05}\right)  : {8018} - {8025}$

53. Jin D, Jin Z, Zhou JT, Szolovits P (2020) BERT真的具有鲁棒性吗？针对文本分类和蕴含(entailment)任务的强基线自然语言攻击。收录于:人工智能会议(AAAI)论文集

54. Ren S, Deng Y, He K, Che W (2019) Generating natural language adversarial examples through probability weighted word saliency. In: Proceedings of the 57th annual meeting of the association for computational linguistics, pp 1085-1097

54. Ren S, Deng Y, He K, Che W (2019) 通过概率加权词显著性生成自然语言对抗样本。收录于:第57届计算语言学协会年会论文集，第1085-1097页

55. Li J, Ji S, Du T, Li B, Wang T (2019) Textbugger: generating adversarial text against real-world applications. In: 26th annual network and distributed system security symposium, NDSS 2019, San Diego, California, USA, 24-27 Feb, 2019. The Internet Society

55. Li J, Ji S, Du T, Li B, Wang T (2019) Textbugger:针对实际应用生成对抗性文本。收录于:第26届网络与分布式系统安全研讨会(NDSS 2019)，美国加利福尼亚州圣地亚哥，2019年2月24-27日。互联网协会

56. Gao J, Lanchantin J, Soffa ML, Qi Y. Black-box generation of adversarial text sequences to evade (2018) Black-box generation of adversarial text sequences to evade deep learning classifiers. In: 2018 IEEE security and privacy workshops (SPW). IEEE, pp 50-56

56. Gao J, Lanchantin J, Soffa ML, Qi Y. 黑盒生成对抗性文本序列以规避(2018)深度学习分类器。收录于:2018年IEEE安全与隐私研讨会(SPW)。IEEE，第50-56页

57. Alzantot M, Sharma Y, Elgohary A, Ho BJ, Srivastava M, Chang KW (2018) Generating natural language adversarial examples. In: Riloff E, Chiang D, Hockenmaier J, Tsujii J (eds)Proceedings of the 2018 conference on empirical methods in natural language processing, Brussels, Belgium, October-November 2018. Association for Computational Linguistics, pp 2890-2896

57. Alzantot M, Sharma Y, Elgohary A, Ho BJ, Srivastava M, Chang KW (2018) 生成自然语言对抗样本。收录于:Riloff E, Chiang D, Hockenmaier J, Tsujii J(编)2018年自然语言处理实证方法会议论文集，比利时布鲁塞尔，2018年10-11月。计算语言学协会，第2890-2896页

58. Mrkšić N, Séaghdha DO, Thomson B, Gašić M, Rojas-Barahona LM, Su PH, Vandyke D, Wen T-H, Young S (2016) Counter-fitting word vectors to linguistic constraints. In: Knight K, Nenkova A, Rambow O (eds) Proceedings of the 2016 conference of the North American chapter of the association for computational linguistics: human language technologies, San Diego, California, June 2016. Association for Computational Linguistics, pp 142-148

58. Mrkšić N, Séaghdha DO, Thomson B, Gašić M, Rojas-Barahona LM, Su PH, Vandyke D, Wen T-H, Young S (2016) 将词向量(word vectors)与语言学约束进行反向调整。收录于:Knight K, Nenkova A, Rambow O(编)2016年北美计算语言学协会人类语言技术会议论文集，圣地亚哥，加利福尼亚，2016年6月。计算语言学协会，第142-148页

59. Liang B, Li H, Su M, Bian P, Li X, Shi W (2018) Deep text classification can be fooled. In: Proceedings of the twenty-seventh international joint conference on artificial intelligence. International joint conferences on artificial intelligence organization

59. Liang B, Li H, Su M, Bian P, Li X, Shi W (2018) 深度文本分类可以被欺骗。收录于:第27届国际人工智能联合会议论文集。国际人工智能联合会议组织

60. Glockner M, Shwartz V, Goldberg Y (2018) Breaking NLI systems with sentences that require simple lexical inferences. In: Gurevych I, Miyao Y (eds) Proceedings of the 56th annual meeting of the association for computational linguistics (volume 2: short papers), Melbourne, Australia, July. Association for Computational Linguistics, pp 650-655

60. Glockner M, Shwartz V, Goldberg Y (2018) 利用需要简单词汇推理的句子破坏自然语言推理(NLI)系统。收录于:Gurevych I, Miyao Y(编)第56届计算语言学协会年会(第二卷:短论文)，澳大利亚墨尔本，2018年7月。计算语言学协会，第650-655页

61. Bowman SR, Angeli G, Potts C, Manning CD (2015) A large annotated corpus for learning natural language inference. In: Màrquez L, Callison-Burch C, Su J (eds) Proceedings of the 2015 conference on empirical methods in natural language processing, Lisbon, Portugal, September. Association for Computational Linguistics, pp 632-642

61. Bowman SR, Angeli G, Potts C, Manning CD (2015) 一个用于学习自然语言推理的大型标注语料库。收录于:Màrquez L, Callison-Burch C, Su J(编)2015年自然语言处理实证方法会议论文集，葡萄牙里斯本，9月。计算语言学协会，第632-642页

62. Lei Qi Wu, Lingfei Chen Pin-Yu, Alex Dimakis, Dhillon Inderjit S, Witbrock Michael J (2019) Discrete adversarial attacks and submodular optimization with applications to text classification. Proc Mach Learn Syst 1:146-165

62. Lei Qi Wu, Lingfei Chen Pin-Yu, Alex Dimakis, Dhillon Inderjit S, Witbrock Michael J (2019) 离散对抗攻击与子模优化及其在文本分类中的应用。机器学习系统会议 1:146-165

63. Li H, Guo D, Fan W, Xu M, Huang J, Meng F, Song (2023) Multistep jailbreaking privacy attacks on ChatGPT. In HBouamor H, Pino J, Bali K (eds) Findings of the association for computational linguistics: EMNLP 2023, Singapore, . Association for Computational Linguistics, pp 4138-4153

63. Li H, Guo D, Fan W, Xu M, Huang J, Meng F, Song (2023) ChatGPT多步越狱隐私攻击。在HBouamor H, Pino J, Bali K (编) 计算语言学协会发现:EMNLP 2023，新加坡，. 计算语言学协会，第4138-4153页

64. Carlini N (2023) A LLM assisted exploitation of AI-Guardian. arXiv preprint arXiv:2307.15008

64. Carlini N (2023) 利用LLM辅助的AI-Guardian利用技术。arXiv预印本 arXiv:2307.15008

65. Liu Y, Deng G, Li Y, Wang K, Zhang T, Liu Y, Wang H, Zheng $\mathrm{Y}$ , Liu $\mathrm{Y}$ (2023) Prompt injection attack against $\mathrm{{llm}}$ -integrated applications. arXiv preprint arXiv:2306.05499

65. Liu Y, Deng G, Li Y, Wang K, Zhang T, Liu Y, Wang H, Zheng $\mathrm{Y}$ , Liu $\mathrm{Y}$ (2023) 针对$\mathrm{{llm}}$一体化应用的提示注入攻击。arXiv预印本 arXiv:2306.05499

66. Chen Y, Arunasalam A, Celik ZB (2023) Can large language models provide security & privacy advice? Measuring the ability of llms to refute misconceptions. In: Proceedings of the 39th annual computer security applications conference, ACSAC '23, New York, NY, USA, 2023. Association for Computing Machinery, pp 366-378

66. Chen Y, Arunasalam A, Celik ZB (2023) 大型语言模型能否提供安全与隐私建议？衡量LLMs反驳误解的能力。在:第39届年度计算机安全应用会议论文集，ACSAC '23，美国纽约，2023年。计算机机械协会，第366-378页

67. Duan H, Dziedzic A, Yaghini M, Papernot N, Boenisch F (2023) On the privacy risk of in-context learning. In: The 61st Annual meeting of the association for computational linguistics

67. Duan H, Dziedzic A, Yaghini M, Papernot N, Boenisch F (2023) 关于上下文学习的隐私风险。在:第61届计算语言学协会年会

68. Xue J, Zheng M, Hua T, Shen Y, Liu Y, Bölöni L, Lou Q (2024) Trojllm: a black-box trojan prompt attack on large language models. Adv Neural Inf Process Syst 36:65665-65677

68. Xue J, Zheng M, Hua T, Shen Y, Liu Y, Bölöni L, Lou Q (2024) Trojllm:一种针对大型语言模型的黑箱特洛伊木马提示攻击。先进神经信息处理系统 36:65665-65677

69. Perez F, Ribeiro I (2022) Ignore previous prompt: attack techniques for language models. arXiv preprint arXiv:2211.09527

69. Perez F, Ribeiro I (2022) 忽略之前的提示:语言模型的攻击技术。arXiv预印本 arXiv:2211.09527

70. Liu Y, Yao Y, Ton JF, Zhang X, Cheng RG, Klochkov Y, Taufiq MF, Li H (2023) trustworthy llms: a survey and guideline for evaluating large language models' alignment. In: Socially Responsible Language Modelling Research

70. Liu Y, Yao Y, Ton JF, Zhang X, Cheng RG, Klochkov Y, Taufiq MF, Li H (2023) 可信赖的LLMs:评估大型语言模型对齐的调查与指南。在:社会责任语言建模研究

71. Wei A, Haghtalab N, Steinhardt J (2024) Jailbroken: How does llm safety training fail? Adv Neural Inf Process Syst 36:80079- 80110

71. Wei A, Haghtalab N, Steinhardt J (2024) 越狱:LLM安全训练为何失败？先进神经信息处理系统 36:80079-80110

72. Ebrahimi J, Rao A, Lowd D, Dou D (2018) HotFlip: white-box adversarial examples for text classification. In: Gurevych I, Miyao $\mathrm{Y}$ (eds) Proceedings of the 56th annual meeting of the association for computational linguistics (volume 2: short papers), Melbourne, Australia, July. Association for Computational Linguistics, pp 31-36

72. Ebrahimi J, Rao A, Lowd D, Dou D (2018) HotFlip:文本分类的白盒对抗样本。在:Gurevych I, Miyao $\mathrm{Y}$ (编) 第56届计算语言学协会年会论文集(第2卷:短论文)，澳大利亚墨尔本，7月。计算语言学协会，第31-36页

73. Chen M, He G, Wu J (2024) ZDDR: a zero-shot defender for adversarial samples detection and restoration. IEEE Access. https://doi.org/10.1109/ACCESS.2024.3356568

73. Chen M, He G, Wu J (2024) ZDDR:一种零样本对抗样本检测与修复的防御方法。IEEE Access。https://doi.org/10.1109/ACCESS.2024.3356568

74. Wallace E, Feng S, Kandpal N, Gardner M, Singh S (2019) Universal adversarial triggers for attacking and analyzing NLP. In: Inui K, Jiang J, Ng V, Wan X (eds) Proceedings of the 2019 conference on empirical methods in natural language processing and the 9th international joint conference on natural language processing (EMNLP-IJCNLP), Hong Kong, China, November 2019. Association for Computational Linguistics, pp 2153-2162

74. Wallace E, Feng S, Kandpal N, Gardner M, Singh S (2019) 通用对抗触发器，用于攻击和分析自然语言处理。在:Inui K, Jiang J, Ng V, Wan X (编) 2019年自然语言处理经验方法会议和第九届国际联合自然语言处理会议论文集，香港，中国，2019年11月。计算机机械协会，第2153-2162页

75. Pruthi D, Dhingra B, Lipton ZC (2019) Combating adversarial misspellings with robust word recognition. In: Korhonen A, Traum D, Màrquez L (eds) Proceedings of the 57th annual meeting of the association for computational linguistics, Florence, Italy, July . Association for Computational Linguistics, pp 5582-5591

75. Pruthi D, Dhingra B, Lipton ZC (2019) 通过鲁棒词识别应对对抗性拼写错误。在:Korhonen A, Traum D, Màrquez L (编) 第57届计算语言学协会年会论文集，意大利佛罗伦萨，7月。计算语言学协会，第5582-5591页

76. Lim S, Schmälzle R (2023) Artificial intelligence for health message generation: an empirical study using a large language model (LLM) and prompt engineering. Front Commun 8:1129082

76. Lim S, Schmälzle R (2023) 人工智能在健康信息生成中的应用:一项使用大型语言模型(LLM)和提示工程的实证研究。前沿传播 8:1129082

77. Jiang W, Li H, Xu G, Zhang T (2023) Color backdoor: a robust poisoning attack in color space. In: Proceedings of the IEEE/CVF conference on computer vision and pattern recognition, pp 8133- 8142

77. Jiang W, Li H, Xu G, Zhang T (2023) 彩色后门:一种在色彩空间中的鲁棒中毒攻击。In: IEEE/CVF计算机视觉与模式识别会议论文集，第8133-8142页

78. Bao R, Wang J, Zhao H (2021) Defending pre-trained language models from adversarial word substitution without performance sacrifice. In: Zong C, Xia F, Li W, Navigli R (eds) Findings of the association for computational linguistics: ACL-IJCNLP 2021, Online, August 2021. Association for Computational Linguistics, pp 3248-3258

78. Bao R, Wang J, Zhao H (2021) 在不牺牲性能的情况下，防御预训练语言模型免受对抗性词替换攻击。In: Zong C, Xia F, Li W, Navigli R (编) 计算语言学协会研究成果:ACL-IJCNLP 2021线上会议，2021年8月。计算语言学协会，第3248-3258页

79. Wang B, Pei H, Pan B, Chen Q, Wang S, Li B (2020) T3: tree-autoencoder constrained adversarial text generation for targeted attack. In: Webber B, Cohn T, He Y, Liu Y (eds) Proceedings of the 2020 conference on empirical methods in natural language processing (EMNLP), Online, November 2020. Association for Computational Linguistics, pp 6134-6150

79. Wang B, Pei H, Pan B, Chen Q, Wang S, Li B (2020) T3:树状自编码器约束的对抗文本生成用于定向攻击。In: Webber B, Cohn T, He Y, Liu Y (编) 2020年自然语言处理实证方法会议论文集(EMNLP)，线上，2020年11月。计算语言学协会，第6134-6150页

80. Lin J, Zou J, Ding N (2021) Using adversarial attacks to reveal the statistical bias in machine reading comprehension models. In: Zong C, Xia F, Li W, Navigli R (eds) Proceedings of the 59th annual meeting of the association for computational linguistics and the 11th international joint conference on natural language processing (volume 2: short papers), Online, August 2021. Association for Computational Linguistics, pp 333-342

80. Lin J, Zou J, Ding N (2021) 利用对抗性攻击揭示机器阅读理解模型中的统计偏差。In: Zong C, Xia F, Li W, Navigli R (编) 第59届计算语言学协会年会暨第11届国际自然语言处理联合会议论文集(第2卷:短论文)，线上，2021年8月。计算语言学协会，第333-342页

81. Gan WC, Ng HT (2019) Improving the robustness of question answering systems to question paraphrasing. In: Proceedings of the 57th annual meeting of the association for computational linguistics, pp 6065-6075

81. Gan WC, Ng HT (2019) 提升问答系统对问题释义(question paraphrasing)鲁棒性的研究。In: 第57届计算语言学协会年会论文集，第6065-6075页

82. Zhang Y, Baldridge J, He L (2019) PAWS: paraphrase adversaries from word scrambling. In: Burstein J, Doran C, Solorio T (eds) Proceedings of the 2019 conference of the North American chapter of the association for computational linguistics: human language technologies, volume 1 (long and short papers), Minneapolis, Minnesota, June . Association for Computational Linguistics, pp 1298-1308

82. Zhang Y, Baldridge J, He L (2019) PAWS:来自词序扰乱的释义对手。In: Burstein J, Doran C, Solorio T (编) 北美计算语言学协会人类语言技术会议论文集(第1卷:长短论文)，明尼阿波利斯，明尼苏达州，2021年6月。计算语言学协会，第1298-1308页

83. Kurita K, Michel P, Neubig G (2020) Weight poisoning attacks on pretrained models. In: Jurafsky D, Chai J, Schluter N, Tetreault J (eds) Proceedings of the 58th annual meeting of the association for computational linguistics, Online, July . Association for Computational Linguistics, pp 2793-2806

83. Kurita K, Michel P, Neubig G (2020) 预训练模型的权重中毒攻击。In: Jurafsky D, Chai J, Schluter N, Tetreault J (编) 第58届计算语言学协会年会论文集，线上，2020年7月。计算语言学协会，第2793-2806页

84. Han X, Zhang Z, Ding N, Gu Y, Liu X, Huo Y, Qiu J, Yao Y, Zhang A, Zhang L et al (2021) Pre-trained models: past, present and future. AI Open 2:225-250

84. Han X, Zhang Z, Ding N, Gu Y, Liu X, Huo Y, Qiu J, Yao Y, Zhang A, Zhang L 等 (2021) 预训练模型:过去、现在与未来。AI Open 2:225-250

85. Fursov I, Zaytsev A, Burnyshev P, Dmitrieva E, Klyuchnikov N, Kravchenko A, Artemova E, Komleva E, Burnaev E (2022) A differentiable language model adversarial attack on text classifiers. IEEE Access 10:17966-17976

85. Fursov I, Zaytsev A, Burnyshev P, Dmitrieva E, Klyuchnikov N, Kravchenko A, Artemova E, Komleva E, Burnaev E (2022) 一种可微分的语言模型对抗攻击文本分类器。IEEE Access 10:17966-17976

86. Bajaj A, Vishwakarma DK (2023) Evading text based emotion detection mechanism via adversarial attacks. Neurocomputing 558:126787

86. Bajaj A, Vishwakarma DK (2023) 通过对抗性攻击规避基于文本的情感检测机制。Neurocomputing 558:126787

87. Myers D, Mohawesh R, Chellaboina VI, Sathvik AL, Venkatesh $\mathrm{P},\mathrm{{Ho}}\mathrm{{YH}}$ , Henshaw H, Alhawawreh M, Berdik D, Jararweh Y (2024) Foundation and large language models: fundamentals, challenges, opportunities, and social impacts. Clust Comput 27(1):1-26

87. Myers D, Mohawesh R, Chellaboina VI, Sathvik AL, Venkatesh $\mathrm{P},\mathrm{{Ho}}\mathrm{{YH}}$ , Henshaw H, Alhawawreh M, Berdik D, Jararweh Y (2024) 基础模型与大型语言模型:基础、挑战、机遇与社会影响。Clust Comput 27(1):1-26

88. Xu X, Kong K, Liu N, Cui L, Wang D, Zhang J, Kankanhalli M (2024) An LLM can fool itself: a prompt-based adversarial attack. In: The twelfth international conference on learning representations

88. Xu X, Kong K, Liu N, Cui L, Wang D, Zhang J, Kankanhalli M (2024) 一个大型语言模型可以欺骗自己:基于提示的对抗攻击。在:第十二届学习表示国际会议

89. Wang T, Wang X, Qin Y, Packer B, Li K, Chen J, Beutel A, Chi E (2020) CAT-gen: improving robustness in NLP models via controlled adversarial text generation. In: Webber B, Cohn T, He $\mathrm{Y}$ , Liu $\mathrm{Y}$ (eds) Proceedings of the 2020 conference on empirical methods in natural language processing (EMNLP), Online, November 2020. Association for Computational Linguistics, pp 5141-5146

89. Wang T, Wang X, Qin Y, Packer B, Li K, Chen J, Beutel A, Chi E (2020) CAT-gen:通过受控对抗文本生成提升NLP模型的鲁棒性。In: Webber B, Cohn T, He $\mathrm{Y}$ , Liu $\mathrm{Y}$ (编) 2020年自然语言处理实证方法会议论文集(EMNLP)，线上，2020年11月。计算语言学协会，第5141-5146页

90. Qi F, Chen Y, Li M, Yao Y, Liu Z, Sun M (2021) ONION: a simple and effective defense against textual backdoor attacks. In: Moens MF, Huang X, Specia L, Yih SWT (eds) Proceedings of the 2021 conference on empirical methods in natural language processing, Online and Punta Cana, Dominican Republic, November (2021). Association for Computational Linguistics, pp 9558-9566

90. Qi F, Chen Y, Li M, Yao Y, Liu Z, Sun M (2021) ONION:一种简单有效的文本后门攻击防御方法。在:Moens MF, Huang X, Specia L, Yih SWT(编)2021年自然语言处理实证方法会议论文集，线上和蓬塔卡纳，多米尼加共和国，2021年11月。计算语言学协会，第9558-9566页

91. Zhang Z, Xiao G, Li Y, Lv T, Qi F, Liu Z, Wang Y, Jiang X, Sun M (2023) Red alarm for pre-trained models: universal vulnerability to neuron-level backdoor attacks. Mach Intell Res 20(2):180-193

91. 张志，肖刚，李毅，吕涛，齐峰，刘志，王勇，江旭，孙明(2023)预训练模型的红色警报:对神经元级后门攻击的普遍脆弱性。机器智能研究20(2):180-193

92. Li L, Song D, Li X, Zeng J, Ma R, Qiu X (20121) Backdoor attacks on pre-trained models by layerwise weight poisoning. In: Moens MF, Huang X, Specia L, Yih SWT (eds) Proceedings of the 2021 conference on empirical methods in natural language processing, Online and Punta Cana, Dominican Republic, November 2021. Association for Computational Linguistics, pp 3023-3032

92. 李丽，宋达，李欣，曾佳，马锐，邱旭(2021)通过逐层权重中毒对预训练模型的后门攻击。在:Moens MF, Huang X, Specia L, Yih SWT(编)2021年自然语言处理实证方法会议论文集，线上和蓬塔卡纳，多米尼加共和国，2021年11月。计算语言学协会，第3023-3032页

93. Cheng M, Yi J, Chen PY, Zhang H, Hsieh CJ (2020) Seq2sick: evaluating the robustness of sequence-to-sequence models with adversarial examples. In: Proceedings of the AAAI conference on artificial intelligence 34:3601-3608

93. 程明，易江，陈PY，张浩，谢CJ(2020)Seq2sick:用对抗样本评估序列到序列模型的鲁棒性。在:第34届人工智能会议(AAAI)论文集，3601-3608页

94. Xie X, Wu J, Liu G, Lin Z (2024) SSCNet: learning-based subspace clustering. Vis Intell 2(1):11

94. 谢欣，吴俊，刘刚，林志(2024)SSCNet:基于学习的子空间聚类。视觉智能，2(1):11

95. Dong X, Luu AT, Ji R, Liu H (2021) Towards robustness against natural language word substitutions. In: International conference on learning representations

95. 董晓，吕安泰，季然，刘浩(2021)迈向对自然语言词替换的鲁棒性。在:国际表示学习会议

96. Blum O, Brattoli B, Ommer B (2019) X-GAN: improving generative adversarial networks with convex combinations. In: Pattern Recognition: 40th German conference, GCPR 2018, Stuttgart, Germany, October 9-12, 2018, proceedings 40. Springer, pp 199- 214

96. Blum O, Brattoli B, Ommer B(2019)X-GAN:通过凸组合改进生成对抗网络。在:模式识别:第40届德国会议，GCPR 2018，德国斯图加特，2018年10月9-12日，论文集第40卷，Springer，第199-214页

97. Szeghy D, Milacski ZA, Fóthi A, Lorincz A (2021) Adversarial perturbation stability of the layered group basis pursuit. def 1:2

97. Szeghy D, Milacski ZA, Fóthi A, Lorincz A(2021)分层群组基础追踪的对抗扰动稳定性。定义1:2

98. Yuan L, Zeng J, Zheng X (2021) Sparsegan: sparse generative adversarial network for text generation. arXiv preprint arXiv:2103.11578

98. Yuan L, Zeng J, Zheng X(2021)Sparsegan:用于文本生成的稀疏生成对抗网络。arXiv预印本 arXiv:2103.11578

99. Tsiligkaridis T, Roberts J (2022) Understanding and increasing efficiency of Frank-Wolfe adversarial training. In: Proceedings of the IEEE/CVF conference on computer vision and pattern recognition, pp 50-59

99. Tsiligkaridis T, Roberts J(2022)理解并提升Frank-Wolfe对抗训练的效率。在:IEEE/CVF计算机视觉与模式识别会议论文集，50-59页

100. La Malfa E (2023) On robustness for natural language processing. PhD thesis, University of Oxford

100. La Malfa E(2023)关于自然语言处理的鲁棒性。牛津大学博士论文

101. Steinhardt J, Koh PW, Liang PS (2017) Certified defenses for data poisoning attacks. In: I. Guyon and U. Von Luxburg and S. Bengio and H. Wallach and R. Fergus and S. Vishwanathan and R.Garnett (eds) Curran Associates, Inc. Adv Neural Inf Process Syst 30. https://proceedings.neurips.cc/paper_files/paper/2017/ file/9d7311ba459f9e45ed746755a32dcd11-Paper.pdf

101. Steinhardt J, Koh PW, Liang PS(2017)数据污染攻击的认证防御。在:I. Guyon、U. Von Luxburg、S. Bengio、H. Wallach、R. Fergus、S. Vishwanathan、R.Garnett(编)Curran出版社。神经信息处理系统进展30。https://proceedings.neurips.cc/paper_files/paper/2017/file/9d7311ba459f9e45ed746755a32dcd11-Paper.pdf

102. Raghunathan A, Steinhardt J, Liang P (2018) Certified defenses against adversarial examples. In: 6th International conference on learning representations, ICLR 2018, Vancouver, BC, Canada, April 30-May 3, 2018, conference track proceedings. OpenRe-view.net

102. Raghunathan A, Steinhardt J, Liang P(2018)针对对抗样本的认证防御。在:第6届国际表示学习会议(ICLR 2018)，加拿大温哥华，BC，2018年4月30日至5月3日，会议论文集。OpenRe-view.net

103. Wang W, Tang P, Lou J, Xiong L (2021) Certified robustness to word substitution attack with differential privacy. In: Proceedings of the 2021 conference of the North American chapter of the association for computational linguistics: human language technologies, pp 1102-1112

103. Wang W, Tang P, Lou J, Xiong L(2021)基于差分隐私的词替换攻击的认证鲁棒性。在:2021年北美计算语言学协会人类语言技术会议论文集，1102-1112页

104. Sato M, Suzuki J, Shindo H, Matsumoto Y (2018) Interpretable adversarial perturbation in input embedding space for text. In: Proceedings of the 27th international joint conference on artificial intelligence, IJCAI'18. AAAI Press, pp 4323-4330

104. Sato M, Suzuki J, Shindo H, Matsumoto Y(2018)用于文本的输入嵌入空间中的可解释对抗扰动。在:第27届国际人工智能联合会议(IJCAI'18)，AAAI出版社，4323-4330页

105. Gong Z, Wang W, Li B, Song D, Ku WS (2018) Adversarial texts with gradient methods (01)

105. Gong Z, Wang W, Li B, Song D, Ku WS(2018)基于梯度方法的对抗文本(01)

106. Jia R, Raghunathan A, Göksel K, Liang P (2019) Certified robustness to adversarial word substitutions. In: Inui K, Jiang $\mathrm{J},\mathrm{{Ng}}\mathrm{V}$ , Wan $\mathrm{X}$ (eds) Proceedings of the 2019 conference on empirical methods in natural language processing and the 9th international joint conference on natural language processing (EMNLP-IJCNLP), Hong Kong, China, November 2019. Association for Computational Linguistics, pp 4129-4142

106. Jia R, Raghunathan A, Göksel K, Liang P (2019) 经过认证的对抗词替换鲁棒性。在:Inui K, Jiang $\mathrm{J},\mathrm{{Ng}}\mathrm{V}$ , Wan $\mathrm{X}$ (编) 2019年自然语言处理经验方法会议及第九届自然语言处理国际联合会议(EMNLP-IJCNLP)论文集，香港，中国，2019年11月。计算语言学协会，第4129-4142页

107. Huang PS, Stanforth R, Welbl J, Dyer C, Yogatama D, Gowal S, Dvijotham K, Kohli P (2019) Achieving verified robustness to symbol substitutions via interval bound propagation. In: Inui $\mathrm{K}$ , Jiang J, $\mathrm{{Ng}}\mathrm{V}$ , Wan $\mathrm{X}$ (eds) Proceedings of the 2019 conference on empirical methods in natural language processing and the 9th international joint conference on natural language processing (EMNLP-IJCNLP), Hong Kong, China, November 2019. Association for Computational Linguistics, pp 4083-4093

107. Huang PS, Stanforth R, Welbl J, Dyer C, Yogatama D, Gowal S, Dvijotham K, Kohli P (2019) 通过区间界传播实现符号替换的验证鲁棒性。在:Inui $\mathrm{K}$ , Jiang J, $\mathrm{{Ng}}\mathrm{V}$ , Wan $\mathrm{X}$ (编) 2019年自然语言处理经验方法会议及第九届自然语言处理国际联合会议(EMNLP-IJCNLP)论文集，香港，中国，2019年11月。计算语言学协会，第4083-4093页

108. Dong X (2022) Adversarial attacks and defenses in natural language processing

108. Dong X (2022) 自然语言处理中的对抗攻击与防御

109. Madry A, Makelov A, Schmidt L, Tsipras D, Vladu A (2018) Towards deep learning models resistant to adversarial attacks. In: 6th International conference on learning Representations, ICLR 2018, Vancouver, BC, Canada, April 30-May 3, 2018, conference track proceedings. OpenReview.net

109. Madry A, Makelov A, Schmidt L, Tsipras D, Vladu A (2018) 面向抗对抗攻击的深度学习模型。 在:第六届国际学习表示会议(ICLR 2018)，加拿大温哥华，BC，2018年4月30日至5月3日，会议论文集。OpenReview.net

110. Yoo JY, Morris JX, Lifland E, Qi Y (2020) Searching for a search method: Benchmarking search algorithms for generating NLP adversarial examples. In: Alishahi A, Belinkov Y, Chrupata G, Hupkes D, Pinter Y, Sajjad H (eds) Proceedings of the third Black-boxNLP workshop on analyzing and interpreting neural networks for NLP, Online, November 2020. Association for Computational Linguistics, pp 323-332

110. Yoo JY, Morris JX, Lifland E, Qi Y (2020) 寻找搜索方法:生成自然语言处理对抗样本的搜索算法基准测试。在:Alishahi A, Belinkov Y, Chrupata G, Hupkes D, Pinter Y, Sajjad H (编) 第三届黑盒自然语言处理工作坊论文集，线上，2020年11月。计算语言学协会，第323-332页

111. Barham S, Feizi S (2019) Interpretable adversarial training for text. arXiv preprint arXiv:1905.12864

111. Barham S, Feizi S (2019) 可解释的文本对抗训练。arXiv预印本 arXiv:1905.12864

112. Papernot N, McDaniel P, Swami A, Harang R (2016) Crafting adversarial input sequences for recurrent neural networks. In: MILCOM 2016-2016 IEEE military communications conference. IEEE, pp 49-54

112. Papernot N, McDaniel P, Swami A, Harang R (2016) 为循环神经网络设计对抗输入序列。在:MILCOM 2016-2016年IEEE军事通信会议。IEEE，第49-54页

113. Miyato T, Dai AM, Goodfellow I (2016) Adversarial training methods for semi-supervised text classification. arXiv preprint arXiv:1605.07725

113. Miyato T, Dai AM, Goodfellow I (2016) 半监督文本分类的对抗训练方法。arXiv预印本 arXiv:1605.07725

114. Guo C, Sablayrolles A, Jégou H, Kiela D (2021) Gradient-based adversarial attacks against text transformers. In: Moens MF, Huang X, Specia L, Yih SWT (eds) Proceedings of the 2021 conference on empirical methods in natural language processing, Online and Punta Cana, Dominican Republic, November 2021. Association for Computational Linguistics, pp 5747-5757

114. Guo C, Sablayrolles A, Jégou H, Kiela D (2021) 针对文本变换器(Transformer)的梯度基础对抗攻击。在:Moens MF, Huang X, Specia L, Yih SWT (编) 2021年自然语言处理经验方法会议论文集，线上和多米尼加共和国蓬塔卡纳，2021年11月。计算语言学协会，第5747-5757页

115. Sadrizadeh S , Dolamic L, Frossard P (2022) Block-sparse adversarial attack to fool transformer-based text classifiers. In: ICASSP 2022-2022 IEEE international conference on acoustics, speech and signal processing (ICASSP). IEEE, pp 7837-7841

115. Sadrizadeh S , Dolamic L, Frossard P (2022) 阻块稀疏对抗攻击以欺骗基于变换器的文本分类器。在:ICASSP 2022-2022年IEEE声学、语音与信号处理国际会议。IEEE，第7837-7841页

116. Costa JC, Roxo T, Proença H, Inácio PRM. How deep learning sees the world: a survey on adversarial attacks & defenses. IEEE Access (2024)

116. Costa JC, Roxo T, Proença H, Inácio PRM. 深度学习如何看待世界:对抗攻击与防御的综述。IEEE Access(2024)

117. Birbil ŞI, Fang SC, Sheu RL (2004) On the convergence of a population-based global optimization algorithm. J Glob Optim 30:301-318

117. Birbil ŞI, Fang SC, Sheu RL (2004) 关于一种基于群体的全局优化算法的收敛性。J Glob Optim 30:301-318

118. Khormali A, Nyang D, Mohaisen D (2020) Generating adversarial examples with an optimized quality. arXiv preprint arXiv:2007.00146

118. Khormali A, Nyang D, Mohaisen D (2020) 生成具有优化质量的对抗样本。arXiv预印本 arXiv:2007.00146

119. Jia R (2020) Building robust natural language processing systems. Stanford University, Stanford

119. Jia R (2020) 构建鲁棒的自然语言处理系统。斯坦福大学，斯坦福

120. Morris JX, Lifland E, Yoo JY, Grigsby J, Jin D, Qi Y (2020) TextAttack: a framework for adversarial attacks, data augmentation, and adversarial training in NLP. In: Liu Q, Schlangen D (eds) Proceedings of the 2020 conference on empirical methods in natural language processing: system demonstrations, Online, October. Association for Computational Linguistics, pp 119-126

120. Morris JX, Lifland E, Yoo JY, Grigsby J, Jin D, Qi Y (2020) TextAttack:一个用于对抗攻击、数据增强和对抗训练的自然语言处理框架。在:Liu Q, Schlangen D (编) 2020年自然语言处理经验方法会议论文集:系统演示，线上，2020年10月。计算语言学协会，第119-126页

121. Zang Y, Qi F, Yang C, Liu Z, Zhang M, Liu Q, Sun M (2020) Word-level textual adversarial attacking as combinatorial optimization. In: Jurafsky D, Chai J, Schluter N, Tetreault J (eds) Proceedings of the 58th annual meeting of the association for computational linguistics, Online, July 2020. Association for Computational Linguistics, pp 6066-6080

121. Zang Y, Qi F, Yang C, Liu Z, Zhang M, Liu Q, Sun M (2020) 词级文本对抗攻击作为组合优化。在:Jurafsky D, Chai J, Schluter N, Tetreault J(编辑)第58届计算语言学协会年会论文集，线上，2020年7月。计算语言学协会，第6066-6080页

122. Maheshwary R, Maheshwary S, Pudi V (2021) Generating natural language attacks in a hard label black box setting. In: Proceedings of the AAAI conference on artificial intelligence 35:13525-13533

122. Maheshwary R, Maheshwary S, Pudi V (2021) 在硬标签黑盒环境中生成自然语言攻击。在:AAAI人工智能会议论文集第35卷:13525-13533

123. Jasser J, Garibay I (2021) Resilience from diversity: population-based approach to harden models against adversarial attacks. arXiv preprint arXiv:2111.10272

123. Jasser J, Garibay I (2021) 多样性中的韧性:基于群体的方法增强模型对抗攻击的抗性。arXiv预印本 arXiv:2111.10272

124. Garg S, Ramakrishnan G (eds) BAE: BERT-based adversarial examples for text classification. In: Webber B, Cohn T, He Y, Liu $\mathrm{Y}$ (eds) Proceedings of the 2020 conference on empirical methods in natural language processing (EMNLP), Online, November 2020. Association for Computational Linguistics, pp 6174-6181

124. Garg S, Ramakrishnan G(编辑) BAE:基于BERT(双向编码器表示)文本分类对抗样本。在:Webber B, Cohn T, He Y, Liu $\mathrm{Y}$(编辑)2020年自然语言处理实证方法会议论文集(EMNLP)，线上，2020年11月。计算语言学协会，第6174-6181页

125. Jin D, Jin Z, Zhou JT, Szolovits P (2020) Is BERT really robust? A strong baseline for natural language attack on text classification and entailment. In: Proceedings of the AAAI conference on artificial intelligence 34:8018-8025

125. Jin D, Jin Z, Zhou JT, Szolovits P (2020) BERT真的具有鲁棒性吗？针对文本分类和蕴含任务的强基线自然语言攻击。在:AAAI人工智能会议论文集第34卷:8018-8025

126. Maheshwary R, Maheshwary S, Pudi V (2021) A strong baseline for query efficient attacks in a black box setting. In: Moens MF, Huang X, Specia L, Yih SWT (eds) Proceedings of the 2021 conference on empirical methods in natural language processing, Online and Punta Cana, Dominican Republic, November 2021. Association for Computational Linguistics, pp 8396-8409

126. Maheshwary R, Maheshwary S, Pudi V (2021) 黑盒环境中查询效率攻击的强基线。在:Moens MF, Huang X, Specia L, Yih SWT(编辑)2021年自然语言处理实证方法会议论文集，线上和多明各岛，2021年11月。计算语言学协会，第8396-8409页

127. Wang B, Xu C, Liu X, Cheng Y, Li B (2022) SemAttack: natural textual attacks via different semantic spaces. In: Carpuat M, De Marneffe MC, Meza Ruiz IV (eds) Findings of the association for computational linguistics: NAACL 2022, Seattle, United States, July 2022. Association for Computational Linguistics, pp 176- 205

127. Wang B, Xu C, Liu X, Cheng Y, Li B (2022) SemAttack:通过不同语义空间实现的自然文本攻击。在:Carpuat M, De Marneffe MC, Meza Ruiz IV(编辑)2022年计算语言学协会会议论文集:NAACL，西雅图，美国，2022年7月。计算语言学协会，第176-205页

128. Lee D, Moon S, Lee J, Song HO (2022) Query-efficient and scalable black-box adversarial attacks on discrete sequential data via Bayesian optimization. In: International conference on machine learning. PMLR, pp 12478-12497

128. Lee D, Moon S, Lee J, Song HO (2022) 通过贝叶斯优化实现的查询高效且可扩展的离散序列数据黑盒对抗攻击。在:国际机器学习会议。PMLR，第12478-12497页

129. Peng H, Wang Z, Zhao D, Wu Y, Han J, Guo S, Ji S, Zhong M (2023) Efficient text-based evolution algorithm to hard-label adversarial attacks on text. J King Saud Univ Comput Inf Sci 35(5):101539

129. Peng H, Wang Z, Zhao D, Wu Y, Han J, Guo S, Ji S, Zhong M (2023) 高效文本演化算法用于文本的硬标签对抗攻击。J King Saud Univ Comput Inf Sci 35(5):101539

130. Liu Y, Huang Y, Cai Z (2023) AED: An black-box NLP classifier model attacker. Neurocomputing 550:126489

130. Liu Y, Huang Y, Cai Z (2023) AED:一种黑盒自然语言处理(NLP)分类器模型攻击工具。Neurocomputing 550:126489

131. Caucheteux C, Gramfort A, King JR (2021) GPT-2's activations predict the degree of semantic comprehension in the human brain. BioRxiv, pp 2021-2004

131. Caucheteux C, Gramfort A, King JR (2021) GPT-2的激活反映人脑中的语义理解程度。BioRxiv，第2021-2004页

132. Goldstein A, Zada Z, Buchnik E, Schain M, Price A, Aubrey B, Nastase SA, Feder A, Emanuel D, Cohen A et al (2022) Shared computational principles for language processing in humans and deep language models. Nat Neurosci 25(3):369-380

132. Goldstein A, Zada Z, Buchnik E, Schain M, Price A, Aubrey B, Nastase SA, Feder A, Emanuel D, Cohen A 等 (2022) 人类与深度语言模型在语言处理中的共享计算原则。Nat Neurosci 25(3):369-380

133. Heilbron M, Armeni K, Schoffelen JM, Hagoort P, De Lange FP (2022) A hierarchy of linguistic predictions during natural language comprehension. In: Proceedings of the national academy of sciences, 119(32):e2201968119

133. Heilbron M, Armeni K, Schoffelen JM, Hagoort P, De Lange FP (2022) 自然语言理解中的层级预测机制。在:美国国家科学院院刊，119(32):e2201968119

134. Kumar S, Sumers TR, Yamakoshi T, Goldstein A, Hasson U, Norman KA, Griffiths TL, Hawkins RD, Nastase SA (2022) Reconstructing the cascade of language processing in the brain using the internal computations of a transformer-based language model. BioRxiv, pp 2022-2006

134. Kumar S, Sumers TR, Yamakoshi T, Goldstein A, Hasson U, Norman KA, Griffiths TL, Hawkins RD, Nastase SA (2022) 利用变换器(Transformer)模型的内部计算重建大脑中的语言处理级联过程。BioRxiv，第2022-2006页

135. Bastings J, Filippova K (2020) The elephant in the interpretability room: Why use attention as explanation when we have saliency methods? In: Alishahi A, Belinkov Y, Chrupafa G, Hupkes D, Pinter Y, Sajjad H (eds) Proceedings of the third BlackboxNLP workshop on analyzing and interpreting neural networks for NLP, Online, November 2020. Association for Computational Linguistics, pp 149-155

135. Bastings J, Filippova K (2020) 解释性中的大象:为什么在有显著性方法的情况下仍然使用注意力机制作为解释？在:Alishahi A, Belinkov Y, Chrupafa G, Hupkes D, Pinter Y, Sajjad H(编)第三区黑盒自然语言处理(BlackboxNLP)工作坊论文集，线上，2020年11月。计算语言学协会，第149-155页

136. Ghojogh B, GhodsiA(2020) Attentionmechanism, transformers, BERT, and GPT: OSF Preprints tutorial and survey 12. https:// www.researchgate.net/profile/Benyamin-Ghojogh/publication/ 347623569_Attention_Mechanism_Transformers_BERT_and_ GPT_Tutorial_and_Survey/links/640e5b3aa1b72772e4eea211/ Attention-Mechanism-Transformers-BERT-and-GPT-Tutorial-and-Survey.pdf

136. Ghojogh B, GhodsiA(2020) 注意力机制(Attention mechanism)、变换器(transformers)、BERT 和 GPT:OSF预印本教程与综述 12. https://www.researchgate.net/profile/Benyamin-Ghojogh/publication/347623569_Attention_Mechanism_Transformers_BERT_and_GPT_Tutorial_and_Survey/links/640e5b3aa1b72772e4eea211/Attention-Mechanism-Transformers-BERT-and-GPT-Tutorial-and-Survey.pdf

137. Sundararajan M, Taly A, Yan Q (2017) Axiomatic attribution for deep networks. In: International conference on machine learning. PMLR, pp 3319-3328

137. Sundararajan M, Taly A, Yan Q (2017) 深度网络的公理归因方法。在:国际机器学习会议。PMLR，第3319-3328页

138. Shrikumar A, Greenside P, Kundaje A (2017) Learning important features through propagating activation differences. In: International conference on machine learning. PMLR, pp 3145-3153

138. Shrikumar A, Greenside P, Kundaje A (2017) 通过传播激活差异学习重要特征。在:国际机器学习会议。PMLR，第3145-3153页

139. Chen J, Song L, Wainwright M, Jordan M (2018) Learning to explain: an information-theoretic perspective on model interpretation. In: International conference on machine learning. PMLR, pp 883-892

139. Chen J, Song L, Wainwright M, Jordan M (2018) 学习解释:一种信息论视角的模型解释。在:国际机器学习会议。PMLR，第883-892页

140. Zang Y, Hou B, Qi F, Liu Z, Meng X, Sun M (2020) Learning to attack: towards textual adversarial attacking in real-world situations. arXiv preprint arXiv:2009.09192

140. Zang Y, Hou B, Qi F, Liu Z, Meng X, Sun M (2020) 学习攻击:面向实际场景的文本对抗攻击。arXiv预印本 arXiv:2009.09192

141. Roth T, Gao Y, Abuadbba A, Nepal S, Liu W (2024) Token-modification adversarial attacks for natural language processing: a survey. AI Commun (04):1-22

141. Roth T, Gao Y, Abuadbba A, Nepal S, Liu W (2024) 语言模型的令牌修改对抗攻击:综述。AI通讯(04):1-22

142. Cheng R, Jin Y (2014) A competitive swarm optimizer for large scale optimization. IEEE Trans Cybern 45(2):191-204

142. Cheng R, Jin Y (2014) 一种用于大规模优化的竞争群体优化器。IEEE智能系统杂志 45(2):191-204

143. Yang Q, Chen WN, Da Deng J, Li Y, Gu T, Zhang J (2017) A level-based learning swarm optimizer for large-scale optimization. IEEE Trans Evolut Comput 22(4):578-594

143. Yang Q, Chen WN, Da Deng J, Li Y, Gu T, Zhang J (2017) 一种基于层级的学习群体优化器，用于大规模优化。IEEE进化计算杂志 22(4):578-594

144. Li X, Yao X (2011) Cooperatively coevolving particle swarms for large scale optimization. IEEE Trans Evolut Comput 16(2):210- 224

144. Li X, Yao X (2011) 协同进化粒子群算法，用于大规模优化。IEEE进化计算杂志 16(2):210-224

145. Mounsif M, Zehnder K, Motie Y, Adam-Gaxotte Z (2023) Swar-Mind: harnessing large language models for flock dynamics. In: 2023 10th international conference on soft computing & machine intelligence (ISCMI). IEEE, pp 171-177 (2023)

145. Mounsif M, Zehnder K, Motie Y, Adam-Gaxotte Z (2023) Swar-Mind:利用大型语言模型实现群体动力学。在:2023年第十届软计算与机器智能国际会议(ISCMI)。IEEE，第171-177页(2023)

146. Wang Q, Guo P, Sun S, Xie L, Hansen JH (2019) Adversarial regularization for end-to-end robust speaker verification. In: Interspeech, pp 4010-4014

146. Wang Q, Guo P, Sun S, Xie L, Hansen JH (2019) 端到端鲁棒语音验证的对抗正则化。在:Interspeech，pp 4010-4014

147. Abdelali A, Mubarak H, Chowdhury S, Hasanain M, Mousi B, Boughorbel S, Abdaljalil S, Kheir YE, Izham D, Dalvi F, Hawasly M, Nazar N, Elshahawy Y, Ali A, Durrani N, Milic-Frayling N, Alam F (2024) LAraBench: benchmarking Arabic AI with large language models. In: Graham Y, Purver M (eds) Proceedings of the 18th conference of the European chapter of the association for computational linguistics (volume 1: long papers), St. Julian's, Malta, March 2024. Association for Computational Linguistics, pp 487-520

147. Abdelali A, Mubarak H, Chowdhury S, Hasanain M, Mousi B, Boughorbel S, Abdaljalil S, Kheir YE, Izham D, Dalvi F, Hawasly M, Nazar N, Elshahawy Y, Ali A, Durrani N, Milic-Frayling N, Alam F (2024) LAraBench:基于大型语言模型的阿拉伯语人工智能基准测试。在:Graham Y, Purver M(编)第十八届欧洲计算语言学会(EACL)会议论文集(第一卷:长论文)，马耳他圣朱利安斯，2024年3月。计算语言学协会，第487-520页

148. Bang Y, Cahyawijaya S, Lee N, Dai W, Su D, Wilie B, Lovenia H, Ji Z, Yu T, Chung W, Do QV (2023) A multitask, multilingual, multimodal evaluation of ChatGPT on reasoning, hallucination, and interactivity. In: Park JC, Arase Y, Hu B, Lu W, Wijaya D, Purwarianti A, Krisnadhi AA (eds) Proceedings of the 13th international joint conference on natural language processing and the 3rd conference of the Asia-Pacific chapter of the association for computational linguistics (volume 1: long papers), Nusa Dua, Bali, November 2023. Association for Computational Linguistics, pp 675-718

148. Bang Y, Cahyawijaya S, Lee N, Dai W, Su D, Wilie B, Lovenia H, Ji Z, Yu T, Chung W, Do QV (2023) ChatGPT在推理、幻觉和交互性方面的多任务、多语言、多模态评估。在:Park JC, Arase Y, Hu B, Lu W, Wijaya D, Purwarianti A, Krisnadhi AA(编)第十三届自然语言处理国际联合会议(IJCNLP)与亚太计算语言学会第三届会议(APACL)论文集(第一卷:长论文)，印尼努沙杜瓦，2023年11月。计算语言学协会，第675-718页

149. Chen Y, Wang R, Jiang H, Shi S, Xu R (2023) Exploring the use of large language models for reference-free text quality evaluation: an empirical study (01):361-374

149. Chen Y, Wang R, Jiang H, Shi S, Xu R (2023) 探索大型语言模型在无参考文本质量评估中的应用:一项实证研究(01):361-374

150. Choi M, Pei J, Kumar S, Shu C, Jurgens D (2023) Do LLMs understand social knowledge? Evaluating the sociability of large language models with SocKET benchmark. In: Bouamor H, Pino J, Bali LK (eds) Proceedings of the 2023 conference on empirical methods in natural language processing, Singapore, December 2023. Association for Computational Linguistics, pp 11370- 11403

150. Choi M, Pei J, Kumar S, Shu C, Jurgens D (2023) 大型语言模型是否理解社会知识？利用SocKET基准评估其社交能力。收录于:Bouamor H, Pino J, Bali LK (编) 2023年自然语言处理实证方法会议论文集，新加坡，2023年12月。计算语言学协会，第11370-11403页

151. Chia YK, Hong P, Bing L, Poria S (2024) InstructEval: towards holistic evaluation of instruction-tuned large language models. In: Miceli-Barone AV, Barez F, Cohen S, Voita E, Germann U, Lukasik M (eds) Proceedings of the first edition of the workshop on the scaling behavior of large language models (SCALE-LLM 2024), St. Julian's, Malta, March 2024. Association for Computational Linguistics, pp 35-64

151. Chia YK, Hong P, Bing L, Poria S (2024) InstructEval:面向指令调优大型语言模型的整体评估。收录于:Miceli-Barone AV, Barez F, Cohen S, Voita E, Germann U, Lukasik M (编) 2024年第一届大规模语言模型扩展行为研讨会论文集(SCALE-LLM 2024)，马耳他圣朱利安斯，2024年3月。计算语言学协会，第35-64页

152. Fu Y, Ou L, Chen M, Wan Y, Peng H, Khot T (2023) Chain-of-thought hub: a continuous effort to measure large language models' reasoning performance. arXiv preprint arXiv:2305.17306

152. Fu Y, Ou L, Chen M, Wan Y, Peng H, Khot T (2023) Chain-of-thought中心:持续衡量大型语言模型推理性能的努力。arXiv预印本 arXiv:2305.17306

153. Gekhman Z, Herzig J, Aharoni R, Elkind C, Szpektor I (2023) Trueteacher: learning factual consistency evaluation with large language models. In: The 2023 conference on empirical methods in natural language processing

153. Gekhman Z, Herzig J, Aharoni R, Elkind C, Szpektor I (2023) Trueteacher:利用大型语言模型学习事实一致性评估。收录于:2023年自然语言处理实证方法会议

154. Honovich O, Aharoni R, Herzig J, Taitelbaum H, Kukliansy D, Cohen V, Scialom T, Szpektor I, Hassidim A, Matias Y (2022) TRUE: re-evaluating factual consistency evaluation. In: Feng S, Wan H, Yuan C, Yu H (eds) Proceedings of the second DialDoc workshop on document-grounded dialogue and conversational question answering, Dublin, Ireland, May 2022. Association for Computational Linguistics, pp 161-175

154. Honovich O, Aharoni R, Herzig J, Taitelbaum H, Kukliansy D, Cohen V, Scialom T, Szpektor I, Hassidim A, Matias Y (2022) TRUE:重新评估事实一致性评估。收录于:Feng S, Wan H, Yuan C, Yu H (编) 第二届基于文档的对话与会话问答研讨会论文集，爱尔兰都柏林，2022年5月。计算语言学协会，第161-175页

155. Lai VD, Ngo NT, Veyseh AP, Man H, Dernoncourt F, Bui T, Nguyen TH (2023)ChatGPT beyond English: towards a comprehensive evaluation of large language models in multilingual learning. In: Bouamor H, Pino J, Bali K (eds) Findings of the association for computational linguistics: EMNLP 2023, Singapore, December 2023. Association for Computational Linguistics, pp 13171-13189

155. Lai VD, Ngo NT, Veyseh AP, Man H, Dernoncourt F, Bui T, Nguyen TH (2023) ChatGPT超越英语:面向多语言学习的大型语言模型全面评估。收录于:Bouamor H, Pino J, Bali K (编) 2023年计算语言学协会会议(EMNLP 2023)研究成果，新加坡，2023年12月。计算语言学协会，第13171-13189页

156. Lopez-Lira A, Tang Y (2023) Can chatgpt forecast stock price movements? return predictability and large language models. In: Return predictability and large language models (April 6, 2023)

156. Lopez-Lira A, Tang Y (2023) ChatGPT能预测股价变动吗？收益预测能力与大型语言模型。收录于:收益预测与大型语言模型(2023年4月6日)

157. Durmus E, Nyugen K, Liao TI, Schiefer N, Askell A, Bakhtin A, Chen C, Hatfield-Dodds Z, Hernandez D, Joseph N et al (2023) Towards measuring the representation of subjective global opinions in language models. arXiv preprint arXiv:2306.16388

157. Durmus E, Nyugen K, Liao TI, Schiefer N, Askell A, Bakhtin A, Chen C, Hatfield-Dodds Z, Hernandez D, Joseph N 等 (2023) 迈向衡量语言模型中主观全球观点表现的研究。arXiv预印本 arXiv:2306.16388

158. Lin YT, Chen YN (2023) LLM-eval: Unified multi-dimensional automatic evaluation for open-domain conversations with large language models. In: Chen YN, Rastogi A (eds) Proceedings of the 5th workshop on NLP for conversational AI (NLP4ConvAI 2023), Toronto, Canada, July 2023. Association for Computational Linguistics, pp 47-58

158. 林Y T, 陈Y N (2023) LLM-eval:面向开放域对话的大规模语言模型的多维度自动评估统一方法。在:陈Y N, Rastogi A(编)第5届对话式人工智能自然语言处理研讨会(NLP4ConvAI 2023)论文集，加拿大多伦多，2023年7月。计算语言学协会，第47-58页

159. Liu H, Ning R, Teng Z, Liu J, Zhou Q, Zhang Y (2023) Evaluating the logical reasoning ability of ChatGPT and GPT-4. arXiv preprint arXiv:2304.03439

159. 刘H, 宁R, 腾Z, 刘J, 周Q, 张Y (2023) 评估ChatGPT和GPT-4的逻辑推理能力。arXiv预印本 arXiv:2304.03439

160. Zhang Y, Xiang T, Hospedales TM, Lu H (2018) Deep mutual learning. In: Proceedings of the IEEE conference on computer vision and pattern recognition, pp 4320-4328

160. 张Y, 向T, Hospedales TM, 卢H (2018) 深度互学习。在:IEEE计算机视觉与模式识别会议论文集，第4320-4328页

161. Brown T, Mann B, Ryder N, Subbiah M, Kaplan JD, Dhariwal P, Neelakantan A, Shyam P, Sastry G, Askell A et al (2020) Language models are few-shot learners. Adv Neural Inf Process Syst 33:1877-1901

161. Brown T, Mann B, Ryder N, Subbiah M, Kaplan JD, Dhariwal P, Neelakantan A, Shyam P, Sastry G, Askell A 等 (2020) 语言模型是少-shot学习者。神经信息处理系统进展 33:1877-1901

162. He P, Liu X, Gao J, Chen W (2020) Deberta: decoding-enhanced BERT with disentangled attention. In: International conference on learning representations

162. 何P, 刘X, 高J, 陈W (2020) Deberta:带解缠注意力的解码增强BERT。在:国际表示学习会议

163. Yang Y, Lv H, Chen N (2022) A survey on ensemble learning under the era of deep learning. Artif Intell Rev 56(6):5545-5589

163. 杨Y, 吕H, 陈N (2022) 深度学习时代的集成学习综述。人工智能评论 56(6):5545-5589

164. Dong X, Yu Z, Cao W, Shi Y, Ma Q (2020) A survey on ensemble learning. Front Comput Sci 14:241-258

164. 董X, 于Z, 曹W, 史Y, 马Q (2020) 集成学习综述。计算机科学前沿 14:241-258

165. Zhu X, Gong (2018) Knowledge distillation by on-the-fly native ensemble. Adv Neural Inf Process Syst 31

165. 朱X, Gong (2018) 通过原生集成进行知识蒸馏。神经信息处理系统进展 31

166. Chen D, Mei JP, Wang C, Feng Y, Chen C (2020) Online knowledge distillation with diverse peers. In: Proceedings of the AAAI conference on artificial intelligence 34:3430-3437

166. 陈D, 梅JP, 王C, 冯Y, 陈C (2020) 多样同行的在线知识蒸馏。在:人工智能协会会议论文集第34卷:3430-3437

167. Li Z, Huang Y, Chen D, Luo T, Cai N, Pan Z (2020) Online knowledge distillation via multi-branch diversity enhancement. In: Proceedings of the Asian conference on computer vision

167. 李Z, 黄Y, 陈D, 罗T, 蔡N, 潘Z (2020) 通过多分支多样性增强的在线知识蒸馏。在:亚洲计算机视觉会议论文集

168. Liu X, Wang Y, Ji J, Cheng H, Zhu X, Awa E, He P, Chen W, Poon H, Cao G et al (2020) The microsoft toolkit of multi-task deep neural networks for natural language understanding. In: Proceedings of the 58th annual meeting of the association for computational linguistics: system demonstrations, pp 118-126

168. 刘X, 王Y, 季J, 程H, 朱X, Awa E, 何P, 陈W, 潘H, 曹G 等 (2020) 微软多任务深度神经网络工具包用于自然语言理解。在:第58届计算语言学协会年会系统演示论文集，第118-126页

169. Luong MT, Le QV, Sutskever I, Vinyals O, Kaiser L (2016) Multitask sequence to sequence learning. In: Bengio Y, LeCun Y (eds) 4th international conference on learning representations, ICLR 2016, San Juan, Puerto Rico, May 2-4, 2016, conference track proceedings

169. 卢昂MT, Le QV, Sutskever I, Vinyals O, Kaiser L (2016) 多任务序列到序列学习。在:Y. Bengio, Y. LeCun(编)第四届表示学习国际会议(ICLR 2016)，波多黎各圣胡安，2016年5月2-4日，会议论文集

170. Ruder S, Bingel J, Augenstein I, Søgaard A (2019) Latent multi-task architecture learning. In: Proceedings of the AAAI conference on artificial intelligence 33:4822-4829

170. Ruder S, Bingel J, Augenstein I, Søgaard A (2019) 潜在多任务架构学习。在:人工智能协会会议论文集第33卷:4822-4829

171. Ramé A, Cord M (2021) Dice: Diversity in deep ensembles via conditional redundancy adversarial estimation. In: ICLR 2021-9th international conference on learning representations

171. Ramé A, Cord M (2021) Dice:通过条件冗余对抗估计实现深度集成的多样性。在:ICLR 2021-第九届表示学习国际会议

172. Feng S, Chen H, Ren X, Ding Z, Li K, Sun X (2021) Collaborative group learning

172. 冯S, 陈H, 任X, 丁Z, 李K, 孙X (2021) 协作组学习

173. Wu G, Gong S (2021) Peer collaborative learning for online knowledge distillation. In: Proceedings of the AAAI conference on artificial intelligence 35:10302-10310

173. 吴G, 宫S (2021) 在线知识蒸馏的同行协作学习。在:人工智能协会会议论文集第35卷:10302-10310

174. Gehman S, Gururangan S, Sap M, Choi Y, Smith NA (2020) RealToxicityPrompts: Evaluating neural toxic degeneration in language models. In: Cohn T, He Y, Liu Y (eds) Findings of the association for computational linguistics: EMNLP 2020, Online, November 2020. Association for Computational Linguistics, pp 3356-3369

174. Gehman S, Gururangan S, Sap M, Choi Y, Smith NA (2020) RealToxicityPrompts:评估语言模型中的神经毒性退化。在:Cohn T, He Y, Liu Y(编)计算语言学协会的研究成果:EMNLP 2020，线上，2020年11月。计算语言学协会，第3356-3369页

175. Maus N, Chao P, Wong E, Gardner J (2023) Adversarial prompting for black box foundation models. arXiv preprint arXiv:2302.04237

175. Maus N, Chao P, Wong E, Gardner J (2023) 对黑箱基础模型的对抗性提示。arXiv预印本 arXiv:2302.04237

176. Shin T, Razeghi Y, Logan IV RL, Wallace E, Singh S (2020) Autoprompt: eliciting knowledge from language models with automatically generated prompts. In: Proceedings of the 2020 conference on empirical methods in natural language processing (EMNLP), pages 4222-4235

176. Shin T, Razeghi Y, Logan IV RL, Wallace E, Singh S (2020) Autoprompt:利用自动生成的提示从语言模型中引出知识。在:2020年自然语言处理经验方法会议(EMNLP)论文集，页4222-4235

177. Zou A, Wang Z, Kolter JZ, Fredrikson M (2023) Universal and transferable adversarial attacks on aligned language models

177. Zou A, Wang Z, Kolter JZ, Fredrikson M (2023) 对齐语言模型的通用且可转移的对抗攻击

178. Goyal S, Doddapaneni S, Khapra MM, Ravindran B (2023) A survey of adversarial defenses and robustness in NLP. ACM Comput Surv 55(14s):1-39

178. Goyal S, Doddapaneni S, Khapra MM, Ravindran B (2023) NLP中的对抗防御与鲁棒性综述。ACM计算综述 55(14s):1-39

179. Liu X, Cheng H, He P, Chen W, Wang Y, Poon H, Gao J (2020) Adversarial training for large neural language models. arXiv preprint arXiv:2004.08994

179. Liu X, Cheng H, He P, Chen W, Wang Y, Poon H, Gao J (2020) 大型神经语言模型的对抗训练。arXiv预印本 arXiv:2004.08994

180. Jain N, Schwarzschild A, Wen Y, Somepalli G, Kirchenbauer J, Chiang PY, Goldblum M, Saha A, Geiping J, Goldstein T (2024) Baseline defenses for adversarial attacks against aligned language models

180. Jain N, Schwarzschild A, Wen Y, Somepalli G, Kirchenbauer J, Chiang PY, Goldblum M, Saha A, Geiping J, Goldstein T (2024) 针对对齐语言模型的对抗攻击的基线防御

181. Kumar A, Agarwal C, Srinivas S, Feizi S, Lakkaraju H (2023) Certifying llm safety against adversarial prompting. arXiv preprint arXiv:2309.02705

181. Kumar A, Agarwal C, Srinivas S, Feizi S, Lakkaraju H (2023) 认证LLM(大规模语言模型)对抗性提示的安全性。arXiv预印本 arXiv:2309.02705

182. Vaswani A, Shazeer N, Parmar N, Uszkoreit J, Jones L, Gomez AN, Kaiser L, Polosukhin I (2017) Attention is all you need. In: I. Guyon and U. Von Luxburg and S. Ben-gio and H. Wallach and R. Fergus and S. Vishwanathan and R. Garnett Curran Associates, Inc. Adv Neural Inf Process Syst 30. https://proceedings.neurips.cc/paper_files/paper/2017/ file/3f5ee243547dee91fbd053c1c4a845aa-Paper.pdf

182. Vaswani A, Shazeer N, Parmar N, Uszkoreit J, Jones L, Gomez AN, Kaiser L, Polosukhin I (2017) 注意力机制就是你所需要的。在:I. Guyon 和 U. Von Luxburg 和 S. Ben-gio 和 H. Wallach 和 R. Fergus 和 S. Vishwanathan 和 R. Garnett(编)神经信息处理系统进展第30卷。https://proceedings.neurips.cc/paper_files/paper/2017/file/3f5ee243547dee91fbd053c1c4a845aa-Paper.pdf

183. Radford A, Wu J, Child R, Luan D, Amodei D, Sutskever I (2019) Language models are unsupervised multitask learners. OpenAI Blog 1(8):9

183. Radford A, Wu J, Child R, Luan D, Amodei D, Sutskever I (2019) 语言模型是无监督的多任务学习者。OpenAI博客 1(8):9

184. Conneau A, Khandelwal K, Goyal N, Chaudhary V, Wenzek G, Guzmán F, Grave E, Ott M, Zettlemoyer L, Stoyanov V (2020) Unsupervised cross-lingual representation learning at scale. In: Jurafsky D, Chai J, Schluter N, Tetreault J (eds) Proceedings of the 58th annual meeting of the association for computational linguistics, Online, July 2020. Association for Computational Linguistics, pp 8440-8451

184. Conneau A, Khandelwal K, Goyal N, Chaudhary V, Wenzek G, Guzmán F, Grave E, Ott M, Zettlemoyer L, Stoyanov V (2020) 大规模无监督跨语言表示学习。在:Jurafsky D, Chai J, Schluter N, Tetreault J(编)第58届计算语言学协会年会论文集，线上，2020年7月。计算语言学协会，第8440-8451页

185. Carlini N, Liu C, Erlingsson U, Kos J, Song D (2019) The secret sharer: evaluating and testing unintended memorization in neural networks. In: 28th USENIX security symposium (USENIX security 19), pp 267-284

185. Carlini N, Liu C, Erlingsson U, Kos J, Song D (2019) 秘密共享者:评估和测试神经网络中的非预期记忆。在:第28届USENIX安全研讨会(USENIX Security 19)，第267-284页

186. Kawaguchi K, Kaelbling LP, Bengio Y (2022) Generalization in deep learning. In: Grohs P, Kutyniok G (eds) Mathematical aspects of deep learning. Cambridge University Press, Cambridge

186. Kawaguchi K, Kaelbling LP, Bengio Y (2022) 深度学习中的泛化。在:Grohs P, Kutyniok G(编)深度学习的数学方面。剑桥大学出版社，剑桥

187. Brown G, Bun M, Feldman V, Smith A, Talwar K (2021) When is memorization of irrelevant training data necessary for high-accuracy learning? In: Proceedings of the ${53}\mathrm{{rd}}$ annual ACM SIGACT symposium on theory of computing, pp 123-132

187. Brown G, Bun M, Feldman V, Smith A, Talwar K (2021) 何时需要记忆无关的训练数据以实现高精度学习？在:年度ACM SIGACT计算理论研讨会论文集，第123-132页

188. Dwork C, McSherry F, Nissim K, Smith A (2006) Calibrating noise to sensitivity in private data analysis. In: Theory of cryptography: third theory of cryptography conference, TCC 2006, New York, NY, USA, March 4-7, 2006. proceedings 3. Springer, pp 265-284

188. Dwork C, McSherry F, Nissim K, Smith A (2006) 在私有数据分析中校准噪声以应对敏感性。在:密码学理论:第三届密码学理论会议(TCC 2006)，纽约，美国，2006年3月4-7日。第3卷，Springer，第265-284页

189. Song S, Chaudhuri K, Sarwate AD (2013) Stochastic gradient descent with differentially private updates. In: 2013 IEEE global conference on signal and information processing. IEEE, pp 245- 248

189. Song S, Chaudhuri K, Sarwate AD (2013) 使用差分隐私更新的随机梯度下降。在:2013年IEEE信号与信息处理全球会议。IEEE，第245-248页

190. Abadi M, Chu A, Goodfellow I, McMahan HB, Mironov I, Talwar K, Zhang L (2016) Deep learning with differential privacy. In: Proceedings of the 2016 ACM SIGSAC conference on computer and communications security, pp 308-318

190. Abadi M, Chu A, Goodfellow I, McMahan HB, Mironov I, Talwar K, Zhang L (2016) 具有差分隐私的深度学习。在:2016年ACM SIGSAC计算机与通信安全会议论文集，第308-318页

191. Li X, Tramer F, Liang P, Hashimoto T (2021) Large language models can be strong differentially private learners. In: International conference on learning representations

191. Li X, Tramer F, Liang P, Hashimoto T (2021) 大型语言模型可以成为强大的差分隐私学习者。在:国际表示学习会议

192. Majmudar J, Dupuy C, Peris C, Smaili S, Gupta R, Zemel R (2022) Differentially private decoding in large language models

192. Majmudar J, Dupuy C, Peris C, Smaili S, Gupta R, Zemel R (2022) 大型语言模型中的差分隐私解码

193. Dupuy C, Arava R, Gupta R, Rumshisky A (2022) An efficient dp-sgd mechanism for large scale NLU models. In: ICASSP 2022-2022 IEEE international conference on acoustics, speech and signal processing (ICASSP). IEEE, pp 4118-4122

193. Dupuy C, Arava R, Gupta R, Rumshisky A (2022) 一种高效的dp-sgd机制用于大规模自然语言理解模型。在:2022年IEEE声学、语音与信号处理国际会议(ICASSP)。IEEE，第4118-4122页

194. Dagan Y, Feldman V (2020) Pac learning with stable and private predictions. In: Conference on learning theory. PMLR, pp 1389- 1410

194. Dagan Y, Feldman V (2020) 具有稳定性和隐私预测的PAC学习。在:学习理论会议。PMLR，第1389-1410页

195. Buckman J, Roy A, Raffel C, Goodfellow I (2018) Thermometer encoding: one hot way to resist adversarial examples. In: International conference on learning representations

195. Buckman J, Roy A, Raffel C, Goodfellow I (2018) 温度编码:一种抗对抗样本的单热编码方法。在:表示学习国际会议

196. Guo C, Rana M, Cisse M, Van Der Maaten L (2018) Countering adversarial images using input transformations. In: International conference on learning representations

196. Guo C, Rana M, Cisse M, Van Der Maaten L (2018) 使用输入变换对抗对抗图像。在:表示学习国际会议

197. Dhillon GS, Azizzadenesheli K, Lipton ZC, Bernstein J, Kossaifi J, Khanna A, Anandkumar A (2018) Stochastic activation pruning for robust adversarial defense. In: International conference on learning representations

197. Dhillon GS, Azizzadenesheli K, Lipton ZC, Bernstein J, Kossaifi J, Khanna A, Anandkumar A (2018) 随机激活剪枝用于鲁棒的对抗防御。在:表示学习国际会议

198. Grosse K, Manoharan P, Papernot N, Backes M, McDaniel P (2017) On the (statistical) detection of adversarial examples. CoRR

198. Grosse K, Manoharan P, Papernot N, Backes M, McDaniel P (2017) 关于对抗样本的(统计)检测。CoRR

199. Gong Z, Wang W (2023) Adversarial and clean data are not twins. In: Proceedings of the sixth international workshop on exploiting artificial intelligence techniques for data management, pp 1-5

199. Gong Z, Wang W (2023) 对抗样本与干净数据不是孪生。在:第六届利用人工智能技术进行数据管理的国际研讨会论文集，第1-5页

200. Minh DN, Luu AT (2022) Textual manifold-based defense against natural language adversarial examples. In: Proceedings of the 2022 conference on empirical methods in natural language processing, pp 6612-6625

200. Minh DN, Luu AT (2022) 基于文本流形的自然语言对抗样本防御。在:2022年自然语言处理实证方法会议论文集，第6612-6625页

201. Yoo K, Kim J, Jang J, Kwak N (2022) Detection of adversarial examples in text classification: benchmark and baseline via robust density estimation. In: Muresan S, Nakov P, Villavicencio A (eds) Findings of the association for computational linguistics: ACL 2022, Dublin, Ireland, May 2022. Association for Computational Linguistics, pp 3656-3672

201. Yoo K, Kim J, Jang J, Kwak N (2022) 文本分类中对抗样本的检测:通过稳健密度估计的基准和基线。在:S. Muresan, P. Nakov, A. Villavicencio(编)《计算语言学协会发现:ACL 2022》，爱尔兰都柏林，2022年5月。计算语言学协会，第3656-3672页

202. Huber L, Kühn MA, Mosca E, Groh G (2022) Detecting word-level adversarial text attacks via shapley additive explanations. In: Proceedings of the 7th workshop on representation learning for NLP, pp 156-166

202. Huber L, Kühn MA, Mosca E, Groh G (2022) 通过Shapley加法解释检测词级对抗文本攻击。在:第七届自然语言处理表示学习研讨会论文集，第156-166页

203. Carlini N, Wagner D (2017) Adversarial examples are not easily detected: bypassing ten detection methods. In: Proceedings of the 10th ACM workshop on artificial intelligence and security, pp 3-14

203. Carlini N, Wagner D (2017) 对抗样本不易被检测:绕过十种检测方法。在:第十届ACM人工智能与安全研讨会论文集，第3-14页

204. Athalye A, Carlini N, Wagner D (2018) Obfuscated gradients give a false sense of security: circumventing defenses to adversarial examples. In: International conference on machine learning. PMLR, pp 274-283

204. Athalye A, Carlini N, Wagner D (2018) 混淆梯度带来虚假的安全感:规避对抗样本的防御。在:机器学习国际会议。PMLR，第274-283页

205. Uesato J, O'donoghue B, Kohli P, Oord A (2018) Adversarial risk and the dangers of evaluating against weak attacks. In: International conference on machine learning. PMLR, pp 5025-5034

205. Uesato J, O'donoghue B, Kohli P, Oord A (2018) 对抗风险与评估弱攻击的危险。在:国际机器学习会议。PMLR，第5025-5034页

206. Laidlaw C, Feizi S (2019) Functional adversarial attacks. In: H. Wallach and H. Larochelle and A. Beygelzimer and F. d'Alché- Buc and E. Fox and R. Garnett Curran Associates, Inc. Adv Neural Inf Process Syst 32. https://proceedings.neurips.cc/paper_files/ paper/2019/file/6e923226e43cd6fac7cfe1e13ad000ac-Paper.pdf

206. Laidlaw C, Feizi S (2019) 功能性对抗攻击。在:H. Wallach、H. Larochelle、A. Beygelzimer、F. d'Alché- Buc、E. Fox、R. Garnett Curran 机构。神经信息处理系统进展第32卷。https://proceedings.neurips.cc/paper_files/paper/2019/file/6e923226e43cd6fac7cfe1e13ad000ac-Paper.pdf

207. Gowal S, Dvijotham K, Stanforth R, Bunel R, Qin C, Uesato J, Arandjelovic R, Mann T, Kohli P (2018) On the effectiveness of interval bound propagation for training verifiably robust models. arXiv preprint arXiv:1810.12715

207. Gowal S, Dvijotham K, Stanforth R, Bunel R, Qin C, Uesato J, Arandjelovic R, Mann T, Kohli P (2018) 区间界限传播在训练可验证鲁棒模型中的有效性。arXiv预印本 arXiv:1810.12715

208. Dvijotham K, Gowal S, Stanforth R, Arandjelovic R, O'Donoghue B, Uesato J, Kohli P (2018) Training verified learners with learned verifiers. arXiv preprint arXiv:1805.10265

208. Dvijotham K, Gowal S, Stanforth R, Arandjelovic R, O'Donoghue B, Uesato J, Kohli P (2018) 使用学习验证器训练经过验证的学习者。arXiv预印本 arXiv:1805.10265

209. Mirman M, Gehr T, Vechev M (2018) Differentiable abstract interpretation for provably robust neural networks. In: International conference on machine learning. PMLR, pp 3578-3586

209. Mirman M, Gehr T, Vechev M (2018) 用于可证明鲁棒神经网络的可微抽象解释。在:国际机器学习会议。PMLR，第3578-3586页

210. Wong E, Kolter Z (2018) Provable defenses against adversarial examples via the convex outer adversarial polytope. In: International conference on machine learning. PMLR, pp 5286-5295

210. Wong E, Kolter Z (2018) 通过凸外对抗多面体证明防御对抗样本的有效性。在:国际机器学习会议。PMLR，第5286-5295页

211. Raghunathan A, Steinhardt J, Liang PS (02018) Semidefinite relaxations for certifying robustness to adversarial examples. In: S. Bengio and H. Wallach and H. Larochelle and K. Grauman and N. Cesa-Bianchi and R. Garnett Curran Associates, Inc. Adv Neural Inf Process Syst 31. https://proceedings.neurips.cc/paper_ files/paper/2018/file/29c0605a3bab4229e46723f89cf59d83- Paper.pdf

211. Raghunathan A, Steinhardt J, Liang PS (2018) 用半正定松弛方法认证对抗样本的鲁棒性。在:S. Bengio、H. Wallach、H. Larochelle、K. Grauman、N. Cesa-Bianchi、R. Garnett Curran 机构。神经信息处理系统进展第31卷。https://proceedings.neurips.cc/paper_files/paper/2018/file/29c0605a3bab4229e46723f89cf59d83-Paper.pdf

212. Singla S, Feizi S (2020) Second-order provable defenses against adversarial attacks. In: International conference on machine learning. PMLR, pp 8981-8991

212. Singla S, Feizi S (2020) 针对对抗攻击的二阶可证明防御。在:国际机器学习会议。PMLR，第8981-8991页

213. Cohen J, Rosenfeld E, Kolter Z (2019) Certified adversarial robustness via randomized smoothing. In: International conference on machine learning. PMLR, pp 1310-1320

213. Cohen J, Rosenfeld E, Kolter Z (2019) 通过随机平滑实现的认证对抗鲁棒性。在:国际机器学习会议。PMLR，第1310-1320页

214. Lecuyer M, Atlidakis V, Geambasu R, Hsu D, Jana S (2019) Certified robustness to adversarial examples with differential privacy. In: 2019 IEEE symposium on security and privacy (SP). IEEE, pp 656-672

214. Lecuyer M, Atlidakis V, Geambasu R, Hsu D, Jana S (2019) 利用差分隐私实现对抗样本的认证鲁棒性。在:2019年IEEE安全与隐私研讨会(SP)。IEEE，第656-672页

215. Li X, Li F (2017) Adversarial examples detection in deep networks with convolutional filter statistics. In: Proceedings of the IEEE international conference on computer vision, pp 5764-5772

215. Li X, Li F (2017) 利用卷积滤波器统计检测深度网络中的对抗样本。在:IEEE国际计算机视觉会议论文集，第5764-5772页

216. Salman H, Li J, Razenshteyn I, Zhang P, Zhang H, Bubeck S, Yang G (2019) Provably robust deep learning via adver-sarially trained smoothed classifiers. In: H. Wallach and H. Larochelle and A.Beygelzimer and F. d'Alché-Buc and E. Fox and R. Garnett Curran Associates, Inc. Adv Neural Inf Process Syst 32. https://proceedings.neurips.cc/paper_files/paper/2019/ file/3a24b25a7b092a252166a1641ae953e7-Paper.pdf

216. Salman H, Li J, Razenshteyn I, Zhang P, Zhang H, Bubeck S, Yang G (2019) 通过对抗训练平滑分类器实现可证明的深度学习鲁棒性。在:H. Wallach、H. Larochelle、A. Beygelzimer、F. d'Alché-Buc、E. Fox、R. Garnett Curran 机构。神经信息处理系统进展第32卷。https://proceedings.neurips.cc/paper_files/paper/2019/file/3a24b25a7b092a252166a1641ae953e7-Paper.pdf

217. Ye M, Gong C, Liu Q (2020) SAFER: a structure-free approach for certified robustness to adversarial word substitutions. In: Jurafsky D, Chai J, Schluter N, Tetreault J (eds) Proceedings of the 58th annual meeting of the association for computational linguistics, Online, July. Association for Computational Linguistics, pp 3465- 3475

217. Ye M, Gong C, Liu Q (2020) SAFER:一种结构无关的认证鲁棒性方法，用于对抗词汇替换攻击。在:Jurafsky D、Chai J、Schluter N、Tetreault J(编)第58届计算语言学协会年会论文集，线上，7月。计算语言学协会，第3465-3475页

218. Zhao H, Ma C, Dong X, Luu AT, Deng ZH, Zhang H (2022) Certified robustness against natural language attacks by causal intervention. In: International conference on machine learning. PMLR, pp 26958-26970

218. Zhao H, Ma C, Dong X, Luu AT, Deng ZH, Zhang H (2022) 通过因果干预实现对自然语言攻击的认证鲁棒性。在:国际机器学习会议。PMLR，第26958-26970页

219. Zhang Z, Zhang G, Hou B, Fan W, Li Q, Liu S, Zhang Y, Chang S (2023) Certified robustness for large language models with self-denoising. arXiv preprint arXiv:2307.07171

219. 张泽, 张刚, 侯博, 范伟, 李强, 刘思, 张颖, 常胜 (2023) 具有自我去噪的认证鲁棒性大型语言模型。arXiv预印本 arXiv:2307.07171

220. Bakhtin A, Gross S, Ott M, Deng Y, Ranzato MA, Szlam A (2019) Real or fake? Learning to discriminate machine from human generated text. arXiv preprint arXiv:1906.03351

220. Bakhtin A, Gross S, Ott M, Deng Y, Ranzato MA, Szlam A (2019) 真伪识别？学习区分机器生成与人类生成文本。arXiv预印本 arXiv:1906.03351

221. Uchendu A, Le T, Shu K, Lee D (2020) Authorship attribution for neural text generation. In: Proceedings of the 2020 conference on empirical methods in natural language processing (EMNLP), pp 8384-8395

221. Uchendu A, Le T, Shu K, Lee D (2020) 神经文本生成的作者归属。收录于:2020年自然语言处理经验方法会议(EMNLP)论文集，第8384-8395页

222. Antoun W, Mouilleron V, Sagot B, Seddah D (2023) Towards a robust detection of language model-generated text: is Chat-GPT that easy to detect? In: Servan C, Vilnat A (eds) Actes de CORIA-TALN 2023. Actes de la 30e Conférence sur le Traite-ment Automatique des Langues Naturelles (TALN), volume 1 : travaux de recherche originaux-articles longs, Paris, France, 6 2023. ATALA, pp 14-27

222. Antoun W, Mouilleron V, Sagot B, Seddah D (2023) 迈向鲁棒的语言模型生成文本检测:Chat-GPT是否如此容易被识别？收录于:Servan C, Vilnat A(编)2023年CORIA-TALN会议论文集。第30届自然语言自动处理(TALN)会议论文集(第1卷:原创研究论文-长篇文章)，法国巴黎，2023年6月。ATALA，第14-27页

223. Li Y, Li Q, Cui L, Bi W, Wang L, Yang L, Shi S, Zhang $\mathrm{Y}$ (2023) Deepfake text detection in the wild. arXiv preprint arXiv:2305.13242

223. 李洋, 李强, 崔磊, 毕伟, 王磊, 杨林, 史思, 张$\mathrm{Y}$ (2023) 野外深度伪造文本检测。arXiv预印本 arXiv:2305.13242

224. Liu Y, Ott M, Goyal N, Du J, Joshi M, Chen D, Levy O, Lewis M, Zettlemoyer L, Stoyanov V (2020) Roberta: a robustly optimized BERT pretraining approach

224. 刘洋, Ott M, Goyal N, Du J, Joshi M, Chen D, Levy O, Lewis M, Zettlemoyer L, Stoyanov V (2020) Roberta:一种鲁棒优化的BERT预训练方法

225. Fagni T, Falchi F, Gambini M, Martella A, Tesconi M (2021) TweepFake: about detecting deepfake tweets. PLoS ONE 16(5):e0251415

225. Fagni T, Falchi F, Gambini M, Martella A, Tesconi M (2021) TweepFake:关于检测深度伪造推文。PLoS ONE 16(5):e0251415

226. Wu J, Yang S, Zhan R, Yuan Y, Wong DF, Chao LS (2023) A survey on LLM-gernerated text detection: necessity, methods, and future directions. arXiv preprint arXiv:2310.14724

226. Wu J, Yang S, Zhan R, Yuan Y, Wong DF, Chao LS (2023) 关于大型语言模型生成文本检测的综述:必要性、方法与未来方向。arXiv预印本 arXiv:2310.14724

227. Zuccon G, Koopman B, Shaik R (2023) ChatGPT hallucinates when attributing answers. In: Proceedings of the annual international ACM SIGIR conference on research and development in information retrieval in the Asia Pacific region, SIGIR-AP '23, New York, NY, USA, 2023. Association for Computing Machinery, page 46-51

227. Zuccon G, Koopman B, Shaik R (2023) ChatGPT在归因回答时出现幻觉。在:2023年亚太地区信息检索研究与开发国际ACM SIGIR会议论文集，SIGIR-AP '23，美国纽约，2023年。计算机协会，第46-51页

228. Liu Y, Zhang Z, Zhang W, Yue S, Zhao X, Cheng X, Zhang Y, $\mathrm{{HuH}}$ (2023) Argugpt: evaluating, understanding and identifying argumentative essays generated by GPT models. arXiv preprint arXiv:2304.07666

228. Liu Y, Zhang Z, Zhang W, Yue S, Zhao X, Cheng X, Zhang Y, $\mathrm{{HuH}}$ (2023) Argugpt:评估、理解与识别由GPT模型生成的论证性文章。arXiv预印本 arXiv:2304.07666

229. Liu Z, Yao Z, Li F, Luo B (2023) Check me if you can: detecting ChatGPT-generated academic writing using checkgpt. arXiv preprint arXiv:2306.05524

229. Liu Z, Yao Z, Li F, Luo B (2023) 你能检测我吗:利用checkgpt检测ChatGPT生成的学术写作。arXiv预印本 arXiv:2306.05524

230. Chen Y, Kang H, Zhai V, Li L, Singh R, Raj B (2023) GPT-sentinel: distinguishing human and chatgpt generated content. arXiv preprint arXiv:2305.07969

230. Chen Y, Kang H, Zhai V, Li L, Singh R, Raj B (2023) GPT哨兵:区分人类与ChatGPT生成内容。arXiv预印本 arXiv:2305.07969

231. Yan Y, Li R, Wang S, Zhang F, Wu W, Xu W (2021) ConSERT: a contrastive framework for self-supervised sentence representation transfer. In: Zong C, Xia F, Li W, Navigli R (eds) Proceedings of the 59th annual meeting of the association for computational linguistics and the 11th international joint conference on natural language processing (volume 1: long papers), Online, August (2021). Association for Computational Linguistics, pp 5065-5075

231. Yan Y, Li R, Wang S, Zhang F, Wu W, Xu W (2021) ConSERT:一种用于句子表示迁移的对比学习框架。收录于:Zong C, Xia F, Li W, Navigli R(编)第59届计算语言学协会年会及第11届自然语言处理国际联合会议论文集(第1卷:长篇论文)，线上，2021年8月。计算机学会，第5065-5075页

232. Gao T, Yao X, Chen D (2021) SimCSE: simple contrastive learning of sentence embeddings. In: Moens MF, Huang X, Specia L, Yih SWT (eds) Proceedings of the 2021 conference on empirical methods in natural language processing, Online and Punta Cana, Dominican Republic, November (2021). Association for Computational Linguistics, pp 6894-6910

232. Gao T, Yao X, Chen D (2021) SimCSE:一种简单的句子嵌入对比学习方法。收录于:Moens MF, Huang X, Specia L, Yih SWT(编)2021年自然语言处理经验方法会议论文集，线上及多明各岛普恩塔卡纳，2021年11月。计算机学会，第6894-6910页

233. Chen Q, Zhang R, Zheng Y, Mao Y (2022) Dual contrastive learning: text classification via label-aware data augmentation. arXiv preprint arXiv:2201.08702

233. Chen Q, Zhang R, Zheng Y, Mao Y (2022) 双重对比学习:通过标签感知的数据增强进行文本分类。arXiv预印本 arXiv:2201.08702

234. Liu X, Zhang Z, Wang Y, Pu H, Lan Y, Shen C (2023) Coco: coherence-enhanced machine-generated text detection under low resource with contrastive learning (01):16167-16188

234. Liu X, Zhang Z, Wang Y, Pu H, Lan Y, Shen C (2023) Coco:在低资源条件下通过对比学习增强机器生成文本的连贯性检测(01):16167-16188

235. Zhong W, Tang D, Xu Z, Wang R, Duan N, Zhou M, Wang J, Yin J (2020) Neural deepfake detection with factual structure of text. In: Webber B, Cohn T, He Y, Liu Y (eds) Proceedings of the 2020 conference on empirical methods in natural language processing (EMNLP), Online, November 2020. Association for Computational Linguistics, pp 2461-2470

235. Zhong W, Tang D, Xu Z, Wang R, Duan N, Zhou M, Wang J, Yin J (2020) 利用文本事实结构进行神经深伪(deepfake)检测。收录于:Webber B, Cohn T, He Y, Liu Y(编)2020年自然语言处理经验方法会议(EMNLP)论文集，线上，2020年11月。计算语言学协会，第2461-2470页

236. Bhattacharjee A, Kumarage T, Moraffah R, Liu H. (2023) ConDA: contrastive domain adaptation for AI-generated text detection. In: Park JC, Arase Y, Hu B, Lu W, Wijaya D, Purwarianti A, Krisnadhi AA (eds) Proceedings of the 13th international joint conference on natural language processing and the 3rd conference of the Asia-Pacific chapter of the association for computational linguistics (volume 1: long Papers), Nusa Dua, Bali, November 2023. Association for Computational Linguistics, pp 598-610

236. Bhattacharjee A, Kumarage T, Moraffah R, Liu H. (2023) ConDA:对比域适应(contrastive domain adaptation)用于AI生成文本检测。在:Park JC, Arase Y, Hu B, Lu W, Wijaya D, Purwarianti A, Krisnadhi AA(编)第13届国际自然语言处理联合会议及亚太地区计算语言学会第三届会议(第一卷:长论文)，巴厘岛努沙杜瓦，2023年11月。计算语言学协会，第598-610页

237. Ullah S, Han M, Pujar S, Pearce H, Coskun A, Stringhini G (2024) LLMS cannot reliably identify and reason about security vulnerabilities (yet?): A comprehensive evaluation, framework, and benchmarks. In: IEEE symposium on security and privacy

237. Ullah S, Han M, Pujar S, Pearce H, Coskun A, Stringhini G (2024) 大型语言模型(LLMS)尚不能可靠识别和推理安全漏洞:全面评估、框架与基准。在:IEEE安全与隐私研讨会

238. Roshan K, Zafar A (2024) Black-box adversarial transferability: an empirical study in cybersecurity perspective. Comput Secur 141:103853

238. Roshan K, Zafar A (2024) 黑箱对抗性转移性:网络安全视角的实证研究。计算机安全 141:103853

239. Zhao Y, Pang T, Du C, Yang X, Li C, Cheung NM, Lin M (2014) On evaluating adversarial robustness of large vision-language models. Adv Neural Inf Process Syst 36:54111-54138

239. Zhao Y, Pang T, Du C, Yang X, Li C, Cheung NM, Lin M (2014) 关于评估大型视觉-语言模型的对抗鲁棒性。先进神经信息处理系统 36:54111-54138

240. Akhtar N, Mian A, Kardan N, Shah M (2021) Advances in adversarial attacks and defenses in computer vision: a survey. IEEE Access 9:155161-155196

240. Akhtar N, Mian A, Kardan N, Shah M (2021) 计算机视觉中对抗攻击与防御的进展:综述。IEEE Access 9:155161-155196

241. Demontis A, Melis M, Pintor M, Jagielski M, Biggio B, Oprea A, Nita-Rotaru C, Roli F (2019) Why do adversarial attacks transfer? Explaining transferability of evasion and poisoning attacks. In: 28th USENIX security symposium (USENIX security 19), pp 321-338

241. Demontis A, Melis M, Pintor M, Jagielski M, Biggio B, Oprea A, Nita-Rotaru C, Roli F (2019) 为什么对抗性攻击具有转移性？解释规避和投毒攻击的可转移性。在:第28届USENIX安全研讨会(USENIX security 19)，第321-338页

242. Le T, Wang S, Lee D (2020) Malcom: generating malicious comments to attack neural fake news detection models. In: 2020 IEEE international conference on data mining (ICDM). IEEE, pp 282- 291

242. Le T, Wang S, Lee D (2020) Malcom:生成恶意评论以攻击神经假新闻检测模型。在:2020年IEEE数据挖掘国际会议(ICDM)。IEEE，第282-291页

243. Zhang D, Zhang T, Lu Y, Zhu Z, Dong (2019) You only propagate once: accelerating adversarial training via-maximal principle. In: H. Wallach and H. Larochelle and A. Beygelzimer and F. d'Alché-Buc and E. Fox and R. Garnett Curran Associates, Inc. Adv Neural Inf Process Syst 32. https://proceedings.neurips.cc/paper_files/paper/2019/ file/812b4ba287f5ee0bc9d43bbf5bbe87fb-Paper.pdf

243. Zhang D, Zhang T, Lu Y, Zhu Z, Dong (2019) 你只需传播一次:通过最大原理加速对抗训练。在:H. Wallach、H. Larochelle、A. Beygelzimer、F. d'Alché-Buc、E. Fox、R. Garnett(编)先进神经信息处理系统第32卷。https://proceedings.neurips.cc/paper_files/paper/2019/file/812b4ba287f5ee0bc9d43bbf5bbe87fb-Paper.pdf

244. Shafahi A, Najibi M, Ghiasi MA, Xu Z, Dickerson J, Studer C, Davis LS, Taylor G, Goldstein T (2019) Adversarial training for free! In: H. Wallach and H. Larochelle and A. Beygelzimer and F. d'Alché-Buc and E. Fox and R. Garnett Curran Associates, Inc. Adv Neural Inf Process Syst 32

244. Shafahi A, Najibi M, Ghiasi MA, Xu Z, Dickerson J, Studer C, Davis LS, Taylor G, Goldstein T (2019) 免费的对抗训练！在:H. Wallach、H. Larochelle、A. Beygelzimer、F. d'Alché-Buc、E. Fox、R. Garnett(编)先进神经信息处理系统第32卷

245. Peris C, Dupuy C, Majmudar J, Parikh R, Smaili S, Zemel R, Gupta R (2023) Privacy in the time of language models. In: Proceedings of the sixteenth ACM international conference on web search and data mining, pp 1291-1292

245. Peris C, Dupuy C, Majmudar J, Parikh R, Smaili S, Zemel R, Gupta R (2023) 语言模型时代的隐私。在:第十六届ACM国际网页搜索与数据挖掘会议论文集，第1291-1292页

246. Madry A, Makelov A, Schmidt L, Tsipras D, Vladu A (2018) Towards deep learning models resistant to adversarial attacks. In: International conference on learning representations

246. Madry A, Makelov A, Schmidt L, Tsipras D, Vladu A (2018) 迈向对抗性攻击抵抗的深度学习模型。在:国际学习表征会议

247. Wong E, Rice L, Kolter JZ (2020) Fast is better than free: revisiting adversarial training. In: 8th international conference on learning representations, ICLR 2020, Addis Ababa, Ethiopia, April 26-30, 2020. OpenReview.net

247. Wong E, Rice L, Kolter JZ (2020) 快速优于免费:重新审视对抗训练。在:第8届国际学习表征会议(ICLR 2020)，埃塞俄比亚亚的斯亚贝巴，2020年4月26-30日。OpenReview.net

248. Yang H, Liang L, Carlone L, Toh KC (2023) An inexact projected gradient method with rounding and lifting by nonlinear programming for solving rank-one semidefinite relaxation of polynomial optimization. Math Progr 201(1):409-472

248. Yang H, Liang L, Carlone L, Toh KC (2023) 一种带有舍入和非线性规划提升的近似投影梯度方法，用于求解多项式优化的秩一半正定松弛。数学规划 201(1):409-472

249. Narang S, Diamos G, Elsen E, Micikevicius P, Alben J, Garcia D, Ginsburg B, Houston M, Kuchaiev O, Venkatesh G, Wu H (2018) Mixed precision training. In: International conference on learning representations

249. Narang S, Diamos G, Elsen E, Micikevicius P, Alben J, Garcia D, Ginsburg B, Houston M, Kuchaiev O, Venkatesh G, Wu H (2018) 混合精度训练。载于:国际表示学习会议

250. Smith LN (2017) Cyclical learning rates for training neural networks. In: 2017 IEEE winter conference on applications of computer vision (WACV). IEEE, pp 464-472

250. Smith LN (2017) 用于训练神经网络的循环学习率。载于:2017 IEEE计算机视觉应用冬季会议(WACV)。IEEE，第464-472页

251. Coleman C, Narayanan D, Kang D, Zhao T, Zhang J, Nardi L, Bailis P, Olukotun K, Ré C, Zaharia M (2017) Dawnbench: an end-to-end deep learning benchmark and competition. Training 100(101):102

251. Coleman C, Narayanan D, Kang D, Zhao T, Zhang J, Nardi L, Bailis P, Olukotun K, Ré C, Zaharia M (2017) Dawnbench:一个端到端的深度学习基准测试与竞赛。训练 100(101):102

252. Chen Y, Wang Q, Wu S, Gao Y, Xu T, Hu Y (2024) TOMGPT: reliable text-only training approach for cost-effective multi-modal large language model. ACM Trans Knowl Discov Data. https:// doi.org/10.1145/3654674

252. Chen Y, Wang Q, Wu S, Gao Y, Xu T, Hu Y (2024) TOMGPT:一种可靠的纯文本训练方法，用于成本效益高的多模态大型语言模型。ACM知识发现与数据传输杂志。https://doi.org/10.1145/3654674

253. Keraghel I, Morbieu S, Nadif M (2024) Beyond words: a comparative analysis of LLM embeddings for effective clustering. In: International symposium on intelligent data analysis. Springer, pp 205-216

253. Keraghel I, Morbieu S, Nadif M (2024) 超越文字:LLM嵌入的有效聚类的对比分析。载于:国际智能数据分析研讨会。Springer，第205-216页

254. Mewada A, Dewang RK (2023) SA-ASBA: a hybrid model for aspect-based sentiment analysis using synthetic attention in pre-trained language BERT model with extreme gradient boosting. J Supercomput 79(5):5516-5551

254. Mewada A, Dewang RK (2023) SA-ASBA:一种结合合成注意力(synthetic attention)与极端梯度提升(extreme gradient boosting)的预训练语言模型(BERT)在方面情感分析中的混合模型。超级计算杂志 79(5):5516-5551

255. Wang Y, Pan Y, Yan M, Su Z, Luan TH (2023) A survey on ChatGPT: AI-generated contents, challenges, and solutions. IEEE Open J Comput Soc. https://doi.org/10.1109/OJCS.2023.3300321

255. Wang Y, Pan Y, Yan M, Su Z, Luan TH (2023) 关于ChatGPT的综述:AI生成内容、挑战与解决方案。IEEE开放期刊计算社会。https://doi.org/10.1109/OJCS.2023.3300321

256. Ribeiro MT, Singh S, Guestrin C (2018) Semantically equivalent adversarial rules for debugging NLP models. In: Proceedings of the 56th annual meeting of the association for computational linguistics (volume 1: long papers), pp 856-865

256. Ribeiro MT, Singh S, Guestrin C (2018) 用于调试自然语言处理(NLP)模型的语义等价对抗规则。收录于第56届计算语言学协会年会论文集(第1卷:长篇论文)，第856-865页

257. Liang B, Li H, Su M, Bian P, Li X, Shi W (2018) Deep text classification can be fooled. In: Proceedings of the 27th international joint conference on artificial intelligence, IJCAI'18. AAAI Press, pp 4208-4215

257. Liang B, Li H, Su M, Bian P, Li X, Shi W (2018) 深度文本分类可能被欺骗。收录于第27届国际人工智能联合会议(IJCAI'18)论文集。AAAI出版社，第4208-4215页

258. Qi X, Huang K, Panda A, Henderson P, Wang M, Mittal P (2024) Visual adversarial examples jailbreak aligned large language models. In: Proceedings of the AAAI conference on artificial intelligence, vol 38, pp 21527-21536

258. Qi X, Huang K, Panda A, Henderson P, Wang M, Mittal P (2024) 视觉对抗样本破解对齐的大型语言模型。收录于第38届人工智能会议(AAAI)论文集，第21527-21536页

259. Zhang Y, Ye L, Tian Z, Chen Z, Zhang H, Li B, Fang B (2024) UCTT: universal and low-cost adversarial example generation for tendency classification. Neural Comput Appl. https://doi.org/10.1007/s00521-024-09760-5

259. Zhang Y, Ye L, Tian Z, Chen Z, Zhang H, Li B, Fang B (2024) UCTT:一种通用且低成本的偏向分类对抗样本生成方法。神经计算应用。https://doi.org/10.1007/s00521-024-09760-5

260. Mnassri K, Farahbakhsh R, Crespi N (2024) Multilingual hate speech detection: a semi-supervised generative adversarial approach. Entropy 26(4):344

260. Mnassri K, Farahbakhsh R, Crespi N (2024) 多语言仇恨言论检测:一种半监督生成对抗方法。熵 26(4):344

261. Wu X, Zhao H, Zhu Y, Shi Y, Yang F, Liu T, Zhai X, Yao W, Li J, Du M et al (2024) Usable XAI: 10 strategies towards exploiting explainability in the LLM era. arXiv preprint arXiv:2403.08946

261. Wu X, Zhao H, Zhu Y, Shi Y, Yang F, Liu T, Zhai X, Yao W, Li J, Du M 等 (2024) 可用的可解释人工智能(XAI):在大模型(LLM)时代利用可解释性的10种策略。arXiv预印本 arXiv:2403.08946

Publisher's Note Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations.

出版者声明:Springer Nature在已发表地图和机构隶属关系中的管辖权声明方面保持中立。

Springer Nature or its licensor (e.g. a society or other partner) holds exclusive rights to this article under a publishing agreement with the author(s) or other rightsholder(s); author self-archiving of the accepted manuscript version of this article is solely governed by the terms of such publishing agreement and applicable law.

Springer Nature或其许可方(例如学会或其他合作伙伴)根据与作者或其他权利持有人签订的出版协议拥有本篇文章的专属权利；作者自行存档本文章的已接受手稿版本仅受此类出版协议和适用法律的约束。