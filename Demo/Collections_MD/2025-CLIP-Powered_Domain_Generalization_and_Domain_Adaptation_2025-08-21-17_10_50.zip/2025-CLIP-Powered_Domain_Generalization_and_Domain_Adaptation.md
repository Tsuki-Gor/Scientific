# CLIP-Powered Domain Generalization and Domain Adaptation: A Comprehensive Survey

# 基于CLIP的领域泛化与领域自适应:全面综述

Jindong Li, Yongguang Li, Yali Fu, Jiahong Liu, Yixin Liu, Menglin Yang*, Irwin King Fellow, IEEE

李劲东，李永光，付雅丽，刘家宏，刘一心，杨梦麟*，IEEE会士，欧文·金

Abstract-As machine learning evolves, domain generalization (DG) and domain adaptation (DA) have become crucial for enhancing model robustness across diverse environments. Contrastive Language-Image Pretraining (CLIP) plays a significant role in these tasks, offering powerful zero-shot capabilities that allow models to perform effectively in unseen domains. However, there remains a significant gap in the literature, as no comprehensive survey currently exists that systematically explores the applications of CLIP in DG and DA, highlighting the necessity for this review. This survey presents a comprehensive review of CLIP’s applications in DG and DA. In DG, we categorize methods into optimizing prompt learning for task alignment and leveraging CLIP as a backbone for effective feature extraction, both enhancing model adaptability. For DA, we examine both source-available methods utilizing labeled source data and source-free approaches primarily based on target domain data, emphasizing knowledge transfer mechanisms and strategies for improved performance across diverse contexts. Key challenges, including overfitting, domain diversity, and computational efficiency, are addressed, alongside future research opportunities to advance robustness and efficiency in practical applications. By synthesizing existing literature and pinpointing critical gaps, this survey provides valuable insights for researchers and practitioners, proposing directions for effectively leveraging CLIP to enhance methodologies in domain generalization and adaptation. Ultimately, this work aims to foster innovation and collaboration in the quest for more resilient machine learning models that can perform reliably across diverse real-world scenarios. A more up-to-date version of the papers is maintained at:

摘要——随着机器学习的发展，领域泛化(Domain Generalization, DG)和领域自适应(Domain Adaptation, DA)已成为提升模型在多样环境中鲁棒性的关键。对比语言-图像预训练(Contrastive Language-Image Pretraining, CLIP)在这些任务中发挥了重要作用，提供了强大的零样本能力，使模型能在未见领域中有效运行。然而，现有文献中尚缺乏系统探讨CLIP在DG和DA中应用的综合综述，凸显了本综述的必要性。本文全面回顾了CLIP在DG和DA中的应用。在DG方面，我们将方法分为优化提示学习以实现任务对齐和利用CLIP作为骨干网络进行有效特征提取，两者均提升了模型的适应性。对于DA，我们考察了利用带标签源数据的源可用方法和主要基于目标域数据的无源方法，重点分析知识迁移机制及提升多样环境下性能的策略。文中还讨论了过拟合、领域多样性和计算效率等关键挑战，并展望了未来提升实际应用中鲁棒性与效率的研究方向。通过整合现有文献并指出关键空白，本综述为研究者和实践者提供了宝贵见解，提出了有效利用CLIP提升领域泛化与自适应方法的方向。最终，本文旨在促进创新与合作，推动构建能在多样真实场景中可靠运行的更具鲁棒性的机器学习模型。最新版本论文维护于:

https://github.com/jindongli-Ai/Survey_on_CLIP-Powered_Domain_Generalization_and_Adaptation.

Index Terms—Vision-Language Model (VLM), CLIP-Powered, Domain Generalization (DG), Domain Adaptation (DA).

关键词——视觉语言模型(Vision-Language Model, VLM)，基于CLIP，领域泛化(DG)，领域自适应(DA)。

## 1 INTRODUCTION

## 1 引言

AS machine learning progresses, domain generalization (DG) and domain adaptation (DA) have emerged as pivotal areas of research aimed at enhancing model robustness across diverse environments $\left\lbrack  {{85},{93}}\right\rbrack$ . Traditional models often rely on extensive labeled data, which can be challenging to obtain due to factors such as time, cost, and privacy concerns. Moreover, the scarcity of labeled datasets, combined with distribution discrepancies between source and target domains, significantly impedes the generalization capabilities of a model. These challenges highlight the urgent need for robust techniques that can adapt to unseen domains or variations in data distribution. Therefore, developing effective DG and DA methods is crucial for a wide array of applications, particularly in fields like healthcare, autonomous driving, and social media, where models must perform reliably in dynamic and unpredictable environments.

随着机器学习的进步，领域泛化(DG)和领域自适应(DA)已成为提升模型在多样环境中鲁棒性的关键研究领域$\left\lbrack  {{85},{93}}\right\rbrack$。传统模型通常依赖大量标注数据，但由于时间、成本和隐私等因素，获取这些数据存在较大挑战。此外，标注数据的稀缺性及源域与目标域之间的分布差异，严重制约了模型的泛化能力。这些挑战凸显了开发能够适应未见领域或数据分布变化的鲁棒技术的紧迫性。因此，开发有效的DG和DA方法对于医疗、自动驾驶和社交媒体等需在动态且不可预测环境中可靠运行的应用尤为重要。

Inspired by earlier works such as VirTex [33] and ICMLM [134], which demonstrated the potential of transformer-based language modeling, masked language modeling, and contrastive objectives for learning image representations from text, the architecture of CLIP employs a contrastive learning framework. By leveraging a large-scale dataset that pairs 400 million images with textual descriptions, CLIP learns rich, multi-modal representations that align similar image-text pairs while distinguishing dissimilar ones. This dual processing captures intricate relationships between visual and linguistic information, significantly bolstering the model's robustness in handling variations in input data. Additionally, CLIP supports flexible task adaptation through prompting $\left\lbrack  {{47},{98},{135}}\right\rbrack$ , enabling nuanced interpretations of visual data based on contextual language cues. As illustrated in Fig. 1, these features make CLIP particularly effective for domain generalization (DG) and domain adaptation (DA). The powerful zero-shot capabilities of CLIP allow models to operate effectively in previously unseen domains without additional training on specific datasets. This adaptability enables CLIP to generalize across tasks-ranging from image classification to object detection-without requiring task-specific fine-tuning. Such versatility not only transforms the DG and DA research landscape but also alters the way problems are conceptualized and addressed in the machine learning community. CLIP's ability to handle domain shifts and transfer knowledge efficiently underscores its transformative potential in enhancing model performance across various domains.

受早期工作如VirTex [33]和ICMLM [134]的启发，这些工作展示了基于Transformer的语言建模、掩码语言建模及对比目标在从文本学习图像表示中的潜力，CLIP架构采用了对比学习框架。通过利用包含4亿张图像及其文本描述的大规模数据集，CLIP学习了丰富的多模态表示，能够对相似的图文对进行对齐，同时区分不相似的对。这种双重处理捕捉了视觉与语言信息间的复杂关系，显著增强了模型处理输入数据变化的鲁棒性。此外，CLIP支持通过提示(prompting)实现灵活的任务适应$\left\lbrack  {{47},{98},{135}}\right\rbrack$，基于上下文语言线索对视觉数据进行细致解读。如图1所示，这些特性使CLIP在领域泛化(DG)和领域自适应(DA)中表现尤为出色。CLIP强大的零样本能力使模型能在未见领域中无需额外特定数据训练即可有效运行。这种适应性使CLIP能够跨任务泛化——从图像分类到目标检测——无需任务特定的微调。这种多功能性不仅改变了DG和DA的研究格局，也改变了机器学习社区对问题的概念化和解决方式。CLIP处理领域转移和高效知识迁移的能力凸显了其在提升各领域模型性能方面的变革潜力。

![bo_d282qmv7aajc738ormjg_0_912_1112_741_394_0.jpg](images/bo_d282qmv7aajc738ormjg_0_912_1112_741_394_0.jpg)

Fig. 1. The characteristics of CLIP and its perfect fit for Domain Generalization (DG) and Domain Adaptation (DA).

图1. CLIP的特性及其与领域泛化(DG)和领域自适应(DA)的完美契合。

---

- Jindong Li and Menglin Yang are with The Hong Kong University of Science and Technology (Guangzhou), Guangzhou, China. E-mail: jli839@connect.hkust-gz.edu.cn, menglinyang@hkust-gz.edu.cn.

- 李劲东和杨梦麟供职于中国广州香港科技大学(广州)。电子邮件:jli839@connect.hkust-gz.edu.cn，menglinyang@hkust-gz.edu.cn。

- Yongguang Li and Yali Fu are with The Jilin University, Changchun, China. E-mail: \{liyg22, fuyl23\}@mails.jlu.edu.cn.

- 李永光和付雅丽供职于中国长春吉林大学。电子邮件:\{liyg22, fuyl23\}@mails.jlu.edu.cn。

- Yixin Liu is with Griffith University, Queensland, Australia. E-mail: Yixin.liu@griffith.edu.au.

- 刘一心供职于澳大利亚昆士兰格里菲斯大学。电子邮件:Yixin.liu@griffith.edu.au。

- Jiahong Liu and Irwin King are with The Chinese University of Hong Kong, Hong Kong, China. E-mail: jiahong.liu21@gmail.com, king@cse.cuhk.edu.hk.

- 刘家宏和Irwin King隶属于中国香港中文大学，香港，中国。电子邮件:jiahong.liu21@gmail.com，king@cse.cuhk.edu.hk。

- *: Corresponding author.

- *:通讯作者。

Manuscript received xxx xx, 20xx; revised xxxx xx, 20xx.

稿件收到日期:xxxx年xx月xx日；修订日期:xxxx年xx月xx日。

---

![bo_d282qmv7aajc738ormjg_1_148_106_1502_1225_0.jpg](images/bo_d282qmv7aajc738ormjg_1_148_106_1502_1225_0.jpg)

Fig. 2. Structure of this paper with representative works.

图2. 本文结构及代表性工作。

Given its remarkable suitability for DG and DA tasks, CLIP has garnered increasing attention in recent years. Researchers have actively explored CLIP-powered methods, proposing innovative approaches to address domain shifts and enhance cross-domain performance. As illustrated in Fig. 3, the number of works leveraging CLIP for DG and DA has surged rapidly, reflecting its growing prominence in the field. This trend underscores the importance of systematically understanding and categorizing these methodologies to fully unlock the potential of CLIP in domain generalization and adaptation.

鉴于CLIP在域泛化(DG)和域适应(DA)任务中的显著适用性，近年来其受到了越来越多的关注。研究人员积极探索基于CLIP的方法，提出创新方案以应对域偏移并提升跨域性能。如图3所示，利用CLIP进行DG和DA的相关工作数量迅速增长，反映了其在该领域日益重要的地位。这一趋势强调了系统理解和分类这些方法的重要性，以充分挖掘CLIP在域泛化和适应中的潜力。

While some surveys $\left\lbrack  {{85},{93}}\right\rbrack$ have explored domain generalization and adaptation broadly, none have specifically addressed the unique contributions and applications of CLIP-powered methods. This gap limits understanding of how CLIP can be effectively utilized within these frameworks and underscores the necessity for a comprehensive analysis of its capabilities and the methodologies that leverage its strengths in DG and DA. By synthesizing existing literature, this survey addresses the knowledge gap, analyzing key methodologies and identifying best practices for utilizing CLIP in domain generalization and adaptation. This comprehensive review helps researchers navigate the field and serves as a resource for practitioners applying these methods in real-world scenarios. The paper structure is shown in Fig. 2.

虽然已有一些综述$\left\lbrack  {{85},{93}}\right\rbrack$广泛探讨了域泛化和域适应，但尚无专门针对基于CLIP方法的独特贡献和应用进行分析的文献。这一空白限制了对CLIP在这些框架中有效利用方式的理解，凸显了对其能力及相关方法进行全面分析的必要性。通过整合现有文献，本综述填补了这一知识空白，分析了关键方法并识别了利用CLIP进行域泛化和适应的最佳实践。该综述有助于研究人员理清该领域脉络，并为实际应用这些方法的从业者提供参考。论文结构如图2所示。

The significance of this survey lies in its broad coverage and ability to guide researchers in selecting strategies tailored to their needs. By showcasing CLIP's capabilities-such as multi-modal learning, adaptability, and zero-shot performance-we provide insights to enhance its effectiveness. We also tackle challenges like overfitting, domain shifts, and labeled data scarcity, offering solutions based on proven techniques and innovative approaches. This guidance will help researchers navigate the complexities of CLIP-powered domain generalization and adaptation.

本综述的重要性在于其广泛覆盖面及指导研究人员选择适合自身需求策略的能力。通过展示CLIP的多模态学习、适应性和零样本性能等能力，我们提供了提升其效能的见解。同时，我们也针对过拟合、域偏移和标注数据稀缺等挑战，基于成熟技术和创新方法提出了解决方案。这些指导将帮助研究人员应对基于CLIP的域泛化和适应中的复杂问题。

![bo_d282qmv7aajc738ormjg_2_140_124_741_513_0.jpg](images/bo_d282qmv7aajc738ormjg_2_140_124_741_513_0.jpg)

Fig. 3. Roadmap (i.e. timeline) of CLIP-powered Domain Generalization (DG) and Domain Adaptation (DA).

图3. 基于CLIP的域泛化(DG)和域适应(DA)路线图(即时间线)。

Ultimately, this survey aims to deepen understanding of the research landscape and encourage further exploration of CLIP's potential in domain generalization and adaptation. By identifying research gaps and proposing future directions, we hope to stimulate collaboration and innovation in the field. The contributions of this survey could be summarized as follows:

最终，本综述旨在加深对该研究领域的理解，鼓励进一步探索CLIP在域泛化和适应中的潜力。通过识别研究空白并提出未来方向，我们希望促进该领域的合作与创新。本综述的贡献可总结如下:

- This survey provides the first comprehensive review focused on CLIP's applications in domain generalization (DG) and domain adaptation (DA). It systematically explores CLIP's unique advantages in multi-modal representation learning and illustrates its practical applicability through real-world use cases across diverse domains.

- 本综述首次系统回顾了CLIP在域泛化(DG)和域适应(DA)中的应用，系统探讨了CLIP在多模态表示学习中的独特优势，并通过跨领域的实际案例展示了其实际适用性。

- We delve into how CLIP enhances generalization, particularly in zero-shot settings, and compare a range of domain adaptation methods, including both source-available and source-free approaches. Through detailed case studies, we evaluate their effectiveness and provide actionable insights into leveraging CLIP for domain-specific tasks.

- 我们深入分析了CLIP如何提升泛化能力，特别是在零样本设置下，并比较了多种域适应方法，包括源数据可用和无源数据方法。通过详细案例研究，评估其效果并提供了利用CLIP完成特定域任务的可操作见解。

- We offer an in-depth overview of datasets and evaluation metrics commonly used in DG and DA research, encompassing single-domain and multi-domain scenarios. This section aims to guide researchers in selecting appropriate benchmarks and metrics to evaluate CLIP-based models effectively across various domain shifts.

- 我们全面介绍了域泛化和域适应研究中常用的数据集和评估指标，涵盖单域和多域场景。本节旨在指导研究人员选择合适的基准和指标，以有效评估基于CLIP的模型在不同域偏移下的表现。

- By identifying key challenges such as overfitting and domain shifts, we shed light on the limitations of CLIP-powered models. Additionally, we propose future research directions that focus on leveraging CLIP's potential to overcome these challenges and explore innovative solutions.

- 通过识别过拟合和域偏移等关键挑战，我们揭示了基于CLIP模型的局限性。此外，提出了未来研究方向，聚焦于发挥CLIP潜力以克服这些挑战并探索创新解决方案。

## 2 PRELIMINARIES

## 2 基础知识

This section presents the foundational concepts and terminology essential for understanding the subsequent discussions on domain generalization and adaptation. It encompasses notations and definitions that frame the context of the research, facilitating a comprehensive exploration of the proposed methodologies.

本节介绍理解后续域泛化和适应讨论所必需的基础概念和术语，涵盖了研究背景的符号和定义，便于全面探讨所提出的方法。

![bo_d282qmv7aajc738ormjg_2_918_104_746_312_0.jpg](images/bo_d282qmv7aajc738ormjg_2_918_104_746_312_0.jpg)

Fig. 4. Comparison of domain generalization (DG) and domain adaptation (DA).

图4. 域泛化(DG)与域适应(DA)比较。

### 2.1 Notations

### 2.1 符号说明

In this paper, we use the notations which are shown in Table 1.

本文中，我们使用表1所示的符号。

### 2.2 Definitions

### 2.2 定义

We provide formal definitions for key concepts related to domain adaptation and generalization. These definitions establish the foundational terminology used throughout the paper, enabling a clearer understanding of the methodologies and their contexts.

我们为与领域适应(domain adaptation)和领域泛化(domain generalization)相关的关键概念提供正式定义。这些定义奠定了全文使用的基础术语，有助于更清晰地理解方法及其应用背景。

#### 2.2.1 Problem Definition

#### 2.2.1 问题定义

Domain Generalization (DG) and Domain Adaptation (DA) are both techniques aimed at improving model performance across different data distributions. As show in Fig. 4, DG focuses on training a model using one or multiple source domains to ensure it generalizes well to unseen target domains. In contrast, DA involves training a model on a labeled source domain and adapting it to a target domain, which is typically unlabeled. While both approaches address challenges related to domain shifts, DG emphasizes generalization capabilities, whereas DA concentrates on adapting to specific target conditions.

领域泛化(DG)和领域适应(DA)均旨在提升模型在不同数据分布上的表现。如图4所示，DG侧重于利用一个或多个源领域训练模型，以确保其能在未见过的目标领域上良好泛化。相比之下，DA则是在有标签的源领域上训练模型，并将其适应到通常无标签的目标领域。两者均应对领域偏移带来的挑战，但DG强调泛化能力，而DA则专注于适应特定目标条件。

Definition 1. Domain Generalization (DG). Domain generalization refers to methods designed to train a model $f$ on multiple source domains ${D}_{s} = \left\{  {{D}_{1},{D}_{2},\cdots ,{D}_{S}}\right\}$ . The objective is to enable the model to generalize well when evaluated on unseen target domains ${D}_{t} = \left\{  {{D}_{1},{D}_{2},\cdots ,{D}_{T}}\right\}$ . This process is critical for ensuring that the model can maintain its performance across diverse and variable conditions, rather than just excelling on the specific datasets it was trained on.

定义1. 领域泛化(DG)。领域泛化指的是旨在在多个源领域$f$上训练模型${D}_{s} = \left\{  {{D}_{1},{D}_{2},\cdots ,{D}_{S}}\right\}$的方法。其目标是使模型在未见过的目标领域${D}_{t} = \left\{  {{D}_{1},{D}_{2},\cdots ,{D}_{T}}\right\}$上也能良好泛化。该过程对于确保模型在多样且变化的条件下维持性能至关重要，而不仅仅是在其训练的数据集上表现优异。

TABLE 1

Notations and Descriptions.

符号及说明。

<table><tr><td>Notation</td><td>Description</td></tr><tr><td>$f : {\mathbb{R}}^{H \times  W} \mapsto  {\mathbb{R}}^{C}$</td><td>Mapping function from image space to class space.</td></tr><tr><td>${D}_{s} = \left\{  {{D}_{1},{D}_{2},\ldots ,{D}_{S}}\right\}$</td><td>Set of multiple source domains.</td></tr><tr><td>${D}_{t} = \left\{  {{D}_{1},{D}_{2},\ldots ,{D}_{T}}\right\}$</td><td>Set of unseen target domains.</td></tr><tr><td>${D}_{K} = {\left\{  \left( {x}_{i},{y}_{i}\right) \right\}  }_{i = 1}^{N}$</td><td>Dataset of domain $K$ with $N$ samples, where ${x}_{i}$ is the input and ${y}_{i}$ is the label.</td></tr><tr><td>${\mathcal{X}}_{K} \in  {\mathbb{R}}^{H \times  W}$</td><td>Input image space of domain $K$ .</td></tr><tr><td>${\mathcal{Y}}_{s} \in  {\mathbb{R}}^{{C}_{s}},{\mathcal{Y}}_{t} \in  {\mathbb{R}}^{{C}_{t}}$</td><td>Label spaces of the source and target domains.</td></tr><tr><td>$C$</td><td>Number of classes in the label space.</td></tr></table>

<table><tbody><tr><td>符号表示</td><td>描述</td></tr><tr><td>$f : {\mathbb{R}}^{H \times  W} \mapsto  {\mathbb{R}}^{C}$</td><td>从图像空间到类别空间的映射函数。</td></tr><tr><td>${D}_{s} = \left\{  {{D}_{1},{D}_{2},\ldots ,{D}_{S}}\right\}$</td><td>多个源域的集合。</td></tr><tr><td>${D}_{t} = \left\{  {{D}_{1},{D}_{2},\ldots ,{D}_{T}}\right\}$</td><td>未见目标域的集合。</td></tr><tr><td>${D}_{K} = {\left\{  \left( {x}_{i},{y}_{i}\right) \right\}  }_{i = 1}^{N}$</td><td>域$K$的数据集，包含$N$个样本，其中${x}_{i}$为输入，${y}_{i}$为标签。</td></tr><tr><td>${\mathcal{X}}_{K} \in  {\mathbb{R}}^{H \times  W}$</td><td>域$K$的输入图像空间。</td></tr><tr><td>${\mathcal{Y}}_{s} \in  {\mathbb{R}}^{{C}_{s}},{\mathcal{Y}}_{t} \in  {\mathbb{R}}^{{C}_{t}}$</td><td>源域和目标域的标签空间。</td></tr><tr><td>$C$</td><td>标签空间中的类别数。</td></tr></tbody></table>

![bo_d282qmv7aajc738ormjg_3_132_114_749_316_0.jpg](images/bo_d282qmv7aajc738ormjg_3_132_114_749_316_0.jpg)

Fig. 5. Comparison of single-source (SS) and multi-source (MS) scenario.

图5. 单源(SS)与多源(MS)场景比较。

Definition 2. Domain Adaptation (DA). Domain adaptation involves training a model $f$ on a labeled source domain ${D}_{s} =$ ${\left\{  \left( {x}_{i},{y}_{i}\right) \right\}  }_{i = 1}^{{N}_{s}}$ and subsequently adapting it to a target domain ${D}_{t} = {\left\{  {x}_{j}\right\}  }_{j = 1}^{{N}_{t}}$ . In this context, the source domain consists of labeled samples, while the target domain is generally unlabeled or contains only sparse labeled data. This flexibility allows the model to adapt its learned representations to perform effectively in the target domain, despite potential differences in data distribution.

定义2. 领域自适应(Domain Adaptation, DA)。领域自适应涉及在带标签的源领域$f$上训练模型${D}_{s} =$${\left\{  \left( {x}_{i},{y}_{i}\right) \right\}  }_{i = 1}^{{N}_{s}}$，随后将其适配到目标领域${D}_{t} = {\left\{  {x}_{j}\right\}  }_{j = 1}^{{N}_{t}}$。在此背景下，源领域包含带标签样本，而目标领域通常无标签或仅含少量标签数据。此灵活性使模型能够调整其学习到的表示，以在目标领域中有效运行，尽管数据分布可能存在差异。

#### 2.2.2 Different Scenarios about Availability of Source Infor- mation

#### 2.2.2 关于源信息可用性的不同场景

Source-Available (SA) scenarios provide labeled data from the source domain to enhance adaptation in the target domain and are further divided into Single-Source (SS) and Multi-Source (MS) methods, as shown in Fig. 5. SS focuses on transferring knowledge from one labeled source domain, while MS leverages information from multiple labeled source domains for improved adaptation. As illustrated in Fig. 6, within Source-Free (SF), there are two subcategories: Source-Data-Free (SDF) allows for extracting knowledge from the source model without direct access to labeled source data, facilitating some adaptation. In contrast, Source-Fully-Free (SFF) prohibits any information from the source domain, requiring the model to rely solely on target data, which significantly increases adaptation challenges. Their specific definitions are as follows:

源可用(Source-Available, SA)场景提供来自源领域的带标签数据以增强目标领域的适应性，进一步分为单源(SS)和多源(MS)方法，如图5所示。单源侧重于从一个带标签的源领域转移知识，而多源则利用多个带标签源领域的信息以提升适应效果。如图6所示，在无源(Source-Free, SF)场景中，有两个子类别:无源数据(Source-Data-Free, SDF)允许在无直接访问带标签源数据的情况下，从源模型中提取知识以实现一定程度的适应；而完全无源(Source-Fully-Free, SFF)则禁止任何源领域信息，要求模型仅依赖目标数据，极大增加了适应难度。其具体定义如下:

Definition 3. Source-Available (SA). Source-available refers to scenarios in which labeled data from the source domain ${D}_{s}$ is accessible for adaptation. This availability facilitates the transfer of knowledge gained from the source domain to improve performance in the target domain ${D}_{t}$ .

定义3. 源可用(Source-Available, SA)。源可用指在适应过程中可访问源领域${D}_{s}$的带标签数据。此可用性促进了从源领域获得的知识向目标领域${D}_{t}$的迁移，以提升性能。

Definition 3.1. Single-Source (SS). Single-source-based methods are specifically designed to tackle shifts in data distribution by enabling the transfer of knowledge from a labeled source domain ${D}_{s}$ to the target domain ${D}_{t}$ .

定义3.1. 单源(Single-Source, SS)。基于单源的方法专门设计用于应对数据分布的变化，通过实现从带标签源领域${D}_{s}$向目标领域${D}_{t}$的知识转移。

Definition 3.2. Multi-Source (MS). Multi-source-based methods employ strategies to address shifts in data distribution by facilitating the transfer of knowledge from multiple labeled source domains ${D}_{s} = \left\{  {{D}_{1},{D}_{2},\cdots ,{D}_{S}}\right\}$ to the target domain ${D}_{t}$ .

定义3.2. 多源(Multi-Source, MS)。基于多源的方法采用策略应对数据分布变化，通过促进从多个带标签源领域${D}_{s} = \left\{  {{D}_{1},{D}_{2},\cdots ,{D}_{S}}\right\}$向目标领域${D}_{t}$的知识转移。

Definition 4. Source-Data-Free (SDF). Source-data-free refers to a setting in which no data from the source domain ${D}_{s}$ are accessible during adaptation. Instead, only a model pre-trained on the source domain is available. The adaptation process must therefore be carried out using only the unlabeled target domain data ${D}_{t}$ , which calls for effective knowledge transfer without direct access to source data.

定义4. 无源数据(Source-Data-Free, SDF)。无源数据指在适应过程中无法访问任何源领域${D}_{s}$数据，仅可使用在源领域预训练的模型。适应过程必须仅依赖无标签目标领域数据${D}_{t}$，这要求在无直接源数据访问的情况下实现有效的知识转移。

![bo_d282qmv7aajc738ormjg_3_912_111_752_337_0.jpg](images/bo_d282qmv7aajc738ormjg_3_912_111_752_337_0.jpg)

Fig. 6. Comparison of source-data-free (SDF) and source-fully-free (SFF). (Take single-source scenario as an example.)

图6. 无源数据(SDF)与完全无源(SFF)比较。(以单源场景为例。)

Definition 5. Source-Fully-Free (SFF). SFF denotes a strict setting where the source domain ${D}_{s}$ does not exist. Instead, models rely solely on a pre-trained foundation model (e.g., CLIP) and perform adaptation directly on the unlabeled target domain ${D}_{t}$ , without any supervision or auxiliary data from ${D}_{s}$ .

定义5. 完全无源(Source-Fully-Free, SFF)。SFF指严格的设置，源领域${D}_{s}$不存在。模型仅依赖预训练基础模型(如CLIP)，并直接在无标签目标领域${D}_{t}$上进行适应，且无任何来自${D}_{s}$的监督或辅助数据。

#### 2.2.3 Different Scenarios about Connection between the Source Domain and the Target Domain

#### 2.2.3 关于源领域与目标领域连接的不同场景

As shown in Fig. 7, there are 4 relationship types that describe the connection between the source domain and the target domain: closed-set, partial-set, open-set, and open-partial-set scenarios. In the closed-set scenario, the source and target domains share an identical set of categories, and the model only needs to focus on minimizing the distribution discrepancy between the two domains. In the partial-set scenario, the target domain contains a subset of the source domain's categories, requiring the model not only to align the shared classes but also to prevent target samples from being misclassified into source-private classes. In the open-set scenario, the target domain includes novel categories not present in the source domain, and the model must identify these unknown classes and group them accordingly. In the open-partial-set scenario, both domains share some categories while also having their own private ones, posing a more complex challenge where the model must align shared categories and isolate private ones to handle severe category shift. Their specific definitions are as follows:

如图7所示，描述源领域与目标领域连接的关系类型有4种:闭集、部分集、开集和开部分集场景。在闭集场景中，源领域与目标领域共享完全相同的类别集合，模型只需关注最小化两域间的分布差异。在部分集场景中，目标领域包含源领域类别的子集，模型不仅需对齐共享类别，还需防止目标样本被误分类到源领域特有类别。在开集场景中，目标领域包含源领域不存在的新类别，模型必须识别这些未知类别并进行归类。在开部分集场景中，两域既共享部分类别又各自拥有私有类别，挑战更为复杂，模型需对齐共享类别并隔离私有类别，以应对严重的类别偏移。其具体定义如下:

Definition 6. Closed-Set (CS). Closed-set scenarios refer to situations where the label space of the target domain ${\mathcal{Y}}_{t}$ is exactly the same as that of the source domain ${\mathcal{Y}}_{s}$ , such that ${\mathcal{Y}}_{t} = {\mathcal{Y}}_{s}$ .

定义6. 闭集(Closed-Set，CS)。闭集场景指目标域的标签空间${\mathcal{Y}}_{t}$与源域的标签空间${\mathcal{Y}}_{s}$完全相同的情况，即${\mathcal{Y}}_{t} = {\mathcal{Y}}_{s}$。

Definition 7. Partial-Set (PS). Partial-set scenarios involve situations where the label space of the target domain ${\mathcal{Y}}_{t}$ contains only a subset of classes from the source domain ${\mathcal{Y}}_{s}$ , such that ${\mathcal{Y}}_{t} \subset  {\mathcal{Y}}_{s}$ and ${\mathcal{Y}}_{s} \smallsetminus  {\mathcal{Y}}_{t} \neq  \varnothing$ .

定义7. 部分集(Partial-Set，PS)。部分集场景涉及目标域的标签空间${\mathcal{Y}}_{t}$仅包含源域标签空间${\mathcal{Y}}_{s}$的部分类别，即满足${\mathcal{Y}}_{t} \subset  {\mathcal{Y}}_{s}$且${\mathcal{Y}}_{s} \smallsetminus  {\mathcal{Y}}_{t} \neq  \varnothing$。

Definition 8. Open-Set (OS). Open-set scenarios encompass cases where the label space of the target domain ${\mathcal{Y}}_{t}$ completely includes the classes present in the source domain ${\mathcal{Y}}_{s}$ , such that ${\mathcal{Y}}_{t} \supset  {\mathcal{Y}}_{s}$ and ${\mathcal{Y}}_{t} \smallsetminus  {\mathcal{Y}}_{s} \neq  \varnothing$ .

定义8. 开集(Open-Set，OS)。开集场景涵盖目标域的标签空间${\mathcal{Y}}_{t}$完全包含源域标签空间${\mathcal{Y}}_{s}$中存在的类别，即满足${\mathcal{Y}}_{t} \supset  {\mathcal{Y}}_{s}$且${\mathcal{Y}}_{t} \smallsetminus  {\mathcal{Y}}_{s} \neq  \varnothing$。

Definition 9. Open-Partial-Set (OPS). Open-partial-set scenarios refer to situations where the label space of the target domain ${\mathcal{Y}}_{t}$ includes some classes from the label space of the source domain ${\mathcal{Y}}_{s}$ , such that ${\mathcal{Y}}_{s} \cap  {\mathcal{Y}}_{t} \neq  \varnothing ,{\mathcal{Y}}_{t} \nsubseteq  {\mathcal{Y}}_{s}$ , and ${\mathcal{Y}}_{s} \nsubseteq  {\mathcal{Y}}_{t}$ . This indicates that there are classes present in ${\mathcal{Y}}_{t}$ that are not in ${\mathcal{Y}}_{s}$ , while also having classes in ${\mathcal{Y}}_{s}$ that do not appear in ${\mathcal{Y}}_{t}$ .

定义9. 开部分集(Open-Partial-Set，OPS)。开部分集场景指目标域的标签空间${\mathcal{Y}}_{t}$包含源域标签空间${\mathcal{Y}}_{s}$中的部分类别，即满足${\mathcal{Y}}_{s} \cap  {\mathcal{Y}}_{t} \neq  \varnothing ,{\mathcal{Y}}_{t} \nsubseteq  {\mathcal{Y}}_{s}$，且${\mathcal{Y}}_{s} \nsubseteq  {\mathcal{Y}}_{t}$。这表明${\mathcal{Y}}_{t}$中存在不在${\mathcal{Y}}_{s}$中的类别，同时${\mathcal{Y}}_{s}$中也存在不出现在${\mathcal{Y}}_{t}$中的类别。

![bo_d282qmv7aajc738ormjg_4_134_116_751_271_0.jpg](images/bo_d282qmv7aajc738ormjg_4_134_116_751_271_0.jpg)

Fig. 7. Comparison of closed-set (CS), partial-set (PS), open-set scenarios (OS) and open-partial-set (OPS).

图7. 闭集(CS)、部分集(PS)、开集(OS)和开部分集(OPS)的比较。

#### 2.2.4 Contrastive Language-Image Pretraining (CLIP)

#### 2.2.4 对比语言-图像预训练(Contrastive Language-Image Pretraining，CLIP)

CLIP learns visual concepts by jointly training on images and their textual descriptions using contrastive learning, aligning images and text in a shared space, as shown in Fig. 8(a). This approach provides flexibility and strong generalization, particularly in zero-shot learning and domain adaptation tasks. The model is based on a transformer architecture and utilizes a contrastive loss function to align image and text embeddings, enabling it to perform well across different tasks and domains without requiring task-specific fine-tuning, with its zero-shot capability (as shown in Fig. 8(b)) allowing it to generalize to new tasks and domains directly from pre-trained models [127].

CLIP通过对图像及其文本描述进行联合训练，利用对比学习方法学习视觉概念，将图像和文本对齐到共享空间，如图8(a)所示。该方法具有灵活性和强大的泛化能力，尤其在零样本学习和领域适应任务中表现突出。该模型基于Transformer架构，采用对比损失函数对图像和文本嵌入进行对齐，使其能够在不同任务和领域中表现良好，无需针对特定任务进行微调，其零样本能力(如图8(b)所示)使其能够直接从预训练模型泛化到新的任务和领域[127]。

Definition 10. CLIP (Contrastive Language-Image Pretraining). Let $\mathcal{I} = \left\{  {{I}_{1},{I}_{2},\ldots ,{I}_{N}}\right\}$ represent a set of images, and $\mathcal{T} = \left\{  {{T}_{1},{T}_{2},\ldots ,{T}_{N}}\right\}$ represent a corresponding set of textual descriptions. CLIP learns a joint embedding space ${\mathbb{R}}^{d}$ by projecting images and their associated texts into this space. The model's objective is to maximize the similarity between paired image-text embeddings while minimizing the similarity between non-paired image-text embeddings. This is achieved using the contrastive loss function $\left\lbrack  {{18},{49},{53},{197}}\right\rbrack$ :

定义10. CLIP(对比语言-图像预训练)。设$\mathcal{I} = \left\{  {{I}_{1},{I}_{2},\ldots ,{I}_{N}}\right\}$为一组图像，$\mathcal{T} = \left\{  {{T}_{1},{T}_{2},\ldots ,{T}_{N}}\right\}$为对应的一组文本描述。CLIP通过将图像及其相关文本投影到一个联合嵌入空间${\mathbb{R}}^{d}$中进行学习。模型的目标是最大化配对图像-文本嵌入之间的相似度，同时最小化非配对图像-文本嵌入之间的相似度。该目标通过对比损失函数$\left\lbrack  {{18},{49},{53},{197}}\right\rbrack$实现:

$$
{\mathcal{L}}_{\text{contrastive }} =  - \frac{1}{N}\mathop{\sum }\limits_{{i = 1}}^{N}\log \frac{\exp \left( {{\mathbf{v}}_{i}^{\top }{\mathbf{t}}_{i}/\tau }\right) }{\mathop{\sum }\limits_{{j = 1}}^{N}\exp \left( {{\mathbf{v}}_{i}^{\top }{\mathbf{t}}_{j}/\tau }\right)  + \exp \left( {{\mathbf{v}}_{j}^{\top }{\mathbf{t}}_{i}/\tau }\right) },
$$

where ${\mathbf{v}}_{i} \in  {\mathbb{R}}^{d}$ and ${\mathbf{t}}_{i} \in  {\mathbb{R}}^{d}$ represent the image and text embeddings of the $i$ -th pair, and $\tau$ is a temperature scaling factor. The contrastive loss ensures that the image and its corresponding textual description are close in the embedding space, while non-paired items are pushed apart.

其中${\mathbf{v}}_{i} \in  {\mathbb{R}}^{d}$和${\mathbf{t}}_{i} \in  {\mathbb{R}}^{d}$分别表示第$i$对的图像和文本嵌入，$\tau$为温度缩放因子。对比损失确保图像及其对应的文本描述在嵌入空间中彼此接近，而非配对项则被推远。

## 3 DOMAIN GENERALIZATION (DG)

## 3 域泛化(Domain Generalization, DG)

Traditional (non-CLIP based) methods have been proposed to achieve domain generalization (DG) from the perspective of domain-invariant [48, 81, 105, 126, 137, 152], data augmentation [27, 67, 172, 201, 202], learning strategies [12, 21, 59, 84, 163, 196], and etc.

传统的(非基于CLIP)方法从域不变性[48, 81, 105, 126, 137, 152]、数据增强[27, 67, 172, 201, 202]、学习策略[12, 21, 59, 84, 163, 196]等角度提出了实现域泛化(DG)的方法。

CLIP-based domain generalization (DG) aims to develop models that generalize to unseen target domains using limited source data. By leveraging CLIP, these methods enhance robustness and adaptability, making them effective in scenarios with scarce target domain data.

基于CLIP的域泛化(DG)旨在利用有限的源域数据开发能够泛化到未见目标域的模型。通过利用CLIP，这些方法增强了模型的鲁棒性和适应性，使其在目标域数据稀缺的场景中表现出色。

### 3.1 Prompt Optimization Techniques

### 3.1 提示优化技术

Prompt optimization techniques focus on refining prompts in CLIP to improve task performance, as illustrated in Fig. 9. Recent approaches automate prompt tuning and enhance context representation, enabling more effective utilization of pre-trained models across diverse applications.

提示优化技术聚焦于精炼CLIP中的提示以提升任务性能，如图9所示。近期方法自动化提示调优并增强上下文表示，使预训练模型在多样化应用中得到更有效的利用。

![bo_d282qmv7aajc738ormjg_4_931_135_711_241_0.jpg](images/bo_d282qmv7aajc738ormjg_4_931_135_711_241_0.jpg)

Fig. 8. The illustration of the (a) training process of CLIP (taking 4 class names and 4 images as example) and (b) zero-shot ability of CLIP (taking 4 class names as example) [127].

图8. (a)CLIP的训练过程示意(以4个类别名称和4张图像为例)和(b)CLIP的零样本能力示意(以4个类别名称为例)[127]。

Zhou et al. [204] introduces Context Optimization (CoOp), a technique that eliminates manual prompt tuning by representing context words as continuous learnable vectors, while keeping the pre-trained parameters frozen. Building on prior work in prompting techniques $\lbrack {39},{63},{65}$ , ${90},{142},{145},{183},{199}\rbrack$ , CoOp defines two types of context: Unified Context for shared class contexts, and Class-Specific Context (CSC) for fine-grained classification tasks, tailoring prompts for individual class characteristics. Inspired by prompt learning in NLP [45, 82] and CV [66, 129, 178, 191], Zhou et al. [203] further develops Conditional Context Optimization (CoCoOp), using a lightweight neural network to generate input-conditional tokens for each image, enhancing parameter efficiency. Yao et al. [177] introduces Knowledge-guided Context Optimization (KgCoOp) to enhance the generalization of learnable prompts for unseen classes. Building on the widespread use of prompt tuning to adapt pre-trained models [42, 64, 123, 159], Kg-CoOp minimizes the gap between learned and hand-crafted prompts, preserving essential knowledge. By incorporating contrastive loss, it creates discriminative prompts effective for both seen and unseen tasks. Zhu et al. [206] introduces Prompt-aligned Gradient (ProGrad), which addresses overfitting by selectively updating prompts whose gradients align with general knowledge in vision-language models (VLMs). This alignment, based on pre-defined prompt predictions, reduces overfitting while preserving essential model knowledge and improving prompt tuning performance, outperforming existing approaches [45, 125, 203, 204]. Khattak et al. [70] introduces MaPLe, the first multimodal prompting framework for fine-tuning CLIP. It aligns vision and language modalities by coupling image and text prompts via a conditioning function, enabling joint optimization through cross-modal gradient propagation. Gao et al. [43] introduces LAMM, which uses trainable category tokens and optimizes $\langle$ CLASS $\rangle$ embeddings through gradient-based search. A hierarchical loss aligns representations across multiple spaces, improving generalization while maintaining CLIP's semantic consistency.

Zhou等人[204]提出了上下文优化(Context Optimization, CoOp)技术，通过将上下文词表示为连续可学习向量，消除了手动提示调优，同时保持预训练参数冻结。基于先前的提示技术研究$\lbrack {39},{63},{65}$，${90},{142},{145},{183},{199}\rbrack$，CoOp定义了两种上下文类型:用于共享类别上下文的统一上下文(Unified Context)和用于细粒度分类任务的类别特定上下文(Class-Specific Context, CSC)，针对各类别特征定制提示。受自然语言处理(NLP)[45, 82]和计算机视觉(CV)[66, 129, 178, 191]中提示学习的启发，Zhou等人[203]进一步发展了条件上下文优化(Conditional Context Optimization, CoCoOp)，利用轻量神经网络为每张图像生成输入条件化的标记，提高参数效率。Yao等人[177]提出了知识引导上下文优化(Knowledge-guided Context Optimization, KgCoOp)，以增强可学习提示对未见类别的泛化能力。基于广泛使用的提示调优适应预训练模型[42, 64, 123, 159]，KgCoOp最小化了学习提示与手工提示之间的差距，保留了关键知识。通过引入对比损失，它生成了对已见和未见任务均有效的判别性提示。Zhu等人[206]提出了提示对齐梯度(Prompt-aligned Gradient, ProGrad)，通过选择性更新与视觉语言模型(VLMs)中通用知识梯度一致的提示，解决了过拟合问题。该对齐基于预定义的提示预测，减少过拟合同时保留关键模型知识，提升提示调优性能，优于现有方法[45, 125, 203, 204]。Khattak等人[70]提出了MaPLe，这是首个用于微调CLIP的多模态提示框架。它通过条件函数耦合图像和文本提示，实现视觉和语言模态的对齐，并通过跨模态梯度传播实现联合优化。Gao等人[43]提出了LAMM，利用可训练的类别标记并通过基于梯度的搜索优化$\langle$类别$\rangle$嵌入。层次化损失对齐多个空间的表示，提升泛化能力，同时保持CLIP的语义一致性。

### 3.2 CLIP is Adopted as Backbone or Encoder

### 3.2 CLIP作为主干或编码器的应用

CLIP is commonly integrated as a backbone or encoder in domain generalization approaches, serving key roles in feature extraction and performance improvement. There are two primary adoption methods for CLIP, as illustrated in Fig. 10.

CLIP常被集成作为域泛化方法中的主干或编码器，承担特征提取和性能提升的关键角色。CLIP的两种主要应用方式如图10所示。

![bo_d282qmv7aajc738ormjg_5_234_115_554_260_0.jpg](images/bo_d282qmv7aajc738ormjg_5_234_115_554_260_0.jpg)

Fig. 9. The different ways about prompt learning optimization [43,70, 147, 203, 204].

图9. 提示学习优化的不同方式[43,70, 147, 203, 204]。

The first method, shown on the left of Fig. 10, involves training both CLIP Image and Text Encoders, often combined with task-specific architectures. This allows the model to adapt to downstream tasks and capture domain-specific patterns, enhancing generalization. The second method, shown on the right of Fig. 10, freezes the CLIP encoders, using them directly for embedding extraction. This approach leverages CLIP's pre-trained knowledge, offering computational efficiency and preventing overfitting, especially with limited training resources.

第一种方法，如图10左侧所示，涉及同时训练CLIP的图像和文本编码器，通常结合任务特定架构。这使模型能够适应下游任务并捕捉域特定模式，增强泛化能力。第二种方法，如图10右侧所示，冻结CLIP编码器，直接用于嵌入提取。该方法利用CLIP的预训练知识，提供计算效率并防止过拟合，尤其适用于训练资源有限的情况。

In both methods, CLIP serves as a flexible feature extractor, whether as a dynamic or static model, enhancing various domain generalization strategies by providing robust and semantically rich embeddings that facilitate effective cross-domain learning.

无论是动态还是静态模型，CLIP都作为灵活的特征提取器，通过提供鲁棒且语义丰富的嵌入，促进有效的跨域学习，增强各种域泛化策略。

#### 3.2.1 Source-Available (SA)

#### 3.2.1 可用源(Source-Available, SA)

This section further organizes source-available methods into single-source and multi-source categories, highlighting their respective methodological characteristics and summarizing typical representative works.

本节进一步将可用源方法划分为单源和多源类别，突出各自的方法特征并总结典型代表性工作。

3.2.1.1 Single-Source Closed-Set Domain Generalization (SS-CSDG): In ${SS}$ -CSDG, the model $f : {\mathbb{R}}^{H \times  W} \mapsto  {\mathbb{R}}^{C}$ is trained using labeled data from a single source domain ${D}_{s} =$ ${\left\{  \left( {x}_{i},{y}_{i}\right) \right\}  }_{i = 1}^{{N}_{s}}$ . The goal is to learn a mapping $f\left( x\right)$ that minimizes task loss on the source domain while maximizing generalization to unseen target domains ${D}_{t} = {\left\{  {x}_{j}\right\}  }_{j = 1}^{{N}_{t}}$ , where the label space of the target domain ${\mathcal{Y}}_{t}$ is identical to that of the source domain, i.e., ${\mathcal{Y}}_{t} = {\mathcal{Y}}_{s}.$

3.2.1.1 单源闭集域泛化(SS-CSDG):在${SS}$-CSDG中，模型$f : {\mathbb{R}}^{H \times  W} \mapsto  {\mathbb{R}}^{C}$使用来自单一源域的带标签数据进行训练${D}_{s} =$${\left\{  \left( {x}_{i},{y}_{i}\right) \right\}  }_{i = 1}^{{N}_{s}}$。目标是学习一个映射$f\left( x\right)$，在源域上最小化任务损失，同时最大化对未见目标域${D}_{t} = {\left\{  {x}_{j}\right\}  }_{j = 1}^{{N}_{t}}$的泛化能力，其中目标域的标签空间${\mathcal{Y}}_{t}$与源域相同，即${\mathcal{Y}}_{t} = {\mathcal{Y}}_{s}.$

SS-CSDG refers to the approach of training a model on a domain (or distribution) to generalize its performance on unseen target domains. Ma et al. [106] proposes BorLan, which uses pre-trained language models to align visual and linguistic features, helping the vision model learn semantic-aware, domain-agnostic representations. It is model-agnostic, supporting various visual and language backbones. Cho et al. [24] introduces DAPT, a prompt tuning method for few-shot learning that optimizes both textual and visual prompts to match the data distribution. Unlike traditional methods [4, 14, 64, 104, 138, 185], it uses inter- and intra-dispersion losses to guide the learning of diverse text embeddings and compact image em-beddings within each class. Khattak et al. [71] introduces PromptSRC, a self-regularization framework for prompt learning inspired by network regularization techniques $\left\lbrack  {{29},{61},{62},{80},{102},{150},{154},{168},{179},{184},{188}}\right\rbrack$ . It regularizes prompt learning through: (1) alignment with the frozen model, (2) self-ensembling of prompts, and (3) encouraging textual diversity to enhance visual-textual balance. This approach mitigates overfitting and preserves CLIP's generalization ability. Yang et al. [175] introduces the MultiModal Adapter (MMA) for vision-language models (VLMs) to improve alignment between text and vision representations, inspired by previous work on adapter methods [11, 17, 20, 44, 54, 55, 114, 151]. MMA aggregates features from both branches into a shared space for gradient communication, applying only to higher layers to balance discrimination and generalization. It finds higher layers contain more dataset-specific knowledge, while lower layers capture more generalizable information. Bose et al. [8] proposes StyLIP, a domain-unified prompt learning method that leverages CLIP's frozen vision encoder and lightweight projectors to extract multiscale style features, enhancing hierarchical domain knowledge and generalization. Bai et al. [6] reframes prompt learning from a generative view and proposes Soft Prompt Generation (SPG), which trains with domain-specific soft prompt labels and uses a generative model to produce instance-specific prompts for unseen domains during inference. Yan et al. [174] presents Language-Guided Diverse Feature Synthesis (LDFS), a method that improves CLIP fine-tuning by generating diverse domain features via text-guided instance-conditional augmentation. It incorporates a pairwise regularizer for feature coherence and uses stochastic text augmentation to bridge the modality gap $\left\lbrack  {{40},{72},{76},{120}}\right\rbrack$ . Lafon et al. [77] introduces Global-Local Prompts (GalLoP), a framework that integrates global and local visual features to create diverse prompts. Local prompts align with sparse image regions, enabling precise text-to-image matching for fine-grained semantics. It refines textual alignment of local visual features $\lbrack {15},{34},{111},{112}$ , 153, 200] using linear projection for few-shot learning. To enhance diversity, it combines global and localized prompts with a "prompt dropout" strategy [41, 150], and uses a multiscale approach to capture broader semantic details.

SS-CSDG指的是在一个域(或分布)上训练模型，以泛化其在未见目标域上的表现的方法。Ma等人[106]提出了BorLan，利用预训练语言模型对视觉和语言特征进行对齐，帮助视觉模型学习语义感知的域无关表示。该方法与模型无关，支持多种视觉和语言骨干网络。Cho等人[24]引入了DAPT，一种用于少样本学习的提示调优方法，优化文本和视觉提示以匹配数据分布。不同于传统方法[4,14,64,104,138,185]，它使用类间和类内分散损失引导多样化文本嵌入和紧凑图像嵌入的学习。Khattak等人[71]提出了PromptSRC，一种受网络正则化技术启发的提示学习自正则框架$\left\lbrack  {{29},{61},{62},{80},{102},{150},{154},{168},{179},{184},{188}}\right\rbrack$。该方法通过:(1)与冻结模型对齐，(2)提示自集成，(3)鼓励文本多样性以增强视觉-文本平衡，来正则化提示学习。此方法缓解了过拟合并保持了CLIP的泛化能力。Yang等人[175]提出了多模态适配器(MMA)用于视觉语言模型(VLMs)，以提升文本与视觉表示的对齐，灵感来自先前的适配器方法研究[11,17,20,44,54,55,114,151]。MMA将两个分支的特征聚合到共享空间以实现梯度通信，仅应用于较高层以平衡判别力和泛化能力。研究发现高层包含更多数据集特定知识，而低层捕获更具泛化性的特征。Bose等人[8]提出了StyLIP，一种域统一的提示学习方法，利用CLIP冻结的视觉编码器和轻量级投影器提取多尺度风格特征，增强层次化域知识和泛化能力。Bai等人[6]从生成视角重新定义提示学习，提出软提示生成(SPG)，通过域特定软提示标签训练，并使用生成模型在推理时为未见域生成实例特定提示。Yan等人[174]提出语言引导的多样特征合成(LDFS)，通过文本引导的实例条件增强生成多样域特征，提升CLIP微调效果。该方法引入成对正则项以保持特征一致性，并使用随机文本增强弥合模态差距$\left\lbrack  {{40},{72},{76},{120}}\right\rbrack$。Lafon等人[77]提出全局-局部提示(GalLoP)框架，融合全局与局部视觉特征以生成多样提示。局部提示与稀疏图像区域对齐，实现细粒度语义的精确文本-图像匹配。该方法通过线性投影细化局部视觉特征的文本对齐$\lbrack {15},{34},{111},{112}$，153,200]，并结合“提示丢弃”策略[41,150]及多尺度方法捕获更广泛的语义细节，以增强多样性。

![bo_d282qmv7aajc738ormjg_5_909_117_755_318_0.jpg](images/bo_d282qmv7aajc738ormjg_5_909_117_755_318_0.jpg)

Fig. 10. The illustration of (Left) CLIP as the backbone and the text encoder or image encoder is trainable, (Right) CLIP as the encoder and the parameters of text encoder and image encoder are frozen.

图10. (左)CLIP作为骨干，文本编码器或图像编码器可训练；(右)CLIP作为编码器，文本编码器和图像编码器参数被冻结。

3.2.1.2 Multi-Source Closed-Set Domain Generalization (MS-CSDG): In MS-CSDG, the model $f : {\mathbb{R}}^{H \times  W} \mapsto$ ${\mathbb{R}}^{C}$ is trained using labeled data from multiple source domains ${D}_{s} = \left\{  {{D}_{1},{D}_{2},\cdots ,{D}_{S}}\right\}$ , with each source domain ${D}_{i}$ having its own label space ${\mathcal{Y}}_{i}$ . The goal of MS-CSDG is to learn a robust model that can generalize effectively to unseen target domains ${D}_{t} = {\left\{  {x}_{j}\right\}  }_{j = 1}^{{N}_{t}}$ , where the label space of the target domain ${\mathcal{Y}}_{t}$ is identical to that of the source domains ${\mathcal{Y}}_{s}$ , such that ${\mathcal{Y}}_{t} = {\mathcal{Y}}_{s}$ .

3.2.1.2 多源闭集域泛化(MS-CSDG):在MS-CSDG中，模型$f : {\mathbb{R}}^{H \times  W} \mapsto$${\mathbb{R}}^{C}$使用来自多个源域的带标签数据进行训练${D}_{s} = \left\{  {{D}_{1},{D}_{2},\cdots ,{D}_{S}}\right\}$，每个源域${D}_{i}$拥有其独立的标签空间${\mathcal{Y}}_{i}$。MS-CSDG的目标是学习一个鲁棒模型，能够有效泛化到未见过的目标域${D}_{t} = {\left\{  {x}_{j}\right\}  }_{j = 1}^{{N}_{t}}$，其中目标域的标签空间${\mathcal{Y}}_{t}$与源域的标签空间${\mathcal{Y}}_{s}$完全相同，因而${\mathcal{Y}}_{t} = {\mathcal{Y}}_{s}$。

MS-CSDG trains a model on multiple source domains to improve generalization to unseen target domains. By integrating knowledge from various source domains, it ensures the model performs well across diverse data distributions, enabling effective transfer to target domains with the same labels but new distributions. Huang et al. [60] distills knowledge from a vision-language teacher by aligning student image features with teacher text features using absolute and relative distance losses for domain generalization. Zhang et al. [194] introduces Domain Prompt Learning (DPL), a lightweight method using a three-layer MLP prompt generator to improve accuracy while maintaining a small parameter size. Bose et al. [8] is also applicable in the context of MS-CSDG, demonstrating impressive performance across diverse source domains. Its ability to leverage multi-scale visual content effectively enhances generalization, making it a robust choice for addressing challenges in MS-DG scenarios. Cheng et al. [23] proposes a prompt tuning framework that disentangles text and visual prompts, enhancing generalization through domain-specific prototypes and invariant prediction fusion. Addepalli et al. [1] proposes VL2V-SD for text-guided self-distillation and VL2V-ADiP for black-box feature fusion, both enhancing OOD generalization. Bai et al. [6] applies to MS-CSDG by generating soft prompts from multiple source domains, enhancing the model's generalization to unseen domains. Xiao et al. [170] introduces Any-Shift Prompting, a framework that enhances CLIP's generalization using hierarchical prompts and a pseudo-shift mechanism, without additional training costs. Singha et al. [147] focuses on multi-source open-set domain generalization, treating closed-set DG as a special case. It demonstrates superior performance on MS-CSDG tasks compared to existing benchmarks. Xuan et al. [173] introduces Consistent Augmentation Learning (CAL), which enhances CLIP for domain generalization using CAFT during training and ETTA during inference for improved robustness. Qiao et al. [124] introduces Mixup-CLIPood, a robust domain generalization method for multimodal object recognition, using mix-up loss and larger vision-language backbones for enhanced generalization.

MS-CSDG通过在多个源域上训练模型，以提升对未见目标域的泛化能力。通过整合来自不同源域的知识，确保模型在多样化数据分布上表现良好，实现对具有相同标签但分布不同的目标域的有效迁移。Huang等[60]通过对齐学生图像特征与教师文本特征，利用绝对和相对距离损失从视觉-语言教师模型中蒸馏知识以实现域泛化。Zhang等[194]提出了域提示学习(Domain Prompt Learning, DPL)，这是一种轻量级方法，使用三层多层感知机(MLP)提示生成器，在保持参数量小的同时提升准确率。Bose等[8]的方法同样适用于MS-CSDG，展示了在多源域上的出色性能，其有效利用多尺度视觉内容的能力显著增强了泛化能力，是应对MS-DG场景挑战的稳健选择。Cheng等[23]提出了一个提示调优框架，解耦文本和视觉提示，通过域特定原型和不变预测融合提升泛化能力。Addepalli等[1]提出了VL2V-SD用于文本引导的自蒸馏，以及VL2V-ADiP用于黑盒特征融合，均增强了OOD泛化能力。Bai等[6]通过从多个源域生成软提示，提升模型对未见域的泛化能力，适用于MS-CSDG。Xiao等[170]引入了Any-Shift Prompting框架，利用分层提示和伪移位机制提升CLIP的泛化能力，且无需额外训练成本。Singha等[147]关注多源开集域泛化，将闭集DG视为特例，在MS-CSDG任务中表现优于现有基准。Xuan等[173]提出了一致性增强学习(Consistent Augmentation Learning, CAL)，通过训练时的CAFT和推理时的ETTA提升CLIP的域泛化鲁棒性。Qiao等[124]提出了Mixup-CLIPood，一种用于多模态目标识别的鲁棒域泛化方法，结合mix-up损失和更大规模的视觉-语言骨干网络以增强泛化能力。

3.2.1.3 Multi-Source Open-Set Domain Generalization (MS-OSDG): In MS-OSDG, the model $f : {\mathbb{R}}^{H \times  W} \mapsto  {\mathbb{R}}^{C}$ is trained using labeled data from multiple source domains ${D}_{s} = \left\{  {{D}_{1},{D}_{2},\cdots ,{D}_{S}}\right\}$ , each with its own label space ${\mathcal{Y}}_{i}$ . In MS-OSDG, the label space of the target domain ${\mathcal{Y}}_{t}$ is a superset of the label space of the source domains ${\mathcal{Y}}_{s}$ , such that ${\mathcal{Y}}_{t} \supset  {\mathcal{Y}}_{s}$ . The target domain ${D}_{t} = {\left\{  {x}_{j}\right\}  }_{j = 1}^{{N}_{t}}$ consists of unlabeled samples from a set of unseen classes.

3.2.1.3 多源开集域泛化(MS-OSDG):在MS-OSDG中，模型$f : {\mathbb{R}}^{H \times  W} \mapsto  {\mathbb{R}}^{C}$使用来自多个源域的带标签数据进行训练${D}_{s} = \left\{  {{D}_{1},{D}_{2},\cdots ,{D}_{S}}\right\}$，每个源域拥有其独立的标签空间${\mathcal{Y}}_{i}$。在MS-OSDG中，目标域的标签空间${\mathcal{Y}}_{t}$是源域标签空间的超集${\mathcal{Y}}_{s}$，因此${\mathcal{Y}}_{t} \supset  {\mathcal{Y}}_{s}$。目标域${D}_{t} = {\left\{  {x}_{j}\right\}  }_{j = 1}^{{N}_{t}}$包含来自一组未见类别的无标签样本。

The scene of MS-OSDG has relatively little exploration at present, and there are not many traditional methods [68, ${117},{143},{164}\rbrack$ either. The objective of MS-OSDG is to develop a model that can generalize to these new classes while leveraging the knowledge learned from the source domains. The model must handle not only domain shifts but also the introduction of new, unseen classes that are not present in the source domains.

MS-OSDG(多源开放域泛化)领域目前探索较少，传统方法[68, ${117},{143},{164}\rbrack$也不多。MS-OSDG的目标是开发一个能够泛化到这些新类别的模型，同时利用从源域学到的知识。该模型不仅要应对域间变化，还需处理源域中不存在的新、未见类别的引入。

Shu et al. [144] proposes CLIPood, which adapts CLIP to OOD settings via margin metric softmax with class-adaptive margins and a Beta-weighted ensemble of zero-shot and fine-tuned models. Singha et al. [147] introduces ODG-CLIP, leveraging the semantic capabilities of the vision-language model, CLIP, with three main innovations. First, it redefines open-domain generalization (ODG) as a multi-class classification task that includes both known and novel categories, using a unique prompt designed to identify unknown class samples. To train this prompt, it utilizes a stable diffusion model [131] with faster inference speed than existing text-to-image generation methods [118, 128, 133] to generate proxy images representing open classes. Second, it designs a style-aware prompt mechanism to learn domain-specific classification weights, enrich visual embed-dings with class-discriminative cues, and maintain semantic consistency across domains. Chen et al. [22] proposes Perturbation Distillation (PD) to transfer knowledge from VLMs to lightweight vision models, improving robustness via score, class, and instance perspectives. It also introduces the Hybrid Domain Generalization (HDG) benchmark and H2-CV metric for broader evaluation.

Shu等人[144]提出了CLIPood，通过带有类别自适应边界的边界度量softmax和零样本与微调模型的Beta加权集成，将CLIP适配到OOD(域外)设置。Singha等人[147]引入了ODG-CLIP，利用视觉语言模型CLIP的语义能力，提出三大创新。首先，将开放域泛化(ODG)重新定义为包含已知和新类别的多分类任务，使用专门设计的提示词识别未知类别样本。为训练该提示词，采用了推理速度快于现有文本到图像生成方法[118, 128, 133]的稳定扩散模型[131]生成代表开放类别的代理图像。其次，设计了风格感知提示机制，学习域特定的分类权重，丰富视觉嵌入的类别判别信息，并保持跨域语义一致性。Chen等人[22]提出了扰动蒸馏(PD)，将知识从视觉语言模型(VLMs)转移到轻量级视觉模型，从得分、类别和实例角度提升鲁棒性。同时引入了混合域泛化(HDG)基准和H2-CV指标以实现更广泛的评估。

#### 3.2.2 Source-Free (SF)

#### 3.2.2 无源(Source-Free，SF)

This section further organizes source-free methods into domain generalization (DG) approaches, highlighting their methodological characteristics and summarizing representative works.

本节进一步将无源方法归纳为域泛化(DG)方法，突出其方法特征并总结代表性工作。

3.2.2.1 Source-(Fully)-Free Domain Generalization (S(F)F-DG): In $S\left( F\right) F$ -DG, the model $f : {\mathbb{R}}^{H \times  W} \mapsto  {\mathbb{R}}^{C}$ is adapted to unseen target domains ${D}_{t} = {\left\{  {x}_{j}\right\}  }_{j = 1}^{{N}_{t}}$ without relying on any information from any source domains ${D}_{s}$ . In this context, models transfer to the target dataset either by learning domain-invariant feature representations through a domain bank [116], or by fine-tuning CLIP using category text features enriched with diverse style information [25, 156, 189].

3.2.2.1 无源(完全无源)域泛化(S(F)F-DG):在$S\left( F\right) F$-DG中，模型$f : {\mathbb{R}}^{H \times  W} \mapsto  {\mathbb{R}}^{C}$适应未见的目标域${D}_{t} = {\left\{  {x}_{j}\right\}  }_{j = 1}^{{N}_{t}}$，且不依赖任何源域信息${D}_{s}$。在此背景下，模型通过域库[116]学习域不变特征表示，或通过使用丰富多样风格信息的类别文本特征微调CLIP[25, 156, 189]，实现向目标数据集的迁移。

In practical applications, obtaining abundant source domain data is often challenging. SF-DG addresses this issue by enabling models to predict target domain samples without accessing source domain data during training. This approach enhances the model's adaptability and flexibility by focusing on knowledge generalization

在实际应用中，获取大量源域数据常常具有挑战性。SF-DG通过使模型在训练时无需访问源域数据即可预测目标域样本，解决了这一问题。该方法通过聚焦知识泛化，提升模型的适应性和灵活性。

Niu et al. [116] proposes a domain-unified prompt representation generator (DUPRG) to obtain a set of domain-unified text representations. By converting textual prompts into structured inputs using text encoding, the method achieves domain invariance during the training phase, thereby eliminating the necessity for extensive source domain data. Cho et al. [25] introduces the model Prompt-Styler, the first attempt to synthesize a variety of styles in a joint vision-language space via prompts, effectively tackling source-free domain generalization. This method emulates various distribution shifts by generating diverse styles through prompts, all without relying on any images. Tang et al. [156] presents Dynamic PromptStyler (DPStyler), which includes Style Generation and Style Removal modules to tackle these challenges. The Style Generation module updates all styles at each training epoch, while the Style Removal module mitigates variations in the encoder's output features that result from input styles. Zhang et al. [189] introduces PromptTA, a novel method that integrates a text adapter to address the challenging SF-DG task. This approach includes a style feature resampling module aimed at effectively capturing the distribution of style features, employing resampling techniques to ensure comprehensive coverage across various domains.

Niu等人[116]提出了域统一提示表示生成器(DUPRG)，通过文本编码将提示词转换为结构化输入，实现训练阶段的域不变性，从而无需大量源域数据。Cho等人[25]引入了Prompt-Styler模型，首次通过提示在联合视觉语言空间合成多样风格，有效应对无源域泛化。该方法通过提示生成多样风格，模拟各种分布变化，且不依赖任何图像。Tang等人[156]提出了动态PromptStyler(DPStyler)，包含风格生成和风格移除模块以应对挑战。风格生成模块在每个训练周期更新所有风格，风格移除模块减轻输入风格导致的编码器输出特征变化。Zhang等人[189]提出了PromptTA，一种结合文本适配器的新方法，针对挑战性的SF-DG任务。该方法包含风格特征重采样模块，旨在有效捕捉风格特征分布，利用重采样技术确保跨域的全面覆盖。

## 4 Domain Adaptation (DA)

## 4 域适应(DA)

Domain adaptation (DA) with CLIP-based methods aims to adapt models to target domains using a limited amount of labeled source data. These methods leverage CLIP's rich feature representations to minimize domain shifts and enhance model performance in new target domains, especially when labeled data in the target domain is scarce. In this section, we organize DA approaches into two categories: source-available (SA) and source-free (SF), focusing on their specific methodologies and representative works.

基于CLIP的方法进行域适应(DA)，旨在利用有限的带标签源数据适配目标域。这些方法利用CLIP丰富的特征表示，最小化域间差异，提升模型在新目标域的性能，尤其在目标域标注数据稀缺时表现突出。本节将DA方法分为源可用(SA)和无源(SF)两类，重点介绍其具体方法和代表性工作。

### 4.1 Source-Available (SA)

### 4.1 源可用(SA)

This section is structured based on two main categories: single-source adaptation and multi-source adaptation. Each category addresses different strategies and challenges in domain adaptation, focusing on how models are trained using either a single source domain or multiple source domains.

本节基于两个主要类别构建:单源适应和多源适应。每个类别探讨领域适应中的不同策略和挑战，重点关注模型如何利用单一源域或多个源域进行训练。

#### 4.1.1 Single-Source (SS)

#### 4.1.1 单源(SS)

4.1.1.1 Single-Source Closed-Set Unsupervised Domain Adaptation (SS-CSUDA): In SS-CSUDA, the label space of the target domain ${\mathcal{Y}}_{t}$ is identical to that of the source domain ${\mathcal{Y}}_{s}$ , such that ${\mathcal{Y}}_{t} = {\mathcal{Y}}_{s}$ . In this scenario, a model $f : {\mathbb{R}}^{H \times  W} \mapsto$ ${\mathbb{R}}^{C}$ is trained on a labeled source domain ${D}_{s} = {\left\{  \left( {x}_{i},{y}_{i}\right) \right\}  }_{i = 1}^{{N}_{s}}$ and subsequently adapted to a target domain ${D}_{t} = {\left\{  {x}_{j}\right\}  }_{j = 1}^{{N}_{t}}$ consisting solely of unlabeled samples.

4.1.1.1 单源闭集无监督领域适应(SS-CSUDA):在SS-CSUDA中，目标域的标签空间${\mathcal{Y}}_{t}$与源域的标签空间${\mathcal{Y}}_{s}$完全相同，即${\mathcal{Y}}_{t} = {\mathcal{Y}}_{s}$。在此情境下，模型$f : {\mathbb{R}}^{H \times  W} \mapsto$${\mathbb{R}}^{C}$在带标签的源域${D}_{s} = {\left\{  \left( {x}_{i},{y}_{i}\right) \right\}  }_{i = 1}^{{N}_{s}}$上训练，随后适应仅包含无标签样本的目标域${D}_{t} = {\left\{  {x}_{j}\right\}  }_{j = 1}^{{N}_{t}}$。

The main challenge in SS-CSUDA is to effectively transfer the knowledge acquired from the labeled source domain to the unlabeled target domain, enabling the model to recognize and classify instances based on the existing class information while navigating the complexities introduced by the absence of labels in the target domain. Lai et al. [78] introduces PADCLIP, which incorporates domain names into prompts and addresses catastrophic forgetting in CLIP through adaptive debiasing, adjusting causal inference with momentum and CFM. Singha et al. [146] introduces AD-CLIP, which learns domain-invariant and class-generic prompt tokens, including domain, image, and class tokens, based on visual features. Ge et al. [46] introduces a domain adaptation framework called DAPrompt, which utilizes domain-specific prompts for UDA and incorporates a dynamic mechanism to adapt the classifier to each domain. Bai et al. [5] introduces Prompt-based Distribution Alignment (PDA), a method that integrates domain knowledge into prompt learning using a two-branch prompt tuning framework with base and alignment branches. Du et al. [35] introduces DAMP, which aligns visual and textual embeddings to leverage domain-invariant semantics, using image context to prompt the language branch in a domain-agnostic, instance-conditioned manner. Li et al. [89] introduces UniMoS, a framework for unsupervised domain adaptation that separates CLIP-extracted visual features into vision and language components, which are trained independently and then aligned using a modality discriminator. Zhou and Zhou [205] presents a cross-modal knowledge distillation (CMKD) approach for UDA, incorporating residual sparse training (RST) to greatly reduce parameter storage requirements and enhance deployment efficiency. Lai et al. [79] introduces prompt task-dependent tuning (PTT) and visual feature refinement (VFR), using domain-aware pseudo-labeling and zero-shot predictions for efficient adaptation of VLMs. Zhu et al. [207] introduces CLIP-Div, a language-guided method that aligns source and target domains using CLIP's domain-agnostic distribution, with two new divergence losses—absolute and relative—to enhance alignment. Different from existing pseudo-labeling related methods $\left\lbrack  {{26},{73},{92},{97},{99},{100},{108},{148},{187},{192},{208}}\right\rbrack$ , it employs a language-guided pseudo-labeling strategy designed to calibrate target pseudo-labels, which enhances the model's generalization on the target domain through self-training. Shi et al. [140] introduces DACR, a CLIP-based unsupervised domain adaptation method that optimizes prompts and image adapters with consistency regularization, improving generalization and domain-specific feature learning through pseudo-label consistency across augmented views. Shi et al. [141] introduces FUZZLE, a novel method that integrates fuzzy techniques $\left\lbrack  {{13},{88},{95},{96},{167},{209}}\right\rbrack$ into prompt learning for the first time within the vision-language model domain. It enhances unsupervised domain adaptation (UDA) by using domain-specific prompt learning, fuzzy C-means, and instance-level fuzzy vectors to align prompts with cluster centers. A KL divergence loss with a fuzzification factor reduces cross-domain gaps during training. Shi et al. [139] introduces VLMTSK-DA, an innovative approach that enhances vision-language models through the integration of Takagi-Sugeno-Kang (TSK) fuzzy systems. Inspired by some fuzzy systems methods $\left\lbrack  {{86},{87},{96},{103},{171}}\right\rbrack$ , It uses the TSK system as an image adapter to manage uncertainty, combining image features residually for optimized performance. Through prompt learning, it synchronizes visual and textual updates for global optimization and applies fuzzy C-means loss to align target data with source clusters, reducing distribution gaps.

SS-CSUDA中的主要挑战是如何有效地将从有标签源域获得的知识迁移到无标签目标域，使模型能够基于现有的类别信息识别和分类实例，同时应对目标域标签缺失带来的复杂性。Lai等人[78]提出了PADCLIP，该方法将域名融入提示词中，并通过自适应去偏(adaptive debiasing)解决CLIP中的灾难性遗忘问题，利用动量和CFM调整因果推断。Singha等人[146]提出了AD-CLIP，基于视觉特征学习域不变和类别通用的提示词标记，包括域、图像和类别标记。Ge等人[46]提出了名为DAPrompt的域适应框架，利用特定域的提示词进行UDA，并引入动态机制以适应每个域的分类器。Bai等人[5]提出了基于提示的分布对齐(Prompt-based Distribution Alignment，PDA)方法，采用包含基础分支和对齐分支的双分支提示调优框架，将域知识整合到提示学习中。Du等人[35]提出了DAMP，通过对齐视觉和文本嵌入以利用域不变语义，使用图像上下文以域无关、实例条件化的方式提示语言分支。Li等人[89]提出了UniMoS，一种无监督域适应框架，将CLIP提取的视觉特征分离为视觉和语言组件，分别独立训练后通过模态判别器进行对齐。Zhou和Zhou[205]提出了一种跨模态知识蒸馏(Cross-Modal Knowledge Distillation，CMKD)方法用于UDA，结合残差稀疏训练(Residual Sparse Training，RST)大幅减少参数存储需求并提升部署效率。Lai等人[79]提出了提示任务依赖调优(Prompt Task-dependent Tuning，PTT)和视觉特征精炼(Visual Feature Refinement，VFR)，利用域感知伪标签和零样本预测实现视觉语言模型(VLMs)的高效适应。Zhu等人[207]提出了CLIP-Div，一种语言引导的方法，利用CLIP的域无关分布对源域和目标域进行对齐，设计了两种新的散度损失——绝对散度和相对散度，以增强对齐效果。与现有伪标签相关方法不同$\left\lbrack  {{26},{73},{92},{97},{99},{100},{108},{148},{187},{192},{208}}\right\rbrack$，该方法采用语言引导的伪标签策略，旨在校准目标伪标签，通过自训练提升模型在目标域的泛化能力。Shi等人[140]提出了DACR，一种基于CLIP的无监督域适应方法，通过一致性正则化优化提示词和图像适配器，利用增强视图间的伪标签一致性提升泛化能力和域特定特征学习。Shi等人[141]提出了FUZZLE，一种首次将模糊技术$\left\lbrack  {{13},{88},{95},{96},{167},{209}}\right\rbrack$引入视觉语言模型领域的创新方法，通过域特定提示学习、模糊C均值和实例级模糊向量实现提示词与聚类中心的对齐。训练过程中引入带有模糊因子的KL散度损失以减少跨域差距。Shi等人[139]提出了VLMTSK-DA，一种通过整合Takagi-Sugeno-Kang(TSK)模糊系统增强视觉语言模型的创新方法。受某些模糊系统方法启发$\left\lbrack  {{86},{87},{96},{103},{171}}\right\rbrack$，该方法将TSK系统用作图像适配器以管理不确定性，残差结合图像特征以优化性能。通过提示学习同步视觉和文本更新实现全局优化，并应用模糊C均值损失将目标数据与源聚类对齐，减少分布差距。

4.1.1.2 Single-Source Open-Set Unsupervised Domain Adaptation (SS-OSUDA): In SS-OSUDA, the label space of the target domain ${\mathcal{Y}}_{t}$ may include classes that are not present in the source domain ${\mathcal{Y}}_{s}$ , such that ${\mathcal{Y}}_{s} \cap  {\mathcal{Y}}_{t} \neq  \varnothing$ and ${\mathcal{Y}}_{s} \subset  {\mathcal{Y}}_{t}$ . In this scenario, a model $f : {\mathbb{R}}^{H \times  W} \mapsto  {\mathbb{R}}^{C}$ is trained on a labeled source domain ${D}_{s} = {\left\{  \left( {x}_{i},{y}_{i}\right) \right\}  }_{i = 1}^{{N}_{s}}$ and subsequently adapted to a target domain ${D}_{t} = {\left\{  {x}_{j}\right\}  }_{j = 1}^{{N}_{t}}$ consisting solely of unlabeled samples.

4.1.1.2 单源开放集无监督领域自适应(SS-OSUDA):在SS-OSUDA中，目标域的标签空间${\mathcal{Y}}_{t}$可能包含源域${\mathcal{Y}}_{s}$中不存在的类别，因此${\mathcal{Y}}_{s} \cap  {\mathcal{Y}}_{t} \neq  \varnothing$和${\mathcal{Y}}_{s} \subset  {\mathcal{Y}}_{t}$。在这种情况下，模型$f : {\mathbb{R}}^{H \times  W} \mapsto  {\mathbb{R}}^{C}$在带标签的源域${D}_{s} = {\left\{  \left( {x}_{i},{y}_{i}\right) \right\}  }_{i = 1}^{{N}_{s}}$上训练，随后适应仅包含无标签样本的目标域${D}_{t} = {\left\{  {x}_{j}\right\}  }_{j = 1}^{{N}_{t}}$。

The primary challenge in SS-OSUDA is to enable the model to effectively generalize its knowledge to recognize both known and unknown classes, while maintaining robust performance in classifying instances from the known classes, despite the uncertainties introduced by the presence of novel classes in the target domain. Yu et al. [182] proposes ODA with CLIP trains model with the guidance of CLIP. This method calculates the entropy of the outputs of the ODA model and the predictions of CLIP on the target domain to identify known and unknown samples. Zeng et al. [186] introduces Decoupling Domain Invariance and Variance with Tailored Prompts (PromptDIV) for OSDA, aiming to learn domain-invariant features for alignment. Specifically, it proposes one-vs-all clustering with text features (OVAT) to generate domain-unbiased pseudo-labels, domain-specific prompts (DSPs) to separate domain-invariant and domain-variant features, and Semisupervised and affinity contrastive learning (SMACL) to enhance feature consistency within the same category. Monga et al. [113] introduces CLIP talks on open-set multi-target domain adaptation (COSMo) for learning domain-agnostic prompts through source domain-guided prompt learning to address Multi-Target Domain Adaptation (MTDA). It employs a domain-specific bias network and separate prompts for known and unknown classes. COSMo is the first to tackle Open-Set Multi-Target Domain Adaptation (OSMTDA), enhancing the adaptation process in real-world scenarios.

SS-OSUDA的主要挑战在于使模型能够有效地泛化其知识，以识别已知和未知类别，同时在目标域中新类别带来的不确定性下，保持对已知类别实例的稳健分类性能。Yu等人[182]提出了基于CLIP指导训练的ODA方法。该方法计算ODA模型输出与CLIP在目标域预测的熵值，以识别已知和未知样本。Zeng等人[186]提出了用于OSDA的定制提示分离域不变性与变异性(PromptDIV)，旨在学习域不变特征以实现对齐。具体而言，提出了基于文本特征的一对多聚类(OVAT)生成域无偏伪标签，域特定提示(DSPs)用于分离域不变和域变特征，以及半监督和亲和对比学习(SMACL)以增强同类别内的特征一致性。Monga等人[113]提出了基于CLIP的开放集多目标域自适应(COSMo)，通过源域引导的提示学习实现域无关提示的学习，以解决多目标域自适应(MTDA)问题。该方法采用域特定偏置网络及分别针对已知和未知类别的提示。COSMo首次解决了开放集多目标域自适应(OSMTDA)，提升了实际场景中的适应过程。

![bo_d282qmv7aajc738ormjg_8_257_115_508_303_0.jpg](images/bo_d282qmv7aajc738ormjg_8_257_115_508_303_0.jpg)

Fig. 11. The scenario of Multi-Source Open-Partial-Set Unsupervised Domain Adaptation (MS-OPSUDA) a.k.a. Universal Multi-Source Domain Adaptation (UniMDA).

图11. 多源开放部分集无监督领域自适应(MS-OPSUDA)场景，又称通用多源领域自适应(UniMDA)。

#### 4.1.2 Multi-Source (MS)

#### 4.1.2 多源(MS)

4.1.2.1 Multi-Source Closed-Set Unsupervised Domain Adaptation (MS-CSUDA): In SS-CSUDA, the label space of the target domain ${\mathcal{Y}}_{t}$ is identical to that of the source domain ${\mathcal{Y}}_{s}$ , such that ${\mathcal{Y}}_{t} = {\mathcal{Y}}_{s}$ . A model $f : {\mathbb{R}}^{H \times  \widetilde{W}} \mapsto  {\mathbb{R}}^{C}$ is trained on a labeled source domain ${D}_{s} = {\left\{  \left( {x}_{i},{y}_{i}\right) \right\}  }_{i = 1}^{{N}_{s}}$ and subsequently adapted to an unlabeled target domain ${D}_{t} = {\left\{  {x}_{j}\right\}  }_{j = 1}^{{N}_{t}}$ consisting solely of unlabeled samples.

4.1.2.1 多源闭集无监督领域自适应(MS-CSUDA):在SS-CSUDA中，目标域的标签空间${\mathcal{Y}}_{t}$与源域${\mathcal{Y}}_{s}$完全相同，因此${\mathcal{Y}}_{t} = {\mathcal{Y}}_{s}$。模型$f : {\mathbb{R}}^{H \times  \widetilde{W}} \mapsto  {\mathbb{R}}^{C}$在带标签的源域${D}_{s} = {\left\{  \left( {x}_{i},{y}_{i}\right) \right\}  }_{i = 1}^{{N}_{s}}$上训练，随后适应仅包含无标签样本的目标域${D}_{t} = {\left\{  {x}_{j}\right\}  }_{j = 1}^{{N}_{t}}$。

The primary challenge in MS-CSUDA lies in effectively leveraging information from multiple source domains to enhance the model's performance on the target domain while addressing the uncertainties that arise from the lack of labels in the target samples. Chen et al. [16] presents MPA, a prompt learning-based MS-UDA method for source-target domain alignment. It trains individual prompts for each domain pair and aligns them using an auto-encoder, with an LST strategy for efficient adaptation to target domains. Wang et al. [166] introduces LanDA, a language-guided MS-DA method that transfers knowledge from multiple source domains to a target domain using only textual descriptions, preserving task-relevant information without requiring target domain images.

MS-CSUDA的主要挑战在于有效利用多个源域的信息，以提升模型在目标域的性能，同时应对目标样本缺乏标签带来的不确定性。Chen等人[16]提出了MPA，一种基于提示学习的多源无监督域自适应方法，用于源-目标域对齐。该方法为每个域对训练独立提示，并通过自编码器进行对齐，采用LST策略实现对目标域的高效适应。Wang等人[166]提出了LanDA，一种语言引导的多源域自适应方法，通过仅使用文本描述将多个源域的知识迁移到目标域，保留任务相关信息，无需目标域图像。

4.1.2.2 Multi-Source Open-Partial-Set Unsupervised Domain Adaptation (MS-OPSUDA) a.k.a. Universal Multi-Source Domain Adaptation (UniMDA): In MS-OPSUDA(UniMDA), the label space of the target domain ${\mathcal{Y}}_{t}$ includes some classes from the label space of the source domains ${\mathcal{Y}}_{s} = \left\{  {{\mathcal{Y}}_{1},{\mathcal{Y}}_{2},\ldots ,{\mathcal{Y}}_{S}}\right\}$ , such that ${\mathcal{Y}}_{s} \cap  {\mathcal{Y}}_{t} \neq  \varnothing ,{\mathcal{Y}}_{t} \nsubseteq  {\mathcal{Y}}_{s}$ , and ${\mathcal{Y}}_{s} \nsubseteq  {\mathcal{Y}}_{t}$ (illustrated in Fig. 11). In this scenario, a model $f : {\mathbb{R}}^{H \times  W} \mapsto  {\mathbb{R}}^{C}$ is trained on multiple labeled source domains ${D}_{s} = \left\{  {{D}_{1},{D}_{2},\ldots ,{D}_{S}}\right\}$ and then adapted to a target domain ${D}_{t} = {\left\{  {x}_{j}\right\}  }_{j = 1}^{{N}_{t}}$ , which consists solely of unlabeled samples.

4.1.2.2 多源开放部分集无监督领域自适应(MS-OPSUDA)，又称通用多源领域自适应(UniMDA):在MS-OPSUDA(UniMDA)中，目标域的标签空间${\mathcal{Y}}_{t}$包含源域标签空间${\mathcal{Y}}_{s} = \left\{  {{\mathcal{Y}}_{1},{\mathcal{Y}}_{2},\ldots ,{\mathcal{Y}}_{S}}\right\}$中的部分类别，满足${\mathcal{Y}}_{s} \cap  {\mathcal{Y}}_{t} \neq  \varnothing ,{\mathcal{Y}}_{t} \nsubseteq  {\mathcal{Y}}_{s}$和${\mathcal{Y}}_{s} \nsubseteq  {\mathcal{Y}}_{t}$(如图11所示)。在此场景下，模型$f : {\mathbb{R}}^{H \times  W} \mapsto  {\mathbb{R}}^{C}$在多个有标签的源域${D}_{s} = \left\{  {{D}_{1},{D}_{2},\ldots ,{D}_{S}}\right\}$上训练，然后适应于仅包含无标签样本的目标域${D}_{t} = {\left\{  {x}_{j}\right\}  }_{j = 1}^{{N}_{t}}$。

UniMDA encounters two primary challenges. The first involves mitigating domain shifts across various domains to capture discriminative representations for shared classes. The second concerns handling class shifts by identifying unknown target samples lacking label information. To date, limited research (e.g., UMAN [180] and HyMOS [10]) has been conducted in the UniMDA domain.

UniMDA面临两个主要挑战。首先是缓解不同域之间的域偏移，以捕捉共享类别的判别性表示。其次是处理类别偏移，通过识别缺乏标签信息的未知目标样本。迄今为止，关于UniMDA的研究较少(例如UMAN [180]和HyMOS [10])。

Yang et al. [176] introduces SAP-CLIP, a Semantic-aware Adaptive Prompt method for UniMDA tasks. It uses learnable prompts to handle domain and class shifts, with a dynamic margin loss that improves detection of unknown samples by increasing their distance from known ones.

Yang等人[176]提出了SAP-CLIP，一种面向UniMDA任务的语义感知自适应提示方法。该方法利用可学习提示处理域和类别偏移，通过动态边界损失提升未知样本的检测能力，使其与已知样本的距离增大。

4.1.2.3 Multi-Source Few-Shot Domain Adaptation (MS-FSDA): Yu et al. [181] addresses MS-FSDA by introducing a prompt learning methodology that enhances VLMs using domain prompts. It also proposes "domain-aware mixup," improving domain prompt learning. The multi-source domain prompt learning (MSDPL) method focuses on both domain and class prompts to enhance performance in few-shot adaptation tasks.

4.1.2.3 多源少样本领域自适应(MS-FSDA):Yu等人[181]通过引入一种提示学习方法解决MS-FSDA，该方法利用域提示增强视觉语言模型(VLMs)。同时提出了“域感知混合”(domain-aware mixup)，以改进域提示学习。多源域提示学习(MSDPL)方法聚焦于域提示和类别提示，提升少样本自适应任务的性能。

### 4.2 Source-Free (SF)

### 4.2 无源(SF)

This section is structured based on two main categories: Source-Fully-Free (SFF) and Source-Data-Free (SDF). Each category addresses distinct strategies and challenges in training models under these conditions.

本节结构基于两个主要类别:完全无源(SFF)和无源数据(SDF)。每个类别针对在这些条件下训练模型的不同策略和挑战进行探讨。

#### 4.2.1 Source-Fully-Free (SFF)

#### 4.2.1 完全无源(SFF)

4.2.1.1 Source-Fully-Free Closed-Set Unsupervised Domain Adaptation (SFF-CSUDA) a.k.a. Closed-Set Unsupervised Fine-Tuning (CS-UFT): Source-Fully-Free Closed-Set Unsupervised Domain Adaptation (SFF-CSUDA), also known as Closed-Set Unsupervised Fine-Tuning (CS-UFT), refers to a framework where the label space of the target domain ${\mathcal{Y}}_{t}$ is identical to that of the predetermined list of known classes ${\mathcal{Y}}_{s}$ , such that ${\mathcal{Y}}_{t} = {\mathcal{Y}}_{s}$ . In this scenario, the model $f : {\mathbb{R}}^{H \times  W} \mapsto  {\mathbb{R}}^{C}$ is adapted to a target domain ${D}_{t} = {\left\{  {x}_{j}\right\}  }_{j = 1}^{{N}_{t}}$ consisting solely of unlabeled samples, with no access to labeled data from a source domain ${D}_{s}$ .

4.2.1.1 完全无源闭集无监督领域自适应(SFF-CSUDA)，又称闭集无监督微调(CS-UFT):完全无源闭集无监督领域自适应(SFF-CSUDA)，也称为闭集无监督微调(CS-UFT)，指目标域的标签空间${\mathcal{Y}}_{t}$与预先确定的已知类别列表${\mathcal{Y}}_{s}$完全相同，满足${\mathcal{Y}}_{t} = {\mathcal{Y}}_{s}$。在此场景下，模型$f : {\mathbb{R}}^{H \times  W} \mapsto  {\mathbb{R}}^{C}$适应仅包含无标签样本的目标域${D}_{t} = {\left\{  {x}_{j}\right\}  }_{j = 1}^{{N}_{t}}$，且无法访问源域${D}_{s}$的有标签数据。

The main challenge in SFF-CSUDA is to utilize the knowledge encoded within the model and any available information from the target domain to effectively classify instances, while maintaining robustness in the absence of source data. Huang et al. [57] presents an unsupervised prompt learning (UPL) framework and it is the first work to introduce unsupervised learning into prompt learning of VLM. The method introduces several techniques, such as a top-K pseudo-labeling strategy, pseudo label ensemble, and prompt representation ensemble, aimed at enhancing transfer performance. Tanwisuth et al. [157] introduces the Prompt-Oriented Unsupervised Fine-Tuning (POUF) framework, which aligns prototypes and target data in the latent space using transport-based distribution alignment and mutual information maximization. Additionally, the formulation of POUF is demonstrated for both language-augmented vision models and masked language models. Hu et al. [56] introduces ReCLIP, which learns a projection space to mitigate misaligned visual-text embeddings and generate pseudo labels. It then utilizes cross-modality self-training with these labels to iteratively refine the encoders and reduce domain gap and misalignment. Mirza et al. [110] presents LaFTer, a label-free, parameter-efficient cross-modal transfer method that utilizes only 0.4% of learned parameters. It fine-tunes a VLM to enhance recognition performance on target classes using automatically generated texts and an unlabeled image collection. This study demonstrates that training solely on automatically gathered language knowledge, such as through LLM prompting, can effectively bootstrap a visual classifier built on an aligned VLM. Zhang et al. [190] introduces the Candidate Pseudolabel Learning (CPL) method for fine-tuning VLM using suitable candidate pseudolabels for unlabeled data. The CPL framework generates refined candidate pseudo labels by constructing a confidence score matrix and considering both intra- and inter-instance label selection to improve true label identification. Ali et al. [3] introduces DPA, which generates accurate pseudo-labels by combining outputs from two prototypes and ranking them to reduce noise, especially early in training. It also aligns textual prototypes with image prototypes to address visual-textual misalignment. Liang et al. [94] proposes Universal Entropy Optimization (UEO), which leverages sample-level confidence to optimize entropy and jointly tunes textual prompts and visual affine transformations in CLIP. Long et al. [101] proposes TFUP, enhancing features with similarity-based predictions and selecting samples using confidence and prototype scores. TFUP-T improves performance through entropy-based adaptation. Feng et al. [38] shows that domain priors enhance CLIP's zero-shot performance and introduces a benchmark with a knowledge disentangling strategy for label-free multi-source generalization.

SFF-CSUDA中的主要挑战是利用模型中编码的知识以及目标域中任何可用的信息，有效地对实例进行分类，同时在缺乏源数据的情况下保持鲁棒性。Huang等人[57]提出了一种无监督提示学习(UPL)框架，这是首个将无监督学习引入视觉语言模型(VLM)提示学习的工作。该方法引入了多种技术，如Top-K伪标签策略、伪标签集成和提示表示集成，旨在提升迁移性能。Tanwisuth等人[157]提出了面向提示的无监督微调(POUF)框架，通过基于传输的分布对齐和互信息最大化，在潜在空间中对原型和目标数据进行对齐。此外，POUF的公式化方法适用于语言增强视觉模型和掩码语言模型。Hu等人[56]提出了ReCLIP，通过学习投影空间来缓解视觉-文本嵌入的错位并生成伪标签，随后利用跨模态自训练迭代优化编码器，减少域间差距和错位。Mirza等人[110]提出了LaFTer，一种无标签、参数高效的跨模态迁移方法，仅使用0.4%的学习参数，通过自动生成文本和无标签图像集合微调VLM，以提升目标类别的识别性能。该研究表明，仅通过自动收集的语言知识(如通过大型语言模型(LLM)提示)训练，能够有效启动基于对齐VLM的视觉分类器。Zhang等人[190]提出了候选伪标签学习(CPL)方法，利用适合的候选伪标签对无标签数据进行VLM微调。CPL框架通过构建置信度评分矩阵，并考虑实例内和实例间的标签选择，生成精炼的候选伪标签以提升真实标签识别。Ali等人[3]提出了DPA，通过结合两个原型的输出并进行排序以减少噪声，尤其是在训练初期，生成准确的伪标签。同时，该方法对齐文本原型与图像原型，解决视觉-文本错位问题。Liang等人[94]提出了通用熵优化(UEO)，利用样本级置信度优化熵，并在CLIP中联合调优文本提示和视觉仿射变换。Long等人[101]提出了TFUP，通过基于相似性的预测增强特征，并利用置信度和原型评分选择样本。TFUP-T通过基于熵的适应进一步提升性能。Feng等人[38]表明域先验提升了CLIP的零样本性能，并引入了一个带有知识解耦策略的无标签多源泛化基准。

4.2.1.2 Source-Fully-Free Partial-Set Unsupervised Domain Adaptation (SFF-PSUDA) a.k.a. Partial-Set Unsupervised Fine-Tuning (PS-UFT): In SFF-PSUDA(PS-UFT), the label space of the target domain ${\mathcal{Y}}_{t}$ is a subset of the label space of the predetermined list of known classes ${\mathcal{Y}}_{s}$ , such that ${\mathcal{Y}}_{t} \subset  {\mathcal{Y}}_{s}$ . In this scenario, the model $f : {\mathbb{R}}^{H \times  W} \mapsto  {\mathbb{R}}^{C}$ is adapted to a target domain ${D}_{t} = {\left\{  {x}_{j}\right\}  }_{j = 1}^{{N}_{t}}$ consisting solely of unlabeled samples, with no access to labeled data from a source domain ${D}_{s}$ .

4.2.1.2 源完全缺失的部分类别无监督域适应(SFF-PSUDA)，又称部分类别无监督微调(PS-UFT):在SFF-PSUDA(PS-UFT)中，目标域的标签空间${\mathcal{Y}}_{t}$是预先确定的已知类别列表${\mathcal{Y}}_{s}$的标签空间的子集，即${\mathcal{Y}}_{t} \subset  {\mathcal{Y}}_{s}$。在此情形下，模型$f : {\mathbb{R}}^{H \times  W} \mapsto  {\mathbb{R}}^{C}$被适配到仅包含无标签样本的目标域${D}_{t} = {\left\{  {x}_{j}\right\}  }_{j = 1}^{{N}_{t}}$，且无法访问源域${D}_{s}$的有标签数据。

The main challenge in SFF-PSUDA is to effectively leverage the knowledge encoded within the model and any available information from the target domain to classify instances corresponding to the known classes, while navigating the complexities introduced by the absence of some classes in the target domain. Liang et al. [94] shows that Universal Entropy Optimization (UEO) excels in SFF-PSUDA by effectively adapting to target domains with a subset of source classes. This method enhances classification accuracy and demonstrates robust performance despite the absence of certain classes, highlighting its potential in real-world applications.

SFF-PSUDA中的主要挑战是有效利用模型中编码的知识及目标域中任何可用信息，对对应已知类别的实例进行分类，同时应对目标域中部分类别缺失带来的复杂性。Liang等人[94]表明通用熵优化(UEO)在SFF-PSUDA中表现优异，能够有效适应包含源类别子集的目标域。该方法提升了分类准确率，并在缺失某些类别的情况下展现出稳健性能，凸显其在实际应用中的潜力。

4.2.1.3 Source-Fully-Free Open-Set Unsupervised Domain Adaptation (SFF-OSUDA) a.k.a. Open-Set Unsupervised Fine-Tuning (OS-UFT): In SFF-OSUDA(OS-UFT), the label space of the target domain ${\mathcal{Y}}_{t}$ may include classes not present in the label space of the predetermined list of known classes ${\mathcal{Y}}_{s}$ , such that ${\mathcal{Y}}_{s} \subset  {\mathcal{Y}}_{t}$ . In this scenario, the model $f : {\mathbb{R}}^{H \times  W} \mapsto  {\mathbb{R}}^{C}$ is adapted to a target domain ${D}_{t} = {\left\{  {x}_{j}\right\}  }_{j = 1}^{{N}_{t}}$ consisting solely of unlabeled samples, with no access to labeled data from a source domain ${D}_{s}$ .

4.2.1.3 完全无源开放集无监督领域自适应(SFF-OSUDA)，又称开放集无监督微调(OS-UFT):在SFF-OSUDA(OS-UFT)中，目标域的标签空间${\mathcal{Y}}_{t}$可能包含预先确定的已知类别列表${\mathcal{Y}}_{s}$中不存在的类别，因此${\mathcal{Y}}_{s} \subset  {\mathcal{Y}}_{t}$。在这种情况下，模型$f : {\mathbb{R}}^{H \times  W} \mapsto  {\mathbb{R}}^{C}$被适配到仅包含未标记样本的目标域${D}_{t} = {\left\{  {x}_{j}\right\}  }_{j = 1}^{{N}_{t}}$，且无法访问源域${D}_{s}$的标记数据。

The primary challenge in SFF-OSUDA lies in learning robust representations that facilitate the recognition of known categories in the target domain, while reliably detecting samples from previously unseen classes, despite the complete absence of labeled source data. Min et al. [109] introduces the UOTA algorithm, which improves pre-trained zero-shot models using open-set unlabeled data. It enables implicit OOD detection, enhances classification for known classes, and achieves state-of-the-art performance with computational efficiency by updating only a lightweight adapter. Liang et al. [94] shows that Universal Entropy Optimization (UEO) excels in SFF-OSUDA, enhancing classification of both known and new instances, and proving robust in dynamic environments with changing class distributions.

SFF-OSUDA的主要挑战在于学习鲁棒的表示，以便在目标域中识别已知类别，同时可靠地检测先前未见过的类别样本，尽管完全没有标记的源数据。Min等人[109]提出了UOTA算法，该算法利用开放集未标记数据改进预训练的零样本模型，实现隐式的OOD(域外)检测，增强已知类别的分类性能，并通过仅更新轻量级适配器以计算效率达到最先进水平。Liang等人[94]表明，通用熵优化(UEO)在SFF-OSUDA中表现优异，提升了已知和新实例的分类效果，并在类别分布动态变化的环境中表现出鲁棒性。

4.2.1.4 Source-Fully-Free Open-Partial-Set Unsupervised Domain Adaptation (SFF-OPSUDA) a.k.a. Open-Partial-Set Unsupervised Fine-Tuning (OPS-UFT): In SFF-OPSUDA(OPS-UFT), the label space of the target domain ${\mathcal{Y}}_{t}$ includes some classes from the label space of the predetermined list of known classes ${\mathcal{Y}}_{s}$ , such that ${\mathcal{Y}}_{s} \cap  {\mathcal{Y}}_{t} \neq  \varnothing ,{\mathcal{Y}}_{t} \nsubseteq  {\mathcal{Y}}_{s}$ , and ${\mathcal{Y}}_{s} \nsubseteq  {\mathcal{Y}}_{t}$ . In this scenario, the model $f : {\mathbb{R}}^{H \times  W} \mapsto  {\mathbb{R}}^{C}$ is adapted to a target domain ${D}_{t} = {\left\{  {x}_{j}\right\}  }_{j = 1}^{{N}_{t}}$ consisting solely of unlabeled samples, with no access to labeled data from a source domain ${D}_{s}$ .

4.2.1.4 完全无源开放部分集无监督领域自适应(SFF-OPSUDA)，又称开放部分集无监督微调(OPS-UFT):在SFF-OPSUDA(OPS-UFT)中，目标域的标签空间${\mathcal{Y}}_{t}$包含预先确定的已知类别列表${\mathcal{Y}}_{s}$中的部分类别，因此${\mathcal{Y}}_{s} \cap  {\mathcal{Y}}_{t} \neq  \varnothing ,{\mathcal{Y}}_{t} \nsubseteq  {\mathcal{Y}}_{s}$，且${\mathcal{Y}}_{s} \nsubseteq  {\mathcal{Y}}_{t}$。在这种情况下，模型$f : {\mathbb{R}}^{H \times  W} \mapsto  {\mathbb{R}}^{C}$被适配到仅包含未标记样本的目标域${D}_{t} = {\left\{  {x}_{j}\right\}  }_{j = 1}^{{N}_{t}}$，且无法访问源域${D}_{s}$的标记数据。

The main challenge in SFF-OPSUDA is to accurately identify target-domain samples belonging to the common classes while reliably detecting samples from unknown classes-i.e., those not included in the predefined set of known categories-and avoiding the misclassification of known categories into unknown ones, all without access to any labeled source data. Liang et al. [94] demonstrates that Universal Entropy Optimization (UEO) enhances SFF-OPSUDA by leveraging common classes between source and target domains. It improves classification of known classes and adapts well to new, unseen classes, making it effective in partial class overlap scenarios.

SFF-OPSUDA的主要挑战是准确识别属于公共类别的目标域样本，同时可靠地检测未知类别样本——即不包含在预定义已知类别集合中的类别——并避免将已知类别误分类为未知类别，且无任何标记的源数据。Liang等人[94]证明，通用熵优化(UEO)通过利用源域和目标域之间的公共类别，提升了SFF-OPSUDA的性能。它改善了已知类别的分类，并能适应新的未见类别，使其在部分类别重叠场景中表现有效。

#### 4.2.2 Source-Data-Free (SDF)

#### 4.2.2 无源数据(SDF)

4.2.2.1 Source-Data-Free Closed-Set Unsupervised Domain Adaptation (SDF-CSUDA): In SDF-CSUDA, the label space of the target domain ${\mathcal{Y}}_{t}$ is identical to that of the source domain ${\mathcal{Y}}_{s}$ , such that ${\mathcal{Y}}_{t} = {\mathcal{Y}}_{s}$ . In this scenario, a model $f : {\mathbb{R}}^{H \times  W} \mapsto  {\mathbb{R}}^{C}$ is adapted to a target domain ${D}_{t} = {\left\{  {x}_{j}\right\}  }_{j = 1}^{{N}_{t}}$ consisting solely of unlabeled samples, with no access to labeled data from a source domain ${D}_{s}$ .

4.2.2.1 无源数据闭集无监督领域自适应(SDF-CSUDA):在SDF-CSUDA中，目标域的标签空间${\mathcal{Y}}_{t}$与源域${\mathcal{Y}}_{s}$的标签空间完全相同，因此${\mathcal{Y}}_{t} = {\mathcal{Y}}_{s}$。在这种情况下，模型$f : {\mathbb{R}}^{H \times  W} \mapsto  {\mathbb{R}}^{C}$被适配到仅包含未标记样本的目标域${D}_{t} = {\left\{  {x}_{j}\right\}  }_{j = 1}^{{N}_{t}}$，且无法访问源域${D}_{s}$的标记数据。

The main challenge in SDF-CSUDA is to enable the model to effectively utilize the information available in the target domain to make accurate predictions for the known classes, while addressing the uncertainties arising from the absence of labeled source data. DIFO [155] introduces a distillation approach for multimodal models, combining prompt learning and knowledge distillation with regularization for improved reliability. Zhang et al. [193] introduces Co-learn++, which enhances target adaptation by integrating pre-trained networks. It improves pseudolabel quality through collaboration with the source model and feature extractor, leveraging CLIP's zero-shot classification decisions. Li et al. [91] introduces CDBN, a data-efficient dual-branch network powered by CLIP. It integrates source domain class semantics into unsupervised fine-tuning for target domain generalization, preserving class information while enhancing accuracy and diversity in predictions. Tian et al. [158] introduces BBC, a black-box domain adaptation method using CLIP. It improves pseudo-label accuracy through joint label generation from a cloud API and CLIP, along with a structure-preserved strategy refining labels using k-nearest neighbors.

SDF-CSUDA中的主要挑战是使模型能够有效利用目标域中的信息，对已知类别进行准确预测，同时解决因缺乏带标签的源数据而产生的不确定性。DIFO [155]提出了一种多模态模型的蒸馏方法，结合提示学习和知识蒸馏，并通过正则化提升可靠性。Zhang等人[193]提出了Co-learn++，通过整合预训练网络增强目标适应性。该方法通过与源模型和特征提取器的协作，利用CLIP(Contrastive Language-Image Pre-training)的零样本分类决策，提升伪标签质量。Li等人[91]提出了CDBN，一种由CLIP驱动的数据高效双分支网络。它将源域类别语义整合到无监督微调中以实现目标域泛化，在保持类别信息的同时提升预测的准确性和多样性。Tian等人[158]提出了BBC，一种基于CLIP的黑盒域适应方法。该方法通过云API和CLIP联合生成标签，并采用结构保持策略利用k近邻优化标签，从而提升伪标签的准确性。

TABLE 2

The different scenarios for DG and DA. (SA: Source-Available, SF: Source-Free, SS: Single-Source, MS: Multi-Source, CS: Closed-Set, PS: Partial-Set, OS: Open-Set, OPS: Open-Partial-Set, FS: Few-Shot, FT: Fine-Tuning)

DG和DA的不同场景。(SA:源可用，SF:无源，SS:单源，MS:多源，CS:闭集，PS:部分集，OS:开集，OPS:开部分集，FS:少样本，FT:微调)

<table><tr><td colspan="3" rowspan="2">Scenario</td><td colspan="2">Source Domain</td><td colspan="3">Target Domain</td><td colspan="4">Category between Source Domain and Target Domain</td></tr><tr><td>Single-Source (SS)</td><td>Multi-Source (MS)</td><td>Source Domain Data</td><td>Source Domain Knowledge</td><td>Target Data (Unlabeled)</td><td>Closed-Set (CS)</td><td>Open-Partial- $\mathbf{{Set}}$ (PS)</td><td>$\mathbf{{Open} - }$ Set (OS)</td><td>Open-Partial- $\mathbf{{Set}}$ (OPS)</td></tr><tr><td rowspan="4">Domain Generalization (DG)</td><td rowspan="3">Source-Available (SA)</td><td>SS-DG</td><td>✓</td><td/><td/><td/><td/><td>✓</td><td>✓</td><td>✓</td><td/></tr><tr><td>MS-CSDG</td><td/><td>✓</td><td/><td/><td/><td>✓</td><td/><td/><td/></tr><tr><td>MS-OSDG</td><td/><td>✓</td><td/><td/><td/><td/><td/><td>✓</td><td/></tr><tr><td>Source-Free (SF)</td><td>S(F)F-DG</td><td/><td/><td/><td>✓</td><td/><td>✓</td><td>✓</td><td>✓</td><td/></tr><tr><td rowspan="11">Domain Adaptation (DA)</td><td rowspan="4">Source-Available (SA)</td><td>SS-CSUDA</td><td>✓</td><td/><td>✓</td><td>✓</td><td>✓</td><td>✓</td><td/><td/><td/></tr><tr><td>SS-OSUDA</td><td>✓</td><td/><td>✓</td><td>✓</td><td>✓</td><td/><td/><td>✓</td><td/></tr><tr><td>MS-UDA</td><td/><td>✓</td><td>✓</td><td>✓</td><td>✓</td><td>✓</td><td>✓</td><td>✓</td><td/></tr><tr><td>MS-FSDA</td><td/><td>✓</td><td>✓</td><td>✓</td><td>✓</td><td>✓</td><td>✓</td><td>✓</td><td/></tr><tr><td rowspan="7">Source-Free (SF)</td><td>SFF-CSUDA a.k.a. CS-UFT</td><td/><td/><td/><td/><td>✓</td><td>✓</td><td/><td/><td/></tr><tr><td>SFF-PSUDA a.k.a. PS-UFT</td><td/><td/><td/><td/><td>✓</td><td/><td>✓</td><td/><td/></tr><tr><td>SFF-OSUDA a.k.a. OS-UFT</td><td/><td/><td/><td/><td>✓</td><td/><td/><td>✓</td><td/></tr><tr><td>SFF-OSUDA a.k.a. OPS-UFT</td><td/><td/><td/><td/><td>✓</td><td/><td/><td/><td>✓</td></tr><tr><td>SDF-CSUDA</td><td/><td/><td/><td>✓</td><td>✓</td><td>✓</td><td/><td/><td/></tr><tr><td>SDF-PSUDA</td><td/><td/><td/><td>✓</td><td>✓</td><td/><td>✓</td><td/><td/></tr><tr><td>SDF-OSUDA</td><td/><td/><td/><td>✓</td><td>✓</td><td/><td/><td>✓</td><td/></tr></table>

<table><tbody><tr><td colspan="3" rowspan="2">场景</td><td colspan="2">源域</td><td colspan="3">目标域</td><td colspan="4">源域与目标域之间的类别</td></tr><tr><td>单源 (SS)</td><td>多源 (MS)</td><td>源域数据</td><td>源域知识</td><td>目标数据(无标签)</td><td>闭集 (CS)</td><td>开放-部分-$\mathbf{{Set}}$ (PS)</td><td>$\mathbf{{Open} - }$ 集 (OS)</td><td>开放-部分-$\mathbf{{Set}}$ (OPS)</td></tr><tr><td rowspan="4">域泛化 (DG)</td><td rowspan="3">源可用 (SA)</td><td>单源-域泛化 (SS-DG)</td><td>✓</td><td></td><td></td><td></td><td></td><td>✓</td><td>✓</td><td>✓</td><td></td></tr><tr><td>多源-闭集域泛化 (MS-CSDG)</td><td></td><td>✓</td><td></td><td></td><td></td><td>✓</td><td></td><td></td><td></td></tr><tr><td>多源-开放集域泛化 (MS-OSDG)</td><td></td><td>✓</td><td></td><td></td><td></td><td></td><td></td><td>✓</td><td></td></tr><tr><td>无源 (SF)</td><td>无源域泛化 (S(F)F-DG)</td><td></td><td></td><td></td><td>✓</td><td></td><td>✓</td><td>✓</td><td>✓</td><td></td></tr><tr><td rowspan="11">域适应 (DA)</td><td rowspan="4">源可用 (SA)</td><td>单源-闭集无监督域适应 (SS-CSUDA)</td><td>✓</td><td></td><td>✓</td><td>✓</td><td>✓</td><td>✓</td><td></td><td></td><td></td></tr><tr><td>单源-开放集无监督域适应 (SS-OSUDA)</td><td>✓</td><td></td><td>✓</td><td>✓</td><td>✓</td><td></td><td></td><td>✓</td><td></td></tr><tr><td>多源无监督域适应 (MS-UDA)</td><td></td><td>✓</td><td>✓</td><td>✓</td><td>✓</td><td>✓</td><td>✓</td><td>✓</td><td></td></tr><tr><td>多源无源域适应 (MS-FSDA)</td><td></td><td>✓</td><td>✓</td><td>✓</td><td>✓</td><td>✓</td><td>✓</td><td>✓</td><td></td></tr><tr><td rowspan="7">无源 (SF)</td><td>无源-闭集无监督域适应 又名 闭集无源微调 (SFF-CSUDA a.k.a. CS-UFT)</td><td></td><td></td><td></td><td></td><td>✓</td><td>✓</td><td></td><td></td><td></td></tr><tr><td>无源-部分无监督域适应 又名 部分无源微调 (SFF-PSUDA a.k.a. PS-UFT)</td><td></td><td></td><td></td><td></td><td>✓</td><td></td><td>✓</td><td></td><td></td></tr><tr><td>无源-开放集无监督域适应 又名 开放集无源微调 (SFF-OSUDA a.k.a. OS-UFT)</td><td></td><td></td><td></td><td></td><td>✓</td><td></td><td></td><td>✓</td><td></td></tr><tr><td>无源-开放集无监督域适应 又名 开放部分无源微调 (SFF-OSUDA a.k.a. OPS-UFT)</td><td></td><td></td><td></td><td></td><td>✓</td><td></td><td></td><td></td><td>✓</td></tr><tr><td>源数据自由-闭集无监督域适应 (SDF-CSUDA)</td><td></td><td></td><td></td><td>✓</td><td>✓</td><td>✓</td><td></td><td></td><td></td></tr><tr><td>源数据自由-部分无监督域适应 (SDF-PSUDA)</td><td></td><td></td><td></td><td>✓</td><td>✓</td><td></td><td>✓</td><td></td><td></td></tr><tr><td>源数据自由-开放集无监督域适应 (SDF-OSUDA)</td><td></td><td></td><td></td><td>✓</td><td>✓</td><td></td><td></td><td>✓</td><td></td></tr></tbody></table>

4.2.2.2 Source-Data-Free Partial-Set Unsupervised Domain Adaptation (SDF-PSUDA): In SDF-PSUDA, the label space of the target domain ${\mathcal{Y}}_{t}$ is a subset of the label space of the source domain ${\mathcal{Y}}_{s}$ , such that ${\mathcal{Y}}_{t} \subset  {\mathcal{Y}}_{s}$ . In this scenario, a model $f : {\mathbb{R}}^{H \times  W} \mapsto  {\mathbb{R}}^{C}$ is adapted to a target domain ${D}_{t} = {\left\{  {x}_{j}\right\}  }_{j = 1}^{{N}_{t}}$ consisting solely of unlabeled samples, without access to labeled data from a source domain ${D}_{s}$ .

4.2.2.2 无源数据部分集无监督领域自适应(SDF-PSUDA):在SDF-PSUDA中，目标域的标签空间${\mathcal{Y}}_{t}$是源域标签空间${\mathcal{Y}}_{s}$的子集，即${\mathcal{Y}}_{t} \subset  {\mathcal{Y}}_{s}$。在此情境下，模型$f : {\mathbb{R}}^{H \times  W} \mapsto  {\mathbb{R}}^{C}$被适配到仅包含未标记样本的目标域${D}_{t} = {\left\{  {x}_{j}\right\}  }_{j = 1}^{{N}_{t}}$，且无法访问源域${D}_{s}$的标记数据。

The main challenge in SDF-PSUDA is adapting the model to target domain classes while handling missing classes and the lack of labeled data. In this context, DIFO [155] adapts the ViL model to target domains where only a subset of source classes is present. The mutual information maximization process focuses on refining the model's understanding of the relevant classes in the partial set, enabling accurate adaptation to the specific class distribution without any labeled source data. Zhang et al. [193] also demonstrates strong performance in SDF-PSUDA, effectively adapting to target domains with a subset of source classes and improving classification accuracy.

SDF-PSUDA的主要挑战在于在处理缺失类别和缺乏标记数据的情况下，将模型适配到目标域类别。对此，DIFO [155]将ViL模型适配到仅包含源类别子集的目标域。互信息最大化过程专注于优化模型对部分集相关类别的理解，使其能够在无任何标记源数据的情况下，准确适配特定类别分布。Zhang等人[193]也展示了SDF-PSUDA中的优异表现，有效适配包含源类别子集的目标域并提升分类准确率。

4.2.2.3 Source-Data-Free Open-Set Unsupervised Domain Adaptation (SDF-OSUDA): In SDF-OSUDA, the label space of the target domain ${\mathcal{Y}}_{t}$ may include classes that are not present in the label space of the source domain ${\mathcal{Y}}_{s}$ , such that ${\mathcal{Y}}_{s} \subset  {\mathcal{Y}}_{t}$ . In this context, a model $f : {\mathbb{R}}^{H \times  W} \mapsto  {\mathbb{R}}^{C}$ is adapted to a target domain ${D}_{t} = {\left\{  {x}_{j}\right\}  }_{j = 1}^{{N}_{t}}$ that contains only unlabeled samples, without access to labeled data from a source domain ${D}_{s}$ .

4.2.2.3 无源数据开放集无监督领域自适应(SDF-OSUDA):在SDF-OSUDA中，目标域的标签空间${\mathcal{Y}}_{t}$可能包含源域标签空间${\mathcal{Y}}_{s}$中不存在的类别，即${\mathcal{Y}}_{s} \subset  {\mathcal{Y}}_{t}$。在此情境下，模型$f : {\mathbb{R}}^{H \times  W} \mapsto  {\mathbb{R}}^{C}$被适配到仅包含未标记样本的目标域${D}_{t} = {\left\{  {x}_{j}\right\}  }_{j = 1}^{{N}_{t}}$，且无法访问源域${D}_{s}$的标记数据。

The core challenge in SDF-OSUDA lies in jointly achieving reliable detection of target-domain samples from unknown classes and accurate classification of those from known classes, under the constraint of no labeled source data.

SDF-OSUDA的核心挑战在于，在无标记源数据的限制下，既要可靠检测目标域中未知类别的样本，又要准确分类已知类别的样本。

Yu et al. [182] investigates adaptable methods for leveraging CLIP in SF-OSUDA. This approach assumes access to a model pre-trained on source domain samples, using its parameters directly to initialize the model for the target domain. DIFO [155] also addresses the challenges of SF-OSUDA, where the target domain may contain unseen classes. By distilling knowledge from the customized ViL model to the target model, DIFO enhances the model's ability to generalize and recognize novel classes, ensuring robust performance in open-set scenarios while effectively leveraging unlabeled data from the target domain. Zhang et al. [193] further evaluates SDF-OSUDA, showing effective identification of unseen classes while maintaining robust generalization in open-set scenarios.

Yu等人[182]研究了利用CLIP在SF-OSUDA中的可适配方法。该方法假设可访问在源域样本上预训练的模型，直接用其参数初始化目标域模型。DIFO [155]同样应对SF-OSUDA的挑战，目标域可能包含未见类别。通过将定制ViL模型的知识蒸馏到目标模型，DIFO增强了模型的泛化能力和新类别识别能力，确保在开放集场景下的稳健性能，同时有效利用目标域的未标记数据。Zhang等人[193]进一步评估了SDF-OSUDA，展示了在开放集场景中有效识别未见类别并保持稳健泛化能力。

## 5 BENCHMARKS AND METRICS

## 5 基准测试与评估指标

This section introduces common datasets and evaluation metrics used in domain adaptation (DA) and domain generalization (DG). Datasets are typically categorized into mul-tidomain and single-domain types, each suited for different experimental settings. The section also discusses key performance metrics, including accuracy and harmonic mean scores, which are crucial for evaluating model performance, especially in scenarios involving unknown classes in the target domain. These benchmarks and metrics provide a foundation for comparing the effectiveness of various DA and DG methods.

本节介绍领域自适应(DA)和领域泛化(DG)中常用的数据集和评估指标。数据集通常分为多域和单域两类，适用于不同的实验设置。还讨论了关键性能指标，包括准确率和调和平均分，这些指标对于评估模型性能尤为重要，尤其是在目标域包含未知类别的场景中。这些基准和指标为比较各种DA和DG方法的有效性提供了基础。

### 5.1 Common Bechmarks

### 5.1 常用基准

#### 5.1.1 Datasets for DA and DG

#### 5.1.1 DA和DG的数据集

DA and DG both use datasets that can be categorized into multi-domain and single-domain types, as shown in Table 3. In a multidomain dataset, each subset represents a distinct domain with the same categories but different image distributions. In DA and DG experiments, one or more domains act as the source domains-single-source $\left\lbrack  {{35},{78},{146}}\right\rbrack$ or multi-source $\left\lbrack  {{16},{166},{181}}\right\rbrack$ -while the remaining domains serve as target domains to evaluate model performance.

DA和DG均使用可分为多域和单域的数据集，如表3所示。在多域数据集中，每个子集代表一个不同的域，类别相同但图像分布不同。在DA和DG实验中，一个或多个域作为源域——单源$\left\lbrack  {{35},{78},{146}}\right\rbrack$或多源$\left\lbrack  {{16},{166},{181}}\right\rbrack$——其余域作为目标域，用于评估模型性能。

TABLE 3

Common datasets in DG and DA. (#: number)

DG和DA中常用的数据集。(#:数量)

<table><tr><td>Field</td><td>Dataset</td><td>#Domains</td><td>#Categories</td><td>#Images</td><td>Link</td></tr><tr><td rowspan="9">Multi- domain Dataset</td><td>Office-Home [161]</td><td>4</td><td>65</td><td>15,588</td><td>https://faculty.cc.gatech.edu/~judy/domainadapt/</td></tr><tr><td>Office-31 [132]</td><td>3</td><td>31</td><td>4,652</td><td>https://www.hemanthdv.org/officeHomeDataset.html</td></tr><tr><td>VisDA-2017 [121]</td><td>2</td><td>12</td><td>280,000</td><td>https://github.com/VisionLearningGroup/taskcv-2017-public</td></tr><tr><td>DomainNet [122]</td><td>6</td><td>345</td><td>586,575</td><td>https://ai.bu.edu/M3SDA/</td></tr><tr><td>PACS [83]</td><td>4</td><td>7</td><td>9,991</td><td>https://www.kaggle.com/datasets/nickfratto/pacs-dataset</td></tr><tr><td>VLCS [36]</td><td>4</td><td>5</td><td>10,729</td><td>https://www.kaggle.com/datasets/iamjanvijay/vlcsdataset/data</td></tr><tr><td>Digits-DG [201]</td><td>4</td><td>10</td><td>24,000</td><td>https://csip.fzu.edu.cn/files/datasets/SSDG/digits_dg.zip</td></tr><tr><td>TerraIncognita [7]</td><td>4</td><td>10</td><td>24,330</td><td>https://beerys.github.io/CaltechCameraTraps/</td></tr><tr><td>NICO++ [195]</td><td>6</td><td>7</td><td>89,232</td><td>https://github.com/xxgege/NICO-plus</td></tr><tr><td rowspan="17">Single- Domain Dataset</td><td>ImageNet [32]</td><td>1</td><td>1000</td><td>1.28M</td><td>https://www.image-net.org/download.php</td></tr><tr><td>ImageNetV2 [130]</td><td>1</td><td>1000</td><td>10,000</td><td>https://github.com/modestyachts/ImageNetV2</td></tr><tr><td>ImageNet-Sketch [162]</td><td>1</td><td>1000</td><td>50,889</td><td>https://github.com/HaohanWang/ImageNet-Sketch</td></tr><tr><td>ImageNet-A [52]</td><td>1</td><td>200</td><td>7,500</td><td>https://github.com/hendrycks/natural-adv-examples</td></tr><tr><td>ImageNet-R[51]</td><td>1</td><td>200</td><td>30,000</td><td>https://github.com/hendrycks/imagenet-r</td></tr><tr><td>CIFAR10 [75]</td><td>1</td><td>10</td><td>60,000</td><td>https://www.cs.toronto.edu/~kriz/cifar.html</td></tr><tr><td>CIFAR100 [75]</td><td>1</td><td>100</td><td>60,000</td><td>https://www.cs.toronto.edu/~kriz/cifar.html</td></tr><tr><td>Caltech101 [37]</td><td>1</td><td>100</td><td>8,242</td><td>https://www.kaggle.com/datasets/imbikramsaha/caltech-101</td></tr><tr><td>DTD [28]</td><td>1</td><td>47</td><td>5,640</td><td>https://www.robots.ox.ac.uk/~vgg/data/dtd/</td></tr><tr><td>EuroSAT [50]</td><td>1</td><td>10</td><td>2,700</td><td>https://www.kaggle.com/datasets/apollo2506/eurosat-dataset</td></tr><tr><td>FGVCAircraft [107]</td><td>1</td><td>100</td><td>10,000</td><td>https://www.robots.ox.ac.uk/~vgg/data/fgvc-aircraft/</td></tr><tr><td>Food101 [9]</td><td>1</td><td>101</td><td>101,000</td><td>https://www.kaggle.com/datasets/dansbecker/food-101</td></tr><tr><td>Flowers102 [115]</td><td>1</td><td>101</td><td>8,189</td><td>https://www.kaggle.com/datasets/demonplus/flower-dataset-102</td></tr><tr><td>OxfordPets [119]</td><td>1</td><td>37</td><td>7,349</td><td>https://www.kaggle.com/datasets/tanlikesmath/the-oxfordiiit-pet-dataset</td></tr><tr><td>SUN397 [169]</td><td>1</td><td>397</td><td>39,700</td><td>https://huggingface.co/datasets/1aurent/SUN397</td></tr><tr><td>StandfordCars [74]</td><td>1</td><td>196</td><td>16,185</td><td>https://www.kaggle.com/datasets/jessicali9530/stanford-cars-dataset/data</td></tr><tr><td>UCF101 [149]</td><td>1</td><td>101</td><td>13,320</td><td>https://www.kaggle.com/datasets/matthewjansen/ucf101-action-recognition</td></tr></table>

<table><tbody><tr><td>领域</td><td>数据集</td><td>领域数量</td><td>类别数量</td><td>图像数量</td><td>链接</td></tr><tr><td rowspan="9">多领域数据集</td><td>Office-Home [161]</td><td>4</td><td>65</td><td>15,588</td><td>https://faculty.cc.gatech.edu/~judy/domainadapt/</td></tr><tr><td>Office-31 [132]</td><td>3</td><td>31</td><td>4,652</td><td>https://www.hemanthdv.org/officeHomeDataset.html</td></tr><tr><td>VisDA-2017 [121]</td><td>2</td><td>12</td><td>280,000</td><td>https://github.com/VisionLearningGroup/taskcv-2017-public</td></tr><tr><td>DomainNet [122]</td><td>6</td><td>345</td><td>586,575</td><td>https://ai.bu.edu/M3SDA/</td></tr><tr><td>PACS [83]</td><td>4</td><td>7</td><td>9,991</td><td>https://www.kaggle.com/datasets/nickfratto/pacs-dataset</td></tr><tr><td>VLCS [36]</td><td>4</td><td>5</td><td>10,729</td><td>https://www.kaggle.com/datasets/iamjanvijay/vlcsdataset/data</td></tr><tr><td>Digits-DG [201]</td><td>4</td><td>10</td><td>24,000</td><td>https://csip.fzu.edu.cn/files/datasets/SSDG/digits_dg.zip</td></tr><tr><td>TerraIncognita [7]</td><td>4</td><td>10</td><td>24,330</td><td>https://beerys.github.io/CaltechCameraTraps/</td></tr><tr><td>NICO++ [195]</td><td>6</td><td>7</td><td>89,232</td><td>https://github.com/xxgege/NICO-plus</td></tr><tr><td rowspan="17">单领域数据集</td><td>ImageNet [32]</td><td>1</td><td>1000</td><td>1.28M</td><td>https://www.image-net.org/download.php</td></tr><tr><td>ImageNetV2 [130]</td><td>1</td><td>1000</td><td>10,000</td><td>https://github.com/modestyachts/ImageNetV2</td></tr><tr><td>ImageNet-Sketch [162]</td><td>1</td><td>1000</td><td>50,889</td><td>https://github.com/HaohanWang/ImageNet-Sketch</td></tr><tr><td>ImageNet-A [52]</td><td>1</td><td>200</td><td>7,500</td><td>https://github.com/hendrycks/natural-adv-examples</td></tr><tr><td>ImageNet-R[51]</td><td>1</td><td>200</td><td>30,000</td><td>https://github.com/hendrycks/imagenet-r</td></tr><tr><td>CIFAR10 [75]</td><td>1</td><td>10</td><td>60,000</td><td>https://www.cs.toronto.edu/~kriz/cifar.html</td></tr><tr><td>CIFAR100 [75]</td><td>1</td><td>100</td><td>60,000</td><td>https://www.cs.toronto.edu/~kriz/cifar.html</td></tr><tr><td>Caltech101 [37]</td><td>1</td><td>100</td><td>8,242</td><td>https://www.kaggle.com/datasets/imbikramsaha/caltech-101</td></tr><tr><td>DTD [28]</td><td>1</td><td>47</td><td>5,640</td><td>https://www.robots.ox.ac.uk/~vgg/data/dtd/</td></tr><tr><td>EuroSAT [50]</td><td>1</td><td>10</td><td>2,700</td><td>https://www.kaggle.com/datasets/apollo2506/eurosat-dataset</td></tr><tr><td>FGVCAircraft [107]</td><td>1</td><td>100</td><td>10,000</td><td>https://www.robots.ox.ac.uk/~vgg/data/fgvc-aircraft/</td></tr><tr><td>Food101 [9]</td><td>1</td><td>101</td><td>101,000</td><td>https://www.kaggle.com/datasets/dansbecker/food-101</td></tr><tr><td>Flowers102 [115]</td><td>1</td><td>101</td><td>8,189</td><td>https://www.kaggle.com/datasets/demonplus/flower-dataset-102</td></tr><tr><td>OxfordPets [119]</td><td>1</td><td>37</td><td>7,349</td><td>https://www.kaggle.com/datasets/tanlikesmath/the-oxfordiiit-pet-dataset</td></tr><tr><td>SUN397 [169]</td><td>1</td><td>397</td><td>39,700</td><td>https://huggingface.co/datasets/1aurent/SUN397</td></tr><tr><td>StandfordCars [74]</td><td>1</td><td>196</td><td>16,185</td><td>https://www.kaggle.com/datasets/jessicali9530/stanford-cars-dataset/data</td></tr><tr><td>UCF101 [149]</td><td>1</td><td>101</td><td>13,320</td><td>https://www.kaggle.com/datasets/matthewjansen/ucf101-action-recognition</td></tr></tbody></table>

The primary difference between DA and DG lies in their respective training and evaluation approaches: DA [46, 78, 89] typically uses labeled source domains and unlabeled target domains, which are jointly trained before testing in the target domain, while DG $\left\lbrack  {6,8,{194}}\right\rbrack$ involves training on one or more labeled source domains, and, after source training, testing is conducted directly in the target domain without additional adaptation.

DA(领域自适应)和DG(领域泛化)之间的主要区别在于各自的训练和评估方法:DA [46, 78, 89] 通常使用有标签的源域和无标签的目标域，二者联合训练后在目标域进行测试，而DG $\left\lbrack  {6,8,{194}}\right\rbrack$ 则是在一个或多个有标签的源域上训练，训练完成后直接在目标域测试，无需额外的适应步骤。

Single-domain datasets, used in SFF-DA methods [56, 57], leverage CLIP's zero-shot capabilities for unsupervised training and adaptation. Datasets like ImageNet and its variants-ImageNetV2, ImageNet-Sketch, ImageNet-A, and ImageNet-R-serve as benchmarks for evaluating domain generalization in few-shot prompt learning.

单域数据集，在SFF-DA方法[56, 57]中使用，利用CLIP的零样本能力进行无监督训练和适应。像ImageNet及其变体——ImageNetV2、ImageNet-Sketch、ImageNet-A和ImageNet-R——作为少样本提示学习中领域泛化的基准数据集。

### 5.2 Common Metrics

### 5.2 常用指标

Both DA and DG methods evaluate performance in the target domain. For DA, metrics depend on the category shift between source set ${\mathcal{Y}}_{s}$ and target set ${\mathcal{Y}}_{t}$ . For DG, metrics are based on the shift between predefined ${\mathcal{Y}}_{s}$ and the actual target set ${\mathcal{Y}}_{t}$ . Specifically:

DA和DG方法均在目标域评估性能。对于DA，指标依赖于源集 ${\mathcal{Y}}_{s}$ 与目标集 ${\mathcal{Y}}_{t}$ 之间的类别分布变化；对于DG，指标基于预定义的 ${\mathcal{Y}}_{s}$ 与实际目标集 ${\mathcal{Y}}_{t}$ 之间的分布差异。具体如下:

1. For ${\mathcal{Y}}_{s} = {\mathcal{Y}}_{t}$ or ${\mathcal{Y}}_{t} \subset  {\mathcal{Y}}_{s}$ with ${\mathcal{Y}}_{s} \smallsetminus  {\mathcal{Y}}_{t} \neq  \varnothing$ cases (i.e., closed-set and partial-set scenarios): As there are no unknown classes in the target domain, prior methods typically use either the average class accuracy (ACC) or domain average accuracy across all transfer tasks to evaluate performance.

1. 对于 ${\mathcal{Y}}_{s} = {\mathcal{Y}}_{t}$ 或 ${\mathcal{Y}}_{t} \subset  {\mathcal{Y}}_{s}$ 含有 ${\mathcal{Y}}_{s} \smallsetminus  {\mathcal{Y}}_{t} \neq  \varnothing$ 情况(即闭集和部分集场景):由于目标域中不存在未知类别，先前方法通常使用平均类别准确率(ACC)或所有迁移任务的域平均准确率来评估性能。

2. For ${\mathcal{Y}}_{s} \subset  {\mathcal{Y}}_{t}$ with ${\mathcal{Y}}_{t} \smallsetminus  {\mathcal{Y}}_{s} \neq  \varnothing$ or ${\mathcal{Y}}_{s} \cap  {\mathcal{Y}}_{t} \neq  \varnothing ,{\mathcal{Y}}_{t} \nsubseteq  {\mathcal{Y}}_{s}$ , with ${\mathcal{Y}}_{s} \nsubseteq  {\mathcal{Y}}_{t}$ cases (i.e., open-set and open-partial-set scenarios): During target domain evaluation, we commonly define ${\mathcal{Y}}_{\text{shared }} = {\mathcal{Y}}_{s} \cap  {\mathcal{Y}}_{t}$ as the set of shared classes. Samples within ${\mathcal{Y}}_{\text{shared }}$ in the target domain are considered known classes, while others are treated as unknown classes. All unknown classes are grouped into a unified "unknown" category. For evaluation, the model must identify these unknown class samples, and performance is measured using the harmonic mean of the known class accuracy (ACC) and unknown class detection accuracy (AUC), calculated as

2. 对于 ${\mathcal{Y}}_{s} \subset  {\mathcal{Y}}_{t}$ 含有 ${\mathcal{Y}}_{t} \smallsetminus  {\mathcal{Y}}_{s} \neq  \varnothing$ 或 ${\mathcal{Y}}_{s} \cap  {\mathcal{Y}}_{t} \neq  \varnothing ,{\mathcal{Y}}_{t} \nsubseteq  {\mathcal{Y}}_{s}$ ，且存在 ${\mathcal{Y}}_{s} \nsubseteq  {\mathcal{Y}}_{t}$ 情况(即开放集和开放部分集场景):在目标域评估时，通常将 ${\mathcal{Y}}_{\text{shared }} = {\mathcal{Y}}_{s} \cap  {\mathcal{Y}}_{t}$ 定义为共享类别集合。目标域中属于 ${\mathcal{Y}}_{\text{shared }}$ 的样本视为已知类别，其他样本视为未知类别。所有未知类别合并为统一的“未知”类别。评估时，模型需识别这些未知类别样本，性能通过已知类别准确率(ACC)和未知类别检测准确率(AUC)的调和平均值衡量，计算公式为

$$
{HOS} = \frac{2 \times  {AC}{C}_{\text{know }} \times  {AC}{C}_{\text{unknow }}}{{AC}{C}_{\text{know }} + {AC}{C}_{\text{unknow }}}. \tag{1}
$$

Notably, some methods use per-class accuracy for ${AC}{C}_{\text{know }}$ (e.g., UEO [94], DIFO [155]), while others calculate accuracy across all known class samples (e.g., ODA with CLIP [182]).

值得注意的是，一些方法对 ${AC}{C}_{\text{know }}$ 使用每类准确率(如UEO [94]、DIFO [155])，而其他方法则计算所有已知类别样本的整体准确率(如基于CLIP的ODA [182])。

## 6 CHALLENGES AND OPPORTUNITIES

## 6 挑战与机遇

CLIP-Powered Domain Generalization and Adaptation encounter several critical challenges that significantly affect their effectiveness and usability. Addressing these challenges is essential for improving model performance and ensuring robust deployment in various applications.

基于CLIP的领域泛化与适应面临若干关键挑战，这些挑战显著影响其效果和可用性。解决这些问题对于提升模型性能和确保在多种应用中的稳健部署至关重要。

Model Interpretability. CLIP-powered models often lack interpretability $\left\lbrack  {{30},{136}}\right\rbrack$ , making it challenging to understand how they arrive at decisions-especially in critical applications like healthcare, where transparency is vital. Attention mechanisms and feature attribution improve explainability by highlighting influential features, helping enhance trust, facilitate debugging, and optimize performance where understanding model reasoning is essential.

模型可解释性。基于CLIP的模型通常缺乏可解释性 $\left\lbrack  {{30},{136}}\right\rbrack$ ，难以理解其决策过程——尤其在医疗等关键应用中，透明性至关重要。注意力机制和特征归因通过突出关键特征提升解释性，有助于增强信任、便于调试并优化性能，特别是在需要理解模型推理的场景中。

Overfitting. Overfitting occurs when CLIP-powered models perform well on the source domain but fail to generalize to unseen targets, often due to limited or imbalanced data. This is especially problematic in domain generalization, where models may learn spurious correlations over domain-invariant features. Techniques like dropout, weight regularization, and data augmentation introduce variability to improve robustness. Recent methods, such as meta-learning and domain adversarial training, simulate domain shifts to promote transferable feature learning, thereby reducing overfitting and enhancing generalization.

过拟合。过拟合指基于CLIP的模型在源域表现良好但无法泛化到未见目标域，常因数据有限或不平衡导致。在领域泛化中尤为突出，模型可能学习到域不变特征上的虚假相关。通过dropout、权重正则化和数据增强等技术引入多样性以提升鲁棒性。近期方法如元学习和领域对抗训练模拟域变化，促进可迁移特征学习，从而减少过拟合并增强泛化能力。

Limited Labeled Data. The scarcity of labeled data in target domains poses a key challenge for CLIP-powered domain adaptation, where supervised learning relies on abundant annotations. This limitation hampers transfer performance, especially under large domain shifts. To mitigate this, unsupervised and semi-supervised strategies-such as pseudo-labeling, few-/zero-shot learning, and leveraging auxiliary source data-are commonly used. These methods help models learn useful patterns with minimal supervision, boosting adaptability to new domains while reducing annotation costs.

标注数据有限。目标域中标注数据的稀缺是CLIP驱动的领域自适应面临的关键挑战，监督学习依赖大量注释。这一限制尤其在大域偏移下阻碍了迁移性能。为缓解此问题，常用无监督和半监督策略，如伪标签、少样本/零样本学习及利用辅助源数据。这些方法帮助模型在最小监督下学习有用模式，提升对新领域的适应性，同时降低标注成本。

Domain Diversity. Domain diversity poses challenges due to variations in lighting, background, object pose, and style across domains, leading to domain shifts that degrade performance. Robust architectures and training strategies-such as multi-task learning and domain-invariant representation learning-promote knowledge sharing and focus on generalizable features. Additionally, contrastive learning and feature alignment help bridge domain gaps, enhancing adaptability to diverse and unseen environments.

领域多样性。领域多样性带来挑战，因不同领域间光照、背景、物体姿态和风格的变化导致域偏移，进而降低性能。稳健的架构和训练策略，如多任务学习和领域不变表示学习，促进知识共享并聚焦于可泛化特征。此外，对比学习和特征对齐有助于弥合领域差距，增强对多样且未见环境的适应能力。

Computational Efficiency. The high computational cost of CLIP-based models, due to their large architectures and multimodal embeddings, poses challenges for real-time or resource-constrained applications, limiting their practicality in scenarios like edge computing or mobile deployment. To address this, compression techniques such as knowledge distillation, pruning, and quantization reduce memory and computation overhead, aiming to maintain performance while improving efficiency for broader and more flexible deployment.

计算效率。基于CLIP的模型因其庞大架构和多模态嵌入导致计算成本高昂，给实时或资源受限应用带来挑战，限制了其在边缘计算或移动部署等场景的实用性。为此，采用知识蒸馏、剪枝和量化等压缩技术以降低内存和计算开销，旨在保持性能的同时提升效率，实现更广泛灵活的部署。

Catastrophic Forgetting. Fine-tuning CLIP-powered models on new domain data can lead to catastrophic forgetting $\left\lbrack  {2,{19},{69}}\right\rbrack$ , where previous knowledge is overwritten by new information, undermining the model's performance across tasks or domains. To address this, regularization-based methods penalize drastic changes in important parameters, while rehearsal-based strategies retrain the model using old data to reinforce prior knowledge. More recent solutions include memory-efficient continual learning and parameter-isolation techniques, preserving past capabilities without sacrificing adaptation. These methods are crucial for maintaining long-term stability and generalization in dynamic environments.

灾难性遗忘。在新领域数据上微调CLIP驱动模型可能导致灾难性遗忘$\left\lbrack  {2,{19},{69}}\right\rbrack$，即新信息覆盖旧知识，削弱模型在多任务或多领域上的表现。为解决此问题，基于正则化的方法惩罚重要参数的剧烈变化，基于重放的策略则通过旧数据再训练强化先前知识。近期方案包括内存高效的持续学习和参数隔离技术，在不牺牲适应性的前提下保留过去能力。这些方法对动态环境中维持长期稳定性和泛化能力至关重要。

## 7 FUTURE DIRECTIONS

## 7 未来方向

As CLIP-powered DG and DA evolve, future research should focus on addressing current limitations and unlocking new potentials for broader applications. This will involve tackling challenges that enhance the models' capabilities, allowing for more effective and reliable deployment across various domains.

随着CLIP驱动的领域泛化(DG)和领域自适应(DA)发展，未来研究应聚焦于解决现有限制并挖掘更广泛应用的新潜力。这将涉及提升模型能力的挑战，使其能更有效、可靠地部署于各类领域。

Interpretable CLIP-Powered Models. Improving the interpretability of CLIP-powered models is crucial for critical applications like healthcare and finance, where transparency is vital $\left\lbrack  {{30},{198}}\right\rbrack$ . Future research could explore explainable AI techniques [136] to enhance model transparency, such as interactive visualizations and human-understandable explanations. This would improve user trust and facilitate collaboration between human experts and AI systems, leading to more responsible deployment.

可解释的CLIP驱动模型。提升CLIP驱动模型的可解释性对医疗和金融等关键应用至关重要，因透明性是核心需求$\left\lbrack  {{30},{198}}\right\rbrack$。未来研究可探索可解释人工智能技术[136]，如交互式可视化和人类可理解的解释，以增强模型透明度。这将提升用户信任，促进人类专家与AI系统的协作，实现更负责任的部署。

Robustness Against Domain Shifts. Addressing domain shifts is a key challenge in domain generalization and adaptation. Future research may focus on robust training frameworks, like adversarial training or meta-learning, to help CLIP-powered models maintain performance in dynamic environments. These approaches could enable better handling of real-world variations and improve model robustness across diverse applications.

对抗领域偏移的鲁棒性。应对领域偏移是领域泛化和自适应的关键挑战。未来研究可聚焦于稳健训练框架，如对抗训练或元学习，帮助CLIP驱动模型在动态环境中保持性能。这些方法将提升模型对现实世界变化的处理能力，增强其在多样应用中的鲁棒性。

Automated Domain Discovery. Automated methods for discovering and characterizing target domains could be explored, using unsupervised clustering to identify distinct domains from unlabeled data. Advanced clustering and dimensionality reduction algorithms could uncover patterns, while self-assessment mechanisms would improve model adaptability, enhancing CLIP-powered systems' robustness.

自动领域发现。可探索自动发现和表征目标领域的方法，利用无监督聚类从未标注数据中识别不同领域。先进的聚类和降维算法可揭示潜在模式，自我评估机制则提升模型适应性，增强CLIP驱动系统的鲁棒性。

Scalable Computational Strategies. Scalable computational strategies for CLIP-based models can be explored through techniques like model pruning, quantization, and distributed computing (cloud and edge platforms) to reduce complexity while maintaining performance. Hybrid approaches combining local and cloud resources could enhance scalability and reduce latency, making CLIP models more accessible.

可扩展计算策略。可通过模型剪枝、量化及分布式计算(云端和边缘平台)等技术探索CLIP模型的可扩展计算策略，以降低复杂度同时保持性能。结合本地与云资源的混合方法可提升可扩展性并减少延迟，使CLIP模型更易获取。

Integration of Multimodal Data. Integrating multimodal data, such as text, images, audio, and sensor data [165], can enhance CLIP model performance [58]. Developing architectures that fuse multiple data types can improve generalization and adaptability, while cross-modal learning can boost effectiveness, enabling models to address diverse real-world challenges.

多模态数据整合。整合文本、图像、音频及传感器数据[165]等多模态信息可提升CLIP模型性能[58]。开发融合多种数据类型的架构可增强泛化和适应能力，跨模态学习则能提升效果，使模型应对多样现实挑战。

Addressing Catastrophic Forgetting. Catastrophic forgetting is a significant challenge in fine-tuning CLIP models, especially in dynamic environments. To address this, techniques like memory-augmented architectures, regularization with dynamic replay, and meta-learning can help models retain prior knowledge while adapting to new tasks $\left\lbrack  {{31},{160}}\right\rbrack$ . These strategies can improve the model's long-term robustness in real-world applications.

解决灾难性遗忘。灾难性遗忘是微调CLIP模型时的重大挑战，尤其在动态环境中。为此，采用记忆增强架构、动态重放正则化和元学习等技术，帮助模型在适应新任务的同时保留先前知识$\left\lbrack  {{31},{160}}\right\rbrack$。这些策略可提升模型在实际应用中的长期鲁棒性。

![bo_d282qmv7aajc738ormjg_13_149_121_717_694_0.jpg](images/bo_d282qmv7aajc738ormjg_13_149_121_717_694_0.jpg)

Fig. 12. Percentage of cited papers in different sections.

图12. 不同章节中被引用论文的百分比。

Ethical Considerations and Bias Mitigation. Ethical deployment of CLIP models involves addressing biases by conducting audits across diverse demographics and applying fairness-aware learning techniques. Engaging stakehold-ers in the development process ensures that the models are inclusive, promoting fairness and robustness while mitigating potential biases in CLIP applications.

伦理考量与偏见缓解。CLIP模型的伦理部署涉及通过对不同群体进行审计和应用公平感知学习技术来解决偏见。让利益相关者参与开发过程，确保模型包容性，促进公平与鲁棒性，同时减轻CLIP应用中的潜在偏见。

## 8 CONCLUSION

## 8 结论

This survey provides an overview of CLIP's applications in domain generalization (DG) and domain adaptation (DA), emphasizing its zero-shot capabilities for handling unseen domains without extensive retraining. It explores methodologies such as prompt learning optimization and CLIP as a backbone architecture to enhance generalization and adaptation strategies. Key challenges like overfitting, domain shifts, and limited labeled data are addressed, along with gaps in existing literature. Fig. 12 visualizes the distribution of CLIP-based approaches in DG and DA, offering insights into their prevalence. By identifying future research directions, this survey encourages further innovation, aiming to improve the robustness, interpretability, and adaptability of CLIP-powered AI systems. REFERENCES

本综述概述了CLIP在领域泛化(DG)和领域适应(DA)中的应用，强调其零样本能力，能够在无需大量重新训练的情况下处理未见领域。文中探讨了如提示学习优化和将CLIP作为骨干架构等方法，以增强泛化和适应策略。重点解决了过拟合、领域偏移和标注数据有限等关键挑战，并指出了现有文献中的不足。图12展示了基于CLIP的方法在DG和DA中的分布，提供了其普及程度的洞见。通过明确未来研究方向，本综述鼓励进一步创新，旨在提升基于CLIP的人工智能系统的鲁棒性、可解释性和适应性。REFERENCES

[1] S. Addepalli, A. R. Asokan, L. Sharma, and R. V. Babu. Leveraging vision-language models for improving domain generalization in image classification. In Proc. of CVPR, pages 23922-23932, 2024.

[1] S. Addepalli, A. R. Asokan, L. Sharma, and R. V. Babu. 利用视觉-语言模型提升图像分类中的领域泛化能力。发表于CVPR会议论文集，页码23922-23932，2024年。

[2] E. L. Aleixo, J. G. Colonna, M. Cristo, and E. Fernandes. Catastrophic forgetting in deep learning: a comprehensive taxonomy. arXiv:2312.10549, 2023.

[2] E. L. Aleixo, J. G. Colonna, M. Cristo, and E. Fernandes. 深度学习中的灾难性遗忘:全面分类。arXiv:2312.10549, 2023年。

[3] E. Ali, S. Silva, and M. H. Khan. Dpa: Dual prototypes alignment for unsupervised adaptation of vision-language models. arXiv:2408.08855, 2024.

[3] E. Ali, S. Silva, and M. H. Khan. DPA:用于视觉-语言模型无监督适应的双原型对齐。arXiv:2408.08855, 2024年。

[4] H. Bahng, A. Jahanian, S. Sankaranarayanan, and P. Isola. Visual prompting: Modifying pixel space to adapt pre-trained models. arXiv:2203.17274, 3(11-12): 3, 2022.

[4] H. Bahng, A. Jahanian, S. Sankaranarayanan, and P. Isola. 视觉提示:通过修改像素空间以适应预训练模型。arXiv:2203.17274, 3(11-12): 3, 2022年。

[5] S. Bai, M. Zhang, W. Zhou, S. Huang, Z. Luan, D. Wang, and B. Chen. Prompt-based distribution alignment for unsupervised domain adaptation. In Proc. of AAAI, volume 38, pages 729-737, 2024.

[5] S. Bai, M. Zhang, W. Zhou, S. Huang, Z. Luan, D. Wang, and B. Chen. 基于提示的分布对齐用于无监督领域适应。发表于AAAI会议论文集，卷38，页729-737，2024年。

[6] S. Bai, Y. Zhang, W. Zhou, Z. Luan, and B. Chen. Soft prompt generation for domain generalization. arXiv:2404.19286, 2024.

[6] S. Bai, Y. Zhang, W. Zhou, Z. Luan, and B. Chen. 软提示生成用于领域泛化。arXiv:2404.19286, 2024年。

[7] S. Beery, G. Van Horn, and P. Perona. Recognition in terra incognita. In Proc. of ECCV, pages 456-473, 2018.

[7] S. Beery, G. Van Horn, and P. Perona. 未知领域中的识别。发表于ECCV会议论文集，页456-473，2018年。

[8] S. Bose, A. Jha, E. Fini, M. Singha, E. Ricci, and B. Banerjee. Stylip: Multi-scale style-conditioned prompt learning for clip-based domain generalization. In Proc. of WACV, pages 5542-5552, 2024.

[8] S. Bose, A. Jha, E. Fini, M. Singha, E. Ricci, and B. Banerjee. Stylip:基于多尺度风格条件的提示学习用于基于CLIP的领域泛化。发表于WACV会议论文集，页5542-5552，2024年。

[9] L. Bossard, M. Guillaumin, and L. Van Gool. Food- 101-mining discriminative components with random forests. In Proc. of ECCV, pages 446-461. Springer, 2014.

[9] L. Bossard, M. Guillaumin, and L. Van Gool. Food-101:利用随机森林挖掘判别成分。发表于ECCV会议论文集，页446-461。Springer出版社，2014年。

[10] S. Bucci, F. C. Borlino, B. Caputo, and T. Tommasi. Distance-based hyperspherical classification for multi-source open-set domain adaptation. In Proc. of WACV, pages 1119-1128, 2022.

[10] S. Bucci, F. C. Borlino, B. Caputo, and T. Tommasi. 基于距离的超球面分类用于多源开放集领域适应。发表于WACV会议论文集，页1119-1128，2022年。

[11] H. Cai, C. Gan, L. Zhu, and S. Han. Tinyll: Reduce memory, not parameters for efficient on-device learning. Proc. of NeurIPS, 33:11285-11297, 2020.

[11] H. Cai, C. Gan, L. Zhu, and S. Han. TinyLL:减少内存而非参数，实现高效的设备端学习。发表于NeurIPS会议论文集，33卷，页11285-11297，2020年。

[12] J. Cha, S. Chun, K. Lee, H.-C. Cho, S. Park, Y. Lee, and S. Park. Swad: Domain generalization by seeking flat minima. Proc. of NeurIPS, 34:22405-22418, 2021.

[12] J. Cha, S. Chun, K. Lee, H.-C. Cho, S. Park, Y. Lee, and S. Park. SWAD:通过寻找平坦极小值实现领域泛化。发表于NeurIPS会议论文集，34卷，页22405-22418，2021年。

[13] X. Che, H. Zuo, J. Lu, and D. Chen. Fuzzy multioutput transfer learning for regression. IEEE Trans. on Fuzzy Systems, 30(7):2438-2451, 2021.

[13] X. Che, H. Zuo, J. Lu, and D. Chen. 模糊多输出迁移学习用于回归。IEEE模糊系统汇刊，30(7):2438-2451，2021年。

[14] G. Chen, W. Yao, X. Song, X. Li, Y. Rao, and K. Zhang. Prompt learning with optimal transport for vision-language models. OpenReview, 2022.

[14] G. Chen, W. Yao, X. Song, X. Li, Y. Rao, and K. Zhang. 基于最优传输的视觉-语言模型提示学习。OpenReview, 2022年。

[15] G. Chen, W. Yao, X. Song, X. Li, Y. Rao, and K. Zhang. Plot: Prompt learning with optimal transport for vision-language models. arXiv:2210.01253, 2022.

[15] G. Chen, W. Yao, X. Song, X. Li, Y. Rao, and K. Zhang. PLOT:基于最优传输的视觉-语言模型提示学习。arXiv:2210.01253, 2022年。

[16] H. Chen, X. Han, Z. Wu, and Y.-G. Jiang. Multi-prompt alignment for multi-source unsupervised domain adaptation. Proc. of NeurIPS, 36:74127-74139, 2023.

[16] H. Chen, X. Han, Z. Wu, 和 Y.-G. Jiang. 多提示对齐用于多源无监督领域自适应。NeurIPS 会议录, 36:74127-74139, 2023。

[17] S. Chen, C. Ge, Z. Tong, J. Wang, Y. Song, J. Wang, and P. Luo. Adaptformer: Adapting vision transformers for scalable visual recognition. Proc. of NeurIPS, 35: 16664-16678, 2022.

[17] S. Chen, C. Ge, Z. Tong, J. Wang, Y. Song, J. Wang, 和 P. Luo. Adaptformer:用于可扩展视觉识别的视觉变换器适配器。NeurIPS 会议录, 35:16664-16678, 2022。

[18] T. Chen, S. Kornblith, M. Norouzi, and G. Hinton. A simple framework for contrastive learning of visual representations. In Proc. of ICML, pages 1597-1607. PMLR, 2020.

[18] T. Chen, S. Kornblith, M. Norouzi, 和 G. Hinton. 一种用于视觉表征对比学习的简单框架。ICML 会议录, 页1597-1607。PMLR, 2020。

[19] Z. Chen and B. Liu. Continual learning and catastrophic forgetting. In Lifelong Machine Learning, pages 55-75. Springer, 2018.

[19] Z. Chen 和 B. Liu. 持续学习与灾难性遗忘。载于《终身机器学习》, 页55-75。Springer, 2018。

[20] Z. Chen, Y. Duan, W. Wang, J. He, T. Lu, J. Dai, and Y. Qiao. Vision transformer adapter for dense predictions. arXiv:2205.08534, 2022.

[20] Z. Chen, Y. Duan, W. Wang, J. He, T. Lu, J. Dai, 和 Y. Qiao. 用于密集预测的视觉变换器适配器。arXiv:2205.08534, 2022。

[21] Z. Chen, W. Wang, Z. Zhao, F. Su, A. Men, and Y. Dong. Instance paradigm contrastive learning for domain generalization. IEEE TCSVT, 34(2):1032-1042, 2023.

[21] Z. Chen, W. Wang, Z. Zhao, F. Su, A. Men, 和 Y. Dong. 用于领域泛化的实例范式对比学习。IEEE TCSVT, 34(2):1032-1042, 2023。

[22] Z. Chen, W. Wang, Z. Zhao, F. Su, A. Men, and H. Meng. Practicaldg: Perturbation distillation on vision-language models for hybrid domain generalization. In Proc. of CVPR, pages 23501-23511, 2024.

[22] Z. Chen, W. Wang, Z. Zhao, F. Su, A. Men, 和 H. Meng. PracticalDG:基于视觉-语言模型的扰动蒸馏用于混合领域泛化。CVPR 会议录, 页23501-23511, 2024。

[23] D. Cheng, Z. Xu, X. Jiang, N. Wang, D. Li, and X. Gao. Disentangled prompt representation for domain generalization. In Proc. of CVPR, pages 23595-23604, 2024.

[23] D. Cheng, Z. Xu, X. Jiang, N. Wang, D. Li, 和 X. Gao. 用于领域泛化的解耦提示表示。CVPR 会议录, 页23595-23604, 2024。

[24] E. Cho, J. Kim, and H. J. Kim. Distribution-aware prompt tuning for vision-language models. In Proc. of ICCV, pages 22004-22013, 2023.

[24] E. Cho, J. Kim, 和 H. J. Kim. 面向视觉-语言模型的分布感知提示调优。ICCV 会议录, 页22004-22013, 2023。

[25] J. Cho, G. Nam, S. Kim, H. Yang, and S. Kwak. Promptstyler: Prompt-driven style generation for source-free domain generalization. In Proc. of ICCV, pages 15702-15712, 2023.

[25] J. Cho, G. Nam, S. Kim, H. Yang, 和 S. Kwak. PromptStyler:无源领域泛化的提示驱动风格生成。ICCV 会议录, 页15702-15712, 2023。

[26] J. Choi, M. Jeong, T. Kim, and C. Kim. Pseudo-labeling curriculum for unsupervised domain adaptation. arXiv:1908.00262, 2019.

[26] J. Choi, M. Jeong, T. Kim, 和 C. Kim. 用于无监督领域自适应的伪标签课程。arXiv:1908.00262, 2019。

[27] S. Choi, D. Das, S. Choi, S. Yang, H. Park, and S. Yun. Progressive random convolutions for single domain generalization. In Proc. of CVPR, pages 10312-10322, 2023.

[27] S. Choi, D. Das, S. Choi, S. Yang, H. Park, 和 S. Yun. 用于单领域泛化的渐进随机卷积。CVPR 会议录, 页10312-10322, 2023。

[28] M. Cimpoi, S. Maji, I. Kokkinos, S. Mohamed, and A. Vedaldi. Describing textures in the wild. In Proc. of CVPR, pages 3606-3613, 2014.

[28] M. Cimpoi, S. Maji, I. Kokkinos, S. Mohamed, 和 A. Vedaldi. 野外纹理描述。CVPR 会议录, 页3606-3613, 2014。

[29] E. D. Cubuk, B. Zoph, J. Shlens, and Q. V. Le. Ran-daugment: Practical automated data augmentation with a reduced search space. In Proc. of CVPR Workshop, pages 702-703, 2020.

[29] E. D. Cubuk, B. Zoph, J. Shlens, 和 Q. V. Le. RandAugment:具有缩减搜索空间的实用自动数据增强。CVPR 研讨会论文集, 页702-703, 2020。

[30] A. Das and P. Rad. Opportunities and challenges in explainable artificial intelligence (xai): A survey. arXiv:2006.11371, 2020.

[30] A. Das 和 P. Rad. 可解释人工智能(XAI)的机遇与挑战:综述。arXiv:2006.11371, 2020。

[31] M. De Lange, R. Aljundi, M. Masana, S. Parisot, X. Jia, A. Leonardis, G. Slabaugh, and T. Tuytelaars. A continual learning survey: Defying forgetting in classification tasks. IEEE TPAMI, 44(7):3366-3385, 2021.

[31] M. De Lange, R. Aljundi, M. Masana, S. Parisot, X. Jia, A. Leonardis, G. Slabaugh, 和 T. Tuytelaars. 持续学习综述:在分类任务中抵抗遗忘。IEEE TPAMI, 44(7):3366-3385, 2021。

[32] J. Deng, W. Dong, R. Socher, L.-J. Li, K. Li, and L. Fei-Fei. Imagenet: A large-scale hierarchical image database. In Proc. of CVPR, pages 248-255. IEEE, 2009.

[32] J. Deng, W. Dong, R. Socher, L.-J. Li, K. Li, 和 L. Fei-Fei. Imagenet: 一个大规模分层图像数据库。发表于CVPR会议论文集，页码248-255。IEEE, 2009。

[33] K. Desai and J. Johnson. Virtex: Learning visual representations from textual annotations. In Proc. of CVPR, pages 11162-11173, 2021.

[33] K. Desai 和 J. Johnson. Virtex: 从文本注释中学习视觉表示。发表于CVPR会议论文集，页码11162-11173，2021。

[34] X. Dong, J. Bao, Y. Zheng, T. Zhang, D. Chen, H. Yang, M. Zeng, W. Zhang, L. Yuan, D. Chen, et al. Maskclip: Masked self-distillation advances contrastive language-image pretraining. In Proc. of CVPR, pages 10995-11005, 2023.

[34] X. Dong, J. Bao, Y. Zheng, T. Zhang, D. Chen, H. Yang, M. Zeng, W. Zhang, L. Yuan, D. Chen 等. Maskclip: 掩码自蒸馏推动对比语言-图像预训练。发表于CVPR会议论文集，页码10995-11005，2023。

[35] Z. Du, X. Li, F. Li, K. Lu, L. Zhu, and J. Li. Domain-agnostic mutual prompting for unsupervised domain adaptation. In Proc. of CVPR, pages 23375-23384, 2024.

[35] Z. Du, X. Li, F. Li, K. Lu, L. Zhu, 和 J. Li. 无监督领域自适应的领域无关互促方法。发表于CVPR会议论文集，页码23375-23384，2024。

[36] Chen Fang, Ye Xu, and Daniel N Rockmore. Unbiased metric learning: On the utilization of multiple datasets and web images for softening bias. In Proc. of ICCV, pages 1657-1664, 2013.

[36] Chen Fang, Ye Xu, 和 Daniel N Rockmore. 无偏度量学习:关于多数据集和网络图像利用以缓解偏差。发表于ICCV会议论文集，页码1657-1664，2013。

[37] L. Fei-Fei, R. Fergus, and P. Perona. Learning generative visual models from few training examples: An incremental bayesian approach tested on 101 object categories. In Proc. of CVPR Workshop, pages 178-178. IEEE, 2004.

[37] L. Fei-Fei, R. Fergus, 和 P. Perona. 从少量训练样本学习生成视觉模型:一种增量贝叶斯方法，在101个物体类别上测试。发表于CVPR研讨会论文集，页码178-178。IEEE, 2004。

[38] R. Feng, T. Yu, X. Jin, X. Yu, L. Xiao, and Z. Chen. Rethinking domain adaptation and generalization in the era of clip. In Proc. of ICIP, pages 2585-2591. IEEE, 2024.

[38] R. Feng, T. Yu, X. Jin, X. Yu, L. Xiao, 和 Z. Chen. 在CLIP时代重新思考领域自适应与泛化。发表于ICIP会议论文集，页码2585-2591。IEEE, 2024。

[39] A. Fürst, E. Rumetshofer, J. Lehner, V. T. Tran, F. Tang, H. Ramsauer, D. Kreil, M. Kopp, G. Klambauer, A. Bitto, et al. Cloob: Modern hopfield networks with infoloob outperform clip. Proc. of NeurIPS, 35:20450- 20468, 2022.

[39] A. Fürst, E. Rumetshofer, J. Lehner, V. T. Tran, F. Tang, H. Ramsauer, D. Kreil, M. Kopp, G. Klambauer, A. Bitto 等. Cloob: 采用InfoLoob的现代Hopfield网络优于CLIP。发表于NeurIPS，卷35，页20450-20468，2022。

[40] R. Gal, O. Patashnik, H. Maron, A. H. Bermano, G. Chechik, and D. Cohen-Or. Stylegan-nada: Clip-guided domain adaptation of image generators. ACM TOG, 41(4):1-13, 2022.

[40] R. Gal, O. Patashnik, H. Maron, A. H. Bermano, G. Chechik, 和 D. Cohen-Or. Stylegan-nada: 基于CLIP引导的图像生成器领域自适应。ACM TOG，41(4):1-13，2022。

[41] Y. Gal and Z. Ghahramani. Dropout as a bayesian approximation: Representing model uncertainty in deep learning. In Proc. of ICML, pages 1050-1059, 2016.

[41] Y. Gal 和 Z. Ghahramani. Dropout作为贝叶斯近似:在深度学习中表示模型不确定性。发表于ICML会议论文集，页码1050-1059，2016。

[42] Z. Gan, L. Li, C. Li, L. Wang, Z. Liu, J. Gao, et al. Vision-language pre-training: Basics, recent advances, and future trends. FTCGV, 14(3-4):163-352, 2022.

[42] Z. Gan, L. Li, C. Li, L. Wang, Z. Liu, J. Gao 等. 视觉-语言预训练:基础、最新进展与未来趋势。FTCGV，14(3-4):163-352，2022。

[43] J. Gao, J. Ruan, S. Xiang, Z. Yu, K. Ji, M. Xie, T. Liu, and Y. Fu. Lamm: Label alignment for multi-modal prompt learning. In Proc. of AAAI, volume 38, pages 1815-1823, 2024.

[43] J. Gao, J. Ruan, S. Xiang, Z. Yu, K. Ji, M. Xie, T. Liu, 和 Y. Fu. Lamm: 多模态提示学习的标签对齐。发表于AAAI会议论文集，卷38，页1815-1823，2024。

[44] P. Gao, S. Geng, R. Zhang, T. Ma, R. Fang, Y. Zhang, H. Li, and Y. Qiao. Clip-adapter: Better vision-language models with feature adapters. IJCV, 132(2): 581-595, 2024.

[44] P. Gao, S. Geng, R. Zhang, T. Ma, R. Fang, Y. Zhang, H. Li, 和 Y. Qiao. Clip-adapter: 通过特征适配器提升视觉-语言模型。IJCV，132(2):581-595，2024。

[45] T. Gao, A. Fisch, and D. Chen. Making pre-trained language models better few-shot learners. arXiv:2012.15723, 2020.

[45] T. Gao, A. Fisch, 和 D. Chen. 让预训练语言模型成为更好的少样本学习者。arXiv:2012.15723, 2020。

[46] C. Ge, R. Huang, M. Xie, Z. Lai, S. Song, S. Li, and G. Huang. Domain adaptation via prompt learning. IEEE TNNLS, 2023.

[46] C. Ge, R. Huang, M. Xie, Z. Lai, S. Song, S. Li, 和 G. Huang. 通过提示学习实现领域自适应。IEEE TNNLS, 2023。

[47] J. Gu, Z. Han, S. Chen, A. Beirami, B. He, G. Zhang, R. Liao, Y. Qin, V. Tresp, and P. Torr. A systematic survey of prompt engineering on vision-language foundation models. arXiv:2307.12980, 2023.

[47] J. Gu, Z. Han, S. Chen, A. Beirami, B. He, G. Zhang, R. Liao, Y. Qin, V. Tresp, 和 P. Torr. 视觉-语言基础模型提示工程的系统综述。arXiv:2307.12980, 2023。

[48] J. Guo, L. Qi, and Y. Shi. Domaindrop: Suppressing domain-sensitive channels for domain generalization. In Proc. of CVPR, pages 19114-19124, 2023.

[48] J. Guo, L. Qi, 和 Y. Shi. Domaindrop:抑制领域敏感通道以实现领域泛化。在CVPR会议论文集，页码19114-19124，2023年。

[49] K. He, H. Fan, Y. Wu, S. Xie, and R. Girshick. Momentum contrast for unsupervised visual representation learning. In Proc. of CVPR, pages 9729-9738, 2020.

[49] K. He, H. Fan, Y. Wu, S. Xie, 和 R. Girshick. 动量对比用于无监督视觉表示学习。在CVPR会议论文集，页码9729-9738，2020年。

[50] P. Helber, B. Bischke, A. Dengel, and D. Borth. Eu-rosat: A novel dataset and deep learning benchmark for land use and land cover classification. IEEE J-STAR, 12(7):2217-2226, 2019.

[50] P. Helber, B. Bischke, A. Dengel, 和 D. Borth. EuroSAT:用于土地利用和土地覆盖分类的新型数据集及深度学习基准。IEEE J-STAR，12(7):2217-2226，2019年。

[51] D. Hendrycks, S. Basart, N. Mu, S. Kadavath, F. Wang, E. Dorundo, R. Desai, T. Zhu, S. Parajuli, M. Guo, et al. The many faces of robustness: A critical analysis of out-of-distribution generalization. In Proc. of ICCV, pages 8340-8349, 2021.

[51] D. Hendrycks, S. Basart, N. Mu, S. Kadavath, F. Wang, E. Dorundo, R. Desai, T. Zhu, S. Parajuli, M. Guo 等. 鲁棒性的多面性:对分布外泛化的批判性分析。在ICCV会议论文集，页码8340-8349，2021年。

[52] D. Hendrycks, K. Zhao, S. Basart, J. Steinhardt, and D. Song. Natural adversarial examples. In Proc. of CVPR, pages 15262-15271, 2021.

[52] D. Hendrycks, K. Zhao, S. Basart, J. Steinhardt, 和 D. Song. 自然对抗样本。在CVPR会议论文集，页码15262-15271，2021年。

[53] R. D. Hjelm, A. Fedorov, S. Lavoie-Marchildon, K. Grewal, P. Bachman, A. Trischler, and Y. Bengio. Learning deep representations by mutual information estimation and maximization. Proc. of ICLR, 2018.

[53] R. D. Hjelm, A. Fedorov, S. Lavoie-Marchildon, K. Grewal, P. Bachman, A. Trischler, 和 Y. Bengio. 通过互信息估计与最大化学习深度表示。ICLR会议论文集，2018年。

[54] N. Houlsby, A. Giurgiu, S. Jastrzebski, B. Morrone, Q. De Laroussilhe, A. Gesmundo, M. Attariyan, and S. Gelly. Parameter-efficient transfer learning for nlp. In Proc. of ICML, pages 2790-2799. PMLR, 2019.

[54] N. Houlsby, A. Giurgiu, S. Jastrzebski, B. Morrone, Q. De Laroussilhe, A. Gesmundo, M. Attariyan, 和 S. Gelly. 用于自然语言处理的参数高效迁移学习。在ICML会议论文集，页码2790-2799。PMLR，2019年。

[55] E. J. Hu, Y. Shen, P. Wallis, Z. Allen-Zhu, Y. Li, S. Wang, L. Wang, and W. Chen. Lora: Low-rank adaptation of large language models. arXiv:2106.09685, 2021.

[55] E. J. Hu, Y. Shen, P. Wallis, Z. Allen-Zhu, Y. Li, S. Wang, L. Wang, 和 W. Chen. LoRA:大规模语言模型的低秩适配。arXiv:2106.09685，2021年。

[56] X. Hu, K. Zhang, L. Xia, A. Chen, J. Luo, Y. Sun, K. Wang, N. Qiao, X. Zeng, M. Sun, et al. Reclip: Refine contrastive language image pre-training with source-free domain adaptation. In Proc. of WACV, pages 2994-3003, 2024.

[56] X. Hu, K. Zhang, L. Xia, A. Chen, J. Luo, Y. Sun, K. Wang, N. Qiao, X. Zeng, M. Sun 等. ReCLIP:通过无源领域适配优化对比语言图像预训练。在WACV会议论文集，页码2994-3003，2024年。

[57] T. Huang, J. Chu, and F. Wei. Unsupervised prompt learning for vision-language models. arXiv:2204.03649, 2022.

[57] T. Huang, J. Chu, 和 F. Wei. 视觉语言模型的无监督提示学习。arXiv:2204.03649，2022年。

[58] Y. Huang, C. Du, Z. Xue, X. Chen, H. Zhao, and L. Huang. What makes multi-modal learning better than single (provably). In Proc. NeurIPS, volume 34, pages 10944-10956, 2021.

[58] Y. Huang, C. Du, Z. Xue, X. Chen, H. Zhao, 和 L. Huang. 多模态学习优于单模态学习的原因(可证明)。NeurIPS会议论文集，卷34，页码10944-10956，2021年。

[59] Z. Huang, H. Wang, E. P. Xing, and D. Huang. Self-challenging improves cross-domain generalization. In Proc. of ECCV, pages 124-140. Springer, 2020.

[59] Z. Huang, H. Wang, E. P. Xing, 和 D. Huang. 自我挑战提升跨域泛化能力。在ECCV会议论文集，页码124-140。Springer，2020年。

[60] Z. Huang, A. Zhou, Z. Ling, M. Cai, H. Wang, and Y. J. Lee. A sentence speaks a thousand images: Domain generalization through distilling clip with language guidance. In Proc. of ICCV, pages 11685-11695, 2023.

[60] Z. Huang, A. Zhou, Z. Ling, M. Cai, H. Wang, 和 Y. J. Lee. 一句话胜过千张图像:通过语言引导蒸馏CLIP实现领域泛化。在ICCV会议论文集，页码11685-11695，2023年。

[61] G. Ilharco, M. Wortsman, S. Y. Gadre, S. Song, H. Ha-jishirzi, S. Kornblith, A. Farhadi, and L. Schmidt. Patching open-vocabulary models by interpolating weights. Proc. of NeurIPS, 35:29262-29277, 2022.

[61] G. Ilharco, M. Wortsman, S. Y. Gadre, S. Song, H. Hajishirzi, S. Kornblith, A. Farhadi, 和 L. Schmidt. 通过插值权重修补开放词汇模型。NeurIPS会议论文集，35:29262-29277，2022年。

[62] S. Ioffe. Batch normalization: Accelerating deep network training by reducing internal covariate shift. arXiv:1502.03167, 2015.

[62] S. Ioffe. 批量归一化:通过减少内部协变量偏移加速深度网络训练。arXiv:1502.03167，2015年。

[63] C. Jia, Y. Yang, Y. Xia, Y.-T. Chen, Z. Parekh, H. Pham, Q. Le, Y.-H. Sung, Z. Li, and T. Duerig. Scaling up visual and vision-language representation learning with noisy text supervision. In Proc. of ICML, pages 4904-4916. PMLR, 2021.

[63] C. Jia, Y. Yang, Y. Xia, Y.-T. Chen, Z. Parekh, H. Pham, Q. Le, Y.-H. Sung, Z. Li, 和 T. Duerig. 利用噪声文本监督扩展视觉及视觉-语言表示学习规模。发表于ICML会议论文集，页码4904-4916。PMLR，2021年。

[64] M. Jia, L. Tang, B.-C. Chen, C. Cardie, S. Belongie, B. Hariharan, and S.-N. Lim. Visual prompt tuning. In Proc. of ECCV, pages 709-727. Springer, 2022.

[64] M. Jia, L. Tang, B.-C. Chen, C. Cardie, S. Belongie, B. Hariharan, 和 S.-N. Lim. 视觉提示调优。发表于ECCV会议论文集，页码709-727。Springer，2022年。

[65] Z. Jiang, F. F. Xu, J. Araki, and G. Neubig. How can we know what language models know? Trans. of ACL, $8 : {423} - {438},{2020}$ .

[65] Z. Jiang, F. F. Xu, J. Araki, 和 G. Neubig. 我们如何知道语言模型知道什么？发表于ACL学报，$8 : {423} - {438},{2020}$ 。

[66] C. Ju, T. Han, K. Zheng, Y. Zhang, and W. Xie. Prompting visual-language models for efficient video understanding. In Proc. of ECCV, pages 105-124. Springer, 2022.

[66] C. Ju, T. Han, K. Zheng, Y. Zhang, 和 W. Xie. 利用提示引导视觉-语言模型实现高效视频理解。发表于ECCV会议论文集，页码105-124。Springer，2022年。

[67] J. Kang, S. Lee, N. Kim, and S. Kwak. Style neophile: Constantly seeking novel styles for domain generalization. In Proc. of CVPR, pages 7130-7140, 2022.

[67] J. Kang, S. Lee, N. Kim, 和 S. Kwak. 风格爱好者:持续探索新颖风格以实现领域泛化。发表于CVPR会议论文集，页码7130-7140，2022年。

[68] K. Katsumata, I. Kishida, A. Amma, and [86] H. Nakayama. Open-set domain generalization via metric learning. In Proc. of ICIP, pages 459-463, 2021.

[68] K. Katsumata, I. Kishida, A. Amma, 和 [86] H. Nakayama. 通过度量学习实现开放集领域泛化。发表于ICIP会议论文集，页码459-463，2021年。

[69] R. Kemker, M. McClure, A. Abitino, T. Hayes, and [87] C. Kanan. Measuring catastrophic forgetting in neural networks. In Proc. AAAI, volume 32, 2018.

[69] R. Kemker, M. McClure, A. Abitino, T. Hayes, 和 [87] C. Kanan. 测量神经网络中的灾难性遗忘。发表于AAAI会议论文集，卷32，2018年。

[70] M. U. Khattak, H. Rasheed, M. Maaz, S. Khan, and F. S. Khan. Maple: Multi-modal prompt learning. In Proc. of CVPR, pages 19113-19122, 2023.

[70] M. U. Khattak, H. Rasheed, M. Maaz, S. Khan, 和 F. S. Khan. Maple:多模态提示学习。在CVPR会议论文集，页码19113-19122，2023年。

[71] M. U. Khattak, S. T. Wasim, M. Naseer, S. Khan, M.- H. Yang, and F. S. Khan. Self-regulating prompts: Foundational model adaptation without forgetting. In Proc. of ICCV, pages 15190-15200, 2023.

[71] M. U. Khattak, S. T. Wasim, M. Naseer, S. Khan, M.-H. Yang, 和 F. S. Khan. 自我调节提示:基础模型适应而不遗忘。在ICCV会议论文集，页码15190-15200，2023年。

[72] G. Kim, T. Kwon, and J. C. Ye. Diffusionclip: Text-guided diffusion models for robust image manipulation. In Proc. of CVPR, pages 2426-2435, 2022.

[72] G. Kim, T. Kwon, 和 J. C. Ye. Diffusionclip:基于文本引导的扩散模型用于鲁棒图像操作。在CVPR会议论文集，页码2426-2435，2022年。

[73] J. Kim, K. Ryoo, J. Seo, G. Lee, D. Kim, H. Cho, and S. Kim. Semi-supervised learning of semantic correspondence with pseudo-labels. In Proc. of CVPR, pages 19699-19709, 2022.

[73] J. Kim, K. Ryoo, J. Seo, G. Lee, D. Kim, H. Cho, 和 S. Kim. 利用伪标签的语义对应半监督学习。在CVPR会议论文集，页码19699-19709，2022年。

[74] J. Krause, M. Stark, J. Deng, and L. Fei-Fei. 3d object representations for fine-grained categorization. In Proc. of ICCV Workshop, pages 554-561, 2013.

[74] J. Krause, M. Stark, J. Deng, 和 L. Fei-Fei. 用于细粒度分类的三维物体表示。在ICCV研讨会论文集，页码554-561，2013年。

[75] A. Krizhevsky, G. Hinton, et al. Learning multiple layers of features from tiny images. 2009.

[75] A. Krizhevsky, G. Hinton 等. 从小图像中学习多层特征。2009年。

[76] G. Kwon and J. C. Ye. Clipstyler: Image style transfer with a single text condition. In Proc. of CVPR, pages 18062-18071, 2022.

[76] G. Kwon 和 J. C. Ye. Clipstyler:基于单一文本条件的图像风格迁移。在CVPR会议论文集，页码18062-18071，2022年。

[77] M. Lafon, E. Ramzi, C. Rambour, N. Audebert, and N. Thome. Gallop: Learning global and local prompts for vision-language models. arXiv:2407.01400, 2024.

[77] M. Lafon, E. Ramzi, C. Rambour, N. Audebert, 和 N. Thome. Gallop:视觉语言模型的全局与局部提示学习。arXiv:2407.01400，2024年。

[78] Z. Lai, N. Vesdapunt, N. Zhou, J. Wu, C. P. Huynh, X. Li, K. K. Fu, and C.-N. Chuah. Padclip: Pseudo-labeling with adaptive debiasing in clip for unsupervised domain adaptation. In Proc. of ICCV, pages 16155-16165, 2023.

[78] Z. Lai, N. Vesdapunt, N. Zhou, J. Wu, C. P. Huynh, X. Li, K. K. Fu, 和 C.-N. Chuah. Padclip:CLIP中带自适应去偏的伪标签用于无监督领域适应。在ICCV会议论文集，页码16155-16165，2023年。

[79] Z. Lai, H. Bai, H. Zhang, X. Du, J. Shan, Y. Yang, C.-N. Chuah, and M. Cao. Empowering unsupervised domain adaptation with large-scale pre-trained vision-language models. In Proc. of WACV, pages 2691-2701, 2024.

[79] Z. Lai, H. Bai, H. Zhang, X. Du, J. Shan, Y. Yang, C.-N. Chuah, 和 M. Cao. 利用大规模预训练视觉语言模型增强无监督领域适应。在WACV会议论文集，页码2691-2701，2024年。

[80] K. Lee, S. Kim, and S. Kwak. Cross-domain ensemble distillation for domain generalization. In Proc. of ECCV, pages 1-20. Springer, 2022.

[80] K. Lee, S. Kim, 和 S. Kwak. 跨域集成蒸馏用于领域泛化。在ECCV会议论文集，页码1-20。Springer出版社，2022年。

[81] S. Lee, J. Bae, and H. Y. Kim. Decompose, adjust, compose: Effective normalization by playing with frequency for domain generalization. In Proc. of CVPR, pages 11776-11785, 2023.

[81] S. Lee, J. Bae, 和 H. Y. Kim. 分解、调整、组合:通过频率操作实现有效归一化以促进领域泛化。在CVPR会议论文集，页码11776-11785，2023年。

[82] B. Lester, R. Al-Rfou, and N. Constant. The power of scale for parameter-efficient prompt tuning. arXiv:2104.08691, 2021.

[82] B. Lester, R. Al-Rfou, 和 N. Constant. 规模的力量:参数高效提示调优。arXiv:2104.08691，2021年。

[83] Da Li, Yongxin Yang, Yi-Zhe Song, and Timothy M Hospedales. Deeper, broader and artier domain generalization. In Proc. of ICCV, pages 5542-5550, 2017.

[83] Da Li, Yongxin Yang, Yi-Zhe Song, 和 Timothy M Hospedales. 更深、更广、更具艺术性的领域泛化。在ICCV会议论文集，页码5542-5550，2017年。

[84] H. Li, S. J. Pan, S. Wang, and A. C. Kot. Domain generalization with adversarial feature learning. In Proc. of CVPR, pages 5400-5409, 2018.

[84] H. Li, S. J. Pan, S. Wang, 和 A. C. Kot. 基于对抗特征学习的领域泛化。在CVPR会议论文集，页码5400-5409，2018年。

[85] J. Li, Z. Yu, Z. Du, L. Zhu, and H. T. Shen. A comprehensive survey on source-free domain adaptation. IEEE TPAMI, 2024.

[85] J. Li, Z. Yu, Z. Du, L. Zhu, 和 H. T. Shen. 无源领域适应的综合综述。IEEE TPAMI，2024年。

[86] K. Li, J. Lu, H. Zuo, and G. Zhang. Attention-bridging ts fuzzy rules for universal multi-domain adaptation without source data. In Proc. of FUZZ-IEEE, pages 1-6. IEEE, 2023.

[86] K. Li, J. Lu, H. Zuo, 和 G. Zhang. 用于无源数据的通用多域适应的注意力桥接模糊规则。发表于FUZZ-IEEE会议论文集，第1-6页。IEEE, 2023。

[87] K. Li, J. Lu, H. Zuo, and G. Zhang. Source-free multidomain adaptation with fuzzy rule-based deep neural networks. IEEE Trans. on Fuzzy Systems, 31(12): 4180-4194, 2023.

[87] K. Li, J. Lu, H. Zuo, 和 G. Zhang. 基于模糊规则深度神经网络的无源多域适应。IEEE模糊系统汇刊，31(12): 4180-4194, 2023。

[88] K. Li, J. Lu, H. Zuo, and G. Zhang. Source-free multidomain adaptation with fuzzy rule-based deep neural networks. IEEE Trans. on Fuzzy Systems, 31(12): 4180-4194, 2023.

[88] K. Li, J. Lu, H. Zuo, 和 G. Zhang. 基于模糊规则深度神经网络的无源多域适应。IEEE模糊系统汇刊，31(12): 4180-4194, 2023。

[89] X. Li, Y. Li, Z. Du, F. Li, K. Lu, and J. Li. Split to merge: Unifying separated modalities for unsupervised domain adaptation. In Proc. of CVPR, pages 23364-23374, 2024.

[89] X. Li, Y. Li, Z. Du, F. Li, K. Lu, 和 J. Li. 拆分到合并:统一分离模态的无监督域适应。发表于CVPR会议论文集，第23364-23374页，2024。

[90] X. L. Li and P. Liang. Prefix-tuning: Optimizing continuous prompts for generation. arXiv:2101.00190, 2021.

[90] X. L. Li 和 P. Liang. 前缀调优:优化连续提示以生成文本。arXiv:2101.00190, 2021。

[91] Y. Li, Y. Cao, J. Li, Q. Wang, and S. Wang. Data-efficient clip-powered dual-branch networks for source-free unsupervised domain adaptation. arXiv:2410.15811, 2024.

[91] Y. Li, Y. Cao, J. Li, Q. Wang, 和 S. Wang. 数据高效的CLIP驱动双分支网络用于无源无监督域适应。arXiv:2410.15811, 2024。

[92] Y.-J. Li, X. Dai, C.-Y. Ma, Y.-C. Liu, K. Chen, B. Wu, Z. He, K. Kitani, and P. Vajda. Cross-domain adaptive teacher for object detection. In Proc. of CVPR, pages 7581-7590, 2022.

[92] Y.-J. Li, X. Dai, C.-Y. Ma, Y.-C. Liu, K. Chen, B. Wu, Z. He, K. Kitani, 和 P. Vajda. 用于目标检测的跨域自适应教师模型。发表于CVPR会议论文集，第7581-7590页，2022。

[93] J. Liang, R. He, and T. Tan. A comprehensive survey on test-time adaptation under distribution shifts. IJCV, pages 1-34, 2024.

[93] J. Liang, R. He, 和 T. Tan. 关于分布偏移下测试时自适应的综合综述。国际计算机视觉杂志(IJCV)，第1-34页，2024。

[94] J. Liang, L. Sheng, Z. Wang, R. He, and T. Tan. Realistic unsupervised clip fine-tuning with universal entropy optimization. In Proc. of ICML, 2024.

[94] J. Liang, L. Sheng, Z. Wang, R. He, 和 T. Tan. 具有通用熵优化的真实无监督CLIP微调。发表于ICML会议论文集，2024。

[95] F. Liu, J. Lu, and G. Zhang. Unsupervised heterogeneous domain adaptation via shared fuzzy equivalence relations. IEEE Trans. on Fuzzy Systems, 26(6): 3555-3568, 2018.

[95] F. Liu, J. Lu, 和 G. Zhang. 通过共享模糊等价关系的无监督异构域适应。IEEE模糊系统汇刊，26(6): 3555-3568, 2018。

[96] F. Liu, G. Zhang, and J. Lu. Multisource heterogeneous unsupervised domain adaptation via fuzzy relation neural networks. IEEE Trans. on Fuzzy Systems, 29(11):3308-3322, 2020.

[96] F. Liu, G. Zhang, 和 J. Lu. 通过模糊关系神经网络的多源异构无监督域适应。IEEE模糊系统汇刊，29(11):3308-3322, 2020。

[97] H. Liu, J. Wang, and M. Long. Cycle self-training for domain adaptation. Proc. of NeurIPS, 34:22968-22981, 2021.

[97] H. Liu, J. Wang, 和 M. Long. 用于域适应的循环自训练。NeurIPS会议论文集，34:22968-22981, 2021。

[98] Pengfei Liu, Weizhe Yuan, Jinlan Fu, Zhengbao Jiang, Hiroaki Hayashi, and Graham Neubig. Pre-train, prompt, and predict: A systematic survey of prompting methods in natural language processing. ACM Computing Surveys, 55(9):1-35, 2023.

[98] Pengfei Liu, Weizhe Yuan, Jinlan Fu, Zhengbao Jiang, Hiroaki Hayashi, 和 Graham Neubig. 预训练、提示与预测:自然语言处理提示方法的系统综述。ACM计算机综述，55(9):1-35, 2023。

[99] M. Long, H. Zhu, J. Wang, and M. I. Jordan. Deep transfer learning with joint adaptation networks. In Proc. of ICML, pages 2208-2217. PMLR, 2017.

[99] M. Long, H. Zhu, J. Wang, 和 M. I. Jordan. 具有联合适应网络的深度迁移学习。发表于ICML会议论文集，第2208-2217页。PMLR, 2017。

[100] M. Long, Z. Cao, J. Wang, and M. I. Jordan. Conditional adversarial domain adaptation. Proc. of NeurIPS, 31, 2018.

[100] M. Long, Z. Cao, J. Wang, 和 M. I. Jordan. 条件对抗域适应。NeurIPS会议论文集，31, 2018。

[101] S. Long, L. Wang, Z. Zhao, Z. Tan, Y. Wu, S. Wang, and J. Wang. Training-free unsupervised prompt for vision-language models. arXiv:2404.16339, 2024.

[101] S. Long, L. Wang, Z. Zhao, Z. Tan, Y. Wu, S. Wang, 和 J. Wang. 免训练的无监督视觉语言模型提示。arXiv:2404.16339, 2024。

[102] I. Loshchilov. Decoupled weight decay regularization. arXiv:1711.05101, 2017.

[102] I. Loshchilov. 解耦权重衰减正则化。arXiv:1711.05101, 2017。

[103] J. Lu, H. Zuo, and G. Zhang. Fuzzy multiple-source transfer learning. IEEE Trans. on Fuzzy Systems, 28(12): 3418-3431, 2019.

[103] J. Lu, H. Zuo, 和 G. Zhang. 模糊多源迁移学习。IEEE模糊系统汇刊, 28(12): 3418-3431, 2019。

[104] Y. Lu, J. Liu, Y. Zhang, Y. Liu, and X. Tian. Prompt distribution learning. In Proc. of CVPR, pages 5206- 5215, 2022.

[104] Y. Lu, J. Liu, Y. Zhang, Y. Liu, 和 X. Tian. 提示分布学习。发表于CVPR会议论文集, 页码5206-5215, 2022。

[105] F. Lv, J. Liang, S. Li, B. Zang, C. H. Liu, Z. Wang, and D. Liu. Causality inspired representation learning for domain generalization. In Proc. of CVPR, pages 8046- 8056, 2022.

[105] F. Lv, J. Liang, S. Li, B. Zang, C. H. Liu, Z. Wang, 和 D. Liu. 基于因果关系启发的表示学习用于领域泛化。发表于CVPR会议论文集, 页码8046-8056, 2022。

[106] W. Ma, S. Li, J. Zhang, C. H. Liu, J. Kang, Y. Wang, and G. Huang. Borrowing knowledge from pre-trained language model: A new data-efficient visual learning paradigm. In Proc. of ICCV, pages 18786-18797, 2023.

[106] W. Ma, S. Li, J. Zhang, C. H. Liu, J. Kang, Y. Wang, 和 G. Huang. 借助预训练语言模型知识:一种新的数据高效视觉学习范式。发表于ICCV会议论文集, 页码18786-18797, 2023。

[107] S. Maji, E. Rahtu, J. Kannala, M. Blaschko, and A. Vedaldi. Fine-grained visual classification of aircraft. arXiv:1306.5151, 2013.

[107] S. Maji, E. Rahtu, J. Kannala, M. Blaschko, 和 A. Vedaldi. 飞机的细粒度视觉分类。arXiv:1306.5151, 2013。

[108] K. Mei, C. Zhu, J. Zou, and S. Zhang. Instance adaptive self-training for unsupervised domain adaptation. In Proc. of ECCV, pages 415-430. Springer, 2020.

[108] K. Mei, C. Zhu, J. Zou, 和 S. Zhang. 实例自适应自训练用于无监督领域适应。发表于ECCV会议论文集, 页码415-430。Springer出版社, 2020。

[109] Y. Min, K. Ryoo, B. Kim, and T. Kim. Uota: Unsupervised open-set task adaptation using a vision-language foundation model. In Proc. of ICML Workshop, 2023.

[109] Y. Min, K. Ryoo, B. Kim, 和 T. Kim. Uota:基于视觉-语言基础模型的无监督开放集任务适应。发表于ICML研讨会, 2023。

[110] M. J. Mirza, L. Karlinsky, W. Lin, H. Possegger, M. Kozinski, R. Feris, and H. Bischof. Lafter: Label-free tuning of zero-shot classifier using language and unlabeled image collections. Proc. of NeurIPS, 36, 2024.

[110] M. J. Mirza, L. Karlinsky, W. Lin, H. Possegger, M. Kozinski, R. Feris, 和 H. Bischof. Lafter:利用语言和无标签图像集合进行零样本分类器的无标签调优。发表于NeurIPS, 第36卷, 2024。

[111] A. Miyai, Q. Yu, G. Irie, and K. Aizawa. Locoop: Few-shot out-of-distribution detection via prompt learning. Proc. of NeurIPS, 36:76298-76310, 2023.

[111] A. Miyai, Q. Yu, G. Irie, 和 K. Aizawa. Locoop:通过提示学习实现少样本分布外检测。发表于NeurIPS, 第36卷:76298-76310, 2023。

[112] A. Miyai, Q. Yu, G. Irie, and K. Aizawa. Zero-shot in-distribution detection in multi-object settings using vision-language foundation models. arXiv:2304.04521, 2023.

[112] A. Miyai, Q. Yu, G. Irie, 和 K. Aizawa. 利用视觉-语言基础模型进行多目标环境下的零样本分布内检测。arXiv:2304.04521, 2023。

[113] M. Monga, S. K. Giroh, A. Jha, M. Singha, B. Banerjee, and J. Chanussot. Cosmo: Clip talks on open-set multi-target domain adaptation. arXiv:2409.00397, 2024.

[113] M. Monga, S. K. Giroh, A. Jha, M. Singha, B. Banerjee, 和 J. Chanussot. Cosmo:CLIP在开放集多目标领域适应中的应用。arXiv:2409.00397, 2024。

[114] C. Mou, X. Wang, L. Xie, Y. Wu, J. Zhang, Z. Qi, and Y. Shan. T2i-adapter: Learning adapters to dig out more controllable ability for text-to-image diffusion models. In Proc. of AAAI, volume 38, pages 4296-4304, 2024.

[114] C. Mou, X. Wang, L. Xie, Y. Wu, J. Zhang, Z. Qi, 和 Y. Shan. T2i-adapter:学习适配器以挖掘文本到图像扩散模型的更多可控能力。发表于AAAI会议论文集, 第38卷, 页码4296-4304, 2024。

[115] M.-E. Nilsback and A. Zisserman. Automated flower classification over a large number of classes. In 2008 Sixth Indian Conf. on CVGIP, pages 722-729. IEEE, 2008.

[115] M.-E. Nilsback 和 A. Zisserman. 大规模类别的自动花卉分类。发表于2008年第六届印度计算机视觉、图形学与图像处理会议, 页码722-729。IEEE, 2008。

[116] H. Niu, H. Li, F. Zhao, and B. Li. Domain-unified prompt representations for source-free domain generalization. arXiv:2209.14926, 2022.

[116] H. Niu, H. Li, F. Zhao, 和 B. Li. 无源领域泛化的领域统一提示表示。arXiv:2209.14926, 2022。

[117] M. Noguchi and S. Shirakawa. Simple domain generalization methods are strong baselines for open domain generalization. In Proc. of IJCNN, pages 1-8, 2024.

[117] M. Noguchi 和 S. Shirakawa. 简单的领域泛化方法是开放领域泛化的强基线。发表于IJCNN会议论文集, 页码1-8, 2024。

[118] J. Oppenlaender. The creativity of text-to-image generation. In Proc. of MindTrek, pages 192-202, 2022.

[118] J. Oppenlaender. 文本到图像生成的创造力。发表于MindTrek会议论文集，第192-202页，2022年。

[119] O. M. Parkhi, A. Vedaldi, A. Zisserman, and C. V. Jawahar. Cats and dogs. In Proc. of CVPR, pages 3498- 3505. IEEE, 2012.

[119] O. M. Parkhi, A. Vedaldi, A. Zisserman, 和 C. V. Jawahar. 猫与狗。发表于CVPR会议论文集，第3498-3505页。IEEE，2012年。

[120] O. Patashnik, Z. Wu, E. Shechtman, D. Cohen-Or, and D. Lischinski. Styleclip: Text-driven manipulation of stylegan imagery. In Proc. of ICCV, pages 2085-2094, 2021.

[120] O. Patashnik, Z. Wu, E. Shechtman, D. Cohen-Or, 和 D. Lischinski. Styleclip:基于文本驱动的StyleGAN图像风格操控。发表于ICCV会议论文集，第2085-2094页，2021年。

[121] Xingchao Peng, Ben Usman, Neela Kaushik, Judy Hoffman, Dequan Wang, and Kate Saenko. Visda: The visual domain adaptation challenge. arXiv:1710.06924, 2017.

[121] 彭星超, Ben Usman, Neela Kaushik, Judy Hoffman, Dequan Wang, 和 Kate Saenko. Visda:视觉域适应挑战。arXiv:1710.06924, 2017年。

[122] Xingchao Peng, Qinxun Bai, Xide Xia, Zijun Huang, Kate Saenko, and Bo Wang. Moment matching for multi-source domain adaptation. In Proc. of ICCV, pages 1406-1415, 2019.

[122] 彭星超, 白勤勋, 夏锡德, 黄子军, Kate Saenko, 和 王博. 多源域适应的矩匹配方法。发表于ICCV会议论文集，第1406-1415页，2019年。

[123] F. Petroni, T. Rocktäschel, P. Lewis, A. Bakhtin, Y. Wu, A. H. Miller, and S. Riedel. Language models as knowledge bases? arXiv:1909.01066, 2019.

[123] F. Petroni, T. Rocktäschel, P. Lewis, A. Bakhtin, Y. Wu, A. H. Miller, 和 S. Riedel. 语言模型作为知识库？arXiv:1909.01066, 2019年。

[124] Y. Qiao, K. Li, J. Lin, R. Wei, C. Jiang, Y. Luo, and H. Yang. Robust domain generalization for multimodal object recognition. In Proc. of AIEA, pages 392- 397. IEEE, 2024.

[124] 乔阳, 李凯, 林军, 魏锐, 江晨, 罗毅, 和 杨辉. 多模态目标识别的鲁棒域泛化。发表于AIEA会议论文集，第392-397页。IEEE，2024年。

[125] Chengwei Qin and Shafiq Joty. Lfpt5: A unified framework for lifelong few-shot language learning based on prompt tuning of t5. arXiv:2110.07298, 2021.

[125] 秦成伟 和 Shafiq Joty. Lfpt5:基于T5提示调优的终身少样本语言学习统一框架。arXiv:2110.07298, 2021年。

[126] S. Qu, Y. Pan, G. Chen, T. Yao, C. Jiang, and T. Mei. Modality-agnostic debiasing for single domain generalization. In Proc. of CVPR, pages 24142-24151, 2023.

[126] 瞿爽, 潘阳, 陈刚, 姚涛, 江晨, 和 梅涛. 单域泛化的模态无关去偏方法。发表于CVPR会议论文集，第24142-24151页，2023年。

[127] A. Radford, J. W. Kim, C. Hallacy, A. Ramesh, G. Goh, S. Agarwal, G. Sastry, A. Askell, P. Mishkin, J. Clark, et al. Learning transferable visual models from natural language supervision. In Proc. of ICML, pages 8748- 8763. PMLR, 2021.

[127] A. Radford, J. W. Kim, C. Hallacy, A. Ramesh, G. Goh, S. Agarwal, G. Sastry, A. Askell, P. Mishkin, J. Clark, 等. 从自然语言监督中学习可迁移视觉模型。发表于ICML会议论文集，第8748-8763页。PMLR，2021年。

[128] A. Ramesh, M. Pavlov, G. Goh, S. Gray, C. Voss, A. Radford, M. Chen, and I. Sutskever. Zero-shot text-to-image generation. In Proc. of ICML, pages 8821- 8831. PMLR, 2021.

[128] A. Ramesh, M. Pavlov, G. Goh, S. Gray, C. Voss, A. Radford, M. Chen, 和 I. Sutskever. 零样本文本到图像生成。发表于ICML会议论文集，第8821-8831页。PMLR，2021年。

[129] Y. Rao, W. Zhao, G. Chen, Y. Tang, Z. Zhu, G. Huang, J. Zhou, and J. Lu. Denseclip: Language-guided dense prediction with context-aware prompting. In Proc. of CVPR, pages 18082-18091, 2022.

[129] Y. Rao, W. Zhao, G. Chen, Y. Tang, Z. Zhu, G. Huang, J. Zhou, 和 J. Lu. Denseclip:基于语言引导的上下文感知密集预测提示。发表于CVPR会议论文集，第18082-18091页，2022年。

[130] B. Recht, R. Roelofs, L. Schmidt, and V. Shankar. Do imagenet classifiers generalize to imagenet? In Proc. of ICML, pages 5389-5400. PMLR, 2019.

[130] B. Recht, R. Roelofs, L. Schmidt, 和 V. Shankar. ImageNet分类器能泛化到ImageNet吗？发表于ICML会议论文集，第5389-5400页。PMLR，2019年。

[131] R. Rombach, A. Blattmann, D. Lorenz, P. Esser, and B. Ommer. High-resolution image synthesis with latent diffusion models. In Proc. of CVPR, pages 10684- 10695, 2022.

[131] R. Rombach, A. Blattmann, D. Lorenz, P. Esser, 和 B. Ommer. 基于潜在扩散模型的高分辨率图像合成。发表于CVPR会议论文集，第10684-10695页，2022年。

[132] Kate Saenko, Brian Kulis, Mario Fritz, and Trevor Darrell. Adapting visual category models to new domains. In Proc. of ECCV 2010, pages 213-226. Springer, 2010.

[132] Kate Saenko, Brian Kulis, Mario Fritz, 和 Trevor Darrell. 视觉类别模型向新域的适应。发表于ECCV 2010会议论文集，第213-226页。Springer，2010年。

[133] C. Saharia, W. Chan, S. Saxena, L. Li, J. Whang, E. L. Denton, K. Ghasemipour, R. Gontijo Lopes, B. Karagol Ayan, T. Salimans, et al. Photorealistic text-to-image diffusion models with deep language understanding. Proc. of NeurIPS, 35:36479-36494, 2022.

[133] C. Saharia, W. Chan, S. Saxena, L. Li, J. Whang, E. L. Denton, K. Ghasemipour, R. Gontijo Lopes, B. Karagol Ayan, T. Salimans, 等. 具备深度语言理解的逼真文本到图像扩散模型。发表于NeurIPS，35卷，第36479-36494页，2022年。

[134] M. B. Sariyildiz, J. Perez, and D. Larlus. Learning visual representations with caption annotations. In Proc. of ECCV, pages 153-170. Springer, 2020.

[134] M. B. Sariyildiz, J. Perez, 和 D. Larlus. 利用字幕注释学习视觉表示。在ECCV会议论文集，页153-170。Springer出版社，2020年。

[135] S. Schulhoff, M. Ilie, N. Balepur, K. Kahadze, A. Liu, C. Si, Y. Li, A. Gupta, H. Han, S. Schulhoff, et al. The prompt report: A systematic survey of prompting techniques. arXiv:2406.06608, 2024.

[135] S. Schulhoff, M. Ilie, N. Balepur, K. Kahadze, A. Liu, C. Si, Y. Li, A. Gupta, H. Han, S. Schulhoff 等人。提示报告:提示技术的系统性综述。arXiv:2406.06608，2024年。

[136] G. Schwalbe and B. Finzel. A comprehensive taxonomy for explainable artificial intelligence: a systematic survey of surveys on methods and concepts. DMKD, 38(5):3043-3101, 2024.

[136] G. Schwalbe 和 B. Finzel。可解释人工智能的全面分类法:方法与概念的综述性调查。数据挖掘与知识发现(DMKD)，38(5):3043-3101，2024年。

[137] S. Shankar, V. Piratla, S. Chakrabarti, S. Chaudhuri, P. Jyothi, and S. Sarawagi. Generalizing across domains via cross-gradient training. arXiv:1804.10745, 2018.

[137] S. Shankar, V. Piratla, S. Chakrabarti, S. Chaudhuri, P. Jyothi, 和 S. Sarawagi。通过交叉梯度训练实现跨域泛化。arXiv:1804.10745，2018年。

[138] S. Shen, S. Yang, T. Zhang, B. Zhai, J. E. Gonzalez, K. Keutzer, and T. Darrell. Multitask vision-language prompt tuning. In Proc. of CVPR, pages 5656-5667, 2024.

[138] S. Shen, S. Yang, T. Zhang, B. Zhai, J. E. Gonzalez, K. Keutzer, 和 T. Darrell。多任务视觉-语言提示调优。在CVPR会议论文集，页5656-5667，2024年。

[139] K. Shi, J. Lu, Z. Fang, and G. Zhang. Enhancing vision-language models incorporating tsk fuzzy system for domain adaptation. In Proc. of FUZZ-IEEE, pages 1-8, 2024.

[139] K. Shi, J. Lu, Z. Fang, 和 G. Zhang。结合tsk模糊系统的视觉-语言模型增强域适应。在FUZZ-IEEE会议论文集，页1-8，2024年。

[140] K. Shi, J. Lu, Z. Fang, and G. Zhang. Clip-enhanced unsupervised domain adaptation with consistency regularization. In Proc. of IJCNN, pages 1-8, 2024.

[140] K. Shi, J. Lu, Z. Fang, 和 G. Zhang。基于CLIP增强的一致性正则化无监督域适应。在IJCNN会议论文集，页1-8，2024年。

[141] K. Shi, J. Lu, Z. Fang, and G. Zhang. Unsupervised domain adaptation enhanced by fuzzy prompt learning. IEEE TFS, 2024.

[141] K. Shi, J. Lu, Z. Fang, 和 G. Zhang。通过模糊提示学习增强的无监督域适应。IEEE模糊系统汇刊(TFS)，2024年。

[142] T. Shin, Y. Razeghi, R. L. Logan IV, E. Wallace, and S. Singh. Autoprompt: Eliciting knowledge from language models with automatically generated prompts. arXiv:2010.15980, 2020.

[142] T. Shin, Y. Razeghi, R. L. Logan IV, E. Wallace, 和 S. Singh。Autoprompt:利用自动生成的提示从语言模型中引出知识。arXiv:2010.15980，2020年。

[143] Y. Shu, Z. Cao, C. Wang, J. Wang, and M. Long. Open domain generalization with domain-augmented meta-learning. In Proc. of CVPR, pages 9624-9633, 2021.

[143] Y. Shu, Z. Cao, C. Wang, J. Wang, 和 M. Long。开放域泛化的域增强元学习。在CVPR会议论文集，页9624-9633，2021年。

[144] Y. Shu, X. Guo, J. Wu, X. Wang, J. Wang, and M. Long. Clipood: Generalizing clip to out-of-distributions. In Proc. of ICML, pages 31716-31731. PMLR, 2023.

[144] Y. Shu, X. Guo, J. Wu, X. Wang, J. Wang, 和 M. Long。Clipood:将CLIP推广至分布外数据。在ICML会议论文集，页31716-31731。PMLR出版社，2023年。

[145] A. Singh, R. Hu, V. Goswami, G. Couairon, W. Galuba, M. Rohrbach, and D. Kiela. Flava: A foundational language and vision alignment model. In Proc. of CVPR, pages 15638-15650, 2022.

[145] A. Singh, R. Hu, V. Goswami, G. Couairon, W. Galuba, M. Rohrbach, 和 D. Kiela。Flava:基础语言与视觉对齐模型。在CVPR会议论文集，页15638-15650，2022年。

[146] M. Singha, H. Pal, A. Jha, and B. Banerjee. Ad-clip: Adapting domains in prompt space using clip. In Proc. of ICCV Workshop, pages 4355-4364, 2023.

[146] M. Singha, H. Pal, A. Jha, 和 B. Banerjee。Ad-clip:利用CLIP在提示空间进行域适应。在ICCV研讨会论文集，页4355-4364，2023年。

[147] M. Singha, A. Jha, S. Bose, A. Nair, M. Abdar, and B. Banerjee. Unknown prompt the only lacuna: Unveiling clip's potential for open domain generalization. In Proc. of CVPR, pages 13309-13319, 2024.

[147] M. Singha, A. Jha, S. Bose, A. Nair, M. Abdar, 和 B. Banerjee。未知提示是唯一缺口:揭示CLIP在开放域泛化中的潜力。在CVPR会议论文集，页13309-13319，2024年。

[148] K. Sohn, D. Berthelot, N. Carlini, Z. Zhang, H. Zhang, C. A. Raffel, E. D. Cubuk, A. Kurakin, and C.-L. Li. Fixmatch: Simplifying semi-supervised learning with consistency and confidence. Proc. of NeurIPS, 33:596- 608, 2020.

[148] K. Sohn, D. Berthelot, N. Carlini, Z. Zhang, H. Zhang, C. A. Raffel, E. D. Cubuk, A. Kurakin, 和 C.-L. Li。Fixmatch:通过一致性和置信度简化半监督学习。NeurIPS会议论文集，33:596-608，2020年。

[149] K. Soomro. Ucf101: A dataset of 101 human actions classes from videos in the wild. arXiv:1212.0402, 2012.

[149] K. Soomro。UCF101:野外视频中101类人体动作数据集。arXiv:1212.0402，2012年。

[150] N. Srivastava, G. Hinton, A. Krizhevsky, I. Sutskever, and R. Salakhutdinov. Dropout: a simple way to prevent neural networks from overfitting. JMLR, 15 (1):1929-1958, 2014.

[150] N. Srivastava, G. Hinton, A. Krizhevsky, I. Sutskever, 和 R. Salakhutdinov. Dropout:防止神经网络过拟合的简单方法。JMLR，15 (1):1929-1958，2014。

[151] A. C. Stickland and I. Murray. Bert and pals: Projected attention layers for efficient adaptation in multi-task learning. In Proc. of ICML, pages 5986-5995. PMLR, 2019.

[151] A. C. Stickland 和 I. Murray. Bert及其伙伴:用于多任务学习中高效适应的投影注意力层。发表于ICML会议论文集，页5986-5995。PMLR，2019。

[152] B. Sun and K. Saenko. Deep coral: Correlation alignment for deep domain adaptation. In Proc. of ECCV Workshop, pages 443-450. Springer, 2016.

[152] B. Sun 和 K. Saenko. Deep coral:用于深度领域适应的相关性对齐。发表于ECCV研讨会论文集，页443-450。Springer，2016。

[153] X. Sun, P. Hu, and K. Saenko. Dualcoop: Fast adaptation to multi-label recognition with limited annotations. Proc. of NeurIPS, 35:30569-30582, 2022.

[153] X. Sun, P. Hu, 和 K. Saenko. Dualcoop:有限标注下多标签识别的快速适应。NeurIPS会议论文集，35:30569-30582，2022。

[154] C. Szegedy, V. Vanhoucke, S. Ioffe, J. Shlens, and Z. Wojna. Rethinking the inception architecture for computer vision. In Proc. of CVPR, pages 2818-2826, 2016.

[154] C. Szegedy, V. Vanhoucke, S. Ioffe, J. Shlens, 和 Z. Wojna. 重新思考计算机视觉中的Inception架构。发表于CVPR会议论文集，页2818-2826，2016。

[155] S. Tang, W. Su, M. Ye, and X. Zhu. Source-free domain adaptation with frozen multimodal foundation model. In Proc. of CVPR, pages 23711-23720, 2024.

[155] S. Tang, W. Su, M. Ye, 和 X. Zhu. 基于冻结多模态基础模型的无源领域适应。发表于CVPR会议论文集，页23711-23720，2024。

[156] Y. Tang, Y. Wan, L. Qi, and X. Geng. Dpstyler: Dynamic promptstyler for source-free domain generalization. arXiv:2403.16697, 2024.

[156] Y. Tang, Y. Wan, L. Qi, 和 X. Geng. Dpstyler:用于无源领域泛化的动态提示风格器。arXiv:2403.16697，2024。

[157] K. Tanwisuth, S. Zhang, H. Zheng, P. He, and M. Zhou. Pouf: Prompt-oriented unsupervised fine-tuning for large pre-trained models. In Proc. of ICML, pages 33816-33832, 2023.

[157] K. Tanwisuth, S. Zhang, H. Zheng, P. He, 和 M. Zhou. Pouf:面向提示的大型预训练模型无监督微调。发表于ICML会议论文集，页33816-33832，2023。

[158] L. Tian, M. Ye, L. Zhou, and Q. He. Clip-guided black-box domain adaptation of image classification. Signal, Image and Video Processing, 18(5):4637-4646, 2024.

[158] L. Tian, M. Ye, L. Zhou, 和 Q. He. 基于CLIP引导的图像分类黑盒领域适应。信号、图像与视频处理，18(5):4637-4646，2024。

[159] M. Tsimpoukelli, J. L. Menick, S. Cabi, S. M. Eslami, O. Vinyals, and F. Hill. Multimodal few-shot learning with frozen language models. Proc. of NeurIPS, 34: 200-212, 2021.

[159] M. Tsimpoukelli, J. L. Menick, S. Cabi, S. M. Eslami, O. Vinyals, 和 F. Hill. 基于冻结语言模型的多模态少样本学习。NeurIPS会议论文集，34: 200-212，2021。

[160] Gido M van de Ven, Nicholas Soures, and Dhireesha Kudithipudi. Continual learning and catastrophic forgetting. arXiv:2403.05175, 2024.

[160] Gido M van de Ven, Nicholas Soures, 和 Dhireesha Kudithipudi. 持续学习与灾难性遗忘。arXiv:2403.05175，2024。

[161] Hemanth Venkateswara, Jose Eusebio, Shayok Chakraborty, and Sethuraman Panchanathan. Deep hashing network for unsupervised domain adaptation. In Proc. of CVPR, pages 5018-5027, 2017.

[161] Hemanth Venkateswara, Jose Eusebio, Shayok Chakraborty, 和 Sethuraman Panchanathan. 用于无监督领域适应的深度哈希网络。发表于CVPR会议论文集，页5018-5027，2017。

[162] H. Wang, S. Ge, Z. Lipton, and E. P. Xing. Learning robust global representations by penalizing local predictive power. Proc. of NeurIPS, 32, 2019.

[162] H. Wang, S. Ge, Z. Lipton, 和 E. P. Xing. 通过惩罚局部预测能力学习鲁棒的全局表示。NeurIPS会议论文集，32，2019。

[163] P. Wang, Z. Zhang, Z. Lei, and L. Zhang. Sharpness-aware gradient matching for domain generalization. In Proc. of CVPR, pages 3769-3778, 2023.

[163] P. Wang, Z. Zhang, Z. Lei, 和 L. Zhang. 面向领域泛化的锐度感知梯度匹配。发表于CVPR会议论文集，页3769-3778，2023。

[164] X. Wang, J. Zhang, L. Qi, and Y. Shi. Generalizable decision boundaries: Dualistic meta-learning for open set domain generalization. In Proc. of ICCV, pages 11564-11573, 2023.

[164] X. Wang, J. Zhang, L. Qi, 和 Y. Shi. 可泛化的决策边界:用于开放集领域泛化的二元元学习。发表于ICCV会议论文集，页11564-11573，2023。

[165] Y. Wang. Survey on deep multi-modal data analytics: Collaboration, rivalry, and fusion. ACM TOMM, 17 (1s):1-25, 2021.

[165] Y. Wang. 深度多模态数据分析综述:协作、竞争与融合。ACM TOMM，17 (1s):1-25，2021。

[166] Z. Wang, L. Zhang, L. Wang, and M. Zhu. Landa: Language-guided multi-source domain adaptation. arXiv:2401.14148, 2024.

[166] Z. Wang, L. Zhang, L. Wang, 和 M. Zhu. Landa:基于语言引导的多源领域自适应。arXiv:2401.14148, 2024。

[167] H. Wei, L. Chen, K. Ruan, and L. Li. Low-rank tensor regularized fuzzy clustering for multiview data. IEEE Trans. on Fuzzy Systems, 28(12):3087-3099, 2020.

[167] H. Wei, L. Chen, K. Ruan, 和 L. Li. 低秩张量正则化模糊聚类用于多视角数据。IEEE模糊系统汇刊, 28(12):3087-3099, 2020。

[168] M. Wortsman, G. Ilharco, J. W. Kim, M. Li, S. Korn-blith, R. Roelofs, R. G. Lopes, H. Hajishirzi, A. Farhadi, H. Namkoong, et al. Robust fine-tuning of zero-shot models. In Proc. of CVPR, pages 7959-7971, 2022.

[168] M. Wortsman, G. Ilharco, J. W. Kim, M. Li, S. Kornblith, R. Roelofs, R. G. Lopes, H. Hajishirzi, A. Farhadi, H. Namkoong, 等. 零样本模型的鲁棒微调。CVPR会议论文集, 页7959-7971, 2022。

[169] J. Xiao, J. Hays, K. A. Ehinger, A. Oliva, and A. Tor-ralba. Sun database: Large-scale scene recognition from abbey to zoo. In Proc. of CVPR, pages 3485-3492. IEEE, 2010.

[169] J. Xiao, J. Hays, K. A. Ehinger, A. Oliva, 和 A. Torralba. SUN数据库:从修道院到动物园的大规模场景识别。CVPR会议论文集, 页3485-3492. IEEE, 2010。

[170] Z. Xiao, J. Shen, M. M. Derakhshani, S. Liao, and C. G. M. Snoek. Any-shift prompting for generalization over distributions. In Proc. of CVPR, pages 13849- 13860, 2024.

[170] Z. Xiao, J. Shen, M. M. Derakhshani, S. Liao, 和 C. G. M. Snoek. 任意分布偏移提示以实现分布泛化。CVPR会议论文集, 页13849-13860, 2024。

[171] P. Xu, Z. Deng, J. Wang, Q. Zhang, K.-S. Choi, and S. Wang. Transfer representation learning with tsk fuzzy system. IEEE Trans. on Fuzzy Systems, 29(3):649- 663, 2019.

[171] P. Xu, Z. Deng, J. Wang, Q. Zhang, K.-S. Choi, 和 S. Wang. 基于TSK模糊系统的迁移表示学习。IEEE模糊系统汇刊, 29(3):649-663, 2019。

[172] Q. Xu, R. Zhang, Y. Zhang, Y. Wang, and Q. Tian. A fourier-based framework for domain generalization. In Proc. of CVPR, pages 14383-14392, 2021.

[172] Q. Xu, R. Zhang, Y. Zhang, Y. Wang, 和 Q. Tian. 基于傅里叶变换的领域泛化框架。CVPR会议论文集, 页14383-14392, 2021。

[173] Q. Xuan, T. Yu, L. Bai, and Y. Ruan. Consistent augmentation learning for generalizing clip to unseen domains. IEEE Access, 2024.

[173] Q. Xuan, T. Yu, L. Bai, 和 Y. Ruan. 一致性增强学习以实现CLIP对未见领域的泛化。IEEE Access, 2024。

[174] S. Yan, C. Luo, Z. Yu, and Z. Ge. Generalizing clip to unseen domain via text-guided diverse novel feature synthesis. arXiv:2405.02586, 2024.

[174] S. Yan, C. Luo, Z. Yu, 和 Z. Ge. 通过文本引导的多样化新颖特征合成实现CLIP对未见领域的泛化。arXiv:2405.02586, 2024。

[175] L. Yang, R. Y. Zhang, Y. Wang, and X. Xie. Mma: Multimodal adapter for vision-language models. In Proc. of CVPR, pages 23826-23837, 2024.

[175] L. Yang, R. Y. Zhang, Y. Wang, 和 X. Xie. MMA:视觉语言模型的多模态适配器。CVPR会议论文集, 页23826-23837, 2024。

[176] Y. Yang, Y. Hou, L. Wen, P. Zeng, and Y. Wang. Semantic-aware adaptive prompt learning for universal multi-source domain adaptation. IEEE Signal Processing Letters, 2024.

[176] Y. Yang, Y. Hou, L. Wen, P. Zeng, 和 Y. Wang. 语义感知自适应提示学习用于通用多源领域自适应。IEEE信号处理快报, 2024。

[177] H. Yao, R. Zhang, and C. Xu. Visual-language prompt tuning with knowledge-guided context optimization. In Proc. of CVPR, pages 6757-6767, 2023.

[177] H. Yao, R. Zhang, 和 C. Xu. 基于知识引导上下文优化的视觉语言提示调优。CVPR会议论文集, 页6757-6767, 2023。

[178] Y. Yao, A. Zhang, Z. Zhang, Z. Liu, T.-S. Chua, and M. Sun. Cpt: Colorful prompt tuning for pre-trained vision-language models. arXiv e-prints, pages arXiv- 2109, 2021.

[178] Y. Yao, A. Zhang, Z. Zhang, Z. Liu, T.-S. Chua, 和 M. Sun. CPT:预训练视觉语言模型的彩色提示调优。arXiv电子预印本, 页arXiv-2109, 2021。

[179] M. Yi, L. Hou, J. Sun, L. Shang, X. Jiang, Q. Liu, and Z. Ma. Improved ood generalization via adversarial training and pretraining. In Proc. of ICML, pages 11987-11997. PMLR, 2021.

[179] M. Yi, L. Hou, J. Sun, L. Shang, X. Jiang, Q. Liu, 和 Z. Ma. 通过对抗训练和预训练提升OOD泛化能力。ICML会议论文集, 页11987-11997. PMLR, 2021。

[180] Y. Yin, Z. Yang, H. Hu, and X. Wu. Universal multi-source domain adaptation for image classification. ${PR}$ , 121:108238, 2022.

[180] Y. Yin, Z. Yang, H. Hu, 和 X. Wu. 通用多源领域自适应用于图像分类。${PR}$ , 121:108238, 2022。

[181] H. Yu, C. Jin, Y. Zhang, X. Cao, and Z. Fang. Domain prompt matters a lot in multi-source few-shot domain adaptation. openreview.net, 2024.

[181] H. Yu, C. Jin, Y. Zhang, X. Cao, 和 Z. Fang. 领域提示在多源少样本领域自适应中至关重要。openreview.net, 2024。

[182] Q. Yu, G. Irie, and K. Aizawa. Open-set domain adaptation with visual-language foundation models. arXiv:2307.16204, 2023.

[182] Q. Yu, G. Irie, 和 K. Aizawa. 基于视觉-语言基础模型的开放集域适应。arXiv:2307.16204, 2023.

[183] L. Yuan, D. Chen, Y.-L. Chen, N. Codella, X. Dai, J. Gao, H. Hu, X. Huang, B. Li, C. Li, et al. Florence: A new foundation model for computer vision. arXiv:2111.11432, 2021.

[183] L. Yuan, D. Chen, Y.-L. Chen, N. Codella, X. Dai, J. Gao, H. Hu, X. Huang, B. Li, C. Li 等. Florence:一种新的计算机视觉基础模型。arXiv:2111.11432, 2021.

[184] S. Yun, D. Han, S. J. Oh, S. Chun, J. Choe, and Y. Yoo. Cutmix: Regularization strategy to train strong classifiers with localizable features. In Proc. of ICCV, pages 6023-6032, 2019.

[184] S. Yun, D. Han, S. J. Oh, S. Chun, J. Choe, 和 Y. Yoo. Cutmix:一种通过局部可定位特征训练强分类器的正则化策略。发表于 ICCV 会议论文集，页码 6023-6032, 2019.

[185] Y. Zang, W. Li, K. Zhou, C. Huang, and C. C. Loy. Unified vision and language prompt learning. arXiv:2210.07225, 2022.

[185] Y. Zang, W. Li, K. Zhou, C. Huang, 和 C. C. Loy. 统一的视觉与语言提示学习。arXiv:2210.07225, 2022.

[186] S. Zeng, X. Liu, and Y. Zhou. Decoupling domain invariance and variance with tailored prompts for open-set domain adaptation. In Proc. of ICIP, pages 645-651, 2024.

[186] S. Zeng, X. Liu, 和 Y. Zhou. 通过定制提示解耦域不变性与方差以实现开放集域适应。发表于 ICIP 会议论文集，页码 645-651, 2024.

[187] B. Zhang, Y. Wang, W. Hou, H. Wu, J. Wang, M. Oku-mura, and T. Shinozaki. Flexmatch: Boosting semi-supervised learning with curriculum pseudo labeling. Proc. of NeurIPS, 34:18408-18419, 2021.

[187] B. Zhang, Y. Wang, W. Hou, H. Wu, J. Wang, M. Okumura, 和 T. Shinozaki. Flexmatch:通过课程伪标签提升半监督学习。发表于 NeurIPS，卷34，页码 18408-18419, 2021.

[188] H. Zhang. Mixup: Beyond empirical risk minimization. arXiv:1710.09412, 2017.

[188] H. Zhang. Mixup:超越经验风险最小化。arXiv:1710.09412, 2017.

[189] H. Zhang, S. Bai, W. Zhou, J. Fu, and B. Chen. Promptta: Prompt-driven text adapter for source-free domain generalization. arXiv:2409.14163, 2024.

[189] H. Zhang, S. Bai, W. Zhou, J. Fu, 和 B. Chen. Promptta:基于提示的文本适配器用于无源域泛化。arXiv:2409.14163, 2024.

[190] J. Zhang, Q. Wei, F. Liu, and L. Feng. Candidate pseu-dolabel learning: Enhancing vision-language models by prompt tuning with unlabeled data. In Proc. of ICML, page 235, 2024.

[190] J. Zhang, Q. Wei, F. Liu, 和 L. Feng. 候选伪标签学习:通过提示调优未标注数据以增强视觉-语言模型。发表于 ICML 会议论文集，页码 235, 2024.

[191] R. Zhang, Z. Guo, W. Zhang, K. Li, X. Miao, B. Cui, Y. Qiao, P. Gao, and H. Li. Pointclip: Point cloud understanding by clip. In Proc. of CVPR, pages 8552- 8562, 2022.

[191] R. Zhang, Z. Guo, W. Zhang, K. Li, X. Miao, B. Cui, Y. Qiao, P. Gao, 和 H. Li. Pointclip:基于 CLIP 的点云理解。发表于 CVPR 会议论文集，页码 8552-8562, 2022.

[192] W. Zhang, W. Ouyang, W. Li, and D. Xu. Collaborative and adversarial network for unsupervised domain adaptation. In Proc. of CVPR, pages 3801-3809, 2018.

[192] W. Zhang, W. Ouyang, W. Li, 和 D. Xu. 用于无监督域适应的协作与对抗网络。发表于 CVPR 会议论文集，页码 3801-3809, 2018.

[193] W. Zhang, L. Shen, and C.-S. Foo. Source-free domain adaptation guided by vision and vision-language pretraining. IJCV, pages 1-23, 2024.

[193] W. Zhang, L. Shen, 和 C.-S. Foo. 基于视觉及视觉-语言预训练的无源域适应指导。国际计算机视觉杂志(IJCV)，页码 1-23, 2024.

[194] X. Zhang, S. S. Gu, Y. Matsuo, and Y. Iwasawa. Domain prompt learning for efficiently adapting clip to unseen domains. Transactions of the Japanese Society for Artificial Intelligence, 38(6):B-MC2_1, 2023.

[194] X. Zhang, S. S. Gu, Y. Matsuo, 和 Y. Iwasawa. 域提示学习:高效适配 CLIP 至未见域。日本人工智能学会会刊，38(6):B-MC2_1, 2023.

[195] X. Zhang, Y. He, R. Xu, H. Yu, Z. Shen, and P. Cui. Nico++: Towards better benchmarking for domain generalization. In Proc. of CVPR, pages 16036-16047, 2023.

[195] X. Zhang, Y. He, R. Xu, H. Yu, Z. Shen, 和 P. Cui. Nico++:迈向更优的域泛化基准。发表于 CVPR 会议论文集，页码 16036-16047, 2023.

[196] X. Zhang, R. Xu, H. Yu, Y. Dong, P. Tian, and P. Cui. Flatness-aware minimization for domain generalization. In Proc. of ICCV, pages 5189-5202, 2023.

[196] X. Zhang, R. Xu, H. Yu, Y. Dong, P. Tian, 和 P. Cui. 面平坦感知最小化用于域泛化。发表于 ICCV 会议论文集，页码 5189-5202, 2023.

[197] Y. Zhang, H. Jiang, Y. Miura, C. D. Manning, and C. P. Langlotz. Contrastive learning of medical visual representations from paired images and text. In Proc. of MLHC, pages 2-25. PMLR, 2022.

[197] Y. Zhang, H. Jiang, Y. Miura, C. D. Manning, 和 C. P. Langlotz. 基于配对图像与文本的医学视觉表征对比学习。发表于 MLHC 会议论文集，页码 2-25，PMLR, 2022.

[198] H. Zhao, H. Chen, F. Yang, N. Liu, H. Deng, H. Cai, S. Wang, D. Yin, and M. Du. Explainability for large language models: A survey. ACM TIST, 15(2):1-38, 2024.

[198] 赵辉, 陈浩, 杨帆, 刘宁, 邓浩, 蔡辉, 王帅, 尹东, 杜明. 大型语言模型的可解释性综述. ACM TIST, 15(2):1-38, 2024.

[199] Z. Zhong, D. Friedman, and D. Chen. Factual probing is [mask]: Learning vs. learning to recall. arXiv:2104.05240, 2021.

[199] 钟志, 弗里德曼, 陈东. 事实探测是[掩码]: 学习与记忆的比较. arXiv:2104.05240, 2021.

[200] C. Zhou, C. C. Loy, and B. Dai. Extract free dense labels from clip. In Proc. of ECCV, pages 696-712. Springer, 2022.

[200] 周超, 罗志成, 戴斌. 从CLIP中提取自由密集标签. ECCV会议论文集, 页696-712. Springer, 2022.

[201] K. Zhou, Y. Yang, T. Hospedales, and T. Xiang. Learning to generate novel domains for domain generalization. In Proc. of ECCV, pages 561-578. Springer, 2020.

[201] 周康, 杨洋, Hospedales, Xiang. 学习生成新颖领域以实现领域泛化. ECCV会议论文集, 页561-578. Springer, 2020.

[202] K. Zhou, Y. Yang, Y. Qiao, and T. Xiang. Domain generalization with mixstyle. arXiv:2104.02008, 2021.

[202] 周康, 杨洋, 乔阳, 向涛. 通过MixStyle实现领域泛化. arXiv:2104.02008, 2021.

[203] K. Zhou, J. Yang, C. C. Loy, and Z. Liu. Conditional prompt learning for vision-language models. In Proc. of CVPR, pages 16816-16825, 2022.

[203] 周康, 杨健, 罗志成, 刘志. 视觉语言模型的条件提示学习. CVPR会议论文集, 页16816-16825, 2022.

[204] K. Zhou, J. Yang, C. C. Loy, and Z. Liu. Learning to prompt for vision-language models. IJCV, 130(9): 2337-2348, 2022.

[204] 周康, 杨健, 罗志成, 刘志. 视觉语言模型的提示学习. IJCV, 130(9): 2337-2348, 2022.

[205] W. Zhou and Z. Zhou. Unsupervised domain adaptation harnessing vision-language pre-training. IEEE TCSVT, 2024.

[205] 周伟, 周志. 利用视觉语言预训练进行无监督领域自适应. IEEE TCSVT, 2024.

[206] B. Zhu, Y. Niu, Y. Han, Y. Wu, and H. Zhang. Prompt-aligned gradient for prompt tuning. In Proc. of ICCV, pages 15659-15669, 2023.

[206] 朱斌, 牛阳, 韩宇, 吴越, 张华. 提示对齐梯度用于提示调优. ICCV会议论文集, 页15659-15669, 2023.

[207] J. Zhu, Y. Chen, and L. Wang. Clip the divergence: Language-guided unsupervised domain adaptation. arXiv:2407.01842, 2024.

[207] 朱军, 陈阳, 王磊. 剪除偏差: 语言引导的无监督领域自适应. arXiv:2407.01842, 2024.

[208] Y. Zou, Z. Yu, B. V. K. Kumar, and J. Wang. Unsupervised domain adaptation for semantic segmentation via class-balanced self-training. In Proc. of ECCV, pages 289-305, 2018.

[208] 邹毅, 余志, Kumar, 王军. 通过类别平衡自训练实现语义分割的无监督领域自适应. ECCV会议论文集, 页289-305, 2018.

[209] H. Zuo, J. Lu, G. Zhang, and W. Pedrycz. Fuzzy rule-based domain adaptation in homogeneous and heterogeneous spaces. IEEE Trans. on Fuzzy Systems,

[209] 左浩, 陆军, 张刚, Pedrycz. 同质与异质空间中的模糊规则域自适应. IEEE模糊系统汇刊,