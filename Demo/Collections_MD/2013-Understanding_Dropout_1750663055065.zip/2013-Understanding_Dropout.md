# Understanding Dropout

# 理解Dropout

Pierre Baldi

Pierre Baldi

Department of Computer Science

计算机科学系

University of California, Irvine

加州大学欧文分校

Irvine, CA 92697

加利福尼亚州欧文市 92697

pfbaldi@uci.edu

Peter Sadowski

Peter Sadowski

Department of Computer Science

计算机科学系

University of California, Irvine

加州大学欧文分校

Irvine, CA 92697

加利福尼亚州欧文市 92697

pjsadows@ics.uci.edu

## Abstract

## 摘要

Dropout is a relatively new algorithm for training neural networks which relies on stochastically "dropping out" neurons during training in order to avoid the co-adaptation of feature detectors. We introduce a general formalism for studying dropout on either units or connections, with arbitrary probability values, and use it to analyze the averaging and regularizing properties of dropout in both linear and non-linear networks. For deep neural networks, the averaging properties of dropout are characterized by three recursive equations, including the approximation of expectations by normalized weighted geometric means. We provide estimates and bounds for these approximations and corroborate the results with simulations. Among other results, we also show how dropout performs stochastic gradient descent on a regularized error function.

Dropout是一种相对较新的神经网络训练算法，通过在训练过程中随机“丢弃”神经元，以避免特征检测器的协同适应。我们提出了一个通用形式，用于研究以任意概率对单元或连接进行dropout，并利用该形式分析了dropout在线性和非线性网络中的平均化和正则化特性。对于深度神经网络，dropout的平均化特性由三个递归方程描述，其中包括通过归一化加权几何平均近似期望值。我们提供了这些近似的估计和界限，并通过模拟验证了结果。除此之外，我们还展示了dropout如何在正则化误差函数上执行随机梯度下降。

## 1 Introduction

## 1 引言

Dropout is an algorithm for training neural networks that was described at NIPS 2012 [7]. In its most simple form, during training, at each example presentation, feature detectors are deleted with probability $q = 1 - p = {0.5}$ and the remaining weights are trained by backpropagation. All weights are shared across all example presentations. During prediction, the weights are divided by two. The main motivation behind the algorithm is to prevent the co-adaptation of feature detectors, or overfitting, by forcing neurons to be robust and rely on population behavior, rather than on the activity of other specific units. In [7], dropout is reported to achieve state-of-the-art performance on several benchmark datasets. It is also noted that for a single logistic unit dropout performs a kind of "geometric averaging" over the ensemble of possible subnetworks, and conjectured that something similar may occur also in multilayer networks leading to the view that dropout may be an economical approximation to training and using a very large ensemble of networks.

Dropout是一种用于训练神经网络的算法，首次在NIPS 2012[7]上提出。其最简单的形式是在训练时，每次呈现样本时，以概率$q = 1 - p = {0.5}$删除特征检测器，剩余的权重通过反向传播进行训练。所有权重在所有样本呈现中共享。预测时，权重除以二。该算法的主要动机是防止特征检测器的协同适应或过拟合，迫使神经元变得鲁棒，依赖于整体群体行为，而非其他特定单元的活动。[7]中报告dropout在多个基准数据集上达到了最先进的性能。文中还指出，对于单个逻辑单元，dropout执行了一种对可能子网络集合的“几何平均”，并推测在多层网络中可能也存在类似现象，从而认为dropout可能是训练和使用非常大规模网络集成的经济近似方法。

In spite of the impressive results that have been reported, little is known about dropout from a theoretical standpoint, in particular about its averaging, regularization, and convergence properties. Likewise little is known about the importance of using $q = {0.5}$ , whether different values of $q$ can be used including different values for different layers or different units, and whether dropout can be applied to the connections rather than the units. Here we address these questions.

尽管已有令人印象深刻的结果报道，但从理论角度对dropout的了解仍然有限，特别是其平均化、正则化和收敛性质。同样，对于使用$q = {0.5}$的重要性、是否可以使用不同的$q$值(包括对不同层或不同单元使用不同值)，以及dropout是否可以应用于连接而非单元，知之甚少。本文将探讨这些问题。

## 2 Dropout in Linear Networks

## 2 线性网络中的Dropout

It is instructive to first look at some of the properties of dropout in linear networks, since these can be studied exactly in the most general setting of a multilayer feedforward network described by an underlying acyclic graph. The activity in unit $i$ of layer $h$ can be expressed as:

首先考察线性网络中dropout的一些性质是有益的，因为这些性质可以在多层前馈网络的最一般设置下精确研究，该网络由一个无环图描述。层$h$中单元$i$的活动可以表示为:

$$
{S}_{i}^{h}\left( I\right)  = \mathop{\sum }\limits_{{l < h}}\mathop{\sum }\limits_{j}{w}_{ij}^{hl}{S}_{j}^{l}\;\text{ with }\;{S}_{j}^{0} = {I}_{j} \tag{1}
$$

where the variables $w$ denote the weights and $I$ the input vector. Dropout applied to the units can be expressed in the form

其中变量$w$表示权重，$I$表示输入向量。应用于单元的Dropout可以表示为

$$
{S}_{i}^{h} = \mathop{\sum }\limits_{{l < h}}\mathop{\sum }\limits_{j}{w}_{ij}^{hl}{\delta }_{j}^{l}{S}_{j}^{l}\;\text{ with }\;{S}_{j}^{0} = {I}_{j} \tag{2}
$$

where ${\delta }_{j}^{l}$ is a gating 0-1 Bernoulli variable, with $P\left( {{\delta }_{j}^{l} = 1}\right)  = {p}_{j}^{l}$ . Throughout this paper we assume that the variables ${\delta }_{j}^{l}$ are independent of each other, independent of the weights, and independent of the activity of the units. Similarly, dropout applied to the connections leads to the random variables

其中${\delta }_{j}^{l}$是一个门控的0-1伯努利(Bernoulli)变量，且$P\left( {{\delta }_{j}^{l} = 1}\right)  = {p}_{j}^{l}$。在本文中，我们假设变量${\delta }_{j}^{l}$彼此独立，且与权重及单元的活动无关。类似地，应用于连接的Dropout导致随机变量

$$
{S}_{i}^{h} = \mathop{\sum }\limits_{{l < h}}\mathop{\sum }\limits_{j}{\delta }_{ij}^{hl}{w}_{ij}^{hl}{S}_{j}^{l}\;\text{ with }\;{S}_{j}^{0} = {I}_{j} \tag{3}
$$

For brevity in the rest of this paper, we focus exclusively on dropout applied to the units, but all the results remain true for the case of dropout applied to the connections with minor adjustments.

为简洁起见，本文余下部分专注于应用于单元的Dropout，但所有结果对应用于连接的Dropout也同样适用，仅需做少量调整。

For a fixed input vector, the expectation of the activity of all the units, taken over all possible realizations of the gating variables hence all possible subnetworks, is given by:

对于固定的输入向量，所有单元的活动期望值(在所有可能的门控变量实现即所有可能的子网络上取平均)由下式给出:

$$
E\left( {S}_{i}^{h}\right)  = \mathop{\sum }\limits_{{l < h}}\mathop{\sum }\limits_{j}{w}_{ij}^{hl}{p}_{j}^{l}E\left( {S}_{j}^{l}\right) \;\text{ for }\;h > 0 \tag{4}
$$

with $E\left( {S}_{j}^{0}\right)  = {I}_{j}$ in the input layer. In short, the ensemble average can easily be computed by feedforward propagation in the original network, simply replacing the weights ${w}_{ij}^{hl}$ by ${w}_{ij}^{hl}{p}_{j}^{l}$ .

其中输入层的$E\left( {S}_{j}^{0}\right)  = {I}_{j}$。简言之，集成平均值可以通过在原始网络中进行前向传播轻松计算，只需将权重${w}_{ij}^{hl}$替换为${w}_{ij}^{hl}{p}_{j}^{l}$即可。

## 3 Dropout in Neural Networks

## 3 神经网络中的Dropout

### 3.1 Dropout in Shallow Neural Networks

### 3.1 浅层神经网络中的Dropout

Consider first a single logistic unit with $n$ inputs $O = \sigma \left( S\right)  = 1/\left( {1 + c{e}^{-{\lambda S}}}\right)$ and $S = \mathop{\sum }\limits_{1}^{n}{w}_{j}{I}_{j}$ . To achieve the greatest level of generality, we assume that the unit produces different outputs ${O}_{1},\ldots ,{O}_{m}$ , corresponding to different sums ${S}_{1}\ldots ,{S}_{m}$ with different probabilities ${P}_{1},\ldots ,{P}_{m}$ $\left( {\sum {P}_{m} = 1}\right)$ . In the most relevant case, these outputs and these sums are associated with the $m = {2}^{n}$ possible subnetworks of the unit. The probabilities ${P}_{1},\ldots ,{P}_{m}$ could be generated, for instance, by using Bernoulli gating variables, although this is not necessary for this derivation. It is useful to define the following four quantities: the mean $E = \sum {P}_{i}{O}_{i}$ ; the mean of the complements ${E}^{\prime } = \sum {P}_{i}\left( {1 - {O}_{i}}\right)  = 1 - E$ ; the weighted geometric mean (WGM) $G = \mathop{\prod }\limits_{i}{O}_{i}^{{P}_{i}}$ ; and the weighted geometric mean of the complements ${G}^{\prime } = \mathop{\prod }\limits_{i}{\left( 1 - {O}_{i}\right) }^{{P}_{i}}$ . We also define the normalized weighted geometric mean ${NWGM} = G/\left( {G + {G}^{\prime }}\right)$ . We can now prove the key averaging theorem for logistic functions:

首先考虑一个具有$n$个输入$O = \sigma \left( S\right)  = 1/\left( {1 + c{e}^{-{\lambda S}}}\right)$和$S = \mathop{\sum }\limits_{1}^{n}{w}_{j}{I}_{j}$的单个逻辑单元。为了达到最大的通用性，我们假设该单元产生不同的输出${O}_{1},\ldots ,{O}_{m}$，对应于不同的加权和${S}_{1}\ldots ,{S}_{m}$，其概率为${P}_{1},\ldots ,{P}_{m}$$\left( {\sum {P}_{m} = 1}\right)$。在最相关的情况下，这些输出和加权和与单元的$m = {2}^{n}$个可能子网络相关联。概率${P}_{1},\ldots ,{P}_{m}$可以通过使用伯努利门控变量生成，尽管这对本推导不是必需的。定义以下四个量是有用的:均值$E = \sum {P}_{i}{O}_{i}$；补集的均值${E}^{\prime } = \sum {P}_{i}\left( {1 - {O}_{i}}\right)  = 1 - E$；加权几何均值(WGM)$G = \mathop{\prod }\limits_{i}{O}_{i}^{{P}_{i}}$；补集的加权几何均值${G}^{\prime } = \mathop{\prod }\limits_{i}{\left( 1 - {O}_{i}\right) }^{{P}_{i}}$。我们还定义了归一化加权几何均值${NWGM} = G/\left( {G + {G}^{\prime }}\right)$。现在我们可以证明逻辑函数的关键平均定理:

$$
{NWGM}\left( {{O}_{1},\ldots ,{O}_{m}}\right)  = \frac{1}{1 + c{e}^{-{\lambda E}\left( S\right) }} = \sigma \left( {E\left( S\right) }\right)  \tag{5}
$$

To prove this result, we write

为证明此结果，我们写出

$$
{NWGM}\left( {{O}_{1},\ldots ,{O}_{m}}\right)  = \frac{1}{1 + \frac{\prod {\left( 1 - {O}_{i}\right) }^{{P}_{i}}}{\prod {O}_{i}^{{P}_{i}}}} = \frac{1}{1 + \frac{\prod {\left( 1 - \sigma \left( {S}_{i}\right) \right) }^{{P}_{i}}}{\prod \sigma {\left( {S}_{i}\right) }^{{P}_{i}}}} \tag{6}
$$

The logistic function satisfies the identity $\left\lbrack  {1 - \sigma \left( x\right) }\right\rbrack  /\sigma \left( x\right)  = c{e}^{-{\lambda x}}$ and thus

逻辑函数满足恒等式$\left\lbrack  {1 - \sigma \left( x\right) }\right\rbrack  /\sigma \left( x\right)  = c{e}^{-{\lambda x}}$，因此

$$
{NWGM}\left( {{O}_{1},\ldots ,{O}_{m}}\right)  = \frac{1}{1 + \prod \left\lbrack  {c{e}^{-\lambda {S}_{i}}}\right\rbrack  {P}_{i}} = \frac{1}{1 + c{e}^{-\lambda \sum {P}_{i}{S}_{i}}} = \sigma \left( {E\left( S\right) }\right)  \tag{7}
$$

Thus in the case of Bernoulli gating variables, we can compute the NWGM over all possible dropout configurations by simple forward propagation by: ${NWGM} = \sigma \left( {\mathop{\sum }\limits_{1}^{n}{w}_{j}{p}_{j}{I}_{j}}\right)$ . A similar result is true also for normalized exponential transfer functions. Finally, one can also show that the only class of functions $f$ that satisfy ${NWGM}\left( f\right)  = f\left( E\right)$ are the constant functions and the logistic functions [1].

因此，在伯努利门控变量的情况下，我们可以通过简单的前向传播计算所有可能Dropout配置的NWGM:${NWGM} = \sigma \left( {\mathop{\sum }\limits_{1}^{n}{w}_{j}{p}_{j}{I}_{j}}\right)$。类似的结果也适用于归一化指数传递函数。最后，还可以证明满足${NWGM}\left( f\right)  = f\left( E\right)$的函数类$f$仅有常数函数和逻辑函数[1]。

### 3.2 Dropout in Deep Neural Networks

### 3.2 深度神经网络中的Dropout

We can now deal with the most interesting case of deep feedforward networks of sigmoidal units ${}^{T}$ described by a set of equations of the form

我们现在可以处理最有趣的情况，即由一组形式为的方程描述的深度前馈sigmoid单元网络${}^{T}$

$$
{O}_{i}^{h} = \sigma \left( {S}_{i}^{h}\right)  = \sigma \left( {\mathop{\sum }\limits_{{l < h}}\mathop{\sum }\limits_{j}{w}_{ij}^{hl}{O}_{j}^{l}}\right) \;\text{ with }\;{O}_{j}^{0} = {I}_{j} \tag{8}
$$

where ${O}_{i}^{h}$ is the output of unit $i$ in layer $h$ . Dropout on the units can be described by

其中 ${O}_{i}^{h}$ 是第 $h$ 层中单元 $i$ 的输出。单元上的Dropout可以描述为

$$
{O}_{i}^{h} = \sigma \left( {S}_{i}^{h}\right)  = \sigma \left( {\mathop{\sum }\limits_{{l < h}}\mathop{\sum }\limits_{j}{w}_{ij}^{hl}{\delta }_{j}^{l}{O}_{j}^{l}}\right) \;\text{ with }\;{O}_{j}^{0} = {I}_{j} \tag{9}
$$

using the Bernoulli selector variables ${\delta }_{j}^{l}$ . For each sigmoidal unit

使用伯努利选择变量 ${\delta }_{j}^{l}$ 。对于每个sigmoidal单元

$$
{NWGM}\left( {O}_{i}^{h}\right)  = \frac{\mathop{\prod }\limits_{\mathcal{N}}{\left( {O}_{i}^{h}\right) }^{P\left( \mathcal{N}\right) }}{\mathop{\prod }\limits_{\mathcal{N}}{\left( {O}_{i}^{h}\right) }^{P\left( \mathcal{N}\right) } + \mathop{\prod }\limits_{\mathcal{N}}{\left( 1 - {O}_{i}^{h}\right) }^{P\left( \mathcal{N}\right) }} \tag{10}
$$

where $\mathcal{N}$ ranges over all possible subnetworks. Assume for now that the ${NWGM}$ provides a good approximation to the expectation (this point will be analyzed in the next section). Then the averaging properties of dropout are described by the following three recursive equations. First the approximation of means by NWGMs:

其中 $\mathcal{N}$ 遍历所有可能的子网络。暂且假设 ${NWGM}$ 能很好地近似期望值(这一点将在下一节中分析)。那么Dropout的平均性质由以下三个递归方程描述。首先是通过归一化加权几何均值(NWGM)对均值的近似:

$$
E\left( {O}_{i}^{h}\right)  \approx  {NWGM}\left( {O}_{i}^{h}\right)  \tag{11}
$$

Second, using the result of the previous section, the propagation of expectation symbols:

其次，利用上一节的结果，期望符号的传播:

$$
{NWGM}\left( {O}_{i}^{h}\right)  = {\sigma }_{i}^{h}\left\lbrack  {E\left( {S}_{i}^{h}\right) }\right\rbrack   \tag{12}
$$

And third, using the linearity of the expectation with respect to sums, and to products of independent random variables:

第三，利用期望对和的线性以及对独立随机变量乘积的线性:

$$
E\left( {S}_{i}^{h}\right)  = \mathop{\sum }\limits_{{l < h}}\mathop{\sum }\limits_{j}{w}_{ij}^{hl}{p}_{j}^{l}E\left( {O}_{j}^{l}\right)  \tag{13}
$$

Equations 11, 12, and 13 are the fundamental equations explaining the averaging properties of the dropout procedure. The only approximation is of course Equation 11 which is analyzed in the next section. If the network contains linear units, then Equation 11 is not necessary for those units and their average can be computed exactly. In the case of regression with linear units in the top layers, this allows one to shave off one layer of approximations. The same is true in binary classification by requiring the output layer to compute directly the ${NWGM}$ of the ensemble rather than the expectation. It can be shown that for any error function that is convex up $\left( \cup \right)$ , the error of the mean, weighted geometric mean, and normalized weighted geometric mean of an ensemble is always less than the expected error of the models [1].

方程11、12和13是解释Dropout过程平均性质的基本方程。当然，唯一的近似是方程11，这将在下一节中分析。如果网络包含线性单元，那么对于这些单元，方程11不是必需的，其平均值可以精确计算。在顶层含有线性单元的回归情况下，这允许减少一层近似。在二分类中，通过要求输出层直接计算集成的 ${NWGM}$ 而非期望值，也有同样效果。可以证明，对于任何凸向上的误差函数 $\left( \cup \right)$ ，集成的均值、加权几何均值和归一化加权几何均值的误差总是小于模型的期望误差[1]。

Equation 11 is exact if and only if the numbers ${O}_{i}^{h}$ are identical over all possible subnetworks $\mathcal{N}$ . Thus it is useful to measure the consistency $C\left( {{O}_{i}^{h}, I}\right)$ of neuron $i$ in layer $h$ for input $I$ by using the variance $\operatorname{Var}\left\lbrack  {{O}_{i}^{h}\left( I\right) }\right\rbrack$ taken over all subnetworks $\mathcal{N}$ and their distribution when the input $I$ is fixed. The larger the variance is, the less consistent the neuron is, and the worse we can expect the approximation in Equation 11 to be. Note that for a random variable $O$ in $\left\lbrack  {0,1}\right\rbrack$ the variance cannot exceed $1/4$ anyway. This is because $\operatorname{Var}\left( O\right)  = E\left( {O}^{2}\right)  - {\left( E\left( O\right) \right) }^{2} \leq  E\left( O\right)  - {\left( E\left( O\right) \right) }^{2} =$ $E\left( O\right) \left( {1 - E\left( O\right) }\right)  \leq  1/4$ . This measure can also be averaged over a training set or a test set.

当且仅当所有可能子网络 $\mathcal{N}$ 中的数值 ${O}_{i}^{h}$ 相同时，方程11是精确的。因此，测量第 $h$ 层中神经元 $i$ 对输入 $I$ 的一致性 $C\left( {{O}_{i}^{h}, I}\right)$ 是有用的，该一致性通过对所有子网络 $\mathcal{N}$ 及其分布在固定输入 $I$ 下的方差 $\operatorname{Var}\left\lbrack  {{O}_{i}^{h}\left( I\right) }\right\rbrack$ 来衡量。方差越大，神经元越不一致，方程11的近似效果越差。注意，对于定义在 $\left\lbrack  {0,1}\right\rbrack$ 上的随机变量 $O$，其方差无论如何不会超过 $1/4$。这是因为 $\operatorname{Var}\left( O\right)  = E\left( {O}^{2}\right)  - {\left( E\left( O\right) \right) }^{2} \leq  E\left( O\right)  - {\left( E\left( O\right) \right) }^{2} =$ $E\left( O\right) \left( {1 - E\left( O\right) }\right)  \leq  1/4$ 。该度量也可以在训练集或测试集上取平均。

---

${}^{1}$ Given the results of the previous sections, the network can also include linear units or normalized exponential units.

${}^{1}$ 根据前几节的结果，网络还可以包含线性单元或归一化指数单元。

---

## 4 The Dropout Approximation

## 4 Dropout近似

Given a set of numbers ${O}_{1},\ldots ,{O}_{m}$ between 0 and 1, with probabilities ${P}_{1},\ldots ,{P}_{M}$ (corresponding to the outputs of a sigmoidal neuron for a fixed input and different subnetworks), we are primarily interested in the approximation of $E$ by ${NWGM}$ . The ${NWGM}$ provides a good approximation because we show below that to a first order of approximation: $E \approx  {NWGM}$ and $E \approx  G$ . Furthermore, there are formulae in the literature for bounding the error $E - G$ in terms of the consistency (e.g. the Cartwright and Field inequality [6]). However, one can suspect that the NWGM provides even a better approximation to $E$ than the geometric mean. For instance, if the numbers ${O}_{i}$ satisfy $0 < {O}_{i} \leq  {0.5}$ (consistently low), then

给定一组介于0和1之间的数值 ${O}_{1},\ldots ,{O}_{m}$，及其概率 ${P}_{1},\ldots ,{P}_{M}$(对应于固定输入和不同子网络下sigmoidal神经元的输出)，我们主要关注用 ${NWGM}$ 近似 $E$ 。 ${NWGM}$ 提供了良好的近似，因为我们下面将展示，一阶近似下:$E \approx  {NWGM}$ 和 $E \approx  G$ 。此外，文献中有关于误差 $E - G$ 的界定公式，基于一致性(例如Cartwright和Field不等式[6])。然而，可以怀疑NWGM对 $E$ 的近似甚至优于几何均值。例如，如果数值 ${O}_{i}$ 满足 $0 < {O}_{i} \leq  {0.5}$(一致地较低)，则

$$
\frac{G}{{G}^{\prime }} \leq  \frac{E}{{E}^{\prime }}\;\text{ and therefore }\;G \leq  \frac{G}{G + {G}^{\prime }} \leq  E \tag{14}
$$

This is proven by applying Jensen’s inequality to the function $\ln x - \ln \left( {1 - x}\right)$ for $x \in  (0,{0.5}\rbrack$ . It is also known as the Ky Fan inequality [2, 8, 9].

这可以通过对函数$\ln x - \ln \left( {1 - x}\right)$应用詹森不等式(Jensen’s inequality)来证明，针对$x \in  (0,{0.5}\rbrack$。这也被称为Ky Fan不等式[2, 8, 9]。

To get even better results, one must consider a second order approximation. For this, we write ${O}_{i} = {0.5} + {\epsilon }_{i}$ with $0 \leq  \left| {\epsilon }_{i}\right|  \leq  {0.5}$ . Thus we have $E\left( O\right)  = {0.5} + E\left( \epsilon \right)$ and $\operatorname{Var}\left( O\right)  = \operatorname{Var}\left( \epsilon \right)$ . Using a Taylor expansion:

为了获得更好的结果，必须考虑二阶近似。为此，我们用$0 \leq  \left| {\epsilon }_{i}\right|  \leq  {0.5}$表示${O}_{i} = {0.5} + {\epsilon }_{i}$。因此我们有$E\left( O\right)  = {0.5} + E\left( \epsilon \right)$和$\operatorname{Var}\left( O\right)  = \operatorname{Var}\left( \epsilon \right)$。利用泰勒展开:

$$
G = \frac{1}{2}\mathop{\prod }\limits_{i}\mathop{\sum }\limits_{{n = 0}}^{\infty }\left( \begin{matrix} {p}_{i} \\  n \end{matrix}\right) {\left( 2{\epsilon }_{i}\right) }^{n} = \frac{1}{2}\left\lbrack  {1 + \mathop{\sum }\limits_{i}{p}_{i}2{\epsilon }_{i} + \mathop{\sum }\limits_{i}\frac{{p}_{i}\left( {{p}_{i} - 1}\right) }{2}{\left( 2{\epsilon }_{i}\right) }^{2} + \mathop{\sum }\limits_{{i < j}}4{p}_{i}{p}_{j}{\epsilon }_{i}{\epsilon }_{j} + {R}_{3}\left( {\epsilon }_{i}\right) }\right\rbrack
$$

(15)

where ${R}_{3}\left( {\epsilon }_{i}\right)$ is the remainder and

其中${R}_{3}\left( {\epsilon }_{i}\right)$是余项，且

$$
{R}_{3}\left( {\epsilon }_{i}\right)  = \left( \begin{matrix} {p}_{i} \\  3 \end{matrix}\right) \frac{{\left( 2{\epsilon }_{i}\right) }^{3}}{{\left( 1 + {u}_{i}\right) }^{3 - {p}_{i}}} \tag{16}
$$

where $\left| {u}_{i}\right|  \leq  2\left| {\epsilon }_{i}\right|$ . Expanding the product gives

其中$\left| {u}_{i}\right|  \leq  2\left| {\epsilon }_{i}\right|$。展开乘积得到

$$
G = \frac{1}{2} + \mathop{\sum }\limits_{i}{p}_{i}{\epsilon }_{i} + {\left( \mathop{\sum }\limits_{i}{\epsilon }_{i}\right) }^{2} - \sum {p}_{i}{\epsilon }_{i}^{2} + {R}_{3}\left( \epsilon \right)  = \frac{1}{2} + E\left( \epsilon \right)  - \operatorname{Var}\left( \epsilon \right)  + {R}_{3}\left( \epsilon \right)  = E\left( O\right)  - \operatorname{Var}\left( O\right)  + {R}_{3}\left( \epsilon \right)
$$

(17)

By symmetry, we have

由于对称性，我们有

$$
{G}^{\prime } = \mathop{\prod }\limits_{i}{\left( 1 - {O}_{i}\right) }^{{p}_{i}} = 1 - E\left( O\right)  - \operatorname{Var}\left( O\right)  + {R}_{3}\left( \epsilon \right)  \tag{18}
$$

where ${R}_{3}\left( \epsilon \right)$ is the higher order remainder. Neglecting the remainder and writing $E = E\left( O\right)$ and $V = \operatorname{Var}\left( O\right)$ we have

其中${R}_{3}\left( \epsilon \right)$是高阶余项。忽略余项并写出$E = E\left( O\right)$和$V = \operatorname{Var}\left( O\right)$，我们得到

$$
\frac{G}{G + {G}^{\prime }} \approx  \frac{E - V}{1 - {2V}}\;\text{ and }\frac{{G}^{\prime }}{G + {G}^{\prime }} \approx  \frac{1 - E - V}{1 - {2V}} \tag{19}
$$

Thus, to a second order, the differences between the mean and the geometric mean and the normalized geometric means satisfy

因此，在二阶近似下，均值与几何均值及归一化几何均值之间的差异满足

$$
E - G \approx  V\;\text{ and }\;E - \frac{G}{G + {G}^{\prime }} \approx  \frac{V\left( {1 - {2E}}\right) }{1 - {2V}} \tag{20}
$$

and

和

$$
1 - E - {G}^{\prime } \approx  V\;\text{ and }\;\left( {1 - E}\right)  - \frac{{G}^{\prime }}{G + {G}^{\prime }} \approx  \frac{V\left( {1 - {2E}}\right) }{1 - {2V}} \tag{21}
$$

Finally it is easy to check that the factor $\left( {1 - {2E}}\right) /\left( {1 - {2V}}\right)$ is always less or equal to 1 . In addition we always have $V \leq  E\left( {1 - E}\right)$ , with equality achieved only for 0-1 Bernoulli variables. Thus

最后，很容易验证因子$\left( {1 - {2E}}\right) /\left( {1 - {2V}}\right)$始终小于或等于1。此外，我们总有$V \leq  E\left( {1 - E}\right)$，且仅当为0-1伯努利变量时取等号。因此

$$
\left| {E - \frac{G}{G + {G}^{\prime }}}\right|  \approx  \frac{V\left| {1 - {2E}}\right| }{1 - {2V}} \leq  \frac{E\left( {1 - E}\right) \left| {1 - {2E}}\right| }{1 - {2V}} \leq  {2E}\left( {1 - E}\right) \left| {1 - {2E}}\right|  \tag{22}
$$

The first inequality is optimal in the sense that it is attained in the case of a Bernoulli variable with expectation $E$ and, intuitively, the second inequality shows that the approximation error is always small, regardless of whether $E$ is close to 0,0.5, or 1 . In short, the NWGM provides a very good approximation to $E$ , better than the geometric mean $G$ . The property is always true to a second order of approximation and it is exact when the activities are consistently low, or when ${NWGM} \leq  E$ , since the latter implies $G \leq  {NWGM} \leq  E$ . Several additional properties of the dropout approximation, including the extension to rectified linear units and other transfer functions, are studied in [1].

第一个不等式在伯努利变量期望为$E$的情况下达到最优，直观上，第二个不等式表明无论$E$接近0、0.5还是1，近似误差始终较小。简言之，NWGM对$E$提供了非常好的近似，优于几何均值$G$。该性质在二阶近似下始终成立，并且当活动值始终较低或当${NWGM} \leq  E$时精确成立，因为后者意味着$G \leq  {NWGM} \leq  E$。[1]中研究了dropout近似的若干附加性质，包括对修正线性单元(ReLU)及其他传递函数的扩展。

## 5 Dropout Dynamics

## 5 Dropout 动态

Dropout performs gradient descent on-line with respect to both the training examples and the ensemble of all possible subnetworks. As such, and with the appropriately decreasing learning rates, it is almost surely convergent like other forms of stochastic gradient descent [11, 4, 5]. To further understand the properties of dropout, it is again instructive to look at the properties of the gradient in the linear case.

Dropout在线上对训练样本及所有可能子网络的集合执行梯度下降。因此，配合适当递减的学习率，它几乎必然收敛，类似于其他形式的随机梯度下降[11, 4, 5]。为了进一步理解dropout的性质，再次考察线性情况下梯度的性质是有益的。

### 5.1 Single Linear Unit

### 5.1 单个线性单元

In the case of a single linear unit, consider the two error functions ${E}_{ENS}$ and ${E}_{D}$ associated with the ensemble of all possible subnetworks and the network with dropout. For a single input $I$ , these are defined by:

对于单个线性单元，考虑与所有可能子网络集合及带dropout的网络相关的两个误差函数${E}_{ENS}$和${E}_{D}$。对于单个输入$I$，它们定义为:

$$
{E}_{ENS} = \frac{1}{2}{\left( t - {O}_{ENS}\right) }^{2} = \frac{1}{2}{\left( t - \mathop{\sum }\limits_{{i = 1}}^{n}{p}_{i}{w}_{i}{I}_{i}\right) }^{2} \tag{23}
$$

$$
{E}_{D} = \frac{1}{2}{\left( t - {O}_{D}\right) }^{2} = \frac{1}{2}{\left( t - \mathop{\sum }\limits_{{i = 1}}^{n}{\delta }_{i}{w}_{i}{I}_{i}\right) }^{2} \tag{24}
$$

We use a single training input $I$ for notational simplicity, otherwise the errors of each training example can be combined additively. The learning gradient is given by

为简化符号，我们使用单个训练输入$I$，否则每个训练样本的误差可以加和。学习梯度表示为

$$
\frac{\partial {E}_{ENS}}{\partial {w}_{i}} =  - \left( {t - {O}_{ENS}}\right) \frac{\partial {O}_{ENS}}{\partial {w}_{i}} =  - \left( {t - {O}_{ENS}}\right) {p}_{i}{I}_{i} \tag{25}
$$

$$
\frac{\partial {E}_{D}}{\partial {w}_{i}} =  - \left( {t - {O}_{D}}\right) \frac{\partial {O}_{D}}{\partial {w}_{i}} =  - \left( {t - {O}_{D}}\right) {\delta }_{i}{I}_{i} =  - t{\lambda }_{i}{I}_{i} + {w}_{i}{\delta }_{i}^{2}{I}_{i}^{2} + \mathop{\sum }\limits_{{j \neq  i}}{w}_{j}{\delta }_{i}{\delta }_{j}{I}_{i}{I}_{j} \tag{26}
$$

The dropout gradient is a random variable and we can take its expectation. A short calculation yields

dropout梯度是一个随机变量，我们可以取其期望。简短计算得出

$$
E\left( \frac{\partial {E}_{D}}{\partial {w}_{i}}\right)  = \frac{\partial {E}_{ENS}}{\partial {w}_{i}} + {w}_{i}{p}_{i}\left( {1 - {p}_{i}}\right) {I}_{i}^{2}\frac{\partial {E}_{ENS}}{\partial {w}_{i}} + {w}_{i}{I}_{i}^{2}\operatorname{Var}\left( {\delta }_{i}\right)  \tag{27}
$$

Thus, remarkably, in this case the expectation of the gradient with dropout is the gradient of the regularized ensemble error

因此，值得注意的是，在这种情况下，带有dropout的梯度期望是正则化集成误差的梯度

$$
E = {E}_{ENS} + \frac{1}{2}\mathop{\sum }\limits_{{i = 1}}^{n}{w}_{i}^{2}{I}_{i}^{2}\operatorname{Var}\left( {\delta }_{i}\right)  \tag{28}
$$

The regularization term is the usual weight decay or Gaussian prior term based on the square of the weights to prevent overfitting. Dropout provides immediately the magnitude of the regularization term which is adaptively scaled by the inputs and by the variance of the dropout variables. Note that ${p}_{i} = {0.5}$ is the value that provides the highest level of regularization.

正则化项是通常的权重衰减或基于权重平方的高斯先验项，用于防止过拟合。Dropout立即提供了正则化项的大小，该大小由输入和dropout变量的方差自适应缩放。注意${p}_{i} = {0.5}$是提供最高正则化水平的值。

### 5.2 Single Sigmoidal Unit

### 5.2 单个Sigmoidal单元

The previous result generalizes to a sigmoidal unit $O = \sigma \left( S\right)  = 1/\left( {1 + c{e}^{-{\lambda S}}}\right)$ trained to minimize the relative entropy error $E =  - \left( {t\log O + \left( {1 - t}\right) \log \left( {1 - O}\right) }\right)$ . In this case,

前述结果推广到训练以最小化相对熵误差$E =  - \left( {t\log O + \left( {1 - t}\right) \log \left( {1 - O}\right) }\right)$的sigmoidal单元$O = \sigma \left( S\right)  = 1/\left( {1 + c{e}^{-{\lambda S}}}\right)$。在这种情况下，

$$
\frac{\partial {E}_{D}}{\partial {w}_{i}} =  - \lambda \left( {t - O}\right) \frac{\partial S}{\partial {w}_{i}} =  - \lambda \left( {t - O}\right) {\delta }_{i}{I}_{i} \tag{29}
$$

The terms $O$ and ${I}_{i}$ are not independent but using a Taylor expansion with the ${NWGM}$ approximation gives

项$O$和${I}_{i}$并非独立，但使用带有${NWGM}$近似的泰勒展开得到

$$
E\left( \frac{\partial {E}_{D}}{\partial {w}_{i}}\right)  \approx  \frac{\partial {E}_{ENS}}{\partial {w}_{i}} + \lambda {\sigma }^{\prime }\left( {S}_{ENS}\right) {w}_{i}{I}_{i}^{2}\operatorname{Var}\left( {\delta }_{i}\right)  \tag{30}
$$

with ${S}_{ENS} = \mathop{\sum }\limits_{j}{w}_{j}{p}_{j}{I}_{j}$ . Thus, as in the linear case, the expectation of the dropout gradient is approximately the gradient of the ensemble network regularized by weight decay terms with the proper adaptive coefficients. A similar analysis, can be carried also for a set of normalized exponential units and for deeper networks [1].

其中${S}_{ENS} = \mathop{\sum }\limits_{j}{w}_{j}{p}_{j}{I}_{j}$。因此，与线性情况类似，dropout梯度的期望近似为带有适当自适应系数的权重衰减正则化的集成网络梯度。类似的分析也可应用于一组归一化指数单元和更深层网络[1]。

### 5.3 Learning Phases and Sparse Coding

### 5.3 学习阶段与稀疏编码

During dropout learning, we can expect three learning phases: (1) At the beginning of learning, when the weights are typically small and random, the total input to each unit is close to 0 for all the units and the consistency is high: the output of the units remains roughly constant across subnetworks (and equal to 0.5 with $c = 1$ ). (2) As learning progresses, activities tend to move towards 0 or 1 and the consistency decreases, i.e. for a given input the variance of the units across subnetworks increases. (3) As the stochastic gradient learning procedure converges, the consistency of the units converges to a stable value.

在dropout学习过程中，我们可以预期三个学习阶段:(1) 学习初期，当权重通常较小且随机时，每个单元的总输入接近0，且一致性较高:单元输出在子网络间大致保持不变(且在$c = 1$下等于0.5)。(2) 随着学习进展，活动趋向于0或1，一致性降低，即对于给定输入，单元在子网络间的方差增加。(3) 随着随机梯度学习过程收敛，单元的一致性收敛到一个稳定值。

Finally, for simplicity, assume that dropout is applied only in layer $h$ where the units have an output of the form ${O}_{i}^{h} = \sigma \left( {S}_{i}^{h}\right)$ and ${S}_{i}^{h} = \mathop{\sum }\limits_{{l < h}}{w}_{ij}^{hl}{\delta }_{j}^{l}{O}_{j}^{l}$ . For a fixed input, ${O}_{j}^{l}$ is a constant since dropout is not applied to layer $l$ . Thus

最后，为简化起见，假设dropout仅应用于层$h$，该层单元的输出形式为${O}_{i}^{h} = \sigma \left( {S}_{i}^{h}\right)$和${S}_{i}^{h} = \mathop{\sum }\limits_{{l < h}}{w}_{ij}^{hl}{\delta }_{j}^{l}{O}_{j}^{l}$。对于固定输入，${O}_{j}^{l}$是常数，因为dropout未应用于层$l$。因此

$$
\operatorname{Var}\left( {S}_{i}^{h}\right)  = \mathop{\sum }\limits_{{l < h}}{\left( {w}_{ij}^{hl}\right) }^{2}{\left( {O}_{j}^{l}\right) }^{2}{p}_{j}^{l}\left( {1 - {p}_{j}^{l}}\right)  \tag{31}
$$

under the usual assumption that the selector variables ${\delta }_{j}^{l}$ are independent of each other. Thus $\operatorname{Var}\left( {S}_{i}^{h}\right)$ depends on three factors. Everything else being equal, it is reduced by: (1) Small weights which goes together with the regularizing effect of dropout; (2) Small activities, which shows that dropout is not symmetric with respect to small or large activities. Overall, dropout tends to favor small activities and thus sparse coding; and (3) Small (close to 0) or large (close to 1) values of the dropout probabilities ${p}_{j}^{l}$ . Thus values ${p}_{j}^{l} = {0.5}$ maximize the regularization effect but may also lead to slower convergence to the consistent state. Additional results and simulations are given in [1].

在通常假设选择变量${\delta }_{j}^{l}$彼此独立的前提下，$\operatorname{Var}\left( {S}_{i}^{h}\right)$依赖于三个因素。其他条件相同的情况下，它会因以下原因减少:(1) 较小的权重，这与dropout的正则化效应相伴随；(2) 较小的活动，表明dropout对小活动和大活动不对称。总体上，dropout倾向于促进小活动，从而实现稀疏编码；(3) 较小(接近0)或较大(接近1)的dropout概率${p}_{j}^{l}$。因此，值${p}_{j}^{l} = {0.5}$最大化正则化效应，但也可能导致收敛到一致状态的速度变慢。更多结果和模拟见[1]。

## 6 Simulation Results

## 6 模拟结果

We use Monte Carlo simulation to partially investigate the approximation framework embodied by the three fundamental dropout equations 11.12 and 13 , the accuracy of the second-order approximation and bounds in Equations 20 and 22, and the dynamics of dropout learning. We experiment with an MNIST classifier of four hidden layers (784-1200-1200-1200-1200-10) that replicates the results in [7] using the Pylearn2 and Theano software libraries [12, 3]. The network is trained with a dropout probability of 0.8 in the input, and 0.5 in the four hidden layers. For fixed weights and a fixed input, 10,000 Monte Carlo simulations are used to estimate the distribution of activity $O$ in each neuron. Let ${O}^{ * }$ be the activation under the deterministic setting with the weights scaled appropriately.

我们使用蒙特卡洛模拟部分研究由三个基本dropout方程11、12和13体现的近似框架，第二阶近似及方程20和22中的界限的准确性，以及dropout学习的动态。我们使用一个四隐藏层的MNIST分类器(784-1200-1200-1200-1200-10)，复现文献[7]中的结果，采用Pylearn2和Theano软件库[12, 3]。网络在输入层使用0.8的dropout概率，四个隐藏层使用0.5的dropout概率进行训练。对于固定权重和固定输入，使用10,000次蒙特卡洛模拟估计每个神经元中活动$O$的分布。令${O}^{ * }$为权重适当缩放后的确定性设置下的激活值。

The left column of Figure 1 confirms empirically that the second-order approximation in Equation 20 and the bound in Equation 22 are accurate. The right column of Figure 1 shows the difference between the true ensemble average $E\left( O\right)$ and the prediction-time neuron activity ${O}^{ * }$ . This difference grows very slowly in the higher layers, and only for active neurons.

图1左栏通过实验证实了方程20中的二阶近似和方程22中的界限是准确的。图1右栏展示了真实集成平均值$E\left( O\right)$与预测时神经元活动${O}^{ * }$之间的差异。该差异在较高层次中增长非常缓慢，且仅限于活跃神经元。

![bo_d1c3om3ef24c73d2ojt0_6_518_316_733_751_0.jpg](images/bo_d1c3om3ef24c73d2ojt0_6_518_316_733_751_0.jpg)

Figure 1: Left: The difference $E\left( O\right)  - {NWGM}\left( O\right)$ , it’s second-order approximation in Equation 20. and the bound from Equation 22, plotted for four hidden layers and a typical fixed input. Right: The difference between the true ensemble average $E\left( O\right)$ and the final neuron prediction ${O}^{ * }$ .

图1:左图:差异$E\left( O\right)  - {NWGM}\left( O\right)$，其在方程20中的二阶近似，以及方程22中的界限，针对四个隐藏层和一个典型固定输入绘制。右图:真实集成平均值$E\left( O\right)$与最终神经元预测${O}^{ * }$之间的差异。

Next, we examine the neuron consistency during dropout training. Figure 2a shows the three phases of learning for a typical neuron. In Figure 2b, we observe that the consistency does not decline in higher layers of the network.

接下来，我们考察了dropout训练期间神经元的一致性。图2a展示了典型神经元的学习三个阶段。图2b中，我们观察到网络较高层次的一致性并未下降。

One clue into how this happens is the distribution of neuron activity. As noted in [10] and section 5 above, dropout training results in sparse activity in the hidden layers (Figure 3). This increases the consistency of neurons in the next layer. References

这一现象的一个线索是神经元活动的分布。如文献[10]及上述第5节所述，dropout训练导致隐藏层中活动稀疏(图3)。这提高了下一层神经元的一致性。参考文献

![bo_d1c3om3ef24c73d2ojt0_7_327_439_537_366_0.jpg](images/bo_d1c3om3ef24c73d2ojt0_7_327_439_537_366_0.jpg)

(a) The three phases of learning. For a particular input, a typical active neuron (red) starts out with low variance, experiences a large increase in variance during learning, and eventually settles to some steady constant value. In contrast, a typical inactive neuron (blue) quickly learns to stay silent. Shown are the mean with 5% and 95% percentiles.

(a) 学习的三个阶段。对于特定输入，典型活跃神经元(红色)起初方差较低，学习过程中方差大幅增加，最终趋于某一稳定常数值。相比之下，典型非活跃神经元(蓝色)迅速学会保持静默。图中显示均值及5%和95%分位数。

![bo_d1c3om3ef24c73d2ojt0_7_889_440_550_367_0.jpg](images/bo_d1c3om3ef24c73d2ojt0_7_889_440_550_367_0.jpg)

(b) Consistency does not noticeably decline in the upper layers. Shown here are the mean $\operatorname{Std}\left( O\right)$ for active neurons ( ${0.1} < O$ after training) in each layer, along with the $5\%$ and ${95}\%$ percentiles.

(b) 一致性在上层并无明显下降。此处展示了每层活跃神经元(训练后为${0.1} < O$)的均值$\operatorname{Std}\left( O\right)$，以及$5\%$和${95}\%$分位数。

![bo_d1c3om3ef24c73d2ojt0_7_357_1465_1076_398_0.jpg](images/bo_d1c3om3ef24c73d2ojt0_7_357_1465_1076_398_0.jpg)

Figure 3: In every hidden layer of a dropout trained network, the distribution of neuron activations ${O}^{ * }$ is sparse and not symmetric. These histograms were totalled over a set of 100 random inputs.

图3:在dropout训练的网络每个隐藏层中，神经元激活${O}^{ * }$的分布稀疏且不对称。这些直方图是对100个随机输入的统计结果。

[1] P. Baldi and P. Sadowski. The Dropout Learning Algorithm. Artificial Intelligence, 2014. In press.

[1] P. Baldi 和 P. Sadowski. Dropout学习算法。人工智能，2014年。待发表。

[2] E. F. Beckenbach and R. Bellman. Inequalities. Springer-Verlag Berlin, 1965.

[2] E. F. Beckenbach 和 R. Bellman. 不等式。施普林格出版社，柏林，1965年。

[3] J. Bergstra, O. Breuleux, F. Bastien, P. Lamblin, R. Pascanu, G. Desjardins, J. Turian, D. Warde-Farley, and Y. Bengio. Theano: a CPU and GPU math expression compiler. In Proceedings of the Python for Scientific Computing Conference (SciPy), Austin, TX, June 2010. Oral Presentation.

[3] J. Bergstra, O. Breuleux, F. Bastien, P. Lamblin, R. Pascanu, G. Desjardins, J. Turian, D. Warde-Farley 和 Y. Bengio. Theano:CPU和GPU数学表达式编译器。载于Python科学计算会议(SciPy)论文集，德克萨斯州奥斯汀，2010年6月。口头报告。

[4] L. Bottou. Online algorithms and stochastic approximations. In D. Saad, editor, Online Learning and Neural Networks. Cambridge University Press, Cambridge, UK, 1998.

[4] L. Bottou. 在线算法与随机逼近。载于D. Saad主编，《在线学习与神经网络》。剑桥大学出版社，英国剑桥，1998年。

[5] L. Bottou. Stochastic learning. In O. Bousquet and U. von Luxburg, editors, Advanced Lectures on Machine Learning, Lecture Notes in Artificial Intelligence, LNAI 3176, pages 146-168. Springer Verlag, Berlin, 2004.

[5] L. Bottou. 随机学习。载于O. Bousquet和U. von Luxburg主编，《机器学习高级讲义》，人工智能讲义系列LNAI 3176，第146-168页。施普林格出版社，柏林，2004年。

[6] D. Cartwright and M. Field. A refinement of the arithmetic mean-geometric mean inequality. Proceedings of the American Mathematical Society, pages 36-38, 1978.

[6] D. Cartwright 和 M. Field. 算术-几何平均不等式的改进。美国数学学会会议录，第36-38页，1978年。

[7] G. Hinton, N. Srivastava, A. Krizhevsky, I. Sutskever, and R. R. Salakhutdinov. Improving neural networks by preventing co-adaptation of feature detectors. http://arxiv.org/abs/1207.0580, 2012.

[7] G. Hinton, N. Srivastava, A. Krizhevsky, I. Sutskever 和 R. R. Salakhutdinov. 通过防止特征检测器的协同适应来改进神经网络。http://arxiv.org/abs/1207.0580，2012年。

[8] E. Neuman and J. Sándor. On the Ky Fan inequality and related inequalities i. MATHEMATICAL INEQUALITIES AND APPLICATIONS, 5:49-56, 2002.

[8] E. Neuman 和 J. Sándor. 关于Ky Fan不等式及相关不等式i。数学不等式与应用，5:49-56，2002年。

[9] E. Neuman and J. Sandor. On the Ky Fan inequality and related inequalities ii. Bulletin of the Australian Mathematical Society, 72(1):87-108, 2005.

[9] E. Neuman 和 J. Sandor. 关于Ky Fan不等式及相关不等式ii。澳大利亚数学学会公报，72(1):87-108，2005年。

[10] S. Nitish. Improving Neural Networks with Dropout. PhD thesis, University of Toronto, Toronto, Canada, 2013.

[10] S. Nitish. 使用Dropout改进神经网络。博士论文，多伦多大学，多伦多，加拿大，2013年。

[11] H. Robbins and D. Siegmund. A convergence theorem for non negative almost supermartin-gales and some applications. Optimizing methods in statistics, pages 233-257, 1971.

[11] H. Robbins 和 D. Siegmund。非负近似超鞅(supermartingales)收敛定理及其若干应用。统计优化方法，页233-257，1971年。

[12] D. Warde-Farley, I. Goodfellow, P. Lamblin, G. Desjardins, F. Bastien, and Y. Bengio. pylearn2. 2011. http://deeplearning.net/software/pylearn2.

[12] D. Warde-Farley, I. Goodfellow, P. Lamblin, G. Desjardins, F. Bastien 和 Y. Bengio。pylearn2。2011年。http://deeplearning.net/software/pylearn2。