# Diffusion Self-Distillation for Zero-Shot Customized Image Generation

# 用于零样本定制图像生成的扩散自蒸馏方法

Shengqu Cai Eric Ryan Chan Yunzhi Zhang

蔡盛曲 埃里克·瑞安·陈 张云志

Leonidas Guibas Jiajun Wu Gordon Wetzstein

利奥尼达斯·吉巴斯 吴佳俊 戈登·韦茨斯坦

Stanford University

斯坦福大学

![0195d6ef-e939-7abd-9b6d-dae30f972af7_0_165_604_1467_507_0.jpg](images/0195d6ef-e939-7abd-9b6d-dae30f972af7_0_165_604_1467_507_0.jpg)

Figure 1. Given an input image, Diffusion Self-Distillation is a novel diffusion-based approach that generates diverse images that maintain the input's identity across various contexts. Unlike prior approaches that require fine-tuning or are limited to specific domains, Diffusion Self-Distillation offers instant customization without any additional inference-stage training, enabling precise control and editability in text-to-image diffusion models. This ability makes Diffusion Self-Distillation a valuable tool for general AI content creation.

图1. 给定一张输入图像，扩散自蒸馏是一种基于扩散的新颖方法，它能生成多样化的图像，且在各种场景下都能保持输入图像的特征。与之前需要微调或局限于特定领域的方法不同，扩散自蒸馏无需任何额外的推理阶段训练即可实现即时定制，使文本到图像的扩散模型能够进行精确控制和编辑。这种能力使扩散自蒸馏成为通用人工智能内容创作的宝贵工具。

## Abstract

## 摘要

Text-to-image diffusion models produce impressive results but are frustrating tools for artists who desire fine-grained control. For example, a common use case is to create images of a specific concept in novel contexts, i.e., "identity-preserving generation". This setting, along with many other tasks (e.g., relighting), is a natural fit for image + text-conditional generative models. However, there is insufficient high-quality paired data to train such a model directly. We propose Diffusion Self-Distillation, a method for using a pre-trained text-to-image model to generate its own dataset for text-conditioned image-to-image tasks. We first leverage a text-to-image diffusion model's in-context generation ability to create grids of images and curate a large paired dataset with the help of a vision-language model. We then fine-tune the text-to-image model into a text+image-to-image model using the curated paired dataset. We demonstrate that Diffusion Self-Distillation outperforms existing zero-shot methods and is competitive with per-instance tuning techniques on a wide range of identity-preserving generation tasks, without requiring test-time optimization. Project page: primecai.github.io/dsd.

文本到图像的扩散模型取得了令人印象深刻的成果，但对于希望进行细粒度控制的艺术家来说，这些模型使用起来却不尽人意。例如，一个常见的应用场景是在新的场景中创建特定概念的图像，即“保持特征的生成”。这种场景以及许多其他任务(如重新打光)非常适合图像 + 文本条件生成模型。然而，没有足够的高质量配对数据来直接训练这样的模型。我们提出了扩散自蒸馏方法，这是一种利用预训练的文本到图像模型为文本条件的图像到图像任务生成自己的数据集的方法。我们首先利用文本到图像扩散模型的上下文生成能力创建图像网格，并在视觉 - 语言模型的帮助下精心整理出一个大型配对数据集。然后，我们使用整理好的配对数据集将文本到图像模型微调为文本 + 图像到图像模型。我们证明了扩散自蒸馏方法在一系列保持特征的生成任务上优于现有的零样本方法，并且在不需要测试时优化的情况下，与每个实例的微调技术具有竞争力。项目页面:primecai.github.io/dsd。

## 1. Introduction

## 1. 引言

In recent years, text-to-image diffusion models [24, 28, 29, 32] have set new standards in image synthesis, generating high-quality and diverse images from textual prompts. However, while their ability to generate images from text is impressive, these models often fall short in offering precise control, editability, and consistency-key features that are crucial for real-world applications. Text input alone can be insufficient to convey specific details, leading to variations that may not fully align with the user's intent, especially in scenarios that require faithful adaptation of a character or asset's identity across different contexts.

近年来，文本到图像的扩散模型 [24, 28, 29, 32] 在图像合成方面树立了新的标准，能够根据文本提示生成高质量且多样化的图像。然而，尽管这些模型从文本生成图像的能力令人印象深刻，但它们在提供精确控制、可编辑性和一致性方面往往有所不足，而这些关键特性对于实际应用至关重要。仅靠文本输入可能不足以传达特定细节，从而导致生成的图像可能与用户的意图不完全一致，特别是在需要在不同场景中忠实保留角色或资产特征的情况下。

Maintaining the instance's identity is challenging, however. We distinguish structure-preserving edits, in which the target and source image share the general layout, but may differ in style, texture, or other local features, and identity-preserving edits, where assets are recognizably the same across target and source images despite potentially large-scale changes in image structure (Fig. 3). The latter task is a superset of the former and requires the model to have a significantly more profound understanding of the input image and concepts to extract and customize the desired identity. For example, image editing $\left\lbrack  {2,{22},{43}}\right\rbrack$ , such as local content editing, re-lighting, and semantic image synthesis, etc. are all structure-preserving and identity-preserving edits, but novel-view synthesis and character-consistent generation under pose variations, are identity-preserving but not structure-preserving. We aim to address the general case, maintaining identity without constraining structure.

然而，保持实例的特征具有挑战性。我们区分了保留结构的编辑和保持特征的编辑，在保留结构的编辑中，目标图像和源图像具有相同的总体布局，但在风格、纹理或其他局部特征上可能有所不同；而在保持特征的编辑中，尽管图像结构可能发生大规模变化，但目标图像和源图像中的资产仍能被识别为相同(图3)。后一种任务是前一种任务的超集，要求模型对输入图像和概念有更深刻的理解，以提取和定制所需的特征。例如，图像编辑 $\left\lbrack  {2,{22},{43}}\right\rbrack$ ，如局部内容编辑、重新打光和语义图像合成等，都是保留结构和保持特征的编辑，而新视角合成和姿态变化下的角色一致生成则是保持特征但不保留结构的编辑。我们的目标是解决一般情况，即在不限制结构的情况下保持特征。

![0195d6ef-e939-7abd-9b6d-dae30f972af7_1_168_196_1463_607_0.jpg](images/0195d6ef-e939-7abd-9b6d-dae30f972af7_1_168_196_1463_607_0.jpg)

Figure 2. Overview of our pipeline. Left: the top shows our vanilla paired data generation wheel (Sec. 3.1). We first sample reference image captions from the LAION [33] dataset. These reference captions are parsed through an LLM to be translated into identity-preserved grid generation prompts (Sec. 3.1.2). We feed these enhanced prompts to a pretrained text-to-image diffusion model to sample potentially identity-preserved grids of images, which are then cropped and composed into vanilla image pairs (Sec. 3.1.1). On the bottom, we show our data curation pipeline (Sec. 3.1.3), where the vanilla image paired are fed into a VLM to classify whether they depict identical main subjects. This process mimics a human annotation/curation process while being fully automatic; we use the curated data as our final training data. Right: we extend the diffusion transformer model into an image-conditioned framework by treating the input image as the first frame of a two-frame sequence. The model generates both frames simultaneously—the first reconstructs the input, while the second is the edited output—allowing effective information exchange between the conditioning image and the desired output.

图2. 我们的流程概述。左:上方展示了我们的原始配对数据生成流程(第3.1节)。我们首先从LAION [33] 数据集中采样参考图像描述。这些参考描述通过大语言模型(LLM)解析，转换为保持特征的网格生成提示(第3.1.2节)。我们将这些增强后的提示输入到预训练的文本到图像扩散模型中，采样可能保持特征的图像网格，然后将其裁剪并组合成原始图像对(第3.1.1节)。下方展示了我们的数据整理流程(第3.1.3节)，将原始图像对输入到视觉 - 语言模型(VLM)中，以分类它们是否描绘了相同的主要对象。这个过程模拟了人工标注/整理过程，同时完全自动化；我们将整理后的数据用作最终的训练数据。右:我们将扩散变压器模型扩展为图像条件框架，将输入图像视为两帧序列的第一帧。模型同时生成两帧——第一帧重建输入图像，而第二帧是编辑后的输出——允许条件图像和所需输出之间进行有效的信息交换。

For structure-preserving edits, adding layers, as in Con-trolNet [43], introduces spatial conditioning controls but is limited to structure guidance and does not address consistent identity adaptation across diverse contexts. For identity-preserving edits, fine-tuning methods such as Dream-Booth [31] and LoRA [13] can improve consistency using a few reference samples but are time consuming and computationally intensive, requiring training for each reference. Zero-shot alternatives like IP-Adapter [42] and Instan-tID [37] offer faster solutions without the need for retraining but fall short in providing the desired level of consistency and customization; IP-Adapter [42] lacks full customization capabilities, and InstantID [37] is restricted to facial identity.

对于保留结构的编辑，像ControlNet [43]那样添加层，引入了空间条件控制，但仅限于结构引导，无法解决在不同上下文环境下一致的身份适配问题。对于保留身份的编辑，诸如DreamBooth [31]和LoRA [13]等微调方法可以利用少量参考样本提高一致性，但耗时且计算量大，每个参考样本都需要进行训练。像IP - Adapter [42]和InstantID [37]这类零样本替代方法无需重新训练，提供了更快的解决方案，但在提供所需的一致性和定制化水平方面有所不足；IP - Adapter [42]缺乏完全定制的能力，而InstantID [37]仅限于面部身份。

In this paper, we propose a novel approach called Diffusion Self-Distillation, designed to address the core challenge of zero-shot instant customization and adaptation of any character or asset in text-to-image diffusion models. We identify the primary obstacle that hinders prior methods, such as IP-Adapter [42] and InstantID [37], from achieving better identity preservation or generalizing beyond facial contexts: the absence of large-scale paired datasets and corresponding supervised identity-preserving training pipelines. With recent advancements in foundational model capabilities, we are now positioned to exploit these strengths further. Specifically, we can generate consistent grids of identical characters or assets, opening a new pathway for customization that eliminates the need for pre-existing, handcrafted paired datasets-which are expensive and time consuming to collect. The ability to generate these consistent grids likely emerged from foundational model training on diverse datasets, including photo albums, mangas, and comics. Our approach harnesses Vision-Language Models (VLMs) to automatically curate many generated grids, producing a diverse set of grid images with consistent identity features across various contexts. This curated synthetic dataset then serves as the foundation for fine-tuning and adapting any identity, transforming the task of zero-shot customized image generation from unsupervised to supervised. Diffusion Self-Distillation offers transformative potential for applications like consistent character generation, camera control, relighting, and asset customization in fields such as comics and digital art. This flexibility allows artists to rapidly iterate and adapt their work, reducing effort and enhancing creative freedom, making Diffusion Self-Distillation a valuable tool for AI-generated content.

在本文中，我们提出了一种名为扩散自蒸馏(Diffusion Self - Distillation)的新方法，旨在解决文本到图像扩散模型中对任何角色或资产进行零样本即时定制和适配这一核心挑战。我们发现了阻碍诸如IP - Adapter [42]和InstantID [37]等先前方法实现更好的身份保留或在面部上下文之外进行泛化的主要障碍:缺乏大规模的配对数据集以及相应的有监督身份保留训练流程。随着基础模型能力的最新进展，我们现在能够进一步利用这些优势。具体而言，我们可以生成相同角色或资产的一致网格，为定制开辟了一条新途径，消除了对预先存在的、手工制作的配对数据集的需求，而收集这些数据集既昂贵又耗时。生成这些一致网格的能力可能源于基础模型在包括相册、漫画和连环画等多样化数据集上的训练。我们的方法利用视觉 - 语言模型(VLMs)自动整理许多生成的网格，生成一组在各种上下文环境中具有一致身份特征的多样化网格图像。这个经过整理的合成数据集随后成为微调并适配任何身份的基础，将零样本定制图像生成任务从无监督转变为有监督。扩散自蒸馏在漫画和数字艺术等领域的一致角色生成、相机控制、重新打光和资产定制等应用方面具有变革性潜力。这种灵活性使艺术家能够快速迭代和调整他们的作品，减少工作量并增强创作自由，使扩散自蒸馏成为人工智能生成内容的宝贵工具。

We summarize our contributions as follows:

我们将贡献总结如下:

- We propose Diffusion Self-Distillation, a zero-shot

- 我们提出了扩散自蒸馏(Diffusion Self - Distillation)，一种零样本

![0195d6ef-e939-7abd-9b6d-dae30f972af7_2_165_202_703_192_0.jpg](images/0195d6ef-e939-7abd-9b6d-dae30f972af7_2_165_202_703_192_0.jpg)

Figure 3. Difference between structure-preserving and identity-preserving edits. In structure-preserving editing, the main structures of the image are preserved, and only local edits or stylizations are performed. In identity-preserving editing, the global structure of the image may change radically.

图3. 保留结构编辑和保留身份编辑的区别。在保留结构编辑中，图像的主要结构得以保留，仅进行局部编辑或风格化处理。在保留身份编辑中，图像的全局结构可能会发生根本性变化。

identity-preserving customized image generation model that scales to any instance under any context, with performances on par with inference-stage tuning methods;

保留身份的定制图像生成模型，该模型可在任何上下文环境下扩展到任何实例，其性能与推理阶段的调优方法相当；

- We provide a self-distillation pipeline to obtain identity-preserving data pairs purely from pretrained text-to-image diffusion models, LLMs, and VLMs, without any human effort involved in the entire data creation wheel;

- 我们提供了一个自蒸馏流程，仅从预训练的文本到图像扩散模型、大语言模型(LLMs)和视觉 - 语言模型(VLMs)中获取保留身份的数据对，整个数据创建过程无需人工干预；

- We correspondingly design a unified architecture for image-to-image translation tasks involving both identity-and structure-preserving edits, including personalization, relighting, depth controls, and instruction following.

- 我们相应地设计了一个统一架构，用于涉及保留身份和保留结构编辑的图像到图像翻译任务，包括个性化、重新打光、深度控制和指令遵循。

## 2. Related work

## 2. 相关工作

Recent advancements in diffusion models have underscored the need for enhanced control and customization in image-generation tasks. Various methods have been proposed to address these challenges through additional conditioning mechanisms, personalization, and rapid adaptation [26].

扩散模型的最新进展凸显了在图像生成任务中增强控制和定制的必要性。已经提出了各种方法，通过额外的条件机制、个性化和快速适配来应对这些挑战 [26]。

Control Mechanisms in Diffusion Models. To move beyond purely text-based controls, approaches like Control-Net [43] introduce spatial conditioning via inputs such as sketches, depth maps, and segmentation masks, enabling fine-grained structure control. ControlNet++ [19] refines this by enhancing the integration of spatial inputs for more nuanced control. Uni-ControlNet [44] unifies various control types within a single framework, standardizing the handling of diverse signals. T2I-Adapter [23] employs lightweight adapters to align pretrained models with external control signals without altering the core architecture. While these methods offer increased flexibility, they often focus on structural conditioning types such as depths and lack capabilities for concept extraction or identity preservation.

扩散模型中的控制机制。为了超越纯粹基于文本的控制，像ControlNet [43]这样的方法通过草图、深度图和分割掩码等输入引入空间条件控制，实现细粒度的结构控制。ControlNet++ [19]通过增强空间输入的集成来改进这一点，以实现更细致的控制。Uni - ControlNet [44]在单一框架内统一了各种控制类型，规范了对不同信号的处理。T2I - Adapter [23]采用轻量级适配器，使预训练模型与外部控制信号对齐，而不改变核心架构。虽然这些方法提供了更大的灵活性，但它们通常侧重于深度等结构条件类型，缺乏概念提取或身份保留的能力。

Personalization and Fine-Tuning. Techniques like Dream-Booth [31] and LoRA [13] enhance the consistency and relevance of generated images by fine-tuning models with small sets of reference images. DreamBooth [31] personalizes models to maintain a subject's identity across different contexts, while LoRA [13] provides an efficient approach to fine-tuning large models without extensive retraining. However, these methods require multiple images and test-time optimization for each reference, which can be computationally expensive-especially with the exponential growth in model sizes (12 billion parameters for FLUX).

个性化和微调。像DreamBooth [31]和LoRA [13]这样的技术通过使用少量参考图像对模型进行微调，提高了生成图像的一致性和相关性。DreamBooth [31]对模型进行个性化处理，以在不同上下文环境中保持主体的身份，而LoRA [13]提供了一种在无需大量重新训练的情况下微调大型模型的高效方法。然而，这些方法每个参考样本都需要多张图像和测试时优化，这在计算上可能成本很高，尤其是随着模型规模呈指数级增长(如FLUX有120亿个参数)。

Zero-Shot and Fast Adaptation. IP-Adapter [42] incorporates image prompts into diffusion models using image em-beddings, allowing for generations that align closely with reference visuals. InstantID [37] ensures zero-shot face preservation, maintaining a subject's key features across various contexts. While effective as zero-shot methods without user training, IP-Adapter [42] struggles to adapt specific targets like unique characters or assets, and InstantID [37] is limited to facial identity preservation. IPAdapter-Instruct [30] enhances image-based conditioning with instruct prompts but relies heavily on specific instructions and task-specific pretrained models. Other methods, such as SuTI [7] and GDT [15], handcrafted corresponding datasets, which are expensive and challenging to collect and scale. Another work along this line is Subject-Diffusion [21], which uses segmentation masks to create synthetic data for training but is bounded by achieving only simple attributes and accessories copying and editing within input images.

零样本和快速适应。IP适配器(IP-Adapter)[42]利用图像嵌入将图像提示融入扩散模型，从而实现与参考视觉效果紧密匹配的图像生成。即时身份识别(InstantID)[37]确保零样本面部特征保留，能在各种场景下保持主体的关键特征。虽然作为无需用户训练的零样本方法很有效，但IP适配器(IP-Adapter)[42]难以适应特定目标，如独特的角色或资产，而即时身份识别(InstantID)[37]仅限于面部身份保留。IP适配器指令(IPAdapter-Instruct)[30]通过指令提示增强了基于图像的条件控制，但严重依赖特定指令和特定任务的预训练模型。其他方法，如SuTI [7]和GDT [15]，需要手工制作相应的数据集，这既昂贵又难以收集和扩展。沿着这一思路的另一项工作是主体扩散(Subject-Diffusion)[21]，它使用分割掩码创建合成数据进行训练，但仅限于复制和编辑输入图像中的简单属性和配饰。

Existing methods contribute valuable advancements but often target specific domains or require user-stage tuning. Diffusion Self-Distillation bridges these gaps by offering a unified, zero-shot approach for consistent customization of characters and assets using minimal input. By leveraging self-distillation assisted by vision-language models, Diffusion Self-Distillation provides a comprehensive and adaptable solution for a wide range of creative applications.

现有方法取得了有价值的进展，但通常针对特定领域或需要用户阶段的调整。扩散自蒸馏(Diffusion Self-Distillation)通过提供一种统一的零样本方法，利用最少的输入实现对角色和资产的一致定制，弥补了这些差距。通过利用视觉语言模型辅助的自蒸馏，扩散自蒸馏(Diffusion Self-Distillation)为广泛的创意应用提供了全面且适应性强的解决方案。

## 3. Diffusion Self-Distillation

## 3. 扩散自蒸馏

We discover that recent text-to-image generation models offer the surprising ability to generate in-context, consistent image grids (see Fig. 2, left). Motivated by this insight, we develop a zero-shot adaptation network that offers fast, diverse, high-quality, and identity-preserving, i.e., consistent image generation conditioned on a reference image. For this purpose, we first generate and curate sets of images that exhibit the desired consistency using pretrained text-to-image diffusion models, large language models (LLMs), and vision-language models (VLMs) (Sec. 3.1). Then, we finetune the same pretrained diffusion model with these consistent image sets, employing our newly proposed parallel processing architecture (Sec. 3.2) to create a conditional model. By this end, Diffusion Self-Distillation finetunes a pretrained text-to-image diffusion model into a zero-shot customized image generator in a supervised manner.

我们发现，最近的文本到图像生成模型具备令人惊讶的上下文内生成一致图像网格的能力(见图2，左)。受这一发现的启发，我们开发了一个零样本适应网络，该网络能够基于参考图像进行快速、多样、高质量且保留身份特征(即一致)的图像生成。为此，我们首先使用预训练的文本到图像扩散模型、大语言模型(LLM)和视觉语言模型(VLM)生成并筛选出具有所需一致性的图像集(3.1节)。然后，我们使用这些一致的图像集对相同的预训练扩散模型进行微调，采用我们新提出的并行处理架构(3.2节)创建一个条件模型。最终，扩散自蒸馏(Diffusion Self-Distillation)以有监督的方式将预训练的文本到图像扩散模型微调为零样本定制图像生成器。

### 3.1. Generating a Pairwise Dataset

### 3.1. 生成成对数据集

To create a pairwise dataset for supervised Diffusion Self-Distillation training, we leverage the emerging multi-image generation capabilities of pretrained text-to-image diffusion models to produce potentially consistent vanilla images (Sec. 3.1.1) created by LLM-generated prompts (Sec. 3.1.2). We then use VLMs to curate these vanilla samples, obtaining clean sets of images that share the desired identity consistency (Sec. 3.1.3). The data generation and curation pipeline is shown in Fig. 2, left.

为了创建用于有监督扩散自蒸馏训练的成对数据集，我们利用预训练文本到图像扩散模型新兴的多图像生成能力，生成由大语言模型生成的提示所创建的潜在一致的原始图像(3.1.1节)。然后，我们使用视觉语言模型对这些原始样本进行筛选，获得具有所需身份一致性的干净图像集(3.1.3节)。数据生成和筛选流程如图2左所示。

#### 3.1.1. Vanilla Data Generation via Teacher Model

#### 3.1.1. 通过教师模型生成原始数据

To generate sets of images that fulfill the desired identity preservation, we prompt the teacher pretrained text-to-image diffusion model to create images containing multiple panels featuring the same subject with variations in expression, pose, lighting conditions, and more, for training purposes. Such prompting can be as simple as specifying the desired identity preservation in the output, such as " a grid of 4 images representing the same $<$ object/character/scene/etc. >", "an evenly separated 4 panels, depicting identical < object/character/scene/etc. >", etc. We additionally specify the expected content in each sub-image/panel. The full set of prompts is provided in our supplemental material Sec. A. Our analysis shows that current state-of-the-art text-to-image diffusion models (e.g., SD3 [8], DALL-E 3, FLUX) demonstrate this identity-preserving capability, likely emerging from their training data, which includes comics, mangas, photo albums, and video frames. Such in-context generation ability is crucial to our data generation wheel.

为了生成满足所需身份保留的图像集，我们向教师预训练文本到图像扩散模型发出提示，要求其创建包含多个面板的图像，这些面板以同一主体为特征，但在表情、姿势、光照条件等方面有所变化，用于训练。这样的提示可以很简单，只需在输出中指定所需的身份保留，例如“一个包含4张代表同一$<$对象/角色/场景等的图像网格”，“一个均匀分隔的4个面板，描绘相同的<对象/角色/场景等>”等。我们还会指定每个子图像/面板中的预期内容。完整的提示集在我们的补充材料A节中提供。我们的分析表明，当前最先进的文本到图像扩散模型(如SD3 [8]、DALL - E 3、FLUX)展示了这种身份保留能力，这可能源于它们的训练数据，其中包括漫画、动漫、相册和视频帧。这种上下文内生成能力对我们的数据生成流程至关重要。

#### 3.1.2. Prompt Generation via LLMs

#### 3.1.2. 通过大语言模型生成提示

We rely on an LLM to "brainstorm" a large dataset of diverse prompts, from which we derive our image grid dataset. By defining a prompt structure, we prompt the LLM to produce text prompts that describe image grids. A challenge we encountered is that when prompted to create large sets of prompts, LLMs tend to produce prompts of low diversity. For example, we noticed that without additional guidance, GPT-4o has a strong preference for prompts with cars and robots, resulting in highly repetitive outputs. To address this issue, we utilize the available image captions in the LAION [33] dataset, feeding them into the LLM as content references. These references from real image captions dramatically improve the diversity of generated prompts. Optionally, we also use the LLM to filter these reference captions, ensuring they contain a clear target for identity preservation. We find that this significantly improves the hit rate of generating consistent multi-image outputs.

我们依靠大语言模型“集思广益”生成大量多样的提示数据集，从中衍生出我们的图像网格数据集。通过定义提示结构，我们促使大语言模型生成描述图像网格的文本提示。我们遇到的一个挑战是，当要求大语言模型创建大量提示集时，它们往往生成多样性较低的提示。例如，我们注意到，如果没有额外的指导，GPT - 4o强烈偏好包含汽车和机器人的提示，导致输出高度重复。为了解决这个问题，我们利用LAION [33]数据集中现有的图像描述，将它们作为内容参考输入到大语言模型中。这些来自真实图像描述的参考显著提高了生成提示的多样性。可选地，我们还使用大语言模型对这些参考描述进行过滤，确保它们包含明确的身份保留目标。我们发现，这显著提高了生成一致多图像输出的成功率。

#### 3.1.3. Dataset Curation and Caption with VLMs

#### 3.1.3. 数据集整理与视觉语言模型标注

While the aforementioned data generation scheme provides identity-preserving multi-image samples of decent quality and quantity, these initial "uncurated" images tend to be noisy and unsuitable for direct use. Therefore, we leverage the strong capabilities of VLMs to curate a clean dataset. We extract pairs of images from the generated samples intended to preserve the identity and ask the VLM whether the two images depict the same object, character, scene, etc. We find that employing Chain-of-Thought prompting [38] is particularly helpful in this context. Specifically, we first prompt the VLM to identify the common object, character, or scene present in both images, then have it describe each one in detail, and finally analyze whether they are identical, providing a conclusive response. This process yields pairs of images that share the same identity.

虽然上述数据生成方案提供了质量和数量都不错的保留身份信息的多图像样本，但这些初始的“未整理”图像往往存在噪声，不适合直接使用。因此，我们利用视觉语言模型(VLM)的强大能力来整理出一个干净的数据集。我们从生成的样本中提取旨在保留身份信息的图像对，并询问视觉语言模型这两张图像是否描绘了相同的物体、人物、场景等。我们发现，在这种情况下采用思维链提示法 [38] 特别有用。具体来说，我们首先提示视觉语言模型识别两张图像中共同存在的物体、人物或场景，然后让它详细描述每一张图像，最后分析它们是否相同，并给出明确的回答。这个过程会得到具有相同身份信息的图像对。

### 3.2. Parallel Processing Architecture

### 3.2. 并行处理架构

We desire a conditional architecture suitable for general image-to-image tasks, including transformations in which structure is preserved, and transformations in which concepts/identities are preserved but image structure is not. This is a challenging problem because it may necessitate the transfer of fine details without guaranteeing spatial correspondences. While the ControlNet [43] architecture is excellent at structure-preserving edits, such as depth-to-image or segmentation-map-to-image, it struggles to preserve details under more complex identity-preserving edits, where the source and target images are not pixel-aligned. On the other hand, IP-Adapter [42] can extract certain concepts, such as styles, from the input image. Still, it strongly relies on a task-specific image encoder and often fails to preserve more complex concepts and identities. Drawing inspiration from the success of multi-view and video diffusion models $\lbrack 1,3 -$ $5,{10} - {12},{14},{16},{18},{34},{35},{39},{41}\rbrack$ , we propose a simple yet effective method to extend the vanilla diffusion transformer model into an image-conditioned diffusion model. Specifically, we treat the input image as the first frame of a video and produce a two-frame video as output. The final loss is computed over the two-frame video, establishing an identity mapping for the first frame and a conditionally editing target for the second frame. Our architecture design allows generality for generic image-to-image translation tasks, since it enables effective information exchange between the two frames, allowing the model to capture complex semantics and perform sophisticated edits, as shown in Fig. 2, right.

我们需要一种适用于通用图像到图像任务的条件架构，包括保留结构的转换，以及保留概念/身份但不保留图像结构的转换。这是一个具有挑战性的问题，因为它可能需要在不保证空间对应关系的情况下传递精细细节。虽然ControlNet [43] 架构在保留结构的编辑方面表现出色，例如深度图到图像或分割图到图像的转换，但在更复杂的保留身份信息的编辑中，当源图像和目标图像的像素不对齐时，它很难保留细节。另一方面，IP - 适配器 [42] 可以从输入图像中提取某些概念，如风格，但它严重依赖于特定任务的图像编码器，并且往往无法保留更复杂的概念和身份信息。受多视图和视频扩散模型 $\lbrack 1,3 -$ $5,{10} - {12},{14},{16},{18},{34},{35},{39},{41}\rbrack$ 成功的启发，我们提出了一种简单而有效的方法，将普通的扩散变压器模型扩展为图像条件扩散模型。具体来说，我们将输入图像视为视频的第一帧，并生成一个两帧的视频作为输出。最终的损失是在两帧视频上计算的，为第一帧建立身份映射，为第二帧建立条件编辑目标。我们的架构设计使通用图像到图像的翻译任务具有通用性，因为它能够实现两帧之间的有效信息交换，使模型能够捕捉复杂的语义并进行精细的编辑，如图2右侧所示。

## 4. Experiments

## 4. 实验

Implementation details. We use FLUX1.0 DEV as both our teacher and student models, achieving self-distillation. For prompt generation, we use GPT-4o; for dataset curation and captioning, we use Gemini-1.5. We train all models on 8 NVIDIA H100 80GB GPUs with an effective batch size of 160 for ${100}\mathrm{k}$ iterations, using AdamW optimizer [20] with a learning rate ${10}^{-4}$ . Our parallel processing architecture uses LoRAs with rank 512 on the base model.

实现细节。我们使用FLUX1.0 DEV作为教师模型和学生模型，实现自蒸馏。对于提示生成，我们使用GPT - 4o；对于数据集整理和标注，我们使用Gemini - 1.5。我们在8块NVIDIA H100 80GB GPU上训练所有模型，有效批量大小为160，进行 ${100}\mathrm{k}$ 次迭代，使用AdamW优化器 [20]，学习率为 ${10}^{-4}$。我们的并行处理架构在基础模型上使用秩为512的低秩自适应(LoRA)。

Datasets. Our final training dataset contains $\sim  {400}\mathrm{k}$ subject-consistent image pairs generated from our teacher model, FLUX1.0 DEV. Generating and curating the dataset is

数据集。我们最终的训练数据集包含从我们的教师模型FLUX1.0 DEV生成的 $\sim  {400}\mathrm{k}$ 个主体一致的图像对。数据集的生成和整理

![0195d6ef-e939-7abd-9b6d-dae30f972af7_4_165_194_1469_957_0.jpg](images/0195d6ef-e939-7abd-9b6d-dae30f972af7_4_165_194_1469_957_0.jpg)

Figure 4. Qualitative comparison. Overall, our method achieves high subject identity preservation and prompt-aligned diversity while not suffering from a "copy-paste" effect, such as the results of IP-Adapter+ [42]. This is largely thanks to our supervised training pipeline, which alleviates the base model's in-context generation ability.

图4. 定性比较。总体而言，我们的方法在实现高主体身份保留和与提示对齐的多样性的同时，不会出现“复制粘贴”效应，例如IP - 适配器+ [42] 的结果。这在很大程度上归功于我们的有监督训练流程，它缓解了基础模型的上下文生成能力问题。

fully automated and requires no human effort, so its size could be further scaled. We use the publicly available DreamBench++ [25] dataset and follow their protocols for evaluation. DreamBench++ [25] is a comprehensive and diverse dataset for evaluating personalized image generation, consisting of 150 high-quality images and 1,350 prompts-significantly more than previous benchmarks like DreamBench [31]. The dataset covers various categories such as animals, humans, objects, etc., including photoreal-istic and non-photorealistic images, with prompts designed to span different difficulty levels (simple/imaginative). In contrast, prompts are generated using GPT-4o and refined by human annotators to ensure diversity and ethical compliance.

是完全自动化的，不需要人工干预，因此其规模可以进一步扩大。我们使用公开可用的DreamBench++ [25] 数据集，并遵循其评估协议。DreamBench++ [25] 是一个用于评估个性化图像生成的全面且多样化的数据集，由150张高质量图像和1350个提示组成，比之前的基准数据集如DreamBench [31] 要多得多。该数据集涵盖了各种类别，如动物、人类、物体等，包括逼真和非逼真的图像，提示设计涵盖了不同的难度级别(简单/富有想象力)。相比之下，提示是使用GPT - 4o生成并由人工标注员进行优化的，以确保多样性和符合道德规范。

Baselines. We follow the setups in DreamBench++ [25] and compare our model with two classes of baselines: inference-stage tuning models and zero-shot models. For inference-stage models, we compare against Textual Inversion [9], DreamBooth [31] and its LoRA [13] version. For zero-shot models, we compare with BLIP-Diffusion [17], Emu2 [36], IP-Adapter [42], IP-Adapter+ [42].

基线模型。我们遵循DreamBench++ [25] 中的设置，将我们的模型与两类基线模型进行比较:推理阶段调优模型和零样本模型。对于推理阶段模型，我们与文本反转 [9]、DreamBooth [31] 及其低秩自适应(LoRA)版本 [13] 进行比较。对于零样本模型，我们与BLIP - 扩散 [17]、Emu2 [36]、IP - 适配器 [42]、IP - 适配器+ [42] 进行比较。

Evaluation metrics. The evaluation protocol of prior works $\left\lbrack  {7,{30},{31},{42}}\right\rbrack$ typically involves comparing the CLIP [27] and DINO [6] feature similarities. However, we note that the metrics mentioned above capture only global semantic similarity, are extremely noisy, and are biased towards "copy-pasting" the input image. This is especially troublesome when the input image or the prompt is complex. We refer to DreamBench++ [25] for a detailed analysis of their limitations. Therefore, we follow the metrics designed in DreamBench++ [25] and report GPT-4o scores on the more diverse DreamBench++ [25] benchmark for both concept preservation (CP) with different categories of subjects and prompt following (PF) with photorealistic (Real.) and Imaginative (Imag.) prompts, then use their product as a final evaluation score. This evaluation protocol emulates a human user study using VLMs. We additionally slightly modify the GPT evaluation prompts so that penalization can be applied if the generated contents show no internal understanding and creative output but instead naively copy over components from the reference image. The modified metrics are named "de-biased concept preservation (Debiased CP)" and "de-biased prompt following (Debiased PF)". The full set of GPT evaluation prompts will be provided in our supplementary Sec. B.

评估指标。先前工作$\left\lbrack  {7,{30},{31},{42}}\right\rbrack$的评估协议通常涉及比较CLIP [27]和DINO [6]的特征相似度。然而，我们注意到上述指标仅能捕捉全局语义相似度，存在极大的噪声，并且倾向于“复制粘贴”输入图像。当输入图像或提示词较为复杂时，这一问题尤为棘手。我们参考了DreamBench++ [25]对其局限性的详细分析。因此，我们采用DreamBench++ [25]中设计的指标，并在更多样化的DreamBench++ [25]基准测试中报告GPT - 4o分数，包括针对不同类别主体的概念保留(CP)以及具有逼真(真实)和富有想象力(想象)提示词的提示遵循(PF)，然后将两者的乘积作为最终评估分数。该评估协议模拟了使用视觉语言模型(VLM)进行的人类用户研究。此外，我们对GPT评估提示词进行了轻微修改，以便在生成内容没有展现出内在理解和创造性输出，而是简单地从参考图像中复制元素时进行惩罚。修改后的指标被命名为“去偏概念保留(去偏CP)”和“去偏提示遵循(去偏PF)”。完整的GPT评估提示词将在我们的补充材料B节中提供。

![0195d6ef-e939-7abd-9b6d-dae30f972af7_5_155_203_1487_1467_0.jpg](images/0195d6ef-e939-7abd-9b6d-dae30f972af7_5_155_203_1487_1467_0.jpg)

Figure 5. Qualitative result. Our Diffusion Self-Distillation is capable of various customization targets across different tasks and styles, for instance, characters or objects, photorealistic or animated. Diffusion Self-Distillation can also take instruction types of prompts as input, similar to InstructPix2Pix [2]. Further, our model exhibits relighting capabilities without significantly altering the scene's content.

图5. 定性结果。我们的扩散自蒸馏方法能够针对不同任务和风格实现各种定制目标，例如人物或物体、逼真风格或动画风格。扩散自蒸馏方法还可以将指令类型的提示词作为输入，类似于InstructPix2Pix [2]。此外，我们的模型在不显著改变场景内容的情况下具备重新打光的能力。

Qualitative results. Fig. 4 presents our qualitative comparison results, demonstrating that our model significantly outperforms all baselines in subject adaptation and concept consistency while exhibiting excellent prompt alignment and diversity in the outputs. Textual Inversion [9], as an early concept extraction method, captures only vague semantics from the input image, making it unsuitable for zero-shot customization tasks that require precise subject adaptation. DreamBooth [31] and DreamBooth-LoRA [13, 31] face challenges in maintaining consistency, primarily because they perform better with multiple input images. This dependency limits their effectiveness when only a single reference image is available. In contrast, our method achieves robust results even with just one input image, highlighting its efficiency and practicality. BLIP-Diffusion [17], operating as a self-supervised representation learning framework, can extract concepts from the input in a zero-shot manner but is confined to capturing overall semantic concepts without the ability to customize specific subjects. Similarly, Emu2 [36], a multimodal foundation model, excels at extracting semantic concepts but lacks mechanisms for specific subject customization, limiting its utility in personalized image generation. IP-Adapter [42] and IP-Adapter+ [42] employ self-supervised learning schemes aimed at reconstructing the input from encoded signals. While effective in extracting global concepts, they suffer from a pronounced "copy-paste" effect, where the generated images closely resemble the input without meaningful transformation. Notably, IP-Adapter+ [42], which utilizes a stronger input image encoder, exacerbates this issue, leading to less diversity and adaptability in the outputs. In contrast, our approach effectively preserves the subject's core identity while enabling diverse and contextually appropriate transformations. As illustrated in Fig. 5, our Diffusion Self-Distillation demonstrates remarkable versatility, adeptly handling various customization targets across different targets (characters, objects, etc.) and styles (photorealistic, animated, etc.). Moreover, Diffusion Self-Distillation generalizes well to a wide range of prompts, including instructions similar to InstructPix2Pix [2], underscoring its robustness and adaptability in diverse customization tasks.

定性结果。图4展示了我们的定性比较结果，表明我们的模型在主体适配和概念一致性方面显著优于所有基线模型，同时在输出结果中展现出出色的提示对齐和多样性。文本反转[9]作为一种早期的概念提取方法，只能从输入图像中捕捉模糊的语义，因此不适用于需要精确主体适配的零样本定制任务。DreamBooth [31]和DreamBooth - LoRA [13, 31]在保持一致性方面面临挑战，主要是因为它们在使用多个输入图像时表现更好。这种对多图像的依赖限制了它们在仅有单张参考图像时的有效性。相比之下，我们的方法即使仅使用一张输入图像也能取得稳健的结果，凸显了其高效性和实用性。BLIP - 扩散[17]作为一种自监督表示学习框架，能够以零样本方式从输入中提取概念，但仅限于捕捉整体语义概念，无法对特定主体进行定制。同样，多模态基础模型Emu2 [36]擅长提取语义概念，但缺乏对特定主体进行定制的机制，限制了其在个性化图像生成中的实用性。IP - 适配器[42]和IP - 适配器+ [42]采用自监督学习方案，旨在从编码信号中重建输入。虽然它们在提取全局概念方面有效，但存在明显的“复制粘贴”效应，即生成的图像与输入图像极为相似，没有有意义的变换。值得注意的是，使用更强输入图像编码器的IP - 适配器+ [42]加剧了这一问题，导致输出结果的多样性和适应性降低。相比之下，我们的方法能够有效保留主体的核心特征，同时实现多样化且符合上下文的变换。如图5所示，我们的扩散自蒸馏方法展现出卓越的通用性，能够熟练处理不同目标(人物、物体等)和风格(逼真风格、动画风格等)的各种定制目标。此外，扩散自蒸馏方法能够很好地泛化到各种提示词，包括类似于InstructPix2Pix [2]的指令，凸显了其在多样化定制任务中的稳健性和适应性。

<table><tr><td rowspan="2">Method</td><td rowspan="2"/><td colspan="4">Concept Preservation</td><td colspan="3">Prompt Following</td><td rowspan="2">CP-PF↑</td><td colspan="4">Debiased Concept Preservation</td><td colspan="4">Debiased PromptFollowingDebiased</td></tr><tr><td>Animal</td><td>Human↑</td><td>Object↑</td><td>Overall↑</td><td>Real.↑</td><td>Imag.↑</td><td>Overall↑</td><td>Animal↑</td><td>Human↑</td><td>Object↑</td><td>Overall↑</td><td>Real.↑</td><td>Imag.↑</td><td>Overall↑</td><td>CP-PF↑</td></tr><tr><td>Textual Inversion</td><td>✘</td><td>0.502</td><td>0.358</td><td>0.305</td><td>0.388</td><td>0.671</td><td>0.437</td><td>0.598</td><td>0.232</td><td>0.741</td><td>0.694</td><td>0.717</td><td>0.722</td><td>0.619</td><td>0.385</td><td>0.541</td><td>0.391</td></tr><tr><td>DreamBooth</td><td>✘</td><td>0.640</td><td>0.199</td><td>0.488</td><td>0.442</td><td>0.798</td><td>0.504</td><td>0.692</td><td>0.306</td><td>0.670</td><td>0.362</td><td>0.676</td><td>0.626</td><td>0.750</td><td>0.467</td><td>0.656</td><td>0.411</td></tr><tr><td>DreamBooth LoRA</td><td>✘</td><td>0.751</td><td>0.311</td><td>0.543</td><td>0.535</td><td>0.898</td><td>0.754</td><td>0.849</td><td>0.450</td><td>0.681</td><td>0.675</td><td>0.761</td><td>0.720</td><td>0.865</td><td>0.718</td><td>0.816</td><td>0.588</td></tr><tr><td>BLIP-Diffusion</td><td>✓</td><td>0.637</td><td>0.557</td><td>0.469</td><td>0.554</td><td>0.581</td><td>0.303</td><td>0.464</td><td>0.257</td><td>0.771</td><td>0.733</td><td>0.745</td><td>0.750</td><td>0.529</td><td>0.266</td><td>0.442</td><td>0.332</td></tr><tr><td>Emu2</td><td>✓</td><td>0.670</td><td>0.546</td><td>0.447</td><td>0.554</td><td>0.732</td><td>0.560</td><td>0.670</td><td>0.371</td><td>0.652</td><td>0.683</td><td>0.701</td><td>0.681</td><td>0.686</td><td>0.494</td><td>0.622</td><td>0.424</td></tr><tr><td>IP-Adapter</td><td>✓</td><td>0.667</td><td>0.558</td><td>0.504</td><td>0.576</td><td>0.743</td><td>0.446</td><td>0.607</td><td>0.350</td><td>0.790</td><td>0.764</td><td>0.743</td><td>0.766</td><td>0.695</td><td>0.377</td><td>0.589</td><td>0.451</td></tr><tr><td>IP-Adapter+</td><td>✓</td><td>0.900</td><td>0.845</td><td>0.759</td><td>0.834</td><td>0.502</td><td>0.279</td><td>0.388</td><td>0.324</td><td>0.481</td><td>0.473</td><td>0.530</td><td>0.504</td><td>0.442</td><td>0.229</td><td>0.371</td><td>0.187</td></tr><tr><td>Ours</td><td>✓</td><td>0.647</td><td>0.567</td><td>0.640</td><td>0.631</td><td>0.777</td><td>0.625</td><td>0.726</td><td>0.458</td><td>0.852</td><td>0.774</td><td>0.750</td><td>0.789</td><td>0.808</td><td>0.681</td><td>0.757</td><td>0.597</td></tr></table>

<table><tbody><tr><td rowspan="2">方法</td><td rowspan="2"></td><td colspan="4">概念保留</td><td colspan="3">提示遵循</td><td rowspan="2">概念保留 - 提示遵循(CP - PF)↑</td><td colspan="4">去偏概念保留</td><td colspan="4">去偏提示遵循</td></tr><tr><td>动物</td><td>人类↑</td><td>物体↑</td><td>总体↑</td><td>真实↑</td><td>虚构↑</td><td>总体↑</td><td>动物↑</td><td>人类↑</td><td>物体↑</td><td>总体↑</td><td>真实↑</td><td>虚构↑</td><td>总体↑</td><td>概念保留 - 提示遵循(CP - PF)↑</td></tr><tr><td>文本反转</td><td>✘</td><td>0.502</td><td>0.358</td><td>0.305</td><td>0.388</td><td>0.671</td><td>0.437</td><td>0.598</td><td>0.232</td><td>0.741</td><td>0.694</td><td>0.717</td><td>0.722</td><td>0.619</td><td>0.385</td><td>0.541</td><td>0.391</td></tr><tr><td>梦境展位(DreamBooth)</td><td>✘</td><td>0.640</td><td>0.199</td><td>0.488</td><td>0.442</td><td>0.798</td><td>0.504</td><td>0.692</td><td>0.306</td><td>0.670</td><td>0.362</td><td>0.676</td><td>0.626</td><td>0.750</td><td>0.467</td><td>0.656</td><td>0.411</td></tr><tr><td>梦境展位低秩自适应(DreamBooth LoRA)</td><td>✘</td><td>0.751</td><td>0.311</td><td>0.543</td><td>0.535</td><td>0.898</td><td>0.754</td><td>0.849</td><td>0.450</td><td>0.681</td><td>0.675</td><td>0.761</td><td>0.720</td><td>0.865</td><td>0.718</td><td>0.816</td><td>0.588</td></tr><tr><td>BLIP - 扩散模型</td><td>✓</td><td>0.637</td><td>0.557</td><td>0.469</td><td>0.554</td><td>0.581</td><td>0.303</td><td>0.464</td><td>0.257</td><td>0.771</td><td>0.733</td><td>0.745</td><td>0.750</td><td>0.529</td><td>0.266</td><td>0.442</td><td>0.332</td></tr><tr><td>鸸鹋2(Emu2)</td><td>✓</td><td>0.670</td><td>0.546</td><td>0.447</td><td>0.554</td><td>0.732</td><td>0.560</td><td>0.670</td><td>0.371</td><td>0.652</td><td>0.683</td><td>0.701</td><td>0.681</td><td>0.686</td><td>0.494</td><td>0.622</td><td>0.424</td></tr><tr><td>图像提示适配器(IP - Adapter)</td><td>✓</td><td>0.667</td><td>0.558</td><td>0.504</td><td>0.576</td><td>0.743</td><td>0.446</td><td>0.607</td><td>0.350</td><td>0.790</td><td>0.764</td><td>0.743</td><td>0.766</td><td>0.695</td><td>0.377</td><td>0.589</td><td>0.451</td></tr><tr><td>图像提示适配器增强版(IP - Adapter+)</td><td>✓</td><td>0.900</td><td>0.845</td><td>0.759</td><td>0.834</td><td>0.502</td><td>0.279</td><td>0.388</td><td>0.324</td><td>0.481</td><td>0.473</td><td>0.530</td><td>0.504</td><td>0.442</td><td>0.229</td><td>0.371</td><td>0.187</td></tr><tr><td>我们的方法</td><td>✓</td><td>0.647</td><td>0.567</td><td>0.640</td><td>0.631</td><td>0.777</td><td>0.625</td><td>0.726</td><td>0.458</td><td>0.852</td><td>0.774</td><td>0.750</td><td>0.789</td><td>0.808</td><td>0.681</td><td>0.757</td><td>0.597</td></tr></tbody></table>

Table 1. Quantitative result. On the human-aligned GPT score metrics, our method is only inferior to IP-Adapter+ [42] for concept preservation (largely because of IP-Adapter families' "copy-pasting" effect) and the tuning-base DreamBooth-LoRA [13, 31] for prompt following, but outperforms every other baseline, achieving the best overall performance considering both concept preservation and prompt following. We also note that on the de-biased GPT evaluation, which penalizes "copy-pasting" the reference image without significant creative interpretation or transformation, the advantages of IP-Adaper+ [42] no longer hold. This can also be partly observed by their bad prompt following scores, meaning they are biased towards the reference input and are not accommodating the input prompt. The first, second, and third values are highlighted, where Diffusion Self-Distillation is the best overall performing model.

表1. 定量结果。在与人对齐的GPT评分指标上，我们的方法仅在概念保留方面逊色于IP-Adapter+ [42](主要是因为IP-Adapter系列的“复制粘贴”效果)，在遵循提示方面逊色于微调基础的DreamBooth-LoRA [13, 31]，但优于其他所有基线方法。综合考虑概念保留和遵循提示这两个方面，我们的方法取得了最佳的整体性能。我们还注意到，在去偏的GPT评估中(该评估会对没有显著创意解读或转换而“复制粘贴”参考图像的情况进行惩罚)，IP-Adaper+ [42]的优势不再存在。从它们较差的遵循提示得分也可以部分观察到这一点，这意味着它们偏向于参考输入，而不能很好地适应输入提示。我们突出显示了排名第一、第二和第三的值，其中扩散自蒸馏是整体表现最佳的模型。

Quantitative results. Quantitative comparison with the baselines are shown in Tab. 1, where we report GPT evaluation following DreamBench++ [25]. Such an evaluation protocol is similar to human score but uses automatic multimodal LLMs. Our method achieves the best overall performances accommodating both concept preservation and prompt following, while only being inferior to IP-Adapter+ [42] for the former (mainly because of the "copy-paste" effect again), and the per-instance tuning DreamBooth-LoRA $\left\lbrack  {{13},{31}}\right\rbrack$ for the latter. We note that the concept preservation evaluation of DreamBench++ [25] is still biased towards favoring a "copy-paste" effect, especially on more challenging and diverse prompts. For instance, the outstanding concept preservation performances of the IP-Adapter family [42] are primarily because of their strong "copy-paste" effect, which copies over the input image without considering relevant essential changes in the prompts. This can also be partly observed by their underperforming prompt following scores, which means they are biased towards the reference input and do not accommodate the input prompt. Therefore, we also present our "de-biased" version of GPT scores, which are as simple as telling GPT to penalize if the generated image resembles a direct copy of the reference image. We observe that the advantages of IP-Adaper+ [42] no longer hold. Overall, Diffusion Self-Distillation is the best-performing model.

定量结果。与基线方法的定量比较见表1，我们按照DreamBench++ [25]的方法进行了GPT评估。这种评估协议与人工评分类似，但使用了自动多模态大语言模型。我们的方法在兼顾概念保留和遵循提示方面取得了最佳的整体性能，仅在概念保留方面逊色于IP-Adapter+ [42](主要还是因为“复制粘贴”效果)，在遵循提示方面逊色于逐实例微调的DreamBooth-LoRA $\left\lbrack  {{13},{31}}\right\rbrack$。我们注意到，DreamBench++ [25]的概念保留评估仍然偏向于“复制粘贴”效果，尤其是在更具挑战性和多样性的提示下。例如，IP-Adapter系列 [42]出色的概念保留性能主要是因为它们强大的“复制粘贴”效果，即直接复制输入图像而不考虑提示中的相关关键变化。从它们较差的遵循提示得分也可以部分观察到这一点，这意味着它们偏向于参考输入，而不能很好地适应输入提示。因此，我们还给出了“去偏”版的GPT得分，其方法很简单，就是告诉GPT如果生成的图像与参考图像直接复制相似就进行惩罚。我们发现，IP-Adaper+ [42]的优势不再存在。总体而言，扩散自蒸馏是表现最佳的模型。

Ablation studies. (1) Data curation: During dataset generation, we first synthesize grids using a frozen pre-trained FLUX model and then filter the images via VLM curation. Why not fine-tune the FLUX model on image grids to improve the hit rate? To study this, we fit a LoRA [13] using $> {7000}$ consistent grids (Fig. 6, left). Though a more significant proportion of samples are consistent grids, we find that the teacher model loses diversity in its output. Therefore, we choose to rely entirely on VLMs to help us curate from large numbers of diverse but potentially noisy grids. (2) Parallel processing architecture: We compare the parallel processing architecture to three alternative image-to-image architectures: 1) concatenating the source image to the noise image ("concatenation"); 2) a ControlNet [43]- based design, and 3) an IP-Adapter [42]-based design. We train each architecture using the same data as our parallel processing model (Fig. 6, middle). For ControlNet [43], we draw the same conclusion as prior work [14], in that it works best for structure-aligned edits, but generally struggles to preserve details when the source image and target image differ in camera pose. IP-Adapter [42] struggles to effectively transfer details and styles from the source image due to the limited capacity of its image encoder. (3) Other image-to-image tasks: Although not "self-distillation", since

消融研究。(1) 数据筛选:在数据集生成过程中，我们首先使用冻结的预训练FLUX模型合成网格，然后通过视觉语言模型(VLM)筛选图像。为什么不直接在图像网格上微调FLUX模型以提高命中率呢？为了研究这个问题，我们使用$> {7000}$一致网格拟合了一个LoRA [13](图6，左)。虽然有更大比例的样本是一致网格，但我们发现教师模型的输出失去了多样性。因此，我们选择完全依靠视觉语言模型(VLM)从大量多样但可能有噪声的网格中进行筛选。(2) 并行处理架构:我们将并行处理架构与三种替代的图像到图像架构进行了比较:1) 将源图像与噪声图像拼接(“拼接”)；2) 基于ControlNet [43]的设计；3) 基于IP-Adapter [42]的设计。我们使用与并行处理模型相同的数据训练了每种架构(图6，中间)。对于ControlNet [43]，我们得出了与先前工作 [14]相同的结论，即它在结构对齐编辑方面效果最佳，但当源图像和目标图像的相机姿态不同时，通常难以保留细节。由于其图像编码器的容量有限，IP-Adapter [42]难以有效地从源图像中传递细节和风格。(3) 其他图像到图像任务:虽然不是“自蒸馏”，因为

![0195d6ef-e939-7abd-9b6d-dae30f972af7_7_166_202_1466_369_0.jpg](images/0195d6ef-e939-7abd-9b6d-dae30f972af7_7_166_202_1466_369_0.jpg)

Figure 6. Ablation study. Left: We compare the base model's in-context sampling ability with a consistent grid LoRA-overfitted model. We observe that although applying LoRA to the base model can increase the likelihood of outputs being consistent grids, it may adversely affect output diversity. Therefore, we rely on vision-language models (VLMs) to curate from a large number of diverse but potentially noisy grids. Right: We compare our architectural design with a vanilla conditional model (by adding a few input channels), ControlNet [43], and IP-Adapter [42]. Our architecture learns the input concepts and identities significantly better. We also demonstrate that our architecture can effectively scale to depth-conditioned image generation similar to ControlNet [43].

图6. 消融研究。左:我们将基础模型的上下文采样能力与过拟合一致网格的LoRA模型进行了比较。我们观察到，虽然对基础模型应用LoRA可以增加输出为一致网格的可能性，但可能会对输出多样性产生不利影响。因此，我们依靠视觉语言模型(VLM)从大量多样但可能有噪声的网格中进行筛选。右:我们将我们的架构设计与普通条件模型(通过增加几个输入通道)、ControlNet [43]和IP-Adapter [42]进行了比较。我们的架构在学习输入概念和身份方面明显更优。我们还证明了我们的架构可以像ControlNet [43]一样有效地扩展到深度条件图像生成任务。

<table><tr><td>Method</td><td>CP↑</td><td>PF ↑</td><td>Creativity $\uparrow$</td></tr><tr><td>Textual Inversion [9]</td><td>1.693</td><td>1.924</td><td>2.850</td></tr><tr><td>DreamBooth [31]</td><td>2.329</td><td>2.883</td><td>3.597</td></tr><tr><td>DreamBooth LoRA [13, 31]</td><td>2.576</td><td>3.386</td><td>4.247</td></tr><tr><td>BLIP-Diffusion [17]</td><td>1.854</td><td>2.281</td><td>0.286</td></tr><tr><td>Emu2 [36]</td><td>1.843</td><td>2.096</td><td>2.965</td></tr><tr><td>IP-Adapter [42]</td><td>2.274</td><td>2.307</td><td>3.481</td></tr><tr><td>IP-Adapter+ [42]</td><td>3.733</td><td>1.959</td><td>2.428</td></tr><tr><td>Ours</td><td>3.661</td><td>3.328</td><td>4.453</td></tr></table>

<table><tbody><tr><td>方法</td><td>CP提升</td><td>PF提升</td><td>创造力 $\uparrow$</td></tr><tr><td>文本反转(Textual Inversion) [9]</td><td>1.693</td><td>1.924</td><td>2.850</td></tr><tr><td>梦境展位(DreamBooth) [31]</td><td>2.329</td><td>2.883</td><td>3.597</td></tr><tr><td>梦境展位低秩自适应(DreamBooth LoRA) [13, 31]</td><td>2.576</td><td>3.386</td><td>4.247</td></tr><tr><td>BLIP扩散模型(BLIP-Diffusion) [17]</td><td>1.854</td><td>2.281</td><td>0.286</td></tr><tr><td>鸸鹋2(Emu2) [36]</td><td>1.843</td><td>2.096</td><td>2.965</td></tr><tr><td>图像提示适配器(IP-Adapter) [42]</td><td>2.274</td><td>2.307</td><td>3.481</td></tr><tr><td>图像提示适配器增强版(IP-Adapter+) [42]</td><td>3.733</td><td>1.959</td><td>2.428</td></tr><tr><td>我们的方法</td><td>3.661</td><td>3.328</td><td>4.453</td></tr></tbody></table>

Table 2. User study. "CP" refers to concept preservation scores and "PF" refers to prompt following scores. The first, second, and third values are highlighted. Our user study results mostly align with our GPT evaluation, where our Diffusion Self-Distillation is the best overall performing model.

表2. 用户研究。“CP”指概念保留得分，“PF”指提示遵循得分。突出显示了第一、第二和第三的值。我们的用户研究结果大多与我们的GPT评估结果一致，其中我们的扩散自蒸馏(Diffusion Self-Distillation)是整体表现最佳的模型。

it requires an externally-sourced paired dataset (generated with Depth Anything [40]), we additionally train our architecture on depth-to-image to demonstrate its utility for more general image-to-image tasks (Fig. 6, right).

由于它需要一个外部来源的配对数据集(使用Depth Anything [40]生成)，我们还在深度到图像任务上训练了我们的架构，以证明其在更通用的图像到图像任务中的实用性(图6，右侧)。

User study. To evaluate the fidelity and prompt consistency of our generated images, we conducted a user study on a random subset of the DreamBench++ [25] test cases, selecting 20 samples. A total of 25 female and 29 male annotators, aged from 22 to 78 (average 34), independently scored each image from 1 to 5 based on three criteria: (1) concept preservation-the consistency with the reference image, (2) prompt alignment-the consistency with the given prompt, and (3) creativity-the level of internal understanding and transformation. The average scores are presented in Tab. 2. Our human annotations closely align with the GPT evaluation, demonstrating that our Diffusion Self-Distillation is slightly behind IP-Adapter+[42] in concept preservation and the inference-stage tuning method DreamBooth-LoRA [13, 31] in prompt alignment. Notably, our model achieved the highest creativity score, while IP-Adapter+ [42] scored lower in this metric due to its "copy-paste" effect. These results further confirm that our Diffusion Self-Distillation offers the

用户研究。为了评估我们生成图像的保真度和提示一致性，我们对DreamBench++ [25]测试用例的一个随机子集进行了用户研究，选择了20个样本。共有25名女性和29名男性注释者，年龄从22岁到78岁(平均34岁)，根据三个标准对每张图像独立打分，分数从1到5:(1)概念保留——与参考图像的一致性；(2)提示对齐——与给定提示的一致性；(3)创造性——内部理解和转换的水平。平均分见表2。我们的人工注释与GPT评估结果非常一致，表明我们的扩散自蒸馏(Diffusion Self-Distillation)在概念保留方面略落后于IP-Adapter+ [42]，在提示对齐方面略落后于推理阶段调优方法DreamBooth-LoRA [13, 31]。值得注意的是，我们的模型在创造性得分方面最高，而IP-Adapter+ [42]由于其“复制粘贴”效应，在这一指标上得分较低。这些结果进一步证实，我们的扩散自蒸馏(Diffusion Self-Distillation)提供了

most balanced and superior overall performance.

最平衡且卓越的整体性能。

## 5. Discussion

## 5. 讨论

We present Diffusion Self-Distillation, a zero-shot approach designed to achieve identity adaptation across a wide range of contexts using text-to-image diffusion models without any human effort. Our method effectively transforms zero-shot customized image generation into a supervised task, substantially reducing its difficulty. Empirical evaluations demonstrate that Diffusion Self-Distillation performs comparably to inference-stage tuning techniques while retaining the efficiency of zero-shot methods.

我们提出了扩散自蒸馏(Diffusion Self-Distillation)，这是一种零样本方法，旨在使用文本到图像扩散模型在无需任何人工干预的情况下，在广泛的上下文中实现身份适配。我们的方法有效地将零样本定制图像生成转化为有监督任务，大大降低了其难度。实证评估表明，扩散自蒸馏(Diffusion Self-Distillation)的性能与推理阶段调优技术相当，同时保留了零样本方法的效率。

Limitations and future work. Our work focuses on identity-preserving edits of characters, objects, and scene relighting. Future directions could explore additional tasks and use cases. Integration with ControlNet [43], for example, could provide fine-grained and independent control of identity and structure. Additionally, extending our approach from image to video generation is a promising avenue of future work.

局限性和未来工作。我们的工作专注于对人物、物体和场景重新打光进行保留身份的编辑。未来的研究方向可以探索更多的任务和用例。例如，与ControlNet [43]集成可以对身份和结构进行细粒度和独立的控制。此外，将我们的方法从图像生成扩展到视频生成是未来工作的一个有前景的方向。

Ethics. We are mindful of the potential misuse, particularly in deepfakes. We oppose exploiting our work for purposes that infringe upon ethical standards or privacy.

伦理问题。我们意识到可能存在的滥用情况，特别是在深度伪造方面。我们反对将我们的工作用于违反道德标准或侵犯隐私的目的。

Conclusion. Our Diffusion Self-Distillation democratizes content creation, enabling identity-preserving, high-quality, and fast customized image generation that adapts seamlessly to evolving foundational models, significantly expanding the creative boundaries of art, design, and digital storytelling.

结论。我们的扩散自蒸馏(Diffusion Self-Distillation)使内容创作更加大众化，能够实现保留身份、高质量且快速的定制图像生成，无缝适应不断发展的基础模型，显著拓展了艺术、设计和数字叙事的创作边界。

Acknowledgements. This project was in part supported by Google, Kaiber AI, 3bodylabs, ONR N00014-23-1-2355, and NSF RI #2211258. ERC was supported by the Nvidia Graduate Fellowship and the Snap Research Fellowship. YZ was in part supported by the Stanford Interdisciplinary Graduate Fellowship.

致谢。本项目部分得到了谷歌(Google)、Kaiber AI、3bodylabs、海军研究办公室(ONR)N00014 - 23 - 1 - 2355以及美国国家科学基金会(NSF)RI #2211258的支持。ERC得到了英伟达研究生奖学金(Nvidia Graduate Fellowship)和Snap研究奖学金(Snap Research Fellowship)的支持。YZ部分得到了斯坦福跨学科研究生奖学金(Stanford Interdisciplinary Graduate Fellowship)的支持。

References

参考文献

[1] Andreas Blattmann, Tim Dockhorn, Sumith Kulal, Daniel Mendelevitch, Maciej Kilian, Dominik Lorenz, Yam Levi, Zion English, Vikram Voleti, Adam Letts, Varun Jampani, and Robin Rombach. Stable video diffusion: Scaling latent video diffusion models to large datasets. In arXiv, 2023. 4

[1] Andreas Blattmann、Tim Dockhorn、Sumith Kulal、Daniel Mendelevitch、Maciej Kilian、Dominik Lorenz、Yam Levi、Zion English、Vikram Voleti、Adam Letts、Varun Jampani和Robin Rombach。稳定视频扩散:将潜在视频扩散模型扩展到大型数据集。发表于arXiv，2023年。4

[2] Tim Brooks, Aleksander Holynski, and Alexei A. Efros. In-structpix2pix: Learning to follow image editing instructions. In ${CVPR},{2023.2},6,7,1$

[2] Tim Brooks、Aleksander Holynski和Alexei A. Efros。In - structpix2pix:学习遵循图像编辑指令。发表于${CVPR},{2023.2},6,7,1$

[3] Tim Brooks, Bill Peebles, Connor Holmes, Will DePue, Yufei Guo, Li Jing, David Schnurr, Joe Taylor, Troy Luhman, Eric Luhman, Clarence Ng, Ricky Wang, and Aditya Ramesh. Video generation models as world simulators. https://openai.com/research/video-generation-models-as-world-simulators, 2024. 4

[3] Tim Brooks、Bill Peebles、Connor Holmes、Will DePue、Yufei Guo、Li Jing、David Schnurr、Joe Taylor、Troy Luhman、Eric Luhman、Clarence Ng、Ricky Wang和Aditya Ramesh。视频生成模型作为世界模拟器。https://openai.com/research/video-generation-models-as-world-simulators，2024年。4

[4] Shengqu Cai, Eric Ryan Chan, Songyou Peng, Mohamad Shahbazi, Anton Obukhov, Luc Van Gool, and Gordon Wet-zstein. Diffdreamer: Towards consistent unsupervised single-view scene extrapolation with conditional diffusion models. In ${ICCV},{2023}$ .

[4] Shengqu Cai、Eric Ryan Chan、Songyou Peng、Mohamad Shahbazi、Anton Obukhov、Luc Van Gool和Gordon Wet - zstein。Diffdreamer:使用条件扩散模型实现一致的无监督单视图场景外推。发表于${ICCV},{2023}$ 。

[5] Shengqu Cai, Duygu Ceylan, Matheus Gadelha, Chun-Hao Huang, Tuanfeng Wang, and Gordon. Wetzstein. Generative rendering: Controllable 4d-guided video generation with 2d diffusion models. In ${CVPR},{2024}$ . 4

[5] 蔡胜曲(Shengqu Cai)、杜伊古·塞兰(Duygu Ceylan)、马泰乌斯·加德利亚(Matheus Gadelha)、黄俊豪(Chun-Hao Huang)、王团风(Tuanfeng Wang)和戈登·韦茨斯坦(Gordon. Wetzstein)。生成式渲染:使用二维扩散模型进行可控的四维引导视频生成。见 ${CVPR},{2024}$ . 4

[6] Mathilde Caron, Hugo Touvron, Ishan Misra, Hervé Jégou, Julien Mairal, Piotr Bojanowski, and Armand Joulin. Emerging properties in self-supervised vision transformers. In ${ICCV}$ , 2021. 5

[6] 玛蒂尔德·卡龙(Mathilde Caron)、雨果·图夫龙(Hugo Touvron)、伊尚·米斯拉(Ishan Misra)、埃尔韦·热古(Hervé Jégou)、朱利安·梅拉勒(Julien Mairal)、皮奥特·博亚诺夫斯基(Piotr Bojanowski)和阿尔芒·朱兰(Armand Joulin)。自监督视觉变换器中的新兴特性。见 ${ICCV}$ ，2021 年。5

[7] Wenhu Chen, Hexiang Hu, Yandong Li, Nataniel Ruiz, Xuhui Jia, Ming-Wei Chang, and William W Cohen. Subject-driven text-to-image generation via apprenticeship learning. In NeurIPS, 2023. 3, 5

[7] 陈文虎(Wenhu Chen)、胡鹤翔(Hexiang Hu)、李岩东(Yandong Li)、纳塔尼尔·鲁伊斯(Nataniel Ruiz)、贾旭辉(Xuhui Jia)、张明伟(Ming-Wei Chang)和威廉·W·科恩(William W Cohen)。通过学徒式学习实现主题驱动的文本到图像生成。见神经信息处理系统大会(NeurIPS)，2023 年。3, 5

[8] Patrick Esser, Sumith Kulal, A. Blattmann, Rahim Entezari, Jonas Muller, Harry Saini, Yam Levi, Dominik Lorenz, Axel Sauer, Frederic Boesel, Dustin Podell, Tim Dockhorn, Zion English, Kyle Lacey, Alex Goodwin, Yannik Marek, and Robin Rombach. Scaling rectified flow transformers for high-resolution image synthesis. In ${ICML},{2024}.4$

[8] 帕特里克·埃瑟(Patrick Esser)、苏米斯·库拉尔(Sumith Kulal)、A. 布拉特曼(A. Blattmann)、拉希姆·恩特扎里(Rahim Entezari)、乔纳斯·穆勒(Jonas Muller)、哈里·赛尼(Harry Saini)、亚姆·列维(Yam Levi)、多米尼克·洛伦茨(Dominik Lorenz)、阿克塞尔·绍尔(Axel Sauer)、弗雷德里克·伯泽尔(Frederic Boesel)、达斯汀·波德尔(Dustin Podell)、蒂姆·多克霍恩(Tim Dockhorn)、锡安·英格利什(Zion English)、凯尔·莱西(Kyle Lacey)、亚历克斯·古德温(Alex Goodwin)、扬尼克·马雷克(Yannik Marek)和罗宾·隆巴赫(Robin Rombach)。用于高分辨率图像合成的缩放整流流变换器。见 ${ICML},{2024}.4$

[9] Rinon Gal, Yuval Alaluf, Yuval Atzmon, Or Patashnik, Amit Haim Bermano, Gal Chechik, and Daniel Cohen-or. An image is worth one word: Personalizing text-to-image generation using textual inversion. In ${ICLR},{2023.5},6,8$

[9] 里农·加尔(Rinon Gal)、尤瓦尔·阿拉卢夫(Yuval Alaluf)、尤瓦尔·阿茨蒙(Yuval Atzmon)、奥尔·帕塔什尼克(Or Patashnik)、阿米特·海姆·贝尔马诺(Amit Haim Bermano)、加尔·切希克(Gal Chechik)和丹尼尔·科恩 - 奥尔(Daniel Cohen - or)。一图胜一词:使用文本反转实现个性化的文本到图像生成。见 ${ICLR},{2023.5},6,8$

[10] Yuwei Guo, Ceyuan Yang, Anyi Rao, Yaohui Wang, Yu Qiao, Dahua Lin, and Bo Dai. Animatediff: Animate your personalized text-to-image diffusion models without specific tuning. In arXiv, 2023. 4

[10] 郭雨薇(Yuwei Guo)、杨策远(Ceyuan Yang)、饶安逸(Anyi Rao)、王耀辉(Yaohui Wang)、乔宇(Yu Qiao)、林达华(Dahua Lin)和戴博(Bo Dai)。Animatediff:无需特定调优即可为个性化的文本到图像扩散模型实现动画效果。见预印本平台 arXiv，2023 年。4

[11] Yingqing He, Tianyu Yang, Yong Zhang, Ying Shan, and Qifeng Chen. Latent video diffusion models for high-fidelity long video generation. In arXiv, 2022.

[11] 何迎清(Yingqing He)、杨天予(Tianyu Yang)、张永(Yong Zhang)、单莹(Ying Shan)和陈启峰(Qifeng Chen)。用于高保真长视频生成的潜在视频扩散模型。见预印本平台 arXiv，2022 年。

[12] Wenyi Hong, Ming Ding, Wendi Zheng, Xinghan Liu, and Jie Tang. Cogvideo: Large-scale pretraining for text-to-video generation via transformers. In arXiv, 2022. 4

[12] 洪文怡(Wenyi Hong)、丁明(Ming Ding)、郑文迪(Wendi Zheng)、刘兴汉(Xinghan Liu)和唐杰(Jie Tang)。Cogvideo:通过变换器进行文本到视频生成的大规模预训练。见预印本平台 arXiv，2022 年。4

[13] Edward J. Hu, Yelong Shen, Phillip Wallis, Zeyuan Allen-Zhu, Yuanzhi Li, Shean Wang, Lu Wang, and Weizhu Chen. Lora: Low-rank adaptation of large language models. In ${ICLR},{2022.2},3,5,6,7,8$

[13] 爱德华·J·胡(Edward J. Hu)、沈叶龙(Yelong Shen)、菲利普·沃利斯(Phillip Wallis)、泽远·艾伦 - 朱(Zeyuan Allen - Zhu)、李远志(Yuanzhi Li)、王社安(Shean Wang)、王璐(Lu Wang)和陈伟柱(Weizhu Chen)。低秩自适应大语言模型(LoRA)。见 ${ICLR},{2022.2},3,5,6,7,8$

[14] Li Hu, Xin Gao, Peng Zhang, Ke Sun, Bang Zhang, and Liefeng Bo. Animate anyone: Consistent and controllable

[14] 胡立(Li Hu)、高鑫(Xin Gao)、张鹏(Peng Zhang)、孙科(Ke Sun)、张邦(Bang Zhang)和薄立峰(Liefeng Bo)。让任何人动起来:用于角色动画的一致且可控的

image-to-video synthesis for character animation. In arXiv, 2023. 4, 7

图像到视频合成。见预印本平台 arXiv，2023 年。4, 7

[15] Lianghua Huang, Wei Wang, Zhi-Fan Wu, Huanzhang Dou, Yupeng Shi, Yutong Feng, Chen Liang, Yu Liu, and Jingren Zhou. Group diffusion transformers are unsupervised multitask learners. In arXiv, 2024. 3

[15] 黄良华(Lianghua Huang)、王伟(Wei Wang)、吴智凡(Zhi - Fan Wu)、窦焕章(Huanzhang Dou)、史宇鹏(Yupeng Shi)、冯宇彤(Yutong Feng)、陈亮(Chen Liang)、刘煜(Yu Liu)和周景仁(Jingren Zhou)。组扩散变换器是无监督多任务学习者。见预印本平台 arXiv，2024 年。3

[16] Zhengfei Kuang, Shengqu Cai, Hao He, Yinghao Xu, Hong-sheng Li, Leonidas Guibas, and Gordon. Wetzstein. Collaborative video diffusion: Consistent multi-video generation with camera control. In NeurIPS, 2024. 4

[16] 匡正飞(Zhengfei Kuang)、蔡胜曲(Shengqu Cai)、何浩(Hao He)、徐英豪(Yinghao Xu)、李洪生(Hong - sheng Li)、利奥尼达斯·吉巴斯(Leonidas Guibas)和戈登·韦茨斯坦(Gordon. Wetzstein)。协作视频扩散:通过相机控制实现一致的多视频生成。见神经信息处理系统大会(NeurIPS)，2024 年。4

[17] Dongxu Li, Junnan Li, and Steven Hoi. BLIP-diffusion: Pre-trained subject representation for controllable text-to-image generation and editing. In NeurIPS, 2023. 5, 6, 8

[17] 李东旭(Dongxu Li)、李俊楠(Junnan Li)和史蒂文·霍伊(Steven Hoi)。BLIP - 扩散:用于可控文本到图像生成和编辑的预训练主题表示。见神经信息处理系统大会(NeurIPS)，2023 年。5, 6, 8

[18] Jiahao Li, Hao Tan, Kai Zhang, Zexiang Xu, Fujun Luan, Yinghao Xu, Yicong Hong, Kalyan Sunkavalli, Greg Shakhnarovich, and Sai Bi. Instant3d: Fast text-to-3d with sparse-view generation and large reconstruction model. In arXiv, 2023. 4

[18] 李佳豪(Jiahao Li)、谭浩(Hao Tan)、张凯(Kai Zhang)、徐泽翔(Zexiang Xu)、栾福军(Fujun Luan)、徐英豪(Yinghao Xu)、洪一聪(Yicong Hong)、卡利安·松卡瓦利(Kalyan Sunkavalli)、格雷格·沙克纳罗维奇(Greg Shakhnarovich)和毕赛(Sai Bi)。Instant3d:通过稀疏视图生成和大型重建模型实现快速文本到三维转换。见预印本平台 arXiv，2023 年。4

[19] Ming Li, Taojiannan Yang, Huafeng Kuang, Jie Wu, Zhaoning Wang, Xuefeng Xiao, and Chen Chen. Controlnet++: Improving conditional controls with efficient consistency feedback. In ${ECCV},{2024.3}$

[19] 李明(Ming Li)、杨桃剑楠(Taojiannan Yang)、邝华峰(Huafeng Kuang)、吴杰(Jie Wu)、王兆宁(Zhaoning Wang)、肖雪峰(Xuefeng Xiao)和陈晨(Chen Chen)。Controlnet++:通过高效一致性反馈改进条件控制。见 ${ECCV},{2024.3}$

[20] Ilya Loshchilov and Frank Hutter. Decoupled weight decay regularization. In ${ICLR},{2019.4}$

[20] 伊利亚·洛希奇洛夫(Ilya Loshchilov)和弗兰克·胡特(Frank Hutter)。解耦权重衰减正则化。见${ICLR},{2019.4}$

[21] Jian Ma, Junhao Liang, Chen Chen, and Haonan Lu. Subject-diffusion: Open domain personalized text-to-image generation without test-time fine-tuning. In SIGGRAPH, 2024. 3

[21] 马健、梁俊豪、陈晨和陆浩楠。主题扩散:无需测试时微调的开放域个性化文本到图像生成。见SIGGRAPH，2024年。3

[22] Chenlin Meng, Yutong He, Yang Song, Jiaming Song, Jiajun Wu, Jun-Yan Zhu, and Stefano Ermon. SDEdit: Guided image synthesis and editing with stochastic differential equations. In ${ICLR},{2022.2}$

[22] 孟晨琳、何宇彤、宋洋、宋佳明、吴佳俊、朱俊彦和斯特凡诺·埃尔蒙(Stefano Ermon)。SDEdit:使用随机微分方程进行引导式图像合成与编辑。见${ICLR},{2022.2}$

[23] Chong Mou, Xintao Wang, Liangbin Xie, Yanze Wu, Jian Zhang, Zhongang Qi, Ying Shan, and Xiaohu Qie. T2i-adapter: Learning adapters to dig out more controllable ability for text-to-image diffusion models. In ${AAAI},{2024.3}$

[23] 牟冲、王新涛、谢良斌、吴彦泽、张健、齐中昂、单莹和郄小虎。T2i适配器:学习适配器以挖掘文本到图像扩散模型更多的可控能力。见${AAAI},{2024.3}$

[24] Alex Nichol, Prafulla Dhariwal, Aditya Ramesh, Pranav Shyam, Pamela Mishkin, Bob McGrew, Ilya Sutskever, and Mark Chen. GLIDE: towards photorealistic image generation and editing with text-guided diffusion models. In arXiv, 2021. 1

[24] 亚历克斯·尼科尔(Alex Nichol)、普拉富拉·达里瓦尔(Prafulla Dhariwal)、阿迪蒂亚·拉梅什(Aditya Ramesh)、普拉纳夫·沙姆(Pranav Shyam)、帕梅拉·米什金(Pamela Mishkin)、鲍勃·麦格鲁(Bob McGrew)、伊利亚·苏茨克维(Ilya Sutskever)和马克·陈(Mark Chen)。GLIDE:借助文本引导的扩散模型实现逼真的图像生成与编辑。见arXiv，2021年。1

[25] Yuang Peng, Yuxin Cui, Haomiao Tang, Zekun Qi, Runpei Dong, Jing Bai, Chunrui Han, Zheng Ge, Xiangyu Zhang, and Shu-Tao Xia. Dreambench++: A human-aligned benchmark for personalized image generation. In arXiv, 2023. 5, 7, 8, 1, 2

[25] 彭远、崔宇鑫、唐浩淼、齐泽坤、董润培、白静、韩春瑞、葛政、张翔宇和夏书涛。Dreambench++:用于个性化图像生成的人类对齐基准。见arXiv，2023年。5, 7, 8, 1, 2

[26] Ryan Po, Wang Yifan, Vladislav Golyanik, Kfir Aberman, Jonathan T Barron, Amit H Bermano, Eric Ryan Chan, Tali Dekel, Aleksander Holynski, Angjoo Kanazawa, et al. State of the art on diffusion models for visual computing. In arXiv, 2023. 3

[26] 瑞安·波(Ryan Po)、王一凡、弗拉迪斯拉夫·戈利亚尼克(Vladislav Golyanik)、基弗·阿伯曼(Kfir Aberman)、乔纳森·T·巴伦(Jonathan T Barron)、阿米特·H·贝尔马诺(Amit H Bermano)、埃里克·瑞安·陈(Eric Ryan Chan)、塔利·德克尔(Tali Dekel)、亚历山大·霍林斯基(Aleksander Holynski)、安乔·金泽(Angjoo Kanazawa)等。视觉计算中扩散模型的最新进展。见arXiv，2023年。3

[27] Alec Radford, Jong Wook Kim, Chris Hallacy, Aditya Ramesh, Gabriel Goh, Sandhini Agarwal, Girish Sastry, Amanda Askell, Pamela Mishkin, Jack Clark, Gretchen Krueger, and Ilya Sutskever. Learning transferable visual models from natural language supervision. In CoRR, 2021. 5

[27] 亚历克·拉德福德(Alec Radford)、金钟旭(Jong Wook Kim)、克里斯·哈拉西(Chris Hallacy)、阿迪蒂亚·拉梅什(Aditya Ramesh)、加布里埃尔·戈(Gabriel Goh)、桑迪尼·阿加瓦尔(Sandhini Agarwal)、吉里什·萨斯特里(Girish Sastry)、阿曼达·阿斯凯尔(Amanda Askell)、帕梅拉·米什金(Pamela Mishkin)、杰克·克拉克(Jack Clark)、格雷琴·克鲁格(Gretchen Krueger)和伊利亚·苏茨克维(Ilya Sutskever)。从自然语言监督中学习可迁移的视觉模型。见CoRR，2021年。5

[28] Aditya Ramesh, Prafulla Dhariwal, Alex Nichol, Casey Chu, and Mark Chen. Hierarchical text-conditional image generation with clip latents. In arXiv, 2022. 1

[28] 阿迪蒂亚·拉梅什(Aditya Ramesh)、普拉富拉·达里瓦尔(Prafulla Dhariwal)、亚历克斯·尼科尔(Alex Nichol)、凯西·朱(Casey Chu)和马克·陈(Mark Chen)。使用CLIP潜变量进行分层文本条件图像生成。见arXiv，2022年。1

[29] Robin Rombach, Andreas Blattmann, Dominik Lorenz, Patrick Esser, and Björn Ommer. High-resolution image synthesis with latent diffusion models. In CVPR, 2022. 1

[29] 罗宾·龙巴赫(Robin Rombach)、安德烈亚斯·布拉特曼(Andreas Blattmann)、多米尼克·洛伦茨(Dominik Lorenz)、帕特里克·埃瑟(Patrick Esser)和比约恩·奥默(Björn Ommer)。使用潜扩散模型进行高分辨率图像合成。见CVPR，2022年。1

[30] Ciara Rowles, Shimon Vainer, Dante De Nigris, Slava Elizarov, Konstantin Kutsy, and Simon Donné. Ipadapter-instruct: Resolving ambiguity in image-based conditioning using instruct prompts. In arXiv, 2024. 3, 5

[30] 西娅拉·罗尔斯(Ciara Rowles)、西蒙·瓦伊纳(Shimon Vainer)、但丁·德·尼格里斯(Dante De Nigris)、斯拉瓦·叶利扎罗夫(Slava Elizarov)、康斯坦丁·库茨(Konstantin Kutsy)和西蒙·多内(Simon Donné)。Ipadapter指令:使用指令提示解决基于图像的条件中的歧义。见arXiv，2024年。3, 5

[31] Nataniel Ruiz, Yuanzhen Li, Varun Jampani, Yael Pritch, Michael Rubinstein, and Kfir Aberman. Dreambooth: Fine tuning text-to-image diffusion models for subject-driven generation. In ${CVPR},{2023.2},3,5,6,7,8$

[31] 纳塔尼尔·鲁伊斯(Nataniel Ruiz)、李元珍、瓦伦·詹帕尼(Varun Jampani)、亚埃尔·普里奇(Yael Pritch)、迈克尔·鲁宾斯坦(Michael Rubinstein)和基弗·阿伯曼(Kfir Aberman)。Dreambooth:针对主题驱动生成微调文本到图像扩散模型。见${CVPR},{2023.2},3,5,6,7,8$

[32] Chitwan Saharia, William Chan, Saurabh Saxena, Lala Li, Jay Whang, Emily Denton, Seyed Kamyar Seyed Ghasemipour, Burcu Karagol Ayan, S. Sara Mahdavi, Rapha Gontijo Lopes, Tim Salimans, Jonathan Ho, David J Fleet, and Mohammad Norouzi. Photorealistic text-to-image diffusion models with deep language understanding. In NeurIPS, 2022. 1

[32] 奇特万·萨哈里亚(Chitwan Saharia)、威廉·陈(William Chan)、索拉布·萨克塞纳(Saurabh Saxena)、拉拉·李(Lala Li)、杰伊·黄(Jay Whang)、艾米丽·丹顿(Emily Denton)、赛义德·卡米亚尔·赛义德·加塞米普尔(Seyed Kamyar Seyed Ghasemipour)、布尔库·卡拉戈尔·阿扬(Burcu Karagol Ayan)、S. 萨拉·马赫达维(S. Sara Mahdavi)、拉法·贡蒂霍·洛佩斯(Rapha Gontijo Lopes)、蒂姆·萨利曼斯(Tim Salimans)、乔纳森·霍(Jonathan Ho)、大卫·J·弗利特(David J Fleet)和穆罕默德·诺鲁兹(Mohammad Norouzi)。具有深度语言理解的逼真文本到图像扩散模型。见NeurIPS，2022年。1

[33] Christoph Schuhmann, Romain Beaumont, Richard Vencu, Cade W Gordon, Ross Wightman, Mehdi Cherti, Theo Coombes, Aarush Katta, Clayton Mullis, Mitchell Worts-man, Patrick Schramowski, Srivatsa R Kundurthy, Katherine Crowson, Ludwig Schmidt, Robert Kaczmarczyk, and Jenia Jitsev. LAION-5b: An open large-scale dataset for training next generation image-text models. In NeurIPS, 2022. 2, 4

[33] 克里斯托夫·舒曼(Christoph Schuhmann)、罗曼·博蒙特(Romain Beaumont)、理查德·文库(Richard Vencu)、凯德·W·戈登(Cade W Gordon)、罗斯·怀特曼(Ross Wightman)、梅赫迪·切尔蒂(Mehdi Cherti)、西奥·库姆斯(Theo Coombes)、阿鲁什·卡塔(Aarush Katta)、克莱顿·穆利斯(Clayton Mullis)、米切尔·沃茨曼(Mitchell Worts - man)、帕特里克·施拉莫夫斯基(Patrick Schramowski)、斯里瓦茨·R·昆杜尔蒂(Srivatsa R Kundurthy)、凯瑟琳·克劳森(Katherine Crowson)、路德维希·施密特(Ludwig Schmidt)、罗伯特·卡兹马尔奇克(Robert Kaczmarczyk)和叶尼亚·吉特塞夫(Jenia Jitsev)。LAION - 5b:用于训练下一代图像 - 文本模型的开放大规模数据集。见NeurIPS，2022年。2, 4

[34] Ruizhi Shao, Youxin Pang, Zerong Zheng, Jingxiang Sun, and Yebin Liu. Human4dit: 360-degree human video generation with 4d diffusion transformer. In SIGGRAPH Asia, 2024. 4

[34] 邵睿智(Ruizhi Shao)、庞友鑫(Youxin Pang)、郑泽荣(Zerong Zheng)、孙景翔(Jingxiang Sun)和刘烨斌(Yebin Liu)。Human4dit:使用4D扩散变压器生成360度人体视频。发表于《SIGGRAPH亚洲会议论文集》，2024年。4

[35] Yichun Shi, Peng Wang, Jianglong Ye, Long Mai, Kejie Li, and Xiao Yang. Mvdream: Multi-view diffusion for 3d generation. In arXiv, 2023. 4

[35] 施怡春(Yichun Shi)、王鹏(Peng Wang)、叶江龙(Jianglong Ye)、麦龙(Long Mai)、李可杰(Kejie Li)和杨晓(Xiao Yang)。Mvdream:用于3D生成的多视图扩散模型。发表于预印本平台arXiv，2023年。4

[36] Quan Sun, Yufeng Cui, Xiaosong Zhang, Fan Zhang, Qiying

[36] 孙全(Quan Sun)、崔宇峰(Yufeng Cui)、张晓松(Xiaosong Zhang)、张帆(Fan Zhang)、齐英

Yu, Zhengxiong Luo, Yueze Wang, Yongming Rao, Jingjing Liu, Tiejun Huang, and Xinlong Wang. Generative multimodal models are in-context learners. In CVPR, 2024. 5, 7, 8

于(Qiying Yu)、罗正雄(Zhengxiong Luo)、王悦泽(Yueze Wang)、饶永明(Yongming Rao)、刘晶晶(Jingjing Liu)、黄铁军(Tiejun Huang)和王新龙(Xinlong Wang)。生成式多模态模型是上下文学习器。发表于《计算机视觉与模式识别会议论文集》(CVPR)，2024年。5, 7, 8

[37] Qixun Wang, Xu Bai, Haofan Wang, Zekui Qin, and Anthony Chen. Instantid: Zero-shot identity-preserving generation in seconds. In arXiv, 2024. 2, 3

[37] 王启勋(Qixun Wang)、白旭(Xu Bai)、王浩凡(Haofan Wang)、秦泽奎(Zekui Qin)和陈安东尼(Anthony Chen)。Instantid:秒级零样本保身份生成。发表于预印本平台arXiv，2024年。2, 3

[38] Jason Wei, Xuezhi Wang, Dale Schuurmans, Maarten Bosma, brian ichter, Fei Xia, Ed H. Chi, Quoc V Le, and Denny Zhou. Chain of thought prompting elicits reasoning in large language models. In NeurIPS, 2022. 4, 1

[38] 杰森·魏(Jason Wei)、王学志(Xuezhi Wang)、戴尔·舒尔曼斯(Dale Schuurmans)、马腾·博斯马(Maarten Bosma)、布莱恩·伊克特(brian ichter)、夏飞(Fei Xia)、埃德·H·池(Ed H. Chi)、乐国伟(Quoc V Le)和周丹尼(Denny Zhou)。思维链提示在大语言模型中引发推理。发表于《神经信息处理系统大会论文集》(NeurIPS)，2022年。4, 1

[39] Yinghao Xu, Hao Tan, Fujun Luan, Sai Bi, Peng Wang, Jiahao Li, Zifan Shi, Kalyan Sunkavalli, Gordon Wetzstein, Zexiang $\mathrm{{Xu}}$ , and Kai Zhang. Dmv3d: Denoising multi-view diffusion using 3d large reconstruction model. In arXiv, 2023. 4

[39] 徐英豪(Yinghao Xu)、谭浩(Hao Tan)、栾福军(Fujun Luan)、毕赛(Sai Bi)、王鹏(Peng Wang)、李佳豪(Jiahao Li)、石子凡(Zifan Shi)、卡利安·松卡瓦利(Kalyan Sunkavalli)、戈登·韦茨斯坦(Gordon Wetzstein)、泽祥 $\mathrm{{Xu}}$ 以及张凯(Kai Zhang)。Dmv3d:使用3D大型重建模型对多视图扩散进行去噪。发表于预印本平台arXiv，2023年。4

[40] Lihe Yang, Bingyi Kang, Zilong Huang, Xiaogang Xu, Jiashi Feng, and Hengshuang Zhao. Depth anything: Unleashing the power of large-scale unlabeled data. In CVPR, 2024. 8

[40] 杨立和(Lihe Yang)、康炳毅(Bingyi Kang)、黄紫龙(Zilong Huang)、徐小刚(Xiaogang Xu)、冯佳时(Jiashi Feng)和赵衡爽(Hengshuang Zhao)。深度万物:释放大规模无标签数据的力量。发表于《计算机视觉与模式识别会议论文集》(CVPR)，2024年。8

[41] Zhuoyi Yang, Jiayan Teng, Wendi Zheng, Ming Ding, Shiyu Huang, Jiazheng Xu, Yuanming Yang, Wenyi Hong, Xiao-han Zhang, Guanyu Feng, et al. Cogvideox: Text-to-video diffusion models with an expert transformer. In arXiv, 2024. 4

[41] 杨卓一(Zhuoyi Yang)、滕佳燕(Jiayan Teng)、郑文迪(Wendi Zheng)、丁铭(Ming Ding)、黄世玉(Shiyu Huang)、许家正(Jiazheng Xu)、杨远明(Yuanming Yang)、洪文怡(Wenyi Hong)、张晓晗(Xiao-han Zhang)、冯冠宇(Guanyu Feng)等。Cogvideox:带有专家变压器的文本到视频扩散模型。发表于预印本平台arXiv，2024年。4

[42] Hu Ye, Jun Zhang, Sibo Liu, Xiao Han, and Wei Yang. Ip-adapter: Text compatible image prompt adapter for text-to-image diffusion models. In arXiv, 2023. 2, 3, 4, 5, 7, 8

[42] 叶虎(Hu Ye)、张军(Jun Zhang)、刘思博(Sibo Liu)、肖涵(Xiao Han)和杨威(Wei Yang)。Ip-adapter:用于文本到图像扩散模型的文本兼容图像提示适配器。发表于预印本平台arXiv，2023年。2, 3, 4, 5, 7, 8

[43] Lvmin Zhang, Anyi Rao, and Maneesh Agrawala. Adding conditional control to text-to-image diffusion models. In ICCV, 2023. 2, 3, 4, 7, 8

[43] 张绿敏(Lvmin Zhang)、饶安怡(Anyi Rao)和马内什·阿格拉瓦拉(Maneesh Agrawala)。为文本到图像扩散模型添加条件控制。发表于《国际计算机视觉会议论文集》(ICCV)，2023年。2, 3, 4, 7, 8

[44] Shihao Zhao, Dongdong Chen, Yen-Chun Chen, Jianmin Bao, Shaozhe Hao, Lu Yuan, and Kwan-Yee K. Wong. Uni-controlnet: All-in-one control to text-to-image diffusion models. In NeurIPS, 2023. 3

[44] 赵世豪(Shihao Zhao)、陈冬冬(Dongdong Chen)、陈燕春(Yen-Chun Chen)、鲍建民(Jianmin Bao)、郝少哲(Shaozhe Hao)、袁璐(Lu Yuan)和关一·K·王(Kwan-Yee K. Wong)。Uni-controlnet:文本到图像扩散模型的一体化控制。发表于《神经信息处理系统大会论文集》(NeurIPS)，2023年。3

# Diffusion Self-Distillation for Zero-Shot Customized Image Generation

# 用于零样本定制图像生成的扩散自蒸馏

Supplementary Material

补充材料

## A. Data Pipeline Prompts

## A. 数据管道提示

In this section, we list out the detailed prompts used in our data generation (Sec. A.1), curation (Sec. A.2) and caption (Sec. A.3) pipelines.

在本节中，我们列出了数据生成(A.1节)、整理(A.2节)和字幕(A.3节)管道中使用的详细提示。

### A.1. Data Generation Prompts

### A.1. 数据生成提示

To generate grid prompts, we employ GPT-4o as our language model (LLM) engine We instruct the LLM to focus on specific aspects during the grid generation process: preserving the identity of the subject, providing detailed content within each grid quadrant, and maintaining appropriate text length. However, we observed that not all sampled reference captions inherently include a clear instance suitable for identity preservation. To address this issue, we introduce an initial filtering stage to ensure that each sampled reference caption contains an identity-preserving target. This filtering enhances the quality and consistency of the generated grids.

为了生成网格提示，我们采用GPT - 4o作为我们的大语言模型(LLM)引擎。我们指示大语言模型在网格生成过程中关注特定方面:保留主体的身份信息，在每个网格象限内提供详细内容，并保持适当的文本长度。然而，我们观察到并非所有采样的参考说明文字都天然包含适合用于身份保留的明确实例。为了解决这个问题，我们引入了一个初始过滤阶段，以确保每个采样的参考说明文字都包含一个可用于身份保留的目标。这种过滤提高了生成网格的质量和一致性。

![0195d6ef-e939-7abd-9b6d-dae30f972af7_10_166_1010_702_474_0.jpg](images/0195d6ef-e939-7abd-9b6d-dae30f972af7_10_166_1010_702_474_0.jpg)

### A.2. Data Curation Prompts

### A.2. 数据整理提示

For data curation, we employ Gemini-1.5. To guide the vision-language model (VLM) in focusing on identity preservation, we utilize Chain-of-Thought (CoT) prompting [38]. Specifically, we first instruct the VLM to identify the common object or character present in both images. Next, we prompt it to describe each one in detail. Finally, we ask the VLM to analyze whether they are identical and to provide a conclusive response. We find that this CoT prompting significantly enhances the model's ability to concentrate on the identity and intricate details of the target object or character.

对于数据整理，我们采用Gemini - 1.5。为了引导视觉 - 语言模型(VLM)关注身份保留，我们利用思维链(CoT)提示法[38]。具体来说，我们首先指示视觉 - 语言模型识别两幅图像中共同存在的物体或角色。接下来，我们提示它详细描述每个物体或角色。最后，我们要求视觉 - 语言模型分析它们是否相同并给出明确的回应。我们发现这种思维链提示法显著增强了模型关注目标物体或角色的身份和复杂细节的能力。

![0195d6ef-e939-7abd-9b6d-dae30f972af7_10_926_347_702_472_0.jpg](images/0195d6ef-e939-7abd-9b6d-dae30f972af7_10_926_347_702_472_0.jpg)

### A.3. Image Caption Prompts

### A.3. 图像说明提示

We provide two methods for prompting our model: using the description of the expected output (Target Description) or InstructPix2Pix [2]-type instructions (Instruction).

我们为模型提示提供了两种方法:使用预期输出的描述(目标描述)或InstructPix2Pix [2]类型的指令(指令)。

![0195d6ef-e939-7abd-9b6d-dae30f972af7_10_929_1073_702_425_0.jpg](images/0195d6ef-e939-7abd-9b6d-dae30f972af7_10_929_1073_702_425_0.jpg)

### B.GPT Evaluation Prompts

### B. GPT评估提示

We closely follow DreamBench++ [25] in terms of our GPT evaluation. In Fig. 7, we demonstrate the prompts we use for evaluation, including our "de-biased" evaluation that penalizes "copy-pasting" effect.

在GPT评估方面，我们严格遵循DreamBench++ [25]。在图7中，我们展示了用于评估的提示，包括我们的“去偏”评估，该评估会对“复制粘贴”效应进行惩罚。

## C. Additional Results

## C. 额外结果

### C.1. Additional Qualitative Comparisons

### C.1. 额外的定性比较

In Fig. 8, we demonstrate more of the qualitative evaluation cases from the DreamBench++ [25] benchmark.

在图8中，我们展示了更多来自DreamBench++ [25]基准测试的定性评估案例。

### C.2. Additional Qualitative Results

### C.2. 额外的定性结果

Due to space constraints in the main paper, we presented shortened prompts. Here, we provide additional qualitative results in Fig. 9, Fig. 10, Fig. 11, Fig. 12, Fig. 13 and Fig. 14, including the full prompts used for their generation. These detailed captions capture various aspects of the images and offer deeper insights into how our model operates.

由于主论文篇幅有限，我们展示了缩短后的提示。在这里，我们在图9、图10、图11、图12、图13和图14中提供了额外的定性结果，包括用于生成这些结果的完整提示。这些详细的说明文字捕捉了图像的各个方面，并为我们的模型如何运行提供了更深入的见解。

![0195d6ef-e939-7abd-9b6d-dae30f972af7_11_175_221_1460_1452_0.jpg](images/0195d6ef-e939-7abd-9b6d-dae30f972af7_11_175_221_1460_1452_0.jpg)

Figure 7. GPT evaluation prompts used across our evaluation, where the left shows the vanilla prompts from DreamBench++ [25] and the right shows our modified "de-biased" prompts, which strongly penalizes "copy-pasting" effects without sufficient creative inputs. We highlight our modified sentences in red.

图7. 我们在评估中使用的GPT评估提示，左侧显示的是来自DreamBench++ [25]的原始提示，右侧显示的是我们修改后的“去偏”提示，该提示会对缺乏足够创意输入的“复制粘贴”效应进行严厉惩罚。我们用红色突出显示了我们修改的句子。

### C.3. Story Telling

### C.3. 故事讲述

Our model exhibits the capability to generate simple comics and manga narratives, as demonstrated in Fig. 15 and Fig. 16, where the conditioning image acts as the first panel. To create these storytelling sequences, we input the initial panel into GPT-4o, which generates a series of prompts centered around the main character from the input image. These prompts are crafted to form a coherent story spanning 8-10 panels, with each prompt being contextually meaningful on its own. Utilizing these prompts alongside the conditioning image, we generate the subsequent panels and finally align them to reconstruct a cohesive narrative.

如图15和图16所示，我们的模型具备生成简单漫画和日本漫画叙事的能力，其中条件图像作为第一格。为了创建这些故事讲述序列，我们将初始格输入到GPT - 4o中，它会围绕输入图像中的主角生成一系列提示。这些提示旨在形成一个连贯的故事，涵盖8 - 10格，每个提示本身在上下文上都有意义。利用这些提示和条件图像，我们生成后续的格子，最后将它们对齐以重构一个连贯的叙事。

![0195d6ef-e939-7abd-9b6d-dae30f972af7_12_165_372_709_484_0.jpg](images/0195d6ef-e939-7abd-9b6d-dae30f972af7_12_165_372_709_484_0.jpg)

## D. Discussion on Scalability

## D. 可扩展性讨论

We acknowledge that the scalability of Diffusion Self-Distillation is not fully explored within the scope of this paper. However, we posit that Diffusion Self-Distillation is inherently scalable along three key dimensions. First, Diffusion Self-Distillation can scale with advancements in the teacher model's grid generation capabilities and its in-context understanding of identity preservation. Second, the scalability extends to the range of tasks we leverage; while this paper focuses on general adaptation tasks, a broader spectrum of applications remains open for exploration. Third, Diffusion Self-Distillation scales with the extent to which we harness foundation models. Increased diversity and more meticulously curated data contribute to improved generalization of our model. As foundation models-including base text-to-image generation models, language models (LLMs), and vision-language models (VLMs)—continue to evolve, Diffusion Self-Distillation naturally benefits from these advancements without necessitating any modifications to the existing workflow. A direct next step involves scaling the method to incorporate a significantly larger dataset and integrating forthcoming, more advanced foundation models.

我们承认，在本文的范围内，扩散自蒸馏(Diffusion Self-Distillation)的可扩展性尚未得到充分探索。然而，我们认为扩散自蒸馏在三个关键维度上具有内在的可扩展性。首先，扩散自蒸馏可随着教师模型的网格生成能力及其对身份保留的上下文理解的提升而扩展。其次，可扩展性延伸到我们所利用的任务范围；虽然本文侧重于通用适配任务，但更广泛的应用领域仍有待探索。第三，扩散自蒸馏可随着我们对基础模型的利用程度而扩展。数据多样性的增加和更精心策划的数据有助于提高我们模型的泛化能力。随着基础模型(包括基础文本到图像生成模型、大语言模型(LLMs)和视觉语言模型(VLMs))不断发展，扩散自蒸馏自然会从这些进步中受益，而无需对现有工作流程进行任何修改。直接的下一步是扩展该方法，以纳入更大的数据集并集成即将推出的更先进的基础模型。

![0195d6ef-e939-7abd-9b6d-dae30f972af7_13_158_294_1477_1620_0.jpg](images/0195d6ef-e939-7abd-9b6d-dae30f972af7_13_158_294_1477_1620_0.jpg)

Figure 8. Additional qualitative comparison.

图 8. 额外的定性比较。

![0195d6ef-e939-7abd-9b6d-dae30f972af7_14_156_278_1483_1660_0.jpg](images/0195d6ef-e939-7abd-9b6d-dae30f972af7_14_156_278_1483_1660_0.jpg)

Figure 9. Additional character identity preserving results.

图 9. 额外的角色身份保留结果。

![0195d6ef-e939-7abd-9b6d-dae30f972af7_15_159_281_1475_1651_0.jpg](images/0195d6ef-e939-7abd-9b6d-dae30f972af7_15_159_281_1475_1651_0.jpg)

Figure 10. Additional character identity preserving results.

图 10. 额外的角色身份保留结果。

![0195d6ef-e939-7abd-9b6d-dae30f972af7_16_161_297_1473_1625_0.jpg](images/0195d6ef-e939-7abd-9b6d-dae30f972af7_16_161_297_1473_1625_0.jpg)

Figure 11. Additional object/item identity preserving results.

图 11. 额外的物体/物品身份保留结果。

![0195d6ef-e939-7abd-9b6d-dae30f972af7_17_158_302_1478_1612_0.jpg](images/0195d6ef-e939-7abd-9b6d-dae30f972af7_17_158_302_1478_1612_0.jpg)

Figure 12. Additional object/item identity preserving results.

图 12. 额外的物体/物品身份保留结果。

![0195d6ef-e939-7abd-9b6d-dae30f972af7_18_163_423_1468_1376_0.jpg](images/0195d6ef-e939-7abd-9b6d-dae30f972af7_18_163_423_1468_1376_0.jpg)

Figure 13. Additional instruction prompting results.

图 13. 额外的指令提示结果。

![0195d6ef-e939-7abd-9b6d-dae30f972af7_19_165_458_1463_1302_0.jpg](images/0195d6ef-e939-7abd-9b6d-dae30f972af7_19_165_458_1463_1302_0.jpg)

Figure 14. Additional relighting results.

图 14. 额外的重新照明结果。

![0195d6ef-e939-7abd-9b6d-dae30f972af7_20_186_203_473_415_0.jpg](images/0195d6ef-e939-7abd-9b6d-dae30f972af7_20_186_203_473_415_0.jpg)

In a room dimly lit by a single lamp, a serious man in a dark suit sat at a wooden table, reading an old book intently. Framed portraits adorned the green walls, and shadows shifted subtly under the soft, directional lighting. The man's expression was deeply focused, as if the secrets of the universe lay within the pages.

在一盏孤灯昏暗的光线下，一个身着深色西装的严肃男子坐在木桌旁，专注地读着一本旧书。绿色的墙壁上挂着镶框的肖像，柔和的定向灯光下，影子在微微移动。男子的神情极为专注，仿佛宇宙的奥秘就藏在书页之中。

![0195d6ef-e939-7abd-9b6d-dae30f972af7_20_679_205_460_413_0.jpg](images/0195d6ef-e939-7abd-9b6d-dae30f972af7_20_679_205_460_413_0.jpg)

Suddenly, he realized something, his intense gaze locked onto a passage he had just read. The warm lamplight threw his shadow across the room, making it loom large against the walls and highlighting his furrowed brow. Something he had discovered in the book seemed urgent-almost alarming.

突然，他意识到了什么，锐利的目光锁定在刚刚读过的一段文字上。温暖的灯光将他的影子投射在房间里，影子在墙壁上显得格外巨大，凸显出他紧皱的眉头。他在书中发现的某些东西似乎很紧急——几乎令人警觉。

![0195d6ef-e939-7abd-9b6d-dae30f972af7_20_1177_203_448_416_0.jpg](images/0195d6ef-e939-7abd-9b6d-dae30f972af7_20_1177_203_448_416_0.jpg)

He leaned forward over the table, urgently flipping through the pages. His hands trembled slightly, and the golden light from the lamp illuminated his tense features, deepening the lines of concentration etched into his face. Whatever he sought, he was desperate to find it.

他探身向前，急切地翻动着书页。他的手微微颤抖，灯光的金色光芒照亮了他紧绷的面容，加深了他脸上专注的皱纹。无论他在寻找什么，他都不顾一切地想要找到它。

![0195d6ef-e939-7abd-9b6d-dae30f972af7_20_175_819_483_415_0.jpg](images/0195d6ef-e939-7abd-9b6d-dae30f972af7_20_175_819_483_415_0.jpg)

Raising his head, the man's eyes fixed on the wall of portraits. Holding the old book open in one hand, he approached the paintings, his eyes narrowing with focus. The faces in the frames seemed to stare back at him, and he scanned each one carefully, as if hoping to find something-some connection-that only he

男子抬起头，目光落在挂满肖像的墙上。他一只手拿着翻开的旧书，朝那些画作走去，眼睛眯成一条缝，全神贯注。画框里的面孔似乎在回望着他，他仔细地扫视着每一幅画，仿佛希望找到某种只有他

could see.

能看到的联系。

![0195d6ef-e939-7abd-9b6d-dae30f972af7_20_671_821_469_412_0.jpg](images/0195d6ef-e939-7abd-9b6d-dae30f972af7_20_671_821_469_412_0.jpg)

With a sense of determination, he reached out to touch a specific portrait, the old book tucked under his arm. His fingers lightly brushed the frame, and his expression grew thoughtful, curious. The soft light emphasized his focused gaze, as if the touch itself might reveal a hidden truth.

他带着坚定的神情，伸出手去触摸一幅特定的肖像，旧书夹在腋下。他的手指轻轻拂过画框，表情变得若有所思，充满好奇。柔和的灯光凸显出他专注的目光，仿佛触摸本身就能揭示一个隐藏的真相。

![0195d6ef-e939-7abd-9b6d-dae30f972af7_20_1153_821_471_412_0.jpg](images/0195d6ef-e939-7abd-9b6d-dae30f972af7_20_1153_821_471_412_0.jpg)

Just then, a creaking sound broke the silence. A hidden door began to open in the wall, and the man stepped back in shock, his eyes wide. The old book clutched in his hands, he stared at the widening gap, where light from a secret passage spilled into the room, creating eerie, shifting shadows.

就在这时，一阵嘎吱声打破了寂静。墙上一扇隐藏的门开始打开，男子震惊地往后退了一步，眼睛睁得大大的。他紧紧抓着手中的旧书，盯着逐渐扩大的缝隙，从秘密通道透进来的光线洒进房间，形成了诡异、摇曳的影子。

![0195d6ef-e939-7abd-9b6d-dae30f972af7_20_161_1454_1468_600_0.jpg](images/0195d6ef-e939-7abd-9b6d-dae30f972af7_20_161_1454_1468_600_0.jpg)

Figure 15. Comic generation example 1. The conditioned image is the first panel.

图15. 漫画生成示例1。条件图像为第一格漫画。

![0195d6ef-e939-7abd-9b6d-dae30f972af7_21_191_206_473_414_0.jpg](images/0195d6ef-e939-7abd-9b6d-dae30f972af7_21_191_206_473_414_0.jpg)

In a room filled with vibrant colors and energy, a focused man with a shaved head and a gold chain sat at a table. He was deeply engrossed in drawing on a sheet of paper, his pencil moving with purpose, while warm light spilled over graffiti-like murals painted on the walls around him. His expression was determined, as if every line he sketched carried deep meaning.

在一个色彩斑斓、充满活力的房间里，一个剃着光头、戴着金链子的专注男子坐在桌前。他全神贯注地在一张纸上作画，铅笔有目的地移动着，温暖的光线洒在他周围墙壁上类似涂鸦的壁画上。他神情坚定，仿佛每一笔勾勒都蕴含着深刻的意义。

![0195d6ef-e939-7abd-9b6d-dae30f972af7_21_723_205_424_411_0.jpg](images/0195d6ef-e939-7abd-9b6d-dae30f972af7_21_723_205_424_411_0.jpg)

After a moment, he held up his sketchpad in his hands. His eyes scanned the drawings he had created, and a look of resolve crossed his face. The colorful murals behind him seemed to mirror the intensity in his gaze, the warm lighting accentuating the passion that had sparked within him.

过了一会儿，他双手举起素描本。他的目光扫视着自己创作的画作，脸上闪过一丝坚定。他身后色彩鲜艳的壁画似乎映照出他目光中的专注，温暖的灯光凸显出他内心燃起的激情。

![0195d6ef-e939-7abd-9b6d-dae30f972af7_21_1208_203_414_415_0.jpg](images/0195d6ef-e939-7abd-9b6d-dae30f972af7_21_1208_203_414_415_0.jpg)

Suddenly inspired, he approached one of the large murals. He began to draw directly onto the wall. His movements were precise and intentional, as colors and patterns flowed from his imagination to the surface. The warm light bathed his intense expression, as if illuminating the raw energy of his creativity.

突然灵感涌现，他走向其中一幅大型壁画，开始直接在墙上作画。他的动作精准而有意图，色彩和图案从他的想象中流淌到墙面上。温暖的灯光笼罩着他专注的神情，仿佛照亮了他创造力的原始能量。

![0195d6ef-e939-7abd-9b6d-dae30f972af7_21_177_822_487_411_0.jpg](images/0195d6ef-e939-7abd-9b6d-dae30f972af7_21_177_822_487_411_0.jpg)

When he was finished, he stepped back to admire his work, arms crossed over his chest. The mural was alive with vivid, swirling graffiti, and his face lit up with pride. The warm light

画完后，他双臂交叉抱在胸前，往后退了几步欣赏自己的作品。壁画上满是生动、回旋的涂鸦，他的脸上洋溢着自豪的神情。温暖的灯光

glowed over the artwork, and for a moment, he stood there, content, knowing he had given life to his vision.

洒在这幅艺术作品上，有那么一刻，他心满意足地站在那里，知道自己让心中的愿景变成了现实。

![0195d6ef-e939-7abd-9b6d-dae30f972af7_21_725_821_415_412_0.jpg](images/0195d6ef-e939-7abd-9b6d-dae30f972af7_21_725_821_415_412_0.jpg)

But he was not done yet. He returned to the table, sketchpad in hand, and began drawing again. His pencil moved even faster now, capturing new ideas that poured into his mind. The room was a swirl of vibrant murals and soft, warm shadows, the energy of creation pulsing through the space.

但他还没画完。他回到桌旁，手里拿着素描本，又开始画了起来。此刻他的铅笔移动得更快了，捕捉着涌入他脑海的新想法。房间里满是色彩鲜艳的壁画和柔和温暖的阴影，创作的活力在这个空间中涌动。

![0195d6ef-e939-7abd-9b6d-dae30f972af7_21_1166_819_456_415_0.jpg](images/0195d6ef-e939-7abd-9b6d-dae30f972af7_21_1166_819_456_415_0.jpg)

Suddenly, he turned his head slightly, as a noise from outside broke his concentration. He set down his pencil, his expression one of curiosity and intrigue. The warm light reflected off his dark jacket, and the graffiti walls behind him seemed to whisper with a story yet to be discovered.

突然，他微微转过头，外面的一声响动打断了他的专注。他放下铅笔，脸上露出好奇和兴致勃勃的神情。温暖的灯光从他深色的夹克上反射出来，他身后的涂鸦墙似乎在低语着一个尚未被发现的故事。

![0195d6ef-e939-7abd-9b6d-dae30f972af7_21_170_1454_1461_597_0.jpg](images/0195d6ef-e939-7abd-9b6d-dae30f972af7_21_170_1454_1461_597_0.jpg)

Figure 16. Comic generation example 2. The conditioned image is the first panel.

图16. 漫画生成示例2。条件图像是第一格。