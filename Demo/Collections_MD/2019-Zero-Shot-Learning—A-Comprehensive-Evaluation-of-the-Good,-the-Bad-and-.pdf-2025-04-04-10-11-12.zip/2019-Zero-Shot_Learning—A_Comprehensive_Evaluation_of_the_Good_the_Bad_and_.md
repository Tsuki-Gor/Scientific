# Zero-Shot Learning—A Comprehensive Evaluation of the Good, the Bad and the Ugly

# 零样本学习——对优点、缺点和不足的全面评估

Yongqin Xian ${}^{\circledR }$ , Student Member, IEEE, Christoph H. Lampert, Bernt Schiele, Fellow, IEEE, and Zeynep Akata, Member, IEEE

冼永钦 ${}^{\circledR }$ ，IEEE学生会员，克里斯托夫·H·兰佩特，伯恩特·席勒，IEEE会士，泽内普·阿卡塔，IEEE会员

Abstract-Due to the importance of zero-shot learning, i.e., classifying images where there is a lack of labeled training data, the number of proposed approaches has recently increased steadily. We argue that it is time to take a step back and to analyze the status quo of the area. The purpose of this paper is three-fold. First, given the fact that there is no agreed upon zero-shot learning benchmark we first define a new benchmark by unifying both the evaluation protocols and data splits of publicly available datasets used for this task. This is an important contribution as published results are often not comparable and sometimes even flawed due to, e.g., pre-training on zero-shot test classes. Moreover, we propose a new zero-shot learning dataset, the Animals with Attributes 2 (AWA2 dataset which we make publicly available both in terms of image features and the images themselves. Second, we compare and analyze a significant number of the state-of-the-art methods in depth, both in the classic zero-shot setting but also in the more realistic generalized zero-shot setting. Finally, we discuss in detail the limitations of the current status of the area which can be taken as a basis for advancing it.

摘要——由于零样本学习(即对缺乏标注训练数据的图像进行分类)的重要性，最近提出的方法数量稳步增加。我们认为现在是时候退一步，分析该领域的现状了。本文的目的有三个方面。首先，鉴于目前没有公认的零样本学习基准，我们首先通过统一用于此任务的公开可用数据集的评估协议和数据划分来定义一个新的基准。这是一项重要贡献，因为已发表的结果往往不可比，有时甚至存在缺陷，例如在零样本测试类上进行预训练。此外，我们提出了一个新的零样本学习数据集，即动物属性2(AWA2)数据集，我们将其图像特征和图像本身都公开提供。其次，我们深入比较和分析了大量的先进方法，既在经典的零样本设置下，也在更现实的广义零样本设置下。最后，我们详细讨论了该领域当前现状的局限性，这些局限性可作为推动其发展的基础。

Index Terms-Generalized zero-shot learning, transductive learning, image classification, weakly-supervised learning

关键词——广义零样本学习、直推式学习、图像分类、弱监督学习

## 1 INTRODUCTION

## 1 引言

Z'ERO-SHOT learning aims to recognize objects whose instances may not have been seen during training [1], [2], [3], [4], [5], [6]. The number of new zero-shot learning methods proposed every year has been increasing rapidly, i.e., the good aspects as our title suggests. Although each new method has been shown to make progress over the previous one, it is difficult to quantify this progress without an established evaluation protocol, i.e., the bad aspects. In fact, the quest for improving numbers has lead to even flawed evaluation protocols, i.e., the ugly aspects. Therefore, in this work, we propose to extensively evaluate a significant number of recent zero-shot learning methods in depth on several small to large-scale datasets using the same evaluation protocol both in zero-shot, i.e., training and test classes are disjoint, and the more realistic generalized zero-shot learning settings, i.e., training classes are present at test time. Fig. 1 presents an illustration of zero-shot and generalized zero-shot learning tasks.

零样本学习旨在识别在训练期间可能未见过实例的对象 [1]、[2]、[3]、[4]、[5]、[6]。每年提出的新零样本学习方法的数量一直在迅速增加，即正如我们标题所暗示的优点方面。尽管每种新方法都被证明比前一种方法有进步，但如果没有既定的评估协议，就很难量化这种进步，即缺点方面。事实上，对提高指标的追求甚至导致了有缺陷的评估协议，即不足方面。因此，在这项工作中，我们建议使用相同的评估协议，在几个从小规模到大规模的数据集上，对大量近期的零样本学习方法进行深入的广泛评估，既在零样本(即训练类和测试类不相交)设置下，也在更现实的广义零样本学习设置(即测试时存在训练类)下。图1展示了零样本和广义零样本学习任务的示意图。

We benchmark and systematically evaluate zero-shot learning w.r.t. three aspects, i.e., methods, datasets and evaluation protocol. The crux of the matter for all zero-shot learning methods is to associate observed and non observed classes through some form of auxiliary information which encodes visually distinguishing properties of objects. Different flavors of zero-shot learning methods that we evaluate in this work are linear [7], [8], [9], [10] and nonlinear [11], [12] compatibility learning frameworks which have dominated the zero-shot learning literature in the past few years whereas an orthogonal direction is learning independent attribute [1] classifiers and finally others [13], [14], [15] propose a hybrid model between independent classifier learning and compatibility learning frameworks which have demonstrated improved results over the compatibility learning frameworks both for zero-shot and generalized zero-shot learning settings.

我们从三个方面对零样本学习进行基准测试和系统评估，即方法、数据集和评估协议。所有零样本学习方法的关键在于通过某种形式的辅助信息将观察到的类和未观察到的类关联起来，这种辅助信息编码了对象的视觉区分属性。我们在这项工作中评估的不同类型的零样本学习方法包括线性 [7]、[8]、[9]、[10] 和非线性 [11]、[12] 兼容性学习框架，这些框架在过去几年中主导了零样本学习文献，而另一个正交方向是学习独立属性 [1] 分类器，最后，其他 [13]、[14]、[15] 方法提出了独立分类器学习和兼容性学习框架之间的混合模型，该模型在零样本和广义零样本学习设置下都比兼容性学习框架取得了更好的结果。

We thoroughly evaluate the second aspect of zero-shot learning, by using multiple splits of several small, medium and large-scale datasets [1], [16], [17], [18], [19]. Among these, the Animals with Attributes (AWA1) dataset [1] introduced as a zero-shot learning dataset with per-class attribute annotations, has been one of the most widely used datasets for zero-shot learning. However, as AWA1 images does not have the public copyright license, only some image features, i.e., SIFT [20], DECAF [21], VGG19 [22] of AWA1 dataset is publicly available, rather than the raw images. On the other hand, improving image features is a significant part of the progress both for supervised learning and for zero-shot learning. In fact, with the fast pace of deep learning, everyday new deep neural network models improve the ImageNet classification performance are being proposed. Without access to images, those new DNN models can not be evaluated on AWA1 dataset. Therefore, with this work, we introduce the Animals with Attributes 2 (AWA2) dataset that has roughly the same number of images all with public licenses, exactly the same number of classes and attributes as the AWA1 dataset. We will make both ResNet [23] features of AWA2 images and the images themselves publicly available.

我们通过使用几个小规模、中等规模和大规模数据集的多个划分 [1]、[16]、[17]、[18]、[19]，彻底评估了零样本学习的第二个方面。其中，动物属性(AWA1)数据集 [1] 作为一个带有每类属性注释的零样本学习数据集被引入，是零样本学习中使用最广泛的数据集之一。然而，由于AWA1图像没有公开版权许可，AWA1数据集只有一些图像特征，即SIFT [20]、DECAF [21]、VGG19 [22] 是公开可用的，而不是原始图像。另一方面，改进图像特征是监督学习和零样本学习进展的重要组成部分。事实上，随着深度学习的快速发展，每天都有新的深度神经网络模型被提出以提高ImageNet分类性能。如果无法访问图像，那些新的深度神经网络模型就无法在AWA1数据集上进行评估。因此，在这项工作中，我们引入了动物属性2(AWA2)数据集，该数据集的图像数量大致相同，所有图像都有公开许可，类和属性的数量与AWA1数据集完全相同。我们将公开提供AWA2图像的ResNet [23] 特征和图像本身。

---

- Y. Xian and B. Schiele are with the Max Planck Institute for Informatics, Saarbrücken 66123, Germany. E-mail: \{yxian, schiele\}@mpi-inf.mpg.de.

- 冼永勤(Y. Xian)和贝恩德·席勒(B. Schiele)就职于德国萨尔布吕肯66123的马克斯·普朗克信息研究所。电子邮件:\{yxian, schiele\}@mpi-inf.mpg.de。

- C. H. Lampert is with the Institute of Science and Technology Austria (IST), Klosterneuburg 3400, Austria. E-mail: chl@ist.ac.at.

- 克里斯托夫·H·兰佩特(C. H. Lampert)就职于奥地利克洛斯特新堡3400的奥地利科技学院(IST)。电子邮件:chl@ist.ac.at。

- Z. Akata is with the University of Amsterdam, Amsterdam 1012, WX, Netherlands, and with the Max Planck Institute for Informatics, Saarbrücken 66123, Germany. E-mail: akata@mpi-inf.mpg.de.

- 兹内普·阿卡塔(Z. Akata)就职于荷兰阿姆斯特丹1012 WX的阿姆斯特丹大学，同时也就职于德国萨尔布吕肯66123的马克斯·普朗克信息研究所。电子邮件:akata@mpi-inf.mpg.de。

Manuscript received 3 July 2017; revised 6 Apr. 2018; accepted 10 July 2018. Date of publication 18 July 2018; date of current version 13 Aug. 2019. (Corresponding author: Yongqin Xian.) Recommended for acceptance by S. Dickinson.

稿件于2017年7月3日收到；2018年4月6日修订；2018年7月10日接受。出版日期为2018年7月18日；当前版本日期为2019年8月13日。(通信作者:冼永勤(Yongqin Xian))。由S. 迪金森推荐接受。

For information on obtaining reprints of this article, please send e-mail to: reprints@ieee.org, and reference the Digital Object Identifier below.

如需获取本文的重印本信息，请发送电子邮件至:reprints@ieee.org，并参考下面的数字对象标识符。

Digital Object Identifier no. 10.1109/TPAMI.2018.2857768

数字对象标识符编号:10.1109/TPAMI.2018.2857768

---

![0195d2b1-719e-720b-bdb3-2e8d7e8c28b6_1_72_122_767_361_0.jpg](images/0195d2b1-719e-720b-bdb3-2e8d7e8c28b6_1_72_122_767_361_0.jpg)

Fig. 1. Zero-shot learning (ZSL) versus generalized zero-shot learning (GZSL): At training time, for both cases the images and attributes of the seen classes $\left( {\mathcal{Y}}^{tr}\right)$ are available. At test time, in the ZSL setting, the learned model is evaluated only on unseen classes $\left( {\mathcal{Y}}^{ts}\right)$ whereas in GZSL setting, the search space contains both training and test classes $\left( {{\mathcal{Y}}^{tr} \cup  {\mathcal{Y}}^{ts}}\right)$ . To facilitate classification without labels, both tasks use some form of side information, e.g., attributes. The attributes are annotated per class, therefore the labeling cost is significantly reduced.

图1. 零样本学习(ZSL)与广义零样本学习(GZSL):在训练阶段，两种情况下都可获取已见类别 $\left( {\mathcal{Y}}^{tr}\right)$ 的图像和属性。在测试阶段，在零样本学习设置中，仅在未见类别 $\left( {\mathcal{Y}}^{ts}\right)$ 上评估所学模型，而在广义零样本学习设置中，搜索空间包含训练类别和测试类别 $\left( {{\mathcal{Y}}^{tr} \cup  {\mathcal{Y}}^{ts}}\right)$ 。为便于无标签分类，两项任务都使用某种形式的辅助信息，例如属性。属性是按类别标注的，因此标注成本显著降低。

We propose a unified evaluation protocol to address the third aspect of zero-shot learning which is one of the most important ones. We emphasize the necessity of tuning hyperparameters of the methods on a validation class split that is disjoint from training classes as improving zero-shot learning performance via tuning parameters on test classes violates the zero-shot assumption. We argue that per-class averaged top-1 accuracy is an important evaluation metric when the dataset is not well balanced with respect to the number of images per class. We point out that extracting image features via a pre-trained deep neural network (DNN) on a large dataset that contains zero-shot test classes also violates the zero-shot learning idea as image feature extraction is a part of the training procedure. Moreover, we argue that demonstrating zero-shot performance on small-scale and coarse grained datasets, i.e., aPY [18] is not conclusive. On the other hand, with this work we emphasize that it is hard to obtain labeled training data for fine-grained classes of rare objects recognizing which requires expert opinion. Therefore, we argue that zero-shot learning methods should be also evaluated on least populated or rare classes. We recommend to abstract away from the restricted nature of zero-shot evaluation and make the task more practical by including training classes in the search space, i.e., generalized zero-shot learning setting. Therefore, we argue that our work plays an important role in advancing the zero-shot learning field by analyzing the good and bad aspects of the zero-shot learning task as well as proposing ways to eliminate the ugly ones.

我们提出了一个统一的评估协议来解决零样本学习的第三个方面，这是最重要的方面之一。我们强调在与训练类别不相交的验证类别划分上调整方法的超参数的必要性，因为通过在测试类别上调整参数来提高零样本学习性能违反了零样本假设。我们认为，当数据集在每个类别的图像数量方面不平衡时，按类别平均的top - 1准确率是一个重要的评估指标。我们指出，通过在包含零样本测试类别的大型数据集上预训练的深度神经网络(DNN)提取图像特征也违反了零样本学习的理念，因为图像特征提取是训练过程的一部分。此外，我们认为在小规模和粗粒度数据集(如aPY [18])上展示零样本性能并不具有决定性。另一方面，通过这项工作，我们强调很难为需要专家意见才能识别的稀有对象的细粒度类别获取带标签的训练数据。因此，我们认为零样本学习方法也应该在样本最少或稀有的类别上进行评估。我们建议摆脱零样本评估的局限性，通过在搜索空间中包含训练类别，即广义零样本学习设置，使任务更具实用性。因此，我们认为我们的工作通过分析零样本学习任务的优缺点，并提出消除缺点的方法，在推动零样本学习领域的发展中发挥了重要作用。

## 2 RELATED WORK

## 2 相关工作

Early works of zero-shot learning [1], [15], [24], [25], [26] make use of the attributes within a two-stage approach to infer the label of an image that belong to one of the unseen classes. In the most general sense, the attributes of an input image are predicted in the first stage, then its class label is inferred by searching the class which attains the most similar set of attributes. For instance, DAP [1] first estimates the Authorized licensed use limited to: JILIN UNIVERSITY. Downloaded on March 26,2025 at 13:28:11 UTC from IEEE Xplore. Restrictions apply. posterior of each attribute for an image by learning probabilistic attribute classifiers. It then calculates the class posteriors and predicts the class label using MAP estimate. Similarly, [24] first learns a probabilistic classifier for each attribute. It then estimates the class posteriors through random forest which is able to handle unreliable attributes. IAP [1] first predicts the class posterior of seen classes, then the probability of each class is used to calculate the attribute posteriors of an image. The class posterior of seen classes is predicted by a multi-class classifier. In addition, this two-stage approach have been extended to the case when attributes are not available. For example, following IAP [1], CONSE [15] first predicts seen class posteriors, then it projects image feature into the Word2vec [27] space by taking the convex combination of top $T$ most possible seen classes. The two-stage models suffer from domain shift [28] between the intermediate task and target task, e.g., although the target task is to predict the class label, the intermediate task of DAP is to learn attribute classifiers.

零样本学习的早期工作[1]、[15]、[24]、[25]、[26]采用两阶段方法，利用属性来推断属于未见类别之一的图像标签。一般来说，第一阶段预测输入图像的属性，然后通过搜索具有最相似属性集的类别来推断其类别标签。例如，属性判别投影(Discriminative Attribute Prediction，DAP)[1]首先通过学习概率属性分类器来估计图像每个属性的后验概率。然后计算类别后验概率，并使用最大后验(Maximum A Posteriori，MAP)估计来预测类别标签。同样，文献[24]首先为每个属性学习一个概率分类器。然后通过能够处理不可靠属性的随机森林来估计类别后验概率。属性推断投影(Inferred Attribute Prediction，IAP)[1]首先预测可见类别的类别后验概率，然后使用每个类别的概率来计算图像的属性后验概率。可见类别的类别后验概率由多类别分类器预测。此外，这种两阶段方法已扩展到属性不可用的情况。例如，遵循IAP [1]的方法，基于上下文的语义嵌入(Contextual Semantic Embedding，CONSE)[15]首先预测可见类别的后验概率，然后通过对前$T$个最可能的可见类别进行凸组合，将图像特征投影到词向量(Word2vec)[27]空间中。两阶段模型存在中间任务和目标任务之间的领域偏移[28]问题，例如，虽然目标任务是预测类别标签，但DAP的中间任务是学习属性分类器。

Recent advances in zero-shot learning directly learns a mapping from an image feature space to a semantic space. Among those, SOC [29] maps the image features into the semantic space and then searches the nearest class embedding vector. ALE [30] learns a bilinear compatibility function between the image and the attribute space using ranking loss. DeViSE [7] also learns a linear mapping between image and semantic space using an efficient ranking loss formulation, and it is evaluated on the large-scale ImageNet dataset. SJE [9] optimizes the structural SVM loss to learn the bilinear compatibility. On the other hand, ESZSL [10] uses the square loss to learn the bilinear compatibility and explicitly regularizes the objective w.r.t Frobenius norm. The ${l}_{2,1}$ -based objective function of [31] suppresses the noise in the semantic space. [32] embeds visual features into the attribute space, and then learns a metric to improve the consistency of the semantic embedding. Recently, SAE [33] proposed a semantic auto encoder to regularize the model by enforcing the image feature projected to the semantic space to be reconstructed.

零样本学习的最新进展是直接学习从图像特征空间到语义空间的映射。其中，语义输出分类器(Semantic Output Codes，SOC)[29]将图像特征映射到语义空间，然后搜索最近的类别嵌入向量。基于注意力的标签嵌入(Attention-based Label Embedding，ALE)[30]使用排序损失学习图像和属性空间之间的双线性兼容性函数。基于深度视觉语义嵌入(Deep Visual-Semantic Embedding，DeViSE)[7]也使用高效的排序损失公式学习图像和语义空间之间的线性映射，并在大规模的ImageNet数据集上进行评估。结构化联合嵌入(Structured Joint Embedding，SJE)[9]优化结构化支持向量机(Support Vector Machine，SVM)损失以学习双线性兼容性。另一方面，高效的零样本学习(Efficient Zero-Shot Learning，ESZSL)[10]使用平方损失学习双线性兼容性，并明确地对目标函数进行关于弗罗贝尼乌斯范数的正则化。文献[31]基于${l}_{2,1}$的目标函数抑制了语义空间中的噪声。文献[32]将视觉特征嵌入到属性空间中，然后学习一种度量来提高语义嵌入的一致性。最近，语义自编码器(Semantic Autoencoder，SAE)[33]提出了一种语义自编码器，通过强制将投影到语义空间的图像特征进行重构来对模型进行正则化。

Other zero-shot learning approaches learn non-linear multi-modal embeddings. LatEm [11] extends the bilinear compatibility model of SJE [9] to be a piecewise linear one by learning multiple linear mappings with the selection of which being a latent variable. CMT [12] uses a neural network with two hidden layers to learn a non-linear projection from image feature space to word2vec [27] space. Unlike other works which build their embedding on top of fixed image features, [34] trains a deep convolutional neural networks while learning a visual semantic embedding. Similarly, [35] argues that the visual feature space is more discriminative than the semantic space, thus it proposes an end-to-end deep embedding model which maps semantic features into the visual space. [36] proposes a simple model by projecting class semantic representations into the visual feature space and performing nearest neighbor classifiers among those projected representations. The projection is learned through support vector regressor with visual exemplars of seen classes, i.e., class centroid in the feature space.

其他零样本学习方法学习非线性多模态嵌入。潜在嵌入(Latent Embedding，LatEm)[11]通过学习多个线性映射(其选择为一个潜在变量)，将SJE [9]的双线性兼容性模型扩展为分段线性模型。跨模态转移(Cross-Modal Transfer，CMT)[12]使用具有两个隐藏层的神经网络来学习从图像特征空间到词向量(Word2vec)[27]空间的非线性投影。与其他基于固定图像特征构建嵌入的工作不同，文献[34]在学习视觉语义嵌入的同时训练深度卷积神经网络。同样，文献[35]认为视觉特征空间比语义空间更具判别性，因此提出了一种端到端的深度嵌入模型，将语义特征映射到视觉空间。文献[36]提出了一个简单的模型，将类别语义表示投影到视觉特征空间，并在这些投影表示中执行最近邻分类器。该投影通过使用可见类别的视觉样本(即特征空间中的类别质心)的支持向量回归器来学习。

Embedding both the image and semantic features into another common intermediate space is another direction that zero-shot learning approaches adapt. SSE [13] uses the mixture of seen class proportions as the common space and argues that images belong to the same class should have similar mixture pattern. JLSE [37] maps visual features and semantic features into two separate latent spaces, and measures their similarity by learning another bilinear compatibility function. Furthermore, hybrid models [14], [38], [39], [40] such as [39] jointly embeds multiple text representations and multiple visual parts to ground attributes on different image regions. SYNC [14] constructs the classifiers of unseen classes by taking the linear combinations of base classifiers, which are trained in a discriminative learning framework.

将图像和语义特征都嵌入到另一个公共中间空间是零样本学习方法采用的另一个方向。共享语义嵌入(Shared Semantic Embedding，SSE)[13]使用可见类别比例的混合作为公共空间，并认为属于同一类别的图像应该具有相似的混合模式。联合潜在语义嵌入(Joint Latent Semantic Embedding，JLSE)[37]将视觉特征和语义特征映射到两个单独的潜在空间，并通过学习另一个双线性兼容性函数来度量它们的相似性。此外，混合模型[14]、[38]、[39]、[40]，如文献[39]，将多个文本表示和多个视觉部分联合嵌入，以将属性定位到不同的图像区域。同步零样本学习(SYNchronized Zero-Shot Learning，SYNC)[14]通过对在判别学习框架中训练的基分类器进行线性组合来构建未见类别的分类器。

While most of zero-shot learning methods learn the cross-modal mapping between the image and class embedding space with discriminative losses, there are a few generative models [41], [42], [43] that represent each class as a probability distribution. GFZSL [41] models each class-conditional distribution as a Gaussian and learns a regression function that maps a class embedding into the latent space. GLaP [42] assumes that each class-conditional distribution follows a Gaussian and generates virtual instances of unseen classes from the learned distribution. [43] learns a multimodal mapping where class and image embeddings of categories are both represented by Gaussian distributions.

虽然大多数零样本学习方法通过判别损失来学习图像和类别嵌入空间之间的跨模态映射，但也有一些生成模型[41]、[42]、[43]将每个类别表示为一个概率分布。GFZSL[41]将每个类别条件分布建模为高斯分布，并学习一个回归函数，该函数将类别嵌入映射到潜在空间。GLaP[42]假设每个类别条件分布遵循高斯分布，并从学习到的分布中生成未见类别的虚拟实例。[43]学习一种多模态映射，其中类别的类别嵌入和图像嵌入都由高斯分布表示。

Apart from the inductive zero-shot learning set-up where the model has no access to neither visual nor side-information of unseen classes, transductive zero-shot learning approaches [28], [44], [45], [46], [47], [48], [49] use visual or semantic information of both seen and unseen classes without having access to the label information. [44] combines DAP and graph-based label propagation. [45] uses the idea of domain adaptation frameworks. [28] proposes hyper-graph label propagation which allows to use multiple class embeddings. [46], [47], [48] use semi-supervised learning based on max-margin framework.

除了归纳式零样本学习设置(在该设置中，模型无法获取未见类别的视觉信息或辅助信息)之外，直推式零样本学习方法[28]、[44]、[45]、[46]、[47]、[48]、[49]在不获取标签信息的情况下使用已见和未见类别的视觉或语义信息。[44]将DAP(判别式属性预测)和基于图的标签传播相结合。[45]采用了领域自适应框架的思想。[28]提出了超图标签传播方法，该方法允许使用多个类别嵌入。[46]、[47]、[48]使用基于最大间隔框架的半监督学习方法。

In zero-shot learning, some form of side information is required to share information between classes so that the knowledge learned from seen classes is transfered to unseen classes. One popular form of side information is attributes, i.e., shared and nameable visual properties of objects. However, attributes usually require costly manual annotation. Thus, there has been a large group of studies [7], [9], [11], [31], [34], [50], [51], [52], [53], [54] which exploit other auxiliary information that reduces this annotation effort. [55] does not use side information however it requires one-shot image of the novel class to perform nearest neighbor search with the learned metric. SJE [9] evaluates four different class embeddings including attributes, word2vec [27], glove [56] and wordnet hierarchy [57]. On ImageNet, [3] leverages the wordnet hierarchy. [52] leverages the rich information of detailed visual descriptions obtained from novice users and improves the performance of attributes obtained from experts. Recently, [58] took a different approach and learned class embeddings using human gaze tracks showing that human gaze is class-specific.

在零样本学习中，需要某种形式的辅助信息来在类别之间共享信息，以便将从已见类别中学到的知识转移到未见类别。一种流行的辅助信息形式是属性，即对象的共享且可命名的视觉属性。然而，属性通常需要昂贵的手动标注。因此，有大量的研究[7]、[9]、[11]、[31]、[34]、[50]、[51]、[52]、[53]、[54]利用其他辅助信息来减少这种标注工作。[55]不使用辅助信息，但它需要新类别中的单样本图像，以便使用学习到的度量进行最近邻搜索。SJE[9]评估了四种不同的类别嵌入，包括属性、word2vec[27]、glove[56]和WordNet层次结构[57]。在ImageNet数据集上，[3]利用了WordNet层次结构。[52]利用从新手用户那里获得的详细视觉描述的丰富信息，并提高了从专家那里获得的属性的性能。最近，[58]采用了一种不同的方法，使用人类注视轨迹来学习类别嵌入，表明人类注视具有类别特异性。

Zero-shot learning has been criticized for being a restrictive set up as it comes with a strong assumption of the image used at prediction time can only come from unseen classes. Therefore, generalized zero-shot learning setting [59] has been proposed to generalize the zero-shot learning task to the case where both seen and unseen classes are used at test time. [60]

零样本学习因其是一种限制性设置而受到批评，因为它有一个很强的假设，即预测时使用的图像只能来自未见类别。因此，广义零样本学习设置[59]被提出，以将零样本学习任务推广到测试时同时使用已见和未见类别的情况。[60]

Authorized licensed use limited to: JILIN UNIVERSITY. Downloaded on March 26,2025 at 13:28:11 UTC from IEEE Xplore. Restrictions appl argues that although ImageNet classification challenge performance has reached beyond human performance, we do not observe similar behavior of the methods that compete at the detection challenge which involves rejecting unknown objects while detecting the position and label of a known object. [7] uses label embeddings to operate on the generalized zero-shot learning setting whereas [61] proposes to learn latent representations for images and classes through coupled linear regression of factorized joint embeddings. On the other hand, [62] introduces a new model layer to the deep net which estimates the probability of an input being from an unknown class and [12] proposes a novelty detection mechanism.

授权许可使用仅限于:吉林大学。于2025年3月26日13:28:11 UTC从IEEE Xplore下载。适用限制。[文献]认为，虽然ImageNet分类挑战的性能已经超越了人类表现，但我们并未观察到参与检测挑战的方法有类似的表现，检测挑战涉及在检测已知对象的位置和标签的同时拒绝未知对象。[7]使用标签嵌入在广义零样本学习设置下进行操作，而[61]则建议通过因式分解联合嵌入的耦合线性回归来学习图像和类别的潜在表示。另一方面，[62]在深度网络中引入了一个新的模型层，用于估计输入来自未知类别的概率，[12]提出了一种新颖性检测机制。

Although zero-shot versus generalized zero-shot learning evaluation works exist [3], [63] in the literature, our work stands out in multiple aspects. For instance, [3] operates on the ImageNet $1\mathrm{\;K}$ by using 800 classes for training and 200 for test. One of the most comprehensive works, [63] provides a comparison between five methods evaluated on three datasets including ImageNet with three standard splits and proposes a metric to evaluate generalized zero-shot learning performance. On the other hand, we evaluate ten zero-shot learning methods on five datasets with several splits both for zero-shot and generalized zero-shot learning settings, provide statistical significance and robustness tests, and present other valuable insights that emerge from our benchmark. In this sense, ours is the most extensive evaluation of zero-shot and generalized zero-shot learning tasks in the literature.

虽然文献中存在零样本学习与广义零样本学习的评估工作[3]、[63]，但我们的工作在多个方面脱颖而出。例如，[3]在ImageNet$1\mathrm{\;K}$上进行操作，使用800个类别进行训练，200个类别进行测试。最全面的工作之一[63]对在包括ImageNet在内的三个数据集上评估的五种方法进行了比较，并提出了一种评估广义零样本学习性能的指标。另一方面，我们在五个数据集上对十种零样本学习方法进行了评估，这些数据集有几种划分方式，适用于零样本和广义零样本学习设置，我们还提供了统计显著性和鲁棒性测试，并展示了从我们的基准测试中得出的其他有价值的见解。从这个意义上说，我们的工作是文献中对零样本和广义零样本学习任务最广泛的评估。

## 3 EVALUATED METHODS

## 3 评估方法

We start by formalizing the zero-shot learning task and then we describe the zero-shot learning methods that we evaluate in this work. Given a training set $\mathcal{S} = \left\{  {\left( {{x}_{n},{y}_{n}}\right) , n = 1\ldots N}\right\}$ , with ${y}_{n} \in  {\mathcal{Y}}^{tr}$ belonging to training classes, the task is to learn $f : \mathcal{X} \rightarrow  \mathcal{Y}$ by minimizing the regularized empirical risk:

我们首先对零样本学习任务进行形式化，然后描述我们在这项工作中评估的零样本学习方法。给定一个训练集$\mathcal{S} = \left\{  {\left( {{x}_{n},{y}_{n}}\right) , n = 1\ldots N}\right\}$，其中${y}_{n} \in  {\mathcal{Y}}^{tr}$属于训练类别，任务是通过最小化正则化经验风险来学习$f : \mathcal{X} \rightarrow  \mathcal{Y}$:

$$
\frac{1}{N}\mathop{\sum }\limits_{{n = 1}}^{N}L\left( {{y}_{n}, f\left( {{x}_{n};W}\right) }\right)  + \Omega \left( W\right) , \tag{1}
$$

where $L\left( \text{.}\right) {isthelossfunctionand\Omega }\left( \text{.}\right) {istheregularization}$ term. Here, the mapping $f : \mathcal{X} \rightarrow  \mathcal{Y}$ from input to output embeddings is defined as:

其中$L\left( \text{.}\right) {isthelossfunctionand\Omega }\left( \text{.}\right) {istheregularization}$项。这里，从输入到输出嵌入的映射$f : \mathcal{X} \rightarrow  \mathcal{Y}$定义为:

$$
f\left( {x;W}\right)  = \mathop{\operatorname{argmax}}\limits_{{y \in  \mathcal{Y}}}F\left( {x, y;W}\right) . \tag{2}
$$

At test time, in zero-shot learning setting, the aim is to assign a test image to an unseen class label, i.e., ${\mathcal{Y}}^{ts} \subset  \mathcal{Y}$ and in generalized zero-shot learning setting, the test image can be assigned either to seen or unseen classes, i.e., ${\mathcal{Y}}^{{tr} + {ts}} \subset  \mathcal{Y}$ with the highest compatibility score.

在测试时，在零样本学习设置中，目标是将测试图像分配给未见类别标签，即${\mathcal{Y}}^{ts} \subset  \mathcal{Y}$；在广义零样本学习设置中，测试图像可以分配给已见或未见类别，即${\mathcal{Y}}^{{tr} + {ts}} \subset  \mathcal{Y}$，并具有最高的兼容性得分。

### 3.1 Learning Linear Compatibility

### 3.1 学习线性兼容性

Attribute Label Embedding (ALE) [30], Deep Visual Semantic Embedding (DEVISE) [7] and Structured Joint Embedding (SJE) [9] use bi-linear compatibility function to associate visual and auxiliary information:

属性标签嵌入(Attribute Label Embedding，ALE)[30]、深度视觉语义嵌入(Deep Visual Semantic Embedding，DEVISE)[7]和结构化联合嵌入(Structured Joint Embedding，SJE)[9]使用双线性兼容性函数来关联视觉和辅助信息:

$$
F\left( {x, y;W}\right)  = \theta {\left( x\right) }^{T}{W\phi }\left( y\right) , \tag{3}
$$

where $\theta \left( x\right)$ and $\phi \left( y\right)$ , i.e., image and class embeddings, both of which are given. $F\left( \text{.}\right) {isparameterizedbythemapping}$ $W$ , that is to be learned. Given an image, compatibility learning frameworks predict the class which attains the maximum compatibility score with the image.

其中$\theta \left( x\right)$和$\phi \left( y\right)$，即图像和类别嵌入，两者都是给定的。$F\left( \text{.}\right) {isparameterizedbythemapping}$ $W$是需要学习的。给定一幅图像，兼容性学习框架预测与该图像具有最大兼容性得分的类别。

Among the methods that are detailed below, ALE [30], DEVISE [7] and SJE [9] do early stopping to implicitly regularize Stochastic Gradient Descent (SGD) while ESZSL [10] and SAE [33] explicitly regularize the embedding model as detailed below. In the following, we provide a unified formulation of these five zero-shot learning methods.

在下面详细介绍的方法中，ALE [30]、DEVISE [7]和SJE [9]采用提前停止策略来隐式地对随机梯度下降(Stochastic Gradient Descent，SGD)进行正则化，而ESZSL [10]和SAE [33]则如下面详细介绍的那样显式地对嵌入模型进行正则化。接下来，我们给出这五种零样本学习方法的统一公式。

DEVISE [7] uses pairwise ranking objective that is inspired from unregularized ranking SVM [64]:

DEVISE [7]使用受无正则化排序支持向量机(Support Vector Machine，SVM)[64]启发的成对排序目标:

$$
\mathop{\sum }\limits_{{y \in  {\mathcal{Y}}^{tr}}}{\left\lbrack  \Delta \left( {y}_{n}, y\right)  + F\left( {x}_{n}, y;W\right)  - F\left( {x}_{n},{y}_{n};W\right) \right\rbrack  }_{ + }, \tag{4}
$$

where $\Delta \left( {{y}_{n}, y}\right)$ is equal to 1 if ${y}_{n} = y$ , otherwise 0 . The objective function is convex and is optimized by Stochastic Gradient Descent.

其中如果${y}_{n} = y$，则$\Delta \left( {{y}_{n}, y}\right)$等于1，否则为0。目标函数是凸函数，并通过随机梯度下降进行优化。

ALE [30] uses the weighted approximate ranking objective [65] for zero-shot learning in the following way:

ALE [30]以如下方式使用加权近似排序目标[65]进行零样本学习:

$$
\mathop{\sum }\limits_{{y \in  {\mathcal{Y}}^{tr}}}\frac{{l}_{{r}_{\Delta \left( {{x}_{n},{y}_{n}}\right) }}}{{r}_{\Delta \left( {{x}_{n},{y}_{n}}\right) }}{\left\lbrack  \Delta \left( {y}_{n}, y\right)  + F\left( {x}_{n}, y;W\right)  - F\left( {x}_{n},{y}_{n};W\right) \right\rbrack  }_{ + }, \tag{5}
$$

where ${l}_{k} = \mathop{\sum }\limits_{{i = 1}}^{k}{\alpha }_{i}$ and ${r}_{\Delta \left( {{x}_{n},{y}_{n}}\right) }$ is defined as:

其中${l}_{k} = \mathop{\sum }\limits_{{i = 1}}^{k}{\alpha }_{i}$和${r}_{\Delta \left( {{x}_{n},{y}_{n}}\right) }$定义为:

$$
\mathop{\sum }\limits_{{y \in  {\mathcal{Y}}^{tr}}}1\left( {F\left( {{x}_{n}, y;W}\right)  + \Delta \left( {{y}_{n}, y}\right)  \geq  F\left( {{x}_{n},{y}_{n};W}\right) }\right) . \tag{6}
$$

Following the heuristic in [66],[30] selects ${\alpha }_{i} = 1/i$ which puts a high emphasis on the top of the rank list.

遵循文献[66]中的启发式方法，文献[30]选择${\alpha }_{i} = 1/i$，它对排名列表的顶部给予了高度重视。

SJE [9] gives the full weight to the top of the ranked list and is inspired from the structured SVM [67]:

SJE [9]对排名列表的顶部赋予全部权重，其灵感来自结构化支持向量机[67]:

$$
{\left\lbrack  \mathop{\max }\limits_{{y \in  {\mathcal{Y}}^{tr}}}\left( \Delta \left( {y}_{n}, y\right)  + F\left( {x}_{n}, y;W\right) \right)  - F\left( {x}_{n},{y}_{n};W\right) \right\rbrack  }_{ + }. \tag{7}
$$

The prediction can only be made after computing the score against all the classifiers, i.e., so as to find the maximum violating class, which makes SJE less efficient than DEVISE and ALE.

只有在计算出针对所有分类器的得分后才能进行预测，即找到最大违反类别，这使得SJE的效率低于DEVISE和ALE。

ESZSL [10] applies a square loss to the ranking formulation and adds the following implicit regularization term to the unregularized risk minimization formulation:

ESZSL [10]对排序公式应用平方损失，并在无正则化风险最小化公式中添加以下隐式正则化项:

$$
\gamma \parallel {W\phi }\left( y\right) {\parallel }^{2} + \lambda {\begin{Vmatrix}\theta {\left( x\right) }^{T}W\end{Vmatrix}}^{2} + \beta \parallel W{\parallel }^{2}, \tag{8}
$$

where $\gamma ,\lambda ,\beta$ are regularization parameters. The first two terms bound the euclidean norm of projected attributes in the feature space and projected image feature in the attribute space respectively. The advantage of this approach is that the objective function is convex and has a closed form solution.

其中$\gamma ,\lambda ,\beta$是正则化参数。前两项分别限制了特征空间中投影属性的欧几里得范数和属性空间中投影图像特征的欧几里得范数。这种方法的优点是目标函数是凸函数，并且有封闭形式的解。

SAE [33] also learns the linear projection from image embedding space to class embedding space, but it further constrains that the projection must be able to reconstruct the original image embedding. Similar to the linear auto-encoder, SAE optimizes the following objective:

自编码器(SAE) [33] 也学习从图像嵌入空间到类别嵌入空间的线性投影，但它进一步约束该投影必须能够重构原始图像嵌入。与线性自编码器类似，SAE 优化以下目标:

$$
\mathop{\min }\limits_{W}{\begin{Vmatrix}\theta \left( x\right)  - {W}^{T}\phi \left( y\right) \end{Vmatrix}}^{2} + \lambda {\begin{Vmatrix}W\theta \left( x\right)  - \phi \left( y\right) \end{Vmatrix}}^{2}, \tag{9}
$$

where $\lambda$ is a hyperparameter to be tuned. The optimization problem can be transformed such that Bartels-Stewart algorithm [68] is able to solve it efficiently.

其中 $\lambda$ 是一个待调整的超参数。该优化问题可以进行变换，以便 Bartels - Stewart 算法 [68] 能够高效地求解它。

### 3.2 Learning Nonlinear Compatibility

### 3.2 学习非线性兼容性

Latent Embeddings (LATEM) [11] and Cross Modal Transfer (CMT) [12] encode an additional non-linearity component to linear compatibility learning framework.

潜在嵌入(LATEM) [11] 和跨模态迁移(CMT) [12] 在线性兼容性学习框架中加入了一个额外的非线性组件。

LATEM [11] constructs a piece-wise linear compatibility:

LATEM [11] 构建了一个分段线性兼容性:

$$
F\left( {x, y;{W}_{i}}\right)  = \mathop{\max }\limits_{{1 \leq  i \leq  K}}\theta {\left( x\right) }^{T}{W}_{i}\phi \left( y\right) , \tag{10}
$$

where every ${W}_{i}$ models a different visual characteristic of the data and the selection of which matrix to use to do the mapping is a latent variable and $K$ is a hyperparameter to be tuned. LATEM uses the ranking loss formulated in Equation (4) and Stochastic Gradient Descent as the optimizer.

其中每个 ${W}_{i}$ 对数据的不同视觉特征进行建模，选择使用哪个矩阵进行映射是一个潜在变量，并且 $K$ 是一个待调整的超参数。LATEM 使用公式(4)中定义的排序损失，并采用随机梯度下降作为优化器。

CMT [12] first maps images into a semantic space of words, i.e., class names, where a neural network with tanh nonlinearity learns the mapping:

CMT [12] 首先将图像映射到一个单词的语义空间，即类别名称空间，其中一个具有双曲正切非线性的神经网络学习该映射:

$$
\mathop{\sum }\limits_{{y \in  \mathcal{Y}}}\mathop{\sum }\limits_{{x \in  {\mathcal{X}}_{y}}}\parallel \phi \left( y\right)  - {W}_{1}\tanh \left( {{W}_{2}{.\theta }\left( x\right) {\parallel }^{2}.}\right.  \tag{11}
$$

where $\left( {{W}_{1},{W}_{2}}\right)$ are weights of the two layer neural network. This is followed by a novelty detection mechanism that assigns images to unseen or seen classes. The novelty is detected either via thresholds learned using the embedded images of the seen classes or the outlier probabilities are obtained in an unsupervised way. As zero-shot learning assumes that test images are only from unseen classes, in our experiments when we refer to CMT, that means we do not use the novelty detection component. On the other hand, we name the CMT with novelty detection as CMT* when we apply it to the generalized zero-shot learning setting.

其中 $\left( {{W}_{1},{W}_{2}}\right)$ 是两层神经网络的权重。随后是一个新奇性检测机制，该机制将图像分配到未见或已见类别。新奇性可以通过使用已见类别的嵌入图像学习到的阈值来检测，或者以无监督的方式获得离群概率。由于零样本学习假设测试图像仅来自未见类别，在我们的实验中，当我们提及 CMT 时，意味着我们不使用新奇性检测组件。另一方面，当我们将带有新奇性检测的 CMT 应用于广义零样本学习设置时，我们将其命名为 CMT*。

### 3.3 Learning Intermediate Attribute Classifiers

### 3.3 学习中间属性分类器

Although Direct Attribute Prediction (DAP) [1] and Indirect Attribute Prediction (IAP) [1] have been shown to perform poorly compared to compatibility learning frameworks [30], we include them to our evaluation for being historically the most widely used methods in the literature.

尽管直接属性预测(DAP) [1] 和间接属性预测(IAP) [1] 与兼容性学习框架 [30] 相比表现较差，但我们将它们纳入评估，因为它们在历史上是文献中使用最广泛的方法。

${DAP}\left\lbrack  1\right\rbrack$ learns probabilistic attribute classifiers and makes a class prediction by combining scores of the learned attribute classifiers. A novel image is assigned to one of the unknown classes using:

${DAP}\left\lbrack  1\right\rbrack$ 学习概率属性分类器，并通过组合所学习的属性分类器的得分进行类别预测。使用以下方法将一幅新图像分配到某个未知类别:

$$
f\left( x\right)  = \mathop{\operatorname{argmax}}\limits_{c}\mathop{\prod }\limits_{{m = 1}}^{M}\frac{p\left( {{a}_{m}^{c} \mid  x}\right) }{p\left( {a}_{m}^{c}\right) }. \tag{12}
$$

with $M$ being the total number of attributes, ${a}_{m}^{c}$ is the $\mathrm{m}$ -th attribute of class $c, p\left( {{a}_{m}^{c} \mid  x}\right)$ is the attribute probability given image $x$ which is obtained from the attribute classifiers whereas $p\left( {a}_{m}^{c}\right)$ is the attribute prior estimated by the empirical mean of attributes over training classes. We train binary classifiers with logistic regression that gives probability scores of attributes with respect to training classes.

其中 $M$ 是属性的总数，${a}_{m}^{c}$ 是类别 $c, p\left( {{a}_{m}^{c} \mid  x}\right)$ 的第 $\mathrm{m}$ 个属性，$x$ 是给定图像的属性概率，该概率从属性分类器中获得，而 $p\left( {a}_{m}^{c}\right)$ 是通过训练类别上属性的经验均值估计的属性先验。我们使用逻辑回归训练二分类器，该分类器给出关于训练类别的属性概率得分。

${IAP}\left\lbrack  1\right\rbrack$ indirectly estimates attributes probabilities of an image by first predicting the probabilities of each training class, then multiplying the class attribute matrix. Once the attributes probabilities are obtained by the following equation:

${IAP}\left\lbrack  1\right\rbrack$ 通过首先预测每个训练类别的概率，然后乘以类别属性矩阵，间接估计图像的属性概率。一旦通过以下方程获得属性概率:

$$
p\left( {{a}_{m} \mid  x}\right)  = \mathop{\sum }\limits_{{k = 1}}^{K}p\left( {{a}_{m} \mid  {y}_{k}}\right) p\left( {{y}_{k} \mid  x}\right) , \tag{13}
$$

where $K$ is the number of training classes, $p\left( {{a}_{m} \mid  {y}_{k}}\right)$ is the predefined class attribute and $p\left( {{y}_{k} \mid  x}\right)$ is training class posterior from multi-class classifier, the Equation (12) is used to predict the class label for which we train a multi-class classifier on training classes with logistic regression.

其中 $K$ 是训练类别的数量，$p\left( {{a}_{m} \mid  {y}_{k}}\right)$ 是预定义的类别属性，$p\left( {{y}_{k} \mid  x}\right)$ 是来自多类别分类器的训练类别后验概率，使用公式(12)预测类别标签，为此我们在训练类别上使用逻辑回归训练一个多类别分类器。

### 3.4 Hybrid Models

### 3.4 混合模型

Semantic Similarity Embedding (SSE) [13], Convex Combination of Semantic Embeddings (CONSE) [15] and Synthesized Classifiers (SYNC) [14] express images and semantic class embeddings as a mixture of seen class proportions, hence we group them as hybrid models.

语义相似性嵌入(SSE) [13]、语义嵌入的凸组合(CONSE) [15] 和合成分类器(SYNC) [14] 将图像和语义类别嵌入表示为已见类别比例的混合，因此我们将它们归为混合模型。

SSE [13] leverages similar class relationships both in image and semantic embedding space. An image is labeled with:

半监督嵌入(SSE)[13]利用了图像和语义嵌入空间中的相似类关系。图像的标签为:

$$
\mathop{\operatorname{argmax}}\limits_{{u \in  \mathcal{U}}}\pi {\left( \theta \left( x\right) \right) }^{T}\psi \left( {\phi \left( {y}_{u}\right) }\right) , \tag{14}
$$

where $\pi ,\psi$ are mappings of class and image embeddings into a common space defined by the mixture of seen classes proportions. Specifically, $\psi$ is learned by sparse coding and $\pi$ is by class dependent transformation.

其中$\pi ,\psi$是将类和图像嵌入映射到由可见类比例混合定义的公共空间的映射。具体而言，$\psi$通过稀疏编码学习得到，$\pi$通过类相关变换得到。

CONSE [15] learns the probability of a training image belonging to a training class:

基于上下文的语义嵌入(CONSE)[15]学习训练图像属于某个训练类别的概率:

$$
f\left( {x, t}\right)  = \mathop{\operatorname{argmax}}\limits_{{y \in  {\mathcal{Y}}^{tr}}}{p}_{tr}\left( {y \mid  x}\right) , \tag{15}
$$

where $y$ denotes the most likely training label $\left( {t = 1}\right)$ for image $x$ . Combination of semantic embeddings(s)is used to assign an unknown image to an unseen class:

其中$y$表示图像$x$最可能的训练标签$\left( {t = 1}\right)$。语义嵌入的组合用于将未知图像分配到未见类别:

$$
\frac{1}{Z}\mathop{\sum }\limits_{{i = 1}}^{T}{p}_{tr}\left( {f\left( {x, t}\right)  \mid  x}\right)  \cdot  s\left( {f\left( {x, t}\right) }\right) , \tag{16}
$$

where $Z = \mathop{\sum }\limits_{{i = 1}}^{T}{p}_{tr}\left( {f\left( {x, t}\right)  \mid  x}\right) , f\left( {x, t}\right)$ denotes the tth most likely label for image $x$ and $T$ controls the maximum number of semantic embedding vectors.

其中$Z = \mathop{\sum }\limits_{{i = 1}}^{T}{p}_{tr}\left( {f\left( {x, t}\right)  \mid  x}\right) , f\left( {x, t}\right)$表示图像$x$的第t个最可能的标签，$T$控制语义嵌入向量的最大数量。

SYNC [14] learns a mapping between the semantic class embedding space and a model space. In the model space, training classes and a set of phantom classes form a weighted bipartite graph. The objective is to minimize distortion error:

同步嵌入(SYNC)[14]学习语义类别嵌入空间和模型空间之间的映射。在模型空间中，训练类别和一组虚拟类别形成一个加权二分图。目标是最小化失真误差:

$$
\mathop{\min }\limits_{{w}_{c}}{\begin{Vmatrix}{w}_{c} - \mathop{\sum }\limits_{{r = 1}}^{R}{s}_{cr}{v}_{r}\end{Vmatrix}}_{2}^{2}. \tag{17}
$$

Semantic and model spaces are aligned by embedding classifiers of real classes $\left( {w}_{c}\right)$ and classifiers of phantom classes $\left( {v}_{r}\right)$ in the weighted graph $\left( {s}_{cr}\right)$ . The classifiers for novel classes are constructed by linearly combining classifiers of phantom classes.

通过在加权图$\left( {s}_{cr}\right)$中嵌入真实类别的分类器$\left( {w}_{c}\right)$和虚拟类别的分类器$\left( {v}_{r}\right)$，使语义空间和模型空间对齐。新类别的分类器通过线性组合虚拟类别的分类器来构建。

GFZSL [41] proposes a generative framework for zero-shot learning by modeling each class-conditional distribution as a multi-variate Gaussian with mean vector $\mu$ and diagonal covariance matrix $\sigma$ . While the parameters of seen classes can be estimated by MLE, that of unseen classes

生成式零样本学习(GFZSL)[41]提出了一种零样本学习的生成框架，将每个类条件分布建模为具有均值向量$\mu$和对角协方差矩阵$\sigma$的多元高斯分布。虽然可见类别的参数可以通过最大似然估计(MLE)来估计，但未见类别的参数

Authorized licensed use limited to: JILIN UNIVERSITY. Downloaded on March 26,2025 at 13:28:11 UTC from IEEE Xplore. F are computed by learning the following two regression functions:

授权许可使用仅限于:吉林大学。于2025年3月26日13:28:11 UTC从IEEE Xplore下载。F通过学习以下两个回归函数来计算:

$$
{\mu }_{y} = {f}_{\mu }\left( {\phi \left( y\right) }\right) \text{and}{\sigma }_{y} = {f}_{\sigma }\left( {\phi \left( y\right) }\right) \text{,} \tag{18}
$$

with an image $x$ , its class is predicted by searching the class with the maximum probability, i.e., ${\operatorname{argmax}}_{y}p\left( {x \mid  {\sigma }_{y},{\mu }_{y}}\right)$ .

对于图像$x$，通过搜索具有最大概率的类别来预测其类别，即${\operatorname{argmax}}_{y}p\left( {x \mid  {\sigma }_{y},{\mu }_{y}}\right)$。

### 3.5 Transductive Zero-Shot Learning Setting

### 3.5 直推式零样本学习设置

In zero-shot learning, transductive setting [69], [70] implies that unlabeled images from unseen classes are available during training. Using unlabeled images are expected to improve performance as they possibly contain useful latent information of unseen classes. Here, we mainly focus on two state-of-the-art transductive approaches [41], [71] and show how to extend ALE [30] into the transductive learning setting.

在零样本学习中，直推式设置[69]、[70]意味着在训练期间可以获得来自未见类别的未标记图像。使用未标记图像有望提高性能，因为它们可能包含未见类别的有用潜在信息。在这里，我们主要关注两种最先进的直推式方法[41]、[71]，并展示如何将自适应标签嵌入(ALE)[30]扩展到直推式学习设置中。

GFZSL-tran [41] uses an Expectation-Maximization (EM) based procedure that alternates between inferring the labels of unlabeled examples of unseen classes and using the inferred labels to update the parameter estimates of unseen class distributions. Since the class-conditional distribution is assumed to be Gaussian, this procedure is equivalent to repeatedly estimating a Gaussian Mixture Model (GMM) with the unlabeled data from unseen classes and use the inferred class labels to re-estimate the GMM.

直推式生成式零样本学习(GFZSL - tran)[41]使用基于期望最大化(EM)的过程，该过程在推断未见类别的未标记示例的标签和使用推断的标签更新未见类别分布的参数估计之间交替进行。由于假设类条件分布是高斯分布，此过程相当于使用来自未见类别的未标记数据反复估计高斯混合模型(GMM)，并使用推断的类别标签重新估计GMM。

DSRL [71] proposes to simultaneously learn image features with non-negative matrix factorization and align them with their corresponding class attributes. This step gives us an initial prediction score matrix ${S}_{0}$ in which each row is one instance and indicates the prediction scores for all unseen classes. To improve the prediction score matrix by transduc-tive learning, a graph-based label propagation algorithm is applied. Specifically, a KNN graph is constructed with the projected instances of unseen classes in the class embedding space,

深度语义表示学习(DSRL)[71]提出同时使用非负矩阵分解学习图像特征，并将它们与其对应的类别属性对齐。这一步为我们提供了一个初始预测得分矩阵${S}_{0}$，其中每一行是一个实例，表示所有未见类别的预测得分。为了通过直推式学习改进预测得分矩阵，应用了基于图的标签传播算法。具体而言，在类别嵌入空间中，使用未见类别的投影实例构建一个K近邻(KNN)图，

$$
{M}_{ij} = \left\{  \begin{array}{ll} \exp \left( {-\frac{d\left( {{x}_{i},{x}_{j}}\right) }{2{\sigma }^{2}}}\right) & \text{ if }i \in  \operatorname{KNN}\left( j\right) \text{ or }j \in  \operatorname{KNN}\left( i\right) \\  0 & \text{ otherwise,} \end{array}\right.
$$

(19)

where $\operatorname{KNN}\left( i\right)$ denotes the k-nearest neighbor of $i$ th instance and $d\left( {{x}_{i},{x}_{j}}\right)$ measures the euclidean distance between ${x}_{i}$ and ${x}_{j}$ . Given the affinity matrix $M$ , a normalized Laplacian matrix $L$ can be computed as $L = {Q}^{-1/2}M{Q}^{-1/2}$ where $Q$ is a diagonal matrix with ${Q}_{ii} = \mathop{\sum }\limits_{j}{M}_{ij}$ . Finally, the standard label propagation [72] gives the closed-form solution:

其中$\operatorname{KNN}\left( i\right)$表示第$i$个实例的k近邻，$d\left( {{x}_{i},{x}_{j}}\right)$测量${x}_{i}$和${x}_{j}$之间的欧几里得距离。给定亲和矩阵$M$，可以计算归一化拉普拉斯矩阵$L$为$L = {Q}^{-1/2}M{Q}^{-1/2}$，其中$Q$是一个对角矩阵，其元素为${Q}_{ii} = \mathop{\sum }\limits_{j}{M}_{ij}$。最后，标准的标签传播[72]给出了闭式解:

$$
S = {\left( I - \alpha L\right) }^{-1} \times  {S}_{0}, \tag{20}
$$

where $\alpha  \in  \left\lbrack  {0,1}\right\rbrack$ is a regularization trade-off parameter and $S$ is the score matrix. The class label of an instance is predicted by searching the class with the highest score, i.e., ${\operatorname{argmax}}_{y}{S}_{iy}$ .

其中 $\alpha  \in  \left\lbrack  {0,1}\right\rbrack$ 是一个正则化权衡参数，$S$ 是得分矩阵。通过搜索得分最高的类别来预测实例的类别标签，即 ${\operatorname{argmax}}_{y}{S}_{iy}$。

ALE-tran Any compatibility learning method that explicitly learns cross-modal mapping from image feature space to class embedding space can be extended to transductive setting following the label propagation procedure of DSRL [71]. Taking the ALE [30] as an example, after learning the linear mapping $W$ , instances of unseen classes can be projected into the class embedding space and a score matrix ${S}_{0}$ can be computed similarly.

ALE - 直推式学习(ALE - tran)任何显式学习从图像特征空间到类别嵌入空间的跨模态映射的兼容性学习方法，都可以按照DSRL [71]的标签传播过程扩展到直推式设置。以ALE [30]为例，在学习到线性映射 $W$ 之后，可以将未见类别的实例投影到类别嵌入空间，并类似地计算得分矩阵 ${S}_{0}$。

TABLE 1

Statistics for SUN [16], CUB [17], AWA1 [1], Proposed AWA2, aPY [18] in Terms of Size, Granularity, Number of Attributes, Numi of Classes in ${\mathcal{Y}}^{tr}$ and ${\mathcal{Y}}^{ts}$ , Number of Images at Training and Test Time for Standard Split (SS) and Our Proposed Splits (PS)

关于SUN [16]、CUB [17]、AWA1 [1]、本文提出的AWA2、aPY [18]在规模、粒度、属性数量、${\mathcal{Y}}^{tr}$ 和 ${\mathcal{Y}}^{ts}$ 中的类别数量、标准划分(SS)和本文提出的划分(PS)在训练和测试时的图像数量方面的统计信息

<table><tr><td rowspan="4">Dataset</td><td rowspan="4">Size</td><td rowspan="4">Granularity</td><td rowspan="4">Att</td><td rowspan="4">$y$</td><td colspan="2" rowspan="3">Number of Images</td><td colspan="9">Number of Classes</td></tr><tr><td/><td colspan="4">At Training Time</td><td colspan="4">At Evaluation Time</td></tr><tr><td/><td colspan="2">SS</td><td colspan="2">PS</td><td colspan="2">SS</td><td colspan="2">PS</td></tr><tr><td>${y}^{tr}$</td><td>${y}^{ts}$</td><td>Total</td><td>${\mathcal{Y}}^{tr}$</td><td>${y}^{ts}$</td><td>${y}^{tr}$</td><td>${\mathcal{V}}^{ts}$</td><td>${y}^{tr}$</td><td>${y}^{ts}$</td><td>${\mathcal{Y}}^{tr}$</td><td>${\mathcal{V}}^{ts}$</td></tr><tr><td>SUN [16]</td><td>medium</td><td>fine</td><td>102</td><td>717</td><td>580 + 65</td><td>72</td><td>14340</td><td>12900</td><td>0</td><td>10320</td><td>0</td><td>0</td><td>1440</td><td>2580</td><td>1440</td></tr><tr><td>CUB [17]</td><td>medium</td><td>fine</td><td>312</td><td>200</td><td>100 + 50</td><td>50</td><td>11788</td><td>8855</td><td>0</td><td>7057</td><td>0</td><td>0</td><td>2933</td><td>1764</td><td>2967</td></tr><tr><td>AWA1 [1]</td><td>medium</td><td>coarse</td><td>85</td><td>50</td><td>27 + 13</td><td>10</td><td>30475</td><td>24295</td><td>0</td><td>19832</td><td>0</td><td>0</td><td>6180</td><td>4958</td><td>5685</td></tr><tr><td>AWA2</td><td>medium</td><td>coarse</td><td>85</td><td>50</td><td>27 + 13</td><td>10</td><td>37322</td><td>30337</td><td>0</td><td>23527</td><td>0</td><td>0</td><td>6985</td><td>5882</td><td>7913</td></tr><tr><td>aPY [18]</td><td>small</td><td>coarse</td><td>64</td><td>32</td><td>${15} + 5$</td><td>12</td><td>15339</td><td>12695</td><td>0</td><td>5932</td><td>0</td><td>0</td><td>2644</td><td>1483</td><td>7924</td></tr></table>

<table><tbody><tr><td rowspan="4">数据集</td><td rowspan="4">大小</td><td rowspan="4">粒度</td><td rowspan="4">属性(Att)</td><td rowspan="4">$y$</td><td colspan="2" rowspan="3">图像数量</td><td colspan="9">类别数量</td></tr><tr><td></td><td colspan="4">训练阶段</td><td colspan="4">评估阶段</td></tr><tr><td></td><td colspan="2">单尺度(SS)</td><td colspan="2">多尺度(PS)</td><td colspan="2">单尺度(SS)</td><td colspan="2">多尺度(PS)</td></tr><tr><td>${y}^{tr}$</td><td>${y}^{ts}$</td><td>总计</td><td>${\mathcal{Y}}^{tr}$</td><td>${y}^{ts}$</td><td>${y}^{tr}$</td><td>${\mathcal{V}}^{ts}$</td><td>${y}^{tr}$</td><td>${y}^{ts}$</td><td>${\mathcal{Y}}^{tr}$</td><td>${\mathcal{V}}^{ts}$</td></tr><tr><td>太阳数据集(SUN [16])</td><td>中等</td><td>精细</td><td>102</td><td>717</td><td>580 + 65</td><td>72</td><td>14340</td><td>12900</td><td>0</td><td>10320</td><td>0</td><td>0</td><td>1440</td><td>2580</td><td>1440</td></tr><tr><td>加州大学伯克利分校鸟类数据集(CUB [17])</td><td>中等</td><td>精细</td><td>312</td><td>200</td><td>100 + 50</td><td>50</td><td>11788</td><td>8855</td><td>0</td><td>7057</td><td>0</td><td>0</td><td>2933</td><td>1764</td><td>2967</td></tr><tr><td>动物属性数据集1(AWA1 [1])</td><td>中等</td><td>粗略</td><td>85</td><td>50</td><td>27 + 13</td><td>10</td><td>30475</td><td>24295</td><td>0</td><td>19832</td><td>0</td><td>0</td><td>6180</td><td>4958</td><td>5685</td></tr><tr><td>动物属性数据集2(AWA2)</td><td>中等</td><td>粗略</td><td>85</td><td>50</td><td>27 + 13</td><td>10</td><td>37322</td><td>30337</td><td>0</td><td>23527</td><td>0</td><td>0</td><td>6985</td><td>5882</td><td>7913</td></tr><tr><td>属性化的帕斯卡数据集(aPY [18])</td><td>小</td><td>粗略</td><td>64</td><td>32</td><td>${15} + 5$</td><td>12</td><td>15339</td><td>12695</td><td>0</td><td>5932</td><td>0</td><td>0</td><td>2644</td><td>1483</td><td>7924</td></tr></tbody></table>

## 4 DATASETS

## 4 数据集

Among the most widely used datasets for zero-shot learning, we select two coarse-grained, one small (aPY [18]) and one medium-scale (AWA1 [1]), and two fine-grained, both medium-scale, datasets (SUN [16], CUB [17]) with attributes and one large-scale dataset (ImageNet [19]) without. Here, we consider between ${10}\mathrm{K}$ and $1\mathrm{M}$ images, and, between 100 and ${1K}$ classes as medium-scale. Details of dataset statistics in terms of the number of images, classes, attributes for the attribute datasets are in Table 1. Furthermore, we introduce our Animals With Attributes 2 (AWA2) dataset and position it with respect to existing datasets.

在零样本学习中最广泛使用的数据集里，我们选择了两个粗粒度数据集，一个小规模的(aPY [18])和一个中等规模的(AWA1 [1])，以及两个细粒度、均为中等规模且带有属性的数据集(SUN [16]、CUB [17])，还有一个无属性的大规模数据集(ImageNet [19])。这里，我们将 ${10}\mathrm{K}$ 到 $1\mathrm{M}$ 张图像以及 100 到 ${1K}$ 个类别视为中等规模。属性数据集在图像数量、类别数量、属性方面的统计细节见表 1。此外，我们介绍了我们的动物属性 2(Animals With Attributes 2，AWA2)数据集，并将其与现有数据集进行定位比较。

### 4.1 Attribute Datasets

### 4.1 属性数据集

Attribute Pascal and Yahoo (aPY) [18] is a small-scale coarse-grained dataset with 64 attributes. Among the total number of 32 classes, 20 Pascal classes are used for training (we randomly select 5 for validation) and 12 Yahoo classes are used for testing. The original Animals with Attributes (AWA1) [1] is a coarse-grained dataset that is medium-scale in terms of the number of images, i.e., 30,475 and small-scale in terms of number of classes, i.e., 50 classes. [1] introduces a standard zero-shot split with 40 classes for training (we randomly select 13 classes for validation) and 10 classes for testing. AWA1 has 85 attributes. Caltech-UCSD-Birds 200- 2011 (CUB) [17] is a fine-grained and medium scale dataset with respect to both number of images and number of classes, i.e., 11,788 images from 200 different types of birds annotated with 312 attributes. [30] introduces the first zero-shot split of CUB with 150 training (50 validation classes) and 50 test classes. SUN [16] is a fine-grained and medium-scale dataset with respect to both number of images and number of classes, i.e., SUN contains 14340 images coming from 717 types of scenes annotated with 102 attributes. Following [1] we use 645 classes of SUN for training (we randomly select 65 classes for validation) and 72 classes for testing.

属性帕斯卡和雅虎(Attribute Pascal and Yahoo，aPY)[18] 是一个小规模的粗粒度数据集，有 64 个属性。在总共 32 个类别中，20 个帕斯卡(Pascal)类别用于训练(我们随机选择 5 个用于验证)，12 个雅虎(Yahoo)类别用于测试。原始的动物属性(Animals with Attributes，AWA1)[1] 是一个粗粒度数据集，就图像数量而言是中等规模，即 30475 张图像，就类别数量而言是小规模，即 50 个类别。[1] 引入了一个标准的零样本划分，40 个类别用于训练(我们随机选择 13 个类别用于验证)，10 个类别用于测试。AWA1 有 85 个属性。加州理工学院 - 加州大学圣地亚哥分校鸟类 200 - 2011(Caltech - UCSD - Birds 200 - 2011，CUB)[17] 是一个细粒度且在图像数量和类别数量上均为中等规模的数据集，即来自 200 种不同鸟类的 11788 张图像，标注了 312 个属性。[30] 引入了 CUB 的第一个零样本划分，150 个训练类别(50 个验证类别)和 50 个测试类别。SUN [16] 是一个细粒度且在图像数量和类别数量上均为中等规模的数据集，即 SUN 包含来自 717 种场景的 14340 张图像，标注了 102 个属性。按照 [1] 的方法，我们使用 SUN 的 645 个类别进行训练(我们随机选择 65 个类别用于验证)，72 个类别用于测试。

Animals with Attributes2 (AWA2) Dataset. One disadvantage of AWA1 dataset is that the images are not publicly available. As having highly descriptive image features is an important component for zero-shot learning, in order to enable vision research on the objects of the AWA1 dataset, we introduce the Animals with Attributes2 (AWA2) dataset. Following [1], we collect 37,322 images for the 50 classes of AWA1 dataset from public web sources, i.e., Flickr, Wikipedia, etc., making sure Authorized licensed use limited to: JILIN UNIVERSITY. Downloaded on March 26,2025 at 13:28:11 UTC from IEEE Xplore. Restrictions apply. that all images of AWA2 have free-use and redistribution licenses and they do not overlap with images of the original Animal with Attributes dataset. The AWA2 dataset uses the same 50 animal classes as AWA1 dataset, similarly the 85 binary and continuous class attributes are common. In total, AWA2 has 37,322 images compared to 30,475 images of AWA1. On average, each class includes 746 images where the least populated class, i.e., mole, has 100 and the most populated class, i.e., horse has 1645 examples. Some example images from polar bear, zebra, otter and tiger classes along with sample attributes from our AWA2 dataset are shown in Fig. 1.

动物属性 2(Animals with Attributes2，AWA2)数据集。AWA1 数据集的一个缺点是图像不公开。由于具有高度描述性的图像特征是零样本学习的重要组成部分，为了能够对 AWA1 数据集的对象进行视觉研究，我们引入了动物属性 2(AWA2)数据集。按照 [1] 的方法，我们从公共网络资源(即 Flickr、维基百科等)为 AWA1 数据集的 50 个类别收集了 37322 张图像，确保授权许可使用仅限于:吉林大学。于 2025 年 3 月 26 日 13:28:11 UTC 从 IEEE Xplore 下载。适用限制。AWA2 的所有图像都有自由使用和再分发许可，并且它们与原始动物属性数据集的图像不重叠。AWA2 数据集使用与 AWA1 数据集相同的 50 个动物类别，同样，85 个二进制和连续的类别属性也是相同的。总体而言，AWA2 有 37322 张图像，而 AWA1 有 30475 张图像。平均而言，每个类别包含 746 张图像，其中样本最少的类别(即鼹鼠)有 100 张，样本最多的类别(即马)有 1645 个样本。图 1 展示了我们 AWA2 数据集中北极熊、斑马、水獭和老虎类别的一些示例图像以及样本属性。

In Fig. 2, we provide some statistics on the AWA2 dataset in comparison with the AWA1 dataset in terms of the number of images and also the distribution of the image features. Compared to AWA1, our proposed AWA2 dataset contains more images, e.g., horse and dolphin among the test classes, antelope and cow among the training classes. Moreover, the t-SNE embedding of these test classes with more training data, e.g., horse, dolphin, seal etc. shows that AWA2 leads to slightly more visible clusters of ResNet features. The images, their labels and ResNet features of our AWA2 are publicly available in http://cvml.ist.ac.at/AwA2.

在图 2 中，我们提供了 AWA2 数据集与 AWA1 数据集在图像数量以及图像特征分布方面的一些统计信息。与 AWA1 相比，我们提出的 AWA2 数据集包含更多的图像，例如测试类别中的马和海豚，训练类别中的羚羊和牛。此外，这些测试类别的 t - SNE 嵌入在有更多训练数据(例如马、海豚、海豹等)的情况下表明，AWA2 导致 ResNet 特征的聚类更明显。我们 AWA2 的图像、标签和 ResNet 特征可在 http://cvml.ist.ac.at/AwA2 上公开获取。

![0195d2b1-719e-720b-bdb3-2e8d7e8c28b6_5_871_1498_765_601_0.jpg](images/0195d2b1-719e-720b-bdb3-2e8d7e8c28b6_5_871_1498_765_601_0.jpg)

Fig. 2. Comparing AWA1 [1] and our AWA2 in terms of number of images (Left) and t-SNE embedding of the image features (the embedding is learned on AWA1 and AWA2 simultaneously, therefore the figures are comparable). AWA2 follows a similar distribution as AWA1 and it contains more examples.

图2. 从图像数量(左)和图像特征的t-SNE嵌入(该嵌入是同时在AWA1和AWA2上学习得到的，因此这些图具有可比性)方面比较AWA1 [1]和我们的AWA2。AWA2的分布与AWA1相似，并且它包含更多的示例。

### 4.2 Large-Scale ImageNet

### 4.2 大规模ImageNet数据集

We also evaluate the performance of methods on the large scale ImageNet [19] which contains a total of 14 million images from ${21}\mathrm{\;K}$ classes, each one labeled with one label, and the classes are hierarchically related as ImageNet follows the WordNet [57].

我们还在大规模的ImageNet数据集 [19] 上评估了各方法的性能，该数据集总共包含来自 ${21}\mathrm{\;K}$ 个类别的1400万张图像，每张图像都有一个标签，并且由于ImageNet遵循WordNet [57]，这些类别具有层次关系。

ImageNet is a natural fit for zero-shot and generalized zero-shot learning as there is a large class imbalance problem. Moreover, ImageNet is diverse in terms of granularity, i.e., it contains a collection of fine-grained datasets, e.g., different vehicle types, as well as coarse-grained datasets. The highest populated class contains 3,047 images whereas there are many classes that contains only a single image. A balanced subset of ImageNet with $1\mathrm{\;K}$ classes containing about 1000 images each is used to train CNNs.

ImageNet非常适合用于零样本和广义零样本学习，因为它存在严重的类别不平衡问题。此外，ImageNet在粒度方面具有多样性，即它包含一系列细粒度数据集(例如不同的车辆类型)以及粗粒度数据集。样本数量最多的类别包含3047张图像，而有许多类别仅包含一张图像。我们使用ImageNet中一个包含 $1\mathrm{\;K}$ 个类别、每个类别约有1000张图像的平衡子集来训练卷积神经网络(CNN)。

Previous works [3] proposed to split the balanced subset of $1\mathrm{\;K}$ classes into 800 training and 200 test classes. In this work, from the total of ${21}\mathrm{\;K}$ classes, we use $1\mathrm{\;K}$ classes for training (among which we use 200 classes for validation) and the test split is either all the remaining ${20}\mathrm{\;K}$ classes or a subset of it, e.g., we determine these subsets based on the hierarchical distance between classes and the population of classes. The details of these splits are provided in the following section.

先前的工作 [3] 提议将 $1\mathrm{\;K}$ 个类别的平衡子集划分为800个训练类别和200个测试类别。在这项工作中，从总共 ${21}\mathrm{\;K}$ 个类别中，我们使用 $1\mathrm{\;K}$ 个类别进行训练(其中我们使用200个类别进行验证)，测试集划分可以是其余所有 ${20}\mathrm{\;K}$ 个类别，也可以是其一个子集，例如，我们根据类别之间的层次距离和类别样本数量来确定这些子集。这些划分的详细信息将在以下部分提供。

## 5 EVALUATION PROTOCOL

## 5 评估协议

In this section, we provide several components of previously used and our proposed ZSL and GZSL evaluation protocols, e.g., image and class encodings, dataset splits and the evaluation criteria. ${}^{1}$

在本节中，我们介绍了先前使用的以及我们提出的零样本学习(ZSL)和广义零样本学习(GZSL)评估协议的几个组成部分，例如图像和类别编码、数据集划分以及评估标准。 ${}^{1}$

### 5.1 Image and Class Embedding

### 5.1 图像和类别嵌入

We extract image features, namely image embeddings, from the entire image for SUN, CUB, AWA1, our AWA2 and ImageNet, with no image pre-processing. For aPY, following the original publication in [18], we crop the images from bounding boxes. Our image embeddings are 2048-dim top-layer pooling units of the 101-layered ResNet [23] as we found that it performs better than 1,024-dim top-layer pooling units of GoogleNet [73]. We use the original ResNet-101 that is pre-trained on ImageNet with $1\mathrm{\;K}$ classes, i.e., the balanced subset, and we do not fine-tune it for any of the mentioned datasets. In addition to the ResNet features, we re-evaluate all methods with their published image features.

我们在不进行任何图像预处理的情况下，从SUN、CUB、AWA1、我们的AWA2和ImageNet的整个图像中提取图像特征，即图像嵌入。对于aPY数据集，按照文献 [18] 中的原始方法，我们从边界框中裁剪图像。我们的图像嵌入是101层ResNet [23] 的2048维顶层池化单元，因为我们发现它的性能优于GoogleNet [73] 的1024维顶层池化单元。我们使用在包含 $1\mathrm{\;K}$ 个类别的ImageNet平衡子集上预训练的原始ResNet - 101，并且不对上述任何数据集进行微调。除了ResNet特征外，我们还使用各方法已发表的图像特征重新评估所有方法。

In zero-shot learning, class embeddings are as important as image features. As class embeddings, for aPY, AWA1, AWA2, CUB and SUN, we use the per-class attributes between values 0 and 1 that are provided with the datasets as binary attributes have been shown [30] to be weaker than continuous attributes. For ImageNet as attributes of ${21}\mathrm{\;K}$ classes are not available, we use Word2Vec [27] trained on Wikipedia provided by [14]. Note that an evaluation of class embeddings is out of the scope of this paper. We refer the reader to [9] for more details on the topic.

在零样本学习中，类别嵌入与图像特征同样重要。对于aPY、AWA1、AWA2、CUB和SUN数据集，我们使用数据集中提供的取值在0到1之间的每类属性作为类别嵌入，因为已有研究 [30] 表明二进制属性比连续属性的效果更差。对于ImageNet数据集，由于 ${21}\mathrm{\;K}$ 个类别的属性不可用，我们使用 [14] 提供的在维基百科上训练的Word2Vec [27]。请注意，对类别嵌入的评估超出了本文的范围。有关该主题的更多详细信息，请参考文献 [9]。

### 5.2 Dataset Splits

### 5.2 数据集划分

Zero-shot learning assumes disjoint training and test classes. Hence, as deep neural network (DNN) training for image feature extraction is actually a part of model training, the dataset used to train DNNs, e.g., ImageNet, should not include any of the test classes. However, we notice from the standard splits (SS) of aPY and AWA1 datasets that 7 aPY test classes out of 12 (monkey, wolf, zebra, mug, building, bag, carriage), 6 AWA1 test classes out of 10 (chimpanzee, giant panda, leopard, persian cat, pig, hippopotamus), are among the $1\mathrm{\;K}$ classes of ImageNet, i.e., are used to pre-train ResNet. On the other hand, the mostly widely used splits, i.e., we term them as standard splits (SS), for SUN from [1] and CUB from [8] shows us that 1 CUB test class out of 50 (Indigo Bunting), and 6 SUN test classes out of 72 (restaurant, supermarket, planetarium, tent, market, bridge), are also among the 1K classes of ImageNet.

零样本学习假设训练类别和测试类别是不相交的。因此，由于用于图像特征提取的深度神经网络(DNN)训练实际上是模型训练的一部分，用于训练DNN的数据集(例如ImageNet)不应包含任何测试类别。然而，我们从aPY和AWA1数据集的标准划分(SS)中注意到，12个aPY测试类别中有7个(猴子、狼、斑马、杯子、建筑物、包、马车)，10个AWA1测试类别中有6个(黑猩猩、大熊猫、豹、波斯猫、猪、河马)，都在ImageNet的$1\mathrm{\;K}$个类别之中，即用于预训练ResNet。另一方面，[1]中SUN数据集和[8]中CUB数据集最广泛使用的划分，即我们称之为标准划分(SS)，显示出50个CUB测试类别中有1个(靛蓝彩鹀)，72个SUN测试类别中有6个(餐厅、超市、天文馆、帐篷、市场、桥梁)，也在ImageNet的1000个类别之中。

We noticed that the accuracy for all methods on those overlapping test classes are higher than others. Therefore, we propose new dataset splits, i.e., proposed splits (PS), insuring that none of the test classes appear in ImageNet 1K, i.e., used to train the ResNet model. We present the differences between the standard splits (SS) and the proposed splits (PS) in Table 1. While in SS and PS no image from test classes is present at training time, at test time our PS includes images from training classes. We designed the PS this way as evaluating accuracy on both training and test classes is crucial to show the generalization of the methods.

我们注意到，所有方法在那些重叠测试类别上的准确率都比其他类别高。因此，我们提出了新的数据集划分，即建议划分(PS)，确保没有一个测试类别出现在用于训练ResNet模型的ImageNet 1000个类别中。我们在表1中展示了标准划分(SS)和建议划分(PS)之间的差异。虽然在SS和PS中，训练时都没有测试类别的图像，但在测试时，我们的PS包含训练类别的图像。我们这样设计PS是因为在训练类别和测试类别上评估准确率对于展示方法的泛化能力至关重要。

For SUN, CUB, AWA1, aPY, and our proposed AWA2 dataset, for measuring the significance of the results, we propose 3 different splits of580,100,27,15and 27 training classes respectively while keeping 72,50,10,12 and 10 test classes the same. It is important to perform hyperparameter search on a disjoint set of validation set of65,50,13,5and 13 classes respectively. We keep the number of classes the same for SS and PS, however we choose different classes while making sure that the test classes do not overlap with the $1\mathrm{\;K}$ training classes of ImageNet.

对于SUN、CUB、AWA1、aPY和我们提出的AWA2数据集，为了衡量结果的显著性，我们分别提出了580、100、27、15和27个训练类别的3种不同划分，同时保持72、50、10、12和10个测试类别不变。分别在65、50、13、5和13个类别的不相交验证集上进行超参数搜索是很重要的。我们为SS和PS保持相同的类别数量，但选择不同的类别，同时确保测试类别与ImageNet的$1\mathrm{\;K}$个训练类别不重叠。

ImageNet provides possibilities of constructing several zero-shot evaluation splits. Following [14], our first two standard splits consider all the classes that are 2-hops and 3-hops away from the original $1\mathrm{\;K}$ classes according to the ImageNet label hierarchy, corresponding to 1509 and 7678 classes. This split measures the generalization ability of the models with respect to the hierarchical and semantic similarity between classes. As discussed in the previous section, another characteristic of ImageNet is the imbalanced sample size. Therefore, our proposed split considers ${500},1\mathrm{\;K}$ and $5\mathrm{\;K}$ most populated classes among the remaining ${21}\mathrm{\;K}$ classes of ImageNet with approximately 1756, 1624 and 1335 images per class on average. Similarly, we consider ${500},1\mathrm{\;K}$ and $5\mathrm{\;K}$ least-populated classes in ImageNet which correspond to most fine-grained subsets of ImageNet with approximately 1,3 and 51 images per class on average. We measure the generalization of methods to the entire ImageNet data distribution by considering a final split of all the remaining approximately ${20}\mathrm{\;K}$ classes of ImageNet with at least 1 image per-class, i.e., approximately 631 images per class on average.

ImageNet为构建多个零样本评估划分提供了可能性。遵循文献[14]，我们的前两个标准划分考虑了根据ImageNet标签层次结构与原始$1\mathrm{\;K}$个类别相距2跳和3跳的所有类别，分别对应1509个和7678个类别。这种划分衡量了模型相对于类别之间的层次和语义相似性的泛化能力。如前一节所述，ImageNet的另一个特点是样本数量不平衡。因此，我们提出的划分考虑了ImageNet剩余${21}\mathrm{\;K}$个类别中${500},1\mathrm{\;K}$和$5\mathrm{\;K}$个样本最多的类别，平均每个类别约有1756、1624和1335张图像。同样，我们考虑了ImageNet中${500},1\mathrm{\;K}$和$5\mathrm{\;K}$个样本最少的类别，这些类别对应于ImageNet中最细粒度的子集，平均每个类别约有1、3和51张图像。我们通过考虑ImageNet所有剩余约${20}\mathrm{\;K}$个类别(每个类别至少有1张图像，即平均每个类别约631张图像)的最终划分，来衡量方法对整个ImageNet数据分布的泛化能力。

### 5.3 Evaluation Criteria

### 5.3 评估标准

Single label image classification accuracy has been measured with Top-1 accuracy, i.e., the prediction is accurate when the predicted class is the correct one. If the accuracy is averaged for all images, high performance on densely Authorized licensed use limited to: JILIN UNIVERSITY. Downloaded on March 26,2025 at 13:28:11 UTC from IEEE Xplore. Restrictions apply. populated classes is encouraged. However, we are interested in having high performance also on sparsely populated classes. Therefore, we average the correct predictions independently for each class before dividing their cumulative sum w.r.t the number of classes, i.e., we measure average per-class top-1 accuracy in the following way:

单标签图像分类准确率是用Top - 1准确率来衡量的，即当预测的类别是正确类别时，预测就是准确的。如果对所有图像的准确率进行平均，那么在样本密集的类别上的高性能会得到鼓励。然而，我们也希望在样本稀疏的类别上有高性能。因此，我们在将每个类别的正确预测的累积和除以类别数量之前，先独立地对每个类别的正确预测进行平均，即我们用以下方式衡量平均每个类别的Top - 1准确率:

$$
{acc}\mathcal{Y} = \frac{1}{\parallel \mathcal{Y}\parallel }\mathop{\sum }\limits_{{c = 1}}^{{\parallel \mathcal{Y}\parallel }}\frac{\# \text{ correct predictions in }\mathrm{c}}{\# \text{ samples in }\mathrm{c}}. \tag{21}
$$

---

1. Our benchmark is in: http://www.mpi-inf.mpg.de/zsl-benchmark

1. 我们的基准测试地址为:http://www.mpi - inf.mpg.de/zsl - benchmark

---

TABLE 2

Reproducing Zero-Shot Results with Methods That Have a Public Implementation: $O =$ Original Results, $R =$ Reproduced Using Provided Image Features and Code

使用具有公开实现的方法重现零样本结果:$O =$ 原始结果，$R =$ 使用提供的图像特征和代码重现的结果

<table><tr><td rowspan="2">Model</td><td colspan="2">SUN</td><td colspan="2">CUB</td><td colspan="2">AWA1</td><td colspan="2">aPY</td></tr><tr><td>R</td><td>O</td><td>R</td><td>O</td><td>R</td><td>O</td><td>R</td><td>O</td></tr><tr><td>DAP [1]</td><td>22.1</td><td>22.2</td><td>-</td><td>-</td><td>41.4</td><td>41.4</td><td>19.1</td><td>19.1</td></tr><tr><td>SSE [13]</td><td>83.0</td><td>82.5</td><td>44.2</td><td>30.4</td><td>64.9</td><td>76.3</td><td>45.7</td><td>46.2</td></tr><tr><td>LATEM [11]</td><td>-</td><td>-</td><td>45.1</td><td>45.5</td><td>71.2</td><td>71.9</td><td>-</td><td>-</td></tr><tr><td>SJE [9]</td><td>-</td><td>-</td><td>50.1</td><td>50.1</td><td>67.2</td><td>66.7</td><td>-</td><td>-</td></tr><tr><td>ESZSL [10]</td><td>64.3</td><td>65.8</td><td>-</td><td>-</td><td>48.0</td><td>49.3</td><td>14.3</td><td>15.1</td></tr><tr><td>SYNC [14]</td><td>62.8</td><td>62.8</td><td>53.4</td><td>53.4</td><td>69.7</td><td>69.7</td><td>-</td><td>-</td></tr><tr><td>SAE [33]</td><td>-</td><td>-</td><td>-</td><td>-</td><td>84.7</td><td>84.7</td><td>-</td><td>-</td></tr><tr><td>GFZSL [41]</td><td>86.5</td><td>86.5</td><td>56.6</td><td>56.5</td><td>80.4</td><td>80.8</td><td>-</td><td>-</td></tr><tr><td>GFZSL-tran [41]</td><td>87.0</td><td>87.0</td><td>63.8</td><td>63.7</td><td>94.9</td><td>94.3</td><td>-</td><td>-</td></tr><tr><td>DSRL [71]</td><td>86.0</td><td>85.4</td><td>57.6</td><td>57.1</td><td>87.7</td><td>87.2</td><td>47.8</td><td>51.3</td></tr></table>

<table><tbody><tr><td rowspan="2">模型</td><td colspan="2">太阳(SUN)</td><td colspan="2">加州大学伯克利分校鸟类数据集(CUB)</td><td colspan="2">动物属性数据集1(AWA1)</td><td colspan="2">属性化的人数据集(aPY)</td></tr><tr><td>R</td><td>O</td><td>R</td><td>O</td><td>R</td><td>O</td><td>R</td><td>O</td></tr><tr><td>判别式属性预测(DAP) [1]</td><td>22.1</td><td>22.2</td><td>-</td><td>-</td><td>41.4</td><td>41.4</td><td>19.1</td><td>19.1</td></tr><tr><td>半监督嵌入(SSE) [13]</td><td>83.0</td><td>82.5</td><td>44.2</td><td>30.4</td><td>64.9</td><td>76.3</td><td>45.7</td><td>46.2</td></tr><tr><td>潜在属性嵌入模型(LATEM) [11]</td><td>-</td><td>-</td><td>45.1</td><td>45.5</td><td>71.2</td><td>71.9</td><td>-</td><td>-</td></tr><tr><td>结构化联合嵌入(SJE) [9]</td><td>-</td><td>-</td><td>50.1</td><td>50.1</td><td>67.2</td><td>66.7</td><td>-</td><td>-</td></tr><tr><td>端到端零样本学习(ESZSL) [10]</td><td>64.3</td><td>65.8</td><td>-</td><td>-</td><td>48.0</td><td>49.3</td><td>14.3</td><td>15.1</td></tr><tr><td>同步零样本学习(SYNC) [14]</td><td>62.8</td><td>62.8</td><td>53.4</td><td>53.4</td><td>69.7</td><td>69.7</td><td>-</td><td>-</td></tr><tr><td>堆叠自动编码器(SAE) [33]</td><td>-</td><td>-</td><td>-</td><td>-</td><td>84.7</td><td>84.7</td><td>-</td><td>-</td></tr><tr><td>生成式特征零样本学习(GFZSL) [41]</td><td>86.5</td><td>86.5</td><td>56.6</td><td>56.5</td><td>80.4</td><td>80.8</td><td>-</td><td>-</td></tr><tr><td>生成式特征零样本学习-迁移(GFZSL - tran) [41]</td><td>87.0</td><td>87.0</td><td>63.8</td><td>63.7</td><td>94.9</td><td>94.3</td><td>-</td><td>-</td></tr><tr><td>深度语义表示学习(DSRL) [71]</td><td>86.0</td><td>85.4</td><td>57.6</td><td>57.1</td><td>87.7</td><td>87.2</td><td>47.8</td><td>51.3</td></tr></tbody></table>

We measure top-1 accuracy in $\%$ . -: image features are not provided in the original paper for this dataset. Top: ZSL, Bottom: transductive ZSL.

我们在$\%$中测量了前1准确率。 -: 原文未提供该数据集的图像特征。顶部:零样本学习(ZSL)，底部:直推式零样本学习(transductive ZSL)。

In the generalized zero-shot learning setting, the search space at evaluation time is not restricted to only test classes $\left( {\mathcal{Y}}^{ts}\right)$ , but includes also the training classes $\left( {\mathcal{Y}}^{tr}\right)$ , hence this setting is more practical. As with our proposed split at test time we have access to some images from training classes, after having computed the average per-class top-1 accuracy on training and test classes, we compute the harmonic mean of training and test accuracies:

在广义零样本学习设置中，评估时的搜索空间并不局限于测试类别$\left( {\mathcal{Y}}^{ts}\right)$，还包括训练类别$\left( {\mathcal{Y}}^{tr}\right)$，因此这种设置更具实用性。由于在测试时我们可以获取训练类别的一些图像，在计算了训练类别和测试类别的每类平均前1准确率后，我们计算训练准确率和测试准确率的调和平均数:

$$
H = \frac{2 * {ac}{c}_{{\mathcal{Y}}^{tr}} * {ac}{c}_{{\mathcal{Y}}^{ts}}}{{ac}{c}_{{\mathcal{Y}}^{tr}} + {ac}{c}_{{\mathcal{Y}}^{ts}}}. \tag{22}
$$

where ${ac}{c}_{ytr}$ and ${ac}{c}_{yts}$ represent the accuracy of images from seen $\left( {\mathcal{Y}}^{tr}\right)$ , and images from unseen $\left( {\mathcal{Y}}^{ts}\right)$ classes respectively. We choose harmonic mean as our evaluation criteria and not arithmetic mean because in arithmetic mean if the seen class accuracy is much higher, it effects the overall results significantly. Instead, our aim is high accuracy on both seen and unseen classes.

其中${ac}{c}_{ytr}$和${ac}{c}_{yts}$分别表示可见类别$\left( {\mathcal{Y}}^{tr}\right)$的图像和不可见类别$\left( {\mathcal{Y}}^{ts}\right)$的图像的准确率。我们选择调和平均数作为评估标准，而不是算术平均数，因为在算术平均数中，如果可见类别准确率高很多，会对整体结果产生显著影响。相反，我们的目标是在可见类别和不可见类别上都实现较高的准确率。

## 6 EXPERIMENTS

## 6 实验

We first provide ZSL results on the attribute datasets SUN, CUB, AWA1, AWA2 and aPY and then on the large-scale ImageNet dataset. Finally, we present results for the GZSL setting.

我们首先给出属性数据集SUN、CUB、AWA1、AWA2和aPY上的零样本学习结果，然后给出大规模ImageNet数据集上的结果。最后，我们给出广义零样本学习(GZSL)设置下的结果。

### 6.1 Zero-Shot Learning Experiments

### 6.1 零样本学习实验

On attribute datasets, i.e., SUN, CUB, AWA1, AWA2, and aPY, we first reproduce the results of each method using their evaluation protocol, then provide a unified evaluation protocol using the same train/val/test class splits, followed by our proposed train/val/test class splits on SUN, CUB, AWA1, aPY and AWA2. We also evaluate the robustness of the methods to parameter tuning and visualize the ranking of different methods. Finally, we evaluate the methods on the large-scale ImageNet dataset.

在属性数据集，即SUN、CUB、AWA1、AWA2和aPY上，我们首先使用每种方法的评估协议重现其结果，然后使用相同的训练/验证/测试类别划分提供统一的评估协议，接着在SUN、CUB、AWA1、aPY和AWA2上采用我们提出的训练/验证/测试类别划分。我们还评估了这些方法对参数调整的鲁棒性，并可视化不同方法的排名。最后，我们在大规模ImageNet数据集上评估这些方法。

TABLE 3

Zero-Shot Learning Results on SUN, CUB, AWA1, AWA2 and aPY Using SS = Standard Split, PS = Proposed Split with ResNet Features

使用SS = 标准划分，PS = 采用ResNet特征的建议划分，在SUN、CUB、AWA1、AWA2和aPY上的零样本学习结果

<table><tr><td rowspan="2">Method</td><td colspan="2">SUN</td><td colspan="2">CUB</td><td colspan="2">AWA1</td><td colspan="2">AWA2</td><td colspan="2">aPY</td></tr><tr><td>SS</td><td>PS</td><td>SS</td><td>PS</td><td>SS</td><td>PS</td><td>SS</td><td>PS</td><td>SS</td><td>PS</td></tr><tr><td>DAP [1]</td><td>38.9</td><td>39.9</td><td>37.5</td><td>40.0</td><td>57.1</td><td>44.1</td><td>58.7</td><td>46.1</td><td>35.2</td><td>33.8</td></tr><tr><td>IAP [1]</td><td>17.4</td><td>19.4</td><td>27.1</td><td>24.0</td><td>48.1</td><td>35.9</td><td>46.9</td><td>35.9</td><td>22.4</td><td>36.6</td></tr><tr><td>CONSE [15]</td><td>44.2</td><td>38.8</td><td>36.7</td><td>34.3</td><td>63.6</td><td>45.6</td><td>67.9</td><td>44.5</td><td>25.9</td><td>26.9</td></tr><tr><td>CMT [12]</td><td>41.9</td><td>39.9</td><td>37.3</td><td>34.6</td><td>58.9</td><td>39.5</td><td>66.3</td><td>37.9</td><td>26.9</td><td>28.0</td></tr><tr><td>SSE [13]</td><td>54.5</td><td>51.5</td><td>43.7</td><td>43.9</td><td>68.8</td><td>60.1</td><td>67.5</td><td>61.0</td><td>31.1</td><td>34.0</td></tr><tr><td>LATEM [11]</td><td>56.9</td><td>55.3</td><td>49.4</td><td>49.3</td><td>74.8</td><td>55.1</td><td>68.7</td><td>55.8</td><td>34.5</td><td>35.2</td></tr><tr><td>ALE [30]</td><td>59.1</td><td>58.1</td><td>53.2</td><td>54.9</td><td>78.6</td><td>59.9</td><td>80.3</td><td>62.5</td><td>30.9</td><td>39.7</td></tr><tr><td>DEVISE [7]</td><td>57.5</td><td>56.5</td><td>53.2</td><td>52.0</td><td>72.9</td><td>54.2</td><td>68.6</td><td>59.7</td><td>35.4</td><td>39.8</td></tr><tr><td>SJE [9]</td><td>57.1</td><td>53.7</td><td>55.3</td><td>53.9</td><td>76.7</td><td>65.6</td><td>69.5</td><td>61.9</td><td>32.0</td><td>32.9</td></tr><tr><td>ESZSL [10]</td><td>57.3</td><td>54.5</td><td>55.1</td><td>53.9</td><td>74.7</td><td>58.2</td><td>75.6</td><td>58.6</td><td>34.4</td><td>38.3</td></tr><tr><td>SYNC [14]</td><td>59.1</td><td>56.3</td><td>54.1</td><td>55.6</td><td>72.2</td><td>54.0</td><td>71.2</td><td>46.6</td><td>39.7</td><td>23.9</td></tr><tr><td>SAE [33]</td><td>42.4</td><td>40.3</td><td>33.4</td><td>33.3</td><td>80.6</td><td>53.0</td><td>80.7</td><td>54.1</td><td>8.3</td><td>8.3</td></tr><tr><td>GFZSL [41]</td><td>62.9</td><td>60.6</td><td>53.0</td><td>49.3</td><td>80.5</td><td>68.3</td><td>79.3</td><td>63.8</td><td>51.3</td><td>38.4</td></tr></table>

<table><tbody><tr><td rowspan="2">方法</td><td colspan="2">太阳(SUN)</td><td colspan="2">加州理工学院鸟类数据集(CUB)</td><td colspan="2">动物属性数据集1(AWA1)</td><td colspan="2">动物属性数据集2(AWA2)</td><td colspan="2">属性金字塔数据集(aPY)</td></tr><tr><td>半监督(SS)</td><td>部分监督(PS)</td><td>半监督(SS)</td><td>部分监督(PS)</td><td>半监督(SS)</td><td>部分监督(PS)</td><td>半监督(SS)</td><td>部分监督(PS)</td><td>半监督(SS)</td><td>部分监督(PS)</td></tr><tr><td>判别式属性预测(DAP [1])</td><td>38.9</td><td>39.9</td><td>37.5</td><td>40.0</td><td>57.1</td><td>44.1</td><td>58.7</td><td>46.1</td><td>35.2</td><td>33.8</td></tr><tr><td>生成式属性预测(IAP [1])</td><td>17.4</td><td>19.4</td><td>27.1</td><td>24.0</td><td>48.1</td><td>35.9</td><td>46.9</td><td>35.9</td><td>22.4</td><td>36.6</td></tr><tr><td>一致性学习(CONSE [15])</td><td>44.2</td><td>38.8</td><td>36.7</td><td>34.3</td><td>63.6</td><td>45.6</td><td>67.9</td><td>44.5</td><td>25.9</td><td>26.9</td></tr><tr><td>跨模态转换(CMT [12])</td><td>41.9</td><td>39.9</td><td>37.3</td><td>34.6</td><td>58.9</td><td>39.5</td><td>66.3</td><td>37.9</td><td>26.9</td><td>28.0</td></tr><tr><td>语义空间嵌入(SSE [13])</td><td>54.5</td><td>51.5</td><td>43.7</td><td>43.9</td><td>68.8</td><td>60.1</td><td>67.5</td><td>61.0</td><td>31.1</td><td>34.0</td></tr><tr><td>后期嵌入模型(LATEM [11])</td><td>56.9</td><td>55.3</td><td>49.4</td><td>49.3</td><td>74.8</td><td>55.1</td><td>68.7</td><td>55.8</td><td>34.5</td><td>35.2</td></tr><tr><td>对抗学习嵌入(ALE [30])</td><td>59.1</td><td>58.1</td><td>53.2</td><td>54.9</td><td>78.6</td><td>59.9</td><td>80.3</td><td>62.5</td><td>30.9</td><td>39.7</td></tr><tr><td>深度视觉语义嵌入(DEVISE [7])</td><td>57.5</td><td>56.5</td><td>53.2</td><td>52.0</td><td>72.9</td><td>54.2</td><td>68.6</td><td>59.7</td><td>35.4</td><td>39.8</td></tr><tr><td>结构化联合嵌入(SJE [9])</td><td>57.1</td><td>53.7</td><td>55.3</td><td>53.9</td><td>76.7</td><td>65.6</td><td>69.5</td><td>61.9</td><td>32.0</td><td>32.9</td></tr><tr><td>端到端零样本学习(ESZSL [10])</td><td>57.3</td><td>54.5</td><td>55.1</td><td>53.9</td><td>74.7</td><td>58.2</td><td>75.6</td><td>58.6</td><td>34.4</td><td>38.3</td></tr><tr><td>同步训练(SYNC [14])</td><td>59.1</td><td>56.3</td><td>54.1</td><td>55.6</td><td>72.2</td><td>54.0</td><td>71.2</td><td>46.6</td><td>39.7</td><td>23.9</td></tr><tr><td>堆叠自动编码器(SAE [33])</td><td>42.4</td><td>40.3</td><td>33.4</td><td>33.3</td><td>80.6</td><td>53.0</td><td>80.7</td><td>54.1</td><td>8.3</td><td>8.3</td></tr><tr><td>广义零样本学习(GFZSL [41])</td><td>62.9</td><td>60.6</td><td>53.0</td><td>49.3</td><td>80.5</td><td>68.3</td><td>79.3</td><td>63.8</td><td>51.3</td><td>38.4</td></tr></tbody></table>

The results report top-1 accuracy in %.

结果以百分比形式报告了前1准确率。

Comparing State-of-The-Art Models. For sanity-check, we reevaluate methods [1], [9], [10], [11], [13], [14] and [33] using publicly available features and code from the original publication on SUN, CUB, AWA1 and aPY (CMT [12] evaluates on CIFAR dataset.). We observe from the results in Table 2 that our reproduced results of DAP [1], SYNC [14], GFZSL [41], GFZSL-tran [41], DSRL [71] and SAE [33] are nearly identical to the reported number in their original publications. For LATEM [11], we obtain slightly different results which can be explained by the non-convexity and thus the sensibility to initialization. Similarly for SJE [9] random sampling in SGD might lead to slightly different results. ESZSL [10] has some variance because its algorithm randomly picks a validation set during each run, which leads to different hyperpara-meters. Notable observations on SSE [13] results are as follows. The published code has hard-coded hyperparameters operational on aPY, i.e., number of iterations, number of data points to train SVM, and one regularizer parameter $\gamma$ which lead to inferior results than the ones reported here, therefore we set these parameters on validation sets. On SUN, SSE uses 10 classes (instead of 72) and our results with validated parameters got an improvement of 0.5 percent that may be due to random sampling of training images. On AWA1, our reproduced result being 64.9 percent is significantly lower than the reported result (76.3 percent). However, we could not reach the reported result even by tuning parameters on the test set (73.8 percent).

比较最先进的模型。为了进行合理性检查，我们使用原始出版物中公开可用的特征和代码，在SUN、CUB、AWA1和aPY数据集上重新评估了方法[1]、[9]、[10]、[11]、[13]、[14]和[33](CMT [12]在CIFAR数据集上进行评估)。从表2的结果中我们观察到，我们对DAP [1]、SYNC [14]、GFZSL [41]、GFZSL - tran [41]、DSRL [71]和SAE [33]的复现结果与它们原始出版物中报告的数值几乎相同。对于LATEM [11]，我们得到的结果略有不同，这可以用非凸性以及对初始化的敏感性来解释。同样，对于SJE [9]，随机梯度下降(SGD)中的随机采样可能会导致结果略有不同。ESZSL [10]存在一些差异，因为其算法在每次运行时会随机选择一个验证集，这会导致不同的超参数。关于SSE [13]结果的显著观察如下。已发布的代码对aPY数据集硬编码了超参数，即迭代次数、训练支持向量机(SVM)的数据点数和一个正则化参数$\gamma$，这导致结果比这里报告的结果差，因此我们在验证集上设置这些参数。在SUN数据集上，SSE使用了10个类别(而不是72个)，并且我们使用验证后的参数得到的结果提高了0.5个百分点，这可能是由于训练图像的随机采样。在AWA1数据集上，我们的复现结果为64.9%，明显低于报告的结果(76.3%)。然而，即使我们在测试集上调整参数(达到73.8%)，也无法达到报告的结果。

In addition to [1], [9], [10], [11], [12], [13], [14], [33], we reimplement [7], [15], [30] based on the original publications. We use train, validation, test splits as provided in Table 1 and report results in Table 3 with deep ResNet features. DAP [1] uses hand-crafted image features and thus reproduced results with those features are significantly lower than the results with deep features (22.1 versus 38.9 percent). When we investigate the results in detail, we noticed two irregularities with reported results on SUN. First, SSE [13] and ESZSL [10] report results on a test split with 10 classes whereas the standard split of SUN contains 72 test classes (74.5 versus 54.5 percent with SSE [13] and 64.3 versus 57.3 percent with ESZSL [10]). Second, after careful examination and correspondence with the authors of SYNC [14], we detected that SUN features were extracted with a MIT Places [74] pre-trained model. As the MIT Places dataset intersects with both training and test classes of SUN, it is expected to lead to significantly better results than ImageNet pre-trained models (62.8 versus 59.1 percent). In addition, while SAE [33] reported 84.7 percent on AWA1, we obtain only 80.7 percent on the standard split. This could be explained by two differences. First, we measure per-class accuracy but SAE [33] reports per-image accuracy which is typically higher when the dataset is class-imbalanced, e.g., AWA1. Indeed, their reported accuracy decreases to 82.0 percent if per-class accuracy is applied. Second, we confirmed with the authors of SAE [33] that they improved Goo-gleNet [75] by adding Batch Normalization and averaging 5 randomly cropped images to obtain better image features. Therefore, as expected, improving visual features lead to improved results in zero-shot learning.

除了[1]、[9]、[10]、[11]、[12]、[13]、[14]、[33]之外，我们还根据原始出版物重新实现了[7]、[15]、[30]。我们使用表1中提供的训练集、验证集和测试集划分，并在表3中报告使用深度ResNet特征的结果。DAP [1]使用手工制作的图像特征，因此使用这些特征的复现结果明显低于使用深度特征的结果(22.1%对38.9%)。当我们详细研究结果时，我们注意到在SUN数据集上报告的结果存在两个异常情况。首先，SSE [13]和ESZSL [10]报告的是在一个包含10个类别的测试划分上的结果，而SUN的标准划分包含72个测试类别(SSE [13]的结果为74.5%对54.5%，ESZSL [10]的结果为64.3%对57.3%)。其次，在仔细检查并与SYNC [14]的作者沟通后，我们发现SUN特征是使用一个在MIT Places [74]上预训练的模型提取的。由于MIT Places数据集与SUN的训练类和测试类都有交集，预计它会比在ImageNet上预训练的模型得到显著更好的结果(62.8%对59.1%)。此外，虽然SAE [33]在AWA1上报告的准确率为84.7%，但我们在标准划分上只得到了80.7%。这可以用两个差异来解释。首先，我们测量的是每类准确率，而SAE [33]报告的是每图像准确率，当数据集存在类别不平衡时(如AWA1)，每图像准确率通常更高。实际上，如果应用每类准确率，他们报告的准确率会降至82.0%。其次，我们与SAE [33]的作者确认，他们通过添加批量归一化(Batch Normalization)并对5张随机裁剪的图像求平均来改进GoogLeNet [75]，以获得更好的图像特征。因此，正如预期的那样，改进视觉特征会在零样本学习中带来更好的结果。

![0195d2b1-719e-720b-bdb3-2e8d7e8c28b6_8_88_122_1535_518_0.jpg](images/0195d2b1-719e-720b-bdb3-2e8d7e8c28b6_8_88_122_1535_518_0.jpg)

Fig. 3. Robustness of 10 methods evaluated on SUN, CUB, AWA1, aPY using 3 validation set splits (results are on the same test split). Top: original split, Bottom: proposed split (Image embeddings = ResNet). We measure top-1 accuracy in %.

图3. 使用3种验证集划分在SUN、CUB、AWA1、aPY数据集上评估的10种方法的鲁棒性(结果基于相同的测试划分)。上:原始划分，下:提出的划分(图像嵌入 = ResNet)。我们以百分比形式测量前1准确率。

Promoting Our Proposed Splits (PS). We propose new dataset splits (see details in Section 4) ensuring that test classes of any of the datasets do not overlap with the ImageNet $1\mathrm{\;K}$ used to pre-train ResNet. As training ResNet is a part of the training procedure, including test classes in the dataset used for pre-training ResNet would violate the zero-shot learning conditions. We compare the results obtained with our proposed split (PS) with previously published standard split (SS) results in Table 3.

推广我们提出的划分(PS)。我们提出了新的数据集划分(详见第4节)，以确保任何数据集的测试类都不与用于预训练ResNet的ImageNet $1\mathrm{\;K}$重叠。由于训练ResNet是训练过程的一部分，将测试类包含在用于预训练ResNet的数据集中会违反零样本学习的条件。我们在表3中比较了使用我们提出的划分(PS)得到的结果与之前发表的标准划分(SS)的结果。

Our first observation is that the results on the PS are significantly lower than the SS for AWA1 and AWA2. This is expected as most of the test classes of AWA1 and AWA2 in SS overlaps with ImageNet 1K. On the other hand, for fine-grained datasets CUB and SUN, the results are not significantly effected as the overlap in that case was not as significant. Our second observation regarding the method ranking is as follows. On SS, SYNC [14] is the best performing method on SUN (59.1 percent) and aPY (39.7 percent) datasets whereas SJE [9] performs the best on CUB (55.3 percent) and SAE [33] performs the best on AWA1 (80.6 percent) and AWA2 (80.7 percent) dataset. On PS, ALE [30] performs the Authorized licensed use limited to: JILIN UNIVERSITY. Downloaded on March 26,2025 at 13:28:11 UTC from IEEE Xplore. Restrictions apply. best on SUN (58.1 percent) and AWA2 (62.5 percent), SYNC [14] on CUB (55.6 percent), SJE [9] on AWA1 (65.6 percent) and DEVISE [7] on aPY (39.8 percent). ALE, SJE and DEVISE all use max-margin bi-linear compatibility learning framework which seem to perform better than others. It is also worth to note that SYNC and SAE perform well on SS, i.e., SYNC is the best performing model for SUN and aPY whereas SAE is for AWA1 and AWA2 on SS, while they perform significantly lower in PS which indicates that they do not generalize well in zero-shot learning task.

我们的第一个观察结果是，对于AWA1和AWA2数据集，在提出的设置(PS)下的结果明显低于标准设置(SS)。这是意料之中的，因为在SS中，AWA1和AWA2的大多数测试类别与ImageNet 1K有重叠。另一方面，对于细粒度数据集CUB和SUN，结果没有受到显著影响，因为在这种情况下的重叠并不显著。我们关于方法排名的第二个观察结果如下。在SS上，SYNC [14]方法在SUN(59.1%)和aPY(39.7%)数据集上表现最佳，而SJE [9]方法在CUB(55.3%)数据集上表现最佳，SAE [33]方法在AWA1(80.6%)和AWA2(80.7%)数据集上表现最佳。在PS上，ALE [30]方法在SUN(58.1%)和AWA2(62.5%)数据集上表现最佳，SYNC [14]方法在CUB(55.6%)数据集上表现最佳，SJE [9]方法在AWA1(65.6%)数据集上表现最佳，DEVISE [7]方法在aPY(39.8%)数据集上表现最佳。ALE、SJE和DEVISE都使用最大间隔双线性兼容性学习框架，该框架似乎比其他方法表现更好。还值得注意的是，SYNC和SAE在SS上表现良好，即SYNC是SUN和aPY数据集上表现最佳的模型，而SAE是SS上AWA1和AWA2数据集上表现最佳的模型，但它们在PS上的表现明显较低，这表明它们在零样本学习任务中的泛化能力不佳。

Evaluating Robustness. We evaluate robustness of 13 methods, i.e., [1], [7], [9], [10], [11], [12], [13], [14], [15], [30], [33], [41], to hyperparameters by setting them on 3 different validation splits while keeping the test split intact. We report results on SS (Fig. 3, top) and PS (Fig. 3, bottom) for SUN, CUB, AWA1, AWA2 and aPY datasets. On SUN and CUB, the results are stable across methods and across dataset splits. This is expected as these datasets both have a balanced number of images across classes and they are fine-grained datasets. Therefore, the validation splits are similar. On the other hand, aPY being a small and coarse-grained dataset has several issues. First, many of the test classes of aPY are included in ImageNet1K. Second, it is not well balanced, i.e., different validation class splits contain significantly different number of images. Third, the class embeddings are far from each other, i.e., objects are semantically different, therefore different validation splits learn a different mapping between images and classes. On AWA1 and AWA2, on SS, the DEVISE method seems to show the largest variance. This might be due to the fact that AWA1 and AWA2 datasets are also coarse-grained and test classes overlap with ImageNet training classes. Indeed, AWA2 being slightly more balanced than AWA1, in the proposed split it does not lead to such a high variance for DEVISE.

评估鲁棒性。我们通过在3种不同的验证分割上设置超参数，同时保持测试分割不变，来评估13种方法(即[1]、[7]、[9]、[10]、[11]、[12]、[13]、[14]、[15]、[30]、[33]、[41])对超参数的鲁棒性。我们报告了在SS(图3，上)和PS(图3，下)上，SUN、CUB、AWA1、AWA2和aPY数据集的结果。在SUN和CUB数据集上，各种方法和不同数据集分割的结果都很稳定。这是意料之中的，因为这两个数据集在各个类别中的图像数量都很均衡，并且它们都是细粒度数据集。因此，验证分割是相似的。另一方面，aPY作为一个小的粗粒度数据集存在几个问题。首先，aPY的许多测试类别包含在ImageNet1K中。其次，它的类别不均衡，即不同的验证类别分割包含的图像数量差异显著。第三，类别嵌入之间的距离很远，即对象在语义上不同，因此不同的验证分割会学习到图像和类别之间不同的映射关系。在AWA1和AWA2数据集的SS设置下，DEVISE方法的方差似乎最大。这可能是因为AWA1和AWA2数据集也是粗粒度的，并且测试类别与ImageNet训练类别有重叠。实际上，由于AWA2比AWA1稍微更均衡一些，在提出的分割中，DEVISE方法在AWA2上的方差没有那么大。

Visualizing Method Ranking. We first evaluate the 13 methods using three different validation splits as in the previous experiment. We then rank them based on their per-class top-1 accuracy using the non-parametric Friedman test [76], which does not assume a distribution on performance but rather uses algorithm ranking. Each entry of the rank matrix on Fig. 4 indicates the number of times the method is ranked at the first to thirteenth rank. We then compute the mean rank of each method and order them based on the mean rank across datasets.

可视化方法排名。我们首先像上一个实验一样，使用三种不同的验证分割来评估这13种方法。然后，我们使用非参数Friedman检验[76]根据它们的每类top - 1准确率对这些方法进行排名，该检验不假设性能服从某种分布，而是使用算法排名。图4中排名矩阵的每个元素表示该方法在第一到第十三名的排名次数。然后，我们计算每种方法的平均排名，并根据跨数据集的平均排名对它们进行排序。

![0195d2b1-719e-720b-bdb3-2e8d7e8c28b6_9_76_123_765_297_0.jpg](images/0195d2b1-719e-720b-bdb3-2e8d7e8c28b6_9_76_123_765_297_0.jpg)

Fig. 4. Ranking 12 models by setting parameters on three validation splits on the standard (SS, left) and proposed (PS, right) setting. Element(i, j)indicates number of times model $i$ ranks at $j$ th over all $4 \times  3$ observations. Models are ordered by their mean rank (displayed in brackets).

图4. 通过在标准设置(SS，左)和提出的设置(PS，右)下的三个验证分割上设置参数，对12个模型进行排名。元素(i, j)表示模型$i$在所有$4 \times  3$次观察中排名为$j$的次数。模型按其平均排名(括号内显示)排序。

Our general observation is that the highest ranked method on both splits is GFZSL, the second highest ranked method on the standard split (SS) is SYNC while it drops to the seventh rank on the proposed split (PS). On the other hand, ALE ranks the second on the SS and the first on the PS. We reinforce our initial observation from numerical results and conclude that GFZSL and ALE seems to be the method that is the most robust in zero-shot learning setting for attribute datasets. These results also indicate the importance of choosing zero-shot splits carefully. On the PS, the two of three highest ranked methods are compatibility learning methods, i.e., ALE and DEVISE whereas the three lowest ranked methods are attribute classifier learning or hybrid methods, i.e., IAP, CMT and CONSE. Therefore, max-margin compatibility learning methods lead to consistently better results in the zero-shot learning task compared to learning independent classifiers. Finally, visualizing the method ranking in this way provides a visually interpretable way of how models compare across datasets.

我们的总体观察结果是，在两种划分方式下排名最高的方法是广义零样本学习(GFZSL)，在标准划分(SS)下排名第二的方法是同步学习(SYNC)，但在我们提出的划分(PS)下它降至第七名。另一方面，属性标签嵌入(ALE)在标准划分下排名第二，在我们提出的划分下排名第一。我们通过数值结果强化了最初的观察，并得出结论:对于属性数据集的零样本学习设置，广义零样本学习(GFZSL)和属性标签嵌入(ALE)似乎是最稳健的方法。这些结果也表明了谨慎选择零样本划分的重要性。在我们提出的划分下，排名前三的方法中有两种是兼容性学习方法，即属性标签嵌入(ALE)和设备(DEVISE)，而排名后三的方法是属性分类器学习或混合方法，即改进的属性预测(IAP)、跨模态转移(CMT)和一致性学习(CONSE)。因此，与学习独立分类器相比，最大间隔兼容性学习方法在零样本学习任务中始终能取得更好的结果。最后，以这种方式可视化方法排名，为模型在不同数据集之间的比较提供了一种直观可解释的方式。

Results on Our Proposed AWA2. We introduce AWA2 which has the same classes and attributes as AWA1, but contains different images each coming with a public copyright license. In order to show that AWA1 and AWA2 images are not the same but similar in nature, we compare the zero-shot learning results on AWA1 and AWA2 in Table. 3. Under the Standard Splits (SS), SAE [33] is the best performing method on both AWA1 (80.6 percent) and AWA2 (80.7 percent). Similarly, for most of the methods, the results on AWA1 are close to those on AWA2, for instance, DAP obtains 57.1 percent on AWA1 and 58.7 percent on AWA2, SSE obtains 68.8 percent on AWA1 and 67.5 percent AWA2, etc. The results under the Proposed Splits (PS) are also consistent across AWA1 and AWA2. For 8 out of 12 methods, the performance difference between AWA1 and AWA2 is within 2 percent. On the other hand, the same consistency is not observed for DEVISE [7], SJE [9] and SYNC [14]. For instance, SJE [9] obtains 65.6 percent on AWA1 and 61.9 percent on AWA2. After careful examination, we noticed that SJE [9] selects different hyper-parameters for AWA1 and AWA2, which results in different performance on those two datasets. In our opinion, this does not indicate a possible dataset artifact, however shows that zero-shot learning is sensitive to parameter setting.

我们提出的AWA2数据集上的结果。我们引入了AWA2数据集，它与AWA1具有相同的类别和属性，但包含不同的图像，且每张图像都带有公开版权许可。为了表明AWA1和AWA2的图像虽然不同但本质上相似，我们在表3中比较了AWA1和AWA2上的零样本学习结果。在标准划分(SS)下，堆叠自编码器(SAE)[33]在AWA1(80.6%)和AWA2(80.7%)上都是表现最好的方法。同样，对于大多数方法，AWA1上的结果与AWA2上的结果相近，例如，判别式属性预测(DAP)在AWA1上的准确率为57.1%，在AWA2上为58.7%；半监督嵌入(SSE)在AWA1上的准确率为68.8%，在AWA2上为67.5%等。在我们提出的划分(PS)下，AWA1和AWA2上的结果也具有一致性。在12种方法中，有8种方法在AWA1和AWA2上的性能差异在2%以内。另一方面，设备(DEVISE)[7]、语义联合嵌入(SJE)[9]和同步学习(SYNC)[14]没有观察到同样的一致性。例如，语义联合嵌入(SJE)[9]在AWA1上的准确率为65.6%，在AWA2上为61.9%。经过仔细检查，我们注意到语义联合嵌入(SJE)[9]为AWA1和AWA2选择了不同的超参数，这导致了在这两个数据集上的性能不同。我们认为，这并不表明可能存在数据集伪影，而是表明零样本学习对参数设置很敏感。

Commonly, a model is trained and evaluated on the same dataset. Across dataset experiments are not easy as different datasets do not share the same attributes. However, AWA1 and AWA2 share both classes and attributes. In order to verify that AWA2 is a good replacement for Authorized licensed use limited to: JILIN UNIVERSITY. Downloaded on March 26,2025 at 13:28:11 UTC from IEEE Xplore. Restrictions apply. AWA1, we conduct across-dataset evaluation for 12 methods, i.e., [1], [7], [9], [10], [11], [12], [13], [14], [15], [30], [33]. In particular, with our Proposed Splits (PS), we train one model on the training set of AWA1 and evaluate it on the test set of AWA2 in the zero-shot learning setting, and vice versa. From Table. 4, we observe that all the models trained on AWA1 generalize well to AWA2 and vice versa.

通常情况下，模型在同一个数据集上进行训练和评估。跨数据集实验并不容易，因为不同的数据集不共享相同的属性。然而，AWA1和AWA2既共享类别又共享属性。为了验证AWA2是AWA1的一个很好的替代数据集(授权许可使用仅限于:吉林大学。于2025年3月26日13:28:11 UTC从IEEE Xplore下载。适用限制条款)，我们对12种方法进行了跨数据集评估，即[1]、[7]、[9]、[10]、[11]、[12]、[13]、[14]、[15]、[30]、[33]。具体来说，使用我们提出的划分(PS)，我们在AWA1的训练集上训练一个模型，并在零样本学习设置下在AWA2的测试集上进行评估，反之亦然。从表4中我们观察到，所有在AWA1上训练的模型都能很好地泛化到AWA2，反之亦然。

TABLE 4

Cross-Dataset Evaluation over AWA1 and AWA2 in Zero-Shot Learning Setting on the Proposed Splits: Left of the Colon Indicates the Training Set and Right of the Colon Indicates the Test Set, e.g., AWA1:AWA2 Means That the Model Is Trained on the Train Set of AWA1 and Evaluated on the Test Set of AWA2

在零样本学习设置下，对AWA1和AWA2在我们提出的划分上进行跨数据集评估:冒号左侧表示训练集，右侧表示测试集，例如，AWA1:AWA2表示模型在AWA1的训练集上训练，并在AWA2的测试集上进行评估

<table><tr><td rowspan="2">Method</td><td colspan="4">Training Set : Test Set</td></tr><tr><td>AWA1: AWA1</td><td>AWA1: AWA2</td><td>AWA2: AWA2</td><td>AWA2: AWA1</td></tr><tr><td>DAP [1]</td><td>44.1</td><td>44.2</td><td>46.1</td><td>46.2</td></tr><tr><td>IAP [1]</td><td>35.9</td><td>36.1</td><td>35.9</td><td>35.3</td></tr><tr><td>CONSE [15]</td><td>45.6</td><td>46.5</td><td>44.5</td><td>43.7</td></tr><tr><td>CMT [12]</td><td>39.5</td><td>40.7</td><td>37.9</td><td>37.7</td></tr><tr><td>SSE [13]</td><td>60.1</td><td>61.6</td><td>61.0</td><td>59.8</td></tr><tr><td>LATEM [11]</td><td>55.1</td><td>55.4</td><td>55.8</td><td>53.5</td></tr><tr><td>ALE [30]</td><td>59.9</td><td>59.9</td><td>62.5</td><td>60.9</td></tr><tr><td>DEVISE [7]</td><td>54.2</td><td>55.2</td><td>59.7</td><td>57.7</td></tr><tr><td>SJE [9]</td><td>65.6</td><td>65.5</td><td>61.9</td><td>62.0</td></tr><tr><td>ESZSL [10]</td><td>58.2</td><td>58.5</td><td>58.6</td><td>59.9</td></tr><tr><td>SYNC [14]</td><td>54.0</td><td>53.7</td><td>46.6</td><td>46.9</td></tr><tr><td>SAE [33]</td><td>53.0</td><td>52.4</td><td>54.1</td><td>53.1</td></tr></table>

<table><tbody><tr><td rowspan="2">方法</td><td colspan="4">训练集 : 测试集</td></tr><tr><td>AWA1: AWA1</td><td>AWA1: AWA2</td><td>AWA2: AWA2</td><td>AWA2: AWA1</td></tr><tr><td>判别式属性预测(Discriminative Attribute Prediction，DAP) [1]</td><td>44.1</td><td>44.2</td><td>46.1</td><td>46.2</td></tr><tr><td>生成式属性预测(Generative Attribute Prediction，IAP) [1]</td><td>35.9</td><td>36.1</td><td>35.9</td><td>35.3</td></tr><tr><td>一致性嵌入(Consistent Embedding，CONSE) [15]</td><td>45.6</td><td>46.5</td><td>44.5</td><td>43.7</td></tr><tr><td>跨模态转换(Cross-Modal Transformation，CMT) [12]</td><td>39.5</td><td>40.7</td><td>37.9</td><td>37.7</td></tr><tr><td>语义自编码器(Semantic Self-Encoder，SSE) [13]</td><td>60.1</td><td>61.6</td><td>61.0</td><td>59.8</td></tr><tr><td>潜在属性嵌入模型(Latent Attribute Embedding Model，LATEM) [11]</td><td>55.1</td><td>55.4</td><td>55.8</td><td>53.5</td></tr><tr><td>属性标签嵌入(Attribute Label Embedding，ALE) [30]</td><td>59.9</td><td>59.9</td><td>62.5</td><td>60.9</td></tr><tr><td>深度视觉语义嵌入模型(Deep Visual-Semantic Embedding Model，DEVISE) [7]</td><td>54.2</td><td>55.2</td><td>59.7</td><td>57.7</td></tr><tr><td>结构化联合嵌入(Structured Joint Embedding，SJE) [9]</td><td>65.6</td><td>65.5</td><td>61.9</td><td>62.0</td></tr><tr><td>端到端零样本学习(End-to-End Zero-Shot Learning，ESZSL) [10]</td><td>58.2</td><td>58.5</td><td>58.6</td><td>59.9</td></tr><tr><td>同步嵌入(Synchronized Embedding，SYNC) [14]</td><td>54.0</td><td>53.7</td><td>46.6</td><td>46.9</td></tr><tr><td>堆叠自编码器(Stacked Autoencoder，SAE) [33]</td><td>53.0</td><td>52.4</td><td>54.1</td><td>53.1</td></tr></tbody></table>

We measure top-1 accuracy in %.

我们以百分比衡量前1准确率。

In addition, we notice that the cross-dataset result is dependent on the training set. For instance, for all the methods, if we fix training set to be from AWA1, the results on the test set of AWA1 and AWA2 are close. To verify this hypothesis, we performed a paired t-test which determines if the mean difference between paired results is significantly higher than zero. To that end, we take the 24 pairs of results whose test sets are the same, i.e., the results obtained with 12 methods on AWA1: AWA2 and AWA2:AWA2 (2nd and 3rd column) as well as the results obtained with 12 methods on AWA1:AWA1 and AWA2:AWA1 (1st and 4th column). The paired t-test rejects the null hypothesis with p-value $= {0.007}$ , indicating that the results are significantly different if the test set is the same but the training set is different. As a conclusion, the training set is an important indicator of the final result and the two datasets, i.e., AWA1 and AWA2 are sufficiently similar. Therefore, our cross-dataset experimental results indicate that AWA2 is a good replacement for AWA1.

此外，我们注意到跨数据集的结果依赖于训练集。例如，对于所有方法，如果我们将训练集固定为来自AWA1，那么在AWA1和AWA2测试集上的结果相近。为了验证这一假设，我们进行了配对t检验，以确定配对结果之间的平均差异是否显著大于零。为此，我们选取了24对测试集相同的结果，即使用12种方法在AWA1:AWA2和AWA2:AWA2(第2列和第3列)上获得的结果，以及使用12种方法在AWA1:AWA1和AWA2:AWA1(第1列和第4列)上获得的结果。配对t检验以p值$= {0.007}$拒绝了原假设，这表明如果测试集相同但训练集不同，结果会有显著差异。综上所述，训练集是最终结果的一个重要指标，并且两个数据集，即AWA1和AWA2足够相似。因此，我们的跨数据集实验结果表明，AWA2是AWA1的一个很好的替代数据集。

Zero-Shot Learning Results on ImageNet. ImageNet scales the methods to a truly large-scale setting, thus these experiments provide further insights on how to tackle the zero-shot learning problem from the practical point of view. Here, we evaluate 10 methods, i.e., [7], [9], [10], [11], [12], [14], [15], [30], [33], [41]. We exclude DAP and IAP as attributes are not available for all ImageNet classes as well as SSE [13] due to scalability issues of the public implementation of the method. Table 5 shows that the best performing method is SYNC [14] which may either indicate that it performs well in large-scale setting or it can learn under uncertainty due to usage of Word2Vec instead of attributes. Another possibility is Word2Vec may be tuned for SYNC as it is provided by the same authors. However, we refrain to make a strong claim as this would requires a full evaluation on class embeddings which is out of the scope of this paper. On the other hand, GFZSL [41] which is the best performing model for attribute datasets perform poorly on ImageNet which may indicate that generative models require a strong class embedding space such as attributes to perform well on ZSL task. Note that due to the computational issues, we were not able to obtain results for GFZSL for $3\mathrm{H},\mathrm{M}5\mathrm{\;K},\mathrm{L}5\mathrm{\;K}$ and All 20K classes.

在ImageNet上的零样本学习结果。ImageNet将这些方法扩展到真正的大规模场景，因此这些实验从实际角度为如何解决零样本学习问题提供了进一步的见解。在这里，我们评估了10种方法，即[7]、[9]、[10]、[11]、[12]、[14]、[15]、[30]、[33]、[41]。我们排除了DAP和IAP，因为并非所有ImageNet类别都有可用的属性，同时排除了SSE [13]，因为该方法的公开实现存在可扩展性问题。表5显示，表现最佳的方法是SYNC [14]，这可能表明它在大规模场景中表现良好，或者由于使用了Word2Vec而不是属性，它能够在不确定的情况下进行学习。另一种可能性是，由于Word2Vec由同一作者提供，可能针对SYNC进行了调优。然而，我们避免做出强烈的断言，因为这需要对类别嵌入进行全面评估，而这超出了本文的范围。另一方面，GFZSL [41]是属性数据集上表现最佳的模型，但在ImageNet上表现不佳，这可能表明生成模型需要一个强大的类别嵌入空间(如属性)才能在零样本学习任务中表现良好。请注意，由于计算问题，我们无法获得GFZSL在$3\mathrm{H},\mathrm{M}5\mathrm{\;K},\mathrm{L}5\mathrm{\;K}$和所有20K类别的结果。

TABLE 5

ImageNet with Different Splits: $2/3\mathrm{H} =$ Classes with $2/3$ Hops Away from the ${\mathcal{Y}}^{tr}$ of ImageNet $1\mathrm{\;K},{500}/1\mathrm{\;K}/5\mathrm{\;K}$ Most Populated Classes, 500/1K/5K Least Populated Classes, All = The Remaining 20K Categories of ImageNet $\left( {\mathcal{Y}}^{ts}\right)$

不同划分的ImageNet:距离ImageNet ${\mathcal{Y}}^{tr}$ $2/3$跳的$2/3\mathrm{H} =$个类别 $1\mathrm{\;K},{500}/1\mathrm{\;K}/5\mathrm{\;K}$ 最密集的类别，500/1K/5K个最稀疏的类别，All = ImageNet剩余的20K个类别 $\left( {\mathcal{Y}}^{ts}\right)$

<table><tr><td rowspan="2">Method</td><td colspan="2">Hierarchy</td><td colspan="3">Most Populated</td><td colspan="3">Least Populated</td><td rowspan="2">All 20 K</td></tr><tr><td>$2\mathrm{H}$</td><td>$3\mathrm{H}$</td><td>500</td><td>1 K</td><td>5 K</td><td>500</td><td>1 K</td><td>5 K</td></tr><tr><td>CONSE [15]</td><td>7.63</td><td>2.18</td><td>12.33</td><td>8.31</td><td>3.22</td><td>3.53</td><td>2.69</td><td>1.05</td><td>0.95</td></tr><tr><td>CMT [12]</td><td>2.88</td><td>0.67</td><td>5.10</td><td>3.04</td><td>1.04</td><td>1.87</td><td>1.08</td><td>0.33</td><td>0.29</td></tr><tr><td>LATEM [11]</td><td>5.45</td><td>1.32</td><td>10.81</td><td>6.63</td><td>1.90</td><td>4.53</td><td>2.74</td><td>0.76</td><td>0.50</td></tr><tr><td>ALE [30]</td><td>5.38</td><td>1.32</td><td>10.40</td><td>6.77</td><td>2.00</td><td>4.27</td><td>2.85</td><td>0.79</td><td>0.50</td></tr><tr><td>DEVISE [7]</td><td>5.25</td><td>1.29</td><td>10.36</td><td>6.68</td><td>1.94</td><td>4.23</td><td>2.86</td><td>0.78</td><td>0.49</td></tr><tr><td>SJE [9]</td><td>5.31</td><td>1.33</td><td>9.88</td><td>6.53</td><td>1.99</td><td>4.93</td><td>2.93</td><td>0.78</td><td>0.52</td></tr><tr><td>ESZSL [10]</td><td>6.35</td><td>1.51</td><td>11.91</td><td>7.69</td><td>2.34</td><td>4.50</td><td>3.23</td><td>0.94</td><td>0.62</td></tr><tr><td>SYNC [14]</td><td>9.26</td><td>2.29</td><td>15.83</td><td>10.75</td><td>3.42</td><td>5.83</td><td>3.52</td><td>1.26</td><td>0.96</td></tr><tr><td>SAE [33]</td><td>4.89</td><td>1.26</td><td>9.96</td><td>6.57</td><td>2.09</td><td>2.50</td><td>2.17</td><td>0.72</td><td>0.56</td></tr><tr><td>GFZSL [41]</td><td>1.45</td><td>-</td><td>2.01</td><td>1.35</td><td>-</td><td>1.40</td><td>1.11</td><td>0.13</td><td>-</td></tr></table>

<table><tbody><tr><td rowspan="2">方法</td><td colspan="2">层次结构</td><td colspan="3">人口最多的</td><td colspan="3">人口最少的</td><td rowspan="2">全部20K</td></tr><tr><td>$2\mathrm{H}$</td><td>$3\mathrm{H}$</td><td>500</td><td>1 K</td><td>5 K</td><td>500</td><td>1 K</td><td>5 K</td></tr><tr><td>CONSE [15]</td><td>7.63</td><td>2.18</td><td>12.33</td><td>8.31</td><td>3.22</td><td>3.53</td><td>2.69</td><td>1.05</td><td>0.95</td></tr><tr><td>CMT [12]</td><td>2.88</td><td>0.67</td><td>5.10</td><td>3.04</td><td>1.04</td><td>1.87</td><td>1.08</td><td>0.33</td><td>0.29</td></tr><tr><td>LATEM [11]</td><td>5.45</td><td>1.32</td><td>10.81</td><td>6.63</td><td>1.90</td><td>4.53</td><td>2.74</td><td>0.76</td><td>0.50</td></tr><tr><td>ALE [30]</td><td>5.38</td><td>1.32</td><td>10.40</td><td>6.77</td><td>2.00</td><td>4.27</td><td>2.85</td><td>0.79</td><td>0.50</td></tr><tr><td>DEVISE [7]</td><td>5.25</td><td>1.29</td><td>10.36</td><td>6.68</td><td>1.94</td><td>4.23</td><td>2.86</td><td>0.78</td><td>0.49</td></tr><tr><td>SJE [9]</td><td>5.31</td><td>1.33</td><td>9.88</td><td>6.53</td><td>1.99</td><td>4.93</td><td>2.93</td><td>0.78</td><td>0.52</td></tr><tr><td>ESZSL [10]</td><td>6.35</td><td>1.51</td><td>11.91</td><td>7.69</td><td>2.34</td><td>4.50</td><td>3.23</td><td>0.94</td><td>0.62</td></tr><tr><td>SYNC [14]</td><td>9.26</td><td>2.29</td><td>15.83</td><td>10.75</td><td>3.42</td><td>5.83</td><td>3.52</td><td>1.26</td><td>0.96</td></tr><tr><td>SAE [33]</td><td>4.89</td><td>1.26</td><td>9.96</td><td>6.57</td><td>2.09</td><td>2.50</td><td>2.17</td><td>0.72</td><td>0.56</td></tr><tr><td>GFZSL [41]</td><td>1.45</td><td>-</td><td>2.01</td><td>1.35</td><td>-</td><td>1.40</td><td>1.11</td><td>0.13</td><td>-</td></tr></tbody></table>

We measure top-1 accuracy in %.

我们以百分比衡量前1准确率。

More detailed observations are as follows. The second highest performing method is ESZSL [10] which is one of the linear embedding models that have an implicit regularization mechanism, which seems to be more effective than early stopping as an explicit regularizer. A general observation from the results of all the methods is that in the most populated classes, the results are higher than the least populated classes which indicates that zero-shot learning on fine-grained ImageNet subsets is a more difficult task. Moreover, we conclude that the nature of the test set, e.g., type of the classes being tested, is more important than the number of classes. Therefore, the selection of the test set is an important aspect of zero-shot learning on large-scale datasets. Furthermore, for all methods we consistently observe a large drop in accuracy between $1\mathrm{\;K}$ and $5\mathrm{\;K}$ most populated classes which is expected as $5\mathrm{\;K}$ contains $\approx  {6.6}\mathrm{M}$ images, making the problem much more difficult than $1\mathrm{\;K}$ ( $\approx  {1624}$ images). It is worth to note that, measuring per-image accuracy in this case would lead to higher results if the labels of the highly populated class samples are predicted correctly. Finally, the largest test set, i.e., All ${20}\mathrm{\;K}$ , the results are poor for all methods which indicates the difficulty of this problem where there is a large room for improvement.

更详细的观察结果如下。表现第二好的方法是ESZSL [10]，它是具有隐式正则化机制的线性嵌入模型之一，作为一种正则化方法，这种隐式机制似乎比提前停止法(early stopping)这种显式正则化方法更有效。从所有方法的结果中可以得出一个普遍的观察结论:在样本数量最多的类别中，结果要高于样本数量最少的类别，这表明在细粒度的ImageNet子集上进行零样本学习是一项更具挑战性的任务。此外，我们得出结论，测试集的性质，例如所测试类别的类型，比类别数量更为重要。因此，测试集的选择是在大规模数据集上进行零样本学习的一个重要方面。此外，对于所有方法，我们始终观察到在样本数量最多的$1\mathrm{\;K}$和$5\mathrm{\;K}$类别之间准确率大幅下降，这是意料之中的，因为$5\mathrm{\;K}$包含$\approx  {6.6}\mathrm{M}$张图像，这使得问题比$1\mathrm{\;K}$($\approx  {1624}$张图像)困难得多。值得注意的是，在这种情况下，如果高样本数量类别样本的标签被正确预测，按图像计算准确率会得到更高的结果。最后，对于最大的测试集，即所有${20}\mathrm{\;K}$类别，所有方法的结果都很差，这表明这个问题存在很大的改进空间。

Several models in the literature evaluate Top-5 and Top-10 as well as Top-1 accuracy on ImageNet. Top-5 and Top-10 accuracy in this case is reasonable as an image usually contains multiple objects however by construction it is associated with a single label in ImageNet. Hence, we provide a comparison of the same 9 models according to all these three criteria in Fig. 5. We observe that SYNC [14] performs significantly better than other methods when the number of images is higher, e.g., 2H, M500, M1K, whereas the gap reduces when the number of images and the number of classes increase, e.g., $3\mathrm{H},\mathrm{L}5\mathrm{\;K}$ and All. In fact, when for All, all the methods perform similarly and poorly which indicates that there is a large room for improvement in this task. In fact, this observation carries on for all three accuracy measures. For Top-5 (middle) and Top-10 (right) accuracy although the numbers are as expected in general higher, the winning model remains as SYNC, significantly for $2\mathrm{H},\mathrm{M}{500}$ and $\mathrm{M}1\mathrm{\;K}$ whereas the difference is smaller with $3\mathrm{H},\mathrm{L}5\mathrm{H},\mathrm{L}1\mathrm{\;K}$ . On the other hand, all methods perform similarly when all ${20}\mathrm{\;K}$ classes are tested.

文献中的几个模型在ImageNet上评估了前5、前10以及前1准确率。在这种情况下，前5和前10准确率是合理的，因为一张图像通常包含多个对象，但在ImageNet中，每张图像按设定只关联一个标签。因此，我们在图5中根据这三个标准对相同的9个模型进行了比较。我们观察到，当图像数量较多时，例如2H、M500、M1K，SYNC [14]的表现明显优于其他方法，而当图像数量和类别数量增加时，例如$3\mathrm{H},\mathrm{L}5\mathrm{\;K}$和所有类别，差距会缩小。实际上，对于所有类别，所有方法的表现都相似且较差，这表明这项任务有很大的改进空间。事实上，这一观察结果适用于所有三种准确率衡量标准。对于前5(中间)和前10(右侧)准确率，虽然总体上数字如预期的那样更高，但表现最佳的模型仍然是SYNC，在$2\mathrm{H},\mathrm{M}{500}$和$\mathrm{M}1\mathrm{\;K}$情况下尤为明显，而在$3\mathrm{H},\mathrm{L}5\mathrm{H},\mathrm{L}1\mathrm{\;K}$情况下差异较小。另一方面，当测试所有${20}\mathrm{\;K}$类别时，所有方法的表现相似。

### 6.2 Generalized Zero-Shot Learning Results

### 6.2 广义零样本学习结果

In real world applications, image classification systems do not have access to whether a novel image belongs to a seen or unseen class in advance. Hence, generalized zero-shot learning is interesting from a practical point of view. Here, we use same models trained on ZSL setting on our proposed splits (PS). We evaluate performance on both ${\mathcal{Y}}^{tr}$ and ${\mathcal{Y}}^{ts}$ (using held-out images).

在现实世界的应用中，图像分类系统无法提前知道一张新图像属于已见类别还是未见类别。因此，从实际应用的角度来看，广义零样本学习很有意义。在这里，我们使用在零样本学习(ZSL)设置下在我们提出的分割(PS)上训练的相同模型。我们在${\mathcal{Y}}^{tr}$和${\mathcal{Y}}^{ts}$上评估性能(使用保留图像)。

As shown in Table 6, generalized zero-shot learning results are significantly lower than zero-shot learning results. This is due to the fact that training classes are included in the search space which act as distractors for the images that come from test classes, e.g., most of the images that are being evaluated. An interesting observation is that compatibility learning frameworks, e.g., ALE, DEVISE, SJE, perform well on test classes. However, methods that learn independent attribute or object classifiers, e.g., DAP and CONSE, perform well on training classes. Due to this discrepancy, we evaluate the harmonic mean which takes a weighted average of training and test class accuracy as shown in Equation (17). The harmonic mean measure ranks ALE as the best performing method on SUN, CUB and AWA1 datasets whereas on our AWA2 dataset DEVISE performs the best and on aPY dataset CMT* performs the best. Note that CMT* has an integrated novelty detection phase for which the method receives another supervision signal determining if the image belongs to a training or a test class. Similar to the ImageNet results, GFZSL [41] performs poorly on GZSL setting.

如表6所示，广义零样本学习的结果明显低于零样本学习的结果。这是因为训练类别被包含在搜索空间中，这对来自测试类别的图像(例如，大多数正在评估的图像)起到了干扰作用。一个有趣的观察结果是，兼容性学习框架，例如ALE、DEVISE、SJE，在测试类别上表现良好。然而，学习独立属性或对象分类器的方法，例如DAP和CONSE，在训练类别上表现良好。由于这种差异，我们评估了调和均值，它对训练类别和测试类别的准确率进行加权平均，如公式(17)所示。调和均值衡量方法将ALE列为在SUN、CUB和AWA1数据集上表现最佳的方法，而在我们的AWA2数据集上，DEVISE表现最佳，在aPY数据集上，CMT*表现最佳。请注意，CMT*有一个集成的新颖性检测阶段，该方法会收到另一个监督信号，用于确定图像属于训练类别还是测试类别。与ImageNet的结果类似，GFZSL [41]在广义零样本学习(GZSL)设置下表现不佳。

![0195d2b1-719e-720b-bdb3-2e8d7e8c28b6_10_88_1745_1534_410_0.jpg](images/0195d2b1-719e-720b-bdb3-2e8d7e8c28b6_10_88_1745_1534_410_0.jpg)

Fig. 5. Zero-Shot Learning experiments on Imagenet, measuring Top-1, Top-5 and Top-10 accuracy. $2/3\mathrm{H} =$ classes with $2/3$ hops away from ImageNet1K training classes $\left( {\mathcal{Y}}^{tr}\right)$ , M500/M1K/M5K denote 500,1K and 5K most populated classes, L500/L1K/L5K denote 500,1K and 5K least populated classes, $\mathrm{{All}} =$ The remaining ${20}\mathrm{\;K}$ categories of ImageNet.

图5. 在ImageNet上进行的零样本学习实验，测量了前1、前5和前10的准确率。$2/3\mathrm{H} =$类，与ImageNet1K训练类$\left( {\mathcal{Y}}^{tr}\right)$相距$2/3$跳，M500/M1K/M5K分别表示样本数量最多的500、1000和5000个类，L500/L1K/L5K分别表示样本数量最少的500、1000和5000个类，$\mathrm{{All}} =$ ImageNet中其余的${20}\mathrm{\;K}$个类别。

Authorized licensed use limited to: JILIN UNIVERSITY. Downloaded on March 26,2025 at 13:28:11 UTC from IEEE Xplore. Restrictions apply.

授权许可使用仅限于:吉林大学。于2025年3月26日13:28:11 UTC从IEEE Xplore下载。使用受限。

TABLE 6

Generalized Zero-Shot Learning on Proposed Split (PS) Measuring ts = Top-1 Accuracy on ${\mathcal{Y}}^{ts}$ , tr = Top-1 Accuracy on ${\mathcal{Y}}^{tr}$ , H = Harmonic Mean (CMT*: CMT with Novelty Detection)

在提议分割(PS)上的广义零样本学习，测量ts = ${\mathcal{Y}}^{ts}$上的前1准确率，tr = ${\mathcal{Y}}^{tr}$上的前1准确率，H = 调和均值(CMT*:带有新颖性检测的CMT)

<table><tr><td rowspan="2">Method</td><td colspan="3">SUN</td><td colspan="3">CUB</td><td colspan="3">AWA1</td><td colspan="3">AWA2</td><td colspan="3">aPY</td></tr><tr><td>ts</td><td>tr</td><td>H</td><td>ts</td><td>tr</td><td>H</td><td>ts</td><td>tr</td><td>H</td><td>ts</td><td>tr</td><td>H</td><td>ts</td><td>tr</td><td>H</td></tr><tr><td>DAP [1]</td><td>4.2</td><td>25.1</td><td>7.2</td><td>1.7</td><td>67.9</td><td>3.3</td><td>0.0</td><td>88.7</td><td>0.0</td><td>0.0</td><td>84.7</td><td>0.0</td><td>4.8</td><td>78.3</td><td>9.0</td></tr><tr><td>IAP [1]</td><td>1.0</td><td>37.8</td><td>1.8</td><td>0.2</td><td>72.8</td><td>0.4</td><td>2.1</td><td>78.2</td><td>4.1</td><td>0.9</td><td>87.6</td><td>1.8</td><td>5.7</td><td>65.6</td><td>10.4</td></tr><tr><td>CONSE [15]</td><td>6.8</td><td>39.9</td><td>11.6</td><td>1.6</td><td>72.2</td><td>3.1</td><td>0.4</td><td>88.6</td><td>0.8</td><td>0.5</td><td>90.6</td><td>1.0</td><td>0.0</td><td>91.2</td><td>0.0</td></tr><tr><td>CMT [12]</td><td>8.1</td><td>21.8</td><td>11.8</td><td>7.2</td><td>49.8</td><td>12.6</td><td>0.9</td><td>87.6</td><td>1.8</td><td>0.5</td><td>90.0</td><td>1.0</td><td>1.4</td><td>85.2</td><td>2.8</td></tr><tr><td>CMT* [12]</td><td>8.7</td><td>28.0</td><td>13.3</td><td>4.7</td><td>60.1</td><td>8.7</td><td>8.4</td><td>86.9</td><td>15.3</td><td>8.7</td><td>89.0</td><td>15.9</td><td>10.9</td><td>74.2</td><td>19.0</td></tr><tr><td>SSE [13]</td><td>2.1</td><td>36.4</td><td>4.0</td><td>8.5</td><td>46.9</td><td>14.4</td><td>7.0</td><td>80.5</td><td>12.9</td><td>8.1</td><td>82.5</td><td>14.8</td><td>0.2</td><td>78.9</td><td>0.4</td></tr><tr><td>LATEM [11]</td><td>14.7</td><td>28.8</td><td>19.5</td><td>15.2</td><td>57.3</td><td>24.0</td><td>7.3</td><td>71.7</td><td>13.3</td><td>11.5</td><td>77.3</td><td>20.0</td><td>0.1</td><td>73.0</td><td>0.2</td></tr><tr><td>ALE [30]</td><td>21.8</td><td>33.1</td><td>26.3</td><td>23.7</td><td>62.8</td><td>34.4</td><td>16.8</td><td>76.1</td><td>27.5</td><td>14.0</td><td>81.8</td><td>23.9</td><td>4.6</td><td>73.7</td><td>8.7</td></tr><tr><td>DEVISE [7]</td><td>16.9</td><td>27.4</td><td>20.9</td><td>23.8</td><td>53.0</td><td>32.8</td><td>13.4</td><td>68.7</td><td>22.4</td><td>17.1</td><td>74.7</td><td>27.8</td><td>4.9</td><td>76.9</td><td>9.2</td></tr><tr><td>SJE [9]</td><td>14.7</td><td>30.5</td><td>19.8</td><td>23.5</td><td>59.2</td><td>33.6</td><td>11.3</td><td>74.6</td><td>19.6</td><td>8.0</td><td>73.9</td><td>14.4</td><td>3.7</td><td>55.7</td><td>6.9</td></tr><tr><td>ESZSL [10]</td><td>11.0</td><td>27.9</td><td>15.8</td><td>12.6</td><td>63.8</td><td>21.0</td><td>6.6</td><td>75.6</td><td>12.1</td><td>5.9</td><td>77.8</td><td>11.0</td><td>2.4</td><td>70.1</td><td>4.6</td></tr><tr><td>SYNC [14]</td><td>7.9</td><td>43.3</td><td>13.4</td><td>11.5</td><td>70.9</td><td>19.8</td><td>8.9</td><td>87.3</td><td>16.2</td><td>10.0</td><td>90.5</td><td>18.0</td><td>7.4</td><td>66.3</td><td>13.3</td></tr><tr><td>SAE [33]</td><td>8.8</td><td>18.0</td><td>11.8</td><td>7.8</td><td>54.0</td><td>13.6</td><td>1.8</td><td>77.1</td><td>3.5</td><td>1.1</td><td>82.2</td><td>2.2</td><td>0.4</td><td>80.9</td><td>0.9</td></tr><tr><td>GFZSL [41]</td><td>0.0</td><td>39.6</td><td>0.0</td><td>0.0</td><td>45.7</td><td>0.0</td><td>1.8</td><td>80.3</td><td>3.5</td><td>2.5</td><td>80.1</td><td>4.8</td><td>0.0</td><td>83.3</td><td>0.0</td></tr></table>

<table><tbody><tr><td rowspan="2">方法</td><td colspan="3">太阳数据集(SUN)</td><td colspan="3">加州理工大学鸟类数据集(CUB)</td><td colspan="3">动物属性数据集1(AWA1)</td><td colspan="3">动物属性数据集2(AWA2)</td><td colspan="3">猿类属性数据集(aPY)</td></tr><tr><td>测试集(ts)</td><td>训练集(tr)</td><td>H</td><td>测试集(ts)</td><td>训练集(tr)</td><td>H</td><td>测试集(ts)</td><td>训练集(tr)</td><td>H</td><td>测试集(ts)</td><td>训练集(tr)</td><td>H</td><td>测试集(ts)</td><td>训练集(tr)</td><td>H</td></tr><tr><td>判别式属性预测模型(DAP) [1]</td><td>4.2</td><td>25.1</td><td>7.2</td><td>1.7</td><td>67.9</td><td>3.3</td><td>0.0</td><td>88.7</td><td>0.0</td><td>0.0</td><td>84.7</td><td>0.0</td><td>4.8</td><td>78.3</td><td>9.0</td></tr><tr><td>归纳式属性预测模型(IAP) [1]</td><td>1.0</td><td>37.8</td><td>1.8</td><td>0.2</td><td>72.8</td><td>0.4</td><td>2.1</td><td>78.2</td><td>4.1</td><td>0.9</td><td>87.6</td><td>1.8</td><td>5.7</td><td>65.6</td><td>10.4</td></tr><tr><td>一致性学习模型(CONSE) [15]</td><td>6.8</td><td>39.9</td><td>11.6</td><td>1.6</td><td>72.2</td><td>3.1</td><td>0.4</td><td>88.6</td><td>0.8</td><td>0.5</td><td>90.6</td><td>1.0</td><td>0.0</td><td>91.2</td><td>0.0</td></tr><tr><td>跨模态转换模型(CMT) [12]</td><td>8.1</td><td>21.8</td><td>11.8</td><td>7.2</td><td>49.8</td><td>12.6</td><td>0.9</td><td>87.6</td><td>1.8</td><td>0.5</td><td>90.0</td><td>1.0</td><td>1.4</td><td>85.2</td><td>2.8</td></tr><tr><td>改进的跨模态转换模型(CMT*) [12]</td><td>8.7</td><td>28.0</td><td>13.3</td><td>4.7</td><td>60.1</td><td>8.7</td><td>8.4</td><td>86.9</td><td>15.3</td><td>8.7</td><td>89.0</td><td>15.9</td><td>10.9</td><td>74.2</td><td>19.0</td></tr><tr><td>半监督嵌入模型(SSE) [13]</td><td>2.1</td><td>36.4</td><td>4.0</td><td>8.5</td><td>46.9</td><td>14.4</td><td>7.0</td><td>80.5</td><td>12.9</td><td>8.1</td><td>82.5</td><td>14.8</td><td>0.2</td><td>78.9</td><td>0.4</td></tr><tr><td>后期嵌入模型(LATEM) [11]</td><td>14.7</td><td>28.8</td><td>19.5</td><td>15.2</td><td>57.3</td><td>24.0</td><td>7.3</td><td>71.7</td><td>13.3</td><td>11.5</td><td>77.3</td><td>20.0</td><td>0.1</td><td>73.0</td><td>0.2</td></tr><tr><td>自适应标签嵌入模型(ALE) [30]</td><td>21.8</td><td>33.1</td><td>26.3</td><td>23.7</td><td>62.8</td><td>34.4</td><td>16.8</td><td>76.1</td><td>27.5</td><td>14.0</td><td>81.8</td><td>23.9</td><td>4.6</td><td>73.7</td><td>8.7</td></tr><tr><td>深度视觉语义嵌入模型(DEVISE) [7]</td><td>16.9</td><td>27.4</td><td>20.9</td><td>23.8</td><td>53.0</td><td>32.8</td><td>13.4</td><td>68.7</td><td>22.4</td><td>17.1</td><td>74.7</td><td>27.8</td><td>4.9</td><td>76.9</td><td>9.2</td></tr><tr><td>语义联合嵌入模型(SJE) [9]</td><td>14.7</td><td>30.5</td><td>19.8</td><td>23.5</td><td>59.2</td><td>33.6</td><td>11.3</td><td>74.6</td><td>19.6</td><td>8.0</td><td>73.9</td><td>14.4</td><td>3.7</td><td>55.7</td><td>6.9</td></tr><tr><td>端到端零样本学习模型(ESZSL) [10]</td><td>11.0</td><td>27.9</td><td>15.8</td><td>12.6</td><td>63.8</td><td>21.0</td><td>6.6</td><td>75.6</td><td>12.1</td><td>5.9</td><td>77.8</td><td>11.0</td><td>2.4</td><td>70.1</td><td>4.6</td></tr><tr><td>同步训练模型(SYNC) [14]</td><td>7.9</td><td>43.3</td><td>13.4</td><td>11.5</td><td>70.9</td><td>19.8</td><td>8.9</td><td>87.3</td><td>16.2</td><td>10.0</td><td>90.5</td><td>18.0</td><td>7.4</td><td>66.3</td><td>13.3</td></tr><tr><td>堆叠自动编码器(SAE) [33]</td><td>8.8</td><td>18.0</td><td>11.8</td><td>7.8</td><td>54.0</td><td>13.6</td><td>1.8</td><td>77.1</td><td>3.5</td><td>1.1</td><td>82.2</td><td>2.2</td><td>0.4</td><td>80.9</td><td>0.9</td></tr><tr><td>生成式零样本学习模型(GFZSL) [41]</td><td>0.0</td><td>39.6</td><td>0.0</td><td>0.0</td><td>45.7</td><td>0.0</td><td>1.8</td><td>80.3</td><td>3.5</td><td>2.5</td><td>80.1</td><td>4.8</td><td>0.0</td><td>83.3</td><td>0.0</td></tr></tbody></table>

We measure top-1 accuracy in %.

我们以百分比衡量前1准确率。

As for the generalized zero-shot learning setting on Image-Net, we report results measured on unseen classes as no images are reserved from seen classes on Fig. 6. Our first observation is that there is no winner model in all cases, the results diverge for different splits and different accuracy measures. For instance, when the performance is measured with Top-1 accuracy, in general the best performing model seems to be DEVISE, ALE and SJE which are all linear compatibility learning models. On the other hand, for Top-5 accuracy different models take the lead in different splits, e.g., CONSE works the best for $3\mathrm{H}$ and $\mathrm{M}5\mathrm{\;K}$ indicating that it performs better when the number of images that come from unseen classes is larger. Whereas SJE and ESZSL works better for $2\mathrm{H},\mathrm{M}{500},\mathrm{L}5\mathrm{H}$ settings. Finally, for Top-10 accuracy, the best performing model overall is ESZSL which is the model that learns a linear compatibility with an explicit regularization scheme. Finally, for Top-1, Top-5 and Top-10 results we observe the same trend for when all the unseen classes are included in the test set, i.e., the models perform similarly however CONSE slightly stands out for Top-5 and Top-10 accuracy plots.

对于Image - Net上的广义零样本学习设置，由于图6中没有从已见类别预留图像，我们报告在未见类别上测量的结果。我们的第一个观察结果是，并非在所有情况下都有表现最佳的模型，不同的分割方式和不同的准确率衡量指标会得出不同的结果。例如，当用前1准确率衡量性能时，总体而言，表现最佳的模型似乎是DEVISE、ALE和SJE，它们都是线性兼容性学习模型。另一方面，对于前5准确率，不同的模型在不同的分割方式中领先，例如，CONSE在$3\mathrm{H}$和$\mathrm{M}5\mathrm{\;K}$设置下表现最佳，这表明当来自未见类别的图像数量较多时，它的表现更好。而SJE和ESZSL在$2\mathrm{H},\mathrm{M}{500},\mathrm{L}5\mathrm{H}$设置下表现更好。最后，对于前10准确率，总体表现最佳的模型是ESZSL，它是一种通过显式正则化方案学习线性兼容性的模型。最后，对于前1、前5和前10的结果，当测试集中包含所有未见类别时，我们观察到相同的趋势，即模型的表现相似，但在绘制前5和前10准确率时，CONSE略有突出。

In summary, generalized zero-shot learning setting provides one more level of detail on the performance of zero-shot learning methods. Our take-home message is that the accuracy of training classes is as important as the accuracy of test classes in real world scenarios. Therefore, methods should be designed in a way that they are able to predict labels well both in train and test classes.

总之，广义零样本学习设置为零样本学习方法的性能提供了更详细的信息。我们的核心观点是，在现实场景中，训练类别的准确率与测试类别的准确率同样重要。因此，方法的设计应使其能够在训练类别和测试类别中都能很好地预测标签。

Visualizing Method Ranking. Similar to the analysis in the previous section that was conducted for zero-shot learning setting, we rank the 13 methods, i.e., [1], [7], [9], [10], [11], [12], [13], [14], [15], [30], [33], [41], based on their results obtained on SUN, CUB, AWA1, AWA2 and aPY. The performance is measured on seen classes, unseen classes and the Harmonic mean of the two.

可视化方法排名。与上一节针对零样本学习设置进行的分析类似，我们根据13种方法(即[1]、[7]、[9]、[10]、[11]、[12]、[13]、[14]、[15]、[30]、[33]、[41])在SUN、CUB、AWA1、AWA2和aPY上的结果对它们进行排名。性能是在已见类别、未见类别以及两者的调和平均值上进行衡量的。

The rank matrix of test classes, i.e., Fig. 7 top left, shows that highest ranked methods, i.e., ALE, DEVISE, SJE, although overall the absolute accuracy numbers are lower (Table 6). Note that in Fig. 4 GFZSL ranked highest which shows that GFZSL is not as strong for GZSL task. The rank matrix of the harmonic mean shows the same trend. However, the rank matrix of training classes, i.e., Fig. 7 top right, shows that models that learn intermediate attribute classifiers perform well for the images that come from training classes. However, these models typically do not lead to a high accuracy for the images that belong to unseen classes as shown in Table 6. This eventually makes the harmonic mean, i.e., the overall accuracy on both training and test classes, lower. These results clearly suggest that one should not only optimize for test class accuracy but also for training class accuracy while evaluating generalized zero-shot learning.

测试类别的排名矩阵，即图7左上角，显示排名最高的方法是ALE、DEVISE、SJE，尽管总体上绝对准确率数值较低(表6)。请注意，在图4中GFZSL排名最高，这表明GFZSL在广义零样本学习(GZSL)任务中表现并不突出。调和平均值的排名矩阵显示出相同的趋势。然而，训练类别的排名矩阵，即图7右上角，显示学习中间属性分类器的模型对于来自训练类别的图像表现良好。然而，如表6所示，这些模型通常无法使属于未见类别的图像获得较高的准确率。这最终导致调和平均值，即训练类别和测试类别的总体准确率较低。这些结果清楚地表明，在评估广义零样本学习时，不仅应优化测试类别的准确率，还应优化训练类别的准确率。

![0195d2b1-719e-720b-bdb3-2e8d7e8c28b6_11_89_1777_1533_407_0.jpg](images/0195d2b1-719e-720b-bdb3-2e8d7e8c28b6_11_89_1777_1533_407_0.jpg)

Fig. 6. GZSL on Imagenet, measuring Top-1, Top-5 and Top-10 accuracy. 2/3H: classes with 2/3 hops away from ImageNet1K ${\mathcal{Y}}^{tr}$ , M500/M1K/M5K: 500/1K/5K most populated classes, L500/L1K/L5K: 500/1K/5K least populated classes, All: Remaining 20K classes.

图6. ImageNet上的广义零样本学习(GZSL)，衡量前1、前5和前10准确率。2/3H:与ImageNet1K ${\mathcal{Y}}^{tr}$ 距离为2/3跳的类别，M500/M1K/M5K:人口最多的500/1000/5000个类别，L500/L1K/L5K:人口最少的500/1000/5000个类别，All:其余20000个类别。

Authorized licensed use limited to: JILIN UNIVERSITY. Downloaded on March 26,2025 at 13:28:11 UTC from IEEE Xplore. Restrictions apply.

授权许可使用仅限于:吉林大学。于2025年3月26日13:28:11 UTC从IEEE Xplore下载。使用受限。

![0195d2b1-719e-720b-bdb3-2e8d7e8c28b6_12_74_124_765_598_0.jpg](images/0195d2b1-719e-720b-bdb3-2e8d7e8c28b6_12_74_124_765_598_0.jpg)

Fig. 7. Ranking 13 models on the proposed split (PS) in generalized zero-shot learning setting. Top-Left: Top-1 accuracy (T1) is measured on unseen classes (ts), Top-Right: T1 is measured on seen classes (tr), Bottom: T1 is measured on Harmonic mean (H).

图7. 在广义零样本学习设置下，对提出的分割(PS)中的13个模型进行排名。左上角:在未见类别(ts)上测量前1准确率(T1)，右上角:在已见类别(tr)上测量T1，底部:在调和平均值(H)上测量T1。

Our final observation from Fig. 7 is that CMT* is better than CMT in all cases which supports the argument that a simple novelty detection scheme helps to improve results. However, it is important to note that the proposed novelty detection mechanism uses more supervision than classic zero-shot learning models. Although the label of test classes is not used, whether the sample comes from a seen or unseen class is an additional supervision.

从图7中我们的最后一个观察结果是，在所有情况下CMT*都比CMT更好，这支持了简单的新颖性检测方案有助于提高结果的观点。然而，重要的是要注意，所提出的新颖性检测机制比经典的零样本学习模型使用了更多的监督信息。虽然没有使用测试类别的标签，但样本是来自已见类别还是未见类别是一种额外的监督信息。

### 6.3 Transductive (Generalized) Zero-Shot Learning

### 6.3 直推式(广义)零样本学习

In contrast to previous zero-shot learning approaches that learn only with data from training classes, transductive approaches use unlabaled images from test classes. In this section, we evaluate three state-of-the-art transductive ZSL approaches, i.e., DSRL [71], GFZSL-tran [41], and ALE-tran [30]. Similar to the previous section, we evaluate those approaches on our proposed splits in both zero-shot learning where test time search space is composed of only unseen classes and generalized zero-shot learning where it contains both seen and unseen classes. The performance is per-class averaged top-1 accuracy.

与之前仅使用训练类数据进行学习的零样本学习方法不同，直推式方法使用测试类的未标记图像。在本节中，我们评估了三种最先进的直推式零样本学习(ZSL)方法，即DSRL [71]、GFZSL - tran [41]和ALE - tran [30]。与上一节类似，我们在我们提出的分割数据集上评估这些方法，包括测试时搜索空间仅由未见类组成的零样本学习，以及搜索空间包含已见类和未见类的广义零样本学习。性能指标为每类平均的top - 1准确率。

Our transductive learning results are presented in Fig. 8. We observe that in ZSL setting, transductive learning leads to accuracy improvement, e.g., ALE-tran and GFZSL-tran outperforms ALE and GFZSL respectively in almost all cases. In particular, on AWA2, GFZSL-tran achieves 78.6 percent, significantly improving GFZSL (63.8 percent). On APY, ALE-tran obtains 45.5 percent and significantly improves ALE (37.1 percent) as well. Moreover, GFZSL-tran outperforms ALE-tran and DSRL on SUN, AWA1 and AWA2. However, ALE-tran performs the best on CUB and APY. In GZSL setting we observe a different trend, i.e., transductive learning does not improve results for ALE in any of the datasets. Authorized licensed use limited to: JILIN UNIVERSITY. Downloaded on March 26,2025 at 13:28:11 UTC from IEEE Xplore. Restrictions apply. Although, on AWA1 and AWA2 GFZSL results improve significantly for the transductive learning setting, on other datasets GFZSL model performs poorly both in inductive and in transductive settings.

我们的直推式学习结果如图8所示。我们观察到，在零样本学习(ZSL)设置中，直推式学习提高了准确率，例如，在几乎所有情况下，ALE - tran和GFZSL - tran分别优于ALE和GFZSL。特别是在AWA2数据集上，GFZSL - tran达到了78.6%，显著优于GFZSL(63.8%)。在APY数据集上，ALE - tran获得了45.5%的准确率，也显著优于ALE(37.1%)。此外，在SUN、AWA1和AWA2数据集上，GFZSL - tran优于ALE - tran和DSRL。然而，在CUB和APY数据集上，ALE - tran表现最佳。在广义零样本学习(GZSL)设置中，我们观察到了不同的趋势，即直推式学习在任何数据集上都没有提高ALE的结果。授权许可使用仅限于:吉林大学。于2025年3月26日13:28:11 UTC从IEEE Xplore下载。适用限制。尽管在AWA1和AWA2数据集上，直推式学习设置下GFZSL的结果有显著改善，但在其他数据集上，GFZSL模型在归纳式和直推式设置下的表现都很差。

![0195d2b1-719e-720b-bdb3-2e8d7e8c28b6_12_873_124_763_317_0.jpg](images/0195d2b1-719e-720b-bdb3-2e8d7e8c28b6_12_873_124_763_317_0.jpg)

Fig. 8. Zero-shot (left) and generalized zero-shot learning (right) results in the transductive learning setting on our Proposesd Split.

图8. 在我们提出的分割数据集上，直推式学习设置下的零样本学习(左)和广义零样本学习(右)结果。

## 7 CONCLUSION

## 7 结论

In this work, we evaluated a significant number of state-of-the-art zero-shot learning methods, i.e., [1], [7], [9], [10], [11], [12], [13], [14], [15], [30], [33], [41], [71], on several datasets, i.e., SUN, CUB, AWA1, AWA2, aPY and ImageNet, within a unified evaluation protocol both in zero-shot and generalized zero-shot settings.

在这项工作中，我们在统一的评估协议下，在零样本和广义零样本设置中，对多个数据集(即SUN、CUB、AWA1、AWA2、aPY和ImageNet)上的大量最先进的零样本学习方法(即[1]、[7]、[9]、[10]、[11]、[12]、[13]、[14]、[15]、[30]、[33]、[41]、[71])进行了评估。

Our evaluation showed that generative models and compatibility learning frameworks have an edge over learning independent object or attribute classifiers and also over other hybrid models for the classic zero-shot learning setting. We observed that unlabeled data of unseen classes can further improve the zero-shot learning results, thus it is not fair to compare transductive learning approaches with inductive ones. We discovered that some standard zero-shot dataset splits may treat feature learning disjoint from the training stage as several test classes are included in the ImageNet1K dataset that is used to train the deep neural networks that act as feature extractor. Therefore, we proposed new dataset splits making sure that none of the test classes in none of the datasets belong to ImageNet1K. Moreover, disjoint training and validation class split is a necessary component of parameter tuning in zero-shot learning setting.

我们的评估表明，在经典的零样本学习设置中，生成模型和兼容性学习框架优于学习独立的对象或属性分类器，也优于其他混合模型。我们观察到，未见类的未标记数据可以进一步提高零样本学习的结果，因此将直推式学习方法与归纳式学习方法进行比较是不公平的。我们发现，一些标准的零样本数据集分割可能会将特征学习与训练阶段分离，因为用于训练作为特征提取器的深度神经网络的ImageNet1K数据集中包含了几个测试类。因此，我们提出了新的数据集分割方法，确保所有数据集中的测试类都不属于ImageNet1K。此外，不相交的训练和验证类分割是零样本学习设置中参数调整的必要组成部分。

In addition, we introduced a new Animal with Attributes (AWA2) dataset. AWA2 inherits the same 50 classes and attributes annotations from the original Animal with Attributes (AWA1) dataset, but consists of different 37,322 images with publicly available redistribution license. Our experimental results showed that the 12 methods that we evaluated perform similarly on AWA2 and AWA1. Moreover, our statistical consistency test indicated that AWA1 and AWA2 are compatible with each other.

此外，我们引入了一个新的动物属性数据集(AWA2)。AWA2继承了原始动物属性数据集(AWA1)相同的50个类别和属性注释，但包含不同的37322张图像，并且具有公开可用的再分发许可证。我们的实验结果表明，我们评估的12种方法在AWA2和AWA1上的表现相似。此外，我们的统计一致性测试表明，AWA1和AWA2彼此兼容。

Finally, including training classes in the search space while evaluating the methods, i.e., generalized zero-shot learning, provides an interesting playground for future research. Although the generalized zero-shot learning accuracy obtained with 13 models compared to their zero-shot learning accuracy is significantly lower, the relative performance comparison of different models remain the same. Having noticed that some models perform well when the test set is composed only of seen classes, while some others perform well when the test set is composed of only of unseen classes, we proposed the Harmonic mean of seen and unseen class accuracy as a unified measure for performance in GZSL setting. The Harmonic mean encourages the models to perform well on both seen and unseen class samples, which is closer to a real world setting. In summary, our work extensively evaluated the good and bad aspects of zero-shot learning while sanitizing the ugly ones.

最后，在评估方法时将训练类纳入搜索空间，即广义零样本学习，为未来的研究提供了一个有趣的平台。尽管与零样本学习准确率相比，13种模型在广义零样本学习中获得的准确率显著较低，但不同模型的相对性能比较保持不变。我们注意到，一些模型在测试集仅由已见类组成时表现良好，而另一些模型在测试集仅由未见类组成时表现良好，因此我们提出将已见类和未见类准确率的调和平均值作为广义零样本学习设置下性能的统一衡量标准。调和平均值鼓励模型在已见类和未见类样本上都表现良好，这更接近现实世界的设置。总之，我们的工作全面评估了零样本学习的优缺点，同时改进了其不足之处。

REFERENCES

参考文献

[1] C. Lampert, H. Nickisch, and S. Harmeling, "Attribute-based classification for zero-shot visual object categorization," IEEE Trans. Pattern Anal. Mach. Intell., vol. 36, no. 3, pp. 453-465, Mar. 2014.

[1] C. 兰珀特(C. Lampert)、H. 尼基施(H. Nickisch)和 S. 哈梅林(S. Harmeling)，“基于属性的零样本视觉目标分类方法”，《IEEE 模式分析与机器智能汇刊》(IEEE Trans. Pattern Anal. Mach. Intell.)，第 36 卷，第 3 期，第 453 - 465 页，2014 年 3 月。

[2] H. Larochelle, D. Erhan, and Y. Bengio, "Zero-data learning of new tasks," in Proc. 23rd Nat. Conf. Artif. Intell., 2008, pp. 646-651.

[2] H. 拉罗谢尔(H. Larochelle)、D. 埃尔汗(D. Erhan)和 Y. 本吉奥(Y. Bengio)，“新任务的零数据学习”，收录于《第 23 届全国人工智能会议论文集》(Proc. 23rd Nat. Conf. Artif. Intell.)，2008 年，第 646 - 651 页。

[3] M. Rohrbach, M. Stark, and B. Schiele, "Evaluating knowledge transfer and zero-shot learning in a large-scale setting," in Proc. IEEE Conf. Comput. Vis. Pattern Recognit., 2011, pp. 1641-1648.

[3] M. 罗尔巴赫(M. Rohrbach)、M. 斯塔克(M. Stark)和 B. 席勒(B. Schiele)，“大规模环境下的知识迁移与零样本学习评估”，收录于《IEEE 计算机视觉与模式识别会议论文集》(Proc. IEEE Conf. Comput. Vis. Pattern Recognit.)，2011 年，第 1641 - 1648 页。

[4] X. Yu and Y. Aloimonos, "Attribute-based transfer learning for object categorization with zero or one training example," in Proc. 11th Eur. Conf. Comput. Vis., 2010, pp. 127-140.

[4] X. 于(X. Yu)和 Y. 阿洛伊莫诺斯(Y. Aloimonos)，“基于属性的零样本或单样本目标分类迁移学习”，收录于《第 11 届欧洲计算机视觉会议论文集》(Proc. 11th Eur. Conf. Comput. Vis.)，2010 年，第 127 - 140 页。

[5] X. Xu, Y. Yang, D. Zhang, H. T. Shen, and J. Song, "Matrix tri-factorization with manifold regularizations for zero-shot learning," in Proc. IEEE Conf. Comput. Vis. Pattern Recognit., 2017, pp. 2007- 2016.

[5] X. 徐(X. Xu)、Y. 杨(Y. Yang)、D. 张(D. Zhang)、H. T. 沈(H. T. Shen)和 J. 宋(J. Song)，“基于流形正则化的矩阵三因子分解用于零样本学习”，收录于《IEEE 计算机视觉与模式识别会议论文集》(Proc. IEEE Conf. Comput. Vis. Pattern Recognit.)，2017 年，第 2007 - 2016 页。

[6] Z. Ding, M. Shao, and Y. Fu, "Low-rank embedded ensemble semantic dictionary for zero-shot learning," in Proc. IEEE Conf. Comput. Vis. Pattern Recognit., 2017, pp. 6005-6013.

[6] Z. 丁(Z. Ding)、M. 邵(M. Shao)和 Y. 傅(Y. Fu)，“用于零样本学习的低秩嵌入集成语义字典”，收录于《IEEE 计算机视觉与模式识别会议论文集》(Proc. IEEE Conf. Comput. Vis. Pattern Recognit.)，2017 年，第 6005 - 6013 页。

[7] A. Frome, G. S. Corrado, J. Shlens, S. Bengio, J. Dean, M. A. Ranzato, and T. Mikolov, "Devise: A deep visual-semantic embedding model," in Proc. Advances Neural Inf. Process. Syst., 2013, pp. 2121-2129.

[7] A. 弗罗梅(A. Frome)、G. S. 科拉多(G. S. Corrado)、J. 施伦斯(J. Shlens)、S. 本吉奥(S. Bengio)、J. 迪恩(J. Dean)、M. A. 兰扎托(M. A. Ranzato)和 T. 米科洛夫(T. Mikolov)，“DEVISE:一种深度视觉语义嵌入模型”，收录于《神经信息处理系统进展会议论文集》(Proc. Advances Neural Inf. Process. Syst.)，2013 年，第 2121 - 2129 页。

[8] Z. Akata, F. Perronnin, Z. Harchaoui, and C. Schmid, "Label embedding for attribute-based classification," in Proc. IEEE Conf. Comput. Vis. Pattern Recognit., 2013, pp. 819-826.

[8] Z. 阿卡塔(Z. Akata)、F. 佩罗宁(F. Perronnin)、Z. 哈查维(Z. Harchaoui)和 C. 施密德(C. Schmid)，“基于属性分类的标签嵌入”，收录于《IEEE 计算机视觉与模式识别会议论文集》(Proc. IEEE Conf. Comput. Vis. Pattern Recognit.)，2013 年，第 819 - 826 页。

[9] Z. Akata, S. Reed, D. Walter, H. Lee, and B. Schiele, "Evaluation of output embeddings for fine-grained image classification," in Proc. IEEE Conf. Comput. Vis. Pattern Recognit., 2015, pp. 2927-2936.

[9] Z. 阿卡塔(Z. Akata)、S. 里德(S. Reed)、D. 沃尔特(D. Walter)、H. 李(H. Lee)和 B. 席勒(B. Schiele)，“细粒度图像分类输出嵌入的评估”，收录于《IEEE 计算机视觉与模式识别会议论文集》(Proc. IEEE Conf. Comput. Vis. Pattern Recognit.)，2015 年，第 2927 - 2936 页。

[10] B. Romera-Paredes and P. H. Torr, "An embarrassingly simple approach to zero-shot learning," Proc. Int. Conf. Mach. Learn., 2015, pp. 2152-2161.

[10] B. 罗梅拉 - 帕雷德斯(B. Romera - Paredes)和 P. H. 托尔(P. H. Torr)，“一种极其简单的零样本学习方法”，《国际机器学习会议论文集》(Proc. Int. Conf. Mach. Learn.)，2015 年，第 2152 - 2161 页。

[11] Y. Xian, Z. Akata, G. Sharma, Q. Nguyen, M. Hein, and B. Schiele, "Latent embeddings for zero-shot classification," in Proc. IEEE Conf. Comput. Vis. Pattern Recognit., 2016, pp. 69-77.

[11] Y. 西安(Y. Xian)、Z. 阿卡塔(Z. Akata)、G. 夏尔马(G. Sharma)、Q. 阮(Q. Nguyen)、M. 海因(M. Hein)和 B. 席勒(B. Schiele)，“用于零样本分类的潜在嵌入”，收录于《IEEE 计算机视觉与模式识别会议论文集》(Proc. IEEE Conf. Comput. Vis. Pattern Recognit.)，2016 年，第 69 - 77 页。

[12] R. Socher, M. Ganjoo, C. D. Manning, and A. Ng, "Zero-shot learning through cross-modal transfer," in Proc. Int. Conf. Neural Inf. Process. Syst., 2013, pp. 935-943.

[12] R. 索切尔(R. Socher)、M. 甘朱(M. Ganjoo)、C. D. 曼宁(C. D. Manning)和 A. 吴(A. Ng)，“通过跨模态迁移进行零样本学习”，收录于《国际神经信息处理系统会议论文集》(Proc. Int. Conf. Neural Inf. Process. Syst.)，2013 年，第 935 - 943 页。

[13] Z. Zhang and V. Saligrama, "Zero-shot learning via semantic similarity embedding," in Proc. IEEE Int. Conf. Comput. Vis., 2015, pp. 4166-4174.

[13] Z. 张(Z. Zhang)和 V. 萨利格拉马(V. Saligrama)，“基于语义相似性嵌入的零样本学习”，收录于《IEEE 国际计算机视觉会议论文集》(Proc. IEEE Int. Conf. Comput. Vis.)，2015 年，第 4166 - 4174 页。

[14] S. Changpinyo, W.-L. Chao, B. Gong, and F. Sha, "Synthesized classifiers for zero-shot learning," in Proc. IEEE Conf. Comput. Vis. Pattern Recognit., 2016, pp. 5327-5336.

[14] S. 昌皮尼奥(S. Changpinyo)、W. - L. 赵(W. - L. Chao)、B. 龚(B. Gong)和 F. 沙(F. Sha)，“用于零样本学习的合成分类器”，收录于《IEEE 计算机视觉与模式识别会议论文集》(Proc. IEEE Conf. Comput. Vis. Pattern Recognit.)，2016 年，第 5327 - 5336 页。

[15] M. Norouzi, T. Mikolov, S. Bengio, Y. Singer, J. Shlens, A. Frome, G. Corrado, and J. Dean, "Zero-shot learning by convex combination of semantic embeddings," in Proc. Int. Conf. Learn. Representation, 2014.

[15] M. 诺鲁齐(M. Norouzi)、T. 米科洛夫(T. Mikolov)、S. 本吉奥(S. Bengio)、Y. 辛格(Y. Singer)、J. 施伦斯(J. Shlens)、A. 弗罗梅(A. Frome)、G. 科拉多(G. Corrado)和 J. 迪恩(J. Dean)，“通过语义嵌入的凸组合进行零样本学习”，收录于《国际学习表征会议论文集》(Proc. Int. Conf. Learn. Representation)，2014 年。

[16] G. Patterson and J. Hays, "Sun attribute database: Discovering, annotating, and recognizing scene attributes," in Proc. IEEE Conf. Comput. Vis. Pattern Recognit., 2012, pp. 2751-2758.

[16] G. 帕特森(G. Patterson)和 J. 海斯(J. Hays)，“SUN 属性数据库:场景属性的发现、标注与识别”，收录于《IEEE 计算机视觉与模式识别会议论文集》(Proc. IEEE Conf. Comput. Vis. Pattern Recognit.)，2012 年，第 2751 - 2758 页。

[17] P. Welinder, S. Branson, T. Mita, C. Wah, F. Schroff, S. Belongie, and P. Perona, "Caltech-UCSD Birds 200," California Institute Technol., Pasadena, CA, Tech. Rep. CNS-TR-2010-001, 2010.

[17] P. 韦林德(P. Welinder)、S. 布兰森(S. Branson)、T. 米塔(T. Mita)、C. 瓦(C. Wah)、F. 施罗夫(F. Schroff)、S. 贝隆吉(S. Belongie)和 P. 佩罗纳(P. Perona)，《加州理工学院 - 加州大学圣地亚哥分校鸟类数据集200》("Caltech-UCSD Birds 200")，加州理工学院(California Institute Technol.)，加利福尼亚州帕萨迪纳市，技术报告 CNS - TR - 2010 - 001，2010年。

[18] A. Farhadi, I. Endres, D. Hoiem, and D. Forsyth, "Describing objects by their attributes," Proc. IEEE Conf. Comput. Vis. Pattern Recognit., 2009, pp. 1778-1785.

[18] A. 法尔哈迪(A. Farhadi)、I. 恩德斯(I. Endres)、D. 霍耶姆(D. Hoiem)和 D. 福赛思(D. Forsyth)，《通过物体属性描述物体》("Describing objects by their attributes")，《电气与电子工程师协会计算机视觉与模式识别会议论文集》(Proc. IEEE Conf. Comput. Vis. Pattern Recognit.)，2009年，第1778 - 1785页。

[19] J. Deng, W. Dong, R. Socher, L.-J. Li, K. Li, and L. Fei-Fei, "ImageNet: A large-scale hierarchical image database," in Proc. IEEE Conf. Com-put. Vis. Pattern Recognit., 2009, pp. 248-255.

[19] J. 邓(J. Deng)、W. 董(W. Dong)、R. 索切尔(R. Socher)、L. - J. 李(L. - J. Li)、K. 李(K. Li)和 L. 费 - 费(L. Fei - Fei)，《ImageNet:大规模分层图像数据库》("ImageNet: A large - scale hierarchical image database")，收录于《电气与电子工程师协会计算机视觉与模式识别会议论文集》(Proc. IEEE Conf. Com - put. Vis. Pattern Recognit.)，2009年，第248 - 255页。

[20] D. G. Lowe, "Distinctive image features from scale-invariant key-points," Int. J. Comput. Vis., vol. 60, no. 2, pp. 91-110, 2004.

[20] D. G. 洛(D. G. Lowe)，《尺度不变关键点的独特图像特征》("Distinctive image features from scale - invariant key - points")，《国际计算机视觉杂志》(Int. J. Comput. Vis.)，第60卷，第2期，第91 - 110页，2004年。

[21] J. Donahue, Y. Jia, O. Vinyals, J. Hoffman, N. Zhang, E. Tzeng, and T. Darrell, "DeCAF: A deep convolutional activation feature for generic visual recognition," in Proc. Int. Conf. Mach. Learn., 2014, pp. I-647-I-655.

[21] J. 多纳休(J. Donahue)、Y. 贾(Y. Jia)、O. 维尼亚尔斯(O. Vinyals)、J. 霍夫曼(J. Hoffman)、N. 张(N. Zhang)、E. 曾(E. Tzeng)和 T. 达雷尔(T. Darrell)，《DeCAF:用于通用视觉识别的深度卷积激活特征》("DeCAF: A deep convolutional activation feature for generic visual recognition")，收录于《国际机器学习会议论文集》(Proc. Int. Conf. Mach. Learn.)，2014年，第I - 647 - I - 655页。

[22] K. Simonyan and A. Zisserman, "Very deep convolutional networks for large-scale image recognition," arXiv:1409.1556, 2014.

[22] K. 西蒙扬(K. Simonyan)和 A. 齐斯曼(A. Zisserman)，《用于大规模图像识别的非常深的卷积网络》("Very deep convolutional networks for large - scale image recognition")，预印本 arXiv:1409.1556，2014年。

[23] K. He, X. Zhang, S. Ren, and J. Sun, "Deep residual learning for image recognition," in Proc. IEEE Conf. Comput. Vis. Pattern Recog-nit., 2016, pp. 770-778.

[23] K. 何(K. He)、X. 张(X. Zhang)、S. 任(S. Ren)和 J. 孙(J. Sun)，《用于图像识别的深度残差学习》("Deep residual learning for image recognition")，收录于《电气与电子工程师协会计算机视觉与模式识别会议论文集》(Proc. IEEE Conf. Comput. Vis. Pattern Recog - nit.)，2016年，第770 - 778页。

[24] Z. Al-Halah, M. Tapaswi, and R. Stiefelhagen, "Recovering the missing link: Predicting class-attribute associations for unsupervised zero-shot learning," in Proc. IEEE Conf. Comput. Vis. Pattern Recognit., 2016, pp. 5975-5984.

[24] Z. 哈拉哈(Z. Al - Halah)、M. 塔帕斯维(M. Tapaswi)和 R. 施蒂费尔哈根(R. Stiefelhagen)，《找回缺失的环节:为无监督零样本学习预测类别 - 属性关联》("Recovering the missing link: Predicting class - attribute associations for unsupervised zero - shot learning")，收录于《电气与电子工程师协会计算机视觉与模式识别会议论文集》(Proc. IEEE Conf. Comput. Vis. Pattern Recognit.)，2016年，第5975 - 5984页。

[25] D. Jayaraman and K. Grauman, "Zero-shot recognition with unre-

[25] D. 贾亚拉曼(D. Jayaraman)和 K. 格劳曼(K. Grauman)，《使用不可靠属性的零样本识别》("Zero - shot recognition with unre -

liable attributes," in Proc. 27th Int. Conf. Neural Inf. Process. Syst., 2014, pp. 3464-3472.

liable attributes")，收录于《第27届国际神经信息处理系统会议论文集》(Proc. 27th Int. Conf. Neural Inf. Process. Syst.)，2014年，第3464 - 3472页。

[26] P. Kankuekul, A. Kawewong, S. Tangruamsub, and O. Hasegawa, "Online incremental attribute-based zero-shot learning," in Proc. IEEE Conf. Comput. Vis. Pattern Recognit., 2012, pp. 3657-3664.

[26] P. 坎库库尔(P. Kankuekul)、A. 卡韦翁(A. Kawewong)、S. 唐鲁阿姆苏布(S. Tangruamsub)和 O. 长谷川(O. Hasegawa)，《基于在线增量属性的零样本学习》("Online incremental attribute - based zero - shot learning")，收录于《电气与电子工程师协会计算机视觉与模式识别会议论文集》(Proc. IEEE Conf. Comput. Vis. Pattern Recognit.)，2012年，第3657 - 3664页。

[27] T. Mikolov, I. Sutskever, K. Chen, G. S. Corrado, and J. Dean, "Distributed representations of words and phrases and their compositionality," in Proc. Int. Conf. Neural Inf. Process. Syst., 2013, pp. 3111-3119.

[27] T. 米科洛夫(T. Mikolov)、I. 苏茨克维(I. Sutskever)、K. 陈(K. Chen)、G. S. 科拉多(G. S. Corrado)和 J. 迪恩(J. Dean)，《单词和短语的分布式表示及其组合性》("Distributed representations of words and phrases and their compositionality")，收录于《国际神经信息处理系统会议论文集》(Proc. Int. Conf. Neural Inf. Process. Syst.)，2013年，第3111 - 3119页。

[28] Y. Fu, T. M. Hospedales, T. Xiang, and S. Gong, "Transductive multi-view zero-shot learning," IEEE Trans. Pattern Anal. Mach. Intell., vol. 37, no. 11, pp. 2332-2345, Nov. 2015.

[28] Y. 傅(Y. Fu)、T. M. 霍斯佩代尔斯(T. M. Hospedales)、T. 向(T. Xiang)和 S. 龚(S. Gong)，《直推式多视图零样本学习》("Transductive multi - view zero - shot learning")，《电气与电子工程师协会模式分析与机器智能汇刊》(IEEE Trans. Pattern Anal. Mach. Intell.)，第37卷，第11期，第2332 - 2345页，2015年11月。

[29] M. Palatucci, D. Pomerleau, G. E. Hinton, and T. M. Mitchell, "Zero-shot learning with semantic output codes," in Proc. Int. Conf. Neural Inf. Process. Syst., 2009, pp. 1410-1418.

[29] M. 帕拉图奇(M. Palatucci)、D. 波梅罗(D. Pomerleau)、G. E. 辛顿(G. E. Hinton)和 T. M. 米切尔(T. M. Mitchell)，《使用语义输出码的零样本学习》("Zero - shot learning with semantic output codes")，收录于《国际神经信息处理系统会议论文集》(Proc. Int. Conf. Neural Inf. Process. Syst.)，2009年，第1410 - 1418页。

[30] Z. Akata, F. Perronnin, Z. Harchaoui, and C. Schmid, "Label-embedding for image classification," IEEE Trans. Pattern Anal. Mach. Intell., vol. 38, no. 7, pp. 1425-1438, Jul. 2016.

[30] Z. 阿卡塔(Z. Akata)、F. 佩罗宁(F. Perronnin)、Z. 哈查维(Z. Harchaoui)和 C. 施密德(C. Schmid)，《用于图像分类的标签嵌入》("Label - embedding for image classification")，《电气与电子工程师协会模式分析与机器智能汇刊》(IEEE Trans. Pattern Anal. Mach. Intell.)，第38卷，第7期，第1425 - 1438页，2016年7月。

[31] R. Qiao, L. Liu, C. Shen, and A. van den Hengel, "Less is more: Zero-shot learning from online textual documents with noise suppression," in Proc. IEEE Conf. Comput. Vis. Pattern Recognit., 2016, pp. 2249-2257.

[31] R. 乔(R. Qiao)、L. 刘(L. Liu)、C. 沈(C. Shen)和 A. 范登亨格尔(A. van den Hengel)，《少即是多:通过抑制噪声从在线文本文档进行零样本学习》("Less is more: Zero - shot learning from online textual documents with noise suppression")，收录于《电气与电子工程师协会计算机视觉与模式识别会议论文集》(Proc. IEEE Conf. Comput. Vis. Pattern Recognit.)，2016年，第2249 - 2257页。

[32] M. Bucher, S. Herbin, and F. Jurie, "Improving semantic embedding consistency by metric learning for zero-shot classiffication," in Proc. 11th Eur. Conf. Comput. Vis., 2016, pp. 730-746.

[32] M. 布赫(M. Bucher)、S. 埃尔班(S. Herbin)和 F. 朱里(F. Jurie)，《通过度量学习提高零样本分类的语义嵌入一致性》，载于《第 11 届欧洲计算机视觉会议论文集》，2016 年，第 730 - 746 页。

[33] E. Kodirov, T. Xiang, and S. Gong, "Semantic autoencoder for zero-shot learning," in Proc. IEEE Conf. Comput. Vis. Pattern Recog-nit., 2017, pp. 4447-4456.

[33] E. 科迪罗夫(E. Kodirov)、T. 向(T. Xiang)和 S. 龚(S. Gong)，《用于零样本学习的语义自动编码器》，载于《电气与电子工程师协会计算机视觉与模式识别会议论文集》，2017 年，第 4447 - 4456 页。

[34] J. Lei Ba, K. Swersky, S. Fidler, et al., "Predicting deep zero-shot convolutional neural networks using textual descriptions," in Proc. IEEE Int. Conf. Comput. Vis., 2015, pp. 4247-4255.

[34] J. 雷·巴(J. Lei Ba)、K. 斯韦尔斯基(K. Swersky)、S. 菲德勒(S. Fidler)等，《使用文本描述预测深度零样本卷积神经网络》，载于《电气与电子工程师协会国际计算机视觉会议论文集》，2015 年，第 4247 - 4255 页。

[35] L. Zhang, T. Xiang, and S. Gong, "Learning a deep embedding model for zero-shot learning," in Proc. IEEE Conf. Comput. Vis. Pattern Recognit., 2017, pp. 3010-3019.

[35] L. 张(L. Zhang)、T. 向(T. Xiang)和 S. 龚(S. Gong)，《学习用于零样本学习的深度嵌入模型》，载于《电气与电子工程师协会计算机视觉与模式识别会议论文集》，2017 年，第 3010 - 3019 页。

[36] S. Changpinyo, W.-L. Chao, and F. Sha, "Predicting visual exemplars of unseen classes for zero-shot learning," ICCV, pp. 3496-3505, 2017.

[36] S. 昌皮尼奥(S. Changpinyo)、W.-L. 赵(W.-L. Chao)和 F. 沙(F. Sha)，《为零样本学习预测未见类别的视觉样本》，《国际计算机视觉会议》，第 3496 - 3505 页，2017 年。

[37] Z. Zhang and V. Saligrama, "Zero-shot learning via joint semantic similarity embedding," in Proc. IEEE Conf. Comput. Vis. Pattern Recognit., 2016, pp. 6034-6042.

[37] Z. 张(Z. Zhang)和 V. 萨利格拉马(V. Saligrama)，《通过联合语义相似性嵌入进行零样本学习》，载于《电气与电子工程师协会计算机视觉与模式识别会议论文集》，2016 年，第 6034 - 6042 页。

[38] Z. Fu, T. Xiang, E. Kodirov, and S. Gong, "Zero-shot object recognition by semantic manifold distance," in Proc. IEEE Conf. Comput. Vis. Pattern Recognit., Jun. 2015, pp. 2635-2644.

[38] Z. 傅(Z. Fu)、T. 向(T. Xiang)、E. 科迪罗夫(E. Kodirov)和 S. 龚(S. Gong)，《通过语义流形距离进行零样本目标识别》，载于《电气与电子工程师协会计算机视觉与模式识别会议论文集》，2015 年 6 月，第 2635 - 2644 页。

[39] Z. Akata, M. Malinowski, M. Fritz, and B. Schiele, "Multi-cue zero-shot learning with strong supervision," in Proc. IEEE Conf. Comput. Vis. Pattern Recognit., 2016, pp. 59-68.

[39] Z. 阿卡塔(Z. Akata)、M. 马林诺夫斯基(M. Malinowski)、M. 弗里茨(M. Fritz)和 B. 席勒(B. Schiele)，《具有强监督的多线索零样本学习》，载于《电气与电子工程师协会计算机视觉与模式识别会议论文集》，2016 年，第 59 - 68 页。

[40] Y. Long, L. Liu, L. Shao, F. Shen, G. Ding, and J. Han, "From zero-shot learning to conventional supervised classification: Unseen visual data synthesis," in Proc. IEEE Conf. Comput. Vis. Pattern Rec-ognit., 2017, pp. 6165-6174.

[40] Y. 龙(Y. Long)、L. 刘(L. Liu)、L. 邵(L. Shao)、F. 沈(F. Shen)、G. 丁(G. Ding)和 J. 韩(J. Han)，《从零样本学习到传统监督分类:未见视觉数据合成》，载于《电气与电子工程师协会计算机视觉与模式识别会议论文集》，2017 年，第 6165 - 6174 页。

[41] V. K. Verm and P. Rai, "A simple exponential family framework for zero-shot learning," in Proc. Eur. Conf. Mach. Learn., 2017, pp. 792-808.

[41] V. K. 维尔姆(V. K. Verm)和 P. 拉伊(P. Rai)，《用于零样本学习的简单指数族框架》，载于《欧洲机器学习会议论文集》，2017 年，第 792 - 808 页。

[42] Y. Li and D. Wang, "Zero-shot learning with generative latent prototype model," arXiv:1705.09474, 2017.

[42] Y. 李(Y. Li)和 D. 王(D. Wang)，《基于生成式潜在原型模型的零样本学习》，预印本 arXiv:1705.09474，2017 年。

[43] T. Mukherjee and T. Hospedales, "Gaussian visual-linguistic embedding for zero-shot recognition," in Proc. Conf. Empirical Methods Natural Language Process., 2016, pp. 912-918.

[43] T. 穆克吉(T. Mukherjee)和 T. 霍斯佩代尔斯(T. Hospedales)，《用于零样本识别的高斯视觉 - 语言嵌入》，载于《自然语言处理经验方法会议论文集》，2016 年，第 912 - 918 页。

[44] M. Rohrbach, S. Ebert, and B. Schiele, "Transfer learning in a transductive setting," in Proc. Int. Conf. Neural Inf. Process. Syst., 2013, pp. 46-54.

[44] M. 罗尔巴赫(M. Rohrbach)、S. 埃伯特(S. Ebert)和 B. 席勒(B. Schiele)，《归纳式环境下的迁移学习》，载于《国际神经信息处理系统会议论文集》，2013 年，第 46 - 54 页。

[45] E. Kodirov, T. Xiang, Z. Fu, and S. Gong, "Unsupervised domain adaptation for zero-shot learning," in Proc. IEEE Int. Conf. Comput. Vis., 2015, pp. 2452-2460.

[45] E. 科迪罗夫(E. Kodirov)、T. 向(T. Xiang)、Z. 傅(Z. Fu)和 S. 龚(S. Gong)，《用于零样本学习的无监督域适应》，载于《电气与电子工程师协会国际计算机视觉会议论文集》，2015 年，第 2452 - 2460 页。

[46] X. Li, Y. Guo, and D. Schuurmans, "Semi-supervised zero-shot classification with label representation learning," in Proc. IEEE Int. Conf. Comput. Vis., 2015, pp. 4211-4219.

[46] X. 李(X. Li)、Y. 郭(Y. Guo)和 D. 舒尔曼斯(D. Schuurmans)，《通过标签表示学习进行半监督零样本分类》，载于《电气与电子工程师协会国际计算机视觉会议论文集》，2015 年，第 4211 - 4219 页。

[47] X. Li and Y. Guo, "Max-margin zero-shot learning for multi-class classification," in Proc. 18th Int. Conf. Artif. Int. Statistics, 2015, pp. 626-634.

[47] X. 李(X. Li)和 Y. 郭(Y. Guo)，《用于多类分类的最大间隔零样本学习》，载于《第 18 届国际人工智能与统计会议论文集》，2015 年，第 626 - 634 页。

[48] Y. Fu and L. Sigal, "Semi-supervised vocabulary-informed learning," in Proc. IEEE Conf. Comput. Vis. Pattern Recognit., 2016, pp. 5337-5346.

[48] 傅(Fu)和西加尔(Sigal)，“半监督词汇感知学习”，收录于《电气与电子工程师协会计算机视觉与模式识别会议论文集》，2016 年，第 5337 - 5346 页。

[49] Z. Zhang and V. Saligrama, "Zero-shot recognition via structured prediction," in Proc. IEEE Conf. Comput. Vis. Pattern Recognit., 2016, pp. 2007-2016.

[49] 张(Zhang)和萨利格拉马(Saligrama)，“通过结构化预测实现零样本识别”，收录于《电气与电子工程师协会计算机视觉与模式识别会议论文集》，2016 年，第 2007 - 2016 页。

[50] T. Mensink, E. Gavves, and C. G. Snoek, "Costa: Co-occurrence statistics for zero-shot classification," in Proc. IEEE Conf. Comput. Vis. Pattern Recognit., 2014, pp. 2441-2448.

[50] 门辛克(Mensink)、加维斯(Gavves)和斯诺克(Snoek)，“科斯塔(Costa):用于零样本分类的共现统计”，收录于《电气与电子工程师协会计算机视觉与模式识别会议论文集》，2014 年，第 2441 - 2448 页。

[51] M. Rohrbach, M. Stark, G. Szarvas, I. Gurevych, and B. Schiele, "What helps where-and why? semantic relatedness for knowledge transfer," in Proc. IEEE Conf. Comput. Vis. Pattern Recognit., 2010, pp. 910-917.

[51] 罗尔巴赫(Rohrbach)、斯塔克(Stark)、萨尔瓦斯(Szarvas)、古雷维奇(Gurevych)和席勒(Schiele)，“什么在何处有帮助以及原因何在？用于知识迁移的语义相关性”，收录于《电气与电子工程师协会计算机视觉与模式识别会议论文集》，2010 年，第 910 - 917 页。

[52] S. Reed, Z. Akata, H. Lee, and B. Schiele, "Learning deep representations of fine-grained visual descriptions," in Proc. IEEE Conf. Comput. Vis. Pattern Recognit., 2016, pp. 49-58.

[52] 里德(Reed)、阿卡塔(Akata)、李(Lee)和席勒(Schiele)，“学习细粒度视觉描述的深度表示”，收录于《电气与电子工程师协会计算机视觉与模式识别会议论文集》，2016 年，第 49 - 58 页。

[53] M. Elhoseiny, B. Saleh, and A. Elgammal, "Write a classifier: Zero-shot learning using purely textual descriptions," in Proc. IEEE Int. Conf. Comput. Vis., 2013, pp. 2584-2591.

[53] 埃尔霍塞尼(Elhoseiny)、萨利赫(Saleh)和埃尔加马尔(Elgammal)，“编写分类器:仅使用文本描述的零样本学习”，收录于《电气与电子工程师协会国际计算机视觉会议论文集》，2013 年，第 2584 - 2591 页。

[54] S. Antol, C. L. Zitnick, and D. Parikh, "Zero-shot learning via visual abstraction," in Proc. Eur. Conf. Comput. Vis., 2014, pp. 401-416.

[54] 安托尔(Antol)、齐特尼克(Zitnick)和帕里克(Parikh)，“通过视觉抽象实现零样本学习”，收录于《欧洲计算机视觉会议论文集》，2014 年，第 401 - 416 页。

[55] T. Mensink, J. Verbeek, F. Perronnin, and G. Csurka, "Metric learning for large scale image classification: Generalizing to new classes at near-zero cost," in Proc. Eur. Conf. Comput. Vis., pp. 488-501, 2012.

[55] 门辛克(Mensink)、韦贝克(Verbeek)、佩罗宁(Perronnin)和丘尔卡(Csurka)，“大规模图像分类的度量学习:以近乎零成本推广到新类别”，收录于《欧洲计算机视觉会议论文集》，2012 年，第 488 - 501 页。

[56] J. Pennington, R. Socher, and C. D. Manning, "Glove: Global vectors for word representation," in Proc. Conf. Empirical Methods Natural Language Process., 2014, pp. 1532-1543.

[56] 彭宁顿(Pennington)、索切尔(Socher)和曼宁(Manning)，“手套(Glove):用于词表示的全局向量”，收录于《自然语言处理经验方法会议论文集》，2014 年，第 1532 - 1543 页。

[57] G. A. Miller, "Wordnet: A lexical database for English," CACM, vol. 38, pp. 39-41, 1995. [Online]. Available: http://doi.acm.org/ 10.1145/219717.219748

[57] 米勒(Miller)，“词网(Wordnet):英语词汇数据库”，《美国计算机协会通讯》，第 38 卷，第 39 - 41 页，1995 年。[在线]。可访问:http://doi.acm.org/ 10.1145/219717.219748

[58] N. Karessli, Z. Akata, B. Schiele, and A. Bulling, "Gaze embed-dings for zero-shot image classification," in Proc. IEEE Comput. Vis. Pattern Recognit., 2017, pp. 6412-6421.

[58] 卡雷斯利(Karessli)、阿卡塔(Akata)、席勒(Schiele)和布林(Bulling)，“用于零样本图像分类的注视嵌入”，收录于《电气与电子工程师协会计算机视觉与模式识别会议论文集》，2017 年，第 6412 - 6421 页。

[59] W. J. Scheirer, A. Rocha, A. Sapkota, and T. E. Boult, "Towards open set recognition," IEEE Trans. Pattern Anal. Mach. Intell., vol. 35, no. 7, pp. 1757-1772, Jul. 2013.

[59] 谢勒(Scheirer)、罗查(Rocha)、萨普科塔(Sapkota)和博尔特(Boult)，“迈向开放集识别”，《电气与电子工程师协会模式分析与机器智能汇刊》，第 35 卷，第 7 期，第 1757 - 1772 页，2013 年 7 月。

[60] L. Jain, W. Scheirer, and T. Boult, "Multi-class open set recognition using probability of inclusion," in Proc. 11th Eur. Conf. Com-put. Vis., 2014, pp. 393-409.

[60] 贾因(Jain)、谢勒(Scheirer)和博尔特(Boult)，“使用包含概率的多类开放集识别”，收录于《第 11 届欧洲计算机视觉会议论文集》，2014 年，第 393 - 409 页。

[61] H. Zhang, X. Shang, W. Yang, H. Xu, H. Luan, and T.-S. Chua, "Online collaborative learning for open-vocabulary visual classifiers," in Proc. IEEE Conf. Comput. Vis. Pattern Recognit., 2016, pp. 2809-2817.

[61] 张(Zhang)、尚(Shang)、杨(Yang)、徐(Xu)、栾(Luan)和蔡(Chua)，“开放词汇视觉分类器的在线协作学习”，收录于《电气与电子工程师协会计算机视觉与模式识别会议论文集》，2016 年，第 2809 - 2817 页。

[62] A. Bendale and T. E. Boult, "Towards open set deep networks," in Proc. IEEE Conf. Comput. Vis. Pattern Recognit., 2016, pp. 1563-1572.

[62] 本代尔(Bendale)和博尔特(Boult)，“迈向开放集深度网络”，收录于《电气与电子工程师协会计算机视觉与模式识别会议论文集》，2016 年，第 1563 - 1572 页。

[63] W.-L. Chao, S. Changpinyo, B. Gong, and F. Sha, "An empirical study and analysis of generalized zero-shot learning for object recognition in the wild," in Proc. 11th Eur. Conf. Comput. Vis., 2016, pp. 52-68.

[63] 赵(Chao)、张品耀(Changpinyo)、龚(Gong)和沙(Sha)，“野外目标识别广义零样本学习的实证研究与分析”，收录于《第 11 届欧洲计算机视觉会议论文集》，2016 年，第 52 - 68 页。

[64] T. Joachims, "Optimizing search engines using clickthrough data," in Proc. 8th ACM SIGKDD Int. Conf. Knowl. Discovery Data Mining, 2002, pp. 133-142.

[64] T. 约阿希姆斯(T. Joachims)，“利用点击数据优化搜索引擎”，载于《第8届ACM SIGKDD国际知识发现与数据挖掘会议论文集》(Proc. 8th ACM SIGKDD Int. Conf. Knowl. Discovery Data Mining)，2002年，第133 - 142页。

[65] N. Usunier, D. Buffoni, and P. Gallinari, "Ranking with ordered weighted pairwise classification," in Proc. Int. Conf. Mach. Learn., 2009, pp. 1057-1064.

[65] N. 于叙涅尔(N. Usunier)、D. 布福尼(D. Buffoni)和P. 加利纳里(P. Gallinari)，“使用有序加权成对分类进行排序”，载于《国际机器学习会议论文集》(Proc. Int. Conf. Mach. Learn.)，2009年，第1057 - 1064页。

[66] J. Weston, S. Bengio, and N. Usunier, "Wsabie: Scaling up to large vocabulary image annotation," in Proc. 22nd Int. Joint Conf. Artif. Intell., 2011, pp. 2764-2770.

[66] J. 韦斯顿(J. Weston)、S. 本吉奥(S. Bengio)和N. 于叙涅尔(N. Usunier)，“Wsabie:扩展到大型词汇图像标注”，载于《第22届国际人工智能联合会议论文集》(Proc. 22nd Int. Joint Conf. Artif. Intell.)，2011年，第2764 - 2770页。

[67] I. Tsochantaridis, T. Joachims, T. Hofmann, and Y. Altun, "Large margin methods for structured and interdependent output variables," J. Mach. Learn. Res., 2005, pp. 1453-1484.

[67] I. 索坎塔里季斯(I. Tsochantaridis)、T. 约阿希姆斯(T. Joachims)、T. 霍夫曼(T. Hofmann)和Y. 阿尔通(Y. Altun)，“用于结构化和相互依赖输出变量的大间隔方法”，《机器学习研究杂志》(J. Mach. Learn. Res.)，2005年，第1453 - 1484页。

[68] R. H. Bartels and G. Stewart, "Solution of the matrix equation ax+ $\mathrm{{xb}} = \mathrm{c}$ [f4]," Commun. ACM, vol. 15, no. 9, pp. 820-826,1972.

[68] R. H. 巴托尔斯(R. H. Bartels)和G. 斯图尔特(G. Stewart)，“矩阵方程ax + $\mathrm{{xb}} = \mathrm{c}$ [f4]的解”，《美国计算机协会通讯》(Commun. ACM)，第15卷，第9期，第820 - 826页，1972年。

[69] O. Chapelle, B. Scholkopf, and A. Zien, "Semi-supervised learning," IEEE Trans. Neural Netw., vol. 20, no. 3, p. 542, 2009.

[69] O. 沙佩勒(O. Chapelle)、B. 肖尔科普夫(B. Scholkopf)和A. 齐恩(A. Zien)，“半监督学习”，《IEEE神经网络汇刊》(IEEE Trans. Neural Netw.)，第20卷，第3期，第542页，2009年。

[70] D. Zhou, O. Bousquet, T. N. Lal, J. Weston, and B. Schölkopf, "Learning with local and global consistency," in Proc. Int. Conf. Neural Inf. Process. Syst., 2004, pp. 321-328.

[70] D. 周(D. Zhou)、O. 布斯凯(O. Bousquet)、T. N. 拉尔(T. N. Lal)、J. 韦斯顿(J. Weston)和B. 肖尔科普夫(B. Schölkopf)，“具有局部和全局一致性的学习”，载于《国际神经信息处理系统会议论文集》(Proc. Int. Conf. Neural Inf. Process. Syst.)，2004年，第321 - 328页。

[71] M. Ye and Y. Guo, "Zero-shot classification with discriminative semantic representation learning," in Proc. IEEE Conf. Comput. Vis. Pattern Recognit., 2017, pp. 5103-5111.

[71] M. 叶(M. Ye)和Y. 郭(Y. Guo)，“通过判别性语义表示学习进行零样本分类”，载于《IEEE计算机视觉与模式识别会议论文集》(Proc. IEEE Conf. Comput. Vis. Pattern Recognit.)，2017年，第5103 - 5111页。

[72] Y. Fujiwara and G. Irie, "Efficient label propagation," in Proc. Int. Conf. Mach. Learn., 2014, pp. 784-792.

[72] Y. 藤原(Y. Fujiwara)和G. 入江(G. Irie)，“高效的标签传播”，载于《国际机器学习会议论文集》(Proc. Int. Conf. Mach. Learn.)，2014年，第784 - 792页。

[73] C. Szegedy, W. Liu, Y. Jia, P. Sermanet, S. Reed, D. Anguelov, D. Erhan, V. Vanhoucke, and A. Rabinovich, "Going deeper with convolutions," in Proc. IEEE Conf. Comput. Vis. Pattern Recognit., 2015, pp. 1-5.

[73] C. 塞格迪(C. Szegedy)、W. 刘(W. Liu)、Y. 贾(Y. Jia)、P. 塞尔马内特(P. Sermanet)、S. 里德(S. Reed)、D. 安格洛夫(D. Anguelov)、D. 埃尔汉(D. Erhan)、V. 范霍克(V. Vanhoucke)和A. 拉宾诺维奇(A. Rabinovich)，“卷积神经网络的深度探索”，载于《IEEE计算机视觉与模式识别会议论文集》(Proc. IEEE Conf. Comput. Vis. Pattern Recognit.)，2015年，第1 - 5页。

[74] B. Zhou, A. Lapedriza, J. Xiao, A. Torralba, and A. Oliva, "Learning deep features for scene recognition using places database," in Proc. Int. Conf. Neural Inf. Process. Syst., 2014, pp. 487-495.

[74] B. 周(B. Zhou)、A. 拉佩德里扎(A. Lapedriza)、J. 肖(J. Xiao)、A. 托拉尔瓦(A. Torralba)和A. 奥利瓦(A. Oliva)，“使用Places数据库学习用于场景识别的深度特征”，载于《国际神经信息处理系统会议论文集》(Proc. Int. Conf. Neural Inf. Process. Syst.)，2014年，第487 - 495页。

[75] C. Szegedy, W. Liu, Y. Jia, P. Sermanet, S. Reed, D. Anguelov, D. Erhan, V. Vanhoucke, and A. Rabinovich, "Going deeper with convolutions," Proc. IEEE Conf. Comput. Vis. Pattern Recognit., 2015, pp. 1-9.

[75] C. 塞格迪(C. Szegedy)、W. 刘(W. Liu)、Y. 贾(Y. Jia)、P. 塞尔马内特(P. Sermanet)、S. 里德(S. Reed)、D. 安格洛夫(D. Anguelov)、D. 埃尔汉(D. Erhan)、V. 范霍克(V. Vanhoucke)和A. 拉宾诺维奇(A. Rabinovich)，“卷积神经网络的深度探索”，《IEEE计算机视觉与模式识别会议论文集》(Proc. IEEE Conf. Comput. Vis. Pattern Recognit.)，2015年，第1 - 9页。

[76] S. Garcia and F. Herrera, "An extension on"statistical comparisons of classifiers over multiple data sets"for all pairwise comparisons," J. Mach. Learn. Res., vol. 9, pp. 2677-2694, 2008.

[76] S. 加西亚(S. Garcia)和F. 埃雷拉(F. Herrera)，“对‘多数据集上分类器的统计比较’的扩展:用于所有成对比较”，《机器学习研究杂志》(J. Mach. Learn. Res.)，第9卷，第2677 - 2694页，2008年。

![0195d2b1-719e-720b-bdb3-2e8d7e8c28b6_14_867_430_230_282_0.jpg](images/0195d2b1-719e-720b-bdb3-2e8d7e8c28b6_14_867_430_230_282_0.jpg)

Yongqin Xian received the BSc degree in software engineering from Beijing Institute of Technology, China, in 2013, and the MSc degree with honors in computer science from Saarland University, Germany, in 2016. He is currently working toward the PhD degree in the Computer Vision and Multimodal Computing group at the Max-Planck Institute for Informatics in Saarbrücken, Germany. His research interests include machine learning and computer vision. He is a student member of the IEEE.

冼永勤(Yongqin Xian)于2013年在中国北京理工大学获得软件工程学士学位，并于2016年在德国萨尔兰大学以优异成绩获得计算机科学硕士学位。他目前正在德国萨尔布吕肯的马克斯·普朗克信息研究所的计算机视觉与多模态计算小组攻读博士学位。他的研究兴趣包括机器学习和计算机视觉。他是电气与电子工程师协会(IEEE)的学生会员。

![0195d2b1-719e-720b-bdb3-2e8d7e8c28b6_14_868_760_230_284_0.jpg](images/0195d2b1-719e-720b-bdb3-2e8d7e8c28b6_14_868_760_230_284_0.jpg)

Christoph Lampert received the PhD degree in mathematics from the University of Bonn, in 2003. In 2010 he joined the Institute of Science and Technology Austria (IST Austria) first as an assistant professor and since 2015 as a professor. His research on computer vision and machine learning has won several international and national awards, including the best paper prize at CVPR 2008. In 2012 he was awarded an ERC Starting Grant by the European Research Council. He is an editor of the International Journal of Computer Vision (IJCV), action editor of the Journal for Machine Learning Research (JMLR), and associate editor in chief of the IEEE Transactions on Pattern Analysis and Machine Intelligence (TPAMI).

克里斯托夫·兰佩特(Christoph Lampert)于2003年在波恩大学获得数学博士学位。2010年，他加入奥地利科学技术研究所(IST Austria)，最初担任助理教授，自2015年起担任教授。他在计算机视觉和机器学习方面的研究获得了多项国际和国内奖项，包括2008年计算机视觉与模式识别会议(CVPR)的最佳论文奖。2012年，他获得了欧洲研究理事会(ERC)的启动资金。他是《国际计算机视觉杂志》(IJCV)的编辑、《机器学习研究杂志》(JMLR)的行动编辑，以及电气与电子工程师协会《模式分析与机器智能汇刊》(TPAMI)的副主编。

![0195d2b1-719e-720b-bdb3-2e8d7e8c28b6_14_867_1195_231_284_0.jpg](images/0195d2b1-719e-720b-bdb3-2e8d7e8c28b6_14_867_1195_231_284_0.jpg)

Bernt Schiele received master's degree in computer science from the University of Karlsruhe and INP Grenoble, in 1994, and the PhD degree in computer vision from INP Grenoble, in 1997. He was a postdoctoral associate and visiting assistant professor with MIT between 1997 and 2000. From 1999 until 2004, he was an assistant professor with ETH Zurich and, from 2004 to 2010, he was a full professor of computer science with TU Darmstadt. In 2010, he was appointed a scientific member of the Max Planck Society and director at the Max Planck Institute for Informatics. Since 2010, he has also been a professor at Saarland University. His main interests include computer vision, perceptual computing, statistical learning methods, wearable computers, and integration of multimodal sensor data. He is particularly interested in developing methods which work under real world conditions. He is a fellow of the IEEE.

伯恩特·席勒(Bernt Schiele)于1994年在卡尔斯鲁厄大学和法国国立高等工业技术学院(INP Grenoble)获得计算机科学硕士学位，并于1997年在法国国立高等工业技术学院获得计算机视觉博士学位。1997年至2000年，他在麻省理工学院(MIT)担任博士后研究员和客座助理教授。1999年至2004年，他在苏黎世联邦理工学院(ETH Zurich)担任助理教授；2004年至2010年，他在达姆施塔特工业大学(TU Darmstadt)担任计算机科学正教授。2010年，他被任命为马克斯·普朗克学会的科学会员和马克斯·普朗克信息研究所所长。自2010年以来，他还担任萨尔兰大学的教授。他的主要研究兴趣包括计算机视觉、感知计算、统计学习方法、可穿戴计算机以及多模态传感器数据的集成。他特别热衷于开发能够在现实世界条件下运行的方法。他是电气与电子工程师协会(IEEE)的会士。

![0195d2b1-719e-720b-bdb3-2e8d7e8c28b6_14_870_1711_225_287_0.jpg](images/0195d2b1-719e-720b-bdb3-2e8d7e8c28b6_14_870_1711_225_287_0.jpg)

Zeynep Akata received the MSc degree from RWTH Aachen, in 2010, and the PhD degree from INRIA of Université de Grenoble, in 2014. She was a post-doctoral researcher with the Max Planck Institute for Informatics between 2014- 2017 and a visiting researcher at UC Berkeley, in 2016-2017. In 2014, she received Lise-Meitner Award for Excellent Women in Computer Science from Max Planck Society. She is currently an assistant professor with the University of Amsterdam, scientific manager of the Delta Lab and a senior researcher at Max Planck Institute for Informatics. Her research interests include machine learning combined with vision and language for the task of explainable artificial intelligence (XAI). She is a member of the IEEE.

泽内普·阿卡塔(Zeynep Akata)于2010年在亚琛工业大学(RWTH Aachen)获得硕士学位，并于2014年在格勒诺布尔大学法国国家信息与自动化研究所(INRIA of Université de Grenoble)获得博士学位。2014年至2017年，她在马克斯·普朗克信息研究所担任博士后研究员；2016年至2017年，她在加州大学伯克利分校(UC Berkeley)担任访问研究员。2014年，她获得了马克斯·普朗克学会颁发的计算机科学优秀女性利泽·迈特纳奖(Lise - Meitner Award)。她目前是阿姆斯特丹大学的助理教授、德尔塔实验室的科学经理，以及马克斯·普朗克信息研究所的高级研究员。她的研究兴趣包括将机器学习与视觉和语言相结合，用于可解释人工智能(XAI)任务。她是电气与电子工程师协会(IEEE)的会员。

$\vartriangleright$ For more information on this or any other computing topic, please visit our Digital Library at www.computer.org/publications/dlib.

$\vartriangleright$ 有关此主题或任何其他计算主题的更多信息，请访问我们的数字图书馆:www.computer.org/publications/dlib。