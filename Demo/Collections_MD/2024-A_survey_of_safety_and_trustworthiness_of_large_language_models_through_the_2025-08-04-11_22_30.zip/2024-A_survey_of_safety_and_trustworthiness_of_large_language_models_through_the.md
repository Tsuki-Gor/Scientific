# A survey of safety and trustworthiness of large language models through the lens of verification and validation

# 通过验证与确认(Verification and Validation)视角对大型语言模型(Large Language Models, LLMs)安全性与可信度的调研

Xiaowei Huang ${}^{1} \cdot$ Wenjie Ruan ${}^{1} \cdot$ Wei Huang ${}^{1,5} \cdot$ Gaojie Jin ${}^{1} \cdot$ Yi Dong ${}^{1} \cdot$ Changshun ${\mathrm{{Wu}}}^{2} \cdot$ Saddek Bensale ${\mathrm{m}}^{2} \cdot$ Ronghui ${\mathrm{{Mu}}}^{1} \cdot  \mathrm{{Yi}}{\mathrm{{Qi}}}^{1} \cdot  \mathrm{{Xingyu}}{\mathrm{{Zhao}}}^{1} \cdot$ Kaiwen Cai ${}^{1} \cdot  {\text{Yanghao Zhang}}^{1} \cdot  {\text{Sihao Wu}}^{1} \cdot$ Peipei Xu ${}^{1} \cdot  {\text{Dengyu Wu}}^{1} \cdot  {\text{Andre Freitas}}^{3} \cdot$ Mustafa A. Mustafa ${}^{3,4}$

黄晓伟 ${}^{1} \cdot$ 阮文杰 ${}^{1} \cdot$ 黄伟 ${}^{1,5} \cdot$ 金高杰 ${}^{1} \cdot$ 董毅 ${}^{1} \cdot$ 孙长顺 ${\mathrm{{Wu}}}^{2} \cdot$ 贝斯达克·本萨勒 ${\mathrm{m}}^{2} \cdot$ 荣辉 ${\mathrm{{Mu}}}^{1} \cdot  \mathrm{{Yi}}{\mathrm{{Qi}}}^{1} \cdot  \mathrm{{Xingyu}}{\mathrm{{Zhao}}}^{1} \cdot$ 蔡凯文 ${}^{1} \cdot  {\text{Yanghao Zhang}}^{1} \cdot  {\text{Sihao Wu}}^{1} \cdot$ 许佩佩 ${}^{1} \cdot  {\text{Dengyu Wu}}^{1} \cdot  {\text{Andre Freitas}}^{3} \cdot$ 穆斯塔法·A·穆斯塔法 ${}^{3,4}$

## Abstract

## 摘要

Large language models (LLMs) have exploded a new heatwave of AI for their ability to engage end-users in human-level conversations with detailed and articulate answers across many knowledge domains. In response to their fast adoption in many industrial applications, this survey concerns their safety and trustworthiness. First, we review known vulnerabilities and limitations of the LLMs, categorising them into inherent issues, attacks, and unintended bugs. Then, we consider if and how the Verification and Validation (V&V) techniques, which have been widely developed for traditional software and deep learning models such as convolutional neural networks as independent processes to check the alignment of their implementations against the specifications, can be integrated and further extended throughout the lifecycle of the LLMs to provide rigorous analysis to the safety and trustworthiness of LLMs and their applications. Specifically, we consider four complementary techniques: falsification and evaluation, verification, runtime monitoring, and regulations and ethical use. In total, ${370} +$ references are considered to support the quick understanding of the safety and trustworthiness issues from the perspective of V&V. While intensive research has been conducted to identify the safety and trustworthiness issues, rigorous yet practical methods are called for to ensure the alignment of LLMs with safety and trustworthiness requirements.

大型语言模型(LLMs)因其能够与终端用户进行人类水平的对话，提供详细且表达清晰的回答，涵盖众多知识领域，已引发人工智能(AI)领域的新热潮。为应对其在众多工业应用中的快速普及，本调研关注其安全性与可信度。首先，我们回顾了已知的LLMs的漏洞与局限，将其分类为固有问题、攻击手段和意外缺陷。随后，探讨了是否以及如何将为传统软件和深度学习模型(如卷积神经网络)广泛开发的验证与确认(V&V)技术，作为独立过程，用于检查模型实现与规范的一致性，整合并延伸到LLMs的整个生命周期，以提供对其安全性与可信度的严格分析。具体而言，我们考虑了四种互补的技术:反证与评估、验证、运行时监控，以及法规与伦理使用。总共，${370} +$篇文献被引用，以支持从V&V角度快速理解安全性与可信度问题。尽管已有大量研究致力于识别这些问题，但仍亟需严谨而实用的方法，以确保LLMs符合安全与可信的要求。

Keywords AI Safety - Trustworthy AI - Verification and Validation - Safeguarding - Large Language Models - Generative AI

关键词 AI安全 - 可信AI - 验证与确认 - 保障措施 - 大型语言模型 - 生成式AI

---

X Xiaowei Huang

黄晓伟

xiaowei.huang@liverpool.ac.uk

University of Liverpool, Liverpool, UK

利物浦大学，英国利物浦

Université Grenoble Alpes, Grenoble, France

格勒诺布尔阿尔卑斯大学，法国格勒诺布尔

The University of Manchester, Manchester, UK

曼彻斯特大学，英国曼彻斯特

COSIC, KU Leuven, Leuven, Belgium

比利时鲁汶 KU Leuven，科斯克研究所

Purple Mountain Laboratories, Nanjing, China

紫金山实验室，南京，中国

---

## 1 Introduction

## 1 引言

A large language model (LLM) is a deep learning model equipped with a massive amount of learnable parameters (commonly reaching more than 10 billion). LLMs are attention-based sequential models based on the transformer architecture (Hrinchuk et al. 2020), which consistently demonstrated the ability to learn universal representations of language. The universal representations of language can then be used in various Natural Language Processing (NLP) task. The recent scale-up of these models, in terms of both numbers of parameters and pre-trained corpora, has confirmed the universality of transformers as mechanisms to encode language representations. At a specific scale, these models started to exhibit in-context learning (Min et al. 2022; Ye et al. 2022), and the properties of learning from few examples (zero/one/few-shot-without the need for fine-tuning) and from natural language prompts (complex instructions which describe the behavioural intent that the model needs to operate). Recent works on Reinforcement Learning via Human Feedback (RLHF) (Ouyang et al. 2022) have further developed the ability of these models to align and respond to increasingly complex prompts, leading to their popularisation in systems such as ChatGPT (https://openai.com/chatgpt) and their use in a large spectrum of applications. The ability of LLMs to deliver sophisticated linguistic and reasoning behaviour, has pushed their application beyond their intended operational envelope.

大型语言模型(LLM)是一种深度学习模型，配备了大量可学习参数(通常超过100亿个)。LLMs基于变换器(Transformer)架构(Hrinchuk等，2020)，是一种关注机制的序列模型，已持续展现出学习通用语言表示的能力。通用的语言表示可以应用于各种自然语言处理(NLP)任务。近年来，随着参数规模和预训练语料库的扩大，这些模型的普适性得到了验证，变换器作为编码语言表示的机制显示出其强大能力。在特定规模下，这些模型开始展现出上下文学习能力(Min等，2022；Ye等，2022)，以及从少量示例(零/一/少-shot，无需微调)和自然语言提示(描述模型行为意图的复杂指令)中学习的特性。最近关于通过人类反馈的强化学习(Reinforcement Learning via Human Feedback, RLHF)(Ouyang等，2022)的研究，进一步提升了这些模型对复杂提示的对齐与响应能力，推动其在ChatGPT(https://openai.com/chatgpt)等系统中的应用，以及在广泛领域的应用。LLMs展现出复杂语言和推理行为的能力，已超出其原本设计的操作范围，推动其应用不断扩展。

While being consistently fluent, LLMs are prone to hallucinations (Shuster et al. 2021), stating factually incorrect statements (Shuster et al. 2022), lacking necessary mechanisms of safety, lacking transparency and control (Tanguy et al. 2016), among many others. Such vulnerabilities and limitations have already led to bad consequences such as suicide case (https://www.vice.com/en/article/pkadgm/man-dies-by-suicide-after-talking-with-ai-chatb ot-widow-says), lawyer submitted fabricated cases as precedent to the court (https://www.bbc.co.uk/news/world-us-canada-65735769), leakage of private information (https://www.engadget.com/chatgpt-briefly-went-offline-after-a-bug-revealed-user-chat-histories-11563 2504.html), etc. Therefore, research is urgently needed to understand the potential vulnerabilities and how the LLMs' behaviour can be assured to be safe and trustable. The goal of this paper is to provide a review of known vulnerabilities and limitations of LLMs and, more importantly, to investigate how the $\mathrm{V}\& \mathrm{V}$ techniques can be adapted to improve the safety and trustworthiness of LLMs. While there are several surveys on LLMs (Zhou et al. 2023; Zhao et al. 2023a), as well as a categorical archive of ChatGPT failures (Borji 2023), to the best of our knowledge, this is the first work that provides a comprehensive discussion on the safety and trustworthiness issues, from the perspective of the V&V.

虽然大规模语言模型(LLMs)始终保持流畅，但它们容易出现幻觉(Shuster等，2021)，陈述事实错误(Shuster等，2022)，缺乏必要的安全机制，缺乏透明度和可控性(Tanguy等，2016)，以及其他许多问题。这些漏洞和限制已经导致了诸如自杀事件(https://www.vice.com/en/article/pkadgm/man-dies-by-suicide-after-talking-with-ai-chatb ot-widow-says)、律师提交伪造案例作为判例(https://www.bbc.co.uk/news/world-us-canada-65735769)、私人信息泄露(https://www.engadget.com/chatgpt-briefly-went-offline-after-a-bug-revealed-user-chat-histories-115632504.html)等不良后果。因此，迫切需要开展研究，以理解潜在的漏洞以及如何确保大规模语言模型(LLMs)的行为安全可信。本文的目标是对已知的LLMs漏洞和限制进行综述，更重要的是，探讨如何将$\mathrm{V}\& \mathrm{V}$技术应用于提升LLMs的安全性和可信度。虽然已有关于LLMs的若干调研(Zhou等，2023；Zhao等，2023a)以及ChatGPT失败案例的分类存档(Borji，2023)，据我们所知，这是首次从验证与确认(V&V)的角度，全面讨论安全性和可信性问题的工作。

With the rising of LLMs and its wide applications, the need to ensure their safety and trustworthiness become prominent. Considering the broader subject of deep learning systems, to support their safety and trustworthiness, a diverse set of technical solutions have been developed by different research communities. For example, the machine learning community is focused on adversarial attacks (Goodfellow et al. 2014; Madry et al. 2017; Croce and Hein 2020; Xu et al. 2020a), outlier detectors Pang et al. (2021), adversarial training (Szegedy et al. 2013; Mirman et al. 2018; Wong et al. 2020), and explainable AI (Xu et al. 2019; Gunning et al. 2019; Ribeiro et al. 2016; Zhao et al. 2021a). The human-computer interaction community is focused on engaging the learning systems in the interactions with end users to improve the end users' confidence (Dudley and Kristens-son 2018). Formal methods community treats ML models as yet another symbolic system (evidenced by their consideration of neurons, layers, etc.) and adapts existing formal methods tools to work on the new systems (Huang et al. 2020a). While research has been intense on these individual methods, a synergy among them has not been addressed. Without a synergy, it is hard, if not impossible, to rigorously understand the causality between methods and how they might collectively support the safe and trusted autonomous systems at runtime. This survey is rooted in the field of AI assurance, aiming to apply a collection of rigorous V&V methods throughout the lifecycle of ML models, to provide assurance on the safety and trustworthiness. An illustrative diagram is given in Fig. 1 for general ML models. To begin with, data collection and synthesis is required to obtain as many as possible the training data, including the synthesis of high quality data through e.g., data argumentation or generative models. In the training phase, other than the prediction accuracy, multiple activities are needed, including e.g., the analysis of the learned feature representations and the checking for unintended bias. After the training, we apply offline V&V methods to the ML model, including techniques to falsify, explain, and verify the ML models. During the deployment phase, we must analyse the impact and hazard of the potential application environment. The operational design domain and operational data will be recorded. A run-time monitor is associated to the ML model to detect outliers, distribution shifts, and failures in the application environment. We may further apply reliability assessment methods to evaluate the reliability of the ML model and identify failure scenarios. Based on the detection or assessment results, we can identify the gaps for improvement. Finally, we outline the factors that affect the performance of the ML model, and optimise the training algorithm to obtain an enhanced ML model.

随着大规模语言模型(LLMs)的兴起及其广泛应用，确保其安全性和可信度的需求变得日益突出。考虑到深度学习系统的更广泛主题，为支持其安全性和可信度，不同研究社区开发了多样的技术方案。例如，机器学习(ML)社区关注对抗性攻击(Goodfellow等，2014；Madry等，2017；Croce和Hein，2020；Xu等，2020a)、异常检测(Pang等，2021)、对抗训练(Szegedy等，2013；Mirman等，2018；Wong等，2020)以及可解释人工智能(Xu等，2019；Gunning等，2019；Ribeiro等，2016；Zhao等，2021a)。人机交互(HCI)社区则致力于让学习系统与终端用户的交互，以提升用户信心(Dudley和Kristens-son，2018)。形式方法(Formal Methods)社区将机器学习模型视为另一种符号系统(通过考虑神经元、层等证据)，并将现有的形式方法工具应用于新系统(Huang等，2020a)。虽然这些单一方法的研究已相当深入，但它们之间的协同作用尚未得到充分解决。没有协同作用，就难以甚至不可能严格理解方法之间的因果关系，以及它们如何共同支持运行时的安全可信自主系统。本调研基于人工智能(AI)保障领域，旨在在整个机器学习模型生命周期中应用一系列严谨的验证与确认(V&V)方法，以提供安全性和可信度的保障。图1展示了通用机器学习模型的生命周期V&V方法总结。首先，需要收集和合成尽可能多的训练数据，包括通过数据增强或生成模型等方式合成高质量数据。在训练阶段，除了预测准确性外，还需进行多项活动，例如分析学习到的特征表示和检查潜在的偏差。在训练完成后，应用离线的V&V方法对模型进行验证，包括反证、解释和验证技术。在部署阶段，必须分析潜在应用环境的影响和风险，记录操作设计域(Operational Design Domain)和操作数据。还会配备运行时监控器，用于检测异常值、分布变化和应用环境中的故障。进一步可以采用可靠性评估方法，评估模型的可靠性并识别故障场景。根据检测或评估结果，识别改进的空白点。最后，分析影响模型性能的因素，优化训练算法，以获得更优的模型。

![bo_d1m003f7aajc73dif160_2_152_185_1224_625_0.jpg](images/bo_d1m003f7aajc73dif160_2_152_185_1224_625_0.jpg)

Fig. 1 Summarisation of lifecycle V&V methods to support AI Assurance

图1  支持人工智能保障的生命周期验证与确认(V&V)方法总结

These V&V techniques have been successful in supporting the reliable and dependable development of software and hardware that are applied to safety-critical systems, and have been adapted to work with machine learning models, mainly focusing on the convolutional neural networks for image classification [see surveys such as Huang et al. (2020a), Liu et al. (2021a) and textbooks such as Huang et al. (2012)], but also extended to consider, for example, object detection, deep reinforcement learning, and recurrent neural networks. This paper discusses how to extend further the V&V techniques to deal with the safety and trustworthiness challenges of LLMs.

这些V&V(验证与确认)技术在支持安全关键系统的软件和硬件的可靠性与可信性开发方面取得了成功，并已被改进以适应机器学习模型，主要集中在用于图像分类的卷积神经网络(Convolutional Neural Networks，CNNs)[参见Huang等(2020a)、Liu等(2021a)以及Huang等(2012)等教材的综述]，但也扩展到考虑例如目标检测、深度强化学习和循环神经网络等方面。本文讨论了如何进一步扩展V&V技术，以应对大型语言模型(LLMs)的安全性和可信性挑战。

$\mathrm{V}\& \mathrm{\;V}$ are independent procedures that are used together for checking that a system (or product, service) meets requirements and specifications and that it fulfills its intended purpose (https://www.imdrf.org/sites/default/files/docs/ghtf/final/sg3/technical-docs/ ghtf-sg3-n99-10-2004-qms-process-guidance-04010.pdf). Among them, verification techniques check the system against a set of design specifications, and validation techniques ensure that the system meets the user's operational needs. From software, convolutional neural networks to LLMs, the scale of the systems grows significantly, which makes the usual V&V techniques less capable due to their computational scalability issues. White-box V&V techniques that take the learnable parameters as their algorithmic input will not work well in practice. Instead, the research should focus on black-box techniques, on which some research has started for convolutional neural networks. In addition, V&V techniques need to consider the non-deterministic nature of LLMs (i.e., different outputs for two tests with identical input), which is a noticeable difference with the usual neural networks, such as convolutional neural networks and object detectors, that currently most $\mathrm{V}\& \mathrm{\;V}$ techniques work on.

$\mathrm{V}\& \mathrm{\;V}$是独立的程序，结合使用以检查系统(或产品、服务)是否符合要求和规范，以及是否实现其预期目的(https://www.imdrf.org/sites/default/files/docs/ghtf/final/sg3/technical-docs/ ghtf-sg3-n99-10-2004-qms-process-guidance-04010.pdf)。其中，验证技术用于检查系统是否符合一套设计规范，确认技术确保系统满足用户的操作需求。从软件、卷积神经网络到LLMs，系统规模显著扩大，这使得传统的V&V技术在计算可扩展性方面面临挑战。以可学习参数作为算法输入的白盒V&V技术在实际中效果不佳。相反，研究应集中在黑盒技术上，目前已有一些关于卷积神经网络的研究。此外，V&V技术还需要考虑LLMs的非确定性特性(即对相同输入的两次测试可能产生不同输出)，这与目前大多数$\mathrm{V}\& \mathrm{\;V}$技术所适用的传统神经网络(如卷积神经网络和目标检测器)存在明显差异。

Considering the fast development of LLMs, this survey does not intend to be complete (although it includes ${370} +$ references), especially when it comes to the applications of LLMs in various domains, but rather a collection of organised literature reviews and discussions to support the understanding of the safety and trustworthiness issues from the perspective of V&V. Through the survey, we noticed that the current research are focused on identifying the vulnerabilities, with limited efforts on systematic approaches to evaluate and verify the safety and trustworthiness properties.

鉴于LLMs的快速发展，本综述并不打算全面覆盖(尽管包含${370} +$参考文献)，尤其是在LLMs在各个领域应用方面，而是作为一份有组织的文献综述和讨论，旨在从V&V的角度帮助理解安全性和可信性问题。通过本次调研，我们注意到当前的研究主要集中在识别漏洞方面，关于系统性评估和验证安全性与可信性属性的工作较少。

The structure of the paper is as follows. In Sect. 2, we review the LLMs and its categories, its lifecycle, and several techniques introduced to improve safety and trustworthiness. Then, in Sect. 3, we present a review of existing vulnerabilities. This is followed by a general verification framework in Sect. 4. The framework includes V&V techniques such as falsification and evaluation (Sect. 5), verification (Sect. 6), runtime monitor (Sect. 7), and ethical use (Sect. 8). We conclude the paper in Sect. 10.

本文结构如下。第2节回顾LLMs及其类别、生命周期，以及为提升安全性和可信性而引入的几种技术。第3节介绍现有漏洞的综述。第4节提出一个通用的验证框架，包括伪造与评估(第5节)、验证(第6节)、运行时监控(第7节)和伦理使用(第8节)等V&V技术。第10节为全文总结。

## 2 Large language models

## 2 大型语言模型

This section summarises the categories of machine learning tasks based on LLMs, followed by a discussion of the lifecycle of LLMs. We will also discuss a few fundamental techniques relevant to the safety analysis.

本节总结了基于LLMs的机器学习任务类别，并讨论了LLMs的生命周期。我们还将介绍一些与安全分析相关的基础技术。

### 2.1 Categories of large language models

### 2.1 大型语言模型的类别

LLMs have been applied to many tasks, such as text generation (Li et al. 2022) content summary (Zhang et al. 2023a) conversational AI (i.e., chatbots) (Wei et al. 2023) and image synthesis (Koh et al. 2023) Other LLMs applications can be seen as their adaptations or further applications. In the following, we discuss the two most notable categories of LLMs: text-based conversational AI and image synthesis. While they might have slightly different concerns, this survey will be more focused on issues related to the former, without touching some issues that are specific to image synthesis such as the detection of fake images.

LLMs已被应用于许多任务，如文本生成(Li等，2022)、内容摘要(Zhang等，2023a)、对话式AI(即聊天机器人)(Wei等，2023)和图像合成(Koh等，2023)。其他LLMs的应用可以视为其改编或扩展。在下文中，我们将讨论两类最具代表性的LLMs:基于文本的对话式AI和图像合成。虽然它们可能存在一些不同的关注点，但本综述将主要关注与前者相关的问题，而不涉及一些特定于图像合成的问题，例如假图片的检测。

![bo_d1m003f7aajc73dif160_4_156_185_1218_563_0.jpg](images/bo_d1m003f7aajc73dif160_4_156_185_1218_563_0.jpg)

Fig. 2 Large language models: evolution roadmap

图2 大型语言模型:演进路线图

#### 2.1.1 Text-based conversational AI

#### 2.1.1 基于文本的对话式AI

LLMs are designed to understand natural language and generate human-like responses to queries and prompts. Almost all NLP tasks [e.g., language translation (Brants et al. 2007) chatbots (Lin et al. 2019; Gu et al. 2020) and virtual assistants (Tulshan and Dhage 2019)] have witnessed tremendous success with Transformer-based pretrained language models (T-PTLMs), relying on Transformer (Vaswani et al. 2017) self-supervised learning (Jaiswal et al. 2020; Liu et al. 2021b)and transfer learning (Houlsby et al. 2019; Ruder et al. 2019) to process and understand the nuances of human language, including grammar, syntax, and context.

大型语言模型(LLMs)旨在理解自然语言并生成类似人类的响应，以应对查询和提示。几乎所有的自然语言处理(NLP)任务[例如，语言翻译(Brants等，2007)、聊天机器人(Lin等，2019；Gu等，2020)和虚拟助手(Tulshan和Dhage，2019)]都在基于Transformer的预训练语言模型(T-PTLMs)中取得了巨大成功，这些模型依赖于Transformer(Vaswani等，2017)自监督学习(Jaiswal等，2020；Liu等，2021b)和迁移学习(Houlsby等，2019；Ruder等，2019)来处理和理解人类语言的细微差别，包括语法、句法和语境。

The well-known text-based LLMs include GPT-1 (Radford et al. 2018) BERT (Devlin et al. 2019) XLNet (Yang et al. 2019) RoBERTa (Liu et al. 2019) ELECTRA (Clark et al. 2020) T5 (Raffel et al. 2020) ALBERT (Lan et al. 2019) BART (Lewis et al. 2020) and PEGASUS (Zhang et al. 2020). These models can learn general language representations from large volumes of unlabelled text data through self-supervised learning and subsequently transfer this knowledge to specific tasks, which has been a major factor contributing to their success in NLP (Kalyan et al. 2021). Kaplan et al. (2020) demonstrated that simply increasing the size of T-PTLMs can lead to improved performance (Kalyan et al. 2021). This finding has spurred the development of LLMs such as GPT-3 (Brown et al. 2020c), PANGU (Zeng et al. 2021b), GShard (Lepikhin et al. 2020), Switch-Transformers (Fedus et al. 2021) and GPT-4 (OpenAI 2023).

著名的基于文本的大型语言模型包括GPT-1(Radford等，2018)、BERT(Devlin等，2019)、XLNet(Yang等，2019)、RoBERTa(Liu等，2019)、ELECTRA(Clark等，2020)、T5(Raffel等，2020)、ALBERT(Lan等，2019)、BART(Lewis等，2020)和PEGASUS(Zhang等，2020)。这些模型通过自监督学习从大量未标注的文本数据中学习通用的语言表示，随后将这些知识迁移到特定任务中，这在自然语言处理(Kalyan等，2021)中起到了关键作用。Kaplan等(2020)证明，单纯增加T-PTLMs的规模可以提升性能(Kalyan等，2021)。这一发现推动了如GPT-3(Brown等，2020c)、PANGU(Zeng等，2021b)、GShard(Lepikhin等，2020)、Switch-Transformers(Fedus等，2021)和GPT-4(OpenAI，2023)等大型模型的发展。

With the advancement of the Transformer development (Vaswani et al. 2017), significant enhancements were achieved in handling sequential data. Leveraging the Transformer architecture, LLMs have been created as potent models with the capacity to generate text resembling human language. ChatGPT represents a distinct embodiment of an LLM, characterised by its remarkable performance that yields groundbreaking outcomes. The progression of LLMs, depicted in Fig. 2, starts from the evolution of deep learning and transformer-based frameworks, culminating in the latest explosion of LLMs. We divide the LLMs into Encoder-only, Decoder-only, and Encoder-Decoder according to Yang et al. (2023). In Encoder-only and Encoder-Decoder architectures, the model predicts masked words in a sentence while taking into account the surrounding context. While Decoder-only models are trained by generating the subsequent word in a sequence based on the preceding words. GPT-style language model belongs to the Decoder-only type.

随着Transformer(Vaswani等，2017)架构的发展，在处理序列数据方面取得了显著的提升。利用Transformer架构，已开发出具有强大能力的模型，能够生成类似人类语言的文本。ChatGPT是大型语言模型的一个典型代表，其卓越的性能带来了突破性的成果。图2所示的大型语言模型的演变过程，从深度学习和基于Transformer的框架的演进开始，最终发展到最新的爆发式增长。我们根据Yang等(2023)将大型语言模型分为编码器(Encoder)专用、解码器(Decoder)专用和编码器-解码器(Encoder-Decoder)三类。在编码器和编码器-解码器架构中，模型在预测句子中的掩码词时会考虑周围的上下文。而解码器模型则通过生成序列中的下一个词，基于前面的词进行训练。GPT风格的语言模型属于解码器(Decoder)专用类型。

We also note that, there are advanced uses of LLMs (or advanced prompt engineering) by considering e.g., self-consistency (Wang et al. 2023b), knowledge graph (Pan et al. 2023), generating programs as the intermediate reasoning steps (Gao et al. 2023), generating both reasoning traces and task-specific actions in an interleaved manner (Yao et al. 2023), etc.

我们还注意到，存在对大型语言模型(或高级提示工程)的更先进应用，例如考虑自一致性(Wang等，2023b)、知识图谱(Pan等，2023)、生成程序作为中间推理步骤(Gao等，2023)、以交错方式生成推理轨迹和任务特定操作(Yao等，2023)等。

#### 2.1.2 Text-based image synthesis

#### 2.1.2 基于文本的图像合成

The transformer model (Vaswani et al. 2017) has become the standard choice for Language Modelling tasks, but it has also found widespread integration in text-to-image tasks. We present a chronological overview of the advancements in text-to-image research. DALL-E (Ramesh et al. 2021) is a representative approach that leverages Transformers for a text-to-image generation. The methodology involves training a dVAE (Rolfe 2016) and subsequently training a 12B decoder-only sparse transformer supervised by image tokens from the pre-trained dVAE. The transformer generates image tokens solely based on text tokens during inference. The resulting image candidates are evaluated by a pretrained CLIP model (Radford et al. 2017) to produce the final generated image. StableFusion (Rombach et al. 2022) differs from DALL-E (Ramesh et al. 2021) by using a diffusion model instead of a Transformer to generate latent image tokens. To incorporate text input, StableFusion (Rombach et al. 2022) first encodes the text using a transformer then conditions the diffusion model on the resulting text tokens. GLIDE (Nichol et al. 2021) employs a transformer model (Vaswani et al. 2017) to encode the text input and then trains a diffusion model to generate images that are conditioned on the text tokens directly. DALL-E2 (Ramesh et al. 2022) effectively leverages LLMs by following a three-step process. First, a CLIP model is trained using text-image pairs. Next, using text tokens as input, an autoregressive or diffusion model generates image tokens. Finally, based on these image tokens, a diffusion model is trained to produce the final image. Imagen (Saharia et al. 2022) employs a pre-trained text encoder, such as BERT (Devlin et al. 2018) or CLIP (Radford et al. 2017), to encode text. It then uses multiple diffusion models to train a process that generates images that start from low-resolution and gradually progress to high-resolution. Parti (Yu et al. 2022) demonstrates that a VQGAN (Esser et al. 2021) and Transformer architecture can achieve superior image synthesis outcomes compared to previous approaches, even without utilising a diffusion model. The eDiff-I model (Balaji et al. 2022) has recently achieved state-of-the-art performance on the MS-COCO dataset (Lin et al. 2014) by leveraging a combination of CLIP and diffusion models.

变换器模型(Vaswani等，2017)已成为语言模型(Language Modelling)任务的标准选择，但它也在文本到图像(text-to-image)任务中得到了广泛应用。本文提供了文本到图像研究的时间演进概述。DALL-E(Ramesh等，2021)是利用变换器(Transformer)进行文本到图像生成的代表性方法。其方法包括训练一个dVAE(Rolfe，2016)，随后训练一个由图像标记(image tokens)监督的12B参数的仅解码器稀疏变换器(decoder-only sparse transformer)，该变换器由预训练的dVAE提供指导。在推理过程中，变换器仅根据文本标记生成图像标记。最终生成的图像候选由预训练的CLIP模型(Radford等，2017)评估，以产生最终的生成图像。StableFusion(Rombach等，2022)不同于DALL-E(Ramesh等，2021)，它采用扩散模型(diffusion model)代替变换器来生成潜在图像标记(latent image tokens)。为了引入文本输入，StableFusion(Rombach等，2022)首先使用变换器对文本进行编码，然后将生成的文本标记作为条件输入到扩散模型中。GLIDE(Nichol等，2021)使用变换器模型(Vaswani等，2017)对文本输入进行编码，随后训练扩散模型以直接根据文本标记生成图像。DALL-E2(Ramesh等，2022)通过三步流程有效利用大规模语言模型(LLMs):首先，训练一个结合文本-图像对的CLIP模型；其次，使用文本标记作为输入，利用自回归(autoregressive)或扩散模型生成图像标记；最后，基于这些图像标记训练扩散模型以生成最终图像。Imagen(Saharia等，2022)采用预训练的文本编码器(如BERT(Devlin等，2018)或CLIP(Radford等，2017))对文本进行编码，然后使用多个扩散模型训练一个逐步从低分辨率到高分辨率生成图像的过程。Parti(Yu等，2022)证明，VQGAN(Esser等，2021)结合变换器架构，即使不使用扩散模型，也能实现优于以往方法的图像合成效果。eDiff-I模型(Balaji等，2022)近期在MS-COCO数据集(Lin等，2014)上取得了最先进的性能，结合了CLIP和扩散模型的优势。

In summary, text-to-image research commonly utilises transformer models (Vaswani et al. 2017) for encoding text input and either the diffusion model or the decoder of an autoencoder for generating images from latent text or image tokens.

总之，文本到图像的研究通常利用变换器模型(Vaswani等，2017)对文本输入进行编码，并使用扩散模型或自编码器(autoencoder)的解码器，从潜在的文本或图像标记中生成图像。

### 2.2 Lifecycle of LLMs

### 2.2 大规模语言模型(LLMs)的生命周期

Figure 3 illustrates the lifecycle stages and the vulnerabilities of LLMs. This section will focus on the introduction of lifecycle stages, and the detailed discussions about vulnerabilities will appear in Sect. 3. The offline model construction is formed of three steps (Zhao et al. 2023a): pre-training, adaptation tuning, and utilisation improvement, such that each step includes several interleaving sub-steps. In general, the pre-training step is similar to the usual machine learning training that goes through data collection, architecture selection, and training. On adaptation tuning, it might conduct instruction tuning (Lou et al. 2023) to learn from task instructions, and alignment tuning (Ouyang et al. 2022; Christiano et al. 2017) to make sure LLMs are aligned with human values, e.g., fair, honest, and harmless. Beyond this, to improve the interaction with the end users, utilisation improvements may be conducted through, for example, in-context learning (Brown et al. 2020c) and chain-of-thought learning (Wei et al. 2022).

图3展示了大规模语言模型的生命周期阶段及其潜在风险。本节将重点介绍生命周期阶段的引入，关于漏洞的详细讨论将在第3节中展开。离线模型的构建包括三个步骤(Zhao等，2023a):预训练、适应调优和利用改进，每个步骤都包含若干交叉的子步骤。一般而言，预训练步骤类似于常规的机器学习训练流程，包括数据收集、架构选择和训练。在适应调优方面，可能进行指令调优(Lou等，2023)以学习任务指令，以及对齐调优(Ouyang等，2022；Christiano等，2017)以确保大模型(LLMs)符合人类价值观，例如公平、诚实和无害。除此之外，为了改善与终端用户的交互，还可以通过上下文学习(Brown等，2020c)和链式思维学习(Wei等，2022)等方法进行利用改进。

![bo_d1m003f7aajc73dif160_6_157_186_1216_567_0.jpg](images/bo_d1m003f7aajc73dif160_6_157_186_1216_567_0.jpg)

Fig. 3 Large language models: lifecycle and vulnerabilities

图3 大规模语言模型:生命周期与漏洞

Once an LLM is trained, an evaluation is needed to ensure that its performance matches the expectation. Usually, we consider the evaluation from three perspectives: evaluation on basic performance, safety analysis to evaluate the consequence of applying the LLM in an application, and the evaluation through publicly available benchmark datasets. The basic performance evaluation considers several basic types of abilities such as language generation and complex reasoning. Safety analysis is to understand the impacts of human alignment, interaction with external environment, and incorporation of LLMs into broader applications such as search engines. On top of these, benchmark datasets and publicly available tools are used as well to support the evaluation. The evaluation will determine if the LLM is acceptable (for pre-specified criteria), and if so, the process will move forward to the deployment stage. Otherwise, at least one failure will be identified, and the process will move back to either of the three training steps.

一旦训练完成大型语言模型(LLM)，就需要进行评估以确保其性能符合预期。通常，我们从三个角度考虑评估:基础性能评估、安全性分析(以评估在应用中使用LLM的后果)以及通过公开可用的基准数据集进行的评估。基础性能评估涉及语言生成和复杂推理等几种基本能力。安全性分析旨在理解人类对齐、与外部环境的交互以及将LLM融入更广泛应用(如搜索引擎)中的影响。在此基础上，还会利用基准数据集和公开工具支持评估。评估的结果将决定该LLM是否符合预设标准，如果符合，流程将进入部署阶段；否则，至少会发现一次失败，流程将返回到三次训练步骤中的任意一步。

On the deployment stage, we will determine how the LLM will be used. For example, it could be available in a web platform for direct interaction with end users, such as the Chat-GPT. ${}^{1}$ Alternatively, it may be embedded into a search engine, such as the new Bing. ${}^{2}$ Nevertheless, according to the common practice, a guardrail is imposed on the conversations between LLMs and end users to ensure that the AI regulation is maximally implemented.

在部署阶段，我们将确定LLM的使用方式。例如，它可以在网页平台上供终端用户直接交互，如Chat-GPT。${}^{1}$或者，它也可以嵌入到搜索引擎中，比如新版的必应。${}^{2}$然而，根据常规做法，会对LLM与终端用户之间的对话设置安全防护措施，以最大程度地落实人工智能监管。

In Fig. 2, within the LLMs lifecycle, three main issues run through: performance issues, sustainability issues, and unintended bugs. These may be caused by one or more stages in the lifecycle. The red block shows that vulnerabilities appear in the LLMs lifecycle, and they may appear in the early stage of the whole period. For example, backdoor attacks and poisoning can contaminate raw data. When LLMs are deployed, problems such as a robustness gap may also arise.

图2显示，在LLM生命周期中，贯穿始终的三个主要问题是:性能问题、可持续性问题和意外漏洞。这些问题可能由生命周期中的一个或多个阶段引起。红色块显示，漏洞会在LLM生命周期中出现，且可能在早期阶段出现。例如，后门攻击和数据污染可能污染原始数据。当LLM部署后，也可能出现鲁棒性差等问题。

---

${}^{1}$ https://openai.com/blog/ChatGPT.

${}^{1}$ https://openai.com/blog/ChatGPT。

${}^{2}$ https://www.bing.com/new.

${}^{2}$ https://www.bing.com/new。

---

### 2.3 Key techniques relevant to safety and trustworthiness

### 2.3 与安全性和可信度相关的关键技术

In the following, we discuss two fundamental techniques that are distinct from the usual deep learning models and have been used by e.g., ChatGPT to improve safety and trustworthiness: reinforcement learning from human feedback and guardrails.

下面，我们将讨论两种不同于常规深度学习模型的基础技术，这些技术已被如ChatGPT等应用用以提升安全性和可信度:人类反馈强化学习(Reinforcement Learning from Human Feedback, RLHF)和安全防护措施(Guardrails)。

#### 2.3.1 Reinforcement learning from human feedback (RLHF)

#### 2.3.1 人类反馈强化学习(RLHF)

RLHF can be conducted in any stage of the "Adaptation Tuning", "Utilisation Improvement", or "Evaluation" in the framework of Fig. 3. RLHF (Christiano et al. 2017; Ouyang et al. 2022; Bai et al. 2022a, b; OpenAI 2023; Lambert et al. 2022; Ziegler et al. 2019) plays a crucial role in the training of language models, as it allows the model to learn from human guidance and avoid generating harmful content. In essence, RLHF assists in aligning language models with safety considerations through fine-tuning with human feedback. OpenAI initially introduced the concept of incorporating human feedback to tackle complex reinforcement learning tasks in Christiano et al. (2017), which subsequently facilitated the development of more sophisticated LLMs, from InstructGPT (Ouyang et al. 2022) to GPT4 (OpenAI 2023). According to InstructGPT (Ouyang et al. 2022), the RLHF training process typically begins by learning a reward function intended to reflect what humans value in the task, utilising human feedback on the model's outputs. Subsequently, the language model is optimised via an RL algorithm, such as PPO (Schulman et al. 2017), using the learned reward function. Reward model training and fine-tuning with RL can be iterated continuously. More comparison data is collected on the current best policy, which is used to train a new reward model and policy. The InstructGPT models demonstrated enhancements in truthfulness and reductions in generating toxic outputs while maintaining minimal performance regressions on public NLP datasets.

RLHF可以在“适应调优”、“利用改进”或“评估”框架中的任何阶段进行(见图3)。RLHF(Christiano等，2017；Ouyang等，2022；Bai等，2022a、b；OpenAI，2023；Lambert等，2022；Ziegler等，2019)在语言模型训练中起着关键作用，因为它允许模型从人类指导中学习，避免生成有害内容。本质上，RLHF通过结合人类反馈进行微调，有助于使语言模型符合安全考虑。OpenAI最初提出引入人类反馈以应对复杂强化学习任务的概念(Christiano等，2017)，随后推动了更先进的LLM(如InstructGPT(Ouyang等，2022)和GPT-4(OpenAI，2023))的发展。根据InstructGPT(Ouyang等，2022)，RLHF的训练过程通常从学习一个反映人类价值的奖励函数开始，利用人类对模型输出结果的反馈。随后，使用如PPO(Schulman等，2017)等强化学习算法，基于学习到的奖励函数对语言模型进行优化。奖励模型的训练和RL微调可以不断迭代。通过在当前最优策略上收集更多对比数据，用于训练新的奖励模型和策略。InstructGPT模型在真实性和减少有害输出方面表现出改进，同时在公共自然语言处理(NLP)数据集上的性能变化很小。

Following InstructGPT, Red Teaming language models (Bai et al. 2022a) introduces a harmlessness preference model to help RLHF to get less harmful agents. The comparison data from red team attacks is used as the training data to develop the harmlessness preference model. The authors of Bai et al. (2022a) utilised the helpful and harmless datasets in preference modelling and RLHF to fine-tune LLMs. They discovered that there was a significant tension between helpfulness and harmlessness. Experiments showed helpfulness and harmlessness model is significantly more harmless than the model trained only on helpfulness data. They also found that alignment with RLHF has many benefits and no cost to performance, like combining alignment training with programming ability and summarisation. The authors of Ganguli et al. (2023) found that LLMs trained with RLHF have the capability for moral self-correction. They believe that the models can learn intricate normative concepts such as stereotyping, bias, and discrimination that pertain to harm. Constitutional AI (Bai et al. 2022b) trains the preference model by relying solely on AI feedback, without requiring human labels to identify harmful outputs. To push the process of aligning LLMs with RLHF, an open-sourced modular library, RL4LMs, and evaluation benchmark, GRUE, designed for optimising language generator with RL are introduced in Ramamurthy et al. (2022). Inspired by the success of RLHF in language-related domains, fine-tuning approaches that utilise human feedback to improve text-to-image models (Lee et al. 2023; Xu et al. 2023; Wu et al. 2023c) have gained popularity as well. To achieve human-robot coexistence, the authors of Gu et al. (2023b) proposed a human-centred robot RL framework consisting of safe exploration, safety value alignment, and safe collaboration. They discussed the importance of interactive behaviours and four potential challenges within human-robot interactive procedures. Although many works indicate that RLHF could decrease the toxicity of generations from LLMs, the induced RLHF, like introducing malicious examples by annotators (Carlini et al. 2023), may cause catastrophic performance and risks. We hope better techniques that lead to transparency, safe and trustworthy RLHF will be developed in the coming future.

继InstructGPT之后，红队(Bai等人，2022a)引入了无害偏好模型，以帮助RLHF(强化学习与人类反馈)获得更少有害的代理。来自红队攻击的对比数据被用作训练数据，以开发无害偏好模型。Bai等人(2022a)的作者在偏好建模和RLHF中利用了有帮助和无害的数据集，以微调大型语言模型(LLMs)。他们发现有帮助性和无害性之间存在显著的矛盾。实验表明，有帮助性和无害性模型明显比仅用有帮助性数据训练的模型更为无害。他们还发现，与RLHF的对齐具有许多好处，并且不会影响性能，比如将对齐训练与编程能力和总结能力结合。Ganguli等人(2023)的作者发现，用RLHF训练的LLMs具有道德自我纠正的能力。他们认为模型可以学习复杂的规范性概念，如刻板印象、偏见和歧视，这些都与伤害相关。宪法AI(Bai等人，2022b)通过仅依赖AI反馈训练偏好模型，无需人工标签来识别有害输出。为了推动LLMs与RLHF的对齐过程，Ramamurthy等人(2022)引入了开源的模块化库RL4LMs和用于优化语言生成器的RL的评估基准GRUE。受到RLHF在语言相关领域成功的启发，利用人类反馈改进文本到图像模型的微调方法(Lee等人，2023；Xu等人，2023；Wu等人，2023c)也逐渐流行起来。为了实现人机共存，Gu等人(2023b)的作者提出了一个以人为中心的机器人RL框架，包括安全探索、安全价值对齐和安全协作。他们讨论了交互行为的重要性以及人机交互过程中可能面临的四个挑战。虽然许多研究表明RLHF可以降低LLMs生成内容的毒性，但引入恶意示例(如注释者的恶意示范，Carlini等人，2023)可能导致灾难性的性能下降和风险。我们希望未来能开发出更好的技术，实现透明、安全和可信的RLHF。

![bo_d1m003f7aajc73dif160_8_161_189_1211_395_0.jpg](images/bo_d1m003f7aajc73dif160_8_161_189_1211_395_0.jpg)

Fig. 4 Taxonomy of vulnerabilities

图4 漏洞分类

#### 2.3.2 Guardrails

#### 2.3.2 防护措施

Considering that some LLMs are interacting directly with end-users, it is necessary to put a layer of protection, called guardrail, when the end users ask for information about violence, profanity, criminal behaviours, race, or other unsavoury topics. Guardrails are deployed in most, if not all, LLMs, including ChatGPT, Claude, and LLaMA. In such cases, a response is provided with the LLM refusing to provide information. While this is a very thin layer of protection because there are many tricks (such as prompt injections that will be reviewed in Sect. 5.1) to circumvent it, it enhances the social responsibility of LLMs.

考虑到一些大型语言模型(LLMs)直接与终端用户交互，当用户询问关于暴力、粗话、犯罪行为、种族或其他不良话题时，有必要设置一层保护措施，称为防护栏(guardrail)。防护栏在大多数(如果不是全部的话)LLMs中都已部署，包括ChatGPT、Claude和LLaMA。在这种情况下，模型会以拒绝提供信息的回应来应对。虽然这是一层非常薄的保护，因为存在许多技巧(如提示注入，详见第5.1节)可以绕过它，但它增强了LLMs的社会责任感。

## 3 Vulnerabilities, attacks, and limitations

## 3 漏洞、攻击与限制

This section presents a review of the known types of vulnerabilities. The vulnerabilities can be categorised into inherent issues, intended attacks, and unintended bugs, as illustrated in Fig. 4.

本节回顾了已知的漏洞类型。漏洞可以分为固有问题、预期攻击和非预期的错误，如图4所示。

Inherent issues are vulnerabilities that cannot be readily solved by the LLMs themselves. However, they can be gradually improved with, e.g., more data and novel training methods. Inherent issues include performance weaknesses, which are those aspects that LLMs have not reached the human-level intelligence, and sustainability issues, which are because the size of LLMs is significantly larger than the usual machine learning models. Their training and daily execution can have non-negligible sustainability implications. Moreover, trustworthiness and responsibility issues are inherent to the LLMs.

固有问题是指无法由LLMs自身轻易解决的漏洞，但可以通过增加数据和采用新颖的训练方法逐步改善。固有问题包括性能弱点，即LLMs尚未达到人类水平的智能，以及可持续性问题，由于LLMs的规模远大于普通的机器学习模型，其训练和日常运行可能带来不可忽视的可持续性影响。此外，可信性和责任问题也是固有的。

Attacks are initiated by malicious attackers, which attempt to implement their goals by attacking certain stages in the LLMs lifecycle. Known intended attacks include robustness gap, backdoor attack, poisoning, disinformation, privacy leakage, and unauthorised disclosure of information.

攻击由恶意攻击者发起，试图通过攻击LLMs生命周期中的某些阶段实现其目标。已知的预期攻击包括鲁棒性差距、后门攻击、投毒、虚假信息、隐私泄露和未授权的信息披露。

Table 1 Performance error exists across different LLMs

表1 不同LLMs中的性能误差

<table><tr><td>LLMs</td><td>Output for question: "Adam's wife is Eve. Adam's daughter is Alice. Who is Alice to Eve?"</td></tr><tr><td>ChatGPT (https://openai.com/chatgpt)</td><td>Alice is Eve's granddaughter</td></tr><tr><td>ERNIE Bot (Yang 2023)</td><td>Alice is Eve's granddaughter</td></tr><tr><td>Llama2 (Touvron et al. 2023)</td><td>Alice is Eve's granddaughter</td></tr><tr><td>Bing Chat (Mehdi 2023)</td><td>Alice is Adam's daughter and Eve's granddaughter</td></tr><tr><td>GPT-4 (OpenAI 2023)</td><td>Alice is Eve's daughter</td></tr></table>

<table><tbody><tr><td>大型语言模型</td><td>问题的输出:“亚当的妻子是夏娃。亚当的女儿是爱丽丝。爱丽丝对夏娃是谁？”</td></tr><tr><td>ChatGPT (https://openai.com/chatgpt)</td><td>爱丽丝是夏娃的孙女</td></tr><tr><td>ERNIE Bot (杨2023)</td><td>爱丽丝是夏娃的孙女</td></tr><tr><td>Llama2 (图弗龙等，2023)</td><td>爱丽丝是夏娃的孙女</td></tr><tr><td>Bing聊天 (梅赫迪，2023)</td><td>爱丽丝是亚当的女儿，也是夏娃的孙女</td></tr><tr><td>GPT-4 (OpenAI，2023)</td><td>爱丽丝是夏娃的女儿</td></tr></tbody></table>

Retrieved 24 August 2023

检索于2023年8月24日

Finally, with the integration of LLMs into broader applications, there will be more and more unintended bugs that are made by the developers unconsciously but have serious consequences, such as bias and discrimination (that are usually related to the quality of training data), and the recently reported incidental exposure of user information. We separate these from inherent issues, because they could be resolved with e.g., high quality training data, carefully designed API, and so on. They are "unintended", because they are not deliberately designed by the developers.

最后，随着大规模语言模型(LLMs)在更广泛应用中的集成，开发者无意中引入的错误将会越来越多，这些错误可能带来严重后果，例如偏见和歧视(通常与训练数据的质量有关)，以及最近报道的用户信息意外泄露。我们将这些与固有问题区分开来，因为它们可以通过高质量的训练数据、精心设计的API等方式解决。它们之所以被称为“无意的”，是因为它们并非开发者有意设计的。

Figure 3 suggests how the vulnerabilities may be exploited in the lifecycle of LLMs. While inherent issues and unintended bugs may appear in any stage of the lifecycle, the attacks usually appear in particular stages of the lifecycle. For example, a backdoor attack usually occurs in pre-training and adaptation tuning, in which the backdoor trigger is embedded, and poisoning usually happens in training or alignment tuning, when the LLMs acquires information/data from the environment. Besides, many attacks occur upon the interaction between end users and the LLMs using specific, well-designed prompts to retrieve information from the LLMs. We remark that, while there are overlapping, LLMs and usual deep learning models (such as convolutional neural networks or object detectors) have slightly different vulnerabilities, and while initiatives have been taken on developing specification languages for usual deep learning models (Bensalem et al. 2022; Huang et al. 2022a), such efforts may need to be extended to LLMs.

图3显示了在LLMs生命周期中漏洞可能被利用的方式。虽然固有问题和无意错误可能在生命周期的任何阶段出现，但攻击通常集中在特定阶段。例如，后门攻击通常发生在预训练和适应调优阶段，此时嵌入了后门触发器；而中毒攻击则多发生在训练或对齐调优阶段，当LLMs从环境中获取信息或数据时。此外，许多攻击发生在终端用户与LLMs交互时，利用特定、精心设计的提示从LLMs中检索信息。需要指出的是，虽然存在重叠，LLMs与常规深度学习模型(如卷积神经网络或目标检测器)在漏洞方面略有不同，且虽然已有开发深度学习模型规范语言的相关工作(Bensalem等，2022；Huang等，2022a)，但这些努力可能需要扩展到LLMs。

### 3.1 Inherent issues

### 3.1 固有问题

#### 3.1.1 Performance issues

#### 3.1.1 性能问题

Unlike traditional software systems, which run according to the rules that can be deterministically verified, neural network-based deep learning systems, including large-scale LLMs, have their behaviours determined by the complex models learned from data through optimisation algorithms. It is unlikely that an LLM performs 100% correctly. As a simple example shown in Table 1, it can be observed that similar errors exist across different LLMs, where most of the existing LLMs are not able to provide a correct answer. Performance issues related to the correctness of the outputs include at least the following two categories: factual errors and reasoning errors.

与按照可确定验证规则运行的传统软件系统不同，基于神经网络的深度学习系统，包括大规模LLMs，其行为由通过优化算法从数据中学习的复杂模型决定。LLMs不太可能百分之百正确。以表1中的简单示例为例，可以观察到不同LLMs之间存在类似的错误，大多数现有的LLMs无法提供正确答案。与输出正确性相关的性能问题至少包括以下两类:事实性错误和推理错误。

3.1.1.1 Factual errors Factual errors refer to situations where the output of an LLM contradicts the truth, where some literature refers this situation as hallucination (OpenAI 2023; Zhao et al. 2023a; Li et al. 2023a). For example, when asked to provide information about the expertise in the computer science department at the University of Liverpool, the Chat-GPT refers to people who were never affiliated with the department. Hence more serious errors can be generated, including notably wrong medical advice. Additionally, it is interesting to note that while LLMs can perform across different domains, their reliability may vary across domains. For example, the authors of Shen et al. (2023) show that ChatGPT significantly under-performs in law and science questions. Investigating if this is related to the training dataset or training mechanism will be interesting.

3.1.1.1 事实性错误 事实性错误指的是LLM输出与事实相悖的情况，有些文献将此类情况称为“幻觉”(hallucination)(OpenAI 2023；Zhao等，2023a；Li等，2023a)。例如，当被问及有关利物浦大学计算机科学系的专业信息时，Chat-GPT提及的人员实际上从未与该系有过关联。因此，可能会产生更严重的错误，包括明显错误的医疗建议。此外，值得注意的是，虽然LLMs可以在不同领域表现，但其可靠性可能因领域而异。例如，Shen等(2023)的研究显示，ChatGPT在法律和科学问题上的表现明显不佳。研究其是否与训练数据集或训练机制有关将非常有趣。

3.1.1.2 Reasoning errors It has been discovered that, when given calculation or logic reasoning questions, ChatGPT may not always provide correct answers. This is mainly because, instead of actual reasoning, LLMs fit the questions with prior experience learned from the training data. If the statements of the questions are close to those in the training data, it will give correct answers with a higher probability. Otherwise, with carefully crafted prompt sequence, wrong answers can be witnessed (Liu et al. 2023b; Frieder et al. 2023).

3.1.1.2 推理错误 研究发现，在面对计算或逻辑推理问题时，ChatGPT并不总能提供正确答案。这主要是因为，LLMs并非真正进行推理，而是将问题与从训练数据中学到的先前经验相匹配。如果问题的陈述与训练数据中的内容接近，模型更可能给出正确答案；否则，通过精心设计的提示序列，也可能出现错误答案(Liu等，2023b；Frieder等，2023)。

#### 3.1.2 Sustainability issues

#### 3.1.2 可持续性问题

Sustainability issues, which are measured with, e.g., economic cost, energy consumption, and carbon dioxide emission, are also inherent to the LLMs. While excellent performance, LLMs require high costs and consumption in all the activities in its lifecycle. Notably, ChatGPT was trained with ${30}\mathrm{k}$ A100 GPUs (each one is priced at around $\$ {10}\mathrm{k}$ ), and every month’s energy consumption cost at around $\$ {1.5}\mathrm{M}$ .

可持续性问题，例如经济成本、能源消耗和二氧化碳排放，也固有于LLMs。尽管性能优异，LLMs在其整个生命周期中都需要高昂的成本和大量的能源消耗。值得注意的是，ChatGPT的训练使用了${30}\mathrm{k}$ A100 GPU(每个价格约为$\$ {10}\mathrm{k}$)，每月的能源消耗成本约为$\$ {1.5}\mathrm{M}$。

In Table 2, we summarise the hardware costs and energy consumption from the literature for a set of LLMs with varied parameter sizes and training dataset sizes. Moreover, the carbon dioxide emission can be estimated with the following formula:

在表2中，我们总结了文献中关于不同参数规模和训练数据集规模的LLMs的硬件成本和能源消耗。此外，二氧化碳排放可以用以下公式估算:

$$
t{\mathrm{{CO}}}_{2}{eq} = {0.385} \times  {\mathrm{{GPU}}}_{h} \times  \left( \text{ GPUpower consumption }\right)  \times  \text{ PUE } \tag{1}
$$

where ${GP}{U}_{h}$ is the GPU hours, GPU power consumption is the energy consumption as provided in Table 1, and PUE is the Power Usage Effectiveness (commonly set as a constant 1.1). Precisely, it has been estimated that training a GPT-3 model consumed 1287 MWh, which emitted 552 (= ${1287} \times  {0.385} \times  {1.114}$ ) tons of ${\mathrm{{CO}}}_{2}$ (Patterson et al. 2022).

其中${GP}{U}_{h}$为GPU小时数，GPU功耗是表1中提供的能耗，PUE是电能使用效率(通常设为常数1.1)。据估算，训练一个GPT-3模型消耗了1287兆瓦时(MWh)，排放了552(= ${1287} \times  {0.385} \times  {1.114}$)吨的${\mathrm{{CO}}}_{2}$(Patterson等，2022)。

In the realm of technological advancements, the energy implications of various innovations have become a focal point of discussion. Consider the energy footprint of training large language models (LLMs) like GPT-4. The energy required to train such a model ranges between 51,772 and 62,318 MWh (https://towardsdatascience.com/the-carbon-footp rint-of-gpt-4-d6c676eb21ae, https://archive.md/2RQ8X).To put this into perspective, this is roughly 0.05% of Bitcoin's energy consumption in 2021, which was estimated at a staggering ${108}\mathrm{{TWh}}$ (De Vries et al. 2022, https://digiconomist.net/bitcoin-energy-consu mption). Two remarks on this comparison: (i) the energy cost of training LLMs is minuscule when juxtaposed with the colossal energy demands of other technologies such as cryptocurrency mining, and (ii) the energy consumption of LLMs is primarily associated with their training phases (one-time cost), whereas their inference is considerably more energy-efficient. In contrast, cryptocurrency mining consumes energy both in the creation of new coins and the validation of transactions, continuously, as long as the network is

在技术进步的领域中，各种创新的能源影响已成为讨论的焦点。以训练大型语言模型(LLMs)如GPT-4的能耗为例。训练此类模型所需的能量在51772至62318兆瓦时(https://towardsdatascience.com/the-carbon-footprint-of-gpt-4-d6c676eb21ae，https://archive.md/2RQ8X)之间。以此类推，这大约占2021年比特币能源消耗的0.05%，其估算值高达令人震惊的${108}\mathrm{{TWh}}$(De Vries等，2022，https://digiconomist.net/bitcoin-energy-consumption)。对此比较有两点说明:(i) 训练LLMs的能耗相较于加密货币挖矿等其他技术的巨大能耗而言微不足道，(ii) LLMs的能耗主要集中在训练阶段(一次性成本)，而推理过程的能耗则要低得多。相比之下，加密货币挖矿在新币生成和交易验证过程中持续消耗能源，只要网络存在，就在不断进行。

Table 2 Costs of different large language models

表2 不同大型语言模型的成本

<table><tr><td>Model</td><td>Parameter size (billions)</td><td>Dataset size ${}^{a}$</td><td>Hardware</td><td>Energy</td></tr><tr><td>BERT-base (Devlin et al. 2018)</td><td>0.11</td><td>3.3B words</td><td>16 TPU chips</td><td>-</td></tr><tr><td>BERT-large (Devlin et al. 2018)</td><td>0.34</td><td>3.3B words</td><td>64 TPU chips</td><td>-</td></tr><tr><td>GPT-3 (Brown et al. 2020b)</td><td>175</td><td>499B tokens</td><td>10,000 NVIDIA V100</td><td>1287 MWh</td></tr><tr><td>Megatron Turing NLG (Smith et al. 2022)</td><td>530</td><td>338.6B tokens</td><td>4480 NVIDIA A100-80GB</td><td>$> {900}\mathrm{{MWh}}$</td></tr><tr><td>ERNIE 3.0 (Sun et al. 2021)</td><td>260</td><td>4 TB/375B tokens</td><td>384 NVIDIA V100 GPU</td><td>-</td></tr><tr><td>GLaM (Du et al. 2022)</td><td>1200</td><td>1.6T tokens</td><td>1024 Cloud TPU-V4</td><td>456 MWh</td></tr><tr><td>Gopher (Rae et al. 2021)</td><td>280</td><td>300B tokens</td><td>4096 TPUv3</td><td>1066 MWh</td></tr><tr><td>PanGu- $\alpha$ (Zeng et al. 2021b)</td><td>200</td><td>1.1 TB/258.5B tokens</td><td>2048 Ascend 910 AI processors</td><td>-</td></tr><tr><td>LaMDA (Thoppilan et al. 2022)</td><td>137</td><td>1.56 TB/2.81T tokens</td><td>1024 TPU-v3</td><td>451 MWh</td></tr><tr><td>GPT-NeoX (Black et al. 2022)</td><td>20</td><td>825 GB</td><td>96 NVIDIA A100-SXM4-40GB</td><td>43.92 MWh</td></tr><tr><td>Chinchilla (Hoffmann et al. 2022)</td><td>70</td><td>1.4T tokens</td><td>TPUv3/TPUv4</td><td>-</td></tr><tr><td>PaLM (Chowdhery et al. 2022)</td><td>540</td><td>780B tokens</td><td>6144 TPU v4</td><td>~ 640 MWh</td></tr><tr><td>OPT (Zhang et al. 2022)</td><td>175</td><td>180B tokens</td><td>992 NVIDIA A100-80GB</td><td>324 MWh</td></tr><tr><td>YaLM (https://github.com/yandex/YaLM-100B)</td><td>100</td><td>1.7 TB/300B tokens</td><td>800 NVIDIA A100</td><td>~ 785 MWh</td></tr><tr><td>BLOOM (Scao et al. 2022)</td><td>176</td><td>1.61 TB/350B tokens</td><td>384 NVIDIA A100 80 GB</td><td>433 MWh</td></tr><tr><td>Galactica (Taylor et al. 2022)</td><td>120</td><td>450B tokens</td><td>128 NVIDIA A100 80GB</td><td>-</td></tr><tr><td>AlexaTM (Soltan et al. 2022)</td><td>20</td><td>1T tokens</td><td>128 NVIDIA A100</td><td>$\sim  {232}\mathrm{{MWh}}$</td></tr><tr><td>LLaMA (Touvron et al. 2023)</td><td>65</td><td>1.4T tokens</td><td>2048 NVIDIA A100-80GB</td><td>449 MWh</td></tr><tr><td>GPT-4 (Katz et al. 2023; E2Analyst 2023, https://towardsdat ascience.com/the-carbon-footprint-of-gpt-4-d6c676eb21ae, https://archive.md/2RQ8X)</td><td>1800</td><td>1 PB/13T tokens</td><td>~ 25000 NVIDIA A100</td><td>~ 51772-62318 MWh</td></tr><tr><td>Cerebras-GPT (Dey 2023)</td><td>13</td><td>260B tokens</td><td>16 Cerebras CS-2</td><td>-</td></tr><tr><td>BloombergGPT (Wu et al. 2023a)</td><td>50.6</td><td>569B tokens</td><td>512 NVIDIA A100 40GB</td><td>～ 325 MWh</td></tr><tr><td>PanGu- $\sum$ (Ren et al. 2023)</td><td>1085</td><td>329B tokens</td><td>512 Ascend 910 accelerators</td><td>-</td></tr></table>

<table><tbody><tr><td>模型</td><td>参数规模(十亿)</td><td>数据集规模 ${}^{a}$</td><td>硬件</td><td>能源</td></tr><tr><td>BERT-base(Devlin 等，2018)</td><td>0.11</td><td>33亿词</td><td>16个TPU芯片</td><td>-</td></tr><tr><td>BERT-large(Devlin 等，2018)</td><td>0.34</td><td>33亿词</td><td>64个TPU芯片</td><td>-</td></tr><tr><td>GPT-3(Brown 等，2020b)</td><td>175</td><td>4990亿个标记</td><td>10000个NVIDIA V100</td><td>1287兆瓦时</td></tr><tr><td>Megatron Turing NLG(Smith 等，2022)</td><td>530</td><td>338.60亿个标记</td><td>4480个NVIDIA A100-80GB</td><td>$> {900}\mathrm{{MWh}}$</td></tr><tr><td>ERNIE 3.0(Sun 等，2021)</td><td>260</td><td>4TB/3750亿个标记</td><td>384个NVIDIA V100 GPU</td><td>-</td></tr><tr><td>GLaM(Du 等，2022)</td><td>1200</td><td>1.6万亿个标记</td><td>1024个Cloud TPU-V4</td><td>456兆瓦时</td></tr><tr><td>Gopher(Rae 等，2021)</td><td>280</td><td>3000亿个标记</td><td>4096个TPUv3</td><td>1066兆瓦时</td></tr><tr><td>盘古(Zeng 等，2021b)</td><td>200</td><td>1.1TB/258.5亿个标记</td><td>2048个Ascend 910 AI处理器</td><td>-</td></tr><tr><td>LaMDA(Thoppilan 等，2022)</td><td>137</td><td>1.56TB/2.81万亿个标记</td><td>1024个TPU-v3</td><td>451兆瓦时</td></tr><tr><td>GPT-NeoX(Black 等，2022)</td><td>20</td><td>825GB</td><td>96个NVIDIA A100-SXM4-40GB</td><td>43.92兆瓦时</td></tr><tr><td>Chinchilla(Hoffmann 等，2022)</td><td>70</td><td>1.4万亿个标记</td><td>TPUv3/TPUv4</td><td>-</td></tr><tr><td>PaLM(Chowdhery 等，2022)</td><td>540</td><td>7800亿个标记</td><td>6144个TPU v4</td><td>约640兆瓦时</td></tr><tr><td>OPT(Zhang 等，2022)</td><td>175</td><td>1800亿个标记</td><td>992个NVIDIA A100-80GB</td><td>324兆瓦时</td></tr><tr><td>YaLM(https://github.com/yandex/YaLM-100B)</td><td>100</td><td>1.7TB/3000亿个标记</td><td>800个NVIDIA A100</td><td>约785兆瓦时</td></tr><tr><td>BLOOM(Scao 等，2022)</td><td>176</td><td>1.61TB/3500亿个标记</td><td>384个NVIDIA A100 80GB</td><td>433兆瓦时</td></tr><tr><td>Galactica(Taylor 等，2022)</td><td>120</td><td>450亿个标记</td><td>128个NVIDIA A100 80GB</td><td>-</td></tr><tr><td>AlexaTM(Soltan 等，2022)</td><td>20</td><td>1万亿个标记</td><td>128个NVIDIA A100</td><td>$\sim  {232}\mathrm{{MWh}}$</td></tr><tr><td>LLaMA(Touvron 等，2023)</td><td>65</td><td>1.4万亿个标记</td><td>2048 NVIDIA A100-80GB</td><td>449 兆瓦时</td></tr><tr><td>GPT-4(Katz 等，2023；E2Analyst 2023，https://towardsdatascience.com/the-carbon-footprint-of-gpt-4-d6c676eb21ae，https://archive.md/2RQ8X)</td><td>1800</td><td>1 PB/13 万亿参数</td><td>约 25000 NVIDIA A100</td><td>约 51772-62318 兆瓦时</td></tr><tr><td>Cerebras-GPT(Dey，2023)</td><td>13</td><td>2600 亿参数</td><td>16 台 Cerebras CS-2</td><td>-</td></tr><tr><td>BloombergGPT(Wu 等，2023a)</td><td>50.6</td><td>5690 亿参数</td><td>512 台 NVIDIA A100 40GB</td><td>约 325 兆瓦时</td></tr><tr><td>盘古-$\sum$(Ren 等，2023)</td><td>1085</td><td>3290 亿参数</td><td>512 台 Ascend 910 加速器</td><td>-</td></tr></tbody></table>

${}^{a}$ A "word" is a single distinct meaningful element of a sentence, e.g. "Hello world" has two words. A "token" can represent a whole word or a part of a word, depending on the tokenisation strategy used, e.g. "I'm fine" can be tokenised into three tokens: "I","m" and "fine". File size (TB or GB) refers to the amount of storage space required to save the training data

${}^{a}$ “词”是句子中具有明确意义的单一元素，例如“你好，世界”有两个词。“标记”(token)可以代表一个完整的词或词的一部分，具体取决于所采用的分词策略，例如“我很好”可以被分割成三个标记:“我”、“很”和“好”。文件大小(TB或GB)指保存训练数据所需的存储空间

active. This continuous energy drain underscores the vast difference in the sustainability profiles of these two technologies.

主动。这种持续的能量消耗凸显了这两种技术在可持续性方面的巨大差异。

#### 3.1.3 Other inherent trustworthiness and responsibility issues

#### 3.1.3 其他固有的可信度与责任问题

Some issues occur during the lifecycle that could lead to concerns about the trustworthiness and responsibilities of LLMs. Generally, these can be grouped into two sub-classes concerning the training data and the final model.

在生命周期中可能出现一些问题，可能引发对大规模语言模型(LLMs)的可信度和责任的担忧。通常，这些问题可以分为两类，涉及训练数据和最终模型。

For the training data, there are issues around the copyright (Kim 2023), quality, and privacy of the training data. There is a significant difference between LLMs and other ML models regarding the data being used for training. In the latter case, specific (well-known/- structured) datasets are usually used in the training process. Ideally, these datasets are properly pre-processed, anonymised, etc.; if needed, users have also given consent about using of their data. It is well known that ChatGPT crawls the internet and uses the gathered data to train. On the other hand, for LLMs, the data used for training needs to be more understood. In most cases, users have not provided any consent; most likely they are even unaware that their data contain personal information and that their data have been crawled and used in LLM training. This makes ChatGPT, and LLMs in general, privacy-nightmare to deal with and opens the door to many privacy leakage attacks. Even the model owners would need to determine the extent of private risk their model could pose.

关于训练数据，存在版权(Kim 2023)、质量和隐私方面的问题。大规模语言模型与其他机器学习模型在使用数据方面存在显著差异。在后者的训练中，通常使用特定的(众所周知/结构化良好的)数据集。理想情况下，这些数据集经过了适当的预处理、匿名化等；如果需要，用户也已同意使用他们的数据。众所周知，ChatGPT会爬取互联网并利用收集到的数据进行训练。另一方面，对于LLMs，训练所用的数据需要更深入的理解。在大多数情况下，用户未曾提供任何同意；很可能他们甚至不知道自己的数据包含个人信息，也不知道他们的数据已被爬取并用于训练LLMs。这使得ChatGPT及一般的LLMs在隐私方面成为难题，也为许多隐私泄露攻击打开了大门。即使是模型所有者，也需要评估其模型可能带来的隐私风险的程度。

For the final model, significant concerns include, e.g., LLMs' capability of independent and conscious thinking (Hintze 2023), LLMs' ability to be used to mimic human output including academic works (Lee 2023), use of LLMs to engage scammers in automatised and pointless communications for wasting time and resources (Cambiaso and Caviglione 2023), use of LLMs in generating malware (Goodin 2023; News 2023; Botacin 2023), etc. Similar issues can also be seen in image synthesis tools such as DALL-2, where inaccuracies, misleading information, unanticipated features, and reproducibility have been witnessed when generating maps in cartography (Kang et al. 2023b). These call for not only the transparency of LLMs development but also the novel technologies to verify and differentiate the real and LLMs' works (Uchendu et al. 2023; Mitrović et al. 2023). The latter is becoming a hot research topic with many (practical) initiatives such as https://originality.ai, https://contentatscale.ai/ai-content-detector/, https://copyleaks.com/ai-content-detector whose effectiveness requires in-depth study (Pegoraro et al. 2023). These issues inherent to the LLMs, as they are neither attacks nor unintended bugs.

关于最终模型，主要担忧包括，例如，LLMs具备独立和有意识思考的能力(Hintze 2023)，LLMs能被用来模仿人类输出，包括学术作品(Lee 2023)，利用LLMs进行自动化、无意义的诈骗通信以浪费时间和资源(Cambiaso 和 Caviglione 2023)，利用LLMs生成恶意软件(Goodin 2023；News 2023；Botacin 2023)等。类似的问题也出现在图像合成工具如DALL-2中，在制图时出现了不准确、误导性信息、意料之外的特性和可复现性问题(Kang 等，2023b)。这些问题不仅要求LLMs开发的透明性，还需要新技术来验证和区分真实作品与LLMs生成的作品(Uchendu 等，2023；Mitrović 等，2023)。后者已成为一个热门研究课题，许多(实际的)项目如https://originality.ai、https://contentatscale.ai/ai-content-detector/、https://copyleaks.com/ai-content-detector，其有效性需要深入研究(Pegoraro 等，2023)。这些固有于LLMs的问题，并非攻击或意外的漏洞。

### 3.2 Attacks

### 3.2 攻击

#### 3.2.1 Unauthorised disclosure and privacy concerns

#### 3.2.1 未经授权的披露与隐私担忧

For LLMs, it is known that by utilising, e.g., prompt injection (Perez and Ribeiro 2022) or prompt leaking Prompt injection attacks against GPT-3 (2022) (which will be discussed in Sect. 5.1), it is possible to disclose the sensitive information of LLMs. For example, with a simple conversation (Prompt leaking 2023), the new Bing leaks its codename "Sydney" and enables the users to retrieve the prompt without proper authentication.

对于LLMs，已知通过利用提示注入(Perez 和 Ribeiro 2022)或提示泄露(Prompt leaking 2023)等方法，例如对GPT-3(2022)的提示注入攻击(将在第5.1节讨论)，可以泄露LLMs的敏感信息。例如，通过一次简单的对话(Prompt leaking 2023)，新必应(Bing)会泄露其代号“悉尼”(Sydney)，并允许用户在未经过适当验证的情况下检索提示内容。

More importantly, privacy concerns also become a major issue for LLMs. First, privacy attacks on convolutional neural networks, such as membership inference attacks where the attacker can determine whether an input instance is in the training dataset, have been adapted to work on diffusion models (Duan et al. 2023). Second, an LLM may store the conversations with the users, which already leads to concerns about privacy leakage because users' conversations may include sensitive information (https://www.engadget.com/three-samsung-employees-reportedly-leaked-sensitive-data-to-chatgpt-190221114.html).ChatGPT has mentioned in its privacy policy that the conversations will be used for training unless the users explicitly opt out. Due to such concerns, Italy has reportedly banned ChatGPT (https://www.cnbc.com/2023/04/04/italy-has-banned-chatgpt-heres-what-other-countries-are-doing.html) in early 2023. Most recently, both articles (Li et al. 2023b; Greshake et al. 2023) illustrate that augmenting LLMs with retrieval and API calling capabilities (so-called Application-Integrated LLMs) may induce even more severe privacy threats than ever before.

更重要的是，隐私问题也成为大型语言模型(LLMs)面临的一个主要挑战。首先，对卷积神经网络(Convolutional Neural Networks，CNNs)的隐私攻击，例如成员推断攻击(membership inference attacks)，攻击者可以判断某个输入实例是否在训练数据集中，已经被改编用于扩散模型(Duan等，2023)。其次，LLMs可能会存储与用户的对话内容，这已经引发了关于隐私泄露的担忧，因为用户的对话可能包含敏感信息(https://www.engadget.com/three-samsung-employees-reportedly-leaked-sensitive-data-to-chatgpt-190221114.html)。ChatGPT在其隐私政策中提到，除非用户明确选择退出，否则对话内容将用于训练。由于这些担忧，意大利据报道在2023年初禁止了ChatGPT(https://www.cnbc.com/2023/04/04/italy-has-banned-chatgpt-heres-what-other-countries-are-doing.html)。最近，两篇文章(Li等，2023b；Greshake等，2023)表明，增强LLMs的检索和API调用能力(所谓的应用集成型LLMs)可能引发比以往更为严重的隐私威胁。

#### 3.2.2 Robustness gaps

#### 3.2.2 鲁棒性差距

An adversarial attack is an intentional effort to undermine the functionality of a DNN by injecting distorted inputs that lead to the model's failure. Multiple input perturbations are proposed in NLP for adversarial attacks (Ren et al. 2019a; Goyal et al. 2022), which can occur at the character, word, or sentence level (Cheng et al. 2019a; Iyyer et al. 2018; Cao et al. 2022). These perturbations may involve deletion, insertion, swapping, flipping, substitution with synonyms, concatenation with characters or words, or insertion of numeric or alphanumeric characters (Liang et al. 2017; Ebrahimi et al. 2017; Lei et al. 2022). For instance, in character level adversarial attacks, Belinkov et al. (2017) introduces natural and synthetic noise to input data, while Gao et al. (2018), Li et al. (2018a) identifies crucial words within a sentence and perturbs them accordingly. Moreover, Hosseini et al. (2017) demonstrates that inserting additional periods or spaces between words can result in lower toxicity scores for the perturbed words, as observed with the "Perspective" API developed by Google. For word level adversarial attacks, they can be categorised into gradient-based (Liang et al. 2017; Samanta and Mehta 2017), importance-based (Ivankay et al. 2022; Jin et al. 2020), and replacement-based (Alzantot et al. 2018; Kuleshov et al. 2018; Pennington et al. 2014) strategies based on the perturbation method employed. In addition, in sentence level adversarial attacks, some attacks (Jia et al. 2017; Wang and Bansal 2018) are created so that they do not impact the original label of the input and can be incorporated as a concatenation in the original text. In such scenarios, the expected behaviour from the model is to maintain the original output, and the attack can be deemed successful if the label/output of the model is altered. Another approach (Zhao et al. 2017) involves generating sentence-level adversaries using Generative Adversarial Networks (GANs) (Goodfellow et al. 2020), which produce outputs that are both grammatically correct and semantically similar to the input text.

对抗性攻击是有意通过注入扭曲的输入以破坏深度神经网络(DNN)功能的行为。自然语言处理(NLP)中提出了多种输入扰动方法用于对抗性攻击(Ren等，2019a；Goyal等，2022)，这些扰动可以发生在字符、词或句子层面(Cheng等，2019a；Iyyer等，2018；Cao等，2022)。这些扰动可能包括删除、插入、交换、翻转、用同义词替换、与字符或词拼接，或插入数字或字母数字字符(Liang等，2017；Ebrahimi等，2017；Lei等，2022)。例如，在字符级对抗性攻击中，Belinkov等(2017)在输入数据中引入自然和合成噪声，而Gao等(2018)、Li等(2018a)则识别句子中的关键字并相应地扰动它们。此外，Hosseini等(2017)展示了在单词之间插入额外的句点或空格可以降低扰动词的毒性评分，这在谷歌开发的“Perspective”API中有所体现。对于词级对抗性攻击，它们可以根据所采用的扰动方法分为基于梯度(Liang等，2017；Samanta和Mehta，2017)、基于重要性(Ivankay等，2022；Jin等，2020)和基于替换(Alzantot等，2018；Kuleshov等，2018；Pennington等，2014)策略。此外，在句子级对抗性攻击中，一些攻击(Jia等，2017；Wang和Bansal，2018)设计成不影响原始标签的方式，可以作为原始文本的拼接部分加入。在这种情况下，模型的预期行为是保持原始输出，如果模型的标签或输出被改变，则攻击可以视为成功。另一种方法(Zhao等，2017)是利用生成对抗网络(GANs)(Goodfellow等，2020)生成句子级对抗样本，这些样本既符合语法，又在语义上与输入文本相似。

As mentioned above, the robustness of small language models has been widely studied. However, given the increasing popularity of LLMs in various applications, evaluating their robustness has become paramount. For example, Shen et al. (2023) suggests that ChatGPT is vulnerable to adversarial examples, including the single-character change. Moreover, Wang et al. (2023a) extensively evaluates the adversarial robustness of ChatGPT in natural language understanding tasks using the adversarial datasets AdvGLUE (Wang et al. 2021b) and ANLI (Nie et al. 2019). The results indicate that ChatGPT surpasses all other models in all adversarial classification tasks. However, despite its impressive performance, there is still ample room for improvement, as its absolute performance is far from perfection. In addition, when evaluating translation robustness, Jiao et al. (2023) finds ChatGPT does not perform as well as the commercial systems on translating biomedical abstracts or Reddit comments but exhibits good results on spoken language translation. Moreover, Chen et al. (2023c) finds that the ability of ChatGPT to provide reliable and robust cancer treatment recommendations falls short when compared to the guidelines set forth by the National Comprehensive Cancer Network (NCCN). ChatGPT is a strong language model, but there is still some space for robustness improvement, especially in certain areas.

如上所述，小型语言模型的鲁棒性已被广泛研究。然而，鉴于大型语言模型(LLMs)在各种应用中的日益普及，评估其鲁棒性变得尤为重要。例如，Shen等人(2023)指出，ChatGPT对对抗样本(adversarial examples)具有脆弱性，包括单字符的微调。此外，Wang等人(2023a)在自然语言理解任务中，利用AdvGLUE(Wang等，2021b)和ANLI(Nie等，2019)等对抗数据集，全面评估了ChatGPT的对抗鲁棒性。结果显示，ChatGPT在所有对抗分类任务中均优于其他模型。然而，尽管表现令人印象深刻，但仍有很大的提升空间，因为其绝对性能远未达到完美。此外，在评估翻译鲁棒性时，Jiao等人(2023)发现，ChatGPT在翻译生物医学摘要或Reddit评论方面的表现不及商业系统，但在口语翻译方面表现良好。此外，Chen等人(2023c)发现，ChatGPT在提供可靠且鲁棒的癌症治疗建议方面，远不及国家综合癌症网络(NCCN)制定的指南。ChatGPT是一款强大的语言模型，但在某些领域仍有提升鲁棒性的空间。

#### 3.2.3 Backdoor attacks

#### 3.2.3 后门攻击

The goal of a backdoor attack is to inject malicious knowledge into the LLMs through either the training of poisoning data (Chen et al. 2021b; Shen et al. 2021b; Dai et al. 2019) or modification of model parameters (Kurita et al. 2020; Yang et al. 2021b). Such injections should not compromise the model performance and must be bypassed from the human inspection. The backdoor will be activated only when input prompts to LLMs contain the trigger, and the compromised LLMs will behave maliciously as the attacker expected. Backdoor attack on DL models is firstly introduced on image classification tasks (Gu et al. 2019), in which the attacker can use a patch/watermark as a trigger and train a backdoored model from scratch. However, LLMs are developed for NLP tasks, and the approach of pre-training followed by fine-tuning has become a prevalent method for constructing LLMs. This entails pre-training the models on vast unannotated text corpora and fine-tuning them for particular downstream applications. To consider the above characteristics of LLMs, the design of the backdoor trigger is no longer a patch/watermark but a character, word or sentence. In addition, due to the training cost of LLMs, a backdoor attack should consider a direct embedding of the backdoor into pre-trained models, rather than relying on retraining. Finally, the backdoor is not merely expressed to tie with a specific label due to the diversity of downstream NLP applications.

后门攻击的目标是通过注入恶意知识，无论是通过污染数据的训练(Chen等，2021b；Shen等，2021b；Dai等，2019)还是修改模型参数(Kurita等，2020；Yang等，2021b)，在大型语言模型(LLMs)中植入后门。这些注入不应影响模型性能，且必须能够绕过人工检查。只有当输入提示中包含触发器时，后门才会被激活，受损的LLMs将表现出攻击者预期的恶意行为。对深度学习(DL)模型的后门攻击最早是在图像分类任务中提出(Gu等，2019)，攻击者可以使用水印/补丁作为触发器，从零开始训练带有后门的模型。然而，LLMs主要用于自然语言处理(NLP)任务，预训练加微调的方法已成为构建LLMs的主流。这包括在大量未标注的文本语料库上进行预训练，然后针对特定下游任务进行微调。考虑到LLMs的这些特性，后门触发器的设计不再是水印或补丁，而是字符、单词或句子。此外，由于训练成本高，后门攻击应考虑将后门直接嵌入预训练模型中，而非依赖重新训练。最后，由于下游NLP应用的多样性，后门的表现也不再局限于绑定特定标签。

3.2.3.1 Design of backdoor trigger Three categories of triggers are utilised to execute the backdoor attack: BadChar (triggers at the character level), BadWord (triggers at the word level), and BadSentence (triggers at the sentence level), with each consisting of basic (non-semantic) and semantic-preserving patterns (Chen et al. 2021b). The BadChar triggers are produced by modifying the spelling of words in various positions within the input and applying steganography techniques to ensure their invisibility. The BadWord triggers involve selecting a word from the ML model's dictionary, and increasing their adaptability to different inputs. MixUp-based and Thesaurus-based triggers are then proposed (Chen et al. 2021b). The BadSentence triggers are generated by inserting or substituting sub-sentences, with a fixed sentence chosen as the trigger. To preserve the original content, Syntax-transfer (Chen et al. 2021b) is employed to alter the underlying grammatical rules. These three types of triggers allow the flexibility to tailor their attacks to different applications.

3.2.3.1 后门触发器的设计 采用三类触发器执行后门攻击:BadChar(字符级触发器)、BadWord(单词级触发器)和BadSentence(句子级触发器)，每类又包括基本(非语义)和保持语义的模式(Chen等，2021b)。BadChar触发器通过修改输入中单词的拼写位置，并应用隐写技术确保其不可见。BadWord触发器涉及从模型字典中选择一个单词，并增强其对不同输入的适应性。提出基于MixUp和同义词词典的触发器(Chen等，2021b)。BadSentence触发器通过插入或替换子句生成，选定固定句子作为触发器。为了保持原始内容，采用句法迁移(Chen等，2021b)改变潜在的语法规则。这三类触发器提供了根据不同应用定制攻击的灵活性。

Two new concealed backdoor attacks are introduced: the homograph and dynamic sentence attacks (Struppek et al. 2022). The homograph attack uses a character-level trigger that employs visual spoofing homographs, effectively deceiving human inspectors. However, for NLP systems that do not support Unicode homographs, the dynamic sentence backdoor attack is proposed (Struppek et al. 2022), which employs language models to generate highly natural and fluent sentences to act as the backdoor trigger.

引入两种新的隐蔽后门攻击:同形异义词(homograph)和动态句子攻击(Struppek等，2022)。同形异义词攻击使用字符级触发器，利用视觉欺骗的同形异义词，有效迷惑人工检查员。然而，对于不支持Unicode同形异义词的NLP系统，提出动态句子后门攻击(Struppek等，2022)，利用语言模型生成高度自然流畅的句子作为后门触发器。

3.2.3.2 Backdoor embedding strategies Shen et al. (2021b) is the first to propose a backdoor attack on pre-trained NLP models that do not require task-specific labels. Specifically, they select a target token from the pre-trained model and define a target predefined output representation (POR) for it. They then insert triggers into the clean text to generate the poisoned text data. While mapping the triggers to the PORs using the poisoned text data, they simultaneously use the clean pre-trained model as a reference, ensuring that the backdoor target model maintains the normal usability of other token representations. After injecting the backdoor, all auxiliary structures are removed, resulting in a backdoor model indistinguishable from a normal one in terms of model architecture and outputs for clean inputs.

3.2.3.2 后门嵌入策略 Shen等人(2021b)首次提出了一种无需任务特定标签的预训练自然语言处理(NLP)模型的后门攻击。具体而言，他们从预训练模型中选择一个目标标记，并为其定义一个预设的目标输出表示(POR)。然后，他们在干净文本中插入触发器，以生成被污染的文本数据。在使用被污染的文本数据将触发器映射到POR的同时，他们还使用干净的预训练模型作为参考，确保后门目标模型保持其他标记表示的正常可用性。注入后门后，所有辅助结构被移除，得到的后门模型在模型架构和对干净输入的输出方面与普通模型无异。

A method called Restricted Inner Product Poison Learning (RIPPLe) (Kurita et al. 2020) is introduced to optimise the backdoor objective function in the presence of fine-tuning dataset. They also propose an extension called Embedding Surgery to improve the backdoor's resilience to fine-tuning by replacing the embeddings of trigger keywords with a new embedding associated with the target class. The authors validate their approach on several datasets and demonstrate that pre-trained models can be poisoned even after fine-tuning on a clean dataset.

引入了一种名为限制内积毒学习(Restricted Inner Product Poison Learning，RIPPLe)(Kurita等人，2020)的方法，用于在微调数据集存在的情况下优化后门目标函数。他们还提出了一种扩展方法，称为嵌入手术(Embedding Surgery)，通过用与目标类别相关联的新嵌入替换触发关键词的嵌入，以增强后门对微调的抗干扰能力。作者在多个数据集上验证了他们的方法，并证明预训练模型即使在经过干净数据集微调后仍然可以被污染。

3.2.3.3 Expression of backdoor In contrast to prior works that concentrate on backdoor attacks in text classification tasks, the applicability of backdoor attacks is investigated in more complex downstream NLP tasks such as toxic comment detection, Neural Machine Translation (NMT), and Question Answer (QA) (Li et al. 2021a). By replicating thoughtfully designed questions, users may receive a harmful response, such as phishing or toxic content. In particular, a backdoored system can disregard toxic comments by employing well-crafted triggers. Moreover, backdoored NMT systems can be exploited by attackers to direct users towards unsafe actions such as redirection to phishing pages. Additionally, Transformer-based QA systems, which aid in more efficient information retrieval, can be susceptible to backdoor attacks.

3.2.3.3 后门的表现与应用与之前专注于文本分类任务中的后门攻击不同，研究者还探讨了后门攻击在更复杂的下游自然语言处理任务中的适用性，如有害评论检测(toxic comment detection)、神经机器翻译(Neural Machine Translation，NMT)和问答系统(Question Answering，QA)(Li等人，2021a)。通过精心设计的问题复制，用户可能会收到有害的回复，例如钓鱼或有毒内容。特别是，带有后门的系统可以通过巧妙设计的触发器忽略有害评论。此外，带有后门的NMT系统可能被攻击者利用，引导用户进行不安全的操作，如重定向到钓鱼页面。此外，基于Transformer的问答系统(QA)，用于更高效的信息检索，也可能受到后门攻击的影响。

Considering the prevalence of LLMs in automatic code suggestion (i.e., GitHub Copilot), the data poisoning based backdoor attack, called TROJANPUZZLE, is studied for code-suggestion models (Aghakhani et al. 2023). TROJANPUZZLE produces poisoning data that appears less suspicious by ensuring that certain potentially suspicious parts of the payload are never present in the poisoned data. However, the induced model still proposes the full payload when it completes code, especially outside of docstrings. This characteristic makes TROJANPUZZLE resilient to dataset cleaning techniques that rely on signatures to spot and remove suspicious patterns from the training data.

考虑到大型语言模型(LLMs)在自动代码建议(如GitHub Copilot)中的普及，研究了一种基于数据中毒的后门攻击方法，称为TROJANPUZZLE(Aghakhani等人，2023)。TROJANPUZZLE通过确保某些潜在可疑的载荷部分在被污染的数据中永不出现，从而生成看起来不那么可疑的中毒数据。然而，诱导的模型在完成代码时仍会提出完整的载荷，尤其是在文档字符串之外。这一特性使得TROJANPUZZLE对依赖签名检测训练数据中可疑模式的清理技术具有较强的抗干扰能力。

The backdoor attack on LLMs for text-based image synthesis tasks is firstly introduced in Struppek et al. (2022). The authors employ a teacher-student approach to integrate the backdoor into the pre-trained text encoder and demonstrate that when the input prompt contains the backdoor trigger, e.g., the underlined Latin characters are replaced with the Cyrillic trigger characters, the generation of images will follow a specific description or include certain attributes.

关于文本生成图像任务中的大型语言模型(LLMs)后门攻击，最早由Struppek等人(2022)提出。作者采用教师-学生(teacher-student)方法将后门集成到预训练的文本编码器中，并证明当输入提示包含后门触发器时，例如用西里尔字符替换带下划线的拉丁字符，生成的图像将遵循特定描述或包含某些属性。

#### 3.2.4 Poisoning and disinformation

#### 3.2.4 中毒与虚假信息

Among various adversarial attacks against DNNs, poisoning attack is one of the most significant and rising security concerns for technologies that rely on data, particularly for models trained by enormous amounts of data acquired from diverse sources. Poisoning attacks attempt to manipulate some of the training data, which might lead the model to generate wrong or biased outputs. As LLM are often fine-tuned based on publicly accessible data (Chen et al. 2021a; Brown et al. 2020a), which are from unreliable and un-trusted documents or websites, the attacker can easily inject some adversaries into the training set of the victim model. Microsoft released a chatbot called Tay on Twitter (Lee 2016). Still it was forced to suspend activity after just one day because it was attacked by being taught to express racist and hateful rhetoric. Gmail's spam filter can be affected by simply injecting corrupted data in the training mails set (Bursz-tein 2018). Consequently, some evil chatbots might be designed to simulate people to spread disinformation or manipulate people, resulting in a critical need to evaluate the robustness of LLMs against data poisoning.

在各种对深度神经网络(DNNs)的对抗性攻击中，中毒攻击(poisoning attack)是最重要且日益受到关注的安全问题之一，尤其对于依赖大量多源数据训练的模型而言。中毒攻击试图操控部分训练数据，可能导致模型生成错误或偏颇的输出。由于大型语言模型(LLMs)通常基于公开可获取的数据(Chen等人，2021a；Brown等人，2020a)进行微调，而这些数据来自不可靠或不可信的文档或网站，攻击者可以轻松将恶意数据注入受害模型的训练集中。微软曾在Twitter上发布了一个名为Tay的聊天机器人(Lee，2016)，但仅运行一天后就被迫暂停，因为它被训练成表达种族主义和仇恨言论而受到攻击。Gmail的垃圾邮件过滤器也可能通过在训练邮件集中注入被污染的数据而受到影响(Bursztein，2018)。因此，一些恶意聊天机器人可能被设计成模拟人类传播虚假信息或操控人们，这使得评估大型语言模型(LLMs)对数据中毒的鲁棒性变得尤为重要。

Nelson et al. (2008) demonstrates how the poisoning attack can render the spam filter useless. By interfering with the training process, even if only 1% of the training dataset is manipulated, the spam filter might be ineffective. The authors propose two attack methods, one is an indiscriminate attack, and another is a targeted attack. The indiscriminate attack sends spam emails that contain words commonly used in legitimate messages to the victim, to force the victim to see more spam and more likely to mark a legitimate email as spam. As for the target attack, the attacker will send training emails containing words likely to be seen in the target email.

Nelson等人(2008)展示了中毒攻击(poisoning attack)如何使垃圾邮件过滤器(spam filter)失效。通过干扰训练过程，即使只操控1%的训练数据集，垃圾邮件过滤器也可能变得无效。作者提出了两种攻击方法，一种是无差别攻击，另一种是定向攻击。无差别攻击向受害者发送包含常用于合法信息中的词汇的垃圾邮件，以迫使受害者看到更多垃圾邮件，并更可能将合法邮件标记为垃圾邮件。至于定向攻击，攻击者会发送包含可能出现在目标邮件中的词汇的训练邮件。

With the increasing popularity of developing LLMs, researchers are becoming concerned about using chatbots to spread information. Since these LLMs, such as Chat-GPT, MidJourney, and Stable Diffusion, are trained on a vast amount of data collected from the internet, monitoring the quality of data sources is challenging. A recent study Carlini et al. (2023) introduced two poisoning attacks on various popular datasets acquired from websites. The first attack involves manipulating the data viewed by the customer who downloads the data to train the model. This takes advantage of the fact that the data observed by the dataset administrator during collection can differ from the data retrieved by the end user. Therefore, an attacker only needs to purchase a few domain names to gain control of a small portion of the data in the overall data collection. Another attack involves modifying datasets containing periodic snapshots, such as Wikipedia. The attacker can manipulate Wikipedia articles before they are included in the snapshot, resulting in the internet storing perturbed documents. Thus, a significant level of uncertainty and risk is involved when people use these LLMs as search engines.

随着大规模语言模型(LLMs)开发的日益普及，研究人员开始关注使用聊天机器人(chatbots)传播信息的问题。由于这些LLMs，如Chat-GPT(Chat Generative Pre-trained Transformer)、MidJourney和Stable Diffusion，是在从互联网收集的大量数据上训练而成，监控数据源的质量变得具有挑战性。最近的一项研究(Carlini等人，2023)介绍了对从网站获取的各种流行数据集的两种中毒攻击。第一种攻击涉及操控下载数据的用户所看到的数据，从而利用数据集管理员在收集过程中观察到的数据可能与最终用户检索到的数据不同的事实。因此，攻击者只需购买少数几个域名，就能控制整体数据收集中的一小部分数据。另一种攻击则涉及修改包含定期快照(如维基百科)的数据集。攻击者可以在这些内容被纳入快照之前操控维基百科的条目，从而导致互联网存储被篡改的文档。因此，在人们将这些LLMs用作搜索引擎时，存在较高的不确定性和风险。

### 3.3 Unintended bugs

### 3.3 非预期的漏洞

#### 3.3.1 Incidental exposure of user information

#### 3.3.1 用户信息的偶然暴露

In addition to the above attacks that an attacker actively initiates, ChatGPT was reported (https://www.engadget.com/chatgpt-briefly-went-offline-after-a-bug-revealed-user-chat-histories-115632504.html) to have a "chat history" bug that enabled the users to see from their ChatGPT sidebars previous chat histories from other users, and OpenAI recognised that this chat history bug may have also potentially revealed personal data from the paid ChatGPT Plus subscribers. According to the official report from Ope-nAI (https://openai.com/blog/march-20-chatgpt-outage), the same bug may have caused inadvertent disclosure of payment-related information for 1.2% of ChatGPT Plus subscribers. The bug was detected within the open-source Redis client library, redis-py. This cannot be an isolated incident, and we are expecting to witness more such "bugs" that could have severe security and privacy implications.

除了上述由攻击者主动发起的攻击外，据报道(https://www.engadget.com/chatgpt-briefly-went-offline-after-a-bug-revealed-user-chat-histories-115632504.html)，ChatGPT存在一个“聊天历史”漏洞，使用户可以从侧边栏看到其他用户的聊天记录，OpenAI也承认该聊天历史漏洞可能还潜在地泄露了付费的ChatGPT Plus订阅用户的个人数据。根据OpenAI的官方报告(https://openai.com/blog/march-20-chatgpt-outage)，同一漏洞可能导致1.2%的ChatGPT Plus订阅用户的支付相关信息被无意中披露。该漏洞是在开源的Redis客户端库redis-py中被检测到的。这不可能是孤立事件，我们预计还会出现更多类似的“漏洞”，可能带来严重的安全和隐私风险。

![bo_d1m003f7aajc73dif160_17_156_186_1216_444_0.jpg](images/bo_d1m003f7aajc73dif160_17_156_186_1216_444_0.jpg)

Fig. 5 Large language models: verification framework in lifecycle

图5 大型语言模型:生命周期中的验证框架

#### 3.3.2 Bias and discrimination

#### 3.3.2 偏见与歧视

Similar to the usual machine learning algorithms, LLMs are trained from data, which may include bias and discrimination. If not amplified, such vulnerabilities will be inherited by the LLMs. For example, Galactica, an LLM similar to ChatGPT trained on 46 million text examples, was shut down by Meta after 3 days because it spewed false and racist information (https://arstechnica.com/information-technology/2022/11/after-contr oversy-meta-pulls-demo-of-ai-model-that-writes-scientific-papers/). A political compass test (Rutinowski et al. 2023) reveals that ChatGPT is biased towards progressive and libertarian views. In addition, ChatGPT has a self-perception (Rutinowski et al. 2023) of seeing itself as having the Myers-Briggs personality type ENFJ.

与一般的机器学习算法类似，LLMs是在包含偏见和歧视的数据上训练的。如果不加以抑制，这些漏洞将被继承。例如，Galactica(类似于ChatGPT的LLM)，在训练了4600万条文本样本后，由Meta公司在3天后关闭，因为它传播了虚假和种族主义信息(https://arstechnica.com/information-technology/2022/11/after-controversy-meta-pulls-demo-of-ai-model-that-writes-scientific-papers/)。一项政治指南针测试(Rutinowski等人，2023)显示，ChatGPT偏向于进步主义和自由意志主义观点。此外，ChatGPT还具有自我认知(Rutinowski等人，2023)，认为自己具有迈尔斯-布里格斯(Myers-Briggs)性格类型ENFJ。

## 4 General verification framework

## 4 通用验证框架

Figure 5 provides an illustration of the general verification framework that might work with LLMs, by positioning the few categories of V&V techniques onto the lifecycle. In the Evaluation stage, other than the activities that are currently conducted (as mentioned in Fig. 3), we need to start with the falsification and evaluation techniques, in parallel with the explanation techniques. Falsification and evaluation techniques provide diverse, yet non-exhaustive, methods to find failure cases and have a statistical understanding about potential failures. Explanation techniques are to provide human-understandable explanations to the output of a LLMs. While these two categories are in parallel, they can interact, e.g., a failure case may require an explanation technique to understand the root cause, and the explanation needs to differentiate between different failure and non-failure cases. The verification techniques, which are usually high cost, may be only required when the LLMs pass the first two categories.

图5展示了一个可能适用于LLMs的通用验证框架，将少数几类验证与确认(V&V)技术映射到整个生命周期。在评估阶段，除了目前已进行的活动(如图3所述)，我们还需要同时进行反证(falsification)和评估技术，以及解释(explanation)技术。反证和评估技术提供多样但非穷尽的方法，用于发现失败案例并对潜在失败进行统计分析。解释技术旨在为LLMs的输出提供人类可理解的解释。虽然这两类技术是并行的，但它们可以相互作用，例如，一个失败案例可能需要解释技术来理解根本原因，而解释又需要区分不同的失败和非失败案例。验证技术通常成本较高，只有在前两类技术通过后才可能需要使用。

Finally, ethical principles and AI regulations are imposed throughout the lifecycle to ensure the ethical use of LLMs.

最后，在整个生命周期中会施加伦理原则和AI法规，以确保LLMs的伦理使用。

Figure 6 presents the taxonomy of verification and validation techniques we surveyed in this paper that can be used for large language models. In the following sections, we will review these techniques in greater details.

图6展示了本文调研的可用于大语言模型(Large Language Models, LLM)的验证与确认(Verification and Validation)技术的分类。在接下来的章节中，我们将对这些技术进行更详细的回顾。

![bo_d1m003f7aajc73dif160_18_249_186_1030_751_0.jpg](images/bo_d1m003f7aajc73dif160_18_249_186_1030_751_0.jpg)

Fig. 6 Taxonomy of surveyed verification and validation techniques for large language models

图6 调研的大语言模型验证与确认技术分类

## 5 Falsification and evaluation

## 5 伪造与评估

This section summarises the known methods for identifying and evaluating the vulnerabilities of LLM-based machine learning applications. Falsification and evaluation requires a red team (Bullwinkle and Urban 2023), which, instead of having annotators label pre-existing texts, interacts with a model and actively finds examples that fail. The red team needs to be consist of people of diverse backgrounds and concerning about different risks (benign vs. malicious). We also discuss on how the methods can, and should, be adapted.

本节总结了识别和评估基于大语言模型的机器学习应用的漏洞的已知方法。伪造与评估需要一个红队(Bullwinkle 和 Urban 2023)，该团队不是让标注员标注已有文本，而是与模型互动，主动寻找失败的示例。红队成员应来自不同背景，关注不同风险(善意与恶意)。我们还讨论了这些方法如何，以及应如何进行调整。

### 5.1 Prompt injection

### 5.1 提示注入

This section discusses using prompts to direct LLMs to generate outputs that do not align with human values. This includes the generation of malware, violence instruction, and so on. Conditional misdirection has been successfully applied which misdirects the AI by creating a situation where a certain event needs to occur to avoid violence.

本节讨论利用提示(prompts)引导大语言模型生成不符合人类价值观的输出，包括生成恶意软件、暴力指令等。条件误导(Conditional Misdirection)已被成功应用，通过制造某种事件必须发生以避免暴力的情境，误导AI。

Prompt injection for LLMs is not vastly distinct from other injection attacks commonly observed in information security. It arises from the concatenation of instructions and data, rendering it arduous for the underlying engine to distinguish them. Consequently, attackers can incorporate instructions into the data fields they manage and compel the engine to carry out unforeseen actions. Within this comprehensive definition of injection attacks, prompt engineering work can be regarded as instructions (analogous to a SQL query, for instance). At the same time, the input information provided can be deemed as data.

大语言模型的提示注入(Prompt Injection, PI)与信息安全中常见的其他注入攻击没有本质区别。它源于指令与数据的拼接，使底层引擎难以区分二者。因此，攻击者可以将指令嵌入其管理的数据字段中，迫使引擎执行未预料的操作。在这种全面的注入攻击定义中，提示工程(Prompt Engineering)工作可以视为指令(类似于SQL查询)，而输入信息则视为数据。

Several methods for mis-aligning LLMs via Prompt Injection (PI) attacks have been successfully applied (https://github.com/dair-ai/Prompt-Engineering-Guide/tree/main/ guides). In these attacks, the adversary can prompt the LLM to generate malicious content or override the initial instructions and the filtering mechanisms. Recent studies have demonstrated that these attacks are difficult to mitigate since current state-of-the-art LLMs are programmed to follow instructions. Therefore, most attacks were based on the assumption that the adversary can directly inject prompt to the LLMs. For example, Perez and Ribeiro (2022) reveals two kinds of threats by manipulating the prompts. The first one is goal hijacking, aiming to divert the intended goal of the original prompts towards a target goal, while prompt leaking endeavours to retrieve information from private prompts.

已有多种利用提示注入(PI)攻击误导大语言模型的方法被成功应用(https://github.com/dair-ai/Prompt-Engineering-Guide/tree/main/guides)。在这些攻击中，攻击者可以诱导模型生成恶意内容，或覆盖初始指令和过滤机制。最新研究表明，这些攻击难以防范，因为当前最先进的大语言模型被设计成遵循指令。因此，大多数攻击假设攻击者可以直接向模型注入提示。例如，Perez 和 Ribeiro(2022)揭示了通过操控提示的两种威胁:第一种是目标劫持，旨在将原始提示的目标偏离，转向攻击者设定的目标；第二种是提示泄露，试图从私有提示中获取信息。

Kang et al. (2023a) explores the programmatic behaviour of LLMs, demonstrating that classical security attacks such as obfuscation, code injection, and virtualisation can be used to circumvent the defence mechanisms of LLMs. This further exhibits that instruction-based LLMs can be misguided to generate natural and convincing person-alised malicious content by leveraging unnatural prompts.

Kang 等人(2023a)探讨了大语言模型的程序行为，证明了诸如混淆(obfuscation)、代码注入(code injection)和虚拟化(virtualisation)等经典安全攻击可以用来绕过大语言模型的防御机制。这进一步表明，基于指令的模型可以通过利用非自然的提示被误导，生成自然且具有说服力的个性化恶意内容。

Moreover, Deshpande et al. (2023) suggests that by assigning ChatGPT a persona, say that of the boxer Muhammad Ali (with a prompt "Speak like Muhammad Ali."), the toxicity of generations can be significantly increased. Maus et al. (2023) develops a black-box framework for producing adversarial prompts for unstructured image and text generation. Employing a token space projection operator provides a solution from mapping the continuous word embedding space into the discrete token space, such that some black-box attacks method, like square attacks, can be applied to explore adversarial prompts. Experimental results found that those adversarial prompts encourage positive sentiments or increase the frequency of the targeted letter in the generated text. Wolf et al. (2023) also suggests the existence of a fundamental limitation on mitigating such prompt injection to trigger undesirable behaviour, i.e., as long as the length of the prompts can be increased, the behaviour has a positive probability to be exhibited.

此外，Deshpande 等人(2023)提出，通过赋予ChatGPT一个特定角色，比如“穆罕默德·阿里”(提示为“像穆罕默德·阿里一样说话。”)，可以显著增加生成内容的毒性。Maus 等人(2023)开发了一个黑箱框架，用于生成对抗性提示(adversarial prompts)，适用于非结构化的图像和文本生成。通过引入令牌空间投影算子，将连续的词嵌入空间映射到离散的令牌空间，从而可以应用诸如平方攻击(square attacks)等黑箱攻击方法，探索对抗性提示。实验结果显示，这些对抗性提示可以激发积极情感，或增加目标字母在生成文本中的出现频率。Wolf 等人(2023)也指出，减轻此类提示注入引发不良行为的根本限制在于，只要可以增加提示的长度，相关行为就有可能发生。

Li et al. (2023b) claims that in the previous versions of ChatGPT, some personal private information could be successfully extracted via direct prompting. However, with the improved guardrails, some behaviours have been well-protected in the March 2023 version of ChatGPT, where ChatGPT is aware of leaking privacy when direct prompts are applied, it will tend to refuse to provide the answer that may contain private information. Although some efforts have been conducted to prevent training data extraction attacks with direct prompts, Li et al. (2023b) illustrates that there is still a sideway to bypass ChatGPT's ethical modules. They propose a method named jailbreak to exploit tricky prompts to set up user-created role plays to alter ChatGPT's ego and programming restrictions, which allows it to answer users' queries unethically. More recently, Greshake et al. (2023) proposes a novel indirect prompt injection, which required the community to have an urgent investigation and evaluation of current mitigation techniques against these threats. When LLMs are integrated with other plugins or using its API calling, the content retrieved from the Web (public source) may already be poisoned and contain malicious prompts pre-injected and selected by adversaries, such that these prompts can be indirectly used to control and direct the model. In other words, prompt injection risks may occur not only in situations where adversaries explicitly prompt LLMs but also among users, developers, and automated data processing systems.

李等人(2023b)声称，在ChatGPT的早期版本中，某些个人隐私信息可以通过直接提示成功提取。然而，随着保护措施的改进，2023年3月版本的ChatGPT在某些行为方面得到了有效保护，当ChatGPT意识到在直接提示下可能泄露隐私时，它会倾向于拒绝提供可能包含私人信息的答案。尽管已经采取一些措施防止通过直接提示进行训练数据提取攻击，李等人(2023b)指出仍存在绕过ChatGPT伦理模块的途径。他们提出了一种名为“越狱(jailbreak)”的方法，利用巧妙的提示设置用户创建角色扮演，从而改变ChatGPT的自我认知和编程限制，使其能够不道德地回答用户的查询。最近，Greshake等人(2023)提出了一种新颖的间接提示注入技术，呼吁社区对当前应对这些威胁的缓解技术进行紧急调查和评估。当大型语言模型(LLMs)与其他插件集成或通过API调用时，从网络(公共资源)检索的内容可能已被污染，包含由对手预先注入和选择的恶意提示，从而可以间接用来控制和引导模型。换句话说，提示注入的风险不仅存在于对抗者明确提示LLMs的场景中，也存在于用户、开发者和自动化数据处理系统之间。

We also noticed that prompt injection, and techniques based on prompt injection to work with the APIs of LLMs, have been used to generate malware (Goodin 2023; News 2023; Botacin 2023).

我们还注意到，提示注入及基于提示注入的技术已被用于生成恶意软件(Goodin 2023；News 2023；Botacin 2023)。

### 5.2 Comparison with Human Experts

### 5.2 与人类专家的比较

Another evaluation thread is to study how LLMs are compared with human experts. For example, for ChatGPT, Guo et al. (2023) conducts the comparison on questions from open-domain, financial, medical, legal, and psychological areas, Farhat et al. (2023) compares on the bibliometric analysis, Malinka et al. (2023) evaluates on university education with a primary focus on computer security-oriented specialisation, Ji et al. (2023) considers the ranking of contents, and Wu et al. (2023e) compares on the grammatical error correction (GEC) task. It is surprising to note that, in all these comparisons, the conclusion is that, ChatGPT does not perform as well as expected. One step further, to study collaboration rather than only focus on comparisons, Qi et al. (2023) explores how ChatGPT's performance on safety analysis can be compared with human experts, and concludes that the best results are from the close collaboration between ChatGPT and the human experts. A similar conclusion was also drawn by Jang and Lukasiewicz (2023) when studying ChatGPT's logically consistent behaviours.

另一个评估方向是研究LLMs与人类专家的比较。例如，对于ChatGPT，Guo等人(2023)在开放领域、金融、医疗、法律和心理学等问题上进行了比较，Farhat等人(2023)进行了文献计量分析，Malinka等人(2023)在以计算机安全为重点的大学教育方面进行了评估，Ji等人(2023)考虑了内容的排名，Wu等人(2023e)则在语法错误校正(GEC)任务上进行了比较。令人惊讶的是，在所有这些比较中，结论都显示ChatGPT的表现未达预期。更进一步，为了研究合作而非仅仅关注比较，Qi等人(2023)探讨了ChatGPT在安全分析中的表现如何与人类专家进行比较，并得出结论:最佳效果来自ChatGPT与人类专家的密切合作。Jang和Lukasiewicz(2023)在研究ChatGPT的逻辑一致性行为时也得出了类似的结论。

In some cases, LLMs can outperform human experts in specific tasks, like processing enormous amounts of data or doing repeated activities with great accuracy. For example, LLMs can be used to analyse massive numbers of medical records to uncover patterns and links between different illnesses, which can aid in medical diagnosis and therapy (Liu et al. 2023d; Agrawal et al. 2022). On the other hand, human experts may outperform LLMs in jobs requiring more complicated reasoning or comprehension of social and cultural contexts. Human specialists, for example, may better interpret and respond to delicate social signs in a conversation, which can be difficult for LLMs. It is important emphasising that LLMs are intended to supplement rather than replace human competence (Shanahan 2022). LLMs can automate specific processes or help human professionals accomplish things more efficiently and precisely (Zhao et al. 2023a). For example, Qi et al. (2023) studies how ChatGPT's performance on safety analysis can be compared with human experts and concludes that the best results are from the close collaboration between ChatGPT and the human experts. Holmes et al. (2023) also shows that huge language models have a lot of potential as knowledgeable assistants collaborating with subject specialists.

在某些情况下，LLMs可以在特定任务中优于人类专家，比如处理海量数据或进行高精度的重复性工作。例如，LLMs可以用来分析大量的医疗记录，发现不同疾病之间的模式和联系，从而辅助医疗诊断和治疗(Liu等人 2023d；Agrawal等人 2022)。另一方面，人类专家在需要更复杂推理或理解社会文化背景的工作中可能优于LLMs。例如，人类专家可能更善于解读和应对对话中的微妙社会信号，而这对LLMs来说可能较为困难。需要强调的是，LLMs旨在补充而非取代人类能力(Shanahan 2022)。LLMs可以自动化某些流程，或帮助人类专业人士更高效、更准确地完成任务(Zhao等人 2023a)。例如，Qi等人(2023)研究了ChatGPT在安全分析中的表现如何与人类专家进行比较，并得出结论:最佳效果来自ChatGPT与人类专家的密切合作。Holmes等人(2023)也显示，大型语言模型作为知识丰富的助手，与专业人员合作具有巨大潜力。

### 5.3 Benchmarks

### 5.3 基准测试

Benchmark datasets have been used to evaluate the performance of LLMs. For example, in Wang et al. (2023a), AdvGLUE and ANLI benchmark datasets are used to assess adversarial robustness, and Flipkart review and DDXPlus medical diagnosis datasets are used to evaluate out-of-distribution evaluation. In Sun et al. (2023), eight kinds of typical safety scenarios and six types of more challenging instruction attacks are used to expose safety issues of LLMs. In Frieder et al. (2023), the GHOSTS dataset is used to evaluate the mathematical capability of ChatGPT.

基准数据集已被用来评估LLMs的性能。例如，Wang等人(2023a)使用AdvGLUE和ANLI基准数据集评估对抗鲁棒性，使用Flipkart评论和DDXPlus医疗诊断数据集评估超出分布(out-of-distribution)能力。在Sun等人(2023)中，采用八种典型安全场景和六种更具挑战性的指令攻击类型，揭示LLMs的安全问题。在Frieder等人(2023)中，使用GHOSTS数据集评估ChatGPT的数学能力。

Regarding the LLMs as a software as a service, rather than previous deep learning models, it becomes imperative to incorporate lifelong time assessment. In Chen et al. (2023a), they evaluated the March 2023 and June 2023 versions of GPT-3.5 and GPT-4 on several diverse benchmarks. The LLM service's behavior can undergo significant changes within a fairly brief period, as evidenced by their findings. According to Edwards (2023), it states that while releasing the results of the benchmark, the providers should provide raw results, not only high-level metrics. So that the inspector is capable of conducting a more thorough examination of the model's defects. Previous NLP works show that fine-tuning pre-trained transformer-based language models such as BERT (Devlin et al. 2018) is an unstable process (Dodge et al. 2020; Lee et al. 2019). During the continual updating of LLMs, it could go through multiple iterations of finetune and RLHF, which even increases the risk of catastrophic forgetting. In Aiyappa et al. (2023), the challenge of ensuring fair model evaluation in the age of closed and continuously trained models is discussed. Moreover, Low-Rank Adaptation (LoRA) is proposed to reduce the trainable parameters and thus could avoid catastrophic forgetting (Hu et al. 2021).

将大型语言模型(LLMs)作为一种软件即服务(SaaS)来看待，而非之前的深度学习模型，变得尤为重要的是引入终身时间评估。在Chen等人(2023a)中，他们在多个不同基准测试中评估了2023年3月和6月版本的GPT-3.5和GPT-4。事实证明，LLM服务的行为在相对短的时间内可能发生显著变化。根据Edwards(2023)的说法，在发布基准测试结果时，提供商应提供原始结果，而不仅仅是高层次的指标，以便检测者能够对模型的缺陷进行更全面的检查。之前的自然语言处理(NLP)研究表明，微调预训练的基于变换器(Transformer)模型(如BERT(Devlin等，2018))是一个不稳定的过程(Dodge等，2020；Lee等，2019)。在LLMs持续更新的过程中，可能会经历多次微调和RLHF(强化学习与人类反馈)迭代，这甚至增加了灾难性遗忘的风险。在Aiyappa等人(2023)中，讨论了在封闭式和持续训练模型时代确保公平模型评估的挑战。此外，提出了低秩适应(LoRA)方法，以减少可训练参数，从而避免灾难性遗忘(Hu等，2021)。

### 5.4 Testing and statistical evaluation

### 5.4 测试与统计评估

As mentioned above, most existing techniques on the falsification and evaluation heavily rely on human intelligence and therefore have a significant level of human involvement. In red teaming, the red team must be creative in finding bad examples. In prompt injection, the attacker needs to design specific (sequence of) prompts to retrieve the information they need. Unfortunately, human expertise and intelligence are expensive and scarce, which calls for automated techniques to have an intensive and fair evaluation, and to find corner cases as exhaustive as possible. In the following, we discuss how testing and statistical evaluation methods can be adapted for a fair evaluation of LLMs.

如上所述，现有的大多数伪造与评估技术在很大程度上依赖于人工智能，因此需要大量的人类参与。在红队测试中，红队必须具备创造性，寻找不良示例。在提示注入(prompt injection)中，攻击者需要设计特定的(序列的)提示以获取所需信息。不幸的是，人类的专业知识和智能成本高昂且稀缺，这就需要自动化技术进行深入且公平的评估，并尽可能穷尽边界情况。以下，我们将讨论如何调整测试和统计评估方法，以实现对LLMs的公平评估。

To simplify it, we assume an LLM is a system that generates an output given an input. Let $\mathbf{D}$ be the space of nature data, an LLM is a function $M : \mathbf{D} \rightarrow  \mathbf{D}$ . In the meantime, there is another function $H : \mathbf{D} \rightarrow  \mathbf{D}$ representing human’s response. For an automated generation of test cases, we need to have an oracle $\mathbf{O}$ , a test coverage metric $\mathbf{C}$ , and a test case generation method $\mathbf{A}$ . The oracle $\mathbf{O}$ determines if an input-output pair(x, y)is correct. The implementation of oracle is related to both $M$ and $H$ , by checking whether given any input $\mathbf{x}$ their outputs $M\left( \mathbf{x}\right)$ and $H\left( \mathbf{x}\right)$ are similar under certain criteria. We call an input-output pair a test case. Given a set of test cases $\mathbf{P} = {\left\{  \left( {\mathbf{x}}_{i},{\mathbf{y}}_{i}\right) \right\}  }_{i = 1,\ldots , n}$ , an evaluation of the coverage metric $\mathbf{C}$ returns a probability value representing the percentage of cases in $\mathbf{P}$ over the cases that should be tested. Finally, the test case generation method $\mathbf{A}$ generates the set $\mathbf{P}$ of test cases. Usually, the design of coverage metric $\mathbf{C}$ should be based on the property to be verified. Therefore, the verification problem is reduced to determining of whether the percentage of test cases in $\mathbf{P}$ that passes the oracle $\mathbf{O}$ is above a pre-specified threshold.

简而言之，我们假设一个LLM是一个在给定输入后生成输出的系统。设$\mathbf{D}$为自然数据空间，LLM是一个函数$M : \mathbf{D} \rightarrow  \mathbf{D}$。同时，还有另一个函数$H : \mathbf{D} \rightarrow  \mathbf{D}$代表人类的反应。为了自动生成测试用例，我们需要一个oracle(判定器)$\mathbf{O}$，一个测试覆盖率指标$\mathbf{C}$，以及一个测试用例生成方法$\mathbf{A}$。oracle(判定器)$\mathbf{O}$用以判断输入-输出对(x, y)是否正确。oracle的实现涉及到$M$和$H$，通过检查在给定任何输入$\mathbf{x}$时，它们的输出$M\left( \mathbf{x}\right)$和$H\left( \mathbf{x}\right)$是否在某些标准下相似。我们将输入-输出对称为测试用例。给定一组测试用例$\mathbf{P} = {\left\{  \left( {\mathbf{x}}_{i},{\mathbf{y}}_{i}\right) \right\}  }_{i = 1,\ldots , n}$，对覆盖率指标$\mathbf{C}$的评估会返回一个概率值，代表在应测试的案例集合$\mathbf{P}$中，符合条件的案例比例。最后，测试用例生成方法$\mathbf{A}$会生成测试用例集$\mathbf{P}$。通常，覆盖率指标$\mathbf{C}$的设计应基于待验证的属性。因此，验证问题简化为判断在测试用例集$\mathbf{P}$中，通过oracle(判定器)$\mathbf{O}$的案例比例是否高于预设阈值。

Statistical evaluation applies statistical methods in order to gain insights into the verification problem we are concerned about. In addition to the purpose of determining the existence of failures (i.e., counterexamples to the satisfiability of desirable properties) in the deep learning model, statistical evaluation assesses the satisfiability of a property in a probabilistic way, by, e.g., aggregating sampling results. The aggregated evaluation result may have the probabilistic guarantee, e.g., the probability of failure rate lower than a threshold $l$ is greater than $1 - \epsilon$ , for some small constant $\epsilon$ .

统计评估采用统计方法，以深入理解我们关心的验证问题。除了判断深度学习模型中是否存在失败(即不满足期望属性的反例)之外，统计评估还以概率方式评估属性的可满足性，例如，通过汇总采样结果。汇总的评估结果可能具有概率保证，例如，失败率低于某个阈值$l$的概率大于$1 - \epsilon$，对于某个较小的常数$\epsilon$。

While the study on LLMs is just started (Reiss 2023), statistical evaluation methods have been proposed for the general machine learning models.

虽然对大规模语言模型(LLMs)的研究刚刚起步(Reiss 2023)，但已经提出了一般机器学习模型的统计评估方法。

Sampling methods and testing methods have been considered for convolutional or recurrent neural networks. Sampling methods, such as Weng et al. (2018), are to summarise property-related statistics from the samples. There are many ways to determine how the test cases are generated, including, e.g., fuzzing, coverage metrics (Sun et al. 2019; Huang et al. 2021), symbolic execution (Gopinath et al. 2018), concolic testing (Sun et al. 2018b), etc. Testing methods, on the other hand, generate a set of test cases and use the generated test cases to evaluate the reliability (or other properties) of deep learning (Sun et al. 2018a). While sampling methods can have probabilistic guarantees via, e.g., Chebyshev's inequality, it is still under investigation on associating test coverage metrics with probabilistic guarantees. Moreover, ensuring that the generated or sampled test cases are realistic is necessary, i.e., on the data distribution (Huang et al. 2022b; Zhao et al. 2021b).

对于卷积神经网络(CNN)或循环神经网络(RNN)，已考虑采样方法和测试方法。采样方法，例如Weng等人(2018)，旨在总结样本的属性相关统计数据。确定测试用例生成方式的方法有很多，包括例如模糊测试(fuzzing)、覆盖率指标(Sun等人 2019；Huang等人 2021)、符号执行(Gopinath等人 2018)、符号执行结合测试(concolic testing)(Sun等人 2018b)等。测试方法则是生成一组测试用例，并利用这些测试用例评估深度学习模型的可靠性(或其他属性)(Sun等人 2018a)。虽然采样方法可以通过切比雪夫不等式(Chebyshev's inequality)等提供概率保证，但关于将测试覆盖率指标与概率保证关联的研究仍在进行中。此外，确保生成或采样的测试用例具有现实性，即符合数据分布(Huang等人 2022b；Zhao等人 2021b)，也是必要的。

For LLMs, the key technical challenges are on the design of test coverage metrics and the test case generation algorithms because (1) LLMs need to be considered in a black-box manner, rather than white-box one; this is mainly due to the size of LLMs that cannot be reasonably explored, and therefore an exploration on the input space will become more practical; (2) LLMs are for natural language texts, and it is hard to define the ordering between two texts; the ordering between two inputs are key to the design of test case generation algorithms; and (3) LLMs are non-deterministic, i.e., different outputs are expected in two tests with identical input.

对于大规模语言模型(LLMs)，主要的技术挑战在于测试覆盖率指标的设计和测试用例生成算法，因为(1)LLMs需要以黑盒方式考虑，而非白盒方式；这主要是由于LLMs的规模无法合理探索，因此对输入空间的探索将变得更为实际；(2)LLMs处理的是自然语言文本，难以定义两个文本之间的排序关系；而两个输入之间的排序关系是设计测试用例生成算法的关键；以及(3)LLMs具有非确定性，即在相同输入的两次测试中，预期会得到不同的输出。

## 6 Verification

## 6  验证

This section discusses if and how more rigorous verification can be extended to work on LLM-based machine-learning tasks. So far, the verification or certification of LLMs is still an emerging research area. This section will first provide a comprehensive and systematic review of the verification techniques on various NLP models. Then, we will discuss a few pioneering black-box verification methods that are workable on large-scale language models. These are followed by a discussion on how to extend these efforts towards LLMs and a review of the efforts to reduce the scale of LLMs to increase the validity of verification techniques.

本节讨论是否以及如何将更严格的验证方法扩展到基于LLMs的机器学习任务。目前，LLMs的验证或认证仍是一个新兴的研究领域。本节将首先对各种自然语言处理(NLP)模型的验证技术进行全面系统的回顾，然后讨论一些可行的黑盒验证方法，这些方法适用于大规模语言模型。接着，将探讨如何将这些努力扩展到LLMs，以及回顾旨在减少LLMs规模以提高验证技术有效性的相关工作。

We remark that, this section is focused on verifying LLMs. For the other direction of utilising LLMs to support the verification, there are works related to e.g., specification autoformalisation (Wu et al. 2022a), code generation (Thakur et al. 2023), assertion generation (Kande et al. 2023), zero-shot vulnerability repair (Pearce et al. 2023).

我们指出，本节重点在于验证LLMs。关于利用LLMs支持验证的其他方向，有相关工作，例如规范自动形式化(Wu等人 2022a)、代码生成(Thakur等人 2023)、断言生成(Kande等人 2023)、零样本漏洞修复(Pearce等人 2023)等。

### 6.1 Verification on natural language processing models

### 6.1 自然语言处理模型的验证

As discussed in previous sections, an attacker could generate millions of adversarial examples by manipulating every word in a sentence. Adversarial examples have different safety and trustworthiness implications to the downstream tasks. For example, a perturbed output text might include different emotions that will affect the sentiment analysis, and it is possible that a perturbed text might have the same meaning but different language style to affect the spam detection. However, such methods may still fail to address numerous unseen cases arising from exponential combinations of different words in a text input. To overcome these limitations, another class of techniques has emerged, grounded in the concept of "certification" or "verification" (Seshia et al. 2016; Huang et al. 2017). For example, via certification or verification, these methods train the model to provide an upper bound on the worst-case loss of perturbations, thereby offering a certificate of robustness without necessitating the exploration of the adversarial space (Sinha et al. 2017). By utilising these certification-driven methods, we can better evaluate the model's robustness in the face of adversarial attacks (Goodfellow and Papernot 2017).

如前几节所述，攻击者可以通过操控句子中的每个词，生成数百万的对抗样本。对抗样本对下游任务的安全性和可信度具有不同的影响。例如，经过扰动的输出文本可能包含不同的情感，从而影响情感分析；也可能扰动后文本意义不变，但语言风格不同，从而影响垃圾邮件检测。然而，这些方法仍可能无法应对由文本中不同词汇的指数级组合所引发的众多未见案例。为克服这些限制，出现了一类基于“认证”或“验证”概念的技术(Seshia等人 2016；Huang等人 2017)。例如，通过认证或验证，这些方法训练模型以提供对最坏情况扰动损失的上界，从而在无需探索对抗空间的情况下提供鲁棒性证明(Sinha等人 2017)。利用这些基于认证的方法，我们可以更好地评估模型在面对对抗攻击时的鲁棒性(Goodfellow和Papernot 2017)。

![bo_d1m003f7aajc73dif160_23_154_177_1223_430_0.jpg](images/bo_d1m003f7aajc73dif160_23_154_177_1223_430_0.jpg)

Fig. 7 Pipeline for robustness verification in Ye et al. (2020)

图7 Ye等人(2020)提出的鲁棒性验证流程

#### 6.1.1 Verification via interval bound propagation

#### 6.1.1 通过区间界限传播进行验证

The first technique successfully adapted from the computer vision domain for verifying NLP models is Interval Bound Propagation (IBP). It is a bounding technique that has gained significant attention for its effectiveness in training large, robust, and verifiable neural networks (Gowal et al. 2018). By striving to minimise the upper bound on the maximum difference between the classification boundary and input perturbation region, IBP allows the incorporation of a loss term during training. This enables the minimisation of the last layer of the perturbation region, ensuring it remains on one side of the classification boundary. As a result, the adversarial region becomes tighter and can be considered certified robust. Notably, Jia et al. (2019) proposed certified robust models while providing maximum perturbations in text classification. The authors employed interval bound propagation to optimise the upper bound over perturbations, providing an upper bound over the discrete set of perturbations in the word vector space.

从计算机视觉领域成功借鉴的验证NLP模型的第一项技术是区间界限传播(IBP)。这是一种边界技术，因其在训练大规模、鲁棒且可验证的神经网络(Gowal等，2018)方面的有效性而受到广泛关注。通过努力最小化分类边界与输入扰动区域之间最大差异的上界，IBP允许在训练过程中引入一个损失项。这使得可以最小化扰动区域的最后一层，确保其始终位于分类边界的一侧。因此，对抗区域变得更加紧密，可以被视为具有认证鲁棒性。值得注意的是，Jia等(2019)提出了在文本分类中提供最大扰动的认证鲁棒模型。作者采用区间界限传播优化扰动的上界，为词向量空间中的离散扰动集提供了上界。

Later on, Huang et al. (2019a) introduced a verification and verifiable training method for neural networks in NLP, proposing a tighter over-approximation in the form of a 'simplex' in the embedding space for input perturbations. To make the network verifiable, they defined the convex hull of all the original unperturbed inputs as a space of delta perturbation. By employing the IBP algorithm, they generated robustness bounds for each neural network layer. Furthermore, as shown in Fig. 7, Ye et al. (2020) proposed structure-free certified robust models, which can be applied to any arbitrary model, overcoming the limitations of IBP-based methods that are not applicable to character-level and sub-word-level models. This work introduced a perturbation set of words using synonym sets and top-K nearest neighbours under the cosine similarity of GloVE vectors (Pennington et al. 2014), which could subsequently generate sentence perturbations using word perturbations and train a provably robust classifier. Very recently, Wallace et al. (2022) highlighted the limitations of IBP-based methods in a broader range of NLP tasks, demonstrating that IBP methods have poor generalisability. In this work, the authors performed a systematic evaluation of various of sentiment analysis tasks. They pointed out some insights regarding the promising improvements and adaptations for IBP methods in the NLP domain.

随后，Huang等(2019a)为NLP中的神经网络引入了一种验证和可验证的训练方法，提出在嵌入空间中以“单纯形”形式对输入扰动进行更紧的过度近似。为了使网络可验证，他们将所有原始未扰动输入的凸包定义为δ扰动空间。通过采用IBP算法，为每个神经网络层生成了鲁棒性界限。此外，如图7所示，Ye等(2020)提出了结构无关的认证鲁棒模型，可以应用于任何任意模型，克服了基于IBP的方法在字符级和子词级模型中的局限性。该工作引入了使用同义词集和余弦相似度下的Top-K邻近词的扰动词集(Pennington等，2014)，随后可以利用词扰动生成句子扰动，并训练出具有可证明鲁棒性的分类器。最近，Wallace等(2022)指出了IBP方法在更广泛的NLP任务中的局限性，证明了IBP方法的泛化能力较差。在这项工作中，作者对多种情感分析任务进行了系统评估，并提出了关于在NLP领域中改进和适应IBP方法的有益见解。

#### 6.1.2 Verification via abstract interpretation

#### 6.1.2 通过抽象解释进行验证

Another popular verification technique applied to various NLP models is based on abstract interpretation or functional over-approximation. The idea behind abstract interpretation is to approximate the behaviour of a program by representing it using a simpler model that is easier to analyse. Specifically, this technique can represent the network using an abstract domain that captures the possible range of values the network can output for a given input. This abstract domain can then be used to reason about the network's behaviour under different conditions, such as when the network is under adversarial perturbation. One notable contribution in this area is POPQORN (Ko et al. 2019). It can find a certificate of robustness for RNN-based networks, which utilised 2D planes to bound the cross-nonlinearity in Long Short-Term Memory (LSTM) networks so a certificate within an ${l}_{p}$ ball can be located if the lower bound on the true label output unit is larger than the upper bounds of all other output units. Later on, Cert-RNN (Du et al. 2021) introduced a robust certification framework for RNNs that overcomes the limitations of POPQORN (Ko et al. 2019). The framework maintains inter-variable correlation and accelerates the non-linearities of RNNs for practical uses. This work utilised Zonotopes (Eppstein 1996) to encapsulate input perturbations. Cert-RNN can verify the properties of the output Zonotopes to determine certifiable robustness. Using Zonotopes, as opposed to boxes, allows improved precision and tighter bounds, leading to a significant speedup compared to POPQORN.

另一种在各种NLP模型中应用的流行验证技术是基于抽象解释或函数的过度逼近。抽象解释的思想是用更简单的模型来近似程序的行为，从而更容易分析。具体而言，该技术可以用抽象域表示网络，捕捉网络对给定输入可能输出的值范围。然后，可以利用这个抽象域推理网络在不同条件下的行为，例如在对抗扰动下的表现。该领域的一个重要贡献是POPQORN(Ko等，2019)，它可以为基于RNN(循环神经网络)的模型找到鲁棒性证书，利用二维平面界定长短期记忆(LSTM)网络中的交叉非线性，如果真实标签输出单元的下界大于所有其他输出单元的上界，就可以在一个${l}_{p}$球内找到证书。随后，Cert-RNN(Du等，2021)提出了一个鲁棒性认证框架，克服了POPQORN(Ko等，2019)的局限性。该框架保持变量间的相关性，加快了RNN中的非线性运算，适用于实际应用。该工作利用Zonotope(Eppstein，1996)封装输入扰动。Cert-RNN可以验证输出Zonotope的性质，以确定可认证的鲁棒性。使用Zonotope而非盒子，可以获得更高的精度和更紧的界限，从而显著提升速度，优于POPQORN。

Recently, Abstractive Recursive Certification (ARC) was introduced to verify the robustness of RNNs (Zhang et al. 2021). Using those transformations, ARC defined a set of programmatically perturbed string transformations and constructed a perturbation space. By memorising the hidden states of strings in the perturbation space that share a common prefix, ARC can efficiently calculate an upper bound while avoiding redundant hidden state computations. Roughly at the same time, Ryou et al. proposed a similar method called Polyhedral Robustness Verifier (PROVER) (Ryou et al. 2021). PROVER can represent input perturbations as polyhedral to generate a certifiably verified network for more general sequential data. To certify large transformers, DeepT was proposed by Bonaert et al. (2021). It was specifically designed to verify the robustness of transformers against synonym replacement-based attacks. DeepT employed multi-norm Zonotopes to achieve larger robustness radii in the certification. For the transformers with self-attention layers, Shi et al. (2019) developed a verification algorithm that can provide a lower bound to ensure the probability of the correct label is consistently higher than that of the incorrect labels. This method can obtain a tighter bound than those obtained from IBP-based methods.

最近，抽象递归认证(ARC)被引入用以验证循环神经网络(RNNs)的鲁棒性(Zhang等，2021)。通过这些变换，ARC定义了一组程序化扰动字符串变换，并构建了一个扰动空间。通过记忆在扰动空间中共享共同前缀的字符串的隐藏状态，ARC可以高效地计算上界，同时避免冗余的隐藏状态计算。大致在同一时间，Ryou等提出了一种类似的方法，称为多面体鲁棒性验证器(PROVER)(Ryou等，2021)。PROVER可以将输入扰动表示为多面体，从而生成可验证的网络，适用于更一般的序列数据。为了验证大型变换器(transformers)，Bonaert等(2021)提出了DeepT。它专门设计用于验证变换器对基于同义词替换攻击的鲁棒性。DeepT采用多范数Zonotope以实现更大的鲁棒半径。在具有自注意力层的变换器中，Shi等(2019)开发了一种验证算法，能够提供下界，确保正确标签的概率始终高于错误标签的概率。这种方法比基于IBP(区间传播)的方法能获得更紧的界限。

#### 6.1.3 Verification via randomised smoothing

#### 6.1.3 通过随机平滑进行验证

Randomised smoothing (RS) (Cohen et al. 2019) is another promising technique for verifying the robustness of deep language models. Its basic idea is to leverage randomness during inference to create a smoothed classifier that is more robust to small perturbations in the input. This technique can also be used to give certified guarantees against adversarial perturbations within a certain radius. Generally, randomized smoothing begins by training a regular neural network on a given dataset. Then, given a trained base classifier $f$ and an input $x$ , the smoothed classifier $g$ is defined using randomness (e.g., Gaussian noise) as: $g\left( x\right)  = {\operatorname{argmax}}_{c}\mathbb{P}\left( {f\left( {x + \epsilon }\right)  = c}\right)$ , where $\epsilon$ is the noise sampled from some distribution (e.g., a Gaussian distribution). During the inference phase, to classify a new sample, noise is randomly sampled from the predetermined distribution multiple times. These instances of noise are then injected into the input $x$ , resulting in noisy samples. Subsequently, the base classifier $f\left( x\right)$ generates predictions for each of these noisy samples. The final prediction is determined by the class with the highest frequency of predictions, thereby shaping the smoothed classifier $g\left( x\right)$ . To certify the robustness of the smoothed classifier $g\left( x\right)$ against adversarial perturbations within a specific radius $r$ centered around the input $x$ , RS calculates the likelihood of agreement between the base classifier $f\left( x\right)$ and $g\left( x\right)$ when noise is introduced to $x$ . If this likelihood exceeds a certain threshold (e.g., surpassing ${0.5} + \tau$ , where $\tau$ represents a minor positive constant), it indicates the certified robustness of $g\left( x\right)$ within a radius $r$ around $x$ .

随机平滑(RS)(Cohen等，2019)是验证深度语言模型鲁棒性的另一种有前景的技术。其基本思想是在推理过程中利用随机性，创建一个对输入微小扰动更具鲁棒性的平滑分类器。这项技术还可以用来提供在一定半径内对抗性扰动的认证保证。通常，随机平滑从在给定数据集上训练常规神经网络开始。然后，给定一个训练好的基础分类器$f$和一个输入$x$，平滑分类器$g$通过引入随机性(例如高斯噪声)定义为:$g\left( x\right)  = {\operatorname{argmax}}_{c}\mathbb{P}\left( {f\left( {x + \epsilon }\right)  = c}\right)$，其中$\epsilon$是从某个分布(如高斯分布)采样的噪声。在推理阶段，为了对新样本进行分类，会多次从预设的分布中随机采样噪声。这些噪声实例被注入到输入$x$中，形成带噪声的样本。随后，基础分类器$f\left( x\right)$对每个带噪声的样本进行预测。最终的预测由预测频率最高的类别决定，从而形成平滑分类器$g\left( x\right)$。为了认证平滑分类器$g\left( x\right)$在以输入$x$为中心、半径为$r$的范围内对抗性扰动的鲁棒性，RS计算基础分类器$f\left( x\right)$与平滑分类器$g\left( x\right)$在引入噪声时的一致性概率。如果该概率超过某个阈值(例如超过${0.5} + \tau$，其中$\tau$表示一个微小的正数常数)，则表明在以$x$为中心、半径为$r$的范围内，平滑分类器$g\left( x\right)$具有认证的鲁棒性。

![bo_d1m003f7aajc73dif160_25_157_182_1222_560_0.jpg](images/bo_d1m003f7aajc73dif160_25_157_182_1222_560_0.jpg)

Fig. 8 Pipeline of wordDP for word-substitution attack and robustness verification (Wang et al. 2021a)

图8 wordDP的流程图，用于词替换攻击和鲁棒性验证(Wang等，2021a)

Figure 8 depicts one of the pioneering efforts of using RS for verifying the robustness of NLP models. It is called WordDP developed by Wang et al. (2021a), the authors introduced a novel approach to provide a certificate of robustness by leveraging the concept of differential privacy. In this work, the researchers considered a sentence as a database and the individual words within it as records. They demonstrated that if a predictive model satisfies a specific threshold of epsilon-differential privacy for a perturbed input, it can be inferred that the input is identical to the clean, unaltered data. This methodology offers a certification of robustness against L-adversary word substitution attacks. In another recent study, Zeng et al. (2021c) introduced RanMASK, a certifiably robust defence method against text adversarial attacks, which employs a novel randomised smoothing technique specifically tailored for NLP models. The input text is manually perturbed in this approach and subsequently fed into a mask language model. Random masks are then generated within the input text to create a large set of masked copies, which are subsequently classified by a base classifier. A "majority vote" mechanism determines the final robust classification. Furthermore, the researchers utilised pre-trained models such as BERT and RoBERTa to generate and train with the masked inputs, showcasing the practical applicability and effectiveness of the Ran-MASK technique in some real-world NLP scenarios.

图8展示了使用RS(随机平滑)验证NLP(自然语言处理)模型鲁棒性的一项开创性工作。该方法名为WordDP，由王等人(2021a)开发，作者引入了一种利用差分隐私(differential privacy)概念提供鲁棒性证明的创新方法。在这项工作中，研究人员将一句话视为数据库，句子中的单词视为记录。他们证明，如果一个预测模型在扰动输入上满足特定阈值的ε-差分隐私(epsilon-differential privacy)，则可以推断该输入与未被修改的干净数据相同。这一方法为抵抗L-对手(L-adversary)词替换攻击提供了鲁棒性认证。在另一项最新研究中，曾等人(2021c)提出了RanMASK，一种针对文本对抗攻击(adversarial attacks)的可认证鲁棒防御方法，采用一种新颖的随机平滑(randomised smoothing)技术，专为NLP模型量身定制。在该方法中，输入文本通过人工扰动后输入到掩码语言模型(mask language model)。随后在输入文本中随机生成掩码，创建大量掩码副本，再由基础分类器进行分类。通过“多数投票”机制确定最终的鲁棒分类。此外，研究人员还利用预训练模型如BERT和RoBERTa对掩码输入进行生成和训练，展示了RanMASK技术在一些实际NLP场景中的应用潜力和有效性。

### 6.2 Black-box verification

### 6.2 黑盒验证

Many existing verification techniques impose specific requirements on DNNs, such as targeting a specific network category or networks with particular activation functions (Huang et al. 2017). With the increasing complexity and scale of large language models (LLMs), traditional verification methods based on layer-by-layer search, abstraction, and transformation have become computationally impractical. Consequently, we envision that black-box approaches have emerged as a more feasible alternative for verifying such models (Wicker et al. 2018; Wu et al. 2020; Xu et al. 2022).

许多现有的验证技术对深度神经网络(DNNs)提出了特定要求，例如针对特定网络类别或具有特定激活函数的网络(Huang等，2017)。随着大型语言模型(LLMs，Large Language Models)复杂性和规模的不断增加，基于逐层搜索、抽象和变换的传统验证方法变得计算上不可行。因此，我们预见到黑盒(black-box)方法已成为验证此类模型的更可行的替代方案(Wicker等，2018；Wu等，2020；Xu等，2022)。

In the black-box setting, adversaries can only query the target classifier without knowing the underlying model or the feature representations of inputs. Several studies have explored more efficient methods for black-box settings, although most of current approaches focus on vision models (Wicker et al. 2018; Wu et al. 2020; Xu et al. 2022). For instance, DeepGO, a reachability analysis tool, offers provable guarantees for neural networks with deep layers and nonlinear activation functions (Ruan et al. 2018). Its extended version, DeepAgn, is compatible with various networks, including feedforward and recurrent neural networks, as long as they exhibit Lipschitz continuity (Zhang et al. 2023b).

在黑盒环境中，攻击者只能查询目标分类器，而无法了解底层模型或输入的特征表示。一些研究探索了更高效的黑盒验证方法，尽管目前大多数方法集中在视觉模型(vision models)(Wicker等，2018；Wu等，2020；Xu等，2022)。例如，DeepGO是一款可验证深层(deep)神经网络(具有深层结构和非线性激活函数)的可达性分析工具(reachability analysis tool)(Ruan等，2018)。其扩展版本DeepAgn兼容多种网络，包括前馈神经网络(feedforward neural networks)和循环神经网络(recurrent neural networks)，只要它们满足Lipschitz连续性(Lipschitz continuity)(Zhang等，2023b)。

Subsequently, an anytime algorithm was developed to approximate global robustness by iteratively computing lower and upper bounds (Ruan et al. 2019). This algorithm returns intermediate bounds and robustness estimates that improve as computation proceeds. For neural network control systems (NNCSs), the DeepNNC verification framework utilises a black-box optimisation algorithm and demonstrates comparable efficiency and accuracy across a wide range of neural network controllers (Zhang et al. 2023c). GeoRobust, another black-box analyser, efficiently verifies the robustness of large-scale DNNs against geometric transformations (Wang et al. 2023c). This method can identify the worst-case manipulation that minimises adversarial loss without knowledge of the target model's internal structures and has been employed to systematically benchmark the geometric robustness of popular ImageNet classifiers.

随后，开发出一种随时(anytime)算法，通过迭代计算上下界(lower and upper bounds)来逼近全局鲁棒性(global robustness)(Ruan等，2019)。该算法在计算过程中会返回中间的界限和鲁棒性估计，随着时间推移不断改善。对于神经网络控制系统(Neural Network Control Systems, NNCSs)，DeepNNC验证框架利用黑盒优化算法，展示了在各种神经网络控制器中的相当效率和准确性(Zhang等，2023c)。另一个黑盒分析工具GeoRobust高效验证大规模深度神经网络(DNNs)对几何变换(geometric transformations)的鲁棒性(Wang等，2023c)。该方法能够在不知晓目标模型内部结构的情况下，识别最差的操控(manipulation)以最小化对抗性损失(adversarial loss)，并已被用于系统性评估流行的ImageNet分类器的几何鲁棒性。

Recently, some researchers have attempted to develop black-box verification methods for NLP models, although these methods are not scalable to LLMs. For example, one study introduced a framework for evaluating the robustness of NLP models against word substitutions (La Malfa et al. 2020). By computing a lower and upper bound for the maximal safe radius for a given input text, this verification method can guarantee that the model prediction does not change if a word is replaced with a plausible alternative, such as a synonym.

近年来，一些研究者尝试开发面向NLP模型的黑盒验证方法，尽管这些方法尚不能扩展到大型语言模型(LLMs，Large Language Models)。例如，一项研究提出了评估NLP模型对词替换(word substitutions)鲁棒性(La Malfa等，2020)的框架。通过计算给定输入文本的最大安全半径(maximal safe radius)的上下界，该验证方法可以保证模型预测在用合理的替代词(如同义词)替换某个词时不发生变化。

We also notice another thread of works focusing on training verifiers, for the correctness of language-to-code generation (Ni et al. 2023) or solving math word problems (Cobbe et al. 2021).

我们还注意到另一类工作专注于训练验证器(verifiers)，用于确保语言到代码(language-to-code)生成的正确性(Ni等，2023)或解决数学文字题(math word problems)(Cobbe等，2021)。

### 6.3 Robustness evaluation on LLMs

### 6.3 大型语言模型(LLMs)鲁棒性评估

Given the prominence of large-scale language models such as GPT, LLaMA, and BERT, some researchers have recently started exploring the robustness evaluation of these models. One such investigation is the work of Cheng et al. (2020), who developed a seq2seq algorithm based on a projected gradient method combined with group lasso and gradient regu-larisation. To address the challenges posed by the vast output space of LLMs, the authors introduced innovative loss functions to conduct non-overlapping and targeted keyword attacks. Through applications in machine translation and text summarisation tasks, their seq2seq model demonstrated the capability to produce desired outputs with high success rates by altering fewer than three words. The preservation of semantic meanings in the generated adversarial examples was further verified using an external sentiment classifier. Another notable contribution comes from Weng et al. (2022, 2023), as shown in Fig. 9. They proposed a self-verification method that leverages the conclusion of the chain of thought (CoT) as a condition for constructing a new sample. The LLM is then tasked with re-predicting the original conditions, which have been masked. This approach allows for the calculation of an explainable verification score based on accuracy, providing valuable insights into the performance of LLMs. Finally, Jiang et al. (2022) introduced an approach that addresses both auto-formalisation (the translation of informal mathematics into formal logical notation) and the proving of "proof sketches" resulting from the auto-formalisation of informal proofs.

鉴于大型语言模型(如GPT、LLaMA和BERT)的突出表现，部分研究人员最近开始探索这些模型的鲁棒性评估。其中一项研究由Cheng等人(2020)进行，他们基于投影梯度法结合组套索(group lasso)和梯度正则化(gradient regularisation)开发了一种序列到序列(seq2seq)算法。为应对大型语言模型(LLMs)庞大的输出空间带来的挑战，作者引入了创新的损失函数，以进行非重叠且有针对性的关键词攻击。通过在机器翻译和文本摘要任务中的应用，他们的seq2seq模型展示了通过少于三个词的修改即可高成功率地产生预期输出的能力。生成的对抗样本中的语义意义得到了外部情感分类器的验证。另一项重要贡献来自Weng等人(2022，2023)，如图9所示。他们提出了一种自我验证方法，利用链式思维(Chain of Thought, CoT)结论作为构建新样本的条件。随后，LLM被要求重新预测已被掩码的原始条件。这种方法可以基于准确率计算出一种可解释的验证得分，为理解LLMs的性能提供了宝贵的见解。最后，Jiang等人(2022)提出了一种同时解决自动形式化(将非正式数学转化为形式逻辑符号)和自动形式化的非正式证明“证明草图”的方法。

![bo_d1m003f7aajc73dif160_27_156_187_1221_677_0.jpg](images/bo_d1m003f7aajc73dif160_27_156_187_1221_677_0.jpg)

Fig. 9 Example of Self-Verification proposed in Weng et al. (2022). In Stage-1, LLM generates some candidate conclusions. Then LLM verifies these conclusions and counts the number of masked conditions that reasoning is correct to as the verification score in Stage-2

图9 展示了Weng等人(2022)提出的自我验证示例。在第一阶段，大型语言模型(LLM)生成一些候选结论。然后，LLM验证这些结论，并统计推理正确的掩码条件数量，作为第二阶段的验证得分

To the best of our knowledge, there remains a conspicuous absence of research on verifying large language models (LLMs). As such, we encourage the academic community to prioritise this vital research domain by developing practical black-box verification methods tailored specifically to LLMs.

据我们所知，关于验证大型语言模型(LLMs)的研究仍然明显不足。因此，我们鼓励学术界将这一重要研究领域置于优先位置，开发专门针对LLMs的实用黑箱验证方法。

### 6.4 Towards smaller models

### 6.4 迈向更小的模型

The current LLMs are of large scale with billions or trillions of parameters. This will make the verification hard, even with the above-mentioned verification techniques. Another possible thread of research to support the ultimate verification is to use smaller LLMs.

当前的大型语言模型(LLMs)参数规模庞大，达到数十亿或数万亿级别。这将使验证变得困难，即使采用上述验证技术也是如此。支持最终验证的另一种潜在研究方向是使用较小的大型语言模型(LLMs)。

A prevailing strategy of developing a smaller LLM is to apply techniques that reduce the parameters of a pre-trained model. One typical method is model compression, such as quan-tisation (Nagel et al. 2020; Liu et al. 2021c; Frantar and Alistarh 2022). However, directly applying quantisation techniques on LLMs leads to performance degradation. To this end, ZeroQuant (Yao et al. 2022) utilise kernel fusion (Wang et al. 2010) to compress weights and activations before data movement, to maximise memory bandwidth utilisation and speed up inference. Similarly, Park et al. (2022) introduces a new LUT-GEMM kernel that allows quan-tised matrix multiplications with either uniform or non-uniform weight quantisation. Both Wang et al. (2010), Park et al. (2022) require custom CUDA kernels. In contrast, Dettmers et al. (2022) improves predictive performance on billion-scale 8-bit transformers. Frantar et al. (2023) further improves GPT model with near-zero performance drop on 3 or 4-bit precision by deploying Optimal Brain Quantisation (Frantar and Alistarh 2022), Lazy Batch-Updates and Cholesky Reformulation. Other than quantisation techniques, Low-rank adaptation (LORA) (Hu et al. 2022) involves decomposing the weights into low-rank matrices, which has been shown to reduce the number of parameters while maintaining model performance significantly.

开发较小的大型语言模型(LLM)的一种主流策略是应用减少预训练模型参数的技术。一种典型方法是模型压缩，例如量化(Nagel等，2020；Liu等，2021c；Frantar和Alistarh，2022)。然而，直接在大型语言模型上应用量化技术会导致性能下降。为此，ZeroQuant(Yao等，2022)利用核融合(Wang等，2010)在数据传输前压缩权重和激活，以最大化内存带宽利用率并加快推理速度。类似地，Park等(2022)引入了一种新的LUT-GEMM内核，支持均匀或非均匀权重量化的矩阵乘法。Wang等(2010)和Park等(2022)都需要定制的CUDA内核。相比之下，Dettmers等(2022)提升了十亿尺度8位变换器(transformer)的预测性能。Frantar等(2023)通过部署最优脑量化(Optimal Brain Quantisation，Frantar和Alistarh，2022)、懒惰批次更新(Lazy Batch-Updates)和Cholesky重构，进一步在3或4位精度下实现几乎零性能损失的GPT模型优化。除了量化技术外，低秩适应(LORA，Hu等，2022)通过将权重分解为低秩矩阵，已被证明能显著减少参数数量，同时保持模型性能。

Knowledge distillation refers to the methodology wherein a streamlined "student" model is trained to approximate the predictive behavior of a more complex "teacher" model (Hinton et al. 2015). This is achieved by leveraging both the ground-truth labels and the teacher model's soft predictions during the training process (Cho and Hariharan 2019; Tung and Mori 2019). The training process enables the student model to assimilate the implicit knowledge encapsulated by the teacher model with less parameters. Specifically, the student model achieves performance similar to the teacher model while being more computationally efficient, making it suitable for deployment in resource-limited settings (Gou et al. 2021; He et al. 2022). In LLMs, the small student model is often used to assimilate information from the pre-trained teacher model (Taori et al. 2023; Chiang et al. 2023; Wu et al. 2023d; Peng et al. 2023; Gu et al. 2023a). This multifaceted transfer of knowledge enables the student model to augment its capabilities in language understanding and generation, which particularly advantageous for deployment in computational environments where resource efficiency is a critical consideration. The "teacher" neural network is trained on extensive text data for various language tasks, such as understanding, generation, translation, and sentiment analysis, and the "student" model, designed to be more resource-efficient, aims to replicate the teacher model's capabilities while using fewer layers and neurons or a simplified architecture. The goal is to achieve comparable performance but with reduced computational overhead.

知识蒸馏是指一种方法，通过训练一个简化的“学生”模型以逼近更复杂的“教师”模型(Hinton等，2015)的预测行为。在训练过程中，利用真实标签和教师模型的软预测(Cho和Hariharan，2019；Tung和Mori，2019)实现这一目标。该训练过程使学生模型能够吸收教师模型所蕴含的隐性知识，参数更少。具体而言，学生模型在性能上接近教师模型，同时具有更高的计算效率，适合在资源有限的环境中部署(Gou等，2021；He等，2022)。在大型语言模型(LLMs)中，常用较小的学生模型来吸收预训练教师模型的信息(Taori等，2023；Chiang等，2023；Wu等，2023d；Peng等，2023；Gu等，2023a)。这种多方面的知识迁移使学生模型能够增强其在语言理解和生成方面的能力，这对于在资源效率至关重要的计算环境中部署尤为有利。教师神经网络在大量文本数据上进行训练，完成理解、生成、翻译和情感分析等多种语言任务，而设计为更节省资源的学生模型旨在复制教师模型的能力，同时减少层数和神经元或采用简化架构。目标是实现性能相当，但计算开销更低。

It is worth noting that Spiking Neural Networks (SNNs), as the third generation neural networks, offer a complementary approach to improve computing efficiency, e.g., utilising sparse operation (Rueckauer et al. 2017; Wu et al. 2022b, 2023b). Recent research has introduced SpikeGPT (Zhu et al. 2023), the largest SNN-based model with 260 million parameters, to demonstrate the performance of SNNs on GPT models, comparable to that of traditional neural networks. In contrast, SNNs require implementation on specialised hardware, such as neu-romorphic chips like TrueNorth (Akopyan et al. 2015) and Loihi (Davies et al. 2018), which have been designed to mimic biological neurons at the circuit level. While the development of SNNs on LLM is still in its early stages, it presents an alternative approach to achieving computing efficiency that works parallel to compression techniques.

值得注意的是，脉冲神经网络(SNNs)作为第三代神经网络，提供了一种补充的途径以提高计算效率，例如利用稀疏操作(Rueckauer等，2017；Wu等，2022b，2023b)。近期研究引入了SpikeGPT(Zhu等，2023)，这是最大规模的基于SNN的模型，拥有2.6亿参数，展示了SNN在GPT模型中的性能，媲美传统神经网络。相比之下，SNN需要在专用硬件上实现，如类神经形态芯片TrueNorth(Akopyan等，2015)和Loihi(Davies等，2018)，这些芯片设计旨在模拟生物神经元的电路层面。虽然SNN在大型语言模型(LLMs)上的发展仍处于早期阶段，但它提供了一种与压缩技术平行的实现计算效率的替代方案。

## 7 Runtime monitor

## 7 运行时监控

Guardrails mentioned in Sect. 2.3.2 provide a safeguard for the LLMs to interact with the end users while retaining its social responsibility. This section discusses a V&V method, i.e., runtime monitor, that is somewhat similar to the guardrails in that, it provides the safeguards on the behaviour of the LLMs against vulnerabilities such as those discussed in Sect. 3. The key motivation for using runtime monitors, rather than the verification, is twofold. First, verification methods require significant computation and hence can become impractical when dealing with large models such as LLMs. Second, a deep learning model might be applied to scenarios different from where the training data is collected. These suggest the need for a runtime monitor to determine the satisfiability of a specification on the fly.

第2.3.2节提到的护栏为大型语言模型(LLMs)与终端用户交互提供了保障，同时保持其社会责任。本节讨论一种验证与确认(V&V)方法，即运行时监控器，它在某种程度上类似于护栏，为LLMs的行为提供保护，防范第3节中讨论的漏洞。使用运行时监控器而非验证的主要动因有两方面。首先，验证方法需要大量计算，当处理如LLMs这样的大模型时，可能变得不切实际。其次，深度学习模型可能应用于与训练数据收集场景不同的场合。这些因素都表明需要一种运行时监控器，以便实时判断规范的满足情况。

Similar to evaluation and verification, there is no existing work on LLMs, but there are proposals for e.g., the convolutional neural networks. Given the missing specifications [(although the attempts to formalise specifications started (Bensalem et al. 2022; Balakrishnan et al. 2019; Huang et al. 2022a)], the current runtime monitoring methods for deep learning start from constructing an abstraction of a property, followed by determining the failure of the property by checking the distance between the abstraction and the original learning model. There are a few existing methods for abstraction of deep learning. For example, in Cheng et al. (2019b), a Boolean abstraction on the ReLU activation pattern of some specific layer is considered and monitored. Conversely of Boolean abstraction, Henzinger et al. (2020) consider box abstractions. In Berthier et al. (2021), a Bayesian network based abstraction, which abstracts hidden features as random variables, is considered.

与评估和验证类似，目前尚无关于LLMs的相关工作，但已有关于卷积神经网络(CNN)等的提案。由于缺乏明确的规范(尽管正式化规范的尝试已开始(Bensalem等，2022；Balakrishnan等，2019；Huang等，2022a))，当前深度学习的运行时监控方法主要从构建属性的抽象开始，然后通过检查抽象与原始学习模型之间的距离来判断属性是否失败。关于深度学习抽象的方法已有一些。例如，Cheng等(2019b)考虑并监控某些特定层的ReLU激活模式的布尔抽象。与布尔抽象相反，Henzinger等(2020)考虑盒子抽象。在Berthier等(2021)中，采用基于贝叶斯网络的抽象，将隐藏特征抽象为随机变量。

The construction of a runtime monitor requires the specification of the failures. Other than direct specifications such as Huang et al. (2022a), which requires additional efforts to convert the formulas into runtime monitors, this can usually be done by collecting a set of failure data and then summarising (through either learning or symbolic reasoning or a combination of them) the relation between failure data and the part of the LLMs to be monitored, e.g., some critical layers of the LLMs or the output (Li et al. 2018b; Cheng et al. 2022).

运行时监控器的构建需要对故障进行规范。除了像Huang等人(2022a)那样的直接规范，这需要额外的努力将公式转换为运行时监控器之外，通常可以通过收集一组故障数据，然后总结(通过学习、符号推理或两者结合)故障数据与待监控的大模型(LLMs)部分之间的关系，例如一些关键层或输出(Li等人，2018b；Cheng等人，2022)来完成。

### 7.1 Monitoring out-of-distribution

### 7.1 监控分布外数据

In the following, we discuss how runtime monitoring techniques have been developed for a specific type of failure, i.e., out of distribution, which suggests that the runtime data is on a different distribution from the training data. It is commonly believed that ML models cannot be reliable when working with data drifted from the training data. Therefore the occurrence of out-of-distribution suggests the existence of risks.

在下文中，我们讨论了针对特定类型故障(即分布外(out of distribution))的运行时监控技术的发展，这种故障表明运行时数据与训练数据来自不同的分布。普遍认为，当数据偏离训练数据时，机器学习(ML)模型的可靠性会受到影响。因此，分布外的出现暗示存在风险。

Neural networks, used in computer vision (CV) or natural language process (NLP) tasks, are known to make overconfident predictions on out-of-distribution (OoD) samples that do not belong to any of the training classes, i.e., in-distribution (ID) data. For security reasons, such inputs and their corresponding predictions must be monitored at runtime, especially for networks deployed in safety-critical applications. Runtime monitoring or detection of out-of-distribution (OoD) samples have been extensively studied in CV (Hen-drycks and Gimpel 2016; DeVries and Taylor 2018; Liang et al. 2018; Ren et al. 2019b; Liu et al. 2020; Yang et al. 2021a). Recently, researchers have paid more attention to this problem for NLP models (Hendrycks et al. 2020), although large-scale language models (ChatGPT) have shown continuous improvement on most adversarial and OoD classification tasks (Wang et al. 2023a). Generally, to monitor OoD samples, one has to devise an ID confidence score function $S\left( \mathbf{x}\right)$ such that an input $\mathbf{x}$ is classified as OoD if the value $S\left( \mathbf{x}\right)$ is less than a predefined threshold $\gamma$ , as shown in Eq. 2.

在计算机视觉(CV)或自然语言处理(NLP)任务中使用的神经网络(Neural networks)已被证明在分布外(OoD)样本上会过度自信地做出预测，这些样本不属于任何训练类别，即分布内(ID)数据。出于安全考虑，必须在运行时监控这些输入及其对应的预测，尤其是在部署于安全关键应用中的网络。关于分布外(OoD)样本的运行时监控或检测已在CV领域(Hen-drycks 和 Gimpel 2016；DeVries 和 Taylor 2018；Liang 等 2018；Ren 等 2019b；Liu 等 2020；Yang 等 2021a)得到广泛研究。近年来，研究者对NLP模型(Hendrycks 等 2020)中的此问题给予了更多关注，尽管大型语言模型(如ChatGPT)在大多数对抗性和分布外(OoD)分类任务中表现出持续改进(Wang 等 2023a)。通常，为了监控分布外(OoD)样本，必须设计一个ID置信度分数函数($S\left( \mathbf{x}\right)$)，使得当输入($\mathbf{x}$)的值($S\left( \mathbf{x}\right)$)低于预设阈值($\gamma$)时，将其分类为分布外(OoD)，如公式2所示。

$$
M\left( \mathbf{x}\right)  = \left\{  \begin{array}{ll} \text{ ID } & \text{ if }S\left( \mathbf{x}\right)  \geq  \gamma \\  \text{ OoD } & \text{ otherwise } \end{array}\right.  \tag{2}
$$

According to what information is used to construct this confidence function $S\left( \mathbf{x}\right)$ , the current OoD monitoring methods for NLP models (Arora et al. 2021; Huang et al. 2020b; Chen et al. 2022, 2023b; Cho et al. 2022; Duan et al. 2022) can be roughly divided into the following three categories.

根据用于构建此置信度函数($S\left( \mathbf{x}\right)$)的信息，当前针对NLP模型的分布外(OoD)监控方法(Arora 等 2021；Huang 等 2020b；Chen 等 2022，2023b；Cho 等 2022；Duan 等 2022)大致可以分为以下三类。

The first category includes input density estimation methods (Ren et al. 2019b; Lee et al. 2020; Gangal et al. 2020; Arora et al. 2021). These methods usually involve a density estimator, either directly in the input space or in the latent space of the generative models for the ID data. The probability value of the input given by such a density estimator can be used as the ID score. One of these examples is Arora et al. (2021) that uses the token perplexity (Lee et al. 2020), avoiding the bias of text length as the ID confidence score.

第一类包括输入密度估计方法(Ren 等 2019b；Lee 等 2020；Gangal 等 2020；Arora 等 2021)。这些方法通常涉及密度估计器，既可以直接在输入空间中，也可以在生成模型的潜在空间中对ID数据进行估计。由此密度估计器给出的输入概率值可以用作ID分数。其中一个例子是Arora等(2021)，他们使用词元困惑度(Lee 等 2020)，避免了文本长度偏差作为ID置信度分数的问题。

The second category includes feature or embedding space approximation methods (Xu et al. 2020b; Podolskiy et al. 2021; Zeng et al. 2021a; Zhou et al. 2021, 2022; Chen et al. 2022). These methods first approximate the seen features by some distribution function, and then use the distance (e.g., Euclidean and Mahalanobis distances) between this distribution and the input feature as the ID confidence score. For instance, Chen et al. (2022) extracts holistic sentence vector embeddings from all intermediate layers and shadow states of all tokens to enhance the general semantics in sentence vectors, thereby improving the performance of OoD text detection algorithms based on feature space distance.

第二类包括特征或嵌入空间近似方法(Xu 等 2020b；Podolskiy 等 2021；Zeng 等 2021a；Zhou 等 2021，2022；Chen 等 2022)。这些方法首先用某个分布函数近似已见特征，然后利用该分布与输入特征之间的距离(如欧几里得距离或马氏距离)作为ID置信度分数。例如，Chen 等(2022)从所有中间层和所有词元的影子状态中提取整体句子向量嵌入，以增强句子向量中的语义信息，从而提升基于特征空间距离的分布外文本检测算法的性能。

The third category includes output confidence calibration methods (Hendrycks et al. 2020; Desai and Durrett 2020; Dan and Roth 2021; Li et al. 2021b; Shen et al. 2021a; Yilmaz and Toraman 2022). These methods use the model's prediction confidence (usually calibrated) as the ID score. The classic is the maximum softmax probability, often used as a strong baseline for $\mathrm{{OoD}}$ detection.

第三类包括输出置信度校准方法(Hendrycks 等 2020；Desai 和 Durrett 2020；Dan 和 Roth 2021；Li 等 2021b；Shen 等 2021a；Yilmaz 和 Toraman 2022)。这些方法使用模型的预测置信度(通常经过校准)作为ID分数。经典的方法是最大softmax概率，常用作分布外($\mathrm{{OoD}}$)检测的强基线。

Despite a lot of work and effort, the current results can still be improved. Moreover, no single method is better than the other at present, which is understandable, given the infinity of OoD data and the ambiguous boundaries of ID data. In terms of performance, the methods mentioned above do not entail significant overhead, as they all involve a single computation of a function related to high-dimensional vectors, which can be accomplished within a short timeframe. When compared to the time required for a single inference of a neural network, this overhead can be considered negligible.

尽管已有大量工作和努力，但目前的结果仍有提升空间。此外，目前没有一种方法优于其他方法，这是可以理解的，因为分布外(OoD)数据无限，ID数据的边界也模糊。在性能方面，上述方法的开销并不大，因为它们都涉及对高维向量相关函数的单次计算，这可以在短时间内完成。与神经网络单次推理所需的时间相比，这种开销可以视为微不足道。

Finally, we remark that OoD detection task in the field of NLP still requires greater efforts in the following two aspects. First, the community ought to reach a consensus on a fine-grained definition of the OoD problem for NLP models, by precisely considering the sources of OoD data and the tasks of NLP models. For example, existing work is done on NLP classification tasks. How to define the OoD problem for the generative NLP models, e.g., what kind of data should be called OoD data to these generative models? Second, a fair evaluation method is needed, given the fact that the training datasets for most large language models (LLM) are unavailable, i.e., it is unclear whether the used test dataset for evaluating OoD methods are OoD data to the tested models or not.

最后，我们指出，在自然语言处理(NLP)领域的异常检测(OoD)任务仍需在以下两个方面做出更大努力。首先，社区应就NLP模型的细粒度异常检测定义达成共识，明确考虑异常数据的来源和NLP模型的任务。例如，现有工作主要针对NLP分类任务。如何为生成式(generative)NLP模型定义异常检测问题，例如，哪些数据应被称为对这些生成模型的异常数据？第二，需建立公平的评估方法，鉴于大多数大型语言模型(LLM)的训练数据集不可用，即目前尚不清楚用于评估异常检测方法的测试数据是否对被测试模型而言是异常数据。

### 7.2 Monitoring attacks

### 7.2 监控攻击

In this subsection, we discuss how to detect adversarial and backdoor attacks in real-time. It is possible to detect the backdoor input at runtime, given a set of clean reference dataset. The runtime monitoring for backdoor attack is based on the observation that although backdoor input and target samples from reference dataset are classified the same by the compromised network, the rationale for this classification is different. The network identifies input features that it has learnt correlate to the target class in the case of clean samples from the target class. It identifies features associated with the backdoor trigger in the case of backdoor samples, causing it to identify the input as the target class.

在本节中，我们讨论如何实时检测对抗攻击和后门(backdoor)攻击。基于一组干净的参考数据集，可以在运行时检测后门输入。后门攻击的运行时监控基于以下观察:虽然被破坏的网络对后门输入和参考数据集中的目标样本的分类相同，但其背后的推理依据不同。网络在处理来自目标类别的干净样本时，会识别出与目标类别相关的输入特征；而在处理后门样本时，则会识别出与后门触发器(trigger)相关的特征，从而将输入误判为目标类别。

Based on the above idea, several detection strategies for backdoor input are developed. Activation Clustering (AC) approach is adopted to check the activation similarity between the runtime input and reference dataset (Chen et al. 2019). The activations of last convolutional layer are obtained for reference dataset and input. They are grouped according to the label and each group is clustered separately. To cluster the activations, the dimensionality reduction technique, Independent Component Analysis (ICA) is applied. Then cluster analysis methods, like exclusionary reclassification, relative size comparison and silhouette score can help users identify if the input contains the backdoor trigger. In addition, the feature importance maps generated from XAI techniques can be leveraged to help identify the backdoor input (Huang et al. 2019b; Tejankar et al. 2023). Since the compromised neural network relies on backdoor trigger to make decision, the backdoor trigger is highlighted when generating the feature importance maps regarding the input. Then, the backdoor input can be filtered out when simple and fixed decision logic is summarised from the explanations. While the runtime monitoring of backdoor for LLMs is few, we believe the current techniques can be extended to LLMs once we can get the hidden activation or explanations from LLMs.

基于上述思想，开发了多种后门输入检测策略。采用激活聚类(Activation Clustering, AC)方法，检查运行时输入与参考数据集之间的激活相似性(Chen等，2019)。获取参考数据集和输入的最后卷积层激活值，并根据标签进行分组，每组单独聚类。为进行激活值聚类，采用降维技术——独立成分分析(Independent Component Analysis, ICA)。随后，利用排除性重分类、相对大小比较和轮廓系数等聚类分析方法，帮助用户判断输入是否包含后门触发器。此外，还可以利用由可解释性(XAI)技术生成的特征重要性图，辅助识别后门输入(Huang等，2019b；Tejankar等，2023)。由于被破坏的神经网络依赖后门触发器进行决策，在生成特征重要性图时会突出显示后门触发器。然后，结合简单且固定的决策逻辑，从解释中总结出后门输入的过滤方法。虽然针对大型语言模型(LLM)的运行时后门监控方法较少，但我们相信，一旦能获取LLM的隐藏激活或解释信息，现有技术可以扩展应用到LLM中。

Adversarial examples are thought to exhibit distinguishable features that set them apart from clean inputs (Ilyas et al. 2019). Consequently, we can leverage this distinction to develop a runtime robust detector. For example, uncertainty values are used as features to build a binary classifier as a detector. Feinman et al. (2017) introduced the Bayesian Uncertainty metric, employing Monte Carlo dropout to estimate uncertainty, primarily detecting adversarial examples situated near the class boundaries, while Smith and Gal (2018) utilised a mutual information approach for the same purpose. Furthermore, Hendrycks and Gimpel (2016) demonstrated that softmax prediction probabilities can be used to identify adversarial examples. They appended a decoder to reconstruct clean inputs from the softmax and jointly trained it with the baseline classifier. Following the hypothesis that diverse models exhibit different mistakes when confronted with the same attack inputs, Monteiro et al. (2019) proposed a bimodel mismatch detection. Moreover, Feinman et al. (2017) introduced kernel density estimation for each class within the training data and subsequently trained a binary classifier as a detector, utilising the density and uncertainty features associated with clean, noisy, and adversarial examples. Although there are also few runtime monitoring methods for detecting adversarial examples in LLMs, we believe these current techniques can be extended to LLMs once we can develop an LLM detection model.

对抗样本(adversarial examples)被认为具有与干净输入不同的可辨识特征(Ilyas等，2019)。因此，我们可以利用这一差异开发一种运行时的鲁棒检测器。例如，使用不确定性值作为特征构建二分类器作为检测器。Feinman等(2017)引入了贝叶斯不确定性(Bayesian Uncertainty)指标，利用蒙特卡洛(Monte Carlo)dropout估算不确定性，主要检测接近类别边界的对抗样本；Smith和Gal(2018)则采用互信息(mutual information)方法实现相同目标。此外，Hendrycks和Gimpel(2016)展示了可以利用softmax预测概率识别对抗样本，他们在softmax基础上添加解码器以重建干净输入，并与基础分类器共同训练。基于不同模型在面对相同攻击输入时会出现不同错误的假设，Monteiro等(2019)提出了双模型不匹配检测。此外，Feinman等(2017)还引入了每个类别的核密度估计(kernel density estimation)，并训练了二分类器作为检测器，利用与干净、噪声和对抗样本相关的密度和不确定性特征。虽然针对LLMs(大型语言模型)检测对抗样本的运行时方法较少，但我们相信，一旦开发出适用于LLMs的检测模型，这些技术也可以得到扩展。

### 7.3 Monitoring output failures

### 7.3 监控输出失败

As we mentioned in previous sections, although LLMs have shown strong performance in many domains (Bang et al. 2023; Liu et al. 2023a; Jiao et al. 2023; Sobania et al. 2023; Zhong et al. 2023), they are also found to be prone to various types of failures after scrutiny and evaluation (Borji 2023; Shen et al. 2023; Zhao et al. 2023b), such as factual errors (Zhao et al. 2023b), coding (Liu et al. 2023c; Khoury et al. 2023), math (Frieder et al. 2023), and reasoning (Liu et al. 2023b). These failures can spell fatal disaster for downstream tasks, especially in safety-critical applications. To address these issues, one way is to devise a mechanism to generate constrained outputs (Hu et al. 2017; Kumar et al. 2020; Madaan et al. 2021). However, LLMs generate output by selecting appropriate words from a vocabulary rather than grabbing corresponding snippets from sources of truth, or reasoning on them. This generative nature makes it challenging to control the output, and even more challenging to ensure that the generated output is, in fact, consistent with the information source. Another way is to monitor the output of the models and take necessary actions. In the following, we first summarise the limited amount of existing work on runtime monitoring of such failures and then discuss how to proceed from a future perspective.

正如我们在前几节提到的，尽管大型语言模型(LLMs)在许多领域表现出色(Bang等，2023；Liu等，2023a；Jiao等，2023；Sobania等，2023；Zhong等，2023)，但经过审查和评估后发现它们也容易出现各种类型的失败(Borji，2023；Shen等，2023；Zhao等，2023b)，例如事实性错误(Zhao等，2023b)、编码(Liu等，2023c；Khoury等，2023)、数学(Frieder等，2023)和推理(Liu等，2023b)。这些失败可能对下游任务造成致命的影响，尤其是在安全关键的应用中。为了解决这些问题，一种方法是设计机制以生成受约束的输出(Hu等，2017；Kumar等，2020；Madaan等，2021)。然而，LLMs生成输出的方式是从词汇表中选择合适的词，而不是从真实源中提取对应片段或对其进行推理。这种生成性质使得控制输出变得具有挑战性，更难确保生成的内容实际上与信息源一致。另一种方法是监控模型的输出并采取必要的措施。以下，我们首先总结现有关于此类失败的运行时监控的有限研究，然后讨论未来的研究方向。

In addition to the generative nature of LLMs, the diversity of downstream tasks also makes it extremely difficult, if not impossible, to have a general monitoring framework for such generative outputs. Such output failures need to be addressed in a targeted manner, according to different application scenarios and the specific scientific knowledge accumulated by humans in various fields such as science and technology. Regarding factual errors, Thorne et al. (2018) proposed a testbed for fact verification. However, this remains an unsolved challenge. Similar to fact-checking, we argue that for code generation failures, the fruitful methods, techniques, and tools accumulated in the field of formal methods related to compilers design (Lam et al. 2006) and program verification (Vardi and Wolper 1986) can be adapted to check whether the generated code is executable or satisfies some specified invariants (Manna and Pnueli 2012; Bensalem et al. 1996, 1998), respectively. As for math-related failures, existing tools in automated theorem proving (Fitting 1996; Bibel 2013) [e.g., Z3 (De Moura and Bjørner 2008) and Prover9 (McCune 2005)] may help. If an LLM is employed within safety-critical systems and its outputs are required to adhere to specified system safety properties, then a combination of traditional runtime monitoring and enforcement techniques (Bauer et al. 2011; Bartocci and Falcone 2018), along with those (Garcia and Fernández 2015; Alshiekh et al. 2018; Jansen et al. 2018, 2020; Gu et al. 2022) specifically developed for safe reinforcement learning, can be put into action. This allows to detect in real-time whether the model's outputs violate predefined behavioural specifications and enforce corrective actions on the model's outputs to ensure the safe operation of the system.

除了LLMs的生成特性外，下游任务的多样性也使得为此类生成输出建立通用监控框架变得极其困难，甚至不可能。这些输出失败需要根据不同的应用场景和人类在科学技术等各个领域积累的具体科学知识进行有针对性的处理。关于事实性错误，Thorne等(2018)提出了一个事实验证的测试平台，但这一挑战仍未解决。类似于事实核查，我们认为在代码生成失败方面，可以借鉴与编译器设计(Lam等，2006)和程序验证(Vardi和Wolper，1986)相关的形式方法领域中积累的有效方法、技术和工具，用于检查生成的代码是否可执行或满足某些特定的不变量(Manna和Pnueli，2012；Bensalem等，1996、1998)。至于数学相关的失败，现有的自动定理证明工具(Fitting，1996；Bibel，2013)[例如Z3(De Moura和Bjørner，2008)和Prover9(McCune，2005)]可能会有所帮助。如果在安全关键系统中使用LLM，并且其输出需要符合特定的系统安全属性，则可以结合传统的运行时监控和执行技术(Bauer等，2011；Bartocci和Falcone，2018)，以及专门为安全强化学习开发的技术(Garcia和Fernández，2015；Alshiekh等，2018；Jansen等，2018、2020；Gu等，2022)，以实现实时检测模型输出是否违反预定义的行为规范，并对模型输出进行强制修正，以确保系统的安全运行。

In order to conduct runtime monitoring for the aforementioned output errors, substantial offline or online overheads are incurred. This is due to the requirement of establishing an auxiliary system aimed at efficiently detecting a range of output anomalies in the model.

为了对上述输出错误进行运行时监控，会带来大量的离线或在线开销。这是因为需要建立一个辅助系统，旨在高效检测模型中的各种输出异常。

Finally, we point out that the current research on the output failures of large-scale language models is still blank. More research is needed, such as configuring a runtime monitor for the output of a specific application, or combining symbolic reasoning and causal reasoning with the model's learning process to ensure that the output avoids failures from the source.

最后，我们指出，目前关于大规模语言模型(LLMs)输出失败的研究仍然空白。需要更多的研究，例如为特定应用配置运行时监控器，或将符号推理和因果推理与模型的学习过程相结合，以确保输出源头避免失败。

### 7.4 Perspective

### 7.4 未来展望

Since LLMs are still in their infancy and have many known vulnerabilities, monitoring these models in real time is a longstanding challenge. In this section, we outline topics for future work to call on more researchers to address this challenge from three perspectives: why, what, and how.

由于LLMs仍处于起步阶段，存在许多已知的漏洞，实时监控这些模型一直是一个长期挑战。在本节中，我们提出未来的研究方向，呼吁更多研究人员从“为什么”、“什么”和“如何”三个角度共同应对这一挑战。

Why does a model need to be monitored? The first thing we want to highlight is whether at some point the LLMs can be trained intelligent enough, so that there is no need to design a separate runtime monitor for these models. For instance, the model is endowed with abilities to automatically detect "illegal inputs" (e.g., out-of-distribution inputs) and guarantee the correctness of its outputs. From our authors' perspective, achieving such level of intelligent models in the foreseeable future is very difficult, if not impossible. The main reasons are as follows. Existing LLMs are still learned from observations, i.e., a training dataset containing partial information. There is no evidence that current learning methods can infer from parts to wholes, even in the case of massive data, nor is there evidence that a training dataset captures all the information. Furthermore, existing learning methods do not characterize their generalization bounds but instead measure the so-called generalization error, which prevents the identification of "illegal inputs". Therefore, it is necessary to monitor the model in real-time.

为什么需要对模型进行监控？我们首先要强调的是，是否有可能在某个阶段使得大型语言模型(LLMs)变得足够智能，以至于无需为这些模型设计单独的运行时监控。例如，模型具备自动检测“非法输入”(如分布外输入)并保证输出正确性的能力。从我们作者的角度来看，在可预见的未来实现如此智能水平的模型是非常困难的，甚至不可能。主要原因如下。现有的大型语言模型仍然是通过观察学习的，即训练数据集包含部分信息。没有证据表明当前的学习方法能够从部分推断出整体，即使在大量数据的情况下，也没有证据表明训练数据集能捕获所有信息。此外，现有的学习方法并不描述其泛化界限，而是测量所谓的泛化误差，这阻碍了“非法输入”的识别。因此，有必要对模型进行实时监控。

What should be monitored? One needs to overcome various vulnerabilities listed in Sect. 3 to reliably use LLMs in safety-critical applications. Equipping the model with a corresponding runtime monitor provides a possible solution complementary to offline verification methods. For example, there have been some works on monitoring whether the model's prediction is made for out-of-distribution inputs and whether the model's output is consistent with some existing fact base. However, to our knowledge, there is no monitoring work on other output failures, e.g., reasoning and code errors; on intended attacks, e.g., robustness, backdoor, and data poisoning. Thus, we call on researchers and practitioners to investigate more in these topics.

需要监控什么？为了在安全关键应用中可靠地使用大型语言模型(LLMs)，需要克服第3节中列出的各种漏洞。为模型配备相应的运行时监控提供了一种补充离线验证方法的可能解决方案。例如，已有一些工作关注监测模型预测是否针对分布外输入，以及模型输出是否与某些现有事实库一致。然而，据我们所知，目前还没有关于其他输出故障的监测工作，例如推理错误和代码错误；也没有关于有意攻击的监测，例如鲁棒性、后门和数据污染。因此，我们呼吁研究人员和从业者在这些主题上进行更多的研究。

How to better design a monitor for a model? The state-of-the-art methods are based on the uncertainty model's predictions. Unfortunately, low uncertainty cannot assure the model's prediction is reliable, and vice versa. To better design monitors for LLMs, we need the following efforts. First, some fundamental intrinsic issues of deep learning models must be better addressed, such as model implicit generalisation and decision boundaries and explainability of model decisions, which may provide more rigorous and formal characterisation and specification for building monitors. Specific to LLMs, some special issues need to be tackled, such as the unavailability of training datasets, the non-transparency of models, the generative nature of multi-modality, etc. Regarding specific tasks, such as the most studied problem of monitoring out-of-distribution inputs, principled methods for system design and evaluation of monitors still needs to be included, as current work is based on calibration of predictive confidence scores and evaluation on one-sided test datasets. Last, we call for great attention to unexplored topics, such as how to monitor other trustworthiness and responsibility issues, attacks, and unintended bugs, along with the model's social and ethical alignments with human society.

如何更好地设计模型的监控器？目前的先进方法主要基于不确定性模型的预测。不幸的是，低不确定性并不能保证模型预测的可靠性，反之亦然。为了更好地设计大型语言模型(LLMs)的监控器，我们需要以下努力。首先，必须更好地解决深度学习模型的一些根本内在问题，例如模型的隐式泛化、决策边界以及模型决策的可解释性，这些可能为构建监控器提供更严格和正式的描述与规范。针对大型语言模型(LLMs)，还需解决一些特殊问题，如训练数据集的不可用性、模型的不透明性、多模态的生成特性等。关于具体任务，例如监测分布外输入这一研究最多的问题，系统设计和监控器评估的原则性方法仍需完善，因为目前的工作主要基于预测置信度分数的校准和在单边测试数据集上的评估。最后，我们呼吁关注一些尚未充分探索的主题，例如如何监控模型的其他可信度和责任问题、攻击以及意外的漏洞，同时考虑模型与人类社会的社会和伦理一致性。

## 8 Regulations and ethical use

## 8 规章与伦理使用

$\mathrm{V}\& \mathrm{V}$ provides a set of technical means to support the alignment of LLMs with human interests. However, it has been argued that constructing LLMs that cannot be abused can be impossible. This suggests that technical means are necessary, but can be insufficient. To this end, it is needed to have ethical means, to supplement the technical means, in ensuring that the complete alignment of the use of LLMs with human interests. In the following, we discuss several recent signs of progress.

$\mathrm{V}\& \mathrm{V}$ 提供了一套技术手段，以支持大型语言模型(LLMs)与人类利益的对齐。然而，有人认为，构建无法被滥用的LLMs可能是不可能的。这表明，技术手段是必要的，但可能不够。为此，需要伦理手段来补充技术手段，确保LLMs的使用完全符合人类利益。以下，我们将讨论一些近期的进展迹象。

### 8.1 Regulate or ban?

### 8.1 规制还是禁令？

A recent debate on "a 6-month suspension on the development (https://futureoflife.org/ open-letter/pause-giant-ai-experiments/) vs. a regulated development" has shown the anxiety of, and the difference of opinions from, the community upon the possibilities of AI development being misaligned with human interests. More radical actions have also been taken. For example, Italy has reportedly banned the ChatGPT (https://www.cnbc.com/ 2023/04/04/italy-has-banned-chatgpt-heres-what-other-countries-are-doing.html). In a US Senate Hearing on May 2023, OpenAI CEO Sam Altman asked the government to regulate AI (Senate 2023). Actually, on AI regulations, major players such as the EU, US, UK, and China all have their respective approaches and initiatives, e.g., the EU's GDPR (2016), AI Act (https://artificialintelligenceact.eu).Data Act (https://ec.europa.eu/commi ssion/presscorner/detail/en/ip_22_1113), the UK's Data Protection Act (https://www.legis lation.gov.uk/ukpga/2018/12/contents/enacted) and pro-innovative approach to regulate AI (https://assets.publishing.service.gov.uk/government/uploads/system/uploads/attachment_ data/file/1146542/a_pro-innovation_approach_to_AI_regulation.pdf), the US's Blueprint for an AI Bill of Rights (https://www.whitehouse.gov/ostp/ai-bill-of-rights/) and AI Risk Management Framework (https://www.nist.gov/itl/ai-risk-management-framework), and China's regulations for recommendation algorithms (http://www.cac.gov.cn/2022-01/ 04/c_1642894606258238.htm), deep synthesis (https://www.chinalawtranslate.com/en/ deep-synthesis/), and algorithm registry (https://beian.cac.gov.cn/#/index).It is unclear (1) whether these regulations on the more general AI/ML, or other AI/ML algorithms, can automatically work for LLMs without any changes, and (2) how the regulations can be projected onto each other in a rigorous, yet operational, way. More importantly, even for general AI/ML, it still needs to be clarified how to sufficiently and effectively address regulatory requirements (such as robustness and transparency) with technical means. The V&V framework proposed in this survey will be one viable solution.

近期关于“暂停六个月(https://futureoflife.org/open-letter/pause-giant-ai-experiments/)开发(https://futureoflife.org/ open-letter/pause-giant-ai-experiments/)”与“受监管开发”的辩论，显示出社区对人工智能(AI)发展可能偏离人类利益的担忧和不同意见。也采取了更激进的措施。例如，意大利据报道已禁止使用ChatGPT(https://www.cnbc.com/2023/04/04/italy-has-banned-chatgpt-heres-what-other-countries-are-doing.html)。在2023年5月的美国参议院听证会上，OpenAI首席执行官山姆·奥特曼(Sam Altman)呼吁政府对AI进行监管(参议院2023)。实际上，关于AI监管，欧盟、美国、英国和中国等主要国家和地区都采取了各自的措施和倡议，例如欧盟的通用数据保护条例(GDPR，2016)、人工智能法案(https://artificialintelligenceact.eu)、数据法案(https://ec.europa.eu/commission/presscorner/detail/en/ip_22_1113)、英国的数据保护法(https://www.legislation.gov.uk/ukpga/2018/12/contents/enacted)以及鼓励创新的AI监管方法(https://assets.publishing.service.gov.uk/government/uploads/system/uploads/attachment_data/file/1146542/a_pro-innovation_approach_to_AI_regulation.pdf)、美国的《人工智能权利法案蓝图》(https://www.whitehouse.gov/ostp/ai-bill-of-rights/)和AI风险管理框架(https://www.nist.gov/itl/ai-risk-management-framework)，以及中国关于推荐算法(http://www.cac.gov.cn/2022-01/04/c_1642894606258238.htm)、深度合成(https://www.chinalawtranslate.com/en/deep-synthesis/)和算法注册(https://beian.cac.gov.cn/#/index)的法规。尚不清楚(1)这些关于更广泛AI/ML或其他AI/ML算法的法规是否能自动适用于大型语言模型(LLMs)，无需任何修改，以及(2)如何以严谨而又可操作的方式将这些法规相互映射。更重要的是，即使是针对一般AI/ML，也仍需明确如何通过技术手段充分且有效地满足监管要求(如鲁棒性和透明性)。本文提出的验证与确认(V&V)框架将是一个可行的解决方案。

Nevertheless, significant issues raised by the LLMs, notably the ChatGPT, include copyright and privacy. The ChatGPT developers reportedly use data from the internet, and it is unclear if the copyrights of the training data have been carefully dealt with, especially when the ChatGPT is eventually for commercial use. Moreover, as a conversational AI, the privacy of the end users, when engaged in a dialogue, is a serious concern. The end-users should be informed on whether and how their dialogues will be stored, used, and redistributed.

然而，LLMs(如ChatGPT)引发的重大问题包括版权和隐私。据报道，ChatGPT的开发者使用了来自互联网的数据，目前尚不清楚训练数据的版权问题是否已得到妥善处理，尤其是在ChatGPT最终用于商业用途时。此外，作为一种对话式人工智能，用户在对话中的隐私也是一个严重关切。最终用户应被告知其对话内容是否以及如何被存储、使用和再分发。

### 8.2 Responsible AI principles

### 8.2 负责任的AI原则

Responsible and accountable AI has been a topic of discussion for the past years (see e.g., https://ec.europa.eu/futurium/en/ai-alliance-consultation.1.html, https://www.microsoft.com/en-us/ai/responsible-ai, https://www.turing.ac.uk/news/publications/understanding-artificial-intelligence-ethics-and-safety.), with a gradual convergence to include properties such as transparency, explainability, fairness, robustness, security, privacy, etc. A governance framework is called for to ensure that these properties are implemented, evaluated, and monitored. A comprehensive discussion and comparison is out of the scope of this survey, but we note that, many properties are required, consistent definitions to many of them are still missing, and properties can be conflicting (i.e., the improvement of one property may compromise others). It is therefore not surprising that it can still be a long way to turn the principles into operational rules.

负责任且可追溯的AI已成为近年来讨论的主题(参见例如https://ec.europa.eu/futurium/en/ai-alliance-consultation.1.html、https://www.microsoft.com/en-us/ai/responsible-ai、https://www.turing.ac.uk/news/publications/understanding-artificial-intelligence-ethics-and-safety.)，逐渐趋向包括透明性、可解释性、公平性、鲁棒性、安全性、隐私等属性。需要建立治理框架，以确保这些属性的实施、评估和监控。全面的讨论和比较超出本调查范围，但我们注意到，许多属性是必需的，许多属性的定义仍不统一，且属性之间可能存在冲突(即改善某一属性可能会损害其他属性)。因此，将原则转化为可操作规则仍然是一段漫长的道路也不足为奇。

Specific to LLMs, ChatGPT and the like have led to severe concerns on e.g., potential misuse, unintended bias, and fair access. To this end, on the enterprise level, ethical principles are needed to guide the development and use of LLMs, including questioning whether something should be done rather than whether it can be done, as requested in https://www.nature.com/articles/d41586-023-00191-1.Moreover, systematic research is also called for to understand the certain to which the misuse of LLMs can lead to bad consequence, as is done in Botacin (2023) on attackers generating malware with LLMs or in Sandoval et al. (2023) which discusses the security implication of using LLMs in generating codes.

针对LLMs(如ChatGPT)等，已引发对潜在滥用、无意偏见和公平访问等严重关切。为此，在企业层面，需要伦理原则指导LLMs的开发和使用，包括质疑“是否应当做某事”而非“是否能做得到”，正如https://www.nature.com/articles/d41586-023-00191-1中所要求的。此外，还需要系统性研究，以理解滥用LLMs可能导致的严重后果，正如Botacin(2023)中关于攻击者利用LLMs生成恶意软件的研究，或Sandoval等(2023)中关于使用LLMs生成代码的安全影响的讨论。

### 8.3 Educational challenges

### 8.3 教育挑战

Verification and validation of safe and trustworthy AI models are not central to the computer science curriculum or data science curricula. When validation and verification of models are taught at all, it is often part of an AI course that emphasizes tinkering with testing data-set rather than as a systematic and rigorous discipline with a solid scientific foundation. We need a curriculum beyond traditional education, covering formal verification, statistics, and XAI.

安全可靠的人工智能(AI)模型的验证与确认并不是计算机科学课程或数据科学课程的核心内容。当验证和确认模型的内容被教授时，通常是作为强调测试数据集调试的人工智能课程的一部分，而不是作为具有坚实科学基础的系统性和严谨学科。我们需要超越传统教育的课程，涵盖形式验证、统计学和可解释人工智能(XAI)等内容。

This need for adequately trained engineers impacts industrial practice, creating inefficiencies and difficulties in building AI systems with safety guarantees. Engineers untrained in safety and trustworthy AI models are often asked to make AI models for AI-critical applications.

这一对经过充分培训的工程师的需求影响着工业实践，造成了在构建具有安全保障的人工智能系统方面的低效和困难。缺乏安全性和可信赖性人工智能模型培训的工程师，常被要求为关键应用开发人工智能模型。

The need for a shared cultural background between AI and rigorous design communities results in fragmented research. They use different terminologies. For example, "trustworthiness" does not have the same meaning across communities. Conferences are separate, no interaction between the two communities. The educational system will take time to adapt to evolving industrial and cultural needs. At the least, we suggest introducing AI students to the rigorous and systematic analysis of safety and trust and the corresponding approaches to the design of AI-critical applications. Another short-term objective should be to define and promote a reference curriculum in computer science with an optional program for designing safe and trusted AI applications.

人工智能(AI)与严谨设计(rigorous design)社区之间共享文化背景的需求，导致研究碎片化。它们使用不同的术语。例如，“可信度”(trustworthiness)在不同社区中含义不同。会议也各自独立，缺乏交流。教育体系需要时间适应不断变化的工业和文化需求。至少，我们建议引导人工智能专业学生进行安全性和可信性系统分析的严谨方法学习，以及相应的关键应用设计方法。另一个短期目标是制定并推广一份计算机科学的参考课程，包含设计安全可信人工智能应用的可选课程。

### 8.4 Transparency and explainability

### 8.4 透明性与可解释性

First, OpenAI's decision to not open-source GPT-3 and beyond has already led to concerns on the transparent development of AI. However, OpenAI said it plans to make more technical details available to other third parties for them to advise on how to weigh the competitive and safety considerations against the scientific value of further transparency. Nevertheless, we have seen a trend of open-sourcing LLMs, with notably Meta's Llama 2 (Touvron et al. 2023). It is also important to note that, no technical details are available on how the guardrail is designed and implemented. It will also be interesting to discuss on whether the guardrail itself should undergo a verification process.

首先，OpenAI决定不对GPT-3及其后续模型开源，已引发关于人工智能开发透明度的担忧。然而，OpenAI表示计划向第三方提供更多技术细节，以便他们就如何权衡竞争与安全考虑以及进一步透明的科学价值提供建议。尽管如此，我们已看到开源大型语言模型(LLMs)的趋势，例如Meta的Llama 2(Touvron等，2023)。还需注意的是，目前尚无关于如何设计和实现安全护栏(guardrail)的技术细节。讨论是否应对护栏本身进行验证，也将是一个有趣的话题。

Second, it has been hard to interpret and explain the decisions of the deep learning models such as image classifiers. The situation becomes worsens when dealing with LLMs (Kambhampati 2022), which have emergent and hard-to-explain behaviours. For example, it has been observed that adding an incarnation, such as "Let's think step by step", to the prompt can achieve improved responses from GPT-3. Techniques are needed to explain such a phenomenon. This calls for extending explainable AI techniques to work with LLMs. In particular, it is necessary to consider the explanations' robustness to explain why such incarnation can lead to improved, yet different, answers. To this end, some prior works on image classifiers, such as Zhao et al. (2021a), Huang et al. (2022c), can be considered.

其次，解释和理解深度学习模型(如图像分类器)的决策一直很困难。当涉及到大型语言模型(Kambhampati，2022)时，情况变得更为复杂，因为它们具有新兴且难以解释的行为。例如，观察到在提示中加入“让我们一步步思考”这样的表达，可以改善GPT-3的响应。需要开发技术来解释这种现象。这就要求将可解释人工智能(XAI)技术扩展到与大型语言模型(LLMs)配合使用。特别是，要考虑解释的鲁棒性，解释为何这种表达能带来更好但不同的答案。为此，可以参考一些关于图像分类器的前期研究，如Zhao等(2021a)、Huang等(2022c)。

## 9 Discussions

## 9 讨论

The safety and trustworthiness issues become more important with the wider adoption of machine learning, especially for LLMs, with which a large number of end users have direct interactions. Research has been significantly lagged behind, partly due to the fact that some issues become more significant for LLMs than they are for the usual machine learning models. The following are an incomplete list of research directions that we believe require significant investments in the near future.

随着机器学习的广泛应用，尤其是大型语言模型(LLMs)，其安全性和可信度问题变得更加重要，因为大量终端用户与之直接交互。相关研究明显滞后，部分原因在于某些问题对LLMs的重要性超过了传统机器学习模型。以下是我们认为在不久的将来需要大量投入的研究方向的不完整列表。

- Data privacy. For usual machine learning models, their training data are obtained beforehand, with many of them being made available to the public. Notable examples include the ImageNet dataset. That is, the privacy and copyright issues for the training data were not as serious. However, LLMs' training data come directly from the internet, many of which are private information and do not have the authori-sations from the data owners. On top of this, various techniques, such as prompt injection and privacy attacks, are available to leak the information. It requires a multi-disciplinary approach to deal with the data privacy issue.

- 数据隐私。对于普通的机器学习模型，其训练数据提前获得，且许多已向公众开放。例如ImageNet数据集。也就是说，训练数据的隐私和版权问题并不严重。然而，LLMs的训练数据直接来自互联网，其中许多是私人信息，未经数据所有者授权。此外，提示注入(prompt injection)和隐私攻击等多种技术也可能泄露信息。解决数据隐私问题需要多学科的合作方法。

- Safety and trustworthiness implications. Currently, research is focused on tricking the LLMs to generate unexpected outcomes. There needs to be systematic approaches to study and measure the certain to which such unexpected outcomes might lead to bad consequences. This requires the modelling of the environment (e.g., an organisation) in which the LLMs are used, including how they are used and the consequences of all possible outcomes. A systematic study will enable the understanding of which aspects of alignments are needed and how to fine-tune the LLMs to different applications domains.

- 安全性与可信度影响。目前的研究主要集中在欺骗LLMs以生成意外结果。需要系统性的方法来研究和衡量这些意外结果可能带来的不良后果。这要求对使用环境(如组织)进行建模，包括其使用方式和所有可能结果的后果。系统性研究将有助于理解哪些方面的对齐(alignment)是必要的，以及如何针对不同应用领域微调(fine-tune)LLMs。

- Rigorous engineering. The LLMs, in its current development, are mostly relying on the massive training data and the exceptional computational power owned by the large tech giants. Its performance currently is measured with various small scale benchmark datasets that are designed for the domain specific aspects of the abilities, for example, the mathematics, the reasoning, and so on. A rigorous engineering approach, by considering the entire development cycle including the evaluation, is needed to support the shifting of the development from extensive mode to intensive mode, and for the benefit of providing assurance cases for the applications of LLMs to safety critical domains.

- 严谨的工程方法。目前的LLMs(大型语言模型)主要依赖于海量的训练数据和大型科技巨头所拥有的卓越计算能力。其性能目前通过针对特定能力领域设计的各种小规模基准数据集进行衡量，例如数学、推理等。需要采用严谨的工程方法，考虑整个开发周期包括评估，以支持从广泛模式向集约模式的转变，并为LLMs在安全关键领域的应用提供保障案例。

- Verification with provable guarantees. Empirical evaluation provides certain evidence about the performance, but cannot be regarded as a rigorous justification, especially in safety critical domains. A mathematically well-founded proof about the performance, e.g., in the form of statistical guarantees such as chain constraint (Bensalem et al. 2023), can be useful for improving the confidence of the users.

- 可证明保证的验证。经验评估提供了关于性能的某些证据，但不能作为严格的依据，尤其在安全关键领域。关于性能的数学基础证明，例如链式约束(Bensalem等，2023)等统计保证形式，能有助于增强用户的信心。

- Regulations and standards. The necessity of regulations has been commonly agreed. However, the regulations do not provide workable measures that are usually recommended in industrial standards. Compliance with regulations and standards is an important part of an assurance case to justify the safety of a product. It is urgent for the community to come up with standards so as to release the full potential of LLMs and AI in general.

- 规章与标准。规章的必要性已被普遍认可。然而，规章通常未提供可行的措施，而工业标准中常建议的措施也有限。遵守规章和标准是保障案例的重要组成部分，用以证明产品的安全性。社区亟需制定标准，以充分释放LLMs和人工智能(AI)的一切潜力。

## 10 Conclusions

## 10 结论

This paper provides an overview of the known vulnerabilities of LLMs, and discusses how the V&V techniques might be adapted to work with them. Given the LLMs are quickly adopted by applications that have direct or indirect interactions with end users, it is imperative that the deployed LLMs undergoes sufficient verdict processes to avoid any undesirable safety and trustworthy consequences. Novel V&V techniques are called for, to deal with the special characteristics of the LLMs such as the nondeterministic behaviours, the model sizes that are significantly larger than the usual machine learning models, the training dataset that is obtained from internet rather than through a careful collection process, etc. Multi-disciplinary development is needed to make sure that all trustworthy issues are fully considered and tackled.

本文概述了LLMs的已知漏洞，并探讨了如何将验证与确认(V&V)技术适应于它们。鉴于LLMs正被迅速应用于与终端用户直接或间接交互的场景，部署的LLMs必须经过充分的验证流程，以避免任何不良的安全性和可信性后果。需要创新的V&V技术，以应对LLMs的特殊特性，如非确定性行为、模型规模远大于普通机器学习模型、训练数据来自互联网而非经过严格收集等。多学科的协作开发是确保所有可信性问题得到充分考虑和解决的关键。

Acknowledgements This project has received funding from the European Union's Horizon 2020 research and innovation programme under Grant Agreement No 956123. It is also financially supported by the U.K. EPSRC through End-to-End Conceptual Guarding of Neural Architectures [EP/T026995/1].

致谢:本项目获得欧盟“地平线2020”研究与创新计划(Horizon 2020)第956123号资助。同时也得到英国工程与物理科学研究委员会(EPSRC)通过“端到端概念保护神经架构(End-to-End Conceptual Guarding of Neural Architectures)”项目(EP/T026995/1)的资金支持。

Author contributions X.H. organises the overall structure and writes several sections of this paper, and others contribute to different sections.

作者贡献:X.H. 负责本文的整体结构组织和部分章节的撰写，其他作者则贡献了不同章节内容。

## Declarations

## 声明

Competing interests The authors declare no competing interests.

利益冲突:作者声明不存在利益冲突。

Open Access This article is licensed under a Creative Commons Attribution 4.0 International License, which permits use, sharing, adaptation, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons licence, and indicate if changes were made. The images or other third party material in this article are included in the article's Creative Commons licence, unless indicated otherwise in a credit line to the material. If material is not included in the article's Creative Commons licence and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder. To view a copy of this licence, visit http://creativecommons.org/licenses/by/4.0/.

开放获取:本文章依据知识共享署名4.0国际许可协议(Creative Commons Attribution 4.0 International License)授权发布，允许在任何媒介或格式下使用、共享、改编、分发和复制，前提是对原作者和来源给予适当的信用，提供许可链接，并注明是否进行了修改。除非在致谢中另有说明，本文中的图片或其他第三方资料也包含在该许可范围内。如果资料未包含在许可中，且您的使用不在法定许可范围内或超出合理使用范围，您需要直接获得版权所有者的许可。访问许可全文请见http://creativecommons.org/licenses/by/4.0/。

## References

## 参考文献

(2004) Quality management systems-process validation guidance. https://www.imdrf.org/sites/default/ files/docs/ghtf/final/sg3/technical-docs/ghtf-sg3-n99-10-2004-qms-process-guidance-04010.pdf. GHTF. Accessed 20 Aug 2023

(2004) 质量管理体系-过程验证指南。https://www.imdrf.org/sites/default/files/docs/ghtf/final/sg3/technical-docs/ghtf-sg3-n99-10-2004-qms-process-guidance-04010.pdf。GHTF。2023年8月20日访问

(2018) Ethics guidelines for trustworthy AI. https://ec.europa.eu/futurium/en/ai-alliance-consultation.1.html.European Commission. Accessed 20 Aug 2023

(2018) 可信赖人工智能伦理指南。https://ec.europa.eu/futurium/en/ai-alliance-consultation.1.html。欧洲委员会。2023年8月20日访问

(2018) The data protection act. https://www.legislation.gov.uk/ukpga/2018/12/contents/enacted.Accessed 20 Aug 2023

(2018) 数据保护法案。https://www.legislation.gov.uk/ukpga/2018/12/contents/enacted。2023年8月20日访问

(2021) China's regulations on the administration of deep synthesis internet information services. https:// www.chinalawtranslate.com/en/deep-synthesis/. Accessed 20 Aug 2023

(2021) 中国深度合成互联网信息服务管理规定。https://www.chinalawtranslate.com/en/deep-synthesis/。2023年8月20日访问

(2022) AI risk management framework. https://www.nist.gov/itl/ai-risk-management-framework.Accessed 20 Aug 2023

(2022) 人工智能风险管理框架。https://www.nist.gov/itl/ai-risk-management-framework。2023年8月20日访问

(2022) China's regulations on recommendation algorithms. http://www.cac.gov.cn/2022-01/04/c_16428 94606258238.htm. Accessed 20 Aug 2023

(2022) 中国关于推荐算法的规定。http://www.cac.gov.cn/2022-01/04/c_16428 94606258238.htm. 2023年8月20日查阅

(2022) Content at scale. https://contentatscale.ai/ai-content-detector/.Accessed 20 Aug 2023

(2022) 大规模内容。https://contentatscale.ai/ai-content-detector/. 2023年8月20日查阅

(2022) Copyleaks. https://copyleaks.com/ai-content-detector.Accessed 20 Aug 2023

(2022) Copyleaks。https://copyleaks.com/ai-content-detector. 2023年8月20日查阅

(2022) New meta AI demo writes racist and inaccurate scientific literature, gets pulled. https://arstechnica.com/information-technology/2022/11/after-controversy-meta-pulls-demo-of-ai-model-that-writes-scientific-papers/.Accessed 20 Aug 2023

(2022) 新的Meta(脸书)AI演示生成种族主义和不准确的科学文献，已被撤下。https://arstechnica.com/information-technology/2022/11/after-controversy-meta-pulls-demo-of-ai-model-that-writes-scientific-papers/. 2023年8月20日查阅

(2022) Originality AI. https://originality.ai.Accessed 20 Aug 2023

(2022) Originality AI。https://originality.ai. 2023年8月20日查阅

(2022) Prompt injection attacks against GPT-3. https://simonwillison.net/2022/Sep/12/prompt-injection/.Accessed 20 Aug 2023

(2022) 针对GPT-3的提示注入攻击。https://simonwillison.net/2022/Sep/12/prompt-injection/. 2023年8月20日查阅

(2023) 'He would still be here': man dies by suicide after talking with AI chatbot, widow says. https://www.vice.com/en/article/pkadgm/man-dies-by-suicide-after-talking-with-ai-chatbot-widow-says.Accessed 23 Aug 2023

(2023) “他还会在这里”:男子与AI聊天机器人交谈后自杀，遗孀称。https://www.vice.com/en/article/pkadgm/man-dies-by-suicide-after-talking-with-ai-chatbot-widow-says. 2023年8月23日查阅

(2023) A pro-innovation approach to AI regulation. https://assets.publishing.service.gov.uk/government/ uploads/system/uploads/attachment_data/file/1146542/a_pro-innovation_approach_to_AI_regulation. pdf. Accessed 20 Aug 2023

(2023) 以创新为导向的AI监管策略。https://assets.publishing.service.gov.uk/government/ uploads/system/uploads/attachment_data/file/1146542/a_pro-innovation_approach_to_AI_regulation. pdf. 2023年8月20日查阅

(2023) Blueprint for an AI bill of rights. https://www.whitehouse.gov/ostp/ai-bill-of-rights/.Accessed 20 Aug 2023

(2023) AI权利宪章蓝图。https://www.whitehouse.gov/ostp/ai-bill-of-rights/. 2023年8月20日查阅

(2023) ChatGPT: get instant answers, find creative inspiration, and learn something new. https://openai.com/chatgpt.Accessed 20 Aug 2023

(2023) ChatGPT:获取即时答案，寻找创意灵感，学习新知识。https://openai.com/chatgpt. 2023年8月20日查阅

(2023) ChatGPT: US lawyer admits using AI for case research. https://www.bbc.co.uk/news/world-us-canada-65735769.Accessed 23 Aug 2023

(2023) ChatGPT:美国律师承认使用AI进行案件研究。https://www.bbc.co.uk/news/world-us-canada-65735769. 2023年8月23日查阅

(2023) China's algorithm registry. https://beian.cac.gov.cn/#/index.Accessed 20 Aug 2023

(2023) 中国算法备案。https://beian.cac.gov.cn/#/index. 2023年8月20日查阅

(2023) EU AI act. https://artificialintelligenceact.eu.Accessed 20 Aug 2023

(2023) 欧盟AI法案。https://artificialintelligenceact.eu. 2023年8月20日查阅

(2023) EU data act. https://ec.europa.eu/commission/presscorner/detail/en/ip_22_1113.Accessed 20 Aug 2023

(2023) 欧盟数据法案。https://ec.europa.eu/commission/presscorner/detail/en/ip_22_1113. 2023年8月20日查阅

(2023) Prompt leaking. https://learnprompting.org/docs/prompt_hacking/leaking.Accessed 20 Aug 2023

(2023) 提示泄露。https://learnprompting.org/docs/prompt_hacking/leaking. 2023年8月20日查阅

(2023) Responsible AI principles from Microsoft. https://www.microsoft.com/en-us/ai/responsible-ai.Accessed 20 Aug 2023

(2023) 微软的负责任AI原则。https://www.microsoft.com/en-us/ai/responsible-ai. 2023年8月20日查阅

(2023) Three Samsung employees reportedly leaked sensitive data to ChatGPT. https://www.engadget.com/ three-samsung-employees-reportedly-leaked-sensitive-data-to-chatgpt-190221114.html. Accessed 20 Aug 2023

(2023) 据报道，三星的三名员工向ChatGPT泄露了敏感数据。https://www.engadget.com/ three-samsung-employees-reportedly-leaked-sensitive-data-to-chatgpt-190221114.html. 2023年8月20日查阅

(2023) Understanding artificial intelligence ethics and safety: a guide for the responsible design and implementation of AI systems in the public sector. https://www.turing.ac.uk/news/publications/understand ing-artificial-intelligence-ethics-and-safety. Accessed 20 Aug 2023

(2023) 理解人工智能伦理与安全:公共部门中负责任的AI系统设计与实施指南。https://www.turing.ac.uk/news/publications/understand ing-artificial-intelligence-ethics-and-safety. 2023年8月20日查阅

Aghakhani H, Dai W, Manoel A, Fernandes X, Kharkar A, Kruegel C, Vigna G, Evans D, Zorn B, Sim R (2023) TrojanPuzzle: covertly poisoning code-suggestion models. arXiv Preprint http://arxiv.org/abs/ 2301.02344

Aghakhani H, Dai W, Manoel A, Fernandes X, Kharkar A, Kruegel C, Vigna G, Evans D, Zorn B, Sim R (2023) TrojanPuzzle:隐秘地污染代码建议模型。arXiv预印本 http://arxiv.org/abs/ 2301.02344

Agrawal M, Hegselmann S, Lang H, Kim Y, Sontag D (2022) Large language models are zero-shot clinical information extractors. arXiv Preprint http://arxiv.org/abs/2205.12689

Agrawal M, Hegselmann S, Lang H, Kim Y, Sontag D (2022) 大型语言模型是零样本临床信息提取器。arXiv预印本 http://arxiv.org/abs/2205.12689

Aiyappa, R An J, Kwak H, Ahn Y-Y (2023) Can we trust the evaluation on ChatGPT? arXiv Preprint http:// arxiv.org/abs/2303.12767

Aiyappa, R An J, Kwak H, Ahn Y-Y (2023) 我们能相信ChatGPT的评估吗？arXiv预印本 http:// arxiv.org/abs/2303.12767

Akopyan F, Sawada J, Cassidy A, Alvarez-Icaza R, Arthur J, Merolla P, Imam N, Nakamura Y, Datta P, Nam G-J et al (2015) TrueNorth: design and tool flow of a 65 MW 1 million neuron programmable neurosynaptic chip. IEEE Trans Comput Aided Des Integr Circuits Syst 34(10):1537-1557

Akopyan F, Sawada J, Cassidy A, Alvarez-Icaza R, Arthur J, Merolla P, Imam N, Nakamura Y, Datta P, Nam G-J 等 (2015) TrueNorth:一款65兆瓦、拥有100万个神经元的可编程神经突触芯片的设计与工具流程。IEEE计算机辅助设计与集成电路系统杂志 34(10):1537-1557

Alshiekh M, Bloem R, Ehlers R, Könighofer B, Niekum S, Topcu U (2018) Safe reinforcement learning via shielding. In: Proceedings of the AAAI conference on artificial intelligence, vol 32

Alshiekh M, Bloem R, Ehlers R, Könighofer B, Niekum S, Topcu U (2018) 通过屏蔽实现安全强化学习。收录于:人工智能会议(AAAI)论文集，第32卷

Alzantot M, Sharma Y, Elgohary A, Ho B-J, Srivastava M, Chang K-W (2018) Generating natural language adversarial examples. arXiv Preprint http://arxiv.org/abs/1804.07998

Alzantot M, Sharma Y, Elgohary A, Ho B-J, Srivastava M, Chang K-W (2018) 生成自然语言对抗样本。arXiv预印本 http://arxiv.org/abs/1804.07998

Arora U, Huang W, He H (2021) Types of out-of-distribution texts and how to detect them. arXiv Preprint http://arxiv.org/abs/2109.06827

Arora U, Huang W, He H (2021) 异常文本的类型及其检测方法。arXiv预印本 http://arxiv.org/abs/2109.06827

Bai Y, Jones A, Ndousse K, Askell A, Chen A, DasSarma N, Drain D, Fort S, Ganguli D, Henighan T et al (2022a) Training a helpful and harmless assistant with reinforcement learning from human feedback. arXiv Preprint http://arxiv.org/abs/2204.05862

Bai Y, Jones A, Ndousse K, Askell A, Chen A, DasSarma N, Drain D, Fort S, Ganguli D, Henighan T 等 (2022a) 通过人类反馈强化学习训练有帮助且无害的助手。arXiv预印本 http://arxiv.org/abs/2204.05862

Bai Y, Kadavath S, Kundu S, Askell A, Kernion J, Jones A, Chen A, Goldie A, Mirhoseini A, McKinnon C et al (2022b) Constitutional AI: harmlessness from AI feedback. arXiv Preprint http://arxiv.org/abs/ 2212.08073

Bai Y, Kadavath S, Kundu S, Askell A, Kernion J, Jones A, Chen A, Goldie A, Mirhoseini A, McKinnon C 等 (2022b) 宪法AI:来自AI反馈的无害性。arXiv预印本 http://arxiv.org/abs/ 2212.08073

Balaji Y, Nah S, Huang X, Vahdat A, Song J, Kreis K, Aittala M, Aila T, Laine S, Catanzaro B et al (2022) eDiff-I: text-to-image diffusion models with an ensemble of expert denoisers. arXiv Preprint http:// arxiv.org/abs/2211.01324

Balaji Y, Nah S, Huang X, Vahdat A, Song J, Kreis K, Aittala M, Aila T, Laine S, Catanzaro B 等 (2022) eDiff-I:由多个专家去噪器组成的文本到图像扩散模型。arXiv预印本 http:// arxiv.org/abs/2211.01324

Balakrishnan A, Puranic AG, Qin X, Dokhanchi A, Deshmukh JV, Ben Amor H, Fainekos G (2019) Specifying and evaluating quality metrics for vision-based perception systems. In: Design, automation & test in Europe conference & exhibition (DATE). pp 1433-1438

Balakrishnan A, Puranic AG, Qin X, Dokhanchi A, Deshmukh JV, Ben Amor H, Fainekos G (2019) 视觉感知系统的指标定义与评估。收录于:欧洲设计、自动化与测试会议(DATE)，第1433-1438页

Bang Y, Cahyawijaya S, Lee N, Dai W, Su D, Wilie B, Lovenia H, Ji Z, Yu T, Chung W et al (2023) A multitask, multilingual, multimodal evaluation of ChatGPT on reasoning, hallucination, and interactivity. arXiv Preprint http://arxiv.org/abs/2302.04023

Bang Y, Cahyawijaya S, Lee N, Dai W, Su D, Wilie B, Lovenia H, Ji Z, Yu T, Chung W 等 (2023) 多任务、多语言、多模态评估ChatGPT在推理、幻觉和交互方面的表现。arXiv预印本 http://arxiv.org/abs/2302.04023

Bartocci E, Falcone Y (2018) Lectures on runtime verification. Springer

Bartocci E, Falcone Y (2018) 运行时验证讲座。Springer

Bauer A, Leucker M, Schallhart C (2011) Runtime verification for LTL and TLTL. ACM Trans Softw Eng Methodol 20(4):1-64

Bauer A, Leucker M, Schallhart C (2011) LTL和TLTL的运行时验证。ACM软件工程方法学杂志 20(4):1-64

Belinkov Y, Bisk Y (2017) Synthetic and natural noise both break neural machine translation. arXiv Preprint http://arxiv.org/abs/1711.02173

贝林科夫 Y, 比斯克 Y (2017) 合成噪声与自然噪声都能破坏神经机器翻译。arXiv预印本 http://arxiv.org/abs/1711.02173

Bensalem S, Lakhnech Y, Saidi H (1996) Powerful techniques for the automatic generation of invariants. In: Computer aided verification: 8th international conference, CAV'96 New Brunswick, NJ, USA, July 31-August 3, 1996 proceedings 8. Springer, pp 323-335

本萨勒姆 S, 拉克内奇 Y, 萨伊迪 H (1996) 自动生成不变量的强大技术。在:计算机辅助验证:第八届国际会议，CAV'96 新泽西州新不伦瑞克，1996年7月31日至8月3日 会议论文集第8卷，Springer，第323-335页

Bensalem S, Lakhnech Y, Owre S (1998) Invest: a tool for the verification of invariants. In: Computer aided verification: 10th international conference, CAV'98 Vancouver, BC, Canada, June 28-July 2, 1998 proceedings 10. Springer, pp 505-510

本萨勒姆 S, 拉克内奇 Y, 奥韦尔 S (1998) Invest:一种用于不变量验证的工具。在:计算机辅助验证:第十届国际会议，CAV'98 加拿大不列颠哥伦比亚省温哥华，1998年6月28日至7月2日 会议论文集第10卷，Springer，第505-510页

Bensalem S, Cheng C-H, Huang X, Katsaros P, Molin A, Nickovic D, Peled D (2022) Formal specification for learning-enabled autonomous systems. In: International workshop on numerical software verification. Springer, pp 131-143

本萨勒姆 S, 郑 C-H, 黄 X, 卡特拉索斯 P, 莫林 A, 尼科维奇 D, 佩莱德 D (2022) 面向学习驱动自主系统的形式规范。在:数值软件验证国际研讨会。Springer，第131-143页

Bensalem S, Cheng C-H, Huang W, Huang X, Wu C, Zhao X (2023) What, indeed, is an achievable provable guarantee for learning-enabled safety critical systems. In: ISoLA 2023

本萨勒姆 S, 郑 C-H, 黄 W, 黄 X, 吴 C, 赵 X (2023) 实际上，学习驱动的安全关键系统的可实现可证明保证是什么。在:ISoLA 2023

Berthier N, Alshareef A, Sharp J, Schewe S, Huang X (2021) Abstraction and symbolic execution of deep neural networks with Bayesian approximation of hidden features. arXiv Preprint http://arxiv.org/abs/2103.03704

贝尔蒂耶 N, 阿尔沙雷夫 A, 夏普 J, 谢维 S, 黄 X (2021) 利用贝叶斯近似对深度神经网络的隐藏特征进行抽象和符号执行。arXiv预印本 http://arxiv.org/abs/2103.03704

Bibel W (2013) Automated theorem proving. Springer Science & Business Media, Berlin

比贝尔 W (2013) 自动定理证明。Springer Science & Business Media，柏林

Bitcoin energy consumption index. https://digiconomist.net/bitcoin-energy-consumption.Accessed 17 Aug 2023

比特币能耗指数。https://digiconomist.net/bitcoin-energy-consumption. 2023年8月17日访问

Black S, Biderman S, Hallahan E, Anthony Q, Gao L, Golding L, He H, Leahy C, McDonell K, Phang J et al (2022) GPT-Neox-20B: an open-source autoregressive language model. arXiv Preprint http:// arxiv.org/abs/2204.06745

Black S, Biderman S, Hallahan E, Anthony Q, Gao L, Golding L, He H, Leahy C, McDonell K, Phang J 等 (2022) GPT-Neox-20B:一个开源的自回归语言模型。arXiv预印本 http:// arxiv.org/abs/2204.06745

Bonaert G, Dimitrov DI, Baader M, Vechev M (2021) Fast and precise certification of transformers. In: Proceedings of the 42nd ACM SIGPLAN international conference on programming language design and implementation. pp 466-481

Bonaert G, Dimitrov DI, Baader M, Vechev M (2021) 快速且精确的变换器(transformers)认证。收录于:第42届ACM SIGPLAN国际会议——编程语言设计与实现论文集，第466-481页

Borji A (2023) A categorical archive of ChatGPT failures. CoRR. http://arxiv.org/abs/2302.03494

Borji A (2023) ChatGPT失败的分类存档。CoRR. http://arxiv.org/abs/2302.03494

Botacin M (2023) GPThreats-3: is automatic malware generation a threat? In: 2023 IEEE security and privacy workshops (SPW). pp 238-254

Botacin M (2023) GPThreats-3:自动恶意软件生成是否构成威胁？收录于:2023年IEEE安全与隐私研讨会(SPW)。第238-254页

Brants T, Popat AC, Xu P, Och FJ, Dean J (2007) Large language models in machine translation. In: Eisner J (ed) EMNLP-CoNLL 2007, proceedings of the 2007 joint conference on empirical methods in natural language processing and computational natural language learning, June 28-30, 2007, Prague, Czech Republic. ACL, pp 858-867

Brants T, Popat AC, Xu P, Och FJ, Dean J (2007) 大型语言模型在机器翻译中的应用。收录于:Eisner J(编)EMNLP-CoNLL 2007，2007年自然语言处理与计算自然语言学习联合会议论文集，2007年6月28-30日，捷克布拉格。ACL，第858-867页

Brown TB, Mann B, Ryder N, Subbiah M, Kaplan J, Dhariwal P, Neelakantan A, Shyam P, Sastry G, Askell A, Agarwal S, Herbert-Voss A, Krueger G, Henighan T, Child R, Ramesh A, Ziegler DM, Wu J, Winter C, Hesse C, Chen M, Sigler E, Litwin M, Gray S, Chess B, Clark J, Berner C, McCandlish S, Radford A, Sutskever I, Amodei D (2020a) Language models are few-shot learners. In: Proceedings of the 34th international conference on neural information processing systems, NIPS'20, Red Hook, NY, USA, 2020. Curran Associates Inc

Brown TB, Mann B, Ryder N, Subbiah M, Kaplan J, Dhariwal P, Neelakantan A, Shyam P, Sastry G, Askell A, Agarwal S, Herbert-Voss A, Krueger G, Henighan T, Child R, Ramesh A, Ziegler DM, Wu J, Winter C, Hesse C, Chen M, Sigler E, Litwin M, Gray S, Chess B, Clark J, Berner C, McCandlish S, Radford A, Sutskever I, Amodei D (2020a) 语言模型是少样本学习者。收录于:第34届神经信息处理系统国际会议(NIPS'20)论文集，纽约红钩，2020年。Curran Associates Inc

Brown T, Mann B, Ryder N, Subbiah M, Kaplan JD, Dhariwal P, Neelakantan A, Shyam P, Sastry G, Askell A et al (2020b) Language models are few-shot learners. Adv Neural Inf Process Syst 33:1877-1901

Brown T, Mann B, Ryder N, Subbiah M, Kaplan JD, Dhariwal P, Neelakantan A, Shyam P, Sastry G, Askell A 等 (2020b) 语言模型是少样本学习者。先进神经信息处理系统，33:1877-1901

Brown T, Mann B, Ryder N, Subbiah M, Kaplan JD, Dhariwal P, Neelakantan A, Shyam P, Sastry G, Askell A, Agarwal S, Herbert-Voss A, Krueger G, Henighan T, Child R, Ramesh A, Ziegler D, Wu J, Winter C, Hesse C, Chen M, Sigler E, Litwin M, Gray S, Chess B, Clark J, Berner C, McCan-dlish S, Radford A, Sutskever I, Amodei D (2020c) Language models are few-shot learners. In: Larochelle H, Ranzato M, Hadsell R, Balcan M, Lin H (eds) Advances in neural information processing systems, vol 33. Curran Associates, Inc., pp 1877-1901

Brown T, Mann B, Ryder N, Subbiah M, Kaplan JD, Dhariwal P, Neelakantan A, Shyam P, Sastry G, Askell A, Agarwal S, Herbert-Voss A, Krueger G, Henighan T, Child R, Ramesh A, Ziegler D, Wu J, Winter C, Hesse C, Chen M, Sigler E, Litwin M, Gray S, Chess B, Clark J, Berner C, McCandlish S, Radford A, Sutskever I, Amodei D (2020c) 语言模型是少样本学习者。收录于:Larochelle H, Ranzato M, Hadsell R, Balcan M, Lin H(编)神经信息处理系统进展，第33卷。Curran Associates, Inc.，第1877-1901页

Bullwinkle M, Urban E (2023) Introduction to red teaming large language models (LLMS). https://learn.microsoft.com/en-us/azure/ai-services/openai/concepts/red-teaming.Accessed 20 Aug 2023

Bullwinkle M, Urban E (2023) 大型语言模型(LLMs)红队介绍。https://learn.microsoft.com/en-us/azure/ai-services/openai/concepts/red-teaming. 2023年8月20日访问

Bursztein E (2018) Attacks against machine learning—an overview. https://elie.net/blog/ai/attacks-again st-machine-learning-an-overview/. Accessed 20 Aug 2023

Bursztein E (2018) 针对机器学习的攻击——概述。https://elie.net/blog/ai/attacks-against-machine-learning-an-overview/. 2023年8月20日访问

Cambiaso E, Caviglione L (2023) Scamming the scammers: using ChatGPT to reply mails for wasting time and resources. arXiv Preprint http://arxiv.org/abs/2303.13521

Cambiaso E, Caviglione L (2023) 骗局骗子:利用ChatGPT回复邮件以浪费时间和资源。arXiv预印本 http://arxiv.org/abs/2303.13521

Cao Y, Li D, Fang M, Zhou T, Gao J, Zhan Y, Tao D (2022) TASA: deceiving question answering models by twin answer sentences attack. arXiv Preprint http://arxiv.org/abs/2210.15221

Cao Y, Li D, Fang M, Zhou T, Gao J, Zhan Y, Tao D (2022) TASA:通过双重答案句攻击欺骗问答模型。arXiv预印本 http://arxiv.org/abs/2210.15221

Carlini N, Jagielski M, Choquette-Choo CA, Paleka D, Pearce W, Anderson H, Terzis A, Thomas K, Tramèr F (2023) Poisoning web-scale training datasets is practical. arXiv Preprint http://arxiv.org/ abs/2302.10149

Carlini N, Jagielski M, Choquette-Choo CA, Paleka D, Pearce W, Anderson H, Terzis A, Thomas K, Tramèr F (2023) 在网络规模的训练数据中投毒是可行的。arXiv预印本 http://arxiv.org/abs/2302.10149

Chen B, Carvalho W, Baracaldo N, Ludwig H, Edwards B, Lee T, Molloy I, Srivastava B (2019) Detecting backdoor attacks on deep neural networks by activation clustering. In: SafeAI@ AAAI

Chen B, Carvalho W, Baracaldo N, Ludwig H, Edwards B, Lee T, Molloy I, Srivastava B (2019) 通过激活簇检测深度神经网络中的后门攻击。发表于:SafeAI@ AAAI

Chen M, Tworek J, Jun H, Yuan Q, de Oliveira Pinto HP, Kaplan J, Edwards H, Burda Y, Joseph N, Brock-man G et al (2021a) Evaluating large language models trained on code. arXiv Preprint http://arxiv.org/abs/2107.03374

Chen M, Tworek J, Jun H, Yuan Q, de Oliveira Pinto HP, Kaplan J, Edwards H, Burda Y, Joseph N, Brockman G 等 (2021a) 评估基于代码训练的大型语言模型。arXiv预印本 http://arxiv.org/abs/2107.03374

Chen X, Salem A, Chen D, Backes M, Ma S, Shen Q, Wu Z, Zhang Y (2021b) BadNL: backdoor attacks against NLP models with semantic-preserving improvements. In: Annual computer security applications conference. pp 554-569

Chen X, Salem A, Chen D, Backes M, Ma S, Shen Q, Wu Z, Zhang Y (2021b) BadNL:针对自然语言处理(NLP)模型的带有语义保持改进的后门攻击。发表于:年度计算机安全应用会议。第554-569页

Chen S, Bi X, Gao R, Sun X (2022) Holistic sentence embeddings for better out-of-distribution detection. In: Findings of the Association for Computational Linguistics: EMNLP 2022, Abu Dhabi, United Arab Emirates, Dec. 2022. Association for Computational Linguistics, pp 6676-6686

Chen S, Bi X, Gao R, Sun X (2022) 用于更好检测分布外(out-of-distribution)样本的整体句子嵌入。发表于:计算语言学协会2022年会议成果:EMNLP 2022，阿布扎比，阿联酋，2022年12月。计算语言学协会，第6676-6686页

Chen L, Zaharia M, Zou J (2023a) How is ChatGPT's behavior changing over time? arXiv Preprint http:// arxiv.org/abs/2307.09009

Chen L, Zaharia M, Zou J (2023a) ChatGPT的行为随时间的变化情况如何？arXiv预印本 http://arxiv.org/abs/2307.09009

Chen S, Yang W, Bi X, Sun X (2023b) Fine-tuning deteriorates general textual out-of-distribution detection by distorting task-agnostic features. In: Findings of the Association for Computational Linguistics: EACL 2023. pp 552-567

Chen S, Yang W, Bi X, Sun X (2023b) 微调通过扭曲任务无关特征，降低了对文本分布外(out-of-distribution)检测的效果。发表于:计算语言学协会2023年会议成果:EACL 2023，第552-567页

Chen S, Kann BH, Foote MB, Aerts HJ, Savova GK, Mak RH, Bitterman DS (2023c) The utility of Chat-GPT for cancer treatment information. medRxiv, pp 2023-03

Chen S, Kann BH, Foote MB, Aerts HJ, Savova GK, Mak RH, Bitterman DS (2023c) Chat-GPT在癌症治疗信息中的实用性。medRxiv，2023-03页

Cheng Y, Jiang L, Macherey W (2019a) Robust neural machine translation with doubly adversarial inputs. arXiv Preprint http://arxiv.org/abs/1906.02443

Cheng Y, Jiang L, Macherey W (2019a) 使用双重对抗性输入实现鲁棒神经机器翻译。arXiv预印本 http://arxiv.org/abs/1906.02443

Cheng C, Nührenberg G, Yasuoka H (2019b) Runtime monitoring neuron activation patterns. In: DATE2019. pp 300-303

Cheng C, Nührenberg G, Yasuoka H (2019b) 运行时监控神经元激活模式。发表于:DATE2019，第300-303页

Cheng M, Yi J, Chen P-Y, Zhang H, Hsieh C-J (2020) Seq2Sick: evaluating the robustness of sequence-to-sequence models with adversarial examples. In: Proceedings of the AAAI conference on artificial intelligence, vol 34. pp 3601-3608

Cheng M, Yi J, Chen P-Y, Zhang H, Hsieh C-J (2020) Seq2Sick:用对抗样本评估序列到序列模型的鲁棒性。发表于:人工智能会议(AAAI)，第34卷，第3601-3608页

Cheng C-H, Wu C, Seferis E, Bensalem S (2022) Prioritizing corners in OOD detectors via symbolic string manipulation. In: Bouajjani A, Holík L, Wu Z (eds) Automated technology for verification and analysis. Springer International Publishing, Cham, pp 397-413

Cheng C-H, Wu C, Seferis E, Bensalem S (2022) 通过符号字符串操作优先考虑异常检测器中的角点。发表于:Bouajjani A, Holík L, Wu Z(编) 自动化验证与分析技术。Springer国际出版，第397-413页

Chiang W-L, Li Z, Lin Z, Sheng Y, Wu Z, Zhang H, Zheng L, Zhuang S, Zhuang Y, Gonzalez JE et al (2023) Vicuna: an open-source chatbot impressing GPT-4 with 90%* ChatGPT quality. See https:// vicuna.Imsys.org. Accessed 14 Apr 2023

Chiang W-L, Li Z, Lin Z, Sheng Y, Wu Z, Zhang H, Zheng L, Zhuang S, Zhuang Y, Gonzalez JE 等 (2023) 维库纳(Vicuna):一款开源聊天机器人，表现优于GPT-4，达到90%的ChatGPT质量。参见https://vicuna.Imsys.org。访问时间:2023年4月14日

Cho JH, Hariharan B (2019) On the efficacy of knowledge distillation. In: Proceedings of the IEEE/CVF international conference on computer vision. pp 4794-4802

Cho JH, Hariharan B (2019) 关于知识蒸馏(knowledge distillation)的有效性。发表于:IEEE/CVF国际计算机视觉会议论文集，第4794-4802页

Cho H, Park C, Kang J, Yoo KM, Kim T, Lee S-G (2022) Enhancing out-of-distribution detection in natural language understanding via implicit layer ensemble. In: Findings of the Association for Computational Linguistics: EMNLP 2022, Abu Dhabi, United Arab Emirates, Dec. 2022. Association for Computational Linguistics, pp 783-798

Cho H, Park C, Kang J, Yoo KM, Kim T, Lee S-G (2022) 通过隐式层集成提升自然语言理解中的分布外检测能力。发表于:计算语言学协会2022年会议成果:EMNLP 2022，阿布扎比，阿联酋，2022年12月。计算语言学协会，第783-798页

Chowdhery A, Narang S, Devlin J, Bosma M, Mishra G, Roberts A, Barham P, Chung HW, Sutton C, Gehr-mann S et al (2022) PaLM: scaling language modeling with pathways. arXiv Preprint http://arxiv.org/ abs/2204.02311

Chowdhery A, Narang S, Devlin J, Bosma M, Mishra G, Roberts A, Barham P, Chung HW, Sutton C, Gehrmann S 等 (2022) PaLM:利用路径(Pathways)扩展语言模型规模。arXiv预印本 http://arxiv.org/abs/2204.02311

Christiano PF, Leike J, Brown T, Martic M, Legg S, Amodei D (2017) Deep reinforcement learning from human preferences. In: Guyon I, Luxburg UV, Bengio S, Wallach H, Fergus R, Vishwanathan S, Garnett $\mathrm{R}$ (eds) Advances in neural information processing systems, vol 30. Curran Associates, Inc

Christiano PF, Leike J, Brown T, Martic M, Legg S, Amodei D (2017) 来自人类偏好的深度强化学习。In: Guyon I, Luxburg UV, Bengio S, Wallach H, Fergus R, Vishwanathan S, Garnett $\mathrm{R}$ (eds) 神经信息处理系统进展，第30卷。Curran Associates, Inc

Clark K, Luong M-T, Le QV, Manning CD (2020) Electra: pre-training text encoders as discriminators rather than generators. arXiv Preprint http://arxiv.org/abs/2003.10555

Clark K, Luong M-T, Le QV, Manning CD (2020) Electra:作为判别器而非生成器的预训练文本编码器。arXiv预印本 http://arxiv.org/abs/2003.10555

Cobbe K, Kosaraju V, Bavarian M, Chen M, Jun H, Kaiser L, Plappert M, Tworek J, Hilton J, Nakano R et al (2021) Training verifiers to solve math word problems. arXiv Preprint http://arxiv.org/abs/2110.14168

Cobbe K, Kosaraju V, Bavarian M, Chen M, Jun H, Kaiser L, Plappert M, Tworek J, Hilton J, Nakano R 等 (2021) 训练验证器以解决数学应用题。arXiv预印本 http://arxiv.org/abs/2110.14168

Cohen J, Rosenfeld E, Kolter Z (2019) Certified adversarial robustness via randomized smoothing. In: International conference on machine learning. PMLR, pp 1310-1320

Cohen J, Rosenfeld E, Kolter Z (2019) 通过随机平滑实现认证的对抗鲁棒性。In: 机器学习国际会议。PMLR，第1310-1320页

Croce F, Hein M (2020) Reliable evaluation of adversarial robustness with an ensemble of diverse parameter-free attacks. In: International conference on machine learning. PMLR, pp 2206-2216

Croce F, Hein M (2020) 使用多样化的无参数攻击集可靠评估对抗鲁棒性。In: 机器学习国际会议。PMLR，第2206-2216页

Dai J, Chen C, Li Y (2019) A backdoor attack against LSTM-based text classification systems. IEEE Access 7:138872-138878

Dai J, Chen C, Li Y (2019) 针对基于LSTM(长短期记忆网络)的文本分类系统的后门攻击。IEEE Access 7:138872-138878

Dan S, Roth D (2021) On the effects of transformer size on in-and out-of-domain calibration. In: Findings of the Association for Computational Linguistics: EMNLP 2021. pp 2096-2101

Dan S, Roth D (2021) 转换器规模对域内外校准效果的影响。In: 计算语言学协会发现:EMNLP 2021。第2096-2101页

Davies M, Srinivasa N, Lin T-H, Chinya G, Cao Y, Choday SH, Dimou G, Joshi P, Imam N, Jain S et al (2018) Loihi: a neuromorphic manycore processor with on-chip learning. IEEE Micro 38(1):82-99

Davies M, Srinivasa N, Lin T-H, Chinya G, Cao Y, Choday SH, Dimou G, Joshi P, Imam N, Jain S 等 (2018) Loihi:具有片上学习能力的神经形态多核处理器。IEEE Micro 38(1):82-99

De Moura L, Bjørner N (2008) Z3: an efficient SMT solver. In: Tools and algorithms for the construction and analysis of systems: 14th international conference, TACAS 2008, held as part of the joint European conferences on theory and practice of software, ETAPS 2008, Budapest, Hungary, March 29-April 6, 2008. Proceedings 14. Springer, pp 337-340

De Moura L, Bjørner N (2008) Z3:高效的SMT求解器。In: 系统构建与分析的工具与算法:第14届国际会议，TACAS 2008，作为软件理论与实践欧洲会议(ETAPS 2008)的一部分在匈牙利布达佩斯举行，2008年3月29日-4月6日。论文集第14卷。Springer，第337-340页

De Vries A, Gallersdörfer U, Klaaßen L, Stoll C (2022) Revisiting bitcoin's carbon footprint. Joule 6(3):498-502

De Vries A, Gallersdörfer U, Klaaßen L, Stoll C (2022) 重新审视比特币的碳足迹。Joule 6(3):498-502

Desai S, Durrett G (2020) Calibration of pre-trained transformers. In: Proceedings of the 2020 conference on empirical methods in natural language processing (EMNLP), Online, Nov. 2020. Association for Computational Linguistics, pp 295-302

Desai S, Durrett G (2020) 预训练变换器的校准。In: 2020年自然语言处理经验方法会议(EMNLP)论文集，线上，2020年11月。计算语言学协会，第295-302页

Deshpande A, Murahari V, Rajpurohit T, Kalyan A, Narasimhan K (2023) Toxicity in ChatGPT: analyzing persona-assigned language models. arXiv Preprint http://arxiv.org/abs/2304.05335

Deshpande A, Murahari V, Rajpurohit T, Kalyan A, Narasimhan K (2023) ChatGPT中的毒性:分析角色分配的语言模型。arXiv预印本 http://arxiv.org/abs/2304.05335

Dettmers T, Lewis M, Belkada Y, Zettlemoyer L (2022) GPT3. int8 (   ): 8-bit matrix multiplication for transformers at scale. In: Advances in neural information processing systems, vol 35. pp 30318-30332

Dettmers T, Lewis M, Belkada Y, Zettlemoyer L (2022) GPT3. int8(   ):大规模变换器的8位矩阵乘法。In: 神经信息处理系统进展，第35卷。第30318-30332页

Devlin J, Chang M-W, Lee K, Toutanova K (2018) BERT: pre-training of deep bidirectional transformers for language understanding. arXiv Preprint http://arxiv.org/abs/1810.04805

Devlin J, Chang M-W, Lee K, Toutanova K (2018) BERT:用于语言理解的深度双向变换器的预训练。arXiv预印本 http://arxiv.org/abs/1810.04805

Devlin J, Chang M-W, Lee K, Toutanova K (2019) BERT: pre-training of deep bidirectional transformers for language understanding. In: Proceedings of the 2019 conference of the North American chapter of the Association for Computational Linguistics: human language technologies, volume 1 (long and short papers), Minneapolis, Minnesota, June 2019. Association for Computational Linguistics, pp 4171-4186

Devlin J, Chang M-W, Lee K, Toutanova K (2019) BERT:用于语言理解的深度双向变换器的预训练。In: 2019年北美计算语言学协会会议论文集:人类语言技术，第一卷(长篇和短篇论文)，明尼阿波利斯，明尼苏达州，2019年6月。计算语言学协会，第4171-4186页

DeVries T, Taylor GW (2018) Learning confidence for out-of-distribution detection in neural networks. arXiv Preprint http://arxiv.org/abs/1802.04865

DeVries T, Taylor GW (2018) 神经网络中用于检测分布外样本的置信度学习。arXiv预印本 http://arxiv.org/abs/1802.04865

Dey N (2023) GPT: a family of open, compute-efficient, large language models. https://www.cerebras.net/ blog/cerebras-gpt-a-family-of-open-compute-efficient-large-language-models/. Accessed 20 Aug 2023

Dey N (2023) GPT:一系列开源、计算效率高的大型语言模型。https://www.cerebras.net/ blog/cerebras-gpt-a-family-of-open-compute-efficient-large-language-models/。2023年8月20日访问

Dodge J, Ilharco G, Schwartz R, Farhadi A, Hajishirzi H, Smith N (2020) Fine-tuning pretrained language models: weight initializations, data orders, and early stopping. arXiv Preprint http://arxiv.org/abs/ 2002.06305

Dodge J, Ilharco G, Schwartz R, Farhadi A, Hajishirzi H, Smith N (2020) 微调预训练语言模型:权重初始化、数据顺序与早停。arXiv预印本 http://arxiv.org/abs/2002.06305

Du T, Ji S, Shen L, Zhang Y, Li J, Shi J, Fang C, Yin J, Beyah R, Wang T (2021) CERT-RNN: towards certifying the robustness of recurrent neural networks. CCS 21(2021):15-19

Du T, Ji S, Shen L, Zhang Y, Li J, Shi J, Fang C, Yin J, Beyah R, Wang T (2021) CERT-RNN:朝着验证循环神经网络(Recurrent Neural Networks)鲁棒性方向努力。CCS 21(2021):15-19

Du N, Huang Y, Dai AM, Tong S, Lepikhin D, Xu Y, Krikun M, Zhou Y, Yu AW, Firat O et al (2022) GLaM: efficient scaling of language models with mixture-of-experts. In: International conference on machine learning. PMLR, pp 5547-5569

Du N, Huang Y, Dai AM, Tong S, Lepikhin D, Xu Y, Krikun M, Zhou Y, Yu AW, Firat O 等 (2022) GLaM:通过专家混合(Mixture-of-Experts)实现语言模型的高效扩展。收录于:国际机器学习会议。PMLR，第5547-5569页

Duan H, Yang Y, Abbasi A, Tam KY (2022) BARLE: background-aware representation learning for background shift out-of-distribution detection. In: Findings of the Association for Computational Linguistics: EMNLP 2022, Abu Dhabi, United Arab Emirates, Dec. 2022. Association for Computational Linguistics, pp 750-764

Duan H, Yang Y, Abbasi A, Tam KY (2022) BARLE:面向背景偏移(Background Shift)检测的背景感知表示学习。在:计算语言学协会(ACL)2022年会议论文集，阿布扎比，阿联酋，2022年12月。计算语言学协会，第750-764页

Duan J, Kong F, Wang S, Shi X, Xu K (2023) Are diffusion models vulnerable to membership inference attacks? arXiv Preprint http://arxiv.org/abs/2302.01316

Duan J, Kong F, Wang S, Shi X, Xu K (2023) 扩散模型(Diffusion Models)是否易受成员推断攻击(Membership Inference Attacks)？arXiv预印本 http://arxiv.org/abs/2302.01316

Dudley JJ, Kristensson PO (2018) A review of user interface design for interactive machine learning. ACM Trans Interact Intell Syst 8(2):1-37

Dudley JJ, Kristensson PO (2018) 交互式机器学习用户界面设计综述。ACM交互智能系统杂志 8(2):1-37

E2Analyst (2023) GPT-4: everything you want to know about OpenAI's new AI model. https://medium.com/predict/gpt-4-everything-you-want-to-know-about-openais-new-ai-model-a5977b42e495.Accessed 20 Aug 2023

E2Analyst (2023) GPT-4:关于OpenAI新型AI模型的全面介绍。https://medium.com/predict/gpt-4-everything-you-want-to-know-about-openais-new-ai-model-a5977b42e495。2023年8月20日访问

Ebrahimi J, Rao A, Lowd D, Dou D (2017) HotFlip: white-box adversarial examples for text classification. arXiv Preprint http://arxiv.org/abs/1712.06751

Ebrahimi J, Rao A, Lowd D, Dou D (2017) HotFlip:文本分类的白盒对抗样本。arXiv预印本 http://arxiv.org/abs/1712.06751

Edwards B (2023) Study claims ChatGPT is losing capability, but some experts aren't convinced. https:// arstechnica.com/information-technology/2023/07/is-chatgpt-getting-worse-over-time-study-claims-yes-but-others-arent-sure/. Accessed 20 Aug 2023

Edwards B (2023) 研究称ChatGPT能力在下降，但一些专家并不认同。https://arstechnica.com/information-technology/2023/07/is-chatgpt-getting-worse-over-time-study-claims-yes-but-others-arent-sure/。2023年8月20日访问

Eppstein D (1996) Zonohedra and zonotopes. Math Educ Res 5(4):15-21

Eppstein D (1996) 旋子(Zonohedra)与旋多面体(Zonotopes)。数学教育研究 5(4):15-21

Esser P, Rombach R, Ommer B (2021) Taming transformers for high-resolution image synthesis. In: Proceedings of the IEEE/CVF conference on computer vision and pattern recognition. pp 12873-12883

Esser P, Rombach R, Ommer B (2021) 高分辨率图像合成中的变换器(Transformers)调优。收录于:IEEE/CVF计算机视觉与模式识别会议论文集。第12873-12883页

EU GDPR (2016). https://gdpr-info.eu.Accessed 20 Aug 2023

欧盟通用数据保护条例(GDPR)(2016)。https://gdpr-info.eu。2023年8月20日访问

Farhat F, Sohail S, Madsen D (2023) How trustworthy is ChatGPT? The case of bibliometric analyses. Cogent Eng 10:06

Farhat F, Sohail S, Madsen D (2023) ChatGPT的可信度如何？以文献计量分析为例。Cogent Engineering 10:06

Fedus W, Zoph B, Shazeer N (2021) Switch transformers: scaling to trillion parameter models with simple and efficient sparsity. J Mach Learn Res 23:1-40

Fedus W, Zoph B, Shazeer N (2021) Switch变换器:通过简单高效的稀疏性(Sparsity)实现万亿参数模型的扩展。机器学习研究杂志 23:1-40

Feinman R, Curtin RR, Shintre S, Gardner AB (2017) Detecting adversarial samples from artifacts. arXiv Preprint http://arxiv.org/abs/1703.00410

Feinman R, Curtin RR, Shintre S, Gardner AB (2017) 从伪迹中检测对抗样本。arXiv预印本 http://arxiv.org/abs/1703.00410

Fitting M (1996) First-order logic and automated theorem proving. Graduate texts in computer science, second edn. Springer

Fitting M (1996) 一阶逻辑与自动定理证明。计算机科学研究生教材，第二版。Springer

Frantar E, Alistarh D (2022) Optimal brain compression: a framework for accurate post-training quantization and pruning. arXiv Preprint http://arxiv.org/abs/2208.11580

Frantar E, Alistarh D (2022) 最优大脑压缩:一种用于精确后训练量化与剪枝的框架。arXiv预印本 http://arxiv.org/abs/2208.11580

Frantar E, Ashkboos S, Hoefler T, Alistarh D (2023) GPTQ: accurate quantization for generative pre-trained transformers. In: International conference on learning representations

Frantar E, Ashkboos S, Hoefler T, Alistarh D (2023) GPTQ:生成式预训练变换模型的精确量化。在:国际学习表征会议

Frieder S, Pinchetti L, Griffiths R-R, Salvatori T, Lukasiewicz T, Petersen PC, Chevalier A, Berner J (2023) Mathematical capabilities of ChatGPT. arXiv Preprint http://arxiv.org/abs/2301.13867

Frieder S, Pinchetti L, Griffiths R-R, Salvatori T, Lukasiewicz T, Petersen PC, Chevalier A, Berner J (2023) ChatGPT的数学能力。arXiv预印本 http://arxiv.org/abs/2301.13867

Gangal V, Arora A, Einolghozati A, Gupta S (2020) Likelihood ratios and generative classifiers for unsupervised out-of-domain detection in task oriented dialog. In: Proceedings of the AAAI conference on artificial intelligence, vol 34. pp 7764-7771

Gangal V, Arora A, Einolghozati A, Gupta S (2020) 任务导向对话中无监督域外检测的似然比与生成分类器。收录于:第34届人工智能会议论文集，pp 7764-7771

Ganguli D, Askell A, Schiefer N, Liao T, Lukošiūtě K, Chen A, Goldie A, Mirhoseini A, Olsson C, Hernandez D et al (2023) The capacity for moral self-correction in large language models. arXiv Preprint http://arxiv.org/abs/2302.07459

Ganguli D, Askell A, Schiefer N, Liao T, Lukošiūtě K, Chen A, Goldie A, Mirhoseini A, Olsson C, Hernandez D 等 (2023) 大型语言模型的道德自我修正能力。arXiv预印本 http://arxiv.org/abs/2302.07459

Gao J, Lanchantin J, Soffa ML, Qi Y (2018) Black-box generation of adversarial text sequences to evade deep learning classifiers. In: 2018 IEEE security and privacy workshops (SPW). IEEE, pp 50-56

Gao J, Lanchantin J, Soffa ML, Qi Y (2018) 黑盒生成对抗文本序列以规避深度学习分类器。在:2018 IEEE安全与隐私研讨会(SPW)。IEEE，pp 50-56

Gao L, Madaan A, Zhou S, Alon U, Liu P, Yang Y, Callan J, Neubig G (2023) PAL: program-aided language models

Gao L, Madaan A, Zhou S, Alon U, Liu P, Yang Y, Callan J, Neubig G (2023) PAL:程序辅助语言模型

Garcia J, Fernández F (2015) A comprehensive survey on safe reinforcement learning. J Mach Learn Res 16(1):1437-1480

Garcia J, Fernández F (2015) 关于安全强化学习的全面综述。机器学习研究杂志 16(1):1437-1480

Goodfellow I, Papernot N (2017) The challenge of verification and testing of machine learning. Cleverhans-blog

Goodfellow I, Papernot N (2017) 机器学习的验证与测试挑战。Cleverhans博客

Goodfellow IJ, Shlens J, Szegedy C (2014) Explaining and harnessing adversarial examples. arXiv Preprint http://arxiv.org/abs/1412.6572

Goodfellow IJ, Shlens J, Szegedy C (2014) 解释与利用对抗样本。arXiv预印本 http://arxiv.org/abs/1412.6572

Goodfellow I, Pouget-Abadie J, Mirza M, Xu B, Warde-Farley D, Ozair S, Courville A, Bengio Y (2020) Generative adversarial networks. Commun ACM 63(11):139-144

Goodfellow I, Pouget-Abadie J, Mirza M, Xu B, Warde-Farley D, Ozair S, Courville A, Bengio Y (2020) 生成对抗网络。通信《ACM》 63(11):139-144

Goodin D (2023) Hackers are selling a service that bypasses ChatGPT restrictions on malware. https://arste chnica.com/information-technology/2023/02/now-open-fee-based-telegram-service-that-uses-chatg pt-to-generate-malware/. Accessed 20 Aug 2023

Goodin D (2023) 黑客出售绕过ChatGPT关于恶意软件限制的服务。https://arstechnica.com/information-technology/2023/02/now-open-fee-based-telegram-service-that-uses-chatgpt-to-generate-malware/。2023年8月20日访问

Gopinath D, Wang K, Zhang M, Pasareanu CS, Khurshid S (2018) Symbolic execution for deep neural networks. arXiv Preprint http://arxiv.org/abs/1807.10439

Gopinath D, Wang K, Zhang M, Pasareanu CS, Khurshid S (2018) 深度神经网络的符号执行。arXiv预印本 http://arxiv.org/abs/1807.10439

Gou J, Yu B, Maybank SJ, Tao D (2021) Knowledge distillation: a survey. Int J Comput Vis 129:1789-1819

Gou J, Yu B, Maybank SJ, Tao D (2021) 知识蒸馏:综述。国际计算机视觉杂志 129:1789-1819

Gowal S, Dvijotham K, Stanforth R, Bunel R, Qin C, Uesato J, Arandjelovic R, Mann T, Kohli P (2018) On the effectiveness of interval bound propagation for training verifiably robust models. arXiv Preprint http://arxiv.org/abs/1810.12715

Gowal S, Dvijotham K, Stanforth R, Bunel R, Qin C, Uesato J, Arandjelovic R, Mann T, Kohli P (2018) 关于区间界限传播在训练可验证鲁棒模型中的有效性。arXiv预印本 http://arxiv.org/abs/1810.12715

Goyal S, Doddapaneni S, Khapra MM, Ravindran B (2022) A survey in adversarial defences and robustness in NLP. arXiv Preprint http://arxiv.org/abs/2203.06414

Goyal S, Doddapaneni S, Khapra MM, Ravindran B (2022) 自然语言处理中的对抗防御与鲁棒性综述。arXiv预印本 http://arxiv.org/abs/2203.06414

GPT-4's details are leaked. https://archive.md/2RQ8X.Accessed 17 Aug 2023

GPT-4的详细信息被泄露。https://archive.md/2RQ8X。2023年8月17日访问

Greshake K, Abdelnabi S, Mishra S, Endres C, Holz T, Fritz M (2023) More than you've asked for: a comprehensive analysis of novel prompt injection threats to application-integrated large language models. arXiv Preprint http://arxiv.org/abs/2302.12173

Greshake K, Abdelnabi S, Mishra S, Endres C, Holz T, Fritz M (2023) 超出您的预期:对应用集成大型语言模型(Large Language Models)中新型提示注入威胁的全面分析。arXiv预印本 http://arxiv.org/abs/2302.12173

Gu T, Liu K, Dolan-Gavitt B, Garg S (2019) BadNets: evaluating backdooring attacks on deep neural networks. IEEE Access 7:47230-47244

Gu T, Liu K, Dolan-Gavitt B, Garg S (2019) BadNets:深度神经网络后门攻击评估。IEEE Access 7:47230-47244

Gu J-C, Li T, Liu Q, Ling Z-H, Su Z, Wei S, Zhu X (2020) Speaker-aware BERT for multi-turn response selection in retrieval-based chatbots. In: Proceedings of the 29th ACM international conference on information & knowledge management, CIKM '20, New York, NY, USA, 2020. Association for Computing Machinery, pp 2041-2044

Gu J-C, Li T, Liu Q, Ling Z-H, Su Z, Wei S, Zhu X (2020) 面向多轮响应选择的说话人感知BERT(Speaker-aware BERT)在检索式聊天机器人中的应用。收录于:第29届ACM国际信息与知识管理会议论文集，CIKM '20，纽约，美国，2020年。计算机协会，页2041-2044

Gu S, Yang L, Du Y, Chen G, Walter F, Wang J, Yang Y, Knoll A (2022) A review of safe reinforcement learning: methods, theory and applications. arXiv Preprint http://arxiv.org/abs/2205.10330

Gu S, Yang L, Du Y, Chen G, Walter F, Wang J, Yang Y, Knoll A (2022) 安全强化学习(Safe Reinforcement Learning)综述:方法、理论与应用。arXiv预印本 http://arxiv.org/abs/2205.10330

Gu Y, Dong L, Wei F, Huang M (2023a) Knowledge distillation of large language models. arXiv Preprint http://arxiv.org/abs/2306.08543

Gu Y, Dong L, Wei F, Huang M (2023a) 大型语言模型(Large Language Models)的知识蒸馏。arXiv预印本 http://arxiv.org/abs/2306.08543

Gu S, Kshirsagar A, Du Y, Chen G, Yang Y, Peters J, Knoll A (2023b) A human-centered safe robot reinforcement learning framework with interactive behaviors. arXiv Preprint http://arxiv.org/abs/2302.13137

Gu S, Kshirsagar A, Du Y, Chen G, Yang Y, Peters J, Knoll A (2023b) 以人为中心的安全机器人强化学习框架及交互行为。arXiv预印本 http://arxiv.org/abs/2302.13137

Gunning D, Stefik M, Choi J, Miller T, Stumpf S, Yang G-Z (2019) XAI—explainable artificial intelligence. Sci Robot 4(37):eaay7120

Gunning D, Stefik M, Choi J, Miller T, Stumpf S, Yang G-Z (2019) 可解释人工智能(Explainable Artificial Intelligence, XAI)。Sci Robot 4(37):eaay7120

Guo B, Zhang X, Wang Z, Jiang M, Nie J, Ding Y, Yue J, Wu Y (2023) How close is ChatGPT to human experts? Comparison corpus, evaluation, and detection. CoRR. abs/2301.07597

Guo B, Zhang X, Wang Z, Jiang M, Nie J, Ding Y, Yue J, Wu Y (2023) ChatGPT与人类专家的接近程度？对比语料库、评估与检测。CoRR. abs/2301.07597

He R, Sun S, Yang J, Bai S, Qi X (2022) Knowledge distillation as efficient pre-training: faster convergence, higher data-efficiency, and better transferability. In: Proceedings of the IEEE/CVF conference on computer vision and pattern recognition. pp 9161-9171

He R, Sun S, Yang J, Bai S, Qi X (2022) 知识蒸馏作为高效预训练方法:更快的收敛速度、更高的数据效率和更好的迁移能力。收录于:IEEE/CVF计算机视觉与模式识别会议论文集，页9161-9171

Hendrycks D, Gimpel K (2016) A baseline for detecting misclassified and out-of-distribution examples in neural networks. In: International conference on learning representations

Hendrycks D, Gimpel K (2016) 神经网络中误分类和分布外(Out-of-Distribution)样本检测的基线方法。收录于:国际表示学习会议

Hendrycks D, Liu X, Wallace E, Dziedzic A, Krishnan R, Song D (2020) Pretrained transformers improve out-of-distribution robustness. In: Proceedings of the 58th annual meeting of the association for computational linguistics. pp 2744-2751

Hendrycks D, Liu X, Wallace E, Dziedzic A, Krishnan R, Song D (2020) 预训练变换模型(Transformers)提升分布外鲁棒性。收录于:第58届计算语言学协会年会论文集，页2744-2751

Henzinger TA, Lukina A, Schilling C (2020) Outside the box: abstraction-based monitoring of neural networks. In: ECAI2020

Henzinger TA, Lukina A, Schilling C (2020) 超出常规:基于抽象的神经网络监控。收录于:ECAI2020

Hinton G, Vinyals O, Dean J (2015) Distilling the knowledge in a neural network. arXiv Preprint http:// arxiv.org/abs/1503.02531

Hinton G, Vinyals O, Dean J (2015) 知识蒸馏(Knowledge Distillation)技术。arXiv预印本 http://arxiv.org/abs/1503.02531

Hintze A (2023) ChatGPT believes it is conscious. arXiv Preprint http://arxiv.org/abs/2304.12898

Hintze A (2023) ChatGPT认为自己具有意识。arXiv预印本 http://arxiv.org/abs/2304.12898

Hoffmann J, Borgeaud S, Mensch A, Buchatskaya E, Cai T, Rutherford E, de Las Casas D, Hendricks LA, Welbl J, Clark A et al (2022) Training compute-optimal large language models. arXiv Preprint http://arxiv.org/abs/2203.15556

霍夫曼 J, 博尔戈奥 S, 门赫 A, 布查茨卡娅 E, 蔡 T, 露瑟福德 E, 德拉斯卡萨斯 D, 亨德里克斯 LA, 韦布尔 J, 克拉克 A 等 (2022) 训练计算最优的大型语言模型。arXiv 预印本 http://arxiv.org/abs/2203.15556

Holmes J, Liu Z, Zhang L, Ding Y, Sio TT, McGee LA, Ashman JB, Li X, Liu T, Shen J et al (2023) Evaluating large language models on a highly-specialized topic, radiation oncology physics. arXiv Preprint http://arxiv.org/abs/2304.01938

霍姆斯 J, 刘 Z, 张 L, 丁 Y, 西奥 TT, 麦基 LA, 阿什曼 JB, 李 X, 刘 T, 沈 J 等 (2023) 在高度专业化主题——放射肿瘤学物理学(radiation oncology physics)上评估大型语言模型。arXiv 预印本 http://arxiv.org/abs/2304.01938

Hosseini H, Kannan S, Zhang B, Poovendran R (2017) Deceiving Google's perspective API built for detecting toxic comments. arXiv Preprint http://arxiv.org/abs/1702.08138

侯塞尼 H, 卡南 S, 张 B, 波文德兰 R (2017) 欺骗谷歌的观点(perspective)API，该API旨在检测有害评论。arXiv 预印本 http://arxiv.org/abs/1702.08138

Houlsby N, Giurgiu A, Jastrzebski S, Morrone B, De Laroussilhe Q, Gesmundo A, Attariyan M, Gelly S (2019) Parameter-efficient transfer learning for NLP. In: International conference on machine learning. PMLR, pp 2790-2799

霍尔斯比 N, 朱尔吉乌 A, 雅斯特热斯基 S, 莫罗内 B, 德拉鲁西尔 Q, 格斯蒙多 A, 阿塔里扬 M, 格利 (Gelly S) (2019) 用于自然语言处理(NLP)的参数高效迁移学习。发表于:机器学习国际会议。PMLR，第2790-2799页

Hrinchuk O, Popova M, Ginsburg B (2020) Correction of automatic speech recognition with transformer sequence-to-sequence model. In: ICASSP 2020-2020 IEEE international conference on acoustics, speech and signal processing (ICASSP). IEEE, pp 7074-7078

赫林楚克 O, 波波娃 M, 金斯堡 B (2020) 使用变换器序列到序列模型(transformer sequence-to-sequence model)校正自动语音识别。发表于:2020年IEEE声学、语音与信号处理国际会议(ICASSP)。IEEE，第7074-7078页

Hu Z, Yang Z, Liang X, Salakhutdinov R, Xing EP (2017) Toward controlled generation of text. In: International conference on machine learning. PMLR, pp 1587-1596

胡 Z, 杨 Z, 梁 X, 萨拉库蒂诺夫 R, 邢 EP (2017) 迈向受控文本生成。发表于:机器学习国际会议。PMLR，第1587-1596页

Hu EJ, Shen Y, Wallis P, Allen-Zhu Z, Li Y, Wang S, Wang L, Chen W (2021) LoRA: low-rank adaptation of large language models. arXiv Preprint http://arxiv.org/abs/2106.09685

胡 EJ, 沈 Y, 沃利斯 P, 艾伦-朱 Z, 李 Y, 王 S, 王 L, 陈 W (2021) LoRA:大规模语言模型的低秩适应。arXiv预印本 http://arxiv.org/abs/2106.09685

Hu EJ, Shen Y, Wallis P, Allen-Zhu Z, Li Y, Wang S, Wang L, Chen W (2022) LoRA: low-rank adaptation of large language models. In: International conference on learning representations

胡 EJ, 沈 Y, 沃利斯 P, 艾伦-朱 Z, 李 Y, 王 S, 王 L, 陈 W (2022) LoRA:大规模语言模型的低秩适应。发表于:学习表征国际会议

Huang X, Jin G, Ruan W (2012) Machine learning basics. In: Machine learning safety. Springer, pp 3-13

黄 X, 金 G, 阮 W (2012) 机器学习基础。发表于:机器学习安全。Springer，第3-13页

Huang X, Kwiatkowska M, Wang S, Wu M (2017) Safety verification of deep neural networks. In: Majumdar R, Kuncak V (eds) Computer aided verification—29th international conference, CAV 2017, Heidelberg, Germany, July 24-28, 2017, proceedings, part I, volume 10426 of lecture notes in computer science. Springer, pp 3-29

黄 X, 克维亚特科斯卡 M, 王 S, 吴 M (2017) 深度神经网络的安全验证。发表于:Majumdar R, Kuncak V (编) 计算机辅助验证——第29届国际会议(CAV 2017)，德国海德堡，2017年7月24-28日，会议录第一部分，计算机科学讲义第10426卷。Springer，第3-29页

Huang P-S, Stanforth R, Welbl J, Dyer C, Yogatama D, Gowal S, Dvijotham K, Kohli P (2019a) Achieving verified robustness to symbol substitutions via interval bound propagation. arXiv Preprint http://arxiv.org/abs/1909.01492

黄 P-S, 斯坦福斯 R, 韦尔布 J, 迪耶 C, Yogatama D, 高瓦 S, 迪维乔塔姆 K, 科利 P (2019a) 通过区间界传播实现符号替换的验证鲁棒性。arXiv预印本 http://arxiv.org/abs/1909.01492

Huang X, Alzantot M, Srivastava M (2019b) NeuronInspect: detecting backdoors in neural networks via output explanations. arXiv Preprint http://arxiv.org/abs/1911.07399

黄 X, 阿尔赞托特 M, 斯里瓦斯塔 M (2019b) NeuronInspect:通过输出解释检测神经网络中的后门。arXiv预印本 http://arxiv.org/abs/1911.07399

Huang X, Kroening D, Ruan W, Sharp J, Sun Y, Thamo E, Wu M, Yi X (2020a) A survey of safety and trustworthiness of deep neural networks: verification, testing, adversarial attack and defence, and interpretability. Comput Sci Rev 37:100270

黄 X, 克罗宁 D, 阮 W, 夏普 J, 孙 Y, 塔莫 E, 吴 M, 易 X (2020a) 深度神经网络的安全性与可信性综述:验证、测试、对抗攻击与防御，以及可解释性。计算机科学评论 37:100270

Huang H, Li Z, Wang L, Chen S, Dong B, Zhou X (2020b) Feature space singularity for out-of-distribution detection. arXiv Preprint http://arxiv.org/abs/2011.14654

黄 H, 李 Z, 王 L, 陈 S, 董 B, 周 X (2020b) 特征空间奇异性用于检测分布外(out-of-distribution)样本。arXiv预印本 http://arxiv.org/abs/2011.14654

Huang W, Sun Y, Zhao X, Sharp J, Ruan W, Meng J, Huang X (2021) Coverage-guided testing for recurrent neural networks. IEEE Trans Reliab 71(3):1191-1206

黄 W, 孙 Y, 赵 X, 夏普 J, 阮 W, 孟 J, 黄 X (2021) 递归神经网络的覆盖引导测试。IEEE可靠性学报 71(3):1191-1206

Huang X, Ruan W, Tang Q, Zhao X (2022a) Bridging formal methods and machine learning with global optimisation. In: Formal methods and software engineering: ${23}\mathrm{{rd}}$ international conference on formal engineering methods, ICFEM 2022, Madrid, Spain, October 24-27, 2022, proceedings. Springer-Verlag, Berlin, Heidelberg, pp 1-19

黄 X, 阮 W, 唐 Q, 赵 X (2022a) 通过全局优化桥接形式方法与机器学习。发表于:形式方法与软件工程:国际形式工程方法会议(ICFEM 2022)，西班牙马德里，2022年10月24-27日，会议录。Springer-Verlag，柏林、海德堡，第1-19页

Huang W, Zhao X, Banks A, Cox V, Huang X (2022b) Hierarchical distribution-aware testing of deep learning. arXiv Preprint http://arxiv.org/abs/2205.08589

黄 W, 赵 X, 班克斯 A, 考克斯 V, 黄 X (2022b) 分层分布感知的深度学习测试。arXiv预印本 http://arxiv.org/abs/2205.08589

Huang W, Zhao X, Jin G, Huang X (2022c) Safari: versatile and efficient evaluations for robustness of interpretability. arXiv Preprint http://arxiv.org/abs/2208.09418

黄 W, 赵 X, 金 G, 黄 X (2022c) Safari:多功能高效的可解释性鲁棒性评估工具。arXiv预印本 http://arxiv.org/abs/2208.09418

Ilyas A, Santurkar S, Tsipras D, Engstrom L, Tran B, Madry A (2019) Adversarial examples are not bugs, they are features. In: Advances in neural information processing systems, vol 32

伊利亚斯 A, 桑图尔卡 S, 兹普拉斯 D, 恩格斯特罗姆 L, 陈 B, 马德 A (2019) 对抗样本不是漏洞，而是特征。发表于:神经信息处理系统进展，第32卷

Italy became the first western country to ban ChatGPT. https://www.cnbc.com/2023/04/04/italy-has banned-chatgpt-heres-what-other-countries-are-doing.html. Accessed 17 Aug 2023

意大利成为第一个禁止ChatGPT(聊天生成预训练变换模型)的西方国家。https://www.cnbc.com/2023/04/04/italy-has-banned-chatgpt-heres-what-other-countries-are-doing.html. 2023年8月17日查阅

Ivankay A, Girardi I, Marchiori C, Frossard P (2022) Fooling explanations in text classifiers. arXiv Preprint http://arxiv.org/abs/2206.03178

Ivankay A, Girardi I, Marchiori C, Frossard P (2022) 文本分类器中的欺骗性解释。arXiv预印本 http://arxiv.org/abs/2206.03178

Iyyer, M Wieting J, Gimpel K, Zettlemoyer L (2018) Adversarial example generation with syntactically controlled paraphrase networks. arXiv Preprint http://arxiv.org/abs/1804.06059

Iyyer, M Wieting J, Gimpel K, Zettlemoyer L (2018) 使用句法控制的释义网络生成对抗样本。arXiv预印本 http://arxiv.org/abs/1804.06059

Jaiswal A, Babu AR, Zadeh MZ, Banerjee D, Makedon F (2020) A survey on contrastive self-supervised learning. Technologies 9(1):2

Jaiswal A, Babu AR, Zadeh MZ, Banerjee D, Makedon F (2020) 对比自监督学习的综述。技术杂志 9(1):2

Jang M, Lukasiewicz T (2023) Consistency analysis of ChatGPT. arXiv Preprint http://arxiv.org/abs/2303.06273

Jang M, Lukasiewicz T (2023) ChatGPT的一致性分析。arXiv预印本 http://arxiv.org/abs/2303.06273

Jansen N, Könighofer B, Junges S, Bloem R (2018) Shielded decision-making in MDPs. arXiv Preprint http://arxiv.org/abs/1807.06096

Jansen N, Könighofer B, Junges S, Bloem R (2018) 马尔可夫决策过程(MDP)中的屏蔽决策。arXiv预印本 http://arxiv.org/abs/1807.06096

Jansen N, Könighofer B, Junges J, Serban A, Bloem R (2020) Safe reinforcement learning using probabilistic shields. Schloss Dagstuhl, Dagstuhl

Jansen N, Könighofer B, Junges J, Serban A, Bloem R (2020) 使用概率屏蔽的安全强化学习。达格斯堡城堡，达格斯堡

Ji Y, Gong Y, Peng Y, Ni C, Sun P, Pan D, Ma B, Li X (2023) Exploring ChatGPT's ability to rank content: a preliminary study on consistency with human preferences

Ji Y, Gong Y, Peng Y, Ni C, Sun P, Pan D, Ma B, Li X (2023) 探索ChatGPT的内容排序能力:关于与人类偏好一致性的初步研究

Jia R, Liang P (2017) Adversarial examples for evaluating reading comprehension systems. arXiv Preprint http://arxiv.org/abs/1707.07328

Jia R, Liang P (2017) 用于评估阅读理解系统的对抗样本。arXiv预印本 http://arxiv.org/abs/1707.07328

Jia R, Raghunathan A, Göksel K, Liang P (2019) Certified robustness to adversarial word substitutions. arXiv Preprint http://arxiv.org/abs/1909.00986

Jia R, Raghunathan A, Göksel K, Liang P (2019) 对抗词替换的认证鲁棒性。arXiv预印本 http://arxiv.org/abs/1909.00986

Jiang AQ, Welleck S, Zhou JP, Li W, Liu J, Jamnik M, Lacroix T, Wu Y, Lample G (2022) Draft, sketch, and prove: guiding formal theorem provers with informal proofs. arXiv Preprint http://arxiv.org/abs/ 2210.12283

Jiang AQ, Welleck S, Zhou JP, Li W, Liu J, Jamnik M, Lacroix T, Wu Y, Lample G (2022) 草稿、草图与证明:用非正式证明引导形式定理证明器。arXiv预印本 http://arxiv.org/abs/ 2210.12283

Jiao W, Wang W, Huang J-t, Wang X, Tu Z (2023) Is ChatGPT a good translator? A preliminary study. arXiv Preprint http://arxiv.org/abs/2301.08745

Jiao W, Wang W, Huang J-t, Wang X, Tu Z (2023) ChatGPT是一个好翻译吗？一项初步研究。arXiv预印本 http://arxiv.org/abs/2301.08745

Jin D, Jin Z, Zhou JT, Szolovits P (2020) Is BERT really robust? A strong baseline for natural language attack on text classification and entailment. In: Proceedings of the AAAI conference on artificial intelligence, vol 34. pp 8018-8025

Jin D, Jin Z, Zhou JT, Szolovits P (2020) BERT真的具有鲁棒性吗？针对文本分类和蕴含任务的强大自然语言攻击基线。发表于:人工智能会议(AAAI)论文集，第34卷，第8018-8025页

Kalyan KS, Rajasekharan A, Sangeetha S (2021) AMMUS: a survey of transformer-based pretrained models in natural language processing. arXiv Preprint http://arxiv.org/abs/2108.05542

Kalyan KS, Rajasekharan A, Sangeetha S (2021) AMMUS:基于变换器(Transformer)的预训练模型在自然语言处理中的综述。arXiv预印本 http://arxiv.org/abs/2108.05542

Kambhampati S (2022) Changing the nature of AI research. Commun ACM 65(9):8-9

Kambhampati S (2022) 改变人工智能研究的本质。Commun ACM 65(9):8-9

Kande R, Pearce H, Tan B, Dolan-Gavitt B, Thakur S, Karri R, Rajendran J (2023) LLM-assisted generation of hardware assertions. CoRR. abs/2306.14027

Kande R, Pearce H, Tan B, Dolan-Gavitt B, Thakur S, Karri R, Rajendran J (2023) 利用大规模语言模型(LLM)辅助生成硬件断言。CoRR. abs/2306.14027

Kang D, Li X, Stoica I, Guestrin C, Zaharia M, Hashimoto T (2023a) Exploiting programmatic behavior of LLMS: dual-use through standard security attacks. arXiv Preprint http://arxiv.org/abs/2302.05733

Kang D, Li X, Stoica I, Guestrin C, Zaharia M, Hashimoto T (2023a) 利用大语言模型(LLMS)的程序行为:通过标准安全攻击实现双重用途。arXiv预印本 http://arxiv.org/abs/2302.05733

Kang Y, Zhang Q, Roth R (2023b) The ethics of AI-generated maps: a study of DALLE 2 and implications for cartography. arXiv Preprint http://arxiv.org/abs/2304.10743

Kang Y, Zhang Q, Roth R (2023b) AI生成地图的伦理问题:以DALLE 2为例的研究及对制图学的启示。arXiv预印本 http://arxiv.org/abs/2304.10743

Kaplan J, McCandlish S, Henighan T, Brown TB, Chess B, Child R, Gray S, Radford A, Wu J, Amodei D (2020) Scaling laws for neural language models. arXiv Preprint http://arxiv.org/abs/2001.08361

Kaplan J, McCandlish S, Henighan T, Brown TB, Chess B, Child R, Gray S, Radford A, Wu J, Amodei D (2020) 神经语言模型的规模定律。arXiv预印本 http://arxiv.org/abs/2001.08361

Katz DM, Bommarito MJ, Gao S, Arredondo P (2023) GPT-4 passes the bar exam. Available at SSRN 4389233

Katz DM, Bommarito MJ, Gao S, Arredondo P (2023) GPT-4通过律师资格考试。可在SSRN 4389233获取

Khoury R, Avila AR, Brunelle J, Camara BM (2023) How secure is code generated by ChatGPT? arXiv Preprint http://arxiv.org/abs/2304.09655

Khoury R, Avila AR, Brunelle J, Camara BM (2023) ChatGPT生成的代码安全性如何？arXiv预印本 http://arxiv.org/abs/2304.09655

Kim Y-M (2023) Data and fair use. Korea Copyright Commission 141:5-53

Kim Y-M (2023) 数据与合理使用。韩国版权委员会 141:5-53

Ko C-Y, Lyu Z, Weng L, Daniel L, Wong N, Lin D (2019) POPQORN: quantifying robustness of recurrent neural networks. In: International conference on machine learning. PMLR, pp 3468-3477

Ko C-Y, Lyu Z, Weng L, Daniel L, Wong N, Lin D (2019) POPQORN:量化循环神经网络的鲁棒性。在:国际机器学习会议。PMLR，第3468-3477页

Koh JY, Fried D, Salakhutdinov R (2023) Generating images with multimodal language models. arXiv Preprint http://arxiv.org/abs/2305.17216

Koh JY, Fried D, Salakhutdinov R (2023) 使用多模态语言模型生成图像。arXiv预印本 http://arxiv.org/abs/2305.17216

Kuleshov V, Thakoor S, Lau T, Ermon S (2018) Adversarial examples for natural language classification problems. arXiv Preprint

Kuleshov V, Thakoor S, Lau T, Ermon S (2018) 自然语言分类问题的对抗样本。arXiv预印本

Kumar A, Ahuja K, Vadapalli R, Talukdar P (2020) Syntax-guided controlled generation of paraphrases. Trans Assoc Comput Linguist 8:330-345

Kumar A, Ahuja K, Vadapalli R, Talukdar P (2020) 语法引导的语义重述控制生成。计算语言学协会交易 8:330-345

Kurita K, Michel P, Neubig G (2020) Weight poisoning attacks on pretrained models. In: Proceedings of the 58th annual meeting of the association for computational linguistics. pp 2793-2806

Kurita K, Michel P, Neubig G (2020) 预训练模型的权重中毒攻击。在:第58届计算语言学协会年会论文集。第2793-2806页

La Malfa E, Wu M, Laurenti L, Wang B, Hartshorn A, Kwiatkowska M (2020) Assessing robustness of text classification through maximal safe radius computation. arXiv Preprint http://arxiv.org/abs/2010.02004

La Malfa E, Wu M, Laurenti L, Wang B, Hartshorn A, Kwiatkowska M (2020) 通过最大安全半径计算评估文本分类的鲁棒性。arXiv预印本 http://arxiv.org/abs/2010.02004

Lam M, Sethi R, Ullman JD, Aho A (2006) Compilers: principles, techniques, and tools. Pearson Education

Lam M, Sethi R, Ullman JD, Aho A (2006) 编译器:原理、技术与工具。Pearson Education

Lambert N, Castricato L, von Werra L, Havrilla A (2022) Illustrating reinforcement learning from human feedback (RLHF). Hugging Face Blog. https://huggingface.co/blog/rlhf

Lambert N, Castricato L, von Werra L, Havrilla A (2022) 说明基于人类反馈的强化学习(RLHF)。Hugging Face博客 https://huggingface.co/blog/rlhf

Lan Z, Chen M, Goodman S, Gimpel K, Sharma P, Soricut R (2019) Albert: a lite BERT for self-supervised learning of language representations. arXiv Preprint http://arxiv.org/abs/1909.11942

Lan Z, Chen M, Goodman S, Gimpel K, Sharma P, Soricut R (2019) Albert:一种轻量级的BERT，用于自监督学习语言表示。arXiv预印本 http://arxiv.org/abs/1909.11942

Lee P (2016) Learning from Tay’s introduction. https://blogs.microsoft.com/blog/2016/03/25/learning-tays-introduction/.Accessed 20 Aug 2023

Lee P (2016) 从Tay的介绍中学习。https://blogs.microsoft.com/blog/2016/03/25/learning-tays-introduction/。2023年8月20日访问

Lee JY (2023) Can an artificial intelligence chatbot be the author of a scholarly article? J Educ Eval Health Prof 20:6

李JY(2023)人工智能聊天机器人能成为学术论文的作者吗？教育评估与健康专业杂志 20:6

Lee C, Cho K, Kang W (2019) Mixout: effective regularization to finetune large-scale pretrained language models. arXiv Preprint http://arxiv.org/abs/1909.11299

李C，赵K，姜W(2019)Mixout:有效的正则化方法，用于微调大规模预训练语言模型。arXiv预印本 http://arxiv.org/abs/1909.11299

Lee N, Bang Y, Madotto A, Fung P (2020) Misinformation has high perplexity. arXiv Preprint http://arxiv.org/abs/2006.04666

李N，邦Y，马多托A，冯P(2020)虚假信息具有高困惑度。arXiv预印本 http://arxiv.org/abs/2006.04666

Lee K, Liu H, Ryu M, Watkins O, Du Y, Boutilier C, Abbeel P, Ghavamzadeh M, Gu SS (2023) Aligning text-to-image models using human feedback. arXiv Preprint http://arxiv.org/abs/2302.12192

李K，刘H，柳M，沃金斯O，杜Y，布蒂利尔C，阿贝尔P，盖瓦姆扎德H，顾SS(2023)使用人类反馈对文本到图像模型进行对齐。arXiv预印本 http://arxiv.org/abs/2302.12192

Lei Y, Cao Y, Li D, Zhou T, Fang M, Pechenizkiy M (2022) Phrase-level textual adversarial attack with label preservation. arXiv Preprint http://arxiv.org/abs/2205.10710

雷Y，曹Y，李D，周T，方M，佩切纽基M(2022)带标签保持的短语级文本对抗攻击。arXiv预印本 http://arxiv.org/abs/2205.10710

Lepikhin D, Lee H, Xu Y, Chen D, Firat O, Huang Y, Krikun M, Shazeer N, Chen Z (2020) GShard: scaling giant models with conditional computation and automatic sharding. arXiv Preprint http://arxiv.org/ abs/2006.16668

莱皮欣D，李H，徐Y，陈D，菲拉特O，黄Y，克里坤M，沙泽尔N，陈Z(2020)GShard:利用条件计算和自动分片扩展巨型模型。arXiv预印本 http://arxiv.org/abs/2006.16668

Lewis M, Liu Y, Goyal N, Ghazvininejad M, Mohamed A, Levy O, Stoyanov V, Zettlemoyer L (2020) BART: denoising sequence-to-sequence pre-training for natural language generation, translation, and comprehension. In: Proceedings of the 58th annual meeting of the association for computational linguistics, Online, July 2020. Association for Computational Linguistics, pp 7871-7880

刘M，刘Y，戈雅N，盖兹维尼贾德M，穆罕默德A，莱维O，斯托扬诺夫V，泽特勒莫耶L(2020)BART:用于自然语言生成、翻译和理解的去噪序列到序列预训练。在:第58届计算语言学协会年会论文集，线上，2020年7月。计算语言学协会，第7871-7880页

Li J, Ji S, Du T, Li B, Wang T (2018a) TextBugger: generating adversarial text against real-world applications. arXiv Preprint http://arxiv.org/abs/1812.05271

李J，季S，杜T，李B，王T(2018a)TextBugger:针对实际应用生成对抗文本。arXiv预印本 http://arxiv.org/abs/1812.05271

Li Y, Ding L, Gao X (2018b) On the decision boundary of deep neural networks. arXiv Preprint http://arxiv.org/abs/1808.05385

李Y，丁L，高X(2018b)关于深度神经网络的决策边界。arXiv预印本 http://arxiv.org/abs/1808.05385

Li S, Liu H, Dong T, Zhao BZH, Xue M, Zhu H, Lu J (2021a) Hidden backdoors in human-centric language models. In: CCS '21: 2021 ACM SIGSAC conference on computer and communications security, virtual event, Republic of Korea, November 15-19, 2021. ACM, pp 3123-3140

李S，刘H，董T，赵BZH，薛M，朱H，卢J(2021a)人类中心语言模型中的隐藏后门。在:2021年ACM SIGSAC计算机与通信安全会议(CCS '21)，虚拟会议，韩国，2021年11月15-19日。ACM，第3123-3140页

Li X, Li J, Sun X, Fan C, Zhang T, Wu F, Meng Y, Zhang J (2021b) kFolden: k -fold ensemble for out-of-distribution detection-fold ensemble for out-of-distribution detection. In: Proceedings of the 2021 conference on empirical methods in natural language processing. pp 3102-3115

李X，李J，孙X，范C，张T，吴F，孟Y，张J(2021b)kFolden:用于检测分布外的k折集成方法。在:2021年自然语言处理经验方法会议论文集，第3102-3115页

Li J, Tang T, Zhao WX, Nie JY, Wen J-R (2022) Pretrained language models for text generation: a survey. arXiv Preprint http://arxiv.org/abs/2201.05273

李J，唐T，赵WX，聂JY，温J-R(2022)预训练语言模型的文本生成:综述。arXiv预印本 http://arxiv.org/abs/2201.05273

Li J, Cheng X, Zhao WX, Nie J-Y, Wen J-R (2023a) HaluEval: a large-scale hallucination evaluation benchmark for large language models. arXiv e-prints, p arXiv-2305

李J，程X，赵WX，聂J-Y，温J-R(2023a)HaluEval:大规模幻觉评估基准，用于大型语言模型。arXiv电子预印本，arXiv-2305

Li H, Guo D, Fan W, Xu M, Song Y (2023b) Multi-step jailbreaking privacy attacks on ChatGPT. arXiv Preprint http://arxiv.org/abs/2304.05197

李H，郭D，范W，徐M，宋Y(2023b)对ChatGPT的多步骤越狱隐私攻击。arXiv预印本 http://arxiv.org/abs/2304.05197

Liang B, Li H, Su M, Bian P, Li X, Shi W (2017) Deep text classification can be fooled. arXiv Preprint http://arxiv.org/abs/1704.08006

梁B，李H，苏M，边P，李X，石W(2017)深度文本分类可以被欺骗。arXiv预印本 http://arxiv.org/abs/1704.08006

Liang S, Li Y, Srikant R (2018) Enhancing the reliability of out-of-distribution image detection in neural networks. In: 6th international conference on learning representations, ICLR 2018

梁S，李Y，斯里坎特R(2018)提升神经网络中分布外图像检测的可靠性。在:第6届表示学习国际会议(ICLR 2018)

Lin T-Y, Maire M, Belongie S, Hays J, Perona P, Ramanan, D Dollár P, Zitnick CL (2014) Microsoft COCO: common objects in context. In: Computer vision-ECCV 2014: 13th European conference, Zurich, Switzerland, September 6-12, 2014, proceedings, part V 13. Springer, pp 740-755

Lin T-Y, Maire M, Belongie S, Hays J, Perona P, Ramanan, D Dollár P, Zitnick CL (2014) 微软COCO:上下文中的常见对象。收录于:计算机视觉-ECCV 2014:第13届欧洲会议，瑞士苏黎世，2014年9月6-12日，论文集，第V部分，第740-755页

Lin Z, Xu P, Winata GI, Siddique FB, Liu Z, Shin J, Fung P (2019) CAiRE: an empathetic neural chatbot. arXiv Preprint http://arxiv.org/abs/1907.12108

Lin Z, Xu P, Winata GI, Siddique FB, Liu Z, Shin J, Fung P (2019) CAiRE:一个具有同理心的神经聊天机器人。arXiv预印本 http://arxiv.org/abs/1907.12108

Liu Y, Ott M, Goyal N, Du J, Joshi M, Chen D, Levy O, Lewis M, Zettlemoyer L, Stoyanov V (2019) Roberta: a robustly optimized BERT pretraining approach. arXiv Preprint http://arxiv.org/abs/1907.11692

Liu Y, Ott M, Goyal N, Du J, Joshi M, Chen D, Levy O, Lewis M, Zettlemoyer L, Stoyanov V (2019) Roberta:一种稳健优化的BERT预训练方法。arXiv预印本 http://arxiv.org/abs/1907.11692

Liu W, Wang X, Owens J, Li Y (2020) Energy-based out-of-distribution detection. Adv Neural Inf Process Syst 33:21464-21475

Liu W, Wang X, Owens J, Li Y (2020) 基于能量的分布外检测。神经信息处理系统进展 33:21464-21475

Liu C, Arnon T, Lazarus C, Strong C, Barrett C, Kochenderfer MJ et al (2021a) Algorithms for verifying deep neural networks. Found Trends Optim 4(3-4):244-404

Liu C, Arnon T, Lazarus C, Strong C, Barrett C, Kochenderfer MJ 等 (2021a) 深度神经网络验证算法。优化基础趋势 4(3-4):244-404

Liu X, Zhang F, Hou Z, Mian L, Wang Z, Zhang J, Tang J (2021b) Self-supervised learning: generative or contrastive. IEEE Trans Knowl Data Eng 35(1):857-876

Liu X, Zhang F, Hou Z, Mian L, Wang Z, Zhang J, Tang J (2021b) 自监督学习:生成式还是对比式。IEEE知识与数据工程学报 35(1):857-876

Liu Z, Wang Y, Han K, Zhang W, Ma S, Gao W (2021c) Post-training quantization for vision transformer. Adv Neural Inf Process Syst 34:28092-28103

Liu Z, Wang Y, Han K, Zhang W, Ma S, Gao W (2021c) 视觉变换器的后训练量化。神经信息处理系统进展 34:28092-28103

Liu Y, Han T, Ma S, Zhang J, Yang Y, Tian J, He H, Li A, He M, Liu Z et al (2023a) Summary of ChatGPT/ GPT-4 research and perspective towards the future of large language models. arXiv Preprint http:// arxiv.org/abs/2304.01852

Liu Y, Han T, Ma S, Zhang J, Yang Y, Tian J, He H, Li A, He M, Liu Z 等 (2023a) ChatGPT/GPT-4研究总结及对大型语言模型未来的展望。arXiv预印本 http:// arxiv.org/abs/2304.01852

Liu H, Ning R, Teng Z, Liu J, Zhou Q, Zhang Y (2023b) Evaluating the logical reasoning ability of Chat-GPT and GPT-4. arXiv Preprint http://arxiv.org/abs/2304.03439

Liu H, Ning R, Teng Z, Liu J, Zhou Q, Zhang Y (2023b) Chat-GPT和GPT-4的逻辑推理能力评估。arXiv预印本 http://arxiv.org/abs/2304.03439

Liu J, Xia CS, Wang Y, Zhang L (2023c) Is your code generated by ChatGPT really correct? Rigorous evaluation of large language models for code generation. arXiv Preprint http://arxiv.org/abs/2305.01210

Liu J, Xia CS, Wang Y, Zhang L (2023c) 你的代码由ChatGPT生成的真的正确吗？大规模语言模型在代码生成中的严格评估。arXiv预印本 http://arxiv.org/abs/2305.01210

Liu Z, Yu X, Zhang L, Wu Z, Cao C, Dai H, Zhao L, Liu W, Shen D, Li Q et al (2023d) DeID-GPT: zero-shot medical text de-identification by GPT-4. arXiv Preprint http://arxiv.org/abs/2303.11032

Liu Z, Yu X, Zhang L, Wu Z, Cao C, Dai H, Zhao L, Liu W, Shen D, Li Q 等 (2023d) DeID-GPT:利用GPT-4实现零样本医疗文本去识别。arXiv预印本 http://arxiv.org/abs/2303.11032

Lou R, Zhang K, Yin W (2023) Is prompt all you need? No. A comprehensive and broader view of instruction learning. arXiv Preprint http://arxiv.org/abs/2303.10475

Lou R, Zhang K, Yin W (2023) 仅靠提示就够了吗？对指令学习的全面与更广阔的视角。arXiv预印本 http://arxiv.org/abs/2303.10475

Madaan N, Padhi I, Panwar N, Saha D (2021) Generate your counterfactuals: towards controlled counterfactual generation for text. In: Proceedings of the AAAI conference on artificial intelligence, vol 35. pp 13516-13524

Madaan N, Padhi I, Panwar N, Saha D (2021) 生成你的反事实:面向受控反事实生成的文本。收录于:第35届人工智能会议论文集，第13516-13524页

Madry A, Makelov A, Schmidt L, Tsipras D, Vladu A (2017) Towards deep learning models resistant to adversarial attacks. arXiv Preprint http://arxiv.org/abs/1706.06083

Madry A, Makelov A, Schmidt L, Tsipras D, Vladu A (2017) 迈向对抗攻击具有抗性的深度学习模型。arXiv预印本 http://arxiv.org/abs/1706.06083

Malinka K, Peresíni M, Firc A, Hujnák O, Janus F (2023) On the educational impact of ChatGPT: is artificial intelligence ready to obtain a university degree? In: Proceedings of the 2023 conference on innovation and technology in computer science education V. 1. pp 47-53

Malinka K, Peresíni M, Firc A, Hujnák O, Janus F (2023) ChatGPT的教育影响:人工智能是否已准备好获得大学学位？收录于:2023年计算机科学教育创新与技术会议论文集，第1卷，第47-53页

Manna Z, Pnueli A (2012) The temporal logic of reactive and concurrent systems: specification. Springer Science & Business Media, Berlin

Manna Z, Pnueli A (2012) 反应式与并发系统的时序逻辑:规范。施普林格科学与商业媒体，柏林

March 20 ChatGPT outage: here's what happened. https://openai.com/blog/march-20-chatgpt-outage.Ope-nAI.Accessed 20 Aug 2023

3月20日ChatGPT故障:发生了什么。https://openai.com/blog/march-20-chatgpt-outage.Ope-nAI.访问时间:2023年8月20日

Maus N, Chao P, Wong E, Gardner J (2023) Adversarial prompting for black box foundation models. arXiv Preprint http://arxiv.org/abs/2302.04237

Ma N, Chao P, Wong E, Gardner J (2023) 对抗性提示(Adversarial prompting)在黑箱基础模型中的应用。arXiv预印本 http://arxiv.org/abs/2302.04237

McCune W (2005) Prover9 and Mace4. https://www.cs.unm.edu/~mccune/prover9/.Accessed 20 Aug 2023

McCune W (2005) Prover9与Mace4。https://www.cs.unm.edu/~mccune/prover9/。访问时间:2023年8月20日

Mehdi Y (2023) Announcing the next wave of AI innovation with Microsoft Bing and Edge

Mehdi Y (2023) 宣布微软必应(Bing)和Edge引领的下一波人工智能创新

Min S, Lyu X, Holtzman A, Artetxe M, Lewis M, Hajishirzi H, Zettlemoyer L (2022) Rethinking the role of demonstrations: what makes in-context learning work? arXiv Preprint http://arxiv.org/abs/2202.12837

Min S, Lyu X, Holtzman A, Artetxe M, Lewis M, Hajishirzi H, Zettlemoyer L (2022) 重新思考示范(demonstrations)的作用:什么使得上下文学习(in-context learning)奏效？arXiv预印本 http://arxiv.org/abs/2202.12837

Mirman M, Gehr T, Vechev M (2018) Differentiable abstract interpretation for provably robust neural networks. In: Dy J, Krause A (eds) Proceedings of the 35th international conference on machine learning, volume 80 of proceedings of machine learning research, 10-15 July 2018. PMLR, pp 3578-3586

Mirman M, Gehr T, Vechev M (2018) 可证明鲁棒(robust)神经网络的可微抽象解释。在:Dy J, Krause A(编)第35届国际机器学习会议论文集，机器学习研究会议论文集第80卷，2018年7月10-15日。PMLR，第3578-3586页

Mitrović S, Andreoletti D, Ayoub O (2023) ChatGPT or human? Detect and explain. Explaining decisions of machine learning model for detecting short ChatGPT-generated text

Mitrović S, Andreoletti D, Ayoub O (2023) ChatGPT还是人类？检测与解释。用于检测短篇ChatGPT生成文本的机器学习模型决策解释

Monteiro J, Albuquerque I, Akhtar Z, Falk TH (2019) Generalizable adversarial examples detection based on bi-model decision mismatch. In: 2019 IEEE international conference on systems, man and cybernetics (SMC). IEEE, pp 2839-2844

Monteiro J, Albuquerque I, Akhtar Z, Falk TH (2019) 基于双模型决策不匹配的泛化对抗样本检测。In:2019年IEEE系统、人类与控制(SMC)国际会议。IEEE，第2839-2844页

Nagel M, Amjad RA, Van Baalen M, Louizos C, Blankevoort T (2020) Up or down? Adaptive rounding for post-training quantization. In: International conference on machine learning. PMLR, pp 7197-7206

Nagel M, Amjad RA, Van Baalen M, Louizos C, Blankevoort T (2020) 上升还是下降？自适应四舍五入(rounding)用于训练后量化。In:国际机器学习会议。PMLR，第7197-7206页

Nelson B, Barreno M, Chi FJ, Joseph AD, Rubinstein BIP, Saini U, Sutton C, Tygar JD, Xia K (2008) Exploiting machine learning to subvert your spam filter. In: Proceedings of the 1st Usenix workshop on large-scale exploits and emergent threats, LEET'08, USA, 2008. USENIX Association

Nelson B, Barreno M, Chi FJ, Joseph AD, Rubinstein BIP, Saini U, Sutton C, Tygar JD, Xia K (2008) 利用机器学习颠覆你的垃圾邮件过滤器。In:第一届USENIX大规模利用与新兴威胁研讨会(LEET'08)，美国，2008年。USENIX协会

News TH (2023) WormGPT: new AI tool allows cybercriminals to launch sophisticated cyber attacks. https://thehackernews.com/2023/07/wormgpt-new-ai-tool-allows.html.Accessed 20 Aug 2023

News TH (2023) WormGPT:一种新型AI工具，使网络犯罪分子能够发动复杂的网络攻击。https://thehackernews.com/2023/07/wormgpt-new-ai-tool-allows.html. 访问时间:2023年8月20日

Ni A, Iyer S, Radev D, Stoyanov V, Yih W-t, Wang S, Lin XV (2023) Lever: learning to verify language-to-code generation with execution. In: International conference on machine learning. PMLR, pp 26106-26128

Ni A, Iyer S, Radev D, Stoyanov V, Yih W-t, Wang S, Lin XV (2023) Lever:学习验证语言到代码(language-to-code)生成的执行效果。In:国际机器学习会议。PMLR，第26106-26128页

Nichol A, Dhariwal P, Ramesh A, Shyam P, Mishkin P, McGrew B, Sutskever I, Chen M (2021) Glide: towards photorealistic image generation and editing with text-guided diffusion models. arXiv Preprint http://arxiv.org/abs/2112.10741

Nichol A, Dhariwal P, Ramesh A, Shyam P, Mishkin P, McGrew B, Sutskever I, Chen M (2021) Glide:朝着文本引导的扩散模型(diffusion models)实现逼真图像生成与编辑的目标。arXiv预印本 http://arxiv.org/abs/2112.10741

Nie Y, Williams A, Dinan E, Bansal M, Weston J, Kiela D (2019) Adversarial NLI: a new benchmark for natural language understanding. arXiv Preprint http://arxiv.org/abs/1910.14599

Nie Y, Williams A, Dinan E, Bansal M, Weston J, Kiela D (2019) 对抗性自然语言推理(NLI):自然语言理解(NLU)的新基准。arXiv预印本 http://arxiv.org/abs/1910.14599

OpenAI (2023) GPT-4 technical report. arXiv e-prints http://arxiv.org/abs/2303.08774

OpenAI (2023) GPT-4技术报告。arXiv电子预印本 http://arxiv.org/abs/2303.08774

OpenAI says a bug leaked sensitive ChatGPT user data. https://www.engadget.com/chatgpt-briefly-went-offline-after-a-bug-revealed-user-chat-histories-115632504.html.Engadget.Accessed 20 Aug 2023

OpenAI表示一次漏洞泄露了敏感的ChatGPT用户数据。https://www.engadget.com/chatgpt-briefly-went-offline-after-a-bug-revealed-user-chat-histories-115632504.html. 访问时间:2023年8月20日

Ouyang L, Wu J, Jiang X, Almeida D, Wainwright C, Mishkin P, Zhang C, Agarwal S, Slama K, Ray A et al (2022) Training language models to follow instructions with human feedback. Adv Neural Inf Process Syst 35:27730-27744

欧阳L, 吴J, 江X, Almeida D, Wainwright C, Mishkin P, 张C, Agarwal S, Slama K, Ray A 等 (2022) 使用人类反馈训练语言模型以遵循指令。神经信息处理系统进展 35:27730-27744

Pan S, Luo L, Wang Y, Chen C, Wang J, Wu X (2023) Unifying large language models and knowledge graphs: a roadmap

潘S, 罗L, 王Y, 陈C, 王J, 吴X (2023) 统一大型语言模型与知识图谱:一份路线图

Pang G, Shen C, Cao L, Hengel AVD (2021) Deep learning for anomaly detection: a review. ACM Comput Surv (CSUR) 54(2):1-38

庞G, 沈C, 曹L, Hengel AVD (2021) 深度学习在异常检测中的应用:综述。ACM计算机综述(CSUR)54(2):1-38

Park G, Park B, Kwon SJ, Kim B, Lee Y, Lee D (2022) nuQmm: quantized MatMul for efficient inference of large-scale generative language models. arXiv Preprint http://arxiv.org/abs/2206.09557

朴G, 朴B, 权SJ, 金B, 李Y, 李D (2022) nuQmm:用于大规模生成式语言模型高效推理的量化矩阵乘法。arXiv预印本 http://arxiv.org/abs/2206.09557

Patterson D, Gonzalez J, Holzle U, Le Q, Liang C, Munguia L-M, Rothchild D, So DR, Texier M, Dean J (2022) The carbon footprint of machine learning training will plateau, then shrink. Computer 55(7):18-28

帕特森D, 冈萨雷斯J, 霍尔茨U, Le Q, 梁C, Munguia L-M, Rothchild D, So DR, Texier M, Dean J (2022) 机器学习训练的碳足迹将达到平台期，然后缩减。计算机 55(7):18-28

Pause giant AI experiments: an open letter. https://futureoflife.org/open-letter/pause-giant-ai-experiments/.Accessed 20 Aug 2023

暂停巨型AI实验:一封公开信。https://futureoflife.org/open-letter/pause-giant-ai-experiments/。2023年8月20日查阅

Pearce H, Tan B, Ahmad B, Karri R, Dolan-Gavitt B (2023) Examining zero-shot vulnerability repair with large language models. In: 2023 IEEE symposium on security and privacy (SP). IEEE, pp 2339-2356

皮尔斯H, 陈B, 艾哈迈德B, 卡里R, 多兰-Gavitt B (2023) 探讨大规模语言模型的零样本漏洞修复。在:2023 IEEE安全与隐私研讨会(SP)。IEEE，第2339-2356页

Pegoraro A, Kumari K, Fereidooni H, Sadeghi A-R (2023) To ChatGPT, or not to ChatGPT: that is the question! arXiv Preprint http://arxiv.org/abs/2304.01487

佩戈拉罗A, 库马里K, 费雷伊杜尼H, 萨德吉A-R (2023) 是选择ChatGPT还是不选择ChatGPT:这是个问题！arXiv预印本 http://arxiv.org/abs/2304.01487

Peng B, Li C, He P, Galley M, Gao J (2023) Instruction tuning with GPT-4. arXiv Preprint http://arxiv.org/ abs/2304.03277

彭B, 李C, 何P, Galley M, 高J (2023) 使用GPT-4进行指令调优。arXiv预印本 http://arxiv.org/abs/2304.03277

Pennington J, Socher R, Manning CD (2014) Glove: global vectors for word representation. In: Proceedings of the 2014 conference on empirical methods in natural language processing (EMNLP). pp ${1532} - {1543}$

彭宁顿J, 索彻R, 曼宁CD (2014) GloVe:用于词表示的全局向量。在:2014年自然语言处理经验方法会议(EMNLP)论文集。第${1532} - {1543}$页

Perez F, Ribeiro I (2022) Ignore previous prompt: attack techniques for language models. arXiv Preprint http://arxiv.org/abs/2211.09527

佩雷斯F, 里贝罗I (2022) 忽略之前的提示:针对语言模型的攻击技术。arXiv预印本 http://arxiv.org/abs/2211.09527

Podolskiy A, Lipin D, Bout A, Artemova E, Piontkovskaya I (2021) Revisiting Mahalanobis distance for transformer-based out-of-domain detection. In: Proceedings of the AAAI conference on artificial intelligence, vol 35. pp 13675-13682

波多尔斯基A, 利平D, 布特A, 阿尔特莫娃E, 皮昂特科夫斯卡娅I (2021) 重新审视用于变换器(transformer)域外检测的马哈拉诺比斯距离。在:人工智能AAA会议论文集，第35卷，第13675-13682页

Prompt engineering guide. https://github.com/dair-ai/Prompt-Engineering-Guide/tree/main/guides.Accessed 20 Aug 2023

提示工程指南。https://github.com/dair-ai/Prompt-Engineering-Guide/tree/main/guides。2023年8月20日查阅

Qi Y, Zhao X, Huang X (2023) Safety analysis in the era of large language models: a case study of STPA using ChatGPT. arXiv Preprint http://arxiv.org/abs/2304.01246

齐Y, 赵X, 黄X (2023) 大型语言模型时代的安全性分析:以ChatGPT为例的STPA案例研究。arXiv预印本 http://arxiv.org/abs/2304.01246

Radford A, Jozefowicz R, Sutskever I (2017) Learning to generate reviews and discovering sentiment. arXiv Preprint http://arxiv.org/abs/1704.01444

拉德福德A, 乔泽福维奇R, 萨茨克弗I (2017) 学习生成评论并发现情感。arXiv预印本 http://arxiv.org/abs/1704.01444

Radford A, Narasimhan K, Salimans T, Sutskever I et al (2018) Improving language understanding by generative pre-training. OpenAI

拉德福德A, 纳拉西姆汉K, 萨利曼斯T, 萨茨克弗I 等 (2018) 通过生成式预训练提升语言理解能力。OpenAI

Rae JW, Borgeaud S, Cai T, Millican K, Hoffmann J, Song F, Aslanides J, Henderson S, Ring R, Young S et al (2021) Scaling language models: methods, analysis & insights from training Gopher. arXiv Preprint http://arxiv.org/abs/2112.11446

Rae JW, Borgeaud S, Cai T, Millican K, Hoffmann J, Song F, Aslanides J, Henderson S, Ring R, Young S 等 (2021) 扩展语言模型:训练Gopher的方法、分析与见解。arXiv预印本 http://arxiv.org/abs/2112.11446

Raffel C, Shazeer N, Roberts A, Lee K, Narang S, Matena M, Zhou Y, Li W, Liu PJ (2020) Exploring the limits of transfer learning with a unified text-to-text transformer. J Mach Learn Res 21(1):5485-5551

Raffel C, Shazeer N, Roberts A, Lee K, Narang S, Matena M, Zhou Y, Li W, Liu PJ (2020) 探索统一文本到文本变换器在迁移学习中的极限。机器学习研究杂志 21(1):5485-5551

Ramamurthy R, Ammanabrolu P, Brantley K, Hessel J, Sifa R, Bauckhage C, Hajishirzi H, Choi Y (2022) Is reinforcement learning (not) for natural language processing?: benchmarks, baselines, and building blocks for natural language policy optimization. arXiv Preprint http://arxiv.org/abs/2210.01241

Ramamurthy R, Ammanabrolu P, Brantley K, Hessel J, Sifa R, Bauckhage C, Hajishirzi H, Choi Y (2022) 强化学习(Reinforcement Learning)是否适用于自然语言处理(Natural Language Processing)？:基准测试、基线模型与自然语言策略优化的构建模块。arXiv预印本 http://arxiv.org/abs/2210.01241

Ramesh A, Pavlov M, Goh G, Gray S, Voss C, Radford A, Chen M, Sutskever I (2021) Zero-shot text-to-image generation. In: International conference on machine learning. PMLR, pp 8821-8831

Ramesh A, Pavlov M, Goh G, Gray S, Voss C, Radford A, Chen M, Sutskever I (2021) 零样本文本到图像生成。在:国际机器学习会议。PMLR，第8821-8831页

Ramesh A, Dhariwal P, Nichol A, Chu C, Chen M (2022) Hierarchical text-conditional image generation with clip latents. arXiv Preprint http://arxiv.org/abs/2204.06125

Ramesh A, Dhariwal P, Nichol A, Chu C, Chen M (2022) 利用clip潜变量进行分层文本条件图像生成。arXiv预印本 http://arxiv.org/abs/2204.06125

Reiss MV (2023) Testing the reliability of ChatGPT for text annotation and classification: a cautionary remark. arXiv Preprint http://arxiv.org/abs/2304.11085

Reiss MV (2023) 测试ChatGPT在文本标注与分类中的可靠性:一则警示。arXiv预印本 http://arxiv.org/abs/2304.11085

Ren S, Deng Y, He K, Che W (2019a) Generating natural language adversarial examples through probability weighted word saliency. In: Proceedings of the 57th annual meeting of the association for computational linguistics. pp 1085-1097

Ren S, Deng Y, He K, Che W (2019a) 通过概率加权词显著性生成自然语言对抗样本。在:第57届计算语言学协会年会论文集。第1085-1097页

Ren J, Liu PJ, Fertig E, Snoek J, Poplin R, Depristo M, Dillon J, Lakshminarayanan B (2019b) Likelihood ratios for out-of-distribution detection. In: Advances in neural information processing systems, vol 32

Ren J, Liu PJ, Fertig E, Snoek J, Poplin R, Depristo M, Dillon J, Lakshminarayanan B (2019b) 用于检测分布外样本的似然比。在:神经信息处理系统进展，第32卷

Ren X, Zhou P, Meng X, Huang X, Wang Y, Wang W, Li P, Zhang X, Podolskiy A, Arshinov G et al (2023) Pangu- $\sigma$ : towards trillion parameter language model with sparse heterogeneous computing. arXiv Preprint http://arxiv.org/abs/2303.10845

Ren X, Zhou P, Meng X, Huang X, Wang Y, Wang W, Li P, Zhang X, Podolskiy A, Arshinov G 等 (2023) 盘古(Pangu-$\sigma$):迈向拥有万亿参数的稀疏异构计算的语言模型。arXiv预印本 http://arxiv.org/abs/2303.10845

Ribeiro MT, Singh S, Guestrin C (2016) "Why should I trust you?": explaining the predictions of any classifier. In: HLT-NAACL demos

Ribeiro MT, Singh S, Guestrin C (2016) “我为什么要相信你？”:解释任何分类器的预测。在:HLT-NAACL演示

Rolfe JT (2016) Discrete variational autoencoders. arXiv Preprint http://arxiv.org/abs/1609.02200

Rolfe JT (2016) 离散变分自编码器。arXiv预印本 http://arxiv.org/abs/1609.02200

Rombach R, Blattmann A, Lorenz D, Esser P, Ommer B (2022) High-resolution image synthesis with latent diffusion models. In: Proceedings of the IEEE/CVF conference on computer vision and pattern recognition. pp 10684-10695

Rombach R, Blattmann A, Lorenz D, Esser P, Ommer B (2022) 利用潜在扩散模型进行高分辨率图像合成。在:IEEE/CVF计算机视觉与模式识别会议论文集。第10684-10695页

Ruan W, Huang X, Kwiatkowska M (2018) Reachability analysis of deep neural networks with provable guarantees. In: IJCAI2018. pp 2651-2659

Ruan W, Huang X, Kwiatkowska M (2018) 具有可证明保证的深度神经网络可达性分析。在:IJCAI2018。第2651-2659页

Ruan W, Wu M, Sun Y, Huang X, Kroening D, Kwiatkowska M (2019) Global robustness evaluation of deep neural networks with provable guarantees for the hamming distance. In: IJCAI2019. pp 5944-5952

Ruan W, Wu M, Sun Y, Huang X, Kroening D, Kwiatkowska M (2019) 具有可证明保证的深度神经网络全局鲁棒性评估，针对汉明距离。在:IJCAI2019。第5944-5952页

Ruder S, Peters ME, Swayamdipta S, Wolf T (2019) Transfer learning in natural language processing. In: Proceedings of the 2019 conference of the North American chapter of the Association for Computational Linguistics: tutorials. pp 15-18

Ruder S, Peters ME, Swayamdipta S, Wolf T (2019) 自然语言处理中的迁移学习。在:2019年北美计算语言学协会会议教程。第15-18页

Rueckauer B, Lungu I-A, Hu Y, Pfeiffer M, Liu S-C (2017) Conversion of continuous-valued deep networks to efficient event-driven networks for image classification. Front Neurosci 11:682

Rueckauer B, Lungu I-A, Hu Y, Pfeiffer M, Liu S-C (2017) 将连续值深度网络转换为高效的事件驱动网络用于图像分类。前沿神经科学 11:682

Rutinowski J, Franke S, Endendyk J, Dormuth I, Pauly M (2023) The self-perception and political biases of ChatGPT. arXiv Preprint http://arxiv.org/abs/2304.07333

Rutinowski J, Franke S, Endendyk J, Dormuth I, Pauly M (2023) ChatGPT的自我认知与政治偏见。arXiv预印本 http://arxiv.org/abs/2304.07333

Ryou W, Chen J, Balunovic M, Singh G, Dan A, Vechev M (2021) Scalable polyhedral verification of recurrent neural networks. In: International conference on computer aided verification. Springer, pp 225-248

Ryou W, Chen J, Balunovic M, Singh G, Dan A, Vechev M (2021) 可扩展的递归神经网络多面体验证。载于:国际计算机辅助验证会议。Springer，页225-248

Saharia C, Chan W, Saxena S, Li L, Whang J, Denton EL, Ghasemipour K, Gontijo Lopes R, Karagol Ayan B, Salimans T et al (2022) Photorealistic text-to-image diffusion models with deep language understanding. Adv Neural Inf Process Syst 35:36479-36494

Saharia C, Chan W, Saxena S, Li L, Whang J, Denton EL, Ghasemipour K, Gontijo Lopes R, Karagol Ayan B, Salimans T 等 (2022) 具有深度语言理解的逼真文本到图像扩散模型。先进神经信息处理系统 35:36479-36494

Samanta S, Mehta S (2017) Towards crafting text adversarial samples. arXiv Preprint http://arxiv.org/ abs/1707.02812

Samanta S, Mehta S (2017) 迈向构建文本对抗样本。arXiv预印本 http://arxiv.org/ abs/1707.02812

Sandoval G, Pearce H, Nys T, Karri R, Garg S, Dolan-Gavitt B (2023) Lost at C: a user study on the security implications of large language model code assistants. arXiv Preprint http://arxiv.org/abs/ 2208.09727

Sandoval G, Pearce H, Nys T, Karri R, Garg S, Dolan-Gavitt B (2023) 迷失在C语言:关于大型语言模型代码助手安全影响的用户研究。arXiv预印本 http://arxiv.org/abs/ 2208.09727

Scao TL, Fan A, Akiki C, Pavlick E, Ilić S, Hesslow D, Castagné R, Luccioni AS, Yvon F, Gallé M et al (2022) Bloom: a 176B-parameter open-access multilingual language model. arXiv Preprint http:// arxiv.org/abs/2211.05100

Scao TL, Fan A, Akiki C, Pavlick E, Ilić S, Hesslow D, Castagné R, Luccioni AS, Yvon F, Gallé M 等 (2022) Bloom:一个拥有1760亿参数的开源多语言模型。arXiv预印本 http:// arxiv.org/abs/2211.05100

Schulman J, Wolski F, Dhariwal P, Radford A, Klimov O (2017) Proximal policy optimization algorithms. arXiv Preprint http://arxiv.org/abs/1707.06347

Schulman J, Wolski F, Dhariwal P, Radford A, Klimov O (2017) 近端策略优化算法。arXiv预印本 http://arxiv.org/abs/1707.06347

Senate U (2023) Senate judiciary subcommittee hearing on oversight of AI. https://techpolicy.press/trans cript-senate-judiciary-subcommittee-hearing-on-oversight-of-ai/. Accessed 20 Aug 2023

参议院U (2023) 参议院司法小组委员会关于人工智能监管的听证会。https://techpolicy.press/trans cript-senate-judiciary-subcommittee-hearing-on-oversight-of-ai/。2023年8月20日访问

Seshia SA, Sadigh D, Sastry SS (2016) Towards verified artificial intelligence. arXiv Preprint http:// arxiv.org/abs/1606.08514

Seshia SA, Sadigh D, Sastry SS (2016) 迈向验证的人工智能。arXiv预印本 http:// arxiv.org/abs/1606.08514

Shanahan M (2022) Talking about large language models. arXiv Preprint http://arxiv.org/abs/2212.03551

Shanahan M (2022) 讨论大型语言模型。arXiv预印本 http://arxiv.org/abs/2212.03551

Shen Y, Hsu Y-C, Ray A, Jin H (2021a) Enhancing the generalization for intent classification and out-of-domain detection in SLU. In: Proceedings of the 59th annual meeting of the association for computational linguistics and the 11th international joint conference on natural language processing (volume 1: long papers). pp 2443-2453

Shen Y, Hsu Y-C, Ray A, Jin H (2021a) 提升意图分类和域外检测的泛化能力。在:第59届计算语言学协会年会论文集及第11届自然语言处理国际联合会议(第一卷:长篇论文)。第2443-2453页

Shen L, Ji S, Zhang X, Li J, Chen J, Shi J, Fang C, Yin J, Wang T (2021b) Backdoor pre-trained models can transfer to all. In: Proceedings of the 2021 ACM SIGSAC conference on computer and communications security. pp 3141-3158

Shen L, Ji S, Zhang X, Li J, Chen J, Shi J, Fang C, Yin J, Wang T (2021b) 后门预训练模型可以迁移到所有任务。在:2021年ACM SIGSAC计算机与通信安全会议论文集。第3141-3158页

Shen X, Chen Z, Backes M, Zhang Y (2023) In ChatGPT we trust? Measuring and characterizing the reliability of ChatGPT. arXiv Preprint http://arxiv.org/abs/2304.08979

Shen X, Chen Z, Backes M, Zhang Y (2023) 我们信任ChatGPT吗？衡量与描述ChatGPT的可靠性。arXiv预印本 http://arxiv.org/abs/2304.08979

Shi Z, Zhang H, Chang K-W, Huang M, Hsieh C-J (2019) Robustness verification for transformers. In: International conference on learning representations

Shi Z, Zhang H, Chang K-W, Huang M, Hsieh C-J (2019) 变换器的鲁棒性验证。在:国际学习表示会议

Shuster K, Poff S, Chen M, Kiela D, Weston J (2021) Retrieval augmentation reduces hallucination in conversation. arXiv Preprint http://arxiv.org/abs/2104.07567

Shuster K, Poff S, Chen M, Kiela D, Weston J (2021) 检索增强减少对话中的幻觉。arXiv预印本 http://arxiv.org/abs/2104.07567

Shuster K, Komeili M, Adolphs L, Roller S, Szlam A, Weston J (2022) Language models that seek for knowledge: modular search & generation for dialogue and prompt completion. arXiv Preprint http://arxiv.org/abs/2203.13224

Shuster K, Komeili M, Adolphs L, Roller S, Szlam A, Weston J (2022) 寻求知识的语言模型:对话与提示完成的模块化搜索与生成。arXiv预印本 http://arxiv.org/abs/2203.13224

Sinha A, Namkoong H, Volpi R, Duchi J (2017) Certifying some distributional robustness with principled adversarial training. arXiv Preprint http://arxiv.org/abs/1710.10571

Sinha A, Namkoong H, Volpi R, Duchi J (2017) 以原则性对抗训练验证某些分布鲁棒性。arXiv 预印本 http://arxiv.org/abs/1710.10571

Smith L, Gal Y (2018) Understanding measures of uncertainty for adversarial example detection. arXiv Preprint http://arxiv.org/abs/1803.08533

Smith L, Gal Y (2018) 理解不确定性度量在对抗样本检测中的作用。arXiv 预印本 http://arxiv.org/abs/1803.08533

Smith S, Patwary M, Norick B, LeGresley P, Rajbhandari S, Casper J, Liu Z, Prabhumoye S, Zerveas G, Korthikanti V et al (2022) Using deepspeed and megatron to train megatron-turing NLG 530B, a large-scale generative language model. arXiv Preprint http://arxiv.org/abs/2201.11990

Smith S, Patwary M, Norick B, LeGresley P, Rajbhandari S, Casper J, Liu Z, Prabhumoye S, Zerveas G, Korthikanti V 等 (2022) 利用deepspeed和megatron训练Megatron-Turing NLG 530B，一种大规模生成式语言模型。arXiv 预印本 http://arxiv.org/abs/2201.11990

Sobania D, Briesch M, Hanna C, Petke J (2023) An analysis of the automatic bug fixing performance of ChatGPT. arXiv Preprint http://arxiv.org/abs/2301.08653

Sobania D, Briesch M, Hanna C, Petke J (2023) ChatGPT自动修复缺陷性能分析。arXiv 预印本 http://arxiv.org/abs/2301.08653

Soltan S, Ananthakrishnan S, FitzGerald J, Gupta R, Hamza W, Khan H, Peris C, Rawls S, Rosenbaum A, Rumshisky A et al (2022) AlexaTM 20B: few-shot learning using a large-scale multilingual seq2seq model. arXiv Preprint http://arxiv.org/abs/2208.01448

Soltan S, Ananthakrishnan S, FitzGerald J, Gupta R, Hamza W, Khan H, Peris C, Rawls S, Rosenbaum A, Rumshisky A 等 (2022) AlexaTM 20B:基于大规模多语言序列到序列模型的少样本学习。arXiv 预印本 http://arxiv.org/abs/2208.01448

Struppek L, Hintersdorf D, Kersting K (2022) Rickrolling the artist: injecting invisible backdoors into text-guided image generation models. arXiv Preprint http://arxiv.org/abs/2211.02408

Struppek L, Hintersdorf D, Kersting K (2022) “点歌”艺术家:在文本引导的图像生成模型中注入隐形后门。arXiv 预印本 http://arxiv.org/abs/2211.02408

Sun Y, Huang X, Kroening D, Sharp J, Hill M, Ashmore R (2018a) Testing deep neural networks. arXiv Preprint http://arxiv.org/abs/1803.04792

Sun Y, Huang X, Kroening D, Sharp J, Hill M, Ashmore R (2018a) 深度神经网络测试。arXiv 预印本 http://arxiv.org/abs/1803.04792

Sun Y, Wu M, Ruan W, Huang X, Kwiatkowska M, Kroening D (2018b) Concolic testing for deep neural networks. In: ASE2018

Sun Y, Wu M, Ruan W, Huang X, Kwiatkowska M, Kroening D (2018b) 深度神经网络的符号测试。在:ASE2018

Sun Y, Huang X, Kroening D, Sharp J, Hill M, Ashmore R (2019) Structural test coverage criteria for deep neural networks. ACM Trans Embed Comput Syst 18(5s):1-23

Sun Y, Huang X, Kroening D, Sharp J, Hill M, Ashmore R (2019) 深度神经网络的结构测试覆盖标准。ACM Trans Embed Comput Syst 18(5s):1-23

Sun Y, Wang S, Feng S, Ding S, Pang C, Shang J, Liu J, Chen X, Zhao Y, Lu Y et al (2021) ERNIE 3.0: large-scale knowledge enhanced pre-training for language understanding and generation. arXiv Preprint http://arxiv.org/abs/2107.02137

Sun Y, Wang S, Feng S, Ding S, Pang C, Shang J, Liu J, Chen X, Zhao Y, Lu Y 等 (2021) ERNIE 3.0:用于语言理解与生成的大规模知识增强预训练模型。arXiv 预印本 http://arxiv.org/abs/2107.02137

Sun H, Zhang Z, Deng J, Cheng J, Huang M (2023) Safety assessment of Chinese large language models. arXiv Preprint http://arxiv.org/abs/2304.10436

Sun H, Zhang Z, Deng J, Cheng J, Huang M (2023) 中国大型语言模型的安全性评估。arXiv 预印本 http://arxiv.org/abs/2304.10436

Szegedy C, Zaremba W, Sutskever I, Bruna J, Erhan D, Goodfellow I, Fergus R (2013) Intriguing properties of neural networks. arXiv Preprint http://arxiv.org/abs/1312.6199

Szegedy C, Zaremba W, Sutskever I, Bruna J, Erhan D, Goodfellow I, Fergus R (2013) 神经网络的引人入胜的特性。arXiv 预印本 http://arxiv.org/abs/1312.6199

Tanguy L, Tulechki N, Urieli A, Hermann E, Raynal C (2016) Natural language processing for aviation safety reports: from classification to interactive analysis. Comput Ind 78:80-95

Tanguy L, Tulechki N, Urieli A, Hermann E, Raynal C (2016) 面向航空安全报告的自然语言处理:从分类到交互式分析。计算工业 78:80-95

Taori R, Gulrajani I, Zhang T, Dubois Y, Li X, Guestrin C, Liang P, Hashimoto TB (2023) Stanford Alpaca: an instruction-following LLaMa model

Taori R, Gulrajani I, Zhang T, Dubois Y, Li X, Guestrin C, Liang P, Hashimoto TB (2023) Stanford Alpaca:一款指令跟随的LLaMa模型

Taylor R, Kardas M, Cucurull G, Scialom T, Hartshorn A, Saravia E, Poulton A, Kerkez V, Stojnic R (2022) Galactica: a large language model for science. arXiv Preprint http://arxiv.org/abs/2211.09085

Taylor R, Kardas M, Cucurull G, Scialom T, Hartshorn A, Saravia E, Poulton A, Kerkez V, Stojnic R (2022) Galactica:面向科学的大型语言模型。arXiv 预印本 http://arxiv.org/abs/2211.09085

Tejankar A, Sanjabi M, Wang Q, Wang S, Firooz H, Pirsiavash H, Tan L (2023) Defending against patch-based backdoor attacks on self-supervised learning. In: Proceedings of the IEEE/CVF conference on computer vision and pattern recognition. pp 12239-12249

Tejankar A, Sanjabi M, Wang Q, Wang S, Firooz H, Pirsiavash H, Tan L (2023) 针对自监督学习中基于补丁的后门攻击的防御。发表于:IEEE/CVF计算机视觉与模式识别会议论文集，第12239-12249页

Thakur S, Ahmad B, Fan Z, Pearce H, Tan B, Karri R, Dolan-Gavitt B, Garg S (2023) Benchmarking large language models for automated Verilog RTL code generation. In: 2023 design, automation & test in Europe conference & exhibition (DATE). IEEE, pp 1-6

Thakur S, Ahmad B, Fan Z, Pearce H, Tan B, Karri R, Dolan-Gavitt B, Garg S (2023) 大型语言模型在自动Verilog RTL代码生成中的基准测试。在:2023年欧洲设计、自动化与测试会议与展览(DATE)。IEEE，第1-6页

The carbon footprint of GPT-4. https://towardsdatascience.com/the-carbon-footprint-of-gpt-4-d6c67 6eb21ae. Accessed 17 Aug 2023

GPT-4的碳足迹。https://towardsdatascience.com/the-carbon-footprint-of-gpt-4-d6c67 6eb21ae。2023年8月17日访问

Thoppilan R, De Freitas D, Hall J, Shazeer N, Kulshreshtha A, Cheng H-T, Jin A, Bos T, Baker L, Du Y et al (2022) LaMDA: language models for dialog applications. arXiv Preprint http://arxiv.org/abs/ 2201.08239

Thoppilan R, De Freitas D, Hall J, Shazeer N, Kulshreshtha A, Cheng H-T, Jin A, Bos T, Baker L, Du Y 等 (2022) LaMDA:对话应用的语言模型。arXiv预印本 http://arxiv.org/abs/2201.08239

Thorne J, Vlachos A, Christodoulopoulos C, Mittal A (2018) FEVER: a large-scale dataset for fact extraction and verification. In: 2018 conference of the North American chapter of the association for computational linguistics: human language technologies, NAACL HLT 2018. Association for Computational Linguistics (ACL), pp 809-819

Thorne J, Vlachos A, Christodoulopoulos C, Mittal A (2018) FEVER:大规模事实提取与验证数据集。在:2018年北美计算语言学协会人类语言技术会议(NAACL HLT 2018)。计算语言学协会(ACL)，第809-819页

Tools such as ChatGPT threaten transparent science; here are our ground rules for their use. https:// www.nature.com/articles/d41586-023-00191-1. Accessed 20 Aug 2023

诸如ChatGPT的工具威胁到科学的透明性；以下是我们使用的基本原则。https://www.nature.com/articles/d41586-023-00191-1。2023年8月20日访问

Touvron H, Lavril T, Izacard G, Martinet X, Lachaux M-A, Lacroix T, Rozière B, Goyal N, Hambro E, Azhar F et al (2023) LLaMA: open and efficient foundation language models. arXiv Preprint http://arxiv.org/abs/2302.13971

Touvron H, Lavril T, Izacard G, Martinet X, Lachaux M-A, Lacroix T, Rozière B, Goyal N, Hambro E, Azhar F 等 (2023) LLaMA:开源高效的基础语言模型。arXiv预印本 http://arxiv.org/abs/2302.13971

Tulshan AS, Dhage SN (2019) Survey on virtual assistant: Google assistant, Siri, Cortana, Alexa. In: Advances in signal processing and intelligent recognition systems: 4th international symposium SIRS 2018, Bangalore, India, September 19-22, 2018, revised selected papers 4. Springer, pp 190-201

Tulshan AS, Dhage SN (2019) 虚拟助手综述:Google助手、Siri、Cortana、Alexa。在:信号处理与智能识别系统的进展:第4届国际研讨会SIRS 2018，印度班加罗尔，2018年9月19-22日，修订精选论文。Springer，第190-201页

Tung F, Mori G (2019) Similarity-preserving knowledge distillation. In: Proceedings of the IEEE/CVF international conference on computer vision. pp 1365-1374

Tung F, Mori G (2019) 保持相似性的知识蒸馏。在:IEEE/CVF国际计算机视觉会议论文集。第1365-1374页

Uchendu A, Lee J, Shen H, Le T, Huang TK, Lee D (2023) Understanding individual and team-based human factors in detecting deepfake texts. CoRR. abs/2304.01002

Uchendu A, Lee J, Shen H, Le T, Huang TK, Lee D (2023) 理解个人与团队在检测深度伪造文本中的人类因素。CoRR. abs/2304.01002

Vardi MY, Wolper P (1986) An automata-theoretic approach to automatic program verification. In: 1st symposium in logic in computer science (LICS). IEEE Computer Society

Vardi MY, Wolper P (1986) 基于自动机理论的自动程序验证方法。在:第一届计算机科学中的逻辑研讨会(LICS)。IEEE计算机学会

Vaswani A, Shazeer N, Parmar N, Uszkoreit J, Jones L, Gomez AN, Kaiser Lu, Polosukhin I (2017) Attention is all you need. In: Guyon I, Luxburg UV, Bengio S, Wallach H, Fergus R, Vishwanathan S, Garnett R (eds) Advances in neural information processing systems, vol 30. Curran Associates, Inc

Vaswani A, Shazeer N, Parmar N, Uszkoreit J, Jones L, Gomez AN, Kaiser Lu, Polosukhin I (2017) 注意力机制:全部都是你需要的。在:Guyon I, Luxburg UV, Bengio S, Wallach H, Fergus R, Vishwanathan S, Garnett R(编)神经信息处理系统的进展，第30卷。Curran Associates, Inc

Wallace M, Khandelwal R, Tang B (2022) Does IBP scale? arXiv Preprint

Wallace M, Khandelwal R, Tang B (2022) IBP能扩展吗？arXiv预印本

Wang Y, Bansal M (2018) Robust machine comprehension models via adversarial training. arXiv Preprint http://arxiv.org/abs/1804.06473

Wang Y, Bansal M (2018) 通过对抗训练实现鲁棒的机器理解模型。arXiv预印本 http://arxiv.org/abs/1804.06473

Wang G, Lin Y, Yi W (2010) Kernel fusion: an effective method for better power efficiency on multithreaded GPU. In: 2010 IEEE/ACM Int'1 conference on green computing and communications & Int'1 conference on cyber, physical and social computing. IEEE, pp 344-350

Wang G, Lin Y, Yi W (2010) 核融合:提升多线程GPU能效的有效方法。在:2010年IEEE/ACM绿色计算与通信国际会议及网络、物理与社会计算国际会议。IEEE，第344-350页

Wang W, Tang P, Lou J, Xiong L (2021a) Certified robustness to word substitution attack with differential privacy. In: Proceedings of the 2021 conference of the North American chapter of the association for computational linguistics: human language technologies. pp 1102-1112

Wang W, Tang P, Lou J, Xiong L (2021a) 通过差分隐私实现对词替换攻击的认证鲁棒性。在:2021年北美计算语言学协会人类语言技术会议论文集。第1102-1112页

Wang B, Xu C, Wang S, Gan Z, Cheng Y, Gao J, Awadallah AH, Li B (2021b) Adversarial glue: a multitask benchmark for robustness evaluation of language models. arXiv Preprint http://arxiv.org/abs/ 2111.02840

Wang B, Xu C, Wang S, Gan Z, Cheng Y, Gao J, Awadallah AH, Li B (2021b) 对抗胶:多任务基准，用于评估语言模型的鲁棒性。arXiv预印本 http://arxiv.org/abs/2111.02840

Wang J, Hu X, Hou W, Chen H, Zheng R, Wang Y, Yang L, Huang H, Ye W, Geng X, Jiao B, Zhang Y, Xie $\mathrm{X}$ (2023a) On the robustness of ChatGPT: an adversarial and out-of-distribution perspective. arXiv e-prints http://arxiv.org/abs/2302.12095

王J，胡X，侯W，陈H，郑R，王Y，杨L，黄H，叶W，耿X，焦B，张Y，谢$\mathrm{X}$(2023a)关于ChatGPT的鲁棒性:对抗性和分布外视角。arXiv 预印本 http://arxiv.org/abs/2302.12095

Wang X, Wei J, Schuurmans D, Le QV, Chi EH, Narang S, Chowdhery A, Zhou D (2023b) Self-consistency improves chain of thought reasoning in language models. In: The eleventh international conference on learning representations

王X，魏J，Schuurmans D，Le QV，Chi EH，Narang S，Chowdhery A，周D(2023b)自洽性提升语言模型中的思维链推理。在:第十一届学习表示国际会议

Wang F, Xu P, Ruan W, Huang X (2023c) Towards verifying the geometric robustness of large-scale neural networks. arXiv Preprint http://arxiv.org/abs/2301.12456

王F，徐P，阮W，黄X(2023c)迈向验证大规模神经网络的几何鲁棒性。arXiv 预印本 http://arxiv.org/abs/2301.12456

Wei J, Wang X, Schuurmans D, Bosma M, Brian Ichter, Xia F, Chi EH, Le QV, Zhou D (2022) Chain of thought prompting elicits reasoning in large language models. In: Oh AH, Agarwal A, Belgrave D, Cho K (eds) Advances in neural information processing systems

魏J，王X，Schuurmans D，Bosma M，Ichter B，夏F，Chi EH，Le QV，周D(2022)思维链提示激发大型语言模型的推理能力。在:Oh AH，Agarwal A，Belgrave D，Cho K(编)神经信息处理系统进展

Wei J, Kim S, Jung H, Kim Y-H (2023) Leveraging large language models to power chatbots for collecting user self-reported data. arXiv Preprint http://arxiv.org/abs/2301.05843

魏J，金S，郑H，金Y-H(2023)利用大型语言模型驱动聊天机器人以收集用户自我报告数据。arXiv 预印本 http://arxiv.org/abs/2301.05843

Weng T-W, Zhang H, Chen P-Y, Yi J, Su D, Gao Y, Hsieh C-J, Daniel L (2018) Evaluating the robustness of neural networks: an extreme value theory approach. arXiv Preprint http://arxiv.org/abs/1801.10578

翁T-W，张H，陈P-Y，易J，苏D，高Y，谢C-J，丹尼尔L(2018)评估神经网络的鲁棒性:极值理论方法。arXiv 预印本 http://arxiv.org/abs/1801.10578

Weng Y, Zhu M, He S, Liu K, Zhao J (2022) Large language models are reasoners with self-verification. arXiv Preprint http://arxiv.org/abs/2212.09561

翁Y，朱M，何S，刘K，赵J(2022)大型语言模型是具有自我验证能力的推理者。arXiv 预印本 http://arxiv.org/abs/2212.09561

Weng Y, Zhu M, Xia F, Li B, He S, Liu K, Zhao J (2023) Neural comprehension: language models with compiled neural networks. arXiv Preprint http://arxiv.org/abs/2304.01665

翁Y，朱M，夏F，李B，何S，刘K，赵J(2023)神经理解:带有编译神经网络的语言模型。arXiv 预印本 http://arxiv.org/abs/2304.01665

Wicker M, Huang X, Kwiatkowska M (2018) Feature-guided black-box safety testing of deep neural networks. In: Tools and algorithms for the construction and analysis of systems: 24th international conference, TACAS 2018, held as part of the European joint conferences on theory and practice of software, ETAPS 2018, Thessaloniki, Greece, April 14-20, 2018, proceedings, part I 24. pp 408-426

Wicker M，黄X，Kwiatkowska M(2018)基于特征引导的深度神经网络黑盒安全测试。在:系统构建与分析的工具与算法:第24届国际会议，TACAS 2018，作为软件理论与实践欧洲联合会议(ETAPS 2018)的一部分，于希腊塞萨洛尼基举行，2018年4月14-20日，论文集，第I部分，第408-426页

Wolf Y, Wies N, Levine Y, Shashua A (2023) Fundamental limitations of alignment in large language models. arXiv Preprint http://arxiv.org/abs/2304.11082

Wolf Y，Wies N，Levine Y，Shashua A(2023)大型语言模型中的对齐的根本限制。arXiv 预印本 http://arxiv.org/abs/2304.11082

Wong E, Rice L, Kolter JZ (2020) Fast is better than free: revisiting adversarial training. arXiv Preprint http://arxiv.org/abs/2001.03994

Wong E，Rice L，Kolter JZ(2020)速度优先胜过免费:重新审视对抗性训练。arXiv 预印本 http://arxiv.org/abs/2001.03994

Wu M, Wicker M, Ruan W, Huang X, Kwiatkowska M (2020) A game-based approximate verification of deep neural networks with provable guarantees. Theor Comput Sci 807:298-329

吴M，Wicker M，阮W，黄X，Kwiatkowska M(2020)基于博弈的深度神经网络近似验证，具有可证明的保证。理论计算机科学 807:298-329

Wu Y, Jiang AQ, Li W, Rabe MN, Staats CE, Jamnik M, Szegedy C (2022a) Autoformalization with large language models. In: Oh AH, Agarwal A, Belgrave D, Cho K (eds) Advances in neural information processing systems

吴Y，江AQ，李W，Rabe MN，Staats CE，Jamnik M，Szegedy C(2022a)利用大型语言模型实现自动形式化。在:Oh AH，Agarwal A，Belgrave D，Cho K(编)神经信息处理系统进展

Wu D, Yi X, Huang X (2022b) A little energy goes a long way: build an energy-efficient, accurate spiking neural network from convolutional neural network. Front Neurosci 16:759900

吴D，易X，黄X(2022b)少量能量带来大不同:从卷积神经网络构建节能高效的脉冲神经网络。前沿神经科学 16:759900

Wu S, Irsoy O, Lu S, Dabravolski V, Dredze M, Gehrmann S, Kambadur P, Rosenberg D, Mann G (2023a) BloombergGPT: a large language model for finance. arXiv Preprint http://arxiv.org/abs/2303.17564

吴S，Irsoy O，卢S，Dabravolski V，Dredze M，Gehrmann S，Kambadur P，Rosenberg D，Mann G(2023a)BloombergGPT:面向金融的大型语言模型。arXiv 预印本 http://arxiv.org/abs/2303.17564

Wu D, Jin G, Yu H, Yi X, Huang X (2023b) Optimising event-driven spiking neural network with regulari-sation and cutoff. arXiv Preprint http://arxiv.org/abs/2301.09522

吴D，金G，余H，易X，黄X(2023b)通过正则化和截止优化事件驱动的脉冲神经网络。arXiv 预印本 http://arxiv.org/abs/2301.09522

Wu X, Sun K, Zhu F, Zhao R, Li H (2023c) Better aligning text-to-image models with human preference. arXiv Preprint http://arxiv.org/abs/2303.14420

吴X, 孙K, 朱F, 赵R, 李H (2023c) 更好地将文本到图像模型与人类偏好对齐。arXiv预印本 http://arxiv.org/abs/2303.14420

Wu M, Waheed A, Zhang C, Abdul-Mageed M, Aji AF (2023d) LaMini-LM: a diverse herd of distilled models from large-scale instructions. arXiv Preprint http://arxiv.org/abs/2304.14402

吴M, Waheed A, 张C, Abdul-Mageed M, Aji AF (2023d) LaMini-LM:来自大规模指令的多样化蒸馏模型群。arXiv预印本 http://arxiv.org/abs/2304.14402

Wu H, Wang W, Wan Y, Jiao W, Lyu M (2023e) ChatGPT or grammarly? Evaluating ChatGPT on grammatical error correction benchmark. arXiv Preprint http://arxiv.org/abs/2303.13648

吴H, 王W, 万Y, 焦W, 吕M (2023e) ChatGPT还是Grammarly？在语法错误校正基准测试中评估ChatGPT。arXiv预印本 http://arxiv.org/abs/2303.13648

Xu F, Uszkoreit H, Du Y, Fan W, Zhao D, Zhu J (2019) Explainable AI: a brief survey on history, research areas, approaches and challenges. In: Natural language processing and Chinese computing: 8th CCF international conference, NLPCC 2019, Dunhuang, China, October 9-14, 2019, proceedings, part II 8. Springer, pp 563-574

许F, Uszkoreit H, 杜Y, 范W, 赵D, 朱J (2019) 可解释的人工智能:关于历史、研究领域、方法与挑战的简要综述。在:自然语言处理与中文计算:第八届中国计算机学会国际会议，NLPCC 2019，敦煌，中国，2019年10月9-14日，论文集第二部分，第8章 Springer，页563-574

$\mathrm{{Xu}}\mathrm{H},\mathrm{{Ma}}\mathrm{Y},\mathrm{{Liu}}\mathrm{H} - \mathrm{C},\mathrm{{Deb}}\mathrm{D},\mathrm{{Liu}}\mathrm{H},\mathrm{{Tang}}\mathrm{J} - \mathrm{L},\mathrm{{Jain}}\mathrm{{AK}}$ (2020a) Adversarial attacks and defenses in images, graphs and text: a review. Int J Autom Comput 17:151-178

$\mathrm{{Xu}}\mathrm{H},\mathrm{{Ma}}\mathrm{Y},\mathrm{{Liu}}\mathrm{H} - \mathrm{C},\mathrm{{Deb}}\mathrm{D},\mathrm{{Liu}}\mathrm{H},\mathrm{{Tang}}\mathrm{J} - \mathrm{L},\mathrm{{Jain}}\mathrm{{AK}}$ (2020a) 图像、图表和文本中的对抗攻击与防御:综述。国际自动化与计算杂志 17:151-178

$\mathrm{{Xu}}\mathrm{H},\mathrm{{He}}\mathrm{K},\mathrm{{Yan}}\mathrm{Y},\mathrm{{Liu}}\mathrm{S},\mathrm{{Liu}}\mathrm{Z},\mathrm{{Xu}}\mathrm{W}\left( {{2020}\mathrm{\;b}}\right) \mathrm{A}$ deep generative distance-based classifier for out-of-domain detection with Mahalanobis space. In: Proceedings of the 28th international conference on computational linguistics. pp 1452-1460

$\mathrm{{Xu}}\mathrm{H},\mathrm{{He}}\mathrm{K},\mathrm{{Yan}}\mathrm{Y},\mathrm{{Liu}}\mathrm{S},\mathrm{{Liu}}\mathrm{Z},\mathrm{{Xu}}\mathrm{W}\left( {{2020}\mathrm{\;b}}\right) \mathrm{A}$ 基于深度生成距离的分类器用于超出域检测，采用马氏空间。在:第28届国际计算语言学会议论文集。第1452-1460页

Xu P, Ruan W, Huang X (2022) Quantifying safety risks of deep neural networks. Complex Intell Syst 9(4):3801-3818

许P, 阮W, 黄X (2022) 深度神经网络安全风险量化。复杂智能系统 9(4):3801-3818

$\mathrm{{XuJ}}$ , Liu $\mathrm{X},\mathrm{{Wu}}\mathrm{Y},\mathrm{{Tong}}\mathrm{Y},\mathrm{{Li}}\mathrm{Q}$ , Ding $\mathrm{M},\mathrm{{Tang}}\mathrm{J}$ , Dong $\mathrm{Y}$ (2023) ImageReward: learning and evaluating human preferences for text-to-image generation. arXiv Preprint http://arxiv.org/abs/2304.05977

$\mathrm{{XuJ}}$ ,刘$\mathrm{X},\mathrm{{Wu}}\mathrm{Y},\mathrm{{Tong}}\mathrm{Y},\mathrm{{Li}}\mathrm{Q}$ ,丁$\mathrm{M},\mathrm{{Tang}}\mathrm{J}$ ,董$\mathrm{Y}$ (2023) ImageReward:学习与评估人类对文本到图像生成偏好的方法。arXiv预印本 http://arxiv.org/abs/2304.05977

Yandex. Yandex/YaLM-100B: pretrained language model with 100B parameters. https://github.com/yan-dex/YaLM-100B.Accessed 20 Aug 2023

Yandex. Yandex/YaLM-100B:具有1000亿参数的预训练语言模型。https://github.com/yan-dex/YaLM-100B。2023年8月20日访问

Yang Z (2023) Chinese tech giant Baidu just released its answer to ChatGPT

杨Z (2023) 中国科技巨头百度刚刚发布了其对ChatGPT的回应

Yang Z, Dai Z, Yang Y, Carbonell J, Salakhutdinov RR, Le QV (2019) XLNet: generalized autoregressive pretraining for language understanding. In: Advances in neural information processing systems, vol 32

杨Z, 戴Z, 杨Y, 卡博内尔 J, 萨拉库廷诺夫 RR, Le QV (2019) XLNet:用于语言理解的广义自回归预训练。在:神经信息处理系统进展，第32卷

Yang J, Zhou K, Li Y, Liu Z (2021a) Generalized out-of-distribution detection: a survey. arXiv Preprint http://arxiv.org/abs/2110.11334

杨J, 周K, 李Y, 刘Z (2021a) 广义超出域检测:综述。arXiv预印本 http://arxiv.org/abs/2110.11334

Yang W, Li L, Zhang Z, Ren X, Sun X, He B (2021b) Be careful about poisoned word embeddings: exploring the vulnerability of the embedding layers in NLP models. In: Proceedings of the 2021 conference of the North American chapter of the association for computational linguistics: human language technologies. pp 2048-2058

杨W, 李L, 张Z, 任X, 孙X, 何B (2021b) 小心被污染的词嵌入:探索NLP模型中嵌入层的脆弱性。在:2021年北美计算语言学协会人类语言技术会议论文集，第2048-2058页

Yang J, Jin H, Tang R, Han X, Feng Q, Jiang H, Yin B, Hu X (2023) Harnessing the power of LLMs in practice: a survey on ChatGPT and beyond. arXiv Preprint http://arxiv.org/abs/2304.13712

杨J, 金H, 唐R, 韩X, 冯Q, 江H, 尹B, 胡X (2023) 实践中利用大规模语言模型的力量:关于ChatGPT及其未来的综述。arXiv预印本 http://arxiv.org/abs/2304.13712

Yao Z, Yazdani Aminabadi R, Zhang M, Wu X, Li C, He Y (2022) ZeroQuant: efficient and affordable post-training quantization for large-scale transformers. In: Advances in neural information processing systems, vol 35. pp 27168-27183

姚泽, Yazdani Aminabadi R, 张 M, 吴 X, 李 C, 何 Y (2022) ZeroQuant:高效且经济的大规模变换器(transformers)后训练量化。在:神经信息处理系统进展，第35卷，第27168-27183页

Yao S, Zhao J, Yu D, Du N, Shafran I, Narasimhan KR, Cao Y (2023) ReAct: synergizing reasoning and acting in language models. In: The eleventh international conference on learning representations

姚 S, 赵 J, 于 D, 杜 N, Shafran I, Narasimhan KR, 曹 Y (2023) ReAct:在语言模型中协同推理与行动。在:第十一届学习表征国际会议

Ye M, Gong C, Liu Q (2020) Safer: a structure-free approach for certified robustness to adversarial word substitutions. arXiv Preprint http://arxiv.org/abs/2005.14424

叶 M, 宫 C, 刘 Q (2020) Safer:一种结构无关的对抗性词替换认证鲁棒性方法。arXiv预印本 http://arxiv.org/abs/2005.14424

Ye X, Iyer S, Celikyilmaz A, Stoyanov V, Durrett G, Pasunuru R (2022) Complementary explanations for effective in-context learning. arXiv Preprint http://arxiv.org/abs/2211.13892

叶 X, 艾耶尔 S, Celikyilmaz A, Stoyanov V, Durrett G, Pasunuru R (2022) 有效的上下文学习的互补解释。arXiv预印本 http://arxiv.org/abs/2211.13892

Yilmaz E, Toraman C (2022) D2U: distance-to-uniform learning for out-of-scope detection. In: Proceedings of the 2022 conference of the North American chapter of the association for computational linguistics: human language technologies. pp 2093-2108

伊尔马兹 E, 托拉曼 C (2022) D2U:距离到均匀(distance-to-uniform)学习用于超出范围检测。在:2022年北美计算语言学协会会议论文集:人类语言技术，第2093-2108页

Yu J, Xu Y, Koh JY, Luong T, Baid G, Wang Z, Vasudevan V, Ku A, Yang Y, Ayan BK et al (2022) Scaling autoregressive models for content-rich text-to-image generation. arXiv Preprint http://arxiv.org/abs/2206.10789

余 J, 徐 Y, Koh JY, 卢 T, Baid G, 王 Z, Vasudevan V, Ku A, 杨 Y, Ayan BK 等 (2022) 扩展自回归模型以实现内容丰富的文本到图像生成。arXiv预印本 http://arxiv.org/abs/2206.10789

Zeng Z, He K, Yan Y, Liu Z, Wu Y, Xu H, Jiang H, Xu W (2021a) Modeling discriminative representations for out-of-domain detection with supervised contrastive learning. In: Proceedings of the 59th annual meeting of the association for computational linguistics and the 11th international joint conference on natural language processing (volume 2: short papers). pp 870-878

曾 Z, 何 K, 闫 Y, 刘 Z, 吴 Y, 徐 H, 江 H, 徐 W (2021a) 使用有监督对比学习建模判别性表示以进行超出域检测。在:第59届年度计算语言学协会会议论文集及第11届自然语言处理国际联合会议(第二卷:短论文)，第870-878页

Zeng W, Ren X, Su T, Wang H, Liao Y, Wang Z, Jiang X, Yang Z, Wang K, Zhang X et al (2021b) Pangu- $\alpha$ : large-scale autoregressive pretrained Chinese language models with auto-parallel computation. arXiv Preprint http://arxiv.org/abs/2104.12369

曾 W, 任 X, 徐 J, 李 L, 袁 L, 黄 X (2021b) Pangu-$\alpha$:具有自动并行计算的大规模自回归预训练中文语言模型。arXiv预印本 http://arxiv.org/abs/2104.12369

Zeng J, Zheng X, Xu J, Li L, Yuan L, Huang X (2021c) Certified robustness to text adversarial attacks by randomized [mask]. arXiv Preprint http://arxiv.org/abs/2105.03743

曾 J, 郑 X, 徐 J, 李 L, 袁 L, 黄 X (2021c) 通过随机[掩码]实现对文本对抗攻击的认证鲁棒性。arXiv预印本 http://arxiv.org/abs/2105.03743

Zhang J, Zhao Y, Saleh M, Liu P (2020) PEGASUS: pre-training with extracted gap-sentences for abstractive summarization. In: III HD, Singh A (eds) Proceedings of the 37th international conference on machine learning, volume 119 of proceedings of machine learning research, 13-18 July 2020. PMLR, pp 11328-11339

张 J, 赵 Y, Saleh M, 刘 P (2020) PEGASUS:利用提取的间隙句子进行预训练以实现抽象摘要。在:第37届国际机器学习会议论文集，卷119，2020年7月13-18日。PMLR，第11328-11339页

Zhang Y, Albarghouthi A, D'Antoni L (2021) Certified robustness to programmable transformations in LSTMS. arXiv Preprint http://arxiv.org/abs/2102.07818

张 Y, Albarghouthi A, D'Antoni L (2021) 在LSTM中对可编程变换的认证鲁棒性。arXiv预印本 http://arxiv.org/abs/2102.07818

Zhang S, Roller S, Goyal N, Artetxe M, Chen M, Chen S, Dewan C, Diab M, Li X, Lin XV et al (2022) OPT: open pre-trained transformer language models. arXiv Preprint http://arxiv.org/abs/2205.01068

张 S, Roller S, Goyal N, Artetxe M, 陈 M, 陈 S, Dewan C, Diab M, 李 X, Lin XV 等 (2022) OPT:开源预训练变换器(transformer)语言模型。arXiv预印本 http://arxiv.org/abs/2205.01068

Zhang T, Ladhak F, Durmus E, Liang P, McKeown K, Hashimoto TB (2023a) Benchmarking large language models for news summarization. arXiv Preprint http://arxiv.org/abs/2301.13848

张 T, Ladhak F, Durmus E, Liang P, McKeown K, Hashimoto TB (2023a) 大型语言模型新闻摘要性能基准测试。arXiv预印本 http://arxiv.org/abs/2301.13848

Zhang C, Ruan W, Wang F, Xu P, Min G, Huang X (2023b) Model-agnostic reachability analysis on deep neural networks. arXiv Preprint http://arxiv.org/abs/2304.00813

张 C, 阮 W, 王 F, 徐 P, 闵 G, 黄 X (2023b) 深度神经网络的模型无关可达性分析。arXiv预印本 http://arxiv.org/abs/2304.00813

Zhang C, Ruan W, Xu P (2023c) Reachability analysis of neural network control systems. arXiv Preprint http://arxiv.org/abs/2301.12100

张 C, 阮 W, 徐 P (2023c) 神经网络控制系统的可达性分析。arXiv预印本 http://arxiv.org/abs/2301.12100

Zhao Z, Dua D, Singh S (2017) Generating natural adversarial examples. arXiv Preprint http://arxiv.org/ abs/1710.11342

赵 Z, 杜 D, 辛 S (2017) 生成自然对抗样本。arXiv预印本 http://arxiv.org/abs/1710.11342

Zhao X, Huang W, Huang X, Robu V, Flynn D (2021a) BayLIME: Bayesian local interpretable model-agnostic explanations. In: de Campos C, Maathuis MH (eds) Proceedings of the thirty-seventh conference on uncertainty in artificial intelligence, volume 161 of proceedings of machine learning research, 27-30 July 2021. PMLR, pp 887-896

赵X，黄W，黄X，Robu V，Flynn D(2021a)BayLIME:贝叶斯局部可解释模型无关解释。在:de Campos C，Maathuis MH(编)第37届不确定性人工智能会议论文集，机器学习研究论文集第161卷，2021年7月27-30日。PMLR，第887-896页

Zhao X, Huang W, Schewe S, Dong Y, Huang X (2021b) Detecting operational adversarial examples for reliable deep learning. In: 2021 51st annual IEEE/IFIP international conference on dependable systems and networks-supplemental volume (DSN-S). pp 5-6

赵X，黄W，Schewe S，Dong Y，黄X(2021b)检测可靠深度学习的操作对抗样本。在:2021年第51届IEEE/IFIP国际可靠系统与网络会议(DSN-S)补充卷，第5-6页

Zhao WX, Zhou K, Li J, Tang T, Wang X, Hou Y, Min Y, Zhang B, Zhang J, Dong Z et al (2023a) A survey of large language models. arXiv Preprint http://arxiv.org/abs/2303.18223

赵WX，周K，李J，唐T，王X，侯Y，闵Y，张B，张J，董Z等(2023a)大型语言模型综述。arXiv预印本 http://arxiv.org/abs/2303.18223

Zhao R, Li X, Chia YK, Ding B, Bing L (2023b) Can ChatGPT-like generative models guarantee factual accuracy? On the mistakes of new generation search engines. arXiv Preprint http://arxiv.org/abs/ 2304.11076

赵R，李X，Chia YK，丁B，Bing L(2023b)类似ChatGPT的生成模型能保证事实准确性吗？关于新一代搜索引擎的错误。arXiv预印本 http://arxiv.org/abs/2304.11076

Zhong Q, Ding L, Liu J, Du B, Tao D (2023) Can ChatGPT understand too? A comparative study on Chat-GPT and fine-tuned BERT. arXiv Preprint http://arxiv.org/abs/2302.10198

钟Q，丁L，刘J，杜B，陶D(2023)ChatGPT也能理解吗？关于Chat-GPT与微调BERT的对比研究。arXiv预印本 http://arxiv.org/abs/2302.10198

Zhou W, Liu F, Chen M (2021) Contrastive out-of-distribution detection for pretrained transformers. In: Proceedings of the 2021 conference on empirical methods in natural language processing (EMNLP)

周W，刘F，陈M(2021)预训练变换模型的对比异常检测。在:2021年自然语言处理经验方法会议(EMNLP)论文集

Zhou Y, Liu P, Qiu X (2022) KNN-contrastive learning for out-of-domain intent classification. In: Proceedings of the 60th annual meeting of the association for computational linguistics (volume 1: long papers). pp 5129-5141

周Y，刘P，邱X(2022)用于超出领域意图分类的KNN对比学习。在:第60届计算语言学协会年会论文集(第1卷:长篇论文)，第5129-5141页

Zhou C, Li Q, Li C, Yu J, Liu Y, Wang G, Zhang K, Ji C, Yan Q, He L et al (2023) A comprehensive survey on pretrained foundation models: a history from BERT to ChatGPT. arXiv Preprint http://arxiv.org/ abs/2302.09419

周C，李Q，李C，余J，刘Y，王G，张K，季C，严Q，何L等(2023)预训练基础模型的全面综述:从BERT到ChatGPT的历史。arXiv预印本 http://arxiv.org/abs/2302.09419

Zhu RJ, Zhao Q, Eshraghian JK (2023) SpikeGPT: generative pre-trained language model with spiking neural networks. arXiv Preprint http://arxiv.org/abs/2302.13939

朱RJ，赵Q，Eshraghian JK(2023)SpikeGPT:结合脉冲神经网络的生成预训练语言模型。arXiv预印本 http://arxiv.org/abs/2302.13939

Ziegler DM, Stiennon N, Wu J, Brown TB, Radford A, Amodei D, Christiano P, Irving G (2019) Fine-tuning language models from human preferences. arXiv Preprint http://arxiv.org/abs/1909.08593

Ziegler DM，Stiennon N，Wu J，Brown TB，Radford A，Amodei D，Christiano P，Irving G(2019)基于人类偏好的微调语言模型。arXiv预印本 http://arxiv.org/abs/1909.08593

Publisher's Note Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations.

出版者声明Springer Nature在已发表地图和机构隶属关系中的管辖权声明方面保持中立。