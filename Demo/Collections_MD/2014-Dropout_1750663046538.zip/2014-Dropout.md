# Dropout: A Simple Way to Prevent Neural Networks from Overfitting

# Dropout:防止神经网络过拟合的简单方法

Nitish Srivastava NITISH@CS.TORONTO.EDU Geoffrey Hinton HINTON@CS.TORONTO.EDU Alex Krizhevsky KRIZ@CS.TORONTO.EDU Ilya Sutskever ILYA@CS.TORONTO.EDU Ruslan Salakhutdinov RSALAKHU@CS.TORONTO.EDU

Nitish Srivastava NITISH@CS.TORONTO.EDU Geoffrey Hinton HINTON@CS.TORONTO.EDU Alex Krizhevsky KRIZ@CS.TORONTO.EDU Ilya Sutskever ILYA@CS.TORONTO.EDU Ruslan Salakhutdinov RSALAKHU@CS.TORONTO.EDU

Department of Computer Science

计算机科学系

University of Toronto

多伦多大学

10 Kings College Road, Rm 3302

国王学院路10号，3302室

Toronto, Ontario, M5S 3G4, Canada.

加拿大安大略省多伦多，M5S 3G4

Editor: Yoshua Bengio

编辑:Yoshua Bengio

## Abstract

## 摘要

Deep neural nets with a large number of parameters are very powerful machine learning systems. However, overfitting is a serious problem in such networks. Large networks are also slow to use, making it difficult to deal with overfitting by combining the predictions of many different large neural nets at test time. Dropout is a technique for addressing this problem. The key idea is to randomly drop units (along with their connections) from the neural network during training. This prevents units from co-adapting too much. During training, dropout samples from an exponential number of different "thinned" networks. At test time, it is easy to approximate the effect of averaging the predictions of all these thinned networks by simply using a single unthinned network that has smaller weights. This significantly reduces overfitting and gives major improvements over other regularization methods. We show that dropout improves the performance of neural networks on supervised learning tasks in vision, speech recognition, document classification and computational biology, obtaining state-of-the-art results on many benchmark data sets.

具有大量参数的深度神经网络是非常强大的机器学习系统。然而，过拟合是此类网络中的一个严重问题。大型网络的使用也较为缓慢，这使得在测试时通过结合多个不同大型神经网络的预测来处理过拟合变得困难。Dropout是一种解决该问题的技术。其核心思想是在训练过程中随机丢弃神经网络中的单元(及其连接)，以防止单元之间过度协同适应。在训练时，dropout相当于从指数级数量的不同“稀疏”网络中采样。测试时，可以通过使用一个权重较小的完整网络来近似所有这些稀疏网络预测的平均效果。这显著减少了过拟合，并在其他正则化方法上带来了重大改进。我们展示了dropout在视觉、语音识别、文档分类和计算生物学等监督学习任务中提升神经网络性能的效果，在多个基准数据集上取得了最先进的结果。

Keywords: neural networks, regularization, model combination, deep learning

关键词:神经网络，正则化，模型组合，深度学习

## 1. Introduction

## 1. 引言

Deep neural networks contain multiple non-linear hidden layers and this makes them very expressive models that can learn very complicated relationships between their inputs and outputs. With limited training data, however, many of these complicated relationships will be the result of sampling noise, so they will exist in the training set but not in real test data even if it is drawn from the same distribution. This leads to overfitting and many methods have been developed for reducing it. These include stopping the training as soon as performance on a validation set starts to get worse, introducing weight penalties of various kinds such as L1 and L2 regularization and soft weight sharing (Nowlan and Hinton, 1992).

深度神经网络包含多个非线性隐藏层，使其成为能够学习输入与输出之间复杂关系的高度表达性模型。然而，在训练数据有限的情况下，许多复杂关系可能仅是采样噪声的结果，因此它们存在于训练集中，但即使测试数据来自相同分布，也不会在真实测试数据中出现。这导致了过拟合，针对这一问题已经开发了多种方法，包括在验证集性能开始恶化时停止训练，引入各种权重惩罚如L1和L2正则化以及软权重共享(Nowlan和Hinton，1992)。

With unlimited computation, the best way to "regularize" a fixed-sized model is to average the predictions of all possible settings of the parameters, weighting each setting by its posterior probability given the training data. This can sometimes be approximated quite well for simple or small models (Xiong et al., 2011; Salakhutdinov and Mnih, 2008), but we would like to approach the performance of the Bayesian gold standard using considerably less computation. We propose to do this by approximating an equally weighted geometric mean of the predictions of an exponential number of learned models that share parameters.

在计算资源无限的情况下，对固定大小模型进行“正则化”的最佳方法是对所有可能参数设置的预测进行加权平均，权重为给定训练数据的后验概率。这在简单或小型模型中有时可以较好地近似(Xiong等，2011；Salakhutdinov和Mnih，2008)，但我们希望用更少的计算量接近贝叶斯金标准的性能。我们提出通过近似指数级数量的共享参数学习模型预测的等权几何平均来实现这一目标。

![bo_d1c3o4n7aajc7389qei0_1_437_252_922_499_0.jpg](images/bo_d1c3o4n7aajc7389qei0_1_437_252_922_499_0.jpg)

Figure 1: Dropout Neural Net Model. Left: A standard neural net with 2 hidden layers. Right: An example of a thinned net produced by applying dropout to the network on the left. Crossed units have been dropped.

图1:Dropout神经网络模型。左图:具有2个隐藏层的标准神经网络。右图:通过对左侧网络应用dropout产生的稀疏网络示例。被划掉的单元已被丢弃。

Model combination nearly always improves the performance of machine learning methods. With large neural networks, however, the obvious idea of averaging the outputs of many separately trained nets is prohibitively expensive. Combining several models is most helpful when the individual models are different from each other and in order to make neural net models different, they should either have different architectures or be trained on different data. Training many different architectures is hard because finding optimal hyperparameters for each architecture is a daunting task and training each large network requires a lot of computation. Moreover, large networks normally require large amounts of training data and there may not be enough data available to train different networks on different subsets of the data. Even if one was able to train many different large networks, using them all at test time is infeasible in applications where it is important to respond quickly.

模型组合几乎总能提升机器学习方法的性能。然而，对于大型神经网络，简单地平均多个独立训练网络的输出代价过高。组合多个模型最有效的前提是各模型之间存在差异，而要使神经网络模型不同，它们应具有不同的架构或在不同数据上训练。训练多种架构困难重重，因为为每种架构寻找最优超参数是一项艰巨任务，且训练每个大型网络都需大量计算。此外，大型网络通常需要大量训练数据，可能没有足够数据支持在不同子集上训练不同网络。即使能够训练多个大型网络，在测试时同时使用它们在需要快速响应的应用中也不可行。

Dropout is a technique that addresses both these issues. It prevents overfitting and provides a way of approximately combining exponentially many different neural network architectures efficiently. The term "dropout" refers to dropping out units (hidden and visible) in a neural network. By dropping a unit out, we mean temporarily removing it from the network, along with all its incoming and outgoing connections, as shown in Figure 1. The choice of which units to drop is random. In the simplest case, each unit is retained with a fixed probability $p$ independent of other units, where $p$ can be chosen using a validation set or can simply be set at 0.5 , which seems to be close to optimal for a wide range of networks and tasks. For the input units, however, the optimal probability of retention is usually closer to 1 than to 0.5 .

Dropout技术同时解决了上述两个问题。它防止过拟合，并提供了一种高效近似组合指数级不同神经网络架构的方法。“dropout”指的是在神经网络中丢弃单元(包括隐藏层和输入层单元)。丢弃单元即暂时将其及其所有输入输出连接从网络中移除，如图1所示。丢弃哪些单元是随机选择的。在最简单的情况下，每个单元以固定概率$p$被保留，且相互独立，该概率可通过验证集选择，或简单设为0.5，这对多种网络和任务来说接近最优。但对于输入单元，最佳保留概率通常更接近1而非0.5。

![bo_d1c3o4n7aajc7389qei0_2_344_253_1029_289_0.jpg](images/bo_d1c3o4n7aajc7389qei0_2_344_253_1029_289_0.jpg)

Figure 2: Left: A unit at training time that is present with probability $p$ and is connected to units in the next layer with weights w. Right: At test time, the unit is always present and the weights are multiplied by $p$ . The output at test time is same as the expected output at training time.

图2:左图:训练时某单元以概率$p$存在，并通过权重w连接到下一层的单元。右图:测试时该单元始终存在，权重乘以$p$。测试时的输出与训练时的期望输出相同。

Applying dropout to a neural network amounts to sampling a "thinned" network from it. The thinned network consists of all the units that survived dropout (Figure 1b). A neural net with $n$ units, can be seen as a collection of ${2}^{n}$ possible thinned neural networks. These networks all share weights so that the total number of parameters is still $O\left( {n}^{2}\right)$ , or less. For each presentation of each training case, a new thinned network is sampled and trained. So training a neural network with dropout can be seen as training a collection of ${2}^{n}$ thinned networks with extensive weight sharing, where each thinned network gets trained very rarely, if at all.

对神经网络应用dropout相当于从中采样一个“稀疏”网络。稀疏网络由所有未被dropout丢弃的单元组成(图1b)。一个拥有$n$个单元的神经网络，可以看作是${2}^{n}$个可能的稀疏神经网络的集合。这些网络共享权重，因此参数总数仍为$O\left( {n}^{2}\right)$或更少。每次训练样本呈现时，都会采样并训练一个新的稀疏网络。因此，使用dropout训练神经网络可以看作是训练一个拥有广泛权重共享的${2}^{n}$个稀疏网络集合，其中每个稀疏网络几乎很少被训练，甚至可能根本未被训练。

At test time, it is not feasible to explicitly average the predictions from exponentially many thinned models. However, a very simple approximate averaging method works well in practice. The idea is to use a single neural net at test time without dropout. The weights of this network are scaled-down versions of the trained weights. If a unit is retained with probability $p$ during training, the outgoing weights of that unit are multiplied by $p$ at test time as shown in Figure 2. This ensures that for any hidden unit the expected output (under the distribution used to drop units at training time) is the same as the actual output at test time. By doing this scaling, ${2}^{n}$ networks with shared weights can be combined into a single neural network to be used at test time. We found that training a network with dropout and using this approximate averaging method at test time leads to significantly lower generalization error on a wide variety of classification problems compared to training with other regularization methods.

测试时，显式地对指数级数量的稀疏模型的预测进行平均不可行。然而，一种非常简单的近似平均方法在实践中效果良好。其思路是在测试时使用一个不带dropout的单一神经网络。该网络的权重是训练权重的缩小版本。如果训练时某单元以概率$p$被保留，则测试时该单元的输出权重乘以$p$，如图2所示。这保证了对于任何隐藏单元，其期望输出(基于训练时丢弃单元的分布)与测试时的实际输出相同。通过这种缩放，拥有共享权重的${2}^{n}$个网络可以合并为一个单一神经网络用于测试。我们发现，使用dropout训练网络并在测试时采用此近似平均方法，在各种分类问题上相比其他正则化方法能显著降低泛化误差。

The idea of dropout is not limited to feed-forward neural nets. It can be more generally applied to graphical models such as Boltzmann Machines. In this paper, we introduce the dropout Restricted Boltzmann Machine model and compare it to standard Restricted Boltzmann Machines (RBM). Our experiments show that dropout RBMs are better than standard RBMs in certain respects.

dropout的思想不限于前馈神经网络。它可以更广泛地应用于图模型，如玻尔兹曼机(Boltzmann Machines)。本文介绍了dropout受限玻尔兹曼机(Restricted Boltzmann Machine, RBM)模型，并将其与标准受限玻尔兹曼机进行比较。我们的实验表明，dropout RBM在某些方面优于标准RBM。

This paper is structured as follows. Section 2 describes the motivation for this idea. Section 3 describes relevant previous work. Section 4 formally describes the dropout model. Section 5 gives an algorithm for training dropout networks. In Section 6, we present our experimental results where we apply dropout to problems in different domains and compare it with other forms of regularization and model combination. Section 7 analyzes the effect of dropout on different properties of a neural network and describes how dropout interacts with the network's hyperparameters. Section 8 describes the Dropout RBM model. In Section 9 we explore the idea of marginalizing dropout. In Appendix A we present a practical guide for training dropout nets. This includes a detailed analysis of the practical considerations involved in choosing hyperparameters when training dropout networks.

本文结构如下。第2节介绍该思想的动机。第3节回顾相关的前期工作。第4节正式描述dropout模型。第5节给出训练dropout网络的算法。第6节展示我们的实验结果，应用dropout于不同领域的问题，并与其他正则化和模型组合方法进行比较。第7节分析dropout对神经网络不同性质的影响，并描述dropout与网络超参数的交互。第8节介绍Dropout RBM模型。第9节探讨对dropout进行边缘化的思想。附录A提供了训练dropout网络的实用指南，包括选择超参数时的详细实践考虑分析。

## 2. Motivation

## 2. 动机

A motivation for dropout comes from a theory of the role of sex in evolution (Livnat et al., 2010). Sexual reproduction involves taking half the genes of one parent and half of the other, adding a very small amount of random mutation, and combining them to produce an offspring. The asexual alternative is to create an offspring with a slightly mutated copy of the parent's genes. It seems plausible that asexual reproduction should be a better way to optimize individual fitness because a good set of genes that have come to work well together can be passed on directly to the offspring. On the other hand, sexual reproduction is likely to break up these co-adapted sets of genes, especially if these sets are large and, intuitively, this should decrease the fitness of organisms that have already evolved complicated coadaptations. However, sexual reproduction is the way most advanced organisms evolved.

dropout的动机来源于关于性在进化中作用的理论(Livnat等，2010)。有性生殖涉及从一方亲本取一半基因，另一方取另一半基因，加入极少量随机突变，组合产生后代。无性生殖则是用亲本基因的略微突变副本产生后代。看似无性生殖应更有利于优化个体适应度，因为一组已协同良好的基因可以直接传递给后代。另一方面，有性生殖可能会打破这些协同适应的基因组合，尤其当这些组合较大时，直观上这应降低已进化出复杂协同适应的生物的适应度。然而，大多数高级生物都是通过有性生殖进化而来。

One possible explanation for the superiority of sexual reproduction is that, over the long term, the criterion for natural selection may not be individual fitness but rather mix-ability of genes. The ability of a set of genes to be able to work well with another random set of genes makes them more robust. Since a gene cannot rely on a large set of partners to be present at all times, it must learn to do something useful on its own or in collaboration with a small number of other genes. According to this theory, the role of sexual reproduction is not just to allow useful new genes to spread throughout the population, but also to facilitate this process by reducing complex co-adaptations that would reduce the chance of a new gene improving the fitness of an individual. Similarly, each hidden unit in a neural network trained with dropout must learn to work with a randomly chosen sample of other units. This should make each hidden unit more robust and drive it towards creating useful features on its own without relying on other hidden units to correct its mistakes. However, the hidden units within a layer will still learn to do different things from each other. One might imagine that the net would become robust against dropout by making many copies of each hidden unit, but this is a poor solution for exactly the same reason as replica codes are a poor way to deal with a noisy channel.

性繁殖优越性的一个可能解释是，从长远来看，自然选择的标准可能不是个体适应度，而是基因的混合能力。一组基因能够与另一组随机基因良好协作，使其更具鲁棒性。由于基因不能依赖于始终存在的大量合作伙伴，它必须学会独立或与少数其他基因协作完成有用的功能。根据该理论，性繁殖的作用不仅是让有用的新基因在群体中传播，还通过减少复杂的共适应，促进这一过程，从而避免新基因降低个体适应度。同样，使用dropout训练的神经网络中的每个隐藏单元必须学会与随机选择的其他单元协作。这应使每个隐藏单元更具鲁棒性，促使其独立创造有用特征，而不依赖其他隐藏单元纠正其错误。然而，同一层内的隐藏单元仍会学会彼此不同的功能。有人可能会想，通过复制多个隐藏单元来增强网络对dropout的鲁棒性，但这与复制码(replica codes)处理噪声信道的效果差不多，是一种糟糕的解决方案。

A closely related, but slightly different motivation for dropout comes from thinking about successful conspiracies. Ten conspiracies each involving five people is probably a better way to create havoc than one big conspiracy that requires fifty people to all play their parts correctly. If conditions do not change and there is plenty of time for rehearsal, a big conspiracy can work well, but with non-stationary conditions, the smaller the conspiracy the greater its chance of still working. Complex co-adaptations can be trained to work well on a training set, but on novel test data they are far more likely to fail than multiple simpler co-adaptations that achieve the same thing.

一个密切相关但略有不同的dropout动机来自对成功阴谋的思考。十个各由五人组成的阴谋，可能比一个需要五十人全部正确配合的大阴谋更容易制造混乱。如果条件不变且有充足的排练时间，大阴谋可以运作良好，但在非平稳条件下，阴谋规模越小，成功的可能性越大。复杂的共适应可以在训练集上表现良好，但在新的测试数据上，它们比多个实现相同功能的简单共适应更容易失败。

## 3. Related Work

## 3. 相关工作

Dropout can be interpreted as a way of regularizing a neural network by adding noise to its hidden units. The idea of adding noise to the states of units has previously been used in the context of Denoising Autoencoders (DAEs) by Vincent et al. (2008, 2010) where noise is added to the input units of an autoencoder and the network is trained to reconstruct the noise-free input. Our work extends this idea by showing that dropout can be effectively applied in the hidden layers as well and that it can be interpreted as a form of model averaging. We also show that adding noise is not only useful for unsupervised feature learning but can also be extended to supervised learning problems. In fact, our method can be applied to other neuron-based architectures, for example, Boltzmann Machines. While $5\%$ noise typically works best for DAEs, we found that our weight scaling procedure applied at test time enables us to use much higher noise levels. Dropping out ${20}\%$ of the input units and ${50}\%$ of the hidden units was often found to be optimal.

Dropout可以被解释为通过向隐藏单元添加噪声来正则化神经网络的一种方法。向单元状态添加噪声的想法此前已在Vincent等人(2008，2010)提出的去噪自编码器(Denoising Autoencoders, DAEs)中使用，在那里噪声被添加到自编码器的输入单元，网络被训练以重构无噪声的输入。我们的工作扩展了这一思想，表明dropout也可以有效地应用于隐藏层，并且可以被解释为一种模型平均的方法。我们还展示了添加噪声不仅对无监督特征学习有用，也可以扩展到监督学习问题。事实上，我们的方法可以应用于其他基于神经元的架构，例如玻尔兹曼机(Boltzmann Machines)。虽然$5\%$噪声通常对DAEs效果最佳，但我们发现测试时应用的权重缩放方法使我们能够使用更高水平的噪声。通常发现丢弃${20}\%$的输入单元和${50}\%$的隐藏单元是最优的。

Since dropout can be seen as a stochastic regularization technique, it is natural to consider its deterministic counterpart which is obtained by marginalizing out the noise. In this paper, we show that, in simple cases, dropout can be analytically marginalized out to obtain deterministic regularization methods. Recently, van der Maaten et al. (2013) also explored deterministic regularizers corresponding to different exponential-family noise distributions, including dropout (which they refer to as "blankout noise"). However, they apply noise to the inputs and only explore models with no hidden layers. Wang and Manning (2013) proposed a method for speeding up dropout by marginalizing dropout noise. Chen et al. (2012) explored marginalization in the context of denoising autoencoders.

由于dropout可以看作是一种随机正则化技术，因此自然会考虑其确定性对应方法，即通过边缘化噪声得到的。在本文中，我们展示了在简单情况下，dropout可以通过解析边缘化得到确定性正则化方法。最近，van der Maaten等人(2013)也探讨了对应不同指数族噪声分布的确定性正则化器，包括dropout(他们称之为“blankout noise”)。然而，他们只对输入施加噪声，且仅研究无隐藏层的模型。Wang和Manning(2013)提出了一种通过边缘化dropout噪声来加速dropout的方法。Chen等人(2012)则在去噪自编码器的背景下探讨了边缘化。

In dropout, we minimize the loss function stochastically under a noise distribution. This can be seen as minimizing an expected loss function. Previous work of Globerson and Roweis (2006); Dekel et al. (2010) explored an alternate setting where the loss is minimized when an adversary gets to pick which units to drop. Here, instead of a noise distribution, the maximum number of units that can be dropped is fixed. However, this work also does not explore models with hidden units.

在dropout中，我们在噪声分布下随机最小化损失函数。这可以看作是最小化期望损失函数。Globerson和Roweis(2006)；Dekel等人(2010)的先前工作探讨了另一种设置，即当对手选择丢弃哪些单元时最小化损失。在这里，不是噪声分布，而是固定了最大可丢弃单元数。然而，该工作也未探讨含隐藏单元的模型。

## 4. Model Description

## 4. 模型描述

This section describes the dropout neural network model. Consider a neural network with $L$ hidden layers. Let $l \in  \{ 1,\ldots , L\}$ index the hidden layers of the network. Let ${\mathbf{z}}^{\left( l\right) }$ denote the vector of inputs into layer $l,{\mathbf{y}}^{\left( l\right) }$ denote the vector of outputs from layer $l\left( {{\mathbf{y}}^{\left( 0\right) } = \mathbf{x}}\right.$ is the input). ${W}^{\left( l\right) }$ and ${\mathbf{b}}^{\left( l\right) }$ are the weights and biases at layer $l$ . The feed-forward operation of a standard neural network (Figure 3a) can be described as (for $l \in  \{ 0,\ldots , L - 1\}$ and any hidden unit $i$ )

本节介绍了dropout神经网络模型。考虑一个具有$L$个隐藏层的神经网络。令$l \in  \{ 1,\ldots , L\}$表示网络的隐藏层索引。令${\mathbf{z}}^{\left( l\right) }$表示第$l,{\mathbf{y}}^{\left( l\right) }$层的输入向量，$l\left( {{\mathbf{y}}^{\left( 0\right) } = \mathbf{x}}\right.$表示第$l\left( {{\mathbf{y}}^{\left( 0\right) } = \mathbf{x}}\right.$层的输出向量(当$l\left( {{\mathbf{y}}^{\left( 0\right) } = \mathbf{x}}\right.$是输入层时)。${W}^{\left( l\right) }$和${\mathbf{b}}^{\left( l\right) }$分别是第$l$层的权重和偏置。标准神经网络(图3a)的前向传播操作可以描述为(对于$l \in  \{ 0,\ldots , L - 1\}$和任意隐藏单元$i$)

$$
{z}_{i}^{\left( l + 1\right) } = {\mathbf{w}}_{i}^{\left( l + 1\right) }{\mathbf{y}}^{l} + {b}_{i}^{\left( l + 1\right) },
$$

$$
{y}_{i}^{\left( l + 1\right) } = f\left( {z}_{i}^{\left( l + 1\right) }\right) ,
$$

where $f$ is any activation function, for example, $f\left( x\right)  = 1/\left( {1 + \exp \left( {-x}\right) }\right)$ .

其中$f$是任意激活函数，例如$f\left( x\right)  = 1/\left( {1 + \exp \left( {-x}\right) }\right)$。

With dropout, the feed-forward operation becomes (Figure 3b)

使用dropout时，前向传播操作变为(图3b)

$$
{r}_{j}^{\left( l\right) } \sim  \operatorname{Bernoulli}\left( p\right)
$$

$$
{\widetilde{\mathbf{y}}}^{\left( l\right) } = {\mathbf{r}}^{\left( l\right) } * {\mathbf{y}}^{\left( l\right) },
$$

$$
{z}_{i}^{\left( l + 1\right) } = {\mathbf{w}}_{i}^{\left( l + 1\right) }{\widetilde{\mathbf{y}}}^{l} + {b}_{i}^{\left( l + 1\right) },
$$

$$
{y}_{i}^{\left( l + 1\right) } = f\left( {z}_{i}^{\left( l + 1\right) }\right) .
$$

![bo_d1c3o4n7aajc7389qei0_5_304_256_1112_600_0.jpg](images/bo_d1c3o4n7aajc7389qei0_5_304_256_1112_600_0.jpg)

Figure 3: Comparison of the basic operations of a standard and dropout network.

图3:标准网络与dropout网络基本操作的比较。

Here $*$ denotes an element-wise product. For any layer $l,{\mathbf{r}}^{\left( l\right) }$ is a vector of independent Bernoulli random variables each of which has probability $p$ of being 1 . This vector is sampled and multiplied element-wise with the outputs of that layer, ${\mathbf{y}}^{\left( l\right) }$ , to create the thinned outputs ${\widetilde{\mathbf{y}}}^{\left( l\right) }$ . The thinned outputs are then used as input to the next layer. This process is applied at each layer. This amounts to sampling a sub-network from a larger network. For learning, the derivatives of the loss function are backpropagated through the sub-network. At test time, the weights are scaled as ${W}_{\text{test }}^{\left( l\right) } = p{W}^{\left( l\right) }$ as shown in Figure 2. The resulting neural network is used without dropout.

这里$*$表示逐元素乘积。对于任意层，$l,{\mathbf{r}}^{\left( l\right) }$是一个独立伯努利随机变量向量，每个变量以概率$p$取值为1。该向量被采样后与该层的输出${\mathbf{y}}^{\left( l\right) }$逐元素相乘，生成稀疏输出${\widetilde{\mathbf{y}}}^{\left( l\right) }$。稀疏输出随后作为下一层的输入。该过程在每一层都被应用，相当于从一个大网络中采样出一个子网络。学习时，损失函数的导数通过该子网络反向传播。测试时，权重按图2所示缩放为${W}_{\text{test }}^{\left( l\right) } = p{W}^{\left( l\right) }$。最终得到的神经网络在测试时不使用dropout。

## 5. Learning Dropout Nets

## 5. Dropout网络的学习

This section describes a procedure for training dropout neural nets.

本节介绍训练dropout神经网络的过程。

### 5.1 Backpropagation

### 5.1 反向传播

Dropout neural networks can be trained using stochastic gradient descent in a manner similar to standard neural nets. The only difference is that for each training case in a mini-batch, we sample a thinned network by dropping out units. Forward and backpropagation for that training case are done only on this thinned network. The gradients for each parameter are averaged over the training cases in each mini-batch. Any training case which does not use a parameter contributes a gradient of zero for that parameter. Many methods have been used to improve stochastic gradient descent such as momentum, annealed learning rates and L2 weight decay. Those were found to be useful for dropout neural networks as well.

dropout神经网络可以使用随机梯度下降法训练，方法与标准神经网络类似。唯一的区别是，对于小批量中的每个训练样本，我们通过丢弃部分单元采样出一个稀疏网络。该训练样本的前向和反向传播仅在该稀疏网络上进行。每个参数的梯度在小批量的训练样本中取平均。任何未使用该参数的训练样本对该参数的梯度贡献为零。已有多种方法用于改进随机梯度下降，如动量法、退火学习率和L2权重衰减，这些方法对dropout神经网络同样有效。

One particular form of regularization was found to be especially useful for dropout-constraining the norm of the incoming weight vector at each hidden unit to be upper bounded by a fixed constant $c$ . In other words, if $\mathbf{w}$ represents the vector of weights incident on any hidden unit, the neural network was optimized under the constraint $\parallel \mathbf{w}{\parallel }_{2} \leq  c$ . This constraint was imposed during optimization by projecting $\mathbf{w}$ onto the surface of a ball of radius $c$ , whenever $\mathbf{w}$ went out of it. This is also called max-norm regularization since it implies that the maximum value that the norm of any weight can take is $c$ . The constant $c$ is a tunable hyperparameter, which is determined using a validation set. Max-norm regularization has been previously used in the context of collaborative filtering (Srebro and Shraibman, 2005). It typically improves the performance of stochastic gradient descent training of deep neural nets, even when no dropout is used.

一种特别有效的正则化形式是对dropout网络施加约束——限制每个隐藏单元输入权重向量的范数上界为固定常数$c$。换言之，若$\mathbf{w}$表示任一隐藏单元的权重向量，则神经网络在约束条件$\parallel \mathbf{w}{\parallel }_{2} \leq  c$下进行优化。该约束通过在优化过程中将$\mathbf{w}$投影到半径为$c$的球面上实现，当$\mathbf{w}$超出该球面时进行投影。这也称为最大范数正则化(max-norm regularization)，意味着任何权重的范数最大值为$c$。常数$c$是可调超参数，通过验证集确定。最大范数正则化此前已在协同过滤(Srebro和Shraibman，2005)中使用。即使不使用dropout，它通常也能提升深度神经网络随机梯度下降训练的性能。

Although dropout alone gives significant improvements, using dropout along with max-norm regularization, large decaying learning rates and high momentum provides a significant boost over just using dropout. A possible justification is that constraining weight vectors to lie inside a ball of fixed radius makes it possible to use a huge learning rate without the possibility of weights blowing up. The noise provided by dropout then allows the optimization process to explore different regions of the weight space that would have otherwise been difficult to reach. As the learning rate decays, the optimization takes shorter steps, thereby doing less exploration and eventually settles into a minimum.

虽然单独使用dropout就能带来显著提升，但将dropout与最大范数正则化(max-norm regularization)、较大的衰减学习率和高动量结合使用，相较于仅使用dropout能获得更显著的提升。一个可能的解释是，将权重向量限制在固定半径的球体内，使得可以使用极大的学习率而不会导致权重爆炸。dropout引入的噪声则使优化过程能够探索权重空间中原本难以到达的不同区域。随着学习率的衰减，优化步长变短，探索减少，最终收敛到一个极小值。

### 5.2 Unsupervised Pretraining

### 5.2 无监督预训练

Neural networks can be pretrained using stacks of RBMs (Hinton and Salakhutdinov, 2006), autoencoders (Vincent et al., 2010) or Deep Boltzmann Machines (Salakhutdinov and Hinton, 2009). Pretraining is an effective way of making use of unlabeled data. Pretraining followed by finetuning with backpropagation has been shown to give significant performance boosts over finetuning from random initializations in certain cases.

神经网络可以通过堆叠受限玻尔兹曼机(RBMs，Hinton和Salakhutdinov，2006)、自编码器(Vincent等，2010)或深度玻尔兹曼机(Deep Boltzmann Machines，Salakhutdinov和Hinton，2009)进行预训练。预训练是一种有效利用无标签数据的方法。实验证明，在某些情况下，预训练后再用反向传播微调，相较于从随机初始化开始微调，能显著提升性能。

Dropout can be applied to finetune nets that have been pretrained using these techniques. The pretraining procedure stays the same. The weights obtained from pretraining should be scaled up by a factor of $1/p$ . This makes sure that for each unit, the expected output from it under random dropout will be the same as the output during pretraining. We were initially concerned that the stochastic nature of dropout might wipe out the information in the pretrained weights. This did happen when the learning rates used during finetuning were comparable to the best learning rates for randomly initialized nets. However, when the learning rates were chosen to be smaller, the information in the pretrained weights seemed to be retained and we were able to get improvements in terms of the final generalization error compared to not using dropout when finetuning.

dropout可以应用于使用上述技术预训练后的网络微调。预训练过程保持不变。预训练得到的权重应按$1/p$倍数放大。这确保了在随机dropout下，每个单元的期望输出与预训练时的输出相同。我们最初担心dropout的随机性可能会抹除预训练权重中的信息。当微调时使用的学习率与随机初始化网络的最佳学习率相当时，确实发生了这种情况。然而，当选择较小的学习率时，预训练权重中的信息似乎得以保留，且相比微调时不使用dropout，最终的泛化误差有所改善。

## 6. Experimental Results

## 6. 实验结果

We trained dropout neural networks for classification problems on data sets in different domains. We found that dropout improved generalization performance on all data sets compared to neural networks that did not use dropout. Table 1 gives a brief description of the data sets. The data sets are

我们在不同领域的数据集上训练了使用dropout的神经网络进行分类任务。结果表明，dropout在所有数据集上均提升了泛化性能，相较于未使用dropout的神经网络。表1简要介绍了这些数据集。数据集包括

- MNIST : A standard toy data set of handwritten digits.

- MNIST:一个标准的手写数字玩具数据集。

- TIMIT : A standard speech benchmark for clean speech recognition.

- TIMIT:一个用于干净语音识别的标准语音基准数据集。

- CIFAR-10 and CIFAR-100 : Tiny natural images (Krizhevsky, 2009).

- CIFAR-10和CIFAR-100:小型自然图像数据集(Krizhevsky，2009)。

- Street View House Numbers data set (SVHN) : Images of house numbers collected by Google Street View (Netzer et al., 2011).

- 街景门牌号数据集(SVHN):由Google街景收集的门牌号图像(Netzer等，2011)。

- ImageNet : A large collection of natural images.

- ImageNet:一个大型自然图像集合。

- Reuters-RCV1 : A collection of Reuters newswire articles.

- Reuters-RCV1:路透社新闻稿集合。

- Alternative Splicing data set: RNA features for predicting alternative gene splicing (Xiong et al., 2011).

- 可变剪接数据集:用于预测基因可变剪接的RNA特征(Xiong等，2011)。

We chose a diverse set of data sets to demonstrate that dropout is a general technique for improving neural nets and is not specific to any particular application domain. In this section, we present some key results that show the effectiveness of dropout. A more detailed description of all the experiments and data sets is provided in Appendix B.

我们选择了多样化的数据集，以证明dropout是一种通用的神经网络改进技术，而非针对某一特定应用领域。在本节中，我们展示了一些关键结果以证明dropout的有效性。所有实验和数据集的更详细描述见附录B。

<table><tr><td>Data Set</td><td>Domain</td><td>Dimensionality</td><td>Training Set</td><td>Test Set</td></tr><tr><td>MNIST</td><td>Vision</td><td>${784}\left( {{28} \times  {28}\text{ grayscale }}\right)$</td><td>60K</td><td>10K</td></tr><tr><td>SVHN</td><td>Vision</td><td>${3072}\left( {{32} \times  {32}\text{color}}\right)$</td><td>600K</td><td>26K</td></tr><tr><td>CIFAR-10/100</td><td>Vision</td><td>${3072}\left( {{32} \times  {32}\text{color}}\right)$</td><td>60K</td><td>10K</td></tr><tr><td>ImageNet (ILSVRC-2012)</td><td>Vision</td><td>${65536}\left( {{256} \times  {256}\text{color}}\right)$</td><td>1.2M</td><td>150K</td></tr><tr><td>TIMIT</td><td>Speech</td><td>2520 (120-dim, 21 frames)</td><td>1.1M frames</td><td>58K frames</td></tr><tr><td>Reuters-RCV1</td><td>Text</td><td>2000</td><td>200K</td><td>200K</td></tr><tr><td>Alternative Splicing</td><td>Genetics</td><td>1014</td><td>2932</td><td>733</td></tr></table>

<table><tbody><tr><td>数据集</td><td>领域</td><td>维度</td><td>训练集</td><td>测试集</td></tr><tr><td>MNIST</td><td>视觉</td><td>${784}\left( {{28} \times  {28}\text{ grayscale }}\right)$</td><td>60K</td><td>10K</td></tr><tr><td>SVHN</td><td>视觉</td><td>${3072}\left( {{32} \times  {32}\text{color}}\right)$</td><td>600K</td><td>26K</td></tr><tr><td>CIFAR-10/100</td><td>视觉</td><td>${3072}\left( {{32} \times  {32}\text{color}}\right)$</td><td>60K</td><td>10K</td></tr><tr><td>ImageNet(ILSVRC-2012)</td><td>视觉</td><td>${65536}\left( {{256} \times  {256}\text{color}}\right)$</td><td>1.2M</td><td>150K</td></tr><tr><td>TIMIT</td><td>语音</td><td>2520(120维，21帧)</td><td>110万帧</td><td>5.8万帧</td></tr><tr><td>Reuters-RCV1</td><td>文本</td><td>2000</td><td>200K</td><td>200K</td></tr><tr><td>可变剪接(Alternative Splicing)</td><td>遗传学</td><td>1014</td><td>2932</td><td>733</td></tr></tbody></table>

Table 1: Overview of the data sets used in this paper.

表1:本文所用数据集概览。

### 6.1 Results on Image Data Sets

### 6.1 图像数据集上的结果

We used five image data sets to evaluate dropout-MNIST, SVHN, CIFAR-10, CIFAR-100 and ImageNet. These data sets include different image types and training set sizes. Models which achieve state-of-the-art results on all of these data sets use dropout.

我们使用了五个图像数据集来评估dropout，分别是MNIST、SVHN、CIFAR-10、CIFAR-100和ImageNet。这些数据集涵盖了不同类型的图像和训练集规模。在所有这些数据集上取得最先进结果的模型均采用了dropout技术。

#### 6.1.1 MNIST

#### 6.1.1 MNIST

<table><tr><td>Method</td><td>Unit Type</td><td>Architecture</td><td>Error %</td></tr><tr><td>Standard Neural Net (Simard et al., 2003)</td><td>Logistic</td><td>2 layers, 800 units</td><td>1.60</td></tr><tr><td>SVM Gaussian kernel</td><td>NA</td><td>NA</td><td>1.40</td></tr><tr><td>Dropout NN</td><td>Logistic</td><td>3 layers, 1024 units</td><td>1.35</td></tr><tr><td>Dropout NN</td><td>ReLU</td><td>3 layers, 1024 units</td><td>1.25</td></tr><tr><td>Dropout NN + max-norm constraint</td><td>ReLU</td><td>3 layers, 1024 units</td><td>1.06</td></tr><tr><td>Dropout NN + max-norm constraint</td><td>ReLU</td><td>3 layers, 2048 units</td><td>1.04</td></tr><tr><td>Dropout NN + max-norm constraint</td><td>ReLU</td><td>2 layers, 4096 units</td><td>1.01</td></tr><tr><td>Dropout NN + max-norm constraint</td><td>ReLU</td><td>2 layers, 8192 units</td><td>0.95</td></tr><tr><td>Dropout NN + max-norm constraint (Goodfellow et al., 2013)</td><td>Maxout</td><td>2 layers, $\left( {5 \times  {240}}\right)$ units</td><td>0.94</td></tr><tr><td>DBN + finetuning (Hinton and Salakhutdinov, 2006)</td><td>Logistic</td><td>500-500-2000</td><td>1.18</td></tr><tr><td>DBM + finetuning (Salakhutdinov and Hinton, 2009)</td><td>Logistic</td><td>500-500-2000</td><td>0.96</td></tr><tr><td>DBN + dropout finetuning</td><td>Logistic</td><td>500-500-2000</td><td>0.92</td></tr><tr><td>DBM + dropout finetuning</td><td>Logistic</td><td>500-500-2000</td><td>0.79</td></tr></table>

<table><tbody><tr><td>方法</td><td>单元类型</td><td>架构</td><td>错误率%</td></tr><tr><td>标准神经网络(Simard 等，2003)</td><td>逻辑回归</td><td>2层，800个单元</td><td>1.60</td></tr><tr><td>支持向量机高斯核</td><td>不适用</td><td>不适用</td><td>1.40</td></tr><tr><td>Dropout神经网络</td><td>逻辑回归</td><td>3层，1024个单元</td><td>1.35</td></tr><tr><td>Dropout神经网络</td><td>ReLU(线性整流单元)</td><td>3层，1024个单元</td><td>1.25</td></tr><tr><td>Dropout神经网络 + 最大范数约束</td><td>ReLU(线性整流单元)</td><td>3层，1024个单元</td><td>1.06</td></tr><tr><td>Dropout神经网络 + 最大范数约束</td><td>ReLU(线性整流单元)</td><td>3层，2048个单元</td><td>1.04</td></tr><tr><td>Dropout神经网络 + 最大范数约束</td><td>ReLU(线性整流单元)</td><td>2层，4096个单元</td><td>1.01</td></tr><tr><td>Dropout神经网络 + 最大范数约束</td><td>ReLU(线性整流单元)</td><td>2层，8192个单元</td><td>0.95</td></tr><tr><td>Dropout神经网络 + 最大范数约束(Goodfellow 等，2013)</td><td>Maxout单元</td><td>2层，$\left( {5 \times  {240}}\right)$个单元</td><td>0.94</td></tr><tr><td>深度置信网络(DBN)+ 微调(Hinton 和 Salakhutdinov，2006)</td><td>逻辑回归</td><td>500-500-2000</td><td>1.18</td></tr><tr><td>深度玻尔兹曼机(DBM)+ 微调(Salakhutdinov 和 Hinton，2009)</td><td>逻辑回归</td><td>500-500-2000</td><td>0.96</td></tr><tr><td>深度置信网络(DBN)+ Dropout微调</td><td>逻辑回归</td><td>500-500-2000</td><td>0.92</td></tr><tr><td>深度玻尔兹曼机(DBM)+ Dropout微调</td><td>逻辑回归</td><td>500-500-2000</td><td>0.79</td></tr></tbody></table>

## Table 2: Comparison of different models on MNIST.

## 表2:不同模型在MNIST上的比较。

The MNIST data set consists of ${28} \times  {28}$ pixel handwritten digit images. The task is to classify the images into 10 digit classes. Table 2 compares the performance of dropout with other techniques. The best performing neural networks for the permutation invariant setting that do not use dropout or unsupervised pretraining achieve an error of about ${1.60}\%$ (Simard et al.,2003). With dropout the error reduces to 1.35%. Replacing logistic units with rectified linear units (ReLUs) (Jarrett et al., 2009) further reduces the error to 1.25%. Adding max-norm regularization again reduces it to 1.06%. Increasing the size of the network leads to better results. A neural net with 2 layers and 8192 units per layer gets down to 0.95% error. Note that this network has more than 65 million parameters and is being trained on a data set of size 60,000 . Training a network of this size to give good generalization error is very hard with standard regularization methods and early stopping. Dropout, on the other hand, prevents overfitting, even in this case. It does not even need early stopping. Goodfellow et al. (2013) showed that results can be further improved to ${0.94}\%$ by replacing ReLU units with maxout units. All dropout nets use $p = {0.5}$ for hidden units and $p = {0.8}$ for input units. More experimental details can be found in Appendix B.1.

MNIST数据集由${28} \times  {28}$像素的手写数字图像组成。任务是将图像分类为10个数字类别。表2比较了dropout与其他技术的性能。在不使用dropout或无监督预训练的置换不变(permutation invariant)设置下，表现最好的神经网络的错误率约为${1.60}\%$(Simard等，2003)。使用dropout后，错误率降至1.35%。将逻辑单元替换为修正线性单元(ReLU，Rectified Linear Units)(Jarrett等，2009)进一步将错误率降低到1.25%。加入最大范数正则化(max-norm regularization)后，错误率再次降低到1.06%。增加网络规模带来更好的结果。一个具有2层、每层8192个单元的神经网络错误率降至0.95%。注意该网络参数超过6500万，训练数据集大小为60000。用标准正则化方法和早停法训练如此规模的网络以获得良好泛化误差非常困难。另一方面，dropout即使在这种情况下也能防止过拟合，甚至不需要早停。Goodfellow等(2013)表明，通过将ReLU单元替换为maxout单元，结果可进一步提升至${0.94}\%$。所有dropout网络在隐藏单元使用$p = {0.5}$，输入单元使用$p = {0.8}$。更多实验细节见附录B.1。

Dropout nets pretrained with stacks of RBMs and Deep Boltzmann Machines also give improvements as shown in Table 2. DBM-pretrained dropout nets achieve a test error of ${0.79}\%$ which is the best performance ever reported for the permutation invariant setting. We note that it possible to obtain better results by using 2-D spatial information and augmenting the training set with distorted versions of images from the standard training set. We demonstrate the effectiveness of dropout in that setting on more interesting data sets.

使用受限玻尔兹曼机(RBMs)和深度玻尔兹曼机(Deep Boltzmann Machines，DBM)堆叠预训练的dropout网络也带来了提升，如表2所示。DBM预训练的dropout网络在测试中达到${0.79}\%$的错误率，这是迄今为止置换不变设置下报告的最佳性能。我们注意到，通过利用二维空间信息和用标准训练集图像的变形版本扩充训练集，可以获得更好的结果。我们将在更有趣的数据集上展示dropout在该设置下的有效性。

In order to test the robustness of dropout, classification experiments were done with networks of many different architectures keeping all hyperparameters, including $p$ , fixed. Figure 4 shows the test error rates obtained for these different architectures as training progresses. The same architectures trained with and without dropout have drastically different test errors as seen as by the two separate clusters of trajectories. Dropout gives a huge improvement across all architectures, without using hyperparameters that were tuned specifically for each architecture.

为了测试dropout的鲁棒性，进行了多种不同架构的网络分类实验，所有超参数包括$p$均保持不变。图4展示了训练过程中这些不同架构的测试错误率。相同架构在有无dropout训练下的测试错误率截然不同，表现为两组明显分离的轨迹。dropout在所有架构上均带来了巨大提升，且未使用针对每个架构专门调优的超参数。

![bo_d1c3o4n7aajc7389qei0_8_894_1080_641_492_0.jpg](images/bo_d1c3o4n7aajc7389qei0_8_894_1080_641_492_0.jpg)

Figure 4: Test error for different architectures with and without dropout. The networks have 2 to 4 hidden layers each with 1024 to 2048 units.

图4:不同架构在有无dropout情况下的测试错误率。网络包含2至4个隐藏层，每层1024至2048个单元。

#### 6.1.2 STREET VIEW HOUSE NUMBERS

#### 6.1.2 街景门牌号数据集

The Street View House Numbers (SVHN) Data Set (Netzer et al., 2011) consists of color images of house numbers collected by Google Street View. Figure 5a shows some examples of images from this data set. The part of the data set that we use in our experiments consists of ${32} \times  {32}$ color images roughly centered on a digit in a house number. The task is to identify that digit.

街景门牌号(Street View House Numbers，SVHN)数据集(Netzer等，2011)由谷歌街景采集的彩色门牌号图像组成。图5a展示了该数据集的一些示例图像。我们实验中使用的数据集部分包含大约${32} \times  {32}$张彩色图像，图像大致以门牌号中的数字为中心。任务是识别该数字。

For this data set, we applied dropout to convolutional neural networks (LeCun et al., 1989). The best architecture that we found has three convolutional layers followed by 2 fully connected hidden layers. All hidden units were ReLUs. Each convolutional layer was followed by a max-pooling layer. Appendix B. 2 describes the architecture in more detail. Dropout was applied to all the layers of the network with the probability of retaining a hidden unit being $p = \left( {{0.9},{0.75},{0.75},{0.5},{0.5},{0.5}}\right)$ for the different layers of the network (going from input to convolutional layers to fully connected layers). Max-norm regularization was used for weights in both convolutional and fully connected layers. Table 3 compares the results obtained by different methods. We find that convolutional nets outperform other methods. The best performing convolutional nets that do not use dropout achieve an error rate of 3.95%. Adding dropout only to the fully connected layers reduces the error to 3.02%. Adding dropout to the convolutional layers as well further reduces the error to 2.55%. Even more gains can be obtained by using maxout units.

针对该数据集，我们将dropout应用于卷积神经网络(LeCun等，1989)。我们找到的最佳架构包含三层卷积层，后接两层全连接隐藏层。所有隐藏单元均为ReLU。每个卷积层后均跟随一个最大池化层。附录B.2对架构进行了更详细描述。dropout应用于网络所有层，隐藏单元保留概率为$p = \left( {{0.9},{0.75},{0.75},{0.5},{0.5},{0.5}}\right)$，该概率随网络层次(从输入层到卷积层再到全连接层)变化。卷积层和全连接层的权重均使用最大范数正则化。表3比较了不同方法的结果。我们发现卷积网络优于其他方法。未使用dropout的最佳卷积网络错误率为3.95%。仅在全连接层添加dropout后，错误率降至3.02%。同时在卷积层添加dropout后，错误率进一步降至2.55%。使用maxout单元还能获得更大提升。

<table><tr><td>Method</td><td>Error %</td></tr><tr><td>Binary Features (WDCH) (Netzer et al., 2011)</td><td>36.7</td></tr><tr><td>HOG (Netzer et al., 2011)</td><td>15.0</td></tr><tr><td>Stacked Sparse Autoencoders (Netzer et al., 2011)</td><td>10.3</td></tr><tr><td>KMeans (Netzer et al., 2011)</td><td>9.4</td></tr><tr><td>Multi-stage Conv Net with average pooling (Sermanet et al., 2012)</td><td>9.06</td></tr><tr><td>Multi-stage Conv Net + L2 pooling (Sermanet et al., 2012)</td><td>5.36</td></tr><tr><td>Multi-stage Conv Net + L4 pooling + padding (Sermanet et al., 2012)</td><td>4.90</td></tr><tr><td>Conv Net + max-pooling</td><td>3.95</td></tr><tr><td>Conv Net + max pooling + dropout in fully connected layers</td><td>3.02</td></tr><tr><td>Conv Net + stochastic pooling (Zeiler and Fergus, 2013)</td><td>2.80</td></tr><tr><td>Conv Net + max pooling + dropout in all layers</td><td>2.55</td></tr><tr><td>Conv Net + maxout (Goodfellow et al., 2013)</td><td>2.47</td></tr><tr><td>Human Performance</td><td>2.0</td></tr></table>

<table><tbody><tr><td>方法</td><td>错误率%</td></tr><tr><td>二值特征(WDCH)(Netzer 等，2011)</td><td>36.7</td></tr><tr><td>HOG(Netzer 等，2011)</td><td>15.0</td></tr><tr><td>堆叠稀疏自编码器(Netzer 等，2011)</td><td>10.3</td></tr><tr><td>K均值(Netzer 等，2011)</td><td>9.4</td></tr><tr><td>多阶段卷积网络，带平均池化(Sermanet 等，2012)</td><td>9.06</td></tr><tr><td>多阶段卷积网络 + L2池化(Sermanet 等，2012)</td><td>5.36</td></tr><tr><td>多阶段卷积网络 + L4池化 + 填充(Sermanet 等，2012)</td><td>4.90</td></tr><tr><td>卷积网络 + 最大池化</td><td>3.95</td></tr><tr><td>卷积网络 + 最大池化 + 全连接层丢弃法</td><td>3.02</td></tr><tr><td>卷积网络 + 随机池化(Zeiler 和 Fergus，2013)</td><td>2.80</td></tr><tr><td>卷积网络 + 最大池化 + 所有层丢弃法</td><td>2.55</td></tr><tr><td>卷积网络 + maxout(Goodfellow 等，2013)</td><td>2.47</td></tr><tr><td>人类表现</td><td>2.0</td></tr></tbody></table>

Table 3: Results on the Street View House Numbers data set.

表3:街景门牌号码数据集的结果。

The additional gain in performance obtained by adding dropout in the convolutional layers (3.02% to 2.55%) is worth noting. One may have presumed that since the convolutional layers don't have a lot of parameters, overfitting is not a problem and therefore dropout would not have much effect. However, dropout in the lower layers still helps because it provides noisy inputs for the higher fully connected layers which prevents them from overfitting.

在卷积层中加入dropout带来的性能提升(从3.02%降至2.55%)值得注意。有人可能会认为由于卷积层参数不多，过拟合问题不严重，因此dropout效果有限。然而，低层的dropout仍然有帮助，因为它为更高层的全连接层提供了带噪声的输入，从而防止它们过拟合。

#### 6.1.3 CIFAR-10 AND CIFAR-100

#### 6.1.3 CIFAR-10和CIFAR-100

The CIFAR-10 and CIFAR-100 data sets consist of ${32} \times  {32}$ color images drawn from 10 and 100 categories respectively. Figure $5\mathrm{\;b}$ shows some examples of images from this data set. A detailed description of the data sets, input preprocessing, network architectures and other experimental details is given in Appendix B.3. Table 4 shows the error rate obtained by different methods on these data sets. Without any data augmentation, Snoek et al. (2012) used Bayesian hyperparameter optimization to obtained an error rate of 14.98% on CIFAR-10. Using dropout in the fully connected layers reduces that to 14.32% and adding dropout in every layer further reduces the error to 12.61%. Goodfellow et al. (2013) showed that the error is further reduced to ${11.68}\%$ by replacing ReLU units with maxout units. On CIFAR-100, dropout reduces the error from 43.48% to 37.20% which is a huge improvement. No data augmentation was used for either data set (apart from the input dropout).

CIFAR-10和CIFAR-100数据集分别包含来自10类和100类的${32} \times  {32}$彩色图像。图$5\mathrm{\;b}$展示了该数据集中的一些图像示例。关于数据集的详细描述、输入预处理、网络架构及其他实验细节见附录B.3。表4展示了不同方法在这些数据集上的错误率。未使用任何数据增强时，Snoek等人(2012)通过贝叶斯超参数优化在CIFAR-10上获得了14.98%的错误率。使用全连接层的dropout将错误率降至14.32%，在每层加入dropout则进一步降至12.61%。Goodfellow等人(2013)通过将ReLU单元替换为maxout单元，错误率进一步降低至${11.68}\%$。在CIFAR-100上，dropout将错误率从43.48%降至37.20%，提升显著。两个数据集均未使用数据增强(除输入dropout外)。

![bo_d1c3o4n7aajc7389qei0_10_270_256_1250_680_0.jpg](images/bo_d1c3o4n7aajc7389qei0_10_270_256_1250_680_0.jpg)

Figure 5: Samples from image data sets. Each row corresponds to a different category.

图5:图像数据集样本。每行对应一个不同类别。

<table><tr><td>Method</td><td>CIFAR-10</td><td>CIFAR-100</td></tr><tr><td>Conv Net + max pooling (hand tuned)</td><td>15.60</td><td>43.48</td></tr><tr><td>Conv Net + stochastic pooling (Zeiler and Fergus, 2013)</td><td>15.13</td><td>42.51</td></tr><tr><td>Conv Net + max pooling (Snoek et al., 2012)</td><td>14.98</td><td>-</td></tr><tr><td>Conv Net + max pooling + dropout fully connected layers</td><td>14.32</td><td>41.26</td></tr><tr><td>Conv Net + max pooling + dropout in all layers</td><td>12.61</td><td>37.20</td></tr><tr><td>Conv Net + maxout (Goodfellow et al., 2013)</td><td>11.68</td><td>38.57</td></tr></table>

<table><tbody><tr><td>方法</td><td>CIFAR-10</td><td>CIFAR-100</td></tr><tr><td>卷积网络 + 最大池化(手工调优)</td><td>15.60</td><td>43.48</td></tr><tr><td>卷积网络 + 随机池化(Zeiler 和 Fergus，2013)</td><td>15.13</td><td>42.51</td></tr><tr><td>卷积网络 + 最大池化(Snoek 等，2012)</td><td>14.98</td><td>-</td></tr><tr><td>卷积网络 + 最大池化 + 全连接层丢弃法(dropout)</td><td>14.32</td><td>41.26</td></tr><tr><td>卷积网络 + 最大池化 + 所有层丢弃法(dropout)</td><td>12.61</td><td>37.20</td></tr><tr><td>卷积网络 + maxout(Goodfellow 等，2013)</td><td>11.68</td><td>38.57</td></tr></tbody></table>

Table 4: Error rates on CIFAR-10 and CIFAR-100.

表4:CIFAR-10和CIFAR-100上的错误率。

#### 6.1.4 IMAGENET

#### 6.1.4 IMAGENET

ImageNet is a data set of over 15 million labeled high-resolution images belonging to roughly 22,000 categories. Starting in 2010, as part of the Pascal Visual Object Challenge, an annual competition called the ImageNet Large-Scale Visual Recognition Challenge (ILSVRC) has been held. A subset of ImageNet with roughly 1000 images in each of 1000 categories is used in this challenge. Since the number of categories is rather large, it is conventional to report two error rates: top-1 and top-5, where the top-5 error rate is the fraction of test images for which the correct label is not among the five labels considered most probable by the model. Figure 6 shows some predictions made by our model on a few test images.

ImageNet是一个包含超过1500万张带标签的高分辨率图像的数据集，涵盖大约22000个类别。自2010年起，作为Pascal视觉对象挑战赛的一部分，每年举办一次名为ImageNet大规模视觉识别挑战赛(ILSVRC，ImageNet Large-Scale Visual Recognition Challenge)。该挑战赛使用ImageNet的一个子集，每个类别约有1000张图像，共1000个类别。由于类别数量较多，通常报告两种错误率:top-1和top-5，其中top-5错误率指测试图像中正确标签不在模型预测的五个最可能标签之内的比例。图6展示了我们的模型对一些测试图像的预测结果。

ILSVRC-2010 is the only version of ILSVRC for which the test set labels are available, so most of our experiments were performed on this data set. Table 5 compares the performance of different methods. Convolutional nets with dropout outperform other methods by a large margin. The architecture and implementation details are described in detail in Krizhevsky et al. (2012).

ILSVRC-2010是唯一一个测试集标签可用的ILSVRC版本，因此我们的大部分实验均在该数据集上进行。表5比较了不同方法的性能。采用dropout的卷积神经网络(convolutional nets)显著优于其他方法。架构和实现细节详见Krizhevsky等人(2012)。

![bo_d1c3o4n7aajc7389qei0_11_381_255_1037_428_0.jpg](images/bo_d1c3o4n7aajc7389qei0_11_381_255_1037_428_0.jpg)

Figure 6: Some ImageNet test cases with the 4 most probable labels as predicted by our model. The length of the horizontal bars is proportional to the probability assigned to the labels by the model. Pink indicates ground truth.

图6:一些ImageNet测试样例及我们模型预测的4个最可能标签。水平条的长度与模型分配给标签的概率成正比。粉色表示真实标签。

<table><tr><td>Model</td><td>Top-1</td><td>Top-5</td></tr><tr><td>Sparse Coding (Lin et al., 2010)</td><td>47.1</td><td>28.2</td></tr><tr><td>SIFT + Fisher Vectors (Sanchez and Perronnin, 2011)</td><td>45.7</td><td>25.7</td></tr><tr><td>Conv Net + dropout (Krizhevsky et al., 2012)</td><td>37.5</td><td>17.0</td></tr></table>

<table><tbody><tr><td>模型</td><td>Top-1</td><td>Top-5</td></tr><tr><td>稀疏编码(Lin 等，2010)</td><td>47.1</td><td>28.2</td></tr><tr><td>SIFT + Fisher向量(Sanchez 和 Perronnin，2011)</td><td>45.7</td><td>25.7</td></tr><tr><td>卷积神经网络 + dropout(Krizhevsky 等，2012)</td><td>37.5</td><td>17.0</td></tr></tbody></table>

Table 5: Results on the ILSVRC-2010 test set.

表5:ILSVRC-2010测试集上的结果。

<table><tr><td>Model</td><td>Top-1 (val)</td><td>Top-5 (val)</td><td>Top-5 (test)</td></tr><tr><td>SVM on Fisher Vectors of Dense SIFT and Color Statistics</td><td>-</td><td>-</td><td>27.3</td></tr><tr><td>Avg of classifiers over FVs of SIFT, LBP, GIST and CSIFT</td><td>-</td><td>-</td><td>26.2</td></tr><tr><td>Conv Net + dropout (Krizhevsky et al., 2012)</td><td>40.7</td><td>18.2</td><td>-</td></tr><tr><td>Avg of 5 Conv Nets + dropout (Krizhevsky et al., 2012)</td><td>38.1</td><td>16.4</td><td>16.4</td></tr></table>

<table><tbody><tr><td>模型</td><td>Top-1(验证)</td><td>Top-5(验证)</td><td>Top-5(测试)</td></tr><tr><td>基于密集SIFT和颜色统计的Fisher向量的支持向量机(SVM)</td><td>-</td><td>-</td><td>27.3</td></tr><tr><td>SIFT、LBP、GIST和CSIFT的Fisher向量分类器平均</td><td>-</td><td>-</td><td>26.2</td></tr><tr><td>卷积神经网络+dropout(Krizhevsky等，2012)</td><td>40.7</td><td>18.2</td><td>-</td></tr><tr><td>5个卷积神经网络+dropout的平均(Krizhevsky等，2012)</td><td>38.1</td><td>16.4</td><td>16.4</td></tr></tbody></table>

Table 6: Results on the ILSVRC-2012 validation/test set.

表6:ILSVRC-2012验证/测试集上的结果。

Our model based on convolutional nets and dropout won the ILSVRC-2012 competition. Since the labels for the test set are not available, we report our results on the test set for the final submission and include the validation set results for different variations of our model. Table 6 shows the results from the competition. While the best methods based on standard vision features achieve a top-5 error rate of about ${26}\%$ , convolutional nets with dropout achieve a test error of about ${16}\%$ which is a staggering difference. Figure 6 shows some examples of predictions made by our model. We can see that the model makes very reasonable predictions, even when its best guess is not correct.

我们基于卷积神经网络和dropout的模型赢得了ILSVRC-2012竞赛。由于测试集的标签不可用，我们报告了最终提交的测试集结果，并包含了模型不同变体在验证集上的结果。表6展示了竞赛中的结果。虽然基于标准视觉特征的最佳方法的top-5错误率约为${26}\%$，但采用dropout的卷积神经网络测试错误率约为${16}\%$，差距惊人。图6展示了我们模型的一些预测示例。可以看到，即使模型的最佳猜测不正确，其预测仍然非常合理。

### 6.2 Results on TIMIT

### 6.2 TIMIT数据集上的结果

Next, we applied dropout to a speech recognition task. We use the TIMIT data set which consists of recordings from 680 speakers covering 8 major dialects of American English reading ten phonetically-rich sentences in a controlled noise-free environment. Dropout neural networks were trained on windows of 21 log-filter bank frames to predict the label of the central frame. No speaker dependent operations were performed. Appendix B. 4 describes the data preprocessing and training details. Table 7 compares dropout neural nets with other models. A 6-layer net gives a phone error rate of ${23.4}\%$ . Dropout further improves it to 21.8%. We also trained dropout nets starting from pretrained weights. A 4-layer net pretrained with a stack of RBMs get a phone error rate of 22.7%. With dropout, this reduces to 19.7%. Similarly, for an 8-layer net the error reduces from 20.5% to 19.7%.

接下来，我们将dropout应用于语音识别任务。我们使用TIMIT数据集，该数据集包含680名说话者的录音，涵盖美国英语的8种主要方言，录制了十句富含音素的句子，环境为无噪声控制条件。dropout神经网络在21帧对数滤波器组窗口上训练，以预测中心帧的标签。未进行说话者依赖操作。附录B.4描述了数据预处理和训练细节。表7比较了dropout神经网络与其他模型。6层网络的音素错误率为${23.4}\%$。dropout进一步将其提升至21.8%。我们还训练了基于预训练权重的dropout网络。使用受限玻尔兹曼机(RBM)堆叠预训练的4层网络音素错误率为22.7%，加入dropout后降至19.7%。同样，8层网络的错误率从20.5%降至19.7%。

<table><tr><td>Method</td><td>Phone Error Rate%</td></tr><tr><td>NN (6 layers) (Mohamed et al., 2010)</td><td>23.4</td></tr><tr><td>Dropout NN (6 layers)</td><td>21.8</td></tr><tr><td>DBN-pretrained NN (4 layers)</td><td>22.7</td></tr><tr><td>DBN-pretrained NN (6 layers) (Mohamed et al., 2010)</td><td>22.4</td></tr><tr><td>DBN-pretrained NN (8 layers) (Mohamed et al., 2010)</td><td>20.7</td></tr><tr><td>mcRBM-DBN-pretrained NN (5 layers) (Dahl et al., 2010)</td><td>20.5</td></tr><tr><td>DBN-pretrained NN (4 layers) + dropout</td><td>19.7</td></tr><tr><td>DBN-pretrained NN (8 layers) + dropout</td><td>19.7</td></tr></table>

<table><tbody><tr><td>方法</td><td>音素错误率%</td></tr><tr><td>神经网络(6层)(Mohamed 等，2010)</td><td>23.4</td></tr><tr><td>Dropout神经网络(6层)</td><td>21.8</td></tr><tr><td>DBN预训练神经网络(4层)</td><td>22.7</td></tr><tr><td>DBN预训练神经网络(6层)(Mohamed 等，2010)</td><td>22.4</td></tr><tr><td>DBN预训练神经网络(8层)(Mohamed 等，2010)</td><td>20.7</td></tr><tr><td>mcRBM-DBN预训练神经网络(5层)(Dahl 等，2010)</td><td>20.5</td></tr><tr><td>DBN预训练神经网络(4层)+ dropout</td><td>19.7</td></tr><tr><td>DBN预训练神经网络(8层)+ dropout</td><td>19.7</td></tr></tbody></table>

Table 7: Phone error rate on the TIMIT core test set.

表7:TIMIT核心测试集上的音素错误率。

### 6.3 Results on a Text Data Set

### 6.3 文本数据集上的结果

To test the usefulness of dropout in the text domain, we used dropout networks to train a document classifier. We used a subset of the Reuters-RCV1 data set which is a collection of over 800,000 newswire articles from Reuters. These articles cover a variety of topics. The task is to take a bag of words representation of a document and classify it into 50 disjoint topics. Appendix B. 5 describes the setup in more detail. Our best neural net which did not use dropout obtained an error rate of 31.05%. Adding dropout reduced the error to ${29.62}\%$ . We found that the improvement was much smaller compared to that for the vision and speech data sets.

为了测试dropout在文本领域的有效性，我们使用dropout网络训练了一个文档分类器。我们使用了Reuters-RCV1数据集的一个子集，该数据集包含了来自路透社的超过80万篇新闻稿。这些文章涵盖了各种主题。任务是将文档的词袋表示分类为50个不相交的主题。附录B.5中对设置有更详细的描述。我们最好的未使用dropout的神经网络错误率为31.05%。加入dropout后错误率降低到${29.62}\%$。我们发现相比视觉和语音数据集，改进幅度要小得多。

### 6.4 Comparison with Bayesian Neural Networks

### 6.4 与贝叶斯神经网络的比较

Dropout can be seen as a way of doing an equally-weighted averaging of exponentially many models with shared weights. On the other hand, Bayesian neural networks (Neal, 1996) are the proper way of doing model averaging over the space of neural network structures and parameters. In dropout, each model is weighted equally, whereas in a Bayesian neural network each model is weighted taking into account the prior and how well the model fits the data, which is the more correct approach. Bayesian neural nets are extremely useful for solving problems in domains where data is scarce such as medical diagnosis, genetics, drug discovery and other computational biology applications. However, Bayesian neural nets are slow to train and difficult to scale to very large network sizes. Besides, it is expensive to get predictions from many large nets at test time. On the other hand, dropout neural nets are much faster to train and use at test time. In this section, we report experiments that compare Bayesian neural nets with dropout neural nets on a small data set where Bayesian neural networks are known to perform well and obtain state-of-the-art results. The aim is to analyze how much does dropout lose compared to Bayesian neural nets.

Dropout可以看作是对共享权重的指数级众多模型进行等权重平均的一种方法。另一方面，贝叶斯神经网络(Neal, 1996)是在神经网络结构和参数空间上进行模型平均的正确方法。在dropout中，每个模型权重相等，而在贝叶斯神经网络中，每个模型的权重会考虑先验和模型对数据的拟合程度，这种方法更为准确。贝叶斯神经网络在数据稀缺的领域如医学诊断、遗传学、药物发现及其他计算生物学应用中极为有用。然而，贝叶斯神经网络训练缓慢且难以扩展到非常大的网络规模。此外，在测试时从多个大型网络获取预测代价高昂。相比之下，dropout神经网络训练和测试速度更快。本节报告了在一个贝叶斯神经网络表现优异并获得最先进结果的小型数据集上，贝叶斯神经网络与dropout神经网络的对比实验。目的是分析dropout相较于贝叶斯神经网络的性能损失。

The data set that we use (Xiong et al., 2011) comes from the domain of genetics. The task is to predict the occurrence of alternative splicing based on RNA features. Alternative splicing is a significant cause of cellular diversity in mammalian tissues. Predicting the occurrence of alternate splicing in certain tissues under different conditions is important for understanding many human diseases. Given the RNA features, the task is to predict the probability of three splicing related events that biologists care about. The evaluation metric is Code Quality which is a measure of the negative KL divergence between the target and the predicted probability distributions (higher is better). Appendix B. 6 includes a detailed description of the data set and this performance metric.

我们使用的数据集(Xiong et al., 2011)来自遗传学领域。任务是基于RNA特征预测可变剪接的发生。可变剪接是哺乳动物组织细胞多样性的一个重要原因。预测特定组织在不同条件下可变剪接的发生对于理解许多人类疾病至关重要。给定RNA特征，任务是预测生物学家关心的三种剪接相关事件的概率。评估指标为代码质量(Code Quality)，衡量目标分布与预测概率分布之间的负KL散度(值越高越好)。附录B.6中包含数据集和该性能指标的详细描述。

<table><tr><td>Method</td><td>Code Quality (bits)</td></tr><tr><td>Neural Network (early stopping) (Xiong et al., 2011)</td><td>440</td></tr><tr><td>Regression, PCA (Xiong et al., 2011)</td><td>463</td></tr><tr><td>SVM, PCA (Xiong et al., 2011)</td><td>487</td></tr><tr><td>Neural Network with dropout</td><td>567</td></tr><tr><td>Bayesian Neural Network (Xiong et al., 2011)</td><td>623</td></tr></table>

<table><tbody><tr><td>方法</td><td>代码质量(比特)</td></tr><tr><td>神经网络(早停法)(Xiong 等，2011)</td><td>440</td></tr><tr><td>回归，主成分分析(PCA)(Xiong 等，2011)</td><td>463</td></tr><tr><td>支持向量机(SVM)，主成分分析(PCA)(Xiong 等，2011)</td><td>487</td></tr><tr><td>带丢弃法的神经网络</td><td>567</td></tr><tr><td>贝叶斯神经网络(Xiong 等，2011)</td><td>623</td></tr></tbody></table>

Table 8: Results on the Alternative Splicing Data Set.

表8:可变剪接数据集的结果。

Table 8 summarizes the performance of different models on this data set. Xiong et al. (2011) used Bayesian neural nets for this task. As expected, we found that Bayesian neural nets perform better than dropout. However, we see that dropout improves significantly upon the performance of standard neural nets and outperforms all other methods. The challenge in this data set is to prevent overfitting since the size of the training set is small. One way to prevent overfitting is to reduce the input dimensionality using PCA. Thereafter, standard techniques such as SVMs or logistic regression can be used. However, with dropout we were able to prevent overfitting without the need to do dimensionality reduction. The dropout nets are very large (1000s of hidden units) compared to a few tens of units in the Bayesian network. This shows that dropout has a strong regularizing effect.

表8总结了不同模型在该数据集上的表现。Xiong等人(2011)使用贝叶斯神经网络(Bayesian neural nets)完成此任务。正如预期的那样，我们发现贝叶斯神经网络的表现优于dropout。然而，我们看到dropout显著提升了标准神经网络的性能，并且优于所有其他方法。该数据集的挑战在于防止过拟合，因为训练集规模较小。防止过拟合的一种方法是使用主成分分析(PCA)降低输入维度。之后，可以使用支持向量机(SVM)或逻辑回归等标准技术。然而，使用dropout我们能够在不进行降维的情况下防止过拟合。与贝叶斯网络中几十个隐藏单元相比，dropout网络非常庞大(有数千个隐藏单元)。这表明dropout具有强大的正则化效果。

### 6.5 Comparison with Standard Regularizers

### 6.5 与标准正则化方法的比较

Several regularization methods have been proposed for preventing overfitting in neural networks. These include L2 weight decay (more generally Tikhonov regularization (Tikhonov, 1943)), lasso (Tibshirani, 1996), KL-sparsity and max-norm regularization. Dropout can be seen as another way of regularizing neural networks. In this section we compare dropout with some of these regularization methods using the MNIST data set.

为防止神经网络过拟合，已经提出了多种正则化方法。这些方法包括L2权重衰减(更广义地称为Tikhonov正则化(Tikhonov, 1943))、套索回归(lasso)(Tibshirani, 1996)、KL稀疏性和最大范数正则化。Dropout可以看作是另一种神经网络的正则化方式。本节中，我们使用MNIST数据集比较dropout与这些正则化方法的效果。

The same network architecture (784-1024-1024-2048-10) with ReLUs was trained using stochastic gradient descent with different regularizations. Table 9 shows the results. The values of different hyperparameters associated with each kind of regularization (decay constants, target sparsity, dropout rate, max-norm upper bound) were obtained using a validation set. We found that dropout combined with max-norm regularization gives the lowest generalization error.

使用相同的网络结构(784-1024-1024-2048-10)和ReLU激活函数，通过随机梯度下降训练，采用不同的正则化方法。表9展示了结果。每种正则化相关的超参数(衰减常数、目标稀疏度、dropout率、最大范数上限)均通过验证集确定。我们发现，dropout结合最大范数正则化能获得最低的泛化误差。

## 7. Salient Features

## 7. 主要特征

The experiments described in the previous section provide strong evidence that dropout is a useful technique for improving neural networks. In this section, we closely examine how dropout affects a neural network. We analyze the effect of dropout on the quality of features produced. We see how dropout affects the sparsity of hidden unit activations. We also see how the advantages obtained from dropout vary with the probability of retaining units, size of the network and the size of the training set. These observations give some insight into why dropout works so well.

前一节描述的实验强有力地证明了dropout是提升神经网络性能的有效技术。本节将深入探讨dropout对神经网络的影响。我们分析dropout对特征质量的影响，观察dropout如何影响隐藏单元激活的稀疏性。同时，我们还考察了保留单元概率、网络规模和训练集大小对dropout优势的影响。这些观察为理解dropout为何效果显著提供了洞见。

<table><tr><td>Method</td><td>Test Classification error %</td></tr><tr><td>L2</td><td>1.62</td></tr><tr><td>$\mathrm{L}2 + \mathrm{L}1$ applied towards the end of training</td><td>1.60</td></tr><tr><td>L2 + KL-sparsity</td><td>1.55</td></tr><tr><td>Max-norm</td><td>1.35</td></tr><tr><td>Dropout + L2</td><td>1.25</td></tr><tr><td>Dropout + Max-norm</td><td>1.05</td></tr></table>

<table><tbody><tr><td>方法</td><td>测试分类错误率%</td></tr><tr><td>L2</td><td>1.62</td></tr><tr><td>$\mathrm{L}2 + \mathrm{L}1$ 应用于训练末期</td><td>1.60</td></tr><tr><td>L2 + KL稀疏性</td><td>1.55</td></tr><tr><td>最大范数</td><td>1.35</td></tr><tr><td>Dropout + L2</td><td>1.25</td></tr><tr><td>Dropout + 最大范数</td><td>1.05</td></tr></tbody></table>

Table 9: Comparison of different regularization methods on MNIST.

表9:不同正则化方法在MNIST上的比较。

### 7.1 Effect on Features

### 7.1 对特征的影响

![bo_d1c3o4n7aajc7389qei0_14_299_891_1196_644_0.jpg](images/bo_d1c3o4n7aajc7389qei0_14_299_891_1196_644_0.jpg)

Figure 7: Features learned on MNIST with one hidden layer autoencoders having 256 rectified linear units.

图7:在MNIST上使用具有256个修正线性单元(ReLU)的单隐藏层自编码器学习的特征。

In a standard neural network, the derivative received by each parameter tells it how it should change so the final loss function is reduced, given what all other units are doing. Therefore, units may change in a way that they fix up the mistakes of the other units. This may lead to complex co-adaptations. This in turn leads to overfitting because these co-adaptations do not generalize to unseen data. We hypothesize that for each hidden unit, dropout prevents co-adaptation by making the presence of other hidden units unreliable. Therefore, a hidden unit cannot rely on other specific units to correct its mistakes. It must perform well in a wide variety of different contexts provided by the other hidden units. To observe this effect directly, we look at the first level features learned by neural networks trained on visual tasks with and without dropout.

在标准神经网络中，每个参数接收到的导数告诉它应如何变化以减少最终的损失函数，前提是考虑到所有其他单元的状态。因此，单元可能会以修正其他单元错误的方式发生变化。这可能导致复杂的协同适应(co-adaptations)。而这又会导致过拟合，因为这些协同适应无法推广到未见过的数据。我们假设对于每个隐藏单元，dropout通过使其他隐藏单元的存在变得不可靠来防止协同适应。因此，隐藏单元不能依赖其他特定单元来纠正其错误。它必须在由其他隐藏单元提供的各种不同上下文中表现良好。为了直接观察这一效果，我们查看了在视觉任务中训练的神经网络在有无dropout情况下学习的第一层特征。

Figure 7a shows features learned by an autoencoder on MNIST with a single hidden layer of 256 rectified linear units without dropout. Figure 7b shows the features learned by an identical autoencoder which used dropout in the hidden layer with $p = {0.5}$ . Both au-toencoders had similar test reconstruction errors. However, it is apparent that the features shown in Figure 7a have co-adapted in order to produce good reconstructions. Each hidden unit on its own does not seem to be detecting a meaningful feature. On the other hand, in Figure 7b, the hidden units seem to detect edges, strokes and spots in different parts of the image. This shows that dropout does break up co-adaptations, which is probably the main reason why it leads to lower generalization errors.

图7a显示了在MNIST上使用单隐藏层256个修正线性单元且无dropout的自编码器学习的特征。图7b显示了使用相同结构但隐藏层应用了$p = {0.5}$ dropout的自编码器学习的特征。两个自编码器的测试重构误差相似。然而，显然图7a中的特征已经协同适应以产生良好的重构。单个隐藏单元本身似乎并未检测到有意义的特征。另一方面，图7b中的隐藏单元似乎检测到了图像不同部分的边缘、笔画和斑点。这表明dropout确实打破了协同适应，这很可能是其导致更低泛化误差的主要原因。

### 7.2 Effect on Sparsity

### 7.2 对稀疏性的影响

![bo_d1c3o4n7aajc7389qei0_15_306_746_1178_525_0.jpg](images/bo_d1c3o4n7aajc7389qei0_15_306_746_1178_525_0.jpg)

Figure 8: Effect of dropout on sparsity. ReLUs were used for both models. Left: The histogram of mean activations shows that most units have a mean activation of about 2.0. The histogram of activations shows a huge mode away from zero. Clearly, a large fraction of units have high activation. Right: The histogram of mean activations shows that most units have a smaller mean mean activation of about 0.7 . The histogram of activations shows a sharp peak at zero. Very few units have high activation.

图8:dropout对稀疏性的影响。两个模型均使用ReLU。左图:平均激活的直方图显示大多数单元的平均激活约为2.0。激活的直方图显示远离零的巨大峰值。显然，大部分单元激活较高。右图:平均激活的直方图显示大多数单元的平均激活较小，约为0.7。激活的直方图在零处有明显峰值。很少有单元激活较高。

We found that as a side-effect of doing dropout, the activations of the hidden units become sparse, even when no sparsity inducing regularizers are present. Thus, dropout automatically leads to sparse representations. To observe this effect, we take the autoencoders trained in the previous section and look at the sparsity of hidden unit activations on a random mini-batch taken from the test set. Figure 8a and Figure 8b compare the sparsity for the two models. In a good sparse model, there should only be a few highly activated units for any data case. Moreover, the average activation of any unit across data cases should be low. To assess both of these qualities, we plot two histograms for each model. For each model, the histogram on the left shows the distribution of mean activations of hidden units across the minibatch. The histogram on the right shows the distribution of activations of the hidden units.

我们发现，作为dropout的副作用，即使没有稀疏性诱导的正则项，隐藏单元的激活也变得稀疏。因此，dropout自动导致稀疏表示。为了观察这一效果，我们取前一节训练的自编码器，查看测试集随机小批量数据上隐藏单元激活的稀疏性。图8a和图8b比较了两个模型的稀疏性。在良好的稀疏模型中，对于任何数据样本，只有少数单元会高度激活。此外，任何单元在所有数据样本上的平均激活应较低。为评估这两点，我们为每个模型绘制了两个直方图。每个模型左侧的直方图显示隐藏单元在小批量数据上的平均激活分布，右侧的直方图显示隐藏单元的激活分布。

Comparing the histograms of activations we can see that fewer hidden units have high activations in Figure $8\mathrm{\;b}$ compared to Figure $8\mathrm{a}$ , as seen by the significant mass away from zero for the net that does not use dropout. The mean activations are also smaller for the dropout net. The overall mean activation of hidden units is close to 2.0 for the autoencoder without dropout but drops to around 0.7 when dropout is used.

比较激活的直方图可以看到，与图$8\mathrm{a}$相比，图$8\mathrm{\;b}$中较少隐藏单元具有高激活，这从未使用dropout的网络激活远离零的显著质量中可见。dropout网络的平均激活也较小。无dropout的自编码器隐藏单元总体平均激活接近2.0，而使用dropout时降至约0.7。

### 7.3 Effect of Dropout Rate

### 7.3 Dropout率的影响

Dropout has a tunable hyperparameter $p$ (the probability of retaining a unit in the network). In this section, we explore the effect of varying this hyperparameter. The comparison is done in two situations.

Dropout有一个可调节的超参数$p$(网络中保留单元的概率)。本节探讨调整该超参数的影响。比较在两种情况下进行。

1. The number of hidden units is held constant.

1. 隐藏单元数量保持不变。

2. The number of hidden units is changed so that the expected number of hidden units that will be retained after dropout is held constant.

2. 改变隐藏单元数量，使得dropout后预期保留的隐藏单元数量保持不变。

In the first case, we train the same network architecture with different amounts of dropout. We use a 784-2048-2048-2048-10 architecture. No input dropout was used. Figure 9a shows the test error obtained as a function of $p$ . If the architecture is held constant, having a small $p$ means very few units will turn on during training. It can be seen that this has led to underfitting since the training error is also high. We see that as $p$ increases, the error goes down. It becomes flat when ${0.4} \leq  p \leq  {0.8}$ and then increases as $p$ becomes close to 1 .

在第一种情况下，我们使用不同的dropout比例训练相同的网络架构。我们采用784-2048-2048-2048-10的架构。未使用输入层dropout。图9a显示了测试误差随$p$变化的情况。如果架构保持不变，较小的$p$意味着训练时激活的单元很少。可以看出，这导致了欠拟合，因为训练误差也很高。随着$p$的增加，误差下降。当达到${0.4} \leq  p \leq  {0.8}$时误差趋于平缓，随后当$p$接近1时误差又开始上升。

![bo_d1c3o4n7aajc7389qei0_16_301_1112_1191_498_0.jpg](images/bo_d1c3o4n7aajc7389qei0_16_301_1112_1191_498_0.jpg)

Figure 9: Effect of changing dropout rates on MNIST.

图9:改变dropout率对MNIST的影响。

Another interesting setting is the second case in which the quantity ${pn}$ is held constant where $n$ is the number of hidden units in any particular layer. This means that networks that have small $p$ will have a large number of hidden units. Therefore, after applying dropout, the expected number of units that are present will be the same across different architectures. However, the test networks will be of different sizes. In our experiments, we set ${pn} = {256}$ for the first two hidden layers and ${pn} = {512}$ for the last hidden layer. Figure $9\mathrm{\;b}$ shows the test error obtained as a function of $p$ . We notice that the magnitude of errors for small values of $p$ has reduced by a lot compared to Figure 9a (for $p = {0.1}$ it fell from 2.7% to 1.7%). Values of $p$ that are close to 0.6 seem to perform best for this choice of ${pn}$ but our usual default value of 0.5 is close to optimal.

另一种有趣的设置是第二种情况，其中${pn}$保持不变，$n$是任意特定层中的隐藏单元数。这意味着具有较小$p$的网络将拥有较多的隐藏单元。因此，应用dropout后，不同架构中预期存在的单元数量将相同。然而，测试网络的规模会不同。在我们的实验中，前两层隐藏层设置为${pn} = {256}$，最后一层隐藏层设置为${pn} = {512}$。图$9\mathrm{\;b}$显示了测试误差随$p$变化的情况。我们注意到，与图9a相比，小$p$值的误差幅度大幅降低(对于$p = {0.1}$，误差从2.7%降至1.7%)。对于该${pn}$选择，接近0.6的$p$值表现最佳，但我们通常默认的0.5值也接近最优。

### 7.4 Effect of Data Set Size

### 7.4 数据集大小的影响

One test of a good regularizer is that it should make it possible to get good generalization error from models with a large number of parameters trained on small data sets. This section explores the effect of changing the data set size when dropout is used with feed-forward networks. Huge neural networks trained in the standard way overfit massively on small data sets. To see if dropout can help, we run classification experiments on MNIST and vary the amount of data given to the network.

一个好的正则化方法的测试标准是，它应能使得在小数据集上训练的参数众多的模型获得良好的泛化误差。本节探讨在使用dropout的前馈网络中，改变数据集大小的影响。以标准方式训练的大型神经网络在小数据集上会严重过拟合。为了验证dropout是否有帮助，我们在MNIST上进行分类实验，并改变网络所用数据量。

The results of these experiments are shown in Figure 10. The network was given data sets of size ${100},{500},1\mathrm{\;K},5\mathrm{\;K},{10}\mathrm{\;K}$ and ${50}\mathrm{\;K}$ chosen randomly from the MNIST training set. The same network architecture (784-1024-1024-2048-10) was used for all data sets. Dropout with $p = {0.5}$ was performed at all the hidden layers and $p = {0.8}$ at the input layer. It can be observed that for extremely small data sets(100,500) dropout does not give any improvements. The model has enough parameters that it can overfit on the training data, even with all the noise coming from dropout. As the size of the data set is increased, the gain from doing dropout increases up to a point and then declines. This suggests that for any given architecture and dropout rate, there is a "sweet spot" corresponding to some amount of data that is large enough to not be memorized in spite of the noise but not so large that overfitting is not a problem anyways.

这些实验结果见图10。网络使用从MNIST训练集中随机选取的大小为${100},{500},1\mathrm{\;K},5\mathrm{\;K},{10}\mathrm{\;K}$和${50}\mathrm{\;K}$的数据集。所有数据集均使用相同的网络架构(784-1024-1024-2048-10)。所有隐藏层均采用$p = {0.5}$的dropout，输入层采用$p = {0.8}$。可以观察到，对于极小的数据集(100，500)，dropout并未带来改进。模型参数足够多，即使有dropout带来的噪声，也能在训练数据上过拟合。随着数据集大小增加，dropout带来的收益先增加后减少。这表明对于任意给定的架构和dropout率，存在一个“最佳点”，对应某个数据量，该数据量足够大以避免被噪声记忆，但又不至于大到过拟合不再是问题。

![bo_d1c3o4n7aajc7389qei0_17_894_588_639_496_0.jpg](images/bo_d1c3o4n7aajc7389qei0_17_894_588_639_496_0.jpg)

Figure 10: Effect of varying data set size.

图10:数据集大小变化的影响。

### 7.5 Monte-Carlo Model Averaging vs. Weight Scaling

### 7.5 蒙特卡洛模型平均与权重缩放

The efficient test time procedure that we propose is to do an approximate model combination by scaling down the weights of the trained neural network. An expensive but more correct way of averaging the models is to sample $k$ neural nets using dropout for each test case and average their predictions. As $k \rightarrow  \infty$ , this Monte-Carlo model average gets close to the true model average. It is interesting to see empirically how many samples $k$ are needed to match the performance of the approximate averaging method. By computing the error for different values of $k$ we can see how quickly the error rate of the finite-sample average approaches the error rate of the true model average.

我们提出的高效测试时方法是通过缩放训练好的神经网络权重来进行近似模型组合。更昂贵但更准确的模型平均方法是对每个测试样本使用dropout采样$k$个神经网络，并对它们的预测结果取平均。随着$k \rightarrow  \infty$的增加，这种蒙特卡洛模型平均接近真实的模型平均。通过实证观察需要多少个样本$k$才能达到近似平均方法的性能。通过计算不同$k$值下的误差，我们可以看到有限样本平均的误差率如何快速接近真实模型平均的误差率。

![bo_d1c3o4n7aajc7389qei0_17_894_1451_641_499_0.jpg](images/bo_d1c3o4n7aajc7389qei0_17_894_1451_641_499_0.jpg)

Figure 11: Monte-Carlo model averaging vs. weight scaling.

图11:蒙特卡洛模型平均与权重缩放。

We again use the MNIST data set and do classification by averaging the predictions of $k$ randomly sampled neural networks. Figure 11 shows the test error rate obtained for different values of $k$ . This is compared with the error obtained using the weight scaling method (shown as a horizontal line). It can be seen that around $k = {50}$ , the Monte-Carlo method becomes as good as the approximate method. Thereafter, the Monte-Carlo method is slightly better than the approximate method but well within one standard deviation of it. This suggests that the weight scaling method is a fairly good approximation of the true model average.

我们再次使用MNIST数据集，通过对$k$个随机采样的神经网络的预测结果取平均来进行分类。图11展示了不同$k$值下获得的测试错误率。该结果与使用权重缩放方法(以一条水平线表示)得到的错误率进行了比较。可以看出，在大约$k = {50}$时，蒙特卡洛方法的效果与近似方法相当。此后，蒙特卡洛方法略优于近似方法，但仍在其一个标准差范围内。这表明权重缩放方法是对真实模型平均的相当好的近似。

## 8. Dropout Restricted Boltzmann Machines

## 8. Dropout受限玻尔兹曼机

Besides feed-forward neural networks, dropout can also be applied to Restricted Boltzmann Machines (RBM). In this section, we formally describe this model and show some results to illustrate its key properties.

除了前馈神经网络，dropout也可以应用于受限玻尔兹曼机(Restricted Boltzmann Machines，RBM)。本节将正式描述该模型，并展示一些结果以说明其关键特性。

### 8.1 Model Description

### 8.1 模型描述

Consider an RBM with visible units $\mathbf{v} \in  \{ 0,1{\} }^{D}$ and hidden units $\mathbf{h} \in  \{ 0,1{\} }^{F}$ . It defines the following probability distribution

考虑一个具有可见单元$\mathbf{v} \in  \{ 0,1{\} }^{D}$和隐藏单元$\mathbf{h} \in  \{ 0,1{\} }^{F}$的RBM。它定义了以下概率分布

$$
P\left( {\mathbf{h},\mathbf{v};\theta }\right)  = \frac{1}{\mathcal{Z}\left( \theta \right) }\exp \left( {{\mathbf{v}}^{\top }W\mathbf{h} + {\mathbf{a}}^{\top }\mathbf{h} + {\mathbf{b}}^{\top }\mathbf{v}}\right) .
$$

Where $\theta  = \{ W,\mathbf{a},\mathbf{b}\}$ represents the model parameters and $\mathcal{Z}$ is the partition function.

其中$\theta  = \{ W,\mathbf{a},\mathbf{b}\}$表示模型参数，$\mathcal{Z}$是配分函数。

Dropout RBMs are RBMs augmented with a vector of binary random variables $\mathbf{r} \in$ $\{ 0,1{\} }^{F}$ . Each random variable ${r}_{j}$ takes the value 1 with probability $p$ , independent of others. If ${r}_{j}$ takes the value 1, the hidden unit ${h}_{j}$ is retained, otherwise it is dropped from the model. The joint distribution defined by a Dropout RBM can be expressed as

Dropout RBM是在RBM基础上增加了一组二元随机变量$\mathbf{r} \in$$\{ 0,1{\} }^{F}$。每个随机变量${r}_{j}$以概率$p$取值为1，且相互独立。如果${r}_{j}$取值为1，则隐藏单元${h}_{j}$被保留，否则从模型中丢弃。Dropout RBM定义的联合分布可表示为

$$
P\left( {\mathbf{r},\mathbf{h},\mathbf{v};p,\theta }\right)  = P\left( {\mathbf{r};p}\right) P\left( {\mathbf{h},\mathbf{v} \mid  \mathbf{r};\theta }\right) ,
$$

$$
P\left( {\mathbf{r};p}\right)  = \mathop{\prod }\limits_{{j = 1}}^{F}{p}^{{r}_{j}}{\left( 1 - p\right) }^{1 - {r}_{j}},
$$

$$
P\left( {\mathbf{h},\mathbf{v} \mid  \mathbf{r};\theta }\right)  = \frac{1}{{\mathcal{Z}}^{\prime }\left( {\theta ,\mathbf{r}}\right) }\exp \left( {{\mathbf{v}}^{\top }W\mathbf{h} + {\mathbf{a}}^{\top }\mathbf{h} + {\mathbf{b}}^{\top }\mathbf{v}}\right) \mathop{\prod }\limits_{{j = 1}}^{F}g\left( {{h}_{j},{r}_{j}}\right) ,
$$

$$
g\left( {{h}_{j},{r}_{j}}\right)  = \mathbb{1}\left( {{r}_{j} = 1}\right)  + \mathbb{1}\left( {{r}_{j} = 0}\right) \mathbb{1}\left( {{h}_{j} = 0}\right) .
$$

${\mathcal{Z}}^{\prime }\left( {\theta ,\mathbf{r}}\right)$ is the normalization constant. $g\left( {{h}_{j},{r}_{j}}\right)$ imposes the constraint that if ${r}_{j} = 0$ , ${h}_{j}$ must be 0 . The distribution over $\mathbf{h}$ , conditioned on $\mathbf{v}$ and $\mathbf{r}$ is factorial

${\mathcal{Z}}^{\prime }\left( {\theta ,\mathbf{r}}\right)$是归一化常数。$g\left( {{h}_{j},{r}_{j}}\right)$施加了约束:如果${r}_{j} = 0$，则${h}_{j}$必须为0。条件于$\mathbf{v}$和$\mathbf{r}$时，$\mathbf{h}$上的分布是因子分布。

$$
P\left( {\mathbf{h} \mid  \mathbf{r},\mathbf{v}}\right)  = \mathop{\prod }\limits_{{j = 1}}^{F}P\left( {{h}_{j} \mid  {r}_{j},\mathbf{v}}\right) ,
$$

$$
P\left( {{h}_{j} = 1 \mid  {r}_{j},\mathbf{v}}\right)  = \mathbb{1}\left( {{r}_{j} = 1}\right) \sigma \left( {{b}_{j} + \mathop{\sum }\limits_{i}{W}_{ij}{v}_{i}}\right) .
$$

![bo_d1c3o4n7aajc7389qei0_19_300_258_1193_643_0.jpg](images/bo_d1c3o4n7aajc7389qei0_19_300_258_1193_643_0.jpg)

Figure 12: Features learned on MNIST by 256 hidden unit RBMs. The features are ordered by L2 norm.

图12:256个隐藏单元的RBM在MNIST上学习到的特征。特征按L2范数排序。

The distribution over $\mathbf{v}$ conditioned on $\mathbf{h}$ is same as that of an RBM

条件于$\mathbf{h}$时，$\mathbf{v}$上的分布与RBM相同。

$$
P\left( {\mathbf{v} \mid  \mathbf{h}}\right)  = \mathop{\prod }\limits_{{i = 1}}^{D}P\left( {{v}_{i} \mid  \mathbf{h}}\right) ,
$$

$$
P\left( {{v}_{i} = 1 \mid  \mathbf{h}}\right)  = \sigma \left( {{a}_{i} + \mathop{\sum }\limits_{j}{W}_{ij}{h}_{j}}\right) .
$$

Conditioned on $\mathbf{r}$ , the distribution over $\{ \mathbf{v},\mathbf{h}\}$ is same as the distribution that an RBM would impose, except that the units for which ${r}_{j} = 0$ are dropped from $\mathbf{h}$ . Therefore, the Dropout RBM model can be seen as a mixture of exponentially many RBMs with shared weights each using a different subset of $\mathbf{h}$ .

条件于$\mathbf{r}$时，$\{ \mathbf{v},\mathbf{h}\}$上的分布与RBM施加的分布相同，只是对于${r}_{j} = 0$的单元从$\mathbf{h}$中被丢弃。因此，Dropout RBM模型可视为具有共享权重的指数级多个RBM的混合，每个使用$\mathbf{h}$的不同子集。

### 8.2 Learning Dropout RBMs

### 8.2 Dropout RBM的学习

Learning algorithms developed for RBMs such as Contrastive Divergence (Hinton et al., 2006) can be directly applied for learning Dropout RBMs. The only difference is that $\mathbf{r}$ is first sampled and only the hidden units that are retained are used for training. Similar to dropout neural networks, a different $\mathbf{r}$ is sampled for each training case in every minibatch. In our experiments, we use CD-1 for training dropout RBMs.

为RBM开发的学习算法，如对比散度(Contrastive Divergence，Hinton等，2006)，可以直接用于学习Dropout RBM。唯一的区别是先采样$\mathbf{r}$，仅使用被保留的隐藏单元进行训练。类似于dropout神经网络，每个小批量的每个训练样本都会采样不同的$\mathbf{r}$。在我们的实验中，使用CD-1训练dropout RBM。

### 8.3 Effect on Features

### 8.3 对特征的影响

Dropout in feed-forward networks improved the quality of features by reducing co-adaptations. This section explores whether this effect transfers to Dropout RBMs as well.

前馈网络中的dropout通过减少共适应性提高了特征质量。本节探讨这种效果是否也适用于Dropout RBM。

Figure 12a shows features learned by a binary RBM with 256 hidden units. Figure 12b shows features learned by a dropout RBM with the same number of hidden units. Features learned by the dropout RBM appear qualitatively different in the sense that they seem to capture features that are coarser compared to the sharply defined stroke-like features in the standard RBM. There seem to be very few dead units in the dropout RBM relative to the standard RBM.

图12a显示了一个具有256个隐藏单元的二元RBM学习到的特征。图12b显示了具有相同隐藏单元数的dropout RBM学习到的特征。dropout RBM学习的特征在质感上有所不同，似乎捕捉到了比标准RBM中清晰定义的笔画状特征更粗糙的特征。与标准RBM相比，dropout RBM中似乎几乎没有“死”单元。

![bo_d1c3o4n7aajc7389qei0_20_347_260_1106_499_0.jpg](images/bo_d1c3o4n7aajc7389qei0_20_347_260_1106_499_0.jpg)

Figure 13: Effect of dropout on sparsity. Left: The activation histogram shows that a large number of units have activations away from zero. Right: A large number of units have activations close to zero and very few units have high activation.

图13:dropout对稀疏性的影响。左图:激活直方图显示大量单元的激活值远离零。右图:大量单元的激活值接近零，只有少数单元激活较高。

### 8.4 Effect on Sparsity

### 8.4 对稀疏性的影响

Next, we investigate the effect of dropout RBM training on sparsity of the hidden unit activations. Figure 13a shows the histograms of hidden unit activations and their means on a test mini-batch after training an RBM. Figure 13b shows the same for dropout RBMs. The histograms clearly indicate that the dropout RBMs learn much sparser representations than standard RBMs even when no additional sparsity inducing regularizer is present.

接下来，我们研究dropout RBM训练对隐藏单元激活稀疏性的影响。图13a显示了训练RBM后，在测试小批量上的隐藏单元激活及其均值的直方图。图13b显示了dropout RBM的相同内容。直方图清楚地表明，即使没有额外的稀疏性诱导正则项，dropout RBM也能学习到比标准RBM更稀疏的表示。

## 9. Marginalizing Dropout

## 9. Dropout的边缘化

Dropout can be seen as a way of adding noise to the states of hidden units in a neural network. In this section, we explore the class of models that arise as a result of marginalizing this noise. These models can be seen as deterministic versions of dropout. In contrast to standard ("Monte-Carlo") dropout, these models do not need random bits and it is possible to get gradients for the marginalized loss functions. In this section, we briefly explore these models.

Dropout可以看作是在神经网络隐藏单元状态上添加噪声的一种方式。本节探讨通过对该噪声进行边缘化而产生的模型类别。这些模型可视为dropout的确定性版本。与标准的(“蒙特卡洛”)dropout不同，这些模型不需要随机比特，并且可以获得边缘化损失函数的梯度。本节将简要探讨这些模型。

Deterministic algorithms have been proposed that try to learn models that are robust to feature deletion at test time (Globerson and Roweis, 2006). Marginalization in the context of denoising autoencoders has been explored previously (Chen et al., 2012). The marginal-ization of dropout noise in the context of linear regression was discussed in Srivastava (2013). Wang and Manning (2013) further explored the idea of marginalizing dropout to speed-up training. van der Maaten et al. (2013) investigated different input noise distributions and the regularizers obtained by marginalizing this noise. Wager et al. (2013) describes how dropout can be seen as an adaptive regularizer.

已有确定性算法被提出，旨在学习对测试时特征删除具有鲁棒性的模型(Globerson和Roweis，2006)。在去噪自编码器背景下，边缘化已被探讨(Chen等，2012)。Srivastava(2013)讨论了线性回归中dropout噪声的边缘化。Wang和Manning(2013)进一步探讨了边缘化dropout以加速训练的思路。van der Maaten等(2013)研究了不同输入噪声分布及通过边缘化该噪声得到的正则项。Wager等(2013)描述了dropout如何被视为一种自适应正则化器。

### 9.1 Linear Regression

### 9.1 线性回归

First we explore a very simple case of applying dropout to the classical problem of linear regression. Let $X \in  {\mathbb{R}}^{N \times  D}$ be a data matrix of $N$ data points. $\mathbf{y} \in  {\mathbb{R}}^{N}$ be a vector of targets. Linear regression tries to find a $\mathbf{w} \in  {\mathbb{R}}^{D}$ that minimizes

首先，我们探讨将dropout应用于经典线性回归问题的一个非常简单的案例。设$X \in  {\mathbb{R}}^{N \times  D}$为包含$N$个数据点的数据矩阵，$\mathbf{y} \in  {\mathbb{R}}^{N}$为目标向量。线性回归试图找到一个$\mathbf{w} \in  {\mathbb{R}}^{D}$，使得以下目标函数最小化

$$
\parallel \mathbf{y} - X\mathbf{w}{\parallel }^{2}.
$$

When the input $X$ is dropped out such that any input dimension is retained with probability $p$ , the input can be expressed as $R * X$ where $R \in  \{ 0,1{\} }^{N \times  D}$ is a random matrix with ${R}_{ij} \sim$ Bernoulli(p)and $*$ denotes an element-wise product. Marginalizing the noise, the objective function becomes

当输入$X$被dropout处理，使得任一输入维度以概率$p$被保留时，输入可表示为$R * X$，其中$R \in  \{ 0,1{\} }^{N \times  D}$是一个随机矩阵，元素服从伯努利分布Bernoulli(p)，$*$表示逐元素乘积。对噪声进行边缘化后，目标函数变为

$$
\mathop{\operatorname{minimize}}\limits_{\mathbf{w}}{\mathbb{E}}_{R \sim  \text{ Bernoulli(p) }}\left\lbrack  {\begin{Vmatrix}\mathbf{y} - \left( R * X\right) \mathbf{w}\end{Vmatrix}}^{2}\right\rbrack  .
$$

This reduces to

该式简化为

$$
\mathop{\operatorname{minimize}}\limits_{\mathbf{w}}\;\parallel \mathbf{y} - {pX}\mathbf{w}{\parallel }^{2} + p\left( {1 - p}\right) \parallel \Gamma \mathbf{w}{\parallel }^{2},
$$

where $\Gamma  = {\left( \operatorname{diag}\left( {X}^{\top }X\right) \right) }^{1/2}$ . Therefore, dropout with linear regression is equivalent, in expectation, to ridge regression with a particular form for $\Gamma$ . This form of $\Gamma$ essentially scales the weight cost for weight ${w}_{i}$ by the standard deviation of the $i$ th dimension of the data. If a particular data dimension varies a lot, the regularizer tries to squeeze its weight more.

其中$\Gamma  = {\left( \operatorname{diag}\left( {X}^{\top }X\right) \right) }^{1/2}$。因此，线性回归中的dropout在期望意义上等价于带有特定形式$\Gamma$的岭回归(ridge regression)。该形式的$\Gamma$本质上通过数据第$i$维的标准差对权重${w}_{i}$的权重惩罚进行缩放。如果某个数据维度变化较大，正则项会更强烈地压缩其对应的权重。

Another interesting way to look at this objective is to absorb the factor of $p$ into $\mathbf{w}$ . This leads to the following form

另一种有趣的视角是将因子$p$吸收到$\mathbf{w}$中，得到以下形式

$$
\mathop{\operatorname{minimize}}\limits_{\mathbf{w}}\;{\begin{Vmatrix}\mathbf{y} - X\widetilde{\mathbf{w}}\end{Vmatrix}}^{2} + \frac{1 - p}{p}\parallel \Gamma \widetilde{\mathbf{w}}{\parallel }^{2},
$$

where $\widetilde{\mathbf{w}} = p\mathbf{w}$ . This makes the dependence of the regularization constant on $p$ explicit. For $p$ close to 1, all the inputs are retained and the regularization constant is small. As more dropout is done (by decreasing $p$ ), the regularization constant grows larger.

其中$\widetilde{\mathbf{w}} = p\mathbf{w}$。这使得正则化常数对$p$的依赖关系变得显式。当$p$接近1时，所有输入均被保留，正则化常数较小。随着dropout程度加大(即$p$减小)，正则化常数增大。

### 9.2 Logistic Regression and Deep Networks

### 9.2 逻辑回归与深度网络

For logistic regression and deep neural nets, it is hard to obtain a closed form marginalized model. However, Wang and Manning (2013) showed that in the context of dropout applied to logistic regression, the corresponding marginalized model can be trained approximately. Under reasonable assumptions, the distributions over the inputs to the logistic unit and over the gradients of the marginalized model are Gaussian. Their means and variances can be computed efficiently. This approximate marginalization outperforms Monte-Carlo dropout in terms of training time and generalization performance.

对于逻辑回归和深度神经网络，难以获得封闭形式的边缘化模型。然而，Wang和Manning(2013)表明，在将dropout应用于逻辑回归的背景下，相应的边缘化模型可以被近似训练。在合理假设下，逻辑单元输入的分布及边缘化模型梯度的分布均为高斯分布，其均值和方差可以高效计算。该近似边缘化在训练时间和泛化性能上优于蒙特卡洛dropout。

However, the assumptions involved in this technique become successively weaker as more layers are added. Therefore, the results are not directly applicable to deep networks.

然而，随着层数增加，该技术所依赖的假设逐渐变弱，因此结果不能直接应用于深度网络。

<table><tr><td>Data Set</td><td>Architecture</td><td>Bernoulli dropout</td><td>Gaussian dropout</td></tr><tr><td>MNIST</td><td>2 layers, 1024 units each</td><td>${1.08} \pm  {0.04}$</td><td>${0.95} \pm  {0.04}$</td></tr><tr><td>CIFAR-10</td><td>3 conv + 2 fully connected layers</td><td>${12.6} \pm  {0.1}$</td><td>${12.5} \pm  {0.1}$</td></tr></table>

<table><tbody><tr><td>数据集</td><td>架构</td><td>伯努利丢弃法(Bernoulli dropout)</td><td>高斯丢弃法(Gaussian dropout)</td></tr><tr><td>MNIST(手写数字数据库)</td><td>2层，每层1024个单元</td><td>${1.08} \pm  {0.04}$</td><td>${0.95} \pm  {0.04}$</td></tr><tr><td>CIFAR-10(图像分类数据集)</td><td>3个卷积层 + 2个全连接层</td><td>${12.6} \pm  {0.1}$</td><td>${12.5} \pm  {0.1}$</td></tr></tbody></table>

Table 10: Comparison of classification error % with Bernoulli and Gaussian dropout. For MNIST, the Bernoulli model uses $p = {0.5}$ for the hidden units and $p = {0.8}$ for the input units. For CIFAR-10, we use $p = \left( {{0.9},{0.75},{0.75},{0.5},{0.5},{0.5}}\right)$ going from the input layer to the top. The value of $\sigma$ for the Gaussian dropout models was set to be $\sqrt{\frac{1 - p}{p}}$ . Results were averaged over 10 different random seeds.

表10:使用伯努利(Bernoulli)和高斯(Gaussian)dropout的分类错误率%比较。对于MNIST，伯努利模型对隐藏单元使用$p = {0.5}$，对输入单元使用$p = {0.8}$。对于CIFAR-10，我们从输入层到顶层使用$p = \left( {{0.9},{0.75},{0.75},{0.5},{0.5},{0.5}}\right)$。高斯dropout模型中$\sigma$的值设为$\sqrt{\frac{1 - p}{p}}$。结果是对10个不同随机种子取平均。

## 10. Multiplicative Gaussian Noise

## 10. 乘法高斯噪声

Dropout involves multiplying hidden activations by Bernoulli distributed random variables which take the value 1 with probability $p$ and 0 otherwise. This idea can be generalized by multiplying the activations with random variables drawn from other distributions. We recently discovered that multiplying by a random variable drawn from $\mathcal{N}\left( {1,1}\right)$ works just as well, or perhaps better than using Bernoulli noise. This new form of dropout amounts to adding a Gaussian distributed random variable with zero mean and standard deviation equal to the activation of the unit. That is, each hidden activation ${h}_{i}$ is perturbed to ${h}_{i} + {h}_{i}r$ where $r \sim  \mathcal{N}\left( {0,1}\right)$ , or equivalently ${h}_{i}{r}^{\prime }$ where ${r}^{\prime } \sim  \mathcal{N}\left( {1,1}\right)$ . We can generalize this to ${r}^{\prime } \sim  \mathcal{N}\left( {1,{\sigma }^{2}}\right)$ where $\sigma$ becomes an additional hyperparameter to tune, just like $p$ was in the standard (Bernoulli) dropout. The expected value of the activations remains unchanged, therefore no weight scaling is required at test time.

Dropout涉及将隐藏激活乘以伯努利分布的随机变量，该变量以概率$p$取值1，否则为0。这个思想可以推广为用其他分布的随机变量乘以激活。我们最近发现，用从$\mathcal{N}\left( {1,1}\right)$中抽取的随机变量相乘效果同样好，甚至可能优于伯努利噪声。这种新的dropout形式相当于添加一个均值为零、标准差等于单元激活值的高斯分布随机变量。即，每个隐藏激活${h}_{i}$被扰动为${h}_{i} + {h}_{i}r$，其中$r \sim  \mathcal{N}\left( {0,1}\right)$，或者等价地为${h}_{i}{r}^{\prime }$，其中${r}^{\prime } \sim  \mathcal{N}\left( {1,1}\right)$。我们可以将其推广为${r}^{\prime } \sim  \mathcal{N}\left( {1,{\sigma }^{2}}\right)$，其中$\sigma$成为一个额外的超参数需要调节，就像标准(伯努利)dropout中的$p$一样。激活的期望值保持不变，因此测试时无需进行权重缩放。

In this paper, we described dropout as a method where we retain units with probability $p$ at training time and scale down the weights by multiplying them by a factor of $p$ at test time. Another way to achieve the same effect is to scale up the retained activations by multiplying by $1/p$ at training time and not modifying the weights at test time. These methods are equivalent with appropriate scaling of the learning rate and weight initializations at each layer.

本文中，我们将dropout描述为训练时以概率$p$保留单元，测试时通过乘以$p$因子缩小权重。另一种实现相同效果的方法是在训练时将保留的激活乘以$1/p$放大，测试时不修改权重。这些方法在适当调整每层的学习率和权重初始化后是等价的。

Therefore, dropout can be seen as multiplying ${h}_{i}$ by a Bernoulli random variable ${r}_{b}$ that takes the value $1/p$ with probability $p$ and 0 otherwise. $E\left\lbrack  {r}_{b}\right\rbrack   = 1$ and $\operatorname{Var}\left\lbrack  {r}_{b}\right\rbrack   = \left( {1 - p}\right) /p$ . For the Gaussian multiplicative noise, if we set ${\sigma }^{2} = \left( {1 - p}\right) /p$ , we end up multiplying ${h}_{i}$ by a random variable ${r}_{g}$ , where $E\left\lbrack  {r}_{g}\right\rbrack   = 1$ and $\operatorname{Var}\left\lbrack  {r}_{g}\right\rbrack   = \left( {1 - p}\right) /p$ . Therefore, both forms of dropout can be set up so that the random variable being multiplied by has the same mean and variance. However, given these first and second order moments, ${r}_{g}$ has the highest entropy and ${r}_{b}$ has the lowest. Both these extremes work well, although preliminary experimental results shown in Table 10 suggest that the high entropy case might work slightly better. For each layer, the value of $\sigma$ in the Gaussian model was set to be $\sqrt{\frac{1 - p}{p}}$ using the $p$ from the corresponding layer in the Bernoulli model.

因此，dropout可以看作是将${h}_{i}$乘以一个伯努利随机变量${r}_{b}$，该变量以概率$p$取值$1/p$，否则为0。$E\left\lbrack  {r}_{b}\right\rbrack   = 1$和$\operatorname{Var}\left\lbrack  {r}_{b}\right\rbrack   = \left( {1 - p}\right) /p$。对于高斯乘法噪声，如果我们设定${\sigma }^{2} = \left( {1 - p}\right) /p$，则最终将${h}_{i}$乘以一个随机变量${r}_{g}$，其中$E\left\lbrack  {r}_{g}\right\rbrack   = 1$且$\operatorname{Var}\left\lbrack  {r}_{g}\right\rbrack   = \left( {1 - p}\right) /p$。因此，这两种dropout形式都可以设置为乘以的随机变量具有相同的均值和方差。然而，给定这些一阶和二阶矩，${r}_{g}$具有最高熵，${r}_{b}$具有最低熵。这两个极端都表现良好，尽管表10中的初步实验结果表明高熵情况可能略优。对于每一层，高斯模型中的$\sigma$值设为$\sqrt{\frac{1 - p}{p}}$，使用对应伯努利模型层的$p$。

## 11. Conclusion

## 11. 结论

Dropout is a technique for improving neural networks by reducing overfitting. Standard backpropagation learning builds up brittle co-adaptations that work for the training data but do not generalize to unseen data. Random dropout breaks up these co-adaptations by making the presence of any particular hidden unit unreliable. This technique was found to improve the performance of neural nets in a wide variety of application domains including object classification, digit recognition, speech recognition, document classification and analysis of computational biology data. This suggests that dropout is a general technique and is not specific to any domain. Methods that use dropout achieve state-of-the-art results on SVHN, ImageNet, CIFAR-100 and MNIST. Dropout considerably improved the performance of standard neural nets on other data sets as well.

Dropout是一种通过减少过拟合来改进神经网络的技术。标准的反向传播学习会形成脆弱的共适应，这些共适应在训练数据上有效，但无法推广到未见过的数据。随机dropout通过使任何特定隐藏单元的存在变得不可靠，打破了这些共适应。该技术被发现能提升神经网络在包括目标分类、数字识别、语音识别、文档分类和计算生物学数据分析等多种应用领域的性能。这表明dropout是一种通用技术，并非特定于某一领域。使用dropout的方法在SVHN、ImageNet、CIFAR-100和MNIST上达到了最先进的结果。dropout也显著提升了标准神经网络在其他数据集上的表现。

This idea can be extended to Restricted Boltzmann Machines and other graphical models. The central idea of dropout is to take a large model that overfits easily and repeatedly sample and train smaller sub-models from it. RBMs easily fit into this framework. We developed Dropout RBMs and empirically showed that they have certain desirable properties.

这一思想可以扩展到受限玻尔兹曼机(Restricted Boltzmann Machines, RBMs)和其他图模型。dropout的核心思想是从一个容易过拟合的大模型中反复采样并训练较小的子模型。RBMs很容易适应这一框架。我们开发了Dropout RBMs，并通过实验证明它们具有某些理想的特性。

One of the drawbacks of dropout is that it increases training time. A dropout network typically takes 2-3 times longer to train than a standard neural network of the same architecture. A major cause of this increase is that the parameter updates are very noisy. Each training case effectively tries to train a different random architecture. Therefore, the gradients that are being computed are not gradients of the final architecture that will be used at test time. Therefore, it is not surprising that training takes a long time. However, it is likely that this stochasticity prevents overfitting. This creates a trade-off between over-fitting and training time. With more training time, one can use high dropout and suffer less overfitting. However, one way to obtain some of the benefits of dropout without stochas-ticity is to marginalize the noise to obtain a regularizer that does the same thing as the dropout procedure, in expectation. We showed that for linear regression this regularizer is a modified form of L2 regularization. For more complicated models, it is not obvious how to obtain an equivalent regularizer. Speeding up dropout is an interesting direction for future work.

dropout的一个缺点是增加了训练时间。一个dropout网络的训练时间通常是相同架构的标准神经网络的2-3倍。训练时间增加的主要原因是参数更新非常嘈杂。每个训练样本实际上都在训练一个不同的随机架构。因此，计算出的梯度并非最终测试时使用的架构的梯度。因此，训练时间较长并不令人意外。然而，这种随机性很可能防止了过拟合。这在过拟合和训练时间之间形成了权衡。训练时间越长，可以使用更高的dropout率，从而减少过拟合。然而，一种在不引入随机性的情况下获得部分dropout益处的方法是对噪声进行边际化，得到一个在期望上与dropout过程相同作用的正则项。我们证明了对于线性回归，这个正则项是L2正则化的变体。对于更复杂的模型，如何获得等效的正则项尚不明显。加速dropout是未来研究的一个有趣方向。

## Acknowledgments

## 致谢

This research was supported by OGS, NSERC and an Early Researcher Award.

本研究得到了OGS、NSERC和早期研究者奖的支持。

## Appendix A. A Practical Guide for Training Dropout Networks

## 附录A. Dropout网络训练实用指南

Neural networks are infamous for requiring extensive hyperparameter tuning. Dropout networks are no exception. In this section, we describe heuristics that might be useful for applying dropout.

神经网络以需要大量超参数调优而闻名，dropout网络也不例外。本节介绍一些应用dropout时可能有用的经验法则。

### A.1 Network Size

### A.1 网络规模

It is to be expected that dropping units will reduce the capacity of a neural network. If $n$ is the number of hidden units in any layer and $p$ is the probability of retaining a unit, then instead of $n$ hidden units, only ${pn}$ units will be present after dropout, in expectation. Moreover, this set of ${pn}$ units will be different each time and the units are not allowed to build co-adaptations freely. Therefore, if an $n$ -sized layer is optimal for a standard neural net on any given task, a good dropout net should have at least $n/p$ units. We found this to be a useful heuristic for setting the number of hidden units in both convolutional and fully connected networks.

丢弃单元会降低神经网络的容量是预料之中的。如果$n$是任一层中的隐藏单元数，$p$是保留单元的概率，那么期望中dropout后存在的单元数为${pn}$，而非$n$。此外，这组${pn}$单元每次都会不同，且单元不允许自由形成共适应。因此，如果在某任务上标准神经网络的最优层大小为$n$，那么一个良好的dropout网络应至少有$n/p$个单元。我们发现这对卷积网络和全连接网络中隐藏单元数的设置是一个有用的经验法则。

### A.2 Learning Rate and Momentum

### A.2 学习率和动量

Dropout introduces a significant amount of noise in the gradients compared to standard stochastic gradient descent. Therefore, a lot of gradients tend to cancel each other. In order to make up for this, a dropout net should typically use 10-100 times the learning rate that was optimal for a standard neural net. Another way to reduce the effect the noise is to use a high momentum. While momentum values of 0.9 are common for standard nets, with dropout we found that values around 0.95 to 0.99 work quite a lot better. Using high learning rate and/or momentum significantly speed up learning.

与标准随机梯度下降相比，dropout引入了大量梯度噪声。因此，许多梯度会相互抵消。为弥补这一点，dropout网络通常应使用比标准神经网络高10-100倍的学习率。另一种减少噪声影响的方法是使用较高的动量。标准网络常用的动量值为0.9，而在dropout中，我们发现0.95到0.99的动量值效果更佳。使用高学习率和/或高动量显著加快了学习速度。

### A.3 Max-norm Regularization

### A.3 最大范数正则化

Though large momentum and learning rate speed up learning, they sometimes cause the network weights to grow very large. To prevent this, we can use max-norm regularization. This constrains the norm of the vector of incoming weights at each hidden unit to be bound by a constant $c$ . Typical values of $c$ range from 3 to 4 .

虽然较大的动量和学习率加快了学习，但有时会导致网络权重变得非常大。为防止这种情况，可以使用最大范数正则化。该方法限制每个隐藏单元输入权重向量的范数不超过常数$c$。典型的$c$值范围是3到4。

### A.4 Dropout Rate

### A.4 Dropout率

Dropout introduces an extra hyperparameter-the probability of retaining a unit $p$ . This hyperparameter controls the intensity of dropout. $p = 1$ , implies no dropout and low values of $p$ mean more dropout. Typical values of $p$ for hidden units are in the range 0.5 to 0.8 . For input layers, the choice depends on the kind of input. For real-valued inputs (image patches or speech frames), a typical value is 0.8 . For hidden layers, the choice of $p$ is coupled with the choice of number of hidden units $n$ . Smaller $p$ requires big $n$ which slows down the training and leads to underfitting. Large $p$ may not produce enough dropout to prevent overfitting.

Dropout引入了一个额外的超参数——保留单元的概率$p$。该超参数控制dropout的强度。$p = 1$表示不使用dropout，$p$的较低值意味着更多的dropout。隐藏单元的典型$p$值范围为0.5到0.8。对于输入层，选择取决于输入类型。对于实值输入(图像块或语音帧)，典型值为0.8。对于隐藏层，$p$的选择与隐藏单元数量$n$的选择相关联。较小的$p$需要较大的$n$，这会减慢训练速度并导致欠拟合。较大的$p$可能无法产生足够的dropout以防止过拟合。

## Appendix B. Detailed Description of Experiments and Data Sets

## 附录B. 实验和数据集的详细描述

This section describes the network architectures and training details for the experimental results reported in this paper. The code for reproducing these results can be obtained from http://www.cs.toronto.edu/~nitish/dropout.The implementation is GPU-based. We used the excellent CUDA libraries-cudamat (Mnih, 2009) and cuda-convnet (Krizhevsky et al., 2012) to implement our networks.

本节描述了本文报告的实验结果所用的网络架构和训练细节。可从http://www.cs.toronto.edu/~nitish/dropout获取复现这些结果的代码。实现基于GPU。我们使用了优秀的CUDA库——cudamat(Mnih, 2009)和cuda-convnet(Krizhevsky等，2012)来实现我们的网络。

### B.1 MNIST

### B.1 MNIST

The MNIST data set consists of 60,000 training and 10,000 test examples each representing a ${28} \times  {28}$ digit image. We held out 10,000 random training images for validation. Hyperpa-rameters were tuned on the validation set such that the best validation error was produced after 1 million weight updates. The validation set was then combined with the training set and training was done for 1 million weight updates. This net was used to evaluate the performance on the test set. This way of using the validation set was chosen because we found that it was easy to set up hyperparameters so that early stopping was not required at all. Therefore, once the hyperparameters were fixed, it made sense to combine the validation and training sets and train for a very long time.

MNIST数据集包含60,000个训练样本和10,000个测试样本，每个样本代表一个${28} \times  {28}$数字图像。我们随机保留了10,000个训练图像作为验证集。超参数在验证集上调优，使得在100万次权重更新后获得最佳验证误差。然后将验证集合并回训练集，继续训练100万次权重更新。该网络用于评估测试集上的性能。采用这种使用验证集的方式是因为我们发现很容易设置超参数，使得完全不需要早停。因此，一旦超参数确定，合并验证集和训练集并进行长时间训练是合理的。

The architectures shown in Figure 4 include all combinations of 2,3, and 4 layer networks with 1024 and 2048 units in each layer. Thus, there are six architectures in all. For all the architectures (including the ones reported in Table 2), we used $p = {0.5}$ in all hidden layers and $p = {0.8}$ in the input layer. A final momentum of 0.95 and weight constraints with $c = 2$ was used in all the layers.

图4所示的架构包括2层、3层和4层网络的所有组合，每层有1024和2048个单元。因此共有六种架构。对于所有架构(包括表2中报告的)，我们在所有隐藏层使用$p = {0.5}$，输入层使用$p = {0.8}$。所有层均使用最终动量0.95和带有$c = 2$的权重约束。

To test the limits of dropout's regularization power, we also experimented with 2 and 3 layer nets having 4096 and 8192 units. 2 layer nets gave improvements as shown in Table 2. However, the three layer nets performed slightly worse than 2 layer ones with the same level of dropout. When we increased dropout, performance improved but not enough to outperform the 2 layer nets.

为了测试dropout正则化能力的极限，我们还尝试了具有4096和8192个单元的2层和3层网络。2层网络如表2所示带来了性能提升。然而，3层网络在相同dropout水平下表现略逊于2层网络。增加dropout后性能有所提升，但不足以超过2层网络。

### B.2 SVHN

### B.2 SVHN

The SVHN data set consists of approximately 600,000 training images and 26,000 test images. The training set consists of two parts-A standard labeled training set and another set of labeled examples that are easy. A validation set was constructed by taking examples from both the parts. Two-thirds of it were taken from the standard set (400 per class) and one-third from the extra set (200 per class), a total of 6000 samples. This same process is used by Sermanet et al. (2012). The inputs were RGB pixels normalized to have zero mean and unit variance. Other preprocessing techniques such as global or local contrast normalization or ZCA whitening did not give any noticeable improvements.

SVHN数据集包含约600,000张训练图像和26,000张测试图像。训练集由两部分组成——一个标准标注训练集和另一个易于识别的标注样本集。验证集由两部分样本构成，其中三分之二来自标准集(每类400个)，三分之一来自额外集(每类200个)，共计6000个样本。该过程同Sermanet等(2012)所用。输入为归一化至零均值和单位方差的RGB像素。其他预处理技术如全局或局部对比度归一化或ZCA白化未带来显著改进。

The best architecture that we found uses three convolutional layers each followed by a max-pooling layer. The convolutional layers have 96, 128 and 256 filters respectively. Each convolutional layer has a $5 \times  5$ receptive field applied with a stride of 1 pixel. Each max pooling layer pools $3 \times  3$ regions at strides of 2 pixels. The convolutional layers are followed by two fully connected hidden layers having 2048 units each. All units use the rectified linear activation function. Dropout was applied to all the layers of the network with the probability of retaining the unit being $p = \left( {{0.9},{0.75},{0.75},{0.5},{0.5},{0.5}}\right)$ for the different layers of the network (going from input to convolutional layers to fully connected layers). In addition, the max-norm constraint with $c = 4$ was used for all the weights. A momentum of 0.95 was used in all the layers. These hyperparameters were tuned using a validation set. Since the training set was quite large, we did not combine the validation set with the training set for final training. We reported test error of the model that had smallest validation error.

我们发现的最佳架构使用了三个卷积层，每个卷积层后面都跟着一个最大池化层。卷积层分别有96、128和256个滤波器。每个卷积层的$5 \times  5$感受野以1像素的步幅应用。每个最大池化层以2像素的步幅对$3 \times  3$区域进行池化。卷积层后面是两个全连接隐藏层，每层有2048个单元。所有单元都使用修正线性激活函数。对网络的所有层都应用了dropout，保留单元的概率在网络的不同层(从输入层到卷积层再到全连接层)分别为$p = \left( {{0.9},{0.75},{0.75},{0.5},{0.5},{0.5}}\right)$。此外，所有权重都使用了最大范数约束，约束值为$c = 4$。所有层都使用了0.95的动量。这些超参数是通过验证集调优的。由于训练集相当大，我们没有将验证集与训练集合并进行最终训练。我们报告了验证误差最小的模型的测试误差。

### B.3 CIFAR-10 and CIFAR-100

### B.3 CIFAR-10 和 CIFAR-100

The CIFAR-10 and CIFAR-100 data sets consists of 50,000 training and 10,000 test images each. They have 10 and 100 image categories respectively. These are ${32} \times  {32}$ color images. We used 5,000 of the training images for validation. We followed the procedure similar to MNIST, where we found the best hyperparameters using the validation set and then combined it with the training set. The images were preprocessed by doing global contrast normalization in each color channel followed by ZCA whitening. Global contrast normalization means that for image and each color channel in that image, we compute the mean of the pixel intensities and subtract it from the channel. ZCA whitening means that we mean center the data, rotate it onto its principle components, normalize each component and then rotate it back. The network architecture and dropout rates are same as that for SVHN, except the learning rates for the input layer which had to be set to smaller values.

CIFAR-10 和 CIFAR-100 数据集各包含50,000张训练图像和10,000张测试图像。它们分别有10个和100个图像类别。这些是${32} \times  {32}$彩色图像。我们使用了5,000张训练图像作为验证集。我们遵循了类似于MNIST的流程，先用验证集找到最佳超参数，然后将验证集与训练集合并。图像预处理包括对每个颜色通道进行全局对比度归一化，随后进行ZCA白化。全局对比度归一化指的是对图像及其每个颜色通道计算像素强度的均值并从通道中减去该均值。ZCA白化指的是对数据进行均值中心化，旋转到主成分空间，归一化每个成分，然后再旋转回去。网络架构和dropout率与SVHN相同，唯独输入层的学习率需要设置得更小。

### B.4 TIMIT

### B.4 TIMIT

The open source Kaldi toolkit (Povey et al., 2011) was used to preprocess the data into log-filter banks. A monophone system was trained to do a forced alignment and to get labels for speech frames. Dropout neural networks were trained on windows of 21 consecutive frames to predict the label of the central frame. No speaker dependent operations were performed. The inputs were mean centered and normalized to have unit variance.

使用开源Kaldi工具包(Povey等，2011)将数据预处理为对数滤波器组。训练了一个单音素系统进行强制对齐并获取语音帧的标签。dropout神经网络在21帧连续窗口上训练，以预测中心帧的标签。未进行说话人依赖操作。输入数据进行了均值中心化和单位方差归一化。

We used probability of retention $p = {0.8}$ in the input layers and 0.5 in the hidden layers. Max-norm constraint with $c = 4$ was used in all the layers. A momentum of 0.95 with a high learning rate of 0.1 was used. The learning rate was decayed as ${\epsilon }_{0}{\left( 1 + t/T\right) }^{-1}$ . For DBN pretraining, we trained RBMs using CD-1. The variance of each input unit for the Gaussian RBM was fixed to 1. For finetuning the DBN with dropout, we found that in order to get the best results it was important to use a smaller learning rate (about 0.01). Adding max-norm constraints did not give any improvements.

我们在输入层使用了保留概率为$p = {0.8}$，在隐藏层使用了0.5。所有层都使用了最大范数约束，约束值为$c = 4$。使用了动量为0.95且学习率较高为0.1的设置。学习率按${\epsilon }_{0}{\left( 1 + t/T\right) }^{-1}$衰减。对于DBN预训练，我们使用CD-1训练了受限玻尔兹曼机(RBM)。高斯RBM中每个输入单元的方差固定为1。对带dropout的DBN进行微调时，我们发现为了获得最佳效果，使用较小的学习率(约0.01)非常重要。添加最大范数约束并未带来改进。

### B.5 Reuters

### B.5 路透社

The Reuters RCV1 corpus contains more than 800,000 documents categorized into 103 classes. These classes are arranged in a tree hierarchy. We created a subset of this data set consisting of 402,738 articles and a vocabulary of 2000 words comprising of 50 categories in which each document belongs to exactly one class. The data was split into equal sized training and test sets. We tried many network architectures and found that dropout gave improvements in classification accuracy over all of them. However, the improvement was not as significant as that for the image and speech data sets. This might be explained by the fact that this data set is quite big (more than 200,000 training examples) and overfitting is not a very serious problem.

路透社RCV1语料库包含超过80万篇文档，分为103个类别。这些类别以树状层级结构排列。我们创建了该数据集的一个子集，包含402,738篇文章和一个由2000个词组成的词汇表，涵盖50个类别，每篇文档恰好属于一个类别。数据被等分为训练集和测试集。我们尝试了多种网络架构，发现dropout在所有架构中均提升了分类准确率。然而，这一提升不如图像和语音数据集显著。这可能是因为该数据集规模较大(超过20万训练样本)，过拟合问题不太严重。

### B.6 Alternative Splicing

### B.6 可变剪接

The alternative splicing data set consists of data for 3665 cassette exons, 1014 RNA features and 4 tissue types derived from 27 mouse tissues. For each input, the target consists of 4 softmax units (one for tissue type). Each softmax unit has 3 states(inc, exc, nc)which are of the biological importance. For each softmax unit, the aim is to predict a distribution over these 3 states that matches the observed distribution from wet lab experiments as closely as possible. The evaluation metric is Code Quality which is defined as

可变剪接数据集包含来自27个小鼠组织的3665个盒式外显子、1014个RNA特征和4种组织类型的数据。对于每个输入，目标由4个softmax单元组成(每个对应一种组织类型)。每个softmax单元有3个状态(inc，exc，nc)，这些状态具有生物学重要性。对于每个softmax单元，目标是预测这3个状态的分布，使其尽可能接近湿实验中观察到的分布。评估指标为代码质量，定义如下

$$
\mathop{\sum }\limits_{{i = 1}}^{\text{data points }}\mathop{\sum }\limits_{{t \in  \text{ tissue types }}}\mathop{\sum }\limits_{{s \in  \{ \text{ inc, exc, nc }\} }}{p}_{i, t}^{s}\log \left( \frac{{q}_{t}^{s}\left( {r}_{i}\right) }{{\bar{p}}^{s}}\right) ,
$$

where, ${p}_{i, t}^{s}$ is the target probability for state $s$ and tissue type $t$ in input $i;{q}_{t}^{s}\left( {r}_{i}\right)$ is the predicted probability for state $s$ in tissue type $t$ for input ${r}_{i}$ and ${\bar{p}}^{s}$ is the average of ${p}_{i, t}^{s}$ over $i$ and $t$ .

其中，${p}_{i, t}^{s}$是输入$i;{q}_{t}^{s}\left( {r}_{i}\right)$中状态$s$和组织类型$t$的目标概率，${r}_{i}$中状态$s$和组织类型$t$的预测概率为${\bar{p}}^{s}$，${p}_{i, t}^{s}$在$i$和$t$上的平均值为${\bar{p}}^{s}$。

A two layer dropout network with 1024 units in each layer was trained on this data set. A value of $p = {0.5}$ was used for the hidden layer and $p = {0.7}$ for the input layer. Max-norm regularization with high decaying learning rates was used. Results were averaged across the same 5 folds used by Xiong et al. (2011). References

在该数据集上训练了一个两层的dropout网络，每层包含1024个单元。隐藏层使用了$p = {0.5}$的值，输入层使用了$p = {0.7}$的值。采用了最大范数正则化和高衰减学习率。结果是基于Xiong等人(2011)使用的相同5折交叉验证的平均值。参考文献

M. Chen, Z. Xu, K. Weinberger, and F. Sha. Marginalized denoising autoencoders for domain adaptation. In Proceedings of the 29th International Conference on Machine Learning, pages 767-774. ACM, 2012.

M. Chen, Z. Xu, K. Weinberger, 和 F. Sha. 用于领域适应的边缘去噪自编码器。载于第29届国际机器学习大会论文集，页767-774。ACM，2012年。

G. E. Dahl, M. Ranzato, A. Mohamed, and G. E. Hinton. Phone recognition with the mean-covariance restricted Boltzmann machine. In Advances in Neural Information Processing Systems 23, pages 469-477, 2010.

G. E. Dahl, M. Ranzato, A. Mohamed, 和 G. E. Hinton. 基于均值-协方差受限玻尔兹曼机的语音识别。载于第23届神经信息处理系统大会论文集，页469-477，2010年。

O. Dekel, O. Shamir, and L. Xiao. Learning to classify with missing and corrupted features. Machine Learning, 81(2):149-178, 2010.

O. Dekel, O. Shamir, 和 L. Xiao. 学习分类时处理缺失和损坏特征。机器学习，81(2):149-178，2010年。

A. Globerson and S. Roweis. Nightmare at test time: robust learning by feature deletion. In Proceedings of the 23rd International Conference on Machine Learning, pages 353-360. ACM, 2006.

A. Globerson 和 S. Roweis. 测试时的噩梦:通过特征删除实现鲁棒学习。载于第23届国际机器学习大会论文集，页353-360。ACM，2006年。

I. J. Goodfellow, D. Warde-Farley, M. Mirza, A. Courville, and Y. Bengio. Maxout networks. In Proceedings of the 30th International Conference on Machine Learning, pages 1319- 1327. ACM, 2013.

I. J. Goodfellow, D. Warde-Farley, M. Mirza, A. Courville, 和 Y. Bengio. Maxout网络。载于第30届国际机器学习大会论文集，页1319-1327。ACM，2013年。

G. Hinton and R. Salakhutdinov. Reducing the dimensionality of data with neural networks. Science, 313(5786):504 - 507, 2006.

G. Hinton 和 R. Salakhutdinov. 利用神经网络降低数据维度。科学，313(5786):504-507，2006年。

G. E. Hinton, S. Osindero, and Y. Teh. A fast learning algorithm for deep belief nets. Neural Computation, 18:1527-1554, 2006.

G. E. Hinton, S. Osindero, 和 Y. Teh. 深度置信网络的快速学习算法。神经计算，18:1527-1554，2006年。

K. Jarrett, K. Kavukcuoglu, M. Ranzato, and Y. LeCun. What is the best multi-stage architecture for object recognition? In Proceedings of the International Conference on Computer Vision (ICCV'09). IEEE, 2009.

K. Jarrett, K. Kavukcuoglu, M. Ranzato, 和 Y. LeCun. 物体识别的最佳多阶段架构是什么？载于国际计算机视觉大会(ICCV'09)论文集。IEEE，2009年。

A. Krizhevsky. Learning multiple layers of features from tiny images. Technical report, University of Toronto, 2009.

A. Krizhevsky. 从微小图像中学习多层特征。多伦多大学技术报告，2009年。

A. Krizhevsky, I. Sutskever, and G. E. Hinton. Imagenet classification with deep convolutional neural networks. In Advances in Neural Information Processing Systems 25, pages 1106-1114, 2012.

A. Krizhevsky, I. Sutskever, 和 G. E. Hinton. 使用深度卷积神经网络进行ImageNet分类。载于第25届神经信息处理系统大会论文集，页1106-1114，2012年。

Y. LeCun, B. Boser, J. S. Denker, D. Henderson, R. E. Howard, W. Hubbard, and L. D. Jackel. Backpropagation applied to handwritten zip code recognition. Neural Computation, 1(4):541-551, 1989.

Y. LeCun, B. Boser, J. S. Denker, D. Henderson, R. E. Howard, W. Hubbard, 和 L. D. Jackel. 反向传播算法应用于手写邮政编码识别。神经计算，1(4):541-551，1989年。

Y. Lin, F. Lv, S. Zhu, M. Yang, T. Cour, K. Yu, L. Cao, Z. Li, M.-H. Tsai, X. Zhou, T. Huang, and T. Zhang. Imagenet classification: fast descriptor coding and large-scale svm training. Large scale visual recognition challenge, 2010.

Y. Lin, F. Lv, S. Zhu, M. Yang, T. Cour, K. Yu, L. Cao, Z. Li, M.-H. Tsai, X. Zhou, T. Huang, 和 T. Zhang. ImageNet分类:快速描述符编码和大规模支持向量机训练。大规模视觉识别挑战，2010年。

A. Livnat, C. Papadimitriou, N. Pippenger, and M. W. Feldman. Sex, mixability, and modularity. Proceedings of the National Academy of Sciences, 107(4):1452-1457, 2010.

A. Livnat, C. Papadimitriou, N. Pippenger, 和 M. W. Feldman. 性别、混合性和模块化。美国国家科学院院刊，107(4):1452-1457，2010年。

V. Mnih. CUDAMat: a CUDA-based matrix class for Python. Technical Report UTML TR 2009-004, Department of Computer Science, University of Toronto, November 2009.

V. Mnih. CUDAMat:基于CUDA的Python矩阵类。多伦多大学计算机科学系技术报告UTML TR 2009-004，2009年11月。

A. Mohamed, G. E. Dahl, and G. E. Hinton. Acoustic modeling using deep belief networks. IEEE Transactions on Audio, Speech, and Language Processing, 2010.

A. Mohamed, G. E. Dahl, 和 G. E. Hinton. 使用深度置信网络(deep belief networks)的声学建模。IEEE音频、语音与语言处理汇刊，2010年。

R. M. Neal. Bayesian Learning for Neural Networks. Springer-Verlag New York, Inc., 1996.

R. M. Neal. 神经网络的贝叶斯学习(Bayesian Learning for Neural Networks)。纽约施普林格出版社，1996年。

Y. Netzer, T. Wang, A. Coates, A. Bissacco, B. Wu, and A. Y. Ng. Reading digits in natural images with unsupervised feature learning. In NIPS Workshop on Deep Learning and Unsupervised Feature Learning 2011, 2011.

Y. Netzer, T. Wang, A. Coates, A. Bissacco, B. Wu, 和 A. Y. Ng. 利用无监督特征学习识别自然图像中的数字。发表于2011年NIPS深度学习与无监督特征学习研讨会，2011年。

S. J. Nowlan and G. E. Hinton. Simplifying neural networks by soft weight-sharing. Neural Computation, 4(4), 1992.

S. J. Nowlan 和 G. E. Hinton. 通过软权重共享简化神经网络。神经计算，4(4)，1992年。

D. Povey, A. Ghoshal, G. Boulianne, L. Burget, O. Glembek, N. Goel, M. Hannemann, P. Motlicek, Y. Qian, P. Schwarz, J. Silovsky, G. Stemmer, and K. Vesely. The Kaldi Speech Recognition Toolkit. In IEEE 2011 Workshop on Automatic Speech Recognition and Understanding. IEEE Signal Processing Society, 2011.

D. Povey, A. Ghoshal, G. Boulianne, L. Burget, O. Glembek, N. Goel, M. Hannemann, P. Motlicek, Y. Qian, P. Schwarz, J. Silovsky, G. Stemmer, 和 K. Vesely. Kaldi语音识别工具包。发表于2011年IEEE自动语音识别与理解研讨会。IEEE信号处理学会，2011年。

R. Salakhutdinov and G. Hinton. Deep Boltzmann machines. In Proceedings of the International Conference on Artificial Intelligence and Statistics, volume 5, pages 448-455, 2009.

R. Salakhutdinov 和 G. Hinton. 深度玻尔兹曼机(Deep Boltzmann machines)。发表于国际人工智能与统计会议论文集，第5卷，页448-455，2009年。

R. Salakhutdinov and A. Mnih. Bayesian probabilistic matrix factorization using Markov chain Monte Carlo. In Proceedings of the 25th International Conference on Machine Learning. ACM, 2008.

R. Salakhutdinov 和 A. Mnih. 使用马尔可夫链蒙特卡洛的贝叶斯概率矩阵分解。发表于第25届国际机器学习会议。ACM，2008年。

J. Sanchez and F. Perronnin. High-dimensional signature compression for large-scale image classification. In Proceedings of the 2011 IEEE Conference on Computer Vision and Pattern Recognition, pages 1665-1672, 2011.

J. Sanchez 和 F. Perronnin. 用于大规模图像分类的高维签名压缩。发表于2011年IEEE计算机视觉与模式识别会议论文集，页1665-1672，2011年。

P. Sermanet, S. Chintala, and Y. LeCun. Convolutional neural networks applied to house numbers digit classification. In International Conference on Pattern Recognition (ICPR 2012), 2012.

P. Sermanet, S. Chintala, 和 Y. LeCun. 卷积神经网络在门牌号码数字分类中的应用。发表于2012年国际模式识别会议(ICPR 2012)，2012年。

P. Simard, D. Steinkraus, and J. Platt. Best practices for convolutional neural networks applied to visual document analysis. In Proceedings of the Seventh International Conference on Document Analysis and Recognition, volume 2, pages 958-962, 2003.

P. Simard, D. Steinkraus, 和 J. Platt. 应用于视觉文档分析的卷积神经网络最佳实践。发表于第七届国际文档分析与识别会议论文集，第2卷，页958-962，2003年。

J. Snoek, H. Larochelle, and R. Adams. Practical Bayesian optimization of machine learning algorithms. In Advances in Neural Information Processing Systems 25, pages 2960-2968, 2012.

J. Snoek, H. Larochelle, 和 R. Adams. 机器学习算法的实用贝叶斯优化。发表于第25届神经信息处理系统进展，页2960-2968，2012年。

N. Srebro and A. Shraibman. Rank, trace-norm and max-norm. In Proceedings of the 18th annual conference on Learning Theory, COLT'05, pages 545-560. Springer-Verlag, 2005.

N. Srebro 和 A. Shraibman. 秩、迹范数和最大范数。发表于第18届学习理论年会COLT'05，页545-560。施普林格出版社，2005年。

N. Srivastava. Improving Neural Networks with Dropout. Master's thesis, University of Toronto, January 2013.

N. Srivastava. 通过Dropout改进神经网络。多伦多大学硕士论文，2013年1月。

R. Tibshirani. Regression shrinkage and selection via the lasso. Journal of the Royal Statistical Society. Series B. Methodological, 58(1):267-288, 1996.

R. Tibshirani. 通过套索(lasso)进行回归收缩与变量选择。英国皇家统计学会学报B辑方法论，58(1):267-288，1996年。

A. N. Tikhonov. On the stability of inverse problems. Doklady Akademii Nauk SSSR, 39(5): 195-198, 1943.

A. N. Tikhonov. 逆问题的稳定性。苏联科学院院报，39(5):195-198，1943年。

L. van der Maaten, M. Chen, S. Tyree, and K. Q. Weinberger. Learning with marginalized corrupted features. In Proceedings of the 30th International Conference on Machine Learning, pages 410-418. ACM, 2013.

L. van der Maaten, M. Chen, S. Tyree, 和 K. Q. Weinberger. 使用边缘化损坏特征的学习方法。发表于第30届国际机器学习大会论文集，页码410-418。ACM，2013年。

P. Vincent, H. Larochelle, Y. Bengio, and P.-A. Manzagol. Extracting and composing robust features with denoising autoencoders. In Proceedings of the 25th International Conference on Machine Learning, pages 1096-1103. ACM, 2008.

P. Vincent, H. Larochelle, Y. Bengio, 和 P.-A. Manzagol. 利用去噪自编码器提取和组合鲁棒特征。发表于第25届国际机器学习大会论文集，页码1096-1103。ACM，2008年。

P. Vincent, H. Larochelle, I. Lajoie, Y. Bengio, and P.-A. Manzagol. Stacked denoising autoencoders: Learning useful representations in a deep network with a local denoising criterion. In Proceedings of the 27th International Conference on Machine Learning, pages 3371-3408. ACM, 2010.

P. Vincent, H. Larochelle, I. Lajoie, Y. Bengio, 和 P.-A. Manzagol. 堆叠去噪自编码器:在深度网络中通过局部去噪准则学习有用表示。发表于第27届国际机器学习大会论文集，页码3371-3408。ACM，2010年。

S. Wager, S. Wang, and P. Liang. Dropout training as adaptive regularization. In Advances in Neural Information Processing Systems 26, pages 351-359, 2013.

S. Wager, S. Wang, 和 P. Liang. Dropout训练作为自适应正则化。发表于《神经信息处理系统进展》第26卷，页码351-359，2013年。

S. Wang and C. D. Manning. Fast dropout training. In Proceedings of the 30th International Conference on Machine Learning, pages 118-126. ACM, 2013.

S. Wang 和 C. D. Manning. 快速dropout训练。发表于第30届国际机器学习大会论文集，页码118-126。ACM，2013年。

H. Y. Xiong, Y. Barash, and B. J. Frey. Bayesian prediction of tissue-regulated splicing using RNA sequence and cellular context. Bioinformatics, 27(18):2554-2562, 2011.

H. Y. Xiong, Y. Barash, 和 B. J. Frey. 基于RNA序列和细胞环境的组织调控剪接的贝叶斯预测。生物信息学，27(18):2554-2562，2011年。

M. D. Zeiler and R. Fergus. Stochastic pooling for regularization of deep convolutional neural networks. CoRR, abs/1301.3557, 2013.

M. D. Zeiler 和 R. Fergus. 用于深度卷积神经网络正则化的随机池化。CoRR, abs/1301.3557, 2013年。