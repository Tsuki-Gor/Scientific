# ${COCOA}$ : Context-Conditional Adaptation for Recognizing Unseen Classes in Unseen Domains

# ${COCOA}$ :用于识别未见领域中未见类别的上下文条件自适应

Puneet Mangla* ${}^{1}$ Shivam Chandhok* ${}^{2}$ Vineeth N Balasubramanian ${}^{1}$ Fahad Shahbaz Khan ${}^{2,3}$ ${}^{1}$ Indian Institute of Technology, Hyderabad ${}^{2}$ Mohamed bin Zayed University of AI, UAE ${}^{3}$ Linköping University, Sweden

普尼特·曼格拉* ${}^{1}$ 希瓦姆·钱德霍克* ${}^{2}$ 维尼特·N·巴拉萨布拉曼尼安 ${}^{1}$ 法哈德·沙赫巴兹·汗 ${}^{2,3}$ ${}^{1}$ 印度理工学院海得拉巴分校 ${}^{2}$ 阿联酋穆罕默德·本·扎耶德人工智能大学 ${}^{3}$ 瑞典林雪平大学

## Abstract

## 摘要

Recent progress towards designing models that can generalize to unseen domains (i.e domain generalization) or unseen classes (i.e zero-shot learning) has embarked interest towards building models that can tackle both domain-shift and semantic shift simultaneously (i.e zero-shot domain generalization). For models to generalize to unseen classes in unseen domains, it is crucial to learn feature representation that preserves class-level (domain-invariant) as well as domain-specific information. Motivated from the success of generative zero-shot approaches, we propose a feature generative framework integrated with a COntext COnditional Adaptive (COCOA) Batch-Normalization layer to seamlessly integrate class-level semantic and domain-specific information. The generated visual features better capture the underlying data distribution enabling us to generalize to unseen classes and domains at test-time. We thoroughly evaluate our approach on established large-scale benchmarks - DomainNet, DomainNet-LS (Limited Sources) - as well as a new CUB-Corruptions benchmark, and demonstrate promising performance over baselines and state-of-the-art methods. We show detailed ablations and analysis to verify that our proposed approach indeed allows us to generate better quality visual features relevant for zero-shot domain generalization.

近期在设计能够泛化到未见领域(即领域泛化)或未见类别(即零样本学习)的模型方面取得的进展，引发了人们对构建能够同时处理领域偏移和语义偏移的模型(即零样本领域泛化)的兴趣。为了使模型能够泛化到未见领域中的未见类别，学习能够保留类别级(领域不变)信息以及特定领域信息的特征表示至关重要。受生成式零样本方法成功的启发，我们提出了一个特征生成框架，该框架集成了上下文条件自适应(COCOA)批量归一化层，以无缝整合类别级语义信息和特定领域信息。生成的视觉特征能够更好地捕捉底层数据分布，使我们能够在测试时泛化到未见类别和领域。我们在已有的大规模基准数据集——DomainNet、DomainNet - LS(有限源)以及新的CUB - 损坏基准数据集上对我们的方法进行了全面评估，并展示了相对于基线方法和最先进方法的有前景的性能。我们进行了详细的消融实验和分析，以验证我们提出的方法确实能够生成与零样本领域泛化相关的更高质量的视觉特征。

## 1. Introduction

## 1. 引言

The dependence of deep learning models on large amounts of data and supervision creates a bottleneck and hinders their utilization in practical scenarios. This is a major problem in computer vision, where it is difficult to acquire large amounts of labeled data due to practical feasibility constraints or high annotation costs. There is thus a need to equip deep learning models with the ability to generalize to unseen tasks or classes at test-time using data from other related tasks or classes (where data is abundant) $\left\lbrack  {{21},{32},{54},{52},{33},{34},{39},{11},{38}}\right\rbrack$ . Two main scenarios where this problem is most prevalent are: (1) when extensive labeled data is present in some related domains but not in the target domain of interest (i.e domain shift); or (2) there is data available for few classes but not all classes of interest (i.e semantic shift).

深度学习模型对大量数据和监督的依赖造成了瓶颈，并阻碍了它们在实际场景中的应用。这在计算机视觉领域是一个主要问题，由于实际可行性限制或高昂的标注成本，很难获取大量标注数据。因此，需要让深度学习模型具备在测试时利用其他相关任务或类别(数据丰富)的数据泛化到未见任务或类别的能力 $\left\lbrack  {{21},{32},{54},{52},{33},{34},{39},{11},{38}}\right\rbrack$ 。这个问题最普遍的两种主要场景是:(1)在一些相关领域有大量标注数据，但在感兴趣的目标领域没有(即领域偏移)；或者(2)有少数类别的可用数据，但不是所有感兴趣类别的数据都有(即语义偏移)。

![0195d706-18c8-71e6-816f-df978d63610a_0_900_682_706_485_0.jpg](images/0195d706-18c8-71e6-816f-df978d63610a_0_900_682_706_485_0.jpg)

Figure 1. Overview of our approach. Shapes represent different domains and colors represent different classes. (Top) We show the zero-shot domain generalization problem setting in which we train on seen classes from source domains and model has to recognize unseen classes in unseen domains at test-time. (Bottom) Encoding semantic and domain context using COntext COnditional Adaptive (COCOA) Batch-Normalization layer helps to instill semantic and domain information into generated features. By jointly fusing both semantic and domain context, our method achieve best generalization to unseen classes in unseen domains at test-time.

图1. 我们方法的概述。形状代表不同的领域，颜色代表不同的类别。(上)我们展示了零样本领域泛化问题的设置，在该设置中，我们在源领域的可见类别上进行训练，模型需要在测试时识别未见领域中的未见类别。(下)使用上下文条件自适应(COCOA)批量归一化层对语义和领域上下文进行编码，有助于将语义和领域信息融入生成的特征中。通过联合融合语义和领域上下文，我们的方法在测试时能够对未见领域中的未见类别实现最佳泛化。

Domain shift challenges occur when the collection of data in the target domain or of all possible backgrounds/views of the depiction of objects is infeasible or tedious $\left\lbrack  {{25},{43},{15}}\right\rbrack$ . Semantic shift challenges occur when there are rare objects or long-tailed distributions which frequently occur in real-world scenarios [35]. There has been great interest and corresponding efforts in recent years towards tackling domain shift and semantic shift separately. However, applications in the real world do not guarantee that only one of them will occur - there is a need to make systems robust to the domain and semantic shifts simultaneously. The problem of tackling domain shift and semantic shift, as considered herein, together can be grouped as the Zero-Shot Domain Generalization (which we call ZSLDG) problem setting [27, 28]. In ZSLDG, the model has access to a set of seen classes from multiple source domains and has to generalize to unseen classes in unseen target domains at test time. Note that this problem of recognizing unseen classes in unseen domains (ZSLDG) is much more challenging than tackling zero-shot learning (ZSL) or domain generalization (DG) separately [27] and growingly relevant as deep learning models get reused across tasks.

当在目标领域收集数据或收集对象所有可能的背景/视图不可行或繁琐时，就会出现领域偏移挑战 $\left\lbrack  {{25},{43},{15}}\right\rbrack$ 。当存在稀有对象或长尾分布(在现实场景中经常出现)时，就会出现语义偏移挑战 [35] 。近年来，人们对分别处理领域偏移和语义偏移有很大的兴趣并付出了相应的努力。然而，现实世界中的应用并不能保证只会出现其中一种情况——需要使系统同时对领域和语义偏移具有鲁棒性。本文所考虑的同时处理领域偏移和语义偏移的问题可以归为零样本领域泛化(我们称之为ZSLDG)问题设置 [27, 28] 。在ZSLDG中，模型可以访问多个源领域的一组可见类别，并且需要在测试时泛化到未见目标领域中的未见类别。请注意，识别未见领域中的未见类别(ZSLDG)这个问题比分别处理零样本学习(ZSL)或领域泛化(DG)要困难得多 [27] ，并且随着深度学习模型在不同任务中的复用，这个问题变得越来越重要。

---

*Equal Contribution

*同等贡献

---

Feature generation methods $\left\lbrack  {{52},{36},{42},{30}}\right\rbrack$ have recently shown significant promise in traditional zero-shot or few-shot learning settings and are among the state-of-the-art today for such problems. However, these approaches assume that the source domains (during training) and the target domain (during testing) are the same and thus aim to generate features that only address semantic shift. They rely on the assumption that the visual-semantic relationship learned during training will generalize to unseen classes at test-time. However, there is no guarantee that this holds for images in domains unseen during training [27]. Thus, when used for addressing ZSLDG, the aforementioned methods lead to suboptimal performance. To tackle domain shift at test-time, it is important to generate feature representations that encode both domain-invariant and domain-specific information at a class level $\left\lbrack  {{10},{44}}\right\rbrack$ . Thus we conjecture that generating features that are consistent with only class-level semantics is not sufficient for addressing ZSLDG. However, encoding domain-specific information along with class information in generated features is not straightforward [27].

特征生成方法 $\left\lbrack  {{52},{36},{42},{30}}\right\rbrack$ 最近在传统的零样本或少样本学习环境中展现出了巨大的潜力，并且是目前解决此类问题的先进方法之一。然而，这些方法假设源领域(训练期间)和目标领域(测试期间)是相同的，因此旨在生成仅解决语义偏移的特征。它们依赖于这样一个假设，即训练期间学习到的视觉 - 语义关系在测试时能够推广到未见类别。然而，没有保证这种假设对于训练期间未见领域的图像也成立 [27]。因此，当用于解决零样本领域泛化(ZSLDG)问题时，上述方法会导致性能欠佳。为了解决测试时的领域偏移问题，生成能够在类别层面编码领域不变信息和领域特定信息的特征表示非常重要 $\left\lbrack  {{10},{44}}\right\rbrack$。因此，我们推测仅生成与类别层面语义一致的特征不足以解决 ZSLDG 问题。然而，在生成的特征中同时编码领域特定信息和类别信息并非易事 [27]。

Drawing inspiration from these observations, we propose a unified generative framework that uses COntext COnditional Adaptive (COCOA) Batch-Normalization to seamlessly integrate semantic and domain information to generate visual features of unseen classes in unseen domains. Depending on the setting, "context" can qualify as domain (for Domain Generalization), semantics (for Zero-Shot Learning), or both (in case of Zero-Shot Domain Generalization). Since this work primarily deals with the ZSLDG setting, 'context' in this work refers to both domain and semantic information (unless specified explicitly). Figure 1 provides an overall view of our framework and setting. Our key contributions are as follows:

受这些观察结果的启发，我们提出了一个统一的生成框架，该框架使用上下文条件自适应(COCOA)批量归一化来无缝集成语义和领域信息，以生成未见领域中未见类别的视觉特征。根据具体情况，“上下文”可以指领域(用于领域泛化)、语义(用于零样本学习)或两者(在零样本领域泛化的情况下)。由于这项工作主要处理 ZSLDG 场景，因此本文中的“上下文”指的是领域和语义信息(除非明确指定)。图 1 展示了我们的框架和场景的总体概况。我们的主要贡献如下:

- We devise a new feature generative framework integrated with COntext COnditional Adaptive (COCOA) batch normalization to encode both semantic and domain information for recognizing unseen classes in unseen domains.

- 我们设计了一个新的特征生成框架，该框架集成了上下文条件自适应(COCOA)批量归一化，用于编码语义和领域信息，以识别未见领域中的未见类别。

- In addition, we use different regularization techniques to regulate the presence of semantic and domain information in generated features in order to achieve better generalization at test-time.

- 此外，我们使用不同的正则化技术来调节生成特征中语义和领域信息的存在，以便在测试时实现更好的泛化。

- We perform comprehensive experiments on standard benchmarks: DomainNet and DomainNet-LS (Limited Sources). Further, we introduce another fine-grained ZSLDG benchmark, CUB-Corruptions, that incorporates domain-shifts encountered in practical real-world scenarios. We demonstrate that our proposed methodology provides state-of-the-art performance for the ZSLDG setting on both established and proposed benchmarks.

- 我们在标准基准数据集上进行了全面的实验:DomainNet 和 DomainNet - LS(有限源)。此外，我们还引入了另一个细粒度的 ZSLDG 基准数据集 CUB - Corruptions，该数据集包含了实际现实场景中遇到的领域偏移。我们证明了我们提出的方法在现有和新提出的基准数据集上针对 ZSLDG 场景都达到了先进的性能。

- We perform extensive analysis to characterize the efficacy of COntext COnditional Adaptation (COCOA) in encoding both semantic and domain-specific information to generate features that capture the given context better.

- 我们进行了广泛的分析，以表征上下文条件自适应(COCOA)在编码语义和领域特定信息以生成更好地捕捉给定上下文的特征方面的有效性。

To the best of our knowledge, this is the first generative approach to address the ZSLDG problem setting.

据我们所知，这是第一种解决 ZSLDG 问题场景的生成方法。

## 2. Related Work

## 2. 相关工作

Our work is situated at the intersection of ZSL and DG, and we hence review each of these kinds of methods first, before discussing the very few ZSLDG methods (two to be precise) that have been developed so far.

我们的工作处于零样本学习(ZSL)和领域泛化(DG)的交叉点，因此我们首先回顾这两类方法，然后再讨论目前已开发的极少数 ZSLDG 方法(确切地说是两种)。

Domain Generalization: Deep learning models suffer from dataset bias which results in poor generalization when training and testing data come from different domains $\left\lbrack  {{47},{17}}\right\rbrack$ . Domain generalization methods aim to alleviate dataset bias and enable models to generalize to unseen domains at inference. Most such approaches can be broadly categorized into two groups: (1) Methods that attempt to develop a domain-agnostic feature representation that is robust to real-world image variations [32, 54, 21, 15, 25]; and (2) Methods that aim to utilize domain-dependent information for generalization. The former group includes traditional approaches to enforce generalization to domains $\left\lbrack  {{32},{54},{21}}\right\rbrack$ , learning invariance via autoencoders [15] or using adversarial learning strategies to alleviate discrepancies between sources $\left\lbrack  {{25},{26}}\right\rbrack$ . Other approaches tackle domain shift by introducing specific training policies to simulate scenarios faced during test time [22] [23, 5] or using self-supervision [6] based techniques which enable the model to focus on the content of the image more than the domain. The common idea behind these approaches is that they tend to discard domain-specific information for generalization.

领域泛化:深度学习模型存在数据集偏差问题，当训练数据和测试数据来自不同领域时，会导致泛化能力较差 $\left\lbrack  {{47},{17}}\right\rbrack$。领域泛化方法旨在减轻数据集偏差，使模型在推理时能够泛化到未见领域。大多数此类方法大致可分为两类:(1)尝试开发一种对现实世界图像变化具有鲁棒性的领域无关特征表示的方法 [32, 54, 21, 15, 25]；(2)旨在利用领域相关信息进行泛化的方法。前一类包括传统的强制向领域泛化的方法 $\left\lbrack  {{32},{54},{21}}\right\rbrack$，通过自编码器学习不变性 [15] 或使用对抗学习策略来减轻源之间的差异 $\left\lbrack  {{25},{26}}\right\rbrack$。其他方法通过引入特定的训练策略来模拟测试时遇到的场景 [22] [23, 5] 或使用基于自监督 [6] 的技术，使模型更关注图像内容而非领域。这些方法背后的共同理念是，它们倾向于为了泛化而丢弃领域特定信息。

In contrast to this, the latter group comprises methods that aim to develop a domain-dependent representation [43, 44]. These approaches aim to collect independent domain statistics for each domain and interpolating them to infer the statistics for the domain of test samples at test time [43]. The main idea is to leverage the domain-specific information by mapping different domains to different points instead of leveraging the domain agnostic information.

与此相反，后一类方法旨在开发一种领域相关的表示 [43, 44]。这些方法旨在为每个领域收集独立的领域统计信息，并在测试时对其进行插值以推断测试样本所在领域的统计信息 [43]。其主要思想是通过将不同领域映射到不同点来利用领域特定信息，而不是利用领域无关信息。

Zero-Shot Learning Most methods that address the zero-shot learning problem aim to leverage the shared semantic space between the seen and unseen classes. The semantic representations usually comprise manually annotated attributes, sentence embeddings, or word-vectors which essentially capture class-level characteristics associated with the object class. Traditional methods [7] strive to channel knowledge through the semantic attribute layer to model the joint and facilitate knowledge transfer from semantic to image space. Other approaches aim to learn a projection function from visual to semantic space $\left\lbrack  {{40},4,{13}}\right\rbrack$ , semantic to visual space $\left\lbrack  {{49},{20},{56},{46}}\right\rbrack$ or a common intermediate embedding space $\left\lbrack  {{48},{57}}\right\rbrack$ , that can generalize to unseen classes at test-time.

零样本学习 大多数解决零样本学习问题的方法旨在利用已见类别和未见类别之间共享的语义空间。语义表示通常包括手动标注的属性、句子嵌入或词向量，这些本质上捕捉了与对象类别相关的类别级特征。传统方法[7]试图通过语义属性层传递知识，以对联合分布进行建模，并促进从语义空间到图像空间的知识迁移。其他方法旨在学习从视觉空间到语义空间$\left\lbrack  {{40},4,{13}}\right\rbrack$、从语义空间到视觉空间$\left\lbrack  {{49},{20},{56},{46}}\right\rbrack$或一个共同的中间嵌入空间$\left\lbrack  {{48},{57}}\right\rbrack$的投影函数，该函数能够在测试时推广到未见类别。

Furthermore, recent efforts use generative models to addressing generalization to unseen classes by synthesizing visual features for unseen classes conditioned on their semantic representations. These methods aim to construct a generative model that can capture the modes of the data distribution well and facilitate knowledge transfer between visual and semantic spaces to ensure better generalization to unseen classes. To this end, recent approaches aim to generate discriminative visual features $\lbrack {52},{36},{42},{30},{12},{18}$ , 19], combine strengths of different generative models like VAE and GAN [53, 33], the model joint likelihood of visual and semantic features in a generative framework $\left\lbrack  {8,{36}}\right\rbrack$ or use other likelihood-based generative models such as normalizing flows [45] to generate visual features.

此外，近期的研究工作使用生成模型，通过基于未见类别的语义表示合成视觉特征，来解决对未见类别的泛化问题。这些方法旨在构建一个生成模型，该模型能够很好地捕捉数据分布的模式，并促进视觉空间和语义空间之间的知识迁移，以确保对未见类别有更好的泛化能力。为此，近期的方法旨在生成具有判别性的视觉特征$\lbrack {52},{36},{42},{30},{12},{18}$、[19]，结合不同生成模型(如变分自编码器(VAE)和生成对抗网络(GAN))的优势[53, 33]，在生成框架中对视觉和语义特征的联合似然进行建模$\left\lbrack  {8,{36}}\right\rbrack$，或者使用其他基于似然的生成模型(如归一化流)[45]来生成视觉特征。

Zero-Shot Domain Generalization The problem of generalization to unseen classes in unseen domains i.e ZSLDG has been recently introduced $\left\lbrack  {{28},{27}}\right\rbrack$ and has attracted attention due to its usefulness in practical real-world scenarios encountered in computer vision. [28] showed results for previously proposed DG methods on the new ZSLDG setting. However, different domains were restricted here to different rotations of the same objects, which is limiting in practice. A more recent approach, CuMix [27], proposed a methodology that mixes up multiple source domains and categories available during training to simulate semantic and domain shift at test time. This work also established a benchmark dataset, DomainNet, for this setting with an evaluation protocol, which we follow in this work for a fair comparison. The DomainNet dataset is also a significant improvement over previous DG datasets, in terms of complexity and variety in domains.

零样本领域泛化 未见领域中对未见类别的泛化问题，即零样本领域泛化(ZSLDG)，最近被提出$\left\lbrack  {{28},{27}}\right\rbrack$，并因其在计算机视觉实际场景中的实用性而受到关注。[28]展示了先前提出的领域泛化(DG)方法在新的ZSLDG设置下的结果。然而，这里不同的领域被限制为相同对象的不同旋转，这在实际应用中具有局限性。最近的一种方法CuMix[27]提出了一种方法，该方法在训练期间混合多个源领域和类别，以模拟测试时的语义和领域偏移。这项工作还为此设置建立了一个基准数据集DomainNet，并制定了评估协议，我们在这项工作中遵循该协议以进行公平比较。DomainNet数据集在领域的复杂性和多样性方面也比以前的DG数据集有了显著改进。

## 3. COCOA: Proposed Methodology

## 3. COCOA:提出的方法

We begin with a discussion of important considerations when designing an approach for ZSLDG.

我们首先讨论在设计ZSLDG方法时的重要考虑因素。

Domain-shift: As discussed earlier, most methods that address only DG aim to map training data onto a domain-invariant manifold to tackle generalization to new domains $\left\lbrack  {{25},{55},{32},{54}}\right\rbrack$ . However, in practice, it is difficult to eliminate domain-specific cues to achieve a perfect domain-invariant representation. In practice, it is observed that feature representations that encode both domain-invariant and domain-specific information achieve improved recognition performance and generalization to new domains $\left\lbrack  {{10},{44}}\right\rbrack$ .

领域偏移:如前所述，大多数仅解决领域泛化(DG)问题的方法旨在将训练数据映射到一个领域不变的流形上，以解决对新领域的泛化问题$\left\lbrack  {{25},{55},{32},{54}}\right\rbrack$。然而，在实践中，很难消除特定领域的线索以实现完美的领域不变表示。在实践中观察到，同时编码领域不变信息和特定领域信息的特征表示能够提高识别性能，并增强对新领域的泛化能力$\left\lbrack  {{10},{44}}\right\rbrack$。

Semantic-shift: Previous works that aim to learn an embedding function $\left\lbrack  {{13},{41},2,{50},{48},3,9}\right\rbrack$ to enable generalization to unseen classes typically suffer from bias towards training data (seen classes), thereby resulting in poor generalization to unseen classes. Generative methods alleviate this issue by synthesizing unseen class features $\left\lbrack  {{52},{53},{36},{42},{30},{12},{18},{19}}\right\rbrack$ , thus reducing ZSL to a standard supervised learning setup. In practice, it is observed that generative approaches outperform other methods (such as embedding-based methods) enabling better generalization to unseen classes at test time.

语义偏移:先前旨在学习嵌入函数$\left\lbrack  {{13},{41},2,{50},{48},3,9}\right\rbrack$以实现对未见类别的泛化的工作通常存在对训练数据(已见类别)的偏差，从而导致对未见类别的泛化能力较差。生成方法通过合成未见类别的特征$\left\lbrack  {{52},{53},{36},{42},{30},{12},{18},{19}}\right\rbrack$来缓解这个问题，从而将零样本学习(ZSL)转化为标准的监督学习设置。在实践中观察到，生成方法在测试时比其他方法(如基于嵌入的方法)表现更好，能够更好地泛化到未见类别。

Drawing motivation from these observations, we propose a generative learning-based model to address the problem of ZSLDG. Since both class-level domain-invariant features (common across domains), as well as unique individual domain-specific characteristics, are important for generalization to unseen classes in unseen domains $\left\lbrack  {{10},{44}}\right\rbrack$ , we aim to learn a generative model which can encode both class-level semantic and domain-specific information in the generated features.

基于这些观察结果，我们提出了一种基于生成学习的模型来解决ZSLDG问题。由于类别级的领域不变特征(跨领域通用)以及独特的个体特定领域特征对于在未见领域中对未见类别的泛化都很重要$\left\lbrack  {{10},{44}}\right\rbrack$，我们旨在学习一个生成模型，该模型能够在生成的特征中同时编码类别级语义信息和特定领域信息。

### 3.1. Problem Setting and Overall Framework

### 3.1. 问题设置和总体框架

Our goal is to train a classifier $\mathcal{C}$ which can tackle domain-shift as well as semantic shift simultaneously and recognize unseen classes in unseen domains at test-time. Let ${S}^{Tr} = \left\{  {\left( {\mathbf{x}, y,{\mathbf{a}}_{y}^{s}, d}\right)  \mid  \mathbf{x} \in  \mathcal{X}, y \in  {\mathcal{Y}}^{s},{\mathbf{a}}_{y}^{s} \in  \mathcal{A}, d \in  {\mathcal{D}}^{s}}\right\}$ denote the training set, where $\mathbf{x}$ is a seen class image in the visual space(X)with corresponding label $y$ from a set of seen class labels ${\mathcal{Y}}^{s}$ . ${\mathbf{a}}_{y}^{s}$ denotes the class-specific semantic representation for seen classes. We assume access to domain labels $d$ for a set of source domains ${\mathcal{D}}^{s}$ with cardinality $K$ . The test-set is denoted by ${S}^{Ts} = \left\{  {\left( {\mathbf{x}, y,{\mathbf{a}}_{y}^{u}, d}\right)  \mid  \mathbf{x} \in  }\right.$ $\mathcal{X}, y \in  {\mathcal{Y}}^{u},{\mathbf{a}}_{y}^{u} \in  \mathcal{A}, d \in  {\mathcal{D}}^{u}\}$ where ${\mathcal{Y}}^{u}$ is the set of labels for unseen classes and ${\mathcal{D}}^{u}$ represents the set of unseen target domains. Note that standard zero-shot setting (tackles only semantic-shift) complies with the condition ${\mathcal{Y}}^{s} \cap  {\mathcal{Y}}^{u} \equiv  \varnothing$ and ${\mathcal{D}}^{s} \equiv  {\mathcal{D}}^{u}$ . The standard DG setting (tackles only domain-shift), on the other hand, works under the condition ${\mathcal{Y}}^{s} \equiv  {\mathcal{Y}}^{u}$ and ${\mathcal{D}}^{s} \cap  {\mathcal{D}}^{u} \equiv  \varnothing$ . In this work, our goal is to address the challenging ZSLDG setting where ${\mathcal{Y}}^{s} \cap  {\mathcal{Y}}^{u} \equiv  \varnothing$ and ${\mathcal{D}}^{s} \cap  {\mathcal{D}}^{u} \equiv  \varnothing$ . We aim to learn a mapping from $\mathcal{X} \rightarrow  {\mathcal{Y}}^{u}$ such that $\mathbf{x} \in  \mathcal{X}$ is sampled from a domain $d \in  {\mathcal{D}}^{u}$ and has class label $y \in  {\mathcal{Y}}^{u}$ , given that, the model is trained using only images from seen classes ${\mathcal{Y}}^{s}$ in seen domains ${\mathcal{D}}^{s}$ .

我们的目标是训练一个分类器$\mathcal{C}$，它能够同时处理领域偏移和语义偏移，并在测试时识别未见领域中的未见类别。令${S}^{Tr} = \left\{  {\left( {\mathbf{x}, y,{\mathbf{a}}_{y}^{s}, d}\right)  \mid  \mathbf{x} \in  \mathcal{X}, y \in  {\mathcal{Y}}^{s},{\mathbf{a}}_{y}^{s} \in  \mathcal{A}, d \in  {\mathcal{D}}^{s}}\right\}$表示训练集，其中$\mathbf{x}$是视觉空间(X)中一个已见类别的图像，其对应的标签$y$来自已见类别标签集合${\mathcal{Y}}^{s}$。${\mathbf{a}}_{y}^{s}$表示已见类别的特定类别语义表示。我们假设可以获取一组源领域${\mathcal{D}}^{s}$的领域标签$d$，该集合的基数为$K$。测试集用${S}^{Ts} = \left\{  {\left( {\mathbf{x}, y,{\mathbf{a}}_{y}^{u}, d}\right)  \mid  \mathbf{x} \in  }\right.$ $\mathcal{X}, y \in  {\mathcal{Y}}^{u},{\mathbf{a}}_{y}^{u} \in  \mathcal{A}, d \in  {\mathcal{D}}^{u}\}$表示，其中${\mathcal{Y}}^{u}$是未见类别的标签集合，${\mathcal{D}}^{u}$表示未见目标领域的集合。请注意，标准零样本设置(仅处理语义偏移)符合条件${\mathcal{Y}}^{s} \cap  {\mathcal{Y}}^{u} \equiv  \varnothing$和${\mathcal{D}}^{s} \equiv  {\mathcal{D}}^{u}$。另一方面，标准领域泛化(DG)设置(仅处理领域偏移)在条件${\mathcal{Y}}^{s} \equiv  {\mathcal{Y}}^{u}$和${\mathcal{D}}^{s} \cap  {\mathcal{D}}^{u} \equiv  \varnothing$下工作。在这项工作中，我们的目标是解决具有挑战性的零样本领域泛化(ZSLDG)设置，即${\mathcal{Y}}^{s} \cap  {\mathcal{Y}}^{u} \equiv  \varnothing$和${\mathcal{D}}^{s} \cap  {\mathcal{D}}^{u} \equiv  \varnothing$的情况。我们的目标是学习一个从$\mathcal{X} \rightarrow  {\mathcal{Y}}^{u}$的映射，使得$\mathbf{x} \in  \mathcal{X}$是从领域$d \in  {\mathcal{D}}^{u}$中采样得到的，并且具有类别标签$y \in  {\mathcal{Y}}^{u}$，前提是该模型仅使用已见领域${\mathcal{D}}^{s}$中已见类别${\mathcal{Y}}^{s}$的图像进行训练。

Our overall framework to address ZSLDG is summarized in Figure 2. We employ a three-stage pipeline, where in the first stage, we train a visual encoder to extract visual features $\mathbf{f}$ that encode discriminative information (described in Sec 3.2). This information consists of both class-level semantic information (domain-invariant) and domain-specific characteristics that help improve generalization [10]. Next, we train a generative model to generate features $\mathbf{f}$ from noise with the help of COntext COnditional Adaptation (COCOA) (described in Sec 3.3). This enables our model to capture both class-level and domain-specific information in generated features $\widehat{\mathbf{f}}$ and generate features relevant for the task. In the third stage, we use our trained generative model to generate features for unseen classes across domains and train a classifier that can handle domain shift as well as semantic shift simultaneously at test-time (described in Sec 3.4).

我们解决零样本领域泛化(ZSLDG)问题的整体框架总结如图2所示。我们采用一个三阶段的流程，在第一阶段，我们训练一个视觉编码器来提取视觉特征$\mathbf{f}$，这些特征编码了判别性信息(详见第3.2节)。此信息包括类别级别的语义信息(领域不变性)和有助于提高泛化能力的特定领域特征[10]。接下来，我们训练一个生成模型，借助上下文条件适应(COCOA)从噪声中生成特征$\mathbf{f}$(详见第3.3节)。这使我们的模型能够在生成的特征$\widehat{\mathbf{f}}$中捕捉类别级别和特定领域的信息，并生成与任务相关的特征。在第三阶段，我们使用训练好的生成模型为跨领域的未见类别生成特征，并训练一个分类器，该分类器能够在测试时同时处理领域偏移和语义偏移(详见第3.4节)。

![0195d706-18c8-71e6-816f-df978d63610a_3_144_204_1464_380_0.jpg](images/0195d706-18c8-71e6-816f-df978d63610a_3_144_204_1464_380_0.jpg)

Figure 2. Overall architecture of our approach. The proposed pipeline consists of three stages: (1) Generalizable Feature Extraction; (2) Generative Module; and (3) Recognition and Inference. The first stage trains a visual backbone $f\left( \text{.}\right)$ to extract visual feature $\mathbf{f}$ that encodes discriminative class-level (domain-invariant) and domain-specific information. The second stage learns a generative model $G$ which uses COntext COnditioned Adaptive (COCOA) batch-normalization layers to fuse and integrate semantic and domain-specific information into the generated features $\widehat{\mathbf{f}}$ . Lastly, the third stage generates visual features for unseen classes across domains and trains a softmax classifier on generated features

图2. 我们方法的整体架构。所提出的流程包括三个阶段:(1)可泛化特征提取；(2)生成模块；(3)识别与推理。第一阶段训练一个视觉主干网络$f\left( \text{.}\right)$来提取视觉特征$\mathbf{f}$，该特征编码了有区分性的类别级(领域不变)和特定领域信息。第二阶段学习一个生成模型$G$，该模型使用上下文条件自适应(COCOA)批量归一化层将语义和特定领域信息融合并整合到生成的特征$\widehat{\mathbf{f}}$中。最后，第三阶段为跨领域的未见类别生成视觉特征，并在生成的特征上训练一个softmax分类器

### 3.2. Generalizable Feature Extraction

### 3.2. 可泛化特征提取

Here, we describe the first stage in our proposed pipeline. Since the semantic representations of both seen and unseen class labels lie in the same space, capturing class-level semantic (domain-invariant) information in visual features becomes important for generalization to unseen classes. In addition to domain-invariant attributes, domain-specific information is also important for generalization to new domains [10]. To this end, we extract visual features $\mathbf{f}$ that encode discriminative class-level cues by training a visual encoder $f\left( \text{.}\right) ,$ which is then used to train a semantic projector $p\left( \text{.}\right)$ . Both these modules are trained with images from all source domains available. The visual encoder and the semantic projector are trained to minimize the following loss:

在这里，我们描述所提出流程的第一阶段。由于已见和未见类别标签的语义表示处于同一空间，因此在视觉特征中捕捉类别级语义(领域不变)信息对于泛化到未见类别至关重要。除了领域不变属性外，特定领域信息对于泛化到新领域也很重要[10]。为此，我们通过训练一个视觉编码器$f\left( \text{.}\right) ,$来提取编码有区分性的类别级线索的视觉特征$\mathbf{f}$，然后使用该特征训练一个语义投影器$p\left( \text{.}\right)$。这两个模块都使用所有可用源领域的图像进行训练。视觉编码器和语义投影器的训练目标是最小化以下损失:

$$
{\mathcal{L}}_{AGG} = {\mathbb{E}}_{\left( {\mathbf{x}, y}\right)  \sim  {S}^{Tr}}\left\lbrack  {{\mathcal{L}}_{CE}\left( {{\mathbf{a}}^{T}p\left( {f\left( \mathbf{x}\right) }\right) , y}\right) }\right\rbrack   \tag{1}
$$

where ${\mathcal{L}}_{CE}$ is standard cross-entropy loss and a $=$ $\left\lbrack  {{\mathbf{a}}_{1}^{s},\ldots ,{\mathbf{a}}_{\left| {\mathcal{Y}}^{s}\right| }^{s}}\right\rbrack$ . To further improve the visual features and enhance their generalizability, we also propose to use a regularization block resulting in an added regularizer loss term $\mathcal{R}\left( \mathbf{f}\right)$ . The regularizer block primarily uses rotation prediction (viz. providing a rotated image as input, and predicting rotation angle), although we attempt other strategies such as CuMix [27] or domain classification in our experiments in Sec 4. The overall loss function to train the visual encoder hence becomes:

其中${\mathcal{L}}_{CE}$是标准交叉熵损失，且$=$$\left\lbrack  {{\mathbf{a}}_{1}^{s},\ldots ,{\mathbf{a}}_{\left| {\mathcal{Y}}^{s}\right| }^{s}}\right\rbrack$。为了进一步改进视觉特征并增强其泛化能力，我们还提议使用一个正则化块，从而增加一个正则化损失项$\mathcal{R}\left( \mathbf{f}\right)$。正则化块主要使用旋转预测(即提供旋转后的图像作为输入，并预测旋转角度)，尽管我们在第4节的实验中尝试了其他策略，如CuMix [27]或领域分类。因此，训练视觉编码器的总体损失函数变为:

$$
{\mathcal{L}}_{R} = {\mathcal{L}}_{AGG} + \mathcal{R}\left( \mathbf{f}\right)  \tag{2}
$$

where $\mathcal{R}\left( \mathbf{f}\right)$ denotes the regularization loss term.

其中$\mathcal{R}\left( \mathbf{f}\right)$表示正则化损失项。

### 3.3. Generative Module

### 3.3. 生成模块

We now describe the next step in our pipeline i.e learning the generative network. To this end, we learn a generative model which comprises of a generator $G : \mathcal{Z} \times  \mathcal{A} \times  \mathcal{D} \rightarrow  \mathcal{F}$ and a projection discriminator [31] (which uses a projection layer to incorporate conditional information into the discriminator) $D : \mathcal{F} \times  \mathcal{A} \times  \mathcal{D} \rightarrow  \mathbb{R}$ as shown in Figure 2. We represent this discriminator as $D = {D}_{l} \circ  {D}_{f}$ ( $\circ$ denotes composition) where ${D}_{f}$ is discriminator’s last feature layer and ${D}_{l}$ is the final linear layer. Both the generator and the projection discriminator are conditioned through a Context Conditional Adaptive (COCOA) Batch-Normalization module, which provides class-specific and domain-specific modulation at various stages during the generation process. Modulating the feature information by such semantic and domain-specific embeddings helps to integrate respective information into the features, thereby enabling better generalization. We use the available (seen) semantic attributes ${\mathbf{a}}_{y}^{s}$ that capture class-level characteristics, for encoding semantic information. However, such a representation that encodes domain information is not present for individual source domains. We hence define learnable (randomly initialized and optimized during training) domain embedding matrices ${\mathcal{E}}_{\text{gen }} = \left\{  {{\mathbf{e}}_{1}^{\text{gen }},{\mathbf{e}}_{2}^{\text{gen }},{\mathbf{e}}_{3}^{\text{gen }}\ldots ,{\mathbf{e}}_{K}^{\text{gen }}}\right\}$ and ${\mathcal{E}}_{\text{disc }} =$ $\left\{  {{\mathbf{e}}_{1}^{\text{disc }},{\mathbf{e}}_{2}^{\text{disc }},{\mathbf{e}}_{3}^{\text{disc }}\ldots {\mathbf{e}}_{K}^{\text{disc }}}\right\}$ for the generator and the discriminator respectively.

我们现在描述流程中的下一步，即学习生成网络。为此，我们学习一个生成模型，该模型由一个生成器 $G : \mathcal{Z} \times  \mathcal{A} \times  \mathcal{D} \rightarrow  \mathcal{F}$ 和一个投影判别器 [31](它使用投影层将条件信息融入判别器)$D : \mathcal{F} \times  \mathcal{A} \times  \mathcal{D} \rightarrow  \mathbb{R}$ 组成，如图 2 所示。我们将这个判别器表示为 $D = {D}_{l} \circ  {D}_{f}$($\circ$ 表示组合)，其中 ${D}_{f}$ 是判别器的最后一个特征层，${D}_{l}$ 是最终的线性层。生成器和投影判别器都通过上下文条件自适应(COCOA)批量归一化模块进行条件设置，该模块在生成过程的各个阶段提供特定类别和特定领域的调制。通过这种语义和特定领域的嵌入来调制特征信息有助于将相应的信息整合到特征中，从而实现更好的泛化。我们使用可用的(已见的)语义属性 ${\mathbf{a}}_{y}^{s}$ 来捕捉类别级别的特征，以编码语义信息。然而，对于各个源领域，并不存在编码领域信息的这种表示。因此，我们分别为生成器和判别器定义可学习的(在训练期间随机初始化并优化)领域嵌入矩阵 ${\mathcal{E}}_{\text{gen }} = \left\{  {{\mathbf{e}}_{1}^{\text{gen }},{\mathbf{e}}_{2}^{\text{gen }},{\mathbf{e}}_{3}^{\text{gen }}\ldots ,{\mathbf{e}}_{K}^{\text{gen }}}\right\}$ 和 ${\mathcal{E}}_{\text{disc }} =$ $\left\{  {{\mathbf{e}}_{1}^{\text{disc }},{\mathbf{e}}_{2}^{\text{disc }},{\mathbf{e}}_{3}^{\text{disc }}\ldots {\mathbf{e}}_{K}^{\text{disc }}}\right\}$。

The generator $G$ takes in noise $\mathbf{z} \in  \mathcal{Z}$ and a context vector $\mathbf{c}$ , and outputs visual features $\widehat{\mathbf{f}} \in  \mathcal{F}$ . The context vector $\mathbf{c}$ , which is the concatenation of class-level semantic attribute ${\mathbf{a}}_{y}^{s}$ and domain-specific embedding ${\mathbf{e}}_{i}^{gen}$ , is provided as input to a BatchNorm estimator network ${B}_{\text{gen }}^{l} : \mathcal{A} \times  \mathcal{D} \rightarrow  {\mathcal{R}}^{2 \times  h}(h$ is the dimension of layer $l$ activation vectors) which outputs batchnorm paramaters, ${\gamma }_{gen}^{l}$ and ${\beta }_{gen}^{l}$ for the $l$ -th layer. Similarly, the discriminator’s feature extractor ${D}_{f}\left( \text{.}\right) {hasaseparateBatchNormestimator}$ network ${B}_{\text{disc }}^{l} : \mathcal{D} \rightarrow  {\mathcal{R}}^{2 \times  h}$ to enable domain-specific context modulation of its batchnorm parameters, ${\gamma }_{\text{disc }}^{l},{\beta }_{\text{disc }}^{l}$ as shown in Figure 2.

生成器 $G$ 接收噪声 $\mathbf{z} \in  \mathcal{Z}$ 和上下文向量 $\mathbf{c}$，并输出视觉特征 $\widehat{\mathbf{f}} \in  \mathcal{F}$。上下文向量 $\mathbf{c}$ 是类别级语义属性 ${\mathbf{a}}_{y}^{s}$ 和特定领域嵌入 ${\mathbf{e}}_{i}^{gen}$ 的拼接，它作为输入被提供给一个批量归一化估计器网络 ${B}_{\text{gen }}^{l} : \mathcal{A} \times  \mathcal{D} \rightarrow  {\mathcal{R}}^{2 \times  h}(h$($l$ 是层 $l$ 激活向量的维度)，该网络为第 $l$ 层输出批量归一化参数 ${\gamma }_{gen}^{l}$ 和 ${\beta }_{gen}^{l}$。类似地，判别器的特征提取器 ${D}_{f}\left( \text{.}\right) {hasaseparateBatchNormestimator}$ 网络 ${B}_{\text{disc }}^{l} : \mathcal{D} \rightarrow  {\mathcal{R}}^{2 \times  h}$ 以实现其批量归一化参数 ${\gamma }_{\text{disc }}^{l},{\beta }_{\text{disc }}^{l}$ 的特定领域上下文调制，如图 2 所示。

Formally, let ${\mathbf{f}}_{\text{gen }}^{l}$ and ${\mathbf{f}}_{\text{disc }}^{l}$ denote feature activations belonging to domain $d$ and semantic attribute ${\mathbf{a}}_{y}^{s}$ , at $l$ -th layer of generator $G$ and discriminator $D$ respectively. We modulate ${\mathbf{f}}_{\text{gen }}^{l}$ and ${\mathbf{f}}_{\text{disc }}^{l}$ individually using Context Conditional Adaptive Batch-Normalization as follows:

形式上，设 ${\mathbf{f}}_{\text{gen }}^{l}$ 和 ${\mathbf{f}}_{\text{disc }}^{l}$ 分别表示属于域 $d$ 和语义属性 ${\mathbf{a}}_{y}^{s}$ 的特征激活，它们分别位于生成器 $G$ 和判别器 $D$ 的第 $l$ 层。我们使用上下文条件自适应批量归一化(Context Conditional Adaptive Batch - Normalization)分别对 ${\mathbf{f}}_{\text{gen }}^{l}$ 和 ${\mathbf{f}}_{\text{disc }}^{l}$ 进行调制，如下所示:

$$
{\gamma }_{\text{gen }}^{l},{\beta }_{\text{gen }}^{l} \leftarrow  {B}_{\text{gen }}^{l}\left( \mathbf{c}\right) \text{ where }\mathbf{c} = \left\lbrack  {{\mathbf{a}}_{y}^{s},{\mathbf{e}}_{d}^{\text{gen }}}\right\rbrack
$$

$$
{\mathbf{f}}_{gen}^{l + 1} \leftarrow  {\gamma }_{gen}^{l} \cdot  \frac{{\mathbf{f}}_{gen}^{l} - {\mu }_{gen}^{l}}{\sqrt{{\left( {\sigma }_{gen}^{l}\right) }^{2} + \epsilon }} + {\beta }_{gen}^{l} \tag{3}
$$

$$
{\gamma }_{\text{disc }}^{l},{\beta }_{\text{disc }}^{l} \leftarrow  {B}_{\text{disc }}^{l}\left( {\mathbf{e}}_{d}^{\text{disc }}\right)
$$

$$
{\mathbf{f}}_{\text{disc }}^{l + 1} \leftarrow  {\gamma }_{\text{disc }}^{l} \cdot  \frac{{\mathbf{f}}_{\text{disc }}^{l} - {\mu }_{\text{disc }}^{l}}{\sqrt{{\left( {\sigma }_{\text{disc }}^{l}\right) }^{2} + \epsilon }} + {\beta }_{\text{disc }}^{l}
$$

Here, $\left( {{\mu }_{\text{gen }}^{l},{\left( {\sigma }_{\text{gen }}^{l}\right) }^{2}}\right)$ and $\left( {{\mu }_{\text{disc }}^{l},{\left( {\sigma }_{\text{disc }}^{l}\right) }^{2}}\right)$ are the mean and variance of activations of the mini-batch (also used to update running statistics) containing ${\mathbf{f}}_{gen}^{l}$ and ${\mathbf{f}}_{disc}^{l}$ respectively. c denotes the context vector composed of semantic and domain embeddings and $\left\lbrack  {\cdot , \cdot  }\right\rbrack$ denotes the concatenation.

这里，$\left( {{\mu }_{\text{gen }}^{l},{\left( {\sigma }_{\text{gen }}^{l}\right) }^{2}}\right)$ 和 $\left( {{\mu }_{\text{disc }}^{l},{\left( {\sigma }_{\text{disc }}^{l}\right) }^{2}}\right)$ 分别是包含 ${\mathbf{f}}_{gen}^{l}$ 和 ${\mathbf{f}}_{disc}^{l}$ 的小批量激活的均值和方差(也用于更新运行统计信息)。c 表示由语义和域嵌入组成的上下文向量，$\left\lbrack  {\cdot , \cdot  }\right\rbrack$ 表示拼接操作。

Finally, the generator and discriminator are trained to optimize the adversarial loss given by:

最后，对生成器和判别器进行训练，以优化以下对抗损失:

$$
{\mathcal{L}}_{D} = {\mathbb{E}}_{\left( {\mathbf{x},{\mathbf{a}}_{y}^{s}, d}\right)  \sim  {S}^{Tr}}\left\lbrack  {\max \left( {0,1 - D\left( {f\left( \mathbf{x}\right) ,{\mathbf{a}}_{y}^{s},{\mathbf{e}}_{d}^{\text{disc }}}\right) }\right) }\right\rbrack   \tag{4}
$$

$$
+ {\mathbb{E}}_{y \sim  {\mathcal{Y}}^{s}, d \sim  {\mathcal{D}}^{s},\mathbf{z} \sim  \mathcal{Z}}\left\lbrack  {\max \left( {0,1 + D\left( {\widehat{\mathbf{f}},{\mathbf{a}}_{y}^{s},{\mathbf{e}}_{d}^{disc}}\right) }\right) }\right\rbrack
$$

$$
{\mathcal{L}}_{G} = {\mathbb{E}}_{y \sim  {\mathcal{Y}}^{s}, d \sim  {\mathcal{D}}^{s},\mathbf{z} \sim  \mathcal{Z}}\left\lbrack  {-D\left( {\widehat{\mathbf{f}},{\mathbf{a}}_{y}^{s},{\mathbf{e}}_{d}^{\text{disc }}}\right) }\right.  \tag{5}
$$

$$
+ {\lambda }_{G} \cdot  {\mathcal{L}}_{CE}\left( {{\mathbf{a}}^{T}p\left( \widehat{\mathbf{f}}\right) , y}\right) \rbrack
$$

where $D\left( {\mathbf{f},\mathbf{a},\mathbf{e}}\right)  = {\mathbf{a}}^{T}{D}_{f}\left( {\mathbf{f},\mathbf{e}}\right)  + {D}_{l}\left( {{D}_{f}\left( {\mathbf{f},\mathbf{e}}\right) }\right)$ is the projection term, $\widehat{\mathbf{f}} = G\left( {\mathbf{z},\mathbf{c}}\right)$ denotes generated feature. The second term, ${\mathcal{L}}_{CE}\left( {{\mathbf{a}}^{T}p\left( \widehat{\mathbf{f}}\right) , y}\right)$ in ${\mathcal{L}}_{G}$ ensures that the generated features have discriminative properties ( ${\lambda }_{G}$ is a hyper-parameter). $p\left( \text{.}\right) {isthesemanticprojectorthatwastrained}$ in the previous stage.

其中 $D\left( {\mathbf{f},\mathbf{a},\mathbf{e}}\right)  = {\mathbf{a}}^{T}{D}_{f}\left( {\mathbf{f},\mathbf{e}}\right)  + {D}_{l}\left( {{D}_{f}\left( {\mathbf{f},\mathbf{e}}\right) }\right)$ 是投影项，$\widehat{\mathbf{f}} = G\left( {\mathbf{z},\mathbf{c}}\right)$ 表示生成的特征。第二项，${\mathcal{L}}_{G}$ 中的 ${\mathcal{L}}_{CE}\left( {{\mathbf{a}}^{T}p\left( \widehat{\mathbf{f}}\right) , y}\right)$ 确保生成的特征具有判别性(${\lambda }_{G}$ 是一个超参数)。$p\left( \text{.}\right) {isthesemanticprojectorthatwastrained}$ 是前一阶段的内容。

### 3.4. Recognition and Inference

### 3.4. 识别与推理

In this section, we describe the training procedure of the classifier $\mathcal{C}$ and the inference mechanism for our proposed model. Given a generative network $G$ trained on the training set ${S}^{Tr}$ as described in Sec 3.3, we freeze the parameters of the generator and aim to synthesize visual features for unseen classes in different domains. To this end, we concatenate the domain embeddings ${\mathbf{e}}_{i}^{\text{gen }},(i \in$ ${\mathcal{D}}^{s}$ ) of the source domains from matrix ${\mathcal{E}}_{\text{gen }}$ (learned end-to-end with the generative model) and the semantic attributes/representations of unseen classes ${\mathbf{a}}_{y}^{u}$ to get the context vector $\mathbf{c}$ , which in turn is input to the trained batchnorm predictor network ${B}_{\text{gen }}^{l}$ . The output batchnorm parameters $\left( {{\gamma }_{gen}^{l},{\beta }_{gen}^{l}}\right)$ are used in the batchnorm layers of the pre-trained generator to generate features $\widehat{\mathbf{f}}$ . This enables us to generate features that are consistent with unseen class semantics and also encode domain information from individual source domains in the training set. After obtaining batch-norm parameters, the new set of unseen class features are generated as follows:

在本节中，我们描述分类器 $\mathcal{C}$ 的训练过程以及我们提出的模型的推理机制。给定一个在训练集 ${S}^{Tr}$ 上训练的生成网络 $G$(如 3.3 节所述)，我们冻结生成器的参数，并旨在为不同域中的未见类别合成视觉特征。为此，我们将矩阵 ${\mathcal{E}}_{\text{gen }}$(与生成模型端到端学习得到)中源域的域嵌入 ${\mathbf{e}}_{i}^{\text{gen }},(i \in$ ${\mathcal{D}}^{s}$)和未见类别的语义属性/表示 ${\mathbf{a}}_{y}^{u}$ 进行拼接，以得到上下文向量 $\mathbf{c}$，该向量又被输入到训练好的批量归一化预测网络 ${B}_{\text{gen }}^{l}$ 中。输出的批量归一化参数 $\left( {{\gamma }_{gen}^{l},{\beta }_{gen}^{l}}\right)$ 用于预训练生成器的批量归一化层，以生成特征 $\widehat{\mathbf{f}}$。这使我们能够生成与未见类别语义一致且还能编码训练集中各个源域的域信息的特征。在获得批量归一化参数后，新的未见类别特征集按如下方式生成:

$$
{\widehat{\mathbf{f}}}_{n} = G\left( {{\mathbf{z}}_{n},\mathbf{c}}\right)  \tag{6}
$$

$$
\text{where}\mathbf{c} = \left\lbrack  {{\mathbf{a}}_{{y}_{n}}^{u},{\mathbf{e}}_{n}^{gen}}\right\rbrack  ,{\mathbf{z}}_{n} \sim  \mathcal{Z},{y}_{n} \sim  {\mathcal{Y}}^{u},{\mathbf{e}}_{n}^{gen} \sim  {\mathcal{E}}_{\text{gen }}
$$

To improve generalization to new domains at test-time and make the classifier domain-agnostic, we synthesize em-beddings of newer domains by interpolating the learned em-beddings of the source domains via a mix-up operation.

为了在测试时提高对新域的泛化能力并使分类器与域无关，我们通过混合操作(mix - up operation)对源域的学习嵌入进行插值，以合成新域的嵌入。

$$
{\mathcal{E}}_{\text{interp }}^{\text{gen }} = \lambda  \cdot  {\mathbf{e}}_{i}^{\text{gen }} + \left( {1 - \lambda }\right)  \cdot  {\mathbf{e}}_{j}^{\text{gen }}\text{ where }i, j \sim  {\mathcal{D}}^{s},\lambda  \sim  \mathcal{U}\left\lbrack  {0,1}\right\rbrack
$$

(7)

where ${\mathbf{e}}_{i}^{\text{gen }}$ and ${\mathbf{e}}_{j}^{\text{gen }}$ refer to the domain embeddings of $i$ -th and $j$ -th source domains. The unseen class features generated using interpolated domain embeddings ${\mathcal{F}}_{\text{int }}^{u} =$ ${\left\{  \left( {\widehat{\mathbf{f}}}_{int}^{n},{y}_{n}\right) \right\}  }_{n = 1}^{N}$ are generated as follows:

其中 ${\mathbf{e}}_{i}^{\text{gen }}$ 和 ${\mathbf{e}}_{j}^{\text{gen }}$ 分别指第 $i$ 个和第 $j$ 个源域的域嵌入。使用插值域嵌入 ${\mathcal{F}}_{\text{int }}^{u} =$ ${\left\{  \left( {\widehat{\mathbf{f}}}_{int}^{n},{y}_{n}\right) \right\}  }_{n = 1}^{N}$ 生成的未见类特征如下所示:

$$
{\widehat{\mathbf{f}}}_{\text{int }}^{n} = G\left( {{\mathbf{z}}_{n},{\mathbf{c}}_{\text{interp. }}}\right) \text{ where }{\mathbf{c}}_{\text{interp. }} = \left\lbrack  {{\mathbf{a}}_{{y}_{n}}^{u},{\mathbf{e}}_{\text{interp. }}^{\text{gen }}}\right\rbrack  , \tag{8}
$$

$$
{\mathbf{z}}_{n} \sim  \mathcal{Z},{y}_{n} \sim  {\mathcal{Y}}^{u},{\mathbf{e}}_{\text{interp }}^{\text{gen }} \sim  {\mathcal{E}}_{\text{interp }}^{\text{gen }}
$$

Next, we train a MLP softmax classifier, $\mathcal{C}\left( \text{.}\right) {onthegen} -$ erated multi-domain unseen class features dataset ${\mathcal{F}}_{\text{int }}^{u}$ by minimizing:

接下来，我们训练一个多层感知机(MLP)softmax分类器 $\mathcal{C}\left( \text{.}\right) {onthegen} -$ ，通过最小化以下目标函数来处理生成的多域未见类特征数据集 ${\mathcal{F}}_{\text{int }}^{u}$ :

$$
{\mathcal{L}}_{CLS} = {\mathbb{E}}_{\left( {{\widehat{\mathbf{f}}}_{int}, y}\right)  \sim  {\mathcal{F}}_{int}^{u}}\left\lbrack  {{\mathcal{L}}_{CE}\left( {\mathcal{C}\left( {\widehat{\mathbf{f}}}_{int}\right) , y}\right) }\right\rbrack   \tag{9}
$$

Classifying image at test time. At test-time, given a test image ${\mathbf{x}}_{\text{test }}$ , we first pass it through the visual encoder $f\left( \text{.}\right) {togetheadiscriminativefeature\ representation}$ ${\mathbf{f}}_{\text{test }} = f\left( \mathbf{x}\right)$ . Next we pass this feature representation to the classifier to get the final prediction.

测试时对图像进行分类。在测试阶段，给定一个测试图像 ${\mathbf{x}}_{\text{test }}$ ，我们首先将其输入视觉编码器 $f\left( \text{.}\right) {togetheadiscriminativefeature\ representation}$ ${\mathbf{f}}_{\text{test }} = f\left( \mathbf{x}\right)$ 。然后，我们将这个特征表示输入分类器以得到最终预测结果。

$$
\widehat{y} = \arg \mathop{\max }\limits_{{y \in  {\mathcal{Y}}^{u}}}\mathcal{C}\left( {\mathbf{f}}_{\text{test }}\right) \left\lbrack  y\right\rbrack   \tag{10}
$$

## 4. Experiments and Results

## 4. 实验与结果

In this section, we describe the experimental setup and validate the performance of our proposed methodology with previously proposed baselines and models addressing the problem of ZSLDG.

在本节中，我们描述实验设置，并将我们提出的方法的性能与之前提出的解决零样本跨域学习(ZSLDG)问题的基线方法和模型进行验证比较。

Datasets: We evaluate our method with all baselines on the DomainNet and DomainNet-LS benchmark datasets, described briefly below. In the Appendix, we provide description and first results on a newer dataset - CUB-Corruptions

数据集:我们在DomainNet和DomainNet - LS基准数据集上，将我们的方法与所有基线方法进行评估，下面简要介绍这些数据集。在附录中，我们提供了一个较新的数据集——CUB - Corruptions的描述和初步结果。

DomainNet: Recently, [27] proposed DomainNet dataset as a benchmark for the ZSLDG problem setting. Domain-Net is a diverse large-scale coarse-grained dataset and currently the established benchmark for the ZSLDG problem setting [27]. Originally proposed for domain adaptation [37], DomainNet is a dataset with 0.6 million images belonging to 345 different categories divided into 6 different domains i.e painting, real, clipart, infograph, quick-draw and sketch. The infograph and quickdraw domains are considered harder to generalize to, since they involve the most evident domain-shift at test time. We follow the seen-unseen class training-testing splits and protocol as established in [27] where we train on 5 domains and test on the left-out domain. We consider each domain as target domain individually through a separate experiment and report average unseen classification accuracy over all such experiments. Also, following [27], we use word2vec representations [29] as the semantic representations for class labels.

DomainNet:最近，文献[27]提出了DomainNet数据集，作为零样本跨域学习(ZSLDG)问题设置的基准。DomainNet是一个多样化的大规模粗粒度数据集，目前是ZSLDG问题设置的既定基准[27]。最初为域适应问题提出[37]，DomainNet包含60万张图像，属于345个不同类别，分为6个不同的域，即绘画、真实图像、剪贴画、信息图、简笔画和素描。信息图和简笔画域被认为更难进行泛化，因为在测试时它们涉及最明显的域偏移。我们遵循文献[27]中建立的可见 - 未见类训练 - 测试划分和协议，在5个域上进行训练，并在留出的域上进行测试。我们通过单独的实验将每个域单独作为目标域，并报告所有此类实验的平均未见类分类准确率。此外，遵循文献[27]，我们使用词向量(word2vec)表示[29]作为类标签的语义表示。

DomainNet-LS: This benchmark, also established in [27], refers to the setting where source domains are limited to only real and painting domains. Compared to DomainNet, this is a more challenging setting since the model may overfit to the fewer source domains [25], thus making it difficult to learn generalizable domain-invariant features.

DomainNet - LS:这个基准也是在文献[27]中建立的，指的是源域仅限于真实图像和绘画域的设置。与DomainNet相比，这是一个更具挑战性的设置，因为模型可能会对较少的源域过拟合[25]，从而难以学习可泛化的域不变特征。

Baselines. For a comprehensive evaluation, we compare our approach with the following set of baselines which include simpler baselines derived from standard ZSL/DG literature (following recent work in ZSLDG [27]) as well as the recent ZSLDG methods.

基线方法。为了进行全面评估，我们将我们的方法与以下一组基线方法进行比较，其中包括从标准零样本学习(ZSL)/域泛化(DG)文献中衍生出的较简单的基线方法(遵循ZSLDG领域的近期工作[27])以及近期的ZSLDG方法。

- Simpler baselines include ZSL methods like SPNet [51], DeViSE [13], ALE [1] and their coupling with well-known DG methods (DANN [14], EpiFCR [24]) (as in [27]).

- 较简单的基线方法包括零样本学习方法，如SPNet[51]、DeViSE[13]、ALE[1]，以及它们与知名的域泛化方法(DANN[14]、EpiFCR[24])的结合(如文献[27]中所述)。

- State-of-the-art ZSLDG method, CuMix [27] as well as its variants: (1) Mixup-img-only where mixup is done only at image level without curriculum; (2) Mixup-two-level where mixup is applied at both feature and image level without curriculum; (3) CuMix-reverse where the curriculum strategy is applied but the order of semantic and domain mixing is switched.

- 最先进的ZSLDG方法CuMix[27]及其变体:(1)仅图像混合(Mixup - img - only)，即仅在图像级别进行混合而不使用课程学习策略；(2)两级混合(Mixup - two - level)，即在特征和图像级别都应用混合而不使用课程学习策略；(3)反向CuMix(CuMix - reverse)，即应用课程学习策略，但语义和域混合的顺序相反。

- Feature generation baselines which include f-clsWGAN [52] (standard ZSL only approach) and its combination with visual backbone trained using AGG (Equation 1) objective (called ${AGG} + f$ -cls ${WGAN}$ ), as well as CuMix [27] methodology (CuMix + f-clsWGAN) and self-supervised rotation [16] feature extraction method $\left( {{ROT} + f - {clsWGAN}}\right)$ .

- 特征生成基线方法，包括f - clsWGAN[52](仅标准零样本学习方法)及其与使用聚合(AGG)目标(公式1)训练的视觉骨干网络的组合(称为 ${AGG} + f$ - cls ${WGAN}$ )，以及CuMix[27]方法(CuMix + f - clsWGAN)和自监督旋转[16]特征提取方法 $\left( {{ROT} + f - {clsWGAN}}\right)$ 。

Note that our proposed approach can be seamlessly integrated into other generative ZSL frameworks, which we leave for future work.

请注意，我们提出的方法可以无缝集成到其他生成式零样本学习框架中，我们将此留作未来工作。

Implementation Details Due to space constraints, we describe the implementation details and hyperparameter settings for our method in the Appendix.

实现细节 由于篇幅限制，我们在附录中描述我们方法的实现细节和超参数设置。

Results on DomainNet Benchmark. Table 1 shows the performance comparison of our method with the aforementioned baselines. We observe that a simple classification-based feature extraction (using only ${\mathcal{L}}_{\mathcal{{AGG}}}$ ) without any regularization when coupled with our generative module i.e ${COCO}{A}_{AGG}$ is able to outperform the current state-of-the-art, CuMix [27]. In addition, when we use rotation prediction as a a regularizing auxiliary task [16] (referred as ${COCOA}_{ROT}$ ), we observe that it achieves the best performance on all domains individually as well as on average (with significant improvement especially on hard domains like quickdraw where there is large domain shift encountered at test-time), thus outperforming [27] by a margin of about $2\%$ average across domains (which corresponds to a $\sim  9\%$ relative increase). We believe this is because the auxiliary task enables better representation learning. More analysis with other regularizers is shown later in the paper.

DomainNet基准测试结果。表1展示了我们的方法与上述基线方法的性能对比。我们发现，一个简单的基于分类的特征提取方法(仅使用${\mathcal{L}}_{\mathcal{{AGG}}}$)，在不进行任何正则化的情况下，与我们的生成模块即${COCO}{A}_{AGG}$结合后，能够超越当前的最先进方法CuMix [27]。此外，当我们使用旋转预测作为一种正则化辅助任务[16](称为${COCOA}_{ROT}$)时，我们发现它在各个领域以及平均水平上都取得了最佳性能(尤其是在像QuickDraw这样的困难领域，在测试时会遇到较大的领域偏移，有显著的改进)，因此在各个领域的平均性能上比[27]高出约$2\%$(相当于相对提升了$\sim  9\%$)。我们认为这是因为辅助任务能够实现更好的表示学习。本文后面将展示使用其他正则化器的更多分析。

Utilizing generative ZSL baselines as it is provides suboptimal generalization performance for the harder ZSLDG problem setting. Also, we observe that combining such generative ZSL frameworks (which generate features with only class level semantics) with different visual backbones including CuMix results in inferior average performance when compared with our approach.

直接使用生成式零样本学习(ZSL)基线方法，对于更具挑战性的零样本领域泛化(ZSLDG)问题设置而言，泛化性能欠佳。此外，我们发现，将此类生成式ZSL框架(仅生成具有类别级语义的特征)与包括CuMix在内的不同视觉骨干网络相结合，与我们的方法相比，平均性能较差。

Results on DomainNet-LS Benchmark. Table 2 shows the individual domain and average performance of our method and baselines on this limited-source setting. We observe that even in this challenging setting, our method outperform [27] by a margin of $\sim  {0.5}\%$ average across all domains (corresponds to $\sim  3\%$ relative improvement).

DomainNet - LS基准测试结果。表2展示了在这种有限源设置下，我们的方法和基线方法在各个领域的性能以及平均性能。我们发现，即使在这种具有挑战性的设置下，我们的方法在所有领域的平均性能上比[27]高出$\sim  {0.5}\%$(相当于相对提升了$\sim  3\%$)。

Evaluation on Corrupted-CUB benchmark, Standard DG and ZSL settings: Owing to space constraints, we report the results of our method on Corrupted-CUB (a newly introduced dataset for ZSLDG), standard ZSL and DG benchmarks in the Appendix.

在Corrupted - CUB基准测试、标准领域泛化(DG)和零样本学习(ZSL)设置下的评估:由于篇幅限制，我们在附录中报告了我们的方法在Corrupted - CUB(一个新引入的用于ZSLDG的数据集)、标准ZSL和DG基准测试上的结果。

Component-wise Ablation Study. Table 3 shows the component-wise performance for our method. We use the DomainNet dataset [27] and rotation-based self-supervision regularization for this study.

组件级消融研究。表3展示了我们方法的组件级性能。我们使用DomainNet数据集[27]和基于旋转的自监督正则化进行这项研究。

- ${S1}$ corresponds to the performance of the feature extractor $f\left( \text{.}\right) {trainedusingusingrotationpredictionasaregu-}$ larizer (without generative stage 2).

- ${S1}$对应于特征提取器$f\left( \text{.}\right) {trainedusingusingrotationpredictionasaregu-}$正则化器(不使用生成阶段2)的性能。

- ${S2}$ corresponds to the performance achieved by learning a generator $G$ without using domain embeddings as an input. Specifically, this implies that the BatchNorm estimator networks ${B}_{gen}^{l}$ is given only the class-level semantic attribute as input i.e context vector $\mathbf{c} = {\mathbf{a}}_{y}^{s}$ .

- ${S2}$对应于在不使用领域嵌入作为输入的情况下学习生成器$G$所取得的性能。具体而言，这意味着批量归一化(BatchNorm)估计器网络${B}_{gen}^{l}$仅以类别级语义属性作为输入，即上下文向量$\mathbf{c} = {\mathbf{a}}_{y}^{s}$。

- ${S3}$ denotes the use of ${S2}$ , with domain embeddings as an additional input in the context vector provided to ${B}_{\text{gen }}^{l}$ i.e $\mathbf{c} = \left\lbrack  {{\mathbf{a}}_{y}^{s},{\mathbf{e}}_{d}^{\text{gen }}}\right\rbrack$ . Note that both ${S2}$ and ${S3}$ follow the inference mechanism described in Sec 3.4 using domain embeddings ${\mathcal{E}}_{\text{gen }}$ , without the use of interpolated domain embeddings ${\mathcal{E}}_{\text{interp }}^{\text{gen }}$ (Eqn 6)

- ${S3}$表示使用${S2}$，并将领域嵌入作为额外输入添加到提供给${B}_{\text{gen }}^{l}$的上下文向量中，即$\mathbf{c} = \left\lbrack  {{\mathbf{a}}_{y}^{s},{\mathbf{e}}_{d}^{\text{gen }}}\right\rbrack$。请注意，${S2}$和${S3}$都遵循第3.4节中描述的使用领域嵌入${\mathcal{E}}_{\text{gen }}$的推理机制，不使用插值领域嵌入${\mathcal{E}}_{\text{interp }}^{\text{gen }}$(公式6)

- Lastly, ${S4}$ denotes our complete model, where we train the final classifier also on features generated by using interpolated domain embeddings ${\mathcal{E}}_{\text{interp }}^{\text{gen }}(\left( {\text{Eqn }8}\right)$ .

- 最后，${S4}$表示我们的完整模型，在该模型中，我们还使用插值领域嵌入${\mathcal{E}}_{\text{interp }}^{\text{gen }}(\left( {\text{Eqn }8}\right)$生成的特征来训练最终分类器。

<table><tr><td colspan="2">$\mathbf{{Method}}$</td><td colspan="5">Target Domain</td><td/></tr><tr><td>DG</td><td>ZSL</td><td>clipart</td><td>infograph</td><td>painting</td><td>quickdraw</td><td>sketch</td><td>Avg.</td></tr><tr><td rowspan="3">-</td><td>DEVISE [13]</td><td>20.1</td><td>11.7</td><td>17.6</td><td>6.1</td><td>16.7</td><td>14.4</td></tr><tr><td>ALE [1]</td><td>22.7</td><td>12.7</td><td>20.2</td><td>6.8</td><td>18.5</td><td>16.2</td></tr><tr><td>SPNet [51]</td><td>26.0</td><td>16.9</td><td>23.8</td><td>8.2</td><td>21.8</td><td>19.4</td></tr><tr><td rowspan="3">DANN [14]</td><td>DEVISE [13]</td><td>20.5</td><td>10.4</td><td>16.4</td><td>7.1</td><td>15.1</td><td>13.9</td></tr><tr><td>ALE [1]</td><td>21.2</td><td>12.5</td><td>19.7</td><td>7.4</td><td>17.9</td><td>15.7</td></tr><tr><td>SPNet [51]</td><td>25.9</td><td>15.8</td><td>24.1</td><td>8.4</td><td>21.3</td><td>19.1</td></tr><tr><td rowspan="3">EpiFCR [24]</td><td>DEVISE [13]</td><td>21.6</td><td>13.9</td><td>19.3</td><td>7.3</td><td>17.2</td><td>15.9</td></tr><tr><td>ALE [1]</td><td>23.2</td><td>14.1</td><td>21.4</td><td>7.8</td><td>20.9</td><td>17.5</td></tr><tr><td>SPNet [51]</td><td>26.4</td><td>16.7</td><td>24.6</td><td>9.2</td><td>23.2</td><td>20.0</td></tr><tr><td colspan="2">Mixup-img-only</td><td>25.2</td><td>16.3</td><td>24.4</td><td>8.7</td><td>21.7</td><td>19.2</td></tr><tr><td colspan="2">Mixup-two-level</td><td>26.6</td><td>17</td><td>25.3</td><td>8.8</td><td>21.9</td><td>19.9</td></tr><tr><td colspan="2">CuMix[27]</td><td>27.6</td><td>17.8</td><td>25.5</td><td>9.9</td><td>22.6</td><td>20.7</td></tr><tr><td colspan="2">f-clsWGAN [52]</td><td>20.0</td><td>13.3</td><td>20.5</td><td>6.6</td><td>14.9</td><td>15.1</td></tr><tr><td colspan="2">AGG + f-clsWGAN</td><td>27.4</td><td>17.0</td><td>25.9</td><td>11.0</td><td>23.8</td><td>21.0</td></tr><tr><td colspan="2">CuMix + f-clsWGAN</td><td>27.3</td><td>17.9</td><td>26.5</td><td>11.2</td><td>24.8</td><td>21.5</td></tr><tr><td colspan="2">ROT + f-clsWGAN</td><td>27.5</td><td>17.4</td><td>26.4</td><td>11.4</td><td>24.6</td><td>21.4</td></tr><tr><td colspan="2">${\mathrm{{COCOA}}}_{AGG}$</td><td>27.6</td><td>17.1</td><td>25.7</td><td>11.8</td><td>23.7</td><td>21.2</td></tr><tr><td colspan="2">${COCOA}_{ROT}$</td><td>28.9</td><td>18.2</td><td>27.1</td><td>13.1</td><td>25.7</td><td>22.6</td></tr></table>

<table><tbody><tr><td colspan="2">$\mathbf{{Method}}$</td><td colspan="5">目标领域</td><td></td></tr><tr><td>DG(域泛化，Domain Generalization)</td><td>ZSL(零样本学习，Zero-Shot Learning)</td><td>剪贴画</td><td>信息图</td><td>绘画</td><td>快速绘图</td><td>素描</td><td>平均值</td></tr><tr><td rowspan="3">-</td><td>DEVISE [13](原文未明确其具体含义，保留英文)</td><td>20.1</td><td>11.7</td><td>17.6</td><td>6.1</td><td>16.7</td><td>14.4</td></tr><tr><td>ALE [1](原文未明确其具体含义，保留英文)</td><td>22.7</td><td>12.7</td><td>20.2</td><td>6.8</td><td>18.5</td><td>16.2</td></tr><tr><td>SPNet [51](原文未明确其具体含义，保留英文)</td><td>26.0</td><td>16.9</td><td>23.8</td><td>8.2</td><td>21.8</td><td>19.4</td></tr><tr><td rowspan="3">DANN [14](原文未明确其具体含义，保留英文)</td><td>DEVISE [13](原文未明确其具体含义，保留英文)</td><td>20.5</td><td>10.4</td><td>16.4</td><td>7.1</td><td>15.1</td><td>13.9</td></tr><tr><td>ALE [1](原文未明确其具体含义，保留英文)</td><td>21.2</td><td>12.5</td><td>19.7</td><td>7.4</td><td>17.9</td><td>15.7</td></tr><tr><td>SPNet [51](原文未明确其具体含义，保留英文)</td><td>25.9</td><td>15.8</td><td>24.1</td><td>8.4</td><td>21.3</td><td>19.1</td></tr><tr><td rowspan="3">EpiFCR [24](原文未明确其具体含义，保留英文)</td><td>DEVISE [13](原文未明确其具体含义，保留英文)</td><td>21.6</td><td>13.9</td><td>19.3</td><td>7.3</td><td>17.2</td><td>15.9</td></tr><tr><td>ALE [1](原文未明确其具体含义，保留英文)</td><td>23.2</td><td>14.1</td><td>21.4</td><td>7.8</td><td>20.9</td><td>17.5</td></tr><tr><td>SPNet [51](原文未明确其具体含义，保留英文)</td><td>26.4</td><td>16.7</td><td>24.6</td><td>9.2</td><td>23.2</td><td>20.0</td></tr><tr><td colspan="2">仅图像混合(Mixup-img-only)</td><td>25.2</td><td>16.3</td><td>24.4</td><td>8.7</td><td>21.7</td><td>19.2</td></tr><tr><td colspan="2">两级混合(Mixup-two-level)</td><td>26.6</td><td>17</td><td>25.3</td><td>8.8</td><td>21.9</td><td>19.9</td></tr><tr><td colspan="2">CuMix[27](原文未明确其具体含义，保留英文)</td><td>27.6</td><td>17.8</td><td>25.5</td><td>9.9</td><td>22.6</td><td>20.7</td></tr><tr><td colspan="2">f-clsWGAN [52](原文未明确其具体含义，保留英文)</td><td>20.0</td><td>13.3</td><td>20.5</td><td>6.6</td><td>14.9</td><td>15.1</td></tr><tr><td colspan="2">AGG + f-clsWGAN(原文未明确其具体含义，保留英文)</td><td>27.4</td><td>17.0</td><td>25.9</td><td>11.0</td><td>23.8</td><td>21.0</td></tr><tr><td colspan="2">CuMix + f-clsWGAN(原文未明确其具体含义，保留英文)</td><td>27.3</td><td>17.9</td><td>26.5</td><td>11.2</td><td>24.8</td><td>21.5</td></tr><tr><td colspan="2">ROT + f-clsWGAN(原文未明确其具体含义，保留英文)</td><td>27.5</td><td>17.4</td><td>26.4</td><td>11.4</td><td>24.6</td><td>21.4</td></tr><tr><td colspan="2">${\mathrm{{COCOA}}}_{AGG}$</td><td>27.6</td><td>17.1</td><td>25.7</td><td>11.8</td><td>23.7</td><td>21.2</td></tr><tr><td colspan="2">${COCOA}_{ROT}$</td><td>28.9</td><td>18.2</td><td>27.1</td><td>13.1</td><td>25.7</td><td>22.6</td></tr></tbody></table>

Table 1. Performance comparison with established baselines and state-of-art methods for ZSLDG problem setting scenario on benchmark DomainNet dataset. We report performance on individual domains as well as average performance. For fair comparison, all reported results follow the backbones, protocol and splits as established in [27]. Best results are highlighted in bold and second best results are underlined

表1. 在基准DomainNet数据集上针对零样本领域泛化(ZSLDG)问题设置场景与已有的基线方法和最先进方法的性能比较。我们报告了各个领域的性能以及平均性能。为了进行公平比较，所有报告的结果均遵循文献[27]中确立的骨干网络、协议和划分方式。最佳结果以粗体突出显示，次佳结果以下划线标注

<table><tr><td>$\mathbf{{Method}}$</td><td>Clipart</td><td>Infograph</td><td>Quickdraw</td><td>Sketch</td><td>Avg</td></tr><tr><td>SPNet</td><td>21.5</td><td>14.1</td><td>4.8</td><td>17.3</td><td>14.4</td></tr><tr><td>Epi-FCR + SPNet</td><td>22.5</td><td>14.9</td><td>5.6</td><td>18.7</td><td>15.4</td></tr><tr><td>MixUp img only</td><td>21.2</td><td>14.0</td><td>4.8</td><td>17.3</td><td>14.3</td></tr><tr><td>MixUp two-level</td><td>22.7</td><td>16.5</td><td>4.9</td><td>19.1</td><td>15.8</td></tr><tr><td>CuMix reverse</td><td>22.9</td><td>15.8</td><td>4.8</td><td>18.2</td><td>15.4</td></tr><tr><td>CuMix</td><td>23.7</td><td>17.1</td><td>5.5</td><td>19.7</td><td>16.5</td></tr><tr><td>${\mathrm{{COCOA}}}_{AGG}$</td><td>23.8</td><td>15.6</td><td>6.7</td><td>20.1</td><td>16.55</td></tr><tr><td>${\mathrm{{COCOA}}}_{ROT}$</td><td>23.82</td><td>15.9</td><td>7.3</td><td>20.75</td><td>16.94</td></tr></table>

<table><tbody><tr><td>$\mathbf{{Method}}$</td><td>剪贴画</td><td>信息图</td><td>快速绘图</td><td>草图</td><td>平均值</td></tr><tr><td>SP网络(SPNet)</td><td>21.5</td><td>14.1</td><td>4.8</td><td>17.3</td><td>14.4</td></tr><tr><td>流行病快速分类回归器 + SP网络(Epi-FCR + SPNet)</td><td>22.5</td><td>14.9</td><td>5.6</td><td>18.7</td><td>15.4</td></tr><tr><td>仅图像混合增强(MixUp img only)</td><td>21.2</td><td>14.0</td><td>4.8</td><td>17.3</td><td>14.3</td></tr><tr><td>两级混合增强(MixUp two-level)</td><td>22.7</td><td>16.5</td><td>4.9</td><td>19.1</td><td>15.8</td></tr><tr><td>反向Cu混合增强(CuMix reverse)</td><td>22.9</td><td>15.8</td><td>4.8</td><td>18.2</td><td>15.4</td></tr><tr><td>Cu混合增强(CuMix)</td><td>23.7</td><td>17.1</td><td>5.5</td><td>19.7</td><td>16.5</td></tr><tr><td>${\mathrm{{COCOA}}}_{AGG}$</td><td>23.8</td><td>15.6</td><td>6.7</td><td>20.1</td><td>16.55</td></tr><tr><td>${\mathrm{{COCOA}}}_{ROT}$</td><td>23.82</td><td>15.9</td><td>7.3</td><td>20.75</td><td>16.94</td></tr></tbody></table>

Table 2. ZSLDG performance comparison with state-of-art methods on DomainNet-LS setting. For fair comparison, all reported results follow the protocol and splits as established in [27]. Best results are highlighted in bold and second best results are underlined.

表2. 在DomainNet-LS设置下，ZSLDG与最先进方法的性能比较。为进行公平比较，所有报告的结果均遵循文献[27]中确立的协议和划分方式。最佳结果以粗体突出显示，次佳结果加下划线标注。

From Table 3, we infer that learning a generative network and training final classifier $C\left( \text{.}\right) {onsynthesizedunseenclass}$ features (i.e. ${S2}$ ) brings significant improvement in the average performance when compared with standalone feature extractor-based pipeline ${S1}$ . Also, we observe that modulating the intermediate features in the generative network with batchnorm parameters conditioned on both domain and semantic embeddings (i.e ${S3}$ ) improves performance on all domains individually as well as enhances average performance when compared with only semantic embeddings-based context in ${S2}$ . This corroborates our hypothesis that conditioning on both domain and semantic embeddings enables the classifier to discriminate between the distribution of features $\mathbf{f}$ better by encoding both domain-specific and class-level information in generated features $\widehat{\mathbf{f}}$ (we discuss this further via feature visualization as well). Furthermore, interpolating source domain embeddings to get new domain representations and training the final classifier using features generated by these interpolated domain embeddings ${S4}$ further improves performance by alleviating the bias towards source domains and enhancing the generalization capabilities of the model.

从表3中我们推断，与基于独立特征提取器的流程${S1}$相比，学习生成网络并使用$C\left( \text{.}\right) {onsynthesizedunseenclass}$特征(即${S2}$)训练最终分类器在平均性能上有显著提升。此外，我们观察到，在生成网络中使用基于领域和语义嵌入的批量归一化参数来调制中间特征(即${S3}$)，与仅基于语义嵌入上下文的${S2}$相比，不仅能提高各个领域的性能，还能提升平均性能。这证实了我们的假设，即基于领域和语义嵌入进行条件设定，能够通过在生成的特征$\widehat{\mathbf{f}}$中编码特定领域和类别级别的信息，使分类器更好地区分特征$\mathbf{f}$的分布(我们也会通过特征可视化进一步讨论这一点)。此外，对源领域嵌入进行插值以获得新的领域表示，并使用这些插值后的领域嵌入生成的特征${S4}$训练最终分类器，通过减轻对源领域的偏差并增强模型的泛化能力，进一步提高了性能。

<table><tr><td>Variant</td><td>Clipart</td><td>Infograph</td><td>Painting</td><td>Quickdraw</td><td>Sketch</td><td>Avg</td></tr><tr><td>${S1}$</td><td>27.5</td><td>17.8</td><td>25.4</td><td>9.5 7</td><td>22.5</td><td>20.54</td></tr><tr><td>${S2}$</td><td>27.67</td><td>17.36</td><td>27.08</td><td>11.57</td><td>24.97</td><td>21.716</td></tr><tr><td>${S3}$</td><td>28.5</td><td>17.6</td><td>26.8</td><td>12.7</td><td>25.48</td><td>22.2</td></tr><tr><td>${S4}$</td><td>28.9</td><td>18.2</td><td>27.1</td><td>13.1</td><td>25.7</td><td>22.6</td></tr></table>

<table><tbody><tr><td>变体(Variant)</td><td>剪贴画(Clipart)</td><td>信息图(Infograph)</td><td>绘画(Painting)</td><td>快速绘图(Quickdraw)</td><td>素描(Sketch)</td><td>平均值(Avg)</td></tr><tr><td>${S1}$</td><td>27.5</td><td>17.8</td><td>25.4</td><td>9.5 7</td><td>22.5</td><td>20.54</td></tr><tr><td>${S2}$</td><td>27.67</td><td>17.36</td><td>27.08</td><td>11.57</td><td>24.97</td><td>21.716</td></tr><tr><td>${S3}$</td><td>28.5</td><td>17.6</td><td>26.8</td><td>12.7</td><td>25.48</td><td>22.2</td></tr><tr><td>${S4}$</td><td>28.9</td><td>18.2</td><td>27.1</td><td>13.1</td><td>25.7</td><td>22.6</td></tr></tbody></table>

Table 3. Ablation study for different components of our framework on DomainNet dataset

表3. 我们的框架不同组件在DomainNet数据集上的消融研究

<table><tr><td>Fusion</td><td>Input</td><td>$\mathbf{{BN}}$</td><td>Clipart</td><td>Infograph</td><td>Painting</td><td>Quickdraw</td><td>Sketch</td><td>Avg</td></tr><tr><td>F1</td><td>$\left\lbrack  {\mathbf{z},{\mathbf{a}}_{y},{\mathbf{e}}^{gen}}\right\rbrack$</td><td>-</td><td>27.75</td><td>14.77</td><td>23.93</td><td>10.79</td><td>25.31</td><td>20.51</td></tr><tr><td>F2</td><td>$\mathbf{z} + \left\lbrack  {{\mathbf{a}}_{y},{\mathbf{e}}^{gen}}\right\rbrack$</td><td>-</td><td>28.23</td><td>14.99</td><td>24.34</td><td>10.0</td><td>23.47</td><td>20.2</td></tr><tr><td>F3</td><td>$\mathbf{z} + {\mathbf{a}}_{y}$</td><td>-</td><td>24.87</td><td>16.09</td><td>23.52</td><td>11.85</td><td>22.89</td><td>19.84</td></tr><tr><td>F4</td><td>$\left\lbrack  {\mathbf{z},{\mathbf{a}}_{y}}\right\rbrack$</td><td>${\mathrm{e}}^{gen}$</td><td>26.56</td><td>16.9</td><td>24.89</td><td>13.0</td><td>24.9</td><td>21.25</td></tr><tr><td>F5</td><td>$\mathbf{z} + {\mathbf{a}}_{y}$</td><td>${\mathrm{e}}^{gen}$</td><td>27.74</td><td>16.19</td><td>26.38</td><td>11.04</td><td>24.13</td><td>21.1</td></tr><tr><td>F6</td><td>$\mathbf{z}$</td><td>$\left\lbrack  {{\mathbf{a}}_{y},{\mathbf{e}}^{gen}}\right\rbrack$</td><td>28.9</td><td>18.2</td><td>27.1</td><td>13.1</td><td>25.7</td><td>22.6</td></tr></table>

<table><tbody><tr><td>融合(Fusion)</td><td>输入(Input)</td><td>$\mathbf{{BN}}$</td><td>剪贴画(Clipart)</td><td>信息图(Infograph)</td><td>绘画(Painting)</td><td>快速绘图(Quickdraw)</td><td>素描(Sketch)</td><td>平均值(Avg)</td></tr><tr><td>F1</td><td>$\left\lbrack  {\mathbf{z},{\mathbf{a}}_{y},{\mathbf{e}}^{gen}}\right\rbrack$</td><td>-</td><td>27.75</td><td>14.77</td><td>23.93</td><td>10.79</td><td>25.31</td><td>20.51</td></tr><tr><td>F2</td><td>$\mathbf{z} + \left\lbrack  {{\mathbf{a}}_{y},{\mathbf{e}}^{gen}}\right\rbrack$</td><td>-</td><td>28.23</td><td>14.99</td><td>24.34</td><td>10.0</td><td>23.47</td><td>20.2</td></tr><tr><td>F3</td><td>$\mathbf{z} + {\mathbf{a}}_{y}$</td><td>-</td><td>24.87</td><td>16.09</td><td>23.52</td><td>11.85</td><td>22.89</td><td>19.84</td></tr><tr><td>F4</td><td>$\left\lbrack  {\mathbf{z},{\mathbf{a}}_{y}}\right\rbrack$</td><td>${\mathrm{e}}^{gen}$</td><td>26.56</td><td>16.9</td><td>24.89</td><td>13.0</td><td>24.9</td><td>21.25</td></tr><tr><td>F5</td><td>$\mathbf{z} + {\mathbf{a}}_{y}$</td><td>${\mathrm{e}}^{gen}$</td><td>27.74</td><td>16.19</td><td>26.38</td><td>11.04</td><td>24.13</td><td>21.1</td></tr><tr><td>F6</td><td>$\mathbf{z}$</td><td>$\left\lbrack  {{\mathbf{a}}_{y},{\mathbf{e}}^{gen}}\right\rbrack$</td><td>28.9</td><td>18.2</td><td>27.1</td><td>13.1</td><td>25.7</td><td>22.6</td></tr></tbody></table>

Table 4. Performance comparison to analyse different potential ways to fuse and encode class-level semantic and domain-specific information in generated features $\widehat{\mathbf{f}}$ while training the generative network $G$ . Symbols $\mathbf{z},{\mathbf{a}}_{y},{\mathbf{e}}^{\text{gen }}$ represents noise, attribute and domain embedding respectively.

表4. 在训练生成网络$G$时，分析在生成特征$\widehat{\mathbf{f}}$中融合和编码类级别语义信息和特定领域信息的不同潜在方法的性能比较。符号$\mathbf{z},{\mathbf{a}}_{y},{\mathbf{e}}^{\text{gen }}$分别表示噪声、属性和领域嵌入。

Fusion Techniques. In this subsection, we validate our choice of using batchnorm-based fusion of domain-specific and class-level semantic information. Specifically, we compare the model performance for different choices of potential ways that could be used to encode this information in the generated features. We show this analysis in Table 4. The input layer column corresponds to the vector input to the generative model and the BN layer corresponds to the em-beddings that are input to the BatchNorm estimator network ${B}_{\text{gen }}^{l}$ . Furthermore,[.] denotes the concatenation of vectors and ${}^{\prime }{ + }^{\prime }$ denotes the addition operation between vectors.

融合技术。在本小节中，我们验证了使用基于批量归一化(BatchNorm)的特定领域信息和类级别语义信息融合方法的选择。具体来说，我们比较了在生成特征中编码此信息的不同潜在方法选择下的模型性能。我们在表4中展示了这一分析。输入层列对应于生成模型的向量输入，而批量归一化层(BN层)对应于输入到批量归一化估计网络${B}_{\text{gen }}^{l}$的嵌入。此外，[.]表示向量的拼接，${}^{\prime }{ + }^{\prime }$表示向量之间的加法运算。

We observe that simply concatenating the domain and semantic embeddings together with noise and providing it as input directly to the generative model (instead of conditional batchnorm) i.e ${F1}$ leads to lower performance than the proposed COCOA approach ${F6}$ . Also, concatenating only semantic embeddings with noise in the input layer and having batchnorm parameters conditioned solely on domain embeddings i.e ${F4}$ also exhibits lower average performance when compared with ${F6}$ . We observe that using ’+’ operator deteriorates performance when compared with the concatenation-based counterpart for all cases. Overall, we achieve the best performance with the proposed method.

我们观察到，简单地将领域嵌入和语义嵌入与噪声拼接在一起，并直接将其作为输入提供给生成模型(而不是使用条件批量归一化)，即${F1}$，其性能低于所提出的COCOA方法${F6}$。此外，在输入层仅将语义嵌入与噪声拼接，并且批量归一化参数仅以领域嵌入为条件，即${F4}$，与${F6}$相比，其平均性能也较低。我们发现，在所有情况下，使用“+”运算符与基于拼接的方法相比，性能会下降。总体而言，我们所提出的方法实现了最佳性能。

Visualization of Generated Features. We now present the visualization of features generated by our trained generative model. We sample semantic attributes ${\mathbf{a}}_{y}^{u}$ for randomly selected unseen classes and use domain embeddings (learned end-to-end) of the five source domains (Real, Infograph, Quickdraw, Clipart, Sketch) used during training. We individually visualize the features generated of each unseen class using only semantic embeddings/context i.e $\mathbf{c} = {\mathbf{a}}_{y}^{u}$ (Fig 3, Row 1) and concatenation of both semantic and domain embeddings/context i.e $\mathbf{c} = \left\lbrack  {{\mathbf{a}}_{y}^{u},{\mathbf{e}}_{d}^{\text{gen }}}\right\rbrack$ (Fig 3, Row 2) when estimating the batchnorm parameters of the generator. We notice that conditioning the batchnorm parameters only on semantic context (Fig 3, Row 1) collapses the generated features of different domains to the same point in the cluster and suffers from mode dropping as observed in [30]. This occurs since the model is unable to explain the variance in features due to domain-specific information. On the other hand, when both semantic and domain context are used (Fig 3, Row 2), the model better captures the modes of the original data distribution. It can be seen that the model can better retain domain-specific variance (associated with the five source domains) within a specific class cluster when both semantic and domain embeddings are both used. More such results are shown in the Appendix.

生成特征的可视化。我们现在展示由我们训练好的生成模型生成的特征的可视化结果。我们为随机选择的未见类采样语义属性${\mathbf{a}}_{y}^{u}$，并使用在训练期间使用的五个源领域(真实图像、信息图、快速绘图、剪贴画、素描)的领域嵌入(端到端学习得到)。在估计生成器的批量归一化参数时，我们分别可视化仅使用语义嵌入/上下文，即$\mathbf{c} = {\mathbf{a}}_{y}^{u}$(图3，第一行)和同时使用语义和领域嵌入/上下文的拼接，即$\mathbf{c} = \left\lbrack  {{\mathbf{a}}_{y}^{u},{\mathbf{e}}_{d}^{\text{gen }}}\right\rbrack$(图3，第二行)为每个未见类生成的特征。我们注意到，仅以语义上下文为批量归一化参数的条件(图3，第一行)会使不同领域生成的特征在聚类中收敛到同一点，并且会出现如文献[30]中所观察到的模式丢失问题。这是因为模型无法解释由于特定领域信息导致的特征方差。另一方面，当同时使用语义和领域上下文时(图3，第二行)，模型能更好地捕捉原始数据分布的模式。可以看出，当同时使用语义和领域嵌入时，模型可以在特定类聚类中更好地保留特定领域的方差(与五个源领域相关)。更多此类结果见附录。

Analysis of Regularizers. As in Sec 3.2, our model is trained with a regularizer block using an additional loss term $\mathcal{R}\left( \mathbf{f}\right)$ , which helps our model to generalize well, as well as regulate the presence of semantic and domain information in visual features. We now analyze the choice of rotation prediction as a regularizer, and study other reg-ularizers for their relevance to this setting, in particular: (1) CuMix [27] that provides feature regularization and has been studied for the ZSLDG setting; we refer to this variant as ${\mathrm{{COCOA}}}_{\text{CuMix }}$ ; and (2) A domain classification regularization to understand whether regulating the amount of domain-specific information also brings any improvement. We refer to this variant as ${\operatorname{COCOA}}_{{DOM}\left( \alpha \right) }$ and the objective is given by:

正则化项分析。如第3.2节所述，我们的模型使用一个带有额外损失项$\mathcal{R}\left( \mathbf{f}\right)$的正则化模块进行训练，这有助于我们的模型更好地泛化，同时调节视觉特征中语义和领域信息的存在。我们现在分析选择旋转预测作为正则化项的情况，并研究其他正则化项与此设置的相关性，具体如下:(1)CuMix [27]，它提供特征正则化，并且已经在零样本跨领域泛化(ZSLDG)设置中进行了研究；我们将此变体称为${\mathrm{{COCOA}}}_{\text{CuMix }}$；(2)领域分类正则化，以了解调节特定领域信息的数量是否也能带来任何改进。我们将此变体称为${\operatorname{COCOA}}_{{DOM}\left( \alpha \right) }$，其目标函数如下:

$$
{\mathcal{L}}_{{DOM}\left( \alpha \right) } = {\mathcal{L}}_{AGG} + \alpha  \cdot  {\mathbb{E}}_{\left( {\mathbf{x}, y, d}\right)  \sim  {S}^{Tr}}\left\lbrack  {{\mathcal{L}}_{CE}\left( {g\left( {f\left( \mathbf{x}\right) }\right) , d}\right) }\right\rbrack
$$

(11)

![0195d706-18c8-71e6-816f-df978d63610a_7_139_1754_708_224_0.jpg](images/0195d706-18c8-71e6-816f-df978d63610a_7_139_1754_708_224_0.jpg)

Figure 3. Individual t-SNE visualization of synthesized image features by COCOA for randomly selected unseen classes (Giraffe, Watermelon, Helicopter, Rainbow, Skyscaper) using only semantic context (Row 1) and both domain-semantic context (Row 2) (Best viewed in color, zoomed in).

图3. COCOA为随机选择的未见类(长颈鹿、西瓜、直升机、彩虹、摩天大楼)合成的图像特征的单独t-SNE可视化结果，分别仅使用语义上下文(第一行)和同时使用领域 - 语义上下文(第二行)(建议彩色放大查看)。

<table><tr><td colspan="2">Variant</td><td>Clipart</td><td>Infograph</td><td>Painting</td><td>Quickdraw</td><td>Sketch</td><td>Avg</td></tr><tr><td rowspan="4">${\operatorname{COCOA}}_{{DOM}\left( \alpha \right) }$</td><td>$\alpha  = 0$</td><td>27.6</td><td>17.1</td><td>25.7</td><td>11.8</td><td>23.7</td><td>21.2</td></tr><tr><td>$\alpha  = {0.01}$</td><td>28.14</td><td>16.1</td><td>27.19</td><td>10.55</td><td>23.8</td><td>21.1</td></tr><tr><td>$\alpha  = {0.05}$</td><td>26.26</td><td>16.7</td><td>26.88</td><td>11.2</td><td>23.6</td><td>20.9</td></tr><tr><td>$\alpha  = {0.1}$</td><td>26.48</td><td>15.5</td><td>26.9</td><td>11.21</td><td>23.7</td><td>20.7</td></tr><tr><td colspan="2">${\mathrm{{COCOA}}}_{CuMix}$</td><td>27.7</td><td>17.5</td><td>27.8</td><td>12.6</td><td>25.6</td><td>22.2</td></tr><tr><td colspan="2">${COCOA}_{ROT}$</td><td>28.9</td><td>18.2</td><td>27.1</td><td>13.1</td><td>25.7</td><td>22.6</td></tr></table>

<table><tbody><tr><td colspan="2">变体(Variant)</td><td>剪贴画(Clipart)</td><td>信息图(Infograph)</td><td>绘画(Painting)</td><td>快速绘图(Quickdraw)</td><td>素描(Sketch)</td><td>平均值(Avg)</td></tr><tr><td rowspan="4">${\operatorname{COCOA}}_{{DOM}\left( \alpha \right) }$</td><td>$\alpha  = 0$</td><td>27.6</td><td>17.1</td><td>25.7</td><td>11.8</td><td>23.7</td><td>21.2</td></tr><tr><td>$\alpha  = {0.01}$</td><td>28.14</td><td>16.1</td><td>27.19</td><td>10.55</td><td>23.8</td><td>21.1</td></tr><tr><td>$\alpha  = {0.05}$</td><td>26.26</td><td>16.7</td><td>26.88</td><td>11.2</td><td>23.6</td><td>20.9</td></tr><tr><td>$\alpha  = {0.1}$</td><td>26.48</td><td>15.5</td><td>26.9</td><td>11.21</td><td>23.7</td><td>20.7</td></tr><tr><td colspan="2">${\mathrm{{COCOA}}}_{CuMix}$</td><td>27.7</td><td>17.5</td><td>27.8</td><td>12.6</td><td>25.6</td><td>22.2</td></tr><tr><td colspan="2">${COCOA}_{ROT}$</td><td>28.9</td><td>18.2</td><td>27.1</td><td>13.1</td><td>25.7</td><td>22.6</td></tr></tbody></table>

Table 5. Analysis on the choice of Regularizer $R\left( \mathbf{f}\right)$ . Note that ${\operatorname{COCOA}}_{{DOM}\left( \alpha \right) }$ with $\alpha  = 0$ is same as ${\operatorname{COCOA}}_{AGG}$

表5. 正则化器 $R\left( \mathbf{f}\right)$ 的选择分析。请注意，带有 $\alpha  = 0$ 的 ${\operatorname{COCOA}}_{{DOM}\left( \alpha \right) }$ 与 ${\operatorname{COCOA}}_{AGG}$ 相同

where $g\left( \text{.}\right) {isafomainclassifier}({implementedassingle}$ linear layer). By varying the hyperparameter $\alpha$ , we can regulate the amount of domain-information in features $f$ . From Table 5, we notice that when CuMix-based regularization is used, features generated using i.e ${\mathrm{{COCOA}}}_{\text{CuMix }}$ leads to improvement in the average performance relative to ${\mathrm{{COCOA}}}_{AGG}$ . We also observe that adding domain classification as an auxiliary prediction task does not bring enhancement in the performance (as $\alpha$ is varied from 0 to 0.1). We hypothesize that while domain information is relevant for better generalization, more such information can cause features to lose their class-discriminative capability. Further analyzing better regularizers to learn better base features is a potential direction for future work.

其中 $g\left( \text{.}\right) {isafomainclassifier}({implementedassingle}$ 线性层)。通过改变超参数 $\alpha$，我们可以调节特征 $f$ 中的领域信息数量。从表5中我们注意到，当使用基于CuMix的正则化时，使用即 ${\mathrm{{COCOA}}}_{\text{CuMix }}$ 生成的特征相对于 ${\mathrm{{COCOA}}}_{AGG}$ 在平均性能上有所提升。我们还观察到，将领域分类作为辅助预测任务并没有带来性能的提升(当 $\alpha$ 从0变化到0.1时)。我们假设，虽然领域信息对于更好的泛化能力是相关的，但更多的此类信息可能会导致特征失去其类别区分能力。进一步分析更好的正则化器以学习更好的基础特征是未来工作的一个潜在方向。

## 5. Conclusion

## 5. 结论

In this work, we propose a unified generative framework for the ZSLDG problem setting that uses an elegant approach to encode class-level (domain-invariant) and domain-specific information. Our approach uses context conditional batch-normalization to integrate class-level semantic and domain-specific information into generated visual features, thereby enabling better generalization. We conduct extensive experiments on benchmark ZSLDG datasets and demonstrate the effectiveness of the proposed method. Furthermore, we show extensive analysis to validate our choice of using conditional batch-normalization to fuse semantic and domain-dependent characteristics. Our future work will include the development of better methods to effectively fuse and regulate the presence of semantic and context information to further improve generalization performance for unseen classes in unseen domains.

在这项工作中，我们为零样本领域泛化(ZSLDG)问题设置提出了一个统一的生成框架，该框架采用一种优雅的方法来编码类别级(领域不变)和特定领域的信息。我们的方法使用上下文条件批量归一化(context conditional batch - normalization)将类别级语义和特定领域信息集成到生成的视觉特征中，从而实现更好的泛化能力。我们在基准ZSLDG数据集上进行了广泛的实验，并证明了所提出方法的有效性。此外，我们进行了广泛的分析，以验证我们选择使用条件批量归一化来融合语义和依赖于领域的特征的合理性。我们未来的工作将包括开发更好的方法来有效融合和调节语义和上下文信息的存在，以进一步提高在未见领域中未见类别的泛化性能。

Acknowledgement: This work has been partly supported by the funding received from DST through the IMPRINT program (IMP/2019/000250)

致谢:这项工作部分得到了科学技术部(DST)通过印记计划(IMPRINT)提供的资金支持(IMP/2019/000250)

## References

## 参考文献

[1] Zeynep Akata, Florent Perronnin, Zaid Harchaoui, and Cordelia Schmid. Label-embedding for attribute-based classification. In Proceedings of the IEEE Conference on Computer Vision and Pattern Recognition, pages 819-826, 2013.

[1] Zeynep Akata、Florent Perronnin、Zaid Harchaoui和Cordelia Schmid。基于属性分类的标签嵌入。见《IEEE计算机视觉与模式识别会议论文集》，第819 - 826页，2013年。

[2] Z. Akata, F. Perronnin, Z. Harchaoui, and C. Schmid. Label embedding for image classification. TPAMI, 2016.

[2] Z. Akata、F. Perronnin、Z. Harchaoui和C. Schmid。用于图像分类的标签嵌入。《模式分析与机器智能汇刊》(TPAMI)，2016年。

[3] Z. Akata, S. Reed, D. Walter, H. Lee, and B. Schiele. Evaluation of output embeddings for fine-grained image classification. CVPR, 2015.

[3] Z. Akata、S. Reed、D. Walter、H. Lee和B. Schiele。用于细粒度图像分类的输出嵌入评估。《计算机视觉与模式识别会议》(CVPR)，2015年。

[4] Yashas Annadani and Soma Biswas. Preserving semantic relations for zero-shot learning. 2018 IEEE/CVF Conference on Computer Vision and Pattern Recognition, pages 7603- 7612, 2018.

[4] Yashas Annadani和Soma Biswas。零样本学习中保留语义关系。2018年《IEEE/CVF计算机视觉与模式识别会议》，第7603 - 7612页，2018年。

[5] Y. Balaji, S. Sankaranarayanan, and R. Chellappa. Metareg: Towards domain generalization using meta-regularization. In NeurIPS, 2018.

[5] Y. Balaji、S. Sankaranarayanan和R. Chellappa。元正则化(Metareg):使用元正则化实现领域泛化。见《神经信息处理系统大会》(NeurIPS)，2018年。

[6] Fabio Maria Carlucci, Antonio D'Innocente, Silvia Bucci, B. Caputo, and T. Tommasi. Domain generalization by solving jigsaw puzzles. 2019 IEEE/CVF Conference on Computer Vision and Pattern Recognition (CVPR), pages 2224-2233, 2019.

[6] Fabio Maria Carlucci、Antonio D'Innocente、Silvia Bucci、B. Caputo和T. Tommasi。通过解决拼图难题实现领域泛化。2019年《IEEE/CVF计算机视觉与模式识别会议》(CVPR)，第2224 - 2233页，2019年。

[7] Lampert CH, Nickisch H, and Harmeling S. Attribute-based classification for zero-shot visual object categorization. IEEE Transactions on Pattern Analysis and Machine Intelligence, 2013.

[7] Lampert CH、Nickisch H和Harmeling S。基于属性的分类用于零样本视觉对象分类。《IEEE模式分析与机器智能汇刊》，2013年。

[8] Shivam Chandhok and V. Balasubramanian. Two-level adversarial visual-semantic coupling for generalized zero-shot learning. WACV, 2021.

[8] Shivam Chandhok和V. Balasubramanian。用于广义零样本学习的两级对抗视觉 - 语义耦合。《冬季计算机视觉应用会议》(WACV)，2021年。

[9] S. Changpinyo, W.-L. Chao, B.; Gong, and F. Sha. Synthesized classifiers for zero-shot learning. CVPR, 2016.

[9] S. Changpinyo、W. - L. Chao、B. Gong和F. Sha。用于零样本学习的合成分类器。《计算机视觉与模式识别会议》(CVPR)，2016年。

[10] Prithvijit Chattopadhyay, Y. Balaji, and Judy Hoffman. Learning to balance specificity and invariance for in and out of domain generalization. volume abs/2008.12839, 2020.

[10] Prithvijit Chattopadhyay、Y. Balaji和Judy Hoffman。学习平衡特异性和不变性以实现领域内和领域外泛化。卷abs/2008.12839，2020年。

[11] Hisham Cholakkal, Guolei Sun, Fahad Shahbaz Khan, and Ling Shao. Object counting and instance segmentation with image-level supervision. 2019 IEEE/CVF Conference on Computer Vision and Pattern Recognition (CVPR), pages 12389-12397, 2019.

[11] 希沙姆·乔拉卡尔(Hisham Cholakkal)、孙国磊(Guolei Sun)、法哈德·沙赫巴兹·汗(Fahad Shahbaz Khan)和邵岭(Ling Shao)。基于图像级监督的目标计数与实例分割。2019年电气与电子工程师协会/计算机视觉基金会计算机视觉与模式识别会议(IEEE/CVF Conference on Computer Vision and Pattern Recognition，CVPR)，第12389 - 12397页，2019年。

[12] Rafael Felix, Vijay BG Kumar, Ian Reid, and Gustavo Carneiro. Multi-modal cycle-consistent generalized zero-shot learning. In Proceedings of the European Conference on Computer Vision, 2018.

[12] 拉斐尔·费利克斯(Rafael Felix)、维杰·BG·库马尔(Vijay BG Kumar)、伊恩·里德(Ian Reid)和古斯塔沃·卡内罗(Gustavo Carneiro)。多模态循环一致的广义零样本学习。《欧洲计算机视觉会议论文集》，2018年。

[13] Andrea Frome, Greg S Corrado, Jon Shlens, Samy Bengio, Jeff Dean, Marc'Aurelio Ranzato, and Tomas Mikolov. Devise: A deep visual-semantic embedding model. In Advances in neural information processing systems, pages 2121-2129, 2013.

[13] 安德里亚·弗罗姆(Andrea Frome)、格雷格·S·科拉多(Greg S Corrado)、乔恩·什伦斯(Jon Shlens)、萨米·本吉奥(Samy Bengio)、杰夫·迪恩(Jeff Dean)、马克·奥雷利奥·兰扎托(Marc'Aurelio Ranzato)和托马斯·米科洛夫(Tomas Mikolov)。DEVISE:一种深度视觉语义嵌入模型。《神经信息处理系统进展》，第2121 - 2129页，2013年。

[14] Yaroslav Ganin, Evgeniya Ustinova, Hana Ajakan, Pascal Germain, Hugo Larochelle, François Laviolette, Mario Marchand, and Victor Lempitsky. Domain-adversarial training of neural networks. The Journal of Machine Learning Research, 17(1):2096-2030, 2016.

[14] 亚罗斯拉夫·加宁(Yaroslav Ganin)、叶夫根尼娅·乌斯蒂诺娃(Evgeniya Ustinova)、哈娜·阿贾坎(Hana Ajakan)、帕斯卡尔·热尔曼(Pascal Germain)、雨果·拉罗谢尔(Hugo Larochelle)、弗朗索瓦·拉维奥莱特(François Laviolette)、马里奥·马尔尚(Mario Marchand)和维克多·伦皮茨基(Victor Lempitsky)。神经网络的领域对抗训练。《机器学习研究杂志》，17(1):2096 - 2030，2016年。

[15] Muhammad Ghifary, W. Kleijn, M. Zhang, and D. Balduzzi. Domain generalization for object recognition with multi-task autoencoders. 2015 IEEE International Conference on Computer Vision (ICCV), pages 2551-2559, 2015.

[15] 穆罕默德·吉法里(Muhammad Ghifary)、W. 克莱因(W. Kleijn)、M. 张(M. Zhang)和D. 巴尔杜齐(D. Balduzzi)。基于多任务自编码器的目标识别领域泛化。2015年电气与电子工程师协会国际计算机视觉会议(IEEE International Conference on Computer Vision，ICCV)，第2551 - 2559页，2015年。

[16] Spyros Gidaris, Praveer Singh, and Nikos Komodakis. Unsupervised representation learning by predicting image rota-

[16] 斯皮罗斯·吉达里斯(Spyros Gidaris)、普拉维尔·辛格(Praveer Singh)和尼科斯·科莫达基斯(Nikos Komodakis)。通过预测图像旋转进行无监督表征学习

tions. ArXiv, abs/1803.07728, 2018.

。预印本平台ArXiv，编号abs/1803.07728，2018年。

[17] Boqing Gong, K. Grauman, and Fei Sha. Reshaping visual datasets for domain adaptation. In NIPS, 2013.

[17] 龚博清(Boqing Gong)、K. 格劳曼(K. Grauman)和沙飞(Fei Sha)。为领域适应重塑视觉数据集。《神经信息处理系统大会》，2013年。

[18] He Huang, Changhu Wang, Philip S Yu, and Chang-Dong Wang. Generative dual adversarial network for generalized zero-shot learning. CVPR, 2019.

[18] 黄贺(He Huang)、王长虎(Changhu Wang)、菲利普·S·于(Philip S Yu)和王长东(Chang - Dong Wang)。用于广义零样本学习的生成式对偶对抗网络。计算机视觉与模式识别会议(CVPR)，2019年。

[19] Rohit Keshari, Richa Singh, and Mayank Vatsa. Generalized zero-shot learning via over-complete distribution. CVPR, 2020.

[19] 罗希特·凯沙里(Rohit Keshari)、里查·辛格(Richa Singh)和马扬克·瓦查(Mayank Vatsa)。通过过完备分布实现广义零样本学习。计算机视觉与模式识别会议(CVPR)，2020年。

[20] Elyor Kodirov, Tao Xiang, Zhenyong Fu, and S. Gong. Unsupervised domain adaptation for zero-shot learning. 2015 IEEE International Conference on Computer Vision (ICCV), pages 2452-2460, 2015.

[20] 埃利奥尔·科迪罗夫(Elyor Kodirov)、陶翔(Tao Xiang)、傅振勇(Zhenyong Fu)和龚少晖(S. Gong)。用于零样本学习的无监督领域适应。2015年电气与电子工程师协会国际计算机视觉会议(IEEE International Conference on Computer Vision，ICCV)，第2452 - 2460页，2015年。

[21] Da Li, Yongxin Yang, Yi-Zhe Song, and Timothy M. Hospedales. Deeper, broader and artier domain generalization. 2017 IEEE International Conference on Computer Vision (ICCV), pages 5543-5551, 2017.

[21] 李达(Da Li)、杨永新(Yongxin Yang)、宋毅哲(Yi - Zhe Song)和蒂莫西·M·霍斯佩代尔斯(Timothy M. Hospedales)。更深、更广、更具艺术性的领域泛化。2017年电气与电子工程师协会国际计算机视觉会议(IEEE International Conference on Computer Vision，ICCV)，第5543 - 5551页，2017年。

[22] Da Li, Yongxin Yang, Yi-Zhe Song, and Timothy M. Hospedales. Learning to generalize: Meta-learning for domain generalization. In ${AAAI},{2018}$ .

[22] 李达(Da Li)、杨永新(Yongxin Yang)、宋毅哲(Yi - Zhe Song)和蒂莫西·M·霍斯佩代尔斯(Timothy M. Hospedales)。学习泛化:用于领域泛化的元学习。见${AAAI},{2018}$ 。

[23] Da Li, J. Zhang, Yongxin Yang, Cong Liu, Yi-Zhe Song, and Timothy M. Hospedales. Episodic training for domain generalization. 2019 IEEE/CVF International Conference on Computer Vision (ICCV), pages 1446-1455, 2019.

[23] 李达(Da Li)、张健树(J. Zhang)、杨永新(Yongxin Yang)、刘聪(Cong Liu)、宋毅哲(Yi - Zhe Song)和蒂莫西·M·霍斯佩代尔斯(Timothy M. Hospedales)。用于领域泛化的情景式训练。2019年电气与电子工程师协会/计算机视觉基金会国际计算机视觉会议(IEEE/CVF International Conference on Computer Vision，ICCV)，第1446 - 1455页，2019年。

[24] Da Li, Jianshu Zhang, Yongxin Yang, Cong Liu, Yi-Zhe Song, and Timothy M Hospedales. Episodic training for domain generalization. In Proceedings of the IEEE International Conference on Computer Vision, pages 1446-1455, 2019.

[24] 李达(Da Li)、张健树(Jianshu Zhang)、杨永新(Yongxin Yang)、刘聪(Cong Liu)、宋毅哲(Yi - Zhe Song)和蒂莫西·M·霍斯佩代尔斯(Timothy M Hospedales)。用于领域泛化的情景式训练。《电气与电子工程师协会国际计算机视觉会议论文集》，第1446 - 1455页，2019年。

[25] Haoliang Li, Sinno Jialin Pan, S. Wang, and A. Kot. Domain generalization with adversarial feature learning. 2018 IEEE/CVF Conference on Computer Vision and Pattern Recognition, pages 5400-5409, 2018.

[25] 李昊亮(Haoliang Li)、潘嘉麟(Sinno Jialin Pan)、王S.(S. Wang)和科特A.(A. Kot)。基于对抗特征学习的领域泛化。2018年电气与电子工程师协会/计算机视觉基金会计算机视觉与模式识别会议，第5400 - 5409页，2018年。

[26] Y. Li, X. Tian, Mingming Gong, Y. Liu, T. Liu, K. Zhang, and D. Tao. Deep domain generalization via conditional invariant adversarial networks. In ${ECCV},{2018}$ .

[26] 李阳(Y. Li)、田鑫(X. Tian)、龚明明(Mingming Gong)、刘洋(Y. Liu)、刘婷(T. Liu)、张凯(K. Zhang)和陶大程(D. Tao)。通过条件不变对抗网络实现深度领域泛化。见 ${ECCV},{2018}$。

[27] Massimiliano Mancini, Zeynep Akata, E. Ricci, and Barbara Caputo. Towards recognizing unseen categories in unseen domains. In ${ECCV},{2020}$ .

[27] 马西米利亚诺·曼奇尼(Massimiliano Mancini)、泽内普·阿卡塔(Zeynep Akata)、E. 里奇(E. Ricci)和芭芭拉·卡普托(Barbara Caputo)。迈向识别未见领域中的未见类别。见 ${ECCV},{2020}$。

[28] Udit Maniyar, K. J. Joseph, A. Deshmukh, Ü. Dogan, and V. Balasubramanian. Zero-shot domain generalization. ArXiv, abs/2008.07443, 2020.

[28] 乌迪特·马尼耶尔(Udit Maniyar)、K. J. 约瑟夫(K. J. Joseph)、A. 德什穆克(A. Deshmukh)、Ü. 多安(Ü. Dogan)和 V. 巴拉苏布拉马尼亚姆(V. Balasubramanian)。零样本领域泛化。预印本 arXiv:2008.07443，2020 年。

[29] Tomas Mikolov, Kai Chen, Greg S. Corrado, and Jeffrey Dean. Efficient estimation of word representations in vector space, 2013.

[29] 托马斯·米科洛夫(Tomas Mikolov)、陈凯(Kai Chen)、格雷格·S·科拉多(Greg S. Corrado)和杰弗里·迪恩(Jeffrey Dean)。向量空间中词表示的高效估计，2013 年。

[30] Ashish Mishra, Shiva Krishna Reddy, Anurag Mittal, and Hema A Murthy. A generative model for zero shot learning using conditional variational autoencoders. CVPRW, 2018.

[30] 阿希什·米什拉(Ashish Mishra)、希瓦·克里希纳·雷迪(Shiva Krishna Reddy)、阿努拉格·米塔尔(Anurag Mittal)和赫马·A·穆尔蒂(Hema A Murthy)。使用条件变分自编码器的零样本学习生成模型。计算机视觉与模式识别研讨会(CVPRW)，2018 年。

[31] Takeru Miyato and Masanori Koyama. cGANs with projection discriminator. In International Conference on Learning Representations, 2018.

[31] 宫田健(Takeru Miyato)和小山正典(Masanori Koyama)。带投影判别器的条件生成对抗网络(cGANs)。见国际学习表征会议，2018 年。

[32] Krikamol Muandet, D. Balduzzi, and B. Schölkopf. Domain generalization via invariant feature representation. ArXiv, abs/1301.2115, 2013.

[32] 克里卡莫尔·穆安代特(Krikamol Muandet)、D. 巴尔杜齐(D. Balduzzi)和 B. 肖尔科普夫(B. Schölkopf)。通过不变特征表示实现领域泛化。预印本 arXiv:1301.2115，2013 年。

[33] Sanath Narayan, A. Gupta, F. Khan, Cees G. M. Snoek, and

[33] 萨纳特·纳拉扬(Sanath Narayan)、A. 古普塔(A. Gupta)、F. 汗(F. Khan)、塞斯·G·M·斯诺克(Cees G. M. Snoek)和

L. Shao. Latent embedding feedback and discriminative features for zero-shot classification. ArXiv, abs/2003.07833, 2020.

邵玲(L. Shao)。用于零样本分类的潜在嵌入反馈和判别特征。预印本 arXiv:2003.07833，2020 年。

[34] Sanath Narayan, Akshita Gupta, Salman Khan, Fahad Shah-baz Khan, Ling Shao, and Mubarak Shah. Discriminative region-based multi-label zero-shot learning. In Proceedings of the IEEE/CVF International Conference on Computer Vision (ICCV), pages 8731-8740, October 2021.

[34] 萨纳特·纳拉扬(Sanath Narayan)、阿克希塔·古普塔(Akshita Gupta)、萨尔曼·汗(Salman Khan)、法哈德·沙赫巴兹·汗(Fahad Shah-baz Khan)、邵玲(Ling Shao)和穆巴拉克·沙阿(Mubarak Shah)。基于判别区域的多标签零样本学习。见电气与电子工程师协会/计算机视觉基金会国际计算机视觉会议(IEEE/CVF International Conference on Computer Vision，ICCV)论文集，第 8731 - 8740 页，2021 年 10 月。

[35] Jian Ni, Shanghang Zhang, and Haiyong Xie. Dual adversarial semantics-consistent network for generalized zero-shot learning. NeurIPS, 2019.

[35] 倪健(Jian Ni)、张上航(Shanghang Zhang)和谢海勇(Haiyong Xie)。用于广义零样本学习的双对抗语义一致网络。神经信息处理系统大会(NeurIPS)，2019 年。

[36] Jian Ni, Shanghang Zhang, and Haiyong Xie. Dual adversarial semantics-consistent network for generalized zero-shot learning. NeurIPS, , 2019.

[36] 倪健(Jian Ni)、张上航(Shanghang Zhang)和谢海勇(Haiyong Xie)。用于广义零样本学习的双对抗语义一致网络。神经信息处理系统大会(NeurIPS)，，2019 年。

[37] Xingchao Peng, Qinxun Bai, Xide Xia, Zijun Huang, Kate Saenko, and Bo Wang. Moment matching for multi-source domain adaptation. In Proceedings of the IEEE International Conference on Computer Vision, pages 1406-1415, 2019.

[37] 彭兴超(Xingchao Peng)、白勤勋(Qinxun Bai)、夏西德(Xide Xia)、黄紫军(Zijun Huang)、凯特·塞内科(Kate Saenko)和王博(Bo Wang)。多源领域自适应的矩匹配。见电气与电子工程师协会国际计算机视觉会议论文集，第 1406 - 1415 页，2019 年。

[38] Jathushan Rajasegaran, Munawar Hayat, Salman Hameed Khan, Fahad Shahbaz Khan, and Ling Shao. Random path selection for continual learning. In NeurIPS, 2019.

[38] 贾图山·拉贾塞加兰(Jathushan Rajasegaran)、穆纳瓦尔·哈亚特(Munawar Hayat)、萨尔曼·哈米德·汗(Salman Hameed Khan)、法哈德·沙赫巴兹·汗(Fahad Shahbaz Khan)和邵玲(Ling Shao)。持续学习的随机路径选择。见神经信息处理系统大会(NeurIPS)，2019 年。

[39] Jathushan Rajasegaran, Salman Hameed Khan, Munawar Hayat, Fahad Shahbaz Khan, and Mubarak Shah. itaml: An incremental task-agnostic meta-learning approach. 2020 IEEE/CVF Conference on Computer Vision and Pattern Recognition (CVPR), pages 13585-13594, 2020.

[39] 贾图山·拉贾塞加兰(Jathushan Rajasegaran)、萨尔曼·哈米德·汗(Salman Hameed Khan)、穆纳瓦尔·哈亚特(Munawar Hayat)、法哈德·沙赫巴兹·汗(Fahad Shahbaz Khan)和穆巴拉克·沙阿(Mubarak Shah)。itaml:一种增量式任务无关元学习方法。2020 年电气与电子工程师协会/计算机视觉基金会计算机视觉与模式识别会议(IEEE/CVF Conference on Computer Vision and Pattern Recognition，CVPR)，第 13585 - 13594 页，2020 年。

[40] Scott E. Reed, Zeynep Akata, H. Lee, and B. Schiele. Learning deep representations of fine-grained visual descriptions. 2016 IEEE Conference on Computer Vision and Pattern Recognition (CVPR), pages 49-58, 2016.

[40] 斯科特·E·里德(Scott E. Reed)、泽内普·阿卡塔(Zeynep Akata)、H. 李(H. Lee)和 B. 席勒(B. Schiele)。细粒度视觉描述的深度表示学习。2016 年电气与电子工程师协会计算机视觉与模式识别会议(IEEE Conference on Computer Vision and Pattern Recognition，CVPR)，第 49 - 58 页，2016 年。

[41] B. Romera-Paredes and P. H. Torr. An embarrassingly simple approach to zero-shot learning. ICML, 2015.

[41] B. 罗梅拉 - 帕雷德斯(Romera - Paredes)和 P. H. 托尔(Torr)。一种极其简单的零样本学习方法。国际机器学习会议(ICML)，2015 年。

[42] Edgar Schonfeld, Sayna Ebrahimi, Samarth Sinha, Trevor Darrell, and Zeynep Akata. Generalized zero-and few-shot learning via aligned variational autoencoders. CVPR, 2019.

[42] 埃德加·舍恩菲尔德(Edgar Schonfeld)、赛娜·易卜拉欣米(Sayna Ebrahimi)、萨马尔思·辛哈(Samarth Sinha)、特雷弗·达雷尔(Trevor Darrell)和泽内普·阿卡塔(Zeynep Akata)。通过对齐变分自编码器实现广义零样本和少样本学习。计算机视觉与模式识别会议(CVPR)，2019 年。

[43] Mattia Segu, A. Tonioni, and Federico Tombari. Batch normalization embeddings for deep domain generalization. ArXiv, abs/2011.12672, 2020.

[43] 马蒂亚·塞古(Mattia Segu)、A. 托尼奥尼(Tonioni)和费德里科·通巴里(Federico Tombari)。用于深度领域泛化的批量归一化嵌入。预印本平台(ArXiv)，编号 abs/2011.12672，2020 年。

[44] Seonguk Seo, Yumin Suh, D. Kim, Jongwoo Han, and B. Han. Learning to optimize domain specific normalization for domain generalization. 2020.

[44] 徐成旭(Seonguk Seo)、徐有民(Yumin Suh)、D. 金(Kim)、韩钟宇(Jongwoo Han)和 B. 韩(Han)。学习优化特定领域归一化以实现领域泛化。2020 年。

[45] Yuming Shen, J. Qin, and L. Huang. Invertible zero-shot recognition flows. In ${ECCV},{2020}$ .

[45] 沈玉明、J. 秦和 L. 黄。可逆零样本识别流。见 ${ECCV},{2020}$。

[46] Yutaro Shigeto, Ikumi Suzuki, K. Hara, M. Shimbo, and Y. Matsumoto. Ridge regression, hubness, and zero-shot learning. In ${ECML}/{PKDD},{2015}$ .

[46] 重藤裕太郎(Yutaro Shigeto)、铃木郁美(Ikumi Suzuki)、K. 原(Hara)、M. 岛本(Shimbo)和 Y. 松本(Matsumoto)。岭回归、枢纽性与零样本学习。见 ${ECML}/{PKDD},{2015}$。

[47] A. Torralba and Alexei A. Efros. Unbiased look at dataset bias. CVPR 2011, pages 1521-1528, 2011.

[47] A. 托拉尔巴(Torralba)和阿列克谢·A. 埃弗罗斯(Alexei A. Efros)。对数据集偏差的无偏审视。计算机视觉与模式识别会议(CVPR)2011 年，第 1521 - 1528 页，2011 年。

[48] Y.-H. H. Tsai, L.-K. Huang, and R. Salakhutdinov. Learning robust visual-semantic embeddings. ICCV, 2017.

[48] 蔡育宏(Y. - H. H. Tsai)、黄立凯(L. - K. Huang)和 R. 萨拉胡季诺夫(Salakhutdinov)。学习鲁棒的视觉 - 语义嵌入。国际计算机视觉会议(ICCV)，2017 年。

[49] Ziyu Wan, Dongdong Chen, Y. Li, Xingguang Yan, Junge Zhang, Y. Yu, and Jing Liao. Transductive zero-shot learning with visual structure constraint. In NeurIPS, 2019.

[49] 万子玉、陈东冬、Y. 李、闫星光、张军格、Y. 余和廖静。具有视觉结构约束的直推式零样本学习。神经信息处理系统大会(NeurIPS)，2019 年。

[50] Y. Xian, Z. Akata, G. Sharma, Q. Nguyen, M. Hein, and B. Schiele. Latent embeddings for zero-shot classification. CVPR, 2016.

[50] Y. 西安(Xian)、Z. 阿卡塔(Akata)、G. 夏尔马(Sharma)、Q. 阮(Nguyen)、M. 海因(Hein)和 B. 席勒(Schiele)。用于零样本分类的潜在嵌入。计算机视觉与模式识别会议(CVPR)，2016 年。

[51] Yongqin Xian, Subhabrata Choudhury, Yang He, Bernt Schiele, and Zeynep Akata. Semantic projection network for zero-and few-label semantic segmentation. In Proceedings of the IEEE Conference on Computer Vision and Pattern Recognition, pages 8256-8265, 2019.

[51] 西安永勤(Yongqin Xian)、苏巴布拉塔·乔杜里(Subhabrata Choudhury)、何洋、伯恩特·席勒(Bernt Schiele)和泽内普·阿卡塔(Zeynep Akata)。用于零标签和少标签语义分割的语义投影网络。见电气与电子工程师协会计算机视觉与模式识别会议论文集，第 8256 - 8265 页，2019 年。

[52] Yongqin Xian, Tobias Lorenz, Bernt Schiele, , and Zeynep Akata. Feature generating networks for zero-shot learning. CVPR, 2018.

[52] 西安永勤(Yongqin Xian)、托比亚斯·洛伦茨(Tobias Lorenz)、伯恩特·席勒(Bernt Schiele)和泽内普·阿卡塔(Zeynep Akata)。用于零样本学习的特征生成网络。计算机视觉与模式识别会议(CVPR)，2018 年。

[53] Y. Xian, S. Sharma, B. Schiele, and Z. Akata. A feature generating framework for any-shot learning. CVPR, 2019.

[53] Y. 西安(Xian)、S. 夏尔马(Sharma)、B. 席勒(Schiele)和 Z. 阿卡塔(Akata)。用于任意样本学习的特征生成框架。计算机视觉与模式识别会议(CVPR)，2019 年。

[54] Zheng Xu, W. Li, Li Niu, and Dong Xu. Exploiting low-rank structure from latent domains for domain generalization. In ${ECCV},{2014}$ .

[54] 徐政、W. 李、牛莉和徐东。从潜在领域中挖掘低秩结构以实现领域泛化。见 ${ECCV},{2014}$。

[55] P. Yang and Wei Gao. Multi-view discriminant transfer learning. In ${IJCAI},{2013}$ .

[55] P. 杨和高伟。多视图判别式迁移学习。见 ${IJCAI},{2013}$。

[56] L. Zhang, Tao Xiang, and S. Gong. Learning a deep embedding model for zero-shot learning. 2017 IEEE Conference on Computer Vision and Pattern Recognition (CVPR), pages 3010-3019, 2017.

[56] 张磊、向涛和龚少刚。学习用于零样本学习的深度嵌入模型。2017 年电气与电子工程师协会计算机视觉与模式识别会议(CVPR)，第 3010 - 3019 页，2017 年。

[57] Ziming Zhang and Venkatesh Saligrama. Zero-shot learning via joint latent similarity embedding. 2016 IEEE Conference on Computer Vision and Pattern Recognition (CVPR), pages 6034-6042, 2016.

[57] 张子铭(Ziming Zhang)和文卡特什·萨利格拉马(Venkatesh Saligrama)。通过联合潜在相似性嵌入实现零样本学习。2016 年电气与电子工程师协会计算机视觉与模式识别会议(IEEE Conference on Computer Vision and Pattern Recognition，CVPR)，第 6034 - 6042 页，2016 年。