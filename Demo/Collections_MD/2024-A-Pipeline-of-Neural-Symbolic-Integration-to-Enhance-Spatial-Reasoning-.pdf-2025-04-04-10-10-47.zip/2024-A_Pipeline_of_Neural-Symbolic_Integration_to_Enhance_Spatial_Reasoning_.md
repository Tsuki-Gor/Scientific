# A Pipeline of Neural-Symbolic Integration to Enhance Spatial Reasoning in Large Language Models

# 增强大语言模型空间推理能力的神经符号集成管道

Rong Wang ${}^{*1}$ , Kun Sun ${}^{2}$ , and Jonas Kuhn ${}^{3}$

王荣 ${}^{*1}$ ，孙坤 ${}^{2}$ ，乔纳斯·库恩 ${}^{3}$

${}^{1,3}$ The Institute of Natural Language Processing, Stuttgart University, Stuttgart,

${}^{1,3}$ 斯图加特大学自然语言处理研究所，斯图加特，

Germany

德国

${}^{2}$ Tübingen, Germany

${}^{2}$ 德国图宾根

## Abstract

## 摘要

Large Language Models (LLMs) have demonstrated impressive capabilities across various tasks. However, LLMs often struggle with spatial reasoning which is one essential part of reasoning and inference and requires understanding complex relationships between objects in space. This paper proposes a novel neural-symbolic framework that enhances LLMs' spatial reasoning abilities. We evaluate our approach on two benchmark datasets: StepGame and SparQA, implementing three distinct strategies: (1) ASP (Answer Set Programming)-based symbolic reasoning, (2) LLM + ASP pipeline using DSPy, and (3) Fact + Logical rules. Our experiments demonstrate significant improvements over the baseline prompting methods, with accuracy increases of 40-50% on StepGame dataset and 3-13% on the more complex SparQA dataset. The "LLM + ASP" pipeline achieves particularly strong results on the tasks of Finding Relations (FR) and Finding Block (FB) questions, though performance varies across different question types. Our impressive results suggest that while neural-symbolic approaches offer promising directions for enhancing spatial reasoning in LLMs, their effectiveness depends heavily on the specific task characteristics and implementation strategies. We propose an integrated, simple yet effective set of strategies using a neural-symbolic pipeline to boost spatial reasoning abilities in LLMs. This pipeline and its strategies demonstrate strong generalizability and broader applicability to other reasoning domains in LLMs, such as temporal reasoning, deductive inference etc.

大语言模型(LLMs)在各种任务中展现出了令人印象深刻的能力。然而，大语言模型在空间推理方面往往表现不佳，而空间推理是推理和推断的重要组成部分，需要理解物体在空间中的复杂关系。本文提出了一种新颖的神经符号框架，以增强大语言模型的空间推理能力。我们在两个基准数据集(StepGame和SparQA)上评估了我们的方法，实施了三种不同的策略:(1)基于回答集编程(ASP)的符号推理；(2)使用DSPy的大语言模型 + 回答集编程管道；(3)事实 + 逻辑规则。我们的实验表明，与基线提示方法相比有显著改进，在StepGame数据集上准确率提高了40 - 50%，在更复杂的SparQA数据集上提高了3 - 13%。“大语言模型 + 回答集编程”管道在寻找关系(FR)和寻找块(FB)问题的任务中取得了特别好的结果，尽管在不同类型的问题上表现有所不同。我们令人印象深刻的结果表明，虽然神经符号方法为增强大语言模型的空间推理能力提供了有前景的方向，但其有效性在很大程度上取决于具体的任务特征和实施策略。我们提出了一套使用神经符号管道的集成、简单而有效的策略，以提高大语言模型的空间推理能力。该管道及其策略在大语言模型的其他推理领域(如时间推理、演绎推理等)表现出了很强的泛化性和更广泛的适用性。

---

*Correspondence to R. W., Email:rongw. de@gmail.com

* 通信作者:王荣，邮箱:rongw.de@gmail.com

---

Keywords: reasoning abilities, ASP, neural-symbolic integration, two stages, generaliability, pipeline, multi-agent AI

关键词:推理能力；回答集编程；神经符号集成；两个阶段；泛化性；管道；多智能体人工智能

## 1 Introduction

## 1 引言

Large Language Models (LLMs) are known for their impressive performance across a range of tasks, demonstrating certain commonsense reasoning abilities. However, since LLMs are trained to predict subsequent words in a sequence, they seem to lack sufficient grounding to excel at tasks requiring spatial, physical, and embodied reasoning. Recent studies (Bang et al., 2023; Cohn, 2023), highlighted the limitations of models like ChatGPT in deductive logical reasoning, spatial reasoning and non-textual semantic reasoning, underlining the need for further improvements in spatial reasoning.

大语言模型(LLMs)以其在一系列任务中的出色表现而闻名，展现出了一定的常识推理能力。然而，由于大语言模型是为预测序列中的后续单词而训练的，它们似乎缺乏足够的基础来在需要空间、物理和具身推理的任务中表现出色。最近的研究(Bang等人，2023；科恩，2023)强调了像ChatGPT这样的模型在演绎逻辑推理、空间推理和非文本语义推理方面的局限性，凸显了在空间推理方面进一步改进的必要性。

Spatial reasoning is a crucial cognitive function that enables humans to conceptualize and predict the movement and interactions of objects in two or three-dimensional spaces (Byrne and Johnson-Laird, 1989). Spatial reasoning is one essential part of reasoning and inference. Reasoning and inference are essential building blocks in advancing Artificial General Intelligence (AGI), which aims to create AI systems that can perform at or beyond human levels across a wide range of cognitive tasks (Kumar et al., 2023). If LLMs are to approach AGI, they must be equipped with spatial reasoning abilities comparable to those of humans. These capabilities are not only valuable in themselves but also essential for LLM-based applications in robotics, task planning, path planning, and navigation (Sharma, 2023; Chen et al., 2024).

空间推理是一项至关重要的认知功能，它使人类能够概念化和预测物体在二维或三维空间中的运动和相互作用(伯恩和约翰逊 - 莱尔德，1989)。空间推理是推理和推断的重要组成部分。推理和推断是推进通用人工智能(AGI)的基本要素，通用人工智能旨在创建能够在广泛的认知任务中达到或超越人类水平的人工智能系统(库马尔等人，2023)。如果大语言模型要接近通用人工智能，它们必须具备与人类相当的空间推理能力。这些能力不仅本身有价值，而且对于基于大语言模型的机器人、任务规划、路径规划和导航应用也至关重要(夏尔马，2023；陈等人，2024)。

Spatial reasoning includes two primary categories: quantitative and qualitative reasoning. Quantitative spatial reasoning involves precise mathematical computations of spatial properties such as distances, angles, coordinates, and dimensions. In contrast, qualitative spatial reasoning (QSR) deals with more abstract, symbolic relationships and relative positions between objects (Cohn and Renz, 2008). QSR comprises directional relations describing how objects are oriented relative to each other (e.g., "north", "left"), distance relations capturing relative proximity (e.g., "near", "far"), and topological relations characterizing how spatial regions connect and contain each other (e.g., "inside", "overlapping", "disconnected"). LLMs face significant challenges in processing these spatial relationships, as they must not only comprehend semantic descriptions of scenes but also perform complex multi-hop reasoning about how objects relate to one another in space (Li et al., 2024a; Yang et al., 2024).

空间推理主要包括两类:定量推理和定性推理。定量空间推理涉及对空间属性(如距离、角度、坐标和尺寸)进行精确的数学计算。相比之下，定性空间推理(QSR)处理物体之间更抽象、符号化的关系和相对位置(科恩和伦茨，2008)。定性空间推理包括描述物体彼此相对方向的方向关系(如“北”“左”)、捕捉相对接近程度的距离关系(如“近”“远”)以及表征空间区域如何相互连接和包含的拓扑关系(如“内部”“重叠”“不相连”)。大语言模型在处理这些空间关系时面临重大挑战，因为它们不仅要理解场景的语义描述，还要对物体在空间中的相互关系进行复杂的多跳推理(李等人，2024a；杨等人，2024)。

Traditional approaches in LLMs mainly rely on free-form prompting in a single call to LLMs for facilitating spatial reasoning. However, these methods have demonstrated notable limitations, particularly on challenging datasets like StepGame (Shi et al., 2022) and SparQA (Mirzaee and Kordjamshidi, 2022), which require multi-step planning. In these scenarios, LLMs often struggle with maintaining coherence, frequently hallucinating or losing sight of the original objectives, resulting in inaccurate and unreliable outputs. Recent advancements have shown promise in augmenting LLMs with external tools for tasks requiring arithmetic, navigation, and knowledge base lookups (Fang et al., 2024). However, these efforts are insufficient for enhancing spatial reasoning in LLMs significantly. Recent studies have introduced neural-symbolic strategies, such as ASP (Answer Set Programming) (Yang et al., 2023), to address the limitations of prompting-based approaches. Neural-symbolic methods typically follow a two-step process: extracting facts using LLMs and then applying logical reasoning. As is known, LLMs excel at extracting facts but struggle with reasoning. However, integrating logical reasoning can effectively bridge this gap in their reasoning capabilities. This approach therefore mitigates the weaknesses of reasoning in LLMs and has been shown to significantly outperform prompting methods (Mirzaee and Kordjamshidi, 2023). However, despite their advantages, current research on employing neural-symbolic approaches to enhance LLMs' spatial reasoning capabilities still faces several challenges. For example, some research merely tested performance on specific datasets without comprehensive evaluation (Yang et al., 2023). Some researchers have not properly applied neural-symbolic methods (Li et al., 2024a). Furthermore, some studies fail to fully explore LLMs' spatial reasoning by implementing incomplete feedback loops via multiple LLMs (Mirzaee and Kordjamshidi, 2023). A detailed analysis is presented in the related work section. Such limitations require the need for more rigorous, integrated and effective approaches.

大语言模型(LLMs)的传统方法主要依赖于单次调用大语言模型时的自由形式提示来促进空间推理。然而，这些方法已显示出显著的局限性，特别是在像StepGame(Shi等人，2022年)和SparQA(Mirzaee和Kordjamshidi，2022年)这样需要多步规划的具有挑战性的数据集上。在这些场景中，大语言模型往往难以保持连贯性，经常产生幻觉或忽视原始目标，导致输出不准确且不可靠。最近的进展表明，在需要算术、导航和知识库查询的任务中，为大语言模型配备外部工具是有前景的(Fang等人，2024年)。然而，这些努力不足以显著增强大语言模型的空间推理能力。最近的研究引入了神经符号策略，如回答集编程(ASP，Answer Set Programming)(Yang等人，2023年)，以解决基于提示的方法的局限性。神经符号方法通常遵循两步过程:使用大语言模型提取事实，然后应用逻辑推理。众所周知，大语言模型擅长提取事实，但在推理方面存在困难。然而，集成逻辑推理可以有效弥补其推理能力的这一差距。因此，这种方法减轻了大语言模型在推理方面的弱点，并且已被证明明显优于提示方法(Mirzaee和Kordjamshidi，2023年)。然而，尽管有这些优点，目前关于采用神经符号方法增强大语言模型空间推理能力的研究仍然面临一些挑战。例如，一些研究仅在特定数据集上测试性能，而没有进行全面评估(Yang等人，2023年)。一些研究人员没有正确应用神经符号方法(Li等人，2024a)。此外，一些研究通过多个大语言模型实施不完整的反馈循环，未能充分探索大语言模型的空间推理能力(Mirzaee和Kordjamshidi，2023年)。相关工作部分将进行详细分析。这些局限性需要更严谨、集成和有效的方法。

To address these limitations, we propose a systematic pipeline that effectively enhances LLMs' spatial reasoning capabilities. Our approach combines strategic prompting with symbolic reasoning to create a robust framework that significantly improves performance of spatial reasoning across different LLM architectures. By integrating feedback loops and ASP-based verification, our methodology demonstrates strong generalizability when tackling complex spatial reasoning tasks. Specifically, building on these insights, we propose a novel neural-symbolic pipeline that integrates LLMs with ASP, aimed at enhancing the LLMs' capabilities of spatial reasoning in SparQA and StepGame datasets. We investigate the potential benefits of integrating symbolic reasoning components into LLMs to further boost their spatial reasoning capabilities. Within the broader field of neural-symbolic AI, the combination of LLMs as parsers with ASP solvers has emerged as a particularly effective approach for complex reasoning tasks. Additionally, the present study is one of the pioneering projects which uses DSPy (Khattab et al., 2023) to pipeline and program LLM.

为了解决这些局限性，我们提出了一个系统的流程，该流程能有效增强大语言模型的空间推理能力。我们的方法将策略性提示与符号推理相结合，创建了一个强大的框架，显著提高了不同大语言模型架构下的空间推理性能。通过集成反馈循环和基于回答集编程(ASP)的验证，我们的方法在处理复杂的空间推理任务时表现出很强的泛化能力。具体而言，基于这些见解，我们提出了一种新颖的神经符号流程，将大语言模型与回答集编程(ASP)集成，旨在增强大语言模型在SparQA和StepGame数据集上的空间推理能力。我们研究了将符号推理组件集成到大语言模型中以进一步提升其空间推理能力的潜在益处。在更广泛的神经符号人工智能领域，将大语言模型作为解析器与回答集编程(ASP)求解器相结合已成为处理复杂推理任务的一种特别有效的方法。此外，本研究是最早使用DSPy(Khattab等人，2023年)对大语言模型进行流程化和编程的项目之一。

Our pipeline's effectiveness is evident across diverse datasets, ranging from simple directional relationships to intricate spatial configurations involving multiple objects and relationships. This systematic approach not only boosts performance but also provides a transparent and reproducible framework for spatial reasoning tasks. Unlike previous methods that work only with specific models or simple scenarios, our strategy can be adapted to various LLMs and maintains its effectiveness and generalizability across different levels of complexity in spatial reasoning challenges. The current study addresses the following research questions:

我们的流程在各种数据集上的有效性显而易见，从简单的方向关系到涉及多个对象和关系的复杂空间配置。这种系统的方法不仅提高了性能，还为空间推理任务提供了一个透明且可重复的框架。与之前仅适用于特定模型或简单场景的方法不同，我们的策略可以适应各种大语言模型，并且在不同复杂程度的空间推理挑战中都能保持其有效性和泛化能力。本研究解决了以下研究问题:

1) How does the performance of our integrating symbolic modules compare with the strategies proposed in previous related work?

1) 我们集成符号模块的方法与之前相关工作中提出的策略相比，性能如何？

2) Why can the integration of symbolic modules enhance the performance of LLMs in spatial reasoning tasks?

2) 为什么集成符号模块可以增强大语言模型在空间推理任务中的性能？

## 2 Related Work

## 2 相关工作

### 2.1 Prompting LLMs for spatial reasoning

### 2.1 为空间推理对大语言模型进行提示

Research in spatial reasoning includes both visual and textual domains, with Visual Spatial Reasoning (VSR) facing challenges even in advanced models like CLIP (Radford et al., 2021). On the other hand, text-based reasoning adds complexity due to linguistic ambiguity (Landau and Jackendoff, 1993). Recent studies by Rozanova et al. (2021) and Mirzaee and Kordjamshidi (2022) have explored transformer models and introduced SparQA, addressing challenges in bridging symbolic language and spatial concepts (Tenbrink and Kuhn, 2011), with (Geibinger, 2023) advancing neural-symbolic approaches. The field has evolved through various traditional prompting strategies to enhance LLM reasoning capabilities, including chain of thought (CoT) (Wei et al., 2022; Chu et al., 2023), few-shot prompting (Schick and Schütze, 2021), least-to-most prompting (Zhou et al., 2022), and self-consistency (Wang et al., 2022b), with newer techniques like tree of thoughts, visualization of thought (Wang et al., 2023), and program-aided language models (Gao et al., 2022) further advancing structured, interpretable approaches for complex reasoning tasks.

空间推理研究涵盖视觉和文本领域，即使在像CLIP(拉德福德等人，2021年)这样的先进模型中，视觉空间推理(Visual Spatial Reasoning，VSR)仍面临挑战。另一方面，基于文本的推理由于语言歧义性而增加了复杂性(兰道和杰肯多夫，1993年)。罗扎诺娃等人(2021年)以及米尔扎伊和科尔贾姆希迪(2022年)最近的研究探索了Transformer模型，并推出了SparQA，以应对弥合符号语言和空间概念之间差距的挑战(滕布林克和库恩，2011年)，盖宾格(2023年)则推动了神经符号方法的发展。该领域通过各种传统的提示策略来提升大语言模型(LLM)的推理能力，包括思维链(Chain of Thought，CoT)(魏等人，2022年；朱等人，2023年)、少样本提示(肖伊克和舒尔策，2021年)、从易到难提示(周等人，2022年)和自一致性(王等人，2022b)，而像思维树、思维可视化(王等人，2023年)和程序辅助语言模型(高等人，2022年)等新技术则进一步推动了用于复杂推理任务的结构化、可解释方法的发展。

### 2.2 Neural-symbolic approach to reasoning

### 2.2 推理的神经符号方法

Neural-symbolic AI has a long history. However, it remained a rather new topic until recently, driven largely by breakthrough advances in deep learning and transformer architectures. Despite deep learning's success, its limitations in reasoning, interpretability, and generalization have driven interest in combining neural and symbolic approaches to employ their complementary strengths.

神经符号人工智能有着悠久的历史。然而，直到最近它仍是一个相当新的话题，这在很大程度上得益于深度学习和Transformer架构的突破性进展。尽管深度学习取得了成功，但其在推理、可解释性和泛化能力方面的局限性促使人们对结合神经和符号方法以发挥它们的互补优势产生了兴趣。

Different from the prompting strategies, the core idea behind neural-symbolic approaches is to integrate the strengths of neural networks, such as learning from data and handling uncertainty, with the strengths of symbolic systems, such as logical reasoning and knowledge representation. This integration aims to address the limitations of each approach when used in isolation. As Garcez and Lamb (2023) point out, neural networks often struggle with explicit reasoning and generalization beyond their training distribution, while symbolic systems can be brittle and struggle with real-world data. Hamilton et al. (2022) emphasize that successful AI systems must incorporate rich representations that facilitate precise, human-interpretable inference. By combining neural architectures with symbolic reasoning, researchers aim to create systems capable of learning from experience but applying logical rules to reason about new situations, thereby addressing some shortcomings of purely neural models (Besold et al., 2021).

与提示策略不同，神经符号方法背后的核心思想是将神经网络的优势(如从数据中学习和处理不确定性)与符号系统的优势(如逻辑推理和知识表示)相结合。这种结合旨在解决每种方法单独使用时的局限性。正如加尔塞斯和兰姆(2023年)所指出的，神经网络在进行显式推理和在训练分布之外进行泛化时往往会遇到困难，而符号系统可能比较脆弱，难以处理现实世界的数据。汉密尔顿等人(2022年)强调，成功的人工智能系统必须包含丰富的表示，以促进精确的、人类可解释的推理。通过将神经架构与符号推理相结合，研究人员旨在创建能够从经验中学习，但能应用逻辑规则对新情况进行推理的系统，从而解决纯神经模型的一些缺点(贝索尔德等人，2021年)。

Based on how neural and symbolic components interact and complement each other, these approaches can be categorized into five distinct patterns: Symbolic[neural], where symbolic systems are enhanced with neural capabilities; neural|Symbolic, implementing hybrid pipelines; neural:Symbolic $\rightarrow$ neural, compiling symbolic rules into neural structures; neural $\otimes$ Symbolic, combining logic rules through embeddings; and neural[Symbolic], enhancing neural systems with symbolic reasoning. Although this taxonomy provides valuable insights, there is significant overlap between these patterns, particularly in how they incorporate symbolic reasoning into neural networks. To provide a more practical framework, we can consolidate these approaches into four fundamental integration architectures, each capturing a distinct way of combining neural and symbolic capabilities: a) Neural symbolic Sequential Integration (Weber et al., 2019) ; b) Neural-symbolic Iterative Integration (Evans and Stanovich, 2013; Bellini-Leite, 2022); c) Symbolic Embedded NN architecture (Riegel et al., 2020); d) LLM+Tools (Parisi et al., 2022) (The details are seen in Appendix A). These approaches have inspired us to develop more effective integration neural-symbolic strategies and a generalized integrated pipeline to enhance the performance of spatial reasoning in LLMs.

根据神经和符号组件相互作用和互补的方式，这些方法可以分为五种不同的模式:符号[神经]，即符号系统通过神经能力得到增强；神经|符号，实现混合流水线；神经:符号 $\rightarrow$ 神经，将符号规则编译成神经结构；神经 $\otimes$ 符号，通过嵌入组合逻辑规则；以及神经[符号]，通过符号推理增强神经系 统。尽管这种分类法提供了有价值的见解，但这些模式之间存在显著的重叠，特别是在它们如何将符号推理融入神经网络方面。为了提供一个更实用的框架，我们可以将这些方法整合为四种基本的集成架构，每种架构都体现了一种独特的结合神经和符号能力的方式:a) 神经符号顺序集成(韦伯等人，2019年)；b) 神经符号迭代集成(埃文斯和斯坦诺维奇，2013年；贝利尼 - 莱特，2022年)；c) 符号嵌入神经网络架构(里格尔等人，2020年)；d) 大语言模型 + 工具(帕里西等人，2022年)(详细信息见附录A)。这些方法启发我们开发更有效的神经符号集成策略和通用的集成流水线，以提高大语言模型在空间推理方面的性能。

We take specific examples to demonstrate the effectiveness of neural-symbolic approaches to boosting various systems. Neural-symbolic systems excel in complex applications by blending data-driven learning with rule-based inference across domains like computer vision, NLP, and robotics. They integrate visual recognition with semantic understanding (Mao et al., 2019a), language with logical inference (Yu et al., 2024), and perception with decision-making (Wang et al., 2022a). Spatial-temporal reasoning, crucial in neural-symbolic AI, enhances problem-solving in physical contexts (Lee et al., 2023). In Qualitative Spatial Reasoning (QSR), combining LLMs with spatial calculi (e.g., RCC-8, CDC) strengthens spatial reasoning (Liu et al., 2009; Katerinenko, 2015), while neural-symbolic integration improves geospatial segmentation (Alirezaie et al., 2019). Multi-hop question answering benefits from systems like NLProlog, which merge neural networks with symbolic reasoning for multi-step inference (Weber et al., 2019; Chen et al., 2019). Language contextualization is advanced by systems like PIGLeT, grounding understanding in a 3D world (Zellers et al., 2021), and neural-symbolic VQA, combining visual perception and logical reasoning (Lu et al., 2024). Overall, neural-symbolic approaches enhance explainability through interpretable reasoning paths, improve robustness by handling edge cases and ensuring consistency, and allow flexible integration of domain-specific knowledge.

我们通过具体示例来展示神经符号方法在提升各类系统性能方面的有效性。神经符号系统通过将数据驱动的学习与基于规则的推理相结合，在计算机视觉、自然语言处理(NLP)和机器人技术等领域的复杂应用中表现出色。它们将视觉识别与语义理解相结合(Mao等人，2019a)，将语言与逻辑推理相结合(Yu等人，2024)，以及将感知与决策相结合(Wang等人，2022a)。时空推理在神经符号人工智能中至关重要，它能增强在物理环境中的问题解决能力(Lee等人，2023)。在定性空间推理(QSR)中，将大语言模型(LLMs)与空间演算(如RCC - 8、CDC)相结合可强化空间推理能力(Liu等人，2009；Katerinenko，2015)，而神经符号集成则可改善地理空间分割(Alirezaie等人，2019)。多跳问答受益于像NLProlog这样的系统，该系统将神经网络与符号推理相结合以进行多步推理(Weber等人，2019；Chen等人，2019)。像PIGLeT这样的系统通过将理解建立在三维世界中推进了语言语境化(Zellers等人，2021)，而神经符号视觉问答则结合了视觉感知和逻辑推理(Lu等人，2024)。总体而言，神经符号方法通过可解释的推理路径增强了解释性，通过处理边缘情况并确保一致性提高了鲁棒性，并允许灵活集成特定领域的知识。

Next we focus on neural-symbolic approach on spatial reasoning in LLMs. Yang et al. (2023) proposed a novel strategy to convert language into logic serving as ASP(Answer Set Programs, a logic-based declarative knowledge representation formalism), and claimed to boost LLMs' spatial reasoning capabilities. However, they merely used LLMs to extract some facts. Instead they tested performance on specific datasets without comprehensive evaluations on spatial reasoning on LLMs. In other words, their ASP method is novel but the method was not actually tested on spatial reasoning in the simplistic dataset (i.e., StepGame. Li et al. (2024a) focus on simplistic datasets (i.e., StepGame) by applying some method which is not neural-symbolic. The method in Li et al. (2024a) is essentially language-based prompting strategy. Furthermore, some studies proposed using mutiple LLMs to form multi-agent to facilitate spatial reasoning, attempting to fully explore LLMs' spatial reasoning by implementing via multiple LLMs (Mirzaee and Kordjamshidi, 2023) on another complex test data (i.e., SparQA). However, it seems that Mirzaee and Kordjamshidi (2023) did not realize loop via mutiple LLM agents. These limitations show the need for better and more comprehensive neural-symbolic strategies. In order to overcome these limitations, we propose a systematic pipeline that enhances LLMs' spatial reasoning by combining strategic prompting with symbolic reasoning. Incorporating feedback loops and ASP-based verification, our method generalizes effectively to complex tasks across diverse LLM architectures.

接下来，我们将重点关注大语言模型中用于空间推理的神经符号方法。Yang等人(2023)提出了一种将语言转换为逻辑的新策略，该逻辑可作为回答集程序(ASP，一种基于逻辑的声明式知识表示形式)，并声称能提升大语言模型的空间推理能力。然而，他们仅仅使用大语言模型提取了一些事实。相反，他们在特定数据集上测试性能，而没有对大语言模型的空间推理进行全面评估。换句话说，他们的ASP方法很新颖，但该方法实际上并未在简单数据集(即StepGame)的空间推理上进行测试。Li等人(2024a)通过应用一些非神经符号的方法专注于简单数据集(即StepGame)。Li等人(2024a)的方法本质上是基于语言的提示策略。此外，一些研究提议使用多个大语言模型形成多智能体以促进空间推理，试图通过在另一个复杂测试数据(即SparQA)上通过多个大语言模型来充分探索大语言模型的空间推理能力(Mirzaee和Kordjamshidi，2023)。然而，似乎Mirzaee和Kordjamshidi(2023)没有意识到通过多个大语言模型智能体的循环问题。这些局限性表明需要更好、更全面的神经符号策略。为了克服这些局限性，我们提出了一个系统的流程，通过将策略性提示与符号推理相结合来增强大语言模型的空间推理能力。我们的方法结合了反馈循环和基于ASP的验证，能够有效地推广到不同大语言模型架构的复杂任务中。

Our strategies are grounded in two key observations from prior research. First, LLMs have demonstrated strong capabilities in understanding and generating spatial descriptions, as well as representing abstract spatial relationships and environments through extensive training on diverse textual data, suggesting their ability to learn and reason about spatial concepts from language alone (Santoro et al., 2018; Smith et al., 2022). Second, recent studies have shown that verbalizing visual input and describing 3D environments in natural language can enable LLMs to outperform vision-language models in certain task domains (Geigle et al., 2023; Ghosh et al., 2024; Chen et al., 2024). Building upon these insights, our study aims to push the boundaries of LLMs' spatial reasoning capabilities by proposing novel new strategies. Moreover, by focusing on language, our study seeks to develop methodologies that capitalize on the inherent strengths of LLMs in processing textual information while addressing their limitations in multi-hop reasoning tasks.

我们的策略基于先前研究的两个关键观察结果。首先，大语言模型通过对多样化文本数据的广泛训练，在理解和生成空间描述以及表示抽象空间关系和环境方面表现出强大的能力，这表明它们仅从语言中就能学习和推理空间概念(Santoro等人，2018；Smith等人，2022)。其次，最近的研究表明，将视觉输入转化为语言并以自然语言描述三维环境可以使大语言模型在某些任务领域中超越视觉 - 语言模型(Geigle等人，2023；Ghosh等人，2024；Chen等人，2024)。基于这些见解，我们的研究旨在通过提出新颖的策略来突破大语言模型空间推理能力的界限。此外，通过专注于语言，我们的研究旨在开发利用大语言模型在处理文本信息方面的固有优势，同时解决它们在多跳推理任务中的局限性的方法。

## 3 Methods

## 3 方法

### 3.1 Datasets

### 3.1 数据集

The two test benchmark datasets are taken to help evaluate the effectivenss of our strategies comprehensively: StepGame (Shi et al., 2022), and SparQA (Mirzaee and Kordjamshidi, 2022). The following provides a detailed account of the two datasets.

我们采用两个测试基准数据集来全面评估我们策略的有效性:StepGame(Shi等人，2022)和SparQA(Mirzaee和Kordjamshidi，2022)。以下是对这两个数据集的详细介绍。

StepGame (Shi et al., 2022) is a synthetic spatial question answering dataset featuring Finding Relations questions that require between 1 to 10 reasoning steps to answer. It employs eight spatial relations (top, down, left, right, top-left, top-right, down-left, and down-right) for story generation. The specific details and samples of StepGame are seen in Appendix B1.

StepGame(Shi等人，2022)是一个合成的空间问答数据集，其特色是“寻找关系”问题，回答这些问题需要1到10个推理步骤。它使用了八种空间关系(上、下、左、右、左上、右上、左下和右下)来生成故事。StepGame的具体细节和示例见附录B1。

Mirzaee and Kordjamshidi (2022) introduced SparQA, a textual question answering benchmark for spatial reasoning, highlighting the unique challenges posed by text-based spatial tasks. Their work emphasized the need for models to understand complex spatial relationships described in natural language and to perform multi-hop reasoning to answer questions accurately. The details and samples of SparQA are seen in Appendix B2. The SparQA dataset advances benchmarking for spatial reasoning in AI, offering a more sophisticated and realistic scenario than predecessors like StepGame. Key features include:

米尔扎伊(Mirzaee)和科尔德贾姆希迪(Kordjamshidi)(2022年)推出了SparQA，这是一个用于空间推理的文本问答基准，凸显了基于文本的空间任务所带来的独特挑战。他们的研究强调，模型需要理解自然语言中描述的复杂空间关系，并进行多跳推理以准确回答问题。SparQA的详细信息和示例见附录B2。SparQA数据集推动了人工智能中空间推理的基准测试，与之前的StepGame等基准相比，它提供了更复杂、更真实的场景。其主要特点包括:

- Broader Language Use: SparQA includes longer, more complex sentences (approximately 2.5 times the length of StepGame). Each scenario typically consists of three blocks arranged vertically or horizontally, with around four objects per block, characterized by attributes like size, color, and shape. In a typical context, there are twelve objects across three blocks, with roughly ten explicitly defined relationships.

- 更广泛的语言运用:SparQA包含更长、更复杂的句子(长度约为StepGame的2.5倍)。每个场景通常由三个垂直或水平排列的方块组成，每个方块大约有四个物体，这些物体具有大小、颜色和形状等属性。在一个典型的情境中，三个方块共有十二个物体，大约有十个明确定义的关系。

- Diverse Question Types: SparQA includes Yes/No, FR, CO, and FB question types, often involving multiple objects and relations. For instance, "What is the relation between the blue circle touching the top edge of block $B$ and the small square?"

- 多样的问题类型:SparQA包括是非题(Yes/No)、自由回答题(FR)、选择填空题(CO)和填空简答题(FB)等问题类型，通常涉及多个物体和关系。例如，“与方块$B$上边缘接触的蓝色圆圈和小正方形之间的关系是什么？”

- Complex Relational Dynamics: SparQA incorporates 3D spatial reasoning, topological relations, and distance relations, with candidate choices such as left, above, near to, and additional synonym terms.

- 复杂的关系动态:SparQA纳入了三维空间推理、拓扑关系和距离关系，候选选项包括左、上、靠近等，还有额外的同义词。

- Quantifier Questions: These questions test quantification abilities, e.g., "Are all of the squares in B?" or "Which block has only small black things inside?" demanding higher-level reasoning.

- 量词问题:这些问题测试量化能力，例如，“所有的正方形都在B中吗？”或“哪个方块里面只有黑色小物体？”这需要更高层次的推理。

Both datasets are employed in the present study to test the effectiveness of our proposed strategies. The following sections introduces these strategies applied in enhancing spatial reasoning abilities in LLMs: 1) Answer Set Programming (ASP); 2) Proposed LLM + ASP Pipeline with DSPy. 3) Fact + Logical rules. We applied the first strategy to StepGame and the second and third strategies to both SparQA and StepGame to evaluate their effectiveness through experiments.

本研究使用这两个数据集来测试我们提出的策略的有效性。以下各节介绍了用于增强大语言模型(LLMs)空间推理能力的这些策略:1)答案集编程(ASP)；2)提出的结合DSPy的大语言模型 + 答案集编程管道；3)事实 + 逻辑规则。我们将第一种策略应用于StepGame，将第二种和第三种策略应用于SparQA和StepGame，通过实验评估它们的有效性。

### 3.2 Answer set programming (ASP)

### 3.2 答案集编程(ASP)

ASP is a powerful declarative programming paradigm tailored for complex reasoning tasks, particularly those that involve knowledge representation and combinatorial search problems (Yang et al., 2023). ASP is declarative, meaning problems are defined through logical relationships between entities, while ASP solvers automatically determine solutions that satisfy given conditions. ASP consists of the following elements: facts, rules, constraints and queries. The following briefly describes these elements.

答案集编程(ASP)是一种强大的声明式编程范式，适用于复杂的推理任务，特别是涉及知识表示和组合搜索问题的任务(杨等人，2023年)。ASP是声明式的，这意味着问题是通过实体之间的逻辑关系来定义的，而ASP求解器会自动确定满足给定条件的解决方案。ASP由以下元素组成:事实、规则、约束和查询。下面简要介绍这些元素。

Facts in ASP form the foundation of the problem domain, representing fundamental truths or atoms. These unconditional statements consist of predicates with arguments. For example, in spatial reasoning, predicates might include:

ASP中的事实构成了问题领域的基础，代表基本事实或原子。这些无条件陈述由带有参数的谓词组成。例如，在空间推理中，谓词可能包括:

- block/1: Represents a block with one argument.

- 方块/1:表示带有一个参数的方块。

- object/5: Represents an object with five attributes (name, size, color, shape, block).

- 物体/5:表示具有五个属性(名称、大小、颜色、形状、方块)的物体。

- is $/3$ : Describes spatial relationships between objects.

- 是 $/3$ :描述物体之间的空间关系。

Example facts can be expressed as:

示例事实可以表示为:

---

block(a).

方块(a)。

	object(BlueTriangle, large, blue, triangle, a).

	物体(蓝色三角形, 大, 蓝色, 三角形, a)。

	object(BlackSquare, large, black, square, a).

	物体(黑色正方形, 大, 黑色, 正方形, a)。

		is (BlueTriangle, left, BlackSquare).

		是(蓝色三角形，左侧，黑色正方形)。

---

Rules are essential in ASP as they define relationships between facts and enable the derivation of new knowledge. Expressed as "Head :- Body", rules indicate that if the conditions in the "Body" are true, then the "Head" is also true. For example:

规则在 Answer Set Programming (ASP，答案集编程) 中至关重要，因为它们定义了事实之间的关系，并能够推导出新知识。规则表示为 “头部 :- 主体”，表明如果 “主体” 中的条件为真，那么 “头部” 也为真。例如:

---

is(Object1, Relation, Object2) :-

是(对象 1，关系，对象 2) :-

object(Object1, _, _, _, Block1),

对象(对象 1，_，_，_，块 1)，

	object(Object2, _, _, _, Block2),

	对象(对象 2，_，_，_，块 2)，

is(Block1, Relation, Block2),

是(块 1，关系，块 2)，

Object1 != Object2.

对象 1 != 对象 2。

---

Constraints in ASP narrow down the solution space by eliminating invalid solutions. Unlike rules, constraints are expressed without a Head, meaning that if the Body conditions are satisfied, the answer set is rejected. For instance:

ASP 中的约束通过排除无效解来缩小解空间。与规则不同，约束的表达没有头部，这意味着如果主体条件得到满足，该答案集将被拒绝。例如:

---

:- object(_, large, _, , Block), object(, small, _, _, Block).

:- 对象(_，大，_，_，块)，对象(_，小，_，_，块)。

---

This constraint ensures that large and small objects cannot occupy the same block.

此约束确保大对象和小对象不能占据同一个块。

Queries allow the system to extract specific information by evaluating whether certain conditions are met. For example:

查询允许系统通过评估某些条件是否满足来提取特定信息。例如:

---

	query(Relation) :-

	查询(关系) :-

object(LargeBlueC, large, blue, _, c),

对象(大蓝色 C，大，蓝色，_，c)，

	object(OtherLargeBlue, large, blue, _, OtherBlock),

	对象(其他大蓝色对象，大，蓝色，_，其他块)，

	is (LargeBlueC, Relation, OtherLargeBlue).

	是(大蓝色 C，关系，其他大蓝色对象)。

---

To implement ASP programs, specialized solvers like Clingo, DLV, or Clasp are used. These solvers compute "answer sets" that represent valid solutions satisfying all rules and constraints. Since multiple answer sets may be generated, post-processing is often necessary to extract the most relevant solutions for specific queries.

要实现 ASP 程序，需要使用专门的求解器，如 Clingo、DLV 或 Clasp。这些求解器计算 “答案集”，这些答案集代表满足所有规则和约束的有效解。由于可能会生成多个答案集，因此通常需要进行后处理，以提取与特定查询最相关的解。

### 3.3 Proposed LLM + ASP pipeline with DSPy

### 3.3 提出的基于DSPy的大语言模型(LLM)+ Answer Set Programming(ASP)管道

ASP is a fundamental neural-symbolic strategy in improving LLMs' spatial reasoning. However, some weaknesses are obvious. For instance, recent studies have demonstrated LLMs' effectiveness as semantic parsers, often surpassing traditional parsing tools. While Geibinger (2023) and Eiter et al. (2022) showed promising results integrating LLMs with ASP, challenges remain. Ishay et al. (2023) found LLMs could generate complex ASP programs but often with errors, while Yang et al. (2023) achieved 90% accuracy on StepGame using GPT-3 and ASP, though scalability remains uncertain.

Answer Set Programming(ASP)是提升大语言模型(LLMs)空间推理能力的一种基础神经符号策略。然而，它也存在一些明显的弱点。例如，近期研究表明，大语言模型(LLMs)作为语义解析器十分有效，其性能常常超越传统解析工具。尽管盖宾格(Geibinger，2023年)和艾特等人(Eiter等，2022年)展示了将大语言模型(LLMs)与Answer Set Programming(ASP)相结合的有前景的结果，但挑战依然存在。伊沙伊等人(Ishay等，2023年)发现，大语言模型(LLMs)能够生成复杂的Answer Set Programming(ASP)程序，但常常存在错误；而杨等人(Yang等，2023年)使用GPT - 3和Answer Set Programming(ASP)在StepGame任务中达到了90%的准确率，不过可扩展性仍不确定。

![0195d6f1-41cf-7377-a691-3db4b842a37a_10_281_631_1088_665_0.jpg](images/0195d6f1-41cf-7377-a691-3db4b842a37a_10_281_631_1088_665_0.jpg)

Figure 1: Pipeline of LLM +ASP approach.

图1:大语言模型(LLM)+ Answer Set Programming(ASP)方法的管道流程。

In order to overcome these weaknesses, inspired by Pan et al. (2023)'s LOGIC-LM framework and integration neural-symbolic strategies, we propose a novel neural-symbolic pipeline employing ASP using DSPy that treats the LLM as an agent capable of feedback and iteration. DSPy (Declarative Self-improving Language Programs, pythonically) is a Python framework that uses a declarative and self-improving approach to simplify working with LLMs (Khattab et al., 2023). It automates the optimization of prompts and model tuning, enhancing reliability and scalability in AI applications. By defining tasks and metrics rather than manual prompts, DSPy streamlines the development of various NLP tasks and complex AI systems. The framework of this pipeline is shown in Fig.1.

为了克服这些弱点，受潘等人(Pan等，2023年)的LOGIC - LM框架和集成神经符号策略的启发，我们提出了一种新颖的神经符号管道，该管道使用DSPy采用Answer Set Programming(ASP)，将大语言模型(LLM)视为一个能够进行反馈和迭代的智能体。DSPy(声明式自我改进语言程序，Python化实现)是一个Python框架，它采用声明式和自我改进的方法来简化与大语言模型(LLMs)的交互(卡塔布等人，2023年)。它能自动优化提示和模型调优，提高人工智能应用的可靠性和可扩展性。通过定义任务和指标而非手动编写提示，DSPy简化了各种自然语言处理(NLP)任务和复杂人工智能系统的开发。该管道的框架如图1所示。

The pipeline consists of four main stages: a) Facts Generation Stage: LLM converts natural language descriptions into symbolic formulations and formal queries. b) ASP Refining Stage: LLM iteratively refines the ASP representation over three iterations, adding rules, checking consistency, and incorporating feedback from error messages. c) Symbolic Reasoning Stage: The refined ASP undergoes inference using the Clingo solver, ensuring accurate and explainable reasoning by combining LLM capabilities with logical inference. d) Result Interpretation and Evaluation: This stage involves mapping the Clingo solver's outputs to candidate answers. For certain question types, like Yes/No and Finding-Block questions, the solver's output can directly serve as the correct answer. However, for Finding Relations and Choose Object questions, additional processing is necessary to filter relevant solutions. In the StepGame context, outputs from the ASP solver are evaluated against a synonym dictionary to determine accuracy.

该管道主要由四个阶段组成:a) 事实生成阶段:大语言模型(LLM)将自然语言描述转换为符号表达式和形式化查询。b) Answer Set Programming(ASP)精炼阶段:大语言模型(LLM)通过三次迭代对Answer Set Programming(ASP)表示进行迭代精炼，添加规则、检查一致性并结合错误消息的反馈。c) 符号推理阶段:经过精炼的Answer Set Programming(ASP)使用Clingo求解器进行推理，通过将大语言模型(LLM)的能力与逻辑推理相结合，确保推理的准确性和可解释性。d) 结果解释与评估:此阶段涉及将Clingo求解器的输出映射到候选答案。对于某些类型的问题，如是非题和寻找块问题，求解器的输出可直接作为正确答案。然而，对于寻找关系和选择对象问题，则需要额外的处理来筛选相关解决方案。在StepGame情境中，Answer Set Programming(ASP)求解器的输出会与同义词词典进行比对以确定准确性。

Overall, this pipeline requires multiple interactions with LLMs during ASP generation and refinement. We employ the DSPy framework to manage these complex workflows (e.g., interfacing with Llama3 60B DeepSeek and GPT 4.0 mini models via their APIs). DSPy's modular features enhance memory retention between modules, enabling adjustments and optimizations while maintaining workflow integrity.

总体而言，该管道在Answer Set Programming(ASP)生成和精炼过程中需要与大语言模型(LLMs)进行多次交互。我们采用DSPy框架来管理这些复杂的工作流程(例如，通过API与Llama3 60B DeepSeek和GPT 4.0 mini模型进行交互)。DSPy的模块化特性增强了模块间的内存保留能力，能够在保持工作流程完整性的同时进行调整和优化。

Additionally, DSPy optimizes LLM prompts and weights, reducing the need for manual prompt engineering and ensuring consistent performance across datasets. Its optimization compiler iteratively generates and refines prompts, enhancing task performance. To support transparency and debugging, outputs from all modules are logged, capturing errors and providing insights for prompt engineering and system optimization, facilitating continuous improvement of the system and enhancing the integration of neural and symbolic components. In this way, this integrated neural-symbolic pipeline could greatly facilitate spatial reasoning in LLMs.

此外，DSPy优化大语言模型(LLM)的提示和权重，减少了手动提示工程的需求，并确保在不同数据集上的性能一致。其优化编译器会迭代生成和精炼提示，提高任务性能。为了支持透明度和调试，所有模块的输出都会被记录，捕捉错误并为提示工程和系统优化提供见解，促进系统的持续改进并加强神经和符号组件的集成。通过这种方式，这种集成的神经符号管道可以极大地促进大语言模型(LLMs)的空间推理能力。

### 3.4 Fact + logical rules

### 3.4 事实 + 逻辑规则

The "LLM + ASP" approach could have some fundamental limitations in applying neural-symbolic integration to complex spatial reasoning tasks. Despite their strong in-context learning capabilities, LLMs may consistently struggle to generate precise logical programs from few-shot examples, particularly when dealing with the formal syntax requirements of ASP or Prolog. This limitation could become especially pronounced in testing in some complex tasks such as the SparQA, where the iterative refinement process necessitates multiple LLM calls for a single ASP program generation, creating significant computational overhead even with a modest three-iteration limit.

“大语言模型(LLM)+ Answer Set Programming(ASP)”方法在将神经符号集成应用于复杂空间推理任务时可能存在一些根本性的局限性。尽管大语言模型(LLMs)具有强大的上下文学习能力，但它们可能仍然难以从少量示例中生成精确的逻辑程序，尤其是在处理Answer Set Programming(ASP)或Prolog的形式语法要求时。这种局限性在一些复杂任务(如SparQA)的测试中可能会变得尤为明显，在这些任务中，迭代精炼过程需要为单个Answer Set Programming(ASP)程序的生成多次调用大语言模型(LLM)，即使将迭代次数限制在适度的三次，也会产生显著的计算开销。

To address these challenges, we propose an alternative neural-symbolic approach that preserves the advantages of structured knowledge representation while reducing the complexity of formal logical programming. Specifically, inspired by Symbolic Embedded Neural Network architectures, our alternative approach embeds logical rules directly into natural language prompts, enabling LLMs to perform reasoning within structured knowledge representations. Instead of relying on the external logical solver to do the reasoning, this approach explicitly prompts LLMs of which rules should be used for certain scenarios. That is why the approach is termed as "fact +logical rules". It is expected that direct rule application in natural language may offer a more reliable path to spatial reasoning than attempting to generate and execute formal logical programs.

为了应对这些挑战，我们提出了一种替代的神经符号方法，该方法在保留结构化知识表示优势的同时，降低了形式逻辑编程的复杂性。具体而言，受符号嵌入神经网络架构的启发，我们的替代方法将逻辑规则直接嵌入到自然语言提示中，使大语言模型(LLMs)能够在结构化知识表示内进行推理。该方法不是依赖外部逻辑求解器进行推理，而是明确地向大语言模型(LLMs)提示在某些场景下应使用哪些规则。这就是为什么该方法被称为“事实 + 逻辑规则”。预计在自然语言中直接应用规则可能比尝试生成和执行形式逻辑程序提供更可靠的空间推理途径。

![0195d6f1-41cf-7377-a691-3db4b842a37a_12_376_340_898_1833_0.jpg](images/0195d6f1-41cf-7377-a691-3db4b842a37a_12_376_340_898_1833_0.jpg)

Figure 2: The roadmap of this study.

图2:本研究的路线图。

The core principle of our alternative approach aligns with a fundamental aspect of neural-symbolic AI: the translation of raw data into structured, symbolic representations that serve as meaning ASP. By using predicates with precise argument structures, we instruct LLMs to create consistent knowledge representations that serve as an intermediate basis for question answering. This structured approach simplifies the previous complex process of generating and refining ASP code while maintaining the benefits of formal reasoning.

我们的替代方法的核心原则与神经符号人工智能(neural-symbolic AI)的一个基本方面相一致:将原始数据转换为结构化的符号表示，这些表示作为答案集编程(Answer Set Programming，ASP)的语义基础。通过使用具有精确参数结构的谓词，我们指导大语言模型(LLMs)创建一致的知识表示，作为问答的中间基础。这种结构化方法简化了之前生成和优化ASP代码的复杂过程，同时保留了形式推理的优势。

### 3.5 Tools, LLMs and evaluation criteria

### 3.5 工具、大语言模型和评估标准

In our experiments, we used DSPy framework to optimize multi-stage prompting workflows, moving from manual prompt engineering to a structured, automated process. DSPy was key in defining and refining each stage of our pipeline-from converting natural language to logical expressions, to generating Python code, and running ASP tasks with Clingo. This setup allows us to streamline complex reasoning processes and achieve high-quality, multistep outputs. While LangChain could support similar workflows, DSPy's focus on multi-stage LLM optimization made it a better fit for our needs.

在我们的实验中，我们使用DSPy框架来优化多阶段提示工作流程，从手动提示工程转向结构化、自动化的过程。DSPy对于定义和优化我们流程的每个阶段至关重要——从将自然语言转换为逻辑表达式，到生成Python代码，再到使用Clingo运行ASP任务。这种设置使我们能够简化复杂的推理过程，并实现高质量的多步骤输出。虽然LangChain可以支持类似的工作流程，但DSPy专注于多阶段大语言模型优化，使其更符合我们的需求。

To evaluate the effectiveness of our approaches in spatial reasoning comprehensively, we selected three representative LLMs with diverse architectures and capabilities: DeepSeek, Llama3, and GPT4.0 Mini. These LLMs were chosen to ensure a comprehensive assessment across different types of language representations, ranging from lightweight and specialized models like DeepSeek to more advanced general-purpose systems like GPT4.0 Mini. Llama3, known for its balance between performance and computational efficiency, provides an intermediate perspective. By testing our methods on these distinct models, we want to demonstrate the adaptability and robustness of our approach across a variety of LLM architectures and reasoning capacities.

为了全面评估我们的方法在空间推理中的有效性，我们选择了三种具有不同架构和能力的代表性大语言模型:DeepSeek、Llama3和GPT4.0 Mini。选择这些大语言模型是为了确保在不同类型的语言表示上进行全面评估，从像DeepSeek这样的轻量级专业模型到像GPT4.0 Mini这样更先进的通用系统。Llama3以其性能和计算效率之间的平衡而闻名，提供了一个中间视角。通过在这些不同的模型上测试我们的方法，我们希望证明我们的方法在各种大语言模型架构和推理能力上的适应性和鲁棒性。

Moreover, to effectively evaluate the impact of our proposed integration methods, we used "direct prompting" as the baseline for comparison. In the following sections, "direct" is used to refer to this baseline method

此外，为了有效评估我们提出的集成方法的影响，我们使用“直接提示”作为比较的基线。在以下部分，“直接”用于指代这种基线方法

LLM performance evaluation includes a range of metrics depending on the task, such as objectivity, truthfulness, human alignment, fluency, coherence, relevance, and task-specific indicators like BLEU, ROUGE, F1, and exact match. For creative or reasoning-intensive tasks, human assessment is often essential to complement automated measures. Frameworks like LangChain and DSPy offer evaluation tools for LLMs. LangChain includes string-based and semantic metrics, while DSPy provides core metrics for NLP tasks, although it lacks direct support for evaluating Answer Set Programming, where no reference answer exists. Considering these, our study adopts micro-F1 score as the main evaluation metric. Table 1 is the summary of the methods, tools, datasets and LLMs used in the present study. Fig. 2 visualizes the methods, tools, datasets and procedures.

大语言模型的性能评估包括一系列取决于任务的指标，如客观性、真实性、与人类的一致性、流畅性、连贯性、相关性，以及特定任务的指标，如BLEU、ROUGE、F1和精确匹配。对于创造性或推理密集型任务，人工评估通常是对自动化评估的必要补充。像LangChain和DSPy这样的框架为大语言模型提供了评估工具。LangChain包括基于字符串和语义的指标，而DSPy为自然语言处理(NLP)任务提供了核心指标，尽管它缺乏对答案集编程(Answer Set Programming)评估的直接支持，因为在这种情况下不存在参考答案。考虑到这些，我们的研究采用微F1分数作为主要评估指标。表1总结了本研究中使用的方法、工具、数据集和大语言模型。图2直观展示了方法、工具、数据集和流程。

Table 1: Summary of Methods, Tools, and Datasets

表1:方法、工具和数据集总结

<table><tr><td>Method</td><td>Pipeline</td><td>Dataset</td><td>LLMs</td><td>Evaluation Criteria</td></tr><tr><td>Answer set programming (ASP)</td><td>Clingo, DLV, or Clasp</td><td>StepGame</td><td rowspan="3">DeepSeek, Llama3, GPT4.0 mini</td><td rowspan="3">micro F1-score accuracy</td></tr><tr><td>Proposed LLM + ASP pipeline</td><td>DSPy</td><td>StepGame, SparQA</td></tr><tr><td>Fact + logical rules</td><td>DSPy</td><td>StepGame, SparQA</td></tr></table>

<table><tbody><tr><td>方法</td><td>流程</td><td>数据集</td><td>大语言模型(LLMs)</td><td>评估标准</td></tr><tr><td>答案集编程(Answer set programming, ASP)</td><td>Clingo、DLV或Clasp</td><td>StepGame</td><td rowspan="3">DeepSeek、Llama3、GPT4.0 mini</td><td rowspan="3">微F1分数准确率</td></tr><tr><td>提出的大语言模型 + 答案集编程流程</td><td>DSPy</td><td>StepGame、SparQA</td></tr><tr><td>事实 + 逻辑规则</td><td>DSPy</td><td>StepGame、SparQA</td></tr></tbody></table>

## 4 Experiment 1: Proposed LLM + ASP

## 4 实验1:提出的大语言模型(LLM)+ 回答集编程(ASP)

Due to the widespread application of ASP in spatial reasoning tasks and the relative simplicity of the StepGame dataset, we have included the detailed implementation and results in Appendix C. These results serve as a baseline for comparisons with other datasets and methodologies in the spatial reasoning domain.

由于回答集编程(ASP)在空间推理任务中广泛应用，且StepGame数据集相对简单，我们将详细的实现和结果放在附录C中。这些结果作为空间推理领域中与其他数据集和方法进行比较的基线。

In this section, we assess the effectiveness and generalizability of the "LLM + ASP" approach on SparQA, a more challenging benchmark than StepGame, with its longer sentences, varied question types, and complex reasoning requirements.

在本节中，我们评估“大语言模型(LLM)+ 回答集编程(ASP)”方法在SparQA上的有效性和泛化能力。SparQA是一个比StepGame更具挑战性的基准数据集，其句子更长、问题类型多样且推理要求复杂。

### 4.1 Implementation

### 4.1 实现

Due to the task complexity and need for high-quality ASP fact generation, we focused on powerful LLMs: GPT4.0 mini, llama3 70B, and Deepseek 76B. We built a subset of the SparQA dataset with 220 examples (55 from each question type) for model inference.

由于任务的复杂性以及对高质量回答集编程(ASP)事实生成的需求，我们专注于强大的大语言模型(LLM):GPT4.0 mini、llama3 70B和Deepseek 76B。我们构建了一个包含220个示例(每种问题类型55个)的SparQA数据集子集用于模型推理。

We adopted the same pipeline as StepGame to SparQA: (1) Converting Natural Language Context and Question to ASP Facts; (2) Adding Rules and Refining ASP Program; (3) Symbolic Reasoning; (4) Result Mapping and Evaluation.

我们将与StepGame相同的流程应用于SparQA:(1)将自然语言上下文和问题转换为回答集编程(ASP)事实；(2)添加规则并优化回答集编程(ASP)程序；(3)符号推理；(4)结果映射和评估。

The first module prompts LLMs to identify blocks, objects, and relation facts using three predicates: block/1, object/5, and is/3. The second module involves rule adoption and ASP refinement, with manually designed rules for inverse, transitive, and symmetric relations. The specific code and samples are seen in Appendix D.

第一个模块促使大语言模型(LLM)使用三个谓词:block/1、object/5和is/3来识别块、对象和关系事实。第二个模块涉及规则采用和回答集编程(ASP)优化，其中包含为逆关系、传递关系和对称关系手动设计的规则。具体代码和示例见附录D。

### 4.2 Results and discussion

### 4.2 结果与讨论

Our neural-symbolic pipeline showed mixed results across different models and question types, as shown in Table ??. Finding Relation (FR) questions demonstrated significant improvement with accuracy increasing by approximately 20% across all models (from 26.92% to 53.12% on Llama3, 38.18% to 58.94% on Deepseek, and 45.45% to 65.32% on GPT 4.0). Finding Block (FB) questions benefited from structured block/5 predicate representation, showing substantial gains particularly in GPT 4.0 (from 60.91% to 80.49%). Choose Object (CO) questions showed varied results, with GPT-4.0 achieving a notable 15% improvement while other models showed minimal changes. Interestingly, Yes/No (YN) questions performed better with direct prompting across all models, suggesting that simpler question types may not benefit from the additional complexity of neural-symbolic methods.

如表??所示，我们的神经符号流程在不同模型和问题类型上呈现出不同的结果。查找关系(FR)问题在所有模型上都有显著改善，准确率大约提高了20%(Llama3从26.92%提高到53.12%，Deepseek从38.18%提高到58.94%，GPT 4.0从45.45%提高到65.32%)。查找块(FB)问题受益于结构化的block/5谓词表示，特别是在GPT 4.0上有显著提升(从60.91%提高到80.49%)。选择对象(CO)问题的结果各不相同，GPT - 4.0有显著的15%的提升，而其他模型变化不大。有趣的是，是/否(YN)问题在所有模型上直接提示的效果更好，这表明较简单的问题类型可能无法从神经符号方法的额外复杂性中受益。

Table 2: Performance Comparison on SparQA (micro F1-score: Accuracy %) (Note: The $\Delta$ column contains data on the improved accuracy by comparing the "LLM + ASP" method with the "direct" prompting method.)

表2:SparQA上的性能比较(微F1分数:准确率 %)(注:$\Delta$列包含“大语言模型(LLM)+ 回答集编程(ASP)”方法与“直接”提示方法相比的准确率提升数据。)

<table><tr><td>Question Type</td><td>Model</td><td>Direct</td><td>LLM+ASP</td><td>$\Delta$</td></tr><tr><td rowspan="3">FR</td><td>Deepseek</td><td>38.18</td><td>58.94</td><td>$+ {20.76}$</td></tr><tr><td>Llama3</td><td>26.92</td><td>53.12</td><td>+26.20</td></tr><tr><td>GPT4.0</td><td>45.45</td><td>65.32</td><td>+19.87</td></tr><tr><td rowspan="3">FB</td><td>Deepseek</td><td>80.56</td><td>85.37</td><td>+4.81</td></tr><tr><td>Llama3</td><td>66.67</td><td>83.33</td><td>+16.66</td></tr><tr><td>GPT4.0</td><td>60.91</td><td>80.49</td><td>$+ {19.58}$</td></tr><tr><td rowspan="3">YN</td><td>Deepseek</td><td>78.19</td><td>70.90</td><td>-7.29</td></tr><tr><td>Llama3</td><td>78.19</td><td>67.27</td><td>-10.92</td></tr><tr><td>GPT4.0</td><td>58.18</td><td>54.54</td><td>-3.64</td></tr><tr><td rowspan="3">CO</td><td>Deepseek</td><td>48.26</td><td>42.81</td><td>-5.45</td></tr><tr><td>Llama3</td><td>55.77</td><td>57.15</td><td>+1.38</td></tr><tr><td>GPT4.0</td><td>57.69</td><td>72.72</td><td>$+ {15.03}$</td></tr></table>

<table><tbody><tr><td>问题类型</td><td>模型</td><td>直接</td><td>大语言模型+答案集编程(LLM+ASP)</td><td>$\Delta$</td></tr><tr><td rowspan="3">自由回答(FR)</td><td>深度求索(Deepseek)</td><td>38.18</td><td>58.94</td><td>$+ {20.76}$</td></tr><tr><td>羊驼3(Llama3)</td><td>26.92</td><td>53.12</td><td>+26.20</td></tr><tr><td>生成式预训练变换器4.0(GPT4.0)</td><td>45.45</td><td>65.32</td><td>+19.87</td></tr><tr><td rowspan="3">是非题(FB)</td><td>深度求索(Deepseek)</td><td>80.56</td><td>85.37</td><td>+4.81</td></tr><tr><td>羊驼3(Llama3)</td><td>66.67</td><td>83.33</td><td>+16.66</td></tr><tr><td>生成式预训练变换器4.0(GPT4.0)</td><td>60.91</td><td>80.49</td><td>$+ {19.58}$</td></tr><tr><td rowspan="3">问答式(YN)</td><td>深度求索(Deepseek)</td><td>78.19</td><td>70.90</td><td>-7.29</td></tr><tr><td>羊驼3(Llama3)</td><td>78.19</td><td>67.27</td><td>-10.92</td></tr><tr><td>生成式预训练变换器4.0(GPT4.0)</td><td>58.18</td><td>54.54</td><td>-3.64</td></tr><tr><td rowspan="3">选择题(CO)</td><td>深度求索(Deepseek)</td><td>48.26</td><td>42.81</td><td>-5.45</td></tr><tr><td>羊驼3(Llama3)</td><td>55.77</td><td>57.15</td><td>+1.38</td></tr><tr><td>生成式预训练变换器4.0(GPT4.0)</td><td>57.69</td><td>72.72</td><td>$+ {15.03}$</td></tr></tbody></table>

### 4.3 Error analysis

### 4.3 误差分析

The ASP solver outputs reveal four main types of errors when inconsistent with ground truth. Grounding Errors occur due to inconsistent variable naming or undefined objects/relations in the ASP code, highlighting the importance of maintaining consistency between facts and queries. Parsing Errors are caused by unqualified relations, punctuation problems, irrelevant comments, or undefined variables. For example, Deepseek often failed to properly comment code with "%", while GPT-4.0 mini frequently mixed argument orders in block/5 facts.

ASP求解器的输出显示，当与真实情况不一致时，主要存在四种类型的误差。接地误差(Grounding Errors)是由于ASP代码中变量命名不一致或对象/关系未定义而产生的，这凸显了保持事实与查询之间一致性的重要性。解析误差(Parsing Errors)是由不合格的关系、标点问题、无关注释或未定义的变量引起的。例如，Deepseek经常不能正确使用“%”对代码进行注释，而GPT - 4.0 mini则经常在block/5事实中混淆参数顺序。

Satisfiability without Query Results arise when facts and rules are insufficient to solve queries, often due to implied relations not being explicitly coded. Consider this example:

无查询结果的可满足性问题(Satisfiability without Query Results)出现在事实和规则不足以解决查询时，通常是由于隐含关系未被明确编码。考虑以下示例:

"The medium triangle is touching the bottom edge of the block. The circle is below and to the left of the small triangle. It is above the medium triangle."

“中等大小的三角形与方块的底边接触。圆形在小三角形的下方和左侧，且在中等大小三角形的上方。”

Here, the query query (R) :- is (medium_triangle, circle) becomes unsatisfiable without explicit relation definitions.

在此，若没有明确的关系定义，查询query (R) :- is (medium_triangle, circle)将无法得到满足。

Wrong choices occurred when the ASP solver produced logically consistent but incorrect results compared to ground truth. Most parsing and grounding errors occurred during query parsing, particularly with complex spatial descriptions involving multiple objects and nested relations. Different models showed distinct error patterns, suggesting the need for model-specific optimization strategies and prompting approaches.

当ASP求解器产生的结果在逻辑上一致但与真实情况不符时，就会出现错误选择。大多数解析和接地误差发生在查询解析过程中，特别是涉及多个对象和嵌套关系的复杂空间描述时。不同的模型表现出不同的误差模式，这表明需要针对特定模型的优化策略和提示方法。

## 5 Experiment 2: Fact + Logical rules

## 5 实验2:事实 + 逻辑规则

### 5.1 Implementation

### 5.1 实现

The implementation consists of two primary stages. The first stage maintains the initial semantic parsing component from the "LLM + ASP" pipeline, where models convert natural language into structured facts using predefined predicates. This conversion provides a clear and organized foundation for subsequent reasoning steps. In the second stage, rather than generating formal logical programs, LLMs directly apply logical rules (inverse, symmetric, transitive, and inter-block relationships for SparQA dataset, and chain linking based on offset for StepGame) through natural language reasoning to derive new knowledge and answer queries. The specific prompt and code samples are seen in Appendix E.

实现过程主要包括两个阶段。第一阶段保留了“大语言模型(LLM) + ASP”流程中的初始语义解析组件，模型使用预定义的谓词将自然语言转换为结构化事实。这种转换为后续的推理步骤提供了清晰且有条理的基础。在第二阶段，大语言模型不是生成正式的逻辑程序，而是通过自然语言推理直接应用逻辑规则(对于SparQA数据集，包括逆关系、对称关系、传递关系和块间关系；对于StepGame，则是基于偏移的链式链接)来推导新知识并回答查询。具体的提示和代码示例见附录E。

### 5.2 Result

### 5.2 结果

The evaluation demonstrates the effectiveness of the "Facts + Rules" approach across both SparQA and StepGame datasets. Table 3 presents a comprehensive performance comparison. To make the comparison easy to observe, we only report the overall F1 score on the dataset, leaving out the question type accuracy.

评估结果表明，“事实 + 规则”方法在SparQA和StepGame两个数据集上均有效。表3给出了全面的性能比较。为便于观察比较，我们仅报告了数据集上的整体F1分数，省略了问题类型的准确率。

Table 3: Performance Comparison of different methods (micro F1-score: Accuracy %)

表3:不同方法的性能比较(微平均F1分数:准确率 %)

<table><tr><td>Dataset</td><td>Model</td><td>Direct</td><td>$\mathrm{{LLM}} + \mathrm{{ASP}}$</td><td>Facts + Rules</td></tr><tr><td rowspan="3">SparQA</td><td>Deepseek</td><td>61.30</td><td>64.51</td><td>66.12</td></tr><tr><td>Llama3</td><td>56.89</td><td>65.22</td><td>65.69</td></tr><tr><td>GPT4.0 mini</td><td>55.56</td><td>68.27</td><td>61.23</td></tr><tr><td rowspan="3">StepGame</td><td>Deepseek</td><td>33.3</td><td>90.9</td><td>46.2</td></tr><tr><td>Llama3</td><td>29.8</td><td>82.4</td><td>64.3</td></tr><tr><td>GPT4.0 mini</td><td>29.9</td><td>83.2</td><td>58.6</td></tr></table>

<table><tbody><tr><td>数据集</td><td>模型</td><td>直接的</td><td>$\mathrm{{LLM}} + \mathrm{{ASP}}$</td><td>事实 + 规则</td></tr><tr><td rowspan="3">稀疏问答(SparQA)</td><td>深度求索(Deepseek)</td><td>61.30</td><td>64.51</td><td>66.12</td></tr><tr><td>羊驼3(Llama3)</td><td>56.89</td><td>65.22</td><td>65.69</td></tr><tr><td>GPT4.0迷你版</td><td>55.56</td><td>68.27</td><td>61.23</td></tr><tr><td rowspan="3">步骤游戏(StepGame)</td><td>深度求索(Deepseek)</td><td>33.3</td><td>90.9</td><td>46.2</td></tr><tr><td>羊驼3(Llama3)</td><td>29.8</td><td>82.4</td><td>64.3</td></tr><tr><td>GPT4.0迷你版</td><td>29.9</td><td>83.2</td><td>58.6</td></tr></tbody></table>

The "Facts + Rules" method demonstrates competitive performance with the "LLM + ASP" approach on the SparQA dataset while significantly outperforming direct prompting $\left( { > 5\% }\right)$ . This success can be attributed to the elimination of parsing errors and inconsistent naming issues that plagued the ASP-based approach. When the facts are correctly represented and logical rules properly applied, the reasoning process becomes more transparent and reliable.

“事实 + 规则”方法在SparQA数据集上的表现与“大语言模型(LLM) + 答案集编程(ASP)”方法相当，同时显著优于直接提示法$\left( { > 5\% }\right)$。这一成功可归因于消除了困扰基于答案集编程方法的解析错误和命名不一致问题。当事实得到正确表示且逻辑规则得到恰当应用时，推理过程会变得更加透明和可靠。

### 5.3 Extension

### 5.3 扩展

We extended this approach to the StepGame dataset by translating its two-dimensional offset-based rules into natural language prompts. While the performance (66.7-77.2%) does not match the exceptional results of the ASP-based approach (82.4-90.9%), it represents a substantial improvement over baseline direct prompting (29.8-33.3%). Surprisingly, the "Facts + Rule" natural language prompts work especially best for Llama3 70B. This improvement is particularly notable in handling extended reasoning chains (k $\geq  5$ ), where the structured approach provides clear guidance for step-by-step inference.

我们通过将StepGame数据集中基于二维偏移的规则转换为自然语言提示，将这种方法扩展到了该数据集。虽然其性能(66.7 - 77.2%)不如基于答案集编程方法的出色结果(82.4 - 90.9%)，但与基线直接提示法(29.8 - 33.3%)相比有了显著提升。令人惊讶的是，“事实 + 规则”自然语言提示对Llama3 70B模型效果尤其好。这种改进在处理扩展推理链(k $\geq  5$)时尤为明显，其中结构化方法为逐步推理提供了清晰的指导。

The success of this simplified approach illustrates an important principle in neural-symbolic integration: effective reasoning can be achieved by employing LLMs' natural language capabilities within a structured framework, without necessarily requiring formal logical programming. By eliminating the computational overhead of ASP generation and refinement while maintaining the benefits of structured reasoning, this method offers a practical alternative for applications where implementation simplicity and computational efficiency are paramount considerations.

这种简化方法的成功说明了神经符号集成中的一个重要原则:可以在结构化框架内利用大语言模型的自然语言能力实现有效的推理，而不一定需要正式的逻辑编程。通过消除答案集编程生成和优化的计算开销，同时保留结构化推理的优势，这种方法为那些将实现简单性和计算效率作为首要考虑因素的应用提供了一种实用的替代方案。

## 6 Discussion

## 6 讨论

### 6.1 Strengths

### 6.1 优势

Compared with the previous related work (Yang et al., 2023; Li et al., 2024a; Mirzaee and Kordjamshidi, 2023), our results shown in Tables ?? and 3 have made substantial improvements in using neural-symbolic methods to enhance spatial reasoning in LLMs. For example, our neural-symbolic approaches achieved over $\mathbf{{80}}\%$ accuracy on StepGame, and averaged $\mathbf{{60}}\%$ on the more complex SparQA dataset. We first confirm that our integration methods are much more effective. Second, our methods greatly outperform the existing methods. For instance, our experiments demonstrate significant improvements over the baseline prompting methods, with accuracy increases of $\mathbf{{40} - {50}\% }$ on StepGame dataset and $\mathbf{3 - {13}\% }$ on the more complex SparQA dataset. The "LLM + ASP" pipeline achieves particularly strong results on the tasks of Finding Relations (FR) and Finding Block (FB) questions, though performance varies across different question types. Additionally, our methods have formed an integrated pipeline compared with previous related work, and further could be easily applied in other domains. We have addressed our first research question. The following will resolve the second research question.

与之前的相关工作(Yang等人，2023；Li等人，2024a；Mirzaee和Kordjamshidi，2023)相比，我们在表??和表3中展示的结果在使用神经符号方法增强大语言模型的空间推理能力方面有了显著改进。例如，我们的神经符号方法在StepGame数据集上的准确率超过了$\mathbf{{80}}\%$，在更复杂的SparQA数据集上的平均准确率达到了$\mathbf{{60}}\%$。首先，我们证实了我们的集成方法更加有效。其次，我们的方法大大优于现有方法。例如，我们的实验表明，与基线提示方法相比有显著改进，在StepGame数据集上准确率提高了$\mathbf{{40} - {50}\% }$，在更复杂的SparQA数据集上提高了$\mathbf{3 - {13}\% }$。“大语言模型 + 答案集编程”流程在寻找关系(FR)和寻找方块(FB)问题的任务中取得了特别好的结果，尽管不同类型问题的性能有所不同。此外，与之前的相关工作相比，我们的方法形成了一个集成流程，并且可以很容易地应用到其他领域。我们已经解决了第一个研究问题。接下来将解决第二个研究问题。

Our experiments demonstrated the potential of neural-symbolic integration, achieving consistent accuracy above $\mathbf{{80}}\%$ across different models. This success can be attributed to three key factors: (1) the effective separation of semantic parsing and logical reasoning, enabling precise control over each component; (2) the well-defined spatial relationships in a 2D environment, allowing for unambiguous predicate representation; and (3) the efficient handling of multi-hop reasoning chains through explicit logical rules.

我们的实验证明了神经符号集成的潜力，在不同模型上实现了始终高于$\mathbf{{80}}\%$的准确率。这一成功可归因于三个关键因素:(1)语义解析和逻辑推理的有效分离，使得能够对每个组件进行精确控制；(2)二维环境中定义明确的空间关系，允许进行明确的谓词表示；(3)通过明确的逻辑规则有效处理多跳推理链。

We summarize our contributions on using neural-symbloic methods to systematically improve the performance of spatial reasoning in LLMs. The five contributions could be described as follows.

我们总结了在使用神经符号方法系统地提高大语言模型空间推理性能方面的贡献。这五项贡献可描述如下。

First, boost spatial reasoning: our integration methods significantly enhance spatial reasoning in complex tasks across various LLMs. While LLMs can struggle with maintaining consistency over long, complex reasoning chains (like navigating through a series of spatial steps), symbolic modules can enforce strict rules of inference and logic, which enhances accuracy and coherence in spatial tasks. Second, advance neural-symbolic approaches: we provide a cohesive pipeline that strengthens neural-symbolic methods for improving LLM reasoning. Third, structured knowledge representation: our approach facilitates efficient knowledge representation and inference through advanced encoding techniques. Our symbolic modules enable LLMs to handle structured, explicit representations of spatial information, such as geometric shapes, positions, and spatial relationships. This allows LLMs to reason in a more organized and interpretable manner compared to raw, unstructured data processing alone. Forth, robust and generalizable: our approach is robust and highly generalizable, making it suitable for other complex reasoning tasks where LLMs typically struggle, such as temporal and deductive reasoning. Our symbolic reasoning systems are designed to generalize better across a wide range of situations by applying logical rules. Integrating this with the probabilistic nature of LLMs provides the system with a more robust way to infer spatial relationships, even in new or unseen scenarios. Moreover, LLMs are strong in natural language processing, while symbolic systems excel at tasks requiring formal logic. By combining both, LLMs can leverage the flexibility of language generation and the rigor of symbolic reasoning, making spatial tasks more efficient and accurate.

首先，提升空间推理能力:我们的集成方法显著增强了各种大语言模型(LLMs)在复杂任务中的空间推理能力。虽然大语言模型在处理长而复杂的推理链(如完成一系列空间步骤的导航)时可能难以保持一致性，但符号模块可以执行严格的推理和逻辑规则，从而提高空间任务的准确性和连贯性。其次，推进神经符号方法:我们提供了一个连贯的流程，强化了用于改进大语言模型推理的神经符号方法。第三，结构化知识表示:我们的方法通过先进的编码技术促进了高效的知识表示和推理。我们的符号模块使大语言模型能够处理空间信息的结构化、明确表示，如几何形状、位置和空间关系。与仅处理原始的非结构化数据相比，这使大语言模型能够以更有条理和可解释的方式进行推理。第四，鲁棒性和可泛化性:我们的方法具有很强的鲁棒性和高度的可泛化性，适用于大语言模型通常难以处理的其他复杂推理任务，如时间推理和演绎推理。我们的符号推理系统旨在通过应用逻辑规则，在更广泛的情况下实现更好的泛化。将其与大语言模型的概率性质相结合，为系统提供了一种更强大的方式来推断空间关系，即使在新的或未见过的场景中也是如此。此外，大语言模型在自然语言处理方面表现出色，而符号系统在需要形式逻辑的任务中表现卓越。通过将两者结合，大语言模型可以利用语言生成的灵活性和符号推理的严谨性，使空间任务更加高效和准确。

### 6.2 Limitations

### 6.2 局限性

This section focuses on the potential problems and limitations on our approaches and experiments. Our experiments with StepGame and SparQA datasets reveal excellent performance of neural-symbolic integration for spatial reasoning tasks. Through systematic evaluation across different question types and reasoning complexities, we observed distinct performance patterns that illuminate the practical considerations for deploying such systems.

本节重点讨论我们的方法和实验可能存在的问题和局限性。我们在StepGame和SparQA数据集上的实验表明，神经符号集成在空间推理任务中表现出色。通过对不同问题类型和推理复杂度的系统评估，我们观察到了不同的性能模式，这为部署此类系统提供了实际考虑因素。

SparQA saw averaging ${60}\%$ accuracy across four question types. However, the SparQA experiments perform differently across the four questions. First, though the over F1 accuracy is higher than the baseline direct prompting strategy, the performance is not consistent among the four types of questions, particularly in YN questions with quantifiers and implicit spatial relationships. Second, the system struggled with query generation for sophisticated question types, often failing to capture the full semantic complexity of natural language descriptions. Third, the refinement process introduced substantial computational overhead, raising questions about scalability in real-world applications.

SparQA在四种问题类型上的平均准确率为${60}\%$。然而，SparQA实验在这四个问题上的表现各不相同。首先，尽管总体F1准确率高于基线直接提示策略，但在四种问题类型中的表现并不一致，特别是在带有量词和隐含空间关系的是非问题上。其次，系统在为复杂问题类型生成查询时遇到困难，往往无法捕捉自然语言描述的全部语义复杂性。第三，细化过程带来了大量的计算开销，引发了关于在实际应用中可扩展性的问题。

This performance disparity between datasets highlights a crucial challenge in neural-symbolic integration: domain sensitivity. While StepGame's structured environment enabled efficient predicate-based representation, SparQA's naturalistic descriptions exposed the difficulties in maintaining consistent mappings between neural and symbolic components. This observation aligns with Yang et al. (2023) findings regarding the domain-specific nature of knowledge modules in symbolic reasoning. Their work demonstrated that even relatively simple reasoning tasks, such as those in the bAbI dataset, require multiple specialized knowledge modules for different types of reasoning (e.g., temporal reasoning, spatial relations, and basic inference). Creating and maintaining such modules can be time-consuming and requires domain expertise.

数据集之间的这种性能差异凸显了神经符号集成中的一个关键挑战:领域敏感性。虽然StepGame的结构化环境实现了基于谓词的高效表示，但SparQA的自然主义描述暴露了在保持神经和符号组件之间一致映射方面的困难。这一观察结果与Yang等人(2023)关于符号推理中知识模块的领域特定性的研究结果一致。他们的工作表明，即使是相对简单的推理任务，如bAbI数据集中的任务，也需要针对不同类型的推理(如时间推理、空间关系和基本推理)使用多个专门的知识模块。创建和维护这些模块可能很耗时，并且需要领域专业知识。

### 6.3 Future directions

### 6.3 未来方向

The neural-symbolic pipeline allows for more explainable and traceable reasoning processes, addressing a major criticism of pure neural network approaches. Nevertheless, this advantage comes at the cost of increased system complexity and the need for careful design of the interaction between neural and symbolic components. The error-prone nature of converting natural language to logic programs, as observed in our experiments, remains a bottleneck of the neural-symbolic approach. This challenge could be addressed by implementing more effective feedback loops between different models and components in the pipeline. Due to the limitations of the DSPy framework and for model comparison purposes, we relied on a single LLM to refine the ASP program.

神经符号流程允许更具可解释性和可追溯性的推理过程，解决了对纯神经网络方法的主要批评。然而，这一优势是以增加系统复杂性和需要精心设计神经和符号组件之间的交互为代价的。正如我们的实验所观察到的，将自然语言转换为逻辑程序容易出错，这仍然是神经符号方法的一个瓶颈。可以通过在流程中的不同模型和组件之间实施更有效的反馈循环来解决这一挑战。由于DSPy框架的局限性以及为了进行模型比较，我们依靠单个大语言模型来细化答案集编程(ASP)程序。

These limitations point toward several promising directions for future research. Future developments should focus on enhancing the robustness and adaptability of these systems while maintaining their core advantage in combining neural flexibility with symbolic precision.The work on context-aware knowledge graph embeddings (Zhu and Sun, 2024) suggests potential approaches for capturing implicit relationships more effectively. Additionally, incorporating probabilistic reasoning capabilities, as demonstrated by De Raedt et al. (2020), could enhance the system's ability to handle uncertainty in spatial relationships. Furthermore, developing error finding and automatic debugging mechanisms (Gu et al., 2023) could improve the system's reliability and reduce the need for manual intervention.

这些局限性为未来的研究指明了几个有前景的方向。未来的发展应专注于增强这些系统的鲁棒性和适应性，同时保持它们将神经灵活性与符号精确性相结合的核心优势。关于上下文感知知识图嵌入的研究(Zhu和Sun，2024)提出了更有效地捕捉隐含关系的潜在方法。此外，正如De Raedt等人(2020)所展示的，纳入概率推理能力可以增强系统处理空间关系不确定性的能力。此外，开发错误发现和自动调试机制(Gu等人，2023)可以提高系统的可靠性，减少手动干预的需求。

In essence, the neural-symbolic approach treats LLMs as agents within a carefully orchestrated system. This perspective shifts the focus from improving individual LLM performance to optimizing the interplay between different components of the system. Future work should explore optimizing interactions between multiple models and reasoning components, involving more sophisticated orchestration techniques, improved integration of probabilistic reasoning with symbolic solvers, and employing the strengths of different LLMs at various stages of neural-symbolic systems.

从本质上讲，神经符号方法将大语言模型视为精心编排的系统中的智能体。这种观点将重点从提高单个大语言模型的性能转移到优化系统不同组件之间的相互作用。未来的工作应探索优化多个模型和推理组件之间的交互，包括采用更复杂的编排技术、改进概率推理与符号求解器的集成，以及在神经符号系统的各个阶段发挥不同大语言模型的优势。

## 7 Conclusion

## 7 结论

This study introduced a novel neural-symbolic pipeline that effectively enhances LLMs' spatial reasoning capabilities. The experimental results demonstrate significant improvements over traditional neural-symbolic methods, showing enhanced performance in complex spatial reasoning tasks across various LLMs. The evaluation results demonstrate the effectiveness, robustness, and generalizability of our approach. However, challenges remain, as evidenced by the performance discrepancy between the two datasets. While the approach achieved over ${80}\%$ accuracy on StepGame, it averaged ${60}\%$ on the more complex SparQA. This requires to further optimize neural-symbolic systems that generalize effectively across diverse problem domains. Nonetheless, our pipeline and strategies show excellent overall performance and significant advancements in spatial reasoning for LLMs. With further refinement, these methods have the potential to revolutionize spatial reasoning capabilities in LLMs and can be adapted to other reasoning domains, marking a substantial leap in neural-symbolic AI. Our work lays a critical foundation for future breakthroughs in AI, driving forward the quest for more intelligent, interpretable, and efficient systems, and offering a pivotal step toward achieving AGI.

本研究引入了一种新颖的神经符号流程，该流程能有效提升大语言模型(LLMs)的空间推理能力。实验结果表明，与传统的神经符号方法相比，该流程有显著改进，在各种大语言模型的复杂空间推理任务中表现更优。评估结果证明了我们方法的有效性、鲁棒性和泛化性。然而，挑战依然存在，两个数据集之间的性能差异就证明了这一点。虽然该方法在StepGame数据集上达到了超过${80}\%$的准确率，但在更复杂的SparQA数据集上平均准确率为${60}\%$。这需要进一步优化神经符号系统，使其能在不同的问题领域有效泛化。尽管如此，我们的流程和策略在大语言模型的空间推理方面总体表现出色，取得了显著进展。通过进一步改进，这些方法有潜力彻底改变大语言模型的空间推理能力，并可应用于其他推理领域，标志着神经符号人工智能的重大飞跃。我们的工作为未来人工智能的突破奠定了关键基础，推动了对更智能、可解释和高效系统的探索，并为实现通用人工智能(AGI)迈出了关键一步。

## References

## 参考文献

Alirezaie, M., Längkvist, M., Sioutis, M., and Loutfi, A. (2019). Semantic referee: A neural-symbolic framework for enhancing geospatial semantic segmentation. Semantic Web, 10(5):863-880.

Alirezaie, M., Längkvist, M., Sioutis, M., 和 Loutfi, A. (2019). 语义裁判:一种用于增强地理空间语义分割的神经符号框架。《语义网》, 10(5):863 - 880.

Bang, Y., Cahyawijaya, S., Lee, N., Dai, W., Su, D., Wilie, B., Lovenia, H., Ji, Z., Yu, T., Chung, W., et al. (2023). A multitask, multilingual, multimodal evaluation of chatgpt on reasoning, hallucination, and interactivity. In Proceedings of the 13th International Joint Conference on Natural Language Processing and the 3rd Conference of the Asia-Pacific Chapter of the Association for Computational Linguistics (Volume 1: Long Papers), pages 675-718.

Bang, Y., Cahyawijaya, S., Lee, N., Dai, W., Su, D., Wilie, B., Lovenia, H., Ji, Z., Yu, T., Chung, W., 等 (2023). 对ChatGPT在推理、幻觉和交互性方面的多任务、多语言、多模态评估。《第13届自然语言处理国际联合会议和第3届亚太计算语言学协会会议论文集(第1卷:长论文)》, 第675 - 718页。

Bellini-Leite, S. C. (2022). Dual process theory: Embodied and predictive; symbolic and classical. Frontiers in Psychology, 13:805386.

Bellini - Leite, S. C. (2022). 双过程理论:具身与预测；符号与经典。《心理学前沿》, 13:805386.

Besold, T. R., d'Avila Garcez, A., Bader, S., Bowman, H., Domingos, P., Hitzler, P., Kühnberger, K.-U., Lamb, L. C., Lima, P. M. V., de Penning, L., et al. (2021). Neural-symbolic learning and reasoning: A survey and interpretation 1. In Neuro-Symbolic Artificial Intelligence: The State of the Art, pages 1-51. IOS press.

Besold, T. R., d'Avila Garcez, A., Bader, S., Bowman, H., Domingos, P., Hitzler, P., Kühnberger, K. - U., Lamb, L. C., Lima, P. M. V., de Penning, L., 等 (2021). 神经符号学习与推理:一项综述与解读1。《神经符号人工智能:现状》, 第1 - 51页。IOS出版社。

Bhandari, P., Anastasopoulos, A., and Pfoser, D. (2023). Are large language models geospatially knowledgeable? In Proceedings of the 31st ACM International Conference on Advances in Geographic Information Systems, pages 1-4.

Bhandari, P., Anastasopoulos, A., 和 Pfoser, D. (2023). 大语言模型是否具备地理空间知识？《第31届ACM地理信息系统进展国际会议论文集》, 第1 - 4页。

Byrne, R. M. and Johnson-Laird, P. N. (1989). Spatial reasoning. Journal of Memory and Language, 28(5):564-575.

Byrne, R. M. 和 Johnson - Laird, P. N. (1989). 空间推理。《记忆与语言杂志》, 28(5):564 - 575.

Cai, T., Wang, X., Ma, T., Chen, X., and Zhou, D. (2023). Large language models as tool makers. arXiv preprint arXiv:2305.17126.

Cai, T., Wang, X., Ma, T., Chen, X., 和 Zhou, D. (2023). 大语言模型作为工具制造者。预印本arXiv:2305.17126。

Chen, B., Xu, Z., Kirmani, S., Ichter, B., Sadigh, D., Guibas, L., and Xia, F. (2024). Spatialvlm: Endowing vision-language models with spatial reasoning capabilities. In Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition, pages 14455-14465.

Chen, B., Xu, Z., Kirmani, S., Ichter, B., Sadigh, D., Guibas, L., 和 Xia, F. (2024). Spatialvlm:赋予视觉语言模型空间推理能力。《IEEE/CVF计算机视觉与模式识别会议论文集》, 第14455 - 14465页。

Chen, H., Suhr, A., Misra, D., Snavely, N., and Artzi, Y. (2019). Touchdown: Natural language navigation and spatial reasoning in visual street environments. In Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition, pages 12538-12547.

Chen, H., Suhr, A., Misra, D., Snavely, N., 和 Artzi, Y. (2019). 触地得分:视觉街道环境中的自然语言导航和空间推理。《IEEE/CVF计算机视觉与模式识别会议论文集》, 第12538 - 12547页。

Chu, Z., Chen, J., Chen, Q., Yu, W., He, T., Wang, H., Peng, W., Liu, M., Qin, B., and Liu, T. (2023). A survey of chain of thought reasoning: Advances, frontiers and future. ArXiv, abs/2309.15402.

Chu, Z., Chen, J., Chen, Q., Yu, W., He, T., Wang, H., Peng, W., Liu, M., Qin, B., 和 Liu, T. (2023). 思维链推理综述:进展、前沿与未来。预印本arXiv:2309.15402。

Cohn, A. G. (2023). An evaluation of chatgpt-4's qualitative spatial reasoning capabilities in rcc-8. arXiv preprint arXiv:2309.15577.

Cohn, A. G. (2023). 对ChatGPT - 4在RCC - 8中的定性空间推理能力的评估。预印本arXiv:2309.15577。

Cohn, A. G. and Renz, J. (2008). Qualitative spatial representation and reasoning. Foundations of Artificial Intelligence, 3:551-596.

Cohn, A. G. 和 Renz, J. (2008). 定性空间表示与推理。《人工智能基础》, 3:551 - 596.

De Raedt, L., Dumančić, S., Manhaeve, R., and Marra, G. (2020). From statistical relational to neuro-symbolic artificial intelligence. arXiv preprint arXiv:2003.08316.

德·雷德特(De Raedt)，L.，杜曼契奇(Dumančić)，S.，曼哈埃夫(Manhaeve)，R.，以及马拉(Marra)，G.(2020)。从统计关系人工智能到神经符号人工智能。预印本 arXiv:2003.08316。

Eiter, T., Higuera, N., Oetsch, J., and Pritz, M. (2022). A neuro-symbolic asp pipeline for visual question answering. Theory and Practice of Logic Programming, 22(5):739-754.

艾特(Eiter)，T.，伊盖拉(Higuera)，N.，奥埃奇(Oetsch)，J.，以及普里茨(Pritz)，M.(2022)。用于视觉问答的神经符号回答集编程(ASP)管道。《逻辑编程理论与实践》，22(5):739 - 754。

Evans, J. S. B. and Stanovich, K. E. (2013). Dual-process theories of higher cognition: Advancing the debate. Perspectives on psychological science, 8(3):223-241.

埃文斯(Evans)，J. S. B.和斯坦诺维奇(Stanovich)，K. E.(2013)。高级认知的双过程理论:推动辩论发展。《心理科学观点》，8(3):223 - 241。

Fang, M., Deng, S., Zhang, Y., Shi, Z., Chen, L., Pechenizkiy, M., and Wang, J. (2024). Large language models are neurosymbolic reasoners. In Proceedings of the AAAI Conference on Artificial Intelligence, volume 38, pages 17985-17993.

方(Fang)，M.，邓(Deng)，S.，张(Zhang)，Y.，施(Shi)，Z.，陈(Chen)，L.，佩切尼茨基(Pechenizkiy)，M.，以及王(Wang)，J.(2024)。大语言模型是神经符号推理器。《AAAI人工智能会议论文集》，第38卷，第17985 - 17993页。

Gao, L., Madaan, A., Zhou, S., Alon, U., Liu, P., Yang, Y., Callan, J., and Neubig, G. (2022). Pal: Program-aided language models. ArXiv, abs/2211.10435.

高(Gao)，L.，马丹(Madaan)，A.，周(Zhou)，S.，阿隆(Alon)，U.，刘(Liu)，P.，杨(Yang)，Y.，卡兰(Callan)，J.，以及纽比格(Neubig)，G.(2022)。PAL:程序辅助语言模型。预印本，abs/2211.10435。

Garcez, A. d. and Lamb, L. C. (2023). Neurosymbolic ai: The 3 rd wave. Artificial Intelligence Review, 56(11):12387-12406.

加尔塞斯(Garcez)，A. d.和兰姆(Lamb)，L. C.(2023)。神经符号人工智能:第三次浪潮。《人工智能评论》，56(11):12387 - 12406。

Geibinger, T. (2023). Explainable answer-set programming. arXiv preprint arXiv:2308.15901.

盖宾格(Geibinger)，T.(2023)。可解释的回答集编程。预印本 arXiv:2308.15901。

Geigle, G., Jain, A., Timofte, R., and Glavaš, G. (2023). mblip: Efficient bootstrapping of multilingual vision-llms. arXiv preprint arXiv:2307.06930.

盖格尔(Geigle)，G.，贾因(Jain)，A.，蒂莫夫特(Timofte)，R.，以及格拉瓦什(Glavaš)，G.(2023)。mblip:多语言视觉大语言模型的高效引导。预印本 arXiv:2307.06930。

Ghosh, A., Acharya, A., Saha, S., Jain, V., and Chadha, A. (2024). Exploring the frontier of vision-language models: A survey of current methodologies and future directions. arXiv preprint arXiv:2404.07214.

戈什(Ghosh)，A.，阿查里雅(Acharya)，A.，萨哈(Saha)，S.，贾因(Jain)，V.，以及查达(Chadha)，A.(2024)。探索视觉 - 语言模型的前沿:当前方法和未来方向综述。预印本 arXiv:2404.07214。

Gu, K., Jun, E., and Althoff, T. (2023). Understanding and supporting debugging workflows in multiverse analysis. In Proceedings of the 2023 CHI Conference on Human Factors in Computing Systems, pages 1-19.

顾(Gu)，K.，朱恩(Jun)，E.，以及阿尔托夫(Althoff)，T.(2023)。理解和支持多元宇宙分析中的调试工作流程。《2023年人机交互大会论文集》，第1 - 19页。

Hamilton, K., Nayak, A., Božić, B., and Longo, L. (2022). Is neuro-symbolic ai meeting its promises in natural language processing? a structured review. Semantic Web, (Preprint):1-42.

汉密尔顿(Hamilton)，K.，纳亚克(Nayak)，A.，博日奇(Božić)，B.，以及隆戈(Longo)，L.(2022)。神经符号人工智能在自然语言处理中是否实现了其承诺？一项结构化综述。《语义网》，(预印本):1 - 42。

Hersche, M., Zeqiri, M., Benini, L., Sebastian, A., and Rahimi, A. (2023). A neuro-vector-symbolic architecture for solving raven's progressive matrices. Nature Machine Intelligence, 5(4):363-375.

赫舍(Hersche)，M.，泽基里(Zeqiri)，M.，贝尼尼(Benini)，L.，塞巴斯蒂安(Sebastian)，A.，以及拉希米(Rahimi)，A.(2023)。用于解决瑞文推理测验的神经向量符号架构。《自然机器智能》，5(4):363 - 375。

Ishay, A., Yang, Z., and Lee, J. (2023). Leveraging large language models to generate answer set programs. arXiv preprint arXiv:2307.07699.

伊沙伊(Ishay)，A.，杨(Yang)，Z.，以及李(Lee)，J.(2023)。利用大语言模型生成回答集程序。预印本 arXiv:2307.07699。

Katerinenko, R. (2015). Semantic spatial reasoning. In KEOD, pages 257- 262.

卡特里年科(Katerinenko)，R.(2015)。语义空间推理。《知识工程与本体开发国际会议论文集》，第257 - 262页。

Khattab, O., Singhvi, A., Maheshwari, P., Zhang, Z., Santhanam, K., Vard-hamanan, S., Haq, S., Sharma, A., Joshi, T. T., Moazam, H., et al. (2023). Dspy: Compiling declarative language model calls into self-improving pipelines. arXiv preprint arXiv:2310.03714.

哈塔布(Khattab)，O.，辛格维(Singhvi)，A.，马赫什瓦里(Maheshwari)，P.，张(Zhang)，Z.，桑塔纳姆(Santhanam)，K.，瓦尔达哈曼南(Vard - hamanan)，S.，哈克(Haq)，S.，夏尔马(Sharma)，A.，乔希(Joshi)，T. T.，莫扎姆(Moazam)，H.等(2023)。Dspy:将声明式语言模型调用编译为自我改进的管道。预印本 arXiv:2310.03714。

Kumar, S., Jain, N., Arora, R., and Nafis, M. T. (2023). Understanding agi: A comprehensive review of theory and application in artificial general intelligence. Available at SSRN 4957203.

库马尔(Kumar)，S.，贾因(Jain)，N.，阿罗拉(Arora)，R.，以及纳菲斯(Nafis)，M. T.(2023)。理解通用人工智能:通用人工智能理论与应用的全面综述。可在社会科学研究网(SSRN)4957203获取。

Landau, B. and Jackendoff, R. (1993). Whence and whither in spatial language and spatial cognition? Behavioral and Brain sciences, 16(2):255- 265.

兰道(Landau)，B.和杰肯道夫(Jackendoff)，R.(1993)。空间语言和空间认知中的“从何而来”与“去往何处”？《行为与脑科学》，16(2):255 - 265。

Lee, J. H., Sioutis, M., Ahrens, K., Alirezaie, M., Kerzel, M., and Wermter, S. (2023). Neuro-symbolic spatio-temporal reasoning. In Compendium of Neurosymbolic Artificial Intelligence, pages 410-429. IOS Press.

李(Lee)，J. H.、西乌蒂斯(Sioutis)，M.、阿伦斯(Ahrens)，K.、阿里雷扎伊(Alirezaie)，M.、克尔策尔(Kerzel)，M.和韦尔特(Wermter)，S.(2023)。神经符号时空推理。《神经符号人工智能纲要》，第410 - 429页。IOS出版社。

Li, F., Hogg, D. C., and Cohn, A. G. (2024a). Advancing spatial reasoning in large language models: An in-depth evaluation and enhancement using the stepgame benchmark. In Proceedings of the AAAI Conference on Artificial Intelligence, volume 38, pages 18500-18507.

李(Li)，F.、霍格(Hogg)，D. C.和科恩(Cohn)，A. G.(2024a)。推进大语言模型中的空间推理:使用步游戏基准进行深入评估和改进。《AAAI人工智能会议论文集》，第38卷，第18500 - 18507页。

Li, F., Hogg, D. C., and Cohn, A. G. (2024b). Reframing spatial reasoning evaluation in language models: A real-world simulation benchmark for qualitative reasoning. arXiv preprint arXiv:2405.15064.

李(Li)，F.、霍格(Hogg)，D. C.和科恩(Cohn)，A. G.(2024b)。重新构建语言模型中的空间推理评估:用于定性推理的现实世界模拟基准。预印本arXiv:2405.15064。

Liu, W., Sanjiang, L., and Jochen, R. (2009). Combining rcc-8 with qualitative direction calculi: Algorithms and complexity. In Twenty-First International Joint Conference on Artificial Intelligence.

刘(Liu)，W.、三江(Sanjiang)，L.和约亨(Jochen)，R.(2009)。将RCC - 8与定性方向演算相结合:算法与复杂度。《第二十一届国际人工智能联合会议》。

Lu, Z., Afridi, I., Kang, H. J., Ruchkin, I., and Zheng, X. (2024). Surveying neuro-symbolic approaches for reliable artificial intelligence of things. Journal of Reliable Intelligent Environments, 10(3):257-279.

陆(Lu)，Z.、阿夫里迪(Afridi)，I.、康(Kang)，H. J.、鲁奇金(Ruchkin)，I.和郑(Zheng)，X.(2024)。可靠的物联网人工智能的神经符号方法综述。《可靠智能环境杂志》，10(3):257 - 279。

Mao, J., Gan, C., Kohli, P., Tenenbaum, J. B., and Wu, J. (2019a). The neuro-symbolic concept learner: Interpreting scenes, words, and sentences from natural supervision. arXiv preprint arXiv:1904.12584.

毛(Mao)，J.、甘(Gan)，C.、科利(Kohli)，P.、特南鲍姆(Tenenbaum)，J. B.和吴(Wu)，J.(2019a)。神经符号概念学习器:通过自然监督解释场景、单词和句子。预印本arXiv:1904.12584。

Mao, J., Gan, C., Kohli, P., Tenenbaum, J. B., and Wu, J. (2019b). The neuro-symbolic concept learner: Interpreting scenes, words, and sentences from natural supervision. arXiv preprint arXiv:1904.12584.

毛(Mao)，J.、甘(Gan)，C.、科利(Kohli)，P.、特南鲍姆(Tenenbaum)，J. B.和吴(Wu)，J.(2019b)。神经符号概念学习器:通过自然监督解释场景、单词和句子。预印本arXiv:1904.12584。

Mirzaee, R. and Kordjamshidi, P. (2022). Transfer learning with synthetic corpora for spatial role labeling and reasoning. arXiv preprint arXiv:2210.16952.

米尔扎伊(Mirzaee)，R.和科尔贾姆希迪(Kordjamshidi)，P.(2022)。使用合成语料库进行空间角色标注和推理的迁移学习。预印本arXiv:2210.16952。

Mirzaee, R. and Kordjamshidi, P. (2023). Disentangling extraction and reasoning in multi-hop spatial reasoning. arXiv preprint arXiv:2310.16731.

米尔扎伊(Mirzaee)，R.和科尔贾姆希迪(Kordjamshidi)，P.(2023)。解开多跳空间推理中的提取和推理。预印本arXiv:2310.16731。

Pan, L., Albalak, A., Wang, X., and Wang, W. Y. (2023). Logic-lm: Empowering large language models with symbolic solvers for faithful logical reasoning. arXiv preprint arXiv:2305.12295.

潘(Pan)，L.、阿尔巴拉科(Albalak)，A.、王(Wang)，X.和王(Wang)，W. Y.(2023)。逻辑大语言模型(Logic - lm):用符号求解器赋能大语言模型以进行可靠的逻辑推理。预印本arXiv:2305.12295。

Parisi, A., Zhao, Y., and Fiedel, N. (2022). Talm: Tool augmented language models. arXiv preprint arXiv:2205.12255.

帕里西(Parisi)，A.、赵(Zhao)，Y.和菲德尔(Fiedel)，N.(2022)。工具增强语言模型(Talm)。预印本arXiv:2205.12255。

Radford, A., Kim, J. W., Hallacy, C., Ramesh, A., Goh, G., Agarwal, S., Sastry, G., Askell, A., Mishkin, P., Clark, J., et al. (2021). Learning transferable visual models from natural language supervision. In International Conference on Machine Learning, pages 8748-8763. PMLR.

拉德福德(Radford)，A.、金(Kim)，J. W.、哈拉西(Hallacy)，C.、拉梅什(Ramesh)，A.、戈(Goh)，G.、阿加瓦尔(Agarwal)，S.、萨斯特里(Sastry)，G.、阿斯凯尔(Askell)，A.、米什金(Mishkin)，P.、克拉克(Clark)，J.等(2021)。从自然语言监督中学习可迁移的视觉模型。《国际机器学习会议》，第8748 - 8763页。PMLR。

Riegel, R., Gray, A., Luus, F., Khan, N., Makondo, N., Akhalwaya, I. Y., Qian, H., Fagin, R., Barahona, F., Sharma, U., et al. (2020). Logical neural networks. arXiv preprint arXiv:2006.13155.

里格尔(Riegel)，R.、格雷(Gray)，A.、卢斯(Luus)，F.、汗(Khan)，N.、马孔多(Makondo)，N.、阿哈尔瓦亚(Akhalwaya)，I. Y.、钱(Qian)，H.、法金(Fagin)，R.、巴拉霍纳(Barahona)，F.、夏尔马(Sharma)，U.等(2020)。逻辑神经网络。预印本arXiv:2006.13155。

Rozanova, J., Ferreira, D., Dubba, K., Cheng, W., Zhang, D., and Freitas, A. (2021). Grounding natural language instructions: Can large language models capture spatial information? arXiv preprint arXiv:2109.08634.

罗扎诺娃(Rozanova)，J.、费雷拉(Ferreira)，D.、杜巴(Dubba)，K.、程(Cheng)，W.、张(Zhang)，D.和弗雷塔斯(Freitas)，A.(2021)。落实自然语言指令:大语言模型能否捕捉空间信息？预印本arXiv:2109.08634。

Santoro, A., Faulkner, R., Raposo, D., Rae, J., Chrzanowski, M., Weber, T., Wierstra, D., Vinyals, O., Pascanu, R., and Lillicrap, T. (2018). Relational recurrent neural networks. Advances in neural information processing systems, 31.

桑托罗(Santoro)，A.、福克纳(Faulkner)，R.、拉波索(Raposo)，D.、雷(Rae)，J.、赫扎诺夫斯基(Chrzanowski)，M.、韦伯(Weber)，T.、维斯特拉(Wierstra)，D.、维尼亚尔斯(Vinyals)，O.、帕斯卡努(Pascanu)，R.和利利克拉普(Lillicrap)，T.(2018)。关系循环神经网络。《神经信息处理系统进展》，31。

Schick, T. and Schütze, H. (2021). True few-shot learning with prompts-a real-world perspective. Transactions of the Association for Computational Linguistics, 10:716-731.

希克(Schick)，T.和舒策(Schütze)，H.(2021)。从现实世界视角看基于提示的真正少样本学习。《计算语言学协会汇刊》，10:716 - 731。

Serafini, L. and Garcez, A. d. (2016). Logic tensor networks: Deep learning and logical reasoning from data and knowledge. arXiv preprint arXiv:1606.04422.

塞拉菲尼(Serafini)，L.和加尔塞斯(Garcez)，A. d.(2016)。逻辑张量网络:基于数据和知识的深度学习与逻辑推理。预印本arXiv:1606.04422。

Sharma, M. (2023). Exploring and improving the spatial reasoning abilities of large language models. arXiv preprint arXiv:2312.01054.

夏尔马(Sharma)，M.(2023)。探索并提升大语言模型的空间推理能力。预印本arXiv:2312.01054。

Shi, Z., Zhang, Q., and Lipani, A. (2022). Stepgame: A new benchmark for robust multi-hop spatial reasoning in texts. In Proceedings of the AAAI conference on artificial intelligence, volume 36, pages 11321-11329.

施(Shi)，Z.、张(Zhang)，Q.和利帕尼(Lipani)，A.(2022)。Stepgame:文本中鲁棒多跳空间推理的新基准。《AAAI人工智能会议论文集》，第36卷，第11321 - 11329页。

Smith, S., Patwary, M., Norick, B., LeGresley, P., Rajbhandari, S., Casper, J., Liu, Z., Prabhumoye, S., Zerveas, G., Korthikanti, V., et al. (2022). Using deepspeed and megatron to train megatron-turing nlg 530b, a large-scale generative language model. arXiv preprint arXiv:2201.11990.

史密斯(Smith)，S.、帕特瓦里(Patwary)，M.、诺里克(Norick)，B.、勒格雷利(LeGresley)，P.、拉杰班达里(Rajbhandari)，S.、卡斯珀(Casper)，J.、刘(Liu)，Z.、普拉布莫耶(Prabhumoye)，S.、泽尔维斯(Zerveas)，G.、科尔蒂坎蒂(Korthikanti)，V.等(2022)。使用DeepSpeed和Megatron训练大规模生成式语言模型Megatron - Turing NLG 530B。预印本arXiv:2201.11990。

Tenbrink, T. and Kuhn, W. (2011). A model of spatial reference frames in language. In Spatial Information Theory: 10th International Conference, COSIT 2011, Belfast, ME, USA, September 12-16, 2011. Proceedings 10, pages 371-390. Springer.

滕布林克(Tenbrink)，T.和库恩(Kuhn)，W.(2011)。语言中的空间参考框架模型。《空间信息理论:第10届国际会议，COSIT 2011，美国缅因州贝尔法斯特，2011年9月12 - 16日》。会议录10，第371 - 390页。施普林格出版社。

Wang, J., Liu, Z., Zhao, L., Wu, Z., Ma, C., Yu, S., Dai, H., Yang, Q., Liu, Y.-H., Zhang, S., Shi, E., Pan, Y., Zhang, T., Zhu, D., Li, X., Jiang, X., Ge, B., Yuan, Y., Shen, D., Liu, T., and Zhang, S. (2023). Review of large vision models and visual prompt engineering. ArXiv, abs/2307.00855.

王(Wang)，J.、刘(Liu)，Z.、赵(Zhao)，L.、吴(Wu)，Z.、马(Ma)，C.、余(Yu)，S.、戴(Dai)，H.、杨(Yang)，Q.、刘(Liu)，Y. - H.、张(Zhang)，S.、施(Shi)，E.、潘(Pan)，Y.、张(Zhang)，T.、朱(Zhu)，D.、李(Li)，X.、江(Jiang)，X.、葛(Ge)，B.、袁(Yuan)，Y.、沈(Shen)，D.、刘(Liu)，T.和张(Zhang)，S.(2023)。大视觉模型与视觉提示工程综述。预印本ArXiv，abs/2307.00855。

Wang, W., Yang, Y., and Wu, F. (2022a). Towards data-and knowledge-driven artificial intelligence: A survey on neuro-symbolic computing. arXiv preprint arXiv:2210.15889.

王(Wang)，W.、杨(Yang)，Y.和吴(Wu)，F.(2022a)。迈向数据与知识驱动的人工智能:神经符号计算综述。预印本arXiv:2210.15889。

Wang, X., Wei, J., Schuurmans, D., Le, Q., Chi, E., and Zhou, D. (2022b). Self-consistency improves chain of thought reasoning in language models. ArXiv, abs/2203.11171.

王(Wang)，X.、魏(Wei)，J.、舒尔曼斯(Schuurmans)，D.、勒(Le)，Q.、池(Chi)，E.和周(Zhou)，D.(2022b)。自一致性提升语言模型的思维链推理能力。预印本ArXiv，abs/2203.11171。

Weber, L., Minervini, P., Münchmeyer, J., Leser, U., and Rocktäschel, T. (2019). Nlprolog: Reasoning with weak unification for question answering in natural language. arXiv preprint arXiv:1906.06187.

韦伯(Weber)，L.、米内尔维尼(Minervini)，P.、明希迈尔(Münchmeyer)，J.、莱泽(Leser)，U.和罗克塔舍尔(Rocktäschel)，T.(2019)。Nlprolog:用于自然语言问答的弱统一推理。预印本arXiv:1906.06187。

Wei, J., Wang, X., Schuurmans, D., Bosma, M., Chi, E., Xia, F., Le, Q., and Zhou, D. (2022). Chain of thought prompting elicits reasoning in large language models. ArXiv, abs/2201.11903.

魏(Wei)，J.、王(Wang)，X.、舒尔曼斯(Schuurmans)，D.、博斯马(Bosma)，M.、池(Chi)，E.、夏(Xia)，F.、勒(Le)，Q.和周(Zhou)，D.(2022)。思维链提示在大语言模型中引发推理。预印本ArXiv，abs/2201.11903。

Weston, J. E. (2016). Dialog-based language learning. Advances in Neural Information Processing Systems, 29.

韦斯顿(Weston)，J. E.(2016)。基于对话的语言学习。《神经信息处理系统进展》，29。

Yang, S., Gribovskaya, E., Kassner, N., Geva, M., and Riedel, S. (2024). Do large language models latently perform multi-hop reasoning? arXiv preprint arXiv:2402.16837.

杨(Yang)，S.、格里博夫斯卡娅(Gribovskaya)，E.、卡斯纳(Kassner)，N.、盖瓦(Geva)，M.和里德尔(Riedel)，S.(2024)。大语言模型是否潜在地执行多跳推理？预印本arXiv:2402.16837。

Yang, Z., Ishay, A., and Lee, J. (2023). Coupling large language models with logic programming for robust and general reasoning from text. arXiv preprint arXiv:2307.07696.

杨(Yang)，Z.、伊沙伊(Ishay)，A.和李(Lee)，J.(2023)。将大语言模型与逻辑编程相结合以实现文本的鲁棒和通用推理。预印本arXiv:2307.07696。

Yi, K., Wu, J., Gan, C., Torralba, A., Kohli, P., and Tenenbaum, J. (2018). Neural-symbolic vqa: Disentangling reasoning from vision and language understanding. Advances in neural information processing systems, 31.

易(Yi)，K.、吴(Wu)，J.、甘(Gan)，C.、托拉尔巴(Torralba)，A.、科利(Kohli)，P.和特南鲍姆(Tenenbaum)，J.(2018)。神经符号视觉问答:将推理与视觉和语言理解分离。《神经信息处理系统进展》，31。

Yu, F., Zhang, H., Tiwari, P., and Wang, B. (2024). Natural language reasoning, a survey. ACM Computing Surveys, 56(12):1-39.

余(Yu)，F.、张(Zhang)，H.、蒂瓦里(Tiwari)，P.和王(Wang)，B.(2024)。自然语言推理综述。《ACM计算调查》，56(12):1 - 39。

Zellers, R., Holtzman, A., Peters, M., Mottaghi, R., Kembhavi, A., Farhadi, A., and Choi, Y. (2021). Piglet: Language grounding through neuro-symbolic interaction in a 3d world. arXiv preprint arXiv:2106.00188.

泽勒斯(Zellers)，R.，霍尔茨曼(Holtzman)，A.，彼得斯(Peters)，M.，莫塔吉(Mottaghi)，R.，肯巴维(Kembhavi)，A.，法尔哈迪(Farhadi)，A.，和崔(Choi)，Y. (2021)。小猪(Piglet):通过3D世界中的神经符号交互实现语言基础。预印本arXiv:2106.00188。

Zhou, D., Scharli, N., Hou, L., Wei, J., Scales, N., Wang, X., Schuurmans, D., Bousquet, O., Le, Q., and Chi, E. (2022). Least-to-most prompting enables complex reasoning in large language models. ArXiv, abs/2205.10625.

周(Zhou)，D.，沙尔利(Scharli)，N.，侯(Hou)，L.，魏(Wei)，J.，斯凯尔斯(Scales)，N.，王(Wang)，X.，舒尔曼斯(Schuurmans)，D.，布斯凯(Bousquet)，O.，勒(Le)，Q.，和池(Chi)，E. (2022)。从最少到最多提示使大语言模型能够进行复杂推理。预印本arXiv: abs/2205.10625。

Zhu, S. and Sun, S. (2024). Exploring knowledge graph-based neural-symbolic system from application perspective. arXiv preprint arXiv:2405.03524.

朱(Zhu)，S.和孙(Sun)，S. (2024)。从应用角度探索基于知识图谱的神经符号系统。预印本arXiv:2405.03524。

## Appendices

## 附录

## Appendix A: Neural-symbolic approaches

## 附录A:神经符号方法

To provide a more practical framework, we can consolidate these approaches into four fundamental integration architectures, each capturing a distinct way of combining neural and symbolic capabilities:

为了提供一个更实用的框架，我们可以将这些方法整合为四种基本的集成架构，每种架构都体现了一种独特的结合神经和符号能力的方式:

a) Neural/ symbolic Sequential Integration:

a) 神经/符号顺序集成:

In this pipeline architecture, neural networks first process raw input to generate symbolic representations, which are then processed by symbolic reasoners for logical inference. This separation also allows for better interpretability and generalization compared to end-to-end neural approaches. For instance, the Neural-Symbolic VQA system (Yi et al., 2018) demonstrates the effectiveness of sequential integration by first using neural networks to parse visual scenes into structured scene representations, followed by symbolic program execution for reasoning about the scene. Weber et al. (2019) developed NLProlog, which exemplifies the integration of neural networks for processing natural language and Prolog symbolic reasoning for multi-step inference. IBM's neural-vector-symbolic architecture (NVSA) (Hersche et al., 2023) uses an NN as the frontend for perception and semantic parsing, and a symbolic reasoner as the backend for probabilistic abductive reasoning.

在这种流水线架构中，神经网络首先处理原始输入以生成符号表示，然后由符号推理器对这些表示进行逻辑推理。与端到端的神经方法相比，这种分离还能实现更好的可解释性和泛化能力。例如，神经符号视觉问答系统(Neural - Symbolic VQA)(易(Yi)等人，2018)通过首先使用神经网络将视觉场景解析为结构化的场景表示，然后执行符号程序对场景进行推理，展示了顺序集成的有效性。韦伯(Weber)等人(2019)开发了自然语言Prolog(NLProlog)，它体现了用于处理自然语言的神经网络与用于多步推理的Prolog符号推理的集成。IBM的神经向量符号架构(NVSA)(赫舍尔(Hersche)等人，2023)使用神经网络作为前端进行感知和语义解析，使用符号推理器作为后端进行概率溯因推理。

b) Neural-symbolic Iterative Integration: It represents a more sophisticated approach where neural and symbolic components interact in multiple cycles, with each component refining its output based on feedback from the other. This architecture is particularly influenced by cognitive dual-process theories (Evans and Stanovich, 2013; Bellini-Leite, 2022). which posit that human reasoning often involves both intuitive (neural) and analytical (symbolic) processes. The neural-Symbolic Concept Learner (Mao et al., 2019b) exemplifies this integration, showcasing the effectiveness of feedback loops in enhancing reasoning capabilities.

b) 神经符号迭代集成:这代表了一种更复杂的方法，其中神经和符号组件在多个循环中进行交互，每个组件根据来自另一个组件的反馈来改进其输出。这种架构尤其受到认知双过程理论(埃文斯(Evans)和斯坦诺维奇(Stanovich)，2013；贝利尼 - 莱特(Bellini - Leite)，2022)的影响，该理论认为人类推理通常涉及直觉(神经)和分析(符号)两种过程。神经符号概念学习器(Neural - Symbolic Concept Learner)(毛(Mao)等人，2019b)体现了这种集成，展示了反馈循环在增强推理能力方面的有效性。

c) Symbolic Embedded NN architecture: This approach incorporates symbolic rules within neural network structures for enhancing the model interpretability and simultaneous neural learning and symbolic reasoning. It often involves mapping symbolic logic rules onto embeddings that serve as soft constraints or regularizers on the NN's loss function. For instance, logical NNs (Riegel et al., 2020) encode knowledge or domain expertise as symbolic rules (first-order logic or fuzzy logic) that act as constraints on the NN output. Logical tensor networks (LTNs) (Serafini and Garcez, 2016), for instance, use logical formulas to define constraints on the tensor representations, which has proven successful in knowledge graph completion tasks.

c) 符号嵌入神经网络架构:这种方法将符号规则融入神经网络结构中，以增强模型的可解释性，并同时进行神经学习和符号推理。它通常涉及将符号逻辑规则映射到嵌入中，这些嵌入作为神经网络损失函数的软约束或正则化项。例如，逻辑神经网络(Logical NNs)(里格尔(Riegel)等人，2020)将知识或领域专业知识编码为符号规则(一阶逻辑或模糊逻辑)，这些规则作为对神经网络输出的约束。例如，逻辑张量网络(Logical Tensor Networks，LTNs)(塞拉菲尼(Serafini)和加尔塞斯(Garcez)，2016)使用逻辑公式来定义对张量表示的约束，这在知识图谱补全任务中已被证明是成功的。

d) LLM+Tools: The emergence of Large Language Models (LLMs) has given rise to a new neural-symbolic architecture pattern that leverages language models as neural reasoning engines while integrating them with external symbolic tools, APIs, self-defined functions and expert models. This approach represents a significant step forward in combining LLMs' powerful language processing abilities with specialized symbolic reasoning tools, broadening the scope of tasks LLMs can handle. Tool Augmented Language Models (TALM) combine LLMs with non-differentiable tools, demonstrating improved performance on knowledge-heavy and reasoning tasks (Parisi et al., 2022). The LLMs As Tool Makers (LATM) framework introduces a closed-loop system where LLMs create and use their own reusable tools, offering a cost-effective solution for complex reasoning tasks (Cai et al., 2023).

d) 大语言模型+工具:大语言模型(LLMs)的出现催生了一种新的神经符号架构模式，该模式利用语言模型作为神经推理引擎，同时将它们与外部符号工具、应用程序编程接口(APIs)、自定义函数和专家模型集成。这种方法代表了将大语言模型强大的语言处理能力与专门的符号推理工具相结合的重要一步，拓宽了大语言模型能够处理的任务范围。工具增强语言模型(Tool Augmented Language Models，TALM)将大语言模型与不可微工具相结合，在知识密集型和推理任务上表现出了更好的性能(帕里西(Parisi)等人，2022)。大语言模型作为工具制造者(LLMs As Tool Makers，LATM)框架引入了一个闭环系统，其中大语言模型创建并使用自己的可重复使用工具，为复杂推理任务提供了一种经济高效的解决方案(蔡(Cai)等人，2023)。

In the context of spatial reasoning tasks, Cohn (2023) explored integrating LLMs with established QSR calculi, evaluating ChatGPT-4's capabilities in RCC-8 reasoning, while Bhandari et al. (2023) investigated LLMs' geospatial knowledge and reasoning abilities. Alirezaie et al. (2019) proposed a semantic referee framework that uses ontological reasoning to improve geospatial semantic segmentation in satellite imagery. Zellers et al. (2021) introduced PIGLeT, a system that grounds language understanding in a 3D world, combining LLM capabilities with symbolic reasoning about physical interactions.

在空间推理任务的背景下，科恩(Cohn)(2023)探索了将大语言模型与已有的定性空间关系(QSR)演算相结合，评估了ChatGPT - 4在区域连接演算(RCC - 8)推理中的能力，而班达里(Bhandari)等人(2023)研究了大语言模型的地理空间知识和推理能力。阿里雷扎伊(Alirezaie)等人(2019)提出了一个语义裁判框架，该框架使用本体推理来改进卫星图像中的地理空间语义分割。泽勒斯(Zellers)等人(2021)引入了小猪(PIGLeT)系统，该系统将语言理解建立在3D世界中，将大语言模型的能力与关于物理交互的符号推理相结合。

Despite these advances, challenges remain in integrating neural and symbolic components efficiently. Maintaining the speed and adaptability of LLMs while scaling hybrid systems to address real-world complexities is an active research area, as noted by Besold et al. (2021). Striking a balance between the general capabilities of LLMs and the rule-based precision of symbolic systems is essential to create effective hybrid models. Additionally, addressing uncertain or incomplete information by leveraging both neural and symbolic strengths remains a crucial focus within the field.

尽管取得了这些进展，但在有效集成神经和符号组件方面仍存在挑战。正如贝索尔德(Besold)等人(2021年)所指出的，在扩展混合系统以应对现实世界的复杂性时，保持大语言模型(LLMs)的速度和适应性是一个活跃的研究领域。在大语言模型的通用能力和符号系统基于规则的精确性之间取得平衡，对于创建有效的混合模型至关重要。此外，利用神经和符号的优势来处理不确定或不完整的信息仍然是该领域的一个关键焦点。

## B: Test dataset samples

## B:测试数据集样本

## B1: Examples in StepGame

## B1:StepGame中的示例

StepGame, developed by Shi et al. (2022), builds upon the foundational concepts of the bAbI dataset (Weston, 2016) to create a benchmark specifically designed for robust multi-hop spatial reasoning. This innovative dataset employs a grid-based system that introduces increased complexity when testing the models' spatial reasoning abilities. StepGame expands the range of directional spatial relations to include eight distinct categories: top (north), down (south), left (west), right (east), top-left (north-west), top-right (north-east), down-left (south-west), and down-right (south-east). Each relation is defined by unique angles and distances, allowing for comprehensive visual representation on a grid. Additionally, the dataset incorporates an "overlap" relation to address scenarios where objects occupy the same location.

由Shi等人(2022年)开发的StepGame，基于bAbI数据集(Weston，2016年)的基础概念，创建了一个专门用于强大多跳空间推理的基准。这个创新的数据集采用了基于网格的系统，在测试模型的空间推理能力时增加了复杂性。StepGame将方向空间关系的范围扩展到包括八个不同的类别:上(北)、下(南)、左(西)、右(东)、左上(西北)、右上(东北)、左下(西南)和右下(东南)。每个关系由独特的角度和距离定义，允许在网格上进行全面的可视化表示。此外，该数据集纳入了“重叠”关系，以处理对象占据相同位置的场景。

The following are examples from StepGame with reasoning hop of 5 and 10 are shown as follows.

以下是来自StepGame的推理跳数为5和10的示例。

Example 1

示例1

Story:

故事:

- A is below $\mathrm{F}$ with a small gap between them.

- A在$\mathrm{F}$下方，两者之间有一个小间隙。

- E is to the right and above $\mathrm{F}$ at an angle of about 45 degrees.

- E在$\mathrm{F}$的右上方，夹角约为45度。

- A is sitting at the 3:00 position to W.

- A位于W的3点钟位置。

- W presents lower left to V.

- W在V的左下方。

- $\mathrm{O}$ is on the same horizontal plane directly left to $\mathrm{V}$ .

- $\mathrm{O}$与$\mathrm{V}$在同一水平面上，且在$\mathrm{V}$的正左侧。

- G presents lower left to O.

- G在O的左下方。

Question: What is the relation of agent $\mathrm{V}$ to agent $\mathrm{A}$ ? Answer: above Example 2

问题:智能体$\mathrm{V}$与智能体$\mathrm{A}$的关系是什么？答案:上方 示例2

Story:

故事:

- $\mathrm{H}$ is diagonally left and below $\mathrm{X}$ .

- $\mathrm{H}$在$\mathrm{X}$的左下方呈对角线分布。

- G and V are in a vertical line with $\mathrm{G}$ on top.

- G和V在一条垂直线上，$\mathrm{G}$在上方。

- G and $\mathrm{P}$ are vertical and $\mathrm{G}$ is below $\mathrm{P}$ .

- G和$\mathrm{P}$垂直，且$\mathrm{G}$在$\mathrm{P}$下方。

- $\mathrm{C}$ is placed in the left direction of $\mathrm{B}$ .

- $\mathrm{C}$位于$\mathrm{B}$的左侧。

- $\mathrm{Z}$ is at the 6 o’clock position relative to $\mathrm{B}$ .

- $\mathrm{Z}$相对于$\mathrm{B}$位于6点钟方向。

- $\mathrm{P}$ is diagonally above $\mathrm{M}$ to the right at a 45 degree.

- $\mathrm{P}$在$\mathrm{M}$右上方呈45度对角线位置。

- M is placed in the left direction of $\mathrm{C}$ .

- M放置在$\mathrm{C}$的左侧。

- $\mathrm{Z}$ is above and to the right of $\mathrm{T}$ .

- $\mathrm{Z}$在$\mathrm{T}$的右上方。

- $\mathrm{D}$ is over there and $\mathrm{H}$ is on the top of it.

- $\mathrm{D}$在那里，$\mathrm{H}$在它的顶部。

- T is there and $\mathrm{D}$ is at the 5 position of a clock face.

- T在那里，$\mathrm{D}$在钟面的5点钟位置。

![0195d6f1-41cf-7377-a691-3db4b842a37a_31_375_350_897_387_0.jpg](images/0195d6f1-41cf-7377-a691-3db4b842a37a_31_375_350_897_387_0.jpg)

Figure 3: An example in the StepGame, adopted by Li et al. (2024b).

图3:StepGame中的一个示例，取自Li等人(2024b)。

Question: What is the relation of the agent $\mathrm{C}$ to the agent $\mathrm{H}$ ? Answer: upper-left

问题:智能体$\mathrm{C}$与智能体$\mathrm{H}$的关系是什么？答案:左上

The two examples could be visualized by Fig. 3.

这两个示例可以通过图3进行可视化展示。

Although the dataset introduces a range of directional spatial relations and multi-hop reasoning challenges, the single Finding Relation question type may not fully reflect the intricacies of real-world spatial reasoning. Research by Li et al. (2024b) indicates that LLMs often struggle more with constructing object-linking chains from shuffled relations than with the spatial reasoning tasks themselves. Prior research (Yang et al., 2024; Li et al., 2024b) suggests StepGame contains template errors that can distort model performance evaluations. These errors arise from insufficient quality control during the crowdsourcing process, leading to inaccuracies in the relationship mappings used within the dataset. Such flaws can result in misleading assessments of an LLM's spatial reasoning capabilities, as they may perform better or worse if these errors were addressed.

尽管该数据集引入了一系列方向空间关系和多跳推理挑战，但单一的“查找关系”问题类型可能无法完全反映现实世界空间推理的复杂性。Li等人(2024b)的研究表明，大型语言模型(LLMs)在从打乱的关系中构建对象链接链时往往比处理空间推理任务本身更困难。先前的研究(Yang等人，2024；Li等人，2024b)表明，StepGame存在模板错误，这些错误会扭曲模型性能评估。这些错误源于众包过程中质量控制不足，导致数据集中使用的关系映射不准确。此类缺陷可能会导致对大型语言模型空间推理能力的评估产生误导，因为如果解决了这些错误，它们的表现可能会更好或更差。

## B2: Samples in SparQA

## B2:SparQA中的样本

As shown in Fig. 4, SparQA is built upon the NLVR (Natural Language for Visual Reasoning) images, featuring synthetically generated scenes depicting various spatial arrangements. Typically, each scenario consists of three blocks arranged either vertically or horizontally, with each block containing around four objects. Each object is characterized by attributes such as size, color, and shape. In a typical context, there are usually twelve objects distributed across three blocks, along with approximately ten explicitly defined relationships.

如图4所示，SparQA基于NLVR(视觉推理自然语言)图像构建，具有合成生成的场景，描绘了各种空间排列。通常，每个场景由三个垂直或水平排列的块组成，每个块包含大约四个对象。每个对象具有大小、颜色和形状等属性。在典型情况下，通常有十二个对象分布在三个块中，以及大约十个明确定义的关系。

The dataset incorporates a wider range of spatial relationships, including 3D spatial reasoning, topological relations and distance relations. For FR questions, the candidate choices include ['left', 'right', 'above', 'below', 'near to', 'far from', 'touching', 'DK'], but there are more synonym relation names involved in the context and question.

该数据集包含更广泛的空间关系，包括3D空间推理、拓扑关系和距离关系。对于“查找关系”(FR)问题，候选选项包括['左'，'右'，'上'，'下'，'靠近'，'远离'，'接触'，'未知']，但上下文中和问题中涉及更多同义关系名称。

![0195d6f1-41cf-7377-a691-3db4b842a37a_32_379_502_891_689_0.jpg](images/0195d6f1-41cf-7377-a691-3db4b842a37a_32_379_502_891_689_0.jpg)

Figure 4: An example of SparQA created from image (adopted from Mirzaee and Kordjamshidi (2022).)

图4:从图像创建的SparQA示例(取自Mirzaee和Kordjamshidi(2022))。

The dataset covers the four question types, presenting a challenge to question answering tasks. Except Yes/No questions, FR, CO and FB questions often involve more than one answer. Additionally, the question often involves more than two objects and relations. For example, "What is the relation between the blue circle which is touching the top edge of block B and the small square?", "What relations exist between the blue object above the yellow thing and the black object above the black thing?"

该数据集涵盖了四种问题类型，对问答任务提出了挑战。除了是非问题外，“查找关系”(FR)、“计数对象”(CO)和“查找块”(FB)问题通常涉及多个答案。此外，问题通常涉及两个以上的对象和关系。例如，“与块B顶部边缘接触的蓝色圆圈和小正方形之间的关系是什么？”，“黄色物体上方的蓝色物体和黑色物体上方的黑色物体之间存在什么关系？”

- Find Relation (FR): Identify the relationship between two objects.

- 查找关系(FR):识别两个对象之间的关系。

- Find Blocks (FB): Locate a block containing certain objects.

- 查找方块 (FB):定位包含特定对象的方块。

- Choose Object (CO): Select between two/three objects based on the criteria.

- 选择对象 (CO):根据标准在两个/三个对象之间进行选择。

- Yes/No (YN): Determine if a specific claim is true or false.

- 是/否 (YN):判断特定陈述是真是假。

Table 4 provides the information on the differences between the two test datasets.

表 4 提供了两个测试数据集之间差异的信息。

Table 4: Dataset Statistics

表 4:数据集统计信息

<table><tr><td>Metric</td><td>SparQA</td><td>StepGame</td></tr><tr><td>#Sent / Story</td><td>7.42</td><td>1.92</td></tr><tr><td>#Tokens / Story</td><td>132.37</td><td>38.16</td></tr><tr><td>#Tokens / Sent</td><td>17.85</td><td>11.21</td></tr><tr><td>#Tokens / Question</td><td>16.61</td><td>13.0</td></tr></table>

<table><tbody><tr><td>指标</td><td>稀疏问答(SparQA)</td><td>步骤游戏(StepGame)</td></tr><tr><td>每个故事的句子数量</td><td>7.42</td><td>1.92</td></tr><tr><td>每个故事的词元数量</td><td>132.37</td><td>38.16</td></tr><tr><td>每个句子的词元数量</td><td>17.85</td><td>11.21</td></tr><tr><td>每个问题的词元数量</td><td>16.61</td><td>13.0</td></tr></tbody></table>

Note that the original dataset is vast, split into train, dev and test subsets, intended for deep learning models training. For LLMs' evaluation, it is not possible and also not necessary to test on the whole dataset. It is normal to use the subset to do the evaluation. Specifically, this study selected a random subset in a range of 200 to 500 samples from the larger dataset, depending on the specific scenario.

请注意，原始数据集规模庞大，被划分为训练集、开发集和测试集子集，用于深度学习模型的训练。对于大语言模型(LLMs)的评估而言，对整个数据集进行测试既不可行也无必要。使用子集进行评估是正常的做法。具体而言，本研究根据具体场景，从较大的数据集中随机选取了200到500个样本的子集。

## Appendix C: Experiment with StepGame

## 附录C:StepGame实验

This section presents our experiment details and results with the StepGame dataset using the DSPy pipeline. The StepGame features less variable language structure compared to SparQA, characterized by short sentences and a single question type focusing on relations between two agents.

本节介绍了我们使用DSPy管道对StepGame数据集进行的实验细节和结果。与SparQA相比，StepGame的语言结构变化较少，其特点是句子简短，且只有一种聚焦于两个主体之间关系的问题类型。

## C1: Implementations

## C1:实现方式

StepGame dataset is divided into two distinct sets: a clean set and a noise set. The clean set contains exactly $\mathrm{k}$ facts for $\mathrm{k}$ -hop instance, while the noise set includes more than $\mathrm{k}$ facts, with the additional facts serving as distractions. For our experiment, we concentrate exclusively on the clean dataset.

StepGame数据集分为两个不同的集合:干净集和噪声集。干净集为$\mathrm{k}$跳实例($\mathrm{k}$-hop instance)精确包含$\mathrm{k}$个事实，而噪声集包含超过$\mathrm{k}$个事实，额外的事实起到干扰作用。在我们的实验中，我们仅专注于干净数据集。

Another important aspect of the StepGame dataset is its reasoning hops range from 1 to 10 hops, distributed across 10 subsets. Specifically, each subset consists of 10,000 samples, each corresponding to a single reasoning hop.

StepGame数据集的另一个重要方面是其推理跳数范围从1到10跳，分布在10个子集中。具体来说，每个子集包含10,000个样本，每个样本对应一个单一的推理跳数。

To ensure a fair comparison, we adopt the methodology outlined in Yang et al. (2023). We collected the first 100 data instances for each reasoning hop $k \in  \{ 1,\ldots ,{10}\}$ and utilized accuracy metrics to evaluate the results. In our final analysis, we will assess the accuracy within each subset of reasoning hops.

为确保公平比较，我们采用了Yang等人(2023)提出的方法。我们为每个推理跳数$k \in  \{ 1,\ldots ,{10}\}$收集了前100个数据实例，并使用准确率指标来评估结果。在最终分析中，我们将评估每个推理跳数子集中的准确率。

As illustrated in the pipeline, we first prompt the LLM to convert natural language expressions into facts, formatted as "is/3" and "query/2". To ensure consistency, the LLM is instructed to utilize only nine predefined relations: left, right, top, down, top_left, top_right, down_left, and down_right, to represent the fact is("A", relation, "B"). To encourage the large language models to map the relations correctly, we provide extra guidelines on how to do the mapping. For example, If the sentence is describing clock-wise information, then 12 denotes top, 1 and 2 denote top_right, 3 denotes right, 4 and 5 denote down_right, 6 denotes down, 7 and 8 denote down_left, 9 denote left, 10 and 11 denote top_left. If the sentence is describing cardinal directions, then north denotes top, east denotes right, south denotes down, and west denotes left.

如管道所示，我们首先提示大语言模型将自然语言表达转换为事实，格式为“is/3”和“query/2”。为确保一致性，指示大语言模型仅使用九个预定义的关系:左、右、上、下、左上、右上、左下和右下，来表示事实is("A", 关系, "B")。为鼓励大语言模型正确映射这些关系，我们提供了关于如何进行映射的额外指导。例如，如果句子描述的是顺时针信息，那么12表示上，1和2表示右上，3表示右，4和5表示右下，6表示下，7和8表示左下，9表示左，10和11表示左上。如果句子描述的是方位方向，那么北表示上，东表示右，南表示下，西表示左。

Subsequently, we add the customized knowledge module or rule to form the complete ASP code. The knowledge module is adapted from Yang et al. (2023) , rather than relying on the LLM to generate them automatically. The rules are crafted to address qualitative spatial reasoning problems within a 2D grid space, by setting the second queried object as the reference point (0,0)and then using cardinal offsets to iteratively calculate the positions of connected objects. Finally, the position(dx, dy)of the first queried object will be found. Based on the values of distance along both $\mathrm{x}$ and $\mathrm{y}$ axis, the relationship between the first and second queried objects can be determined.

随后，我们添加定制的知识模块或规则以形成完整的回答集编程(ASP)代码。知识模块改编自Yang等人(2023)的研究，而非依赖大语言模型自动生成。这些规则旨在解决二维网格空间内的定性空间推理问题，通过将第二个查询对象设置为参考点(0,0)，然后使用方位偏移量迭代计算相连对象的位置。最后，将找到第一个查询对象的位置(dx, dy)。根据沿$\mathrm{x}$轴和$\mathrm{y}$轴的距离值，可以确定第一个和第二个查询对象之间的关系。

To translate the rules into ASP compatible rules, it looks like the following:

将规则转换为与ASP兼容的规则后，如下所示:

---

	ASP Code

	ASP代码

	location $\left( {{Q2},0,0}\right)  :  -$ query(Q2).

	位置 $\left( {{Q2},0,0}\right)  :  -$ 查询(Q2)。

	offset(overlap, 0, 0; top, 0, 1; down, 0, -1; left, -1, 0; right, 1, 0;

	偏移量(重叠, 0, 0; 上, 0, 1; 下, 0, -1; 左, -1, 0; 右, 1, 0;

${\operatorname{top}}_{l}{eft}, - 1,1;{to}{p}_{r}{ight},1,1;{dow}{n}_{l}{eft}, - 1, - 1;{dow}{n}_{r}{ight},1, - 1)$ .

${is}\left( {A,{R1}, B}\right)  :  - {is}\left( {B,{R2}, A}\right)$ , offset(R2, X, Y), offset(R1, - X, - Y).

${is}\left( {A,{R1}, B}\right)  :  - {is}\left( {B,{R2}, A}\right)$ ,偏移量(R2, X, Y),偏移量(R1, - X, - Y)。

nums(-100..100).

数字范围(-100..100)。

${location}\left( {A,{Xa},{Ya}}\right)  :  - {location}\left( {B,{Xb},{Yb}}\right) ,{nums}\left( {Xa}\right) ,{nums}\left( {Ya}\right) ,{is}\left( {A,{Kind}, B}\right) ,$

offset(Kind, Dx, Dy), $\mathrm{{Xa}} - \mathrm{{Xb}} = \mathrm{{Dx}},\mathrm{{Ya}} - \mathrm{{Yb}} = \mathrm{{Dy}}$ .

偏移量(类型, Dx, Dy), $\mathrm{{Xa}} - \mathrm{{Xb}} = \mathrm{{Dx}},\mathrm{{Ya}} - \mathrm{{Yb}} = \mathrm{{Dy}}$ 。

location (B, Xb, Yb) :- location (A, Xa, Ya), nums (Xb), nums (Yb), is (A, Kind, B),

位置 (B, Xb, Yb) :- 位置 (A, Xa, Ya)，数字 (Xb)，数字 (Yb)，是 (A, 类型, B)，

	offset(Kind, Dx, Dy), $\mathrm{{Xa}} - \mathrm{{Xb}} = \mathrm{{Dx}},\mathrm{{Ya}} - \mathrm{{Yb}} = \mathrm{{Dy}}$ .

	偏移量(类型, Dx, Dy)，$\mathrm{{Xa}} - \mathrm{{Xb}} = \mathrm{{Dx}},\mathrm{{Ya}} - \mathrm{{Yb}} = \mathrm{{Dy}}$ 。

		answer $\left( \mathrm{R}\right)  \mathrel{\text{:=}}$ query(Q1,), location(Q1, X, Y), offset $\left( {R,{Ox},{Oy}}\right) ,({Ox} =  - 1 : X < 0;{Ox} = 0$ :

		答案 $\left( \mathrm{R}\right)  \mathrel{\text{:=}}$ 查询(Q1,)，位置(Q1, X, Y)，偏移量 $\left( {R,{Ox},{Oy}}\right) ,({Ox} =  - 1 : X < 0;{Ox} = 0$ :

$X = 0;{Ox} = 1 : X > 0;{Oy} =  - 1 : Y < 0;{Oy} = 0 : Y = 0;{Oy} = 1 : Y > 0$ ).showanswer $/1$ .

$X = 0;{Ox} = 1 : X > 0;{Oy} =  - 1 : Y < 0;{Oy} = 0 : Y = 0;{Oy} = 1 : Y > 0$ ).显示答案 $/1$ 。

---

Figure 5: ASP code sample

图 5:回答集编程(Answer Set Programming，ASP)代码示例

After proper refinement if necessary, the ASP code will be passed as the inputs for the next module and executed by the external ASP solver Clingo to obtain the results.

如有必要进行适当优化后，ASP 代码将作为下一个模块的输入，并由外部 ASP 求解器 Clingo 执行以获得结果。

While the StepGame dataset is designed to be unique and robust, it is important to note that ambiguities in expressions can lead to multiple answers being returned by the ASP solver. For instance, consider a context-based question involving a 3-hop scenario:

虽然 StepGame 数据集被设计为独特且健壮的，但需要注意的是，表达式中的歧义可能会导致 ASP 求解器返回多个答案。例如，考虑一个涉及 3 跳场景的基于上下文的问题:

- Story: "D is on the left side of and below E. M is over G. M is diagonally left and below E. B is under G."

- 故事:“D 在 E 的左侧且下方。M 在 G 的上方。M 在 E 的左斜下方。B 在 G 的下方。”

- Question: "What is the relation of agent $\mathrm{G}$ to agent $\mathrm{E}$ ?"

- 问题:“主体 $\mathrm{G}$ 与主体 $\mathrm{E}$ 的关系是什么？”

- Ground-Truth Label: "down_left".

- 真实标签:“左下方”。

The relations can be mapped as follows:

这些关系可以映射如下:

- is ( " D " , left , " E " ) .

- 是 ( " D " , 左 , " E " ) 。

- is ("D", down, "E").

- 是 ("D", 下, "E")。

- is ("M", top, "G").

- 是 ("M", 上, "G")。

- is("M", down_left, "E").

- 是("M", 左下方, "E")。

- is ("B", down, "G").

- 是 ("B", 下, "G")。

- query ("G", "E").

- 查询("G", "E")。

When combined with customized rules, the ASP solver returns all possible relations between $\mathrm{G}$ and $\mathrm{E}$ : "down_left, down, down_right, left, top_left". However, if we change the two facts, ("D", left, "E"). is ("D", down, "E") to one fact is ("D", down_left, "E"), we would obtain a singular result from the ASP solver: "down_left," which matches the ground truth label in the dataset.

当与自定义规则结合使用时，回答集编程(ASP)求解器会返回$\mathrm{G}$和$\mathrm{E}$之间的所有可能关系:“左下、下、右下、左、左上”。然而，如果我们将两个事实，即("D", 左, "E")和("D", 下, "E")，改为一个事实("D", 左下, "E")，那么我们将从ASP求解器得到一个单一结果:“左下”，这与数据集中的真实标签相匹配。

However, upon closer examination of the natural language description—"D is on the left side of and below E"-it becomes evident that this does not definitively imply that $\mathrm{D}$ is diagonally down-left from $\mathrm{E}$ , since the spatial distance and arrangement could affect this interpretation. Both Llama 70B and Deepseek tend to separate diagonal relations into two distinct factual representations when other expressions exist between them. Conversely, they consolidate relations into one fact when explicitly described as "left down" or as a diagonal relation. We can see how the ambiguity of natural language plays a role in the conversion of logical expression.

然而，仔细审视自然语言描述——“D在E的左侧且下方”——可以明显看出，这并不一定意味着$\mathrm{D}$在$\mathrm{E}$的左下方对角位置，因为空间距离和排列方式可能会影响这种解读。当两者之间存在其他表达方式时，Llama 70B和Deepseek都倾向于将对角关系拆分为两种不同的事实表示。相反，当明确描述为“左下”或对角关系时，它们会将关系合并为一个事实。由此可见，自然语言的模糊性在逻辑表达式的转换中起到了一定作用。

## C2: Results and discussion

## C2:结果与讨论

Our analysis reveals that the LLM + ASP approach provides a significant advantage, functioning effectively as a quality checker for the dataset. Among 1,000 predictions across various reasoning hops $k \in  \{ 1,\ldots ,{10}\}$ , nearly 100 instances were identified as problematic, stemming from issues within the dataset itself. As the reasoning hop $\mathrm{k}$ increases, a cumulative trend emerges, suggesting that many errors may arise from insufficient quality control over the crowdsourced expressions. Notably, Li et al. (2024b) highlighted that out of eight types of relations examined, only "above" and "left" were found to be free of errors.

我们的分析表明，大语言模型(LLM)+回答集编程(ASP)的方法具有显著优势，能有效地作为数据集的质量检查工具。在跨越各种推理步数$k \in  \{ 1,\ldots ,{10}\}$的1000次预测中，近100个实例被识别为有问题，这些问题源于数据集本身。随着推理步数$\mathrm{k}$的增加，出现了累积趋势，这表明许多错误可能是由于对众包表达式的质量控制不足造成的。值得注意的是，Li等人(2024b)强调，在所研究的八种关系类型中，只有“上方”和“左侧”被发现没有错误。

The inherent ambiguity in natural language significantly contributes to errors in LLM predictions. Despite these challenges, all the three LLMs outperform baseline direct answer prompting and Chain-of-Thought (CoT) prompting for the StepGame dataset by 40-50% improvement. For instance, at reasoning hop $\mathrm{k} = 5$ , accuracy rates for direct prompting were recorded as follows: 38.50%( Llama 70B), 33.33% (Deepseek) and 29.91% (GPT 4.0 mini). In contrast, the accuracy for 100 examples of the same reasoning hop is ${77}\% ,{82}\% ,{69}\%$ respectively. We can see the hybrid neural symbolic method, to be specific LLM+ ASP, works much better than the end to end prompting methods, with at least around ${40}\%$ accuracy increase for all the three models. The results are shown in Table 5.

自然语言固有的模糊性是导致大语言模型(LLM)预测出错的重要原因。尽管存在这些挑战，但在StepGame数据集上，这三种大语言模型的表现都比基线直接回答提示和思维链(CoT)提示方法高出40 - 50%。例如，在推理步数为$\mathrm{k} = 5$时，直接提示的准确率记录如下:38.50%(Llama 70B)、33.33%(Deepseek)和29.91%(GPT 4.0 mini)。相比之下，相同推理步数的100个示例的准确率分别为${77}\% ,{82}\% ,{69}\%$。我们可以看到，混合神经符号方法，具体来说是LLM + ASP，比端到端提示方法效果要好得多，这三种模型的准确率至少提高了约${40}\%$。结果如表5所示。

Table 5: Accuracy of LLMs + ASP on StepGame (Accuracy %)

表5:大语言模型(LLM)+回答集编程(ASP)在StepGame上的准确率(准确率%)

<table><tr><td>Model</td><td>千港元</td><td>千港元</td><td>千港元</td><td>千港元</td><td>千港元</td><td>千港元</td><td>千港元</td><td>千港元</td><td>K=9</td><td>K=10</td></tr><tr><td>Deepseek (Baseline)</td><td>53.7</td><td>47.4</td><td>44.3</td><td>34.6</td><td>33.3</td><td>24.2</td><td>22.3</td><td>19.5</td><td>17.3</td><td>16.8</td></tr><tr><td>Deepseek + ASP</td><td>93.7</td><td>89.2</td><td>92.5</td><td>89.3</td><td>88.5</td><td>87.7</td><td>86.3</td><td>85.2</td><td>84.5</td><td>79.8</td></tr><tr><td>Llama3 (Baseline)</td><td>48.2</td><td>49.4</td><td>42.5</td><td>32.4</td><td>28.2</td><td>26.3</td><td>18.1</td><td>17.6</td><td>15.8</td><td>14.2</td></tr><tr><td>Llama3 70B + ASP</td><td>82.2</td><td>76.4</td><td>79.5</td><td>81.2</td><td>77.9</td><td>80.4</td><td>72.8</td><td>70.1</td><td>69.3</td><td>65.7</td></tr><tr><td>GPT 4o mini (Baseline)</td><td>54.6</td><td>48.4</td><td>47.3</td><td>33.2</td><td>29.9</td><td>27.2</td><td>16.3</td><td>14.8</td><td>13.9</td><td>13.5</td></tr><tr><td>GPT 4o mini + ASP</td><td>85.8</td><td>82.4</td><td>85.5</td><td>85.3</td><td>87.1</td><td>85.5</td><td>79.2</td><td>75.3</td><td>72.5</td><td>68.9</td></tr><tr><td>SOTA (Yang, 2023)</td><td>92.6</td><td>89.9</td><td>89.1</td><td>93.8</td><td>92.9</td><td>91.6</td><td>91.2</td><td>90.4</td><td>89.0</td><td>88.3</td></tr></table>

<table><tbody><tr><td>模型</td><td>千港元</td><td>千港元</td><td>千港元</td><td>千港元</td><td>千港元</td><td>千港元</td><td>千港元</td><td>千港元</td><td>K=9</td><td>K=10</td></tr><tr><td>Deepseek(基线模型)</td><td>53.7</td><td>47.4</td><td>44.3</td><td>34.6</td><td>33.3</td><td>24.2</td><td>22.3</td><td>19.5</td><td>17.3</td><td>16.8</td></tr><tr><td>Deepseek + 自适应采样策略(ASP)</td><td>93.7</td><td>89.2</td><td>92.5</td><td>89.3</td><td>88.5</td><td>87.7</td><td>86.3</td><td>85.2</td><td>84.5</td><td>79.8</td></tr><tr><td>Llama3(基线模型)</td><td>48.2</td><td>49.4</td><td>42.5</td><td>32.4</td><td>28.2</td><td>26.3</td><td>18.1</td><td>17.6</td><td>15.8</td><td>14.2</td></tr><tr><td>Llama3 70B + 自适应采样策略(ASP)</td><td>82.2</td><td>76.4</td><td>79.5</td><td>81.2</td><td>77.9</td><td>80.4</td><td>72.8</td><td>70.1</td><td>69.3</td><td>65.7</td></tr><tr><td>GPT 4o mini(基线模型)</td><td>54.6</td><td>48.4</td><td>47.3</td><td>33.2</td><td>29.9</td><td>27.2</td><td>16.3</td><td>14.8</td><td>13.9</td><td>13.5</td></tr><tr><td>GPT 4o mini + 自适应采样策略(ASP)</td><td>85.8</td><td>82.4</td><td>85.5</td><td>85.3</td><td>87.1</td><td>85.5</td><td>79.2</td><td>75.3</td><td>72.5</td><td>68.9</td></tr><tr><td>最优技术水平(SOTA，Yang，2023)</td><td>92.6</td><td>89.9</td><td>89.1</td><td>93.8</td><td>92.9</td><td>91.6</td><td>91.2</td><td>90.4</td><td>89.0</td><td>88.3</td></tr></tbody></table>

It is worth noting that the results cannot compete with Yang et al. (2023)’s results, where they claimed that they achieved ${100}\%$ accuracy when taking out the problematic dataset.

值得注意的是，这些结果无法与杨等人(2023年)的结果相媲美，他们声称在剔除有问题的数据集后达到了${100}\%$的准确率。

As shown in Table 5, we observed a consistent and substantial improvement in performance across all tested models when compared to baseline approaches. The integration of symbolic reasoning with large language models yielded an average accuracy improvement of ${40} - {60}\%$ over end to end prompting methods, including direct answer and simple CoT prompting. At reasoning hop $\mathrm{k} = 5$ , for instance, we observed the following performance improvements: Deepseek improved from 33.3% (baseline) to 88.5% (+55.2%), Llama 70B improved from 28.2% to 77.9% (+49.7%), GPT-4 mini improved from 29.9% to 87.1% (+57.2%). These improvements are particularly significant given the challenging nature of multi-hop reasoning tasks, validating the effectiveness of separating linguistic understanding from logical reasoning in structured and simplified language.

如表5所示，与基线方法相比，我们观察到所有测试模型的性能都有持续且显著的提升。将符号推理与大语言模型相结合，与端到端提示方法(包括直接回答和简单的思维链提示)相比，平均准确率提高了${40} - {60}\%$。例如，在推理跳数为$\mathrm{k} = 5$时，我们观察到以下性能提升:Deepseek从33.3%(基线)提高到88.5%(提升55.2%)，Llama 70B从28.2%提高到77.9%(提升49.7%)，GPT - 4 mini从29.9%提高到87.1%(提升57.2%)。鉴于多跳推理任务的挑战性，这些提升尤为显著，验证了在结构化和简化语言中将语言理解与逻辑推理分离的有效性。

We observed a consistent pattern of performance degradation as reasoning depth increased. The general trend is consistent and suggests that the complexity of the tasks grows with the number of hops.

我们观察到，随着推理深度的增加，性能下降呈现出一致的模式。总体趋势是一致的，这表明任务的复杂性随着跳数的增加而增加。

The success of LLM + ASP can be attributed to several key factors. The simplified predicate structure, utilizing only is/3 and query/2 predicates, provides a clear bridge between natural language and logical forms. This simplification, combined with our well-designed knowledge module, enables efficient handling of spatial relationships while maintaining robust error detection capabilities.

大语言模型 + 答案集编程(LLM + ASP)的成功可归因于几个关键因素。简化的谓词结构仅使用is/3和query/2谓词，为自然语言和逻辑形式之间提供了清晰的桥梁。这种简化与我们精心设计的知识模块相结合，能够在有效处理空间关系的同时，保持强大的错误检测能力。

## C3: Error analysis

## C3:错误分析

The ASP solver outputs can be categorized into three types: 1). Parsing Errors: Syntax mistakes, inconsistent variables, or incomplete code (rare, $< 2\% )$ ; 2). Satisfiable but No Query Results: No syntax errors but solver cannot find valid solutions (rare, $< 2\%$ ); 3). Inconsistency with Ground Truth Labels: Most common error, typically due to ambiguous language expressions.

答案集编程(ASP)求解器的输出可分为三种类型:1)解析错误:语法错误、变量不一致或代码不完整(罕见，$< 2\% )$)；2)可满足但无查询结果:无语法错误，但求解器无法找到有效解决方案(罕见，$< 2\%$)；3)与真实标签不一致:最常见的错误，通常是由于语言表达模糊造成的。

For example, consider this scenario:

例如，考虑以下场景:

- Story: "D is on the left side of and below E. M is over G. M is diagonally left and below E. B is under G."

- 故事:“D在E的左侧且下方。M在G的上方。M在E的左下方斜对角处。B在G的下方。”

- Question: "What is the relation of agent $G$ to agent $E$ ?"

- 问题:“主体$G$与主体$E$的关系是什么？”

- Ground-Truth Label: "down_left".

- 真实标签:“左下方”。

When mapped to facts:

当映射为事实时:

- is ( "D", left, "E" ) .

- is ( "D", left, "E" ) .

- is ("D", down, "E").

- is ("D", down, "E").

- is ("M", top, "G").

- is ("M", top, "G").

- is ("M", down_left, "E").

- is ("M", down_left, "E").

- is ("B", down, "G").

- is ("B", down, "G").

- query ("G", "E").

- 查询("G", "E")。

The ASP solver returns multiple possible relations ("down_left, down, down_right, left, top_left") due to ambiguous language interpretation. Llama 70B showed more instances of multiple relation results and "satisfiable but no query results" compared to Deepseek, suggesting lower semantic parsing effectiveness.

由于语言解释存在歧义，Answer Set Programming(ASP)求解器返回了多种可能的关系(“左下、下、右下、左、左上”)。与Deepseek相比，Llama 70B出现更多返回多种关系结果以及“可满足但无查询结果”的情况，这表明其语义解析效果较差。

The StepGame benchmark’s simplicity (95% of sentences contain single is/3 relation facts) and clear agent definitions make it suitable for testing smaller LLMs or specialized semantic parsers paired with ASP solvers. While testing with smaller models (Openchat, Mistral 8B, Llama 8B, Gemma 8B) remains pending, the LLM + ASP approach is expected to yield higher accuracy than baseline prompting.

StepGame基准测试的简单性(95%的句子仅包含单个is/3关系事实)和明确的智能体定义，使其适合测试较小的大语言模型(LLM)或与ASP求解器配合使用的专用语义解析器。虽然使用较小模型(Openchat、Mistral 8B、Llama 8B、Gemma 8B)的测试尚未进行，但预计LLM + ASP方法将比基线提示方法产生更高的准确率。

## Appendix D: The code and examples in experiment in SparQA

## 附录D:SparQA实验中的代码和示例

Compared with the offset -based rule in StepGame, this knowledge module used in SparQA is not very complicated, as it relies on the logical rule to infer the new relations.

与StepGame中基于偏移量的规则相比，SparQA中使用的这个知识模块并不复杂，因为它依靠逻辑规则来推断新的关系。

The symbolic reasoning module involves executing the ASP solver on the generated facts and rules. The ASP solver outputs all answer sets or facts that satisfy the given conditions. For Yes/No, Find Relations (FR), and Find Block (FB) questions, there is no need for post-processing to calculate accuracy against the ground truth label to evaluate the performance of the language model. However, for Choose Object (CO) questions, a manual review of the ASP results is necessary for evaluation.

符号推理模块涉及对生成的事实和规则执行ASP求解器。ASP求解器输出所有满足给定条件的答案集或事实。对于是非题、查找关系(FR)和查找方块(FB)问题，无需进行后处理以对照真实标签计算准确率来评估语言模型的性能。然而，对于选择对象(CO)问题，需要手动审查ASP结果以进行评估。

To illustrate this point, consider the following example: "What object is not above the purple rectangle? The orange triangle or the white square?" The actual answer is "['the white square']." In this case, the query can be expressed as query(Object) :- object(Object, _, _, _, _), object(purple_rectangle, _, purple, rectangle, _), not is(Object, above, purple_rectangle). When executed, the ASP solver will return all objects that are not above the purple rectangle. For instance, if the output is "small_white_square, small_black_square, large_yellow_square," we observe that small_white_square is included in this result while the orange triangle is not. Since this satisfies the condition of the query correctly, we consider this ASP result as valid. The complete set of prompts for semantic parsing is seen in the following section.

为了说明这一点，考虑以下示例:“哪个对象不在紫色矩形上方？是橙色三角形还是白色正方形？”实际答案是“['白色正方形']”。在这种情况下，查询可以表示为query(Object) :- object(Object, _, _, _, _), object(purple_rectangle, _, purple, rectangle, _), not is(Object, above, purple_rectangle)。执行时，ASP求解器将返回所有不在紫色矩形上方的对象。例如，如果输出是“small_white_square, small_black_square, large_yellow_square”，我们会发现小白色正方形包含在这个结果中，而橙色三角形不在。由于这正确满足了查询条件，我们认为这个ASP结果是有效的。语义解析的完整提示集见下一节。

---

## ASP Code Sample

## ASP代码示例

- % Inverse relations

- % 逆关系

inverse ( left , right ;

逆关系 ( 左 , 右 ;

right, left;

右, 左;

front, behind;

前, 后;

behind, front;

后, 前;

above, below;

上, 下;

below, above).

下, 上).

$\operatorname{is}\left( {Y,{R2}, X}\right)  :  - \operatorname{is}\left( {X,{R1}, Y}\right)$ , inverse $\left( {{R1},{R2}}\right) , X! = Y$ .

$\operatorname{is}\left( {Y,{R2}, X}\right)  :  - \operatorname{is}\left( {X,{R1}, Y}\right)$ ，逆关系 $\left( {{R1},{R2}}\right) , X! = Y$ 。

...

% Symmetric relations

% 对称关系(Symmetric relations)

symmetric(touching; disconnected; overlapping;

对称(接触；分离；重叠；

adjacent; near; far).

相邻；接近；远离)。

$\operatorname{is}\left( {Y, R, X}\right)  :  - \operatorname{is}\left( {X, R, Y}\right)$ , symmetric $\left( R\right) , X! = Y$ .

$\operatorname{is}\left( {Y, R, X}\right)  :  - \operatorname{is}\left( {X, R, Y}\right)$ ，对称 $\left( R\right) , X! = Y$ 。

	...

% Intra-block object relations

% 块内对象关系(Intra - block object relations)

is $\left( {{01},\mathrm{R},{02}}\right)  :  -$ object(01, L, L, L, Block),

是 $\left( {{01},\mathrm{R},{02}}\right)  :  -$ 对象(01, L, L, L,块)，

object(02, _, _, _, Block),

对象(02, _, _, _, 块)，

is(01, R,02),

是(01, R,02)，

${01}! = {02}$

---

Figure 6: ASP code sample

图 6:ASP 代码示例

ASP code is implemented in the module of "Proposed LLM + ASP", as shown as follows.

ASP 代码在“提议的大语言模型 + ASP”模块中实现，如下所示。

---

## ASP Code Sample

## ASP 代码示例

% Inverse relations

% 逆关系(Inverse relations)

inverse(left, right; right, left;

逆(左，右；右，左；

front, behind; behind, front;

前，后；后，前；

above, below; below, above).

上，下；下，上)。

$\operatorname{is}\left( {Y,{R2}, X}\right)  :  - \operatorname{is}\left( {X,{R1}, Y}\right)$ , inverse $\left( {{R1},{R2}}\right) , X! = Y$ .

$\operatorname{is}\left( {Y,{R2}, X}\right)  :  - \operatorname{is}\left( {X,{R1}, Y}\right)$ ，逆 $\left( {{R1},{R2}}\right) , X! = Y$ 。

% Symmetric relations

% 对称关系(Symmetric relations)

	...

% Inter-block object relations

% 块间对象关系(Inter-block object relations)

is(01, R, 02) :- object(01, _, _, _, B1),

is(01, R, 02) :- object(01, _, _, _, B1),

object(02, _, _, _, B2),

object(02, _, _, _, B2),

is $\left( {\mathrm{B}1,\mathrm{R},\mathrm{B}2}\right) ,{01}! = {02},\mathrm{\;B}1! = \mathrm{B}2$ .

是 $\left( {\mathrm{B}1,\mathrm{R},\mathrm{B}2}\right) ,{01}! = {02},\mathrm{\;B}1! = \mathrm{B}2$ 。

---

Figure 7: ASP code sample

图7:ASP代码示例

## Appendix E: Prompts samples

## 附录E:提示示例

## E1: Visualization Prompts for StepGame

## E1:StepGame的可视化提示

Role: A spatial visualization expert specializing in converting textual spatial relationships into grid layouts.

角色:一位擅长将文本空间关系转换为网格布局的空间可视化专家。

Task: Given a story describing spatial relations and a position query between two agents, create a step-by-step grid visualization to determine the answer. Process: 1). Initial Grid Setup

任务:给定一个描述空间关系的故事以及两个主体之间的位置查询，创建一个逐步的网格可视化来确定答案。过程:1). 初始网格设置

* Create $5 \times  5$ or $7 \times  7$ grid with periods (.)

* 用句点 (.) 创建 $5 \times  5$ 或 $7 \times  7$ 网格

* Place query's second agent at center as anchor

* 将查询中的第二个主体放置在中心作为锚点

2). Sequential Agent Placement

2). 顺序主体放置

* Build from anchor agent

* 从锚点主体开始构建

* Place agents based on explicit relations only

* 仅根据明确的关系放置主体

* Each placement must connect to existing agents

* 每次放置都必须与现有主体相连

3). Validation and Optimization ...

3). 验证与优化...

4). Answer Generation ...

4). 答案生成...

Example output:

示例输出:

Story: "D is left of E. M is above E. B is below E." Question: "What is the relation of B to M?"

故事:“D 在 E 的左边。M 在 E 的上方。B 在 E 的下方。”问题:“B 与 M 是什么关系？”

## E2:Symbolic Fact Representation and Logical Rules

## E2:符号事实表示与逻辑规则

Module 1: Natural Language to ASP Facts

模块 1:自然语言转换为 Answer Set Programming(ASP)事实

Given a context and spatial question, extract all facts using three predicates:

给定一个上下文和空间问题，使用三个谓词提取所有事实:

- block/1: block(name)

- block/1:块(名称)

- object/5: object(distinct_name, size, color, shape, block)

- object/5:对象(唯一名称，大小，颜色，形状，块)

- relation/2: relation (object1, object2)

- relation/2:关系(对象 1，对象 2)

Example:

示例:

block(a) .

块(a) .

object(large_blue_triangle, large, blue, triangle, a).

对象(大蓝色三角形, 大, 蓝色, 三角形, a)。

%object(blue_oval, unknown, blue, oval, b).

%对象(蓝色椭圆形, 未知, 蓝色, 椭圆形, b)。

left(large_blue_triangle, blue_oval).

左(大蓝色三角形, 蓝色椭圆形)。

Module 2: Logical Rules Application

模块 2:逻辑规则应用

Apply spatial logical rules to connect facts with queries:

应用空间逻辑规则将事实与查询关联起来:

Inverse Relations:

逆关系:

% If $X$ is [Relation1] of $Y$ , and [Relation1] is inverse of [Relation2],

% 如果 $X$ 是 $Y$ 的 [关系1]，且 [关系1] 是 [关系2] 的逆关系，

% then $Y$ is [Relation2] of $X$

% 那么 $Y$ 是 $X$ 的 [关系2]

Symmetric Relations: ...

对称关系:...

Inter-block Relations: ...

块间关系:...

Output format:

输出格式:

\{

"Reasoning": "step 1, 2, 3 ...",

"推理过程": "步骤 1, 2, 3 ...",

"Answer": "Your answer"

"答案": "你的答案"

\}

E3:NL-Facts Module Prompts for StepGame

E3:步骤游戏的自然语言事实模块提示

Role: Expert semantic parser converting context sentences into atomic facts. Fact Types:

角色:将上下文句子转换为原子事实的专业语义解析器。事实类型:

1. Relation facts: is ("A", relation, "B")

1. 关系事实:is ("A", 关系, "B")

2. Query facts: query ( " A " , " B " )

2. 查询事实:query ( " A " , " B " )

Relation Set:

关系集合:

- left, right, top, down

- 左，右，上，下

- top_left, top_right

- 左上，右上

- down_left, down_right

- 左下，右下

Mapping Rules:

映射规则:

1). Clock Positions:

1). 时钟位置:

12:00 -> top 1-2:00 -> top_right

12:00 -> 上 1 - 2:00 -> 右上

3:00 -> right 4-5:00 -> down_right

3:00 -> 右 4 - 5:00 -> 右下

...

2). Cardinal Directions: ...

2). 方位方向:...

Example: Input story:

示例:输入故事:

"U and V are parallel, and U is to the left of V."

"U 和 V 平行，且 U 在 V 的左侧。"

"T and G are parallel, and T on the left of G."

"T 和 G 平行，且 T 在 G 的左侧。"

"V is positioned in the front right corner of Z."

"V 位于 Z 的右前角。"

...

Question: "What is the relation of the agent $G$ to the agent $Z$ ?" Output: is("U", left,"V"). is("T", left,"G"). is("V", top_right,"Z"). ...

问题:“主体 $G$ 与主体 $Z$ 的关系是什么？” 输出:is("U", left,"V"). is("T", left,"G"). is("V", top_right,"Z"). ...

## E4: ASP Refinement Module Prompts for StepGame

## E4:StepGame 的 ASP 细化模块提示

Step 1: Analysis Checklist

步骤 1:分析清单

- Completeness: Verify all story elements are represented

- 完整性:验证所有故事元素均有体现

- Syntax: Check format ... - Safety: Confirm - Arguments in quotes - Relations unquoted and lowercase - Consistency: Verify relations use standard set:

- 语法:检查格式 ... - 安全性:确认 - 参数加引号 - 关系不加引号且为小写 - 一致性:验证关系使用标准集合:

\{left, right, top, down, top_left,

{左，右，上，下，左上，

top_right, down_left, down_right\}

右上，左下，右下}

...

- Each fact on separate line

- 每个事实单独一行

- No extra punctuation

- 无额外标点符号

- Query: Verify question correctly represented

- 查询:验证问题是否正确表示

Step 2: Refinement Process ...

步骤2:细化过程...

Step 3: Final Output Format

步骤3:最终输出格式

is ("A", left, "B") .

是 ("A", 左, "B") 。

is("C", top_right,"D").

是("C", 右上, "D")。

query("E","F").

查询("E", "F")。

## E5: Natural Language to ASP Conversion Prompts for SparQA

## E5:SparQA的自然语言到回答集编程(ASP)转换提示

Module 1: Initial ASP Code Generation

模块1:初始ASP代码生成

Role: Expert parser for converting natural language to logical represen-

角色:将自然语言转换为逻辑表示的专业解析器

tations.

表示。

Step 1: Fact Extraction

步骤1:事实提取

Three essential predicates:

三个基本谓词:

1. block (name)

1. 块(名称)

Example: block(a). block(a;b;c).

示例:block(a)。block(a;b;c)。

...

Critical Rules: ...

关键规则:...

Example Context Translation:

示例上下文翻译:

Context: "There is a block A below block B. In A, there is a large blue triangle to the left of and below a large black square. Far above the square is a large black circle."

上下文:“在方块B下方有一个方块A。在A中，有一个蓝色大三角形位于黑色大正方形的左下方。在正方形的上方远处有一个黑色大圆圈。”

...

Step 2: Query Generation

步骤2:查询生成

Query formats:

查询格式:

- Yes/No questions: query (yes) and query (no)

- 是非问题:query (yes) 和 query (no)

- Wh-Questions: query(relation), query(object), or query(block)

- 特殊疑问句:query(关系)，query(对象) 或 query(方块)

Example queries:

示例查询:

% Are all squares in B?

% 所有正方形都在B中吗？

query(no) :- object(_,_,_, square, Block), Block != b.

query(no) :- 对象(_,_,_, 正方形, 方块), 方块 != b。

query(yes) : - not query(no). ...

query(yes) : - 非 query(no)。...

## Module 2: ASP Refinement Refinement Process:

## 模块2:ASP细化 细化过程:

1. Check facts: - Validate predicates and argument counts - Verify relation names - Ensure consistent variable naming 2. Verify query: - Appropriate query type - Logical consistency - Variable safety 3. Format output: ... Common Errors and Fixes:

1. 检查事实: - 验证谓词和参数数量 - 验证关系名称 - 确保变量命名一致 2. 验证查询: - 合适的查询类型 - 逻辑一致性 - 变量安全性 3. 格式化输出:... 常见错误及修复方法:

- Syntax: Ensure head :- body. structure

- 语法:确保遵循 头部 :- 主体。的结构

- Unsafe variables: Bind all variables in positive literals

- 不安全变量:绑定正文字中的所有变量

- Grounding: Verify predicate argument counts

- 基础检查:验证谓词参数数量

- Undefined predicates: Define all used predicates

- 未定义的谓词:定义所有使用的谓词

- Inconsistent rules: Resolve contradictions

- 不一致的规则:解决矛盾

Final ASP Structure:

最终的回答集编程(ASP)结构:

---

% Facts

% 事实

<facts>

% Rules

% 规则

		<rules>

	...

---