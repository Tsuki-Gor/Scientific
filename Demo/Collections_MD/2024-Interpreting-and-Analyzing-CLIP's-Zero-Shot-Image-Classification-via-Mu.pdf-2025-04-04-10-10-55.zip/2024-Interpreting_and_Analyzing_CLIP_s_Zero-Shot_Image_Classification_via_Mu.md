# Interpreting and Analyzing CLIP's Zero-Shot Image Classification via Mutual Knowledge

# 通过互知识解读和分析CLIP的零样本图像分类

Fawaz Sammani, Nikos Deligiannis

法瓦兹·萨马尼(Fawaz Sammani)，尼科斯·德利吉安尼斯(Nikos Deligiannis)

ETRO Department, Vrije Universiteit Brussel, Pleinlaan 2, B-1050 Brussels, Belgium imec, Kapeldreef 75, B-3001 Leuven, Belgium

比利时布鲁塞尔自由大学ETRO系，普莱因拉安2号，B - 1050布鲁塞尔 比利时imec公司，卡佩尔德雷夫75号，B - 3001鲁汶

fawaz.sammani@vub.be, ndeligia@etrovub.be

fawaz.sammani@vub.be，ndeligia@etrovub.be

## Abstract

## 摘要

Contrastive Language-Image Pretraining (CLIP) performs zero-shot image classification by mapping images and textual class representation into a shared embedding space, then retrieving the class closest to the image. This work provides a new approach for interpreting CLIP models for image classification from the lens of mutual knowledge between the two modalities. Specifically, we ask: what concepts do both vision and language CLIP encoders learn in common that influence the joint embedding space, causing points to be closer or further apart? We answer this question via an approach of textual concept-based explanations, showing their effectiveness, and perform an analysis encompassing a pool of 13 CLIP models varying in architecture, size and pretraining datasets. We explore those different aspects in relation to mutual knowledge, and analyze zero-shot predictions. Our approach demonstrates an effective and human-friendly way of understanding zero-shot classification decisions with CLIP. ${}^{1}$

对比语言 - 图像预训练(Contrastive Language - Image Pretraining，CLIP)通过将图像和文本类别表示映射到一个共享的嵌入空间，然后检索最接近图像的类别来执行零样本图像分类。这项工作从两种模态之间的互知识角度，为解读用于图像分类的CLIP模型提供了一种新方法。具体来说，我们提出问题:视觉和语言CLIP编码器共同学习了哪些概念，这些概念影响了联合嵌入空间，使得点之间距离更近或更远？我们通过一种基于文本概念的解释方法回答了这个问题，展示了其有效性，并对一组13个在架构、规模和预训练数据集方面有所不同的CLIP模型进行了分析。我们探索了与互知识相关的这些不同方面，并分析了零样本预测。我们的方法展示了一种有效且对人类友好的方式来理解使用CLIP进行的零样本分类决策。${}^{1}$

## 1 Introduction

## 1 引言

Contrastive Language-Image Pretraining (CLIP) [44] has catalyzed a paradigm shift in zero-shot and few-shot learning methodologies for image classification [61, 54, 31, 36, 66, 57]. CLIP consists of a vision and language encoder, both which are trained to map positive image-text pairs close together in embedding space, while pushing away negative ones. In the context of information theory, the channel which connects two information sources is referred to as the information channel [10], and its reliability and effectiveness is often studied through Mutual Information (MI) analysis between the two sources [53]. The training dynamics of contrastive models inherently involve a significant degree of shared knowledge between the vision and language sources, as both models must map similar points close in the embedding space. This suggests the existence of a vision-language information channel (Figure 1a) wherein the shared knowledge between the two modalities is stored.

对比语言 - 图像预训练(CLIP)[44]推动了图像分类的零样本和少样本学习方法的范式转变[61, 54, 31, 36, 66, 57]。CLIP由一个视觉编码器和一个语言编码器组成，这两个编码器都经过训练，将正的图像 - 文本对在嵌入空间中映射得彼此靠近，同时将负的图像 - 文本对推开。在信息论的背景下，连接两个信息源的通道被称为信息通道[10]，其可靠性和有效性通常通过两个源之间的互信息(Mutual Information，MI)分析来研究[53]。对比模型的训练动态本质上涉及视觉和语言源之间的大量共享知识，因为两个模型都必须在嵌入空间中将相似的点映射得靠近。这表明存在一个视觉 - 语言信息通道(图1a)，其中存储了两种模态之间的共享知识。

Inspired by this, we aim to interpret this channel and measure the relationship and mutual knowledge between the image and text encoders of CLIP, for a given zero-shot prediction. We therefore pose the following question: What concepts did the vision and language encoders learn in common, such that the image-text points are closer or further apart in the joint space?

受此启发，对于给定的零样本预测，我们旨在解读这个通道，并衡量CLIP的图像编码器和文本编码器之间的关系和互知识。因此，我们提出以下问题:视觉编码器和语言编码器共同学习了哪些概念，使得图像 - 文本点在联合空间中距离更近或更远？

The two sources of information-the vision encoder and the text encoder-differ in modality: the vision encoder provides interpretation as visual regions, while the text encoder can only provide interpretation as text. To understand the commonalities in what both encoders learn, we must establish a shared medium for their interpretations. As a result, applying existing attribution techniques $\left\lbrack  {{51},{60},{45},2}\right\rbrack$ does not suffice. Moreover, the information channel is composed of discrete units of information (i.e., bits), however these attribution techniques provide general, high-level interpretations

两个信息源——视觉编码器和文本编码器——在模态上有所不同:视觉编码器以视觉区域的形式提供解释，而文本编码器只能以文本的形式提供解释。为了理解两个编码器所学内容的共性，我们必须为它们的解释建立一个共享的媒介。因此，应用现有的归因技术$\left\lbrack  {{51},{60},{45},2}\right\rbrack$是不够的。此外，信息通道由离散的信息单元(即比特)组成，然而这些归因技术提供的是一般性的、高层次的解释

---

${}^{1}$ https://github.com/fawazsammani/clip-interpret-mutual-knowledge

${}^{1}$ https://github.com/fawazsammani/clip - interpret - mutual - knowledge

---

![0195d6ee-5e8d-7e59-bdaf-525eddd2b72d_1_311_205_1178_621_0.jpg](images/0195d6ee-5e8d-7e59-bdaf-525eddd2b72d_1_311_205_1178_621_0.jpg)

Figure 1: CLIP maps visual and textual inputs into a joint embedding space, with an information channel expressed in terms of the Mutual Information (MI) between them (a). We interpret the visual features from the vision encoder with multimodal concepts (b) which represent object parts and their corresponding textual description. From the language encoder, we identify points (shown in grey) around the zero-shot prediction (shown in green) as textual descriptions of the predicted class (c). By considering the textual descriptors corresponding to the visual concepts, and the textual descriptors of the language encoder for the predicted class, the two encoders establish a common space of textual concepts allowing us to identify mutual concepts and analyze their shared knowledge (d).

图1:CLIP将视觉和文本输入映射到一个联合嵌入空间，其中信息通道用它们之间的互信息(MI)表示(a)。我们用多模态概念(b)解读视觉编码器的视觉特征，这些概念表示对象部分及其相应的文本描述。从语言编码器中，我们将零样本预测(绿色显示)周围的点(灰色显示)识别为预测类别的文本描述(c)。通过考虑与视觉概念对应的文本描述符，以及语言编码器针对预测类别的文本描述符，两个编码器建立了一个文本概念的公共空间，使我们能够识别共同概念并分析它们的共享知识(d)。

(e.g., attributing the main object in the scene). They do not break-down the entangled attribution into their internal components. For instance, when applied to images of different dog breeds, attribution techniques might highlight the entire dog, indicating that the model is focusing on the correct object. However, they do not reveal what exactly in the main object influenced the model's decision. Which specific features of the dog were important? Is it the shape of the nose, the ears, the body, the head or the snout? ImageNet [30], for example, is a coarse-grained dataset, requiring models to learn distinctive concepts of an object to make decisions, but current explainability techniques do not reflect this. Therefore, we argue that distinctive fine-grained concepts are more beneficial for representing the discrete units in a channel, while also facilitating the calculation of mutual information between the two sources efficiently.

(例如，将场景中的主要对象归因)。它们没有将纠缠的归因分解为其内部组件。例如，当应用于不同犬种的图像时，归因技术可能会突出显示整个狗，表明模型关注的是正确的对象。然而，它们并没有揭示主要对象中究竟是什么影响了模型的决策。狗的哪些特定特征是重要的？是鼻子的形状、耳朵、身体、头部还是口鼻部？例如，ImageNet [30]是一个粗粒度的数据集，要求模型学习对象的独特概念来做出决策，但当前的可解释性技术并没有反映这一点。因此，我们认为独特的细粒度概念更有利于表示通道中的离散单元，同时也有助于高效地计算两个源之间的互信息。

To address this question, we interpret the outcome of the visual and textual encoder as discrete random variables and use the MI to quantify the amount of information obtained about one random variable (visual data) through the other random variable (textual data). Drawing from this inspiration, we strive towards an interpretation and analysis approach of textual concepts; short descriptions in natural language (e.g., "a long snout", "feathered ears"). In addition to being human-friendly interpretable, understood even to layman users, each textual concept can be mapped to an integer in a dictionary of predefined concepts (e.g.,"a long snout" $\rightarrow  0$ ,"feathered ears" $\rightarrow  1$ ). Since integers are discrete, they can represent the information units of the channel, while also facilitating the calculation of MI in the discrete space directly, which is fast, efficient, and reliable. This approach also eliminates the need for MI approximations typically required in the continuous space.

为解决这个问题，我们将视觉编码器和文本编码器的输出结果解释为离散随机变量，并使用互信息(MI)来量化通过一个随机变量(文本数据)获得的关于另一个随机变量(视觉数据)的信息量。受此启发，我们致力于一种文本概念的解释和分析方法；即使用自然语言进行简短描述(例如，“长鼻子”、“有羽毛的耳朵”)。除了便于人类理解，即使是外行用户也能明白之外，每个文本概念都可以映射到预定义概念字典中的一个整数(例如，“长鼻子” $\rightarrow  0$ ，“有羽毛的耳朵” $\rightarrow  1$ )。由于整数是离散的，它们可以表示通道的信息单元，同时也便于直接在离散空间中计算互信息，这种计算方式快速、高效且可靠。这种方法还消除了在连续空间中通常需要的互信息近似计算。

In order to achieve this, we need the two CLIP encoders to output random variables in the same space (that is, the space of textual concepts). In the vision encoder, we first refer to visual concepts as object parts grounded in the image and directly extracted from the visual features (Figure 1b, top). Those are discrete visual units that are not in the textual domain, however each of them can be described via a textual concept. Therefore, we refer to textual concepts in the vision encoder as textual descriptions of those visual concepts. As a result, multimodal concepts in the vision encoder are corresponding pairs of visual-textual semantics describing discriminative parts of an object (Figure 1b). Depending on the dataset, an object can also refer to the main scene (e.g., lake or ocean in Places365 dataset [65]). Notably, our approach does not involve training any model to generate those multimodal concepts. The textual component of these multimodal concepts at the vision encoder are now expressive of the visual concepts in the text domain. Once the mapping of visual concepts to textual concepts is achieved, we proceed with extracting textual concepts from the language encoder. This can be achieved by identifying points around the zero-shot prediction (Figure 1c). Given the output embedding of the predicted class (green point) from the language encoder, we identify related textual concepts (grey points) around that prediction. These directly serve as textual concepts explaining the prediction. The two encoders of CLIP now share a common medium of textual concepts, and we can establish the mutual concepts of both the vision and language encoders (Figure 1d). By observing Figure 1d, we see that the snout and its physical features (e.g., wrinkled, long, pointy) are expressive of what the vision and language encoders learn in common, which influence the prediction of a "bluetick coonhound" in the joint space.

为了实现这一点，我们需要两个CLIP编码器在同一空间(即文本概念空间)中输出随机变量。在视觉编码器中，我们首先将视觉概念定义为基于图像并直接从视觉特征中提取的对象部分(图1b，顶部)。这些是不在文本域中的离散视觉单元，然而，每个视觉单元都可以通过一个文本概念来描述。因此，我们将视觉编码器中的文本概念称为这些视觉概念的文本描述。结果，视觉编码器中的多模态概念是描述对象可区分部分的视觉 - 文本语义对应对(图1b)。根据数据集的不同，一个对象也可以指主要场景(例如，Places365数据集 [65] 中的湖泊或海洋)。值得注意的是，我们的方法不涉及训练任何模型来生成这些多模态概念。视觉编码器中这些多模态概念的文本部分现在能够在文本域中表达视觉概念。一旦实现了视觉概念到文本概念的映射，我们就可以从语言编码器中提取文本概念。这可以通过识别零样本预测周围的点来实现(图1c)。给定语言编码器对预测类别的输出嵌入(绿点)，我们识别该预测周围的相关文本概念(灰点)。这些直接作为解释预测的文本概念。CLIP的两个编码器现在共享一个文本概念的公共媒介，我们可以建立视觉编码器和语言编码器的共同概念(图1d)。通过观察图1d，我们可以看到鼻子及其物理特征(例如，有皱纹、长、尖)表达了视觉编码器和语言编码器的共同学习内容，这些内容影响了在联合空间中对“蓝褐猎浣熊犬”的预测。

Our work contributes as follows: 1) it introduces a user-friendly approach to interpreting CLIP’s visual features through multimodal concepts, and we demonstrate the effectiveness of those concepts by surpassing other baselines and achieving gains of up to 3.75% in zero-shot accuracy. 2) it enables us to visualize what CLIP models learn in common when making zero-shot predictions, and how the two encoders influence each other, and 3) it allows us to explore relationships between various model aspects (model size, pretraining data, and accuracy) and its shared knowledge, and inspect the degree of correlation between the CLIP vision and text encoders.

我们的工作贡献如下:1) 它引入了一种用户友好的方法，通过多模态概念来解释CLIP的视觉特征，并且我们通过超越其他基线并在零样本准确率上实现高达3.75%的提升，证明了这些概念的有效性。2) 它使我们能够可视化CLIP模型在进行零样本预测时的共同学习内容，以及两个编码器如何相互影响，3) 它允许我们探索模型的各个方面(模型大小、预训练数据和准确率)与其共享知识之间的关系，并检查CLIP视觉编码器和文本编码器之间的相关程度。

## 2 Related Work

## 2 相关工作

Multimodal Explanations: So far, post-hoc multimodal explanations have been limited to the context of Natural Language Explanations (NLE) [41, 24, 48]. NLEs are annotated textual explanations for the output prediction for a variety of vision and vision-language tasks, where models are explicitly trained to generate such explanations. The visual explanation counterpart is typically obtained by visualizing the attention weights of the prediction. However, there are two significant issues in NLEs. Firstly, we argue that any interpretability technique based on training is not faithful to the model being interpreted, and falls more towards the task of image captioning where the caption is the explanation. Explanations should not reflect what humans desire, but rather reflect the model's own reasoning. Training these models also involves learning biases and statistical correlations, akin to the challenges faced by any machine learning model. A recent work [47] showed that trained textual explanation models are highly susceptible to the shortcut bias learning problem, rendering the explanation ineffective despite achieving state-of-the-art results on Natural Language Generation metrics. Secondly, both the visual and textual explanations generated by NLEs are general, high-level and entangled (e.g., highlighting the main object in the scene). On the other hand, our multimodal explanations tackle both issues outlined in NLE. They are (i) training-free and (ii) offer distinctive, fine-grained concepts. Another line of work $\left\lbrack  {{36},{43}}\right\rbrack$ extracts descriptors from a large language model and uses them as additional information when building class embedding weights of CLIP. The set of descriptors with the highest similarity with respect to the global image are considered as an explanation for the prediction. While those textual concepts are fine-grained, the explanation generated is single-modal. Different from [36], our concept-based explanations are multi-modal fine-grained explanations, composed of visual-textual concepts which are directly grounded in the image. Finally, [64] analyzes primitive concepts in vision-language contrastive models. We discuss this work in Section J in the appendix since it is less-relevant to our study.

多模态解释:到目前为止，事后多模态解释仅限于自然语言解释(Natural Language Explanations，NLE)的范畴 [41, 24, 48]。自然语言解释是针对各种视觉和视觉 - 语言任务的输出预测所标注的文本解释，在这些任务中，模型经过明确训练以生成此类解释。与之对应的视觉解释通常是通过可视化预测的注意力权重获得的。然而，自然语言解释存在两个显著问题。首先，我们认为任何基于训练的可解释性技术都不能忠实反映被解释的模型，而更倾向于图像描述任务，其中描述内容即为解释。解释不应反映人类的期望，而应反映模型自身的推理过程。训练这些模型还涉及学习偏差和统计相关性，这与任何机器学习模型所面临的挑战类似。最近的一项工作 [47] 表明，经过训练的文本解释模型极易受到捷径偏差学习问题的影响，尽管在自然语言生成指标上取得了最先进的结果，但解释却毫无效果。其次，自然语言解释所生成的视觉和文本解释都是笼统、高层次且相互纠缠的(例如，突出场景中的主要对象)。另一方面，我们的多模态解释解决了自然语言解释中概述的两个问题。它们(i)无需训练，(ii)提供独特、细粒度的概念。另一项工作 $\left\lbrack  {{36},{43}}\right\rbrack$ 从大型语言模型中提取描述符，并在构建 CLIP 的类别嵌入权重时将其用作额外信息。与全局图像相似度最高的一组描述符被视为对预测的解释。虽然这些文本概念是细粒度的，但生成的解释是单模态的。与 [36] 不同，我们基于概念的解释是多模态细粒度解释，由直接基于图像的视觉 - 文本概念组成。最后，[64] 分析了视觉 - 语言对比模型中的原始概念。由于这项工作与我们的研究相关性较低，我们将在附录的 J 节中讨论。

Joint Embedding Space of Contrastive Models: A few works investigate the vision-language modality gap in the joint feature space. [18] suggests that this gap stems from inherent differences between the two data modalities. Conversely, [32] discovered that there exists a gap that causes the image and text embeddings to be placed in two distinct regions in the joint space without any overlap. In contrast to [18], they attribute this gap to the inductive bias of neural network architectures, such that embeddings of two randomly initialized models are inherently separated within the joint space, and the contrastive learning objective maintains this separation. Different from the aforementioned works, our study does not investigate the gap. Instead, we assume the gap is fundamentally present, and analyze the strength of the shared knowledge within the two models, which influence this gap.

对比模型的联合嵌入空间:有几项工作研究了联合特征空间中的视觉 - 语言模态差距。[18] 认为这种差距源于两种数据模态之间的内在差异。相反，[32] 发现存在一种差距，导致图像和文本嵌入在联合空间中被放置在两个不同的区域，没有任何重叠。与 [18] 不同，他们将这种差距归因于神经网络架构的归纳偏差，使得两个随机初始化模型的嵌入在联合空间中本质上是分离的，并且对比学习目标维持了这种分离。与上述工作不同，我们的研究不探讨这种差距。相反，我们假设这种差距本质上是存在的，并分析影响这种差距的两个模型内共享知识的强度。

## 3 Method

## 3 方法

Consider the problem of image classification, where the aim is to classify an image into a set of categories $\mathcal{Y}$ . For ImageNet [30], $\left| \mathcal{Y}\right|  = 1,{000}$ . CLIP [66] formulates image classification as a retrieval task by using the textual class names of $\mathcal{Y}$ denoted as ${\mathcal{Y}}^{t}$ , converting them into fixed natural text prompts (e.g., an image of a \{class\}), and encoding them with the language encoder of CLIP. The image is then encoded with the visual encoder of CLIP. The nearest category $y \in  \mathcal{Y}$ to the image in the shared embedding space is then selected as the predicted class. In this context, the language encoder of CLIP can be seen as an encoder which encodes the weights of an image classifier.

考虑图像分类问题，其目标是将图像分类到一组类别 $\mathcal{Y}$ 中。对于 ImageNet [30]，$\left| \mathcal{Y}\right|  = 1,{000}$。CLIP [66] 通过使用 $\mathcal{Y}$ 的文本类名(表示为 ${\mathcal{Y}}^{t}$)将图像分类表述为一个检索任务，将它们转换为固定的自然文本提示(例如，一张 \{类别\} 的图像)，并使用 CLIP 的语言编码器对其进行编码。然后使用 CLIP 的视觉编码器对图像进行编码。然后在共享嵌入空间中选择与图像最接近的类别 $y \in  \mathcal{Y}$ 作为预测类别。在这种情况下，CLIP 的语言编码器可以被视为对图像分类器的权重进行编码的编码器。

![0195d6ee-5e8d-7e59-bdaf-525eddd2b72d_3_312_203_1172_279_0.jpg](images/0195d6ee-5e8d-7e59-bdaf-525eddd2b72d_3_312_203_1172_279_0.jpg)

Figure 2: A high-level overview of our method for deriving visual concepts at the vision encoder (a), querying each visual concept individually from a textual bank to describe the visual concept in natural text (b), and then deriving textual concepts at the language encoder (c). The outputs of (b) and (c) share a common space of fine-grained textual concepts such that mutual information can be better calculated.

图 2:我们方法的高层次概述，包括在视觉编码器处推导视觉概念(a)，从文本库中单独查询每个视觉概念以用自然文本描述该视觉概念(b)，然后在语言编码器处推导文本概念(c)。(b)和(c)的输出共享一个细粒度文本概念的公共空间，以便更好地计算互信息。

Notation: We consider an image $I \in  {\mathbb{R}}^{H \times  W \times  3}$ , a CLIP model $\phi$ composed of a Vision Transformer (ViT) encoder ${\phi }^{v}$ and a language encoder ${\phi }^{l}$ , and a set of features $\dot{f} = {\phi }^{v}\left( I\right)  \in  {\mathbb{R}}^{N \times  C}$ extracted using ${\phi }^{v}$ , where $N = H/P \times  W/P$ , with $P$ being the patch size of ${\phi }^{v}$ and $C$ being the feature dimension size. ${\phi }^{v}$ and ${\phi }^{l}$ are each followed by separate projection layers $\psi  \in  {\mathbb{R}}^{C \times  c}$ which are fed with the [CLS] vector of the feature representation. For ease of notation, we represent the similarity score in the unified embedding space between an image-text input pair(i, j)by $s\left( {i, j}\right)  = \left( {{\psi }^{v} \circ  {\phi }^{v}\left( i\right) }\right)  \cdot  {\left( {\psi }^{l} \circ  {\phi }^{l}\left( j\right) \right) }^{T}$ . Similarly, we define ${s}^{l}\left( {{j}^{1},{j}^{2}}\right)$ as the similarity in the language embedding space between two text inputs $\left( {{j}^{1},{j}^{2}}\right)$ by replacing ${\psi }^{v},{\phi }^{v}$ with ${\psi }^{l},{\phi }^{l}$ , respectively.

符号说明:我们考虑一幅图像$I \in  {\mathbb{R}}^{H \times  W \times  3}$，一个由视觉变换器(ViT)编码器${\phi }^{v}$和语言编码器${\phi }^{l}$组成的CLIP模型$\phi$，以及一组使用${\phi }^{v}$提取的特征$\dot{f} = {\phi }^{v}\left( I\right)  \in  {\mathbb{R}}^{N \times  C}$，其中$N = H/P \times  W/P$，$P$为${\phi }^{v}$的图像块大小，$C$为特征维度大小。${\phi }^{v}$和${\phi }^{l}$之后分别连接独立的投影层$\psi  \in  {\mathbb{R}}^{C \times  c}$，这些投影层接收特征表示的[CLS]向量。为便于表示，我们用$s\left( {i, j}\right)  = \left( {{\psi }^{v} \circ  {\phi }^{v}\left( i\right) }\right)  \cdot  {\left( {\psi }^{l} \circ  {\phi }^{l}\left( j\right) \right) }^{T}$表示图像 - 文本输入对(i, j)在统一嵌入空间中的相似度得分。类似地，我们通过分别用${\psi }^{l},{\phi }^{l}$替换${\psi }^{v},{\phi }^{v}$，将两个文本输入$\left( {{j}^{1},{j}^{2}}\right)$在语言嵌入空间中的相似度定义为${s}^{l}\left( {{j}^{1},{j}^{2}}\right)$。

We utilize a Large Language Model (LLM) to generate descriptors ${}^{2}$ for all classes of a dataset we analyze. These descriptors are then combined into a unified set $\mathcal{D}$ which contains all class-agnostic textual descriptors (i.e., the class name does not appear in the descriptor), and its cardinality (the number of descriptors it contains) is $D$ , that is, $D = \left| \mathcal{D}\right|$ . For the ImageNet dataset, $D = 4,{229}$ after discarding repetitive descriptors across the entire pool. Concepts in $\mathcal{D}$ are now applicable to any object and are not restricted to the class they were extracted from. For example, the textual descriptor "can be hung from a tree" is extracted from the class "swing" in ImageNet, but can now be applied to many other classes (e.g., monkey, siamang). The prompt and LLM we used, along with a detailed ablation study on various prompts and LLMs as well as the relevance and diversity of the generated descriptors, are presented in Section A. 4 of the appendix.

我们利用大语言模型(LLM)为我们分析的数据集的所有类别生成描述符${}^{2}$。然后将这些描述符组合成一个统一的集合$\mathcal{D}$，该集合包含所有与类别无关的文本描述符(即描述符中不出现类别名称)，其基数(即包含的描述符数量)为$D$，即$D = \left| \mathcal{D}\right|$。对于ImageNet数据集，在去除整个集合中的重复描述符后，$D = 4,{229}$。$\mathcal{D}$中的概念现在适用于任何对象，而不限于从中提取它们的类别。例如，文本描述符“可以挂在树上”是从ImageNet的“秋千”类别中提取的，但现在可以应用于许多其他类别(例如，猴子、合趾猿)。我们使用的提示词和大语言模型，以及对各种提示词和大语言模型的详细消融研究，以及生成描述符的相关性和多样性，在附录的A.4节中给出。

Measuring the relationship and mutual knowledge between the image and text encoders for a given prediction is not straight-forward, as the two encoders differ in modality. Concepts in the language encoder can only be described via text, and concepts in the vision encoder can natively be described by image regions. Therefore, we need to map both concept modalities into a common space in order to quantify the mutual knowledge between the two encoders. A high-level overview of our method is shown in Figure 2. Given a set of images, we extract their visual features and perform spectral graph clustering on those features to obtain the most prominent image patches. We derive post-hoc grounded visual concepts representing object parts by applying Principal Component Analysis (PCA) or K-means clustering solely on the identified prominent patches (this is shown in Figure 2a). We encode the textual descriptors $\mathcal{D}$ with the CLIP language encoder, and query each visual concept region (encoded with the CLIP visual encoder) from the set of descriptors $\mathcal{D}$ . In this way, we associate each visual concept with a textual concept describing it in natural text, producing ${\mathcal{D}}_{v} \subseteq  \mathcal{D}$ (Figure 2b). In the final stage, the zero-shot predicted class and the set of descriptors $\mathcal{D}$ are encoded with the CLIP language encoder, and the most similar descriptors close to the zero-shot prediction in the language embedding space are retrieved, producing ${\mathcal{D}}_{\widehat{y}} \subseteq  \mathcal{D}$ (Figure 2c). Now, the two encoders share a common space of textual concepts, and the MI can be calculated efficiently in the discrete space using a probability-based approach by mapping each textual concept to a corresponding integer. The MI between ${\mathcal{D}}_{v}$ and ${\mathcal{D}}_{\widehat{y}}$ is defined as:

对于给定的预测，测量图像编码器和文本编码器之间的关系和共同知识并非易事，因为这两个编码器的模态不同。语言编码器中的概念只能通过文本描述，而视觉编码器中的概念本质上可以由图像区域描述。因此，为了量化两个编码器之间的共同知识，我们需要将这两种概念模态映射到一个共同的空间中。图2展示了我们方法的高层概述。给定一组图像，我们提取它们的视觉特征，并对这些特征进行谱图聚类，以获得最突出的图像块。我们仅对已识别的突出图像块应用主成分分析(PCA)或K均值聚类，从而推导出代表对象部分的事后基础视觉概念(如图2a所示)。我们使用CLIP语言编码器对文本描述符$\mathcal{D}$进行编码，并从描述符集合$\mathcal{D}$中查询每个视觉概念区域(使用CLIP视觉编码器进行编码)。通过这种方式，我们将每个视觉概念与用自然文本描述它的文本概念相关联，生成${\mathcal{D}}_{v} \subseteq  \mathcal{D}$(图2b)。在最后阶段，使用CLIP语言编码器对零样本预测类别和描述符集合$\mathcal{D}$进行编码，并检索在语言嵌入空间中最接近零样本预测的最相似描述符，生成${\mathcal{D}}_{\widehat{y}} \subseteq  \mathcal{D}$(图2c)。现在，两个编码器共享一个文本概念的共同空间，并且可以通过将每个文本概念映射到相应的整数，在离散空间中使用基于概率的方法高效地计算互信息(MI)。${\mathcal{D}}_{v}$和${\mathcal{D}}_{\widehat{y}}$之间的互信息定义为:

$$
I\left( {{\mathcal{D}}_{v};{\mathcal{D}}_{\widehat{y}}}\right)  = H\left( {\mathcal{D}}_{v}\right)  + H\left( {\mathcal{D}}_{\widehat{y}}\right)  - H\left( {{\mathcal{D}}_{v},{\mathcal{D}}_{\widehat{y}}}\right) , \tag{1}
$$

---

${}^{2}$ we will use the terms "descriptors" and "textual concepts" interchangeably

${}^{2}$ 我们将互换使用“描述符”和“文本概念”这两个术语

---

where $H$ represents the entropy and $H\left( {.,.}\right)$ represents the joint entropy which we compute through a simple contingency table. We provide the derivation for this formulation in Section B of the Appendix. In the next subsections, we describe each of the aformentioned steps shown in Figure 2. Finally, we elaborate on the formulation of mutual information dynamics in Section 3.3.

其中$H$表示熵，$H\left( {.,.}\right)$表示联合熵，我们通过一个简单的列联表来计算联合熵。我们在附录的B节中给出了这个公式的推导过程。在接下来的小节中，我们将描述图2中所示的上述每个步骤。最后，我们将在3.3节中详细阐述互信息动态的公式。

### 3.1 Multi-modal Concepts in the Visual Encoder

### 3.1 视觉编码器中的多模态概念

Visual-based Concepts: We first identify and separate the prominent patches in $f$ from those that are non-relevant. Drawing inspiration from prior works on unsupervised object localization [35, 55, 6], we propose to decompose the feature space $f$ into two groups, identifying the most prominent group as the focal point of the model. Specifically, we first construct an affinity matrix ${A}^{f}$ from the patchwise feature correlations of $f : {A}^{f} = f{f}^{T} \in  {\mathbb{R}}^{N \times  N}$ , where ${A}^{f}$ serves as a spectral graph representing rich semantic information within the features. Each node in this graph corresponds to an image patch. We then apply eigendecomposition on ${A}^{f}$ and extract the second largest (non-zero) eigenvector ${e}_{f} \in  {\mathbb{R}}^{N}$ , known as the Fiedler eigenvector. The sign of each element in ${e}_{f}$ represents a binary segmentation mask, dividing the graph nodes into two groups with minimal connectivity. We consider the subset of patches ${f}^{p}$ corresponding to a positive sign in ${e}_{f}$ as the most prominent and obtain an importance map. This decomposition technique is simple, fast and only requires features without needing gradients. We adopt Conditional Random Fields (CRF) [28] as an interpolation technique to interpolate the patch-based importance map to the resolution of the image. This approach provides better visual results than other interpolation techniques, while also preserving the underlying importance map (see experimental proof in Section A. 3 of the Appendix). Finally, we note that $f$ can be the tokens or keys of the last attention layer of the transformer. We ablate and analyze both in Section A. 1 of the Appendix, and explore using PCA as an alternative decomposition technique.

基于视觉的概念:我们首先识别并将$f$中的突出图像块与不相关的图像块分离。受先前关于无监督目标定位工作[35, 55, 6]的启发，我们提议将特征空间$f$分解为两组，将最突出的组确定为模型的焦点。具体来说，我们首先根据$f : {A}^{f} = f{f}^{T} \in  {\mathbb{R}}^{N \times  N}$的逐块特征相关性构建一个亲和矩阵${A}^{f}$，其中${A}^{f}$作为一个谱图，代表特征内丰富的语义信息。该图中的每个节点对应一个图像块。然后，我们对${A}^{f}$进行特征分解，并提取第二大(非零)特征向量${e}_{f} \in  {\mathbb{R}}^{N}$，即菲德勒特征向量。${e}_{f}$中每个元素的符号代表一个二进制分割掩码，将图节点划分为连接性最小的两组。我们将${e}_{f}$中对应正号的图像块子集${f}^{p}$视为最突出的，并获得一个重要性图。这种分解技术简单、快速，只需要特征，不需要梯度。我们采用条件随机场(CRF)[28]作为一种插值技术，将基于图像块的重要性图插值到图像的分辨率。与其他插值技术相比，这种方法提供了更好的视觉效果，同时也保留了底层的重要性图(见附录A.3节中的实验证明)。最后，我们注意到$f$可以是Transformer最后一个注意力层的标记或键。我们在附录A.1节中对两者进行消融和分析，并探索使用PCA作为一种替代的分解技术。

Next, our aim is to derive visual concepts (i.e., object parts) from the high-level prominent patches extracted in the previous step. We draw upon the methodologies from $\left\lbrack  {{40},1,9}\right\rbrack$ and apply either PCA or K-means clustering solely on the identified prominent image patches ${f}^{p}$ across $B$ images. In Section 4, we report results using each of these techniques. This process dissects the prominent image patches into a set of distinct components or clusters $\mathcal{L}$ of length $L$ , which express visual concepts. The visual concepts are unique, i.e., a patch can only be assigned to a single concept. An overview of this process is shown in Figure 2a.

接下来，我们的目标是从先前步骤中提取的高级显著斑块中推导出视觉概念(即对象部分)。我们借鉴了$\left\lbrack  {{40},1,9}\right\rbrack$中的方法，仅对跨$B$张图像识别出的显著图像斑块${f}^{p}$应用主成分分析(PCA)或K均值聚类。在第4节中，我们报告了使用这些技术各自得到的结果。此过程将显著图像斑块分解为一组长度为$L$的不同组件或聚类$\mathcal{L}$，这些组件或聚类表达了视觉概念。视觉概念是唯一的，即一个斑块只能被分配给一个单一的概念。图2a展示了这一过程的概述。

Describing Visual Concepts with Textual Descriptions: We seek to link each visual concept identified in the previous step, to a textual descriptor. Initially, we encode each visual concept using the CLIP visual encoder by applying the visual prompt engineering approach proposed in [54]. This approach involves drawing a red circle around the region of interest or blurring the area outside it, in order to direct the vision encoder's attention to that specific region, ensuring it encodes that area rather than the entire image. This approach has achieved strong zero-shot performance across diverse localization tasks, greatly surpassing cropping-based approaches [59]. A subsequent work [63] verifies the effectiveness of this approach (see more details in Section F of the Appendix). We apply this technique to all the detected visual concepts in the image to yield a set of prompted images ${\mathcal{I}}_{p} = \left\{  {{I}_{{p}^{1}}\ldots {I}_{{p}^{L}}}\right\}$ , where $L$ is the number of visual concepts. Next, we encode the textual descriptors $\mathcal{D}$ with the CLIP language encoder. Given that CLIP maps images and textual inputs close together in the embedding space, we find the associated top- $k$ textual descriptors for a given visual concept by simply computing the similarity between the embedding of ${I}_{p}^{j}$ and all textual descriptors $\mathcal{D} : s\left( {{I}_{{p}^{j}},{\mathcal{D}}_{i}}\right)$ , where $j$ ranges over the $L$ visual concepts, and $i$ ranges over the top- $k$ textual descriptors ${}^{3}$ . This results in an assignment matrix $\widehat{\mathcal{C}} \in  {\mathbb{R}}^{L \times  D}$ . However, we observed that, with this approach, numerous visual concepts get mapped to the same descriptor, suggesting a distribution with low entropy. To address this, we enhance the alignment of the two distributions by treating $- \widehat{\mathcal{C}}$ as a cost matrix and transforming it into a permutation matrix $\Pi$ via Optimal Transport:

用文本描述来描述视觉概念:我们试图将上一步中识别出的每个视觉概念与一个文本描述符关联起来。最初，我们通过应用[54]中提出的视觉提示工程方法，使用CLIP视觉编码器对每个视觉概念进行编码。这种方法包括在感兴趣区域周围画一个红色圆圈或模糊其外部区域，以便将视觉编码器的注意力引导到该特定区域，确保它对该区域而非整个图像进行编码。这种方法在各种定位任务中实现了强大的零样本性能，大大超越了基于裁剪的方法[59]。后续的一项工作[63]验证了这种方法的有效性(详见附录F节)。我们将这种技术应用于图像中所有检测到的视觉概念，以生成一组提示图像${\mathcal{I}}_{p} = \left\{  {{I}_{{p}^{1}}\ldots {I}_{{p}^{L}}}\right\}$，其中$L$是视觉概念的数量。接下来，我们使用CLIP语言编码器对文本描述符$\mathcal{D}$进行编码。鉴于CLIP在嵌入空间中将图像和文本输入映射得很接近，我们通过简单地计算${I}_{p}^{j}$的嵌入与所有文本描述符$\mathcal{D} : s\left( {{I}_{{p}^{j}},{\mathcal{D}}_{i}}\right)$之间的相似度，为给定的视觉概念找到相关的前$k$个文本描述符，其中$j$遍历$L$个视觉概念，$i$遍历前$k$个文本描述符${}^{3}$。这会得到一个分配矩阵$\widehat{\mathcal{C}} \in  {\mathbb{R}}^{L \times  D}$。然而，我们观察到，使用这种方法时，许多视觉概念会被映射到同一个描述符，这表明分布的熵较低。为了解决这个问题，我们通过将$- \widehat{\mathcal{C}}$视为成本矩阵，并通过最优传输将其转换为置换矩阵$\Pi$来增强这两种分布的对齐:

$$
\widehat{\Pi }\left( {L, D}\right)  = \mathop{\operatorname{argmax}}\limits_{{\Pi  \in  {\mathbb{R}}^{L \times  D}}}\mathop{\sum }\limits_{{l \in  \mathcal{L}, d \in  \mathcal{D}}}{\Pi }_{ld}\exp \left( {\tau {\widehat{\mathcal{C}}}_{ld}}\right)  \tag{2}
$$

where $\tau$ is a temperature parameter. We solve this optimization problem efficiently with the Sinkhorn-Knopp algorithm [56]. The top textual descriptor from each column of $\Pi$ is then selected as the descriptor for the respective visual concept represented by each row of $\Pi$ . We denote the textual concepts produced by this stage as ${\mathcal{D}}_{v}$ . In Section A. 2 of the Appendix, we perform ablation studies on Optimal Transport and demonstrate that it achieves diversity among the different visual concepts.

其中$\tau$是一个温度参数。我们使用Sinkhorn - Knopp算法[56]有效地解决了这个优化问题。然后，从$\Pi$的每一列中选择得分最高的文本描述符作为由$\Pi$的每一行所代表的相应视觉概念的描述符。我们将这一阶段产生的文本概念表示为${\mathcal{D}}_{v}$。在附录A.2节中，我们对最优传输进行了消融研究，并证明它在不同的视觉概念之间实现了多样性。

---

${}^{3}$ we select the descriptors with scores more than 0.02 points above the50-th percentile of values

${}^{3}$我们选择得分比值的第50百分位数高出0.02分以上的描述符

---

### 3.2 Textual Concepts in the Language Encoder

### 3.2 语言编码器中的文本概念

Given the zero-shot prediction of CLIP denoted as $\widehat{y}$ with ${\widehat{y}}^{t}$ being a textual representation of the prediction, we can represent $\widehat{y}$ as the center of a cluster in the joint space (green point in Figure 1c), with other points in that cluster (grey points) being textual concepts directly explaining the prediction $\widehat{y}$ . We use the same set of textual descriptors $\mathcal{D}$ (described in Section 3) to identify those concepts. We extract those textual concepts by computing the similarity between the language embeddings of the predicted class and the language embeddings of all descriptors $\mathcal{D}$ , via: ${s}^{l}\left( {{\widehat{y}}^{t},\mathcal{D}}\right)$ . We select the top- $u$ descriptors with the highest similarity score as those textual concepts and denote them by ${\mathcal{D}}_{\widehat{y}}$ .

给定CLIP的零样本预测，记为$\widehat{y}$，其中${\widehat{y}}^{t}$是该预测的文本表示，我们可以将$\widehat{y}$表示为联合空间中一个聚类的中心(图1c中的绿点)，该聚类中的其他点(灰点)是直接解释预测$\widehat{y}$的文本概念。我们使用同一组文本描述符$\mathcal{D}$(在第3节中描述)来识别这些概念。我们通过计算预测类别的语言嵌入与所有描述符$\mathcal{D}$的语言嵌入之间的相似度来提取这些文本概念，方法如下:${s}^{l}\left( {{\widehat{y}}^{t},\mathcal{D}}\right)$。我们选择相似度得分最高的前$u$个描述符作为这些文本概念，并将它们记为${\mathcal{D}}_{\widehat{y}}$。

### 3.3 Mutual Information Dynamics

### 3.3 互信息动态

A simple calculation of the MI between the vision and language concepts as in Eq. (1), fails to account for the contribution of each individual information unit (i.e., concept) to the overall MI. We define that two sources have a strong shared knowledge when a source retains knowledge about the other, despite removing important information units from it. To realize this, we first organize the textual concepts of the vision encoder ${\mathcal{D}}_{v}$ in descending order based on their importance to the image, and sequentially ablate them, removing one at each step and calculating the MI (Eq. (1)) between them and ${\mathcal{D}}_{\widehat{y}}$ after each removal step. This process generates a curve. We report the Area under the Curve (AUC) to represent the MI dynamics. The strength of the shared information can be identified by how fast the MI in a curve drops. A higher AUC indicates gradual or late drops of MI in the curve, and thus stronger shared knowledge. A lower AUC indicates sharp or early drops of MI as concepts are removed, and thus weaker shared knowledge. We note that knowledge-retaining is not attributed to redundant information units since all concepts in $\mathcal{D}$ are unique.

像式(1)那样简单计算视觉和语言概念之间的互信息(MI)，无法考虑每个单独信息单元(即概念)对整体互信息的贡献。我们定义，当一个源在去除重要信息单元后仍保留关于另一个源的知识时，这两个源具有强大的共享知识。为了实现这一点，我们首先根据视觉编码器${\mathcal{D}}_{v}$的文本概念对图像的重要性按降序排列，并依次去除它们，每次去除一个，并在每次去除步骤后计算它们与${\mathcal{D}}_{\widehat{y}}$之间的互信息(式(1))。这个过程会生成一条曲线。我们报告曲线下面积(AUC)来表示互信息动态。共享信息的强度可以通过曲线中互信息下降的速度来确定。较高的AUC表示曲线中互信息逐渐下降或后期下降，因此共享知识更强。较低的AUC表示随着概念的去除，互信息急剧下降或早期下降，因此共享知识较弱。我们注意到，知识保留并非归因于冗余信息单元，因为$\mathcal{D}$中的所有概念都是唯一的。

Finally, it is worth noting that the MI dynamics also serve as an evaluation strategy for the identified mutual concepts. By assuming that stronger shared knowledge is associated with higher zero-shot accuracy, we would expect a positive correlation between the AUC and zero-shot accuracy.

最后，值得注意的是，互信息动态也可作为对已识别的互概念的一种评估策略。假设更强的共享知识与更高的零样本准确率相关，我们预计AUC与零样本准确率之间存在正相关关系。

## 4 Experiments and Analysis

## 4 实验与分析

Evaluation of Multimodal Concepts: Since the multimodal concepts serve as inputs for MI analysis, we begin by evaluating these concepts to demonstrate their effectiveness and reliability. We formulate 3 baselines that adapt existing literature of single-modality concept-based explanations, to their multimodal case. MM-CBM is a formulation of Label-Free Concept Bottleneck Models [39] to the case of Multimodal Concept Bottlenecks. MM-ProtoSim is a formulation of the prototype-based ProtoSim [38] adapted to the multimodal case. We compare the performance of these baselines in Table 5 of the Appendix. The last baseline is denoted as "Feature Maps" and is a formulation of Neuron Annotation works $\left\lbrack  {{19},{11}}\right\rbrack$ to suit our case. Feature Maps identifies spatial feature activation maps as concepts. All baselines require training to generate textual concepts, and we train them on the full ImageNet training set. All baselines as well as our multimodal concepts are evaluated with 4 evaluation metrics common in the literature of XAI, namely, Insertion (higher is better) and Deletion (lower is better) [42], Accuracy Drop (low is better) and Accuracy Increase (higher is better) [7]. We provide a description of the baselines with qualitative example in Section D of the Appendix, and of the evaluation metrics in Section E of the Appendix. As seen in Table 1, our concept-based multimodal explanations outperforms all baselines except on the Insertion Metric, where the MM-CBM baseline wins. Although not within the scope of our work, Table 5 of the Appendix also shows that our MM-ProtoSim baseline achieves state-of-the-art results on concept bottleneck models, on the challenging ImageNet dataset in which many other works fail to scale to. We also show that it not only maintains standard accuracy, but significantly improves it, another phenomenon in which many previous works including LF-CBM fail to achieve. This shows the effectiveness of considering multimodal concepts for modeling discriminative tasks.

多模态概念的评估:由于多模态概念是互信息分析的输入，我们首先评估这些概念，以证明它们的有效性和可靠性。我们制定了3个基线，将现有的基于单模态概念的解释文献应用于多模态情况。MM - CBM是将无标签概念瓶颈模型[39]应用于多模态概念瓶颈的情况。MM - ProtoSim是将基于原型的ProtoSim[38]方法应用于多模态情况。我们在附录表5中比较了这些基线的性能。最后一个基线记为“特征图”，是将神经元注释工作$\left\lbrack  {{19},{11}}\right\rbrack$进行调整以适应我们的情况。特征图将空间特征激活图识别为概念。所有基线都需要进行训练以生成文本概念，我们在完整的ImageNet训练集上对它们进行训练。所有基线以及我们的多模态概念都使用可解释人工智能(XAI)文献中常见的4种评估指标进行评估，即插入指标(越高越好)和删除指标(越低越好)[42]、准确率下降(越低越好)和准确率提升(越高越好)[7]。我们在附录D节中对基线进行了描述并给出了定性示例，在附录E节中对评估指标进行了描述。如表1所示，我们基于概念的多模态解释在除插入指标外的所有指标上都优于所有基线，在插入指标上MM - CBM基线获胜。虽然这不在我们的工作范围内，但附录表5还显示，我们的MM - ProtoSim基线在概念瓶颈模型上取得了最先进的结果，在具有挑战性的ImageNet数据集上，许多其他工作都无法扩展到该数据集。我们还表明，它不仅保持了标准准确率，而且显著提高了准确率，这是包括LF - CBM在内的许多先前工作都未能实现的另一个现象。这表明考虑多模态概念对建模判别任务是有效的。

Table 1: Evaluation scores of our multimodal explanations compared to the baselines established. All use the same features, model and textual concept bank for fair comparison.

表1:我们的多模态解释与已建立的基线的评估得分比较。所有方法都使用相同的特征、模型和文本概念库以进行公平比较。

<table><tr><td>Explanation</td><td>Requires Training</td><td>Delet. $\downarrow$</td><td>Insert.↑</td><td>AccDrop $\downarrow$</td><td>AccInc↑</td></tr><tr><td>MM-CBM</td><td>Yes</td><td>3.147</td><td>3.385</td><td>2.634</td><td>1.013</td></tr><tr><td>MM-ProtoSim</td><td>Yes</td><td>3.149</td><td>3.358</td><td>2.665</td><td>0.943</td></tr><tr><td>Feature Maps</td><td>Yes</td><td>2.921</td><td>3.114</td><td>2.283</td><td>1.233</td></tr><tr><td>Ours (PCA)</td><td>No</td><td>2.460</td><td>3.168</td><td>1.582</td><td>1.849</td></tr><tr><td>Ours (K-means)</td><td>No</td><td>2.422</td><td>3.122</td><td>1.555</td><td>1.781</td></tr></table>

<table><tbody><tr><td>解释</td><td>需要训练</td><td>删除。$\downarrow$</td><td>插入。↑</td><td>准确率下降 $\downarrow$</td><td>准确率上升↑</td></tr><tr><td>多模态对比基准模型(MM-CBM)</td><td>是</td><td>3.147</td><td>3.385</td><td>2.634</td><td>1.013</td></tr><tr><td>多模态原型相似度(MM-ProtoSim)</td><td>是</td><td>3.149</td><td>3.358</td><td>2.665</td><td>0.943</td></tr><tr><td>特征图</td><td>是</td><td>2.921</td><td>3.114</td><td>2.283</td><td>1.233</td></tr><tr><td>我们的方法(主成分分析，PCA)</td><td>否</td><td>2.460</td><td>3.168</td><td>1.582</td><td>1.849</td></tr><tr><td>我们的方法(K-means聚类)</td><td>否</td><td>2.422</td><td>3.122</td><td>1.555</td><td>1.781</td></tr></tbody></table>

Table 2: Effectiveness and Relevancy of our multimodal concepts in boosting zero-shot accuracy of both ResNet and ViT CLIP models on the ImageNet validation set compared to baselines [36, 43].

表2:与基线方法[36, 43]相比，我们的多模态概念在提升ResNet和ViT CLIP模型在ImageNet验证集上的零样本准确率方面的有效性和相关性。

<table><tr><td>ResNets</td><td>Base</td><td>Ours</td><td>$\Delta$</td><td>ViTs</td><td>Base</td><td>Ours</td><td>$\Delta$</td></tr><tr><td>RN50</td><td>59.54</td><td>61.85</td><td>+2.31</td><td>ViT-B/16</td><td>67.93</td><td>70.28</td><td>+2.35</td></tr><tr><td>RN50x4</td><td>64.36</td><td>67.93</td><td>+3.57</td><td>ViT-B/32</td><td>63.28</td><td>65.58</td><td>+2.30</td></tr><tr><td>RN50x16</td><td>68.47</td><td>72.22</td><td>+3.75</td><td>ViT-L/14</td><td>74.69</td><td>76.74</td><td>+2.05</td></tr><tr><td>RN101</td><td>60.68</td><td>64.14</td><td>+3.46</td><td>ViT-L/14@336px</td><td>75.49</td><td>77.64</td><td>+2.15</td></tr></table>

<table><tbody><tr><td>残差网络(ResNets)</td><td>基础</td><td>我们的方法</td><td>$\Delta$</td><td>视觉Transformer(ViTs)</td><td>基础</td><td>我们的方法</td><td>$\Delta$</td></tr><tr><td>残差网络50层(RN50)</td><td>59.54</td><td>61.85</td><td>+2.31</td><td>视觉Transformer基础版/16(ViT - B/16)</td><td>67.93</td><td>70.28</td><td>+2.35</td></tr><tr><td>残差网络50层x4(RN50x4)</td><td>64.36</td><td>67.93</td><td>+3.57</td><td>视觉Transformer基础版/32(ViT - B/32)</td><td>63.28</td><td>65.58</td><td>+2.30</td></tr><tr><td>残差网络50层x16(RN50x16)</td><td>68.47</td><td>72.22</td><td>+3.75</td><td>视觉Transformer大版本/14(ViT - L/14)</td><td>74.69</td><td>76.74</td><td>+2.05</td></tr><tr><td>残差网络101层(RN101)</td><td>60.68</td><td>64.14</td><td>+3.46</td><td>视觉Transformer大版本/14@336像素(ViT - L/14@336px)</td><td>75.49</td><td>77.64</td><td>+2.15</td></tr></tbody></table>

Next, we show how our multimodal explanations are an effective application of CLIP prompt engineering for image classification with descriptions $\left\lbrack  {{36},{43}}\right\rbrack$ , achieving gains in zero-shot accuracy of up to 3.75%. Another purpose of this experiment is to show that the multimodal concepts and descriptors identified, are a reliable source of input for mutual information analysis. We start by identifying the two most similar classes to the zero-shot prediction in the CLIP language embedding space. We then take the validation images from both of these classes, and extract multi-modal explanations using our approach. We then take the textual component of the multi-modal explanations as additional descriptors $\in  \mathcal{D}$ and re-evaluate the zero-shot classification of CLIP ${}^{4}$ . If the detected open-set concepts are relevant to the prediction, we should expect an improvement in zero-shot classification accuracy. As shown in Table 2, this application shows significant gains in zero-shot accuracy for all CLIP models relative to the baselines [36, 43]. This demonstrates the effectiveness and relevance of the detected concepts to the CLIP model. More details about this experiment can be found in Section $\mathrm{K}$ of the Appendix.

接下来，我们展示我们的多模态解释如何成为CLIP提示工程在带描述的图像分类中的有效应用 $\left\lbrack  {{36},{43}}\right\rbrack$，实现高达3.75%的零样本准确率提升。该实验的另一个目的是表明，所识别出的多模态概念和描述符是互信息分析的可靠输入源。我们首先在CLIP语言嵌入空间中确定与零样本预测最相似的两个类别。然后，我们从这两个类别中选取验证图像，并使用我们的方法提取多模态解释。接着，我们将多模态解释的文本部分作为额外的描述符 $\in  \mathcal{D}$，并重新评估CLIP的零样本分类 ${}^{4}$。如果检测到的开放集概念与预测相关，我们应该期望零样本分类准确率有所提高。如表2所示，相对于基线 [36, 43]，此应用在所有CLIP模型的零样本准确率上都显示出显著提升。这证明了检测到的概念对CLIP模型的有效性和相关性。关于该实验的更多细节可在附录的第 $\mathrm{K}$ 节中找到。

Models and Datasets: Our MI analysis considers a wide range of CLIP models varying in architecture, size and pretraining datasets, evaluated on the full ImageNet validation split [30]. We consider the original CLIP ViT models [44]: ViT-B/16 and ViT-B/32 are base models of patch size 16 and 32, respectively; ViT-L/14 and ViT-L/14@336 are large models of patch size 14, where the later (denoted as ViT-L/14↑) is finetuned with an image size of ${336} \times  {336}$ . The aforementioned models are trained on the WIT 400M dataset [44]. We also consider additional models from OpenCLIP [22,8] trained on DataComp [16] of 1B images and Data Filtering Network (DFN) [14] of 2B images. Both of these datasets use filtering strategies to curate clean, higher-quality data. We refer to these models with an additional suffix: -dcp and -dfn. Ultimately, we can analyze how model (and patch) size and pretraining datasets affect the information channel. We also consider the CNN-based ResNet (RN) CLIP models trained on WIT 400M: RN-50, RN-101, RN-50×4 and RN-50×16. The RN models with $\left( {\times r}\right)$ denote width scaling $r$ . We also consider two CLIP ConvNeXt-Base models [33] from OpenCLIP, trained on LAION-400M [50] (ConvNeXt-B1), and on an aesthetic subset of LAION-5B [49] (ConvNeXt-B2). In total, our analysis comprises 13 CLIP models.

模型和数据集:我们的互信息(MI)分析考虑了一系列架构、大小和预训练数据集不同的CLIP模型，并在完整的ImageNet验证集分割上进行评估 [30]。我们考虑原始的CLIP ViT模型 [44]:ViT - B/16和ViT - B/32分别是块大小为16和32的基础模型；ViT - L/14和ViT - L/14@336是块大小为14的大型模型，其中后者(表示为ViT - L/14↑)是使用大小为 ${336} \times  {336}$ 的图像进行微调的。上述模型是在WIT 400M数据集 [44] 上训练的。我们还考虑了来自OpenCLIP [22, 8] 的其他模型，这些模型分别在包含10亿张图像的DataComp [16] 和包含20亿张图像的数据过滤网络(DFN) [14] 上进行训练。这两个数据集都使用过滤策略来筛选出干净、高质量的数据。我们给这些模型添加额外的后缀:-dcp和 - dfn。最终，我们可以分析模型(和块)大小以及预训练数据集如何影响信息通道。我们还考虑了在WIT 400M上训练的基于卷积神经网络(CNN)的ResNet(RN)CLIP模型:RN - 50、RN - 101、RN - 50×4和RN - 50×16。带有 $\left( {\times r}\right)$ 的RN模型表示宽度缩放 $r$。我们还考虑了OpenCLIP中的两个CLIP ConvNeXt - 基础模型 [33]，它们分别在LAION - 400M [50](ConvNeXt - B1)和LAION - 5B [49] 的美学子集(ConvNeXt - B2)上进行训练。总的来说，我们的分析涵盖了13个CLIP模型。

Quantitative Analysis: We start by examining the MI and its dynamics across models. In Table 3, we report the MI (applying Eq. 1) and AUC (as described in Section 3.3) for all CLIP models we analyze. Additionally, we include the dataset size used for training each model and its respective zero-shot classification accuracy on the ImageNet validation set [30]. We report these metrics for both PCA and K-means, which consistently show correlation. We sort the models based on their top-1 zero-shot accuracy. We remind readers that we define stronger shared knowledge based on higher AUC rather than higher MI. In Figure 5 (detailed further), we provide examples of classes that support this claim and contribute to this phenomenon. Our first observation is that AUC aligns well with accuracy, with ViT-B/16-dfn ranking top. Our second observation is that CLIP ViT models are characterized with stronger shared knowledge than CLIP CNNs (ResNets and ConvNeXts). This supports the premise that pretraining transformer models, which lack inductive biases, perform better when trained on larger datasets [12].

定量分析:我们首先研究互信息及其在不同模型中的动态变化。在表3中，我们报告了所分析的所有CLIP模型的互信息(应用公式1)和AUC(如第3.3节所述)。此外，我们还列出了用于训练每个模型的数据集大小及其在ImageNet验证集上的相应零样本分类准确率 [30]。我们报告了主成分分析(PCA)和K - 均值聚类的这些指标，它们始终显示出相关性。我们根据模型的前1名零样本准确率对其进行排序。我们提醒读者，我们基于更高的AUC而不是更高的互信息来定义更强的共享知识。在图5(进一步详细说明)中，我们提供了支持这一说法并导致这一现象的类别示例。我们的第一个观察结果是，AUC与准确率高度一致，ViT - B/16 - dfn排名最高。我们的第二个观察结果是，CLIP ViT模型比CLIP CNN(ResNet和ConvNeXt)具有更强的共享知识。这支持了这样一个前提，即缺乏归纳偏置的预训练Transformer模型在更大的数据集上训练时表现更好 [12]。

---

${}^{4}$ We find that some classes are overly discriminative, in which multimodal explanations of their neighboring classes introduce noise. For those classes, we simply do not introduce any additional descriptors to them.

${}^{4}$ 我们发现有些类别具有过度的区分性，其相邻类别的多模态解释会引入噪声。对于这些类别，我们干脆不为它们引入任何额外的描述符。

---

Table 3: MI and AUC scores for different model families using PCA and K-means evaluated on the full ImageNet validation split, along with the pretraining data and Top-1 accuracy.

表3:在完整的ImageNet验证集分割上使用PCA和K - 均值评估的不同模型族的互信息和AUC分数，以及预训练数据和前1名准确率。

<table><tr><td rowspan="2">Model Family</td><td rowspan="2">Model</td><td rowspan="2">Data Size</td><td rowspan="2">Top-1 (%)</td><td colspan="2">$\mathbf{{MI}}$</td><td colspan="2">AUC</td></tr><tr><td>PCA</td><td>K-means</td><td>PCA</td><td>K-means</td></tr><tr><td rowspan="7">ViTs</td><td>ViT-B/32</td><td>400M</td><td>61.66</td><td>7.40</td><td>7.26</td><td>3.61</td><td>3.39</td></tr><tr><td>ViT-B/16</td><td>400M</td><td>67.70</td><td>7.50</td><td>7.44</td><td>3.62</td><td>3.53</td></tr><tr><td>ViT-B/32-dcp</td><td>1B</td><td>68.88</td><td>7.79</td><td>7.65</td><td>3.93</td><td>3.70</td></tr><tr><td>ViT-B/16-dcp</td><td>1B</td><td>73.37</td><td>7.68</td><td>7.58</td><td>3.99</td><td>3.81</td></tr><tr><td>ViT-L/14</td><td>400M</td><td>74.77</td><td>7.94</td><td>7.89</td><td>4.47</td><td>4.37</td></tr><tr><td>ViT-L/14↑</td><td>400M</td><td>76.23</td><td>7.96</td><td>7.93</td><td>4.51</td><td>4.44</td></tr><tr><td>ViT-B/16-dfn</td><td>2B</td><td>76.24</td><td>8.19</td><td>8.11</td><td>4.62</td><td>4.46</td></tr><tr><td rowspan="4">ResNets</td><td>RN-50</td><td>400M</td><td>58.42</td><td>7.14</td><td>7.20</td><td>3.23</td><td>3.32</td></tr><tr><td>RN-101</td><td>400M</td><td>60.90</td><td>7.43</td><td>7.53</td><td>3.49</td><td>3.60</td></tr><tr><td>RN-50 $\times  4$</td><td>400M</td><td>65.28</td><td>7.53</td><td>7.58</td><td>3.84</td><td>3.90</td></tr><tr><td>RN-50 $\times  {16}$</td><td>400M</td><td>70.04</td><td>7.51</td><td>7.63</td><td>3.85</td><td>4.03</td></tr><tr><td rowspan="2">ConvNeXTs</td><td>CNeXt-B1</td><td>400M</td><td>65.36</td><td>6.47</td><td>6.66</td><td>2.54</td><td>2.80</td></tr><tr><td>CNeXt-B2</td><td>13B</td><td>71.22</td><td>7.16</td><td>7.56</td><td>3.19</td><td>3.74</td></tr></table>

<table><tbody><tr><td rowspan="2">模型家族</td><td rowspan="2">模型</td><td rowspan="2">数据规模</td><td rowspan="2">前1准确率(%)</td><td colspan="2">$\mathbf{{MI}}$</td><td colspan="2">曲线下面积(AUC)</td></tr><tr><td>主成分分析(PCA)</td><td>K均值聚类(K-means)</td><td>主成分分析(PCA)</td><td>K均值聚类(K-means)</td></tr><tr><td rowspan="7">视觉Transformer(ViTs)</td><td>视觉Transformer基础版/32(ViT-B/32)</td><td>400M</td><td>61.66</td><td>7.40</td><td>7.26</td><td>3.61</td><td>3.39</td></tr><tr><td>视觉Transformer基础版/16(ViT-B/16)</td><td>400M</td><td>67.70</td><td>7.50</td><td>7.44</td><td>3.62</td><td>3.53</td></tr><tr><td>视觉Transformer基础版/32-动态通道剪枝(ViT-B/32-dcp)</td><td>1B</td><td>68.88</td><td>7.79</td><td>7.65</td><td>3.93</td><td>3.70</td></tr><tr><td>视觉Transformer基础版/16-动态通道剪枝(ViT-B/16-dcp)</td><td>1B</td><td>73.37</td><td>7.68</td><td>7.58</td><td>3.99</td><td>3.81</td></tr><tr><td>视觉Transformer大型版/14(ViT-L/14)</td><td>400M</td><td>74.77</td><td>7.94</td><td>7.89</td><td>4.47</td><td>4.37</td></tr><tr><td>视觉Transformer大型版/14↑(ViT-L/14↑)</td><td>400M</td><td>76.23</td><td>7.96</td><td>7.93</td><td>4.51</td><td>4.44</td></tr><tr><td>视觉Transformer基础版/16-动态特征归一化(ViT-B/16-dfn)</td><td>2B</td><td>76.24</td><td>8.19</td><td>8.11</td><td>4.62</td><td>4.46</td></tr><tr><td rowspan="4">残差网络(ResNets)</td><td>残差网络-50(RN-50)</td><td>400M</td><td>58.42</td><td>7.14</td><td>7.20</td><td>3.23</td><td>3.32</td></tr><tr><td>残差网络-101(RN-101)</td><td>400M</td><td>60.90</td><td>7.43</td><td>7.53</td><td>3.49</td><td>3.60</td></tr><tr><td>残差网络-50 $\times  4$</td><td>400M</td><td>65.28</td><td>7.53</td><td>7.58</td><td>3.84</td><td>3.90</td></tr><tr><td>残差网络-50 $\times  {16}$</td><td>400M</td><td>70.04</td><td>7.51</td><td>7.63</td><td>3.85</td><td>4.03</td></tr><tr><td rowspan="2">卷积神经网络(ConvNeXTs)</td><td>卷积神经网络B1(CNeXt-B1)</td><td>400M</td><td>65.36</td><td>6.47</td><td>6.66</td><td>2.54</td><td>2.80</td></tr><tr><td>卷积神经网络B2(CNeXt-B2)</td><td>13B</td><td>71.22</td><td>7.16</td><td>7.56</td><td>3.19</td><td>3.74</td></tr></tbody></table>

To further understand the effect of model size and pretraining datasets on MI dynamics, we divide the models into two families. We first fix the pretraining data and vary the model and patch size. For this analysis, we use ViT-B/16, ViT-B/32, ViT-L/14 and ViT-L/14↑ trained on WIT 400M. We show the curves in Figure 3 (left). As shown, larger models with more patches (either via a smaller patch size or a via a larger image size) correspond to higher AUC, suggesting that these models are better at encoding shared knowledge. Next, we fix the model size and vary the pretraining data. The results are shown in Figure 3 (middle). As shown, larger and higher-quality data lead to improved shared encoding on ImageNet. In Section G of the Appendix, we also perform analysis on the Places365 [65] and Food101 [5] datasets. The previous observations may be well-known and non-surprising. Nonetheless, what is noteworthy is the direct relationship established between the strength of the shared encoding (represented by the AUC) and model size, pretraining data and zero-shot accuracy. For example, we fit a linear line to the data points to approximate the AUC-accuracy relationship in Figure 3 (right), and determine the coefficients to be 11.24 and 25.97 for ViT models (blue line). This suggests that the accuracy is related to the strength by a factor of 11 . Similarly, approximating the AUC-data relationship provides insights into the amount and quality of pretraining data required to achieve a desired strength of shared knowledge. This principle also extends to model size and could allow us to design small, efficient models. Finally, this relationship is valuable for model selection, especially in cases where accuracy alone is insufficient for distinguishing between models (e.g., models with very similar accuracies such as ViT-L/14↑ and ViT-B/16-dfn). In Table 3 and Figure 3 (green line), we show that AUC demonstrates a linear correlation with accuracy and model size within the ResNet family. It is worth noting that AUC-Accuracy relationship only holds within a given architecture; different architectures (ViT, ResNets, ConvNeXts) have different designs and ways of learning representation. Therefore, they differ in how they utilize data and encode shared knowledge. As an example, $\mathrm{{RN}} - {50} \times  {16}$ includes much more dimensions to store information than ConvNeXt-B2, and it is reasonable to expect that the shared information in RN-50x16 is stronger, despite ConvNeXt-B2 achieves a slightly higher accuracy. In fact, the gradual design trajectory of ConvNeXt [33] was built and tuned towards a higher classification accuracy.

为了进一步理解模型大小和预训练数据集对互信息(MI)动态的影响，我们将模型分为两类。首先，我们固定预训练数据，改变模型和图像块(patch)大小。在这项分析中，我们使用在WIT 400M数据集上训练的ViT - B/16、ViT - B/32、ViT - L/14和ViT - L/14↑模型。我们在图3(左)中展示了相关曲线。如图所示，具有更多图像块的更大模型(通过更小的图像块大小或更大的图像尺寸)对应着更高的曲线下面积(AUC)，这表明这些模型在编码共享知识方面表现更优。接下来，我们固定模型大小，改变预训练数据。结果如图3(中)所示。如图所示，更大且质量更高的数据能提升在ImageNet数据集上的共享编码效果。在附录的G节中，我们还对Places365 [65]和Food101 [5]数据集进行了分析。之前的观察结果可能是众所周知且不足为奇的。然而，值得注意的是，共享编码强度(由AUC表示)与模型大小、预训练数据和零样本准确率之间建立了直接关系。例如，我们对数据点拟合一条直线来近似图3(右)中的AUC - 准确率关系，并确定ViT模型(蓝线)的系数分别为11.24和25.97。这表明准确率与强度的关系系数为11。同样，近似AUC - 数据关系有助于了解实现所需共享知识强度所需的预训练数据的数量和质量。这一原则也适用于模型大小，使我们能够设计出小型高效的模型。最后，这种关系对于模型选择很有价值，特别是在仅靠准确率不足以区分模型的情况下(例如，ViT - L/14↑和ViT - B/16 - dfn等准确率非常相似的模型)。在表3和图3(绿线)中，我们展示了在ResNet模型家族中，AUC与准确率和模型大小呈线性相关。值得注意的是，AUC - 准确率关系仅在给定的架构内成立；不同的架构(ViT、ResNet、ConvNeXt)有不同的设计和学习表示的方式。因此，它们在利用数据和编码共享知识方面存在差异。例如，$\mathrm{{RN}} - {50} \times  {16}$比ConvNeXt - B2包含更多用于存储信息的维度，尽管ConvNeXt - B2的准确率略高，但可以合理预期RN - 50x16中的共享信息更强。事实上，ConvNeXt [33]的渐进式设计轨迹是朝着更高的分类准确率构建和调整的。

Analyzing Concepts in the Vision Encoder: Although the focus of our work is to interpret and analyze mutual concepts in the vision and language encoders of CLIP, we can still utilize our multimodal explanations to inspect internal concepts learned in the vision encoder of CLIP for individual instances. Figure 4 shows 4 examples, each represented by a distinct visual cluster denoted by a different color. The corresponding textual description for each visual cluster is provided below, aligned with its corresponding color. Different from attribution-based techniques [51,60,45,2] which typically highlight high-level and general features, our multimodal explanations disentangle the features to offer visually and textually distinctive, fine-grained concepts. An example of such

分析视觉编码器中的概念:尽管我们工作的重点是解释和分析CLIP的视觉和语言编码器中的共同概念，但我们仍然可以利用多模态解释来检查CLIP视觉编码器针对单个实例学习到的内部概念。图4展示了4个示例，每个示例由一个不同颜色表示的独特视觉簇代表。每个视觉簇对应的文本描述如下，与相应的颜色对齐。与基于归因的技术[51,60,45,2](通常突出高级和通用特征)不同，我们的多模态解释将特征解耦，以提供在视觉和文本上具有独特性的细粒度概念。

![0195d6ee-5e8d-7e59-bdaf-525eddd2b72d_8_316_210_1169_312_0.jpg](images/0195d6ee-5e8d-7e59-bdaf-525eddd2b72d_8_316_210_1169_312_0.jpg)

Figure 3: MI Dynamics curve comparing model families (left) and pretraining datasets (middle). Correlation of AUC with zero-shot classification accuracy is shown right for ViTs and ResNets.

图3:比较模型家族(左)和预训练数据集(中)的互信息(MI)动态曲线。右侧展示了ViT和ResNet模型的AUC与零样本分类准确率的相关性。

![0195d6ee-5e8d-7e59-bdaf-525eddd2b72d_8_314_638_1172_296_0.jpg](images/0195d6ee-5e8d-7e59-bdaf-525eddd2b72d_8_314_638_1172_296_0.jpg)

Figure 4: Qualitative examples of multimodal concepts in the vision encoder. The second-top textual descriptor may be omitted to avoid clutter.

图4:视觉编码器中多模态概念的定性示例。为避免混乱，可能会省略倒数第二行的文本描述符。

concepts in Figure 4 are long feathered ears, long whiskers (first example); blue plumage, red beak (third example). These types of concepts are significantly more beneficial for understanding models and analyzing MI. More examples of our multimodal concepts are in Section H of the Appendix.

图4中的概念示例有长羽毛耳朵、长胡须(第一个示例)；蓝色羽毛、红色鸟喙(第三个示例)。这类概念对于理解模型和分析互信息(MI)更有帮助。附录的H节中还有更多我们的多模态概念示例。

![0195d6ee-5e8d-7e59-bdaf-525eddd2b72d_8_315_1175_1163_390_0.jpg](images/0195d6ee-5e8d-7e59-bdaf-525eddd2b72d_8_315_1175_1163_390_0.jpg)

Figure 5: Analyzing concepts in different ImageNet classes with Mutual Knowledge

图5:使用共享知识分析不同ImageNet类别的概念

Analyzing Mutual Knowledge across Classes: Next, we show how to make use of our multimodal explanations and MI dynamics to analyze concepts across a set of images pertaining to a class. In Figure 5 we show examples of three classes from ImageNet: sock, siamang and crayfish. Results are averaged across all $B$ images of the class $(B = {50}$ for ImageNet validation set). On the left, we show the MI curves. Note that, although the initial MI value for siamang is higher than that of sock, the AUC for sock (2.10) surpasses that of siamang (1.82). This is attributed to the fact that the curve for siamang starts at a higher point but drops faster at early stages. This shows that considering MI alone without its dynamics, is not representative of the strength of shared information. Next, we aim to delve deeper into this analysis using our multimodal explanations. To accomplish this, we examine the same semantic concept corresponding across all images. In Figure 5 (right), we showcase the semantic concept representing a gibbon body for the "siamang" class (e.g., dark fur with light markings; four-limbed primate), visually identified by the red color. Similarly for the "sock" class, we show the semantic concept of patterns and styles (e.g., various colors, patterns, and styles; plush texture; decorative pattern), visually identified by the blue color. Analyzing the curves and the area under them suggests that general concepts such as patterns and styles are better encoded than discriminative concepts such as the body of a siamang. This rationale stems from the fact that CLIP was trained on a dataset from the internet, which is less discriminatory; it is less common to encounter images of an endangered specie of a gibbon compared to general concepts such as patterns and styles, which are prevalent characteristics across many objects in the world.

跨类别分析共同知识:接下来，我们将展示如何利用多模态解释和互信息(MI)动态来分析属于某一类别的一组图像中的概念。在图5中，我们展示了ImageNet数据集中三个类别的示例:袜子(sock)、合趾猿(siamang)和小龙虾(crayfish)。结果是对ImageNet验证集中类别 $(B = {50}$ 的所有 $B$ 张图像求平均值得到的。在左侧，我们展示了互信息曲线。请注意，尽管合趾猿的初始互信息值高于袜子，但袜子的曲线下面积(AUC，2.10)超过了合趾猿(1.82)。这是因为合趾猿的曲线起点较高，但在早期阶段下降得更快。这表明，仅考虑互信息而不考虑其动态变化，并不能代表共享信息的强度。接下来，我们旨在使用多模态解释更深入地进行这一分析。为此，我们研究了所有图像中对应的相同语义概念。在图5(右侧)中，我们展示了“合趾猿”类别中代表长臂猿身体的语义概念(例如，带有浅色斑纹的深色毛发；四肢灵长类动物)，用红色在视觉上标识出来。同样，对于“袜子”类别，我们展示了图案和样式的语义概念(例如，各种颜色、图案和样式；毛绒质地；装饰图案)，用蓝色在视觉上标识出来。分析曲线及其下方的面积表明，像图案和样式这样的通用概念比像合趾猿身体这样的区分性概念编码得更好。这一原理源于CLIP是在来自互联网的数据集上进行训练的，该数据集的区分性较低；与图案和样式等通用概念(这些是世界上许多物体普遍具有的特征)相比，遇到濒危长臂猿物种图像的情况较少。

Visualizing Mutual Concepts: Finally, we provide visualizations of the mutual concepts detected by both vision and language encoders of CLIP in Figure 6. In the first example, we see that mutual concepts are distinctive to the zero-shot prediction of celo (e.g., handheld musical instrument, strings stretched across the head, a sound hole), suggesting that both encoders effectively represent the image and class in the joint space. In the second example, we see that the language encoder is stronger than the visual encoder at encoding the concept of a rattle snack since it provides related concepts, while the mutual concepts are weaker (only one mutual concept describes a rattle snack). These visualizations help us understand the common concepts learned by both encoders and how the encoders influence each other in the joint space. More examples are in Section I of the Appendix.

可视化共同概念:最后，我们在图6中展示了CLIP的视觉编码器和语言编码器检测到的共同概念的可视化结果。在第一个示例中，我们看到共同概念对于西鲁琴(celo)的零样本预测具有独特性(例如，手持乐器、横跨琴头的琴弦、音孔)，这表明两个编码器在联合空间中有效地表示了图像和类别。在第二个示例中，我们看到语言编码器在编码拨浪鼓零食的概念方面比视觉编码器更强，因为它提供了相关概念，而共同概念较弱(只有一个共同概念描述拨浪鼓零食)。这些可视化结果帮助我们理解两个编码器学习到的共同概念，以及编码器在联合空间中如何相互影响。更多示例见附录的第一部分。

![0195d6ee-5e8d-7e59-bdaf-525eddd2b72d_9_319_673_1152_272_0.jpg](images/0195d6ee-5e8d-7e59-bdaf-525eddd2b72d_9_319_673_1152_272_0.jpg)

Figure 6: Visualizing Vision-Language-Mutual Concepts

图6:可视化视觉 - 语言共同概念

## 5 Conclusion

## 5 结论

We proposed an approach for interpreting CLIP models for image classification from the perspective of mutual knowledge, by analyzing and interpreting the information channel established along with its dynamics. In the future, our work could be extended to non-contrastive models, or even to two parts of the same model. Finally, it is important to note that, like any research, our work has its own set of limitations, which are discussed in Section C of the appendix.

我们提出了一种从共同知识的角度解释用于图像分类的CLIP模型的方法，通过分析和解释所建立的信息通道及其动态变化。未来，我们的工作可以扩展到非对比模型，甚至扩展到同一模型的两个部分。最后，需要注意的是，与任何研究一样，我们的工作也有其自身的局限性，这些局限性在附录的C部分进行了讨论。

## Acknowledgement

## 致谢

Fawaz Sammani is fully and solely funded by the Fonds Wetenschappelijk Onderzoek (FWO) (PhD fellowship strategic basic research 1SH7W24N). N. Deligiannis acknowledges support from the Francqui Foundation (2024-2027 Francqui Research Professorship on Trustworthy AI) and the "Onderzoeksprogramma Artificiele Intelligentie (AI) Vlaanderen" programme.

法瓦兹·萨马尼(Fawaz Sammani)由弗拉芒科学研究基金会(Fonds Wetenschappelijk Onderzoek，FWO)全额资助(博士奖学金战略基础研究项目1SH7W24N)。N. 德利吉安尼斯(N. Deligiannis)感谢弗朗基基金会(Francqui Foundation)的支持(2024 - 2027年弗朗基可信人工智能研究教授职位)以及“弗拉芒人工智能研究计划(Onderzoeksprogramma Artificiele Intelligentie (AI) Vlaanderen)”项目。

References

参考文献

[1] Amir, S., Gandelsman, Y., Bagon, S., Dekel, T.: Deep vit features as dense visual descriptors. European Conference on Computer Vision Workshops (ECCVW 2022) abs/2112.05814 (2022)

[1] 阿米尔(Amir, S.)、甘德尔曼(Gandelsman, Y.)、巴贡(Bagon, S.)、德克尔(Dekel, T.):将深度视觉Transformer特征用作密集视觉描述符。欧洲计算机视觉研讨会(European Conference on Computer Vision Workshops，ECCVW 2022)，abs/2112.05814 (2022)

[2] Bach, S., Binder, A., Montavon, G., Klauschen, F., Müller, K.R., Samek, W.: On pixel-wise explanations for non-linear classifier decisions by layer-wise relevance propagation. PLoS ONE 10 (2015)

[2] 巴赫(Bach, S.)、宾德(Binder, A.)、蒙塔冯(Montavon, G.)、克劳斯琴(Klauschen, F.)、米勒(Müller, K.R.)、萨梅克(Samek, W.):通过逐层相关性传播对非线性分类器决策进行逐像素解释。《公共科学图书馆·综合》(PLoS ONE)10 (2015)

[3] Bau, D., Zhou, B., Khosla, A., Oliva, A., Torralba, A.: Network dissection: Quantifying interpretability of deep visual representations. In: Computer Vision and Pattern Recognition (2017)

[3] 鲍(Bau, D.)、周(Zhou, B.)、科斯拉(Khosla, A.)、奥利瓦(Oliva, A.)、托拉尔巴(Torralba, A.):网络剖析:量化深度视觉表征的可解释性。见:《计算机视觉与模式识别》(Computer Vision and Pattern Recognition)(2017)

[4] Berg, T., Liu, J., Lee, S.W., Alexander, M.L., Jacobs, D.W., Belhumeur, P.N.: Birdsnap: Large-scale fine-grained visual categorization of birds. 2014 IEEE Conference on Computer Vision and Pattern Recognition pp. 2019-2026 (2014)

[4] 伯格(Berg, T.)、刘(Liu, J.)、李(Lee, S.W.)、亚历山大(Alexander, M.L.)、雅各布斯(Jacobs, D.W.)、贝尔休默(Belhumeur, P.N.):鸟类快照(Birdsnap):大规模鸟类细粒度视觉分类。2014年电气与电子工程师协会计算机视觉与模式识别会议，第2019 - 2026页 (2014)

[5] Bossard, L., Guillaumin, M., Van Gool, L.: Food-101 - mining discriminative components with random forests. In: European Conference on Computer Vision (2014)

[5] 博萨尔(Bossard)，L.；吉约曼(Guillaumin)，M.；范古尔(Van Gool)，L.:《Food - 101 - 利用随机森林挖掘判别性组件》。见:欧洲计算机视觉会议(2014 年)

[6] Caron, M., Touvron, H., Misra, I., J'egou, H., Mairal, J., Bojanowski, P., Joulin, A.: Emerging properties in self-supervised vision transformers. 2021 IEEE/CVF International Conference on Computer Vision (ICCV) pp. 9630-9640 (2021)

[6] 卡龙(Caron)，M.；图夫龙(Touvron)，H.；米斯拉(Misra)，I.；埃古(J'egou)，H.；马伊拉尔(Mairal)，J.；博亚诺夫斯基(Bojanowski)，P.；朱林(Joulin)，A.:《自监督视觉变换器中的新兴特性》。2021 年电气与电子工程师协会/计算机视觉基金会国际计算机视觉会议(ICCV)，第 9630 - 9640 页(2021 年)

[7] Chefer, H., Gur, S., Wolf, L.: Transformer interpretability beyond attention visualization. 2021 IEEE/CVF Conference on Computer Vision and Pattern Recognition (CVPR) pp. 782-791 (2020)

[7] 切费尔(Chefer)，H.；古尔(Gur)，S.；沃尔夫(Wolf)，L.:《超越注意力可视化的变换器可解释性》。2021 年电气与电子工程师协会/计算机视觉基金会计算机视觉与模式识别会议(CVPR)，第 782 - 791 页(2020 年)

[8] Cherti, M., Beaumont, R., Wightman, R., Wortsman, M., Ilharco, G., Gordon, C., Schuhmann, C., Schmidt, L., Jitsev, J.: Reproducible scaling laws for contrastive language-image learning. In: Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition. pp. 2818-2829 (2023)

[8] 切尔蒂(Cherti)，M.；博蒙特(Beaumont)，R.；怀特曼(Wightman)，R.；沃茨曼(Wortsman)，M.；伊尔哈科(Ilharco)，G.；戈登(Gordon)，C.；舒曼(Schuhmann)，C.；施密特(Schmidt)，L.；吉特塞夫(Jitsev)，J.:《对比语言 - 图像学习的可重现缩放定律》。见:电气与电子工程师协会/计算机视觉基金会计算机视觉与模式识别会议论文集，第 2818 - 2829 页(2023 年)

[9] Collins, E., Achanta, R., Süsstrunk, S.: Deep feature factorization for concept discovery. European Conference on Computer Vision (ECCV) abs/1806.10206 (2018)

[9] 柯林斯(Collins)，E.；阿昌塔(Achanta)，R.；苏斯特伦克(Süsstrunk)，S.:《用于概念发现的深度特征分解》。欧洲计算机视觉会议(ECCV)，论文编号 abs/1806.10206(2018 年)

[10] Cover, T.M., Thomas, J.A.: Elements of information theory (2005)

[10] 科弗(Cover)，T.M.；托马斯(Thomas)，J.A.:《信息论基础》(2005 年)

[11] Dani, M., Rio-Torto, I., Alaniz, S., Akata, Z.: Devil: Decoding vision features into language. German Conference on Pattern Recognition (GCPR) abs/2309.01617 (2023)

[11] 达尼(Dani)，M.；里奥 - 托尔托(Rio - Torto)，I.；阿拉尼斯(Alaniz)，S.；阿卡塔(Akata)，Z.:《魔鬼(Devil):将视觉特征解码为语言》。德国模式识别会议(GCPR)，论文编号 abs/2309.01617(2023 年)

[12] Dosovitskiy, A., Beyer, L., Kolesnikov, A., Weissenborn, D., Zhai, X., Unterthiner, T., Dehghani, M., Minderer, M., Heigold, G., Gelly, S., Uszkoreit, J., Houlsby, N.: An image is worth 16x16 words: Transformers for image recognition at scale. In: International Conference on Learning Representations (2021), https://openreview.net/forum?id=YicbFdNTTy

[12] 多索维茨基(Dosovitskiy)，A.；拜尔(Beyer)，L.；科列斯尼科夫(Kolesnikov)，A.；魏森博恩(Weissenborn)，D.；翟(Zhai)，X.；翁特希纳(Unterthiner)，T.；德赫加尼(Dehghani)，M.；明德勒(Minderer)，M.；海戈尔德(Heigold)，G.；格利(Gelly)，S.；乌兹科雷特(Uszkoreit)，J.；豪尔斯比(Houlsby)，N.:《一幅图像值 16x16 个单词:大规模图像识别的变换器》。见:国际学习表征会议(2021 年)，https://openreview.net/forum?id=YicbFdNTTy

[13] Ester, M., Kriegel, H.P., Sander, J., Xu, X.: A density-based algorithm for discovering clusters in large spatial databases with noise. In: Knowledge Discovery and Data Mining (1996)

[13] 埃斯特(Ester)，M.；克里格尔(Kriegel)，H.P.；桑德(Sander)，J.；徐(Xu)，X.:《一种基于密度的算法，用于在含噪声的大型空间数据库中发现聚类》。见:知识发现与数据挖掘(1996 年)

[14] Fang, A., Jose, A.M., Jain, A., Schmidt, L., Toshev, A., Shankar, V.: Data filtering networks. Workshop on Distribution Shifts, 37th Conference on Neural Information Processing Systems abs/2309.17425 (2023)

[14] 方(Fang)，A.；何塞(Jose)，A.M.；贾因(Jain)，A.；施密特(Schmidt)，L.；托舍夫(Toshev)，A.；尚卡尔(Shankar)，V.:《数据过滤网络》。第 37 届神经信息处理系统大会分布偏移研讨会，论文编号 abs/2309.17425(2023 年)

[15] Fu, S., Hamilton, M., Brandt, L.E., Feldmann, A., Zhang, Z., Freeman, W.T.: Featup: A model-agnostic framework for features at any resolution. In: The Twelfth International Conference on Learning Representations (2024), https://openreview.net/forum?id=GkJiNn2QDF

[15] 傅(Fu)，S.；汉密尔顿(Hamilton)，M.；布兰特(Brandt)，L.E.；费尔德曼(Feldmann)，A.；张(Zhang)，Z.；弗里曼(Freeman)，W.T.:《Featup:一种适用于任意分辨率特征的与模型无关的框架》。见:第十二届国际学习表征会议(2024 年)，https://openreview.net/forum?id=GkJiNn2QDF

[16] Gadre, S.Y., Ilharco, G., Fang, A., Hayase, J., Smyrnis, G., Nguyen, T., Marten, R., Wortsman, M., Ghosh, D., Zhang, J., Orgad, E., Entezari, R., Daras, G., Pratt, S., Ramanujan, V., Bitton, Y., Marathe, K., Mussmann, S., Vencu, R., Cherti, M., Krishna, R., Koh, P.W., Saukh, O., Ratner, A.J., Song, S., Hajishirzi, H., Farhadi, A., Beaumont, R., Oh, S., Dimakis, A.G., Jitsev, J., Carmon, Y., Shankar, V., Schmidt, L.: Datacomp: In search of the next generation of multimodal datasets. ArXiv abs/2304.14108 (2023)

[16] 加德雷(Gadre)，S.Y.；伊尔哈科(Ilharco)，G.；方(Fang)，A.；早濑(Hayase)，J.；斯米尔尼斯(Smyrnis)，G.；阮(Nguyen)，T.；马滕(Marten)，R.；沃茨曼(Wortsman)，M.；戈什(Ghosh)，D.；张(Zhang)，J.；奥尔加德(Orgad)，E.；恩特扎里(Entezari)，R.；达拉斯(Daras)，G.；普拉特(Pratt)，S.；拉马努金(Ramanujan)，V.；比顿(Bitton)，Y.；马拉特(Marathe)，K.；穆斯曼(Mussmann)，S.；文库(Vencu)，R.；切尔蒂(Cherti)，M.；克里希纳(Krishna)，R.；科赫(Koh)，P.W.；绍赫(Saukh)，O.；拉特纳(Ratner)，A.J.；宋(Song)，S.；哈吉希尔齐(Hajishirzi)，H.；法尔哈迪(Farhadi)，A.；博蒙特(Beaumont)，R.；吴(Oh)，S.；迪马基斯(Dimakis)，A.G.；吉特塞夫(Jitsev)，J.；卡蒙(Carmon)，Y.；尚卡尔(Shankar)，V.；施密特(Schmidt)，L.:《Datacomp:寻找下一代多模态数据集》。预印本 arXiv:2304.14108(2023 年)

[17] Ghiasi, G., Lin, T.Y., Le, Q.V.: Dropblock: A regularization method for convolutional networks. In: Neural Information Processing Systems (2018)

[17] 吉亚西(Ghiasi)，G.；林(Lin)，T.Y.；勒(Le)，Q.V.:《Dropblock:卷积网络的一种正则化方法》。见:神经信息处理系统(2018 年)

[18] Guo, W., Wang, J., Wang, S.: Deep multimodal representation learning: A survey. IEEE Access 7, 63373-63394 (2019)

[18] 郭(Guo)，W.；王(Wang)，J.；王(Wang)，S.:《深度多模态表征学习综述》。《电气与电子工程师协会接入》7 卷，第 63373 - 63394 页(2019 年)

[19] Hernandez, E., Schwettmann, S., Bau, D., Bagashvili, T., Torralba, A., Andreas, J.: Natural language descriptions of deep visual features. International Conference on Learning Representations (ICLR) abs/2201.11114 (2022)

[19] 埃尔南德斯(Hernandez, E.)、施韦特曼(Schwettmann, S.)、鲍(Bau, D.)、巴加什维利(Bagashvili, T.)、托拉尔巴(Torralba, A.)、安德里亚斯(Andreas, J.):深度视觉特征的自然语言描述。国际学习表征会议(International Conference on Learning Representations，ICLR)abs/2201.11114 (2022)

[20] Hessel, J., Holtzman, A., Forbes, M., Bras, R.L., Choi, Y.: CLIPScore: a reference-free evaluation metric for image captioning. In: EMNLP (2021)

[20] 赫塞尔(Hessel, J.)、霍尔茨曼(Holtzman, A.)、福布斯(Forbes, M.)、布拉斯(Bras, R.L.)、崔(Choi, Y.):CLIPScore:一种无参考的图像描述评估指标。见:自然语言处理经验方法会议(EMNLP)(2021)

[21] Hooker, S., Erhan, D., Kindermans, P.J., Kim, B.: A benchmark for interpretability methods in deep neural networks. In: Wallach, H., Larochelle, H., Beygelzimer, A., d'Alché-Buc, F., Fox, E., Garnett, R. (eds.) Advances in Neural Information Processing Systems. vol. 32. Curran Associates, Inc. (2019)

[21] 胡克(Hooker, S.)、埃尔汗(Erhan, D.)、金德曼斯(Kindermans, P.J.)、金(Kim, B.):深度神经网络可解释性方法的基准。见:沃拉赫(Wallach, H.)、拉罗谢尔(Larochelle, H.)、贝格尔齐默(Beygelzimer, A.)、达尔谢 - 布克(d'Alché - Buc, F.)、福克斯(Fox, E.)、加内特(Garnett, R.)(编)《神经信息处理系统进展》。第32卷。柯伦联合公司(Curran Associates, Inc.)(2019)

[22] Ilharco, G., Wortsman, M., Wightman, R., Gordon, C., Carlini, N., Taori, R., Dave, A., Shankar, V., Namkoong, H., Miller, J., Hajishirzi, H., Farhadi, A., Schmidt, L.: Openclip (Jul 2021)

[22] 伊尔哈科(Ilharco, G.)、沃茨曼(Wortsman, M.)、怀特曼(Wightman, R.)、戈登(Gordon, C.)、卡尔尼尼(Carlini, N.)、陶里(Taori, R.)、戴夫(Dave, A.)、尚卡尔(Shankar, V.)、南孔(Namkoong, H.)、米勒(Miller, J.)、哈吉希尔齐(Hajishirzi, H.)、法尔哈迪(Farhadi, A.)、施密特(Schmidt, L.):Openclip(2021年7月)

[23] Jang, E., Gu, S., Poole, B.: Categorical reparameterization with gumbel-softmax. In: International Conference on Learning Representations (2017)

[23] 张(Jang, E.)、顾(Gu, S.)、普尔(Poole, B.):使用Gumbel - 软最大化进行类别重参数化。见:国际学习表征会议(International Conference on Learning Representations)(2017)

[24] Kayser, M., Camburu, O.M., Salewski, L., Emde, C., Do, V., Akata, Z., Lukasiewicz, T.: e-vil: A dataset and benchmark for natural language explanations in vision-language tasks. ArXiv abs/2105.03761 (2021)

[24] 凯泽(Kayser, M.)、坎布卢(Camburu, O.M.)、萨勒夫斯基(Salewski, L.)、埃姆德(Emde, C.)、多(Do, V.)、阿卡塔(Akata, Z.)、卢卡西维茨(Lukasiewicz, T.):e - vil:用于视觉 - 语言任务中自然语言解释的数据集和基准。预印本库(ArXiv)abs/2105.03761 (2021)

[25] Kingma, D.P., Ba, J.: Adam: A method for stochastic optimization. CoRR abs/1412.6980 (2014)

[25] 金马(Kingma, D.P.)、巴(Ba, J.):Adam:一种随机优化方法。计算机研究存储库(CoRR)abs/1412.6980 (2014)

[26] Kirillov, A., Mintun, E., Ravi, N., Mao, H., Rolland, C., Gustafson, L., Xiao, T., Whitehead, S., Berg, A.C., Lo, W.Y., Dollár, P., Girshick, R.B.: Segment anything. 2023 IEEE/CVF International Conference on Computer Vision (ICCV) pp. 3992-4003 (2023)

[26] 基里洛夫(Kirillov, A.)、明顿(Mintun, E.)、拉维(Ravi, N.)、毛(Mao, H.)、罗兰(Rolland, C.)、古斯塔夫森(Gustafson, L.)、肖(Xiao, T.)、怀特黑德(Whitehead, S.)、伯格(Berg, A.C.)、罗(Lo, W.Y.)、多尔(Dollár, P.)、吉尔希克(Girshick, R.B.):任意分割。2023年电气与电子工程师协会/计算机视觉基金会国际计算机视觉会议(2023 IEEE/CVF International Conference on Computer Vision，ICCV)，第3992 - 4003页 (2023)

[27] Koh, P.W., Nguyen, T., Tang, Y.S., Mussmann, S., Pierson, E., Kim, B., Liang, P.: Concept bottleneck models. In: III, H.D., Singh, A. (eds.) Proceedings of the 37th International Conference on Machine Learning. Proceedings of Machine Learning Research, vol. 119, pp. 5338-5348. PMLR (13-18 Jul 2020)

[27]  Koh, P.W.、阮(Nguyen, T.)、唐(Tang, Y.S.)、穆斯曼(Mussmann, S.)、皮尔森(Pierson, E.)、金(Kim, B.)、梁(Liang, P.):概念瓶颈模型。见:III, H.D.、辛格(Singh, A.)(编)《第37届国际机器学习会议论文集》。机器学习研究会议录，第119卷，第5338 - 5348页。机器学习研究会议录(Proceedings of Machine Learning Research，PMLR)(2020年7月13 - 18日)

[28] Krähenbühl, P., Koltun, V.: Efficient inference in fully connected crfs with gaussian edge potentials. Neural Information Processing Systems abs/1210.5644 (2011)

[29] 克雷恩布尔(Krähenbühl, P.)、科尔图恩(Koltun, V.):具有高斯边缘势的全连接条件随机场的高效推理。神经信息处理系统abs/1210.5644 (2011)

[29] Krähenbühl, P., Koltun, V.: Efficient inference in fully connected crfs with gaussian edge potentials. In: Shawe-Taylor, J., Zemel, R., Bartlett, P., Pereira, F., Weinberger, K. (eds.) Advances in Neural Information Processing Systems. vol. 24. Curran Associates, Inc. (2011)

[29] 克雷恩布尔(Krähenbühl, P.)、科尔图恩(Koltun, V.):具有高斯边缘势的全连接条件随机场的高效推理。见:肖韦 - 泰勒(Shawe - Taylor, J.)、泽梅尔(Zemel, R.)、巴特利特(Bartlett, P.)、佩雷拉(Pereira, F.)、温伯格(Weinberger, K.)(编)《神经信息处理系统进展》。第24卷。柯伦联合公司(Curran Associates, Inc.)(2011)

[30] Krizhevsky, A., Sutskever, I., Hinton, G.E.: Imagenet classification with deep convolutional neural networks. Communications of the ACM 60,84-90 (2012)

[30] 克里兹维茨基(Krizhevsky, A.)、苏斯克韦弗(Sutskever, I.)、辛顿(Hinton, G.E.):使用深度卷积神经网络进行ImageNet分类。《美国计算机协会通讯》(Communications of the ACM)60, 84 - 90 (2012)

[31] Li, W., Zhu, L., Wen, L., Yang, Y.: Decap: Decoding clip latents for zero-shot captioning via text-only training. In: The Eleventh International Conference on Learning Representations

[31] 李(Li, W.)、朱(Zhu, L.)、文(Wen, L.)、杨(Yang, Y.):Decap:通过仅文本训练解码CLIP潜在变量以实现零样本描述。见:第十一届国际学习表征会议

[32] Liang, W., Zhang, Y., Kwon, Y., Yeung, S., Zou, J.: Mind the gap: Understanding the modality gap in multi-modal contrastive representation learning. In: NeurIPS (2022)

[32] 梁(Liang, W.)、张(Zhang, Y.)、权(Kwon, Y.)、杨(Yeung, S.)、邹(Zou, J.):关注差距:理解多模态对比表征学习中的模态差距。见:神经信息处理系统大会(NeurIPS)(2022)

[33] Liu, Z., Mao, H., Wu, C., Feichtenhofer, C., Darrell, T., Xie, S.: A convnet for the 2020s. 2022 IEEE/CVF Conference on Computer Vision and Pattern Recognition (CVPR) pp. 11966-11976 (2022)

[33] 刘(Liu, Z.)、毛(Mao, H.)、吴(Wu, C.)、费希滕霍费尔(Feichtenhofer, C.)、达雷尔(Darrell, T.)、谢(Xie, S.):面向2020年代的卷积网络。2022年电气与电子工程师协会/计算机视觉基金会计算机视觉与模式识别会议(2022 IEEE/CVF Conference on Computer Vision and Pattern Recognition，CVPR)，第11966 - 11976页 (2022)

[34] Loshchilov, I., Hutter, F.: Sgdr: Stochastic gradient descent with warm restarts. arXiv: Learning (2016)

[34] 洛希奇洛夫(Loshchilov, I.)、胡特(Hutter, F.):SGDR:带热重启的随机梯度下降。预印本库(arXiv):学习 (2016)

[35] Melas-Kyriazi, L., Rupprecht, C., Laina, I., Vedaldi, A.: Deep spectral methods: A surprisingly strong baseline for unsupervised semantic segmentation and localization. 2022 IEEE/CVF Conference on Computer Vision and Pattern Recognition (CVPR) pp. 8354-8365 (2022)

[35] 梅拉斯 - 基里亚齐(Melas-Kyriazi)，L.；鲁普雷希特(Rupprecht)，C.；莱娜(Laina)，I.；韦尔达利(Vedaldi)，A.:深度谱方法:无监督语义分割和定位的惊人强大基线。2022年电气与电子工程师协会/计算机视觉基金会计算机视觉与模式识别会议(CVPR)，第8354 - 8365页(2022年)

[36] Menon, S., Vondrick, C.: Visual classification via description from large language models. International Conference on Learning Representations abs/2210.07183 (2023)

[36] 梅农(Menon)，S.；冯德里克(Vondrick)，C.:通过大语言模型的描述进行视觉分类。国际学习表征会议，论文编号abs/2210.07183(2023年)

[37] Müllner, D.: Modern hierarchical, agglomerative clustering algorithms. ArXiv abs/1109.2378 (2011)

[37] 米尔纳(Müllner)，D.:现代层次聚合聚类算法。预印本库论文编号abs/1109.2378(2011年)

[38] van Noord, N.: Prototype-based dataset comparison. 2023 IEEE/CVF International Conference on Computer Vision (ICCV) pp. 1944-1954 (2023)

[38] 范·诺德(van Noord)，N.:基于原型的数据集比较。2023年电气与电子工程师协会/计算机视觉基金会国际计算机视觉会议(ICCV)，第1944 - 1954页(2023年)

[39] Oikarinen, T., Das, S., Nguyen, L.M., Weng, T.W.: Label-free concept bottleneck models. In: International Conference on Learning Representations (2023)

[39] 奥卡里宁(Oikarinen)，T.；达斯(Das)，S.；阮(Nguyen)，L.M.；翁(Weng)，T.W.:无标签概念瓶颈模型。见:国际学习表征会议(2023年)

[40] Oquab, M., Darcet, T., Moutakanni, T., Vo, H.V., Szafraniec, M., Khalidov, V., Fernandez, P., HAZIZA, D., Massa, F., El-Nouby, A., Assran, M., Ballas, N., Galuba, W., Howes, R., Huang, P.Y., Li, S.W., Misra, I., Rabbat, M., Sharma, V., Synnaeve, G., Xu, H., Jegou, H., Mairal, J., Labatut, P., Joulin, A., Bojanowski, P.: DINOv2: Learning robust visual features without supervision. Transactions on Machine Learning Research (TMLR) (2024)

[40] 奥夸布(Oquab)，M.；达塞(Darcet)，T.；穆塔卡尼(Moutakanni)，T.；沃(Vo)，H.V.；萨夫拉涅茨(Szafraniec)，M.；哈利多夫(Khalidov)，V.；费尔南德斯(Fernandez)，P.；哈齐扎(HAZIZA)，D.；马萨(Massa)，F.；埃尔 - 努比(El - Nouby)，A.；阿斯兰(Assran)，M.；巴拉斯(Ballas)，N.；加卢巴(Galuba)，W.；豪斯(Howes)，R.；黄(Huang)，P.Y.；李(Li)，S.W.；米斯拉(Misra)，I.；拉巴特(Rabbat)，M.；夏尔马(Sharma)，V.；西纳埃夫(Synnaeve)，G.；徐(Xu)，H.；热古(Jegou)，H.；马伊拉尔(Mairal)，J.；拉巴图(Labatut)，P.；茹林(Joulin)，A.；博亚诺夫斯基(Bojanowski)，P.:DINOv2:无监督学习鲁棒视觉特征。机器学习研究汇刊(TMLR)(2024年)

[41] Park, D.H., Hendricks, L.A., Akata, Z., Rohrbach, A., Schiele, B., Darrell, T., Rohrbach, M.: Multimodal explanations: Justifying decisions and pointing to the evidence. 2018 IEEE/CVF Conference on Computer Vision and Pattern Recognition pp. 8779-8788 (2018)

[41] 朴(Park)，D.H.；亨德里克斯(Hendricks)，L.A.；阿卡塔(Akata)，Z.；罗尔巴赫(Rohrbach)，A.；席勒(Schiele)，B.；达雷尔(Darrell)，T.；罗尔巴赫(Rohrbach)，M.:多模态解释:为决策提供依据并指出证据。2018年电气与电子工程师协会/计算机视觉基金会计算机视觉与模式识别会议，第8779 - 8788页(2018年)

[42] Petsiuk, V., Das, A., Saenko, K.: Rise: Randomized input sampling for explanation of black-box models. In: British Machine Vision Conference (BMVC) (2018)

[42] 佩丘克(Petsiuk)，V.；达斯(Das)，A.；萨内科(Saenko)，K.:RISE:用于解释黑盒模型的随机输入采样。见:英国机器视觉会议(BMVC)(2018年)

[43] Pratt, S., Liu, R., Farhadi, A.: What does a platypus look like? generating customized prompts for zero-shot image classification. International Conference on Computer Vision (ICCV) abs/2209.03320 (2023)

[43] 普拉特(Pratt)，S.；刘(Liu)，R.；法尔哈迪(Farhadi)，A.:鸭嘴兽长什么样？为零样本图像分类生成定制提示。国际计算机视觉会议，论文编号abs/2209.03320(2023年)

[44] Radford, A., Kim, J.W., Hallacy, C., Ramesh, A., Goh, G., Agarwal, S., Sastry, G., Askell, A., Mishkin, P., Clark, J., Krueger, G., Sutskever, I.: Learning transferable visual models from natural language supervision. In: ICML (2021)

[44] 拉德福德(Radford)，A.；金(Kim)，J.W.；哈拉西(Hallacy)，C.；拉梅什(Ramesh)，A.；戈(Goh)，G.；阿加瓦尔(Agarwal)，S.；萨斯特里(Sastry)，G.；阿斯凯尔(Askell)，A.；米什金(Mishkin)，P.；克拉克(Clark)，J.；克鲁格(Krueger)，G.；苏茨克维(Sutskever)，I.:从自然语言监督中学习可迁移视觉模型。见:国际机器学习会议(2021年)

[45] Ribeiro, M.T., Singh, S., Guestrin, C.: "why should i trust you?": Explaining the predictions of any classifier. Proceedings of the 22nd ACM SIGKDD International Conference on Knowledge Discovery and Data Mining (2016)

[45] 里贝罗(Ribeiro)，M.T.；辛格(Singh)，S.；格斯特林(Guestrin)，C.:“我为什么要相信你？”:解释任何分类器的预测。第22届美国计算机协会知识发现与数据挖掘国际会议论文集(2016年)

[46] Rong, Y., Leemann, T., Borisov, V., Kasneci, G., Kasneci, E.: A consistent and efficient evaluation strategy for attribution methods. In: Proceedings of the 39th International Conference on Machine Learning. pp. 18770-18795. PMLR (2022)

[46] 荣(Rong)，Y.；利曼(Leemann)，T.；鲍里索夫(Borisov)，V.；卡斯内奇(Kasneci)，G.；卡斯内奇(Kasneci)，E.:归因方法的一致且高效的评估策略。见:第39届国际机器学习会议论文集，第18770 - 18795页。机器学习研究会议录(PMLR)(2022年)

[47] Sammani, F., Deligiannis, N.: Uni-nlx: Unifying textual explanations for vision and vision-language tasks. 2023 IEEE/CVF International Conference on Computer Vision Workshops (ICCVW) pp. 4636-4641 (2023)

[47] 萨曼尼(Sammani)，F.；德利吉安尼斯(Deligiannis)，N.:Uni - nlx:统一视觉和视觉 - 语言任务的文本解释。2023年电气与电子工程师协会/计算机视觉基金会国际计算机视觉研讨会(ICCVW)，第4636 - 4641页(2023年)

[48] Sammani, F., Mukherjee, T., Deligiannis, N.: Nlx-gpt: A model for natural language explanations in vision and vision-language tasks. 2022 IEEE/CVF Conference on Computer Vision and Pattern Recognition (CVPR) pp. 8312-8322 (2022)

[48] 萨曼尼(Sammani)，F.；穆克吉(Mukherjee)，T.；德利吉安尼斯(Deligiannis)，N.:Nlx - gpt:用于视觉和视觉 - 语言任务的自然语言解释模型。2022年电气与电子工程师协会/计算机视觉基金会计算机视觉与模式识别会议(CVPR)，第8312 - 8322页(2022年)

[49] Schuhmann, C., Beaumont, R., Vencu, R., Gordon, C., Wightman, R., Cherti, M., Coombes, T., Katta, A., Mullis, C., Wortsman, M., Schramowski, P., Kundurthy, S., Crowson, K., Schmidt, L., Kaczmarczyk, R., Jitsev, J.: Laion-5b: An open large-scale dataset for training next generation image-text models. ArXiv abs/2210.08402 (2022)

[49] 舒曼(Schuhmann, C.)、博蒙特(Beaumont, R.)、文库(Vencu, R.)、戈登(Gordon, C.)、怀特曼(Wightman, R.)、切尔蒂(Cherti, M.)、库姆斯(Coombes, T.)、卡塔(Katta, A.)、穆利斯(Mullis, C.)、沃茨曼(Wortsman, M.)、施拉莫夫斯基(Schramowski, P.)、昆杜尔西(Kundurthy, S.)、克劳森(Crowson, K.)、施密特(Schmidt, L.)、卡奇马尔奇克(Kaczmarczyk, R.)、吉特塞夫(Jitsev, J.):Laion - 5b:用于训练下一代图像 - 文本模型的开放大规模数据集。《arXiv预印本》abs/2210.08402 (2022)

[50] Schuhmann, C., Vencu, R., Beaumont, R., Kaczmarczyk, R., Mullis, C., Katta, A., Coombes, T., Jitsev, J., Komatsuzaki, A.: Laion-400m: Open dataset of clip-filtered 400 million image-text pairs. NeurIPS Data-Centric AI Workshop abs/2111.02114 (2021)

[50] 舒曼(Schuhmann, C.)、文库(Vencu, R.)、博蒙特(Beaumont, R.)、卡奇马尔奇克(Kaczmarczyk, R.)、穆利斯(Mullis, C.)、卡塔(Katta, A.)、库姆斯(Coombes, T.)、吉特塞夫(Jitsev, J.)、小松崎(Komatsuzaki, A.):Laion - 400m:经过CLIP过滤的4亿个图像 - 文本对的开放数据集。《神经信息处理系统大会以数据为中心的人工智能研讨会》abs/2111.02114 (2021)

[51] Selvaraju, R.R., Das, A., Vedantam, R., Cogswell, M., Parikh, D., Batra, D.: Grad-cam: Visual explanations from deep networks via gradient-based localization. International Journal of Computer Vision 128, 336-359 (2019)

[51] 塞尔瓦拉朱(Selvaraju, R.R.)、达斯(Das, A.)、维丹塔姆(Vedantam, R.)、科格斯韦尔(Cogswell, M.)、帕里克(Parikh, D.)、巴特拉(Batra, D.):Grad - CAM:通过基于梯度的定位实现深度网络的可视化解释。《国际计算机视觉杂志》128, 336 - 359 (2019)

[52] Sharma, P., Ding, N., Goodman, S., Soricut, R.: Conceptual captions: A cleaned, hypernymmed, image alt-text dataset for automatic image captioning. In: Proceedings of ACL (2018)

[52] 夏尔马(Sharma, P.)、丁(Ding, N.)、古德曼(Goodman, S.)、索里库特(Soricut, R.):概念性字幕:用于自动图像字幕的经过清理、具有上位词的图像替代文本数据集。见:《计算语言学协会会议论文集》(2018)

[53] Shin, J.W., Kim, S.J.: A mathematical theory of communication (2006)

[53] 申(Shin, J.W.)、金(Kim, S.J.):通信的数学理论 (2006)

[54] Shtedritski, A., Rupprecht, C., Vedaldi, A.: What does clip know about a red circle? visual prompt engineering for vlms. 2023 IEEE/CVF International Conference on Computer Vision (ICCV) pp. 11953-11963 (2023)

[54] 什捷德里茨基(Shtedritski, A.)、鲁普雷希特(Rupprecht, C.)、韦尔迪耶(Vedaldi, A.):CLIP对红色圆圈了解多少？视觉语言模型的视觉提示工程。《2023年电气与电子工程师协会/计算机视觉基金会国际计算机视觉会议》第11953 - 11963页 (2023)

[55] Siméoni, O., Puy, G., Vo, H.V., Roburin, S., Gidaris, S., Bursuc, A., P’erez, P., Marlet, R., Ponce, J.: Localizing objects with self-supervised transformers and no labels. British Machine Vision Conference (BMVC) abs/2109.14279 (2021)

[55] 西梅奥尼(Siméoni, O.)、皮伊(Puy, G.)、沃(Vo, H.V.)、罗布林(Roburin, S.)、吉达里斯(Gidaris, S.)、布尔苏克(Bursuc, A.)、佩雷斯(P’erez, P.)、马莱(Marlet, R.)、庞斯(Ponce, J.):使用自监督变压器进行无标签目标定位。《英国机器视觉会议》abs/2109.14279 (2021)

[56] Sinkhorn, R., Knopp, P.: Concerning nonnegative matrices and doubly stochastic matrices. Pacific Journal of Mathematics 21, 343-348 (1967)

[56] 辛克霍恩(Sinkhorn, R.)、克诺普(Knopp, P.):关于非负矩阵和双随机矩阵。《太平洋数学杂志》21, 343 - 348 (1967)

[57] Song, H., Dong, L., Zhang, W., Liu, T., Wei, F.: Clip models are few-shot learners: Empirical studies on vqa and visual entailment. In: Annual Meeting of the Association for Computational Linguistics (2022)

[57] 宋(Song, H.)、董(Dong, L.)、张(Zhang, W.)、刘(Liu, T.)、魏(Wei, F.):CLIP模型是少样本学习者:关于视觉问答和视觉蕴含的实证研究。见:《计算语言学协会年会》(2022)

[58] Srivastava, N., Hinton, G.E., Krizhevsky, A., Sutskever, I., Salakhutdinov, R.: Dropout: a simple way to prevent neural networks from overfitting. J. Mach. Learn. Res. 15, 1929-1958 (2014)

[58] 斯里瓦斯塔瓦(Srivastava, N.)、辛顿(Hinton, G.E.)、克里兹维斯基(Krizhevsky, A.)、苏茨克维(Sutskever, I.)、萨拉胡丁诺夫(Salakhutdinov, R.):Dropout:防止神经网络过拟合的简单方法。《机器学习研究杂志》15, 1929 - 1958 (2014)

[59] Subramanian, S., Merrill, W., Darrell, T., Gardner, M., Singh, S., Rohrbach, A.: Reclip: A strong zero-shot baseline for referring expression comprehension. In: Annual Meeting of the Association for Computational Linguistics (2022)

[59] 苏布拉马尼亚姆(Subramanian, S.)、梅里尔(Merrill, W.)、达雷尔(Darrell, T.)、加德纳(Gardner, M.)、辛格(Singh, S.)、罗尔巴赫(Rohrbach, A.):ReCLIP:用于指代表达理解的强大零样本基线。见:《计算语言学协会年会》(2022)

[60] Sundararajan, M., Taly, A., Yan, Q.: Axiomatic attribution for deep networks. ArXiv abs/1703.01365 (2017)

[60] 桑达拉扬(Sundararajan, M.)、塔利(Taly, A.)、严(Yan, Q.):深度网络的公理归因。《arXiv预印本》abs/1703.01365 (2017)

[61] Tewel, Y., Shalev, Y., Schwartz, I., Wolf, L.: Zerocap: Zero-shot image-to-text generation for visual-semantic arithmetic. 2022 IEEE/CVF Conference on Computer Vision and Pattern Recognition (CVPR) pp. 17897-17907 (2021)

[61] 特韦尔(Tewel, Y.)、沙莱夫(Shalev, Y.)、施瓦茨(Schwartz, I.)、沃尔夫(Wolf, L.):Zerocap:用于视觉语义算术的零样本图像到文本生成。《2022年电气与电子工程师协会/计算机视觉基金会计算机视觉与模式识别会议》第17897 - 17907页 (2021)

[62] Wah, C., Branson, S., Welinder, P., Perona, P., Belongie, S.: The Caltech-UCSD Birds-200-2011 Dataset (Jul 2011)

[62] 瓦(Wah, C.)、布兰森(Branson, S.)、韦林德(Welinder, P.)、佩罗纳(Perona, P.)、贝隆吉(Belongie, S.):加州理工学院 - 加州大学圣地亚哥分校鸟类200 - 2011数据集(2011年7月)

[63] Yang, L., Wang, Y., Li, X., Wang, X., Yang, J.: Fine-grained visual prompting. Neural Information Processing Systems abs/2306.04356 (2023)

[63] 杨(Yang, L.)、王(Wang, Y.)、李(Li, X.)、王(Wang, X.)、杨(Yang, J.):细粒度视觉提示。《神经信息处理系统》abs/2306.04356 (2023)

[64] Yun, T., Bhalla, U., Pavlick, E., Sun, C.: Do vision-language pretrained models learn composable primitive concepts? Transactions on Machine Learning Research (TMLR) 2023 (2022)

[64] 云(Yun, T.)、巴拉(Bhalla, U.)、帕夫利克(Pavlick, E.)、孙(Sun, C.):视觉 - 语言预训练模型是否学习了可组合的基本概念？《机器学习研究汇刊》(TMLR) 2023 (2022)

[65] Zhou, B., Lapedriza, A., Khosla, A., Oliva, A., Torralba, A.: Places: A 10 million image database for scene recognition. IEEE Transactions on Pattern Analysis and Machine Intelligence (2017)

[65] 周(Zhou)、B.、拉佩德里扎(Lapedriza)、A.、科斯拉(Khosla)、A.、奥利瓦(Oliva)、A.、托拉尔巴(Torralba)、A.:Places:用于场景识别的千万级图像数据库。《电气与电子工程师协会模式分析与机器智能汇刊》(2017年)

[66] Zhou, K., Yang, J., Loy, C.C., Liu, Z.: Learning to prompt for vision-language models. International Journal of Computer Vision 130, 2337 - 2348 (2021)

[66] 周(Zhou)、K.、杨(Yang)、J.、洛伊(Loy)、C.C.、刘(Liu)、Z.:学习为视觉 - 语言模型设置提示。《国际计算机视觉杂志》130卷，2337 - 2348页(2021年)

## Appendix

## 附录

## A Ablation Studies

## A 消融研究

### A.1 Feature Facets

### A.1 特征方面

We consider three types of vision features $f$ : the tokens and keys of the last attention layer of the transformer, as well as an ensemble of them. In Figure 1, we show the similarity of the [CLS] token across all layers for both the tokens and key features of a ViT-B/16. As shown, the token features of the last layer are dissimilar to all previous layers, while the similarity of the key features is consistent across all layers. This is rational since token features (a function of the key features) have to adapt their feature space to align with language features. However, by running object localization experiments on the full ImageNet validation split, we find that this phenomenon is only present in large models. In Table 1 we report the CorLoc metric where we fit a bounding box around the most prominent region and calculate the percentage of samples with an IoU larger than 0.5 between that box and the ground-truth bounding box. In general, key features are more stable. By further examining the results, we note that PCA performs significantly worse than Graph Decomposition (GDC) of the feature affinity matrix, suggesting the presence of complex features that cannot be captured through linear combinations of dimensions, requiring graph-based approaches to model higher-order relationships. Therefore, we adopt eigenvector decomposition of the graph affinity matrix as the primary method for extracting prominent patches.

我们考虑三种类型的视觉特征 $f$:Transformer最后一个注意力层的标记(tokens)和键(keys)，以及它们的组合。在图1中，我们展示了ViT - B/16的标记和键特征在所有层上[CLS]标记的相似性。如图所示，最后一层的标记特征与之前所有层都不相似，而键特征在所有层上的相似性是一致的。这是合理的，因为标记特征(键特征的函数)必须调整其特征空间以与语言特征对齐。然而，通过在完整的ImageNet验证集上进行目标定位实验，我们发现这种现象只出现在大型模型中。在表1中，我们报告了CorLoc指标，即我们在最显著区域周围拟合一个边界框，并计算该框与真实边界框的交并比(IoU)大于0.5的样本百分比。一般来说，键特征更稳定。通过进一步检查结果，我们注意到主成分分析(PCA)的表现明显不如特征亲和矩阵的图分解(GDC)，这表明存在无法通过维度的线性组合捕获的复杂特征，需要基于图的方法来建模高阶关系。因此，我们采用图亲和矩阵的特征向量分解作为提取显著斑块的主要方法。

![0195d6ee-5e8d-7e59-bdaf-525eddd2b72d_14_308_1046_597_281_0.jpg](images/0195d6ee-5e8d-7e59-bdaf-525eddd2b72d_14_308_1046_597_281_0.jpg)

Figure 1: CLIP layer similarity analysis for the token features (a) and key features (b).

图1:标记特征(a)和键特征(b)的CLIP层相似性分析。

Table 1: Ablation studies on CorLoc for different feature facets and decomposition methods. GDC: Graph Decomposition.

表1:不同特征方面和分解方法的CorLoc消融研究。GDC:图分解。

<table><tr><td/><td>ViT-B/16</td><td>ViT-L/14↑</td></tr><tr><td>Keys (GDC)</td><td>54.0</td><td>46.9</td></tr><tr><td>Keys (PCA)</td><td>46.9</td><td>39.3</td></tr><tr><td>Tokens (GDC)</td><td>55.8</td><td>30.7</td></tr><tr><td>Tokens (PCA)</td><td>1.0</td><td>30.0</td></tr><tr><td>Ensemble (GDC)</td><td>54.7</td><td>-</td></tr><tr><td>Ensemble (PCA)</td><td>15.2</td><td>-</td></tr></table>

<table><tbody><tr><td></td><td>视觉Transformer基础模型/16(ViT-B/16)</td><td>视觉Transformer大模型/14↑(ViT-L/14↑)</td></tr><tr><td>键(全局维度聚类，GDC)</td><td>54.0</td><td>46.9</td></tr><tr><td>键(主成分分析，PCA)</td><td>46.9</td><td>39.3</td></tr><tr><td>标记(全局维度聚类，GDC)</td><td>55.8</td><td>30.7</td></tr><tr><td>标记(主成分分析，PCA)</td><td>1.0</td><td>30.0</td></tr><tr><td>集成模型(全局维度聚类，GDC)</td><td>54.7</td><td>-</td></tr><tr><td>集成模型(主成分分析，PCA)</td><td>15.2</td><td>-</td></tr></tbody></table>

### A.2 Optimal Transport

### A.2 最优传输(Optimal Transport)

We test the effectiveness of OT on our multimodal explanations. Let ${T}^{l}$ represent the detected textual concepts in an image $I$ for a visual concept $l$ , where $1 \leq  l \leq  L$ such that $T = \left\{  {{T}^{1},{T}^{2},\ldots ,{T}^{L}}\right\}$ . Since visual concepts describe unique semantic regions (i.e., parts of objects), the textual descriptors associated with each visual concept should also be unique. To evaluate this, we define the Entropy metric which measures the diversity of $T$ across all $L$ visual concepts. This metric penalizes textual concepts that appear repeatedly across two or more visual concepts. A higher value indicates greater diversity. We present the findings in Table 2. The baseline case maps textual descriptors corresponding to the visual concepts without any post-processing steps. As shown, this leads to a low entropy and non-diverse results where some visual concepts are mapped to the same textual descriptor. Figure 2 shows this effect qualitatively. Using OT alleviates this issue and considerably increases the entropy.

我们测试了最优传输(OT)在多模态解释中的有效性。设${T}^{l}$表示图像$I$中针对视觉概念$l$检测到的文本概念，其中$1 \leq  l \leq  L$满足$T = \left\{  {{T}^{1},{T}^{2},\ldots ,{T}^{L}}\right\}$。由于视觉概念描述的是独特的语义区域(即物体的部分)，因此与每个视觉概念相关联的文本描述符也应该是独特的。为了评估这一点，我们定义了熵指标，该指标用于衡量所有$L$个视觉概念中$T$的多样性。该指标会对在两个或更多视觉概念中反复出现的文本概念进行惩罚。值越高表示多样性越大。我们在表2中展示了研究结果。基线情况是在没有任何后处理步骤的情况下，将与视觉概念对应的文本描述符进行映射。如图所示，这会导致熵值较低且结果缺乏多样性，即一些视觉概念被映射到相同的文本描述符。图2定性地展示了这种效果。使用最优传输(OT)可以缓解这个问题，并显著提高熵值。

Table 2: Entropy scores for ablating Optimal Transport.

表2:去除最优传输(Optimal Transport)后的熵得分。

<table><tr><td/><td>PCA</td><td>K-means</td></tr><tr><td>w/o Optimal Transport</td><td>1.70</td><td>1.70</td></tr><tr><td>w/ Optimal Transport</td><td>2.33</td><td>2.34</td></tr></table>

<table><tbody><tr><td></td><td>主成分分析(PCA)</td><td>K均值聚类(K-means)</td></tr><tr><td>无最优传输(w/o Optimal Transport)</td><td>1.70</td><td>1.70</td></tr><tr><td>有最优传输(w/ Optimal Transport)</td><td>2.33</td><td>2.34</td></tr></tbody></table>

![0195d6ee-5e8d-7e59-bdaf-525eddd2b72d_15_609_206_575_517_0.jpg](images/0195d6ee-5e8d-7e59-bdaf-525eddd2b72d_15_609_206_575_517_0.jpg)

Figure 2: Optimal Transport (OT) diversifies textual concepts across their visual counterparts

图2:最优传输(OT)使文本概念在其视觉对应物之间多样化

### A.3 Eigendecomposition and CRF effect

### A.3 特征分解与条件随机场(CRF)效应

To match the dimensions of the importance map with those of the image, we need to perform interpolation. However, interpolation usually results in pixel overshooting effects. As an alternative interpolation technique, we use Conditional Random Fields (CRF) [28] to interpolate the patch-based importance map to a finer-grained pixel-based map. Prior to this, we remove noisy scattered patches by extracting the largest fully-connected component (FCC) of the importance map, which represents the largest primary connected region. A recent work [15] shows that this approach enhances explainability. It is important to note that both the FCC and CRF preserve the original importance map's integrity and do not compromise its faithfulness. This is quantitatively demonstrated in Table 3 for several ViT and ResNet CLIP models. We first evaluate the effect of interpolating the binary importance map produced by eigendecomposition using nearest neighbor interpolation. To perform this evaluation, we blur the non-prominent regions of the image (those with a negative sign in ${e}_{f}$ ) using an ${11} \times  {11}$ Gaussian kernel, effectively removing the details from these areas. We opt to blur those areas rather than zeroing them out in order to avoid the Out-Of-Distribution (OOD) problem reported in [21, 46]. We then reassess the zero-shot accuracy. As shown, using only the most prominenet features identified by eigendecomposition does not drastically reduce the zero-shot accuracy, with a loss of only $3\%$ on average. This validates that the features obtained by eigendecomposition are indeed the most important and are the ones that mainly (largely) contribute to the model's performance. Next, we show the effect on zero-shot accuracy when taking the FCC, followed by CRF. As shown, this results in very marginal effects on accuracy compared to Nearest Neighbor interpolation, indicating that these components does not alter the underlying importance map. Note that the marginal effect can be either positive, where the FCC enhances zero-shot accuracy, or negative, where excluding regions other than the fully-connected component reduces accuracy. In both scenarios, the effect is very minimal and can be considered negligible. Therefore, we decided to use these two components to achieve better visualizations.

为了使重要性图的维度与图像的维度相匹配，我们需要进行插值。然而，插值通常会导致像素过冲效应。作为一种替代的插值技术，我们使用条件随机场(CRF)[28]将基于块的重要性图插值为更细粒度的基于像素的图。在此之前，我们通过提取重要性图的最大全连通分量(FCC)来去除嘈杂的分散块，该分量代表最大的主要连通区域。最近的一项工作[15]表明，这种方法提高了解释性。需要注意的是，FCC和CRF都保留了原始重要性图的完整性，并且不会损害其忠实性。表3针对几个视觉Transformer(ViT)和残差网络(ResNet)的对比语言-图像预训练(CLIP)模型对此进行了定量展示。我们首先评估使用最近邻插值对特征分解产生的二值重要性图进行插值的效果。为了进行此评估，我们使用${11} \times  {11}$高斯核模糊图像的非显著区域(即${e}_{f}$中符号为负的区域)，有效地去除这些区域的细节。我们选择模糊这些区域而不是将其置零，以避免文献[21, 46]中报道的分布外(OOD)问题。然后我们重新评估零样本准确率。如图所示，仅使用特征分解识别出的最显著特征不会大幅降低零样本准确率，平均仅损失$3\%$。这验证了通过特征分解获得的特征确实是最重要的，并且是主要(在很大程度上)对模型性能做出贡献的特征。接下来，我们展示提取FCC后再进行CRF处理对零样本准确率的影响。如图所示，与最近邻插值相比，这对准确率的影响非常小，表明这些组件不会改变底层的重要性图。请注意，这种微小的影响可能是正向的，即FCC提高了零样本准确率；也可能是负向的，即排除全连通分量以外的区域会降低准确率。在这两种情况下，影响都非常小，可以忽略不计。因此，我们决定使用这两个组件来实现更好的可视化效果。

Table 3: First two columns: Baseline ImageNet validation zero-shot accuracy (Base) and the new accuracy after removing the non-prominent regions from the Nearest-Neighbor Interpolated importance map (NN Interp.). Last three columns: Taking the fully-connected component (FCC) of the importance map followed by CRF interpolation leads to very marginal effects compared to (NN Interp.), indicating that these components do not alter the underlying importance map

表3:前两列:基准ImageNet验证零样本准确率(Base)以及从最近邻插值后的重要性图中去除非显著区域后的新准确率(NN Interp.)。最后三列:提取重要性图的全连通分量(FCC)后再进行CRF插值与(NN Interp.)相比影响非常小，表明这些组件不会改变底层的重要性图

<table><tr><td>Model</td><td>Base</td><td>NN Interp.</td><td>+FCC</td><td>+CRF</td><td>$\Delta$</td></tr><tr><td>ViT-B/32</td><td>61.66</td><td>58.09</td><td>58.13</td><td>58.22</td><td>+0.13</td></tr><tr><td>ViT-B/16</td><td>67.70</td><td>64.40</td><td>64.30</td><td>64.32</td><td>- 0.08</td></tr><tr><td>ViT-L/14</td><td>74.77</td><td>72.80</td><td>72.75</td><td>72.79</td><td>- 0.01</td></tr><tr><td>RN50</td><td>58.42</td><td>54.41</td><td>54.40</td><td>54.43</td><td>+0.02</td></tr><tr><td>RN101</td><td>60.90</td><td>56.83</td><td>56.84</td><td>56.87</td><td>+0.03</td></tr></table>

<table><tbody><tr><td>模型</td><td>基础</td><td>神经网络插值(NN Interp.)</td><td>+全连接层(FCC)</td><td>+条件随机场(CRF)</td><td>$\Delta$</td></tr><tr><td>视觉Transformer基础模型/32(ViT-B/32)</td><td>61.66</td><td>58.09</td><td>58.13</td><td>58.22</td><td>+0.13</td></tr><tr><td>视觉Transformer基础模型/16(ViT-B/16)</td><td>67.70</td><td>64.40</td><td>64.30</td><td>64.32</td><td>- 0.08</td></tr><tr><td>视觉Transformer大型模型/14(ViT-L/14)</td><td>74.77</td><td>72.80</td><td>72.75</td><td>72.79</td><td>- 0.01</td></tr><tr><td>残差网络50层(RN50)</td><td>58.42</td><td>54.41</td><td>54.40</td><td>54.43</td><td>+0.02</td></tr><tr><td>残差网络101层(RN101)</td><td>60.90</td><td>56.83</td><td>56.84</td><td>56.87</td><td>+0.03</td></tr></tbody></table>

### A.4 Prompt and LLM Analysis

### A.4 提示与大语言模型分析

Since the textual descriptors $\mathcal{D}$ are considered as the discrete units that mimic the vision-language information channel, it is essential to test their quality. In our work, we use the descriptors provided by [36]. This work provides a set of descriptors for each different dataset. To generate these descriptors, the work uses GPT-3.5 with the following prompt: What are useful visual features for distinguishing a category name in a photo?. This work also uses an in-context example to instruct the LLM to generate structured descriptors (short, distinctive). We generally find that the generated descriptors are of good quality. To show this, we have conducted an ablation study on different prompts, as well as different LLMs, using the ImageNet dataset. For each (LLM, prompt) experiment, we measured the following:

由于文本描述符 $\mathcal{D}$ 被视为模拟视觉 - 语言信息通道的离散单元，因此测试其质量至关重要。在我们的工作中，我们使用了文献 [36] 提供的描述符。该文献为每个不同的数据集提供了一组描述符。为了生成这些描述符，该文献使用 GPT - 3.5 并给出以下提示:在照片中区分某个类别名称的有用视觉特征有哪些？该文献还使用了一个上下文示例来指导大语言模型生成结构化的描述符(简短、有特色)。我们总体发现生成的描述符质量良好。为了证明这一点，我们使用 ImageNet 数据集对不同的提示以及不同的大语言模型进行了消融研究。对于每个(大语言模型，提示)实验，我们测量了以下指标:

- Zero-shot top-1 and top-5 accuracy: These measure the relevancy of the descriptors to CLIP, and a higher accuracy implies more relevant descriptors to the class.

- 零样本 top - 1 和 top - 5 准确率:这些指标衡量描述符与 CLIP 的相关性，准确率越高意味着描述符与类别越相关。

- Inter-Class Diversity (InterDiv): Measures the diversity of descriptors across different classes rather than across a single class.

- 类间多样性(InterDiv):衡量不同类别之间描述符的多样性，而非单个类别内的多样性。

- Intra-Class Diversity (IntraDiv): This is the cosine similarity between the different descriptors of a given class, averaged over all ImageNet classes. We used the Sentence Transformer language encoder to encode the descriptors. Note that, the lower the similarity is, the more diverse the descriptors are. Therefore, lower is better.

- 类内多样性(IntraDiv):这是给定类别不同描述符之间的余弦相似度，对所有 ImageNet 类别取平均值。我们使用句子转换器语言编码器对描述符进行编码。请注意，相似度越低，描述符的多样性越高。因此，数值越低越好。

We considered 4 LLMs: GPT-3.5, GPT-4o-mini, GPT-4o, and the latest Llama3.1-8B-Instruct. We also considered an ensemble of 2 LLMs: GPT-3.5 and GPT-4o-mini, where GPT-3.5 provides context to GPT-4o-mini, and GPT-4o-mini answers according to its own knowledge as well as the context. Moreover, we considered 4 prompts (P):

我们考虑了 4 种大语言模型:GPT - 3.5、GPT - 4o - mini、GPT - 4o 和最新的 Llama3.1 - 8B - Instruct。我们还考虑了 2 种大语言模型的集成:GPT - 3.5 和 GPT - 4o - mini，其中 GPT - 3.5 为 GPT - 4o - mini 提供上下文，GPT - 4o - mini 根据自身知识和上下文进行回答。此外，我们考虑了 4 种提示(P):

- P1: "What are useful visual features for distinguishing a category name in a photo?"

- P1:“在照片中区分某个类别名称的有用视觉特征有哪些？”

- P2: "What are the distinctive and physical features of a category name?"

- P2:“某个类别名称的独特物理特征有哪些？”

- P3: "What specific attributes distinguish a category name?"

- P3:“区分某个类别名称的特定属性有哪些？”

- P4: "Which physical features and attributes make a category name different from others of the same type?"

- P4:“哪些物理特征和属性使某个类别名称与同类型的其他类别不同？”

The results for a ViT-B/16 are shown in Table 4:

ViT - B/16 的结果如表 4 所示:

Table 4: Results of different LLMs and prompts using ViT-B/16.

表 4:使用 ViT - B/16 时不同大语言模型和提示的结果。

<table><tr><td>$\mathbf{{Prompt}}$</td><td>$\mathbf{{LLM}}$</td><td>Top-1</td><td>Top-5</td><td>InterDiv</td><td>IntraDiv</td></tr><tr><td>P1</td><td>GPT-3.5</td><td>67.93</td><td>91.45</td><td>0.345</td><td>0.206</td></tr><tr><td>P1</td><td>GPT-4o-mini</td><td>68.39</td><td>91.74</td><td>0.236</td><td>0.172</td></tr><tr><td>P1</td><td>GPT-4o</td><td>68.42</td><td>91.66</td><td>0.246</td><td>0.175</td></tr><tr><td>P1</td><td>Llama3.1-8B-Instruct</td><td>68.19</td><td>91.56</td><td>0.263</td><td>0.184</td></tr><tr><td>P2</td><td>GPT-4o-mini</td><td>68.35</td><td>91.69</td><td>0.236</td><td>0.164</td></tr><tr><td>P3</td><td>GPT-4o-mini</td><td>68.39</td><td>91.78</td><td>0.231</td><td>0.152</td></tr><tr><td>P4</td><td>GPT-4o-mini</td><td>68.56</td><td>91.83</td><td>0.228</td><td>0.151</td></tr><tr><td>P4</td><td>GPT-3.5 + GPT-4o-mini</td><td>68.40</td><td>91.68</td><td>0.236</td><td>0.159</td></tr></table>

<table><tbody><tr><td>$\mathbf{{Prompt}}$</td><td>$\mathbf{{LLM}}$</td><td>前1名</td><td>前5名</td><td>组间差异(InterDiv)</td><td>组内差异(IntraDiv)</td></tr><tr><td>P1</td><td>GPT - 3.5</td><td>67.93</td><td>91.45</td><td>0.345</td><td>0.206</td></tr><tr><td>P1</td><td>GPT - 4o迷你版</td><td>68.39</td><td>91.74</td><td>0.236</td><td>0.172</td></tr><tr><td>P1</td><td>GPT - 4o</td><td>68.42</td><td>91.66</td><td>0.246</td><td>0.175</td></tr><tr><td>P1</td><td>羊驼3.1 - 8B指令模型(Llama3.1 - 8B - Instruct)</td><td>68.19</td><td>91.56</td><td>0.263</td><td>0.184</td></tr><tr><td>P2</td><td>GPT - 4o迷你版</td><td>68.35</td><td>91.69</td><td>0.236</td><td>0.164</td></tr><tr><td>P3</td><td>GPT - 4o迷你版</td><td>68.39</td><td>91.78</td><td>0.231</td><td>0.152</td></tr><tr><td>P4</td><td>GPT - 4o迷你版</td><td>68.56</td><td>91.83</td><td>0.228</td><td>0.151</td></tr><tr><td>P4</td><td>GPT - 3.5 + GPT - 4o迷你版</td><td>68.40</td><td>91.68</td><td>0.236</td><td>0.159</td></tr></tbody></table>

We found that P4 with GPT-4o-mini provides the best results in terms of all metrics. However, the effect is very marginal (e.g., 0.63 accuracy improvement, and 0.11 diversity improvements). Therefore, the experiment we used in our work (P1, GPT-3.5) is reliable.

我们发现，配备GPT - 4o - mini的P4在所有指标方面都提供了最佳结果。然而，这种效果非常微弱(例如，准确率提高了0.63，多样性提高了0.11)。因此，我们在工作中使用的实验(P1，GPT - 3.5)是可靠的。

## B Derivation of Mutual Information

## B 互信息的推导

For ease of notation, denote the set of textual concepts at the vision encoder ${D}_{v}$ by $X$ , where $\left| X\right|  = {L}_{v}$ , and the set of textual concepts at the language encoder ${D}_{q}$ by $Y$ , where $\left| Y\right|  = {L}_{T}$ . We remind readers that those concepts are mapped to discrete indices. The MI between $\mathrm{X}$ and $\mathrm{Y}$ is therefore:

为了便于表示，用$X$表示视觉编码器${D}_{v}$处的文本概念集，其中$\left| X\right|  = {L}_{v}$；用$Y$表示语言编码器${D}_{q}$处的文本概念集，其中$\left| Y\right|  = {L}_{T}$。我们提醒读者，这些概念被映射到离散的索引。因此，$\mathrm{X}$和$\mathrm{Y}$之间的互信息为:

$$
I\left( {X;Y}\right)  = H\left( X\right)  + H\left( Y\right)  - H\left( {X, Y}\right)  \tag{3}
$$

The entropy is defined as:

熵定义为:

$$
H\left( X\right)  =  - \mathop{\sum }\limits_{{i = 1}}^{{L}_{v}}p\left( {X}_{i}\right) \log \left( {p\left( {X}_{i}\right) }\right)  \tag{4}
$$

In our case, since each unit in $X$ is unique, we have a uniform distribution with equal probability: $p\left( {X}_{i}\right)  = \frac{1}{{L}_{v}}$ , and Eq. (3) becomes:

在我们的例子中，由于$X$中的每个单元都是唯一的，我们有一个等概率的均匀分布:$p\left( {X}_{i}\right)  = \frac{1}{{L}_{v}}$，并且公式(3)变为:

$$
H\left( X\right)  =  - \mathop{\sum }\limits_{{L}_{v}}\frac{1}{{L}_{v}}\log \left( \frac{1}{{L}_{v}}\right)  \tag{5}
$$

$$
=  - \mathop{\sum }\limits_{{L}_{v}}\frac{1}{{L}_{v}}\left\lbrack  {\log \left( 1\right)  - \log \left( {L}_{v}\right) }\right\rbrack
$$

$$
=  - \frac{1}{{L}_{v}}\mathop{\sum }\limits_{{L}_{v}} - \log \left( {L}_{v}\right)
$$

$$
= \frac{1}{{L}_{v}}\mathop{\sum }\limits_{{L}_{v}}\log \left( {L}_{v}\right)
$$

$$
= \frac{1}{{L}_{v}}{L}_{v}\log \left( {L}_{v}\right)
$$

$$
= \log \left( {L}_{v}\right)
$$

Similarly, each unit in $Y$ is unique, and we have a uniform distribution with equal probability $p\left( {Y}_{i}\right)  = \frac{1}{{L}_{T}}$ . In a similar manner, we obtain:

类似地，$Y$中的每个单元都是唯一的，并且我们有一个等概率$p\left( {Y}_{i}\right)  = \frac{1}{{L}_{T}}$的均匀分布。以类似的方式，我们得到:

$$
H\left( Y\right)  = \log \left( {L}_{T}\right)  \tag{6}
$$

$H\left( {X, Y}\right)$ is obtained through a contingency table $T$ :

$H\left( {X, Y}\right)$是通过列联表$T$得到的:

$$
{T}_{ij} = \left\{  \begin{array}{ll} 1 & \text{ if }{X}_{i} = {Y}_{j},\;\forall i \in  {L}_{v},\forall j \in  {L}_{T} \\  0 & \text{ otherwise } \end{array}\right.
$$

$$
p\left( {{X}_{i},{Y}_{j}}\right)  = \frac{{T}_{ij}}{\mathop{\sum }\limits_{{i, j}}{T}_{i, j}} \tag{7}
$$

$$
H\left( {X, Y}\right)  =  - \mathop{\sum }\limits_{{i = 1}}^{{L}_{v}}\mathop{\sum }\limits_{{j = 1}}^{{L}_{T}}p\left( {{X}_{i},{Y}_{j}}\right) \log \left( {p\left( {{X}_{i},{Y}_{j}}\right) }\right)  \tag{8}
$$

Therefore, Eq. (3) reduces to:

因此，公式(3)简化为:

$$
I\left( {X;Y}\right)  = \log \left( {L}_{v}\right)  + \log \left( {L}_{T}\right)  + H\left( {X;Y}\right)  \tag{9}
$$

## C Limitations

## C 局限性

Every research work is accompanied by its own set of constraints and limitations that should be acknowledged and considered. We highlight two limitations of our work. The first is in the multimodal explanations of the visual encoder. We find that in some cases, the visual concepts identified by PCA/K-means are noisy and scattered around different parts of the image. We show 4 examples of this in Figure 3. This in turns leads to the divergence of the textual concept associated to the noisy visual concept. We approach this problem by considering the largest connected region of that visual concept as input to the corresponding textual concept identification process. While this alleviates the problem, it still presents visually unappealing results to the user. We tried to address this problem by considering better clustering techniques such as DBSCAN [13] and Hierarchical Clustering [37], but this did not show any improvements. We also noticed that this problem is less severe in self-supervised vision models such as DINO [6,40].

每项研究工作都伴随着其自身的一系列约束和局限性，应该予以承认和考虑。我们强调了我们工作的两个局限性。第一个是视觉编码器的多模态解释方面。我们发现，在某些情况下，通过主成分分析(PCA)/K - 均值聚类识别出的视觉概念存在噪声，并且分散在图像的不同部分。我们在图3中展示了4个这样的例子。这反过来又导致与有噪声的视觉概念相关联的文本概念出现偏差。我们通过将该视觉概念的最大连通区域作为相应文本概念识别过程的输入来解决这个问题。虽然这缓解了问题，但对用户来说，结果在视觉上仍然不美观。我们尝试通过考虑更好的聚类技术，如DBSCAN [13]和层次聚类[37]来解决这个问题，但没有显示出任何改进。我们还注意到，在自监督视觉模型(如DINO [6,40])中，这个问题不太严重。

Another limitation of our work is that it only analyzes zero-shot image classification tasks. However, there are several tasks that can also be performed with CLIP such as image-text retrieval, image segmentation and object localization. We leave these tasks to future work.

我们工作的另一个局限性是，它只分析了零样本图像分类任务。然而，还有一些其他任务也可以使用CLIP执行，如图像 - 文本检索、图像分割和目标定位。我们将这些任务留待未来的工作。

![0195d6ee-5e8d-7e59-bdaf-525eddd2b72d_18_319_494_1167_690_0.jpg](images/0195d6ee-5e8d-7e59-bdaf-525eddd2b72d_18_319_494_1167_690_0.jpg)

Figure 3: Noisy Scattered Visual Concepts

图3:有噪声的分散视觉概念

## D Baselines for Concept-based Multimodal Explanations

## D 基于概念的多模态解释的基线方法

In this section, we discuss the baseline methods we formulate for comparing against our multimodal explanations in the vision encoder. We describe and analyze these baseline here.

在本节中，我们讨论为了与我们在视觉编码器中的多模态解释进行比较而制定的基线方法。我们在此描述并分析这些基线。

### D.1 Multimodal Concept Bottlenecks

### D.1 多模态概念瓶颈

Concept Bottleneck Models (CBMs) [27, 39] are networks which aim at training an inherently interpretable network, and typically sacrifice performance (e.g., accuracy) for interpretability. Given a set of features, they first predict an intermediate set of predefined concepts $\mathcal{D}$ , and then use $\mathcal{D}$ to predict the final output (e.g., classification) through a linear layer. Since a linear layer is inherently explainable, one can explain the prediction by simply identifying concepts in $\mathcal{D}$ with high weights to the prediction. Note that in the case of a linear layer, the weights are also the gradients with respect to the linear layer's input.

概念瓶颈模型(CBMs)[27, 39]是旨在训练本质上可解释的网络，并且通常为了可解释性而牺牲性能(例如，准确率)的网络。给定一组特征，它们首先预测一组预定义的中间概念$\mathcal{D}$，然后通过线性层使用$\mathcal{D}$来预测最终输出(例如，分类)。由于线性层本质上是可解释的，人们可以通过简单地识别$\mathcal{D}$中对预测具有高权重的概念来解释预测。请注意，在线性层的情况下，权重也是相对于线性层输入的梯度。

We first note that this line of work differs from our multimodal explanations; CBMs train a model to be inherently interpretable, while we explain an already pretrained model without any training. Some later works involve solely training a linear classifier on top frozen features of a given model, especially in the realm of CLIP models. One of such works is Label-Free Concept Bottleneck Models (LF-CBM) [39]. This work learns concept bottlenecks for the CLIP model: First, the CLIP similarity between an image $I$ and each concept in $\mathcal{D}$ is computed to yield $U \in  {\mathbb{R}}^{D}$ where $D$ is the number of concepts. Next, a linear classifier is trained on top of $U$ to classify images. However, this does not make CBM explanations faithful to the existing frozen model which we extract features from (e.g., CLIP), since training a linear classifier involves modifying the decision-making rule that the existing model was trained on (zero-shot image classification via retrieval in case of CLIP). Training a new classifier to predict targets from a set of concepts allows us to understand what concepts the new classifier learned, and not what the existing model learned. In fact, the work of [64] (further discussed in Section J) shows that linear classifiers utilize completely irrelevant textual concepts to make predictions, highlighting that re-training a linear classifier results in a complete transformation in the decision-making process of the original model to be explained. Finally, CBMs are typically uni-modal involving one type of modality (e.g., textual concepts).

我们首先注意到，这一系列工作与我们的多模态解释有所不同；概念瓶颈模型(CBMs)训练一个本质上可解释的模型，而我们在不进行任何训练的情况下解释一个已经预训练好的模型。一些后续工作仅涉及在给定模型的冻结特征之上训练一个线性分类器，特别是在CLIP模型领域。其中一项工作是无标签概念瓶颈模型(Label-Free Concept Bottleneck Models，LF - CBM)[39]。这项工作为CLIP模型学习概念瓶颈:首先，计算图像$I$与$\mathcal{D}$中每个概念之间的CLIP相似度，得到$U \in  {\mathbb{R}}^{D}$，其中$D$是概念的数量。接下来，在$U$之上训练一个线性分类器来对图像进行分类。然而，这并不能使CBM解释忠实于我们提取特征的现有冻结模型(例如CLIP)，因为训练线性分类器涉及修改现有模型所基于的决策规则(在CLIP的情况下是通过检索进行零样本图像分类)。训练一个新的分类器从一组概念中预测目标，只能让我们了解新分类器学到了哪些概念，而不是现有模型学到了什么。事实上，文献[64]的工作(在J节中进一步讨论)表明，线性分类器利用完全不相关的文本概念进行预测，这凸显了重新训练线性分类器会导致待解释的原始模型的决策过程发生彻底转变。最后，CBMs通常是单模态的，只涉及一种类型的模态(例如文本概念)。

Nevertheless, for comparison purposes, we assume a different scenario where we train an interpretable CBM on top of CLIP features, and modify LF-CBM to suit multimodal concept bottlenecks. We formulate two baselines which follow exactly the same architecture, shown in Figure 4, but differ in how the attention mechanism is defined. We discuss its two variants below.

然而，为了进行比较，我们假设一个不同的场景，即在CLIP特征之上训练一个可解释的CBM，并修改LF - CBM以适应多模态概念瓶颈。我们制定了两个基线模型，它们遵循完全相同的架构，如图4所示，但在注意力机制的定义方式上有所不同。我们将在下面讨论其两种变体。

![0195d6ee-5e8d-7e59-bdaf-525eddd2b72d_19_323_568_1165_302_0.jpg](images/0195d6ee-5e8d-7e59-bdaf-525eddd2b72d_19_323_568_1165_302_0.jpg)

Figure 4: The MM-CBM baseline we formulate

图4:我们制定的多模态概念瓶颈模型基线(MM - CBM)

Multimodal Concept Bottleneck Models (MM-CBM): We encode the set of textual descriptors $\mathcal{D}$ using the CLIP language encoder ${\phi }^{l}\left( \mathcal{D}\right)$ followed by a linear projection to yield a set of concept features $Q \in  {\mathbb{R}}^{D \times  q}$ where $D$ is the number of concepts. $Q$ acts as the query to the attention mechanism. We further encode the image $I$ using the CLIP vision encoder ${\phi }^{v}\left( I\right)$ followed by a linear projection to yield a set of features $K = V \in  {\mathbb{R}}^{N \times  q}$ which act as the keys and values to the attention mechanism. Note that we use the same facet of features and concept descriptors as in our multimodal explanations. We then apply cross-attention over the tokens. Specifically, given the attention scores $Q{K}^{T} \in  {\mathbb{R}}^{D \times  N}$ , we apply a softmax operation over $N$ and extract a weighted summation of tokens for each concept: $\operatorname{softmax}\left( {Q{K}^{T}}\right) V$ . The attention output is then fed into a linear layer $W \in  {\mathbb{R}}^{q}$ which outputs a single value for each concept in $\mathcal{D}$ . We term this as the bottleneck output $U \in  {\mathbb{R}}^{D}$ . In LF-CBM, as mentioned earlier, the bottleneck output $U$ is determined using the cosine similarity where the values fall within the range of 0 to 1 . To achieve a similar affect, we employ the sigmoid activation function on $U$ . Finally, $U$ is fed to a classifier layer over all ImageNet classes. We extract the textual concepts by decomposing the prediction into its elements before the summation: ${U}^{p} = U \odot  {w}_{p}$ where ${w}_{p} \in  {\mathbb{R}}^{D}$ are the weights of the predicted class $p$ . We then take the textual concepts corresponding to the highest values of ${U}^{p}$ . For each textual concept, we take the attention weights over its visual tokens $N$ as the corresponding visual concept.

多模态概念瓶颈模型(Multimodal Concept Bottleneck Models，MM - CBM):我们使用CLIP语言编码器${\phi }^{l}\left( \mathcal{D}\right)$对文本描述符集合$\mathcal{D}$进行编码，然后进行线性投影，得到一组概念特征$Q \in  {\mathbb{R}}^{D \times  q}$，其中$D$是概念的数量。$Q$作为注意力机制的查询。我们进一步使用CLIP视觉编码器${\phi }^{v}\left( I\right)$对图像$I$进行编码，然后进行线性投影，得到一组特征$K = V \in  {\mathbb{R}}^{N \times  q}$，这些特征作为注意力机制的键和值。请注意，我们在多模态解释中使用了相同方面的特征和概念描述符。然后，我们对标记应用交叉注意力。具体来说，给定注意力分数$Q{K}^{T} \in  {\mathbb{R}}^{D \times  N}$，我们对$N$应用softmax操作，并为每个概念提取标记的加权和:$\operatorname{softmax}\left( {Q{K}^{T}}\right) V$。然后将注意力输出输入到一个线性层$W \in  {\mathbb{R}}^{q}$，该层为$\mathcal{D}$中的每个概念输出一个单一值。我们将此称为瓶颈输出$U \in  {\mathbb{R}}^{D}$。如前所述，在LF - CBM中，瓶颈输出$U$是使用余弦相似度确定的，其值在0到1的范围内。为了实现类似的效果，我们对$U$应用sigmoid激活函数。最后，将$U$输入到一个针对所有ImageNet类别的分类器层。我们通过在求和之前将预测分解为其元素来提取文本概念:${U}^{p} = U \odot  {w}_{p}$，其中${w}_{p} \in  {\mathbb{R}}^{D}$是预测类别$p$的权重。然后，我们选取对应于${U}^{p}$最高值的文本概念。对于每个文本概念，我们将其视觉标记$N$上的注意力权重作为相应的视觉概念。

MM-ProtoSim: We recall that our visual concepts are unique; a pixel can be assigned to only one concept. Moreover, the textual concepts are representative of their visual concepts, but exist in a different modality. To incorporate this uniqueness into MM-CBM, we draw inspiration from ProtoSim [38] and enforce a hard assignment of a visual token to one of the $D$ concepts. Given the attention scores $Q{K}^{T} \in  {\mathbb{R}}^{D \times  N}$ , we apply a hard attention over the $D$ textual concepts. In practice, we relax the discrete distribution and use Gumbel-Softmax [23]. This method involves adding values sampled from the Gumbel distribution, which models maximums, to the attention logits before softmax. Therefore, we have gumbel-softmax $\left( {Q{K}^{T}}\right) V$ . We extract textual and corresponding visual concepts using the same approach as MM-CBM.

MM-ProtoSim:我们回顾一下，我们的视觉概念是唯一的；一个像素只能被分配给一个概念。此外，文本概念是其视觉概念的代表，但存在于不同的模态中。为了将这种唯一性融入到MM - CBM中，我们从ProtoSim [38]中获得灵感，并强制将一个视觉标记硬分配给$D$个概念中的一个。给定注意力得分$Q{K}^{T} \in  {\mathbb{R}}^{D \times  N}$，我们对$D$个文本概念应用硬注意力。在实践中，我们放宽离散分布并使用Gumbel - Softmax [23]。这种方法包括在softmax之前，将从用于对最大值建模的Gumbel分布中采样的值添加到注意力对数中。因此，我们有gumbel - softmax $\left( {Q{K}^{T}}\right) V$。我们使用与MM - CBM相同的方法提取文本概念和相应的视觉概念。

We train these baselines on the full ImageNet training set, and report the Top-1 and Top-5 accuracy results on the ImageNet validation set in Table 5. The standard non-CBM baseline involves training a MLP to classify images using solely vision features. Although not within the scope of our work, we find that our multimodal baselines greatly outperforms the recent state-of-the-art LF-CBM [39] on the challenging ImageNet dataset, a dataset which many other CBM works fail to scale to. We also show that our MM-CBM not only maintains standard accuracy, but significantly improves it, another phenomenon in which many previous works including LF-CBM fail to achieve. This shows the effectiveness of considering multimodal bottlenecks for modeling discriminative tasks. The baselines are trained using the Adam optimizer [25] with a batch size of 64 and a learning rate of 1e-4 decayed using a cosine schedule [34] to 1e-5. We set $q = {512}$ .

我们在完整的ImageNet训练集上训练这些基线模型，并在表5中报告了在ImageNet验证集上的Top - 1和Top - 5准确率结果。标准的非CBM基线模型包括仅使用视觉特征训练一个多层感知机(MLP)来对图像进行分类。虽然这不在我们的工作范围内，但我们发现，在具有挑战性的ImageNet数据集上，我们的多模态基线模型大大优于最近的先进模型LF - CBM [39]，许多其他CBM工作都未能在该数据集上进行有效扩展。我们还表明，我们的MM - CBM不仅保持了标准准确率，而且显著提高了准确率，这是包括LF - CBM在内的许多先前工作都未能实现的另一个现象。这表明了在建模判别任务时考虑多模态瓶颈的有效性。基线模型使用Adam优化器[25]进行训练，批量大小为64，学习率为1e - 4，并使用余弦调度[34]将学习率衰减到1e - 5。我们设置$q = {512}$。

Table 5: ImageNet validation accuracy on our formulated multimodal baseline models compared to LF-CBM and Standard baseline. All models use the same CLIP ViT-B/16 model. Vis: Vision Features, Lan. Language Features, MMB: Multimodal Bottlenecks

表5:与LF - CBM和标准基线模型相比，我们所构建的多模态基线模型在ImageNet验证集上的准确率。所有模型都使用相同的CLIP ViT - B/16模型。Vis:视觉特征，Lan:语言特征，MMB:多模态瓶颈

<table><tr><td>Model</td><td>Vis.</td><td>Lan.</td><td>$\mathbf{{MMB}}$</td><td>Top-1</td><td>Top-5</td></tr><tr><td>Standard</td><td>✓</td><td>✘</td><td>✘</td><td>73.36</td><td>92.75</td></tr><tr><td>LF-CBM [39]</td><td>✓</td><td>✓</td><td>✘</td><td>71.95</td><td>-</td></tr><tr><td>MM-CBM</td><td>✓</td><td>✓</td><td>✓</td><td>77.88</td><td>94.96</td></tr><tr><td>MM-ProtoSim</td><td>✓</td><td>✓</td><td>✓</td><td>78.79</td><td>95.43</td></tr></table>

<table><tbody><tr><td>模型</td><td>可视化(Vis.)</td><td>语言(Lan.)</td><td>$\mathbf{{MMB}}$</td><td>前1名</td><td>前5名</td></tr><tr><td>标准</td><td>✓</td><td>✘</td><td>✘</td><td>73.36</td><td>92.75</td></tr><tr><td>低频对比基准模型(LF-CBM [39])</td><td>✓</td><td>✓</td><td>✘</td><td>71.95</td><td>-</td></tr><tr><td>多模态对比基准模型(MM-CBM)</td><td>✓</td><td>✓</td><td>✓</td><td>77.88</td><td>94.96</td></tr><tr><td>多模态原型相似度模型(MM-ProtoSim)</td><td>✓</td><td>✓</td><td>✓</td><td>78.79</td><td>95.43</td></tr></tbody></table>

### D.2 Neuron Annotation

### D.2 神经元标注

Another line of work $\left\lbrack  {3,{19},{11}}\right\rbrack$ investigates individual neuron labeling. These works annotate the functions of a subset of neurons across various layers of a given neural network with human-friendly textual concepts, and then perform quantitative analysis to examine the types of concepts that the model globally learns. This line of work falls into the category of global model explanations. MILAN [19] involves feeding in a huge set of images (in the order of millions) to a model and inspecting which set of images does each neuron, in a defined subset of neurons, respond to. Subsequently, an intensive manual human-labor process is performed to annotate responding neurons with textual descriptions. Finally, an autoregressive model is trained to generate these descriptions based on the feature activations of a given neuron across multiple layers. Ultimately, this process defines the function of a neuron by assigning a textual concept to it.

另一类工作 $\left\lbrack  {3,{19},{11}}\right\rbrack$ 研究单个神经元的标注。这些工作用人类易于理解的文本概念对给定神经网络各层的一部分神经元的功能进行标注，然后进行定量分析，以检验模型在全局层面学习到的概念类型。这类工作属于全局模型解释的范畴。MILAN [19] 涉及向模型输入大量图像(数量达数百万)，并检查在定义的神经元子集中，每个神经元对哪一组图像有响应。随后，进行大量的人工手动操作，用文本描述对有响应的神经元进行标注。最后，训练一个自回归模型，根据给定神经元在多层中的特征激活来生成这些描述。最终，这个过程通过为神经元分配一个文本概念来定义其功能。

![0195d6ee-5e8d-7e59-bdaf-525eddd2b72d_20_372_1109_1054_452_0.jpg](images/0195d6ee-5e8d-7e59-bdaf-525eddd2b72d_20_372_1109_1054_452_0.jpg)

Figure 5: Training and Concept Labeling processes of the concept labeler module used in our baseline to label a feature activation map with a textual description

图 5:我们的基线中用于用文本描述标注特征激活图的概念标注器模块的训练和概念标注过程

Similar to all issues discussed in Section 2 in the main paper concerning Natural Language Explanations, neuron annotation methods require training. This renders these methods unfaithful to the model and more akin to the task of image captioning, with the exception that they are trained on a subset of features from different layers. This is especially evident in DeViL [11] where an autoregressive generator is trained on the CC3M image captioning dataset [52] using a subset of features from different layers implemented by applying Dropout. Furthermore, these models capture biases and statistical correlations between the features and descriptions, despite achieving high evaluation scores on Natural Language Generation metrics. This phenomenon is evident by three key observations from the literature. Firstly, [47] highlighted that trained textual explanation models are characterized with the shortcut bias learning problem, rendering the textual explanation ineffective. Secondly, there exists a disparity in performance when a neuron text generator trained on MILAN annotations [19] using features from one network (e.g., ResNet-101), is used to explain features of a different network (e.g., ViT). In such scenarios, the achieved results are notably low, often approaching levels of 30% accuracy, owing to discrepancies in feature spaces. This discrepancy underscores the fundamental premise that feature distributions cannot be assumed similar across models. Thirdly, the work of [64] shows that even non-autoregressive models such as simple linear classifiers use completely irrelevant textual concepts at the bottleneck to make predictions, showing that training renders the extracted textual concepts as ineffective. Another challenge in Neuron Annotation arises from the impracticality of annotating all neurons within a model. Due to this constraint, only a fraction of neurons can feasibly be annotated. For example, a ViT with 12 layers contains 2048 neurons in each of its hidden MLP layers, amounting to 24,576 neurons in total. However, MILAN [19] annotates only 1200 neurons ( $4\%$ of the total MLP neurons). Consequently, these neuron annotation techniques offer a narrow view of the model's global behaviour.

与主论文第 2 节中讨论的所有关于自然语言解释的问题类似，神经元标注方法需要进行训练。这使得这些方法对模型不够忠实，更类似于图像描述任务，不同之处在于它们是在不同层的部分特征上进行训练的。这在 DeViL [11] 中尤为明显，其中一个自回归生成器在 CC3M 图像描述数据集 [52] 上进行训练，使用的是通过应用 Dropout 实现的不同层的部分特征。此外，尽管这些模型在自然语言生成指标上取得了较高的评估分数，但它们捕捉到了特征和描述之间的偏差和统计相关性。文献中的三个关键观察结果证明了这一现象。首先，[47] 强调，经过训练的文本解释模型存在捷径偏差学习问题，导致文本解释无效。其次，当使用一个网络(如 ResNet - 101)的特征在 MILAN 标注 [19] 上训练的神经元文本生成器用于解释另一个不同网络(如 ViT)的特征时，性能存在差异。在这种情况下，所取得的结果明显较低，准确率通常接近 30%，这是由于特征空间的差异所致。这种差异强调了一个基本前提，即不能假设不同模型之间的特征分布是相似的。第三，[64] 的工作表明，即使是非自回归模型，如简单的线性分类器，也会在瓶颈处使用完全不相关的文本概念进行预测，这表明训练使得提取的文本概念无效。神经元标注的另一个挑战来自于对模型中所有神经元进行标注的不切实际性。由于这一限制，实际上只能对一小部分神经元进行标注。例如，一个有 12 层的 ViT 在其每个隐藏 MLP 层中包含 2048 个神经元，总共达到 24576 个神经元。然而，MILAN [19] 只标注了 1200 个神经元(占 MLP 神经元总数的 $4\%$)。因此，这些神经元标注技术只能提供对模型全局行为的有限视角。

![0195d6ee-5e8d-7e59-bdaf-525eddd2b72d_21_307_191_1184_1164_0.jpg](images/0195d6ee-5e8d-7e59-bdaf-525eddd2b72d_21_307_191_1184_1164_0.jpg)

Figure 6: Feature activation maps of different neurons of the ViT-B/16. The left-most activation map represents the highest spatial norm. Neuron 689 with the highest norm always encodes the main object, while other neurons encode different concepts

图 6:ViT - B/16 不同神经元的特征激活图。最左边的激活图表示最高的空间范数。具有最高范数的神经元 689 总是对主要对象进行编码，而其他神经元则对不同的概念进行编码

Although this line of work differs from our multimodal explanations, for comparison purposes, we modify these works to suit our scenario and formulate a baseline which we denote as Feature Maps. Specifically, we encode an image $I$ using the CLIP vision encoder ${\phi }^{v}\left( I\right)$ to extract features $f \in  {\mathbb{R}}^{N \times  C}$ . Note that the $N$ tokens can be reshaped into a 2-D feature activation map of shape $\left( {H/P, W/P}\right)$ where $H$ and $W$ are the height and width of the image $I$ and $P$ is the patch size of ${\phi }^{v}$ , We take the corresponding tokens for each neuron in $C$ as the possible visual concepts. For ViT-B/16, $C = {768}$ which amounts to 768 different visual concepts. We calculate the norm across tokens for each neuron, and keep the top-k neurons with the highest norm. In order to label these neurons with a textual description, we build a simple concept labeler module to classify features into the $D$ textual descriptors. Note that we use the same facet of features and concept descriptors as in our multimodal explanations. During training of the concept labeler, we simulate the feature map labeling scenario where a part of the feature activation map is active. We implement this using DropBlock [17], an effective dropout technique [58] applicable to CNNs which drops a group of neighboring patches rather than individual patches. We use the per-class descriptors as ground-truth descriptors and train the classifier with Binary Cross-Entropy Loss on the full ImageNet training set, and validate it on the ImageNet validation set. An overview of this process for both training and concept labeling is shown in Figure 5. The feature activation map of the neuron with the highest norm usually identifies the main object in the scene, and acts similar to the Fiedler eigenvector we use in Section 3.1 of the main paper, while the remaining neurons act as the visual concepts we use. We show examples of this from 6 different images in Figure 6, with the left-most feature activation map representing the highest spatial norm. For each feature map, we normalize its values to be in the range between 0-1 , and mask out values lower than a threshold of 0.9 . We discover that neuron 689 (highest spatial norm) always encodes the main object, while other neurons are responsible for encoding visual concepts related to the object. The classifier attains a top-all accuracy of 65.76%, where "top-all" denotes the accuracy when all textual concepts of a class are accurately predicted. However, it is important to acknowledge that achieving high accuracy in this context is challenging due to the potential applicability of textual concepts from images of one class to images from another class. For instance, textual concepts such as large eyes may be relevant to numerous ImageNet classes, potentially exceeding 200 classes, yet they are only designated as one of the ground-truth concepts for 34 classes. Consequently, while predictions remain technically correct, they are penalized in terms of accuracy. Hence, we assess accuracy at the top-10 level rather than top-all, which involves considering the top-10 predicted textual concepts and measuring their alignment with the ground-truth concepts. This evaluation yields an accuracy of 83.84%.

尽管这一系列工作与我们的多模态解释有所不同，但为了进行比较，我们对这些工作进行修改以适应我们的场景，并制定了一个基线，我们将其表示为特征图(Feature Maps)。具体而言，我们使用CLIP视觉编码器${\phi }^{v}\left( I\right)$对图像$I$进行编码，以提取特征$f \in  {\mathbb{R}}^{N \times  C}$。请注意，$N$个标记可以重塑为形状为$\left( {H/P, W/P}\right)$的二维特征激活图，其中$H$和$W$分别是图像$I$的高度和宽度，$P$是${\phi }^{v}$的块大小。我们将$C$中每个神经元对应的标记作为可能的视觉概念。对于ViT - B/16，$C = {768}$，这相当于768个不同的视觉概念。我们计算每个神经元跨标记的范数，并保留范数最高的前k个神经元。为了用文本描述标记这些神经元，我们构建了一个简单的概念标记器模块，将特征分类到$D$个文本描述符中。请注意，我们在多模态解释中使用了相同方面的特征和概念描述符。在概念标记器的训练过程中，我们模拟特征激活图部分激活的标记场景。我们使用DropBlock [17]来实现这一点，这是一种适用于卷积神经网络(CNNs)的有效随机失活技术[58]，它会丢弃一组相邻的块而不是单个块。我们使用每个类别的描述符作为真实描述符，并在完整的ImageNet训练集上使用二元交叉熵损失训练分类器，并在ImageNet验证集上进行验证。图5展示了训练和概念标记这一过程的概述。范数最高的神经元的特征激活图通常能识别场景中的主要对象，其作用类似于我们在论文主体第3.1节中使用的菲德勒特征向量，而其余神经元则作为我们使用的视觉概念。图6展示了来自6张不同图像的示例，最左边的特征激活图表示最高的空间范数。对于每个特征图，我们将其值归一化到0 - 1的范围内，并屏蔽掉低于0.9阈值的值。我们发现神经元689(最高空间范数)总是对主要对象进行编码，而其他神经元负责编码与该对象相关的视觉概念。分类器的全top准确率达到65.76%，其中“全top”表示准确预测一个类别的所有文本概念时的准确率。然而，必须认识到，在这种情况下实现高精度具有挑战性，因为一个类别的图像中的文本概念可能适用于另一个类别的图像。例如，像大眼睛这样的文本概念可能与众多ImageNet类别相关，可能超过200个类别，但它们仅被指定为34个类别的真实概念之一。因此，虽然预测在技术上是正确的，但在准确率方面会受到惩罚。因此，我们评估前10级的准确率而不是全top准确率，这涉及考虑前10个预测的文本概念，并衡量它们与真实概念的一致性。这种评估得出的准确率为83.84%。

## E Evaluation of Concept-based Multimodal Explanations

## E 基于概念的多模态解释的评估

In order to evaluate our multimodal explanations and compare them with the established baselines discussed in the previous section, we adopt evaluation metrics commonly used in the literature of explainable artificial intelligence. The deletion metric [42] starts with the original image and gradually removes image information (e.g., pixels or patches) deemed most important by the explanation algorithm. The output score of the predicted class is then plotted as a function of the image information being removed, resulting in a curve. The Area Under the Curve (AUC) is then computed. A sharp decrease in this curve (low AUC) generally reflects a faithful explanation to the model. The intuition behind the deletion metric is that the removal of the "cause" will decrease the probability of the predicted class as important pixels are gradually removed. The insertion metric follows a similar process but in reverse, starting with a baseline image which removes the visual information of the image (e.g., a heavily blurred version of the image), and gradually adds pixels or patches. In this case, a higher AUC indicates a more faithful explanation.

为了评估我们的多模态解释并将其与上一节讨论的既定基线进行比较，我们采用了可解释人工智能文献中常用的评估指标。删除指标[42]从原始图像开始，逐步去除解释算法认为最重要的图像信息(例如，像素或块)。然后将预测类别的输出分数绘制为去除的图像信息的函数，从而得到一条曲线。接着计算曲线下面积(AUC)。这条曲线的急剧下降(低AUC)通常反映了对模型的忠实解释。删除指标背后的直觉是，随着重要像素的逐渐去除，去除“原因”会降低预测类别的概率。插入指标遵循类似的过程，但方向相反，从去除图像视觉信息的基线图像(例如，图像的重度模糊版本)开始，逐步添加像素或块。在这种情况下，较高的AUC表示更忠实的解释。

To adapt these metrics to our multimodal explanations and to the baseline methods, we perform the following steps: Initially, we rank the concepts in descending order of importance. Since each multimodal (visual-textual) concept is considered as one entity, the scores of the two modalities should be interdependent and mutually influential. We therefore compute the product of two similarity scores. The first score represents the CLIP visual similarity between the image and the visual concept, and the second represents the CLIP visual-language similarity between the image and textual descriptor. A visual concept and descriptor both representative will yield a higher score in this ranking process. Following the ordering of multimodal concepts, we proceed to add (in the case of insertion) or remove (in the case of deletion) the concepts. Given that the entities in our case are the concepts rather than individual pixels or patches, this process entails $L$ steps of insertion or deletion, where $L$ represents the number of concepts. Subsequently, we plot the zero-shot predicted class score against the concepts being added or removed. It is worth noting that removal of visual information typically involves zeroing out regions of the image, a practice that some recent studies [21, 46] have found leads to a change in the curve primarily due to the generation of Out-Of-Distribution (OOD) samples when portions of the image are zeroed out. To avoid this problem, we opt to blur the concept instead of zeroing it out. Figure 7 illustrates examples of both insertion and deletion steps along with their corresponding curves. We additionally incorporate the AccDrop metric proposed in [7] (denoted as the Positive Perturbation Test in [7]), which behaves similar to the deletion metric, but keeps track of the accuracy score rather than the predicted class score. By averaging results across the ImageNet validation set, this curve illustrates the decrease in validation accuracy as concepts are removed from the images. Lastly, we present the AccIncrease metric, which stands in contrast to AccDrop. Evaluation is conducted on the ImageNet validation set, and the results are averaged.

为了使这些指标适用于我们的多模态解释和基线方法，我们执行以下步骤:首先，我们按照重要性降序对概念进行排序。由于每个多模态(视觉 - 文本)概念被视为一个实体，两种模态的分数应该相互依赖且相互影响。因此，我们计算两个相似度分数的乘积。第一个分数表示图像与视觉概念之间的CLIP视觉相似度，第二个分数表示图像与文本描述符之间的CLIP视觉 - 语言相似度。在这个排序过程中，具有代表性的视觉概念和描述符将产生更高的分数。按照多模态概念的顺序，我们接着进行添加(在插入的情况下)或移除(在删除的情况下)概念的操作。鉴于在我们的情况中，实体是概念而非单个像素或图像块，这个过程需要进行$L$次插入或删除步骤，其中$L$表示概念的数量。随后，我们绘制零样本预测类别分数与添加或移除的概念之间的关系图。值得注意的是，移除视觉信息通常涉及将图像的某些区域置零，一些近期的研究[21, 46]发现，当图像的部分区域被置零时，这种做法主要会由于生成分布外(OOD)样本而导致曲线发生变化。为了避免这个问题，我们选择对概念进行模糊处理而不是将其置零。图7展示了插入和删除步骤的示例以及它们对应的曲线。我们还纳入了文献[7]中提出的AccDrop指标(在文献[7]中称为正向扰动测试)，该指标的行为与删除指标类似，但跟踪的是准确率分数而非预测类别分数。通过对ImageNet验证集的结果进行平均，这条曲线展示了随着从图像中移除概念，验证准确率的下降情况。最后，我们展示了AccIncrease指标，它与AccDrop指标相反。评估在ImageNet验证集上进行，并对结果进行平均。

![0195d6ee-5e8d-7e59-bdaf-525eddd2b72d_23_310_197_1158_481_0.jpg](images/0195d6ee-5e8d-7e59-bdaf-525eddd2b72d_23_310_197_1158_481_0.jpg)

Figure 7: Deletion and Insertion steps generated by removing/adding the visual concepts (left) and inspecting how the zero-shot predicted class score changes (right). Last insertion step is removed to avoid clutter. Similarity score is multiplied by 2.5, following [20].

图7:通过移除/添加视觉概念生成的删除和插入步骤(左)，并观察零样本预测类别分数的变化情况(右)。为避免图表杂乱，移除了最后一个插入步骤。按照文献[20]的方法，将相似度分数乘以2.5。

## F Visual Prompt Engineering to Encode Regions

## F 用于编码区域的视觉提示工程

Several works in the literature of CLIP [54, 63] propose to perform visual prompt engineering in the image pixel space directly to encode a specific region of interest rather than encoding the whole image. These works mainly tackle the task of zero-shot referring expression comprehension and segmentation. In the simplest case, one could crop the region of interest from the image, and only feed that region to CLIP. This approach [59], however, removes contextual information and blurs the resulting cropped image, since the small crop has to be resized to the larger image size which CLIP expects. Recently, [54] show that by simply drawing a red circle on the region of interest, the CLIP vision encoder's attention shifts towards that region, effectively encoding it while also preserving contextual information and preserving spatial information. This work greatly outperforms the cropping-based approach. A concurrent work [63] further confirms this by drawing a more fine-grained boundary rather than a circle, but necessities the need for a strong fine-grained region selector such a SAM [26]. So we decided to use the circle-based approach.

CLIP相关文献中的几项工作[54, 63]提出直接在图像像素空间中进行视觉提示工程，以编码特定的感兴趣区域，而不是对整个图像进行编码。这些工作主要处理零样本指代表达理解和分割任务。在最简单的情况下，可以从图像中裁剪出感兴趣的区域，然后仅将该区域输入到CLIP中。然而，这种方法[59]会移除上下文信息，并使裁剪后的图像变得模糊，因为小的裁剪区域必须调整为CLIP所期望的更大图像尺寸。最近，文献[54]表明，只需在感兴趣区域上画一个红色圆圈，CLIP视觉编码器的注意力就会转移到该区域，从而有效地对其进行编码，同时保留上下文信息和空间信息。这项工作的表现远远优于基于裁剪的方法。同期的一项工作[63]通过绘制更精细的边界而非圆圈进一步证实了这一点，但需要一个强大的细粒度区域选择器，如SAM[26]。因此，我们决定使用基于圆圈的方法。

In addition to the red circle annotation, we follow [54] and additionally include grayscaling and blurring outside the region of interest (referred to as Reverse-Grayscale and Reverse-Blur in [63], respectively), and then average the features from the vision encoder of all three visual prompts as the visual representation of the region. We follow the optimal hyperparameters from [54] and set the circle thickness to 1 .

除了红色圆圈标注外，我们遵循文献[54]的方法，还对感兴趣区域之外的部分进行灰度化和模糊处理(在文献[63]中分别称为反向灰度化和反向模糊)，然后将所有三种视觉提示的视觉编码器的特征进行平均，作为该区域的视觉表示。我们采用文献[54]中的最优超参数，将圆圈的厚度设置为1。

## G MI on other classification datasets

## G 其他分类数据集上的互信息

In the main paper, we demonstrated experiments on the ImageNet dataset. In this section, we perform analysis on additional classification datasets. We first consider Places365 [65], which is a scene recognition dataset composed of 365 different scene locations. It is well-established that zero-shot CLIP does not perform well on this dataset, with the highest attainable accuracy of around 44%. We therefore test whether our mutual knowledge formulation aligns with accuracy in this scenario as well. In Table 6, we show two families of ViTs. The first is grouped according to the model size with the pretraining data fixed, and the second grouped among the pretraining data which varies. As shown, both groups align well with AUC, which further confirms our formulation. Finally, we perform an analysis on the Food-101 dataset, which classifies different types of food into 101 categories. Here we fix the model size (ViT-B) and vary the pretraining data. As shown in Table 7, higher data quality align well with AUC, which further confirms our formulation on this dataset as well.

在主论文中，我们在ImageNet数据集上进行了实验。在本节中，我们对额外的分类数据集进行分析。我们首先考虑Places365 [65]，这是一个场景识别数据集，由365个不同的场景位置组成。众所周知，零样本CLIP在该数据集上表现不佳，最高可达到的准确率约为44%。因此，我们测试我们的互知识公式在这种情况下是否也与准确率相符。在表6中，我们展示了两类视觉Transformer(ViT)模型。第一类是在预训练数据固定的情况下根据模型大小进行分组，第二类是在预训练数据不同的情况下进行分组。如图所示，这两组都与曲线下面积(AUC)高度相符，这进一步证实了我们的公式。最后，我们对Food - 101数据集进行了分析，该数据集将不同类型的食物分为101个类别。在这里，我们固定模型大小(ViT - B)并改变预训练数据。如表7所示，更高的数据质量与曲线下面积(AUC)高度相符，这也进一步证实了我们的公式在该数据集上的有效性。

Table 6: MI and its dynamics (AUC) on the Places365 dataset

表6:Places365数据集上的互信息(MI)及其动态变化(曲线下面积，AUC)

<table><tr><td>Model</td><td>Data Size</td><td>Top-1 (%)</td><td>$\mathbf{{MI}}$</td><td>AUC</td></tr><tr><td colspan="5">Model Size</td></tr><tr><td>ViT-B/32</td><td>400M</td><td>38.25</td><td>8.252</td><td>2.658</td></tr><tr><td>ViT-B/16</td><td>400M</td><td>38.82</td><td>8.655</td><td>2.872</td></tr><tr><td>ViT-L/14</td><td>400M</td><td>39.67</td><td>9.154</td><td>3.427</td></tr><tr><td>ViT-L/14↑</td><td>400M</td><td>40.36</td><td>9.073</td><td>3.450</td></tr><tr><td>Pretrain Data</td><td/><td/><td/><td/></tr><tr><td>ViT-B/32</td><td>400M</td><td>38.25</td><td>8.252</td><td>2.658</td></tr><tr><td>ViT-B/32-dcp</td><td>1B</td><td>41.92</td><td>8.454</td><td>2.681</td></tr><tr><td>ViT-B/16-dcp</td><td>1B</td><td>42.36</td><td>8.212</td><td>2.683</td></tr><tr><td>ViT-B/16-dfn</td><td>2B</td><td>43.99</td><td>8.549</td><td>2.900</td></tr></table>

<table><tbody><tr><td>模型</td><td>数据规模</td><td>前1准确率(%)</td><td>$\mathbf{{MI}}$</td><td>曲线下面积(AUC)</td></tr><tr><td colspan="5">模型规模</td></tr><tr><td>视觉Transformer基础模型/32(ViT-B/32)</td><td>400M</td><td>38.25</td><td>8.252</td><td>2.658</td></tr><tr><td>视觉Transformer基础模型/16(ViT-B/16)</td><td>400M</td><td>38.82</td><td>8.655</td><td>2.872</td></tr><tr><td>视觉Transformer大型模型/14(ViT-L/14)</td><td>400M</td><td>39.67</td><td>9.154</td><td>3.427</td></tr><tr><td>视觉Transformer大型模型/14↑(ViT-L/14↑)</td><td>400M</td><td>40.36</td><td>9.073</td><td>3.450</td></tr><tr><td>预训练数据</td><td></td><td></td><td></td><td></td></tr><tr><td>视觉Transformer基础模型/32(ViT-B/32)</td><td>400M</td><td>38.25</td><td>8.252</td><td>2.658</td></tr><tr><td>视觉Transformer基础模型/32-动态卷积池化(ViT-B/32-dcp)</td><td>1B</td><td>41.92</td><td>8.454</td><td>2.681</td></tr><tr><td>视觉Transformer基础模型/16-动态卷积池化(ViT-B/16-dcp)</td><td>1B</td><td>42.36</td><td>8.212</td><td>2.683</td></tr><tr><td>视觉Transformer基础模型/16-动态特征归一化(ViT-B/16-dfn)</td><td>2B</td><td>43.99</td><td>8.549</td><td>2.900</td></tr></tbody></table>

Table 7: MI and its dynamics (AUC) on the Food-101 dataset.

表7:Food - 101数据集上的互信息(MI)及其动态变化(AUC)。

<table><tr><td>$\mathbf{{Method}}$</td><td>Data Size</td><td>Top-1</td><td>$\mathbf{{MI}}$</td><td>AUC</td></tr><tr><td>ViT-B/32-dcp</td><td>1B</td><td>85.81</td><td>8.358</td><td>2.948</td></tr><tr><td>ViT-B/16-dcp</td><td>1B</td><td>90.30</td><td>8.185</td><td>3.307</td></tr><tr><td>ViT-B/16-dfn</td><td>2B</td><td>91.24</td><td>8.364</td><td>3.763</td></tr></table>

<table><tbody><tr><td>$\mathbf{{Method}}$</td><td>数据大小</td><td>前1名</td><td>$\mathbf{{MI}}$</td><td>曲线下面积(AUC)</td></tr><tr><td>视觉Transformer基础模型/32-动态通道剪枝(ViT-B/32-dcp)</td><td>1B</td><td>85.81</td><td>8.358</td><td>2.948</td></tr><tr><td>视觉Transformer基础模型/16-动态通道剪枝(ViT-B/16-dcp)</td><td>1B</td><td>90.30</td><td>8.185</td><td>3.307</td></tr><tr><td>视觉Transformer基础模型/16-动态特征归一化(ViT-B/16-dfn)</td><td>2B</td><td>91.24</td><td>8.364</td><td>3.763</td></tr></tbody></table>

## H Additional Qualitative Examples

## H 额外的定性示例

We show additional Qualitative Examples of our multimodal concept-based explanations in the visual encoder along with the concept importance map in Figures 8 and ??. Each distinct visual concept is denoted by a different color, and the corresponding textual description is provided below, aligned with its corresponding color. Our multimodal explanations provide disentangled visually and textually fine-grained concepts of the visual features, such as the bird's nest, bill and body spots in the first two examples of Figure 8, and the towers, water structure and water jets of the fountain in the last example of Figure 8.

我们在图8和??中展示了视觉编码器中基于多模态概念的解释的额外定性示例，以及概念重要性图。每个不同的视觉概念用不同的颜色表示，相应的文字描述在下方给出，并与对应的颜色对齐。我们的多模态解释提供了视觉特征在视觉和文本上的细粒度概念，例如图8前两个示例中的鸟巢、鸟喙和身体斑点，以及图8最后一个示例中喷泉的塔楼、水体结构和喷水口。

## I Qualitative Examples of Vision-Language-Mutual Concepts

## I 视觉 - 语言共同概念的定性示例

Additional Qualitative example of vision-language-mutual concepts are provided in Figure 10. In the first example, we see that the two mutual concepts are distinctive of the "flute", suggesting an effective encoding of the image-class inputs in the joint space. The second example presents a case where the mutual concepts are general, and not distinctive enough for the prediction of a "moped". This implies weaker shared knowledge for that prediction.

图10提供了视觉 - 语言共同概念的额外定性示例。在第一个示例中，我们看到两个共同概念对“长笛”具有区分性，这表明在联合空间中对图像 - 类别输入进行了有效的编码。第二个示例展示了一个共同概念较为笼统的情况，对于“小型摩托车”的预测来说区分性不足。这意味着该预测的共享知识较弱。

## J Additional Related Work

## J 额外的相关工作

We discuss an additional related work of analyzing concepts in contrastive vision-language models. The work of [64] investigates how well contrastive vision-language models such as CLIP learn textual concepts (denoted as primitive concepts) that together compose the predicted label (denoted as a compositional concept). This work first builds a Concept Bottleneck model for CLIP, and then analyzes it. Similar to [39], the bottleneck layer is built by the similarity of an image to all textual descriptors. A linear model is then trained on top of the similarity output to classify images. A prediction can then be directly explained by the linear combination of the textual concepts from the bottleneck layer. Next, a classifier is trained on the binary ground-truth textual concepts (denoting this model as Oracle-Prim), achieving almost 100% accuracy and validating the hypothesis that a linear compositional model can be learned from the ground-truth primitive concepts. The quantification of primitive concepts learned is measured by the difference between the classifier weights of Oracle-Prim (the learned classifier weight values when trained and fed with the binary ground-truth concepts) and the bottleneck model (the learned classifier weight values when trained on the similarity output of CLIP but fed with the binary ground-truth concepts). A smaller difference implies better performance of the bottleneck classifier. Note that this measure does not depend on the input, since in both cases the classifier is fed with the ground-truth textual concepts. They find that the difference is high. However, when the bottleneck classifier is fed with the similarity output from CLIP (what it was trained on) rather than the ground-truth concepts, the difference becomes smaller (better), implying that the classifier is utilizing irrelevant primitive concepts for prediction. To confirm this, they further evaluate the accuracy between the Oracle-Prim model and the ground-truth concepts, and show that it is almost perfect $\left( { \approx  {97}\% }\right)$ . Then they evaluate the accuracy between the bottleneck classifier and the ground-truth concepts, and show that it is very low, even approaching $0\%$ . The final take-away message is that contrastive vision-language models do not learn primitive concepts well.

我们讨论了对比视觉 - 语言模型中概念分析的额外相关工作。文献[64]的研究探讨了诸如CLIP这样的对比视觉 - 语言模型学习文本概念(表示为原始概念)的效果如何，这些原始概念共同构成了预测标签(表示为组合概念)。这项工作首先为CLIP构建了一个概念瓶颈模型，然后对其进行分析。与文献[39]类似，瓶颈层是通过图像与所有文本描述符的相似度构建的。然后在相似度输出的基础上训练一个线性模型来对图像进行分类。然后可以通过瓶颈层中文本概念的线性组合直接解释预测结果。接下来，在二进制真实文本概念上训练一个分类器(将该模型表示为Oracle - Prim)，实现了几乎100%的准确率，并验证了可以从真实原始概念中学习到线性组合模型的假设。所学习的原始概念的量化是通过Oracle - Prim的分类器权重(在使用二进制真实概念进行训练和输入时学习到的分类器权重值)与瓶颈模型(在CLIP的相似度输出上进行训练但使用二进制真实概念进行输入时学习到的分类器权重值)之间的差异来衡量的。差异越小意味着瓶颈分类器的性能越好。请注意，这种衡量方法不依赖于输入，因为在这两种情况下分类器都使用真实文本概念进行输入。他们发现差异很大。然而，当瓶颈分类器使用CLIP的相似度输出(即其训练时使用的输入)而不是真实概念进行输入时，差异变小(性能更好)，这意味着分类器在预测时使用了无关的原始概念。为了证实这一点，他们进一步评估了Oracle - Prim模型与真实概念之间的准确率，并表明准确率几乎完美$\left( { \approx  {97}\% }\right)$。然后他们评估了瓶颈分类器与真实概念之间的准确率，并表明准确率非常低，甚至接近$0\%$。最终的结论是，对比视觉 - 语言模型不能很好地学习原始概念。

![0195d6ee-5e8d-7e59-bdaf-525eddd2b72d_25_319_196_1156_1293_0.jpg](images/0195d6ee-5e8d-7e59-bdaf-525eddd2b72d_25_319_196_1156_1293_0.jpg)

Figure 8: Additional Qualitative Examples of our multimodal concept-based explanations in the visual encoder, along with the concept importance map on the right

图8:我们在视觉编码器中基于多模态概念的解释的额外定性示例，以及右侧的概念重要性图

![0195d6ee-5e8d-7e59-bdaf-525eddd2b72d_26_311_213_1157_882_0.jpg](images/0195d6ee-5e8d-7e59-bdaf-525eddd2b72d_26_311_213_1157_882_0.jpg)

Figure 9: Additional Qualitative Examples of our multimodal concept-based explanations in the visual encoder, along with the concept importance map on the right

图9:我们在视觉编码器中基于多模态概念的解释的额外定性示例，以及右侧的概念重要性图

![0195d6ee-5e8d-7e59-bdaf-525eddd2b72d_26_315_1216_1167_280_0.jpg](images/0195d6ee-5e8d-7e59-bdaf-525eddd2b72d_26_315_1216_1167_280_0.jpg)

Figure 10: Qualitative Examples of our vision-language-mutual concepts

图10:我们的视觉 - 语言共同概念的定性示例

However, it is worth noting that this work only studies the joint feature space and using fine-grained datasets such as CUB [62] in which CLIP is shown to perform poorly. For example, the best CLIP model (ViT-L/14@336px) achieves a 49.5% zero-shot accuracy on the Birdsnap dataset [4], a fine-grained dataset for bird classification. Hence, this conclusion cannot be extrapolated to other datasets such as ImageNet, a general coarse-grained dataset encompassing a diverse set of 1000 objects from the real-world. Moreover, since this work is based on Concept Bottleneck Models, it inherits the same problems discussed in Section D.1. Finally, this study measures how well can CLIP dissect concepts from the joint feature space directly when explicitly trained to do so, while we study the degree of shared knowledge between the vision and language models which eventually leads to the alignment in the joint feature space.

然而，值得注意的是，这项工作仅研究了联合特征空间，并使用了诸如CUB [62]这样的细粒度数据集，在这些数据集中CLIP的表现不佳。例如，最佳的CLIP模型(ViT - L/14@336px)在鸟类分类的细粒度数据集Birdsnap [4]上的零样本准确率为49.5%。因此，这一结论不能推广到其他数据集，如图像网(ImageNet)，这是一个包含来自现实世界的1000种不同对象的通用粗粒度数据集。此外，由于这项工作基于概念瓶颈模型，它继承了D.1节中讨论的相同问题。最后，这项研究衡量了CLIP在明确训练以从联合特征空间中剖析概念时的效果，而我们研究的是视觉和语言模型之间的共享知识程度，最终导致在联合特征空间中的对齐。

## K Additional Implementation Details

## K 额外的实现细节

In section 3.1, we set $k = {500}$ and $\tau  = 1$ . For analyzing the mutual information and its dynamics in Section 4.1 in the main paper, we set the number of concepts $L = 5$ and consider the top 3 textual concepts for each visual concept. This results in a maximum of $5 \times  3 = {15}$ textual concepts in the vision encoder, which are used for analyzing the MI dynamics. All baselines use also 5 concepts. For the CRF, we use the implementation from [29] and leave all parameters as their default settings. The original OpenAI CLIP models are provided from https://github.com/openai/CLIP.

在3.1节中，我们设置了$k = {500}$和$\tau  = 1$。为了分析主论文4.1节中的互信息及其动态变化，我们将概念数量设置为$L = 5$，并为每个视觉概念考虑前3个文本概念。这导致视觉编码器中最多有$5 \times  3 = {15}$个文本概念，用于分析互信息(MI)动态。所有基线方法也使用5个概念。对于条件随机场(CRF)，我们使用文献[29]中的实现，并将所有参数保留为默认设置。原始的OpenAI CLIP模型可从https://github.com/openai/CLIP获取。

For the application of CLIP zero-shot image classification with descriptors used in evaluating the effectiveness of our multimodal explanations, we use the prompt from [47]: how can you identify a <class label>. Distinctive and physical features describing it is <descriptor> for both the baseline methods $\left\lbrack  {{36},{43}}\right\rbrack$ and our method. This prompt has shown strong performance when class labels are paired with descriptors.

在使用描述符进行CLIP零样本图像分类的应用中(用于评估我们的多模态解释的有效性)，我们使用文献[47]中的提示:你如何识别一个<类别标签>。对于基线方法$\left\lbrack  {{36},{43}}\right\rbrack$和我们的方法，描述它的独特物理特征是<描述符>。当类别标签与描述符配对时，这个提示表现出了很强的性能。

All experiments are ran on a single NVIDIA RTX3090 GPU. Experiments on the full ImageNet validation set require around 10-11 hours for base ViT models and 20 hours for large ViT models.

所有实验均在单张NVIDIA RTX3090 GPU上运行。在完整的ImageNet验证集上进行实验，基础ViT模型大约需要10 - 11小时，大型ViT模型需要20小时。

## L Language Encoder Prompts for Classifiers and Descriptors

## L 用于分类器和描述符的语言编码器提示

The prompts we use for the language encoder for constructing the zero-shot classifiers are shown in Table 8 and are averaged for each textual representation of the class [CLASS].

我们用于构建零样本分类器的语言编码器提示如表8所示，并对类别[CLASS]的每个文本表示进行平均。

Table 8: Prompt templates for ImageNet, Places365, and Food101 datasets.

表8:ImageNet、Places365和Food101数据集的提示模板。

<table><tr><td>Dataset</td><td>Prompt Templates</td></tr><tr><td>ImageNet</td><td>itap of a [CLASS]. a bad photo of the [CLASS]. a origami [CLASS]. a photo of the large [CLASS]. a [CLASS] in a video game. art of the [CLASS]. a photo of the small [CLASS]. a photo of a [CLASS].</td></tr><tr><td>Places365</td><td>a photo taken in an [CLASS]. a photo of a [CLASS]. a scene taken in a [CLASS].</td></tr><tr><td>Food101</td><td>a photo of [CLASS], a type of food.</td></tr></table>

<table><tbody><tr><td>数据集</td><td>提示模板</td></tr><tr><td>图像网(ImageNet)</td><td>一张[类别]的抓拍照片。一张[类别]的糟糕照片。一个折纸[类别]。一张大型[类别]的照片。电子游戏里的一个[类别]。[类别]的艺术作品。一张小型[类别]的照片。一张[类别]的照片。</td></tr><tr><td>场景365(Places365)</td><td>在一个[类别]中拍摄的照片。一张[类别]的照片。在一个[类别]中拍摄的场景。</td></tr><tr><td>食物101(Food101)</td><td>一张[类别](一种食物)的照片。</td></tr></tbody></table>

The prompt we use for the language encoder for constructing the descriptors classifier is: a photo showing [DES], where [DES] represents the descriptor.

我们用于构建描述符分类器的语言编码器的提示语是:一张展示[DES]的照片，其中[DES]代表描述符。