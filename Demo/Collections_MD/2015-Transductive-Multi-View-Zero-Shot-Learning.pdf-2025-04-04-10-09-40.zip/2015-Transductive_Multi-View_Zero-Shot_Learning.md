# Transductive Multi-View Zero-Shot Learning

# 直推式多视图零样本学习

Yanwei Fu, Timothy M. Hospedales, Member, IEEE, Tao Xiang, and Shaogang Gong

傅彦伟，蒂莫西·M·霍斯佩代尔斯(IEEE会员)，向涛，龚少刚

Abstract-Most existing zero-shot learning approaches exploit transfer learning via an intermediate semantic representation shared between an annotated auxiliary dataset and a target dataset with different classes and no annotation. A projection from a low-level feature space to the semantic representation space is learned from the auxiliary dataset and applied without adaptation to the target dataset. In this paper we identify two inherent limitations with these approaches. First, due to having disjoint and potentially unrelated classes, the projection functions learned from the auxiliary dataset/domain are biased when applied directly to the target dataset/ domain. We call this problem the projection domain shift problem and propose a novel framework, transductive multi-view embedding, to solve it. The second limitation is the prototype sparsity problem which refers to the fact that for each target class, only a single prototype is available for zero-shot learning given a semantic representation. To overcome this problem, a novel heterogeneous multi-view hypergraph label propagation method is formulated for zero-shot learning in the transductive embedding space. It effectively exploits the complementary information offered by different semantic representations and takes advantage of the manifold structures of multiple representation spaces in a coherent manner. We demonstrate through extensive experiments that the proposed approach (1) rectifies the projection shift between the auxiliary and target domains, (2) exploits the complementarity of multiple semantic representations, (3) significantly outperforms existing methods for both zero-shot and N-shot recognition on three image and video benchmark datasets, and (4) enables novel cross-view annotation tasks.

摘要——现有的大多数零样本学习方法通过在带注释的辅助数据集和具有不同类别且无注释的目标数据集之间共享的中间语义表示来利用迁移学习。从辅助数据集学习从低级特征空间到语义表示空间的投影，并在不进行调整的情况下应用于目标数据集。在本文中，我们指出了这些方法存在的两个内在局限性。首先，由于类别不相交且可能不相关，从辅助数据集/领域学习到的投影函数在直接应用于目标数据集/领域时会产生偏差。我们将这个问题称为投影领域偏移问题，并提出了一种新颖的框架——直推式多视图嵌入来解决该问题。第二个局限性是原型稀疏问题，即对于每个目标类别，在给定语义表示的情况下，零样本学习仅能获得单个原型。为克服这个问题，我们在直推式嵌入空间中为零样本学习制定了一种新颖的异构多视图超图标签传播方法。该方法有效地利用了不同语义表示提供的互补信息，并以连贯的方式利用了多个表示空间的流形结构。我们通过大量实验证明，所提出的方法(1)纠正了辅助领域和目标领域之间的投影偏移；(2)利用了多种语义表示的互补性；(3)在三个图像和视频基准数据集上，在零样本和N样本识别方面显著优于现有方法；(4)实现了新颖的跨视图注释任务。

Index Terms-Transducitve learning, multi-view Learning, transfer Learning, zero-shot Learning, heterogeneous hypergraph

索引术语——直推式学习，多视图学习，迁移学习，零样本学习，异构超图

## 1 INTRODUCTION

## 1 引言

HUMANS can distinguish 30,000 basic object classes [3] and many more subordinate ones (e.g. breeds of dogs). They can also create new categories dynamically from few examples or solely based on high-level description. In contrast, most existing computer vision techniques require hundreds of labelled samples for each object class in order to learn a recognition model. Inspired by humans' ability to recognise without seeing samples, and motivated by the prohibitive cost of training sample collection and annotation, the research area of learning to learn or lifelong learning [6], [35] has received increasing interests. These studies aim to intelligently apply previously learned knowledge to help future recognition tasks. In particular, a major and topical challenge in this area is to build recognition models capable of recognising novel visual categories without labelled training samples, i.e. zero-shot learning (ZSL).

人类能够区分30000种基本物体类别[3]以及更多的从属类别(例如狗的品种)。他们还可以根据少量示例或仅基于高级描述动态创建新的类别。相比之下，现有的大多数计算机视觉技术为了学习识别模型，每个物体类别都需要数百个带标签的样本。受人类无需看到样本就能识别的能力启发，并且由于训练样本收集和注释的成本过高，元学习或终身学习领域[6]、[35]受到了越来越多的关注。这些研究旨在智能地应用先前学到的知识来帮助未来的识别任务。特别是，该领域的一个主要且热门的挑战是构建能够在没有带标签的训练样本的情况下识别新颖视觉类别的识别模型，即零样本学习(ZSL)。

The key idea underpinning ZSL approaches is to exploit knowledge transfer via an intermediate-level semantic representation. Common semantic representations include binary vectors of visual attributes [15], [27], [31] (e.g. 'hasTail' in Fig. 1) and continuous word vectors [11], [32], [44] encoding linguistic context. In ZSL, two datasets with disjoint classes are considered: a labelled auxiliary set where a semantic representation is given for each data point, and a target dataset to be classified without any labelled samples. The semantic representation is assumed to be shared between the auxiliary/source and target/test dataset. It can thus be re-used for knowledge transfer between the source and target sets: a projection function mapping low-level features to the semantic representation is learned from the auxiliary data by classifier or regressor. This projection is then applied to map each unlabelled target class instance into the same semantic space. In this space, a 'prototype' of each target class is specified, and each projected target instance is classified by measuring similarity to the class prototypes. Depending on the semantic space, the class prototype could be a binary attribute vector listing class properties (e.g., 'hasTail') [27] or a word vector describing the linguistic context of the textual class name [11].

零样本学习方法的关键思想是通过中级语义表示来利用知识迁移。常见的语义表示包括视觉属性的二进制向量[15]、[27]、[31](例如图1中的“有尾巴”)和编码语言上下文的连续词向量[11]、[32]、[44]。在零样本学习中，考虑两个类别不相交的数据集:一个是带标签的辅助集，其中每个数据点都有一个语义表示；另一个是待分类的目标数据集，没有任何带标签的样本。假设语义表示在辅助/源数据集和目标/测试数据集之间是共享的。因此，它可以用于源数据集和目标数据集之间的知识迁移:通过分类器或回归器从辅助数据中学习将低级特征映射到语义表示的投影函数。然后应用该投影将每个未标记的目标类实例映射到相同的语义空间。在这个空间中，指定每个目标类的一个“原型”，并通过测量与类原型的相似度对每个投影后的目标实例进行分类。根据语义空间的不同，类原型可以是列出类属性(例如“有尾巴”)的二进制属性向量[27]，也可以是描述文本类名称语言上下文的词向量[11]。

Two inherent problems exist in this conventional zero-shot learning approach. The first problem is the projection domain shift problem. Since the two datasets have different and potentially unrelated classes, the underlying data distributions of the classes differ, so do the 'ideal' projection functions between the low-level feature space and the semantic spaces. Therefore, using the projection functions learned from the auxiliary dataset/domain without any adaptation to the target dataset/domain causes an unknown shift/bias. We call it the projection domain shift problem. This is illustrated in Fig. 1, which shows two object classes from the animals with attributes (AwA) dataset [28]: Zebra is one of the 40 auxiliary classes while Pig is one of 10 target classes. Both of them share the same 'hasTail' semantic attribute, but the visual appearance of their tails differs greatly (Fig. 1a). Similarly, many other attributes of Pig are visually different from the corresponding attributes in the auxiliary classes. Fig. 1b illustrates the projection domain See http://www.ieee.org/publications_standards/publications/rights/index.html for more information. shift problem by plotting (in 2D using t-SNE [47]) an 85D attribute space representation of the image feature projections and class prototypes (85D binary attribute vectors). A large discrepancy can be seen between the Pig prototype in the semantic attribute space and the projections of its class member instances, but not for the auxiliary Zebra class. This discrepancy is caused when the projections learned from the 40 auxiliary classes are applied directly to project the Pig instances-what 'hasTail' (as well as the other 84 attributes) visually means is different now. Such a discrepancy will inherently degrade the effectiveness of zero-shot recognition of the Pig class because the target class instances are classified according to their similarities/distances to those prototypes. To our knowledge, this problem has neither been identified nor addressed in the zero-shot learning literature.

这种传统的零样本学习方法存在两个内在问题。第一个问题是投影域偏移问题。由于两个数据集具有不同且可能不相关的类别，这些类别的底层数据分布不同，低级特征空间和语义空间之间的“理想”投影函数也不同。因此，使用从辅助数据集/域中学到的投影函数，而不对目标数据集/域进行任何调整，会导致未知的偏移/偏差。我们将其称为投影域偏移问题。图1对此进行了说明，该图展示了来自动物属性数据集(Animals with Attributes，AwA)[28]的两个对象类别:斑马是40个辅助类别之一，而猪是10个目标类别之一。它们都具有相同的“有尾巴”语义属性，但它们尾巴的视觉外观差异很大(图1a)。同样，猪的许多其他属性在视觉上也与辅助类别中的相应属性不同。图1b通过绘制(使用t - SNE [47]进行二维绘制)图像特征投影和类别原型(85维二进制属性向量)的85维属性空间表示，说明了投影域偏移问题。可以看到，语义属性空间中的猪原型与其类别成员实例的投影之间存在很大差异，但辅助类别斑马则不存在这种情况。当从40个辅助类别中学到的投影直接应用于投影猪的实例时，就会出现这种差异——现在“有尾巴”(以及其他84个属性)在视觉上的含义不同了。这种差异本质上会降低猪类别的零样本识别效果，因为目标类别实例是根据它们与那些原型的相似度/距离进行分类的。据我们所知，这个问题在零样本学习文献中既未被识别也未得到解决。

---

- Y. Fu is with the Disney Research, Pittsburgh, PA 15213.

- 傅宇(Y. Fu)就职于匹兹堡迪士尼研究院，宾夕法尼亚州匹兹堡市，邮编15213。

E-mail: y.fu@qmul.ac.uk.

电子邮件:y.fu@qmul.ac.uk。

- T.M. Hospedales, T. Xiang, and S. Gong are with the School of Electronic Engineering and Computer Science, Queen Mary University of London E1 4NS, United Kingdom.

- T.M. 霍斯佩代尔斯(T.M. Hospedales)、向涛(T. Xiang)和龚少刚(S. Gong)就职于英国伦敦玛丽女王大学电子工程与计算机科学学院，邮编E1 4NS。

E-mail: \{t.hospedales, t.xiang, s.gong\}@qmul.ac.uk.

电子邮件:{t.hospedales, t.xiang, s.gong}@qmul.ac.uk。

reprints@ieee.org, and reference the Digital Object Identifier below.

请发送至reprints@ieee.org，并参考下面的数字对象标识符。

---

![0195e08a-2f2a-7034-a202-61776690cc02_1_86_125_739_367_0.jpg](images/0195e08a-2f2a-7034-a202-61776690cc02_1_86_125_739_367_0.jpg)

Fig. 1. An illustration of the projection domain shift problem. Zero-shot prototypes are shown as red stars and predicted semantic attribute projections (defined in Section 3.2) shown in blue.

图1. 投影域偏移问题的示意图。零样本原型用红色星星表示，预测的语义属性投影(在3.2节中定义)用蓝色表示。

The second problem is the prototype sparsity problem: for each target class, we only have a single prototype which is insufficient to fully represent what that class looks like. As shown in Figs. 6b and 6c, there often exist large intra-class variations and inter-class similarities. Consequently, even if the single prototype is centred among its class instances in the semantic representation space, existing zero-shot classifiers will still struggle to assign correct class labels-one prototype per class is not enough to represent the intra-class variability or help disambiguate class overlap [39].

第二个问题是原型稀疏问题:对于每个目标类别，我们只有一个原型，这不足以完全表示该类别看起来是什么样的。如图6b和图6c所示，通常存在较大的类内差异和类间相似性。因此，即使单个原型在语义表示空间中位于其类别实例的中心，现有的零样本分类器仍然难以分配正确的类别标签——每个类别一个原型不足以表示类内变异性，也无助于消除类别重叠的歧义[39]。

In addition to these two problems, conventional approaches to zero-shot learning are also limited in exploiting multiple intermediate semantic representations. Each representation (or semantic 'view') may contain complementary information-useful for distinguishing different classes in different ways. While both visual attributes [9], [15], [27], [31] and linguistic semantic representations such as word vectors [11], [32], [44] have been independently exploited successfully, it remains unattempted and non-trivial to synergistically exploit multiple semantic views. This is because they are often of very different dimensions and types and each suffers from different domain shift effects discussed above.

除了这两个问题之外，传统的零样本学习方法在利用多个中间语义表示方面也存在局限性。每个表示(或语义“视图”)可能包含互补信息，这些信息以不同的方式有助于区分不同的类别。虽然视觉属性[9]、[15]、[27]、[31]和语言语义表示(如词向量[11]、[32]、[44])都已被独立地成功利用，但协同利用多个语义视图仍未被尝试过，而且并非易事。这是因为它们的维度和类型通常非常不同，并且每个都受到上述不同的域偏移效应的影响。

In this paper, we propose to solve the projection domain shift problem using transductive multi-view embedding. The transductive setting means using the unlabelled test data to improve generalisation accuracy. In our framework, each unlabelled target class instance is represented by multiple views: its low-level feature view and its (biased) projections in multiple semantic spaces (visual attribute space and word space in this work). To rectify the projection domain shift between auxiliary and target datasets, we introduce a multi-view semantic space alignment process to Authorized licensed use limited to: JILIN UNIVERSITY. Downloaded on March 29,2025 at 06:13:38 UTC from IEEE Xplore. Restrictions apply. correlate different semantic views and the low-level feature view by projecting them onto a common latent embedding space learned using multi-view canonical correlation analysis (CCA) [17]. The intuition is that when the biased target data projections (semantic representations) are correlated/ aligned with their (unbiased) low-level feature representations, the bias/projection domain shift is alleviated. The effects of this process on projection domain shift are illustrated by Fig. 1c, where after alignment, the target Pig class prototype is much closer to its member points in this embedding space. Furthermore, after exploiting the complementarity of different low-level feature and semantic views synergistically in the common embedding space, different target classes become more compact and more separable (see Fig. 6d for an example), making the subsequent zero-shot recognition a much easier task.

在本文中，我们提议使用直推式多视图嵌入来解决投影域偏移问题。直推式设置意味着利用未标记的测试数据来提高泛化准确率。在我们的框架中，每个未标记的目标类实例由多个视图表示:其低级特征视图以及它在多个语义空间(在本工作中为视觉属性空间和词空间)中的(有偏差的)投影。为了纠正辅助数据集和目标数据集之间的投影域偏移，我们引入了一个多视图语义空间对齐过程，将不同的语义视图和低级特征视图投影到一个使用多视图典型相关分析(CCA)[17]学习得到的公共潜在嵌入空间，从而使它们相互关联。授权许可使用仅限于:吉林大学。于2025年3月29日06:13:38 UTC从IEEE Xplore下载。适用限制。其直觉是，当有偏差的目标数据投影(语义表示)与其(无偏差的)低级特征表示相关/对齐时，偏差/投影域偏移就会得到缓解。图1c展示了这一过程对投影域偏移的影响，在对齐之后，目标“猪”类原型在这个嵌入空间中与其成员点的距离更近了。此外，在公共嵌入空间中协同利用不同低级特征和语义视图的互补性之后，不同的目标类变得更加紧凑且更易分离(例如见图6d)，这使得后续的零样本识别任务变得容易得多。

Even with the proposed transductive multi-view embedding framework, the prototype sparsity problem remains-instead of one prototype per class, a handful are now available depending on how many views are embedded, which are still sparse. Our solution is to pose this as a semi-supervised learning [57] problem: prototypes in each view are treated as labelled 'instances', and we exploit the manifold structure of the unlabelled data distribution in each view in the embedding space via label propagation on a graph. To this end, we introduce a novel transductive multi-view hypergraph label propagation (TMV-HLP) algorithm for recognition. The core in our TMV-HLP algorithm is a new distributed representation of graph structure termed heterogeneous hypergraph which allows us to exploit the complementarity of different semantic and low-level feature views, as well as the manifold structure of the target data to compensate for the impoverished supervision available from the sparse prototypes. Zero-shot learning is then performed by semi-supervised label propagation from the prototypes to the target data points within and across the graphs. The whole framework is illustrated in Fig. 2.

即使采用了所提出的直推式多视图嵌入框架，原型稀疏问题仍然存在——现在每个类不是只有一个原型，而是根据嵌入的视图数量有少量可用的原型，但仍然很稀疏。我们的解决方案是将其视为一个半监督学习[57]问题:将每个视图中的原型视为有标记的“实例”，并通过图上的标签传播来利用嵌入空间中每个视图里未标记数据分布的流形结构。为此，我们引入了一种新颖的直推式多视图超图标签传播(TMV - HLP)算法用于识别。我们的TMV - HLP算法的核心是一种称为异构超图的图结构的新分布式表示，它使我们能够利用不同语义和低级特征视图的互补性，以及目标数据的流形结构，以弥补稀疏原型所提供的有限监督。然后通过半监督标签传播，在图内和图间从原型向目标数据点进行零样本学习。整个框架如图2所示。

By combining our transductive embedding framework and the TMV-HLP zero-shot recognition algorithm, our approach generalises seamlessly when none (zero-shot), or few (N-shot) samples of the target classes are available. Uniquely it can also synergistically exploit zero + N-shot (i.e., both prototypes and labelled samples) learning. Furthermore, the proposed method enables a number of novel cross-view annotation tasks including zero-shot class description and zero prototype learning.

通过结合我们的直推式嵌入框架和TMV - HLP零样本识别算法，我们的方法在目标类没有(零样本)或只有少量(N样本)样本可用时能够无缝泛化。独特的是，它还可以协同利用零样本 + N样本(即原型和有标记样本)学习。此外，所提出的方法还支持一些新颖的跨视图标注任务，包括零样本类描述和零原型学习。

Our contributions. Our contributions are as follows: (1) To our knowledge, this is the first attempt to investigate and provide a solution to the projection domain shift problem in zero-shot learning. (2) We propose a transductive multiview embedding space that not only rectifies the projection shift, but also exploits the complementarity of multiple semantic representations of visual data. (3) A novel trans-ductive multi-view heterogeneous hypergraph label propagation algorithm is developed to improve both zero-shot and N-shot learning tasks in the embedding space and overcome the prototype sparsity problem. (4) The learned embedding space enables a number of novel cross-view annotation tasks. Extensive experiments are carried out and the results show that our approach significantly outperforms existing methods for both zero-shot and N-shot recognition on three image and video benchmark datasets.

我们的贡献。我们的贡献如下:(1)据我们所知，这是首次尝试研究并解决零样本学习中的投影域偏移问题。(2)我们提出了一种直推式多视图嵌入空间，它不仅可以纠正投影偏移，还能利用视觉数据的多种语义表示的互补性。(3)开发了一种新颖的直推式多视图异构超图标签传播算法，以改进嵌入空间中的零样本和N样本学习任务，并克服原型稀疏问题。(4)所学习的嵌入空间支持一些新颖的跨视图标注任务。我们进行了大量实验，结果表明，在三个图像和视频基准数据集上，我们的方法在零样本和N样本识别方面明显优于现有方法。

![0195e08a-2f2a-7034-a202-61776690cc02_2_112_131_1476_566_0.jpg](images/0195e08a-2f2a-7034-a202-61776690cc02_2_112_131_1476_566_0.jpg)

Fig. 2. The pipeline of our framework illustrated on the task of classifying unlabelled target data into two classes.

图2. 我们的框架在将未标记的目标数据分类为两类任务上的流程示意图。

## 2 RELATED WORK

## 2 相关工作

Semantic spaces for zero-shot learning. To address zero-shot learning, attribute-based semantic representations have been explored for images [9], [27] and to a lesser extent videos [15], [31]. Most existing studies [1], [24], [27], [33], [34], [41], [54] assume that an exhaustive ontology of attributes has been manually specified at either the class or instance level. However, annotating attributes scales poorly as ontologies tend to be domain specific. This is despite efforts exploring augmented data-driven/latent attributes at the expense of name-ability [9], [15], [31]. To address this, semantic representations using existing ontologies and incidental data have been proposed [37], [38]. Recently, word vector approaches based on distributed language representations have gained popularity. In this case a word space is extracted from linguistic knowledge bases e.g., Wikipedia by natural language processing models such as [4], [32]. The language model is then used to project each class' textual name into this space. These projections can be used as prototypes for zero-shot learning [11], [44]. Importantly, regardless of the semantic spaces used, existing methods focus on either designing better semantic spaces or how to best learn the projections. The former is orthogonal to our work-any semantic spaces can be used in our framework and better ones would benefit our model. For the latter, no existing work has identified or addressed the projection domain shift problem.

用于零样本学习的语义空间。为了解决零样本学习问题，基于属性的语义表示已被用于图像研究[9]、[27]，在较小程度上也用于视频研究[15]、[31]。大多数现有研究[1]、[24]、[27]、[33]、[34]、[41]、[54]假设已在类别或实例层面手动指定了详尽的属性本体。然而，随着本体往往具有领域特定性，对属性进行标注的扩展性较差。尽管有研究探索了以可命名性为代价的增强型数据驱动/潜在属性[9]、[15]、[31]。为了解决这个问题，有人提出了使用现有本体和附带数据的语义表示方法[37]、[38]。最近，基于分布式语言表示的词向量方法受到了广泛关注。在这种情况下，通过自然语言处理模型(如[4]、[32])从语言知识库(如维基百科)中提取词空间。然后使用语言模型将每个类别的文本名称投影到这个空间中。这些投影可以用作零样本学习的原型[11]、[44]。重要的是，无论使用何种语义空间，现有方法要么专注于设计更好的语义空间，要么专注于如何最好地学习投影。前者与我们的工作无关——任何语义空间都可以在我们的框架中使用，更好的语义空间将使我们的模型受益。对于后者，目前还没有现有工作识别或解决投影领域偏移问题。

Transductive zero-shot learning was considered by Fu et al. [13], [15] who introduced a generative model to for user-defined and latent attributes. A simple transductive zero-shot learning algorithm is proposed: averaging the prototype's k-nearest neighbours (KNN) to exploit the test data attribute distribution. Rohrbach et al. [36] proposed a more elaborate transductive strategy, using graph-based label propagation to exploit the manifold structure of the test data. These studies effectively transform the ZSL task into a transductive semi-supervised learning task [57] with Authorized licensed use limited to: JILIN UNIVERSITY. Downloaded on March 29,2025 at 06:13:38 UTC from IEEE Xplore. Restrictions apply. prototypes providing the few labelled instances. Nevertheless, these studies and this paper (as with most previous work [27], [28], [37]) only consider recognition among the novel classes: unifying zero-shot with supervised learning remains an open challenge [44].

傅等人[13]、[15]考虑了直推式零样本学习，他们引入了一个生成模型来处理用户定义和潜在属性。提出了一种简单的直推式零样本学习算法:对原型的k近邻(KNN)进行平均，以利用测试数据的属性分布。罗尔巴赫等人[36]提出了一种更精细的直推式策略，使用基于图的标签传播来利用测试数据的流形结构。这些研究有效地将零样本学习(ZSL)任务转化为直推式半监督学习任务[57]，授权许可使用仅限于:吉林大学。于2025年3月29日06:13:38 UTC从IEEE Xplore下载。适用限制。原型提供了少量有标签的实例。然而，这些研究和本文(与大多数先前的工作[27]、[28]、[37]一样)只考虑了新类别之间的识别:将零样本学习与监督学习统一起来仍然是一个未解决的挑战[44]。

Domain adaptation. Domain adaptation methods attempt to address the domain shift problems that occur when the assumption that the source and target instances are drawn from the same distribution is violated. Methods have been derived for both classification [8], [10] and regression [45], and both with [8] and without [10] requiring label information in the target task. Our zero-shot learning problem means that most of supervised domain adaptation methods are inapplicable. Our projection domain shift problem differs from the conventional domain shift problems in that (i) it is indirectly observed in terms of the projection shift rather than the feature distribution shift, and (ii) the source domain classes and target domain classes are completely different and could even be unrelated. Consequently our domain adaptation method differs significantly from the existing unsupervised ones such as [10] in that our method relies on correlating different representations of the unlabelled target data in a multi-view embedding space.

领域自适应。领域自适应方法试图解决当源实例和目标实例来自同一分布的假设被违反时出现的领域偏移问题。已经为分类[8]、[10]和回归[45]推导了相关方法，并且这些方法有的需要目标任务中的标签信息[8]，有的则不需要[10]。我们的零样本学习问题意味着大多数监督式领域自适应方法都不适用。我们的投影领域偏移问题与传统的领域偏移问题不同，因为(i)它是通过投影偏移而不是特征分布偏移间接观察到的，(ii)源领域类别和目标领域类别完全不同，甚至可能无关。因此，我们的领域自适应方法与现有的无监督方法(如[10])有很大不同，因为我们的方法依赖于在多视图嵌入空间中关联未标记目标数据的不同表示。

Learning multi-view embedding spaces. Relating low-level feature and semantic views of data has been exploited in visual recognition and cross-modal retrieval. Most existing work [17], [23], [43], [51] focuses on modelling images/videos with associated text (e.g. tags on Flickr/YouTube). Multi-view CCA is often exploited to provide unsupervised fusion of different modalities. However, there are two fundamental differences between previous multi-view embedding work and ours: (1) Our embedding space is transductive, that is, learned from unlabelled target data from which all semantic views are estimated by projection rather than being the original views. These projected views thus have the projection domain shift problem that the previous work does not have. (2) The objectives are different: we aim to rectify the projection domain shift problem via the embedding in order to perform better recognition and annotation while previous studies target primarily cross-modal retrieval. Note that although in this work, the popular CCA model is adopted for multi-view embedding, other models [40], [49] could also be considered.

学习多视图嵌入空间。在视觉识别和跨模态检索中，已经利用了数据的低级特征视图和语义视图之间的关联。大多数现有工作[17]、[23]、[43]、[51]专注于对带有相关文本(如Flickr/YouTube上的标签)的图像/视频进行建模。多视图典型相关分析(CCA)经常被用于提供不同模态的无监督融合。然而，先前的多视图嵌入工作与我们的工作有两个根本区别:(1)我们的嵌入空间是直推式的，即从未标记的目标数据中学习，所有语义视图都是通过投影估计得到的，而不是原始视图。因此，这些投影视图存在先前工作所没有的投影领域偏移问题。(2)目标不同:我们的目标是通过嵌入来纠正投影领域偏移问题，以实现更好的识别和标注，而先前的研究主要针对跨模态检索。需要注意的是，虽然在这项工作中采用了流行的CCA模型进行多视图嵌入，但也可以考虑其他模型[40]、[49]。

Graph-based label propagation. In most previous zero-shot learning studies (e.g., direct attribute prediction (DAP) [28]), the available knowledge (a single prototype per target class) is very limited. There has therefore been recent interest in additionally exploiting the unlabelled target data distribution by transductive learning [15], [36]. However, both [36] and [15] suffer from the projection domain shift problem, and are unable to effectively exploit multiple semantic representations/views. In contrast, after embedding, our framework synergistically integrates the low-level feature and semantic representations by transductive multi-view hypergraph label propagation. Moreover, TMV-HLP gener-alises beyond zero-shot to N-shot learning if labelled instances are available for the target classes.

基于图的标签传播。在大多数先前的零样本学习研究中(例如，直接属性预测(DAP)[28])，可用的知识(每个目标类别一个单一原型)非常有限。因此，最近人们对通过直推式学习[15]、[36]额外利用未标记的目标数据分布产生了兴趣。然而，文献[36]和[15]都存在投影域偏移问题，并且无法有效利用多种语义表示/视图。相比之下，在嵌入之后，我们的框架通过直推式多视图超图标签传播协同集成了低级特征和语义表示。此外，如果目标类别有标记实例可用，直推式多视图超图标签传播(TMV - HLP)可以从零样本学习推广到N样本学习。

In a broader context, graph-based label propagation [55] in general, and classification on multi-view graphs (C-MG) in particular are well-studied in semi-supervised learning. Most C-MG solutions are based on the seminal work of Zhou et al. [56] which generalises spectral clustering from a single graph to multiple graphs by defining a mixture of random walks on multiple graphs. In the embedding space, instead of constructing local neighbourhood graphs for each view independently (e.g. TMV-BLP [14]), this paper proposes a distributed representation of pairwise similarity using heterogeneous hypergraphs. Such a distributed heterogeneous hypergraph representation can better explore the higher-order relations between any two nodes of different complementary views, and thus give rise to a more robust pairwise similarity graph and lead to better classification performance than previous multi-view graph methods [14], [56]. Hypergraphs have been used as an effective tool to align multiple data/feature modalities in data mining [29], multimedia [12] and computer vision [19], [30] applications. A hypergraph is the generalisation of a 2-graph with edges connecting many nodes/vertices, versus connecting two nodes in conventional 2-graphs. This makes it cope better with noisy nodes and thus achieve better performance than conventional graphs [12], [21], [22]. The only existing work considering hypergraphs for multi-view data modelling is [19]. Different from the multi-view hypergraphs proposed in [19] which are homogeneous, that is, constructed in each view independently, we construct a multi-view heterogeneous hypergraph: using the nodes from one view as query nodes to compute hyperedges in another view. This novel graph structure better exploits the complementarity of different views in the common embedding space.

从更广泛的背景来看，基于图的标签传播[55]，特别是多视图图分类(C - MG)，在半监督学习中得到了深入研究。大多数C - MG解决方案基于周等人[56]的开创性工作，该工作通过定义多个图上的随机游走混合，将谱聚类从单个图推广到多个图。在嵌入空间中，本文没有为每个视图独立构建局部邻域图(例如TMV - BLP [14])，而是提出了一种使用异构超图的成对相似性分布式表示。这种分布式异构超图表示可以更好地探索不同互补视图的任意两个节点之间的高阶关系，因此与先前的多视图图方法[14]、[56]相比，能够产生更稳健的成对相似性图，并带来更好的分类性能。超图已被用作数据挖掘[29]、多媒体[12]和计算机视觉[19]、[30]应用中对齐多种数据/特征模态的有效工具。超图是2 - 图的推广，其边可以连接多个节点/顶点，而传统的2 - 图的边只连接两个节点。这使得超图能够更好地处理噪声节点，因此比传统图[12]、[21]、[22]具有更好的性能。目前唯一考虑使用超图进行多视图数据建模的工作是文献[19]。与文献[19]中提出的同构多视图超图(即在每个视图中独立构建)不同，我们构建了一个多视图异构超图:使用一个视图中的节点作为查询节点来计算另一个视图中的超边。这种新颖的图结构更好地利用了公共嵌入空间中不同视图的互补性。

## 3 LEARNING A TRANSDUCTIVE MULTI-VIEW EMBEDDING SPACE

## 3 学习直推式多视图嵌入空间

A schematic overview of our framework is given in Fig. 2. We next introduce some notation and assumptions, followed by the details of how to map image features into each semantic space, and how to map multiple spaces into a common embedding space.

图2给出了我们框架的示意图。接下来，我们将介绍一些符号和假设，然后详细说明如何将图像特征映射到每个语义空间，以及如何将多个空间映射到一个公共嵌入空间。

### 3.1 Problem Setup

### 3.1 问题设定

We have ${c}_{S}$ source/auxiliary classes with ${n}_{S}$ instances $S = \left\{  {{X}_{S},{Y}_{S}^{i},{\mathbf{z}}_{S}}\right\}$ and ${c}_{T}$ target classes $T = \left\{  {{X}_{T},{Y}_{T}^{i},{\mathbf{z}}_{T}}\right\}$ Authorized licensed use limited to: JILIN UNIVERSITY. Downloaded on March 29,2025 at 06:13:38 UTC from IEEE Xplore. Restrictions apply. with ${n}_{T}$ instances. ${X}_{S} \in  {\mathbb{R}}^{{n}_{s} \times  t}$ and ${X}_{T} \in  {\mathbb{R}}^{{n}_{T} \times  t}$ denote the $t$ -dimensional low-level feature vectors of auxiliary and target instances respectively. ${\mathbf{z}}_{S}$ and ${\mathbf{z}}_{T}$ are the auxiliary and target class label vectors. We assume the auxiliary and target classes are disjoint: ${\mathbf{z}}_{S} \cap  {\mathbf{z}}_{T} = \varnothing$ . We have $I$ different types of semantic representations; ${Y}_{S}^{i}$ and ${Y}_{T}^{i}$ represent the $i$ -th type of ${m}_{i}$ -dimensional semantic representation for the auxiliary and target datasets respectively; so ${Y}_{S}^{i} \in  {\mathbb{R}}^{{n}_{S} \times  {m}_{i}}$ and ${Y}_{T}^{i} \in  {\mathbb{R}}^{{n}_{T} \times  {m}_{i}}$ . Note that for the auxiliary dataset, ${Y}_{S}^{i}$ is given as each data point is labelled. But for the target dataset, ${Y}_{T}^{i}$ is missing, and its prediction ${\widehat{Y}}_{T}^{i}$ from ${X}_{T}$ is used instead. As we shall see, this is obtained using a projection function learned from the auxiliary dataset. The problem of zero-shot learning is to estimate ${\mathbf{z}}_{T}$ given ${X}_{T}$ and ${\widehat{Y}}_{T}^{i}$ .

我们有 ${c}_{S}$ 个源/辅助类别，包含 ${n}_{S}$ 个实例 $S = \left\{  {{X}_{S},{Y}_{S}^{i},{\mathbf{z}}_{S}}\right\}$，以及 ${c}_{T}$ 个目标类别 $T = \left\{  {{X}_{T},{Y}_{T}^{i},{\mathbf{z}}_{T}}\right\}$ 授权许可使用仅限于:吉林大学。于2025年3月29日协调世界时06:13:38从IEEE Xplore下载。适用限制条款。包含 ${n}_{T}$ 个实例。${X}_{S} \in  {\mathbb{R}}^{{n}_{s} \times  t}$ 和 ${X}_{T} \in  {\mathbb{R}}^{{n}_{T} \times  t}$ 分别表示辅助实例和目标实例的 $t$ 维低级特征向量。${\mathbf{z}}_{S}$ 和 ${\mathbf{z}}_{T}$ 分别是辅助类别和目标类别的标签向量。我们假设辅助类别和目标类别是不相交的:${\mathbf{z}}_{S} \cap  {\mathbf{z}}_{T} = \varnothing$ 。我们有 $I$ 种不同类型的语义表示；${Y}_{S}^{i}$ 和 ${Y}_{T}^{i}$ 分别表示辅助数据集和目标数据集的第 $i$ 种 ${m}_{i}$ 维语义表示；因此 ${Y}_{S}^{i} \in  {\mathbb{R}}^{{n}_{S} \times  {m}_{i}}$ 和 ${Y}_{T}^{i} \in  {\mathbb{R}}^{{n}_{T} \times  {m}_{i}}$ 。请注意，对于辅助数据集，由于每个数据点都有标签，所以 ${Y}_{S}^{i}$ 是已知的。但对于目标数据集，${Y}_{T}^{i}$ 是缺失的，而是使用从 ${X}_{T}$ 得到的预测值 ${\widehat{Y}}_{T}^{i}$ 。正如我们将看到的，这是通过使用从辅助数据集学习到的投影函数得到的。零样本学习的问题是在已知 ${X}_{T}$ 和 ${\widehat{Y}}_{T}^{i}$ 的情况下估计 ${\mathbf{z}}_{T}$ 。

Without any labelled data for the target classes, external knowledge is needed to represent what each target class looks like, in the form of class prototypes. Specifically, each target class $c$ has a pre-defined class-level semantic prototype ${\mathbf{y}}_{c}^{i}$ in each semantic view $i$ . In this paper, we consider two types of intermediate semantic representation (i.e. $I = 2$ )-attributes and word vectors, which represent two distinct and complementary sources of information. We use $\mathcal{X},\mathcal{A}$ and $\mathcal{V}$ to denote the low-level feature, attribute and word vector spaces respectively. The attribute space $\mathcal{A}$ is typically manually defined using a standard ontology. For the word vector space $\mathcal{V}$ , we employ the state-of-the-art skip-gram neural network model [32] trained on all English Wikipedia articles. ${}^{1}$ Using this learned model, we can project the textual name of any class into the $\mathcal{V}$ space to get its word vector representation. Unlike semantic attributes, it is a 'free' semantic representation in that this process does not need any human annotation. We next address how to project low-level features into these two spaces.

由于目标类别没有任何带标签的数据，需要外部知识以类别原型的形式来表示每个目标类别是什么样的。具体来说，每个目标类别 $c$ 在每个语义视图 $i$ 中都有一个预定义的类别级语义原型 ${\mathbf{y}}_{c}^{i}$ 。在本文中，我们考虑两种类型的中间语义表示(即 $I = 2$ )——属性和词向量，它们代表了两种不同且互补的信息来源。我们分别使用 $\mathcal{X},\mathcal{A}$ 、$\mathcal{A}$ 和 $\mathcal{V}$ 来表示低级特征空间、属性空间和词向量空间。属性空间 $\mathcal{A}$ 通常是使用标准本体手动定义的。对于词向量空间 $\mathcal{V}$ ，我们采用在所有英文维基百科文章上训练的最先进的跳字(skip-gram)神经网络模型 [32] 。${}^{1}$ 使用这个学习到的模型，我们可以将任何类别的文本名称投影到 $\mathcal{V}$ 空间中，以获得其词向量表示。与语义属性不同，这是一种“免费”的语义表示，因为这个过程不需要任何人工标注。接下来我们将探讨如何将低级特征投影到这两个空间中。

### 3.2 Learning the Projections of Semantic Spaces

### 3.2 学习语义空间的投影

Mapping images and videos into semantic space $i$ requires a projection function ${f}^{i} : \mathcal{X} \rightarrow  {\mathcal{Y}}^{i}$ . This is typically realised by classifier [27] or regressor [44]. In this paper, using the auxiliary set $S$ , we train support vector classifiers ${f}^{\mathcal{A}}\left( \cdot \right)$ and support vector regressors ${f}^{\mathcal{V}}\left( \cdot \right)$ for each dimension ${}^{2}$ of the auxiliary class attribute and word vectors respectively. Then the target class instances ${X}_{T}$ have the semantic projections: ${\widehat{Y}}_{T}^{\mathcal{A}} = {f}^{\mathcal{A}}\left( {X}_{T}\right)$ and ${\widehat{Y}}_{T}^{\mathcal{V}} = {f}^{\mathcal{V}}\left( {X}_{T}\right)$ . However, these predicted intermediate semantics have the projection domain shift problem illustrated in Fig. 1. To address this, we learn a transductive multi-view semantic embedding space to align the semantic projections with the low-level features of target data.

将图像和视频映射到语义空间 $i$ 需要一个投影函数 ${f}^{i} : \mathcal{X} \rightarrow  {\mathcal{Y}}^{i}$。这通常通过分类器 [27] 或回归器 [44] 来实现。在本文中，利用辅助集 $S$，我们分别为辅助类属性和词向量的每个维度 ${}^{2}$ 训练支持向量分类器 ${f}^{\mathcal{A}}\left( \cdot \right)$ 和支持向量回归器 ${f}^{\mathcal{V}}\left( \cdot \right)$。然后，目标类实例 ${X}_{T}$ 具有语义投影:${\widehat{Y}}_{T}^{\mathcal{A}} = {f}^{\mathcal{A}}\left( {X}_{T}\right)$ 和 ${\widehat{Y}}_{T}^{\mathcal{V}} = {f}^{\mathcal{V}}\left( {X}_{T}\right)$。然而，这些预测的中间语义存在图 1 所示的投影域偏移问题。为了解决这个问题，我们学习了一个直推式多视图语义嵌入空间，以使语义投影与目标数据的低级特征对齐。

### 3.3 Transductive Multi-View Embedding

### 3.3 直推式多视图嵌入

We introduce a multi-view semantic alignment (i.e. trans-ductive multi-view embedding) process to correlate target instances in different (biased) semantic view projections with their low-level feature view. This process alleviates the projection domain shift problem, as well as providing a common space in which heterogeneous views can be directly compared, and their complementarity exploited (Section 4). To this end, we employ multi-view canonical correlation analysis for ${n}_{V}$ views, with the target data representation in view $i$ denoted ${\Phi }^{i}$ , a ${n}_{T} \times  {m}_{i}$ matrix. Specifically, we project three views of each target class instance ${f}^{\mathcal{A}}\left( {X}_{T}\right) ,{f}^{\mathcal{V}}\left( {X}_{T}\right)$ and ${X}_{T}$ (i.e. ${n}_{V} = I + 1 = 3$ ) into a shared embedding space. The three projection functions ${W}^{i}$ are learned by

我们引入了一个多视图语义对齐(即直推式多视图嵌入)过程，以将不同(有偏差的)语义视图投影中的目标实例与其低级特征视图关联起来。这个过程缓解了投影域偏移问题，同时提供了一个公共空间，在这个空间中可以直接比较异构视图，并利用它们的互补性(第 4 节)。为此，我们对 ${n}_{V}$ 个视图采用多视图典型相关分析，视图 $i$ 中的目标数据表示记为 ${\Phi }^{i}$，是一个 ${n}_{T} \times  {m}_{i}$ 矩阵。具体来说，我们将每个目标类实例 ${f}^{\mathcal{A}}\left( {X}_{T}\right) ,{f}^{\mathcal{V}}\left( {X}_{T}\right)$ 和 ${X}_{T}$ 的三个视图(即 ${n}_{V} = I + 1 = 3$)投影到一个共享的嵌入空间中。三个投影函数 ${W}^{i}$ 通过以下方式学习

$$
\mathop{\min }\limits_{{\left\{  {\mathrm{W}}^{\mathrm{i}}\right\}  }_{\mathrm{i} = 1}^{{\mathrm{n}}_{\mathrm{V}}}}\mathop{\sum }\limits_{{i, j = 1}}^{{n}_{V}}\;\operatorname{Trace}\left( {{W}^{i}{\sum }_{ij}{W}^{j}}\right)
$$

$$
= \mathop{\sum }\limits_{{i, j = 1}}^{{n}_{V}}\;{\begin{Vmatrix}{\Phi }^{i}{W}^{i} - {\Phi }^{j}{W}^{j}\end{Vmatrix}}_{F}^{2} \tag{1}
$$

$$
\text{s.t.}{\left\lbrack  {W}^{i}\right\rbrack  }^{T}{\sum }_{ii}{W}^{i} = I\;{\left\lbrack  {\mathbf{w}}_{k}^{i}\right\rbrack  }^{T}{\sum }_{ij}{\mathbf{w}}_{l}^{j} = 0
$$

$$
i \neq  j, k \neq  l\;i, j = 1,\ldots ,{n}_{V}\;k, l = 1,\ldots ,{n}_{T},
$$

---

1. To 13 Feb. 2014, it includes 2.9 billion words from a 4.33 million-words vocabulary (single and bi/tri-gram words).

1. 截至 2014 年 2 月 13 日，它包含来自 433 万个单词词汇表(单字词和双/三字词)的 29 亿个单词。

2. Note that methods for learning projection functions for all dimensions jointly exist (e.g. [11]) and can be adopted in our framework.

2. 请注意，存在联合学习所有维度投影函数的方法(例如 [11])，并且可以在我们的框架中采用。

---

where ${W}^{i}$ is the projection matrix which maps the view ${\Phi }^{i}$ $\left( { \in  {\mathbb{R}}^{{n}_{T} \times  {m}_{i}}}\right)$ into the embedding space and ${\mathbf{w}}_{k}^{i}$ is the $k$ th column of ${W}^{i}.{\sum }_{ij}$ is the covariance matrix between ${\Phi }^{i}$ and ${\Phi }^{j}$ . The optimisation problem above is multi-convex as long as ${\sum }_{ii}$ are non-singular. The local optimum can be easily found by iteratively maximising over each ${W}^{i}$ given the current values of the other coefficients as detailed in [18].

其中 ${W}^{i}$ 是将视图 ${\Phi }^{i}$ $\left( { \in  {\mathbb{R}}^{{n}_{T} \times  {m}_{i}}}\right)$ 映射到嵌入空间的投影矩阵，${\mathbf{w}}_{k}^{i}$ 是 ${W}^{i}.{\sum }_{ij}$ 的第 $k$ 列，${\Phi }^{j}$ 是 ${\Phi }^{i}$ 和 ${\Phi }^{j}$ 之间的协方差矩阵。只要 ${\sum }_{ii}$ 是非奇异的，上述优化问题就是多凸的。如 [18] 中详细所述，通过在给定其他系数当前值的情况下对每个 ${W}^{i}$ 进行迭代最大化，可以很容易地找到局部最优解。

The dimensionality ${m}_{e}$ of the embedding space is the sum of the input view dimensions, i.e. ${m}_{e} = \mathop{\sum }\limits_{{i = 1}}^{{n}_{V}}{m}_{i}$ , so ${W}^{i} \in  {\mathbb{R}}^{{m}_{i} \times  {m}_{e}}$ . Compared to the classic approach to CCA [18] which projects to a lower dimension space, this retains all the input information including uncorrelated dimensions which may be valuable and complementary. Side-stepping the task of explicitly selecting a subspace dimension, we use a more stable and effective soft-weighting strategy to implicitly emphasise significant dimensions in the embedding space. This can be seen as a generalisation of standard dimension reducing approaches to CCA, which implicitly define a binary weight vector that activates a subset of dimensions and deactivates others. Since the importance of each dimension is reflected by its corresponding eigenvalue [17], [18], we use the eigenvalues to weight the dimensions and define a weighted embedding space $\Gamma$ :

嵌入空间的维度 ${m}_{e}$ 是输入视图维度之和，即 ${m}_{e} = \mathop{\sum }\limits_{{i = 1}}^{{n}_{V}}{m}_{i}$ ，因此 ${W}^{i} \in  {\mathbb{R}}^{{m}_{i} \times  {m}_{e}}$ 。与经典的典型相关分析(CCA)方法 [18] (该方法投影到低维空间)相比，这种方法保留了所有输入信息，包括可能有价值且互补的不相关维度。我们避开了明确选择子空间维度的任务，采用了一种更稳定有效的软加权策略，以隐式地强调嵌入空间中的重要维度。这可以看作是对CCA标准降维方法的推广，标准降维方法隐式地定义了一个二进制权重向量，激活一部分维度并停用其他维度。由于每个维度的重要性由其对应的特征值反映 [17] 、 [18] ，我们使用特征值对维度进行加权，并定义一个加权嵌入空间 $\Gamma$ :

$$
{\Psi }^{i} = {\Phi }^{i}{W}^{i}{\left\lbrack  {D}^{i}\right\rbrack  }^{\lambda } = {\Phi }^{i}{W}^{i}{\widetilde{D}}^{i}, \tag{2}
$$

where ${D}^{i}$ is a diagonal matrix with its diagonal elements set to the eigenvalues of each dimension in the embedding space, $\lambda$ is a power weight of ${D}^{i}$ and empirically set to 4 [17], and ${\Psi }^{i}$ is the final representation of the target data from view $i$ in $\Gamma$ . We index the ${n}_{V} = 3$ views as $i \in  \{ \mathcal{X}$ , $\mathcal{V},\mathcal{A}\}$ for notational convenience. The same formulation can be used if more views are available.

其中 ${D}^{i}$ 是一个对角矩阵，其对角元素设置为嵌入空间中每个维度的特征值， $\lambda$ 是 ${D}^{i}$ 的幂权重，根据经验设置为4 [17] ， ${\Psi }^{i}$ 是视图 $i$ 在 $\Gamma$ 中目标数据的最终表示。为了符号表示方便，我们将 ${n}_{V} = 3$ 个视图索引为 $i \in  \{ \mathcal{X}$ 、 $\mathcal{V},\mathcal{A}\}$ 。如果有更多视图，也可以使用相同的公式。

Similarity in the embedding space. The choice of similarity metric is important for high-dimensional embedding spaces. For the subsequent recognition and annotation tasks, we compute cosine distance in $\Gamma$ by ${l}_{2}$ normalisation: normalising any vector ${\mathbf{\psi }}_{k}^{i}$ (the $k$ th row of ${\Psi }^{i}$ ) to unit length

嵌入空间中的相似度。对于高维嵌入空间，相似度度量的选择很重要。对于后续的识别和标注任务，我们通过 ${l}_{2}$ 归一化在 $\Gamma$ 中计算余弦距离:将任何向量 ${\mathbf{\psi }}_{k}^{i}$ ( ${\Psi }^{i}$ 的第 $k$ 行)归一化为单位长度

Authorized licensed use limited to: JILIN UNIVERSITY. Downloaded on March 29,2025 at 06:13:38 UTC from IEEE Xplore. Restrictions apply. (i.e. ${\begin{Vmatrix}{\psi }_{k}^{i}\end{Vmatrix}}_{2} = 1$ ). Cosine similarity is given by the inner product of any two vectors in $\Gamma$ .

授权许可使用仅限于:吉林大学。于2025年3月29日06:13:38 UTC从IEEE Xplore下载。适用限制。(即 ${\begin{Vmatrix}{\psi }_{k}^{i}\end{Vmatrix}}_{2} = 1$ )。余弦相似度由 $\Gamma$ 中任意两个向量的内积给出。

## 4 RECOGNITION BY MULTI-VIEW HYPERGRAPH LABEL PROPAGATION

## 4 基于多视图超图标签传播的识别

For zero-shot recognition, each target class $c$ to be recognised has a semantic prototype ${\mathbf{y}}_{c}^{i}$ in each view $i$ . Similarly, we have three views of each unlabelled instance ${f}^{\mathcal{A}}\left( {X}_{T}\right)$ , ${f}^{\mathcal{V}}\left( {X}_{T}\right)$ and ${X}_{T}$ . The class prototypes are expected to be the mean of the distribution of their class in semantic space, since the projection function ${f}^{i}$ is trained to map instances to their class prototype in each semantic view. To exploit the learned space $\Gamma$ to improve recognition, we project both the unlabelled instances and the prototypes into the embedding space. ${}^{3}$ The prototypes ${\mathbf{y}}_{c}^{i}$ for views $i \in  \{ \mathcal{A},\mathcal{V}\}$ are projected as ${\mathbf{\psi }}_{c}^{i} = {\mathbf{y}}_{c}^{i}{W}^{i}{\widetilde{D}}^{i}$ . So we have ${\mathbf{\psi }}_{c}^{\mathcal{A}}$ and ${\mathbf{\psi }}_{c}^{\mathcal{V}}$ for the attribute and word vector prototypes of each target class $c$ in $\Gamma$ . In the absence of a prototype for the (non-semantic) low-level feature view $\mathcal{X}$ , we synthesise it as ${\psi }_{c}^{\mathcal{X}} = \left( {\psi }_{c}^{\mathcal{A}}\right.  +$ $\left. {\psi }_{c}^{\mathcal{V}}\right) /2$ . If labelled data is available (i.e., N-shot case), these are also projected into the space. Recognition could now be achieved using NN classification with the embedded prototypes/N-shots as labelled data. However, this does not effectively exploit the multi-view complementarity, and suffers from labelled data (prototype) sparsity. To solve this problem, we next introduce a unified framework to fuse the views and transductively exploit the manifold structure of the unlabelled target data to perform zero-shot and N-shot learning.

对于零样本识别，每个待识别的目标类别 $c$ 在每个视图 $i$ 中都有一个语义原型 ${\mathbf{y}}_{c}^{i}$。同样，每个未标记实例 ${f}^{\mathcal{A}}\left( {X}_{T}\right)$、${f}^{\mathcal{V}}\left( {X}_{T}\right)$ 和 ${X}_{T}$ 都有三个视图。由于投影函数 ${f}^{i}$ 经过训练，可将实例映射到每个语义视图中的类别原型，因此类别原型应是其类别在语义空间中分布的均值。为了利用所学空间 $\Gamma$ 来提高识别率，我们将未标记实例和原型都投影到嵌入空间中。${}^{3}$ 视图 $i \in  \{ \mathcal{A},\mathcal{V}\}$ 的原型 ${\mathbf{y}}_{c}^{i}$ 被投影为 ${\mathbf{\psi }}_{c}^{i} = {\mathbf{y}}_{c}^{i}{W}^{i}{\widetilde{D}}^{i}$。因此，在 $\Gamma$ 中，每个目标类别 $c$ 的属性和词向量原型分别为 ${\mathbf{\psi }}_{c}^{\mathcal{A}}$ 和 ${\mathbf{\psi }}_{c}^{\mathcal{V}}$。由于(非语义)低级特征视图 $\mathcal{X}$ 没有原型，我们将其合成 ${\psi }_{c}^{\mathcal{X}} = \left( {\psi }_{c}^{\mathcal{A}}\right.  +$ $\left. {\psi }_{c}^{\mathcal{V}}\right) /2$。如果有标记数据(即 N 样本情况)，也会将其投影到该空间中。现在可以使用最近邻(NN)分类，将嵌入的原型/N 样本作为标记数据来实现识别。然而，这种方法无法有效利用多视图的互补性，并且会受到标记数据(原型)稀疏性的影响。为了解决这个问题，我们接下来引入一个统一的框架，融合各个视图，并通过直推式方法利用未标记目标数据的流形结构，以进行零样本和 N 样本学习。

Most or all of the target instances are unlabelled, so classification based on the sparse prototypes is effectively a semi-supervised learning problem [57]. We leverage graph-based semi-supervised learning to exploit the manifold structure of the unlabelled data transductively for classification. This differs from the conventional approaches such as direct attribute prediction [28] or NN, which too simplistically assume that the data distribution for each target class is Gaussian or multinomial. However, since our embedding space contains multiple projections of the target data and prototypes, it is hard to define a single graph that synergistically exploits the manifold structure of all views. We therefore construct multiple graphs within and across views in a transductive multi-view hypergraph label propagation model. Specifically, we construct the heterogeneous hyper-graphs across views to combine/align the different manifold structures so as to enhance the robustness and exploit the complementarity of different views. Semi-supervised learning is then performed by propagating the labels from the sparse prototypes (zero-shot) and/or the few labelled target instances (N-shot) to the unlabelled data using random walk on the graphs.

大多数或所有目标实例都是未标记的，因此基于稀疏原型的分类实际上是一个半监督学习问题 [57]。我们利用基于图的半监督学习方法，通过直推式方式利用未标记数据的流形结构进行分类。这与传统方法(如直接属性预测 [28] 或最近邻法)不同，传统方法过于简单地假设每个目标类别的数据分布是高斯分布或多项分布。然而，由于我们的嵌入空间包含目标数据和原型的多个投影，很难定义一个能协同利用所有视图流形结构的单一图。因此，我们在直推式多视图超图标签传播模型中，在视图内和视图间构建多个图。具体来说，我们跨视图构建异构超图，以组合/对齐不同的流形结构，从而增强鲁棒性并利用不同视图的互补性。然后，通过在图上进行随机游走，将标签从稀疏原型(零样本)和/或少量标记的目标实例(N 样本)传播到未标记数据，从而进行半监督学习。

### 4.1 Constructing Heterogeneous Hypergraphs

### 4.1 构建异构超图

Pairwise node similarity. The key idea behind a hypergraph based method is to group similar data points, represented as vertices/nodes on a graph, into hyperedges, so that the subsequent computation is less sensitive to individual noisy nodes. With the hyperedges, the pairwise similarity between two data points are measured as the similarity between the two hyperedges that they belong to, instead of that between the two nodes only. For both forming hyper-edges and computing the similarity between two hyper-edges, pairwise similarity between two graph nodes needs to be defined. In our embedding space $\Gamma$ , each data point in each view defines a node, and the similarity between any pair of nodes is:

节点对相似度。基于超图的方法的核心思想是将相似的数据点(在图中表示为顶点/节点)分组到超边中，这样后续的计算对单个噪声节点就不那么敏感。有了超边，两个数据点之间的成对相似度就被衡量为它们所属的两个超边之间的相似度，而不仅仅是两个节点之间的相似度。无论是形成超边还是计算两个超边之间的相似度，都需要定义两个图节点之间的成对相似度。在我们的嵌入空间 $\Gamma$ 中，每个视图中的每个数据点都定义一个节点，任意一对节点之间的相似度为:

$$
\omega \left( {{\mathbf{\psi }}_{k}^{i},{\mathbf{\psi }}_{l}^{j}}\right)  = \exp \left( \frac{ < {\mathbf{\psi }}_{k}^{i},{\mathbf{\psi }}_{l}^{j}{ > }^{2}}{\varpi }\right) , \tag{3}
$$

---

3. Before being projected into $\Gamma$ , the prototypes are updated by semilatent zero shot learning algorithm in [15].

3. 在投影到 $\Gamma$ 之前，原型通过文献 [15] 中的半隐式零样本学习算法进行更新。

---

![0195e08a-2f2a-7034-a202-61776690cc02_5_356_126_999_400_0.jpg](images/0195e08a-2f2a-7034-a202-61776690cc02_5_356_126_999_400_0.jpg)

Fig. 3. An example of constructing heterogeneous hypergraphs. Suppose in the embedding space, we have 14 nodes belonging to seven data points $A, B, C, D, E, F$ and $G$ of two views—view $i$ (rectangle) and view $j$ (circle). Data points $A, B, C$ and $D, E, F, G$ belong to two different classes—red and green respectively. The multi-view semantic embedding maximises the correlations (connected by black dash lines) between the two views of the same node. Two hypergraphs are shown $\left( {\mathcal{G}}^{ij}\right.$ at the left and ${\mathcal{G}}^{ji}$ at the right) with the heterogeneous hyperedges drawn with red/green dash ovals for the nodes of red/green classes. Each hyperedge consists of two most similar nodes to the query node.

图3. 构建异构超图的示例。假设在嵌入空间中，我们有14个节点，它们属于两个视图(视图 $i$(矩形)和视图 $j$(圆形))的七个数据点 $A, B, C, D, E, F$ 和 $G$。数据点 $A, B, C$ 和 $D, E, F, G$ 分别属于两个不同的类别——红色和绿色。多视图语义嵌入最大化了同一节点的两个视图之间的相关性(用黑色虚线连接)。展示了两个超图(左边的 $\left( {\mathcal{G}}^{ij}\right.$ 和右边的 ${\mathcal{G}}^{ji}$)，其中红色/绿色类别的节点的异构超边用红色/绿色虚线椭圆表示。每个超边由与查询节点最相似的两个节点组成。

where $< {\psi }_{k}^{i},{\psi }_{l}^{j}{ > }^{2}$ is the square of inner product between the $i$ th and $j$ th projections of nodes $k$ and $l$ with a bandwidth parameter $\varpi {.}^{4}$ Note that Eq. (3) defines the pairwise similarity between any two nodes within the same view $\left( {i = j}\right)$ or across different views $\left( {i \neq  j}\right)$ .

其中 $< {\psi }_{k}^{i},{\psi }_{l}^{j}{ > }^{2}$ 是节点 $k$ 和 $l$ 的第 $i$ 个和第 $j$ 个投影之间的内积的平方，带宽参数为 $\varpi {.}^{4}$。请注意，公式(3)定义了同一视图内 $\left( {i = j}\right)$ 或不同视图间 $\left( {i \neq  j}\right)$ 任意两个节点之间的成对相似度。

Heterogeneous hyperedges. Given the multi-view projections of the target data, we aim to construct a set of across-view heterogeneous hypergraphs

异构超边。给定目标数据的多视图投影，我们的目标是构建一组跨视图的异构超图

$$
{\mathcal{G}}^{c} = \left\{  {{\mathcal{G}}^{ij} \mid  i, j \in  \{ \mathcal{X},\mathcal{V},\mathcal{A}\} , i \neq  j}\right\}  , \tag{4}
$$

where ${\mathcal{G}}^{ij} = \left\{  {{\Psi }^{i},{E}^{ij},{\Omega }^{ij}}\right\}$ denotes the cross-view heterogeneous hypergraph from view $i$ to $j$ (in that order) and ${\Psi }^{i}$ is the node set in view $i;{E}^{ij}$ is the hyperedge set and ${\Omega }^{ij}$ is the pairwise node similarity set for the hyperedges. Specifically, we have the hyperedge set ${E}^{ij} = \left\{  {{e}_{{\psi }_{k}^{i}}^{ij} \mid  i \neq  j, k = 1,\ldots {n}_{T} + }\right.$ $\left. {c}_{T}\right\}$ where each hyperedge ${e}_{{\psi }_{k}^{i}}^{ij}$ includes the nodes ${}^{5}$ in view $j$ that are the most similar to node ${\psi }_{k}^{i}$ in view $i$ and the similarity set ${\Omega }^{ij} = \left\{  {{\Delta }_{{\psi }_{k}^{i}}^{ij} = \left\{  {\omega \left( {{\psi }_{k}^{i},{\psi }_{l}^{j}}\right) }\right\}   \mid  i \neq  j,{\psi }_{l}^{j} \in  {e}_{{\psi }_{k}^{i}}^{ij}k = 1,\ldots }\right\}$ $\left. {{n}_{T} + {c}_{T}}\right\}$ where $\omega \left( {{\mathbf{\psi }}_{k}^{i},{\mathbf{\psi }}_{l}^{j}}\right)$ is computed using Eq. (3).

其中 ${\mathcal{G}}^{ij} = \left\{  {{\Psi }^{i},{E}^{ij},{\Omega }^{ij}}\right\}$ 表示从视图 $i$ 到视图 $j$(按此顺序)的跨视图异构超图，${\Psi }^{i}$ 是视图 $i;{E}^{ij}$ 中的节点集，${\Omega }^{ij}$ 是超边的成对节点相似度集。具体来说，我们有超边集 ${E}^{ij} = \left\{  {{e}_{{\psi }_{k}^{i}}^{ij} \mid  i \neq  j, k = 1,\ldots {n}_{T} + }\right.$ $\left. {c}_{T}\right\}$，其中每个超边 ${e}_{{\psi }_{k}^{i}}^{ij}$ 包含视图 $j$ 中与视图 $i$ 中的节点 ${\psi }_{k}^{i}$ 最相似的节点 ${}^{5}$，以及相似度集 ${\Omega }^{ij} = \left\{  {{\Delta }_{{\psi }_{k}^{i}}^{ij} = \left\{  {\omega \left( {{\psi }_{k}^{i},{\psi }_{l}^{j}}\right) }\right\}   \mid  i \neq  j,{\psi }_{l}^{j} \in  {e}_{{\psi }_{k}^{i}}^{ij}k = 1,\ldots }\right\}$ $\left. {{n}_{T} + {c}_{T}}\right\}$，其中 $\omega \left( {{\mathbf{\psi }}_{k}^{i},{\mathbf{\psi }}_{l}^{j}}\right)$ 使用公式(3)计算。

Authorized licensed use limited to: JILIN UNIVERSITY. Downloaded on March 29,2025 at 06:13:38 UTC from IEEE Xplore. Restrictions apply.

授权许可使用仅限于:吉林大学。于2025年3月29日06:13:38 UTC从IEEE Xplore下载。适用限制条款。

We call ${\psi }_{k}^{i}$ the query node for hyperedge ${e}_{{\psi }_{k}^{i}}^{ij}$ , since the hyperedge ${e}_{{\psi }_{k}^{i}}^{ij}$ intrinsically groups all nodes in view $j$ that are most similar to node ${\mathbf{\psi }}_{k}^{i}$ in view $i$ . Similarly, ${\mathcal{G}}^{ji}$ can be constructed by using nodes from view $j$ to query nodes in view $i$ . Therefore given three views, we have six across view/heterogeneous hypergraphs. Fig. 3 illustrates two heterogeneous hypergrahs constructed from two views. Interestingly, our way of defining hyperedges naturally corresponds to the star expansion [46] where the query node (i.e. ${\psi }_{k}^{i}$ ) is introduced to connect each node in the hyperedge ${e}_{{\psi }_{k}^{i}}^{ij}$ .

我们将 ${\psi }_{k}^{i}$ 称为超边 ${e}_{{\psi }_{k}^{i}}^{ij}$ 的查询节点，因为超边 ${e}_{{\psi }_{k}^{i}}^{ij}$ 本质上对视图 $j$ 中与视图 $i$ 中的节点 ${\mathbf{\psi }}_{k}^{i}$ 最相似的所有节点进行了分组。类似地，可以通过使用视图 $j$ 中的节点来查询视图 $i$ 中的节点来构建 ${\mathcal{G}}^{ji}$。因此，给定三个视图，我们有六个跨视图/异构超图。图 3 展示了由两个视图构建的两个异构超图。有趣的是，我们定义超边的方式自然对应于星形扩展 [46]，其中引入查询节点(即 ${\psi }_{k}^{i}$)来连接超边 ${e}_{{\psi }_{k}^{i}}^{ij}$ 中的每个节点。

Similarity strength of hyperedge. For each hyperedge ${e}_{{\psi }_{L}^{i}}^{ij}$ , we measure its similarity strength by using its query nodes ${\psi }_{k}^{i}$ . Specifically, we use the weight ${\delta }_{{\psi }_{k}^{i}}^{ij}$ to indicate the similarity strength of nodes connected within the hyperedge ${e}_{{\psi }_{k}^{i}}^{ij}$ . Thus, we define ${\delta }_{{\psi }_{k}^{i}}^{ij}$ based on the mean similarity of the set ${\Delta }_{{\psi }_{k}^{i}}^{ij}$ for the hyperedge

超边的相似性强度。对于每个超边 ${e}_{{\psi }_{L}^{i}}^{ij}$，我们使用其查询节点 ${\psi }_{k}^{i}$ 来衡量其相似性强度。具体来说，我们使用权重 ${\delta }_{{\psi }_{k}^{i}}^{ij}$ 来表示超边 ${e}_{{\psi }_{k}^{i}}^{ij}$ 内连接节点的相似性强度。因此，我们基于超边的集合 ${\Delta }_{{\psi }_{k}^{i}}^{ij}$ 的平均相似性来定义 ${\delta }_{{\psi }_{k}^{i}}^{ij}$

$$
{\delta }_{{\mathbf{\psi }}_{k}^{i}}^{ij} = \frac{1}{\left| {e}_{{\mathbf{\psi }}_{k}^{i}}^{ij}\right| }\mathop{\sum }\limits_{{\omega \left( {{\mathbf{\psi }}_{k}^{i},{\mathbf{\psi }}_{l}^{j}}\right)  \in  {\Delta }_{{\mathbf{\psi }}_{k}^{i}}^{ij},{\mathbf{\psi }}_{l}^{j} \in  {\psi }_{{\mathbf{\psi }}_{k}^{i}}^{ij}}}\omega \left( {{\mathbf{\psi }}_{k}^{i},{\mathbf{\psi }}_{l}^{j}}\right) , \tag{5}
$$

where $\left| {e}_{{\psi }_{k}^{i}}^{ij}\right|$ is the cardinality of hyperedge ${e}_{{\psi }_{k}^{i}}^{ij}$ .

其中 $\left| {e}_{{\psi }_{k}^{i}}^{ij}\right|$ 是超边 ${e}_{{\psi }_{k}^{i}}^{ij}$ 的基数。

In the embedding space $\Gamma$ , similarity sets ${\Delta }_{{\psi }_{k}^{i}}^{ij}$ and ${\Delta }_{{\psi }_{l}^{i}}^{ij}$ can be compared. Nevertheless, these sets come from heterogeneous views and have varying scales. Thus some normalisation steps are necessary to make the two similarity sets more comparable and the subsequent computation more robust. Specifically, we extend zero-score normalisation to the similarity sets: (a) We assume $\forall {\Delta }_{{\psi }_{k}^{i}}^{ij} \in  {\Omega }^{ij}$ and ${\Delta }_{{\psi }_{k}^{i}}^{ij}$ should follow Gaussian distribution. Thus, we enforce zero-score normalisation to ${\Delta }_{{\psi }_{k}^{i}}^{ij}$ . (b) We further assume that the retrieved similarity set ${\Omega }^{ij}$ between all the queried nodes ${\mathbf{\psi }}_{k}^{i}\left( {l = 1,\ldots {n}_{T}}\right)$ from view $i$ and ${\psi }_{l}^{j}$ should also follow Gaussian distributions. So we again enforce Gaussian distribution to the pairwise similarities between ${\psi }_{l}^{j}$ and all query nodes from view $i$ by zero-score normalisation. (c) We select the first $K$ highest values from ${\Delta }_{{\psi }_{k}^{i}}^{ij}$ as new similarity set ${\bar{\Delta }}_{{\psi }_{k}^{i}}^{ij}$ for hyper-edge ${e}_{{\psi }_{k}^{i}}^{ij} \cdot  {\bar{\Delta }}_{{\psi }_{k}^{i}}^{ij}$ is then used in Eq. (5) in place of ${\Delta }_{{\psi }_{k}^{i}}^{ij}$ . These normalisation steps aim to compute a more robust similarity between each pair of hyperedges.

在嵌入空间 $\Gamma$ 中，可以比较相似性集合 ${\Delta }_{{\psi }_{k}^{i}}^{ij}$ 和 ${\Delta }_{{\psi }_{l}^{i}}^{ij}$。然而，这些集合来自异构视图，并且具有不同的尺度。因此，需要进行一些归一化步骤，以使两个相似性集合更具可比性，并使后续计算更加稳健。具体来说，我们将零分归一化扩展到相似性集合:(a) 我们假设 $\forall {\Delta }_{{\psi }_{k}^{i}}^{ij} \in  {\Omega }^{ij}$ 和 ${\Delta }_{{\psi }_{k}^{i}}^{ij}$ 应遵循高斯分布。因此，我们对 ${\Delta }_{{\psi }_{k}^{i}}^{ij}$ 执行零分归一化。(b) 我们进一步假设，从视图 $i$ 中所有被查询节点 ${\mathbf{\psi }}_{k}^{i}\left( {l = 1,\ldots {n}_{T}}\right)$ 与 ${\psi }_{l}^{j}$ 之间检索到的相似性集合 ${\Omega }^{ij}$ 也应遵循高斯分布。因此，我们再次通过零分归一化对 ${\psi }_{l}^{j}$ 与视图 $i$ 中所有查询节点之间的成对相似性执行高斯分布。(c) 我们从 ${\Delta }_{{\psi }_{k}^{i}}^{ij}$ 中选择前 $K$ 个最高值作为超边 ${e}_{{\psi }_{k}^{i}}^{ij} \cdot  {\bar{\Delta }}_{{\psi }_{k}^{i}}^{ij}$ 的新相似性集合 ${\bar{\Delta }}_{{\psi }_{k}^{i}}^{ij}$，然后在公式 (5) 中用 ${\bar{\Delta }}_{{\psi }_{k}^{i}}^{ij}$ 代替 ${\Delta }_{{\psi }_{k}^{i}}^{ij}$。这些归一化步骤旨在计算每对超边之间更稳健的相似性。

---

4. Most previous work [36], [56] sets $\varpi$ by cross-validation. Inspired by [26], a simpler strategy for setting $\varpi$ is adopted: $\varpi  \approx  \underset{k, l = 1,\cdots , n}{\text{ median }} <$ ${\mathbf{\psi }}_{k}^{i},{\mathbf{\psi }}_{l}^{j}{ > }^{2}$ in order to have roughly the same number of similar and dissimilar sample pairs. This makes the edge weights from different pairs of nodes more comparable.

4. 大多数先前的工作 [36]、[56] 通过交叉验证来设置 $\varpi$。受 [26] 的启发，采用了一种更简单的设置 $\varpi$ 的策略:$\varpi  \approx  \underset{k, l = 1,\cdots , n}{\text{ median }} <$ ${\mathbf{\psi }}_{k}^{i},{\mathbf{\psi }}_{l}^{j}{ > }^{2}$，以便使相似和不相似的样本对数量大致相同。这使得不同节点对之间的边权重更具可比性。

5. Both the unlabelled samples and the prototypes are nodes.

5. 未标记样本和原型都是节点。

---

Computing similarity between hyperedges. With the hyper-graph, the similarity between two nodes is computed using their hyperedges ${e}_{{\psi }_{h}^{i}}^{ij}$ . Specifically, for each hyperedge there is an associated incidence matrix ${H}^{ij} = \left( {h\left( {\psi }_{l}^{j}\right. }\right.$ , $\left. \left. {e}_{{\psi }_{k}^{i}}^{ij}\right) \right) \left( {{n}_{T} + {c}_{T}}\right)  \times  \left| {E}^{ij}\right|$ where

计算超边之间的相似度。利用超图，使用两个节点的超边 ${e}_{{\psi }_{h}^{i}}^{ij}$ 来计算它们之间的相似度。具体来说，对于每个超边，都有一个关联的关联矩阵 ${H}^{ij} = \left( {h\left( {\psi }_{l}^{j}\right. }\right.$，$\left. \left. {e}_{{\psi }_{k}^{i}}^{ij}\right) \right) \left( {{n}_{T} + {c}_{T}}\right)  \times  \left| {E}^{ij}\right|$，其中

$$
h\left( {{\psi }_{l}^{j},{e}_{{\psi }_{k}^{i}}^{ij}}\right)  = \left\{  \begin{array}{ll} 1 & \text{ if }{\psi }_{l}^{j} \in  {e}_{{\psi }_{k}^{i}}^{ij}, \\  0 & \text{ otherwise }. \end{array}\right.  \tag{6}
$$

To take into consideration the similarity strength between hyperedge and query node, we extend the binary valued hyperedge incidence matrix ${H}^{ij}$ to soft-assigned incidence matrix $S{H}^{ij} = {\left( sh\left( {\psi }_{l}^{j},{e}_{{\psi }_{k}^{i}}^{ij}\right) \right) }_{\left( {{n}_{T} + {c}_{T}}\right)  \times  \left| {E}^{ij}\right| }$ as follows:

为了考虑超边和查询节点之间的相似强度，我们将二值超边关联矩阵 ${H}^{ij}$ 扩展为软分配关联矩阵 $S{H}^{ij} = {\left( sh\left( {\psi }_{l}^{j},{e}_{{\psi }_{k}^{i}}^{ij}\right) \right) }_{\left( {{n}_{T} + {c}_{T}}\right)  \times  \left| {E}^{ij}\right| }$，如下所示:

$$
\operatorname{sh}\left( {{\psi }_{l}^{j},{e}_{{\psi }_{k}^{i}}^{ij}}\right)  = {\delta }_{{\psi }_{k}^{i}}^{ij} \cdot  \omega \left( {{\psi }_{k}^{i},{\psi }_{l}^{j}}\right)  \cdot  h\left( {{\psi }_{l}^{j},{e}_{{\psi }_{k}^{i}}^{ij}}\right) . \tag{7}
$$

This soft-assigned incidence matrix is the product of three components: (1) the weight ${\delta }_{{\psi }_{k}^{i}}$ for hyperedge ${e}_{{\psi }_{k}^{i}}^{ij}$ ; (2) the pairwise similarity computed using queried node ${\mathbf{\psi }}_{k}^{i}$ ; (3) the binary valued hyperedge incidence matrix element $h\left( {{\mathbf{\psi }}_{l}^{j},{e}_{{\mathbf{\psi }}_{k}^{i}}^{ij}}\right)$ . To make the values of $S{H}^{ij}$ comparable among the different heterogeneous views, we apply ${l}_{2}$ normalisation to the soft-assigned incidence matrix values for all node incident to each hyperedge.

这个软分配关联矩阵由三个部分组成:(1) 超边 ${e}_{{\psi }_{k}^{i}}^{ij}$ 的权重 ${\delta }_{{\psi }_{k}^{i}}$；(2) 使用查询节点 ${\mathbf{\psi }}_{k}^{i}$ 计算的成对相似度；(3) 二值超边关联矩阵元素 $h\left( {{\mathbf{\psi }}_{l}^{j},{e}_{{\mathbf{\psi }}_{k}^{i}}^{ij}}\right)$。为了使 $S{H}^{ij}$ 的值在不同的异构视图之间具有可比性，我们对每个超边关联的所有节点的软分配关联矩阵值应用 ${l}_{2}$ 归一化。

Now for each heterogeneous hypergraph, we can finally define the pairwise similarity between any two nodes or hyperedges. Specifically for ${\mathcal{G}}^{ij}$ , the similarity between the oth and $l$ th nodes is

现在，对于每个异构超图，我们最终可以定义任意两个节点或超边之间的成对相似度。具体来说，对于 ${\mathcal{G}}^{ij}$，第 o 个节点和第 $l$ 个节点之间的相似度为

$$
{\omega }_{c}^{ij}\left( {{\mathbf{\psi }}_{o}^{j},{\mathbf{\psi }}_{l}^{j}}\right)  = \mathop{\sum }\limits_{\substack{{{e}_{{\psi }_{k}^{i}}^{ij} \in  {E}^{ij}} }}\operatorname{sh}\left( {{\mathbf{\psi }}_{o}^{j},{e}_{{\psi }_{k}^{i}}^{ij}}\right)  \cdot  \operatorname{sh}\left( {{\mathbf{\psi }}_{l}^{j},{e}_{{\psi }_{k}^{i}}^{ij}}\right) . \tag{8}
$$

With this pairwise hyperedge similarity, the hypergraph definition is now complete. Empirically, given a node, other nodes on the graph that have very low similarities will have very limited effects on its label. Thus, to reduce computational cost, we only use the K-nearest-neighbour ${}^{6}$ nodes of each node [57] for the subsequent label propagation step.

有了这种成对的超边相似度，超图的定义现在就完成了。根据经验，给定一个节点，图中与之相似度非常低的其他节点对其标签的影响非常有限。因此，为了降低计算成本，我们在后续的标签传播步骤中仅使用每个节点的 K 近邻 ${}^{6}$ 节点 [57]。

The advantages of heterogeneous hypergraphs. We argue that the pairwise similarity of heterogeneous hypergraphs is a distributed representation [2]. To explain it, we can use star extension [46] to extend a hypergraph into a 2-graph. For each hyperedge ${e}_{{\psi }_{k}^{i}}^{ij}$ , the query node ${\psi }_{k}^{i}$ is used to compute the pairwise similarity ${\Delta }_{{\psi }_{k}^{i}}^{ij}$ of all the nodes in view $j$ . Each hyperedge can thus define a hyper-plane by categorising the nodes in view $j$ into two groups: strong and weak similarity group regarding to query node ${\psi }_{k}^{i}$ . In other words, the hyperedge set ${E}^{ij}$ is multi-clustering with linearly separated regions (by each hyperplane) per classes. Since the final pairwise similarity in Eq. (8) can be represented by a set of similarity weights computed by hyperedge, and such weights are not mutually exclusive and are statistically independent, we consider the heterogeneous hypergraph a distributed representation. The advantage of having a distributed representation has been studied by Watts and Strogatz [52], [53] which shows that such a representation gives rise to better convergence rates and better clustering abilities. In contrast, the homogeneous hypergraphs adopted by previous work [12], [19], [22] does not have this property which makes them less robust against noise. In addition, fusing different views in the early stage of graph construction potentially can lead to better exploitation of the complementarity of different views. However, it is worth pointing out that (1) The reason we can query nodes across views to construct heterogeneous hypergraph is because we have projected all views in the same embedding space in the first place. (2) Hypergraphs typically gain robustness at the cost of losing discriminative power-it essentially blurs the boundary of different clusters/classes by taking average over hyperedges. A typical solution is to fuse hypergraphs with 2-graphs [12], [19], [29], which we adopt here as well.

异构超图的优势。我们认为，异构超图的成对相似性是一种分布式表示 [2]。为了解释这一点，我们可以使用星型扩展 [46] 将超图扩展为 2 - 图。对于每个超边 ${e}_{{\psi }_{k}^{i}}^{ij}$，查询节点 ${\psi }_{k}^{i}$ 用于计算视图 $j$ 中所有节点的成对相似性 ${\Delta }_{{\psi }_{k}^{i}}^{ij}$。因此，每个超边可以通过将视图 $j$ 中的节点分为两组来定义一个超平面:相对于查询节点 ${\psi }_{k}^{i}$ 的强相似性组和弱相似性组。换句话说，超边集 ${E}^{ij}$ 是多聚类的，每个类别都有线性分隔的区域(由每个超平面分隔)。由于公式 (8) 中的最终成对相似性可以由一组通过超边计算的相似性权重表示，并且这些权重并非相互排斥且在统计上是独立的，我们认为异构超图是一种分布式表示。Watts 和 Strogatz [52]、[53] 研究了分布式表示的优势，结果表明这种表示能带来更好的收敛速度和更好的聚类能力。相比之下，先前工作 [12]、[19]、[22] 采用的同构超图不具备这一特性，这使得它们在抗噪声方面的鲁棒性较差。此外，在图构建的早期阶段融合不同视图可能会更好地利用不同视图的互补性。然而，值得指出的是:(1) 我们能够跨视图查询节点以构建异构超图的原因是，我们首先将所有视图投影到了同一个嵌入空间中。(2) 超图通常以牺牲判别能力为代价来获得鲁棒性——它本质上是通过对超边取平均值来模糊不同聚类/类别的边界。一种典型的解决方案是将超图与 2 - 图融合 [12]、[19]、[29]，我们在这里也采用了这种方法。

### 4.2 Label Propagation by Random Walk

### 4.2 通过随机游走进行标签传播

Now we have two types of graphs: heterogeneous hyper-graphs ${\mathcal{G}}^{c} = \left\{  {\mathcal{G}}^{ij}\right\}$ and 2-graphs ${}^{7}{\mathcal{G}}^{p} = \left\{  {\mathcal{G}}^{i}\right\}$ . Given three views $\left( {{n}_{V} = 3}\right)$ , we thus have nine graphs in total (six hyper-graphs and three 2-graphs). To classify the unlabelled nodes, we need to propagate label information from the prototype nodes across the graph. Such semi-supervised label propagation [56], [57] has a closed-form solution and is explained as a random walk. A random walk requires pairwise transition probability for nodes $k$ and $l$ . We obtain this by aggregating the information from all graphs $\mathcal{G} = \left\{  {{\mathcal{G}}^{p};{\mathcal{G}}^{c}}\right\}$ ,

现在我们有两种类型的图:异构超图 ${\mathcal{G}}^{c} = \left\{  {\mathcal{G}}^{ij}\right\}$ 和 2 - 图 ${}^{7}{\mathcal{G}}^{p} = \left\{  {\mathcal{G}}^{i}\right\}$。给定三个视图 $\left( {{n}_{V} = 3}\right)$，我们总共有九个图(六个超图和三个 2 - 图)。为了对未标记的节点进行分类，我们需要将标签信息从原型节点传播到整个图中。这种半监督标签传播 [56]、[57] 有一个封闭形式的解，并可以解释为随机游走。随机游走需要节点 $k$ 和 $l$ 的成对转移概率。我们通过聚合所有图 $\mathcal{G} = \left\{  {{\mathcal{G}}^{p};{\mathcal{G}}^{c}}\right\}$ 的信息来获得这个概率。

$$
p\left( {k \rightarrow  l}\right)  = \mathop{\sum }\limits_{{i \in  \{ \mathcal{X},\mathcal{V},\mathcal{A}\} }}p\left( {k \rightarrow  l \mid  {\mathcal{G}}^{i}}\right)  \cdot  p\left( {{\mathcal{G}}^{i} \mid  k}\right)  \tag{9}
$$

$$
+ \mathop{\sum }\limits_{{i, j \in  \{ \mathcal{X},\mathcal{V},\mathcal{A}\} , i \neq  j}}p\left( {k \rightarrow  l \mid  {\mathcal{G}}^{ij}}\right)  \cdot  p\left( {{\mathcal{G}}^{ij} \mid  k}\right) ,
$$

where

其中

$$
p\left( {k \rightarrow  l \mid  {\mathcal{G}}^{i}}\right)  = \frac{{\omega }_{p}^{i}\left( {{\mathbf{\psi }}_{k}^{i},{\mathbf{\psi }}_{l}^{i}}\right) }{\mathop{\sum }\limits_{o}{\omega }_{p}^{i}\left( {{\mathbf{\psi }}_{k}^{i},{\mathbf{\psi }}_{o}^{i}}\right) }, \tag{10}
$$

and

并且

$$
p\left( {k \rightarrow  l \mid  {\mathcal{G}}^{ij}}\right)  = \frac{{\omega }_{c}^{ij}\left( {{\mathbf{\psi }}_{k}^{j},{\mathbf{\psi }}_{l}^{j}}\right) }{\mathop{\sum }\limits_{o}{\omega }_{c}^{ij}\left( {{\mathbf{\psi }}_{k}^{j},{\mathbf{\psi }}_{o}^{j}}\right) },
$$

and then the posterior probability to choose graph ${\mathcal{G}}^{i}$ at projection/node ${\psi }_{k}^{i}$ will be:

然后在投影/节点 ${\psi }_{k}^{i}$ 处选择图 ${\mathcal{G}}^{i}$ 的后验概率将为:

$$
p\left( {{\mathcal{G}}^{i} \mid  k}\right)  = \frac{\pi \left( {k \mid  {\mathcal{G}}^{i}}\right) p\left( {\mathcal{G}}^{i}\right) }{\mathop{\sum }\limits_{i}\pi \left( {k \mid  {\mathcal{G}}^{i}}\right) p\left( {\mathcal{G}}^{i}\right)  + \mathop{\sum }\limits_{{ij}}\pi \left( {k \mid  {\mathcal{G}}^{ij}}\right) p\left( {\mathcal{G}}^{ij}\right) }, \tag{11}
$$

$$
p\left( {{\mathcal{G}}^{ij} \mid  k}\right)  = \frac{\pi \left( {k \mid  {\mathcal{G}}^{ij}}\right) p\left( {\mathcal{G}}^{ij}\right) }{\mathop{\sum }\limits_{i}\pi \left( {k \mid  {\mathcal{G}}^{i}}\right) p\left( {\mathcal{G}}^{i}\right)  + \mathop{\sum }\limits_{{ij}}\pi \left( {k \mid  {\mathcal{G}}^{ij}}\right) p\left( {\mathcal{G}}^{ij}\right) }, \tag{12}
$$

where $p\left( {\mathcal{G}}^{i}\right)$ and $p\left( {\mathcal{G}}^{ij}\right)$ are the prior probability of graphs ${\mathcal{G}}^{i}$ and ${\mathcal{G}}^{ij}$ in the random walk. This probability expresses prior expectation about the informativeness of each graph. The sameBayesian model averaging [14] can be used here to estimate these prior probabilities. However, the computational cost is combinatorially increased with the number of views; and it turns out the prior is not critical to the results of our framework. Therefore, uniform prior is used in our experiments.

其中 $p\left( {\mathcal{G}}^{i}\right)$ 和 $p\left( {\mathcal{G}}^{ij}\right)$ 是随机游走中图 ${\mathcal{G}}^{i}$ 和 ${\mathcal{G}}^{ij}$ 的先验概率。这个概率表达了对每个图信息性的先前期望。同样的贝叶斯模型平均法 [14] 可以在这里用于估计这些先验概率。然而，计算成本会随着视图数量的增加而组合式增长；而且事实证明，先验对我们框架的结果并不关键。因此，在我们的实验中使用均匀先验。

---

6. $K = {30}$ . It can be varied from ${10} \sim  {50}$ with little effect in our experiments.

6. $K = {30}$。在我们的实验中，它可以在 ${10} \sim  {50}$ 范围内变化而影响很小。

---

The stationary probabilities for node $k$ in ${\mathcal{G}}^{i}$ and ${\mathcal{G}}^{ij}$ are

节点 $k$ 在 ${\mathcal{G}}^{i}$ 和 ${\mathcal{G}}^{ij}$ 中的平稳概率为

$$
\pi \left( {k \mid  {\mathcal{G}}^{i}}\right)  = \frac{\mathop{\sum }\limits_{l}{\omega }_{p}^{i}\left( {{\mathbf{\psi }}_{k}^{i},{\mathbf{\psi }}_{l}^{i}}\right) }{\mathop{\sum }\limits_{o}\mathop{\sum }\limits_{l}{\omega }_{p}^{i}\left( {{\mathbf{\psi }}_{k}^{i},{\mathbf{\psi }}_{o}^{i}}\right) }, \tag{13}
$$

$$
\pi \left( {k \mid  {\mathcal{G}}^{ij}}\right)  = \frac{\mathop{\sum }\limits_{l}{\omega }_{c}^{ij}\left( {{\mathbf{\psi }}_{k}^{j},{\mathbf{\psi }}_{l}^{j}}\right) }{\mathop{\sum }\limits_{k}\mathop{\sum }\limits_{o}{\omega }_{c}^{ij}\left( {{\mathbf{\psi }}_{k}^{j},{\mathbf{\psi }}_{o}^{j}}\right) }. \tag{14}
$$

Finally, the stationary probability across the multi-view hypergraph is computed as:

最后，跨多视图超图的平稳概率计算如下:

$$
\pi \left( k\right)  = \mathop{\sum }\limits_{{i \in  \{ \mathcal{X},\mathcal{V},\mathcal{A}\} }}\pi \left( {k \mid  {\mathcal{G}}^{i}}\right)  \cdot  p\left( {\mathcal{G}}^{i}\right)  \tag{15}
$$

$$
+ \mathop{\sum }\limits_{{i, j \in  \{ \mathcal{X},\mathcal{V},\mathcal{A}\} , i \neq  j}}\pi \left( {k \mid  {\mathcal{G}}^{ij}}\right)  \cdot  p\left( {\mathcal{G}}^{ij}\right) . \tag{16}
$$

Given the defined graphs and random walk process, we can derive our label propagation algorithm (TMV-HLP). Let $P$ denote the transition probability matrix defined by Eq. (9) and $\Pi$ the diagonal matrix with the elements $\pi \left( k\right)$ computed by Eq. (15). The Laplacian matrix $\mathcal{L}$ combines information of different views and is defined as: $\mathcal{L} = \Pi  - \frac{{\Pi P} + {P}^{T}\Pi }{2}$ . The label matrix $Z$ for labelled N-shot data or zero-shot prototypes is defined as:

给定已定义的图和随机游走过程，我们可以推导出我们的标签传播算法(TMV - HLP)。令 $P$ 表示由式(9)定义的转移概率矩阵，$\Pi$ 表示对角矩阵，其元素 $\pi \left( k\right)$ 由式(15)计算得出。拉普拉斯矩阵 $\mathcal{L}$ 结合了不同视图的信息，定义为:$\mathcal{L} = \Pi  - \frac{{\Pi P} + {P}^{T}\Pi }{2}$ 。用于标记的 N 样本数据或零样本原型的标签矩阵 $Z$ 定义为:

$$
Z\left( {{q}_{k}, c}\right)  = \left\{  \begin{array}{ll} 1 & {q}_{k} \in  \text{ class }c, \\   - 1 & {q}_{k} \notin  \text{ class }c, \\  0 & \text{ unknown. } \end{array}\right.  \tag{17}
$$

Given the label matrix $Z$ and Laplacian $\mathcal{L}$ , label propagation on multiple graphs has the closed-form solution [56]: $\widehat{Z} = \eta {\left( \eta \Pi  + \mathcal{L}\right) }^{-1}{\Pi Z}$ where $\eta$ is a regularisation parameter. ${}^{8}$ Note that in our framework, both labelled target class instances and prototypes are modelled as graph nodes. Thus the difference between zero-shot and N-shot learning lies only on the initial labelled instances: Zero-shot learning has the prototypes as labelled nodes; N-shot has instances as labelled nodes; and a new condition exploiting both prototypes and N-shot together is possible. This unified recognition framework thus applies when either or both of prototypes and labelled instances are available. The computational cost of our TMV-HLP is $\mathcal{O}\left( {{\left( {c}_{T} + {n}_{T}\right) }^{2} \cdot  {n}_{V}^{2} + }\right.$ $\left. {\left( {c}_{T} + {n}_{T}\right) }^{3}\right)$ , where $K$ is the number of nearest neighbours in the KNN graphs, and ${n}_{V}$ is the number of views. It costs $\mathcal{O}\left( {{\left( {c}_{T} + {n}_{T}\right) }^{2} \cdot  {n}_{V}^{2}}\right)$ to construct the heterogeneous graph, while the inverse matrix of Laplacian matrix $\mathcal{L}$ in label propagation step will take $\mathcal{O}\left( {\left( {c}_{T} + {n}_{T}\right) }^{3}\right)$ computational time, which however can be further reduced to $\mathcal{O}\left( {{c}_{T}{n}_{T}t}\right)$ using

给定标签矩阵 $Z$ 和拉普拉斯矩阵 $\mathcal{L}$ ，多图上的标签传播具有闭式解 [56]:$\widehat{Z} = \eta {\left( \eta \Pi  + \mathcal{L}\right) }^{-1}{\Pi Z}$ ，其中 $\eta$ 是一个正则化参数。${}^{8}$ 请注意，在我们的框架中，标记的目标类实例和原型都被建模为图节点。因此，零样本学习和 N 样本学习之间的区别仅在于初始标记的实例:零样本学习将原型作为标记节点；N 样本学习将实例作为标记节点；并且可以同时利用原型和 N 样本的新情况。因此，当原型和标记实例中的任一个或两者都可用时，这个统一的识别框架都适用。我们的 TMV - HLP 的计算成本为 $\mathcal{O}\left( {{\left( {c}_{T} + {n}_{T}\right) }^{2} \cdot  {n}_{V}^{2} + }\right.$ $\left. {\left( {c}_{T} + {n}_{T}\right) }^{3}\right)$ ，其中 $K$ 是 KNN 图中最近邻的数量，${n}_{V}$ 是视图的数量。构建异构图需要 $\mathcal{O}\left( {{\left( {c}_{T} + {n}_{T}\right) }^{2} \cdot  {n}_{V}^{2}}\right)$ 的时间，而标签传播步骤中拉普拉斯矩阵 $\mathcal{L}$ 的逆矩阵将需要 $\mathcal{O}\left( {\left( {c}_{T} + {n}_{T}\right) }^{3}\right)$ 的计算时间，不过使用藤原和入江 [16] 的最新研究成果可以将其进一步减少到 $\mathcal{O}\left( {{c}_{T}{n}_{T}t}\right)$ ，其中 $Z$ 是他们论文中的一个迭代参数且 $\mathcal{L}$ 。

8. It can be varied from 1-10 with little effects in our experiments. the recent work of Fujiwara and Irie [16], where $t$ is an iteration parameter in their paper and $t \ll  {n}_{T}$ .

8. 在我们的实验中，它可以在 1 - 10 之间变化，影响很小。

## 5 ANNOTATION AND BEYOND

## 5 标注及拓展

Our multi-view embedding space $\Gamma$ bridges the semantic gap between low-level features $\mathcal{X}$ and semantic representations $\mathcal{A}$ and $\mathcal{V}$ . Leveraging this cross-view mapping, annotation [17], [20], [51] can be improved and applied in novel ways. We consider three annotation tasks here:

我们的多视图嵌入空间 $\Gamma$ 弥合了低级特征 $\mathcal{X}$ 与语义表示 $\mathcal{A}$ 和 $\mathcal{V}$ 之间的语义鸿沟。利用这种跨视图映射，可以改进标注 [17]、[20]、[51] 并以新颖的方式应用。我们在此考虑三个标注任务:

Instance level annotation. Given a new instance $u$ , we can describe/annotate it by predicting its attributes. The conventional solution is directly applying ${\widehat{\mathbf{y}}}_{u}^{\mathcal{A}} = {f}^{\mathcal{A}}\left( {\mathbf{x}}_{u}\right)$ for test data ${\mathbf{x}}_{u}$ [9],[17]. However, as analysed before, this suffers from the projection domain shift problem. To alleviate this, our multi-view embedding space aligns the semantic attribute projections with the low-level features of each unlabelled instance in the target domain. This alignment can be used for image annotation in the target domain. Thus, with our framework, we can now infer attributes for any test instance via the learned embedding space $\Gamma$ as ${\widehat{\mathbf{y}}}_{u}^{A} = {\mathbf{x}}_{u}$ ${W}^{\mathcal{X}}{\widetilde{D}}^{\mathcal{X}}{\left\lbrack  {W}^{\mathcal{A}}{\widetilde{D}}^{\mathcal{A}}\right\rbrack  }^{-1}.$

实例级标注。给定一个新实例 $u$ ，我们可以通过预测其属性来描述/标注它。传统的解决方案是直接将 ${\widehat{\mathbf{y}}}_{u}^{\mathcal{A}} = {f}^{\mathcal{A}}\left( {\mathbf{x}}_{u}\right)$ 应用于测试数据 ${\mathbf{x}}_{u}$ [9]、[17]。然而，如前所述，这会受到投影域偏移问题的影响。为了缓解这个问题，我们的多视图嵌入空间将语义属性投影与目标域中每个未标记实例的低级特征对齐。这种对齐可用于目标域中的图像标注。因此，借助我们的框架，我们现在可以通过学习到的嵌入空间 $\Gamma$ 推断任何测试实例的属性，即 ${\widehat{\mathbf{y}}}_{u}^{A} = {\mathbf{x}}_{u}$ ${W}^{\mathcal{X}}{\widetilde{D}}^{\mathcal{X}}{\left\lbrack  {W}^{\mathcal{A}}{\widetilde{D}}^{\mathcal{A}}\right\rbrack  }^{-1}.$

Zero-shot class description. From a broader machine intelligence perspective, one might be interested to ask what are the attributes of an unseen class, based solely on the class name. Given our multi-view embedding space, we can infer the semantic attribute description of a novel class. This zero-shot class description task could be useful, for example, to hypothesise the zero-shot attribute prototype of a class instead of defining it by experts [27] or ontology [15]. Our transductive embedding enables this task by connecting semantic word space (i.e. naming) and discriminative attribute space (i.e. describing). Given the prototype ${\mathbf{y}}_{c}^{\mathcal{V}}$ from the name of a novel class $c$ , we compute ${\widehat{\mathbf{y}}}_{c}^{\mathcal{A}} = {\mathbf{y}}_{c}^{\mathcal{V}}{W}^{\mathcal{V}}{\widetilde{D}}^{\mathcal{V}}$ ${\left\lbrack  {W}^{\mathcal{A}}{\widetilde{D}}^{\mathcal{A}}\right\rbrack  }^{-1}$ to generate the class-level attribute description.

零样本类别描述。从更广泛的机器智能视角来看，人们可能会有兴趣探究，仅依据类别名称，一个未见类别的属性是什么。鉴于我们的多视图嵌入空间，我们能够推断出一个新类别的语义属性描述。例如，这项零样本类别描述任务可能很有用，它可以假设一个类别的零样本属性原型，而不是由专家[27]或本体[15]来定义它。我们的直推式嵌入通过连接语义词空间(即命名)和判别性属性空间(即描述)来实现这一任务。给定一个新类别 $c$ 的名称对应的原型 ${\mathbf{y}}_{c}^{\mathcal{V}}$，我们计算 ${\widehat{\mathbf{y}}}_{c}^{\mathcal{A}} = {\mathbf{y}}_{c}^{\mathcal{V}}{W}^{\mathcal{V}}{\widetilde{D}}^{\mathcal{V}}$ ${\left\lbrack  {W}^{\mathcal{A}}{\widetilde{D}}^{\mathcal{A}}\right\rbrack  }^{-1}$ 以生成类别级别的属性描述。

Zero prototype learning. This task is the inverse of the previous task-to infer the name of class given a set of attributes. It could be useful, for example, to validate or assess a proposed zero-shot attribute prototype, or to provide an automated semantic-property based index into a dictionary or database. To our knowledge, this is the first attempt to evaluate the quality of a class attribute prototype because no previous work has directly and systematically linked linguistic knowledge space with visual attribute space. Specifically given an attribute prototype ${\mathbf{y}}_{c}^{\mathcal{A}}$ , we can use ${\widehat{\mathbf{y}}}_{c}^{\mathcal{V}} =$ ${\widehat{\mathbf{y}}}_{c}^{\mathcal{A}}{W}^{\mathcal{A}}{\widetilde{D}}^{\mathcal{A}}{\left\lbrack  {W}^{\mathcal{V}}{\widetilde{D}}^{\mathcal{V}}\right\rbrack  }^{-1}$ to name the corresponding class and perform retrieval on dictionary words in $\mathcal{V}$ using ${\widehat{\mathbf{y}}}_{c}^{\mathcal{V}}$ .

零原型学习。这项任务与前一项任务相反——给定一组属性来推断类别的名称。例如，它可能有助于验证或评估一个提出的零样本属性原型，或者为字典或数据库提供一个基于自动语义属性的索引。据我们所知，这是首次尝试评估类别属性原型的质量，因为之前没有工作直接且系统地将语言知识空间与视觉属性空间联系起来。具体来说，给定一个属性原型 ${\mathbf{y}}_{c}^{\mathcal{A}}$，我们可以使用 ${\widehat{\mathbf{y}}}_{c}^{\mathcal{V}} =$ ${\widehat{\mathbf{y}}}_{c}^{\mathcal{A}}{W}^{\mathcal{A}}{\widetilde{D}}^{\mathcal{A}}{\left\lbrack  {W}^{\mathcal{V}}{\widetilde{D}}^{\mathcal{V}}\right\rbrack  }^{-1}$ 来命名相应的类别，并使用 ${\widehat{\mathbf{y}}}_{c}^{\mathcal{V}}$ 在 $\mathcal{V}$ 中的字典词上进行检索。

## 6 EXPERIMENTS

## 6 实验

### 6.1 Datasets and Settings

### 6.1 数据集和设置

We evaluate our framework on three widely used image/ video datasets: Animals with Attributes, Unstructured Social Activity Attribute (USAA), and Caltech-UCSD-Birds (CUB). ${AwA}$ [27] consists of 50 classes of animals $({30},{475}$ images) and 85 associated class-level attributes. It has a standard source/target split for zero-shot learning with 10 classes and 6,180 images held out as the target dataset. We use the same 'hand-crafted' low-level features (RGB colour histograms, SIFT, rgSIFT, PHOG, SURF and local self-similarity histograms) released with the dataset (denoted as $\mathcal{H}$ ); and the same multi-kernel learning (MKL) attribute classifier from [27]. USAA is a video dataset [15] with 69 instance-level attributes for eight classes of complex (unstructured) social group activity videos from YouTube. Each class has around 100 training and test videos respectively. USAA provides the instance-level attributes since there are significant intra-class variations. We use the thresholded mean of instances from each class to define a binary attribute prototype as in [15]. The same setting in [15] is adopted: four classes as source and four classes as target data. We use exactly the same SIFT, MFCC and STIP low-level features for USAA as in [15]. CUB-200-2011 [48] contains 11,788 images of 200 bird classes. This is more challenging than AwA-it is designed for fine-grained recognition and has more classes but fewer images. Each class is annotated with 312 binary attributes derived from a bird species ontology. We use 150 classes as auxiliary data, holding out 50 as test data. We extract 128 dimensional SIFT and colour histogram descriptors from regular grid of multi-scale and aggregate them into image-level feature Fisher Vectors(F)by using 256 Gaussians, as in [1]. Colour histogram and PHOG features are also used to extract global color and texture cues from each image. Due to the recent progress on deep learning based representations, we also extract OverFeat $\left( \mathcal{O}\right) {\left\lbrack  {42}\right\rbrack  }^{9}$ from AwA and CUB as an alternative to $\mathcal{H}$ and $\mathcal{F}$ respectively. In addition, DeCAF (D) [7] is also considered for AwA.

我们在三个广泛使用的图像/视频数据集上评估了我们的框架:动物属性数据集(Animals with Attributes)、非结构化社交活动属性数据集(Unstructured Social Activity Attribute，USAA)和加州理工学院 - 加州大学圣地亚哥分校鸟类数据集(Caltech - UCSD - Birds，CUB)。${AwA}$[27]包含50类动物$({30},{475}$图像)和85个相关的类级别属性。它有一个用于零样本学习的标准源/目标划分，其中10个类别和6180张图像作为目标数据集。我们使用与该数据集一起发布的相同的“手工制作”低级特征(RGB颜色直方图、SIFT、rgSIFT、PHOG、SURF和局部自相似性直方图)(表示为$\mathcal{H}$)；以及来自[27]的相同的多核学习(MKL)属性分类器。USAA是一个视频数据集[15]，它包含来自YouTube的八类复杂(非结构化)社交群体活动视频的69个实例级属性。每个类别分别约有100个训练视频和测试视频。由于存在显著的类内差异，USAA提供了实例级属性。我们像[15]中那样使用每个类别的实例的阈值均值来定义一个二进制属性原型。采用了[15]中的相同设置:四个类别作为源数据，四个类别作为目标数据。我们对USAA使用与[15]中完全相同的SIFT、MFCC和STIP低级特征。CUB - 200 - 2011[48]包含200类鸟类的11788张图像。这比动物属性数据集(AwA)更具挑战性——它是为细粒度识别设计的，类别更多但图像更少。每个类别都用从鸟类物种本体派生的312个二进制属性进行了标注。我们使用150个类别作为辅助数据，留出50个作为测试数据。我们从多尺度规则网格中提取128维的SIFT和颜色直方图描述符，并像[1]中那样使用256个高斯分布将它们聚合为图像级特征费舍尔向量(F)。颜色直方图和PHOG特征也用于从每个图像中提取全局颜色和纹理线索。由于基于深度学习的表示方法的最新进展，我们还分别从AwA和CUB中提取了OverFeat$\left( \mathcal{O}\right) {\left\lbrack  {42}\right\rbrack  }^{9}$，作为$\mathcal{H}$和$\mathcal{F}$的替代。此外，对于AwA，我们还考虑了深度卷积激活特征(DeCAF，D)[7]。

TABLE 1

Comparison with the State-of-the-Art on Zero-Shot Learning on AwA, USAA and CUB

在AwA、USAA和CUB数据集上的零样本学习与现有技术的比较

<table><tr><td>Approach</td><td>AwA (H [27])</td><td>AwA (0)</td><td>AwA(O, D)</td><td>USAA</td><td>CUB (0)</td><td>CUB ( $\mathcal{F}$ )</td></tr><tr><td>DAP</td><td>40.5([27])/41.4([28])/38.4*</td><td>51.0*</td><td>57.1*</td><td>33.2([15])/35.2*</td><td>26.2*</td><td>9.1*</td></tr><tr><td>IAP</td><td>27.8([27])/42.2([28])</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td></tr><tr><td>M2LATM [15]***</td><td>41.3</td><td>-</td><td>-</td><td>41.9</td><td>-</td><td>-</td></tr><tr><td>ALE/HLE/AHLE [1]</td><td>37.4 / 39.0 / 43.5</td><td>-</td><td>-</td><td>-</td><td>-</td><td>18.0*</td></tr><tr><td>Mo/Ma/O/D [38]</td><td>27.0 / 23.6 / 33.0 / 35.7</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td></tr><tr><td>PST [36]***</td><td>42.7</td><td>54.1*</td><td>62.9*</td><td>36.2*</td><td>38.3*</td><td>13.2*</td></tr><tr><td>[54]</td><td>48.3**</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td></tr><tr><td>TMV-BLP [14]***</td><td>47.7</td><td>69.9</td><td>77.8</td><td>48.2</td><td>45.2</td><td>16.3</td></tr><tr><td>TMV-HLP***</td><td>49.0</td><td>73.5</td><td>80.5</td><td>50.4</td><td>47.9</td><td>19.5</td></tr></table>

<table><tbody><tr><td>方法</td><td>AwA(H [27])</td><td>AwA(0)</td><td>AwA(O，D)</td><td>美国联合服务汽车协会(USAA)</td><td>加州大学伯克利分校数据集(CUB)(0)</td><td>加州大学伯克利分校数据集(CUB)( $\mathcal{F}$ )</td></tr><tr><td>判别式属性预测(DAP)</td><td>40.5([27])/41.4([28])/38.4*</td><td>51.0*</td><td>57.1*</td><td>33.2([15])/35.2*</td><td>26.2*</td><td>9.1*</td></tr><tr><td>生成式属性预测(IAP)</td><td>27.8([27])/42.2([28])</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td></tr><tr><td>多模态到标签注意力转移模型(M2LATM) [15]***</td><td>41.3</td><td>-</td><td>-</td><td>41.9</td><td>-</td><td>-</td></tr><tr><td>属性学习嵌入(ALE)/高阶属性学习嵌入(HLE)/自适应高阶属性学习嵌入(AHLE) [1]</td><td>37.4 / 39.0 / 43.5</td><td>-</td><td>-</td><td>-</td><td>-</td><td>18.0*</td></tr><tr><td>模型/映射/目标/数据(Mo/Ma/O/D) [38]</td><td>27.0 / 23.6 / 33.0 / 35.7</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td></tr><tr><td>概率语义转移(PST) [36]***</td><td>42.7</td><td>54.1*</td><td>62.9*</td><td>36.2*</td><td>38.3*</td><td>13.2*</td></tr><tr><td>[54]</td><td>48.3**</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td></tr><tr><td>基于主题模型向量的双线性投影(TMV - BLP) [14]***</td><td>47.7</td><td>69.9</td><td>77.8</td><td>48.2</td><td>45.2</td><td>16.3</td></tr><tr><td>基于主题模型向量的高阶投影(TMV - HLP)***</td><td>49.0</td><td>73.5</td><td>80.5</td><td>50.4</td><td>47.9</td><td>19.5</td></tr></tbody></table>

Features $\mathcal{H},\mathcal{O},\mathcal{D}$ and $\mathcal{F}$ represent hand-crafted, OverFeat, DeCAF, and Fisher Vector respectively. Mo, Ma, O and D represent the highest results by the mined object class-attribute associations, mined attributes, objectness as attributes and direct similarity methods used in [38] respectively. ‘-’; no result reported. *’ our implementation. **: requires additional human annotations. ***: requires unlabelled data, i.e. a transductive setting.

特征 $\mathcal{H},\mathcal{O},\mathcal{D}$ 和 $\mathcal{F}$ 分别代表手工特征、OverFeat特征、DeCAF特征和Fisher向量。Mo、Ma、O和D分别代表文献[38]中使用的挖掘对象类别 - 属性关联、挖掘属性、将目标性作为属性以及直接相似性方法所得到的最高结果。‘ - ’:未报告结果。*:我们的实现。**:需要额外的人工标注。***:需要未标注数据，即直推式设置。

We report absolute classification accuracy on USAA and mean accuracy for AwA and CUB for direct comparison to published results. The word vector space is trained by the model in [32] with 1,000 dimensions.

为了与已发表的结果进行直接比较，我们报告了USAA数据集上的绝对分类准确率，以及AwA和CUB数据集上的平均准确率。词向量空间由文献[32]中的模型训练得到，维度为1000。

### 6.2 Recognition by Zero-Shot Learning

### 6.2 零样本学习识别

#### 6.2.1 Comparisons with State-of-the-Art

#### 6.2.1 与现有最优方法的比较

We compare our method (TMV-HLP) with the recent state-of-the-art models that report results or can be re-implemented by us on the three datasets in Table 1. They cover a wide range of approaches on utilising semantic intermediate representation for zero-shot learning. They can be roughly categorised according to the semantic representation(s) used: DAP and IAP ([27], [28]), M2LATM [15], ALE [1], [36] and [50] use attributes only; HLE/AHLE [1] and $\mathrm{{Mo}}/\mathrm{{Ma}}/\mathrm{O}/\mathrm{D}$ [38] use both attributes and linguistic knowledge bases (same as us); [54] uses attribute and some additional human manual annotation. Note that our linguistic knowledge base representation is in the form of word vectors, which does not incur additional manual annotation. Our method also does not exploit data-driven attributes such as M2LATM [15] and Mo/Ma/O/D [38].

我们将我们的方法(TMV - HLP)与近期的最优模型进行比较，这些模型在表1中的三个数据集上报告了结果或者可以由我们重新实现。它们涵盖了利用语义中间表示进行零样本学习的广泛方法。根据所使用的语义表示，它们大致可以分为以下几类:DAP和IAP(文献[27]、[28])、M2LATM [15]、ALE(文献[1]、[36]和[50])仅使用属性；HLE/AHLE [1]和 $\mathrm{{Mo}}/\mathrm{{Ma}}/\mathrm{O}/\mathrm{D}$ [38]同时使用属性和语言知识库(与我们相同)；文献[54]使用属性和一些额外的人工手动标注。请注意，我们的语言知识库表示采用词向量的形式，不会产生额外的手动标注。我们的方法也不利用如M2LATM [15]和Mo/Ma/O/D [38]那样的数据驱动属性。

Consider first the results on the most widely used AwA. Apart from the standard hand-crafted feature(H), we consider the more powerful OverFeat deep feature(O), and a combination of OverFeat and DeCAF $\left( {\mathcal{O},\mathcal{D}}\right) .{}^{10}$ Table 1 shows that (1) with the same experimental settings and the same feature ( $\mathcal{H}$ ), our TMV-HLP (49.0 percent) outperforms the best result reported so far (48.3 percent) in [54] which, unlike ours, requires additional human annotation to relabel the similarities between auxiliary and target classes. (2) With the more powerful OverFeat feature, our method achieves 73.5 percent zero-shot recognition accuracy. Even more remarkably, when both the OverFeat and DeCAF features are used in our framework, the result (see the AwA (O, D)column) is 80.5 percent. Even with only 10 target classes, this is an extremely good result given that we do not have any labelled samples from the target classes. Note that this good result is not solely due to the feature strength, as the margin between the conventional DAP and our TMV-HLP is much bigger indicating that our TMV-HLP plays a critical role in achieving this result. (3) Our method is also superior to the AHLE method in [1] which also uses two semantic spaces: attribute and WordNet hierarchy. Different from our embedding framework, AHLE simply concatenates the two spaces. (4) Our method also outperforms the other alternatives of either mining other semantic knowledge bases (Mo/Ma/O/D [38]) or exploring data-driven attributes (M2LATM [15]). (5) Among all compared methods, PST [36] is the only one except ours that performs label propagation based transductive learning. It yields better results than DAP in all the experiments which essentially does nearest neighbour in the semantic space. TMV-HLP consistently beats PST in all the results shown in Table 1 thanks to our multi-view embedding. (6) Compared to our TMV-BLP model [14], the superior results of TMV-HLP

首先考虑在使用最广泛的AwA数据集上的结果。除了标准的手工特征(H)，我们还考虑了更强大的OverFeat深度特征(O)，以及OverFeat和DeCAF的组合 $\left( {\mathcal{O},\mathcal{D}}\right) .{}^{10}$ 表1显示:(1)在相同的实验设置和相同的特征( $\mathcal{H}$ )下，我们的TMV - HLP方法(49.0%)优于文献[54]中迄今为止报告的最佳结果(48.3%)，与我们的方法不同，文献[54]的方法需要额外的人工标注来重新标记辅助类和目标类之间的相似度。(2)使用更强大的OverFeat特征时，我们的方法实现了73.5%的零样本识别准确率。更值得注意的是，当在我们的框架中同时使用OverFeat和DeCAF特征时，结果(见AwA (O, D)列)达到了80.5%。即使只有10个目标类，考虑到我们没有来自目标类的任何标注样本，这也是一个非常好的结果。请注意，这个好结果不仅仅是由于特征的强大，因为传统的DAP方法和我们的TMV - HLP方法之间的差距更大，这表明我们的TMV - HLP方法在取得这个结果中起到了关键作用。(3)我们的方法也优于文献[1]中的AHLE方法，该方法同样使用了两个语义空间:属性空间和WordNet层次结构空间。与我们的嵌入框架不同，AHLE方法只是简单地将这两个空间拼接起来。(4)我们的方法还优于其他方法，这些方法要么挖掘其他语义知识库(Mo/Ma/O/D [38])，要么探索数据驱动属性(M2LATM [15])。(5)在所有比较的方法中，PST [36]是除我们的方法之外唯一基于标签传播进行直推式学习的方法。在所有实验中，它的结果都优于本质上是在语义空间中进行最近邻搜索的DAP方法。由于我们的多视图嵌入方法，在表1所示的所有结果中，TMV - HLP方法始终优于PST方法。(6)与我们的TMV - BLP模型[14]相比，TMV - HLP方法的结果更优

10. With these two low-level feature views, there are six views in total in the embedding space. shows that the proposed heterogeneous hypergraph is more effective than the homogeneous 2-graphs used in TMV-BLP for zero-shot learning.

10. 有了这两个低级特征视图，嵌入空间中总共有六个视图。这表明，所提出的异构超图在零样本学习方面比TMV - BLP中使用的同构2 - 图更有效。

![0195e08a-2f2a-7034-a202-61776690cc02_9_76_123_766_352_0.jpg](images/0195e08a-2f2a-7034-a202-61776690cc02_9_76_123_766_352_0.jpg)

Fig. 4. (a) Comparing soft and hard dimension weighting of CCA for AwA. (b) Contributions of CCA and label propagation on AwA. ${\Psi }^{\mathcal{A}}$ and ${\Psi }^{\mathcal{V}}$ indicate the subspaces of target data from view $\mathcal{A}$ and $\mathcal{V}$ in $\Gamma$ respectively; and LP is conducted on ${\mathcal{G}}^{\mathcal{A}}$ and ${\mathcal{G}}^{\mathcal{V}}$ respectively. Hand-crafted features are used in both experiments.

图4. (a) 比较用于AwA数据集的典型相关分析(CCA)的软维度加权和硬维度加权。(b) CCA和标签传播在AwA数据集上的作用。${\Psi }^{\mathcal{A}}$ 和 ${\Psi }^{\mathcal{V}}$ 分别表示来自 $\Gamma$ 中视图 $\mathcal{A}$ 和 $\mathcal{V}$ 的目标数据子空间；并且标签传播(LP)分别在 ${\mathcal{G}}^{\mathcal{A}}$ 和 ${\mathcal{G}}^{\mathcal{V}}$ 上进行。两个实验均使用手工特征。

Table 1 also shows that on two very different datasets: USAA video activity, and CUB fine-grained, our TMV-HLP significantly outperforms the state-of-the-art alternatives. In particular, on the more challenging CUB, 47.9 percent accuracy is achieved on 50 classes (chance level 2 percent) using the OverFeat feature. Considering the fine-grained nature and the number of classes, this is even more impressive than the 80.5 percent result on AwA.

表1还显示，在两个截然不同的数据集上:美国陆军应用实验室(USAA)视频活动数据集和加州大学伯克利分校(CUB)细粒度数据集，我们提出的多视图高阶标签传播(TMV - HLP)方法显著优于现有最先进的方法。特别是，在更具挑战性的CUB数据集上，使用OverFeat特征在50个类别上实现了47.9%的准确率(随机猜测准确率为2%)。考虑到数据集的细粒度性质和类别数量，这一结果甚至比在AwA数据集上取得的80.5%的准确率更令人印象深刻。

#### 6.2.2 Further Evaluations

#### 6.2.2 进一步评估

Effectiveness of soft weighting for CCA embedding. In this experiment, we compare the soft-weighting (Eq. (2)) of CCA embedding space $\Gamma$ (a strategy adopted in this work) with the conventional hard-weighting strategy of selecting the number of dimensions for CCA projection. Fig. 4a shows that the performance of the hard-weighting CCA depends on the number of projection dimensions selected (blue curve). In contrast, our soft-weighting strategy uses all dimensions weighted by the CCA eigenvalues, so that the important dimensions are automatically weighted more highly. The result shows that this strategy is clearly better and it is not very sensitive to the weighting parameter $\lambda$ , with choices of $\lambda  > 2$ all working well.

CCA嵌入软加权的有效性。在本实验中，我们将CCA嵌入空间 $\Gamma$ 的软加权策略(公式(2)，本工作采用的策略)与传统的为CCA投影选择维度数量的硬加权策略进行比较。图4a显示，硬加权CCA的性能取决于所选的投影维度数量(蓝色曲线)。相比之下，我们的软加权策略使用由CCA特征值加权的所有维度，从而重要维度会自动获得更高的权重。结果表明，该策略明显更优，并且对加权参数 $\lambda$ 不太敏感，$\lambda  > 2$ 的各种选择都能取得良好效果。

Contributions of individual components. There are two major components in our ZSL framework: CCA embedding and label propagation. In this experiment we investigate whether both of them contribute to the strong performance. To this end, we compare the ZSL results on AwA with label propagation and without (nearest neighbour) before and after CCA embedding. In Fig. 4b, we can see that: (i) Label propagation always helps regardless whether the views have been embedded using CCA, although its effects are more pronounced after embedding. (ii) Even without label propagation, i.e. using nearest neighbour for classification, the performance is improved by the CCA embedding. However, the improvement is bigger with label propagation. This result thus suggests that both CCA embedding and label propagation are useful, and our ZSL framework works the best when both are used.

各组件的贡献。我们的零样本学习(ZSL)框架中有两个主要组件:CCA嵌入和标签传播。在本实验中，我们研究这两个组件是否都对良好性能有贡献。为此，我们比较了在CCA嵌入前后，在AwA数据集上使用标签传播和不使用标签传播(最近邻方法)的ZSL结果。在图4b中，我们可以看到:(i) 无论视图是否使用CCA进行嵌入，标签传播总是有帮助的，尽管其效果在嵌入后更为显著。(ii) 即使不使用标签传播，即使用最近邻方法进行分类，CCA嵌入也能提高性能。然而，使用标签传播时性能提升更大。因此，这一结果表明，CCA嵌入和标签传播都很有用，并且当同时使用这两个组件时，我们的ZSL框架效果最佳。

Transductive multi-view embedding. To further validate the contribution of our transductive multi-view embedding space, we split up different views with and without embedding and the results are shown in Fig. 5. In Figs. 5a and 5c, the hand-crafted feature $\mathcal{H}$ and SIFT, MFCC and STIP low-level features are used for AwA and USAA respectively, and we compare $\mathcal{V}$ vs. $\Gamma \left( {\mathcal{X} + \mathcal{V}}\right) ,\mathcal{A}$ vs. $\Gamma \left( {\mathcal{X} + \mathcal{A}}\right)$ and $\left\lbrack  {\mathcal{V},\mathcal{A}}\right\rbrack$ vs. $\Gamma \left( {\mathcal{X} + \mathcal{V} + \mathcal{A}}\right)$ (see the caption of Fig. 5 for definitions). We use DAP for $\mathcal{A}$ and nearest neighbour for $\mathcal{V}$ and $\left\lbrack  {\mathcal{V},\mathcal{A}}\right\rbrack$ , because the prototypes of $\mathcal{V}$ are not binary vectors so DAP cannot be applied. We use TMV-HLP for $\Gamma \left( {\mathcal{X} + \mathcal{V}}\right)$ and $\Gamma \left( {\mathcal{X} + \mathcal{A}}\right)$ respectively. We highlight the following observations: (1) After transductive embedding, $\Gamma \left( {\mathcal{X} + \mathcal{V} + \mathcal{A}}\right)$ , $\Gamma \left( {\mathcal{X} + \mathcal{V}}\right)$ and $\Gamma \left( {\mathcal{X} + \mathcal{A}}\right)$ outperform $\left\lbrack  {\mathcal{V},\mathcal{A}}\right\rbrack  ,\mathcal{V}$ and $\mathcal{A}$ respectively. This means that the transductive embedding is helpful whichever semantic space is used in rectifying the projection domain shift problem by aligning the semantic views with low-level features. (2) The results of $\left\lbrack  {\mathcal{V},\mathcal{A}}\right\rbrack$ are higher than those of $\mathcal{A}$ and $\mathcal{V}$ individually, showing that the two semantic views are indeed complementary even with simple feature level fusion. Similarly, our TMV-HLP on all views $\Gamma \left( {\mathcal{X} + \mathcal{V} + \mathcal{A}}\right)$ improves individual embeddings $\Gamma \left( {\mathcal{X} + \mathcal{V}}\right)$ and $\Gamma \left( {\mathcal{X} + \mathcal{A}}\right)$ .

直推式多视图嵌入。为了进一步验证我们的直推式多视图嵌入空间的作用，我们分别对有无嵌入的不同视图进行了拆分，结果如图5所示。在图5a和图5c中，手工特征 $\mathcal{H}$ 以及SIFT(尺度不变特征变换)、MFCC(梅尔频率倒谱系数)和STIP(时空兴趣点)低级特征分别用于AwA(动物属性数据集)和USAA(未提及，可能是特定数据集)，我们比较了 $\mathcal{V}$ 与 $\Gamma \left( {\mathcal{X} + \mathcal{V}}\right) ,\mathcal{A}$ 与 $\Gamma \left( {\mathcal{X} + \mathcal{A}}\right)$ 以及 $\left\lbrack  {\mathcal{V},\mathcal{A}}\right\rbrack$ 与 $\Gamma \left( {\mathcal{X} + \mathcal{V} + \mathcal{A}}\right)$(定义见图5的说明)。我们对 $\mathcal{A}$ 使用DAP(判别式属性预测)，对 $\mathcal{V}$ 和 $\left\lbrack  {\mathcal{V},\mathcal{A}}\right\rbrack$ 使用最近邻方法，因为 $\mathcal{V}$ 的原型不是二进制向量，所以不能应用DAP。我们分别对 $\Gamma \left( {\mathcal{X} + \mathcal{V}}\right)$ 和 $\Gamma \left( {\mathcal{X} + \mathcal{A}}\right)$ 使用TMV - HLP(直推式多视图高阶标签传播)。我们着重指出以下观察结果:(1) 经过直推式嵌入后，$\Gamma \left( {\mathcal{X} + \mathcal{V} + \mathcal{A}}\right)$、$\Gamma \left( {\mathcal{X} + \mathcal{V}}\right)$ 和 $\Gamma \left( {\mathcal{X} + \mathcal{A}}\right)$ 分别优于 $\left\lbrack  {\mathcal{V},\mathcal{A}}\right\rbrack  ,\mathcal{V}$ 和 $\mathcal{A}$。这意味着无论使用哪种语义空间，直推式嵌入都有助于通过将语义视图与低级特征对齐来纠正投影域偏移问题。(2) $\left\lbrack  {\mathcal{V},\mathcal{A}}\right\rbrack$ 的结果分别高于 $\mathcal{A}$ 和 $\mathcal{V}$，这表明即使进行简单的特征级融合，这两个语义视图确实是互补的。同样，我们在所有视图 $\Gamma \left( {\mathcal{X} + \mathcal{V} + \mathcal{A}}\right)$ 上的TMV - HLP改进了单个嵌入 $\Gamma \left( {\mathcal{X} + \mathcal{V}}\right)$ 和 $\Gamma \left( {\mathcal{X} + \mathcal{A}}\right)$。

Embedding deep learning feature views also helps. In Fig. 5b three different low-level features are considered for AwA: hand-crafted(H), OverFeat(O)and DeCAF features(D). The zero-shot learning results of each individual space are indicated as ${\mathcal{V}}_{\mathcal{H}},{\mathcal{A}}_{\mathcal{H}},{\mathcal{V}}_{\mathcal{O}},{\mathcal{A}}_{\mathcal{O}},{\mathcal{V}}_{\mathcal{D}},{\mathcal{A}}_{\mathcal{D}}$ in Fig. 5b and we observe that ${\mathcal{V}}_{\mathcal{O}} > {\mathcal{V}}_{\mathcal{D}} > {\mathcal{V}}_{\mathcal{H}}$ and ${\mathcal{A}}_{\mathcal{O}} > {\mathcal{A}}_{\mathcal{D}} > {\mathcal{A}}_{\mathcal{H}}$ . That is OverFeat $>$ DeCAF $>$ hand-crafted features. It is widely reported that deep features have better performance than 'hand-crafted' features on many computer vision benchmark datasets [5], [42]. What is interesting to see here is that OverFeat $>$ DeCAF since both are based on the same convolutional neural network (CNN) model of [25]. Apart from implementation details, one significant difference is that DeCAF is pre-trained by ILSVRC2012 while OverFeat by ILSVRC2013 which contains more animal classes meaning better (more relevant) features can be learned. It is also worth pointing out that: (1) With both OverFeat and DeCAF features, the number of views to learn an embedding space increases from 3 to 9 ; and our results suggest that the more views, the better chance to solve the domain shift problem and the data become more separable as different views contain complementary information. (2) Fig. 5b shows that when all nine available views $\left( {{\mathcal{X}}_{\mathcal{H}},{\mathcal{V}}_{\mathcal{H}},{\mathcal{A}}_{\mathcal{H}},{\mathcal{X}}_{\mathcal{D}},{\mathcal{V}}_{\mathcal{D}},{\mathcal{A}}_{\mathcal{D}},{\mathcal{X}}_{\mathcal{O}},{\mathcal{V}}_{\mathcal{O}}\text{and}{\mathcal{A}}_{\mathcal{O}}}\right)$ are used for embedding, the result is significantly better than those from each individual view. Nevertheless, it is lower than that obtained by embedding views $\left( {{\mathcal{X}}_{\mathcal{D}},{\mathcal{V}}_{\mathcal{D}},{\mathcal{A}}_{\mathcal{D}},{\mathcal{X}}_{\mathcal{O}}}\right.$ , ${\mathcal{V}}_{\mathcal{O}}$ and ${\mathcal{A}}_{\mathcal{O}}$ ). This suggests that view selection may be required when a large number of views are available for learning the embedding space.

嵌入深度学习特征视图也有帮助。在图5b中，针对AwA考虑了三种不同的低级特征:手工特征(H)、OverFeat特征(O)和DeCAF特征(D)。每个单独空间的零样本学习结果在图5b中表示为 ${\mathcal{V}}_{\mathcal{H}},{\mathcal{A}}_{\mathcal{H}},{\mathcal{V}}_{\mathcal{O}},{\mathcal{A}}_{\mathcal{O}},{\mathcal{V}}_{\mathcal{D}},{\mathcal{A}}_{\mathcal{D}}$，我们观察到 ${\mathcal{V}}_{\mathcal{O}} > {\mathcal{V}}_{\mathcal{D}} > {\mathcal{V}}_{\mathcal{H}}$ 和 ${\mathcal{A}}_{\mathcal{O}} > {\mathcal{A}}_{\mathcal{D}} > {\mathcal{A}}_{\mathcal{H}}$。即OverFeat $>$ DeCAF $>$ 手工特征。许多计算机视觉基准数据集 [5]、[42] 广泛报道称，深度特征在性能上优于“手工”特征。这里有趣的是，OverFeat $>$ DeCAF，因为两者都基于文献 [25] 中的同一卷积神经网络(CNN)模型。除了实现细节外，一个显著的区别是DeCAF由ILSVRC2012预训练，而OverFeat由ILSVRC2013预训练，ILSVRC2013包含更多的动物类别，这意味着可以学习到更好(更相关)的特征。还值得指出的是:(1)使用OverFeat和DeCAF特征时，学习嵌入空间的视图数量从3个增加到9个；我们的结果表明，视图越多，解决领域偏移问题的机会就越大，并且由于不同视图包含互补信息，数据变得更易分离。(2)图5b显示，当使用所有九个可用视图 $\left( {{\mathcal{X}}_{\mathcal{H}},{\mathcal{V}}_{\mathcal{H}},{\mathcal{A}}_{\mathcal{H}},{\mathcal{X}}_{\mathcal{D}},{\mathcal{V}}_{\mathcal{D}},{\mathcal{A}}_{\mathcal{D}},{\mathcal{X}}_{\mathcal{O}},{\mathcal{V}}_{\mathcal{O}}\text{and}{\mathcal{A}}_{\mathcal{O}}}\right)$ 进行嵌入时，结果明显优于每个单独视图的结果。然而，它低于通过嵌入视图 $\left( {{\mathcal{X}}_{\mathcal{D}},{\mathcal{V}}_{\mathcal{D}},{\mathcal{A}}_{\mathcal{D}},{\mathcal{X}}_{\mathcal{O}}}\right.$、${\mathcal{V}}_{\mathcal{O}}$ 和 ${\mathcal{A}}_{\mathcal{O}}$ 获得的结果。这表明当有大量视图可用于学习嵌入空间时，可能需要进行视图选择。

![0195e08a-2f2a-7034-a202-61776690cc02_9_224_1725_1259_402_0.jpg](images/0195e08a-2f2a-7034-a202-61776690cc02_9_224_1725_1259_402_0.jpg)

Fig. 5. Effectiveness of transductive multi-view embedding. (a) zero-shot learning on AwA using only hand-crafted features; (b) zero-shot learning on AwA using hand-crafted and deep features together; (c) zero-shot learning on USAA. $\left\lbrack  {\mathcal{V},\mathcal{A}}\right\rbrack$ indicates the concatenation of semantic word and attribute space vectors. $\Gamma \left( {\mathcal{X} + \mathcal{V}}\right)$ and $\Gamma \left( {\mathcal{X} + \mathcal{A}}\right)$ mean using low-level+semantic word spaces and low-level+attribute spaces respectively to learn the embedding. $\Gamma \left( {\mathcal{X} + \mathcal{V} + \mathcal{A}}\right)$ indicates using all three views to learn the embedding.

图5. 直推式多视图嵌入的有效性。(a)仅使用手工特征在AwA上进行零样本学习；(b)同时使用手工特征和深度特征在AwA上进行零样本学习；(c)在USAA上进行零样本学习。$\left\lbrack  {\mathcal{V},\mathcal{A}}\right\rbrack$ 表示语义词和属性空间向量的拼接。$\Gamma \left( {\mathcal{X} + \mathcal{V}}\right)$ 和 $\Gamma \left( {\mathcal{X} + \mathcal{A}}\right)$ 分别表示使用低级 + 语义词空间和低级 + 属性空间来学习嵌入。$\Gamma \left( {\mathcal{X} + \mathcal{V} + \mathcal{A}}\right)$ 表示使用所有三个视图来学习嵌入。

Authorized licensed use limited to: JILIN UNIVERSITY. Downloaded on March 29,2025 at 06:13:38 UTC from IEEE Xplore. Restrictions apply.

授权许可使用仅限于:吉林大学。于2025年3月29日06:13:38 UTC从IEEE Xplore下载。适用限制条款。

![0195e08a-2f2a-7034-a202-61776690cc02_10_95_127_1518_727_0.jpg](images/0195e08a-2f2a-7034-a202-61776690cc02_10_95_127_1518_727_0.jpg)

Fig. 6. t-SNE Visualisation of (a) OverFeat view $\left( {\mathcal{X}}_{\mathcal{O}}\right)$ ,(b) attribute view $\left( {\mathcal{A}}_{\mathcal{O}}\right)$ ,(c) word vector view $\left( {\mathcal{V}}_{\mathcal{O}}\right)$ , and (d) transition probability of pairwise nodes computed by Eq. (9) of TMV-HLP in $\left( {\Gamma {\left( \mathcal{X} + \mathcal{A} + \mathcal{V}\right) }_{\mathcal{O},\mathcal{D}}}\right)$ . The unlabelled target classes are much more separable in (d).

图6. (a) OverFeat视图 $\left( {\mathcal{X}}_{\mathcal{O}}\right)$ 、(b) 属性视图 $\left( {\mathcal{A}}_{\mathcal{O}}\right)$ 、(c) 词向量视图 $\left( {\mathcal{V}}_{\mathcal{O}}\right)$ 以及 (d) 在 $\left( {\Gamma {\left( \mathcal{X} + \mathcal{A} + \mathcal{V}\right) }_{\mathcal{O},\mathcal{D}}}\right)$ 中通过式(9)计算的TMV - HLP成对节点转移概率的t - SNE可视化图。在(d)中，未标记的目标类别更易于区分。

Embedding makes target classes more separable. We employ t-SNE [47] to visualise the space ${\mathcal{X}}_{\mathcal{O}},{\mathcal{V}}_{\mathcal{O}},{\mathcal{A}}_{\mathcal{O}}$ and $\Gamma {\left( \mathcal{X} + \mathcal{A} + \mathcal{V}\right) }_{\mathcal{O},\mathcal{D}}$ in Fig. 6. It shows that even in the powerful OverFeat view, the 10 target classes are heavily overlapped (Fig. 6a). It gets better in the semantic views (Figs. 6b and 6c). However, when all 6 views are embedded, all classes are clearly separable (Fig. 6d).

嵌入操作使目标类别更易于区分。我们使用t - SNE [47]对图6中的空间 ${\mathcal{X}}_{\mathcal{O}},{\mathcal{V}}_{\mathcal{O}},{\mathcal{A}}_{\mathcal{O}}$ 和 $\Gamma {\left( \mathcal{X} + \mathcal{A} + \mathcal{V}\right) }_{\mathcal{O},\mathcal{D}}$ 进行可视化。结果表明，即使在强大的OverFeat视图中，10个目标类别也存在严重的重叠(图6a)。在语义视图中情况有所改善(图6b和图6c)。然而，当所有6个视图都进行嵌入操作后，所有类别都能清晰区分(图6d)。

Running time. In practice, for the AwA dataset with hand-crafted features, our pipeline takes less than 30 minutes to complete the zero-shot classification task (over 6,180 images) using a six core ${2.66}\mathrm{{GHz}}\mathrm{{CPU}}$ platform. This includes the time for multi-view CCA embedding and label propagation using our heterogeneous hypergraphs.

运行时间。在实际应用中，对于使用手工特征的AwA数据集，我们的流程在六核 ${2.66}\mathrm{{GHz}}\mathrm{{CPU}}$ 平台上完成零样本分类任务(处理超过6180张图像)所需时间不到30分钟。这包括多视图CCA嵌入和使用我们的异构超图进行标签传播的时间。

### 6.3 Annotation and Beyond

### 6.3 标注及拓展

In this section we evaluate our multi-view embedding space for the conventional and novel annotation tasks introduced in Section 5.

在本节中，我们评估了用于第5节介绍的传统和新颖标注任务的多视图嵌入空间。

Instance annotation by attributes. To quantify the annotation performance, we predict attributes/annotations for each target class instance for USAA, which has the largest instance level attribute variations among the three datasets. We employ two standard measures: mean average precision (mAP) and (FM) between the estimated and true annotation list. Using our multi-view embedding space, our method (FM: 0.341, mAP: 0.355) outperforms significantly the baseline of directly estimating ${\mathbf{y}}_{u}^{\mathcal{A}} = {f}^{\mathcal{A}}\left( {\mathbf{x}}_{u}\right)$ (FM: 0.299, mAP: 0.267).

通过属性进行实例标注。为了量化标注性能，我们为USAA的每个目标类实例预测属性/标注，USAA在三个数据集中具有最大的实例级属性变化。我们采用两种标准度量:平均精度均值(mAP)和估计标注列表与真实标注列表之间的F度量(FM)。使用我们的多视图嵌入空间，我们的方法(FM:0.341，mAP:0.355)显著优于直接估计 ${\mathbf{y}}_{u}^{\mathcal{A}} = {f}^{\mathcal{A}}\left( {\mathbf{x}}_{u}\right)$ 的基线方法(FM:0.299，mAP:0.267)。

Zero-shot description. In this task, we explicitly infer the attributes corresponding to a specified novel class, given only the textual name of that class without seeing any visual samples. Table 2 illustrates this for AwA. Clearly most of the top/bottom five attributes predicted for each of the 10 target classes are meaningful (in the ideal case, all top five should be true positives and all bottom five true negatives). Predicting the top-5 attributes for each class gives an F-measure of 0.236 . In comparison, if we directly select the five nearest attribute name projection to the class name projection (prototype) in the word space, the F-measure is 0.063, demonstrating the importance of learning the multi-view embedding space. In addition to providing a method to automatically-rather than manually-generate an attribute ontology, this task is interesting because even a human could find it very challenging (effectively a human has to list the attributes of a class which he has never seen or been explicitly taught about, but has only seen mentioned in text).

零样本描述。在这项任务中，仅给定指定新颖类别的文本名称，而不查看任何视觉样本，我们明确推断出与该类别对应的属性。表2展示了AwA的相关情况。显然，为10个目标类别中的每个类别预测的前/后五个属性大多是有意义的(在理想情况下，前五个应该都是真阳性，后五个应该都是真阴性)。为每个类别预测前5个属性的F度量为0.236。相比之下，如果我们直接在词空间中选择与类别名称投影(原型)最接近的五个属性名称投影，F度量为0.063，这证明了学习多视图嵌入空间的重要性。除了提供一种自动(而非手动)生成属性本体的方法外，这项任务很有趣，因为即使是人类也会觉得非常具有挑战性(实际上，人类必须列出一个他从未见过或未被明确教导过，但仅在文本中提及过的类别的属性)。

Zero prototype learning. In this task we attempt the reverse of the previous experiment: inferring a class name given a list of attributes. Table 3 illustrates this for USAA. Table 3a shows queries by the groundtruth attribute definitions of some USAA classes and the top-4 ranked list of classes returned. The estimated class names of each attribute vector are reasonable-the top-4 words are either the class name or related to the class name. A baseline is to use the textual names of the attributes projected in the word space (summing their word vectors) to search for the nearest classes in word space, instead of the embedding space. Table 3a shows that the predicted classes in this case are reasonable, but significantly worse than querying via the embedding space. To quantify this we evaluate the average rank of the true name for each USAA class when queried by its attributes. For querying by embedding space, the average rank is an impressive 2.13 (out of ${4.33}\mathrm{M}$ words with a chance-level rank of 2.17 M), compared with the average rank of 110.24 by directly querying word space [32] with textual descriptions of the attributes. Table 3b shows an example of "incremental" query using the ontology definition of birthday party [15]. We first query the 'wrapped presents' attribute only, followed by adding 'small balloon' and all other attributes ('birthday songs and 'birthday caps'). The changing list of top ranked retrieved words intuitively reflects the expectation of the combinatorial meaning of the attributes.

零原型学习。在这项任务中，我们尝试进行与之前实验相反的操作:根据属性列表推断类名。表3以美国汽车协会(USAA)为例进行了说明。表3a展示了根据一些美国汽车协会类别的真实属性定义进行的查询，以及返回的排名前4的类别列表。每个属性向量的估计类名是合理的——排名前4的词要么是类名，要么与类名相关。一种基线方法是使用投影到词空间中的属性文本名称(将它们的词向量相加)在词空间中搜索最近的类别，而不是在嵌入空间中搜索。表3a显示，在这种情况下预测的类别是合理的，但明显比通过嵌入空间进行查询的结果差。为了量化这一点，我们评估了每个美国汽车协会类别在通过其属性进行查询时其真实名称的平均排名。通过嵌入空间进行查询时，平均排名达到了令人印象深刻的2.13(在${4.33}\mathrm{M}$个词中，随机水平排名为2.17 M)，而直接使用属性的文本描述在词空间中进行查询[32]的平均排名为110.24。表3b展示了一个使用生日派对本体定义进行“增量式”查询的示例[15]。我们首先仅查询“包装好的礼物”属性，然后添加“小气球”和所有其他属性(“生日歌曲”和“生日帽”)。排名靠前的检索词列表的变化直观地反映了对属性组合含义的预期。

TABLE 2

Zero-Shot Description of 10 AwA Target Classes

10个动物属性数据集(AwA)目标类别的零样本描述

<table><tr><td>AwA</td><td/><td>Attributes</td></tr><tr><td rowspan="2">pc</td><td>T-5</td><td>active, furry, tail, paws, ground.</td></tr><tr><td>B-5</td><td>swims, hooves, long neck, horns, arctic</td></tr><tr><td>hp</td><td>T-5 B-5</td><td>old world, strong, quadrupedal, fast, walks red, plankton, skimmers, stripes, tunnels</td></tr><tr><td>lp</td><td>T-5 B-5</td><td>old world, active, fast, quadrupedal, muscle plankton, arctic, insects, hops, tunnels</td></tr><tr><td>hw</td><td>T-5 B-5</td><td>fish, smart, fast, group, flippers hops, grazer, tunnels, fields, plains</td></tr><tr><td>seal</td><td>T-5 B-5</td><td>old world, smart, fast, chew teeth, strong fly, insects, tree, hops, tunnels</td></tr><tr><td>cp</td><td>T-5 B-5</td><td>fast, smart, chew teeth, active, brown tunnels, hops, skimmers, fields, long neck</td></tr><tr><td rowspan="2">rat</td><td>T-5</td><td>active, fast, furry, new world, paws</td></tr><tr><td>B-5</td><td>arctic, plankton, hooves, horns, long neck</td></tr><tr><td rowspan="2">gp</td><td>T-5</td><td>quadrupedal, active, old world, walks, furry</td></tr><tr><td>B-5</td><td>tunnels, skimmers, long neck, blue, hops</td></tr><tr><td rowspan="2">pig</td><td>T-5</td><td>quadrupedal, old world, ground, furry, chew teeth</td></tr><tr><td>B-5</td><td>desert, long neck, orange, blue, skimmers</td></tr><tr><td rowspan="2">rc</td><td>T-5</td><td>fast, active, furry, quadrupedal, forest</td></tr><tr><td>B-5</td><td>long neck, desert, tusks, skimmers, blue</td></tr></table>

<table><tbody><tr><td>呜呜呜</td><td></td><td>属性</td></tr><tr><td rowspan="2">个人电脑</td><td>T-5</td><td>活跃、毛茸茸、有尾巴、有爪子、在地面上。</td></tr><tr><td>B-5</td><td>会游泳、有蹄子、长脖子、有角、生活在北极</td></tr><tr><td>生命值</td><td>T - 5 B - 5</td><td>旧世界、强壮、四足动物、速度快、行走、红色、浮游生物、撇水鸟、条纹、有洞穴</td></tr><tr><td>低级点数</td><td>T - 5 B - 5</td><td>旧世界、活跃、速度快、四足动物、肌肉浮游生物、北极、昆虫、跳跃、有洞穴</td></tr><tr><td>硬件</td><td>T - 5 B - 5</td><td>鱼类、聪明、速度快、群居、有鳍状肢、跳跃、食草动物、有洞穴、田野、平原</td></tr><tr><td>海豹</td><td>T - 5 B - 5</td><td>旧世界、聪明、速度快、会咀嚼、强壮、会飞、昆虫、树木、跳跃、有洞穴</td></tr><tr><td>控制点数</td><td>T - 5 B - 5</td><td>速度快、聪明、会咀嚼、活跃、棕色、有洞穴、跳跃、撇水鸟、田野、长脖子</td></tr><tr><td rowspan="2">老鼠</td><td>T-5</td><td>活跃、速度快、毛茸茸、新世界、有爪子</td></tr><tr><td>B-5</td><td>北极、浮游生物、蹄子、角、长脖子</td></tr><tr><td rowspan="2">通用点数</td><td>T-5</td><td>四足动物、活跃、旧世界、会行走、毛茸茸</td></tr><tr><td>B-5</td><td>洞穴、撇水鸟、长脖子、蓝色、跳跃</td></tr><tr><td rowspan="2">猪</td><td>T-5</td><td>四足动物、旧世界、在地面上、毛茸茸、会咀嚼</td></tr><tr><td>B-5</td><td>沙漠、长脖子、橙色、蓝色、撇水鸟</td></tr><tr><td rowspan="2">远程控制</td><td>T-5</td><td>速度快、活跃、毛茸茸、四足动物、森林</td></tr><tr><td>B-5</td><td>长脖子、沙漠、獠牙、撇水鸟、蓝色</td></tr></tbody></table>

$\Gamma$ is learned using six views $\left( {{\mathcal{X}}_{\mathcal{D}},{\mathcal{V}}_{\mathcal{D}},{\mathcal{A}}_{\mathcal{D}},{\mathcal{X}}_{\mathcal{O}},{\mathcal{V}}_{\mathcal{O}}\text{and}{\mathcal{A}}_{\mathcal{O}}}\right)$ . The true positives are highlighted in bold. pc, hp, lp, hw, cp, gp, and rc are short for Persian cat, hippopotamus, leopard, humpback whale, chimpanzee, giant panda, and raccoon respectively. T-5/B-5 are the top/bottom five attributes predicted for each target class.

$\Gamma$ 是使用六个视图 $\left( {{\mathcal{X}}_{\mathcal{D}},{\mathcal{V}}_{\mathcal{D}},{\mathcal{A}}_{\mathcal{D}},{\mathcal{X}}_{\mathcal{O}},{\mathcal{V}}_{\mathcal{O}}\text{and}{\mathcal{A}}_{\mathcal{O}}}\right)$ 学习得到的。真阳性结果用粗体突出显示。pc、hp、lp、hw、cp、gp 和 rc 分别是波斯猫(Persian cat)、河马(hippopotamus)、豹(leopard)、座头鲸(humpback whale)、黑猩猩(chimpanzee)、大熊猫(giant panda)和浣熊(raccoon)的缩写。T - 5/B - 5 是为每个目标类别预测的前/后五个属性。

## 7 CONCLUSIONS

## 7 结论

We identified the challenge of projection domain shift in zero-shot learning and presented a new framework to solve it by rectifying the biased projections in a multi-view embedding space. We also proposed a novel label-propagation algorithm TMV-HLP based on heterogeneous across-view hypergraphs. TMV-HLP synergistically exploits multiple intermediate semantic representations, as well as the manifold structure of unlabelled target data to improve recognition in a unified way for zero shot, $\mathrm{N}$ -shot and zero $+ \mathrm{N}$ shot learning tasks. As a result we achieved state-of-the-art performance on the challenging AwA, CUB and USAA datasets. Finally, we demonstrated that our framework enables novel tasks of relating textual class names and their semantic attributes.

我们确定了零样本学习中投影域偏移的挑战，并提出了一个新的框架，通过纠正多视图嵌入空间中的有偏投影来解决该问题。我们还提出了一种基于异构跨视图超图的新型标签传播算法 TMV - HLP。TMV - HLP 协同利用多个中间语义表示以及未标记目标数据的流形结构，以统一的方式提高零样本、$\mathrm{N}$ 样本和零 $+ \mathrm{N}$ 样本学习任务的识别能力。因此，我们在具有挑战性的 AwA、CUB 和 USAA 数据集上取得了最先进的性能。最后，我们证明了我们的框架能够实现将文本类名与其语义属性相关联的新任务。

A number of directions have been identified for future work. First, we employ CCA for learning the embedding space. Although it works well, other embedding frameworks can be considered (e.g. [49]). In the current pipeline, low-level features are first projected onto different semantic views before embedding. It should be possible to develop a unified embedding framework to combine these two steps. Second, under a realistic lifelong learning setting [6], an unlabelled data point could either belong to a seen/auxiliary category or an unseen class. An ideal framework should be able to classify both seen and unseen classes [44]. Finally, our results suggest that more views, either manually defined (attributes), extracted from a linguistic corpus (word space), or learned from visual data (deep features), can potentially give rise to better embedding space. More investigation is needed on how to systematically design and select semantic views for embedding.

已经确定了未来工作的多个方向。首先，我们采用典型相关分析(CCA)来学习嵌入空间。虽然它效果良好，但也可以考虑其他嵌入框架(例如 [49])。在当前的流程中，低级特征在嵌入之前首先被投影到不同的语义视图上。应该有可能开发一个统一的嵌入框架来结合这两个步骤。其次，在现实的终身学习环境 [6] 中，一个未标记的数据点可能属于已见/辅助类别或未见类别。一个理想的框架应该能够对已见和未见类别进行分类 [44]。最后，我们的结果表明，更多的视图，无论是手动定义的(属性)、从语言语料库中提取的(词空间)还是从视觉数据中学习到的(深度特征)，都有可能产生更好的嵌入空间。需要进一步研究如何系统地设计和选择用于嵌入的语义视图。

TABLE 3

Zero Prototype Learning on USAA

USAA 上的零原型学习

<table><tr><td>(a) Query by GT attributes of</td><td>Query via embedding space</td><td>Query attribute words in word space</td></tr><tr><td>graduation party</td><td>party, graduation, audience, caucus</td><td>cheering, proudly, dressed, wearing</td></tr><tr><td>music_performance</td><td>music, performance, musical, heavy metal</td><td>sing, singer, sang, dancing</td></tr><tr><td>wedding_ceremony</td><td>wedding_ceremony, wedding, glosses, stag</td><td>nun, christening, bridegroom, wedding_ceremony</td></tr><tr><td>(b) Attribute query</td><td colspan="2">Top ranked words</td></tr><tr><td>wrapped presents</td><td colspan="2" rowspan="3">music; performance; solo_performances; performing wedding; wedding_reception; birthday_celebration; birthday birthday_party; prom; wedding reception</td></tr><tr><td>+small balloon</td></tr><tr><td>+birthday song +birthday caps</td></tr></table>

<table><tbody><tr><td>(a) 通过<b1>的GT属性进行查询</b1></td><td>通过嵌入空间进行查询</td><td>在词空间中查询属性词</td></tr><tr><td>毕业派对</td><td>派对、毕业、观众、核心小组</td><td>欢呼、自豪地、穿着、戴着</td></tr><tr><td>音乐表演</td><td>音乐、表演、音乐的、重金属</td><td>唱歌、歌手、唱(过去式)、跳舞</td></tr><tr><td>婚礼仪式</td><td>婚礼仪式、婚礼、光泽、 stag(单身派对)</td><td>修女、洗礼、新郎、婚礼仪式</td></tr><tr><td>(b) 属性查询</td><td colspan="2">排名靠前的词</td></tr><tr><td>包装好的礼物</td><td colspan="2" rowspan="3">音乐；表演；个人表演；婚礼表演；婚礼招待会；生日庆祝；生日派对；毕业舞会；婚礼招待会</td></tr><tr><td>+小气球</td></tr><tr><td>+生日歌 +生日帽</td></tr></tbody></table>

(a) Querying classes by groundtruth (GT) attribute definitions of the specified classes. (b) An incrementally constructed attribute query for the birthday_party class. Bold indicates true positive.

(a) 通过指定类别的真实标签(GT)属性定义来查询类别。(b) 为生日派对(birthday_party)类别逐步构建的属性查询。粗体表示真阳性。

Authorized licensed use limited to: JILIN UNIVERSITY. Downloaded on March 29,2025 at 06:13:38 UTC from IEEE Xplore. Restrictions apply.

授权许可使用仅限于:吉林大学。于2025年3月29日协调世界时06:13:38从IEEE Xplore下载。使用受限。

## ACKNOWLEDGMENTS

## 致谢

The work was done while Yanwei Fu was at Queen Mary University of London. Yanwei Fu is the corresponding author.

这项工作是付彦伟在伦敦玛丽女王大学时完成的。付彦伟是通讯作者。

## REFERENCES

## 参考文献

[1] Z. Akata, F. Perronnin, Z. Harchaoui, and C. Schmid, "Label-embedding for attribute-based classification," in Proc. IEEE Conf. Comput. Vis. Pattern Recog., 2013, pp. 819-826.

[1] Z. Akata、F. Perronnin、Z. Harchaoui和C. Schmid，“基于属性分类的标签嵌入”，收录于《IEEE计算机视觉与模式识别会议论文集》，2013年，第819 - 826页。

[2] Y. Bengio, "Learning deep architectures for AI," Found. Trends Mach. Learn., vol. 2, pp. 1-127, 2009.

[2] Y. Bengio，“为人工智能学习深度架构”，《机器学习基础与趋势》，第2卷，第1 - 127页，2009年。

[3] I. Biederman, "Recognition by components-A theory of human image understanding," Psychological Rev., vol. 94, pp. 115-147, 1987.

[3] I. Biederman，“成分识别——人类图像理解理论”，《心理学评论》，第94卷，第115 - 147页，1987年。

[4] P. F. Brown, V. J. Pietra, P. V. deSouza, J. C. Lai, and R. L. Mercer, "Class-based n-gram models of natural language," J. Comput. Linguistics, vol. 18, pp. 467-479, 1992.

[4] P. F. Brown、V. J. Pietra、P. V. deSouza、J. C. Lai和R. L. Mercer，“基于类别的自然语言n - 元语法模型”，《计算语言学杂志》，第18卷，第467 - 479页，1992年。

[5] K. Chatfield, K. Simonyan, A. Vedaldi, and A. Zisserman, "Return of the devil in the details: Delving deep into convolutional nets," ArXiv e-prints, 2014.

[5] K. Chatfield、K. Simonyan、A. Vedaldi和A. Zisserman，“细节决定成败:深入研究卷积网络”，预印本，2014年。

[6] X. Chen, A. Shrivastava, and A. Gupta, "NEIL: Extracting visual knowledge from web data," in Proc. IEEE Int. Conf. Comput. Vis., 2013, pp. 1409-1416.

[6] X. Chen、A. Shrivastava和A. Gupta，“NEIL:从网络数据中提取视觉知识”，收录于《IEEE国际计算机视觉会议论文集》，2013年，第1409 - 1416页。

[7] J. Donahue, Y. Jia, O. Vinyals, J. Hoffman, N. Zhang, E. Tzeng, and T. Darrell, "DeCAF: A deep convolutional activation feature for generic visual recognition," CoRR, abs/1310.1531, 2013.

[7] J. Donahue、Y. Jia、O. Vinyals、J. Hoffman、N. Zhang、E. Tzeng和T. Darrell，“DeCAF:用于通用视觉识别的深度卷积激活特征”，预印本，编号abs/1310.1531，2013年。

[8] L. Duan, I. W. Tsang, D. Xu, and S. J. Maybank, "Domain transfer SVM for video concept detection," in Proc. IEEE Conf. Comput. Vis. Pattern Recog., 2009, pp. 1375-1381.

[8] L. Duan、I. W. Tsang、D. Xu和S. J. Maybank，“用于视频概念检测的域转移支持向量机”，收录于《IEEE计算机视觉与模式识别会议论文集》，2009年，第1375 - 1381页。

[9] A. Farhadi, I. Endres, D. Hoiem, and D. Forsyth, "Describing objects by their attributes," in Proc. IEEE Conf. Comput. Vis. Pattern Recog., 2009, pp. 1778-1785.

[9] A. Farhadi、I. Endres、D. Hoiem和D. Forsyth，“通过属性描述对象”，收录于《IEEE计算机视觉与模式识别会议论文集》，2009年，第1778 - 1785页。

[10] B. Fernando, A. Habrard, M. Sebban, and T. Tuytelaars, "Unsupervised visual domain adaptation using subspace alignment," in Proc. IEEE Int. Conf. Comput. Vis., 2013, pp. 2960-2967.

[10] B. Fernando、A. Habrard、M. Sebban和T. Tuytelaars，“使用子空间对齐的无监督视觉域适应”，收录于《IEEE国际计算机视觉会议论文集》，2013年，第2960 - 2967页。

[11] A. Frome, G. S. Corrado, J. Shlens, S. Bengio, J. Dean, M. Ranzato, and T. Mikolov, "DeViSE: A deep visual-semantic embedding model," in Proc. Adv. Neural Inf. Process. Syst., 2013, pp. 2121-2129.

[11] A. Frome、G. S. Corrado、J. Shlens、S. Bengio、J. Dean、M. Ranzato和T. Mikolov，“DeViSE:深度视觉 - 语义嵌入模型”，收录于《神经信息处理系统进展会议论文集》，2013年，第2121 - 2129页。

[12] Y. Fu, Y. Guo, Y. Zhu, F. Liu, C. Song, and Z.-H. Zhou, "Multiview video summarization," IEEE Trans. Multimedia, vol. 12, no. 7, pp. 717-729, Nov. 2010.

[12] 傅宇(Y. Fu)、郭宇(Y. Guo)、朱宇(Y. Zhu)、刘峰(F. Liu)、宋超(C. Song)和周志华(Z.-H. Zhou)，“多视图视频摘要”，《IEEE多媒体汇刊》(IEEE Trans. Multimedia)，第12卷，第7期，第717 - 729页，2010年11月。

[13] Y. Fu, T. Hospedales, T. Xiang, and S. Gong, "Attribute learning for understanding unstructured social activity," in Proc. 12th Eur. Conf. Comput. Vis., 2012, pp. 530-543.

[13] 傅宇(Y. Fu)、霍斯佩代尔斯(T. Hospedales)、向涛(T. Xiang)和龚少晖(S. Gong)，“用于理解非结构化社交活动的属性学习”，收录于《第12届欧洲计算机视觉会议论文集》(Proc. 12th Eur. Conf. Comput. Vis.)，2012年，第530 - 543页。

[14] Y. Fu, T. M. Hospedales, T. Xiang, Z. Fu, and S. Gong, "Transductive multi-view embedding for zero-shot recognition and annotation," Computer Vision-ECCV 2014 Lecture Notes in Computer Science, vol. 8690, pp. 584-599, 2014.

[14] 傅宇(Y. Fu)、霍斯佩代尔斯(T. M. Hospedales)、向涛(T. Xiang)、傅智(Z. Fu)和龚少晖(S. Gong)，“用于零样本识别和标注的直推式多视图嵌入”，《计算机视觉 - ECCV 2014计算机科学讲义》(Computer Vision - ECCV 2014 Lecture Notes in Computer Science)，第8690卷，第584 - 599页，2014年。

[15] Y. Fu, T. M. Hospedales, T. Xiang, and S. Gong, "Learning multimodal latent attributes," IEEE Trans. Pattern Anal. Mach. Intell., vol. 36, no. 2, pp. 303-316, Feb. 2014.

[15] 傅宇(Y. Fu)、霍斯佩代尔斯(T. M. Hospedales)、向涛(T. Xiang)和龚少晖(S. Gong)，“学习多模态潜在属性”，《IEEE模式分析与机器智能汇刊》(IEEE Trans. Pattern Anal. Mach. Intell.)，第36卷，第2期，第303 - 316页，2014年2月。

[16] Y. Fujiwara and G. Irie, "Efficient label propagation," in Proc. 31st Int. Conf. Mach. Learning, 2014, pp. 784-792.

[16] 藤原洋(Y. Fujiwara)和入江刚(G. Irie)，“高效标签传播”，收录于《第31届国际机器学习会议论文集》(Proc. 31st Int. Conf. Mach. Learning)，2014年，第784 - 792页。

[17] Y. Gong, Q. Ke, M. Isard, and S. Lazebnik, "A multi-view embedding space for modeling internet images, tags, and their semantics," Int. J. Comput. Vis., vol. 106, pp. 210-233, 2014.

[17] 龚宇(Y. Gong)、柯强(Q. Ke)、伊萨德(M. Isard)和拉泽布尼克(S. Lazebnik)，“用于建模互联网图像、标签及其语义的多视图嵌入空间”，《国际计算机视觉杂志》(Int. J. Comput. Vis.)，第106卷，第210 - 233页，2014年。

[18] D. R. Hardoon, S. Szedmak, and J. Shawe-Taylor, "Canonical correlation analysis: An overview with application to learning methods," Neural Comput., vol. 16, pp. 2639-2664, 2004.

[18] 哈多恩(D. R. Hardoon)、塞德马克(S. Szedmak)和肖韦 - 泰勒(J. Shawe - Taylor)，“典型相关分析:应用于学习方法的综述”，《神经计算》(Neural Comput.)，第16卷，第2639 - 2664页，2004年。

[19] C. Hong, J. Yu, J. Li, and X. Chen, "Multi-view hypergraph learning by patch alignment framework," Neurocomputing, vol. 118, pp. 79-86, 2013.

[19] 洪超(C. Hong)、余杰(J. Yu)、李军(J. Li)和陈翔(X. Chen)，“基于补丁对齐框架的多视图超图学习”，《神经计算》(Neurocomputing)，第118卷，第79 - 86页，2013年。

[20] T. Hospedales, S. Gong, and T. Xiang, "Learning tags from unsegmented videos of multiple human actions," in Proc. IEEE 11th Int. Conf. Data Mining, 2011, pp. 251-259.

[20] 霍斯佩代尔斯(T. Hospedales)、龚少晖(S. Gong)和向涛(T. Xiang)，“从多人动作的未分割视频中学习标签”，收录于《IEEE第11届国际数据挖掘会议论文集》(Proc. IEEE 11th Int. Conf. Data Mining)，2011年，第251 - 259页。

[21] Y. Huang, Q. Liu, and D. Metaxas, "Video object segmentation by hypergraph cut," in Proc. IEEE Conf. Comput. Vis. Patern Recog., 2009, pp. 1738-1745.

[21] 黄毅(Y. Huang)、刘奇(Q. Liu)和梅塔克萨斯(D. Metaxas)，“通过超图切割进行视频对象分割”，收录于《IEEE计算机视觉与模式识别会议论文集》(Proc. IEEE Conf. Comput. Vis. Patern Recog.)，2009年，第1738 - 1745页。

[22] Y. Huang, Q. Liu, S. Zhang, and D. N. Metaxas, "Image retrieval via probabilistic hypergraph ranking," in Proc. IEEE Conf. Comput. Vis. Pattern Recog., 2010, pp. 3376-3383.

[22] 黄毅(Y. Huang)、刘奇(Q. Liu)、张帅(S. Zhang)和梅塔克萨斯(D. N. Metaxas)，“通过概率超图排序进行图像检索”，收录于《IEEE计算机视觉与模式识别会议论文集》(Proc. IEEE Conf. Comput. Vis. Pattern Recog.)，2010年，第3376 - 3383页。

[23] S. J. Hwang and K. Grauman, "Learning the relative importance of objects from tagged images for retrieval and cross-modal search," Int. J. Comput. Vis., vol. 100, pp. 134-153, 2011.

[23] 黄圣俊(S. J. Hwang)和格劳曼(K. Grauman)，“从带标签图像中学习对象的相对重要性以用于检索和跨模态搜索”，《国际计算机视觉杂志》(Int. J. Comput. Vis.)，第100卷，第134 - 153页，2011年。

[24] S. J. Hwang, F. Sha, and K. Grauman, "Sharing features between objects and their attributes," in Proc. IEEE Conf. Comput. Vis. Pat-

[24] 黄圣俊(S. J. Hwang)、沙峰(F. Sha)和格劳曼(K. Grauman)，“对象及其属性之间的特征共享”，收录于《IEEE计算机视觉与模式识别会议论文集》(Proc. IEEE Conf. Comput. Vis. Pat -

tern Recog., 2011, pp. 1761-1768.

tern Recog.)，2011年，第1761 - 1768页。

[25] A. Krizhevsky, I. Sutskever, and G. E. Hinton, "Imagenet classification with deep convolutional neural networks," in Proc. Adv. Neural Inf. Process. Syst., 2012, pp. 1097-1105.

[25] 克里兹维茨基(A. Krizhevsky)、苏斯克维(I. Sutskever)和辛顿(G. E. Hinton)，“使用深度卷积神经网络进行ImageNet分类”，收录于《神经信息处理系统进展会议论文集》(Proc. Adv. Neural Inf. Process. Syst.)，2012年，第1097 - 1105页。

[26] C. H. Lampert, "Kernel methods in computer vision," Found. Trends Comput. Graph. Vis., vol. 4, pp. 193-285, 2009.

[26] 兰佩特(C. H. Lampert)，“计算机视觉中的核方法”，《计算机图形与视觉基础与趋势》(Found. Trends Comput. Graph. Vis.)，第4卷，第193 - 285页，2009年。

[27] C. H. Lampert, H. Nickisch, and S. Harmeling, "Learning to detect unseen object classes by between-class attribute transfer," in Proc. IEEE Conf. Comput. Vis. Pattern Recog., 2009, pp. 951-958.

[27] C. H. 兰珀特(C. H. Lampert)、H. 尼克施(H. Nickisch)和 S. 哈梅林(S. Harmeling)，“通过类间属性转移学习检测未见物体类别”，收录于《电气与电子工程师协会计算机视觉与模式识别会议论文集》(Proc. IEEE Conf. Comput. Vis. Pattern Recog.)，2009 年，第 951 - 958 页。

[28] C. H. Lampert, H. Nickisch, and S. Harmeling, "Attribute-based classification for zero-shot visual object categorization," IEEE Trans. Pattern Anal. Mach. Intell., vol. 36, no. 3, pp. 453-465, Mar. 2014.

[28] C. H. 兰珀特(C. H. Lampert)、H. 尼克施(H. Nickisch)和 S. 哈梅林(S. Harmeling)，“基于属性的零样本视觉物体分类”，《电气与电子工程师协会模式分析与机器智能汇刊》(IEEE Trans. Pattern Anal. Mach. Intell.)，第 36 卷，第 3 期，第 453 - 465 页，2014 年 3 月。

[29] X. Li, W. Hu, C. Shen, A. Dick, and Z. Zhang, "Context-aware hypergraph construction for robust spectral clustering," IEEE Trans. Knowl. Data Eng., vol. 26, no. 10, pp. 2588-2597, Oct. 2014.

[29] 李 X(X. Li)、胡 W(W. Hu)、沈 C(C. Shen)、迪克 A(A. Dick)和张 Z(Z. Zhang)，“用于鲁棒谱聚类的上下文感知超图构建”，《电气与电子工程师协会知识与数据工程汇刊》(IEEE Trans. Knowl. Data Eng.)，第 26 卷，第 10 期，第 2588 - 2597 页，2014 年 10 月。

[30] X. Li, Y. Li, C. Shen, A. R. Dick, and A. van den Hengel, "Contextual hypergraph modelling for salient object detection," in Proc. IEEE Int. Conf. Comput. Vis., 2013, pp. 3328-3335.

[30] 李 X(X. Li)、李 Y(Y. Li)、沈 C(C. Shen)、迪克 A. R(A. R. Dick)和范登亨格尔 A(A. van den Hengel)，“用于显著物体检测的上下文超图建模”，收录于《电气与电子工程师协会国际计算机视觉会议论文集》(Proc. IEEE Int. Conf. Comput. Vis.)，2013 年，第 3328 - 3335 页。

[31] J. Liu, B. Kuipers, and S. Savarese, "Recognizing human actions by attributes," in Proc. IEEE Conf. Comput. Vis. Pattern Recog., 2011, pp. 3337-3344.

[31] 刘 J(J. Liu)、库伊珀斯 B(B. Kuipers)和萨瓦雷塞 S(S. Savarese)，“通过属性识别人类动作”，收录于《电气与电子工程师协会计算机视觉与模式识别会议论文集》(Proc. IEEE Conf. Comput. Vis. Pattern Recog.)，2011 年，第 3337 - 3344 页。

[32] T. Mikolov, K. Chen, G. Corrado, and J. Dean, "Efficient estimation of word representation in vector space," in Proc. Workshop ICLR, 2013.

[32] T. 米科洛夫(T. Mikolov)、陈 K(K. Chen)、科拉多 G(G. Corrado)和迪恩 J(J. Dean)，“向量空间中词表示的高效估计”，收录于《学习表征研讨会论文集》(Proc. Workshop ICLR)，2013 年。

[33] M. Palatucci, G. Hinton, D. Pomerleau, and T. M. Mitchell, "Zero-shot learning with semantic output codes," in Proc. Adv. Neural Inf. Process. Syst., 2009, pp. 1410-1418.

[33] M. 帕拉图奇(M. Palatucci)、辛顿 G(G. Hinton)、波默罗伊 D(D. Pomerleau)和米切尔 T. M(T. M. Mitchell)，“使用语义输出码的零样本学习”，收录于《神经信息处理系统进展会议论文集》(Proc. Adv. Neural Inf. Process. Syst.)，2009 年，第 1410 - 1418 页。

[34] D. Parikh and K. Grauman, "Relative attributes," in Proc. IEEE Int. Conf. Comput. Vis., 2011, pp. 503-510.

[34] 帕里克 D(D. Parikh)和格劳曼 K(K. Grauman)，“相对属性”，收录于《电气与电子工程师协会国际计算机视觉会议论文集》(Proc. IEEE Int. Conf. Comput. Vis.)，2011 年，第 503 - 510 页。

[35] A. Pentina and C. H. Lampert, "A PAC-Bayesian bound for lifelong learning anastasia," in Proc. Int. Conf. Mach. Learning, 2014, pp. 991-999.

[35] A. 彭蒂娜(A. Pentina)和 C. H. 兰珀特(C. H. Lampert)，“终身学习的 PAC - 贝叶斯界”，收录于《国际机器学习会议论文集》(Proc. Int. Conf. Mach. Learning)，2014 年，第 991 - 999 页。

[36] M. Rohrbach, S. Ebert, and B. Schiele, "Transfer learning in a transductive setting," in Proc. Adv. Neural Inf. Process. Syst., 2013, pp. 46-54.

[36] M. 罗尔巴赫(M. Rohrbach)、埃伯特 S(S. Ebert)和席勒 B(B. Schiele)，“直推式设置下的迁移学习”，收录于《神经信息处理系统进展会议论文集》(Proc. Adv. Neural Inf. Process. Syst.)，2013 年，第 46 - 54 页。

[37] M. Rohrbach, M. Stark, and B. Schiele, "Evaluating knowledge transfer and zero-shot learning in a large-scale setting," in Proc. IEEE Conf. Comput. Vis. Pattern Recog., 2012, pp. 1641-1648.

[37] M. 罗尔巴赫(M. Rohrbach)、斯塔克 M(M. Stark)和席勒 B(B. Schiele)，“大规模设置下的知识迁移和零样本学习评估”，收录于《电气与电子工程师协会计算机视觉与模式识别会议论文集》(Proc. IEEE Conf. Comput. Vis. Pattern Recog.)，2012 年，第 1641 - 1648 页。

[38] M. Rohrbach, M. Stark, G. Szarvas, I. Gurevych, and B. Schiele, "What helps where- and why semantic relatedness for knowledge transfer," in Proc. IEEE Conf. Comput. Vis. Pattern Recog., 2010, pp. 910-917.

[38] M. 罗尔巴赫(M. Rohrbach)、斯塔克 M(M. Stark)、萨尔瓦斯 G(G. Szarvas)、古雷维奇 I(I. Gurevych)和席勒 B(B. Schiele)，“什么在何处起作用以及为何语义相关性对知识迁移有帮助”，收录于《电气与电子工程师协会计算机视觉与模式识别会议论文集》(Proc. IEEE Conf. Comput. Vis. Pattern Recog.)，2010 年，第 910 - 917 页。

[39] E. Rosch, "Classification of real-world objects: Origins and representations in cognition," in Thinking: Readings in Cognitive Science. Cambridge, U.K.: Cambridge Univ. Press, 1977.

[39] E. 罗施(E. Rosch)，“现实世界物体的分类:认知中的起源与表征”，收录于《思维:认知科学读物》(Thinking: Readings in Cognitive Science)。英国剑桥:剑桥大学出版社(Cambridge Univ. Press)，1977 年。

[40] R. Rosipal and N. Kramer, "Overview and recent advances in partial least squares," in Subspace, Latent Structure and Feature Selection, C. Saunders, M. Grobelnik, S. Gunn, and J. Shawe-Taylor, Eds. Berlin, Germany: Springer, 2006, pp. 34-51.

[40] R. 罗西帕尔(R. Rosipal)和克莱默 N(N. Kramer)，“偏最小二乘法概述与最新进展”，收录于《子空间、潜在结构与特征选择》(Subspace, Latent Structure and Feature Selection)，C. 桑德斯(C. Saunders)、M. 格罗贝尔尼克(M. Grobelnik)、S. 冈恩(S. Gunn)和 J. 肖韦 - 泰勒(J. Shawe - Taylor)编。德国柏林:施普林格出版社(Springer)，2006 年，第 34 - 51 页。

[41] W. J. Scheirer, N. Kumar, P. N. Belhumeur, and T. E. Boult, "Multi-attribute spaces: Calibration for attribute fusion and similarity search," in Proc. IEEE Conf. Comput. Vis. Pattern Recog., 2012, pp. 2933-2940.

[41] 谢勒 W. J(W. J. Scheirer)、库马尔 N(N. Kumar)、贝尔休默尔 P. N(P. N. Belhumeur)和博尔特 T. E(T. E. Boult)，“多属性空间:属性融合和相似度搜索的校准”，收录于《电气与电子工程师协会计算机视觉与模式识别会议论文集》(Proc. IEEE Conf. Comput. Vis. Pattern Recog.)，2012 年，第 2933 - 2940 页。

[42] P. Sermanet, D. Eigen, X. Zhang, M. Mathieu, R. Fergus, and Y. LeCun, "Overfeat: Integrated recognition, localization and detection using convolutional networks," in Proc. Int. Conf. Learning Representations, 2014.

[42] P. 塞尔马内特(P. Sermanet)、艾根 D(D. Eigen)、张 X(X. Zhang)、马蒂厄 M(M. Mathieu)、弗格斯 R(R. Fergus)和勒昆 Y(Y. LeCun)，“Overfeat:使用卷积网络的集成识别、定位与检测”，收录于《国际学习表征会议论文集》(Proc. Int. Conf. Learning Representations)，2014 年。

[43] R. Socher and L. Fei-Fei, "Connecting modalities: Semi-supervised segmentation and annotation of images using unaligned text corpora," in Proc. IEEE Conf. Comput. Vis. Pattern Recog., 2010, pp. 966-973.

[43] R. 索切尔(R. Socher)和 L. 费菲菲(L. Fei-Fei)，“连接模态:使用未对齐文本语料库进行图像的半监督分割和标注”，收录于《电气与电子工程师协会计算机视觉与模式识别会议论文集》(Proc. IEEE Conf. Comput. Vis. Pattern Recog.)，2010 年，第 966 - 973 页。

[44] R. Socher, M. Ganjoo, H. Sridhar, O. Bastani, C. D. Manning, and A. Y. Ng, "Zero-shot learning through cross-modal transfer," in Proc. Adv. Neural Inf. Process. Syst., 2013, pp. 935-943.

[44] R. 索切尔(R. Socher)、M. 甘朱(M. Ganjoo)、H. 斯里达尔(H. Sridhar)、O. 巴斯塔尼(O. Bastani)、C. D. 曼宁(C. D. Manning)和 A. Y. 吴(A. Y. Ng)，“通过跨模态转移实现零样本学习”，收录于《神经信息处理系统进展会议论文集》(Proc. Adv. Neural Inf. Process. Syst.)，2013 年，第 935 - 943 页。

[45] A. J. Storkey and M. Sugiyama, "Mixture regression for covariate shift," in Proc. Adv. Neural Inf. Process. Syst., 2007, pp. 1337-1344.

[45] A. J. 斯托基(A. J. Storkey)和 M. 杉山(M. Sugiyama)，“用于协变量偏移的混合回归”，收录于《神经信息处理系统进展会议论文集》(Proc. Adv. Neural Inf. Process. Syst.)，2007 年，第 1337 - 1344 页。

[46] L. Sun, S. Ji, and J. Ye, "Hypergraph spectral learning for multi-label classification," in Proc. 14th ACM SIGKDD Int. Conf. Knowl. Discovery Data Mining, 2008, pp. 668-676.

[46] 孙磊(L. Sun)、季士强(S. Ji)和叶杰平(J. Ye)，“用于多标签分类的超图谱学习”，收录于《第 14 届美国计算机协会知识发现与数据挖掘国际会议论文集》(Proc. 14th ACM SIGKDD Int. Conf. Knowl. Discovery Data Mining)，2008 年，第 668 - 676 页。

[47] L. van der Maaten and G. Hinton, "Visualizing high-dimensional data using t-SNE," J. Mach. Learning Res., vol. 9, pp. 2579-2605, 2008.

[47] L. 范德马坦(L. van der Maaten)和 G. 辛顿(G. Hinton)，“使用 t - 分布随机邻域嵌入(t - SNE)可视化高维数据”，《机器学习研究杂志》(J. Mach. Learning Res.)，第 9 卷，第 2579 - 2605 页，2008 年。

[48] C. Wah, S. Branson, P. Welinder, P. Perona, and S. Belongie, "The Caltech-UCSD Birds-200-2011 Dataset," California Inst. Technol., Pasadena, CA, USA, Tech. Rep. CNS-TR-2011-001, 2011.

[48] C. 瓦(C. Wah)、S. 布兰森(S. Branson)、P. 韦林德(P. Welinder)、P. 佩罗纳(P. Perona)和 S. 贝隆吉(S. Belongie)，“加州理工学院 - 加州大学圣地亚哥分校鸟类 200 - 2011 数据集”，美国加利福尼亚州帕萨迪纳市加州理工学院，技术报告 CNS - TR - 2011 - 001，2011 年。

[49] K. Wang, R. He, W. Wang, L. Wang, and T. Tan, "Learning coupled feature spaces for cross-modal matching," in Proc. IEEE Int. Conf. Comput. Vis., 2013, pp. 2088-2095.

[49] 王宽(K. Wang)、何仁(R. He)、王文(W. Wang)、王亮(L. Wang)和谭铁牛(T. Tan)，“学习用于跨模态匹配的耦合特征空间”，收录于《电气与电子工程师协会国际计算机视觉会议论文集》(Proc. IEEE Int. Conf. Comput. Vis.)，2013 年，第 2088 - 2095 页。

[50] X. Wang and Q. Ji, "A unified probabilistic approach modeling relationships between attributes and objects," in Proc. IEEE Int. Conf. Comput. Vis., 2013, pp. 2120-2127.

[50] 王鑫(X. Wang)和季强(Q. Ji)，“一种统一的概率方法对属性和对象之间的关系进行建模”，收录于《电气与电子工程师协会国际计算机视觉会议论文集》(Proc. IEEE Int. Conf. Comput. Vis.)，2013 年，第 2120 - 2127 页。

[51] Y. Wang and S. Gong, "Translating topics to words for image annotation," in Proc. 16th ACM Conf. Inf. Knowl. Manage., 2007, pp. 995-998.

[51] 王宇(Y. Wang)和龚少刚(S. Gong)，“将主题转换为单词用于图像标注”，收录于《第 16 届美国计算机协会信息与知识管理会议论文集》(Proc. 16th ACM Conf. Inf. Knowl. Manage.)，2007 年，第 995 - 998 页。

[52] D. Watts and S. Strogatz, "Collective dynamics of 'small-world' networks," Nature, vol. 393, pp. 440-442, 1998.

[52] D. 沃茨(D. Watts)和 S. 斯托加茨(S. Strogatz)，“‘小世界’网络的集体动力学”，《自然》(Nature)，第 393 卷，第 440 - 442 页，1998 年。

[53] D. J. Watts, Small Worlds: The Dynamics of Networks between Order and Randomness, 8th ed. Oakland, CA, USA: Univ. Press California, 2004.

[53] D. J. 沃茨(D. J. Watts)，《小世界:有序与随机之间的网络动力学》(Small Worlds: The Dynamics of Networks between Order and Randomness)，第 8 版。美国加利福尼亚州奥克兰市:加利福尼亚大学出版社，2004 年。

[54] F. X. Yu, L. Cao, R. S. Feris, J. R. Smith, and S.-F. Chang, "Designing category-level attributes for discriminative visual recognition," in Proc. IEEE Conf. Comput. Vis. Pattern Recog., 2013, pp. 771-778.

[54] 余峰(F. X. Yu)、曹龙兵(L. Cao)、R. S. 费里斯(R. S. Feris)、J. R. 史密斯(J. R. Smith)和张少锋(S. - F. Chang)，“为判别式视觉识别设计类别级属性”，收录于《电气与电子工程师协会计算机视觉与模式识别会议论文集》(Proc. IEEE Conf. Comput. Vis. Pattern Recog.)，2013 年，第 771 - 778 页。

[55] D. Zhou, O. Bousquet, T. N. Lal, J. Weston, and B. Schölkopf, "Learning with local and global consistency," in Proc. Adv. Inf. Process. Syst., 2004, pp. 321-328.

[55] 周登勇(D. Zhou)、O. 布斯凯(O. Bousquet)、T. N. 拉尔(T. N. Lal)、J. 韦斯顿(J. Weston)和 B. 肖尔科普夫(B. Schölkopf)，“基于局部和全局一致性的学习”，收录于《信息处理系统进展会议论文集》(Proc. Adv. Inf. Process. Syst.)，2004 年，第 321 - 328 页。

[56] D. Zhou and C. J. C. Burges, "Spectral clustering and transductive learning with multiple views," in Proc. Int. Conf. Mach. Learning, 2007, pp. 1159-1166.

[56] 周登勇(D. Zhou)和 C. J. C. 伯吉斯(C. J. C. Burges)，“多视图谱聚类和直推式学习”，收录于《国际机器学习会议论文集》(Proc. Int. Conf. Mach. Learning)，2007 年，第 1159 - 1166 页。

[57] X. Zhu, "Semi-supervised learning literature survey," Dept. Com-put. Sci., Univ. Wisconsin-Madison, Madison, WI, USA, Tech. Rep. 1530, 2007.

[57] 朱晓燕(X. Zhu)，“半监督学习文献综述”，美国威斯康星大学麦迪逊分校计算机科学系，技术报告 1530，2007 年。

![0195e08a-2f2a-7034-a202-61776690cc02_13_72_1051_231_286_0.jpg](images/0195e08a-2f2a-7034-a202-61776690cc02_13_72_1051_231_286_0.jpg)

Yanwei Fu received the PhD degree from Queen Mary University of London in 2014, and the MEng degree from the Department of Computer Science & Technology, Nanjing University in 2011, China. He is a postdoctoral researcher with Leonid Sigal in Disney Research, Pittsburgh, which is co-located with Carnegie Mellon University. His research interests include attribute learning for image and video understanding, robust learning to rank, and large-scale video summarization.

傅彦伟于 2014 年从伦敦大学玛丽皇后学院获得博士学位，并于 2011 年在中国南京大学计算机科学与技术系获得工学硕士学位。他是匹兹堡迪士尼研究院与莱昂尼德·西加尔(Leonid Sigal)合作的博士后研究员，该研究院与卡内基梅隆大学相邻。他的研究兴趣包括用于图像和视频理解的属性学习、鲁棒排序学习以及大规模视频摘要。

![0195e08a-2f2a-7034-a202-61776690cc02_13_868_128_230_283_0.jpg](images/0195e08a-2f2a-7034-a202-61776690cc02_13_868_128_230_283_0.jpg)

Timothy M. Hospedales received the PhD degree in neuroinformatics from the University of Edinburgh in 2008. He is currently a lecturer (assistant professor) of computer science at Queen Mary University of London. His research interests include probabilistic modeling and machine learning applied variously to problems in computer vision, data mining, interactive learning, and neuroscience. He has published more than 20 papers in major international journals and conferences. He is a member of the IEEE.

蒂莫西·M·霍斯佩代尔斯(Timothy M. Hospedales)于2008年在爱丁堡大学(University of Edinburgh)获得神经信息学博士学位。他目前是伦敦玛丽女王大学(Queen Mary University of London)计算机科学系的讲师(助理教授)。他的研究兴趣包括概率建模和机器学习，这些技术广泛应用于计算机视觉、数据挖掘、交互式学习和神经科学等领域的问题。他已在主要国际期刊和会议上发表了20多篇论文。他是电气与电子工程师协会(IEEE)的成员。

![0195e08a-2f2a-7034-a202-61776690cc02_13_870_482_228_279_0.jpg](images/0195e08a-2f2a-7034-a202-61776690cc02_13_870_482_228_279_0.jpg)

Tao Xiang received the PhD degree in electrical and computer engineering from the National University of Singapore in 2002. He is currently a reader (associate professor) in the School of Electronic Engineering and Computer Science, Queen Mary University of London. His research interests include computer vision and machine learning. He has published more than 100 papers in international journals and conferences and coauthored a book, Visual Analysis of Behaviour: From Pixels to Semantics.

向涛(Tao Xiang)于2002年在新加坡国立大学(National University of Singapore)获得电气与计算机工程博士学位。他目前是伦敦玛丽女王大学(Queen Mary University of London)电子工程与计算机科学学院的高级讲师(副教授)。他的研究兴趣包括计算机视觉和机器学习。他已在国际期刊和会议上发表了100多篇论文，并合著了一本书《行为的视觉分析:从像素到语义》(Visual Analysis of Behaviour: From Pixels to Semantics)。

![0195e08a-2f2a-7034-a202-61776690cc02_13_871_832_226_284_0.jpg](images/0195e08a-2f2a-7034-a202-61776690cc02_13_871_832_226_284_0.jpg)

Shaogang Gong received the DPhil in computer vision from Keble College, Oxford University in 1989. He is a professor of visual computation at Queen Mary University of London, a fellow of the Institution of Electrical Engineers and a fellow of the British Computer Society. His research interests include computer vision, machine learning, and video analysis.

龚少刚(Shaogang Gong)于1989年在牛津大学(Oxford University)凯布尔学院(Keble College)获得计算机视觉博士学位。他是伦敦玛丽女王大学(Queen Mary University of London)视觉计算领域的教授，也是电气工程师协会会士和英国计算机协会会士。他的研究兴趣包括计算机视觉、机器学习和视频分析。

$\vartriangleright$ For more information on this or any other computing topic, please visit our Digital Library at www.computer.org/publications/dlib.

$\vartriangleright$ 如需了解有关此主题或其他计算主题的更多信息，请访问我们的数字图书馆:www.computer.org/publications/dlib。