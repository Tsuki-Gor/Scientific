# Learning Attributes Equals  Multi-Source Domain Generalization

# 学习属性等同于多源领域泛化

Chuang Gan

甘闯

IIIS, Tsinghua University

清华大学交叉信息研究院

ganchuang1990@gmail.com

Tianbao Yang

杨天保

University of Iowa

爱荷华大学

tianbao-yang@uiowa.edu

Boqing Gong

龚博清

CRCV, U. of Central Florida

中佛罗里达大学计算机视觉研究中心

bgong@crcv.ucf.edu

## Abstract

## 摘要

Attributes possess appealing properties and benefit many computer vision problems, such as object recognition, learning with humans in the loop, and image retrieval. Whereas the existing work mainly pursues utilizing attributes for various computer vision problems, we contend that the most basic problem-how to accurately and robustly detect attributes from images-has been left under explored. Especially, the existing work rarely explicitly tackles the need that attribute detectors should generalize well across different categories, including those previously unseen. Noting that this is analogous to the objective of multi-source domain generalization, if we treat each category as a domain, we provide a novel perspective to attribute detection and propose to gear the techniques in multi-source domain generalization for the purpose of learning cross-category generalizable attribute detectors. We validate our understanding and approach with extensive experiments on four challenging datasets and three different problems.

属性具有吸引人的特性，并且对许多计算机视觉问题有益，例如目标识别、有人在环的学习以及图像检索。尽管现有工作主要致力于将属性用于各种计算机视觉问题，但我们认为最基本的问题——如何从图像中准确且鲁棒地检测属性——尚未得到充分探索。特别是，现有工作很少明确解决属性检测器应在不同类别(包括先前未见的类别)上具有良好泛化能力的需求。注意到如果我们将每个类别视为一个领域，这与多源领域泛化的目标类似，我们为属性检测提供了一个新的视角，并提议将多源领域泛化技术用于学习跨类别可泛化的属性检测器。我们通过在四个具有挑战性的数据集和三个不同问题上进行广泛的实验验证了我们的理解和方法。

## 1. Introduction

## 1. 引言

Visual attributes are middle-level concepts which humans use to describe objects, human faces, scenes, activities, and so on (e.g., four-legged, smiley, outdoor, and crowded). A major appeal of attributes is that they are not only human-nameable but also machine-detectable, making it possible to serve as the building blocks to describe instances $\left\lbrack  {{18},{42},{57},{55}}\right\rbrack$ , teach machines to recognize previously unseen classes by zero-shot learning [44, 52], or offer a natural human-computer interactions channel for image/video search [64, 81, 40, 70].

视觉属性是人类用于描述物体、人脸、场景、活动等的中层概念(例如，四条腿、微笑、户外、拥挤)。属性的一个主要吸引力在于它们不仅可以被人类命名，还可以被机器检测到，这使得它们有可能作为描述实例的基本元素 $\left\lbrack  {{18},{42},{57},{55}}\right\rbrack$，通过零样本学习教会机器识别先前未见的类别 [44, 52]，或者为图像/视频搜索提供自然的人机交互渠道 [64, 81, 40, 70]。

However, we contend that the long-standing pursuit after utilizing attributes for various computer vision problems has left the most basic problem-how to accurately and robustly detect attributes from images or videos-far from being solved. Especially, the existing work rarely explicitly tackles the need that attribute detectors should generalize well across different categories, including those previously unseen ones. For instance, the attribute detector "four-legged" is expected to correctly tell a giant panda is four-legged even if it is trained from the images of horses, cows, zebras, and pigs (i.e., no pandas).

然而，我们认为长期以来致力于将属性用于各种计算机视觉问题，却使得最基本的问题——如何从图像或视频中准确且鲁棒地检测属性——远未得到解决。特别是，现有工作很少明确解决属性检测器应在不同类别(包括先前未见的类别)上具有良好泛化能力的需求。例如，属性检测器“四条腿”应该能够正确判断大熊猫是四条腿的，即使它是从马、牛、斑马和猪(即没有大熊猫)的图像中训练出来的。

![0195d177-4450-77f6-a4af-980fc4fb8726_0_946_686_632_497_0.jpg](images/0195d177-4450-77f6-a4af-980fc4fb8726_0_946_686_632_497_0.jpg)

Figure 1. The boundaries between middle-level attributes and high-level object classes cross each other. We thus do not expect that the features originally learned for separating elephant, sheep, and giraffe could also be optimal for detecting the attribute "bush", which is shared by them. We propose to understand attribute detection as multi-source domain generalization and to explicitly break the class boundaries in order to learn high-quality attribute detectors.

图1. 中层属性和高层目标类别之间的边界相互交叉。因此，我们不期望最初为区分大象、绵羊和长颈鹿而学习的特征也能最适合检测它们共有的属性“灌木丛”。我们提议将属性检测理解为多源领域泛化，并明确打破类别边界，以学习高质量的属性检测器。

Indeed, most of the existing attribute detectors [44, ${18},{42},9,{32},{35},8,{10},{12},{75},{31}\rbrack$ are built using features engineered or learned for object recognition together with off-shelf machine learning classifiers-without tailoring them to reflect the idiosyncrasies of attributes. This is suboptimal; the successful techniques on object recognition do not necessarily apply to attributes learning mainly for two reasons. First, attributes are in a different semantic space as opposed to objects; they are in the middle of low-level visual cues and the high-level object labels. Second, attribute detection can even be considered as an orthogonal task to object recognition, in that attributes are shared by different objects (e.g., zebras, lions, and mice are all "furry") and distinctive attributes are present in the same object (e.g., a car is boxy and has wheels). As shown in Figure 1, the boundaries between attributes and between object categories cross each other. Therefore, we do not expect that the features originally learned for separating elephant, sheep, and giraffe could also be optimal for detecting the attribute "bush", which is shared by them.

实际上，大多数现有的属性检测器 [44, ${18},{42},9,{32},{35},8,{10},{12},{75},{31}\rbrack$ 是使用为目标识别设计或学习的特征以及现成的机器学习分类器构建的，而没有针对属性的特性进行定制。这并不是最优的；目标识别方面的成功技术不一定适用于属性学习，主要有两个原因。首先，与目标相比，属性处于不同的语义空间；它们介于低级视觉线索和高级目标标签之间。其次，属性检测甚至可以被视为与目标识别正交的任务，因为不同的目标共享属性(例如，斑马、狮子和老鼠都是“有毛的”)，并且同一目标具有不同的属性(例如，汽车是方形的且有轮子)。如图1所示，属性之间和目标类别之间的边界相互交叉。因此，我们不期望最初为区分大象、绵羊和长颈鹿而学习的特征也能最适合检测它们共有的属性“灌木丛”。

In this paper, we propose to re-examine the fundamental attribute detection problem and aim to develop an attribute-oriented feature representation, such that one can conveniently apply off-shelf classifiers to obtain high-quality attribute detectors. We expect that the detectors learned from our new representation are capable of breaking the boundaries of object categories and generalizing well across both seen and unseen classes. To this end, we cast attribute detection as a multi-source domain generalization problem $\left\lbrack  {{50},{80},{51}}\right\rbrack$ by noting that the desired properties from attributes are analogous to the objective of the latter.

在本文中，我们提议重新审视基本的属性检测问题，并旨在开发一种面向属性的特征表示，以便人们可以方便地应用现成的分类器来获得高质量的属性检测器。我们期望从我们的新表示中学习到的检测器能够打破目标类别的边界，并在已见和未见类别上都具有良好的泛化能力。为此，我们注意到属性所需的特性与多源领域泛化的目标类似，从而将属性检测视为一个多源领域泛化问题 $\left\lbrack  {{50},{80},{51}}\right\rbrack$。

Particularly, a domain refers to an underlying data distribution. Multi-source domain generalization aims to extract knowledge from several related source domains such that it is applicable to different domains, especially to those unseen at the training stage. This is in accordance with our objective for learning cross-category generalizable attributes detectors, if we consider each category as a distinctive domain.

特别地，一个领域指的是一个潜在的数据分布。多源领域泛化旨在从几个相关的源领域中提取知识，使其适用于不同的领域，特别是在训练阶段未见的领域。如果我们将每个类别视为一个独特的领域，这与我们学习跨类别可泛化属性检测器的目标是一致的。

Motivated by this observation, we employ the Unsupervised Domain-Invariant Component Analysis (UDICA) [50] as the basic building block for our approach. The key principle of UDICA is that minimizing the distributional variance of different domains-categories in our context, can improve the cross-domain (cross-category) generalization capabilities of the classifiers. A supervised extension to UDICA was introduced in [50] depending on the inverse of a covariance operator as well as some mild assumptions. However, the inverse operation is both computationally expensive and unstable in practice. We instead propose to use the alternative of centered kernel alignment [13] to account for the attribute labeling information. We show that the centered kernel alignment can be seamlessly integrated with UDICA, enabling us to learn both category-invariant and attribute-discriminative feature representations.

受这一观察结果的启发，我们采用无监督域不变分量分析(Unsupervised Domain-Invariant Component Analysis，UDICA)[50]作为我们方法的基本构建模块。UDICA的关键原则是，在我们的情境中最小化不同域 - 类别(domain - category)的分布差异，可以提高分类器的跨域(跨类别)泛化能力。文献[50]引入了一种基于协方差算子逆以及一些温和假设的UDICA监督扩展方法。然而，求逆运算在计算上既昂贵又不稳定。相反，我们建议使用中心核对齐(centered kernel alignment)[13]的方法来处理属性标签信息。我们证明了中心核对齐可以与UDICA无缝集成，使我们能够学习到既具有类别不变性又具有属性判别性的特征表示。

Our approach takes as input the features of the training images, their class (domain) labels, as well as their attribute labels. It operates upon kernels derived from the input data and learns a kernel projection to "distill" category-invariant and attribute-discriminative signals embedded in the original features. The overall output is a new feature vector for each image, which can be readily used in traditional machine learning models like SVMs for training the cross-category generalizable attribute detectors.

我们的方法将训练图像的特征、它们的类别(域)标签以及属性标签作为输入。它基于从输入数据导出的核进行操作，并学习一个核投影，以“提取”嵌入在原始特征中的类别不变和属性判别信号。总体输出是每个图像的一个新特征向量，该向量可直接用于传统机器学习模型(如支持向量机，SVM)来训练跨类别可泛化的属性检测器。

The contributions of the paper are summarized below.

本文的贡献总结如下。

- To the best of our knowledge, this work is the first attempt to tackle attribute detection from the multi-source domain generalization point of view. This enables us to explicitly model the need that the attribute detectors should transcend different categories and generalize to previously unseen ones.

- 据我们所知，这项工作是首次从多源域泛化的角度来解决属性检测问题。这使我们能够明确地建模属性检测器应超越不同类别并泛化到先前未见类别的需求。

- We introduce the centered kernel alignment to UDICA and arrive at an integrated method to strengthen the discriminative power of the learned attributes on one hand, and eliminate the domain differences between categories on the other hand.

- 我们将中心核对齐方法引入到UDICA中，得到了一种集成方法，一方面增强了所学习属性的判别能力，另一方面消除了类别之间的域差异。

- We test our approach to four datasets: Animal With Attributes [44], Caltech-UCSD Birds [76], aPascal-aYahoo [18], and UCF101 [67], and test the learned representations on three tasks: attribute detection itself, zero-shot learning, and image retrieval. Our results are significantly better than those of competitive baselines, verifying the effectiveness of the new perspective for solving attribute detection as domain generalization.

- 我们在四个数据集上测试了我们的方法:含属性动物数据集(Animal With Attributes)[44]、加州理工 - 加州大学圣地亚哥分校鸟类数据集(Caltech - UCSD Birds)[76]、aPascal - aYahoo数据集[18]和UCF101数据集[67]，并在三个任务上测试了所学习的表示:属性检测本身、零样本学习和图像检索。我们的结果明显优于具有竞争力的基线方法，验证了将属性检测作为域泛化问题解决的新视角的有效性。

The rest of this paper is organized as follows. In Section 2, we review related work in attribute detection, domain generalization, and domain adaptation. Section 3 and section 4 present the attribute learning framework. The experimental settings and evaluation results are presented in Section 5. Section 6 concludes the paper.

本文的其余部分组织如下。在第2节中，我们回顾属性检测、域泛化和域适应方面的相关工作。第3节和第4节介绍属性学习框架。实验设置和评估结果在第5节中给出。第6节对本文进行总结。

## 2. Related work and background

## 2. 相关工作和背景

Our approach is related to two separate research areas, attribute detection and domain adaptation/generalization. We unify them in this work.

我们的方法与两个独立的研究领域相关，即属性检测和域适应/泛化。我们在这项工作中将它们统一起来。

Attributes learning. Earlier work on attribute detection mainly focused on modeling the correlations among attributes [9, 32, 35, 8, 10, 12, 75, 31], localizing some special part-related attributes (e.g., tails of mammals) [4, 6, 37, 3, 83, 59, 14], and the relationship between attributes and categories [79, 48, 32, 54]. Some recent work has applied deep models to attribute detection [11, 83, 47, 16]. None of these methods explicitly model the cross-category generalization of the attributes, except the one by Farhadi et al. [18] where the authors select features within each category to downweight category-specific cues. Likely due to the fact that the attribute and category cues are interplayed, their feature selection procedure only gives limited gain. We propose to overcome this challenge by investigating all categories together and employing nonlinear mapping functions.

属性学习。早期关于属性检测的工作主要集中在对属性之间的相关性进行建模[9, 32, 35, 8, 10, 12, 75, 31]、定位一些与特定部位相关的属性(例如，哺乳动物的尾巴)[4, 6, 37, 3, 83, 59, 14]以及属性与类别之间的关系[79, 48, 32, 54]。最近一些工作将深度模型应用于属性检测[11, 83, 47, 16]。除了Farhadi等人[18]的方法(作者在每个类别中选择特征以降低特定类别线索的权重)之外，这些方法都没有明确地对属性的跨类别泛化进行建模。可能由于属性和类别线索相互影响，他们的特征选择过程只带来了有限的收益。我们建议通过一起研究所有类别并采用非线性映射函数来克服这一挑战。

Attributes possess versatile properties and benefit a wide range of challenging computer vision tasks. They serve as the basic building blocks for one to compose categories (e.g., different objects) [44, 52, 82, 17, 38, ${78},1,{34}\rbrack$ and describe instances $\left\lbrack  {{18},{42},{57},{55},{77}}\right\rbrack$ , enabling knowledge transfer between them. Attributes also reveal the rich structures underlying categories and are thus often employed to regulate machine learning models for visual recognition $\lbrack {69},{73},{45},{63},{33},{22}$ , 21, 62]. Moreover, attributes offer a natural human-computer interaction channel for visual recognition with humans in the loop [7], relevance feedback in image retrieval $\left\lbrack  {{42},{64},{55},{60},{81},{40},{58},{25},{72}}\right\rbrack$ , and active learning [41, 56, 5, 46, 43]. In this paper, we test the proposed approach on both attribute detection and its applications to zero-shot learning and image retrieval.

属性具有多种特性，并且有助于解决一系列具有挑战性的计算机视觉任务。它们是人们组合类别(例如，不同对象)[44, 52, 82, 17, 38, ${78},1,{34}\rbrack$的基本构建块，并用于描述实例$\left\lbrack  {{18},{42},{57},{55},{77}}\right\rbrack$，从而实现它们之间的知识转移。属性还揭示了类别背后丰富的结构，因此常被用于规范用于视觉识别的机器学习模型$\lbrack {69},{73},{45},{63},{33},{22}$，21, 62]。此外，属性为有人参与的视觉识别提供了一种自然的人机交互渠道[7]，用于图像检索中的相关反馈$\left\lbrack  {{42},{64},{55},{60},{81},{40},{58},{25},{72}}\right\rbrack$和主动学习[41, 56, 5, 46, 43]。在本文中，我们在属性检测及其在零样本学习和图像检索中的应用上测试了所提出的方法。

Domain generalization and adaptation. Domain generalization is still at its early developing stage. A feature projection-based algorithm, Domain-Invariant Component Analysis (DICA), was introduced in [50] to learn by minimizing the variance of the source domains. Recently, domain generation has been introduce into computer vision community for object recognition $\left\lbrack  {{80},{23}}\right\rbrack$ and video recognition [51]. We propose to gear multi-source domain generalization techniques for the purpose of learning cross-category generalizable attribute detectors. Multi-source domain adaptation $\left\lbrack  {{49},{29},{24},{71},{15}}\right\rbrack$ is related to our approach if we consider a transductive setting (i.e., the learner has access to the test data). While it assumes a single target domain, in attribute detection the test data are often sampled from more than one unseen domain.

领域泛化与适应。领域泛化仍处于早期发展阶段。文献[50]中引入了一种基于特征投影的算法——领域不变分量分析(Domain-Invariant Component Analysis，DICA)，通过最小化源领域的方差来进行学习。最近，领域生成已被引入计算机视觉领域，用于目标识别$\left\lbrack  {{80},{23}}\right\rbrack$和视频识别[51]。我们提议采用多源领域泛化技术，以学习跨类别可泛化的属性检测器。如果考虑直推式设置(即学习者可以访问测试数据)，多源领域适应$\left\lbrack  {{49},{29},{24},{71},{15}}\right\rbrack$与我们的方法相关。虽然它假设只有一个目标领域，但在属性检测中，测试数据通常是从多个未知领域中采样得到的。

### 2.1. Background on distributional variance

### 2.1. 分布方差背景

Denote by $\mathcal{H}$ and $k\left( {\cdot , \cdot  }\right)$ respectively a Reproducing Kernel Hilbert Space and its associated kernel function. For an arbitrary distribution ${P}_{y}\left( \mathbf{x}\right)$ indexed by $y \in  \mathcal{Y}$ , the following mapping,

分别用$\mathcal{H}$和$k\left( {\cdot , \cdot  }\right)$表示再生核希尔伯特空间(Reproducing Kernel Hilbert Space)及其关联的核函数。对于由$y \in  \mathcal{Y}$索引的任意分布${P}_{y}\left( \mathbf{x}\right)$，以下映射

$$
\mu \left\lbrack  {{P}_{y}\left( \mathbf{x}\right) }\right\rbrack   = \int k\left( {\mathbf{x}, \cdot  }\right) \mathrm{d}{P}_{y}\left( \mathbf{x}\right)  \triangleq  {\mu }_{y} \tag{1}
$$

is injective if $k$ is a characteristic kernel $\left\lbrack  {{66},{27},{68}}\right\rbrack$ . In other words, the kernel mean map ${\mu }_{y}$ in the RKHS $\mathcal{H}$ preserves all the statistical information of ${P}_{y}\left( \mathbf{x}\right)$ .

如果$k$是特征核$\left\lbrack  {{66},{27},{68}}\right\rbrack$，则该映射是单射的。换句话说，再生核希尔伯特空间$\mathcal{H}$中的核均值映射${\mu }_{y}$保留了${P}_{y}\left( \mathbf{x}\right)$的所有统计信息。

The distributional variance follows naturally,

分布方差自然随之而来

$$
\mathbb{V}\left( \mathcal{Y}\right)  = \frac{1}{\left| \mathcal{Y}\right| }\mathop{\sum }\limits_{{y \in  \mathcal{Y}}}{\begin{Vmatrix}{\mu }_{y} - {\mu }_{0}\end{Vmatrix}}_{\mathcal{H}}^{2},\widehat{\mathbb{V}}\left( \mathcal{Y}\right)  = \operatorname{tr}\left( {KQ}\right) , \tag{2}
$$

where ${\mu }_{0}$ is the map of the mean of all the distributions in $\mathcal{Y}$ . In practice, we do not have access to the distributions. Instead, we observe the samples ${S}_{y}, y \in  \mathcal{Y}$ each drawn from a distribution ${P}_{y}\left( \mathbf{x}\right)$ and can thus empirically estimate the distributional variance by $\widehat{\mathbb{V}}\left( \mathcal{Y}\right)  =$ $\operatorname{tr}\left( {KQ}\right)$ . Here $K$ is the (centered) ${}^{1}$ kernel matrix over all the samples, and $Q$ collects the coefficients which depend on only the numbers of samples. We refer the readers to [50] for more details including the consistency between the distributional variance $\mathbb{V}$ and its estimate $\widehat{\mathbb{V}}$ .

其中${\mu }_{0}$是$\mathcal{Y}$中所有分布的均值映射。在实践中，我们无法获取这些分布。相反，我们观察到从分布${P}_{y}\left( \mathbf{x}\right)$中抽取的样本${S}_{y}, y \in  \mathcal{Y}$，因此可以通过$\widehat{\mathbb{V}}\left( \mathcal{Y}\right)  =$ $\operatorname{tr}\left( {KQ}\right)$对分布方差进行经验估计。这里$K$是所有样本上的(中心化)${}^{1}$核矩阵，$Q$收集仅依赖于样本数量的系数。关于分布方差$\mathbb{V}$及其估计$\widehat{\mathbb{V}}$之间的一致性等更多细节，我们建议读者参考文献[50]。

## 3. Attribute detection

## 3. 属性检测

This section formalizes attribute detection and shows its in-depth connection to domain generalization.

本节对属性检测进行了形式化定义，并展示了其与领域泛化的深层次联系。

Problem statement. Suppose that we have access to an annotated dataset of $M$ images. They are in the form of $\left( {{\mathbf{x}}_{m},{\mathbf{a}}_{m},{y}_{m}}\right)$ where ${\mathbf{x}}_{m} \in  {\mathbb{R}}^{\mathrm{D}}$ is the feature vector extracted from the $m$ -th image ${I}_{m}, m \in  \left\lbrack  \mathrm{M}\right\rbrack   \triangleq$ $\{ 1,2,\cdots ,\mathrm{M}\}$ . Two types of annotations are provided for each image, the category label ${y}_{m} \in  \left\lbrack  \mathrm{C}\right\rbrack$ and the attribute annotations ${\mathbf{a}}_{m} \in  \{ 0,1{\} }^{\mathrm{A}}$ . Though we use binary attributes (e.g., the presence or absence of stripes) to in this paper for clarity, it is straightforward to extend our approach to multi-way and continuous-valued attributes. Note that a particular attribute ${\mathbf{a}}_{m}^{i}$ could appear in many categories (e.g., zebras, cows, giant pandas, lions, and mice are all furry). Moreover, there may be test images from previously unseen categories $\{ \mathrm{C} + 1,\mathrm{C} + 2,\cdots \}$ for example in zero-shot learning. Our objective is to learn accurate and robust attribute detectors $\mathcal{C}\left( {\mathbf{x}}_{m}\right)  \in  \{ 0,1{\} }^{\mathrm{A}}$ to well generalize across different categories, especially to be able to perform well on the unseen classes.

问题陈述。假设我们可以访问一个包含 $M$ 张图像的带注释数据集。这些图像的形式为 $\left( {{\mathbf{x}}_{m},{\mathbf{a}}_{m},{y}_{m}}\right)$，其中 ${\mathbf{x}}_{m} \in  {\mathbb{R}}^{\mathrm{D}}$ 是从第 $m$ 张图像 ${I}_{m}, m \in  \left\lbrack  \mathrm{M}\right\rbrack   \triangleq$ $\{ 1,2,\cdots ,\mathrm{M}\}$ 中提取的特征向量。为每张图像提供了两种类型的注释，即类别标签 ${y}_{m} \in  \left\lbrack  \mathrm{C}\right\rbrack$ 和属性注释 ${\mathbf{a}}_{m} \in  \{ 0,1{\} }^{\mathrm{A}}$。为了清晰起见，本文使用二元属性(例如，是否存在条纹)，但将我们的方法扩展到多分类和连续值属性是很直接的。请注意，特定的属性 ${\mathbf{a}}_{m}^{i}$ 可能出现在许多类别中(例如，斑马、奶牛、大熊猫、狮子和老鼠都有毛发)。此外，在零样本学习等情况下，可能存在来自先前未见过的类别 $\{ \mathrm{C} + 1,\mathrm{C} + 2,\cdots \}$ 的测试图像。我们的目标是学习准确且鲁棒的属性检测器 $\mathcal{C}\left( {\mathbf{x}}_{m}\right)  \in  \{ 0,1{\} }^{\mathrm{A}}$，以便在不同类别之间实现良好的泛化，特别是能够在未见类别上表现良好。

## Attribute detection as domain generalization

## 将属性检测视为领域泛化

-A new perspective. In this paper, we understand attribute detection as a domain generalization problem. A domain refers to an underlying data distribution. In our context, it refers to the distribution ${P}_{y}\left( {\mathbf{x},\mathbf{a}}\right)$ of a category $y \in  \left\lbrack  \mathrm{C}\right\rbrack$ over the input $\mathbf{x}$ and attribute labels $\mathbf{a}$ . As shown in Figure 2, the domains/categories are assumed to be related and are sampled from a common distribution $\mathcal{P}$ . This is reasonable considering that images and categories can often be organized in a hierarchy. Thanks to the relationships between different categories, we expect to learn new image representations for attribute detection, such that the corresponding detectors will perform well on both seen and unseen classes.

- 新视角。在本文中，我们将属性检测理解为一个领域泛化问题。领域是指潜在的数据分布。在我们的上下文中，它指的是类别 $y \in  \left\lbrack  \mathrm{C}\right\rbrack$ 在输入 $\mathbf{x}$ 和属性标签 $\mathbf{a}$ 上的分布 ${P}_{y}\left( {\mathbf{x},\mathbf{a}}\right)$。如图 2 所示，假设这些领域/类别是相关的，并且是从一个共同的分布 $\mathcal{P}$ 中采样得到的。考虑到图像和类别通常可以组织成层次结构，这是合理的。由于不同类别之间的关系，我们期望学习用于属性检测的新图像表示，使得相应的检测器在已见和未见类别上都能表现良好。

---

${}^{1}$ All kernels discussed in this paper have been centered [13].

${}^{1}$ 本文讨论的所有核函数都已进行中心化处理 [13]。

---

![0195d177-4450-77f6-a4af-980fc4fb8726_3_207_205_666_328_0.jpg](images/0195d177-4450-77f6-a4af-980fc4fb8726_3_207_205_666_328_0.jpg)

Figure 2. Attribute detection as multi-source domain generalization. Given labeled data sampled from several categories/domains, i.e., distributions ${P}_{y}\left( {\mathbf{x},\mathbf{a}}\right) , y \in  \left\lbrack  \mathrm{C}\right\rbrack$ over image representations $\mathbf{x}$ and attribute labels $\mathbf{a}$ , we extract knowledge useful for attribute detection and applicable to different domains/categories, especially to previously unseen ones ${P}_{\mathrm{C} + 1},{P}_{\mathrm{C} + 2},\cdots$ . The domains are assumed related and sampled from a common distribution $\mathcal{P}$ .

图 2. 将属性检测视为多源领域泛化。给定从几个类别/领域(即图像表示 $\mathbf{x}$ 和属性标签 $\mathbf{a}$ 上的分布 ${P}_{y}\left( {\mathbf{x},\mathbf{a}}\right) , y \in  \left\lbrack  \mathrm{C}\right\rbrack$)中采样得到的带标签数据，我们提取对属性检测有用且适用于不同领域/类别的知识，特别是适用于先前未见的类别 ${P}_{\mathrm{C} + 1},{P}_{\mathrm{C} + 2},\cdots$。假设这些领域是相关的，并且是从一个共同的分布 $\mathcal{P}$ 中采样得到的。

## 4. Approach

## 4. 方法

Our key idea is to find a feature transformation of the input $\mathbf{x}$ to eliminate the mismatches between different domains/categories in terms of their marginal distributions over the input, whereas ideally we should consider the joint distributions ${P}_{y}\left( {\mathbf{x},\mathbf{a}}\right) , y \in  \left\lbrack  \mathrm{C}\right\rbrack$ . In particular, we use Unsupervised Domain Invariant Component Analysis (UDICA) [50] and centered kernel alignment [13] for this purpose. Note that modeling the marginal distributions ${P}_{y}\left( \mathbf{x}\right)$ is a common practice in domain generalization $\left\lbrack  {{50},{80},{23}}\right\rbrack$ and domain adaptation $\left\lbrack  {{30},{53},{26}}\right\rbrack$ and performs well in many applications. We leave investigating the joint distributions ${P}_{y}\left( {\mathbf{x},\mathbf{a}}\right)$ for future work.

我们的核心思想是找到输入 $\mathbf{x}$ 的特征变换，以消除不同领域/类别在输入的边缘分布方面的不匹配，而理想情况下，我们应该考虑联合分布 ${P}_{y}\left( {\mathbf{x},\mathbf{a}}\right) , y \in  \left\lbrack  \mathrm{C}\right\rbrack$。具体而言，我们为此目的使用无监督域不变分量分析(Unsupervised Domain Invariant Component Analysis，UDICA)[50] 和中心核对齐(centered kernel alignment)[13]。请注意，对边缘分布 ${P}_{y}\left( \mathbf{x}\right)$ 进行建模是领域泛化 $\left\lbrack  {{50},{80},{23}}\right\rbrack$ 和领域自适应 $\left\lbrack  {{30},{53},{26}}\right\rbrack$ 中的常见做法，并且在许多应用中表现良好。我们将对联合分布 ${P}_{y}\left( {\mathbf{x},\mathbf{a}}\right)$ 的研究留作未来工作。

Next, we present how to integrate UDICA and centered kernel alignment. Jointly they give rise to new feature representations which account for both attribute discriminativeness and cross-category generalizability.

接下来，我们介绍如何将 UDICA 和中心核对齐相结合。它们共同产生了新的特征表示，这些表示既考虑了属性的区分性，又考虑了跨类别泛化能力。

### 4.1. UDICA

### 4.1. 无监督域不变分量分析(UDICA)

The projection from one RKHS to another results in the following transformation of the kernel matrices, ${\mathbb{R}}^{\mathrm{M} \times  \mathrm{M}} \ni  K \mapsto  \widetilde{K} = {KB}{B}^{T}K \in  {\mathbb{R}}^{\mathrm{M} \times  \mathrm{M}}$ [61]. As a result, one can take(KB)as the empirical kernel map, i.e., consider the $m$ -th row of(KB)as the new feature representations of image ${I}_{m}$ and plug them into any linear classifiers. UDICA learns the transformation $B$ by imposing the following properties.

从一个再生核希尔伯特空间(RKHS)到另一个再生核希尔伯特空间的投影会导致核矩阵发生以下变换，${\mathbb{R}}^{\mathrm{M} \times  \mathrm{M}} \ni  K \mapsto  \widetilde{K} = {KB}{B}^{T}K \in  {\mathbb{R}}^{\mathrm{M} \times  \mathrm{M}}$ [61]。因此，我们可以将 (KB) 视为经验核映射，即把 (KB) 的第 $m$ 行作为图像 ${I}_{m}$ 的新特征表示，并将它们代入任何线性分类器中。UDICA 通过施加以下属性来学习变换 $B$。

Minimizing distributional variance. The empirical distributional variance (cf. Section 2.1) between different domains/categories becomes the following in our context,

最小化分布方差。在我们的情境中，不同领域/类别之间的经验分布方差(参见第 2.1 节)变为以下形式，

$$
{\mathbb{V}}_{B}\left( \left\lbrack  \mathrm{C}\right\rbrack  \right)  = \operatorname{tr}\left( {\widetilde{K}Q}\right)  = \operatorname{tr}\left( {{B}^{T}{KQKB}}\right) . \tag{3}
$$

Intuitively, the domains would be perfectly matched when the variance is 0 . Since there are many seen categories, each as a domain, we expect the learned projection to be generalizable and work well for the unseen classes as well.

直观地说，当方差为 0 时，各个领域将完全匹配。由于有许多已见类别，每个类别都可视为一个领域，我们期望学习到的投影具有泛化能力，并且对未见类别也能很好地起作用。

Maximizing data variance. Starting from the empirical kernel map(KB), it is not difficult to see that the data covariance is ${\left( KB\right) }^{T}\left( {KB}\right) /\mathrm{M}$ and the variance is

最大化数据方差。从经验核映射 (KB) 出发，不难看出数据协方差为 ${\left( KB\right) }^{T}\left( {KB}\right) /\mathrm{M}$，方差为

$$
{\mathbb{V}}_{B}\left( \left\lbrack  \mathrm{M}\right\rbrack  \right)  = \operatorname{tr}\left( {{B}^{T}{K}^{2}B}\right) /\mathrm{M}. \tag{4}
$$

Regularizing the transformation. UDICA regularizes the transformation by minimizing

对变换进行正则化。UDICA 通过最小化来对变换进行正则化

$$
\mathcal{R}\left( B\right)  = \operatorname{tr}\left( {{B}^{T}{KB}}\right) . \tag{5}
$$

Alternatively, one can use the Frobenius norm $\parallel B{\parallel }_{F}$ , as did in [53], to constrain the complexity of $B$ .

或者，我们可以像文献 [53] 那样，使用弗罗贝尼乌斯范数 $\parallel B{\parallel }_{F}$ 来约束 $B$ 的复杂度。

Combining the above criteria, we arrive at the following problem,

综合上述标准，我们得到以下问题，

$$
\mathop{\max }\limits_{B}\frac{\operatorname{tr}\left( {{B}^{T}{K}^{2}B}\right) /\mathrm{M}}{\operatorname{tr}\left( {{B}^{T}{KQKB} + {B}^{T}{KB}}\right) }, \tag{6}
$$

where the nominator corresponds to the data variance and the denominator sums up the distributional variance and the regularization over $B$ .

其中分子对应数据方差，分母是分布方差和对 $B$ 的正则化之和。

By solving the above problem, we are essentially blurring the boundaries between different categories and match the classes with each other, due to the distributional variance term in the denominator. This thus eliminates the barrier for attribute detectors to generalize in various classes. Our experiments verify the effectiveness the learned new representations(KB). Nonetheless, we can further improve the performance by modeling the attribute labels using centered kernel alignment.

通过解决上述问题，由于分母中的分布方差项，我们实际上是在模糊不同类别之间的边界，并使各个类别相互匹配。这就消除了属性检测器在不同类别中进行泛化的障碍。我们的实验验证了所学习到的新表示 (KB) 的有效性。尽管如此，我们可以通过使用中心核对齐对属性标签进行建模来进一步提高性能。

### 4.2. Centered kernel alignment

### 4.2. 中心核对齐

Note that our training data are in the form of $\left( {{\mathbf{x}}_{m},{\mathbf{a}}_{m},{y}_{m}}\right) , m \in  \left\lbrack  \mathrm{M}\right\rbrack$ . For each image there are multiple attribute labels which may be highly correlated. Besides, we would like to stick to kernel methods to be consistent with our choice of UDICA-indeed, the distributional variance is best implemented by kernel methods (cf. Section 2.1). These considerations lead to our decision on using kernel alignment [13] to model the multi-attribute supervised information.

请注意，我们的训练数据采用 $\left( {{\mathbf{x}}_{m},{\mathbf{a}}_{m},{y}_{m}}\right) , m \in  \left\lbrack  \mathrm{M}\right\rbrack$ 的形式。对于每幅图像，有多个属性标签，这些标签可能高度相关。此外，为了与我们选择的 UDICA 保持一致，我们希望坚持使用核方法——实际上，分布方差最好通过核方法来实现(参见第 2.1 节)。基于这些考虑，我们决定使用核对齐 [13] 来对多属性监督信息进行建模。

Let ${L}_{m,{m}^{\prime }} = \left\langle  {{\mathbf{a}}_{m},{\mathbf{a}}_{{m}^{\prime }}}\right\rangle$ be the kernel matrix over the attributes. Since $L$ is computed directly from the attribute labels, it preserves the correlations among them and serves as the "perfect" target kernel for the transformed kernel $\widetilde{K} = {KB}{B}^{T}K$ to align to. The centered kernel alignment is then computed by,

设 ${L}_{m,{m}^{\prime }} = \left\langle  {{\mathbf{a}}_{m},{\mathbf{a}}_{{m}^{\prime }}}\right\rangle$ 为属性上的核矩阵。由于 $L$ 是直接从属性标签计算得出的，它保留了属性之间的相关性，并作为变换后的核 $\widetilde{K} = {KB}{B}^{T}K$ 要对齐的“完美”目标核。然后通过以下方式计算中心核对齐:

$$
\rho \left( {\widetilde{K}, L}\right)  = \frac{\operatorname{tr}\left( {\widetilde{K}L}\right) }{\sqrt{\operatorname{tr}\left( {\widetilde{K}\widetilde{K}}\right) }\sqrt{\operatorname{tr}\left( {LL}\right) }} \tag{7}
$$

where we abuse the notation $L$ slightly to denote that it is centered [13].

这里我们稍微滥用一下符号 $L$ 来表示它是经过中心化处理的 [13]。

We would like to integrate the kernel alignment with UDICA in a unified optimization problem. To this end, firstly it is safe to drop tr(LL)in eq. (7) since it has nothing to do with the projection $B$ we are learning. Moreover, note that the role of $\operatorname{tr}\left( {\widetilde{K}\widetilde{K}}\right)$ duplicates with the regularization in eq. (6) to some extent, as it is mainly to avoid trivial solutions for the kernel alignment. We thus only add $\operatorname{tr}\left( {\widetilde{K}L}\right)$ to the nominator of UDICA,

我们希望在一个统一的优化问题中将核对齐与无监督判别不变分量分析(UDICA)相结合。为此，首先可以安全地去掉等式 (7) 中的 tr(LL)，因为它与我们正在学习的投影 $B$ 无关。此外，注意到 $\operatorname{tr}\left( {\widetilde{K}\widetilde{K}}\right)$ 的作用在一定程度上与等式 (6) 中的正则化重复，因为它主要是为了避免核对齐出现平凡解。因此，我们只将 $\operatorname{tr}\left( {\widetilde{K}L}\right)$ 添加到 UDICA 的分子中。

$$
\mathop{\max }\limits_{B}\frac{\operatorname{tr}\left( {\gamma {B}^{T}{K}^{2}B/\mathrm{M} + \left( {1 - \gamma }\right) {B}^{T}{KLKB}}\right) }{\operatorname{tr}\left( {{B}^{T}{KQKB} + {B}^{T}{KB}}\right) }, \tag{8}
$$

where $\gamma  \in  \left\lbrack  {0,1}\right\rbrack$ balances the data variance and the kernel alignment with the supervised attribute labeling information. We cross-validate $\gamma$ in our experiments. We name this formulation KDICA, which couples the centered kernel alignment and UDICA. The former closely tracks the attribute discriminative information and the latter facilitates the cross-category generalization of the attribute detectors to be trained upon KDICA.

其中 $\gamma  \in  \left\lbrack  {0,1}\right\rbrack$ 平衡了数据方差和带有监督属性标签信息的核对齐。我们在实验中对 $\gamma$ 进行交叉验证。我们将这种公式命名为核对齐域不变分量分析(KDICA)，它将中心核对齐和 UDICA 结合起来。前者紧密跟踪属性判别信息，后者有助于基于 KDICA 训练的属性检测器进行跨类别泛化。

Optimization. By writing out the Lagrangian of the formalized problem (eq. (8)) and then setting the derivative with respect to $B$ to 0, we arrive at a generalized eigen-decomposition problem,

优化。通过写出形式化问题(等式 (8))的拉格朗日函数，然后将关于 $B$ 的导数设为 0，我们得到一个广义特征分解问题:

$$
\left( {\gamma {K}^{2}/\mathrm{M} + \left( {1 - \gamma }\right) {KLK}}\right) B
$$

$$
= \left( {{KQK} + K}\right) {B\Gamma } \tag{9}
$$

where $\Gamma$ is a diagonal matrix containing all the eigenvalues (Lagrangian multipliers). We find the solution $B$ as the Leading eigen-vectors. The number of eigen-vectors is cross-validated in our experiments. Again, we remind that(KB)serves as the new feature representations of the images for training attribute detectors. The details of our proposed framework has been shown in algorithm 1 .

其中 $\Gamma$ 是一个包含所有特征值(拉格朗日乘子)的对角矩阵。我们将解 $B$ 作为主特征向量。特征向量的数量在我们的实验中进行交叉验证。再次提醒，(KB) 作为训练属性检测器的图像的新特征表示。我们提出的框架的详细信息已在算法 1 中展示。

Algorithm 1 Kernel-alignment Domain-Invariant Component Analysis (KDICA).

算法 1 核对齐域不变分量分析(KDICA)。

---

Input: Parameters $\gamma$ and $\mathrm{b} \ll  \mathrm{M}$ . Training data $\mathcal{S} =$

输入:参数 $\gamma$ 和 $\mathrm{b} \ll  \mathrm{M}$。训练数据 $\mathcal{S} =$

	${\left\{  \left( {\mathbf{x}}_{m},{y}_{m},{\mathbf{a}}_{m}\right) \right\}  }_{m = 1}^{\mathrm{M}}$

Output: Projection ${B}_{\mathrm{M} \times  \mathrm{b}}$

输出:投影 ${B}_{\mathrm{M} \times  \mathrm{b}}$

	Calculate gram matrix $\left\lbrack  {K}_{ij}\right\rbrack   = k\left( {{\mathbf{x}}_{i},{\mathbf{x}}_{j}}\right)$ and

	计算格拉姆矩阵 $\left\lbrack  {K}_{ij}\right\rbrack   = k\left( {{\mathbf{x}}_{i},{\mathbf{x}}_{j}}\right)$ 和

	$\left\lbrack  {L}_{ij}\right\rbrack   = l\left( {{\mathbf{a}}_{i},{\mathbf{a}}_{j}}\right)$

	Solve:

	求解:

	$\left( {\gamma {K}^{2}/\mathrm{M} + \left( {1 - \gamma }\right) {KLK}}\right) B = \left( {{KQK} + K}\right) {B\Gamma }.$

	: Output $B$ and $\widetilde{K} \leftarrow  {KB}{B}^{\mathrm{T}}K$

	:输出 $B$ 和 $\widetilde{K} \leftarrow  {KB}{B}^{\mathrm{T}}K$

	Use(KB)as if they are the features to learn linear

	将 (KB) 当作特征来学习线性

	classifiers and $\widetilde{K}$ for kernelized classifiers

	分类器，使用 $\widetilde{K}$ 用于核化分类器

---

## 5. Experiment

## 5. 实验

This section presents our experimental results on four benchmark datasets. We test our approach for both the immediate task of attribute detection and two other problems, zero-shot learning and image retrieval, which could benefit from high-quality attribute detectors.

本节展示了我们在四个基准数据集上的实验结果。我们针对属性检测的直接任务以及另外两个问题(零样本学习和图像检索)测试了我们的方法，这两个问题可以从高质量的属性检测器中受益。

### 5.1. Experiment setup

### 5.1. 实验设置

Dataset. We use four datasets to validate the proposed approach; three of them contain images for object and scene recognition and the last one contains videos for action recognition. (a) The Animal with attribute (AWA) [44] dataset comprises of 30,475 images belonging to 50 animal classes. Each class is annotated with 85 attributes. Following the standard split by the dataset, we divide the dataset into 40 classes(24,295images)to be used for training and 10 classes $(6,{180}$ images) for testing. (b) Caltech-UCSD Birds 2011 (CUB) [76] is a dataset with fine-grained objects. There are 11,788 images of 200 different bird classes in CUB. Each class is annotated with 312 binary attributes. We split the dataset as suggested in [1] to facilitate direct comparison (150 classes for training and 50 classes for testing). (c) aPascal-aYahoo [18] consists of two attribute datases: the a-PASCAL dataset, which contains 12,695 images (6,340 for training and 6,355 for testing) collected for the Pascal VOC 2008 challenge, and a-Yahoo including 2,644 test images. Each images is annotated with 64 attributes. There are 20 object classes in a-Pascal and 12 in a-Yahoo and they are disjoint. Following the settings of $\left\lbrack  {{64},{81}}\right\rbrack$ , we use the pre-defined training images in a-Pascal as the training set and test on a-Yahoo. (d) UCF101 dataset [67] is a large dateset for video action recognition. It contains 13,320 videos of 101 action classes. Each action class comes with 115 attributes. The videos are collected from YouTube with large variations in camera motion, object appearance, viewpoint, cluttered background, and illumination conditions. We run 10 rounds of experiments each with a random split of ${81}/{20}$ classes for the training/testing sets, and then report the averaged results.

数据集。我们使用四个数据集来验证所提出的方法；其中三个数据集包含用于目标和场景识别的图像，最后一个数据集包含用于动作识别的视频。(a) 带属性的动物(Animal with attribute，AWA)[44] 数据集包含属于 50 个动物类别的 30475 张图像。每个类别都标注了 85 个属性。按照数据集的标准划分，我们将数据集划分为 40 个类别(24295 张图像)用于训练，10 个类别($(6,{180}$ 张图像)用于测试。(b) 加州理工学院 - 加州大学圣地亚哥分校鸟类 2011 年(Caltech - UCSD Birds 2011，CUB)[76] 是一个包含细粒度目标的数据集。CUB 中有 200 种不同鸟类的 11788 张图像。每个类别都标注了 312 个二进制属性。我们按照文献 [1] 中的建议划分数据集，以便进行直接比较(150 个类别用于训练，50 个类别用于测试)。(c) aPascal - aYahoo [18] 由两个属性数据集组成:a - PASCAL 数据集，它包含为 Pascal VOC 2008 挑战赛收集的 12695 张图像(6340 张用于训练，6355 张用于测试)，以及包含 2644 张测试图像的 a - Yahoo 数据集。每张图像都标注了 64 个属性。a - PASCAL 中有 20 个目标类别，a - Yahoo 中有 12 个目标类别，且它们互不相交。按照 $\left\lbrack  {{64},{81}}\right\rbrack$ 的设置，我们使用 a - PASCAL 中预定义的训练图像作为训练集，并在 a - Yahoo 上进行测试。(d) UCF101 数据集 [67] 是一个用于视频动作识别的大型数据集。它包含 101 个动作类别的 13320 个视频。每个动作类别都有 115 个属性。这些视频是从 YouTube 上收集的，在相机运动、目标外观、视角、杂乱背景和光照条件等方面存在很大差异。我们进行 10 轮实验，每轮实验都随机划分 ${81}/{20}$ 个类别作为训练/测试集，然后报告平均结果。

<table><tr><td>Approcahes</td><td>AWA</td><td>CUB</td><td>a-Yahoo</td><td>UCF101</td></tr><tr><td>IAP [44]</td><td>74.0/79.2*</td><td>74.9*</td><td>-</td><td>-</td></tr><tr><td>ALE [1]</td><td>65.7</td><td>60.3</td><td>-</td><td>-</td></tr><tr><td>HAP [12]</td><td>74.0/79.1*</td><td>${68.5}/{74.1}^{ * }$</td><td>${58.2}^{ * }$</td><td>${72.1} \pm  {1.1}$</td></tr><tr><td>${\mathrm{{CSHAP}}}_{G}$ [12]</td><td>74.3/79.4*</td><td>${62.7}/{74.6}^{ * }$</td><td>${58.2}^{ * }$</td><td>${72.3} \pm  {1.0}$</td></tr><tr><td>${\mathrm{{CSHAP}}}_{H}$ [12]</td><td>74.0/79.0*</td><td>${68.5}/{73.4}^{ * }$</td><td>${65.2}^{ * }$</td><td>${72.4} \pm  {1.1}$</td></tr><tr><td>DAP [44]</td><td>${72.8}/{78.9}^{ * }$</td><td>61.8/72.1*</td><td>${77.4}^{ * }$</td><td>${71.8} \pm  {1.2}$</td></tr><tr><td>UDICA (Ours)</td><td>83.9</td><td>76.0</td><td>82.3</td><td>$\mathbf{{74.3} \pm  {1.3}}$</td></tr><tr><td>KDICA (Ours)</td><td>84.4</td><td>76.4</td><td>84.7</td><td>$\mathbf{{75.5} \pm  {1.1}}$</td></tr></table>

<table><tbody><tr><td>方法</td><td>自动唤醒算法(AWA)</td><td>加州大学伯克利分校鸟类数据集(CUB)</td><td>a - 雅虎</td><td>UCF101数据集</td></tr><tr><td>图像属性预测(IAP) [44]</td><td>74.0/79.2*</td><td>74.9*</td><td>-</td><td>-</td></tr><tr><td>自适应局部增强(ALE) [1]</td><td>65.7</td><td>60.3</td><td>-</td><td>-</td></tr><tr><td>分层属性预测(HAP) [12]</td><td>74.0/79.1*</td><td>${68.5}/{74.1}^{ * }$</td><td>${58.2}^{ * }$</td><td>${72.1} \pm  {1.1}$</td></tr><tr><td>${\mathrm{{CSHAP}}}_{G}$ [12]</td><td>74.3/79.4*</td><td>${62.7}/{74.6}^{ * }$</td><td>${58.2}^{ * }$</td><td>${72.3} \pm  {1.0}$</td></tr><tr><td>${\mathrm{{CSHAP}}}_{H}$ [12]</td><td>74.0/79.0*</td><td>${68.5}/{73.4}^{ * }$</td><td>${65.2}^{ * }$</td><td>${72.4} \pm  {1.1}$</td></tr><tr><td>判别式属性预测(DAP) [44]</td><td>${72.8}/{78.9}^{ * }$</td><td>61.8/72.1*</td><td>${77.4}^{ * }$</td><td>${71.8} \pm  {1.2}$</td></tr><tr><td>无监督判别式独立成分分析(UDICA)(我们的方法)</td><td>83.9</td><td>76.0</td><td>82.3</td><td>$\mathbf{{74.3} \pm  {1.3}}$</td></tr><tr><td>核判别式独立成分分析(KDICA)(我们的方法)</td><td>84.4</td><td>76.4</td><td>84.7</td><td>$\mathbf{{75.5} \pm  {1.1}}$</td></tr></tbody></table>

Table 1. Average Attribute Prediction Accuracy (%, in AUC.)

表1. 平均属性预测准确率(%，以AUC计)

Features. For the first three image datasets, we use the Convolutional Neural Network (CNN) implementation provided by Caffe [36], particularly with the 19-layer network architecture and parameters from Oxford [65], to extract 4,096-dimensional CNN feature representations from images (i.e., the activations of the first fully-connected layer fc6). For the UCF101 dataset, we use the 3D CNN (C3D) [74] pre-trained on the Sport 1M dataset [39] to construct video-clip features from both spatial and temporal dimensions. We then use average pooling to obtain the video-level representations. We ${\ell }_{2}$ normalize the feature representations in the following experiments.

特征。对于前三个图像数据集，我们使用Caffe [36]提供的卷积神经网络(Convolutional Neural Network，CNN)实现，特别是采用来自牛津大学[65]的19层网络架构和参数，从图像中提取4096维的CNN特征表示(即第一个全连接层fc6的激活值)。对于UCF101数据集，我们使用在Sport 1M数据集[39]上预训练的3D CNN(C3D)[74]从空间和时间维度构建视频片段特征。然后，我们使用平均池化来获得视频级别的表示。我们${\ell }_{2}$在后续实验中对特征表示进行归一化处理。

Implementation details. We choose the Gaussian RBF kernel and fix the bandwidth parameter as 1 for our approach to learning new image representations. After that, to train the attribute detectors, we input the learned representations into standard linear Support Vector Machines (see the empirical kernel map in Set-cion 4.1). There are two free hyper-parameters when we train the detectors using the representations learned through UDICA, the hyper-parameter $C$ in SVM and the number $\mathrm{b}$ of leading eigen-vectors in UDICA. We use five-fold cross-validation to choose the best values for $C$ and b respectively from $\{ {0.01},{0.1},1,{10},{100}\}$ and $\{ {30},{50},{70},{90},{110},{130},{150}\}$ . We use the same $C$ and b for KDICA and only cross-validate $\gamma$ in equation (9) from $\{ {0.2},{0.5},{0.8}\}$ to learn the SVM based attribute detectors with KDICA.

实现细节。对于学习新图像表示的方法，我们选择高斯径向基函数(RBF)核，并将带宽参数固定为1。之后，为了训练属性检测器，我们将学习到的表示输入到标准线性支持向量机中(见4.1节中的经验核映射)。当我们使用通过无监督判别式独立成分分析(UDICA)学习到的表示来训练检测器时，有两个自由超参数，即支持向量机(SVM)中的超参数$C$和UDICA中前导特征向量的数量$\mathrm{b}$。我们使用五折交叉验证分别从$\{ {0.01},{0.1},1,{10},{100}\}$和$\{ {30},{50},{70},{90},{110},{130},{150}\}$中选择$C$和b的最佳值。对于核判别式独立成分分析(KDICA)，我们使用相同的$C$和b，并且仅从$\{ {0.2},{0.5},{0.8}\}$中对公式(9)中的$\gamma$进行交叉验证，以学习基于KDICA的支持向量机属性检测器。

Evaluation. We first test our approach to attribute detection on all the four datasets (AWA, CUB, aPascal-aYahoo, and UCF101). To see how much the other tasks, which involve attributes, can gain from higher-quality attribute detectors, we further conduct zero-shot learning [52, 44] experiments on AWA, CUB, and UCF101, and multi-attribute based image retrieval on AWA. We evaluate the results of attribute detection and image retrieval by the averaged Area Under ROC Curve (AUC), the higher the better, and the results of zero-shot learning by classification accuracy.

评估。我们首先在所有四个数据集(AWA、CUB、aPascal - aYahoo和UCF101)上测试我们的属性检测方法。为了了解其他涉及属性的任务能从更高质量的属性检测器中获得多少收益，我们进一步在AWA、CUB和UCF101上进行零样本学习[52, 44]实验，并在AWA上进行基于多属性的图像检索。我们通过平均ROC曲线下面积(AUC)评估属性检测和图像检索的结果，该值越高越好，通过分类准确率评估零样本学习的结果。

### 5.2. Attribute prediction

### 5.2. 属性预测

Table 1 presents the attribute prediction performance of our approaches and several competitive baselines. In particular, we compare with four state-of-the-art attribute detection methods: Directly Attribute Prediction (DAP) [44], Indirectly Attribute Prediction (IAP) [44], Attribute Label Embedding (ALE) [1], and Hypergraph-regularized Attribute Predictors (HAP) [12]. Note that we can directly contrast our methods with DAP to see the effectiveness of the learned new representations, because they share the same input and classifiers and only differ in that we learn the new attribute-discriminative and category-invariant feature representations. The IAP model first maps any input to the seen classes and then predicts the attributes on top of those. The ALE method unifies attribute prediction with object class prediction instead of directly optimizing with respect to attributes. We thus do not expect it to perform quite well on the attribute prediction task. HAP explores the correlations among attributes explicitly by hyper-graphs, while we achieve this implicitly in the kernel alignment. Additionally, we also show the results of ${\mathrm{{CSHAP}}}_{G}$ and ${\mathrm{{CSHAP}}}_{H}$ , two variations of HAP to model class labels.

表1展示了我们的方法和几种有竞争力的基线方法的属性预测性能。具体来说，我们与四种最先进的属性检测方法进行了比较:直接属性预测(Directly Attribute Prediction，DAP)[44]、间接属性预测(Indirectly Attribute Prediction，IAP)[44]、属性标签嵌入(Attribute Label Embedding，ALE)[1]和超图正则化属性预测器(Hypergraph - regularized Attribute Predictors，HAP)[12]。请注意，我们可以直接将我们的方法与DAP进行对比，以查看学习到的新表示的有效性，因为它们具有相同的输入和分类器，唯一的区别在于我们学习了新的具有属性判别性和类别不变性的特征表示。IAP模型首先将任何输入映射到已见类别，然后在此基础上预测属性。ALE方法将属性预测与对象类别预测统一起来，而不是直接针对属性进行优化。因此，我们预计它在属性预测任务上的表现不会很好。HAP通过超图显式地探索属性之间的相关性，而我们在核对齐中隐式地实现了这一点。此外，我们还展示了${\mathrm{{CSHAP}}}_{G}$和${\mathrm{{CSHAP}}}_{H}$的结果，它们是HAP用于建模类别标签的两种变体。

We include in Table 1 both the results of these methods reported in the original papers, when they are available, and those we obtained (marked by '*') by running the source code provided by the authors. We use the same CNN features (for AWA, CUB, and aPascal-aYahoo) and C3D features (for UCF101) we extracted for the baselines and our approach.

在表1中，我们既包含了这些方法在原始论文中报告的结果(如果有的话)，也包含了我们通过运行作者提供的源代码获得的结果(标记为'*')。我们为基线方法和我们的方法使用了相同的CNN特征(用于AWA、CUB和aPascal - aYahoo)和C3D特征(用于UCF101)。

![0195d177-4450-77f6-a4af-980fc4fb8726_6_234_237_1330_355_0.jpg](images/0195d177-4450-77f6-a4af-980fc4fb8726_6_234_237_1330_355_0.jpg)

Figure 3. Some attributes on which the proposed KDICA significantly improves the performance of DAP.

图3. 所提出的KDICA显著提高DAP性能的一些属性。

<table><tr><td>Approcahes</td><td>AWA</td><td>CUB</td><td>UCF101</td></tr><tr><td>ALE [1]</td><td>37.4</td><td>18.0</td><td>-</td></tr><tr><td>HLE [1]</td><td>39.0</td><td>12.1</td><td>-</td></tr><tr><td>AHLE [1]</td><td>43.5</td><td>17.0</td><td>-</td></tr><tr><td>DA [35]</td><td>30.6</td><td>-</td><td>-</td></tr><tr><td>MLA [19]</td><td>41.3</td><td>-</td><td>-</td></tr><tr><td>ZSRF [34]</td><td>48.7</td><td>-</td><td>-</td></tr><tr><td>SM [20]</td><td>66.0</td><td>-</td><td>-</td></tr><tr><td>Embedding [2]</td><td>60.1</td><td>29.9</td><td>-</td></tr><tr><td>IAP [44]</td><td>${42.2}/{49.4}^{ * }$</td><td>${4.6}/{34.9}{}^{ * }$</td><td>-</td></tr><tr><td>HAP [12]</td><td>${45.0}/{55.6}^{ * }$</td><td>17.5/40.7*</td><td>-</td></tr><tr><td>${\mathrm{{CSHAP}}}_{G}$ [12]</td><td>${45.0}/{54.5}^{ * }$</td><td>17.5/38.7*</td><td>-</td></tr><tr><td>${\mathrm{{CSHAP}}}_{H}$ [12]</td><td>${45.6}/{53.3}^{ * }$</td><td>17.5/36.9*</td><td>-</td></tr><tr><td>DAP [44]</td><td>${41.2}/{58.9}^{ * }$</td><td>${10.5}/{39.8}^{ * }$</td><td>${26.8} \pm  {1.1}$</td></tr><tr><td>UDCIA (Ours)</td><td>63.6</td><td>42.4</td><td>$\mathbf{{29.6} \pm  {1.2}}$</td></tr><tr><td>KDCIA (Ours)</td><td>73.8</td><td>43.7</td><td>${31.1} \pm  {0.8}$</td></tr></table>

<table><tbody><tr><td>方法</td><td>平均加权注意力(Average Weighted Attention，AWA)</td><td>加州大学伯克利分校鸟类数据集(Caltech-UCSD Birds-200-2011，CUB)</td><td>UCF101数据集</td></tr><tr><td>自适应学习率均衡器(Adaptive Learning Equalizer，ALE) [1]</td><td>37.4</td><td>18.0</td><td>-</td></tr><tr><td>混合学习率均衡器(Hybrid Learning Equalizer，HLE) [1]</td><td>39.0</td><td>12.1</td><td>-</td></tr><tr><td>自适应混合学习率均衡器(Adaptive Hybrid Learning Equalizer，AHLE) [1]</td><td>43.5</td><td>17.0</td><td>-</td></tr><tr><td>域自适应(Domain Adaptation，DA) [35]</td><td>30.6</td><td>-</td><td>-</td></tr><tr><td>多标签注意力(Multi-Label Attention，MLA) [19]</td><td>41.3</td><td>-</td><td>-</td></tr><tr><td>零样本随机森林(Zero-Shot Random Forest，ZSRF) [34]</td><td>48.7</td><td>-</td><td>-</td></tr><tr><td>相似度匹配(Similarity Matching，SM) [20]</td><td>66.0</td><td>-</td><td>-</td></tr><tr><td>嵌入(Embedding) [2]</td><td>60.1</td><td>29.9</td><td>-</td></tr><tr><td>图像注意力池化(Image Attention Pooling，IAP) [44]</td><td>${42.2}/{49.4}^{ * }$</td><td>${4.6}/{34.9}{}^{ * }$</td><td>-</td></tr><tr><td>混合注意力池化(Hybrid Attention Pooling，HAP) [12]</td><td>${45.0}/{55.6}^{ * }$</td><td>17.5/40.7*</td><td>-</td></tr><tr><td>${\mathrm{{CSHAP}}}_{G}$ [12]</td><td>${45.0}/{54.5}^{ * }$</td><td>17.5/38.7*</td><td>-</td></tr><tr><td>${\mathrm{{CSHAP}}}_{H}$ [12]</td><td>${45.6}/{53.3}^{ * }$</td><td>17.5/36.9*</td><td>-</td></tr><tr><td>动态注意力池化(Dynamic Attention Pooling，DAP) [44]</td><td>${41.2}/{58.9}^{ * }$</td><td>${10.5}/{39.8}^{ * }$</td><td>${26.8} \pm  {1.1}$</td></tr><tr><td>无监督动态上下文信息聚合(Unsupervised Dynamic Contextual Information Aggregation，UDCIA)(我们的方法)</td><td>63.6</td><td>42.4</td><td>$\mathbf{{29.6} \pm  {1.2}}$</td></tr><tr><td>有监督动态上下文信息聚合(Knowledge-based Dynamic Contextual Information Aggregation，KDCIA)(我们的方法)</td><td>73.8</td><td>43.7</td><td>${31.1} \pm  {0.8}$</td></tr></tbody></table>

Table 2. Zero-shot recognition performances. (%, in accuracy)

表2. 零样本识别性能。(%，准确率)

Overall results. From Table 1, we can find that UDCIA and KDICA outperform all the baselines on all the four datasets. More specifically, the relative accuracy gains of UDCIA over DAP are ${6.3}\%$ on the AWA dataset and ${5.4}\%$ on the CUB dateset, respectively, under the same feature and experimental settings. These clearly validate our assumption that blurring the category boundaries improves the generalizabilities of attribute detectors to previously unseen categories. The KDICA with centered kernel alignment is slightly better than the UDICA approach by incorporating attribute discriminative signals into the new feature representations. Delving into the per-unseen-class attribute detection result, we find that our KDICA-based approach improves the results of DAP for 71 out of 85 attributes on AWA and 272 out of 312 on CUB.

总体结果。从表1中，我们可以发现UDCIA(无监督判别式类别属性学习)和KDICA(基于核判别式类别属性学习)在所有四个数据集上的表现都优于所有基线方法。更具体地说，在相同的特征和实验设置下，UDCIA相对于DAP(判别式属性预测)在AWA数据集上的相对准确率提升分别为${6.3}\%$，在CUB数据集上为${5.4}\%$。这些结果清楚地验证了我们的假设，即模糊类别边界可以提高属性检测器对先前未见类别的泛化能力。采用中心核对齐的KDICA通过将属性判别信号融入新的特征表示中，略优于UDICA方法。深入研究每个未见类别的属性检测结果，我们发现基于KDICA的方法在AWA数据集的85个属性中有71个、在CUB数据集的312个属性中有272个提高了DAP的检测结果。

When domain generalization helps. We give some qualitative analyses using Figure 3 and 4 here. For the attributes in Figure 3, the proposed KDICA significantly improves the performance of the DAP approach. Those attributes ("muscle", "domestic", etc.) appear in visually quite different object categories. It seems like breaking the category boundaries is necessary in this case in order to make the attribute detectors generalize to the unseen classes. On the other hand, Figure 4 shows the attributes for which our approach can hardly improve DAP's performance. The attribute "yellow" is too trivial to detect with nearly ${100}\%$ accuracy already by DAP. The attribute "swim" is actually shared by visually similar categories, leaving not much room for KDICA to play any role.

领域泛化何时起作用。我们在此使用图3和图4进行一些定性分析。对于图3中的属性，所提出的KDICA显著提高了DAP方法的性能。那些属性(如“肌肉发达”“家养的”等)出现在视觉上差异很大的对象类别中。在这种情况下，似乎打破类别边界对于使属性检测器能够泛化到未见类别是必要的。另一方面，图4显示了我们的方法几乎无法提高DAP性能的属性。“黄色”这一属性过于简单，DAP已经以接近${100}\%$的准确率进行检测。“游泳”这一属性实际上由视觉上相似的类别共享，这使得KDICA几乎没有发挥作用的空间。

![0195d177-4450-77f6-a4af-980fc4fb8726_6_944_731_625_121_0.jpg](images/0195d177-4450-77f6-a4af-980fc4fb8726_6_944_731_625_121_0.jpg)

Figure 4. Example attributes that KDICA could not improve the detection accuracy over the traditional DAP approach.

图4. KDICA无法比传统DAP方法提高检测准确率的示例属性。

### 5.3. Zero-shot learning

### 5.3. 零样本学习

As the intermediate representations of images and videos, attributes are often used in high-level computer vision applications. In this section, we conduct experiments on zero-shot learning to examine whether the improved attribute detectors could also benefit this task.

作为图像和视频的中间表示，属性常用于高级计算机视觉应用中。在本节中，我们进行零样本学习实验，以检验改进后的属性检测器是否也能使该任务受益。

Given our UDICA and KDICA based attribute detection results, we simply input them to the second layer of the DAP model [44] to solve the zero-shot learning problem. We then compare with several well-known zero-shot recognition systems as shown in Table 2. We run our own experiments for some of them whose source code are provided by the authors. The corresponding results are again marked by '*'.

根据我们基于UDICA和KDICA的属性检测结果，我们只需将它们输入到DAP模型[44]的第二层来解决零样本学习问题。然后，我们将其与几个著名的零样本识别系统进行比较，如表2所示。对于一些作者提供了源代码的系统，我们进行了自己的实验。相应的结果再次用“*”标记。

<table><tr><td>query</td><td>VGG</td><td>UDICA</td><td>KDICA</td></tr><tr><td>single</td><td>78.9</td><td>83.9</td><td>84.4</td></tr><tr><td>double</td><td>77.2</td><td>79.5</td><td>81.0</td></tr><tr><td>triple</td><td>76.1</td><td>78.6</td><td>79.4</td></tr></table>

<table><tbody><tr><td>查询</td><td>视觉几何组网络(VGG)</td><td>无监督动态独立成分分析(UDICA)</td><td>核动态独立成分分析(KDICA)</td></tr><tr><td>单个</td><td>78.9</td><td>83.9</td><td>84.4</td></tr><tr><td>双个；双重</td><td>77.2</td><td>79.5</td><td>81.0</td></tr><tr><td>三个；三重</td><td>76.1</td><td>78.6</td><td>79.4</td></tr></tbody></table>

Table 3. Multi-attribute based image retrieval results on AWA by the late fusion of individual attribute detection scores. (%, in AUC)

表3. 通过单个属性检测分数的后期融合在AWA数据集上基于多属性的图像检索结果。(%，以AUC为指标)

We see that in Table 2 the proposed simple solution to zero-shot learning outperforms the other state-of-the-art methods on the AWA, CUB, and UCF101 datasets, especially its immediate rival DAP. In addition, we notice that our kernel alignment technique (KDICA) improves the zero-shot recognition results over UDICA significantly on AWA. The improvements over UDICA on the other two datasets are also more significant than the improvements for the attribute prediction task (see Section 5.2 and Table 1). This observation is interesting; it seems like implying that increasing the quality of the attribute detectors is rewarding, because the increase will be magnified to even larger improvement for the zero-shot learning. Similar observation applies if we compare the differences between DAP and UDICA/KDICA respectively in Table 2 and Table 1. Finally, we note that our main purpose is indeed to investigate how better attribute detectors can benefit zero-shot learning. We do not expect to have a thorough comparison of the existing zero-shot learning methods.

我们从表2中可以看出，所提出的零样本学习简单解决方案在AWA、CUB和UCF101数据集上的表现优于其他最先进的方法，尤其是其直接竞争对手DAP(直接属性预测，Direct Attribute Prediction)。此外，我们注意到，我们的核对齐技术(KDICA，核去相关独立成分分析，Kernel Decorrelated Independent Component Analysis)在AWA数据集上显著提高了零样本识别结果，相较于UDICA(无监督去相关独立成分分析，Unsupervised Decorrelated Independent Component Analysis)有明显提升。在另外两个数据集上，相较于UDICA的改进也比属性预测任务的改进更为显著(见5.2节和表1)。这一观察结果很有趣；这似乎意味着提高属性检测器的质量是有回报的，因为这种提升在零样本学习中会被放大为更大的改进。如果我们分别比较表2和表1中DAP与UDICA/KDICA之间的差异，也会有类似的观察结果。最后，我们要指出，我们的主要目的确实是研究更好的属性检测器如何能使零样本学习受益。我们并不期望对现有的零样本学习方法进行全面比较。

### 5.4. Multi-attribute based image retrieval

### 5.4 基于多属性的图像检索

In this section, we do some experiments on the AWA dataset for the multi-attribute based image retrieval, whose performance depends on the reliabilities of the attribute predictions. We input our learned feature representations to two popular frameworks for multi-attribute based image retrieval: TagProp [28] and the fusion of individual prediction scores [42]. In TagProp, we use its $\sigma$ ML variant to compute the ranking scores of the multi-attributes queries. For the fusion of individual classifiers, we directly sum up the confidence scores corresponding to the multiple attributes in a query. The results of the fusion and TagProp are respectively shown in Table 3 and Table 4. We can observe that our attribute-oriented representations improve the fusion technique for image retrieval on a variety of queries (single attribute, attribute pairs, and triplets). Under the TagProp framework, the improvement is marginal on querying by attribute pairs and triples and significant for single-attribute queries.

在本节中，我们在AWA数据集上进行了一些基于多属性的图像检索实验，其性能取决于属性预测的可靠性。我们将学习到的特征表示输入到两个流行的基于多属性的图像检索框架中:TagProp [28]和单个预测分数融合方法 [42]。在TagProp中，我们使用其$\sigma$ ML变体来计算多属性查询的排名分数。对于单个分类器的融合，我们直接将查询中对应多个属性的置信度分数相加。融合方法和TagProp的结果分别显示在表3和表4中。我们可以观察到，我们以属性为导向的表示方法改进了在各种查询(单属性、属性对和属性三元组)下的图像检索融合技术。在TagProp框架下，通过属性对和三元组查询时的改进幅度较小，而对于单属性查询的改进则较为显著。

<table><tr><td>query</td><td>VGG</td><td>UDICA</td><td>KDICA</td></tr><tr><td>single</td><td>76.3</td><td>78.5</td><td>79.2</td></tr><tr><td>double</td><td>75.9</td><td>76.1</td><td>76.1</td></tr><tr><td>triple</td><td>75.5</td><td>75.6</td><td>75.8</td></tr></table>

<table><tbody><tr><td>查询</td><td>视觉几何组网络(VGG)</td><td>无监督动态独立成分分析(UDICA)</td><td>核动态独立成分分析(KDICA)</td></tr><tr><td>单个</td><td>76.3</td><td>78.5</td><td>79.2</td></tr><tr><td>双个；双重</td><td>75.9</td><td>76.1</td><td>76.1</td></tr><tr><td>三个；三重</td><td>75.5</td><td>75.6</td><td>75.8</td></tr></tbody></table>

Table 4. Multi-attribute based image retrieval results on AWA by TagProp. (%, in AUC)

表4. TagProp在AWA数据集上基于多属性的图像检索结果(%，以AUC衡量)

## 6. Conclusion

## 6. 结论

In this paper, we propose to re-examine the fundamental attribute detection problem and develop a novel attribute-oriented feature representation by casting the problem as multi-source domain generalization, such that one can conveniently apply off-shelf classifiers to obtain high-quality attribute detectors. The attribute detectors learned from our new representation are capable of breaking the boundaries of object categories and generalizing well to unseen classes. Extensive experiment on four datasets, and three tasks, validate that our attribute representation not only improves the quality of attributes, but also benefits succeeding applications, such as zero-shot recognition and image retrieval.

在本文中，我们提议重新审视基本的属性检测问题，并通过将该问题转化为多源领域泛化问题，开发一种新颖的面向属性的特征表示方法，这样人们就可以方便地应用现成的分类器来获得高质量的属性检测器。从我们的新表示中学习到的属性检测器能够打破对象类别的界限，并能很好地泛化到未见类别。在四个数据集和三项任务上进行的大量实验验证了我们的属性表示不仅提高了属性的质量，而且有利于后续应用，如零样本识别和图像检索。

Acknowledgement. This work was supported in part by NSF IIS-1566511. Chuang Gan was partially supported by the National Basic Research Program of China Grant 2011CBA00300, 2011CBA00301, the National Natural Science Foundation of China Grant 61033001, 61361136003. Tianbao Yang was partially supported by NSF IIS-1463988 and NSF IIS-1545995.

致谢。本工作部分得到了美国国家科学基金会(NSF)IIS - 1566511项目的支持。甘闯部分得到了中国国家基础研究计划项目(编号2011CBA00300、2011CBA00301)、中国国家自然科学基金项目(编号61033001、61361136003)的资助。杨天保部分得到了NSF IIS - 1463988和NSF IIS - 1545995项目的支持。

## References

## 参考文献

[1] Z. Akata, F. Perronnin, Z. Harchaoui, and C. Schmid. Label-embedding for attribute-based classification. In CVPR, 2013. 3, 5, 6, 7

[1] Z. Akata, F. Perronnin, Z. Harchaoui和C. Schmid。基于标签嵌入的属性分类。发表于2013年计算机视觉与模式识别会议(CVPR)。3, 5, 6, 7

[2] Z. Akata, S. Reed, D. Walter, H. Lee, and B. Schiele. Evaluation of output embeddings for fine-grained image classification. In ${CVPR}$ , pages ${2927} - {2936},{2015.7}$

[2] Z. Akata, S. Reed, D. Walter, H. Lee和B. Schiele。细粒度图像分类输出嵌入的评估。发表于${CVPR}$，第${2927} - {2936},{2015.7}$页

[3] T. Berg and P. N. Belhumeur. Poof: Part-based one-vs.- one features for fine-grained categorization, face verification, and attribute estimation. In CVPR, 2013. 2

[3] T. Berg和P. N. Belhumeur。Poof:基于部件的一对一特征用于细粒度分类、人脸验证和属性估计。发表于2013年计算机视觉与模式识别会议(CVPR)。2

[4] T. L. Berg, A. C. Berg, and J. Shih. Automatic attribute discovery and characterization from noisy web data. In ${ECCV},{2010.2}$

[4] T. L. Berg, A. C. Berg和J. Shih。从嘈杂的网络数据中自动发现和表征属性。发表于${ECCV},{2010.2}$

[5] A. Biswas and D. Parikh. Simultaneous active learning of classifiers & attributes via relative feedback. In CVPR, 2013. 3

[5] A. Biswas和D. Parikh。通过相对反馈同时主动学习分类器和属性。发表于2013年计算机视觉与模式识别会议(CVPR)。3

[6] L. Bourdev, S. Maji, and J. Malik. Describing people: A poselet-based approach to attribute classification. In ICCV, 2011. 2

[6] L. Bourdev, S. Maji和J. Malik。描述人物:一种基于姿态片的属性分类方法。发表于2011年国际计算机视觉会议(ICCV)。2

[7] S. Branson, C. Wah, F. Schroff, B. Babenko, P. Welin-der, P. Perona, and S. Belongie. Visual recognition with humans in the loop. In ${ECCV},{2010.3}$

[7] S. Branson, C. Wah, F. Schroff, B. Babenko, P. Welin - der, P. Perona和S. Belongie。有人参与的视觉识别。发表于${ECCV},{2010.3}$

[8] C.-Y. Chen and K. Grauman. Inferring analogous attributes. In ${CVPR},{2014}.1,2$

[8] C. - Y. Chen和K. Grauman。推断相似属性。发表于${CVPR},{2014}.1,2$

[9] H. Chen, A. Gallagher, and B. Girod. Describing clothing by semantic attributes. In ${ECCV},{2012.1},2$

[9] H. Chen, A. Gallagher和B. Girod。通过语义属性描述服装。发表于${ECCV},{2012.1},2$

[10] L. Chen, Q. Zhang, and B. Li. Predicting multiple attributes via relative multi-task learning. In ${CVPR},{2014}$ . 1, 2

[10] L. Chen, Q. Zhang和B. Li。通过相对多任务学习预测多个属性。发表于${CVPR},{2014}$。1, 2

[11] Q. Chen, J. Huang, R. Feris, L. M. Brown, J. Dong, and S. Yan. Deep domain adaptation for describing people based on fine-grained clothing attributes. In CVPR, 2015. 3

[11] Q. Chen, J. Huang, R. Feris, L. M. Brown, J. Dong和S. Yan。基于细粒度服装属性的深度领域自适应人物描述。发表于2015年计算机视觉与模式识别会议(CVPR)。3

[12] S.-W. Choi, C. H. Lee, and I. K. Park. Scene classification via hypergraph-based semantic attributes subnetworks identification. In ${ECCV},{2014.1},2,6,7$

[12] 崔相宇(S.-W. Choi)、李昶勋(C. H. Lee)和朴仁圭(I. K. Park)。通过基于超图的语义属性子网络识别进行场景分类。见${ECCV},{2014.1},2,6,7$

[13] C. Cortes, M. Mohri, and A. Rostamizadeh. Algorithms for learning kernels based on centered alignment. The Journal of Machine Learning Research, 13(1):795-828, 2012. 2, 3, 4, 5

[13] 科尔特斯(C. Cortes)、莫赫里(M. Mohri)和罗斯塔米扎德(A. Rostamizadeh)。基于中心对齐的核学习算法。《机器学习研究杂志》，13(1):795 - 828，2012年。2, 3, 4, 5

[14] K. Duan, D. Parikh, D. Crandall, and K. Grauman. Discovering localized attributes for fine-grained recognition. In ${CVPR},$ pages $= {3474} - {3481},$ year $= {2012.2}$

[14] 段柯(K. Duan)、帕里克(D. Parikh)、克兰德尔(D. Crandall)和格劳曼(K. Grauman)。发现用于细粒度识别的局部属性。见${CVPR},$ 第$= {3474} - {3481},$页 年份$= {2012.2}$

[15] L. Duan, I. W. Tsang, D. Xu, and T.-S. Chua. Domain adaptation from multiple sources via auxiliary classifiers. In ${ICML},{2009.3}$

[15] 段立(L. Duan)、曾毅文(I. W. Tsang)、徐丹(D. Xu)和蔡建宇(T.-S. Chua)。通过辅助分类器进行多源领域自适应。见${ICML},{2009.3}$

[16] V. Escorcia, J. C. Niebles, and B. Ghanem. On the relationship between visual attributes and convolutional networks. In ${CVPR},{2015.3}$

[16] 埃斯科西亚(V. Escorcia)、涅夫莱斯(J. C. Niebles)和加内姆(B. Ghanem)。视觉属性与卷积网络之间的关系。见${CVPR},{2015.3}$

[17] A. Farhadi, I. Endres, and D. Hoiem. Attribute-centric recognition for cross-category generalization. In CVPR, 2010. 3

[17] 法尔哈迪(A. Farhadi)、恩德斯(I. Endres)和霍耶姆(D. Hoiem)。以属性为中心的跨类别泛化识别。见2010年计算机视觉与模式识别会议(CVPR)。3

[18] A. Farhadi, I. Endres, D. Hoiem, and D. Forsyth. Describing objects by their attributes. In CVPR, 2009. 1, 2, 3,5

[18] 法尔哈迪(A. Farhadi)、恩德斯(I. Endres)、霍耶姆(D. Hoiem)和福赛思(D. Forsyth)。通过属性描述物体。见2009年计算机视觉与模式识别会议(CVPR)。1, 2, 3, 5

[19] Y. Fu, T. M. Hospedales, T. Xiang, and S. Gong. Learning multimodal latent attributes. Pattern Analysis and Machine Intelligence, IEEE Transactions on, 36(2):303- 316, 2014. 7

[19] 傅岩(Y. Fu)、霍斯佩代尔斯(T. M. Hospedales)、向涛(T. Xiang)和龚绍光(S. Gong)。学习多模态潜在属性。《IEEE模式分析与机器智能汇刊》，36(2):303 - 316，2014年。7

[20] Z. Fu, T. Xiang, E. Kodirov, and S. Gong. Zero-shot object recognition by semantic manifold distance. In CVPR, 2015. 7

[20] 付泽(Z. Fu)、向涛(T. Xiang)、科迪罗夫(E. Kodirov)和龚绍光(S. Gong)。通过语义流形距离进行零样本目标识别。见2015年计算机视觉与模式识别会议(CVPR)。7

[21] C. Gan, M. Lin, Y. Yang, Y. Zhuang, and A. G. Hauptmann. Exploring semantic inter-class relationships (SIR) for zero-shot action recognition. In ${AAAI},{2015.3}$

[21] 甘超(C. Gan)、林敏(M. Lin)、杨毅(Y. Yang)、庄越挺(Y. Zhuang)和豪普特曼(A. G. Hauptmann)。探索用于零样本动作识别的语义类间关系(SIR)。见${AAAI},{2015.3}$

[22] C. Gan, Y. Yang, L. Zhu, D. Zhao, and Y. Zhuang. Recognizing an action using its name: A knowledge-based approach. International Journal of Computer Vision, pages $1 - {17},{2016.3}$

[22] 甘超(C. Gan)、杨毅(Y. Yang)、朱磊(L. Zhu)、赵丹(D. Zhao)和庄越挺(Y. Zhuang)。利用动作名称识别动作:一种基于知识的方法。《国际计算机视觉杂志》，第$1 - {17},{2016.3}$页

[23] M. Ghifary, W. B. Kleijn, M. Zhang, and D. Balduzzi. Domain generalization for object recognition with multitask autoencoders. ICCV, 2015. 3, 4

[23] 吉法里(M. Ghifary)、克莱因(W. B. Kleijn)、张敏(M. Zhang)和巴尔杜齐(D. Balduzzi)。使用多任务自编码器进行目标识别的领域泛化。见2015年国际计算机视觉会议(ICCV)。3, 4

[24] B. Gong, K. Grauman, and F. Sha. Reshaping visual datasets for domain adaptation. In NIPS, 2013. 3

[24] 龚波(B. Gong)、格劳曼(K. Grauman)和沙飞(F. Sha)。为领域自适应重塑视觉数据集。见2013年神经信息处理系统大会(NIPS)。3

[25] B. Gong, J. Liu, X. Wang, and X. Tang. Learning seman-

[25] 龚波(B. Gong)、刘静(J. Liu)、王鑫(X. Wang)和唐晓鸥(X. Tang)。学习

tic signatures for 3d object retrieval. IEEE Transactions on Multimedia, 15(2):369-377, 2013. 3

用于三维目标检索的语义特征。《IEEE多媒体汇刊》，15(2):369 - 377，2013年。3

[26] B. Gong, Y. Shi, F. Sha, and K. Grauman. Geodesic flow kernel for unsupervised domain adaptation. In CVPR, 2012. 4

[26] 龚波(B. Gong)、施扬(Y. Shi)、沙飞(F. Sha)和格劳曼(K. Grauman)。用于无监督领域自适应的测地流核。见2012年计算机视觉与模式识别会议(CVPR)。4

[27] A. Gretton, K. M. Borgwardt, M. Rasch, B. Schölkopf, and A. J. Smola. A kernel method for the two-sample problem. In NIPS, 2006. 3

[27] A. 格雷顿(A. Gretton)、K. M. 博格瓦尔特(K. M. Borgwardt)、M. 拉施(M. Rasch)、B. 肖尔科普夫(B. Schölkopf)和 A. J. 斯莫拉(A. J. Smola)。双样本问题的核方法。发表于《神经信息处理系统大会》(NIPS)，2006 年。3

[28] M. Guillaumin, T. Mensink, J. Verbeek, and C. Schmid. Tagprop: Discriminative metric learning in nearest neighbor models for image auto-annotation. In ICCV, pages 309-316, 2009. 8

[28] M. 吉约曼(M. Guillaumin)、T. 门辛克(T. Mensink)、J. 韦贝克(J. Verbeek)和 C. 施密德(C. Schmid)。标签传播(Tagprop):用于图像自动标注的最近邻模型中的判别式度量学习。发表于《国际计算机视觉大会》(ICCV)，第 309 - 316 页，2009 年。8

[29] J. Hoffman, B. Kulis, T. Darrell, and K. Saenko. Discovering latent domains for multisource domain adaptation. In ${ECCV},{2012.3}$

[29] J. 霍夫曼(J. Hoffman)、B. 库利斯(B. Kulis)、T. 达雷尔(T. Darrell)和 K. 萨内科(K. Saenko)。多源域适应中潜在域的发现。发表于 ${ECCV},{2012.3}$

[30] J. Huang, A. Gretton, K. M. Borgwardt, B. Schölkopf, and A. J. Smola. Correcting sample selection bias by unlabeled data. In NIPS, pages 601-608, 2006. 4

[30] J. 黄(J. Huang)、A. 格雷顿(A. Gretton)、K. M. 博格瓦尔特(K. M. Borgwardt)、B. 肖尔科普夫(B. Schölkopf)和 A. J. 斯莫拉(A. J. Smola)。利用无标签数据纠正样本选择偏差。发表于《神经信息处理系统大会》(NIPS)，第 601 - 608 页，2006 年。4

[31] S. Huang, M. Elhoseiny, A. Elgammal, and D. Yang. Learning hypergraph-regularized attribute predictors. In CVPR, 2015. 1, 2

[31] S. 黄(S. Huang)、M. 埃尔霍塞尼(M. Elhoseiny)、A. 埃尔加马尔(A. Elgammal)和 D. 杨(D. Yang)。学习超图正则化属性预测器。发表于《计算机视觉与模式识别会议》(CVPR)，2015 年。1, 2

[32] S. J. Hwang, F. Sha, and K. Grauman. Sharing features between objects and their attributes. In CVPR, 2011. 1, 2

[32] S. J. 黄(S. J. Hwang)、F. 沙(F. Sha)和 K. 格劳曼(K. Grauman)。对象及其属性之间的特征共享。发表于《计算机视觉与模式识别会议》(CVPR)，2011 年。1, 2

[33] S. J. Hwang and L. Sigal. A unified semantic embedding: Relating taxonomies and attributes. In NIPS, 2014. 3

[33] S. J. 黄(S. J. Hwang)和 L. 西加尔(L. Sigal)。统一语义嵌入:关联分类法和属性。发表于《神经信息处理系统大会》(NIPS)，2014 年。3

[34] D. Jayaraman and K. Grauman. Zero-shot recognition with unreliable attributes. In NIPS, pages 3464-3472, 2014. 3,7

[34] D. 贾亚拉曼(D. Jayaraman)和 K. 格劳曼(K. Grauman)。使用不可靠属性的零样本识别。发表于《神经信息处理系统大会》(NIPS)，第 3464 - 3472 页，2014 年。3,7

[35] D. Jayaraman, F. Sha, and K. Grauman. Decorrelating semantic visual attributes by resisting the urge to share. In ${CVPR},{2014}.1,2,7$

[35] D. 贾亚拉曼(D. Jayaraman)、F. 沙(F. Sha)和 K. 格劳曼(K. Grauman)。通过抑制共享冲动来对语义视觉属性进行去相关处理。发表于 ${CVPR},{2014}.1,2,7$

[36] Y. Jia, E. Shelhamer, J. Donahue, S. Karayev, J. Long, R. B. Girshick, S. Guadarrama, and T. Darrell. Caffe: Convolutional architecture for fast feature embedding. In ACM Multimedia, volume 2, page 4, 2014. 6

[36] Y. 贾(Y. Jia)、E. 谢尔哈默(E. Shelhamer)、J. 多纳休(J. Donahue)、S. 卡拉耶夫(S. Karayev)、J. 朗(J. Long)、R. B. 吉尔希克(R. B. Girshick)、S. 瓜达拉马(S. Guadarrama)和 T. 达雷尔(T. Darrell)。Caffe:用于快速特征嵌入的卷积架构。发表于《ACM 多媒体会议》(ACM Multimedia)，第 2 卷，第 4 页，2014 年。6

[37] J. Joo, S. Wang, and S.-C. Zhu. Human attribute recognition by rich appearance dictionary. In ${ICCV},{2013.2}$

[37] J. 朱(J. Joo)、S. 王(S. Wang)和 S.-C. 朱(S.-C. Zhu)。基于丰富外观字典的人体属性识别。发表于 ${ICCV},{2013.2}$

[38] P. Kankuekul, A. Kawewong, S. Tangruamsub, and O. Hasegawa. Online incremental attribute-based zero-shot learning. In ${CVPR},{2012.3}$

[38] P. 坎库库尔(P. Kankuekul)、A. 卡韦翁(A. Kawewong)、S. 唐鲁阿姆苏布(S. Tangruamsub)和 O. 长谷川(O. Hasegawa)。基于属性的在线增量零样本学习。发表于 ${CVPR},{2012.3}$

[39] A. Karpathy, G. Toderici, S. Shetty, T. Leung, R. Suk-thankar, and L. Fei-Fei. Large-scale video classification with convolutional neural networks. In CVPR, 2014. 6

[39] A. 卡尔帕蒂(A. Karpathy)、G. 托德里奇(G. Toderici)、S. 谢蒂(S. Shetty)、T. 梁(T. Leung)、R. 苏克坦卡尔(R. Suk-thankar)和 L. 费菲(L. Fei-Fei)。使用卷积神经网络的大规模视频分类。发表于《计算机视觉与模式识别会议》(CVPR)，2014 年。6

[40] A. Kovashka, D. Parikh, and K. Grauman. Whittlesearch: Image search with relative attribute feedback. In CVPR, 2012.1,3

[40] A. 科瓦什卡(A. Kovashka)、D. 帕里克(D. Parikh)和 K. 格劳曼(K. Grauman)。细筛搜索(Whittlesearch):带有相对属性反馈的图像搜索。发表于《计算机视觉与模式识别会议》(CVPR)，2012 年。1,3

[41] A. Kovashka, S. Vijayanarasimhan, and K. Grauman. Actively selecting annotations among objects and attributes. In ${ICCV},{2011.3}$

[41] A. 科瓦什卡(A. Kovashka)、S. 维贾亚纳拉西姆汉(S. Vijayanarasimhan)和 K. 格劳曼(K. Grauman)。在对象和属性之间主动选择标注。发表于 ${ICCV},{2011.3}$

[42] N. Kumar, A. C. Berg, P. N. Belhumeur, and S. K. Nayar. Attribute and simile classifiers for face verification. In ICCV, 2009. 1, 3, 8

[42] N. 库马尔(N. Kumar)、A. C. 伯格(A. C. Berg)、P. N. 贝尔休默尔(P. N. Belhumeur)和 S. K. 纳亚尔(S. K. Nayar)。用于人脸验证的属性和比喻分类器。发表于《国际计算机视觉大会》(ICCV)，2009 年。1, 3, 8

[43] S. Lad and D. Parikh. Interactively guiding semi-supervised clustering via attribute-based explanations. In ${ECCV},{2014}.3$

[43] S. 拉德(S. Lad)和 D. 帕里克(D. Parikh)。通过基于属性的解释交互式引导半监督聚类。见${ECCV},{2014}.3$

[44] C. H. Lampert, H. Nickisch, and S. Harmeling. Learning to detect unseen object classes by between-class attribute transfer. In ${CVPR},{2009.1},2,3,5,6,7$

[44] C. H. 兰佩特(C. H. Lampert)、H. 尼克isch(H. Nickisch)和 S. 哈梅林(S. Harmeling)。通过类间属性转移学习检测未见对象类别。见${CVPR},{2009.1},2,3,5,6,7$

[45] L.-J. Li, H. Su, L. Fei-Fei, and E. P. Xing. Object bank: A high-level image representation for scene classification & semantic feature sparsification. In NIPS, 2010. 3

[45] 李立军(L.-J. Li)、苏航(H. Su)、李菲菲(L. Fei-Fei)和邢波(E. P. Xing)。对象库:用于场景分类和语义特征稀疏化的高级图像表示。见《神经信息处理系统大会》(NIPS)，2010 年。3

[46] L. Liang and K. Grauman. Beyond comparing image pairs: Setwise active learning for relative attributes. In CVPR, 2014. 3

[46] 梁亮(L. Liang)和 K. 格劳曼(K. Grauman)。超越图像对比较:用于相对属性的集合式主动学习。见《计算机视觉与模式识别会议》(CVPR)，2014 年。3

[47] P. Luo, X. Wang, and X. Tang. A deep sum-product architecture for robust facial attributes analysis. In ICCV, 2013. 3

[47] 罗平(P. Luo)、王晓刚(X. Wang)和汤晓鸥(X. Tang)。用于鲁棒面部属性分析的深度和积架构。见《国际计算机视觉会议》(ICCV)，2013 年。3

[48] D. Mahajan, S. Sellamanickam, and V. Nair. A joint learning framework for attribute models and object descriptions. In ${ICCV},{2011.2}$

[48] D. 马哈詹(D. Mahajan)、S. 塞拉马尼克姆(S. Sellamanickam)和 V. 奈尔(V. Nair)。属性模型和对象描述的联合学习框架。见${ICCV},{2011.2}$

[49] Y. Mansour, M. Mohri, and A. Rostamizadeh. Domain adaptation with multiple sources. In NIPS, 2009. 3

[49] Y. 曼苏尔(Y. Mansour)、M. 莫赫里(M. Mohri)和 A. 罗斯塔米扎德(A. Rostamizadeh)。多源领域自适应。见《神经信息处理系统大会》(NIPS)，2009 年。3

[50] K. Muandet, D. Balduzzi, and B. Schölkopf. Domain generalization via invariant feature representation. In ICML, 2013. 2, 3, 4

[50] K. 穆安代特(K. Muandet)、D. 巴尔杜齐(D. Balduzzi)和 B. 肖尔科普夫(B. Schölkopf)。通过不变特征表示进行领域泛化。见《国际机器学习会议》(ICML)，2013 年。2, 3, 4

[51] L. Niu, W. Li, and D. Xu. Visual recognition by learning from web data: A weakly supervised domain generalization approach. In ${CVPR},{2015.2},3$

[51] 牛力(L. Niu)、李伟(W. Li)和徐丹(D. Xu)。通过从网络数据中学习进行视觉识别:一种弱监督领域泛化方法。见${CVPR},{2015.2},3$

[52] M. Palatucci, D. Pomerleau, G. E. Hinton, and T. M. Mitchell. Zero-shot learning with semantic output codes. In ${NIPS},{2009.1},3,6$

[52] M. 帕拉图奇(M. Palatucci)、D. 波默罗伊(D. Pomerleau)、G. E. 辛顿(G. E. Hinton)和 T. M. 米切尔(T. M. Mitchell)。使用语义输出码的零样本学习。见${NIPS},{2009.1},3,6$

[53] S. J. Pan, I. W. Tsang, J. T. Kwok, and Q. Yang. Domain adaptation via transfer component analysis. IEEE Transactions on Neural Networks, 22(2):199-210, 2011. 4

[53] 潘世剑(S. J. Pan)、曾毅文(I. W. Tsang)、郭建涛(J. T. Kwok)和杨强(Q. Yang)。通过转移成分分析进行领域自适应。《电气与电子工程师协会神经网络汇刊》，22(2):199 - 210，2011 年。4

[54] D. Parikh and K. Grauman. Interactively building a discriminative vocabulary of nameable attributes. In CVPR, pages 1681-1688, 2011. 2

[54] D. 帕里克(D. Parikh)和 K. 格劳曼(K. Grauman)。交互式构建可命名属性的判别词汇表。见《计算机视觉与模式识别会议》(CVPR)，第 1681 - 1688 页，2011 年。2

[55] D. Parikh and K. Grauman. Relative attributes. In ICCV, 2011.1,3

[55] D. 帕里克(D. Parikh)和 K. 格劳曼(K. Grauman)。相对属性。见《国际计算机视觉会议》(ICCV)，2011 年。1, 3

[56] A. Parkash and D. Parikh. Attributes for classifier feedback. In ${ECCV},{2012.3}$

[56] A. 帕卡什(A. Parkash)和 D. 帕里克(D. Parikh)。用于分类器反馈的属性。见${ECCV},{2012.3}$

[57] G. Patterson and J. Hays. SUN attribute database: Discovering, annotating, and recognizing scene attributes. In CVPR, 2012. 1, 3

[57] G. 帕特森(G. Patterson)和 J. 海斯(J. Hays)。SUN 属性数据库:发现、标注和识别场景属性。见《计算机视觉与模式识别会议》(CVPR)，2012 年。1, 3

[58] M. Rastegari, A. Diba, D. Parikh, and A. Farhadi. Multi-attribute queries: To merge or not to merge? In ${CVPR}$ , 2013. 3

[58] M. 拉斯泰加里(M. Rastegari)、A. 迪巴(A. Diba)、D. 帕里克(D. Parikh)和 A. 法哈迪(A. Farhadi)。多属性查询:合并还是不合并？见${CVPR}$，2013 年。3

[59] R. N. Sandeep, Y. Verma, and C. Jawahar. Relative parts: Distinctive parts for learning relative attributes. In CVPR, 2014. 2

[59] R. N. 桑迪普(R. N. Sandeep)、Y. 维尔马(Y. Verma)和 C. 贾瓦哈尔(C. Jawahar)。相对部分:用于学习相对属性的独特部分。发表于《计算机视觉与模式识别会议》(CVPR)，2014 年。2

[60] W. J. Scheirer, N. Kumar, P. N. Belhumeur, and T. E. Boult. Multi-attribute spaces: Calibration for attribute fusion and similarity search. In ${CVPR},{2012.3}$

[60] W. J. 谢勒(W. J. Scheirer)、N. 库马尔(N. Kumar)、P. N. 贝尔休默尔(P. N. Belhumeur)和 T. E. 博尔特(T. E. Boult)。多属性空间:属性融合和相似性搜索的校准。发表于 ${CVPR},{2012.3}$

[61] B. Schölkopf, A. Smola, and K.-R. Müller. Kernel principal component analysis. In International Conference on Artificial Neural Networks, 1997. 4

[61] B. 肖尔科普夫(B. Schölkopf)、A. 斯莫拉(A. Smola)和 K.-R. 米勒(K.-R. Müller)。核主成分分析。发表于《国际人工神经网络会议》，1997 年。4

[62] Z. Shi, Y. Yang, T. M. Hospedales, and T. Xiang. Weakly supervised learning of objects, attributes and their associations. In ${ECCV},{2014.3}$

[62] 施泽(Z. Shi)、杨阳(Y. Yang)、T. M. 霍斯佩代尔斯(T. M. Hospedales)和向涛(T. Xiang)。对象、属性及其关联的弱监督学习。发表于 ${ECCV},{2014.3}$

[63] A. Shrivastava, S. Singh, and A. Gupta. Constrained semi-supervised learning using attributes and comparative attributes. In ${ECCV},{2012.3}$

[63] A. 什里瓦斯塔瓦(A. Shrivastava)、S. 辛格(S. Singh)和 A. 古普塔(A. Gupta)。使用属性和比较属性的约束半监督学习。发表于 ${ECCV},{2012.3}$

[64] B. Siddiquie, R. S. Feris, and L. S. Davis. Image ranking and retrieval based on multi-attribute queries. In CVPR, 2011.1,3,6

[64] B. 西迪基(B. Siddiquie)、R. S. 费里斯(R. S. Feris)和 L. S. 戴维斯(L. S. Davis)。基于多属性查询的图像排序和检索。发表于《计算机视觉与模式识别会议》(CVPR)，2011 年。1、3、6

[65] K. Simonyan and A. Zisserman. Very deep convolutional networks for large-scale image recognition. ICLR, 2015. 6

[65] K. 西蒙扬(K. Simonyan)和 A. 齐斯曼(A. Zisserman)。用于大规模图像识别的非常深的卷积网络。发表于《国际学习表征会议》(ICLR)，2015 年。6

[66] A. Smola, A. Gretton, L. Song, and B. Schölkopf. A hilbert space embedding for distributions. In Algorithmic Learning Theory, 2007. 3

[66] A. 斯莫拉(A. Smola)、A. 格雷顿(A. Gretton)、L. 宋(L. Song)和 B. 肖尔科普夫(B. Schölkopf)。分布的希尔伯特空间嵌入。发表于《算法学习理论会议》，2007 年。3

[67] K. Soomro, A. R. Zamir, and M. Shah. UCF101: A dataset of 101 human actions classes from videos in the wild. arXiv preprint arXiv:1212.0402, 2012. 2, 6

[67] K. 苏姆罗(K. Soomro)、A. R. 扎米尔(A. R. Zamir)和 M. 沙阿(M. Shah)。UCF101:一个包含 101 个人类动作类别的野外视频数据集。预印本 arXiv:1212.0402，2012 年。2、6

[68] B. K. Sriperumbudur, A. Gretton, K. Fukumizu, B. Schölkopf, and G. R. Lanckriet. Hilbert space embed-dings and metrics on probability measures. The Journal of Machine Learning Research, 11:1517-1561, 2010. 3

[68] B. K. 斯里佩伦布杜尔(B. K. Sriperumbudur)、A. 格雷顿(A. Gretton)、K. 福水(K. Fukumizu)、B. 肖尔科普夫(B. Schölkopf)和 G. R. 兰克里埃(G. R. Lanckriet)。概率测度的希尔伯特空间嵌入和度量。《机器学习研究杂志》，第 11 卷:1517 - 1561，2010 年。3

[69] Y. Su, M. Allan, and F. Jurie. Improving object classification using semantic attributes. In ${BMVC},{2010.3}$

[69] 苏洋(Y. Su)、M. 艾伦(M. Allan)和 F. 朱里(F. Jurie)。使用语义属性改进对象分类。发表于 ${BMVC},{2010.3}$

[70] C. Sun, C. Gan, and R. Nevatia. Automatic concept discovery from parallel text and visual corpora. In ${ICCV}$ , pages 2596-2604, 2015. 1

[70] 孙晨(C. Sun)、甘灿(C. Gan)和 R. 内瓦蒂亚(R. Nevatia)。从并行文本和视觉语料库中自动发现概念。发表于 ${ICCV}$，第 2596 - 2604 页，2015 年。1

[71] Q. Sun, R. Chattopadhyay, S. Panchanathan, and J. Ye. A two-stage weighting framework for multi-source domain adaptation. In NIPS, 2011. 3

[71] 孙强(Q. Sun)、R. 查托帕德亚(R. Chattopadhyay)、S. 潘查纳坦(S. Panchanathan)和叶杰平(J. Ye)。用于多源域适应的两阶段加权框架。发表于《神经信息处理系统大会》(NIPS)，2011 年。3

[72] R. Tao, A. W. Smeulders, and S.-F. Chang. Attributes and categories for generic instance search from one example. In ${CVPR},{2015.3}$

[73] 陶然(R. Tao)、A. W. 斯梅尔兹(A. W. Smeulders)和张少锋(S.-F. Chang)。从一个示例进行通用实例搜索的属性和类别。发表于 ${CVPR},{2015.3}$

[73] L. Torresani, M. Szummer, and A. Fitzgibbon. Efficient object category recognition using classemes. In ${ECCV}$ , 2010. 3

[74] L. 托雷萨尼(L. Torresani)、M. 苏默(M. Szummer)和 A. 菲茨吉本(A. Fitzgibbon)。使用类元进行高效的对象类别识别。发表于 ${ECCV}$，2010 年。3

[74] D. Tran, L. Bourdev, R. Fergus, L. Torresani, and M. Paluri. C3d: Generic features for video analysis. ${ICCV},{2015.6}$

[75] D. 陈(D. Tran)、L. 布尔代夫(L. Bourdev)、R. 弗格斯(R. Fergus)、L. 托雷萨尼(L. Torresani)和 M. 帕卢里(M. Paluri)。C3D:用于视频分析的通用特征。${ICCV},{2015.6}$

[75] A. Vedaldi, S. Mahendran, S. Tsogkas, S. Maji, R. Gir-shick, J. Kannala, E. Rahtu, I. Kokkinos, M. B. Blaschko, D. Weiss, B. Taskar, K. Simonyan, N. Saphra, and S. Mohamed. Understanding objects in detail with fine-grained attributes. In ${CVPR},{2014}.1,2$

[75] A. 韦尔瓦尔迪(A. Vedaldi)、S. 马亨德兰(S. Mahendran)、S. 索格卡斯(S. Tsogkas)、S. 马吉(S. Maji)、R. 吉尔希克(R. Gir-shick)、J. 卡纳拉(J. Kannala)、E. 拉赫图(E. Rahtu)、I. 科基诺斯(I. Kokkinos)、M. B. 布拉施科(M. B. Blaschko)、D. 韦斯(D. Weiss)、B. 塔斯卡(B. Taskar)、K. 西蒙扬(K. Simonyan)、N. 萨夫拉(N. Saphra)和 S. 穆罕默德(S. Mohamed)。利用细粒度属性详细理解物体。见${CVPR},{2014}.1,2$

[76] C. Wah, S. Branson, P. Welinder, P. Perona, and S. Be-longie. The caltech-ucsd birds-200-2011 dataset. Technical report, California Institute of Technology, 2011. 2, 5

[76] C. 瓦(C. Wah)、S. 布兰森(S. Branson)、P. 韦林德(P. Welinder)、P. 佩罗纳(P. Perona)和 S. 贝隆吉(S. Be-longie)。加州理工学院 - 加州大学圣地亚哥分校鸟类 200 - 2011 数据集。技术报告，加州理工学院，2011 年。2, 5

[77] L. Wang, Y. Qiao, and X. Tang. Motionlets: Mid-level $3\mathrm{\;d}$ parts for human motion recognition. In ${CVPR}$ , pages 2674-2681, 2013. 3

[77] L. 王(L. Wang)、Y. 乔(Y. Qiao)和 X. 唐(X. Tang)。运动元(Motionlets):用于人体运动识别的中级$3\mathrm{\;d}$部件。见${CVPR}$，第 2674 - 2681 页，2013 年。3

[78] X. Wang and Q. Ji. A unified probabilistic approach modeling relationships between attributes and objects. In ${ICCV},{2013.3}$

[78] X. 王(X. Wang)和 Q. 季(Q. Ji)。一种统一的概率方法对属性和物体之间的关系进行建模。见${ICCV},{2013.3}$

[79] Y. Wang and G. Mori. A discriminative latent model of object classes and attributes. In ${ECCV},{2010.2}$

[79] Y. 王(Y. Wang)和 G. 森(G. Mori)。一种物体类别和属性的判别式潜在模型。见${ECCV},{2010.2}$

[80] Z. Xu, W. Li, L. Niu, and D. Xu. Exploiting low-rank structure from latent domains for domain generalization. In ${ECCV},{2014.2},3,4$

[80] Z. 徐(Z. Xu)、W. 李(W. Li)、L. 牛(L. Niu)和 D. 徐(D. Xu)。从潜在领域挖掘低秩结构以实现领域泛化。见${ECCV},{2014.2},3,4$

[81] F. X. Yu, R. Ji, M.-H. Tsai, G. Ye, and S.-F. Chang. Weak attributes for large-scale image retrieval. In ${CVPR},{2012}$ . 1,3,6

[81] F. X. 余(F. X. Yu)、R. 季(R. Ji)、M.-H. 蔡(M.-H. Tsai)、G. 叶(G. Ye)和 S.-F. 张(S.-F. Chang)。用于大规模图像检索的弱属性。见${CVPR},{2012}$。1,3,6

[82] X. Yu and Y. Aloimonos. Attribute-based transfer learning for object categorization with zero/one training example. In ${ECCV},{2010.3}$

[82] X. 余(X. Yu)和 Y. 阿洛伊莫诺斯(Y. Aloimonos)。基于属性的迁移学习用于零/单训练示例的物体分类。见${ECCV},{2010.3}$

[83] N. Zhang, M. Paluri, M. Ranzato, T. Darrell, and L. Bourdev. Panda: Pose aligned networks for deep attribute modeling. In ${CVPR},{2014.2},3$

[83] N. 张(N. Zhang)、M. 帕卢里(M. Paluri)、M. 兰扎托(M. Ranzato)、T. 达雷尔(T. Darrell)和 L. 布尔代夫(L. Bourdev)。熊猫(Panda):用于深度属性建模的姿态对齐网络。见${CVPR},{2014.2},3$