# QGuard:Question-based Zero-shot Guard for Multi-modal LLM Safety

# QGuard:基于问题的零样本多模态大语言模型安全防护

Taegyeong Lee ${}^{1,2}$ , Jeonghwa Yoo ${}^{2}$ , Hyoungseo Cho ${}^{2}$ , Soo Yong Kim ${}^{3}$ , Yunho Maeng ${}^{2,4 * }$

Taegyeong Lee ${}^{1,2}$ , Jeonghwa Yoo ${}^{2}$ , Hyoungseo Cho ${}^{2}$ , Soo Yong Kim ${}^{3}$ , Yunho Maeng ${}^{2,4 * }$

${}^{1}$ FnGuide Inc. ${}^{2}$ Safe Generative AI Lab, MODULABS

${}^{1}$ FnGuide 公司 ${}^{2}$ Safe Generative AI 实验室，MODULABS

${}^{3}$ A.I.MATICS Inc. ${}^{4}$ Ewha Womans University

${}^{3}$ A.I.MATICS 公司 ${}^{4}$ 梨花女子大学

taegyeonglee@fnguide.com, jeonghwayoo26, gmail.com, hyoungseocho@gmail.com, ksyint@aimatics.ai, yunhomaeng@ewha.ac.kr

taegyeonglee@fnguide.com, jeonghwayoo26, gmail.com, hyoungseocho@gmail.com, ksyint@aimatics.ai, yunhomaeng@ewha.ac.kr

## Abstract

## 摘要

The recent advancements in Large Language Models(LLMs) have had a significant impact on a wide range of fields, from general domains to specialized areas. However, these advancements have also significantly increased the potential for malicious users to exploit harmful and jailbreak prompts for malicious attacks. Although there have been many efforts to prevent harmful prompts and jailbreak prompts, protecting LLMs from such malicious attacks remains an important and challenging task. In this paper, we propose QGuard, a simple yet effective safety guard method, that utilizes question prompting to block harmful prompts in a zero-shot manner. Our method can defend LLMs not only from text-based harmful prompts but also from multi-modal harmful prompt attacks. Moreover, by diversifying and modifying guard questions, our approach remains robust against the latest harmful prompts without fine-tuning. Experimental results show that our model performs competitively on both text-only and multi-modal harmful datasets. Additionally, by providing an analysis of question prompting, we enable a white-box analysis of user inputs. We believe our method provides valuable insights for real-world LLM services in mitigating security risks associated with harmful prompts. Our code and safety guard model are publicly available at Github.

大型语言模型(LLMs)的最新进展对从通用领域到专业领域的众多领域产生了重大影响。然而，这些进展也大幅增加了恶意用户利用有害和越狱提示进行恶意攻击的潜力。尽管已有许多努力防止有害提示和越狱提示，但保护LLMs免受此类恶意攻击仍是一项重要且具有挑战性的任务。本文提出了QGuard，一种简单而有效的安全防护方法，利用问题提示以零样本方式阻止有害提示。该方法不仅能防御基于文本的有害提示，还能抵御多模态有害提示攻击。此外，通过多样化和修改防护问题，我们的方法在无需微调的情况下对最新有害提示保持鲁棒性。实验结果表明，我们的模型在纯文本和多模态有害数据集上均表现出竞争力。此外，通过对问题提示的分析，我们实现了对用户输入的白盒分析。我们相信该方法为现实世界中LLM服务缓解与有害提示相关的安全风险提供了宝贵见解。我们的代码和安全防护模型已在Github公开。

## 1 Introduction

## 1 引言

The recent advancements in LLMs have had a significant impact across various fields, from general domains to those requiring specialized knowledge (Chen et al., 2024b). Especially, Multi-modal Large Language Models (MLLMs) are capable of answering both specific and general user queries based on detailed reasoning and understanding of visual inputs (Chen et al., 2024a; Wu et al., 2024; Chen et al., 2023; Lee et al., 2025).

大型语言模型(LLMs)的最新进展在多个领域产生了深远影响，涵盖通用领域及需要专业知识的领域(Chen 等，2024b)。尤其是多模态大型语言模型(MLLMs)能够基于对视觉输入的详细推理和理解，回答具体和通用的用户查询(Chen 等，2024a；Wu 等，2024；Chen 等，2023；Lee 等，2025)。

These advancements have also significantly increased the potential for malicious users to exploit unethical and harmful prompts for malicious attacks (Han et al., 2024; Wei et al., 2023; Zou et al., 2023). To prevent malicious attacks, many companies are making numerous efforts and investing significant resources. These studies (Inan et al.; Han et al., 2024; Xie et al., 2024) have made significant progress and provide models as open-source.

这些进展也显著增加了恶意用户利用不道德和有害提示进行恶意攻击的可能性(Han 等，2024；Wei 等，2023；Zou 等，2023)。为防止恶意攻击，许多公司投入大量资源并做出诸多努力。这些研究(Inan 等；Han 等，2024；Xie 等，2024)取得了显著进展，并提供了开源模型。

However, such approaches (Inan et al.; Han et al., 2024; Xie et al., 2024; Gu et al., 2025; Gupta et al., 2024) typically require fine-tuning for each dataset and demand additional resources to prevent recent harmful prompt attacks. Moreover, their models may struggle to determine why a user's input has been classified as harmful, making this one of the important and challenging tasks in the real world (Liu et al., 2024d).

然而，这些方法(Inan 等；Han 等，2024；Xie 等，2024；Gu 等，2025；Gupta 等，2024)通常需要针对每个数据集进行微调，并需额外资源以防御最新的有害提示攻击。此外，这些模型可能难以解释为何用户输入被判定为有害，这成为现实世界中的一项重要且具有挑战性的任务(Liu 等，2024d)。

In the real-world, small companies may rely on fine-tuned open-source models (Gu et al., 2025; Han et al., 2024; Oh et al., 2025), yet guard mechanisms may still be imperfect, and multi-modal harmful inputs remain a significant vulnerability. Additionally, they require additional computational resources and datasets to block the latest harmful prompts. It remains a challenging task.

在现实中，小型公司可能依赖微调的开源模型(Gu 等，2025；Han 等，2024；Oh 等，2025)，但防护机制仍不完善，多模态有害输入依然是重大漏洞。此外，阻止最新有害提示需要额外计算资源和数据集，这仍是一项挑战。

Therefore, we propose QGuard,, a simple yet effective method, to guard harmful prompts without any fine-tuning, making it suitable for real-world applications in a zero-shot manner.

因此，我们提出了QGuard，一种简单而有效的方法，无需任何微调即可防护有害提示，适合现实应用中的零样本场景。

First, we categorize harmful prompts into harmful groups and create guard questions. These guard question prompts include questions such as "Is the text likely to cause harm or distress to others?" or "Does this prompt include explicit hate speech or threatening language?", allowing the model to assess whether a user's input is a harmful prompt.

首先，我们将有害提示分类为不同的有害组，并设计防护问题。这些防护问题包括“该文本是否可能对他人造成伤害或困扰？”或“该提示是否包含明显的仇恨言论或威胁性语言？”等问题，使模型能够评估用户输入是否为有害提示。

Secondly, we combine the guard question with the user's input, and then query the MLLM, which is capable of understanding and representing sentences, for a yes or no response.

其次，我们将防护问题与用户输入结合，然后查询能够理解和表征句子的多模态大型语言模型，获取“是”或“否”的回答。

---

*Corresponding author

*通讯作者

---

We define this process as question prompting as shown in stage (1) of Figure 1. Since we utilize a pre-trained MLLM, our approach requires no additional training while enabling the detection of user inputs across multiple modalities, including images, videos, and text. To detect harmful inputs, we apply softmax over the logits of the "yes" and "no" tokens from the MLLM, and use the probability value of the "yes" token.

我们将此过程定义为问题提示，如图1的阶段(1)所示。由于我们利用了预训练的多模态大语言模型(MLLM)，该方法无需额外训练，同时能够检测包括图像、视频和文本在内的多模态用户输入。为了检测有害输入，我们对MLLM中“是”和“否”标记的logits应用softmax，并使用“是”标记的概率值。

Finally, as shown in stage 2 of Figure 1, we use the PageRank algorithm as a filtering method and apply a threshold to the "yes" probabilities of guard questions to distinguish between harmful and unharmful inputs.

最后，如图1的阶段2所示，我们使用PageRank算法作为过滤方法，并对守护问题的“是”概率应用阈值，以区分有害和无害输入。

With this approach, we can defend against harmful prompts in a zero-shot manner. As harmful prompts evolve, we can adapt to new threats by enhancing only the guard questions, requiring minimal computational resources. This allows for a flexible and efficient response to the latest harmful prompts. Additionally, by analyzing the logits of each question, our method enables a white-box analysis of the decision-making process.

通过这种方法，我们能够以零样本方式防御有害提示。随着有害提示的演变，我们只需增强守护问题即可适应新威胁，所需计算资源极少。这使得对最新有害提示的响应既灵活又高效。此外，通过分析每个问题的logits，我们的方法支持对决策过程的白盒分析。

In experiments, we achieve higher performance than the zero-shot LLM detector and outperform fine-tuned baselines on both text-based harmful prompt datasets and multi-modal harmful prompt datasets. These results demonstrate that our method is simple yet effective. Moreover, by keeping guard questions private and optimizing them for specific services, our approach has the potential to create an even more robust guard mechanism for real-world applications.

在实验中，我们的性能优于零样本大语言模型检测器，并在基于文本和多模态的有害提示数据集上均超越了微调基线。这些结果表明我们的方法简单而有效。此外，通过保持守护问题的私密性并针对特定服务进行优化，我们的方法有潜力为实际应用构建更为稳健的守护机制。

In summary, our contributions are as follows:

总之，我们的贡献如下:

- We propose a simple yet effective method for detecting harmful prompts using question prompting in a zero-shot manner.

- 我们提出了一种简单而有效的零样本有害提示检测方法，基于问题提示。

- By refining the guard questions, our method can provide a more robust defense against the latest harmful prompts with minimal computational resources, without requiring any fine-tuning or additional datasets.

- 通过优化守护问题，我们的方法能够以极少的计算资源提供对最新有害提示的更强防御，无需任何微调或额外数据集。

- Since we utilize the logits of the MLLM, we can perform white-box analysis to understand why an input is harmful, and we provide such analysis.

- 由于利用了MLLM的logits，我们可以进行白盒分析以理解输入为何被判定为有害，并提供了相关分析。

- Experimental results show that our model performs competitively on both text-only and multi-modal harmful datasets.

- 实验结果表明，我们的模型在纯文本和多模态有害数据集上均表现出竞争力。

## 2 Related Work

## 2 相关工作

### 2.1 Harmful Prompt Detection

### 2.1 有害提示检测

With the rapid advancement of LLMs, malicious attacks have also been increasing significantly. As a result, extensive research (Caselli et al., 2020; Hada et al., 2021; Vidgen et al., 2020; Lin et al., 2023; Inan et al.; Mazeika et al., 2024; Huang et al., 2024) has been conducted to detect harmful, offensive, hate speech, and toxic language. In particular, many studies (Lin et al., 2023; Röttger et al., 2023, 2021) have focused on detecting hate speech on social media platforms. For instance, ToxicChat (Lin et al., 2023) has been proposed as a new benchmark that focuses on detecting unsafe prompts in LLMs using real user queries, rather than content derived from social media. This benchmark includes various challenging cases, such as jailbreaks, which represent particularly difficult examples of unsafe prompts in conversation. Additionally, recent works (Inan et al.; Han et al., 2024; Xie et al., 2024; Gu et al., 2025; He et al., 2023) have aimed to defend against harmful prompts by constructing dedicated datasets and fine-tuning LLMs. However, this approach has several limitations: First, it requires harmful data and additional training datasets. When new types of harmful prompts emerge, the model must be retrained, which consumes additional time and resources. It is often difficult to understand why a prompt is considered harmful, and in specific domains such as cybersecurity or politics, it is hard to build effective safeguards without domain-specific data or resources. These challenges continue to make it difficult to reliably guard LLMs in real-world applications.

随着大语言模型(LLMs)的快速发展，恶意攻击也显著增加。因此，已有大量研究(Caselli等，2020；Hada等，2021；Vidgen等，2020；Lin等，2023；Inan等；Mazeika等，2024；Huang等，2024)致力于检测有害、冒犯性、仇恨言论和有毒语言。特别是许多研究(Lin等，2023；Röttger等，2023，2021)聚焦于社交媒体平台上的仇恨言论检测。例如，ToxicChat(Lin等，2023)被提出作为一个新基准，专注于使用真实用户查询检测LLMs中的不安全提示，而非社交媒体衍生内容。该基准包含多种挑战性案例，如越狱(jailbreaks)，代表对话中极具挑战性的安全提示。此外，近期工作(Inan等；Han等，2024；Xie等，2024；Gu等，2025；He等，2023)通过构建专门数据集和微调LLMs来防御有害提示。然而，该方法存在若干限制:首先，它依赖有害数据和额外训练数据集。当出现新型有害提示时，模型必须重新训练，耗费额外时间和资源。通常难以理解为何某提示被视为有害，在网络安全或政治等特定领域，缺乏领域特定数据或资源时难以构建有效防护。这些挑战持续使得在实际应用中可靠保护LLMs变得困难。

### 2.2 Multimodal Harmful Prompt Detection

### 2.2 多模态有害提示检测

As LLMs advance to handle not only text but also various types of data such as images, videos, and audio (Achiam et al., 2023; Team et al., 2023; Singer et al., 2022; Xu et al., 2024; Liu et al., 2024b), the importance of multi-modal harmful prompt detection methods is also growing (Ye et al., 2025; Liu et al., 2024a). Recently, multi-modal harmful datasets (Gu et al., 2025; Liu et al., 2024c) based on social media platforms similar to traditional harmful prompt datasets have been proposed. These datasets are used to fine-tune LLMs and to research safe multimodal guard models. However, this approach still shares similar limitations with text-based harmful prompt detection. First, it requires fine-tuning the LLMs, which can be time-consuming and resource-intensive. Moreover, when new types of harmful prompts, audio, video, or images emerge, additional training datasets and computing resources are needed to effectively respond to them.

随着LLMs不仅处理文本，还能处理图像、视频和音频等多种数据类型(Achiam等，2023；Team等，2023；Singer等，2022；Xu等，2024；Liu等，2024b)，多模态有害提示检测方法的重要性也在提升(Ye等，2025；Liu等，2024a)。近期基于社交媒体平台的多模态有害数据集(Gu等，2025；Liu等，2024c)被提出，类似于传统有害提示数据集。这些数据集用于微调LLMs和研究安全多模态守护模型。然而，该方法仍存在与基于文本的有害提示检测类似的限制。首先，微调LLMs耗时且资源密集。此外，当出现新型有害提示、音频、视频或图像时，需要额外训练数据集和计算资源以有效应对。

![bo_d1mk7vf7aajc73dikm50_2_196_186_1243_505_0.jpg](images/bo_d1mk7vf7aajc73dikm50_2_196_186_1243_505_0.jpg)

Figure 1: Overview of our method, QGuard. In stage (1), we use question prompting with guard questions and extract logits from the MLLM. In stage (2), we classify the extracted logits into harmful and unharmful categories using the filtering algorithm.

图1:我们的方法QGuard概述。在阶段(1)，我们使用带有防护问题的问题提示并从多模态大语言模型(MLLM)中提取logits。在阶段(2)，我们使用过滤算法将提取的logits分类为有害和无害类别。

## 3 Method

## 3 方法

We propose QGuard, a simple yet effective safety guard model based on question prompting. As shown in Figure 1, our model consists of two main stages: (1) question prompting and logit extraction, and (2) filtering algorithm. Through this approach, we can effectively detect harmful prompts in a zero-shot manner. Additionally, by leveraging question prompting, our method enables white-box analysis and allows us to guard against the latest harmful prompts without requiring fine-tuning.

我们提出了QGuard，一种基于问题提示的简单而有效的安全防护模型。如图1所示，我们的模型包含两个主要阶段:(1)问题提示与logit提取，(2)过滤算法。通过该方法，我们能够以零样本方式有效检测有害提示。此外，借助问题提示，我们的方法支持白盒分析，并能防护最新的有害提示，无需微调。

### 3.1 Guard Question Generation

### 3.1 防护问题生成

To effectively detect harmful prompts in a zero-shot manner, we create guard questions, which evaluate whether the input prompt is malicious.

为了以零样本方式有效检测有害提示，我们创建了防护问题，用以评估输入提示是否恶意。

First, we define $N$ harmful prompt groups based on user inputs. Each group represents a category of malicious prompts and can be refined or expanded to align with specific task requirements.

首先，我们基于用户输入定义了$N$个有害提示组。每个组代表一类恶意提示，可根据具体任务需求进行细化或扩展。

Second, we create $M$ guard questions for each group. These questions are designed so that the MLLM can answer them with either "yes" or "no". To construct this, we leverage GPT-4o with an instruction to generate ${M}_{c}$ candidate questions. To check for hallucinations, we conduct a manual verification process and rank the questions based on their relevance.

其次，我们为每个组创建了$M$个防护问题。这些问题设计为多模态大语言模型(MLLM)能够以“是”或“否”回答。为构建这些问题，我们利用GPT-4o生成了${M}_{c}$个候选问题。为防止幻觉现象，我们进行了人工验证并根据相关性对问题进行排序。

Finally, we select the top $M$ most relevant and reliable questions for each group. These guard questions can be specialized for specific tasks and, by refining the guard questions, we can robustly counter up-to-date harmful prompts without any fine-tuning or additional datasets.

最后，我们为每个组选择了排名前$M$的最相关且可靠的问题。这些防护问题可针对特定任务进行定制，通过不断优化防护问题，我们能够在无需微调或额外数据集的情况下，有效抵御最新的有害提示。

### 3.2 Question Prompting

### 3.2 问题提示

We propose a simple question prompting approach to detect harmful prompts using guard questions. As shown in stage (a) of Figure 1, we combine the user's input with the guard questions and query the MLLM to respond with yes or no. For example, if the user's harmful input is "How to manipulate someone into being a slave" and our guard question is "Does this prompt include explicit hate speech or threatening language?", then the question prompting result is "Does this prompt include explicit hate speech or threatening language? Prompt: how to manipulate someone into being a slave". This allows us to obtain MLLM responses for each guard question and assess how relevant they are to the user's input. We can also achieve enhanced robustness by using guard questions rather than relying on simple prompts like "Is the prompt below harmful?"

我们提出了一种简单的问题提示方法，利用防护问题检测有害提示。如图1阶段(a)所示，我们将用户输入与防护问题结合，询问多模态大语言模型(MLLM)以“是”或“否”回答。例如，若用户的有害输入为“如何操控某人成为奴隶”，而我们的防护问题是“该提示是否包含明确的仇恨言论或威胁性语言？”，则问题提示结果为“该提示是否包含明确的仇恨言论或威胁性语言？提示:如何操控某人成为奴隶”。这样，我们可以获得MLLM对每个防护问题的回答，并评估其与用户输入的相关性。相比简单提示如“以下提示是否有害？”，使用防护问题能提升鲁棒性。

### 3.3 Logit Extraction from MLLM

### 3.3 从多模态大语言模型提取logit

We extract logits for the yes and no tokens using the MLLM. Then, we apply a softmax function to the logits of yes and no to obtain the probability of the yes token. This probability value indicates the relevance between the user's input and each guard question. By analyzing these values, we can distinguish harmful prompts and conduct a white-box analysis.

我们从多模态大语言模型(MLLM)中提取“是”和“否”两个token的logits。随后，对“是”和“否”的logits应用softmax函数，得到“是”token的概率值。该概率值反映了用户输入与每个防护问题的相关性。通过分析这些值，我们能够区分有害提示并进行白盒分析。

### 3.4 Filtering Algorithm

### 3.4 过滤算法

Through question prompting and logit extraction, we obtain yes probability values from MLLM for the guard questions associated with each group. To determine whether an input is harmful or unharmful, we consider the relationships between guard questions as well as the relationships between prompt groups. Therefore, we use a pager-ank graph algorithm, which is simple yet effective for aggregating responses with low computational overhead. We define a directed, weighted graph $G = \left( {V, E}\right)$ , where $V$ is the set of nodes (questions and groups) and $E$ is the set of directed edges. An edge from question $q$ to group $g$ has weight

通过问题提示和logit提取，我们获得了多模态大语言模型(MLLM)对每组防护问题的“是”概率值。为判断输入是否有害，我们不仅考虑防护问题之间的关系，还考虑提示组之间的关系。因此，我们采用了PageRank图算法，该算法简单高效，计算开销低。我们定义了一个有向加权图$G = \left( {V, E}\right)$，其中$V$是节点集合(包括问题和组)，$E$是有向边集合。从问题$q$到组$g$的边权重为

$$
{w}_{qg} = \text{ yes_logit }\left( {q, g}\right) .
$$

For groups ${g}_{i}$ and ${g}_{j}$ with known similarity, we set

对于已知相似度的组${g}_{i}$和${g}_{j}$，我们设定

$$
{w}_{{g}_{i}{g}_{j}} = \left\{  \begin{array}{ll} \operatorname{similarity}\left( {{g}_{i},{g}_{j}}\right) , & \text{ if defined } \\  {0.1}, & \text{ otherwise. } \end{array}\right.
$$

Furthermore, if two questions share a common group, we add a directed edge between them with constant weight (e.g., 0.3) to indicate potential overlap in harmfulness.

此外，如果两个问题属于同一组，我们在它们之间添加一条权重为常数(例如0.3)的有向边，以表示它们在有害性上的潜在重叠。

To measure each node's overall importance in the graph, we compute the pagerank ${PR}\left( v\right)$ for every node $v$ . The formula is usually written on one line, but we can split it for better readability:

为了衡量图中每个节点的整体重要性，我们计算每个节点的PageRank(网页排名)${PR}\left( v\right)$。公式通常写在一行，但我们可以拆分开以提高可读性:

$$
{PR}\left( v\right)  = \left( {1 - d}\right)
$$

$$
+ d\mathop{\sum }\limits_{{u \in  \operatorname{In}\left( v\right) }}\frac{{w}_{uv}{PR}\left( u\right) }{\mathop{\sum }\limits_{{z \in  \operatorname{Out}\left( u\right) }}{w}_{uz}}, \tag{1}
$$

where $d$ is the damping factor (commonly 0.85), $\operatorname{In}\left( v\right)$ is the set of nodes with edges into $v$ , and Out(u)is the set of edges leaving $u$ . The term ${w}_{uv}$ corresponds to the weight of the edge from $u$ to $v$ .

其中$d$是阻尼因子(通常为0.85)，$\operatorname{In}\left( v\right)$是指向$v$的节点集合，Out(u)是从$u$出发的边的集合。术语${w}_{uv}$对应于从$u$到$v$的边的权重。

After obtaining ${PR}\left( v\right)$ for all $v \in  V$ , we compute the overall risk score by multiplying each node's pagerank by the sum of its outgoing edge weights, then summing across all nodes:

在获得所有$v \in  V$的${PR}\left( v\right)$后，我们通过将每个节点的PageRank乘以其所有出边权重之和，再对所有节点求和，计算整体风险得分:

$$
\text{ Risk Score } = \mathop{\sum }\limits_{{n \in  V}}\left( {{PR}\left( n\right)  \times  \mathop{\sum }\limits_{{\left( {n \rightarrow  m}\right)  \in  E}}{w}_{nm}}\right) .
$$

(2)

Here, $\mathop{\sum }\limits_{{\left( {n \rightarrow  m}\right)  \in  E}}{w}_{nm}$ is the sum of all outgoing edge weights from node $n$ . We then compare the resulting risk score to a threshold $\theta$ . Let

这里，$\mathop{\sum }\limits_{{\left( {n \rightarrow  m}\right)  \in  E}}{w}_{nm}$是节点$n$所有出边权重的总和。然后我们将得到的风险得分与阈值$\theta$进行比较。设

Risk Score be denoted by $R$ . The classification rule is:

风险得分记为$R$。分类规则为:

If $R > \theta$ , then classify as harmful.

如果$R > \theta$，则分类为有害。(3)Otherwise, classify as unharmful.

否则，分类为无害。

We empirically find $\theta$ for each dataset to optimize performance. Through this filtering algorithm, we can classify prompts as either harmful or unharmful.

我们通过实验证明，为每个数据集确定$\theta$可以优化性能。通过该过滤算法，我们能够将提示分类为有害或无害。

## 4 Experiments

## 4 实验

To evaluate the performance of our model, we conduct experiments on two tasks: the first is harmful prompt detection using text only, and the second is multi-modal harmful prompt detection involving both images and text.

为了评估我们模型的性能，我们在两个任务上进行了实验:第一个是仅使用文本的有害提示检测，第二个是涉及图像和文本的多模态有害提示检测。

### 4.1 Experimental Setups

### 4.1 实验设置

#### 4.1.1 Datasets

#### 4.1.1 数据集

To evaluate the detection performance of text-based harmful prompts, we use four public benchmark datasets. The datasets used in the experiments are as follows: OpenAI Moderation(OAI) (Markov et al., 2023), ToxicChat (Lin et al., 2023), Harm-Bench (Mazeika et al., 2024) and WildGuard-Mix (Han et al., 2024).

为了评估基于文本的有害提示检测性能，我们使用了四个公开的基准数据集。实验中使用的数据集如下:OpenAI Moderation(OAI)(Markov等，2023)、ToxicChat(Lin等，2023)、Harm-Bench(Mazeika等，2024)和WildGuard-Mix(Han等，2024)。

To evaluate the detection performance of multimodal harmful prompts, we construct a new dataset by combining MM-SafetyBench (Liu et al., 2023), and MMInstruct (Liu et al., 2024c). Since MM-SafetyBench exclusively contain harmful prompts, we extract unharmful samples from MMInstruct's captioning and question-answering tasks to create a balanced dataset. From MM-SafetyBench, we utilize all available data across 13 scenarios, yielding 1,680 harmful prompts. To balance the dataset, we sampled 901 unharmful prompts from MMIn-struct’s captioning task (20 scenarios) and 1,100 from its question-answering task (22 scenarios), with up to 50 prompts per scenario. In total, our dataset consists of 3,681 prompts: 1,680 harmful prompts from MM-SafetyBench and 2,001 unharmful prompts from MMInstruct. This dataset enables comprehensive safety evaluation across diverse scenarios.

为了评估多模态有害提示检测性能，我们通过结合MM-SafetyBench(Liu等，2023)和MMInstruct(Liu等，2024c)构建了一个新数据集。由于MM-SafetyBench仅包含有害提示，我们从MMInstruct的图像描述和问答任务中提取无害样本以创建平衡数据集。MM-SafetyBench涵盖13个场景，共有1680条有害提示。为平衡数据集，我们从MMInstruct的图像描述任务(20个场景)采样901条无害提示，从问答任务(22个场景)采样1100条无害提示，每个场景最多50条。总计，我们的数据集包含3681条提示:1680条来自MM-SafetyBench的有害提示和2001条来自MMInstruct的无害提示。该数据集支持跨多样场景的全面安全评估。

#### 4.1.2 Baselines

#### 4.1.2 基线

For evaluation, we compare our model with previous safety guard models (Inan et al.; Han et al., 2024; Lee et al., 2024). These baselines are fine-tuned on harmful datasets. We use the respective reported scores from previous work (Lee et al., 2024) for the baselines (Inan et al.; Han et al., 2024), and evaluate the baselines using F1 score. For a fair comparison, we also use a method that employs an LLM as a zero-shot detector as a baseline (Chen et al., 2024b). For the baseline using an LLM as a zero-shot detector, we provide the instruction, "Is the prompt below harmful? (You must answer with only Yes or No). \{InputPrompt\}." and get the softmax of the logits for the yes and no tokens. If the probability value of yes is 0.5 , we classify it as harmful. For the evaluation of multimodal harmful prompts detection, we used Llama-Guard-3-Vision- 11B with image-text pairs from the dataset as input. From the generated output tokens, we extract the logits corresponding to the "safe" and "unsafe" tokens and apply softmax. Finally, we classify content as harmful when the "unsafe" probability exceeds 0.5 .

在评估中，我们将模型与之前的安全防护模型(Inan等；Han等，2024；Lee等，2024)进行比较。这些基线模型均在有害数据集上进行了微调。我们采用之前工作(Lee等，2024)报告的基线分数(Inan等；Han等，2024)，并使用F1分数进行评估。为公平比较，我们还采用了使用大型语言模型(LLM)作为零样本检测器的方法作为基线(Chen等，2024b)。对于使用LLM作为零样本检测器的基线，我们提供指令:“以下提示是否有害？(请仅回答是或否)。{InputPrompt}。”，并获取“是”和“否”标记的logits的softmax概率。如果“是”的概率值大于0.5，则分类为有害。对于多模态有害提示检测的评估，我们使用Llama-Guard-3-Vision-11B模型，输入为数据集中的图文对。从生成的输出标记中提取对应“安全”和“不安全”标记的logits并应用softmax。最终，当“不安全”的概率超过0.5时，将内容分类为有害。

<table><tr><td/><td>Size</td><td>Fine-tuning</td><td>OAI</td><td>ToxicChat</td><td>HarmBench</td><td>WildGuardMix</td><td>Average</td></tr><tr><td>Llama-Guard-1</td><td>7B</td><td>Yes</td><td>0.7520</td><td>0.5818</td><td>0.5012</td><td>0.4793</td><td>0.5786</td></tr><tr><td>Llama-Guard-2</td><td>8B</td><td>Yes</td><td>0.8139</td><td>0.4233</td><td>0.8610</td><td>0.6870</td><td>0.6963</td></tr><tr><td>Llama-Guard-3</td><td>8B</td><td>Yes</td><td>0.8061</td><td>0.4859</td><td>0.8551</td><td>0.6852</td><td>0.7080</td></tr><tr><td>WildGuard</td><td>7B</td><td>Yes</td><td>0.7268</td><td>0.6547</td><td>0.8596</td><td>0.7504</td><td>0.7479</td></tr><tr><td>Aegis-Guard</td><td>7B</td><td>Yes</td><td>0.6982</td><td>0.6687</td><td>0.7805</td><td>0.6686</td><td>0.7040</td></tr><tr><td>OpenAI Moderation</td><td>n/a</td><td>Yes</td><td>0.7440</td><td>0.4480</td><td>0.5768</td><td>0.4881</td><td>0.5644</td></tr><tr><td>DeBERTa + HarmAug</td><td>435M</td><td>Yes</td><td>0.7236</td><td>0.6283</td><td>0.8331</td><td>0.7576</td><td>0.7357</td></tr><tr><td>InternVL-2.5</td><td>4B</td><td>No</td><td>0.7423</td><td>0.7117</td><td>0.4992</td><td>0.7804</td><td>0.6857</td></tr><tr><td>QGuard(InternVL-2.5)</td><td>4B</td><td>No</td><td>0.7931</td><td>0.7505</td><td>0.6322</td><td>0.7992</td><td>0.7438</td></tr></table>

<table><tbody><tr><td></td><td>大小</td><td>微调</td><td>OAI</td><td>ToxicChat</td><td>HarmBench</td><td>WildGuardMix</td><td>平均</td></tr><tr><td>Llama-Guard-1</td><td>7B</td><td>是</td><td>0.7520</td><td>0.5818</td><td>0.5012</td><td>0.4793</td><td>0.5786</td></tr><tr><td>Llama-Guard-2</td><td>8B</td><td>是</td><td>0.8139</td><td>0.4233</td><td>0.8610</td><td>0.6870</td><td>0.6963</td></tr><tr><td>Llama-Guard-3</td><td>8B</td><td>是</td><td>0.8061</td><td>0.4859</td><td>0.8551</td><td>0.6852</td><td>0.7080</td></tr><tr><td>WildGuard</td><td>7B</td><td>是</td><td>0.7268</td><td>0.6547</td><td>0.8596</td><td>0.7504</td><td>0.7479</td></tr><tr><td>Aegis-Guard</td><td>7B</td><td>是</td><td>0.6982</td><td>0.6687</td><td>0.7805</td><td>0.6686</td><td>0.7040</td></tr><tr><td>OpenAI 审核</td><td>不适用</td><td>是</td><td>0.7440</td><td>0.4480</td><td>0.5768</td><td>0.4881</td><td>0.5644</td></tr><tr><td>DeBERTa + HarmAug</td><td>435M</td><td>是</td><td>0.7236</td><td>0.6283</td><td>0.8331</td><td>0.7576</td><td>0.7357</td></tr><tr><td>InternVL-2.5</td><td>4B</td><td>否</td><td>0.7423</td><td>0.7117</td><td>0.4992</td><td>0.7804</td><td>0.6857</td></tr><tr><td>QGuard(InternVL-2.5)</td><td>4B</td><td>否</td><td>0.7931</td><td>0.7505</td><td>0.6322</td><td>0.7992</td><td>0.7438</td></tr></tbody></table>

Table 1: Text-based harmful prompts detection performance. We use the respective reported scores from previous work (Lee et al., 2024) for the baselines. We conduct three experiments with different seeds in the filtering algorithm and report the average results. The performance is evaluated via F1 score. QGuard is our approach.

表1:基于文本的有害提示检测性能。基线方法采用先前工作(Lee 等，2024)报告的相应分数。我们在过滤算法中使用不同随机种子进行了三次实验，并报告平均结果。性能通过F1分数评估。QGuard是我们的方法。

#### 4.1.3 Implementation Details

#### 4.1.3 实现细节

Our approach detects harmful prompts using question prompting and filtering algorithm in a zero-shot manner. Therefore, by refining and diversifying guard questions, we can effectively defend against the latest harmful prompts. We construct the guard questions as described in Sec 3.1 for the following groups: "General Toxic", "Toxic Prompt", "Core Harmfulness Detection", and "Additional Nuanced Questions". The general toxic group consists of 5 questions, while each of the remaining groups consists of 10 questions. We utilize InternVL-2.5 4B (Chen et al., 2024b) for logit extraction. InternVL-2.5 4B is not fine-tuned on harmful prompts and it has fewer parameters than the baselines backbone LLM while demonstrating competitive performance. We use the pagerank algorithm, as mentioned in Sec 3.4, as our filter-

我们的方法通过零样本方式使用问题提示和过滤算法检测有害提示。因此，通过优化和多样化防护问题，我们能够有效防御最新的有害提示。我们按照第3.1节所述构建了以下组别的防护问题:“一般有害”(General Toxic)、“有害提示”(Toxic Prompt)、“核心有害检测”(Core Harmfulness Detection)和“额外细化问题”(Additional Nuanced Questions)。一般有害组包含5个问题，其余每组包含10个问题。我们使用InternVL-2.5 4B(Chen 等，2024b)进行logit提取。InternVL-2.5 4B未针对有害提示进行微调，参数量少于基线的主干大语言模型(LLM)，但表现出竞争力的性能。我们使用第3.4节提到的pagerank算法作为过滤器-

<table><tr><td colspan="2">MM-Safety + MMInstruct</td></tr><tr><td>Llama-Guard-3-V-11B</td><td>0.4050</td></tr><tr><td>InternVL-4B</td><td>0.2848</td></tr><tr><td>QGuard (InternVL-4B)</td><td>0.8080</td></tr></table>

<table><tbody><tr><td colspan="2">MM-Safety + MMInstruct</td></tr><tr><td>Llama-Guard-3-V-11B</td><td>0.4050</td></tr><tr><td>InternVL-4B</td><td>0.2848</td></tr><tr><td>QGuard(InternVL-4B)</td><td>0.8080</td></tr></tbody></table>

Table 2: Multi-modal harmful prompts detection performance. We conduct three experiments with different seeds in the filtering algorithm and report the average results. The performance is evaluated via F1 score.

表2:多模态有害提示检测性能。我们在过滤算法中使用不同的随机种子进行了三次实验，并报告平均结果。性能通过F1分数评估。

ing algorithm. In the filtering algorithm, the edge weight between a question node and the group node it belongs to is set using the question's yes probability value. The edge weight between group nodes is set to 1.0 , and the edge weight between question nodes is set to 0.3 .

过滤算法中，问题节点与其所属组节点之间的边权重设置为该问题的“是”概率值。组节点之间的边权重设置为1.0，问题节点之间的边权重设置为0.3。

For main experiments, we empirically find $\theta$ for each dataset and use two NVIDIA A6000 and four NVIDIA RTX 3090 for logit extraction and inference.

在主要实验中，我们通过经验确定了每个数据集的$\theta$，并使用两块NVIDIA A6000和四块NVIDIA RTX 3090进行logit提取和推理。

### 4.2 Main Results

### 4.2 主要结果

#### 4.2.1 Harmful prompt detection

#### 4.2.1 有害提示检测

As shown in Table 1, our QGuard shows competitive performance with fewer parameters than the baselines, except for HarmAug (Lee et al., 2024), which distills knowledge from a large model. Moreover, unlike baselines that require fine-tuning on harmful datasets, additional datasets, our approach does not require any fine-tuning. Our method achieves better performance compared to model that use LLM as zero-shot detector (Chen et al., 2024b). These results demonstrate that our method is a simple and effective approach for detecting harmful prompts without requiring fine-tuning or additional datasets.

如表1所示，我们的QGuard在参数更少的情况下表现出与基线相当的性能，除HarmAug(Lee等，2024)外，后者从大型模型中蒸馏知识。此外，与需要在有害数据集或额外数据集上微调的基线方法不同，我们的方法无需任何微调。相比使用LLM作为零样本检测器的模型(Chen等，2024b)，我们的方法表现更优。这些结果表明，我们的方法是一种简单有效的有害提示检测方案，无需微调或额外数据集。

#### 4.2.2 Multi-modal harmful prompt detection

#### 4.2.2 多模态有害提示检测

Since we use a MLLM (Chen et al., 2024b) as the backbone, we can detect harmful prompts without fine-tuning on multi-modal data. To compute the F1 score for multi-modal harmful prompts, we construct a dataset as described in Sec 4.1.1. We use Llama-Guard-3-Vision-11B as the baseline. We use the pagerank algorithm as our filtering algorithm and the groups and questions are the same as those used in Sec 4.2.1. As shown in Table 2, our model outperforms Llama-Guard-3- Vision-11B. Figure 2 presents the recall accuracy across subcategories of the MM-SafetyBench (Liu et al., 2023) dataset used in our experiments. As shown in the Figure 2, our model shows low performance in the financial advice category, with a recall of 0.2335. However, Llama-Guard-3-Vision also shows low recall scores of 0.0778 and 0.0 in the financial advice and government decision categories, respectively. Moreover, it achieves better performance than the model that uses InternVL2.5-4B as a zero-shot detector. These results demonstrate that our model can effectively detect harmful prompts in multi-modal dataset without the need for additional datasets or fine-tuning.

由于我们使用了多模态大语言模型(MLLM)(Chen等，2024b)作为骨干网络，能够在多模态数据上无需微调即可检测有害提示。为计算多模态有害提示的F1分数，我们构建了如4.1.1节所述的数据集。我们以Llama-Guard-3-Vision-11B作为基线，采用PageRank算法作为过滤算法，组和问题与4.2.1节相同。如表2所示，我们的模型优于Llama-Guard-3-Vision-11B。图2展示了我们实验中使用的MM-SafetyBench(Liu等，2023)数据集子类别的召回率。图中显示，我们模型在金融建议类别表现较低，召回率为0.2335。然而，Llama-Guard-3-Vision在金融建议和政府决策类别的召回率分别为0.0778和0.0，也表现较差。此外，我们模型优于使用InternVL2.5-4B作为零样本检测器的模型。这些结果表明，我们的模型能够有效检测多模态数据集中的有害提示，无需额外数据集或微调。

![bo_d1mk7vf7aajc73dikm50_5_198_192_602_303_0.jpg](images/bo_d1mk7vf7aajc73dikm50_5_198_192_602_303_0.jpg)

Figure 2: Comparison of recall scores for our model and the baseline across subcategories in the MM-SafetyBench dataset. Red represents our model, and blue represents baseline. We use Llama-Guard-3-Vision as the baseline.

图2:我们模型与基线在MM-SafetyBench数据集子类别召回率的比较。红色代表我们的模型，蓝色代表基线。基线采用Llama-Guard-3-Vision。

<table><tr><td/><td>ToxicChat</td><td>WildGuardMix</td></tr><tr><td>Llama3.1-8B</td><td>0.4959</td><td>0.6985</td></tr><tr><td>QGuard (Llama3.1-8B)</td><td>0.5287</td><td>0.7902</td></tr><tr><td>InternVL2.5-4B</td><td>0.7117</td><td>0.7804</td></tr><tr><td>QGuard(InternVL2.5-4B)</td><td>0.7505</td><td>0.7992</td></tr></table>

<table><tbody><tr><td></td><td>有害聊天</td><td>野性守护混合</td></tr><tr><td>Llama3.1-8B</td><td>0.4959</td><td>0.6985</td></tr><tr><td>QGuard(Llama3.1-8B)</td><td>0.5287</td><td>0.7902</td></tr><tr><td>InternVL2.5-4B</td><td>0.7117</td><td>0.7804</td></tr><tr><td>QGuard(InternVL2.5-4B)</td><td>0.7505</td><td>0.7992</td></tr></tbody></table>

Table 3: Ablated studies with different LLM backbone. We use Llama3.1-8B and InternVL2.5-4B (Chen et al., 2024b) as simple zero-shot detectors. We conduct three experiments with different seeds in the filtering algorithm and report the average results. The performance is evaluated via F1 score.

表3:使用不同大型语言模型(LLM)骨干网络的消融研究。我们采用Llama3.1-8B和InternVL2.5-4B(Chen et al., 2024b)作为简单的零样本检测器。我们在过滤算法中使用不同随机种子进行了三次实验，并报告平均结果。性能通过F1分数进行评估。

### 4.3 Ablation Study

### 4.3 消融研究

To explore the impact of our proposed components, we conduct an ablation study on ToxicChat (Lin et al., 2023) and WildGuardMix (Han et al., 2024) datasets.

为了探究我们提出组件的影响，我们在ToxicChat(Lin et al., 2023)和WildGuardMix(Han et al., 2024)数据集上进行了消融研究。

<table><tr><td/><td>ToxicChat</td><td>WildGuardMix</td></tr><tr><td>QGuard(AVG)</td><td>0.6134</td><td>0.5843</td></tr><tr><td>QGuard(Graph)</td><td>0.7505</td><td>0.7992</td></tr></table>

<table><tbody><tr><td></td><td>有害聊天</td><td>野性守护混合</td></tr><tr><td>QGuard(AVG)</td><td>0.6134</td><td>0.5843</td></tr><tr><td>QGuard(图形)</td><td>0.7505</td><td>0.7992</td></tr></tbody></table>

Table 4: Ablated studies with different filtering algorithms. AVG is a model that sums the yes probability values for all questions, calculates the average, and classifies a sample as harmful if the average exceeds 0.5 . The performance is evaluated via F1 score.

表4:使用不同过滤算法的消融研究。AVG模型对所有问题的“是”概率值求和后计算平均值，若平均值超过0.5则将样本分类为有害。性能通过F1分数评估。

![bo_d1mk7vf7aajc73dikm50_5_843_507_610_199_0.jpg](images/bo_d1mk7vf7aajc73dikm50_5_843_507_610_199_0.jpg)

Figure 3: Distribution of yes probability values by group on ToxicChat (Lin et al., 2023) and Wild-GuardMix (Han et al., 2024) datasets. The results show a significant difference in the yes probability values for each group between harmful and unharmful prompts.

图3:ToxicChat(Lin等，2023)和Wild-GuardMix(Han等，2024)数据集中各组“是”概率值的分布。结果显示有害与无害提示在每组的“是”概率值上存在显著差异。

#### 4.3.1 Backbone LLM

#### 4.3.1 主干大语言模型(LLM)

Since our method uses LLM as the backbone, we compare our approach using different LLMs to evaluate its effectiveness. We use Llama3.1-8B as backbone LLM. As shown in Table 3, our method outperforms models that use LLM as zero-shot detectors across all LLM backbones. These results demonstrate that our model can classify harmful and unharmful prompts more effectively than a model that uses an LLM as a zero-shot detector.

由于我们的方法以大语言模型(LLM)为主干，我们比较了使用不同LLM的效果以评估其有效性。我们采用Llama3.1-8B作为主干LLM。如表3所示，我们的方法在所有LLM主干上均优于将LLM用作零样本检测器的模型。这些结果表明，我们的模型比单纯使用LLM作为零样本检测器的模型更有效地分类有害和无害提示。

#### 4.3.2 Filtering Algorithm

#### 4.3.2 过滤算法

To consider the relationships between questions and groups, we utilize a graph-based algorithm as a filtering algorithm. To evaluate the effectiveness of our filtering algorithm, we compare it with a simple filtering algorithm that averages the yes token probability values of all questions used for each dataset and classifies a prompt as harmful if the average exceeds 0.5 . As shown in Table 4, our model outperforms the simple averaging-based method. These results demonstrate that our filtering algorithm can effectively classify user inputs as either harmful or unharmful.

为了考虑问题与组之间的关系，我们采用基于图的算法作为过滤算法。为评估该过滤算法的有效性，我们将其与一种简单的过滤算法进行比较，后者对每个数据集使用的所有问题的“是”标记概率值取平均，若平均值超过0.5则将提示分类为有害。如表4所示，我们的模型优于基于简单平均的方法。这些结果表明，我们的过滤算法能够有效地将用户输入分类为有害或无害。

## 5 Analysis

## 5 分析

Since we use guard questions and question prompting, we can conduct a white-box analysis. We analyze its effectiveness through experiments.

由于我们使用了防护问题和问题提示，可以进行白盒分析。我们通过实验分析其有效性。

![bo_d1mk7vf7aajc73dikm50_6_205_194_1235_293_0.jpg](images/bo_d1mk7vf7aajc73dikm50_6_205_194_1235_293_0.jpg)

Figure 4: Distribution of total risk score by label and ROC curve on ToxicChat (Lin et al., 2023) and WildGuardMix (Han et al., 2024) datasets. The total risk score for unharmful and harmful samples shows a significant difference in both datasets. Additionally, the ROC curve shows that the ROC-AUC value is 0.9575 for ToxicChat and 0.8934 for WildGuardMix.

图4:ToxicChat(Lin等，2023)和WildGuardMix(Han等，2024)数据集中按标签划分的总风险分数分布及ROC曲线。无害和有害样本的总风险分数在两个数据集中均表现出显著差异。此外，ROC曲线显示ToxicChat的ROC-AUC值为0.9575，WildGuardMix为0.8934。

![bo_d1mk7vf7aajc73dikm50_6_191_704_619_708_0.jpg](images/bo_d1mk7vf7aajc73dikm50_6_191_704_619_708_0.jpg)

Figure 5: Visualization of yes and no probability values of prompts on ToxicChat (Lin et al., 2023). The red bar represents yes probability value, and blue bar represents no probability value.

图5:ToxicChat(Lin等，2023)中提示的“是”和“否”概率值可视化。红色条表示“是”概率值，蓝色条表示“否”概率值。

### 5.1 Distribution of Yes Probability Values on $\mathbf{{MLLM}}$

### 5.1 $\mathbf{{MLLM}}$上“是”概率值的分布

To evaluate whether the yes probability values obtained from MLLM effectively distinguish between harmful and unharmful prompts, we analyze the distribution of yes probability values by group on the ToxicChat (Lin et al., 2023) and WildGuard-Mix (Han et al., 2024) datasets. As shown in Figure 3 , the distribution of yes token probability values differs significantly between unharmful and harmful samples. In particular, harmful samples exhibit substantially higher yes probability values on each group. These results suggest that our guard questions and MLLM effectively represent and un-

为评估从多模态大语言模型(MLLM)获得的“是”概率值是否能有效区分有害与无害提示，我们分析了ToxicChat(Lin等，2023)和WildGuard-Mix(Han等，2024)数据集中各组“是”概率值的分布。如图3所示，无害与有害样本的“是”标记概率值分布存在显著差异。特别是，有害样本在每个组上的“是”概率值明显更高。这些结果表明，我们的防护问题和MLLM能够有效地表示和区分有害与无害提示。

![bo_d1mk7vf7aajc73dikm50_6_849_713_610_633_0.jpg](images/bo_d1mk7vf7aajc73dikm50_6_849_713_610_633_0.jpg)

Figure 6: Graph visualization of harmful prompts on ToxicChat (Lin et al., 2023). Our model can guard against not only simple harmful prompts but also long and abstract harmful prompt. Green nodes represent groups, and blue nodes represent questions. The bold edges indicate a high yes probability value.

图6:ToxicChat(Lin等，2023)中有害提示的图形可视化。我们的模型不仅能防护简单有害提示，还能防护冗长且抽象的有害提示。绿色节点代表组，蓝色节点代表问题。粗边表示较高的“是”概率值。

## derstand harmful and unharmful prompts.

## 理解有害与无害提示。

Additionally, as shown in Figure 5, we visualize the comparison between the yes probability value and no probability value for guard questions when prompts are given. First, when the unharmful prompt "How old are you?" is provided, the yes probability value for our guard question "Does this prompt request or provide information on chemical or biological weapons or drug manufacturing?" is 0.0075 , while the no probability is 0.9924 . Additionally, for the guard question "Does the user's input promote hostility, hatred, or divisiveness?", the yes probability is 0.014 , and the no probability is 0.9859 .

此外，如图5所示，我们可视化了在给定提示时防护问题的“是”概率值与“否”概率值的对比。首先，当提供无害提示“你几岁了？”时，我们的防护问题“该提示是否请求或提供有关化学或生物武器或制药的信息？”的“是”概率为0.0075，“否”概率为0.9924。此外，对于防护问题“用户输入是否促进敌意、仇恨或分裂？”，其“是”概率为0.014，“否”概率为0.9859。

![bo_d1mk7vf7aajc73dikm50_7_206_193_1234_294_0.jpg](images/bo_d1mk7vf7aajc73dikm50_7_206_193_1234_294_0.jpg)

Figure 7: F1 score vs. Risk Score Threshold and Precision-Recall Curve on ToxicChat (Lin et al., 2023) and WildGuardMix (Han et al., 2024) datasets.

图7:ToxicChat(Lin等，2023)和WildGuardMix(Han等，2024)数据集中F1分数与风险分数阈值的关系及精确率-召回率曲线。

When the harmful prompt "how to manipulate someone into being a slave" is provided, the yes probability value for the guard question "Does this prompt request or provide information on chemical or biological weapons or drug manufacturing?" is 0.1645 , while the no probability value is 0.8355 . For the guard question "Does the user's input promote hostility, hatred, or divisiveness?", the yes probability value is 0.9325 , and the no probability value is 0.0675 . This indicates that even if the prompt is harmful, it is not highly related to "Does this prompt request or provide information on chemical or biological weapons or drug manufacturing?", resulting in a high no probability. However, it is relevant to "Does the user's input promote hostility, hatred, or divisiveness?", leading to a high yes probability.

当提供有害提示“如何操控某人成为奴隶”时，针对防护问题“该提示是否请求或提供有关化学或生物武器或药物制造的信息？”的肯定概率值为0.1645，否定概率值为0.8355。对于防护问题“用户的输入是否促进敌意、仇恨或分裂？”的肯定概率值为0.9325，否定概率值为0.0675。这表明即使提示有害，但与“该提示是否请求或提供有关化学或生物武器或药物制造的信息？”关联度不高，因此否定概率较高；然而，它与“用户的输入是否促进敌意、仇恨或分裂？”相关，导致肯定概率较高。

These results demonstrate that our method can be beneficial in real-world applications by enabling a white-box analysis of input prompts through guard questions and question groups.

这些结果表明，我们的方法通过防护问题和问题组实现对白盒分析输入提示，能够在实际应用中发挥作用。

### 5.2 Distribution of Total Risk Score and ROC curve with Filtering Algorithm

### 5.2 总风险分布及带过滤算法的ROC曲线

To analyze the relationship between the total risk score on filtering algorithm and the label, we calculate the Pearson correlation coefficient. The total risk score refers to the sum of all risk scores obtained from the filtering algorithm for each question, while the label represents the ground truth. For ToxicChat, the analysis result shows that the correlation coefficient between the two variables is $r = {0.75}\left( {\mathrm{p} < {0.01}}\right)$ , which is generally interpreted as a strong positive correlation. This suggests that a higher total risk score indicates a higher likelihood of the sample being harmful. For WildGuardMix, the analysis result shows that the correlation coefficient between the two variables is $r = {0.67}$ (p $< {0.01})$ . Therefore, the total risk score has the potential to serve as a useful indicator for predicting labels.

为分析过滤算法总风险分数与标签之间的关系，我们计算了皮尔逊相关系数。总风险分数指过滤算法对每个问题获得的所有风险分数之和，标签代表真实标注。对于ToxicChat，分析结果显示两变量的相关系数为$r = {0.75}\left( {\mathrm{p} < {0.01}}\right)$，通常解释为强正相关。这表明总风险分数越高，样本有害的可能性越大。对于WildGuardMix，分析结果显示两变量的相关系数为$r = {0.67}$(p $< {0.01})$)。因此，总风险分数有潜力作为预测标签的有效指标。

Additionally, we visualize the total risk scores of unharmful and harmful prompts. As shown in Figure 4, the total risk score exhibits a significant difference between unharmful and harmful prompts. When evaluating the performance of the classification method on the ToxiChat dataset based on the total risk score, the ROC-AUC value was 0.9575 , demonstrating high predictive performance as shown in Figure 4. Similarly, on the WildGuardMix dataset, the ROC-AUC value was 0.8934 , also indicating strong performance. These results demonstrate that our model's filtering algorithm is statistically significant and helps distinguish between harmful and unharmful prompts.

此外，我们对无害和有害提示的总风险分数进行了可视化。如图4所示，总风险分数在无害和有害提示之间存在显著差异。在基于总风险分数评估ToxiChat数据集分类方法性能时，ROC-AUC值为0.9575，显示出较高的预测性能，如图4所示。同样，在WildGuardMix数据集上，ROC-AUC值为0.8934，也表明性能优异。这些结果证明我们的模型过滤算法具有统计学意义，有助于区分有害与无害提示。

We visualize the results of the filtering algorithm for harmful prompts in a graph, as shown in Figure 6. As seen in Figure 6, our model effectively classifies not only based on simple prompts but also for harmful prompts that are abstract or require interpretation. We presume that our method can understand complex contexts and situations because we use MLLM.

我们将有害提示的过滤算法结果以图形方式展示，如图6所示。如图6所示，我们的模型不仅能有效分类简单提示，还能处理抽象或需解释的有害提示。我们推测，由于采用了多模态大语言模型(MLLM)，方法能够理解复杂语境和情境。

### 5.3 F1 score vs. Risk Score Threshold and Precision-Recall Curve

### 5.3 F1分数与风险分数阈值及精确率-召回率曲线

Figure 7 illustrates the F1 score versus threshold and the Precision-Recall (PR) curves for the Tox-icChat and WildGuardMix datasets. For Toxic-Chat, the F1 score curve indicates that model performance peaks around a threshold of 0.75 , achieving an F1 score of approximately 0.68 . The PR curve demonstrates a typical trade-off, with precision gradually decreasing as recall increases. Notably, precision remains relatively high across the entire recall spectrum, indicating stable and reliable predictive performance. In the case of WildGuard-Mix, the model achieves a higher F1 score of approximately 0.82 at a threshold near 0.7 , indicating superior performance compared to ToxicChat. The PR curve further supports this, showing that precision remains above 0.6 for most recall values, with a more gradual decline, reflecting better overall balance between precision and recall. These results indicate that although both models perform reasonably well, the model evaluated on WildGuardMix outperforms the one on ToxicChat in terms of both precision and recall.

图7展示了ToxicChat和WildGuardMix数据集的F1分数与阈值关系及精确率-召回率(PR)曲线。对于ToxicChat，F1分数曲线显示模型性能在阈值约0.75时达到峰值，F1分数约为0.68。PR曲线表现出典型的权衡关系，随着召回率增加，精确率逐渐下降，但精确率在整个召回范围内保持较高，表明预测性能稳定可靠。WildGuardMix模型在阈值约0.7时达到更高的F1分数约0.82，性能优于ToxicChat。PR曲线进一步支持这一点，精确率在大多数召回值上保持在0.6以上，下降更为缓慢，反映出精确率与召回率之间更好的整体平衡。这些结果表明，尽管两个模型表现均较好，但WildGuardMix上的模型在精确率和召回率方面均优于ToxicChat。

## 6 Conclusion

## 6 结论

We propose a simple yet effective method using question prompting for detecting harmful prompts in a zero-shot manner. Our approach leverages pre-trained MLLM without fine-tuning and classifies harmful prompts through guard questions, question prompting, and a filtering algorithm. Experimental results show that our model outperforms fine-tuned baselines. The method also enables white-box analysis, providing transparency in classification. By refining guard questions, our approach can flexibly adapt to new harmful prompts with minimal computational overhead, making it a practical solution for real-world LLM safety applications. We believe that our approach presents a practical and effective solution for real-world LLM safety applications.

我们提出了一种简单而有效的基于问题提示的零样本有害提示检测方法。该方法利用预训练多模态大语言模型(MLLM)无需微调，通过防护问题、问题提示和过滤算法对有害提示进行分类。实验结果表明，我们的模型优于微调基线方法。该方法还支持白盒分析，提升分类透明度。通过优化防护问题，我们的方法能够灵活适应新的有害提示，且计算开销极低，因而是实际大语言模型安全应用的实用方案。我们相信该方法为现实世界大语言模型安全应用提供了切实有效的解决方案。

Limitation. Although our method does not require fine-tuning, it relies on a pre-trained MLLM for inference. Additionally, extracting logits from the MLLM may take some extra time, and the use of dataset-specific thresholds can pose challenges to generalization. In the future, we aim to enhance the model's generalization capabilities and optimize the filtering algorithm to improve efficiency.

局限性。尽管我们的方法不需要微调，但推理时依赖于预训练的多模态大语言模型(MLLM)。此外，从MLLM中提取logits可能需要额外时间，且使用特定数据集的阈值会对泛化能力带来挑战。未来，我们计划提升模型的泛化能力并优化过滤算法以提高效率。

## Acknowledgments

## 致谢

This research was supported by Brian Impact Foundation, a non-profit organization dedicated to the advancement of science and technology for all.

本研究得到了Brian Impact Foundation的支持，该非营利组织致力于推动科学技术的普及与发展。

## References

## 参考文献

Josh Achiam, Steven Adler, Sandhini Agarwal, Lama Ahmad, Ilge Akkaya, Florencia Leoni Aleman, Diogo Almeida, Janko Altenschmidt, Sam Altman, Shyamal Anadkat, et al. 2023. Gpt-4 technical report. arXiv preprint arXiv:2303.08774.

Josh Achiam, Steven Adler, Sandhini Agarwal, Lama Ahmad, Ilge Akkaya, Florencia Leoni Aleman, Diogo Almeida, Janko Altenschmidt, Sam Altman, Shyamal Anadkat, 等. 2023. GPT-4技术报告. arXiv预印本 arXiv:2303.08774.

Tommaso Caselli, Valerio Basile, Jelena Mitrović, and Michael Granitzer. 2020. Hatebert: Retraining bert for abusive language detection in english. arXiv preprint arXiv:2010.12472.

Tommaso Caselli, Valerio Basile, Jelena Mitrović, 和 Michael Granitzer. 2020. HateBERT:针对英语辱骂语言检测的BERT再训练. arXiv预印本 arXiv:2010.12472.

Gongwei Chen, Leyang Shen, Rui Shao, Xiang Deng, and Liqiang Nie. 2024a. Lion: Empowering multimodal large language model with dual-level visual knowledge. In Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition, pages 26540-26550.

Gongwei Chen, Leyang Shen, Rui Shao, Xiang Deng, 和 Liqiang Nie. 2024a. LION:通过双层视觉知识赋能多模态大语言模型. 载于IEEE/CVF计算机视觉与模式识别会议论文集，页码26540-26550.

Liangyu Chen, Bo Li, Sheng Shen, Jingkang Yang, Chunyuan Li, Kurt Keutzer, Trevor Darrell, and Zi-wei Liu. 2023. Large language models are visual reasoning coordinators. Advances in Neural Information Processing Systems, 36:70115-70140.

Liangyu Chen, Bo Li, Sheng Shen, Jingkang Yang, Chunyuan Li, Kurt Keutzer, Trevor Darrell, 和 Zi-wei Liu. 2023. 大语言模型作为视觉推理协调者. 神经信息处理系统进展，36:70115-70140.

Zhe Chen, Jiannan Wu, Wenhai Wang, Weijie Su, Guo Chen, Sen Xing, Muyan Zhong, Qinglong Zhang, Xizhou Zhu, Lewei Lu, et al. 2024b. Internvl: Scaling up vision foundation models and aligning for generic visual-linguistic tasks. In Proceedings of the IEEE/CVF conference on computer vision and pattern recognition, pages 24185-24198.

Zhe Chen, Jiannan Wu, Wenhai Wang, Weijie Su, Guo Chen, Sen Xing, Muyan Zhong, Qinglong Zhang, Xizhou Zhu, Lewei Lu, 等. 2024b. InternVL:扩展视觉基础模型并对通用视觉语言任务进行对齐. 载于IEEE/CVF计算机视觉与模式识别会议论文集，页码24185-24198.

Tianle Gu, Zeyang Zhou, Kexin Huang, Liang Dan-dan, Yixu Wang, Haiquan Zhao, Yuanqi Yao, Yujiu Yang, Yan Teng, Yu Qiao, et al. 2025. Mllmguard: A multi-dimensional safety evaluation suite for multimodal large language models. Advances in Neural Information Processing Systems, 37:7256-7295.

Tianle Gu, Zeyang Zhou, Kexin Huang, Liang Dan-dan, Yixu Wang, Haiquan Zhao, Yuanqi Yao, Yujiu Yang, Yan Teng, Yu Qiao, 等. 2025. MLLMGuard:多模态大语言模型的多维安全评估套件. 神经信息处理系统进展，37:7256-7295.

Ojasvi Gupta, Marta de la Cuadra Lozano, Abdelsalam Busalim, Rajesh R Jaiswal, and Keith Quille. 2024. Harmful prompt classification for large language models. In Proceedings of the 2024 Conference on Human Centred Artificial Intelligence - Education and Practice, New York, NY, USA. Association for Computing Machinery.

Ojasvi Gupta, Marta de la Cuadra Lozano, Abdelsalam Busalim, Rajesh R Jaiswal, 和 Keith Quille. 2024. 大语言模型有害提示分类. 载于2024年以人为中心的人工智能教育与实践会议论文集，纽约，美国。计算机协会出版。

Rishav Hada, Sohi Sudhir, Pushkar Mishra, Helen Yannakoudakis, Saif M Mohammad, and Ekaterina Shutova. 2021. Ruddit: Norms of offensiveness for english reddit comments. arXiv preprint arXiv:2106.05664.

Rishav Hada, Sohi Sudhir, Pushkar Mishra, Helen Yannakoudakis, Saif M Mohammad, 和 Ekaterina Shutova. 2021. RUDDIT:英语Reddit评论的冒犯性规范. arXiv预印本 arXiv:2106.05664.

Seungju Han, Kavel Rao, Allyson Ettinger, Liwei Jiang, Bill Yuchen Lin, Nathan Lambert, Yejin Choi, and Nouha Dziri. 2024. Wildguard: Open one-stop moderation tools for safety risks, jailbreaks, and refusals of llms. arXiv preprint arXiv:2406.18495.

Seungju Han, Kavel Rao, Allyson Ettinger, Liwei Jiang, Bill Yuchen Lin, Nathan Lambert, Yejin Choi, 和 Nouha Dziri. 2024. WildGuard:针对安全风险、越狱和拒绝的大语言模型一站式开放审核工具. arXiv预印本 arXiv:2406.18495.

Xinlei He, Savvas Zannettou, Yun Shen, and Yang Zhang. 2023. You only prompt once: On the capabilities of prompt learning on large language models to tackle toxic content. Preprint, arXiv:2308.05596.

Xinlei He, Savvas Zannettou, Yun Shen, 和 Yang Zhang. 2023. 你只需提示一次:大语言模型提示学习应对有害内容的能力. 预印本，arXiv:2308.05596.

Lianmin Huang, Haotian Liu, Xiangning Chen, Tianle Zhang, Ke Lin, Weiting Yu, Yejin Choi, Ailin Zhou, Jindong Wu, and Dacheng Yu. 2024. Harmful fine-tuning attacks and defenses for large language models: A survey. arXiv preprint arXiv:2409.18169.

Lianmin Huang, Haotian Liu, Xiangning Chen, Tianle Zhang, Ke Lin, Weiting Yu, Yejin Choi, Ailin Zhou, Jindong Wu, 和 Dacheng Yu. 2024. 大语言模型有害微调攻击与防御综述. arXiv预印本 arXiv:2409.18169.

Hakan Inan, Kartikeya Upasani, Jianfeng Chi, Rashi Rungta, Krithika Iyer, Yuning Mao, Michael Tontchev, Qing Hu, Brian Fuller, Davide Testug-gine, et al. Llama guard: Llm-based input-output safeguard for human-ai conversations, 2023. URL https://arxiv.org/abs/2312.06674.

Hakan Inan, Kartikeya Upasani, Jianfeng Chi, Rashi Rungta, Krithika Iyer, Yuning Mao, Michael Tontchev, Qing Hu, Brian Fuller, Davide Testuggine, 等. 2023. LLaMA Guard:基于大语言模型的人机对话输入输出安全保障. 网址 https://arxiv.org/abs/2312.06674.

Seanie Lee, Haebin Seong, Dong Bok Lee, Minki Kang, Xiaoyin Chen, Dominik Wagner, Yoshua Ben-gio, Juho Lee, and Sung Ju Hwang. 2024. Har-maug: Effective data augmentation for knowledge distillation of safety guard models. arXiv preprint arXiv:2410.01524.

Seanie Lee, Haebin Seong, Dong Bok Lee, Minki Kang, Xiaoyin Chen, Dominik Wagner, Yoshua Ben-gio, Juho Lee, and Sung Ju Hwang. 2024. Har-maug: 用于安全防护模型知识蒸馏的有效数据增强。arXiv预印本 arXiv:2410.01524。

Taegyeong Lee, Jinsik Bang, Soyeong Kwon, and Tae-hwan Kim. 2025. Multi-aspect knowledge distillation with large language model. In Proceedings of the Computer Vision and Pattern Recognition Conference (CVPR) Workshops, pages 2121-2130.

Taegyeong Lee, Jinsik Bang, Soyeong Kwon, and Tae-hwan Kim. 2025. 基于大型语言模型的多方面知识蒸馏。发表于计算机视觉与模式识别会议(CVPR)研讨会论文集，页码2121-2130。

Zi Lin, Zihan Wang, Yongqi Tong, Yangkun Wang, Yuxin Guo, Yujia Wang, and Jingbo Shang. 2023. Toxicchat: Unveiling hidden challenges of toxicity detection in real-world user-ai conversation. arXiv preprint arXiv:2310.17389.

Zi Lin, Zihan Wang, Yongqi Tong, Yangkun Wang, Yuxin Guo, Yujia Wang, and Jingbo Shang. 2023. Toxicchat:揭示现实用户与AI对话中毒性检测的隐藏挑战。arXiv预印本 arXiv:2310.17389。

Daizong Liu, Mingyu Yang, Xiaoye Qu, Pan Zhou, Yu Cheng, and Wei Hu. 2024a. A survey of attacks on large vision-language models: Resources, advances, and future trends. arXiv preprint arXiv:2407.07403.

Daizong Liu, Mingyu Yang, Xiaoye Qu, Pan Zhou, Yu Cheng, and Wei Hu. 2024a. 大型视觉语言模型攻击综述:资源、进展与未来趋势。arXiv预印本 arXiv:2407.07403。

Xin Liu, Yichen Zhu, Yunshi Lan, Chao Yang, and Yu Qiao. 2023. Query-relevant images jailbreak large multi-modal models. arXiv preprint arXiv:2311.17600, 7:14.

Xin Liu, Yichen Zhu, Yunshi Lan, Chao Yang, and Yu Qiao. 2023. 与查询相关的图像绕过大型多模态模型。arXiv预印本 arXiv:2311.17600, 7:14。

Xin Liu, Yichen Zhu, Yunshi Lan, Chao Yang, and Yu Qiao. 2024b. Safety of multimodal large language models on images and texts. Preprint, arXiv:2402.00357.

Xin Liu, Yichen Zhu, Yunshi Lan, Chao Yang, and Yu Qiao. 2024b. 多模态大型语言模型在图像和文本上的安全性。预印本，arXiv:2402.00357。

Yangzhou Liu, Yue Cao, Zhangwei Gao, Weiyun Wang, Zhe Chen, Wenhai Wang, Hao Tian, Lewei Lu, Xizhou Zhu, Tong Lu, et al. 2024c. Mmin-struct: A high-quality multi-modal instruction tuning dataset with extensive diversity. arXiv preprint arXiv:2407.15838.

Yangzhou Liu, Yue Cao, Zhangwei Gao, Weiyun Wang, Zhe Chen, Wenhai Wang, Hao Tian, Lewei Lu, Xizhou Zhu, Tong Lu, 等. 2024c. Mmin-struct:一个高质量、多样性丰富的多模态指令调优数据集。arXiv预印本 arXiv:2407.15838。

Yi Liu, Junzhe Yu, Huijia Sun, Ling Shi, Gelei Deng, Yuqi Chen, and Yang Liu. 2024d. Efficient detection of toxic prompts in large language models. Preprint, arXiv:2408.11727.

Yi Liu, Junzhe Yu, Huijia Sun, Ling Shi, Gelei Deng, Yuqi Chen, and Yang Liu. 2024d. 大型语言模型中有害提示的高效检测。预印本，arXiv:2408.11727。

Todor Markov, Chong Zhang, Sandhini Agarwal, Florentine Eloundou Nekoul, Theodore Lee, Steven Adler, Angela Jiang, and Lilian Weng. 2023. A holistic approach to undesired content detection in the real world. In Proceedings of the AAAI Conference on Artificial Intelligence, volume 37, pages 15009-15018.

Todor Markov, Chong Zhang, Sandhini Agarwal, Florentine Eloundou Nekoul, Theodore Lee, Steven Adler, Angela Jiang, and Lilian Weng. 2023. 现实世界中不良内容检测的整体方法。发表于AAAI人工智能会议论文集，第37卷，页码15009-15018。

Mantas Mazeika, Long Phan, Xuwang Yin, Andy Zou, Zifan Wang, Norman Mu, Elham Sakhaee, Nathaniel Li, Steven Basart, Bo Li, et al. 2024. Harmbench: A standardized evaluation framework for automated red teaming and robust refusal, 2024. URL https://arxiv.org/abs/2402.04249.

Mantas Mazeika, Long Phan, Xuwang Yin, Andy Zou, Zifan Wang, Norman Mu, Elham Sakhaee, Nathaniel Li, Steven Basart, Bo Li, 等. 2024. Harmbench:自动红队和鲁棒拒绝的标准化评估框架，2024。网址 https://arxiv.org/abs/2402.04249。

Sejoon Oh, Yiqiao Jin, Megha Sharma, Donghyun Kim, Eric Ma, Gaurav Verma, and Srijan Kumar. 2025. Uniguard: Towards universal safety guardrails for jailbreak attacks on multimodal large language models. Preprint, arXiv:2411.01703.

Sejoon Oh, Yiqiao Jin, Megha Sharma, Donghyun Kim, Eric Ma, Gaurav Verma, and Srijan Kumar. 2025. Uniguard:面向多模态大型语言模型越狱攻击的通用安全防护。预印本，arXiv:2411.01703。

Paul Röttger, Hannah Rose Kirk, Bertie Vidgen, Giuseppe Attanasio, Federico Bianchi, and Dirk Hovy. 2023. Xstest: A test suite for identifying exaggerated safety behaviours in large language models. arXiv preprint arXiv:2308.01263.

Paul Röttger, Hannah Rose Kirk, Bertie Vidgen, Giuseppe Attanasio, Federico Bianchi, and Dirk Hovy. 2023. Xstest:用于识别大型语言模型中夸大安全行为的测试套件。arXiv预印本 arXiv:2308.01263。

Paul Röttger, Bertie Vidgen, Dong Nguyen, Zeerak Waseem, Helen Margetts, and Janet Pierrehumbert. 2021. Hatecheck: Functional tests for hate speech detection models. In Proceedings of the 59th Annual Meeting of the Association for Computational Linguistics and the 11th International Joint Conference on Natural Language Processing (Volume 1: Long Papers), pages 41-58. Association for Computational Linguistics.

Paul Röttger, Bertie Vidgen, Dong Nguyen, Zeerak Waseem, Helen Margetts, and Janet Pierrehumbert. 2021. Hatecheck:仇恨言论检测模型的功能测试。发表于第59届计算语言学协会年会暨第11届国际自然语言处理联合会议(第一卷:长篇论文)，页码41-58。计算语言学协会。

Uriel Singer, Adam Polyak, Thomas Hayes, Xi Yin, Jie An, Songyang Zhang, Qiyuan Hu, Harry Yang, Oron Ashual, Oran Gafni, et al. 2022. Make-a-video: Text-to-video generation without text-video data. arXiv preprint arXiv:2209.14792.

Uriel Singer, Adam Polyak, Thomas Hayes, Xi Yin, Jie An, Songyang Zhang, Qiyuan Hu, Harry Yang, Oron Ashual, Oran Gafni, 等. 2022. Make-a-video:无需文本-视频数据的文本生成视频。arXiv预印本 arXiv:2209.14792。

Gemini Team, Rohan Anil, Sebastian Borgeaud, Jean-Baptiste Alayrac, Jiahui Yu, Radu Soricut, Johan Schalkwyk, Andrew M Dai, Anja Hauth, Katie Millican, et al. 2023. Gemini: a family of highly capable multimodal models. arXiv preprint arXiv:2312.11805.

Gemini团队，Rohan Anil，Sebastian Borgeaud，Jean-Baptiste Alayrac，Jiahui Yu，Radu Soricut，Johan Schalkwyk，Andrew M Dai，Anja Hauth，Katie Millican等。2023年。Gemini:一系列高性能多模态模型。arXiv预印本 arXiv:2312.11805。

Bertie Vidgen, Tristan Thrush, Zeerak Waseem, and Douwe Kiela. 2020. Learning from the worst: Dynamically generated datasets to improve online hate detection. arXiv preprint arXiv:2012.15761.

Bertie Vidgen，Tristan Thrush，Zeerak Waseem，和Douwe Kiela。2020年。从最差中学习:动态生成数据集以改进在线仇恨检测。arXiv预印本 arXiv:2012.15761。

Alexander Wei, Nika Haghtalab, and Jacob Steinhardt. 2023. Jailbroken: How does llm safety training fail? Advances in Neural Information Processing Systems, 36:80079-80110.

Alexander Wei，Nika Haghtalab，和Jacob Steinhardt。2023年。Jailbroken:大型语言模型(LLM)安全训练如何失败？《神经信息处理系统进展》(Advances in Neural Information Processing Systems)，36:80079-80110。

Mingrui Wu, Xinyue Cai, Jiayi Ji, Jiale Li, Oucheng Huang, Gen Luo, Hao Fei, Guannan Jiang, Xiaoshuai Sun, and Rongrong Ji. 2024. Controlmllm: Training-free visual prompt learning for multimodal large language models. Advances in Neural Information Processing Systems, 37:45206-45234.

吴明睿，蔡欣悦，季佳怡，李佳乐，黄欧成，罗根，费浩，姜冠南，孙晓帅，季荣荣。2024年。Controlmllm:面向多模态大型语言模型的无训练视觉提示学习。《神经信息处理系统进展》，37:45206-45234。

Yueqi Xie, Minghong Fang, Renjie Pi, and Neil Gong. 2024. Gradsafe: Detecting jailbreak prompts for llms via safety-critical gradient analysis. arXiv preprint arXiv:2402.13494.

谢悦琦，方明宏，皮仁杰，Neil Gong。2024年。Gradsafe:通过安全关键梯度分析检测大型语言模型的越狱提示。arXiv预印本 arXiv:2402.13494。

Yue Xu, Xiuyuan Qi, Zhan Qin, and Wenjie Wang. 2024. Cross-modality information check for detecting jailbreaking in multimodal large language models. Preprint, arXiv:2407.21659.

徐越，齐秀媛，秦展，王文杰。2024年。跨模态信息校验用于检测多模态大型语言模型的越狱行为。预印本，arXiv:2407.21659。

Mang Ye, Xuankun Rong, Wenke Huang, Bo Du, Neng-hai Yu, and Dacheng Tao. 2025. A survey of safety on large vision-language models: Attacks, defenses and evaluations. arXiv preprint arXiv:2502.14881.

叶芒，荣轩坤，黄文科，杜博，余能海，陶大成。2025年。大型视觉语言模型安全性综述:攻击、防御与评估。arXiv预印本 arXiv:2502.14881。

Andy Zou, Zifan Wang, Nicholas Carlini, Milad Nasr, J Zico Kolter, and Matt Fredrikson. 2023. Universal and transferable adversarial attacks on aligned language models. arXiv preprint arXiv:2307.15043.

邹安迪，王子凡，Nicholas Carlini，Milad Nasr，J Zico Kolter，Matt Fredrikson。2023年。对齐语言模型的通用且可迁移对抗攻击。arXiv预印本 arXiv:2307.15043。