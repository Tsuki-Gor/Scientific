# Episode-based Prototype Generating Network for Zero-Shot Learning

# 基于情节的零样本学习原型生成网络

Yunlong Yu ${}^{1 * }$ Zhong Ji ${}^{2 * }$ Jungong ${\mathrm{{Han}}}^{3}$ Zhongfei Zhang ${}^{4}$

于云龙 ${}^{1 * }$ 纪忠 ${}^{2 * }$ 韩军工 ${\mathrm{{Han}}}^{3}$ 张忠飞 ${}^{4}$

${}^{1}$ College of Information Science &Electronic Engineering, Zhejiang University, China ${}^{2}$ Tianjin Key BIIT Lab, School of Electrical &Information Engineering, Tianjin University, China ${}^{3}$ WMG Data Science, University of Warwick, UK ${}^{4}$ Department of Computer Science, Binghamton University, USA

${}^{1}$ 浙江大学信息与电子工程学院，中国 ${}^{2}$ 天津大学电气自动化与信息工程学院天津市生物信息技术重点实验室，中国 ${}^{3}$ 英国华威大学WMG数据科学系 ${}^{4}$ 美国宾厄姆顿大学计算机科学系

yuyunlong@zju.edu.cn, jizhon@tju.edu.cn, jungong.han@warwick.ac.uk, zhongfei@cs.binghamton.edu

yuyunlong@zju.edu.cn, jizhon@tju.edu.cn, jungong.han@warwick.ac.uk, zhongfei@cs.binghamton.edu

## Abstract

## 摘要

We introduce a simple yet effective episode-based training framework for zero-shot learning (ZSL), where the learning system requires to recognize unseen classes given only the corresponding class semantics. During training, the model is trained within a collection of episodes, each of which is designed to simulate a zero-shot classification task. Through training multiple episodes, the model progressively accumulates ensemble experiences on predicting the mimetic unseen classes, which will generalize well on the real unseen classes. Based on this training framework, we propose a novel generative model that synthesizes visual prototypes conditioned on the class semantic prototypes. The proposed model aligns the visual-semantic interactions by formulating both the visual prototype generation and the class semantic inference into an adversarial framework paired with a parameter-economic Multi-modal Cross-Entropy Loss to capture the discriminative information. Extensive experiments on four datasets under both traditional ZSL and generalized ZSL tasks show that our model outperforms the state-of-the-art approaches by large margins.

我们为零样本学习(ZSL)引入了一个简单而有效的基于情节的训练框架，在该框架中，学习系统需要仅根据相应的类别语义来识别未见类别。在训练过程中，模型在一系列情节中进行训练，每个情节都旨在模拟一个零样本分类任务。通过训练多个情节，模型逐步积累预测模拟未见类别的综合经验，这将在真实未见类别上有很好的泛化能力。基于这个训练框架，我们提出了一种新颖的生成模型，该模型基于类别语义原型合成视觉原型。所提出的模型通过将视觉原型生成和类别语义推理都纳入一个对抗框架，并结合参数经济的多模态交叉熵损失来捕捉判别信息，从而对齐视觉 - 语义交互。在传统ZSL和广义ZSL任务下的四个数据集上进行的大量实验表明，我们的模型大幅优于现有最先进的方法。

## 1. Introduction

## 1. 引言

With the renaissance of deep learning, tremendous breakthroughs have been achieved on various visual tasks [12, 5, 21]. However, the deep learning techniques typically rely on the availability of artificially balanced training data, which poses a significant bottleneck against building comprehensive models for the real visual world. In recent years, Zero-Shot Learning (ZSL) [16, 9, 32, 37, 36] has been attracting a lot of attention due to its potential to address the data scarcity issue.

随着深度学习的复兴，在各种视觉任务上取得了巨大突破 [12, 5, 21]。然而，深度学习技术通常依赖于人工平衡的训练数据的可用性，这对为真实视觉世界构建全面的模型构成了重大瓶颈。近年来，零样本学习(ZSL) [16, 9, 32, 37, 36] 因其解决数据稀缺问题的潜力而备受关注。

Zero-Shot Learning (ZSL) aims at recognizing unseen classes that have no visual instances during the training stage. Such harsh but realistic scenarios are painful for the traditional classification approaches because there are no labeled visual data to support the parameter training for unseen classes. To tackle this task, the existing methods mostly resort to the transfer learning that assumes the model trained on the seen classes can be applied to the unseen classes, and focus on learning a transferable model with the seen data.

零样本学习(ZSL)旨在识别在训练阶段没有视觉实例的未见类别。这种苛刻但现实的场景对于传统分类方法来说是棘手的，因为没有标记的视觉数据来支持未见类别的参数训练。为了解决这个任务，现有的方法大多采用迁移学习，即假设在已见类别上训练的模型可以应用于未见类别，并专注于利用已见数据学习一个可迁移的模型。

![0195e035-f6c1-757a-ab08-b11e9284a329_0_922_756_664_342_0.jpg](images/0195e035-f6c1-757a-ab08-b11e9284a329_0_922_756_664_342_0.jpg)

Figure 1. An illustration of the episode-based framework for ZSL. The training process consists of a collection of episodes, each of which randomly splits the training data into two class-exclusive subsets: one is used for training the base model, the other one is used for refining the model. The model generalized ability is progressively enhanced as the episodes go on. The test data are predicted with the final model.

图1. ZSL基于情节的框架示意图。训练过程由一系列情节组成，每个情节将训练数据随机划分为两个类别互斥的子集:一个用于训练基础模型，另一个用于优化模型。随着情节的推进，模型的泛化能力逐渐增强。最终模型用于预测测试数据。

Although promising performances have been achieved, the most existing approaches $\left\lbrack  {1,2,{32},{22},9,{25},{27},{23}}\right\rbrack$ dedicated to designing visual-semantic interaction models with the seen classes cannot guarantee to generalize well to the unseen classes, as the seen and unseen classes are located in disjoint domains. Furthermore, the models trained with the seen data favorably guide the unseen test instances to be misclassified into the seen classes, which tends to produce a remarkable imbalanced classification shift issue. The existing generative approaches $\left\lbrack  {{15},{17},{34}}\right\rbrack$ transfer the zero-shot classification task to a traditional classification problem via synthesizing some visual features for unseen classes, which can alleviate the above issues to some extent. However, they still struggle in the generalized ZSL task due to the instability in training and mode collapse issues.

尽管已经取得了有前景的性能，但大多数现有的 $\left\lbrack  {1,2,{32},{22},9,{25},{27},{23}}\right\rbrack$ 致力于用已见类别设计视觉 - 语义交互模型的方法不能保证在未见类别上有很好的泛化能力，因为已见和未见类别位于不相交的领域。此外，用已见数据训练的模型会使未见测试实例被错误分类到已见类别中，这往往会产生显著的不平衡分类偏移问题。现有的生成方法 $\left\lbrack  {{15},{17},{34}}\right\rbrack$ 通过为未见类别合成一些视觉特征将零样本分类任务转化为传统分类问题，这在一定程度上可以缓解上述问题。然而，由于训练的不稳定性和模式崩溃问题，它们在广义ZSL任务中仍然面临困难。

---

*The corresponding authors are Yunlong Yu and Zhong Ji.

* 通讯作者是于云龙和纪忠。

---

Inspired by the success of meta-learning in the few-shot learning task $\left\lbrack  {{26},{28}}\right\rbrack$ , we introduce an episode-based training paradigm to learn a zero-shot classification model for mitigating the above issues. Specifically, the training process consists of a collection of episodes. Each episode randomly splits the training data into two class-exclusive subsets: one support set and one refining set. In this way, each episode mimics a fake zero-shot classification task. The support set is used to train a base model, which builds semantic interactions between the visual and the class semantic modalities. The refining set is used to refine the base model by minimizing the differences between the ground-truth labels and the predicted ones obtained with the base model in a pre-defined space. The model trained in the current episode is initialized with the model parameters learned from the previous episode. As the episodes go on, the base model progressively accumulates ensemble experiences on predicting fake unseen classes, which will generalize well to the real unseen classes. In this way, the gap between the seen and unseen domains can be reduced accordingly. The framework of the whole idea is illustrated in Fig. 1.

受元学习在少样本学习任务 $\left\lbrack  {{26},{28}}\right\rbrack$ 中取得成功的启发，我们引入了一种基于情节的训练范式来学习零样本分类模型，以缓解上述问题。具体而言，训练过程由一系列情节组成。每个情节将训练数据随机划分为两个类别互斥的子集:一个支持集和一个精炼集。通过这种方式，每个情节都模拟了一个虚假的零样本分类任务。支持集用于训练一个基础模型，该模型在视觉模态和类别语义模态之间建立语义交互。精炼集用于通过最小化真实标签与在预定义空间中使用基础模型获得的预测标签之间的差异来精炼基础模型。当前情节中训练的模型使用从上一个情节中学到的模型参数进行初始化。随着情节的推进，基础模型逐渐积累预测虚假未见类别的集成经验，这些经验将很好地推广到真实的未见类别。通过这种方式，可见领域和未见领域之间的差距可以相应地减小。整个思路的框架如图1所示。

Under the above episode-based training framework, the base model plays an indispensable role in the process of the prediction of unseen classes. In this work, we design an elegant Prototype Generating Network (PGN) as the base model to synthesize class-level visual prototypes conditioned on the class semantic prototypes. As a departure from the existing generative approaches that involve the minimax play games between a generator and a discriminator, our model consists of two generators that map the visual features and the class semantic prototypes into their counterparts and a discriminator that distinguishes between the concatenation of the real visual features and the real class semantic prototypes and the concatenation of the fake counterparts. To capture the discriminative information, we further devise a novel Multi-modal Cross-Entropy Loss to integrate the visual features, class semantic prototypes, and class labels into a classification network. Compared with the existing generative approaches that require an extra assisting classification network with a separate set of learning parameters, our classification network introduces no extra parameters, thus is more efficient.

在上述基于情节的训练框架下，基础模型在预测未见类别过程中起着不可或缺的作用。在这项工作中，我们设计了一个精巧的原型生成网络(Prototype Generating Network，PGN)作为基础模型，以类别语义原型为条件合成类别级别的视觉原型。与现有的涉及生成器和判别器之间进行极小极大博弈的生成式方法不同，我们的模型由两个生成器和一个判别器组成，其中两个生成器将视觉特征和类别语义原型映射到它们的对应物，判别器用于区分真实视觉特征和真实类别语义原型的拼接以及虚假对应物的拼接。为了捕捉判别信息，我们进一步设计了一种新颖的多模态交叉熵损失函数，将视觉特征、类别语义原型和类别标签整合到一个分类网络中。与现有的需要额外辅助分类网络和一组单独学习参数的生成式方法相比，我们的分类网络不引入额外参数，因此效率更高。

In summary, our contributions are concluded into the following three-fold.

综上所述，我们的贡献总结为以下三个方面。

1. To enhance the adaptability of the model, we introduce an episode-based training paradigm for ZSL that trains the models within a collection of episodes, each of which is designed to simulate a fake ZSL task. Through training multiple episodes, the model progressively accumulates a wealth of experiences on predicting the fake unseen classes, which will generalize well to the real unseen classes.

1. 为了增强模型的适应性，我们为零样本学习(Zero-Shot Learning，ZSL)引入了一种基于情节的训练范式，该范式在一系列情节中训练模型，每个情节都旨在模拟一个虚假的零样本学习任务。通过训练多个情节，模型逐渐积累了大量预测虚假未见类别的经验，这些经验将很好地推广到真实的未见类别。

2. We propose a well-designed prototype generating network to synthesize visual prototypes conditioned on the class semantic prototypes. It aligns the visual-semantic interactions by formulating both the visual prototype generation and the class semantic inference into an adversarial framework and captures the discriminative information with an efficient Multi-modal Cross-Entropy Loss.

2. 我们提出了一个精心设计的原型生成网络，以类别语义原型为条件合成视觉原型。该网络通过将视觉原型生成和类别语义推理都纳入一个对抗框架来对齐视觉 - 语义交互，并使用高效的多模态交叉熵损失函数捕捉判别信息。

3. Extensive experiments on four benchmarks show that the proposed approach achieves the state-of-the-art performances under both the traditional ZSL and the realistic generalized ZSL tasks.

3. 在四个基准数据集上的大量实验表明，所提出的方法在传统零样本学习和现实广义零样本学习任务下均达到了最先进的性能。

## 2. Related Work

## 2. 相关工作

In this section, we provide an overview of the most related work on ZSL and episode-based approaches.

在本节中，我们概述了与零样本学习和基于情节的方法最相关的工作。

### 2.1. Generative ZSL

### 2.1. 生成式零样本学习

Recently, the generative approaches predominate in ZSL by exploiting either the existing generative models $\left\lbrack  {{10},{14}}\right\rbrack$ or their variations $\left\lbrack  {{24},{40},4}\right\rbrack$ to synthesize visual features from the class-level semantic features (e.g., attributes and text description embeddings) along with some noises. $\left\lbrack  {{34},{39},{17}}\right\rbrack$ introduce the Wasserstein generative adversarial network (WGAN) [3] paired with a classification network to synthesize visual features for unseen classes such that the ZSL task is transferred to a traditional classification problem. Differently, [39] also introduces a visual pivot regularization to preserve the inter-class discrimination of the generated features while [17] enhances the inter-class discrimination by enforcing the generated visual features to be close to at least one class meta-representations. In contrast to GAN-based approaches, $\left\lbrack  {{31},{24}}\right\rbrack$ formulate the feature generation into the variational autoencoder (VAE) [14] model to fit the class-specific latent distribution and highly discriminative feature representations. To combine the strength of VAE and GAN, [35] develops a conditional generative model to synthesize visual features, which is also extended to exploit the unlabeled instances under the transductive setting via an unconditional discriminator.

最近，生成式方法在零样本学习中占据主导地位，它们通过利用现有的生成模型 $\left\lbrack  {{10},{14}}\right\rbrack$ 或其变体 $\left\lbrack  {{24},{40},4}\right\rbrack$，结合一些噪声从类别级语义特征(例如属性和文本描述嵌入)中合成视觉特征。$\left\lbrack  {{34},{39},{17}}\right\rbrack$ 引入了瓦瑟斯坦生成对抗网络(Wasserstein Generative Adversarial Network，WGAN)[3] 并与一个分类网络配对，为未见类别合成视觉特征，从而将零样本学习任务转化为一个传统的分类问题。不同的是，[39] 还引入了视觉枢轴正则化来保留生成特征的类间判别性，而 [17] 通过强制生成的视觉特征接近至少一个类别元表示来增强类间判别性。与基于生成对抗网络(Generative Adversarial Network，GAN)的方法不同，$\left\lbrack  {{31},{24}}\right\rbrack$ 将特征生成纳入变分自编码器(Variational Autoencoder，VAE)[14] 模型中，以拟合特定类别的潜在分布和高度判别性的特征表示。为了结合变分自编码器和生成对抗网络的优势，[35] 开发了一个条件生成模型来合成视觉特征，该模型还通过一个无条件判别器扩展到在直推式设置下利用未标记实例。

Our model is also a generative approach. Instead of synthesizing instance-level visual features, we synthesize class-level visual prototypes conditioned on the class semantic prototypes without extra noise input. Among previous generative approaches, several are closely related to our model. For example, DEM [38] trains a visual prototype generating network with a three-layer neural network by minimizing the differences between the synthesized visual prototypes and real visual features. In contrast, our approach formulates both the visual prototype generation and class semantic inference into a united framework. Different from $\left\lbrack  {6,{13}}\right\rbrack$ that formulate the visual feature generation and class semantic inference in a cycle-consistent manner, our model formulates these two processes with two separable bidirectional mapping networks that are integrated by the discriminator and the classification network, which aligns the visual-semantic interactions better. Furthermore, our approach is trained in an episode-based framework to enhance the adaptability to the unseen classes.

我们的模型也是一种生成式方法。我们不是合成实例级的视觉特征，而是在不输入额外噪声的情况下，基于类别语义原型合成类别级的视觉原型。在以往的生成式方法中，有几种与我们的模型密切相关。例如，DEM [38] 通过最小化合成的视觉原型与真实视觉特征之间的差异，使用三层神经网络训练一个视觉原型生成网络。相比之下，我们的方法将视觉原型生成和类别语义推理统一到一个框架中。与 $\left\lbrack  {6,{13}}\right\rbrack$ 以循环一致的方式构建视觉特征生成和类别语义推理不同，我们的模型使用两个可分离的双向映射网络来构建这两个过程，这两个网络通过判别器和分类网络进行整合，从而更好地协调视觉 - 语义交互。此外，我们的方法在基于情节的框架中进行训练，以增强对未见类别的适应性。

![0195e035-f6c1-757a-ab08-b11e9284a329_2_271_199_1206_538_0.jpg](images/0195e035-f6c1-757a-ab08-b11e9284a329_2_271_199_1206_538_0.jpg)

Figure 2. Diagram of the proposed approach for one episode training step that consists of a training stage (top) and a refining stage (below). The training stage trains the base model by aligning the visual-semantic interaction (V.S. Interaction). The refining stage first initializes the label prediction of the test data with the trained model in a pre-defined space and then fine-tunes the model by minimizing the differences between the predicted results and the ground-truth labels.

图 2. 所提出的单情节训练步骤方法的示意图，该步骤包括训练阶段(上)和细化阶段(下)。训练阶段通过协调视觉 - 语义交互(V.S. 交互)来训练基础模型。细化阶段首先在预定义空间中使用训练好的模型初始化测试数据的标签预测，然后通过最小化预测结果与真实标签之间的差异来微调模型。

### 2.2. Episode-based approach

### 2.2. 基于情节的方法

Episode-based training strategy has been widely explored in the few-shot learning task $\left\lbrack  {8,{19},{26},{29}}\right\rbrack$ that divides the training process into extensive episodes, each of which mimics a few-shot learning task. However, few researches apply the episode-based training strategy to ZSL.

基于情节的训练策略已在少样本学习任务 $\left\lbrack  {8,{19},{26},{29}}\right\rbrack$ 中得到广泛探索，该策略将训练过程划分为大量情节，每个情节模拟一个少样本学习任务。然而，很少有研究将基于情节的训练策略应用于零样本学习(ZSL)。

In this work, we introduce the episode-based paradigm to train the ZSL model. Different from the existing episode-based few-shot approaches, each episode in our approach mimics a zero-shot classification task, which requires to train a base visual-semantic interaction model to achieve the prediction of unseen classes. One related work to ours is RELATION NET [28] that also trains a ZSL model in an episode-based paradigm. However, RELATION NET [28] learns a general metric space to evaluate the relations between the visual instances and the class semantic features rather than simulating a zero-shot classification task. Another related work is $3\mathrm{{ME}}$ [7] that improves the performance with an ensemble of two different models. Our approach can also be seen as a special ensemble approach that consists of a collection of models. Differently, the models are not equal to vote for the final classification instead of accumulating the previous experiences recursively.

在这项工作中，我们引入基于情节的范式来训练零样本学习模型。与现有的基于情节的少样本方法不同，我们方法中的每个情节都模拟一个零样本分类任务，这需要训练一个基础的视觉 - 语义交互模型来实现对未见类别的预测。与我们相关的一项工作是 RELATION NET [28]，它也在基于情节的范式中训练零样本学习模型。然而，RELATION NET [28] 学习一个通用的度量空间来评估视觉实例与类别语义特征之间的关系，而不是模拟一个零样本分类任务。另一项相关工作是 $3\mathrm{{ME}}$ [7]，它通过集成两个不同的模型来提高性能。我们的方法也可以看作是一种特殊的集成方法，它由一组模型组成。不同的是，这些模型不是通过平等投票来进行最终分类，而是递归地积累先前的经验。

## 3. Methodology

## 3. 方法

In this section, we first introduce the problem formulation and then report our approach in detail.

在本节中，我们首先介绍问题的表述，然后详细介绍我们的方法。

### 3.1. Problem Formulation

### 3.1. 问题表述

Suppose that we collect a training sample set $\mathcal{S} =$ ${\left\{  {\mathbf{x}}_{i},{\mathbf{a}}_{i},{\mathbf{y}}_{i}\right\}  }_{i = 1}^{N}$ that consists of $N$ samples from $M$ seen categories, where ${\mathbf{x}}_{i} \in  {\mathbb{R}}^{D}$ is the $D$ -dimensional visual representation (e.g., CNN feature) for the $i$ -th instance, ${\mathbf{a}}_{i} \in  {\mathbb{R}}^{K}$ and ${\mathbf{y}}_{i}$ are its $K$ -dimensional class semantic prototype (e.g., class-level attribute or text description vector) and one-hot class label, respectively. At the test time, in the traditional zero-shot classification setting, the task is to classify a test instance into one of the candidate unseen categories, and in the generalized zero-shot classification setting, the task is to classify the test instance into either a seen or an unseen category.

假设我们收集了一个训练样本集 $\mathcal{S} =$ ${\left\{  {\mathbf{x}}_{i},{\mathbf{a}}_{i},{\mathbf{y}}_{i}\right\}  }_{i = 1}^{N}$，它由来自 $M$ 个已见类别的 $N$ 个样本组成，其中 ${\mathbf{x}}_{i} \in  {\mathbb{R}}^{D}$ 是第 $i$ 个实例的 $D$ 维视觉表示(例如，卷积神经网络特征)，${\mathbf{a}}_{i} \in  {\mathbb{R}}^{K}$ 和 ${\mathbf{y}}_{i}$ 分别是其 $K$ 维类别语义原型(例如，类别级属性或文本描述向量)和独热类别标签。在测试时，在传统的零样本分类设置中，任务是将一个测试实例分类到候选未见类别之一；在广义零样本分类设置中，任务是将测试实例分类到已见或未见类别中。

### 3.2. Model

### 3.2. 模型

At the training stage, we introduce an episode-based paradigm for training, which trains the model by simulating multiple zero-shot classification tasks on the seen categories. Each episode matches an individual zero-shot classification task. In each episode, the seen categories $\mathcal{S}$ are randomly split into two class-exclusive sets, one support set ${\mathcal{S}}^{tr} = \left\{  {{\mathbf{X}}_{tr},{\mathbf{A}}_{tr},{\mathbf{Y}}_{tr}}\right\}$ and one refining set ${\mathcal{S}}^{te} = \left\{  {{\mathbf{X}}_{te},{\mathbf{A}}_{te},{\mathbf{Y}}_{te}}\right\}$ , where ${\mathbf{Y}}_{tr}$ and ${\mathbf{Y}}_{te}$ are disjoint.

在训练阶段，我们引入了一种基于情节(episode)的训练范式，该范式通过在已见类别上模拟多个零样本分类任务来训练模型。每个情节对应一个单独的零样本分类任务。在每个情节中，已见类别 $\mathcal{S}$ 被随机划分为两个互斥的类别集合，一个支持集 ${\mathcal{S}}^{tr} = \left\{  {{\mathbf{X}}_{tr},{\mathbf{A}}_{tr},{\mathbf{Y}}_{tr}}\right\}$ 和一个精炼集 ${\mathcal{S}}^{te} = \left\{  {{\mathbf{X}}_{te},{\mathbf{A}}_{te},{\mathbf{Y}}_{te}}\right\}$，其中 ${\mathbf{Y}}_{tr}$ 和 ${\mathbf{Y}}_{te}$ 是不相交的。

![0195e035-f6c1-757a-ab08-b11e9284a329_3_137_202_723_303_0.jpg](images/0195e035-f6c1-757a-ab08-b11e9284a329_3_137_202_723_303_0.jpg)

Figure 3. The basic model that aligns the semantic consistency across different modalities. The combination of both image feature $\mathrm{x}$ and class semantic prototype a takes as the real input, while the combination of both the synthesized visual prototype $\widetilde{\mathbf{x}}$ and the projected class semantic feature $\widetilde{\mathbf{a}}$ as the fake input of the discriminator $D$ . Both $F$ and $G$ are mapping networks.

图3. 用于对齐不同模态间语义一致性的基本模型。图像特征 $\mathrm{x}$ 和类别语义原型 a 的组合作为真实输入，而合成视觉原型 $\widetilde{\mathbf{x}}$ 和投影后的类别语义特征 $\widetilde{\mathbf{a}}$ 的组合作为判别器 $D$ 的虚假输入。$F$ 和 $G$ 均为映射网络。

As illustrated in Fig. 2, each episode consists of a training stage and a refining stage. The training stage learns a base model to align the semantic consistency, which is used to predict the unseen classes from the corresponding class semantic prototypes. The refining stage updates the model parameters by minimizing the predicted results and the ground-truth labels. Training each episode can be seen as a process of accumulating experience on zero-shot classification. The experience will be carried forward to the next episode as the episode goes on. After training a collection of episodes, the model is expected to be an expert in predicting unseen classes such that it can generalize well to the real unseen classes. In the following, we introduce the base model and the refining model in an episode in detail.

如图2所示，每个情节由训练阶段和精炼阶段组成。训练阶段学习一个基础模型来对齐语义一致性，该模型用于从相应的类别语义原型中预测未见类别。精炼阶段通过最小化预测结果与真实标签之间的差异来更新模型参数。训练每个情节可以看作是一个积累零样本分类经验的过程。随着情节的推进，这些经验将被传递到下一个情节。在训练完一系列情节后，期望该模型成为预测未见类别的专家，从而能够很好地泛化到实际的未见类别。接下来，我们将详细介绍一个情节中的基础模型和精炼模型。

#### 3.2.1 Prototype Generating Network

#### 3.2.1 原型生成网络(Prototype Generating Network)

To address the zero-shot classification task, the learning agent requires learning a base model to infer unseen categories from the corresponding class semantic prototypes. In this paper, we devise a Prototype Generating Network (PGN) to achieve this goal.

为了解决零样本分类任务，学习代理需要学习一个基础模型，以便从相应的类别语义原型中推断未见类别。在本文中，我们设计了一个原型生成网络(Prototype Generating Network，PGN)来实现这一目标。

For the visual modality, we learn a class semantic inference network $F : {\mathbb{R}}^{D} \rightarrow  {\mathbb{R}}^{K}$ to project the image features into the class semantic space by regressing the image features to be close to the corresponding class semantic prototypes, which is formulated as:

对于视觉模态，我们学习一个类别语义推理网络 $F : {\mathbb{R}}^{D} \rightarrow  {\mathbb{R}}^{K}$，通过将图像特征回归到接近相应的类别语义原型，将图像特征投影到类别语义空间，其公式如下:

$$
{L}_{\mathcal{V} \rightarrow  \mathcal{A}} = \mathop{\sum }\limits_{i}{\begin{Vmatrix}F\left( {\mathbf{x}}_{i}\right)  - {\mathbf{a}}_{i}\end{Vmatrix}}_{2}^{2}. \tag{1}
$$

Similarly, for the class semantic modality, we learn a visual prototype generating network $G : {\mathbb{R}}^{K} \rightarrow  {\mathbb{R}}^{D}$ to project the class semantic prototypes into the visual space. Since each class usually consists of many image instances but corresponds to only one class semantic prototype, the mapping function $G$ can be seen as a one-to-many semantic-to-visual feature generator. The mapping function $G$ is learned by minimizing the distances between the synthesized visual feature $G\left( {\mathbf{a}}_{i}\right)$ (we call it visual prototype) and the real visual feature ${\mathbf{x}}_{i}$ .

类似地，对于类别语义模态，我们学习一个视觉原型生成网络 $G : {\mathbb{R}}^{K} \rightarrow  {\mathbb{R}}^{D}$，将类别语义原型投影到视觉空间。由于每个类别通常由许多图像实例组成，但仅对应一个类别语义原型，因此映射函数 $G$ 可以看作是一个一对多的语义到视觉特征生成器。映射函数 $G$ 通过最小化合成视觉特征 $G\left( {\mathbf{a}}_{i}\right)$(我们称之为视觉原型)与真实视觉特征 ${\mathbf{x}}_{i}$ 之间的距离来学习。

$$
{L}_{\mathcal{A} \rightarrow  \mathcal{V}} = \mathop{\sum }\limits_{i}{\begin{Vmatrix}G\left( {\mathbf{a}}_{i}\right)  - {\mathbf{x}}_{i}\end{Vmatrix}}_{2}^{2}. \tag{2}
$$

With $F$ and $G$ , we can construct the relationships between the visual space and the class semantic space. However, they are independent to each other. To better align the semantic consistency, we introduce the adversarial mechanism to regularize both mapping networks, as illustrated in Fig. 3. Specifically, we leverage a modified WGAN [11] to integrate the projected class semantic vector $\widetilde{\mathbf{a}}$ and the real class semantic prototype a separately to generator and discriminator. The loss is written:

利用 $F$ 和 $G$，我们可以构建视觉空间和类别语义空间之间的关系。然而，它们彼此独立。为了更好地对齐语义一致性，如图3所示，我们引入对抗机制来规范这两个映射网络。具体来说，我们利用改进的WGAN [11] 分别将投影后的类别语义向量 $\widetilde{\mathbf{a}}$ 和真实的类别语义原型 a 集成到生成器和判别器中。损失函数如下:

$$
{L}_{WGAN} = \mathbb{E}\left\lbrack  {D\left( {\mathbf{x},\mathbf{a}}\right) }\right\rbrack   - \mathbb{E}\left\lbrack  {D\left( {\widetilde{\mathbf{x}},\widetilde{\mathbf{a}}}\right) }\right\rbrack   -  \tag{3}
$$

$$
\lambda \mathbb{E}\left\lbrack  {\left( {\begin{Vmatrix}{\nabla }_{\widehat{\mathbf{x}}}D\left( \widehat{\mathbf{x}},\widehat{\mathbf{a}}\right) \end{Vmatrix}}_{2} - 1\right) }^{2}\right\rbrack  ,
$$

where $\widetilde{\mathbf{a}} = F\left( \mathbf{x}\right)$ is the inferential class semantic feature; $\widetilde{\mathbf{x}} = G\left( \mathbf{a}\right)$ is the synthetic visual prototype. $\widehat{\mathbf{x}} =$ $\tau \mathbf{x} + \left( {1 - \tau }\right) \widetilde{\mathbf{x}}$ and $\widehat{\mathbf{a}} = \tau \mathbf{a} + \left( {1 - \tau }\right) \widetilde{\mathbf{a}}$ with $\tau  \sim  U\left( {0,1}\right)$ , $\lambda$ is the penalty coefficient. $D$ denotes the discriminator network. In contrast to the existing GAN-based approaches, the proposed model can be seen as containing two generators and one discriminator, where the generators separately perform on the two different modalities while the discriminator integrates them.

其中 $\widetilde{\mathbf{a}} = F\left( \mathbf{x}\right)$ 是推理类语义特征；$\widetilde{\mathbf{x}} = G\left( \mathbf{a}\right)$ 是合成视觉原型。$\widehat{\mathbf{x}} =$ $\tau \mathbf{x} + \left( {1 - \tau }\right) \widetilde{\mathbf{x}}$ 和 $\widehat{\mathbf{a}} = \tau \mathbf{a} + \left( {1 - \tau }\right) \widetilde{\mathbf{a}}$ 与 $\tau  \sim  U\left( {0,1}\right)$ ，$\lambda$ 是惩罚系数。$D$ 表示判别器网络。与现有的基于生成对抗网络(GAN)的方法相比，所提出的模型可以看作包含两个生成器和一个判别器，其中生成器分别在两种不同的模态上执行操作，而判别器将它们进行整合。

The above model aligns the semantic consistency between the visual features and class semantics. However, training such a model neglects to exploit the discriminative information to distinguish categories, which is essential to the final class prediction. To address this issue, we further propose a multi-modal cross-entropy loss that interweaves the image features, class semantics, and the one-hot class labels into a united framework. With the above model, the class semantic prototypes of all training categories are projected into the visual space to obtain their corresponding class visual prototypes that are pre-stored in a visual feature buffer $G\left( {\mathbf{A}}_{S}\right)$ , where $G\left( {\mathbf{a}}_{i}\right)$ denotes the class visual prototype of the $i$ -th category. The affinities between a visual sample $\mathrm{x}$ and all class visual prototypes could be obtained with their inner products ${\mathbf{x}}^{T}G\left( {\mathbf{A}}_{S}\right)$ . In this way, the probability of the input visual sample $\mathbf{x}$ belonging to the $i$ -th category in the visual space can be evaluated with the affinity of visual sample $\mathbf{x}$ matching the $i$ -th class semantic vector with the following cross-modal softmax function:

上述模型使视觉特征和类语义之间的语义一致性对齐。然而，训练这样的模型忽略了利用判别信息来区分类别，而这对于最终的类别预测至关重要。为了解决这个问题，我们进一步提出了一种多模态交叉熵损失，它将图像特征、类语义和独热类别标签交织到一个统一的框架中。利用上述模型，所有训练类别的类语义原型被投影到视觉空间中，以获得它们对应的类视觉原型，这些原型预先存储在一个视觉特征缓冲区 $G\left( {\mathbf{A}}_{S}\right)$ 中，其中 $G\left( {\mathbf{a}}_{i}\right)$ 表示第 $i$ 类的类视觉原型。一个视觉样本 $\mathrm{x}$ 与所有类视觉原型之间的相似度可以通过它们的内积 ${\mathbf{x}}^{T}G\left( {\mathbf{A}}_{S}\right)$ 获得。通过这种方式，输入视觉样本 $\mathbf{x}$ 在视觉空间中属于第 $i$ 类的概率可以通过视觉样本 $\mathbf{x}$ 与第 $i$ 类语义向量的相似度，使用以下跨模态 softmax 函数进行评估:

$$
{p}_{i}^{\mathcal{V}}\left( \mathbf{x}\right)  = \frac{\exp \left( {{\mathbf{x}}^{T}G\left( {\mathbf{a}}_{i}\right) }\right) }{\mathop{\sum }\limits_{j}\exp \left( {{\mathbf{x}}^{T}G\left( {\mathbf{a}}_{j}\right) }\right) }. \tag{4}
$$

Similarly, in the class semantic space, all class semantic vectors are pre-stored in a class semantic buffer ${\mathbf{A}}_{S}$ and a visual sample $\mathbf{x}$ is represented as $F\left( \mathbf{x}\right)$ . Therefore, the probability of $\mathbf{x}$ belonging to the $i$ -th category in the class semantic space can be defined as

类似地，在类语义空间中，所有类语义向量预先存储在一个类语义缓冲区 ${\mathbf{A}}_{S}$ 中，一个视觉样本 $\mathbf{x}$ 表示为 $F\left( \mathbf{x}\right)$ 。因此，$\mathbf{x}$ 在类语义空间中属于第 $i$ 类的概率可以定义为

$$
{p}_{i}^{\mathcal{S}}\left( \mathbf{x}\right)  = \frac{\exp \left( {F{\left( \mathbf{x}\right) }^{T}{\mathbf{a}}_{i}}\right) }{\mathop{\sum }\limits_{j}\exp \left( {F{\left( \mathbf{x}\right) }^{T}{\mathbf{a}}_{j}}\right) }. \tag{5}
$$

Our goal is to maximize the above probabilities in both the visual and class semantic spaces, which can be formulated by minimizing the following Multi-modal Cross-Entropy (MCE) Loss,

我们的目标是在视觉和类语义空间中最大化上述概率，这可以通过最小化以下多模态交叉熵(MCE)损失来实现。

$$
{L}_{MCE} =  - \mathop{\sum }\limits_{\mathbf{x}}\log {p}_{i}^{\mathcal{V}}\left( \mathbf{x}\right)  - \mathop{\sum }\limits_{\mathbf{x}}\log {p}_{i}^{\mathcal{S}}\left( \mathbf{x}\right) . \tag{6}
$$

By minimizing Eq. (6), the intra-class instances are forced to have higher affinities with their corresponding class semantic prototype than those with the other class semantic prototypes. In this way, the discriminative information can be effectively preserved in both the visual space and class semantic spaces. Compared with the existing generative approaches $\left\lbrack  {{17},{34}}\right\rbrack$ that train a softmax classification model with both the real seen visual features and the synthesized unseen visual features, our classification model introduces no extra parameters, which is more efficient and feasible.

通过最小化公式(6)，迫使类内实例与其对应的类语义原型的相似度高于与其他类语义原型的相似度。通过这种方式，判别信息可以在视觉空间和类语义空间中得到有效保留。与现有的生成方法 $\left\lbrack  {{17},{34}}\right\rbrack$ 相比，这些方法使用真实可见的视觉特征和合成的不可见视觉特征来训练一个 softmax 分类模型，我们的分类模型不引入额外的参数，这更高效且可行。

Overall, our full objective then becomes,

总体而言，我们的完整目标变为

$$
\mathop{\min }\limits_{G}\mathop{\max }\limits_{D}{L}_{WGAN} + \alpha {L}_{\mathcal{V} \rightarrow  \mathcal{A}} + \beta {L}_{\mathcal{A} \rightarrow  \mathcal{V}} + \gamma {L}_{MCE}, \tag{7}
$$

where $\alpha ,\beta$ , and $\gamma$ are hype-parameters to balance each terms.

其中 $\alpha ,\beta$ 和 $\gamma$ 是用于平衡各项的超参数。

#### 3.2.2 Refining Model

#### 3.2.2 细化模型

With the trained $G$ , the test instance could be classified by searching the nearest generated class visual prototype in the visual space with a pre-defined distance metric. For an unseen instance ${\mathbf{x}}_{t}$ , its class label is predicted by,

利用训练好的 $G$ ，可以通过使用预定义的距离度量在视觉空间中搜索最近的生成类视觉原型来对测试实例进行分类。对于一个未见实例 ${\mathbf{x}}_{t}$ ，其类别标签通过以下方式预测:

$$
{\widehat{y}}_{t} = \arg \mathop{\min }\limits_{k}\left( {d\left( {{\mathbf{x}}_{t}, G\left( {\mathbf{a}}_{k}\right) }\right) }\right) , \tag{8}
$$

where ${\mathbf{a}}_{k}$ is the class semantic prototype of the $k$ -th unseen class, $G\left( {\mathbf{a}}_{k}\right)$ is the corresponding generated class visual prototype. $d\left( {\cdot , \cdot  }\right)$ denotes a certain distance metric, such as Euclidean or Consine distance.

其中 ${\mathbf{a}}_{k}$ 是第 $k$ 个未见类别的类语义原型，$G\left( {\mathbf{a}}_{k}\right)$ 是对应的生成类视觉原型。$d\left( {\cdot , \cdot  }\right)$ 表示某种距离度量，如欧几里得距离或余弦距离。

The base model focuses on building the visual-semantic interactions on the seen classes, which cannot ensure that it generalizes well to the unseen classes in the pre-defined metric space. To enhance the model adaptability to the unseen classes, we refine the part parameters of the base model that are used for predicting unseen classes on the test set ${\mathcal{S}}^{te}$ in the pre-defined metric space. Specifically, given a distance function $d$ , the base model produces a distribution over classes for a test instance ${\mathbf{x}}_{t}$ based on a softmax over distance to the class semantic prototypes in the visual space,

基础模型专注于在已见类别(seen classes)上构建视觉 - 语义交互，这无法确保它在预定义的度量空间中能很好地泛化到未见类别(unseen classes)。为了增强模型对未见类别的适应性，我们在预定义的度量空间中，对基础模型中用于预测测试集 ${\mathcal{S}}^{te}$ 未见类别的部分参数进行细化。具体而言，给定一个距离函数 $d$，基础模型基于视觉空间中到类别语义原型的距离的 softmax 函数，为测试实例 ${\mathbf{x}}_{t}$ 生成一个类别分布。

$$
{p}_{G}\left( {y = k \mid  {\mathbf{x}}_{t}}\right)  = \frac{\exp \left( {-d\left( {{\mathbf{x}}_{t}, G\left( {\mathbf{a}}_{k}\right) }\right) }\right) }{\mathop{\sum }\limits_{{k}^{\prime }}\exp \left( {-d\left( {{\mathbf{x}}_{t}, G\left( {\mathbf{a}}_{{k}^{\prime }}\right) }\right) }\right) }, \tag{9}
$$

where $d\left( {\cdot , \cdot  }\right)$ is the distance metric as the same as that in Eq. (8). By minimizing the negative log-probability $J\left( G\right)  =  - \log {p}_{G}\left( {y = k \mid  {\mathbf{x}}_{t}}\right)$ of the true class $k$ , the mapping function $G$ is improved for generalizing to the unseen classes in the defined metric space. We observe empirically that the choice of distance metric is vital, as the classification performances with Euclidean distance mostly outperform those with Cosine distance. In the experiments, we report the results with the Euclidean distance, if not specified.

其中 $d\left( {\cdot , \cdot  }\right)$ 是与式 (8) 中相同的距离度量。通过最小化真实类别 $k$ 的负对数概率 $J\left( G\right)  =  - \log {p}_{G}\left( {y = k \mid  {\mathbf{x}}_{t}}\right)$，改进映射函数 $G$，使其在定义的度量空间中能够泛化到未见类别。我们通过实验观察到，距离度量的选择至关重要，因为使用欧几里得距离(Euclidean distance)的分类性能大多优于使用余弦距离(Cosine distance)的性能。在实验中，若未特别说明，我们报告的是使用欧几里得距离的结果。

The model PGN trained with episode-based framework is short for E-PGN. The training process of E-PGN is summarized in Algorithm 1

使用基于情节的框架训练的模型 PGN 简称为 E - PGN。E - PGN 的训练过程总结在算法 1 中。

Algorithm 1: Proposed E-PGN approach.

算法 1:提出的 E - PGN 方法。

---

Input: The seen category set $\mathcal{S}$ , the hyper-parameters

输入:已见类别集合 $\mathcal{S}$，超参数

		$\alpha ,\beta$ , and $\gamma$ .

		$\alpha ,\beta$ 和 $\gamma$。

Output: Visual prototype generating network $G$ .

输出:视觉原型生成网络 $G$。

Initialize the parameters of both $F$ and $G$ .

初始化 $F$ 和 $G$ 的参数。

## while not done do

## 当未完成时执行

	Randomly sample ${\mathcal{S}}^{tr}$ and ${\mathcal{S}}^{te}$ from $\mathcal{S}$ ;

	从 $\mathcal{S}$ 中随机采样 ${\mathcal{S}}^{tr}$ 和 ${\mathcal{S}}^{te}$；

	for samples in ${\mathcal{S}}^{tr}$ do

	对于 ${\mathcal{S}}^{tr}$ 中的样本

		Optimize $F$ and $G$ by Eq. (7);

		通过式 (7) 优化 $F$ 和 $G$；

	for samples in ${\mathcal{S}}^{te}$ do

	对于 ${\mathcal{S}}^{te}$ 中的样本

		Calculate probability distribution by Eq. (9);

		通过式 (9) 计算概率分布；

		Update $G$ by minimizing the negative

		通过最小化负

		log-probability.

		对数概率更新 <b0></b0>。

return The parameters of $G$ .

返回 $G$ 的参数。

---

## 4. Experiments

## 4. 实验

In this section, we conduct experiments to evaluate the effectiveness of the proposed model. We first document the datasets and experimental settings and then compare E-PGN with the state-of-the-art. Finally, we study the properties of the proposed E-PGN with a serious of ablation experiments.

在本节中，我们进行实验以评估所提出模型的有效性。我们首先记录数据集和实验设置，然后将E - PGN与最先进的方法进行比较。最后，我们通过一系列消融实验研究所提出的E - PGN的特性。

### 4.1. Datasets and Experimental settings

### 4.1. 数据集和实验设置

Datasets. Among the most widely used datasets for zero-shot classification, we select two coarse-grained datasets, namely Animals with Attributes (AwA1) [16], Animals with Attributes2 (AwA2) [33], and two fine-grained datasets, i.e., Caltech-UCSD Birds-200-2011 (CUB) [30] and Oxford Flowers (FLO) [18]. AwA1 and AwA2 consist of different visual images from the same 50 animal classes, each class is annotated with 85-dimensional semantic attributes. CUB and FLO respectively contain 200 bird species and 102 flower categories. As for the class semantic representations of both CUB and FLO datasets, we average the 1,024-dimensional character-based CNN-RNN [20] features extracted from the fine-grained visual descriptions (10 sentences per image). We adopt the standard zero-shot splits provided by [33] for AwA1, AwA2, and CUB datasets. For FLO dataset, we use the splits provided by [18]. A dataset summary is given in Table 1.

数据集。在最广泛使用的零样本分类数据集中，我们选择了两个粗粒度数据集，即动物属性数据集(Animals with Attributes，AwA1)[16]、动物属性2数据集(Animals with Attributes2，AwA2)[33]，以及两个细粒度数据集，即加州理工学院 - 加州大学圣地亚哥分校鸟类200 - 2011数据集(Caltech - UCSD Birds - 200 - 2011，CUB)[30]和牛津花卉数据集(Oxford Flowers，FLO)[18]。AwA1和AwA2包含来自相同50个动物类别的不同视觉图像，每个类别都标注了85维的语义属性。CUB和FLO分别包含200种鸟类和102种花卉类别。对于CUB和FLO数据集的类别语义表示，我们对从细粒度视觉描述(每张图像10个句子)中提取的1024维基于字符的CNN - RNN [20]特征进行平均。我们采用[33]为AwA1、AwA2和CUB数据集提供的标准零样本划分。对于FLO数据集，我们使用[18]提供的划分。数据集总结见表1。

<table><tr><td rowspan="2">Method</td><td colspan="4">AwA1</td><td colspan="4">AwA2</td><td colspan="4">CUB</td><td colspan="4">FLO</td></tr><tr><td>T</td><td>$\mathbf{u}$</td><td>S</td><td>H</td><td>T</td><td>$\mathbf{u}$</td><td>$\mathbf{S}$</td><td>H</td><td>T</td><td>$\mathbf{u}$</td><td>$\mathbf{S}$</td><td>H</td><td>T</td><td>$\mathbf{u}$</td><td>S</td><td>$\mathbf{H}$</td></tr><tr><td>ALE [1]</td><td>59.9</td><td>16.8</td><td>76.1</td><td>27.5</td><td>62.5</td><td>14.0</td><td>81.8</td><td>23.9</td><td>54.9</td><td>23.7</td><td>62.8</td><td>34.4</td><td>48.5</td><td>13.3</td><td>61.6</td><td>21.9</td></tr><tr><td>SJE [2]</td><td>65.6</td><td>11.3</td><td>74.6</td><td>19.6</td><td>61.9</td><td>8.0</td><td>73.9</td><td>14.4</td><td>53.9</td><td>23.5</td><td>59.2</td><td>33.6</td><td>53.4</td><td>13.9</td><td>47.6</td><td>21.5</td></tr><tr><td>ESZSL [22]</td><td>58.2</td><td>2.4</td><td>70.1</td><td>4.6</td><td>58.6</td><td>5.9</td><td>77.8</td><td>11.0</td><td>53.9</td><td>12.6</td><td>63.8</td><td>21.0</td><td>51.0</td><td>11.4</td><td>56.8</td><td>19.0</td></tr><tr><td>DEM [38]</td><td>68.4</td><td>32.8</td><td>84.7</td><td>47.3</td><td>67.1</td><td>30.5</td><td>86.4</td><td>45.1</td><td>51.7</td><td>19.6</td><td>57.9</td><td>29.2</td><td>77.8*</td><td>57.2*</td><td>67.7*</td><td>62.0*</td></tr><tr><td>GAZSL [39]</td><td>68.2</td><td>29.6</td><td>84.2</td><td>43.8</td><td>70.2</td><td>35.4</td><td>86.9</td><td>50.3</td><td>55.8</td><td>31.7</td><td>61.3</td><td>41.8</td><td>60.5</td><td>28.1</td><td>77.4</td><td>41.2</td></tr><tr><td>CLSWGAN [34]</td><td>68.2</td><td>57.9</td><td>61.4</td><td>59.6</td><td>65.3</td><td>56.1</td><td>65.5</td><td>60.4</td><td>57.3</td><td>43.7</td><td>57.7</td><td>49.7</td><td>67.2</td><td>59.0</td><td>73.9</td><td>65.6</td></tr><tr><td>Cycle-UWGAN [6]</td><td>66.8</td><td>56.9</td><td>64.0</td><td>60.2</td><td>-</td><td>-</td><td>-</td><td>-</td><td>58.6</td><td>45.7</td><td>61.0</td><td>52.3</td><td>70.3</td><td>59.2</td><td>72.5</td><td>65.1</td></tr><tr><td>SE-ZSL [15]</td><td>69.5</td><td>56.3</td><td>67.8</td><td>61.5</td><td>69.2</td><td>58.3</td><td>68.1</td><td>62.8</td><td>59.6</td><td>41.5</td><td>53.3</td><td>46.7</td><td>-</td><td>-</td><td>-</td><td>-</td></tr><tr><td>LisGAN [17]</td><td>70.6</td><td>52.6</td><td>76.3</td><td>62.3</td><td>70.4*</td><td>47.0*</td><td>77.6*</td><td>58.5*</td><td>58.8</td><td>46.5</td><td>57.9</td><td>51.6</td><td>69.6</td><td>57.7</td><td>83.8</td><td>68.3</td></tr><tr><td>f-VAEGAN-D2 [35]</td><td>71.1</td><td>57.6</td><td>70.6</td><td>63.5</td><td>-</td><td>-</td><td>-</td><td>-</td><td>61.0</td><td>48.4</td><td>60.1</td><td>53.6</td><td>67.7</td><td>56.8</td><td>74.9</td><td>64.6</td></tr><tr><td>CADA-VAE [24]</td><td>62.3</td><td>57.3</td><td>72.8</td><td>64.1</td><td>64.0</td><td>55.8</td><td>75.0</td><td>63.9</td><td>60.4</td><td>51.6</td><td>53.5</td><td>52.4</td><td>-</td><td>-</td><td>-</td><td>-</td></tr><tr><td>ABP [40]</td><td>69.3</td><td>57.3</td><td>67.1</td><td>61.8</td><td>70.4</td><td>55.3</td><td>72.6</td><td>62.6</td><td>58.5</td><td>47.0</td><td>54.8</td><td>50.6</td><td>-</td><td>-</td><td>-</td><td>-</td></tr><tr><td>RELATION NET [28]</td><td>68.2</td><td>31.4</td><td>91.3</td><td>46.7</td><td>64.2</td><td>30.0</td><td>93.4</td><td>45.3</td><td>55.6</td><td>38.1</td><td>61.1</td><td>47.0</td><td>78.5*</td><td>50.8*</td><td>88.5*</td><td>64.5*</td></tr><tr><td>3ME [7]</td><td>65.6</td><td>55.5</td><td>65.7</td><td>60.2</td><td>-</td><td>-</td><td>-</td><td>-</td><td>71.1</td><td>49.6</td><td>60.1</td><td>54.3</td><td>83.9</td><td>57.8</td><td>79.2</td><td>66.8</td></tr><tr><td>E-PGN (Ours)</td><td>74.4</td><td>62.1</td><td>83.4</td><td>71.2</td><td>73.4</td><td>52.6</td><td>83.5</td><td>64.6</td><td>72.4</td><td>52.0</td><td>61.1</td><td>56.2</td><td>85.7</td><td>71.5</td><td>82.2</td><td>76.5</td></tr></table>

<table><tbody><tr><td rowspan="2">方法</td><td colspan="4">AwA1(动物属性数据集1)</td><td colspan="4">AwA2(动物属性数据集2)</td><td colspan="4">CUB(加州理工学院-加州大学圣地亚哥分校鸟类数据集)</td><td colspan="4">FLO(花卉数据集)</td></tr><tr><td>T</td><td>$\mathbf{u}$</td><td>S</td><td>H</td><td>T</td><td>$\mathbf{u}$</td><td>$\mathbf{S}$</td><td>H</td><td>T</td><td>$\mathbf{u}$</td><td>$\mathbf{S}$</td><td>H</td><td>T</td><td>$\mathbf{u}$</td><td>S</td><td>$\mathbf{H}$</td></tr><tr><td>ALE [1](自适应标签嵌入 [1])</td><td>59.9</td><td>16.8</td><td>76.1</td><td>27.5</td><td>62.5</td><td>14.0</td><td>81.8</td><td>23.9</td><td>54.9</td><td>23.7</td><td>62.8</td><td>34.4</td><td>48.5</td><td>13.3</td><td>61.6</td><td>21.9</td></tr><tr><td>SJE [2](语义联合嵌入 [2])</td><td>65.6</td><td>11.3</td><td>74.6</td><td>19.6</td><td>61.9</td><td>8.0</td><td>73.9</td><td>14.4</td><td>53.9</td><td>23.5</td><td>59.2</td><td>33.6</td><td>53.4</td><td>13.9</td><td>47.6</td><td>21.5</td></tr><tr><td>ESZSL [22](增强型零样本学习 [22])</td><td>58.2</td><td>2.4</td><td>70.1</td><td>4.6</td><td>58.6</td><td>5.9</td><td>77.8</td><td>11.0</td><td>53.9</td><td>12.6</td><td>63.8</td><td>21.0</td><td>51.0</td><td>11.4</td><td>56.8</td><td>19.0</td></tr><tr><td>DEM [38](判别式嵌入模型 [38])</td><td>68.4</td><td>32.8</td><td>84.7</td><td>47.3</td><td>67.1</td><td>30.5</td><td>86.4</td><td>45.1</td><td>51.7</td><td>19.6</td><td>57.9</td><td>29.2</td><td>77.8*</td><td>57.2*</td><td>67.7*</td><td>62.0*</td></tr><tr><td>GAZSL [39](广义零样本学习 [39])</td><td>68.2</td><td>29.6</td><td>84.2</td><td>43.8</td><td>70.2</td><td>35.4</td><td>86.9</td><td>50.3</td><td>55.8</td><td>31.7</td><td>61.3</td><td>41.8</td><td>60.5</td><td>28.1</td><td>77.4</td><td>41.2</td></tr><tr><td>CLSWGAN [34](基于条件标签的半监督生成对抗网络 [34])</td><td>68.2</td><td>57.9</td><td>61.4</td><td>59.6</td><td>65.3</td><td>56.1</td><td>65.5</td><td>60.4</td><td>57.3</td><td>43.7</td><td>57.7</td><td>49.7</td><td>67.2</td><td>59.0</td><td>73.9</td><td>65.6</td></tr><tr><td>Cycle - UWGAN [6](循环无监督生成对抗网络 [6])</td><td>66.8</td><td>56.9</td><td>64.0</td><td>60.2</td><td>-</td><td>-</td><td>-</td><td>-</td><td>58.6</td><td>45.7</td><td>61.0</td><td>52.3</td><td>70.3</td><td>59.2</td><td>72.5</td><td>65.1</td></tr><tr><td>SE - ZSL [15](语义嵌入零样本学习 [15])</td><td>69.5</td><td>56.3</td><td>67.8</td><td>61.5</td><td>69.2</td><td>58.3</td><td>68.1</td><td>62.8</td><td>59.6</td><td>41.5</td><td>53.3</td><td>46.7</td><td>-</td><td>-</td><td>-</td><td>-</td></tr><tr><td>LisGAN [17](Lis生成对抗网络 [17])</td><td>70.6</td><td>52.6</td><td>76.3</td><td>62.3</td><td>70.4*</td><td>47.0*</td><td>77.6*</td><td>58.5*</td><td>58.8</td><td>46.5</td><td>57.9</td><td>51.6</td><td>69.6</td><td>57.7</td><td>83.8</td><td>68.3</td></tr><tr><td>f - VAEGAN - D2 [35](特征变分自编码器生成对抗网络 - D2 [35])</td><td>71.1</td><td>57.6</td><td>70.6</td><td>63.5</td><td>-</td><td>-</td><td>-</td><td>-</td><td>61.0</td><td>48.4</td><td>60.1</td><td>53.6</td><td>67.7</td><td>56.8</td><td>74.9</td><td>64.6</td></tr><tr><td>CADA - VAE [24](对比自适应变分自编码器 [24])</td><td>62.3</td><td>57.3</td><td>72.8</td><td>64.1</td><td>64.0</td><td>55.8</td><td>75.0</td><td>63.9</td><td>60.4</td><td>51.6</td><td>53.5</td><td>52.4</td><td>-</td><td>-</td><td>-</td><td>-</td></tr><tr><td>ABP [40](注意力平衡投影 [40])</td><td>69.3</td><td>57.3</td><td>67.1</td><td>61.8</td><td>70.4</td><td>55.3</td><td>72.6</td><td>62.6</td><td>58.5</td><td>47.0</td><td>54.8</td><td>50.6</td><td>-</td><td>-</td><td>-</td><td>-</td></tr><tr><td>RELATION NET [28](关系网络 [28])</td><td>68.2</td><td>31.4</td><td>91.3</td><td>46.7</td><td>64.2</td><td>30.0</td><td>93.4</td><td>45.3</td><td>55.6</td><td>38.1</td><td>61.1</td><td>47.0</td><td>78.5*</td><td>50.8*</td><td>88.5*</td><td>64.5*</td></tr><tr><td>3ME [7](三重匹配嵌入 [7])</td><td>65.6</td><td>55.5</td><td>65.7</td><td>60.2</td><td>-</td><td>-</td><td>-</td><td>-</td><td>71.1</td><td>49.6</td><td>60.1</td><td>54.3</td><td>83.9</td><td>57.8</td><td>79.2</td><td>66.8</td></tr><tr><td>E - PGN(我们的方法)</td><td>74.4</td><td>62.1</td><td>83.4</td><td>71.2</td><td>73.4</td><td>52.6</td><td>83.5</td><td>64.6</td><td>72.4</td><td>52.0</td><td>61.1</td><td>56.2</td><td>85.7</td><td>71.5</td><td>82.2</td><td>76.5</td></tr></tbody></table>

Table 2. Performance (in %) comparisons for both traditional and generalized ZSL in terms of average per-class top-1 accuracy (T), unseen accuracy(u), seen accuracy(s), and their harmonic mean(H). * indicates the results obtained by ourselves with the codes released by the authors. The best results are marked in boldface.

表2. 传统和广义零样本学习(ZSL)在每类平均top-1准确率(T)、未见类别准确率(u)、已见类别准确率(s)及其调和均值(H)方面的性能(%)比较。* 表示我们使用作者发布的代码得到的结果。最佳结果以粗体标记。

<table><tr><td>Dataset</td><td>$\mathcal{K}$</td><td>${\mathcal{V}}_{s}$</td><td>${\mathcal{V}}_{u}$</td><td>${\mathcal{X}}_{a}$</td><td>${\mathcal{X}}_{s}$</td><td>${\mathcal{X}}_{u}$</td></tr><tr><td>AwA1 [16]</td><td>85</td><td>40</td><td>10</td><td>30,475</td><td>5,685</td><td>4,958</td></tr><tr><td>AwA2 [33]</td><td>85</td><td>40</td><td>10</td><td>37,322</td><td>5,882</td><td>7,913</td></tr><tr><td>CUB [30]</td><td>1,024</td><td>150</td><td>50</td><td>11,788</td><td>2,967</td><td>1,764</td></tr><tr><td>FLO [18]</td><td>1,024</td><td>82</td><td>20</td><td>8,189</td><td>5,394</td><td>1,155</td></tr></table>

<table><tbody><tr><td>数据集</td><td>$\mathcal{K}$</td><td>${\mathcal{V}}_{s}$</td><td>${\mathcal{V}}_{u}$</td><td>${\mathcal{X}}_{a}$</td><td>${\mathcal{X}}_{s}$</td><td>${\mathcal{X}}_{u}$</td></tr><tr><td>动物属性数据集1(AwA1) [16]</td><td>85</td><td>40</td><td>10</td><td>30,475</td><td>5,685</td><td>4,958</td></tr><tr><td>动物属性数据集2(AwA2) [33]</td><td>85</td><td>40</td><td>10</td><td>37,322</td><td>5,882</td><td>7,913</td></tr><tr><td>加州大学伯克利分校鸟类数据集(CUB) [30]</td><td>1,024</td><td>150</td><td>50</td><td>11,788</td><td>2,967</td><td>1,764</td></tr><tr><td>花卉数据集(FLO) [18]</td><td>1,024</td><td>82</td><td>20</td><td>8,189</td><td>5,394</td><td>1,155</td></tr></tbody></table>

Table 1. The statistics of four benchmark datasets, in terms of class semantic dimensionality $\mathcal{K}$ , number of seen classes ${\mathcal{Y}}_{s}$ , number of unseen classes ${\mathcal{Y}}_{u}$ , number of all instances ${\mathcal{X}}_{a}$ , number of test seen instances ${\mathcal{X}}_{s}$ and unseen instances ${\mathcal{X}}_{u}$ .

表1. 四个基准数据集的统计信息，包括类别语义维度 $\mathcal{K}$、已见类别数量 ${\mathcal{Y}}_{s}$、未见类别数量 ${\mathcal{Y}}_{u}$、所有实例数量 ${\mathcal{X}}_{a}$、测试已见实例数量 ${\mathcal{X}}_{s}$ 和未见实例数量 ${\mathcal{X}}_{u}$。

Evaluation Protocol. In this work, we evaluate our approach on both traditional ZSL and generalized ZSL tasks. For the traditional ZSL task, we apply the extensively used average per-class top-1 accuracy(T)as the evaluation protocol. For the generalized ZSL task, we follow the protocol proposed in [33] to evaluate the approaches with both seen class accuracy $\mathbf{s}$ and unseen class accuracy $\mathbf{u}$ , as well as their harmonic mean $\mathbf{H}$ .

评估协议。在这项工作中，我们在传统零样本学习(ZSL)和广义零样本学习(ZSL)任务上评估我们的方法。对于传统ZSL任务，我们采用广泛使用的每类平均top - 1准确率(T)作为评估协议。对于广义ZSL任务，我们遵循文献[33]中提出的协议，用已见类别准确率 $\mathbf{s}$ 和未见类别准确率 $\mathbf{u}$ 以及它们的调和均值 $\mathbf{H}$ 来评估这些方法。

Implementation settings. Following $\left\lbrack  {{33},{34}}\right\rbrack$ , we use the top pooling units of the ResNet-101 [12] pre-trained on ImageNet-1K as the image features. Thus, each input image is represented as a 2,048-dimensional vector. As a pre-processing step, we normalize the visual features into $\left\lbrack  {0,1}\right\rbrack$ . In terms of the model architecture, we implement $F$ , $G$ , and $D$ as simple three-layer neural networks with 1,800, 1,800, and 1,600 hidden units. Both $F$ and $D$ apply ReLU as the activation function on both the hidden layer and the output layer, both of which follow a dropout layer. While developing the model, we have observed that by applying the tanh activation function for the hidden layer of $G$ would obtain more stable and better results. In terms of the learning rate of the base model, we set $5{e}^{-5}$ for AwA1, CUB, and FLO datasets, and $2{e}^{-4}$ for AwA2 dataset. For all datasets, we set the learning rate of the refining model as $1/{10}$ of the original base model. In each episode, the base model is trained for 100 epochs by stochastic gradient decent using the Adam optimizer and a batch size of 128 for AwA1 dataset and 32 for the other datasets. The refining model in each episode is trained for 10 epochs using the same optimizer and batch size as the base model. Our model is implemented using TensorFlow framework. The code is available at ${}^{1}$ .

实现设置。遵循 $\left\lbrack  {{33},{34}}\right\rbrack$，我们使用在ImageNet - 1K上预训练的ResNet - 101 [12]的顶层池化单元作为图像特征。因此，每个输入图像表示为一个2048维的向量。作为预处理步骤，我们将视觉特征归一化到 $\left\lbrack  {0,1}\right\rbrack$。在模型架构方面，我们将 $F$、$G$ 和 $D$ 实现为具有1800、1800和1600个隐藏单元的简单三层神经网络。$F$ 和 $D$ 都在隐藏层和输出层应用ReLU作为激活函数，这两层之后都跟着一个丢弃层。在开发模型时，我们观察到，为 $G$ 的隐藏层应用tanh激活函数会获得更稳定和更好的结果。关于基础模型的学习率，我们为AwA1、CUB和FLO数据集设置 $5{e}^{-5}$，为AwA2数据集设置 $2{e}^{-4}$。对于所有数据集，我们将精炼模型的学习率设置为原始基础模型的 $1/{10}$。在每个阶段，基础模型通过随机梯度下降使用Adam优化器训练100个周期，AwA1数据集的批量大小为128，其他数据集的批量大小为32。每个阶段的精炼模型使用与基础模型相同的优化器和批量大小训练10个周期。我们的模型使用TensorFlow框架实现。代码可在 ${}^{1}$ 获取。

### 4.2. Comparing State-of-The-Art Approaches

### 4.2. 与最先进的方法进行比较

Table 2 describes the classification performances of E-PGN and fourteen competitors including three discriminative approaches $\left\lbrack  {1,2,{22}}\right\rbrack$ , nine generative approaches $\lbrack {38},{39}$ , ${34},6,{15},{17},{35},{24},{40}\rbrack$ , one episode-based approach [28], and one ensemble approach [7].

表2描述了E - PGN和十四个竞争对手的分类性能，其中包括三种判别式方法 $\left\lbrack  {1,2,{22}}\right\rbrack$、九种生成式方法 $\lbrack {38},{39}$、${34},6,{15},{17},{35},{24},{40}\rbrack$、一种基于阶段的方法[28]和一种集成方法[7]。

From Table 2, we observe that the proposed E-PGN achieves significant improvements over the state-of-the-art in terms of both $\mathbf{T}$ and $\mathbf{H}$ on four datasets. Specifically in $\mathbf{T}$ metric, the overall accuracy improvement on AwA1 increases from 71.1% to 74.4%, on AwA2 from 70.4% to 73.4%, on CUB from 71.1% to 72.4%, and on FLO from 83.9% to 85.7%, i.e., all quite significant. Remarkably, E-PGN achieves 71.2% and 76.5% for $\mathbf{H}$ metric on AwA1 and FLO datasets, which marginally improves the second-best performance by ${7.1}\%$ and ${8.2}\%$ . On AwA2 and CUB datasets, the proposed E-PGN also gains improvements from 63.9% to ${64.6}\%$ and from ${54.3}\%$ to ${56.2}\%$ , respectively. Compared with the other episode-based approach RELATION NET [28], our E-PGN achieves significant improvements on four datasets, which indicates that our mimetic strategy captures more discriminative transfer knowledge than learning the distance metric strategy. Compared with the other ensemble approach 3ME [7], our E-PGN also has obvious improvements under different metrics across different datasets.

从表2中我们可以观察到，所提出的E - PGN(增强型原型生成网络，Enhanced Prototype Generation Network)在四个数据集上的$\mathbf{T}$和$\mathbf{H}$指标方面均比现有最先进的方法有显著提升。具体而言，在$\mathbf{T}$指标上，AwA1数据集的整体准确率从71.1%提升到74.4%，AwA2数据集从70.4%提升到73.4%，CUB数据集从71.1%提升到72.4%，FLO数据集从83.9%提升到85.7%，这些提升都相当显著。值得注意的是，E - PGN在AwA1和FLO数据集的$\mathbf{H}$指标上分别达到了71.2%和76.5%，相较于次优性能分别提升了${7.1}\%$和${8.2}\%$。在AwA2和CUB数据集上，所提出的E - PGN也分别从63.9%提升到${64.6}\%$，从${54.3}\%$提升到${56.2}\%$。与其他基于情节的方法RELATION NET [28]相比，我们的E - PGN在四个数据集上都取得了显著提升，这表明我们的模拟策略比学习距离度量策略能捕获更多有区分性的迁移知识。与其他集成方法3ME [7]相比，我们的E - PGN在不同数据集的不同指标下也有明显提升。

---

https://github.com/yunlongyu/EPGN

---

<table><tr><td rowspan="2">Method</td><td colspan="4">AwA1</td><td colspan="4">AwA2</td><td colspan="4">CUB</td><td colspan="4">FLO</td></tr><tr><td>T</td><td>$\mathbf{u}$</td><td>$\mathbf{S}$</td><td>H</td><td>T</td><td>$\mathbf{u}$</td><td>$\mathbf{S}$</td><td>H</td><td>T</td><td>$\mathbf{u}$</td><td>$\mathbf{S}$</td><td>H</td><td>T</td><td>$\mathbf{u}$</td><td>$\mathbf{S}$</td><td>H</td></tr><tr><td>PGN</td><td>72.2</td><td>52.6</td><td>86.3</td><td>65.3</td><td>71.2</td><td>48.0</td><td>83.6</td><td>61.0</td><td>68.3</td><td>48.5</td><td>57.2</td><td>52.5</td><td>81.4</td><td>63.6</td><td>77.8</td><td>70.0</td></tr><tr><td>E-PGN (5)</td><td>72.2</td><td>57.2</td><td>83.8</td><td>68.0</td><td>73.5</td><td>51.2</td><td>83.0</td><td>63.3</td><td>70.4</td><td>50.5</td><td>59.0</td><td>54.4</td><td>84.2</td><td>67.7</td><td>79.6</td><td>73.2</td></tr><tr><td>E-PGN (10)</td><td>74.4</td><td>62.1</td><td>83.4</td><td>71.2</td><td>73.4</td><td>52.6</td><td>83.5</td><td>64.6</td><td>72.4</td><td>52.0</td><td>61.1</td><td>56.2</td><td>85.7</td><td>71.5</td><td>82.2</td><td>76.5</td></tr><tr><td>E-PGN (15)</td><td>73.8</td><td>62.2</td><td>82.9</td><td>71.1</td><td>74.2</td><td>50.5</td><td>84.1</td><td>63.1</td><td>69.6</td><td>51.5</td><td>57.4</td><td>54.3</td><td>85.3</td><td>70.5</td><td>80.4</td><td>75.2</td></tr></table>

<table><tbody><tr><td rowspan="2">方法</td><td colspan="4">动物属性数据集1(AwA1)</td><td colspan="4">动物属性数据集2(AwA2)</td><td colspan="4">加州理工学院鸟类数据集(CUB)</td><td colspan="4">花卉数据集(FLO)</td></tr><tr><td>T</td><td>$\mathbf{u}$</td><td>$\mathbf{S}$</td><td>H</td><td>T</td><td>$\mathbf{u}$</td><td>$\mathbf{S}$</td><td>H</td><td>T</td><td>$\mathbf{u}$</td><td>$\mathbf{S}$</td><td>H</td><td>T</td><td>$\mathbf{u}$</td><td>$\mathbf{S}$</td><td>H</td></tr><tr><td>原型生成网络(PGN)</td><td>72.2</td><td>52.6</td><td>86.3</td><td>65.3</td><td>71.2</td><td>48.0</td><td>83.6</td><td>61.0</td><td>68.3</td><td>48.5</td><td>57.2</td><td>52.5</td><td>81.4</td><td>63.6</td><td>77.8</td><td>70.0</td></tr><tr><td>增强原型生成网络(E - PGN)(5)</td><td>72.2</td><td>57.2</td><td>83.8</td><td>68.0</td><td>73.5</td><td>51.2</td><td>83.0</td><td>63.3</td><td>70.4</td><td>50.5</td><td>59.0</td><td>54.4</td><td>84.2</td><td>67.7</td><td>79.6</td><td>73.2</td></tr><tr><td>增强原型生成网络(E - PGN)(10)</td><td>74.4</td><td>62.1</td><td>83.4</td><td>71.2</td><td>73.4</td><td>52.6</td><td>83.5</td><td>64.6</td><td>72.4</td><td>52.0</td><td>61.1</td><td>56.2</td><td>85.7</td><td>71.5</td><td>82.2</td><td>76.5</td></tr><tr><td>增强原型生成网络(E - PGN)(15)</td><td>73.8</td><td>62.2</td><td>82.9</td><td>71.1</td><td>74.2</td><td>50.5</td><td>84.1</td><td>63.1</td><td>69.6</td><td>51.5</td><td>57.4</td><td>54.3</td><td>85.3</td><td>70.5</td><td>80.4</td><td>75.2</td></tr></tbody></table>

Table 3. Performance (in %) comparisons of the number of the selected mimetic unseen classes in each episode. PGN indicates the model trained without episode-based paradigm.

表3. 每一轮中所选模拟未见类数量的性能(%)比较。PGN表示未采用基于轮次范式训练的模型。

We also observe that the seen classification accuracy $\mathbf{s}$ is much better than unseen classification accuracy $\mathbf{u}$ , which indicates that the unseen test instances tend to be misclassified into the seen classes. This classification shifting issue is ubiquitous across all the existing approaches. From the results, we observe that the generative approaches alleviate this shift issue to some extent, resulting in the improvement of $\mathbf{H}$ measure. However, those approaches balance the differences between the seen class accuracy and the unseen class accuracy via decreasing the seen class accuracy while improving the unseen class accuracy, which is not desirable in practice. In contrast, our E-PGN is more robust than the competitors, which substantially boosts the harmonic mean $\mathbf{H}$ via improving the unseen class accuracy while maintaining the seen class accuracy at a high level. Our performance improvement is benefited from the progressive episode-training strategy paired with the effective base model.

我们还观察到，已见分类准确率 $\mathbf{s}$ 远高于未见分类准确率 $\mathbf{u}$，这表明未见测试实例往往会被错误分类到已见类中。这种分类偏移问题在所有现有方法中普遍存在。从结果来看，我们发现生成式方法在一定程度上缓解了这种偏移问题，从而提高了 $\mathbf{H}$ 指标。然而，这些方法通过降低已见类准确率来平衡已见类准确率和未见类准确率之间的差异，同时提高未见类准确率，这在实际应用中并不理想。相比之下，我们的E - PGN比竞争对手更稳健，它通过提高未见类准确率，同时将已见类准确率维持在较高水平，大幅提升了调和均值 $\mathbf{H}$。我们的性能提升得益于渐进式轮次训练策略与有效的基础模型相结合。

### 4.3. Further Analysis

### 4.3. 进一步分析

#### 4.3.1 Impact of episode-based paradigm

#### 4.3.1 基于轮次范式的影响

In the first experiment, we evaluate the impact of the episode-training scheme and how the number of selected mimetic unseen classes in each episode affects the performances on different datasets. To do so, we vary the number of selected mimetic unseen classes from 0 to 15 in intervals of 5 . It should be noted that the case where the number of selected mimetic unseen classes equaling 0 indicates the approach trained without the episode-based paradigm and the optimization process degenerates to the traditional batch-based training strategy.

在第一个实验中，我们评估了轮次训练方案的影响，以及每一轮中所选模拟未见类的数量如何影响不同数据集的性能。为此，我们将所选模拟未见类的数量以5为间隔从0变化到15。需要注意的是，所选模拟未见类数量等于0的情况表示未采用基于轮次范式训练的方法，优化过程退化为传统的基于批次的训练策略。

According to the results in Table 3, we observe that E-PGN mostly performs better than PGN on four datasets under different metrics except $\mathbf{s}$ on AwA1 dataset, which indicates the effectiveness of the proposed episode-based training strategy. Compared with PGN, the E-PGN may spoil the whole training structure to some extent, but can progressively accumulate the knowledge on how to adapt to novel classes with the episode-based training paradigm, and thus better results are obtained. Besides, we also observe that the number of the selected mimetic unseen classes greatly impacts the classification performances. Specifically, E-PGN (10) basically beats E-PGN (5) on four datasets. However, with the further increase of the number, the performances tend to decrease, we speculate that the reason is that when more mimetic unseen classes are selected for refining, fewer training classes are left for training the base model, leading to unsatisfied initialization for the prediction of the mimetic unseen classes.

根据表3中的结果，我们观察到，除了在AwA1数据集上的 $\mathbf{s}$ 指标外，E - PGN在四个数据集上的不同指标下大多比PGN表现更好，这表明所提出的基于轮次的训练策略是有效的。与PGN相比，E - PGN可能在一定程度上破坏了整个训练结构，但可以通过基于轮次的训练范式逐步积累如何适应新类别的知识，从而获得更好的结果。此外，我们还观察到，所选模拟未见类的数量对分类性能有很大影响。具体来说，E - PGN (10) 在四个数据集上基本优于E - PGN (5)。然而，随着数量的进一步增加，性能往往会下降，我们推测原因是，当选择更多的模拟未见类进行细化时，留给基础模型训练的训练类就会减少，导致对模拟未见类的预测初始化不理想。

![0195e035-f6c1-757a-ab08-b11e9284a329_6_906_567_700_559_0.jpg](images/0195e035-f6c1-757a-ab08-b11e9284a329_6_906_567_700_559_0.jpg)

Figure 4. Traditional and generalized zero-shot classification results with traditional cross-entropy loss (short for CE) and multi-modal cross-entropy loss (short for MCE) on four datasets.

图4. 四个数据集上使用传统交叉熵损失(简称CE)和多模态交叉熵损失(简称MCE)的传统和广义零样本分类结果。

#### 4.3.2 Performance impacts of E-PGN components

#### 4.3.2 E - PGN组件的性能影响

In this study, we quantify the benefits of the different components in E-PGN on the performances. In the proposed E-PGN model, except for the base adversarial loss, there are three components: two regression losses and one multimodal classification loss. Each loss is controlled by a hyper-parameter, i.e., $\alpha ,\beta$ , and $\gamma$ . We select the values of the hyper-parameters only from 0 and 1 . When the value of a hyper-parameter equals 1 , its corresponding component is "switch on", otherwise is "switch off". The performance differences between the two scenarios reveal the effects of the component.

在本研究中，我们量化了E - PGN中不同组件对性能的益处。在所提出的E - PGN模型中，除了基础对抗损失外，还有三个组件:两个回归损失和一个多模态分类损失。每个损失由一个超参数控制，即 $\alpha ,\beta$ 和 $\gamma$。我们仅从0和1中选择超参数的值。当超参数的值等于1时，其对应的组件“开启”，否则“关闭”。两种场景之间的性能差异揭示了该组件的影响。

<table><tr><td/><td rowspan="2">$\beta$</td><td rowspan="2">$\gamma$</td><td colspan="4">AwA1</td><td colspan="4">AwA2</td><td colspan="4">CUB</td><td colspan="4">FLO</td></tr><tr><td>$\alpha$</td><td>T</td><td>$\mathbf{u}$</td><td>$\mathbf{S}$</td><td>H</td><td>T</td><td>$\mathbf{u}$</td><td>S</td><td>H</td><td>T</td><td>$\mathbf{u}$</td><td>$\mathbf{S}$</td><td>H</td><td>T</td><td>$\mathbf{u}$</td><td>$\mathbf{S}$</td><td>H</td></tr><tr><td/><td>✓</td><td>✓</td><td>73.1</td><td>60.3</td><td>82.3</td><td>69.6</td><td>72.6</td><td>51.3</td><td>81.6</td><td>63.0</td><td>71.2</td><td>50.9</td><td>59.1</td><td>54.7</td><td>85.0</td><td>69.2</td><td>79.7</td><td>74.1</td></tr><tr><td>✓</td><td/><td>✓</td><td>73.8</td><td>61.0</td><td>83.1</td><td>70.4</td><td>72.2</td><td>52.5</td><td>82.7</td><td>64.3</td><td>67.2</td><td>45.9</td><td>55.9</td><td>50.4</td><td>85.8</td><td>69.4</td><td>82.0</td><td>75.2</td></tr><tr><td>✓</td><td>✓</td><td/><td>70.8</td><td>56.2</td><td>82.2</td><td>66.8</td><td>70.9</td><td>43.2</td><td>79.9</td><td>56.1</td><td>66.8</td><td>45.2</td><td>52.5</td><td>48.8</td><td>86.2</td><td>70.0</td><td>79.2</td><td>74.4</td></tr><tr><td/><td/><td>✓</td><td>72.1</td><td>56.2</td><td>81.5</td><td>66.5</td><td>71.2</td><td>48.5</td><td>84.0</td><td>61.5</td><td>70.3</td><td>50.0</td><td>57.5</td><td>53.5</td><td>85.6</td><td>71.3</td><td>80.5</td><td>75.6</td></tr><tr><td>✓</td><td>✓</td><td>✓</td><td>74.4</td><td>62.1</td><td>83.4</td><td>71.2</td><td>73.4</td><td>52.6</td><td>83.5</td><td>64.6</td><td>72.4</td><td>52.0</td><td>61.1</td><td>56.2</td><td>85.7</td><td>71.5</td><td>82.2</td><td>76.5</td></tr></table>

<table><tbody><tr><td></td><td rowspan="2">$\beta$</td><td rowspan="2">$\gamma$</td><td colspan="4">AwA1</td><td colspan="4">AwA2</td><td colspan="4">加州理工学院鸟类数据集(CUB，Caltech-UCSD Birds)</td><td colspan="4">花卉数据集(FLO，Flowers)</td></tr><tr><td>$\alpha$</td><td>T</td><td>$\mathbf{u}$</td><td>$\mathbf{S}$</td><td>H</td><td>T</td><td>$\mathbf{u}$</td><td>S</td><td>H</td><td>T</td><td>$\mathbf{u}$</td><td>$\mathbf{S}$</td><td>H</td><td>T</td><td>$\mathbf{u}$</td><td>$\mathbf{S}$</td><td>H</td></tr><tr><td></td><td>√</td><td>√</td><td>73.1</td><td>60.3</td><td>82.3</td><td>69.6</td><td>72.6</td><td>51.3</td><td>81.6</td><td>63.0</td><td>71.2</td><td>50.9</td><td>59.1</td><td>54.7</td><td>85.0</td><td>69.2</td><td>79.7</td><td>74.1</td></tr><tr><td>√</td><td></td><td>√</td><td>73.8</td><td>61.0</td><td>83.1</td><td>70.4</td><td>72.2</td><td>52.5</td><td>82.7</td><td>64.3</td><td>67.2</td><td>45.9</td><td>55.9</td><td>50.4</td><td>85.8</td><td>69.4</td><td>82.0</td><td>75.2</td></tr><tr><td>√</td><td>√</td><td></td><td>70.8</td><td>56.2</td><td>82.2</td><td>66.8</td><td>70.9</td><td>43.2</td><td>79.9</td><td>56.1</td><td>66.8</td><td>45.2</td><td>52.5</td><td>48.8</td><td>86.2</td><td>70.0</td><td>79.2</td><td>74.4</td></tr><tr><td></td><td></td><td>√</td><td>72.1</td><td>56.2</td><td>81.5</td><td>66.5</td><td>71.2</td><td>48.5</td><td>84.0</td><td>61.5</td><td>70.3</td><td>50.0</td><td>57.5</td><td>53.5</td><td>85.6</td><td>71.3</td><td>80.5</td><td>75.6</td></tr><tr><td>√</td><td>√</td><td>√</td><td>74.4</td><td>62.1</td><td>83.4</td><td>71.2</td><td>73.4</td><td>52.6</td><td>83.5</td><td>64.6</td><td>72.4</td><td>52.0</td><td>61.1</td><td>56.2</td><td>85.7</td><td>71.5</td><td>82.2</td><td>76.5</td></tr></tbody></table>

Table 4. Ablation study of the E-PGN components on four datasets. The best results are marked in boldface.

表4. E - PGN组件在四个数据集上的消融研究。最佳结果以粗体标记。

From the results illustrated in Table 4, we observe that the model with all three components mostly achieves the best performances for fourteen out of sixteen metrics, which indicates that the three calibration terms complement each other. Besides, we observe that the performances of the model without MCE loss $\left( {\gamma  = 0}\right)$ degrade significantly on three out of four datasets, which reveals that the MCE loss contributes significantly to the classification performance.

从表4所示的结果中，我们观察到包含所有三个组件的模型在十六个指标中的十四个指标上大多取得了最佳性能，这表明这三个校准项相互补充。此外，我们观察到没有MCE损失 $\left( {\gamma  = 0}\right)$ 的模型在四个数据集中的三个数据集上性能显著下降，这表明MCE损失对分类性能有显著贡献。

#### 4.3.3 Impact of classification network

#### 4.3.3 分类网络的影响

To further validate the superiority of the proposed multimodal cross-entropy loss, we compare our E-PGN against the method with the traditional cross-entropy loss. From the results illustrated in Fig. 4, we observe that the proposed E-PGN with MCE loss performs much better than the counterpart with traditional Cross-Entropy (CE) loss on AwA1, AwA2, and CUB datasets, and performs neck to neck on FLO dataset. We argue that the superiority is due to that the MCE loss encodes with the class semantic information into the classification module, which both preserves the discriminative information and enhances the visual-semantic consistence. Besides, compared with the model with the traditional CE loss, the model with the MCE loss introduces no extra training parameters, which is more efficient.

为了进一步验证所提出的多模态交叉熵损失的优越性，我们将我们的E - PGN与使用传统交叉熵损失的方法进行了比较。从图4所示的结果中，我们观察到使用MCE损失的所提出的E - PGN在AwA1、AwA2和CUB数据集上的性能远优于使用传统交叉熵(CE)损失的对应方法，在FLO数据集上的性能相当。我们认为这种优越性是由于MCE损失将类别语义信息编码到分类模块中，既保留了判别信息，又增强了视觉 - 语义一致性。此外，与使用传统CE损失的模型相比，使用MCE损失的模型不引入额外的训练参数，效率更高。

#### 4.3.4 Impact of distance metric

#### 4.3.4 距离度量的影响

In this experiment, we investigate how the distance metric affects the classification performance. In Fig. 5, we compare Cosine vs. Euclidean distance under different metrics on four datasets. We observe that the performances obtained in the Euclidean space are significantly better than those obtained in the Cosine space under most cases, indicating that the Euclidean distance is more suitable to our approach. The inferior performances obtained in Cosine space may be due to that the Cosine distance is not a Bregman divergence [26].

在这个实验中，我们研究了距离度量如何影响分类性能。在图5中，我们比较了四个数据集上不同指标下的余弦距离和欧几里得距离。我们观察到，在大多数情况下，在欧几里得空间中获得的性能明显优于在余弦空间中获得的性能，这表明欧几里得距离更适合我们的方法。在余弦空间中获得的较差性能可能是由于余弦距离不是Bregman散度[26]。

![0195e035-f6c1-757a-ab08-b11e9284a329_7_906_571_700_541_0.jpg](images/0195e035-f6c1-757a-ab08-b11e9284a329_7_906_571_700_541_0.jpg)

Figure 5. Traditional and generalized zero-shot classification results with Euclidean distance (short for Euc) and Cosine distance (short for Cos) on four datasets.

图5. 四个数据集上使用欧几里得距离(简称Euc)和余弦距离(简称Cos)的传统和广义零样本分类结果。

## 5. Conclusion

## 5. 结论

In this paper, we have introduced an episode-based training paradigm to enhance the adaptability of the model for zero-shot learning. It divides the training process into a collection of episodes, each of which mimics a fake zero-shot classification task. By training multiple episodes, the model accumulates a wealth of ensemble experiences on predicting the mimetic unseen classes, which generalizes well on the real unseen classes. Under this training paradigm, we have proposed an effective generative model to align the visual-semantic consistency paired with a parameter-economic multi-modal cross-entropy loss. The comprehensive results on four benchmark datasets demonstrate that the proposed model achieves the new state-of-the-art and beats the competitors by large margins.

在本文中，我们引入了一种基于情节的训练范式来增强模型在零样本学习中的适应性。它将训练过程划分为一系列情节，每个情节模拟一个虚假的零样本分类任务。通过训练多个情节，模型积累了大量关于预测模拟未见类别的集成经验，这在真实未见类别上具有良好的泛化能力。在这种训练范式下，我们提出了一种有效的生成模型，以对齐视觉 - 语义一致性，并结合了一种参数经济的多模态交叉熵损失。四个基准数据集上的综合结果表明，所提出的模型达到了新的最先进水平，并大幅击败了竞争对手。

Acknowledgement. This work is supported in part by NSFC (61672456, U19B2043), Zhejiang Lab (2018EC0ZX01-2), the fundamental research funds for central universities in China (No. 2017FZA5007), Artificial Intelligence Research Foundation of Baidu Inc., the Key Program of Zhejiang Province, China (No. 2015C01027), the funding from HIKVision and Horizon Robotics, and ZJU Converging Media Computing Lab.

致谢。本工作部分得到了国家自然科学基金(61672456，U19B2043)、之江实验室(2018EC0ZX01 - 2)、中央高校基本科研业务费(编号2017FZA5007)、百度人工智能研究基金、浙江省重点项目(编号2015C01027)、海康威视和地平线机器人的资助以及浙江大学融合媒体计算实验室的支持。

## References

## 参考文献

[1] Zeynep Akata, Florent Perronnin, Zaid Harchaoui, and Cordelia Schmid. Label-embedding for attribute-based classification. In ${CVPR}$ , pages ${819} - {826},{2013}$ .

[1] Zeynep Akata，Florent Perronnin，Zaid Harchaoui和Cordelia Schmid。基于属性分类的标签嵌入。见 ${CVPR}$ ，第 ${819} - {826},{2013}$ 页。

[2] Zeynep Akata, Scott Reed, Daniel Walter, Honglak Lee, and Bernt Schiele. Evaluation of output embeddings for fine-grained image classification. In ${CVPR}$ , pages 2927-2936, 2015.

[2] Zeynep Akata，Scott Reed，Daniel Walter，Honglak Lee和Bernt Schiele。细粒度图像分类输出嵌入的评估。见 ${CVPR}$ ，第2927 - 2936页，2015年。

[3] Martin Arjovsky, Soumith Chintala, and Léon Bottou. Wasser-stein generative adversarial networks. In ${ICML}$ , pages 214- 223, 2017.

[3] Martin Arjovsky，Soumith Chintala和Léon Bottou。Wasserstein生成对抗网络。见 ${ICML}$ ，第214 - 223页，2017年。

[4] Yuval Atzmon and Gal Chechik. Adaptive confidence smoothing for generalized zero-shot learning. In CVPR, pages 11671- 11680, 2019.

[4] Yuval Atzmon和Gal Chechik。广义零样本学习的自适应置信平滑。见CVPR，第11671 - 11680页，2019年。

[5] Deng-Ping Fan, Wenguan Wang, Ming-Ming Cheng, and Jianbing Shen. Shifting more attention to video salient object detection. In CVPR, pages 8554-8564, 2019.

[5] 樊登平，王文冠，程明明和沈建兵。将更多注意力转移到视频显著目标检测上。见CVPR，第8554 - 8564页，2019年。

[6] Rafael Felix, Vijay BG Kumar, Ian Reid, and Gustavo Carneiro. Multi-modal cycle-consistent generalized zero-shot learning. In ${ECCV}$ , pages ${21} - {37},{2018}$ .

[6] 拉斐尔·费利克斯(Rafael Felix)、维杰·BG·库马尔(Vijay BG Kumar)、伊恩·里德(Ian Reid)和古斯塔沃·卡内罗(Gustavo Carneiro)。多模态循环一致的广义零样本学习。见 ${ECCV}$ ，第 ${21} - {37},{2018}$ 页。

[7] Rafael Felix, Michele Sasdelli, Ian Reid, and Gustavo Carneiro. Multi-modal ensemble classification for generalized zero shot learning. arXiv:1901.04623, 2019.

[7] 拉斐尔·费利克斯(Rafael Felix)、米歇尔·萨斯德利(Michele Sasdelli)、伊恩·里德(Ian Reid)和古斯塔沃·卡内罗(Gustavo Carneiro)。用于广义零样本学习的多模态集成分类。预印本 arXiv:1901.04623，2019 年。

[8] Chelsea Finn, Pieter Abbeel, and Sergey Levine. Model-agnostic meta-learning for fast adaptation of deep networks. In ${ICML}$ , pages 1126-1135,2017.

[8] 切尔西·芬恩(Chelsea Finn)、彼得·阿贝贝尔(Pieter Abbeel)和谢尔盖·列维(Sergey Levine)。用于深度网络快速适应的模型无关元学习。见 ${ICML}$ ，第 1126 - 1135 页，2017 年。

[9] Andrea Frome, Greg S Corrado, Jon Shlens, Samy Bengio, Jeff Dean, Tomas Mikolov, et al. Devise: A deep visual-semantic embedding model. In NeurIPS, pages 2121-2129, 2013.

[9] 安德里亚·弗罗姆(Andrea Frome)、格雷格·S·科拉多(Greg S Corrado)、乔恩·什伦斯(Jon Shlens)、萨米·本吉奥(Samy Bengio)、杰夫·迪恩(Jeff Dean)、托马斯·米科洛夫(Tomas Mikolov)等。Devise:一种深度视觉 - 语义嵌入模型。见神经信息处理系统大会(NeurIPS)，第 2121 - 2129 页，2013 年。

[10] Ian Goodfellow, Jean Pouget-Abadie, Mehdi Mirza, Bing Xu, David Warde-Farley, Sherjil Ozair, Aaron Courville, and Yoshua Bengio. Generative adversarial nets. In NeurIPS, pages 2672-2680, 2014.

[10] 伊恩·古德费洛(Ian Goodfellow)、让·普热 - 阿巴迪(Jean Pouget - Abadie)、梅赫迪·米尔扎(Mehdi Mirza)、徐冰(Bing Xu)、大卫·沃德 - 法利(David Warde - Farley)、舍尔吉尔·奥扎尔(Sherjil Ozair)、亚伦·库尔维尔(Aaron Courville)和约书亚·本吉奥(Yoshua Bengio)。生成对抗网络。见神经信息处理系统大会(NeurIPS)，第 2672 - 2680 页，2014 年。

[11] Ishaan Gulrajani, Faruk Ahmed, Martin Arjovsky, Vincent Dumoulin, and Aaron C Courville. Improved training of wasserstein gans. In NeurIPS, pages 5767-5777, 2017.

[11] 伊沙安·古拉贾尼(Ishaan Gulrajani)、法鲁克·艾哈迈德(Faruk Ahmed)、马丁·阿约夫斯基(Martin Arjovsky)、文森特·迪穆兰(Vincent Dumoulin)和亚伦·C·库尔维尔(Aaron C Courville)。改进的 Wasserstein 生成对抗网络训练方法。见神经信息处理系统大会(NeurIPS)，第 5767 - 5777 页，2017 年。

[12] Kaiming He, Xiangyu Zhang, Shaoqing Ren, and Jian Sun. Deep residual learning for image recognition. In ${CVPR}$ , pages 770-778, 2016.

[12] 何恺明(Kaiming He)、张祥雨(Xiangyu Zhang)、任少卿(Shaoqing Ren)和孙剑(Jian Sun)。用于图像识别的深度残差学习。见 ${CVPR}$ ，第 770 - 778 页，2016 年。

[13] He Huang, Changhu Wang, Philip S Yu, and Chang-Dong Wang. Generative dual adversarial network for generalized zero-shot learning. In CVPR, pages 801-810, 2019.

[13] 黄贺(He Huang)、王长虎(Changhu Wang)、菲利普·S·于(Philip S Yu)和王长东(Chang - Dong Wang)。用于广义零样本学习的生成式对偶对抗网络。见计算机视觉与模式识别会议(CVPR)，第 801 - 810 页，2019 年。

[14] Diederik P Kingma and Max Welling. Autoencoding variational bayes. In ${ICLR},{2014}$ .

[14] 迪德里克·P·金马(Diederik P Kingma)和马克斯·韦林(Max Welling)。自动编码变分贝叶斯。见 ${ICLR},{2014}$ 。

[15] Vinay Kumar Verma, Gundeep Arora, Ashish Mishra, and Piyush Rai. Generalized zero-shot learning via synthesized examples. In CVPR, pages 4281-4289, 2018.

[15] 维奈·库马尔·维尔马(Vinay Kumar Verma)、贡迪普·阿罗拉(Gundeep Arora)、阿希什·米什拉(Ashish Mishra)和皮尤什·拉伊(Piyush Rai)。通过合成示例进行广义零样本学习。见计算机视觉与模式识别会议(CVPR)，第 4281 - 4289 页，2018 年。

[16] Christoph H Lampert, Hannes Nickisch, and Stefan Harmel-ing. Learning to detect unseen object classes by between-class attribute transfer. In CVPR, pages 951-958, 2009.

[16] 克里斯托夫·H·兰佩特(Christoph H Lampert)、汉内斯·尼基施(Hannes Nickisch)和斯特凡·哈梅林(Stefan Harmel - ing)。通过类间属性转移学习检测未见对象类。见计算机视觉与模式识别会议(CVPR)，第 951 - 958 页，2009 年。

[17] Jingjing Li, Mengmeng Jin, Ke Lu, Zhengming Ding, Lei Zhu, and Zi Huang. Leveraging the invariant side of generative zero-shot learning. In CVPR, pages 7402-7411, 2019.

[17] 李晶晶(Jingjing Li)、金萌萌(Mengmeng Jin)、卢柯(Ke Lu)、丁正明(Zhengming Ding)、朱磊(Lei Zhu)和黄子(Zi Huang)。利用生成式零样本学习的不变性方面。见计算机视觉与模式识别会议(CVPR)，第 7402 - 7411 页，2019 年。

[18] Maria-Elena Nilsback and Andrew Zisserman. Automated flower classification over a large number of classes. In ${IC}$ - CVGI, pages 722-729, 2008.

[18] 玛丽亚 - 埃琳娜·尼尔兹巴克(Maria - Elena Nilsback)和安德鲁·齐斯曼(Andrew Zisserman)。大规模类别上的自动花卉分类。见 ${IC}$ - 计算机视觉与图形学国际会议(CVGI)，第 722 - 729 页，2008 年。

[19] Sachin Ravi and Hugo Larochelle. Optimization as a model for few-shot learning. In ICLR, 2017.

[19] 萨钦·拉维(Sachin Ravi)和雨果·拉罗谢尔(Hugo Larochelle)。将优化作为少样本学习的模型。见国际学习表征会议(ICLR)，2017 年。

[20] Scott Reed, Zeynep Akata, Honglak Lee, and Bernt Schiele. Learning deep representations of fine-grained visual descriptions. In ${CVPR}$ , pages ${49} - {58},{2016}$ .

[20] 斯科特·里德(Scott Reed)、泽内普·阿卡塔(Zeynep Akata)、洪拉克·李(Honglak Lee)和伯恩特·谢勒(Bernt Schiele)。学习细粒度视觉描述的深度表示。见 ${CVPR}$ ，第 ${49} - {58},{2016}$ 页。

[21] Shaoqing Ren, Kaiming He, Ross Girshick, and Jian Sun. Faster r-cnn: Towards real-time object detection with region proposal networks. In NeurIPS, pages 91-99, 2015.

[21] 任少卿(Shaoqing Ren)、何恺明(Kaiming He)、罗斯·吉里什克(Ross Girshick)和孙剑(Jian Sun)。Faster R - CNN:基于区域提议网络的实时目标检测。见神经信息处理系统大会(NeurIPS)，第 91 - 99 页，2015 年。

[22] Bernardino Romera-Paredes and Philip Torr. An embarrassingly simple approach to zero-shot learning. In ${ICML}$ , pages 2152-2161, 2015.

[22] 贝尔纳迪诺·罗梅拉 - 帕雷德斯(Bernardino Romera - Paredes)和菲利普·托尔(Philip Torr)。一种极其简单的零样本学习方法。发表于 ${ICML}$，第2152 - 2161页，2015年。

[23] Mert Bulent Sariyildiz and Ramazan Gokberk Cinbis. Gradient matching generative networks for zero-shot learning. In CVPR, pages 2168-2178, 2019.

[23] 梅尔特·布伦特·萨里耶尔迪兹(Mert Bulent Sariyildiz)和拉马赞·戈克伯克·钦比斯(Ramazan Gokberk Cinbis)。用于零样本学习的梯度匹配生成网络。发表于计算机视觉与模式识别会议(CVPR)，第2168 - 2178页，2019年。

[24] Edgar Schonfeld, Sayna Ebrahimi, Samarth Sinha, Trevor Darrell, and Zeynep Akata. Generalized zero-and few-shot learning via aligned variational autoencoders. In ${CVPR}$ , pages 8247-8255, 2019.

[24] 埃德加·舍恩菲尔德(Edgar Schonfeld)、赛娜·易卜拉希米(Sayna Ebrahimi)、萨马尔思·辛哈(Samarth Sinha)、特雷弗·达雷尔(Trevor Darrell)和泽内普·阿卡塔(Zeynep Akata)。通过对齐变分自编码器实现广义零样本和少样本学习。发表于 ${CVPR}$，第8247 - 8255页，2019年。

[25] Yutaro Shigeto, Ikumi Suzuki, Kazuo Hara, Masashi Shimbo, and Yuji Matsumoto. Ridge regression, hubness, and zero-shot learning. In ${ECML}\& {KDD}$ , pages 135-151,2015.

[25] 重藤裕太郎(Yutaro Shigeto)、铃木郁美(Ikumi Suzuki)、原和夫(Kazuo Hara)、岛本正志(Masashi Shimbo)和松本裕二(Yuji Matsumoto)。岭回归、枢纽性与零样本学习。发表于 ${ECML}\& {KDD}$，第135 - 151页，2015年。

[26] Jake Snell, Kevin Swersky, and Richard Zemel. Prototypical networks for few-shot learning. In NeurIPS, pages 4077- 4087, 2017.

[26] 杰克·斯内尔(Jake Snell)、凯文·斯沃尔斯基(Kevin Swersky)和理查德·泽梅尔(Richard Zemel)。用于少样本学习的原型网络。发表于神经信息处理系统大会(NeurIPS)，第4077 - 4087页，2017年。

[27] Jie Song, Chengchao Shen, Yezhou Yang, Yang Liu, and Mingli Song. Transductive unbiased embedding for zero-shot learning. In ${CVPR}$ , pages ${1024} - {1033},{2018}$ .

[27] 宋杰、沈成超、杨业洲、杨柳和宋明利。用于零样本学习的直推式无偏嵌入。发表于 ${CVPR}$，第 ${1024} - {1033},{2018}$ 页。

[28] Flood Sung, Yongxin Yang, Li Zhang, Tao Xiang, Philip H S Torr, and Timothy M Hospedales. Learning to compare: Relation network for few-shot learning. In ${CVPR}$ , pages 1199-1208, 2018.

[28] 弗洛德·宋(Flood Sung)、杨永新、张立、向涛、菲利普·H·S·托尔(Philip H S Torr)和蒂莫西·M·霍斯佩代尔斯(Timothy M Hospedales)。学会比较:用于少样本学习的关系网络。发表于 ${CVPR}$，第1199 - 1208页，2018年。

[29] Oriol Vinyals, Charles Blundell, Timothy Lillicrap, Daan Wierstra, et al. Matching networks for one shot learning. In NeurIPS, pages 3630-3638, 2016.

[29] 奥里奥尔·维尼亚尔斯(Oriol Vinyals)、查尔斯·布伦德尔(Charles Blundell)、蒂莫西·利利克拉普(Timothy Lillicrap)、达恩·维斯特拉(Daan Wierstra)等。用于单样本学习的匹配网络。发表于神经信息处理系统大会(NeurIPS)，第3630 - 3638页，2016年。

[30] Catherine Wah, Steve Branson, Peter Welinder, Pietro Perona, and Serge Belongie. The caltech-ucsd birds-200-2011 dataset. 2011.

[30] 凯瑟琳·瓦(Catherine Wah)、史蒂夫·布兰森(Steve Branson)、彼得·韦林德(Peter Welinder)、彼得罗·佩罗纳(Pietro Perona)和塞尔日·贝洛涅(Serge Belongie)。加州理工学院 - 加州大学圣地亚哥分校鸟类200 - 2011数据集。2011年。

[31] Wenlin Wang, Yunchen Pu, Vinay Kumar Verma, Kai Fan, Yizhe Zhang, Changyou Chen, Piyush Rai, and Lawrence Carin. Zero-shot learning via class-conditioned deep generative models. In AAAI, pages 4211-4218, 2018.

[31] 王文林、蒲云晨、维奈·库马尔·维尔马(Vinay Kumar Verma)、范凯、张一哲、陈长有、皮尤什·拉伊(Piyush Rai)和劳伦斯·卡林(Lawrence Carin)。通过类条件深度生成模型实现零样本学习。发表于美国人工智能协会会议(AAAI)，第4211 - 4218页，2018年。

[32] Yongqin Xian, Zeynep Akata, Gaurav Sharma, Quynh Nguyen, Matthias Hein, and Bernt Schiele. Latent embed-dings for zero-shot classification. In CVPR, pages 69-77, 2016.

[32] 冼永勤(Yongqin Xian)、泽内普·阿卡塔(Zeynep Akata)、高拉夫·夏尔马(Gaurav Sharma)、阮琼(Quynh Nguyen)、马蒂亚斯·海因(Matthias Hein)和伯恩特·席勒(Bernt Schiele)。用于零样本分类的潜在嵌入。发表于计算机视觉与模式识别会议(CVPR)，第69 - 77页，2016年。

[33] Yongqin Xian, Christoph H Lampert, Bernt Schiele, and Zeynep Akata. Zero-shot learning-a comprehensive evaluation of the good, the bad and the ugly. TPAMI, 41(9):2251- 2265, 2018.

[33] 冼永勤(Yongqin Xian)、克里斯托夫·H·兰佩特(Christoph H Lampert)、伯恩特·席勒(Bernt Schiele)和泽内普·阿卡塔(Zeynep Akata)。零样本学习——对优劣与不足的全面评估。发表于《模式分析与机器智能汇刊》(TPAMI)，41(9):2251 - 2265，2018年。

[34] Yongqin Xian, Tobias Lorenz, Bernt Schiele, and Zeynep Akata. Feature generating networks for zero-shot learning. In CVPR, pages 5542-5551, 2018.

[34] 冼永勤(Yongqin Xian)、托比亚斯·洛伦茨(Tobias Lorenz)、伯恩特·席勒(Bernt Schiele)和泽内普·阿卡塔(Zeynep Akata)。用于零样本学习的特征生成网络。发表于计算机视觉与模式识别会议(CVPR)，第5542 - 5551页，2018年。

[35] Yongqin Xian, Saurabh Sharma, Bernt Schiele, and Zeynep Akata. f-vaegan-d2: A feature generating framework for any-shot learning. In CVPR, pages 10275-10284, 2019.

[35] 冼永勤(Yongqin Xian)、索拉布·夏尔马(Saurabh Sharma)、伯恩特·席勒(Bernt Schiele)和泽内普·阿卡塔(Zeynep Akata)。f - vaegan - d2:一种用于任意样本学习的特征生成框架。发表于计算机视觉与模式识别会议(CVPR)，第10275 - 10284页，2019年。

[36] Guo-Sen Xie, Li Liu, Xiaobo Jin, Fan Zhu, Zheng Zhang, Jie Qin, Yazhou Yao, and Ling Shao. Attentive region embedding

[36] 谢国森、刘力、金小波、朱凡、张政、秦杰、姚亚洲和邵玲。用于零样本学习的注意力区域嵌入

network for zero-shot learning. In CVPR, pages 9384-9393, 2019.

网络。发表于计算机视觉与模式识别会议(CVPR)，第9384 - 9393页，2019年。

[37] Yunlong Yu, Zhong Ji, Yanwei Fu, Jichang Guo, Yanwei Pang, and Zhongfei Zhang. Stacked semantics-guided attention model for fine-grained zero-shot learning. In NeurIPS, pages 5995-6004, 2018.

[37] 于云龙、纪忠、付彦伟、郭吉昌、庞彦伟和张中飞。用于细粒度零样本学习的堆叠语义引导注意力模型。发表于《神经信息处理系统大会》(NeurIPS)，第5995 - 6004页，2018年。

[38] Li Zhang, Tao Xiang, and Shaogang Gong. Learning a deep embedding model for zero-shot learning. In CVPR, pages 2021-2030, 2017.

[38] 张莉、向涛和龚少刚。用于零样本学习的深度嵌入模型学习。发表于《计算机视觉与模式识别会议》(CVPR)，第2021 - 2030页，2017年。

[39] Yizhe Zhu, Mohamed Elhoseiny, Bingchen Liu, Xi Peng, and Ahmed Elgammal. A generative adversarial approach for zero-shot learning from noisy texts. In ${CVPR}$ , pages 1004- 1013, 2018.

[39] 朱一哲、穆罕默德·埃尔霍塞尼、刘炳辰、彭熙和艾哈迈德·埃尔加马尔。一种从嘈杂文本中进行零样本学习的生成对抗方法。发表于 ${CVPR}$ ，第1004 - 1013页，2018年。

[40] Yizhe Zhu, Jianwen Xie, Bingchen Liu, and Ahmed Elgam-mal. Learning feature-to-feature translator by alternating back-propagation for zero-shot learning. In ${ICCV}$ , pages 9844-9854, 2019.

[40] 朱一哲、谢建文、刘炳辰和艾哈迈德·埃尔加马尔。通过交替反向传播学习特征到特征的转换器以用于零样本学习。发表于 ${ICCV}$ ，第9844 - 9854页，2019年。