# Domain Generalization - A Causal Perspective

# 领域泛化——因果视角

A Preprint

预印本

Paras Sheth, Raha Moraffah, K. Selçuk Candan, Adrienne Raglin ${}^{ \dagger  }$ , Huan Liu ${}^{ * }$

帕拉斯·谢思(Paras Sheth)、拉哈·莫拉法(Raha Moraffah)、K. 塞尔丘克·坎丹(K. Selçuk Candan)、阿德里安娜·拉格林(Adrienne Raglin) ${}^{ \dagger  }$、刘欢(Huan Liu) ${}^{ * }$

November 8, 2022

2022年11月8日

## Abstract

## 摘要

Machine learning models rely on various assumptions to attain high accuracy. One of the preliminary assumptions of these models is the independent and identical distribution, which suggests that the train and test data are sampled from the same distribution. However, this assumption seldom holds in the real world due to distribution shifts. As a result models that rely on this assumption exhibit poor generalization capabilities. Over the recent years, dedicated efforts have been made to improve the generalization capabilities of these models collectively known as - domain generalization methods. The primary idea behind these methods is to identify stable features or mechanisms that remain invariant across the different distributions. Many generalization approaches employ causal theories to describe invariance since causality and invariance are inextricably intertwined. However, current surveys deal with the causality-aware domain generalization methods on a very high-level Furthermore, we argue that it is possible to categorize the methods based on how causality is leveraged in that method and in which part of the model pipeline is it used. To this end, we categorize the causal domain generalization methods into three categories, namely, (i) Invariance via Causal Data Augmentation methods which are applied during the data pre-processing stage, (ii) Invariance via Causal representation learning methods that are utilized during the representation learning stage, and (iii) Invariance via Transferring Causal mechanisms methods that are applied during the classification stage of the pipeline. Furthermore, this survey includes in-depth insights into benchmark datasets and code repositories for domain generalization methods. We conclude the survey with insights and discussions on future directions.

机器学习模型依赖各种假设来实现高精度。这些模型的一个基本假设是独立同分布，即训练数据和测试数据是从同一分布中采样得到的。然而，由于分布偏移，这一假设在现实世界中很少成立。因此，依赖这一假设的模型泛化能力较差。近年来，人们致力于提高这些模型的泛化能力，这些方法统称为领域泛化方法。这些方法背后的主要思想是识别在不同分布中保持不变的稳定特征或机制。许多泛化方法采用因果理论来描述不变性，因为因果关系和不变性是紧密相连的。然而，目前的综述只是从非常宏观的层面探讨了具有因果意识的领域泛化方法。此外，我们认为可以根据方法中如何利用因果关系以及在模型流程的哪个部分使用因果关系对这些方法进行分类。为此，我们将因果领域泛化方法分为三类，即:(i)通过因果数据增强实现不变性的方法，应用于数据预处理阶段；(ii)通过因果表示学习实现不变性的方法，应用于表示学习阶段；(iii)通过转移因果机制实现不变性的方法，应用于流程的分类阶段。此外，本综述还深入介绍了用于领域泛化方法的基准数据集和代码库。最后，我们对未来的研究方向进行了展望和讨论。

## Keywords domain generalization - causality - vision - natural language processing - graphs

## 关键词 领域泛化 - 因果关系 - 视觉 - 自然语言处理 - 图

Machine learning (ML) models have achieved widespread success in variety of applications, including recommender systems [1], autonomous cars [2], and across various areas including, but not limited to, computer vision, graphs, and natural language processing. However, the success of these models is accompanied by various assumptions such as the independent and identical distributions or the i.i.d. assumption. According to this assumption the training and testing data are identically and independently distributed. In other words, the train and test data stem from the same distribution.

机器学习(ML)模型在各种应用中取得了广泛的成功，包括推荐系统 [1]、自动驾驶汽车 [2]，以及计算机视觉、图和自然语言处理等多个领域。然而，这些模型的成功伴随着各种假设，如独立同分布假设(i.i.d. 假设)。根据这一假设，训练数据和测试数据是独立同分布的。换句话说，训练数据和测试数据来自同一分布。

However, real-world data seldom abides by this assumption. Due to the dynamic nature of the systems that employ the machine learning models, the training data distribution might not be the same as the test data distribution and as a result the model's accuracy decreases. Under the machine learning paradigm, this phenomenon is known as distribution shift. For instance consider the task of digit classification as shown in Fig. 1 Given a model trained on a set of black and white handwritten digits [3] and evaluated on a set of colored handwritten digits [4] it is observed that the model performance drastically reduces, which raises the question Why this happens? It is well known that machine learning models leverage correlations among the different features to improve the prediction accuracy [5, 6]. However, in multiple real-world scenarios and the shown example, the model learns patterns (correlations) that are present in the training data but do not hold when evaluated against the test data. Thus, it results in the degrading performance.

然而，现实世界的数据很少遵循这一假设。由于采用机器学习模型的系统具有动态性，训练数据的分布可能与测试数据的分布不同，从而导致模型的准确率下降。在机器学习范式中，这种现象被称为分布偏移。例如，考虑图1所示的数字分类任务。给定一个在一组黑白手写数字上训练的模型 [3]，并在一组彩色手写数字上进行评估 [4]，可以观察到模型的性能急剧下降，这就引出了一个问题:为什么会出现这种情况？众所周知，机器学习模型利用不同特征之间的相关性来提高预测准确率 [5, 6]。然而，在多个现实场景和所示示例中，模型学习到的模式(相关性)存在于训练数据中，但在对测试数据进行评估时却不成立。因此，这会导致性能下降。

One possible solution to address the distribution shift problem is to improve the generalization capabilities of the ML models which can be done in various ways including Domain Adaptation (DA) and Domain Generalization (DG).

解决分布偏移问题的一种可能方法是提高机器学习模型的泛化能力，可以通过多种方式实现，包括领域自适应(DA)和领域泛化(DG)。

---

*Adrienne Raglin is with Army Research Laboratory (ARL). All other authors are with School of Computing and Augmented Intelligence, Arizona State University, Tempe, AZ, USA. (e-mail: \{psheth5, rmoraffa, candan, huanliu\}@asu.edu, adrienne.raglin2.civ@mail.mil)

*阿德里安娜·拉格林就职于陆军研究实验室(ARL)。其他所有作者均就职于美国亚利桑那州坦佩市亚利桑那州立大学计算与增强智能学院。(电子邮件:{psheth5, rmoraffa, candan, huanliu}@asu.edu，adrienne.raglin2.civ@mail.mil)

---

![0195d14d-089f-77d1-a441-1daf38e81816_1_229_203_1340_507_0.jpg](images/0195d14d-089f-77d1-a441-1daf38e81816_1_229_203_1340_507_0.jpg)

Figure 1: The task of digit classification from a domain generalization perspective. A model trained on MNIST dataset would fail to generalize when evaluated on ColoredMNIST, or RotatedMNIST.

图1:从领域泛化的角度看数字分类任务。在MNIST数据集上训练的模型在ColoredMNIST或RotatedMNIST数据集上进行评估时将无法实现泛化。

Although domain adaptation methods lie outside the scope of this survey, we introduce them to distinguish between domain generalization and domain adaptation. Generally, both DA and DG focus on the same task, i.e., to improve the generalizability in ML models. However, the key difference between DA and DG methods is that the DA methods use a small number of unlabeled data points from the previously unseen test data (also known as target domain(s)) to fine-tune the model trained on the training data (also known as source domain(s)) [7, 8, 9]. However, in real-world settings the target data is usually not accessible beforehand to perform model adaptation. Thus, to deal with situations when the target domain data is unavailable, domain generalization methods were introduced [10].

尽管领域自适应(Domain Adaptation，DA)方法不在本次综述的范围内，但我们引入它们是为了区分领域泛化(Domain Generalization，DG)和领域自适应。一般来说，DA和DG都关注同一任务，即提高机器学习模型的泛化能力。然而，DA和DG方法的关键区别在于，DA方法使用少量来自先前未见测试数据(也称为目标领域)的无标签数据点，来微调在训练数据(也称为源领域)上训练的模型 [7, 8, 9]。然而，在现实场景中，通常无法提前获取目标数据来进行模型自适应。因此，为了应对目标领域数据不可用的情况，引入了领域泛化方法 [10]。

With the distinction of DG and DA methods, we focus on understanding the working mechanism of DG methods, and how causality aids in the process. To understand this, let's consider the aforementioned digit classification scenario. Although the train domain data consisted of black and white images of digits and the target domain consisted of colored digits, as humans we are still able to classify the digits even after the distribution shift. Even though the digits are colored in the target domain, the shape of the digit, which is crucial in determining the digit, remains invariant. This implies that even in the presence of distribution shifts there exists a set of features that are invariant and are crucial for the prediction performance. Furthermore, it is well established that causality and invariance are tightly linked to each other, i.e., one of the dimensions of causality is invariance [11, 12]. Thus, causality can be a useful tool in capturing the invariance present in the data, justifying the range of methods that have leveraged different causal theories for improving the generalization capabilities of models [4, 13].

在区分了DG和DA方法之后，我们将重点放在理解DG方法的工作机制，以及因果关系在这一过程中所起的作用。为了理解这一点，让我们考虑前面提到的数字分类场景。尽管训练领域数据由数字的黑白图像组成，而目标领域由彩色数字组成，但作为人类，即使在分布发生变化后，我们仍然能够对数字进行分类。即使目标领域中的数字是彩色的，但对于确定数字至关重要的数字形状保持不变。这意味着，即使存在分布变化，仍然存在一组不变的特征，这些特征对于预测性能至关重要。此外，因果关系和不变性之间的紧密联系已得到充分证实，即因果关系的一个维度就是不变性 [11, 12]。因此，因果关系可以作为捕捉数据中不变性的有用工具，这也证明了一系列利用不同因果理论来提高模型泛化能力的方法的合理性 [4, 13]。

Since there exist multiple causality aware domain generalization methods, the next step should be to understand how these methods leverage causality and how they differ among themselves. Although majority of the existing surveys discuss causal domain generalization methods [14, 15, 16] they mostly club all the methods under the same umbrella term, i.e., causality aware domain generalization methods or causal representation methods. We argue that these methods can be better classified based on where the causal theories are leveraged during the entire model pipeline. To this end, we categorize these papers broadly into three different categories: (i) Invariance via Causal Data Augmentation methods which are applied during the data pre-processing stage, (ii) Invariance via Causal representation learning methods that are utilized during the representation learning stage, and (iii) Invariance via Transferring Causal mechanisms methods that are applied during the classification stage of the pipeline. Furthermore, Fig. 2 shows the detailed breakdown of these categories into their corresponding subcategories.

由于存在多种具有因果意识的领域泛化方法，下一步应该是理解这些方法如何利用因果关系，以及它们之间的差异。尽管现有的大多数综述都讨论了因果领域泛化方法 [14, 15, 16]，但它们大多将所有方法归为同一类别，即具有因果意识的领域泛化方法或因果表示方法。我们认为，可以根据在整个模型流程中利用因果理论的位置，对这些方法进行更好的分类。为此，我们将这些论文大致分为三类:(i)通过因果数据增强实现不变性的方法，应用于数据预处理阶段；(ii)通过因果表示学习实现不变性的方法，应用于表示学习阶段；(iii)通过转移因果机制实现不变性的方法，应用于流程的分类阶段。此外，图2展示了这些类别进一步细分为相应子类别。

The remaining part of the survey is categorized as follows. Section 1 covers the problem definition and causal preliminaries, Section 2 covers the different categories and the sub-categories helping the reader understand how causality can be leveraged in different parts of the model pipeline and how each category tackles its corresponding challenges. Section 3 covers the Causal DG methods developed for the graphs and Natural Language Processing (NLP). Section ?? covers the benchmark datasets and evaluation schemes employed by various methods for evaluating the performances. This section also covers the publicly available code repositories which could aid researchers in developing and testing their own models. We finally conclude the survey with Section ??.

本综述的其余部分分类如下。第1节涵盖问题定义和因果预备知识，第2节涵盖不同的类别和子类别，帮助读者理解如何在模型流程的不同部分利用因果关系，以及每个类别如何应对相应的挑战。第3节涵盖为图和自然语言处理(Natural Language Processing，NLP)开发的因果DG方法。第??节涵盖各种方法用于评估性能的基准数据集和评估方案。本节还涵盖公开可用的代码库，这些代码库可以帮助研究人员开发和测试自己的模型。最后，我们在第??节对本综述进行总结。

![0195d14d-089f-77d1-a441-1daf38e81816_2_197_210_1407_1220_0.jpg](images/0195d14d-089f-77d1-a441-1daf38e81816_2_197_210_1407_1220_0.jpg)

Figure 2: The categorization of Causal Domain Generalization techniques.

图2:因果领域泛化技术的分类。

## 1 Problem Definition and Preliminaries

## 1 问题定义和预备知识

### 1.1 Problem Definition

### 1.1 问题定义

Consider $X$ as the set of features, $Y$ as the set of labels, and $D$ as the set of domain(s) with sample spaces $\mathcal{X},\mathcal{Y}$ , and $\mathcal{D}$ , respectively. A domain is defined as a joint distribution ${P}_{X, Y}$ on $\mathcal{X} \times  \mathcal{Y}$ . Let ${P}_{X}$ represent $X$ ’s marginal distribution, ${P}_{X \mid  Y}$ represent the class-conditional distribution of $X$ given $Y$ , and ${P}_{Y \mid  X}$ represent the posterior distribution of $Y$ given $X$ .

设 $X$ 为特征集，$Y$ 为标签集，$D$ 为具有样本空间 $\mathcal{X},\mathcal{Y}$ 和 $\mathcal{D}$ 的领域集。领域定义为 $\mathcal{X} \times  \mathcal{Y}$ 上的联合分布 ${P}_{X, Y}$。设 ${P}_{X}$ 表示 $X$ 的边缘分布，${P}_{X \mid  Y}$ 表示给定 $Y$ 时 $X$ 的类条件分布，${P}_{Y \mid  X}$ 表示给定 $X$ 时 $Y$ 的后验分布。

A domain generalization model’s purpose is to learn a predictive model $f : \mathcal{X} \rightarrow  \mathcal{Y}$ . However, while dealing with domain generalization, the common assumption implies that training data was obtained from a finite subset of the possible domains ${D}_{\text{train }} \subset  \mathcal{D}$ . Furthermore, the number of training domains is given by $K$ , and ${D}_{\text{train }} = {\left\{  {d}_{i}\right\}  }_{i = 1}^{K} \subset  \mathcal{D}$ . As a result, the training data is sampled from a distribution $P\left\lbrack  {X, Y \mid  D = {d}_{i}}\right\rbrack  \;\forall i \in  \left\lbrack  k\right\rbrack$ . The domain generalization model, then aims at utilizing only source (train) domain(s) data with the goal of minimizing the prediction error on a previously unseen target (test) domain. The corresponding joint distribution of the target domain ${D}_{\text{test }}$ is given by ${P}_{X, Y}^{{D}_{\text{test }}}$ and ${P}_{X, Y}^{{D}_{\text{test }}} \neq  {P}_{XY}^{\left( k\right) },\forall k \in  \{ 1,\ldots , K\}$ . Ideally, the goal is to learn a classifier that is optimal for all domains $\mathcal{D}$ .

领域泛化模型的目的是学习一个预测模型$f : \mathcal{X} \rightarrow  \mathcal{Y}$。然而，在处理领域泛化问题时，通常假设训练数据是从可能领域的有限子集中获取的${D}_{\text{train }} \subset  \mathcal{D}$。此外，训练领域的数量由$K$给出，且${D}_{\text{train }} = {\left\{  {d}_{i}\right\}  }_{i = 1}^{K} \subset  \mathcal{D}$。因此，训练数据是从一个分布$P\left\lbrack  {X, Y \mid  D = {d}_{i}}\right\rbrack  \;\forall i \in  \left\lbrack  k\right\rbrack$中采样得到的。然后，领域泛化模型的目标是仅利用源(训练)领域的数据，以最小化在之前未见过的目标(测试)领域上的预测误差。目标领域${D}_{\text{test }}$的相应联合分布由${P}_{X, Y}^{{D}_{\text{test }}}$和${P}_{X, Y}^{{D}_{\text{test }}} \neq  {P}_{XY}^{\left( k\right) },\forall k \in  \{ 1,\ldots , K\}$给出。理想情况下，目标是学习一个对所有领域$\mathcal{D}$都最优的分类器。

### 1.2 Preliminaries

### 1.2 预备知识

Most causality-aware domain generalization models aim to mitigate the reliance on spurious correlations by accounting for the confounding effects. For instance, some works mitigate the confounding bias induced by the non-causal features on the causal features and the labels. This leads to better generalizability of the machine learning model. Confounding variables refer to those sets of variables that may be observed or unobserved, directly influencing the supposed cause and effect variables.

大多数考虑因果关系的领域泛化模型旨在通过考虑混杂效应来减少对虚假相关性的依赖。例如，一些研究减轻了非因果特征对因果特征和标签所导致的混杂偏差。这使得机器学习模型具有更好的泛化能力。混杂变量是指那些可能被观察到或未被观察到的变量集，它们会直接影响假定的因果变量。

The confounding bias can be accounted for with either backdoor adjustment or front-door adjustment based on the nature of the problem. Therefore, we begin by defining the backdoor criterion.

根据问题的性质，可以通过后门调整或前门调整来处理混杂偏差。因此，我们首先定义后门准则。

Definition 1. Given a Directed Acyclic Graph (DAG) $G$ , a set of nodes $Z$ , and a pair of nodes, namely, $X$ and $Y$ , we say that $Z$ satisfies the backdoor criterion relative to $X$ and $Y$ if:

定义1. 给定一个有向无环图(DAG)$G$、一组节点$Z$以及一对节点，即$X$和$Y$，如果满足以下条件，我们称$Z$相对于$X$和$Y$满足后门准则:

- no node in $Z$ is a descendant of $Y$

- $Z$中没有节点是$Y$的后代

- Every path between $X$ and $Y$ that contains an arrow in $Y$ is blocked by $Z$ .

- $X$和$Y$之间每条包含指向$Y$的箭头的路径都被$Z$阻断。

If $Z$ satisfies the backdoor criterion for $X$ and $Y$ , the causal effect between $X$ and $Y$ is identifiable. The causal effect from $X$ to $Y$ can be formulated as,

如果$Z$相对于$X$和$Y$满足后门准则，则$X$和$Y$之间的因果效应是可识别的。从$X$到$Y$的因果效应可以表示为:

$$
P\left( {Y \mid  X}\right)  = \mathop{\sum }\limits_{z}P\left( {Y \mid  X, Z}\right) P\left( Z\right) . \tag{1}
$$

Similarly, another way to account for the confounding variables is the front-door criterion.

类似地，另一种处理混杂变量的方法是前门准则。

Definition 2. Given a Directed Acyclic Graph (DAG) $G$ , a set of nodes $Z$ , and a pair of nodes, namely, $X$ and $Y$ , we say that $Z$ satisfies the front-door criterion relative to $X$ and $Y$ if:

定义2. 给定一个有向无环图(DAG)$G$、一组节点$Z$以及一对节点，即$X$和$Y$，如果满足以下条件，我们称$Z$相对于$X$和$Y$满足前门准则:

- All directed paths from $X$ to $Y$ are intercepted by $Z$ ;

- 从$X$到$Y$的所有有向路径都被$Z$截断；

- There exists no unblocked backdoor path from $X$ to $Z$ ; and

- 从$X$到$Z$不存在未被阻断的后门路径；并且

- $X$ blocks all possible backdoor paths from $Z$ to $Y$ .

- $X$阻断了从$Z$到$Y$的所有可能的后门路径。

As per the front-door adjustment, if $Z$ satisfies the front-door criterion for $X$ and $Y$ , and if $P\left( {X, Z}\right)  > 0$ , then the causal effect between $X$ and $Y$ is identifiable. The causal effect from $X$ to $Y$ can be formulated as,

根据前门调整，如果$Z$相对于$X$和$Y$满足前门准则，并且如果$P\left( {X, Z}\right)  > 0$，那么$X$和$Y$之间的因果效应是可识别的。从$X$到$Y$的因果效应可以表示为:

$$
P\left( {Y \mid  \operatorname{do}\left( X\right) }\right)  = \mathop{\sum }\limits_{z}\mathop{\sum }\limits_{{x}^{\prime }}P\left( {Y \mid  Z,{X}^{\prime }}\right) P\left( {X}^{\prime }\right) P\left( {Z \mid  X}\right) . \tag{2}
$$

## 2 Domain Generalization via Invariance Learning

## 2 通过不变性学习实现领域泛化

Causal Domain Generalization methods aim to leverage causal theories to improve the generalization capabilities of models. The causal theories are utilized in various stages of the standard machine learning pipeline. To this end, we categorize the Causal DG methods based on how and where the causality aspects are utilized. To this end, we propose three categories, namely, (1) Invariance via Causal Data Augmentation methods which are applied during the data pre-processing stage, (2) Invariance via Causal representation learning methods that are utilized during the representation learning stage, and (3) Invariance via Transferring Causal mechanisms methods that are applied during the classification stage of the pipeline.

因果领域泛化(Causal Domain Generalization)方法旨在利用因果理论来提高模型的泛化能力。因果理论被应用于标准机器学习流程的各个阶段。为此，我们根据因果关系方面的利用方式和位置对因果领域泛化方法进行分类。为此，我们提出了三类方法，即:(1)通过因果数据增强实现不变性的方法，该方法应用于数据预处理阶段；(2)通过因果表示学习实现不变性的方法，该方法应用于表示学习阶段；(3)通过转移因果机制实现不变性的方法，该方法应用于流程的分类阶段。

Furthermore, we present the different subcategories associated with each category (when applicable) and discuss the methods for each corresponding sub-category. A summary of the categorization can be seen in Fig. 2 In the following sub-sections, we provide a comprehensive and detailed review of these methods corresponding to the above order and discuss their differences and theoretical connections.

此外，我们介绍了与每个类别相关的不同子类别(如果适用)，并讨论了每个相应子类别所采用的方法。分类总结如图2所示。在接下来的小节中，我们将按照上述顺序对这些方法进行全面而详细的回顾，并讨论它们的差异和理论联系。

These frameworks learn generalizable feature representations across different domains. Often, these representations are interpreted as causal feature representations. One possible way to learn such causal representations is to disentangle the input representations into causal and non-causal feature representations. By doing so, the domain shift can be justified as interventions on the non-causal features. In such a condition, the primary goal is to minimize a loss that is robust under changes in the distribution of these style (non-causal) features. For example, in Fig 3, the learned input representations can be divided into causal and non-causal features. Utilizing only the causal features for the task can improve generalizability.

这些框架学习跨不同领域的可泛化特征表示。通常，这些表示被解释为因果特征表示。学习此类因果表示的一种可能方法是将输入表示分解为因果和非因果特征表示。通过这样做，领域偏移可以被解释为对非因果特征的干预。在这种情况下，主要目标是最小化在这些风格(非因果)特征分布变化下具有鲁棒性的损失。例如，在图3中，学习到的输入表示可以分为因果和非因果特征。仅利用因果特征进行任务可以提高泛化能力。

![0195d14d-089f-77d1-a441-1daf38e81816_4_395_196_1003_998_0.jpg](images/0195d14d-089f-77d1-a441-1daf38e81816_4_395_196_1003_998_0.jpg)

Figure 3: A simple causal graph that disentangles the input representations into causal and non-causal representations. Only the causal representations are used for prediction.

图3:一个简单的因果图，将输入表示分解为因果和非因果表示。仅使用因果表示进行预测。

### 2.1 Invariance via Causal Data Augmentation

### 2.1 通过因果数据增强实现不变性

In this section, we present the frameworks that achieve invariance via causal data augmentation. Frameworks in this category utilize causal features and augment the data by considering all possible confounders/ spurious variables. Although these methods eventually aim to learn causal representations, the mechanisms they employ (such as identifying the features to augment on) follow a causal procedure thus promoting such methods to have their own category.

在本节中，我们介绍通过因果数据增强实现不变性的框架。该类别中的框架利用因果特征，并通过考虑所有可能的混杂因素/虚假变量来增强数据。尽管这些方法最终旨在学习因果表示，但它们采用的机制(例如确定要增强的特征)遵循因果过程，因此促使这些方法自成一类。

#### 2.1.1 Counterfactual Feature based Data Augmentation

#### 2.1.1 基于反事实特征的数据增强

Zhang et al. [17] propose a generalizable framework for the task of human pose estimation. The proposed framework aims to leverage generation of counterfactuals by intervening on the domain variable. In particular, these counterfactuals are generated by changing the domain variable. This framework enforces three main criteria to learn the causal representations: (1) Producing low-error prediction over the observed samples; (2) Producing low-error prediction over counterfactual samples; and (3) The counterfactual and observed feature representations are similar. The authors propose to implement the framework in two branches, namely observed branch and counterfactual branch. In the observed branch, images from source domain are fed to a feature extractor (encoder) to get the observed feature representation distribution. In the counterfactual branch, a GAN-based architecture is utilized to learn the distribution of counterfactuals from a ground-truth pose and random noise. Both observed and counterfactual representations are then fed to predictors to ensure they have high predictive power. To minimize the distance between observed and counterfactual representations a smooth- ${l}_{1}$ distance is utilized. The objective of this framework is given below:

Zhang等人[17]为人体姿态估计任务提出了一个可泛化的框架。所提出的框架旨在通过对领域变量进行干预来生成反事实。具体而言，这些反事实是通过改变领域变量生成的。该框架实施三个主要标准来学习因果表示:(1)对观察样本产生低误差预测；(2)对反事实样本产生低误差预测；(3)反事实和观察到的特征表示相似。作者提议将该框架分为两个分支来实现，即观察分支和反事实分支。在观察分支中，将源领域的图像输入到特征提取器(编码器)中，以获得观察到的特征表示分布。在反事实分支中，利用基于生成对抗网络(GAN)的架构从真实姿态和随机噪声中学习反事实的分布。然后将观察和反事实表示都输入到预测器中，以确保它们具有较高的预测能力。为了最小化观察和反事实表示之间的距离，使用了平滑${l}_{1}$距离。该框架的目标如下:

$$
\mathop{\min }\limits_{{{\theta }_{f},{\theta }_{h}}}{\mathbb{E}}_{\left( {x, y, u}\right)  \sim  \left( {p\left( x\right) , p\left( y\right) , p\left( u\right) }\right. }{\mathcal{L}}_{F}\left( {h\left( {f\left( x\right) }\right) , y}\right)  \tag{3}
$$

$$
{\lambda }_{1}{\mathcal{L}}_{CF}\left( {h\left( {g\left( {u, y}\right) }\right) , y}\right)  + {\lambda }_{2}{\mathcal{L}}_{\text{dist }}\left( {f\left( x\right) , g\left( {u, y}\right) }\right) ,
$$

where ${\mathcal{L}}_{F}$ and ${\mathcal{L}}_{CF}$ denote the prediction loss over observed and counterfactual representations, ${\lambda }_{1}$ and ${\lambda }_{2}$ are hyperparameters.

其中${\mathcal{L}}_{F}$和${\mathcal{L}}_{CF}$分别表示观察和反事实表示的预测损失，${\lambda }_{1}$和${\lambda }_{2}$是超参数。

Chen et al. [18] propose the Interventional Emotion Recognition Network (IERN) to improve the visual emotion recognition framework's generalization via causal data augmentation. IERN first disentangles the input image into the context features (confounding features) and emotion features (causal features). Finally, the framework proposes to debias the classifier via backdoor criterion using the following objective:

Chen等人[18]提出了干预式情感识别网络(Interventional Emotion Recognition Network，IERN)，通过因果数据增强来提高视觉情感识别框架的泛化能力。IERN首先将输入图像分解为上下文特征(混杂特征)和情感特征(因果特征)。最后，该框架提议通过后门准则对分类器进行去偏，使用以下目标:

$$
{\mathcal{L}}_{cl} = \mathop{\min }\limits_{{{f}_{c}^{\theta },{g}_{e}^{\theta },{f}_{b}^{\theta }}}\left( {{l}_{CE}\left( {\frac{1}{{N}_{c}}\left( {\mathop{\sum }\limits_{{i = 1}}^{{N}_{C}}{f}_{c}\left( {{g}_{r}\left( {{g}_{e}\left( {{f}_{b}\left( x\right) }\right) ,{C}_{i}}\right) }\right) ,{y}_{e}}\right) }\right) }\right) , \tag{4}
$$

where ${f}_{c}$ denotes the classifier, ${g}_{e}\left( {{f}_{b}\left( x\right) }\right)$ represent the emotion features, ${C}_{i}$ are the confounders, ad ${N}_{C}$ is the number of confounders. Ouyang et al. [19], propose a causal data augmentation approach to single-source domain generalization problem, where training data is only available from one source domain. The authors propose that the performance deterioration under domain shift may arise due to shifted domain-dependent features or shifted-correlation effect which is induced due to the presence of confounders. To deal with this problem, the authors propose to utilize causal intervention to augment the data and improve the robustness and generalization of the model. The proposed model consist of two parts: (1) global intensity non-linear augmentation (GIN) technique that utilizes randomly-weighted shallow convolutional networks to transforms images while keeping the shapes invariant; (2) interventional pseudo-correlation augmentation (IPA) technique that removes the confounder via re-sampling appearances of confounded objects independently. To augment the data, the framework first applies GIN on the input images to get new appearances. Then the two GIN-augmented of the same image are blended via IPA in a spatially-variable manner. Mitrovic et al. [20] propose a novel self-supervised objective, Representation Learning via Invariant Causal Mechanisms (RELIC) based on a causal analysis of contranstive learning frameworks. To do so, the authors propose to model the data generation process similar to the causal graph presented in Fig 3 The graph indicates that the data is generated from content (causal) and style (non-causal) variables and that only the only content (causal) is informative of the downstream tasks (label prediction). Given the causal graph, the paper indicates that the optimal representation should be invariant predictor of proxy targets on correlated, not causally related features. Since none of the causal or correlational variables are known, the authors utilize data augmentations to simulate interventions on the styles (correlational) variables. Finally, the paper proposes a regularizer to enforce the invariance under data augmentations as follows:

其中 ${f}_{c}$ 表示分类器，${g}_{e}\left( {{f}_{b}\left( x\right) }\right)$ 表示情感特征，${C}_{i}$ 是混杂因素，${N}_{C}$ 是混杂因素的数量。欧阳等人 [19] 针对单源领域泛化问题提出了一种因果数据增强方法，在该问题中，训练数据仅来自一个源领域。作者提出，领域偏移下的性能下降可能是由于领域相关特征的偏移或由混杂因素导致的偏移相关效应引起的。为了解决这个问题，作者提议利用因果干预来增强数据，提高模型的鲁棒性和泛化能力。所提出的模型由两部分组成:(1)全局强度非线性增强(GIN)技术，该技术利用随机加权的浅层卷积网络在保持图像形状不变的情况下对图像进行变换；(2)干预伪相关增强(IPA)技术，该技术通过独立重新采样混杂对象的外观来去除混杂因素。为了增强数据，该框架首先对输入图像应用 GIN 以获得新的外观。然后，通过 IPA 以空间可变的方式将同一图像的两个 GIN 增强版本进行融合。米特罗维奇等人 [20] 基于对比学习框架的因果分析，提出了一种新颖的自监督目标，即通过不变因果机制进行表征学习(RELIC)。为此，作者提议对数据生成过程进行建模，类似于图 3 中呈现的因果图。该图表明，数据是从内容(因果)和风格(非因果)变量生成的，并且只有内容(因果)变量对下游任务(标签预测)有信息价值。给定因果图，论文指出，最优表征应该是相关但非因果相关特征上代理目标的不变预测器。由于因果变量和相关变量均未知，作者利用数据增强来模拟对风格(相关)变量的干预。最后，论文提出了一个正则化器，以如下方式强制数据增强下的不变性:

$$
\min {\mathbb{E}}_{X \sim  p\left( X\right) }{\mathbb{E}}_{{a}_{lk},{a}_{qt} \sim  \mathcal{A} \times  \mathcal{A}}\mathop{\sum }\limits_{{b \in  \left\{  {{a}_{lk},{a}_{qt}}\right\}  }}{\mathcal{L}}_{b}\left( {{Y}^{R}, f\left( X\right) }\right)  \tag{5}
$$

$$
\text{s.t.}{KL}\left( {{p}^{\operatorname{do}\left( {a}_{lk}\right) }\left( {{Y}^{R} \mid  f\left( X\right) }\right) ,{p}^{\operatorname{do}\left( {a}_{qt}\right) }\left( {{Y}^{R} \mid  f\left( X\right) }\right) }\right)  \leq  \rho \text{,}
$$

where $\mathcal{A} = \left\{  {{a}_{1},\ldots ,{a}_{m}}\right\}$ is a set of data augmentations generated by intervening on the style variables, $\mathcal{L}$ is the proxy task loss and KL is the Kullback-Leibler (KL) divergence. This KL-divergence based regularizer enforces that the prediction of the proxy targets is invariant across data augmentations.

其中 $\mathcal{A} = \left\{  {{a}_{1},\ldots ,{a}_{m}}\right\}$ 是通过对风格变量进行干预生成的数据增强集合，$\mathcal{L}$ 是代理任务损失，KL 是库尔贝克 - 莱布勒(KL)散度。这个基于 KL 散度的正则化器强制要求代理目标的预测在数据增强过程中保持不变。

#### 2.1.2 Gradient-based Data Augmentation

#### 2.1.2 基于梯度的数据增强

Bai et al. [21] argue that many domain generalization methods work well for one dataset but perform poorly for others. They claim this happens because the domain generalization problems have multiple dimensions - correlation shift and diversity shift. Correlation shift is when the labels and the environments are correlated, and the relations change across different environments. Diversity shift means the data comes from different domains, thus having significantly different styles. For instance, the sketch of a horse, a cartoon horse, an image of a horse, and an art of a horse all represent horses in different styles. Furthermore, real-world data exists, which is a mixture of these shifts. To handle these dimensions simultaneously, they propose a novel decomposed feature representation and semantic augmentation approach. First, the proposed method decomposes the representations of the input image into context and category features. Then, they perform gradient-based semantic augmentation on context features, representing attributes, styles, and more; to disentangle the spurious correlation between features. The semantic data augmentation is performed by adversarially perturbing the feature space of the context related features of the original sample as follows:

白等人 [21] 认为，许多领域泛化方法在一个数据集上效果良好，但在其他数据集上表现不佳。他们声称，这种情况的发生是因为领域泛化问题具有多个维度——相关性偏移和多样性偏移。相关性偏移是指标签和环境之间存在相关性，并且这种关系在不同环境中会发生变化。多样性偏移意味着数据来自不同的领域，因此具有显著不同的风格。例如，一匹马的素描、一匹卡通马、一张马的图像和一幅马的艺术作品都以不同的风格表现马。此外，现实世界中的数据是这些偏移的混合。为了同时处理这些维度，他们提出了一种新颖的分解特征表示和语义增强方法。首先，所提出的方法将输入图像的表示分解为上下文特征和类别特征。然后，他们对上下文特征进行基于梯度的语义增强，上下文特征代表属性、风格等；以解开特征之间的虚假相关性。语义数据增强是通过对抗性地扰动原始样本上下文相关特征的特征空间来实现的，如下所示:

$$
{z}_{i}^{c} = {z}_{i}^{c} + {\alpha }_{i} \cdot  \epsilon  \cdot  \frac{{\nabla }_{{z}_{i}^{c}}\left( {l\left( {h}_{{\theta }_{c}}\right) \left( {{z}_{i}^{c},{c}_{i}}\right) }\right) )}{\begin{Vmatrix}{\nabla }_{{z}_{i}^{c}}\left( l\left( {h}_{{\theta }_{c}}\right) \left( {z}_{i}^{c},{c}_{i}\right) \right) )\end{Vmatrix}}, \tag{6}
$$

where ${z}_{i}^{c}$ is the context feature representation, ${h}_{{\theta }_{c}}$ is the context feature discriminator, $\epsilon$ is a hyperparameter which controls the maximum length of the augmentation vectors, and ${\alpha }_{i}$ is randomly sampled from $\left\lbrack  {0,1}\right\rbrack$ . Unlike methods in the earlier category, this work does not aim to generate counterfactuals to improve generalization, rather they perform gradient based augmentation on disentangled context features to eliminate distribution shifts for various generalization tasks.

其中 ${z}_{i}^{c}$ 是上下文特征表示，${h}_{{\theta }_{c}}$ 是上下文特征判别器，$\epsilon$ 是一个超参数，用于控制增强向量的最大长度，${\alpha }_{i}$ 是从 $\left\lbrack  {0,1}\right\rbrack$ 中随机采样得到的。与前面类别中的方法不同，这项工作的目的不是生成反事实来提高泛化能力，而是对解纠缠的上下文特征进行基于梯度的增强，以消除各种泛化任务中的分布偏移。

![0195d14d-089f-77d1-a441-1daf38e81816_6_545_200_707_316_0.jpg](images/0195d14d-089f-77d1-a441-1daf38e81816_6_545_200_707_316_0.jpg)

Figure 4: The data generating process as shown in [22]. As per the authors, the input $X$ is generated by a collection of unobserved factors (such as texture, object, shape, and so on). Only $Y, X$ , and possibly the confounders are observed during training time. $Y$ represents the variable that needs to be predicted. The generative factors are assumed to not have any causal relation among themselves. This work also assumes that the label and the confounders have an effect on the generative factors. $S$ represents the style variables.

图4:如文献[22]所示的数据生成过程。根据作者的说法，输入$X$由一组未观察到的因素(如纹理、物体、形状等)生成。在训练时，仅观察到$Y, X$，可能还有混杂因素。$Y$表示需要预测的变量。假设生成因素之间不存在任何因果关系。这项工作还假设标签和混杂因素会对生成因素产生影响。$S$表示风格变量。

### 2.2 Invariance via Learning Causal Representations

### 2.2 通过学习因果表示实现不变性

Causal DG methods aim to capture invariance with the aid of causal theories. Majority of these methods aim at learning a causal representation of the data that is highly predictive of the downstream task. For instance, consider the task of digit classification as discussed in the Introduction. Despite applying various transformations to the digits,(such as rotating the digits, coloring the digits, and so on) humans are still able to correctly associate digits with the labels. This phenomenon could be attributed to the fact that humans utilize the features that do not change during these transformations such as the shape of the digit. Thus, these features can be considered causal. However, learning these representations is not straightforward as these features are not directly observable making it challenging to guide the machine. One possible way to guide the model to rely on causal representations is with the aid of disentanglement. The range of works that consider disentanglement can be further divided into two parts namely, works that consider disentanglement with no causal interactions among the latent factors, and works that consider disentanglement with causal interactions among the latent factors. In this section we discuss these different categories.

因果数据生成(Causal DG)方法旨在借助因果理论来捕捉不变性。这些方法中的大多数旨在学习对下游任务具有高度预测性的数据因果表示。例如，考虑引言中讨论的数字分类任务。尽管对数字应用了各种变换(如旋转数字、给数字上色等)，人类仍然能够正确地将数字与标签关联起来。这种现象可以归因于人类利用了在这些变换过程中不发生变化的特征，如数字的形状。因此，这些特征可以被视为因果特征。然而，学习这些表示并非易事，因为这些特征无法直接观察到，这给引导机器带来了挑战。引导模型依赖因果表示的一种可能方法是借助解纠缠。考虑解纠缠的一系列工作可以进一步分为两部分，即考虑潜在因素之间无因果交互的解纠缠工作，以及考虑潜在因素之间有因果交互的解纠缠工作。在本节中，我们将讨论这些不同的类别。

#### 2.2.1 Disentanglement Assuming No Causal Interactions Among the Latent Factors

#### 2.2.1 假设潜在因素之间无因果交互的解纠缠

This section discusses the works that assume the latent factors (i.e. the causal and non-causal factors) bare no causal interactions amongst each other. Majority of the papers utilize a simple causal graph as seen in Fig. 3. The input features are divided into causal and non-causal features.

本节讨论假设潜在因素(即因果因素和非因果因素)之间不存在因果交互的工作。大多数论文使用如图3所示的简单因果图。输入特征被分为因果特征和非因果特征。

## Disentanglement when Auxiliary Variables are Available

## 存在辅助变量时的解纠缠

A range of variables utilize auxiliary variables to aid the disentanglement process. For instance, in the task of image classification, auxiliary variables could be additional cues about the object, or they could be background variables indicating the image background. Thus, auxiliary variables can aid in distinguishing causal and non-causal features. The authors in [13, 23, 24] aim to utilize auxiliary variables to separate causal from non-causal features, and learn the representations accordingly. For example, in grouped observations for certain datasets the same object (ID) is seen under multiple situations [23], which can guide the prediction to be based more on the latent core (causal) characteristics and less on the latent style (non-causal) features by penalizing between-object variance of the prediction less than variation for the same object. The authors of [23] contend that direct interventions on style elements frequently result in the creation of a new domain. So, if ${F}_{0}$ represents the joint distribution of the $\left( {{ID}, Y,{X}^{\text{style }}}\right)$ in the training distribution, then intervening on ${X}^{\text{style }}$ yields a new joint distribution of the (ID, $Y,{\widetilde{X}}^{\text{style }}$ ) indicated by $F$ . As a result, we obtain the following class of distributions:

一系列变量利用辅助变量来辅助解纠缠过程。例如，在图像分类任务中，辅助变量可以是关于物体的额外线索，也可以是指示图像背景的背景变量。因此，辅助变量有助于区分因果特征和非因果特征。文献[13, 23, 24]的作者旨在利用辅助变量将因果特征与非因果特征分离，并相应地学习表示。例如，在某些数据集的分组观测中，同一物体(ID)在多种情况下被观察到[23]，通过对不同物体预测的方差惩罚小于同一物体的方差惩罚，可以引导预测更多地基于潜在核心(因果)特征，而较少地基于潜在风格(非因果)特征。文献[23]的作者认为，对风格元素的直接干预通常会导致创建一个新的领域。因此，如果${F}_{0}$表示训练分布中$\left( {{ID}, Y,{X}^{\text{style }}}\right)$的联合分布，那么对${X}^{\text{style }}$进行干预会产生由$F$表示的(ID, $Y,{\widetilde{X}}^{\text{style }}$)的新联合分布。因此，我们得到以下分布类:

$$
{\mathcal{F}}_{\xi } = \left\{  {F : {D}_{\text{style }}\left( {{F}_{0}, F}\right)  \leq  \xi }\right\}   \tag{7}
$$

where ${D}_{\text{style }}\left( {{F}_{0}, F}\right)$ is the distance between the two distributions. The primary goal is to optimize a worst-case loss over this distribution class. This loss can be formulated as,

其中${D}_{\text{style }}\left( {{F}_{0}, F}\right)$是两个分布之间的距离。主要目标是在这个分布类上优化最坏情况下的损失。这个损失可以表示为:

$$
{L}_{\xi }\left( \theta \right)  = \mathop{\sup }\limits_{{F \in  {\mathcal{F}}_{\xi }}}{E}_{F}\left\lbrack  {\ell \left( {Y,{f}_{\theta }\left( X\right) }\right) }\right\rbrack   \tag{8}
$$

For arbitrary strong interventions on the style features, the loss would be given by,

对于风格特征的任意强干预，损失将由下式给出:

$$
{L}_{\infty }\left( \theta \right)  = \mathop{\lim }\limits_{{\xi  \rightarrow  \infty }}\mathop{\sup }\limits_{{F \in  {\mathcal{F}}_{\xi }}}{E}_{F}\left\lbrack  {\ell \left( {Y,{f}_{\theta }\left( X\right) }\right) }\right\rbrack   \tag{9}
$$

![0195d14d-089f-77d1-a441-1daf38e81816_7_313_200_1182_321_0.jpg](images/0195d14d-089f-77d1-a441-1daf38e81816_7_313_200_1182_321_0.jpg)

Minimizing this loss guarantees an accurate prediction that performs well even for significant shifts in the conditional distribution of style features. Rather than pooling over all examples, CoRe [23] exploits the ID variable to penalize the loss function. The overall objective function is given by,

最小化这个损失可以保证即使在风格特征的条件分布发生显著变化时也能进行准确预测。与对所有示例进行汇总不同，CoRe [23]利用ID变量对损失函数进行惩罚。总体目标函数由下式给出:

$$
{\widehat{\theta }}^{\text{core }}\left( \lambda \right)  = {\operatorname{argmin}}_{\theta }\widehat{E}\left\lbrack  {\ell \left( {Y,{f}_{\theta }\left( X\right) }\right) }\right\rbrack   + \lambda  \cdot  {\widehat{C}}_{\theta } \tag{10}
$$

where ${\widehat{C}}_{\theta }$ is a conditional variance penalty of the form

其中${\widehat{C}}_{\theta }$是形式为

$$
{\widehat{C}}_{f,\nu ,\theta } \mathrel{\text{:=}} \widehat{E}\left\lbrack  {\widehat{\operatorname{Var}}{\left( {f}_{\theta }\left( X\right)  \mid  Y,\text{ ID }\right) }^{\nu }}\right\rbrack   \tag{11}
$$

for the conditional-variance-of-prediction, and

的预测条件方差惩罚，并且

$$
{\widehat{C}}_{\ell ,\nu ,\theta } \mathrel{\text{:=}} \widehat{E}\left\lbrack  {\widehat{\operatorname{Var}}{\left( \ell \left( Y,{f}_{\theta }\left( X\right) \right)  \mid  Y,\mathrm{{ID}}\right) }^{\nu }}\right\rbrack   \tag{12}
$$

for the conditional-variance-of-loss. ${f}_{\theta }\left( X\right)$ is the representation of the input $X, Y$ is the image label, ${ID}$ is the identifier label or the object label, and $\nu  \in  \{ 1/2,1\}$ . Mahajan et al. [13] argue that for representations, the class-conditional domain invariant objective is inadequate. They add to the CoRe framework by including an approach for when objects (ID variables) are not detected. When the stable feature distribution differs across domains, the class-conditional aim is insufficient to learn the stable features. To solve this issue, they use a causal graph to express within-class variance in stable features. The authors propose using the causal graph to learn the representation regardless of the classification loss. Liu et al. [25] claim that CoRe adds no new generative modeling efforts at the expense of limited capability for invariant causal processes They further contend that deep learning methods fail to generalize to unexplored domains because the representations they learnt blend semantic and stylistic information owing to false correlations. They propose using a causal generative model that follows a causal approach to describe the semantic and stylistic aspects independently to address these issues. Similar to CoRe, Makar et al. [26] suggest that identifying invariant characteristics is a tough undertaking since it is impossible to distinguish the effect of non-causal factors without extra supervision. Instead of ID labels, the authors recommend employing auxiliary labels (such as picture background labels) to provide information about the irrelevant component that is available during training but not during testing. The authors offer a method for using these auxiliary labels to build a predictor whose risk is roughly invariant over a well-defined range of test distributions.

关于损失的条件方差。${f}_{\theta }\left( X\right)$ 是输入的表示，$X, Y$ 是图像标签，${ID}$ 是标识符标签或对象标签，并且 $\nu  \in  \{ 1/2,1\}$。马哈詹(Mahajan)等人 [13] 认为，对于表示而言，类条件域不变目标是不充分的。他们通过纳入一种针对未检测到对象(ID 变量)情况的方法，对 CoRe 框架进行了扩展。当稳定特征分布在不同领域存在差异时，类条件目标不足以学习到稳定特征。为解决这一问题，他们使用因果图来表达稳定特征的类内方差。作者们提出使用因果图来学习表示，而不考虑分类损失。刘(Liu)等人 [25] 声称，CoRe 没有增加新的生成式建模工作，却以不变因果过程的能力有限为代价。他们进一步认为，深度学习方法无法推广到未探索的领域，因为它们学习到的表示由于虚假相关性而混合了语义和风格信息。他们提出使用一种遵循因果方法的因果生成模型，以独立描述语义和风格方面，从而解决这些问题。与 CoRe 类似，马卡尔(Makar)等人 [26] 指出，识别不变特征是一项艰巨的任务，因为在没有额外监督的情况下，无法区分非因果因素的影响。作者们建议使用辅助标签(如图像背景标签)来替代 ID 标签，以提供有关在训练期间可用但在测试期间不可用的无关组件的信息。作者们提供了一种使用这些辅助标签构建预测器的方法，该预测器的风险在明确定义的测试分布范围内大致不变。

Neet et al. [27] argue that causality-aware domain generalization frameworks impose regularization constraints to learn the invariance. However, when datasets with multi-attribute shifts are considered, deciding which regularization could lead to learning the invariance is difficult. To overcome this problem, the authors propose Causally Adaptive Constraint Minimization (CACM). CACM, leverage the information provided by multiple independent shifts across attributes, assuming structural knowledge of the shifts. By identifying the correct constraints, CACM applies them as regularizers in the overall objective function. Moreover, the attributes correlate with the label that can change between train and test data. The model aims to learn a risk-invariant predictor that obtains minimum risk on all distributions. Mathematically,

尼特(Neet)等人 [27] 认为，具有因果意识的领域泛化框架会施加正则化约束来学习不变性。然而，当考虑具有多属性偏移的数据集时，很难确定哪种正则化可以导致学习到不变性。为克服这个问题，作者们提出了因果自适应约束最小化(Causally Adaptive Constraint Minimization，CACM)方法。CACM 利用跨属性的多个独立偏移所提供的信息，并假设这些偏移具有结构知识。通过识别正确的约束，CACM 将它们作为正则化项应用于总体目标函数中。此外，属性与标签相关，而标签在训练数据和测试数据之间可能会发生变化。该模型旨在学习一个风险不变的预测器，使其在所有分布上获得最小风险。从数学角度来看，

$$
{g}_{\text{rinv }} \in  \arg \mathop{\min }\limits_{{g \in  {G}_{\text{rinv }}}}{R}_{P}\left( g\right) \forall P \in  \mathcal{P} \tag{13}
$$

$$
\text{where}{G}_{\text{rinv }} = \left\{  {g : {R}_{P}\left( g\right)  = {R}_{{P}^{\prime }}\left( g\right) \forall P,{P}^{\prime } \in  \mathcal{P}}\right\}  \text{,}
$$

where $R$ is the risk of predictor $g$ , and $\mathcal{P}$ represents all the distributions. The authors divide the auxiliary attributes $A$ into three types of attributes ${\mathbf{A}}_{\overline{ind}}$ , which represents the attributes that are correlated with the label, ${\mathbf{A}}_{\text{ind }}$ , the attributes that are independent of the label and $E$ denotes the domain. The shifts are based on the relationship between the auxiliary attributes $A$ and the label $Y$ . Based on these distinctions of attributes, the authors define four kinds of shifts that are possible based on the causal graph. They are Independent, Causal, Confounded, and Selected. First, the authors identify the conditional independence constraints satisfied by the causal features and enforce that learned representation $\phi$ should follow the same constraint. The authors leverage the d-seperation [28] strategy and first, for every observed variable $V \in  \mathcal{V}$ in the graph, check whether $\left( {{\mathbf{X}}_{c}, V}\right)$ are d-separated. If not, check whether $\left( {{\mathbf{X}}_{c}, V}\right)$ are d-separated conditioned on any subset of the remaining observed variables in $\mathcal{V} \smallsetminus  \{ V\}$ . Finally, the model applies those constraints as a regularizer to the standard ERM loss. Thus, the final objective function is formulated as,

其中 $R$ 是预测器 $g$ 的风险，$\mathcal{P}$ 表示所有分布。作者们将辅助属性 $A$ 分为三种类型的属性 ${\mathbf{A}}_{\overline{ind}}$，它表示与标签相关的属性；${\mathbf{A}}_{\text{ind }}$，表示与标签无关的属性；$E$ 表示领域。偏移是基于辅助属性 $A$ 和标签 $Y$ 之间的关系。基于这些属性的区分，作者们根据因果图定义了四种可能的偏移类型，即独立偏移、因果偏移、混杂偏移和选择偏移。首先，作者们确定因果特征所满足的条件独立约束，并强制要求学习到的表示 $\phi$ 应遵循相同的约束。作者们利用 d - 分离 [28] 策略，首先，对于图中的每个观测变量 $V \in  \mathcal{V}$，检查 $\left( {{\mathbf{X}}_{c}, V}\right)$ 是否是 d - 分离的。如果不是，则检查 $\left( {{\mathbf{X}}_{c}, V}\right)$ 在 $\mathcal{V} \smallsetminus  \{ V\}$ 中其余观测变量的任何子集的条件下是否是 d - 分离的。最后，该模型将这些约束作为正则化项应用于标准经验风险最小化(ERM)损失。因此，最终的目标函数被表述为

$$
{g}_{1},\phi  = \arg \mathop{\min }\limits_{{{g}_{1},\phi }};\;\ell \left( {{g}_{1}\left( {\phi \left( \mathbf{x}\right) }\right) , y}\right)  + {\lambda }^{ * }\left( \text{ RegPenalty }\right) , \tag{14}
$$

where $\ell$ is the classification loss, $\lambda$ is a hyperparameter, and RegPenalty is the regularization penalty. The penalty depends on the type of distribution shift for each attribute.

其中 $\ell$ 是分类损失，$\lambda$ 是超参数，RegPenalty 是正则化惩罚项。该惩罚项取决于每个属性的分布偏移类型。

## Disentanglement when Auxiliary Variables are Unavailable

## 辅助变量不可用时的解纠缠

Although auxiliary variables can aid with causal disentanglement, these variables are not always easily available. A series of work aim to tackle the causal disentanglement problem in the absence of auxiliary variables [22, 27, 29, 30]. Chevalley et al. [22] argue that the invariant representations are reformulated as a feature of a causal process, and propose a regularizer that guarantees invariance via distribution matching. The proposed framework, in particular, describes the underlying generation process using the DAG shown in Fig. 4 Different domains are then represented in the provided DAG via soft-intervention on the domain variable. The invariant representations are therefore characterized as those that have no complete causal influence on the domain variable. The classification is formulated as:

尽管辅助变量有助于进行因果解缠，但这些变量并非总是容易获取。一系列研究旨在解决在没有辅助变量的情况下的因果解缠问题 [22, 27, 29, 30]。Chevalley 等人 [22] 认为，不变表示可以重新表述为因果过程的一个特征，并提出了一种通过分布匹配来保证不变性的正则化方法。具体而言，所提出的框架使用图 4 所示的有向无环图(DAG)来描述潜在的生成过程。然后，通过对领域变量进行软干预，在给定的有向无环图中表示不同的领域。因此，不变表示的特征是对领域变量没有完全因果影响的那些表示。分类问题可表述为:

$$
\mathop{\min }\limits_{{Z = f\left( X\right) }}\mathcal{L}\left( {Y, c\left( Z\right) }\right)  \tag{15}
$$

$$
\text{s.t.}{\mathbb{E}}_{{N}_{d},{N}_{d}^{\prime }}\left\lbrack  {\operatorname{dist}\left( {p}^{\operatorname{do}\left( {d = {N}_{d}}\right) \left( Z\right) ,{p}^{\operatorname{do}\left( {d = {N}_{d}^{\prime }}\right) \left( Z\right) }}\right) }\right\rbrack  \text{,}
$$

where $Z$ is the learned representation and dist denotes the distance between the distributions and ${N}_{d},{N}_{d}^{\prime }$ are the interventions on the domain variable. One way to disentangle causal and non-causal features in the presence of multiple domains, but the absence of auxiliary variables would be to utilize contrastive learning. The primary assumption under this setting is that the non-causal feature representations are similar for instances from the same domain. Thus, by guiding the machine learning model to learn non-causal representations, we can learn causal representations by learning orthogonal representations to the non-causal representations. In this setting, the objective function is usually represented as,

其中 $Z$ 是学习到的表示，dist 表示分布之间的距离，${N}_{d},{N}_{d}^{\prime }$ 是对领域变量的干预。在存在多个领域但没有辅助变量的情况下，解缠因果特征和非因果特征的一种方法是利用对比学习。在这种情况下的主要假设是，来自同一领域的实例的非因果特征表示是相似的。因此，通过引导机器学习模型学习非因果表示，我们可以通过学习与非因果表示正交的表示来学习因果表示。在这种情况下，目标函数通常表示为:

$$
\mathcal{L} = {\mathcal{L}}^{cls} + {\mathcal{L}}^{con} \tag{16}
$$

where ${\mathcal{L}}^{cls}$ represent the classification loss, and ${\mathcal{L}}^{con}$ represents the contrastive loss. ${\mathcal{L}}^{cls}$ is formulated similar to Eq. 8 as it aims to predict the image label using the representation of the causal factors. ${\mathcal{L}}^{\text{con }}$ is formulated as,

其中 ${\mathcal{L}}^{cls}$ 表示分类损失，${\mathcal{L}}^{con}$ 表示对比损失。${\mathcal{L}}^{cls}$ 的公式与公式 8 类似，因为它旨在使用因果因素的表示来预测图像标签。${\mathcal{L}}^{\text{con }}$ 的公式为:

$$
{\mathcal{L}}_{i, j}^{con} =  - \log \frac{\exp \left( {\operatorname{sim}\left( {{z}_{i},{z}_{j}}\right) /\tau }\right) }{\mathop{\sum }\limits_{{k = 1}}^{{2N}}\exp \left( {\operatorname{sim}\left( {{z}_{i},{z}_{k}}\right) /\tau }\right) } \tag{17}
$$

where $\tau$ is the temperature normalization factor, and $\operatorname{sim}$ is the similarity function. The intuition here is that we want the similar representations ${z}_{i}$ and ${zj}$ to be close to each other, and the dissimilar representations ${z}_{i}$ and ${z}_{k}$ to be more distant from each other. Recent works, including [24, 29] leverage this assumption to identify the causal features. Chen et al. [29] Concentrate on utilizing both semantic (causal) and stylistic (non-causal) characteristics. This paper's primary hypothesis is that instances from the same domain should exchange style information. This aids in the efficient disentanglement of style features, easing the search for actual semantic features with a low degree of freedom. Following the acquisition of style data, the network learns semantic information in orthogonal directions to the domain style. As a result, the network avoids overfitting style cues and instead concentrates on learning semantic elements. On the other hand, Trivedi et al. [24] claim that standard domain generalization methods are inapplicable to computer games because games are more than just graphics, gaming images include functional qualities related with the game genre as well as aesthetic features unique to each game. As a result, representations derived from a pre-trained model perform well on the game on which it was trained, resulting in poor generalization. To overcome this issue, the authors recommend using contrastive learning. The authors use the causal graph to distinguish between content and stylistic aspects, stating that the game genre is defined by the content elements.

其中 $\tau$ 是温度归一化因子，$\operatorname{sim}$ 是相似度函数。这里的直觉是，我们希望相似的表示 ${z}_{i}$ 和 ${zj}$ 彼此接近，而不相似的表示 ${z}_{i}$ 和 ${z}_{k}$ 彼此远离。最近的研究，包括 [24, 29]，利用这一假设来识别因果特征。Chen 等人 [29] 专注于同时利用语义(因果)和风格(非因果)特征。本文的主要假设是，来自同一领域的实例应该交换风格信息。这有助于有效地解缠风格特征，从而更容易寻找自由度较低的实际语义特征。在获取风格数据之后，网络在与领域风格正交的方向上学习语义信息。因此，网络避免了对风格线索的过拟合，而是专注于学习语义元素。另一方面，Trivedi 等人 [24] 声称，标准的领域泛化方法不适用于计算机游戏，因为游戏不仅仅是图形，游戏图像还包括与游戏类型相关的功能特征以及每个游戏独有的美学特征。因此，从预训练模型中得到的表示在其训练的游戏上表现良好，但泛化能力较差。为了克服这个问题，作者建议使用对比学习。作者使用因果图来区分内容和风格方面，指出游戏类型是由内容元素定义的。

The ways mentioned earlier are helpful for the traditional machine learning setting. However, in an online learning scenario, where an agent continually learns as it interacts with the world, it is more challenging to identify the causal features. To tackle this problem, Javed et al. [30] propose a framework for detecting and removing spurious features on a continuous basis. The framework's basic premise is that the association between a false characteristic and the goal is not continuous over time. The authors also contend that in order to infer a causal model from observable data, an agent must go through three phases. First, the agent must understand the basic data representations. Second, the agent must deduce the causal relationships between the variables. Finally, in order to generate correct predictions, the agent must grasp the interplay between these factors.

前面提到的方法对传统机器学习场景很有帮助。然而，在在线学习场景中，智能体在与环境交互的过程中持续学习，识别因果特征则更具挑战性。为了解决这个问题，Javed 等人 [30] 提出了一个持续检测和去除虚假特征的框架。该框架的基本前提是，虚假特征与目标之间的关联在时间上不是连续的。作者还认为，为了从可观测数据中推断出因果模型，智能体必须经历三个阶段。首先，智能体必须理解基本的数据表示。其次，智能体必须推断变量之间的因果关系。最后，为了做出正确的预测，智能体必须掌握这些因素之间的相互作用。

#### 2.2.2 Disentanglement Assuming Causal Interactions Among the Latent Factors

#### 2.2.2 假设潜在因素之间存在因果交互的解缠

This section discusses the works that assume the latent factors (i.e. the causal and non-causal factors) have a causal interaction amongst each other. Majority of the works assume the non-causal features to act as confounding factors and aim to leverage front-door or back-door criterion to mitigate confounding bias and improve generalization. There also exist works that aim to learn the nature of the relationships among the latent factors. For instance, Yang et al. [31] suggest that when it comes to disentangling the generative elements of observational data, the bulk of frameworks presume that the latent factors are independent of one another. However, in practice, this assumption may not hold true. To solve this issue, they offer CausalVAE, a new framework. CausalVAE employs a Structural Causal Model layer that enables the model to recover latent components with semantics and structure using a Directed Acyclic Graph (DAG). First, the input $x$ is encoded to get the independent components $z$ . The collected factors are subsequently processed by the Structural Causal Model (SCM) layer, which converts independent factors into causal endogenous ones. Finally, a masking method is employed to replicate the assignment operation of SCMs by propagating the influence of parental variables on their children. Then the representation of the latent exogenous independent variables can be written as,

本节讨论了假设潜在因素(即因果因素和非因果因素)之间存在因果相互作用的研究。大多数研究假设非因果特征充当混杂因素，并旨在利用前门准则或后门准则来减轻混杂偏差并提高泛化能力。也有一些研究旨在了解潜在因素之间关系的性质。例如，Yang等人[31]指出，在解开观测数据的生成元素时，大多数框架假定潜在因素彼此独立。然而，在实践中，这一假设可能并不成立。为了解决这个问题，他们提出了一种新的框架CausalVAE。CausalVAE采用了一个结构因果模型层，该层使模型能够使用有向无环图(DAG)恢复具有语义和结构的潜在成分。首先，对输入$x$进行编码以获得独立成分$z$。收集到的因素随后由结构因果模型(SCM)层进行处理，该层将独立因素转换为因果内生因素。最后，采用一种掩码方法，通过传播父变量对其子变量的影响来复制结构因果模型的赋值操作。然后，潜在外生独立变量的表示可以写成:

$$
\epsilon  = h\left( {x, u}\right)  + \zeta  \tag{18}
$$

where $\zeta$ is the independent noise term. After obtaining $\epsilon$ , the causal representation is obtained as a linear SCM,

其中$\zeta$是独立噪声项。获得$\epsilon$后，因果表示可以通过线性结构因果模型得到:

$$
\mathbf{z} = {\mathbf{A}}^{T}\mathbf{z} + \epsilon  = {\left( I - {\mathbf{A}}^{T}\right) }^{-1}\epsilon  \tag{19}
$$

where $\mathbf{A}$ represents the adjacency matrix of the causal graph, where ${\mathbf{A}}_{i} \in  {\mathbb{R}}^{n}$ is the weight vector such that ${\mathbf{A}}_{ji}$ encodes the causal strength from ${z}_{j}$ and ${z}_{i}$ , and $I$ is an identity matrix. Finally, the causal representations undergo a masking mechanism. This step resembles an SCM, which depicts how children are generated by their corresponding parental variables. The masking mechanism is formulated as,

其中$\mathbf{A}$表示因果图的邻接矩阵，${\mathbf{A}}_{i} \in  {\mathbb{R}}^{n}$是权重向量，使得${\mathbf{A}}_{ji}$编码了从${z}_{j}$到${z}_{i}$的因果强度，$I$是单位矩阵。最后，因果表示经过一个掩码机制。这一步类似于结构因果模型，它描述了子变量是如何由其对应的父变量生成的。掩码机制的公式为:

$$
{z}_{i} = {g}_{i}\left( {{\mathbf{A}}_{i} \circ  \mathbf{Z};{\mathbf{\eta }}_{i}}\right)  + {\epsilon }_{i} \tag{20}
$$

where $\circ$ represents the element-wise multiplication, ${\mathbf{\eta }}_{i}$ is a parameter of the nonlinear function ${g}_{i}$ . The final loss function consists of multiple terms, including the ELBO loss for VAE [32] and different constraints to ensure the latent variables $\mathbf{A}$ and $z$ are identifiable.

其中$\circ$表示逐元素相乘，${\mathbf{\eta }}_{i}$是非线性函数${g}_{i}$的一个参数。最终的损失函数由多个项组成，包括变分自编码器(VAE)的证据下界(ELBO)损失[32]以及确保潜在变量$\mathbf{A}$和$z$可识别的不同约束条件。

## Mitigating Confounding Bias via Backdoor Adjustments

## 通过后门调整减轻混杂偏差

The backdoor adjustment aids in approximating the interventional distribution, which can guide in identifying the causal link between the causal features and the image label. Let ${CS}$ denote the representation of the causal features, $S$ denote the representation of the non-causal features, and $Y$ denote the image label. The causal-graph under this scenario can be visualized as shown in Fig 5a Similar to Eq 1, the backdoor adjustment can be formulated as,

后门调整有助于近似干预分布，这可以指导识别因果特征和图像标签之间的因果联系。设${CS}$表示因果特征的表示，$S$表示非因果特征的表示，$Y$表示图像标签。在这种情况下的因果图可以如图5a所示进行可视化。与公式1类似，后门调整可以表示为:

$$
P\left( {Y \mid  {do}\left( {S = {s}_{k}}\right) }\right)  = \mathop{\sum }\limits_{{i = 1}}^{\left| CS\right| }P\left( {Y \mid  S = {s}_{k},{CS} = {c}_{i}}\right) P\left( {{CS} = {c}_{i}}\right)  \tag{21}
$$

Zhang et al. [33] aim to utilize the causal graph to shed light on the poor generalization of classic person re-identification models when applied to unknown contexts. The primary premise of this research is that person pictures are influenced by two sets of latent random variables, namely identity-specific and domain-specific aspects. The authors propose Multi-Domain Disentangled Adversarial Neural Networks (MDANN), which learn two encoders from various datasets for embedding identity-specific (causal) and domain-specific (non-causal) components. To eliminate domain (identity) relevant information from embedded identity (domain) specific representations, the adversarial learning principle is used. Then, as shown in Eq. 21, a backdoor adjustment block (BA) is presented, which uses the identity-specific and domain-specific representations to achieve the approximation. The objective function is a combination of the backdoor adjustment and the classification loss.

Zhang等人[33]旨在利用因果图来解释经典行人重识别模型在应用于未知场景时泛化能力较差的问题。这项研究的主要前提是，行人图片受到两组潜在随机变量的影响，即特定身份和特定领域的因素。作者提出了多领域解纠缠对抗神经网络(MDANN)，该网络从不同的数据集中学习两个编码器，用于嵌入特定身份(因果)和特定领域(非因果)的成分。为了从嵌入的特定身份(领域)表示中消除与领域(身份)相关的信息，使用了对抗学习原则。然后，如公式21所示，提出了一个后门调整块(BA)，它使用特定身份和特定领域的表示来实现近似。目标函数是后门调整和分类损失的组合。

Simiarly, Deng et al. [34] Attempt to use causality to enhance knowledge distillation among teacher-student models in order to improve generalizability. The authors create a causal graph to represent the causal linkages between the pre-trained instructor, the samples, and the prediction. To eliminate biased knowledge based on backdoor adjustment, the model employs the softened logits learnt by the teacher as the context information of an image. Overall, the proposed methodology captures full teacher representations while removing bias through causal intervention. Wang et al. [35] present a causal attention model capable of distinguishing between causal and confounding picture aspects. The authors use backdoor adjustment to accomplish disentanglement of the causative and confounding aspects. To address the over-adjustment problem, they create data splits repeatedly and gradually self-annotate the confounders.

类似地，Deng等人[34]试图利用因果关系来增强师生模型之间的知识蒸馏，以提高泛化能力。作者创建了一个因果图来表示预训练教师、样本和预测之间的因果联系。为了基于后门调整消除有偏知识，该模型使用教师学习到的软化逻辑作为图像的上下文信息。总体而言，所提出的方法在通过因果干预消除偏差的同时，捕获了完整的教师表示。Wang等人[35]提出了一种能够区分因果和混杂图像方面的因果注意力模型。作者使用后门调整来实现因果和混杂方面的解纠缠。为了解决过度调整的问题，他们反复创建数据分割并逐步对混杂因素进行自标注。

## Mitigating Confounding Bias via Front-Door Adjustments

## 通过前门调整减轻混杂偏差

When the spurious features or confounders are unidentifiable or their distributions are hard to model, then one can use the front-door adjustment as it does not require explicitly modeling for the confounders. By introducing an intermediate variable $Z$ between the input $X$ and output $Y$ , the front-door criterion transfers the requirement of modeling the intervening effects of confounders to modeling the intervening effects of the input. The motivation for this is clear if we consider a two state intervention. If we set the value of $X$ , we can determine the corresponding value of $Z$ , and we can then intervene again to fix that value of $Z$ . By doing this for every value of $Z$ we are able to determine the effect of $X$ on $Y$ . The causal-graph under this scenario can be visualized as shown in Fig 5b The front-door criterion can be formulated as shown in Eq. 2, where ${x}^{\prime }$ denotes the set of training data. By leveraging the front-door criterion, Li et al. [36] present an approach for mitigating confounding bias in the absence of identifying the confounders The proposed technique simulates the interventions among various samples using the front-door criteria and then optimizes the global-scope intervening impact on the instance-level interventions. Unlike previous studies, this is the first effort to use the front-door criteria for learning causal visual cues by taking the intervention among samples into account.

当虚假特征或混杂因素无法识别，或者其分布难以建模时，可以使用前门调整方法，因为该方法不需要对混杂因素进行显式建模。通过在输入 $X$ 和输出 $Y$ 之间引入一个中间变量 $Z$，前门准则将对混杂因素干预效应进行建模的要求转化为对输入干预效应进行建模。如果考虑一个双状态干预，这样做的动机就很明确了。如果我们设定 $X$ 的值，就可以确定 $Z$ 的相应值，然后我们可以再次进行干预以固定 $Z$ 的该值。通过对 $Z$ 的每个值都进行这样的操作，我们就能确定 $X$ 对 $Y$ 的影响。这种情况下的因果图可以如图 5b 所示进行可视化。前门准则可以用公式 2 表示，其中 ${x}^{\prime }$ 表示训练数据集。通过利用前门准则，Li 等人 [36] 提出了一种在无法识别混杂因素的情况下减轻混杂偏差的方法。所提出的技术使用前门准则模拟各种样本之间的干预，然后优化全局范围的干预对实例级干预的影响。与以往的研究不同，这是首次尝试通过考虑样本间的干预，利用前门准则来学习因果视觉线索。

### 2.3 Invariance via Learning/Transfering Causal Mechanisms

### 2.3 通过学习/迁移因果机制实现不变性

These papers train mechanisms (such as neural networks) invariant across different domains. The conditionals in these cases remain invariant. These frameworks impose that the invariance of conditionals is valid as long as the conditionals represent the causal mechanisms. Formally, given $\mathbf{X}$ as the input, $Y$ as the label and ${S}^{ * }$ as the subset of invariant predictors, the conditional distribution $P\left( {{Y}^{k} \mid  {\mathbf{X}}_{{S}^{ * }}^{k}}\right)$ is invariant across the $k$ domains.

这些论文训练在不同领域间保持不变的机制(如神经网络)。在这些情况下，条件概率保持不变。这些框架规定，只要条件概率代表因果机制，条件概率的不变性就是有效的。形式上，给定 $\mathbf{X}$ 作为输入，$Y$ 作为标签，${S}^{ * }$ 作为不变预测因子的子集，条件分布 $P\left( {{Y}^{k} \mid  {\mathbf{X}}_{{S}^{ * }}^{k}}\right)$ 在 $k$ 个领域间是不变的。

#### 2.3.1 IRM and its Extensions

#### 2.3.1 不变风险最小化(IRM)及其扩展

When the training data originates from multiple domains, dividing the features into causal and non-causal features becomes challenging. One of the pioneering works - Invariant Risk Minimization (IRM) [4], was the first to address this problem. The authors propose to find a data representation such that a classifier trained on top of that representation matches for all domains. If the training data ${D}_{d} \mathrel{\text{:=}} {\left\{  \left( {x}_{i}^{d},{y}_{i}^{d}\right) \right\}  }_{i = 1}^{{n}_{d}}$ is collected under multiple domains $d \in  {\mathcal{E}}_{\text{tr }}$ . Then, to achieve high generalizability, the model should minimize the following loss,

当训练数据来自多个领域时，将特征划分为因果特征和非因果特征变得具有挑战性。开创性工作之一——不变风险最小化(Invariant Risk Minimization，IRM)[4] 首次解决了这个问题。作者提议寻找一种数据表示，使得基于该表示训练的分类器在所有领域都适用。如果训练数据 ${D}_{d} \mathrel{\text{:=}} {\left\{  \left( {x}_{i}^{d},{y}_{i}^{d}\right) \right\}  }_{i = 1}^{{n}_{d}}$ 是在多个领域 $d \in  {\mathcal{E}}_{\text{tr }}$ 下收集的。那么，为了实现高泛化性，模型应最小化以下损失:

$$
{R}^{\mathrm{{OOD}}}\left( f\right)  = \mathop{\max }\limits_{{e \in  {\mathcal{E}}_{\text{all }}}}{R}^{e}\left( f\right)  \tag{22}
$$

where ${R}^{e}\left( f\right)  \mathrel{\text{:=}} {\mathbb{E}}_{{X}^{e},{Y}^{e}}\left\lbrack  {\ell \left( {f\left( {X}^{e}\right) ,{Y}^{e}}\right) }\right\rbrack$ is the risk under domain $e,{\mathcal{E}}_{\text{all }}$ is a large set of unseen domains that are related to the source domains, $\ell \left( {f\left( {X}^{e}\right) }\right.$ is the representation function for the input $X$ from domain $e$ , and ${Y}^{e}$ is the true image label. IRM is a learning paradigm to estimate data representations eliciting invariant predictors $w \circ  \Phi$ across multiple domains. The constrained optimization problem that IRM aims to solve can be formulated as,

其中 ${R}^{e}\left( f\right)  \mathrel{\text{:=}} {\mathbb{E}}_{{X}^{e},{Y}^{e}}\left\lbrack  {\ell \left( {f\left( {X}^{e}\right) ,{Y}^{e}}\right) }\right\rbrack$ 是领域 $e,{\mathcal{E}}_{\text{all }}$ 下的风险，$e,{\mathcal{E}}_{\text{all }}$ 是与源领域相关的大量未见领域的集合，$\ell \left( {f\left( {X}^{e}\right) }\right.$ 是来自领域 $e$ 的输入 $X$ 的表示函数，${Y}^{e}$ 是真实图像标签。IRM 是一种学习范式，用于估计在多个领域中能引出不变预测因子 $w \circ  \Phi$ 的数据表示。IRM 旨在解决的约束优化问题可以表述为:

$$
\mathop{\min }\limits_{{\mathbf{w},\Phi }}\mathop{\sum }\limits_{{e \in  {\mathcal{E}}_{\text{train }}}}{R}^{e}\left( {\mathbf{w} \circ  \Phi }\right)  \tag{23}
$$

$$
\text{s.t.}\mathbf{w} \in  \mathop{\operatorname{argmin}}\limits_{\widehat{\mathbf{w}}}{R}^{e}\left( {\widehat{\mathbf{w}} \circ  \Phi }\right) \text{,}
$$

where ${R}^{e}$ is the cross-entropy loss for domain $e,\Phi$ is the feature extractor and $w$ is a linear classifier. Since this is a bi-level optimization problem, it is difficult to optimize. By adopting the first-order approximation, the loss function is,

其中 ${R}^{e}$ 是领域 $e,\Phi$ 的交叉熵损失，$e,\Phi$ 是特征提取器，$w$ 是线性分类器。由于这是一个双层优化问题，因此难以进行优化。通过采用一阶近似，损失函数为:

$$
\mathop{\min }\limits_{\Phi }\mathop{\sum }\limits_{{e \in  {\mathcal{E}}_{\text{train }}}}{R}^{e}\left( \Phi \right)  + \lambda  \cdot  \begin{Vmatrix}{{\nabla }_{w \mid  w = {1.0}}{R}^{e}\left( {w \circ  \Phi }\right) }\end{Vmatrix}, \tag{24}
$$

where $w \in  \mathbb{R}$ is a dummy classifier. To find the invariant features across different domains, the authors assume that the data from all the environments share the same underlying Structural Equation Model (SEM).

其中 $w \in  \mathbb{R}$ 是一个虚拟分类器。为了找到不同领域间的不变特征，作者假设所有环境的数据都共享相同的潜在结构方程模型(Structural Equation Model，SEM)。

Ahuja et al. [37] show that IRM fails in settings where invariant features capture all information about the label in the input. They further show that along with the information bottleneck constraints, the invariance principle works in both settings - when invariant features capture the label's information entirely and when they do not. Krueger et al. [38] argue that the IRM principle is less effective when different domains are noisy. Furthermore, the authors also claim that IRM fails to achieve robustness w.r.t. covariate shifts. Also, the authors show that reducing differences in risk across training domains can reduce a model's sensitivity to a wide range of extreme distributional shifts, including the challenging setting where the input contains causal and anti-causal elements. Since the proposed model seeks robustness to whichever forms of distributional shift, it is more focused on the domain generalization problem than IRM. Finally, the authors prove that equality of risks can be a sufficient criterion for discovering causal structure. Li et al. [39] argue that the IRM principle fails for nonlinear classifiers and when pseudo-invariant features and geometric skews exist. To solve the problems of IRM, the authors in this work aim to utilize mutual information for causal prediction. Furthermore, they aim to adopt the variational formulation of the mutual information for nonlinear classifiers to develop a tractable loss function. The proposed model seeks to minimize invariant risks while at the same time mitigating the impact of pseudo-invariant features and geometric skews. Guo et al. [40] argue that the IRM principle guarantees the existence of an invariant optimal classifier for a set of overlapping feature representations across domains. However, as DNNs tend to learn shortcuts, they can circumvent IRM by learning non-overlapping representations for different domains. Thus, IRM fails when the spurious correlations are stronger than the invariant relations. The authors propose to utilize conditional distribution matching to overcome this problem.

阿胡贾(Ahuja)等人[37]表明，在不变特征捕获了输入中关于标签的所有信息的情况下，不变风险最小化(IRM)方法会失效。他们进一步指出，结合信息瓶颈约束，不变性原则在两种情况下都适用——当不变特征完全捕获标签信息时，以及当它们没有完全捕获时。克鲁格(Krueger)等人[38]认为，当不同领域存在噪声时，IRM原则的效果会变差。此外，作者还声称，IRM在处理协变量偏移时无法实现鲁棒性。同时，作者表明，减少跨训练领域的风险差异可以降低模型对各种极端分布偏移的敏感性，包括输入包含因果和反因果元素的具有挑战性的情况。由于所提出的模型追求对任何形式的分布偏移都具有鲁棒性，因此它比IRM更关注领域泛化问题。最后，作者证明了风险相等可以作为发现因果结构的充分标准。李(Li)等人[39]认为，对于非线性分类器以及存在伪不变特征和几何偏差的情况，IRM原则会失效。为了解决IRM的问题，本文作者旨在利用互信息进行因果预测。此外，他们旨在为非线性分类器采用互信息的变分形式，以开发一个易于处理的损失函数。所提出的模型旨在最小化不变风险，同时减轻伪不变特征和几何偏差的影响。郭(Guo)等人[40]认为，IRM原则保证了对于一组跨领域的重叠特征表示，存在一个不变的最优分类器。然而，由于深度神经网络(DNN)倾向于学习捷径，它们可以通过为不同领域学习非重叠表示来规避IRM。因此，当虚假相关性强于不变关系时，IRM会失效。作者提出利用条件分布匹配来克服这个问题。

Huh et al. [41] propose that by conserving the class-conditioned feature expectation ${\mathbb{E}}_{e}\left\lbrack  {f\left( x\right)  \mid  y}\right\rbrack$ across the different domains, one could overcome the flaws in IRM. Bellot et al. [42] argue that earlier works that optimize for worst-case error under interventions on observed variables are typically not optimal under moderate interventions, especially in the presence of unobserved confounders. They also argue that minimum average error solutions can optimize for any dependency in the data, and their performance deteriorates when the data is subjected to interventions on observed variables; but better adjusts to interventions on the confounders. Thus, causal and minimum average error solutions can be interpreted as two extremes of a distributionally robust optimization problem with a range of intermediate solutions that may have a more desirable performance. To this end, the authors propose Derivative Invariant Risk Minimization (DIRM) that interpolates between the causal solution and the minimum average error solution.

许(Huh)等人[41]提出，通过在不同领域中保持类条件特征期望${\mathbb{E}}_{e}\left\lbrack  {f\left( x\right)  \mid  y}\right\rbrack$，可以克服IRM的缺陷。贝洛特(Bellot)等人[42]认为，早期在对观测变量进行干预的情况下优化最坏情况误差的工作，在适度干预下通常不是最优的，特别是在存在未观测到的混杂因素的情况下。他们还认为，最小平均误差解决方案可以针对数据中的任何依赖关系进行优化，但当数据受到对观测变量的干预时，其性能会下降；不过，它能更好地适应对混杂因素的干预。因此，因果解决方案和最小平均误差解决方案可以被解释为分布鲁棒优化问题的两个极端，存在一系列中间解决方案，这些方案可能具有更理想的性能。为此，作者提出了导数不变风险最小化(DIRM)方法，该方法在因果解决方案和最小平均误差解决方案之间进行插值。

The IRM algorithm has also been effectively utilized in various applications. For instance, Francis et al. [43] highlights the application of generalization in federated learning models. The authors argue that the current federated learning models have poor generalizability as most of the data for the federated server are not i.i.d making it difficult for these models to generalize better. To this end, they propose to leverage causal learning to improve the generalizability in a federated learning scenario. The proposed model consists of client and global server layers. The client layer extracts the features from their respective input data. The global layer aids the participating clients in exchanging intermediate training components and trains the federated model in collaboration by minimizing the empirical average loss. The authors leverage IRM to learn invariant predictors in a federated learning setup that can attain an optimal empirical risk on all the participating client domains.

IRM算法也已在各种应用中得到有效利用。例如，弗朗西斯(Francis)等人[43]强调了泛化在联邦学习模型中的应用。作者认为，当前的联邦学习模型泛化能力较差，因为联邦服务器的大部分数据不是独立同分布的，这使得这些模型难以实现更好的泛化。为此，他们提议利用因果学习来提高联邦学习场景中的泛化能力。所提出的模型由客户端层和全局服务器层组成。客户端层从各自的输入数据中提取特征。全局层帮助参与的客户端交换中间训练组件，并通过最小化经验平均损失来协同训练联邦模型。作者利用IRM在联邦学习设置中学习不变预测器，这些预测器可以在所有参与的客户端领域上实现最优的经验风险。

#### 2.3.2 Utilizing Auxiliary Functions to Model Conditional Distributions

#### 2.3.2 利用辅助函数对条件分布进行建模

Generally, the domain generalization problem can be solved by posing it from a causal discovery point of view. Muller et al. [44] argue that when posed from a causal discovery viewpoint, a set of features exists for which the relation between this set and the label is invariant across all domains. They claim that this happens because of the Independent Causal Mechanisms (ICM) principle, which states that every mechanism acts independently of the others. Given a joint distribution of the input $\mathbf{X}$ , the chain rule can decompose this distribution into a product of conditionals. This can be formulated as,

一般来说，可以从因果发现的角度来解决领域泛化问题。穆勒(Muller)等人[44]认为，从因果发现的角度来看，存在一组特征，这组特征与标签之间的关系在所有领域中都是不变的。他们声称这是由于独立因果机制(ICM)原则，该原则指出每个机制都独立于其他机制起作用。给定输入$\mathbf{X}$的联合分布，链式法则可以将该分布分解为条件分布的乘积。这可以表示为:

$$
{p}_{\mathbf{X}}\left( {{x}_{1},\ldots ,{x}_{D}}\right)  = \mathop{\prod }\limits_{{i = 1}}^{D}{p}_{i}\left( {{x}_{i} \mid  {\mathbf{x}}_{{pa}\left( i\right) }}\right) , \tag{25}
$$

where ${\mathbf{x}}_{{pa}\left( i\right) }$ refer to the causal parents of ${x}_{i}$ , and the conditionals ${p}_{i}$ of this causal factorization are called causal mechanisms. The normalizing flows model complex distributions using invertible functions $T$ , which map the densities of interest to latent normal distributions. Thus, the authors represent the conditional distribution $P\left( {Y \mid  h\left( \mathbf{X}\right) }\right)$ using a conditional normalizing flow. They seek to learn a mapping $R = T\left( {Y;h\left( \mathbf{X}\right) }\right)$ such that, $R \sim  \mathcal{N}\left( {0,1}\right)  \bot  h\left( \mathbf{X}\right)$ when $Y \sim  P(Y \mid  h\left( \mathbf{X}\right) .T$ can be learned by minimizing the negative log-likelihood as,

其中 ${\mathbf{x}}_{{pa}\left( i\right) }$ 指的是 ${x}_{i}$ 的因果父节点，这种因果分解的条件概率 ${p}_{i}$ 被称为因果机制。归一化流(Normalizing Flows)使用可逆函数 $T$ 对复杂分布进行建模，这些函数将感兴趣的密度映射到潜在的正态分布。因此，作者使用条件归一化流来表示条件分布 $P\left( {Y \mid  h\left( \mathbf{X}\right) }\right)$。他们试图学习一个映射 $R = T\left( {Y;h\left( \mathbf{X}\right) }\right)$，使得当 $Y \sim  P(Y \mid  h\left( \mathbf{X}\right) .T$ 时，$R \sim  \mathcal{N}\left( {0,1}\right)  \bot  h\left( \mathbf{X}\right)$ 可以通过最小化负对数似然而学习得到，

$$
{\mathcal{L}}_{\mathrm{{NLL}}}\left( {T, h}\right)  \mathrel{\text{:=}} {\mathbb{E}}_{h\left( \mathbf{X}\right) , Y}\left\lbrack  {\parallel T(Y;h\left( \mathbf{X}\right) {\parallel }^{2}/2}\right.  \tag{26}
$$

$$
\left. {\cdot  - \log \left| {\det {\nabla }_{y}T\left( {Y;h\left( \mathbf{X}\right) }\right) }\right| }\right\rbrack   + C,
$$

where $C$ is a constant, det ${\nabla }_{y}$ is the Jacobian determinant. Finally, the authors propose a differentiable two-part objective function formulated by,

其中 $C$ 是一个常数，det ${\nabla }_{y}$ 是雅可比行列式。最后，作者提出了一个可微的两部分目标函数，其形式为

$$
\arg \mathop{\min }\limits_{{\theta ,\phi }}\left( {\mathop{\max }\limits_{{e \in  \mathcal{E}}}\left\{  {{\mathcal{L}}_{\mathrm{{NLL}}}\left( {{T}_{\theta },{h}_{\phi }}\right) }\right\}   + {\lambda }_{I}{\mathcal{L}}_{I}\left( {{P}_{R},{P}_{{h}_{\phi }\left( \mathbf{X}\right) , E}}\right) }\right) , \tag{27}
$$

where $\phi$ and $\theta$ denote model parameters, ${h}_{\phi }$ denotes the feature extractor, $E$ denotes the domain, and ${\mathcal{L}}_{I}$ denotes the Hilbert Schmidt Independence Criterion (HSIC) [45], a kernel-based independence measure that penalizes dependence between the distributions of $R$ and $\left( {{h}_{\phi }\left( \mathbf{X}\right) , E}\right)$ . The distribution loss stems from the theorem that if $R \bot  \left( {h\left( \mathbf{X}\right) , E}\right)$ . Then, it holds that $Y \bot  E \mid  h\left( \mathbf{X}\right)$ .

其中 $\phi$ 和 $\theta$ 表示模型参数，${h}_{\phi }$ 表示特征提取器，$E$ 表示域，${\mathcal{L}}_{I}$ 表示希尔伯特 - 施密特独立性准则(HSIC)[45]，这是一种基于核的独立性度量，用于惩罚 $R$ 和 $\left( {{h}_{\phi }\left( \mathbf{X}\right) , E}\right)$ 分布之间的依赖性。分布损失源于一个定理，即如果 $R \bot  \left( {h\left( \mathbf{X}\right) , E}\right)$ ，那么有 $Y \bot  E \mid  h\left( \mathbf{X}\right)$ 。

#### 2.3.3 Graphical Criterion based Methods

#### 2.3.3 基于图形准则的方法

Zheng et al. [46] leverage the causal factorization from the ICM principle to identify the autonomous generating factors (i.e., distribution of each variable given its cause), as changing one will not affect others. Due to this autonomy, it is necessary to have varied factors to account for the distributional shifts. The authors classify this set of variables as the mutable set, which is not assumed to be known. The authors further argue that obtaining a set of invariant predictors is possible, conditioned on the intervened mutable variables and any stable subset. However, it becomes a challenging task when the degeneration condition does not hold. The degeneration condition implies that the predictor with the whole stable set is min-max optimal if the intervened distribution can degenerate to the conditional one. When this condition is determined not to hold, the authors transform the worst-case quadratic loss into an optimization problem over all subsets of the stable set, the minimizer of which is sufficient and necessary for the predictor to be min-max optimal.

郑等人 [46] 利用独立因果机制(ICM)原则中的因果分解来识别自主生成因素(即每个变量在其原因给定下的分布)，因为改变一个因素不会影响其他因素。由于这种自主性，需要有不同的因素来解释分布的变化。作者将这组变量归类为可变集，该集合不假定是已知的。作者进一步认为，在对可变变量进行干预以及存在任何稳定子集的条件下，有可能获得一组不变的预测因子。然而，当退化条件不成立时，这就成为一项具有挑战性的任务。退化条件意味着，如果干预后的分布可以退化为条件分布，那么具有整个稳定集的预测因子是最小 - 最大最优的。当确定该条件不成立时，作者将最坏情况下的二次损失转化为对稳定集所有子集的优化问题，该问题的极小值点是预测因子达到最小 - 最大最优的充分必要条件。

Lv et al. [47] propose a novel method, Causality Inspired Representation Learning (CIRL), which aims to learn causal representations. They argue that the intrinsic causal mechanisms (formalized as conditional distributions) can be feasible to construct if the causal factors are given. However, it is hard to recover the causal factors since they are unobservable. To alleviate this problem, they propose to learn representations based on three general properties of the causal factors. They are (1) The causal factors are separated from the non-causal factors; (2) The factorization of the causal factors should be jointly independent; and (3) the factors should be causally sufficient, i.e., they should contain the necessary causal information needed for the classification task. These properties are based on Common Cause Principle and Independent Causal Mechanism principle. First, CIRL performs interventions using Fourier transforms to differentiate between causal and non-causal features. Next, representations of the augmented and the original images are learned as $r = \widehat{g}\left( x\right)$ , where $g\left( \text{.}\right) {istherepresentationfunction}.{To}$ simulate the causal factors that remain invariant to the intervention, the model enforces $\widehat{g}$ to keep unchanged dimension-wisely, as,

吕等人 [47] 提出了一种新颖的方法，即因果启发的表征学习(CIRL)，旨在学习因果表征。他们认为，如果给定因果因素，那么构建内在的因果机制(形式化为条件分布)是可行的。然而，由于因果因素是不可观测的，因此很难恢复它们。为了缓解这个问题，他们提议基于因果因素的三个一般属性来学习表征。它们是:(1)因果因素与非因果因素分离；(2)因果因素的分解应该是联合独立的；(3)这些因素应该具有因果充分性，即它们应该包含分类任务所需的必要因果信息。这些属性基于共同原因原则和独立因果机制原则。首先，CIRL 使用傅里叶变换进行干预，以区分因果特征和非因果特征。接下来，将增强图像和原始图像的表征学习为 $r = \widehat{g}\left( x\right)$ ，其中 $g\left( \text{.}\right) {istherepresentationfunction}.{To}$ 模拟在干预下保持不变的因果因素，模型强制 $\widehat{g}$ 在维度上保持不变，即

$$
\mathop{\max }\limits_{\widehat{g}}\frac{1}{N}\mathop{\sum }\limits_{{i = 1}}^{N}\operatorname{COR}\left( {{\widetilde{\mathbf{r}}}_{i}^{o},{\widetilde{\mathbf{r}}}_{i}^{a}}\right) , \tag{28}
$$

where ${\widetilde{\mathbf{r}}}_{i}^{o}$ and ${\widetilde{\mathbf{r}}}_{i}^{a}$ are the normalized Z-score of the ${i}^{th}$ column of ${\mathbf{R}}^{o} = {\left\lbrack  {\left( {\mathbf{r}}_{1}^{o}\right) }^{T},\ldots ,{\left( {\mathbf{r}}_{B}^{o}\right) }^{T}\right\rbrack  }^{T} \in  {\mathbb{R}}^{B \times  N}$ and ${\mathbf{R}}^{a} =$ ${\left\lbrack  {\left( {\mathbf{r}}_{1}^{a}\right) }^{T},\ldots ,{\left( {\mathbf{r}}_{B}^{a}\right) }^{T}\right\rbrack  }^{T}$ , respectively, ${COR}$ is a correlation function, and $N$ is the number of dimensions. The joint independence among the causal factors is imposed by ensuring that any two dimensions of the representations are independent. Thus, the same dimension of ${\mathbf{R}}^{o}$ and ${\mathbf{R}}^{a}$ are considered positive pairs. In contrast, the different dimensions are considered negative pairs. Positive pairs should hold a stronger correlation when compared to negative pairs. This can be formulated with a factorization loss ${\mathcal{L}}_{Fac}$ which can be formulated as,

其中 ${\widetilde{\mathbf{r}}}_{i}^{o}$ 和 ${\widetilde{\mathbf{r}}}_{i}^{a}$ 分别是 ${\mathbf{R}}^{o} = {\left\lbrack  {\left( {\mathbf{r}}_{1}^{o}\right) }^{T},\ldots ,{\left( {\mathbf{r}}_{B}^{o}\right) }^{T}\right\rbrack  }^{T} \in  {\mathbb{R}}^{B \times  N}$ 和 ${\mathbf{R}}^{a} =$ ${\left\lbrack  {\left( {\mathbf{r}}_{1}^{a}\right) }^{T},\ldots ,{\left( {\mathbf{r}}_{B}^{a}\right) }^{T}\right\rbrack  }^{T}$ 的 ${i}^{th}$ 列的归一化Z分数，${COR}$ 是一个相关函数，$N$ 是维度数。通过确保表示的任意两个维度相互独立来实现因果因素之间的联合独立性。因此，${\mathbf{R}}^{o}$ 和 ${\mathbf{R}}^{a}$ 的相同维度被视为正样本对。相反，不同维度被视为负样本对。与负样本对相比，正样本对应具有更强的相关性。这可以用一个因式分解损失 ${\mathcal{L}}_{Fac}$ 来表示，其公式如下:

$$
{\mathcal{L}}_{Fac} = \frac{1}{2}\parallel \mathbf{C} - \mathbf{I}{\parallel }_{F}^{2}, \tag{29}
$$

where $C$ is the correlation matrix computed as,

其中 $C$ 是计算得到的相关矩阵，计算公式为:

${\mathbf{C}}_{ij} = \frac{\left\langle  {\widetilde{r}}_{i}^{0},{\widetilde{r}}_{j}^{n}\right\rangle  }{\begin{Vmatrix}{\widetilde{r}}_{i}^{n}\end{Vmatrix}\begin{Vmatrix}{\widetilde{r}}_{j}^{n}\end{Vmatrix}}, i, j \in  1,2,\ldots , N$ , and $I$ is the identity matrix. Classification loss with the causal representations can be computed to ensure the representations are causally sufficient. However, inferior dimensions may carry relatively less causal information and make a small contribution to classification. Thus, the authors design an adversarial mask module to detect the inferior dimensions. The module learns the importance of the different dimensions. The dimensions corresponding to the largest $\kappa  \in  \left( {0,1}\right)$ ratio are regarded as superior. In contrast, the rest are regarded as inferior ones. The authors use the GumbelSoftmax trick [16] to sample a mask with $\kappa \mathrm{N}$ values approaching 1 . Thus, the classification loss is given by,

${\mathbf{C}}_{ij} = \frac{\left\langle  {\widetilde{r}}_{i}^{0},{\widetilde{r}}_{j}^{n}\right\rangle  }{\begin{Vmatrix}{\widetilde{r}}_{i}^{n}\end{Vmatrix}\begin{Vmatrix}{\widetilde{r}}_{j}^{n}\end{Vmatrix}}, i, j \in  1,2,\ldots , N$ ，并且 $I$ 是单位矩阵。可以计算具有因果表示的分类损失，以确保这些表示在因果关系上是充分的。然而，较差的维度可能携带相对较少的因果信息，并且对分类的贡献较小。因此，作者设计了一个对抗性掩码模块来检测较差的维度。该模块学习不同维度的重要性。对应最大 $\kappa  \in  \left( {0,1}\right)$ 比率的维度被视为优质维度。相反，其余的被视为较差维度。作者使用GumbelSoftmax技巧 [16] 来采样一个值接近1的掩码。因此，分类损失由以下公式给出:

$$
{\mathcal{L}}_{cls}^{sup} = \ell \left( {{\widehat{h}}_{1}\left( {{r}^{o} \odot  {m}^{o}}\right) , y}\right)  + \ell \left( {{\widehat{h}}_{1}\left( {{r}^{a} \odot  {m}^{a}}\right) , y}\right)  \tag{30}
$$

$$
{\mathcal{L}}_{cls}^{inf} = \ell \left( {{\widehat{h}}_{2}\left( {{r}^{o} \odot  \left( {1 - {m}^{o}}\right) }\right) , y}\right)  + \ell \left( {{\widehat{h}}_{2}\left( {{r}^{a} \odot  \left( {1 - {m}^{a}}\right) }\right) , y}\right) .
$$

The final objective function is represented as,

最终的目标函数表示为:

$$
\mathop{\min }\limits_{{\widehat{g},{\widehat{h}}_{1},{\widehat{h}}_{2}}}{\mathcal{L}}_{cls}^{sup} + {\mathcal{L}}_{cls}^{inf} + \tau {\mathcal{L}}_{Fac},\;\mathop{\min }\limits_{\widehat{w}}{\mathcal{L}}_{cls}^{sup} - {\mathcal{L}}_{cls}^{inf}, \tag{31}
$$

where $\tau$ is the trade-off parameter. Similarly, Wang et al. [48] argue that rather than the distribution of the features, it is the causal mechanism that remains invariant across domains. By utilizing feature-level invariance with the aid of regularizers, the model may learn spurious features that are only correlated to the label. Thus, to this end, the authors propose to treat the machine learning models as SCMs. In other words, the authors propose a novel constraint that measures the Average Causal Effect (ACE) between the causal attributions in the networks. They leverage contrastive learning and introduce ACE contrastive loss that pairs samples from the same class and different domains as positive pairs and those of different classes as negative pairs. The ACE contrastive loss regularizes the learning procedure and encourages domain-independent attributions of extracted features. The causal attribution of the neuron ${z}^{j}$ , corresponding to the ${j}^{\text{th }}$ feature, on the output $y$ is calculated as the subtraction between the interventional expectation of $y$ when ${z}^{j} = \alpha$ and a baseline of ${z}^{j}$ , given by,

其中 $\tau$ 是权衡参数。同样，Wang等人 [48] 认为，跨领域保持不变的是因果机制，而不是特征的分布。通过借助正则化器利用特征级别的不变性，模型可能会学习到仅与标签相关的虚假特征。因此，为此目的，作者提议将机器学习模型视为结构因果模型(SCMs)。换句话说，作者提出了一种新的约束，用于衡量网络中因果归因之间的平均因果效应(ACE)。他们利用对比学习，并引入了ACE对比损失，将来自同一类别和不同领域的样本对作为正样本对，将不同类别的样本对作为负样本对。ACE对比损失对学习过程进行正则化，并鼓励提取的特征具有与领域无关的归因。神经元 ${z}^{j}$ 对应于 ${j}^{\text{th }}$ 特征在输出 $y$ 上的因果归因，计算为当 ${z}^{j} = \alpha$ 时 $y$ 的干预期望与 ${z}^{j}$ 的基线之间的差值，计算公式如下:

$$
{c}_{{do}\left( {{z}^{j} = \alpha }\right) }^{y} = \mathbb{E}\left\lbrack  {y \mid  {do}\left( {{z}^{j} = \alpha }\right) }\right\rbrack   - {\mathbb{E}}_{{z}^{j}}\left\lbrack  {\mathbb{E}\left\lbrack  {y \mid  {do}\left( {{z}^{j} = \alpha }\right) }\right\rbrack  }\right\rbrack  . \tag{32}
$$

The ACE vector for the ${i}^{t}h$ samples is given by,

${i}^{t}h$ 个样本的ACE向量由以下公式给出:

$$
{\mathbf{c}}_{i} = \left\lbrack  {{c}_{i}^{1},{c}_{i}^{2},\ldots {c}_{i}^{n}}\right\rbrack  . \tag{33}
$$

The final objective function is then formulated as,

最终的目标函数则表示为:

$$
{\mathcal{L}}_{\mathcal{A}}\left( {\mathbf{D};\theta ,\phi }\right)  = \mathop{\sum }\limits_{{i = 1}}^{m}\ell \left( {{g}_{\phi }\left( {{f}_{\theta }\left( {x}_{i}\right) }\right) ,{y}_{i}}\right)  + \rho \mathop{\sum }\limits_{{i = 1}}^{m}{\mathcal{A}}_{\theta ,\phi }\left( {x}_{i}\right) , \tag{34}
$$

where the first term denotes the classification loss, ${g}_{phi}$ is the classifier and ${f}_{\theta }$ are the features and ${\mathcal{A}}_{\theta ,\phi }\left( {x}_{i}\right)$ represents the Contrastive ACE loss which is given by,

其中第一项表示分类损失，${g}_{phi}$ 是分类器，${f}_{\theta }$ 是特征，${\mathcal{A}}_{\theta ,\phi }\left( {x}_{i}\right)$ 表示对比ACE损失，其计算公式如下:

$$
\max \left\{  {\operatorname{dist}\left( {{\mathbf{c}}_{i},{\mathbf{c}}_{q\left( {\mathcal{P}}_{i}\right) }}\right)  - \operatorname{dist}\left( {{\mathbf{c}}_{i},{\mathbf{c}}_{q\left( {\mathcal{N}}_{i}\right) }}\right)  + \delta ,0}\right\}  , \tag{35}
$$

where $q\left( {\mathcal{P}}_{i}\right)$ is an index sampled uniformly at random from the positive pairs’ set, $q\left( {\mathcal{N}}_{i}\right)$ is from the negative pair, $\delta$ is a margin variable, dist is a distance metric. Sun et al. [49] argue that when dealing with sensory-level data such as modeling pixels, it is beneficial to model the problem similar to human perception; i.e., the causal factors of the label $Y$ is related to unobserved abstractions $S$ via a mechanism ${f}_{y}$ such that $Y \leftarrow  {f}_{y}\left( {S,{\varepsilon }_{y}}\right)$ , where $\varepsilon$ is a noise term. At the same time, there exist latent variables $Z$ that, along with variables $S$ generate the input image $X$ via mechanism ${f}_{x}$ such that $X \leftarrow  {f}_{x}\left( {S, Z,{\varepsilon }_{x}}\right)$ . Under this situation, domain shifts occur when variables $Z$ are allowed to correlate to the variables $S$ spuriously. For instance, when dealing with the image classification problem, the background features can be classified as $Z$ , and the object-related abstractions such as shape can be classified as $S$ . The authors encapsulate this information in a set of causal models. They argue that the generating mechanisms ${f}_{x}$ and ${f}_{y}$ are invariant across domains. At the same time, the spurious relation between $Z$ and $S$ is allowed to vary. Mathematically, Causal Invariance refers to the condition when $P\left( {Y \mid  {do}\left( s\right) }\right)$ and $P\left( {X \mid  {do}\left( s\right) ,{do}\left( z\right) }\right)$ are stable to the shift across domains. The authors finally reformulate the Variational Bayesian method to estimate the Causal Invariance during training and optimize it during testing.

其中 $q\left( {\mathcal{P}}_{i}\right)$ 是从正样本对集合中均匀随机采样的一个索引，$q\left( {\mathcal{N}}_{i}\right)$ 来自负样本对，$\delta$ 是一个边界变量，dist 是一个距离度量。孙等人 [49] 认为，在处理感官层面的数据(如对像素进行建模)时，以类似于人类感知的方式对问题进行建模是有益的；即，标签 $Y$ 的因果因素通过一种机制 ${f}_{y}$ 与未观察到的抽象概念 $S$ 相关联，使得 $Y \leftarrow  {f}_{y}\left( {S,{\varepsilon }_{y}}\right)$ ，其中 $\varepsilon$ 是一个噪声项。同时，存在潜在变量 $Z$ ，它们与变量 $S$ 一起通过机制 ${f}_{x}$ 生成输入图像 $X$ ，使得 $X \leftarrow  {f}_{x}\left( {S, Z,{\varepsilon }_{x}}\right)$ 。在这种情况下，当允许变量 $Z$ 与变量 $S$ 产生虚假关联时，就会发生领域偏移。例如，在处理图像分类问题时，背景特征可以归类为 $Z$ ，而与物体相关的抽象概念(如形状)可以归类为 $S$ 。作者将这些信息封装在一组因果模型中。他们认为生成机制 ${f}_{x}$ 和 ${f}_{y}$ 在不同领域之间是不变的。同时，允许 $Z$ 和 $S$ 之间的虚假关系发生变化。从数学上讲，因果不变性指的是 $P\left( {Y \mid  {do}\left( s\right) }\right)$ 和 $P\left( {X \mid  {do}\left( s\right) ,{do}\left( z\right) }\right)$ 对跨领域的偏移保持稳定的条件。作者最终重新表述了变分贝叶斯方法，以在训练期间估计因果不变性，并在测试期间对其进行优化。

#### 2.3.4 Kernel-based Optimization Methods

#### 2.3.4 基于核的优化方法

Muandet et al. [50] was one of the earliest works aiming at enhancing the generalizability of the machine learning models from a causal perspective. The authors argue that the conditional distribution of the label $Y$ , given an input $X$ is stable. However, the marginal distribution i.e., $P\left( X\right)$ may fluctuate smoothly. Due to this fluctuation machine learning models may suffer from model misspecification, i.e. the model fails to account for everything that it should. To alleviate this problem, the authors propose Domain Invariant Component Analysis (DICA). DICA aims to find data transformations that minimize the difference between the marginal distribution of different domains while preserving the stable conditional $P\left( {Y \mid  X}\right)$ . They introduce a domain generalization approach that learns an invariant transformation across domains between inputs and outputs by minimizing the dissimilarities between different domains. Basically, the objective of this work is to find a transformation that satisfies the following two properties: (1) Minimizing the distance between the distribution of the samples transformed via this transformation; and (2) The learned transformation between input and output remains invariant across different domains. To do so, a kernel-based optimization objective is

穆安代特等人 [50] 的研究是最早从因果角度旨在提高机器学习模型泛化能力的工作之一。作者认为，给定输入 $X$ 时，标签 $Y$ 的条件分布是稳定的。然而，边缘分布，即 $P\left( X\right)$ 可能会平滑波动。由于这种波动，机器学习模型可能会出现模型误设问题，即模型未能考虑到它应该考虑的所有因素。为了缓解这个问题，作者提出了领域不变分量分析(Domain Invariant Component Analysis，DICA)。DICA 旨在找到一种数据变换，在保留稳定的条件分布 $P\left( {Y \mid  X}\right)$ 的同时，最小化不同领域边缘分布之间的差异。他们引入了一种领域泛化方法，通过最小化不同领域之间的差异，学习输入和输出之间跨领域的不变变换。基本上，这项工作的目标是找到一种满足以下两个属性的变换:(1)最小化通过该变换转换后的样本分布之间的距离；(2)学习到的输入和输出之间的变换在不同领域之间保持不变。为此，定义了一个基于核的优化目标

defined as:

定义为:

$$
\mathop{\max }\limits_{{B \in  {\mathbb{R}}^{N} \times  M}}\frac{\frac{1}{n}\operatorname{Tr}\left( {{B}^{T}L{\left( L + n\epsilon {I}_{n}\right) }^{-1}{K}^{2}B}\right. }{\operatorname{Tr}\left( {{B}^{T}{KQKB} + {BKB}}\right) }\text{,} \tag{36}
$$

where $\mathrm{K}$ and $\mathrm{Q}$ are the block kernel and coefficient matrices, respectively and $\mathrm{B}$ is the estimator which satisfies the two desired properties.

其中 $\mathrm{K}$ 和 $\mathrm{Q}$ 分别是块核矩阵和系数矩阵，$\mathrm{B}$ 是满足两个期望属性的估计器。

## 3 Domain Generalization in Text and Graphs

## 3 文本和图数据中的领域泛化

So far we have surveyed existing works on the causal domain generalization for the image data. In the following we discuss the frameworks designed for text and graph data.

到目前为止，我们已经综述了现有的针对图像数据的因果领域泛化相关工作。接下来，我们将讨论为文本和图数据设计的框架。

### 3.1 Invariance Learning for Text

### 3.1 文本的不变性学习

With the advances of large pre-trained models, Natural Language Processing models have gained widespread success over multiple applications in the real world. However, these models are brittle to out-of-domain samples [51]. A series of works, showcase how the language models rely on spurious correlations for classification. For instance, Wang et al. [52] show that words such as Spielberg is correlated to positive movie reviews. Wulczyn et al. [53] show that a toxicity classifier learns that "gay" is correlated with toxic comments. To address the reliance on spurious correlations recent works [54, 55, 56, 57, 58] aim at leveraging different causal techniques to improve the generalizability of the NLP models. Interested readers can refer to [59] which focuses on how to infer causal relations in natural language processing models. Causality-aware domain generalization works in the natural language domain are also aligned with our defined categories. For instance, recent works in NLP [60, 61] leveraged human in-the-loop systems to make the models robust to spurious correlations by leveraging human common sense of causality. They augment training data with crowd-sourced annotations about reasoning of possible shifts in unmeasured variables and finally conduct robust optimization to control worst-case loss. While these works highlight that human annotations improve the robustness, collecting such annotations can be costly. To overcome this problem Wang et al. [55] propose to train a robust classifier with automatically generated counterfactual samples which is aligned with causal data augmentation approaches as listed earlier in the categorization section. The authors aim at utilizing the closest opposite matching approach to identify the likely causal features, and then generate counterfactual training samples by substituting causal features with their antonyms and assigning opposite labels to the newly generated samples.

随着大型预训练模型的发展，自然语言处理(Natural Language Processing，NLP)模型在现实世界的多个应用中取得了广泛的成功。然而，这些模型对于领域外样本较为脆弱[51]。一系列研究展示了语言模型如何依赖虚假相关性进行分类。例如，Wang等人[52]表明，像“斯皮尔伯格(Spielberg)”这样的词与积极的电影评论相关。Wulczyn等人[53]表明，毒性分类器会学习到“同性恋(gay)”与有毒评论相关。为了解决对虚假相关性的依赖问题，近期的研究[54, 55, 56, 57, 58]旨在利用不同的因果技术来提高NLP模型的泛化能力。感兴趣的读者可以参考[59]，该文献专注于如何在自然语言处理模型中推断因果关系。自然语言领域中具有因果意识的领域泛化研究也与我们定义的类别一致。例如，NLP领域的近期研究[60, 61]利用人工参与的系统，通过利用人类的因果常识使模型对虚假相关性具有鲁棒性。他们用关于未测量变量可能变化推理的众包注释来扩充训练数据，最后进行鲁棒优化以控制最坏情况下的损失。虽然这些研究强调了人工注释可以提高鲁棒性，但收集此类注释的成本可能很高。为了克服这个问题，Wang等人[55]提出用自动生成的反事实样本训练一个鲁棒分类器，这与分类部分前面列出的因果数据扩充方法一致。作者旨在利用最接近的相反匹配方法来识别可能的因果特征，然后通过用反义词替换因果特征并为新生成的样本分配相反的标签来生成反事实训练样本。

Mathematically, for a given sample(d, y), where $d$ represents document and $y$ represents the label, the corresponding counterfactual $\left( {{d}^{\prime },{y}^{\prime }}\right)$ is generated by (i) substituting causal terms in $d$ with their antonyms to get ${d}^{\prime }$ , and (ii) assigning an opposite label ${y}^{\prime }$ to ${d}^{\prime }$ . The authors propose a two-stage process as follows:

从数学角度来看，对于给定的样本(d, y)，其中$d$表示文档，$y$表示标签，相应的反事实样本$\left( {{d}^{\prime },{y}^{\prime }}\right)$通过以下方式生成:(i) 用反义词替换$d$中的因果术语以得到${d}^{\prime }$；(ii) 为${d}^{\prime }$分配相反的标签${y}^{\prime }$。作者提出了如下两阶段过程:

- Using models such as logistic regression, the authors identify the strongly correlated terms $\left\langle  {{t}_{1}\ldots {t}_{k}}\right\rangle$ as candidate causal features.

- 使用逻辑回归等模型，作者将强相关术语$\left\langle  {{t}_{1}\ldots {t}_{k}}\right\rangle$识别为候选因果特征。

- For each top term $t$ and a set of documents containing $t : {D}_{t} = \left\langle  {{d}_{1}\ldots {d}_{n}}\right\rangle$ , the authors utilize context similarity to identify documents with opposite labels.

- 对于每个顶级术语$t$和包含$t : {D}_{t} = \left\langle  {{d}_{1}\ldots {d}_{n}}\right\rangle$的一组文档，作者利用上下文相似度来识别具有相反标签的文档。

- Then, the authors select the highest score match for each term and identify likely causal features by picking those whose closest opposite matches have scores greater than a threshold (0.95 is used below).

- 然后，作者为每个术语选择得分最高的匹配，并通过选择那些最接近的相反匹配得分大于某个阈值(以下使用0.95)的术语来识别可能的因果特征。

- Then for each sample, the authors substitute the causal terms with antonyms and generate counterfactual samples. Finally, they train the robust classifier using the original and counterfactual data.

- 然后，对于每个样本，作者用反义词替换因果术语并生成反事实样本。最后，他们使用原始数据和反事实数据训练鲁棒分类器。

Similarly, Tan et al. [62] propose to construct meaningful counterfactuals that would reflect the model's decision boundaries. The authors leverage rule-based schemes that negate causal relations or strengthen conditionally causal sentences.

同样，Tan等人[62]提出构建能够反映模型决策边界的有意义的反事实样本。作者利用基于规则的方案来否定因果关系或强化条件因果语句。

Choi et al. [54] aim to utilize contrastive learning to enhance the representations of the causal features, this is aligned with capturing invariance via learning causal representations. The porposed model ${C}^{2}L$ , first aims to identify the causal tokens based on attribution scores. Formally, to identify the important tokens, the authors leverage attribution scores as follows:

Choi等人[54]旨在利用对比学习来增强因果特征的表示，这与通过学习因果表示来捕捉不变性是一致的。所提出的模型${C}^{2}L$首先旨在根据归因得分识别因果标记。形式上，为了识别重要标记，作者如下利用归因得分:

$$
{g}_{i} = {\begin{Vmatrix}{\nabla }_{{\mathbf{w}}_{i}^{p}}{\mathcal{L}}_{\text{task }}\left( x, y;\phi \right) \end{Vmatrix}}^{2}, \tag{37}
$$

where $x$ denotes the input, $y$ denotes the label, ${g}_{i}$ denotes the gradient magnitude computed from the classifier ${f}_{\phi }$ , and ${\mathcal{L}}_{\text{task }}$ denotes the cross-entropy loss. The gradient-based score of token $w$ is aggregated over all the training texts

其中$x$表示输入，$y$表示标签，${g}_{i}$表示从分类器${f}_{\phi }$计算得到的梯度大小，${\mathcal{L}}_{\text{task }}$表示交叉熵损失。标记$w$的基于梯度的得分在所有包含标记$x$的训练文本上进行聚合

having the token $w$ by:

通过以下方式:

$$
{s}^{\text{grad }}\left( w\right)  = \mathop{\sum }\limits_{{\left( {x, y}\right)  \in  \mathcal{D}}}\frac{1}{{n}_{w, x}}\mathop{\sum }\limits_{{i \in  \{ 1,\ldots , T\} }}\mathbb{I}\left( {{w}_{i} = w}\right)  \cdot  {g}_{i} \tag{38}
$$

where $\mathbb{I}$ is an indicator function, and ${n}_{w, x}$ is the number of word $w$ in the input $x$ . After obtaining the scores for each tokens, the authors employ a causal validation technique to identify the causal tokens. As per this step, the authors compute the Individual Treatment Effect (ITE) of each token on the label. The main intuition behind this step is that, if the masked text can be reconstructed into multiple examples with different classes, we can decide the masked term has a causal effect. To this end, the authors use BERT with dropout mechanism to identify the top- $k$ substitutions for the token $w$ . The $k$ candidates are then passed through the classifier to obtained the predicted labels $\widehat{y}$ . By testing whether the $k$ labels are evenly distributed into the classes, we can decide the high-attributed token $w$ as causal to its task label $y$ .

其中 $\mathbb{I}$ 是一个指示函数，${n}_{w, x}$ 是输入 $x$ 中单词 $w$ 的数量。在获得每个标记的分数后，作者采用因果验证技术来识别因果标记。这一步背后的主要直觉是，如果被屏蔽的文本可以重构为具有不同类别的多个示例，我们就可以判定被屏蔽的术语具有因果效应。为此，作者使用带有丢弃机制的 BERT 来识别标记 $w$ 的前 $k$ 个替换项。然后将这 $k$ 个候选项通过分类器以获得预测标签 $\widehat{y}$。通过测试这 $k$ 个标签是否均匀分布在各个类别中，我们可以判定高归因标记 $w$ 对其任务标签 $y$ 具有因果关系。

Finally, the authors leverage contrastive learning to better learn the causal structure of the classification task. After obtaining the causal features, the authors generate causal triplets of the form $\left( {x,{x}^{ + },{x}^{ - }}\right) .{x}^{ - }$ denotes the counterfactual pair that is generated by masking out causal words. In contrast, ${x}^{ + }$ denotes the factual pair generated by masking one of the non-causal words that is still recognized as the original label $y$ , which helps to learn a model invariant to these features. The contrastive objective aims at mapping the representation of $x$ closer to ${x}^{ + }$ and further from ${x}^{ - }$ . The objective can be formulated as,

最后，作者利用对比学习来更好地学习分类任务的因果结构。在获得因果特征后，作者生成形式为 $\left( {x,{x}^{ + },{x}^{ - }}\right) .{x}^{ - }$ 的因果三元组，$\left( {x,{x}^{ + },{x}^{ - }}\right) .{x}^{ - }$ 表示通过屏蔽因果词生成的反事实对。相比之下，${x}^{ + }$ 表示通过屏蔽一个仍被识别为原始标签 $y$ 的非因果词生成的事实对，这有助于学习一个对这些特征不变的模型。对比目标旨在将 $x$ 的表示映射得更接近 ${x}^{ + }$ 且远离 ${x}^{ - }$。该目标可以表述为

$$
{\mathcal{L}}_{c}\left( {x;\theta }\right)  = \max (0,
$$

$$
{\Delta }_{m} + \frac{1}{J}\mathop{\sum }\limits_{{j = 1}}^{J}{s}_{\theta }\left( {x,{x}_{j}^{ + }}\right)  - \frac{1}{J}\mathop{\sum }\limits_{{j = 1}}^{J}{s}_{\theta }\left( {x,{x}_{j}^{ - }}\right) ) \tag{39}
$$

where $J$ is the number of positive/negative pairs, ${\Delta }_{m}$ is a margin value and ${s}_{\theta }\left( {\cdot , \cdot  }\right)$ is distance between the representations. The final objective function is given by,

其中 $J$ 是正/负对的数量，${\Delta }_{m}$ 是一个边界值，${s}_{\theta }\left( {\cdot , \cdot  }\right)$ 是表示之间的距离。最终的目标函数为

$$
\mathcal{L} = {\mathcal{L}}_{\text{task }} + \lambda {\mathcal{L}}_{c} \tag{40}
$$

where $\lambda$ is a balancing coefficient for the contrastive objective.

其中 $\lambda$ 是对比目标的平衡系数。

Inspired by IRM [4], Peyrard et al. [57] propose invariant Language Modeling (iLM), a framework that generalizes better across multiple environments for language models in NLP. iLM is aligned with learning invariance by transferring causal mechanisms. The ILM aims at utilizing a game-theoretic implementation of IRM for language models. In this case, the invariance is achieved by a specific training schedule in which each environment competes with the others to optimize their environment-specific loss by updating subsets of the Language Model (LM) in a round-robin fashion.

受不变风险最小化(Invariant Risk Minimization，IRM)[4] 的启发，佩拉尔等人 [57] 提出了不变语言建模(invariant Language Modeling，iLM)，这是一个能让自然语言处理(NLP)中的语言模型在多个环境中更好地泛化的框架。iLM 通过转移因果机制来实现学习不变性。ILM 旨在为语言模型采用 IRM 的博弈论实现方法。在这种情况下，不变性是通过一种特定的训练方案实现的，在该方案中，每个环境与其他环境竞争，以循环方式更新语言模型(Language Model，LM)的子集来优化其特定环境的损失。

The IRM-games [63] method aims to change the training procedure of IRM by using a game-theoretic perspective in which each environment $e$ is tied to its own classifier ${w}^{e}$ , and the feature representation $\phi$ is shared. The global classifier $w$ is defined as an ensemble formulated as,

IRM 博弈(IRM - games)[63] 方法旨在通过博弈论的视角改变 IRM 的训练过程，在该视角中，每个环境 $e$ 都与自己的分类器 ${w}^{e}$ 相关联，并且特征表示 $\phi$ 是共享的。全局分类器 $w$ 被定义为一个集成，形式为

$$
w = \frac{1}{\left| \mathcal{E}\right| }\mathop{\sum }\limits_{{e \in  \mathcal{E}}}{w}^{e} \tag{41}
$$

where $\mathcal{E}$ represents the set of training environments. Each environment takes turns to minimize their own empirical risk ${R}^{e}\left( {w \circ  \phi }\right)$ w.r.t their own classifier ${w}^{e}$ , while the shared $\phi$ is updated periodically. The authors adopt this IRM-games setup for language models. First, the shared representation can be represented by the main body of the encoder of an LM, and ${w}^{e}$ is the language modeling head that outputs the logits after the last layer. The multiple environments for this task can be the different sources from which text data emerges, for instance, encyclopedic texts, Twitter, news articles, and so on. Suppose for each environment the data can be represented as ${\left\{  \left( {X}^{e},{Y}^{e}\right) \right\}  }_{e = 1\ldots n}$ . A forward pass on a batch $\left( {{x}_{i},{y}_{i}}\right)$ sampled according to $P\left( {{X}^{i},{Y}^{i}}\right)$ from environment $i$ involves $n$ language modeling heads ${\left\{  {w}_{e}\right\}  }_{e = 1\ldots n}$ :

其中 $\mathcal{E}$ 表示训练环境的集合。每个环境轮流相对于自己的分类器 ${w}^{e}$ 最小化自己的经验风险 ${R}^{e}\left( {w \circ  \phi }\right)$，同时定期更新共享的 $\phi$。作者将这种 IRM 博弈设置应用于语言模型。首先，共享表示可以由语言模型编码器的主体表示，${w}^{e}$ 是在最后一层之后输出对数几率的语言建模头。该任务的多个环境可以是文本数据的不同来源，例如百科文本、推特、新闻文章等等。假设对于每个环境，数据可以表示为 ${\left\{  \left( {X}^{e},{Y}^{e}\right) \right\}  }_{e = 1\ldots n}$。从环境 $i$ 根据 $P\left( {{X}^{i},{Y}^{i}}\right)$ 采样的一批 $\left( {{x}_{i},{y}_{i}}\right)$ 数据的前向传播涉及 $n$ 个语言建模头 ${\left\{  {w}_{e}\right\}  }_{e = 1\ldots n}$:

$$
\widehat{y} = \operatorname{softmax}\left( {\mathop{\sum }\limits_{{e = 1}}^{n}{w}_{e} \circ  \phi \left( {x}_{i}\right) }\right)  \tag{42}
$$

Based on the task, a modeling loss $\mathcal{L}$ can be applied to the output $\widehat{y}$ . Since the underlying causal model is not known for language models, utilizing the data stemming from different environments can facilitate in learning the invariant relationships. However, the choice of environments is an important step as the environments define which relations are spurious in nature.

基于该任务，可以将建模损失$\mathcal{L}$应用于输出$\widehat{y}$。由于语言模型的底层因果模型未知，利用来自不同环境的数据有助于学习不变关系。然而，环境的选择是重要的一步，因为环境决定了哪些关系本质上是虚假的。

### 3.2 Invariance Learning for Graphs

### 3.2 图的不变性学习

Unlike vision and natural language data, graph data is heterogeneous. Graph Neural Networks (GNNs) fuse heterogeneous information from node features and graph structures to learn effective node embeddings. However, the complex and unobserved non-linear dependencies among representations are much more difficult to be measured and eliminated than the linear cases for decorrelation of non-graph data. In out-of-distribution scenarios, when complex heterogeneous distribution shifts exist, the performance of current GNN models can degrade substantially, mainly induced by spurious correlations. The spurious correlations intrinsically come from the subtle correlations between irrelevant and relevant representations. To address this problem, a variety of methods have been proposed.

与视觉和自然语言数据不同，图数据具有异质性。图神经网络(Graph Neural Networks，GNNs)融合来自节点特征和图结构的异质信息，以学习有效的节点嵌入。然而，与非图数据去相关的线性情况相比，表征之间复杂且未被观察到的非线性依赖关系更难测量和消除。在分布外场景中，当存在复杂的异质分布偏移时，当前GNN模型的性能可能会大幅下降，这主要是由虚假相关性引起的。虚假相关性本质上来自不相关和相关表征之间的微妙关联。为了解决这个问题，人们提出了多种方法。

Liu et al. [64] leverage graph data augmentations to identify graph rationales. The authors aim to augment the rationale subgraph by removing its environment subgraph and combining it with different environment subgraphs. Furthermore, they propose a framework, namely, GREA, that leverages masking to separate the rationales from the environment. After learning the node representations with the aid of a GNN, a Multi-Layer Perceptron (MLP) is used to map the node representations to a mask vector $\mathbf{m} \in  {\left( 0,1\right) }^{N}$ on the nodes in the set $\mathcal{V}.{m}_{v} = \Pr \left( {v \in  {\mathcal{V}}^{\left( r\right) }}\right)$ is the node-level mask that indicates the probability of node $v \in  \mathcal{V}$ being classified into the rationale subgraph. It is formulated as,

Liu等人[64]利用图数据增强来识别图基本原理。作者旨在通过移除环境子图并将其与不同的环境子图组合来增强基本原理子图。此外，他们提出了一个名为GREA的框架，该框架利用掩码将基本原理与环境分离。在借助GNN学习节点表征后，使用多层感知机(Multi - Layer Perceptron，MLP)将节点表征映射到一个掩码向量$\mathbf{m} \in  {\left( 0,1\right) }^{N}$，集合$\mathcal{V}.{m}_{v} = \Pr \left( {v \in  {\mathcal{V}}^{\left( r\right) }}\right)$中的节点上的$\mathbf{m} \in  {\left( 0,1\right) }^{N}$是节点级掩码，它表示节点$v \in  \mathcal{V}$被分类到基本原理子图的概率。其公式表示为:

$$
m = \sigma \left( {{\mathrm{{MLP}}}_{1}\left( {{\mathrm{{GNN}}}_{1}\left( g\right) }\right) }\right)  \tag{43}
$$

GREA uses another GNN encoder to generate contextualized node representations $\mathbf{H} : \mathbf{H} = {\mathrm{{GNN}}}_{2}\left( g\right)$ . With $\mathbf{m}$ and $\mathbf{H}$ , the rationale subgraph and environment subgraph can be easily separated in the latent space. The rationale and environment subgraph are generated as,

GREA使用另一个GNN编码器来生成上下文节点表征$\mathbf{H} : \mathbf{H} = {\mathrm{{GNN}}}_{2}\left( g\right)$。利用$\mathbf{m}$和$\mathbf{H}$，可以在潜在空间中轻松分离基本原理子图和环境子图。基本原理子图和环境子图生成如下:

$$
{\mathbf{h}}^{\left( r\right) } = {\mathbf{1}}_{N}^{\top } \cdot  \left( {\mathbf{m} \times  \mathbf{H}}\right) ,\;{\mathbf{h}}^{\left( e\right) } = {1}_{N}^{\top } \cdot  \left( {\left( {{1}_{N} - \mathbf{m}}\right)  \times  \mathbf{H}}\right) ,
$$

where ${\mathbf{1}}_{N}$ denotes the $N$ -size column vector with all entries as 1, and ${\mathbf{h}}^{\left( r\right) },{\mathbf{h}}^{\left( e\right) } \in  {\mathbb{R}}^{d}$ are the representation vectors of rationale graph ${g}^{\left( r\right) }$ and environment graph ${g}^{\left( e\right) }$ , respectively. After the rationale and environment separation, the model leverages two augmentation strategies to make predictions. First, it combines each rationale subgraph with multiple environment subgraphs to generate augmented samples which can improve the model's robustness and generalization. The prediction is made as,

其中${\mathbf{1}}_{N}$表示所有元素均为1的$N$维列向量，${\mathbf{h}}^{\left( r\right) },{\mathbf{h}}^{\left( e\right) } \in  {\mathbb{R}}^{d}$分别是基本原理图${g}^{\left( r\right) }$和环境图${g}^{\left( e\right) }$的表征向量。在分离基本原理和环境后，模型利用两种增强策略进行预测。首先，它将每个基本原理子图与多个环境子图组合以生成增强样本，这可以提高模型的鲁棒性和泛化能力。预测公式如下:

$$
{\widehat{y}}_{\left( i, j\right) } = {\operatorname{MLP}}_{2}\left( {\mathbf{h}}_{\left( i, j\right) }\right)  \tag{44}
$$

where ${\widehat{y}}_{i, j}$ is computed as,

其中${\widehat{y}}_{i, j}$计算如下:

$$
{\mathbf{h}}_{\left( i, j\right) } = \operatorname{AGG}\left( {{\mathbf{h}}_{i}^{\left( r\right) },{\mathbf{h}}_{j}^{\left( e\right) }}\right)  = {\mathbf{h}}_{i}^{\left( r\right) } + {\mathbf{h}}_{j}^{\left( e\right) } \tag{45}
$$

Second, it removes the environment subgraph and uses only the rationale subgraphs to make predictions as follows,

其次，它移除环境子图，仅使用基本原理子图进行如下预测:

$$
{\widehat{y}}_{i}^{\left( r\right) } = {\mathrm{{MLP}}}_{2}\left( {\mathbf{h}}_{i}^{\left( r\right) }\right)  \tag{46}
$$

For instance, Fan et al. [65] propose to leverage causality to overcome the subgraph-level spurious correlations to improve the GNN generalizability. They analyzed the degeneration of GNNs from a causal view and propose a novel causal variable distinguishing regularizer to decorrelate each high-level variable pair by learning a set of sample weights. The sample reweighting method aids in eliminating the dependence between high-level variables, where non-linear dependence is measured by weighted Hilbert-Schmidt Independence Criterion (HSIC) [45]. HSIC is formulated as,

例如，Fan等人[65]提出利用因果关系来克服子图级别的虚假相关性，以提高GNN的泛化能力。他们从因果角度分析了GNN的退化问题，并提出了一种新颖的因果变量区分正则化器，通过学习一组样本权重来使每对高级变量去相关。样本重加权方法有助于消除高级变量之间的依赖关系，其中非线性依赖关系通过加权希尔伯特 - 施密特独立性准则(weighted Hilbert - Schmidt Independence Criterion，HSIC)[45]来测量。HSIC公式表示为:

$$
{\operatorname{HSIC}}_{0}^{k, l}\left( {U, V,\mathbf{w}}\right)  = {\left( m - 1\right) }^{-2}\operatorname{tr}\left( {\widehat{\mathbf{K}}\mathbf{P}\widehat{\mathbf{L}}\mathbf{P}}\right)  \tag{47}
$$

where $\widehat{\mathbf{K}},\widehat{\mathbf{L}} \in  {\mathbb{R}}^{m \times  m}$ are weighted RBF kernel matrices containing entries ${\widehat{\mathbf{K}}}_{ij} = k\left( {{\widehat{U}}_{i},{\widehat{U}}_{j}}\right)$ and ${\widehat{\mathbf{L}}}_{ij} = l\left( {{\widehat{V}}_{i},{\widehat{V}}_{j}}\right)$ , $\widehat{U} = \left( {\mathbf{w} \cdot  {\mathbf{1}}^{\mathrm{T}}}\right)  \odot  U$ , and $\widehat{V} = \left( {\mathbf{w} \cdot  {\mathbf{1}}^{\mathrm{T}}}\right)  \odot  V$ . Finally, the weights are optimized as,

其中 $\widehat{\mathbf{K}},\widehat{\mathbf{L}} \in  {\mathbb{R}}^{m \times  m}$ 是加权径向基函数(RBF)核矩阵，包含元素 ${\widehat{\mathbf{K}}}_{ij} = k\left( {{\widehat{U}}_{i},{\widehat{U}}_{j}}\right)$ 和 ${\widehat{\mathbf{L}}}_{ij} = l\left( {{\widehat{V}}_{i},{\widehat{V}}_{j}}\right)$ 、 $\widehat{U} = \left( {\mathbf{w} \cdot  {\mathbf{1}}^{\mathrm{T}}}\right)  \odot  U$ 以及 $\widehat{V} = \left( {\mathbf{w} \cdot  {\mathbf{1}}^{\mathrm{T}}}\right)  \odot  V$ 。最后，权重优化如下:

$$
{\mathbf{w}}^{ * } = \underset{\mathbf{w} \in  {\Delta }_{m}}{\arg \min }\mathop{\sum }\limits_{{1 < p < {n}_{L}}}{\operatorname{HSIC}}_{0}^{k, l}\left( {{\mathbf{H}}_{,0 : d},{\mathbf{H}}_{,\left( {p - 1}\right) d : {pd}},\mathbf{w}}\right) , \tag{48}
$$

where ${\Delta }_{m} = \left\{  {\mathbf{w} \in  {\mathbb{R}}_{ + }^{n} \mid  \mathop{\sum }\limits_{{i = 1}}^{m}{\mathbf{w}}_{i} = m}\right\}$ , and we utilize ${\mathbf{H}}_{,0 : d}$ denotes the treatment variable, and ${\mathbf{H}}_{,\left( {p - 1}\right) d : {pd}}$ denotes the confounders, $\mathbf{w} = \operatorname{softmax}\left( \mathbf{w}\right)$ to satisfy this constrain Hence, reweighting training samples with the optimal ${\mathbf{w}}^{ * }$ can mitigate the dependence between high-level treatment variable with confounders to the greatest extent. Sui et al. [66] propose a causal attention model that could distinguish between causal and confounding features of a graph. The authors leverage the backdoor adjustment to disentangle the causal and confounding features. The proposed model separates the causal and confounding features from full graphs using attention mechanism.

其中 ${\Delta }_{m} = \left\{  {\mathbf{w} \in  {\mathbb{R}}_{ + }^{n} \mid  \mathop{\sum }\limits_{{i = 1}}^{m}{\mathbf{w}}_{i} = m}\right\}$ ，并且我们利用 ${\mathbf{H}}_{,0 : d}$ 表示处理变量， ${\mathbf{H}}_{,\left( {p - 1}\right) d : {pd}}$ 表示混杂因素， $\mathbf{w} = \operatorname{softmax}\left( \mathbf{w}\right)$ 以满足此约束。因此，用最优的 ${\mathbf{w}}^{ * }$ 对训练样本进行重新加权，可以最大程度地减轻高级处理变量与混杂因素之间的依赖关系。Sui 等人 [66] 提出了一种因果注意力模型，该模型可以区分图的因果特征和混杂特征。作者利用后门调整来解开因果特征和混杂特征。所提出的模型使用注意力机制从完整图中分离出因果特征和混杂特征。

Bevilacqua et al. [67] leverage causal models inspired by Stochastic Block Models (SBM) [68] and graphon random graph models [69] to learn size-invariant representations that better extrapolate between test and train graph data. The authors construct graph representations from subgraph densities and use attribute symmetry regularization to mitigate the shift of graph size and vertex attribute distributions.

Bevilacqua 等人 [67] 利用受随机块模型(SBM) [68] 和图子随机图模型 [69] 启发的因果模型，来学习大小不变的表示，以便在测试图数据和训练图数据之间更好地进行外推。作者从子图密度构建图表示，并使用属性对称正则化来减轻图大小和顶点属性分布的偏移。

Chen et al. [70] propose to provide guaranteed OOD generalization on graphs under different distribution shifts. The authors leverage three SCMs to characterize the distribution shifts that could happen on graphs. They further argue that GNNs are invariant to distribution shifts if they focus only on a invariant and critical subgraph ${G}_{c}$ that contains the most of the information in $G$ about the underlying causes of the label. To learn the invariant representation, the authors propose to align with two causal mechanisms that occur during graph generation, i.e., $C \rightarrow  G$ and $\left( {{G}_{s},{E}_{G},{G}_{c}}\right)  \rightarrow  G$ where $C$ represents the causal features, $S$ represents the non-causal features, ${E}_{G}$ denotes the environment, ${G}_{c}$ inherits the invariant information of $C$ that would not be affected by the interventions, and ${G}_{s}$ inherits the varying features. The alignment is realized by decomposing a GNN into a featurizer GNN $g : \mathcal{G} \rightarrow  {\mathcal{G}}_{c}$ aiming to identify the desired ${G}_{c}$ ; b) a classifier GNN ${f}_{c} : {\mathcal{G}}_{c} \rightarrow  \mathcal{Y}$ that predicts the label $Y$ based on the estimated ${G}_{c}$ , where ${\mathcal{G}}_{c}$ refers to the space of subgraphs of $G$ . Formally, the learning objectives of ${f}_{c}$ and $g$ can be formulated as:

Chen 等人 [70] 提出在不同分布偏移的情况下，为图提供有保证的分布外(OOD)泛化能力。作者利用三个结构因果模型(SCM)来描述图上可能发生的分布偏移。他们进一步认为，如果图神经网络(GNN)仅关注一个不变且关键的子图 ${G}_{c}$ ，该子图包含 $G$ 中关于标签潜在原因的大部分信息，那么 GNN 对分布偏移是不变的。为了学习不变表示，作者提出与图生成过程中出现的两种因果机制对齐，即 $C \rightarrow  G$ 和 $\left( {{G}_{s},{E}_{G},{G}_{c}}\right)  \rightarrow  G$ ，其中 $C$ 表示因果特征， $S$ 表示非因果特征， ${E}_{G}$ 表示环境， ${G}_{c}$ 继承了 $C$ 中不受干预影响的不变信息， ${G}_{s}$ 继承了变化的特征。这种对齐是通过将 GNN 分解为:a)一个特征提取 GNN $g : \mathcal{G} \rightarrow  {\mathcal{G}}_{c}$ ，旨在识别所需的 ${G}_{c}$ ；b)一个分类器 GNN ${f}_{c} : {\mathcal{G}}_{c} \rightarrow  \mathcal{Y}$ ，它基于估计的 ${G}_{c}$ 预测标签 $Y$ ，其中 ${\mathcal{G}}_{c}$ 指的是 $G$ 的子图空间。形式上， ${f}_{c}$ 和 $g$ 的学习目标可以表述为:

$$
\mathop{\min }\limits_{{{f}_{c}, g}}R\left( {{f}_{c}\left( {\widehat{G}}_{c}\right) }\right) \text{, s.t.}{\widehat{G}}_{c} \bot  E,{\widehat{G}}_{c} = g\left( G\right) \text{,}
$$

where $R\left( {{f}_{c}\left( {\widehat{G}}_{c}\right) }\right)$ is the empirical risk of ${f}_{c}$ that takes ${\widehat{G}}_{c}$ as innuts to predict label $Y$ for $G$ , and ${\widehat{G}}_{c}$ is the intermediate subgraph containing information about $C$ and is independent of $E$ . The final objective is given by,

其中 $R\left( {{f}_{c}\left( {\widehat{G}}_{c}\right) }\right)$ 是 ${f}_{c}$ 的经验风险，它将 ${\widehat{G}}_{c}$ 作为输入，为 $G$ 预测标签 $Y$，并且 ${\widehat{G}}_{c}$ 是包含关于 $C$ 信息的中间子图，且与 $E$ 无关。最终目标由下式给出:

$$
\mathop{\max }\limits_{{{f}_{c}, g}}I\left( {{\widehat{G}}_{c};Y}\right)  + I\left( {{\widehat{G}}_{s};Y}\right) ,
$$

$$
\text{s.t.}{\widehat{G}}_{c} \in  \underset{{G}_{c} = g\left( G\right) ,{\widetilde{G}}_{c} = g\left( \widetilde{G}\right) }{\arg \max }I\left( {{\widehat{G}}_{c};{\widetilde{G}}_{c} \mid  Y}\right) \text{,} \tag{49}
$$

$$
I\left( {{\widehat{G}}_{s};Y}\right)  \leq  I\left( {{\widehat{G}}_{c};Y}\right) ,{\widehat{G}}_{s} = G - g\left( G\right) ,
$$

This work differs from [67] as it establishes generic SCMs that are compatible with several graph generation models, and different types of distribution shifts. Wu et al. [71] aims at identifying graph rationales that capture the invariant causal patterns. To this end, the authors propose Discovering Invariant Rationales (DIR), which leverages causal interventions to instantiate environments and further distinguish the causal and non-causal parts. The task of invariant rationalization can be formulated as,

这项工作与文献 [67] 不同，因为它建立了与多种图生成模型和不同类型的分布偏移兼容的通用结构因果模型(Structural Causal Models，SCMs)。Wu 等人 [71] 旨在识别能够捕捉不变因果模式的图基本原理。为此，作者提出了发现不变基本原理(Discovering Invariant Rationales，DIR)方法，该方法利用因果干预来实例化环境，并进一步区分因果和非因果部分。不变合理化任务可以表述为:

$$
\mathop{\min }\limits_{{{h}_{\widetilde{C}},{h}_{\widehat{Y}}}}\mathcal{R}\left( {{h}_{\widehat{Y}} \circ  {h}_{\widetilde{C}}\left( G\right) , Y}\right) ,\;\text{ s.t. }Y \bot  \widetilde{S} \mid  \widetilde{C}, \tag{50}
$$

where ${h}_{\widetilde{C}}$ discovers rationale $\widetilde{C}$ from the observed $G,{h}_{\widetilde{Y}}$ represents the classifier, $\widetilde{C}$ is the causal rationale and $\widetilde{S} = G \smallsetminus  \widetilde{C}$ is the complement of $\widetilde{C}$ . Furthermore, to obtain the environments the authors generate $s$ -interventional distribution by doing intervention ${do}\left( {S = s}\right)$ on $S$ , which removes every link from the parents ${PA}\left( S\right)$ to the variable $S$ and fixes $S$ to the specific value $s$ . By stratifying different values $\mathbb{S} = \{ s\}$ , they obtain multiple $s$ -interventional distributions. The DIR Risk is formulated as,

其中 ${h}_{\widetilde{C}}$ 从观察到的 $G,{h}_{\widetilde{Y}}$ 中发现基本原理 $\widetilde{C}$，$G,{h}_{\widetilde{Y}}$ 表示分类器，$\widetilde{C}$ 是因果基本原理，$\widetilde{S} = G \smallsetminus  \widetilde{C}$ 是 $\widetilde{C}$ 的补集。此外，为了获得环境，作者通过对 $S$ 进行干预 ${do}\left( {S = s}\right)$ 来生成 $s$ -干预分布，这会移除从父节点 ${PA}\left( S\right)$ 到变量 $S$ 的每个链接，并将 $S$ 固定为特定值 $s$。通过对不同的值 $\mathbb{S} = \{ s\}$ 进行分层，他们获得了多个 $s$ -干预分布。DIR 风险表述为:

$$
\min {\mathcal{R}}_{\mathrm{{DIR}}} = {\mathbb{E}}_{s}\left\lbrack  {\mathcal{R}\left( {h\left( G\right) , Y \mid  \operatorname{do}\left( {S = s}\right) }\right) }\right\rbrack   +  \tag{51}
$$

$$
\lambda {\operatorname{Var}}_{s}\left( {\{ \mathcal{R}\left( {h\left( G\right) , Y \mid  \operatorname{do}\left( {S = s}\right) }\right) \} }\right)
$$

where $\mathcal{R}\left( {h\left( G\right) , Y \mid  {do}\left( {S = s}\right) }\right)$ computes the risk under the $s$ -interventional distribution, Var $\left( \cdot \right)$ calculates the variance of risks over different $s$ -interventional distributions and $\lambda$ is a hyper-parameter to control the strength of invariant learning.

其中 $\mathcal{R}\left( {h\left( G\right) , Y \mid  {do}\left( {S = s}\right) }\right)$ 计算在 $s$ -干预分布下的风险，Var $\left( \cdot \right)$ 计算不同 $s$ -干预分布下风险的方差，$\lambda$ 是一个超参数，用于控制不变学习的强度。

## 4 Benchmark, Evaluation, and Code Repositories

## 4 基准、评估和代码仓库

In this section, we provide a comprehensive review of benchmark datasets and evaluation metrics for all three types of data, i.e., image, text and graph, for the causal domain generalization task.

在本节中，我们对因果领域泛化任务的所有三种类型的数据(即图像、文本和图)的基准数据集和评估指标进行了全面回顾。

### 4.1 Benchmark Datasets

### 4.1 基准数据集

Causality-aware domain generalization has been studied across various applications, including but not limited to computer vision, natural language processing, and graphs. Tables 1 and 2 summarize the commonly used datasets based on the different applications. In this section, we briefly describe these datasets and the applications.

因果感知领域泛化已经在各种应用中得到研究，包括但不限于计算机视觉、自然语言处理和图。表 1 和表 2 总结了基于不同应用的常用数据集。在本节中，我们简要描述这些数据集及其应用。

Face Detection can be decomposed into multiple tasks, such as face attributes detection, and human face synthesis. Some of the benchmark datasets are CelebA [72] which contains auxiliary attribute labels (such as GENDER, SMILE) to improve the generalization performance. A range of datasets, including Face-Forensics++ [73] and DeeperForensics-1.0 [74], were leveraged to facilitate generalization for the human face synthesis task.

人脸检测可以分解为多个任务，如人脸属性检测和人脸合成。一些基准数据集包括 CelebA [72]，它包含辅助属性标签(如性别、微笑)以提高泛化性能。一系列数据集，包括 Face - Forensics++ [73] 和 DeeperForensics - 1.0 [74]，被用于促进人脸合成任务的泛化。

Emotion detection has been studied extensively to aid applications such as mental health care and driver drowsiness detection. Benchmark datasets such as CK+ [75], MMI [76], and Oulu-CASIA [77] have been leveraged to test generalization capabilities for emotion detection. These datasets contain multiple face angles along with basic expression labels such as anger, disgust, and fear.

情感检测已经得到了广泛研究，以辅助心理健康护理和驾驶员困倦检测等应用。诸如 CK+ [75]、MMI [76] 和 Oulu - CASIA [77] 等基准数据集已被用于测试情感检测的泛化能力。这些数据集包含多个面部角度以及愤怒、厌恶和恐惧等基本表情标签。

Handwritten digit recognition are a good example of distribution shifts as the different writing styles of people are as different domains and the shape of the digit remains invariant. Many methods have leveraged benchmark digits datasets to solve the generalization problem in digits recognition. Some majorly applied datasets are FashionMNIST [78] (which is a collection of grayscale fashion article images), ColoredMNIST+ [40], MNIST-M [79], SVHN [80], and SYN [79], MNIST [3] and its variants such as ColoredMNIST [4] (where the digits have different color distributions) and RotatedMNIST [81] (where the digits are rotated on different angles).

手写数字识别是分布偏移的一个很好的例子，因为人们不同的书写风格就像不同的领域，而数字的形状保持不变。许多方法利用基准数字数据集来解决数字识别中的泛化问题。一些主要应用的数据集包括 FashionMNIST [78](这是一个灰度时尚物品图像的集合)、ColoredMNIST+ [40]、MNIST - M [79]、SVHN [80] 和 SYN [79]、MNIST [3] 及其变体，如 ColoredMNIST [4](其中数字具有不同的颜色分布)和 RotatedMNIST [81](其中数字以不同角度旋转)。

Medical Imaging refers to an umbrella term comprising multiple tasks. In the medical scenario, domain shifts are mainly caused by different acquisition processes. Thus, to improve the generalization performance, a range of works [13, 19, 49] leveraged real-world medical imaging datasets such as Alzheimer's Disease Neuroimaging Initiative (ADNI) [82]. Furthermore, the Chest X-rays dataset contains images from three sources: NIH [83], ChexPert [84] and RSNA [85]. The central task for this dataset was to classify the image to whether the patient has Pneumonia (1) or not (0).

医学成像(Medical Imaging)是一个涵盖多项任务的统称。在医学场景中，领域偏移主要由不同的采集过程引起。因此，为了提高泛化性能，一系列研究[13, 19, 49]利用了现实世界的医学成像数据集，如阿尔茨海默病神经影像学倡议(Alzheimer's Disease Neuroimaging Initiative，ADNI)[82]。此外，胸部X光数据集包含来自三个来源的图像:美国国立卫生研究院(NIH)[83]、ChexPert数据集[84]和美国放射学会影像网络(RSNA)[85]。该数据集的核心任务是对图像进行分类，判断患者是否患有肺炎(1表示是，0表示否)。

Body pose estimation refers to the 3D pose estimation task. Recently the authors et al. [17] proposed to leverage causality to improve the cross-domain pose estimation problem. They utilize multiple benchmark datasets such as Human3.6M [86], 3DPW [87], MPI-INF-3DHP (3DHP) [88], SURREAL [89], and HumanEva [90] for body pose estimation.

人体姿态估计(Body pose estimation)指的是三维姿态估计任务。最近，文献[17]的作者等人提出利用因果关系来解决跨领域姿态估计问题。他们利用多个基准数据集进行人体姿态估计，如Human3.6M数据集[86]、3DPW数据集[87]、马克斯·普朗克信息研究所三维人体姿态数据集(MPI-INF-3DHP，3DHP)[88]、SURREAL数据集[89]和HumanEva数据集[90]。

Person Re-IDentification aims at matching person images of the same identity across multiple camera views. In this scenario, the domain shift arises in image resolution, viewpoint, lighting condition, background, etc. Some benchmark datasets for this task are CUHK02 [91], CUHK03 [92], Market1501 [93], DukeMTMC-ReID [94], CUHKSYSU PersonSearch [95].

行人重识别(Person Re-IDentification)旨在跨多个摄像头视角匹配同一身份的行人图像。在这种场景下，领域偏移出现在图像分辨率、视角、光照条件、背景等方面。该任务的一些基准数据集包括香港中文大学02数据集(CUHK02)[91]、香港中文大学03数据集(CUHK03)[92]、Market1501数据集[93]、杜克多目标多摄像头行人重识别数据集(DukeMTMC-ReID)[94]、香港中文大学SYSU行人搜索数据集(CUHKSYSU PersonSearch)[95]。

<table><tr><td>$\mathbf{{Dataset}}$</td><td>Description</td><td>Domain</td><td>Downstream Task</td><td>Basic Statistics of the Dataset</td><td>Useful in which Category and How?</td></tr><tr><td>CelebA</td><td>is a large-scale face attributes dataset. The images in this dataset cover large pose variations and background clutter.</td><td>Vision</td><td>Face Detection</td><td>202,599 celebrity images 10,177 unique celebrities 40 attribute annotations.</td><td>Since it provides access to auxiliary labels such as GENDER and SMILE, it has been utilized across multiple causal methods that aim to learn and identify the causal features of an image.</td></tr><tr><td>CK+</td><td>The Extended Cohn-Kanade (CK+) dataset contains video sequences ranging from 18 to 50 years of age with various genders and heritage. The videos are labeled to denote the emotions such as anger, disgust, and so on.</td><td>Vision</td><td>Emotion Detection</td><td>593 video sequences 123 different subjects 327 labelled videos</td><td>This dataset has been used for causal data augmentation by combining different features useful to predict emotions with confounding features such as noise.</td></tr><tr><td>MNIST</td><td>The MNIST database (Modified National Institute of Standards and Technology database) is a large collection of handwritten digits.</td><td>Vision</td><td>Digit Recognition</td><td>70,000 instances 10 classes</td><td>MNIST is a part of the DigitsDG dataset that contains 4 domains, including MNIST, MNIST-M SVHN and SYN. It has been leveraged by causal methods trying to learn and identify the causal features.</td></tr><tr><td>CMNIST</td><td>Colored MNIST (CMNIST) is a synthetic binary classification task derived from MNIST. In CMNIST the color and the label have a different correlation in the train set when compared to the correlation in the test set.</td><td>Vision</td><td>Digit Recognition</td><td>70,000 instances 2 classes</td><td>CMNIST was a synthetic dataset introduced in the IRM paper. Since the spurrious correlation between color and the label changes in the training and test set, this dataset has been used in a wide-range of works that learn invariance by transfering the causal mechanisms.</td></tr><tr><td>Chest X-Ray14</td><td>ChestX-ray14 is a medical imaging dataset which contains frontal-view X-ray images of unique patients along with disease labels mined from text.</td><td>Vision</td><td>Medical Imaging</td><td>112,120 X-ray images 30,805 unique patients 23 years worth data.</td><td>Chest X-ray14 is a part of the ChestX-rays dataset that contains 3 domains, including, ChestXray14, MIMIC-CXR, and Stanford CheXpert. These datasets have been leveraged in causal methods trying to learn and identify the causal features.</td></tr><tr><td>Human3.6M</td><td>Human3.6M is a 3D human pose and corresponding images dataset. It contains various actors both male and female posing in different scenarios.</td><td>Vision</td><td>Human Pose Estimation</td><td>3.6 million images 11 professional actors 17 scenarios</td><td>Since this dataset provides access to different poses under different domains, this dataset has been leveraged by causal data augmentation approaches where given the domain and the content, the models generate causally augmented images to train the model.</td></tr><tr><td>CUHK03</td><td>The CUHK03 consists of images of different identities. where 6 campus cameras were deployed for image collection and each identity is captured by 2 campus cameras. This dataset provides two types of annotations, one by manually labelled bounding boxes and the other by bounding boxes produced by an automatic detector.</td><td>Vision</td><td>Person Re-ID</td><td>14,097 images 1,467 identities</td><td>Since this dataset reflects the same person across multiple backgrounds, this dataset has been leveraged by causal methods that aim to learn and identify the causal features present in an image.</td></tr><tr><td>WaterBirds</td><td>The WaterBirds dataset consists of water birds and land birds. It was extracted from Caltech-UCSD Birds-200-2011 benchmark dataset, with water and land background extracted from the Places dataset</td><td>Vision</td><td>Birds Classification</td><td>$\sim  5,{000}$ images 2 classes</td><td>Since this dataset contains auxiliary labels such as the label for the background of an image, they have been utilized in causal methods that aim to learn and identify the causal features present in an image.</td></tr><tr><td>Terra Incognita</td><td>This dataset contains images from twenty camera traps which were deployed to monitor animal populations. Since the traps are fixed, the background changes little across images. Capture is triggered automatically, thus eliminating human bias</td><td>Vision</td><td>Animals Classification</td><td>24.788 images 10 classes 4 domains</td><td>Since this dataset contain high cross-domain discrepancies it has been used in causal methods that aim to learn and identify the causal features and by causal methods that capture invariance through the transfer of causal mechanisms</td></tr><tr><td>PACS</td><td>PACS refers to Photo, Art, Cartoon, and Sketch. Each of the domain have seven categories.</td><td>Vision</td><td>Object Recognition</td><td>9,985 images 4 domains 7 categories</td><td>Since this dataset contains the representation of the same object across multiple image styles it allows models to distinguish between causal and non-causal features. Thus, it is widely used in causal methods that aim to learn and identify the causal features present in an image.</td></tr><tr><td>OfficeHome</td><td>Office-Home is a benchmark dataset that represents images of the same object under different scenarios, including Art, Clipart, Product and Real-World.</td><td>Vision</td><td>Object Recognition</td><td>15.500 images 65 categories 4 domains</td><td>Since this dataset contains the representation of the same object across multiple image styles. it allows models to distinguish between causal and non-causal features. Thus, it is widely used in causal methods that aim to learn and identify the causal features present in an image.</td></tr></table>

<table><tbody><tr><td>$\mathbf{{Dataset}}$</td><td>描述</td><td>领域</td><td>下游任务</td><td>数据集基本统计信息</td><td>在哪些类别中有用以及如何使用？</td></tr><tr><td>CelebA</td><td>是一个大规模人脸属性数据集。该数据集中的图像涵盖了较大的姿态变化和杂乱的背景。</td><td>视觉</td><td>人脸检测</td><td>202,599张名人图像，10,177个独特名人，40个属性标注。</td><td>由于它提供了诸如性别和微笑等辅助标签，因此已被多种旨在学习和识别图像因果特征的因果方法所利用。</td></tr><tr><td>CK+</td><td>扩展的科恩 - 卡纳德(CK+)数据集包含年龄从18岁到50岁不等、不同性别和种族的视频序列。这些视频被标注以表示愤怒、厌恶等情绪。</td><td>视觉</td><td>情绪检测</td><td>593个视频序列，123个不同的受试者，327个标注视频</td><td>该数据集已通过将对预测情绪有用的不同特征与诸如噪声等混淆特征相结合，用于因果数据增强。</td></tr><tr><td>MNIST</td><td>MNIST数据库(修改后的美国国家标准与技术研究院数据库)是一个大规模的手写数字集合。</td><td>视觉</td><td>数字识别</td><td>70,000个实例，10个类别</td><td>MNIST是DigitsDG数据集的一部分，该数据集包含4个领域，包括MNIST、MNIST - M、SVHN和SYN。它已被试图学习和识别因果特征的因果方法所利用。</td></tr><tr><td>CMNIST</td><td>彩色MNIST(CMNIST)是一个从MNIST派生的合成二分类任务。在CMNIST中，训练集中颜色和标签的相关性与测试集中的相关性不同。</td><td>视觉</td><td>数字识别</td><td>70,000个实例，2个类别</td><td>CMNIST是IRM论文中引入的一个合成数据集。由于颜色和标签之间的虚假相关性在训练集和测试集中发生变化，该数据集已被广泛应用于通过转移因果机制来学习不变性的研究中。</td></tr><tr><td>Chest X - Ray14</td><td>ChestX - ray14是一个医学影像数据集，它包含独特患者的正位X射线图像以及从文本中挖掘出的疾病标签。</td><td>视觉</td><td>医学影像</td><td>112,120张X射线图像，30,805个独特患者，23年的数据。</td><td>Chest X - ray14是ChestX - rays数据集的一部分，该数据集包含3个领域，包括ChestXray14、MIMIC - CXR和斯坦福CheXpert。这些数据集已被试图学习和识别因果特征的因果方法所利用。</td></tr><tr><td>Human3.6M</td><td>Human3.6M是一个三维人体姿态及相应图像的数据集。它包含不同场景下不同性别(男性和女性)的演员摆姿势的图像。</td><td>视觉</td><td>人体姿态估计</td><td>360万张图像，11名专业演员，17种场景</td><td>由于该数据集提供了不同领域下的不同姿势，因此它已被因果数据增强方法所利用，在给定领域和内容的情况下，模型生成因果增强图像来训练模型。</td></tr><tr><td>CUHK03</td><td>CUHK03由不同身份的图像组成。其中部署了6个校园摄像头进行图像采集，每个身份由2个校园摄像头捕捉。该数据集提供两种类型的标注，一种是手动标注的边界框，另一种是自动检测器生成的边界框。</td><td>视觉</td><td>行人重识别</td><td>14,097张图像，1,467个身份</td><td>由于该数据集反映了同一人在多个背景下的情况，因此它已被旨在学习和识别图像中因果特征的因果方法所利用。</td></tr><tr><td>WaterBirds</td><td>WaterBirds数据集由水鸟和陆鸟组成。它是从加州理工学院 - 加州大学圣地亚哥分校鸟类200 - 2011基准数据集中提取的，水和陆地背景是从Places数据集中提取的。</td><td>视觉</td><td>鸟类分类</td><td>$\sim  5,{000}$张图像，2个类别</td><td>由于该数据集包含诸如图像背景标签等辅助标签，因此它们已被旨在学习和识别图像中因果特征的因果方法所利用。</td></tr><tr><td>Terra Incognita</td><td>该数据集包含来自20个相机陷阱的图像，这些相机陷阱用于监测动物种群。由于陷阱是固定的，图像之间的背景变化很小。捕捉是自动触发的，从而消除了人为偏差。</td><td>视觉</td><td>动物分类</td><td>24,788张图像，10个类别，4个领域</td><td>由于该数据集包含较高的跨领域差异，因此它已被旨在学习和识别因果特征的因果方法以及通过转移因果机制来捕捉不变性的因果方法所使用。</td></tr><tr><td>PACS</td><td>PACS指照片、艺术、卡通和素描。每个领域有七个类别。</td><td>视觉</td><td>目标识别</td><td>9,985张图像，4个领域，7个类别</td><td>由于该数据集包含同一物体在多种图像风格下的表示，因此它允许模型区分因果特征和非因果特征。因此，它被广泛应用于旨在学习和识别图像中因果特征的因果方法中。</td></tr><tr><td>OfficeHome</td><td>Office - Home是一个基准数据集，它表示同一物体在不同场景下的图像，包括艺术、剪贴画、产品和现实世界。</td><td>视觉</td><td>目标识别</td><td>15,500张图像，65个类别，4个领域</td><td>由于该数据集包含同一对象在多种图像风格下的表示，它使模型能够区分因果特征和非因果特征。因此，它被广泛应用于旨在学习和识别图像中因果特征的因果方法中。</td></tr></tbody></table>

Table 1: A description of different vision benchmark datasets and how they have been leveraged by different causality-aware domain generalization methods.

表1:不同视觉基准数据集的描述，以及不同的因果感知领域泛化方法如何利用这些数据集。

<table><tr><td>$\mathbf{{Dataset}}$</td><td>Description</td><td>Domain</td><td>Downstream Task</td><td>Basic Statistics of the Dataset</td><td>Useful in which Category and How?</td></tr><tr><td>PROTEINS</td><td>PROTEINS is a dataset of proteins that are classified as enzymes or non-enzymes. Nodes represent the amino acids and two nodes are connected by an edge if they are less than 6 Angstroms apart.</td><td>Graph</td><td>Graph Classification</td><td>1,113 graphs 39 Avg. no. of nodes 2 classes</td><td>This dataset is used along with other biological graph datasets such as MUTAG and NCI1 by causal methods that aim to learn and identify the causal features present in an image.</td></tr><tr><td>Multi-NLI</td><td>The Multi-Genre Natural Language Inference dataset is a collection of written and spoken english data over ten different genres.</td><td>Text</td><td>Natural Language Inference</td><td>433K sentence-pairs 10 domains</td><td>This dataset contains spurious correlations as usually, the second sentence in a pair containing a negation is classified as contradiction. Works leveraging causal data augmentation have tried to tackle this spuriousness by generating counterfactuals for this situation.</td></tr><tr><td>CivilComments</td><td>Civil Comments contains the archive of the Civil Comments platform. It is annotated for toxicity across different demographic groups in the english language.</td><td>Text</td><td>Toxicity Detection</td><td>~2 million comments 8 domains (demographic groups) 2 classes</td><td>This dataset has been leveraged by causal methods that aim to learn and identify the causal features from text as it is possible to find the spurious correlations between different words and the toxicity labels of the comments.</td></tr><tr><td>Amazon Kindle Reviews</td><td>The Amazon Kindle Reviews dataset contains product reviews from kindle. The main goal is to infer the review's sentiment as positive or negative.</td><td>Text</td><td>Sentiment Classification</td><td>10,500 reviews</td><td>This dataset is leveraged by the causal data augmentation methods as these models perform data augmentations on non-causal (non-sentimental) words to study the domain generalization problem. It has also been used by causal methods that aim to learn and identify the causal features from text as the sentimental words have a causal relation to the sentiment classification task.</td></tr></table>

<table><tbody><tr><td>$\mathbf{{Dataset}}$</td><td>描述</td><td>领域</td><td>下游任务</td><td>数据集的基本统计信息</td><td>在哪些类别中有用以及如何使用？</td></tr><tr><td>蛋白质数据集(PROTEINS)</td><td>蛋白质数据集(PROTEINS)是一个蛋白质数据集，其中的蛋白质被分类为酶或非酶。节点代表氨基酸，如果两个节点之间的距离小于6埃，则它们通过一条边相连。</td><td>图</td><td>图分类</td><td>1113个图 平均节点数39 2个类别</td><td>该数据集与其他生物图数据集(如MUTAG和NCI1)一起被因果方法使用，这些方法旨在学习和识别图像中存在的因果特征。</td></tr><tr><td>多体裁自然语言推理数据集(Multi - NLI)</td><td>多体裁自然语言推理数据集(Multi - NLI)是一个包含十种不同体裁的书面和口语英语数据的集合。</td><td>文本</td><td>自然语言推理</td><td>43.3万个句子对 10个领域</td><td>该数据集包含虚假相关性，因为通常情况下，包含否定词的句子对中的第二个句子会被分类为矛盾。利用因果数据增强的方法试图通过为这种情况生成反事实来解决这种虚假性。</td></tr><tr><td>文明评论数据集(CivilComments)</td><td>文明评论数据集(CivilComments)包含文明评论平台的存档。它针对不同人口群体的英语评论进行了毒性标注。</td><td>文本</td><td>毒性检测</td><td>约200万条评论 8个领域(人口群体) 2个类别</td><td>该数据集被因果方法利用，这些方法旨在从文本中学习和识别因果特征，因为可以发现不同单词与评论的毒性标签之间的虚假相关性。</td></tr><tr><td>亚马逊Kindle评论数据集</td><td>亚马逊Kindle评论数据集包含Kindle的产品评论。主要目标是推断评论的情感是积极还是消极。</td><td>文本</td><td>情感分类</td><td>10500条评论</td><td>该数据集被因果数据增强方法利用，因为这些模型对非因果(非情感)词汇进行数据增强，以研究领域泛化问题。它也被旨在从文本中学习和识别因果特征的因果方法使用，因为情感词汇与情感分类任务存在因果关系。</td></tr></tbody></table>

Table 2: A description of different Graph and Text benchmark datasets and how they have been leveraged by different causality-aware domain generalization methods.

表2:不同图和文本基准数据集的描述，以及不同的因果感知领域泛化方法如何利用这些数据集。

Animal and Birds Classification refers to classifying different animals and bird species observed across multiple environments. For instance, the WaterBirds dataset contains images of water birds (Gulls) and land birds (Warblers) extracted from the Caltech-UCSD Birds-200- 2011 (CUB) dataset [96] with water and land background extracted from the Places dataset [97]. In addition, there are multiple datasets for animal classification, such as iWiLDSCam [98], and TerraIncognita [99].

动物和鸟类分类是指对在多个环境中观察到的不同动物和鸟类物种进行分类。例如，水鸟数据集(WaterBirds dataset)包含从加州理工学院 - 加州大学圣地亚哥分校鸟类200 - 2011数据集(Caltech - UCSD Birds - 200 - 2011，CUB)[96]中提取的水鸟(海鸥)和陆鸟(莺)的图像，其水和陆地背景则从地点数据集(Places dataset)[97]中提取。此外，还有多个用于动物分类的数据集，如iWiLDSCam [98]和TerraIncognita [99]。

Object Recognition is one of the most prominent tasks for studying the domain generalization problem, where the domain shift varies substantially across different datasets. For instance, PACS [100], OfficeHome [101], DomainNet [102] and ImageNet-R [103], deal with image style changes where the same object is varied across different styles. Another commonly used datasets are DomainNet [102], VLCS [104], ImageNet-C [105], NICO [106] and NICO++ [107].

目标识别是研究领域泛化问题最突出的任务之一，不同数据集之间的领域偏移差异很大。例如，PACS [100]、OfficeHome [101]、DomainNet [102]和ImageNet - R [103]处理的是图像风格变化，即同一物体在不同风格下呈现不同形态。其他常用的数据集还有DomainNet [102]、VLCS [104]、ImageNet - C [105]、NICO [106]和NICO++ [107]。

Graph Classification is a crucial activity when dealing with graph distribution shifts. For this endeavor, a variety of datasets have been chosen to help with domain generalization. One such small-scale real-world dataset is HIV, which was modified from MoleculeNet [108]. ZINC is a real-world dataset for molecular property regression from the ZINC database [109]. Motif is a synthetic base-motif dataset motivated by Spurious-Motif [71].

图分类是处理图分布偏移时的一项关键活动。为此，人们选择了各种数据集来辅助领域泛化。其中一个小规模的真实世界数据集是HIV，它是从分子网络数据集(MoleculeNet)[108]修改而来的。ZINC是一个来自ZINC数据库[109]的用于分子属性回归的真实世界数据集。Motif是一个受虚假主题(Spurious - Motif)[71]启发的合成基础主题数据集。

Node Classificiation is another prominent task when dealing with node classification. Currently there exists several datasets that contain the out-of-distribution samples to test graph generalization capabilities, such as Cora [110], and Arxiv [111]. There also exist synthetic dataset such CBAS derived from the BA-Shapes [112].

节点分类是处理节点分类问题时的另一个突出任务。目前有几个包含分布外样本的数据集可用于测试图的泛化能力，如科拉数据集(Cora)[110]和arxiv数据集[111]。也存在像从BA - 形状数据集(BA - Shapes)[112]派生而来的CBAS这样的合成数据集。

Sentiment Classification deals with the task of classifying sentiments from human documents. Currently there exists several benchmark datasets for this task, examples include, Amazon Reviews Dataset [113], IMDb dataset [114], FineFood dataset [115]. Various works such as [54] aim to utilize multiple datasets listed here by training the model on one of the benchmark datasets and evaluate it against the other benchmarks.

情感分类处理的是从人类文档中对情感进行分类的任务。目前有几个用于此任务的基准数据集，例如亚马逊评论数据集(Amazon Reviews Dataset)[113]、互联网电影数据库数据集(IMDb dataset)[114]、美食数据集(FineFood dataset)[115]。诸如[54]等各种研究旨在通过在其中一个基准数据集上训练模型，并在其他基准数据集上进行评估，来利用这里列出的多个数据集。

Toxicity Detection refers to the task of detecting toxicity in textual data. One of the well-known benchmarks is the CivilComments dataset [116]. When evaluating for the cross-domain generalizability, the model is tested to see whether the model can detect toxicity without depending on the demographic identities.

毒性检测是指检测文本数据中毒性的任务。其中一个著名的基准是文明评论数据集(CivilComments dataset)[116]。在评估跨领域泛化能力时，会测试模型是否能够在不依赖人口统计学身份的情况下检测毒性。

Natural Language Inference aims at classifying pair of texts based on their logical relationship. One of the benchmark datasets for NLI is MultiNLI [117]. A series of works such as [54] have utilized this benchmark.

自然语言推理旨在根据文本对之间的逻辑关系对其进行分类。自然语言推理(NLI)的基准数据集之一是多自然语言推理数据集(MultiNLI)[117]。诸如[54]等一系列研究都利用了这个基准。

### 4.2 Evaluation

### 4.2 评估

Causality-aware domain generalization methods employ evaluation mechanisms that are very similar to standard domain generalization methods. Furthermore, the causal theories and methodologies employed by these frameworks help in the identification of invariant relationships while doing the same downstream task. Thus, the evaluation procedure is determined by the technique's nature, i.e., whether the approach is a single source domain generalization (where the model is trained on data from a single source) or a multi-source domain generalization (where the model is trained on data from multiple sources).

因果感知领域泛化方法采用的评估机制与标准领域泛化方法非常相似。此外，这些框架所采用的因果理论和方法有助于在执行相同下游任务时识别不变关系。因此，评估过程由技术的性质决定，即该方法是单源领域泛化(模型在来自单一源的数据上进行训练)还是多源领域泛化(模型在来自多个源的数据上进行训练)。

For instance, the leave-one-domain-out rule is one of the most prominent when dealing with multi-source domain generalization [13, 23, 31, 118]. Per this rule, given a dataset containing at least two distinct domains, multiple are used as source domains for training the model while one is used as the target domain, on which the model is directly tested without any adaptation. Another commonly employed strategy for domain generalization is Training-domain validation set [19, 119]. In this setting, the source domains are split into two parts; one is used for training while the other is used for validation. While training the model, each domain's training parts are combined, and the validation parts are used to select the best model. When dealing with single domain generalization methods, the popular approach is to train the model on the source domain and directly evaluate it on the different test domains.

例如，留一域法(leave - one - domain - out rule)是处理多源领域泛化时最突出的规则之一[13, 23, 31, 118]。根据该规则，给定一个包含至少两个不同领域的数据集，将其中多个领域用作训练模型的源领域，而将一个领域用作目标领域，在该目标领域上直接对模型进行测试，无需任何调整。另一种常用的领域泛化策略是训练域验证集法(Training - domain validation set)[19, 119]。在这种设置中，源领域被分为两部分；一部分用于训练，另一部分用于验证。在训练模型时，将每个领域的训练部分合并，而验证部分用于选择最佳模型。在处理单领域泛化方法时，常用的方法是在源领域上训练模型，并直接在不同的测试领域上对其进行评估。

Classification accuracy, top-1 error rate, top-5 error rate, and DICE scores are some of the main measures used to assess these models. The classification accuracy metric indicates how well the model classifies samples. The top-1 error rate determines if the model's projected top class corresponds to the target label. In the instance of the Top-5 mistake rate, we examine whether or not the target label appears in the top-5 predictions. Finally, the DICE scores compare the pixel-by-pixel agreement of a projected segmentation with its matching ground truth. Aside from these commonly used metrics, some works [20] leveraged mean Corruption Error (mCE) and mean relative Corruption Error (mrCE), which are commonly used to evaluate a model's robustness.

分类准确率、前1错误率、前5错误率和DICE分数是用于评估这些模型的一些主要指标。分类准确率指标表明模型对样本的分类效果如何。前1错误率确定模型预测的顶级类别是否与目标标签相符。在前5错误率的情况下，我们检查目标标签是否出现在前5个预测中。最后，DICE分数比较预测分割与相应真实标签的逐像素一致性。除了这些常用指标外，一些研究[20]还利用了平均损坏误差(mean Corruption Error，mCE)和平均相对损坏误差(mean relative Corruption Error，mrCE)，这些指标通常用于评估模型的鲁棒性。

Although the causality-aware models strive to perform the same downstream job, we believe that causal evaluation procedures and metrics, in addition to the traditional setting, are required to verify the models' causal features. For example, Yang et.al [31] leveraged Maximal Information Coefficient (MIC) and Total Information Coefficient (TIC) [120] as additional evaluation metrics. They use these metrics because they reflect the degree of information relevance between the learnt representation and the ground truth labels of ideas, which is important because their model tries to learn causal representations.

尽管因果感知模型致力于执行相同的下游任务，但我们认为，除了传统设置外，还需要因果评估程序和指标来验证模型的因果特征。例如，Yang等人[31]利用最大信息系数(Maximal Information Coefficient，MIC)和总信息系数(Total Information Coefficient，TIC)[120]作为额外的评估指标。他们使用这些指标是因为它们反映了所学表示与想法的真实标签之间的信息相关程度，这很重要，因为他们的模型试图学习因果表示。

## 5 Conclusion

## 5 结论

In this survey, we provide a comprehensive overview of out-of-distribution generalization approaches from a causal perspective. In particular, depending on at which stage of training the machine learning framework the causal domain generalization component is applied, we classify them into three main categories, namely causal data augmentation methods (applied during the data pre-processing phase), invariant causal representation learning approaches (performed during the representation learning stage), and invariant causal mechanism learning algorithms (applied at the classifier level) and explain the state-of-the-art methods in each category. Depending on the approach taken, we further categorize the approaches in each category into sub-categories as shown in Figure 2 . Moreover, we extend our categories to the textual and graph data and classify the approaches developed for those data types into our three categories. Comparing the comprehensive body of literature for the image data with recent works on textual and graph data, we observe many future research directions for these data types. Specifically, while most works on these data types belong to the causal data augmentation category, the causal representation learning and causal invariant mechanism learning-based approaches are greatly underexplored. We therefore suggest exploring these two directions for both of these data types. To evaluate the causal domain generalization approaches systematically, we provide a comprehensive list of commonly-used datasets and evaluation metrics to assess the performance of the proposed frameworks. These evaluation guidelines can be used by researchers and practitioners to appropriately evaluate the performance of their frameworks and compare the performance of existing methodologies.

在本综述中，我们从因果角度对分布外泛化方法进行了全面概述。具体而言，根据因果领域泛化组件在机器学习框架的哪个训练阶段应用，我们将其分为三大类，即因果数据增强方法(在数据预处理阶段应用)、不变因果表示学习方法(在表示学习阶段执行)和不变因果机制学习算法(在分类器层面应用)，并解释了每类中的最先进方法。根据所采用的方法，我们进一步将每类方法细分为子类别，如图2所示。此外，我们将分类扩展到文本和图数据，并将为这些数据类型开发的方法归入我们的三个类别。将图像数据的大量文献与最近关于文本和图数据的研究进行比较，我们发现了这些数据类型未来的许多研究方向。具体来说，虽然关于这些数据类型的大多数研究属于因果数据增强类别，但基于因果表示学习和因果不变机制学习的方法仍有待深入探索。因此，我们建议针对这两种数据类型探索这两个方向。为了系统地评估因果领域泛化方法，我们提供了一份常用数据集和评估指标的综合列表，以评估所提出框架的性能。研究人员和从业者可以使用这些评估指南来适当评估其框架的性能，并比较现有方法的性能。

## References

## 参考文献

[1] Paras Sheth et al. Causal disentanglement with network information for debiased recommendations. arXiv preprint arXiv:2204.07221, 2022.

[1] Paras Sheth等人。利用网络信息进行因果解缠以实现无偏推荐。预印本arXiv:2204.07221，2022年。

[2] Jack Stilgoe. Machine learning, social learning and the governance of self-driving cars. Social studies of science, 2018.

[2] Jack Stilgoe。机器学习、社会学习与自动驾驶汽车的治理。《科学的社会研究》，2018年。

[3] Yann LeCun et al. Gradient-based learning applied to document recognition. Proceedings of the IEEE, 1998.

[3] Yann LeCun等人。基于梯度的学习在文档识别中的应用。《电气与电子工程师协会汇刊》，1998年。

[4] Martin Arjovsky et al. Invariant risk minimization. arXiv preprint arXiv:1907.02893, 2019.

[4] Martin Arjovsky等人。不变风险最小化。预印本arXiv:1907.02893，2019年。

[5] Rowland W Pettit, Robert Fullem, Chao Cheng, and Christopher I Amos. Artificial intelligence, machine learning, and deep learning for clinical outcome prediction. Emerging topics in life sciences, 2021.

[5] Rowland W Pettit、Robert Fullem、Chao Cheng和Christopher I Amos。用于临床结果预测的人工智能、机器学习和深度学习。《生命科学新兴话题》，2021年。

[6] Olga V Demler, Michael J Pencina, and Ralph B D'Agostino Sr. Impact of correlation on predictive ability of biomarkers. Statistics in medicine, 2013.

[6] Olga V Demler、Michael J Pencina和Ralph B D'Agostino Sr。相关性对生物标志物预测能力的影响。《医学统计学》，2013年。

[7] Kate Saenko et al. Adapting visual category models to new domains. In ${ECCV},{2010}$ .

[7] Kate Saenko等人。将视觉类别模型适应新领域。见${ECCV},{2010}$。

[8] Zhihe Lu et al. Stochastic classifiers for unsupervised domain adaptation. In CVPR, 2020.

[8] Zhihe Lu等人。用于无监督领域适应的随机分类器。见《计算机视觉与模式识别会议》，2020年。

[9] Ziwei Liu et al. Open compound domain adaptation. In CVPR, 2020.

[9] Ziwei Liu等人。开放复合领域适应。见《计算机视觉与模式识别会议》，2020年。

[10] Gilles Blanchard et al. Generalizing from several related classification tasks to a new unlabeled sample. NeurIPS, 2011.

[10] Gilles Blanchard等人。从多个相关分类任务泛化到新的未标记样本。《神经信息处理系统大会》，2011年。

[11] Pierrick Bourrat. Measuring causal invariance formally. Entropy, 2021.

[11] Pierrick Bourrat。正式测量因果不变性。《熵》，2021年。

[12] Peter Bühlmann. Invariance, causality and robustness. Statistical Science, 2020.

[12] Peter Bühlmann。不变性、因果关系和鲁棒性。《统计科学》，2020年。

[13] Divyat Mahajan et al. Domain generalization using causal matching. In ICML, 2021.

[13] 迪维亚特·马哈詹(Divyat Mahajan)等人。使用因果匹配的领域泛化。发表于《国际机器学习会议》(ICML)，2021年。

[14] Kaiyang Zhou et al. Domain generalization: A survey. IEEE Transactions on Pattern Analysis and Machine Intelligence, 2022.

[14] 周开阳(Kaiyang Zhou)等人。领域泛化综述。发表于《电气与电子工程师协会模式分析与机器智能汇刊》(IEEE Transactions on Pattern Analysis and Machine Intelligence)，2022年。

[15] Zheyan Shen et al. Towards out-of-distribution generalization: A survey. arXiv preprint arXiv:2108.13624, 2021.

[15] 沈哲彦(Zheyan Shen)等人。迈向分布外泛化:综述。预印本 arXiv:2108.13624，2021年。

[16] Jindong Wang et al. Generalizing to unseen domains: A survey on domain generalization. IEEE TKDE, 2022.

[16] 王晋东(Jindong Wang)等人。泛化到未见领域:领域泛化综述。发表于《电气与电子工程师协会知识与数据工程汇刊》(IEEE TKDE)，2022年。

[17] Xiheng Zhang et al. Learning causal representation for training cross-domain pose estimator via generative interventions. In ${CVF},{2021}$ .

[17] 张希恒(Xiheng Zhang)等人。通过生成干预学习用于训练跨领域姿态估计器的因果表示。发表于${CVF},{2021}$。

[18] Yuedong Chen et al. Towards unbiased visual emotion recognition via causal intervention. arXiv preprint arXiv:2107.12096, 2021.

[18] 陈粤东(Yuedong Chen)等人。通过因果干预实现无偏视觉情感识别。预印本 arXiv:2107.12096，2021年。

[19] Cheng Ouyang et al. Causality-inspired single-source domain generalization for medical image segmentation.

[19] 欧阳程(Cheng Ouyang)等人。受因果关系启发的单源领域泛化用于医学图像分割。

arXiv preprint arXiv:2111.12525, 2021.

预印本 arXiv:2111.12525，2021年。

[20] Jovana Mitrovic et al. Representation learning via invariant causal mechanisms. arXiv preprint arXiv:2010.07922, 2020.

[20] 约瓦娜·米特罗维奇(Jovana Mitrovic)等人。通过不变因果机制进行表示学习。预印本 arXiv:2010.07922，2020年。

[21] Haoyue Bai et al. Decaug: Out-of-distribution generalization via decomposed feature representation and semantic augmentation. In ${AAAI},{2021}$ .

[21] 白皓月(Haoyue Bai)等人。Decaug:通过分解特征表示和语义增强实现分布外泛化。发表于${AAAI},{2021}$。

[22] Mathieu Chevalley, Charlotte Bunne, Andreas Krause, and Stefan Bauer. Invariant causal mechanisms through distribution matching. arXiv preprint arXiv:2206.11646, 2022.

[22] 马蒂厄·谢瓦利耶(Mathieu Chevalley)、夏洛特·邦内(Charlotte Bunne)、安德烈亚斯·克劳斯(Andreas Krause)和斯特凡·鲍尔(Stefan Bauer)。通过分布匹配实现不变因果机制。预印本 arXiv:2206.11646，2022年。

[23] Christina Heinze-Deml et al. Conditional variance penalties and domain shift robustness. arXiv preprint arXiv:1710.11469, 2017.

[23] 克里斯蒂娜·海因策 - 德姆尔(Christina Heinze - Deml)等人。条件方差惩罚与领域偏移鲁棒性。预印本 arXiv:1710.11469，2017年。

[24] Chintan Trivedi et al. Contrastive learning of generalized game representations. In 2021 IEEE Conference on Games (CoG), 2021.

[24] 钦坦·特里维迪(Chintan Trivedi)等人。广义游戏表示的对比学习。发表于2021年电气与电子工程师协会游戏会议(CoG)，2021年。

[25] Chang Liu et al. Learning causal semantic representation for out-of-distribution prediction. NeurIPS, 2021.

[25] 刘畅(Chang Liu)等人。为分布外预测学习因果语义表示。发表于《神经信息处理系统大会》(NeurIPS)，2021年。

[26] Maggie Makar et al. Causally motivated shortcut removal using auxiliary labels. In AISTATS, 2022.

[26] 玛吉·马卡尔(Maggie Makar)等人。使用辅助标签进行因果驱动的捷径去除。发表于《人工智能与统计会议》(AISTATS)，2022年。

[27] Jivat Neet Kaur et al. Modeling the data-generating process is necessary for out-of-distribution generalization. arXiv e-prints, 2022.

[27] 吉瓦特·尼特·考尔(Jivat Neet Kaur)等人。对数据生成过程进行建模对于分布外泛化是必要的。arXiv电子预印本，2022年。

[28] Judea Pearl. Causality. 2009.

[28] 朱迪亚·珀尔(Judea Pearl)。《因果论》(Causality)。2009年。

[29] Yang Chen et al. A style and semantic memory mechanism for domain generalization. In ${CVF},{2021}$ .

[29] 陈洋(Yang Chen)等人。用于领域泛化的风格与语义记忆机制。见 ${CVF},{2021}$ 。

[30] Khurram Javed et al. Learning causal models online. arXiv preprint arXiv:2006.07461, 2020.

[30] 库拉姆·贾韦德(Khurram Javed)等人。在线学习因果模型。预印本 arXiv:2006.07461，2020年。

[31] Mengyue Yang et al. Causalvae: Disentangled representation learning via neural structural causal models. In CVF, 2021.

[31] 杨梦月(Mengyue Yang)等人。因果变分自编码器(Causalvae):通过神经结构因果模型进行解纠缠表征学习。见计算机视觉基金会会议(CVF)，2021年。

[32] Diederik P Kingma and Max Welling. Auto-encoding variational bayes. arXiv preprint arXiv:1312.6114, 2013.

[32] 迪德里克·P·金马(Diederik P Kingma)和马克斯·韦林(Max Welling)。自动编码变分贝叶斯。预印本 arXiv:1312.6114，2013年。

[33] Yi-Fan Zhang et al. Learning domain invariant representations for generalizable person re-identification. arXiv preprint arXiv:2103.15890, 2021.

[33] 张一帆(Yi - Fan Zhang)等人。学习用于可泛化行人重识别的领域不变表征。预印本 arXiv:2103.15890，2021年。

[34] Xiang Deng and othersi. Comprehensive knowledge distillation with causal intervention. NeurIPS, 2021.

[34] 邓翔(Xiang Deng)等人。通过因果干预进行全面知识蒸馏。神经信息处理系统大会(NeurIPS)，2021年。

[35] Tan Wang et al. Causal attention for unbiased visual recognition. In ${CVF},{2021}$ .

[35] 王坦(Tan Wang)等人。用于无偏视觉识别的因果注意力机制。见 ${CVF},{2021}$ 。

[36] Xin Li et al. Confounder identification-free causal visual feature learning. arXiv preprint arXiv:2111.13420, 2021.

[36] 李鑫(Xin Li)等人。无需混杂因素识别的因果视觉特征学习。预印本 arXiv:2111.13420，2021年。

[37] Kartik Ahuja et al. Invariance principle meets information bottleneck for out-of-distribution generalization. NeurIPS, 2021.

[37] 卡蒂克·阿胡贾(Kartik Ahuja)等人。不变性原理与信息瓶颈相结合实现分布外泛化。神经信息处理系统大会(NeurIPS)，2021年。

[38] David Krueger et al. Out-of-distribution generalization via risk extrapolation (rex). In ICML, 2021.

[38] 大卫·克鲁格(David Krueger)等人。通过风险外推(rex)实现分布外泛化。见国际机器学习会议(ICML)，2021年。

[39] Bo Li et al. Invariant information bottleneck for domain generalization. In ${AAAI},{2022}$ .

[39] 李博(Bo Li)等人。用于领域泛化的不变信息瓶颈。见 ${AAAI},{2022}$ 。

[40] Ruocheng Guo et al. Out-of-distribution prediction with invariant risk minimization: The limitation and an effective fix. arXiv preprint arXiv:2101.07732, 2021.

[40] 郭若成(Ruocheng Guo)等人。使用不变风险最小化进行分布外预测:局限性与有效解决方案。预印本 arXiv:2101.07732，2021年。

[41] Dongsung Huh et al. The missing invariance principle found-the reciprocal twin of invariant risk minimization. arXiv preprint arXiv:2205.14546, 2022.

[41] 胡东成(Dongsung Huh)等人。缺失的不变性原理被发现——不变风险最小化的对偶孪生。预印本 arXiv:2205.14546，2022年。

[42] Alexis Bellot et al. Accounting for unobserved confounding in domain generalization. arXiv preprint arXiv:2007.10653, 2020.

[42] 亚历克西斯·贝洛(Alexis Bellot)等人。在领域泛化中考虑未观察到的混杂因素。预印本 arXiv:2007.10653，2020年。

[43] Sreya Francis et al. Towards causal federated learning for enhanced robustness and privacy. arXiv preprint arXiv:2104.06557, 2021.

[43] 斯瑞亚·弗朗西斯(Sreya Francis)等人。迈向增强鲁棒性和隐私性的因果联邦学习。预印本 arXiv:2104.06557，2021年。

[44] Jens Müller et al. Learning robust models using the principle of independent causal mechanisms. In DAGM German Conference on Pattern Recognition, 2021.

[44] 延斯·米勒(Jens Müller)等人。利用独立因果机制原理学习鲁棒模型。发表于2021年德国模式识别会议(DAGM German Conference on Pattern Recognition)。

[45] Arthur Gretton et al. Measuring statistical dependence with hilbert-schmidt norms. In International conference on algorithmic learning theory. Springer, 2005.

[45] 亚瑟·格雷顿(Arthur Gretton)等人。用希尔伯特 - 施密特范数测量统计依赖性。发表于2005年算法学习理论国际会议(International conference on algorithmic learning theory)，施普林格出版社(Springer)。

[46] Xiangyu Zheng et al. Learning towards robustness in causally-invariant predictors. arXiv preprint arXiv:2107.01876, 2021.

[46] 郑翔宇(Xiangyu Zheng)等人。朝着因果不变预测器的鲁棒性学习。预印本arXiv:2107.01876，2021年。

[47] Fangrui Lv et al. Causality inspired representation learning for domain generalization. In ${CVF},{2022}$ .

[47] 吕芳锐(Fangrui Lv)等人。受因果关系启发的领域泛化表示学习。发表于${CVF},{2022}$ 。

[48] Yunqi Wang et al. Contrastive ace: domain generalization through alignment of causal mechanisms. arXiv preprint arXiv:2106.00925, 2021.

[48] 王云琪(Yunqi Wang)等人。对比式ACE:通过对齐因果机制实现领域泛化。预印本arXiv:2106.00925，2021年。

[49] Xinwei Sun, Botong Wu, Xiangyu Zheng, Chang Liu, Wei Chen, Tao Qin, and Tie-yan Liu. Latent causal invariant model. arXiv preprint arXiv:2011.02203, 2020.

[49] 孙新伟(Xinwei Sun)、吴伯通(Botong Wu)、郑翔宇(Xiangyu Zheng)、刘畅(Chang Liu)、陈伟(Wei Chen)、秦涛(Tao Qin)和刘铁岩(Tie - yan Liu)。潜在因果不变模型。预印本arXiv:2011.02203，2020年。

[50] Krikamol Muandet et al. Domain generalization via invariant feature representation. In ICML, 2013.

[50] 克里卡莫尔·穆安代特(Krikamol Muandet)等人。通过不变特征表示实现领域泛化。发表于2013年国际机器学习会议(ICML)。

[51] Dan Hendrycks et al. Pretrained transformers improve out-of-distribution robustness. arXiv preprint arXiv:2004.06100, 2020.

[51] 丹·亨德里克斯(Dan Hendrycks)等人。预训练的Transformer提高分布外鲁棒性。预印本arXiv:2004.06100，2020年。

[52] Zhao Wang et al. Identifying spurious correlations for robust text classification. arXiv preprint arXiv:2010.02458, 2020.

[52] 王钊(Zhao Wang)等人。识别虚假相关性以实现鲁棒的文本分类。预印本arXiv:2010.02458，2020年。

[53] Ellery Wulczyn et al. Ex machina: Personal attacks seen at scale. In Proceedings of the 26th international conference on world wide web, 2017.

[53] 埃勒里·伍尔钦(Ellery Wulczyn)等人。《机械姬》:大规模视角下的人身攻击。发表于2017年第26届万维网国际会议论文集(Proceedings of the 26th international conference on world wide web)。

[54] Seungtaek Choi et al. C21: Causally contrastive learning for robust text classification. 2022.

[54] 崔承泽(Seungtaek Choi)等人。C21:用于鲁棒文本分类的因果对比学习。2022年。

[55] Zhao Wang et al. Robustness to spurious correlations in text classification via automatically generated counter-factuals. In ${AAAI},{2021}$ .

[55] 王钊(Zhao Wang)等人。通过自动生成反事实实现文本分类对虚假相关性的鲁棒性。发表于${AAAI},{2021}$ 。

[56] Victor Veitch et al. Counterfactual invariance to spurious correlations: Why and how to pass stress tests. arXiv preprint arXiv:2106.00545, 2021.

[56] 维克多·维奇(Victor Veitch)等人。对虚假相关性的反事实不变性:为何以及如何通过压力测试。预印本arXiv:2106.00545，2021年。

[57] Maxime Peyrard et al. Invariant language modeling. arXiv preprint arXiv:2110.08413, 2021.

[57] 马克西姆·佩拉尔(Maxime Peyrard)等人。不变语言建模。预印本arXiv:2110.08413，2021年。

[58] Lu Cheng et al. Bias mitigation for toxicity detection via sequential decisions. In ACM SIGIR, 2022.

[58] 程璐(Lu Cheng)等人。通过顺序决策减轻毒性检测中的偏差。发表于2022年美国计算机协会信息检索研究与发展会议(ACM SIGIR)。

[59] Amir Feder et al. Causal inference in natural language processing: Estimation, prediction, interpretation and beyond. arXiv preprint arXiv:2109.00725, 2021.

[59] 阿米尔·费德(Amir Feder)等人。自然语言处理中的因果推断:估计、预测、解释及其他。预印本arXiv:2109.00725，2021年。

[60] Megha Srivastava et al. Robustness to spurious correlations via human annotations. In ICML, 2020.

[60] 梅加·斯里瓦斯塔瓦(Megha Srivastava)等人。通过人工注释增强对虚假相关性的鲁棒性。发表于《国际机器学习会议》(ICML)，2020年。

[61] Divyansh Kaushik et al. Learning the difference that makes a difference with counterfactually-augmented data. arXiv preprint arXiv:1909.12434, 2019.

[61] 迪维亚恩什·考希克(Divyansh Kaushik)等人。利用反事实增强数据学习产生差异的差异。预印本 arXiv:1909.12434，2019年。

[62] Fiona Anting Tan et al. Causal augmentation for causal sentence classification. In Proceedings of the First Workshop on Causal Inference and NLP, 2021.

[62] 菲奥娜·安廷·谭(Fiona Anting Tan)等人。用于因果句子分类的因果增强。发表于《首届因果推理与自然语言处理研讨会会议录》，2021年。

[63] Kartik Ahuja et al. Invariant risk minimization games. In ICML, 2020.

[63] 卡蒂克·阿胡贾(Kartik Ahuja)等人。不变风险最小化博弈。发表于《国际机器学习会议》(ICML)，2020年。

[64] Gang Liu et al. Graph rationalization with environment-based augmentations. arXiv preprint arXiv:2206.02886, 2022.

[64] 刘刚等人。基于环境增强的图合理化。预印本 arXiv:2206.02886，2022年。

[65] Shaohua Fan et al. Generalizing graph neural networks on out-of-distribution graphs. arXiv preprint arXiv:2111.10657, 2021.

[65] 范少华等人。在分布外图上推广图神经网络。预印本 arXiv:2111.10657，2021年。

[66] Yongduo Sui et al. Causal attention for interpretable and generalizable graph classification. arXiv preprint arXiv:2112.15089, 2022.

[66] 隋永铎等人。用于可解释和可泛化图分类的因果注意力。预印本 arXiv:2112.15089，2022年。

[67] Beatrice Bevilacqua et al. Size-invariant graph representations for graph classification extrapolations. In ICML, 2021.

[67] 比阿特丽斯·贝维拉夸(Beatrice Bevilacqua)等人。用于图分类外推的尺寸不变图表示。发表于《国际机器学习会议》(ICML)，2021年。

[68] Tom AB Snijders et al. Estimation and prediction for stochastic blockmodels for graphs with latent block structure. Journal of classification, 1997.

[68] 汤姆·AB·斯尼德斯(Tom AB Snijders)等人。具有潜在块结构的图的随机块模型的估计和预测。《分类学杂志》，1997年。

[69] László Lovász et al. Limits of dense graph sequences. Journal of Combinatorial Theory, Series B, 2006.

[69] 拉斯洛·洛瓦斯(László Lovász)等人。稠密图序列的极限。《组合理论杂志，B辑》，2006年。

[70] Yongqiang Chen et al. Invariance principle meets out-of-distribution generalization on graphs. arXiv preprint arXiv:2202.05441, 2022.

[70] 陈永强等人。不变性原理与图上的分布外泛化。预印本 arXiv:2202.05441，2022年。

[71] Ying-Xin Wu et al. Discovering invariant rationales for graph neural networks. arXiv preprint arXiv:2201.12872, 2022.

[71] 吴迎新等人。发现图神经网络的不变基本原理。预印本 arXiv:2201.12872，2022年。

[72] Tero Karras et al. Progressive growing of gans for improved quality, stability, and variation. arXiv preprint arXiv:1710.10196, 2017.

[72] 特罗·卡拉斯(Tero Karras)等人。渐进式生成对抗网络以提高质量、稳定性和多样性。预印本 arXiv:1710.10196，2017年。

[73] Andreas Rossler et al. Faceforensics++: Learning to detect manipulated facial images. In IEEE CVF, 2019.

[73] 安德烈亚斯·罗斯勒(Andreas Rossler)等人。Faceforensics++:学习检测被篡改的面部图像。发表于《电气与电子工程师协会计算机视觉与模式识别会议》(IEEE CVF)，2019年。

[74] Liming Jiang et al. Deeperforensics-1.0: A large-scale dataset for real-world face forgery detection. In IEEE CVF, 2020.

[74] 蒋黎明等人。Deeperforensics - 1.0:用于现实世界人脸伪造检测的大规模数据集。发表于《电气与电子工程师协会计算机视觉与模式识别会议》(IEEE CVF)，2020年。

[75] Patrick Lucey et al. The extended cohn-kanade dataset (ck+): A complete dataset for action unit and emotion-specified expression. In IEEE CVPR, 2010.

[75] 帕特里克·卢西(Patrick Lucey)等人。扩展的科恩 - 卡纳德数据集(ck +):用于动作单元和特定情感表达的完整数据集。发表于《电气与电子工程师协会计算机视觉与模式识别会议》(IEEE CVPR)，2010年。

[76] Michel Valstar et al. Induced disgust, happiness and surprise: an addition to the mmi facial expression database. In Proc. 3rd Intern. Workshop on EMOTION (satellite of LREC): Corpora for Research on Emotion and Affect, 2010.

[76] 米歇尔·瓦尔斯特(Michel Valstar)等人。诱发的厌恶、快乐和惊讶情绪:MMI面部表情数据库的补充。收录于《第三届国际情感研讨会(LREC卫星会议):情感与情绪研究语料库》会议论文集，2010年。

[77] Guoying Zhao et al. Facial expression recognition from near-infrared videos. Image and vision computing, 2011.

[77] 赵国英(Guoying Zhao)等人。基于近红外视频的面部表情识别。《图像与视觉计算》，2011年。

[78] Han Xiao et al. Fashion-mnist: a novel image dataset for benchmarking machine learning algorithms. arXiv preprint arXiv:1708.07747, 2017.

[78] 肖涵(Han Xiao)等人。时尚MNIST:用于机器学习算法基准测试的新型图像数据集。预印本arXiv:1708.07747，2017年。

[79] Yaroslav Ganin et al. Unsupervised domain adaptation by backpropagation. In ICML, 2015.

[79] 亚罗斯拉夫·加宁(Yaroslav Ganin)等人。通过反向传播进行无监督领域自适应。收录于《国际机器学习会议》，2015年。

[80] Yuval Netzer et al. Reading digits in natural images with unsupervised feature learning. 2011.

[80] 尤瓦尔·内策尔(Yuval Netzer)等人。利用无监督特征学习读取自然图像中的数字。2011年。

[81] Muhammad Ghifary et al. Domain generalization for object recognition with multi-task autoencoders. In IEEE CVF, 2015.

[81] 穆罕默德·吉法里(Muhammad Ghifary)等人。使用多任务自动编码器进行目标识别的领域泛化。发表于IEEE计算机视觉基金会(IEEE CVF)会议，2015年。

[82] Clifford R Jack Jr et al. The alzheimer's disease neuroimaging initiative (adni): Mri methods. Journal of Magnetic Resonance Imaging: An Official Journal of the International Society for Magnetic Resonance in Medicine, 2008.

[82] 小克利福德·R·杰克(Clifford R Jack Jr)等人。阿尔茨海默病神经影像学倡议(ADNI):磁共振成像(MRI)方法。《磁共振成像杂志:国际医学磁共振学会官方期刊》，2008年。

[83] Xiaosong Wang et al. Chestx-ray8: Hospital-scale chest x-ray database and benchmarks on weakly-supervised classification and localization of common thorax diseases. In CVPR, 2017.

[83] 王晓松(Xiaosong Wang)等人。Chestx - ray8:医院规模的胸部X光数据库以及常见胸部疾病弱监督分类和定位的基准。发表于计算机视觉与模式识别会议(CVPR)，2017年。

[84] Jeremy Irvin et al. Chexpert: A large chest radiograph dataset with uncertainty labels and expert comparison. In ${AAAI},{2019}$ .

[84] 杰里米·欧文(Jeremy Irvin)等人。Chexpert:一个带有不确定标签和专家对比的大型胸部X光数据集。发表于${AAAI},{2019}$。

[85] Tomás Franquet. Imaging of community-acquired pneumonia. Journal of thoracic imaging, 2018.

[85] 托马斯·弗朗凯(Tomás Franquet)。社区获得性肺炎的影像学检查。《胸部影像学杂志》，2018年。

[86] Catalin Ionescu et al. Human3. 6m: Large scale datasets and predictive methods for 3d human sensing in natural environments. IEEE transactions on pattern analysis and machine intelligence, 2013.

[86] 卡塔林·约内斯库(Catalin Ionescu)等人。Human3. 6m:自然环境中3D人体感知的大规模数据集和预测方法。《IEEE模式分析与机器智能汇刊》，2013年。

[87] Timo Von Marcard et al. Recovering accurate 3d human pose in the wild using imus and a moving camera. In Proceedings of the European Conference on Computer Vision (ECCV), 2018.

[87] 蒂莫·冯·马尔卡德(Timo Von Marcard)等人。利用惯性测量单元(IMU)和移动相机在野外恢复准确的3D人体姿态。发表于欧洲计算机视觉会议(ECCV)论文集，2018年。

[88] Dushyant Mehta et al. Monocular 3d human pose estimation in the wild using improved cnn supervision. In 2017 international conference on 3D vision (3DV), 2017.

[88] 杜什扬特·梅塔(Dushyant Mehta)等人。利用改进的卷积神经网络(CNN)监督在野外进行单目3D人体姿态估计。发表于2017年国际3D视觉会议(3DV)，2017年。

[89] Gul Varol et al. Learning from synthetic humans. In CVPR, 2017.

[89] 古尔·瓦罗尔(Gul Varol)等人。从合成人类中学习。发表于计算机视觉与模式识别会议(CVPR)，2017年。

[90] Leonid Sigal et al. Humaneva: Synchronized video and motion capture dataset and baseline algorithm for evaluation of articulated human motion. International journal of computer vision, 2010.

[90] 列昂尼德·西加尔(Leonid Sigal)等人。Humaneva:同步视频和运动捕捉数据集以及用于评估关节式人体运动的基准算法。《国际计算机视觉杂志》，2010年。

[91] Wei Li et al. Locally aligned feature transforms across views. In CVPR, 2013.

[91] 李伟(Wei Li)等人。跨视图的局部对齐特征变换。发表于计算机视觉与模式识别会议(CVPR)，2013年。

[92] Wei Li et al. Deepreid: Deep filter pairing neural network for person re-identification. In CVPR, 2014.

[92] 李伟(Wei Li)等人。Deepreid:用于行人重识别的深度滤波器配对神经网络。发表于计算机视觉与模式识别会议(CVPR)，2014年。

[93] Liang Zheng et al. Scalable person re-identification: A benchmark. In CVPR, 2015.

[93] 郑亮(Liang Zheng)等人。可扩展的行人重识别:一个基准。发表于计算机视觉与模式识别会议(CVPR)，2015年。

[94] Zhedong Zheng et al. Unlabeled samples generated by gan improve the person re-identification baseline in vitro. In ${CVPR},{2017}$ .

[94] 郑哲东(Zhedong Zheng)等人。生成对抗网络(GAN)生成的无标签样本在体外改善了行人重识别基准。发表于${CVPR},{2017}$。

[95] Tong Xiao et al. End-to-end deep learning for person search. arXiv preprint arXiv:1604.01850, 2016.

[95] 肖桐(Tong Xiao)等人。用于行人搜索的端到端深度学习。预印本arXiv:1604.01850，2016年。

[96] Catherine Wah et al. The caltech-ucsd birds-200-2011 dataset. 2011.

[96] 凯瑟琳·瓦(Catherine Wah)等人。加州理工学院 - 加州大学圣地亚哥分校鸟类200 - 2011数据集。2011年。

[97] Bolei Zhou et al. Places: A 10 million image database for scene recognition. IEEE transactions on pattern analysis and machine intelligence, 2017.

[97] 周博磊(Bolei Zhou)等人。Places:用于场景识别的千万图像数据库。《电气与电子工程师协会模式分析与机器智能汇刊》，2017年。

[98] Sara Beery et al. The iwildcam 2018 challenge dataset. arXiv preprint arXiv:1904.05986, 2019.

[98] 萨拉·比里(Sara Beery)等人。2018年野生动物相机挑战数据集。预印本arXiv:1904.05986，2019年。

[99] Sara Beery et al. Recognition in terra incognita. In ECCV, 2018.

[99] 萨拉·比里(Sara Beery)等人。未知领域的识别。收录于欧洲计算机视觉会议(ECCV)，2018年。

[100] Da Li et al. Deeper, broader and artier domain generalization. In ICCV, 2017.

[100] 李达(Da Li)等人。更深、更广、更具艺术性的领域泛化。收录于国际计算机视觉大会(ICCV)，2017年。

[101] Hemanth Venkateswara et al. Deep hashing network for unsupervised domain adaptation. In CVPR, 2017.

[101] 赫曼斯·文卡特斯瓦拉(Hemanth Venkateswara)等人。用于无监督领域自适应的深度哈希网络。收录于计算机视觉与模式识别会议(CVPR)，2017年。

[102] Xingchao Peng et al. Moment matching for multi-source domain adaptation. In IEEE CVF, 2019.

[102] 彭兴超(Xingchao Peng)等人。多源领域自适应的矩匹配。收录于电气与电子工程师协会计算机视觉基金会会议(IEEE CVF)，2019年。

[103] Dan Hendrycks et al. The many faces of robustness: A critical analysis of out-of-distribution generalization. In IEEE CVF, 2021.

[103] 丹·亨德里克斯(Dan Hendrycks)等人。鲁棒性的多面性:对分布外泛化的批判性分析。收录于电气与电子工程师协会计算机视觉基金会会议(IEEE CVF)，2021年。

[104] Chen Fang et al. Unbiased metric learning: On the utilization of multiple datasets and web images for softening bias. In ${ICCV},{2013}$ .

[104] 方晨(Chen Fang)等人。无偏度量学习:利用多个数据集和网络图像减轻偏差。收录于${ICCV},{2013}$ 。

[105] Dan Hendrycks et al. Benchmarking neural network robustness to common corruptions and perturbations. arXiv preprint arXiv:1903.12261, 2019.

[105] 丹·亨德里克斯(Dan Hendrycks)等人。对常见损坏和扰动的神经网络鲁棒性进行基准测试。预印本arXiv:1903.12261，2019年。

[106] Yue andothers He. Towards non-iid image classification: A dataset and baselines. Pattern Recognition, 2021.

[106] 何岳(Yue He)等人。迈向非独立同分布图像分类:一个数据集和基准。《模式识别》，2021年。

[107] Xingxuan Zhang et al. Nico++: Towards better benchmarking for domain generalization. arXiv preprint arXiv:2204.08040, 2022.

[107] 张兴轩(Xingxuan Zhang)等人。Nico++:迈向更好的领域泛化基准测试。预印本arXiv:2204.08040，2022年。

[108] Zhenqin Wu et al. Moleculenet: a benchmark for molecular machine learning. Chemical science, 2018.

[108] 吴珍钦(Zhenqin Wu)等人。分子网络(Moleculenet):分子机器学习的基准。《化学科学》，2018年。

[109] Rafael Gómez-Bombarelli et al. Automatic chemical design using a data-driven continuous representation of molecules. ACS central science, 2018.

[109] 拉斐尔·戈麦斯 - 邦巴雷利(Rafael Gómez - Bombarelli)等人。使用分子的数据驱动连续表示进行自动化学设计。《美国化学学会中心科学》，2018年。

[110] Aleksandar Bojchevski et al. Deep gaussian embedding of graphs: Unsupervised inductive learning via ranking. arXiv preprint arXiv:1707.03815, 2017.

[110] 亚历山大·博伊切夫斯基(Aleksandar Bojchevski)等人。图的深度高斯嵌入:通过排序进行无监督归纳学习。预印本arXiv:1707.03815，2017年。

[111] Weihua Hu et al. Open graph benchmark: Datasets for machine learning on graphs. NeurIPS, 2020.

[111] 胡伟华(Weihua Hu)等人。开放图基准:图机器学习的数据集。神经信息处理系统大会(NeurIPS)，2020年。

[112] Zhitao Ying et al. Gnnexplainer: Generating explanations for graph neural networks. NeurIPS, 2019.

[112] 应智涛(Zhitao Ying)等人。Gnnexplainer:为图神经网络生成解释。《神经信息处理系统大会》(NeurIPS)，2019年。

[113] Fang Fang et al. Domain adaptation for sentiment classification in light of multiple sources. INFORMS Journal on Computing, 2014.

[113] 方芳(Fang Fang)等人。基于多源的情感分类领域自适应。《运筹学与管理科学学会计算期刊》(INFORMS Journal on Computing)，2014年。

[114] Andrew Maas et al. Learning word vectors for sentiment analysis. In ACL: Human language technologies, 2011.

[114] 安德鲁·马斯(Andrew Maas)等人。用于情感分析的词向量学习。《计算语言学协会:人类语言技术》(ACL: Human language technologies)，2011年。

[115] Julian John McAuley et al. From amateurs to connoisseurs: modeling the evolution of user expertise through online reviews. In WWW, 2013.

[115] 朱利安·约翰·麦考利(Julian John McAuley)等人。从业余爱好者到鉴赏家:通过在线评论建模用户专业知识的演变。《万维网会议》(WWW)，2013年。

[116] Daniel Borkan et al. Nuanced metrics for measuring unintended bias with real data for text classification. In WWW, 2019.

[116] 丹尼尔·博尔坎(Daniel Borkan)等人。用于使用真实数据测量文本分类中意外偏差的细致指标。《万维网会议》(WWW)，2019年。

[117] Adina Williams et al. A broad-coverage challenge corpus for sentence understanding through inference. arXiv preprint arXiv:1704.05426, 2017.

[117] 阿迪娜·威廉姆斯(Adina Williams)等人。一个通过推理进行句子理解的广泛覆盖挑战语料库。预印本arXiv:1704.05426，2017年。

[118] Chaochao Lu et al. Invariant causal representation learning for out-of-distribution generalization. In ICLR, 2021.

[118] 陆超超(Chaochao Lu)等人。用于分布外泛化的不变因果表示学习。《国际学习表征会议》(ICLR)，2021年。

[119] Ruoyu Wang et al. Improving ood generalization with causal invariant transformations. 2021.

[119] 王若愚(Ruoyu Wang)等人。通过因果不变变换改进分布外泛化。2021年。

[120] Justin B Kinney et al. Equitability, mutual information, and the maximal information coefficient. Proceedings of the National Academy of Sciences, 2014.

[120] 贾斯汀·B·金尼(Justin B Kinney)等人。公平性、互信息和最大信息系数。《美国国家科学院院刊》(Proceedings of the National Academy of Sciences)，2014年。