# Object-Aware Domain Generalization for Object Detection

# 面向目标检测的目标感知域泛化

Wooju Lee*, Dasol Hong*, Hyungtae Lim ${}^{ \dagger  }$ , Hyun Myung ${}^{ \dagger  }$

Wooju Lee*, Dasol Hong*, Hyungtae Lim ${}^{ \dagger  }$ , Hyun Myung ${}^{ \dagger  }$

Urban Robotics Lab, School of Electrical Engineering,

韩国先进科学技术院电气工程学院城市机器人实验室

Korea Advanced Institute of Science and Technology, Republic of Korea

韩国先进科学技术院，韩国

\{dnwn24, ds.hong, shapelim, hmyung\}@kaist.ac.kr

\{dnwn24, ds.hong, shapelim, hmyung\}@kaist.ac.kr

## Abstract

## 摘要

Single-domain generalization (S-DG) aims to generalize a model to unseen environments with a single-source domain. However, most S-DG approaches have been conducted in the field of classification. When these approaches are applied to object detection, the semantic features of some objects can be damaged, which can lead to imprecise object localization and misclassification. To address these problems, we propose an object-aware domain generalization (OA-DG) method for single-domain generalization in object detection. Our method consists of data augmentation and training strategy, which are called OA-Mix and OA-Loss, respectively. OA-Mix generates multi-domain data with multi-level transformation and object-aware mixing strategy. OA-Loss enables models to learn domain-invariant representations for objects and backgrounds from the original and OA-Mixed images. Our proposed method outperforms state-of-the-art works on standard benchmarks. Our code is available at https://github.com/WoojuLee24/OA-DG.

单域泛化(Single-domain generalization, S-DG)旨在利用单一源域使模型泛化到未见过的环境中。然而，大多数S-DG方法均在分类领域开展。当这些方法应用于目标检测时，部分目标的语义特征可能被破坏，导致目标定位不准确和误分类。为解决这些问题，我们提出了一种面向目标检测的目标感知域泛化(Object-Aware Domain Generalization, OA-DG)方法。该方法包括数据增强和训练策略，分别称为OA-Mix和OA-Loss。OA-Mix通过多层次变换和目标感知混合策略生成多域数据。OA-Loss使模型能够从原始图像和OA-Mix生成的图像中学习目标和背景的域不变表示。我们的方法在标准基准测试中优于现有最先进方法。代码可在https://github.com/WoojuLee24/OA-DG获取。

## Introduction

## 引言

Modern deep neural networks (DNNs) have achieved human-level performances in various applications such as image classification and object detection (He et al. 2016; Dosovitskiy et al. 2021; Carion et al. 2020; Ren et al. 2015). However, DNNs are vulnerable to various types of domain shifts, which have not been seen in the source domain (Dan and Thomas 2019; Lee and Myung 2022; Michaelis et al. 2019; Wu and Deng 2022). Even a small change in the domain can have disastrous results in real-world scenarios such as autonomous driving (Michaelis et al. 2019; Wu and Deng 2022). Thus, DNNs should be robust against the domain shifts to be applied in real-world applications.

现代深度神经网络(Deep Neural Networks, DNNs)在图像分类和目标检测等多种应用中已达到人类水平的表现(He et al. 2016；Dosovitskiy et al. 2021；Carion et al. 2020；Ren et al. 2015)。然而，DNNs对源域未见过的各种域偏移(domain shifts)极为敏感(Dan and Thomas 2019；Lee and Myung 2022；Michaelis et al. 2019；Wu and Deng 2022)。即使是微小的域变化，在自动驾驶等实际场景中也可能导致灾难性后果(Michaelis et al. 2019；Wu and Deng 2022)。因此，DNNs必须具备对域偏移的鲁棒性，才能应用于实际环境。

Domain generalization (DG) aims to generalize a model to unseen target domains by using only the source domain (Hendrycks et al. 2019; Kim et al. 2021; Yao et al. 2022; Zhou et al. 2022). However, most DG methods rely on multiple source domains and domain annotations, which are generally unavailable (Kim et al. 2021; Lin et al. 2021; Yao et al. 2022). Single-domain generalization (S-DG) achieves DG without any additional knowledge about multiple domains (Wan et al. 2022; Wang et al. 2021b).

域泛化(Domain Generalization, DG)旨在仅利用源域使模型泛化到未见过的目标域(Hendrycks et al. 2019；Kim et al. 2021；Yao et al. 2022；Zhou et al. 2022)。然而，大多数DG方法依赖于多个源域和域标注，而这些通常不可用(Kim et al. 2021；Lin et al. 2021；Yao et al. 2022)。单域泛化(Single-domain generalization, S-DG)则无需额外的多域信息即可实现域泛化(Wan et al. 2022；Wang et al. 2021b)。

![bo_d282q677aajc738orm7g_0_936_623_703_763_0.jpg](images/bo_d282q677aajc738orm7g_0_936_623_703_763_0.jpg)

Figure 1. (a) Existing data augmentation methods can damage the semantic features of objects. (b) OA-Mix generates multiple domains while preserving semantic features. (c)- (e) The dotted line, arrow, circle, triangle, and star mean pull, push, car, person, and background, respectively. (c) The background contains different semantics (red and orange stars), but these are treated identically and pulled. (d) The method ignores semantic relationships between background instances. (e) OA-Loss considers semantic relations of background instances from multi-domain.

图1. (a) 现有数据增强方法可能破坏目标的语义特征。 (b) OA-Mix在保持语义特征的同时生成多域数据。 (c)-(e) 虚线、箭头、圆圈、三角形和星形分别表示拉近、推远、汽车、行人和背景。 (c) 背景包含不同语义(红色和橙色星形)，但被同等对待并拉近。 (d) 该方法忽略了背景实例间的语义关系。 (e) OA-Loss考虑了来自多域的背景实例语义关系。

Data augmentation has been successfully applied for S-DG in image classification (Hendrycks et al. 2019; Modas et al. 2022). The methods can be used to generate multi-source domains from a single-source domain. However, object detection addresses multiple objects in an image. When data augmentation methods for S-DG are applied to object detection, object annotations may be damaged. As shown in Figure 1(a), spatial and color transformations can damage the positional or semantic features of objects. Michaelis et al. (2019) avoided this problem with style-transfer augmentations that do not change object locations. However, this approach does not leverage a rich set of transformations in image classification, thus limiting the domain coverage. Therefore, data augmentation for single-source domain generalization for object detection (S-DGOD) should include various transformations without damaging object annotation.

数据增强已成功应用于图像分类的单域泛化(Hendrycks et al. 2019；Modas et al. 2022)，可从单一源域生成多源域数据。然而，目标检测涉及图像中的多个目标。当将单域泛化的数据增强方法应用于目标检测时，目标标注可能被破坏。如图1(a)所示，空间和颜色变换可能损害目标的位置或语义特征。Michaelis等(2019)通过不改变目标位置的风格迁移增强避免了该问题，但该方法未充分利用图像分类中的丰富变换，限制了域覆盖范围。因此，面向目标检测的单源域泛化(S-DGOD)数据增强应包含多样变换且不损害目标标注。

---

*These authors contributed equally.

*这些作者贡献相同。

${}^{ \dagger  }$ Corresponding authors: Dr. Hyungtae Lim and Prof. Hyun Myung

${}^{ \dagger  }$ 通讯作者:Hyungtae Lim博士和Hyun Myung教授

Copyright © 2024, Association for the Advancement of Artificial Intelligence (www.aaai.org). All rights reserved.

版权所有 © 2024，人工智能促进协会(www.aaai.org)。保留所有权利。

---

Recently, contrastive learning methods have been proposed to reduce the gap between the original and augmented domains (Kim et al. 2021; Yao et al. 2022). The methods address inter-class and intra-class relationships from multi-domain. However, they only train the relationships in object classes and do not consider background class for object detection (Sun et al. 2021) as shown in Figure 1(d). Because the object detector misclassifies foreground as background in OOD, considering the background class is required to classify the presence of objects in OOD. Therefore, the contrastive learning method should consider both the foreground and background classes for object detectors to classify objectness in out-of-distribution.

最近，提出了对比学习方法以缩小原始域与增强域之间的差距(Kim 等，2021；Yao 等，2022)。这些方法从多域角度处理类间和类内关系。然而，它们仅训练目标类别之间的关系，未考虑目标检测中的背景类别(Sun 等，2021)，如图1(d)所示。由于目标检测器在OOD(分布外)情况下会将前景误判为背景，因此需要考虑背景类别以判断OOD中目标的存在。因此，对比学习方法应同时考虑前景和背景类别，以使目标检测器能够在分布外环境中判别目标性。

In this study, we propose object-aware domain generalization method (OA-DG) for S-DGOD to overcome the aforementioned limitations. Our method consists of OA-Mix for data augmentation and OA-Loss for reducing the domain gap. OA-Mix consists of multi-level transformations and object-aware mixing. Multi-level transformations introduce local domain changes within an image and object-aware mixing prevents the transformations from damaging object annotation. OA-Mix is the first object-aware approach that allows a rich set of image transformations for S-DGOD.

本研究提出了面向单域泛化目标检测(S-DGOD)的目标感知域泛化方法(OA-DG)，以克服上述限制。该方法包括用于数据增强的OA-Mix和用于缩小域差距的OA-Loss。OA-Mix由多层次变换和目标感知混合组成。多层次变换在图像内引入局部域变化，目标感知混合则防止变换破坏目标标注。OA-Mix是首个允许丰富图像变换且具备目标感知能力的S-DGOD方法。

OA-Loss reduces the gap between the original and augmented domains in an object-aware manner. For foreground instances, the method trains inter-class and intra-class relations to improve object classification in out-of-distribution. Meanwhile, the background instances that belong to the same class can partially include the foreground objects of different classes. OA-Loss allows the model to learn the semantic relations among background instances in multi-domain as illustrated in Figure 1(e). To the best of our knowledge, the proposed method first trains the semantic relations for both the foreground and background instances to achieve DG with contrastive methods.

OA-Loss以目标感知方式缩小原始域与增强域之间的差距。对于前景实例，该方法训练类间和类内关系以提升分布外的目标分类性能。与此同时，同一背景类别的背景实例可能部分包含不同类别的前景目标。OA-Loss使模型能够学习多域背景实例间的语义关系，如图1(e)所示。据我们所知，所提方法首次同时训练前景和背景实例的语义关系，以实现基于对比方法的域泛化。

Our proposed method shows the best performance on common corruption (Michaelis et al. 2019) and various weather benchmarks (Wu and Deng 2022) in an urban scene. The contributions can be summarized as follows.

我们提出的方法在城市场景中的常见扰动(Michaelis 等，2019)和多种天气基准(Wu 和 Deng，2022)上表现最佳。贡献总结如下。

- We propose OA-Mix, a general and effective data augmentation method for S-DGOD. It increases image diversity while preserving important semantic features with multi-level transformations and object-aware mixing.

- 我们提出了OA-Mix，一种通用且有效的S-DGOD数据增强方法。通过多层次变换和目标感知混合，增加图像多样性的同时保留重要语义特征。

- We propose OA-Loss that reduces the domain gap between the original and augmented images. OA-Loss enables the model to learn semantic relations of foreground and background instances from multi-domain.

- 我们提出了OA-Loss，缩小原始图像与增强图像之间的域差距。OA-Loss使模型能够学习多域中前景和背景实例的语义关系。

- Extensive experiments on standard benchmarks show that the proposed method outperforms state-of-the-art methods on unseen target domains.

- 在标准基准上的大量实验表明，所提方法在未见目标域上优于最先进方法。

## Related Work

## 相关工作

## Data Augmentation for Domain Generalization

## 域泛化的数据增强

Recently, many successful data augmentation methods for S-DG have been proposed for image classification. Aug-Mix (Hendrycks et al. 2019) mixes the results of the augmentation chains to generate more diverse domains. Modas et al. (2022) generated diverse domains using three primitive transformations with smoothness and strength parameters. However, direct application of these methods to object detection can damage the locations or semantic annotations of objects, as shown in Figure 1(a). Geirhos et al. (2018) avoided this issue by using style transfer (Gatys, Ecker, and Bethge 2016) that does not damage object annotations and improved robustness to synthetic corruptions. However, data augmentation methods for S-DGOD should generate diverse domains with a broad range of transformations rather than a limited set of transformations. The proposed OA-Mix uses an object-aware approach to create various domains without damaging object annotations.

近年来，针对单域泛化(S-DG)的图像分类，提出了许多成功的数据增强方法。Aug-Mix(Hendrycks 等，2019)混合增强链的结果以生成更多样的域。Modas 等(2022)利用三种原始变换及平滑度和强度参数生成多样域。然而，直接将这些方法应用于目标检测可能破坏目标的位置或语义标注，如图1(a)所示。Geirhos 等(2018)通过使用不会破坏目标标注的风格迁移(Gatys, Ecker, 和 Bethge，2016)避免了此问题，并提升了对合成扰动的鲁棒性。但S-DGOD的数据增强方法应生成涵盖广泛变换的多样域，而非有限变换集。所提OA-Mix采用目标感知策略，在不破坏目标标注的前提下创造多样域。

## Contrastive Learning for Domain Generalization

## 域泛化的对比学习

The contrastive learning methods for domain generalization build domain-invariant representations from multi-domain with sample-to-sample pairs (Yao et al. 2022; Kim et al. 2021; Li et al. 2021). The methods pull positive sample pairs of multi-domain and push negative samples away. PCL (Yao et al. 2022) arranges representative features and sample-to-sample pairs from multi-domain. SelfReg (Kim et al. 2021) aligns positive sample pairs and regularizes features with a self-supervised contrastive manner. PDEN (Li et al. 2021) progressively generates diverse domains and arranges features with a contrastive loss. However, these contrastive learning methods address semantic relations of sample-to-sample pairs only in object classes, not the background class.

域泛化的对比学习方法通过样本对构建多域的域不变表示(Yao 等，2022；Kim 等，2021；Li 等，2021)。这些方法拉近多域中正样本对，推远负样本。PCL(Yao 等，2022)安排多域的代表性特征和样本对。SelfReg(Kim 等，2021)对齐正样本对并以自监督对比方式正则化特征。PDEN(Li 等，2021)逐步生成多样域并用对比损失安排特征。然而，这些对比学习方法仅处理目标类别的样本对语义关系，未涉及背景类别。

## Single-Domain Generalization for Object Detection

## 单域泛化目标检测

Recently, several S-DGOD methods have been proposed. CycConf (Wang et al. 2021a) enforces the object detector to learn invariant representations across the same instances under various conditions. However, CycConf requires annotated video datasets, which are not generally given. CDSD (Wu and Deng 2022) propagates domain-invariant features to the detector with self-knowledge distillation. However, the model does not diversify the single-domain with data augmentation, which potentially can be improved. Vidit et al. (2023) utilized a pre-trained vision-language model to generalize a detector, but textual hints about the target domains should be given. Our proposed method does not require prior knowledge about target domains and achieves S-DGOD in an object-aware approach.

最近，提出了几种S-DGOD方法。CycConf(Wang等，2021a)强制目标检测器学习在不同条件下相同实例的不变表示。然而，CycConf需要带注释的视频数据集，而这类数据集通常不可得。CDSD(Wu和Deng，2022)通过自我知识蒸馏将域不变特征传播给检测器，但该模型未通过数据增强实现单域多样化，存在潜在改进空间。Vidit等(2023)利用预训练的视觉-语言模型来泛化检测器，但需要提供关于目标域的文本提示。我们提出的方法不依赖目标域的先验知识，并以面向对象的方式实现了S-DGOD。

## Method

## 方法

We propose OA-DG method for S-DGOD. Our approach consists of OA-Mix, which augments images, and OA-Loss, which achieves DG based on these augmented images. OA-DG can be applied to both one-stage and two-stage object detectors. The overview of OA-DG is illustrated in Figure 2.

我们提出了用于S-DGOD的OA-DG方法。该方法包括OA-Mix，用于图像增强，以及基于这些增强图像实现域泛化的OA-Loss。OA-DG可应用于一阶段和两阶段目标检测器。OA-DG的整体框架如图2所示。

![bo_d282q677aajc738orm7g_2_155_153_1486_500_0.jpg](images/bo_d282q677aajc738orm7g_2_155_153_1486_500_0.jpg)

Figure 2. Overview of OA-DG method. (a) OA-Mix transforms an image at multiple levels and mixes the transformed image with the original image in an object-aware manner. The original and augmented images are fed into the object detectors that share weights. (b) OA-Loss trains the object detectors to learn the domain-invariant representations from the original and augmented images. Circles, triangles, and stars represent car, person, and background classes, respectively. An augmented instance has white slanted lines. Another shape within a star indicates the partially included object in the background. The consistency loss aligns the original and augmented instances (dotted line). The contrastive loss aligns the positive pairs (dotted line) and repulses the negative pairs (arrow).

图2. OA-DG方法概览。(a) OA-Mix在多个层面变换图像，并以面向对象的方式将变换后的图像与原图混合。原图和增强图像输入共享权重的目标检测器。(b) OA-Loss训练目标检测器从原图和增强图像中学习域不变表示。圆形、三角形和星形分别代表汽车、行人和背景类别。增强实例带有白色斜线。星形内的另一形状表示背景中部分包含的对象。一致性损失对齐原始和增强实例(虚线)。对比损失对齐正样本对(虚线)并排斥负样本对(箭头)。

![bo_d282q677aajc738orm7g_2_165_940_685_488_0.jpg](images/bo_d282q677aajc738orm7g_2_165_940_685_488_0.jpg)

Figure 3. Overview of OA-Mix method. (a) Multi-level transformations generate locally diverse changes. Red and green boxes denote foreground and random regions, respectively. (b) Object-aware mixing strategy preserves semantic features against image transformations.

图3. OA-Mix方法概览。(a) 多层次变换生成局部多样化变化。红色和绿色框分别表示前景和随机区域。(b) 面向对象的混合策略在图像变换中保持语义特征。

## OA-Mix

## OA-Mix

Diversity and affinity are two important factors to be considered in data augmentation for S-DGOD. Diversity refers to the variety of features in the augmented image. Affinity refers to the distributional similarity between the original and augmented images. In other words, effective data augmentation methods should generate diverse data that does not deviate significantly from the distribution of the original data. This section decomposes OA-Mix into two components: multi-level transformation for diversity and object-aware mixing strategy for affinity.

多样性和亲和性是S-DGOD数据增强中需考虑的两个重要因素。多样性指增强图像中特征的多样化程度。亲和性指原始图像与增强图像之间的分布相似性。换言之，有效的数据增强方法应生成多样化且不显著偏离原始数据分布的数据。本节将OA-Mix分解为两部分:用于多样性的多层次变换和用于亲和性的面向对象混合策略。

Multi-Level Transformations OA-Mix enhances domain diversity by applying locally diverse changes within an image. Locally diverse changes can be achieved with a multilevel transformation strategy. As shown in Figure 3(a), an image is randomly divided into several regions such as foreground, background, and random box regions. Then, different transformation operations, such as color and spatial transformations, are randomly applied to each region. Spatial transformation operations are applied at the foreground level to preserve the location of the object. As a result, multilevel transformation enhances the domain diversity of the augmented image without damaging the object locations

多层次变换 OA-Mix通过在图像内施加局部多样化变化来增强域多样性。局部多样化变化可通过多层次变换策略实现。如图3(a)所示，图像被随机划分为多个区域，如前景、背景和随机框区域。然后，针对每个区域随机应用不同的变换操作，如颜色和空间变换。空间变换操作应用于前景层，以保持对象位置。因此，多层次变换在不破坏对象位置的前提下增强了增强图像的域多样性。

Object-Aware Mixing In object detection, each object in an image has different characteristics, such as size, location, and color distribution. Depending on these object-specific characteristics, transformations can damage the semantic features of an object. For example, Figure 3(b) shows that image transformation can damage the semantic features of objects with monotonous color distribution. Previous works mix the original and augmented images at the image level to mitigate the degradation of semantic features. However, the method of mixing the entire image with the same weight does not sufficiently utilize object information.

面向对象的混合 在目标检测中，图像中的每个对象具有不同特征，如大小、位置和颜色分布。基于这些对象特性，变换可能损害对象的语义特征。例如，图3(b)显示图像变换可能损害颜色分布单一对象的语义特征。以往工作在图像层面混合原图和增强图像以减轻语义特征退化，但以相同权重混合整张图像的方法未能充分利用对象信息。

Therefore, we calculate the saliency score $s$ for each object based on the saliency map to consider the properties of each object. The saliency score is calculated as $\mathbf{S} \in  {\mathbb{R}}^{h \times  w}$ from object with size $h \times  w$ :

因此，我们基于显著性图为每个对象计算显著性分数$s$，以考虑各对象属性。显著性分数根据对象大小$h \times  w$计算为$\mathbf{S} \in  {\mathbb{R}}^{h \times  w}$:

$$
s = \frac{1}{hw}\mathop{\sum }\limits_{{x = 1}}^{w}\mathop{\sum }\limits_{{y = 1}}^{h}{\mathbf{S}}_{x, y}. \tag{1}
$$

Specifically, the saliency map is a spatial representation of the spectral residual, which is the unpredictable frequency in an image. The object with a high saliency score has clear semantic signals. In contrast, the object with a low score has weak semantic signals as shown in Figure 3(b). Object-aware mixing strategy increases the mixing weight of the original image for objects with low saliency scores, thereby preventing semantic feature damage. Specifically, for each area $P$ of the image, it linearly combines the original and augmented images with the mixing weight $m$ :

具体而言，显著性图是频谱残差的空间表示，频谱残差为图像中不可预测的频率。显著性分数高的对象具有清晰的语义信号。相反，显著性分数低的对象语义信号较弱，如图3(b)所示。面向对象的混合策略增加显著性分数低对象的原图混合权重，从而防止语义特征损害。具体地，对于图像的每个区域$P$，以混合权重$m$线性组合原图和增强图像:

$$
{\mathbf{I}}_{\text{oamix }} = \mathop{\sum }\limits_{P}\left( {m{\mathbf{I}}_{\text{aug }}^{P} + \left( {1 - m}\right) {\mathbf{I}}_{\text{orig }}^{P}}\right) ,
$$

where $m$ is sampled from different distributions depending on saliency score $s$ . As a result, the strategy enhances the affinity of the augmented image, mitigating the negative effects of transformations.

其中$m$根据显著性分数$s$从不同分布采样。该策略增强了增强图像的亲和性，减轻了变换的负面影响。

## OA-Loss

## OA-Loss

OA-Loss is designed to train the domain-invariant representations between the original and OA-Mixed domains in an object-aware approach. The object-aware method arranges instances in multi-domain according to the semantics of the instances. OA-Loss does not depend on any object detection framework and can be applied to both one-stage and two-stage detection frameworks.

OA-Loss旨在以面向对象的方式训练原始域与OA-Mixed域之间的域不变表示。该面向对象的方法根据实例的语义在多域中排列实例。OA-Loss不依赖任何目标检测框架，且可应用于一阶段和两阶段检测框架。

Review of Supervised Contrastive Learning The supervised contrastive learning methods construct positive pairs for the same class and negative pairs for different classes (Khosla et al. 2020; Sun et al. 2021; Yao et al. 2022). The methods align intra-class and repulse inter-class instances in the embedding space. Previous methods for object detection (Sun et al. 2021) utilized only the foreground instances and ignored the semantic relations among background instances. In contrast, we explore the meaning of background instances for domain-invariant representations.

监督对比学习综述 监督对比学习方法为同一类别构建正样本对，为不同类别构建负样本对(Khosla等，2020；Sun等，2021；Yao等，2022)。这些方法在嵌入空间中对齐类内实例，排斥类间实例。以往的目标检测方法(Sun等，2021)仅利用前景实例，忽略了背景实例之间的语义关系。相比之下，我们探讨了背景实例在域不变表示中的意义。

Meaning of Background Instances In object detection, each instance feature is labeled as the background if all intersection of unions (IoUs) with the ground-truth set are less than an IoU threshold, and foreground otherwise. Instance features correspond to region proposals and grid cell features in two-stage and one-stage detection frameworks, respectively.

背景实例的意义 在目标检测中，若某实例与真实标注集合的所有交并比(IoU)均低于阈值，则该实例特征被标记为背景，否则为前景。实例特征分别对应于两阶段检测框架中的区域提议和一阶段检测框架中的网格单元特征。

The background instances can partially contain the foreground object of different classes However, existing supervised contrastive learning methods (Khosla et al. 2020; Kang et al. 2021; Li et al. 2022; Yao et al. 2022) regard different background instances identically and form positive pairs, leading to false semantic relations of foreground objects. Therefore, the relationship between background instances is required to be defined in an object-aware manner.

背景实例可能部分包含不同类别的前景对象，然而现有的监督对比学习方法(Khosla等，2020；Kang等，2021；Li等，2022；Yao等，2022)将不同的背景实例视为相同，构成正样本对，导致前景对象的语义关系错误。因此，背景实例之间的关系需要以面向对象的方式定义。

OA Contrastive Learning OA-Loss trains the semantic relations among instances in an object-aware approach to reduce the multi-domain gap. For foreground instances, the method pulls the same class and pushes different classes away to improve object classification in multi-domain (Sun et al. 2021). For background instances, the method pushes background instances away from each other except for the augmented instances as shown in Figure 2. OA-Loss trains the model to discriminate between background instances containing foreground objects of various classes. As a result, our approach reflects the meaning of the background class, which is difficult to define as a single class.

面向对象的对比学习 OA-Loss以面向对象的方式训练实例间的语义关系，以缩小多域间的差距。对于前景实例，该方法拉近同类实例，推远异类实例，以提升多域中的目标分类性能(Sun等，2021)。对于背景实例，除增强实例外，该方法将背景实例彼此推远，如图2所示。OA-Loss训练模型区分包含不同类别前景对象的背景实例。因此，我们的方法反映了背景类别的含义，该类别难以定义为单一类别。

In addition, the negative pairs of background instances repulse each other, helping the model to output different features. OA-Loss allows the model to generate various background features and trains the multi-domain gaps for various features, further improving generalization capability of the object detector.

此外，背景实例的负样本对相互排斥，帮助模型输出不同的特征。OA-Loss使模型能够生成多样的背景特征，并针对多样特征训练多域差距，进一步提升目标检测器的泛化能力。

To incorporate positive and negative sample pairs into contrastive learning, we encode the instance features into contrastive features $\mathbf{Z}$ . Following supervised contrastive learning (Kim et al. 2021; Sun et al. 2021), a contrastive branch is introduced parallel to the classification and regression branches as shown in Figure 2. The contrastive branch consists of two layer multilayer perceptrons (MLPs). The contrastive branch generates feature set $\mathbf{Z}$ from the multilevel regions of OA-Mix and proposed regions of the model. The multi-level regions enable detectors to learn semantic relations in a wider variety of domains.

为将正负样本对纳入对比学习，我们将实例特征编码为对比特征$\mathbf{Z}$。遵循监督对比学习(Kim等，2021；Sun等，2021)，在分类和回归分支的并行位置引入对比分支，如图2所示。对比分支由两层多层感知机(MLP)组成。对比分支从OA-Mix的多层区域和模型的提议区域生成特征集$\mathbf{Z}$。多层区域使检测器能够学习更广泛域中的语义关系。

We set each contrastive feature ${\mathbf{z}}_{i} \in  \mathbf{Z}$ as an anchor. The positive set of each feature ${\mathbf{z}}_{i}$ is defined as:

我们将每个对比特征${\mathbf{z}}_{i} \in  \mathbf{Z}$设为锚点。每个特征${\mathbf{z}}_{i}$的正样本集定义为:

$$
{\mathbf{Z}}_{i}^{\text{pos }} = \left\{  \begin{array}{ll} \left\{  {\mathbf{z} \mid  y\left( \mathbf{z}\right)  = y\left( {\mathbf{z}}_{i}\right) ,\forall \mathbf{z} \in  \mathbf{Z} \smallsetminus  \left\{  {\mathbf{z}}_{i}\right\}  }\right\}  & \text{ if foreground } \\  \left\{  {\mathbf{z}}_{i}^{\prime }\right\}  & \text{ otherwise,} \end{array}\right.  \tag{2}
$$

where $y$ is the label mapping function for feature $\mathbf{z}.{\mathbf{z}}^{\prime }$ is the augmented feature from $\mathbf{z}$ . The positive set ${\mathbf{Z}}^{\text{pos }}$ is defined as the same class for foreground anchors and the same instance for background anchors. The proposed contrastive loss ${L}_{ct}$ is defined as:

其中$y$为特征的标签映射函数，$\mathbf{z}.{\mathbf{z}}^{\prime }$为来自$\mathbf{z}$的增强特征。正样本集${\mathbf{Z}}^{\text{pos }}$定义为前景锚点的同类和背景锚点的同实例。所提出的对比损失${L}_{ct}$定义为:

$$
{L}_{ct} = \frac{1}{\left| \mathbf{Z}\right| }\mathop{\sum }\limits_{{{\mathbf{z}}_{i} \in  \mathbf{Z}}}{L}_{{\mathbf{z}}_{i}}, \tag{3}
$$

$$
{L}_{{\mathbf{z}}_{i}} = \frac{-1}{\left| {\mathbf{Z}}_{i}^{\text{pos }}\right| }\mathop{\sum }\limits_{{{\mathbf{z}}_{j} \in  {\mathbf{Z}}_{i}^{\text{pos }}}}\log \frac{\exp \left( {{\widetilde{\mathbf{z}}}_{i} \cdot  {\widetilde{\mathbf{z}}}_{j}/\tau }\right) }{\mathop{\sum }\limits_{{{\mathbf{z}}_{k} \in  \mathbf{Z} \smallsetminus  \left\{  {\mathbf{z}}_{i}\right\}  }}\exp \left( {{\widetilde{\mathbf{z}}}_{i} \cdot  {\widetilde{\mathbf{z}}}_{k}/\tau }\right) }, \tag{4}
$$

where $\left| \mathbf{Z}\right|$ and $\left| {\mathbf{Z}}_{i}^{\text{pos }}\right|$ are the cardinalities of $\mathbf{Z}$ and ${\mathbf{Z}}_{i}^{\text{pos }}$ , respectively. $\tau$ is the temperature scaling parameter and ${\widetilde{\mathbf{z}}}_{i} =$ $\frac{{\mathbf{z}}_{i}}{\left| \right| {\mathbf{z}}_{i}\left| \right| }$ denotes normalized features. The contrastive loss optimizes the feature similarity to align instances for the positive set ${\mathbf{Z}}_{i}^{\text{pos }}$ , and repulse otherwise.

其中$\left| \mathbf{Z}\right|$和$\left| {\mathbf{Z}}_{i}^{\text{pos }}\right|$分别为$\mathbf{Z}$和${\mathbf{Z}}_{i}^{\text{pos }}$的基数。$\tau$为温度缩放参数，${\widetilde{\mathbf{z}}}_{i} =$ $\frac{{\mathbf{z}}_{i}}{\left| \right| {\mathbf{z}}_{i}\left| \right| }$表示归一化特征。对比损失优化特征相似度，使正样本集${\mathbf{Z}}_{i}^{\text{pos }}$内的实例对齐，反之则排斥。

We also designed the consistency loss to reduce the gap between the original and augmented domains at logit-level. To make consistent output in multi-domain (Hendrycks et al. 2019; Modas et al. 2022), we adopt Jensen-Shannon (JS) divergence as the consistency loss to reduce the gap between the original and OA-Mixed domains. JS divergence is a symmetric and smoothed version of the Kullback-Leibler (KL) divergence. The consistency loss is defined as:

我们还设计了一致性损失，以在logit层面减少原始域与增强域之间的差距。为了在多域(Hendrycks 等，2019；Modas 等，2022)中实现一致的输出，我们采用了Jensen-Shannon(JS)散度作为一致性损失，以缩小原始域与OA-Mixed域之间的差距。JS散度是Kullback-Leibler(KL)散度的对称且平滑版本。一致性损失定义为:

$$
{L}_{cs} = \frac{1}{2}\left( {\mathbf{{KL}}\left\lbrack  {\mathbf{p}\parallel \mathbf{M}}\right\rbrack   + \mathbf{{KL}}\left\lbrack  {{\mathbf{p}}_{ + }\parallel \mathbf{M}}\right\rbrack  }\right) , \tag{5}
$$

where $\mathbf{p}$ and ${\mathbf{p}}_{ + }$ are model predictions from original and OA-Mixed images, respectively. $\mathbf{M} = \frac{1}{2}\left( {\mathbf{p} + {\mathbf{p}}_{ + }}\right)$ is the mixture probability of predictions. The loss improves the generalization ability to classify the objects in OOD.

其中$\mathbf{p}$和${\mathbf{p}}_{ + }$分别是来自原始图像和OA-Mixed图像的模型预测，$\mathbf{M} = \frac{1}{2}\left( {\mathbf{p} + {\mathbf{p}}_{ + }}\right)$是预测的混合概率。该损失提升了对OOD(域外数据)中对象分类的泛化能力。

<table><tr><td rowspan="2">Method</td><td rowspan="2">Clean</td><td colspan="3">Noise</td><td colspan="4">Blur</td><td colspan="4">Weather</td><td colspan="4">Digital</td><td rowspan="2">mPC</td></tr><tr><td>Gauss.</td><td>Shot</td><td>Impulse</td><td>Defocus</td><td>Glass</td><td>Motion</td><td>Zoom</td><td>Snow</td><td>Frost</td><td>Fog</td><td>Bright</td><td>Contrast</td><td>Elastic</td><td>Pixel</td><td>JPEG’</td></tr><tr><td>Standard</td><td>42.2</td><td>0.5</td><td>1.1</td><td>1.1</td><td>17.2</td><td>16.5</td><td>18.3</td><td>2.1</td><td>2.2</td><td>12.3</td><td>29.8</td><td>32.0</td><td>24.1</td><td>40.1</td><td>18.7</td><td>15.1</td><td>15.4</td></tr><tr><td colspan="18">+ Data augmentation</td></tr><tr><td>Cutout</td><td>42.5</td><td>0.6</td><td>1.2</td><td>1.2</td><td>17.8</td><td>15.9</td><td>18.9</td><td>2.0</td><td>2.5</td><td>13.6</td><td>29.8</td><td>32.3</td><td>24.6</td><td>40.1</td><td>18.9</td><td>15.6</td><td>15.7</td></tr><tr><td>Photo’</td><td>42.7</td><td>1.6</td><td>2.7</td><td>1.9</td><td>17.9</td><td>14.1</td><td>18.7</td><td>2.0</td><td>2.4</td><td>16.5</td><td>36.0</td><td>39.1</td><td>27.1</td><td>39.7</td><td>18.0</td><td>16.4</td><td>16.9</td></tr><tr><td>AutoAug-det †</td><td>42.4</td><td>0.9</td><td>1.6</td><td>0.9</td><td>16.8</td><td>14.4</td><td>18.9</td><td>2.0</td><td>1.9</td><td>16.0</td><td>32.9</td><td>35.2</td><td>26.3</td><td>39.4</td><td>17.9</td><td>11.6</td><td>15.8</td></tr><tr><td>AugMix</td><td>39.5</td><td>5.0</td><td>6.8</td><td>5.1</td><td>18.3</td><td>18.1</td><td>19.3</td><td>6.2</td><td>5.0</td><td>20.5</td><td>31.2</td><td>33.7</td><td>25.6</td><td>37.4</td><td>20.3</td><td>19.6</td><td>18.1</td></tr><tr><td>Stylized</td><td>36.3</td><td>4.8</td><td>6.8</td><td>4.3</td><td>19.5</td><td>18.7</td><td>18.5</td><td>2.7</td><td>3.5</td><td>17.0</td><td>30.5</td><td>31.9</td><td>22.7</td><td>33.9</td><td>22.6</td><td>20.8</td><td>17.2</td></tr><tr><td>OA-Mix (ours)</td><td>42.7</td><td>7.2</td><td>9.6</td><td>7.7</td><td>22.8</td><td>18.8</td><td>21.9</td><td>5.4</td><td>5.2</td><td>23.6</td><td>37.3</td><td>38.7</td><td>31.9</td><td>40.2</td><td>22.2</td><td>20.2</td><td>20.8</td></tr><tr><td colspan="18">+ Loss function</td></tr><tr><td>SupCon</td><td>43.2</td><td>7.0</td><td>9.5</td><td>7.4</td><td>22.6</td><td>20.2</td><td>22.3</td><td>4.3</td><td>5.3</td><td>23.0</td><td>37.3</td><td>38.9</td><td>31.6</td><td>40.1</td><td>24.0</td><td>20.1</td><td>20.9</td></tr><tr><td>FSCE</td><td>43.1</td><td>7.4</td><td>10.2</td><td>8.2</td><td>23.3</td><td>20.3</td><td>21.5</td><td>4.8</td><td>5.6</td><td>23.6</td><td>37.1</td><td>38.0</td><td>31.9</td><td>40.0</td><td>23.2</td><td>20.4</td><td>21.0</td></tr><tr><td>OA-Loss (ours) = OA-DG</td><td>43.4</td><td>8.2</td><td>10.6</td><td>8.4</td><td>24.6</td><td>20.5</td><td>22.3</td><td>4.8</td><td>6.1</td><td>25.0</td><td>38.4</td><td>39.7</td><td>32.8</td><td>40.2</td><td>23.8</td><td>22.0</td><td>21.8</td></tr><tr><td colspan="18">${}^{ \dagger  }$ We followed the searched policies (Zoph et al. 2020).</td></tr></table>

<table><tbody><tr><td rowspan="2">方法</td><td rowspan="2">干净</td><td colspan="3">噪声</td><td colspan="4">模糊</td><td colspan="4">天气</td><td colspan="4">数字</td><td rowspan="2">mPC</td></tr><tr><td>高斯(Gauss.)</td><td>散粒噪声</td><td>脉冲噪声</td><td>散焦</td><td>玻璃</td><td>运动</td><td>变焦</td><td>雪</td><td>霜</td><td>雾</td><td>亮度</td><td>对比度</td><td>弹性变换</td><td>像素</td><td>JPEG</td></tr><tr><td>标准</td><td>42.2</td><td>0.5</td><td>1.1</td><td>1.1</td><td>17.2</td><td>16.5</td><td>18.3</td><td>2.1</td><td>2.2</td><td>12.3</td><td>29.8</td><td>32.0</td><td>24.1</td><td>40.1</td><td>18.7</td><td>15.1</td><td>15.4</td></tr><tr><td colspan="18">+ 数据增强</td></tr><tr><td>遮挡(Cutout)</td><td>42.5</td><td>0.6</td><td>1.2</td><td>1.2</td><td>17.8</td><td>15.9</td><td>18.9</td><td>2.0</td><td>2.5</td><td>13.6</td><td>29.8</td><td>32.3</td><td>24.6</td><td>40.1</td><td>18.9</td><td>15.6</td><td>15.7</td></tr><tr><td>照片</td><td>42.7</td><td>1.6</td><td>2.7</td><td>1.9</td><td>17.9</td><td>14.1</td><td>18.7</td><td>2.0</td><td>2.4</td><td>16.5</td><td>36.0</td><td>39.1</td><td>27.1</td><td>39.7</td><td>18.0</td><td>16.4</td><td>16.9</td></tr><tr><td>AutoAug-det †</td><td>42.4</td><td>0.9</td><td>1.6</td><td>0.9</td><td>16.8</td><td>14.4</td><td>18.9</td><td>2.0</td><td>1.9</td><td>16.0</td><td>32.9</td><td>35.2</td><td>26.3</td><td>39.4</td><td>17.9</td><td>11.6</td><td>15.8</td></tr><tr><td>AugMix</td><td>39.5</td><td>5.0</td><td>6.8</td><td>5.1</td><td>18.3</td><td>18.1</td><td>19.3</td><td>6.2</td><td>5.0</td><td>20.5</td><td>31.2</td><td>33.7</td><td>25.6</td><td>37.4</td><td>20.3</td><td>19.6</td><td>18.1</td></tr><tr><td>风格化</td><td>36.3</td><td>4.8</td><td>6.8</td><td>4.3</td><td>19.5</td><td>18.7</td><td>18.5</td><td>2.7</td><td>3.5</td><td>17.0</td><td>30.5</td><td>31.9</td><td>22.7</td><td>33.9</td><td>22.6</td><td>20.8</td><td>17.2</td></tr><tr><td>OA-Mix(本方法)</td><td>42.7</td><td>7.2</td><td>9.6</td><td>7.7</td><td>22.8</td><td>18.8</td><td>21.9</td><td>5.4</td><td>5.2</td><td>23.6</td><td>37.3</td><td>38.7</td><td>31.9</td><td>40.2</td><td>22.2</td><td>20.2</td><td>20.8</td></tr><tr><td colspan="18">+ 损失函数</td></tr><tr><td>SupCon</td><td>43.2</td><td>7.0</td><td>9.5</td><td>7.4</td><td>22.6</td><td>20.2</td><td>22.3</td><td>4.3</td><td>5.3</td><td>23.0</td><td>37.3</td><td>38.9</td><td>31.6</td><td>40.1</td><td>24.0</td><td>20.1</td><td>20.9</td></tr><tr><td>FSCE</td><td>43.1</td><td>7.4</td><td>10.2</td><td>8.2</td><td>23.3</td><td>20.3</td><td>21.5</td><td>4.8</td><td>5.6</td><td>23.6</td><td>37.1</td><td>38.0</td><td>31.9</td><td>40.0</td><td>23.2</td><td>20.4</td><td>21.0</td></tr><tr><td>OA-Loss(本方法)= OA-DG</td><td>43.4</td><td>8.2</td><td>10.6</td><td>8.4</td><td>24.6</td><td>20.5</td><td>22.3</td><td>4.8</td><td>6.1</td><td>25.0</td><td>38.4</td><td>39.7</td><td>32.8</td><td>40.2</td><td>23.8</td><td>22.0</td><td>21.8</td></tr><tr><td colspan="18">${}^{ \dagger  }$ 我们遵循了搜索到的策略(Zoph 等，2020)。</td></tr></tbody></table>

Table 1. Comparison with state-of-the-art methods on Cityscapes-C. For each corruption type, the average performance was calculated. mPC is an average performance of 15 corruption types.

表1. 在Cityscapes-C数据集上与最先进方法的比较。对于每种腐败类型，计算了平均性能。mPC是15种腐败类型的平均性能。

Training Objectives Our method trains the base detector in an end-to-end manner. Our OA-Loss ${L}_{OA}$ consists of consistency loss ${L}_{cs}$ and contrastive loss ${L}_{ct}$ .

训练目标 我们的方法以端到端的方式训练基础检测器。我们的OA损失(OA-Loss)${L}_{OA}$由一致性损失${L}_{cs}$和对比损失${L}_{ct}$组成。

$$
{L}_{OA} = {L}_{cs} + \gamma {L}_{ct}, \tag{6}
$$

where $\gamma$ is hyperparameter. OA-Loss can be added to the original loss ${L}_{\text{det }}$ for the general detector. The joint training loss is defined as

其中$\gamma$是超参数。OA损失可以加到通用检测器的原始损失${L}_{\text{det }}$中。联合训练损失定义为

$$
L = {L}_{det} + \lambda {L}_{OA}, \tag{7}
$$

where $\lambda$ balances the scales of the losses. The joint training loss allows the model to learn object semantics and domain-invariant representations from OA-Mixed domains.

其中$\lambda$用于平衡各损失的尺度。联合训练损失使模型能够从OA混合域(OA-Mixed domains)中学习目标语义和域不变表示。

## Experiments

## 实验

In this section, we evaluate the robustness of our method against out-of-distribution. We also conduct ablation studies to verify the effectiveness of proposed modules.

本节中，我们评估了方法对分布外(out-of-distribution)数据的鲁棒性。同时进行了消融研究以验证所提模块的有效性。

## Datasets

## 数据集

We evaluated the DG performance of our method in an urban scene for common corruptions and various weather conditions. Cityscapes-C (Michaelis et al. 2019) is a test benchmark to evaluate object detection robustness to corrupted domains. Cityscapes-C provides 15 corruptions on five severity levels. The corruptions are divided into four categories: noise, blur, weather, and digital. These corruption types are used to measure and understand the robustness against OOD (Dan and Thomas 2019). The common corruptions should be used only to evaluate the robustness of the model and are strictly prohibited to be used during training.

我们在城市场景中评估了方法对常见腐败和多种天气条件下的域泛化性能。Cityscapes-C(Michaelis等，2019)是一个用于评估目标检测对腐败域鲁棒性的测试基准。Cityscapes-C提供了15种腐败类型，分为五个严重程度等级。腐败类型分为四类:噪声、模糊、天气和数字腐败。这些腐败类型用于衡量和理解对分布外(OOD，Dan和Thomas 2019)数据的鲁棒性。常见腐败仅用于评估模型鲁棒性，严禁在训练中使用。

Diverse Weather Dataset (DWD) is an urban-scene detection benchmark to assess object detection robustness to various weather conditions. DWD collected data from BDD-100k (2020), FoggyCityscapes (2018), and Adverse-Weather (2020) datasets. It consists of five different weather conditions: daytime-sunny, night-sunny, dusk-rainy, night-rainy, and daytime-foggy. Training should be conducted only using the daytime-sunny dataset and robustness is evaluated against other adverse weather datasets.

多样天气数据集(Diverse Weather Dataset，DWD)是一个城市场景检测基准，用于评估目标检测对多种天气条件的鲁棒性。DWD收集了BDD-100k(2020)、FoggyCityscapes(2018)和Adverse-Weather(2020)数据集的数据。包含五种不同天气条件:白天晴朗、夜晚晴朗、黄昏雨天、夜晚雨天和白天有雾。训练仅使用白天晴朗数据集，鲁棒性则在其他恶劣天气数据集上评估。

## Evaluation Metrics

## 评估指标

Following (Michaelis et al. 2019; Wu and Deng 2022), we evaluate the domain generalization performance of our method in various domains using mean average precision (mAP). The robustness against OOD is evaluated using mean performance under corruption (mPC), which is the average of mAPs for all corrupted domains and severity levels.

遵循(Michaelis等，2019；Wu和Deng，2022)，我们使用平均精度均值(mAP)评估方法在不同域的域泛化性能。对分布外(OOD)的鲁棒性使用腐败下的平均性能(mPC)评估，即所有腐败域和严重程度的mAP平均值。

$$
\mathrm{{mPC}} = \frac{1}{{N}_{C}}\mathop{\sum }\limits_{{C = 1}}^{{N}_{C}}\frac{1}{{N}_{S}}\mathop{\sum }\limits_{{S = 1}}^{{N}_{S}}{P}_{C, S}, \tag{8}
$$

where ${P}_{C, S}$ is the performance on the test data corrupted by corruption $C$ at severity level $S,{N}_{C}$ and ${N}_{S}$ are the number of corruption and severity, respectively. ${N}_{C}$ and ${N}_{S}$ are set to 15 and 5 in Cityscapes-C; and 4 and 1 in DWD, respectively.

其中${P}_{C, S}$是由腐败类型$C$在严重程度$S,{N}_{C}$下腐败的测试数据上的性能，${N}_{S}$和${N}_{C}$分别是腐败类型数和严重程度数。Cityscapes-C中${N}_{C}$和${N}_{S}$分别设为15和5；DWD中分别设为4和1。

## Robustness on Common Corruptions

## 常见腐败下的鲁棒性

Table 1 shows the performance of the state-of-the-art models on clean and corrupted domains. The baseline model is Faster R-CNN with ResNet-50 and feature pyramid networks (FPN). Each model is trained only on the clean domain and evaluated on both the clean and corrupted domains. Temperature scaling parameter $\tau$ for contrastive loss is set to 0.06 . We set $\lambda$ and $\gamma$ to 10 and 0.001 . More details can be seen in the supplementary material.

表1展示了最先进模型在干净和腐败域上的性能。基线模型为采用ResNet-50和特征金字塔网络(FPN)的Faster R-CNN。每个模型仅在干净域上训练，并在干净及腐败域上评估。对比损失的温度缩放参数$\tau$设为0.06。我们将$\lambda$和$\gamma$分别设为10和0.001。更多细节见补充材料。

Cutout (Zhong et al. 2020) and photometric distortion (Redmon and Farhadi 2018) are data augmentation methods that can improve the generalization performance of object detectors. However, they showed limited improvements in performance on corrupted domains. AutoAug-det (Zoph et al. 2020) explores augmentation policies for the generalization of object detection. The method improved performance in the clean domain, but there was no significant performance improvement in the corrupted domain.

Cutout(Zhong等，2020)和光度失真(Redmon和Farhadi，2018)是可提升目标检测器泛化性能的数据增强方法，但在腐败域上的性能提升有限。AutoAug-det(Zoph等，2020)探索了目标检测泛化的数据增强策略，该方法提升了干净域性能，但在腐败域上未见显著性能提升。

<table><tr><td rowspan="2"/><td colspan="5">mAP</td><td rowspan="2">mPC</td></tr><tr><td>Daytime- sunny</td><td>Night- sunny</td><td>Dusk- rainy</td><td>Night- rainy</td><td>Daytime- foggy</td></tr><tr><td>Baseline</td><td>48.1</td><td>34.4</td><td>26.0</td><td>12.4</td><td>32.0</td><td>26.2</td></tr><tr><td>SW</td><td>50.6</td><td>33.4</td><td>26.3</td><td>13.7</td><td>30.8</td><td>26.1</td></tr><tr><td>IBN-Net</td><td>49.7</td><td>32.1</td><td>26.1</td><td>14.3</td><td>29.6</td><td>25.5</td></tr><tr><td>IterNorm</td><td>43.9</td><td>29.6</td><td>22.8</td><td>12.6</td><td>28.4</td><td>23.4</td></tr><tr><td>ISW</td><td>51.3</td><td>33.2</td><td>25.9</td><td>14.1</td><td>31.8</td><td>26.3</td></tr><tr><td>SHADE</td><td>-</td><td>33.9</td><td>29.5</td><td>16.8</td><td>33.4</td><td>28.4</td></tr><tr><td>CDSD</td><td>56.1</td><td>36.6</td><td>28.2</td><td>16.6</td><td>33.5</td><td>28.7</td></tr><tr><td>SRCD</td><td>-</td><td>36.7</td><td>28.8</td><td>17.0</td><td>35.9</td><td>29.6</td></tr><tr><td>Ours</td><td>55.8</td><td>38.0</td><td>33.9</td><td>16.8</td><td>38.3</td><td>31.8</td></tr></table>

<table><tbody><tr><td rowspan="2"></td><td colspan="5">平均精度均值(mAP)</td><td rowspan="2">平均类别精度(mPC)</td></tr><tr><td>白天-晴朗</td><td>夜晚-晴朗</td><td>黄昏-雨天</td><td>夜晚-雨天</td><td>白天-有雾</td></tr><tr><td>基线</td><td>48.1</td><td>34.4</td><td>26.0</td><td>12.4</td><td>32.0</td><td>26.2</td></tr><tr><td>SW</td><td>50.6</td><td>33.4</td><td>26.3</td><td>13.7</td><td>30.8</td><td>26.1</td></tr><tr><td>IBN-Net</td><td>49.7</td><td>32.1</td><td>26.1</td><td>14.3</td><td>29.6</td><td>25.5</td></tr><tr><td>IterNorm</td><td>43.9</td><td>29.6</td><td>22.8</td><td>12.6</td><td>28.4</td><td>23.4</td></tr><tr><td>ISW</td><td>51.3</td><td>33.2</td><td>25.9</td><td>14.1</td><td>31.8</td><td>26.3</td></tr><tr><td>SHADE</td><td>-</td><td>33.9</td><td>29.5</td><td>16.8</td><td>33.4</td><td>28.4</td></tr><tr><td>CDSD</td><td>56.1</td><td>36.6</td><td>28.2</td><td>16.6</td><td>33.5</td><td>28.7</td></tr><tr><td>SRCD</td><td>-</td><td>36.7</td><td>28.8</td><td>17.0</td><td>35.9</td><td>29.6</td></tr><tr><td>本方法</td><td>55.8</td><td>38.0</td><td>33.9</td><td>16.8</td><td>38.3</td><td>31.8</td></tr></tbody></table>

Table 2. Comparison with state-of-the-art methods on Diverse Weather Dataset. mPC is an average performance of OOD weathers: night-sunny, dusk-rainy, night-sunny, and daytime-foggy.

表2. 在多样天气数据集上的最新方法比较。mPC是OOD天气的平均性能:夜间晴天、黄昏雨天、夜间晴天和白天雾天。

AugMix (Hendrycks et al. 2019) and stylized augmentation (Geirhos et al. 2018) are effective for S-DG in image classification. AugMix generates augmented images with unclear object locations, leading to a performance drop on the clean domain. Stylized augmentation improved performance on the corrupted domains with style transfer. However, the method did not consider affinity with the original domain, which decreased performance in the clean domain.

AugMix(Hendrycks等，2019)和风格化增强(Geirhos等，2018)在图像分类的单域泛化(S-DG)中效果显著。AugMix生成的增强图像中物体位置模糊，导致在干净域上的性能下降。风格化增强通过风格迁移提升了损坏域的性能，但该方法未考虑与原始域的亲和性，导致干净域性能下降。

In contrast, OA-Mix maintains the clean domain performance with an object-aware mixing and improves the DG performance with multi-level transformations. Furthermore, we evaluated contrastive methods combined with OA-Mix. SupCon (Khosla et al. 2020) and FSCE (Sun et al. 2021) are contrastive learning methods that can reduce the multi-domain gap. The methods improved the clean performance, but the performance for the corrupted domain was not improved significantly. OA-Loss trains the semantic relations in an object-aware approach and achieved higher performance in both clean and corrupted domains. Consequently, OA-DG showed the best performance with ${43.4}\mathrm{{mAP}}$ and ${21.8}\mathrm{{mPC}}$ in the clean and corrupted domains, respectively.

相比之下，OA-Mix通过物体感知混合保持了干净域性能，并通过多层次变换提升了域泛化性能。此外，我们评估了与OA-Mix结合的对比学习方法。SupCon(Khosla等，2020)和FSCE(Sun等，2021)是能够缩小多域差距的对比学习方法。这些方法提升了干净域性能，但对损坏域性能提升不显著。OA-Loss以物体感知方式训练语义关系，在干净域和损坏域均取得更高性能。因此，OA-DG在干净域和损坏域分别以${43.4}\mathrm{{mAP}}$和${21.8}\mathrm{{mPC}}$表现最佳。

## Robustness on Various Weather Conditions

## 各种天气条件下的鲁棒性

Table 2 shows the DG performances in real-world weather conditions through DWD. We follow the settings in the CDSD (Wu and Deng 2022) for DWD. We used Faster R-CNN with ResNet-101 backbone as a base object detector. Temperature scaling hyperparameter $\tau$ is set to 0.07 . We set $\lambda$ and $\gamma$ to 10 and 0.001, respectively, for Faster R-CNN. More details can be seen in the supplementary material.

表2展示了通过DWD在真实天气条件下的域泛化性能。我们遵循CDSD(Wu和Deng，2022)中DWD的设置。基准目标检测器采用带ResNet-101骨干的Faster R-CNN。温度缩放超参数$\tau$设为0.07。Faster R-CNN的$\lambda$和$\gamma$分别设为10和0.001。更多细节见补充材料。

OA-DG is compared with state-of-the-art S-DGOD methods. SW (Pan et al. 2019), IBN-Net (Pan et al. 2018), Iter-Norm (Huang et al. 2019), ISW (Choi et al. 2021), and

OA-DG与最新的单域泛化目标检测(S-DGOD)方法进行了比较。SW(Pan等，2019)、IBN-Net(Pan等，2018)、Iter-Norm(Huang等，2019)、ISW(Choi等，2021)以及

<table><tr><td>Transformations</td><td>Mixing strategy</td><td>mAP</td><td>mPC</td></tr><tr><td>✘</td><td>✘</td><td>42.2</td><td>15.4</td></tr><tr><td>Single-level</td><td>✘</td><td>39.9</td><td>16.8</td></tr><tr><td>Multi-level</td><td>✘</td><td>40.5</td><td>17.5</td></tr><tr><td>Multi-level</td><td>Standard</td><td>41.6</td><td>19.7</td></tr><tr><td>Multi-level</td><td>Object-aware</td><td>42.7</td><td>20.8</td></tr></table>

<table><tbody><tr><td>变换</td><td>混合策略</td><td>平均精度均值(mAP)</td><td>平均分类准确率(mPC)</td></tr><tr><td>✘</td><td>✘</td><td>42.2</td><td>15.4</td></tr><tr><td>单层级</td><td>✘</td><td>39.9</td><td>16.8</td></tr><tr><td>多层级</td><td>✘</td><td>40.5</td><td>17.5</td></tr><tr><td>多层级</td><td>标准</td><td>41.6</td><td>19.7</td></tr><tr><td>多层级</td><td>对象感知</td><td>42.7</td><td>20.8</td></tr></tbody></table>

Table 3. Ablation analysis of our proposed OA-Mix on Cityscapes-C dataset.

表3. 我们提出的OA-Mix在Cityscapes-C数据集上的消融分析。

<table><tr><td rowspan="2">Consistency</td><td colspan="2">Contrastive</td><td rowspan="2">mAP</td><td rowspan="2">mPC</td></tr><tr><td>Target</td><td>Rule</td></tr><tr><td>✘</td><td>✘</td><td>✘</td><td>42.7</td><td>20.8</td></tr><tr><td>✓</td><td>✘</td><td>✘</td><td>43.1</td><td>21.2</td></tr><tr><td>✓</td><td>fg</td><td>class-aware</td><td>43.4</td><td>21.3</td></tr><tr><td>✓</td><td>$\mathrm{{fg}} + \mathrm{{bg}}$</td><td>class-aware</td><td>43.3</td><td>21.1</td></tr><tr><td>✓</td><td>$\mathrm{{fg}} + \mathrm{{bg}}$</td><td>object-aware</td><td>43.4</td><td>21.8</td></tr></table>

<table><tbody><tr><td rowspan="2">一致性</td><td colspan="2">对比学习的</td><td rowspan="2">平均精度均值(mAP)</td><td rowspan="2">平均精确度均值(mPC)</td></tr><tr><td>目标</td><td>规则</td></tr><tr><td>✘</td><td>✘</td><td>✘</td><td>42.7</td><td>20.8</td></tr><tr><td>✓</td><td>✘</td><td>✘</td><td>43.1</td><td>21.2</td></tr><tr><td>✓</td><td>前景</td><td>类别感知的</td><td>43.4</td><td>21.3</td></tr><tr><td>✓</td><td>$\mathrm{{fg}} + \mathrm{{bg}}$</td><td>类别感知的</td><td>43.3</td><td>21.1</td></tr><tr><td>✓</td><td>$\mathrm{{fg}} + \mathrm{{bg}}$</td><td>对象感知的</td><td>43.4</td><td>21.8</td></tr></tbody></table>

Table 4. Ablation analysis of our proposed contrastive method on Cityscapes-C. Our method considers all the semantic relations of the same instance, foreground class, background class, and background instances. fg and bg denote foreground and background instances, respectively.

表4. 我们提出的对比方法在Cityscapes-C上的消融分析。我们的方法考虑了同一实例、前景类别、背景类别和背景实例的所有语义关系。fg和bg分别表示前景和背景实例。

SHADE (Zhao et al. 2022) are feature normalization methods to improve DG. Compared with the baseline without any S-DGOD approaches, the feature normalization methods improve performance in certain weather conditions, but do not consistently enhance the performance for OOD. CDSD (Wu and Deng 2022) and SRCD (Rao et al. 2023) improved the performances in all weather conditions with domain-invariant features. Our proposed OA-DG achieved the top performance with 31.8 mPC in OOD weather conditions. Compared with the baseline, our method improves domain generalization in all weather conditions, especially in corrupted environments such as dusk-rainy and daytime-foggy.

SHADE(Zhao等，2022)是用于提升域泛化(DG)的特征归一化方法。与未采用任何S-DGOD方法的基线相比，特征归一化方法在某些天气条件下提升了性能，但未能持续增强OOD(域外)性能。CDSD(Wu和Deng，2022)和SRCD(Rao等，2023)通过域不变特征提升了所有天气条件下的性能。我们提出的OA-DG在OOD天气条件下以31.8 mPC取得了最佳性能。与基线相比，我们的方法提升了所有天气条件下的域泛化能力，尤其是在黄昏雨天和白天雾天等受损环境中表现突出。

## Ablation Studies

## 消融研究

All ablation studies evaluate DG performance in Cityscapes- $\mathrm{C}$ with the same settings as Table 1. Details and more ablation studies can be found in the supplementary material.

所有消融研究均在Cityscapes-$\mathrm{C}$中以表1相同设置评估DG性能。详细内容及更多消融研究见补充材料。

OA-Mix This experiment validates the impact of individual components within OA-Mix. Table 3 shows the clean performance and robustness according to multi-level transformations and object-aware mixing strategy. The single-level transformation improved performance on corrupted domains compared with the baseline. The multi-level transformation transforms the image at the local level and improved mPC compared with the single-level transformation. However, both transformations showed lower clean performance than the baseline due to the damage to the semantic features of objects. Standard mixing mitigates the negative effects of transformations. However, it does not utilize object information, which leads to lower clean performance than the baseline. Only the object-aware mixing strategy showed a clean performance above the baseline and achieved the best mPC performance as well.

OA-Mix 本实验验证了OA-Mix中各组成部分的影响。表3展示了基于多层次变换和面向对象混合策略的清洁性能和鲁棒性。单层次变换相比基线提升了受损域的性能。多层次变换在局部层面对图像进行变换，较单层次变换提升了mPC。然而，由于对物体语义特征的破坏，两种变换的清洁性能均低于基线。标准混合缓解了变换的负面影响，但未利用对象信息，导致清洁性能低于基线。仅面向对象的混合策略实现了高于基线的清洁性能，并取得了最佳的mPC表现。

![bo_d282q677aajc738orm7g_6_152_147_1451_368_0.jpg](images/bo_d282q677aajc738orm7g_6_152_147_1451_368_0.jpg)

Figure 4. From the left to the right, the detection results of the clean, shot noise, defocus blur, and frost domains are visualized. Compared with the baseline, OA-DG detects the object more accurately in diverse corrupted domains.

图4. 从左至右依次展示了清洁、脉冲噪声、散焦模糊和霜冻域的检测结果。与基线相比，OA-DG在多种受损域中对物体的检测更为准确。

<table><tr><td rowspan="2"/><td colspan="2">Faster R-CNN</td><td colspan="2">YOLOv3</td></tr><tr><td>Baseline</td><td>OA-DG</td><td>Baseline</td><td>OA-DG</td></tr><tr><td>mAP</td><td>42.2</td><td>43.4 (+1.2)</td><td>34.6</td><td>37.2 (+2.6)</td></tr><tr><td>mPC</td><td>15.4</td><td>21.8 (+6.4)</td><td>12.4</td><td>15.6 (+3.2)</td></tr><tr><td>FLOPs (G)</td><td>408.7</td><td>409.0</td><td>194.0</td><td>199.5</td></tr></table>

<table><tbody><tr><td rowspan="2"></td><td colspan="2">Faster R-CNN(快速区域卷积神经网络)</td><td colspan="2">YOLOv3(你只看一次v3)</td></tr><tr><td>基线</td><td>OA-DG</td><td>基线</td><td>OA-DG</td></tr><tr><td>平均精度均值(mAP)</td><td>42.2</td><td>43.4 (+1.2)</td><td>34.6</td><td>37.2 (+2.6)</td></tr><tr><td>平均类别准确率(mPC)</td><td>15.4</td><td>21.8 (+6.4)</td><td>12.4</td><td>15.6 (+3.2)</td></tr><tr><td>浮点运算次数(十亿次，FLOPs)</td><td>408.7</td><td>409.0</td><td>194.0</td><td>199.5</td></tr></tbody></table>

Table 5. Performance and computational complexity of Faster R-CNN and YOLOv3 on Cityscapes.

表5. Faster R-CNN和YOLOv3在Cityscapes上的性能与计算复杂度。

Contrastive Methods In Table 4, we verify the effectiveness of OA-Loss on Cityscapes-C. The consistency loss improved mPC by reducing the domain gap between the original and augmented instances. Then, we conducted an ablation study of contrastive learning according to the target and rule. The class-aware methods simply pull intra-class and push inter-class away. Both class-aware methods improved clean performance, but did not improve performance on the corrupted domains. In contrast, OA-Loss allows the model to train multi-domain gaps in an object-aware manner for all the instances. Our OA-Loss was improved by ${0.7}\mathrm{{mAP}}$ and ${1.0}\mathrm{{mPC}}$ in both clean and corrupted domains, respectively, validating the superiority of the object-aware approach.

对比方法 在表4中，我们验证了OA-Loss在Cityscapes-C上的有效性。通过减少原始实例与增强实例之间的域差异，一致性损失提升了mPC。随后，我们根据目标和规则对对比学习进行了消融研究。类别感知方法简单地拉近类内距离并推远类间距离。两种类别感知方法均提升了干净域的性能，但未能提升损坏域的表现。相比之下，OA-Loss使模型能够以对象感知的方式训练所有实例的多域差异。我们的OA-Loss在干净域和损坏域分别由${0.7}\mathrm{{mAP}}$和${1.0}\mathrm{{mPC}}$提升，验证了对象感知方法的优越性。

Object Detector Architectures Table 5 shows the generalization capability of OA-DG to object detection framework. We conducted additional experiments with YOLOv3, a popular one-stage object detector. Although YOLOv3 used various bag of tricks such as photometric distortion to improve its generalization capability, OA-DG improved its performance in both clean and corrupted domains. This implies that our method is not limited to a specific detector architecture and can be applied to general object detectors.

目标检测器架构 表5展示了OA-DG对目标检测框架的泛化能力。我们使用流行的一阶段目标检测器YOLOv3进行了额外实验。尽管YOLOv3采用了诸如光度失真等多种技巧以提升泛化能力，OA-DG仍在干净域和损坏域均提升了其性能。这表明我们的方法不限于特定检测器架构，可应用于通用目标检测器。

## Qualitative Analysis

## 定性分析

Visual Analysis Figure 4 shows the results for the baseline and our model at clean and corrupted domains on Cityscapes. In the clean domain, both the baseline and our model accurately detect objects, but the baseline fails to detect most objects in the corrupted domain. Compared with the baseline, our model accurately detects small objects and improves object localization in OOD.

视觉分析 图4展示了基线模型和我们模型在Cityscapes干净域与损坏域的结果。在干净域，基线和我们模型均能准确检测对象，但基线在损坏域中大多数对象检测失败。与基线相比，我们的模型能准确检测小目标并提升OOD中的目标定位。

![bo_d282q677aajc738orm7g_6_952_649_679_335_0.jpg](images/bo_d282q677aajc738orm7g_6_952_649_679_335_0.jpg)

Figure 5. Feature correlations of the baseline and OA-DG between the clean and corrupted domains. Zero to seven on each axis denote the object classes and eight denotes the background class. Compared with the baseline, our method has higher correlations between the same class in OOD.

图5. 基线和OA-DG在干净域与损坏域之间的特征相关性。坐标轴上的0至7表示对象类别，8表示背景类别。与基线相比，我们的方法在OOD中同类之间的相关性更高。

Feature Analysis Figure 5 shows the feature correlations between the clean and shot noise domains on Cityscapes. The feature correlations are measured as the average of cosine similarity for each class and normalized in the $x$ -axis. Following (Ranasinghe et al. 2021), we use the features of the penultimate layer in the classification head. In Figure 5, the $x$ -axis and $y$ -axis represent the clean and corrupted domains, respectively. The comparison between the corrupted and clean domains shows that the baseline has little correlation between the same classes. This hinders the baseline from detecting objects in the corrupted domain, as shown in Figure 4. Compared with the baseline, the OA-DG method has higher correlations between the same class, but lower correlations with other classes.

特征分析 图5展示了Cityscapes中干净域与脉冲噪声域之间的特征相关性。特征相关性通过各类别余弦相似度平均值测量，并在$x$轴上归一化。参照(Ranasinghe et al. 2021)，我们使用分类头倒数第二层的特征。图5中，$x$轴和$y$轴分别代表干净域和损坏域。损坏域与干净域的对比显示基线在同类之间相关性较低，阻碍了其在损坏域的目标检测，如图4所示。相比基线，OA-DG方法在同类之间相关性更高，而与其他类别相关性更低。

## Conclusion

## 结论

In this study, we propose object-aware domain generalization (OA-DG) method for single-domain generalization in object detection. OA-Mix generates multi-domain with mixing strategies and preserved semantics. OA-Loss trains the domain-invariant representations for foreground and background instances from multi-domain. Our experimental results demonstrate that the proposed method can improve the robustness of object detectors to unseen domains.

本研究提出了用于单域泛化的对象感知域泛化(OA-DG)方法，应用于目标检测。OA-Mix通过混合策略生成多域且保持语义一致。OA-Loss训练多域中前景和背景实例的域不变表示。实验结果表明，该方法能提升目标检测器对未知域的鲁棒性。

## Acknowledgements

## 致谢

This work was supported in part by Institute of Information & communications Technology Planning & Evaluation (IITP) grant funded by Korea government (MSIT) (No.2020-0-00440, Development of Artificial Intelligence Technology that Continuously Improves Itself as the Situation Changes in the Real World). This work was supported in part by Korea Evaluation Institute Of Industrial Technology (KEIT) grant funded by the Korea government (MOTIE) (No.20023455, Development of Cooperate Mapping, Environment Recognition and Autonomous Driving Technology for Multi Mobile Robots Operating in Large-scale Indoor Workspace). The students are supported by the BK21 FOUR from the Ministry of Education (Republic of Korea). References

本工作部分由韩国政府(MSIT)资助的信息通信技术规划评价院(IITP)项目支持(编号2020-0-00440，开发能够随着现实世界变化持续自我改进的人工智能技术)。本工作部分由韩国政府(MOTIE)资助的韩国工业技术评价院(KEIT)项目支持(编号20023455，开发适用于大规模室内工作空间多移动机器人协作映射、环境识别与自动驾驶技术)。学生由韩国教育部BK21 FOUR项目支持。参考文献

Carion, N.; Massa, F.; Synnaeve, G.; Usunier, N.; Kirillov, A.; and Zagoruyko, S. 2020. End-to-end object detection with transformers. In Proceedings of the European Conference on Computer Vision, 213-229. Springer.

Carion, N.; Massa, F.; Synnaeve, G.; Usunier, N.; Kirillov, A.; and Zagoruyko, S. 2020. 端到端目标检测与transformers。在欧洲计算机视觉会议论文集，213-229。Springer。

Choi, S.; Jung, S.; Yun, H.; Kim, J. T.; Kim, S.; and Choo, J. 2021. RobustNet: Improving domain generalization in urban-scene segmentation via instance selective whitening. In Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition, 11580-11590.

Choi, S.; Jung, S.; Yun, H.; Kim, J. T.; Kim, S.; and Choo, J. 2021. RobustNet:通过实例选择性白化提升城市场景分割的域泛化能力。在IEEE/CVF计算机视觉与模式识别会议论文集，11580-11590。

Dan, H.; and Thomas, D. 2019. Benchmarking neural network robustness to common corruptions and perturbations. In International Conference on Learning Representations.

Dan, H.; and Thomas, D. 2019. 神经网络对常见损坏和扰动的鲁棒性基准测试。在国际学习表征会议。

Dosovitskiy, A.; Beyer, L.; Kolesnikov, A.; Weissenborn, D.; Zhai, X.; Unterthiner, T.; Dehghani, M.; Minderer, M.; Heigold, G.; Gelly, S.; Uszkoreit, J.; and Houlsby, N. 2021. An image is worth ${16} \times  {16}$ words: Transformers for image recognition at scale. In International Conference on Learning Representations.

Dosovitskiy, A.; Beyer, L.; Kolesnikov, A.; Weissenborn, D.; Zhai, X.; Unterthiner, T.; Dehghani, M.; Minderer, M.; Heigold, G.; Gelly, S.; Uszkoreit, J.; and Houlsby, N. 2021. 一张图胜过${16} \times  {16}$字:大规模图像识别的Transformer(变换器)方法。发表于国际学习表征会议。

Gatys, L. A.; Ecker, A. S.; and Bethge, M. 2016. Image style transfer using convolutional neural networks. In Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition, 2414-2423.

Gatys, L. A.; Ecker, A. S.; and Bethge, M. 2016. 使用卷积神经网络进行图像风格迁移。发表于IEEE/CVF计算机视觉与模式识别会议论文集，2414-2423页。

Geirhos, R.; Rubisch, P.; Michaelis, C.; Bethge, M.; Wich-mann, F. A.; and Brendel, W. 2018. ImageNet-trained CNNs are biased towards texture; increasing shape bias improves accuracy and robustness. In International Conference on Learning Representations.

Geirhos, R.; Rubisch, P.; Michaelis, C.; Bethge, M.; Wich-mann, F. A.; and Brendel, W. 2018. 训练于ImageNet的卷积神经网络(CNN)偏向纹理；增加形状偏向可提升准确性和鲁棒性。发表于国际学习表征会议。

Hassaballah, M.; Kenk, M. A.; Muhammad, K.; and Minaee, S. 2020. Vehicle detection and tracking in adverse weather using a deep learning framework. IEEE Transactions on Intelligent Transportation Systems, 22(7): 4230-4242.

Hassaballah, M.; Kenk, M. A.; Muhammad, K.; and Minaee, S. 2020. 利用深度学习框架进行恶劣天气下的车辆检测与跟踪。IEEE智能交通系统汇刊，22(7): 4230-4242。

He, K.; Zhang, X.; Ren, S.; and Sun, J. 2016. Deep residual learning for image recognition. In Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition, 770-778.

He, K.; Zhang, X.; Ren, S.; and Sun, J. 2016. 用于图像识别的深度残差学习。发表于IEEE/CVF计算机视觉与模式识别会议论文集，770-778页。

Hendrycks, D.; Mu, N.; Cubuk, E. D.; Zoph, B.; Gilmer, J.; and Lakshminarayanan, B. 2019. AugMix: A simple data processing method to improve robustness and uncertainty. In International Conference on Learning Representations.

Hendrycks, D.; Mu, N.; Cubuk, E. D.; Zoph, B.; Gilmer, J.; and Lakshminarayanan, B. 2019. AugMix:一种简单的数据处理方法以提升鲁棒性和不确定性。发表于国际学习表征会议。

Huang, L.; Zhou, Y.; Zhu, F.; Liu, L.; and Shao, L. 2019. Iterative normalization: Beyond standardization towards efficient whitening. In Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition, 4874- 4883.

Huang, L.; Zhou, Y.; Zhu, F.; Liu, L.; and Shao, L. 2019. 迭代归一化:超越标准化实现高效白化。发表于IEEE/CVF计算机视觉与模式识别会议论文集，4874-4883页。

Kang, B.; Li, Y.; Xie, S.; Yuan, Z.; and Feng, J. 2021. Exploring balanced feature spaces for representation learning. In International Conference on Learning Representations.

Kang, B.; Li, Y.; Xie, S.; Yuan, Z.; and Feng, J. 2021. 探索平衡的特征空间以进行表征学习。发表于国际学习表征会议。

Khosla, P.; Teterwak, P.; Wang, C.; Sarna, A.; Tian, Y.; Isola, P.; Maschinot, A.; Liu, C.; and Krishnan, D. 2020. Supervised contrastive learning. Advances in Neural Information Processing Systems, 33: 18661-18673.

Khosla, P.; Teterwak, P.; Wang, C.; Sarna, A.; Tian, Y.; Isola, P.; Maschinot, A.; Liu, C.; and Krishnan, D. 2020. 监督对比学习。神经信息处理系统进展，33: 18661-18673。

Kim, D.; Yoo, Y.; Park, S.; Kim, J.; and Lee, J. 2021. Sel-fReg: Self-supervised contrastive regularization for domain generalization. In Proceedings of the IEEE/CVF International Conference on Computer Vision, 9619-9628.

Kim, D.; Yoo, Y.; Park, S.; Kim, J.; and Lee, J. 2021. Sel-fReg:用于领域泛化的自监督对比正则化。发表于IEEE/CVF国际计算机视觉会议论文集，9619-9628页。

Lee, W.; and Myung, H. 2022. Adversarial attack for asynchronous event-based data. In Proceedings of the AAAI Conference on Artificial Intelligence, volume 36, 1237-1244.

Lee, W.; and Myung, H. 2022. 针对异步事件数据的对抗攻击。发表于AAAI人工智能会议论文集，第36卷，1237-1244页。

Li, L.; Gao, K.; Cao, J.; Huang, Z.; Weng, Y.; Mi, X.; Yu, Z.; Li, X.; and Xia, B. 2021. Progressive domain expansion network for single domain generalization. In Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition, 224-233.

Li, L.; Gao, K.; Cao, J.; Huang, Z.; Weng, Y.; Mi, X.; Yu, Z.; Li, X.; and Xia, B. 2021. 用于单领域泛化的渐进式领域扩展网络。发表于IEEE/CVF计算机视觉与模式识别会议论文集，224-233页。

Li, T.; Cao, P.; Yuan, Y.; Fan, L.; Yang, Y.; Feris, R. S.; Indyk, P.; and Katabi, D. 2022. Targeted supervised contrastive learning for long-tailed recognition. In Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition, 6918-6928.

Li, T.; Cao, P.; Yuan, Y.; Fan, L.; Yang, Y.; Feris, R. S.; Indyk, P.; and Katabi, D. 2022. 针对长尾识别的目标监督对比学习。发表于IEEE/CVF计算机视觉与模式识别会议论文集，6918-6928页。

Lin, C.; Yuan, Z.; Zhao, S.; Sun, P.; Wang, C.; and Cai, J. 2021. Domain-invariant disentangled network for generalizable object detection. In Proceedings of the IEEE/CVF International Conference on Computer Vision, 8771-8780.

Lin, C.; Yuan, Z.; Zhao, S.; Sun, P.; Wang, C.; and Cai, J. 2021. 用于泛化目标检测的领域不变解耦网络。发表于IEEE/CVF国际计算机视觉会议论文集，8771-8780页。

Michaelis, C.; Mitzkus, B.; Geirhos, R.; Rusak, E.; Bring-mann, O.; Ecker, A. S.; Bethge, M.; and Brendel, W. 2019. Benchmarking robustness in object detection: Autonomous driving when winter is coming. arXiv preprint arXiv:1907.07484.

Michaelis, C.; Mitzkus, B.; Geirhos, R.; Rusak, E.; Bring-mann, O.; Ecker, A. S.; Bethge, M.; and Brendel, W. 2019. 目标检测鲁棒性基准测试:冬季来临时的自动驾驶。arXiv预印本 arXiv:1907.07484。

Modas, A.; Rade, R.; Ortiz-Jiménez, G.; Moosavi-Dezfooli, S.-M.; and Frossard, P. 2022. PRIME: A few primitives can boost robustness to common corruptions. In Proceedings of the European Conference on Computer Vision, 623-640. Springer.

Modas, A.; Rade, R.; Ortiz-Jiménez, G.; Moosavi-Dezfooli, S.-M.; 和 Frossard, P. 2022. PRIME:少量原语即可提升对常见扰动的鲁棒性。载于欧洲计算机视觉会议论文集，623-640。Springer。

Pan, X.; Luo, P.; Shi, J.; and Tang, X. 2018. Two at once: Enhancing learning and generalization capacities via IBN-net. In Proceedings of the European Conference on Computer Vision, 464-479.

Pan, X.; Luo, P.; Shi, J.; 和 Tang, X. 2018. 一举两得:通过IBN-net提升学习和泛化能力。载于欧洲计算机视觉会议论文集，464-479。

Pan, X.; Zhan, X.; Shi, J.; Tang, X.; and Luo, P. 2019. Switchable whitening for deep representation learning. In Proceedings of the IEEE/CVF International Conference on Computer Vision, 1863-1871.

Pan, X.; Zhan, X.; Shi, J.; Tang, X.; 和 Luo, P. 2019. 可切换白化用于深度表示学习。载于IEEE/CVF国际计算机视觉会议论文集，1863-1871。

Ranasinghe, K.; Naseer, M.; Hayat, M.; Khan, S.; and Khan, F. S. 2021. Orthogonal projection loss. In Proceedings of the IEEE/CVF International Conference on Computer Vision, 12333-12343.

Ranasinghe, K.; Naseer, M.; Hayat, M.; Khan, S.; 和 Khan, F. S. 2021. 正交投影损失。载于IEEE/CVF国际计算机视觉会议论文集，12333-12343。

Rao, Z.; Guo, J.; Tang, L.; Huang, Y.; Ding, X.; and Guo, S. 2023. SRCD: Semantic reasoning with compound domains for single-domain generalized object detection. arXiv preprint arXiv:2307.01750.

Rao, Z.; Guo, J.; Tang, L.; Huang, Y.; Ding, X.; 和 Guo, S. 2023. SRCD:用于单域泛化目标检测的复合域语义推理。arXiv预印本 arXiv:2307.01750。

Redmon, J.; and Farhadi, A. 2018. YOLOv3: An Incremental Improvement. arXiv:1804.02767.

Redmon, J.; 和 Farhadi, A. 2018. YOLOv3:渐进式改进。arXiv:1804.02767。

Ren, S.; He, K.; Girshick, R.; and Sun, J. 2015. Faster R-CNN: Towards real-time object detection with region proposal networks. Advances in Neural Information Processing Systems, 28.

Ren, S.; He, K.; Girshick, R.; 和 Sun, J. 2015. Faster R-CNN:基于区域提议网络的实时目标检测。神经信息处理系统进展，28卷。

Sakaridis, C.; Dai, D.; and Van Gool, L. 2018. Semantic foggy scene understanding with synthetic data. International Journal of Computer Vision, 126: 973-992.

Sakaridis, C.; Dai, D.; 和 Van Gool, L. 2018. 利用合成数据进行语义雾天场景理解。国际计算机视觉杂志，126卷:973-992。

Sun, B.; Li, B.; Cai, S.; Yuan, Y.; and Zhang, C. 2021. FSCE: Few-shot object detection via contrastive proposal encoding. In Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition, 7352-7362.

Sun, B.; Li, B.; Cai, S.; Yuan, Y.; 和 Zhang, C. 2021. FSCE:通过对比提议编码实现少样本目标检测。载于IEEE/CVF计算机视觉与模式识别会议论文集，7352-7362。

Vidit, V.; Engilberge, M.; and Salzmann, M. 2023. CLIP the gap: A single domain generalization approach for object detection. arXiv preprint arXiv:2301.05499.

Vidit, V.; Engilberge, M.; 和 Salzmann, M. 2023. CLIP the gap:一种用于目标检测的单域泛化方法。arXiv预印本 arXiv:2301.05499。

Wan, C.; Shen, X.; Zhang, Y.; Yin, Z.; Tian, X.; Gao, F.; Huang, J.; and Hua, X.-S. 2022. Meta convolutional neural networks for single domain generalization. In Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition, 4682-4691.

Wan, C.; Shen, X.; Zhang, Y.; Yin, Z.; Tian, X.; Gao, F.; Huang, J.; 和 Hua, X.-S. 2022. 用于单域泛化的元卷积神经网络。载于IEEE/CVF计算机视觉与模式识别会议论文集，4682-4691。

Wang, X.; Huang, T. E.; Liu, B.; Yu, F.; Wang, X.; Gonzalez, J. E.; and Darrell, T. 2021a. Robust object detection via instance-level temporal cycle confusion. In Proceedings of the IEEE/CVF International Conference on Computer Vision, 9143-9152.

Wang, X.; Huang, T. E.; Liu, B.; Yu, F.; Wang, X.; Gonzalez, J. E.; 和 Darrell, T. 2021a. 通过实例级时间循环混淆实现鲁棒目标检测。载于IEEE/CVF国际计算机视觉会议论文集，9143-9152。

Wang, Z.; Luo, Y.; Qiu, R.; Huang, Z.; and Baktashmotlagh, M. 2021b. Learning to diversify for single domain generalization. In Proceedings of the IEEE/CVF International Conference on Computer Vision, 834-843.

Wang, Z.; Luo, Y.; Qiu, R.; Huang, Z.; 和 Baktashmotlagh, M. 2021b. 学习多样化以实现单域泛化。载于IEEE/CVF国际计算机视觉会议论文集，834-843。

Wu, A.; and Deng, C. 2022. Single-domain generalized object detection in urban scene via cyclic-disentangled self-distillation. In Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition, 847-856.

Wu, A.; 和 Deng, C. 2022. 通过循环解缠自蒸馏实现城市场景中的单域泛化目标检测。载于IEEE/CVF计算机视觉与模式识别会议论文集，847-856。

Yao, X.; Bai, Y.; Zhang, X.; Zhang, Y.; Sun, Q.; Chen, R.; Li, R.; and Yu, B. 2022. PCL: Proxy-based contrastive learning for domain generalization. In Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition, 7097-7107.

Yao, X.; Bai, Y.; Zhang, X.; Zhang, Y.; Sun, Q.; Chen, R.; Li, R.; 和 Yu, B. 2022. PCL:基于代理的对比学习用于域泛化。载于IEEE/CVF计算机视觉与模式识别会议论文集，7097-7107。

Yu, F.; Chen, H.; Wang, X.; Xian, W.; Chen, Y.; Liu, F.; Mad-havan, V.; and Darrell, T. 2020. BDD100k: A diverse driving dataset for heterogeneous multitask learning. In Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition, 2636-2645.

Yu, F.; Chen, H.; Wang, X.; Xian, W.; Chen, Y.; Liu, F.; Madhavan, V.; 和 Darrell, T. 2020. BDD100k:用于异构多任务学习的多样化驾驶数据集。载于IEEE/CVF计算机视觉与模式识别会议论文集，2636-2645。

Zhao, Y.; Zhong, Z.; Zhao, N.; Sebe, N.; and Lee, G. H. 2022. Style-hallucinated dual consistency learning for domain generalized semantic segmentation. In Proceedings of the European Conference on Computer Vision, 535-552. Springer.

赵勇；钟志；赵宁；Sebe，N.；李光辉。2022。基于风格幻觉的双重一致性学习用于领域泛化语义分割。载于欧洲计算机视觉会议论文集，535-552。施普林格出版社。

Zhong, Z.; Zheng, L.; Kang, G.; Li, S.; and Yang, Y. 2020. Random erasing data augmentation. In Proceedings of the AAAI Conference on Artificial Intelligence, volume 34, 13001-13008.

钟志；郑磊；康刚；李松；杨洋。2020。随机擦除数据增强。载于美国人工智能协会(AAAI)会议论文集，第34卷，13001-13008。

Zhou, K.; Liu, Z.; Qiao, Y.; Xiang, T.; and Loy, C. C. 2022. Domain generalization: A survey. IEEE Transactions on Pattern Analysis and Machine Intelligence.

周康；刘志；乔阳；向涛；Loy，C. C.。2022。领域泛化综述。IEEE模式分析与机器智能汇刊。

Zoph, B.; Cubuk, E. D.; Ghiasi, G.; Lin, T.-Y.; Shlens, J.; and Le, Q. V. 2020. Learning data augmentation strategies for object detection. In Proceedings of the European Conference on Computer Vision, 566-583. Springer.

Zoph，B.；Cubuk，E. D.；Ghiasi，G.；Lin，T.-Y.；Shlens，J.；Le，Q. V.。2020。面向目标检测的数据增强策略学习。载于欧洲计算机视觉会议论文集，566-583。施普林格出版社。