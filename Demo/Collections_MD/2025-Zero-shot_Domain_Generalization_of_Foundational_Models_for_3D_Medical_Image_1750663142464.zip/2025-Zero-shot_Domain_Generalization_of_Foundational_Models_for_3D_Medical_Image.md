# Zero-shot Domain Generalization of Foundational Models for 3D Medical Image Segmentation: An Experimental Study

# 基础模型在3D医学图像分割中的零样本领域泛化:一项实验研究

Soumitri Chattopadhyay ${}^{1}$ , Başar Demir ${}^{1}$ , and Marc Niethammer ${}^{2}$

Soumitri Chattopadhyay ${}^{1}$ , Başar Demir ${}^{1}$ , 和 Marc Niethammer ${}^{2}$

${}^{1}$ University of North Carolina at Chapel Hill

${}^{1}$ 北卡罗来纳大学教堂山分校

${}^{2}$ University of California, San Diego

${}^{2}$ 加州大学圣地亚哥分校

\{soumitri, bdemir\}@cs.unc.edu

\{soumitri, bdemir\}@cs.unc.edu

mniethammer@ucsd.edu

Abstract. Domain shift, caused by variations in imaging modalities and acquisition protocols, limits model generalization in medical image segmentation. While foundation models (FMs) trained on diverse large-scale data hold promise for zero-shot generalization, their application to volumetric medical data remains underexplored. In this study, we examine their ability towards domain generalization (DG), by conducting a comprehensive experimental study encompassing 6 medical segmentation FMs and 12 public datasets spanning multiple modalities and anatomies. Our findings reveal the potential of promptable FMs in bridging the domain gap via smart prompting techniques. Additionally, by probing into multiple facets of zero-shot DG, we offer valuable insights into the viability of FMs for DG and identify promising avenues for future research.

摘要。由于成像模态和采集协议的差异导致的领域偏移限制了医学图像分割模型的泛化能力。尽管在多样化大规模数据上训练的基础模型(FMs)在零样本泛化方面展现出潜力，但其在体积医学数据上的应用尚未充分探索。本研究通过涵盖6个医学分割基础模型和12个跨多模态及多解剖结构的公开数据集的综合实验，考察了其领域泛化(DG)能力。我们的结果揭示了可提示基础模型通过智能提示技术弥合领域差距的潜力。此外，通过探讨零样本领域泛化的多个方面，我们为基础模型在领域泛化中的可行性提供了宝贵见解，并指出了未来研究的有希望方向。

Keywords: Domain generalization - Foundational models - 3D medical image segmentation

关键词:领域泛化 - 基础模型 - 3D医学图像分割

## 1 Introduction

## 1 引言

Medical imaging involves a broad variety of scanners, acquisition protocols, imaging modalities (e.g., CT, MR, PET, ultrasound), sequences (T1w, T2w, ADC MRIs), and varying demographics. As a result, there are large variations in the distributions of the visual data. This issue is commonly referred to as ${do}$ - main shift [26], and poses a significant challenge for classical data-driven models, where the test distribution is assumed to match the training distribution. To overcome this, prior works have focused on domain adaptation [28,45], test-time adaptation [41,23] and domain generalization (DG) [43]. However, using these approaches requires individual models to be trained for a given pair of modalities and hence, cannot be adopted for generalized applications.

医学成像涉及多种扫描仪、采集协议、成像模态(如CT、MR、PET、超声)、序列(T1加权、T2加权、ADC MRI)及不同的人口统计学特征。因此，视觉数据的分布存在较大差异。该问题通常被称为领域偏移(domain shift)[26]，对传统的数据驱动模型构成重大挑战，因为这些模型假设测试分布与训练分布一致。为克服这一问题，先前工作主要集中于领域适应[28,45]、测试时适应[41,23]和领域泛化(DG)[43]。然而，这些方法需要针对特定模态对训练单独模型，因而难以应用于通用场景。

Originally rooted in the NLP community [4,37,5], foundational models (FMs) have recently been developed in the visual domain [2], for vision-language modeling [36], visual generation [38], registration [40,9] and segmentation [25,32]. A key characteristic of these models is that they are trained on large-scale cu-rated data, which suggests the potential to generalize to new distributions in a zero-shot manner. In particular, CLIP [36] and SAM [25] have shown impressive zero-shot capabilities for coarse-level classification and sparse-promptable segmentation tasks [44]. Recently, the SAM paradigm has been extended to medical volumes, leading to large-scale volumetric segmentation models $\left\lbrack  {{42},{13}}\right\rbrack$ , going beyond 2D slice-level approaches [32] to full-volume inference. However, to our best knowledge, no studies yet have investigated these foundational 3D segmenters for zero-shot domain generalization.

基础模型(FMs)最初源自自然语言处理领域[4,37,5]，近年来已在视觉领域得到发展[2]，应用于视觉-语言建模[36]、视觉生成[38]、配准[40,9]和分割[25,32]。这些模型的一个关键特征是基于大规模精心策划的数据训练，显示出零样本泛化到新分布的潜力。特别是CLIP[36]和SAM[25]在粗粒度分类和稀疏提示分割任务中展现了令人印象深刻的零样本能力[44]。最近，SAM范式已扩展至医学体积数据，催生了大规模体积分割模型$\left\lbrack  {{42},{13}}\right\rbrack$，超越了二维切片级方法[32]，实现了全体积推断。然而，据我们所知，尚无研究探讨这些基础的3D分割器在零样本领域泛化中的表现。

In this work, we probe the feasibility of zero-shot domain generalization for 3D medical image segmentation with segmentation FMs. To this end, we first describe a taxonomy that categorizes existing off-the-shelf FMs, based on their training knowledge (specific modalities/general), inputs (promptable/automatic) and targets (finite set of classes, or prompt-specific). Our study encompasses 6 medical FMs and 12 volumetric segmentation datasets (described in Sec. 3) comprising various anatomies and modalities. To assess zero-shot DG holistically, we examine dataset distribution shifts, cross-modal transferability (Sec. 4.1), and generalization to unseen anatomies (Sec. 4.2). Our empirical findings reveal that most existing FMs exhibit a significant domain gap compared to in-domain-trained specialist models [19]. However, recent text-promptable models show stronger DG, narrowing this gap (Sec. 4.3), potentially making them a promising direction for domain-generalizable models in medical image computing.

本工作探讨了基于分割基础模型的3D医学图像分割零样本领域泛化的可行性。为此，我们首先提出了一个分类法，根据训练知识(特定模态/通用)、输入类型(可提示/自动)和目标(有限类别集或提示特定)对现有现成基础模型进行分类。我们的研究涵盖6个医学基础模型和12个体积分割数据集(详见第3节)，涉及多种解剖结构和模态。为全面评估零样本领域泛化，我们考察了数据集分布偏移、跨模态迁移能力(第4.1节)及对未见解剖结构的泛化(第4.2节)。实证结果显示，大多数现有基础模型与领域内训练的专用模型[19]相比存在显著领域差距。然而，近期的文本提示模型表现出更强的领域泛化能力，缩小了该差距(第4.3节)，有望成为医学图像计算中领域泛化模型的有前景方向。

Our study is driven by two key factors: (i) Zero-shot generalizability is a desirable trait of FMs [2], and given their success in natural vision tasks [36,25,44], it is crucial to investigate whether similar performance extends to medical image segmentation across datasets, anatomies, and modalities. (ii) DG in medical image segmentation remains a long-standing challenge with significant relevance to federated learning [31,34], automating the manual clinical segmentation process, and adoption to newer modalities with limited annotations. Our work is both timely and essential for advancing research on zero-shot FM generalization.

本研究由两个关键因素驱动:(i)零样本泛化是基础模型的理想特性[2]，鉴于其在自然视觉任务中的成功[36,25,44]，有必要探讨其性能是否能扩展至跨数据集、解剖结构和模态的医学图像分割；(ii)医学图像分割中的领域泛化是一个长期存在的挑战，与联邦学习[31,34]、临床手动分割自动化及有限标注的新模态适应密切相关。我们的工作及时且必要，有助于推动零样本基础模型泛化的研究进展。

## In summary, the contributions of our work are as follows:

## 总结而言，我们工作的贡献如下:

1. We define a taxonomy for existing 3D medical segmentation FMs structured around domain generalization.

1. 我们围绕领域泛化定义了现有3D医学分割基础模型的分类法。

2. We assess their zero-shot performance across datasets encompassing diverse anatomies and multiple modalities/sequences.

2. 我们评估了它们在涵盖多种解剖结构和多种模态/序列的数据集上的零样本性能。

3. Our analysis covers multiple facets of DG, including generalization to unseen modalities, the impact of different prompts, and adaptation to novel anatomical structures.

3. 我们的分析涵盖了域泛化(DG)的多个方面，包括对未见模态的泛化、不同提示词的影响以及对新颖解剖结构的适应。

4. Our findings provide key insights into the feasibility of FMs for domain generalization and highlight promising directions for future research.

4. 我们的研究结果为基础模型(FMs)在域泛化中的可行性提供了关键见解，并指出了未来研究的有前景方向。

## 2 Related Work

## 2 相关工作

Foundational models for segmentation: While prior approaches relied on training segmentation models based on a finite set of target classes $\left\lbrack  {{19},{39},{15}}\right\rbrack$ which limits their wider applicability, the advent of large-scale promptable models like SAM [25] imparted flexibility by enabling the model to generate outputs based on user-specified inputs. Recently, this paradigm has been adopted in medical imaging for $2\mathrm{D}\left\lbrack  {{32},8}\right\rbrack$ and $3\mathrm{D}\left\lbrack  {{42},{13}}\right\rbrack$ segmentations, being trained on assembled corpora of multi-sourced datasets. It is useful to probe how well, if at all, these models can generalize to varying data distributions and imaging modalities - which is what we explore in our current study.

分割的基础模型:以往的方法依赖于基于有限目标类别训练分割模型$\left\lbrack  {{19},{39},{15}}\right\rbrack$，这限制了其更广泛的适用性，而大型可提示模型(如SAM [25])的出现通过允许模型基于用户指定的输入生成输出，赋予了灵活性。近期，这一范式已被应用于医学影像中的$2\mathrm{D}\left\lbrack  {{32},8}\right\rbrack$和$3\mathrm{D}\left\lbrack  {{42},{13}}\right\rbrack$分割，训练数据集由多源数据集汇编而成。探究这些模型在多大程度上能够泛化到不同的数据分布和成像模态是有意义的——这正是我们当前研究所探讨的内容。

Domain generalization in medical imaging: The broad range of imaging modalities, scanners, protocols, and demographics make domain shift a prevalent issue for 3D medical image segmentation [7], with dataset-specific trained models struggling to generalize to different domains. Prior approaches have focused on unsupervised domain adaptation [45,28], test-time adaptation [41,23] and domain generalization $\left\lbrack  {{43},{12},{14}}\right\rbrack$ . The recent advent of FMs for medical imaging $\left\lbrack  {{39},{16},{42}}\right\rbrack$ makes them potential candidates to achieve domain generalization, owing to their large-scale training across diverse datasets. In this work, we investigate the generalizability of such models for 3D segmentation tasks across multiple domain shift scenarios.

医学影像中的域泛化:成像模态、扫描仪、协议和人口统计的多样性使得域偏移成为3D医学图像分割中的普遍问题[7]，针对特定数据集训练的模型难以泛化到不同域。以往方法主要关注无监督域适应[45,28]、测试时适应[41,23]和域泛化$\left\lbrack  {{43},{12},{14}}\right\rbrack$。基础模型(FMs)在医学影像领域的最新出现$\left\lbrack  {{39},{16},{42}}\right\rbrack$使其成为实现域泛化的潜在候选者，得益于其在多样化数据集上的大规模训练。本文研究了此类模型在多种域偏移场景下3D分割任务的泛化能力。

## 3 Materials and Methods

## 3 材料与方法

### 3.1 Datasets

### 3.1 数据集

We use several publicly available volumetric medical segmentation datasets spanning multiple anatomical regions and modalities, which facilitate (1) zero-shot domain transfer and (2) unseen organ segmentation experiments, both of which we feel are crucial to probe domain generalization.

我们使用了多个公开的体积医学分割数据集，涵盖多个解剖区域和模态，便于进行(1)零样本域迁移和(2)未见器官分割实验，这两者对于探究域泛化都至关重要。

- Abdominal organs: Datasets containing segmentations of various organs in the human abdominal region – BTCV [27], AMOS‘22 [21], FLARE‘22 [33], CHAOS [24], MSD-Spleen [1]. Notably, AMOS'22 provides both CT and MR datasets having the same target organs, and we use both in our study.

- 腹部器官:包含人体腹部多个器官分割的数据集——BTCV [27]、AMOS‘22 [21]、FLARE‘22 [33]、CHAOS [24]、MSD-Spleen [1]。值得注意的是，AMOS'22同时提供了CT和MR数据集，且目标器官相同，我们在研究中均使用了这两者。

- Pelvic anatomy: Focused on prostate segmentation from MR volumes - MSD-Prostate [1] (having T2w and ADC sequences) and PROMISE12 [29]. We merged the peripheral and transitional regions in MSD-Prostate into a single region for consistency with PROMISE12 and models trained on the full prostate.

- 骨盆解剖:聚焦于MR体积的前列腺分割——MSD-Prostate [1](包含T2加权和ADC序列)和PROMISE12 [29]。我们将MSD-Prostate中的外周区和过渡区合并为单一区域，以与PROMISE12及基于整个前列腺训练的模型保持一致。

- Cardiac substructures: Datasets with segmentations of the atria, ventricles, and myocardium - MSD-Heart [1] and MMWHS - CT & MR [47].

- 心脏亚结构:包含心房、心室和心肌分割的数据集——MSD-Heart [1]和MMWHS - CT & MR [47]。

Table 1 provides more details on the composition of the datasets.

表1提供了数据集组成的更多细节。

### 3.2 Model Taxonomy

### 3.2 模型分类

We describe a taxonomy for the 3D segmentation FMs used in this study and list them below. Additionally, Table 2 describes their training domains, target classes and preprocessing of inputs before passing them into their networks.

我们描述了本研究中使用的3D分割基础模型的分类法，并列举如下。此外，表2介绍了它们的训练域、目标类别及输入预处理方式。

Table 1: Datasets used in our domain generalization study. They encompass a diverse range of anatomies (abdomen, pelvic, cardiac and entire body) across multiple modalities (CT, MR) and sequences (e.g., T1w, T2w, T2-SPIR, and ADC MRIs).

表1:我们域泛化研究中使用的数据集。它们涵盖了多种解剖结构(腹部、骨盆、心脏及全身)以及多种模态(CT、MR)和序列(如T1加权、T2加权、T2-SPIR和ADC MRI)。

<table><tr><td>$\mathbf{{Dataset}}$</td><td>Anatomies</td><td>Modalities</td><td>#classes</td><td>#samples</td></tr><tr><td>BTCV [27]</td><td>abdominal organs</td><td>CT</td><td>13</td><td>30</td></tr><tr><td>AMOS’22 [21]</td><td>abdominal organs</td><td>CT, MR</td><td>15</td><td>CT: 120, MR: 60 (test set)</td></tr><tr><td>FLARE’22 [33]</td><td>abdominal organs</td><td>CT</td><td>13</td><td>train: 50; test: 22</td></tr><tr><td>CHAOS [24]</td><td>abdominal organs</td><td>MR: T2-SPIR</td><td>4</td><td>20</td></tr><tr><td>MSD-Spleen [1]</td><td>spleen (abdomen)</td><td>CT</td><td>1</td><td>41</td></tr><tr><td>MSD-Prostate [1]</td><td>prostate (pelvic)</td><td>MR: T2w, ADC</td><td>1</td><td>32</td></tr><tr><td>PROMISE12 [29]</td><td>prostate (pelvic)</td><td>MR: T2w</td><td>1</td><td>train: 50; test: 30</td></tr><tr><td>MMWHS [47]</td><td>cardiac substructures</td><td>CT, MR</td><td>5</td><td>CT: 20, MR: 20</td></tr><tr><td>MSD-Heart [1]</td><td>left atrium (cardiac)</td><td>MR</td><td>1</td><td>20</td></tr></table>

<table><tbody><tr><td>$\mathbf{{Dataset}}$</td><td>解剖结构</td><td>成像模态</td><td>类别数</td><td>样本数</td></tr><tr><td>BTCV [27]</td><td>腹部器官</td><td>CT(计算机断层扫描)</td><td>13</td><td>30</td></tr><tr><td>AMOS’22 [21]</td><td>腹部器官</td><td>CT，MR(磁共振成像)</td><td>15</td><td>CT:120，MR:60(测试集)</td></tr><tr><td>FLARE’22 [33]</td><td>腹部器官</td><td>CT(计算机断层扫描)</td><td>13</td><td>训练:50；测试:22</td></tr><tr><td>CHAOS [24]</td><td>腹部器官</td><td>MR:T2-SPIR</td><td>4</td><td>20</td></tr><tr><td>MSD-Spleen [1]</td><td>脾脏(腹部)</td><td>CT(计算机断层扫描)</td><td>1</td><td>41</td></tr><tr><td>MSD-Prostate [1]</td><td>前列腺(盆腔)</td><td>MR:T2加权，ADC</td><td>1</td><td>32</td></tr><tr><td>PROMISE12 [29]</td><td>前列腺(盆腔)</td><td>MR:T2加权</td><td>1</td><td>训练:50；测试:30</td></tr><tr><td>MMWHS [47]</td><td>心脏亚结构</td><td>CT，MR(磁共振成像)</td><td>5</td><td>CT:20，MR:20</td></tr><tr><td>MSD-Heart [1]</td><td>左心房(心脏)</td><td>MR</td><td>1</td><td>20</td></tr></tbody></table>

Domain-specific FMs: These include models that have been trained on cu-rated corpora comprising multiple anatomy-specific datasets in a specific modality. In this category, we consider the following models: FSEFT [39], VISTA3D [16] and MRSegmentator [15]. While the former two models were trained with publicly accessible CT volumes only, MRSegmentator was trained with both CT and MR data, the latter coming from an in-house corpus [15]. Moreover, FSEFT focuses on segmenting abdominal and thoracic structures, whereas VISTA3D and MRSegmentator are trained on a larger set of organs.

特定领域的基础模型(FMs):包括在特定模态下由多个解剖学特定数据集组成的经过精心策划的语料库上训练的模型。在此类别中，我们考虑以下模型:FSEFT [39]、VISTA3D [16] 和 MRSegmentator [15]。前两者仅使用公开可获取的CT体积数据训练，而MRSegmentator则同时使用了来自内部语料库的CT和MR数据[15]。此外，FSEFT专注于腹部和胸部结构的分割，而VISTA3D和MRSegmentator则训练于更大范围的器官集合。

Visual Prompted FMs: As discussed earlier, promptable segmentation models $\left\lbrack  {{25},{42}}\right\rbrack$ enable more general segmentations, since the target can be guided by user-defined visual region of interest indicators (e.g., points/clicks, bounding boxes, or segmentation masks) [25]. Following this paradigm, we evaluate two such recently proposed models for volumetric medical segmentation: SAM-Med3D [42] and SegVol [13]. While SAM-Med3D is trained with 3D point prompts and multiple modalities, the latter is trained only on CT volumes and enables both points and bounding boxes as visual prompt inputs.

视觉提示基础模型(FMs):如前所述，可提示分割模型$\left\lbrack  {{25},{42}}\right\rbrack$支持更通用的分割，因为目标可以通过用户定义的视觉兴趣区域指示器(例如点/点击、边界框或分割掩码)进行引导[25]。基于此范式，我们评估了两种最近提出的体积医学分割模型:SAM-Med3D [42] 和 SegVol [13]。SAM-Med3D使用3D点提示并支持多模态训练，而后者仅在CT体积上训练，且支持点和边界框作为视觉提示输入。

Text Prompted FMs: Moving beyond spatial prompts, we also evaluate text promptable segmentation models - SegVol [13] and SAT [46], where spatial prompts can be replaced (or augmented) with semantic text for target organs.

文本提示基础模型(FMs):超越空间提示，我们还评估了文本提示分割模型——SegVol [13] 和 SAT [46]，其中空间提示可以被目标器官的语义文本替代或增强。

## 4 Experiments

## 4 实验

Implementation: All models are implemented in PyTorch [35] and MONAI [6], accelerated by a 48GB Nvidia RTX A6000 GPU. We used publicly available codebases and checkpoints for all models. Specific preprocessing details for each model, such as input spacing and intensity ranges for different modalities, are outlined in Table 2. Our inference scripts will be open-sourced upon acceptance.

实现:所有模型均基于PyTorch [35] 和 MONAI [6] 实现，并由48GB Nvidia RTX A6000 GPU加速。我们使用了所有模型的公开代码库和检查点。各模型的具体预处理细节，如不同模态的输入间距和强度范围，详见表2。我们的推理脚本将在论文接受后开源。

Table 2: List of foundational 3D medical segmentation models, along with their respective input preprocessing. We focus on domain-specific trained FMs, visual and text promptable FMs and investigate their domain generalization feasibility.

表2:基础3D医学分割模型列表及其相应的输入预处理。我们重点关注特定领域训练的基础模型、视觉和文本提示基础模型，并探讨其领域泛化能力。

<table><tr><td>Model</td><td>Training domain</td><td>#classes</td><td>Resampling</td><td>Intensity clipping ranges</td></tr><tr><td>FSEFT [39]</td><td>CT</td><td>29</td><td>${1.5}{mm}^{3}$</td><td>CT: $\left\lbrack  {-{175},{250}}\right\rbrack  \mathrm{{HU}}$ ; MR: ${\left\lbrack  1,{99}\right\rbrack  }^{th}$ %ile</td></tr><tr><td>VISTA3D [16]</td><td>CT</td><td>124</td><td>${1.5}{mm}^{3}$</td><td>CT: $\left\lbrack  {-{1000},{1000}}\right\rbrack$ HU; MR: ${\left\lbrack  1,{99}\right\rbrack  }^{th}$ %ile</td></tr><tr><td>MRSegmentator [15]</td><td>CT, MR</td><td>40</td><td>${1.5} \times  {1.5} \times  {3.0}\mathrm{\;m}{\mathrm{\;m}}^{3}$</td><td>CT: ${\left\lbrack  {0.5},{99.5}\right\rbrack  }^{th}\%$ ile; MR: Z-score norm.</td></tr><tr><td>SAM-Med3D [42]</td><td>CT, MR</td><td>-</td><td>${1.5}{mm}^{3}$</td><td>CT & MR: Z-score norm.</td></tr><tr><td>SegVol [13]</td><td>CT</td><td>-</td><td>-</td><td>CT: ${\left\lbrack  {0.5},{99.5}\right\rbrack  }^{th}$ %ile; MR: ${\left\lbrack  1,{99}\right\rbrack  }^{th}$ %ile</td></tr><tr><td>SAT [46]</td><td>CT, MR, PET</td><td>-</td><td>${1.0} \times  {1.0} \times  {3.0}{\mathrm{\;{mm}}}^{3}$</td><td>CT: $\left\lbrack  {-{500},{1000}}\right\rbrack  \mathrm{{HU}}$ ; MR: ${\left\lbrack  {0.5},{99.5}\right\rbrack  }^{th}$ %ile</td></tr></table>

<table><tbody><tr><td>模型</td><td>训练领域</td><td>类别数</td><td>重采样</td><td>强度截断范围</td></tr><tr><td>FSEFT [39]</td><td>CT(计算机断层扫描)</td><td>29</td><td>${1.5}{mm}^{3}$</td><td>CT: $\left\lbrack  {-{175},{250}}\right\rbrack  \mathrm{{HU}}$ ; MR(磁共振成像): ${\left\lbrack  1,{99}\right\rbrack  }^{th}$ 百分位</td></tr><tr><td>VISTA3D [16]</td><td>CT(计算机断层扫描)</td><td>124</td><td>${1.5}{mm}^{3}$</td><td>CT: $\left\lbrack  {-{1000},{1000}}\right\rbrack$ HU(Hounsfield单位); MR: ${\left\lbrack  1,{99}\right\rbrack  }^{th}$ 百分位</td></tr><tr><td>MRSegmentator [15]</td><td>CT，MR</td><td>40</td><td>${1.5} \times  {1.5} \times  {3.0}\mathrm{\;m}{\mathrm{\;m}}^{3}$</td><td>CT: ${\left\lbrack  {0.5},{99.5}\right\rbrack  }^{th}\%$ 百分位；MR: Z分数归一化</td></tr><tr><td>SAM-Med3D [42]</td><td>CT，MR</td><td>-</td><td>${1.5}{mm}^{3}$</td><td>CT和MR: Z分数归一化</td></tr><tr><td>SegVol [13]</td><td>CT(计算机断层扫描)</td><td>-</td><td>-</td><td>CT: ${\left\lbrack  {0.5},{99.5}\right\rbrack  }^{th}$ 百分位；MR: ${\left\lbrack  1,{99}\right\rbrack  }^{th}$ 百分位</td></tr><tr><td>SAT [46]</td><td>CT，MR，PET(正电子发射断层扫描)</td><td>-</td><td>${1.0} \times  {1.0} \times  {3.0}{\mathrm{\;{mm}}}^{3}$</td><td>CT: $\left\lbrack  {-{500},{1000}}\right\rbrack  \mathrm{{HU}}$ ; MR: ${\left\lbrack  {0.5},{99.5}\right\rbrack  }^{th}$ 百分位</td></tr></tbody></table>

Evaluation metric: We used the Dice Similarity Coefficient (DSC) [11] to report all experimental results, considering it to be the de facto standard metric for evaluating segmentation models [7,20].

评估指标:我们使用Dice相似系数(DSC)[11]报告所有实验结果，认为其是评估分割模型的事实标准指标[7,20]。

In-domain specialist model: We chose nnUNet [19] as the specialist "oracle" model defining the empirical upper bound performance in-domain, subsequently quantifying the domain gap with respect to the FMs. Choosing nnUNet is supported by a recent study [20] that concluded it to be the SoTA segmentation model. Specifically, we report results from SAT [46], which extensively trained dataset-specific nnUNets and provided full training details for reproducibility.

领域内专家模型:我们选择nnUNet [19]作为专家“oracle”模型，定义领域内的经验上限性能，随后量化与基础模型(FMs)的领域差距。选择nnUNet得到了近期研究[20]的支持，该研究认为其为最先进(SoTA)的分割模型。具体而言，我们报告了SAT [46]的结果，该研究对特定数据集的nnUNet进行了广泛训练，并提供了完整的训练细节以保证可复现性。

### 4.1 Zero-shot transfer of domain-specific FMs

### 4.1 领域特定基础模型的零样本迁移

Our analysis starts with probing the domain transferability of large-scale modality-specific trained FMs: FSEFT [39], VISTA3D [16] and MRSegmentator [15]. In Table 3, we report average Dice scores across all organs for each dataset.

我们的分析从探究大规模模态特定训练基础模型(FSEFT [39]、VISTA3D [16]和MRSegmentator [15])的领域迁移能力开始。在表3中，我们报告了各数据集中所有器官的平均Dice分数。

Table 3: Performance of domain-specific FMs across different datasets. Datasets marked as (-) were used for training the respective model and are hence excluded for domain generalization experiments. Cardiac and Prostate datasets are excluded since those anatomies were not present during training of the comparative models.

表3:领域特定基础模型在不同数据集上的表现。标记为(-)的数据集用于训练相应模型，因此在领域泛化实验中被排除。心脏和前列腺数据集被排除，因为这些解剖结构在比较模型的训练中未出现。

<table><tr><td rowspan="2">Domain-specific FMs</td><td colspan="4">$\mathbf{{CT}}$</td><td colspan="2">$\mathbf{{MR}}$</td></tr><tr><td>BTCV</td><td>AMOS‘22</td><td>FLARE‘22</td><td>MSD-Spleen</td><td>CHAOS</td><td>AMOS‘22</td></tr><tr><td>FSEFT [39]</td><td>-</td><td>-</td><td>75.06</td><td>-</td><td>23.76</td><td>38.72</td></tr><tr><td>VISTA3D [16]</td><td>82.52</td><td>-</td><td>87.29</td><td>-</td><td>24.10</td><td>42.28</td></tr><tr><td>MRSegmentator [15]</td><td>84.42</td><td>84.35</td><td>88.85</td><td>95.68</td><td>89.83</td><td>74.86</td></tr><tr><td>nnUNet (specialist) [19]</td><td>88.89</td><td>89.77</td><td>93.36</td><td>96.70</td><td>88.89</td><td>86.43</td></tr></table>

<table><tbody><tr><td rowspan="2">特定领域的基础模型</td><td colspan="4">$\mathbf{{CT}}$</td><td colspan="2">$\mathbf{{MR}}$</td></tr><tr><td>BTCV</td><td>AMOS‘22</td><td>FLARE‘22</td><td>MSD-脾脏</td><td>CHAOS</td><td>AMOS‘22</td></tr><tr><td>FSEFT [39]</td><td>-</td><td>-</td><td>75.06</td><td>-</td><td>23.76</td><td>38.72</td></tr><tr><td>VISTA3D [16]</td><td>82.52</td><td>-</td><td>87.29</td><td>-</td><td>24.10</td><td>42.28</td></tr><tr><td>MRSegmentator [15]</td><td>84.42</td><td>84.35</td><td>88.85</td><td>95.68</td><td>89.83</td><td>74.86</td></tr><tr><td>nnUNet(专家)[19]</td><td>88.89</td><td>89.77</td><td>93.36</td><td>96.70</td><td>88.89</td><td>86.43</td></tr></tbody></table>

Analysis. Notably, we observe significant domain gaps for all these models compared to the in-domain specialists [19], for both modality transfer $\left( {\mathrm{{CT}} \rightarrow  \mathrm{{MR}}}\right)$ as well as distribution shifts within the same modality. Expectedly, the CT-trained FSEFT and VISTA3D models greatly struggle to generalize to MR datasets having on same target anatomies they were trained on, and yield low segmentation scores on CHAOS-MR ( $\approx  {65}\%$ lower Dice) and AMOS-MR ( $\approx  {46}\%$ lower Dice) compared to the in-domain nnUNet. Furthermore, FSEFT also fails to generalize within CT, performing $\approx  {18}\%$ lower on FLARE’22 than nnUNet, while VISTA3D performs better but still lags by $\approx  6\%$ behind on BTCV and FLARE'22. MRSegmentator shows superior generalization, significantly reducing the performance gap with in-domain specialists. However, since it was trained on both CT and MR [15], this improvement is expected. The key takeaway is that while FSEFT and VISTA3D struggle for both within-modality and unseen-modality distribution shifts, MRSegmentator improves domain generalization with stronger performance on within-modality distribution drifts. Nevertheless, for most datasets, even MRSegmentator shows a considerable segmentation performance gap compared to the dataset-specific nnUNets.

分析。值得注意的是，我们观察到所有这些模型与领域内专家[19]相比存在显著的领域差距，无论是模态转换$\left( {\mathrm{{CT}} \rightarrow  \mathrm{{MR}}}\right)$还是同一模态内的分布变化。正如预期，基于CT训练的FSEFT和VISTA3D模型在泛化到具有相同目标解剖结构的MR数据集时表现不佳，在CHAOS-MR($\approx  {65}\%$ Dice系数显著降低)和AMOS-MR($\approx  {46}\%$ Dice系数显著降低)上的分割得分远低于领域内的nnUNet。此外，FSEFT在CT内部的泛化能力也不足，在FLARE’22上的表现比nnUNet低$\approx  {18}\%$，而VISTA3D表现较好，但在BTCV和FLARE'22上仍落后$\approx  6\%$。MRSegmentator展现出更优的泛化能力，显著缩小了与领域内专家的性能差距。然而，由于其同时在CT和MR上训练[15]，这一提升是预期之内的。关键结论是，尽管FSEFT和VISTA3D在同模态和未见模态的分布变化中均表现不佳，MRSegmentator通过在同模态分布漂移上的更强性能提升了领域泛化能力。尽管如此，对于大多数数据集，即使是MRSegmentator与特定数据集的nnUNet相比，分割性能仍存在较大差距。

### 4.2 Visual promptable FMs

### 4.2 可视化提示的基础模型

With domain-specific FMs having limited target organs, we next shift focus to what has been the recent paradigm of segmentation FMs - prompting with spatial region of interest inputs $\left\lbrack  {{25},{42},{13}}\right\rbrack$ . Our candidate models are SAM-Med3D [42] and SegVol [13], with 3D points and bounding boxes as prompts. Table 4 shows the average Dice scores for each testing dataset.

鉴于领域特定的基础模型在目标器官数量上的限制，我们接下来将关注最近的分割基础模型范式——通过空间感兴趣区域输入进行提示$\left\lbrack  {{25},{42},{13}}\right\rbrack$。我们的候选模型是SAM-Med3D[42]和SegVol[13]，提示形式为3D点和边界框。表4展示了各测试数据集的平均Dice得分。

Table 4: Performance of visually promptable foundational models. 'P' denotes the number of points provided as prompts. Values are Dice %.

表4:可视化提示基础模型的性能。‘P’表示提供的提示点数量。数值为Dice百分比。

<table><tr><td rowspan="2">Visual Prompted FMs</td><td colspan="4">SAM-Med3D [42]</td><td colspan="2">SegVol [13]</td><td rowspan="2">nnUNet [19] (specialist)</td></tr><tr><td>P=1</td><td>P=3</td><td>P=5</td><td>P=10</td><td>P=5</td><td>Bbox</td></tr><tr><td colspan="8">Abdominal CT</td></tr><tr><td>BTCV</td><td>78.99</td><td>80.99</td><td>81.49</td><td>81.86</td><td>67.04</td><td>80.15</td><td>88.89</td></tr><tr><td>AMOS‘22</td><td>79.06</td><td>81.74</td><td>82.31</td><td>83.18</td><td>65.46</td><td>79.82</td><td>89.77</td></tr><tr><td>FLARE‘22</td><td>84.41</td><td>86.63</td><td>86.91</td><td>87.28</td><td>68.25</td><td>76.93</td><td>93.36</td></tr><tr><td>MSD-Spleen</td><td>94.00</td><td>94.43</td><td>94.51</td><td>94.62</td><td>91.72</td><td>94.21</td><td>96.70</td></tr><tr><td colspan="8">Abdominal MR</td></tr><tr><td>CHAOS</td><td>89.52</td><td>90.64</td><td>91.54</td><td>91.76</td><td>80.25</td><td>10.11</td><td>88.89</td></tr><tr><td>AMOS‘22</td><td>71.01</td><td>75.04</td><td>76.43</td><td>77.47</td><td>60.18</td><td>45.96</td><td>86.43</td></tr><tr><td colspan="8">Pelvic (MR)</td></tr><tr><td>MSD-Prostate (T2)</td><td>84.32</td><td>88.33</td><td>88.85</td><td>89.93</td><td>57.53</td><td>37.27</td><td>87.60</td></tr><tr><td>MSD-Prostate (ADC)</td><td>80.53</td><td>84.77</td><td>86.37</td><td>86.97</td><td>66.76</td><td>25.82</td><td>87.60</td></tr><tr><td>PROMISE12</td><td>84.41</td><td>86.86</td><td>88.02</td><td>88.98</td><td>55.27</td><td>39.42</td><td>88.86</td></tr><tr><td colspan="8">Cardiac</td></tr><tr><td>MMWHS (CT)</td><td>52.09</td><td>62.25</td><td>65.24</td><td>69.18</td><td>46.82</td><td>61.53</td><td>88.64</td></tr><tr><td>MMWHS (MR)</td><td>54.55</td><td>66.67</td><td>70.08</td><td>72.99</td><td>39.82</td><td>51.48</td><td>30.88</td></tr><tr><td>MSD-Heart (MR)</td><td>79.69</td><td>86.32</td><td>87.20</td><td>88.22</td><td>42.66</td><td>57.88</td><td>94.28</td></tr></table>

<table><tbody><tr><td rowspan="2">视觉提示的基础模型</td><td colspan="4">SAM-Med3D [42]</td><td colspan="2">SegVol [13]</td><td rowspan="2">nnUNet [19](专家模型)</td></tr><tr><td>P=1</td><td>P=3</td><td>P=5</td><td>P=10</td><td>P=5</td><td>边界框</td></tr><tr><td colspan="8">腹部CT</td></tr><tr><td>BTCV</td><td>78.99</td><td>80.99</td><td>81.49</td><td>81.86</td><td>67.04</td><td>80.15</td><td>88.89</td></tr><tr><td>AMOS‘22</td><td>79.06</td><td>81.74</td><td>82.31</td><td>83.18</td><td>65.46</td><td>79.82</td><td>89.77</td></tr><tr><td>FLARE‘22</td><td>84.41</td><td>86.63</td><td>86.91</td><td>87.28</td><td>68.25</td><td>76.93</td><td>93.36</td></tr><tr><td>MSD-脾脏</td><td>94.00</td><td>94.43</td><td>94.51</td><td>94.62</td><td>91.72</td><td>94.21</td><td>96.70</td></tr><tr><td colspan="8">腹部磁共振</td></tr><tr><td>CHAOS</td><td>89.52</td><td>90.64</td><td>91.54</td><td>91.76</td><td>80.25</td><td>10.11</td><td>88.89</td></tr><tr><td>AMOS‘22</td><td>71.01</td><td>75.04</td><td>76.43</td><td>77.47</td><td>60.18</td><td>45.96</td><td>86.43</td></tr><tr><td colspan="8">骨盆(磁共振)</td></tr><tr><td>MSD-前列腺(T2)</td><td>84.32</td><td>88.33</td><td>88.85</td><td>89.93</td><td>57.53</td><td>37.27</td><td>87.60</td></tr><tr><td>MSD-前列腺(ADC)</td><td>80.53</td><td>84.77</td><td>86.37</td><td>86.97</td><td>66.76</td><td>25.82</td><td>87.60</td></tr><tr><td>PROMISE12</td><td>84.41</td><td>86.86</td><td>88.02</td><td>88.98</td><td>55.27</td><td>39.42</td><td>88.86</td></tr><tr><td colspan="8">心脏</td></tr><tr><td>MMWHS(CT)</td><td>52.09</td><td>62.25</td><td>65.24</td><td>69.18</td><td>46.82</td><td>61.53</td><td>88.64</td></tr><tr><td>MMWHS(磁共振)</td><td>54.55</td><td>66.67</td><td>70.08</td><td>72.99</td><td>39.82</td><td>51.48</td><td>30.88</td></tr><tr><td>MSD-心脏(磁共振)</td><td>79.69</td><td>86.32</td><td>87.20</td><td>88.22</td><td>42.66</td><td>57.88</td><td>94.28</td></tr></tbody></table>

Effect of prompts. Unsurprisingly, for SAM-Med3D, segmentation performance consistently improves with an increase in point prompts. However, it is interesting to observe that the performance gain quickly saturates for even greater increase in number of points: for instance, for cardiac substructures [47,1], Table 4 shows that while increasing $P = 1 \rightarrow  3$ greatly improves segmentation performance $\left( {\Delta  \approx  {10}\% }\right)$ - the margin of improvement is lower for $P = 3 \rightarrow  5$ $\left( {\Delta  \approx  {2.6}\% }\right)$ and $P = 5 \rightarrow  {10}\left( {\Delta  \approx  {2.3}\% }\right)$ . Other datasets show lower improvement margins with an increasing number of points. For SegVol, point-prompted scores remain consistently lower than for SAM-Med3D, but bounding boxes improve segmentation on several datasets. Notably, for all CT datasets, bounding boxes outperform points, aligning with prior findings [13]. However, for unseen MR modalities, points outperform boxes (e.g., AMOS'22-MR: 60.18 vs. 45.96, PROMISE12: 55.27 vs. 39.42). We hypothesize that bounding boxes capture background regions, leading to misclassification of foreground voxels in unseen modalities, whereas points - always marking the foreground-avoid this issue.

提示的影响。不出所料，对于SAM-Med3D，随着点提示数量的增加，分割性能持续提升。然而，有趣的是，性能提升在点数进一步增加时很快趋于饱和:例如，对于心脏亚结构[47,1]，表4显示，虽然增加$P = 1 \rightarrow  3$显著提升了分割性能$\left( {\Delta  \approx  {10}\% }\right)$——但对于$P = 3 \rightarrow  5$$\left( {\Delta  \approx  {2.6}\% }\right)$和$P = 5 \rightarrow  {10}\left( {\Delta  \approx  {2.3}\% }\right)$，提升幅度较小。其他数据集随着点数增加，提升幅度也较低。对于SegVol，点提示的得分始终低于SAM-Med3D，但边界框在多个数据集上提升了分割效果。值得注意的是，对于所有CT数据集，边界框优于点提示，这与先前研究[13]一致。然而，对于未见过的MR模态，点提示优于边界框(例如，AMOS'22-MR:60.18比45.96，PROMISE12:55.27比39.42)。我们推测边界框捕捉了背景区域，导致未见模态中前景体素被误分类，而点提示始终标记前景，避免了此问题。

Domain generalization analysis. SegVol is a CT-only trained model; for zero-shot transfer on MR datasets, it performs considerably worse compared to SAM-Med3D with the same number of point prompts $\left( {{\Delta }_{\mathrm{P} = 5}\left( \mathrm{{CHAOS}}\right)  \approx  }\right.$ ${11}\% ,{\Delta }_{\mathrm{P} = 5}\left( \mathrm{{AMOS}}\right)  \approx  {16}\% )$ . On the brighter side, SegVol achieves higher Dice scores than its domain-specific counterparts (FSEFT [39] and VISTA3D [16], from Table 3). SAM-Med3D was trained with both CT and MR data and shows stronger generalizability, even outperforming the specialist nnUNet on CHAOS (91.76 vs. 88.89) and MSD-Prostate T2 (89.93 vs. 87.60). Yet, it exhibits a significant domain gap against the in-domain specialist nnUNet on the abdominal $\left( {{\Delta }_{\mathrm{{BTCV}}} \approx  7\% ,{\Delta }_{\mathrm{{AMOS}} - \mathrm{{MR}}} \approx  9\% }\right)$ and cardiac $\left( {{\Delta }_{\mathrm{{MMWHS}} - \mathrm{{CT}}} \approx  }\right.$ ${20}\% ,{\Delta }_{\text{MSD-Heart }} \approx  6\%$ ) datasets. Nevertheless, visual prompted FMs dominate domain-specific FMs in terms of applicability towards a broader range of anatomies, paving the way to reduce the existing domain gap compared to specialist models.

领域泛化分析。SegVol是仅在CT上训练的模型；在MR数据集上的零样本迁移表现明显不如使用相同点提示数量的SAM-Med3D$\left( {{\Delta }_{\mathrm{P} = 5}\left( \mathrm{{CHAOS}}\right)  \approx  }\right.$${11}\% ,{\Delta }_{\mathrm{P} = 5}\left( \mathrm{{AMOS}}\right)  \approx  {16}\% )$。好消息是，SegVol的Dice分数高于其领域特定的对应模型(FSEFT[39]和VISTA3D[16]，见表3)。SAM-Med3D同时使用CT和MR数据训练，展现出更强的泛化能力，甚至在CHAOS(91.76比88.89)和MSD-Prostate T2(89.93比87.60)上超越了专用的nnUNet。然而，在腹部$\left( {{\Delta }_{\mathrm{{BTCV}}} \approx  7\% ,{\Delta }_{\mathrm{{AMOS}} - \mathrm{{MR}}} \approx  9\% }\right)$和心脏$\left( {{\Delta }_{\mathrm{{MMWHS}} - \mathrm{{CT}}} \approx  }\right.$${20}\% ,{\Delta }_{\text{MSD-Heart }} \approx  6\%$数据集上，它与领域内专用nnUNet存在显著的领域差距。尽管如此，视觉提示的基础模型在适用更广泛解剖结构方面优于领域特定模型，为缩小与专用模型的领域差距铺平了道路。

Generalization to unseen anatomies via prompting. SegVol's training corpus lacked pelvic and cardiac anatomies [13], allowing us to assess its zero-shot performance. From Table 4, for MMWHS-CT (known modality), SegVol with boxes nears SAM-Med3D's performance with 3-point prompts (61.53 vs. 62.25), but SAM-Med3D surpasses it beyond this. For prostate and cardiac MR, scores fall well below in-domain specialist nnUNets [19]. These results indicate that current 3D promptable FMs still struggle with unseen anatomies, requiring further research and improvements.

通过提示实现对未见解剖结构的泛化。SegVol的训练语料缺乏盆腔和心脏解剖结构[13]，使我们能够评估其零样本性能。从表4看，对于MMWHS-CT(已知模态)，使用边界框的SegVol接近SAM-Med3D的3点提示性能(61.53比62.25)，但SAM-Med3D在此基础上表现更优。对于前列腺和心脏MR，得分远低于领域内专用nnUNet[19]。这些结果表明，当前的3D可提示基础模型在处理未见解剖结构时仍存在困难，需进一步研究和改进。

### 4.3 Text promptable FMs

### 4.3 文本提示基础模型

Going further, recent works have also enabled semantic textual prompts to denote target structures for segmentation, typically processed via a pre-trained text encoder $\left\lbrack  {{36},{10},{22}}\right\rbrack$ . We have two candidate models - SegVol with text prompts [13] and SAT [46]. Table 5 shows the corresponding Dice scores obtained.

进一步地，近期工作也实现了通过语义文本提示来指定分割目标结构，通常通过预训练文本编码器$\left\lbrack  {{36},{10},{22}}\right\rbrack$处理。我们有两个候选模型——带文本提示的SegVol[13]和SAT[46]。表5展示了相应的Dice分数。

Table 5: Performance of text promptable FMs. SAT-Nano and SAT-Pro denote smaller (110M) and larger capacity (447M) model variants respectively, while SAT-Ft is a fine-tuned version (not zero-shot) of SAT-Pro on the respective datasets.

表5:文本提示基础模型的性能。SAT-Nano和SAT-Pro分别表示较小(1.1亿参数)和较大容量(4.47亿参数)的模型变体，而SAT-Ft是SAT-Pro在相应数据集上的微调版本(非零样本)。

<table><tr><td rowspan="2">Text Prompted FMs</td><td colspan="3">SegVol [13]</td><td colspan="3">SAT [46]</td><td rowspan="2">nnUNet [19] (specialist)</td></tr><tr><td>text</td><td>text+bbox</td><td>text+points</td><td>Nano</td><td>Pro</td><td>Ft</td></tr><tr><td colspan="8">Abdominal CT</td></tr><tr><td>BTCV</td><td>80.68</td><td>81.87</td><td>71.70</td><td>79.60</td><td>80.71</td><td>81.60</td><td>88.89</td></tr><tr><td>AMOS‘22</td><td>75.30</td><td>81.12</td><td>69.09</td><td>84.93</td><td>86.37</td><td>88.75</td><td>89.77</td></tr><tr><td>FLARE‘22</td><td>77.32</td><td>78.73</td><td>72.79</td><td>88.79</td><td>91.12</td><td>91.78</td><td>93.36</td></tr><tr><td>MSD-Spleen</td><td>95.75</td><td>95.79</td><td>95.76</td><td>93.50</td><td>94.12</td><td>94.97</td><td>96.70</td></tr><tr><td colspan="8">Abdominal MR</td></tr><tr><td>CHAOS</td><td>73.23</td><td>21.32</td><td>81.06</td><td>82.07</td><td>87.28</td><td>87.99</td><td>88.89</td></tr><tr><td>AMOS‘22</td><td>62.73</td><td>47.29</td><td>61.59</td><td>78.76</td><td>78.90</td><td>84.82</td><td>86.43</td></tr><tr><td colspan="8">Pelvic (MR)</td></tr><tr><td>MSD-Prostate (T2)</td><td>0.01</td><td>20.53</td><td>26.65</td><td>73.38</td><td>78.33</td><td>77.98</td><td>87.60</td></tr><tr><td>MSD-Prostate (ADC)</td><td>0.05</td><td>35.21</td><td>65.71</td><td>73.38</td><td>78.33</td><td>77.98</td><td>87.60</td></tr><tr><td>PROMISE12</td><td>0.20</td><td>24.68</td><td>30.50</td><td>84.55</td><td>86.51</td><td>87.28</td><td>88.86</td></tr><tr><td colspan="8">Cardiac</td></tr><tr><td>MMWHS (CT)</td><td>0.03</td><td>35.54</td><td>13.01</td><td>88.23</td><td>89.97</td><td>91.14</td><td>88.64</td></tr><tr><td>MMWHS (MR)</td><td>0.07</td><td>29.24</td><td>13.78</td><td>84.37</td><td>86.70</td><td>87.73</td><td>30.88</td></tr><tr><td>MSD-Heart (MR)</td><td>0.02</td><td>54.45</td><td>37.16</td><td>90.28</td><td>92.61</td><td>93.38</td><td>94.28</td></tr></table>

<table><tbody><tr><td rowspan="2">文本提示的基础模型</td><td colspan="3">SegVol [13]</td><td colspan="3">SAT [46]</td><td rowspan="2">nnUNet [19](专用模型)</td></tr><tr><td>文本</td><td>文本+边界框</td><td>文本+点</td><td>纳米</td><td>专业版</td><td>微调</td></tr><tr><td colspan="8">腹部CT</td></tr><tr><td>BTCV</td><td>80.68</td><td>81.87</td><td>71.70</td><td>79.60</td><td>80.71</td><td>81.60</td><td>88.89</td></tr><tr><td>AMOS‘22</td><td>75.30</td><td>81.12</td><td>69.09</td><td>84.93</td><td>86.37</td><td>88.75</td><td>89.77</td></tr><tr><td>FLARE‘22</td><td>77.32</td><td>78.73</td><td>72.79</td><td>88.79</td><td>91.12</td><td>91.78</td><td>93.36</td></tr><tr><td>MSD-脾脏</td><td>95.75</td><td>95.79</td><td>95.76</td><td>93.50</td><td>94.12</td><td>94.97</td><td>96.70</td></tr><tr><td colspan="8">腹部磁共振</td></tr><tr><td>CHAOS</td><td>73.23</td><td>21.32</td><td>81.06</td><td>82.07</td><td>87.28</td><td>87.99</td><td>88.89</td></tr><tr><td>AMOS‘22</td><td>62.73</td><td>47.29</td><td>61.59</td><td>78.76</td><td>78.90</td><td>84.82</td><td>86.43</td></tr><tr><td colspan="8">骨盆(磁共振)</td></tr><tr><td>MSD-前列腺(T2)</td><td>0.01</td><td>20.53</td><td>26.65</td><td>73.38</td><td>78.33</td><td>77.98</td><td>87.60</td></tr><tr><td>MSD-前列腺(ADC)</td><td>0.05</td><td>35.21</td><td>65.71</td><td>73.38</td><td>78.33</td><td>77.98</td><td>87.60</td></tr><tr><td>PROMISE12</td><td>0.20</td><td>24.68</td><td>30.50</td><td>84.55</td><td>86.51</td><td>87.28</td><td>88.86</td></tr><tr><td colspan="8">心脏</td></tr><tr><td>MMWHS(CT)</td><td>0.03</td><td>35.54</td><td>13.01</td><td>88.23</td><td>89.97</td><td>91.14</td><td>88.64</td></tr><tr><td>MMWHS(磁共振)</td><td>0.07</td><td>29.24</td><td>13.78</td><td>84.37</td><td>86.70</td><td>87.73</td><td>30.88</td></tr><tr><td>MSD-心脏(磁共振)</td><td>0.02</td><td>54.45</td><td>37.16</td><td>90.28</td><td>92.61</td><td>93.38</td><td>94.28</td></tr></tbody></table>

Text inputs boost spatial prompts. We investigate the effect of semantic prompts as an additional guidance alongside spatial prompts for SegVol [13], denoted by "text+bbox" and "text+points" in Table 5. Comparing them with corresponding vanilla spatial prompts in Table 4, we notice that for known anatomies (abdominal CT and MR), the addition of text consistently improves segmentations from raw spatial prompts (BTCV: ${80.15}\mathrm{w}/$ bbox, ${81.87}\mathrm{w}/$ text+bbox; CHAOS: ${80.25}\mathrm{\;w}/$ points, ${81.06}\mathrm{\;w}/$ text+points). We show example segmentation results in Figure 1. For unseen anatomies, text prompts completely fail, since the model has no knowledge to spatially ground such concepts.

文本输入增强空间提示。我们研究了语义提示作为空间提示的额外引导对SegVol [13]的影响，在表5中以“text+bbox”和“text+points”表示。与表4中对应的纯空间提示相比，我们注意到对于已知解剖结构(腹部CT和MR)，文本的加入始终提升了基于原始空间提示的分割效果(BTCV:${80.15}\mathrm{w}/$ bbox，${81.87}\mathrm{w}/$ text+bbox；CHAOS:${80.25}\mathrm{\;w}/$ points，${81.06}\mathrm{\;w}/$ text+points)。我们在图1中展示了示例分割结果。对于未知解剖结构，文本提示完全失效，因为模型无法将此类概念空间定位。

Semantic prompts show better domain generalization. As can be seen from Table 5 (as well as Table 4), for known anatomies, text-prompted segmentation shows better generalizability across modalities, surpassing visual prompts. In particular, SAT shows strong segmentation performance across all datasets, reducing the empirical domain gap with in-domain specialists in several cases. SAT also outperforms SegVol in the text-prompted configuration on most datasets. However, we point out that SAT and SegVol are not directly comparable: the training corpus of SAT is significantly larger than for SegVol [46], and while SegVol uses a CLIP [36] encoder for text, while SAT leverages a BERT [10] model pre-trained on medical documents, enhancing anatomical knowledge during prompting. Although there still remains a considerable empirical gap of SAT with in-domain nnUNets, it has been able to reduce it further as compared to previous FMs $\left\lbrack  {{39},{16},{42}}\right\rbrack$ with greater applicability across different anatomies and

语义提示表现出更好的领域泛化能力。如表5(以及表4)所示，对于已知解剖结构，基于文本提示的分割在跨模态泛化上优于视觉提示。特别是，SAT在所有数据集上均表现出强劲的分割性能，在多个案例中缩小了与领域内专家的经验域差距。SAT在大多数数据集上的文本提示配置中也优于SegVol。然而，我们指出SAT和SegVol不可直接比较:SAT的训练语料库远大于SegVol [46]，且SegVol使用CLIP [36]编码器处理文本，而SAT则利用在医学文献上预训练的BERT [10]模型，增强了提示时的解剖知识。尽管SAT与领域内nnUNets仍存在显著经验差距，但相比之前的基础模型(FM)$\left\lbrack  {{39},{16},{42}}\right\rbrack$，它已进一步缩小该差距，并在不同解剖结构上展现出更广泛的适用性，

![bo_d1c3stf7aajc7389qf5g_8_397_339_1015_282_0.jpg](images/bo_d1c3stf7aajc7389qf5g_8_397_339_1015_282_0.jpg)

Fig. 1: Qualitative results showing segmentation improvement in SegVol with text - bbox prompts for seen (CT; MSD-Spleen) and unseen (MR; CHAOS) modalities.

图1:定性结果展示了SegVol在已见(CT；MSD-Spleen)和未见(MR；CHAOS)模态下，结合文本-边界框提示的分割改进。

modalities, which makes us optimistic that text-promptable segmentation [46,30] possibly combined with visual prompts for further refinement will eventually become the universal segmentation paradigm.

模态，这使我们乐观地认为，基于文本提示的分割[46,30]，结合视觉提示以进一步精细化，最终将成为通用的分割范式。

## 5 Conclusion

## 5 结论

In this study, we explored the DG feasibility of FMs for 3D medical image segmentation, encompassing a variety of domain shift cases across anatomies and modalities, and different categories of FMs for a holistic analysis. The take-home message from our empirical findings is - while domain-specific FMs fail to generalize across domain shifts, promptable FMs show potential to bridge the domain gap, but require smart prompting techniques that can effectively convey the region-of-interest pointer to the model, possibly achievable by text prompts with spatial inputs for refinement. Future works should build upon these findings to develop a truly universal, domain-generalized segmentation framework.

本研究探讨了基础模型(FM)在3D医学图像分割中的领域泛化(DG)可行性，涵盖了解剖结构和模态的多种领域迁移情况，以及不同类别的基础模型以进行全面分析。我们的经验结论是——尽管领域特定的基础模型难以跨领域迁移，具备提示能力的基础模型展现出弥合领域差距的潜力，但需要智能的提示技术，能够有效向模型传达感兴趣区域的指示，这可能通过结合空间输入的文本提示实现精细化。未来工作应基于这些发现，开发真正通用且具领域泛化能力的分割框架。

## 6 Acknowledgements

## 6 致谢

This research was, in part, funded by the National Institutes of Health (NIH) under other transactions 1OT2OD038045-01 and NIAMS 1R01AR082684. The views and conclusions contained in this document are those of the authors and should not be interpreted as representing official policies, either expressed or implied, of the NIH.

本研究部分由美国国立卫生研究院(NIH)通过其他交易1OT2OD038045-01和NIAMS 1R01AR082684资助。本文所含观点和结论仅代表作者本人，不应被解读为NIH的官方政策，无论明示或暗示。

## References

## 参考文献

1. Antonelli, M., Reinke, A., Bakas, S., Farahani, K., et al.: The medical segmentation decathlon. Nature communications (2022)

1. Antonelli, M., Reinke, A., Bakas, S., Farahani, K., 等:医学分割十项全能竞赛。自然通讯 (2022)

2. Awais, M., Naseer, M., Khan, S., Anwer, R.M., Cholakkal, H., Shah, M., Yang, M.H., Khan, F.S.: Foundation models defining a new era in vision: a survey and outlook. IEEE TPAMI (2025)

2. Awais, M., Naseer, M., Khan, S., Anwer, R.M., Cholakkal, H., Shah, M., Yang, M.H., Khan, F.S.:基础模型定义视觉新时代:综述与展望。IEEE TPAMI (2025)

3. Bilic, P., Christ, P., Li, H.B., Vorontsov, E., Ben-Cohen, A., Kaissis, G., Szeskin, A., Jacobs, C., Mamani, G.E.H., Chartrand, G., et al.: The liver tumor segmentation benchmark (lits). Medical image analysis 84, 102680 (2023)

3. Bilic, P., Christ, P., Li, H.B., Vorontsov, E., Ben-Cohen, A., Kaissis, G., Szeskin, A., Jacobs, C., Mamani, G.E.H., Chartrand, G., 等:肝肿瘤分割基准(LiTS)。医学图像分析 84, 102680 (2023)

4. Bommasani, R., Hudson, D.A., Adeli, E., Altman, R., et al.: On the opportunities and risks of foundation models. arXiv preprint arXiv:2108.07258 (2021)

4. Bommasani, R., Hudson, D.A., Adeli, E., Altman, R., 等:基础模型的机遇与风险。arXiv预印本 arXiv:2108.07258 (2021)

5. Brown, T., Mann, B., Ryder, N., Subbiah, M., et al.: Language models are few-shot learners. In: NeurIPS (2020)

5. Brown, T., Mann, B., Ryder, N., Subbiah, M., 等:语言模型是少样本学习者。发表于NeurIPS (2020)

6. Cardoso, M.J., Li, W., Brown, R., Ma, N., et al.: Monai: An open-source framework for deep learning in healthcare. arXiv preprint arXiv:2211.02701 (2022)

6. Cardoso, M.J., Li, W., Brown, R., Ma, N., 等: Monai: 一个用于医疗保健深度学习的开源框架。arXiv预印本 arXiv:2211.02701 (2022)

7. Cekmeceli, K., Himmetoglu, M., Tombak, G.I., Susmelj, A., et al.: Do vision foundation models enhance domain generalization in medical image segmentation? arXiv preprint arXiv:2409.07960 (2024)

7. Cekmeceli, K., Himmetoglu, M., Tombak, G.I., Susmelj, A., 等: 视觉基础模型是否提升了医学图像分割中的领域泛化能力？arXiv预印本 arXiv:2409.07960 (2024)

8. Cheng, J., Ye, J., Deng, Z., Chen, J., et al.: Sam-med2d. arXiv preprint arXiv:2308.16184 (2023)

8. Cheng, J., Ye, J., Deng, Z., Chen, J., 等: Sam-med2d。arXiv预印本 arXiv:2308.16184 (2023)

9. Demir, B., Tian, L., Greer, H., Kwitt, R., et al.: MultiGradICON: A foundation model for multimodal medical image registration. In: MICCAI WBIR (2024)

9. Demir, B., Tian, L., Greer, H., Kwitt, R., 等: MultiGradICON: 一个用于多模态医学图像配准的基础模型。发表于: MICCAI WBIR (2024)

10. Devlin, J., Chang, M.W., Lee, K., Toutanova, K.: Bert: Pre-training of deep bidirectional transformers for language understanding. In: NACCL (2019)

10. Devlin, J., Chang, M.W., Lee, K., Toutanova, K.: BERT: 用于语言理解的深度双向变换器预训练。发表于: NACCL (2019)

11. Dice, L.R.: Measures of the amount of ecologic association between species. Ecology (1945)

11. Dice, L.R.: 物种间生态关联量的度量。生态学 (1945)

12. Dou, Q., Coelho de Castro, D., Kamnitsas, K., Glocker, B.: Domain generalization via model-agnostic learning of semantic features. In: NeurIPS (2019)

12. Dou, Q., Coelho de Castro, D., Kamnitsas, K., Glocker, B.: 通过模型无关的语义特征学习实现领域泛化。发表于: NeurIPS (2019)

13. Du, Y., Bai, F., Huang, T., Zhao, B.: Segvol: Universal and interactive volumetric medical image segmentation. In: NeurIPS (2024)

13. Du, Y., Bai, F., Huang, T., Zhao, B.: Segvol: 通用且交互式的体积医学图像分割。发表于: NeurIPS (2024)

14. Fu, Y., Chen, Z., Ye, Y., Lei, X., Wang, Z., Xia, Y.: Cosam: Self-correcting sam for domain generalization in 2d medical image segmentation. arXiv preprint arXiv:2411.10136 (2024)

14. Fu, Y., Chen, Z., Ye, Y., Lei, X., Wang, Z., Xia, Y.: Cosam: 用于二维医学图像分割领域泛化的自我纠正SAM。arXiv预印本 arXiv:2411.10136 (2024)

15. Häntze, H., Xu, L., Mertens, C.J., et al.: Mrsegmentator: Multi-modality segmentation of 40 classes in mri and ct. arXiv preprint arXiv:2405.06463 (2024)

15. Häntze, H., Xu, L., Mertens, C.J., 等: Mrsegmentator: MRI和CT中40类多模态分割。arXiv预印本 arXiv:2405.06463 (2024)

16. He, Y., Guo, P., Tang, Y., Myronenko, A., et al.: Vista3d: Versatile imaging segmentation and annotation model for $3\mathrm{\;d}$ computed tomography. arXiv preprint arXiv:2406.05285 (2024)

16. He, Y., Guo, P., Tang, Y., Myronenko, A., 等: Vista3d: 用于$3\mathrm{\;d}$计算机断层扫描的多功能成像分割与标注模型。arXiv预印本 arXiv:2406.05285 (2024)

17. Heller, N., Isensee, F., Maier-Hein, K.H., Hou, X., Xie, C., Li, F., Nan, Y., Mu, G., Lin, Z., Han, M., et al.: The state of the art in kidney and kidney tumor segmentation in contrast-enhanced ct imaging: Results of the kits19 challenge. Medical image analysis $\mathbf{{67}},{101821}\left( {2021}\right)$

17. Heller, N., Isensee, F., Maier-Hein, K.H., Hou, X., Xie, C., Li, F., Nan, Y., Mu, G., Lin, Z., Han, M., 等: 造影增强CT成像中肾脏及肾肿瘤分割的最新进展:KITS19挑战赛结果。医学图像分析 $\mathbf{{67}},{101821}\left( {2021}\right)$

18. Heller, N., Isensee, F., Trofimova, D., Tejpaul, R., Zhao, Z., Chen, H., Wang, L., Golts, A., Khapun, D., Shats, D., et al.: The kits21 challenge: Automatic segmentation of kidneys, renal tumors, and renal cysts in corticomedullary-phase ct. arXiv preprint arXiv:2307.01984 (2023)

18. Heller, N., Isensee, F., Trofimova, D., Tejpaul, R., Zhao, Z., Chen, H., Wang, L., Golts, A., Khapun, D., Shats, D., 等: KITS21挑战赛:皮质髓质期CT中肾脏、肾肿瘤及肾囊肿的自动分割。arXiv预印本 arXiv:2307.01984 (2023)

19. Isensee, F., Jaeger, P.F., Kohl, S.A., Petersen, J., Maier-Hein, K.H.: nnu-net: a self-configuring method for deep learning-based biomedical image segmentation. Nature Methods (2021)

19. Isensee, F., Jaeger, P.F., Kohl, S.A., Petersen, J., Maier-Hein, K.H.: nnU-Net: 一种自配置的基于深度学习的生物医学图像分割方法。自然方法 (2021)

20. Isensee, F., Wald, T., Ulrich, C., Baumgartner, M., Roy, S., Maier-Hein, K., Jaeger, P.F.: nnu-net revisited: A call for rigorous validation in 3d medical image segmentation. In: MICCAI (2024)

20. Isensee, F., Wald, T., Ulrich, C., Baumgartner, M., Roy, S., Maier-Hein, K., Jaeger, P.F.: nnU-Net再访:呼吁对三维医学图像分割进行严格验证。发表于: MICCAI (2024)

21. Ji, Y., Bai, H., Ge, C., Yang, J., et al.: Amos: A large-scale abdominal multi-organ benchmark for versatile medical image segmentation. In: NeurIPS (2022)

21. Ji, Y., Bai, H., Ge, C., Yang, J., 等: AMOS: 一个大规模腹部多器官多功能医学图像分割基准。发表于: NeurIPS (2022)

22. Jin, Q., Kim, W., Chen, Q., Comeau, D.C., Yeganova, L., Wilbur, W.J., Lu, Z.: Medcpt: Contrastive pre-trained transformers with large-scale pubmed search logs for zero-shot biomedical information retrieval. Bioinformatics (2023)

22. Jin, Q., Kim, W., Chen, Q., Comeau, D.C., Yeganova, L., Wilbur, W.J., Lu, Z.: Medcpt:基于大规模PubMed搜索日志的对比预训练变换器，用于零样本生物医学信息检索。Bioinformatics (2023)

23. Karani, N., Erdil, E., Chaitanya, K., Konukoglu, E.: Test-time adaptable neural networks for robust medical image segmentation. MedIA (2021)

23. Karani, N., Erdil, E., Chaitanya, K., Konukoglu, E.: 测试时可适应神经网络用于鲁棒的医学图像分割。MedIA (2021)

24. Kavur, A.E., Gezer, N.S., Bariş, M., Aslan, S., et al.: Chaos challenge-combined (ct-mr) healthy abdominal organ segmentation. MedIA (2021)

24. Kavur, A.E., Gezer, N.S., Bariş, M., Aslan, S., 等:Chaos挑战-联合(CT-MR)健康腹部器官分割。MedIA (2021)

25. Kirillov, A., Mintun, E., Ravi, N., et al.: Segment anything. In: ICCV (2023)

25. Kirillov, A., Mintun, E., Ravi, N., 等:分割一切。发表于:ICCV (2023)

26. Kondrateva, E., Pominova, M., Popova, E., Sharaev, M., Bernstein, A., Burnaev, E.: Domain shift in computer vision models for mri data analysis: an overview. In: SPIE ICMV (2021)

26. Kondrateva, E., Pominova, M., Popova, E., Sharaev, M., Bernstein, A., Burnaev, E.: MRI数据分析中计算机视觉模型的领域偏移综述。发表于:SPIE ICMV (2021)

27. Landman, B., Xu, Z., Igelsias, J., Styner, M., Langerak, T., Klein, A.: Miccai multi-atlas labeling beyond the cranial vault-workshop and challenge. In: MICCAI multi-atlas labeling beyond cranial vault-workshop challenge (2015)

27. Landman, B., Xu, Z., Igelsias, J., Styner, M., Langerak, T., Klein, A.: MICCAI多图谱标注超越颅腔-研讨会与挑战。发表于:MICCAI多图谱标注超越颅腔-研讨会挑战 (2015)

28. Li, Y., Wang, N., Shi, J., Hou, X., Liu, J.: Adaptive batch normalization for practical domain adaptation. Pattern Recognition (2018)

28. Li, Y., Wang, N., Shi, J., Hou, X., Liu, J.: 实用领域自适应的自适应批归一化。模式识别 (2018)

29. Litjens, G., Toth, R., Van De Ven, W., Hoeks, C., et al.: Evaluation of prostate segmentation algorithms for MRI: the PROMISE12 challenge. MedIA (2014)

29. Litjens, G., Toth, R., Van De Ven, W., Hoeks, C., 等:MRI前列腺分割算法评估:PROMISE12挑战。MedIA (2014)

30. Liu, J., Zhang, Y., Chen, J.N., Xiao, J., Lu, Y., A Landman, B., Yuan, Y., Yuille, A., Tang, Y., Zhou, Z.: CLIP-driven universal model for organ segmentation and tumor detection. In: ICCV (2023)

30. Liu, J., Zhang, Y., Chen, J.N., Xiao, J., Lu, Y., A Landman, B., Yuan, Y., Yuille, A., Tang, Y., Zhou, Z.: 基于CLIP驱动的通用器官分割与肿瘤检测模型。发表于:ICCV (2023)

31. Liu, Q., Chen, C., Qin, J., Dou, Q., Heng, P.A.: Feddg: Federated domain generalization on medical image segmentation via episodic learning in continuous frequency space. In: CVPR (2021)

31. Liu, Q., Chen, C., Qin, J., Dou, Q., Heng, P.A.: FEDDG:通过连续频率空间的情景学习实现医学图像分割的联邦领域泛化。发表于:CVPR (2021)

32. Ma, J., He, Y., Li, F., Han, L., You, C., Wang, B.: Segment anything in medical images. Nature Communications (2024)

32. Ma, J., He, Y., Li, F., Han, L., You, C., Wang, B.: 医学图像中的分割一切。自然通讯 (2024)

33. Ma, J., Zhang, Y., Gu, S., Ge, C., et al.: Unleashing the strengths of unlabeled data in pan-cancer abdominal organ quantification: the flare22 challenge. arXiv preprint arXiv:2308.05862 (2023)

33. Ma, J., Zhang, Y., Gu, S., Ge, C., 等:释放无标签数据在泛癌腹部器官量化中的潜力:FLARE22挑战。arXiv预印本 arXiv:2308.05862 (2023)

34. Nguyen, A.T., Torr, P., Lim, S.N.: Fedsr: A simple and effective domain generalization method for federated learning. In: NeurIPS (2022)

34. Nguyen, A.T., Torr, P., Lim, S.N.: FEDSR:一种简单有效的联邦学习领域泛化方法。发表于:NeurIPS (2022)

35. Paszke, A., Gross, S., Massa, F., Lerer, A., et al.: Pytorch: An imperative style, high-performance deep learning library. In: NeurIPS (2019)

35. Paszke, A., Gross, S., Massa, F., Lerer, A., 等:PyTorch:一种命令式风格的高性能深度学习库。发表于:NeurIPS (2019)

36. Radford, A., Kim, J.W., Hallacy, C., Ramesh, A., et al.: Learning transferable visual models from natural language supervision. In: ICML (2021)

36. Radford, A., Kim, J.W., Hallacy, C., Ramesh, A., 等:从自然语言监督中学习可迁移视觉模型。发表于:ICML (2021)

37. Radford, A., Narasimhan, K., Salimans, T., Sutskever, I.: Improving language understanding by generative pre-training. OpenAI (2018)

37. Radford, A., Narasimhan, K., Salimans, T., Sutskever, I.: 通过生成式预训练提升语言理解能力。OpenAI (2018)

38. Ramesh, A., Pavlov, M., Goh, G., Gray, S., Voss, C., Radford, A., Chen, M., Sutskever, I.: Zero-shot text-to-image generation. In: ICML (2021)

38. Ramesh, A., Pavlov, M., Goh, G., Gray, S., Voss, C., Radford, A., Chen, M., Sutskever, I.: 零样本文本到图像生成。发表于:ICML (2021)

39. Silva-Rodriguez, J., Dolz, J., Ayed, I.B.: Towards foundation models and few-shot parameter-efficient fine-tuning for volumetric organ segmentation. In: MICCAI Workshops (2023)

39. Silva-Rodriguez, J., Dolz, J., Ayed, I.B.: 面向基础模型和少样本参数高效微调的体积器官分割。发表于:MICCAI研讨会 (2023)

40. Tian, L., Greer, H., Kwitt, R., Vialard, F.X., et al.: unigradicon: A foundation model for medical image registration. In: MICCAI (2024)

40. Tian, L., Greer, H., Kwitt, R., Vialard, F.X., 等:unigradicon:一种用于医学图像配准的基础模型。发表于:MICCAI (2024)

41. Valanarasu, J.M.J., Guo, P., Vibashan, V., Patel, V.M.: On-the-fly test-time adaptation for medical image segmentation. In: MIDL (2024)

41. Valanarasu, J.M.J., Guo, P., Vibashan, V., Patel, V.M.: 医学图像分割的即时测试时自适应。发表于:MIDL (2024)

42. Wang, H., Guo, S., Ye, J., Deng, Z., et al.: Sam-med3d: towards general-purpose segmentation models for volumetric medical images. In: ECCV BIC (2024)

42. Wang, H., Guo, S., Ye, J., Deng, Z., 等:Sam-med3d:面向体积医学图像通用分割模型。发表于:ECCV BIC (2024)

43. Yoon, J.S., Oh, K., Shin, Y., Mazurowski, M.A., Suk, H.I.: Domain generalization for media: A survey. arXiv preprint arXiv:2310.08598 (2023)

43. Yoon, J.S., Oh, K., Shin, Y., Mazurowski, M.A., Suk, H.I.: 媒体领域泛化综述。arXiv预印本 arXiv:2310.08598 (2023)

44. Zhang, C., Liu, L., Cui, Y., Huang, G., Lin, W., Yang, Y., Hu, Y.: A comprehensive survey on segment anything model for vision and beyond. arXiv preprint arXiv:2305.08196 (2023)

44. Zhang, C., Liu, L., Cui, Y., Huang, G., Lin, W., Yang, Y., Hu, Y.: 关于Segment Anything Model(SAM)及其视觉及其他应用的综合综述。arXiv预印本 arXiv:2305.08196 (2023)

45. Zhang, Z., Yang, L., Zheng, Y.: Translating and segmenting multimodal medical volumes with cycle-and shape-consistency generative adversarial network. In: CVPR (2018)

45. Zhang, Z., Yang, L., Zheng, Y.: 利用循环与形状一致性生成对抗网络进行多模态医学体积的翻译与分割。发表于:CVPR (2018)

46. Zhao, Z., Zhang, Y., Wu, C., Zhang, X., et al.: One model to rule them all: Towards universal segmentation for medical images with text prompts. arXiv preprint arXiv:2312.17183 (2023)

46. Zhao, Z., Zhang, Y., Wu, C., Zhang, X., 等:一模型统治所有:面向带文本提示的医学图像通用分割。arXiv预印本 arXiv:2312.17183 (2023)

47. Zhuang, X., Li, L., Payer, C., Stern, D., et al.: Evaluation of algorithms for multimodality whole heart segmentation: an open-access grand challenge. MedIA (2019)

47. Zhuang, X., Li, L., Payer, C., Stern, D., 等:多模态全心脏分割算法评估:一个开放访问的大挑战。MedIA (2019)

## A Organ-wise segmentation results

## A 按器官分割结果

For additional analysis, we also provide organ-wise segmentation results of the comparative models across the multi-class datasets used in this study. We show these results using box plots in Figure 2 for abdominal CT, Figure 3 for abdominal MR, and Figure 4 for the cardiac datasets.

为了进一步分析，我们还提供了本研究中使用的多类别数据集上各比较模型的按器官分割结果。我们在图2中以箱线图形式展示了腹部CT数据集的结果，图3为腹部MR数据集，图4为心脏数据集。

From the figures, we observe that for certain organs like liver, kidneys and spleen, the segmentation performance across foundational models is more reliable (both in-domain and out-of-domain) compared to other structures (duodenum or adrenal glands). Notably, the training set of models like FSEFT [39] or SegVol [13] also comprised several organ-specific datasets, such as the Medical Segmentation Decathlon datasets with liver, pancreas and spleen segmentation tasks [1], Liver Tumor Segmentation (LiTS'17) [3], Kidney Tumor Segmentation (KiTS'19, KiTS'23) [17,18], among others. We hypothesize that the superior performance of models on these anatomical structures is due to their higher frequency of occurrence in their respective training corpora.

从图中可以观察到，对于肝脏、肾脏和脾脏等某些器官，基础模型的分割性能(包括域内和域外)较其他结构(如十二指肠或肾上腺)更为稳定。值得注意的是，诸如FSEFT [39]或SegVol [13]等模型的训练集也包含多个器官特定数据集，如包含肝脏、胰腺和脾脏分割任务的Medical Segmentation Decathlon数据集 [1]，肝肿瘤分割(LiTS'17)[3]，肾肿瘤分割(KiTS'19, KiTS'23)[17,18]等。我们推测模型在这些解剖结构上的优异表现，源于它们在各自训练语料中的高频出现。

![bo_d1c3stf7aajc7389qf5g_12_274_320_1247_1733_0.jpg](images/bo_d1c3stf7aajc7389qf5g_12_274_320_1247_1733_0.jpg)

Fig. 2: Box plots for organ-wise dice scores for all comparative models on the abdominal CT datasets used in this study.

图2:本研究中所有比较模型在腹部CT数据集上的按器官Dice系数箱线图。

![bo_d1c3stf7aajc7389qf5g_13_271_525_1252_1144_0.jpg](images/bo_d1c3stf7aajc7389qf5g_13_271_525_1252_1144_0.jpg)

Fig. 3: Box plots for organ-wise dice scores for all comparative models on the abdominal MR datasets used in this study.

图3:本研究中所有比较模型在腹部MR数据集上的按器官Dice系数箱线图。

![bo_d1c3stf7aajc7389qf5g_14_273_518_1248_1149_0.jpg](images/bo_d1c3stf7aajc7389qf5g_14_273_518_1248_1149_0.jpg)

Fig. 4: Box plots for organ-wise dice scores for all comparative models on the cardiac datasets used in this study.

图4:本研究中所有比较模型在心脏数据集上的按器官Dice系数箱线图。

