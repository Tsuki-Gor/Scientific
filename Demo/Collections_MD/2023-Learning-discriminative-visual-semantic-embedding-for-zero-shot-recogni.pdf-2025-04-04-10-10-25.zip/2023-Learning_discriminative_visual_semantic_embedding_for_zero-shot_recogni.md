IMAGE

# Learning discriminative visual semantic embedding for zero-shot recognition

# 用于零样本识别的判别式视觉语义嵌入学习

Yurui Xie ${}^{a, * }$ , Tiecheng Song ${}^{b}$ , Jianying Yuan ${}^{a}$

谢宇锐 ${}^{a, * }$ ，宋铁城 ${}^{b}$ ，袁建英 ${}^{a}$

${}^{a}$ School of Control Engineering, Chengdu University of Information Technology, Chengdu 610225, China

${}^{a}$ 成都信息工程大学控制工程学院，四川 成都 610225

${}^{b}$ School of Communication and Information Engineering, Chongqing University of Posts and Telecommunications, Chongqing 400065, China

${}^{b}$ 重庆邮电大学通信与信息工程学院，重庆 400065

## ARTICLEINFO

## 文章信息

Keywords:

关键词:

Zero-shot learning

零样本学习

Manually defined attributes

人工定义属性

Visual attributes

视觉属性

Semantic embedding space

语义嵌入空间

## A B S T R A C T

## 摘要

We present a novel zero-shot learning (ZSL) method that concentrates on strengthening the discriminative visual information of the semantic embedding space for recognizing object classes. To address the ZSL problem, many previous works strive to learn a transformation to bridge the visual features and semantic representations, while ignoring that the discriminative property of the semantic embedding space can benefit zero-shot prediction tasks. Among these existing approaches, human-defined attributes are typically employed to build up the mid-level semantics. However, the discriminative capability and completeness of manually defined attributes are hard to guarantee, which may easily cause semantic ambiguity. To alleviate this issue, we propose a discriminative visual semantic embedding (DVSE) model that formulates the ZSL problem as a supervised dictionary learning framework. The proposed method is capable of exploring a set of discriminative visual attributes and ensures knowledge transfer across categories. Moreover, a unified objective is introduced to generate an augmented semantic embedding space where these learned visual attributes and human-defined attributes are incorporated jointly for consolidating the visual cues of feature representations. Finally, we treat the DVSE model as an optimization problem and further propose an iterative solver. Extensive experiments on several challenging benchmark datasets demonstrate that the proposed method achieves favorable performances compared with state-of-the-art ZSL approaches.

我们提出了一种新颖的零样本学习(ZSL)方法，该方法专注于增强语义嵌入空间的判别性视觉信息，以识别目标类别。为了解决零样本学习问题，许多先前的工作致力于学习一种变换，以弥合视觉特征和语义表示之间的差距，而忽略了语义嵌入空间的判别特性可以有益于零样本预测任务。在这些现有方法中，通常使用人工定义的属性来构建中层语义。然而，人工定义属性的判别能力和完整性难以保证，这可能容易导致语义歧义。为了缓解这个问题，我们提出了一种判别式视觉语义嵌入(DVSE)模型，该模型将零样本学习问题表述为一个有监督的字典学习框架。所提出的方法能够探索一组判别性视觉属性，并确保跨类别的知识迁移。此外，引入了一个统一的目标，以生成一个增强的语义嵌入空间，其中将这些学习到的视觉属性和人工定义的属性联合起来，以巩固特征表示的视觉线索。最后，我们将DVSE模型视为一个优化问题，并进一步提出了一个迭代求解器。在几个具有挑战性的基准数据集上的大量实验表明，与现有最先进的零样本学习方法相比，所提出的方法取得了良好的性能。

## 1. Introduction

## 1. 引言

There have been tremendous strides in visual recognition over the past few years owing to the prosperity of deep learning [1-6]. Despite the remarkable advances, state-of-the-art approaches in deep learning require a large quantity of annotated training samples. This premise is usually unavailable in real-world scenarios due to the costly annotation efforts. Meanwhile, with the ever-growing number of newly defined classes, the object classes may follow a long-tailed distribution [7,8] such that some of the common objects have sufficient training samples while the others have few or even no training data. For this reason, it is infeasible to train a model to cover all the object classes. To handle this problem, zero-shot learning (ZSL) has recently emerged as a feasible solution.

由于深度学习的蓬勃发展，过去几年中视觉识别取得了巨大的进展 [1 - 6]。尽管取得了显著的进步，但深度学习中的现有最先进方法需要大量带注释的训练样本。由于注释工作成本高昂，这一前提在现实场景中通常无法满足。同时，随着新定义类别的数量不断增加，目标类别可能遵循长尾分布 [7, 8]，使得一些常见目标有足够的训练样本，而其他目标则只有很少甚至没有训练数据。因此，训练一个模型来覆盖所有目标类别是不可行的。为了解决这个问题，零样本学习(ZSL)最近成为了一种可行的解决方案。

The goal of zero-shot learning is to predict target classes where no annotated image from these types of classes is available. In fact, ZSL is inspired by the cognitive mechanism of humans in transferring learned knowledge for recognizing unseen objects. For instance, it is easy for a human to identify a new species of animal when only telling us what it looks like or how different the appearances of this animal class and others are. A reasonable explanation is that there exists some mid-level semantic knowledge across classes in the human cognitive process that can help us recognize novel objects via knowledge transfer. ZSL imitates the valuable property of our learning behavior and thus it avoids the collection of a large quantity of well-labeled samples for model training, which improves the expansibility of the visual recognition system. As for mid-level knowledge in ZSL, we also call it semantic embedding space that is typically built up via manually defined attributes [9-12] or wordvector [13-16] in existing ZSL approaches. Although human-defined semantics supports transferability knowledge for predicting unseen classes, few works get a deeper insight into whether it has enough discriminative capabilities that alleviate semantic ambiguity.

零样本学习的目标是预测没有这些类别带注释图像的目标类别。实际上，零样本学习的灵感来自人类在识别未见目标时转移所学知识的认知机制。例如，当只告诉我们一种新动物的外观或该动物类别与其他类别外观的差异时，人类很容易识别出这种新动物。一个合理的解释是，在人类认知过程中，跨类别存在一些中层语义知识，这些知识可以通过知识转移帮助我们识别新目标。零样本学习模仿了我们学习行为的这一宝贵特性，从而避免了为模型训练收集大量标注良好的样本，提高了视觉识别系统的可扩展性。对于零样本学习中的中层知识，我们也称之为语义嵌入空间，在现有的零样本学习方法中，它通常是通过人工定义的属性 [9 - 12] 或词向量 [13 - 16] 来构建的。尽管人工定义的语义为预测未见类别提供了可转移的知识，但很少有工作深入研究它是否具有足够的判别能力来缓解语义歧义。

In this paper, our study focuses on consolidating the discriminative information of the semantic embedding space and formulates ZSL as a dictionary learning optimization problem. The motivation of this work aims to overcome the following drawbacks of artificial attributes as Fig. 1 shows. First, current zero-shot learning approaches concentrate on leveraging the manually designed attributes to learn an alignment between visual features and attribute vectors. While the artificial attributes are semantically descriptive, it is difficult to ensure the discriminative capability of feature representations for recognition tasks. For example, animals 'zebra', 'antelope' and 'cow' have the same attribute stripes, even though they have significant differences in appearance. Besides, some of the manually defined attributes such as active, solitary, smelly and etc, cause a man-made gap where these attributes provide few visual cues to learn. Another potential drawback is that a vocabulary formed by the artificial attributes is essentially under-complete, which further constrains the descriptive capability of the semantic embedding space.

在本文中，我们的研究重点是巩固语义嵌入空间的判别信息，并将零样本学习表述为一个字典学习优化问题。这项工作的动机旨在克服如图1所示的人工属性的以下缺点。首先，当前的零样本学习方法专注于利用人工设计的属性来学习视觉特征和属性向量之间的对齐。虽然人工属性具有语义描述性，但很难确保特征表示在识别任务中的判别能力。例如，动物“斑马”、“羚羊”和“牛”都有相同的属性“条纹”，尽管它们在外观上有显著差异。此外，一些人工定义的属性，如“活跃”、“独居”、“有臭味”等，造成了人为的差距，因为这些属性提供的视觉线索很少。另一个潜在的缺点是，由人工属性形成的词汇本质上是不完整的，这进一步限制了语义嵌入空间的描述能力。

---

* Correspondence to: School of Control Engineering, Chengdu University of Information Technology, Xuefu Road 24, Chengdu, 610225, China.

* 通信地址:中国成都学府路24号成都信息工程大学控制工程学院，邮编610225。

E-mail addresses: xieyurui@cuit.edu.cn (Y. Xie), songtc@cqupt.edu.cn (T. Song), yuanjy@cuit.edu.cn (J. Yuan).

电子邮箱地址:xieyurui@cuit.edu.cn(谢Y.)，songtc@cqupt.edu.cn(宋T.)，yuanjy@cuit.edu.cn(袁J.)。

---

![0195da39-8010-7dd8-a310-a27a9d32cb75_1_126_154_700_533_0.jpg](images/0195da39-8010-7dd8-a310-a27a9d32cb75_1_126_154_700_533_0.jpg)

Fig. 1. The drawbacks of artificial attributes. First, the visual cues from artificial attributes lack class-specific discriminative knowledge for recognition tasks. For example, these same attributes 'tail', 'stripes', 'white' etc. are usually shared across different object classes. Besides, it is hard to link some attributes marked as dashed ellipses to image features due to few correlations between these attributes and the visual information.

图1. 人工属性的缺点。首先，人工属性的视觉线索缺乏用于识别任务的特定类别的判别知识。例如，“尾巴”“条纹”“白色”等相同属性通常在不同的对象类别中共享。此外，由于这些属性与视觉信息之间的相关性很少，很难将一些用虚线椭圆标记的属性与图像特征联系起来。

In order to address the above inherent problems, a novel zero-shot learning method is introduced to enrich the semantic information of feature representations. To be exact, we propose a discriminative visual semantic embedding (DVSE) model to exploit potential visual attributes via a supervised dictionary learning formulation. Furthermore, a unified feature representation objective is introduced to jointly incorporate the learned visual attributes and human-defined attributes for generating an augmented semantic embedding space, thus improving the discriminative power for representing features. Fig. 2 illustrates the conceptual diagram of the proposed method. The main contributions of this work are highlighted as follows: (1) A discriminative visual semantic embedding (DVSE) model is presented to formulate the ZSL problem as a supervised dictionary learning framework. Unlike most of the existing ZSL methods that are limited by the manually defined attributes, the valuable merit of DVSE is capable of discovering discriminative visual attributes and facilitating to strengthen the semantically descriptive power of the embedding space. (2) Discriminative visual attributes are explicitly incorporated into the learning process of feature representations together with artificial attributes via a unified optimization objective and hence enrich the visual cues for recognition tasks. (3) We deduce an iterative algorithm to achieve the solution of DVSE, and the extensive experimental results conducted on benchmark datasets demonstrate that the proposed method achieves favorable performances compared with state-of-the-art ZSL approaches.

为了解决上述固有问题，引入了一种新颖的零样本学习方法来丰富特征表示的语义信息。确切地说，我们提出了一种判别式视觉语义嵌入(DVSE)模型，通过有监督的字典学习公式来挖掘潜在的视觉属性。此外，引入了一个统一的特征表示目标，将学习到的视觉属性和人工定义的属性结合起来，以生成一个增强的语义嵌入空间，从而提高特征表示的判别能力。图2展示了所提出方法的概念图。这项工作的主要贡献如下:(1)提出了一种判别式视觉语义嵌入(DVSE)模型，将零样本学习(ZSL)问题表述为一个有监督的字典学习框架。与大多数现有的受限于人工定义属性的ZSL方法不同，DVSE的宝贵优点是能够发现具有判别性的视觉属性，并有助于增强嵌入空间的语义描述能力。(2)通过一个统一的优化目标，将具有判别性的视觉属性与人工属性明确地纳入特征表示的学习过程中，从而丰富了识别任务的视觉线索。(3)我们推导了一种迭代算法来求解DVSE，在基准数据集上进行的大量实验结果表明，与最先进的ZSL方法相比，所提出的方法取得了良好的性能。

The rest of this paper is organized as follows. Section 2 briefly reviews the related works in ZSL. The proposed DVSE model is introduced in Section 3. Then, Section 4 demonstrates the optimization algorithm for DVSE. Experimental results are given in Section 5. Finally, we conclude this paper in Section 6.

本文的其余部分组织如下。第2节简要回顾了ZSL领域的相关工作。第3节介绍了所提出的DVSE模型。然后，第4节展示了DVSE的优化算法。第5节给出了实验结果。最后，我们在第6节对本文进行总结。

## 2. Related work

## 2. 相关工作

Semantic information plays a critical role in the zero-shot learning (ZSL) problem. It builds up the secondary representations of visual features and further ensures knowledge transfer from seen to unseen classes for ZSL recognition tasks. Recently, attributes [9-12,17,18] and word vectors [13-16] are two popular manners to provide semantics. Attributes typically reflect mid-level visual properties (e.g., color, shape, texture and etc.) which are the most commonly used in ZSL. Once the attribute ontology is defined, attribute vectors also called the class prototypes can be generated to describe different classes. Similar to attributes, word vectors are collected from a large text corpus and provide an alternative way to link visual features and class labels. However, the above manually defined knowledge usually derives from our intuitions that probably still exists a large gap between the visual space and semantic embedding space. This means that the quality of human-defined knowledge is hard to guarantee in terms of discriminativeness and completeness. To address this problem, we propose to explore potential visual attributes to enhance the descriptive capability of the semantic embedding space.

语义信息在零样本学习(ZSL)问题中起着关键作用。它构建了视觉特征的二次表示，并进一步确保了ZSL识别任务中从已见类别到未见类别的知识迁移。最近，属性[9 - 12,17,18]和词向量[13 - 16]是两种流行的提供语义的方式。属性通常反映中级视觉属性(例如，颜色、形状、纹理等)，这在ZSL中是最常用的。一旦定义了属性本体，就可以生成属性向量(也称为类原型)来描述不同的类别。与属性类似，词向量是从大型文本语料库中收集的，为连接视觉特征和类别标签提供了另一种方式。然而，上述人工定义的知识通常源于我们的直觉，这可能导致视觉空间和语义嵌入空间之间仍然存在很大差距。这意味着人工定义知识的判别性和完整性在质量上很难保证。为了解决这个问题，我们建议探索潜在的视觉属性，以增强语义嵌入空间的描述能力。

The pioneering work [19] of ZSL targets learning different attribute classifiers in an intuitive manner and then recognizes the test instance by comparing its generated attribute vector with the descriptions of unseen classes. However, since each attribute classifier is trained independently, the relations among attributes are not exploited for representing an image. In order to alleviate this issue, recent advances of ZSL try to seek a common semantic embedding space where all the attributes are considered as a whole to bridge the gap between visual space and label space. Along this research line, Akata et al. [10,20] use a compatibility function with bilinear form to map visual features into attribute vectors. Following this framework, [21] incorporates multiple linear projections to better model the mapping relations. More recently, Kodirov et al. [11] develop a shallow encoder-decoder model combined with a reconstruction penalty to project visual features into the semantic space. Ding et al. [22] integrate a low-rank constraint to highlight shared attributes among classes via a dictionary learning framework. [23] further utilizes a graph structure with a feature encoder to tackle the domain shift issue. Jie et al. [24] extend the sparse coding [25] formulation to learn residual attributes in order to compensate for reconstruction errors caused by defined attributes. Li et al. [26] propose to adjust the primary class prototypes for improving the accuracy of class descriptions. Meanwhile, some studies of ZSL attempt to learn complicated projection functions. For example, Cacheux et al. [27] apply a triplet loss to model a robust mapping between image features and attribute vectors, which benefits mitigating the confusion of similar classes in ZSL recognition. Zhang et al. [28] utilize kernel function to learn a non-linear mapping from the visual space to semantic embedding space. Our work belongs to the same line of visual-semantic alignment, and yet we focus on exploring discriminative visual attributes in order to generate an augmented semantic embedding space where visual attributes and human-defined attributes are jointly incorporated into the learning of feature representations.

零样本学习(ZSL)的开创性工作[19]旨在以直观的方式学习不同的属性分类器，然后通过将生成的属性向量与未见类别的描述进行比较来识别测试实例。然而，由于每个属性分类器是独立训练的，因此未利用属性之间的关系来表示图像。为了缓解这一问题，ZSL的最新进展试图寻找一个共同的语义嵌入空间，在该空间中，所有属性被视为一个整体，以弥合视觉空间和标签空间之间的差距。沿着这一研究方向，Akata等人[10,20]使用具有双线性形式的兼容性函数将视觉特征映射到属性向量。在这个框架下，文献[21]结合了多个线性投影，以更好地建模映射关系。最近，Kodirov等人[11]开发了一种浅层编码器 - 解码器模型，并结合重建惩罚项，将视觉特征投影到语义空间。Ding等人[22]通过字典学习框架引入低秩约束，以突出类别之间的共享属性。文献[23]进一步利用带有特征编码器的图结构来解决领域偏移问题。Jie等人[24]扩展了稀疏编码[25]公式，以学习残差属性，从而补偿由定义属性引起的重建误差。Li等人[26]提出调整主要类别原型，以提高类别描述的准确性。同时，一些ZSL研究试图学习复杂的投影函数。例如，Cacheux等人[27]应用三元组损失来建模图像特征和属性向量之间的鲁棒映射，这有助于减轻ZSL识别中相似类别的混淆。Zhang等人[28]利用核函数学习从视觉空间到语义嵌入空间的非线性映射。我们的工作属于相同的视觉 - 语义对齐研究方向，但我们专注于探索具有判别性的视觉属性，以生成一个增强的语义嵌入空间，在该空间中，视觉属性和人为定义的属性共同融入特征表示的学习中。

Moreover, there are some other works that try to handle the ZSL problem from different perspectives. One main direction is to synthesize visual samples of unseen classes and then reduce ZSL to a conventional classification problem $\left\lbrack  {{12},{17},{29}}\right\rbrack$ . To be specific, Guo et al. [29] assume a Gaussian distribution for each unseen class which is estimated by the similarities of class attributes. In this method, visual samples are synthesized by random sampling from the probability densities of unseen classes. Recently, $\left\lbrack  {{30},{31}}\right\rbrack$ formulate the feature synthesis problem into a variational autoencoder (VAE) framework based on the given semantic embedding. The performance of ZSL largely relies on the reliable estimation of the class distribution. Besides, [12, 17,32] are built on the generative adversarial networks (GANs) [33] that learn a feature generator along with a discriminator in an adversarial manner. Although GAN-based models show satisfactory results, it is notoriously difficult to train [34]. Apart from feature synthesis approaches, Biswas et al. [35] propose to learn the inverse mapping from the semantic space to visual space using an encoder-decoder network, which helps in preserving the correlations of different classes. Tong et al. [36] propose to factorize an image feature into different components where more generalizable feature representations can be transferred to unseen classes. [37] develops multiple modular networks to decouple the intrinsic compositionality of the label space. It is shown effective for the problem of compositional zero-shot classification tasks.

此外，还有一些其他工作试图从不同角度处理ZSL问题。一个主要方向是合成未见类别的视觉样本，然后将ZSL问题转化为传统的分类问题$\left\lbrack  {{12},{17},{29}}\right\rbrack$。具体来说，Guo等人[29]假设每个未见类别服从高斯分布，该分布通过类别属性的相似度进行估计。在这种方法中，通过从未见类别的概率密度中随机采样来合成视觉样本。最近，文献$\left\lbrack  {{30},{31}}\right\rbrack$基于给定的语义嵌入，将特征合成问题表述为变分自编码器(VAE)框架。ZSL的性能在很大程度上依赖于对类别分布的可靠估计。此外，文献[12, 17,32]基于生成对抗网络(GANs)[33]构建，该网络以对抗的方式学习一个特征生成器和一个判别器。尽管基于GAN的模型显示出令人满意的结果，但众所周知，其训练难度较大[34]。除了特征合成方法之外，Biswas等人[35]提出使用编码器 - 解码器网络学习从语义空间到视觉空间的逆映射，这有助于保留不同类别之间的相关性。Tong等人[36]提出将图像特征分解为不同的组件，以便将更具泛化性的特征表示迁移到未见类别。文献[37]开发了多个模块化网络，以解耦标签空间的内在组合性。结果表明，该方法对组合式零样本分类任务问题是有效的。

![0195da39-8010-7dd8-a310-a27a9d32cb75_2_214_151_1309_571_0.jpg](images/0195da39-8010-7dd8-a310-a27a9d32cb75_2_214_151_1309_571_0.jpg)

Fig. 2. Demonstration of the discriminative visual semantic embedding (DVSE) method that jointly utilizes these learned visual attributes and artificial attributes to generate an augmented semantic embedding space. Hence, discriminative image representations can be encoded from it for zero-shot recognition tasks.

图2. 判别性视觉语义嵌入(DVSE)方法的演示，该方法联合利用这些学习到的视觉属性和人工属性来生成一个增强的语义嵌入空间。因此，可以从中编码出具有判别性的图像表示，用于零样本识别任务。

### 3.The proposed method

### 3. 所提出的方法

In this section, we introduce the proposed discriminative visual semantic embedding (DVSE) model to explore a set of discriminative visual attributes and further incorporate them into an optimization objective of the feature representation. Moreover, an iterative algorithm is deduced to obtain the solution of DVSE in the next section. Here, we first demonstrate the problem formulation of zero-shot learning.

在本节中，我们介绍所提出的判别性视觉语义嵌入(DVSE)模型，以探索一组具有判别性的视觉属性，并将其进一步纳入特征表示的优化目标中。此外，在下一节中，我们将推导一种迭代算法来求解DVSE。在这里，我们首先阐述零样本学习的问题表述。

### 3.1. Problem formulation

### 3.1. 问题表述

In ZSL $\left\lbrack  {{21},{38},{39}}\right\rbrack$ recognition tasks, the dataset is divided into ${C}_{s}$ seen classes in source domain $S = \left\{  {{F}_{s},{A}_{s},{L}_{s}}\right\}$ and ${C}_{u}$ unseen classes taken as the target domain $T = \left\{  {{F}_{t},{A}_{t},{L}_{t}}\right\}$ , consisting of sample features $F$ , semantic representations $A$ that typically are generated by attributes $\left\lbrack  {9 - {11},{17}}\right\rbrack$ or word vectors $\left\lbrack  {{13},{14}}\right\rbrack$ , and class labels $L$ for source and target domains, respectively. More specifically, a $d$ -dimension visual feature is extracted for each sample, thus we can obtain feature matrices ${F}_{s} = \left\lbrack  {{f}_{1},{f}_{2},\ldots ,{f}_{{n}_{s}}}\right\rbrack   \in  {\mathbf{R}}^{d \times  {n}_{s}}$ and ${F}_{t} =$ $\left\lbrack  {{f}_{1},{f}_{2},\ldots ,{f}_{{n}_{u}}}\right\rbrack   \in  {\mathbf{R}}^{d \times  {n}_{u}}$ , where ${n}_{s},{n}_{u}$ denote the number of samples in the seen and unseen classes. ${A}_{s} \in  {\mathbf{R}}^{m \times  {n}_{s}}$ and ${A}_{t} \in  {\mathbf{R}}^{m \times  {n}_{u}}$ are the $m$ -dimension semantic representations from seen and unseen classes respectively, where $m$ is the number of human-defined attributes. As for class labels, it is noticed that the label spaces of seen and unseen classes are disjoint: ${L}_{s} \cap  {L}_{t} = \varnothing$ . Given the training data $S = \left\{  {{F}_{s},{A}_{s},{L}_{s}}\right\}$ from the source domain, the goal of ZSL is to learn a classifier to predict semantic representations of samples from the target domain $\Psi  : {F}_{t} \rightarrow  {A}_{t}$ , then the class label of each test sample can be assigned naturally using the class prototypes of unseen classes. Recently, traditional zero-shot learning is expanded to the generalized ZSL problem (GZSL) [38] where samples from seen and unseen classes are both considered in the test time. Since the search space of the class label is not restricted to the unseen classes, it brings us a challenge that a more general classifier ${\Psi }_{GZSL} : F \rightarrow  A$ should be learned in the GZSL setting.

在零样本学习(Zero-Shot Learning，ZSL)$\left\lbrack  {{21},{38},{39}}\right\rbrack$识别任务中，数据集被划分为源域$S = \left\{  {{F}_{s},{A}_{s},{L}_{s}}\right\}$中的${C}_{s}$个已见类别(seen classes)和作为目标域$T = \left\{  {{F}_{t},{A}_{t},{L}_{t}}\right\}$的${C}_{u}$个未见类别(unseen classes)，分别包含样本特征$F$、通常由属性$\left\lbrack  {9 - {11},{17}}\right\rbrack$或词向量$\left\lbrack  {{13},{14}}\right\rbrack$生成的语义表示$A$，以及源域和目标域的类别标签$L$。更具体地说，为每个样本提取一个$d$维的视觉特征，因此我们可以得到特征矩阵${F}_{s} = \left\lbrack  {{f}_{1},{f}_{2},\ldots ,{f}_{{n}_{s}}}\right\rbrack   \in  {\mathbf{R}}^{d \times  {n}_{s}}$和${F}_{t} =$ $\left\lbrack  {{f}_{1},{f}_{2},\ldots ,{f}_{{n}_{u}}}\right\rbrack   \in  {\mathbf{R}}^{d \times  {n}_{u}}$，其中${n}_{s},{n}_{u}$分别表示已见类别和未见类别中的样本数量。${A}_{s} \in  {\mathbf{R}}^{m \times  {n}_{s}}$和${A}_{t} \in  {\mathbf{R}}^{m \times  {n}_{u}}$分别是来自已见类别和未见类别的$m$维语义表示，其中$m$是人为定义的属性数量。至于类别标签，需要注意的是，已见类别和未见类别的标签空间是不相交的:${L}_{s} \cap  {L}_{t} = \varnothing$。给定来自源域的训练数据$S = \left\{  {{F}_{s},{A}_{s},{L}_{s}}\right\}$，零样本学习的目标是学习一个分类器来预测来自目标域$\Psi  : {F}_{t} \rightarrow  {A}_{t}$的样本的语义表示，然后可以使用未见类别的类别原型自然地为每个测试样本分配类别标签。最近，传统的零样本学习扩展到了广义零样本学习问题(Generalized Zero-Shot Learning，GZSL)[38]，在测试时同时考虑来自已见类别和未见类别的样本。由于类别标签的搜索空间不限于未见类别，这给我们带来了一个挑战，即在广义零样本学习设置中应该学习一个更通用的分类器${\Psi }_{GZSL} : F \rightarrow  A$。

### 3.2. Zero-shot learning with discriminative visual semantic embedding (DVSE)

### 3.2. 具有判别性视觉语义嵌入(Discriminative Visual Semantic Embedding，DVSE)的零样本学习

## A. Feature projection with human-defined attributes

## A. 使用人为定义属性的特征投影

The key issue of zero-shot learning is to bridge the gap between the visual space and semantic embedding space. To achieve this, we first learn a visual-semantic alignment from seen classes by the manually defined attributes. Formally, the following objective is developed to calculate a transformation matrix in order to align visual features ${F}_{s}$ and semantic representations ${A}_{s}$ .

零样本学习的关键问题是弥合视觉空间和语义嵌入空间之间的差距。为了实现这一点，我们首先通过手动定义的属性从已见类别中学习视觉 - 语义对齐。形式上，开发以下目标来计算一个变换矩阵，以便对齐视觉特征${F}_{s}$和语义表示${A}_{s}$。

$$
\mathop{\min }\limits_{W}{\begin{Vmatrix}{A}_{s} - W{F}_{s}\end{Vmatrix}}_{F}^{2} \tag{1}
$$

where $\parallel  \cdot  {\parallel }_{F}^{2}$ is the Frobenius norm. ${A}_{s}$ denotes all the semantic representations of sample features ${F}_{s}$ using human-defined attributes, each column of the matrix ${A}_{s}$ associates with an attribute vector called class prototype that indicates which class this sample belongs to. $W \in$ ${\mathbf{R}}^{m \times  d}$ reveals the mapping relation between ${A}_{s}$ and ${F}_{s}$ . The Eq. (1) is essentially a standard least squares formulation and a closed-form solution can be obtained as.

其中$\parallel  \cdot  {\parallel }_{F}^{2}$是弗罗贝尼乌斯范数(Frobenius norm)。${A}_{s}$表示使用人为定义的属性对样本特征${F}_{s}$的所有语义表示，矩阵${A}_{s}$的每一列都与一个称为类别原型的属性向量相关联，该向量指示该样本属于哪个类别。$W \in$ ${\mathbf{R}}^{m \times  d}$揭示了${A}_{s}$和${F}_{s}$之间的映射关系。方程(1)本质上是一个标准的最小二乘法公式，可以得到一个封闭形式的解为。

$$
W = {A}_{s}{F}_{s}^{T} \cdot  {\left( {F}_{s}{F}_{s}^{T}\right) }^{-1} \tag{2}
$$

## B. Discriminative visual attributes learning

## B. 判别性视觉属性学习

Although human-defined attributes provide mid-level semantics to generate an embedding space that connects visual features and class labels, there exist two major drawbacks that limit the expansibility of current zero-shot learning. First, artificial attributes tend to describe different object classes using the sharing of semantic vocabulary. For this reason, class-specific knowledge cannot be substantially incorporated into the feature representations of an image, leading to semantic ambiguity for further recognition tasks. Besides, it is hard to say that these artificially designed attributes can cover diverse appearance changes in object classes, which means the completeness of the semantic embedding space is difficult to guarantee. Therefore, the above issues motivate us to develop a new way that is able to explore discriminative visual attributes for consolidating the semantically descriptive capability of the embedding space. Concretely, we propose a discriminative visual semantic embedding (DVSE) method to cast the ZSL problem into a supervised dictionary learning framework. The objective of discriminative visual attributes learning is defined as:

尽管人为定义的属性为生成连接视觉特征和类别标签的嵌入空间提供了中层语义，但目前的零样本学习存在两个主要缺点，限制了其可扩展性。首先，人工属性倾向于使用共享的语义词汇来描述不同的对象类别。因此，特定类别的知识无法充分融入图像的特征表示中，从而导致后续识别任务出现语义模糊。此外，很难说这些人工设计的属性能够涵盖对象类别中多样的外观变化，这意味着语义嵌入空间的完整性难以保证。因此，上述问题促使我们开发一种新方法，能够探索具有判别性的视觉属性，以增强嵌入空间的语义描述能力。具体而言，我们提出了一种判别性视觉语义嵌入(Discriminative Visual Semantic Embedding，DVSE)方法，将零样本学习(Zero-Shot Learning，ZSL)问题转化为有监督的字典学习框架。判别性视觉属性学习的目标定义如下:

$$
\mathop{\min }\limits_{{D, Y, K, Z}}{\begin{Vmatrix}{F}_{s} - DY\end{Vmatrix}}_{F}^{2} + \alpha {\begin{Vmatrix}{A}_{s} - KY\end{Vmatrix}}_{F}^{2} + \beta \parallel P - {ZY}{\parallel }_{F}^{2} \tag{3}
$$

$$
+ {\lambda }_{1}\parallel K{\parallel }_{F}^{2} + {\lambda }_{2}\parallel Z{\parallel }_{F}^{2}
$$

Reconstruction Residual Term: In the above model, the first term ${\begin{Vmatrix}{F}_{s} - DY\end{Vmatrix}}_{F}^{2}$ is the reconstruction residual over the learned visual attributes, where ${F}_{s}$ is the sample features from seen classes, $D \in$ ${\mathbf{R}}^{d \times  N}$ is a visual dictionary that aims to discover discriminative visual attributes, and $N$ denotes the number of learned visual attributes. $Y \in$ ${\mathbf{R}}^{N \times  {n}_{s}}$ is the reconstruction coefficients of sample features ${F}_{s}$ on the dictionary $D$ . The Eq. (3) minimizes this reconstruction residual term to collaboratively explore potential visual attributes and build a link between the image features ${F}_{s}$ and these learned attributes.

重建残差项:在上述模型中，第一项${\begin{Vmatrix}{F}_{s} - DY\end{Vmatrix}}_{F}^{2}$是学习到的视觉属性上的重建残差，其中${F}_{s}$是来自已见类别的样本特征，$D \in$ ${\mathbf{R}}^{d \times  N}$是一个旨在发现判别性视觉属性的视觉字典，$N$表示学习到的视觉属性的数量。$Y \in$ ${\mathbf{R}}^{N \times  {n}_{s}}$是样本特征${F}_{s}$在字典$D$上的重建系数。公式(3)最小化这个重建残差项，以协同探索潜在的视觉属性，并在图像特征${F}_{s}$和这些学习到的属性之间建立联系。

Consistency Constraint: The second term ${\begin{Vmatrix}{A}_{s} - KY\end{Vmatrix}}_{F}^{2}$ of Eq. (3) is a consistency constraint between the semantic representations ${A}_{s}$ and reconstruction coefficients $Y$ , where $K \in  {\mathbf{R}}^{m \times  N}$ denotes a linear transformation matrix that reflects their differences, $m$ denotes the number of human-defined attributes. This term leverages the knowledge from human-defined attributes to guide the learning procedure of discriminative visual attributes and ensures the affinity between them. Besides, the regularizer $\parallel K{\parallel }_{F}^{2}$ is used to avoid trivial solutions.

一致性约束:公式(3)的第二项${\begin{Vmatrix}{A}_{s} - KY\end{Vmatrix}}_{F}^{2}$是语义表示${A}_{s}$和重建系数$Y$之间的一致性约束，其中$K \in  {\mathbf{R}}^{m \times  N}$表示反映它们差异的线性变换矩阵，$m$表示人为定义的属性的数量。这一项利用人为定义的属性知识来指导判别性视觉属性的学习过程，并确保它们之间的关联性。此外，正则化项$\parallel K{\parallel }_{F}^{2}$用于避免平凡解。

Classification Loss: In order to enrich the discriminative capability of visual attributes, a classification loss is incorporated into the learning objective. Inspired by [40-42], we employ a linear classifier with zero bias $\Phi \left( {Y, Z, b}\right)  = {ZY} + b, b = 0$ to encode the reconstruction coefficients $Y$ into predictive class labels, where $Z \in  {\mathbf{R}}^{\left| {L}_{s}\right|  \times  N}$ and $b$ are the classifier parameters, and $\left| {L}_{s}\right|$ denotes the number of classes from seen classes. The minimization of $\parallel P - {ZY}{\parallel }_{F}^{2}$ is to reinforce the class-specific discriminative semantics for potential visual attributes. Here, $P \in  {\mathbf{R}}^{\left| {L}_{s}\right|  \times  {n}_{s}}$ is a label matrix that the index of non-zero entry of each column ${p}_{i} = \{ 0,0,1,\ldots ,0\}$ indicates the class of the $i$ th sample, and the last term $\parallel Z{\parallel }_{F}^{2}$ is a regularization penalty on classifier parameters. In addition, $\alpha ,\beta ,{\lambda }_{1}$ and ${\lambda }_{2}$ of Eq. (3) are the weighting parameters to trade-off different cost terms.

分类损失:为了增强视觉属性的判别能力，在学习目标中引入了分类损失。受文献[40 - 42]的启发，我们采用一个零偏置的线性分类器$\Phi \left( {Y, Z, b}\right)  = {ZY} + b, b = 0$将重建系数$Y$编码为预测的类别标签，其中$Z \in  {\mathbf{R}}^{\left| {L}_{s}\right|  \times  N}$和$b$是分类器参数，$\left| {L}_{s}\right|$表示已见类别的数量。最小化$\parallel P - {ZY}{\parallel }_{F}^{2}$是为了增强潜在视觉属性的特定类别判别语义。这里，$P \in  {\mathbf{R}}^{\left| {L}_{s}\right|  \times  {n}_{s}}$是一个标签矩阵，每一列${p}_{i} = \{ 0,0,1,\ldots ,0\}$的非零元素索引表示第$i$个样本的类别，最后一项$\parallel Z{\parallel }_{F}^{2}$是对分类器参数的正则化惩罚。此外，公式(3)中的$\alpha ,\beta ,{\lambda }_{1}$和${\lambda }_{2}$是权衡不同代价项的权重参数。

### 3.3. Recognition via augmented semantic embedding space

### 3.3. 通过增强的语义嵌入空间进行识别

In a zero-shot learning scenario, we need to predict the class label of a test sample that comes from seen/unseen classes. In order to strengthen the discriminative capability of semantic representations, a unified optimization objective is proposed to generate an augmented semantic embedding space that jointly assembles these learned visual attributes and human-defined attributes for representing image features. Mathematically, given the image feature ${f}_{i}$ of the $i$ th test sample, the learned visual-semantic alignment $W$ , transformation matrix $K$ and visual attribute set $D$ , the learning of the semantic representation ${a}_{i} \in  {\mathbf{R}}^{m \times  1}$ can be accomplished by solving the following problem:

在零样本学习场景中，我们需要预测来自已见/未见类别的测试样本的类别标签。为了增强语义表示的判别能力，我们提出了一个统一的优化目标，以生成一个增强的语义嵌入空间，该空间将这些学习到的视觉属性和人为定义的属性组合在一起，用于表示图像特征。从数学角度来看，给定第 $i$ 个测试样本的图像特征 ${f}_{i}$、学习到的视觉 - 语义对齐 $W$、变换矩阵 $K$ 和视觉属性集 $D$，语义表示 ${a}_{i} \in  {\mathbf{R}}^{m \times  1}$ 的学习可以通过解决以下问题来完成:

$$
\mathop{\min }\limits_{{{a}_{i},{y}_{i}}}{\begin{Vmatrix}{a}_{i} - W \cdot  {f}_{i}\end{Vmatrix}}_{F}^{2} + {\eta }_{1}{\begin{Vmatrix}{f}_{i} - D \cdot  {y}_{i}\end{Vmatrix}}_{F}^{2} + {\eta }_{2}{\begin{Vmatrix}{a}_{i} - K \cdot  {y}_{i}\end{Vmatrix}}_{F}^{2} \tag{4}
$$

where ${y}_{i} \in  {\mathbf{R}}^{N \times  1}$ is the reconstruction coefficients of the feature ${f}_{i}$ on the dictionary $D$ .

其中 ${y}_{i} \in  {\mathbf{R}}^{N \times  1}$ 是特征 ${f}_{i}$ 在字典 $D$ 上的重构系数。

In Eq. (4), the first term ${\begin{Vmatrix}{a}_{i} - W \cdot  {f}_{i}\end{Vmatrix}}_{F}^{2}$ is designed to map an image feature ${f}_{i}$ from the visual space to semantic embedding space. Furthermore, we incorporate the reconstruction residual ${\begin{Vmatrix}{f}_{i} - D \cdot  {y}_{i}\end{Vmatrix}}_{F}^{2}$ of the image feature ${f}_{i}$ over these learned visual attributes as guidance to produce an augmented embedding space that yields more descriptive semantic representations for ZSL tasks. Here, ${\begin{Vmatrix}{a}_{i} - K \cdot  {y}_{i}\end{Vmatrix}}_{F}^{2}$ is a consistency constraint between semantic representations ${a}_{i}$ and reconstruction coefficients ${y}_{i}$ as mentioned earlier. Overall, the minimization of the above terms in Eq. (4) encourages the model to reconstruct an image feature using these learned visual attributes and consolidates the discriminative capability of the semantic representation in a mutual boosting way. In other words, image features are projected into an augmented semantic embedding space by considering both these manually defined attributes and potential visual attributes, thereby facilitating to relieve semantic ambiguity for differentiating object classes.

在公式 (4) 中，第一项 ${\begin{Vmatrix}{a}_{i} - W \cdot  {f}_{i}\end{Vmatrix}}_{F}^{2}$ 旨在将图像特征 ${f}_{i}$ 从视觉空间映射到语义嵌入空间。此外，我们将图像特征 ${f}_{i}$ 在这些学习到的视觉属性上的重构残差 ${\begin{Vmatrix}{f}_{i} - D \cdot  {y}_{i}\end{Vmatrix}}_{F}^{2}$ 作为引导，以生成一个增强的嵌入空间，从而为零样本学习(ZSL)任务产生更具描述性的语义表示。这里，${\begin{Vmatrix}{a}_{i} - K \cdot  {y}_{i}\end{Vmatrix}}_{F}^{2}$ 是前面提到的语义表示 ${a}_{i}$ 和重构系数 ${y}_{i}$ 之间的一致性约束。总体而言，最小化公式 (4) 中的上述项促使模型使用这些学习到的视觉属性重构图像特征，并以相互促进的方式巩固语义表示的判别能力。换句话说，通过同时考虑这些手动定义的属性和潜在的视觉属性，将图像特征投影到一个增强的语义嵌入空间中，从而有助于缓解区分对象类别时的语义歧义。

Once we obtain the feature representation ${a}_{i}$ with the augmented semantic embedding space, the similarities between ${a}_{i}$ and each class prototype can be calculated. Therefore, the class label of a test sample is predicted by assigning its feature representation to one of the class prototypes using the nearest neighbor classifier. That is to say, the recognition can be carried out by transforming the visual feature of seen or unseen classes into an augmented semantic embedding space, where the nearest neighbor classifier is used to determine the object class in terms of the nearest distances of class prototypes against the feature representation ${a}_{i}$ .

一旦我们通过增强的语义嵌入空间获得特征表示 ${a}_{i}$，就可以计算 ${a}_{i}$ 与每个类别原型之间的相似度。因此，使用最近邻分类器将测试样本的特征表示分配给其中一个类别原型，从而预测测试样本的类别标签。也就是说，可以通过将已见或未见类别的视觉特征转换到增强的语义嵌入空间中来进行识别，在该空间中，使用最近邻分类器根据类别原型与特征表示 ${a}_{i}$ 的最近距离来确定对象类别。

## 4. Optimization

## 4. 优化

In this section, we develop an optimization algorithm for the solution of DVSE. At first, it is obvious that the objective of Eq. (3) is not convex with respect to all the variables $\{ D, Y, K, Z\}$ , but it is convex for each of them when the other variables are fixed. Therefore, an alternating algorithm is deduced to reformulate the minimization problem of Eq. (3) into multiple sub-problems as follows.

在本节中，我们开发了一种用于求解深度视觉语义嵌入(DVSE)的优化算法。首先，很明显公式 (3) 的目标函数关于所有变量 $\{ D, Y, K, Z\}$ 不是凸函数，但当其他变量固定时，对于每个变量而言它是凸函数。因此，我们推导出一种交替算法，将公式 (3) 的最小化问题重新表述为多个子问题，如下所示。

Updating $Y$ : Suppose that variables $\{ D, K, Z\}$ are fixed, we can update the reconstruction coefficients $Y$ . Since these terms that are independent of $Y$ can be removed from Eq. (3), the objective is reduced to the following problem:

更新 $Y$:假设变量 $\{ D, K, Z\}$ 是固定的，我们可以更新重构系数 $Y$。由于可以从公式 (3) 中移除与 $Y$ 无关的项，目标函数简化为以下问题:

$$
\mathop{\min }\limits_{Y}{\begin{Vmatrix}{F}_{s} - DY\end{Vmatrix}}_{F}^{2} + \alpha {\begin{Vmatrix}{A}_{s} - KY\end{Vmatrix}}_{F}^{2} + \beta \parallel P - {ZY}{\parallel }_{F}^{2} \tag{5}
$$

which can yield the closed-form solution

这可以得到闭式解

$$
Y = {\left( {D}^{T}D + \alpha {K}^{T}K + \beta {Z}^{T}Z\right) }^{-1}\left( {{D}^{T}{F}_{s} + \alpha {K}^{T}{A}_{s} + \beta {Z}^{T}P}\right)  \tag{6}
$$

Updating $D$ : When variables $\{ Y, K, Z\}$ are fixed, the visual dictionary $D$ is updated by solving the formulation as follows:

更新 $D$:当变量 $\{ Y, K, Z\}$ 固定时，通过求解以下公式来更新视觉字典 $D$:

$$
\mathop{\min }\limits_{D}{\begin{Vmatrix}{F}_{s} - DY\end{Vmatrix}}_{F}^{2} \tag{7}
$$

thus we obtain the updated $D$ as

因此，我们得到更新后的 $D$ 为

$$
D = {F}_{s}{Y}^{T}{\left( Y{Y}^{T}\right) }^{-1} \tag{8}
$$

Updating $K$ and $Z$ : To calculate the transformation matrix $K$ , the other variables are fixed. The objective of Eq. (3) is rewritten as:

更新 $K$ 和 $Z$:为了计算变换矩阵 $K$，固定其他变量。公式 (3) 的目标函数重写为:

$$
\mathop{\min }\limits_{K}\alpha {\begin{Vmatrix}{A}_{s} - KY\end{Vmatrix}}_{F}^{2} + {\lambda }_{1}\parallel K{\parallel }_{F}^{2} \tag{9}
$$

therefore, we can derive an analytical solution of $K$

因此，我们可以推导出 $K$ 的解析解

$$
K = \alpha {A}_{s}{Y}^{T}{\left( \alpha Y{Y}^{T} + {\lambda }_{1}I\right) }^{-1} \tag{10}
$$

Like the solution procedure for $K, Z$ is updated below

与 $K, Z$ 的求解过程类似，更新过程如下

$$
Z = {\beta P}{Y}^{T}{\left( \beta Y{Y}^{T} + {\lambda }_{2}I\right) }^{-1} \tag{11}
$$

In order to calculate the feature representations via augmented semantic embedding space, we need to update variables ${a}_{i}$ and ${y}_{i}$ in the optimization problem of Eq. (4). In detail, an iterative algorithm is presented to achieve this.

为了通过增强的语义嵌入空间计算特征表示，我们需要在公式 (4) 的优化问题中更新变量 ${a}_{i}$ 和 ${y}_{i}$。具体来说，我们提出了一种迭代算法来实现这一目标。

Updating ${a}_{i}$ : With the reconstruction coefficients ${y}_{i}$ fixed, the independent term with respect to ${a}_{i}$ can be removed from Eq. (4). Therefore, the objective is equivalent to the following optimization sub-problem:

更新 ${a}_{i}$ :在重构系数 ${y}_{i}$ 固定的情况下，可以从公式 (4) 中移除关于 ${a}_{i}$ 的独立项。因此，该目标等价于以下优化子问题:

$$
\mathop{\min }\limits_{{a}_{i}}{\begin{Vmatrix}{a}_{i} - W \cdot  {f}_{i}\end{Vmatrix}}_{F}^{2} + {\eta }_{2}{\begin{Vmatrix}{a}_{i} - K \cdot  {y}_{i}\end{Vmatrix}}_{F}^{2} \tag{12}
$$

then the semantic representation ${a}_{i}$ is updated as

然后语义表示 ${a}_{i}$ 更新为

$$
{a}_{i} = {\left( 1 + {\eta }_{2}I\right) }^{-1}\left( {W{f}_{i} + {\eta }_{2}K{y}_{i}}\right)  \tag{13}
$$

Updating ${y}_{i}$ : Moreover, we update reconstruction coefficients ${y}_{i}$ when the variable ${a}_{i}$ is fixed. In this case, the objective Eq. (4) is converted into the following problem:

更新 ${y}_{i}$ :此外，当变量 ${a}_{i}$ 固定时，我们更新重构系数 ${y}_{i}$ 。在这种情况下，目标公式 (4) 转化为以下问题:

$$
\mathop{\min }\limits_{{y}_{i}}{\eta }_{1}{\begin{Vmatrix}{f}_{i} - D \cdot  {y}_{i}\end{Vmatrix}}_{F}^{2} + {\eta }_{2}{\begin{Vmatrix}{a}_{i} - K \cdot  {y}_{i}\end{Vmatrix}}_{F}^{2} \tag{14}
$$

where ${y}_{i}$ is updated as

其中 ${y}_{i}$ 更新为

$$
{y}_{i} = {\left( {\eta }_{1}{D}^{T}D + {\eta }_{2}{K}^{T}K\right) }^{-1}\left( {{\eta }_{1}{D}^{T}{f}_{i} + {\eta }_{2}{K}^{T}{a}_{i}}\right)  \tag{15}
$$

Initialization: To implement the optimization algorithm of Eq. (3), we need to initialize variables $\{ D, K, Z\}$ . Specifically, the dictionary $D$ is initialized by the k-means algorithm using all the training samples from seen classes, and we use a random matrix to initialize linear transformation $K$ and classifier parameters $Z$ respectively. Regarding the minimization problem of Eq. (4), the reconstruction coefficient ${y}_{i}$ is initialized using the feature-sign search algorithm [43], then ${a}_{i}$ and ${y}_{i}$ are alternately updated in a mutual reinforced manner. The whole optimization procedure of the proposed method is summarized in Algorithm 1. The objectives can converge to a feasible solution after a few iterations in the experiments.

初始化:为了实现公式 (3) 的优化算法，我们需要初始化变量 $\{ D, K, Z\}$ 。具体来说，字典 $D$ 通过 k - 均值算法(k - means algorithm)使用来自已见类别的所有训练样本进行初始化，并且我们分别使用随机矩阵来初始化线性变换 $K$ 和分类器参数 $Z$ 。对于公式 (4) 的最小化问题，重构系数 ${y}_{i}$ 使用特征符号搜索算法(feature - sign search algorithm)[43] 进行初始化，然后 ${a}_{i}$ 和 ${y}_{i}$ 以相互增强的方式交替更新。所提出方法的整个优化过程总结在算法 1 中。在实验中，经过几次迭代后，目标可以收敛到一个可行解。

Algorithm 1 Discriminative Visual Semantic Embedding (DVSE) for ZSL Recognition

算法 1 用于零样本学习(ZSL)识别的判别式视觉语义嵌入(Discriminative Visual Semantic Embedding，DVSE)

---

Input: visual features ${F}_{s} \in  {\mathbf{R}}^{d \times  {n}_{s}}$ , attribute vectors ${A}_{s} \in  {\mathbf{R}}^{m \times  {n}_{s}}$ , label

输入:视觉特征 ${F}_{s} \in  {\mathbf{R}}^{d \times  {n}_{s}}$ 、属性向量 ${A}_{s} \in  {\mathbf{R}}^{m \times  {n}_{s}}$ 、标签

		matrix $P \in  {\mathbf{R}}^{\left| {L}_{s}\right|  \times  {n}_{s}}$ , weighting parameters $\alpha ,\beta ,{\lambda }_{1},{\lambda }_{2},{\eta }_{1}$ and ${\eta }_{2}$ .

		矩阵 $P \in  {\mathbf{R}}^{\left| {L}_{s}\right|  \times  {n}_{s}}$ 、加权参数 $\alpha ,\beta ,{\lambda }_{1},{\lambda }_{2},{\eta }_{1}$ 和 ${\eta }_{2}$ 。

Output: $D \in  {\mathbf{R}}^{d \times  N}, W \in  {\mathbf{R}}^{m \times  d}, Y \in  {\mathbf{R}}^{N \times  {n}_{s}}, K \in  {\mathbf{R}}^{m \times  N}, Z \in  {\mathbf{R}}^{\left| {L}_{s}\right|  \times  N}$ ,

输出:$D \in  {\mathbf{R}}^{d \times  N}, W \in  {\mathbf{R}}^{m \times  d}, Y \in  {\mathbf{R}}^{N \times  {n}_{s}}, K \in  {\mathbf{R}}^{m \times  N}, Z \in  {\mathbf{R}}^{\left| {L}_{s}\right|  \times  N}$ ，

		${a}_{i} \in  {\mathbf{R}}^{m \times  1},{y}_{i} \in  {\mathbf{R}}^{N \times  1}$

		initialize $D, K, Z$ and ${y}_{i}$

		初始化 $D, K, Z$ 和 ${y}_{i}$

		Compute visual-semantic alignment $W$ though Eq. (2);

		通过公式 (2) 计算视觉 - 语义对齐 $W$ ；

		Discriminative Visual Attributes via Supervised Dictionary

		通过有监督字典学习的判别式视觉属性

		Learning

		学习

		while not convergence do

		当未收敛时

			Update the coefficients $Y$ using Eq. (6);

			使用公式 (6) 更新系数 $Y$ ；

			Update the dictionary $D$ though Eq. (8);

			通过公式 (8) 更新字典 $D$ ；

			Compute transformation matrix $K$ by using Eq. (10);

			通过公式(10)计算变换矩阵$K$；

			Update classifier parameters $Z$ though Eq. (11);

			通过公式(11)更新分类器参数$Z$；

		end while

		结束循环

		Feature Representation with Augmented Semantic Embedding

		增强语义嵌入的特征表示

		Space

		空间

		while not convergence do

		当未收敛时执行以下操作

			Update the feature representation ${a}_{i}$ though Eq. (13);

			通过公式(13)更新特征表示${a}_{i}$；

			Update reconstruction coefficients ${y}_{i}$ by Eq. (15);

			通过公式(15)更新重构系数${y}_{i}$；

		end while

		结束循环

---

Table 1

表1

The statistics of five benchmark zero-shot learning datasets, in terms of number of images (# Img), manually defined attributes (# Attr), seen classes (# Seen) and unseen classes (# Unseen).

五个基准零样本学习数据集的统计信息，包括图像数量(# 图像)、手动定义的属性数量(# 属性)、已见类别数量(# 已见)和未见类别数量(# 未见)。

<table><tr><td>Dataset</td><td>#Img</td><td>#Attr</td><td>#Seen</td><td>#Unseen</td></tr><tr><td>AwA2 [38]</td><td>37,322</td><td>85</td><td>40</td><td>10</td></tr><tr><td>AwA [44]</td><td>30,475</td><td>85</td><td>40</td><td>10</td></tr><tr><td>CUB [45]</td><td>11,788</td><td>312</td><td>150</td><td>50</td></tr><tr><td>SUN [46]</td><td>14,340</td><td>102</td><td>645</td><td>72</td></tr><tr><td>aPY [9]</td><td>15,339</td><td>64</td><td>20</td><td>12</td></tr></table>

<table><tbody><tr><td>数据集</td><td>图像数量</td><td>属性数量</td><td>已见类别数量</td><td>未见类别数量</td></tr><tr><td>动物属性数据集2(AwA2) [38]</td><td>37,322</td><td>85</td><td>40</td><td>10</td></tr><tr><td>动物属性数据集(AwA) [44]</td><td>30,475</td><td>85</td><td>40</td><td>10</td></tr><tr><td>加州大学圣地亚哥分校鸟类数据集(CUB) [45]</td><td>11,788</td><td>312</td><td>150</td><td>50</td></tr><tr><td>场景理解数据集(SUN) [46]</td><td>14,340</td><td>102</td><td>645</td><td>72</td></tr><tr><td>属性人和物数据集(aPY) [9]</td><td>15,339</td><td>64</td><td>20</td><td>12</td></tr></tbody></table>

## 5. Experiments

## 5. 实验

### 5.1. Datasets and evaluations metrics

### 5.1. 数据集和评估指标

We evaluate the performances of the proposed method on five challenging benchmark datasets for zero-shot learning: Animals with Attributes2 (AwA2) [38], Animals with Attributes (AwA) [44], Caltech-UCSD Bird 200-2011 (CUB) [45], SUN scene attribute dataset (SUN) [46] and Attribute Pascal and Yahoo (aPY) [9]. AwA dataset consists of 30,475 images from 50 animal classes. Each class associates with an 85-dim human-defined attribute vector. AwA2 is a new version of the animals with attributes dataset which contains different images, but with a similar setting. CUB is a fine-grained dataset that consists of 11,788 images in 200 bird classes, and each class is labeled with a 312- dim attribute vector. SUN is also a challenging fine-grained dataset that contains in total 14,340 images from 717 scene categories. This dataset adopts 102 attributes to describe each scene category. Compared to CUB, the visual differences of scenes exhibit more diversity across categories. The aPY dataset includes 20 object classes with overall 12,695 images from PASCAL VOC 2008 dataset and 2644 images collected by the Yahoo search engine. A 64-dim attribute vector is provided for each class in this dataset. The statistics of the above benchmark datasets are summarized in Table 1.

我们在五个具有挑战性的零样本学习基准数据集上评估了所提出方法的性能:动物属性数据集2(Animals with Attributes2，AwA2) [38]、动物属性数据集(Animals with Attributes，AwA) [44]、加州理工学院 - 加州大学圣地亚哥分校鸟类200 - 2011数据集(Caltech - UCSD Bird 200 - 2011，CUB) [45]、SUN场景属性数据集(SUN scene attribute dataset，SUN) [46] 以及属性帕斯卡和雅虎数据集(Attribute Pascal and Yahoo，aPY) [9]。AwA数据集包含来自50个动物类别的30475张图像。每个类别与一个85维的人工定义属性向量相关联。AwA2是动物属性数据集的新版本，包含不同的图像，但设置类似。CUB是一个细粒度数据集，包含200个鸟类类别的11788张图像，每个类别都用一个312维的属性向量进行标注。SUN也是一个具有挑战性的细粒度数据集，总共包含来自717个场景类别的14340张图像。该数据集采用102个属性来描述每个场景类别。与CUB相比，场景的视觉差异在不同类别之间表现出更多的多样性。aPY数据集包括20个对象类别，共有来自PASCAL VOC 2008数据集的12695张图像和通过雅虎搜索引擎收集的2644张图像。该数据集中的每个类别都提供了一个64维的属性向量。上述基准数据集的统计信息总结在表1中。

In the proposed method, we aim to handle a more realistic but difficult scenario that both seen and unseen objects exist during the test time, which is challenging because it removes the assumption that the search space is only restricted to the unseen classes. The performances of our method are evaluated by the average per-class top-1 accuracy $\left\lbrack  {{10},{12},{28},{35}}\right\rbrack$ . Different from the conventional top-1 accuracy, the recognition rate of each class is calculated separately, avoiding the possibility of bias because of the unbalanced data from classes. Furthermore, since the testing instances come from either seen or unseen classes, the average per-class top-1 accuracy on seen classes, denoted by ${A}_{s}$ , the average per-class top-1 accuracy on unseen classes, denoted by ${A}_{u}$ , and their harmonic mean [38], defined as $H = (2 *$ ${A}_{u} * {A}_{s})/\left( {{A}_{u} + {A}_{s}}\right)$ , are reported to evaluate ZSL approaches.

在所提出的方法中，我们旨在处理一个更现实但更困难的场景，即在测试时既有已见对象又有未见对象，这具有挑战性，因为它消除了搜索空间仅局限于未见类别的假设。我们的方法的性能通过平均每类top - 1准确率 $\left\lbrack  {{10},{12},{28},{35}}\right\rbrack$ 进行评估。与传统的top - 1准确率不同，每个类别的识别率是分别计算的，避免了由于类别数据不平衡而产生偏差的可能性。此外，由于测试实例来自已见或未见类别，因此报告已见类别上的平均每类top - 1准确率(记为 ${A}_{s}$ )、未见类别上的平均每类top - 1准确率(记为 ${A}_{u}$ )以及它们的调和均值 [38](定义为 $H = (2 *$ ${A}_{u} * {A}_{s})/\left( {{A}_{u} + {A}_{s}}\right)$ )来评估零样本学习(ZSL)方法。

### 5.2. Implementation details

### 5.2. 实现细节

The data-split of datasets adheres to the work [38] that provides the uniform criterion for a fair evaluation of different methods. Here, we adopt the newly proposed split [38] for grouping the training and testing samples on the abovementioned benchmarks to ensure that there is no overlap between the testing classes and the ImageNet dataset (used for training feature extractors like ResNet mentioned below), which totally meets the assumption that seen and unseen classes are disjoint in the ZSL setting. Following [23,27,28,47], we extract the 2048- dimensional CNN feature using Resnet-101 [2] as the visual feature for an image. For discriminative visual attributes learning of Eq. (3), the scale parameters $\alpha ,\beta$ are set as 0.1, regularization parameters ${\lambda }_{1},{\lambda }_{2}$ are chosen as 0.01 , and the number of discriminative visual attributes is set as 200 in the experiments. Regarding the ZSL recognition stage, ${\eta }_{1}$ and ${\eta }_{2}$ of Eq. (4) are empirically set as 0.3 for the learning of feature representations. All the above hyperparameters were chosen from the range $\left\lbrack  {{10}^{-3},{10}^{1}}\right\rbrack$ according to the experimental evaluation. Concretely, we did not conduct a systematic hyperparameter search in brute-force implementation. Instead, we tuned them by first performing a coarse grid search, and then a finer search was taken to determine the parameters setting around the previous best performing values. In addition, it is noticed that the proposed model is not sensitive to minor changes of these hyperparameters, as shown in Fig. 7, and yet a slight improvement will be obtained by adjusting them further for each individual dataset.

数据集的数据划分遵循文献 [38]，该文献为公平评估不同方法提供了统一的标准。在这里，我们采用新提出的划分方法 [38] 对上述基准数据集的训练和测试样本进行分组，以确保测试类别与ImageNet数据集(用于训练如下面提到的ResNet等特征提取器)之间没有重叠，这完全符合零样本学习设置中已见和未见类别不相交的假设。遵循文献 [23,27,28,47]，我们使用Resnet - 101 [2] 提取2048维的卷积神经网络(CNN)特征作为图像的视觉特征。对于公式(3)中的判别性视觉属性学习，尺度参数 $\alpha ,\beta$ 设置为0.1，正则化参数 ${\lambda }_{1},{\lambda }_{2}$ 选择为0.01，并且在实验中将判别性视觉属性的数量设置为200。关于零样本学习识别阶段，公式(4)中的 ${\eta }_{1}$ 和 ${\eta }_{2}$ 经验性地设置为0.3用于特征表示的学习。上述所有超参数都是根据实验评估从范围 $\left\lbrack  {{10}^{-3},{10}^{1}}\right\rbrack$ 中选择的。具体来说，我们没有在暴力实现中进行系统的超参数搜索。相反，我们首先进行了粗略的网格搜索，然后进行了更精细的搜索，以确定在之前最佳性能值附近的参数设置。此外，如图7所示，注意到所提出的模型对这些超参数的微小变化不敏感，但通过为每个单独的数据集进一步调整它们仍会获得轻微的改进。

Our experimental observation reveals that the proposed optimization algorithm could converge very well, as shown in Section 5.6, where we will stop the iterative process when either the different of objectives (3) and (4) in adjacent iterations are below a small positive threshold $\epsilon  = {10}^{-3}$ or the number of iterations excesses a preset threshold (we set $= {30}$ as default). For inference with the nearest neighbor classifier, the semantic representation ${a}_{i}$ updated by Eq. (13) is further ${l}_{2}$ normalized. Since all the ZSL benchmark datasets provide the semantic representation of each class, namely class prototypes, thus a label of the closet class is assigned to an input instance in the semantic embedding space.

我们的实验观察表明，所提出的优化算法能够很好地收敛，如第5.6节所示。在该节中，当相邻迭代中目标函数(3)和(4)的差值低于一个小的正阈值$\epsilon  = {10}^{-3}$，或者迭代次数超过预设阈值(我们默认设置为$= {30}$)时，我们将停止迭代过程。对于最近邻分类器的推理，通过公式(13)更新的语义表示${a}_{i}$会进一步进行${l}_{2}$归一化处理。由于所有零样本学习(ZSL)基准数据集都提供了每个类别的语义表示，即类别原型，因此在语义嵌入空间中，会将最接近类别的标签分配给输入实例。

### 5.3. Zero-shot learning evaluation

### 5.3. 零样本学习评估

In this section, we conduct extensive experiments on benchmark datasets to verify the effectiveness of our model and compare it with state-of-the-art methods, including DAP [19], CMT [48], LATEM [21], ESZSL [49], PSR [35], DCN [39], SE-ZSL [50], CDL [47], ABP [51], TLZSL [27], MLSE [23], OCD [31], ZSKL [28], and etc. The recognition accuracies of different ZSL approaches are summarized in Table 2.

在本节中，我们在基准数据集上进行了广泛的实验，以验证我们模型的有效性，并将其与最先进的方法进行比较，这些方法包括判别式属性预测(DAP)[19]、跨模态转换(CMT)[48]、潜在嵌入模型(LATEM)[21]、嵌入空间零样本学习(ESZSL)[49]、原型语义表示(PSR)[35]、深度跨模态网络(DCN)[39]、语义嵌入零样本学习(SE - ZSL)[50]、协同深度学习(CDL)[47]、自适应双原型(ABP)[51]、转移学习零样本学习(TLZSL)[27]、多模态语义嵌入(MLSE)[23]、最优类别判别(OCD)[31]、零样本知识学习(ZSKL)[28]等等。不同零样本学习方法的识别准确率总结在表2中。

The recognition accuracies of the proposed method on AwA2, AwA, CUB, SUN, and aPY are 74.9%, 74.4%, 64.4%, 42.6% and 59.5%, respectively. This empirical evaluation in Table 2 demonstrates that DVSE surpasses other competitors on the AwA2, AwA and aPY by wide margins. As for CUB and SUN, they are actually very complicated fine-grained datasets that many of the bird/scene classes are quite similar. This means there exist fewer informative structures among categories. Therefore, it is challenging for our model to explore discriminative class-specific patterns in the visual space. From the results, we see that DVSE is still superior to other competing approaches on CUB, closely followed by MLSE with 64.2% accuracy, but does not perform well on SUN. After in-depth observation, the reason could be that the subtle differences between categories on SUN not only exist in the visual appearance of local regions, but also in the diversity of intrinsic spatial layout, which leads to confused semantic vectors when features are projected into the embedding space. Overall, it can be seen that the proposed approach yields the best performances against other traditional and state-of-the-art ZSL methods on most of the above benchmark datasets. This verifies that DVSE is capable of exploring potential visual attributes to enhance the discriminative power of the semantic embedding space. Another interesting discovery is that most models in Table 2 perform better on AwA2, AwA, CUB, and SUN than aPY, the reason is that it is difficult to learn some transferability knowledge from the aPY dataset. More concretely, AwA2 and AwA only consist of different animal classes, CUB and SUN just contain subordinate bird/scene classes, therefore it is reasonable to ensure the knowledge transfer from seen classes to unseen ones. But for aPY, all object classes are collected in a random manner, thus few inter-class relations can be utilized to benefit the zero-shot learning.

所提出的方法在动物属性数据集2(AwA2)、动物属性数据集(AwA)、加州大学伯克利分校鸟类数据集(CUB)、场景理解数据集(SUN)和属性青年艺术家数据集(aPY)上的识别准确率分别为74.9%、74.4%、64.4%、42.6%和59.5%。表2中的实证评估表明，深度视觉语义嵌入(DVSE)在AwA2、AwA和aPY上大幅超越了其他竞争对手。至于CUB和SUN，它们实际上是非常复杂的细粒度数据集，许多鸟类/场景类别非常相似。这意味着类别之间的信息结构较少。因此，我们的模型在视觉空间中探索具有判别性的特定类别模式具有挑战性。从结果来看，我们发现DVSE在CUB上仍然优于其他竞争方法，紧随其后的是准确率为64.2%的MLSE，但在SUN上表现不佳。经过深入观察，原因可能是SUN上类别之间的细微差异不仅存在于局部区域的视觉外观上，还存在于内在空间布局的多样性上，这导致在将特征投影到嵌入空间时语义向量混乱。总体而言，可以看出，所提出的方法在上述大多数基准数据集上的表现优于其他传统和最先进的零样本学习方法。这验证了DVSE能够探索潜在的视觉属性，以增强语义嵌入空间的判别能力。另一个有趣的发现是，表2中的大多数模型在AwA2、AwA、CUB和SUN上的表现优于aPY，原因是很难从aPY数据集中学习到一些可迁移的知识。更具体地说，AwA2和AwA仅由不同的动物类别组成，CUB和SUN仅包含下属的鸟类/场景类别，因此确保从已见类别到未见类别的知识迁移是合理的。但对于aPY，所有对象类别都是随机收集的，因此很少有类间关系可用于零样本学习。

Table 2

表2

Per-class top-1 accuracies of zero-shot learning on the AwA2, AwA, CUB and aPY benchmark datasets. The best and the second best performances are marked in bold and underlined, respectively.

在AwA2、AwA、CUB和aPY基准数据集上零样本学习的每类前1准确率。最佳和次佳表现分别用粗体和下划线标记。

<table><tr><td>Method</td><td>AwA2</td><td>AwA</td><td>CUB</td><td>SUN</td><td>$\mathbf{{aPY}}$</td><td>Method</td><td>AwA2</td><td>AwA</td><td>CUB</td><td>SUN</td><td>$\mathbf{{aPY}}$</td></tr><tr><td>DAP [19]</td><td>46.1</td><td>44.1</td><td>40.0</td><td>39.9</td><td>33.8</td><td>DCN [39]</td><td>-</td><td>65.2</td><td>56.2</td><td>61.8</td><td>43.6</td></tr><tr><td>CONSE [52]</td><td>44.5</td><td>45.6</td><td>34.3</td><td>38.8</td><td>26.9</td><td>SE-ZSL [50]</td><td>69.2</td><td>69.5</td><td>59.6</td><td>63.4</td><td>-</td></tr><tr><td>CMT [48]</td><td>37.9</td><td>39.5</td><td>34.6</td><td>39.9</td><td>28.0</td><td>TLZSL [27]</td><td>67.9</td><td>-</td><td>63.8</td><td>63.5</td><td>-</td></tr><tr><td>SSE [53]</td><td>61.0</td><td>60.1</td><td>43.9</td><td>51.5</td><td>34.0</td><td>LisGAN [54]</td><td>-</td><td>70.6</td><td>58.8</td><td>61.7</td><td>43.1</td></tr><tr><td>LATEM [21]</td><td>55.8</td><td>55.1</td><td>49.3</td><td>55.3</td><td>35.2</td><td>MLSE [23]</td><td>67.8</td><td>-</td><td>64.2</td><td>62.8</td><td>46.2</td></tr><tr><td>SYNC [55]</td><td>46.6</td><td>54.0</td><td>55.6</td><td>56.3</td><td>23.9</td><td>JGM [56]</td><td>69.5</td><td>69.9</td><td>54.9</td><td>59.0</td><td>36.3</td></tr><tr><td>ALE [10]</td><td>62.5</td><td>59.9</td><td>54.9</td><td>58.1</td><td>39.7</td><td>ABP [51]</td><td>70.4</td><td>69.3</td><td>58.5</td><td>61.5</td><td>-</td></tr><tr><td>DEVISE [13]</td><td>59.7</td><td>54.2</td><td>52.0</td><td>56.5</td><td>39.8</td><td>CDL [47]</td><td>-</td><td>69.9</td><td>54.5</td><td>63.6</td><td>43.0</td></tr><tr><td>ESZSL [49]</td><td>58.6</td><td>58.2</td><td>53.9</td><td>54.5</td><td>38.3</td><td>OCD [31]</td><td>71.3</td><td>-</td><td>60.3</td><td>63.5</td><td>-</td></tr><tr><td>SAE [11]</td><td>54.1</td><td>53.0</td><td>33.3</td><td>40.3</td><td>8.3</td><td>ZSKL [28]</td><td>70.5</td><td>70.1</td><td>51.7</td><td>61.7</td><td>45.3</td></tr><tr><td>PSR [35]</td><td>63.8</td><td>-</td><td>56.0</td><td>61.4</td><td>38.4</td><td>DVSE</td><td>74.9</td><td>74.4</td><td>64.4</td><td>42.6</td><td>59.5</td></tr></table>

<table><tbody><tr><td>方法</td><td>动物属性数据集2(Animals with Attributes 2，AwA2)</td><td>动物属性数据集(Animals with Attributes，AwA)</td><td>加州大学圣地亚哥分校鸟类数据集(Caltech-UCSD Birds，CUB)</td><td>太阳场景数据集(Scene UNderstanding，SUN)</td><td>$\mathbf{{aPY}}$</td><td>方法</td><td>动物属性数据集2(Animals with Attributes 2，AwA2)</td><td>动物属性数据集(Animals with Attributes，AwA)</td><td>加州大学圣地亚哥分校鸟类数据集(Caltech-UCSD Birds，CUB)</td><td>太阳场景数据集(Scene UNderstanding，SUN)</td><td>$\mathbf{{aPY}}$</td></tr><tr><td>判别式属性预测(Discriminative Attribute Prediction，DAP) [19]</td><td>46.1</td><td>44.1</td><td>40.0</td><td>39.9</td><td>33.8</td><td>深度跨模态网络(Deep Cross-modal Network，DCN) [39]</td><td>-</td><td>65.2</td><td>56.2</td><td>61.8</td><td>43.6</td></tr><tr><td>一致性学习(Consensus Learning，CONSE) [52]</td><td>44.5</td><td>45.6</td><td>34.3</td><td>38.8</td><td>26.9</td><td>语义嵌入零样本学习(Semantic Embedding Zero-Shot Learning，SE-ZSL) [50]</td><td>69.2</td><td>69.5</td><td>59.6</td><td>63.4</td><td>-</td></tr><tr><td>跨模态转移(Cross-Modal Transfer，CMT) [48]</td><td>37.9</td><td>39.5</td><td>34.6</td><td>39.9</td><td>28.0</td><td>转移学习零样本学习(Transfer Learning Zero-Shot Learning，TLZSL) [27]</td><td>67.9</td><td>-</td><td>63.8</td><td>63.5</td><td>-</td></tr><tr><td>半监督嵌入(Semi-Supervised Embedding，SSE) [53]</td><td>61.0</td><td>60.1</td><td>43.9</td><td>51.5</td><td>34.0</td><td>潜在图像生成对抗网络(Latent Image Generative Adversarial Network，LisGAN) [54]</td><td>-</td><td>70.6</td><td>58.8</td><td>61.7</td><td>43.1</td></tr><tr><td>后期嵌入模型(Late Embedding Model，LATEM) [21]</td><td>55.8</td><td>55.1</td><td>49.3</td><td>55.3</td><td>35.2</td><td>多标签语义嵌入(Multi-Label Semantic Embedding，MLSE) [23]</td><td>67.8</td><td>-</td><td>64.2</td><td>62.8</td><td>46.2</td></tr><tr><td>同步训练(Synchronous Training，SYNC) [55]</td><td>46.6</td><td>54.0</td><td>55.6</td><td>56.3</td><td>23.9</td><td>联合生成模型(Joint Generative Model，JGM) [56]</td><td>69.5</td><td>69.9</td><td>54.9</td><td>59.0</td><td>36.3</td></tr><tr><td>对抗学习嵌入(Adversarial Learning Embedding，ALE) [10]</td><td>62.5</td><td>59.9</td><td>54.9</td><td>58.1</td><td>39.7</td><td>属性引导投影(Attribute-Guided Projection，ABP) [51]</td><td>70.4</td><td>69.3</td><td>58.5</td><td>61.5</td><td>-</td></tr><tr><td>深度视觉语义嵌入模型(Deep Visual-Semantic Embedding Model，DEVISE) [13]</td><td>59.7</td><td>54.2</td><td>52.0</td><td>56.5</td><td>39.8</td><td>协同深度嵌入学习(Collaborative Deep Learning，CDL) [47]</td><td>-</td><td>69.9</td><td>54.5</td><td>63.6</td><td>43.0</td></tr><tr><td>高效零样本学习(Efficient Zero-Shot Learning，ESZSL) [49]</td><td>58.6</td><td>58.2</td><td>53.9</td><td>54.5</td><td>38.3</td><td>最优分类器设计(Optimal Classifier Design，OCD) [31]</td><td>71.3</td><td>-</td><td>60.3</td><td>63.5</td><td>-</td></tr><tr><td>堆叠自动编码器(Stacked Autoencoder，SAE) [11]</td><td>54.1</td><td>53.0</td><td>33.3</td><td>40.3</td><td>8.3</td><td>零样本知识迁移(Zero-Shot Knowledge Transfer，ZSKL) [28]</td><td>70.5</td><td>70.1</td><td>51.7</td><td>61.7</td><td>45.3</td></tr><tr><td>原型语义表示(Prototype Semantic Representation，PSR) [35]</td><td>63.8</td><td>-</td><td>56.0</td><td>61.4</td><td>38.4</td><td>深度视觉语义嵌入(Deep Visual-Semantic Embedding，DVSE)</td><td>74.9</td><td>74.4</td><td>64.4</td><td>42.6</td><td>59.5</td></tr></tbody></table>

To further investigate the behavior of the proposed model, Table 3 reports the comparative results on the seen classes $\left( {A}_{s}\right)$ , unseen classes $\left( {A}_{u}\right)$ , and their harmonic mean(H), respectively. As for AwA2, we observe that DVSE clearly outperforms all the competing methods by large margins in most cases. Similar to AwA2, the proposed method achieves the winning performance against all the traditional and state-of-the-art competitors by obvious margins on the aPY dataset, especially showing an impressive result on the unseen classes $\left( {A}_{u}\right)$ , confirming again the benefits of using discriminative visual attributes to distinguish semantic objects. On CUB and SUN, it is interesting to observe that the DVSE model exhibits superiority to other competing approaches on the seen classes $\left( {A}_{s}\right)$ , but does not maintain this good performance on the unseen classes, which thereby lowers the harmonic mean (H) in evaluations. The reason behind this phenomenon is mainly derived from the fact that, compared to AwA2 and aPY, the inter-class variations come from the fine-grained CUB and SUN benchmarks exhibit more subtle differences in appearance, which severely deteriorates the discriminative power of image features when knowledge transfer between categories. In other words, the proposed method is actually based on the global feature of the whole image, it is usually hard to capture a sufficient amount of details and subtleties in image contents. This means extremely similar object classes have close proximity after projecting them into the semantic embedding space, resulting in the confused feature representations for recognition. Also, we notice that the accuracy on SUN drops dramatically as shown in Table 2. This can be understood by the fact that the learned feature representations are not fully compatible with the visual semantics, and hence do not give decent performance when knowledge transfer to unseen classes. Diving further into this, it is probably due to two reasons: First, the scene names are usually more ambiguous than typical object names such as dog, bird, and flower to name a few. Take the fine-grained SUN dataset for example, many scene classes (e.g., swimming pool, kiosk, amusement, etc.) are associated with additional 'indoor' or 'outdoor' annotations as the different semantic categories, meaning that the distinction between classes blurs and it becomes increasingly harder to learn visually descriptive information from such classes with very small inter-class variations. Second, compared with AwA, AwA2, CUB and aPY, the object classes from SUN tend to exhibit the diversity of intrinsic spatial configurations in addition to the image content, and thus challenge the ZSL model to understand the semantic meaning of a scene. From the above empirical analysis, we believe this issue leaves us the next opportunity to incorporate a more expressive component like region zooming or contextual reasoning into this work for robustly grasping more discriminative visual cues in an image. Another interesting observation on these benchmarks is that the generative model-based methods like SE-ZSL [50] and JGM [56], marked as ${}^{ \dagger  }$ , normally perform better than others on unseen classes (still, DVSE favorably outperforms JGM on two benchmarks), this is because generative models attempt to synthesize samples from the unseen classes and subsequently train robust classifiers using these synthetic data. However, it is worth mentioning that these generative models are not easy to train due to the min-max optimization.

为了进一步研究所提出模型的性能，表3分别报告了在已见类别$\left( {A}_{s}\right)$、未见类别$\left( {A}_{u}\right)$及其调和均值(H)上的对比结果。对于AwA2数据集，我们观察到在大多数情况下，DVSE(判别式视觉语义嵌入，Discriminative Visual-Semantic Embedding)明显大幅优于所有竞争方法。与AwA2类似，在所提出的方法在aPY数据集上明显优于所有传统方法和最先进的竞争方法，尤其是在未见类别$\left( {A}_{u}\right)$上取得了令人印象深刻的结果，这再次证实了使用判别性视觉属性来区分语义对象的好处。在CUB和SUN数据集上，有趣的是，DVSE模型在已见类别$\left( {A}_{s}\right)$上表现出优于其他竞争方法的优势，但在未见类别上未能保持这种良好性能，从而降低了评估中的调和均值(H)。这一现象的原因主要在于，与AwA2和aPY相比，细粒度的CUB和SUN基准测试中的类间差异在外观上表现出更细微的差别，这在类别间进行知识迁移时严重削弱了图像特征的判别能力。换句话说，所提出的方法实际上是基于整个图像的全局特征，通常难以捕捉图像内容中足够多的细节和微妙之处。这意味着在将极其相似的对象类别投影到语义嵌入空间后，它们的距离很近，导致用于识别的特征表示混乱。此外，如表2所示，我们注意到在SUN数据集上的准确率大幅下降。这可以理解为，所学习到的特征表示与视觉语义不完全兼容，因此在将知识迁移到未见类别时表现不佳。深入探究，这可能有两个原因:首先，场景名称通常比典型的对象名称(如狗、鸟和花等)更模糊。以细粒度的SUN数据集为例，许多场景类别(如游泳池、售货亭、娱乐场所等)会根据不同的语义类别添加额外的“室内”或“室外”注释，这意味着类别之间的区别变得模糊，并且从类间差异非常小的此类类别中学习视觉描述信息变得越来越困难。其次，与AwA、AwA2、CUB和aPY相比，SUN数据集中的对象类别除了图像内容外，还呈现出内在空间配置的多样性，因此对零样本学习(ZSL，Zero-Shot Learning)模型理解场景的语义含义提出了挑战。从上述实证分析来看，我们认为这个问题为我们提供了下一个机会，即在此工作中融入更具表现力的组件，如区域缩放或上下文推理，以更稳健地捕捉图像中更具判别性的视觉线索。在这些基准测试中另一个有趣的观察结果是，基于生成模型的方法，如SE - ZSL [50]和JGM [56](标记为${}^{ \dagger  }$)，通常在未见类别上的表现优于其他方法(不过，在两个基准测试中，DVSE仍优于JGM)，这是因为生成模型试图从未见类别中合成样本，然后使用这些合成数据训练稳健的分类器。然而，值得一提的是，由于涉及最小 - 最大优化，这些生成模型并不容易训练。

![0195da39-8010-7dd8-a310-a27a9d32cb75_5_944_597_646_616_0.jpg](images/0195da39-8010-7dd8-a310-a27a9d32cb75_5_944_597_646_616_0.jpg)

Fig. 3. Visualization of the confusion matrix with zero-shot setting by the proposed method on the CUB [45] fine-grained dataset.

图3. 所提出的方法在CUB [45]细粒度数据集上零样本设置下的混淆矩阵可视化。

In order to visualize the zero-shot recognition performance, we report the obtained confusion matrix by the proposed method on the CUB dataset in Fig. 3. As can be seen, although CUB is a challenging fine-grained benchmark that only exists subtle differences among classes, the DVSE model can still present appealing accuracies in the zero-shot setting. It is noticed that the color distribution shows a series of relatively higher accuracies (bright squares) in most of the classes, and a few misclassified cases (cold tone squares), indicating the valuable merit of DVSE for discovering discriminative visual cues for recognition tasks. Additionally, it would be interesting to see how the proposed method performs by considering the configuration of different visual features. Table 4 compares the performances of DVSE with various image features extracted from pretrained CNN models like VGG [59], VD [1], GoogLeNet [60], ResNet [2] and EfficientNet [61] on the AwA2 benchmark. As reported in this table, DVSE using visual features by EfficientNet [61] achieves the best performance, closely followed by DVSE with ResNet [2] which is taken as default in our method. From the results, it is clear that the potential of more advanced CNN architectures can further benefit the learning of discriminative visual attributes, favorably improving prediction accuracy.

为了直观展示零样本识别性能，我们在图3中展示了所提出的方法在CUB数据集上得到的混淆矩阵。可以看出，尽管CUB是一个具有挑战性的细粒度基准数据集，类别之间仅存在细微差异，但DVSE模型在零样本设置下仍能呈现出不错的准确率。值得注意的是，颜色分布显示，大多数类别都有一系列相对较高的准确率(亮色方块)，以及少数误分类的情况(冷色调方块)，这表明DVSE在为识别任务发现有区分性的视觉线索方面具有重要价值。此外，观察所提出的方法在考虑不同视觉特征配置时的表现会很有趣。表4比较了DVSE与从预训练的卷积神经网络(CNN)模型(如VGG [59]、VD [1]、GoogLeNet [60]、ResNet [2]和EfficientNet [61])中提取的各种图像特征在AwA2基准数据集上的性能。如表中所示，使用EfficientNet [61]提取的视觉特征的DVSE取得了最佳性能，紧随其后的是使用ResNet [2]的DVSE，这也是我们方法中的默认设置。从结果可以明显看出，更先进的CNN架构的潜力可以进一步有助于学习有区分性的视觉属性，从而有利地提高预测准确率。

Table 3

表3

Zero-shot recognition results on four benchmark datasets. ${A}_{n}$ refers to the average per-class top-1 accuracy on the unseen classes; ${A}_{s}$ refers to the average per-class top-1 accuracy on the seen classes; $H$ is the harmonic mean. The best and the second best performances are marked in bold and underlined, respectively. ${}^{ \dagger  }$ indicates the generative model-based methods.

四个基准数据集上的零样本识别结果。${A}_{n}$指未见类别上的平均每类top - 1准确率；${A}_{s}$指已见类别上的平均每类top - 1准确率；$H$是调和均值。最佳和次佳性能分别用粗体和下划线标记。${}^{ \dagger  }$表示基于生成模型的方法。

<table><tr><td rowspan="2">Methods</td><td colspan="3">AwA2</td><td colspan="3">CUB</td><td colspan="3">SUN</td><td colspan="3">aPY</td></tr><tr><td>${A}_{U}$</td><td>${A}_{S}$</td><td>$H$</td><td>${A}_{U}$</td><td>${A}_{S}$</td><td>$H$</td><td>${A}_{U}$</td><td>${A}_{S}$</td><td>$H$</td><td>${A}_{U}$</td><td>${A}_{S}$</td><td>$H$</td></tr><tr><td>DAP [19]</td><td>0.0</td><td>84.7</td><td>0.0</td><td>1.7</td><td>67.9</td><td>3.3</td><td>4.2</td><td>25.2</td><td>7.2</td><td>4.8</td><td>78.3</td><td>9.0</td></tr><tr><td>CONSE [52]</td><td>0.5</td><td>90.6</td><td>1.0</td><td>1.6</td><td>72.2</td><td>3.1</td><td>6.8</td><td>39.9</td><td>11.6</td><td>0.0</td><td>91.2</td><td>0.0</td></tr><tr><td>CMT [48]</td><td>0.5</td><td>90.0</td><td>1.0</td><td>7.2</td><td>49.8</td><td>12.6</td><td>8.1</td><td>21.8</td><td>11.8</td><td>1.4</td><td>85.2</td><td>2.8</td></tr><tr><td>LATEM [21]</td><td>11.5</td><td>77.3</td><td>20.0</td><td>15.2</td><td>57.3</td><td>24.0</td><td>14.7</td><td>28.8</td><td>19.5</td><td>0.1</td><td>73.0</td><td>0.2</td></tr><tr><td>SYNC [55]</td><td>10.0</td><td>90.5</td><td>18.0</td><td>11.5</td><td>70.9</td><td>19.8</td><td>7.9</td><td>43.3</td><td>13.4</td><td>7.4</td><td>66.3</td><td>13.3</td></tr><tr><td>ALE [10]</td><td>14.0</td><td>81.8</td><td>23.9</td><td>23.7</td><td>62.8</td><td>34.4</td><td>21.8</td><td>33.1</td><td>26.3</td><td>4.6</td><td>73.7</td><td>8.7</td></tr><tr><td>DEVISE [13]</td><td>17.1</td><td>74.7</td><td>27.8</td><td>23.8</td><td>53.0</td><td>32.8</td><td>16.9</td><td>27.4</td><td>20.9</td><td>4.9</td><td>76.9</td><td>9.2</td></tr><tr><td>SAE [11]</td><td>1.1</td><td>82.2</td><td>2.2</td><td>7.8</td><td>54.0</td><td>13.6</td><td>8.8</td><td>18.0</td><td>11.8</td><td>0.4</td><td>80.9</td><td>0.9</td></tr><tr><td>PSR [35]</td><td>20.7</td><td>73.8</td><td>32.3</td><td>24.6</td><td>54.3</td><td>33.9</td><td>20.8</td><td>37.2</td><td>26.7</td><td>13.5</td><td>51.4</td><td>21.4</td></tr><tr><td>GFZSL [57]</td><td>2.5</td><td>80.1</td><td>4.8</td><td>0.0</td><td>45.7</td><td>0.0</td><td>0.0</td><td>39.6</td><td>0.0</td><td>0.0</td><td>83.3</td><td>0.0</td></tr><tr><td>MLSE [23]</td><td>23.8</td><td>83.2</td><td>37.0</td><td>22.3</td><td>71.6</td><td>34.0</td><td>20.7</td><td>36.4</td><td>26.4</td><td>12.7</td><td>74.3</td><td>21.7</td></tr><tr><td>VSE [58]</td><td>45.6</td><td>88.7</td><td>60.2</td><td>39.5</td><td>68.9</td><td>50.2</td><td>-</td><td>-</td><td>-</td><td>43.6</td><td>78.7</td><td>56.2</td></tr><tr><td>SE-ZSL ${}^{ \dagger  }$ [50]</td><td>58.3</td><td>68.1</td><td>62.8</td><td>41.5</td><td>53.3</td><td>46.7</td><td>40.9</td><td>30.5</td><td>34.9</td><td>-</td><td>-</td><td>-</td></tr><tr><td>${\mathrm{{JGM}}}^{ \dagger  }$ [56]</td><td>56.2</td><td>71.7</td><td>63.0</td><td>42.7</td><td>45.6</td><td>44.1</td><td>44.4</td><td>30.9</td><td>36.5</td><td>31.1</td><td>43.3</td><td>36.2</td></tr><tr><td>ZSKL [28]</td><td>18.9</td><td>82.7</td><td>30.8</td><td>21.6</td><td>52.8</td><td>30.6</td><td>20.1</td><td>31.4</td><td>24.5</td><td>10.5</td><td>76.2</td><td>18.5</td></tr><tr><td>DVSE</td><td>78.4</td><td>74.0</td><td>76.1</td><td>10.7</td><td>82.3</td><td>19.0</td><td>12.1</td><td>46.0</td><td>19.2</td><td>76.3</td><td>94.7</td><td>84.5</td></tr></table>

<table><tbody><tr><td rowspan="2">方法</td><td colspan="3">AwA2(动物属性数据集2，Animals with Attributes 2)</td><td colspan="3">CUB(加州理工学院-加州大学圣地亚哥分校鸟类数据集，Caltech-UCSD Birds)</td><td colspan="3">SUN(场景理解数据库，Scene UNderstanding database)</td><td colspan="3">aPY(属性-人-青年数据集，Attributes - People - Yahoo)</td></tr><tr><td>${A}_{U}$</td><td>${A}_{S}$</td><td>$H$</td><td>${A}_{U}$</td><td>${A}_{S}$</td><td>$H$</td><td>${A}_{U}$</td><td>${A}_{S}$</td><td>$H$</td><td>${A}_{U}$</td><td>${A}_{S}$</td><td>$H$</td></tr><tr><td>判别式属性预测(Discriminative Attribute Prediction，DAP) [19]</td><td>0.0</td><td>84.7</td><td>0.0</td><td>1.7</td><td>67.9</td><td>3.3</td><td>4.2</td><td>25.2</td><td>7.2</td><td>4.8</td><td>78.3</td><td>9.0</td></tr><tr><td>一致性嵌入(Consistent Embedding，CONSE) [52]</td><td>0.5</td><td>90.6</td><td>1.0</td><td>1.6</td><td>72.2</td><td>3.1</td><td>6.8</td><td>39.9</td><td>11.6</td><td>0.0</td><td>91.2</td><td>0.0</td></tr><tr><td>跨模态转移(Cross - Modal Transfer，CMT) [48]</td><td>0.5</td><td>90.0</td><td>1.0</td><td>7.2</td><td>49.8</td><td>12.6</td><td>8.1</td><td>21.8</td><td>11.8</td><td>1.4</td><td>85.2</td><td>2.8</td></tr><tr><td>后期嵌入模型(Late Embedding Model，LATEM) [21]</td><td>11.5</td><td>77.3</td><td>20.0</td><td>15.2</td><td>57.3</td><td>24.0</td><td>14.7</td><td>28.8</td><td>19.5</td><td>0.1</td><td>73.0</td><td>0.2</td></tr><tr><td>同步嵌入(Synchronous Embedding，SYNC) [55]</td><td>10.0</td><td>90.5</td><td>18.0</td><td>11.5</td><td>70.9</td><td>19.8</td><td>7.9</td><td>43.3</td><td>13.4</td><td>7.4</td><td>66.3</td><td>13.3</td></tr><tr><td>对抗学习嵌入(Adversarial Learning Embedding，ALE) [10]</td><td>14.0</td><td>81.8</td><td>23.9</td><td>23.7</td><td>62.8</td><td>34.4</td><td>21.8</td><td>33.1</td><td>26.3</td><td>4.6</td><td>73.7</td><td>8.7</td></tr><tr><td>深度视觉语义嵌入模型(Deep Visual - Semantic Embedding Model，DEVISE) [13]</td><td>17.1</td><td>74.7</td><td>27.8</td><td>23.8</td><td>53.0</td><td>32.8</td><td>16.9</td><td>27.4</td><td>20.9</td><td>4.9</td><td>76.9</td><td>9.2</td></tr><tr><td>语义自动编码器(Semantic Autoencoder，SAE) [11]</td><td>1.1</td><td>82.2</td><td>2.2</td><td>7.8</td><td>54.0</td><td>13.6</td><td>8.8</td><td>18.0</td><td>11.8</td><td>0.4</td><td>80.9</td><td>0.9</td></tr><tr><td>原型语义回归(Prototype Semantic Regression，PSR) [35]</td><td>20.7</td><td>73.8</td><td>32.3</td><td>24.6</td><td>54.3</td><td>33.9</td><td>20.8</td><td>37.2</td><td>26.7</td><td>13.5</td><td>51.4</td><td>21.4</td></tr><tr><td>广义零样本学习的生成流(Generative Flows for Generalized Zero - Shot Learning，GFZSL) [57]</td><td>2.5</td><td>80.1</td><td>4.8</td><td>0.0</td><td>45.7</td><td>0.0</td><td>0.0</td><td>39.6</td><td>0.0</td><td>0.0</td><td>83.3</td><td>0.0</td></tr><tr><td>多标签语义嵌入(Multi - Label Semantic Embedding，MLSE) [23]</td><td>23.8</td><td>83.2</td><td>37.0</td><td>22.3</td><td>71.6</td><td>34.0</td><td>20.7</td><td>36.4</td><td>26.4</td><td>12.7</td><td>74.3</td><td>21.7</td></tr><tr><td>视觉语义嵌入(Visual - Semantic Embedding，VSE) [58]</td><td>45.6</td><td>88.7</td><td>60.2</td><td>39.5</td><td>68.9</td><td>50.2</td><td>-</td><td>-</td><td>-</td><td>43.6</td><td>78.7</td><td>56.2</td></tr><tr><td>语义嵌入零样本学习(Semantic Embedding Zero - Shot Learning，SE - ZSL) ${}^{ \dagger  }$ [50]</td><td>58.3</td><td>68.1</td><td>62.8</td><td>41.5</td><td>53.3</td><td>46.7</td><td>40.9</td><td>30.5</td><td>34.9</td><td>-</td><td>-</td><td>-</td></tr><tr><td>${\mathrm{{JGM}}}^{ \dagger  }$ [56]</td><td>56.2</td><td>71.7</td><td>63.0</td><td>42.7</td><td>45.6</td><td>44.1</td><td>44.4</td><td>30.9</td><td>36.5</td><td>31.1</td><td>43.3</td><td>36.2</td></tr><tr><td>零样本知识蒸馏(Zero - Shot Knowledge Distillation，ZSKL) [28]</td><td>18.9</td><td>82.7</td><td>30.8</td><td>21.6</td><td>52.8</td><td>30.6</td><td>20.1</td><td>31.4</td><td>24.5</td><td>10.5</td><td>76.2</td><td>18.5</td></tr><tr><td>深度视觉语义嵌入(Deep Visual - Semantic Embedding，DVSE)</td><td>78.4</td><td>74.0</td><td>76.1</td><td>10.7</td><td>82.3</td><td>19.0</td><td>12.1</td><td>46.0</td><td>19.2</td><td>76.3</td><td>94.7</td><td>84.5</td></tr></tbody></table>

![0195da39-8010-7dd8-a310-a27a9d32cb75_6_307_791_1126_703_0.jpg](images/0195da39-8010-7dd8-a310-a27a9d32cb75_6_307_791_1126_703_0.jpg)

Fig. 4. Qualitative evaluation of the proposed method on the AwA2 [38] dataset. The 7 out of 10 unseen class labels are listed on the top, then 3 randomly selected samples from all the correctly classified images are presented for each class. The next two rows show the misclassified instances with high confidences (marked with red bounding boxes), and the bottom part of this figure lists the corresponding misclassified labels for the above unrecognized samples respectively.

图4. 所提出的方法在AwA2 [38]数据集上的定性评估。顶部列出了10个未见类别标签中的7个，然后为每个类别展示了从所有正确分类的图像中随机选择的3个样本。接下来的两行展示了高置信度误分类的实例(用红色边界框标记)，该图的底部分别列出了上述未识别样本对应的误分类标签。

### 5.4. Qualitative results

### 5.4. 定性结果

Furthermore, we report some qualitative results with the proposed method. Specifically, Fig. 4 presents 7 out of 10 unseen animal classes on the AwA2 dataset. For each class, three correctly classified samples are randomly selected and shown first, then the next two rows give the misclassified ones (red bounding boxes) with high confidence. The bottom part of this figure lists the misclassified labels. We observe that DVSE performs very well on two unseen classes 'Blue whale', 'Giraffe', where only one test sample from the 'Blue whale' is misclassified and all samples are predicted correctly on the 'Giraffe' class. Also, the rest columns show some sample images from the other classes. From the results, we notice that discriminative visual cues can be explored effectively via the DVSE model for representing images from unseen classes, even if there is no sample of these specific classes in training time.

此外，我们报告了所提出方法的一些定性结果。具体而言，图4展示了AwA2数据集上10个未见动物类别中的7个。对于每个类别，首先随机选择并展示三个正确分类的样本，然后接下来的两行给出了高置信度的误分类样本(红色边界框)。该图的底部列出了误分类标签。我们观察到，DVSE在两个未见类别“蓝鲸(Blue whale)”和“长颈鹿(Giraffe)”上表现非常好，其中“蓝鲸”类别只有一个测试样本被误分类，而“长颈鹿”类别所有样本都被正确预测。此外，其余列展示了来自其他类别的一些样本图像。从结果中我们注意到，即使在训练时没有这些特定类别的样本，也可以通过DVSE模型有效地探索用于表示未见类别图像的判别性视觉线索。

Table 4

表4

Performances of DVSE with various configurations of the image feature on the AwA2 benchmark. The best and the second best performances are marked in bold and underlined, respectively.

在AwA2基准上，DVSE在图像特征的各种配置下的性能。最佳和次佳性能分别用粗体和下划线标记。

<table><tr><td>Configuration</td><td>Average top-1 (all classes)</td><td>Unseen classes $\left( {A}_{u}\right)$</td><td>Seen classes $\left( {A}_{s}\right)$</td><td>Harmonic mean(H)</td></tr><tr><td>DVSE-vgg-f [59]</td><td>70.4</td><td>75.6</td><td>69.1</td><td>72.2</td></tr><tr><td>DVSE-vd16 [1]</td><td>74.6</td><td>78.2</td><td>73.7</td><td>75.9</td></tr><tr><td>DVSE-googlenet [60]</td><td>69.3</td><td>74.8</td><td>67.9</td><td>71.2</td></tr><tr><td>DVSE-resnet101 [2]</td><td>74.9</td><td>78.4</td><td>74.0</td><td>76.1</td></tr><tr><td>DVSE-efficinet-b3 [61]</td><td>76.2</td><td>78.8</td><td>75.5</td><td>77.1</td></tr><tr><td>DVSE-efficient-b6 [61]</td><td>76.7</td><td>79.0</td><td>76.1</td><td>77.5</td></tr></table>

<table><tbody><tr><td>配置</td><td>平均前1准确率(所有类别)</td><td>未见类别 $\left( {A}_{u}\right)$</td><td>已见类别 $\left( {A}_{s}\right)$</td><td>调和平均数(H)</td></tr><tr><td>DVSE - vgg - f [59]</td><td>70.4</td><td>75.6</td><td>69.1</td><td>72.2</td></tr><tr><td>DVSE - vd16 [1]</td><td>74.6</td><td>78.2</td><td>73.7</td><td>75.9</td></tr><tr><td>DVSE - googlenet [60]</td><td>69.3</td><td>74.8</td><td>67.9</td><td>71.2</td></tr><tr><td>DVSE - resnet101 [2]</td><td>74.9</td><td>78.4</td><td>74.0</td><td>76.1</td></tr><tr><td>DVSE - efficinet - b3 [61]</td><td>76.2</td><td>78.8</td><td>75.5</td><td>77.1</td></tr><tr><td>DVSE - efficient - b6 [61]</td><td>76.7</td><td>79.0</td><td>76.1</td><td>77.5</td></tr></tbody></table>

![0195da39-8010-7dd8-a310-a27a9d32cb75_7_267_144_1216_1020_0.jpg](images/0195da39-8010-7dd8-a310-a27a9d32cb75_7_267_144_1216_1020_0.jpg)

Fig. 5. Qualitative results of the proposed method on the CUB [45] dataset. The 8 out of 50 unseen bird class labels are listed on the top, then we randomly select 3 samples from all the recognized ones for each class to present in the first part. The next two rows show the unrecognized instances (marked with red bounding boxes) that have high confidences. Finally, we list the misclassified labels at the bottom and provide an exemplary instance (marked with a blue bounding box) for each of these bird labels.

图5. 所提出的方法在CUB [45]数据集上的定性结果。50个未见鸟类类别标签中的8个列在顶部，然后我们为每个类别从所有已识别的样本中随机选择3个样本在第一部分展示。接下来的两行展示了具有高置信度的未识别实例(用红色边界框标记)。最后，我们在底部列出误分类的标签，并为每个鸟类标签提供一个示例实例(用蓝色边界框标记)。

![0195da39-8010-7dd8-a310-a27a9d32cb75_7_153_1306_645_551_0.jpg](images/0195da39-8010-7dd8-a310-a27a9d32cb75_7_153_1306_645_551_0.jpg)

Fig. 6. t-SNE [62] visualization of the feature representation distribution for 10 unseen classes in the augmented semantic embedding space on the AwA2 dataset. Different colors of dots denote different classes.

图6. 在AwA2数据集的增强语义嵌入空间中，10个未见类别的特征表示分布的t - SNE [62]可视化。不同颜色的点表示不同的类别。

Besides, we present 8 out of 50 unseen bird classes on the CUB dataset in Fig. 5. To better show the subtle differences among classes, we add a part of this figure to provide an exemplary instance of a bird (blue bounding box) for each misclassified label. As can be seen from the top-3 retrieved test images of each class, the DVSE model is able to discover informative visual patterns to recognize unseen classes in this fine-grained dataset. Moreover, we observe that the misclassified samples (red bounding boxes) are very similar to these exemplary instances of predicted classes in appearance. In fact, it can easily cause confusion even for humans in this case.

此外，我们在图5中展示了CUB数据集上50个未见鸟类类别中的8个。为了更好地展示类别之间的细微差异，我们在图中添加了一部分内容，为每个误分类的标签提供一个鸟类示例实例(蓝色边界框)。从每个类别的前3个检索测试图像可以看出，DVSE模型能够发现有信息价值的视觉模式，以识别这个细粒度数据集中的未见类别。此外，我们观察到误分类的样本(红色边界框)在外观上与预测类别的这些示例实例非常相似。实际上，在这种情况下，即使对于人类来说也很容易造成混淆。

To further show the effectiveness of DVSE, we implement the t-SNE [62] visualization for semantic representations of image features in the augmented semantic embedding space. Fig. 6 presents the distribution of learned semantic representations ${a}_{i}$ of Eq. (4) from 10 unseen classes on the AwA2 dataset. We observe that most of the classes are tightly crowding together where the semantic representations from different classes are well scattered, and a bunch of samples exhibit relatively ambiguous structures. This validates that the proposed method is able to strengthen the descriptive capability of the semantic embedding space and facilitates knowledge transfer across object classes.

为了进一步展示DVSE的有效性，我们对增强语义嵌入空间中图像特征的语义表示进行了t - SNE [62]可视化。图6展示了AwA2数据集上10个未见类别的式(4)中学习到的语义表示${a}_{i}$的分布。我们观察到，大多数类别紧密聚集在一起，不同类别的语义表示分布良好，并且有一组样本呈现出相对模糊的结构。这验证了所提出的方法能够增强语义嵌入空间的描述能力，并促进跨对象类别的知识转移。

### 5.5. Parameter sensitivity

### 5.5. 参数敏感性

In order to provide a deeper insight into the efficacy of each component in the proposed model, we report the parameter sensitivity of DVSE on the benchmark datasets. Specifically, we evaluate the performances of DVSE with respect to these trade-off parameters $\alpha$ , $\beta ,{\lambda }_{1}$ and ${\lambda }_{2}$ in Fig. 7, respectively. In detail, we vary each parameter in the range of $\left\lbrack  {{10}^{-3},{10}^{-2},{10}^{-1},{10}^{0},{10}^{1}}\right\rbrack$ when the others are fixed to selected optimal values as listed in Section 5.2. As for the parameter $\alpha$ shown in Fig. 7(a), we notice that the recognition rate is improved gradually when $\alpha$ is varied from ${10}^{-3}$ to ${10}^{0}$ , but if the higher value is assigned to it, the performance degrades. It is observed that DVSE can achieve better performance around ${10}^{-1}$ on all the evaluation datasets. From the above analysis of $\alpha$ , we see that the consistency constraint can benefit zero-shot learning, but a large weighting factor for this term may hurt the diversity of feature representations in the semantic embedding space, leading to performance degradation.

为了更深入地了解所提出模型中每个组件的有效性，我们报告了DVSE在基准数据集上的参数敏感性。具体来说，我们分别在图7中评估了DVSE相对于这些权衡参数$\alpha$、$\beta ,{\lambda }_{1}$和${\lambda }_{2}$的性能。详细地说，当其他参数固定为第5.2节中列出的选定最优值时，我们在$\left\lbrack  {{10}^{-3},{10}^{-2},{10}^{-1},{10}^{0},{10}^{1}}\right\rbrack$范围内改变每个参数。如图7(a)所示的参数$\alpha$，我们注意到当$\alpha$从${10}^{-3}$变化到${10}^{0}$时，识别率逐渐提高，但如果给它分配更高的值，性能会下降。可以观察到，DVSE在所有评估数据集上大约在${10}^{-1}$处可以实现更好的性能。从上述对$\alpha$的分析中，我们看到一致性约束可以有利于零样本学习，但该术语的大权重因子可能会损害语义嵌入空间中特征表示的多样性，导致性能下降。

![0195da39-8010-7dd8-a310-a27a9d32cb75_8_185_154_1377_315_0.jpg](images/0195da39-8010-7dd8-a310-a27a9d32cb75_8_185_154_1377_315_0.jpg)

Fig. 7. The effects of different parameter configurations on benchmark datasets; (a) parameter $\alpha$ analysis; (b) parameter $\beta$ analysis; (c) parameter influence of ${\lambda }_{1}$ ; (d) parameter influence of ${\lambda }_{2}$ .

图7. 不同参数配置对基准数据集的影响；(a) 参数$\alpha$分析；(b) 参数$\beta$分析；(c) 参数${\lambda }_{1}$的影响；(d) 参数${\lambda }_{2}$的影响。

![0195da39-8010-7dd8-a310-a27a9d32cb75_8_399_585_948_416_0.jpg](images/0195da39-8010-7dd8-a310-a27a9d32cb75_8_399_585_948_416_0.jpg)

Fig. 8. Objective values with respect to the number of iterations on benchmark datasets. (a) Convergence curve of DVSE on AwA2 [38]. (b) Convergence curve of DVSE on CUB [45].

图8. 基准数据集上目标值随迭代次数的变化。(a) DVSE在AwA2 [38]上的收敛曲线。(b) DVSE在CUB [45]上的收敛曲线。

Moreover, the sensitivity of $\beta$ is shown in Fig. 7(b), we observe that these varying curves have a similar pattern to that of the parameter $\alpha$ , but the performances degrade remarkably if the value of $\beta$ continues to increase $\left( { > {10}^{0}}\right)$ on AwA2 and CUB. As for aPY, it is interesting to notice that the result of DVSE is insensitive to a large weighting value of $\beta$ . From the analysis of $\beta$ , we notice that the classification loss is able to reasonably capture discriminative visual information for representing image features. But if we impose a strong supervised constraint on the learning of seen classes, it hurts the generalization capability of knowledge from seen classes to unseen ones. The performance of aPY does not degenerate probably due to the reason that object classes from this dataset are collected randomly, which means weak relations among classes cause the insensitivity on performance when knowledge transfer from seen classes. Also, the influence of parameters ${\lambda }_{1}$ and ${\lambda }_{2}$ are evaluated on benchmarks and we exhibit the behavior of the proposed model at various values in Fig. 7(c) and (d), in which we notice that DVSE produces relatively steady performance over a large range of ${\lambda }_{1},{\lambda }_{2} \in  \left\lbrack  {{10}^{-3},{10}^{1}}\right\rbrack$ . This suggests that the regularization on transformation matrices $K$ and $Z$ of Eq. (3) has limited influence on the recognition tasks. On the whole, we set ${\lambda }_{1},{\lambda }_{2} = {0.01}$ as default throughout the experiments.

此外，图7(b)展示了$\beta$的敏感性。我们观察到，这些变化曲线与参数$\alpha$的曲线模式相似，但如果$\beta$的值在AwA2和CUB数据集上继续增大$\left( { > {10}^{0}}\right)$，性能会显著下降。至于aPY数据集，有趣的是，DVSE的结果对$\beta$的大权重值不敏感。通过对$\beta$的分析，我们发现分类损失能够合理地捕捉用于表示图像特征的判别性视觉信息。但如果我们对已见类别的学习施加较强的监督约束，就会损害知识从已见类别向未见类别迁移的泛化能力。aPY数据集的性能没有下降，可能是因为该数据集中的目标类别是随机收集的，这意味着类别之间的关系较弱，导致在知识从已见类别迁移时，性能对其不敏感。此外，我们在基准数据集上评估了参数${\lambda }_{1}$和${\lambda }_{2}$的影响，并在图7(c)和(d)中展示了所提出模型在不同值下的表现，我们注意到DVSE在较大的${\lambda }_{1},{\lambda }_{2} \in  \left\lbrack  {{10}^{-3},{10}^{1}}\right\rbrack$范围内产生相对稳定的性能。这表明式(3)中对变换矩阵$K$和$Z$的正则化对识别任务的影响有限。总体而言，我们在整个实验中默认设置${\lambda }_{1},{\lambda }_{2} = {0.01}$。

### 5.6. Convergence analysis

### 5.6. 收敛性分析

As the DVSE model is not joint convex over all the variables, we derive an alternative optimization algorithm to reformulate the Eq. (3) into multiple easier sub-problems, where all the variables involved in the model can be readily solved in an iterative manner. Fig. 8 demonstrates the objective curves on the AwA2 and CUB datasets, respectively. It is observed that the optimization algorithm has a fast convergence speed and good stability after a few iterations. Although convergence is not theoretically guaranteed in this non-convex case, empirical results validate that our optimization solver converges to a feasible solution.

由于DVSE模型在所有变量上并非联合凸的，我们推导了一种交替优化算法，将式(3)重新表述为多个更简单的子问题，模型中涉及的所有变量都可以通过迭代方式轻松求解。图8分别展示了在AwA2和CUB数据集上的目标曲线。可以观察到，优化算法在经过几次迭代后具有较快的收敛速度和良好的稳定性。尽管在这种非凸情况下理论上不能保证收敛，但实验结果验证了我们的优化求解器能够收敛到一个可行解。

## 6. Conclusion

## 6. 结论

In this paper, we presented a novel method to strengthen the descriptive capability of the semantic embedding space for zero-shot learning. Specifically, we cast the ZSL problem into a supervised dictionary learning formulation that enables the exploration of discriminative attributes implied in the visual space. Moreover, the learned visual attributes and human-defined attributes are leveraged jointly to provide an augmented semantic embedding space, which helps to promote the discriminative capability of feature representations for further ZSL recognition tasks. Finally, we regarded our model as an optimization problem and derived an iterative algorithm to solve it. The experimental results conducted on several popular benchmark datasets demonstrate its efficiency, which is shown to achieve favorable performances compared with state-of-the-art methods.

在本文中，我们提出了一种新方法来增强零样本学习中语义嵌入空间的描述能力。具体来说，我们将零样本学习问题转化为一个有监督的字典学习公式，从而能够探索视觉空间中隐含的判别性属性。此外，我们将学习到的视觉属性和人为定义的属性联合起来，提供一个增强的语义嵌入空间，这有助于提高特征表示的判别能力，以用于进一步的零样本学习识别任务。最后，我们将我们的模型视为一个优化问题，并推导了一种迭代算法来求解它。在几个流行的基准数据集上进行的实验结果证明了其有效性，与现有最先进的方法相比，该模型表现出了良好的性能。

## CRediT authorship contribution statement

## 作者贡献声明

Yurui Xie: Conceptualization, Methodology, Software, Validation, Investigation, Writing - original draft. Tiecheng Song: Formal analysis, Writing - review & editing, Funding acquisition. Jianying Yuan: Writing - review & editing, Funding acquisition.

谢宇锐:概念构思、方法设计、软件开发、验证、调查、初稿撰写。宋铁城:形式分析、审核与编辑、资金获取。袁建英:审核与编辑、资金获取。

## Declaration of competing interest

## 利益冲突声明

The authors declare that they have no known competing financial interests or personal relationships that could have appeared to influence the work reported in this paper.

作者声明，他们没有已知的可能影响本文所报告工作的竞争性财务利益或个人关系。

## Data availability

## 数据可用性

The authors do not have permission to share data.

作者未获得共享数据的许可。

## Acknowledgments

## 致谢

This work was supported by The National Natural Science Foundation of China (No. 61806028, No. 61702065), and in part by The Educational Foundation of Sichuan Province, China (No. 18ZB0125), the Sichuan Science and Technology Program, China (No. 2021YFG0133).

本工作得到了国家自然科学基金(项目编号:61806028、61702065)的支持，部分得到了四川省教育厅科研项目(项目编号:18ZB0125)、四川省科技计划项目(项目编号:2021YFG0133)的资助。

## References

## 参考文献

[1] K. Simonyan, A. Zisserman, Very deep convolutional networks for large-scale image recognition, in: International Conference on Learning Representations, ICLR, 2015.

[1] K. Simonyan, A. Zisserman, 用于大规模图像识别的深度卷积网络，见:国际学习表征会议(ICLR)，2015年。

[2] K. He, X. Zhang, S. Ren, J. Sun, Deep residual learning for image recognition, in: IEEE Conference on Computer Vision and Pattern Recognition, CVPR, 2016, pp. 770-778.

[2] K. He, X. Zhang, S. Ren, J. Sun, 用于图像识别的深度残差学习，见:电气与电子工程师协会计算机视觉与模式识别会议(CVPR)，2016年，第770 - 778页。

[3] A. Chetouani, L. Li, On the use of a scanpath predictor and convolutional neural network for blind image quality assessment, Signal Process., Image Commun. 89 (2020).

[3] A. 谢图阿尼(A. Chetouani)、L. 李(L. Li)，《关于使用扫描路径预测器和卷积神经网络进行盲图像质量评估》，《信号处理与图像通信》(Signal Process., Image Commun.)，第89卷(2020年)。

[4] N. Passalis, A. Tefas, Deep supervised hashing using quadratic spherical mutual information for efficient image retrieval, Signal Process., Image Commun. 93 (2021).

[4] N. 帕萨利斯(N. Passalis)、A. 泰法斯(A. Tefas)，《使用二次球面互信息的深度监督哈希用于高效图像检索》，《信号处理与图像通信》(Signal Process., Image Commun.)，第93卷(2021年)。

[5] E.R. Rezende, G.C. Ruppert, A. Theophilo, E.K. Tokuda, T. Carvalho, Exposing computer generated images by using deep convolutional neural networks, Signal Process., Image Commun. 66 (2018) 113-126.

[5] E.R. 雷森德(E.R. Rezende)、G.C. 鲁珀特(G.C. Ruppert)、A. 西奥菲洛(A. Theophilo)、E.K. 托库达(E.K. Tokuda)、T. 卡瓦略(T. Carvalho)，《使用深度卷积神经网络揭露计算机生成图像》，《信号处理与图像通信》(Signal Process., Image Commun.)，第66卷(2018年)，第113 - 126页。

[6] M. Fanfani, M. Iuliani, F. Bellavia, C. Colombo, A. Piva, A vision-based fully automated approach to robust image cropping detection, Signal Process., Image Commun. 80 (2020).

[6] M. 范法尼(M. Fanfani)、M. 尤利亚尼(M. Iuliani)、F. 贝拉维亚(F. Bellavia)、C. 科伦坡(C. Colombo)、A. 皮瓦(A. Piva)，《一种基于视觉的全自动鲁棒图像裁剪检测方法》，《信号处理与图像通信》(Signal Process., Image Commun.)，第80卷(2020年)。

[7] R. Salakhutdinov, A. Torralba, J. Tenenbaum, Learning to share visual appearance for multiclass object detection, in: IEEE Conference on Computer Vision and Pattern Recognition, CVPR, 2011, pp. 1481-1488.

[7] R. 萨拉胡季诺夫(R. Salakhutdinov)、A. 托拉尔巴(A. Torralba)、J. 特南鲍姆(J. Tenenbaum)，《学习共享视觉外观用于多类目标检测》，收录于:《电气与电子工程师协会计算机视觉与模式识别会议论文集》(IEEE Conference on Computer Vision and Pattern Recognition, CVPR)，2011年，第1481 - 1488页。

[8] X. Zhu, D. Anguelov, D. Ramanan, Capturing long-tail distributions of object subcategories, in: IEEE Conference on Computer Vision and Pattern Recognition, CVPR, 2014, pp. 915-922.

[8] X. 朱(X. Zhu)、D. 安格洛夫(D. Anguelov)、D. 拉马南(D. Ramanan)，《捕捉目标子类别长尾分布》，收录于:《电气与电子工程师协会计算机视觉与模式识别会议论文集》(IEEE Conference on Computer Vision and Pattern Recognition, CVPR)，2014年，第915 - 922页。

[9] A. Farhadi, I. Endres, D. Hoiem, D. Forsyth, Describing objects by their attributes, in: IEEE Conference on Computer Vision and Pattern Recognition, CVPR, 2009, pp. 1778-1785.

[9] A. 法尔哈迪(A. Farhadi)、I. 恩德斯(I. Endres)、D. 霍耶姆(D. Hoiem)、D. 福赛思(D. Forsyth)，《通过属性描述目标》，收录于:《电气与电子工程师协会计算机视觉与模式识别会议论文集》(IEEE Conference on Computer Vision and Pattern Recognition, CVPR)，2009年，第1778 - 1785页。

[10] Z. Akata, F. Perronnin, Z. Harchaoui, C. Schmid, Label-embedding for image classification, IEEE Trans. Pattern Anal. Mach. Intell. 38 (7) (2016) 1425-1438.

[10] Z. 阿卡塔(Z. Akata)、F. 佩罗宁(F. Perronnin)、Z. 哈查维(Z. Harchaoui)、C. 施密德(C. Schmid)，《用于图像分类的标签嵌入》，《电气与电子工程师协会模式分析与机器智能汇刊》(IEEE Trans. Pattern Anal. Mach. Intell.)，第38卷(第7期)(2016年)，第1425 - 1438页。

[11] E. Kodirov, T. Xiang, S. Gong, Semantic autoencoder for zero-shot learning, in: IEEE Conference on Computer Vision and Pattern Recognition, CVPR, 2017, pp. 4447-4456.

[11] E. 科迪罗夫(E. Kodirov)、T. 向(T. Xiang)、S. 龚(S. Gong)，《用于零样本学习的语义自编码器》，收录于:《电气与电子工程师协会计算机视觉与模式识别会议论文集》(IEEE Conference on Computer Vision and Pattern Recognition, CVPR)，2017年，第4447 - 4456页。

[12] M. Elhoseiny, M. Elfeki, Creativity inspired zero-shot learning, in: IEEE/CVF International Conference on Computer Vision, ICCV, 2019, pp. 5783-5792.

[12] M. 埃尔霍塞尼(M. Elhoseiny)、M. 埃尔费基(M. Elfeki)，《受创造力启发的零样本学习》，收录于:《电气与电子工程师协会/计算机视觉基金会国际计算机视觉会议论文集》(IEEE/CVF International Conference on Computer Vision, ICCV)，2019年，第5783 - 5792页。

[13] A. Frome, G.S. Corrado, J. Shlens, S. Bengio, J. Dean, A. Ranzato, T. Mikolov, DeViSE: A deep visual-semantic embedding model, in: Advances in Neural Information Processing Systems, NIPS, 2013, pp. 2121-2129.

[13] A. 弗罗姆(A. Frome)、G.S. 科拉多(G.S. Corrado)、J. 什伦斯(J. Shlens)、S. 本吉奥(S. Bengio)、J. 迪恩(J. Dean)、A. 兰扎托(A. Ranzato)、T. 米科洛夫(T. Mikolov)，《DeViSE:一种深度视觉 - 语义嵌入模型》，收录于:《神经信息处理系统进展》(Advances in Neural Information Processing Systems, NIPS)，2013年，第2121 - 2129页。

[14] M. Elhoseiny, B. Saleh, A. Elgammal, Write a classifier: Zero-shot learning using purely textual descriptions, in: IEEE International Conference on Computer Vision, ICCV, 2013, pp. 2584-2591.

[14] M. 埃尔霍塞尼(M. Elhoseiny)、B. 萨利赫(B. Saleh)、A. 埃尔加马尔(A. Elgammal)，《编写分类器:使用纯文本描述的零样本学习》，收录于:《电气与电子工程师协会国际计算机视觉会议论文集》(IEEE International Conference on Computer Vision, ICCV)，2013年，第2584 - 2591页。

[15] P. Morgado, N. Vasconcelos, Semantically consistent regularization for zero-shot recognition, in: IEEE Conference on Computer Vision and Pattern Recognition, CVPR, 2017, pp. 2037-2046.

[15] P. 莫尔加多(P. Morgado)、N. 瓦斯康塞洛斯(N. Vasconcelos)，《用于零样本识别的语义一致正则化》，收录于:《电气与电子工程师协会计算机视觉与模式识别会议论文集》(IEEE Conference on Computer Vision and Pattern Recognition, CVPR)，2017年，第2037 - 2046页。

[16] B. Demirel, R.G. Cinbis, N. Ikizler-Cinbis, Attributes2Classname: A discriminative model for attribute-based unsupervised zero-shot learning, in: IEEE International Conference on Computer Vision, ICCV, 2017, pp. 1241-1250.

[16] B. 德米雷尔(B. Demirel)、R.G. 钦比斯(R.G. Cinbis)、N. 伊基兹勒 - 钦比斯(N. Ikizler - Cinbis)，《Attributes2Classname:一种基于属性的无监督零样本学习判别模型》，收录于:《电气与电子工程师协会国际计算机视觉会议论文集》(IEEE International Conference on Computer Vision, ICCV)，2017年，第1241 - 1250页。

[17] Y. Zhu, M. Elhoseiny, B. Liu, X. Peng, A. Elgammal, A generative adversarial approach for zero-shot learning from noisy texts, in: IEEE/CVF Conference on Computer Vision and Pattern Recognition, 2018, pp. 1004-1013.

[17] Y. 朱(Y. Zhu)、M. 埃尔霍塞尼(M. Elhoseiny)、B. 刘(B. Liu)、X. 彭(X. Peng)、A. 埃尔加马尔(A. Elgammal)，《一种从嘈杂文本进行零样本学习的生成对抗方法》，收录于:《电气与电子工程师协会/计算机视觉基金会计算机视觉与模式识别会议论文集》(IEEE/CVF Conference on Computer Vision and Pattern Recognition)，2018年，第1004 - 1013页。

[18] J. Liu, K. Song, Y. He, H. Dong, Y. Yan, Q. Meng, Learning object-centric complementary features for zero-shot learning, Signal Process., Image Commun. 89 (2020).

[18] J. 刘(J. Liu)、K. 宋(K. Song)、Y. 何(Y. He)、H. 董(H. Dong)、Y. 严(Y. Yan)、Q. 孟(Q. Meng)，《学习以目标为中心的互补特征用于零样本学习》，《信号处理与图像通信》(Signal Process., Image Commun.)，第89卷(2020年)。

[19] C.H. Lampert, H. Nickisch, S. Harmeling, Attribute-based classification for zero-shot visual object categorization, IEEE Trans. Pattern Anal. Mach. Intell. 36 (3) (2014) 453-465.

[19] C.H. 兰珀特(C.H. Lampert)、H. 尼基施(H. Nickisch)、S. 哈梅林(S. Harmeling)，基于属性的零样本视觉目标分类，《电气与电子工程师协会模式分析与机器智能汇刊》(IEEE Trans. Pattern Anal. Mach. Intell.)36 (3) (2014) 453 - 465。

[20] Z. Akata, S. Reed, D. Walter, B. Schiele, Evaluation of output embeddings for fine-grained image classification, in: IEEE Conference on Computer Vision and Pattern Recognition, CVPR, 2015, pp. 2927-2936.

[20] Z. 阿卡塔(Z. Akata)、S. 里德(S. Reed)、D. 沃尔特(D. Walter)、B. 席勒(B. Schiele)，细粒度图像分类输出嵌入的评估，见:《电气与电子工程师协会计算机视觉与模式识别会议论文集》(IEEE Conference on Computer Vision and Pattern Recognition, CVPR)，2015 年，第 2927 - 2936 页。

[21] Y. Xian, Z. Akata, G. Sharma, Q. Nguyen, M. Hein, B. Schiele, Latent embeddings for zero-shot classification, in: IEEE Conference on Computer Vision and Pattern Recognition, CVPR, 2016, pp. 69-77.

[21] Y. 西安(Y. Xian)、Z. 阿卡塔(Z. Akata)、G. 夏尔马(G. Sharma)、Q. 阮(Q. Nguyen)、M. 海因(M. Hein)、B. 席勒(B. Schiele)，零样本分类的潜在嵌入，见:《电气与电子工程师协会计算机视觉与模式识别会议论文集》(IEEE Conference on Computer Vision and Pattern Recognition, CVPR)，2016 年，第 69 - 77 页。

[22] Z. Ding, M. Shao, Y. Fu, Low-rank embedded ensemble semantic dictionary for zero-shot learning, in: 2017 IEEE Conference on Computer Vision and Pattern Recognition, CVPR, 2017, pp. 6005-6013.

[22] Z. 丁(Z. Ding)、M. 邵(M. Shao)、Y. 傅(Y. Fu)，用于零样本学习的低秩嵌入集成语义字典，见:《2017 年电气与电子工程师协会计算机视觉与模式识别会议论文集》(2017 IEEE Conference on Computer Vision and Pattern Recognition, CVPR)，2017 年，第 6005 - 6013 页。

[23] Z. Ding, H. Liu, Marginalized latent semantic encoder for zero-shot learning, in: IEEE/CVF Conference on Computer Vision and Pattern Recognition, CVPR, 2019, pp. 6184-6192.

[23] Z. 丁(Z. Ding)、H. 刘(H. Liu)，用于零样本学习的边缘化潜在语义编码器，见:《电气与电子工程师协会/计算机视觉基金会计算机视觉与模式识别会议论文集》(IEEE/CVF Conference on Computer Vision and Pattern Recognition, CVPR)，2019 年，第 6184 - 6192 页。

[24] J. Song, C. Shen, J. Lei, A.-X. Zeng, K. Ou, D. Tao, M. Song, Selective zero-shot classification with augmented attributes, in: European Conference on Computer Vision, ECCV, 2018, pp. 474-490.

[24] J. 宋(J. Song)、C. 沈(C. Shen)、J. 雷(J. Lei)、A.-X. 曾(A.-X. Zeng)、K. 欧(K. Ou)、D. 陶(D. Tao)、M. 宋(M. Song)，具有增强属性的选择性零样本分类，见:《欧洲计算机视觉会议论文集》(European Conference on Computer Vision, ECCV)，2018 年，第 474 - 490 页。

[25] M. Aharon, M. Elad, A. Bruckstein, K-SVD: An algorithm for designing overcom-

[25] M. 阿哈龙(M. Aharon)、M. 埃拉德(M. Elad)、A. 布鲁克斯坦(A. Bruckstein)，K - SVD:一种用于设计过完备稀疏表示字典的算法

plete dictionaries for sparse representation, IEEE Trans. Signal Process. 54 (11) (2006) 4311-4322.

，《电气与电子工程师协会信号处理汇刊》(IEEE Trans. Signal Process.)54 (11) (2006) 4311 - 4322。

[26] X. Li, M. Fang, D. Feng, HaikunLi, J. Wu, Prototype adjustment for zero shot classification, Signal Process., Image Commun. 74 (2019) 242-252.

[26] X. 李(X. Li)、M. 方(M. Fang)、D. 冯(D. Feng)、李海昆(HaikunLi)、J. 吴(J. Wu)，零样本分类的原型调整，《信号处理:图像通信》(Signal Process., Image Commun.)74 (2019) 242 - 252。

[27] Y.L. Cacheux, H.L. Borgne, M. Crucianu, Modeling inter and intra-class relations in the triplet loss for zero-shot learning, in: IEEE/CVF International Conference on Computer Vision, ICCV, 2019, pp. 10332-10341.

[27] Y.L. 卡谢(Y.L. Cacheux)、H.L. 博尔涅(H.L. Borgne)、M. 克鲁恰努(M. Crucianu)，零样本学习三元组损失中的类间和类内关系建模，见:《电气与电子工程师协会/计算机视觉基金会国际计算机视觉会议论文集》(IEEE/CVF International Conference on Computer Vision, ICCV)，2019 年，第 10332 - 10341 页。

[28] H. Zhang, P. Koniusz, Zero-shot kernel learning, in: IEEE/CVF Conference on Computer Vision and Pattern Recognition, CVPR, 2018, pp. 7670-7679.

[28] H. 张(H. Zhang)、P. 科尼乌斯(P. Koniusz)，零样本核学习，见:《电气与电子工程师协会/计算机视觉基金会计算机视觉与模式识别会议论文集》(IEEE/CVF Conference on Computer Vision and Pattern Recognition, CVPR)，2018 年，第 7670 - 7679 页。

[29] Y. Guo, G. Ding, J. Han, Y. Gao, Synthesizing samples for zero-shot learning, in: International Joint Conference on Artificial Intelligence, IJCAI, 2017, pp. 1774-1780.

[29] Y. 郭(Y. Guo)、G. 丁(G. Ding)、J. 韩(J. Han)、Y. 高(Y. Gao)，零样本学习的样本合成，见:《国际人工智能联合会议论文集》(International Joint Conference on Artificial Intelligence, IJCAI)，2017 年，第 1774 - 1780 页。

[30] W. Wang, Y. Pu, V.K. Verma, K. Fan, et al., Zero-shot learning via class-conditioned deep generative models, in: The AAAI Conference on Artificial Intelligence, AAAI, 2017, pp. 1774-1780.

[30] W. 王(W. Wang)、Y. 蒲(Y. Pu)、V.K. 维尔马(V.K. Verma)、K. 范(K. Fan)等，通过类条件深度生成模型进行零样本学习，见:《美国人工智能协会会议论文集》(The AAAI Conference on Artificial Intelligence, AAAI)，2017 年，第 1774 - 1780 页。

[31] R. Keshari, R. Singh, M. Vatsa, Generalized zero-shot learning via overcomplete distribution, in: IEEE/CVF Conference on Computer Vision and Pattern Recognition, CVPR, 2020, pp. 13297-13305.

[31] R. 凯沙里(R. Keshari)、R. 辛格(R. Singh)、M. 瓦萨(M. Vatsa)，通过过完备分布进行广义零样本学习，见:《电气与电子工程师协会/计算机视觉基金会计算机视觉与模式识别会议论文集》(IEEE/CVF Conference on Computer Vision and Pattern Recognition, CVPR)，2020 年，第 13297 - 13305 页。

[32] X. Li, M. Fang, B. Chen, Generalized zero-shot classification via iteratively generating and selecting unseen samples, Signal Process., Image Commun. 92 (2021).

[32] X. 李(X. Li)、M. 方(M. Fang)、B. 陈(B. Chen)，通过迭代生成和选择未见样本进行广义零样本分类，《信号处理:图像通信》(Signal Process., Image Commun.)92 (2021)。

[33] I. Goodfellow, J. Pouget-Abadie, M. Mirza, B. Xu, D. Warde-Farley, S. Ozair, A. Courville, Y. Bengio, Generative adversarial nets, in: Advances in Neural Information Processing Systems, NIPS, 2014, pp. 2672-2680.

[33] I. 古德费洛(I. Goodfellow)、J. 普热-阿巴迪(J. Pouget - Abadie)、M. 米尔扎(M. Mirza)、B. 徐(B. Xu)、D. 沃德 - 法利(D. Warde - Farley)、S. 奥扎尔(S. Ozair)、A. 库尔维尔(A. Courville)、Y. 本吉奥(Y. Bengio)，生成对抗网络，见:《神经信息处理系统进展》(Advances in Neural Information Processing Systems, NIPS)，2014 年，第 2672 - 2680 页。

[34] M. Arjovsky, L. Bottou, Towards principled methods for training generative adversarial networks, in: The International Conference on Learning Representations, ICLR, 2017.

[34] M. 阿尔乔夫斯基(M. Arjovsky)、L. 博图(L. Bottou)，《迈向训练生成对抗网络的原则性方法》，载于:国际学习表征会议(The International Conference on Learning Representations，ICLR)，2017 年。

[35] S. Biswas, Y. Annadani, Preserving semantic relations for zero-shot learning, in: IEEE Conference on Computer Vision and Pattern Recognition, CVPR, 2018, pp. 7603-7612.

[35] S. 比斯瓦斯(S. Biswas)、Y. 安纳达尼(Y. Annadani)，《零样本学习中语义关系的保留》，载于:电气与电子工程师协会计算机视觉与模式识别会议(IEEE Conference on Computer Vision and Pattern Recognition，CVPR)，2018 年，第 7603 - 7612 页。

[36] B. Tong, C. Wang, M. Klinkigt, Y. Kobayashi, Y. Nonaka, Hierarchical disentanglement of discriminative latent features for zero-shot learning, in: The IEEE Conference on Computer Vision and Pattern Recognition, CVPR, 2019, pp. 11459-11468.

[36] B. 童(B. Tong)、C. 王(C. Wang)、M. 克林基格特(M. Klinkigt)、Y. 小林(Y. Kobayashi)、Y. 野中(Y. Nonaka)，《零样本学习中判别性潜在特征的分层解缠》，载于:电气与电子工程师协会计算机视觉与模式识别会议(The IEEE Conference on Computer Vision and Pattern Recognition，CVPR)，2019 年，第 11459 - 11468 页。

[37] S. Purushwalkam, M. Nickel, A. Gupta, M. Ranzato, Task-driven modular networks for zero-shot compositional learning, in: IEEE/CVF International Conference on Computer Vision, ICCV, 2019, pp. 3592-3601.

[37] S. 普鲁什瓦尔卡姆(S. Purushwalkam)、M. 尼克(M. Nickel)、A. 古普塔(A. Gupta)、M. 兰扎托(M. Ranzato)，《用于零样本组合学习的任务驱动模块化网络》，载于:电气与电子工程师协会/计算机视觉基金会国际计算机视觉会议(IEEE/CVF International Conference on Computer Vision，ICCV)，2019 年，第 3592 - 3601 页。

[38] Y. Xian, C.H. Lampert, B. Schiele, Z. Akata, Zero-shot learning - A comprehensive evaluation of the good, the bad and the ugly, IEEE Trans. Pattern Anal. Mach. Intell. 41 (9) (2019) 2251-2265.

[38] Y. 西安(Y. Xian)、C.H. 兰佩特(C.H. Lampert)、B. 席勒(B. Schiele)、Z. 阿卡塔(Z. Akata)，《零样本学习——对好坏丑的全面评估》，《电气与电子工程师协会模式分析与机器智能汇刊》(IEEE Trans. Pattern Anal. Mach. Intell.)41 (9) (2019) 2251 - 2265。

[39] S. Liu, M. Long, J. Wang, M.I. Jordan, Generalized zero-shot learning with deep calibration network, in: Advances in Neural Information Processing Systems, Vol. 31, NIPS, 2018, pp. 2005-2015.

[39] S. 刘(S. Liu)、M. 龙(M. Long)、J. 王(J. Wang)、M.I. 乔丹(M.I. Jordan)，《基于深度校准网络的广义零样本学习》，载于:《神经信息处理系统进展》(Advances in Neural Information Processing Systems)，第 31 卷，神经信息处理系统大会(NIPS)，2018 年，第 2005 - 2015 页。

[40] J. Mairal, J. Ponce, G. Sapiro, A. Zisserman, F. Bach, Supervised dictionary learning, in: Advances in Neural Information Processing Systems, Vol. 21, NIPS, 2009, pp. 1033-1040.

[40] J. 梅拉勒(J. Mairal)、J. 庞斯(J. Ponce)、G. 萨皮罗(G. Sapiro)、A. 齐斯曼(A. Zisserman)、F. 巴赫(F. Bach)，《有监督字典学习》，载于:《神经信息处理系统进展》(Advances in Neural Information Processing Systems)，第 21 卷，神经信息处理系统大会(NIPS)，2009 年，第 1033 - 1040 页。

[41] Z. Jiang, Z. Lin, L.S. Davis, Label consistent K-SVD: Learning a discriminative dictionary for recognition, IEEE Trans. Pattern Anal. Mach. Intell. 35 (11) (2013) 2651-2664.

[41] Z. 江(Z. Jiang)、Z. 林(Z. Lin)、L.S. 戴维斯(L.S. Davis)，《标签一致 K - SVD:学习用于识别的判别性字典》，《电气与电子工程师协会模式分析与机器智能汇刊》(IEEE Trans. Pattern Anal. Mach. Intell.)35 (11) (2013) 2651 - 2664。

[42] Q. Zhang, B. Li, Discriminative K-SVD for dictionary learning in face recognition, in: IEEE Conference on Computer Vision and Pattern Recognition, CVPR, 2010, pp. 2691-2698.

[42] Q. 张(Q. Zhang)、B. 李(B. Li)，《用于人脸识别字典学习的判别性 K - SVD》，载于:电气与电子工程师协会计算机视觉与模式识别会议(IEEE Conference on Computer Vision and Pattern Recognition，CVPR)，2010 年，第 2691 - 2698 页。

[43] H. Lee, A. Battle, R. Raina, A.Y. Ng, Efficient sparse coding algorithms, in: The Conference on Neural Information Processing Systems, NIPS, 2007, pp. 801-808.

[43] H. 李(H. Lee)、A. 巴特尔(A. Battle)、R. 雷纳(R. Raina)、A.Y. 吴(A.Y. Ng)，《高效稀疏编码算法》，载于:神经信息处理系统会议(The Conference on Neural Information Processing Systems，NIPS)，2007 年，第 801 - 808 页。

[44] C.H. Lampert, H. Nickisch, S. Harmeling, Attribute-based classification for zero-shot visual object categorization, IEEE Trans. Pattern Anal. Mach. Intell. 36 (3) (2014) 453-465.

[44] C.H. 兰佩特(C.H. Lampert)、H. 尼克isch(H. Nickisch)、S. 哈梅林(S. Harmeling)，《基于属性的分类用于零样本视觉对象分类》，《电气与电子工程师协会模式分析与机器智能汇刊》(IEEE Trans. Pattern Anal. Mach. Intell.)36 (3) (2014) 453 - 465。

[45] C. Wah, S. Branson, P. Perona, S. Belongie, Multiclass recognition and part localization with humans in the loop, in: 2011 International Conference on Computer Vision, 2011, pp. 2524-2531.

[45] C. 瓦(C. Wah)、S. 布兰森(S. Branson)、P. 佩罗纳(P. Perona)、S. 贝隆吉(S. Belongie)，《有人参与的多类识别和部件定位》，载于:2011 年国际计算机视觉会议(2011 International Conference on Computer Vision)，2011 年，第 2524 - 2531 页。

[46] G. Patterson, J. Hays, SUN attribute database: Discovering, annotating, and recognizing scene attributes, in: IEEE Conference on Computer Vision and Pattern Recognition, CVPR, 2012, pp. 2751-2758.

[46] G. 帕特森(G. Patterson)、J. 海斯(J. Hays)，《SUN 属性数据库:发现、标注和识别场景属性》，载于:电气与电子工程师协会计算机视觉与模式识别会议(IEEE Conference on Computer Vision and Pattern Recognition，CVPR)，2012 年，第 2751 - 2758 页。

[47] H. Jiang, R. Wang, S. Shan, X. Chen, Learning class prototypes via structure alignment for zero-shot recognition, in: European Conference on Computer Vision, ECCV, 2018, pp. 121-138.

[47] H. 江(H. Jiang)、R. 王(R. Wang)、S. 单(S. Shan)、X. 陈(X. Chen)，《通过结构对齐学习类原型用于零样本识别》，载于:欧洲计算机视觉会议(European Conference on Computer Vision，ECCV)，2018 年，第 121 - 138 页。

[48] R. Socher, M. Ganjoo, C.D. Manning, A. Ng, Zero-shot learning through cross-modal transfer, in: Advances in Neural Information Processing Systems, NIPS, 2013, pp. 935-943.

[48] R. 索切尔(R. Socher)、M. 甘乔(M. Ganjoo)、C.D. 曼宁(C.D. Manning)、A. 吴(A. Ng)，《通过跨模态转移进行零样本学习》，载于:《神经信息处理系统进展》(Advances in Neural Information Processing Systems)，神经信息处理系统大会(NIPS)，2013 年，第 935 - 943 页。

[49] B. Romera-Paredes, P.H. Torr, An embarrassingly simple approach to zero-shot learning, in: International Conference on Machine Learning, ICML, 2015, pp. 2152-2161.

[49] B. 罗梅拉 - 帕雷德斯(B. Romera - Paredes)、P.H. 托尔(P.H. Torr)，《一种极其简单的零样本学习方法》，载于:国际机器学习会议(International Conference on Machine Learning，ICML)，2015 年，第 2152 - 2161 页。

[50] V.K. Verma, G. Arora, A. Mishra, P. Rai, Generalized zero-shot learning via synthesized examples, in: IEEE/CVF Conference on Computer Vision and Pattern Recognition, CVPR, 2018, pp. 4281-4289.

[50] V.K. 维尔马(V.K. Verma)、G. 阿罗拉(G. Arora)、A. 米什拉(A. Mishra)、P. 拉伊(P. Rai)，通过合成示例实现广义零样本学习，见:电气与电子工程师协会/计算机视觉基金会计算机视觉与模式识别会议(IEEE/CVF Conference on Computer Vision and Pattern Recognition，CVPR)，2018 年，第 4281 - 4289 页。

[51] Y. Zhu, J. Xie, B. Liu, A. Elgammal, Learning feature-to-feature translator by alternating back-propagation for generative zero-shot learning, in: 2019 IEEE/CVF International Conference on Computer Vision, ICCV, 2019, pp. 9843-9853.

[51] Y. 朱(Y. Zhu)、J. 谢(J. Xie)、B. 刘(B. Liu)、A. 埃尔加马尔(A. Elgammal)，通过交替反向传播学习特征到特征的转换器以实现生成式零样本学习，见:2019 年电气与电子工程师协会/计算机视觉基金会国际计算机视觉会议(2019 IEEE/CVF International Conference on Computer Vision，ICCV)，2019 年，第 9843 - 9853 页。

[52] M. Norouzi, T. Mikolov, S. Bengio, Y. Singer, J. Shlens, A. Frome, G. Corrado, J. Dean, Zero-shot learning by convex combination of semantic embeddings, in: The International Conference on Learning Representations, ICLR, 2014.

[52] M. 诺鲁兹(M. Norouzi)、T. 米科洛夫(T. Mikolov)、S. 本吉奥(S. Bengio)、Y. 辛格(Y. Singer)、J. 施伦斯(J. Shlens)、A. 弗罗姆(A. Frome)、G. 科拉多(G. Corrado)、J. 迪恩(J. Dean)，通过语义嵌入的凸组合实现零样本学习，见:国际学习表征会议(The International Conference on Learning Representations，ICLR)，2014 年。

[53] Z. Zhang, V. Saligrama, Zero-shot learning via semantic similarity embedding, in: IEEE International Conference on Computer Vision, ICCV, 2015, pp. 4166-4174.

[53] Z. 张(Z. Zhang)、V. 萨利格拉马(V. Saligrama)，通过语义相似性嵌入实现零样本学习，见:电气与电子工程师协会国际计算机视觉会议(IEEE International Conference on Computer Vision，ICCV)，2015 年，第 4166 - 4174 页。

[54] J. Li, M. Jing, K. Lu, Z. Ding, L. Zhu, Z. Huang, Leveraging the invariant side of generative zero-shot learning, in: IEEE/CVF Conference on Computer Vision and Pattern Recognition, CVPR, 2019, pp. 7394-7403.

[54] J. 李(J. Li)、M. 景(M. Jing)、K. 陆(K. Lu)、Z. 丁(Z. Ding)、L. 朱(L. Zhu)、Z. 黄(Z. Huang)，利用生成式零样本学习的不变性方面，见:电气与电子工程师协会/计算机视觉基金会计算机视觉与模式识别会议(IEEE/CVF Conference on Computer Vision and Pattern Recognition，CVPR)，2019 年，第 7394 - 7403 页。

[55] S. Changpinyo, W. Chao, B. Gong, F. Sha, Synthesized classifiers for zero-shot learning, in: IEEE Conference on Computer Vision and Pattern Recognition, CVPR, 2016, pp. 5327-5336.

[55] S. 张品耀(S. Changpinyo)、W. 赵(W. Chao)、B. 龚(B. Gong)、F. 沙(F. Sha)，用于零样本学习的合成分类器，见:电气与电子工程师协会计算机视觉与模式识别会议(IEEE Conference on Computer Vision and Pattern Recognition，CVPR)，2016 年，第 5327 - 5336 页。

[56] R. Gao, X. Hou, J. Qin, L. Liu, F. Zhu, Z. Zhang, A joint generative model for zero-shot learning, in: Proceedings of the European Conference on Computer Vision (ECCV) Workshops, 2018, pp. 631-646.

[56] R. 高(R. Gao)、X. 侯(X. Hou)、J. 秦(J. Qin)、L. 刘(L. Liu)、F. 朱(F. Zhu)、Z. 张(Z. Zhang)，用于零样本学习的联合生成模型，见:欧洲计算机视觉会议(European Conference on Computer Vision，ECCV)研讨会论文集，2018 年，第 631 - 646 页。

[57] V.K. Verma, P. Rai, A simple exponential family framework for zero-shot learning, in: European Conference on Machine Learning and Knowledge Discovery in Databases, ECML, 2017, pp. 792-808.

[57] V.K. 维尔马(V.K. Verma)、P. 拉伊(P. Rai)，用于零样本学习的简单指数族框架，见:欧洲机器学习与数据库知识发现会议(European Conference on Machine Learning and Knowledge Discovery in Databases，ECML)，2017 年，第 792 - 808 页。

[58] P. Zhu, H. Wang, V. Saligrama, Generalized zero-shot recognition based on visually semantic embedding, in: IEEE/CVF Conference on Computer Vision and Pattern Recognition, CVPR, 2019, pp. 2990-2998.

[58] P. 朱(P. Zhu)、H. 王(H. Wang)、V. 萨利格拉马(V. Saligrama)，基于视觉语义嵌入的广义零样本识别，见:电气与电子工程师协会/计算机视觉基金会计算机视觉与模式识别会议(IEEE/CVF Conference on Computer Vision and Pattern Recognition，CVPR)，2019 年，第 2990 - 2998 页。

[59] K. Chatfield, K. Simonyan, A. Vedaldi, A. Zisserman, Return of the devil in the details: Delving deep into convolutional nets, in: British Machine Vision Conference, BMVC, 2014.

[59] K. 查特菲尔德(K. Chatfield)、K. 西莫扬(K. Simonyan)、A. 韦达利(A. Vedaldi)、A. 齐斯曼(A. Zisserman)，细节决定成败:深入研究卷积网络，见:英国机器视觉会议(British Machine Vision Conference，BMVC)，2014 年。

[60] C. Szegedy, W. Liu, Y. Jia, P. Sermanet, S. Reed, D. Anguelov, D. Erhan, V. Vanhoucke, A. Rabinovich, Going deeper with convolutions, in: IEEE Conference on Computer Vision and Pattern Recognition, CVPR, 2015, pp. 1-9.

[60] C. 塞格迪(C. Szegedy)、W. 刘(W. Liu)、Y. 贾(Y. Jia)、P. 塞尔马内特(P. Sermanet)、S. 里德(S. Reed)、D. 安格洛夫(D. Anguelov)、D. 埃尔汉(D. Erhan)、V. 范霍克(V. Vanhoucke)、A. 拉宾诺维奇(A. Rabinovich)，卷积网络的深度探索，见:电气与电子工程师协会计算机视觉与模式识别会议(IEEE Conference on Computer Vision and Pattern Recognition，CVPR)，2015 年，第 1 - 9 页。

[61] M. Tan, Q.V. Le, EfficientNet: Rethinking model scaling for convolutional neural networks, in: International Conference on Machine Learning, Vol. 97, ICML, 2019, pp. 6105-6114.

[61] M. 谭(M. Tan)、Q.V. 勒(Q.V. Le)，EfficientNet:重新思考卷积神经网络的模型缩放，见:国际机器学习会议(International Conference on Machine Learning)，第 97 卷，2019 年，第 6105 - 6114 页。

[62] L.V. der Maaten, G. Hinton, Viualizing data using t-SNE, J. Mach. Learn. Res. 9 (2008) 2579-2605.

[62] L.V. 德马坦(L.V. der Maaten)、G. 辛顿(G. Hinton)，使用 t - SNE 可视化数据，《机器学习研究杂志》(J. Mach. Learn. Res.)9(2008)2579 - 2605。