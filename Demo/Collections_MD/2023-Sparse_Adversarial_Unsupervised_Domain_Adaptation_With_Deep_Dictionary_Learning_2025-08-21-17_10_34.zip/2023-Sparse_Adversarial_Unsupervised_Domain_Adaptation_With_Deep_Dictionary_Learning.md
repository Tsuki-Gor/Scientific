# Sparse Adversarial Unsupervised Domain Adaptation With Deep Dictionary Learning for Traffic Scene Classification

# 基于深度字典学习的稀疏对抗无监督领域自适应用于交通场景分类

Mohsen Saffari ${}^{\circledR }$ , Student Member, IEEE, Mahdi Khodayar ${}^{\circledR }$ , Member, IEEE, and Seyed Mohammad Jafar Jalali, Member, IEEE

Mohsen Saffari ${}^{\circledR }$ ，IEEE学生会员，Mahdi Khodayar ${}^{\circledR }$ ，IEEE会员，Seyed Mohammad Jafar Jalali，IEEE会员

Abstract-In recent years, the accurate recognition of traffic scenes has played a key role in autonomous vehicle operations. However, most works in this area do not address the domain shift issue where the classification performance is degraded when the distribution of the source and target images are different due to weather changes. Also, lack of sparsity of current studies results in sample complexity and overfitting issues. To mitigate these challenges, this paper proposes a novel Sparse Adversarial Domain Adaptation (SADA) model for traffic scene classification. Our objective is to learn a scene classifier on a source domain with sunny weather and transfer its knowledge to a target domain with different weather (i.e., cloudy, rainy, and snowy) to enhance the classification performance on the target. First, a sparse representation is learned from the source traffic scenes via nonlinear dictionary learning in the latent space of a deep classifier. Then, a conditional generative adversarial network is devised to capture the distribution of the source sparse codes. Finally, a domain invariant sparse feature extractor is developed via a minimax game to align the sparse codes of the target domain images with the source; hence, providing domain adaptation for traffic scene classification using a deep neural network. Experimental results on a real-world dataset collected by the Honda Research Institute (HRI) indicate the superior performance of the proposed SADA compared to current traffic scene classification methods and state-of-the-art domain adaptation frameworks.

摘要——近年来，交通场景的准确识别在自动驾驶车辆的运行中发挥了关键作用。然而，该领域的大多数研究未能解决领域偏移问题，即由于天气变化导致源域和目标域图像分布不同，从而使分类性能下降。此外，现有研究缺乏稀疏性，导致样本复杂度高和过拟合问题。为缓解这些挑战，本文提出了一种新颖的稀疏对抗领域自适应(Sparse Adversarial Domain Adaptation，SADA)模型用于交通场景分类。我们的目标是在晴朗天气的源域上学习场景分类器，并将其知识迁移到具有不同天气(如多云、雨天和雪天)的目标域，以提升目标域的分类性能。首先，通过深度分类器的潜在空间中的非线性字典学习，从源交通场景中学习稀疏表示。然后，设计条件生成对抗网络以捕捉源域稀疏编码的分布。最后，通过极小极大博弈开发域不变稀疏特征提取器，使目标域图像的稀疏编码与源域对齐，从而利用深度神经网络实现交通场景分类的领域自适应。在本田研究院(Honda Research Institute，HRI)收集的真实数据集上的实验结果表明，所提SADA方法在性能上优于当前的交通场景分类方法及最先进的领域自适应框架。

Index Terms-Adversarial learning, deep neural networks, dictionary learning, domain adaptation, traffic scene classification.

关键词——对抗学习，深度神经网络，字典学习，领域自适应，交通场景分类。

## I. INTRODUCTION

## 一、引言

NOWADAYS, due to the increasing interest in autonomous vehicles, recognition of the traffic scenes captured by mounted front cameras has become an active research field in the intelligent transportation system realm. Traffic scene understanding can provide valuable information for real-time decision-making in autonomous vehicles; for instance, recognizing intersections helps the vehicle to better control its speed and avoid potential collisions. Hence, proposing an effective solution for traffic scene classification will assist autonomous driving technologies to achieve human-level reasoning and understanding. In the driving context, each scene includes various attributes such as weather conditions, lighting, traffic, road type, etc. The large range of variations in traffic images have made traffic scene classification a challenging problem for current data-driven studies [1], [2].

随着自动驾驶车辆兴趣的日益增长，利用车载前置摄像头捕获的交通场景识别已成为智能交通系统领域的一个活跃研究方向。交通场景理解能够为自动驾驶车辆的实时决策提供宝贵信息；例如，识别路口有助于车辆更好地控制速度并避免潜在碰撞。因此，提出有效的交通场景分类解决方案将助力自动驾驶技术实现类人水平的推理与理解。在驾驶环境中，每个场景包含多种属性，如天气状况、光照、交通状况、道路类型等。交通图像的多样变化使得交通场景分类成为当前数据驱动研究中的一大挑战[1]，[2]。

Prior works on traffic scene understanding focused on using the geographical information and contextual knowledge of the road to gain a high sense of the environment. These methods include the road detection algorithms that work based on depth clues with traditional RGB information and local road information [3], [4], traffic object recognition with depth information [5], and road scene classification by multi-scale appearance and motion features [6]. Due to the remarkable success of deep neural networks (DNNs) and the significant improvement of computational resources, the vast majority of recent works leverage DNNs to solve challenging traffic scene understanding problems. Sikiric et al. [7] applied a deep convolution neural network (CNN) on the on-board vehicle images to extract a compact set of visual traffic patterns and recognize various scene types (e.g., tunnel, road, overpass, etc.). Similarly, a traffic scene recognition method using CNNs is developed by combining local deep learning features and multi-classifier fusion [8]. Also, Oeljeklaus et al. [9] proposed a pixel-wise labeling model for semantic scene understanding and road type classification via the Inception-V1 encoder-decoder pipeline [10].

先前关于交通场景理解的研究主要侧重于利用地理信息和道路的上下文知识以获得对环境的深刻感知。这些方法包括基于深度线索结合传统RGB信息和局部道路信息的道路检测算法[3]，[4]，结合深度信息的交通物体识别[5]，以及通过多尺度外观和运动特征进行的道路场景分类[6]。得益于深度神经网络(DNN)取得的显著成功及计算资源的显著提升，绝大多数最新研究利用DNN解决复杂的交通场景理解问题。Sikiric等人[7]在车载图像上应用深度卷积神经网络(CNN)提取紧凑的视觉交通模式集并识别多种场景类型(如隧道、道路、高架桥等)。类似地，结合局部深度学习特征和多分类器融合的方法被用于交通场景识别[8]。此外，Oeljeklaus等人[9]提出了基于Inception-V1编码器-解码器架构的像素级标注模型，用于语义场景理解和道路类型分类[10]。

Although DNNs have shown promising performances on various computer vision tasks [6], [7], [11] and timeseries forecasting [12], [13], [14], recent studies reveal their lack of efficiency when the distribution of the testing dataset (target domain) is different from the training dataset (source domain). Therefore, recent computer vision studies are focused on the domain shift problem where the DNN features are transferred from the source domain to the target using domain adaptation (DA) techniques. Recently, a few traffic scene segmentation studies addressed the domain shift problem caused by inconsistencies between the source and target data distributions such as variations in weather condition, illumination, and road type. Di et al. [15] addressed the problem of semantic segmentation for rainy and night-time scenes using daytime images. They reduced the impact of domain shift at the representation level by extracting substantial similarities between domain pairs using a CNN. Further, a segmentation space adaptation (SSA) model is proposed to reduce the impact of domain shift on the segmentation level. Similarly, a DA-based method for traffic scene understanding is proposed in [2] where the deep representation of scene images are extracted using deep CNNs, and a compact domain invariant representation is constructed by cross-domain metric learning and subspace alignment. Kothandaraman et al. [16] developed a road segmentation approach under severe weather conditions (i.e., snow, rain, and fog) by constructing a pre-trained model on the clear weather samples and taking advantage of curriculum learning [17] to bridge the source and target domains' gap progressively.

尽管深度神经网络(DNNs)在各种计算机视觉任务[6]，[7]，[11]和时间序列预测[12]，[13]，[14]中表现出良好的性能，近期研究表明，当测试数据集(目标域)的分布与训练数据集(源域)不同，DNN的效率会显著下降。因此，近期计算机视觉研究聚焦于域迁移问题，即通过域适应(DA)技术将DNN特征从源域迁移到目标域。最近，一些交通场景分割研究针对由源域和目标域数据分布不一致引起的域迁移问题进行了探讨，这些不一致包括天气条件、光照和道路类型的变化。Di等人[15]利用白天图像解决了雨天和夜间场景的语义分割问题。他们通过使用卷积神经网络(CNN)提取域对之间的显著相似性，在表示层面减少了域迁移的影响。此外，提出了一种分割空间适应(SSA)模型，以减少域迁移在分割层面的影响。同样，文献[2]提出了一种基于域适应的交通场景理解方法，该方法利用深度CNN提取场景图像的深层表示，并通过跨域度量学习和子空间对齐构建紧凑的域不变表示。Kothandaraman等人[16]针对恶劣天气条件(如雪、雨和雾)开发了一种道路分割方法，该方法基于晴朗天气样本构建预训练模型，并利用课程学习[17]逐步缩小源域与目标域之间的差距。

---

Manuscript received 11 June 2022; revised 13 November 2022; accepted 28 December 2022. Date of publication 24 January 2023; date of current version 24 July 2023. (Corresponding author: Mohsen Saffari.)

稿件收到日期:2022年6月11日；修订日期:2022年11月13日；接受日期:2022年12月28日。发布日期:2023年1月24日；当前版本日期:2023年7月24日。(通讯作者:Mohsen Saffari。)

Mohsen Saffari and Mahdi Khodayar are with the Department of Computer Science, University of Tulsa, Tulsa, OK 74104-3189 USA (e-mail: mohsen-saf-fari@utulsa.edu; mahdi-khodayar@utulsa.edu).

Mohsen Saffari和Mahdi Khodayar隶属于美国俄克拉荷马州塔尔萨市塔尔萨大学计算机科学系，邮编74104-3189(电子邮件:mohsen-saf-fari@utulsa.edu；mahdi-khodayar@utulsa.edu)。

Seyed Mohammad Jafar Jalali is with the Institute for Intelligent Systems Research, and Innovation, Deakin University, Waurn Ponds, VIC 3216, Australia (e-mail: s.jalali@deakin.edu.au).

Seyed Mohammad Jafar Jalali隶属于澳大利亚维多利亚州沃恩庞兹市迪肯大学智能系统研究与创新研究所，邮编3216(电子邮件:s.jalali@deakin.edu.au)。

Digital Object Identifier 10.1109/TETCI.2023.3234548

数字对象唯一标识符 10.1109/TETCI.2023.3234548

---

Current traffic scene classification schemes suffer from several shortcomings:

当前交通场景分类方案存在若干不足:

1) Although the domain shift issue is considered in multiple studies on traffic scene semantic segmentation [2], [16], [18], state-of-the-art methods do not address the domain shift issue caused by weather variations. Moreover, current traffic scene classification studies do not employ domain adaptation techniques to address such changes in traffic scenes. Thus, they are not applicable to the real-world traffic scene understanding under different weather conditions.

1) 尽管多项交通场景语义分割研究[2]，[16]，[18]考虑了域迁移问题，但现有最先进方法未能解决由天气变化引起的域迁移问题。此外，当前交通场景分类研究未采用域适应技术来应对交通场景中的此类变化，因此无法适用于不同天气条件下的真实交通场景理解。

2) Current studies such as [7], [8], and [19] use dense features obtained by fully connected layers on top of convolutional blocks and they do not study the sparsity of their extracted visual features; hence, they require a large number of dense parameters, which results in a higher chance of overfitting and training sample complexity.

2) 当前研究如[7]，[8]和[19]使用卷积块顶部的全连接层获得的密集特征，且未研究其提取视觉特征的稀疏性；因此，这些方法需要大量密集参数，导致过拟合风险增加和训练样本复杂度提升。

3) They rely on discriminative approaches that cannot automatically capture powerful unsupervised features from the underlying traffic image distributions, while these features can significantly improve the classification performance.

3) 它们依赖判别方法，无法自动捕获潜在交通图像分布中的强大无监督特征，而这些特征能够显著提升分类性能。

Motivated by these drawbacks, this paper seeks to solve the DA problem for traffic scene classification. The objective is to transfer the classification knowledge from a source domain (i.e., clear sunny scenes) to the target domain (i.e., snowy, rainy, and cloudy scenes). To this end, we propose a sparse unsupervised domain adaptation (UDA) model that learns and classifies a sparse nonlinear representation of complex traffic scenes by incorporating dictionary learning (DL) into deep adversarial learning of traffic scenes. First, a novel task-relevant nonlinear DL method is devised to capture the significant visual patterns of traffic images in the source domain. The DL provides a powerful sparse representation of the source traffic scenes. Then, a sparse code augmentation model is devised using an adversarial framework to learn the complex probability distribution of the sparse representations of source images. Finally, a domain invariant feature extractor is designed to align the target data distribution with the source. Our domain invariant representation is further used to classify traffic scenes in the target domain via a DNN. The contributions of this work are:

针对上述缺陷，本文旨在解决交通场景分类的域适应问题。目标是将分类知识从源域(即晴朗阳光场景)迁移到目标域(即雪天、雨天和多云场景)。为此，我们提出了一种稀疏无监督域适应(UDA)模型，通过将字典学习(DL)融入交通场景的深度对抗学习，学习并分类复杂交通场景的稀疏非线性表示。首先，设计了一种新颖的任务相关非线性字典学习方法，以捕捉源域交通图像的重要视觉模式。字典学习为源交通场景提供了强大的稀疏表示。随后，利用对抗框架设计了稀疏编码增强模型，以学习源图像稀疏表示的复杂概率分布。最后，设计了域不变特征提取器，将目标数据分布与源数据对齐。我们进一步利用该域不变表示通过深度神经网络对目标域交通场景进行分类。本文的贡献包括:

1) We formulate the domain shift problem in traffic scene classification caused by changes in weather via unsupervised domain adaptation. The presented work bridges the gap between the source and target domains with different weather conditions by developing a deep sparse feature augmentation technique.

1) 我们通过无监督域适应方法，针对由天气变化引起的交通场景分类中的域迁移问题进行了建模。本文通过开发深度稀疏特征增强技术，弥合了不同天气条件下源域与目标域之间的差距。

2) A novel generative domain invariant feature extraction model is devised for the classification of traffic scenes. The proposed model is capable of learning powerful unsupervised generative features from the underlying source and target scene distributions; hence, provides a more informative data representation compared to the state-of-the-art methods that are mainly based on discriminative feature extraction.

2) 提出了一种新颖的生成式领域不变特征提取模型，用于交通场景分类。该模型能够从源域和目标场景的潜在分布中学习强大的无监督生成特征；因此，相较于主要基于判别特征提取的现有方法，提供了更具信息量的数据表示。

3) A new nonlinear task-relevant DL model is developed and incorporated into deep conditional generative adversarial networks (CGANs) to encourage the sparsity of the traffic scene representations. The obtained sparse features capture the most significant visual patterns of traffic images while reducing the sample complexity of the proposed DNN. Our model provides more robust and accurate classification results with respect to weather changes compared to the state-of-the-art frameworks.

3) 开发了一种新的非线性任务相关深度学习(DL)模型，并将其整合到深度条件生成对抗网络(CGANs)中，以促进交通场景表示的稀疏性。获得的稀疏特征捕捉了交通图像中最显著的视觉模式，同时降低了所提深度神经网络(DNN)的样本复杂度。与现有先进框架相比，我们的模型在天气变化下提供了更稳健且更准确的分类结果。

The rest of the paper is organized as follows: Section II presents the traffic scene classification with domain shift problem. Section III presents the proposed UDA model using DL and CGANs. First, the mathematical definition of the model is discussed. Then, the optimization and learning algorithms are provided. Section IV shows the experimental results using a real-world dataset. Finally, Section V presents the conclusions.

论文其余部分安排如下:第二节介绍带有领域偏移问题的交通场景分类。第三节介绍基于深度学习和条件生成对抗网络的所提无监督领域自适应(UDA)模型。首先讨论模型的数学定义，然后给出优化和学习算法。第四节展示使用真实数据集的实验结果。最后，第五节给出结论。

## II. Problem Formulation

## II. 问题描述

Let us consider a set of ${N}^{S}$ labeled street traffic images in a source domain (dataset) ${\mathcal{D}}^{S} = {\left\{  \left\langle  {x}_{i}^{S},{y}_{i}^{S}\right\rangle  \right\}  }_{i = 1}^{{N}^{S}}$ where each ${x}_{i}^{S} \in  {X}^{S}$ is a $W \times  H$ dimensional RGB image and its label ${y}_{i}^{S} \in  {Y}^{S}$ is a $K$ -dimensional multi-label vector corresponding to $K$ classes (i.e., intersection, construction zone, zebra crossing, etc.). A target domain is a set of unlabeled street scene images ${\mathcal{D}}^{T} = {\left\{  {x}_{j}^{T} \in  {X}^{T}\right\}  }_{j = 1}^{{N}^{T}}$ that need to be labeled. The source images are captured in a clear and sunny weather while the target domain images are in other weather conditions (e.g., cloudy, rainy, and snowy). Due to the change of the weather condition, the data distributions of source and target are different $P\left( {X}^{S}\right)  \neq$ $P\left( {X}^{T}\right)$ . Hence, the performance of a classifier $\left( {f\left( {x}_{i}^{S}\right)  = {y}_{i}^{S}}\right)$ that is trained on ${\mathcal{D}}^{\mathcal{S}}$ domain will significantly drop in the target domain ${\mathcal{D}}^{T}$ , which is known as the domain shift problem. Our objective is to learn a robust domain invariant classifier that provides high classification accuracy on ${\mathcal{D}}^{T}$ images using the obtained knowledge in ${\mathcal{D}}^{S}$ .

考虑源域(数据集)${\mathcal{D}}^{S} = {\left\{  \left\langle  {x}_{i}^{S},{y}_{i}^{S}\right\rangle  \right\}  }_{i = 1}^{{N}^{S}}$中一组带标签的街道交通图像${N}^{S}$，其中每个${x}_{i}^{S} \in  {X}^{S}$是一个$W \times  H$维的RGB图像，其标签${y}_{i}^{S} \in  {Y}^{S}$是一个对应于$K$个类别(如交叉路口、施工区、人行横道等)的$K$维多标签向量。目标域是一组需要标注的无标签街景图像${\mathcal{D}}^{T} = {\left\{  {x}_{j}^{T} \in  {X}^{T}\right\}  }_{j = 1}^{{N}^{T}}$。源图像采集于晴朗天气，而目标域图像则处于其他天气条件(如多云、雨天和雪天)。由于天气条件的变化，源域和目标域的数据分布不同$P\left( {X}^{S}\right)  \neq$$P\left( {X}^{T}\right)$。因此，在源域${\mathcal{D}}^{\mathcal{S}}$上训练的分类器$\left( {f\left( {x}_{i}^{S}\right)  = {y}_{i}^{S}}\right)$在目标域${\mathcal{D}}^{T}$上的性能会显著下降，这被称为领域偏移问题。我们的目标是学习一个稳健的领域不变分类器，利用在${\mathcal{D}}^{S}$中获得的知识，在${\mathcal{D}}^{T}$图像上实现高分类准确率。

## III. METHODOLOGY

## III. 方法论

The idea of the proposed model is to map the source and target domains into a shared domain invariant sparse feature space. These features help us to provide a high classification accuracy on ${\mathcal{D}}^{T}$ when the model is trained on ${\mathcal{D}}^{S}$ , hence, providing an effective knowledge transfer from the source to target. Therefore, we seek to minimize the distance between the distribution of our sparse features corresponding to ${\mathcal{D}}^{S}$ and ${\mathcal{D}}^{T}$ . In other words, we align the sparse features of the target domain with the source. As shown in Fig. 1, the proposed model consists of three main modules. First, we train a sparse coding function $\left( {E}_{SC}\right)$ to represent each source image ${x}_{i}^{S}$ by a sparse feature ${\alpha }_{{x}_{i}^{S}}$ . We feed ${\alpha }_{{x}_{i}^{S}}$ to a classifier $C$ parameterized by $W$ and $b$ to learn classification decision boundaries of the source domain. Hence, ${E}_{SC}$ would learn task-relevant sparse features that discriminate source samples ${x}_{i}^{S} \in  {X}^{S}$ . In the second module, a CGAN is developed to learn the distribution of source sparse codes ${A}^{S} = {\left\{  {\alpha }_{{x}_{i}^{S}}\right\}  }_{i = 1}^{{N}^{S}}$ using a generator $G$ and a discriminator ${D}_{1}$ function. The generator $G$ seeks to generate sparse codes that follow the distribution of ${A}^{S}$ while ${D}_{1}$ validates the produced codes. Finally, in the third module, we develop a CGAN framework that includes the sparse code generator $G$ learned in the second module, a deep sparse feature extractor ${E}_{DI}$ , and a domain discriminator ${D}_{2}$ . Here, generator $G$ produces the reference source sparse codes, while ${E}_{DI}$ extracts the deep sparse codes from either source or target domains. The discriminator ${D}_{2}$ is responsible for discriminating the source and target sparse codes. The features extracted by learned ${E}_{DI}$ are used by $C$ to classify the target images. This section provides the details of each module in the following.

所提模型的核心思想是将源域和目标域映射到一个共享的域不变稀疏特征空间。这些特征帮助我们在模型以${\mathcal{D}}^{S}$训练时，在${\mathcal{D}}^{T}$上实现高分类准确率，从而实现从源域到目标域的有效知识迁移。因此，我们旨在最小化对应于${\mathcal{D}}^{S}$和${\mathcal{D}}^{T}$的稀疏特征分布之间的距离。换言之，我们将目标域的稀疏特征与源域对齐。如图1所示，所提模型由三个主要模块组成。首先，我们训练一个稀疏编码函数$\left( {E}_{SC}\right)$，用以通过稀疏特征${\alpha }_{{x}_{i}^{S}}$表示每个源图像${x}_{i}^{S}$。我们将${\alpha }_{{x}_{i}^{S}}$输入由$W$和$b$参数化的分类器$C$，以学习源域的分类决策边界。因此，${E}_{SC}$将学习区分源样本${x}_{i}^{S} \in  {X}^{S}$的任务相关稀疏特征。在第二模块中，开发了一个条件生成对抗网络(CGAN)以利用生成器$G$和判别器${D}_{1}$函数学习源稀疏编码${A}^{S} = {\left\{  {\alpha }_{{x}_{i}^{S}}\right\}  }_{i = 1}^{{N}^{S}}$的分布。生成器$G$旨在生成符合${A}^{S}$分布的稀疏编码，而${D}_{1}$则验证生成的编码。最后，在第三模块中，我们构建了一个包含第二模块中学习的稀疏编码生成器$G$、深度稀疏特征提取器${E}_{DI}$和域判别器${D}_{2}$的CGAN框架。此处，生成器$G$生成参考的源稀疏编码，${E}_{DI}$从源域或目标域提取深度稀疏编码。判别器${D}_{2}$负责区分源域和目标域的稀疏编码。由学习到的${E}_{DI}$提取的特征被$C$用于目标图像的分类。本节将详细介绍各模块内容。

![bo_d285ftn7aajc738oslfg_2_246_259_1197_327_0.jpg](images/bo_d285ftn7aajc738oslfg_2_246_259_1197_327_0.jpg)

Fig. 1. Training procedure of the proposed model, representing the modules described in Section III-A. The solid arrow from Module A to B indicates the model is transferred from A to B and used without modification in Module B. The dashed arrow from module A to B indicates that the model is trained in A and used in B as an initialization.

图1. 所提模型的训练流程，展示了第III-A节中描述的各模块。从模块A到B的实线箭头表示模型从A转移到B并在B中不作修改地使用。模块A到B的虚线箭头表示模型在A中训练，并作为初始化在B中使用。

## A. Proposed Model Architecture

## A. 所提模型架构

1) Module 1: Dictionary Learning for Source Classification: This module develops a sparse discriminative classifier using nonlinear dictionary learning to classify source images ${\left\{  {x}_{i}^{S}\right\}  }_{i = 1}^{{N}_{S}}$ . To this end, we first extract the nonlinear spatial features of each ${x}_{i}^{S} \in  {X}^{S}$ using a deep CNN ${f}_{\theta }$ parameterized by $\theta$ . The obtained latent features ${z}_{{x}_{i}^{S}} = {f}_{\theta }\left( {x}_{i}^{S}\right)  \in  {\mathbb{R}}^{h}$ are fed to a dictionary learning module where $D = \left\lbrack  {{d}_{1},{d}_{2},\ldots ,{d}_{q}}\right\rbrack   \in  {\mathbb{R}}^{h \times  q}$ is the dictionary matrix with $q$ atoms (captured patterns) ${\left\{  {d}_{i}\right\}  }_{i = 1}^{q}$ and ${\alpha }_{{x}_{i}^{S}} \in  {\mathbb{R}}^{q}$ is the sparse code corresponding to each sample ${x}_{i}^{S}$ . Then, the obtained ${\alpha }_{{x}_{i}^{S}}$ is fed to a DNN with internal Rectified Linear Unit (ReLU) activation functions and a Softmax output layer denoted by ${C}_{W, b}$ where $W$ and $b$ are the sets of weights and biases of $C$ , respectively. We jointly optimize ${f}_{\theta }, D, C$ and the sparse codes matrix $A = \left\lbrack  {{\alpha }_{{x}_{1}^{S}},{\alpha }_{{x}_{2}^{S}},\ldots ,{\alpha }_{{x}_{{N}_{S}}^{S}}}\right\rbrack$ using the formulated optimization:

1) 模块1:用于源分类的字典学习:该模块利用非线性字典学习开发了一种稀疏判别分类器，用于对源图像进行分类${\left\{  {x}_{i}^{S}\right\}  }_{i = 1}^{{N}_{S}}$。为此，我们首先使用由$\theta$参数化的深度卷积神经网络(CNN)提取每个${x}_{i}^{S} \in  {X}^{S}$的非线性空间特征${f}_{\theta }$。获得的潜在特征${z}_{{x}_{i}^{S}} = {f}_{\theta }\left( {x}_{i}^{S}\right)  \in  {\mathbb{R}}^{h}$被输入到字典学习模块，其中$D = \left\lbrack  {{d}_{1},{d}_{2},\ldots ,{d}_{q}}\right\rbrack   \in  {\mathbb{R}}^{h \times  q}$是包含$q$个原子(捕获的模式)的字典矩阵${\left\{  {d}_{i}\right\}  }_{i = 1}^{q}$，${\alpha }_{{x}_{i}^{S}} \in  {\mathbb{R}}^{q}$是对应于每个样本的稀疏编码${x}_{i}^{S}$。然后，得到的${\alpha }_{{x}_{i}^{S}}$被输入到具有内部整流线性单元(ReLU)激活函数和Softmax输出层的深度神经网络(DNN)中，记为${C}_{W, b}$，其中$W$和$b$分别是$C$的权重和偏置集合。我们通过以下优化公式联合优化${f}_{\theta }, D, C$和稀疏编码矩阵$A = \left\lbrack  {{\alpha }_{{x}_{1}^{S}},{\alpha }_{{x}_{2}^{S}},\ldots ,{\alpha }_{{x}_{{N}_{S}}^{S}}}\right\rbrack$:

$$
\mathop{\min }\limits_{{D, A,{\theta }_{f}, W, b}}\;{J}_{1} = \frac{1}{{N}_{S}}\mathop{\sum }\limits_{{i = 1}}^{{N}_{S}}\left( {{\begin{Vmatrix}{z}_{{x}_{i}^{S}} - D{\alpha }_{{x}_{i}^{S}}\end{Vmatrix}}_{2}^{2} + {\omega }_{1}{\begin{Vmatrix}{\alpha }_{{x}_{i}^{S}}\end{Vmatrix}}_{1}}\right)
$$

$$
+ \frac{{\omega }_{2}}{{N}_{S}}\mathop{\sum }\limits_{{i = 1}}^{{N}_{S}}{\mathcal{L}}_{CE}\left( {{y}_{i}^{S},{\widehat{y}}_{i}^{S}}\right)  + {\omega }_{3}\mathop{\sum }\limits_{{l = 1}}^{L}\left( {{\begin{Vmatrix}{W}_{C}^{\left( l\right) }\end{Vmatrix}}_{F}^{2} + {\begin{Vmatrix}{b}_{C}^{\left( l\right) }\end{Vmatrix}}_{2}^{2}}\right)
$$

$$
\text{s.t.}{\begin{Vmatrix}{d}_{j}\end{Vmatrix}}_{2}^{2} \leq  1,\forall 1 \leq  j \leq  q \tag{1}
$$

where ${W}_{C}^{\left( l\right) }$ and ${b}_{C}^{\left( l\right) }$ are the weight and bias of the $l$ -th layer in $C$ , respectively. The first term in (1) reflects the DL-based source data reconstruction and sparse code regularization error functions of our DL model. The second term, ${\mathcal{L}}_{CE}\left( {\widehat{y}, y}\right)$ , is the multi-label cross entropy classification error between the actual source class label ${y}_{i}^{S}$ and predicted label ${\widehat{y}}_{i}^{S} = C\left( {{\alpha }_{{x}_{i}};W, b}\right)$ . The third term regularizes the parameters of $C$ via ${L2}$ regularization. Here, ${\omega }_{1},{\omega }_{2},{\omega }_{3}$ are positive coefficients that determine the contribution of each term to ${J}_{1}$ .

其中，${W}_{C}^{\left( l\right) }$和${b}_{C}^{\left( l\right) }$分别是$C$中第$l$层的权重和偏置。(1)式中的第一项反映了基于字典学习(DL)的源数据重构和稀疏编码正则化误差函数。第二项${\mathcal{L}}_{CE}\left( {\widehat{y}, y}\right)$是实际源类别标签${y}_{i}^{S}$与预测标签${\widehat{y}}_{i}^{S} = C\left( {{\alpha }_{{x}_{i}};W, b}\right)$之间的多标签交叉熵分类误差。第三项通过${L2}$正则化约束了$C$的参数。这里，${\omega }_{1},{\omega }_{2},{\omega }_{3}$是正系数，用于确定各项对${J}_{1}$的贡献。

2) Module 2: Source Sparse Codes Augmentation: This module develops a sparse code feature augmentation model via a CGAN to learn the distribution of the sparse codes (i.e., features) of source domain images ${A}^{S}$ . By learning the distribution of representative sparse codes, the model can generate an arbitrary number of features conditioned on a particular class. Hence, feature augmentation increases generalization capacity and reduces the chance of overfitting. The proposed CGAN contains a generator $G$ and a discriminator ${D}_{1}$ parameterized by ${\theta }_{G}$ and ${\theta }_{{D}_{1}}$ , respectively. Here, $G$ receives the random noise vector $\epsilon$ and one-hot encoded label ${y}_{i}^{S}$ to produce a sample (i.e., sparse code) that follows the distribution of the source sparse codes. The discriminator ${D}_{1}$ receives the sparse code ${\alpha }_{{x}_{i}^{S}}$ and the corresponding one-hot encoded label ${y}_{i}^{S}$ and outputs the probability of ${\alpha }_{{x}_{i}^{S}}$ being real (i.e., coming from the distribution of source sparse codes corresponding to label ${y}_{i}^{S}$ ) or fake. We train our CGAN using the following minimax game between $G$ and ${D}_{1}$ :

2) 模块2:源稀疏编码增强:该模块通过条件生成对抗网络(CGAN)构建稀疏编码特征增强模型，以学习源域图像稀疏编码(即特征)的分布${A}^{S}$。通过学习代表性稀疏编码的分布，模型能够基于特定类别生成任意数量的特征。因此，特征增强提升了泛化能力，减少了过拟合的可能性。所提CGAN包含由${\theta }_{G}$和${\theta }_{{D}_{1}}$参数化的生成器$G$和判别器${D}_{1}$。其中，生成器$G$接收随机噪声向量$\epsilon$和独热编码标签${y}_{i}^{S}$，生成符合源稀疏编码分布的样本(即稀疏编码)。判别器${D}_{1}$接收稀疏编码${\alpha }_{{x}_{i}^{S}}$及对应的独热编码标签${y}_{i}^{S}$，输出${\alpha }_{{x}_{i}^{S}}$为真实(即来自对应标签${y}_{i}^{S}$的源稀疏编码分布)或伪造的概率。我们通过以下生成器$G$与判别器${D}_{1}$之间的极小极大博弈训练CGAN:

$$
\mathop{\min }\limits_{{\theta }_{G}}\mathop{\max }\limits_{{\theta }_{{D}_{1}}}{J}_{2} = {\mathbb{E}}_{\left( {{x}_{i}^{S},{y}_{i}^{S}}\right)  \sim  \left( {{X}^{S},{Y}^{S}}\right) }\left\lbrack  {\log {D}_{1}\left( {{\alpha }_{{x}_{i}^{S}},{y}_{i}^{S}}\right) }\right\rbrack
$$

$$
+ {\mathbb{E}}_{\left( {\epsilon ,{y}_{i}^{S}}\right)  \sim  \left( {\mathcal{N},{Y}^{S}}\right) }\left\lbrack  {\log \left( {1 - {D}_{1}\left( {G\left( {\epsilon ,{y}_{i}^{S}}\right) ,{y}_{i}^{S}}\right) }\right) }\right\rbrack
$$

(2)where $\epsilon$ is sampled from the Normal distribution $\mathcal{N}$ . Here, ${\alpha }_{{x}_{i}^{S}}$ is the computed sparse code of source image ${x}_{i}^{S}$ obtained by ${E}_{SC}$ learned in Module 1. We define our discriminator ${D}_{1}$ as a binary classifier that discriminates the sparse codes generated by $G$ and ${E}_{SC}$ . This process guides $G$ to learn the distribution of the sparse codes corresponding to source images.

其中$\epsilon$采样自正态分布$\mathcal{N}$。这里，${\alpha }_{{x}_{i}^{S}}$是通过模块1中学习的${E}_{SC}$获得的源图像${x}_{i}^{S}$的计算稀疏编码。我们将判别器${D}_{1}$定义为二分类器，用以区分由$G$和${E}_{SC}$生成的稀疏编码。该过程引导$G$学习对应源图像的稀疏编码分布。

![bo_d285ftn7aajc738oslfg_3_133_183_718_192_0.jpg](images/bo_d285ftn7aajc738oslfg_3_133_183_718_192_0.jpg)

Fig. 2. Testing procedure of the proposed model for a target image ${x}_{i}^{T} \in  {X}^{T}$ . ${\widehat{y}}_{i}^{T}$ is the estimation of the true label ${y}_{i}^{T}$ . Note that ${E}_{DI}$ and $C$ come from Modules 1 and 3 discussed in Section III-A, respectively.

图2. 所提模型对目标图像${x}_{i}^{T} \in  {X}^{T}$的测试流程。${\widehat{y}}_{i}^{T}$为真实标签${y}_{i}^{T}$的估计。注意，${E}_{DI}$和$C$分别来自第III-A节讨论的模块1和模块3。

3) Module 3: Learning Domain Invariant Sparse Representations: Here, we define a CGAN to learn an optimal domain invariant sparse representation that best describes both source and target domains. The proposed CGAN consists of the generator $G$ trained in Module 2, a sparse code feature extractor ${E}_{DI}$ , and a domain discriminator ${D}_{2}$ . As shown in Fig. $1,{E}_{DI}$ and ${E}_{SC}$ share the same structure, and ${E}_{DI}$ is initialized with the trained ${E}_{SC}$ from Module 1. In this setting, $G$ produces sparse codes from $\epsilon  \sim  \mathcal{N}$ while ${E}_{DI}$ computes the sparse codes corresponding to the images in source or target domains. Here, ${D}_{2}$ receives the sparse codes generated by $G$ and ${E}_{DI}$ and decides if they are sampled from the same domain (i.e., they both come from the source domain) or not (i.e., one comes from the source and the other comes from the target domain.) As shown in (3), the objective of Module 3 is to deceive ${D}_{2}$ so that it does not recognize target sparse codes from the source ones. That is, the ${E}_{DI}$ aligns the target sparse codes with the source features, hence computing domain invariant sparse codes. To optimize ${E}_{DI}$ and ${D}_{2}$ in this adversarial framework, we solve the following minimax game:

3) 模块3:学习域不变稀疏表示:在此，我们定义一个CGAN以学习最佳的域不变稀疏表示，能够同时描述源域和目标域。所提CGAN由模块2中训练的生成器$G$、稀疏编码特征提取器${E}_{DI}$和域判别器${D}_{2}$组成。如图所示，$1,{E}_{DI}$和${E}_{SC}$结构相同，且${E}_{DI}$以模块1中训练的${E}_{SC}$初始化。在此设置中，$G$从$\epsilon  \sim  \mathcal{N}$生成稀疏编码，而${E}_{DI}$计算源域或目标域图像对应的稀疏编码。判别器${D}_{2}$接收由$G$和${E}_{DI}$生成的稀疏编码，判断它们是否采样自同一域(即均来自源域)或不同域(即一个来自源域，另一个来自目标域)。如公式(3)所示，模块3的目标是欺骗${D}_{2}$，使其无法区分目标稀疏编码与源稀疏编码。即，${E}_{DI}$将目标稀疏编码与源特征对齐，从而计算域不变稀疏编码。为在该对抗框架中优化${E}_{DI}$和${D}_{2}$，我们求解以下极小极大博弈:

$$
\mathop{\min }\limits_{{A, D,{\theta }_{f}}}\mathop{\max }\limits_{{\theta }_{{D}_{2}}}{J}_{3} = {\mathbb{E}}_{\left( {\epsilon ,{y}_{i}^{S}}\right)  \sim  \left( {\mathcal{N},{Y}^{S}}\right) }\left\lbrack  {\log \left( {1 - {D}_{2}\left( {G\left( {\epsilon ,{y}_{i}^{S}}\right) }\right) }\right) }\right\rbrack
$$

$$
+ {\mathbb{E}}_{{x}_{i} \sim  \left( {{X}^{S} \cup  {X}^{T}}\right) }\left\lbrack  {\log {D}_{2}\left( {\alpha }_{{x}_{i}}\right) }\right\rbrack
$$

$$
+ \frac{1}{N}\mathop{\sum }\limits_{{i = 1}}^{N}\left( {{\begin{Vmatrix}{f}_{\theta }\left( {x}_{i}\right)  - D{\alpha }_{{x}_{i}}\end{Vmatrix}}_{2}^{2} + {\omega }_{1}{\begin{Vmatrix}{\alpha }_{{x}_{i}}\end{Vmatrix}}_{1}}\right)
$$

$$
\text{s.t.}{\begin{Vmatrix}{d}_{j}\end{Vmatrix}}_{2}^{2} \leq  1,\forall 1 \leq  j \leq  q \tag{3}
$$

where ${\alpha }_{{x}_{i}}$ is the sparse representation of an image ${x}_{i}$ sampled from ${X}^{S} \cup  {X}^{T}$ , while ${\theta }_{f}$ and ${\theta }_{{D}_{2}}$ are the parameters of $f$ and ${D}_{2}$ , respectively. Here, $N$ is the total number of source and target images $\left( {N = {N}_{S} + {N}_{T}}\right)$ . By solving the optimization problem in (3), the optimal domain invariant encoder ${E}_{DI}$ is achieved.

其中 ${\alpha }_{{x}_{i}}$ 是从 ${X}^{S} \cup  {X}^{T}$ 采样得到的图像的稀疏表示 ${x}_{i}$ ，而 ${\theta }_{f}$ 和 ${\theta }_{{D}_{2}}$ 分别是 $f$ 和 ${D}_{2}$ 的参数。这里，$N$ 是源域和目标域图像的总数 $\left( {N = {N}_{S} + {N}_{T}}\right)$ 。通过求解式(3)中的优化问题，获得了最优的域不变编码器 ${E}_{DI}$ 。

Fig. 2 shows the classification process (test) of the target domain images using our trained domain invariant sparse feature extractor ${E}_{DI}$ and classifier $C$ . For each target image ${x}_{i}^{T} \in  {X}^{T}$ , we obtain the class ${\widehat{y}}_{i}^{T} \simeq  {y}_{i}^{T}$ by feeding the domain invariant feature ${\alpha }_{{x}_{i}^{T}}$ extracted by ${E}_{DI}$ to our classifier $C$ .

图2展示了使用我们训练好的域不变稀疏特征提取器 ${E}_{DI}$ 和分类器 $C$ 对目标域图像进行分类(测试)的过程。对于每个目标图像 ${x}_{i}^{T} \in  {X}^{T}$ ，我们通过将 ${E}_{DI}$ 提取的域不变特征 ${\alpha }_{{x}_{i}^{T}}$ 输入分类器 $C$ 来获得类别 ${\widehat{y}}_{i}^{T} \simeq  {y}_{i}^{T}$ 。

## B. Learning and Optimization

## B. 学习与优化

This section discusses the training procedure of the proposed model using the objective functions defined in the three modules discussed in Section III-A.

本节讨论了利用第III-A节中定义的三个模块的目标函数对所提模型进行训练的过程。

Module 1: Dictionary Learning for Source Classification: The defined optimization problem in (1) is not jointly convex w.r.t. the dictionary $D$ , sparse code matrix $A =$ $\left\lbrack  {{\alpha }_{{x}_{1}^{S}},{\alpha }_{{x}_{2}^{S}},\ldots ,{\alpha }_{{x}_{{N}_{S}}^{S}}}\right\rbrack  ,{f}_{\theta }$ , and ${C}_{W, b}$ . Therefore, we propose a three-step iterative method to solve this optimization.

模块1:源域分类的字典学习:式(1)中定义的优化问题对于字典 $D$ 、稀疏编码矩阵 $A =$ $\left\lbrack  {{\alpha }_{{x}_{1}^{S}},{\alpha }_{{x}_{2}^{S}},\ldots ,{\alpha }_{{x}_{{N}_{S}}^{S}}}\right\rbrack  ,{f}_{\theta }$ 和 ${C}_{W, b}$ 并非联合凸的。因此，我们提出了一个三步迭代方法来求解该优化问题。

a) Step 1: Training ${\theta }_{f},{W}_{C}$ , and ${b}_{C}$ : In this step, we fix $D$ and $A$ , and rewrite the optimization problem in (1) as:

a) 第一步:训练 ${\theta }_{f},{W}_{C}$ 和 ${b}_{C}$ :在此步骤中，我们固定 $D$ 和 $A$ ，并将式(1)中的优化问题重写为:

$$
\mathop{\min }\limits_{{{\theta }_{f},{W}_{C},{b}_{C}}}{J}_{1}^{\left( 1\right) } = \frac{1}{{N}_{S}}\mathop{\sum }\limits_{{i = 1}}^{{N}_{S}}
$$

$$
\left( {{\begin{Vmatrix}{f}_{\theta }\left( {x}_{i}^{S}\right)  - D{\alpha }_{{x}_{i}^{S}}\end{Vmatrix}}_{2}^{2} + {\omega }_{2}{\mathcal{L}}_{CE}\left( {{y}_{i}^{S},{\widehat{y}}_{i}^{S}}\right) }\right)
$$

$$
+ {\omega }_{3}\mathop{\sum }\limits_{{l = 1}}^{L}\left( {{\begin{Vmatrix}{W}_{C}^{\left( l\right) }\end{Vmatrix}}_{F}^{2} + {\begin{Vmatrix}{b}_{C}^{\left( l\right) }\end{Vmatrix}}_{2}^{2}}\right)  + {\kappa }_{1} \tag{4}
$$

where ${\kappa }_{1}$ is a positive constant. The revised objective function ${J}_{1}^{\left( 1\right) }$ is differentiable w.r.t. the parameters ${\theta }_{f},{W}_{C}$ , and ${b}_{C}$ . Thus, we minimize it by the gradient descent (GD) method using the gradients $\partial {J}_{1}^{\left( 1\right) }/\partial \Theta$ for $\Theta  = \left\{  {{\theta }_{f},{W}_{C},{b}_{C}}\right\}$ .

其中 ${\kappa }_{1}$ 是一个正常数。修正后的目标函数 ${J}_{1}^{\left( 1\right) }$ 关于参数 ${\theta }_{f},{W}_{C}$ 和 ${b}_{C}$ 是可微的。因此，我们利用梯度 $\partial {J}_{1}^{\left( 1\right) }/\partial \Theta$ 对 $\Theta  = \left\{  {{\theta }_{f},{W}_{C},{b}_{C}}\right\}$ 采用梯度下降(GD)方法进行最小化。

b) Step 2: Training Dictionary $D$ : In this step, we fix $A$ , ${\theta }_{f},{W}_{C}$ and ${b}_{C}$ (learned from Step 1), and update $D$ . Therefore, (1) is written as:

b) 第二步:训练字典 $D$ :在此步骤中，我们固定从第一步学习得到的 $A$ 、${\theta }_{f},{W}_{C}$ 和 ${b}_{C}$ ，并更新 $D$ 。因此，式(1)可写为:

$$
\mathop{\min }\limits_{D}{J}_{1}^{\left( 2\right) } = \frac{1}{{N}_{S}}\mathop{\sum }\limits_{{i = 1}}^{{N}_{S}}{\begin{Vmatrix}{f}_{\theta }\left( {x}_{i}^{S}\right)  - D{\alpha }_{{x}_{i}}\end{Vmatrix}}_{2}^{2} + {\kappa }_{2}
$$

$$
\text{s.t.}{\begin{Vmatrix}{d}_{j}\end{Vmatrix}}_{2}^{2} \leq  1,\;\forall 1 \leq  j \leq  q\text{,} \tag{5}
$$

where ${\kappa }_{2}$ is a positive constant. This optimization problem is convex w.r.t. $D$ and can be solved by the Lagrange multiplier method. We define the Lagrangian function as:

其中 ${\kappa }_{2}$ 是一个正常数。该优化问题关于 $D$ 是凸的，可通过拉格朗日乘子法求解。我们定义拉格朗日函数为:

$$
\mathcal{L}\left( {D,\Phi }\right)  = \frac{1}{{N}_{S}}\mathop{\sum }\limits_{{i = 1}}^{{N}_{S}}{\begin{Vmatrix}{f}_{\theta }\left( {x}_{i}^{S}\right)  - D{\alpha }_{{x}_{i}^{S}}\end{Vmatrix}}_{2}^{2} + \mathop{\sum }\limits_{{j = 1}}^{J}{\phi }_{j}\left( {{\begin{Vmatrix}{d}_{j}\end{Vmatrix}}_{2}^{2} - 1}\right)
$$

(6)

where ${\phi }_{j} \geq  0$ denotes the $j$ -th Lagrange multiplier, and vector $\Phi  = {\left\lbrack  {\phi }_{1},{\phi }_{2},\ldots ,{\phi }_{q}\right\rbrack  }^{\top }$ contains these multipliers. We obtain an analytical solution for (6) by:

其中 ${\phi }_{j} \geq  0$ 表示第 $j$ 个拉格朗日乘子，向量 $\Phi  = {\left\lbrack  {\phi }_{1},{\phi }_{2},\ldots ,{\phi }_{q}\right\rbrack  }^{\top }$ 包含这些乘子。我们通过以下方式获得式(6)的解析解:

$$
\frac{\partial \mathcal{L}\left( {D,\Phi }\right) }{\partial D} = 0\; \Rightarrow  \;D = {f}_{\theta }\left( {X}^{S}\right) {A}^{\top }{\left( A{A}^{\top } + \Delta \right) }^{-1} \tag{7}
$$

where ${f}_{\theta }\left( {X}^{S}\right)  = \left\lbrack  {{z}_{{x}_{1}^{S}},{z}_{{x}_{2}^{S}},\ldots ,{z}_{{x}_{{N}^{S}}^{S}}}\right\rbrack   \in  {\mathbb{R}}^{h \times  {N}_{s}}$ , and $\Delta  =$ ${N}^{S}\operatorname{diag}\left( \Phi \right)  \in  {\mathbb{R}}^{q \times  q}$ is a diagonal matrix. By substituting the solution of $D$ in (7) into (6), we can rewrite the dual optimization problem as:

其中 ${f}_{\theta }\left( {X}^{S}\right)  = \left\lbrack  {{z}_{{x}_{1}^{S}},{z}_{{x}_{2}^{S}},\ldots ,{z}_{{x}_{{N}^{S}}^{S}}}\right\rbrack   \in  {\mathbb{R}}^{h \times  {N}_{s}}$ ，且 $\Delta  =$ ${N}^{S}\operatorname{diag}\left( \Phi \right)  \in  {\mathbb{R}}^{q \times  q}$ 是一个对角矩阵。通过将 (7) 中 $D$ 的解代入 (6)，我们可以将对偶优化问题重写为:

$$
\mathop{\max }\limits_{\Phi }{\mathcal{L}}_{\text{Dual }}\left( \Phi \right)  = \frac{1}{{N}_{S}}\mathop{\sum }\limits_{{i = 1}}^{{N}_{S}}\left.\parallel  {{f}_{\theta }\left( {x}_{i}^{S}\right) }\right.
$$

$$
- {f}_{\theta }\left( {X}^{S}\right) {A}^{\top }{\left( A{A}^{\top } + \Delta \right) }^{-1}{\alpha }_{{x}_{i}^{S}}{\parallel }_{2}^{2}
$$

$$
+ \mathop{\sum }\limits_{{j = 1}}^{q}{\phi }_{j}\left( {{\begin{Vmatrix}{f}_{\theta }\left( {X}^{S}\right) {A}^{\top }{\left( A{A}^{\top } + \Delta \right) }^{-1}{\gamma }_{j}\end{Vmatrix}}_{2}^{2} - 1}\right)  \tag{8}
$$

where ${\gamma }_{j}$ is the $j$ -th unit vector. The dual problem in (8) can be solved using GD by computing the gradient of ${\mathcal{L}}_{\text{Dual }}\left( \Phi \right)$ w.r.t. $\Phi$ as:

其中 ${\gamma }_{j}$ 是第 $j$ 个单位向量。式 (8) 中的对偶问题可以通过计算 ${\mathcal{L}}_{\text{Dual }}\left( \Phi \right)$ 关于 $\Phi$ 的梯度，使用梯度下降法(GD)求解，具体为:

$$
\frac{\partial {\mathcal{L}}_{\text{Dual }}\left( \Phi \right) }{\partial {\phi }_{j}} = {\begin{Vmatrix}{f}_{\theta }\left( {X}^{S}\right) {A}^{\top }{\left( A{A}^{\top } + \Delta \right) }^{-1}{\gamma }_{j}\end{Vmatrix}}_{2}^{2} - 1 \tag{9}
$$

Substituting the ${\Delta }^{ * }$ (the optimal $\Delta$ ) into (7) gives the learned dictionary $D$ .

将 ${\Delta }^{ * }$(最优的 $\Delta$ )代入 (7) 得到学习到的字典 $D$ 。

c) Step 3: Obtaining Sparse Codes: In this step, we compute $A$ using the learned ${f}_{\theta },{W}_{C},{b}_{C}$ and $D$ . The optimization in (1) is written as:

c) 第三步:获取稀疏编码:在此步骤中，我们使用学习到的 ${f}_{\theta },{W}_{C},{b}_{C}$ 和 $D$ 计算 $A$ 。(1) 中的优化问题写为:

$$
\mathop{\min }\limits_{A}{J}_{1}^{\left( 3\right) } = \frac{1}{{N}_{S}}\mathop{\sum }\limits_{{i = 1}}^{{N}_{S}}\left( {{\begin{Vmatrix}{f}_{\theta }\left( {x}_{i}^{S}\right)  - D{\alpha }_{{x}_{i}^{S}}\end{Vmatrix}}_{2}^{2} + {\omega }_{1}{\begin{Vmatrix}{\alpha }_{{x}_{i}^{S}}\end{Vmatrix}}_{1}}\right)
$$

$$
+ \frac{{\omega }_{2}}{{N}_{S}}\mathop{\sum }\limits_{{i = 1}}^{{N}_{S}}\left( {{\mathcal{L}}_{CE}\left( {{y}_{i}^{S},{\widehat{y}}_{i}^{S}}\right) }\right)  + {\kappa }_{3} \tag{10}
$$

where ${\kappa }_{3}$ is a positive constant. The optimization problem in (10) is convex w.r.t. each ${\alpha }_{{x}_{i}^{S}}$ , but it is non-smooth because of involving ${l}_{1}$ -norm of ${\alpha }_{{x}_{i}^{S}}$ . As in [20], to solve this non-smooth problem, we replace the ${l}_{1}$ -norm with epsilon- ${l}_{1}$ norm. The epsilon norm of an arbitrary vector $v$ is computed by $\mathop{\sum }\limits_{k}\sqrt{{v}_{k}^{2} + \xi }$ , with a small positive constant $\xi  = {10}^{-5}$ . Considering this norm definition, the derivative of (10) w.r.t. ${\alpha }_{{x}_{i}^{S}}$ can be calculated as:

其中 ${\kappa }_{3}$ 是一个正常数。式 (10) 中的优化问题关于每个 ${\alpha }_{{x}_{i}^{S}}$ 是凸的，但由于涉及 ${\alpha }_{{x}_{i}^{S}}$ 的 ${l}_{1}$ 范数，问题是非光滑的。参考文献 [20]，为了解决该非光滑问题，我们用 epsilon-${l}_{1}$ 范数替代 ${l}_{1}$ 范数。任意向量 $v$ 的 epsilon 范数通过 $\mathop{\sum }\limits_{k}\sqrt{{v}_{k}^{2} + \xi }$ 计算，其中 $\xi  = {10}^{-5}$ 是一个小的正常数。基于该范数定义，(10) 关于 ${\alpha }_{{x}_{i}^{S}}$ 的导数可计算为:

$$
\frac{\partial {J}_{1}^{\left( 3\right) }}{\partial {\alpha }_{{x}_{i}^{S}}} =  - 2{D}^{\top }\left( {{f}_{\theta }\left( {x}_{i}^{S}\right)  - D{\alpha }_{{x}_{i}^{S}}}\right)  + {\omega }_{1}{\Delta }_{1}{\alpha }_{{x}_{i}^{S}} + {\omega }_{2}{\nabla }_{{\alpha }_{{x}_{i}^{S}}}{\mathcal{L}}_{CE}^{i}
$$

(11)

where ${\Delta }_{1} \in  {\mathbb{R}}^{q \times  q}$ is a diagonal matrix with non-zero elements ${\delta }_{jj} = {\left( {\alpha }_{ij}^{2} + \epsilon \right) }^{-\frac{1}{2}}$ for row indices $j = 1,2,\ldots , q$ . Here, $\nabla$ is the differential operator and ${\mathcal{L}}_{CE}^{i} = {\mathcal{L}}_{CE}\left( {{y}_{i}^{S},{\widehat{y}}_{i}^{S}}\right)$ . We calculate the analytical solution of ${\alpha }_{{x}_{i}}$ by setting $\partial {J}_{1}^{\left( 3\right) }/\partial {\alpha }_{{x}_{i}^{S}}$ to zero. Hence, ${\alpha }_{{x}_{i}^{S}}$ is calculated by:

其中 ${\Delta }_{1} \in  {\mathbb{R}}^{q \times  q}$ 是一个对角矩阵，其非零元素为 ${\delta }_{jj} = {\left( {\alpha }_{ij}^{2} + \epsilon \right) }^{-\frac{1}{2}}$ ，对应行索引为 $j = 1,2,\ldots , q$ 。这里，$\nabla$ 是微分算子，${\mathcal{L}}_{CE}^{i} = {\mathcal{L}}_{CE}\left( {{y}_{i}^{S},{\widehat{y}}_{i}^{S}}\right)$ 。我们通过令 $\partial {J}_{1}^{\left( 3\right) }/\partial {\alpha }_{{x}_{i}^{S}}$ 为零，计算 ${\alpha }_{{x}_{i}}$ 的解析解。因此，${\alpha }_{{x}_{i}^{S}}$ 计算为:

$$
{\alpha }_{{x}_{i}^{S}} = {\left( {D}^{\top }D + \frac{{\omega }_{1}}{2}{\Delta }_{1}\right) }^{-1}\left( {{D}^{\top }{f}_{\theta }\left( {x}_{i}^{S}\right)  - \frac{{\omega }_{2}}{2}{\nabla }_{{\alpha }_{{x}_{i}^{S}}}{\mathcal{L}}_{CE}^{i}}\right)
$$

(12)

Considering the dependency of ${\Delta }_{1}$ to $A$ in (12), we can obtain ${\alpha }_{{x}_{i}^{S}}$ by alternatively optimizing ${\alpha }_{{x}_{i}^{S}}$ and ${\Delta }_{1}$ . We initialize ${\alpha }_{{x}_{i}^{S}} = {\left( {D}^{\top }D + {\omega }_{1}I\right) }^{-1}{D}^{\top }{f}_{\theta }\left( {x}_{i}^{S}\right)$ where $I \in  {\mathbb{R}}^{q \times  q}$ is the Identity matrix. The training procedure of Module 1 is shown in Algorithm 1.

考虑到 (12) 中 ${\Delta }_{1}$ 对 $A$ 的依赖性，我们可以通过交替优化 ${\alpha }_{{x}_{i}^{S}}$ 和 ${\Delta }_{1}$ 来获得 ${\alpha }_{{x}_{i}^{S}}$ 。我们初始化 ${\alpha }_{{x}_{i}^{S}} = {\left( {D}^{\top }D + {\omega }_{1}I\right) }^{-1}{D}^{\top }{f}_{\theta }\left( {x}_{i}^{S}\right)$ ，其中 $I \in  {\mathbb{R}}^{q \times  q}$ 是单位矩阵。模块1的训练过程如算法1所示。

Module 2: Training $G$ and ${D}_{1}$ : In the second module, we train the proposed CGAN using a minimax game shown in (2). The discriminator ${D}_{1}$ and sparse code generator $G$ are two players of this game. ${D}_{1}$ and $G$ seek to maximize and minimize the defined objective function in (2), respectively. Hence, the parameters of ${D}_{1}$ denoted by ${\theta }_{{D}_{1}}$ are updated by stochastic gradient ascent on ${N}_{S}$ source samples. The gradient of (2) w.r.t. ${\theta }_{{D}_{1}}$ is obtained by:

模块2:训练$G$和${D}_{1}$:在第二模块中，我们使用公式(2)中展示的极小极大博弈训练所提出的条件生成对抗网络(CGAN)。判别器${D}_{1}$和稀疏编码生成器$G$是该博弈的两个参与者。${D}_{1}$和$G$分别寻求最大化和最小化公式(2)中定义的目标函数。因此，${D}_{1}$的参数，记为${\theta }_{{D}_{1}}$，通过对${N}_{S}$个源样本进行随机梯度上升进行更新。公式(2)关于${\theta }_{{D}_{1}}$的梯度由下式获得:

$$
\frac{\partial }{\partial {\theta }_{{D}_{1}}}\left( {\frac{1}{{N}_{S}}\mathop{\sum }\limits_{{i = 1}}^{{N}_{S}}\left\lbrack  {\log \left( {1 - {D}_{1}\left( {G\left( {\epsilon ,{y}_{i}^{S}}\right) ,{y}_{i}^{S}}\right) }\right) }\right. }\right.
$$

$$
\left. \left. {+\log {D}_{1}\left( {{\alpha }_{{x}_{i}^{S}},{y}_{i}^{S}}\right) }\right\rbrack  \right)  \tag{13}
$$

Algorithm 1: Module 1 Training.

算法1:模块1训练。

---

Inputs: Source data $\left( {{X}^{S},{Y}^{S}}\right)$ , Objective coefficients

输入:源数据$\left( {{X}^{S},{Y}^{S}}\right)$，目标系数

${\omega }_{1},{\omega }_{2},{\omega }_{3}$ and GD Learning rate $\beta$ .

${\omega }_{1},{\omega }_{2},{\omega }_{3}$和梯度下降学习率$\beta$。

Output: Trained $D,{\theta }_{f},{W}_{C}$ and ${b}_{C}$ .

输出:训练后的$D,{\theta }_{f},{W}_{C}$和${b}_{C}$。

while Objective ${J}_{1}$ in (1) is not converged do

当公式(1)中的目标${J}_{1}$未收敛时，循环执行

	- Step 1: Training ${\theta }_{f},{W}_{C},{b}_{C}$

	- 步骤1:训练${\theta }_{f},{W}_{C},{b}_{C}$

	for ${x}_{i}^{S} \in  {X}^{S}$ do

	对于${x}_{i}^{S} \in  {X}^{S}$执行

		Update $\Theta  = \left\{  {{\theta }_{f},{W}_{C},{b}_{C}}\right\}$ by GD using $\partial {J}_{1}^{\left( 1\right) }/\partial \Theta$

		使用$\partial {J}_{1}^{\left( 1\right) }/\partial \Theta$通过梯度下降更新$\Theta  = \left\{  {{\theta }_{f},{W}_{C},{b}_{C}}\right\}$

	end for

	结束循环

	- Step 2: Training $D$

	- 步骤2:训练$D$

	Initialize $\Phi  = 1$ , and $\Delta  = {N}^{S}\operatorname{diag}\left( \Phi \right)  \in  {\mathbb{R}}^{q \times  q}$

	初始化$\Phi  = 1$和$\Delta  = {N}^{S}\operatorname{diag}\left( \Phi \right)  \in  {\mathbb{R}}^{q \times  q}$

	while ${\mathcal{L}}_{\text{Dual }}\left( \Phi \right)$ is not converge do

	当${\mathcal{L}}_{\text{Dual }}\left( \Phi \right)$未收敛时，循环执行

		Obtain ${\Delta }^{ * }$ using (9)

		使用公式(9)获得${\Delta }^{ * }$

	end while

	结束循环

	Obtain $D$ by substituting ${\Delta }^{ * }$ into (7)

	通过将${\Delta }^{ * }$代入公式(7)获得$D$

	- Step 3: Training $A$

	- 第3步:训练 $A$

	for ${x}_{i}^{S} \in  {X}^{S}$ do

	对于 ${x}_{i}^{S} \in  {X}^{S}$ 执行

		Initialize ${\alpha }_{{x}_{i}^{S}} = {\left( {D}^{\top }D + {\omega }_{3}I\right) }^{-1}{D}^{\top }{f}_{\theta }\left( {x}_{i}^{S}\right)$

		初始化 ${\alpha }_{{x}_{i}^{S}} = {\left( {D}^{\top }D + {\omega }_{3}I\right) }^{-1}{D}^{\top }{f}_{\theta }\left( {x}_{i}^{S}\right)$

		while Objective ${J}_{1}^{\left( 3\right) }$ in (10) is not converged do

		当目标函数 ${J}_{1}^{\left( 3\right) }$ 在(10)中未收敛时执行

			Alternatively update ${\Delta }_{1}$ and ${\alpha }_{{x}_{i}^{S}}$ in (12)

			交替更新(12)中的 ${\Delta }_{1}$ 和 ${\alpha }_{{x}_{i}^{S}}$

		end while

		结束循环

	end for

	结束循环

end while

结束循环

---

Algorithm 2: Module 2 Training.

算法2:模块2训练。

---

Inputs: Source data $\left( {{X}^{S},{Y}^{S}}\right)$ , Trained sparse coding

输入:源数据 $\left( {{X}^{S},{Y}^{S}}\right)$ ，训练好的稀疏编码

function ${E}_{SC}$ , and adversarial training epochs ${k}_{{D}_{1}}$ and

函数 ${E}_{SC}$ ，以及对抗训练轮数 ${k}_{{D}_{1}}$ 和

${k}_{G}$ .

Output: Trained generator $G$ and discriminator ${D}_{1}$ .

输出:训练好的生成器 $G$ 和判别器 ${D}_{1}$ 。

while Objective (2) is not converged do

当目标函数(2)未收敛时执行

	- Training ${D}_{1}$

	- 训练 ${D}_{1}$

	for $k = 1,\ldots ,{k}_{{D}_{1}}$ do

	对于 $k = 1,\ldots ,{k}_{{D}_{1}}$ 执行

		Sample $m$ vectors from $\mathcal{N}$

		从 $\mathcal{N}$ 中采样 $m$ 向量

		Sample $m$ image-label pairs from $\left( {{X}^{S},{Y}^{S}}\right)$

		从$\left( {{X}^{S},{Y}^{S}}\right)$中采样$m$图像-标签对

		Update ${\theta }_{{D}_{1}}$ by ascending the gradient in (13)

		通过对(13)中的梯度上升更新${\theta }_{{D}_{1}}$

	end for

	结束循环

	- Training $G$

	- 训练$G$

	for $k = 1,\ldots ,{k}_{G}$ do

	对$k = 1,\ldots ,{k}_{G}$执行循环

		Sample $m$ vectors from $\mathcal{N}$

		从$\mathcal{N}$中采样$m$向量

		Update ${\theta }_{G}$ by descending the gradient in (14)

		通过对(14)中的梯度下降更新${\theta }_{G}$

	end for

	结束循环

end while

结束while循环

---

The parameters of $G$ are updated by GD. The gradient of (2) w.r.t. ${\theta }_{G}$ is computed by:

通过梯度下降法(GD)更新$G$的参数。计算(2)关于${\theta }_{G}$的梯度如下:

$$
\frac{\partial }{\partial {\theta }_{G}}\left( {\frac{1}{{N}_{S}}\mathop{\sum }\limits_{{i = 1}}^{{N}_{S}}\left\lbrack  {\log \left( {1 - {D}_{1}\left( {G\left( {\epsilon ,{y}_{i}^{S}}\right) ,{y}_{i}^{S}}\right) }\right) }\right\rbrack  }\right)  \tag{14}
$$

Algorithm 2 summarizes the proposed training procedure of Module 2.

算法2总结了模块2的训练过程。

Module 3: Training ${D}_{2}$ and ${E}_{DI}$ : As stated in Section III-A3, ${D}_{2}$ and ${E}_{DI}$ aim to maximize and minimize (3), respectively. The optimization process can be performed using the iterative method by alternatively optimizing ${D}_{2}$ and ${E}_{DI}$ . To train ${D}_{2}$ with fixed ${E}_{DI}$ , the minimax game in (3) can be rewritten as:

模块3:训练${D}_{2}$和${E}_{DI}$:如第III-A3节所述，${D}_{2}$和${E}_{DI}$分别旨在最大化和最小化(3)。该优化过程可通过交替优化${D}_{2}$和${E}_{DI}$的迭代方法实现。为在固定${E}_{DI}$的情况下训练${D}_{2}$，(3)中的极大极小游戏可重写为:

$$
\mathop{\max }\limits_{{\theta }_{{D}_{2}}}{\mathcal{L}}_{{D}_{2}} = \frac{1}{N}\mathop{\sum }\limits_{{i = 1}}^{N}\log {D}_{2}\left( {\alpha }_{{x}_{i}^{S}}\right)  + \log \left( {1 - {D}_{2}\left( {G\left( {\epsilon ,{y}_{i}^{S}}\right) }\right) }\right)  \tag{15}
$$

Algorithm 3: Module 3 Training.

算法3:模块3训练。

---

Inputs: Source data $\left( {{X}^{S},{Y}^{S}}\right)$ , Target data $\left( {X}^{T}\right)$ ,

输入:源数据$\left( {{X}^{S},{Y}^{S}}\right)$，目标数据$\left( {X}^{T}\right)$，

Trained generator $G$ , and adversarial training epochs

训练好的生成器$G$，以及对抗训练的迭代次数

${k}_{{D}_{2}},{k}_{DI}$ .

Output: Trained ${E}_{DI}$ and ${D}_{2}$ .

输出:训练好的${E}_{DI}$和${D}_{2}$。

while Objective (3) is not converged do

当目标函数(3)未收敛时，执行

	- Training ${D}_{2}$

	- 训练${D}_{2}$

	for $k = 1,\ldots ,{k}_{{D}_{2}}$ do

	对于$k = 1,\ldots ,{k}_{{D}_{2}}$执行

		Sample $m$ random vectors from $\mathcal{N}$

		从$\mathcal{N}$中采样$m$个随机向量

		Sample $m$ random images from ${X}^{S} \cup  {X}^{T}$

		从${X}^{S} \cup  {X}^{T}$中采样$m$张随机图像

		Update ${\theta }_{{D}_{2}}$ by ascending the gradient of (15)

		通过对(15)的梯度上升更新${\theta }_{{D}_{2}}$

	end for

	结束循环

	- Training ${E}_{DI}$

	- 训练${E}_{DI}$

	for $k = 1,\ldots ,{k}_{DI}$

	对于$k = 1,\ldots ,{k}_{DI}$执行

		Sample $m$ random sample from $\left( {{X}^{S},{Y}^{S}}\right)$

		从$\left( {{X}^{S},{Y}^{S}}\right)$中采样$m$个随机样本

		Update ${\theta }_{{E}_{DI}}$ in (16)

		根据(16)更新${\theta }_{{E}_{DI}}$

	end for

	结束循环

end while

结束循环

---

where $N = {N}_{S} + {N}_{T}$ , and ${x}_{i}$ is a sample drawn from ${X}^{S} \cup$ ${X}^{T}$ . We implement ${D}_{2}$ using a deep ReLU neural network, therefore,(15) can be solved using GD with $\partial {\mathcal{L}}_{D2}/\partial {\theta }_{{D}_{2}}$ .

其中$N = {N}_{S} + {N}_{T}$和${x}_{i}$是从${X}^{S} \cup$${X}^{T}$中抽取的样本。我们使用深度ReLU神经网络实现${D}_{2}$，因此，(15)可以使用带有$\partial {\mathcal{L}}_{D2}/\partial {\theta }_{{D}_{2}}$的梯度下降法(GD)求解。

Using the learned ${D}_{2}$ , the optimization can be written as:

利用学习到的${D}_{2}$，优化问题可表示为:

$$
\mathop{\min }\limits_{{A, D,{\theta }_{f}}}{\mathcal{L}}_{{\theta }_{{E}_{DI}}} = \frac{1}{N}\mathop{\sum }\limits_{{i = 1}}^{N}\left( \left( {\log {D}_{2}\left( {\alpha }_{{x}_{i}}\right) }\right) \right.
$$

$$
\left. {+{\begin{Vmatrix}{f}_{\theta }\left( {x}_{i}\right)  - D{\alpha }_{{x}_{i}}\end{Vmatrix}}_{2}^{2} + {\omega }_{1}{\begin{Vmatrix}{\alpha }_{{x}_{i}}\end{Vmatrix}}_{1}}\right)
$$

$$
\text{s.t.}{\begin{Vmatrix}{d}_{j}\end{Vmatrix}}_{2}^{2} \leq  1,\forall 1 \leq  j \leq  q \tag{16}
$$

The optimization problem in (16) is similar to (1), therefore, ${f}_{\theta }$ is trained using GD with $\partial {\mathcal{L}}_{{\theta }_{{E}_{DI}}}/\partial {\theta }_{f}$ as in Step 1 of Algorithm 1. Similar to (5), we update $D$ using (7), and similar to (12), the sparse code ${\alpha }_{{x}_{i}}$ corresponding to each ${x}_{i} \sim  {X}^{S} \cup  {X}^{T}$ is obtained by:

式(16)中的优化问题与(1)类似，因此，${f}_{\theta }$采用算法1第1步中的GD方法并以$\partial {\mathcal{L}}_{{\theta }_{{E}_{DI}}}/\partial {\theta }_{f}$进行训练。类似于(5)，我们使用(7)更新$D$，类似于(12)，对应每个${x}_{i} \sim  {X}^{S} \cup  {X}^{T}$的稀疏编码${\alpha }_{{x}_{i}}$通过以下方式获得:

$$
{\alpha }_{{x}_{i}} = {\left( {D}^{\top }D + \frac{{\omega }_{1}}{2}{\Delta }_{1}\right) }^{-1}{\left( {D}^{\top }{f}_{\theta }\left( {x}_{i}\right)  - \frac{1}{2}{\nabla }_{{\alpha }_{{x}_{i}}}{\mathcal{L}}_{{D}_{2}}^{i}\right) }_{.} \tag{17}
$$

where ${\mathcal{L}}_{{D}_{2}}^{i} = \log {D}_{2}\left( {\alpha }_{{x}_{i}}\right)$ . Algorithm 3 shows the training procedure of Module 3.

其中${\mathcal{L}}_{{D}_{2}}^{i} = \log {D}_{2}\left( {\alpha }_{{x}_{i}}\right)$。算法3展示了模块3的训练过程。

## IV. EXPERIMENTAL RESULTS

## 四、实验结果

## A. Datasets

## A. 数据集

We evaluate our proposed model on three real-world traffic scene datasets including the Honda Scenes Dataset (HSD) [1], Berkeley DeepDrive ${100}\mathrm{\;K}$ (BDD100 K) [21], and Fleet Management 3 (FM3) [7]. Table I shows number of samples (images) for HSD across four different domains (i.e., sunny(S), cloudy (T1), rainy(T2), snowy(T3)). As stated in the problem formulation in Section II, we consider $S$ as source and ${T1},{T2}$ , and ${T3}$ as our target domains.

我们在三个真实交通场景数据集上评估所提模型，包括Honda Scenes Dataset (HSD) [1]、Berkeley DeepDrive ${100}\mathrm{\;K}$ (BDD100K) [21]和Fleet Management 3 (FM3) [7]。表I展示了HSD在四个不同域(即晴天(S)、多云(T1)、雨天(T2)、雪天(T3))中的样本(图像)数量。如第二节问题描述所述，我们将$S$视为源域，${T1},{T2}$和${T3}$作为目标域。

TABLE I

NUMBER OF SAMPLES OF DIFFERENT DATASETS IN SOURCE AND TARGET DOMAINS

源域和目标域中不同数据集的样本数量

<table><tr><td rowspan="2">Dataset</td><td rowspan="2">Source Domain Sunny (S)</td><td colspan="3">Target Domains</td><td rowspan="2">Total</td></tr><tr><td>Cloudy (T1)</td><td>Rainy (T2)</td><td>Snowy (T3)</td></tr><tr><td>HSD</td><td>712,185</td><td>149,481</td><td>32,850</td><td>16,540</td><td>911,056</td></tr><tr><td>BDD100K</td><td>60,591</td><td>12,591</td><td>7.125</td><td>7,888</td><td>88.195</td></tr><tr><td>FM3</td><td>6,413</td><td>2,105</td><td>2,428</td><td>514</td><td>5,035</td></tr></table>

<table><tbody><tr><td rowspan="2">数据集</td><td rowspan="2">源域 晴天 (S)</td><td colspan="3">目标域</td><td rowspan="2">总计</td></tr><tr><td>多云 (T1)</td><td>雨天 (T2)</td><td>雪天 (T3)</td></tr><tr><td>HSD</td><td>712,185</td><td>149,481</td><td>32,850</td><td>16,540</td><td>911,056</td></tr><tr><td>BDD100K</td><td>60,591</td><td>12,591</td><td>7.125</td><td>7,888</td><td>88.195</td></tr><tr><td>FM3</td><td>6,413</td><td>2,105</td><td>2,428</td><td>514</td><td>5,035</td></tr></tbody></table>

![bo_d285ftn7aajc738oslfg_5_902_459_729_483_0.jpg](images/bo_d285ftn7aajc738oslfg_5_902_459_729_483_0.jpg)

Fig. 3. Sample images corresponding to four classes in our four domains of HSD dataset. The first, second, third, and fourth rows indicate Zebra Crossing, Construction Zone, Rail Crossing, and 4-Way Intersection, respectively.

图3. HSD数据集中四个领域对应的四个类别的示例图像。第一、二、三、四行分别表示斑马线、施工区、铁路道口和四路交叉口。

The HSD is a recent large-scale annotated image dataset for traffic scene classification collected by the Honda Research Institute, CA, USA [1]. This dataset contains traffic images in various weather conditions including sunny, cloudy, and rainy in San Francisco Bay area. Due to the lack of snowy scenes, we collect and use snowy images from YouTube videos trimmed with 25 fps rate. The resolution of our images is ${1280} \times  {720}$ pixels. We consider eight classes including construction zone (CZ), zebra crossing (ZC), 3-way intersection (I3), 4-way intersection (I4), overhead bridge (OB), rail crossing (RC), no signal intersection (NS), and stop intersection (SI) under different domains. Fig. 3 depicts four random samples of four different classes in each domain.

HSD是由美国加州本田研究所收集的一个最新的大规模带注释的交通场景分类图像数据集[1]。该数据集包含旧金山湾区各种天气条件下的交通图像，包括晴天、多云和雨天。由于缺乏雪天场景，我们从YouTube视频中以25帧每秒的速率截取并使用了雪天图像。我们的图像分辨率为${1280} \times  {720}$像素。我们考虑了八个类别，包括施工区(CZ)、斑马线(ZC)、三路交叉口(I3)、四路交叉口(I4)、天桥(OB)、铁路道口(RC)、无信号交叉口(NS)和停车交叉口(SI)，涵盖不同领域。图3展示了每个领域中四个不同类别的四个随机样本。

The BDD100 K is an innovative, wide-ranging, and large-scale dataset of visual driving scenes. This dataset is composed of ${10}^{5}$ high-resolution (720p) images collected in New York, Berkeley, and San Francisco under four major weather conditions including clear, cloudy, rainy, and snowy. There are six categories of visual scenes in this dataset, including city streets (CS), parking lots (PL), gas stations (GS), tunnels (TU), residential areas (RA), and highways (HI).

BDD100 K是一个创新的、广泛的、大规模视觉驾驶场景数据集。该数据集由在纽约、伯克利和旧金山采集的${10}^{5}$张高分辨率(720p)图像组成，涵盖晴朗、多云、雨天和雪天四种主要天气条件。数据集中包含六类视觉场景，包括城市街道(CS)、停车场(PL)、加油站(GS)、隧道(TU)、住宅区(RA)和高速公路(HI)。

The FM3 is a novel traffic scene categorization dataset that contains 11,448 images captured in Croatia using an on-board RGB camera. The images are taken during daylight hours with a resolution of ${640} \times  {480}$ pixels. There are two subsets of images in this dataset: the main part, FM3m, which contains 6,413 images with good visibility and illumination conditions (i.e., sunny), and the appendix, FM3a, which contains 5,035 images with various types of visual degradation caused by changes in weather conditions (i.e., cloudy, rainy, and snowy). We consider FM3m as our source domain and different weather conditions of FM3a as our target domains. In this dataset, the traffic scenes are categorized into eight classes: highway (HI), road (RO), tunnel (TU), exit (EX), settlement (SE), overhead bridge (OB), booth (BO), and traffic (TR).

FM3是一个新颖的交通场景分类数据集，包含在克罗地亚使用车载RGB摄像头拍摄的11,448张图像。图像均在白天拍摄，分辨率为${640} \times  {480}$像素。该数据集包含两个子集:主集FM3m，包含6,413张具有良好能见度和光照条件(即晴天)的图像；附录集FM3a，包含5,035张因天气变化(即多云、雨天和雪天)导致视觉退化的图像。我们将FM3m视为源域，将FM3a中不同天气条件视为目标域。数据集中交通场景分为八类:高速公路(HI)、道路(RO)、隧道(TU)、出口(EX)、居民区(SE)、天桥(OB)、收费亭(BO)和交通(TR)。

## B. Experimental Settings

## B. 实验设置

Motivated by the significant success of residual convolutional networks for visual feature extraction [22], we use the ResNet152 [23] neural network as our encoder ${f}_{\theta }$ pretrained on the Places365 dataset [24]. Using a pretrained neural network boosts the classification accuracy and decrease the training time of the first module. The GD is implemented using Adam optimizer [25] with a momentum 0.95 , weight decay 0.005 , and an adaptive learning rate ${\beta }_{k + 1} = {\beta }_{k} \times  {\left( 1 - k/{E}_{Max}\right) }^{0.9}$ where $k$ is the training iteration number and ${E}_{Max} = {25} \times  {10}^{3}$ is the total number of training epochs. The initial value ${\beta }_{1}$ is set to 0.01 . In all of our experiments, we set the input batch size to 64 .

受残差卷积网络在视觉特征提取方面显著成功的启发[22]，我们采用在Places365数据集[24]上预训练的ResNet152[23]神经网络作为编码器${f}_{\theta }$。使用预训练神经网络提升了分类准确率并减少了第一个模块的训练时间。GD采用Adam优化器[25]实现，动量为0.95，权重衰减为0.005，自适应学习率为${\beta }_{k + 1} = {\beta }_{k} \times  {\left( 1 - k/{E}_{Max}\right) }^{0.9}$，其中$k$为训练迭代次数，${E}_{Max} = {25} \times  {10}^{3}$为训练总轮数。初始值${\beta }_{1}$设为0.01。在所有实验中，输入批量大小设为64。

The classifier ${C}_{W, b}$ is considered as a 3-layer fully connected ReLU deep neural network [26] with a $c$ -dimensional softmax output layer where each output unit corresponds to a class (e.g., zebra crossing, construction zone, etc.). we set $c = 8$ for HSD and FM3, while $c = 6$ for BDD100 K. We implemented our generator $G$ by a DNN that contains two identical blocks. Each block contains a 1024-dimensional fully connected ReLU layer, a Batch Normalization layer [27], and a Dropout layer [28] with dropout rate $p = {0.25}$ . The latter block is connected to a $q$ -dimensional fully connected layer with tanh activation function. ${D}_{1}$ is a DNN with two dense ReLU layers and a sigmoid neuron in its output layer. The first ReLU layer has 512 units and the second layer has 128 units. ${D}_{2}$ is implemented using the same DNN structure as ${D}_{1}$ .

分类器${C}_{W, b}$被设计为一个三层全连接ReLU深度神经网络[26]，输出层为$c$维的softmax，每个输出单元对应一个类别(如斑马线、施工区等)。我们为HSD和FM3设置$c = 8$，为BDD100 K设置$c = 6$。生成器$G$由包含两个相同模块的深度神经网络构成。每个模块包含一个1024维全连接ReLU层、一个批归一化层[27]和一个丢弃率为$p = {0.25}$的Dropout层[28]。后一个模块连接到一个具有tanh激活函数的$q$维全连接层。${D}_{1}$是一个包含两个密集ReLU层和一个sigmoid输出神经元的深度神经网络。第一层ReLU有512个单元，第二层有128个单元。${D}_{2}$采用与${D}_{1}$相同的网络结构实现。

We consider ${15}\%$ of the source images uniformly sampled from all classes as our validation set. To determine the optimal hyper-parameters $h, q,{\omega }_{1},{\omega }_{2}$ , and ${\omega }_{3}$ , we evaluate different configurations of $h \in  \left\lbrack  {{100},{500}}\right\rbrack  , q \in  \left\lbrack  {{50},{300}}\right\rbrack  ,{\omega }_{1} \in  \left\lbrack  {{0.05},{0.55}}\right\rbrack$ , ${\omega }_{2} \in  \left\lbrack  {{0.1},1}\right\rbrack$ , and ${\omega }_{3} \in  \left\lbrack  {{10}^{-5},{10}^{-1}}\right\rbrack$ . The configuration with the maximum classification accuracy on the validation set is considered as the optimal hyper-parameters. As shown in Fig. 4, the configuration with $h = {400}, q = {150},{\omega }_{1} = {0.15},{\omega }_{2} = {0.9}$ , and ${\omega }_{3} = {10}^{-3}$ results in the maximum validation accuracy. It must be highlighted that ${E}_{SC}$ and ${E}_{DI}$ share the same structure, therefore, they have equal hyper-parameters.

我们将源图像中均匀采样自所有类别的${15}\%$作为验证集。为了确定最优超参数$h, q,{\omega }_{1},{\omega }_{2}$和${\omega }_{3}$，我们评估了不同配置的$h \in  \left\lbrack  {{100},{500}}\right\rbrack  , q \in  \left\lbrack  {{50},{300}}\right\rbrack  ,{\omega }_{1} \in  \left\lbrack  {{0.05},{0.55}}\right\rbrack$、${\omega }_{2} \in  \left\lbrack  {{0.1},1}\right\rbrack$和${\omega }_{3} \in  \left\lbrack  {{10}^{-5},{10}^{-1}}\right\rbrack$。在验证集上分类准确率最高的配置被视为最优超参数。如图4所示，配置为$h = {400}, q = {150},{\omega }_{1} = {0.15},{\omega }_{2} = {0.9}$和${\omega }_{3} = {10}^{-3}$时，验证准确率达到最大。需要强调的是，${E}_{SC}$和${E}_{DI}$结构相同，因此它们具有相同的超参数。

We developed and trained our model in Python 3.8 with the Pytorch framework [29] on a PC with Intel Core-i7 CPU, NVidia Quadro RTX 6000 GPU, and 256 GB of RAM memory.

我们在配备Intel Core-i7 CPU、NVidia Quadro RTX 6000 GPU和256 GB内存的PC上，使用Python 3.8和Pytorch框架[29]开发并训练了我们的模型。

## C. Baselines

## C. 基线方法

We compare the presented work with the most recent studies on traffic scene classification, including deep transfer learning with image descriptors (DTLID) [7], deep multi-classifier fusion (DMCF) [8], deep Inception neural network (DINN) [9], and Faster Region with convolutional neural network (FRCNN) [19].

我们将所提出的工作与最新的交通场景分类研究进行比较，包括基于图像描述符的深度迁移学习(DTLID)[7]、深度多分类器融合(DMCF)[8]、深度Inception神经网络(DINN)[9]以及基于卷积神经网络的Faster Region(FRCNN)[19]。

![bo_d285ftn7aajc738oslfg_6_886_184_736_459_0.jpg](images/bo_d285ftn7aajc738oslfg_6_886_184_736_459_0.jpg)

Fig. 4. Hyperparameter selection based on validation accuracy.

图4. 基于验证准确率的超参数选择。

Moreover, we compare our proposed model with state-of-the-art domain adaptation-based image classification frameworks including the Deep Siamese DA convolutional neural Network (DSDANet) [30], Multi-Representation Adaptation Network (MRAN) [31], Center-aligned domain adaptation network (Cen-terDA) [34], Dissimilarity-based Maximum Mean Discrepancy (D-MMD) [32], Drop To Adapt network (DTA) [33], Stochastic classifiers (STAR) [35], and Dynamic Weighted Learning (DWL) [36]. In addition, to highlight the importance of domain adaptation on improving the classification results, we report the accuracy of our model without domain adaptation. In this baseline, called Source Only, we train ${E}_{DI}$ on source and test it on target domains. The baselines considered in our research have been reimplemented and evaluated using the datasets in our studies. In order to provide a fair comparison, we use grid search to tune the hyperparameters of other baselines, and the set of hyperparameters with the lowest validation MAPE is considered the optimal set of hyperparameters.

此外，我们将所提模型与最先进的基于领域自适应的图像分类框架进行比较，包括深度孪生领域自适应卷积神经网络(DSDANet)[30]、多表示自适应网络(MRAN)[31]、中心对齐领域自适应网络(CenterDA)[34]、基于不相似性最大均值差异(D-MMD)[32]、Drop To Adapt网络(DTA)[33]、随机分类器(STAR)[35]和动态加权学习(DWL)[36]。此外，为突出领域自适应在提升分类结果中的重要性，我们报告了未使用领域自适应的模型准确率。在此基线中，称为仅源域(Source Only)，我们在源域上训练${E}_{DI}$，并在目标域上测试。我们研究中考虑的基线方法均已重新实现并使用本研究的数据集进行评估。为保证公平比较，我们采用网格搜索调优其他基线的超参数，验证集上MAPE最低的超参数组被视为最优超参数组。

## D. Results and Discussion

## D. 结果与讨论

Tables II-IV show the obtained average accuracy of our proposed model and the benchmarks for the HSD when the source is sunny and targets are cloudy (shown asSunny $\rightarrow$ Cloudy), rainy (shown as Sunny $\rightarrow$ Rainy), and snowy (shown as Sunny $\rightarrow$ Rainy), respectively. The tables summarize the classification accuracy of each class and the performance of the baselines on all defined classes in HSD. Similarly, Tables V-VII and VIII-X compare the average classification accuracies of the models for source and target images of BDD100 K and FM3 datasets, respectively. From the obtained results in Tables IV, VII, and $\mathrm{X}$ , we observe that $\operatorname{Sunny} \rightarrow  \operatorname{Snowy}$ is the most difficult cross-domain problem which yields the lowest classification accuracy on the target set $\left( {{T}_{3} : \text{ Snowy }}\right)$ across all classes in different datasets. For instance, in the cloudy domain of BDD100 K dataset, the average classification accuracy of FRCNN and DSDANet are ${74.85}\%$ and ${79.40}\%$ , while in the snowy domain, these results are ${58.27}\%$ and ${64.62}\%$ , respectively. This drop in classification accuracy stems from the stronger visual variations inSunny $\rightarrow$ Snowy compared to Sunny $\rightarrow$ Cloudy domain shifts.

表II-IV展示了当源域为晴天，目标域分别为多云(表示为Sunny $\rightarrow$ Cloudy)、雨天(表示为Sunny $\rightarrow$ Rainy)和雪天(表示为Sunny $\rightarrow$ Rainy)时，我们提出的模型与基准方法在HSD(天气状态识别，HSD)任务中的平均准确率。表中总结了每个类别的分类准确率以及基线方法在HSD所有定义类别上的表现。同样，表V-VII和VIII-X分别比较了BDD100K和FM3数据集中源图像与目标图像的模型平均分类准确率。从表IV、VII及$\mathrm{X}$中的结果可以看出，$\operatorname{Sunny} \rightarrow  \operatorname{Snowy}$是最具挑战性的跨域问题，在不同数据集的所有类别中，目标集$\left( {{T}_{3} : \text{ Snowy }}\right)$的分类准确率最低。例如，在BDD100K数据集的多云域中，FRCNN和DSDANet的平均分类准确率分别为${74.85}\%$和${79.40}\%$，而在雪天域中，这些结果分别为${58.27}\%$和${64.62}\%$。分类准确率的下降主要源于Sunny $\rightarrow$ Snowy相比Sunny $\rightarrow$ Cloudy域转移中更强烈的视觉变化。

TABLE II

CLASSIFICATION ACCURACIES (MEAN ± STD %) FOR DIFFERENT METHODS OVER TEN INDEPENDENT RUNS FOR THE ${Sunny} \rightarrow  {Cloudy}$ TASK IN THE HSD DATASET. THE BEST RESULTS ARE INDICATED IN BOLD AND THE SECOND BEST RESULTS ARE UNDERLINED

HSD数据集中${Sunny} \rightarrow  {Cloudy}$任务不同方法的分类准确率(均值 ± 标准差 %)，基于十次独立运行。最佳结果以粗体表示，次佳结果以下划线标出

<table><tr><td>Method</td><td>CZ</td><td>ZC</td><td>I3</td><td>I4</td><td>OB</td><td>RC</td><td>NS</td><td>SI</td><td>Average</td></tr><tr><td>Source Only</td><td>${75.4} \pm  {0.7}$</td><td>${72.6} \pm  {0.4}$</td><td>${74.8} \pm  {0.6}$</td><td>${76.9} \pm  {0.2}$</td><td>${79.3} \pm  {0.4}$</td><td>${77.6} \pm  {0.8}$</td><td>${75.2} \pm  {0.4}$</td><td>${73.4} \pm  {0.1}$</td><td>75.65</td></tr><tr><td>DINN [9]</td><td>${70.2} \pm  {0.4}$</td><td>${73.6} \pm  {0.2}$</td><td>${71.9} \pm  {0.6}$</td><td>${72.4} \pm  {0.7}$</td><td>${76.8} \pm  {0.5}$</td><td>${74.1} \pm  {0.4}$</td><td>${71.6} \pm  {0.1}$</td><td>${69.3} \pm  {0.2}$</td><td>72.49</td></tr><tr><td>DTLID [7]</td><td>${74.8} \pm  {0.4}$</td><td>${75.9} \pm  {0.1}$</td><td>${73.1} \pm  {0.6}$</td><td>${76.2} \pm  {0.9}$</td><td>${78.4} \pm  {0.8}$</td><td>${73.7} \pm  {0.5}$</td><td>${72.5} \pm  {0.1}$</td><td>${70.4} \pm  {0.2}$</td><td>74.38</td></tr><tr><td>DMCF [8]</td><td>${75.2} \pm  {0.5}$</td><td>${71.3} \pm  {0.1}$</td><td>${75.9} \pm  {0.2}$</td><td>${75.5} \pm  {0.6}$</td><td>${77.4} \pm  {0.7}$</td><td>${76.1} \pm  {0.5}$</td><td>${73.2} \pm  {0.4}$</td><td>${71.9} \pm  {0.9}$</td><td>74.56</td></tr><tr><td>FRCNN [15]</td><td>${73.2} \pm  {0.1}$</td><td>${75.6} \pm  {0.7}$</td><td>${71.1} \pm  {1.5}$</td><td>${77.9} \pm  {1.1}$</td><td>${74.8} \pm  {0.9}$</td><td>${76.4} \pm  {0.4}$</td><td>${74.3} \pm  {1.4}$</td><td>${75.5} \pm  {0.7}$</td><td>74.85</td></tr><tr><td>DSDANet [26]</td><td>${78.8} \pm  {0.2}$</td><td>${77.1} \pm  {0.6}$</td><td>${79.5} \pm  {0.4}$</td><td>${80.3} \pm  {0.6}$</td><td>${82.7} \pm  {0.4}$</td><td>${81.9} \pm  {0.1}$</td><td>${78.2} \pm  {0.3}$</td><td>${76.7} \pm  {0.1}$</td><td>79.40</td></tr><tr><td>MRAN [27]</td><td>${79.4} \pm  {0.4}$</td><td>${77.1} \pm  {0.3}$</td><td>${81.5} \pm  {0.2}$</td><td>${83.8} \pm  {0.9}$</td><td>${84.6} \pm  {0.8}$</td><td>${81.3} \pm  {0.2}$</td><td>${79.5} \pm  {0.3}$</td><td>${78.7} \pm  {0.4}$</td><td>80.73</td></tr><tr><td>D-MMD [28]</td><td>${82.2} \pm  {0.4}$</td><td>${81.3} \pm  {0.6}$</td><td>${84.5} \pm  {0.7}$</td><td>${86.9} \pm  {0.6}$</td><td>${87.0} \pm  {0.4}$</td><td>${84.4} \pm  {0.8}$</td><td>${81.2} \pm  {0.1}$</td><td>${80.4} \pm  {0.1}$</td><td>83.49</td></tr><tr><td>DTA [29]</td><td>${81.4} \pm  {0.5}$</td><td>${78.1} \pm  {0.9}$</td><td>${80.1} \pm  {0.4}$</td><td>${85.2} \pm  {0.8}$</td><td>${84.4} \pm  {0.2}$</td><td>${83.2} \pm  {0.1}$</td><td>${78.5} \pm  {0.4}$</td><td>${79.3} \pm  {0.6}$</td><td>81.26</td></tr><tr><td>CenterDA [30]</td><td>${80.8} \pm  {0.9}$</td><td>${82.7} \pm  {0.6}$</td><td>${81.9} \pm  {0.8}$</td><td>${83.1} \pm  {1.0}$</td><td>${81.7} \pm  {0.7}$</td><td>${82.4} \pm  {0.5}$</td><td>${82.6} \pm  {1.2}$</td><td>${82.3} \pm  {0.6}$</td><td>82.19</td></tr><tr><td>STAR [31]</td><td>${84.7} \pm  {0.7}$</td><td>${85.9} \pm  {0.6}$</td><td>${87.1} \pm  {0.5}$</td><td>${86.5} \pm  {0.4}$</td><td>${88.4} \pm  {0.1}$</td><td>${86.5} \pm  {0.2}$</td><td>${85.6} \pm  {0.3}$</td><td>${83.2} \pm  {0.9}$</td><td>85.74</td></tr><tr><td>DWL [32]</td><td>${88.0} \pm  {0.8}$</td><td>${86.7} \pm  {0.4}$</td><td>${90.8} \pm  {0.1}$</td><td>${91.6} \pm  {0.2}$</td><td>${91.9} \pm  {0.6}$</td><td>${85.2} \pm  {0.5}$</td><td>${88.1} \pm  {0.3}$</td><td>${87.5} \pm  {0.2}$</td><td>88.75</td></tr><tr><td>Proposed</td><td>${93.4} \pm  {0.6}$</td><td>${92.5} \pm  {0.9}$</td><td>${94.2} \pm  {0.4}$</td><td>${95.4} \pm  {0.1}$</td><td>${96.6} \pm  {0.2}$</td><td>${93.3} \pm  {0.4}$</td><td>${90.4} \pm  {0.1}$</td><td>$\mathbf{{89.8} \pm  {0.2}}$</td><td>93.20</td></tr></table>

<table><tbody><tr><td>方法</td><td>CZ</td><td>ZC</td><td>I3</td><td>I4</td><td>OB</td><td>RC</td><td>NS</td><td>SI</td><td>平均值</td></tr><tr><td>仅源域</td><td>${75.4} \pm  {0.7}$</td><td>${72.6} \pm  {0.4}$</td><td>${74.8} \pm  {0.6}$</td><td>${76.9} \pm  {0.2}$</td><td>${79.3} \pm  {0.4}$</td><td>${77.6} \pm  {0.8}$</td><td>${75.2} \pm  {0.4}$</td><td>${73.4} \pm  {0.1}$</td><td>75.65</td></tr><tr><td>DINN [9]</td><td>${70.2} \pm  {0.4}$</td><td>${73.6} \pm  {0.2}$</td><td>${71.9} \pm  {0.6}$</td><td>${72.4} \pm  {0.7}$</td><td>${76.8} \pm  {0.5}$</td><td>${74.1} \pm  {0.4}$</td><td>${71.6} \pm  {0.1}$</td><td>${69.3} \pm  {0.2}$</td><td>72.49</td></tr><tr><td>DTLID [7]</td><td>${74.8} \pm  {0.4}$</td><td>${75.9} \pm  {0.1}$</td><td>${73.1} \pm  {0.6}$</td><td>${76.2} \pm  {0.9}$</td><td>${78.4} \pm  {0.8}$</td><td>${73.7} \pm  {0.5}$</td><td>${72.5} \pm  {0.1}$</td><td>${70.4} \pm  {0.2}$</td><td>74.38</td></tr><tr><td>DMCF [8]</td><td>${75.2} \pm  {0.5}$</td><td>${71.3} \pm  {0.1}$</td><td>${75.9} \pm  {0.2}$</td><td>${75.5} \pm  {0.6}$</td><td>${77.4} \pm  {0.7}$</td><td>${76.1} \pm  {0.5}$</td><td>${73.2} \pm  {0.4}$</td><td>${71.9} \pm  {0.9}$</td><td>74.56</td></tr><tr><td>FRCNN [15]</td><td>${73.2} \pm  {0.1}$</td><td>${75.6} \pm  {0.7}$</td><td>${71.1} \pm  {1.5}$</td><td>${77.9} \pm  {1.1}$</td><td>${74.8} \pm  {0.9}$</td><td>${76.4} \pm  {0.4}$</td><td>${74.3} \pm  {1.4}$</td><td>${75.5} \pm  {0.7}$</td><td>74.85</td></tr><tr><td>DSDANet [26]</td><td>${78.8} \pm  {0.2}$</td><td>${77.1} \pm  {0.6}$</td><td>${79.5} \pm  {0.4}$</td><td>${80.3} \pm  {0.6}$</td><td>${82.7} \pm  {0.4}$</td><td>${81.9} \pm  {0.1}$</td><td>${78.2} \pm  {0.3}$</td><td>${76.7} \pm  {0.1}$</td><td>79.40</td></tr><tr><td>MRAN [27]</td><td>${79.4} \pm  {0.4}$</td><td>${77.1} \pm  {0.3}$</td><td>${81.5} \pm  {0.2}$</td><td>${83.8} \pm  {0.9}$</td><td>${84.6} \pm  {0.8}$</td><td>${81.3} \pm  {0.2}$</td><td>${79.5} \pm  {0.3}$</td><td>${78.7} \pm  {0.4}$</td><td>80.73</td></tr><tr><td>D-MMD [28]</td><td>${82.2} \pm  {0.4}$</td><td>${81.3} \pm  {0.6}$</td><td>${84.5} \pm  {0.7}$</td><td>${86.9} \pm  {0.6}$</td><td>${87.0} \pm  {0.4}$</td><td>${84.4} \pm  {0.8}$</td><td>${81.2} \pm  {0.1}$</td><td>${80.4} \pm  {0.1}$</td><td>83.49</td></tr><tr><td>DTA [29]</td><td>${81.4} \pm  {0.5}$</td><td>${78.1} \pm  {0.9}$</td><td>${80.1} \pm  {0.4}$</td><td>${85.2} \pm  {0.8}$</td><td>${84.4} \pm  {0.2}$</td><td>${83.2} \pm  {0.1}$</td><td>${78.5} \pm  {0.4}$</td><td>${79.3} \pm  {0.6}$</td><td>81.26</td></tr><tr><td>CenterDA [30]</td><td>${80.8} \pm  {0.9}$</td><td>${82.7} \pm  {0.6}$</td><td>${81.9} \pm  {0.8}$</td><td>${83.1} \pm  {1.0}$</td><td>${81.7} \pm  {0.7}$</td><td>${82.4} \pm  {0.5}$</td><td>${82.6} \pm  {1.2}$</td><td>${82.3} \pm  {0.6}$</td><td>82.19</td></tr><tr><td>STAR [31]</td><td>${84.7} \pm  {0.7}$</td><td>${85.9} \pm  {0.6}$</td><td>${87.1} \pm  {0.5}$</td><td>${86.5} \pm  {0.4}$</td><td>${88.4} \pm  {0.1}$</td><td>${86.5} \pm  {0.2}$</td><td>${85.6} \pm  {0.3}$</td><td>${83.2} \pm  {0.9}$</td><td>85.74</td></tr><tr><td>DWL [32]</td><td>${88.0} \pm  {0.8}$</td><td>${86.7} \pm  {0.4}$</td><td>${90.8} \pm  {0.1}$</td><td>${91.6} \pm  {0.2}$</td><td>${91.9} \pm  {0.6}$</td><td>${85.2} \pm  {0.5}$</td><td>${88.1} \pm  {0.3}$</td><td>${87.5} \pm  {0.2}$</td><td>88.75</td></tr><tr><td>提出的方法</td><td>${93.4} \pm  {0.6}$</td><td>${92.5} \pm  {0.9}$</td><td>${94.2} \pm  {0.4}$</td><td>${95.4} \pm  {0.1}$</td><td>${96.6} \pm  {0.2}$</td><td>${93.3} \pm  {0.4}$</td><td>${90.4} \pm  {0.1}$</td><td>$\mathbf{{89.8} \pm  {0.2}}$</td><td>93.20</td></tr></tbody></table>

TABLE III

CLASSIFICATION ACCURACIES (MEAN $\pm$ STD %) FOR DIFFERENT METHODS OVER TEN INDEPEDDENT RUNS FOR THE ${Sunny} \rightarrow$ Rainy TASK IN THE HSD DATASET. THE BEST RESULTS ARE INDICATED IN BOLD AND THE SECOND BEST RESULTS ARE UNDERLINED

HSD数据集中${Sunny} \rightarrow$雨天任务的不同方法在十次独立运行中的分类准确率(平均值$\pm$标准差%)。最佳结果以粗体显示，次佳结果以下划线标出

<table><tr><td>Method</td><td>CZ</td><td>ZC</td><td>13</td><td>I4</td><td>OB</td><td>RC</td><td>NS</td><td>SI</td><td>Average</td></tr><tr><td>Source Only</td><td>${67.2} \pm  {0.1}$</td><td>${62.1} \pm  {0.0}$</td><td>${68.3} \pm  {0.8}$</td><td>${70.2} \pm  {0.4}$</td><td>${66.8} \pm  {0.6}$</td><td>${65.3} \pm  {0.5}$</td><td>${63.7} \pm  {0.7}$</td><td>${56.4} \pm  {0.8}$</td><td>65.00</td></tr><tr><td>DINN [9]</td><td>${66.4} \pm  {0.5}$</td><td>${64.1} \pm  {0.6}$</td><td>${62.3} \pm  {0.1}$</td><td>${65.4} \pm  {0.3}$</td><td>${67.9} \pm  {0.1}$</td><td>${63.6} \pm  {0.4}$</td><td>${58.2} \pm  {0.7}$</td><td>${59.3} \pm  {0.8}$</td><td>63.40</td></tr><tr><td>DTLID [7]</td><td>${68.4} \pm  {0.9}$</td><td>${61.1} \pm  {0.3}$</td><td>${63.3} \pm  {0.7}$</td><td>${66.6} \pm  {0.2}$</td><td>${64.2} \pm  {0.1}$</td><td>${65.7} \pm  {0.4}$</td><td>${61.2} \pm  {0.7}$</td><td>${60.5} \pm  {0.8}$</td><td>63.88</td></tr><tr><td>DMCF [8]</td><td>${64.3} \pm  {0.5}$</td><td>${65.1} \pm  {0.3}$</td><td>${63.8} \pm  {0.4}$</td><td>${68.4} \pm  {0.7}$</td><td>${71.4} \pm  {0.6}$</td><td>${63.5} \pm  {0.3}$</td><td>${59.0} \pm  {0.8}$</td><td>${62.6} \pm  {0.9}$</td><td>64.76</td></tr><tr><td>FRCNN [15]</td><td>${65.7} \pm  {0.7}$</td><td>${64.4} \pm  {0.4}$</td><td>${62.4} \pm  {0.9}$</td><td>${65.8} \pm  {1.3}$</td><td>${66.2} \pm  {1.4}$</td><td>${61.1} \pm  {0.8}$</td><td>${67.1} \pm  {0.6}$</td><td>${65.8} \pm  {0.9}$</td><td>64.81</td></tr><tr><td>DSDANet [26]</td><td>${72.3} \pm  {0.9}$</td><td>${69.4} \pm  {0.4}$</td><td>${73.6} \pm  {0.8}$</td><td>${75.1} \pm  {0.0}$</td><td>${77.2} \pm  {0.1}$</td><td>${74.4} \pm  {0.8}$</td><td>${69.3} \pm  {0.4}$</td><td>${67.8} \pm  {0.3}$</td><td>72.39</td></tr><tr><td>MRAN [27]</td><td>${74.0} \pm  {0.3}$</td><td>${70.1} \pm  {0.2}$</td><td>${74.6} \pm  {0.6}$</td><td>${78.1} \pm  {0.7}$</td><td>${79.2} \pm  {0.9}$</td><td>${76.4} \pm  {0.5}$</td><td>${74.1} \pm  {0.0}$</td><td>${71.7} \pm  {0.6}$</td><td>74.78</td></tr><tr><td>D-MMD [28]</td><td>${79.6} \pm  {0.2}$</td><td>${78.1} \pm  {0.7}$</td><td>${81.3} \pm  {0.1}$</td><td>${80.5} \pm  {0.0}$</td><td>${79.1} \pm  {0.4}$</td><td>${82.5} \pm  {0.5}$</td><td>${79.4} \pm  {0.3}$</td><td>${78.7} \pm  {0.7}$</td><td>79.90</td></tr><tr><td>DTA [29]</td><td>${75.6} \pm  {0.5}$</td><td>${76.4} \pm  {0.3}$</td><td>${73.8} \pm  {0.2}$</td><td>${75.9} \pm  {0.3}$</td><td>${80.4} \pm  {0.1}$</td><td>${79.0} \pm  {0.2}$</td><td>${76.9} \pm  {0.6}$</td><td>${76.2} \pm  {0.8}$</td><td>76.78</td></tr><tr><td>CenterDA [30]</td><td>${80.7} \pm  {0.7}$</td><td>${82.4} \pm  {1.1}$</td><td>${83.3} \pm  {1.5}$</td><td>${79.6} \pm  {0.8}$</td><td>${81.9} \pm  {0.9}$</td><td>${83.5} \pm  {0.7}$</td><td>${78.1} \pm  {1.2}$</td><td>${82.2} \pm  {0.6}$</td><td>81.46</td></tr><tr><td>STAR [31]</td><td>${83.9} \pm  {0.2}$</td><td>${89.2} \pm  {0.6}$</td><td>${85.0} \pm  {0.4}$</td><td>${88.4} \pm  {0.9}$</td><td>${89.4} \pm  {0.5}$</td><td>${84.3} \pm  {0.1}$</td><td>${81.3} \pm  {0.0}$</td><td>${82.7} \pm  {0.4}$</td><td>85.53</td></tr><tr><td>DWL [32]</td><td>${86.9} \pm  {0.6}$</td><td>${87.1} \pm  {0.9}$</td><td>$\overline{84.7} \pm  {0.2}$</td><td>${90.6} \pm  {0.4}$</td><td>${90.5} \pm  {0.5}$</td><td>${87.2} \pm  {0.3}$</td><td>${88.3} \pm  {0.5}$</td><td>${87.4} \pm  {0.1}$</td><td>87.83</td></tr><tr><td>Proposed</td><td>${90.4} \pm  {0.9}$</td><td>${91.6} \pm  {0.4}$</td><td>${92.2} \pm  {0.1}$</td><td>$\overline{93.7} \pm  {0.8}$</td><td>${92.7} \pm  {0.4}$</td><td>$\overline{89.9} \pm  {0.5}$</td><td>$\overline{\mathbf{{90.2}}} \pm  {0.5}$</td><td>${91.3} \pm  {0.3}$</td><td>91.50</td></tr></table>

<table><tbody><tr><td>方法</td><td>CZ</td><td>ZC</td><td>13</td><td>I4</td><td>OB</td><td>RC</td><td>NS</td><td>SI</td><td>平均值</td></tr><tr><td>仅源域</td><td>${67.2} \pm  {0.1}$</td><td>${62.1} \pm  {0.0}$</td><td>${68.3} \pm  {0.8}$</td><td>${70.2} \pm  {0.4}$</td><td>${66.8} \pm  {0.6}$</td><td>${65.3} \pm  {0.5}$</td><td>${63.7} \pm  {0.7}$</td><td>${56.4} \pm  {0.8}$</td><td>65.00</td></tr><tr><td>DINN [9]</td><td>${66.4} \pm  {0.5}$</td><td>${64.1} \pm  {0.6}$</td><td>${62.3} \pm  {0.1}$</td><td>${65.4} \pm  {0.3}$</td><td>${67.9} \pm  {0.1}$</td><td>${63.6} \pm  {0.4}$</td><td>${58.2} \pm  {0.7}$</td><td>${59.3} \pm  {0.8}$</td><td>63.40</td></tr><tr><td>DTLID [7]</td><td>${68.4} \pm  {0.9}$</td><td>${61.1} \pm  {0.3}$</td><td>${63.3} \pm  {0.7}$</td><td>${66.6} \pm  {0.2}$</td><td>${64.2} \pm  {0.1}$</td><td>${65.7} \pm  {0.4}$</td><td>${61.2} \pm  {0.7}$</td><td>${60.5} \pm  {0.8}$</td><td>63.88</td></tr><tr><td>DMCF [8]</td><td>${64.3} \pm  {0.5}$</td><td>${65.1} \pm  {0.3}$</td><td>${63.8} \pm  {0.4}$</td><td>${68.4} \pm  {0.7}$</td><td>${71.4} \pm  {0.6}$</td><td>${63.5} \pm  {0.3}$</td><td>${59.0} \pm  {0.8}$</td><td>${62.6} \pm  {0.9}$</td><td>64.76</td></tr><tr><td>FRCNN [15]</td><td>${65.7} \pm  {0.7}$</td><td>${64.4} \pm  {0.4}$</td><td>${62.4} \pm  {0.9}$</td><td>${65.8} \pm  {1.3}$</td><td>${66.2} \pm  {1.4}$</td><td>${61.1} \pm  {0.8}$</td><td>${67.1} \pm  {0.6}$</td><td>${65.8} \pm  {0.9}$</td><td>64.81</td></tr><tr><td>DSDANet [26]</td><td>${72.3} \pm  {0.9}$</td><td>${69.4} \pm  {0.4}$</td><td>${73.6} \pm  {0.8}$</td><td>${75.1} \pm  {0.0}$</td><td>${77.2} \pm  {0.1}$</td><td>${74.4} \pm  {0.8}$</td><td>${69.3} \pm  {0.4}$</td><td>${67.8} \pm  {0.3}$</td><td>72.39</td></tr><tr><td>MRAN [27]</td><td>${74.0} \pm  {0.3}$</td><td>${70.1} \pm  {0.2}$</td><td>${74.6} \pm  {0.6}$</td><td>${78.1} \pm  {0.7}$</td><td>${79.2} \pm  {0.9}$</td><td>${76.4} \pm  {0.5}$</td><td>${74.1} \pm  {0.0}$</td><td>${71.7} \pm  {0.6}$</td><td>74.78</td></tr><tr><td>D-MMD [28]</td><td>${79.6} \pm  {0.2}$</td><td>${78.1} \pm  {0.7}$</td><td>${81.3} \pm  {0.1}$</td><td>${80.5} \pm  {0.0}$</td><td>${79.1} \pm  {0.4}$</td><td>${82.5} \pm  {0.5}$</td><td>${79.4} \pm  {0.3}$</td><td>${78.7} \pm  {0.7}$</td><td>79.90</td></tr><tr><td>DTA [29]</td><td>${75.6} \pm  {0.5}$</td><td>${76.4} \pm  {0.3}$</td><td>${73.8} \pm  {0.2}$</td><td>${75.9} \pm  {0.3}$</td><td>${80.4} \pm  {0.1}$</td><td>${79.0} \pm  {0.2}$</td><td>${76.9} \pm  {0.6}$</td><td>${76.2} \pm  {0.8}$</td><td>76.78</td></tr><tr><td>CenterDA [30]</td><td>${80.7} \pm  {0.7}$</td><td>${82.4} \pm  {1.1}$</td><td>${83.3} \pm  {1.5}$</td><td>${79.6} \pm  {0.8}$</td><td>${81.9} \pm  {0.9}$</td><td>${83.5} \pm  {0.7}$</td><td>${78.1} \pm  {1.2}$</td><td>${82.2} \pm  {0.6}$</td><td>81.46</td></tr><tr><td>STAR [31]</td><td>${83.9} \pm  {0.2}$</td><td>${89.2} \pm  {0.6}$</td><td>${85.0} \pm  {0.4}$</td><td>${88.4} \pm  {0.9}$</td><td>${89.4} \pm  {0.5}$</td><td>${84.3} \pm  {0.1}$</td><td>${81.3} \pm  {0.0}$</td><td>${82.7} \pm  {0.4}$</td><td>85.53</td></tr><tr><td>DWL [32]</td><td>${86.9} \pm  {0.6}$</td><td>${87.1} \pm  {0.9}$</td><td>$\overline{84.7} \pm  {0.2}$</td><td>${90.6} \pm  {0.4}$</td><td>${90.5} \pm  {0.5}$</td><td>${87.2} \pm  {0.3}$</td><td>${88.3} \pm  {0.5}$</td><td>${87.4} \pm  {0.1}$</td><td>87.83</td></tr><tr><td>提出的方法</td><td>${90.4} \pm  {0.9}$</td><td>${91.6} \pm  {0.4}$</td><td>${92.2} \pm  {0.1}$</td><td>$\overline{93.7} \pm  {0.8}$</td><td>${92.7} \pm  {0.4}$</td><td>$\overline{89.9} \pm  {0.5}$</td><td>$\overline{\mathbf{{90.2}}} \pm  {0.5}$</td><td>${91.3} \pm  {0.3}$</td><td>91.50</td></tr></tbody></table>

TABLE IV

CLASSIFICATION ACURACIES (MEAN $\pm$ STD %) FOR DIFFERENT METHODS OVER TEN INDEPEDENDENT RUNS FOR THE ${Sunny} \rightarrow  {Snowy}$ TASK IN THE ${HSD}$ DATASET. THE BEST RESULTS ARE INDICATED IN BOLD AND THE SECOND BEST RESULTS ARE UNDERLINED

在$\pm$任务的${HSD}$数据集中，不同方法在十次独立运行中的分类准确率(平均值 $\pm$ 标准差 %)。最佳结果以粗体显示，次佳结果加下划线。

<table><tr><td>Method</td><td>CZ</td><td>ZC</td><td>13</td><td>I4</td><td>OB</td><td>RC</td><td>NS</td><td>SI</td><td>Average</td></tr><tr><td>Source Only</td><td>${61.1} \pm  {0.9}$</td><td>${55.6} \pm  {0.5}$</td><td>${62.8} \pm  {0.1}$</td><td>${63.4} \pm  {0.3}$</td><td>${62.7} \pm  {0.4}$</td><td>${60.4} \pm  {0.1}$</td><td>${57.0} \pm  {0.4}$</td><td>${58.2} \pm  {0.2}$</td><td>60.15</td></tr><tr><td>DINN [9]</td><td>${62.1} \pm  {0.5}$</td><td>${52.6} \pm  {0.2}$</td><td>${58.2} \pm  {0.6}$</td><td>${62.0} \pm  {0.3}$</td><td>${64.5} \pm  {0.7}$</td><td>${61.9} \pm  {0.3}$</td><td>${58.4} \pm  {0.1}$</td><td>${56.3} \pm  {0.2}$</td><td>59.50</td></tr><tr><td>DTLID [7]</td><td>${64.9} \pm  {0.6}$</td><td>${54.4} \pm  {0.4}$</td><td>${56.6} \pm  {0.9}$</td><td>${63.8} \pm  {0.4}$</td><td>${63.5} \pm  {0.6}$</td><td>${62.3} \pm  {0.3}$</td><td>${57.6} \pm  {0.5}$</td><td>${56.1} \pm  {0.2}$</td><td>59.90</td></tr><tr><td>DMCF [8]</td><td>${63.2} \pm  {0.6}$</td><td>${55.4} \pm  {0.3}$</td><td>${58.3} \pm  {0.4}$</td><td>${60.6} \pm  {0.3}$</td><td>${61.6} \pm  {0.5}$</td><td>${61.4} \pm  {0.2}$</td><td>${56.0} \pm  {0.6}$</td><td>${55.1} \pm  {0.1}$</td><td>58.95</td></tr><tr><td>FRCNN [15]</td><td>${62.9} \pm  {0.8}$</td><td>${60.4} \pm  {0.7}$</td><td>${62.1} \pm  {0.9}$</td><td>${61.0} \pm  {0.4}$</td><td>${60.8} \pm  {1.2}$</td><td>${57.4} \pm  {1.1}$</td><td>${55.2} \pm  {0.7}$</td><td>${59.6} \pm  {0.8}$</td><td>59.93</td></tr><tr><td>DSDANet [26]</td><td>${66.8} \pm  {0.6}$</td><td>${60.6} \pm  {0.4}$</td><td>${63.2} \pm  {0.3}$</td><td>${64.5} \pm  {0.7}$</td><td>${65.0} \pm  {0.6}$</td><td>${64.4} \pm  {0.5}$</td><td>${61.6} \pm  {0.1}$</td><td>${59.2} \pm  {0.2}$</td><td>63.16</td></tr><tr><td>MRAN [27]</td><td>${69.2} \pm  {0.2}$</td><td>${61.8} \pm  {0.3}$</td><td>${63.5} \pm  {0.4}$</td><td>${62.6} \pm  {0.6}$</td><td>${63.4} \pm  {0.4}$</td><td>${65.3} \pm  {0.4}$</td><td>${60.6} \pm  {0.1}$</td><td>${61.2} \pm  {0.9}$</td><td>63.45</td></tr><tr><td>D-MMD [28]</td><td>${71.2} \pm  {0.5}$</td><td>${67.6} \pm  {0.6}$</td><td>${72.3} \pm  {0.7}$</td><td>${75.4} \pm  {0.8}$</td><td>${71.4} \pm  {0.9}$</td><td>${68.5} \pm  {0.4}$</td><td>${65.1} \pm  {0.2}$</td><td>${64.5} \pm  {0.1}$</td><td>69.50</td></tr><tr><td>DTA [29]</td><td>${70.0} \pm  {0.2}$</td><td>${64.2} \pm  {0.3}$</td><td>${68.9} \pm  {0.7}$</td><td>${69.4} \pm  {0.9}$</td><td>${70.2} \pm  {0.2}$</td><td>${68.3} \pm  {0.5}$</td><td>${63.4} \pm  {0.4}$</td><td>${64.5} \pm  {0.8}$</td><td>67.36</td></tr><tr><td>CenterDA [30]</td><td>${70.3} \pm  {0.9}$</td><td>${72.6} \pm  {0.4}$</td><td>${69.7} \pm  {0.6}$</td><td>${68.8} \pm  {0.7}$</td><td>${71.3} \pm  {1.4}$</td><td>${72.6} \pm  {1.1}$</td><td>${67.4} \pm  {0.6}$</td><td>${68.1} \pm  {1.7}$</td><td>70.10</td></tr><tr><td>STAR [31]</td><td>${76.4} \pm  {0.1}$</td><td>${71.3} \pm  {0.2}$</td><td>${74.6} \pm  {0.4}$</td><td>${76.8} \pm  {0.5}$</td><td>${73.5} \pm  {0.2}$</td><td>${69.8} \pm  {0.5}$</td><td>${68.4} \pm  {0.9}$</td><td>${69.2} \pm  {0.7}$</td><td>72.50</td></tr><tr><td>DWL [32]</td><td>${78.9} \pm  {0.6}$</td><td>${71.1} \pm  {0.4}$</td><td>${78.4} \pm  {0.6}$</td><td>${80.5} \pm  {0.2}$</td><td>${78.7} \pm  {0.4}$</td><td>${71.3} \pm  {0.8}$</td><td>${69.5} \pm  {0.4}$</td><td>${73.1} \pm  {0.5}$</td><td>75.18</td></tr><tr><td>Proposed</td><td>${83.5} \pm  {0.9}$</td><td>${75.1} \pm  {0.5}$</td><td>$\overline{80.8} \pm  {0.6}$</td><td>$\overline{\mathbf{{84.7}}} \pm  {0.4}$</td><td>${85.7} \pm  {0.2}$</td><td>${74.9} \pm  {0.4}$</td><td>$\overline{73.2} \pm  {0.9}$</td><td>${75.4} \pm  {0.7}$</td><td>79.16</td></tr></table>

<table><tbody><tr><td>方法</td><td>CZ</td><td>ZC</td><td>13</td><td>I4</td><td>OB</td><td>RC</td><td>NS</td><td>SI</td><td>平均值</td></tr><tr><td>仅源域</td><td>${61.1} \pm  {0.9}$</td><td>${55.6} \pm  {0.5}$</td><td>${62.8} \pm  {0.1}$</td><td>${63.4} \pm  {0.3}$</td><td>${62.7} \pm  {0.4}$</td><td>${60.4} \pm  {0.1}$</td><td>${57.0} \pm  {0.4}$</td><td>${58.2} \pm  {0.2}$</td><td>60.15</td></tr><tr><td>DINN [9]</td><td>${62.1} \pm  {0.5}$</td><td>${52.6} \pm  {0.2}$</td><td>${58.2} \pm  {0.6}$</td><td>${62.0} \pm  {0.3}$</td><td>${64.5} \pm  {0.7}$</td><td>${61.9} \pm  {0.3}$</td><td>${58.4} \pm  {0.1}$</td><td>${56.3} \pm  {0.2}$</td><td>59.50</td></tr><tr><td>DTLID [7]</td><td>${64.9} \pm  {0.6}$</td><td>${54.4} \pm  {0.4}$</td><td>${56.6} \pm  {0.9}$</td><td>${63.8} \pm  {0.4}$</td><td>${63.5} \pm  {0.6}$</td><td>${62.3} \pm  {0.3}$</td><td>${57.6} \pm  {0.5}$</td><td>${56.1} \pm  {0.2}$</td><td>59.90</td></tr><tr><td>DMCF [8]</td><td>${63.2} \pm  {0.6}$</td><td>${55.4} \pm  {0.3}$</td><td>${58.3} \pm  {0.4}$</td><td>${60.6} \pm  {0.3}$</td><td>${61.6} \pm  {0.5}$</td><td>${61.4} \pm  {0.2}$</td><td>${56.0} \pm  {0.6}$</td><td>${55.1} \pm  {0.1}$</td><td>58.95</td></tr><tr><td>FRCNN [15]</td><td>${62.9} \pm  {0.8}$</td><td>${60.4} \pm  {0.7}$</td><td>${62.1} \pm  {0.9}$</td><td>${61.0} \pm  {0.4}$</td><td>${60.8} \pm  {1.2}$</td><td>${57.4} \pm  {1.1}$</td><td>${55.2} \pm  {0.7}$</td><td>${59.6} \pm  {0.8}$</td><td>59.93</td></tr><tr><td>DSDANet [26]</td><td>${66.8} \pm  {0.6}$</td><td>${60.6} \pm  {0.4}$</td><td>${63.2} \pm  {0.3}$</td><td>${64.5} \pm  {0.7}$</td><td>${65.0} \pm  {0.6}$</td><td>${64.4} \pm  {0.5}$</td><td>${61.6} \pm  {0.1}$</td><td>${59.2} \pm  {0.2}$</td><td>63.16</td></tr><tr><td>MRAN [27]</td><td>${69.2} \pm  {0.2}$</td><td>${61.8} \pm  {0.3}$</td><td>${63.5} \pm  {0.4}$</td><td>${62.6} \pm  {0.6}$</td><td>${63.4} \pm  {0.4}$</td><td>${65.3} \pm  {0.4}$</td><td>${60.6} \pm  {0.1}$</td><td>${61.2} \pm  {0.9}$</td><td>63.45</td></tr><tr><td>D-MMD [28]</td><td>${71.2} \pm  {0.5}$</td><td>${67.6} \pm  {0.6}$</td><td>${72.3} \pm  {0.7}$</td><td>${75.4} \pm  {0.8}$</td><td>${71.4} \pm  {0.9}$</td><td>${68.5} \pm  {0.4}$</td><td>${65.1} \pm  {0.2}$</td><td>${64.5} \pm  {0.1}$</td><td>69.50</td></tr><tr><td>DTA [29]</td><td>${70.0} \pm  {0.2}$</td><td>${64.2} \pm  {0.3}$</td><td>${68.9} \pm  {0.7}$</td><td>${69.4} \pm  {0.9}$</td><td>${70.2} \pm  {0.2}$</td><td>${68.3} \pm  {0.5}$</td><td>${63.4} \pm  {0.4}$</td><td>${64.5} \pm  {0.8}$</td><td>67.36</td></tr><tr><td>CenterDA [30]</td><td>${70.3} \pm  {0.9}$</td><td>${72.6} \pm  {0.4}$</td><td>${69.7} \pm  {0.6}$</td><td>${68.8} \pm  {0.7}$</td><td>${71.3} \pm  {1.4}$</td><td>${72.6} \pm  {1.1}$</td><td>${67.4} \pm  {0.6}$</td><td>${68.1} \pm  {1.7}$</td><td>70.10</td></tr><tr><td>STAR [31]</td><td>${76.4} \pm  {0.1}$</td><td>${71.3} \pm  {0.2}$</td><td>${74.6} \pm  {0.4}$</td><td>${76.8} \pm  {0.5}$</td><td>${73.5} \pm  {0.2}$</td><td>${69.8} \pm  {0.5}$</td><td>${68.4} \pm  {0.9}$</td><td>${69.2} \pm  {0.7}$</td><td>72.50</td></tr><tr><td>DWL [32]</td><td>${78.9} \pm  {0.6}$</td><td>${71.1} \pm  {0.4}$</td><td>${78.4} \pm  {0.6}$</td><td>${80.5} \pm  {0.2}$</td><td>${78.7} \pm  {0.4}$</td><td>${71.3} \pm  {0.8}$</td><td>${69.5} \pm  {0.4}$</td><td>${73.1} \pm  {0.5}$</td><td>75.18</td></tr><tr><td>提出的方法</td><td>${83.5} \pm  {0.9}$</td><td>${75.1} \pm  {0.5}$</td><td>$\overline{80.8} \pm  {0.6}$</td><td>$\overline{\mathbf{{84.7}}} \pm  {0.4}$</td><td>${85.7} \pm  {0.2}$</td><td>${74.9} \pm  {0.4}$</td><td>$\overline{73.2} \pm  {0.9}$</td><td>${75.4} \pm  {0.7}$</td><td>79.16</td></tr></tbody></table>

TABLE V

CLASSIFICATION ACCURACIES (MEAN $\pm$ STD %) FOR DIFFERENT METHODS OVER TEN INDEPENDENT RUNS FOR THE ${Sunny} \rightarrow  {Cloudy}$ TASK IN THE BDD100 K DATASET. THE BEST RESULTS ARE INDICATED IN BOLD AND THE SECOND BEST RESULTS ARE UNDERLINED

BDD100K数据集中${Sunny} \rightarrow  {Cloudy}$任务的不同方法在十次独立运行中的分类准确率(平均值$\pm$标准差%)。最佳结果以粗体显示，次佳结果以下划线标出

<table><tr><td>Method</td><td>CS</td><td>PL</td><td>GA</td><td>TU</td><td>RA</td><td>HI</td><td>Average</td></tr><tr><td>Source Only</td><td>${70.8} \pm  {0.9}$</td><td>${68.1} \pm  {1.0}$</td><td>${70.6} \pm  {0.7}$</td><td>${69.4} \pm  {1.1}$</td><td>${72.9} \pm  {0.5}$</td><td>${71.2} \pm  {0.4}$</td><td>70.50</td></tr><tr><td>DINN [9]</td><td>${66.9} \pm  {1.0}$</td><td>${67.3} \pm  {0.8}$</td><td>${70.4} \pm  {0.8}$</td><td>${62.7} \pm  {0.9}$</td><td>${65.6} \pm  {1.2}$</td><td>${68.2} \pm  {1.3}$</td><td>66.85</td></tr><tr><td>DTLID [7]</td><td>${67.3} \pm  {0.8}$</td><td>${69.6} \pm  {0.5}$</td><td>${71.8} \pm  {0.6}$</td><td>${65.7} \pm  {1.1}$</td><td>${64.4} \pm  {1.3}$</td><td>${65.2} \pm  {0.8}$</td><td>67.33</td></tr><tr><td>DMCF [8]</td><td>${70.4} \pm  {0.9}$</td><td>${67.5} \pm  {1.3}$</td><td>${66.1} \pm  {0.7}$</td><td>${69.9} \pm  {0.9}$</td><td>${71.6} \pm  {0.7}$</td><td>${66.3} \pm  {1.4}$</td><td>68.63</td></tr><tr><td>FRCNN [15]</td><td>${71.1} \pm  {1.1}$</td><td>${68.9} \pm  {0.9}$</td><td>${69.5} \pm  {1.6}$</td><td>${69.6} \pm  {0.8}$</td><td>${68.4} \pm  {0.9}$</td><td>${67.2} \pm  {0.7}$</td><td>69.11</td></tr><tr><td>DSDANet [26]</td><td>${76.1} \pm  {0.7}$</td><td>${73.4} \pm  {0.6}$</td><td>${79.8} \pm  {0.8}$</td><td>${78.3} \pm  {0.9}$</td><td>${77.7} \pm  {0.4}$</td><td>${79.1} \pm  {1.5}$</td><td>77.40</td></tr><tr><td>MRAN [27]</td><td>${76.8} \pm  {0.4}$</td><td>${80.4} \pm  {0.8}$</td><td>${81.6} \pm  {0.9}$</td><td>${78.3} \pm  {1.2}$</td><td>${81.1} \pm  {0.7}$</td><td>${79.9} \pm  {0.6}$</td><td>79.68</td></tr><tr><td>D-MMD [28]</td><td>${81.9} \pm  {0.3}$</td><td>${86.0} \pm  {0.4}$</td><td>${80.5} \pm  {1.2}$</td><td>${84.6} \pm  {0.7}$</td><td>${85.2} \pm  {1.5}$</td><td>${83.6} \pm  {0.9}$</td><td>83.63</td></tr><tr><td>DTA [29]</td><td>${80.7} \pm  {0.9}$</td><td>${83.8} \pm  {1.0}$</td><td>${81.6} \pm  {1.3}$</td><td>${79.5} \pm  {0.6}$</td><td>${84.2} \pm  {0.8}$</td><td>${83.3} \pm  {1.4}$</td><td>82.18</td></tr><tr><td>CenterDA [30]</td><td>${85.4} \pm  {1.1}$</td><td>${83.2} \pm  {0.5}$</td><td>${88.6} \pm  {0.6}$</td><td>${81.6} \pm  {0.9}$</td><td>${82.7} \pm  {1.2}$</td><td>${82.9} \pm  {1.0}$</td><td>84.06</td></tr><tr><td>STAR [31]</td><td>${89.4} \pm  {0.8}$</td><td>${88.3} \pm  {0.9}$</td><td>${82.4} \pm  {1.4}$</td><td>${85.7} \pm  {0.9}$</td><td>${86.5} \pm  {0.7}$</td><td>${87.9} \pm  {1.3}$</td><td>86.70</td></tr><tr><td>DWL [32]</td><td>${87.5} \pm  {1.2}$</td><td>${90.0} \pm  {0.9}$</td><td>${88.2} \pm  {0.6}$</td><td>${83.3} \pm  {1.1}$</td><td>${88.4} \pm  {0.8}$</td><td>${89.0} \pm  {1.0}$</td><td>87.73</td></tr><tr><td>Proposed</td><td>${94.2} \pm  {0.7}$</td><td>${90.6} \pm  {0.9}$</td><td>${88.4} \pm  {0.4}$</td><td>${91.9} \pm  {0.8}$</td><td>${89.7} \pm  {0.5}$</td><td>${93.8} \pm  {0.6}$</td><td>91.43</td></tr></table>

<table><tbody><tr><td>方法</td><td>CS</td><td>PL</td><td>GA</td><td>TU</td><td>RA</td><td>HI</td><td>平均值</td></tr><tr><td>仅源域</td><td>${70.8} \pm  {0.9}$</td><td>${68.1} \pm  {1.0}$</td><td>${70.6} \pm  {0.7}$</td><td>${69.4} \pm  {1.1}$</td><td>${72.9} \pm  {0.5}$</td><td>${71.2} \pm  {0.4}$</td><td>70.50</td></tr><tr><td>DINN [9]</td><td>${66.9} \pm  {1.0}$</td><td>${67.3} \pm  {0.8}$</td><td>${70.4} \pm  {0.8}$</td><td>${62.7} \pm  {0.9}$</td><td>${65.6} \pm  {1.2}$</td><td>${68.2} \pm  {1.3}$</td><td>66.85</td></tr><tr><td>DTLID [7]</td><td>${67.3} \pm  {0.8}$</td><td>${69.6} \pm  {0.5}$</td><td>${71.8} \pm  {0.6}$</td><td>${65.7} \pm  {1.1}$</td><td>${64.4} \pm  {1.3}$</td><td>${65.2} \pm  {0.8}$</td><td>67.33</td></tr><tr><td>DMCF [8]</td><td>${70.4} \pm  {0.9}$</td><td>${67.5} \pm  {1.3}$</td><td>${66.1} \pm  {0.7}$</td><td>${69.9} \pm  {0.9}$</td><td>${71.6} \pm  {0.7}$</td><td>${66.3} \pm  {1.4}$</td><td>68.63</td></tr><tr><td>FRCNN [15]</td><td>${71.1} \pm  {1.1}$</td><td>${68.9} \pm  {0.9}$</td><td>${69.5} \pm  {1.6}$</td><td>${69.6} \pm  {0.8}$</td><td>${68.4} \pm  {0.9}$</td><td>${67.2} \pm  {0.7}$</td><td>69.11</td></tr><tr><td>DSDANet [26]</td><td>${76.1} \pm  {0.7}$</td><td>${73.4} \pm  {0.6}$</td><td>${79.8} \pm  {0.8}$</td><td>${78.3} \pm  {0.9}$</td><td>${77.7} \pm  {0.4}$</td><td>${79.1} \pm  {1.5}$</td><td>77.40</td></tr><tr><td>MRAN [27]</td><td>${76.8} \pm  {0.4}$</td><td>${80.4} \pm  {0.8}$</td><td>${81.6} \pm  {0.9}$</td><td>${78.3} \pm  {1.2}$</td><td>${81.1} \pm  {0.7}$</td><td>${79.9} \pm  {0.6}$</td><td>79.68</td></tr><tr><td>D-MMD [28]</td><td>${81.9} \pm  {0.3}$</td><td>${86.0} \pm  {0.4}$</td><td>${80.5} \pm  {1.2}$</td><td>${84.6} \pm  {0.7}$</td><td>${85.2} \pm  {1.5}$</td><td>${83.6} \pm  {0.9}$</td><td>83.63</td></tr><tr><td>DTA [29]</td><td>${80.7} \pm  {0.9}$</td><td>${83.8} \pm  {1.0}$</td><td>${81.6} \pm  {1.3}$</td><td>${79.5} \pm  {0.6}$</td><td>${84.2} \pm  {0.8}$</td><td>${83.3} \pm  {1.4}$</td><td>82.18</td></tr><tr><td>CenterDA [30]</td><td>${85.4} \pm  {1.1}$</td><td>${83.2} \pm  {0.5}$</td><td>${88.6} \pm  {0.6}$</td><td>${81.6} \pm  {0.9}$</td><td>${82.7} \pm  {1.2}$</td><td>${82.9} \pm  {1.0}$</td><td>84.06</td></tr><tr><td>STAR [31]</td><td>${89.4} \pm  {0.8}$</td><td>${88.3} \pm  {0.9}$</td><td>${82.4} \pm  {1.4}$</td><td>${85.7} \pm  {0.9}$</td><td>${86.5} \pm  {0.7}$</td><td>${87.9} \pm  {1.3}$</td><td>86.70</td></tr><tr><td>DWL [32]</td><td>${87.5} \pm  {1.2}$</td><td>${90.0} \pm  {0.9}$</td><td>${88.2} \pm  {0.6}$</td><td>${83.3} \pm  {1.1}$</td><td>${88.4} \pm  {0.8}$</td><td>${89.0} \pm  {1.0}$</td><td>87.73</td></tr><tr><td>提出的方法</td><td>${94.2} \pm  {0.7}$</td><td>${90.6} \pm  {0.9}$</td><td>${88.4} \pm  {0.4}$</td><td>${91.9} \pm  {0.8}$</td><td>${89.7} \pm  {0.5}$</td><td>${93.8} \pm  {0.6}$</td><td>91.43</td></tr></tbody></table>

TABLE VI

CLASSIFICATION ACCURACIES (MEAN $\pm$ STD %) FOR DIFFERENT METHODS OVER TEN INDEPENDENT RUNS FOR THE ${Sunny} \rightarrow  {Rainy}$ TASK IN THE BDD100 K DATASET. THE BEST RESULTS ARE INDICATED IN BOLD AND THE SECOND BEST RESULTS ARE UNDERLINED

BDD100K数据集中${Sunny} \rightarrow  {Rainy}$任务的不同方法在十次独立运行中的分类准确率(平均值$\pm$标准差%)。最佳结果以粗体显示，次佳结果以下划线标出

<table><tr><td>Method</td><td>CS</td><td>PL</td><td>GA</td><td>TU</td><td>RA</td><td>HI</td><td>Average</td></tr><tr><td>Source Only</td><td>${62.8} \pm  {1.0}$</td><td>${63.4} \pm  {0.6}$</td><td>${65.7} \pm  {0.9}$</td><td>${60.1} \pm  {0.7}$</td><td>${61.8} \pm  {0.8}$</td><td>${62.6} \pm  {1.1}$</td><td>62.73</td></tr><tr><td>DINN [9]</td><td>${56.2} \pm  {1.2}$</td><td>${58.4} \pm  {1.3}$</td><td>${57.3} \pm  {0.9}$</td><td>${61.2} \pm  {0.5}$</td><td>${55.3} \pm  {0.6}$</td><td>${56.9} \pm  {1.0}$</td><td>57.55</td></tr><tr><td>DTLID [7]</td><td>${60.6} \pm  {0.9}$</td><td>${57.7} \pm  {0.7}$</td><td>${55.3} \pm  {1.1}$</td><td>${56.4} \pm  {0.8}$</td><td>${61.6} \pm  {0.7}$</td><td>${60.3} \pm  {1.3}$</td><td>58.65</td></tr><tr><td>DMCF [8]</td><td>${59.9} \pm  {0.8}$</td><td>${62.1} \pm  {1.1}$</td><td>${56.7} \pm  {1.2}$</td><td>${57.9} \pm  {0.9}$</td><td>${60.3} \pm  {0.6}$</td><td>${62.1} \pm  {0.9}$</td><td>59.83</td></tr><tr><td>FRCNN [15]</td><td>${61.1} \pm  {0.6}$</td><td>${61.4} \pm  {0.7}$</td><td>${60.8} \pm  {1.5}$</td><td>${59.6} \pm  {0.7}$</td><td>${61.5} \pm  {1.0}$</td><td>${62.0} \pm  {1.3}$</td><td>61.07</td></tr><tr><td>DSDANet [26]</td><td>${67.9} \pm  {0.7}$</td><td>${69.4} \pm  {0.8}$</td><td>${70.1} \pm  {1.2}$</td><td>${68.8} \pm  {1.0}$</td><td>${69.0} \pm  {0.6}$</td><td>${67.1} \pm  {0.9}$</td><td>68.72</td></tr><tr><td>MRAN [27]</td><td>${68.4} \pm  {0.8}$</td><td>${72.6} \pm  {0.7}$</td><td>${71.8} \pm  {1.0}$</td><td>${70.3} \pm  {1.2}$</td><td>${72.2} \pm  {0.8}$</td><td>${69.1} \pm  {0.8}$</td><td>70.73</td></tr><tr><td>D-MMD [28]</td><td>${72.6} \pm  {1.0}$</td><td>${74.8} \pm  {0.8}$</td><td>${75.6} \pm  {1.2}$</td><td>${73.8} \pm  {1.1}$</td><td>${71.9} \pm  {0.7}$</td><td>${73.9} \pm  {0.9}$</td><td>73.77</td></tr><tr><td>DTA [29]</td><td>${68.3} \pm  {0.9}$</td><td>${73.3} \pm  {1.1}$</td><td>${72.9} \pm  {0.6}$</td><td>${69.9} \pm  {1.2}$</td><td>${72.6} \pm  {0.7}$</td><td>${73.5} \pm  {0.5}$</td><td>71.75</td></tr><tr><td>CenterDA [30]</td><td>${76.4} \pm  {0.8}$</td><td>${79.1} \pm  {1.4}$</td><td>${77.4} \pm  {1.2}$</td><td>${73.4} \pm  {0.7}$</td><td>${78.3} \pm  {1.0}$</td><td>${78.0} \pm  {0.9}$</td><td>77.10</td></tr><tr><td>STAR [31]</td><td>${81.6} \pm  {0.9}$</td><td>${80.5} \pm  {0.7}$</td><td>${82.6} \pm  {1.2}$</td><td>${78.4} \pm  {1.3}$</td><td>${83.9} \pm  {0.9}$</td><td>${85.2} \pm  {0.8}$</td><td>82.03</td></tr><tr><td>DWL [32]</td><td>${83.6} \pm  {0.8}$</td><td>${85.4} \pm  {1.2}$</td><td>${81.9} \pm  {0.9}$</td><td>${87.4} \pm  {0.8}$</td><td>${85.6} \pm  {1.0}$</td><td>${85.1} \pm  {1.1}$</td><td>84.83</td></tr><tr><td>Proposed</td><td>${90.6} \pm  {0.9}$</td><td>$\mathbf{{87.4} \pm  {0.6}}$</td><td>${86.4} \pm  {0.7}$</td><td>${91.3} \pm  {0.8}$</td><td>${89.7} \pm  {0.9}$</td><td>${88.7} \pm  {0.5}$</td><td>89.02</td></tr></table>

<table><tbody><tr><td>方法</td><td>CS</td><td>PL</td><td>GA</td><td>TU</td><td>RA</td><td>HI</td><td>平均值</td></tr><tr><td>仅源域</td><td>${62.8} \pm  {1.0}$</td><td>${63.4} \pm  {0.6}$</td><td>${65.7} \pm  {0.9}$</td><td>${60.1} \pm  {0.7}$</td><td>${61.8} \pm  {0.8}$</td><td>${62.6} \pm  {1.1}$</td><td>62.73</td></tr><tr><td>DINN [9]</td><td>${56.2} \pm  {1.2}$</td><td>${58.4} \pm  {1.3}$</td><td>${57.3} \pm  {0.9}$</td><td>${61.2} \pm  {0.5}$</td><td>${55.3} \pm  {0.6}$</td><td>${56.9} \pm  {1.0}$</td><td>57.55</td></tr><tr><td>DTLID [7]</td><td>${60.6} \pm  {0.9}$</td><td>${57.7} \pm  {0.7}$</td><td>${55.3} \pm  {1.1}$</td><td>${56.4} \pm  {0.8}$</td><td>${61.6} \pm  {0.7}$</td><td>${60.3} \pm  {1.3}$</td><td>58.65</td></tr><tr><td>DMCF [8]</td><td>${59.9} \pm  {0.8}$</td><td>${62.1} \pm  {1.1}$</td><td>${56.7} \pm  {1.2}$</td><td>${57.9} \pm  {0.9}$</td><td>${60.3} \pm  {0.6}$</td><td>${62.1} \pm  {0.9}$</td><td>59.83</td></tr><tr><td>FRCNN [15]</td><td>${61.1} \pm  {0.6}$</td><td>${61.4} \pm  {0.7}$</td><td>${60.8} \pm  {1.5}$</td><td>${59.6} \pm  {0.7}$</td><td>${61.5} \pm  {1.0}$</td><td>${62.0} \pm  {1.3}$</td><td>61.07</td></tr><tr><td>DSDANet [26]</td><td>${67.9} \pm  {0.7}$</td><td>${69.4} \pm  {0.8}$</td><td>${70.1} \pm  {1.2}$</td><td>${68.8} \pm  {1.0}$</td><td>${69.0} \pm  {0.6}$</td><td>${67.1} \pm  {0.9}$</td><td>68.72</td></tr><tr><td>MRAN [27]</td><td>${68.4} \pm  {0.8}$</td><td>${72.6} \pm  {0.7}$</td><td>${71.8} \pm  {1.0}$</td><td>${70.3} \pm  {1.2}$</td><td>${72.2} \pm  {0.8}$</td><td>${69.1} \pm  {0.8}$</td><td>70.73</td></tr><tr><td>D-MMD [28]</td><td>${72.6} \pm  {1.0}$</td><td>${74.8} \pm  {0.8}$</td><td>${75.6} \pm  {1.2}$</td><td>${73.8} \pm  {1.1}$</td><td>${71.9} \pm  {0.7}$</td><td>${73.9} \pm  {0.9}$</td><td>73.77</td></tr><tr><td>DTA [29]</td><td>${68.3} \pm  {0.9}$</td><td>${73.3} \pm  {1.1}$</td><td>${72.9} \pm  {0.6}$</td><td>${69.9} \pm  {1.2}$</td><td>${72.6} \pm  {0.7}$</td><td>${73.5} \pm  {0.5}$</td><td>71.75</td></tr><tr><td>CenterDA [30]</td><td>${76.4} \pm  {0.8}$</td><td>${79.1} \pm  {1.4}$</td><td>${77.4} \pm  {1.2}$</td><td>${73.4} \pm  {0.7}$</td><td>${78.3} \pm  {1.0}$</td><td>${78.0} \pm  {0.9}$</td><td>77.10</td></tr><tr><td>STAR [31]</td><td>${81.6} \pm  {0.9}$</td><td>${80.5} \pm  {0.7}$</td><td>${82.6} \pm  {1.2}$</td><td>${78.4} \pm  {1.3}$</td><td>${83.9} \pm  {0.9}$</td><td>${85.2} \pm  {0.8}$</td><td>82.03</td></tr><tr><td>DWL [32]</td><td>${83.6} \pm  {0.8}$</td><td>${85.4} \pm  {1.2}$</td><td>${81.9} \pm  {0.9}$</td><td>${87.4} \pm  {0.8}$</td><td>${85.6} \pm  {1.0}$</td><td>${85.1} \pm  {1.1}$</td><td>84.83</td></tr><tr><td>提出的方法</td><td>${90.6} \pm  {0.9}$</td><td>$\mathbf{{87.4} \pm  {0.6}}$</td><td>${86.4} \pm  {0.7}$</td><td>${91.3} \pm  {0.8}$</td><td>${89.7} \pm  {0.9}$</td><td>${88.7} \pm  {0.5}$</td><td>89.02</td></tr></tbody></table>

TABLE VII

CLASSIFICATION ACCURACIES (MEAN $\pm$ STD %) FOR DIFFERNT METHODS OVER TEN INDEPENDENT RUNS FOR THE ${Sunny} \rightarrow  {Snowy}$ TASK IN TH BDD100 K DATASET. THE BEST RESULTS ARE INDICATED IN BOLD AND THE SECOND BEST RESULTS ARE UNDERLINED

BDD100K数据集中${Sunny} \rightarrow  {Snowy}$任务的不同方法在十次独立运行中的分类准确率(平均值$\pm$标准差%)。最佳结果以粗体显示，次佳结果加下划线。

<table><tr><td>Method</td><td>CS</td><td>PL</td><td>GA</td><td>TU</td><td>RA</td><td>HI</td><td>Average</td></tr><tr><td>Source Only</td><td>${58.9} \pm  {0.8}$</td><td>${61.3} \pm  {0.7}$</td><td>${57.9} \pm  {0.9}$</td><td>${60.5} \pm  {0.4}$</td><td>${56.6} \pm  {1.1}$</td><td>${59.4} \pm  {0.6}$</td><td>59.10</td></tr><tr><td>DINN [9]</td><td>${53.7} \pm  {0.8}$</td><td>${59.3} \pm  {0.9}$</td><td>${56.9} \pm  {1.2}$</td><td>${55.8} \pm  {1.1}$</td><td>${55.5} \pm  {0.6}$</td><td>${58.0} \pm  {0.7}$</td><td>56.53</td></tr><tr><td>DTLID [7]</td><td>${56.9} \pm  {1.3}$</td><td>${59.1} \pm  {0.4}$</td><td>${58.7} \pm  {0.9}$</td><td>${58.0} \pm  {1.0}$</td><td>${55.3} \pm  {0.7}$</td><td>${57.9} \pm  {0.5}$</td><td>57.65</td></tr><tr><td>DMCF [8]</td><td>${55.4} \pm  {0.8}$</td><td>${60.7} \pm  {0.9}$</td><td>${57.1} \pm  {1.2}$</td><td>${58.7} \pm  {0.6}$</td><td>${56.4} \pm  {0.7}$</td><td>${59.3} \pm  {1.3}$</td><td>57.93</td></tr><tr><td>FRCNN [15]</td><td>${56.6} \pm  {0.6}$</td><td>${61.1} \pm  {0.7}$</td><td>${57.0} \pm  {1.4}$</td><td>${59.6} \pm  {0.6}$</td><td>${57.2} \pm  {0.5}$</td><td>${58.1} \pm  {0.8}$</td><td>58.27</td></tr><tr><td>DSDANet [26]</td><td>${65.5} \pm  {0.9}$</td><td>${67.8} \pm  {0.7}$</td><td>${61.1} \pm  {0.8}$</td><td>${64.0} \pm  {0.6}$</td><td>${63.9} \pm  {0.8}$</td><td>${65.4} \pm  {1.1}$</td><td>64.62</td></tr><tr><td>MRAN [27]</td><td>${66.3} \pm  {0.8}$</td><td>${69.5} \pm  {0.4}$</td><td>${68.0} \pm  {0.9}$</td><td>${69.5} \pm  {0.8}$</td><td>${64.1} \pm  {1.2}$</td><td>${66.7} \pm  {0.7}$</td><td>67.35</td></tr><tr><td>D-MMD [28]</td><td>${70.7} \pm  {0.9}$</td><td>${69.9} \pm  {0.7}$</td><td>${71.3} \pm  {0.6}$</td><td>${72.4} \pm  {0.5}$</td><td>${69.1} \pm  {1.7}$</td><td>${68.8} \pm  {0.9}$</td><td>70.37</td></tr><tr><td>DTA [29]</td><td>${68.7} \pm  {1.1}$</td><td>${68.4} \pm  {0.6}$</td><td>${66.8} \pm  {0.7}$</td><td>${70.3} \pm  {0.9}$</td><td>${68.7} \pm  {1.2}$</td><td>${69.1} \pm  {1.3}$</td><td>68.67</td></tr><tr><td>CenterDA [30]</td><td>${70.0} \pm  {1.4}$</td><td>${72.5} \pm  {0.8}$</td><td>${71.9} \pm  {0.9}$</td><td>${71.8} \pm  {0.7}$</td><td>${69.4} \pm  {0.7}$</td><td>${69.2} \pm  {0.6}$</td><td>70.80</td></tr><tr><td>STAR [31]</td><td>${71.4} \pm  {1.0}$</td><td>${74.8} \pm  {0.6}$</td><td>${72.1} \pm  {0.5}$</td><td>${72.4} \pm  {0.6}$</td><td>${71.1} \pm  {0.7}$</td><td>${72.6} \pm  {0.9}$</td><td>72.40</td></tr><tr><td>DWL [32]</td><td>${73.9} \pm  {1.2}$</td><td>${71.2} \pm  {1.4}$</td><td>${73.6} \pm  {0.9}$</td><td>${72.8} \pm  {0.7}$</td><td>${70.5} \pm  {0.8}$</td><td>${73.7} \pm  {0.6}$</td><td>72.62</td></tr><tr><td>Proposed</td><td>${77.9} \pm  {0.4}$</td><td>${76.4} \pm  {0.5}$</td><td>${78.8} \pm  {0.8}$</td><td>${75.2} \pm  {0.6}$</td><td>${74.0} \pm  {0.7}$</td><td>$\mathbf{{74.1} \pm  {0.6}}$</td><td>76.07</td></tr></table>

<table><tbody><tr><td>方法</td><td>CS</td><td>PL</td><td>GA</td><td>TU</td><td>RA</td><td>HI</td><td>平均值</td></tr><tr><td>仅源域</td><td>${58.9} \pm  {0.8}$</td><td>${61.3} \pm  {0.7}$</td><td>${57.9} \pm  {0.9}$</td><td>${60.5} \pm  {0.4}$</td><td>${56.6} \pm  {1.1}$</td><td>${59.4} \pm  {0.6}$</td><td>59.10</td></tr><tr><td>DINN [9]</td><td>${53.7} \pm  {0.8}$</td><td>${59.3} \pm  {0.9}$</td><td>${56.9} \pm  {1.2}$</td><td>${55.8} \pm  {1.1}$</td><td>${55.5} \pm  {0.6}$</td><td>${58.0} \pm  {0.7}$</td><td>56.53</td></tr><tr><td>DTLID [7]</td><td>${56.9} \pm  {1.3}$</td><td>${59.1} \pm  {0.4}$</td><td>${58.7} \pm  {0.9}$</td><td>${58.0} \pm  {1.0}$</td><td>${55.3} \pm  {0.7}$</td><td>${57.9} \pm  {0.5}$</td><td>57.65</td></tr><tr><td>DMCF [8]</td><td>${55.4} \pm  {0.8}$</td><td>${60.7} \pm  {0.9}$</td><td>${57.1} \pm  {1.2}$</td><td>${58.7} \pm  {0.6}$</td><td>${56.4} \pm  {0.7}$</td><td>${59.3} \pm  {1.3}$</td><td>57.93</td></tr><tr><td>FRCNN [15]</td><td>${56.6} \pm  {0.6}$</td><td>${61.1} \pm  {0.7}$</td><td>${57.0} \pm  {1.4}$</td><td>${59.6} \pm  {0.6}$</td><td>${57.2} \pm  {0.5}$</td><td>${58.1} \pm  {0.8}$</td><td>58.27</td></tr><tr><td>DSDANet [26]</td><td>${65.5} \pm  {0.9}$</td><td>${67.8} \pm  {0.7}$</td><td>${61.1} \pm  {0.8}$</td><td>${64.0} \pm  {0.6}$</td><td>${63.9} \pm  {0.8}$</td><td>${65.4} \pm  {1.1}$</td><td>64.62</td></tr><tr><td>MRAN [27]</td><td>${66.3} \pm  {0.8}$</td><td>${69.5} \pm  {0.4}$</td><td>${68.0} \pm  {0.9}$</td><td>${69.5} \pm  {0.8}$</td><td>${64.1} \pm  {1.2}$</td><td>${66.7} \pm  {0.7}$</td><td>67.35</td></tr><tr><td>D-MMD [28]</td><td>${70.7} \pm  {0.9}$</td><td>${69.9} \pm  {0.7}$</td><td>${71.3} \pm  {0.6}$</td><td>${72.4} \pm  {0.5}$</td><td>${69.1} \pm  {1.7}$</td><td>${68.8} \pm  {0.9}$</td><td>70.37</td></tr><tr><td>DTA [29]</td><td>${68.7} \pm  {1.1}$</td><td>${68.4} \pm  {0.6}$</td><td>${66.8} \pm  {0.7}$</td><td>${70.3} \pm  {0.9}$</td><td>${68.7} \pm  {1.2}$</td><td>${69.1} \pm  {1.3}$</td><td>68.67</td></tr><tr><td>CenterDA [30]</td><td>${70.0} \pm  {1.4}$</td><td>${72.5} \pm  {0.8}$</td><td>${71.9} \pm  {0.9}$</td><td>${71.8} \pm  {0.7}$</td><td>${69.4} \pm  {0.7}$</td><td>${69.2} \pm  {0.6}$</td><td>70.80</td></tr><tr><td>STAR [31]</td><td>${71.4} \pm  {1.0}$</td><td>${74.8} \pm  {0.6}$</td><td>${72.1} \pm  {0.5}$</td><td>${72.4} \pm  {0.6}$</td><td>${71.1} \pm  {0.7}$</td><td>${72.6} \pm  {0.9}$</td><td>72.40</td></tr><tr><td>DWL [32]</td><td>${73.9} \pm  {1.2}$</td><td>${71.2} \pm  {1.4}$</td><td>${73.6} \pm  {0.9}$</td><td>${72.8} \pm  {0.7}$</td><td>${70.5} \pm  {0.8}$</td><td>${73.7} \pm  {0.6}$</td><td>72.62</td></tr><tr><td>提出的方法</td><td>${77.9} \pm  {0.4}$</td><td>${76.4} \pm  {0.5}$</td><td>${78.8} \pm  {0.8}$</td><td>${75.2} \pm  {0.6}$</td><td>${74.0} \pm  {0.7}$</td><td>$\mathbf{{74.1} \pm  {0.6}}$</td><td>76.07</td></tr></tbody></table>

TABLE VIII

表 VIII

CLASSIFICATION ACCURACIES (MEAN $\pm$ STD %) FOR DIFFERENT METHODS OVER TEN INDEPENDENT RUNS FOR THE ${Sunny} \rightarrow  {Cloudy}$ TASK IN THE FM3 DATASET. THE BEST RESULTS ARE INDICATED IN BOLD AND THE SECOND BEST RESULTS ARE UNDERLINED

在 FM3 数据集的 ${Sunny} \rightarrow  {Cloudy}$ 任务中，不同方法在十次独立运行中的分类准确率(平均值 $\pm$ 标准差 %)。最佳结果以粗体显示，次佳结果加下划线。

<table><tr><td>Method</td><td>HI</td><td>RO</td><td>TU</td><td>EX</td><td>SE</td><td>OB</td><td>BO</td><td>TR</td><td>Average</td></tr><tr><td>Source Only</td><td>${65.3} \pm  {0.5}$</td><td>${67.7} \pm  {0.7}$</td><td>${69.3} \pm  {0.9}$</td><td>${63.1} \pm  {1.2}$</td><td>${70.2} \pm  {0.8}$</td><td>${69.5} \pm  {1.3}$</td><td>${68.3} \pm  {0.8}$</td><td>${71.4} \pm  {0.6}$</td><td>68.10</td></tr><tr><td>DINN [9]</td><td>${61.1} \pm  {1.1}$</td><td>${66.4} \pm  {1.3}$</td><td>${67.2} \pm  {0.6}$</td><td>${63.0} \pm  {0.4}$</td><td>${66.8} \pm  {1.3}$</td><td>${65.3} \pm  {0.8}$</td><td>${66.2} \pm  {0.9}$</td><td>${65.9} \pm  {0.7}$</td><td>65.24</td></tr><tr><td>DTLID [7]</td><td>${62.5} \pm  {0.7}$</td><td>${67.6} \pm  {0.6}$</td><td>${66.6} \pm  {0.8}$</td><td>${61.9} \pm  {1.3}$</td><td>${68.9} \pm  {1.2}$</td><td>${66.4} \pm  {0.7}$</td><td>${67.3} \pm  {0.6}$</td><td>${68.8} \pm  {1.0}$</td><td>66.25</td></tr><tr><td>DMCF [8]</td><td>${64.5} \pm  {0.6}$</td><td>${67.0} \pm  {0.5}$</td><td>${68.8} \pm  {1.4}$</td><td>${62.5} \pm  {0.9}$</td><td>${68.7} \pm  {1.3}$</td><td>${68.2} \pm  {0.8}$</td><td>${66.4} \pm  {1.2}$</td><td>${68.3} \pm  {0.7}$</td><td>66.80</td></tr><tr><td>FRCNN [15]</td><td>${65.0} \pm  {0.9}$</td><td>${66.9} \pm  {0.6}$</td><td>${68.2} \pm  {0.7}$</td><td>${62.1} \pm  {1.2}$</td><td>${68.5} \pm  {0.8}$</td><td>${68.8} \pm  {1.1}$</td><td>${68.0} \pm  {1.0}$</td><td>${69.9} \pm  {0.5}$</td><td>67.18</td></tr><tr><td>DSDANet [26]</td><td>${72.3} \pm  {0.4}$</td><td>${73.8} \pm  {0.7}$</td><td>${78.2} \pm  {0.5}$</td><td>${76.6} \pm  {1.0}$</td><td>${72.3} \pm  {0.9}$</td><td>${74.1} \pm  {1.2}$</td><td>${76.9} \pm  {1.3}$</td><td>${74.3} \pm  {0.7}$</td><td>74.81</td></tr><tr><td>MRAN [27]</td><td>${71.7} \pm  {0.7}$</td><td>${75.6} \pm  {0.8}$</td><td>${79.9} \pm  {0.6}$</td><td>${75.4} \pm  {1.2}$</td><td>${74.7} \pm  {1.1}$</td><td>${77.7} \pm  {1.4}$</td><td>${75.1} \pm  {0.7}$</td><td>${75.2} \pm  {0.8}$</td><td>75.66</td></tr><tr><td>D-MMD [28]</td><td>${77.4} \pm  {1.3}$</td><td>${80.3} \pm  {0.9}$</td><td>${78.3} \pm  {1.0}$</td><td>${75.6} \pm  {0.8}$</td><td>${78.2} \pm  {0.7}$</td><td>${80.8} \pm  {0.6}$</td><td>${81.1} \pm  {1.2}$</td><td>${83.4} \pm  {0.6}$</td><td>79.39</td></tr><tr><td>DTA [29]</td><td>${78.2} \pm  {0.7}$</td><td>${77.4} \pm  {1.1}$</td><td>${80.1} \pm  {0.9}$</td><td>${73.2} \pm  {1.2}$</td><td>${75.7} \pm  {0.8}$</td><td>${78.9} \pm  {1.0}$</td><td>${79.4} \pm  {1.3}$</td><td>${81.3} \pm  {0.7}$</td><td>78.02</td></tr><tr><td>CenterDA [30]</td><td>${80.7} \pm  {0.5}$</td><td>${79.8} \pm  {0.5}$</td><td>${80.6} \pm  {0.9}$</td><td>${78.9} \pm  {1.2}$</td><td>${82.3} \pm  {1.4}$</td><td>${81.6} \pm  {0.7}$</td><td>${83.3} \pm  {0.8}$</td><td>${84.7} \pm  {0.9}$</td><td>81.49</td></tr><tr><td>STAR [31]</td><td>${85.9} \pm  {0.7}$</td><td>${81.3} \pm  {0.8}$</td><td>${81.4} \pm  {0.5}$</td><td>${82.7} \pm  {0.6}$</td><td>${83.4} \pm  {0.9}$</td><td>${87.4} \pm  {0.7}$</td><td>${86.1} \pm  {0.6}$</td><td>${85.9} \pm  {1.2}$</td><td>84.26</td></tr><tr><td>DWL [32]</td><td>${84.2} \pm  {0.5}$</td><td>${85.1} \pm  {1.3}$</td><td>${83.7} \pm  {1.4}$</td><td>${85.1} \pm  {0.9}$</td><td>${86.2} \pm  {0.8}$</td><td>${85.5} \pm  {0.7}$</td><td>${88.3} \pm  {0.6}$</td><td>${87.1} \pm  {1.1}$</td><td>85.65</td></tr><tr><td>Proposed</td><td>${88.7} \pm  {0.6}$</td><td>$\mathbf{{87.4} \pm  {0.8}}$</td><td>${88.8} \pm  {0.3}$</td><td>${88.2} \pm  {0.5}$</td><td>${90.1} \pm  {0.4}$</td><td>${89.7} \pm  {0.7}$</td><td>${92.7} \pm  {0.6}$</td><td>${91.3} \pm  {0.9}$</td><td>89.61</td></tr></table>

<table><tbody><tr><td>方法</td><td>HI</td><td>RO</td><td>TU</td><td>EX</td><td>SE</td><td>OB</td><td>BO</td><td>TR</td><td>平均</td></tr><tr><td>仅源</td><td>${65.3} \pm  {0.5}$</td><td>${67.7} \pm  {0.7}$</td><td>${69.3} \pm  {0.9}$</td><td>${63.1} \pm  {1.2}$</td><td>${70.2} \pm  {0.8}$</td><td>${69.5} \pm  {1.3}$</td><td>${68.3} \pm  {0.8}$</td><td>${71.4} \pm  {0.6}$</td><td>68.10</td></tr><tr><td>DINN [9]</td><td>${61.1} \pm  {1.1}$</td><td>${66.4} \pm  {1.3}$</td><td>${67.2} \pm  {0.6}$</td><td>${63.0} \pm  {0.4}$</td><td>${66.8} \pm  {1.3}$</td><td>${65.3} \pm  {0.8}$</td><td>${66.2} \pm  {0.9}$</td><td>${65.9} \pm  {0.7}$</td><td>65.24</td></tr><tr><td>DTLID [7]</td><td>${62.5} \pm  {0.7}$</td><td>${67.6} \pm  {0.6}$</td><td>${66.6} \pm  {0.8}$</td><td>${61.9} \pm  {1.3}$</td><td>${68.9} \pm  {1.2}$</td><td>${66.4} \pm  {0.7}$</td><td>${67.3} \pm  {0.6}$</td><td>${68.8} \pm  {1.0}$</td><td>66.25</td></tr><tr><td>DMCF [8]</td><td>${64.5} \pm  {0.6}$</td><td>${67.0} \pm  {0.5}$</td><td>${68.8} \pm  {1.4}$</td><td>${62.5} \pm  {0.9}$</td><td>${68.7} \pm  {1.3}$</td><td>${68.2} \pm  {0.8}$</td><td>${66.4} \pm  {1.2}$</td><td>${68.3} \pm  {0.7}$</td><td>66.80</td></tr><tr><td>FRCNN [15]</td><td>${65.0} \pm  {0.9}$</td><td>${66.9} \pm  {0.6}$</td><td>${68.2} \pm  {0.7}$</td><td>${62.1} \pm  {1.2}$</td><td>${68.5} \pm  {0.8}$</td><td>${68.8} \pm  {1.1}$</td><td>${68.0} \pm  {1.0}$</td><td>${69.9} \pm  {0.5}$</td><td>67.18</td></tr><tr><td>DSDANet [26]</td><td>${72.3} \pm  {0.4}$</td><td>${73.8} \pm  {0.7}$</td><td>${78.2} \pm  {0.5}$</td><td>${76.6} \pm  {1.0}$</td><td>${72.3} \pm  {0.9}$</td><td>${74.1} \pm  {1.2}$</td><td>${76.9} \pm  {1.3}$</td><td>${74.3} \pm  {0.7}$</td><td>74.81</td></tr><tr><td>MRAN [27]</td><td>${71.7} \pm  {0.7}$</td><td>${75.6} \pm  {0.8}$</td><td>${79.9} \pm  {0.6}$</td><td>${75.4} \pm  {1.2}$</td><td>${74.7} \pm  {1.1}$</td><td>${77.7} \pm  {1.4}$</td><td>${75.1} \pm  {0.7}$</td><td>${75.2} \pm  {0.8}$</td><td>75.66</td></tr><tr><td>D-MMD [28]</td><td>${77.4} \pm  {1.3}$</td><td>${80.3} \pm  {0.9}$</td><td>${78.3} \pm  {1.0}$</td><td>${75.6} \pm  {0.8}$</td><td>${78.2} \pm  {0.7}$</td><td>${80.8} \pm  {0.6}$</td><td>${81.1} \pm  {1.2}$</td><td>${83.4} \pm  {0.6}$</td><td>79.39</td></tr><tr><td>DTA [29]</td><td>${78.2} \pm  {0.7}$</td><td>${77.4} \pm  {1.1}$</td><td>${80.1} \pm  {0.9}$</td><td>${73.2} \pm  {1.2}$</td><td>${75.7} \pm  {0.8}$</td><td>${78.9} \pm  {1.0}$</td><td>${79.4} \pm  {1.3}$</td><td>${81.3} \pm  {0.7}$</td><td>78.02</td></tr><tr><td>CenterDA [30]</td><td>${80.7} \pm  {0.5}$</td><td>${79.8} \pm  {0.5}$</td><td>${80.6} \pm  {0.9}$</td><td>${78.9} \pm  {1.2}$</td><td>${82.3} \pm  {1.4}$</td><td>${81.6} \pm  {0.7}$</td><td>${83.3} \pm  {0.8}$</td><td>${84.7} \pm  {0.9}$</td><td>81.49</td></tr><tr><td>STAR [31]</td><td>${85.9} \pm  {0.7}$</td><td>${81.3} \pm  {0.8}$</td><td>${81.4} \pm  {0.5}$</td><td>${82.7} \pm  {0.6}$</td><td>${83.4} \pm  {0.9}$</td><td>${87.4} \pm  {0.7}$</td><td>${86.1} \pm  {0.6}$</td><td>${85.9} \pm  {1.2}$</td><td>84.26</td></tr><tr><td>DWL [32]</td><td>${84.2} \pm  {0.5}$</td><td>${85.1} \pm  {1.3}$</td><td>${83.7} \pm  {1.4}$</td><td>${85.1} \pm  {0.9}$</td><td>${86.2} \pm  {0.8}$</td><td>${85.5} \pm  {0.7}$</td><td>${88.3} \pm  {0.6}$</td><td>${87.1} \pm  {1.1}$</td><td>85.65</td></tr><tr><td>提出的方法</td><td>${88.7} \pm  {0.6}$</td><td>$\mathbf{{87.4} \pm  {0.8}}$</td><td>${88.8} \pm  {0.3}$</td><td>${88.2} \pm  {0.5}$</td><td>${90.1} \pm  {0.4}$</td><td>${89.7} \pm  {0.7}$</td><td>${92.7} \pm  {0.6}$</td><td>${91.3} \pm  {0.9}$</td><td>89.61</td></tr></tbody></table>

TABLE IX

CLASSIFICATION ACCURACIES (MEAN $\pm$ STD %) FOR DIFFERENT METHODS OVER TEN INDEPEDDENT RUNS FOR THE ${Sunny} \rightarrow$ Rainy TASK IN THE FM3 DATASET. THE BEST RESULTS ARE INDICATED IN BOLD AND THE Second BEST RESULTS ARE UNDERLINED

FM3数据集中${Sunny} \rightarrow$雨天任务的不同方法在十次独立运行中的分类准确率(平均值$\pm$标准差%)。最佳结果以粗体显示，次佳结果加下划线。

<table><tr><td>Method</td><td>HI</td><td>RO</td><td>TU</td><td>EX</td><td>SE</td><td>OB</td><td>BO</td><td>TR</td><td>Average</td></tr><tr><td>Source Only</td><td>${59.3} \pm  {0.5}$</td><td>${60.2} \pm  {0.6}$</td><td>${58.8} \pm  {0.4}$</td><td>${60.7} \pm  {0.8}$</td><td>${57.4} \pm  {0.7}$</td><td>${61.7} \pm  {0.8}$</td><td>${59.1} \pm  {0.9}$</td><td>${62.6} \pm  {0.6}$</td><td>59.98</td></tr><tr><td>DINN [9]</td><td>${54.0} \pm  {1.1}$</td><td>${52.2} \pm  {0.8}$</td><td>${55.1} \pm  {0.7}$</td><td>${53.7} \pm  {0.8}$</td><td>${52.8} \pm  {0.9}$</td><td>${55.3} \pm  {1.1}$</td><td>${51.6} \pm  {1.2}$</td><td>${52.3} \pm  {0.7}$</td><td>53.38</td></tr><tr><td>DTLID [7]</td><td>${55.4} \pm  {0.5}$</td><td>${53.2} \pm  {1.0}$</td><td>${54.8} \pm  {1.2}$</td><td>${54.4} \pm  {1.3}$</td><td>${54.1} \pm  {0.7}$</td><td>${56.2} \pm  {0.8}$</td><td>${56.7} \pm  {0.4}$</td><td>${54.4} \pm  {0.6}$</td><td>54.90</td></tr><tr><td>DMCF [8]</td><td>${54.2} \pm  {0.8}$</td><td>${57.7} \pm  {1.3}$</td><td>${58.2} \pm  {0.7}$</td><td>${56.2} \pm  {0.6}$</td><td>${57.2} \pm  {1.5}$</td><td>${55.7} \pm  {0.7}$</td><td>${60.5} \pm  {0.9}$</td><td>${57.9} \pm  {0.7}$</td><td>57.20</td></tr><tr><td>FRCNN [15]</td><td>${56.1} \pm  {1.3}$</td><td>${62.4} \pm  {0.7}$</td><td>${58.1} \pm  {0.8}$</td><td>${58.3} \pm  {1.4}$</td><td>${57.2} \pm  {1.2}$</td><td>${55.8} \pm  {0.9}$</td><td>${62.9} \pm  {0.8}$</td><td>${60.3} \pm  {0.6}$</td><td>58.89</td></tr><tr><td>DSDANet [26]</td><td>${68.4} \pm  {1.3}$</td><td>${69.9} \pm  {0.9}$</td><td>${63.8} \pm  {0.7}$</td><td>${63.1} \pm  {0.4}$</td><td>${62.2} \pm  {0.9}$</td><td>${64.2} \pm  {0.5}$</td><td>${64.8} \pm  {1.1}$</td><td>${65.5} \pm  {1.3}$</td><td>65.23</td></tr><tr><td>MRAN [27]</td><td>${65.5} \pm  {1.4}$</td><td>${63.3} \pm  {0.8}$</td><td>${66.1} \pm  {0.9}$</td><td>${64.8} \pm  {0.7}$</td><td>${65.0} \pm  {1.1}$</td><td>${66.1} \pm  {1.3}$</td><td>${73.3} \pm  {0.8}$</td><td>${64.7} \pm  {0.9}$</td><td>66.10</td></tr><tr><td>D-MMD [28]</td><td>${71.3} \pm  {1.0}$</td><td>${74.4} \pm  {1.3}$</td><td>${76.3} \pm  {0.7}$</td><td>${75.6} \pm  {0.8}$</td><td>${72.4} \pm  {1.1}$</td><td>${71.1} \pm  {0.9}$</td><td>${70.9} \pm  {0.8}$</td><td>${69.1} \pm  {0.4}$</td><td>72.63</td></tr><tr><td>DTA [29]</td><td>${68.5} \pm  {0.8}$</td><td>${64.8} \pm  {0.9}$</td><td>${71.2} \pm  {0.8}$</td><td>${72.2} \pm  {1.2}$</td><td>${70.6} \pm  {0.7}$</td><td>${67.4} \pm  {0.9}$</td><td>${71.6} \pm  {1.0}$</td><td>${71.8} \pm  {1.1}$</td><td>69.76</td></tr><tr><td>CenterDA [30]</td><td>${75.3} \pm  {1.3}$</td><td>${72.4} \pm  {1.2}$</td><td>${76.8} \pm  {1.4}$</td><td>${79.3} \pm  {0.7}$</td><td>${74.3} \pm  {0.6}$</td><td>${74.2} \pm  {0.9}$</td><td>${72.9} \pm  {0.8}$</td><td>${73.3} \pm  {0.6}$</td><td>74.81</td></tr><tr><td>STAR [31]</td><td>${80.9} \pm  {0.9}$</td><td>${79.3} \pm  {0.8}$</td><td>${86.7} \pm  {0.7}$</td><td>${80.4} \pm  {1.3}$</td><td>${85.6} \pm  {1.2}$</td><td>${81.2} \pm  {0.9}$</td><td>${77.6} \pm  {0.8}$</td><td>${78.1} \pm  {0.5}$</td><td>81.25</td></tr><tr><td>DWL [32]</td><td>${82.3} \pm  {0.9}$</td><td>${80.9} \pm  {1.6}$</td><td>${84.1} \pm  {0.4}$</td><td>${85.5} \pm  {0.6}$</td><td>${83.2} \pm  {0.7}$</td><td>${84.6} \pm  {1.2}$</td><td>${78.1} \pm  {0.8}$</td><td>${80.3} \pm  {0.9}$</td><td>82.38</td></tr><tr><td>Proposed</td><td>${85.1} \pm  {1.0}$</td><td>${84.5} \pm  {0.6}$</td><td>${87.2} \pm  {0.7}$</td><td>${88.7} \pm  {1.2}$</td><td>${89.3} \pm  {0.9}$</td><td>${90.0} \pm  {0.7}$</td><td>${82.3} \pm  {0.5}$</td><td>${86.9} \pm  {0.6}$</td><td>86.75</td></tr></table>

<table><tbody><tr><td>方法</td><td>HI</td><td>RO</td><td>TU</td><td>EX</td><td>SE</td><td>OB</td><td>BO</td><td>TR</td><td>平均值</td></tr><tr><td>仅源域</td><td>${59.3} \pm  {0.5}$</td><td>${60.2} \pm  {0.6}$</td><td>${58.8} \pm  {0.4}$</td><td>${60.7} \pm  {0.8}$</td><td>${57.4} \pm  {0.7}$</td><td>${61.7} \pm  {0.8}$</td><td>${59.1} \pm  {0.9}$</td><td>${62.6} \pm  {0.6}$</td><td>59.98</td></tr><tr><td>DINN [9]</td><td>${54.0} \pm  {1.1}$</td><td>${52.2} \pm  {0.8}$</td><td>${55.1} \pm  {0.7}$</td><td>${53.7} \pm  {0.8}$</td><td>${52.8} \pm  {0.9}$</td><td>${55.3} \pm  {1.1}$</td><td>${51.6} \pm  {1.2}$</td><td>${52.3} \pm  {0.7}$</td><td>53.38</td></tr><tr><td>DTLID [7]</td><td>${55.4} \pm  {0.5}$</td><td>${53.2} \pm  {1.0}$</td><td>${54.8} \pm  {1.2}$</td><td>${54.4} \pm  {1.3}$</td><td>${54.1} \pm  {0.7}$</td><td>${56.2} \pm  {0.8}$</td><td>${56.7} \pm  {0.4}$</td><td>${54.4} \pm  {0.6}$</td><td>54.90</td></tr><tr><td>DMCF [8]</td><td>${54.2} \pm  {0.8}$</td><td>${57.7} \pm  {1.3}$</td><td>${58.2} \pm  {0.7}$</td><td>${56.2} \pm  {0.6}$</td><td>${57.2} \pm  {1.5}$</td><td>${55.7} \pm  {0.7}$</td><td>${60.5} \pm  {0.9}$</td><td>${57.9} \pm  {0.7}$</td><td>57.20</td></tr><tr><td>FRCNN [15]</td><td>${56.1} \pm  {1.3}$</td><td>${62.4} \pm  {0.7}$</td><td>${58.1} \pm  {0.8}$</td><td>${58.3} \pm  {1.4}$</td><td>${57.2} \pm  {1.2}$</td><td>${55.8} \pm  {0.9}$</td><td>${62.9} \pm  {0.8}$</td><td>${60.3} \pm  {0.6}$</td><td>58.89</td></tr><tr><td>DSDANet [26]</td><td>${68.4} \pm  {1.3}$</td><td>${69.9} \pm  {0.9}$</td><td>${63.8} \pm  {0.7}$</td><td>${63.1} \pm  {0.4}$</td><td>${62.2} \pm  {0.9}$</td><td>${64.2} \pm  {0.5}$</td><td>${64.8} \pm  {1.1}$</td><td>${65.5} \pm  {1.3}$</td><td>65.23</td></tr><tr><td>MRAN [27]</td><td>${65.5} \pm  {1.4}$</td><td>${63.3} \pm  {0.8}$</td><td>${66.1} \pm  {0.9}$</td><td>${64.8} \pm  {0.7}$</td><td>${65.0} \pm  {1.1}$</td><td>${66.1} \pm  {1.3}$</td><td>${73.3} \pm  {0.8}$</td><td>${64.7} \pm  {0.9}$</td><td>66.10</td></tr><tr><td>D-MMD [28]</td><td>${71.3} \pm  {1.0}$</td><td>${74.4} \pm  {1.3}$</td><td>${76.3} \pm  {0.7}$</td><td>${75.6} \pm  {0.8}$</td><td>${72.4} \pm  {1.1}$</td><td>${71.1} \pm  {0.9}$</td><td>${70.9} \pm  {0.8}$</td><td>${69.1} \pm  {0.4}$</td><td>72.63</td></tr><tr><td>DTA [29]</td><td>${68.5} \pm  {0.8}$</td><td>${64.8} \pm  {0.9}$</td><td>${71.2} \pm  {0.8}$</td><td>${72.2} \pm  {1.2}$</td><td>${70.6} \pm  {0.7}$</td><td>${67.4} \pm  {0.9}$</td><td>${71.6} \pm  {1.0}$</td><td>${71.8} \pm  {1.1}$</td><td>69.76</td></tr><tr><td>CenterDA [30]</td><td>${75.3} \pm  {1.3}$</td><td>${72.4} \pm  {1.2}$</td><td>${76.8} \pm  {1.4}$</td><td>${79.3} \pm  {0.7}$</td><td>${74.3} \pm  {0.6}$</td><td>${74.2} \pm  {0.9}$</td><td>${72.9} \pm  {0.8}$</td><td>${73.3} \pm  {0.6}$</td><td>74.81</td></tr><tr><td>STAR [31]</td><td>${80.9} \pm  {0.9}$</td><td>${79.3} \pm  {0.8}$</td><td>${86.7} \pm  {0.7}$</td><td>${80.4} \pm  {1.3}$</td><td>${85.6} \pm  {1.2}$</td><td>${81.2} \pm  {0.9}$</td><td>${77.6} \pm  {0.8}$</td><td>${78.1} \pm  {0.5}$</td><td>81.25</td></tr><tr><td>DWL [32]</td><td>${82.3} \pm  {0.9}$</td><td>${80.9} \pm  {1.6}$</td><td>${84.1} \pm  {0.4}$</td><td>${85.5} \pm  {0.6}$</td><td>${83.2} \pm  {0.7}$</td><td>${84.6} \pm  {1.2}$</td><td>${78.1} \pm  {0.8}$</td><td>${80.3} \pm  {0.9}$</td><td>82.38</td></tr><tr><td>提出的方法</td><td>${85.1} \pm  {1.0}$</td><td>${84.5} \pm  {0.6}$</td><td>${87.2} \pm  {0.7}$</td><td>${88.7} \pm  {1.2}$</td><td>${89.3} \pm  {0.9}$</td><td>${90.0} \pm  {0.7}$</td><td>${82.3} \pm  {0.5}$</td><td>${86.9} \pm  {0.6}$</td><td>86.75</td></tr></tbody></table>

TABLE X

CLASSIFICATION ACCURACIES (MEAN $\pm$ STD %) FOR DIFFERENT METHODS OVER TEN INDEPENDENT RUNS FOR THE ${Sunny} \rightarrow  {Snowy}$ TASK IN THE FM3 DATASET. THE BEST RESULTS ARE INDICATED IN BOLD AND THE SECOND BEST RESULTS ARE UNDERLINED

FM3数据集中${Sunny} \rightarrow  {Snowy}$任务的不同方法在十次独立运行中的分类准确率(平均值$\pm$标准差%)。最佳结果以粗体显示，次佳结果以下划线标出

<table><tr><td>Method</td><td>HI</td><td>RO</td><td>TU</td><td>EX</td><td>SE</td><td>OB</td><td>BO</td><td>TR</td><td>Average</td></tr><tr><td>Source Only</td><td>${56.3} \pm  {0.6}$</td><td>${54.3} \pm  {0.8}$</td><td>${52.0} \pm  {0.7}$</td><td>${55.6} \pm  {0.9}$</td><td>${50.2} \pm  {0.6}$</td><td>${53.8} \pm  {1.1}$</td><td>${50.3} \pm  {0.6}$</td><td>${51.3} \pm  {0.8}$</td><td>52.98</td></tr><tr><td>DINN [9]</td><td>${48.6} \pm  {0.5}$</td><td>${46.1} \pm  {0.6}$</td><td>${48.2} \pm  {0.9}$</td><td>${50.3} \pm  {0.8}$</td><td>${43.2} \pm  {0.7}$</td><td>${44.6} \pm  {0.6}$</td><td>${43.2} \pm  {0.7}$</td><td>${45.7} \pm  {0.9}$</td><td>46.24</td></tr><tr><td>DTLID [7]</td><td>${50.8} \pm  {0.6}$</td><td>${48.9} \pm  {0.8}$</td><td>${49.8} \pm  {0.7}$</td><td>${50.4} \pm  {0.6}$</td><td>${44.3} \pm  {0.7}$</td><td>${48.4} \pm  {0.5}$</td><td>${45.6} \pm  {0.9}$</td><td>${46.9} \pm  {1.2}$</td><td>48.14</td></tr><tr><td>DMCF [8]</td><td>${52.6} \pm  {1.3}$</td><td>${51.3} \pm  {0.9}$</td><td>${52.6} \pm  {1.1}$</td><td>${49.1} \pm  {1.4}$</td><td>${46.6} \pm  {0.7}$</td><td>${50.0} \pm  {1.2}$</td><td>${48.3} \pm  {0.6}$</td><td>${49.8} \pm  {0.8}$</td><td>50.04</td></tr><tr><td>FRCNN [15]</td><td>${55.3} \pm  {0.8}$</td><td>${52.1} \pm  {0.7}$</td><td>${50.5} \pm  {0.6}$</td><td>${52.1} \pm  {0.9}$</td><td>${48.3} \pm  {1.2}$</td><td>${50.6} \pm  {1.3}$</td><td>${49.6} \pm  {0.6}$</td><td>${50.3} \pm  {0.7}$</td><td>51.10</td></tr><tr><td>DSDANet [26]</td><td>${60.9} \pm  {1.6}$</td><td>${58.7} \pm  {0.9}$</td><td>${51.3} \pm  {1.2}$</td><td>${57.0} \pm  {1.1}$</td><td>${57.2} \pm  {1.0}$</td><td>${55.6} \pm  {0.7}$</td><td>${59.3} \pm  {0.8}$</td><td>${58.6} \pm  {0.7}$</td><td>57.33</td></tr><tr><td>MRAN [27]</td><td>${62.5} \pm  {0.9}$</td><td>${60.8} \pm  {0.8}$</td><td>${54.6} \pm  {1.2}$</td><td>${65.1} \pm  {1.0}$</td><td>${60.6} \pm  {0.7}$</td><td>${59.1} \pm  {0.6}$</td><td>${58.8} \pm  {0.9}$</td><td>${59.8} \pm  {1.1}$</td><td>59.04</td></tr><tr><td>D-MMD [28]</td><td>${63.8} \pm  {1.3}$</td><td>${64.9} \pm  {0.8}$</td><td>${60.2} \pm  {0.7}$</td><td>${61.4} \pm  {0.6}$</td><td>${62.1} \pm  {1.1}$</td><td>${60.9} \pm  {0.9}$</td><td>${61.8} \pm  {0.6}$</td><td>${59.7} \pm  {1.3}$</td><td>61.85</td></tr><tr><td>DTA [29]</td><td>${63.5} \pm  {0.9}$</td><td>${61.6} \pm  {0.8}$</td><td>${57.2} \pm  {1.3}$</td><td>${58.7} \pm  {1.4}$</td><td>${61.3} \pm  {0.9}$</td><td>${58.1} \pm  {0.7}$</td><td>${57.7} \pm  {1.1}$</td><td>${60.3} \pm  {0.9}$</td><td>59.80</td></tr><tr><td>CenterDA [30]</td><td>${60.5} \pm  {0.7}$</td><td>${65.4} \pm  {1.5}$</td><td>${63.1} \pm  {0.9}$</td><td>${61.8} \pm  {1.2}$</td><td>${62.2} \pm  {0.7}$</td><td>${62.7} \pm  {1.3}$</td><td>${64.2} \pm  {0.9}$</td><td>${61.3} \pm  {1.4}$</td><td>62.65</td></tr><tr><td>STAR [31]</td><td>${63.2} \pm  {0.8}$</td><td>${67.5} \pm  {0.7}$</td><td>${67.1} \pm  {1.2}$</td><td>${64.9} \pm  {1.5}$</td><td>${68.3} \pm  {0.7}$</td><td>${67.2} \pm  {0.9}$</td><td>${63.7} \pm  {1.6}$</td><td>${63.1} \pm  {1.4}$</td><td>65.63</td></tr><tr><td>DWL [32]</td><td>${65.4} \pm  {1.3}$</td><td>${68.3} \pm  {0.7}$</td><td>${66.2} \pm  {0.9}$</td><td>${70.0} \pm  {0.7}$</td><td>${67.1} \pm  {0.6}$</td><td>${64.9} \pm  {0.7}$</td><td>${66.7} \pm  {1.1}$</td><td>${65.7} \pm  {0.8}$</td><td>66.79</td></tr><tr><td>Proposed</td><td>${68.1} \pm  {0.5}$</td><td>${67.5} \pm  {0.6}$</td><td>${74.9} \pm  {0.8}$</td><td>${73.4} \pm  {1.1}$</td><td>${75.5} \pm  {0.7}$</td><td>${69.9} \pm  {0.8}$</td><td>${68.4} \pm  {0.5}$</td><td>$\mathbf{{71.8} \pm  {1.0}}$</td><td>71.19</td></tr></table>

<table><tbody><tr><td>方法</td><td>HI</td><td>RO</td><td>TU</td><td>EX</td><td>SE</td><td>OB</td><td>BO</td><td>TR</td><td>平均</td></tr><tr><td>仅源域</td><td>${56.3} \pm  {0.6}$</td><td>${54.3} \pm  {0.8}$</td><td>${52.0} \pm  {0.7}$</td><td>${55.6} \pm  {0.9}$</td><td>${50.2} \pm  {0.6}$</td><td>${53.8} \pm  {1.1}$</td><td>${50.3} \pm  {0.6}$</td><td>${51.3} \pm  {0.8}$</td><td>52.98</td></tr><tr><td>DINN [9]</td><td>${48.6} \pm  {0.5}$</td><td>${46.1} \pm  {0.6}$</td><td>${48.2} \pm  {0.9}$</td><td>${50.3} \pm  {0.8}$</td><td>${43.2} \pm  {0.7}$</td><td>${44.6} \pm  {0.6}$</td><td>${43.2} \pm  {0.7}$</td><td>${45.7} \pm  {0.9}$</td><td>46.24</td></tr><tr><td>DTLID [7]</td><td>${50.8} \pm  {0.6}$</td><td>${48.9} \pm  {0.8}$</td><td>${49.8} \pm  {0.7}$</td><td>${50.4} \pm  {0.6}$</td><td>${44.3} \pm  {0.7}$</td><td>${48.4} \pm  {0.5}$</td><td>${45.6} \pm  {0.9}$</td><td>${46.9} \pm  {1.2}$</td><td>48.14</td></tr><tr><td>DMCF [8]</td><td>${52.6} \pm  {1.3}$</td><td>${51.3} \pm  {0.9}$</td><td>${52.6} \pm  {1.1}$</td><td>${49.1} \pm  {1.4}$</td><td>${46.6} \pm  {0.7}$</td><td>${50.0} \pm  {1.2}$</td><td>${48.3} \pm  {0.6}$</td><td>${49.8} \pm  {0.8}$</td><td>50.04</td></tr><tr><td>FRCNN [15]</td><td>${55.3} \pm  {0.8}$</td><td>${52.1} \pm  {0.7}$</td><td>${50.5} \pm  {0.6}$</td><td>${52.1} \pm  {0.9}$</td><td>${48.3} \pm  {1.2}$</td><td>${50.6} \pm  {1.3}$</td><td>${49.6} \pm  {0.6}$</td><td>${50.3} \pm  {0.7}$</td><td>51.10</td></tr><tr><td>DSDANet [26]</td><td>${60.9} \pm  {1.6}$</td><td>${58.7} \pm  {0.9}$</td><td>${51.3} \pm  {1.2}$</td><td>${57.0} \pm  {1.1}$</td><td>${57.2} \pm  {1.0}$</td><td>${55.6} \pm  {0.7}$</td><td>${59.3} \pm  {0.8}$</td><td>${58.6} \pm  {0.7}$</td><td>57.33</td></tr><tr><td>MRAN [27]</td><td>${62.5} \pm  {0.9}$</td><td>${60.8} \pm  {0.8}$</td><td>${54.6} \pm  {1.2}$</td><td>${65.1} \pm  {1.0}$</td><td>${60.6} \pm  {0.7}$</td><td>${59.1} \pm  {0.6}$</td><td>${58.8} \pm  {0.9}$</td><td>${59.8} \pm  {1.1}$</td><td>59.04</td></tr><tr><td>D-MMD [28]</td><td>${63.8} \pm  {1.3}$</td><td>${64.9} \pm  {0.8}$</td><td>${60.2} \pm  {0.7}$</td><td>${61.4} \pm  {0.6}$</td><td>${62.1} \pm  {1.1}$</td><td>${60.9} \pm  {0.9}$</td><td>${61.8} \pm  {0.6}$</td><td>${59.7} \pm  {1.3}$</td><td>61.85</td></tr><tr><td>DTA [29]</td><td>${63.5} \pm  {0.9}$</td><td>${61.6} \pm  {0.8}$</td><td>${57.2} \pm  {1.3}$</td><td>${58.7} \pm  {1.4}$</td><td>${61.3} \pm  {0.9}$</td><td>${58.1} \pm  {0.7}$</td><td>${57.7} \pm  {1.1}$</td><td>${60.3} \pm  {0.9}$</td><td>59.80</td></tr><tr><td>CenterDA [30]</td><td>${60.5} \pm  {0.7}$</td><td>${65.4} \pm  {1.5}$</td><td>${63.1} \pm  {0.9}$</td><td>${61.8} \pm  {1.2}$</td><td>${62.2} \pm  {0.7}$</td><td>${62.7} \pm  {1.3}$</td><td>${64.2} \pm  {0.9}$</td><td>${61.3} \pm  {1.4}$</td><td>62.65</td></tr><tr><td>STAR [31]</td><td>${63.2} \pm  {0.8}$</td><td>${67.5} \pm  {0.7}$</td><td>${67.1} \pm  {1.2}$</td><td>${64.9} \pm  {1.5}$</td><td>${68.3} \pm  {0.7}$</td><td>${67.2} \pm  {0.9}$</td><td>${63.7} \pm  {1.6}$</td><td>${63.1} \pm  {1.4}$</td><td>65.63</td></tr><tr><td>DWL [32]</td><td>${65.4} \pm  {1.3}$</td><td>${68.3} \pm  {0.7}$</td><td>${66.2} \pm  {0.9}$</td><td>${70.0} \pm  {0.7}$</td><td>${67.1} \pm  {0.6}$</td><td>${64.9} \pm  {0.7}$</td><td>${66.7} \pm  {1.1}$</td><td>${65.7} \pm  {0.8}$</td><td>66.79</td></tr><tr><td>提出的方法</td><td>${68.1} \pm  {0.5}$</td><td>${67.5} \pm  {0.6}$</td><td>${74.9} \pm  {0.8}$</td><td>${73.4} \pm  {1.1}$</td><td>${75.5} \pm  {0.7}$</td><td>${69.9} \pm  {0.8}$</td><td>${68.4} \pm  {0.5}$</td><td>$\mathbf{{71.8} \pm  {1.0}}$</td><td>71.19</td></tr></tbody></table>

In addition, we observe that the models with domain adaptation techniques in their architectures (e.g., MRAN, STAR, and D-MMD) outperform the models that do not consider the domain shift issue (i.e., DINN, DTLID, DMCF, FRCNN). For instance, as shown in Table II, the MRAN that defines a conditional maximum mean discrepancy loss to align the distribution of source and target images improved the classification accuracy of DTLID and DINN by 6.35% and 8.24%, respectively. Similarly, in Sunny $\rightarrow$ Rainy and Sunny $\rightarrow$ Snowy of BDD100 K, the DSDANet improves the FRCNN classification results by 7.65% and 6.35%, respectively. The DSDANet is a DA-based model that minimizes the distance between spatial-spectral features of source and target through a Siamese architecture while FRCNN merely considers the convolutional features of source images. These classification improvements highlight the importance of considering the domain shift issue for traffic scene classification application.

此外，我们观察到在架构中采用领域自适应技术的模型(例如 MRAN、STAR 和 D-MMD)优于未考虑领域偏移问题的模型(即 DINN、DTLID、DMCF、FRCNN)。例如，如表 II 所示，MRAN 通过定义条件最大均值差异(conditional maximum mean discrepancy)损失来对齐源域和目标域图像的分布，使 DTLID 和 DINN 的分类准确率分别提升了 6.35% 和 8.24%。同样，在 BDD100K 的晴天$\rightarrow$雨天和晴天$\rightarrow$雪天场景中，DSDANet 分别使 FRCNN 的分类结果提升了 7.65% 和 6.35%。DSDANet 是一种基于领域自适应的模型，通过孪生网络结构最小化源域和目标域的时空光谱特征距离，而 FRCNN 仅考虑源图像的卷积特征。这些分类性能的提升凸显了在交通场景分类应用中考虑领域偏移问题的重要性。

As shown in Tables II-X, the Source Only baseline works better than traffic scene classification models including DINN, DTLID, DMCF, and FRCNN. For instance, as shown in Table II, it outperforms DTLID and DMCF by 1.27% and 1.09%, respectively. Similar improvements can be observed on BDD100 K and FM3 datasets. This superiority in performance is due to capturing a powerful sparse image representation in the latent space of a DNN which enhances the generalization capacity of DNNs and mitigates the overfitting challenges.

如表 II 至 X 所示，Source Only 基线模型的表现优于包括 DINN、DTLID、DMCF 和 FRCNN 在内的交通场景分类模型。例如，如表 II 所示，其准确率分别比 DTLID 和 DMCF 高出 1.27% 和 1.09%。在 BDD100K 和 FM3 数据集上也观察到了类似的提升。这种性能优势归因于在深度神经网络(DNN)的潜在空间中捕获了强大的稀疏图像表示，增强了 DNN 的泛化能力并缓解了过拟合问题。

Among the DA-based methods, the DSDANet achieves the lowest average accuracy due to its small parameter space that declines the generalization capacity. As shown in Tables II and III, MRAN improves the average accuracy of DSDANet by ${1.33}\%$ and ${2.39}\%$ in Sunny $\rightarrow$ Cloudy and Sunny $\rightarrow$ Rainy in HSD, respectively. This improvement is due to employing a deeper feature extractor (i.e., ResNet50) to capture the complex patterns of traffic images. As shown in Tables VI and X, the DTA model outperforms MRAN by ${3.04}\%$ and ${2.81}\%$ on BDD100 K and FM3 datasets, respectively. Similar improvements in classification accuracy are observable in HSD dataset. This superiority is because of leveraging an adversarial dropout which reduces the chance of overfitting and helps the model to learn highly nonlinear patterns. Using the MMD loss for within and between class features of source and target images, the D-MMD achieves higher average classification accuracy on all cross-domains problems of all datasets compared to DTA. For instance, as shown in Tables VIII and IX, the D-MMD outperforms DTA by 1.37% and 2.87% in Sunny $\rightarrow$ Cloudy and Sunny $\rightarrow$ Rainy domain shifts of the FM3 dataset, respectively. Similar improvements are reported in Tables II-VII for HSD and BDD100 K.

在基于领域自适应的方法中，DSDANet 由于参数空间较小，导致泛化能力下降，取得了最低的平均准确率。如表 II 和 III 所示，MRAN 在 HSD 数据集的晴天$\rightarrow$多云和晴天$\rightarrow$雨天场景中，分别比 DSDANet 提升了${1.33}\%$和${2.39}\%$的平均准确率。这一提升归因于采用了更深的特征提取器(即 ResNet50)以捕捉交通图像的复杂模式。如表 VI 和 X 所示，DTA 模型在 BDD100K 和 FM3 数据集上分别比 MRAN 高出${3.04}\%$和${2.81}\%$。在 HSD 数据集中也观察到了类似的分类准确率提升。这种优势源于利用了对抗性丢弃(adversarial dropout)，减少了过拟合的可能性，帮助模型学习高度非线性模式。通过对源域和目标域图像的类内及类间特征使用最大均值差异(MMD)损失，D-MMD 在所有数据集的跨域问题上均实现了比 DTA 更高的平均分类准确率。例如，如表 VIII 和 IX 所示，D-MMD 在 FM3 数据集的晴天$\rightarrow$多云和晴天$\rightarrow$雨天领域偏移中，分别比 DTA 高出 1.37% 和 2.87%。在 HSD 和 BDD100K 的表 II 至 VII 中也报告了类似的提升。

The CenterDA model that learns the global distribution of the target domain by determining the common class center and minimizing the distance between the deep features and corresponding class center shows slightly higher classification accuracy compared to D-MMD. As shown in Tables V and VII, the CenterDA achieves 84.06 % and 70.80 % classification accuracy in cloudy and snowy domains of BDD100 K, while the D-MMD yields 83.63% and 70.37%, respectively. The CenterDA shows similar improvements in HSD and FM3 compared to D-MMD. Also, the STAR that uses a diverse set of weighted classifiers to enhance the object classification performance in the UDA problem offers a better domain adaptation compared to the CenterDA with ${6.44}\%$ and ${2.98}\%$ in the Sunny $\rightarrow$ Rainy and Sunny $\rightarrow$ Snowy configurations of the FM3 dataset, respectively. Similar improvements can be observed in HSD and BDD100 K. We observe that DWL which addresses the discriminability vanishing problem via excessive alignment learning is the best baseline across all domain shift problems in different datasets. As shown in Tables II and III, the DWL outperforms STAR by ${3.01}\%$ and ${2.30}\%$ in Sunny $\rightarrow$ Cloudy and Sunny $\rightarrow$ Rainy tasks of HSD, respectively. Similar accuracy improvements are obtained by DWL in BDD100 K and FM3. The main reason for such improvements is preventing domain misalignment and discriminability vanishing problems by dynamically adjusting the weights on the corresponding losses in an adversarial learning scheme.

CenterDA模型通过确定公共类别中心并最小化深度特征与对应类别中心之间的距离，学习目标域的全局分布，其分类准确率略高于D-MMD。如表V和表VII所示，CenterDA在BDD100 K的多云和降雪域分别达到84.06%和70.80%的分类准确率，而D-MMD分别为83.63%和70.37%。与D-MMD相比，CenterDA在HSD和FM3中也表现出类似的提升。此外，STAR通过使用多样化的加权分类器集合来提升UDA问题中的目标分类性能，在FM3数据集的晴天${6.44}\%$雨天和晴天$\rightarrow$降雪配置中，相较于CenterDA表现出更好的域适应性。HSD和BDD100 K中也观察到了类似的提升。我们发现，DWL通过解决过度对齐学习导致的判别能力消失问题，是不同数据集中所有域迁移问题中表现最好的基线。如表II和表III所示，DWL在HSD的晴天$\rightarrow$多云和晴天$\rightarrow$雨天任务中分别比STAR高出${3.01}\%$和${2.30}\%$。在BDD100 K和FM3中，DWL也获得了类似的准确率提升。这些提升的主要原因是在对抗学习框架中动态调整对应损失的权重，从而防止域错配和判别能力消失问题。

Tables II-X indicate that our approach leads to a significantly better performance compared to current state-of-the-art traffic scene classification and domain adaptation frameworks. As shown in Tables II and III, the proposed model outperforms DWL (i.e., the best compared benchmark) by 4.45% and 3.67% in the Sunny $\rightarrow$ Cloudy and Sunny $\rightarrow$ Rainy settings of HSD, respectively. Also, in the BDD100 K dataset, our proposed SADA improves the classification accuracies of DWL by 4.19% and 3.45% in Sunny $\rightarrow$ Rainy and Sunny $\rightarrow$ Snowy tasks, respectively. Similar improvements are observable in the FM3 dataset. In comparison with the Source Only method, we observe more than ${20}\%$ improvement as shown in Tables VIII and IX, which reflects the merit of adversarial domain adaptation in the mitigation of domain shift issues. Similar improvements can be observed in other datasets and domain adaptation tasks. The superiority of the proposed model over other benchmarks stems from taking advantage of adversarial learning and feature augmentation in source and target, and providing a sparse data representation that best describes both domains. The accuracy improvements achieved by our model show the benefits of dictionary learning to capture highly complex visual patterns via sparse representation and adversarial learning to improve the generalization of domain adaptation DNNs.

表II至表X显示，我们的方法相比当前最先进的交通场景分类和域适应框架，性能显著提升。如表II和表III所示，所提模型在HSD的晴天$\rightarrow$多云和晴天$\rightarrow$雨天设置中，分别比DWL(即最佳对比基线)高出4.45%和3.67%。此外，在BDD100 K数据集中，我们提出的SADA在晴天$\rightarrow$雨天和晴天$\rightarrow$降雪任务中，分别提升了DWL的分类准确率4.19%和3.45%。FM3数据集中也观察到了类似的提升。与仅使用源域方法相比，如表VIII和表IX所示，我们观察到超过${20}\%$的提升，反映了对抗域适应在缓解域偏移问题上的优势。其他数据集和域适应任务中也有类似的提升。所提模型优于其他基线的原因在于利用了对抗学习和源域及目标域的特征增强，并提供了最佳描述两个域的稀疏数据表示。我们模型实现的准确率提升展示了字典学习通过稀疏表示捕捉高度复杂视觉模式的优势，以及对抗学习提升域适应深度神经网络泛化能力的效果。

![bo_d285ftn7aajc738oslfg_10_131_187_1466_407_0.jpg](images/bo_d285ftn7aajc738oslfg_10_131_187_1466_407_0.jpg)

Fig. 5. t-SNE visualization of sparse codes extracted by (a) ${E}_{SC}$ and (b) ${E}_{DI}$ .

图5. 由(a) ${E}_{SC}$和(b) ${E}_{DI}$提取的稀疏编码的t-SNE可视化。

## E. Sparse Code Visualization

## E. 稀疏编码可视化

To show the effectiveness of the obtained sparse codes and their robustness to weather variations across different domains, we visualize the sparse codes learned by ${E}_{SC}$ and ${E}_{DI}$ for the images in the source and target domains of the HSD. To this end, we randomly sample 1000 images from the source and target domains of the HSD and used our trained encoders ${E}_{SC}$ and ${E}_{DI}$ to extract the sparse codes. Fig. 5(a) illustrates the 2-dimensional t-SNE [37] of the source sparse codes extracted by ${E}_{SC}$ while Fig. 5(b) indicates the 2-dimensional t-SNE of the domain invariant sparse codes extracted by ${E}_{DI}$ across the source and target samples. As shown in Fig. 5(a), ${E}_{SC}$ captures powerful patterns of the source images that can successfully cluster the source images into their different classes. Additionally, Fig. 5(b) indicates that the sparse codes of the target samples are well aligned with the source samples. This observation shows the effectiveness of the proposed method in identifying domain invariant features for the underlying classification task. That is, the proposed SADA is robust to weather variations in different target datasets.

为了展示所获得稀疏编码的有效性及其对不同域间天气变化的鲁棒性，我们对HSD源域和目标域图像中由${E}_{SC}$和${E}_{DI}$学习的稀疏编码进行了可视化。为此，我们从HSD的源域和目标域随机抽取1000张图像，使用训练好的编码器${E}_{SC}$和${E}_{DI}$提取稀疏编码。图5(a)展示了由${E}_{SC}$提取的源域稀疏编码的二维t-SNE[37]，而图5(b)显示了由${E}_{DI}$提取的跨源域和目标域样本的域不变稀疏编码的二维t-SNE。如图5(a)所示，${E}_{SC}$捕捉了源图像的强大模式，能够成功将源图像聚类到不同类别中。此外，图5(b)表明目标样本的稀疏编码与源样本良好对齐。该观察结果证明了所提方法在识别底层分类任务的域不变特征方面的有效性。即，所提SADA对不同目标数据集中的天气变化具有鲁棒性。

## V. CONCLUSION

## V. 结论

This paper tackles the domain adaptation traffic scene classification under different weather conditions caused by the domain shift issue. The source domain consists of the traffic images in clear sunny weather while the target domain is the traffic images in other weather conditions (i.e., cloudy, rainy, and snowy). A novel sparse adversarial domain adaptation (SADA) DNN is proposed that captures powerful sparse data representations from source traffic scenes. An adversarial deep architecture is devised to align the sparse representation of the target with the source images. This structure extracts powerful domain invariant sparse visual features used by a deep discriminative classifier for an accurate target scene classification. Experiments on three real-world datasets, including HSD, BDD100 K, and FM3, show ${3.98}\% ,{3.45}\%$ , and 4.40% improvement in terms of classification accuracy compared to DWL method on Sunny $\rightarrow$ Snowy domain shift case, respectively. REFERENCES

本文针对因领域偏移问题导致的不同天气条件下的交通场景分类的领域自适应进行了研究。源领域包含晴朗天气下的交通图像，而目标领域则是其他天气条件(即多云、雨天和雪天)下的交通图像。提出了一种新颖的稀疏对抗领域自适应(SADA)深度神经网络(DNN)，该网络从源交通场景中捕获强大的稀疏数据表示。设计了一种对抗深度架构，将目标的稀疏表示与源图像对齐。该结构提取了强大的领域不变稀疏视觉特征，供深度判别分类器用于准确的目标场景分类。在包括HSD、BDD100K和FM3的三个真实世界数据集上的实验表明，分别在晴天与雪天领域偏移情况下，相较于DWL方法，分类准确率提升了${3.98}\% ,{3.45}\%$和4.40%。参考文献

[1] A. Narayanan, I. Dwivedi, and B. Dariush, "Dynamic traffic scene classification with space-time coherence," in Proc. IEEE Int. Conf. Robot. Automat., 2019, pp. 5629-5635.

[1] A. Narayanan, I. Dwivedi, and B. Dariush, "Dynamic traffic scene classification with space-time coherence," in Proc. IEEE Int. Conf. Robot. Automat., 2019, pp. 5629-5635.

[2] S. Di, H. Zhang, C.-G. Li, X. Mei, D. Prokhorov, and H. Ling, "Cross-domain traffic scene understanding: A dense correspondence-based transfer learning approach," IEEE Trans. Intell. Transp. Syst., vol. 19, no. 3, pp. 745-757, Mar. 2018.

[2] S. Di, H. Zhang, C.-G. Li, X. Mei, D. Prokhorov, and H. Ling, "Cross-domain traffic scene understanding: A dense correspondence-based transfer learning approach," IEEE Trans. Intell. Transp. Syst., vol. 19, no. 3, pp. 745-757, Mar. 2018.

[3] Q. Wang, J. Fang, and Y. Yuan, "Adaptive road detection via context-aware label transfer," Neurocomputing, vol. 158, pp. 174-183, 2015.

[3] Q. Wang, J. Fang, and Y. Yuan, "Adaptive road detection via context-aware label transfer," Neurocomputing, vol. 158, pp. 174-183, 2015.

[4] J. M. Alvarez, A. M. López, T. Gevers, and F. Lumbreras, "Combining priors, appearance, and context for road detection," IEEE Trans. Intell. Transp. Syst., vol. 15, no. 3, pp. 1168-1178, Jun. 2014.

[4] J. M. Alvarez, A. M. López, T. Gevers, and F. Lumbreras, "Combining priors, appearance, and context for road detection," IEEE Trans. Intell. Transp. Syst., vol. 15, no. 3, pp. 1168-1178, Jun. 2014.

[5] Y. Xia, W. Xu, L. Zhang, X. Shi, and K. Mao, "Integrating 3D structure into traffic scene understanding with RGB-D data," Neurocomputing, vol. 151, pp. 700-709, 2015.

[5] Y. Xia, W. Xu, L. Zhang, X. Shi, and K. Mao, "Integrating 3D structure into traffic scene understanding with RGB-D data," Neurocomputing, vol. 151, pp. 700-709, 2015.

[6] A. Bolovinou, C. Kotsiourou, and A. Amditis, "Dynamic road scene classification: Combining motion with a visual vocabulary model," in Proc. IEEE 16th Int. Conf. Inf. Fusion, 2013, pp. 1151-1158.

[6] A. Bolovinou, C. Kotsiourou, and A. Amditis, "Dynamic road scene classification: Combining motion with a visual vocabulary model," in Proc. IEEE 16th Int. Conf. Inf. Fusion, 2013, pp. 1151-1158.

[7] I. Sikirić, K. Brkić, P. Bevandić, I. Krešo, J. Krapac, and S. Segvić, "Traffic scene classification on a representation budget," IEEE Trans. Intell. Transp. Syst., vol. 21, no. 1, pp. 336-345, Jan. 2020.

[7] I. Sikirić, K. Brkić, P. Bevandić, I. Krešo, J. Krapac, and S. Segvić, "Traffic scene classification on a representation budget," IEEE Trans. Intell. Transp. Syst., vol. 21, no. 1, pp. 336-345, Jan. 2020.

[8] F. Wu, S. Yan, J. S. Smith, and B. Zhang, "Deep multiple classifier fusion for traffic scene recognition," Granular Comput., vol. 6, no. 1, pp. 217-228, 2021.

[8] F. Wu, S. Yan, J. S. Smith, and B. Zhang, "Deep multiple classifier fusion for traffic scene recognition," Granular Comput., vol. 6, no. 1, pp. 217-228, 2021.

[9] M. Oeljeklaus, F. Hoffmann, and T. Bertram, "A combined recognition and segmentation model for urban traffic scene understanding," in Proc. IEEE 20th Int. Conf. Intell. Transp. Syst., 2017, pp. 1-6.

[9] M. Oeljeklaus, F. Hoffmann, and T. Bertram, "A combined recognition and segmentation model for urban traffic scene understanding," in Proc. IEEE 20th Int. Conf. Intell. Transp. Syst., 2017, pp. 1-6.

[10] J. Wang, Y. Lin, M. Zhang, Y. Gao, and A. J. Ma, "Multi-level temporal dilated dense prediction for action recognition," IEEE Trans. Multimedia, vol. 24, pp. 2553-2566, 2022.

[10] J. Wang, Y. Lin, M. Zhang, Y. Gao, and A. J. Ma, "Multi-level temporal dilated dense prediction for action recognition," IEEE Trans. Multimedia, vol. 24, pp. 2553-2566, 2022.

[11] M. Saffari, M. Khodayar, M. S. Ebrahimi Saadabadi, A. F. Sequeira, and J. S. Cardoso, "Maximum relevance minimum redundancy dropout with informative kernel determinantal point process," Sensors, vol. 21, no. 5, 2021, Art. no. 1846.

[11] M. Saffari, M. Khodayar, M. S. Ebrahimi Saadabadi, A. F. Sequeira, and J. S. Cardoso, "Maximum relevance minimum redundancy dropout with informative kernel determinantal point process," Sensors, vol. 21, no. 5, 2021, Art. no. 1846.

[12] M. Saffari, M. Khodayar, S. M. J. Jalali, M. Shafie-khah, and J. P. Catalão, "Deep convolutional graph rough variational auto-encoder for short-term photovoltaic power forecasting," in Proc. IEEE Int. Conf. Smart Energy Syst. Technol., 2021, pp. 1-6.

[12] M. Saffari, M. Khodayar, S. M. J. Jalali, M. Shafie-khah, 和 J. P. Catalão, “用于短期光伏功率预测的深度卷积图粗糙变分自编码器”，载于 IEEE 国际智能能源系统技术会议论文集，2021，页码1-6。

[13] M. Saffari, M. Khodayar, and M. E. Khodayar, "Deep recurrent extreme learning machine for behind-the-meter photovoltaic disaggregation," Electricity J., vol. 35, no. 5, 2022, Art. no. 107137.

[13] M. Saffari, M. Khodayar, 和 M. E. Khodayar, “基于深度递归极限学习机的电表后光伏分解”，《电力杂志》，第35卷，第5期，2022，文章编号107137。

[14] J. Regan, M. Saffari, and M. Khodayar, "Deep attention and generative neural networks for nonintrusive load monitoring," Electricity J., vol. 35, no. 5, 2022, Art. no. 107127.

[14] J. Regan, M. Saffari, 和 M. Khodayar, “用于非侵入式负载监测的深度注意力与生成神经网络”，《电力杂志》，第35卷，第5期，2022，文章编号107127。

[15] S. Di et al., "Rainy night scene understanding with near scene semantic adaptation," IEEE Trans. Intell. Transp. Syst., vol. 22, no. 3, pp. 1594-1602, Mar. 2021.

[15] S. Di 等，“带近景语义适应的雨夜场景理解”，《IEEE智能交通系统汇刊》，第22卷，第3期，页码1594-1602，2021年3月。

[16] D. Kothandaraman, R. Chandra, and D. Manocha, "SS-SFDA: Self-supervised source-free domain adaptation for road segmentation in hazardous environments," in Proc. IEEE/CVF Int. Conf. Comput. Vis., 2021, Art. no. 3049-3059.

[16] D. Kothandaraman, R. Chandra, 和 D. Manocha, “SS-SFDA:用于危险环境道路分割的无源自监督源域无关域适应”，载于 IEEE/CVF 国际计算机视觉会议论文集，2021，文章编号3049-3059。

[17] Y. Bengio, J. Louradour, R. Collobert, and J. Weston, "Curriculum learning," in Proc. IEEE 26th Annu. Int. Conf. Mach. Learn., 2009, pp. 41-48.

[17] Y. Bengio, J. Louradour, R. Collobert, 和 J. Weston, “课程学习”，载于 IEEE 第26届年度国际机器学习会议论文集，2009，页码41-48。

[18] Y. Hua and D. Yi, "Synthetic to realistic imbalanced domain adaption for urban scene perception," IEEE Trans. Ind. Inform., vol. 18, no. 5, pp. 3248-3255, May 2022.

[18] Y. Hua 和 D. Yi, “用于城市场景感知的合成到真实不平衡域适应”，《IEEE工业信息学汇刊》，第18卷，第5期，页码3248-3255，2022年5月。

[19] J. Ni, K. Shen, Y. Chen, W. Cao, and S. X. Yang, "An improved deep network-based scene classification method for self-driving cars," IEEE Trans. Instrum. Meas., vol. 71, 2022, Art. no. 5001614.

[19] J. Ni, K. Shen, Y. Chen, W. Cao, 和 S. X. Yang, “一种改进的基于深度网络的自动驾驶场景分类方法”，《IEEE仪器与测量汇刊》，第71卷，2022，文章编号5001614。

[20] H. Wang, F. Nie, and H. Huang, "Robust distance metric learning via simultaneous 11-norm minimization and maximization," in Proc. Int. Conf. Mach. Learn., 2014, pp. 1836-1844.

[20] H. Wang, F. Nie, 和 H. Huang, “通过同时最小化和最大化11范数的鲁棒距离度量学习”，载于国际机器学习会议论文集，2014，页码1836-1844。

[21] F. Yu et al., "BDD100 k: A diverse driving dataset for heterogeneous multitask learning," in Proc. IEEE/CVF Conf. Comput. Vis. Pattern Recognit., 2020, pp. 2636-2645.

[21] F. Yu 等，“BDD100k:用于异构多任务学习的多样化驾驶数据集”，载于 IEEE/CVF 计算机视觉与模式识别会议论文集，2020，页码2636-2645。

[22] X. Zhang, Z. Chen, Q. J. Wu, L. Cai, D. Lu, and X. Li, "Fast semantic segmentation for scene perception," IEEE Trans. Ind. Inform., vol. 15, no. 2, pp. 1183-1192, Feb. 2019.

[22] X. Zhang, Z. Chen, Q. J. Wu, L. Cai, D. Lu, 和 X. Li, “用于场景感知的快速语义分割”，《IEEE工业信息学汇刊》，第15卷，第2期，页码1183-1192，2019年2月。

[23] K. He, X. Zhang, S. Ren, and J. Sun, "Deep residual learning for image recognition," in Proc. IEEE Conf. Comput. Vis. Pattern Recognit., 2016, pp. 770-778.

[23] K. He, X. Zhang, S. Ren, 和 J. Sun, “用于图像识别的深度残差学习”，载于 IEEE 计算机视觉与模式识别会议论文集，2016，页码770-778。

[24] B. Zhou, A. Lapedriza, A. Khosla, A. Oliva, and A. Torralba, "Places: A 10 million image database for scene recognition," IEEE Trans. Pattern Anal. Mach. Intell., vol. 40, no. 6, pp. 1452-1464, Jun. 2018.

[24] B. Zhou, A. Lapedriza, A. Khosla, A. Oliva, 和 A. Torralba, “Places:一个包含1000万张图像的场景识别数据库”，《IEEE模式分析与机器智能汇刊》，第40卷，第6期，页码1452-1464，2018年6月。

[25] M. Saffari, M. Khodayar, and M. Teshnehlab, "Random Weights Rough Neural Network for Glaucoma Diagnosis," in Proc. Int. Conf. Natural Comput., Fuzzy Syst. Knowl. Discov., 2021, pp. 534-545.

[25] M. Saffari, M. Khodayar, 和 M. Teshnehlab, “用于青光眼诊断的随机权重粗糙神经网络”，载于国际自然计算、模糊系统与知识发现会议论文集，2021，页码534-545。

[26] S. T. Mehedi, A. Anwar, Z. Rahman, K. Ahmed, and R. Islam, "Dependable intrusion detection system for IoT: A deep transfer learning-based approach," IEEE Trans. Ind. Inform., vol. 19, no. 1, pp. 1006-1017, Jan. 2023.

[26] S. T. Mehedi, A. Anwar, Z. Rahman, K. Ahmed, 和 R. Islam, “面向物联网的可靠入侵检测系统:基于深度迁移学习的方法”，《IEEE工业信息学汇刊》，第19卷，第1期，页码1006-1017，2023年1月。

[27] S. Ioffe and C. Szegedy, "Batch normalization: Accelerating deep network training by reducing internal covariate shift," in Proc. Int. Conf. Mach. Learn., 2015, pp. 448-456.

[27] S. Ioffe 和 C. Szegedy，“批量归一化(Batch normalization):通过减少内部协变量偏移加速深度网络训练”，发表于国际机器学习大会论文集，2015年，第448-456页。

[28] N. Srivastava, G. Hinton, A. Krizhevsky, I. Sutskever, and R. Salakhutdi-nov, "Dropout: A simple way to prevent neural networks from overfitting," J. Mach. Learn. Res., vol. 15, no. 1, pp. 1929-1958, 2014.

[28] N. Srivastava, G. Hinton, A. Krizhevsky, I. Sutskever 和 R. Salakhutdinov，“Dropout:防止神经网络过拟合的简单方法”，机器学习研究杂志，第15卷，第1期，2014年，第1929-1958页。

[29] A. Paszke et al., "Pytorch: An imperative style, high-performance deep learning library," in Proc. 33rd Adv. Int. Conf. Neural Inf. Process. Syst., 2019, vol. 32, pp. 8026-8037.

[29] A. Paszke 等，“Pytorch:一种命令式风格的高性能深度学习库”，发表于第33届神经信息处理系统高级国际会议论文集，2019年，第32卷，第8026-8037页。

[30] H. Chen, C. Wu, B. Du, and L. Zhang, "DSDANet: Deep siamese domain adaptation convolutional neural network for cross-domain change detection," 2020, arXiv:2006.09225.

[30] H. Chen, C. Wu, B. Du 和 L. Zhang，“DSDANet:用于跨域变化检测的深度孪生域适应卷积神经网络”，2020年，arXiv:2006.09225。

[31] Y. Zhu et al., "Multi-representation adaptation network for cross-domain image classification," Neural Netw., vol. 119, pp. 214-221, 2019.

[31] Y. Zhu 等，“用于跨域图像分类的多表示适应网络”，神经网络，第119卷，2019年，第214-221页。

[32] D. Mekhazni, A. Bhuiyan, G. Ekladious, and E. Granger, "Unsupervised domain adaptation in the dissimilarity space for person re-identification," in Proc. Eur. Conf. Comput. Vis., 2020, pp. 159-174.

[32] D. Mekhazni, A. Bhuiyan, G. Ekladious 和 E. Granger，“基于不相似度空间的无监督域适应用于行人再识别”，发表于欧洲计算机视觉会议，2020年，第159-174页。

[33] S. Lee, D. Kim, N. Kim, and S.-G. Jeong, "Drop to adapt: Learning discriminative features for unsupervised domain adaptation," in Proc. IEEE/CVF Int. Conf. Comput. Vis., 2019, pp. 91-100.

[33] S. Lee, D. Kim, N. Kim 和 S.-G. Jeong，“Drop to adapt:无监督域适应的判别特征学习”，发表于IEEE/CVF国际计算机视觉会议，2019年，第91-100页。

[34] G. Wei, Z. Wei, L. Huang, J. Nie, and X. Li, "Center-aligned domain adaptation network for image classification," Expert Syst. Appl., vol. 168, 2021, Art. no. 114381.

[34] G. Wei, Z. Wei, L. Huang, J. Nie 和 X. Li，“面向图像分类的中心对齐域适应网络”，专家系统应用，第168卷，2021年，文章编号114381。

[35] Z. Lu, Y. Yang, X. Zhu, C. Liu, Y.-Z. Song, and T. Xiang, "Stochastic classifiers for unsupervised domain adaptation," in Proc. IEEE/CVF Conf. Comput. Vis. Pattern Recognit., 2020, Art. no. 9111-9120.

[35] Z. Lu, Y. Yang, X. Zhu, C. Liu, Y.-Z. Song 和 T. Xiang，“用于无监督域适应的随机分类器”，发表于IEEE/CVF计算机视觉与模式识别会议，2020年，文章编号9111-9120。

[36] N. Xiao and L. Zhang, "Dynamic weighted learning for unsupervised domain adaptation," in Proc. IEEE/CVF Conf. Comput. Vis. Pattern Recog-nit., 2021, pp. 15242-15251.

[36] N. Xiao 和 L. Zhang，“无监督域适应的动态加权学习”，发表于IEEE/CVF计算机视觉与模式识别会议，2021年，第15242-15251页。

[37] L. Van der Maaten and G. Hinton, "Visualizing data using t-SNE," J. Mach. Learn. Res., vol. 9, no. 11, pp. 2579-2605, 2008.

[37] L. Van der Maaten 和 G. Hinton，“使用t-SNE进行数据可视化”，机器学习研究杂志，第9卷，第11期，2008年，第2579-2605页。

![bo_d285ftn7aajc738oslfg_11_893_533_221_277_0.jpg](images/bo_d285ftn7aajc738oslfg_11_893_533_221_277_0.jpg)

Mohsen Saffari (Student Member, IEEE) received the B.Sc. degree in electrical engineering from the Shahrood University of Technology, Shahrud, Iran, in 2014, and the M.Sc. degree in electrical engineering from the K. N. Toosi University of Technology, Tehran, Iran, in 2016. He is currently working toward the Ph.D. degree in computer science with the University of Tulsa, Tulsa, OK, USA. His research interests include theories and applications of machine learning in computer vision and energy systems. He is a Reviewer of IEEE TRANSACTIONS ON VEHICULAR TECHNOLOGY, IEEE TRANSACTIONS ON EMERGING TOPICS IN COMPUTATIONAL INTELLIGENCE, and Neural Processing Letters Journal.

Mohsen Saffari(IEEE学生会员)于2014年获得伊朗Shahrood理工大学电气工程学士学位，2016年获得伊朗K. N. Toosi理工大学电气工程硕士学位。目前，他在美国俄克拉荷马州塔尔萨大学攻读计算机科学博士学位。其研究兴趣包括机器学习在计算机视觉和能源系统中的理论与应用。他是IEEE《车辆技术汇刊》(TRANSACTIONS ON VEHICULAR TECHNOLOGY)、IEEE《计算智能新兴主题汇刊》(TRANSACTIONS ON EMERGING TOPICS IN COMPUTATIONAL INTELLIGENCE)及《神经处理快报》(Neural Processing Letters)期刊的审稿人。

![bo_d285ftn7aajc738oslfg_11_892_1021_224_280_0.jpg](images/bo_d285ftn7aajc738oslfg_11_892_1021_224_280_0.jpg)

Mahdi Khodayar (Member, IEEE) received the B.Sc. degree in computer engineering and the M.Sc. degree in artificial intelligence from the K. N. Toosi University of Technology, Tehran, Iran, in 2013 and 2015, respectively, and the Ph.D. degree in electrical engineering from Southern Methodist University, Dallas, TX, USA, in 2020. In 2017, he was a Research Assistant with the College of Computer and Information Science, Northeastern University, Boston, MA, USA. He is currently an Assistant Professor with the Department of Computer Science, The University of Tulsa, Tulsa, OK, USA. His main research interests include machine learning, statistical pattern recognition, deep learning, sparse modeling, and spatiotemporal pattern recognition. Dr. Khodayar was a Reviewer for many reputable journals, including the IEEE TRANSACTIONS ON NEURAL NETWORKS AND LEARNING SYSTEMS, IEEE TRANSACTIONS ON INDUSTRIAL INFORMATICS, IEEE TRANSACTIONS ON FUZZY SYSTEMS, IEEE TRANSACTIONS ON SUSTAINABLE ENERGY, and IEEE TRANSACTIONS ON POWER SYSTEMS.

Mahdi Khodayar(IEEE会员)于2013年和2015年分别获得伊朗德黑兰K. N. Toosi理工大学计算机工程学士学位和人工智能硕士学位，2020年获得美国德克萨斯州达拉斯南方卫理公会大学电气工程博士学位。2017年，他曾任职于美国马萨诸塞州波士顿东北大学计算机与信息科学学院的研究助理。目前，他是美国俄克拉荷马州塔尔萨大学计算机科学系的助理教授。其主要研究方向包括机器学习、统计模式识别、深度学习、稀疏建模及时空模式识别。Khodayar博士曾为多家知名期刊担任审稿人，包括IEEE神经网络与学习系统汇刊(IEEE TRANSACTIONS ON NEURAL NETWORKS AND LEARNING SYSTEMS)、IEEE工业信息学汇刊(IEEE TRANSACTIONS ON INDUSTRIAL INFORMATICS)、IEEE模糊系统汇刊(IEEE TRANSACTIONS ON FUZZY SYSTEMS)、IEEE可持续能源汇刊(IEEE TRANSACTIONS ON SUSTAINABLE ENERGY)及IEEE电力系统汇刊(IEEE TRANSACTIONS ON POWER SYSTEMS)。

![bo_d285ftn7aajc738oslfg_11_891_1648_224_274_0.jpg](images/bo_d285ftn7aajc738oslfg_11_891_1648_224_274_0.jpg)

Seyed Mohammad Jafar Jalali (Member, IEEE) received the M.S. degree in information technology major in advanced information systems from Allameh Tabataba'i University, Tehran, Iran, in 2016, and the Ph.D. degree from the Institute for Intelligent Systems Research and Innovation, Deakin University, Bur-wood, VIC, Australia, in 2021. He was a Research Assistant with the University of Massachusetts, Boston, MA, USA, conducting research in the field of artificial intelligence. He is currently a Research Fellow with Deakin University. His primary research interests include machine learning, deep neural architecture search, deep learning, and optimization. He was the recipient of the prestigious Deakin University Postgraduate Research Scholarship, in 2018. He is the Winner of the prestigious Alfred Deakin Postdoctoral Research Fellowship Award, in 2021.

Seyed Mohammad Jafar Jalali(IEEE会员)于2016年获得伊朗德黑兰Allameh Tabataba'i大学高级信息系统专业信息技术硕士学位，2021年获得澳大利亚维多利亚州伯伍德迪肯大学智能系统研究与创新学院博士学位。他曾在美国马萨诸塞州波士顿马萨诸塞大学担任研究助理，开展人工智能领域的研究。目前，他是迪肯大学的研究员。其主要研究兴趣包括机器学习、深度神经架构搜索、深度学习及优化。2018年，他获得了享有盛誉的迪肯大学研究生研究奖学金，2021年荣获著名的Alfred Deakin博士后研究奖学金。