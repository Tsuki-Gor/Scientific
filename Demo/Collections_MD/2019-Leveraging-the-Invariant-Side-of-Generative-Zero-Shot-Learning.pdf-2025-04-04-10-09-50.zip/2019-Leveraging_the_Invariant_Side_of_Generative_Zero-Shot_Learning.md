# Leveraging the Invariant Side of Generative Zero-Shot Learning

# 利用生成式零样本学习的不变性方面

Jingjing ${\mathrm{{Li}}}^{1}$ , Mengmeng ${\mathrm{{Jing}}}^{1}$ , Ke ${\mathrm{{Lu}}}^{1}$ , Zhengming ${\mathrm{{Ding}}}^{2}$ , Lei ${\mathrm{{Zhu}}}^{3}$ , Zi ${\mathrm{{Huang}}}^{4}$ ${}^{1}$ University of Electronic Science and Technology of China; ${}^{3}$ Shandong Normal Unversity ${}^{2}$ Indiana University-Purdue University Indianapolis; ${}^{4}$ University of Queensland

晶晶 ${\mathrm{{Li}}}^{1}$ ，萌萌 ${\mathrm{{Jing}}}^{1}$ ，柯 ${\mathrm{{Lu}}}^{1}$ ，正明 ${\mathrm{{Ding}}}^{2}$ ，雷 ${\mathrm{{Zhu}}}^{3}$ ，子 ${\mathrm{{Huang}}}^{4}$ ${}^{1}$ 电子科技大学； ${}^{3}$ 山东师范大学 ${}^{2}$ 印第安纳大学 - 普渡大学印第安纳波利斯分校； ${}^{4}$ 昆士兰大学

lijin117@yeah.net

## Abstract

## 摘要

Conventional zero-shot learning (ZSL) methods generally learn an embedding, e.g., visual-semantic mapping, to handle the unseen visual samples via an indirect manner. In this paper, we take the advantage of generative adversarial networks (GANs) and propose a novel method, named leveraging invariant side GAN (LisGAN), which can directly generate the unseen features from random noises which are conditioned by the semantic descriptions. Specifically, we train a conditional Wasserstein GANs in which the generator synthesizes fake unseen features from noises and the discriminator distinguishes the fake from real via a minimax game. Considering that one semantic description can correspond to various synthesized visual samples, and the semantic description, figuratively, is the soul of the generated features, we introduce soul samples as the invariant side of generative zero-shot learning in this paper. A soul sample is the meta-representation of one class. It visualizes the most semantically-meaningful aspects of each sample in the same category. We regularize that each generated sample (the varying side of generative ZSL) should be close to at least one soul sample (the invariant side) which has the same class label with it. At the zero-shot recognition stage, we propose to use two classifiers, which are deployed in a cascade way, to achieve a coarse-to-fine result. Experiments on five popular benchmarks verify that our proposed approach can outperform state-of-the-art methods with significant improvements ${}^{1}$ .

传统的零样本学习(ZSL)方法通常学习一种嵌入，例如视觉 - 语义映射，以间接方式处理未见的视觉样本。在本文中，我们利用生成对抗网络(GANs)的优势，提出了一种名为利用不变性方面生成对抗网络(LisGAN)的新方法，该方法可以根据语义描述从随机噪声中直接生成未见的特征。具体来说，我们训练了一个条件 Wasserstein 生成对抗网络，其中生成器从噪声中合成虚假的未见特征，鉴别器通过极小极大博弈区分虚假特征和真实特征。考虑到一个语义描述可以对应各种合成的视觉样本，并且形象地说，语义描述是生成特征的“灵魂”，我们在本文中引入“灵魂样本”作为生成式零样本学习的不变性方面。灵魂样本是一个类别的元表示。它可视化了同一类别中每个样本最具语义意义的方面。我们规定每个生成的样本(生成式零样本学习的可变方面)应至少接近一个与其具有相同类别标签的灵魂样本(不变性方面)。在零样本识别阶段，我们建议使用两个级联部署的分类器来实现从粗到细的识别结果。在五个流行基准数据集上的实验验证了我们提出的方法能够显著优于现有最先进的方法 ${}^{1}$ 。

## 1. Introduction

## 1. 引言

In general, a computer vision algorithm can only handle the objects which appeared in the training dataset. In other words, an algorithm can only recognize the objects which are seen before. However, for some specific real-world applications, we either do not have the training sample of one object or the sample is too expensive to be labeled. For instance, we want the approach to trigger a message when it encounters a sample with a rare gene mutation from one species. Unfortunately, we did not have the visual features of the sample for training. The things we have are merely the images taken from normal instances and some semantic descriptions which describe the characteristics of the mutation and how it differs from normal ones. Conventional machine learning algorithms would fail in this task, but a human being would not. A human being is able to recognize an unseen object at the first glance by only reading some semantic descriptions. Inspired by this, zero-shot learning (ZSL) $\left\lbrack  {5,{32},{35},{36}}\right\rbrack$ is proposed to handle unseen objects by the model which is trained on only seen objects and semantic descriptions about both seen and unseen categories.

一般来说，计算机视觉算法只能处理训练数据集中出现过的对象。换句话说，算法只能识别之前见过的对象。然而，对于一些特定的现实应用，我们要么没有某个对象的训练样本，要么标注样本的成本太高。例如，我们希望该方法在遇到来自某一物种的具有罕见基因突变的样本时触发一条消息。不幸的是，我们没有用于训练的该样本的视觉特征。我们所拥有的仅仅是从正常实例中拍摄的图像以及一些描述突变特征及其与正常特征差异的语义描述。传统的机器学习算法在这项任务中会失败，但人类不会。人类仅通过阅读一些语义描述就能一眼识别出未见的对象。受此启发，零样本学习(ZSL) $\left\lbrack  {5,{32},{35},{36}}\right\rbrack$ 被提出，用于让仅在见过的对象和关于见过与未见类别的语义描述上训练的模型处理未见对象。

![0195e05a-b157-797d-a35b-5773a73e3543_0_961_660_588_292_0.jpg](images/0195e05a-b157-797d-a35b-5773a73e3543_0_961_660_588_292_0.jpg)

Figure 1. Zero-shot learning with GANs, i.e., generative ZSL.

图 1. 使用生成对抗网络的零样本学习，即生成式零样本学习。

Since the seen and unseen classes are connected by the semantic descriptions, a natural idea is to learn a visual-semantic mapping so that both seen and unseen samples can be compared in the semantic space. For instance, previous works $\left\lbrack  {5,{37} - {39}}\right\rbrack$ learn either shallow or deep embeddings for zero-shot learning. These methods handle the unseen samples via an indirect way. Considering that one semantic description can correspond to enormous number of visual samples, the performance of zero-shot learning is restricted with the limited semantic information.

由于见过的和未见的类别通过语义描述相连，一个自然的想法是学习一种视觉 - 语义映射，以便在语义空间中比较见过的和未见的样本。例如，先前的工作 $\left\lbrack  {5,{37} - {39}}\right\rbrack$ 为零样本学习学习浅层或深层嵌入。这些方法以间接方式处理未见样本。考虑到一个语义描述可以对应大量的视觉样本，零样本学习的性能受到有限语义信息的限制。

Recently, thanks to the advances in generative adversarial networks (GANs) [8], a few approaches are proposed to directly generate unseen samples from the random noises and semantic descriptions $\left\lbrack  {{24},{34},{40}}\right\rbrack$ , as shown in Fig. 1. With the generated unseen samples, zero-shot learning can be transformed to a general supervised machine learning problem. In such a learning paradigm, however, the challenges of zero-shot learning have been also passed on to the GANs. In the GANs based paradigms for zero-shot learning, we have to address the spurious and soulless generating problem. Specifically, we generally have only one semantic description, e.g., one attributes vector, one article or one paragraph of texts, for a specific category, but the semantic description is inherently related to a great mass of images in the visual space. For instance, "a tetrapod with a tail" can be mapped to many animals, e.g., cats, dogs and horses. At the same time, some objects from different categories have very similar attributes, such as "tigers" and "ligers". Thus, the generative adversarial networks for zero-shot learning must challenge two issues: 1) how to guarantee the generative diversity based on limited and even similar attributes? 2) how to make sure that each generated sample is highly related with the real samples and corresponding semantic descriptions? However, since deploying GANs to address the ZSL problem is a new topic, most of existing works did not explicitly address the two issues. In this paper, we propose a novel approach which takes the two aspects into consideration and carefully handles them in the formulation.

最近，得益于生成对抗网络(GANs)[8]的发展，人们提出了一些方法，可直接从随机噪声和语义描述 $\left\lbrack  {{24},{34},{40}}\right\rbrack$ 中生成未见样本，如图1所示。利用生成的未见样本，零样本学习可以转化为一个通用的有监督机器学习问题。然而，在这样的学习范式中，零样本学习的挑战也传递给了生成对抗网络。在基于生成对抗网络的零样本学习范式中，我们必须解决虚假和空洞的生成问题。具体来说，对于一个特定类别，我们通常只有一个语义描述，例如一个属性向量、一篇文章或一段文本，但语义描述在视觉空间中本质上与大量图像相关。例如，“有尾巴的四足动物”可以映射到许多动物，如猫、狗和马。同时，来自不同类别的一些物体具有非常相似的属性，如“老虎”和“狮虎兽”。因此，用于零样本学习的生成对抗网络必须应对两个问题:1) 如何在有限甚至相似的属性基础上保证生成的多样性？2) 如何确保每个生成的样本与真实样本和相应的语义描述高度相关？然而，由于将生成对抗网络应用于解决零样本学习(ZSL)问题是一个新课题，大多数现有工作并未明确解决这两个问题。在本文中，我们提出了一种新方法，该方法考虑了这两个方面，并在公式中仔细处理了它们。

---

${}^{1}$ Codes and datasets are available at github.com/lijin118/LisGAN

${}^{1}$ 代码和数据集可在github.com/lijin118/LisGAN获取

---

At first, to guarantee that the generated samples are meaningful, we propose to generate samples from random noises which are conditioned with the class semantic descriptions. At the same time, we also introduce the supervised classification loss in the GAN discriminator to preserve the inter-class discrimination during the adversarial training. Furthermore, to ensure that each synthesized sample (the varying side of generative zero-shot learning) is highly related with the real ones and corresponding semantic descriptions (the invariant side), we introduce soul samples in this paper, as shown in Fig. 3. For unseen classes, the visual characteristics of a generated sample only depend on the semantic descriptions. Thus, the semantic information is the soul of the generated samples. The soul sample must be not very specific so that it can plainly visualize the most semantically-meaningful aspects and relate to as many samples as possible. For the seen images, therefore, we define that a soul sample is an average representation of them. For the generated samples, we regularize them to be close to soul samples. Thus, we can guarantee that each generated sample is highly related with the real ones and corresponding semantic descriptions.

首先，为了确保生成的样本有意义，我们提议从以类别语义描述为条件的随机噪声中生成样本。同时，我们还在生成对抗网络的判别器中引入了有监督的分类损失，以在对抗训练期间保留类间区分性。此外，为了确保每个合成样本(生成式零样本学习的可变部分)与真实样本和相应的语义描述(不变部分)高度相关，我们在本文中引入了灵魂样本，如图3所示。对于未见类别，生成样本的视觉特征仅取决于语义描述。因此，语义信息是生成样本的灵魂。灵魂样本不能过于具体，以便它能清晰地可视化最具语义意义的方面，并与尽可能多的样本相关联。因此，对于已见图像，我们将灵魂样本定义为它们的平均表示。对于生成的样本，我们对其进行正则化，使其接近灵魂样本。这样，我们可以确保每个生成的样本与真实样本和相应的语义描述高度相关。

To summarize, the main contributions of this paper are:

综上所述，本文的主要贡献如下:

1) We propose a novel ZSL method LisGAN which takes advantage of generative adversarial networks. Specifically, we deploy the conditional GANs to tackle the two issues: generative diversity and generative reliability. To improve the quality of generated features, we introduce soul samples which are defined as the representations of each category. By further considering the multi-view nature of different images, we propose to define multiple soul samples for each class. We regularize each generated sample to be close to at least one soul sample so that the varying side in generative zero-shot learning would not be divorced from the invariant side.

1) 我们提出了一种新颖的零样本学习(ZSL)方法LisGAN，该方法利用了生成对抗网络。具体来说，我们部署条件生成对抗网络来解决两个问题:生成多样性和生成可靠性。为了提高生成特征的质量，我们引入了灵魂样本，将其定义为每个类别的表示。通过进一步考虑不同图像的多视图性质，我们提议为每个类别定义多个灵魂样本。我们对每个生成的样本进行正则化，使其至少接近一个灵魂样本，这样生成式零样本学习中的可变部分就不会与不变部分脱节。

2) At the zero-shot recognition stage, we propose that if we have high confidence in recognizing an unseen sample, the sample (with its assigned pseudo label) will be leveraged as the reference to recognize other unseen samples. Specifically, we propose to use two classifiers, which are deployed in a cascade way, to achieve a coarse-to-fine result. We also report a simple yet efficient method to measure the classification confidence in this paper.

2) 在零样本识别阶段，我们提出，如果我们对识别一个未见样本有很高的置信度，那么该样本(及其分配的伪标签)将被用作识别其他未见样本的参考。具体来说，我们提议使用两个级联部署的分类器，以实现从粗到细的识别结果。我们还在本文中报告了一种简单而有效的方法来衡量分类置信度。

3) Extensive experiments on five widely used datasets verify that our proposed method can outperform state-of-the-art methods with remarkable improvements.

3) 在五个广泛使用的数据集上进行的大量实验验证了我们提出的方法能够显著优于现有最先进的方法。

## 2. Related Work

## 2. 相关工作

### 2.1. Zero-Shot Learning

### 2.1. 零样本学习

Inspired by the human ability that one can recognize an object at the first glance by only knowing some semantic descriptions of it, zero-shot learning [4, 6, 13, 17, 35] aims to learn a model with good generalization ability which can recognize unseen objects by only giving some semantic attributes. A typical zero-shot learning model is trained on visual features which only contain the seen samples and semantic features which contain both seen and unseen samples. Since the seen objects and unseen ones are only connected in the semantic space and the unseen objects need to be recognized by the visual features, zero-shot learning methods generally learn a visual-semantic embedding with the seen samples. At the zero-shot classification stage, unseen samples are projected into the semantic space and labeled by semantic attributes $\left\lbrack  {5,{15},{16},{29}}\right\rbrack$ . Instead of learning a visual-semantic embedding, some previous works also propose to learn a semantic-visual mapping so that the unseen samples can be represented by the seen ones [12,30]. In addition, there are also some works to learn an intermediate space shared by the visual features and semantic features $\left\lbrack  {4,{38},{39}}\right\rbrack$ . Besides, ZSL is also related with domain adaptation and cold-start recommendation [18-21].

受人类仅通过了解物体的一些语义描述就能一眼识别该物体这一能力的启发，零样本学习[4, 6, 13, 17, 35]旨在学习一个具有良好泛化能力的模型，该模型仅通过给定一些语义属性就能识别未见物体。一个典型的零样本学习模型是基于视觉特征(仅包含已见样本)和语义特征(包含已见和未见样本)进行训练的。由于已见物体和未见物体仅在语义空间中存在关联，且需要通过视觉特征来识别未见物体，因此零样本学习方法通常会利用已见样本学习一种视觉 - 语义嵌入。在零样本分类阶段，未见样本会被投影到语义空间，并通过语义属性进行标注 $\left\lbrack  {5,{15},{16},{29}}\right\rbrack$。除了学习视觉 - 语义嵌入之外，一些先前的工作还提出学习一种语义 - 视觉映射，以便用已见样本表示未见样本[12,30]。此外，还有一些工作致力于学习一个视觉特征和语义特征共享的中间空间 $\left\lbrack  {4,{38},{39}}\right\rbrack$。此外，零样本学习(ZSL)还与领域自适应和冷启动推荐相关[18 - 21]。

From the recent literatures, typical zero-shot learning tasks are zero-shot classification [11, 36], zero-shot retrieval [22] and generalized zero-shot recognition [32]. The main difference between zero-shot learning and generalized zero-shot recognition is that the former only classifies the unseen samples in the unseen category and the latter recognizes samples, which can be either seen ones and unseen ones, in both seen and unseen categories.

从近期的文献来看，典型的零样本学习任务包括零样本分类[11, 36]、零样本检索[22]和广义零样本识别[32]。零样本学习和广义零样本识别的主要区别在于，前者仅对未见类别中的未见样本进行分类，而后者则对已见和未见类别中的样本(可以是已见样本或未见样本)进行识别。

It is easy to observe that conventional zero-shot learning methods are indirect. They usually need to learn a space mapping function. Recently, by taking advantage of generative adversarial networks $\left\lbrack  {3,8}\right\rbrack$ , several methods $\left\lbrack  {{34},{40}}\right\rbrack$ are proposed to directly generate unseen samples from their corresponding attributes, which converts the conventional zero-shot learning to a classic supervised learning problem.

不难发现，传统的零样本学习方法是间接的。它们通常需要学习一个空间映射函数。最近，利用生成对抗网络 $\left\lbrack  {3,8}\right\rbrack$，有几种方法 $\left\lbrack  {{34},{40}}\right\rbrack$ 被提出用于直接从相应属性生成未见样本，这将传统的零样本学习转化为一个经典的有监督学习问题。

![0195e05a-b157-797d-a35b-5773a73e3543_2_193_207_1375_422_0.jpg](images/0195e05a-b157-797d-a35b-5773a73e3543_2_193_207_1375_422_0.jpg)

Figure 2. Idea illustration of our LisGAN (Leveraging invariant side GAN). We train a conditional WGAN to generate fake unseen images from random noises and semantic attributes. Multiple soul samples for each class are introduced to regularize the generator. Unseen samples classified with high confidence are leveraged to fine-tune final results.

图2. 我们的LisGAN(利用不变侧生成对抗网络)的思想示意图。我们训练一个条件Wasserstein生成对抗网络(WGAN)，从随机噪声和语义属性中生成虚假的未见图像。引入每个类别的多个核心样本对生成器进行正则化。利用高置信度分类的未见样本对最终结果进行微调。

### 2.2. Generative Adversarial Nets

### 2.2. 生成对抗网络

A typical generative adversarial networks (GANs) [8] consists of two components: a generator and a discriminator. The two players are trained in an adversarial manner. Specifically, the generator $G$ tries to generate fake images from input noises to fool the discriminator, while the discriminator $D$ attempts to distinguish real images and fake ones. In general, the input of $G$ is random noise and the output is the synthesized image. The inputs of $D$ are both real images and fake images, the output is a probability distribution. In this paper, we deploy $G$ to generate sample features instead of image pixels.

一个典型的生成对抗网络(GANs)[8]由两个组件组成:一个生成器和一个判别器。这两个参与者以对抗的方式进行训练。具体来说，生成器 $G$ 试图从输入噪声中生成虚假图像以欺骗判别器，而判别器 $D$ 则试图区分真实图像和虚假图像。一般来说，$G$ 的输入是随机噪声，输出是合成图像。$D$ 的输入包括真实图像和虚假图像，输出是一个概率分布。在本文中，我们使用 $G$ 来生成样本特征，而不是图像像素。

Although GANs has shown quite impressive results and profound impacts, the vanilla GAN is very hard to train. Wasserstein GANs (WGANs) [3] presents an alternative to traditional GAN training. WGANs can improve the stability of learning, get rid of problems like mode collapse, and provide meaningful learning curves useful for debugging and hyperparameter searches. In addition, conditional GANs [23] are proposed to enhance the outputs of traditional GANs. With conditional GANs, one can incorporate the class labels and other information into the generator and discriminator to synthesize specified samples.

尽管生成对抗网络(GANs)已经取得了相当令人瞩目的成果并产生了深远的影响，但原始的生成对抗网络很难训练。Wasserstein生成对抗网络(WGANs)[3]为传统的生成对抗网络训练提供了一种替代方法。Wasserstein生成对抗网络可以提高学习的稳定性，避免模式崩溃等问题，并提供对调试和超参数搜索有用的有意义的学习曲线。此外，条件生成对抗网络[23]被提出用于增强传统生成对抗网络的输出。通过条件生成对抗网络，可以将类别标签和其他信息融入生成器和判别器中，以合成指定的样本。

### 3.The Proposed Method

### 3. 所提出的方法

### 3.1. Definitions and Notations

### 3.1. 定义和符号

Given $n$ labeled seen samples with both visual features $X \in  {\mathbb{R}}^{d \times  n}$ and semantic descriptions $A \in  {\mathbb{R}}^{m \times  n}$ for training, zero-shot learning aims to recognize ${n}_{u}$ unknown visual samples ${X}_{u} \in  {\mathbb{R}}^{d \times  {n}_{u}}$ which only have semantic attributes ${A}_{u} \in  {\mathbb{R}}^{m \times  {n}_{u}}$ for training. Let $Y$ and ${Y}_{u}$ be the label space of $X$ and ${X}_{u}$ , respectively, in zero-shot learning we have $Y \cap  {Y}_{u} = \varnothing$ . Suppose that we have $C$ and ${C}_{u}$ categories in total for seen data and unseen data, respectively, classical zero-shot learning recognizes ${X}_{u}$ by only searching in ${C}_{u}$ , while generalized zero-shot learning searches in $C \cup  {C}_{s}$ . The semantic descriptions $A$ and ${A}_{u}$ are either provided as binary/numerical vectors or word embedding/RNN features. Each semantic description $a$ corresponds to a category $y$ . Formally, given $\{ X, A, Y\}$ and $\left\{  {{A}_{u},{Y}_{u}}\right\}$ for training, the task of zero shot learning is to learn a function $f : {\mathcal{X}}_{u} \rightarrow  {\mathcal{Y}}_{u}$ and generalized zero shot learning is to learn a function $f : \left\{  {\mathcal{X},{\mathcal{X}}_{u}}\right\}   \rightarrow  \mathcal{Y} \cup  {\mathcal{Y}}_{u}$ .

给定用于训练的 $n$ 个有标签的已见样本，这些样本同时具有视觉特征 $X \in  {\mathbb{R}}^{d \times  n}$ 和语义描述 $A \in  {\mathbb{R}}^{m \times  n}$，零样本学习旨在识别 ${n}_{u}$ 个未知的视觉样本 ${X}_{u} \in  {\mathbb{R}}^{d \times  {n}_{u}}$，这些样本仅具有用于训练的语义属性 ${A}_{u} \in  {\mathbb{R}}^{m \times  {n}_{u}}$。设 $Y$ 和 ${Y}_{u}$ 分别为 $X$ 和 ${X}_{u}$ 的标签空间，在零样本学习中，我们有 $Y \cap  {Y}_{u} = \varnothing$。假设我们分别有 $C$ 个和 ${C}_{u}$ 个类别用于已见数据和未见数据，经典的零样本学习仅在 ${C}_{u}$ 中搜索来识别 ${X}_{u}$，而广义零样本学习在 $C \cup  {C}_{s}$ 中搜索。语义描述 $A$ 和 ${A}_{u}$ 可以作为二进制/数值向量或词嵌入/RNN 特征提供。每个语义描述 $a$ 对应一个类别 $y$。形式上，给定用于训练的 $\{ X, A, Y\}$ 和 $\left\{  {{A}_{u},{Y}_{u}}\right\}$，零样本学习的任务是学习一个函数 $f : {\mathcal{X}}_{u} \rightarrow  {\mathcal{Y}}_{u}$，广义零样本学习的任务是学习一个函数 $f : \left\{  {\mathcal{X},{\mathcal{X}}_{u}}\right\}   \rightarrow  \mathcal{Y} \cup  {\mathcal{Y}}_{u}$。

### 3.2. Overall Idea

### 3.2. 总体思路

In this paper, we take advantage of GANs to directly generate fake visual features for unseen samples from random noises and the semantic descriptions. Then, the synthesized visual features are used as references to classify real unseen samples. Since we only have ${A}_{u}$ and the GAN discriminator cannot access ${X}_{u}$ in the training stage, the real or fake game, therefore, cannot be played. Thus, we mainly train our GAN on the seen classes. At the same time, we deploy the conditional GANs so that the class embedding can be incorporated into both generator $G$ and discriminator $D$ . Since $\{ A, Y\}$ and $\left\{  {{A}_{u},{Y}_{u}}\right\}$ are interconnected, i.e., $A$ and ${A}_{u}$ have the same semantic space, the conditional GAN which generates high-quality samples for seen classes is also expected to generate high-quality samples for unseen categories. The main idea of this paper is illustrated in Fig 2. Compared with existing methods which also deploy GANs for zero-shot learning, our novelty comes from two aspects. The first one is that we introduce multiple soul samples per class to regularize the generator. The second is that we leverage the unseen samples which are classified with high confidence to facilitate the subsequent unseen samples. Experiments reported in section 5 show that we can achieve a significant improvement against state-of-the-art methods on various datasets.

在本文中，我们利用生成对抗网络(GANs)从随机噪声和语义描述中直接为未见样本生成虚假视觉特征。然后，将合成的视觉特征用作参考来对真实的未见样本进行分类。由于在训练阶段我们只有 ${A}_{u}$，且 GAN 判别器无法访问 ${X}_{u}$，因此无法进行真假博弈。因此，我们主要在已见类别上训练我们的 GAN。同时，我们部署条件 GAN，以便将类别嵌入纳入生成器 $G$ 和判别器 $D$ 中。由于 $\{ A, Y\}$ 和 $\left\{  {{A}_{u},{Y}_{u}}\right\}$ 是相互关联的，即 $A$ 和 ${A}_{u}$ 具有相同的语义空间，为已见类别生成高质量样本的条件 GAN 也有望为未见类别生成高质量样本。本文的主要思路如图 2 所示。与现有的同样使用 GAN 进行零样本学习的方法相比，我们的新颖性来自两个方面。第一个方面是我们为每个类别引入多个核心样本(soul samples)来规范生成器。第二个方面是我们利用高置信度分类的未见样本，以促进后续未见样本的处理。第 5 节报告的实验表明，在各种数据集上，我们相对于现有最先进的方法可以取得显著的改进。

![0195e05a-b157-797d-a35b-5773a73e3543_3_209_192_579_189_0.jpg](images/0195e05a-b157-797d-a35b-5773a73e3543_3_209_192_579_189_0.jpg)

Figure 3. Soul samples of the horse category. Considering the nature multi-view property of visual objects, e.g., real images of an object are usually captured from different views, we propose to learn multiple soul samples for each class. By such a formulation, the domain shift issue caused by different views can be alleviated.

图 3. 马类别的核心样本。考虑到视觉对象的自然多视角属性，例如，一个对象的真实图像通常从不同视角捕获，我们建议为每个类别学习多个核心样本。通过这种方式，可以缓解由不同视角引起的领域偏移问题。

### 3.3. Train the LisGAN

### 3.3. 训练 LisGAN

Given the seen samples $\{ X, A, Y\}$ , the attributes ${A}_{u}$ of the unseen sample and random noises $z \sim  \mathcal{N}\left( {0,1}\right)$ , the GAN generator $G$ uses the input $a$ and nosies $z$ to synthesize fake features. At the same time, the GAN discriminator $D$ takes the features of real image $x$ and $G\left( {z, a}\right)$ as inputs to discriminate whether an input feature is real or fake. Formally, the loss of $G$ can be formulated as follows:

给定已见样本 $\{ X, A, Y\}$、未见样本的属性 ${A}_{u}$ 和随机噪声 $z \sim  \mathcal{N}\left( {0,1}\right)$，GAN 生成器 $G$ 使用输入 $a$ 和噪声 $z$ 来合成虚假特征。同时，GAN 判别器 $D$ 将真实图像的特征 $x$ 和 $G\left( {z, a}\right)$ 作为输入，以判别输入特征是真实的还是虚假的。形式上，$G$ 的损失可以表述如下:

$$
{L}_{G} =  - \mathbb{E}\left\lbrack  {D\left( {G\left( {z, a}\right) }\right) }\right\rbrack   - \lambda \mathbb{E}\left\lbrack  {\log P\left( {y \mid  G\left( {z, a}\right) }\right) }\right\rbrack  , \tag{1}
$$

where the first term is the Wasserstein loss [3] and the second one is the supervised classification loss on the synthesized features, $\lambda  > 0$ is a balancing parameter.

其中第一项是瓦瑟斯坦损失 [3]，第二项是合成特征上的监督分类损失，$\lambda  > 0$ 是一个平衡参数。

Similarly, the loss of the discriminator can be formulated as follows:

类似地，判别器的损失可以表述如下:

$$
{L}_{D} = \mathbb{E}\left\lbrack  {D\left( {G\left( {z, a}\right) }\right) }\right\rbrack   - \mathbb{E}\left\lbrack  {D\left( x\right) }\right\rbrack
$$

$$
- \lambda \left( {\mathbb{E}\left\lbrack  {\log P\left( {y \mid  G\left( {z, a}\right) }\right) }\right\rbrack   + \mathbb{E}\left\lbrack  {\log P\left( {y \mid  x}\right) }\right\rbrack  }\right)  \tag{2}
$$

$$
- \beta \mathbb{E}\left\lbrack  {\left( \parallel {\nabla }_{\widehat{x}}D\left( \widehat{x}\right) {\parallel }_{2} - 1\right) }^{2}\right\rbrack  ,
$$

where $\beta  > 0$ is a hyper-parameter. The fourth term, similar with the third one, is a supervised classification loss on real samples. The last term is used to enforce the Lipschitz constraint [9], in which $\widehat{x} = {\mu x} + \left( {1 - \mu }\right) G\left( {z, a}\right)$ with $\mu  \sim  U\left( {0,1}\right)$ . As suggested in [9], we fix $\beta  = {10}$ .

其中 $\beta  > 0$ 是一个超参数。第四项与第三项类似，是真实样本上的监督分类损失。最后一项用于强制执行利普希茨约束 [9]，其中 $\widehat{x} = {\mu x} + \left( {1 - \mu }\right) G\left( {z, a}\right)$ 且 $\mu  \sim  U\left( {0,1}\right)$。正如 [9] 中所建议的，我们固定 $\beta  = {10}$。

In our model, we take the CNN features of samples as the visual input $X$ . Both the generator and discriminator are implemented with fully connected layers and ReLU activations. Thus, the model is feasible to incorporate into different CNN architectures. At the same time, the output of the generator is directly visual features rather than image pixels. By optimizing the above two-player minimax game, the conditional GAN generator is able to synthesize fake features of the seen images with the class embedding $A$ . Since the unseen objects share the same semantic space with the seen samples, the conditional GAN generator can also synthesize visual features for unseen categories via ${A}_{u}$ . With the optimization problem in Eq. (1) and Eq. (2), our model can guarantee the generative diversity with similar attributes. With the supervised classification loss, it can also ensure that the learned features are discriminative for further classification. However, the model does not explicitly address the quality of the generated features. In this paper, to make sure that each generated feature is highly related with the semantic descriptions and real samples, we introduce soul samples to regularize the generator. Since the soul samples of a category should reflect the most remarkable characteristics of the class as much as possible, we deploy the average representation of all samples from the category $c$ to define the soul sample of $c$ , which is similar with prototypical networks for few-shot learning [31]. Furthermore, considering the nature multi-view property of real samples, as shown in Fig. 3, we further propose that a category $c$ should have multiple soul samples to address the multi-view issue. To this end, we first group the real features of one seen class into $k$ clusters. For simplicity, we fix $k = 3$ in this paper. Then, we calculate a soul sample for each cluster. Let $\left\{  {{X}_{1}^{c},{X}_{2}^{c},\cdots ,{X}_{k}^{c}}\right\}$ be the $k$ clusters of category $c$ , the soul samples ${S}^{c} = \left\{  {{s}_{1}^{c},{s}_{2}^{c},\cdots ,{s}_{k}^{c}}\right\}$ are

在我们的模型中，我们将样本的卷积神经网络(CNN)特征作为视觉输入 $X$。生成器和判别器均采用全连接层和修正线性单元(ReLU)激活函数实现。因此，该模型可以很方便地集成到不同的卷积神经网络架构中。同时，生成器的输出是直接的视觉特征，而不是图像像素。通过优化上述两人极小极大博弈，条件生成对抗网络(GAN)生成器能够利用类别嵌入 $A$ 合成已见图像的虚假特征。由于未见对象与已见样本共享相同的语义空间，条件生成对抗网络生成器也可以通过 ${A}_{u}$ 为未见类别合成视觉特征。通过式(1)和式(2)中的优化问题，我们的模型可以保证具有相似属性的生成多样性。通过监督分类损失，它还可以确保学习到的特征对于进一步分类具有判别性。然而，该模型并未明确解决生成特征的质量问题。在本文中，为了确保每个生成的特征都与语义描述和真实样本高度相关，我们引入灵魂样本对生成器进行正则化。由于一个类别的灵魂样本应尽可能反映该类别的最显著特征，我们采用该类别 $c$ 所有样本的平均表示来定义 $c$ 的灵魂样本，这与用于少样本学习的原型网络 [31] 类似。此外，考虑到真实样本的自然多视图属性，如图 3 所示，我们进一步提出一个类别 $c$ 应该有多个灵魂样本来解决多视图问题。为此，我们首先将一个已见类别的真实特征分组为 $k$ 个聚类。为简单起见，本文中我们固定 $k = 3$。然后，我们为每个聚类计算一个灵魂样本。设 $\left\{  {{X}_{1}^{c},{X}_{2}^{c},\cdots ,{X}_{k}^{c}}\right\}$ 为类别 $c$ 的 $k$ 个聚类，灵魂样本 ${S}^{c} = \left\{  {{s}_{1}^{c},{s}_{2}^{c},\cdots ,{s}_{k}^{c}}\right\}$ 为

defined as:

定义为:

$$
{s}_{k}^{c} = \frac{1}{\left| {X}_{k}^{c}\right| }\mathop{\sum }\limits_{{{x}_{i} \in  {X}_{k}^{c}}}{x}_{i}. \tag{3}
$$

Similarly, for the generated fake features, we can also define the soul sample ${\widetilde{s}}_{k}^{c}$ as:

类似地，对于生成的虚假特征，我们也可以将灵魂样本 ${\widetilde{s}}_{k}^{c}$ 定义为:

$$
{\widetilde{s}}_{k}^{c} = \frac{1}{\left| {\widetilde{X}}_{k}^{c}\right| }\mathop{\sum }\limits_{{{\widetilde{x}}_{i} \in  {\widetilde{X}}_{k}^{c}}}{\widetilde{x}}_{i}, \tag{4}
$$

where ${\widetilde{x}}_{i} = G\left( {z, a}\right)$ is a generated fake feature.

其中 ${\widetilde{x}}_{i} = G\left( {z, a}\right)$ 是一个生成的虚假特征。

In this paper, we encourage that each generated sample $\widetilde{x}$ for class $c$ should be close to at least one soul sample ${s}^{c}$ . Formally, we introduce the following regularization:

在本文中，我们鼓励为类别 $c$ 生成的每个样本 $\widetilde{x}$ 应至少接近一个灵魂样本 ${s}^{c}$。形式上，我们引入以下正则化:

$$
{L}_{R1} = \frac{1}{{n}_{1}}\mathop{\sum }\limits_{{i = 1}}^{{n}_{1}}\mathop{\min }\limits_{{j \in  \left\lbrack  {1, k}\right\rbrack  }}{\begin{Vmatrix}{\widetilde{x}}_{i} - {s}_{j}^{c}\end{Vmatrix}}_{2}^{2}, \tag{5}
$$

where ${n}_{1}$ is the number of generated samples and $k$ is the number of soul samples per class. At the same time, since the soul samples can also be seen as the centroid of one cluster, we encourage that the fake soul samples should be close to at least one real soul sample from the same class, which can be formulated as:

其中 ${n}_{1}$ 是生成样本的数量，$k$ 是每个类别的灵魂样本数量。同时，由于灵魂样本也可以看作是一个聚类的质心，我们鼓励虚假灵魂样本应至少接近同一类别的一个真实灵魂样本，这可以表述为:

$$
{L}_{R2} = \frac{1}{C}\mathop{\sum }\limits_{{c = 1}}^{C}\mathop{\min }\limits_{{j \in  \left\lbrack  {1, k}\right\rbrack  }}{\begin{Vmatrix}{\widetilde{s}}_{j}^{c} - {s}_{j}^{c}\end{Vmatrix}}_{2}^{2}, \tag{6}
$$

where $C$ is the number of total categories. With the two regularizations ${L}_{R1}$ and ${L}_{R2}$ , our model avoids to generate soulless features. Each of the generated features would be close to the real ones, which guarantees the quality of the fake features. From another perspective, ${L}_{R1}$ is an individual regularization which addresses single samples and ${L}_{R2}$ is a group regularization which takes care of a cluster.

其中 $C$ 是总类别的数量。通过两个正则化项 ${L}_{R1}$ 和 ${L}_{R2}$，我们的模型避免生成无意义的特征。每个生成的特征都将接近真实特征，这保证了虚假特征的质量。从另一个角度来看，${L}_{R1}$ 是一个针对单个样本的个体正则化项，${L}_{R2}$ 是一个针对聚类的组正则化项。

### 3.4. Predict Unseen Samples

### 3.4. 预测未见样本

Once the GAN is trained to be able to generate visual features for seen classes, it can also synthesize visual features for the unseen ones with random noises and semantic attributes ${A}_{u}$ . Then, the zero-shot learning is automatically converted to a supervised learning problem. Specifically, we can train a softmax classifier on the generated features and classify the real unseen features. The softmax is formulated as minimizing the following negative log likelihood:

一旦生成对抗网络(GAN)经过训练，能够为已见类别生成视觉特征，它也可以利用随机噪声和语义属性 ${A}_{u}$ 为未见类别合成视觉特征。然后，零样本学习就自动转化为一个有监督学习问题。具体来说，我们可以在生成的特征上训练一个softmax分类器，并对真实的未见特征进行分类。softmax的公式为最小化以下负对数似然:

$$
\mathop{\min }\limits_{\theta } - \frac{1}{\left| \mathcal{X}\right| }\mathop{\sum }\limits_{{\left( {x, y}\right)  \in  \left( {\mathcal{X},\mathcal{Y}}\right) }}\log P\left( {y \mid  x;\theta }\right) , \tag{7}
$$

where $\theta$ is the training parameter and

其中 $\theta$ 是训练参数，

$$
P\left( {y \mid  x;\theta }\right)  = \frac{\exp \left( {{\theta }_{y}^{\top }x}\right) }{\mathop{\sum }\limits_{{i = 1}}^{N}\exp \left( {{\theta }_{i}^{\top }x}\right) }. \tag{8}
$$

In this paper, we further propose that we can leverage an unseen sample if we have sufficient confidence in believing that the sample has been correctly classified. Since the output of the softmax layer is a vector which contains the probabilities of all possible categories, the entropy of the vector can be used to measure the certainty of the results. If a probability vector has lower entropy, we have more confidence of the results. Therefore, we leverage the samples which have low classification entropy and deploy them as references to classify the other unseen samples. Specifically, we calculate the sample entropy by:

在本文中，我们进一步提出，如果我们有足够的信心认为一个未见样本已被正确分类，就可以利用该样本。由于softmax层的输出是一个包含所有可能类别的概率的向量，因此该向量的熵可以用来衡量结果的确定性。如果一个概率向量的熵较低，我们对结果就更有信心。因此，我们利用分类熵较低的样本，并将它们作为参考来对其他未见样本进行分类。具体来说，我们通过以下方式计算样本熵:

$$
\mathrm{E}\left( y\right)  =  - \mathop{\sum }\limits_{{c = 1}}^{C}{y}_{c}\log {y}_{c}. \tag{9}
$$

In our model, we deploy two classifiers via a cascade manner to predict the unseen samples. The first classifier is used to evaluate the classification confidence and the second is used to leverage the correctly classified samples. In our zero-shot recognition, the first classifier is a softmax trained on the generated fake features, while second classifier can be either a trained classifier, e.g., softmax classifier, SVM, or just a training-free classifier, e.g., NNC.

在我们的模型中，我们通过级联方式部署两个分类器来预测未见样本。第一个分类器用于评估分类置信度，第二个分类器用于利用被正确分类的样本。在我们的零样本识别中，第一个分类器是在生成的虚假特征上训练的softmax分类器，而第二个分类器可以是一个经过训练的分类器，如softmax分类器、支持向量机(SVM)，或者只是一个无需训练的分类器，如最近邻分类器(NNC)。

## 4. Experiments

## 4. 实验

### 4.1. Datasets

### 4.1. 数据集

APascal-aYahoo (aPaY) contains 32 categories from both PASCAL VOC 2008 dataset and Yahoo image search engine. Specifically, 20 classes are from PASCAL and 12 classes are from Yahoo. The total number of aPaY is 15,339. Following previous work $\left\lbrack  {{35},{40}}\right\rbrack$ , we deploy the PASCAL VOC 2008 as seen dataset and the Yahoo as unseen one. An additional 64-dimensional attribute vector is annotated for each category.

APascal - aYahoo(aPaY)包含来自PASCAL VOC 2008数据集和雅虎图像搜索引擎的32个类别。具体来说，20个类别来自PASCAL，12个类别来自雅虎。aPaY的总数为15339。遵循先前的工作 $\left\lbrack  {{35},{40}}\right\rbrack$ ，我们将PASCAL VOC 2008用作已见数据集，将雅虎数据集用作未见数据集。为每个类别标注了一个额外的64维属性向量。

Animals with Attributes (AwA) [14] consists of 30,475 images of 50 animals classes. The animals classes are aligned with Osherson's classical class/attribute matrix, thereby providing 85 numeric attribute values for each class.

带属性的动物数据集(Animals with Attributes，AwA) [14] 包含50个动物类别的30475张图像。这些动物类别与奥舍尔森(Osherson)的经典类别/属性矩阵对齐，从而为每个类别提供85个数值属性值。

Caltech-UCSD Birds-200-2011 (CUB) [33] is an extended version of the CUB-200 dataset. CUB is a challenging dataset which contains 11,788 images of 200 bird species. Each species is associated with a Wikipedia article and organized by scientific classification (order, family, genus, species). A vocabulary of 28 attribute groupings and 312 binary attributes were associated with the dataset based on an online tool for bird species identification.

加州理工学院 - 加州大学圣地亚哥分校鸟类数据集200 - 2011(Caltech - UCSD Birds - 200 - 2011，CUB) [33] 是CUB - 200数据集的扩展版本。CUB是一个具有挑战性的数据集，包含200种鸟类的11788张图像。每个物种都与一篇维基百科文章相关联，并按科学分类(目、科、属、种)进行组织。基于一个用于鸟类物种识别的在线工具，为该数据集关联了一个包含28个属性分组和312个二元属性的词汇表。

Table 1. Dataset statistics. The (number) in # Seen Classes indicates the number of seen classes used for test in the GZSL.

表1. 数据集统计信息。#已见类别中的(数字)表示在广义零样本学习(GZSL)测试中使用的已见类别的数量。

<table><tr><td>Dataset</td><td>aPaY</td><td>AwA</td><td>CUB</td><td>FLO</td><td>SUN</td></tr><tr><td>#Samples</td><td>15,339</td><td>30,475</td><td>11,788</td><td>8,189</td><td>14,340</td></tr><tr><td>#Attributes</td><td>64</td><td>85</td><td>312</td><td>1,024</td><td>102</td></tr><tr><td>#Seen Classes</td><td>20 (5)</td><td>40 (13)</td><td>150 (50)</td><td>82 (20)</td><td>645 (65)</td></tr><tr><td>#Unseen Classes</td><td>12</td><td>10</td><td>50</td><td>20</td><td>72</td></tr></table>

<table><tbody><tr><td>数据集</td><td>aPaY</td><td>AwA</td><td>CUB</td><td>FLO</td><td>太阳(SUN)</td></tr><tr><td>样本数量</td><td>15,339</td><td>30,475</td><td>11,788</td><td>8,189</td><td>14,340</td></tr><tr><td>属性数量</td><td>64</td><td>85</td><td>312</td><td>1,024</td><td>102</td></tr><tr><td>已见类别数量</td><td>20 (5)</td><td>40 (13)</td><td>150 (50)</td><td>82 (20)</td><td>645 (65)</td></tr><tr><td>未见类别数量</td><td>12</td><td>10</td><td>50</td><td>20</td><td>72</td></tr></tbody></table>

Oxford Flowers (FLO) [25] dataset consists of 8,189 images which comes from 102 flower categories. Each class consists of between 40 and 258 images. The images have large scale, pose and light variations. In addition, there are categories that have large variations within the category and several very similar categories. For this dataset, we use the same semantic descriptions provided by Reed et al. [28].

牛津花卉(Oxford Flowers，FLO)[25]数据集包含8189张图像，这些图像来自102个花卉类别。每个类别包含40到258张图像。这些图像在尺度、姿态和光照方面存在较大变化。此外，有些类别内部差异较大，还有几个类别非常相似。对于这个数据集，我们使用里德(Reed)等人[28]提供的相同语义描述。

SUN attributes (SUN) [27] is a large-scale scene attribute dataset, which spans 717 categories and 14,340 images in total. Each category includes 102 attribute labels.

太阳属性(SUN attributes，SUN)[27]是一个大规模场景属性数据集，总共涵盖717个类别和14340张图像。每个类别包含102个属性标签。

For clarity, we report the dataset statistics and zero-shot split settings in Table 1. The zero-shot splits of aPaY, AwA, CUB and SUN are same with previous work [35] and the splits of FLO is same with [28]. For the real CNN features, we follow previous work [34] to extract 2048-dimensional features from ResNet-101 [10] which is pre-trained on Im-ageNet. For the semantic descriptions, we use the default attributes included in the datasets. Specifically, since FLO did not provide attributes with the dataset, we use the 1024- dimensional RNN descriptions via the model of [28]. For fair comparisons, all of our experimental settings are same with the protocols reported in previous work [34].

为清晰起见，我们在表1中报告了数据集统计信息和零样本分割设置。aPaY、AwA、CUB和SUN的零样本分割与先前的工作[35]相同，FLO的分割与[28]相同。对于真实的卷积神经网络(CNN)特征，我们遵循先前的工作[34]，从在ImageNet上预训练的ResNet - 101[10]中提取2048维特征。对于语义描述，我们使用数据集中包含的默认属性。具体来说，由于FLO数据集未提供属性，我们通过[28]的模型使用1024维的循环神经网络(RNN)描述。为了进行公平比较，我们所有的实验设置都与先前工作[34]中报告的协议相同。

### 4.2. Implementation and Compared Methods

### 4.2. 实现与对比方法

In our model, the GAN is implemented via multilayer perceptron with Rectified Linear Unit (ReLU) activation. Specifically, the generator $G$ contains a fully connected layer with 4,096 hidden units. The noise $z$ is conditioned by the semantic description $a$ and then severed as the inputs of $G$ . An additional ReLU layer is deployed as the output layer of $G$ which outputs the synthesized fake features. The discriminator $D$ takes the real features and the synthesized fake features from $G$ and processes them via an FC layer, a Leaky ReLU layer, an FC layer and a ReLU layer. The discriminator has two branches for output. One is used to tell fake from real and the other is a standard $n$ -ways classifier to predict the correct category of each sample. In this paper, we set $\lambda  = {0.01}$ and $\beta  = {10}$ . The weight for two regular-izations are all set to 0.01 . The sample entropy threshold is set to be smaller than the median of all entropies. One can also tune the hyper-parameters by cross-validation.

在我们的模型中，生成对抗网络(GAN)通过具有修正线性单元(Rectified Linear Unit，ReLU)激活函数的多层感知机实现。具体而言，生成器 $G$ 包含一个具有4096个隐藏单元的全连接层。噪声 $z$ 由语义描述 $a$ 进行条件约束，然后作为 $G$ 的输入。一个额外的ReLU层被用作 $G$ 的输出层，输出合成的虚假特征。判别器 $D$ 接收来自 $G$ 的真实特征和合成的虚假特征，并通过一个全连接层、一个带泄漏修正线性单元(Leaky ReLU)层、一个全连接层和一个ReLU层对它们进行处理。判别器有两个输出分支。一个用于区分真假，另一个是标准的 $n$ 路分类器，用于预测每个样本的正确类别。在本文中，我们设置 $\lambda  = {0.01}$ 和 $\beta  = {10}$ 。两个正则化项的权重均设置为0.01。样本熵阈值设置为小于所有熵的中位数。也可以通过交叉验证来调整超参数。

The compared methods are representative ones published in the fast few years and the state-of-the-art ones reported very recently. Specifically, we compare our approach with: DAP [15], CONSE [26], SSE [38], DeViSE [7], SJE [2], ESZSL [29], ALE [1], SYNC [4], SAE [13], DEM [37], GAZSL [40] and f-CLSWGAN [34].

对比方法是过去几年发表的具有代表性的方法以及最近报道的最先进的方法。具体来说，我们将我们的方法与以下方法进行比较:DAP [15]、CONSE [26]、SSE [38]、DeViSE [7]、SJE [2]、ESZSL [29]、ALE [1]、SYNC [4]、SAE [13]、DEM [37]、GAZSL [40]和f - CLSWGAN [34]。

Table 2. The top-1 accuracy (%) of zero-shot learning on different datasets. The best results are highlighted with bold numbers.

表2. 不同数据集上零样本学习的前1准确率(%)。最佳结果用粗体数字突出显示。

<table><tr><td/><td/><td>.</td><td/><td/><td/></tr><tr><td>Methods</td><td>aPaY</td><td>AwA</td><td>CUB</td><td>FLO</td><td>SUN</td></tr><tr><td>DAP [15]</td><td>33.8</td><td>44.1</td><td>40.0</td><td>-</td><td>39.9</td></tr><tr><td>CONSE [26]</td><td>26.9</td><td>45.6</td><td>34.3</td><td>-</td><td>38.8</td></tr><tr><td>SSE [38]</td><td>34.0</td><td>60.1</td><td>43.9</td><td>-</td><td>51.5</td></tr><tr><td>DeViSE [7]</td><td>39.8</td><td>54.2</td><td>52.0</td><td>45.9</td><td>56.5</td></tr><tr><td>SJE [2]</td><td>32.9</td><td>65.6</td><td>53.9</td><td>53.4</td><td>53.7</td></tr><tr><td>ESZSL [29]</td><td>38.3</td><td>58.2</td><td>53.9</td><td>51.0</td><td>54.5</td></tr><tr><td>ALE [1]</td><td>39.7</td><td>59.9</td><td>54.9</td><td>48.5</td><td>58.1</td></tr><tr><td>SYNC [4]</td><td>23.9</td><td>54.0</td><td>55.6</td><td>-</td><td>56.3</td></tr><tr><td>SAE [13]</td><td>8.3</td><td>53.0</td><td>33.3</td><td>-</td><td>40.3</td></tr><tr><td>DEM [37]</td><td>35.0</td><td>68.4</td><td>51.7</td><td>-</td><td>61.9</td></tr><tr><td>GAZSL [40]</td><td>41.1</td><td>68.2</td><td>55.8</td><td>60.5</td><td>61.3</td></tr><tr><td>f-CLSWGAN [34]</td><td>40.5</td><td>68.2</td><td>57.3</td><td>67.2</td><td>60.8</td></tr><tr><td>LisGAN [Ours]</td><td>43.1</td><td>70.6</td><td>58.8</td><td>69.6</td><td>61.7</td></tr></table>

<table><tbody><tr><td></td><td></td><td>.</td><td></td><td></td><td></td></tr><tr><td>方法</td><td>aPaY(原文未明确含义，保留原文)</td><td>AwA(原文未明确含义，保留原文)</td><td>CUB(原文未明确含义，保留原文)</td><td>FLO(原文未明确含义，保留原文)</td><td>太阳(SUN)</td></tr><tr><td>判别式属性预测(DAP) [15]</td><td>33.8</td><td>44.1</td><td>40.0</td><td>-</td><td>39.9</td></tr><tr><td>CONSE(原文未明确含义，保留原文) [26]</td><td>26.9</td><td>45.6</td><td>34.3</td><td>-</td><td>38.8</td></tr><tr><td>语义自编码器(SSE) [38]</td><td>34.0</td><td>60.1</td><td>43.9</td><td>-</td><td>51.5</td></tr><tr><td>DeViSE(原文未明确含义，保留原文) [7]</td><td>39.8</td><td>54.2</td><td>52.0</td><td>45.9</td><td>56.5</td></tr><tr><td>结构化联合嵌入(SJE) [2]</td><td>32.9</td><td>65.6</td><td>53.9</td><td>53.4</td><td>53.7</td></tr><tr><td>ESZSL(原文未明确含义，保留原文) [29]</td><td>38.3</td><td>58.2</td><td>53.9</td><td>51.0</td><td>54.5</td></tr><tr><td>ALE(原文未明确含义，保留原文) [1]</td><td>39.7</td><td>59.9</td><td>54.9</td><td>48.5</td><td>58.1</td></tr><tr><td>SYNC(原文未明确含义，保留原文) [4]</td><td>23.9</td><td>54.0</td><td>55.6</td><td>-</td><td>56.3</td></tr><tr><td>堆叠自编码器(SAE) [13]</td><td>8.3</td><td>53.0</td><td>33.3</td><td>-</td><td>40.3</td></tr><tr><td>DEM(原文未明确含义，保留原文) [37]</td><td>35.0</td><td>68.4</td><td>51.7</td><td>-</td><td>61.9</td></tr><tr><td>GAZSL(原文未明确含义，保留原文) [40]</td><td>41.1</td><td>68.2</td><td>55.8</td><td>60.5</td><td>61.3</td></tr><tr><td>f - 条件标签生成对抗网络(f - CLSWGAN) [34]</td><td>40.5</td><td>68.2</td><td>57.3</td><td>67.2</td><td>60.8</td></tr><tr><td>我们的LisGAN</td><td>43.1</td><td>70.6</td><td>58.8</td><td>69.6</td><td>61.7</td></tr></tbody></table>

Table 3. The results (top-1 accuracy %) of generalized zero-shot learning on aPaY dataset. The Mean in this table is the harmonic mean of seen and unseen samples, i.e., Mean=(2*Unseen*Seen)/(Unseen+Seen).

表3. 在aPaY数据集上广义零样本学习的结果(前1准确率 %)。此表中的均值是已见样本和未见样本的调和均值，即均值 = (2 * 未见样本准确率 * 已见样本准确率) / (未见样本准确率 + 已见样本准确率)。

<table><tr><td rowspan="2">Methods</td><td colspan="3">aPaY</td></tr><tr><td>Unseen</td><td>Seen</td><td>Mean</td></tr><tr><td>DAP [15]</td><td>4.8</td><td>78.3</td><td>9.0</td></tr><tr><td>CONSE [26]</td><td>0.0</td><td>91.2</td><td>0.0</td></tr><tr><td>SSE [38]</td><td>0.2</td><td>78.9</td><td>0.4</td></tr><tr><td>DeViSE [7]</td><td>4.9</td><td>76.9</td><td>9.2</td></tr><tr><td>SJE [2]</td><td>3.7</td><td>55.7</td><td>6.9</td></tr><tr><td>ESZSL [29]</td><td>2.4</td><td>70.1</td><td>4.6</td></tr><tr><td>ALE [1]</td><td>4.6</td><td>73.7</td><td>8.7</td></tr><tr><td>SYNC [4]</td><td>7.4</td><td>66.3</td><td>13.3</td></tr><tr><td>SAE [13]</td><td>0.4</td><td>80.9</td><td>0.9</td></tr><tr><td>DEM [37]</td><td>11.1</td><td>75.1</td><td>19.4</td></tr><tr><td>GAZSL [40]</td><td>14.2</td><td>78.6</td><td>24.0</td></tr><tr><td>f-CLSWGAN [34]</td><td>32.9</td><td>61.7</td><td>42.9</td></tr><tr><td>LisGAN [Ours]</td><td>34.3</td><td>68.2</td><td>45.7</td></tr></table>

<table><tbody><tr><td rowspan="2">方法</td><td colspan="3">aPaY</td></tr><tr><td>未见的</td><td>已见的</td><td>均值</td></tr><tr><td>判别式属性投影(DAP) [15]</td><td>4.8</td><td>78.3</td><td>9.0</td></tr><tr><td>基于一致性的语义嵌入(CONSE) [26]</td><td>0.0</td><td>91.2</td><td>0.0</td></tr><tr><td>半监督嵌入(SSE) [38]</td><td>0.2</td><td>78.9</td><td>0.4</td></tr><tr><td>深度视觉语义嵌入(DeViSE) [7]</td><td>4.9</td><td>76.9</td><td>9.2</td></tr><tr><td>语义联合嵌入(SJE) [2]</td><td>3.7</td><td>55.7</td><td>6.9</td></tr><tr><td>端到端零样本学习(ESZSL) [29]</td><td>2.4</td><td>70.1</td><td>4.6</td></tr><tr><td>对抗学习嵌入(ALE) [1]</td><td>4.6</td><td>73.7</td><td>8.7</td></tr><tr><td>同步嵌入(SYNC) [4]</td><td>7.4</td><td>66.3</td><td>13.3</td></tr><tr><td>堆叠自编码器(SAE) [13]</td><td>0.4</td><td>80.9</td><td>0.9</td></tr><tr><td>判别式嵌入模型(DEM) [37]</td><td>11.1</td><td>75.1</td><td>19.4</td></tr><tr><td>生成式零样本学习(GAZSL) [40]</td><td>14.2</td><td>78.6</td><td>24.0</td></tr><tr><td>特征分类器生成对抗网络(f - CLSWGAN) [34]</td><td>32.9</td><td>61.7</td><td>42.9</td></tr><tr><td>列表生成对抗网络(LisGAN)[我们的方法]</td><td>34.3</td><td>68.2</td><td>45.7</td></tr></tbody></table>

Following previous work $\left\lbrack  {{34},{40}}\right\rbrack$ , we report the average per-class top-1 accuracy for each of the evaluated method. Specifically, for classic zero-shot learning, we report the top-1 accuracy of unseen samples by only searching the unseen label space. However, for the generalized zero-shot learning, we report the accuracy on both seen classes and unseen classes with the same settings in [35]. Some of the results reported in this paper are also cited from [35].

根据先前的工作 $\left\lbrack  {{34},{40}}\right\rbrack$，我们报告了每种评估方法的平均每类前1准确率。具体而言，对于经典的零样本学习，我们仅通过搜索未见标签空间来报告未见样本的前1准确率。然而，对于广义零样本学习，我们按照文献[35]中的相同设置报告了可见类和未见类的准确率。本文报告的一些结果也引用自文献[35]。

### 4.3. Zero-shot Learning

### 4.3. 零样本学习

We report the zero-shot learning results on the five datasets in Table 2. In these experiments, the possible categories of unseen samples are searched from only ${Y}_{u}$ . It can be seen that our method achieves the best on four of the five evaluations. We also achieved state-of-the-art result on the last dataset. Specifically, we achieved ${2.6}\%$ improvement over the state-of-the-art method on aPaY dataset. We also achieved 2.4%, 1.5% and 2.4% on AWA, CUB and FLO.

我们在表2中报告了在五个数据集上的零样本学习结果。在这些实验中，未见样本的可能类别仅从 ${Y}_{u}$ 中搜索。可以看出，我们的方法在五项评估中的四项中取得了最佳效果。我们在最后一个数据集上也取得了最先进的结果。具体而言，在aPaY数据集上，我们比最先进的方法提高了 ${2.6}\%$。我们在AWA、CUB和FLO数据集上也分别取得了2.4%、1.5%和2.4%的提升。

![0195e05a-b157-797d-a35b-5773a73e3543_5_903_210_682_349_0.jpg](images/0195e05a-b157-797d-a35b-5773a73e3543_5_903_210_682_349_0.jpg)

Figure 4. The confusion matrix on the evaluation of aPaY dataset.

图4. aPaY数据集评估的混淆矩阵。

From the results, we can also observe that the GAN-based methods, e.g., GAZSL, f-CLSWGAN and ours, generally perform better than embedding ones, e.g., SSE, ALE and SAE. The embedding methods handle the unseen samples via an indirect manner, while the GAN method directly handle it by converting it to a supervised learning task. The results suggest that GAN could be a promising way to address zero-shot learning problem in the future. Apart from generating visual features from noises, GANs can also be used for semantic augmentation in zero-shot learning. In our future work, we will incorporate semantic data augmentation in our model to cover more unseen samples.

从结果中我们还可以观察到，基于生成对抗网络(GAN)的方法，如GAZSL、f - CLSWGAN和我们的方法，通常比嵌入方法，如SSE、ALE和SAE表现更好。嵌入方法通过间接方式处理未见样本，而GAN方法通过将其转换为有监督学习任务直接处理。结果表明，GAN可能是未来解决零样本学习问题的一种有前途的方法。除了从噪声中生成视觉特征外，GAN还可用于零样本学习中的语义增强。在我们未来的工作中，我们将在模型中纳入语义数据增强，以覆盖更多未见样本。

### 4.4. Generalized Zero-shot Learning

### 4.4. 广义零样本学习

We further report the experiment results of generalized zero-shot learning in Table 3 and Table 4. Table 3 shows the results on aPaY dataset and Table 4 shows the results on the other 4 datasets. In generalized zero-shot learning, the seen classes are split into two parts: one for training and the other for test. At the test stage, both seen and unseen samples are recognized by searching the possible categories from $Y \cup  {Y}_{u}$ . The splits of seen classes can be seen in Table 1 and more details can be found in previous work [35]. Since both seen and unseen classes are tested in generalized zero-shot learning, we also report the harmonic mean of seen accuracy and unseen accuracy in the tables.

我们进一步在表3和表4中报告了广义零样本学习的实验结果。表3显示了在aPaY数据集上的结果，表4显示了在其他4个数据集上的结果。在广义零样本学习中，可见类被分为两部分:一部分用于训练，另一部分用于测试。在测试阶段，通过从 $Y \cup  {Y}_{u}$ 中搜索可能的类别来识别可见和未见样本。可见类的划分可以在表1中看到，更多细节可以在先前的工作[35]中找到。由于在广义零样本学习中同时测试了可见类和未见类，我们还在表中报告了可见准确率和未见准确率的调和均值。

From the results in Table 3 and Table 4, we can draw the similar conclusions as from Table 2. Our approach performs better than existing methods. Our results are significantly better on the unseen samples and harmonic mean, which means our proposed method has a much better generalized ability. It is able to classify the samples into the true category. Our approach is stably dependable on both seen and unseen classes. Although some previous methods, e.g., DAP, ESZSL and SAE, perform well on the conventional zero-shot learning setting with unseen samples, their performances degrade dramatically on the generalized zero-shot learning. They tend to mess up when the possible categories of unseen samples become large. Thus, the applicability of these methods is limited in real applications.

从表3和表4的结果中，我们可以得出与表2类似的结论。我们的方法比现有方法表现更好。我们在未见样本和调和均值上的结果明显更好，这意味着我们提出的方法具有更好的泛化能力。它能够将样本分类到真实类别中。我们的方法在可见类和未见类上都稳定可靠。虽然一些先前的方法，如DAP、ESZSL和SAE，在传统的未见样本零样本学习设置中表现良好，但它们在广义零样本学习中的性能急剧下降。当未见样本的可能类别变多时，它们往往会混淆。因此，这些方法在实际应用中的适用性有限。

The harmonic mean is more stable regarding outliers than the arithmetic mean and geometric mean. Thus, from the results reported in Table 3 and Table 4, we can also observe that our method is more stable than the compared methods. It avoids extreme results on different evaluations. In terms of the harmonic mean, we achieved up to 2.8%, ${2.7}\% ,{1.9}\% ,{2.7}\%$ and ${0.8}\%$ improvements on aPaY, AwA, CUB, FLO and SUN, respectively. The average is over the five is ${2.2}\%$ . Although our method did not perform the best on some seen categories, it performs almost neck to neck with the previous state-of-the-arts. These results verified the outstanding generalization ability of our method.

调和均值在处理离群值方面比算术均值和几何均值更稳定。因此，从表3和表4报告的结果中，我们还可以观察到我们的方法比对比方法更稳定。它避免了在不同评估中出现极端结果。在调和均值方面，我们在aPaY、AwA、CUB、FLO和SUN数据集上分别取得了高达2.8%、${2.7}\% ,{1.9}\% ,{2.7}\%$ 和 ${0.8}\%$ 的提升。五项的平均值为 ${2.2}\%$。虽然我们的方法在一些可见类别上没有表现出最佳效果，但它与先前的最先进方法几乎不相上下。这些结果验证了我们方法出色的泛化能力。

Table 4. The results (top-1 accuracy %) of generalized zero-shot learning. The Mean in this table is the harmonic mean of seen and unseen samples, i.e., Mean=(2*Unseen*Seen)/(Unseen+Seen). The best results are highlighted with bold numbers.

表4. 广义零样本学习的结果(前1准确率 %)。本表中的均值是可见和未见样本的调和均值，即均值 = (2 * 未见准确率 * 可见准确率) / (未见准确率 + 可见准确率)。最佳结果用粗体数字突出显示。

<table><tr><td rowspan="2">Methods</td><td colspan="3">AwA</td><td colspan="3">CUB</td><td colspan="3">FLO</td><td colspan="3">SUN</td></tr><tr><td>Unseen</td><td>Seen</td><td>Mean</td><td>Unseen</td><td>Seen</td><td>Mean</td><td>Unseen</td><td>Seen</td><td>Mean</td><td>Unseen</td><td>Seen</td><td>Mean</td></tr><tr><td>DAP [15]</td><td>0.0</td><td>88.7</td><td>0.0</td><td>1.7</td><td>67.9</td><td>3.3</td><td>-</td><td>-</td><td>-</td><td>4.2</td><td>25.2</td><td>7.2</td></tr><tr><td>CONSE [26]</td><td>0.4</td><td>88.6</td><td>0.8</td><td>1.6</td><td>72.2</td><td>3.1</td><td>-</td><td>-</td><td>-</td><td>6.8</td><td>39.9</td><td>11.6</td></tr><tr><td>SSE [38]</td><td>7.0</td><td>80.5</td><td>12.9</td><td>8.5</td><td>46.9</td><td>14.4</td><td>-</td><td>-</td><td>-</td><td>2.1</td><td>36.4</td><td>4.0</td></tr><tr><td>DeViSE [7]</td><td>13.4</td><td>68.7</td><td>22.4</td><td>23.8</td><td>53.0</td><td>32.8</td><td>9.9</td><td>44.2</td><td>16.2</td><td>16.9</td><td>27.4</td><td>20.9</td></tr><tr><td>SJE [2]</td><td>11.3</td><td>74.6</td><td>19.6</td><td>23.5</td><td>59.2</td><td>33.6</td><td>13.9</td><td>47.6</td><td>21.5</td><td>14.7</td><td>30.5</td><td>19.8</td></tr><tr><td>ESZSL [29]</td><td>5.9</td><td>77.8</td><td>11.0</td><td>2.4</td><td>70.1</td><td>4.6</td><td>11.4</td><td>56.8</td><td>19.0</td><td>11.0</td><td>27.9</td><td>15.8</td></tr><tr><td>ALE [1]</td><td>14.0</td><td>81.8</td><td>23.9</td><td>4.6</td><td>73.7</td><td>8.7</td><td>13.3</td><td>61.6</td><td>21.9</td><td>21.8</td><td>33.1</td><td>26.3</td></tr><tr><td>SYNC [4]</td><td>10.0</td><td>90.5</td><td>18.0</td><td>7.4</td><td>66.3</td><td>13.3</td><td>-</td><td>-</td><td>-</td><td>7.9</td><td>43.3</td><td>13.4</td></tr><tr><td>SAE [13]</td><td>1.1</td><td>82.2</td><td>2.2</td><td>0.4</td><td>80.9</td><td>0.9</td><td>-</td><td>-</td><td>-</td><td>8.8</td><td>18.0</td><td>11.8</td></tr><tr><td>DEM [37]</td><td>30.5</td><td>86.4</td><td>45.1</td><td>11.1</td><td>75.1</td><td>19.4</td><td>-</td><td>-</td><td>-</td><td>20.5</td><td>34.3</td><td>25.6</td></tr><tr><td>GAZSL [40]</td><td>19.2</td><td>86.5</td><td>31.4</td><td>23.9</td><td>60.6</td><td>34.3</td><td>28.1</td><td>77.4</td><td>41.2</td><td>21.7</td><td>34.5</td><td>26.7</td></tr><tr><td>f-CLSWGAN [34]</td><td>57.9</td><td>61.4</td><td>59.6</td><td>43.7</td><td>57.7</td><td>49.7</td><td>59.0</td><td>73.8</td><td>65.6</td><td>42.6</td><td>36.6</td><td>39.4</td></tr><tr><td>LisGAN [Ours]</td><td>52.6</td><td>76.3</td><td>62.3</td><td>46.5</td><td>57.9</td><td>51.6</td><td>57.7</td><td>83.8</td><td>68.3</td><td>42.9</td><td>37.8</td><td>40.2</td></tr></table>

<table><tbody><tr><td rowspan="2">方法</td><td colspan="3">AwA(动物属性数据集)</td><td colspan="3">CUB(加州大学伯克利分校鸟类数据集)</td><td colspan="3">FLO(花卉数据集)</td><td colspan="3">SUN(场景理解数据集)</td></tr><tr><td>未见类别</td><td>已见类别</td><td>均值</td><td>未见类别</td><td>已见类别</td><td>均值</td><td>未见类别</td><td>已见类别</td><td>均值</td><td>未见类别</td><td>已见类别</td><td>均值</td></tr><tr><td>判别式属性投影法 [15]</td><td>0.0</td><td>88.7</td><td>0.0</td><td>1.7</td><td>67.9</td><td>3.3</td><td>-</td><td>-</td><td>-</td><td>4.2</td><td>25.2</td><td>7.2</td></tr><tr><td>一致性嵌入法 [26]</td><td>0.4</td><td>88.6</td><td>0.8</td><td>1.6</td><td>72.2</td><td>3.1</td><td>-</td><td>-</td><td>-</td><td>6.8</td><td>39.9</td><td>11.6</td></tr><tr><td>半监督嵌入法 [38]</td><td>7.0</td><td>80.5</td><td>12.9</td><td>8.5</td><td>46.9</td><td>14.4</td><td>-</td><td>-</td><td>-</td><td>2.1</td><td>36.4</td><td>4.0</td></tr><tr><td>深度视觉语义嵌入法 [7]</td><td>13.4</td><td>68.7</td><td>22.4</td><td>23.8</td><td>53.0</td><td>32.8</td><td>9.9</td><td>44.2</td><td>16.2</td><td>16.9</td><td>27.4</td><td>20.9</td></tr><tr><td>结构化联合嵌入法 [2]</td><td>11.3</td><td>74.6</td><td>19.6</td><td>23.5</td><td>59.2</td><td>33.6</td><td>13.9</td><td>47.6</td><td>21.5</td><td>14.7</td><td>30.5</td><td>19.8</td></tr><tr><td>高效零样本学习法 [29]</td><td>5.9</td><td>77.8</td><td>11.0</td><td>2.4</td><td>70.1</td><td>4.6</td><td>11.4</td><td>56.8</td><td>19.0</td><td>11.0</td><td>27.9</td><td>15.8</td></tr><tr><td>属性标签嵌入法 [1]</td><td>14.0</td><td>81.8</td><td>23.9</td><td>4.6</td><td>73.7</td><td>8.7</td><td>13.3</td><td>61.6</td><td>21.9</td><td>21.8</td><td>33.1</td><td>26.3</td></tr><tr><td>同步嵌入法 [4]</td><td>10.0</td><td>90.5</td><td>18.0</td><td>7.4</td><td>66.3</td><td>13.3</td><td>-</td><td>-</td><td>-</td><td>7.9</td><td>43.3</td><td>13.4</td></tr><tr><td>堆叠自动编码器法 [13]</td><td>1.1</td><td>82.2</td><td>2.2</td><td>0.4</td><td>80.9</td><td>0.9</td><td>-</td><td>-</td><td>-</td><td>8.8</td><td>18.0</td><td>11.8</td></tr><tr><td>判别式嵌入匹配法 [37]</td><td>30.5</td><td>86.4</td><td>45.1</td><td>11.1</td><td>75.1</td><td>19.4</td><td>-</td><td>-</td><td>-</td><td>20.5</td><td>34.3</td><td>25.6</td></tr><tr><td>广义零样本学习生成对抗网络法 [40]</td><td>19.2</td><td>86.5</td><td>31.4</td><td>23.9</td><td>60.6</td><td>34.3</td><td>28.1</td><td>77.4</td><td>41.2</td><td>21.7</td><td>34.5</td><td>26.7</td></tr><tr><td>特征分类器生成对抗网络法 [34]</td><td>57.9</td><td>61.4</td><td>59.6</td><td>43.7</td><td>57.7</td><td>49.7</td><td>59.0</td><td>73.8</td><td>65.6</td><td>42.6</td><td>36.6</td><td>39.4</td></tr><tr><td>LisGAN(我们的方法)</td><td>52.6</td><td>76.3</td><td>62.3</td><td>46.5</td><td>57.9</td><td>51.6</td><td>57.7</td><td>83.8</td><td>68.3</td><td>42.9</td><td>37.8</td><td>40.2</td></tr></tbody></table>

Considering the fact that both GAZSL and f-CLSWGAN leverage GANs to synthesize unseen samples, the performance boost of our method can be attributed to two aspects. One is that we introduce soul samples to guarantee that each generated sample is highly related with the semantic description. The soul samples regularizations also address the multi-view characteristic. As a result, it can automatically take care of the domain-shift problem caused by different views in zero-shot learning. The other aspect is that our cascade classifier is able to leverage the results from the first classifier and strengthen the second one. Such a formulation provides the results via a coarse-to-fine manner. The results verify that it is beneficial to leverage the invariant side of generative ZSL. The invariant side regularizations guarantee that each synthesized sample is highly related with the real ones and corresponding semantic descriptions.

考虑到GAZSL和f - CLSWGAN都利用生成对抗网络(GANs)来合成未见样本这一事实，我们方法的性能提升可归因于两个方面。一是我们引入了核心样本(soul samples)，以确保每个生成的样本都与语义描述高度相关。核心样本正则化还解决了多视图特征问题。因此，它可以自动处理零样本学习中由不同视图引起的领域偏移问题。另一方面，我们的级联分类器能够利用第一个分类器的结果来强化第二个分类器。这种形式以由粗到细的方式得出结果。结果证实，利用生成式零样本学习(ZSL)的不变性方面是有益的。不变性方面的正则化确保每个合成样本都与真实样本以及相应的语义描述高度相关。

### 4.5. Model Analysis

### 4.5. 模型分析

In this section, we analyze our model under different settings. Since our GAN generates visual features rather than image pixels, it is inappropriate to show the synthesized results with images. We will analyze our model in terms of the generalization ability and stability. The sensitivity of hyper-parameters are also discussed.

在本节中，我们将在不同设置下分析我们的模型。由于我们的生成对抗网络生成的是视觉特征而非图像像素，因此用图像展示合成结果并不合适。我们将从泛化能力和稳定性方面分析我们的模型。还将讨论超参数的敏感性。

#### 4.5.1 Class-wise Accuracy

#### 4.5.1 类别准确率

To show the experimental results of our method in a more fine-grained scale, we report the confusion matrix of f-CLSGAN and our method on the aPaY dataset in Fig. 4. Compared with Fig. 4(a) and Fig. 4(b), we can see that our method generally has better accuracy on most of the categories. Notably, we can see that the accuracy on category "tvmonitor", "donkey" and "jetski" are boosted around 10% against f-CLSWGAN. There is also a common phenomenon that the ZSL methods perform poorly on some unseen categories. We will investigate fine-grained / classwise zero-shot learning in our future work.

为了更细粒度地展示我们方法的实验结果，我们在图4中报告了f - CLSGAN和我们的方法在aPaY数据集上的混淆矩阵。对比图4(a)和图4(b)，我们可以看到我们的方法在大多数类别上通常具有更高的准确率。值得注意的是，我们可以看到在“电视监视器(tvmonitor)”、“驴(donkey)”和“喷气式滑水艇(jetski)”类别上，与f - CLSWGAN相比，准确率提高了约10%。还有一个常见现象是，零样本学习方法在一些未见类别上表现不佳。我们将在未来的工作中研究细粒度/按类别零样本学习。

#### 4.5.2 Parameter Sensitivity

#### 4.5.2 参数敏感性

In our model, we have several hype-parameters to tune. The parameter $\beta$ controls the Lipschitz constraint. As suggested in [9], we fix $\beta  = {10}$ in this paper. The parameter $\lambda$ balances the supervised classification loss, its influence is reported in Fig. 5(a). In our formulation, we also introduced a weight coefficient to adjust the contribution of soul sample regularizations. Its sensitivity is reported in Fig. 5(b). Similarly, Fig. 5(c) and Fig. 5(d) show the effects of sample entropy threshold and synthesized sample numbers per class, respectively. From the results, we can see that the weight parameters for classification loss and soul sample regularization should be relatively small. The sample entropy threshold is recommended to set to be smaller than the median of all samples. The more synthesized samples, the better results generally there will be. However, more samples also introduce more noises and need more training costs. In practice, we suggest to split the seen categories as training set and validation set for cross-validation. Specifically. we report the sensitivity of $k$ in Fig. 7(a). Since $k$ is not sensitive, we fix $k = 3$ to reduce the computation cost.

在我们的模型中，有几个超参数需要调整。参数 $\beta$ 控制利普希茨约束。正如文献[9]所建议的，我们在本文中固定 $\beta  = {10}$。参数 $\lambda$ 平衡有监督分类损失，其影响如图5(a)所示。在我们的公式中，我们还引入了一个权重系数来调整核心样本正则化的贡献。其敏感性如图5(b)所示。类似地，图5(c)和图5(d)分别显示了样本熵阈值和每类合成样本数量的影响。从结果中我们可以看到，分类损失和核心样本正则化的权重参数应该相对较小。建议将样本熵阈值设置为小于所有样本的中位数。一般来说，合成样本越多，结果越好。然而，更多的样本也会引入更多的噪声，并且需要更多的训练成本。在实践中，我们建议将可见类别划分为训练集和验证集进行交叉验证。具体来说，我们在图7(a)中报告了 $k$ 的敏感性。由于 $k$ 不敏感，我们固定 $k = 3$ 以降低计算成本。

![0195e05a-b157-797d-a35b-5773a73e3543_7_169_211_1413_325_0.jpg](images/0195e05a-b157-797d-a35b-5773a73e3543_7_169_211_1413_325_0.jpg)

Figure 5. Parameter sensitivity. The horizontal axis of (c) indicates the sample entropy threshold is not larger than the entropy of $x\%$ samples where all sample entropies are sorted from small to large., e.g., 50 indicates the sample entropy threshold is set as the median of all sample entropies. The horizontal axis of (d) indicates synthesized sample numbers per class.

图5. 参数敏感性。(c)的横轴表示样本熵阈值不大于 $x\%$ 个样本的熵，其中所有样本熵按从小到大排序，例如，50表示样本熵阈值设置为所有样本熵的中位数。(d)的横轴表示每类合成样本的数量。

![0195e05a-b157-797d-a35b-5773a73e3543_7_151_677_688_286_0.jpg](images/0195e05a-b157-797d-a35b-5773a73e3543_7_151_677_688_286_0.jpg)

Figure 6. The trends of training stability. For GZSL in (b), we report the harmonic mean on both seen and unseen samples.

图6. 训练稳定性趋势。对于(b)中的广义零样本学习(GZSL)，我们报告了可见和未见样本的调和均值。

![0195e05a-b157-797d-a35b-5773a73e3543_7_163_1056_652_241_0.jpg](images/0195e05a-b157-797d-a35b-5773a73e3543_7_163_1056_652_241_0.jpg)

Figure 7. The results of different $k$ (number of clusters) and ablation analysis of ZSL with aPaY.

图7. 不同 $k$(聚类数量)的结果以及aPaY数据集上零样本学习的消融分析。

#### 4.5.3 Model Stability

#### 4.5.3 模型稳定性

Since our approach deploys an adversarial training manner, it needs several epochs to achieve the balance between the generator and the discriminator. In Fig. 6, we report the zero-shot learning and generalized zero-shot learning results of our method with different epochs in terms of testing error. The results reflect the training stability of our model. It can be seen that our model shows a stable training trend with the increasing of training epochs. Although there are small fluctuations, our model can achieve a stable results with 30 epochs. For different real-world applications, one can deploy cross-validation to choose the optimal epoch.

由于我们的方法采用对抗训练方式，需要几个训练轮次(epochs)才能在生成器和判别器之间达到平衡。在图6中，我们报告了我们的方法在不同训练轮次下的零样本学习和广义零样本学习的测试误差结果。这些结果反映了我们模型的训练稳定性。可以看出，随着训练轮次的增加，我们的模型呈现出稳定的训练趋势。虽然有小的波动，但我们的模型在30个训练轮次后可以达到稳定的结果。对于不同的实际应用，可以采用交叉验证来选择最佳的训练轮次。

#### 4.5.4 Ablation Analysis

#### 4.5.4 消融分析

Conditional WGAN has been a cutting-edge but popular technique in computer vision tasks. It is more like an infrastructure in the community. Thus, we fix the conditional WGAN and focus on soul sample regularization and the cascade classifier in this section. We first report the results of plain conditional WGAN. Then, we introduce additional components into the model and observe the effects of them. The results of ablation analysis are reported in Fig. 7(b). The five settings demonstrate that different components in our framework are all significant. The supervised loss guarantees that the generated features are discriminative. The soul samples regularizations constrain that each synthesized sample is close to the very semantic descriptions. Multiple soul samples per class provide a relaxed solution to handle domain shit problem caused by the multi-view issue. The cascade classifier leverages the result of sample entropy and presents a more fine accuracy.

条件生成对抗网络(Conditional WGAN)在计算机视觉任务中是一种前沿且流行的技术。它更像是该领域的一种基础架构。因此，在本节中，我们固定条件生成对抗网络，重点关注灵魂样本正则化和级联分类器。我们首先报告普通条件生成对抗网络的结果。然后，我们将额外的组件引入模型并观察它们的效果。消融分析的结果如图7(b)所示。这五种设置表明我们框架中的不同组件都很重要。监督损失确保生成的特征具有区分性。灵魂样本正则化约束每个合成样本接近其语义描述。每个类别多个灵魂样本为处理由多视图问题引起的领域偏移问题提供了一种宽松的解决方案。级联分类器利用样本熵的结果并呈现出更精细的准确率。

## 5. Conclusion

## 5. 结论

In this paper, we propose a novel zero-shot learning method by taking advantage of generative adversarial networks. Specially, we deploy conditional WGAN to synthesize fake unseen samples from random noises. To guarantee that each generated sample is close to real ones and their corresponding semantic descriptions, we introduce soul samples regularizations in the GAN generator. At the zero-shot recognition stage, we further propose to use a cascade classifier to fine-tune the accuracy. Extensive experiments on five popular benchmarks verified that our method can outperform previous state-of-the-art ones with remarkable advances. In our future work, we will explore data augmentation with GAN which can be used to synthesize more semantic descriptions to cover more unseen samples.

在本文中，我们利用生成对抗网络提出了一种新颖的零样本学习方法。具体来说，我们部署条件生成对抗网络从随机噪声中合成未见类别的虚假样本。为了确保每个生成的样本接近真实样本及其对应的语义描述，我们在生成对抗网络的生成器中引入了灵魂样本正则化。在零样本识别阶段，我们进一步提出使用级联分类器来微调准确率。在五个流行基准数据集上的大量实验验证了我们的方法能够显著优于先前的最先进方法。在未来的工作中，我们将探索使用生成对抗网络进行数据增强，以合成更多的语义描述来覆盖更多未见类别的样本。

## Acknowledgments

## 致谢

This work was supported in part by the National Natural Science Foundation of China under Grant 61806039, 61832001, 61802236, 61572108 and 61632007, in part by the ARC under Grant FT130101530, in part by the National Postdoctoral Program for Innovative Talents under Grant BX201700045, and in part by the China Postdoctoral Science Foundation under Grant 2017M623006.

本工作部分得到了国家自然科学基金(项目编号:61806039、61832001、61802236、61572108和61632007)的资助，部分得到了澳大利亚研究委员会(ARC)资助(项目编号:FT130101530)，部分得到了国家博士后创新人才支持计划(项目编号:BX201700045)的资助，部分得到了中国博士后科学基金(项目编号:2017M623006)的资助。

## References

## 参考文献

[1] Zeynep Akata, Florent Perronnin, Zaid Harchaoui, and Cordelia Schmid. Label-embedding for image classification. IEEE TPAMI, 38(7):1425-1438, 2016.

[1] Zeynep Akata，Florent Perronnin，Zaid Harchaoui和Cordelia Schmid。用于图像分类的标签嵌入。《IEEE模式分析与机器智能汇刊》(IEEE TPAMI)，38(7):1425 - 1438，2016。

[2] Zeynep Akata, Scott Reed, Daniel Walter, Honglak Lee, and Bernt Schiele. Evaluation of output embeddings for fine-grained image classification. In CVPR, pages 2927-2936, 2015.

[2] Zeynep Akata，Scott Reed，Daniel Walter，Honglak Lee和Bernt Schiele。细粒度图像分类输出嵌入的评估。《计算机视觉与模式识别会议》(CVPR)，第2927 - 2936页，2015。

[3] Martin Arjovsky, Soumith Chintala, and Léon Bottou. Wasserstein generative adversarial networks. In ${ICML}$ , pages 214-223, 2017.

[3] Martin Arjovsky，Soumith Chintala和Léon Bottou。Wasserstein生成对抗网络。《${ICML}$》，第214 - 223页，2017。

[4] Soravit Changpinyo, Wei-Lun Chao, Boqing Gong, and Fei Sha. Synthesized classifiers for zero-shot learning. In CVPR, pages 5327-5336, 2016.

[4] Soravit Changpinyo，Wei - Lun Chao，Boqing Gong和Fei Sha。用于零样本学习的合成分类器。《计算机视觉与模式识别会议》(CVPR)，第5327 - 5336页，2016。

[5] Zhengming Ding, Ming Shao, and Yun Fu. Low-rank embedded ensemble semantic dictionary for zero-shot learning. In ${CVPR}$ . IEEE, 2017.

[5] 丁正明，邵明和傅云。用于零样本学习的低秩嵌入集成语义字典。《${CVPR}$》。IEEE，2017。

[6] Zhengming Ding, Ming Shao, and Yun Fu. Generative zero-shot learning via low-rank embedded semantic dictionary. IEEE TPAMI, 2018.

[6] 丁正明，邵明和傅云。通过低秩嵌入语义字典进行生成式零样本学习。《IEEE模式分析与机器智能汇刊》(IEEE TPAMI)，2018。

[7] Andrea Frome, Greg S Corrado, Jon Shlens, Samy Bengio, Jeff Dean, Tomas Mikolov, et al. Devise: A deep visual-semantic embedding model. In NIPS, pages 2121-2129, 2013.

[7] Andrea Frome，Greg S Corrado，Jon Shlens，Samy Bengio，Jeff Dean，Tomas Mikolov等。Devise:一种深度视觉 - 语义嵌入模型。《神经信息处理系统大会》(NIPS)，第2121 - 2129页，2013。

[8] Ian Goodfellow, Jean Pouget-Abadie, Mehdi Mirza, Bing Xu, David Warde-Farley, Sherjil Ozair, Aaron Courville, and Yoshua Bengio. Generative adversarial nets. In NIPS, pages 2672-2680, 2014.

[8] Ian Goodfellow，Jean Pouget - Abadie，Mehdi Mirza，Bing Xu，David Warde - Farley，Sherjil Ozair，Aaron Courville和Yoshua Bengio。生成对抗网络。《神经信息处理系统大会》(NIPS)，第2672 - 2680页，2014。

[9] Ishaan Gulrajani, Faruk Ahmed, Martin Arjovsky, Vincent Dumoulin, and Aaron C Courville. Improved training of wasserstein gans. In NIPS, pages 5767-5777, 2017.

[9] Ishaan Gulrajani，Faruk Ahmed，Martin Arjovsky，Vincent Dumoulin和Aaron C Courville。改进的Wasserstein生成对抗网络训练。《神经信息处理系统大会》(NIPS)，第5767 - 5777页，2017。

[10] Kaiming He, Xiangyu Zhang, Shaoqing Ren, and Jian Sun. Deep residual learning for image recognition. In CVPR, pages 770-778, 2016.

[10] 何恺明，张祥雨，任少卿和孙剑。用于图像识别的深度残差学习。《计算机视觉与模式识别会议》(CVPR)，第770 - 778页，2016。

[11] Huajie Jiang, Ruiping Wang, Shiguang Shan, Yi Yang, and Xilin Chen. Learning discriminative latent attributes for zero-shot classification. In ${ICCV}$ , pages ${4223} - {4232}$ ,2017.

[11] 蒋华杰、王瑞平、单世广、杨易和陈熙霖。为零样本分类学习判别性潜在属性。发表于 ${ICCV}$ ，第 ${4223} - {4232}$ 页，2017年。

[12] Elyor Kodirov, Tao Xiang, Zhenyong Fu, and Shaogang Gong. Unsupervised domain adaptation for zero-shot learning. In ${ICCV}$ , pages 2452-2460,2015.

[12] 埃利奥尔·科迪罗夫、向涛、傅振勇和龚少刚。零样本学习的无监督领域自适应。发表于 ${ICCV}$ ，第2452 - 2460页，2015年。

[13] Elyor Kodirov, Tao Xiang, and Shaogang Gong. Semantic autoencoder for zero-shot learning. arXiv preprint arXiv:1704.08345, 2017.

[13] 埃利奥尔·科迪罗夫、向涛和龚少刚。用于零样本学习的语义自编码器。预印本arXiv:1704.08345，2017年。

[14] Christoph H Lampert, Hannes Nickisch, and Stefan Harmel-ing. Learning to detect unseen object classes by between-class attribute transfer. In CVPR, pages 951-958. IEEE, 2009.

[14] 克里斯托夫·H·兰佩特、汉斯·尼克isch和斯特凡·哈梅林。通过类间属性转移学习检测未见物体类别。发表于计算机视觉与模式识别会议(CVPR)，第951 - 958页。电气与电子工程师协会(IEEE)，2009年。

[15] Christoph H Lampert, Hannes Nickisch, and Stefan Harmel-ing. Attribute-based classification for zero-shot visual object categorization. IEEE TPAMI, 36(3):453-465, 2014.

[15] 克里斯托夫·H·兰佩特、汉斯·尼克isch和斯特凡·哈梅林。基于属性的分类用于零样本视觉物体分类。《电气与电子工程师协会模式分析与机器智能汇刊》(IEEE TPAMI)，36(3):453 - 465，2014年。

[16] Jimmy Lei Ba, Kevin Swersky, Sanja Fidler, et al. Predicting deep zero-shot convolutional neural networks using textual descriptions. In ${ICCV}$ , pages ${4247} - {4255},{2015}$ .

[16] 吉米·雷·巴、凯文·斯沃尔斯基、桑贾·菲德勒等。使用文本描述预测深度零样本卷积神经网络。发表于 ${ICCV}$ ，第 ${4247} - {4255},{2015}$ 页。

[17] Jingjing Li, Mengmeng Jing, Ke Lu, Lei Zhu, Yang Yang, and Zi Huang. From zero-shot learning to cold-start recommendation. In ${AAAI},{2019}$ .

[17] 李晶晶、景萌萌、卢柯、朱磊、杨洋和黄子。从零样本学习到冷启动推荐。发表于 ${AAAI},{2019}$ 。

[18] Jingjing Li, Ke Lu, Zi Huang, and Heng Tao Shen. Two birds

[18] 李晶晶

one stone: on both cold-start and long-tail recommendation. In ${ACMMM}$ , pages 898-906. ACM, 2017.

一石二鸟:兼顾冷启动和长尾推荐。发表于 ${ACMMM}$ ，第898 - 906页。美国计算机协会(ACM)，2017年。

[19] Jingjing Li, Ke Lu, Zi Huang, Lei Zhu, and Heng Tao Shen. Heterogeneous domain adaptation through progressive alignment. IEEE TNNLS, 2018.

[19] 李晶晶、卢柯、黄子、朱磊和沈恒涛。通过渐进式对齐进行异构领域自适应。《电气与电子工程师协会神经网络与学习系统汇刊》(IEEE TNNLS)，2018年。

[20] Jingjing Li, Ke Lu, Zi Huang, Lei Zhu, and Heng Tao Shen. Transfer independently together: A generalized framework for domain adaptation. IEEE TCYB, 2018.

[20] 李晶晶、卢柯、黄子、朱磊和沈恒涛。独立协同迁移:一种通用的领域自适应框架。《电气与电子工程师协会控制论汇刊》(IEEE TCYB)，2018年。

[21] Jingjing Li, Lei Zhu, Zi Huang, Ke Lu, and Jidong Zhao. I read, i saw, i tell: Texts assisted fine-grained visual classification. In ${ACMMM}$ . ACM, 2018.

[21] 李晶晶、朱磊、黄子、卢柯和赵冀东。我阅读，我看见，我讲述:文本辅助的细粒度视觉分类。发表于 ${ACMMM}$ 。美国计算机协会(ACM)，2018年。

[22] Yang Long, Li Liu, Yuming Shen, Ling Shao, and J Song. Towards affordable semantic searching: Zero-shot. retrieval via dominant attributes. In ${AAAI},{2018}$ .

[22] 龙洋、刘莉、沈玉明、邵玲和J·宋。迈向经济实惠的语义搜索:通过主导属性进行零样本检索。发表于 ${AAAI},{2018}$ 。

[23] Mehdi Mirza and Simon Osindero. Conditional generative adversarial nets. arXiv preprint arXiv:1411.1784, 2014.

[23] 梅赫迪·米尔扎和西蒙·奥辛德罗。条件生成对抗网络。预印本arXiv:1411.1784，2014年。

[24] Ashish Mishra, M Reddy, Anurag Mittal, and Hema A Murthy. A generative model for zero shot learning using conditional variational autoencoders. In ${CVPR},{2018}$ .

[24] 阿什什·米什拉、M·雷迪、阿努拉格·米塔尔和赫马·A·穆尔蒂。使用条件变分自编码器的零样本学习生成模型。发表于 ${CVPR},{2018}$ 。

[25] M-E. Nilsback and A. Zisserman. Automated flower classification over a large number of classes. In ICVGIP, Dec 2008.

[25] M - E·尼尔斯巴克和A·齐斯曼。大量类别上的自动花卉分类。发表于印度计算机视觉、图形与图像处理会议(ICVGIP)，2008年12月。

[26] Mohammad Norouzi, Tomas Mikolov, Samy Bengio, Yoram Singer, Jonathon Shlens, Andrea Frome, Greg S Corrado, and Jeffrey Dean. Zero-shot learning by convex combination of semantic embeddings. arXiv preprint arXiv:1312.5650, 2013.

[26] 穆罕默德·诺鲁齐(Mohammad Norouzi)、托马斯·米科洛夫(Tomas Mikolov)、萨米·本吉奥(Samy Bengio)、约拉姆·辛格(Yoram Singer)、乔纳森·什伦斯(Jonathon Shlens)、安德里亚·弗罗姆(Andrea Frome)、格雷格·S·科拉多(Greg S Corrado)和杰弗里·迪恩(Jeffrey Dean)。通过语义嵌入的凸组合进行零样本学习。预印本 arXiv:1312.5650，2013年。

[27] Genevieve Patterson and James Hays. Sun attribute database: Discovering, annotating, and recognizing scene attributes. In CVPR, pages 2751-2758. IEEE, 2012.

[27] 吉纳维芙·帕特森(Genevieve Patterson)和詹姆斯·海斯(James Hays)。太阳属性数据库:发现、标注和识别场景属性。收录于《计算机视觉与模式识别会议论文集》(CVPR)，第2751 - 2758页。电气与电子工程师协会(IEEE)，2012年。

[28] Scott Reed, Zeynep Akata, Honglak Lee, and Bernt Schiele. Learning deep representations of fine-grained visual descriptions. In ${CVPR}$ , pages ${49} - {58},{2016}$ .

[28] 斯科特·里德(Scott Reed)、泽内普·阿卡塔(Zeynep Akata)、洪拉克·李(Honglak Lee)和伯恩特·席勒(Bernt Schiele)。学习细粒度视觉描述的深度表示。收录于 ${CVPR}$ ，第 ${49} - {58},{2016}$ 页。

[29] Bernardino Romera-Paredes and Philip Torr. An embarrassingly simple approach to zero-shot learning. In ${ICML}$ , pages 2152-2161, 2015.

[29] 贝尔纳迪诺·罗梅拉 - 帕雷德斯(Bernardino Romera - Paredes)和菲利普·托尔(Philip Torr)。一种极其简单的零样本学习方法。收录于 ${ICML}$ ，第2152 - 2161页，2015年。

[30] Yutaro Shigeto, Ikumi Suzuki, Kazuo Hara, Masashi Shimbo, and Yuji Matsumoto. Ridge regression, hubness, and zero-shot learning. In ECML-KDD, pages 135-151. Springer, 2015.

[30] 重藤裕太郎(Yutaro Shigeto)、铃木郁美(Ikumi Suzuki)、原和夫(Kazuo Hara)、岛本正志(Masashi Shimbo)和松本裕二(Yuji Matsumoto)。岭回归、枢纽性与零样本学习。收录于《欧洲机器学习与知识发现会议论文集》(ECML - KDD)，第135 - 151页。施普林格出版社(Springer)，2015年。

[31] Jake Snell, Kevin Swersky, and Richard Zemel. Prototypical networks for few-shot learning. In NIPS, pages 4077-4087, 2017.

[31] 杰克·斯内尔(Jake Snell)、凯文·斯沃尔斯基(Kevin Swersky)和理查德·泽梅尔(Richard Zemel)。用于少样本学习的原型网络。收录于《神经信息处理系统大会论文集》(NIPS)，第4077 - 4087页，2017年。

[32] V Kumar Verma, Gundeep Arora, Ashish Mishra, and Piyush Rai. Generalized zero-shot learning via synthesized examples. In ${CVPR},{2018}$ .

[32] V·库马尔·维尔马(V Kumar Verma)、贡迪普·阿罗拉(Gundeep Arora)、阿希什·米什拉(Ashish Mishra)和皮尤什·拉伊(Piyush Rai)。通过合成示例进行广义零样本学习。收录于 ${CVPR},{2018}$ 。

[33] Catherine Wah, Steve Branson, Peter Welinder, Pietro Per-ona, and Serge Belongie. The caltech-ucsd birds-200-2011 dataset. 2011.

[33] 凯瑟琳·瓦(Catherine Wah)、史蒂夫·布兰森(Steve Branson)、彼得·韦林德(Peter Welinder)、彼得罗·佩罗纳(Pietro Per - ona)和塞尔日·贝洛尼(Serge Belongie)。加州理工学院 - 加州大学圣地亚哥分校鸟类200 - 2011数据集。2011年。

[34] Yongqin Xian, Tobias Lorenz, Bernt Schiele, and Zeynep Akata. Feature generating networks for zero-shot learning. In ${CVPR},{2018}$ .

[34] 冼永勤(Yongqin Xian)、托比亚斯·洛伦茨(Tobias Lorenz)、伯恩特·席勒(Bernt Schiele)和泽内普·阿卡塔(Zeynep Akata)。用于零样本学习的特征生成网络。收录于 ${CVPR},{2018}$ 。

[35] Yongqin Xian, Bernt Schiele, and Zeynep Akata. Zero-shot learning-the good, the bad and the ugly. arXiv preprint arXiv:1703.04394, 2017.

[35] 冼永勤(Yongqin Xian)、伯恩特·席勒(Bernt Schiele)和泽内普·阿卡塔(Zeynep Akata)。零样本学习——好的、坏的和丑陋的。预印本 arXiv:1703.04394，2017年。

[36] Meng Ye and Yuhong Guo. Zero-shot classification with discriminative semantic representation learning. In CVPR, 2017.

[36] 叶萌和郭宇宏。通过判别性语义表示学习进行零样本分类。收录于《计算机视觉与模式识别会议论文集》(CVPR)，2017年。

[37] Li Zhang, Tao Xiang, Shaogang Gong, et al. Learning a deep embedding model for zero-shot learning. 2017.

[37] 张立、向涛、龚少刚等。学习用于零样本学习的深度嵌入模型。2017年。

[38] Ziming Zhang and Venkatesh Saligrama. Zero-shot learning via semantic similarity embedding. In ${ICCV}$ , pages 4166- 4174, 2015.

[38] 张紫铭和文卡特什·萨利格拉马(Venkatesh Saligrama)。通过语义相似性嵌入进行零样本学习。收录于 ${ICCV}$ ，第4166 - 4174页，2015年。

[39] Ziming Zhang and Venkatesh Saligrama. Zero-shot learning via joint latent similarity embedding. In ${CVPR}$ , pages 6034- 6042, 2016.

[39] 张紫铭和文卡特什·萨利格拉马(Venkatesh Saligrama)。通过联合潜在相似性嵌入进行零样本学习。收录于 ${CVPR}$ ，第6034 - 6042页，2016年。

[40] Yizhe Zhu, Mohamed Elhoseiny, Bingchen Liu, Xi Peng, and Ahmed Elgammal. A generative adversarial approach for zero-shot learning from noisy texts. In CVPR, 2018.

[40] 朱一哲、穆罕默德·埃尔霍塞尼(Mohamed Elhoseiny)、刘炳辰、彭熙和艾哈迈德·埃尔加马尔(Ahmed Elgammal)。一种从嘈杂文本中进行零样本学习的生成对抗方法。收录于《计算机视觉与模式识别会议论文集》(CVPR)，2018年。