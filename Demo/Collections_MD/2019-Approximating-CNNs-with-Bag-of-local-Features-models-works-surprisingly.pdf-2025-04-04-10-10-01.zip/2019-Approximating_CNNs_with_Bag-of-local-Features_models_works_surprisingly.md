# APPROXIMATING CNNS WITH BAG-OF-LOCAL- FEATURES MODELS WORKS SURPRISINGLY WELL ON IMAGENET

# 用局部特征袋模型近似卷积神经网络在 ImageNet 上效果出奇地好

Wieland Brendel and Matthias Bethge

维兰德·布伦德尔(Wieland Brendel)和马蒂亚斯·贝格(Matthias Bethge)

Eberhard Karls University of Tübingen, Germany

德国图宾根大学(Eberhard Karls University of Tübingen)

Werner Reichardt Centre for Integrative Neuroscience, Tübingen, Germany

德国图宾根维尔纳·赖哈特综合神经科学中心(Werner Reichardt Centre for Integrative Neuroscience)

Bernstein Center for Computational Neuroscience, Tübingen, Germany

德国图宾根伯恩斯坦计算神经科学中心(Bernstein Center for Computational Neuroscience)

\{wieland.brendel, matthias.bethge\}@bethgelab.org

\{wieland.brendel, matthias.bethge\}@bethgelab.org

## Abstract

## 摘要

Deep Neural Networks (DNNs) excel on many complex perceptual tasks but it has proven notoriously difficult to understand how they reach their decisions. We here introduce a high-performance DNN architecture on ImageNet whose decisions are considerably easier to explain. Our model, a simple variant of the ResNet- 50 architecture called BagNet, classifies an image based on the occurrences of small local image features without taking into account their spatial ordering. This strategy is closely related to the bag-of-feature (BoF) models popular before the onset of deep learning and reaches a surprisingly high accuracy on ImageNet (87.6% top-5 for ${33} \times  {33}$ px features and Alexnet performance for ${17} \times  {17}\mathrm{{px}}$ features). The constraint on local features makes it straight-forward to analyse how exactly each part of the image influences the classification. Furthermore, the BagNets behave similar to state-of-the art deep neural networks such as VGG-16, ResNet-152 or DenseNet-169 in terms of feature sensitivity, error distribution and interactions between image parts. This suggests that the improvements of DNNs over previous bag-of-feature classifiers in the last few years is mostly achieved by better fine-tuning rather than by qualitatively different decision strategies.

深度神经网络(DNNs)在许多复杂的感知任务中表现出色，但事实证明，要理解它们是如何做出决策的极其困难。我们在此介绍一种在 ImageNet 上表现出色的深度神经网络架构，其决策过程相当容易解释。我们的模型是 ResNet - 50 架构的一个简单变体，称为 BagNet，它根据小的局部图像特征的出现情况对图像进行分类，而不考虑它们的空间顺序。这种策略与深度学习出现之前流行的特征袋(BoF)模型密切相关，并且在 ImageNet 上达到了惊人的高精度(对于 ${33} \times  {33}$ 像素特征，前 5 准确率为 87.6%，对于 ${17} \times  {17}\mathrm{{px}}$ 特征，性能与 Alexnet 相当)。对局部特征的限制使得分析图像的每个部分究竟如何影响分类变得直接明了。此外，在特征敏感性、误差分布和图像部分之间的相互作用方面，BagNets 的行为与 VGG - 16、ResNet - 152 或 DenseNet - 169 等最先进的深度神经网络相似。这表明，近年来深度神经网络相对于之前的特征袋分类器的改进，主要是通过更好的微调实现的，而不是通过本质上不同的决策策略。

## 1 INTRODUCTION

## 1 引言

A big obstacle in understanding the decision-making of DNNs is due to the complex dependencies between input and hidden activations: for one, the effect of any part of the input on a hidden activation depends on the state of many other parts of the input. Likewise, the role of a hidden unit on downstream representations depends on the activity of many other units. This dependency makes it extremely difficult to understand how DNNs reach their decisions.

理解深度神经网络决策过程的一个重大障碍在于输入和隐藏激活之间的复杂依赖关系:一方面，输入的任何部分对隐藏激活的影响取决于输入的许多其他部分的状态。同样，一个隐藏单元对下游表示的作用取决于许多其他单元的活动。这种依赖关系使得理解深度神经网络如何做出决策变得极其困难。

To circumvent this problem we here formulate a new DNN architecture that is easier to interpret ${by}$ design. Our architecture is inspired by bag-of-feature (BoF) models which - alongside extensions such as VLAD encoding or Fisher Vectors - have been the most successful approaches to large-scale object recognition before the advent of deep learning (up to 75% top-5 on ImageNet) and classify images based on the counts, but not the spatial relationships, of a set of local image features. This structure makes the decisions of BoF models particularly easy to explain.

为了克服这个问题，我们在此设计了一种新的深度神经网络架构，该架构在设计上更容易解释。我们的架构受到特征袋(BoF)模型的启发，在深度学习出现之前，特征袋模型(以及诸如 VLAD 编码或 Fisher 向量等扩展)是大规模目标识别最成功的方法(在 ImageNet 上前 5 准确率高达 75%)，它根据一组局部图像特征的数量而不是空间关系对图像进行分类。这种结构使得特征袋模型的决策特别容易解释。

To be concise, throughout this manuscript the concept of interpretability refers to the way in which evidence from small image patches is integrated to reach an image-level decision. While basic BoF models perform just a simple and transparent spatial aggregate of the patch-wise evidences, DNNs non-linearly integrate information across the whole image.

简而言之，在整个论文中，可解释性的概念指的是如何整合小图像块的证据以做出图像级别的决策。虽然基本的特征袋模型只是对图像块的证据进行简单而透明的空间聚合，但深度神经网络则是在整个图像上非线性地整合信息。

In this paper we show that it is possible to combine the performance and flexibility of DNNs with the interpretability of BoF models, and that the resulting model family (called BagNets) is able to reach high accuracy on ImageNet even if limited to fairly small image patches. Given the simplicity of BoF models we imagine many use cases for which it can be desirable to trade a bit of accuracy for better interpretability, just as this is common e.g. for linear function approximation. This includes diagnosing failure cases (e.g. adversarial examples) or non-iid. settings (e.g. domain transfer), benchmarking diagnostic tools (e.g. attribution methods) or serving as interpretable parts of a computer vision pipeline (e.g. with a relational network on top of the local features).

在本文中，我们表明可以将深度神经网络的性能和灵活性与特征袋模型的可解释性相结合，并且由此产生的模型家族(称为 BagNets)即使仅限于相当小的图像块，也能够在 ImageNet 上达到高精度。鉴于特征袋模型的简单性，我们设想了许多应用场景，在这些场景中，为了获得更好的可解释性而牺牲一些准确性是可取的，就像在线性函数逼近中常见的那样。这包括诊断失败案例(例如对抗性示例)或非独立同分布设置(例如领域转移)、对诊断工具(例如归因方法)进行基准测试，或者作为计算机视觉流程中可解释的部分(例如在局部特征之上使用关系网络)。

![0195e036-d19c-71db-a83c-e4017b98e2b1_1_305_201_1183_494_0.jpg](images/0195e036-d19c-71db-a83c-e4017b98e2b1_1_305_201_1183_494_0.jpg)

Figure 1: Deep bag-of-features models (BagNets). (A) The models extract features from small image patches which are each fed into a linear classifier yielding one logit heatmap per class. These heatmaps are averaged across space and passed through a softmax to get the final class probabilities. (B) Top-5 ImageNet performance over patch size. (C) Correlation with logits of VGG-16.

图 1:深度特征袋模型(BagNets)。(A)这些模型从小图像块中提取特征，每个特征都输入到一个线性分类器中，为每个类别生成一个对数几率热图。这些热图在空间上进行平均，并通过 softmax 函数得到最终的类别概率。(B)前 5 ImageNet 性能与图像块大小的关系。(C)与 VGG - 16 的对数几率的相关性。

In addition, we demonstrate similarities between the decision-making behaviour of BagNets and popular DNNs in computer vision. These similarities suggest that current network architectures base their decisions on a large number of relatively weak and local statistical regularities and are not sufficiently encouraged - either through their architecture, training procedure or task specification - to learn more holistic features that can better appreciate causal relationships between different parts of the image.

此外，我们展示了 BagNets 的决策行为与计算机视觉中流行的深度神经网络之间的相似性。这些相似性表明，当前的网络架构基于大量相对较弱的局部统计规律做出决策，并且没有通过其架构、训练过程或任务规范得到足够的激励来学习更整体的特征，这些特征能够更好地理解图像不同部分之间的因果关系。

## 2 NETWORK ARCHITECTURE

## 2 网络架构

We here recount the main elements of a classic bag-of-features model before introducing the simpler DNN-based BagNets in the next paragraph. Bag-of-feature representations can be described by analogy to bag-of-words representations. With bag-of-words, one counts the number of occurrences of words from a vocabulary in a document. This vocabulary contains important words (but not common ones like "and" or "the") and word clusters (i.e. semantically similar words like "gigantic" and "enormous" are subsumed). The counts of each word in the vocabulary are assembled as one long term vector. This is called the bag-of-words document representation because all ordering of the words is lost. Likewise, bag-of-feature representations are based on a vocabulary of visual words which represent clusters of local image features. The term vector for an image is then simply the number of occurrences of each visual word in the vocabulary. This term vector is used as an input to a classifier (e.g. SVM or MLP). Many successful image classification models have been based on this pipeline (Csurka et al., 2004; Jurie & Triggs, 2005; Zhang et al., 2007; Lazebnik et al., 2006), see O'Hara & Draper (2011) for an up-to-date overview.

在接下来的段落中介绍更简单的基于深度神经网络(DNN)的词袋网络(BagNets)之前，我们在此详述经典特征袋模型的主要元素。特征袋表示法可以通过与词袋表示法进行类比来描述。在词袋模型中，人们会统计文档中词汇表里每个单词的出现次数。这个词汇表包含重要的单词(但不包含像“and”或“the”这样的常用词)以及词簇(即语义相似的单词，如“gigantic”和“enormous”会被归为一类)。词汇表中每个单词的计数会组合成一个长的词向量。这被称为词袋文档表示法，因为单词的所有顺序信息都丢失了。同样，特征袋表示法基于视觉单词的词汇表，这些视觉单词代表局部图像特征的簇。然后，图像的词向量就是词汇表中每个视觉单词的出现次数。这个词向量被用作分类器(如支持向量机(SVM)或多层感知机(MLP))的输入。许多成功的图像分类模型都是基于这个流程构建的(Csurka等人，2004年；Jurie和Triggs，2005年；Zhang等人，2007年；Lazebnik等人，2006年)，最新综述可参见O'Hara和Draper(2011年)的研究。

BoF models are easy to interpret if the classifier on top of the term vector is linear. In this case the influence of a given part of the input on the classifier is independent of the rest of the input.

如果基于词向量的分类器是线性的，那么特征袋(BoF)模型就很容易解释。在这种情况下，输入的某一部分对分类器的影响与输入的其余部分无关。

Based on this insight we construct a linear DNN-based BoF model as follows (see Figure 1): first, we infer a 2048 dimensional feature representation from each image patch of size $\mathrm{q} \times  \mathrm{q}$ pixels using multiple stacked ResNet blocks and apply a linear classifier to infer the class evidence for each patch (heatmaps). We average the class evidence across all patches to infer the image-level class evidence (logits). This structure differs from other ResNets (He et al. 2015) only in the replacement of many $3 \times  3$ by $1 \times  1$ convolutions, thereby limiting the receptive field size of the topmost convolutional layer to $\mathrm{q} \times  \mathrm{q}$ pixels (see Appendix for details). There is no explicit assignment to visual words. This could be added through a sparse projection into a high-dimensional embedding but we did not see benefits for interpretability. We denote the resulting architecture as BagNet- $q$ and test $q \in  \left\lbrack  {9,{17},{33}}\right\rbrack$ .

基于这一见解，我们按如下方式构建一个基于深度神经网络(DNN)的线性特征袋(BoF)模型(见图1):首先，我们使用多个堆叠的残差网络(ResNet)模块从每个大小为 $\mathrm{q} \times  \mathrm{q}$ 像素的图像块中推断出一个2048维的特征表示，并应用线性分类器为每个图像块推断类别证据(热力图)。我们对所有图像块的类别证据进行平均，以推断图像级别的类别证据(对数几率)。这种结构与其他残差网络(He等人，2015年)的不同之处仅在于将许多 $3 \times  3$ 卷积替换为 $1 \times  1$ 卷积，从而将最顶层卷积层的感受野大小限制为 $\mathrm{q} \times  \mathrm{q}$ 像素(详细信息见附录)。这里没有明确地分配视觉单词。可以通过稀疏投影到高维嵌入中来添加这一步骤，但我们并未发现这对可解释性有什么好处。我们将得到的架构表示为BagNet - $q$ 并测试 $q \in  \left\lbrack  {9,{17},{33}}\right\rbrack$ 。

![0195e036-d19c-71db-a83c-e4017b98e2b1_2_309_237_1172_468_0.jpg](images/0195e036-d19c-71db-a83c-e4017b98e2b1_2_309_237_1172_468_0.jpg)

Figure 2: Heatmaps showing the class evidence extracted from of each part of the image. The spatial sum over the evidence is the total class evidence.

图2:显示从图像各部分提取的类别证据的热力图。证据的空间总和即为总类别证据。

Note that an important ingredient of our model is the linear classifier on top of the local feature representation. The word linear here refers to the combination of a linear spatial aggregation (a simple average) and a linear classifier on top of the aggregated features. The fact that the classifier and the spatial aggregation are both linear and thus interchangeable allows us to pinpoint exactly how evidence from local image patches is integrated into one image-level decision.

请注意，我们模型的一个重要组成部分是基于局部特征表示的线性分类器。这里的“线性”指的是线性空间聚合(简单平均)和基于聚合特征的线性分类器的组合。分类器和空间聚合都是线性的，因此可以互换，这一事实使我们能够准确地确定局部图像块的证据是如何整合到一个图像级别的决策中的。

## 3 RELATED LITERATURE

## 3 相关文献

BoF models and DNNs There are some model architectures that fuse elements from DNNs and BoF models. Predominantly, DNNs were used to replace the previously hand-tuned feature extraction stage in BoF models, often using intermediate or higher layer features of pretrained DNNs (Feng et al., 2017; Gong et al., 2014; Ng et al., 2015; Mohedano et al., 2016; Cao et al., 2017; Khan et al., 2016) for tasks such as image retrieval or geographical scene classification. Other work has explored how well insights from DNN training (e.g. data augmentation) transfer to the training of BoF and Improved Fisher Vector models (Chatfield et al. 2014) and how SIFT and CNN feature descriptions perform (Babenko & Lempitsky, 2015). In contrast, our proposed BoF model architecture is simpler and closer to standard DNNs used for object recognition while still maintaining the interpretability of linear BoF models with local features. Furthermore, to our knowledge this is the first work that explores the relationship between the decision-making of BoF and DNN models.

特征袋(BoF)模型和深度神经网络(DNN) 有一些模型架构融合了深度神经网络和特征袋模型的元素。主要是，深度神经网络被用于取代特征袋模型中之前手动调整的特征提取阶段，通常使用预训练深度神经网络的中间层或更高层特征(Feng等人，2017年；Gong等人，2014年；Ng等人，2015年；Mohedano等人，2016年；Cao等人，2017年；Khan等人，2016年)来完成图像检索或地理场景分类等任务。其他研究探索了深度神经网络训练中的见解(如数据增强)对特征袋模型和改进的费舍尔向量模型训练的迁移效果(Chatfield等人，2014年)，以及尺度不变特征变换(SIFT)和卷积神经网络(CNN)特征描述的性能表现(Babenko和Lempitsky，2015年)。相比之下，我们提出的特征袋模型架构更简单，更接近用于目标识别的标准深度神经网络，同时仍保持了具有局部特征的线性特征袋模型的可解释性。此外，据我们所知，这是第一项探索特征袋模型和深度神经网络模型决策过程之间关系的研究。

Interpretable DNNs Our work is most closely related to approaches that use DNNs in conjunction with more interpretable elements. Pinheiro & Collobert (2014) adds explicit labelling of single pixels before the aggregation to an image-level label. The label of each pixel, however, is still inferred from the whole image, making the pixel assignments difficult to interpret. Xiao et al. (2015) proposed a multi-step approach combining object-, part- and domain-detectors to reach a classification decision. In this process object-relevant patches of variable sizes are extracted. In contrast, our approach is much simpler, reaches higher accuracy and is easier to interpret. Besides pixel-level attention-based mechanisms there are several attempts to make the evidence accumulation more interpretable. Hinton et al. (2015) introduced soft decision trees that are trained on the predictions of neural networks. While this increases performance of decision trees, the gap to neural networks on data sets like ImageNet is still large. In Li et al. (2017) an autoencoder architecture is combined with a shallow classifier based on prototype representations. Chen et al. (2018) uses a similar approach but is based on a convolutional architecture to extract class-specific prototype patches. The interpretation of the prototype-based classification, however, is difficult because only the L2 norm between the prototypes and the extracted latent representations is considered ${}^{1}$ . Finally, the class activation maps by Zhou et al. (2015) share similarities to our approach as they also use a CNN with global average pooling and a linear classifier in order to extract class-specific heatmaps. However, their latent representations are

可解释的深度神经网络(DNNs) 我们的工作与将深度神经网络与更具可解释性的元素结合使用的方法最为相关。Pinheiro和Collobert(2014)在将单个像素聚合为图像级标签之前，对其进行了明确标注。然而，每个像素的标签仍然是从整个图像推断出来的，这使得像素分配难以解释。Xiao等人(2015)提出了一种多步骤方法，结合对象、部分和领域检测器来做出分类决策。在这个过程中，会提取不同大小的与对象相关的图像块。相比之下，我们的方法要简单得多，准确率更高，也更易于解释。除了基于像素级注意力的机制外，还有一些尝试使证据积累更具可解释性。Hinton等人(2015)引入了软决策树，这些决策树是在神经网络的预测结果上进行训练的。虽然这提高了决策树的性能，但在像ImageNet这样的数据集上，决策树与神经网络之间的差距仍然很大。在Li等人(2017)的研究中，自编码器架构与基于原型表示的浅层分类器相结合。Chen等人(2018)采用了类似的方法，但基于卷积架构来提取特定类别的原型图像块。然而，基于原型的分类的解释很困难，因为只考虑了原型与提取的潜在表示之间的L2范数 ${}^{1}$ 。最后，Zhou等人(2015)提出的类激活图与我们的方法有相似之处，因为它们也使用了带有全局平均池化的卷积神经网络(CNN)和线性分类器来提取特定类别的热力图。然而，他们的潜在表示是

---

${}^{1}$ Just because two images have a similar latent representation does not mean that they share any similarities in terms of human-interpretable features.

${}^{1}$ 仅仅因为两幅图像具有相似的潜在表示，并不意味着它们在人类可解释的特征方面有任何相似之处。

---

![0195e036-d19c-71db-a83c-e4017b98e2b1_3_321_191_1165_523_0.jpg](images/0195e036-d19c-71db-a83c-e4017b98e2b1_3_321_191_1165_523_0.jpg)

Figure 3: Most informative image patches for BagNets. For each class (row) and each model (column) we plot two subrows: in the top subrow we show patches that caused the highest logit outputs for the given class across all validation images with that label. Patches in the bottom subrow are selected in the same way but from all validation images with a different label (highlighting errors).

图3:BagNets最具信息量的图像块。对于每个类别(行)和每个模型(列)，我们绘制两行子图:在上面的子行中，我们展示了在所有带有该标签的验证图像中，对给定类别产生最高对数几率输出的图像块。下面子行中的图像块以相同的方式选择，但来自所有带有不同标签的验证图像(突出显示错误)。

extracted from the whole image and it is unclear how the heatmaps in the latent space are related to the pixel space. In our approach the CNN representations are restricted to very small image patches, making it possible to trace exactly how each image patch contributes the final decision.

从整个图像中提取的，并且不清楚潜在空间中的热力图与像素空间有何关联。在我们的方法中，卷积神经网络的表示被限制在非常小的图像块上，这使得我们能够准确追踪每个图像块是如何对最终决策做出贡献的。

Scattering networks Another related work by Oyallon et al. (2017) uses a scattering network with small receptive fields (14 x 14 pixels) in conjunction with a two-layer Multilayer Perceptron or a ResNet-10 on top of the scattering network. This approach reduces the overall depth of the model compared to ResNets (with matched classification accuracy) but does not increase interpretability (because of the non-linear classifier on top of the local scattering features).

散射网络 Oyallon等人(2017)的另一项相关工作使用了具有小感受野(14×14像素)的散射网络，并在散射网络之上结合了两层多层感知器或ResNet - 10。与ResNet相比，这种方法在保持分类准确率的情况下降低了模型的整体深度，但并没有提高可解释性(因为在局部散射特征之上使用了非线性分类器)。

A set of superficially similar but unrelated approaches are region proposal models (Wei et al. 2016) Tang et al. 2017; 2016; Arandjelovic et al. 2015). Such models typically use the whole image to infer smaller image regions with relevant objects. These regions are then used to extract a spatially aligned subset of features from the highest DNN layer (so information is still integrated far beyond the proposed image patch). Our approach does not rely on region proposals and extracts features only from small local regions.

一组表面上相似但不相关的方法是区域提议模型(Wei等人2016；Tang等人2017、2016；Arandjelovic等人2015)。这类模型通常使用整个图像来推断包含相关对象的较小图像区域。然后，这些区域用于从深度神经网络的最高层提取空间对齐的特征子集(因此信息仍然在提议的图像块之外进行整合)。我们的方法不依赖于区域提议，仅从小的局部区域提取特征。

## 4 RESULTS

## 4 结果

In the first two subsections we investigate the classification performance of BagNets for different patch sizes and demonstrate insights we can derive from its interpretable structure. Thereafter we compare the behaviour of BagNets with several widely used high-performance DNNs (e.g. VGG-16, ResNet-50, DenseNet-169) and show evidence that their decision-making shares many similarities.

在前两个小节中，我们研究了不同图像块大小下BagNets的分类性能，并展示了我们可以从其可解释结构中获得的见解。此后，我们将BagNets的行为与几种广泛使用的高性能深度神经网络(如VGG - 16、ResNet - 50、DenseNet - 169)进行了比较，并证明它们的决策过程有许多相似之处。

### 4.1 ACCURACY & RUNTIME OF BAGNETS ON IMAGENET

### 4.1 BagNets在ImageNet上的准确率和运行时间

We train the BagNets directly on ImageNet (see Appendix for details). Surprisingly, patch sizes as small as ${17} \times  {17}$ pixels suffice to reach AlexNet (Krizhevsky et al. 2012) performance (80.5% top-5 performance) while patches sizes ${33} \times  {33}$ pixels suffice to reach close to ${87.6}\%$ .

我们直接在ImageNet上训练BagNets(详情见附录)。令人惊讶的是，小至 ${17} \times  {17}$ 像素的图像块就足以达到AlexNet(Krizhevsky等人2012)的性能(前5准确率为80.5%)，而 ${33} \times  {33}$ 像素的图像块足以接近 ${87.6}\%$ 。

We also compare the runtime of BagNet-q $\left( {q = {33},{17},9}\right)$ in inference mode with images of size $3 \times  {224} \times  {224}$ and batch size 64 against a vanilla ResNet-50. Across all receptive field sizes BagNets reach around 155 images/s for BagNets compared to 570 images/s for ResNet-50. The difference in runtime can be attributed to the reduced amount of downsampling in BagNets compared to ResNet-50.

我们还将推理模式下BagNet - q $\left( {q = {33},{17},9}\right)$处理尺寸为 $3 \times  {224} \times  {224}$、批量大小为64的图像的运行时间与普通的ResNet - 50进行了比较。在所有感受野大小下，BagNet每秒约能处理155张图像，而ResNet - 50每秒能处理570张图像。运行时间的差异可归因于与ResNet - 50相比，BagNet的下采样量减少。

### 4.2 EXPLAINING DECISIONS

### 4.2 解释决策

For each $\mathrm{q} \times  \mathrm{q}$ patch the model infers evidence for each ImageNet classes, thus yielding a high-resolution and very precise heatmap that shows which parts of the image contributes most to certain decisions. We display these heatmaps for the predicted class for ten randomly chosen test images in

对于每个 $\mathrm{q} \times  \mathrm{q}$ 图像块，模型会推断每个ImageNet类别的证据，从而生成高分辨率且非常精确的热力图，该热力图显示图像的哪些部分对特定决策贡献最大。我们在图中展示了随机选择的十张测试图像的预测类别的这些热力图

Figure 2. Clearly, most evidence lies around the shapes of objects (e.g. the crip or the paddles) or certain predictive image features like the glowing borders of the pumpkin. Also, for animals eyes or legs are important. It's also notable that background features (like the forest in the deer image) are pretty much ignored by the BagNets.

图2。显然，大多数证据集中在物体的形状周围(例如板条箱或桨)，或者某些具有预测性的图像特征，如南瓜发光的边缘。此外，对于动物来说，眼睛或腿部很重要。值得注意的是，BagNet几乎忽略了背景特征(如鹿图像中的森林)。

Next we pick a class and run the BagNets across all validation images to find patches with the most class evidence. Some of these patches are taken from images of that class (i.e. they carry "correct" evidence) while other patches are from images of another class (i.e. these patches can lead to misclassifications). In Figure 3 we show the top-7 patches from both correct and incorrect images for several classes (rows) and different BagNets (columns). This visualisation yields many insights: for example, book jackets are identified mainly by the text on the cover, leading to confusion with other text on t-shirts or websites. Similarly, keys of a typewriter are often interpreted as evidence for handheld computers. The tench class, a large fish species, is often identified by fingers on front of a greenish background. Closer inspection revealed that tench images typically feature the fish hold up like a trophy, thus making the hand and fingers holding it a very predictive image feature. Flamingos are detected by their beaks, which makes them easy to confuse with other birds like storks, while grooms are primarily identified by the transition from suit to neck, an image feature present in many other classes.

接下来，我们选择一个类别，并让BagNet对所有验证图像进行处理，以找到具有最多类别证据的图像块。其中一些图像块来自该类别的图像(即它们携带“正确”的证据)，而其他图像块来自其他类别的图像(即这些图像块可能导致错误分类)。在图3中，我们展示了几个类别(行)和不同BagNet(列)的正确和错误图像中的前7个图像块。这种可视化提供了许多见解:例如，书的封面主要通过封面上的文字来识别，这会导致与T恤或网站上的其他文字产生混淆。同样，打字机的按键通常被解释为手持计算机的证据。丁鲷类别(一种大型鱼类)通常通过绿色背景前的手指来识别。仔细观察发现，丁鲷图像通常以将鱼像奖杯一样举起的方式呈现，因此拿着鱼的手和手指成为了一个非常具有预测性的图像特征。火烈鸟通过它们的喙来检测，这使得它们很容易与鹳等其他鸟类混淆，而新郎主要通过西装到脖子的过渡来识别，这一图像特征在许多其他类别中也存在。

![0195e036-d19c-71db-a83c-e4017b98e2b1_4_969_385_513_785_0.jpg](images/0195e036-d19c-71db-a83c-e4017b98e2b1_4_969_385_513_785_0.jpg)

Figure 4: Images misclassified by BagNet- 33 and VGG-16 with heatmaps for true and predicted label and the most predictive image patches. Class probability reported for BagNet-33 (left) and VGG (right).

图4:BagNet - 33和VGG - 16错误分类的图像，带有真实标签和预测标签的热力图以及最具预测性的图像块。报告了BagNet - 33(左)和VGG(右)的类别概率。

In Figure 4 we analyse images misclassified by both BagNet-33 and VGG-16. In the first example the ground-truth class "cleaver" was confused with "granny smith" because of the green cucumber at the top of the image. Looking at the three most predictive patches plotted alongside each heatmap, which show the apple-like edges of the green cucumber pieces, this choice looks comprehensible. Similarly, the local patches in the "thimble" image resemble a gas mask if viewed in isolation. The letters in the "miniskirt" image are very salient, thus leading to the "book jacket" prediction while in the last image the green blanket features a glucamole-like texture.

在图4中，我们分析了BagNet - 33和VGG - 16都错误分类的图像。在第一个例子中，真实类别“切肉刀”被误分类为“澳洲青苹”，原因是图像顶部的绿色黄瓜。查看每个热力图旁边绘制的三个最具预测性的图像块，这些图像块显示了绿色黄瓜片类似苹果的边缘，这种分类选择看起来是可以理解的。同样，“顶针”图像中的局部图像块如果单独看，类似于防毒面具。“迷你裙”图像中的字母非常突出，因此导致了“书封面”的预测，而在最后一张图像中，绿色毯子具有类似鳄梨酱的纹理。

### 4.3 COMPARING THE DECISION-MAKING OF BAGNETS AND HIGH-PERFORMANCE DNNS

### 4.3 比较BagNet和高性能深度神经网络的决策过程

In the next paragraphs we investigate how similar the decision-making of BagNets is to high-performance DNNs like VGG-16, ResNet-50, ResNet-152 and DenseNet-169. There is no single answer or number, partially because we lack a sensible distance metric between networks. One can compare the pearson correlation between logits (for VGG-16, BagNet-9/17/33 reach 0.70 / 0.79 / 0.88 respectively, see Figure 1C), but this number can only give a first hint as it does not investigate the specific process that led to the decision. However, the decision-making of BagNets does feature certain key characteristics that we can compare to other models.

在接下来的段落中，我们研究BagNet的决策过程与VGG - 16、ResNet - 50、ResNet - 152和DenseNet - 169等高性能深度神经网络(DNN)的相似程度。没有单一的答案或数值，部分原因是我们缺乏网络之间合理的距离度量。可以比较对数几率之间的皮尔逊相关性(对于VGG - 16，BagNet - 9/17/33的相关性分别达到0.70 / 0.79 / 0.88，见图1C)，但这个数值只能给出一个初步的提示，因为它没有研究导致决策的具体过程。然而，BagNet的决策过程确实具有某些关键特征，我们可以将其与其他模型进行比较。

![0195e036-d19c-71db-a83c-e4017b98e2b1_4_315_1684_1167_415_0.jpg](images/0195e036-d19c-71db-a83c-e4017b98e2b1_4_315_1684_1167_415_0.jpg)

Figure 5: Examples of original and texturised images. A vanilla VGG-16 still reaches high accuracy on the texturised images while humans suffer greatly from the loss of global shapes in many images.

图5:原始图像和纹理化图像的示例。普通的VGG - 16在纹理化图像上仍然能达到较高的准确率，而人类在许多图像中因失去全局形状而受到很大影响。

![0195e036-d19c-71db-a83c-e4017b98e2b1_5_301_177_1156_1010_0.jpg](images/0195e036-d19c-71db-a83c-e4017b98e2b1_5_301_177_1156_1010_0.jpg)

Figure 6: Interaction of spatially separated image parts. (A) Changes in class-evidence when single image patches are masked (centre) versus change when all patches are masked simultaneously (right). For linear BoF models both terms are the same. (B) Masking regions for different patch sizes. (C) Correlation between both terms for different DNNs over different patch sizes. Interactions are greatly depressed for image features larger than ${30} \times  {30}\mathrm{{px}}$ .

图6:空间分离的图像部分的相互作用。(A) 单个图像块被遮挡时(中间)与所有图像块同时被遮挡时(右侧)类别证据的变化。对于线性词袋(BoF)模型，这两个项是相同的。(B) 不同图像块大小的遮挡区域。(C) 不同深度神经网络(DNN)在不同图像块大小下这两个项之间的相关性。对于大于 ${30} \times  {30}\mathrm{{px}}$ 的图像特征，相互作用会大大减弱。

Image Scrambling One core component of the bag-of-feature networks is the neglect of the spatial relationships between image parts. In other words, scrambling the parts across the image while keeping their counts constant does not change the model decision. Is the same true for current computer vision models like VGG or ResNets? Unfortunately, due to the overlapping receptive fields it is generally not straight-forward to scramble an image in a way that leaves the feature histograms invariant. For VGG-16 an algorithm that comes close to this objective is the popular texture synthesis algorithm based on the Gram features of the hidden layer activations (Gatys et al. 2015), Figure 5 For humans, the scrambling severely increases the difficulty of the task while the performance of VGG-16 is little affected (90.1% on clean versus 79.4% on texturised image).

图像打乱 特征袋网络的一个核心组成部分是忽略图像部分之间的空间关系。换句话说，在保持图像部分数量不变的情况下打乱它们在图像中的位置不会改变模型的决策。对于像VGG或残差网络(ResNets)这样的当前计算机视觉模型来说也是如此吗？不幸的是，由于感受野的重叠，通常很难以一种使特征直方图不变的方式打乱图像。对于VGG - 16，一种接近这一目标的算法是基于隐藏层激活的格拉姆(Gram)特征的流行纹理合成算法(Gatys等人，2015年)，见图5。对于人类来说，打乱操作会极大地增加任务的难度，而VGG - 16的性能几乎不受影响(干净图像上的准确率为90.1%，纹理化图像上的准确率为79.4%)。

This suggests that VGG, in stark contrast to humans, does not rely on global shape integration for perceptual discrimination but rather on statistical regularities in the histogram of local image features. It is well known by practioners that the aforementioned texture synthesis algorithm does not work for ResNet- and DenseNet architectures, the reasons of which are not yet fully understood.

这表明，与人类形成鲜明对比的是，VGG在感知判别时不依赖于全局形状整合，而是依赖于局部图像特征直方图中的统计规律。从业者们都知道，上述纹理合成算法不适用于残差网络(ResNet)和密集连接网络(DenseNet)架构，其原因尚未完全明确。

Spatially distinct image manipulations do not interact For BoF models with a linear (but not non-linear!) classifier we do not only expect invariance to the spatial arrangement of image parts, but also that the marginal presence or absence of an image part always has the same effect on the evidence accumulation (i.e. is independent of the rest of the image). In other words, for a BoF model an image with five unconnected wheels (and nothing else) would carry more evidence for class "bike" than a regular photo of a bicycle; a linear BoF model simply ignores whether there is also a frame and a saddle. More precisely, let ${\ell }_{\text{model }}\left( \mathbf{x}\right)$ be the class evidence (logit) as a function of the input $\mathbf{x}$ and let ${\mathbf{\delta }}_{i}$ be spatially separated and non-overlapping input modifications. For a BagNet-q it holds that

空间上不同的图像操作不会相互作用 对于使用线性(而非非线性！)分类器的词袋(BoF)模型，我们不仅期望其对图像部分的空间排列具有不变性，还期望图像部分的存在或缺失对证据积累的影响始终相同(即与图像的其他部分无关)。换句话说，对于一个词袋模型，一张有五个不相连轮子(没有其他东西)的图像比一张普通自行车照片对“自行车”类别的证据支持更多；线性词袋模型根本不考虑是否还有车架和车座。更准确地说，设 ${\ell }_{\text{model }}\left( \mathbf{x}\right)$ 是作为输入 $\mathbf{x}$ 的函数的类别证据(对数几率)，设 ${\mathbf{\delta }}_{i}$ 是空间上分离且不重叠的输入修改。对于BagNet - q，有

$$
{\ell }_{\text{model }}\left( \mathbf{x}\right)  - {\ell }_{\text{model }}\left( {\mathbf{x} + \mathop{\sum }\limits_{i}{\mathbf{\delta }}_{i}}\right)  = \mathop{\sum }\limits_{i}\left( {{\ell }_{\text{model }}\left( \mathbf{x}\right)  - {\ell }_{\text{model }}\left( {\mathbf{x} + {\mathbf{\delta }}_{i}}\right) }\right) , \tag{1}
$$

as long as the modifications are separated by more than $q$ pixels. We use the Pearson correlation between the LHS and RHS of eq. (1) as a measure of non-linear interactions between image parts In our experiments we partition the image into a grid of non-overlapping square-sized patches with patch size $q$ . We then replace every second patch in every second row (see Figure 6B) with its DC component (the spatial channel average) both in isolation (RHS of eq. (1)) and in combination (LHS of eq. (1)), see Figure 6A. This ensures that the masked patches are spaced by $q$ pixels and that always around $1/4$ of the image is masked. Since most objects fill much of the image, we can expect that the masking will remove many class-predictive image features. We measure the Pearson correlation between the LHS and RHS of eq. 1 for different patch sizes $q$ and DNN models (Figure 6C). The results (Figure 6C) show that VGG-16 exhibits few interactions between image parts spaced by more than 30 pixels. The interactions increase for deeper and more performant architectures.

只要修改部分之间的间距超过 $q$ 像素。我们使用公式(1)左右两侧的皮尔逊相关性作为图像部分之间非线性相互作用的度量。在我们的实验中，我们将图像划分为大小为 $q$ 的不重叠方形图像块网格。然后，我们将每隔一行的每隔一个图像块(见图6B)替换为其直流分量(空间通道平均值)，分别单独替换(公式(1)的右侧)和组合替换(公式(1)的左侧)，见图6A。这确保了被遮挡的图像块间距为 $q$ 像素，并且始终大约有 $1/4$ 的图像被遮挡。由于大多数物体占据了图像的大部分，我们可以预期遮挡操作会去除许多具有类别预测性的图像特征。我们测量了不同图像块大小 $q$ 和深度神经网络模型下公式(1)左右两侧的皮尔逊相关性(图6C)。结果(图6C)表明，VGG - 16在间距超过30像素的图像部分之间表现出很少的相互作用。对于更深层、性能更好的架构，相互作用会增加。

Error distribution In Figure 7 we plot the top-5 accuracy within each ImageNet class of BagNet- 33 against the accuracy of regular DNNs. For comparison we also plot VGG-11 against VGG-16. The analysis reveals that the error distribution is fairly consistent between models.

误差分布 在图7中，我们绘制了BagNet - 33在每个ImageNet类别中的前5准确率与常规深度神经网络的准确率的对比图。为了进行比较，我们还绘制了VGG - 11与VGG - 16的对比图。分析表明，模型之间的误差分布相当一致。

Spatial sensitivity To see whether BagNets and DNNs use similar image parts for image classification we follow Zintgraf et al. (2017) and test how the prediction of DNNs is changing when we mask the most predictive image parts. In Figure 8 (top) we compare the decrease in predicted class probability for an increasing number of masked $8 \times  8$ patches. The masking locations are determined by the heatmaps of BagNets which we compare against random maskings as well as several popular attribution techniques (Baehrens et al. 2010; Sundararajan et al. 2017; Kindermans et al. 2018; Shrikumar et al., 2017) (we use the implementations of DeepExplain (Ancona et al. 2017) which compute heatmaps directly in the tested models. Notice that these attribution methods have an advantage because they compute heatmaps knowing everything about the models (white-box setting). Nonetheless, the heatmaps from BagNets turn out to be more predictive for class-relevant image parts (see also Table 1). In other words, image parts that are relevant to BagNets are similarly relevant for the classification of normal DNNs. VGG-16 is most affected by the masking of local patches while deeper and more performant architectures are more robust to the relatively small masks, which again suggests that deeper architectures take into account larger spatial relationships.

空间敏感性 为了探究BagNets和深度神经网络(DNNs)在图像分类时是否使用相似的图像部分，我们参考了Zintgraf等人(2017年)的研究，测试了当我们对最具预测性的图像部分进行掩码处理时，DNNs的预测结果会如何变化。在图8(上)中，我们比较了随着被掩码的 $8 \times  8$ 图像块数量增加，预测类别概率的下降情况。掩码位置由BagNets的热力图确定，我们还将其与随机掩码以及几种流行的归因技术(Baehrens等人，2010年；Sundararajan等人，2017年；Kindermans等人，2018年；Shrikumar等人，2017年)进行了对比(我们使用了DeepExplain(Ancona等人，2017年)的实现，该实现可直接在测试模型中计算热力图。请注意，这些归因方法具有优势，因为它们在计算热力图时对模型的所有信息都了如指掌(白盒设置)。尽管如此，BagNets的热力图在预测与类别相关的图像部分方面表现更优(另见表格1)。换句话说，与BagNets相关的图像部分对于普通DNNs的分类同样具有相关性。VGG - 16受局部图像块掩码的影响最大，而更深层、性能更优的架构对相对较小的掩码更具鲁棒性，这再次表明更深层的架构考虑了更大范围的空间关系。

## 5 DISCUSSION & OUTLOOK

## 5 讨论与展望

In this paper we introduced and analysed a novel interpretable DNN architecture - coined BagNets - that classifies images based on linear bag-of-local-features representations. The results demonstrate that even complex perceptual tasks like ImageNet can be solved just based on small image features and without any notion of spatial relationships. In addition we showed that the key properties of BagNets, in particlar invariance to spatial relationships as well as weak interactions between image features, are also present to varying degrees in many common computer vision models like ResNet-50

在本文中，我们介绍并分析了一种新颖的可解释深度神经网络架构——我们将其命名为BagNets，它基于线性局部特征集合表示对图像进行分类。结果表明，像ImageNet这样复杂的感知任务仅基于小图像特征且无需考虑任何空间关系就可以解决。此外，我们还表明BagNets的关键特性，特别是对空间关系的不变性以及图像特征之间的弱相互作用，在许多常见的计算机视觉模型(如ResNet - 50)中也不同程度地存在。

![0195e036-d19c-71db-a83c-e4017b98e2b1_6_311_1821_1170_303_0.jpg](images/0195e036-d19c-71db-a83c-e4017b98e2b1_6_311_1821_1170_303_0.jpg)

Figure 7: Scatter plots of class-conditional top-5 errors for different models.

图7:不同模型的类别条件前5错误率散点图。

![0195e036-d19c-71db-a83c-e4017b98e2b1_7_308_223_1177_727_0.jpg](images/0195e036-d19c-71db-a83c-e4017b98e2b1_7_308_223_1177_727_0.jpg)

Figure 8: Similarity of image features used for object classification. (Top) Decrease of leading class probability in VGG-16, ResNet-50, ResNet-152 and DenseNet-169 if increasingly more patches are masked according to the heatmaps of BagNets and several popular attribution methods. The faster the decrease the more closely does the heatmap highlight image parts relevant for the model decisions making. Image parts relevant to the BagNets turn out to be similarly relevant for all models and outperform post-hoc attribution methods. (Bottom) The first four heatmaps show attributions computed on VGG-16, the other three heatmaps show the class evidence of BagNets.

图8:用于目标分类的图像特征的相似性。(上)如果根据BagNets的热力图和几种流行的归因方法对越来越多的图像块进行掩码处理，VGG - 16、ResNet - 50、ResNet - 152和DenseNet - 169中主要类别概率的下降情况。下降速度越快，说明热力图越能准确突出与模型决策相关的图像部分。事实证明，与BagNets相关的图像部分对所有模型都具有相似的相关性，并且优于事后归因方法。(下)前四个热力图显示了在VGG - 16上计算的归因结果，另外三个热力图显示了BagNets的类别证据。

<table><tr><td rowspan="2"/><td>Sali- ency</td><td>Int. Grad.</td><td>$\epsilon$ -LRP</td><td>Deep LIFT</td><td>BN-9</td><td>BN-17</td><td>BN-33</td></tr><tr><td colspan="4">white-box</td><td colspan="3">black-box</td></tr><tr><td>VGG-16</td><td>0.369</td><td>0.250</td><td>0.326</td><td>0.162</td><td>0.158</td><td>0.151</td><td>0.193</td></tr><tr><td>ResNet-50</td><td>0.528</td><td>0.492</td><td>0.545</td><td>0.379</td><td>0.281</td><td>0.263</td><td>0.291</td></tr><tr><td>ResNet-152</td><td>0.602</td><td>0.580</td><td>0.614</td><td>0.479</td><td>0.394</td><td>0.371</td><td>0.393</td></tr><tr><td>DenseNet-169</td><td>0.589</td><td>0.515</td><td>0.571</td><td>0.423</td><td>0.339</td><td>0.326</td><td>0.359</td></tr></table>

<table><tbody><tr><td rowspan="2"></td><td>显著性(Saliency)</td><td>内部梯度(Int. Grad.)</td><td>$\epsilon$ - 局部相关传播(-LRP)</td><td>深度提升(Deep LIFT)</td><td>BN - 9</td><td>BN - 17</td><td>BN - 33</td></tr><tr><td colspan="4">白盒(white - box)</td><td colspan="3">黑盒(black - box)</td></tr><tr><td>VGG - 16</td><td>0.369</td><td>0.250</td><td>0.326</td><td>0.162</td><td>0.158</td><td>0.151</td><td>0.193</td></tr><tr><td>残差网络50(ResNet - 50)</td><td>0.528</td><td>0.492</td><td>0.545</td><td>0.379</td><td>0.281</td><td>0.263</td><td>0.291</td></tr><tr><td>残差网络152(ResNet - 152)</td><td>0.602</td><td>0.580</td><td>0.614</td><td>0.479</td><td>0.394</td><td>0.371</td><td>0.393</td></tr><tr><td>密集连接网络169(DenseNet - 169)</td><td>0.589</td><td>0.515</td><td>0.571</td><td>0.423</td><td>0.339</td><td>0.326</td><td>0.359</td></tr></tbody></table>

Table 1: Average probability of leading class after masking the 100 patches ( $8 \times  8$ pixels) with the highest attribution according to different heatmaps (columns).

表1:根据不同的热力图(列)，将归因最高的100个图像块($8 \times  8$像素)进行掩码处理后，主导类别的平均概率。

or VGG-16, suggesting that the decision-making of many DNNs trained on ImageNet follows at least in part a similar bag-of-feature strategy. In contrast to the perceived "leap" in performance from bag-of-feature models to deep neural networks, the representations learnt by DNNs may in the end still be similar to the pre-deep learning era.

或者是VGG - 16，这表明许多在ImageNet数据集上训练的深度神经网络(DNN)的决策至少部分遵循了类似的特征袋策略。与从特征袋模型到深度神经网络在性能上被认为的“飞跃”相反，深度神经网络学习到的表征最终可能仍与深度学习之前的时代相似。

VGG-16 is particularly close to bag-of-feature models, as demonstrated by the weak interactions (Figure 6) and the sensitivity to the same small image patches as BagNets (Figure 8). Deeper networks, on the other hand, exhibit stronger nonlinear interactions between image parts and are less sensitive to local maskings. This might explain why texturisation (Figure 5) works well in VGG-16 but fails for ResNet- and DenseNet-architectures.

如弱交互(图6)以及与BagNets对相同小图像块的敏感性(图8)所示，VGG - 16尤其接近特征袋模型。另一方面，更深的网络在图像各部分之间表现出更强的非线性交互，并且对局部掩码的敏感性较低。这可能解释了为什么纹理化(图5)在VGG - 16中效果良好，但在ResNet和DenseNet架构中却失败了。

Clearly, ImageNet alone is not sufficient to force DNNs to learn more physical and causal representation of the world - simply because such a representation is not necessary to solve the task (local image features are enough). This might explain why DNNs generalise poorly to distribution shifts: a DNN trained on natural images has learnt to recognize the textures and local image features associated with different objects (like the fur and eyes of a cat or the keys of a typewriter) and will inevitably fail if presented with cartoon-like images as they lack the key local image features upon which it bases its decisions.

显然，仅靠ImageNet数据集不足以迫使深度神经网络学习更多关于世界的物理和因果表征——仅仅是因为解决该任务并不需要这样的表征(局部图像特征就足够了)。这可能解释了为什么深度神经网络在分布偏移时泛化能力较差:在自然图像上训练的深度神经网络学会了识别与不同对象相关的纹理和局部图像特征(如猫的皮毛和眼睛，或打字机的按键)，如果给它呈现卡通风格的图像，它必然会失败，因为这些图像缺乏它用于决策的关键局部图像特征。

One way forward is to define novel tasks that cannot be solved using local statistical regularities. Here the BagNets can serve as a way to evaluate a lower-bound on the task performance as a function of the observable length-scales. Furthermore, BagNets can be an interesting tool in any application in which it is desirable to trade some accuracy for better interpretability. For example, BagNets can make it much easier to spot the relevant spatial locations and image features that are predictive of certain diseases in medical imaging. Likewise, they can serve as diagnostic tools to benchmark feature attribution techniques since ground-truth attributions are directly available. BagNets can also serve as interpretable parts of a larger computer vision pipeline (e.g. in autonomous cars) as they make it easier to understand edge and failure cases. We released the pretrained BagNets (BagNet-9, BagNet- 17 and BagNet-33) for PyTorch and Keras at https://github.com/wielandbrendel/ bag-of-local-features-models

一种可行的方法是定义无法通过局部统计规律解决的新任务。在这里，BagNets可以作为一种评估任务性能下限的方法，该下限是可观测长度尺度的函数。此外，在任何希望以一定的准确性换取更好可解释性的应用中，BagNets都可以成为一个有趣的工具。例如，在医学成像中，BagNets可以更容易地找出与某些疾病预测相关的空间位置和图像特征。同样，由于可以直接获得真实的归因，它们可以作为诊断工具来对特征归因技术进行基准测试。BagNets还可以作为更大的计算机视觉流程(如自动驾驶汽车)中可解释的部分，因为它们使我们更容易理解边缘情况和失败情况。我们在https://github.com/wielandbrendel/ bag - of - local - features - models上发布了预训练的BagNets(BagNet - 9、BagNet - 17和BagNet - 33)，适用于PyTorch和Keras。

Taken together, DNNs might be more powerful than previous hand-tuned bag-of-feature algorithms in discovering weak statistical regularities, but that does not necessarily mean that they learn substantially different representations. We hope that this work will encourage and inspire future work to adapt tasks, architectures and training algorithms to encourage models to learn more causal models of the world.

综上所述，深度神经网络在发现微弱的统计规律方面可能比以前手动调整的特征袋算法更强大，但这并不一定意味着它们学习到了本质上不同的表征。我们希望这项工作能够鼓励和启发未来的研究，调整任务、架构和训练算法，促使模型学习更多关于世界的因果模型。

## ACKNOWLEDGMENTS

## 致谢

This work has been funded, in part, by the German Research Foundation (DFG CRC 1233 on "Robust Vision") as well as by the Intelligence Advanced Research Projects Activity (IARPA) via Department of Interior / Interior Business Center (DoI/IBC) contract number D16PC00003.

这项工作部分由德国研究基金会(DFG CRC 1233，项目名称为“鲁棒视觉”)资助，以及由高级情报研究计划局(IARPA)通过内政部/内政业务中心(DoI/IBC)合同号D16PC00003资助。

## REFERENCES

## 参考文献

Marco Ancona, Enea Ceolini, Cengiz Öztireli, and Markus Gross. Towards better understanding of gradient-based attribution methods for deep neural networks, 2017. URL http://arxiv org/abs/1711.06104

Marco Ancona、Enea Ceolini、Cengiz Öztireli和Markus Gross。《深入理解基于梯度的深度神经网络归因方法》，2017年。网址:http://arxiv org/abs/1711.06104

Relja Arandjelovic, Petr Gronát, Akihiko Torii, Tomás Pajdla, and Josef Sivic. Netvlad: CNN architecture for weakly supervised place recognition. CoRR, abs/1511.07247, 2015. URL http: //arxiv.org/abs/1511.07247

Relja Arandjelovic、Petr Gronát、Akihiko Torii、Tomás Pajdla和Josef Sivic。《Netvlad:用于弱监督地点识别的卷积神经网络架构》。计算机研究报告，编号abs/1511.07247，2015年。网址:http://arxiv.org/abs/1511.07247

Artem Babenko and Victor S. Lempitsky. Aggregating deep convolutional features for image retrieval. CoRR, abs/1510.07493, 2015. URL http://arxiv.org/abs/1510.07493

Artem Babenko和Victor S. Lempitsky。《聚合深度卷积特征用于图像检索》。计算机研究报告，编号abs/1510.07493，2015年。网址:http://arxiv.org/abs/1510.07493

David Baehrens, Timon Schroeter, Stefan Harmeling, Motoaki Kawanabe, Katja Hansen, and Klaus-Robert Müller. How to explain individual classification decisions. Journal of Machine Learning Research, 11:1803-1831, 2010.

David Baehrens、Timon Schroeter、Stefan Harmeling、Motoaki Kawanabe、Katja Hansen和Klaus - Robert Müller。《如何解释个体分类决策》。《机器学习研究杂志》，第11卷:1803 - 1831页，2010年。

Jiewei Cao, Zi Huang, and Heng Tao Shen. Local deep descriptors in bag-of-words for image retrieval. In Proceedings of the on Thematic Workshops of ACM Multimedia 2017, Thematic Workshops '17, pp. 52-58, New York, NY, USA, 2017. ACM. ISBN 978-1-4503-5416-5. doi: 10.1145/3126686.3127018.

曹杰伟、黄子、沈恒涛。用于图像检索的词袋模型中的局部深度描述符。《2017 年 ACM 多媒体专题研讨会论文集》，专题研讨会 '17，第 52 - 58 页，美国纽约州纽约市，2017 年。美国计算机协会。ISBN 978 - 1 - 4503 - 5416 - 5。doi: 10.1145/3126686.3127018。

Ken Chatfield, Karen Simonyan, Andrea Vedaldi, and Andrew Zisserman. Return of the devil in the details: Delving deep into convolutional nets. In Michel François Valstar, Andrew P. French, and Tony P. Pridmore (eds.), BMVC. BMVA Press, 2014.

肯·查特菲尔德、凯伦·西蒙扬、安德里亚·韦尔迪耶、安德鲁·齐斯曼。细节决定成败:深入探究卷积网络。载于米歇尔·弗朗索瓦·瓦尔斯特、安德鲁·P·弗伦奇、托尼·P·普里德莫尔(编)，《英国机器视觉会议》。英国机器视觉协会出版社，2014 年。

Chaofan Chen, Oscar Li, Alina Barnett, Jonathan Su, and Cynthia Rudin. This looks like that: deep learning for interpretable image recognition. CoRR, abs/1806.10574, 2018. URL http: //arxiv.org/abs/1806.10574

陈超凡、奥斯卡·李、阿丽娜·巴尼特、乔纳森·苏、辛西娅·鲁丁。“这个看起来像那个”:用于可解释图像识别的深度学习。预印本论文库，编号 abs/1806.10574，2018 年。网址:http://arxiv.org/abs/1806.10574

G. Csurka, C. Bray, C. Dance, and L. Fan. Visual categorization with bags of keypoints. Workshop on Statistical Learning in Computer Vision, ECCV, pp. 1-22, 2004.

G. 丘尔卡、C. 布雷、C. 丹斯、L. 范。基于关键点词袋的视觉分类。《计算机视觉统计学习研讨会》，欧洲计算机视觉会议，第 1 - 22 页，2004 年。

Jiangfan Feng, Yuanyuan Liu, and Lin Wu. Bag of visual words model with deep spatial features for

冯江帆、刘媛媛、吴琳。具有深度空间特征的视觉词袋模型用于

geographical scene classification. Comp. Int. and Neurosc., 2017:5169675:1-5169675:14, 2017.

地理场景分类。《计算智能与神经科学》，2017 年:5169675:1 - 5169675:14，2017 年。

Leon A. Gatys, Alexander S. Ecker, and Matthias Bethge. Texture synthesis and the controlled generation of natural stimuli using convolutional neural networks. CoRR, abs/1505.07376, 2015.

莱昂·A·加蒂斯、亚历山大·S·埃克、马蒂亚斯·贝格。使用卷积神经网络进行纹理合成和自然刺激的可控生成。预印本论文库，编号 abs/1505.07376，2015 年。

Yunchao Gong, Liwei Wang, Ruiqi Guo, and Svetlana Lazebnik. Multi-scale orderless pooling of deep convolutional activation features. In David J. Fleet, Tomás Pajdla, Bernt Schiele, and Tinne Tuytelaars (eds.), ECCV (7), volume 8695 of Lecture Notes in Computer Science, pp. 392-407. Springer, 2014. ISBN 978-3-319-10583-3.

龚云超、王利伟、郭瑞琪、斯韦特兰娜·拉泽布尼克。深度卷积激活特征的多尺度无序池化。载于大卫·J·弗利特、托马斯·帕伊德拉、伯恩特·席勒、廷内·图伊特拉尔斯(编)，《欧洲计算机视觉会议(第 7 部分)》，《计算机科学讲义》第 8695 卷，第 392 - 407 页。施普林格出版社，2014 年。ISBN 978 - 3 - 319 - 10583 - 3。

Kaiming He, Xiangyu Zhang, Shaoqing Ren, and Jian Sun. Deep residual learning for image recognition. CoRR, abs/1512.03385, 2015.

何恺明、张祥雨、任少卿、孙剑。用于图像识别的深度残差学习。预印本论文库，编号 abs/1512.03385，2015 年。

Geoffrey Hinton, Oriol Vinyals, and Jeff Dean. Distilling the knowledge in a neural network, 2015.

杰弗里·辛顿、奥里奥尔·温亚尔斯、杰夫·迪恩。蒸馏神经网络中的知识，2015 年。

Frédéric Jurie and Bill Triggs. Creating efficient codebooks for visual recognition. In ICCV, pp. 604-610, 2005.

弗雷德里克·朱里、比尔·特里格斯。为视觉识别创建高效码本。《国际计算机视觉会议》，第 604 - 610 页，2005 年。

Fahad Shahbaz Khan, Joost van de Weijer, Rao Muhammad Anwer, Andrew D. Bagdanov, Michael Felsberg, and Jorma Laaksonen. Scale coding bag of deep features for human attribute and action recognition. CoRR, abs/1612.04884, 2016.

法哈德·沙赫巴兹·汗、约斯特·范德韦杰、拉奥·穆罕默德·安瓦尔、安德鲁·D·巴格丹诺夫、迈克尔·费尔斯伯格、约尔马·拉卡森。用于人类属性和动作识别的深度特征尺度编码词袋。预印本论文库，编号 abs/1612.04884，2016 年。

Pieter-Jan Kindermans, Kristof T Schütt, Maximilian Alber, Klaus-Robert Müller, Dumitru Er-han, Been Kim, and Sven Dähne. Learning how to explain neural networks: Patternnet and patternattribution. In 6th International Conference on Learning Representations, 2018.

彼得 - 扬·金德曼斯、克里斯托夫·T·舒特、马克西米利安·阿尔伯、克劳斯 - 罗伯特·米勒、杜米特鲁·埃尔汉、金·贝恩、斯文·达恩。学习如何解释神经网络:模式网络和模式归因。《第六届国际学习表征会议》，2018 年。

Alex Krizhevsky, Ilya Sutskever, and Geoffrey E Hinton. Imagenet classification with deep convolutional neural networks. In Advances in neural information processing systems, pp. 1097-1105, 2012.

亚历克斯·克里兹夫斯基、伊利亚·苏茨克维、杰弗里·E·辛顿。使用深度卷积神经网络进行 ImageNet 图像分类。《神经信息处理系统进展》，第 1097 - 1105 页，2012 年。

Svetlana Lazebnik, Cordelia Schmid, and Jean Ponce. Beyond bags of features: Spatial pyramid matching for recognizing natural scene categories. 2006.

斯韦特兰娜·拉泽布尼克、科迪莉亚·施密德、让·庞塞。超越特征词袋:用于自然场景类别识别的空间金字塔匹配。2006 年。

Oscar Li, Hao Liu, Chaofan Chen, and Cynthia Rudin. Deep learning for case-based reasoning through prototypes: A neural network that explains its predictions. CoRR, abs/1710.04806, 2017. URL http://arxiv.org/abs/1710.04806

奥斯卡·李、刘浩、陈超凡、辛西娅·鲁丁。通过原型进行基于案例推理的深度学习:一个解释其预测的神经网络。预印本论文库，编号 abs/1710.04806，2017 年。网址:http://arxiv.org/abs/1710.04806

Eva Mohedano, Kevin McGuinness, Noel E. O'Connor, Amaia Salvador, Ferran Marques, and Xavier Giro-i Nieto. Bags of local convolutional features for scalable instance search. In Proceedings of the 2016 ACM on International Conference on Multimedia Retrieval, ICMR '16, pp. 327-331, New York, NY, USA, 2016. ACM. ISBN 978-1-4503-4359-6. doi: 10.1145/2911996.2912061. URL http://doi.acm.org/10.1145/2911996.2912061.

伊娃·莫埃达诺(Eva Mohedano)、凯文·麦吉尼斯(Kevin McGuinness)、诺埃尔·E·奥康纳(Noel E. O'Connor)、阿玛亚·萨尔瓦多(Amaia Salvador)、费兰·马奎斯(Ferran Marques)和哈维尔·希罗 - 涅托(Xavier Giro - i Nieto)。用于可扩展实例搜索的局部卷积特征包。收录于《2016 年 ACM 国际多媒体检索会议论文集》(Proceedings of the 2016 ACM on International Conference on Multimedia Retrieval)，ICMR '16，第 327 - 331 页，美国纽约，2016 年。美国计算机协会(ACM)。ISBN 978 - 1 - 4503 - 4359 - 6。doi: 10.1145/2911996.2912061。网址:http://doi.acm.org/10.1145/2911996.2912061。

Joe Yue-Hei Ng, Fan Yang, and Larry S. Davis. Exploiting local features from deep networks for image retrieval. In CVPR Workshops, pp. 53-61. IEEE Computer Society, 2015. ISBN 978-1-4673-6759-2.

吴岳熙(Joe Yue - Hei Ng)、杨帆(Fan Yang)和拉里·S·戴维斯(Larry S. Davis)。利用深度网络的局部特征进行图像检索。收录于《计算机视觉与模式识别研讨会论文集》(CVPR Workshops)，第 53 - 61 页。电气与电子工程师协会计算机学会(IEEE Computer Society)，2015 年。ISBN 978 - 1 - 4673 - 6759 - 2。

Stephen O'Hara and Bruce A. Draper. Introduction to the bag of features paradigm for image classification and retrieval. abs/1101.3354, 2011.

斯蒂芬·奥哈拉(Stephen O'Hara)和布鲁斯·A·德雷珀(Bruce A. Draper)。特征包范式在图像分类和检索中的介绍。预印本编号 abs/1101.3354，2011 年。

Edouard Oyallon, Eugene Belilovsky, and Sergey Zagoruyko. Scaling the scattering transform: Deep hybrid networks. CoRR, abs/1703.08961, 2017. URL http://arxiv.org/abs/1703.08961

爱德华·奥亚隆(Edouard Oyallon)、叶夫根尼·贝利洛夫斯基(Eugene Belilovsky)和谢尔盖·扎戈鲁科(Sergey Zagoruyko)。扩展散射变换:深度混合网络。预印本库(CoRR)，预印本编号 abs/1703.08961，2017 年。网址:http://arxiv.org/abs/1703.08961

Pedro H. O. Pinheiro and Ronan Collobert. Weakly supervised semantic segmentation with convolutional networks. CoRR, abs/1411.6228, 2014. URL http://arxiv.org/abs/1411.6228.

佩德罗·H·O·平heiro(Pedro H. O. Pinheiro)和罗南·科洛贝尔(Ronan Collobert)。基于卷积网络的弱监督语义分割。预印本库(CoRR)，预印本编号 abs/1411.6228，2014 年。网址:http://arxiv.org/abs/1411.6228。

Avanti Shrikumar, Peyton Greenside, and Anshul Kundaje. Learning important features through propagating activation differences. CoRR, abs/1704.02685, 2017.

阿凡提·什里库马尔(Avanti Shrikumar)、佩顿·格林赛德(Peyton Greenside)和安舒尔·昆达吉(Anshul Kundaje)。通过传播激活差异学习重要特征。预印本库(CoRR)，预印本编号 abs/1704.02685，2017 年。

Mukund Sundararajan, Ankur Taly, and Qiqi Yan. Axiomatic attribution for deep networks. CoRR, abs/1703.01365, 2017.

穆昆德·桑达拉扬(Mukund Sundararajan)、安库尔·塔利(Ankur Taly)和闫琪琪(Qiqi Yan)。深度网络的公理归因。预印本库(CoRR)，预印本编号 abs/1703.01365，2017 年。

Peng Tang, Xinggang Wang, Baoguang Shi, Xiang Bai, Wenyu Liu, and Zhuowen Tu. Deep fishernet for object classification. CoRR, abs/1608.00182, 2016. URL http://arxiv.org/abs/ 1608.00182

唐鹏、王兴刚、史宝光、白翔、刘文宇和涂卓文。用于目标分类的深度费舍尔网络。预印本库(CoRR)，预印本编号 abs/1608.00182，2016 年。网址:http://arxiv.org/abs/ 1608.00182

Peng Tang, Xinggang Wang, Zilong Huang, Xiang Bai, and Wenyu Liu. Deep patch learning for weakly supervised object classification and discovery. CoRR, abs/1705.02429, 2017. URL http://arxiv.org/abs/1705.02429

唐鹏、王兴刚、黄紫龙、白翔和刘文宇。用于弱监督目标分类和发现的深度补丁学习。预印本库(CoRR)，预印本编号 abs/1705.02429，2017 年。网址:http://arxiv.org/abs/1705.02429

Yunchao Wei, Wei Xia, Min Lin, Junshi Huang, Bingbing Ni, Jian Dong, Yao Zhao, and Shuicheng Yan. Hcp: A flexible cnn framework for multi-label image classification. IEEE Trans. Pattern Anal. Mach. Intell., 38, 2016.

魏云超、夏伟、林敏、黄军仕、倪冰冰、董健、赵耀和颜水成。Hcp:一种用于多标签图像分类的灵活卷积神经网络框架。《电气与电子工程师协会模式分析与机器智能汇刊》(IEEE Trans. Pattern Anal. Mach. Intell.)，第 38 卷，2016 年。

Tianjun Xiao, Yichong Xu, Kuiyuan Yang, Jiaxing Zhang, Yuxin Peng, and Zheng Zhang. The application of two-level attention models in deep convolutional neural network for fine-grained image classification. In IEEE Conference on Computer Vision and Pattern Recognition, CVPR 2015, Boston, MA, USA, June 7-12, 2015, pp. 842-850, 2015. doi: 10.1109/CVPR.2015.7298685. URL https://doi.org/10.1109/CVPR.2015.7298685

肖天军、徐一冲、杨奎元、张嘉兴、彭宇新和张政。两级注意力模型在深度卷积神经网络细粒度图像分类中的应用。收录于《电气与电子工程师协会计算机视觉与模式识别会议论文集》(IEEE Conference on Computer Vision and Pattern Recognition)，CVPR 2015，美国马萨诸塞州波士顿，2015 年 6 月 7 - 12 日，第 842 - 850 页，2015 年。doi: 10.1109/CVPR.2015.7298685。网址:https://doi.org/10.1109/CVPR.2015.7298685

Jianguo Zhang, Marcin Marszalek, Svetlana Lazebnik, and Cordelia Schmid. Local features and kernels for classification of texture and object categories: A comprehensive study. International Journal of Computer Vision, 73(2):213-238, 2007.

张建国、马尔钦·马尔沙莱克(Marcin Marszalek)、斯韦特兰娜·拉泽布尼克(Svetlana Lazebnik)和科迪莉亚·施密德(Cordelia Schmid)。用于纹理和目标类别分类的局部特征和核函数:一项全面研究。《国际计算机视觉杂志》(International Journal of Computer Vision)，73(2):213 - 238，2007 年。

Bolei Zhou, Aditya Khosla, Ågata Lapedriza, Aude Oliva, and Antonio Torralba. Learning deep features for discriminative localization. CoRR, abs/1512.04150, 2015. URL http://arxiv.org/abs/1512.04150

周博磊、阿迪亚·科斯拉(Aditya Khosla)、阿加塔·拉佩德里扎(Ågata Lapedriza)、奥德·奥利瓦(Aude Oliva)和安东尼奥·托拉尔巴(Antonio Torralba)。用于判别式定位的深度特征学习。预印本库(CoRR)，预印本编号 abs/1512.04150，2015 年。网址:http://arxiv.org/abs/1512.04150

Luisa M. Zintgraf, Taco S. Cohen, Tameem Adel, and Max Welling. Visualizing deep neural network decisions: Prediction difference analysis. CoRR, abs/1702.04595, 2017.

路易莎·M·津特格拉夫(Luisa M. Zintgraf)、塔科·S·科恩(Taco S. Cohen)、塔米姆·阿德尔(Tameem Adel)和马克斯·韦林(Max Welling)。可视化深度神经网络决策:预测差异分析。预印本库(CoRR)，预印本编号 abs/1702.04595，2017 年。

## A APPENDIX

## A 附录

The architecture of the BagNets is detailed in Figure A.1. Training of the models was performed in PyTorch using the default ImageNet training script of Torchvision (https://github.com/ pytorch/vision, commit 8a4786a) with default parameters. In brief, we used SGD with momentum (0.9), a batchsize of 256 and an initial learning rate of 0.01 which we decreased by a factor of 10 every 30 epochs. Images were resized to 256 pixels (shortest side) after which we extracted a random crop of size ${224} \times  {224}$ pixels.

BagNet网络架构的详细信息如图A.1所示。模型训练使用PyTorch，采用Torchvision的默认ImageNet训练脚本(https://github.com/ pytorch/vision，提交版本8a4786a)并使用默认参数。简而言之，我们使用带动量(0.9)的随机梯度下降法(SGD)，批量大小为256，初始学习率为0.01，每30个训练周期将学习率降低为原来的1/10。图像被调整为256像素(最短边)，然后我们随机裁剪出大小为 ${224} \times  {224}$ 像素的图像块。

![0195e036-d19c-71db-a83c-e4017b98e2b1_11_580_561_647_1342_0.jpg](images/0195e036-d19c-71db-a83c-e4017b98e2b1_11_580_561_647_1342_0.jpg)

Figure A.1: The BagNet architecture is almost equivalent to the ResNet-50 architectures except for a few changes in the strides and the replacement of most $3 \times  3$ convolutions with $1 \times  1$ convolutions. Each ResNet block has an expansion of size four (that means the number of output feature maps is four times the number of feature maps within the block). The downsampling operation (dashed arrows) is a simple $1 \times  1$ convolution with stride 2 .

图A.1:BagNet架构与ResNet - 50架构几乎相同，只是在步长上有一些变化，并且将大多数 $3 \times  3$ 卷积替换为 $1 \times  1$ 卷积。每个ResNet模块的扩展系数为4(即输出特征图的数量是模块内特征图数量的4倍)。下采样操作(虚线箭头)是一个简单的步长为2的 $1 \times  1$ 卷积。

![0195e036-d19c-71db-a83c-e4017b98e2b1_12_309_199_1176_1875_0.jpg](images/0195e036-d19c-71db-a83c-e4017b98e2b1_12_309_199_1176_1875_0.jpg)

Figure A.2: Feature attributions of VGG generated using different methods (Saliency, Integrated Gradients, $\epsilon$ -LRP and DeepLIFT) and feature attributions of BagNets.

图A.2:使用不同方法(显著性图、积分梯度、$\epsilon$ - LRP和深度提升法)生成的VGG特征归因以及BagNet的特征归因。

![0195e036-d19c-71db-a83c-e4017b98e2b1_13_325_189_1166_1938_0.jpg](images/0195e036-d19c-71db-a83c-e4017b98e2b1_13_325_189_1166_1938_0.jpg)

Figure A.3: Same as Figure 3 but for more classes.

图A.3:与图3相同，但涉及更多类别。

### A.1 EFFECT OF LOGIT THRESHOLDING

### A.1 对数阈值的影响

We tested how sensitive the classification accuracy of BagNet-33 is with respect to the exact values of the logits for each patch. To this end we thresholded the logits in two ways: first, by setting all values below the threshold to the threshold (and all values above the threshold stay as is). In the second case we binarized the heatmaps by setting all values below the threshold to zero and all values above the threshold to one (this completely removes the amplitude). The results can be found in Figure A.4 Most interestingly, for certain binarization thresholds the top-5 accuracy is within 3-4% of the vanilla BagNet performance. This indicates that the amplitude of the heatmaps is not decisive.

我们测试了BagNet - 33的分类准确率对每个图像块对数的确切值的敏感程度。为此，我们以两种方式对对数进行阈值处理:首先，将所有低于阈值的值设置为阈值(高于阈值的值保持不变)。在第二种情况下，我们将热力图二值化，将所有低于阈值的值设置为0，高于阈值的值设置为1(这完全消除了幅值信息)。结果如图A.4所示。最有趣的是，对于某些二值化阈值，前5准确率与原始BagNet性能相差在3 - 4%以内。这表明热力图的幅值并非决定性因素。

![0195e036-d19c-71db-a83c-e4017b98e2b1_14_309_546_1168_549_0.jpg](images/0195e036-d19c-71db-a83c-e4017b98e2b1_14_309_546_1168_549_0.jpg)

Figure A.4: Effect of thresholding the logits on the model performance (top-5 accuracy).

图A.4:对数阈值处理对模型性能(前5准确率)的影响。

