# A Novel Neural-symbolic System under Statistical Relational Learning

# 统计关系学习下的新型神经符号系统

Dongran ${\mathrm{{Yu}}}^{1,2}$ , Xueyan ${\mathrm{{Liu}}}^{1,{4}^{ * }}$ , Shirui ${\mathrm{{Pan}}}^{3}$ , Anchen ${\mathrm{{Li}}}^{1,4}$ and Bo ${\mathrm{{Yang}}}^{1,{4}^{ * }}$

董然 ${\mathrm{{Yu}}}^{1,2}$ ，薛妍 ${\mathrm{{Liu}}}^{1,{4}^{ * }}$ ，史瑞 ${\mathrm{{Pan}}}^{3}$ ，安晨 ${\mathrm{{Li}}}^{1,4}$ 和薄 ${\mathrm{{Yang}}}^{1,{4}^{ * }}$

${}^{1}$ The Key Laboratory of Symbolic Computation and Knowledge Engineer, Ministry of Education, Jilin University, Changchun, 130012, Jilin, China.

${}^{1}$ 吉林大学符号计算与知识工程教育部重点实验室，吉林长春 130012

${}^{2}$ School of Artificial Intelligence, Jilin University, Changchun,130012, Jilin, China. ${}^{3}$ School of Information and Communication Technology, Griffith University, Brisbane, 4222, Queensland, Australia.

${}^{2}$ 吉林大学人工智能学院，吉林长春 130012。${}^{3}$ 格里菲斯大学信息与通信技术学院，澳大利亚昆士兰州布里斯班 4222

${}^{4}$ School of Computer Science and Technology, Jilin University, Changchun,130012, Jilin, China.

${}^{4}$ 吉林大学计算机科学与技术学院，吉林长春 130012

*Corresponding author(s). E-mail(s): xueyanliu@jlu.edu.cn; ybo@jlu.edu.cn; Contributing authors: yudran@foxmail.com; xueyanliu@jlu.edu.cn; s.pan@griffith.edu.au; liac20@mails.jlu.edu.cn; ybo@jlu.edu.cn;

*通讯作者。电子邮箱:xueyanliu@jlu.edu.cn；ybo@jlu.edu.cn；贡献作者:yudran@foxmail.com；xueyanliu@jlu.edu.cn；s.pan@griffith.edu.au；liac20@mails.jlu.edu.cn；ybo@jlu.edu.cn;

## Abstract

## 摘要

A key objective in field of artificial intelligence is to develop cognitive models that can exhibit humanlike intellectual capabilities. One promising approach to achieving this is through neural-symbolic systems, which combine the strengths of deep learning and symbolic reasoning. However, current approaches in this area have been limited in their combining way, generalization and interpretability. To address these limitations, we propose a general bi-level probabilistic graphical reasoning framework called GBPGR. This framework leverages statistical relational learning to effectively integrate deep learning models and symbolic reasoning in a mutually beneficial manner. In GBPGR, the results of symbolic reasoning are utilized to refine and correct the predictions made by the deep learning models. At the same time, the deep learning models assist in enhancing the efficiency of the symbolic reasoning process. Through extensive experiments, we demonstrate that our approach achieves high performance and exhibits effective generalization in both transductive and inductive tasks.

人工智能领域的一个关键目标是开发能够展现类人智能能力的认知模型。实现这一目标的一个有前景的方法是通过神经符号系统，它结合了深度学习和符号推理的优势。然而，目前该领域的方法在结合方式、泛化能力和可解释性方面存在局限性。为解决这些局限性，我们提出了一个名为GBPGR的通用双层概率图推理框架。该框架利用统计关系学习，以互利的方式有效整合深度学习模型和符号推理。在GBPGR中，符号推理的结果用于细化和纠正深度学习模型的预测。同时，深度学习模型有助于提高符号推理过程的效率。通过大量实验，我们证明了我们的方法在直推式和归纳式任务中都取得了高性能，并展现出有效的泛化能力。

Keywords: Neural-symbolic systems, Deep learning, Statistical relational learning, Markov logic networks

关键词:神经符号系统；深度学习；统计关系学习；马尔可夫逻辑网络

Human cognitive systems consist of perception and reasoning. Specifically, perception is primarily responsible for recognizing information, while reasoning is responsible for thinking and logically deducing information. When humans process information, they combine both perception and reasoning to maximize their ability to comprehend and analyze information. Artificial intelligence (AI) systems already exist that possess either perception or reasoning capabilities. For instance, deep learning models excel at perception and have achieved remarkable performance in various perception tasks. They demonstrate inductive learning capabilities and computational efficiency. In contrast, symbolic logic is adept at logical reasoning and has yielded impressive results in reasoning tasks. It boasts deductive reasoning abilities, generalization, and interpretability. However, both types of models still have their limitations. Deep learning models often operate as black boxes, lacking interpretability, exhibiting weak generalization, and requiring large amounts of training data to perform satisfactorily. Conversely, symbolic logic relies on search algorithms to find solutions in the search space, which can result in slow reasoning when confronted with large search spaces. Hence, by combining and leveraging the strengths of both approaches, we can integrate the processes of perception and reasoning into a unified framework, mimicking the human cognitive system more effectively. Indeed, Leslie G. Valiant, the Turing Award winner, considers that reconciling the statistical nature of learning and the logical nature of reasoning to build a cognitive computing model that integrates concept learning and concept manipulation is one of the three fundamental problems and challenges of computer science [1].

人类认知系统由感知和推理组成。具体来说，感知主要负责识别信息，而推理负责思考和逻辑推导信息。当人类处理信息时，他们会将感知和推理结合起来，以最大限度地提高理解和分析信息的能力。已经存在具备感知或推理能力的人工智能(AI)系统。例如，深度学习模型在感知方面表现出色，在各种感知任务中取得了显著的性能。它们展示了归纳学习能力和计算效率。相比之下，符号逻辑擅长逻辑推理，在推理任务中取得了令人印象深刻的结果。它拥有演绎推理能力、泛化能力和可解释性。然而，这两种类型的模型仍然存在局限性。深度学习模型通常像黑匣子一样运行，缺乏可解释性，泛化能力较弱，并且需要大量的训练数据才能表现良好。相反，符号逻辑依靠搜索算法在搜索空间中寻找解决方案，当面对大的搜索空间时，推理速度可能会很慢。因此，通过结合和利用这两种方法的优势，我们可以将感知和推理过程整合到一个统一的框架中，更有效地模拟人类认知系统。事实上，图灵奖获得者莱斯利·G·瓦利安特认为，调和学习的统计性质和推理的逻辑性质，以构建一个集成概念学习和概念操作的认知计算模型，是计算机科学的三个基本问题和挑战之一 [1]。

The neural-symbolic system is a promising approach that successfully integrates perception and reasoning into a unified framework [2-4]. Various neural-symbolic systems have emerged, which can be broadly classified into three categories [5]: learning for reasoning methods, reasoning for learning methods, and learning-reasoning methods. Learning for reasoning methods [6-8] primarily focus on symbolic reasoning. Reasoning for learning approaches [9-11] primarily emphasize the role of deep learning models. Only a few studies explore learning-reasoning methods to achieve a more comprehensive integration $\left\lbrack  {{12},{13}}\right\rbrack$ . While these approaches has made significant progress in neural-symbolic systems field, it remains an open problem that requires further exploration and research.

神经符号系统是一种有前途的方法，它成功地将感知和推理整合到一个统一的框架中 [2 - 4]。已经出现了各种神经符号系统，大致可以分为三类 [5]:推理学习方法、学习推理方法和学习 - 推理方法。推理学习方法 [6 - 8] 主要关注符号推理。学习推理方法 [9 - 11] 主要强调深度学习模型的作用。只有少数研究探索学习 - 推理方法以实现更全面的整合 $\left\lbrack  {{12},{13}}\right\rbrack$ 。虽然这些方法在神经符号系统领域取得了显著进展，但这仍然是一个需要进一步探索和研究的开放性问题。

This paper introduces a novel framework, called the general bi-level probabilistic graph reasoning framework (GBPGR), to integrate deep learning models with symbolic reasoning in a mutually beneficial manner. In GBPGR, symbolic reasoning assists the deep learning models by making their predictions more logical, consistent with common sense, and interpretable, thereby improving their generalization capabilities. On the other hand, the deep learning models aid symbolic reasoning by enhancing their efficiency and robustness to noise. Symbolic reasoning takes inputs from deep learning and learns a joint probability distribution based on first-order logic (FOL). This joint probability distribution is then used to infer the values of arbitrary variables. However, there are two challenges when building the two-layer structure: (1) how to combine both deep learning and symbolic reasoning to model a joint probability distribution with FOL; (2) how to train it in an end-to-end pose. Overcoming these challenges is crucial for successfully implementing the GBPGR framework.

本文介绍了一种名为通用双层概率图推理框架(GBPGR)的新型框架，旨在以互利的方式将深度学习模型与符号推理相结合。在GBPGR中，符号推理通过使深度学习模型的预测更具逻辑性、符合常识且具有可解释性，从而提高其泛化能力。另一方面，深度学习模型通过提高符号推理的效率和对噪声的鲁棒性来辅助符号推理。符号推理从深度学习获取输入，并基于一阶逻辑(FOL)学习联合概率分布。然后使用该联合概率分布来推断任意变量的值。然而，构建两层结构时存在两个挑战:(1)如何将深度学习和符号推理相结合，以一阶逻辑对联合概率分布进行建模；(2)如何以端到端的方式对其进行训练。克服这些挑战对于成功实现GBPGR框架至关重要。

The proposed GBPGR framework leverages the techniques of statistical relational learning (SRL) to address the challenge (1). SRL combines First-order logics (FOLs, relation models) and probabilistic graphical models (statistical models), serving as a bridge between relational and statistical learning [14]. This integration provides logical semantics to probabilistic graphical models and effectively captures uncertainty. Specifically, FOLs are represented as undirected graphs using Markov Logic Networks (MLNs) [15] as the low-level layer of the GBPGR framework. MLNs enable the unification of FOLs and probabilistic graphical models into a single representation [16]. The prediction results of the deep learning models serve as nodes in the high-level layer. To establish connections between the two layers of the framework, edges are created based on identifiers and the number of variables in the predicate. This process enables constructing a joint probability distribution involving both the probabilistic graphical model with FOLs and the deep learning models. By incorporating SRL techniques and building a joint probability distribution, the GBPGR enables the integration of symbolic reasoning and deep learning models, thereby facilitating a mutually beneficial interaction between perception and reasoning processes.

所提出的GBPGR框架利用统计关系学习(SRL)技术来应对挑战(1)。统计关系学习将一阶逻辑(FOL，关系模型)和概率图模型(统计模型)相结合，充当关系学习和统计学习之间的桥梁[14]。这种集成赋予概率图模型逻辑语义，并有效捕捉不确定性。具体而言，使用马尔可夫逻辑网络(MLN)[15]将一阶逻辑表示为无向图，作为GBPGR框架的底层。马尔可夫逻辑网络能够将一阶逻辑和概率图模型统一为单一表示[16]。深度学习模型的预测结果作为高层的节点。为了在框架的两层之间建立连接，根据标识符和谓词中的变量数量创建边。这个过程使得能够构建一个涉及带有一阶逻辑的概率图模型和深度学习模型的联合概率分布。通过结合统计关系学习技术并构建联合概率分布，GBPGR实现了符号推理和深度学习模型的集成，从而促进感知和推理过程之间的互利交互。

To address the challenge (2), we use the variational EM algorithm to train the model. Specifically, the workflow of GBPGR contains two steps: concept learning and concept manipulation, as shown in Fig. 1. During concept learning, the deep learning models learn a mapping function from the training data to concepts, such as "stripe". Subsequently, these acquired concepts serve as elements for symbolic reasoning, allowing the model to learn a joint probability distribution and infer results. Once the model is trained, it can execute concept manipulations in both transductive and inductive scenarios. In the transductive settings, the model recognizes samples within the training data. In the inductive scenario, the model recognizes samples not encountered during the training process through symbolic reasoning. This capacity for symbolic reasoning enables the model to handle previously unseen data and extend its capabilities beyond the training set.

为了应对挑战(2)，我们使用变分期望最大化(EM)算法来训练模型。具体而言，GBPGR的工作流程包含两个步骤:概念学习和概念操作，如图1所示。在概念学习期间，深度学习模型学习从训练数据到概念(如“条纹”)的映射函数。随后，这些获取的概念作为符号推理的元素，使模型能够学习联合概率分布并推断结果。一旦模型训练完成，它可以在直推式和归纳式场景中执行概念操作。在直推式设置中，模型识别训练数据中的样本。在归纳式场景中，模型通过符号推理识别训练过程中未遇到的样本。这种符号推理能力使模型能够处理以前未见过的数据，并将其能力扩展到训练集之外。

![0195ea34-fd6a-7872-b55f-5da9e4b421ce_2_147_166_1442_780_0.jpg](images/0195ea34-fd6a-7872-b55f-5da9e4b421ce_2_147_166_1442_780_0.jpg)

Fig. 1 Overview of GBPGR. The concept learning aims to acquire fundamental concepts such as "catlike", "tawny" and "spot" from train data. In transductive concept manipulation, the learned concepts and the original rules are employed to test data whose labels have occurred in the training sets. Incorporating these learned concepts endows GBPGR with interpretability, as it provides insights into how the prediction results are derived based on them in conjunction with the rules. Conversely, in inductive concept manipulation, the function of the learned concepts as the rule body, and new rules are introduced to reason the result when testing a new sample whose label has never appeared in the training set.

图1 GBPGR概述。概念学习旨在从训练数据中获取基本概念，如“猫样”、“黄褐色”和“斑点”。在直推式概念操作中，使用学习到的概念和原始规则来测试标签已在训练集中出现过的数据。结合这些学习到的概念使GBPGR具有可解释性，因为它提供了关于如何根据这些概念结合规则得出预测结果的见解。相反，在归纳式概念操作中，学习到的概念作为规则体发挥作用，并在测试标签从未在训练集中出现过的新样本时引入新规则来推理结果。

In our previous conference paper [17], we provided an initial presentation and validation of the proposed idea on visual relationship detection. However, this current study significantly extends that work by including new tasks such as digit image addition and zero-shot image classification, new baseline models and extensive experimental validations and comparisons.

在我们之前的会议论文[17]中，我们对所提出的视觉关系检测想法进行了初步介绍和验证。然而，本研究通过纳入新任务(如数字图像加法和零样本图像分类)、新的基线模型以及广泛的实验验证和比较，显著扩展了该工作。

## Results

## 结果

## Overview of GBPGR

## GBPGR概述

An overview of GBPGR, consisting of two important phases (i.e., concept learning and concept manipulation), is shown in Fig. 1.

GBPGR的概述如图1所示，它由两个重要阶段(即概念学习和概念操作)组成。

Concept learning focuses on acquiring fundamental concepts (e.g., predicates in rules) from train data. For instance, we can learn fundamental concepts like "catlike", "tawny" and "spot" from images containing leopards, and "horselike", "white&black" and "stripe" from an image containing zebras, utilizing the rules R1 likecat $\left( x\right)  \land  \operatorname{tawny}\left( x\right)  \land  \operatorname{spot}\left( x\right)  \Rightarrow$ leopard(x)and R2 horselike $\left( x\right)  \land$ white $\&$ black $\left( x\right)  \land$ stripe $\left( x\right)  \Rightarrow$ $\operatorname{zebra}\left( x\right)$ , respectively. In this paper, we use FOLs such as rule body $\Rightarrow$ rule head as our rules.

概念学习专注于从训练数据中获取基本概念(例如，规则中的谓词)。例如，我们可以分别利用规则R1(如猫科动物 $\left( x\right)  \land  \operatorname{tawny}\left( x\right)  \land  \operatorname{spot}\left( x\right)  \Rightarrow$ 豹(x))和规则R2(如马科动物 $\left( x\right)  \land$ 白色 $\&$ 黑色 $\left( x\right)  \land$ 条纹 $\left( x\right)  \Rightarrow$ $\operatorname{zebra}\left( x\right)$)，从包含豹的图像中学习“似猫的”“黄褐色的”和“斑点”等基本概念，从包含斑马的图像中学习“似马的”“黑白相间的”和“条纹”等基本概念。在本文中，我们使用诸如规则体 $\Rightarrow$ 规则头之类的一阶逻辑(FOLs)作为我们的规则。

Concept manipulation aims to infer results that can implement two manipulations such as transductive concept manipulation and inductive concept manipulation. In transductive concept manipulation, the learned concepts and the original rules are employed to test data whose labels have occurred in the training sets. Incorporating these learned concepts endows GBPGR with interpretability, as it provides insights into how the prediction results are derived based on them in conjunction with the rules. For example, the predicted label "leopard" can be attributed to the rule R1. Conversely, in inductive concept manipulation, the learned concepts and the new rules are employed to test data whose label has never appeared in the training set. More concretely, the learned concepts are regarded as the rule body of new rule to reason rule head as the result when testing a new sample. For instance, when an image containing a tiger is fed into the well-trained model, it can trigger the new rule R3 and obtain corresponding concept groundings such as "catlike", "tawny" and "stripe". By leveraging R3 and the concept groundings, the model performs reasoning to infer the new concept "tiger". This approach enables the application of previously learned concepts to new tasks, facilitating reasoning and prediction in a more generalizable manner. Through this process, the model effectively learns, reasons, and generates interpretable results based on the acquired concepts, showcasing its ability to adapt to diverse problem domains and provide valuable insights into the reasoning behind its predictions.

概念操作旨在推断能够实现两种操作(如直推式概念操作和归纳式概念操作)的结果。在直推式概念操作中，使用学习到的概念和原始规则来测试标签已在训练集中出现过的数据。结合这些学习到的概念使GBPGR具有可解释性，因为它提供了基于这些概念并结合规则得出预测结果的见解。例如，预测标签“豹”可归因于规则R1。相反，在归纳式概念操作中，使用学习到的概念和新规则来测试标签从未在训练集中出现过的数据。更具体地说，在测试新样本时，学习到的概念被视为新规则的规则体，以推理出规则头作为结果。例如，当将包含老虎的图像输入到训练良好的模型中时，它可以触发新规则R3并获得相应的概念实例化，如“似猫的”“黄褐色的”和“条纹”。通过利用R3和概念实例化，模型进行推理以推断出新概念“老虎”。这种方法使先前学习到的概念能够应用于新任务，以更具通用性的方式促进推理和预测。通过这个过程，模型基于获取的概念有效地学习、推理并生成可解释的结果，展示了其适应不同问题领域并为其预测背后的推理提供有价值见解的能力。

![0195ea34-fd6a-7872-b55f-5da9e4b421ce_3_172_161_1379_1850_0.jpg](images/0195ea34-fd6a-7872-b55f-5da9e4b421ce_3_172_161_1379_1850_0.jpg)

Fig. 2 Illustration of concept learning and manipulation. a, NRM aims to predict labels for raw data and output pseudo-labels and feature vectors. b, SRM is a bi-level probabilistic graphical model, where the high-level layer represents the prediction results (pseudo-labels) generated by NRM. In contrast, the low-level layer consists of the ground atoms of logic rules, which are grounded by feature vectors and concept networks. The whole model is trained end-to-end, using backpropagation to revise pseudo-labels. c, Transductive manipulation. d, Inductive manipulation.

图2 概念学习和操作的示意图。a，神经推理模块(NRM)旨在为原始数据预测标签并输出伪标签和特征向量。b，符号推理模块(SRM)是一个双层概率图模型，其中高层表示由NRM生成的预测结果(伪标签)。相比之下，低层由逻辑规则的基原子组成，这些基原子由特征向量和概念网络进行实例化。整个模型进行端到端训练，使用反向传播来修正伪标签。c，直推式操作。d，归纳式操作。

## Concept learning

## 概念学习

Fig. 2a and Fig. 2b show concept learning. Concept learning includes a neural reasoning module (NRM) and a symbolic reasoning module (SRM). More specifically, NRM is a task network and aims to output pseudo-labels and feature vectors. SRM is a bi-level probabilistic graphical model that is accountable for reasoning results. In SRM, the high-level layer represents the prediction results (pseudo-labels) generated by NRM. In contrast, the low-level layer consists of the ground atoms ${}^{1}$ of logic rules, which are grounded by feature vectors and concept networks. The whole model is trained end-to-end, using backpropagation to revise pseudo-labels. The revised labels from SRM are then adopted to replace pseudo-labels of NRM in the subsequent iteration. After $N$ iterations, the model outputs predicted results of NRM based on symbolic knowledge.

图2a和图2b展示了概念学习。概念学习包括一个神经推理模块(NRM)和一个符号推理模块(SRM)。更具体地说，NRM是一个任务网络，旨在输出伪标签和特征向量。SRM是一个双层概率图模型，负责推理结果。在SRM中，高层表示由NRM生成的预测结果(伪标签)。相比之下，低层由逻辑规则的基原子 ${}^{1}$ 组成，这些基原子由特征向量和概念网络进行实例化。整个模型进行端到端训练，使用反向传播来修正伪标签。然后，在后续迭代中，采用SRM修正后的标签来替换NRM的伪标签。经过 $N$ 次迭代后，模型基于符号知识输出NRM的预测结果。

## Concept manipulation

## 概念操作

As mentioned above, two concept manipulations exist in GBPGR. Thus, we designed two corresponding methods. The first method is transductive, wherein a trained task network is utilized to predict results, and a probabilistic graphical model is employed to provide interpretation, as shown in Fig. 2c. In contrast, the second method is inductive. In this approach, fuzzy logic reasoning is employed to generate output results, accompanied by a reasoning path as the interpretation, as shown in Fig. 2d.

如上所述，GBPGR中存在两种概念操作。因此，我们设计了两种相应的方法。第一种方法是直推式的，其中使用训练好的任务网络来预测结果，并使用概率图模型来提供解释，如图2c所示。相比之下，第二种方法是归纳式的。在这种方法中，使用模糊逻辑推理来生成输出结果，并伴有推理路径作为解释，如图2d所示。

In Fig. 2c, it is worth noting that the training and test sets have overlapping classes such as "zebra". Our learning process involves training on the training dataset and subsequently making predictions on the test set. More specifically, the steps of transductive manipulation are: (1) inputting new data and obtaining prediction labels through the trained task network; (2) identifying the nodes in the high-level layer based on the prediction labels; (3) matching the nodes in the high-level layer with the logical rules in the MLN to identify the candidate rules; (4) inputting feature vectors to the concept network, retrieving the scores of the concepts, and then applying probabilistic reasoning (Eq. (1)) and fuzzy logic reasoning to obtain the probability score of each rule is true. The rules with high scores are selected as the evidence chain, which interprets the prediction labels. In this paper, we match the prediction results with the low-level nodes to achieve interpretability. If a successful match is achieved, it indicates that the logic rules containing those nodes are triggered, and the corresponding clique composed of those nodes is selected. To quantify the likelihood that the candidate rule is true, we calculate the probability using t-norm fuzzy logic [18]. This process enables us to obtain evidence in the form of logic rules that support the reasoning outcomes. To enhance interpretability, we select the most prominent piece of evidence based on the posterior probability $P\left( {R \mid  \widehat{y}}\right)$ as follows.

在图2c中，值得注意的是，训练集和测试集存在重叠的类别，如“斑马”。我们的学习过程包括在训练数据集上进行训练，然后在测试集上进行预测。更具体地说，直推式操作的步骤如下:(1)输入新数据，并通过训练好的任务网络获得预测标签；(2)根据预测标签识别高层中的节点；(3)将高层中的节点与马尔可夫逻辑网络(MLN)中的逻辑规则进行匹配，以识别候选规则；(4)将特征向量输入概念网络，检索概念的得分，然后应用概率推理(公式(1))和模糊逻辑推理，以获得每个规则为真的概率得分。得分较高的规则被选作证据链，用于解释预测标签。在本文中，我们将预测结果与低层节点进行匹配以实现可解释性。如果匹配成功，则表明包含这些节点的逻辑规则被触发，并选择由这些节点组成的相应团。为了量化候选规则为真的可能性，我们使用t-范数模糊逻辑[18]计算概率。这个过程使我们能够以支持推理结果的逻辑规则的形式获得证据。为了增强可解释性，我们根据后验概率 $P\left( {R \mid  \widehat{y}}\right)$ 选择最突出的一条证据，如下所示。

$$
P\left( {R \mid  \widehat{y}}\right)  = \mathop{\prod }\limits_{{{A}_{i} \in  {T}_{r}}}p\left( {{A}_{i} \mid  \widehat{y}}\right) , \tag{1}
$$

where ${T}_{r}$ is the candidate logic rule here. ${A}_{i}$ represents grounding atom sets in ${T}_{r}$ and is a variable in the low-level layer. $\widehat{y}$ represents pseudo-labels.

其中 ${T}_{r}$ 是这里的候选逻辑规则。 ${A}_{i}$ 表示 ${T}_{r}$ 中的基原子集，并且是低层中的一个变量。 $\widehat{y}$ 表示伪标签。

In Fig. 2d, it is important to note that there is no intersection between the training and test data. Specifically, there are three steps for inductive manipulation: (1) rewriting logic rules based on a new task to accommodate specific requirements; (2) grounding the logic rules using feature vectors from task network; (3) inputting the feature vector of the concept mentioned in the rule body of the candidate rules into the concept networks to obtain the labels of the concepts. Then, reason the solution for the new task based on both the rule head and the rule body together. This process can be seen as reprogramming for the new problem, utilizing the learned predicate concepts from the previous step to tackle more complex problem scenarios. For example, the model is trained on single-digit tasks and tested on multi-digit tasks. By adopting this approach, the model can adapt its knowledge and reasoning capabilities to address new problems, thereby showcasing the generalization capabilities of our approach.

在图2d中，重要的是要注意训练数据和测试数据之间没有交集。具体来说，归纳式操作有三个步骤:(1)根据新任务重写逻辑规则以满足特定要求；(2)使用任务网络的特征向量对逻辑规则进行基化；(3)将候选规则的规则体中提到的概念的特征向量输入概念网络，以获得概念的标签。然后，基于规则头和规则体一起推理新任务的解决方案。这个过程可以看作是对新问题进行重新编程，利用上一步学到的谓词概念来处理更复杂的问题场景。例如，模型在一位数任务上进行训练，并在多位数任务上进行测试。通过采用这种方法，模型可以调整其知识和推理能力以解决新问题，从而展示了我们方法的泛化能力。

---

${}^{1}$ ground atom is a replacement of all of its arguments by constants.

${}^{1}$ 基原子是其所有参数都被常量替换后的结果。

---

## Performance of the GBPGR

## 广义基化概率图推理(GBPGR)的性能

To validate the effectiveness of our GBPGR model on performance, generalization and interpretability, we conducted experiments on some challenge tasks, including visual relationship detection (supervised task, transductive concept manipulation) and digit image addition (weakly supervised task, transductive concept manipulation and inductive concept manipulation). In this section, the experimental setup includes datasets, metrics and implementation details, please refer to the section Methods for more information.

为了验证我们的GBPGR模型在性能、泛化性和可解释性方面的有效性，我们在一些具有挑战性的任务上进行了实验，包括视觉关系检测(有监督任务，直推式概念操作)和数字图像加法(弱监督任务，直推式概念操作和归纳式概念操作)。在本节中，实验设置包括数据集、指标和实现细节，更多信息请参考“方法”部分。

Visual relationship detection. In this task, the NRM component of our model follows the architecture described in [22], and it was trained on the VRD datasets. The experimental results of GBPGR and several state-of-the-art methods are presented in Table 1. We adopt evaluation metrics the same as [22], including Relationship detection (ReD) and Phrase detection (PhD). Note, $k$ represents candidate relations for each relationship proposal (or $k$ relationship predictions for each object box pair). Since not all state-of-the-art methods specified $k$ in their experiment, we use "free $k$ " [22] to report results when takes $k$ as a hyper-parameter.

视觉关系检测。在这个任务中，我们模型的归一化关系模块(NRM)采用了文献[22]中描述的架构，并在视觉关系检测(VRD)数据集上进行了训练。GBPGR和几种最先进方法的实验结果如表1所示。我们采用与文献[22]相同的评估指标，包括关系检测(ReD)和短语检测(PhD)。注意， $k$ 表示每个关系提议的候选关系(或每对目标框的 $k$ 个关系预测)。由于并非所有最先进的方法在其实验中都指定了 $k$ ，当将 $k$ 作为超参数时，我们使用“自由 $k$ ”[22]来报告结果。

In Table 1, the results demonstrate that our GBPGR outperforms state-of-the-art methods in most cases. This can be attributed to the fact that GBPGR can leverage additional information from logic rules, such as the correlation between objects, to learn a more powerful model. Compared to the baseline method LS-VRU [22], GBPGR achieves significantly better performance. This suggests that the SRM component of GBPGR effectively acts as an error corrector, contributing to improved results.

在表1中，结果表明我们的GBPGR在大多数情况下优于最先进的方法。这可以归因于GBPGR能够利用逻辑规则中的额外信息，如对象之间的相关性，来学习一个更强大的模型。与基线方法LS-VRU [22]相比，GBPGR取得了显著更好的性能。这表明GBPGR的语义推理模块(SRM)有效地起到了纠错器的作用，有助于提高结果。

GBPGR has achieved superior results compared to the baseline methods. The improvement provided by the SRM can be attributed to two key factors. First, the SRM is designed as a probabilistic graphical model that captures dependencies between variables, allowing for more accurate modeling of complex relationships. Second, our logic rules are constructed based on the co-occurrence relationships between predicates, indicating that when one object appears, another object is likely to appear as well. By maximizing the joint probability of the probabilistic graphical model, we effectively maximize the co-occurrence probability during the training phase.

与基线方法相比，GBPGR(广义贝叶斯概率图推理)取得了更优的结果。SRM(结构关系模型)带来的改进可归因于两个关键因素。首先，SRM被设计为一种概率图模型，它能够捕捉变量之间的依赖关系，从而更准确地对复杂关系进行建模。其次，我们的逻辑规则是基于谓词之间的共现关系构建的，这表明当一个对象出现时，另一个对象也很可能出现。通过最大化概率图模型的联合概率，我们在训练阶段有效地最大化了共现概率。

Digit image addition. To evaluate the performance of GBPGR on weakly supervised tasks, we conducted experiments on single-digit addition and multi-digit addition. In this experiment, we input two digit images to GBPGR, and its output is the predicted addition result. The accuracy (Acc) of GBPGR and the CNN baseline on the test set are shown in Fig. 3a. Comparing the results of GBPGR with the CNN baseline, we can observe that GBPGR achieves decent performance. This demonstrates the feasibility of GBPGR in bypassing the need for strong supervised information typically required in pure deep learning approaches. By integrating symbolic knowledge, GBPGR is able to leverage additional supervision signals, such as data labels or relations between data, which leads to improved model performance.

数字图像加法。为了评估GBPGR(广义贝叶斯概率图推理)在弱监督任务上的性能，我们在单数字加法和多数字加法上进行了实验。在这个实验中，我们将两个数字图像输入到GBPGR中，其输出是预测的加法结果。GBPGR和CNN基线在测试集上的准确率(Acc)如图3a所示。将GBPGR的结果与CNN基线进行比较，我们可以观察到GBPGR取得了不错的性能。这证明了GBPGR在绕过纯深度学习方法通常所需的强监督信息方面的可行性。通过整合符号知识，GBPGR能够利用额外的监督信号，如数据标签或数据之间的关系，从而提高模型性能。

## Generalizaton of the GBPGR

## GBPGR(广义贝叶斯概率图推理)的泛化能力

We conducted experiments to assess the generalization capabilities of GBPGR. In this study, generalization has two meanings. First, it refers to how well GBPGR performs when it is tested on a new task. For example, the labels of the testing samples are rarely even not contained in the training sets. We validate this generalization in visual relationship detection, image classification and digit image addition. Second, it demonstrates how GBPGR performs once tested on challenging tasks after being trained on easy ones. To verify the second generalizability, we implement experiment on digit image addition task.

我们进行了实验来评估GBPGR(广义贝叶斯概率图推理)的泛化能力。在这项研究中，泛化有两层含义。首先，它指的是GBPGR在新任务上的测试表现如何。例如，测试样本的标签很少甚至不包含在训练集中。我们在视觉关系检测、图像分类和数字图像加法中验证了这种泛化能力。其次，它展示了GBPGR在简单任务上训练后在具有挑战性的任务上的测试表现。为了验证第二种泛化能力，我们在数字图像加法任务上进行了实验。

Table 1 Test performance of visual relationship detection. The recall results for the top 50/100 in "ReD" and "PhD" are reported, respectively. The best result is highlighted in bold. "-" denotes the corresponding result is not provided.

表1 视觉关系检测的测试性能。分别报告了“ReD”和“PhD”中前50/100的召回结果。最佳结果用粗体突出显示。“-”表示未提供相应结果。

<table><tr><td>Methods</td><td colspan="2">ReD</td><td colspan="2">PhD</td><td colspan="4">ReD</td><td colspan="4">PhD</td></tr><tr><td/><td colspan="4">free $k$</td><td colspan="2">$k = 1$</td><td colspan="2">$k = {70}$</td><td colspan="2">$k = 1$</td><td colspan="2">$k = {70}$</td></tr><tr><td>Recall@</td><td>50</td><td>100</td><td>50</td><td>100</td><td>50</td><td>100</td><td>50</td><td>100</td><td>50</td><td>100</td><td>50</td><td>100</td></tr><tr><td>Lk distilation[19]</td><td>22.7</td><td>31.9</td><td>26.5</td><td>29.8</td><td>19.2</td><td>21.3</td><td>22.7</td><td>31.9</td><td>23.1</td><td>24.0</td><td>26.3</td><td>29.4</td></tr><tr><td>Zoom-Net[20]</td><td>21.4</td><td>27.3</td><td>29.1</td><td>37.3</td><td>18.9</td><td>21.4</td><td>21.4</td><td>27.3</td><td>28.8</td><td>28.1</td><td>29.1</td><td>37.3</td></tr><tr><td>CAI+SCA-M[20]</td><td>22.3</td><td>28.5</td><td>29.6</td><td>38.4</td><td>19.5</td><td>22.4</td><td>22.3</td><td>28.5</td><td>25.2</td><td>28.9</td><td>29.6</td><td>38.4</td></tr><tr><td>MF-URLN[21]</td><td>23.9</td><td>26.8</td><td>31.5</td><td>36.1</td><td>23.9</td><td>26.8</td><td>-</td><td>-</td><td>23.9</td><td>26.8</td><td>-</td><td>-</td></tr><tr><td>[22]</td><td>27.0</td><td>32.6</td><td>32.9</td><td>39.6</td><td>23.7</td><td>26.7</td><td>27.0</td><td>32.6</td><td>28.9</td><td>32.9</td><td>32.9</td><td>39.6</td></tr><tr><td>GPS-Net[23]</td><td>27.8</td><td>31.7</td><td>33.8</td><td>39.2</td><td>-</td><td>-</td><td>27.8</td><td>31.7</td><td>-</td><td>-</td><td>33.8</td><td>39.2</td></tr><tr><td>UVTransE[24]</td><td>27.4</td><td>34.6</td><td>31.8</td><td>40.4</td><td>25.7</td><td>29.7</td><td>27.3</td><td>34.1</td><td>30.0</td><td>36.2</td><td>31.5</td><td>39.8</td></tr><tr><td>NMP[25]</td><td>21.5</td><td>27.5</td><td>-</td><td>-</td><td>20.2</td><td>24.0</td><td>21.5</td><td>27.5</td><td>-</td><td>-</td><td>-</td><td>-</td></tr><tr><td>GBPGR</td><td>29.4</td><td>35.3</td><td>36.2</td><td>43.0</td><td>26.2</td><td>29.4</td><td>29.4</td><td>35.3</td><td>32.3</td><td>36.4</td><td>36.2</td><td>43.0</td></tr></table>

<table><tbody><tr><td>方法</td><td colspan="2">ReD(原文未明确含义，保留英文)</td><td colspan="2">哲学博士(PhD)</td><td colspan="4">ReD(原文未明确含义，保留英文)</td><td colspan="4">哲学博士(PhD)</td></tr><tr><td></td><td colspan="4">免费 $k$</td><td colspan="2">$k = 1$</td><td colspan="2">$k = {70}$</td><td colspan="2">$k = 1$</td><td colspan="2">$k = {70}$</td></tr><tr><td>召回率@</td><td>50</td><td>100</td><td>50</td><td>100</td><td>50</td><td>100</td><td>50</td><td>100</td><td>50</td><td>100</td><td>50</td><td>100</td></tr><tr><td>Lk蒸馏法[19](Lk distilation)</td><td>22.7</td><td>31.9</td><td>26.5</td><td>29.8</td><td>19.2</td><td>21.3</td><td>22.7</td><td>31.9</td><td>23.1</td><td>24.0</td><td>26.3</td><td>29.4</td></tr><tr><td>变焦网络[20](Zoom-Net)</td><td>21.4</td><td>27.3</td><td>29.1</td><td>37.3</td><td>18.9</td><td>21.4</td><td>21.4</td><td>27.3</td><td>28.8</td><td>28.1</td><td>29.1</td><td>37.3</td></tr><tr><td>CAI+SCA - M[20](原文未明确含义，保留英文)</td><td>22.3</td><td>28.5</td><td>29.6</td><td>38.4</td><td>19.5</td><td>22.4</td><td>22.3</td><td>28.5</td><td>25.2</td><td>28.9</td><td>29.6</td><td>38.4</td></tr><tr><td>MF - URLN[21](原文未明确含义，保留英文)</td><td>23.9</td><td>26.8</td><td>31.5</td><td>36.1</td><td>23.9</td><td>26.8</td><td>-</td><td>-</td><td>23.9</td><td>26.8</td><td>-</td><td>-</td></tr><tr><td>[22]</td><td>27.0</td><td>32.6</td><td>32.9</td><td>39.6</td><td>23.7</td><td>26.7</td><td>27.0</td><td>32.6</td><td>28.9</td><td>32.9</td><td>32.9</td><td>39.6</td></tr><tr><td>GPS网络[23](GPS - Net)</td><td>27.8</td><td>31.7</td><td>33.8</td><td>39.2</td><td>-</td><td>-</td><td>27.8</td><td>31.7</td><td>-</td><td>-</td><td>33.8</td><td>39.2</td></tr><tr><td>UVTransE[24](原文未明确含义，保留英文)</td><td>27.4</td><td>34.6</td><td>31.8</td><td>40.4</td><td>25.7</td><td>29.7</td><td>27.3</td><td>34.1</td><td>30.0</td><td>36.2</td><td>31.5</td><td>39.8</td></tr><tr><td>NMP[25](原文未明确含义，保留英文)</td><td>21.5</td><td>27.5</td><td>-</td><td>-</td><td>20.2</td><td>24.0</td><td>21.5</td><td>27.5</td><td>-</td><td>-</td><td>-</td><td>-</td></tr><tr><td>GBPGR(原文未明确含义，保留英文)</td><td>29.4</td><td>35.3</td><td>36.2</td><td>43.0</td><td>26.2</td><td>29.4</td><td>29.4</td><td>35.3</td><td>32.3</td><td>36.4</td><td>36.2</td><td>43.0</td></tr></tbody></table>

![0195ea34-fd6a-7872-b55f-5da9e4b421ce_6_150_750_1436_819_0.jpg](images/0195ea34-fd6a-7872-b55f-5da9e4b421ce_6_150_750_1436_819_0.jpg)

Fig. 3 Performance, generalization and ablation results. a, Performance comparisons on digit image addition task (single-addition and multi-addition tasks). b, Performance comparisons with state-of-the-art models (SABR [26], MLSE [27], AREN [28], LFGAA [29], DAZLE [30], APN [31], CF-ZSL [32], DUET [33], MSDN [34]) on image classification task (zero-shot learning). The horizontal coordinates indicate different models. c, Generalization comparisons on the visual relationship detection (VRD dataset). Zero-shot learning results of GBPGR and baselines LS-VRU. Larger ReD indicates better results. d, Generalization comparisons on digit image addition task. Quantitative results comparing the generalization performance of GBPGR with the baseline CNN on the test set, using random sampling 300 training samples to train the model. e, Ablation results on digit image addition task. Here is the performance of GBPGR with different loss components. f, Ablation results on the image classification task.

图3 性能、泛化和消融实验结果。a，数字图像加法任务(单加法和多加法任务)的性能比较。b，在图像分类任务(零样本学习)中与最先进模型(SABR [26]、MLSE [27]、AREN [28]、LFGAA [29]、DAZLE [30]、APN [31]、CF - ZSL [32]、DUET [33]、MSDN [34])的性能比较。横坐标表示不同的模型。c，视觉关系检测(VRD数据集)的泛化比较。GBPGR和基线模型LS - VRU的零样本学习结果。ReD值越大表示结果越好。d，数字图像加法任务的泛化比较。在测试集上比较GBPGR和基线CNN泛化性能的定量结果，使用随机抽样的300个训练样本训练模型。e，数字图像加法任务的消融实验结果。这里展示了GBPGR在不同损失组件下的性能。f，图像分类任务的消融实验结果。

Visual relationship detection. we examined the performance of our GBPGR model compared to the baseline LS-VRU in a zero-shot environment. In this scenario, the training and testing data consisted of disjoint sets of relationships from the VRD dataset, as depicted in Fig. 3c. The results indicate that our GBPGR outperforms LS-VRU across different recalls. This highlights the limitations of LS-VRU in handling sparse relationships. In contrast, GBPGR effectively incorporates symbolic knowledge from logic rules and language priors, enabling it to be less affected by sparse relationships and achieve better performance.

视觉关系检测。我们在零样本环境下检查了我们的GBPGR模型与基线LS - VRU的性能。在这种情况下，训练和测试数据由VRD数据集中不相交的关系集组成，如图3c所示。结果表明，在不同的召回率下，我们的GBPGR优于LS - VRU。这凸显了LS - VRU在处理稀疏关系方面的局限性。相比之下，GBPGR有效地结合了来自逻辑规则和语言先验的符号知识，使其受稀疏关系的影响较小，并能取得更好的性能。

![0195ea34-fd6a-7872-b55f-5da9e4b421ce_7_134_168_1448_788_0.jpg](images/0195ea34-fd6a-7872-b55f-5da9e4b421ce_7_134_168_1448_788_0.jpg)

Fig. 4 Interpretability analysis. a, An example that can show the interpretability of GBPGR. For example, why is a relationship "next to" between "laptop" and "keyboard" or "mouse" in an image? According to Eq. (1), the model can find the most confident logic rule is $\operatorname{laptop}\left( x\right)  \land$ next $\operatorname{to}\left( {x, y}\right)  \Rightarrow$ keyboard $\left( y\right)  \vee$ mouse(y). This indicates that the reasoning results of GBPGR are consistent with commonsense. b, Reasoning process of the multi-digit addition. (1) Rewrite logic rules based on multi-digit addition (new task); (2) Grounding rules using feature vectors of $x$ and $y$ from CNN; (3) The process involves inputting the feature vectors associated with the concept mentioned in the candidate rule body into the concept network to obtain the corresponding concept labels. Ultimately, the solution for the new task is achieved by combining the information from both the rule head and rule body, allowing for reasoning and deduction. Note, the variables $x$ and $y$ represent the multi-digit numbers. The symbol ${e}_{i}$ denotes the feature vector associated with each digit image. Additionally, the variable ${d}_{i}$ represents the label for each individual digit image, while $z$ represents the label for the addition operation.

图4 可解释性分析。a，一个可以展示GBPGR可解释性的例子。例如，为什么图像中“笔记本电脑”和“键盘”或“鼠标”之间存在“相邻”关系？根据公式(1)，模型可以找到最有把握的逻辑规则是 $\operatorname{laptop}\left( x\right)  \land$ 相邻 $\operatorname{to}\left( {x, y}\right)  \Rightarrow$ 键盘 $\left( y\right)  \vee$ 鼠标(y)。这表明GBPGR的推理结果与常识一致。b，多位数加法的推理过程。(1) 根据多位数加法(新任务)重写逻辑规则；(2) 使用来自CNN的 $x$ 和 $y$ 的特征向量对规则进行接地；(3) 该过程包括将与候选规则体中提到的概念相关的特征向量输入到概念网络中，以获得相应的概念标签。最终，通过结合规则头和规则体的信息来实现新任务的求解，从而进行推理和演绎。注意，变量 $x$ 和 $y$ 表示多位数。符号 ${e}_{i}$ 表示与每个数字图像相关的特征向量。此外，变量 ${d}_{i}$ 表示每个单独数字图像的标签，而 $z$ 表示加法运算的标签。

Image classification. To evaluate the performance of GBPGR on zero-shot learning, we conducted an experiment on image classification. Fig. $3\mathrm{\;b}$ presents the results. From the results, we can observe that our GBPGR achieves the best accuracy. This shows that GBPGR can capture common attributes and relationships from seen categories for recognizing unseen categories. In addition, this experiment also illustrates symbolic reasoning with logic rules making the model more robust.

图像分类。为了评估GBPGR在零样本学习上的性能，我们进行了图像分类实验。图 $3\mathrm{\;b}$ 展示了结果。从结果中我们可以观察到，我们的GBPGR取得了最佳的准确率。这表明GBPGR可以从已见类别中捕捉共同属性和关系，以识别未见类别。此外，该实验还表明基于逻辑规则的符号推理使模型更具鲁棒性。

Digit image addition. We proceeded to assess the generalization capability of GBPGR in weakly supervised tasks by comparing it to the baseline CNN. In this context, we validate the generalization performance under various scenarios, including limited training data and learning in a simple task while testing in a more complex task.

数字图像加法。我们通过与基线CNN进行比较，评估了GBPGR在弱监督任务中的泛化能力。在这种情况下，我们验证了在各种场景下的泛化性能，包括有限的训练数据以及在简单任务中学习而在更复杂任务中测试的情况。

In a limited training data scenario, we measured the performance using Acc on the test set with random sampling 300 training samples. As depicted in Fig. 3d, GBPGR consistently achieved higher Acc compared to the CNN. This is because the baseline CNN solely relies on digit image features as input and struggles to train a sufficiently robust model. In contrast, GBPGR leverages both digit image features and the relationships between digit images, such as the relationships encoded in logic rules, enabling it to learn a more effective model.

在有限训练数据的场景下，我们使用随机抽样的300个训练样本，通过测试集上的准确率(Acc)来衡量性能。如图3d所示，与CNN相比，GBPGR始终能获得更高的准确率。这是因为基线CNN仅依赖数字图像特征作为输入，难以训练出足够鲁棒的模型。相比之下，GBPGR同时利用数字图像特征和数字图像之间的关系，例如逻辑规则中编码的关系，使其能够学习到更有效的模型。

To validate the learned model in sigle-digit addition can generalize complex task, we introduce multi-digit addition task. In multi-digit addition, the input comprises two lists of images, where each element represents a digit. Each list represents a multi-digit number. The label corresponds to the sum of the two numbers. We visualize this reasoning process in Fig. 4b. In Fig. 3a multi-digit, the result has successfully demonstrated the enhanced prediction accuracy of our multi-digit addition task by leveraging the predicate concepts acquired during the single-digit addition task. Our results show a significant improvement compared to the baseline method. This highlights the flexibility of our model, which is capable of generalizing from simple tasks to more complex ones by modifying the logic rules. Notably, this generalization is achieved due to the shared learnable basic concepts (predicates) between the two tasks.

为了验证在个位数加法中学习到的模型能够泛化到复杂任务，我们引入了多位数加法任务。在多位数加法中，输入由两个图像列表组成，其中每个元素代表一个数字。每个列表代表一个多位数。标签对应于这两个数字的和。我们在图4b中可视化了这个推理过程。在图3a的多位数示例中，结果成功展示了通过利用在个位数加法任务中获得的谓词概念，我们的多位数加法任务的预测准确性得到了提高。与基线方法相比，我们的结果显示出显著的改进。这凸显了我们模型的灵活性，它能够通过修改逻辑规则从简单任务泛化到更复杂的任务。值得注意的是，这种泛化的实现是由于两个任务之间共享可学习的基本概念(谓词)。

## Interpretibility of the GBPGR

## 广义布尔谓词图推理(GBPGR)的可解释性

To assess the interpretability of our proposed model, we devised a quantitative method (Eq. (1)) to identify evidence (i.e., the rules) supporting the prediction results. In the case of the supervised and weakly supervised tasks, we visualized the detection results and the interpretability process in Fig. 4a and Fig. 4b, respectively. For instance, the logic rule laptop $\left( x\right)  \land$ next $\operatorname{to}\left( {x, y}\right)  \Rightarrow$ keyboard $\left( y\right)  \vee$ mouse(y) makes Eq. (1) get high value, thus this rule is confident for the relationship "next to" in the VRD task Fig. 4a. Fig. 4b shows how GBPGR works with the new rules when dealing with challenging tasks after training on the simple tasks. The simple task involves single-digit addition, represented as $\operatorname{digit}\left( {x,{d}_{1}}\right)  \land  \operatorname{digit}\left( {y,{d}_{2}}\right)  \Rightarrow  \operatorname{addition}\left( {{d}_{1} + {d}_{2}, z}\right) .$ On the other hand, the challenging task refers to multi-digit addition, represented as digit $\left( {{x}_{1},{d}_{1}}\right)  \land$ $\operatorname{digit}\left( {{x}_{2},{d}_{2}}\right)  \land  \operatorname{digit}\left( {{y}_{1},{d}_{3}}\right)  \land  \operatorname{digit}\left( {{y}_{2},{d}_{4}}\right)  \Rightarrow$ addition $\left( {{10} \times  {d}_{1} + {d}_{2} + {10} \times  {d}_{3} + {d}_{4}, z}\right)$ . By learning the basic concept of "digit" in single-digit addition, we can then generalize this knowledge to the multi-digit addition task through rule reasoning. Based on these figures, we can conclude that our model possesses the capability of self-reasoning, offering commonsense and easily understandable evidence to support its prediction results.

为了评估我们提出的模型的可解释性，我们设计了一种定量方法(公式(1))来识别支持预测结果的证据(即规则)。在有监督和弱监督任务的情况下，我们分别在图4a和图4b中可视化了检测结果和可解释性过程。例如，逻辑规则“笔记本电脑 $\left( x\right)  \land$ 在……旁边 $\operatorname{to}\left( {x, y}\right)  \Rightarrow$ 键盘 $\left( y\right)  \vee$ 鼠标(y)”使公式(1)获得较高的值，因此该规则对于视觉关系检测(VRD)任务图4a中的“相邻”关系具有较高的置信度。图4b展示了广义布尔谓词图推理(GBPGR)在简单任务上训练后，在处理具有挑战性的任务时如何运用新规则。简单任务涉及个位数加法，表示为 $\operatorname{digit}\left( {x,{d}_{1}}\right)  \land  \operatorname{digit}\left( {y,{d}_{2}}\right)  \Rightarrow  \operatorname{addition}\left( {{d}_{1} + {d}_{2}, z}\right) .$ 。另一方面，具有挑战性的任务指的是多位数加法，表示为 数字 $\left( {{x}_{1},{d}_{1}}\right)  \land$ $\operatorname{digit}\left( {{x}_{2},{d}_{2}}\right)  \land  \operatorname{digit}\left( {{y}_{1},{d}_{3}}\right)  \land  \operatorname{digit}\left( {{y}_{2},{d}_{4}}\right)  \Rightarrow$ 加法 $\left( {{10} \times  {d}_{1} + {d}_{2} + {10} \times  {d}_{3} + {d}_{4}, z}\right)$ 。通过在个位数加法中学习“数字”的基本概念，我们可以通过规则推理将这一知识泛化到多位数加法任务中。基于这些图，我们可以得出结论，我们的模型具备自我推理的能力，能够提供常识性且易于理解的证据来支持其预测结果。

## Ablation studies on GBPGR

## 广义布尔谓词图推理(GBPGR)的消融研究

To investigate how the model trade-off affects reasoning performance, we design three variants to verify the effect of individual components on GBPGR. Specifically, we obtain different variants for optimized objection Eq. (10) (Please refer to Methods) by setting values of the trade-off factors. The three variants are as follows: (1) GBPGR-SRM $\left( {\alpha  = 1,\beta  = 0,\gamma  = 0}\right)$ : removing symbolic reasoning module. (2) GBPGR-NRM $(\alpha  = 1/2,\beta  = 1,\gamma  =$ 1): removing a half of visual reasoning module. (3) GBPGR-OI $\left( {\alpha  = 1,\beta  = 1,\gamma  = 0}\right)$ : removing crossentropy of observed variables.

为了研究模型的权衡如何影响推理性能，我们设计了三种变体来验证各个组件对广义布尔谓词图推理(GBPGR)的影响。具体来说，我们通过设置权衡因子的值，为优化目标公式(10)(请参考方法部分)获得不同的变体。这三种变体如下:(1) GBPGR - SRM $\left( {\alpha  = 1,\beta  = 0,\gamma  = 0}\right)$ :移除符号推理模块。(2) GBPGR - NRM $(\alpha  = 1/2,\beta  = 1,\gamma  =$ 1):移除一半的视觉推理模块。(3) GBPGR - OI $\left( {\alpha  = 1,\beta  = 1,\gamma  = 0}\right)$ :移除观测变量的交叉熵。

We conducted experiments on the MNIST and AwA2 datasets to evaluate the performance of GBPGR and its variants. The results are presented in Fig. 3e and Fig. 3f, respectively. For Fig. 3e, we observe that the performance of the GBPGR-NRM variant is higher compared to its GBPGR-SRM counterparts, which differs from the results on the VRD dataset. This can be attributed to the fact that weakly supervised tasks, such as the MNIST dataset, have limited supervised information. In the case of weakly supervised tasks, the input images do not have their own individual labels, but only the labels for addition. This might result in the NRM module playing a more limited role in the task. Moreover, this finding indicates that leveraging symbolic knowledge is even more important for weakly supervised tasks compared to supervised tasks.

我们在MNIST和AwA2数据集上进行了实验，以评估GBPGR及其变体的性能。结果分别如图3e和图3f所示。对于图3e，我们观察到GBPGR - NRM变体的性能比其GBPGR - SRM对应变体更高，这与VRD数据集上的结果不同。这可以归因于像MNIST数据集这样的弱监督任务的监督信息有限。在弱监督任务中，输入图像没有各自独立的标签，只有加法的标签。这可能导致NRM模块在任务中发挥的作用更为有限。此外，这一发现表明，与监督任务相比，利用符号知识对于弱监督任务更为重要。

From Fig. 3f, we observe that the correlations among the components of SRM, VRM, and OI have a significantly positive impact on image classification in zero-shot learning. Additionally, we notice that the performance of our model is notably improved when the SRM module is applied. This validates the effectiveness of the logic rules incorporated in our model, as it aligns with our theoretical analysis suggesting that symbolic knowledge in logic rules can rectify the results of the NRM.

从图3f中，我们观察到SRM、VRM和OI组件之间的相关性对零样本学习中的图像分类有显著的积极影响。此外，我们注意到应用SRM模块时，我们模型的性能有显著提升。这验证了我们模型中纳入的逻辑规则的有效性，因为这与我们的理论分析一致，即逻辑规则中的符号知识可以纠正NRM的结果。

## Conclusion

## 结论

In this study, we introduce GBPGR as a general model based on neural-symbolic systems. Our objective is to enhance the performance and generalization of the model, as well as provide interpretability of the results. Additionally, we propose a novel evaluation metric to measure the interpretability of the deep model. Based on our experimental results, we demonstrate that GBPGR surpasses state-of-the-art methods in various reasoning tasks, including supervised and weakly supervised scenarios and zero-shot learning in terms of performance and generalization. Moreover, we emphasize the interpretability aspect of GBPGR by providing visualizations that enhance the understanding of the reasoning process.

在本研究中，我们引入了GBPGR作为一种基于神经符号系统的通用模型。我们的目标是提高模型的性能和泛化能力，并提供结果的可解释性。此外，我们提出了一种新的评估指标来衡量深度模型的可解释性。根据我们的实验结果，我们证明了GBPGR在各种推理任务中，包括监督和弱监督场景以及零样本学习方面，在性能和泛化能力上都超越了现有最先进的方法。此外，我们通过提供可视化结果来强调GBPGR的可解释性，以增强对推理过程的理解。

## Methods

## 方法

## Model definition

## 模型定义

We define our model as a function $F$ that takes the raw input $D$ and the pre-defined limited set of logic rules $R$ and maps them to the output $y$ (i.e., $y = F\left( {D, R}\right) )$ . More specifically, $y = F\left( {D, R}\right)$ can be further simplified as computing a posterior probability $P\left( {y \mid  D, R}\right)$ when provided with input data $D$ and logic rules $R$ . Therefore, the learning process of the model can be formulated as a posterior computation problem, which can be defined as follows:

我们将我们的模型定义为一个函数 $F$，它接受原始输入 $D$ 和预定义的有限逻辑规则集 $R$，并将它们映射到输出 $y$(即 $y = F\left( {D, R}\right) )$ 。更具体地说，$y = F\left( {D, R}\right)$ 可以进一步简化为在给定输入数据 $D$ 和逻辑规则 $R$ 时计算后验概率 $P\left( {y \mid  D, R}\right)$ 。因此，模型的学习过程可以表述为一个后验计算问题，定义如下:

$$
\forall \left( {D, y}\right) \max P\left( {y \mid  D, R}\right) \text{.} \tag{2}
$$

In object detection tasks, the input data $D$ represents images, and the output $y$ represents the corresponding labels of objects present in those images. For instance, $D$ could consist of a set of images, and $y$ would contain the object labels such as "cat", "dog", etc., indicating the objects recognized in each image. In single-digit addition tasks, the input data $D$ includes pairs of digit images and their corresponding addition operations, while the output $y$ represents the labels for the addition results. For example, $D$ could consist of digit images of " 2 " and " 3 ", and $y$ would contain the label "5" as the addition result.

在目标检测任务中，输入数据 $D$ 表示图像，输出 $y$ 表示这些图像中存在的目标的相应标签。例如，$D$ 可以由一组图像组成，$y$ 则包含诸如“猫”、“狗”等目标标签，指示每张图像中识别出的目标。在个位数加法任务中，输入数据 $D$ 包括数字图像对及其相应的加法运算，而输出 $y$ 表示加法结果的标签。例如，$D$ 可以由数字“2”和“3”的图像组成，$y$ 则包含加法结果标签“5”。

## Statistic relation learning

## 统计关系学习

Many tasks in real-world application domains are characterized by the presence of both uncertainty and complex relational structure. Statistical learning focuses on the former, and relational learning on the latter. Statistical relational learning (SRL) seeks to combine the power of both [14].

现实世界应用领域中的许多任务都具有不确定性和复杂关系结构并存的特点。统计学习侧重于前者，而关系学习侧重于后者。统计关系学习(SRL)旨在结合两者的优势[14]。

In this study, we leverage SRL to integrate first-order logic (FOL) and probabilistic graphical models, creating a unified framework that enables probabilistic inference for reasoning problems. To achieve this integration, we employ Markov logic network (MLN) [16], which is a well-known SRL model, to represent logic rules as undirected graphs representing joint probability distributions. In the constructed undirected graph, nodes are generated based on all ground atoms, which are logical predicates with their arguments replaced by specific constants. An edge is established between two nodes if the corresponding ground atoms co-occur in at least one ground FOL. Consequently, a ground MLN can be formulated as a joint probability distribution, capturing the dependencies and correlations among the ground atoms. Thus, a ground MLN can be defined as a joint probability distribution:

在本研究中，我们利用SRL将一阶逻辑(FOL)和概率图模型相结合，创建了一个统一的框架，用于解决推理问题的概率推断。为了实现这种结合，我们采用了马尔可夫逻辑网络(MLN)[16]，这是一种著名的SRL模型，将逻辑规则表示为表示联合概率分布的无向图。在构建的无向图中，节点基于所有基原子生成，基原子是其参数被特定常量替换的逻辑谓词。如果对应的基原子至少在一个基FOL中同时出现，则在两个节点之间建立一条边。因此，一个基MLN可以被表述为一个联合概率分布，捕捉基原子之间的依赖关系和相关性。因此，一个基MLN可以被定义为一个联合概率分布:

$$
P\left( A\right)  = \frac{1}{Z\left( w\right) }\exp \left\{  {\mathop{\sum }\limits_{{r \in  R}}{w}_{r}\mathop{\sum }\limits_{{A}_{r}}\phi \left( {A}_{r}\right) }\right\}  , \tag{3}
$$

where $Z\left( w\right)$ is the partition function summing overall ground atoms. $A$ is all ground atoms in the knowledge base. $R$ is the set of logic rules and $r$ is a logic rule. ${A}_{r}$ is ground atom sets in $r.\phi$ is a potential function in terms of the number of times the logic rule is true. $w$ is the weight sets of all logic rules. ${w}_{r}$ represents the weight of a logic rule $r$ . The greater weight, the greater confidence of logic rules.

其中 $Z\left( w\right)$ 是对所有基原子求和的配分函数(partition function)。$A$ 是知识库中的所有基原子。$R$ 是逻辑规则集，$r$ 是一条逻辑规则。${A}_{r}$ 是 $r.\phi$ 中的基原子集，$r.\phi$ 是一个关于逻辑规则为真次数的势函数(potential function)。$w$ 是所有逻辑规则的权重集。${w}_{r}$ 表示逻辑规则 $r$ 的权重。权重越大，逻辑规则的置信度越高。

To fully leverage the benefits of deep learning and symbolic reasoning, the GBPGR model needs to fulfill two essential requirements. Firstly, it should be capable of fitting labeled data and enabling joint training, allowing it to learn from both data and symbolic knowledge. Secondly, the model's predictions should align with symbolic knowledge, indicating that the model's output should activate relevant logic rules. To address these requirements, we utilize statistical relational learning (SRL) as an interface to connect deep learning and symbolic reasoning in a mutually beneficial manner.

为了充分发挥深度学习和符号推理的优势，GBPGR 模型需要满足两个基本要求。首先，它应该能够拟合带标签的数据并支持联合训练，使其能够从数据和符号知识中学习。其次，模型的预测结果应该与符号知识一致，即模型的输出应该激活相关的逻辑规则。为了满足这些要求，我们利用统计关系学习(Statistical Relational Learning，SRL)作为接口，以互利的方式连接深度学习和符号推理。

GBPGR includes a neural reasoning module (NRM, it is Fig 2a) and a symbolic reasoning module (SRM, it is Fig 2b). During training, information is propagated from the task network to the SRM fitting labeled data and symbolic knowledge. Therefore, the overall learning objective of the GBPGR is defined as $O$ in Eq. (4).

GBPGR 包括一个神经推理模块(Neural Reasoning Module，NRM，如图 2a 所示)和一个符号推理模块(Symbolic Reasoning Module，SRM，如图 2b 所示)。在训练过程中，信息从任务网络传播到 SRM，以拟合带标签的数据和符号知识。因此，GBPGR 的整体学习目标在公式 (4) 中定义为 $O$。

$$
O = {O}_{\text{task }} + {O}_{\text{logic }}, \tag{4}
$$

where ${O}_{\text{task }}$ represents the learning objective of a specific task (objective of the task network), characterizing how well the model's predictions fit the data. ${O}_{\text{logic }}$ is a symbolic reasoning objective (regularization loss), characterizing how well the model's predictions fit the symbolic knowledge.

其中 ${O}_{\text{task }}$ 表示特定任务的学习目标(任务网络的目标)，表征模型的预测结果与数据的拟合程度。${O}_{\text{logic }}$ 是一个符号推理目标(正则化损失)，表征模型的预测结果与符号知识的拟合程度。

## Neural reasoning module

## 神经推理模块

A neural reasoning module (NRM, Fig. 2a) is implemented as a deep neural network, where the specific architecture depends on the task at hand, such as visual relationship detection in this paper. The NRM is responsible for predicting labels and outputs feature vectors. The architecture of the NRM may vary depending on the specific task requirements. Considering the previous analysis and Eq. (4) in the paper, the learning objective function of the NRM can be formulated as follows:

神经推理模块(NRM，图 2a)被实现为一个深度神经网络，其具体架构取决于手头的任务，例如本文中的视觉关系检测。NRM 负责预测标签并输出特征向量。NRM 的架构可能会根据具体任务要求而有所不同。考虑到之前的分析和本文中的公式 (4)，NRM 的学习目标函数可以表述如下:

$$
{O}_{\text{task }} = {P}_{{\theta }_{1}}\left( {y \mid  D}\right) , \tag{5}
$$

where ${\theta }_{1}$ is the learnable parameter of the NRM.

其中 ${\theta }_{1}$ 是 NRM 的可学习参数。

## Symbolic reasoning module

## 符号推理模块

To connect deep learning models with symbolic logic, we utilize SRL to build a probabilistic graphical model in the symbolic reasoning module (SRM). This module consists of a double-layer probabilistic graph, as shown in Fig. 2b, with two types of nodes: the reasoning results of the NRM in the high-level layer and the ground atoms of logic rules grounded by feature vectors in the low-level layer. The high-level layer represents the prediction results of the NRM, while the low-level layer represents MLN. In the low-level layer, MLN is used to connect observed predicates (labeled or appearing in the training data) and unobserved predicates (unlabeled), representing them as a joint probability distribution to infer the probability of unobserved predicates. Between the two layers, we align the prediction results of deep learning models with the ground atoms in logic rules to revise errors. This demonstrates that GBPGR fits both labeled data and symbolic knowledge. Furthermore, MLN plays a crucial role in fitting symbolic knowledge by utilizing joint probabilistic distribution values to quantify the degree of fit for logic rules. The objective of SRM is to use SRLs to learn variables and guide the reasoning of the NRM in the right direction, acting as an error corrector. Our SRM is task-agnostic, and once the probabilistic graphical model is constructed, it can be performed accordingly in the variational expectation-maximization (EM) framework.

为了将深度学习模型与符号逻辑连接起来，我们在符号推理模块(SRM)中利用 SRL 构建了一个概率图模型。该模块由一个双层概率图组成，如图 2b 所示，有两种类型的节点:高层的 NRM 推理结果和低层由特征向量接地的逻辑规则的基原子。高层表示 NRM 的预测结果，而低层表示马尔可夫逻辑网络(Markov Logic Network，MLN)。在低层，MLN 用于连接观测谓词(带标签或出现在训练数据中)和未观测谓词(未带标签)，将它们表示为联合概率分布，以推断未观测谓词的概率。在两层之间，我们将深度学习模型的预测结果与逻辑规则中的基原子对齐，以修正错误。这表明 GBPGR 既能拟合带标签的数据，又能拟合符号知识。此外，MLN 通过利用联合概率分布值来量化逻辑规则的拟合程度，在拟合符号知识方面起着至关重要的作用。SRM 的目标是使用 SRL 学习变量，并引导 NRM 朝着正确的方向进行推理，起到纠错器的作用。我们的 SRM 与任务无关，一旦构建了概率图模型，就可以在变分期望最大化(Variational Expectation - Maximization，EM)框架中相应地执行。

Logic rules are a type of commonsense knowledge that is easily understood by humans. In this paper, we consider the FOL language as a means to describe knowledge in the form of logic rules, which offers a strong expressive ability [35]. FOL allows for the definition of any predicates and the description of any relations. In Fig. 2b, the SRM consists of two types of nodes (random variables) and cliques (potential functions). Let $y$ represent the set of high-level nodes, and let $A$ represent the set of low-level nodes, which consist of the ground atoms in the logic rules. A clique $\left\{  {{\widehat{y}}_{i},{A}_{j}}\right\}$ expresses the correlation between the levels. Additionally, subset ${A}_{r} = \left\{  {{A}_{1},\cdots ,{A}_{m}}\right\}$ represents a clique composed of the ground atoms corresponding to a logic rule $r$ , achieved by assigning constants to its arguments. In this study, to obtain the low-level nodes, we need to perform grounding of the logic rules, meaning that predicates are instantiated by constants (which are feature vectors in this paper). To accomplish this, we employ fuzzy logic techniques such as t-norm [18] for instantiation. However, if we were to perform grounding for all logic rules in the database, the number of variables would become excessively large, increasing the complexity of the models. Therefore, during training, the model can identify logic rules that are strongly related to the data, such as predicates that contain the same labels as the data in a logic rule. The optimization goal of the SRM is defined as ${O}_{\text{logic }}$ in Eq. (6), which is to maximize a joint probability distribution over all variables,

逻辑规则是一种人类易于理解的常识性知识。在本文中，我们将一阶逻辑(FOL)语言作为以逻辑规则形式描述知识的手段，它具有强大的表达能力[35]。一阶逻辑允许定义任何谓词并描述任何关系。在图2b中，结构风险最小化(SRM)模型由两种类型的节点(随机变量)和团(势函数)组成。令 $y$ 表示高层节点的集合，令 $A$ 表示低层节点的集合，这些低层节点由逻辑规则中的基原子组成。团 $\left\{  {{\widehat{y}}_{i},{A}_{j}}\right\}$ 表示不同层之间的相关性。此外，子集 ${A}_{r} = \left\{  {{A}_{1},\cdots ,{A}_{m}}\right\}$ 表示由对应于逻辑规则 $r$ 的基原子组成的团，这是通过为其参数分配常量来实现的。在本研究中，为了获得低层节点，我们需要对逻辑规则进行基化处理，即谓词由常量(本文中为特征向量)实例化。为了实现这一点，我们采用模糊逻辑技术，如t-范数[18]进行实例化。然而，如果我们要对数据库中的所有逻辑规则进行基化处理，变量的数量将变得过大，从而增加模型的复杂度。因此，在训练过程中，模型可以识别与数据密切相关的逻辑规则，例如逻辑规则中包含与数据相同标签的谓词。结构风险最小化模型的优化目标在公式(6)中定义为 ${O}_{\text{logic }}$，即最大化所有变量的联合概率分布。

$$
{O}_{\text{logic }} = {P}_{{\theta }_{2}, w}\left( {\widehat{y}, R}\right)  = \frac{1}{Z\left( w\right) }\exp \left\{  {\mathop{\sum }\limits_{{{\widehat{y}}_{i} \in  \widehat{y},{A}_{j} \in  A}}{\phi }_{b}\left( {{\widehat{y}}_{i},{A}_{j}}\right) }\right.
$$

$$
\left. {+\mathop{\sum }\limits_{{r \in  R}}{w}_{r}\mathop{\sum }\limits_{{A}_{r}}{\phi }_{l}\left( {A}_{r}\right) }\right\}  ,
$$

(6)

where ${\phi }_{b}$ is the potential function between levels and implies a distribution that encourages the connected high-level nodes and low-level nodes to take the same values, and it is formalized as ${\phi }_{b}\left( {{\widehat{y}}_{i},{A}_{j}}\right)  = {\begin{Vmatrix}{\widehat{y}}_{i} - {A}_{j}\end{Vmatrix}}_{2}$ and ${\phi }_{l}$ is the potential function of the low-level layer and represents the time of the logic rules are true.

其中 ${\phi }_{b}$ 是层间的势函数，表示一种促使相连的高层节点和低层节点取相同值的分布，其形式化为 ${\phi }_{b}\left( {{\widehat{y}}_{i},{A}_{j}}\right)  = {\begin{Vmatrix}{\widehat{y}}_{i} - {A}_{j}\end{Vmatrix}}_{2}$，${\phi }_{l}$ 是低层的势函数，表示逻辑规则为真的时间。

In the high-level layer, the nodes represent the preliminary reasoning results, and there are no edges connecting these nodes. To form the cliques $\left\{  {{\widehat{y}}_{i},{A}_{j}}\right\}$ between the high-level and low-level nodes, we establish connections based on identifiers that nodes with the same identifier are connected. Additionally, to incorporate error correction, we utilize the ${L}_{2}$ norm between the high-level and low-level nodes as a potential function ${\phi }_{b}$ to align them in the joint probability distribution. During training, the ${L}_{2}$ norm decreases, indicating that the SRM acts as a regularization mechanism for error correction. Moreover, the decrease in the ${L}_{2}$ norm signifies that the NRM learns more information from symbolic knowledge.

在高层中，节点表示初步推理结果，且这些节点之间没有边相连。为了在高层节点和低层节点之间形成团 $\left\{  {{\widehat{y}}_{i},{A}_{j}}\right\}$，我们根据标识符建立连接，即具有相同标识符的节点相互连接。此外，为了进行纠错，我们利用高层节点和低层节点之间的 ${L}_{2}$ 范数作为势函数 ${\phi }_{b}$，以使它们在联合概率分布中对齐。在训练过程中，${L}_{2}$ 范数减小，这表明结构风险最小化模型起到了纠错的正则化机制的作用。此外，${L}_{2}$ 范数的减小意味着神经关系模型(NRM)从符号知识中学习到了更多信息。

The low-level layer is MLNs, where nodes are ground atoms in FOLs, and edges are the relations that nodes co-occur in at least one ground FOL. To show the construction process, we use an example to illustrate. Constant set is $C = \left\{  {{c}_{1},{c}_{2}}\right\}$ from the NRM and FOL is likecat $\left( x\right)  \land  \operatorname{tawny}\left( x\right)  \land  \operatorname{spot}\left( x\right)  \Rightarrow$ leopard(x). First, we can get ground atoms by instantiation such as ${A}_{r} = \left\{  {\text{ likecat }\left( {c}_{1}\right) ,\text{ likecat }\left( {c}_{2}\right) ,}\right.$ tawny $\left( {c}_{1}\right) ,$ tawny $\left( {c}_{2}\right) ,$ $\operatorname{spot}\left( {c}_{1}\right) ,\operatorname{spot}\left( {c}_{2}\right) ,\operatorname{leopard}\left( {c}_{1}\right) ,\operatorname{leopard}\left( {c}_{2}\right) \}$ ; Second, ground atoms are combined according to FOL, which attains two ground FOLs likecat $\left( {c}_{1}\right)  \land$ tawny $\left( {c}_{1}\right)  \land  \operatorname{spot}\left( {c}_{1}\right)  \Rightarrow$ leopard $\left( {c}_{1}\right)$ and likecat $\left( {c}_{2}\right)  \land$ $\operatorname{tawny}\left( {c}_{2}\right)  \land  \operatorname{spot}\left( {c}_{2}\right)  \Rightarrow  \operatorname{leopard}\left( {c}_{2}\right)$ ; Finally, we construct ground FOLs via MLN, e.g., Eq. (3).

底层是马尔可夫逻辑网络(MLNs)，其中节点是一阶逻辑(FOLs)中的基原子，边是节点在至少一个基一阶逻辑中同时出现的关系。为了展示构建过程，我们用一个例子来说明。常量集是来自神经推理模块(NRM)的 $C = \left\{  {{c}_{1},{c}_{2}}\right\}$，一阶逻辑如 likecat $\left( x\right)  \land  \operatorname{tawny}\left( x\right)  \land  \operatorname{spot}\left( x\right)  \Rightarrow$ leopard(x)。首先，我们可以通过实例化得到基原子，如 ${A}_{r} = \left\{  {\text{ likecat }\left( {c}_{1}\right) ,\text{ likecat }\left( {c}_{2}\right) ,}\right.$ tawny $\left( {c}_{1}\right) ,$ tawny $\left( {c}_{2}\right) ,$ $\operatorname{spot}\left( {c}_{1}\right) ,\operatorname{spot}\left( {c}_{2}\right) ,\operatorname{leopard}\left( {c}_{1}\right) ,\operatorname{leopard}\left( {c}_{2}\right) \}$；其次，基原子根据一阶逻辑进行组合，得到两个基一阶逻辑，如 likecat $\left( {c}_{1}\right)  \land$ tawny $\left( {c}_{1}\right)  \land  \operatorname{spot}\left( {c}_{1}\right)  \Rightarrow$ leopard $\left( {c}_{1}\right)$ 和 likecat $\left( {c}_{2}\right)  \land$ $\operatorname{tawny}\left( {c}_{2}\right)  \land  \operatorname{spot}\left( {c}_{2}\right)  \Rightarrow  \operatorname{leopard}\left( {c}_{2}\right)$；最后，我们通过马尔可夫逻辑网络构建基一阶逻辑，例如公式(3)。

## Optimization

## 优化

The GBPGR model consists of two neural networks: the NRM (Neural Reasoning Module) and the concept network, as well as a probabilistic graphical model known as the SRM (Symbolic Reasoning Module). The NRM is responsible for predicting data labels, while the concept network aims to infer the labels of hidden variables, which are variables present in logical rules but not in the dataset. The SRM learns a joint distribution to perform reasoning.

GBPGR 模型由两个神经网络组成:神经推理模块(NRM)和概念网络，以及一个称为符号推理模块(SRM)的概率图模型。神经推理模块负责预测数据标签，而概念网络旨在推断隐藏变量的标签，隐藏变量是存在于逻辑规则中但不在数据集中的变量。符号推理模块学习联合分布以进行推理。

To achieve end-to-end training, the GBPGR model utilizes the variational EM algorithm. The training process involves iteratively optimizing the parameters of the NRM, SRM and concept network. In the E-step, the posterior distribution of the latent variables is inferred, while in the M-step, the weights of the logic rules are learned. The training phase continues until the model reaches convergence, meaning that no further improvement is observed. The parameters of the NRM are denoted as ${\theta }_{1}$ , the parameters of the concept network as ${\theta }_{2}$ , and $w$ represents the weights of the logic rules in the SRM.

为了实现端到端训练，GBPGR 模型采用变分期望最大化(EM)算法。训练过程包括迭代优化神经推理模块、符号推理模块和概念网络的参数。在 E 步中，推断潜在变量的后验分布，而在 M 步中，学习逻辑规则的权重。训练阶段持续到模型收敛，即不再观察到进一步的改进。神经推理模块的参数表示为 ${\theta }_{1}$，概念网络的参数表示为 ${\theta }_{2}$，$w$ 表示符号推理模块中逻辑规则的权重。

We need to maximize $O$ to train the whole model. However, due to the requirement of computing the partition function $Z\left( w\right)$ in ${P}_{{\theta }_{2}, w}\left( {\widehat{y}, R}\right)$ , it is intractable to optimize this objective function directly. Therefore, we introduce the variational EM algorithm and optimize the variational evidence lower bound (ELBO):

我们需要最大化 $O$ 来训练整个模型。然而，由于需要计算 ${P}_{{\theta }_{2}, w}\left( {\widehat{y}, R}\right)$ 中的配分函数 $Z\left( w\right)$，直接优化这个目标函数是难以处理的。因此，我们引入变分期望最大化算法并优化变分证据下界(ELBO):

$$
{ELBO} = {E}_{{Q}_{{\theta }_{2}}}\left\lbrack  {\log {P}_{w}\left( {\widehat{y}, R}\right) }\right\rbrack   - {E}_{{Q}_{{\theta }_{2}}}\left\lbrack  {\log {Q}_{{\theta }_{2}}\left( {\widehat{y} \mid  R}\right) }\right\rbrack  ,
$$

(7)

where ${Q}_{{\theta }_{2}}\left( {\widehat{y} \mid  R}\right)$ is the variational posterior distribution.

其中 ${Q}_{{\theta }_{2}}\left( {\widehat{y} \mid  R}\right)$ 是变分后验分布。

In general, we can use the variational EM algorithm to optimize the ELBO. That is, we minimize KL divergence between the variational posterior distribution ${Q}_{{\theta }_{2}}\left( {\widehat{y} \mid  R}\right)$ and the true posterior distribution ${P}_{w}\left( {\widehat{y} \mid  R}\right)$ during the E-step. Due to the complicated graph structure among variables, the exact inference is computationally intractable. Therefore, we adopt a mean-field distribution to approximate the true posterior. The variables are independently inferred as follows:

一般来说，我们可以使用变分期望最大化算法来优化变分证据下界。也就是说，我们在 E 步中最小化变分后验分布 ${Q}_{{\theta }_{2}}\left( {\widehat{y} \mid  R}\right)$ 和真实后验分布 ${P}_{w}\left( {\widehat{y} \mid  R}\right)$ 之间的 KL 散度。由于变量之间的图结构复杂，精确推断在计算上是难以处理的。因此，我们采用平均场分布来近似真实后验。变量的独立推断如下:

$$
{Q}_{{\theta }_{2}}\left( {\widehat{y} \mid  R}\right)  = \mathop{\prod }\limits_{{{A}_{i} \in  A}}{Q}_{{\theta }_{2}}\left( {A}_{i}\right) . \tag{8}
$$

For the convenience of calculation, traditional variational methods need a predefined distribution such as Dirichlet distribution. Unlike them, we use neural networks to parameterize the variational calculation in Eq. (8). Consequently, the variational process becomes a process of learning parameters of neural networks. We use a tensor network as our concept network to model ${Q}_{{\theta }_{2}}\left( {A}_{i}\right)$ .

为了便于计算，传统的变分方法需要一个预定义的分布，如狄利克雷分布(Dirichlet distribution)。与它们不同的是，我们使用神经网络对式(8)中的变分计算进行参数化。因此，变分过程变成了一个学习神经网络参数的过程。我们使用张量网络作为概念网络来对 ${Q}_{{\theta }_{2}}\left( {A}_{i}\right)$ 进行建模。

To attain predicate labels of the hidden variables, we first need to feed data features into concept networks. Then, the concept network outputs a binary predicate label if it is fed two feature vectors. Otherwise, it outputs the unary predicate label. For example, we input feature vector of the zebra into concept network, and concept network can output predicate "zebra". Additionally, to improve performance of the concept network by supervised information, we introduce a cross-entropy to optimization:

为了获得隐藏变量的谓词标签，我们首先需要将数据特征输入到概念网络中。然后，如果输入两个特征向量，概念网络会输出一个二元谓词标签；否则，它会输出一元谓词标签。例如，我们将斑马的特征向量输入到概念网络中，概念网络可以输出谓词“斑马”。此外，为了通过监督信息提高概念网络的性能，我们引入了交叉熵进行优化:

$$
{L}_{\text{cro }} = \mathop{\sum }\limits_{{{A}_{i} \in  A}}{Q}_{{\theta }_{2}}\left( {A}_{i}\right) \log {\widehat{y}}_{i}. \tag{9}
$$

Thus, in the E-step, Eq. (4) is rewritten as

因此，在 E 步中，式(4)被重写为

$$
O = \alpha {O}_{\text{task }} + \beta {O}_{\text{logic }} - \gamma {L}_{\text{cro }}, \tag{10}
$$

where $\alpha ,\beta$ and $\gamma$ are trade-off factor whose domains are in the interval $\left\lbrack  {0,1}\right\rbrack$ .

其中 $\alpha ,\beta$ 和 $\gamma$ 是权衡因子，其取值范围在区间 $\left\lbrack  {0,1}\right\rbrack$ 内。

In the E-step, we maximize Eq. (10) to learn a joint probability distribution ${P}_{{\theta 2}, w}$ and infer the posterior distribution of the latent variables in this paper.

在 E 步中，我们最大化式(10)以学习联合概率分布 ${P}_{{\theta 2}, w}$ 并推断本文中潜在变量的后验分布。

In the M-step, we learn the weights of the logic rules. As we need to optimize weights, the partition function $Z\left( w\right)$ in Eq. (6) is not a constant anymore, and ${Q}_{\theta 2}$ will be fixed. The partition function $Z\left( w\right)$ has an exponential number of terms, which makes it intractable to optimize ELBO directly. To solve the above problem, we use pseudo-log-likelihood [15] to approximate ELBO, which is defined as:

在 M 步中，我们学习逻辑规则的权重。由于我们需要优化权重，式(6)中的配分函数 $Z\left( w\right)$ 不再是一个常数，并且 ${Q}_{\theta 2}$ 将被固定。配分函数 $Z\left( w\right)$ 有指数级数量的项，这使得直接优化证据下界(ELBO)变得难以处理。为了解决上述问题，我们使用伪对数似然 [15] 来近似证据下界，其定义为:

$$
{P}_{w}\left( {y, R}\right)  \simeq  {E}_{{Q}_{{\theta }_{2}}}\left\lbrack  {\mathop{\sum }\limits_{{{A}_{i} \in  A}}\log {P}_{w}\left( {{A}_{i} \mid  M{B}_{{A}_{i}}}\right) }\right\rbrack  , \tag{11}
$$

where $M{B}_{{A}_{i}}$ is Markov blanket of the ground atom ${A}_{i}$ . For each rule $r$ that connects ${A}_{i}$ to its Markov blanket, we optimize the weights ${w}_{r}$ by gradient descent, the derivative is the following:

其中 $M{B}_{{A}_{i}}$ 是基原子 ${A}_{i}$ 的马尔可夫毯(Markov blanket)。对于连接 ${A}_{i}$ 与其马尔可夫毯的每个规则 $r$，我们通过梯度下降优化权重 ${w}_{r}$，其导数如下:

$$
\nabla {w}_{r}{E}_{{Q}_{{\theta }_{2}}}\left\lbrack  {\log {P}_{w}\left( {{A}_{i} \mid  M{B}_{{A}_{i}}}\right) }\right\rbrack   \simeq  \widehat{{y}_{i}} - {P}_{w}\left( {{A}_{i} \mid  M{B}_{{A}_{i}}}\right) ,
$$

(12)

where ${\widehat{y}}_{i} = 0$ or 1 if ${A}_{i}$ is an observed variable, and ${\widehat{y}}_{i} = {Q}_{{\theta }_{2}}\left( {A}_{i}\right)$ otherwise.

其中如果 ${A}_{i}$ 是一个观测变量，则 ${\widehat{y}}_{i} = 0$ 为 1，否则为 ${\widehat{y}}_{i} = {Q}_{{\theta }_{2}}\left( {A}_{i}\right)$。

## Experimental setup

## 实验设置

Tasks and datasets. For the supervised task, we use two classical datasets: Visual Relationship Detection(VRD) [36]. For the weakly supervised task, we adopt a handwritten digit dataset MNIST. In the zero-shot learning task, we use AwA2 [37] dataset.

任务和数据集。对于有监督任务，我们使用两个经典数据集:视觉关系检测(Visual Relationship Detection，VRD) [36]。对于弱监督任务，我们采用手写数字数据集 MNIST。在零样本学习任务中，我们使用 AwA2 [37] 数据集。

The VRD contains 5,000 images, with 4,000 images as training data and 1,000 images as testing data. There are 100 object classes and 70 predicates (relations). The VRD includes 37,993 relation annotations with 6,672 unique relations and 24.25 relationships per object category. This dataset contains 1,877 relationships in the test set never occur in the training set, thus allowing us to evaluate the generalization of our model in zero-shot prediction.

VRD 包含 5000 张图像，其中 4000 张图像作为训练数据，1000 张图像作为测试数据。有 100 个对象类别和 70 个谓词(关系)。VRD 包含 37993 个关系注释，有 6672 个唯一关系，每个对象类别平均有 24.25 个关系。该数据集的测试集中有 1877 个关系在训练集中从未出现过，因此我们可以评估我们的模型在零样本预测中的泛化能力。

The MNIST is a handwritten digit dataset and includes 0-9 digit images. In this paper, the task is to learn the "single-digit addition" formula given two MNIST images and a "addition" label. To implement the experiment on single-digit addition, we randomly choose the initial feature of two digits to concat a tuple and take their addition as their labels. MNIST has 60,000 train sets and 10,000 test sets.

MNIST 是一个手写数字数据集，包含 0 - 9 的数字图像。在本文中，任务是给定两张 MNIST 图像和一个“加法”标签，学习“一位数加法”公式。为了进行一位数加法实验，我们随机选择两个数字的初始特征来拼接成一个元组，并将它们的和作为标签。MNIST 有 60000 个训练集和 10000 个测试集。

The $\mathbf{{AwA2}}$ consists of 50 animal classes with 37,322 images. Training data contains 40 classes with 30,337 images and test data has 10 classes with 6,985 images. Additionally, AwA2 provides 85 numeric attribute values for each class.

$\mathbf{{AwA2}}$ 由 50 个动物类别和 37322 张图像组成。训练数据包含 40 个类别和 30337 张图像，测试数据包含 10 个类别和 6985 张图像。此外，AwA2 为每个类别提供了 85 个数值属性值。

The logic rules. In this paper, logic rules encode relationships between a subject and multiple objects for supervised tasks. Thus, we build logic rules through an artificial way for VRD. That is, we take relationship annotations together with their subjects and objects to construct a logic rule according to the annotation file in the dataset. For example, we can obtain a logic rule as laptop $\left( x\right)  \land$ next $\operatorname{to}\left( {x, y}\right)  \Rightarrow$ keyboard $\left( y\right)  \vee$ mouse(y) by the above method. As a result, the numbers of logic rules are 1,642 and 3,435 on VRD and VG200 datasets, respectively. Unlike VRD and VG200 datasets, MNIST dataset has no relationship annotation. To adapt to our weakly supervised task, we define corresponding logic rules, e.g., combining two one-digit labels and their addition label as logic rule. For example, $\operatorname{digit}\left( {x,{d}_{1}}\right)  \land$ $\operatorname{digit}\left( {y,{d}_{2}}\right)  \Rightarrow  \operatorname{addition}\left( {{d}_{1} + {d}_{2}, z}\right)$ , where the head of the logic rules is the addition label, and the body is two one-digit labels. In zero-shot learning, we design 50 logic rules for AwA2 dataset, where rule head is animal categories and rule body consists of their attributes. For instance, $\operatorname{catlike}\left( x\right)  \land  \operatorname{tawny}\left( x\right)  \land  \operatorname{spot}\left( x\right)  \Rightarrow  \operatorname{leopard}\left( x\right)$ .

逻辑规则。在本文中，逻辑规则对监督任务中一个主体与多个客体之间的关系进行编码。因此，我们通过人工方式为视觉关系检测(VRD，Visual Relationship Detection)构建逻辑规则。也就是说，我们根据数据集中的标注文件，将关系标注及其主体和客体组合起来构建逻辑规则。例如，通过上述方法，我们可以得到一个逻辑规则，如笔记本电脑 $\left( x\right)  \land$ 在……旁边 $\operatorname{to}\left( {x, y}\right)  \Rightarrow$ 键盘 $\left( y\right)  \vee$ 鼠标(y)。结果，在VRD和VG200数据集上的逻辑规则数量分别为1642条和3435条。与VRD和VG200数据集不同，MNIST数据集没有关系标注。为了适应我们的弱监督任务，我们定义了相应的逻辑规则，例如，将两个一位数标签及其相加后的标签组合成逻辑规则。例如，$\operatorname{digit}\left( {x,{d}_{1}}\right)  \land$ $\operatorname{digit}\left( {y,{d}_{2}}\right)  \Rightarrow  \operatorname{addition}\left( {{d}_{1} + {d}_{2}, z}\right)$，其中逻辑规则的头部是相加后的标签，主体是两个一位数标签。在零样本学习中，我们为AwA2数据集设计了50条逻辑规则，其中规则头部是动物类别，规则主体由它们的属性组成。例如，$\operatorname{catlike}\left( x\right)  \land  \operatorname{tawny}\left( x\right)  \land  \operatorname{spot}\left( x\right)  \Rightarrow  \operatorname{leopard}\left( x\right)$ 。

Metrics. For VRD, we adopt evaluation metrics same as [22], which runs Relationship detection (ReD) and Phrase detection (PhD) and shows recall rates (Recall@) for the top ${50}/{100}$ results, with $k = 1,{70}$ candidate relations per relationship proposal (or $k$ relationship predictions for per object box pair) before taking the top ${50}/{100}$ predictions. ReD is to input an image and output labels of triples and boxes of the objects. PhD is to input an image and output labels and boxes of triples.

评估指标。对于VRD，我们采用与文献[22]相同的评估指标，该指标运行关系检测(ReD，Relationship Detection)和短语检测(PhD，Phrase Detection)，并展示前 ${50}/{100}$ 个结果的召回率(Recall@)，在选取前 ${50}/{100}$ 个预测结果之前，每个关系提议有 $k = 1,{70}$ 个候选关系(或每对目标框有 $k$ 个关系预测)。ReD是输入一张图像，输出三元组的标签和目标的边界框。PhD是输入一张图像，输出三元组的标签和边界框。

For MNIST and AwA2, we adopt accu- $\operatorname{racy}\left( \mathbf{{Acc}}\right)$ to evaluate the performance of the model. They are defined as Eq. (13).

对于MNIST和AwA2，我们采用准确率 $\operatorname{racy}\left( \mathbf{{Acc}}\right)$ 来评估模型的性能。它们的定义如公式(13)所示。

$$
{Acc} = \frac{{TP} + {TN}}{{TP} + {TN} + {FP} + {FN}}, \tag{13}
$$

where ${TP}$ denotes true positive, ${TN}$ denotes true negative, ${FP}$ indicates false positive, and ${FN}$ is false negative.

其中 ${TP}$ 表示真阳性，${TN}$ 表示真阴性，${FP}$ 表示假阳性，${FN}$ 表示假阴性。

For the logic rule, we compute the probability of a logic rule that is true as evaluation of logic rules. Here, we adopt Lukaseiwicz of t-norm fuzzy logic [18].

对于逻辑规则，我们计算逻辑规则为真的概率，以此作为对逻辑规则的评估。在这里，我们采用卢卡西维茨(Lukaseiwicz)t - 范数模糊逻辑[18]。

Implementation details. For VRD and VG200, we use a published LS-VRU [22] as NRM. LS-VRU includes a CNN [38], Region Proposal Network (RPN), and two Fully connected layers (FCs). Before training, we use pre-trained weights on COCO [39] dataset to initialize each branch and adopt word2vec [40] as the word vector in the experiment. During training, the basic setting is the same as [22]. More specifically, we train our model for 7 epochs on VRD and VG200. We set the learning rate as ${1e} - 2$ for the first 5 epochs and ${1e} - 4$ for the rest 2 epochs. Dimension of object feature is $D = {512}$ .

实现细节。对于VRD和VG200，我们使用已发布的LS - VRU [22]作为神经规则模型(NRM，Neural Rule Model)。LS - VRU包括一个卷积神经网络(CNN，Convolutional Neural Network)[38]、区域提议网络(RPN，Region Proposal Network)和两个全连接层(FCs，Fully connected layers)。在训练之前，我们使用在COCO [39]数据集上的预训练权重来初始化每个分支，并在实验中采用词向量模型(word2vec)[40]作为词向量。在训练过程中，基本设置与文献[22]相同。更具体地说，我们在VRD和VG200上对模型进行7个轮次(epoch)的训练。我们将前5个轮次的学习率设置为 ${1e} - 2$，后2个轮次的学习率设置为 ${1e} - 4$。目标特征的维度为 $D = {512}$。

For MNIST, the NRM of the weakly supervised task uses a CNN as an encoder where two linear layers as the classifier, and the activation function adopt ReLU and Softmax. MNIST includes 0-9 digits, so the classifier outputs a vector of 10 dimensions, and each dimension means the number of two digits. Our learning rate and epoch are ${1e} - 4$ and 15,000, respectively. Additionally, we set batch as 64 during training and batch as 1000 during the test.

对于MNIST，弱监督任务的NRM使用一个CNN作为编码器，其中两个线性层作为分类器，激活函数采用修正线性单元(ReLU，Rectified Linear Unit)和Softmax。MNIST包含0 - 9的数字，因此分类器输出一个10维的向量，每个维度表示两个数字相加的结果。我们的学习率和轮次分别为 ${1e} - 4$ 和15000。此外，我们在训练期间将批量大小设置为64，在测试期间将批量大小设置为1000。

For AwA2, we design our NRM based on LFGAA [29] method, which adds attribute align loss. More specifically, we first use ResNet101 as our backbone network to extract image feature, and images are randomly cropped to the corresponding size. Second, we select four feature mapping functions to learn attribute attention in different visual level. Finally, we use Adam optimizer and set 15 epoch, 64 as batch and learning rate are $1\mathrm{e} - 5$ .

对于AwA2数据集，我们基于LFGAA [29]方法设计了我们的NRM(归一化残差模块)，该方法增加了属性对齐损失。更具体地说，我们首先使用ResNet101作为骨干网络来提取图像特征，并将图像随机裁剪到相应的大小。其次，我们选择四个特征映射函数来学习不同视觉层次的属性注意力。最后，我们使用Adam优化器，并设置15个训练周期(epoch)，批量大小(batch)为64，学习率为 $1\mathrm{e} - 5$。

## References

## 参考文献

[1] Valiant, L.G.: Three problems in computer science. In: JACM, vol. 50, pp. 96-99 (2003)

[1] 瓦利安特(Valiant)，L.G.:计算机科学中的三个问题。见:《美国计算机协会期刊》(JACM)，第50卷，第96 - 99页(2003年)

[2] Belle, V.: Symbolic logic meets machine learning: A brief survey in infinite domains. In: SUM, pp. 3-16 (2020)

[2] 贝尔(Belle)，V.:符号逻辑与机器学习的结合:无限域中的简要综述。见:《可扩展不确定性管理会议》(SUM)，第3 - 16页(2020年)

[3] Hitzler, P., Sarker, M.K.: Neuro-symbolic artificial intelligence: The state of the art. In: Neuro-Symbolic Artificial Intelligence (2021)

[3] 希茨勒(Hitzler)，P.，萨克尔(Sarker)，M.K.:神经符号人工智能:现状。见:《神经符号人工智能》(2021年)

[4] Curry, E., Salwala, D., Dhingra, P., Pontes,

[4] 柯里(Curry)，E.，萨尔瓦拉(Salwala)，D.，丁格拉(Dhingra)，P.，庞特斯(Pontes)

F.A., Yadav, P.: Multimodal event processing: A neural-symbolic paradigm for the internet of multimedia things. IOTJ 9(15), 13705-13724 (2022)

F.A.，亚达夫(Yadav)，P.:多模态事件处理:多媒体物联网的神经符号范式。《物联网期刊》(IOTJ)9(15)，13705 - 13724(2022年)

[5] Yu, D., Yang, B., Liu, D., Wang, H., Pan, S.: A survey on neural-symbolic systems. NN (2022)

[5] 余(Yu)，D.，杨(Yang)，B.，刘(Liu)，D.，王(Wang)，H.，潘(Pan)，S.:神经符号系统综述。《神经网络》(NN)(2022年)

[6] Qu, M., Tang, J.: Probabilistic logic neural networks for reasoning. NIPS 32 (2019)

[6] 曲(Qu)，M.，唐(Tang)，J.:用于推理的概率逻辑神经网络。《神经信息处理系统大会》(NIPS)32(2019年)

[7] Zhang, Y., Chen, X., Yang, Y., Ramamurthy, A., Li, B., Qi, Y., Song, L.: Efficient probabilistic logic reasoning with graph neural networks. ICLR (2020)

[7] 张(Zhang)，Y.，陈(Chen)，X.，杨(Yang)，Y.，拉马穆尔西(Ramamurthy)，A.，李(Li)，B.，齐(Qi)，Y.，宋(Song)，L.:基于图神经网络的高效概率逻辑推理。《国际学习表征会议》(ICLR)(2020年)

[8] Mao, J., Gan, C., Kohli, P., Tenenbaum, J.B., Wu, J.: The neuro-symbolic concept learner: Interpreting scenes, words, and sentences from natural supervision. In: arXiv Preprint arXiv:1904.12584 (2019)

[8] 毛(Mao)，J.，甘(Gan)，C.，科利(Kohli)，P.，特南鲍姆(Tenenbaum)，J.B.，吴(Wu)，J.:神经符号概念学习器:从自然监督中解释场景、单词和句子。见:预印本arXiv:1904.12584(2019年)

[9] Xu, J., Zhang, Z., Friedman, T., Liang, Y., Broeck, G.: A semantic loss function for deep learning with symbolic knowledge. In: ICML, pp. 5502-5511 (2018)

[9] 徐(Xu)，J.，张(Zhang)，Z.，弗里德曼(Friedman)，T.，梁(Liang)，Y.，布罗克(Broeck)，G.:用于结合符号知识的深度学习的语义损失函数。见:《国际机器学习会议》(ICML)，第5502 - 5511页(2018年)

[10] Xie, Y., Xu, Z., Kankanhalli, M.S., Meel, K.S., Soh, H.: Embedding symbolic knowledge into deep networks. NIPS (2019)

[10] 谢(Xie)，Y.，徐(Xu)，Z.，坎坎哈利(Kankanhalli)，M.S.，米尔(Meel)，K.S.，苏(Soh)，H.:将符号知识嵌入到深度网络中。《神经信息处理系统大会》(NIPS)(2019年)

[11] Luo, R., Zhang, N., Han, B., Yang, L.: Context-aware zero-shot recognition. In: AAAI, vol. 34, pp. 11709-11716 (2020)

[11] 罗(Luo)，R.，张(Zhang)，N.，韩(Han)，B.，杨(Yang)，L.:上下文感知的零样本识别。见:《美国人工智能协会会议》(AAAI)，第34卷，第11709 - 11716页(2020年)

[12] Manhaeve, R., Dumančić, S., Kimmig, A., Demeester, T., De Raedt, L.: Neural probabilistic logic programming in deepproblog. AI 298, 103504 (2021)

[12] 曼哈埃夫(Manhaeve)，R.，杜曼契奇(Dumančić)，S.，基米希(Kimmig)，A.，德梅斯特(Demeester)，T.，德拉埃特(De Raedt)，L.:深度概率逻辑编程中的神经概率逻辑编程。《人工智能》(AI)298，103504(2021年)

[13] Zhou, Z.-H.: Abductive learning: towards bridging machine learning and logical reasoning. SCIS $\mathbf{{62}}\left( 7\right) ,1 - 3\left( {2019}\right)$

[13] 周(Zhou)，Z.-H.:溯因学习:迈向连接机器学习和逻辑推理。《科学通报》(SCIS) $\mathbf{{62}}\left( 7\right) ,1 - 3\left( {2019}\right)$

[14] Getoor, L., Taskar, B.: Introduction to Statistical Relational Learning, (2007)

[14] 格托尔(Getoor)，L.；塔斯卡(Taskar)，B.:《统计关系学习导论》(2007年)

[15] Richardson, M., Domingos, P.: Markov logic networks. ML 62(1), 107-136 (2006)

[15] 理查森(Richardson)，M.；多明戈斯(Domingos)，P.:马尔可夫逻辑网络。《机器学习》62(1)，第107 - 136页(2006年)

[16] Domingos, P., Lowd, D.: Unifying logical and

[16] 多明戈斯(Domingos)，P.；洛德(Lowd)，D.:用马尔可夫逻辑统一逻辑人工智能和统计人工智能

statistical ai with markov logic. Communications of the ACM 62(7), 74-83 (2019)

《美国计算机协会通讯》62(7)，第74 - 83页(2019年)

[17] Yu, D., Yang, B., Wei, Q., Li, A., Pan, S.: A probabilistic graphical model based on neural-symbolic reasoning for visual relationship detection. In: CVPR, pp. 10609-10618 (2022)

[17] 于(Yu)，D.；杨(Yang)，B.；魏(Wei)，Q.；李(Li)，A.；潘(Pan)，S.:基于神经符号推理的概率图模型用于视觉关系检测。见:《计算机视觉与模式识别会议论文集》，第10609 - 10618页(2022年)

[18] Novák, V., Perfilieva, I., Mockor, J.: Mathematical Principles of Fuzzy Logic vol. 517, (2012)

[18] 诺瓦克(Novák)，V.；佩尔菲利耶娃(Perfilieva)，I.；莫科尔(Mockor)，J.:《模糊逻辑的数学原理》第517卷(2012年)

[19] Yu, R., Li, A., Morariu, V.I., Davis, L.S.: Visual relationship detection with internal and external linguistic knowledge distillation. In: ECCV, pp. 1974-1982 (2017)

[19] 于(Yu)，R.；李(Li)，A.；莫拉里乌(Morariu)，V.I.；戴维斯(Davis)，L.S.:利用内部和外部语言知识蒸馏进行视觉关系检测。见:《欧洲计算机视觉会议论文集》，第1974 - 1982页(2017年)

[20] Yin, G., Sheng, L., Liu, B., Yu, N., Wang, X., Shao, J., Loy, C.C.: Zoom-net: Mining deep feature interactions for visual relationship recognition. In: ECCV, pp. 322-338 (2018)

[20] 尹(Yin)，G.；盛(Sheng)，L.；刘(Liu)，B.；于(Yu)，N.；王(Wang)，X.；邵(Shao)，J.；洛伊(Loy)，C.C.:变焦网络(Zoom - net):挖掘深度特征交互用于视觉关系识别。见:《欧洲计算机视觉会议论文集》，第322 - 338页(2018年)

[21] Zhan, Y., Yu, J., Yu, T., Tao, D.: On exploring undetermined relationships for visual relationship detection. In: CVPR, pp. 5128- 5137 (2019)

[21] 詹(Zhan)，Y.；于(Yu)，J.；于(Yu)，T.；陶(Tao)，D.:探索未确定关系用于视觉关系检测。见:《计算机视觉与模式识别会议论文集》，第5128 - 5137页(2019年)

[22] Zhang, J., Kalantidis, Y., Rohrbach, M., Paluri, M., Elgammal, A., Elhoseiny, M.: Large-scale visual relationship understanding. In: AAAI, vol. 33, pp. 9185-9194 (2019)

[22] 张(Zhang)，J.；卡兰蒂迪斯(Kalantidis)，Y.；罗尔巴赫(Rohrbach)，M.；帕卢里(Paluri)，M.；埃尔加马尔(Elgammal)，A.；埃尔霍塞尼(Elhoseiny)，M.:大规模视觉关系理解。见:《美国人工智能协会会议论文集》第33卷，第9185 - 9194页(2019年)

[23] Lin, X., Ding, C., Zeng, J., Tao, D.: Gps-net: Graph property sensing network for scene graph generation. In: CVPR, pp. 3746-3753 (2020)

[23] 林(Lin)，X.；丁(Ding)，C.；曾(Zeng)，J.；陶(Tao)，D.:GPS网络(Gps - net):用于场景图生成的图属性感知网络。见:《计算机视觉与模式识别会议论文集》，第3746 - 3753页(2020年)

[24] Hung, Z.-S., Mallya, A., Lazebnik, S.: Contextual translation embedding for visual relationship detection and scene graph generation. TPAMI 43(11), 3820-3832 (2020)

[24] 洪(Hung)，Z. - S.；马利亚(Mallya)，A.；拉泽布尼克(Lazebnik)，S.:用于视觉关系检测和场景图生成的上下文翻译嵌入。《模式分析与机器智能汇刊》43(11)，第3820 - 3832页(2020年)

[25] Hu, Y., Chen, S., Chen, X., Zhang, Y., Gu, X.: Neural message passing for visual relationship detection. arXiv preprint arXiv:2208.04165 (2022)

[25] 胡(Hu)，Y.；陈(Chen)，S.；陈(Chen)，X.；张(Zhang)，Y.；顾(Gu)，X.:用于视觉关系检测的神经消息传递。预印本arXiv:2208.04165(2022年)

[26] Paul, A., Krishnan, N.C., Munjal, P.: Semantically aligned bias reducing zero shot learning. In: CVPR, pp. 7056-7065 (2019)

[26] 保罗(Paul)，A.；克里什南(Krishnan)，N.C.；蒙贾尔(Munjal)，P.:语义对齐的无偏零样本学习。见:《计算机视觉与模式识别会议论文集》，第7056 - 7065页(2019年)

[27] Ding, Z., Liu, H.: Marginalized latent seman-

[27] 丁(Ding)，Z.；刘(Liu)，H.:用于零样本学习的边缘化潜在语义编码器

tic encoder for zero-shot learning. In: CVPR, pp. 6191-6199 (2019)

见:《计算机视觉与模式识别会议论文集》，第6191 - 6199页(2019年)

[28] Xie, G.-S., Liu, L., Jin, X., Zhu, F., Zhang, Z., Qin, J., Yao, Y., Shao, L.: Attentive region embedding network for zero-shot learning. In: CVPR, pp. 9384-9393 (2019)

[28] 谢(Xie)，G.-S.；刘(Liu)，L.；金(Jin)，X.；朱(Zhu)，F.；张(Zhang)，Z.；秦(Qin)，J.；姚(Yao)，Y.；邵(Shao)，L.:用于零样本学习的注意力区域嵌入网络。见:计算机视觉与模式识别会议(CVPR)，第9384 - 9393页(2019年)

[29] Liu, Y., Guo, J., Cai, D., He, X.: Attribute attention for semantic disambiguation in zero-shot learning. In: ECCV, pp. 6698-6707 (2019)

[29] 刘(Liu)，Y.；郭(Guo)，J.；蔡(Cai)，D.；何(He)，X.:零样本学习中用于语义消歧的属性注意力。见:欧洲计算机视觉会议(ECCV)，第6698 - 6707页(2019年)

[30] Huynh, D., Elhamifar, E.: Fine-grained generalized zero-shot learning via dense attribute-based attention. In: CVPR, pp. 4483-4493 (2020)

[30] 阮(Huynh)，D.；埃尔哈米法尔(Elhamifar)，E.:通过基于密集属性的注意力实现细粒度广义零样本学习。见:计算机视觉与模式识别会议(CVPR)，第4483 - 4493页(2020年)

[31] Xu, W., Xian, Y., Wang, J., Schiele, B., Akata, Z.: Attribute prototype network for zero-shot learning. NIPS 33, 21969-21980 (2020)

[31] 徐(Xu)、冼(Xian)、王(Wang)、席勒(Schiele)、阿卡塔(Akata):用于零样本学习的属性原型网络。《神经信息处理系统大会论文集》(NIPS)33，21969 - 21980(2020)

[32] Yang, B., Zhang, Y., Peng, Y., Zhang, c., Hang, J.: Collaborative filtering based zero-shot learning. Journal of Software $\mathbf{{32}}\left( 9\right)$ , 2801-2815 (2021)

[32] 杨(Yang)、张(Zhang)、彭(Peng)、张(Zhang)、杭(Hang):基于协同过滤的零样本学习。《软件学报》$\mathbf{{32}}\left( 9\right)$，2801 - 2815(2021)

[33] Chen, Z., Huang, Y., Chen, J., Geng, Y., Zhang, W., Fang, Y., Pan, J.Z., Chen, H.: Duet: Cross-modal semantic grounding for contrastive zero-shot learning. In: AAAI, vol. 37, pp. 405-413 (2023)

[33] 陈(Chen)、黄(Huang)、陈(Chen)、耿(Geng)、张(Zhang)、方(Fang)、潘(Pan)、陈(Chen):二重奏(Duet):用于对比零样本学习的跨模态语义基础。见:《美国人工智能协会会议论文集》(AAAI)，第37卷，第405 - 413页(2023)

[34] Chen, S., Hong, Z., Xie, G.-S., Yang, W., Peng, Q., Wang, K., Zhao, J., You, X.: Msdn: Mutually semantic distillation network for zero-shot learning. In: CVPR, pp. 7612-7621 (2022)

[34] 陈(Chen)、洪(Hong)、谢(Xie)、杨(Yang)、彭(Peng)、王(Wang)、赵(Zhao)、尤(You):MSDN:用于零样本学习的相互语义蒸馏网络。见:《计算机视觉与模式识别会议论文集》(CVPR)，第7612 - 7621页(2022)

[35] Enderton, H.B.: A Mathematical Introduction to Logic, (2001)

[35] 恩德尔顿(Enderton):《数理逻辑引论》(A Mathematical Introduction to Logic)(2001)

[36] Lu, C., Krishna, R., Bernstein, M., Fei-Fei, L.: Visual relationship detection with language priors. In: ECCV, pp. 852-869 (2016)

[36] 陆(Lu)、克里希纳(Krishna)、伯恩斯坦(Bernstein)、李菲菲(Fei - Fei):利用语言先验进行视觉关系检测。见:《欧洲计算机视觉会议论文集》(ECCV)，第852 - 869页(2016)

[37] Xian, Y., Lampert, C.H., Schiele, B., Akata, Z.: Zero-shot learning-a comprehensive evaluation of the good, the bad and the ugly. In: TPAMI, vol. 41, pp. 2251-2265 (2019)

[37] 冼(Xian)、兰佩特(Lampert)、席勒(Schiele)、阿卡塔(Akata):零样本学习——对好坏优劣的全面评估。见:《模式分析与机器智能汇刊》(TPAMI)，第41卷，第2251 - 2265页(2019)

[38] O'Shea, K., Nash, R.: An introduction to convolutional neural networks. arXiv preprint arXiv:1511.08458 (2015)

[38] 奥谢(O'Shea)、纳什(Nash):卷积神经网络导论。预印本arXiv:1511.08458(2015)

[39] Lin, T.-Y., Maire, M., Belongie, S., Hays, J., Perona, P., Ramanan, D., Dollár, P., Zit-nick, C.L.: Microsoft coco: Common objects in context. In: ECCV, pp. 740-755 (2014)

[39] 林(Lin)、梅尔(Maire)、贝隆吉(Belongie)、海斯(Hays)、佩罗纳(Perona)、拉马南(Ramanan)、多尔(Dollár)、齐特尼克(Zit - nick):微软COCO数据集:上下文中的常见物体。见:《欧洲计算机视觉会议论文集》(ECCV)，第740 - 755页(2014)

[40] Mikolov, T., Sutskever, I., Chen, K., Corrado, G.S., Dean, J.: Distributed representations of words and phrases and their compositionality. In: NIPS, pp. 3111-3119 (2013)

[40] 米科洛夫(Mikolov)、苏茨克维(Sutskever)、陈(Chen)、科拉多(Corrado)、迪恩(Dean):单词和短语的分布式表示及其组合性。见:《神经信息处理系统大会论文集》(NIPS)，第3111 - 3119页(2013)