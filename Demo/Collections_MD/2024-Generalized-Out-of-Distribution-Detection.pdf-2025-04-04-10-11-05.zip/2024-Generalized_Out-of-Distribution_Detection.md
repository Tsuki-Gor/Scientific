# Generalized Out-of-Distribution Detection: A Survey

# 广义分布外检测:综述

Jingkang Yang ${}^{1} \cdot  {\text{Kaiyang Zhou}}^{1} \cdot$ Yixuan ${\mathrm{{Li}}}^{2} \cdot$ Ziwei ${\mathrm{{Liu}}}^{1}\square$

杨景康 ${}^{1} \cdot  {\text{Kaiyang Zhou}}^{1} \cdot$ 李逸轩 ${\mathrm{{Li}}}^{2} \cdot$ 刘子微 ${\mathrm{{Liu}}}^{1}\square$

Received: 27 April 2023 / Accepted: 26 April 2024 / Published online: 23 June 2024

收稿日期:2023年4月27日 / 录用日期:2024年4月26日 / 在线发表日期:2024年6月23日

© The Author(s), under exclusive licence to Springer Science+Business Media, LLC, part of Springer Nature 2024

© 作者(们)，2024年独家授权给施普林格科学商业媒体有限责任公司，施普林格自然旗下一部分

## Abstract

## 摘要

Out-of-distribution (OOD) detection is critical to ensuring the reliability and safety of machine learning systems. For instance, in autonomous driving, we would like the driving system to issue an alert and hand over the control to humans when it detects unusual scenes or objects that it has never seen during training time and cannot make a safe decision. The term, OOD detection, first emerged in 2017 and since then has received increasing attention from the research community, leading to a plethora of methods developed, ranging from classification-based to density-based to distance-based ones. Meanwhile, several other problems, including anomaly detection (AD), novelty detection (ND), open set recognition (OSR), and outlier detection (OD), are closely related to OOD detection in terms of motivation and methodology. Despite common goals, these topics develop in isolation, and their subtle differences in definition and problem setting often confuse readers and practitioners. In this survey, we first present a unified framework called generalized OOD detection, which encompasses the five aforementioned problems, i.e., AD, ND, OSR, OOD detection, and OD. Under our framework, these five problems can be seen as special cases or sub-tasks, and are easier to distinguish. Despite comprehensive surveys of related fields, the summarization of OOD detection methods remains incomplete and requires further advancement. This paper specifically addresses the gap in recent technical developments in the field of OOD detection. It also provides a comprehensive discussion of representative methods from other sub-tasks and how they relate to and inspire the development of OOD detection methods. The survey concludes by identifying open challenges and potential research directions.

分布外(OOD)检测对于确保机器学习系统的可靠性和安全性至关重要。例如，在自动驾驶中，当驾驶系统检测到训练期间从未见过且无法做出安全决策的异常场景或物体时，我们希望它能发出警报并将控制权交给人类。“分布外检测”这一术语于2017年首次出现，此后受到了研究界越来越多的关注，催生了大量的方法，包括基于分类、基于密度和基于距离的方法。同时，其他几个问题，包括异常检测(AD)、新奇检测(ND)、开放集识别(OSR)和离群点检测(OD)，在动机和方法上与分布外检测密切相关。尽管目标相似，但这些主题各自独立发展，它们在定义和问题设定上的细微差异常常使读者和从业者感到困惑。在本综述中，我们首先提出了一个名为广义分布外检测的统一框架，该框架涵盖了上述五个问题，即异常检测、新奇检测、开放集识别、分布外检测和离群点检测。在我们的框架下，这五个问题可以被视为特殊情况或子任务，更容易区分。尽管已有相关领域的综合综述，但分布外检测方法的总结仍不完整，需要进一步完善。本文特别填补了分布外检测领域近期技术发展的空白。它还全面讨论了来自其他子任务的代表性方法，以及它们如何与分布外检测方法的发展相关并提供启发。综述最后指出了尚未解决的挑战和潜在的研究方向。

Keywords Out-of-distribution detection $\cdot$ AI safety $\cdot$ Model trustworthiness $\cdot$ Open set recognition $\cdot$ Computer vision

关键词 分布外检测 $\cdot$ 人工智能安全 $\cdot$ 模型可信度 $\cdot$ 开放集识别 $\cdot$ 计算机视觉

## 1 Introduction

## 1 引言

A trustworthy visual recognition system should not only produce accurate predictions on known context, but also detect unknown examples and reject them (or hand them over to human users for safe handling) (Amodei et al., 2016;

一个值得信赖的视觉识别系统不仅应在已知环境下做出准确预测，还应检测出未知样本并拒绝它们(或将其交给人类用户安全处理)(阿莫迪等人，2016；

Mohseni et al., 2021; Hendrycks et al., 2021; Hendrycks & Mazeika, 2022). For instance, a well-trained food classifier should be able to detect non-food images such as selfies uploaded by users, and reject such input instead of blindly classifying them into existing food categories. In safety-critical applications such as autonomous driving, the driving system must issue a warning and hand over the control to drivers when it detects unusual scenes or objects it has never seen during training (Fig. 1).

莫赫森尼等人，2021；亨德里克斯等人，2021；亨德里克斯和梅泽卡，2022)。例如，一个训练良好的食物分类器应该能够检测出用户上传的自拍等非食物图像，并拒绝此类输入，而不是盲目地将它们分类到现有的食物类别中。在自动驾驶等安全关键应用中，当驾驶系统检测到训练期间从未见过的异常场景或物体时，必须发出警告并将控制权交给驾驶员(图1)。

Most existing machine learning models are trained based on the closed-world assumption (Krizhevsky et al., 2012; He et al., 2015), where the test data is assumed to be drawn i.i.d. from the same distribution as the training data, known as in-distribution (ID). However, when models are deployed in an open-world scenario (Drummond & Shearer, 2006), test samples can be out-of-distribution (OOD) and therefore should be handled with caution. The distributional shifts can be caused by semantic shift (e.g., OOD samples are drawn from different classes) (Hendrycks & Gimpel, 2017), or covariate shift (e.g., OOD samples from a different domain) (Ben-David et al., 2010; Li et al., 2017b; Wang & Deng, 2018).

大多数现有的机器学习模型是基于封闭世界假设进行训练的(克里热夫斯基等人，2012；何等人，2015)，即假设测试数据与训练数据来自相同的分布，且是独立同分布的，这被称为分布内(ID)。然而，当模型部署在开放世界场景中时(德拉蒙德和希勒，2006)，测试样本可能是分布外(OOD)的，因此需要谨慎处理。分布偏移可能由语义偏移(例如，分布外样本来自不同的类别)(亨德里克斯和金佩尔，2017)或协变量偏移(例如，来自不同领域的分布外样本)(本 - 戴维等人，2010；李等人，2017b；王和邓，2018)引起。

---

Communicated by Hong Liu.

由刘洪传达。

☑ Ziwei Liu

☑ 刘子微

ziwei.liu@ntu.edu.sgh

Jingkang Yang

杨景康

jingkang001@ntu.edu.sgh

Kaiyang Zhou

周开阳

kaiyang.zhou@ntu.edu.sg

Yixuan Li

李逸轩

sharonli@cs.wisc.edu

1 S-Lab, Nanyang Technological University, Singapore, Singapore

1 新加坡南洋理工大学S-Lab

2 Department of Computer Sciences, University of Wisconsin-Madison, Madison, WI, USA

2 美国威斯康星大学麦迪逊分校计算机科学系，威斯康星州麦迪逊市

---

![0195d2b3-e92e-7da1-8c3c-990b96d6d818_1_144_149_710_609_0.jpg](images/0195d2b3-e92e-7da1-8c3c-990b96d6d818_1_144_149_710_609_0.jpg)

Fig. 1 Taxonomy of generalized OOD detection framework, illustrated by classification tasks. Four bases are used for the task taxonomy: (1) Distribution shift to detect: the task focuses on detecting covariate shift or semantic shift; (2) ID data type: the ID data contains one single class or multiple classes; (3) Whether the task requires ID classification; (4) Transductive learning task requires all observations; inductive tasks follow the train-test scheme. Note that ND is often interchangeable with AD, but ND is more concerned with semantic anomalies. OOD detection is generally interchangeable with OSR for classification tasks

图1 广义分布外(OOD)检测框架的分类，以分类任务为例说明。该任务分类使用了四个依据:(1)待检测的分布偏移:任务重点在于检测协变量偏移或语义偏移；(2)分布内(ID)数据类型:ID数据包含单一类别或多个类别；(3)任务是否需要进行ID分类；(4)直推式学习任务需要所有观测值；归纳式任务遵循训练 - 测试方案。请注意，新奇检测(ND)通常可与异常检测(AD)互换使用，但ND更关注语义异常。对于分类任务，OOD检测通常可与开放集识别(OSR)互换使用

The detection of semantic distribution shift (e.g., due to the occurrence of new classes) is the focal point of OOD detection tasks, where the label space $\mathcal{Y}$ can be different between ID and OOD data and hence the model should not make any prediction. In addition to OOD detection, several problems adopt the "open-world" assumption and have a similar goal of identifying OOD examples. These include outlier detection (OD) (Aggarwal & Yu, 2001; Hodge & Austin, 2004; Ben-Gal, 2005; Wang et al., 2019a), anomaly detection (AD) (Ruff et al., 2021; Pang et al., 2020; Bulusu et al., 2020; Chalapathy & Chawla, 2019), novelty detection (ND) (Pimentel et al., 2014; Miljković, 2010; Markou & Singh, 2003a; Markou & Singh, 2003b), and open set recognition (OSR) (Boult et al., 2019; Huang & Chen, 2020; Mahdavi & Carvalho, 2021). While all these problems are related to each other by sharing similar motivations, subtle differences exist among the sub-topics in terms of the specific definition. However, the lack of a comprehensive understanding of the relationship between the different sub-topics leads to confusion for both researchers and practitioners. Even worse, these sub-topics, which are supposed to be compared and learned from each other, are developing in isolation.

语义分布偏移的检测(例如，由于新类别的出现)是OOD检测任务的重点，其中ID数据和OOD数据之间的标签空间$\mathcal{Y}$可能不同，因此模型不应进行任何预测。除了OOD检测之外，有几个问题采用了“开放世界”假设，并且具有识别OOD示例的相似目标。这些问题包括离群点检测(OD)(Aggarwal & Yu，2001；Hodge & Austin，2004；Ben - Gal，2005；Wang等人，2019a)、异常检测(AD)(Ruff等人，2021；Pang等人，2020；Bulusu等人，2020；Chalapathy & Chawla，2019)、新奇检测(ND)(Pimentel等人，2014；Miljković，2010；Markou & Singh，2003a；Markou & Singh，2003b)和开放集识别(OSR)(Boult等人，2019；Huang & Chen，2020；Mahdavi & Carvalho，2021)。虽然所有这些问题因具有相似的动机而相互关联，但在具体定义方面，这些子主题之间存在细微差异。然而，对不同子主题之间关系缺乏全面理解，导致研究人员和从业者都感到困惑。更糟糕的是，这些本应相互比较和借鉴的子主题正在孤立地发展。

In this survey, we for the first time clarify the similarities and differences between these problems, and present a unified framework termed generalized OOD detection. Under this framework, the five problems (i.e., AD, ND, OSR, OOD detection, and OD) can be viewed as special cases or sub-topics. While other sub-topics have been extensively surveyed, the summarization of OOD detection methods is still inadequate and requires further exploration. This paper fills this gap by focusing specifically on recent technical developments in OOD detection, analyzing fair experimental comparisons among classical methods on common benchmarks. Our survey concludes by highlighting open challenges and outlining potential avenues for future research.

在本综述中，我们首次阐明了这些问题之间的异同，并提出了一个称为广义OOD检测的统一框架。在这个框架下，这五个问题(即AD、ND、OSR、OOD检测和OD)可以被视为特殊情况或子主题。虽然其他子主题已经得到了广泛的综述，但对OOD检测方法的总结仍然不足，需要进一步探索。本文通过专门关注OOD检测的最新技术发展，分析经典方法在常见基准上的公平实验比较，填补了这一空白。我们的综述最后强调了开放的挑战，并概述了未来研究的潜在途径。

We further conduct a literature review for each sub-topic, with a special focus on the OOD detection task. To sum up, we make three contributions to the research community:

我们进一步对每个子主题进行了文献综述，特别关注OOD检测任务。综上所述，我们为研究界做出了三点贡献:

1. A Unified Framework For the first time, we systematically review five closely related topics of AD, ND, OSR, OOD detection, and OD, and present a unified framework of generalized OOD detection. Under this framework, the similarities and differences of the five sub-topics can be systematically compared and analyzed. We hope our unification helps the community better understand these problems and correctly position their research in the literature.

1. 统一框架 我们首次系统地回顾了异常检测(AD)、新奇检测(ND)、开放集识别(OSR)、分布外检测(OOD检测)和离群点检测(OD)这五个密切相关的主题，并提出了广义OOD检测的统一框架。在这个框架下，可以系统地比较和分析这五个子主题的异同。我们希望我们的统一工作有助于研究界更好地理解这些问题，并在文献中正确定位他们的研究。

2. A Comprehensive Survey for OOD Detection Noticing the existence of comprehensive surveys on AD, ND, OSR, and OD methodologies in recent years (Ruff et al., 2021; Pang et al., 2020; Bulusu et al., 2020; Chalapa-thy & Chawla, 2019; Huang & Chen, 2020), this survey provides a comprehensive overview of OOD detection methods and thus complements existing surveys. By connecting with methodologies of other sub-topics that are also briefly reviewed, as well as sharing the insights from a fair comparison on a standard benchmark, we hope to provide readers with a more holistic understanding of the developments for each problem and their interconnections, especially for OOD detection.

2. OOD检测的全面综述 鉴于近年来已经有关于AD、ND、OSR和OD方法的全面综述(Ruff等人，2021；Pang等人，2020；Bulusu等人，2020；Chalapathy & Chawla，2019；Huang & Chen，2020)，本综述提供了OOD检测方法的全面概述，从而补充了现有的综述。通过与其他也进行了简要回顾的子主题的方法相联系，并分享在标准基准上的公平比较所获得的见解，我们希望为读者提供对每个问题的发展及其相互联系的更全面理解，特别是对于OOD检测。

3. Future Research Directions We draw readers' attention to some problems or limitations that remain in the current generalized OOD detection field. We conclude this survey with discussions on open challenges and opportunities for future research.

3. 未来研究方向 我们提请读者注意当前广义OOD检测领域仍然存在的一些问题或局限性。我们在本综述的结尾讨论了开放的挑战和未来研究的机会。

Organization of Remaining Sections To match the mentioned contributions, in Sect. 2, we introduce the generalized OOD detection framework and discuss related topics to better position our survey. In Sect. 3, we provide a comprehensive overview of the methodologies for OOD detection, categorizing them into four groups: (1) classification-based methods, which largely rely on classifiers; (2) density-based methods, which detect OOD by modeling data density; (3) distance-based methods, which use distance metrics (usually in the feature space) to identify OODs; and (4) reconstruction-based methods, which are characterized by reconstruction techniques. In Sect. 4, we briefly introduce methodologies for other sub-tasks, including AD, ND, OSR, and OD, to provide readers with a broader understanding of OOD-related problems and inspire the development of more effective methods. To offer readers further insights from an empirical perspective, in Sect. 5 we conduct a thorough analysis that provides a fair comparison between representative OOD detection methods and methods from other sub-tasks. Additionally, we highlight some of the remaining problems and limitations that exist in the current generalized OOD detection field. We conclude this survey with a discussion on the open challenges and opportunities for future research. It is worth noting that a concurrent survey (Salehi et al., 2021) provides a detailed explanation of OOD-related methods, which greatly complements our work.

剩余章节的组织 为了与上述贡献相匹配，在第2节中，我们介绍广义的分布外(OOD)检测框架，并讨论相关主题，以便更好地定位我们的综述。在第3节中，我们全面概述了OOD检测方法，将其分为四类:(1)基于分类的方法，主要依赖分类器；(2)基于密度的方法，通过对数据密度建模来检测OOD；(3)基于距离的方法，使用距离度量(通常在特征空间中)来识别OOD；(4)基于重构的方法，其特点是采用重构技术。在第4节中，我们简要介绍其他子任务的方法，包括异常检测(AD)、新奇检测(ND)、开放集识别(OSR)和离群点检测(OD)，以便让读者更广泛地了解与OOD相关的问题，并启发更有效方法的开发。为了从实证角度为读者提供更多见解，在第5节中，我们进行了全面分析，对有代表性的OOD检测方法和其他子任务的方法进行了公平比较。此外，我们还强调了当前广义OOD检测领域中存在的一些剩余问题和局限性。我们在本综述的结尾讨论了未来研究面临的开放性挑战和机遇。值得注意的是，一项同期综述(Salehi等人，2021年)详细解释了与OOD相关的方法，这对我们的工作起到了很好的补充作用。

![0195d2b3-e92e-7da1-8c3c-990b96d6d818_2_149_159_1456_475_0.jpg](images/0195d2b3-e92e-7da1-8c3c-990b96d6d818_2_149_159_1456_475_0.jpg)

Fig. 2 Illustration of sub-tasks under generalized OOD detection framework with vision tasks. Tags on test images refer to model's expected predictions. a In sensory anomaly detection, test images with covariate shift will be considered as OOD. No semantic shift occurs in this setting. b In one-class novelty detection, normal/ID images belong to one class. Test images with semantic shift will be considered as OOD. c In multi-class novelty detection, ID images belong to multiple classes. Test images with semantic shift will be considered as OOD. Note that $\mathbf{b}$ and $\mathbf{c}$ compose novelty detection, which is identical to the topic of semantic anomaly detection. d Open set recognition is identical to multi-class novelty detection in the task of detection, with the only difference that open set recognition further requires ID classification. Out-of-distribution detection solves the same problem as open-set recognition. It canonically aims to detect test samples with semantic shift without losing the ID classification accuracy. However, OOD Detection encompasses a broader spectrum of learning tasks and solution space. e Outlier detection does not follow a train-test scheme. All observations are provided. It fits in the generalized OOD detection framework by defining the majority distribution as ID. Outliers can have any distribution shift from the majority

图2 具有视觉任务的广义OOD检测框架下子任务的示意图。测试图像上的标签指的是模型的预期预测。a 在感官异常检测中，具有协变量偏移的测试图像将被视为OOD。在此设置中不会发生语义偏移。b 在单类新奇检测中，正常/分布内(ID)图像属于一个类别。具有语义偏移的测试图像将被视为OOD。c 在多类新奇检测中，ID图像属于多个类别。具有语义偏移的测试图像将被视为OOD。请注意，$\mathbf{b}$和$\mathbf{c}$构成了新奇检测，这与语义异常检测的主题相同。d 开放集识别在检测任务上与多类新奇检测相同，唯一的区别是开放集识别还需要进行ID分类。分布外检测解决的问题与开放集识别相同。它通常旨在检测具有语义偏移的测试样本，同时不降低ID分类的准确性。然而，OOD检测涵盖了更广泛的学习任务和解决方案空间。e 离群点检测不遵循训练 - 测试方案。提供了所有观测值。通过将多数分布定义为ID，它适用于广义OOD检测框架。离群点可能与多数分布有任何分布偏移

## 2 Generalized OOD Detection

## 2 广义OOD检测

Framework Overview In this section, we introduce a unified framework termed generalized OOD detection, which encapsulates five related sub-topics: anomaly detection (AD), novelty detection (ND), open set recognition (OSR), out-of-distribution (OOD) detection, and outlier detection (OD). These sub-topics can be similar in the sense that they all define a certain in-distribution, with the common goal of detecting out-of-distribution samples under the open-world assumption. However, subtle differences exist among the sub-topics in terms of the specific definition and properties of ID and OOD data-which are often overlooked by the research community. To this end, we provide a clear introduction and description of each sub-topic in respective subsections (from Sect.2.1 to 2.5). Each subsection details the motivation, background, formal definition, as well as relative position within the unified framework. Applications and benchmarks are also introduced, with concrete examples that facilitate understanding. Figure 2 illustrates the settings for each sub-topic. In the end, we conclude this section by introducing the neighborhood topics to clarify the scope of the generalized OOD detection framework (Sect. 2.6).

框架概述 在本节中，我们介绍一个统一的框架，称为广义OOD检测，它包含五个相关的子主题:异常检测(AD)、新奇检测(ND)、开放集识别(OSR)、分布外(OOD)检测和离群点检测(OD)。这些子主题在某种意义上可能相似，因为它们都定义了某种分布内情况，共同目标是在开放世界假设下检测分布外样本。然而，这些子主题在ID和OOD数据的具体定义和属性方面存在细微差异，而这些差异往往被研究界所忽视。为此，我们在各个小节(从第2.1节到第2.5节)中对每个子主题进行了清晰的介绍和描述。每个小节详细阐述了动机、背景、正式定义以及在统一框架中的相对位置。还介绍了应用和基准，并给出了便于理解的具体示例。图2展示了每个子主题的设置。最后，我们在本节结尾介绍了相关主题，以明确广义OOD检测框架的范围(第2.6节)。

Preliminary: Distribution Shift In our framework, we recognize the complexity and interconnectedness of distribution shifts, which are central to understanding various OOD scenarios. Distribution shifts can be broadly categorized into covariate shift and semantic (label) shift, but it's important to clarify their interdependence. Firstly, let's define the input space as $\mathcal{X}$ (sensory observations) and the label space as $\mathcal{Y}$ (semantic categories). The data distribution is represented by the joint distribution $P\left( {X, Y}\right)$ over the space $\mathcal{X} \times  \mathcal{Y}$ . Distribution shift can occur in either the marginal distribution $P\left( X\right)$ , or both $P\left( Y\right)$ and $P\left( X\right)$ . Note that shift in $P\left( Y\right)$ naturally triggers shift in $P\left( X\right)$ .

初步介绍:分布偏移 在我们的框架中，我们认识到分布偏移的复杂性和相互关联性，这对于理解各种分布外(OOD)场景至关重要。分布偏移大致可分为协变量偏移(covariate shift)和语义(标签)偏移(semantic (label) shift)，但明确它们之间的相互依赖关系很重要。首先，我们将输入空间定义为$\mathcal{X}$(感官观测值)，将标签空间定义为$\mathcal{Y}$(语义类别)。数据分布由空间$\mathcal{X} \times  \mathcal{Y}$上的联合分布$P\left( {X, Y}\right)$表示。分布偏移可能发生在边缘分布$P\left( X\right)$中，或者同时发生在$P\left( Y\right)$和$P\left( X\right)$中。请注意，$P\left( Y\right)$的偏移自然会引发$P\left( X\right)$的偏移。

Covariate Shift This occurs when there is a change in the marginal distribution $P\left( X\right)$ , affecting the input space, while the label space $\mathcal{Y}$ remains constant. Examples of covariate distribution shift on $P\left( X\right)$ include adversarial examples (Goodfellow et al., 2015; Madry et al., 2018), domain shift (Qui nonero-Candela et al., 2009), and style changes (Gatys et al., 2016). Semantic Shift This involves changes in both $P\left( Y\right)$ and indirectly $P\left( X\right)$ . A shift in the label space $P\left( Y\right)$ implies the introduction of new categories or the alteration of existing ones. This change naturally affects the input space $P\left( X\right)$ since the nature of the data being observed or collected is now different.

协变量偏移 当边缘分布$P\left( X\right)$发生变化，影响输入空间，而标签空间$\mathcal{Y}$保持不变时，就会发生这种情况。$P\left( X\right)$上的协变量分布偏移的例子包括对抗样本(Goodfellow等人，2015年；Madry等人，2018年)、领域偏移(Qui nonero - Candela等人，2009年)和风格变化(Gatys等人，2016年)。语义偏移 这涉及到$P\left( Y\right)$的变化以及间接的$P\left( X\right)$的变化。标签空间$P\left( Y\right)$的偏移意味着引入了新的类别或改变了现有的类别。这种变化自然会影响输入空间$P\left( X\right)$，因为现在观察或收集的数据的性质不同了。

Remark Given the interdependence between $P\left( X\right)$ and $P\left( Y\right)$ , it’s crucial to distinguish the intentions behind different types of distribution shifts. We define Covariate Shift as scenarios where changes are intended in the input space $\left( {P\left( X\right) }\right)$ without any deliberate alteration to the label space $\left( {P\left( Y\right) }\right)$ . On the other hand, Semantic Shift specifically aims to modify the semantic content, directly impacting the label space $\left( {P\left( Y\right) }\right)$ and, consequently, the input space $\left( {P\left( X\right) }\right)$ .

备注 鉴于$P\left( X\right)$和$P\left( Y\right)$之间的相互依赖关系，区分不同类型分布偏移背后的意图至关重要。我们将协变量偏移定义为在输入空间$\left( {P\left( X\right) }\right)$中有意进行改变，而不对标签空间$\left( {P\left( Y\right) }\right)$进行任何刻意改变的场景。另一方面，语义偏移专门旨在修改语义内容，直接影响标签空间$\left( {P\left( Y\right) }\right)$，并因此影响输入空间$\left( {P\left( X\right) }\right)$。

Importantly, we note that covariate shift is more commonly used to evaluate model generalization and robustness performance, where the label space $\mathcal{Y}$ remains the same during test time. On the other hand, the detection of semantic distribution shift (e.g., due to the occurrence of new classes) is the focal point of many detection tasks considered in this framework, where the label space $\mathcal{Y}$ can be different between ID and OOD data and hence the model should not make any prediction.

重要的是，我们注意到协变量偏移更常用于评估模型的泛化能力和鲁棒性性能，在测试时标签空间$\mathcal{Y}$保持不变。另一方面，检测语义分布偏移(例如，由于新类别的出现)是本框架中许多检测任务的重点，在这种情况下，分布内(ID)数据和分布外(OOD)数据的标签空间$\mathcal{Y}$可能不同，因此模型不应进行任何预测。

With the concept of distribution shift in mind, readers can get a general idea of the differences and connections among sub-topics/tasks in Fig. 1. Notice that different sub-tasks can be easily identified with the following four dichotomies: (1) covariate/semantic shift dichotomy; (2) single/multiple class dichotomy; (3) ID classification needed/non-needed dichotomy; (4) inductive/transductive dichotomy. Next, we proceed with elaborating on each sub-topic.

考虑到分布偏移的概念，读者可以大致了解图1中各子主题/任务之间的差异和联系。请注意，通过以下四个二分法可以轻松识别不同的子任务:(1)协变量/语义偏移二分法；(2)单类/多类二分法；(3)需要/不需要分布内分类二分法；(4)归纳/直推二分法。接下来，我们将详细阐述每个子主题。

### 2.1 Anomaly Detection

### 2.1 异常检测

Background The notion of "anomaly" stands in contrast with the "normal" defined in advance. The concept of "normal" should be clear and reflect the real task. For example, to create a "not-hotdog detector", the concept of the normal should be clearly defined as the hotdog class, i.e., a food category, so that objects that violate this definition are identified as anomalies, which include steaks, rice, and non-food objects like cats and dogs. Ideally, "hotdog" would be regarded as a homogeneous concept, regardless of the sub-classes of French or American hotdog.

背景 “异常”的概念与预先定义的“正常”概念形成对比。“正常”的概念应该清晰明确，并反映实际任务。例如，要创建一个“非热狗检测器”，“正常”的概念应明确定义为热狗类别，即一种食物类别，这样违反该定义的对象就会被识别为异常，包括牛排、米饭以及猫和狗等非食物对象。理想情况下，无论法式热狗还是美式热狗这些子类如何，“热狗”都应被视为一个同质概念。

Current anomaly detection settings often restrict the environment of interest to some specific scenarios. For example, the "not-hotdog detector" only focuses on realistic images, assuming the nonexistence of images from other domains such as sketches. Another realistic example is industrial defect detection, which is based on only one set of assembly lines for a specific product. In other words, the "open-world" assumption is usually not completely "open". Nevertheless, "not-hotdog" or "defects" can form a large unknown space that breaks the "closed-world" assumption.

当前的异常检测设置通常将关注的环境限制在某些特定场景中。例如，“非热狗检测器”仅关注真实图像，假设不存在来自其他领域(如素描)的图像。另一个实际例子是工业缺陷检测，它仅基于特定产品的一组装配线。换句话说，“开放世界”假设通常并非完全“开放”。然而，“非热狗”或“缺陷”可能形成一个巨大的未知空间，打破了“封闭世界”假设。

In summary, the key to anomaly detection is to define normal clearly (usually without sub-classes) and detect all possible anomalous samples under some specific scenarios. Definition Anomaly detection (AD) (Chandola et al., 2009) aims to detect any anomalous samples that deviate from the predefined normality during testing. The deviation can happen due to either covariate shift or semantic shift, which leads to two sub-tasks: sensory AD and semantic AD, respectively (Ruff et al., 2021).

综上所述，异常检测的关键在于清晰地定义正常情况(通常不包含子类)，并在某些特定场景下检测所有可能的异常样本。定义 异常检测(AD)(Chandola 等人，2009 年)旨在在测试期间检测任何偏离预定义正常情况的异常样本。这种偏离可能是由于协变量偏移或语义偏移导致的，分别对应两个子任务:感官异常检测和语义异常检测(Ruff 等人，2021 年)。

Sensory AD detects test samples with covariate shift, under the assumption that normalities come from the same covariate distribution. No semantic shift takes place in sensory AD settings. On the other hand, semantic AD detects test samples with label shift, assuming that normalities come from the same semantic distribution (category), i.e., normalities should belong to only one class.

感官异常检测在假设正常情况来自同一协变量分布的前提下，检测具有协变量偏移的测试样本。在感官异常检测设置中不会发生语义偏移。另一方面，语义异常检测在假设正常情况来自同一语义分布(类别)的前提下，检测具有标签偏移的测试样本，即正常情况应仅属于一个类别。

Formally, in sensory AD, normalities are from in-distribution $P\left( X\right)$ while anomalies encountered at test time are from out-of-distribution ${P}^{\prime }\left( X\right)$ , where $P\left( X\right)  \neq  {P}^{\prime }\left( X\right)$ -only covariate shift occurs. The goal in sensory AD is to detect samples from ${P}^{\prime }\left( X\right)$ . No semantic shift occurs in this setting, i.e., $P\left( Y\right)  = {P}^{\prime }\left( Y\right)$ . Conversely, for semantic AD, only semantic shift occurs (i.e., $P\left( Y\right)  \neq  {P}^{\prime }\left( Y\right)$ ) and the goal is to detect samples that belong to novel classes.

形式上，在感官异常检测中，正常情况来自分布内 $P\left( X\right)$，而测试时遇到的异常来自分布外 ${P}^{\prime }\left( X\right)$，其中 $P\left( X\right)  \neq  {P}^{\prime }\left( X\right)$ - 仅发生协变量偏移。感官异常检测的目标是检测来自 ${P}^{\prime }\left( X\right)$ 的样本。在这种设置中不会发生语义偏移，即 $P\left( Y\right)  = {P}^{\prime }\left( Y\right)$。相反，对于语义异常检测，仅发生语义偏移(即 $P\left( Y\right)  \neq  {P}^{\prime }\left( Y\right)$)，目标是检测属于新类别的样本。

Remark: Sensory/Semantic Dichotomy Our sensory/semantic dichotomy for the AD sub-task definition comes from the low-level sensory anomalies and high-level semantic anomalies that are introduced in Ahmed and Courville (2020) and highlighted in the recent AD survey (Ruff et al., 2021), to reflect the rise of deep learning. Note that although most sensory and semantic AD methods are shown to be mutually inclusive due to the common shift on $P\left( X\right)$ , some approaches are specialized in one of the sub-tasks (ref. Sect.4.2). Recent research communities are also trending on subdividing types of anomalies to develop targeted methods, so that practitioners can select the optimal solution for their own practical problem (Ahmed & Courville, 2020; Zhang et al., 2021).

备注:感官/语义二分法 我们对异常检测子任务定义的感官/语义二分法源自 Ahmed 和 Courville(2020 年)引入并在近期异常检测综述(Ruff 等人，2021 年)中强调的低级感官异常和高级语义异常，以反映深度学习的兴起。请注意，尽管由于 $P\left( X\right)$ 上的共同偏移，大多数感官和语义异常检测方法显示出相互包容的特性，但一些方法专门针对其中一个子任务(参考第 4.2 节)。近期研究界也倾向于细分异常类型以开发有针对性的方法，以便从业者能够为自己的实际问题选择最优解决方案(Ahmed & Courville，2020 年；Zhang 等人，2021 年)。

Position in Framework Under the generalized OOD detection framework, the definition of "normality" seamlessly connects to the notion of "in-distribution", and "anomaly" corresponds to "out-of-distribution". Importantly, AD treats ID samples as a whole, which means that regardless of the number of classes (or statistical modalities) in ID data, AD does not require differentiation in the ID samples. This feature is an important distinction between AD and other sub-topics such as OSR and OOD detection.

在框架中的位置 在广义的分布外检测框架下，“正常情况”的定义与“分布内”的概念无缝衔接，“异常”对应“分布外”。重要的是，异常检测将分布内样本视为一个整体，这意味着无论分布内数据中的类别(或统计模式)数量如何，异常检测都不需要对分布内样本进行区分。这一特征是异常检测与其他子主题(如开放集识别和分布外检测)的重要区别。

Application and Benchmark Sensory AD only focuses on objects with the same or similar semantics, and identifies the observational differences on their surface. Samples with sensory differences are recognized as sensory anomalies. Example applications include adversarial defense (Akhtar & Mian, 2018), forgery recognition of biometrics and artworks (Patel et al., 2016; Wen et al., 2015; Nixon et al., 2008; Polatkan et al., 2009), image forensics (Dolhansky et al., 2019; Jiang et al., 2021c; Yang et al., 2020c), industrial inspection (Bergmann et al., 2019; Chu & Kitani, 2020; Atha & Jahanshahi, 2018), etc.. The most popular academic AD benchmark is MVTec-AD (Bergmann et al., 2019) for industrial inspection. Beyond academic research, sensory AD has significant potential in various real-world applications, such as detecting counterfeit items in retail and e-commerce and identifying manipulated media in journalism and law enforcement.

应用与基准 感官异常检测仅关注具有相同或相似语义的对象，并识别其表面的观测差异。具有感官差异的样本被识别为感官异常。示例应用包括对抗防御(Akhtar & Mian，2018 年)、生物特征和艺术品的伪造识别(Patel 等人，2016 年；Wen 等人，2015 年；Nixon 等人，2008 年；Polatkan 等人，2009 年)、图像取证(Dolhansky 等人，2019 年；Jiang 等人，2021c；Yang 等人，2020c)、工业检测(Bergmann 等人，2019 年；Chu & Kitani，2020 年；Atha & Jahanshahi，2018 年)等。最流行的学术异常检测基准是用于工业检测的 MVTec - AD(Bergmann 等人，2019 年)。除了学术研究，感官异常检测在各种现实世界应用中具有巨大潜力，例如在零售和电子商务中检测假冒商品，以及在新闻和执法中识别被篡改的媒体。

In contrast to sensory AD, semantic AD only focuses on the semantic shift. An example of real-world applications is crime surveillance (Idrees et al., 2018; Diehl & Hampshire, 2002). Active image crawlers for a specific category also need semantic AD methods to ensure the purity of the collected images (Li & Fei-Fei, 2010). An example of the academic benchmarks is to recursively use one class from MNIST as ID during training, and ask the model to distinguish it from the rest of the 9 classes during testing.

与感官异常检测(sensory AD)不同，语义异常检测(semantic AD)仅关注语义变化。现实应用的一个例子是犯罪监控(Idrees等人，2018年；Diehl和Hampshire，2002年)。针对特定类别的主动图像爬虫也需要语义异常检测方法来确保所收集图像的纯度(Li和Fei - Fei，2010年)。学术基准的一个例子是在训练期间递归地使用MNIST中的一个类别作为已知类别(ID)，并要求模型在测试期间将其与其余9个类别区分开来。

Evaluation In the AD benchmarks, test samples are annotated to be either normal or abnormal. The deployed anomaly detector will produce a confidence score for a test sample, indicating how confident the model considers the sample as normality. Samples below the predefined confidence threshold are considered abnormal. By viewing the anomalies as positive and true normalities as negative, ${}^{1}$ different thresholds will produce a series of true positive rates (TPR) and false-positive rates (FPR)-from which we can calculate the area under the receiver operating characteristic curve (AUROC) (Fawcett, 2006). Similarly, the precision and recall values can be used to compute metrics of F-scores and the area under the precision-recall curve (AUPR) (Powers, 2020). Note that there can be two variants of AUPR values: one treating "normal" as the positive class, and the other treating "abnormal" as the positive class. For AUROC and AUPR, a higher value indicates better detection performance.

评估 在异常检测基准中，测试样本被标注为正常或异常。部署的异常检测器将为测试样本生成一个置信度分数，表明模型认为该样本为正常的置信程度。低于预定义置信阈值的样本被视为异常。将异常视为阳性，真正的正常样本视为阴性，${}^{1}$不同的阈值将产生一系列真阳性率(TPR)和假阳性率(FPR)——由此我们可以计算受试者工作特征曲线下的面积(AUROC)(Fawcett，2006年)。同样，精确率和召回率值可用于计算F分数和精确率 - 召回率曲线下的面积(AUPR)(Powers，2020年)。请注意，AUPR值有两种变体:一种将“正常”视为正类，另一种将“异常”视为正类。对于AUROC和AUPR，值越高表示检测性能越好。

Remark: Alternative Taxonomy on Anomalies Some previous literature considers anomalies types to be three-fold: point anomalies, conditional or contextural anomalies, and group or collective anomalies (Pang et al., 2020; Chalapa-thy & Chawla, 2019; Ruff et al., 2021). In this survey, we mainly focus on point anomalies detection for its popularity in practical applications and its adequacy to elucidate the similarities and differences between sub-tasks. Details of the other two kinds of anomalies, i.e., contextural anomalies that often occur in time-series tasks, and collective anomalies that are common in the data mining field, are not covered in this survey. We recommend readers to the recent AD survey papers (Ruff et al., 2021) for an in-depth discussion on them. Remark: Taxonomy Based on Supervision We use sensory/semantic dichotomy to subdivide AD at the task level. From the perspective of methodologies, some literature categorizes AD techniques into unsupervised and (semi- ) supervised settings. Note that these two taxonomies are orthogonal as they focus on tasks and methods respectively.

备注:异常的另一种分类 一些先前的文献认为异常类型可分为三类:点异常、条件或上下文异常以及组或集体异常(Pang等人，2020年；Chalapathy和Chawla，2019年；Ruff等人，2021年)。在本综述中，我们主要关注点异常检测，因为它在实际应用中很流行，并且足以阐明子任务之间的异同。本综述不涵盖其他两种异常的细节，即经常出现在时间序列任务中的上下文异常和数据挖掘领域常见的集体异常。我们建议读者参考最近的异常检测综述论文(Ruff等人，2021年)以深入讨论这些内容。备注:基于监督的分类 我们使用感官/语义二分法在任务层面细分异常检测。从方法学的角度来看，一些文献将异常检测技术分为无监督和(半)监督设置。请注意，这两种分类是正交的，因为它们分别关注任务和方法。

### 2.2 Novelty Detection

### 2.2 新奇性检测

Background The word "novel" generally refers to the unknown, new, and something interesting. While novelty detection (ND) is often interchangeable with AD in the community, strictly speaking, their subtle difference is worth noticing. In terms of motivation, novelty detection usually does not perceive "novel" test samples as erroneous, fraudulent, or malicious as AD does, but cherishes them as learning resources for potential future use with a positive learning attitude (Pang et al., 2020; Ruff et al., 2021). In fact, novelty detection is also known as "novel class detection" (Markou & Singh, 2003a, b), indicating that it is primarily focusing on detecting semantic shift.

背景 “新奇”一词通常指未知、新颖且有趣的事物。虽然在该领域中，新奇性检测(ND)通常可与异常检测(AD)互换使用，但严格来说，它们之间的细微差异值得注意。在动机方面，新奇性检测通常不会像异常检测那样将“新奇”的测试样本视为错误、欺诈或恶意的，而是以积极的学习态度将它们视为未来潜在用途的学习资源(Pang等人，2020年；Ruff等人，2021年)。实际上，新奇性检测也被称为“新奇类别检测”(Markou和Singh，2003a，b)，这表明它主要侧重于检测语义变化。

Definition Novelty detection aims to detect any test samples that do not fall into any training category. The detected novel samples are usually prepared for future constructive procedures, such as more specialized analysis, or incremental learning of the model itself. Based on the number of training classes, ND contains two different settings: (1) one-class novelty detection (one-class ${ND}$ ): only one class exists in the training set; (2) multi-class novelty detection (multi-class ND): multiple classes exist in the training set. It is worth noting that despite having many ID classes, the goal of multi-class ND is only to distinguish novel samples from ID. Both one-class and multi-class ND are formulated as binary classification problems.

定义 新奇性检测旨在检测任何不属于任何训练类别的测试样本。检测到的新奇样本通常为未来的建设性程序做准备，例如更专业的分析或模型本身的增量学习。根据训练类别的数量，新奇性检测包含两种不同的设置:(1)单类新奇性检测(单类${ND}$):训练集中只有一个类别；(2)多类新奇性检测(多类ND):训练集中存在多个类别。值得注意的是，尽管有多已知类别(ID)，但多类新奇性检测的目标只是将新奇样本与已知类别区分开来。单类和多类新奇性检测都被表述为二分类问题。

Position in Framework Under the generalized OOD detection framework, ND deals with the setting where OOD samples have semantic shift, without the need for classification in the ID set even if possible. Therefore, ND shares the same problem definition with semantic AD.

在框架中的位置 在广义的分布外(OOD)检测框架下，新奇性检测处理的是分布外样本存在语义变化的情况，即使可能也无需对已知类别(ID)集合进行分类。因此，新奇性检测与语义异常检测具有相同的问题定义。

Application and Benchmark Real-world ND application includes video surveillance (Idrees et al., 2018; Diehl & Hampshire, 2002), planetary exploration (Kerner et al., 2019) and incremental learning (Al-Behadili et al., 2015; Pathak et al., 2017). For one-class ND, an example academic benchmark can be identical to that of semantic AD, which considers one class from MNIST as ID and the rest as the novel. The corresponding MNIST benchmark for multi-class ND may use the first 6 classes during training, and test on the remaining 4 classes as OOD. Beyond academic research, ND has significant potential on new drag discovery, new species discovery, etc.

应用与基准测试 现实世界中的新奇检测(ND)应用包括视频监控(伊德里斯等人，2018年；迪尔和汉普郡，2002年)、行星探索(克纳等人，2019年)和增量学习(阿尔 - 贝哈迪利等人，2015年；帕塔克等人，2017年)。对于单类新奇检测，一个学术基准示例可以与语义异常检测(AD)的基准相同，即把MNIST数据集中的一个类别视为已知类别(ID)，其余类别视为新奇类别。多类新奇检测对应的MNIST基准可能在训练时使用前6个类别，并将其余4个类别作为分布外(OOD)数据进行测试。除学术研究外，新奇检测在新药发现、新物种发现等方面具有巨大潜力。

---

${}^{1}$ Align with MSP (Hendrycks & Gimpel,2017) Check https://github.com/Jingkang50/OpenOOD/issues/206this issue in OpenOOD.

${}^{1}$ 与最大软概率(MSP)方法对齐(亨德里克斯和金佩尔，2017年) 查看OpenOOD中的这个问题:https://github.com/Jingkang50/OpenOOD/issues/206。

---

Evaluation The evaluation of ND is identical to AD, which is based on AUROC, AUPR, or F-scores (see details in Sect. 2.1).

评估 新奇检测的评估与异常检测相同，基于受试者工作特征曲线下面积(AUROC)、精确率 - 召回率曲线下面积(AUPR)或F分数(详见2.1节)。

Remark: One-Class/Multi-class Dichotomy Although the ND models do not require the ID classification even with multi-class annotations, the method on multi-class ND can be different from one-class ND, as multi-class ND can make use of the multi-class classifier while one-class ND cannot. Also note that semantic AD can be further split into one-class semantic AD and multi-class semantic AD that matches ND, as semantic AD is equivalent to ND.

备注:单类/多类二分法 尽管新奇检测模型即使有多类标注也不需要进行已知类别分类，但多类新奇检测的方法可能与单类新奇检测不同，因为多类新奇检测可以利用多类分类器，而单类新奇检测则不能。还需注意，由于语义异常检测等同于新奇检测，因此语义异常检测可进一步分为与新奇检测对应的单类语义异常检测和多类语义异常检测。

Remark: Nuance Between AD and ND Apart from the special interest in semantics, some literature (Perera et al., 2019; Xia et al., 2015) also point out that ND is supposed to be fully unsupervised (no novel data in training), while AD might have some abnormal training samples. It's important to note that neither AD nor ND necessitates the classification of ID data. This is a key distinction between OSR and OOD detection, which we will discuss in subsequent sections.

备注:异常检测与新奇检测的细微差别 除了对语义的特殊关注外，一些文献(佩雷拉等人，2019年；夏等人，2015年)还指出，新奇检测应是完全无监督的(训练中没有新奇数据)，而异常检测可能有一些异常训练样本。重要的是要注意，异常检测和新奇检测都不需要对已知类别数据进行分类。这是开放集识别(OSR)和分布外检测的一个关键区别，我们将在后续章节中讨论。

### 2.3 Open Set Recognition

### 2.3 开放集识别

Background Machine learning models trained in the closed-world setting can incorrectly classify test samples from unknown classes as one of the known categories with high confidence (Scheirer et al., 2013). Some literature refers to this notorious overconfident behavior of the model as "arrogance", or "agnostophobia" (Dhamija et al., 2018). Open set recognition (OSR) is proposed to address this problem, with their own terminology of "known known classes" to represent the categories that exist at training, and "unknown unknown classes" for test categories that do not fall into any training category. Some other terms, such as open category detection (Liu et al., 2018a) and open set learning (Fang et al., 2021), are simply different expressions for OSR.

背景 在封闭世界环境下训练的机器学习模型可能会将来自未知类别的测试样本错误地高置信度分类为已知类别之一(谢勒等人，2013年)。一些文献将模型这种臭名昭著的过度自信行为称为“傲慢”或“未知恐惧”(达米贾等人，2018年)。开放集识别(OSR)就是为解决这个问题而提出的，它使用“已知的已知类别”来表示训练时存在的类别，用“未知的未知类别”来表示不属于任何训练类别的测试类别。其他一些术语，如开放类别检测(刘等人，2018a)和开放集学习(方等人，2021年)，只是开放集识别的不同表述。

Definition Open set recognition requires the multi-class classifier to simultaneously: (1) accurately classify test samples from "known known classes", and (2) detect test samples from "unknown unknown classes".

定义 开放集识别要求多类分类器同时做到:(1)准确分类来自“已知的已知类别”的测试样本；(2)检测来自“未知的未知类别”的测试样本。

Position in Framework OSR well aligns with our generalized OOD detection framework, where "known known classes" and "unknown unknown classes" correspond to ID and OOD respectively. Formally, OSR deals with the case where OOD samples during testing have semantic shift, i.e., $P\left( Y\right)  \neq  {P}^{\prime }\left( Y\right)$ . The goal of OSR is largely shared with that of multi-class ND-the only difference is that OSR additionally requires accurate classification of ID samples from $P\left( Y\right)$ .

在框架中的位置 开放集识别与我们的广义分布外检测框架高度契合，其中“已知的已知类别”和“未知的未知类别”分别对应已知类别(ID)和分布外(OOD)。形式上，开放集识别处理的是测试时分布外样本存在语义偏移的情况，即 $P\left( Y\right)  \neq  {P}^{\prime }\left( Y\right)$ 。开放集识别的目标与多类新奇检测基本相同，唯一的区别是开放集识别还要求准确分类来自 $P\left( Y\right)$ 的已知类别样本。

Application and Benchmark OSR supports the robust deployment of real-world image classifiers in general, which can reject unknown samples in the open world (Sorio et al., 2010; Xu et al., 2019). An example academic benchmark on MNIST can be identical to multi-class ND, which considers the first 6 classes as ID and the remaining 4 classes as OOD. In addition, OSR further requires a good classifier on the 6 ID classes.

应用与基准测试 一般来说，开放集识别支持现实世界图像分类器的稳健部署，它可以拒绝开放世界中的未知样本(索里奥等人，2010年；徐等人，2019年)。MNIST数据集上的一个学术基准示例可以与多类新奇检测相同，即把前6个类别视为已知类别，其余4个类别视为分布外数据。此外，开放集识别还要求对这6个已知类别有一个良好的分类器。

Evaluation Similar to AD and ND, the metrics for OSR include F-scores, AUROC, and AUPR. Beyond them, the classification performance is also evaluated by standard ID accuracy. While the above metrics evaluate the novelty detection and ID classification capabilities independently, some works raise some evaluation criteria for joint evaluation, such as CCR@FPR $x$ (Dhamija et al.,2018), which calculates the class-wise recall when a certain FPR equal to $x\left( {\text{e.g.,}{10}^{-1}}\right)$ is achieved.

评估 与异常检测和新奇检测类似，开放集识别的评估指标包括F分数、受试者工作特征曲线下面积(AUROC)和精确率 - 召回率曲线下面积(AUPR)。除此之外，还通过标准的已知类别准确率来评估分类性能。虽然上述指标分别评估新奇检测和已知类别分类能力，但一些研究提出了一些联合评估的标准，如误报率(FPR)为 $x\left( {\text{e.g.,}{10}^{-1}}\right)$ 时的类别召回率(CCR@FPR $x$ )(达米贾等人，2018年)。

### 2.4 Out-of-Distribution Detection

### 2.4 分布外检测

Background With the observation that deep learning models are often inappropriate but in fact overconfident in classifying samples from different semantic distributions in the image classification task and text categorization (Hendrycks & Gimpel, 2017), the field of out-of-distribution detection emerges, requiring the model to reject inputs that are semantically different from the training distribution and therefore should not be predicted by the model.

背景 有观察表明，在图像分类任务和文本分类中，深度学习模型在对来自不同语义分布的样本进行分类时，往往表现不佳却过度自信(Hendrycks & Gimpel，2017)，由此催生了分布外检测(Out-of-distribution detection)领域，该领域要求模型拒绝那些语义与训练分布不同、因而不应由模型进行预测的输入。

Definition Out-of-distribution detection, or OOD detection, aims to detect test samples drawn from a distribution that is different from the training distribution, with the definition of distribution to be well-defined according to the application in the target. For most machine learning tasks, the distribution should refer to "label distribution", which means that OOD samples should not have overlapping labels w.r.t.training data. Formally, in the OOD detection, the test samples come from a distribution whose semantics are shifted from ID, i.e., $P\left( Y\right)  \neq  {P}^{\prime }\left( Y\right)$ . Note that the training set usually contains multiple classes, and OOD detection should NOT harm the ID classification capability.

定义 分布外检测(Out-of-distribution detection，简称OOD检测)旨在检测来自与训练分布不同的分布的测试样本，分布的定义应根据目标应用进行明确界定。对于大多数机器学习任务而言，分布应指“标签分布”，这意味着分布外(OOD)样本的标签不应与训练数据的标签有重叠。形式上，在分布外检测中，测试样本来自语义与分布内(ID)不同的分布，即 $P\left( Y\right)  \neq  {P}^{\prime }\left( Y\right)$ 。请注意，训练集通常包含多个类别，且分布外检测不应损害分布内(ID)分类能力。

Position in Framework Out-of-distribution detection can be canonical to OSR in common machine learning tasks like multi-class classification-keeping the classification performance on test samples from ID class space $\mathcal{Y}$ , and reject OOD test samples with semantics outside the support of $\mathcal{Y}$ . Also, the multi-class setting and the requirement of ID classification distinguish the task from AD and ND.

在框架中的位置 在多类分类等常见机器学习任务中，分布外检测与开放集识别(OSR)具有相似性——保持对来自分布内(ID)类别空间 $\mathcal{Y}$ 的测试样本的分类性能，并拒绝语义在 $\mathcal{Y}$ 支持范围之外的分布外(OOD)测试样本。此外，多类设置和分布内(ID)分类要求使该任务有别于异常检测(AD)和新奇性检测(ND)。

Application and Benchmark The application of OOD detection usually falls into safety-critical situations, such as autonomous driving (Huang et al., 2020b; Geiger et al., 2012). In the context of self-driving vehicles, OOD detection (also OSR) plays a crucial role in identifying novel or unexpected objects and scenarios, allowing the system to take appropriate actions to ensure the safety of passengers and pedestrians. Other potential real-world applications include medical diagnosis, where OOD detection can help flag unusual patient cases that may require further attention from healthcare professionals, and industrial monitoring, where it can identify anomalies in sensor data that could indicate potential equipment failures or safety hazards. An example academic benchmark is to use CIFAR-10 as ID during training and to distinguish CIFAR images from other datasets such as SVHN, etc.. Researchers should pay attention that OOD datasets should NOT have label overlapping with ID datasets when building the benchmark.

应用与基准 分布外检测的应用通常出现在对安全要求极高的场景中，例如自动驾驶(Huang等人，2020b；Geiger等人，2012)。在自动驾驶车辆的背景下，分布外检测(也即开放集识别)在识别新的或意外的物体和场景方面起着至关重要的作用，使系统能够采取适当的行动，以确保乘客和行人的安全。其他潜在的实际应用包括医学诊断，在医学诊断中，分布外检测可以帮助标记出可能需要医疗专业人员进一步关注的异常患者病例；以及工业监测，在工业监测中，它可以识别传感器数据中的异常，这些异常可能预示着潜在的设备故障或安全隐患。一个学术基准示例是在训练时使用CIFAR - 10作为分布内(ID)数据集，并将CIFAR图像与其他数据集(如SVHN等)区分开来。研究人员在构建基准时应注意，分布外(OOD)数据集的标签不应与分布内(ID)数据集的标签有重叠。

Evaluation Apart from F-scores, AUROC, and AUPR, another commonly-used metric is FPR@TPR $x$ , which measures the FPR when the TPR is $x$ (e.g.,0.95). Some works also use an alternative metric, TNR@TPR $x$ , which is equivalent to 1-FPR@TPR $x$ . OOD detection also concerns the performance of ID classification.

评估 除了F分数、受试者工作特征曲线下面积(AUROC)和精确率 - 召回率曲线下面积(AUPR)之外，另一个常用的指标是真阳性率(TPR)为 $x$ 时的假阳性率(FPR)，即FPR@TPR $x$ (例如，当TPR为0.95时)。一些研究还使用另一个替代指标，即真阴性率(TNR)在TPR为 $x$ 时的值，即TNR@TPR $x$ ，它等同于1 - FPR@TPR $x$ 。分布外检测还涉及分布内(ID)分类的性能。

Remark: OSR vs OOD Detection The difference between OSR and OOD detection tasks is three-fold.

备注:开放集识别(OSR)与分布外检测的区别 开放集识别(OSR)和分布外检测任务的区别体现在三个方面。

(1) Different Benchmark Setup OSR benchmarks usually split one multi-class classification dataset into ID and OOD parts according to classes, while OOD detection takes one dataset as ID and finds several other datasets as OOD with the guarantee of non-overlapping categories between ID/OOD datasets. However, despite the different benchmark traditions of the two sub-tasks, they are in fact tackling the same problem of semantic shift detection.

(1)不同的基准设置 开放集识别(OSR)基准通常根据类别将一个多类分类数据集划分为分布内(ID)和分布外(OOD)两部分，而分布外检测则将一个数据集作为分布内(ID)数据集，并找到其他几个数据集作为分布外(OOD)数据集，同时保证分布内/分布外数据集之间的类别不重叠。然而，尽管这两个子任务的基准传统不同，但它们实际上解决的是同一个语义偏移检测问题。

(2) No Additional data in OSR Due to the requirement of theoretical open-risk bound guarantee, OSR discourages the usage of additional data during training by design (Boult et al., 2019). This restriction precludes methods that are more focused on effective performance improvements (e.g., outlier exposures (Hendrycks et al., 2019b; Zhang et al., 2023b)) but may violate OSR constraints.

(2)开放集识别(OSR)不使用额外数据 由于需要保证理论上的开放风险边界，开放集识别(OSR)在设计上不鼓励在训练过程中使用额外数据(Boult等人，2019)。这一限制排除了那些更注重有效提高性能(例如，异常暴露(Hendrycks等人，2019b；Zhang等人，2023b))但可能违反开放集识别(OSR)约束的方法。

(3) Broadness of OOD Detection Compare to OSR, OOD detection encompasses a broader spectrum of learning tasks (e.g., multi-label classification (Hendrycks et al., 2022a)), wider solution space (to be discussed in Sect. 3).

(3)分布外检测的广泛性 与开放集识别(OSR)相比，分布外检测涵盖了更广泛的学习任务(例如，多标签分类(Hendrycks等人，2022a))和更广泛的解决方案空间(将在第3节讨论)。

Remark: Mainstream OOD Detection Focuses on Semantics While most works in the current community interpret the keyword "out-of-distribution" as "out-of-label/semantic-distribution", some OOD detection works also consider detecting covariate shifts (Hsu et al., 2020), which claim that covariate shift usually leads to a significant drop in model performance and therefore needs to be identified and rejected. However, although detecting covariate shift is reasonable on some specific tasks (usually due to high-risk or privacy reasons) that are to be discussed in the following paragraph, research on this topic remains a controversial task w.r.t OOD generalization tasks (c.f.Sects. 2.6 and 6.2). Detecting semantic shift has been the mainstream of OOD detection tasks.

备注:主流的分布外(OOD)检测聚焦于语义 虽然当前学界的大多数研究将“分布外”这一关键词解读为“标签/语义分布外”，但也有一些OOD检测研究考虑检测协变量偏移(Hsu等人，2020)，这些研究认为协变量偏移通常会导致模型性能显著下降，因此需要识别并排除。然而，尽管检测协变量偏移在一些特定任务(通常出于高风险或隐私原因)中是合理的(将在下一段讨论)，但在OOD泛化任务方面，关于这一主题的研究仍然是一个有争议的任务(参见第2.6节和第6.2节)。检测语义偏移一直是OOD检测任务的主流。

Remark: To Generalize, or To Detect? We provide another definition from the perspective of generalization: Out-of-distribution detection, or OOD detection, aims to detect test samples to which the model cannot or does not want to generalize (Pleiss et al., 2019). In most of the machine learning tasks, such as image classification, the models are expected to generalize their prediction capability to samples with covariate shift, and they are only unable to generalize when semantic shift occurs. However, for applications where models are by-design nontransferable to other domain, such as many deep reinforcement learning tasks like game AI (Vinyals et al., 2017; Sedlmeier et al., 2019), the key term "distribution" should refer to "data/input distribution", so that the model should refuse to decide the environment that is not the same as the training environment, i.e., $P\left( X\right)  \neq  {P}^{\prime }\left( X\right)$ . Similar applications are those high-risk tasks such as medical image classification (Zim-merer et al., 2022) or in privacy-sensitive scenario (Tariq et al., 2020), where the models are expected to be very conservative and only make predictions for samples exactly from the training distribution, rejecting any samples that deviate from it. Recent studies (Averly & Chao, 2023) also highlight a model-specific view: a robust model should generalize to examples with covariate shift; a weak model should reject them. Ultimately, an OOD detection task is considered valid when it successfully balances the aspects of "detection" and "generalization", taking into account factors such as meaningfulness and the inherent challenges presented by the task. Nonetheless, detecting semantic shift remains the primary focus of OOD detection tasks and is central to this survey.

备注:是泛化还是检测？ 我们从泛化的角度给出另一个定义:分布外检测(OOD检测)旨在检测模型无法或不想泛化的测试样本(Pleiss等人，2019)。在大多数机器学习任务中，如图像分类，模型期望将其预测能力泛化到存在协变量偏移的样本上，只有当发生语义偏移时，模型才无法泛化。然而，对于那些设计上不能迁移到其他领域的应用，如许多深度强化学习任务(如游戏AI)(Vinyals等人，2017；Sedlmeier等人，2019)，关键术语“分布”应指“数据/输入分布”，这样模型应该拒绝判断与训练环境不同的环境，即$P\left( X\right)  \neq  {P}^{\prime }\left( X\right)$。类似的应用还包括医疗图像分类(Zimmerer等人，2022)等高风险任务或隐私敏感场景(Tariq等人，2020)，在这些场景中，模型期望非常保守，只对与训练分布完全相同的样本进行预测，拒绝任何偏离该分布的样本。最近的研究(Averly & Chao，2023)还强调了一种特定于模型的观点:一个鲁棒的模型应该能够泛化到存在协变量偏移的样本；而一个较弱的模型应该拒绝这些样本。最终，当OOD检测任务成功平衡了“检测”和“泛化”两个方面，并考虑到任务的意义和内在挑战等因素时，该任务才被认为是有效的。尽管如此，检测语义偏移仍然是OOD检测任务的主要焦点，也是本综述的核心内容。

### 2.5 Outlier Detection

### 2.5 离群点检测

Background According to Wikipedia (Wikipedia contributors, 2021), an outlier is a data point that differs significantly from other observations. Recall that the problem settings in AD, ND, OSR, and OOD detect unseen test samples that are different from the training data distribution. In contrast, outlier detection directly processes all observations and aims to select outliers from the contaminated dataset (Ben-Gal, 2005; Hodge & Austin, 2004; Aggarwal & Yu, 2001). Since outlier detection does not follow the train-test procedure but has access to all observations, approaches to this problem are usually transductive rather than inductive (Bianchini et al., 2016).

背景 根据维基百科(维基百科贡献者，2021)的定义，离群点是与其他观测值有显著差异的数据点。回顾一下，异常检测(AD)、新奇检测(ND)、开放集识别(OSR)和分布外检测(OOD)的问题设定是检测与训练数据分布不同的未见测试样本。相比之下，离群点检测直接处理所有观测值，旨在从受污染的数据集中选择离群点(Ben - Gal，2005；Hodge & Austin，2004；Aggarwal & Yu，2001)。由于离群点检测不遵循训练 - 测试流程，而是可以访问所有观测值，因此解决该问题的方法通常是直推式的，而非归纳式的(Bianchini等人，2016)。

Definition Outlier detection aims to detect samples that are markedly different from the others in the given observation set, due to either covariate or semantic shift.

定义 离群点检测旨在检测给定观测集中由于协变量偏移或语义偏移而与其他样本明显不同的样本。

Position in Framework Different from all previous subtasks, whose in-distribution is defined during training, the "in-distribution" for outlier detection refers to the majority of the observations. Outliers may exist due to semantic shift on $P\left( Y\right)$ , or covariate shift on $P\left( X\right)$ .

在框架中的位置 与之前的所有子任务不同，之前子任务的分布内是在训练期间定义的，而离群点检测的“分布内”是指大多数观测值。离群点可能由于$P\left( Y\right)$上的语义偏移或$P\left( X\right)$上的协变量偏移而存在。

Application and Benchmark While mostly applied in data mining tasks (Ben-Gal, 2005; Basu & Meckesheimer, 2007; Dou et al., 2019), outlier detection is also used in real-world computer vision applications such as video surveillance (Xiao et al., 2015) and dataset cleaning (Liu et al., 2004; Loureiro et al., 2004; Van den Broeck et al., 2005). For the application of dataset cleaning, outlier detection is usually used as a pre-processing step for the main tasks such as learning from open-set noisy labels (Wang et al., 2018), webly supervised learning (Chen & Gupta, 2015), and open-set semi-supervised learning (Cao et al., 2021). To construct an outlier detection benchmark on MNIST, one class should be chosen so that all samples that belong to this class are considered as inliers. A small fraction of samples from other classes are introduced as outliers to be detected.

应用与基准 离群点检测主要应用于数据挖掘任务(Ben - Gal，2005；Basu & Meckesheimer，2007；Dou等人，2019)，也用于现实世界的计算机视觉应用，如视频监控(Xiao等人，2015)和数据集清理(Liu等人，2004；Loureiro等人，2004；Van den Broeck等人，2005)。在数据集清理应用中，离群点检测通常作为主要任务的预处理步骤，如从开放集噪声标签中学习(Wang等人，2018)、弱监督学习(Chen & Gupta，2015)和开放集半监督学习(Cao等人，2021)。为了在MNIST数据集上构建离群点检测基准，应选择一个类别，将属于该类别的所有样本视为内点。引入其他类别的一小部分样本作为待检测的离群点。

Evaluation Apart from F-scores, AUROC, and AUPR, the evaluation of outlier detectors can be also evaluated by the performance of the main task it supports. For example, if an outlier detector is used to purify a dataset with noisy labels, the performance of a classifier that is trained on the cleaned dataset can indicate the quality of the outlier detector.

评估 除了F值、受试者工作特征曲线下面积(AUROC)和精确率-召回率曲线下面积(AUPR)之外，异常值检测器的评估还可以通过其支持的主要任务的性能来进行。例如，如果使用异常值检测器来净化带有噪声标签的数据集，那么在清理后的数据集上训练的分类器的性能可以表明异常值检测器的质量。

Remark: On Inclusion of Outlier Detection Interestingly, the outlier detection task can be considered as an outlier in the generalized OOD detection framework, since outlier detectors are operated on the scenario when all observations are given, rather than following the training-test scheme. Also, publications exactly on this topic are rarely seen in the recent deep learning venues. However, we still include outlier detection in our framework, because intuitively speaking, outliers also belong to one type of out-of-distribution, and introducing it can help familiarize readers more with various terms (e.g., OD, AD, ND, OOD) that have confused the community for a long while.

备注:关于纳入异常值检测 有趣的是，异常值检测任务可以被视为广义分布外(OOD)检测框架中的一个特例，因为异常值检测器是在所有观测值都已知的场景下运行的，而不是遵循训练 - 测试方案。此外，在最近的深度学习会议中，很少看到专门针对这一主题的出版物。然而，我们仍然将异常值检测纳入我们的框架，因为直观地说，异常值也属于分布外的一种类型，引入它可以帮助读者更熟悉各种让该领域困惑已久的术语(例如，异常检测(OD)、异常值检测(AD)、新奇性检测(ND)、分布外检测(OOD))。

### 2.6 Related Topics

### 2.6 相关主题

Apart from the five sub-topics that are described in our generalized OOD detection framework (shown in Fig. 1), we further briefly discuss five related topics below, which help clarify the scope of this survey.

除了我们广义分布外检测框架中描述的五个子主题(如图1所示)，我们下面进一步简要讨论五个相关主题，这有助于明确本综述的范围。

Learning with Rejection (LWR) LWR (Bartlett & Wegkamp, 2008) can date back to early works on abstention (Chow, 1970; Fumera & Roli, 2002), which considered simple model families such as SVMs (Cortes & Vapnik, 1995). The phenomenon of neural networks' overconfidence in OOD data is first revealed by Nguyen et al. (2015). Despite methodologies differences, subsequent works developed on OOD detection and OSR share the underlying spirit of classification with the rejection option.

带拒绝选项的学习(LWR) 带拒绝选项的学习(Bartlett & Wegkamp，2008)可以追溯到早期关于弃权的研究(Chow，1970；Fumera & Roli，2002)，这些研究考虑了诸如支持向量机(SVMs)(Cortes & Vapnik，1995)等简单的模型族。Nguyen等人(2015)首次揭示了神经网络在分布外数据上过度自信的现象。尽管方法有所不同，但后续在分布外检测和开放集识别(OSR)方面的研究都与带拒绝选项的分类有着相同的内在精神。

Domain Adaptation/Generalization Domain Adaptation (DA) (Wang & Deng, 2018) and Domain Generalization (DG) (Zhou et al., 2021b) also follow "open-world" assumption. Different from generalized OOD detection settings, DA/DG expects the existence of covariate shift during testing without any semantic shift and requires classifiers to make accurate predictions into the same set of classes (Liu et al., 2020c). Noticing that OOD detection commonly concerns detecting the semantic shift, which is complementary to DA/DG. In the case when both covariate and semantic shift take place, the model should be able to detect semantic shift while being robust to covariate shift. More discussion on relations between DA/DG and OOD detection is in Sect. 6.2. The difference between DA and DG is that while the former requires extra but few training samples from the target domain, the latter does not.

领域自适应/泛化 领域自适应(DA)(Wang & Deng，2018)和领域泛化(DG)(Zhou等人，2021b)也遵循“开放世界”假设。与广义分布外检测设置不同，领域自适应/泛化期望在测试期间存在协变量偏移而没有任何语义偏移，并要求分类器对同一组类别进行准确预测(Liu等人，2020c)。值得注意的是，分布外检测通常关注检测语义偏移，这与领域自适应/泛化是互补的。当协变量和语义偏移同时发生时，模型应该能够检测到语义偏移，同时对协变量偏移具有鲁棒性。关于领域自适应/泛化与分布外检测之间关系的更多讨论见第6.2节。领域自适应和领域泛化的区别在于，前者需要来自目标领域的额外但少量的训练样本，而后者则不需要。

Novelty Discovery Novelty discovery (Han et al., 2019; Zhao & Han, 2021; Jia et al., 2021; Vaze et al., 2022a; Joseph et al., 2022) requires all observations to be given in advance as outlier detection does. The observations are provided in a semi-supervised manner, and the goal is to explore and discover the new categories and classes in the unlabeled set. Different from outlier detection where outliers are sparse, the unlabeled set in novelty discovery setting can mostly consist of, and even be overwhelmed by unknown classes.

新奇性发现 新奇性发现(Han等人，2019；Zhao & Han，2021；Jia等人，2021；Vaze等人，2022a；Joseph等人，2022)和异常值检测一样，要求提前给出所有观测值。观测值以半监督的方式提供，目标是探索和发现未标记集中的新类别。与异常值检测中异常值稀疏不同，新奇性发现设置中的未标记集大多可能由未知类别组成，甚至可能被未知类别主导。

Zero-Shot Learning Zero-shot learning (Wang et al., 2019b) has a similar goal of novelty discovery but follows the training-testing scheme. The test set is under the "open-world" assumption with unknown classes, which expects classifiers trained only on the known classes to perform classification on unknown testing samples with the help of extra information such as label relationships.

零样本学习 零样本学习(Wang等人，2019b)与新奇性发现有相似的目标，但遵循训练 - 测试方案。测试集遵循“开放世界”假设，包含未知类别，这期望仅在已知类别上训练的分类器借助额外信息(如标签关系)对未知测试样本进行分类。

Open-World Recognition Open-world recognition (Ben-dale & Boult, 2015) aims to build a lifelong learning machine that can actively detect novel images (Liu et al., 2019), label them as new classes, and perform continuous learning. It can be viewed as a combination of novelty detection (or open-set recognition) and incremental learning. More specifically, open-world recognition extends the concept of OSR by adding the ability to incrementally learn new classes over time. In open-world scenarios, the system not only identifies unknown instances but also can update its model to include these new classes as part of the known set. This approach is more dynamic and suited for real-world applications where the environment is not static, and new categories can emerge after the initial training phase (Parmar et al., 2023).

开放世界识别 开放世界识别(Ben - dale & Boult，2015)旨在构建一个终身学习机器，该机器可以主动检测新奇图像(Liu等人，2019)，将它们标记为新类别，并进行持续学习。它可以被视为新奇性检测(或开放集识别)和增量学习的结合。更具体地说，开放世界识别通过增加随时间增量学习新类别的能力扩展了开放集识别的概念。在开放世界场景中，系统不仅能识别未知实例，还能更新其模型，将这些新类别纳入已知类别集合。这种方法更具动态性，适用于环境不是静态的、在初始训练阶段后可能出现新类别的现实应用(Parmar等人，2023)。

Conformal Prediction Conformal prediction (CP) stands as a robust statistical framework in machine learning, primarily designed to provide confidence measures for predictions (Shafer & Vovk, 2008; Angelopoulos & Bates, 2021). Distinctively, it yields prediction intervals with specified confidence levels, transcending the limitations of mere point estimates. In scenarios of OOD detection, the conformal prediction framework becomes particularly insightful: wider prediction intervals or lower confidence levels generated by conformal prediction methods can serve as indicators of such OOD data. Although research at the intersection of CP and OOD detection is still emerging (Kaur et al., 2022a, b; Cai et al., 2021), the potential of applying the conformal prediction framework in this domain is significant and warrants further exploration (Table 1; Fig. 3).

共形预测 共形预测(Conformal Prediction，CP)是机器学习中一个强大的统计框架，主要用于为预测提供置信度度量(Shafer & Vovk，2008；Angelopoulos & Bates，2021)。其独特之处在于，它能生成具有指定置信水平的预测区间，超越了单纯点估计的局限性。在分布外(Out-of-Distribution，OOD)检测场景中，共形预测框架尤其具有启发性:共形预测方法生成的更宽预测区间或更低置信水平可作为此类OOD数据的指标。尽管CP与OOD检测交叉领域的研究仍处于起步阶段(Kaur等人，2022a，b；Cai等人，2021)，但在该领域应用共形预测框架的潜力巨大，值得进一步探索(表1；图3)。

Table 1 Paper list for out-of-distribution detection

表1 分布外检测相关论文列表

<table><tr><td>Sections</td><td>References</td></tr><tr><td colspan="2">Section 3.1 Classification</td></tr><tr><td colspan="2">Section 3.1.1 Output-based Methods</td></tr><tr><td>a: Training-free</td><td>Hendrycks and Gimpel (2017), Liang et al. (2018), Lee et al. (2018b), Liu et al. (2020), Sastry and Oore (2020), Wang et al. (2021), Zhang et al. (2023a), Sun et al. (2021b), Dong et al. (2022), Sun and Li (2022), Sun et al. (2022), Lin et al. (2021), Sastry and Oore (2019), Zhang et al. (2023a), Djurisic et al. (2023), Park et al. (2023b), Park et al. (2023a), Jiang et al. (2023b), Liu et al. (2023)</td></tr><tr><td>b: Training-based</td><td>DeVries and Taylor (2018), Wang et al. (2021, 2022b), Vyas et al. (2018), Bitterwolf et al. (2020), Chen et al. (2020b), Hein et al. (2019), Choi and Chung (2020), Chen et al. (2021c), Hein et al. (2019), Thulasidasan et al. (2019), Yun et al. (2019), DeVries and Taylor (2017), Hendrycks et al. (2019c, 2022c), Tack et al. (2020), Meinke and Hein (2019), Bibas et al. (2021), Lin et al. (2021), Dong et al. (2022), Hsu et al. (2020), Wei et al. (2022), Lee et al. (2018c), Huang and Li (2021), Linderman et al. (2023), Shalev et al. (2018), Fort et al. (2021), Gan (2021)</td></tr><tr><td colspan="2">Section 3.1.2 Outlier Exposure</td></tr><tr><td>a: Real Outliers</td><td>Hendrycks et al. (2019b), Dhamija et al. (2018), Yu and Aizawa (2019), Mohseni et al. (2020), Chen et al. (2021c), Thulasidasan et al. (2021), Papadopoulos et al. (2021), Chen et al. (2021c), Ming et al. (2022b), Li and Vasconcelos (2020), Zhang et al. (2023b), Yang et al. (2021), Lu et al. (2023), Shafaei et al. (2019), Katz-Samuels et al. (2022), Wang et al. (2023b)</td></tr><tr><td>b: Data Generation</td><td>Lee et al. (2018a), Vernekar et al. (2019), Sricharan et al. (2018), Jeong and Kim (2020), Du et al. (2022b), Tao et al. (2023), Wang et al. (2023c), Zheng et al. (2023), Du et al. (2022a)</td></tr><tr><td>Section 3.1.3: Gradient-based Methods</td><td>Liang et al. (2018), Huang et al. (2021), Igoe et al. (2022)</td></tr><tr><td>Section 3.1.4: Bayesian Models</td><td>Gal and Ghahramani (2016), Lakshminarayanan et al. (2017), Osawa et al. (2019), Malinin and Gales (2018, 2019), Nandy et al. (2020), Kim et al. (2021)</td></tr><tr><td>Section 3.1.5: OOD for Foundation Models</td><td>Hendrycks et al. (2019a, 2020), Fort et al. (2021), Ming and Li (2023), Miyai et al. (2023a, b), Lu et al. (2023), Esmaeilpour et al. (2022), Ming et al. (2022a), Wang et al. (2023a)</td></tr><tr><td>Section 3.2: Density-based Methods</td><td>Zong et al. (2018), Abati et al. (2019), Pidhorskyi et al. (2018), Deecke et al. (2018), Sabokrou et al. (2018), Lee et al. (2018b), Kobyzev et al. (2020), Zisselman and Tamar (2020), Kingma and Dhariwal (2018), Van Oord et al. (2016), Jiang et al. (2021a), Nalis- nick et al. (2018), Choi et al. (2018), Kirichenko et al. (2020), Ren et al. (2019), Serrà et al. (2020), Xiao et al. (2020), Wang et al. (2022a)</td></tr><tr><td>Section 3.3: Distance-based Methods</td><td>Lee et al. (2018b), Ren et al. (2021), Techapanurak et al. (2020), Chen et al. (2020c), Zaeemzadeh et al. (2021), Van Amersfoort et al. (2020), Huang et al. (2020a), Sun et al. (2022), Ming et al. (2023), Kim et al. (2023)</td></tr><tr><td>Section 3.4: Reconstruction-based Methods</td><td>Denouden et al. (2018), Zhou (2022), Yang et al. (2022c), Jiang et al. (2023a), Li et al. (2023b)</td></tr><tr><td>Section 3.5: Theoretical Analysis</td><td>Zhang et al. (2021), Morteza and Li (2022), Scheirer et al. (2013), Jain et al. (2014), Rudd et al. (2017), Liu et al. (2018a), Fang et al. (2021, 2022)</td></tr></table>

<table><tbody><tr><td>章节</td><td>参考文献</td></tr><tr><td colspan="2">3.1节 分类</td></tr><tr><td colspan="2">3.1.1节 基于输出的方法</td></tr><tr><td>a: 免训练</td><td>亨德里克斯和金佩尔(Hendrycks and Gimpel，2017年)、梁等人(Liang et al.，2018年)、李等人(Lee et al.，2018b年)、刘等人(Liu et al.，2020年)、萨斯特里和奥雷(Sastry and Oore，2020年)、王等人(Wang et al.，2021年)、张等人(Zhang et al.，2023a年)、孙等人(Sun et al.，2021b年)、董等人(Dong et al.，2022年)、孙和李(Sun and Li，2022年)、孙等人(Sun et al.，2022年)、林等人(Lin et al.，2021年)、萨斯特里和奥雷(Sastry and Oore，2019年)、张等人(Zhang et al.，2023a年)、久里西奇等人(Djurisic et al.，2023年)、朴等人(Park et al.，2023b年)、朴等人(Park et al.，2023a年)、江等人(Jiang et al.，2023b年)、刘等人(Liu et al.，2023年)</td></tr><tr><td>b: 基于训练</td><td>德弗里斯和泰勒(DeVries and Taylor，2018年)、王等人(Wang et al.，2021年、2022b年)、维亚斯等人(Vyas et al.，2018年)、比特沃尔夫等人(Bitterwolf et al.，2020年)、陈等人(Chen et al.，2020b年)、海因等人(Hein et al.，2019年)、崔和钟(Choi and Chung，2020年)、陈等人(Chen et al.，2021c年)、海因等人(Hein et al.，2019年)、图拉萨迪桑等人(Thulasidasan et al.，2019年)、尹等人(Yun et al.，2019年)、德弗里斯和泰勒(DeVries and Taylor，2017年)、亨德里克斯等人(Hendrycks et al.，2019c年、2022c年)、塔克等人(Tack et al.，2020年)、迈因克和海因(Meinke and Hein，2019年)、比巴斯等人(Bibas et al.，2021年)、林等人(Lin et al.，2021年)、董等人(Dong et al.，2022年)、许等人(Hsu et al.，2020年)、魏等人(Wei et al.，2022年)、李等人(Lee et al.，2018c年)、黄和李(Huang and Li，2021年)、林德曼等人(Linderman et al.，2023年)、沙莱夫等人(Shalev et al.，2018年)、福特等人(Fort et al.，2021年)、甘(Gan，2021年)</td></tr><tr><td colspan="2">3.1.2节 异常值暴露</td></tr><tr><td>a: 真实异常值</td><td>亨德里克斯等人(Hendrycks et al.，2019b年)、达米贾等人(Dhamija et al.，2018年)、余和相泽(Yu and Aizawa，2019年)、莫赫森尼等人(Mohseni et al.，2020年)、陈等人(Chen et al.，2021c年)、图拉萨迪桑等人(Thulasidasan et al.，2021年)、帕帕多普洛斯等人(Papadopoulos et al.，2021年)、陈等人(Chen et al.，2021c年)、明等人(Ming et al.，2022b年)、李和瓦斯康塞洛斯(Li and Vasconcelos，2020年)、张等人(Zhang et al.，2023b年)、杨等人(Yang et al.，2021年)、陆等人(Lu et al.，2023年)、沙法伊等人(Shafaei et al.，2019年)、卡茨 - 塞缪尔斯等人(Katz - Samuels et al.，2022年)、王等人(Wang et al.，2023b年)</td></tr><tr><td>b: 数据生成</td><td>李等人(Lee et al.，2018a年)、韦尔内卡尔等人(Vernekar et al.，2019年)、斯里查兰等人(Sricharan et al.，2018年)、郑和平和金(Jeong and Kim，2020年)、杜等人(Du et al.，2022b年)、陶等人(Tao et al.，2023年)、王等人(Wang et al.，2023c年)、郑等人(Zheng et al.，2023年)、杜等人(Du et al.，2022a年)</td></tr><tr><td>3.1.3节:基于梯度的方法</td><td>梁等人(Liang et al.，2018年)、黄等人(Huang et al.，2021年)、伊戈等人(Igoe et al.，2022年)</td></tr><tr><td>3.1.4节:贝叶斯模型</td><td>加尔和加哈拉马尼(Gal and Ghahramani，2016年)、拉克什米纳拉亚南等人(Lakshminarayanan et al.，2017年)、大泽等人(Osawa et al.，2019年)、马利宁和盖尔斯(Malinin and Gales，2018年、2019年)、南迪等人(Nandy et al.，2020年)、金等人(Kim et al.，2021年)</td></tr><tr><td>3.1.5节:基础模型的分布外检测</td><td>亨德里克斯等人(Hendrycks et al.，2019a年、2020年)、福特等人(Fort et al.，2021年)、明和李(Ming and Li，2023年)、宫井等人(Miyai et al.，2023a年、b年)、陆等人(Lu et al.，2023年)、埃斯迈尔普尔等人(Esmaeilpour et al.，2022年)、明等人(Ming et al.，2022a年)、王等人(Wang et al.，2023a年)</td></tr><tr><td>3.2节:基于密度的方法</td><td>宗等人(2018年)、阿巴蒂等人(2019年)、皮德霍尔斯基等人(2018年)、迪克等人(2018年)、萨博克罗等人(2018年)、李等人(2018b)、科比泽夫等人(2020年)、齐塞尔曼和塔马尔(2020年)、金马和达里瓦尔(2018年)、范·奥尔德等人(2016年)、江等人(2021a)、纳利斯尼克等人(2018年)、崔等人(2018年)、基里琴科等人(2020年)、任等人(2019年)、塞拉等人(2020年)、肖等人(2020年)、王等人(2022a)</td></tr><tr><td>3.3节:基于距离的方法</td><td>李等人(2018b)、任等人(2021年)、泰查帕努拉克等人(2020年)、陈等人(2020c)、扎伊姆扎德等人(2021年)、范·阿默斯福特等人(2020年)、黄等人(2020a)、孙等人(2022年)、明等人(2023年)、金等人(2023年)</td></tr><tr><td>3.4节:基于重建的方法</td><td>德努登等人(2018年)、周(2022年)、杨等人(2022c)、江等人(2023a)、李等人(2023b)</td></tr><tr><td>3.5节:理论分析</td><td>张等人(2021年)、莫尔塔扎和李(2022年)、谢勒等人(2013年)、贾恩等人(2014年)、鲁德等人(2017年)、刘等人(2018a)、方等人(2021年，2022年)</td></tr></tbody></table>

## 3 OOD Detection: Methodology

## 3 分布外(OOD)检测:方法

In this section, we introduce the methodology for OOD detection. Initially, we explore classification-based models in Sect. 3.1. These models primarily utilize the model's output, such as softmax scores, to identify OOD instances. We further examine outlier exposure-based methods that leverage external data sources and other types of methods. The later section is followed by density-based methods in Sect.3.2. Distance-based methods will be introduced in Sect.3.3. A brief discussion will be included at the end.

在本节中，我们将介绍分布外(OOD)检测的方法。首先，我们将在3.1节中探讨基于分类的模型。这些模型主要利用模型的输出，如softmax分数，来识别分布外(OOD)实例。我们还将进一步研究基于异常值暴露的方法，这些方法利用外部数据源，以及其他类型的方法。随后，我们将在3.2节中介绍基于密度的方法。基于距离的方法将在3.3节中介绍。最后将进行简要讨论。

### 3.1 Classification-Based Methods

### 3.1 基于分类的方法

Research on OOD detection originated from a simple baseline, that is, using the maximum softmax probability as the indicator score of ID-ness (Hendrycks & Gimpel, 2017). Early OOD detection methods focus on deriving improved OOD scores based on the output of neural networks.

分布外(OOD)检测的研究源于一个简单的基线，即使用最大softmax概率作为分布内(ID)程度的指标分数(亨德里克斯和金佩尔，2017年)。早期的分布外(OOD)检测方法侧重于根据神经网络的输出来推导改进的分布外(OOD)分数。

#### 3.1.1 Output-Based Methods

#### 3.1.1 基于输出的方法

a. Post-Hoc Detection Post-hoc methods have the advantage of being easy to use without modifying the training procedure and objective. The property can be important for the adoption of OOD detection methods in real-world production environments, where the overhead cost of retraining can be prohibitive. Early work ODIN (Liang et al., 2018) is a post-hoc method that uses temperature scaling and input perturbation to amplify the ID/OOD separability. Key to the method, a sufficiently large temperature has a strong smoothing effect that transforms the softmax score back to the logit space-which effectively distinguishes ID vs. OOD. Note that this is different from confidence calibration, where a much milder $T$ is employed. While calibration focuses on representing the true correctness likelihood of ID data only, the ODIN score is designed to maximize the gap between ID and OOD data and may no longer be meaningful from a predictive confidence standpoint. Built on the insights, recent work (Liu et al., 2020; Lin et al., 2021) proposed using an energy score for OOD detection, which enjoys theoretical interpretation from a likelihood perspective (Morteza & Li, 2022). Test samples with lower energy are considered ID and vice versa. JointEnergy score (Wang et al., 2021) is then proposed to perform OOD detection for multi-label classification networks. The most recent work SHE (Zhang et al., 2023a) uses stored patterns that represent classes to measure the discrepancy of unseen data for OOD detection, which is hyperparameter-free and computationally efficient compared to classic energy methods. Techniques such as layer-wise Mahalanobis distance (Lee et al., 2018b) and Gram Matrix (Sastry & Oore, 2020) are implemented for better-hidden feature quality to perform density estimation.

a. 事后检测 事后检测方法的优点是易于使用，无需修改训练过程和目标。这一特性对于在现实生产环境中采用分布外(OOD)检测方法至关重要，因为在这些环境中，重新训练的开销可能过高。早期的工作ODIN(梁等人，2018年)是一种事后检测方法，它使用温度缩放和输入扰动来增强分布内(ID)/分布外(OOD)的可分离性。该方法的关键在于，足够大的温度具有很强的平滑效果，能将softmax分数转换回对数几率空间，从而有效区分分布内(ID)和分布外(OOD)。请注意，这与置信度校准不同，置信度校准采用的是温和得多的$T$。虽然校准仅关注表示分布内(ID)数据的真实正确可能性，但ODIN分数旨在最大化分布内(ID)和分布外(OOD)数据之间的差距，从预测置信度的角度来看，它可能不再有意义。基于这些见解，近期的工作(刘等人，2020年；林等人，2021年)提出使用能量分数进行分布外(OOD)检测，从似然性的角度来看，该方法具有理论解释(莫尔塔扎和李，2022年)。能量较低的测试样本被视为分布内(ID)样本，反之则为分布外(OOD)样本。随后，联合能量分数(王等人，2021年)被提出用于多标签分类网络的分布外(OOD)检测。最新的工作SHE(张等人，2023a)使用表示类别的存储模式来衡量未见数据的差异，以进行分布外(OOD)检测，与经典的能量方法相比，该方法无需超参数且计算效率高。为了获得更好的隐藏特征质量以进行密度估计，还采用了诸如逐层马氏距离(李等人，2018b)和格拉姆矩阵(萨斯特里和奥雷，2020年)等技术。

![0195d2b3-e92e-7da1-8c3c-990b96d6d818_9_147_146_1461_478_0.jpg](images/0195d2b3-e92e-7da1-8c3c-990b96d6d818_9_147_146_1461_478_0.jpg)

Fig. 3 Timeline for representative OOD detection methodologies. Different colors indicate different categories of methodologies. Each method has its corresponding reference (inconspicuous white) in the lower right corner. Methods with high citations and open-source code are prioritized for inclusion in this figure (Color figure online)

图3 代表性分布外(OOD)检测方法的时间线。不同颜色表示不同类别的方法。每种方法在右下角都有其相应的参考文献(不显眼的白色)。本图优先纳入引用次数高且有开源代码的方法(彩色图见在线版本)

Recently, one fundamental cause of the overconfidence issue on OOD data has been revealed that using mismatched BatchNorm statistics-that are estimated on ID data yet blindly applied to the OOD data in testing-can trigger abnormally high unit activations and model output accordingly (Sun et al., 2021b). Therefore, ReAct (Sun et al., 2021b) proposes truncating the high activations, which establishes strong post-hoc detection performance and further boosts the performance of existing scoring functions. Similarly, NMD (Dong et al., 2022) uses the activation means from BatchNorm layers for ID/OOD discrepancy. While ReAct considers activation space, (Sun & Li, 2022) proposes a weight sparsification-based OOD detection framework termed DICE. DICE ranks weights based on a measure of contribution and selectively uses the most salient weights to derive the output for OOD detection. By pruning away noisy signals, DICE provably reduces the output variance for OOD data, resulting in a sharper output distribution and stronger separability from ID data. In a similar vein, ASH (Djurisic et al., 2023) also targets the activation space but adopts a different strategy. It removes a significant portion (e.g., 90%) of an input's feature representations from a late layer based on a top-K criterion, followed by adjusting the remaining activations (e.g., 10%) either by scaling or assigning constant values, yielding surprisingly effective results.

最近，研究揭示了在分布外(OOD)数据上出现过度自信问题的一个根本原因，即使用不匹配的批量归一化(BatchNorm)统计量——这些统计量是在分布内(ID)数据上估计的，但在测试时盲目应用于分布外(OOD)数据——会相应地引发异常高的单元激活和模型输出(孙等人，2021b)。因此，ReAct(孙等人，2021b)提出截断高激活值，这建立了强大的事后检测性能，并进一步提升了现有评分函数的性能。同样，NMD(董等人，2022年)使用批量归一化(BatchNorm)层的激活均值来衡量分布内(ID)/分布外(OOD)的差异。当ReAct考虑激活空间时，(孙和李，2022年)提出了一个基于权重稀疏化的分布外(OOD)检测框架，称为DICE。DICE根据贡献度量对权重进行排序，并选择性地使用最显著的权重来推导用于分布外(OOD)检测的输出。通过去除噪声信号，DICE可证明地降低了分布外(OOD)数据的输出方差，从而产生更尖锐的输出分布，并增强了与分布内(ID)数据的可分离性。同样，ASH(久里西奇等人，2023年)也针对激活空间，但采用了不同的策略。它根据前K准则从较深的层中移除输入特征表示的很大一部分(例如90%)，然后通过缩放或赋予常数值来调整剩余的激活值(例如10%)，从而产生了惊人的有效结果。

b. Training-Based Methods With the training phase, confidence can be developed via designing a confidence-estimating branch (DeVries & Taylor, 2018) or class (Wang et al., 2021), ensembling with leaving-out strategy (Vyas et al., 2018), adversarial training (Bitterwolf et al., 2020; Chen et al., 2020b; Hein et al., 2019; Choi & Chung, 2020; Chen et al., 2021c), stronger data augmentation (Hein et al., 2019; Thulasidasan et al., 2019; Yun et al., 2019; DeVries & Taylor, 2017; Hendrycks et al., 2019c, 2022c), pretext training (Tack et al., 2020), better uncertainty modeling (Meinke & Hein, 2019; Bibas et al., 2021), input-level manipulation (Liang et al., 2018; Wang et al., 2022b), and utilizing feature or statistics from the intermediate-layer features (Lin et al., 2021; Dong et al., 2022). Especially, to enhance the sensitivity to covariate shift, some methods focus on the hidden representations in the middle layers of neural networks. Generalized ODIN, or G-ODIN (Hsu et al., 2020) extended ODIN (Liang et al., 2018) by using a specialized training objective termed DeConf-C and choosing hyperparameters such as perturbation magnitude on ID data. Note that we do not categorize G-ODIN as post-hoc method as it requires model retraining. Recent work (Wei et al., 2022) shows that the overconfidence issue can be mitigated through Logit Normalization (Logit-Norm), a simple fix to the common cross-entropy loss by enforcing a constant vector norm on the logits in training. Trained with LogitNorm, neural networks produce highly distinguishable confidence scores between in- and out-of-distribution data.

b. 基于训练的方法 在训练阶段，可以通过设计一个置信度估计分支(DeVries & Taylor，2018)或类别(Wang 等人，2021)、采用留一策略进行集成(Vyas 等人，2018)、对抗训练(Bitterwolf 等人，2020；Chen 等人，2020b；Hein 等人，2019；Choi & Chung，2020；Chen 等人，2021c)、更强的数据增强(Hein 等人，2019；Thulasidasan 等人，2019；Yun 等人，2019；DeVries & Taylor，2017；Hendrycks 等人，2019c，2022c)、前置训练(Tack 等人，2020)、更好的不确定性建模(Meinke & Hein，2019；Bibas 等人，2021)、输入级操作(Liang 等人，2018；Wang 等人，2022b)以及利用中间层特征的特征或统计信息(Lin 等人，2021；Dong 等人，2022)来提高置信度。特别是，为了增强对协变量偏移的敏感性，一些方法专注于神经网络中间层的隐藏表示。广义 ODIN 或 G - ODIN(Hsu 等人，2020)通过使用一种称为 DeConf - C 的专门训练目标，并在内部数据(ID data)上选择诸如扰动幅度等超参数，对 ODIN(Liang 等人，2018)进行了扩展。请注意，我们不将 G - ODIN 归类为事后方法，因为它需要重新训练模型。最近的工作(Wei 等人，2022)表明，通过对数归一化(Logit - Norm)可以缓解过度自信问题，这是一种通过在训练中对对数进行恒定向量归一化来对常见交叉熵损失进行的简单修正。使用对数归一化训练的神经网络在分布内和分布外数据之间产生高度可区分的置信度分数。

Some works redesign the label space to achieve good OOD detection performance. While commonly used to encode categorical information for classification, the one-hot encoding ignores the inherent relationship among labels. For example, it is unreasonable to have a uniform distance between dog and cat vs. dog and car. To this end, several works attempt to use information in the label space for OOD detection. Some works arrange the large semantic space into a hierarchical taxonomy of known classes (Lee et al., 2018c; Huang et al., 2021; Linderman et al., 2023). Under the redesigned label architecture, top-down classification strategy (Lee et al., 2018c; Linderman et al., 2023) and group softmax training (Huang et al., 2021) are demonstrated effective. Another set of works uses word embeddings to automatically construct the label space. In Shalev et al. (2018), the sparse one-hot labels are replaced with several dense word embeddings from different NLP models, forming multiple regression heads for robust training. When testing, the label, which has the minimal distance to all the embedding vectors from different heads, will be considered as the prediction. If the minimal distance crosses above the threshold, the sample would be classified as "novel". Recent works further take the image features from language-image pre-training models (Radford et al., 2021) to better detect novel classes, where the image encoding space also contains rich information from the language space (Fort et al., 2021; Gan, 2021).

一些工作重新设计标签空间以实现良好的分布外(OOD)检测性能。虽然独热编码(one - hot encoding)通常用于对分类的类别信息进行编码，但它忽略了标签之间的内在关系。例如，狗和猫之间的距离与狗和汽车之间的距离相同是不合理的。为此，一些工作尝试利用标签空间中的信息进行 OOD 检测。一些工作将大的语义空间安排成已知类别的层次分类法(Lee 等人，2018c；Huang 等人，2021；Linderman 等人，2023)。在重新设计的标签架构下，自上而下的分类策略(Lee 等人，2018c；Linderman 等人，2023)和分组 softmax 训练(Huang 等人，2021)被证明是有效的。另一组工作使用词嵌入来自动构建标签空间。在 Shalev 等人(2018)的研究中，稀疏的独热标签被来自不同自然语言处理(NLP)模型的几个密集词嵌入所取代，形成多个回归头以进行稳健训练。在测试时，与来自不同头的所有嵌入向量距离最小的标签将被视为预测结果。如果最小距离超过阈值，则该样本将被分类为“新类别”。最近的工作进一步利用语言 - 图像预训练模型(Radford 等人，2021)的图像特征来更好地检测新类别，其中图像编码空间也包含来自语言空间的丰富信息(Fort 等人，2021；Gan，2021)。

#### 3.1.2 Methods with Outlier Exposure

#### 3.1.2 带有离群值暴露的方法

a. Real Outliers Another branch of OOD detection methods makes use of a set of collected OOD samples, or "outlier", during training to help models learn ID/OOD discrepancy. Starting from the concurrent baselines that encourage a flat/high-entropic prediction on given OOD samples (Hendrycks et al., 2019b; Dhamija et al., 2018) and suppressing OOD feature magnitudes (Dhamija et al., 2018), a follow-up work, MCD (Yu & Aizawa, 2019) uses a network with two branches, between which entropy discrepancy is enlarged for OOD training data. Another straightforward approach with outlier exposure spares an extra abstention (or rejection class) and considers all the given OOD samples in this class (Mohseni et al., 2020; Chen et al., 2021c; Thulasi-dasan et al., 2021). A later work OECC (Papadopoulos et al., 2021) noticed that an extra regularization for confidence calibration introduces additional improvement for OE. To effectively utilize the given, usually massive, OOD samples, some work use outlier mining (Chen et al., 2021c; Ming et al., 2022b) and adversarial resampling (Li & Vasconcelos, 2020) approaches to obtain a compact yet representative set. In cases where the meaningful "near"-OOD images are not available, MixOE (Zhang et al., 2023b) proposes to interpolate between ID and "far"-OOD images to obtain informative outliers for better regularization. Other works consider a more practical scenario where given OOD samples contain ID samples, therefore using pseudo-labeling (Mohseni et al., 2020) or ID filtering methods (Yang et al., 2021) with optimal transport scheme (Lu et al., 2023) to reduce the interference of ID data. In general, OOD detection with outlier exposure can reach a much better performance.

a. 真实离群值 另一类分布外(OOD)检测方法在训练过程中利用一组收集到的OOD样本，即“离群值”，来帮助模型学习分布内(ID)/OOD的差异。从鼓励对给定OOD样本进行平坦/高熵预测(亨德里克斯等人，2019b；达米贾等人，2018)并抑制OOD特征幅度(达米贾等人，2018)的同期基线方法开始，后续工作MCD(于和相泽，2019)使用了一个具有两个分支的网络，在这两个分支之间扩大OOD训练数据的熵差异。另一种直接的离群值暴露方法预留了一个额外的弃权(或拒绝类别)，并将所有给定的OOD样本归为该类别(莫赫塞尼等人，2020；陈等人，2021c；图拉西 - 达桑等人，2021)。后来的工作OECC(帕帕多普洛斯等人，2021)注意到，用于置信度校准的额外正则化对离群值暴露(OE)方法有额外的改进。为了有效利用通常数量庞大的给定OOD样本，一些工作采用离群值挖掘(陈等人，2021c；明等人，2022b)和对抗性重采样(李和瓦斯康塞洛斯，2020)方法来获得一个紧凑但具有代表性的集合。在没有有意义的“近”OOD图像的情况下，MixOE(张等人，2023b)提出在ID和“远”OOD图像之间进行插值，以获得信息丰富的离群值，从而实现更好的正则化。其他工作考虑了一种更实际的场景，即给定的OOD样本中包含ID样本，因此使用伪标签法(莫赫塞尼等人，2020)或ID过滤方法(杨等人，2021)以及最优传输方案(陆等人，2023)来减少ID数据的干扰。一般来说，使用离群值暴露的OOD检测可以达到更好的性能。

In typical outlier exposure setups, the auxiliary outlier data used during training is assumed to be representative of the true OOD data encountered at test time. However, research shows that the performance can be largely affected by the correlations between given and real OOD samples (Shafaei et al., 2019). Wang et al. (2023c) and Katz-Samuels et al. (2022) both highlight that the discrepancy between surrogate and test-time OOD distributions can hinder the effectiveness of outlier exposure methods. To address the issue, recent work (Katz-Samuels et al., 2022) proposes a novel framework that enables effectively exploiting unlabeled in-the-wild data for OOD detection. Unlabeled wild data is frequently available since it is produced essentially for free whenever deploying an existing classifier in a real-world system. This setting can be viewed as training OOD detectors in their natural habitats, which provide a much better match to the true test time distribution than data collected offline. Wang et al. (2023b) propose an approach to craft an augmented set of OOD distributions around the training outliers to mitigate this distribution shift. Accounting for potential shifts in the OOD data distribution, in addition to shifts in the ID data, is an important consideration for developing robust OOD detectors that can handle the complexities of real-world settings.

在典型的离群值暴露设置中，训练期间使用的辅助离群值数据被假定能够代表测试时遇到的真实OOD数据。然而，研究表明，给定的OOD样本与真实OOD样本之间的相关性会在很大程度上影响检测性能(沙法伊等人，2019)。王等人(2023c)和卡茨 - 塞缪尔斯等人(2022)都强调，替代OOD分布与测试时OOD分布之间的差异会阻碍离群值暴露方法的有效性。为了解决这个问题，近期的工作(卡茨 - 塞缪尔斯等人，2022)提出了一个新颖的框架，该框架能够有效利用未标记的自然数据进行OOD检测。未标记的自然数据通常很容易获取，因为在现实世界系统中部署现有分类器时，这些数据本质上是免费产生的。这种设置可以看作是在自然环境中训练OOD检测器，与离线收集的数据相比，它能更好地匹配真实测试时的分布。王等人(2023b)提出了一种方法，在训练离群值周围构建一组增强的OOD分布，以减轻这种分布偏移。除了考虑ID数据的潜在偏移外，考虑OOD数据分布的潜在偏移对于开发能够处理现实世界复杂情况的鲁棒OOD检测器是一个重要的考量因素。

b. Outlier Data Generation The outlier exposure approaches impose a strong assumption on the availability of OOD training data, which can be infeasible in practice. When no OOD sample is available, some methods attempt to synthesize OOD samples to enable ID/OOD separability. Existing works leverage GANs to generate OOD training samples and force the model predictions to be uniform (Lee et al., 2018a), generate boundary samples in the low-density region (Vernekar et al., 2019), or similarly, high-confidence OOD samples (Sricharan et al., 2018), or using meta-learning the update sample generation (Jeong & Kim, 2020). However, synthesizing images in the high-dimensional pixel space can be difficult to optimize. Recent work VOS (Du et al., 2022b) proposed synthesizing virtual outliers from the low-likelihood region in the feature space, which is more tractable given lower dimensionality. While VOS (Du et al., 2022b) is a parametric approach that models the feature space as a class-conditional Gaussian distribution, NPOS (Tao et al., 2023) also generates outlier ID data but in a nonparametric approach. Noticing the generated OOD data could be incorrect or irrelevant, DOE (Wang et al., 2023c) synthesizes hard OOD data that leads to worst judgments to train the OOD detector with a min-max learning scheme, and ATOL (Zheng et al., 2023) uses auxiliary task to relieve the mistaken OOD generation. In object detection, (Du et al., 2022a) proposes synthesizing unknown objects from videos in the wild using spatial-temporal unknown distillation.

b. 离群数据生成 离群暴露方法对分布外(OOD)训练数据的可用性提出了很强的假设，而这在实践中可能并不可行。当没有可用的OOD样本时，一些方法试图合成OOD样本以实现分布内(ID)/OOD的可分离性。现有工作利用生成对抗网络(GANs)来生成OOD训练样本，并迫使模型预测具有均匀性(Lee等人，2018a)，在低密度区域生成边界样本(Vernekar等人，2019)，或者类似地，生成高置信度的OOD样本(Sricharan等人，2018)，或者使用元学习来更新样本生成(Jeong和Kim，2020)。然而，在高维像素空间中合成图像可能难以优化。近期的工作VOS(Du等人，2022b)提出从特征空间中的低似然区域合成虚拟离群点，鉴于其维度较低，这种方法更易于处理。虽然VOS(Du等人，2022b)是一种将特征空间建模为类别条件高斯分布的参数化方法，但NPOS(Tao等人，2023)也生成离群ID数据，不过采用的是非参数化方法。考虑到生成的OOD数据可能不正确或不相关，DOE(Wang等人，2023c)合成会导致最差判断的难OOD数据，以通过最小 - 最大学习方案训练OOD检测器，而ATOL(Zheng等人，2023)使用辅助任务来缓解错误的OOD生成。在目标检测中，(Du等人，2022a)提出使用时空未知蒸馏从野外视频中合成未知目标。

#### 3.1.3 Gradient-Based Methods

#### 3.1.3 基于梯度的方法

Existing OOD detection approaches primarily rely on the output (Sect.3.1) or feature space for deriving OOD scores, while overlooking information from the gradient space. ODIN (Liang et al., 2018) first explored using gradient information for OOD detection. In particular, ODIN proposed using input pre-processing by adding small perturbations obtained from the input gradients. The goal of ODIN perturbations is to increase the softmax score of any given input by reinforcing the model's belief in the predicted label. Ultimately the perturbations have been found to create a greater gap between the softmax scores of ID and OOD inputs, thus making them more separable and improving the performance of OOD detection. While ODIN only uses gradients implicitly through input perturbation, recent work proposed GradNorm (Huang et al., 2021) which explicitly derives a scoring function from the gradient space. GradNorm employs the vector norm of gradients, backpropagated from the KL divergence between the softmax output and a uniform probability distribution. A recent research (Igoe et al., 2022) demonstrates that while gradient-based methods are effective, their success does not necessarily depend on gradients, but rather on the magnitude of learned feature embeddings and predicted output distribution.

现有的OOD检测方法主要依赖输出(3.1节)或特征空间来推导OOD分数，而忽略了梯度空间的信息。ODIN(Liang等人，2018)首次探索了使用梯度信息进行OOD检测。具体而言，ODIN提出通过添加从输入梯度获得的小扰动来进行输入预处理。ODIN扰动的目标是通过强化模型对预测标签的置信度来提高任何给定输入的softmax分数。最终发现，这些扰动能够在ID和OOD输入的softmax分数之间产生更大的差距，从而使它们更易于分离，并提高OOD检测的性能。虽然ODIN仅通过输入扰动隐式地使用梯度，但近期的工作提出了GradNorm(Huang等人，2021)，它从梯度空间显式地推导了一个评分函数。GradNorm采用从softmax输出和均匀概率分布之间的KL散度反向传播得到的梯度向量范数。最近的一项研究(Igoe等人，2022)表明，虽然基于梯度的方法是有效的，但它们的成功并不一定依赖于梯度，而是依赖于学习到的特征嵌入的大小和预测输出分布。

#### 3.1.4 Bayesian Models

#### 3.1.4 贝叶斯模型

A Bayesian model is a statistical model that implements Bayes' rule to infer all uncertainty within the model (Jaynes, 1986). The most representative method is the Bayesian neural network (Neal, 2012), which draws samples from the posterior distribution of the model via MCMC (Gamer-man & Lopes, 2006), Laplace methods (Mackay, 1992; Foong et al., 2020) and variational inference (Peterson & Hartman, 1989), forming the epistemic uncertainty of the model prediction. However, their obvious shortcomings of inaccurate predictions (Wenzel et al., 2020) and high computational costs (Gelman, 2008) prevent them from wide adoption in practice. Recent works attempt several less principled approximations including MC-dropout (Gal & Ghahramani, 2016) and deep ensembles (Dietterich, 2000; Lakshminarayanan et al., 2017; Maddox et al., 2019) for faster and better estimates of uncertainty. These methods are less competitive for OOD uncertainty estimation. Further exploration takes natural-gradient variational inference and enables practical and affordable modern deep learning training while preserving the benefits of Bayesian principles (Osawa et al., 2019). Dirichlet Prior Network (DPN) is also used for OOD detection with an uncertainty modeling of three different sources of uncertainty: model uncertainty, data uncertainty, and distributional uncertainty, and form a line of works (Malinin & Gales, 2018, 2019; Nandy et al., 2020). Recently, the Bayesian hypothesis test has been used to formulate OOD detection, with upweighting method and Hessian approximation for scalability (Kim et al., 2021).

贝叶斯模型是一种应用贝叶斯规则来推断模型内所有不确定性的统计模型(Jaynes，1986)。最具代表性的方法是贝叶斯神经网络(Neal，2012)，它通过马尔可夫链蒙特卡罗(MCMC)方法(Gamerman和Lopes，2006)、拉普拉斯方法(Mackay，1992；Foong等人，2020)和变分推断(Peterson和Hartman，1989)从模型的后验分布中抽取样本，形成模型预测的认知不确定性。然而，它们明显的缺点，如预测不准确(Wenzel等人，2020)和计算成本高(Gelman，2008)，阻碍了它们在实践中的广泛应用。近期的工作尝试了几种不太严谨的近似方法，包括蒙特卡罗随机失活(MC - dropout)(Gal和Ghahramani，2016)和深度集成(Dietterich，2000；Lakshminarayanan等人，2017；Maddox等人，2019)，以更快、更好地估计不确定性。这些方法在OOD不确定性估计方面竞争力较弱。进一步的探索采用自然梯度变分推断，在保留贝叶斯原理优势的同时，实现了实用且经济的现代深度学习训练(Osawa等人，2019)。狄利克雷先验网络(DPN)也用于OOD检测，它对三种不同来源的不确定性进行建模:模型不确定性、数据不确定性和分布不确定性，并形成了一系列相关工作(Malinin和Gales，2018，2019；Nandy等人，2020)。最近，贝叶斯假设检验已被用于制定OOD检测方法，并采用加权方法和海森矩阵近似以提高可扩展性(Kim等人，2021)。

#### 3.1.5 OOD Detection for Foundation Models

#### 3.1.5 基础模型的OOD检测

Foundation models (Bommasani et al., 2021), notably large-scale vision-language models (Radford et al., 2021), have demonstrated exceptional performance in a variety of downstream tasks. Their success is largely attributed to extensive pre-training on large-scale datasets. Several works (Hendrycks et al., 2019a; Fort et al., 2021; Hendrycks et al., 2020) reveal that well-pretrained models can significantly enhance OOD detection, particularly in challenging scenarios.

基础模型(Bommasani等人，2021年)，尤其是大规模视觉语言模型(Radford等人，2021年)，在各种下游任务中表现出了卓越的性能。它们的成功在很大程度上归功于在大规模数据集上进行的广泛预训练。多项研究(Hendrycks等人，2019a；Fort等人，2021年；Hendrycks等人，2020年)表明，经过良好预训练的模型可以显著增强分布外(OOD)检测能力，特别是在具有挑战性的场景中。

However, adapting (tuning) these models for downstream tasks with specific semantic (label) space in the training data remains a challenge, as simple approaches such as linear probing, prompt tuning (Zhou et al., 2022a, b; Jia et al., 2022), and adaptor-style fine-tuning methods (Gao et al., 2023) do not have good results on OOD detection. Dong et al. (2023) establish a comprehensive few-shot OOD detection benchmark, demonstrating the superiority of parameter-efficient fine-tuning strategies over conventional techniques. They propose a novel method called Domain-Specific and General Knowledge Fusion (DSGF) to strengthen fine-tuned features with original pre-trained features, significantly enhancing few-shot OOD detection capabilities. To advance the problem, a thorough investigation (Ming & Li, 2023) examines how fine-tuned vision-language models are performed. Additionally, recent research (Miyai et al., 2023a) highlights the impact of large-scale pretraining data and provides a systematic study on pretraining strategies on OOD detection performance. On a technical front, LoCoOp (Miyai et al., 2023b) introduces OOD regularization to a subset of CLIP’s local features identified as OOD, enhancing prompt learning for better ID and OOD differentiation, and LSA (Lu et al., 2023) uses a bidirectional prompt customization mechanism to enhance the image-text alignment.

然而，要使这些模型适应(微调)训练数据中具有特定语义(标签)空间的下游任务仍然是一项挑战，因为诸如线性探测、提示微调(Zhou等人，2022a，b；Jia等人，2022年)和适配器式微调方法(Gao等人，2023年)等简单方法在OOD检测方面效果不佳。Dong等人(2023年)建立了一个全面的少样本OOD检测基准，证明了参数高效微调策略优于传统技术。他们提出了一种名为特定领域与通用知识融合(DSGF)的新方法，用原始预训练特征强化微调后的特征，显著增强了少样本OOD检测能力。为了推进这一问题的研究，一项深入调查(Ming和Li，2023年)研究了微调后的视觉语言模型的性能。此外，近期研究(Miyai等人，2023a)强调了大规模预训练数据的影响，并对预训练策略对OOD检测性能的影响进行了系统研究。在技术方面，LoCoOp(Miyai等人，2023b)将OOD正则化引入到被识别为OOD的CLIP局部特征子集中，增强了提示学习，以便更好地区分分布内(ID)和OOD样本，而LSA(Lu等人，2023年)则使用双向提示定制机制来增强图像 - 文本对齐。

The strong zero-shot learning capabilities of models like CLIP (Radford et al., 2021) also open avenues for zero-shot OOD detection. This new setting aims to categorize known class samples and detect samples that do not belong to any of the known classes, where known classes are represented solely through textual descriptions or class names, eliminating the need for explicit training on these classes. Addressing this, ZOC (Esmaeilpour et al., 2022) trains a decoder based on CLIP's visual encoder to create candidate labels for OOD detection. While ZOC is computationally intensive and data-demanding, MCM (Ming et al., 2022a) opts for soft-max scaling to align visual features with textual concepts for OOD detection. Jiang et al. (2023c) propose NegLabel, which introduces massive negative labels exhibiting significant semantic differences from ID labels, determining whether an image is OOD by comparing its affinity towards ID and negative labels. Bai et al. (2023) construct ID-like outliers using CLIP and propose an ID-like prompt learning framework to identify challenging OOD samples. Nie et al. (2023) propose to learn a set of negative prompts for each class, which are leveraged along with learned positive prompts to measure similarity and dissimilarity in the feature space simultaneously, enabling more accurate detection of OOD samples. A recent advancement, CLIPN (Wang et al., 2023a), innovatively integrates a "no" logic in OOD detection. Utilizing new prompts and a text encoder, along with novel opposite loss functions, CLIPN effectively tackles the challenge of identifying hard-to-distinguish OOD samples. This development marks a significant stride in enhancing the precision of OOD detection in complex scenarios.

像CLIP(Radford等人，2021年)这样的模型强大的零样本学习能力也为零样本OOD检测开辟了新途径。这种新的设置旨在对已知类别样本进行分类，并检测不属于任何已知类别的样本，其中已知类别仅通过文本描述或类别名称来表示，无需对这些类别进行显式训练。针对这一问题，ZOC(Esmaeilpour等人，2022年)基于CLIP的视觉编码器训练了一个解码器，以创建用于OOD检测的候选标签。虽然ZOC计算量大且对数据要求高，但MCM(Ming等人，2022a)选择使用soft - max缩放来使视觉特征与文本概念对齐，以进行OOD检测。Jiang等人(2023c)提出了NegLabel方法，该方法引入了与ID标签具有显著语义差异的大量负标签，通过比较图像与ID标签和负标签的亲和度来确定图像是否为OOD。Bai等人(2023年)使用CLIP构建类似ID的离群值，并提出了一个类似ID的提示学习框架来识别具有挑战性的OOD样本。Nie等人(2023年)提议为每个类别学习一组负提示，并将其与学习到的正提示一起用于同时测量特征空间中的相似性和差异性，从而能够更准确地检测OOD样本。最近的一项进展，CLIPN(Wang等人，2023a)在OOD检测中创新性地集成了“否”逻辑。CLIPN利用新的提示和文本编码器，以及新颖的对立损失函数，有效地解决了识别难以区分的OOD样本这一难题。这一进展标志着在复杂场景中提高OOD检测精度方面迈出了重要一步。

### 3.2 Density-Based Methods

### 3.2 基于密度的方法

Density-based methods in OOD detection explicitly model the in-distribution with some probabilistic models, and flag test data in low-density regions as OOD. Although OOD detection can be different from AD in that multiple classes exist in the in-distribution, density estimation methods used for AD in Sect.4.2 can be directly adapted to OOD detection by unifying the ID data as a whole (Zong et al., 2018; Abati et al., 2019; Pidhorskyi et al., 2018; Deecke et al., 2018; Sabokrou et al., 2018). When the ID contains multiple classes, class-conditional Gaussian distribution can explicitly model the in-distribution so that the OOD samples can be identified based on their likelihoods (Lee et al., 2018b). Flow-based methods (Kobyzev et al., 2020; Zisselman & Tamar, 2020; Kingma & Dhariwal, 2018; Van Oord et al., 2016; Jiang et al., 2021a) can also be used for probabilistic modeling. While directly estimating the likelihood seems like a natural approach, some works (Nalisnick et al., 2018; Choi et al., 2018; Kirichenko et al., 2020) find that probabilistic models sometimes assign a higher likelihood for the OOD sample. Several works attempt to solve the problems using likelihood ratio (Ren et al., 2019). Serrà et al. (2020) finds that the likelihood exhibits a strong bias towards the input complexity and proposes a likelihood ratio-based method to compensate for the influence of input complexity. Recent methods turn to new scores such as likelihood regret (Xiao et al., 2020) or an ensemble of multiple density models (Choi et al., 2018). To directly model the density of semantic space, SEM score is used with a simple combination of density estimation in the low-level and high-level space (Yang et al., 2022b). Overall, generative models can be prohibitively challenging to train and optimize, and the performance can often lag behind the classification-based approaches (Sect. 3.1).

在离群分布(OOD)检测中，基于密度的方法使用一些概率模型对分布内数据进行显式建模，并将低密度区域的测试数据标记为离群分布数据。尽管OOD检测与异常检测(AD)有所不同，因为分布内存在多个类别，但第4.2节中用于AD的密度估计方法可以通过将分布内(ID)数据作为一个整体进行统一，直接应用于OOD检测(宗等人，2018年；阿巴蒂等人，2019年；皮德霍尔斯基等人，2018年；迪克等人，2018年；萨博克罗等人，2018年)。当ID包含多个类别时，类条件高斯分布可以对分布内数据进行显式建模，从而可以根据离群样本的似然性来识别它们(李等人，2018b)。基于流的方法(科比泽夫等人，2020年；齐塞尔曼和塔马尔，2020年；金玛和达里瓦尔，2018年；范·奥尔德等人，2016年；江等人，2021a)也可用于概率建模。虽然直接估计似然性似乎是一种自然的方法，但一些研究(纳利斯尼克等人，2018年；崔等人，2018年；基里琴科等人，2020年)发现，概率模型有时会为离群样本分配更高的似然性。一些研究试图使用似然比来解决这些问题(任等人，2019年)。塞拉等人(2020年)发现，似然性对输入复杂度表现出强烈的偏差，并提出了一种基于似然比的方法来补偿输入复杂度的影响。最近的方法转向了新的得分，如似然遗憾(肖等人，2020年)或多个密度模型的集成(崔等人，2018年)。为了直接对语义空间的密度进行建模，SEM得分与低层次和高层次空间中的密度估计进行简单组合使用(杨等人，2022b)。总体而言，生成模型的训练和优化可能极具挑战性，并且其性能通常落后于基于分类的方法(第3.1节)。

### 3.3 Distance-Based Methods

### 3.3 基于距离的方法

The basic idea of distance-based methods is that the testing OOD samples should be relatively far away from the centroids or prototypes of in-distribution classes. (Lee et al., 2018b) uses the minimum Mahalanobis distance to all class centroids for detection. A subsequent work splits the images into foreground and background and then calculates the Mahalanobis distance ratio between the two spaces (Ren et al., 2021). In contrast to the parametric approach, recent work (Sun et al., 2022) shows strong promise of nonparametric nearest-neighbor distance for OOD detection. Unlike Mahalanobis, the non-parametric approach does not impose any distributional assumption about the underlying feature space, hence providing stronger simplicity, flexibility, and generality.

基于距离的方法的基本思想是，测试的离群分布样本应该相对远离分布内类别的质心或原型。(李等人，2018b)使用到所有类质心的最小马氏距离进行检测。后续的一项工作将图像分为前景和背景，然后计算两个空间之间的马氏距离比(任等人，2021年)。与参数化方法不同，最近的研究(孙等人，2022年)表明，非参数最近邻距离在OOD检测中具有很大的潜力。与马氏距离不同，非参数方法不对底层特征空间施加任何分布假设，因此具有更强的简单性、灵活性和通用性。

For distance functions, some works use cosine similarity between test sample features and class features to determine OOD samples (Techapanurak et al., 2020; Chen et al., 2020c). The one-dimensional subspace spanned by the first singular vector of the training features is shown to be more suitable for cosine similarity-based detection (Zaeemzadeh et al., 2021). Moreover, other works leverage distances with radial basis function kernel (Van Amersfoort et al., 2020), Euclidean distance (Huang et al., 2020a), and geodesic distance (Gomes et al., 2022) between the input's embedding and the class centroids. Apart from calculating the distance between samples and class centroids, the feature norm in the orthogonal complement space of the principal space is shown effective on OOD detection (Wang et al., 2022a). Recent work CIDER (Ming et al., 2023) explores the usability of the embeddings in the hyperspherical space, where inter-class dispersion and inner-class compactness can be encouraged.

对于距离函数，一些研究使用测试样本特征与类特征之间的余弦相似度来确定离群分布样本(特查帕努拉克等人，2020年；陈等人，2020c)。研究表明，由训练特征的第一个奇异向量所张成的一维子空间更适合基于余弦相似度的检测(扎伊姆扎德等人，2021年)。此外，其他研究利用输入嵌入与类质心之间的径向基函数核距离(范·阿默斯福特等人，2020年)、欧几里得距离(黄等人，2020a)和测地距离(戈麦斯等人，2022年)。除了计算样本与类质心之间的距离外，主空间正交补空间中的特征范数在OOD检测中也被证明是有效的(王等人，2022a)。最近的研究CIDER(明等人，2023年)探索了超球面空间中嵌入的可用性，在该空间中可以促进类间分散和类内紧凑性。

### 3.4 Reconstruction-Based Methods

### 3.4 基于重建的方法

The core idea of reconstruction-based methods is that the encoder-decoder framework trained on the ID data usually yields different outcomes for ID and OOD samples. The difference in model performance can be utilized as an indicator for detecting anomalies. For example, reconstruction models that are only trained by ID data cannot well recover the OOD data (Denouden et al., 2018), and therefore the OOD can be identified. While reconstruction-based models with pixel-level comparison seem not a popular solution in OOD detection for its expensive training cost, reconstructing with hidden features is shown as a promising alternative (Zhou, 2022). Rather than reconstructing the entire image, recent work MoodCat (Yang et al., 2022c) masks a random portion of the input image and identifies OOD samples using the quality of the classification-based reconstruction results. READ (Jiang et al., 2023a) combines inconsistencies from a classifier and an autoencoder by transforming the reconstruction error of raw pixels to the latent space of the classifier. MOOD (Li et al., 2023b) shows that masked image modeling for pretraining is beneficial to OOD detection tasks compared to contrastive training and classic classifier training.

基于重建的方法的核心思想是，在分布内(ID)数据上训练的编码器 - 解码器框架通常会对分布内和分布外(OOD)样本产生不同的结果。模型性能的差异可以作为检测异常的指标。例如，仅由分布内数据训练的重建模型无法很好地恢复分布外数据(Denouden 等人，2018 年)，因此可以识别出分布外数据。虽然基于像素级比较的重建模型由于其高昂的训练成本，在分布外检测中似乎不是一个流行的解决方案，但使用隐藏特征进行重建被证明是一种有前途的替代方法(周，2022 年)。近期的 MoodCat 工作(杨等人，2022c)不是重建整个图像，而是对输入图像的随机部分进行掩码处理，并使用基于分类的重建结果的质量来识别分布外样本。READ(江等人，2023a)通过将原始像素的重建误差转换到分类器的潜在空间，结合了分类器和自动编码器的不一致性。MOOD(李等人，2023b)表明，与对比训练和经典分类器训练相比，用于预训练的掩码图像建模有利于分布外检测任务。

### 3.5 Theoretical Analysis

### 3.5 理论分析

Early theoretical research on OOD detection (Zhang et al., 2021) delves into the limitations of Deep Generative Models (DGMs) in OOD contexts. This work uncovers a critical flaw where DGMs frequently assign greater probabilities to OOD data compared to training data, attributing this issue primarily to model misestimation rather than the typical set hypothesis. This hypothesis posits that relevant out-distributions might be located in high-likelihood areas of the data distribution. The study concludes that any generalized OOD task must restrict the set of distributions that are considered out-of-distribution, as without any restrictions, the task is impossible. Later work (Morteza & Li, 2022) advances the field by developing a comprehensive analytical framework aimed at enhancing theoretical understanding and practical performance of OOD detection methods in neural networks. Their innovative approach culminates in a novel OOD detection method that surpasses existing techniques in both theoretical robustness and empirical performance.

早期关于分布外检测的理论研究(张等人，2021 年)深入探讨了深度生成模型(DGMs)在分布外场景中的局限性。这项工作揭示了一个关键缺陷，即深度生成模型通常会比训练数据更大概率地分配给分布外数据，主要将此问题归因于模型的错误估计，而非典型的集合假设。该假设认为相关的分布外数据可能位于数据分布的高似然区域。研究得出结论，任何广义的分布外任务都必须限制被视为分布外的分布集合，因为如果没有任何限制，该任务是不可能完成的。后来的工作(Morteza 和李，2022 年)通过开发一个全面的分析框架推动了该领域的发展，旨在增强对神经网络中分布外检测方法的理论理解和实际性能。他们的创新方法最终形成了一种新的分布外检测方法，在理论鲁棒性和实证性能方面都超越了现有技术。

Another series of studies has been focused on Open-Set Learning (OSL). The seminal work in this domain (Scheirer et al., 2013) conceptualizes open-space risk for recognizing samples from unknown classes. The following research applies extreme value theory to OSL (Jain et al., 2014; Rudd et al., 2017). While probably approximately correct (PAC) theory is applied for OSR (Liu et al., 2018a), their method required test samples during training. Therefore, an investigation of the generalization error bound is conducted and proves the existence of a low-error OSL algorithm under certain assumptions (Fang et al., 2021). Still, under the PAC theory, a later study establishes necessary and sufficient conditions for the learnability of OOD detection in various scenarios (Fang et al., 2022), including cases with overlapping and non-overlapping ID and OOD data. Their work also offers theoretical support for existing OOD detection algorithms and suggests that OOD detection is possible under certain practical conditions.

另一系列研究集中在开放集学习(OSL)上。该领域的开创性工作(Scheirer 等人，2013 年)为识别来自未知类别的样本概念化了开放空间风险。后续研究将极值理论应用于开放集学习(Jain 等人，2014 年；Rudd 等人，2017 年)。虽然大概近似正确(PAC)理论被应用于开放集识别(OSR)(刘等人，2018a)，但他们的方法在训练期间需要测试样本。因此，对泛化误差界进行了研究，并证明了在某些假设下存在低误差的开放集学习算法(方等人，2021 年)。尽管如此，在大概近似正确理论下，后来的一项研究为各种场景下分布外检测的可学习性建立了充分必要条件(方等人，2022 年)，包括分布内和分布外数据有重叠和无重叠的情况。他们的工作还为现有的分布外检测算法提供了理论支持，并表明在某些实际条件下分布外检测是可行的。

Despite these theoretical advancements, the field eagerly anticipates further research addressing aspects such as generalization in OOD detection, the explainability of these models, the integration of deep learning theory specific to OOD detection, and the exploration of foundation model theories pertinent to this area.

尽管有这些理论进展，但该领域迫切期待进一步的研究来解决诸如分布外检测中的泛化问题、这些模型的可解释性、专门针对分布外检测的深度学习理论的整合，以及探索与该领域相关的基础模型理论等方面的问题。

### 3.6 Discussion

### 3.6 讨论

The field of OOD detection has enjoyed rapid development since its emergence, with a large space of solutions. In the multi-class setting, the problem can be canonical to OSR (Sect.4.1)—accurately classify test samples from ID within the class space $\mathcal{Y}$ , and reject test samples with semantics outside the support of $\mathcal{Y}$ . The difference often lies in the evaluation protocol. OSR splits a dataset into two halves: one set as ID and another set as OOD. In contrast, OOD allows a more general and flexible evaluation by considering test samples from different datasets or domains. Moreover, OOD detection encompasses a broader spectrum of learning tasks (e.g., multi-label classification (Wang et al., 2021), object detection (Du et al., 2022b, a)) and solution space. Apart from the methodology development, theoretical understanding has also received attention in the community (Morteza & Li, 2022), providing provable guarantees and empirical analysis to understand how OOD detection performance changes with respect to data distributions.

分布外检测领域自出现以来发展迅速，有大量的解决方案。在多类设置中，该问题可以规范为开放集识别(OSR)(4.1 节)——在类别空间 $\mathcal{Y}$ 内准确分类来自分布内的测试样本，并拒绝语义在 $\mathcal{Y}$ 支持范围之外的测试样本。差异通常在于评估协议。开放集识别将数据集分成两半:一组作为分布内数据，另一组作为分布外数据。相比之下，分布外检测通过考虑来自不同数据集或领域的测试样本，允许更通用和灵活的评估。此外，分布外检测涵盖了更广泛的学习任务(例如，多标签分类(王等人，2021 年)、目标检测(杜等人，2022b，a))和解决方案空间。除了方法开发之外，理论理解也受到了该领域的关注(Morteza 和李，2022 年)，为理解分布外检测性能如何随数据分布变化提供了可证明的保证和实证分析。

## 4 Methodologies from Other Sub-tasks

## 4 来自其他子任务的方法

In this section, we briefly introduce methodologies for subtasks under the generalized OOD detection framework, including AD, ND, OSR, and OD, in hope that the methods from other sub-tasks can inspire more ideas for OOD detection community.

在本节中，我们简要介绍广义分布外检测框架下子任务的方法，包括异常检测(AD)、新奇性检测(ND)、开放集识别(OSR)和离群点检测(OD)，希望来自其他子任务的方法能为分布外检测领域带来更多的思路。

### 4.1 Open Set Recognition

### 4.1 开放集识别

The concept of OSR was first introduced in (Scheirer et al., 2013), which showed the validity of 1-class SVM and binary SVM for solving the OSR problem. In particular, (Scheirer et al., 2013) proposes the 1-vs-Set SVM to manage the open-set risk by solving a two-plane optimization problem instead of the classic half-space of a binary linear classifier. This paper highlighted that the open-set space should also be bounded, in addition to bounding the ID risk.

开放集识别(OSR)的概念最早由(Scheirer等人，2013)提出，该研究展示了单类支持向量机(1-class SVM)和二分类支持向量机(binary SVM)解决开放集识别问题的有效性。具体而言，(Scheirer等人，2013)提出了一对多集支持向量机(1-vs-Set SVM)，通过解决一个双平面优化问题而非经典二分类线性分类器的半空间问题来管理开放集风险。该论文强调，除了限制已知类别(ID)风险外，开放集空间也应该有界。

Classification-Based Methods Early works focused on logits redistribution using the compact abating probability (CAP) (Scheirer et al., 2014) and extreme value theory (EVT) (Smith, 1990; Castillo, 2012; Jain et al., 2014). In particular, classic probabilistic models lack the consideration of open-set space. CAP explicitly models the probability of class membership abating from ID points to OOD points, and EVT focuses on modeling the tail distribution with extreme high/low values. In the context of deep learning, OpenMax (Bendale & Boult, 2016) first implements EVT for neural networks. OpenMax replaces the softmax layer with an OpenMax layer, which calibrates the logits with a per-class EVT probabilistic model such as Weibull distribution.

基于分类的方法 早期的工作集中于使用紧凑衰减概率(CAP)(Scheirer等人，2014)和极值理论(EVT)(Smith，1990；Castillo，2012；Jain等人，2014)进行对数几率(logits)重新分配。具体来说，经典概率模型缺乏对开放集空间的考虑。紧凑衰减概率(CAP)明确地对从已知类别(ID)点到未知类别(OOD)点的类别隶属概率衰减进行建模，而极值理论(EVT)则专注于对具有极高/极低值的尾部分布进行建模。在深度学习的背景下，OpenMax(Bendale & Boult，2016)首次将极值理论(EVT)应用于神经网络。OpenMax用OpenMax层取代了softmax层，该层使用基于每个类别的极值理论概率模型(如威布尔分布)来校准对数几率(logits)。

To bypass open-set risk construction, some works attained good results without EVT. For example, some work uses a membership loss to encourage high activations for known classes, and uses large-scale external datasets to learn globally negative filters that can reduce the activations of novel images (Perera & Patel, 2019). Apart from explicitly forcing discrepancy between known/unknown classes, other methods extract stronger features through an auxiliary task of transformation classification (Perera et al., 2020), or mutual information maximization between the input image and its latent features (Sun et al., 2021a), etc..

为了绕过开放集风险构建，一些工作在不使用极值理论(EVT)的情况下取得了良好的效果。例如，一些工作使用隶属损失来鼓励已知类别的高激活值，并使用大规模外部数据集来学习全局负滤波器，以降低新图像的激活值(Perera & Patel，2019)。除了明确强制已知/未知类别之间的差异外，其他方法通过变换分类的辅助任务(Perera等人，2020)或输入图像与其潜在特征之间的互信息最大化(Sun等人，2021a)等方式提取更强的特征。

Image generation techniques have been utilized to synthesize unknown samples from known classes, which helps distinguish between known vs. unknown samples (Ge et al., 2017; Neal et al., 2018; Zhou et al., 2021a; Kong & Ramanan, 2021). While these methods are promising on simple images such as handwritten characters, they do not scale to complex natural image datasets due to the difficulty in generating high-quality images in high-dimensional space. Another solution is to successively choose random categories in the training set and treat them as unknown, which helps the classifier to shrink the boundaries and gain the ability to identify unknown classes (Geng & Chen, 2020; Jang & Kim, 2020). Moreover, Schlachter et al. (2019) splits the training data into typical and atypical subsets, which also helps learn compact classification boundaries.

图像生成技术已被用于从已知类别合成未知样本，这有助于区分已知和未知样本(Ge等人，2017；Neal等人，2018；Zhou等人，2021a；Kong & Ramanan，2021)。虽然这些方法在手写字符等简单图像上很有前景，但由于在高维空间中生成高质量图像的困难，它们无法扩展到复杂的自然图像数据集。另一种解决方案是在训练集中依次选择随机类别并将其视为未知类别，这有助于分类器缩小边界并获得识别未知类别的能力(Geng & Chen，2020；Jang & Kim，2020)。此外，Schlachter等人(2019)将训练数据分为典型和非典型子集，这也有助于学习紧凑的分类边界。

Distance-Based Methods Distance-based methods for OSR require the prototypes to be class-conditional, which allows maintaining the ID classification performance. Category-based clustering and prototyping are performed based on the visual features extracted from the classifiers. OOD samples can be detected by computing the distance w.r.t. clusters (Masana et al., 2018; Shu et al., 2020). Some methods also leveraged contrastive learning to learn more compact clusters for known classes (Liu et al., 2020a; Chen et al., 2020a), which enlarge the distance between ID and OOD. CROSR (Yoshihashi et al., 2019) enhances the features by concatenating visual embeddings from both the classifier and reconstruction model for distance computation in the extended feature space. Besides using features from classifiers, GMVAE (Cao et al., 2020) extracts features using a reconstruction VAE, and models the embeddings of the training set as a Gaussian mixture with multiple centroids for the following distance-based operations. Classifiers using nearest neighbors are also adapted for OSR problem (Júnior et al., 2017). By storing the training samples, the nearest neighbor distance ratio is used for identifying unknown samples in testing.

基于距离的方法 开放集识别(OSR)的基于距离的方法要求原型具有类别条件性，这有助于保持已知类别(ID)的分类性能。基于从分类器中提取的视觉特征进行基于类别的聚类和原型构建。可以通过计算与聚类的距离来检测未知类别(OOD)样本(Masana等人，2018；Shu等人，2020)。一些方法还利用对比学习为已知类别学习更紧凑的聚类(Liu等人，2020a；Chen等人，2020a)，这扩大了已知类别(ID)和未知类别(OOD)之间的距离。CROSR(Yoshihashi等人，2019)通过连接来自分类器和重建模型的视觉嵌入来增强特征，以便在扩展特征空间中进行距离计算。除了使用分类器的特征外，GMVAE(Cao等人，2020)使用重建变分自编码器(VAE)提取特征，并将训练集的嵌入建模为具有多个质心的高斯混合模型，以便进行后续的基于距离的操作。使用最近邻的分类器也适用于开放集识别(OSR)问题(Júnior等人，2017)。通过存储训练样本，最近邻距离比用于在测试中识别未知样本。

Reconstruction-Based Methods With similar motivations as Sect. 3.4, reconstruction-based methods expect different reconstruction behavior for ID vs. OOD samples. The difference can be captured in the latent feature space or the pixel space of reconstructed images.

基于重建的方法 与3.4节的动机类似，基于重建的方法期望已知类别(ID)和未知类别(OOD)样本具有不同的重建行为。这种差异可以在潜在特征空间或重建图像的像素空间中被捕捉到。

By sparsely encoding images from the known classes, open-set samples can be identified based on their dense representation. Techniques such as sparsity concentration index (Zhang & Patel, 2016) and kernel null space methods (Bodesheim et al., 2013; Liu et al., 2017) are used for sparse encoding.

通过对已知类别的图像进行稀疏编码，可以根据开放集样本的密集表示来识别它们。诸如稀疏集中指数(Zhang & Patel，2016)和核零空间方法(Bodesheim等人，2013；Liu等人，2017)等技术被用于稀疏编码。

By fixing the visual encoder obtained from standard multi-class training to maintain ID classification performance, C2AE trains a decoder conditioned on label vectors and estimates the reconstructed images using EVT to distinguish unknown classes (Oza & Patel, 2019). Subsequent works use conditional Gaussian distributions by forcing different latent features to approximate class-wise Gaussian models, which enables classifying known samples as well as rejecting unknown samples (Sun et al., 2020). Other methods generate counterfactual images, which help the model focus more on semantics (Yue et al., 2021). Adversarial defense is also considered in Shao et al. (2020) to enhance model robustness.

通过固定从标准多类训练中获得的视觉编码器以保持身份(ID)分类性能，C2AE训练一个以标签向量为条件的解码器，并使用极值理论(EVT)估计重建图像，以区分未知类别(Oza & Patel，2019)。后续工作通过迫使不同的潜在特征逼近按类别划分的高斯模型来使用条件高斯分布，这使得模型既能对已知样本进行分类，又能拒绝未知样本(Sun等人，2020)。其他方法生成反事实图像，这有助于模型更多地关注语义(Yue等人，2021)。Shao等人(2020)还考虑了对抗防御，以增强模型的鲁棒性。

Discussion Although there is not an independent section for density-based methods, these methods can play an important role and are fused as a critical step in some classification-based methods such as OpenMax (Bendale & Boult, 2016). The density estimation on visual embeddings can effectively detect unknown classes without influencing the classification performance. A hybrid model also uses a flow-based density estimator to detect unknown samples (Zhang et al., 2020).

讨论 尽管没有独立的章节介绍基于密度的方法，但这些方法可以发挥重要作用，并且在一些基于分类的方法(如OpenMax(Bendale & Boult，2016))中作为关键步骤被融合。对视觉嵌入进行密度估计可以在不影响分类性能的情况下有效检测未知类别。一个混合模型还使用基于流的密度估计器来检测未知样本(Zhang等人，2020)。

As introduced in Sect.2.4, the general goal of OSR and OOD detection is aligned, that is to detect semantic shift from the training data. Therefore, we encourage methods from these two field should learn more from each other. For example, apart from novel methods, OSR research also shows that a good classifier (Vaze et al., 2022b) in the close-set is critical to OSR performance, which should also applicable to OOD detection tasks.

正如第2.4节所介绍的，开放集识别(OSR)和分布外(OOD)检测的总体目标是一致的，即检测与训练数据的语义偏移。因此，我们鼓励这两个领域的方法相互学习。例如，除了新颖的方法之外，OSR研究还表明，封闭集内的优秀分类器(Vaze等人，2022b)对OSR性能至关重要，这也应该适用于OOD检测任务。

### 4.2 Anomaly Detection and Novelty Detection

### 4.2 异常检测和新奇性检测

This section reviews methodologies for sensory and semantic AD and one-class ND. Notice that multi-classes ND is covered in the previous. Given homogeneous in-distribution data, approaches include density-based, reconstruction-based, distance-based, and hybrid methods. We also discuss theoretical works.

本节回顾了感官和语义异常检测(AD)以及单类新奇性检测(ND)的方法。请注意，多类ND已在前面介绍过。对于同质的分布内数据，方法包括基于密度的方法、基于重建的方法、基于距离的方法和混合方法。我们还将讨论理论方面的工作。

Density-Based Methods Density-based methods model normal data (ID) distributions, assuming anomalous test data has low likelihood while normal data has higher likelihood. Techniques include classic density estimation, density estimation with deep generative models, energy-based models, and frequency-based methods.

基于密度的方法 基于密度的方法对正常数据(分布内，ID)的分布进行建模，假设异常测试数据的似然较低，而正常数据的似然较高。技术包括经典密度估计、使用深度生成模型的密度估计、基于能量的模型和基于频率的方法。

Parametric density estimation assumes pre-defined distributions (Danuser & Stricker, 1998). Methods involve multivariate Gaussian distribution (De Maesschalck et al., 2000; Leys et al., 2018), mixed Gaussian distribution (Red-ner & Walker, 1984; Eskin, 2000), and Poisson distribution (Turcotte et al., 2016). Non-parametric density estimation handles more complex scenarios (Izenman, 1991) with histograms (Van Ryzin, 1973; Xie et al., 2012; Kind et al., 2009; Goldstein & Dengel, 2012) and kernel density estimation (KDE) (Parzen, 1962; Desforges et al., 1998; Hu et al., 2018).

参数密度估计假设数据符合预定义的分布(Danuser & Stricker，1998)。方法包括多元高斯分布(De Maesschalck等人，2000；Leys等人，2018)、混合高斯分布(Redner & Walker，1984；Eskin，2000)和泊松分布(Turcotte等人，2016)。非参数密度估计使用直方图(Van Ryzin，1973；Xie等人，2012；Kind等人，2009；Goldstein & Dengel，2012)和核密度估计(KDE)(Parzen，1962；Desforges等人，1998；Hu等人，2018)来处理更复杂的场景(Izenman，1991)。

Neural networks generate high-quality features to enhance classic density estimation. Techniques include autoencoder (AE) (Kramer, 1991) and variational autoencoder (VAE) (Kingma & Welling, 2013)-based models, generative adversarial networks (GANs) (Goodfellow et al., 2014), flow-based models (Rezende & Mohamed, 2015; Kobyzev et al., 2020), and representation enhancement strategies.

神经网络生成高质量的特征以增强经典密度估计。技术包括基于自编码器(AE)(Kramer，1991)和变分自编码器(VAE)(Kingma & Welling，2013)的模型、生成对抗网络(GANs)(Goodfellow等人，2014)、基于流的模型(Rezende & Mohamed，2015；Kobyzev等人，2020)以及表示增强策略。

EBMs use scalar energy scores to express probability density (Ngiam et al., 2011) and provide a solution for AD (Zhai et al., 2016). Training EBMs can be computationally expensive, but score matching (Hyvärinen & Dayan, 2005) and stochastic gradient Langevin dynamics (Welling & Teh, 2011) enable efficient training.

基于能量的模型(EBMs)使用标量能量分数来表示概率密度(Ngiam等人，2011)，并为异常检测(AD)提供了一种解决方案(Zhai等人，2016)。训练EBMs的计算成本可能很高，但得分匹配(Hyvärinen & Dayan，2005)和随机梯度朗之万动力学(Welling & Teh，2011)可以实现高效训练。

Frequency domain analysis for AD includes methods like CNN kernel smoothing (Wang et al., 2020), spectrum-oriented data augmentation (Chen et al., 2021a), and phase spectrum targeting (Liu et al., 2021). These mainly focus on sensory AD.

用于异常检测的频域分析方法包括卷积神经网络(CNN)核平滑(Wang等人，2020)、面向频谱的数据增强(Chen等人，2021a)和相位谱靶向(Liu等人，2021)等。这些方法主要关注感官异常检测。

Reconstruction-Based Methods These AD methods leverage model performance differences on normal and abnormal data in feature space or by reconstruction error.

基于重建的方法 这些异常检测方法利用模型在特征空间中对正常和异常数据的性能差异，或者通过重建误差来进行检测。

Sparse reconstruction assumes normal samples can be accurately reconstructed using a limited set of basis functions, while anomalies have larger reconstruction costs and a dense representation (Adler et al., 2015; Li et al., 2017a; Mo et al.,2013). Techniques include ${L}_{1}$ norm-based kernel PCA (Xiao et al., 2013) and low-rank embedded networks (Jiang et al., 2021b).

稀疏重建假设正常样本可以使用有限的一组基函数进行准确重建，而异常样本的重建成本更高，并且具有密集表示(Adler等人，2015；Li等人，2017a；Mo等人，2013)。技术包括基于${L}_{1}$范数的核主成分分析(PCA)(Xiao等人，2013)和低秩嵌入网络(Jiang等人，2021b)。

Reconstruction-error methods assume a model trained on normal data will produce better reconstructions for normal test samples than anomalies. Deep models include AEs (Chen et al., 2018), VAEs (An & Cho, 2015), GANs (Zenati et al., 2018), and U-Net (Liu et al., 2018b).

重建误差方法假定，在正常数据上训练的模型对正常测试样本的重建效果会比对异常样本的更好。深度模型包括自动编码器(AE，Chen等人，2018)、变分自动编码器(VAE，An和Cho，2015)、生成对抗网络(GAN，Zenati等人，2018)和U型网络(U-Net，Liu等人，2018b)。

AE/VAE-based models combine reconstruction-error with AE/VAE models (Chen et al., 2018; An & Cho, 2015) and use strategies like reconstructing by memorized normality (Gong et al., 2019; Park et al., 2020), adapting model architectures (Lai et al., 2020), and partial/conditional reconstruction (Yan et al., 2021; Pidhorskyi et al., 2018; Nguyen et al., 2019). In semi-supervised AD, CoRA (Tian et al., 2019) trains two AEs on inliers and outliers, using reconstruction errors for anomaly detection. Reconstruction-error methods using GANs leverage the discriminator to calculate reconstruction error for anomaly detection (Zenati et al., 2018). Variants like denoising GANs (Sabokrou et al., 2018), class-conditional GANs (Perera et al., 2019), and ensembling (Han et al., 2020) further improve performance. Gradient-based methods observe different patterns on training gradient between normalities and anomalies in a reconstruction task, using gradient-based representation to characterize anomalies (Kwon et al., 2020).

基于自动编码器/变分自动编码器(AE/VAE)的模型将重建误差与AE/VAE模型相结合(Chen等人，2018；An和Cho，2015)，并采用诸如通过记忆正常模式进行重建(Gong等人，2019；Park等人，2020)、调整模型架构(Lai等人，2020)以及部分/条件重建(Yan等人，2021；Pidhorskyi等人，2018；Nguyen等人，2019)等策略。在半监督异常检测(AD)中，对比重建自动编码器(CoRA，Tian等人，2019)在正常样本和异常样本上训练两个自动编码器，利用重建误差进行异常检测。使用生成对抗网络的重建误差方法利用判别器计算重建误差以进行异常检测(Zenati等人，2018)。去噪生成对抗网络(Sabokrou等人，2018)、类别条件生成对抗网络(Perera等人，2019)和集成方法(Han等人，2020)等变体进一步提高了性能。基于梯度的方法在重建任务中观察正常样本和异常样本在训练梯度上的不同模式，利用基于梯度的表示来表征异常(Kwon等人，2020)。

Distance-Based Methods These methods detect anomalies by calculating the distance between samples and prototypes (Wettschereck, 1994), requiring training data in memory. Methods include K-nearest Neighbors (Tian et al., 2014) and prototype-based methods (Münz et al., 2007; Syarif et al., 2012).

基于距离的方法 这些方法通过计算样本与原型之间的距离来检测异常(Wettschereck，1994)，需要在内存中存储训练数据。方法包括K近邻法(Tian等人，2014)和基于原型的方法(Münz等人，2007；Syarif等人，2012)。

Classification-Based Methods AD and one-class ND are often formulated as unsupervised learning problems, but there are some supervised and semi-supervised methods as well. One-class classification (OCC) directly learns a decision boundary that corresponds to a desired density level set of the normal data distribution (Tax, 2002). DeepSVDD (Ruff et al., 2018) introduced classic OCC to the deep learning community. PU learning (Zhang & Zuo, 2008; Bekker & Davis, 2020; Jaskie & Spanias, 2019; Ruff et al., 2020) is proposed for the semi-supervised AD setting where unlabeled data is available in addition to the normal data. Self-supervised learning methods use pretext tasks such as contrastive learning (Tack et al., 2020), image transformation prediction (Bergman & Hoshen, 2020; Golan & El-Yaniv, 2018), and future frame prediction (Georgescu et al., 2021), where anomalies are more likely to make mistakes on the designed task.

基于分类的方法 异常检测和单类新奇检测(ND)通常被表述为无监督学习问题，但也有一些有监督和半监督方法。单类分类(OCC)直接学习一个决策边界，该边界对应于正常数据分布的期望密度水平集(Tax，2002)。深度支持向量数据描述(DeepSVDD，Ruff等人，2018)将经典的单类分类引入到深度学习领域。正例和无标签学习(PU学习，Zhang和Zuo，2008；Bekker和Davis，2020；Jaskie和Spanias，2019；Ruff等人，2020)是为半监督异常检测场景提出的，在该场景中，除了正常数据外还有无标签数据。自监督学习方法使用前置任务，如对比学习(Tack等人，2020)、图像变换预测(Bergman和Hoshen，2020；Golan和El-Yaniv，2018)和未来帧预测(Georgescu等人，2021)，在这些任务中，异常样本更有可能在设计的任务上出错。

One-class classification learns a decision boundary that corresponds to a desired density level set of the normal data distribution, which DeepSVDD (Ruff et al., 2018) introduced to the deep learning community. PU learning (Zhang & Zuo, 2008; Bekker & Davis, 2020; Jaskie & Spanias, 2019; Ruff et al., 2020) is a popular method for the semi-supervised AD setting. Self-supervised learning methods use pretext tasks such as contrastive learning (Tack et al., 2020), image transformation prediction (Bergman & Hoshen, 2020; Golan & El-Yaniv, 2018), and future frame prediction (Georgescu et al., 2021), where anomalies are more likely to make mistakes on the designed task.

单类分类学习一个决策边界，该边界对应于正常数据分布的期望密度水平集，深度支持向量数据描述(DeepSVDD，Ruff等人，2018)将其引入到深度学习领域。正例和无标签学习(PU学习，Zhang和Zuo，2008；Bekker和Davis，2020；Jaskie和Spanias，2019；Ruff等人，2020)是半监督异常检测场景中一种流行的方法。自监督学习方法使用前置任务，如对比学习(Tack等人，2020)、图像变换预测(Bergman和Hoshen，2020；Golan和El-Yaniv，2018)和未来帧预测(Georgescu等人，2021)，在这些任务中，异常样本更有可能在设计的任务上出错。

Discussion: Sensory vs Semantic AD Sensory and semantic AD approaches assume the normal data as homogeneous, despite the presence of multiple categories within it. While semantic AD methods are mainly applicable to sensory AD problems, the latter can benefit from techniques that focus on lower-level features (e.g., flow-based and hidden feature-based), local representations, and frequency-based methods. Although current OOD detection tasks mostly focus on semantic shift, the method for Sensory AD might be especially helpful for far OOD detection, like ImageNet vs Texture dataset.

讨论:感官异常检测与语义异常检测 感官和语义异常检测方法都假定正常数据是同质的，尽管其中存在多个类别。虽然语义异常检测方法主要适用于感官异常检测问题，但感官异常检测可以从专注于低级特征(如基于流和基于隐藏特征的方法)、局部表示和基于频率的方法等技术中受益。尽管当前的分布外(OOD)检测任务大多关注语义偏移，但感官异常检测方法可能对远距离分布外检测特别有用，如图像网(ImageNet)与纹理数据集的对比。

Discussion: Theoretical Analysis In addition to algorithmic development, theoretical analysis of AD and one-class ND has also been provided in some works. For instance, (Liu et al., 2018a) constructs a clean set of ID and a mixed set of ID/OOD with identical sample sizes, achieving a PAC-style finite sample guarantee for detecting a certain portion of anomalies with the minimum number of false alarms. All these works could be beneficial to the theoretical works of OOD detection.

讨论:理论分析 除了算法开发，一些研究还对异常检测和单类新奇检测进行了理论分析。例如，(Liu等人，2018a)构建了一个样本大小相同的干净的分布内(ID)集合和一个混合的ID/OOD集合，为以最少的误报检测出一定比例的异常提供了PAC风格的有限样本保证。所有这些研究都可能对分布外检测的理论研究有益。

### 4.3 Outlier Detection

### 4.3 离群值检测

Outlier detection (OD) observes all samples to identify significant deviations from the majority distribution. Though mostly studied in data mining, deep learning-based OD methods are used for data cleaning in open-set noisy data (Wang et al., 2018; Chen & Gupta, 2015) and open-set semi-supervised learning (Cao et al., 2021).

离群值检测(Outlier Detection，OD)会观察所有样本，以识别与多数分布存在显著偏差的样本。尽管离群值检测大多在数据挖掘领域进行研究，但基于深度学习的离群值检测方法可用于开放集噪声数据的数据清洗(Wang等人，2018；Chen和Gupta，2015)以及开放集半监督学习(Cao等人，2021)。

Density-Based Methods OD methods include Gaussian distribution (Altman & Bland, 2005; Leys et al., 2013), Mahalanobis distance (De Maesschalck et al., 2000), Gaussian mixtures (Yang et al., 2009), and Local outlier factor (LOF) (Breunig et al., 2000). RANSAC (Fischler & Bolles, 1981) estimates parameters for a mathematical model. Classic density methods and NN-based density methods can also be applied.

基于密度的方法 离群值检测方法包括高斯分布(Altman和Bland，2005；Leys等人，2013)、马氏距离(De Maesschalck等人，2000)、高斯混合模型(Yang等人，2009)以及局部离群因子(Local Outlier Factor，LOF)(Breunig等人，2000)。随机抽样一致性算法(Random Sample Consensus，RANSAC)(Fischler和Bolles，1981)用于估计数学模型的参数。经典密度方法和基于神经网络的密度方法也可以应用。

Distance-Based Methods Outliers can be detected by neighbor counting (Sugiyama & Borgwardt, 2013; Orair et al., 2010), DBSCAN clustering (Ester et al., 1996), and graph-based methods (Hautamaki et al., 2004; Muhlenbach et al., 2004; Liu et al., 2010; Akoglu et al., 2015; Noble & Cook, 2003; Kou et al., 2007; Mingqiang et al., 2012; Wu et al., 2021; Yang et al., 2020a).

基于距离的方法 可以通过邻居计数(Sugiyama和Borgwardt，2013；Orair等人，2010)、基于密度的空间聚类应用(Density-Based Spatial Clustering of Applications with Noise，DBSCAN)(Ester等人，1996)以及基于图的方法(Hautamaki等人，2004；Muhlenbach等人，2004；Liu等人，2010；Akoglu等人，2015；Noble和Cook，2003；Kou等人，2007；Mingqiang等人，2012；Wu等人，2021；Yang等人，2020a)来检测离群值。

Classification-Based Methods AD methods like Isolation Forest (Liu et al., 2008) and OC-SVM (Tax, 2002; Ruff et al., 2018) can be applied to OD. Deep learning models can identify outliers (Li et al., 2017). Techniques for robustness and feature generalizability include ensembling (Nguyen et al., 2020), co-training (Han et al., 2018), and distillation (Li et al., 2017; Yang et al., 2020b).

基于分类的方法 像孤立森林(Isolation Forest，Liu等人，2008)和单类支持向量机(One-Class Support Vector Machine，OC - SVM)(Tax，2002；Ruff等人，2018)等异常检测(Anomaly Detection，AD)方法可以应用于离群值检测。深度学习模型可以识别离群值(Li等人，2017)。提高鲁棒性和特征泛化能力的技术包括集成学习(Nguyen等人，2020)、协同训练(Han等人，2018)和知识蒸馏(Li等人，2017；Yang等人，2020b)。

Discussion OD techniques are valuable for open-set semi-supervised learning, learning with open-set noisy labels, and novelty discovery. All these solutions can be applied especially when OOD samples are exposed during the training stage (Yang et al., 2021).

讨论 离群值检测技术对于开放集半监督学习、带有开放集噪声标签的学习以及新奇事物发现具有重要价值。当在训练阶段出现分布外(Out-of-Distribution，OOD)样本时，所有这些解决方案都可以应用(Yang等人，2021)。

## 5 Benchmarks and Experiments

## 5 基准测试与实验

In this section, we report the fair comparison of methodologies that from different categories on the CIFAR (Krizhevsky et al., 2009) benchmark. The report originated from OpenOOD benchmarks (Yang et al., 2022a). We selected several popular AD methods, OOD detection methods (post-hot, training-required, and extra-data-required), and model robustness methods.

在本节中，我们报告了在CIFAR(Krizhevsky等人，2009)基准测试上不同类别的方法的公平比较结果。该报告源自OpenOOD基准测试(Yang等人，2022a)。我们选择了几种流行的异常检测方法、分布外检测方法(事后处理、需要训练和需要额外数据的方法)以及模型鲁棒性方法。

### 5.1 Benchmarks and Metrics

### 5.1 基准测试与指标

The common practice for building OOD detection benchmarks is to consider an entire dataset as in-distribution (ID), and then collect several datasets that are disconnected from any ID categories as OOD datasets. In this part, we show the results from two popular OOD benchmarks with ID datasets of CIFAR-10 (Krizhevsky et al., 2009), CIFAR- 100 (Krizhevsky et al., 2009) from OpenOOD (c.f.Fig. 4), with each benchmark designing near-OOD and far-OOD datasets to facilitate detailed analysis of the OOD detectors. Near-OOD datasets only have semantic shift compared with ID datasets, while far-OOD further contains obvious covariate (domain) shift.

构建分布外检测基准测试的常见做法是将整个数据集视为分布内(In - Distribution，ID)数据集，然后收集几个与任何分布内类别无关的数据集作为分布外数据集。在这部分，我们展示了来自两个流行的分布外基准测试的结果，这些基准测试使用OpenOOD中的CIFAR - 10(Krizhevsky等人，2009)和CIFAR - 100(Krizhevsky等人，2009)作为分布内数据集(参见图4)，每个基准测试都设计了近分布外和远分布外数据集，以便对分布外检测器进行详细分析。近分布外数据集与分布内数据集相比仅存在语义偏移，而远分布外数据集还包含明显的协变量(领域)偏移。

CIFAR-10 CIFAR-10 (Krizhevsky et al., 2009) is a 10-class dataset for general object classification, which contains ${50}\mathrm{k}$ training images and ${10}\mathrm{k}$ test images. As for the OOD dataset, we construct near-OOD with CIFAR- 100 (Krizhevsky et al., 2009) and TinyImageNet (Krizhevsky et al., 2012). Notice that 1,207 images are removed from TinyImageNet since they actually belong to CIFAR-10 classes (Yang et al., 2021). Far-OOD is built by MNIST (LeCun & Cortes, 2005), SVHN (Netzer et al., 2011), Texture (Kyl-berg, 2011), and Places365 (Zhou et al., 2017) with 1,305 images are removed due to semantic overlaps.

CIFAR - 10 CIFAR - 10(Krizhevsky等人，2009)是一个用于通用目标分类的10类数据集，包含${50}\mathrm{k}$张训练图像和${10}\mathrm{k}$张测试图像。至于分布外数据集，我们使用CIFAR - 100(Krizhevsky等人，2009)和TinyImageNet(Krizhevsky等人，2012)构建近分布外数据集。请注意，由于TinyImageNet中有1207张图像实际上属于CIFAR - 10类别，因此将其移除(Yang等人，2021)。远分布外数据集由MNIST(LeCun和Cortes，2005)、街景门牌号(Street View House Numbers，SVHN)(Netzer等人，2011)、纹理数据集(Texture，Kylberg，2011)和Places365(Zhou等人，2017)构建，由于语义重叠移除了1305张图像。

CIFAR-100 Another OOD detection benchmark uses CIFAR-100 (Krizhevsky et al., 2009) as an in-distribution, which contains ${50}\mathrm{k}$ training images and ${10}\mathrm{k}$ test images with 100 classes. For OOD dataset, near-OOD includes CIFAR- 10 (Krizhevsky et al., 2009) and TinyImageNet (Torralba et al., 2008). Similar to the CIFAR-10 benchmark, 2,502 images are removed from TinyImageNet due to the overlapping semantics with CIFAR-100 classes (Yang et al., 2021). Far-OOD consists of MNIST (LeCun & Cortes, 2005), SVHN (Netzer et al., 2011), Texture (Kylberg, 2011), and Places365 (Zhou et al., 2017) with 1,305 images removed.

CIFAR - 100 另一个离群分布(OOD)检测基准使用 CIFAR - 100(克里兹夫斯基等人，2009 年)作为分布内数据集，它包含 ${50}\mathrm{k}$ 张训练图像和 ${10}\mathrm{k}$ 张测试图像，共 100 个类别。对于 OOD 数据集，近 OOD 数据集包括 CIFAR - 10(克里兹夫斯基等人，2009 年)和 TinyImageNet(托拉尔巴等人，2008 年)。与 CIFAR - 10 基准类似，由于与 CIFAR - 100 类别存在语义重叠，从 TinyImageNet 中移除了 2502 张图像(杨等人，2021 年)。远 OOD 数据集由 MNIST(勒昆和科尔特斯，2005 年)、SVHN(内策尔等人，2011 年)、Texture(基尔贝里，2011 年)和 Places365(周等人，2017 年)组成，移除了 1305 张图像。

Metrics We only report the AUROC scores, which measure the area under the Receiver Operating Characteristic (ROC) curve.

指标 我们仅报告受试者工作特征曲线下面积(AUROC)分数，该分数衡量的是受试者工作特征(ROC)曲线下的面积。

![0195d2b3-e92e-7da1-8c3c-990b96d6d818_17_151_165_696_327_0.jpg](images/0195d2b3-e92e-7da1-8c3c-990b96d6d818_17_151_165_696_327_0.jpg)

Fig. 4 The illustration of CIFAR-10 benchmark that is used in Sect. 5. The CIFAR-100 benchmark simply swaps the position of CIFAR-10 and CIFAR-100 in the figure

图 4 第 5 节中使用的 CIFAR - 10 基准的示意图。CIFAR - 100 基准只需在图中交换 CIFAR - 10 和 CIFAR - 100 的位置。

### 5.2 Experimental Setup

### 5.2 实验设置

To ensure a fair comparison across methods that originate from different fields and have different implementations, unified settings with common hyperparameters and architecture choices are implemented. ResNet-18 (He et al., 2016) is used as the backbone network. If the implemented method requires training, the widely accepted setting with SGD optimizer, a learning rate of 0.1 , momentum of 0.9 , and weight decay of 0.0005 for 100 epochs, is used. For further details, please refer to OpenOOD (Yang et al., 2022a; Zhang et al., 2023c).

为确保对来自不同领域且实现方式不同的方法进行公平比较，采用了具有常见超参数和架构选择的统一设置。使用 ResNet - 18(何等人，2016 年)作为骨干网络。如果所实现的方法需要训练，则采用广泛认可的设置，即使用随机梯度下降(SGD)优化器，学习率为 0.1，动量为 0.9，权重衰减为 0.0005，训练 100 个周期。更多详细信息，请参考 OpenOOD(杨等人，2022a；张等人，2023c)。

### 5.3 Experimental Results and Findings

### 5.3 实验结果与发现

Data Augmentation Methods are the Most Effective We split Fig. 5 into several sections based on the method type. Generally, the most effective methods are those that use model uncertainty works with data augmentation techniques. This group mainly includes simple and effective methods such as preprocessing methods like PixMix (Hendrycks et al., 2022c) and CutMix (Yun et al., 2019). PixMix achieves 93.1% on Near-OOD in CIFAR-10, the best performance among all the methods in this benchmark. These methods also perform well in most of the other benchmarks. Similarly, other simple and effective methods to enhance model uncertainty estimation such as Ensemble (Dietterich, 2000) and Mixup (Thulasidasan et al., 2019) also demonstrate excellent performance.

数据增强方法最为有效 我们根据方法类型将图 5 分为几个部分。一般来说，最有效的方法是那些结合了模型不确定性和数据增强技术的方法。这一类主要包括简单有效的方法，如预处理方法，如 PixMix(亨德里克斯等人，2022c)和 CutMix(尹等人，2019)。PixMix 在 CIFAR - 10 的近 OOD 数据集上达到了 93.1% 的准确率，是该基准中所有方法中表现最好的。这些方法在其他大多数基准中也表现良好。同样，其他增强模型不确定性估计的简单有效方法，如集成学习(迪特里希，2000 年)和 Mixup(图拉萨迪桑等人，2019 年)也表现出色。

Extra Data Seems Not Necessary? Comparing UDG (Yang et al., 2021) (the best from the extra-data part) with KNN (Sun et al., 2022) (the best from the extra data-free part), we found that UDG's advantage is only in CIFAR-10 near-OOD, which is not satisfactory since a large quantity of real outlier data is required. In this benchmark, we use the entire TinyImageNet training set as the extra data, the choice of training outliers could greatly affect the performance of OOD detectors, so further exploration is needed.

额外数据似乎并非必要？ 将 UDG(杨等人，2021 年)(额外数据部分表现最好的方法)与 KNN(孙等人，2022 年)(无额外数据部分表现最好的方法)进行比较，我们发现 UDG 仅在 CIFAR - 10 近 OOD 数据集上有优势，考虑到需要大量真实的离群数据，这并不令人满意。在这个基准中，我们使用整个 TinyImageNet 训练集作为额外数据，训练离群数据的选择可能会极大地影响 OOD 检测器的性能，因此需要进一步探索。

Post-Hoc Methods Outperform Training in General Surprisingly, methods that require training do not necessarily perform better. In general, inference-only methods outperform trained methods. Nevertheless, the trained models can be generally used in conjunction with post-hoc methods, which could potentially further increase their performance.

事后方法总体上优于训练方法 令人惊讶的是，需要训练的方法并不一定表现更好。一般来说，仅推理方法的表现优于经过训练的方法。然而，经过训练的模型通常可以与事后方法结合使用，这有可能进一步提高它们的性能。

Post-Hoc Methods are Making Progress In general, recent post-hoc methods have had better performance than previous methods since 2021, indicating that the direction of inference-only methods is promising and making progress. Recent methods show improvements in performance on more realistic datasets than previous methods, which focused on toy datasets. For example, the classic MDS performs well on MNIST but poorly on CIFAR-10 and CIFAR-100, while the recent KNN maintains good performance on MNIST, CIFAR-10, CIFAR-100, and also shows outstanding performance on ImageNet (Yang et al., 2022a).

事后方法正在取得进展 总体而言，自 2021 年以来，近期的事后方法比以前的方法表现更好，这表明仅推理方法的方向很有前景且正在取得进展。与之前专注于玩具数据集的方法相比，近期的方法在更真实的数据集上表现有所提升。例如，经典的 MDS 在 MNIST 数据集上表现良好，但在 CIFAR - 10 和 CIFAR - 100 数据集上表现不佳，而近期的 KNN 在 MNIST、CIFAR - 10、CIFAR - 100 数据集上保持了良好的性能，并且在 ImageNet 数据集上也表现出色(杨等人，2022a)。

Some AD Methods are Good at Far-OOD Although anomaly detection (AD) methods were originally designed to detect pixel-level appearance differences on the MVTec-AD dataset, they have shown potency in far-OOD detection, such as with DRAEM and CutPaste. Both methods achieved high performance on far-OOD detection, especially when using CIFAR-100 as the in-distribution dataset.

一些异常检测方法擅长远 OOD 检测 尽管异常检测(AD)方法最初是为了检测 MVTec - AD 数据集上的像素级外观差异而设计的，但它们在远 OOD 检测中显示出了潜力，如 DRAEM 和 CutPaste。这两种方法在远 OOD 检测中都取得了很高的性能，尤其是在使用 CIFAR - 100 作为分布内数据集时。

Explore OpenOOD for More Experimental Findings Accompanying our survey, we lead the development of OpenOOD (Yang et al., 2022a), an open-source codebase that provides a unified framework and benchmarking platform for conducting fair comparisons of various model architectures and OOD detection methods. OpenOOD is continuously updated and includes two comprehensive experimental reports (Yang et al., 2022a; Zhang et al., 2023c) that delve into extensive analysis and discovery. ${}^{2}$ We encourage readers to explore OpenOOD's resources for a deeper understanding of key aspects such as selecting model architectures, utilizing pre-trained models, practical applications, and detailed implementation insights.

探索OpenOOD以获取更多实验发现 伴随我们的综述，我们主导开发了OpenOOD(Yang等人，2022a)，这是一个开源代码库，为对各种模型架构和离群分布(OOD)检测方法进行公平比较提供了统一框架和基准测试平台。OpenOOD会持续更新，包含两份全面的实验报告(Yang等人，2022a；Zhang等人，2023c)，深入进行了广泛的分析和探索。${}^{2}$ 我们鼓励读者探索OpenOOD的资源，以更深入地了解关键方面，如选择模型架构、使用预训练模型、实际应用以及详细的实现见解。

### 5.4 Exclusion of Covariate-Shift Detection

### 5.4 排除协变量偏移检测

While OpenOOD does not include settings for pure covariate shift, this was a deliberate choice. The primary focus is on semantic shifts, which are fundamental to OOD detection. By not separately analyzing covariate shifts, we aim to avoid potential misinterpretations and prevent the overemphasis on covariate shift detection. Experiments in Yang et al. (2022b) highlight a key finding: most current OOD detectors are more sensitive to covariate shifts than semantic shifts and lead to the concept of "full-spectrum OOD detection", advocating for models that effectively generalize to handle covariate shifts while simultaneously detecting samples with semantic shifts. More experimental evaluations can be found in OpenOOD v1.5 (Zhang et al., 2023c).

虽然OpenOOD不包含纯协变量偏移的设置，但这是经过深思熟虑的选择。主要关注的是语义偏移，这是离群分布(OOD)检测的基础。不单独分析协变量偏移，我们旨在避免潜在的误解，并防止过度强调协变量偏移检测。Yang等人(2022b)的实验突出了一个关键发现:当前大多数离群分布(OOD)检测器对协变量偏移比对语义偏移更敏感，并引出了“全谱离群分布(OOD)检测”的概念，倡导能够有效泛化以处理协变量偏移，同时检测具有语义偏移样本的模型。更多实验评估可在OpenOOD v1.5(Zhang等人，2023c)中找到。

---

2 OpenOOD provides a https://zjysteven.github.io/

2 OpenOOD提供了一个https://zjysteven.github.io/

OpenOOD/leaderboard to track SOTAs.

OpenOOD/leaderboard来跟踪当前最优方法(SOTAs)。

---

![0195d2b3-e92e-7da1-8c3c-990b96d6d818_18_149_166_1448_387_0.jpg](images/0195d2b3-e92e-7da1-8c3c-990b96d6d818_18_149_166_1448_387_0.jpg)

Fig. 5 Comparison between different methodologies under generalized OOD detection framework on the CIFAR-10/100 benchmarks. Results are from OpenOOD (Yang et al., 2022a). Different colors denote the method categories. Each method reports near-OOD (left-bar) and far-

图5 在CIFAR - 10/100基准测试的广义离群分布(OOD)检测框架下不同方法的比较。结果来自OpenOOD(Yang等人，2022a)。不同颜色表示方法类别。每种方法报告了近离群分布(左柱)和远

OOD (right-bar) AUROC scores, as introduced in Sect.5.1. Method names in black originated for OOD detection, while in red are AD methods, blue for OSR methods, and pink for models from model uncertainty works (Color figure online)

离群分布(右柱)的曲线下面积(AUROC)分数，如第5.1节所述。黑色的方法名称源自离群分布(OOD)检测，红色的是异常检测(AD)方法，蓝色的是开放集识别(OSR)方法，粉色的是来自模型不确定性研究的模型(彩色图见在线版本)

## 6 Challenges and Future Directions

## 6 挑战与未来方向

In this section, we discuss the challenges and future directions of generalized OOD detection.

在本节中，我们讨论广义离群分布(OOD)检测的挑战和未来方向。

### 6.1 Challenges

### 6.1 挑战

a. Proper Evaluation and Benchmarking We hope this survey can clarify the distinctions and connections of various sub-tasks, and help future works properly identify the target problem and benchmarks within the framework. The mainstream OOD detection works primarily focus on detecting semantic shifts. Admittedly, the field of OOD detection can be very broad due to the diverse nature of distribution shifts. Such a broad OOD definition also leads to some challenges and concerns (Ahmed & Courville, 2020; Gan, 2021), which advocate a clear specification of OOD type in consideration (e.g., semantic OOD, adversarial OOD, etc.) so that proposed solutions can be more specialized. Besides, the motivation of detecting a certain distribution shift also requires clarification. While rejecting classifying samples with semantic shift is apparent, detecting sensory OOD should be specified to some meaningful scenarios to contextualize the necessity and practical relevance of the task.

a. 恰当的评估与基准设定 我们希望本综述能够厘清各种子任务之间的区别与联系，并帮助未来的研究在该框架内正确识别目标问题和基准。主流的分布外(OOD)检测工作主要聚焦于检测语义偏移。诚然，由于分布偏移的多样性，OOD检测领域可能非常广泛。如此宽泛的OOD定义也带来了一些挑战和问题(Ahmed & Courville, 2020; Gan, 2021)，这些研究主张明确考虑的OOD类型(例如，语义OOD、对抗性OOD等)，以便所提出的解决方案更具针对性。此外，检测某种分布偏移的动机也需要明确。虽然拒绝分类具有语义偏移的样本是显而易见的，但检测感官OOD应明确应用于某些有意义的场景，以说明该任务的必要性和实际相关性。

We also urge the community to carefully construct the benchmarks and evaluations. It is noticed that early work (Hendrycks & Gimpel, 2017) ignored the fact that some OOD datasets may contain images with ID categories, causing inaccurate performance evaluation. Fortunately, recent OOD detection works (Yang et al., 2021) have realized this flaw and pay special attention to removing ID classes from OOD samples to ensure proper evaluation.

我们还敦促学界谨慎构建基准和评估方法。值得注意的是，早期的研究(Hendrycks & Gimpel, 2017)忽略了一些OOD数据集可能包含属于分布内(ID)类别的图像这一事实，导致性能评估不准确。幸运的是，近期的OOD检测研究(Yang等人，2021)已经意识到了这一缺陷，并特别注意从OOD样本中去除ID类，以确保进行恰当的评估。

b. Outlier-Free OOD Detection The outlier exposure approach (Hendrycks et al., 2019b) imposes a strong assumption of the availability of OOD training data, which can be difficult to obtain in practice. Moreover, one needs to perform careful de-duplication to ensure that the outlier training data does not contain ID data. These restrictions may lead to inflexible solutions and prevent the adoption of methods in the real world. Going forward, a major challenge for the field is to devise outlier-free learning objectives that are less dependent on auxiliary outlier dataset.

b. 无离群点的OOD检测 离群点暴露方法(Hendrycks等人，2019b)强烈假设可以获取OOD训练数据，但在实际中这可能很难实现。此外，需要进行仔细的去重操作，以确保离群点训练数据不包含ID数据。这些限制可能导致解决方案缺乏灵活性，并阻碍这些方法在现实世界中的应用。未来，该领域的一个主要挑战是设计出较少依赖辅助离群点数据集的无离群点学习目标。

c. Tradeoff Between Classification and OOD Detection In OSR and OOD detection, it is important to achieve the dual objectives simultaneously: one for the ID task (e.g., image classification), another for the OOD detection task. For a shared network, an inherent trade-off may exist between the two tasks. Promising solutions should strive for both. These two tasks may or may not contradict each other, depending on the methodologies. For example, (Liu et al., 2019) advocated the integration of image classification and open-set recognition so that the model will possess the capability of discriminative recognition on known classes and sensitivity to novel classes at the same time. (Vaze et al., 2022b) also showed that the ability of detecting novel classes can be highly correlated with its accuracy on the closed-set classes. Yang et al. (2021) demonstrated that optimizing for the cluster compactness of ID classes may facilitate both improved classification and distance-based OOD detection performance. Such solutions may be more desirable than ND, which develops a binary OOD detector separately from the classification model, and requires deploying two models.

c. 分类与OOD检测之间的权衡 在开放集识别(OSR)和OOD检测中，同时实现两个目标非常重要:一个是针对ID任务(例如，图像分类)，另一个是针对OOD检测任务。对于一个共享网络，这两个任务之间可能存在内在的权衡。有前景的解决方案应该兼顾两者。这两个任务可能相互矛盾，也可能不矛盾，这取决于所采用的方法。例如，(Liu等人，2019)主张将图像分类和开放集识别相结合，使模型同时具备对已知类别的判别识别能力和对新类别的敏感性。(Vaze等人，2022b)也表明，检测新类别的能力可能与模型在封闭集类别上的准确性高度相关。Yang等人(2021)证明，优化ID类的聚类紧凑性可能有助于提高分类性能和基于距离的OOD检测性能。与单独开发一个二元OOD检测器并与分类模型分开部署的方法(ND)相比，这种解决方案可能更可取，因为ND需要部署两个模型。

d. Real-World Benchmarks and Evaluations Current methods in OOD detection are predominantly evaluated on smaller datasets like CIFAR. However, it has been observed that strategies effective on CIFAR may not perform as well on larger datasets like ImageNet, which has a more extensive semantic space. This discrepancy underscores the importance of conducting OOD detection evaluations in large-scale, real-world settings. Consequently, we recommend future research to focus on benchmarks based on ImageNet for OOD detection (Huang et al., 2021) and to explore large-scale Open Set Recognition (OSR) benchmarks (Vaze et al., 2022b) to fully test the effectiveness of these methods. Additionally, recent research (Bitterwolf et al., 2023) highlights the presence of erroneous samples in ImageNet OOD benchmarks and introduces the corrected NINCO dataset for more accurate evaluations. Furthermore, expanding the scope of benchmarks to encompass real-world scenarios, such as more realistic datasets (Koh et al., 2021; Cultrera et al., 2023), and object-level OOD detection (Du et al., 2022b, a), can provide valuable insights, especially in safety-critical applications like autonomous driving.

d. 现实世界的基准和评估 当前的OOD检测方法主要在像CIFAR这样的较小数据集上进行评估。然而，已经观察到，在CIFAR上有效的策略在像ImageNet这样具有更广泛语义空间的较大数据集上可能表现不佳。这种差异凸显了在大规模、现实世界环境中进行OOD检测评估的重要性。因此，我们建议未来的研究聚焦于基于ImageNet的OOD检测基准(Huang等人，2021)，并探索大规模开放集识别(OSR)基准(Vaze等人，2022b)，以全面测试这些方法的有效性。此外，近期的研究(Bitterwolf等人，2023)强调了ImageNet OOD基准中存在错误样本的问题，并引入了经过修正的NINCO数据集以进行更准确的评估。此外，将基准的范围扩大到涵盖现实世界场景，例如更真实的数据集(Koh等人，2021; Cultrera等人，2023)和对象级OOD检测(Du等人，2022b, a)，可以提供有价值的见解，特别是在自动驾驶等对安全至关重要的应用中。

### 6.2 Future Directions

### 6.2 未来方向

a. Methodologies Across Sub-tasks Due to the inherent connections among different sub-tasks, their solution space can be shared and inspired by each other. For example, the recent emerging density-based OOD detection research (c.f.Sect.3.2) can draw insights from the density-based AD methods (c.f.Sect.4.2) that have been around for a long time. b. OOD Detection & Generalization An open-world classifier should consider two tasks, i.e., being robust to covariate shift while being aware of the semantic shift. Existing works pursue these two goals independently. Recent work proposes a semantically coherent OOD detection framework (Yang et al., 2021) that encourages detecting semantic OOD samples while being robust to negligible covariate shift. Given the vague definition of OOD, (Ming et al., 2022c) proposed a formalization of OOD detection by explicitly taking into account the separation between invariant features (semantically related) and environmental features (non-semantic). The work highlighted that spurious environmental features in the training set can significantly impact OOD detection, especially when the semantic OOD data contains the spurious feature. Further, full-spectrum OOD detection (Yang et al., 2022b) highlights the effects of "covariate-shifted in-distribution", and show that most of the previous OOD detectors are unfortunately sensitive to covariate shift rather than semantic shift. This setting explicitly promotes the generalization ability of OOD detectors. Recent works on open long-tailed recognition (Liu et al., 2019), open compound domain adaptation (Liu et al., 2020c), open-set domain adaptation (Panareda Busto & Gall, 2017) and open-set domain generalization (Shu et al., 2021) consider the potential existence of open-class samples. Looking ahead, we envision great research opportunities on how OOD detection and OOD generalization can better enable each other (Liu et al., 2019), in terms of both algorithmic design and comprehensive performance evaluation. c. OOD Detection & Open-Set Noisy Labels Existing methods of learning from open-set noisy labels focus on suppressing the negative effects of noise (Wang et al., 2018; Li et al., 2021). However, the open-set noisy samples can be useful for outlier exposure (c.f. Sect. 3.1.2) (Wu et al., 2021) and potentially benefit OOD detection. With a similar idea, the setting of open-set semi-supervised learning can be promising for OOD detection. We believe the combination of OOD detection and the previous two fields can provide more insights and possibilities.

a. 跨子任务的方法学 由于不同子任务之间存在内在联系，它们的解决方案空间可以相互共享和启发。例如，最近新兴的基于密度的离群分布(OOD)检测研究(参见第3.2节)可以从已经存在很长时间的基于密度的异常检测(AD)方法(参见第4.2节)中汲取灵感。b. 离群分布检测与泛化 一个开放世界分类器应该考虑两个任务，即在对协变量偏移具有鲁棒性的同时，能够感知语义偏移。现有工作独立地追求这两个目标。最近的一项工作提出了一个语义连贯的离群分布检测框架(Yang等人，2021)，该框架鼓励在对可忽略的协变量偏移具有鲁棒性的同时检测语义离群分布样本。鉴于离群分布的定义模糊，(Ming等人，2022c)通过明确考虑不变特征(语义相关)和环境特征(非语义)之间的分离，对离群分布检测进行了形式化。该工作强调，训练集中的虚假环境特征会显著影响离群分布检测，特别是当语义离群分布数据包含虚假特征时。此外，全谱离群分布检测(Yang等人，2022b)强调了“协变量偏移的分布内”的影响，并表明大多数先前的离群分布检测器不幸地对协变量偏移而非语义偏移敏感。这种设置明确促进了离群分布检测器的泛化能力。最近关于开放长尾识别(Liu等人，2019)、开放复合域适应(Liu等人，2020c)、开放集域适应(Panareda Busto和Gall，2017)和开放集域泛化(Shu等人，2021)的工作考虑了开放类样本的潜在存在。展望未来，我们预见在离群分布检测和离群分布泛化如何在算法设计和综合性能评估方面更好地相互促进方面存在巨大的研究机会(Liu等人，2019)。c. 离群分布检测与开放集噪声标签 现有的从开放集噪声标签中学习的方法主要集中在抑制噪声的负面影响(Wang等人，2018；Li等人，2021)。然而，开放集噪声样本可用于离群点暴露(参见第3.1.2节)(Wu等人，2021)，并可能有利于离群分布检测。基于类似的想法，开放集半监督学习的设置可能对离群分布检测有很大的前景。我们相信离群分布检测与前两个领域的结合可以提供更多的见解和可能性。

e. OOD Detection Enhanced with World Knowledge The existing works utilizing foundation models, particularly multi-modal ones such as CLIP (Radford et al., 2021), have significantly enhanced OOD detection performance, as discussed in Sect.3.1.5. Starting from this, recent advancements have further focused on leveraging the extensive world knowledge encapsulated in Large Language Models (Dai et al., 2023). This approach aligns with the rapid development in multi-modal world models (Yang et al., 2023; Liu et al., 2023; Li et al., 2023a), presenting burgeoning opportunities for further innovation within the OOD detection community.

e. 利用世界知识增强离群分布检测 如第3.1.5节所述，现有利用基础模型(特别是像CLIP(Radford等人，2021)这样的多模态模型)的工作显著提高了离群分布检测性能。在此基础上，最近的进展进一步聚焦于利用大语言模型中封装的广泛世界知识(Dai等人，2023)。这种方法与多模态世界模型的快速发展相契合(Yang等人，2023；Liu等人，2023；Li等人，2023a)，为离群分布检测领域带来了新的创新机遇。

rks utilizing foundation mod. OOD Detection For Broader Learning Tasks As mentioned in Sect.3.6, OOD detection encompasses a broader spectrum of learning tasks, including multi-label classification (Wang et al., 2021), object detection (Du et al., 2022b, a), image segmentation (Hendrycks et al., 2022a), time-series prediction (Kaur et al., 2022b), and LiDAR-based 3D object detection (Nguyen, 2022). For the classification task itself, the researchers also extended the OOD detection technique to improve the reliability of zero-shot pretrained models (Esmaeilpour et al., 2022) (e.g., CLIP). Furthermore, some studies focus on applying OOD detection methods to produce reliable image captions (Shalev et al., 2022). Recent advancements extend OOD detection to continuously adaptive or online learning environments (Wu et al., 2023). Additionally, OOD detection could show promise to address model reliability issues in broader applications, like mitigating hallucination problems in large language models (Zhou et al., 2020).

利用基础模型的工作。用于更广泛学习任务的离群分布检测 如第3.6节所述，离群分布检测涵盖了更广泛的学习任务，包括多标签分类(Wang等人，2021)、目标检测(Du等人，2022b，a)、图像分割(Hendrycks等人，2022a)、时间序列预测(Kaur等人，2022b)和基于激光雷达的3D目标检测(Nguyen，2022)。对于分类任务本身，研究人员还将离群分布检测技术扩展到提高零样本预训练模型(Esmaeilpour等人，2022)(例如CLIP)的可靠性。此外，一些研究专注于应用离群分布检测方法来生成可靠的图像描述(Shalev等人，2022)。最近的进展将离群分布检测扩展到连续自适应或在线学习环境(Wu等人，2023)。此外，离群分布检测在解决更广泛应用中的模型可靠性问题方面可能显示出前景，例如缓解大语言模型中的幻觉问题(Zhou等人，2020)。

Building upon the concept of out-of-distribution (OOD) detection, a recent work introduces unsolvable problem detection (UPD) (Miyai et al., 2024) for question-answering models. UPD asks these models to detect and refrain from predicting answers for unexpected or unsolvable input questions, thereby extending the concept of OOD detection to (visual) question-answering settings. This extension aims to revive OOD detection approaches in broader AI tasks, such as those involving vision-language models (VLMs). Such "unsolvable problem" could be extended to broader contexts, such as dangerous robotic manipulation tasks, and ambiguous or toxic missions.

基于分布外(Out-of-distribution，OOD)检测的概念，近期的一项工作为问答模型引入了不可解问题检测(Unsolvable Problem Detection，UPD)(Miyai等人，2024)。UPD要求这些模型检测意外或不可解的输入问题，并避免对其答案进行预测，从而将OOD检测的概念扩展到(视觉)问答场景。这一扩展旨在使OOD检测方法在更广泛的人工智能任务中得到应用，例如涉及视觉语言模型(Vision-Language Models，VLMs)的任务。这种“不可解问题”可以扩展到更广泛的场景，例如危险的机器人操作任务以及模糊或有害的任务。

In sum, we hope the integration of OOD detection methods would promise to enhance the reliability and practicality of models across various fields, and insights from these fields could, in turn, further refine OOD detection techniques.

总之，我们希望OOD检测方法的整合有望提高各领域模型的可靠性和实用性，而这些领域的见解反过来又可以进一步完善OOD检测技术。

## 7 Conclusion

## 7 结论

In this survey, we comprehensively review five topics: AD, ND, OSR, OOD detection, and OD, and unify them as a framework of generalized OOD detection. By articulating the motivations and definitions of each sub-task, we encourage follow-up works to accurately locate their target problems and find the most suitable benchmarks. By sorting out the methodologies for each sub-task, we hope that readers can easily grasp the mainstream methods, identify suitable baselines, and contribute future solutions in light of existing ones. By providing insights, challenges, and future directions, we hope that future works will pay more attention to the existing problems and explore more interactions across other tasks within or even outside the scope of generalized OOD detection.

在本综述中，我们全面回顾了五个主题:异常检测(Anomaly Detection，AD)、新奇检测(Novelty Detection，ND)、开放集识别(Open Set Recognition，OSR)、分布外检测(Out-of-distribution Detection，OOD)和离群点检测(Outlier Detection，OD)，并将它们统一为一个广义OOD检测框架。通过阐述每个子任务的动机和定义，我们鼓励后续工作准确确定其目标问题并找到最合适的基准。通过梳理每个子任务的方法，我们希望读者能够轻松掌握主流方法，确定合适的基线，并根据现有方法提出未来的解决方案。通过提供见解、挑战和未来方向，我们希望未来的工作能够更加关注现有问题，并探索广义OOD检测范围内甚至范围外其他任务之间的更多交互。

Acknowledgements This study is supported by the Ministry of Education, Singapore, under its MOE AcRF Tier 2 (MOE-T2EP20221-0012), NTU NAP, and under the RIE2020 Industry Alignment Fund-Industry Collaboration Projects (IAF-ICP) Funding Initiative, as well as cash and in-kind contribution from the industry partner(s). YL is supported by the Office of the Vice Chancellor for Research and Graduate Education (OVCRGE) with funding from the Wisconsin Alumni Research Foundation (WARF).

致谢 本研究得到了新加坡教育部的支持，资助项目包括教育部学术研究基金二级项目(MOE AcRF Tier 2，项目编号:MOE-T2EP20221 - 0012)、南洋理工大学学术休假计划(NTU NAP)，以及2020年研究、创新与企业计划产业对接基金 - 产业合作项目(RIE2020 Industry Alignment Fund - Industry Collaboration Projects，IAF - ICP)资助计划，同时还得到了行业合作伙伴的现金和实物捐赠。YL得到了研究与研究生教育副校长办公室(Office of the Vice Chancellor for Research and Graduate Education，OVCRGE)的支持，资金来自威斯康星校友研究基金会(Wisconsin Alumni Research Foundation，WARF)。

Data Availability The datasets analyzed during the current study in Sect. 5 are available in the OpenOOD repository, https://github.com/ Jingkang50/OpenOOD.

数据可用性 第5节中当前研究期间分析的数据集可在OpenOOD仓库中获取，网址为:https://github.com/ Jingkang50/OpenOOD。

## References

## 参考文献

Abati, D., Porrello, A., Calderara, S., & Cucchiara, R. (2019). Latent space autoregression for novelty detection. In ${CVPR}$ .

Abati, D., Porrello, A., Calderara, S., & Cucchiara, R. (2019). 用于新奇检测的潜在空间自回归。见 ${CVPR}$ 。

Adler, A., Elad, M., Hel-Or, Y., & Rivlin, E. (2015). Sparse coding with anomaly detection. Journal of Signal Processing Systems, 79, 179-188.

Adler, A., Elad, M., Hel - Or, Y., & Rivlin, E. (2015). 带有异常检测的稀疏编码。《信号处理系统杂志》，79, 179 - 188。

Aggarwal, C. C., & Yu, P. S. (2001). Outlier detection for high dimensional data. In ${ACM}\;{SIGMOD}$ .

Aggarwal, C. C., & Yu, P. S. (2001). 高维数据的离群点检测。见 ${ACM}\;{SIGMOD}$ 。

Ahmed, F., & Courville, A. (2020). Detecting semantic anomalies. In ${AAAI}$ .

Ahmed, F., & Courville, A. (2020). 检测语义异常。见 ${AAAI}$ 。

Akhtar, N., & Mian, A. (2018). Threat of adversarial attacks on deep learning in computer vision: A survey. IEEE Access, 6, 14410- 14430.

Akhtar, N., & Mian, A. (2018). 计算机视觉中深度学习面临的对抗攻击威胁:综述。《IEEE接入》，6, 14410 - 14430。

Akoglu, L., Tong, H., & Koutra, D. (2015). Graph based anomaly detection and description: A survey. Data Mining and Knowledge Discovery, 29, 626-688.

Akoglu, L., Tong, H., & Koutra, D. (2015). 基于图的异常检测与描述:综述。《数据挖掘与知识发现》，29, 626 - 688。

Al-Behadili, H., Grumpe, A., & Wöhler, C. (2015). Incremental learning and novelty detection of gestures in a multi-class system. In AIMS.

Al - Behadili, H., Grumpe, A., & Wöhler, C. (2015). 多类系统中手势的增量学习与新奇检测。见AIMS。

Altman, D. G., & Bland, J. M. (2005). Standard deviations and standard errors. BMJ, 6, 66.

Altman, D. G., & Bland, J. M. (2005). 标准差与标准误差。《英国医学杂志》，6, 66。

Amodei, D., Olah, C., Steinhardt, J., Christiano, P., Schulman, J., & Mané, D. (2016). Concrete problems in AI safety, arXiv preprint arXiv:1606.06565

Amodei, D., Olah, C., Steinhardt, J., Christiano, P., Schulman, J., & Mané, D. (2016). 人工智能安全中的具体问题，arXiv预印本arXiv:1606.06565

An, J., & Cho, S. (2015). Variational autoencoder based anomaly detection using reconstruction probability. In Special lecture on IE.

安(An)和赵(Cho)(2015年)。基于变分自编码器，利用重建概率进行异常检测。载于工业工程特别讲座。

Angelopoulos, A. N., & Bates, S. (2021). A gentle introduction to conformal prediction and distribution-free uncertainty quantification, arXiv preprint arXiv:2107.07511

安杰洛普洛斯(Angelopoulos)和贝茨(Bates)(2021年)。共形预测和无分布不确定性量化简明介绍，预印本arXiv:2107.07511

Atha, D. J., & Jahanshahi, M. R. (2018). Evaluation of deep learning approaches based on convolutional neural networks for corrosion detection. Structural Health Monitoring, 17, 1110-1128.

阿萨(Atha)和贾汉沙希(Jahanshahi)(2018年)。基于卷积神经网络的深度学习方法在腐蚀检测中的评估。《结构健康监测》，第17卷，第1110 - 1128页。

Averly, R., & Chao, W.-L. (2023). Unified out-of-distribution detection: A model-specific perspective, arXiv preprint arXiv:2304.06813

阿弗利(Averly)和赵(Chao)(2023年)。统一的分布外检测:特定模型视角，预印本arXiv:2304.06813

Bai, Y., Han, Z., Zhang, C., Cao, B., Jiang, X., & Hu, Q. (2023). Id-like prompt learning for few-shot out-of-distribution detection, arXiv preprint arXiv:2311.15243

白(Bai)、韩(Han)、张(Zhang)、曹(Cao)、江(Jiang)和胡(Hu)(2023年)。用于小样本分布外检测的类身份提示学习，预印本arXiv:2311.15243

Bartlett, P. L., & Wegkamp, M. H. (2008). Classification with a reject option using a hinge loss. Journal of Machine Learning Research, 9, 8.

巴特利特(Bartlett)和韦格坎普(Wegkamp)(2008年)。使用铰链损失的带拒绝选项的分类。《机器学习研究杂志》，第9卷，第8页。

Basu, S., & Meckesheimer, M. (2007). Automatic outlier detection for time series: An application to sensor data. Knowledge and Information Systems, 11, 137-154.

巴苏(Basu)和梅克斯海默(Meckesheimer)(2007年)。时间序列的自动离群值检测:在传感器数据中的应用。《知识与信息系统》，第11卷，第137 - 154页。

Bekker, J., & Davis, J. (2020). Learning from positive and unlabeled data: A survey. Machine Learning, 109, 719-760.

贝克尔(Bekker)和戴维斯(Davis)(2020年)。从正样本和无标签数据中学习:综述。《机器学习》，第109卷，第719 - 760页。

Bendale, A., & Boult, T. (2015). Towards open world recognition. In ${CVPR}$ .

本代尔(Bendale)和博尔特(Boult)(2015年)。迈向开放世界识别。载于${CVPR}$。

Bendale, A., & Boult, T. E. (2016). Towards open set deep networks. In ${CVPR}$ .

本代尔(Bendale)和博尔特(Boult)(2016年)。迈向开放集深度网络。载于${CVPR}$。

Ben-David, S., Blitzer, J., Crammer, K., Kulesza, A., Pereira, F., & Vaughan, J. W. (2010). A theory of learning from different domains. Machine Learning, 79, 151-175.

本 - 戴维(Ben - David)、布利策(Blitzer)、克拉默(Crammer)、库莱扎(Kulesza)、佩雷拉(Pereira)和沃恩(Vaughan)(2010年)。不同领域学习理论。《机器学习》，第79卷，第151 - 175页。

Ben-Gal, I. (2005). Outlier detection. In Data mining and knowledge discovery handbook.

本 - 加尔(Ben - Gal)(2005年)。离群值检测。载于《数据挖掘与知识发现手册》。

Bergman, L., & Hoshen, Y. (2020). Classification-based anomaly detection for general data. In ${ICLR}$ .

伯格曼(Bergman)和霍申(Hoshen)(2020年)。基于分类的通用数据异常检测。载于${ICLR}$。

Bergmann, P., Fauser, M., Sattlegger, D., & Steger, C. (2019). Mvtec ad-A comprehensive real-world dataset for unsupervised anomaly detection. In ${CVPR}$ .

伯格曼(Bergmann)、福泽尔(Fauser)、萨特莱格(Sattlegger)和施泰格(Steger)(2019年)。Mvtec ad - 用于无监督异常检测的综合现实世界数据集。载于${CVPR}$。

Bianchini, M., Belahcen, A., & Scarselli, F. (2016). A comparative study of inductive and transductive learning with feedforward neural networks. In Conference of the Italian Association for artificial intelligence.

比安基尼(Bianchini)、贝拉赫森(Belahcen)和斯卡尔塞利(Scarselli)(2016年)。前馈神经网络归纳学习和直推学习的比较研究。载于意大利人工智能协会会议。

Bibas, K., Feder, M., & Hassner, T. (2021). Single layer predictive normalized maximum likelihood for out-of-distribution detection. In NeurIPS.

比巴斯(Bibas)、费德(Feder)和哈斯纳(Hassner)(2021年)。用于分布外检测的单层预测归一化最大似然法。载于神经信息处理系统大会(NeurIPS)。

Bitterwolf, J., Meinke, A., & Hein, M. (2020). Certifiably adversarially robust detection of out-of-distribution data. In NeurIPS.

比特沃夫(Bitterwolf)，J.，迈因克(Meinke)，A.，& 海因(Hein)，M.(2020)。可证明对抗鲁棒的分布外数据检测。发表于神经信息处理系统大会(NeurIPS)。

Bitterwolf, J., Müller, M., & Hein, M. (2023). In or out? fixing imagenet out-of-distribution detection evaluation. In ${ICML}$ .

比特沃夫(Bitterwolf)，J.，米勒(Müller)，M.，& 海因(Hein)，M.(2023)。是分布内还是分布外？修正ImageNet分布外检测评估。发表于${ICML}$。

Bodesheim, P., Freytag, A., Rodner, E., Kemmler, M., & Denzler, J. (2013). Kernel null space methods for novelty detection. In CVPR.

博德舍姆(Bodesheim)，P.，弗赖塔格(Freytag)，A.，罗德纳(Rodner)，E.，凯姆勒(Kemmler)，M.，& 登茨勒(Denzler)，J.(2013)。用于新奇性检测的核零空间方法。发表于计算机视觉与模式识别会议(CVPR)。

Bommasani, R., Hudson, D. A., Adeli, E., Altman, R., Arora, S., von Arx, S., Bernstein, M. S., Bohg, J., Bosselut, A., Brunskill, E., & Brynjolfsson, E. (2021). On the opportunities and risks of foundation models, arXiv preprint arXiv:2108.07258

博马萨尼(Bommasani)，R.，哈德森(Hudson)，D. A.，阿德利(Adeli)，E.，奥尔特曼(Altman)，R.，阿罗拉(Arora)，S.，冯·阿尔克斯(von Arx)，S.，伯恩斯坦(Bernstein)，M. S.，博格(Bohg)，J.，博塞卢特(Bosselut)，A.，布伦斯克尔(Brunskill)，E.，& 布林约尔松(Brynjolfsson)，E.(2021)。关于基础模型的机遇与风险，预印本论文arXiv:2108.07258

Boult, T. E., Cruz, S., Dhamija, A. R., Gunther, M., Henrydoss, J., & Scheirer, W. J. (2019). Learning and the unknown: Surveying steps toward open world recognition. In ${AAAI}$ .

博尔特(Boult)，T. E.，克鲁兹(Cruz)，S.，达米贾(Dhamija)，A. R.，冈瑟(Gunther)，M.，亨里多斯(Henrydoss)，J.，& 谢勒(Scheirer)，W. J.(2019)。学习与未知:迈向开放世界识别的步骤综述。发表于${AAAI}$。

Breunig, M. M., Kriegel, H.-P., Ng, R. T., & Sander, J. (2000). Lof: identifying density-based local outliers. In SIGMOD.

布罗伊尼格(Breunig)，M. M.，克里格尔(Kriegel)，H.-P.，吴(Ng)，R. T.，& 桑德(Sander)，J.(2000)。局部离群因子(LOF):识别基于密度的局部离群点。发表于管理数据会议(SIGMOD)。

Bulusu, S., Kailkhura, B., Li, B., Varshney, P. K., & Song, D. (2020). Anomalous example detection in deep learning: A survey. IEEE Access, 8, 132330-132347.

布卢苏(Bulusu)，S.，凯尔库拉(Kailkhura)，B.，李(Li)，B.，瓦尔什尼(Varshney)，P. K.，& 宋(Song)，D.(2020)。深度学习中的异常示例检测:综述。《电气与电子工程师协会接入》(IEEE Access)，8，132330 - 132347。

Cai, F., Ozdagli, A. I., Potteiger, N., & Koutsoukos, X. (2021). Inductive conformal out-of-distribution detection based on adversarial autoencoders. In 2021 IEEE international conference on omni-layer intelligent systems (COINS) (pp. 1-6). IEEE.

蔡(Cai)，F.，奥兹达格利(Ozdagli)，A. I.，波泰格(Potteiger)，N.，& 库特苏科斯(Koutsoukos)，X.(2021)。基于对抗自编码器的归纳共形分布外检测。发表于2021年电气与电子工程师协会全层智能系统国际会议(COINS)(第1 - 6页)。电气与电子工程师协会(IEEE)。

Cao, A., Luo, Y., & Klabjan, D. (2020). Open-set recognition with Gaussian mixture variational autoencoders. In AAAI.

曹(Cao)，A.，罗(Luo)，Y.，& 克拉布扬(Klabjan)，D.(2020)。使用高斯混合变分自编码器进行开放集识别。发表于美国人工智能协会会议(AAAI)。

Cao, K., Brbic, M., & Leskovec, J. (2021). Open-world semi-supervised learning, arXiv preprint arXiv:2102.03526

曹(Cao)，K.，布尔比奇(Brbic)，M.，& 莱斯科维奇(Leskovec)，J.(2021)。开放世界半监督学习，预印本论文arXiv:2102.03526

Castillo, E. (2012). Extreme value theory in engineering. Elsevier.

卡斯蒂略(Castillo)，E.(2012)。工程中的极值理论。爱思唯尔(Elsevier)出版社。

Chalapathy, R., & Chawla, S. (2019). Deep learning for anomaly detection: A survey, arXiv preprint arXiv:1901.0340

查拉帕蒂(Chalapathy)，R.，& 乔拉(Chawla)，S.(2019)。用于异常检测的深度学习:综述，预印本论文arXiv:1901.0340

Chandola, V., Banerjee, A., & Kumar, V. (2009). Anomaly detection: A survey. ACM computing surveys (CSUR), 41(3), 1-58.

钱德拉(Chandola)，V.，班纳吉(Banerjee)，A.，& 库马尔(Kumar)，V.(2009)。异常检测:综述。《美国计算机协会计算调查》(ACM Computing Surveys，CSUR)，41(3)，1 - 58。

Chen, G., Peng, P., Ma, L., Li, J., Du, L., & Tian, Y. (2021a). Amplitude-phase recombination: Rethinking robustness of convolutional neural networks in frequency domain. In ICCV.

陈(Chen)，G.，彭(Peng)，P.，马(Ma)，L.，李(Li)，J.，杜(Du)，L.，& 田(Tian)，Y.(2021a)。幅度 - 相位重组:重新思考卷积神经网络在频域中的鲁棒性。发表于国际计算机视觉会议(ICCV)。

Chen, G., Qiao, L., Shi, Y., Peng, P., Li, J., Huang, T., Pu, S., & Tian, Y. (2020a). Learning open set network with discriminative reciprocal points. In ${ECCV}$ .

陈(Chen)，G.，乔(Qiao)，L.，施(Shi)，Y.，彭(Peng)，P.，李(Li)，J.，黄(Huang)，T.，蒲(Pu)，S.，& 田(Tian)，Y.(2020a)。使用判别性互反点学习开放集网络。发表于${ECCV}$。

Chen, J., Li, Y., Wu, X., Liang, Y., & Jha, S. (2020b). Robust out-of-distribution detection for neural networks, arXiv preprint arXiv:2003.09711

陈(Chen)，J.，李(Li)，Y.，吴(Wu)，X.，梁(Liang)，Y.，& 贾(Jha)，S.(2020b)。神经网络的鲁棒分布外检测，预印本论文arXiv:2003.09711

Chen, J., Li, Y., Wu, X., Liang, Y., & Jha, S. (2021c). Atom: Robustifying out-of-distribution detection using outlier mining. In ${ECML}\& {PKDD}$ .

陈(Chen)、李(Li)、吴(Wu)、梁(Liang)和贾(Jha)(2021c)。ATOM:利用离群点挖掘增强分布外检测的鲁棒性。见${ECML}\& {PKDD}$。

Chen, X., & Gupta, A. (2015). Webly supervised learning of convolutional networks. In ${ICCV}$ .

陈(Chen)和古普塔(Gupta)(2015)。基于网络监督的卷积网络学习。见${ICCV}$。

Chen, X., Lan, X., Sun, F., & Zheng, N. (2020c). A boundary based out-of-distribution classifier for generalized zero-shot learning. In ${ECCV}$ .

陈(Chen)、兰(Lan)、孙(Sun)和郑(Zheng)(2020c)。用于广义零样本学习的基于边界的分布外分类器。见${ECCV}$。

Chen, Z., Yeo, C. K., Lee, B. S., & Lau, C. T. (2018). Autoencoder-based network anomaly detection. In Wireless telecommunications symposium.

陈(Chen)、杨(Yeo)、李(Lee)和刘(Lau)(2018)。基于自编码器的网络异常检测。见无线电信研讨会。

Choi, H., Jang, E., & Alemi, A. A. (2018). Waic, but why? generative ensembles for robust anomaly detection, arXiv preprint arXiv:1810.01392

崔(Choi)、张(Jang)和阿莱米(Alemi)(2018)。WAIC，但为什么呢？用于鲁棒异常检测的生成式集成，预印本arXiv:1810.01392

Choi, S., & Chung, S.-Y. (2020). Novelty detection via blurring. In ${ICLR}$ .

崔(Choi)和钟(Chung)(2020)。通过模糊进行新奇性检测。见${ICLR}$。

Chow, C. (1970). On optimum recognition error and reject tradeoff. IEEE Transactions on Information Theory, 16, 41-6.

周(Chow)(1970)。关于最优识别错误与拒绝权衡。《IEEE信息论汇刊》，16，41 - 6。

Chu, W.-H., & Kitani, K. M. (2020). Neural batch sampling with reinforcement learning for semi-supervised anomaly detection. In ${ECCV}$ .

朱(Chu)和北谷(Kitani)(2020)。用于半监督异常检测的基于强化学习的神经批量采样。见${ECCV}$。

Cortes, C., & Vapnik, V. (1995). Support-vector networks. Machine learning, 20, 273-97.

科尔特斯(Cortes)和瓦普尼克(Vapnik)(1995)。支持向量网络。《机器学习》，20，273 - 97。

Cultrera, L., Seidenari, L., & Del Bimbo, A. (2023). Leveraging visual attention for out-of-distribution detection. In Proceedings of the IEEE/CVF international conference on computer vision (pp. 4447-4456).

库尔特拉(Cultrera)、塞德纳里(Seidenari)和德尔宾博(Del Bimbo)(2023)。利用视觉注意力进行分布外检测。见IEEE/CVF国际计算机视觉会议论文集(第4447 - 4456页)。

Dai, Y., Lang, H., Zeng, K., Huang, F., & Li, Y., (2023). Exploring large language models for multi-modal out-of-distribution detection, arXiv preprint arXiv:2310.08027

戴(Dai)、郎(Lang)、曾(Zeng)、黄(Huang)和李(Li)(2023)。探索大语言模型用于多模态分布外检测，预印本arXiv:2310.08027

Danuser, G., & Stricker, M. (1998). Parametric model fitting: From inlier characterization to outlier detection. In TPAMI.

达努瑟(Danuser)和施特里克尔(Stricker)(1998)。参数模型拟合:从内点特征到离群点检测。见《模式分析与机器智能汇刊》(TPAMI)。

De Maesschalck, R., Jouan-Rimbaud, D., & Massart, D. L. (2000). The Mahalanobis distance, chemometrics and intelligent laboratory systems.

德梅斯查尔克(De Maesschalck)、茹安 - 兰博(Jouan - Rimbaud)和马萨特(Massart)(2000)。马氏距离、化学计量学与智能实验室系统。

Deecke, L., Vandermeulen, R., Ruff, L., Mandt, S., & Kloft, M. (2018). Image anomaly detection with generative adversarial networks. In ${ECML}\& {KDD}$ .

德克(Deecke)、范德梅伦(Vandermeulen)、鲁夫(Ruff)、曼特(Mandt)和克洛夫特(Kloft)(2018)。利用生成对抗网络进行图像异常检测。见${ECML}\& {KDD}$。

Denouden, T., Salay, R., Czarnecki, K., Abdelzad, V., Phan, B., & Vernekar, S. (2018). Improving reconstruction autoencoder out-of-distribution detection with Mahalanobis distance, arXiv preprint arXiv:1812.02765

德努登(Denouden)、萨莱(Salay)、恰尔内茨基(Czarnecki)、阿卜杜勒扎德(Abdelzad)、潘(Phan)和韦尔内卡尔(Vernekar)(2018)。利用马氏距离改进重构自编码器的分布外检测，预印本arXiv:1812.02765

Desforges, M., Jacob, P., & Cooper, J. (1998). Applications of probability density estimation to the detection of abnormal conditions in engineering. In Proceedings of the institution of mechanical engineers.

德斯福热斯(Desforges)、雅各布(Jacob)和库珀(Cooper)(1998)。概率密度估计在工程异常状况检测中的应用。见机械工程师学会会议论文集。

DeVries, T., & Taylor, G. W. (2017). Improved regularization of convolutional neural networks with cutout, arXiv preprint arXiv:1708.04552

德弗里斯(DeVries)，T.，& 泰勒(Taylor)，G. W.(2017)。使用Cutout改进卷积神经网络的正则化，arXiv预印本arXiv:1708.04552

DeVries, T., & Taylor, G. W. (2018). Learning confidence for out-of-distribution detection in neural networks, arXiv preprint arXiv:1802.04865

德弗里斯(DeVries)，T.，& 泰勒(Taylor)，G. W.(2018)。学习神经网络中分布外检测的置信度，arXiv预印本arXiv:1802.04865

Dhamija, A. R., Günther, M., & Boult, T. E. (2018). Reducing network

达米贾(Dhamija)，A. R.，京特(Günther)，M.，& 博尔特(Boult)，T. E.(2018)。减少网络

agnostophobia. In NeurIPS.

分布外恐惧症。发表于神经信息处理系统大会(NeurIPS)。

Diehl, C. P., & Hampshire, J. B. (2002). Real-time object classification and novelty detection for collaborative video surveillance. In IJCNN.

迪尔(Diehl)，C. P.，& 汉普郡(Hampshire)，J. B.(2002)。协作视频监控的实时目标分类和新奇检测。发表于国际神经网络联合会议(IJCNN)。

Dietterich, T. G. (2000). Ensemble methods in machine learning. In International workshop on multiple classifier systems.

迪特里希(Dietterich)，T. G.(2000)。机器学习中的集成方法。发表于多分类器系统国际研讨会。

Djurisic, A., Bozanic, N., Ashok, A., & Liu, R. (2023). Extremely simple activation shaping for out-of-distribution detection. In ICLR.

久里西奇(Djurisic)，A.，博扎尼奇(Bozanic)，N.，阿肖克(Ashok)，A.，& 刘(Liu)，R.(2023)。用于分布外检测的极其简单的激活塑形。发表于国际学习表征会议(ICLR)。

Dolhansky, B., Howes, R., Pflaum, B., Baram, N., & Ferrer, C. C. (2019). The deepfake detection challenge (dfdc) preview dataset, arXiv preprint arXiv:1910.08854

多尔汉斯基(Dolhansky)，B.，豪斯(Howes)，R.，普劳姆(Pflaum)，B.，巴拉姆(Baram)，N.，& 费雷尔(Ferrer)，C. C.(2019)。深度伪造检测挑战(DFDC)预览数据集，arXiv预印本arXiv:1910.08854

Dong, J., Gao, Y., Zhou, H., Cen, J., Yao, Y., Yoon, S., & Sun, P. D. (2023). Towards few-shot out-of-distribution detection, arXiv preprint arXiv:2311.12076

董(Dong)，J.，高(Gao)，Y.，周(Zhou)，H.，岑(Cen)，J.，姚(Yao)，Y.，尹(Yoon)，S.，& 孙(Sun)，P. D.(2023)。迈向少样本分布外检测，arXiv预印本arXiv:2311.12076

Dong, X., Guo, J., Ang Li, W.-T.T., Liu, C., & Kung, H. (2022a). Neural mean discrepancy for efficient out-of-distribution detection. In ${CVPR}$ .

董(Dong)，X.，郭(Guo)，J.，李安(Ang Li)，W.-T.T.，刘(Liu)，C.，& 孔(Kung)，H.(2022a)。用于高效分布外检测的神经均值差异。发表于${CVPR}$。

Dong, X., Guo, J., Li, A., Ting, W.-T., Liu, C., & Kung, H. (2022a). Neural mean discrepancy for efficient out-of-distribution detection. In ${CVPR}$ .

董(Dong)，X.，郭(Guo)，J.，李(Li)，A.，廷(Ting)，W.-T.，刘(Liu)，C.，& 孔(Kung)，H.(2022a)。用于高效分布外检测的神经均值差异。发表于${CVPR}$。

Dou, Y., Li, W., Liu, Z., Dong, Z., Luo, J., & Philip, S. Y. (2019). Uncovering download fraud activities in mobile app markets. In ${ASONAM}$ .

窦(Dou)，Y.，李(Li)，W.，刘(Liu)，Z.，董(Dong)，Z.，罗(Luo)，J.，& 菲利普(Philip)，S. Y.(2019)。揭示移动应用市场中的下载欺诈活动。发表于${ASONAM}$。

Drummond, N., & Shearer, R. (2006). The open world assumption. In eSI workshop.

德拉蒙德(Drummond)，N.，& 希勒(Shearer)，R.(2006)。开放世界假设。发表于eSI研讨会。

Du, X., Wang, X., Gozum, G., & Li, Y. (2022a). Unknown-aware object detection: Learning what you don't know from videos in the wild. In Proceedings of the IEEE/CVF conference on computer vision and pattern recognition.

杜(Du)，X.，王(Wang)，X.，戈祖姆(Gozum)，G.，& 李(Li)，Y.(2022a)。未知感知目标检测:从自然场景视频中学习未知内容。发表于电气与电子工程师协会/计算机视觉基金会计算机视觉与模式识别会议论文集。

Du, X., Wang, Z., Cai, M., & Li, Y. (2022b). Vos: Learning what you don't know by virtual outlier synthesis. In Proceedings of the international conference on learning representations.

杜(Du)，X.，王(Wang)，Z.，蔡(Cai)，M.，& 李(Li)，Y.(2022b)。Vos:通过虚拟离群值合成学习未知内容。发表于国际学习表征会议论文集。

Eskin, E. (2000). Anomaly detection over noisy data using learned probability distributions. In ${ICML}$ .

埃斯金(Eskin)，E.(2000)。使用学习到的概率分布对含噪数据进行异常检测。发表于${ICML}$。

Esmaeilpour, S., Liu, B., Robertson, E., & Shu, L. (2022). Zero-shot out-of-distribution detection based on the pretrained model clip. In ${AAAI}$ .

埃斯迈尔普尔(Esmaeilpour)，S.，刘(Liu)，B.，罗伯逊(Robertson)，E.，& 舒(Shu)，L.(2022)。基于预训练模型CLIP的零样本分布外检测。见${AAAI}$。

Ester, M., Kriegel, H.-P., Sander, J., & Xu, X. (1996). A density-based algorithm for discovering clusters in large spatial databases with noise. In ${KDD}$ .

埃斯特(Ester)，M.，克里格尔(Kriegel)，H.-P.，桑德(Sander)，J.，& 徐(Xu)，X.(1996)。一种基于密度的算法，用于在含噪声的大型空间数据库中发现聚类。见${KDD}$。

Fang, Z., Li, Y., Lu, J., Dong, J., Han, B., & Liu, F. (2022). Is out-of-distribution detection learnable? In NeurIPS.

方(Fang)，Z.，李(Li)，Y.，陆(Lu)，J.，董(Dong)，J.，韩(Han)，B.，& 刘(Liu)，F.(2022)。分布外检测是否可学习？见神经信息处理系统大会(NeurIPS)。

Fang, Z., Lu, J., Liu, A., Liu, F., & Zhang, G. (2021). Learning bounds for open-set learning. In ${ICML}$ .

方(Fang)，Z.，陆(Lu)，J.，刘(Liu)，A.，刘(Liu)，F.，& 张(Zhang)，G.(2021)。开放集学习的学习边界。见${ICML}$。

Fawcett, T. (2006). An introduction to roc analysis. Pattern Recognition Letters, 27, 861-74.

福西特(Fawcett)，T.(2006)。受试者工作特征(ROC)分析导论。《模式识别快报》，27，861 - 74。

Fischler, M. A., & Bolles, R. C. (1981). Random sample consensus: A paradigm for model fitting with applications to image analysis and automated cartography. Communications of the ACM, 24, 381- 395.

菲施勒(Fischler)，M. A.，& 博尔斯(Bolles)，R. C.(1981)。随机抽样一致性:一种用于模型拟合的范式及其在图像分析和自动制图中的应用。《美国计算机协会通讯》，24，381 - 395。

Foong, A. Y., Li, Y., Hernández-Lobato, J. M., & Turner, R. E. (2020). 'in-between' uncertainty in Bayesian neural networks. In ICML- $W$ .

冯(Foong)，A. Y.，李(Li)，Y.，埃尔南德斯 - 洛巴托(Hernández - Lobato)，J. M.，& 特纳(Turner)，R. E.(2020)。贝叶斯神经网络中的“中间”不确定性。见国际机器学习会议(ICML) - $W$。

Fort, S., Ren, J., & Lakshminarayanan, B. (2021). Exploring the limits of out-of-distribution detection. In NeurIPS.

福特(Fort, S.)、任(Ren, J.)和拉克什米纳拉亚南(Lakshminarayanan, B.)(2021 年)。探索分布外检测的极限。发表于神经信息处理系统大会(NeurIPS)。

Fumera, G., & Roli, F. (2002). Support vector machines with embedded reject option. In International workshop on support vector machines.

富梅拉(Fumera, G.)和罗利(Roli, F.)(2002 年)。带有嵌入式拒绝选项的支持向量机。发表于支持向量机国际研讨会。

Gal, Y., & Ghahramani, Z. (2016). Dropout as a Bayesian approximation: Representing model uncertainty in deep learning. In ICML.

加尔(Gal, Y.)和加哈拉马尼(Ghahramani, Z.)(2016 年)。将随机失活作为贝叶斯近似:在深度学习中表示模型不确定性。发表于国际机器学习会议(ICML)。

Gamerman, D., & Lopes, H. F. (2006). Markov chain Monte Carlo: Stochastic simulation for Bayesian inference. CRC Press.

加默曼(Gamerman, D.)和洛佩斯(Lopes, H. F.)(2006 年)。马尔可夫链蒙特卡罗方法:用于贝叶斯推断的随机模拟。CRC 出版社。

Gan, W. (2021). Language guided out-of-distribution detection.

甘(Gan, W.)(2021 年)。语言引导的分布外检测。

Gao, P., Geng, S., Zhang, R., Ma, T., Fang, R., Zhang, Y., Li, H., &

高(Gao, P.)、耿(Geng, S.)、张(Zhang, R.)、马(Ma, T.)、方(Fang, R.)、张(Zhang, Y.)、李(Li, H.)和

Qiao, Y. (2023). Clip-adapter: Better vision-language models with feature adapters. International Journal of Computer Vision, 132, 1-15.

乔(Qiao, Y.)(2023 年)。CLIP 适配器:通过特征适配器实现更好的视觉 - 语言模型。《国际计算机视觉杂志》(International Journal of Computer Vision)，132 卷，第 1 - 15 页。

Gatys, L. A., Ecker, A. S., & Bethge, M. (2016). Image style transfer using convolutional neural networks. In CVPR.

加蒂斯(Gatys, L. A.)、埃克(Ecker, A. S.)和贝格(Bethge, M.)(2016 年)。使用卷积神经网络进行图像风格迁移。发表于计算机视觉与模式识别会议(CVPR)。

Ge, Z., Demyanov, S., Chen, Z., & Garnavi, R. (2017). Generative openmax for multi-class open set classification. In ${BMVC}$ .

葛(Ge, Z.)、杰米亚诺夫(Demyanov, S.)、陈(Chen, Z.)和加尔纳维(Garnavi, R.)(2017 年)。用于多类开放集分类的生成式开放最大值方法。发表于${BMVC}$。

Geiger, A., Lenz, P., & Urtasun, R. (2012). Are we ready for autonomous driving? The Kitti vision benchmark suite. In CVPR.

盖格(Geiger, A.)、伦茨(Lenz, P.)和乌尔塔松(Urtasun, R.)(2012 年)。我们准备好自动驾驶了吗？基蒂视觉基准套件。发表于计算机视觉与模式识别会议(CVPR)。

Gelman, A. (2008). Objections to Bayesian statistics. Bayesian Analysis, 66, 4445-449.

格尔曼(Gelman, A.)(2008 年)。对贝叶斯统计的异议。《贝叶斯分析》(Bayesian Analysis)，66 卷，第 4445 - 449 页。

Geng, C., & Chen, S. (2020). Collective decision for open set recognition. In ${TKDE}$ .

耿(Geng, C.)和陈(Chen, S.)(2020 年)。开放集识别的集体决策。发表于${TKDE}$。

Geng, C., Huang, S., & Chen, S. (2020). Recent advances in open set recognition: A survey. In TPAMI.

耿(Geng, C.)、黄(Huang, S.)和陈(Chen, S.)(2020 年)。开放集识别的最新进展:综述。发表于《模式分析与机器智能汇刊》(TPAMI)。

Georgescu, M.-I., Barbalau, A., Ionescu, R. T., Khan, F. S., Popescu, M., & Shah, M. (2021). Anomaly detection in video via self-supervised and multi-task learning. In ${CVPR}$ .

乔治斯库(Georgescu, M.-I.)、巴尔巴拉乌(Barbalau, A.)、约内斯库(Ionescu, R. T.)、汗(Khan, F. S.)、波佩斯库(Popescu, M.)和沙阿(Shah, M.)(2021 年)。通过自监督和多任务学习进行视频异常检测。发表于${CVPR}$。

Golan, I., & El-Yaniv, R. (2018). Deep anomaly detection using geometric transformations. In NeurIPS.

戈兰(Golan, I.)和埃尔 - 亚尼夫(El - Yaniv, R.)(2018 年)。使用几何变换进行深度异常检测。发表于神经信息处理系统大会(NeurIPS)。

Goldstein, M., & Dengel, A. (2012). Histogram-based outlier score (hbos): A fast unsupervised anomaly detection algorithm. In ${KI}$ - 2012: Poster and demo track.

戈尔茨坦(Goldstein, M.)和邓格尔(Dengel, A.)(2012 年)。基于直方图的离群值分数(HBOS):一种快速无监督异常检测算法。发表于${KI}$ - 2012:海报与演示环节。

Gomes, E. D. C., Alberge, F., Duhamel, P., & Piantanida, P. (2022). Igeood: An information geometry approach to out-of-distribution detection. In ${ICLR}$ .

戈麦斯(Gomes, E. D. C.)、阿尔贝热(Alberge, F.)、杜阿梅尔(Duhamel, P.)和皮安塔尼达(Piantanida, P.)(2022 年)。Igeood:一种用于分布外检测的信息几何方法。见${ICLR}$。

Gong, D., Liu, L., Le, V., Saha, B., Mansour, M. R., Venkatesh, S., & Hengel, A. V. D. (2019). Memorizing normality to detect anomaly: Memory-augmented deep autoencoder for unsupervised anomaly detection. In ${CVPR}$ .

龚(Gong, D.)、刘(Liu, L.)、勒(Le, V.)、萨哈(Saha, B.)、曼苏尔(Mansour, M. R.)、文卡特什(Venkatesh, S.)和亨格尔(Hengel, A. V. D.)(2019 年)。通过记忆正常情况来检测异常:用于无监督异常检测的记忆增强深度自动编码器。见${CVPR}$。

Goodfellow, I., Pouget-Abadie, J., Mirza, M., Xu, B., Warde-Farley, D., Ozair, S., Courville, A., & Bengio, Y. (2014). Generative adversarial nets. In NIPS.

古德费洛(Goodfellow, I.)、普热-阿巴迪(Pouget - Abadie, J.)、米尔扎(Mirza, M.)、徐(Xu, B.)、沃德 - 法利(Warde - Farley, D.)、奥扎尔(Ozair, S.)、库尔维尔(Courville, A.)和本吉奥(Bengio, Y.)(2014 年)。生成对抗网络。见神经信息处理系统大会(NIPS)。

Goodfellow, I. J., Shlens, J., & Szegedy, C. (2015). Explaining and harnessing adversarial examples. In ICLR.

古德费洛(Goodfellow, I. J.)、什伦斯(Shlens, J.)和塞吉迪(Szegedy, C.)(2015 年)。解释和利用对抗样本。见国际学习表征会议(ICLR)。

Han, B., Yao, Q., Yu, X., Niu, G., Xu, M., Hu, W., Tsang, I., & Sugiyama, M. (2018). Co-teaching: Robust training of deep neural networks with extremely noisy labels. In NIPS.

韩(Han, B.)、姚(Yao, Q.)、余(Yu, X.)、牛(Niu, G.)、徐(Xu, M.)、胡(Hu, W.)、曾(Tsang, I.)和杉山(Sugiyama, M.)(2018 年)。协同教学:使用极嘈杂标签对深度神经网络进行鲁棒训练。见神经信息处理系统大会(NIPS)。

Han, K., Vedaldi, A., & Zisserman, A. (2019). Learning to discover novel visual categories via deep transfer clustering. In CVPR.

韩(Han, K.)、韦尔迪耶(Vedaldi, A.)和齐斯曼(Zisserman, A.)(2019 年)。通过深度迁移聚类学习发现新颖视觉类别。见计算机视觉与模式识别会议(CVPR)。

Han, X., Chen, X., & Liu, L.-P. (2020). Gan ensemble for anomaly detection, arXiv preprint arXiv:2012.07988

韩(Han, X.)、陈(Chen, X.)和刘(Liu, L. - P.)(2020 年)。用于异常检测的生成对抗网络集成，预印本 arXiv:2012.07988

Hautamaki, V., Karkkainen, I., & Franti, P. (2004). Outlier detection using k-nearest neighbour graph. In ICPR.

豪塔马基(Hautamaki, V.)、卡尔卡宁(Karkkainen, I.)和弗兰蒂(Franti, P.)(2004 年)。使用 k 近邻图进行离群点检测。见国际模式识别会议(ICPR)。

He, K., Zhang, X., Ren, S., & Sun, J. (2015). Delving deep into rectifiers: Surpassing human-level performance on imagenet classification. In ${ICCV}$ .

何(He, K.)、张(Zhang, X.)、任(Ren, S.)和孙(Sun, J.)(2015 年)。深入研究整流器:在 ImageNet 分类任务上超越人类水平的性能。见${ICCV}$。

He, K., Zhang, X., Ren, S., & Sun, J. (2016). Deep residual learning for image recognition. In ${CVPR}$ .

何(He, K.)、张(Zhang, X.)、任(Ren, S.)和孙(Sun, J.)(2016 年)。用于图像识别的深度残差学习。见${CVPR}$。

Hein, M., Andriushchenko, M., & Bitterwolf, J. (2019). Why relu networks yield high-confidence predictions far away from the training data and how to mitigate the problem. In CVPR.

海因(Hein, M.)、安德里乌申科(Andriushchenko, M.)和比特沃尔夫(Bitterwolf, J.)(2019 年)。为什么 ReLU 网络在远离训练数据的地方会产生高置信度预测以及如何缓解该问题。见计算机视觉与模式识别会议(CVPR)。

Hendrycks, D., Basart, S., Mazeika, M., Mostajabi, M., Steinhardt, J., & Song, D. (2022a) Scaling out-of-distribution detection for real-world settings. In ${ICML}$ .

亨德里克斯(Hendrycks, D.)、巴萨特(Basart, S.)、马泽伊卡(Mazeika, M.)、莫斯塔贾比(Mostajabi, M.)、斯坦哈特(Steinhardt, J.)和宋(Song, D.)(2022a)。为现实世界场景扩展分布外检测。见${ICML}$。

Hendrycks, D., Carlini, N., Schulman, J., & Steinhardt, J. (2021). Unsolved problems in ML safety. arXiv preprint, arXiv:2109.13916

亨德里克斯(Hendrycks, D.)、卡利尼(Carlini, N.)、舒尔曼(Schulman, J.)和斯坦哈特(Steinhardt, J.)(2021 年)。机器学习安全领域未解决的问题。预印本，arXiv:2109.13916

Hendrycks, D., & Gimpel, K. (2017). A baseline for detecting misclassified and out-of-distribution examples in neural networks. In ${ICLR}$ .

亨德里克斯(Hendrycks, D.)和金佩尔(Gimpel, K.)(2017 年)。神经网络中检测误分类和分布外样本的基线方法。见${ICLR}$。

Hendrycks, D., Lee, K., & Mazeika, M. (2019a). Using pre-training can improve model robustness and uncertainty. In International conference on machine learning (pp. 2712-2721). PMLR.

亨德里克斯(Hendrycks, D.)、李(Lee, K.)和马泽伊卡(Mazeika, M.)(2019a)。使用预训练可以提高模型的鲁棒性和不确定性估计。见国际机器学习会议(第 2712 - 2721 页)。机器学习研究会议录(PMLR)。

Hendrycks, D., Liu, X., Wallace, E., Dziedzic, A., Krishnan, R., & Song, D. (2020). Pretrained transformers improve out-of-distribution robustness, arXiv preprint arXiv:2004.06100

亨德里克斯(Hendrycks, D.)、刘(Liu, X.)、华莱士(Wallace, E.)、迪齐奇(Dziedzic, A.)、克里什南(Krishnan, R.)和宋(Song, D.)(2020 年)。预训练的变换器可提高分布外鲁棒性，预印本 arXiv:2004.06100

Hendrycks, D., & Mazeika, M. (2022). X-risk analysis for AI research.

亨德里克斯(Hendrycks)，D.，& 梅泽卡(Mazeika)，M.(2022)。人工智能研究的存在性风险分析。

arXiv preprint, arXiv:2206.05862

预印本，arXiv:2206.05862

Hendrycks, D., Mazeika, M., & Dietterich, T. (2019b). Deep anomaly detection with outlier exposure. In ${ICLR}$ .

亨德里克斯(Hendrycks)，D.，梅泽卡(Mazeika)，M.，& 迪特里希(Dietterich)，T.(2019b)。通过异常值暴露进行深度异常检测。见${ICLR}$。

Hendrycks, D., Mu, N., Cubuk, E. D., Zoph, B., Gilmer, J., & Lak-shminarayanan, B. (2019c). Augmix: A simple data processing method to improve robustness and uncertainty. arXiv preprint arXiv:1912.02781

亨德里克斯(Hendrycks)，D.，穆(Mu)，N.，丘布克(Cubuk)，E. D.，佐夫(Zoph)，B.，吉尔默(Gilmer)，J.，& 拉克什米纳拉亚南(Lak-shminarayanan)，B.(2019c)。Augmix:一种提高鲁棒性和不确定性的简单数据处理方法。预印本 arXiv:1912.02781

Hendrycks, D., Zou, A., Mazeika, M., Tang, L., Song, D., & Steinhardt, J. (2022c). Pixmix: Dreamlike pictures comprehensively improve safety measures.

亨德里克斯(Hendrycks)，D.，邹(Zou)，A.，梅泽卡(Mazeika)，M.，唐(Tang)，L.，宋(Song)，D.，& 斯坦哈特(Steinhardt)，J.(2022c)。Pixmix:梦幻般的图片全面提升安全措施。

Hodge, V., & Austin, J. (2004). A survey of outlier detection methodologies. Artificial Intelligence Review, 22, 85-126.

霍奇(Hodge)，V.，& 奥斯汀(Austin)，J.(2004)。异常值检测方法综述。《人工智能评论》，22，85 - 126。

Hsu, Y.-C., Shen, Y., Jin, H., & Kira, Z. (2020). Generalized odin: Detecting out-of-distribution image without learning from out-of-distribution data. In ${CVPR}$ .

许(Hsu)，Y.-C.，沈(Shen)，Y.，金(Jin)，H.，& 基拉(Kira)，Z.(2020)。广义奥丁(ODIN):无需从分布外数据学习即可检测分布外图像。见${CVPR}$。

Hu, W., Gao, J., Li, B., Wu, O., Du, J., & Maybank, S. (2018). Anomaly detection using local kernel density estimation and context-based regression. In ${TKDE}$ .

胡(Hu)，W.，高(Gao)，J.，李(Li)，B.，吴(Wu)，O.，杜(Du)，J.，& 梅班克(Maybank)，S.(2018)。使用局部核密度估计和基于上下文的回归进行异常检测。见${TKDE}$。

Huang, H., Li, Z., Wang, L., Chen, S., Dong, B., & Zhou, X. (2020a). Feature space singularity for out-of-distribution detection, arXiv preprint arXiv:2011.14654

黄(Huang)，H.，李(Li)，Z.，王(Wang)，L.，陈(Chen)，S.，董(Dong)，B.，& 周(Zhou)，X.(2020a)。用于分布外检测的特征空间奇异性，预印本 arXiv:2011.14654

Huang, R., Geng, A., & Li, Y. (2021). On the importance of gradients for detecting distributional shifts in the wild. In NeurIPS.

黄(Huang)，R.，耿(Geng)，A.，& 李(Li)，Y.(2021)。梯度对于检测现实世界中分布变化的重要性。见神经信息处理系统大会(NeurIPS)。

Huang, R., & Li, Y. (2021). Mos: Towards scaling out-of-distribution detection for large semantic space. In ${CVPR}$ .

黄(Huang)，R.，& 李(Li)，Y.(2021)。MOS:实现大语义空间的分布外检测扩展。见${CVPR}$。

Huang, X., Kroening, D., Ruan, W., Sharp, J., Sun, Y., Thamo, E., Wu, M., & Yi, X. (2020b). A survey of safety and trustworthiness of deep neural networks: Verification, testing, adversarial attack and defence, and interpretability. Computer Science Review, 37, 100270.

黄(Huang)，X.，克罗宁(Kroening)，D.，阮(Ruan)，W.，夏普(Sharp)，J.，孙(Sun)，Y.，萨莫(Thamo)，E.，吴(Wu)，M.，& 易(Yi)，X.(2020b)。深度神经网络安全性和可信度综述:验证、测试、对抗攻击与防御以及可解释性。《计算机科学评论》，37，100270。

Hyvärinen, A., & Dayan, P. (2005). Estimation of non-normalized statistical models by score matching.

海瓦里宁(Hyvärinen)，A.，& 戴扬(Dayan)，P.(2005)。通过得分匹配估计非归一化统计模型。

Idrees, H., Shah, M., & Surette, R. (2018). Enhancing camera surveillance using computer vision: A research note. Policing: An International Journal, 41, 292-307.

伊德里斯(Idrees)，H.，沙阿(Shah)，M.，& 瑟雷特(Surette)，R.(2018)。利用计算机视觉增强摄像头监控:一篇研究笔记。《警务:国际期刊》，41，292 - 307。

Igoe, C., Chung, Y., Char, I., & Schneider, J. (2022). How useful are gradients for ood detection really? arXiv preprint arXiv:2205.10439

伊戈(Igoe)，C.，钟(Chung)，Y.，查尔(Char)，I.，& 施耐德(Schneider)，J.(2022)。梯度对于分布外检测到底有多有用？预印本 arXiv:2205.10439

Izenman, A. J. (1991). Review papers: Recent developments in nonparametric density estimation. Journal of the American Statistical Association, 86, 205-224.

伊曾曼(Izenman)，A. J.(1991)。综述文章:非参数密度估计的最新进展。《美国统计协会杂志》，86，205 - 224。

Jain, L. P., Scheirer, W. J., & Boult, T. E. (2014). Multi-class open set recognition using probability of inclusion. In ${ECCV}$ .

贾恩(Jain)，L. P.，谢勒(Scheirer)，W. J.，& 博尔特(Boult)，T. E.(2014)。使用包含概率的多类开放集识别。见${ECCV}$。

Jang, J., & Kim, C. O. (2020). One-vs-rest network-based deep probability model for open set recognition, arXiv preprint arXiv:2004.08067

张(Jang)，J.，& 金(Kim)，C. O.(2020)。基于一对多网络的深度概率模型用于开放集识别，预印本arXiv:2004.08067

Jaskie, K., & Spanias, A. (2019). Positive and unlabeled learning algorithms and applications: A survey. In International conference on information, intelligence, systems and applications.

贾斯基(Jaskie)，K.，& 斯帕尼亚斯(Spanias)，A.(2019)。正样本和无标签学习算法及其应用:综述。见国际信息、智能、系统与应用会议。

Jaynes, E. T. (1986). Bayesian methods: General background.

杰恩斯(Jaynes)，E. T.(1986)。贝叶斯方法:一般背景。

Jeong, T., & Kim, H. (2020). Ood-maml: Meta-learning for few-shot out-of-distribution detection and classification. In NeurIPS.

郑(Jeong)，T.，& 金(Kim)，H.(2020)。Ood - maml:用于小样本分布外检测和分类的元学习。见神经信息处理系统大会(NeurIPS)。

Jia, M., Tang, L., Chen, B.-C., Cardie, C., Belongie, S., Hariharan, B., & Lim, S.-N. (2022). Visual prompt tuning. In European conference on computer vision (pp. 709-727). Springer.

贾(Jia)，M.，唐(Tang)，L.，陈(Chen)，B. - C.，卡迪(Cardie)，C.，贝隆吉(Belongie)，S.，哈里哈兰(Hariharan)，B.，& 林(Lim)，S. - N.(2022)。视觉提示调优。见欧洲计算机视觉会议(第709 - 727页)。施普林格出版社。

Jia, X., Han, K., Zhu, Y., & Green, B. (2021). Joint representation learning and novel category discovery on single-and multi-modal data. In ${ICCV}$ .

贾(Jia)，X.，韩(Han)，K.，朱(Zhu)，Y.，& 格林(Green)，B.(2021)。单模态和多模态数据的联合表示学习与新类别发现。见${ICCV}$。

Jiang, D., Sun, S., & Yu, Y. (2021a). Revisiting flow generative models for out-of-distribution detection. In International conference on learning representations.

蒋(Jiang)，D.，孙(Sun)，S.，& 余(Yu)，Y.(2021a)。重新审视用于分布外检测的流生成模型。见国际学习表征会议。

Jiang, K., Xie, W., Lei, J., Jiang, T., & Li, Y. (2021b). Lren: Low-rank embedded network for sample-free hyperspectral anomaly

蒋(Jiang)，K.，谢(Xie)，W.，雷(Lei)，J.，蒋(Jiang)，T.，& 李(Li)，Y.(2021b)。Lren:用于无样本高光谱异常

detection. In ${AAAI}$ .

检测的低秩嵌入网络。见${AAAI}$。

Jiang, L., Guo, Z., Wu, W., Liu, Z., Liu, Z., Loy, C.C., Yang, S., Xiong, Y., Xia, W., Chen, B., Zhuang, P., Li, S., Chen, S., Yao, T., Ding, S., Li, J., Huang, F., Cao, L., Ji, R., Lu, C., & Tan, G. (2021c). Deep-erForensics Challenge 2020 on real-world face forgery detection: Methods and results, arXiv preprint arXiv:2102.09471

蒋(Jiang)，L.，郭(Guo)，Z.，吴(Wu)，W.，刘(Liu)，Z.，刘(Liu)，Z.，洛伊(Loy)，C. C.，杨(Yang)，S.，熊(Xiong)，Y.，夏(Xia)，W.，陈(Chen)，B.，庄(Zhuang)，P.，李(Li)，S.，陈(Chen)，S.，姚(Yao)，T.，丁(Ding)，S.，李(Li)，J.，黄(Huang)，F.，曹(Cao)，L.，季(Ji)，R.，陆(Lu)，C.，& 谭(Tan)，G.(2021c)。2020年现实世界人脸伪造检测深度取证挑战赛:方法与结果，预印本arXiv:2102.09471

Jiang, W., Cheng, H., Chen, M., Feng, S., Ge, Y., & Wang, C. (2023a). Read: Aggregating reconstruction error into out-of-distribution detection. In ${AAAI}$ .

蒋(Jiang)，W.，程(Cheng)，H.，陈(Chen)，M.，冯(Feng)，S.，葛(Ge)，Y.，& 王(Wang)，C.(2023a)。Read:将重建误差聚合到分布外检测中。见${AAAI}$。

Jiang, X., Liu, F., Fang, Z., Chen, H., Liu, T., Zheng, F., & Han, B. (2023b). Detecting out-of-distribution data through in-distribution class prior. In International conference on machine learning (pp. 15067-15088). PMLR.

蒋(Jiang)，X.，刘(Liu)，F.，方(Fang)，Z.，陈(Chen)，H.，刘(Liu)，T.，郑(Zheng)，F.，& 韩(Han)，B.(2023b)。通过分布内类别先验检测分布外数据。见国际机器学习会议(第15067 - 15088页)。机器学习研究会议录(PMLR)。

Jiang, X., Liu, F., Fang, Z., Chen, H., Liu, T., Zheng, F., & Han, B. (2023c). Negative label guided ood detection with pretrained vision-language models. In The twelfth international conference on learning representations.

蒋(Jiang)，X.，刘(Liu)，F.，方(Fang)，Z.，陈(Chen)，H.，刘(Liu)，T.，郑(Zheng)，F.，& 韩(Han)，B.(2023c)。使用预训练视觉 - 语言模型的负标签引导分布外检测。见第十二届国际学习表征会议。

Joseph, K., Paul, S., Aggarwal, G., Biswas, S., Rai, P., Han, K., & Balasubramanian, V. N. (2022). Novel class discovery without forgetting. In ${ECCV}$ .

约瑟夫(Joseph)，K.，保罗(Paul)，S.，阿加瓦尔(Aggarwal)，G.，比斯瓦斯(Biswas)，S.，拉伊(Rai)，P.，韩(Han)，K.，& 巴拉苏布拉马尼亚姆(Balasubramanian)，V. N.(2022)。不遗忘的新类别发现。见${ECCV}$。

Júnior, P.R.M., De Souza, R. M., Werneck, R. D. O., Stein, B. V., Paz-inato, D. V., de Almeida, W. R., Penatti, O. A., Torres, R. D. S., & Rocha, A. (2017). Nearest neighbors distance ratio open-set classifier. Machine Learning, 6, 66.

小朱尼尔(Júnior)，P. R. M.，德索萨(De Souza)，R. M.，韦内克(Werneck)，R. D. O.，斯坦(Stein)，B. V.，帕齐纳托(Paz - inato)，D. V.，德阿尔梅达(de Almeida)，W. R.，佩纳蒂(Penatti)，O. A.，托雷斯(Torres)，R. D. S.，& 罗查(Rocha)，A.(2017)。最近邻距离比开放集分类器。《机器学习》，6，66。

Katz-Samuels, J., Nakhleh, J., Nowak, R., & Li, Y. (2022). Training ood detectors in their natural habitats. In International conference on machine learning (ICML). PMLR.

卡茨 - 塞缪尔斯(Katz - Samuels)，J.，纳赫勒(Nakhleh)，J.，诺瓦克(Nowak)，R.，& 李(Li)，Y. (2022)。在自然环境中训练分布外(OOD)检测器。见国际机器学习会议(ICML)。机器学习研究会议录(PMLR)。

Kaur, R., Jha, S., Roy, A., Park, S., Dobriban, E., Sokolsky, O., & Lee, I. (2022a). idecode: In-distribution equivariance for conformal out-of-distribution detection. In Proceedings of the AAAI conference on artificial intelligence (vol. 36, pp. 7104-7114).

考尔(Kaur)，R.，贾(Jha)，S.，罗伊(Roy)，A.，朴(Park)，S.，多布里班(Dobriban)，E.，索科尔斯基(Sokolsky)，O.，& 李(Lee)，I. (2022a)。idecode:用于共形分布外检测的分布内等变性。见美国人工智能协会会议论文集(第36卷，第7104 - 7114页)。

Kaur, R., Sridhar, K., Park, S., Jha, S., Roy, A., Sokolsky, O., & Lee, I. (2022b). Codit: Conformal out-of-distribution detection in time-series data, arXiv e-prints.

考尔(Kaur)，R.，斯里达尔(Sridhar)，K.，朴(Park)，S.，贾(Jha)，S.，罗伊(Roy)，A.，索科尔斯基(Sokolsky)，O.，& 李(Lee)，I. (2022b)。Codit:时间序列数据中的共形分布外检测，arXiv预印本。

Kerner, H. R., Wellington, D. F., Wagstaff, K. L., Bell, J. F., Kwan, C., & Amor, H. B. (2019). Novelty detection for multispectral images with application to planetary exploration. In AAAI.

克纳(Kerner)，H. R.，惠灵顿(Wellington)，D. F.，瓦格斯塔夫(Wagstaff)，K. L.，贝尔(Bell)，J. F.，关(Kwan)，C.，& 阿莫尔(Amor)，H. B. (2019)。用于多光谱图像的新奇性检测及其在行星探索中的应用。见美国人工智能协会会议(AAAI)。

Kim, J.-H., Yun, S., & Song, H. O. (2023). Neural relation graph: A unified framework for identifying label noise and outlier data. In Thirty-seventh conference on neural information processing systems.

金(Kim)，J. - H.，尹(Yun)，S.，& 宋(Song)，H. O. (2023)。神经关系图:一种识别标签噪声和离群数据的统一框架。见第三十七届神经信息处理系统会议。

Kim, K., Shin, J., & Kim, H. (2021). Locally most powerful Bayesian test for out-of-distribution detection using deep generative models. In NeurIPS.

金(Kim)，K.，申(Shin)，J.，& 金(Kim)，H. (2021)。使用深度生成模型进行分布外检测的局部最强大贝叶斯检验。见神经信息处理系统大会(NeurIPS)。

Kind, A., Stoecklin, M. P., & Dimitropoulos, X. (2009). Histogram-based traffic anomaly detection. IEEE Transactions on Network and Service Management, 6, 110-121.

金德(Kind)，A.，施托克林(Stoecklin)，M. P.，& 季米特罗普洛斯(Dimitropoulos)，X. (2009)。基于直方图的流量异常检测。《IEEE网络与服务管理汇刊》，6，110 - 121。

Kingma, D. P., & Dhariwal, P. (2018). Glow: Generative flow with invertible 1x1 convolutions. In NeurIPS.

金玛(Kingma)，D. P.，& 达里瓦尔(Dhariwal)，P. (2018)。Glow:具有可逆1x1卷积的生成流。见神经信息处理系统大会(NeurIPS)。

Kingma, D. P., & Welling, M. (2013). Auto-encoding variational Bayes, arXiv preprint arXiv:1312.6114

金玛(Kingma)，D. P.，& 韦林(Welling)，M. (2013)。自动编码变分贝叶斯，arXiv预印本arXiv:1312.6114

Kirichenko, P., Izmailov, P., & Wilson, A. G. (2020). Why normalizing flows fail to detect out-of-distribution data. in NeurIPS.

基里琴科(Kirichenko)，P.，伊兹马伊洛夫(Izmailov)，P.，& 威尔逊(Wilson)，A. G. (2020)。为什么归一化流无法检测分布外数据。见神经信息处理系统大会(NeurIPS)。

Kobyzev, I., Prince, S., & Brubaker, M. (2020). Normalizing flows: An introduction and review of current methods. In TPAMI.

科比泽夫(Kobyzev)，I.，普林斯(Prince)，S.，& 布鲁贝克(Brubaker)，M. (2020)。归一化流:当前方法的介绍与综述。见《模式分析与机器智能汇刊》(TPAMI)。

Koh, P. W., Sagawa, S., Marklund, H., Xie, S. M., Zhang, M., Balsubra-mani, A., Hu, W., Yasunaga, M., Phillips, R. L., Gao, I., & Lee, T. (2021). Wilds: A benchmark of in-the-wild distribution shifts. In International conference on machine learning (pp. 5637-5664). PMLR.

 Koh，P. W.，Sagawa，S.，Marklund，H.，Xie，S. M.，Zhang，M.，Balsubra - mani，A.，Hu，W.，Yasunaga，M.，Phillips，R. L.，Gao，I.，& Lee，T. (2021)。Wilds:一个野外分布偏移的基准。见国际机器学习会议(第5637 - 5664页)。机器学习研究会议录(PMLR)。

Kong, S., & Ramanan, D. (2021). Opengan: Open-set recognition via open data generation. In ${ICCV}$ .

孔(Kong)，S.，& 拉马南(Ramanan)，D. (2021)。Opengan:通过开放数据生成进行开放集识别。见${ICCV}$ 。

Kou, Y., Lu, C.-T., & Dos Santos, R. F. (2007). Spatial outlier detection: A graph-based approach. In 19th IEEE international conference on tools with artificial intelligence (ICTAI).

寇(Kou)，Y.，卢(Lu)，C. - T.，& 多斯桑托斯(Dos Santos)，R. F. (2007)。空间离群点检测:一种基于图的方法。见第19届IEEE人工智能工具国际会议(ICTAI)。

Kramer, M. A. (1991). Nonlinear principal component analysis using

克莱默(Kramer)，M. A. (1991)。使用

autoassociative neural networks. AIChE Journal, 37, 233-243.

自联想神经网络的非线性主成分分析。《美国化学工程师学会杂志》，37，233 - 243。

Krizhevsky, A., & Hinton, G. (2009). Learning multiple layers of features from tiny images.

克里热夫斯基(Krizhevsky)，A.，& 辛顿(Hinton)，G.(2009)。从微小图像中学习多层特征。

Krizhevsky, A., Nair, V., & Hinton, G. (2009). Cifar-10 and cifar-100 datasets (vol. 6, (no. 1), p. 1). https://www.cs.toronto.edu/kriz/ cifar.html

克里热夫斯基(Krizhevsky)，A.，奈尔(Nair)，V.，& 辛顿(Hinton)，G.(2009)。Cifar - 10和Cifar - 100数据集(第6卷，第1期，第1页)。https://www.cs.toronto.edu/kriz/ cifar.html

Krizhevsky, A., Sutskever, I., & Hinton, G. E. (2012). Imagenet classification with deep convolutional neural networks. In NIPS.

克里热夫斯基(Krizhevsky)，A.，苏斯克维(Sutskever)，I.，& 辛顿(Hinton)，G. E.(2012)。使用深度卷积神经网络进行ImageNet图像分类。发表于神经信息处理系统大会(NIPS)。

Kwon, G., Prabhushankar, M., Temel, D., & AlRegib, G. (2020). Backpropagated gradient representations for anomaly detection. In ${ECCV}$ .

权(Kwon)，G.，普拉布尚卡尔(Prabhushankar)，M.，特梅尔(Temel)，D.，& 阿尔雷吉布(AlRegib)，G.(2020)。用于异常检测的反向传播梯度表示。发表于${ECCV}$。

Kylberg, G. (2011). Kylberg texture dataset v. 1.0.

凯尔伯格(Kylberg)，G.(2011)。凯尔伯格纹理数据集1.0版。

Lai, C.-H., Zou, D., & Lerman, G. (2020). Robust subspace recovery layer for unsupervised anomaly detection. In ICLR.

赖(Lai)，C. - H.，邹(Zou)，D.，& 勒曼(Lerman)，G.(2020)。用于无监督异常检测的鲁棒子空间恢复层。发表于国际学习表征会议(ICLR)。

Lakshminarayanan, B., Pritzel, A., & Blundell, C. (2017). Simple and scalable predictive uncertainty estimation using deep ensembles. In NeurIPS.

拉克什米纳拉亚南(Lakshminarayanan)，B.，普里策尔(Pritzel)，A.，& 布伦德尔(Blundell)，C.(2017)。使用深度集成进行简单且可扩展的预测不确定性估计。发表于神经信息处理系统大会(NeurIPS)。

LeCun, Y., & Cortes, C. (2005). The mnist database of handwritten digits.

勒昆(LeCun)，Y.，& 科尔特斯(Cortes)，C.(2005)。手写数字MNIST数据库。

Lee, K., Lee, H., Lee, K., & Shin, J. (2018a). Training confidence-calibrated classifiers for detecting out-of-distribution samples.

李(Lee)，K.，李(Lee)，H.，李(Lee)，K.，& 申(Shin)，J.(2018a)。训练用于检测分布外样本的置信度校准分类器。

Lee, K., Lee, K., Lee, H., & Shin, J. (2018b). A simple unified framework for detecting out-of-distribution samples and adversarial attacks. In NeurIPS.

李(Lee)，K.，李(Lee)，K.，李(Lee)，H.，& 申(Shin)，J.(2018b)。用于检测分布外样本和对抗攻击的简单统一框架。发表于神经信息处理系统大会(NeurIPS)。

Lee, K., Lee, K., Min, K., Zhang, Y., Shin, J., & Lee, H. (2018c). Hierarchical novelty detection for visual object recognition. In CVPR.

李(Lee)，K.，李(Lee)，K.，闵(Min)，K.，张(Zhang)，Y.，申(Shin)，J.，& 李(Lee)，H.(2018c)。用于视觉对象识别的分层新奇性检测。发表于计算机视觉与模式识别会议(CVPR)。

Leys, C., Klein, O., Dominicy, Y., & Ley, C. (2018). Detecting multivariate outliers: Use a robust variant of the Mahalanobis distance. Journal of Experimental Social Psychology, 74, 150-156.

莱伊斯(Leys)，C.，克莱因(Klein)，O.，多米尼西(Dominicy)，Y.，& 莱伊(Ley)，C.(2018)。检测多元异常值:使用马氏距离(Mahalanobis distance)的稳健变体。《实验社会心理学杂志》，74，150 - 156。

Leys, C., Ley, C., Klein, O., Bernard, P., & Licata, L. (2013). Detecting outliers: Do not use standard deviation around the mean, use absolute deviation around the median. Journal of Experimental Social Psychology, 49(4), 764-766.

莱伊斯(Leys)，C.，莱伊(Ley)，C.，克莱因(Klein)，O.，伯纳德(Bernard)，P.，& 利卡塔(Licata)，L.(2013)。检测异常值:不要使用均值的标准差，而应使用中位数的绝对偏差。《实验社会心理学杂志》，49(4)，764 - 766。

Li, A., Miao, Z., Cen, Y., & Cen, Y. (2017a). Anomaly detection using sparse reconstruction in crowded scenes. Multimedia Tools and Applications, 76, 26249-26271.

李(Li)，A.，苗(Miao)，Z.，岑(Cen)，Y.，& 岑(Cen)，Y.(2017a)。在拥挤场景中使用稀疏重建进行异常检测。《多媒体工具与应用》，76，26249 - 26271。

Li, B., Zhang, Y., Chen, L., Wang, J., Yang, J., & Liu, Z. (2023a). Otter: A multi-modal model with in-context instruction tuning, arXiv preprint arXiv:2305.03726

李(Li)，B.，张(Zhang)，Y.，陈(Chen)，L.，王(Wang)，J.，杨(Yang)，J.，& 刘(Liu)，Z.(2023a)。水獭(Otter):一种具有上下文指令调优的多模态模型，预印本arXiv:2305.03726

Li, D., Yang, Y., Song, Y.-Z., & Hospedales, T. M. (2017b). Deeper, broader and artier domain generalization. In ${ICCV}$ .

李(Li)，D.，杨(Yang)，Y.，宋(Song)，Y. - Z.，& 霍斯佩代尔斯(Hospedales)，T. M.(2017b)。更深、更广、更具艺术性的领域泛化。发表于${ICCV}$。

Li, J., Chen, P., Yu, S., He, Z., Liu, S., & Jia, J. (2023b). Rethinking out-of-distribution (ood) detection: Masked image modeling is all you need. In ${CVPR}$ .

李，J.，陈，P.，余，S.，何，Z.，刘，S.，& 贾，J.(2023b)。重新思考分布外(OOD)检测:你只需要掩码图像建模。见${CVPR}$。

Li, J., Xiong, C., & Hoi, S. C. (2021). Mopro: Webly supervised learning with momentum prototypes. In ICLR.

李，J.，熊，C.，& 霍伊，S. C.(2021)。Mopro:基于动量原型的弱监督学习。见国际学习表征会议(ICLR)。

Li, L.-J., & Fei-Fei, L. (2010). Optimol: Automatic online picture collection via incremental model learning. In ${IJCV}$ .

李，L.-J.，& 费菲，L.(2010)。Optimol:通过增量模型学习实现自动在线图片收集。见${IJCV}$。

Li, Y., & Vasconcelos, N. (2020). Background data resampling for outlier-aware classification. In ${CVPR}$ .

李，Y.，& 瓦斯康塞洛斯，N.(2020)。用于异常感知分类的背景数据重采样。见${CVPR}$。

Li, Y., Yang, J., Song, Y., Cao, L., Luo, J., & Li, L.-J. (2017). Learning from noisy labels with distillation. In ${CVPR}$ .

李，Y.，杨，J.，宋，Y.，曹，L.，罗，J.，& 李，L.-J.(2017)。通过蒸馏从含噪标签中学习。见${CVPR}$。

Liang, S., Li, Y., & Srikant, R. (2018). Enhancing the reliability of out-of-distribution image detection in neural networks. In ICLR.

梁，S.，李，Y.，& 斯里坎特，R.(2018)。提高神经网络中分布外图像检测的可靠性。见国际学习表征会议(ICLR)。

Lin, Z., Roy, S.D., & Li, Y. (2021). Mood: Multi-level out-of-distribution detection. In ${CVPR}$ .

林，Z.，罗伊，S.D.，& 李，Y.(2021)。Mood:多级分布外检测。见${CVPR}$。

Linderman, R., Zhang, J., Inkawhich, N., Li, H., & Chen, Y. (2023). Fine-grain inference on out-of-distribution data with hierarchical classification. In S. Chandar, R. Pascanu, H. Sedghi, & D. Pre-cup (Eds.) Proceedings of the 2nd conference on lifelong learning agents (vol. 232 of Proceedings of Machine Learning Research, pp. 162-183). PMLR.

林德曼，R.，张，J.，英卡维奇，N.，李，H.，& 陈，Y.(2023)。使用层次分类对分布外数据进行细粒度推理。见S. 钱达尔、R. 帕斯卡努、H. 塞德吉和D. 普雷卡普(编)《第二届终身学习智能体会议论文集》(《机器学习研究会议录》第232卷，第162 - 183页)。机器学习研究会议录(PMLR)。

Liu, B., Kang, H., Li, H., Hua, G., & Vasconcelos, N. (2020a). Few-shot

刘，B.，康，H.，李，H.，华，G.，& 瓦斯康塞洛斯，N.(2020a)。少样本

open-set recognition using meta-learning. In ${CVPR}$ .

使用元学习的开放集识别。见${CVPR}$。

Liu, F. T., Ting, K. M., & Zhou, Z.-H. (2008). Isolation forest. In ICDM.

刘，F. T.，廷，K. M.，& 周，Z.-H.(2008)。隔离森林。见数据挖掘国际会议(ICDM)。

Liu, H., Li, C., Wu, Q., & Lee, Y. J. (2023). Visual instruction tuning, arXiv preprint arXiv:2304.08485

刘，H.，李，C.，吴，Q.，& 李，Y. J.(2023)。视觉指令调优，预印本arXiv:2304.08485

Liu, H., Li, X., Zhou, W., Chen, Y., He, Y., Xue, H., Zhang, W., & Yu, N. (2021). Spatial-phase shallow learning: Rethinking face forgery detection in frequency domain. In ${CVPR}$ .

刘，H.，李，X.，周，W.，陈，Y.，何，Y.，薛，H.，张，W.，& 余，N.(2021)。空间相位浅层学习:重新思考频域中的人脸伪造检测。见${CVPR}$。

Liu, H., Shah, S., & Jiang, W. (2004). On-line outlier detection and data cleaning. Computers & Chemical Engineering, 28, 1635-1647.

刘，H.，沙阿，S.，& 江，W.(2004)。在线异常检测和数据清理。《计算机与化学工程》，28，1635 - 1647。

Liu, J., Lian, Z., Wang, Y., & Xiao, J. (2017). Incremental kernel null space discriminant analysis for novelty detection. In CVPR.

刘，J.，连，Z.，王，Y.，& 肖，J.(2017)。用于新奇检测的增量核零空间判别分析。见计算机视觉与模式识别会议(CVPR)。

Liu, S., Garrepalli, R., Dietterich, T., Fern, A., & Hendrycks, D. (2018a). Open category detection with pac guarantees. In ICML.

刘，S.，加雷帕利，R.，迪特里希，T.，费恩，A.，& 亨德里克斯，D.(2018a)。具有PAC保证的开放类别检测。见国际机器学习会议(ICML)。

Liu, W., He, J., & Chang, S.-F. (2010). Large graph construction for scalable semi-supervised learning. In ${ICML}$ .

刘(Liu)、何(He)和张(Chang)(2010 年)。用于可扩展半监督学习的大图构建。见${ICML}$。

Liu, W., Luo, W., Lian, D., & Gao, S. (2018b). Future frame prediction for anomaly detection-A new baseline. In CVPR.

刘(Liu)、罗(Luo)、连(Lian)和高(Gao)(2018b 年)。用于异常检测的未来帧预测——一种新的基线方法。见计算机视觉与模式识别会议(CVPR)。

Liu, W., Wang, X., Owens, J. D., & Li, Y. (2020b). Energy-based out-of-distribution detection. In NeurIPS.

刘(Liu)、王(Wang)、欧文斯(Owens)和李(Li)(2020b 年)。基于能量的分布外检测。见神经信息处理系统大会(NeurIPS)。

Liu, X., Lochman, Y., & Zach, C. (2023). Gen: Pushing the limits of softmax-based out-of-distribution detection. In Proceedings of the IEEE/CVF conference on computer vision and pattern recognition (pp. 23946-23955).

刘(Liu)、洛赫曼(Lochman)和扎克(Zach)(2023 年)。Gen:突破基于 Softmax 的分布外检测的极限。见电气与电子工程师协会/计算机视觉基金会计算机视觉与模式识别会议论文集(第 23946 - 23955 页)。

Liu, Z., Miao, Z., Pan, X., Zhan, X., Lin, D., Yu, S. X., & Gong, B. (2020c). Open compound domain adaptation. In CVPR.

刘(Liu)、苗(Miao)、潘(Pan)、詹(Zhan)、林(Lin)、余(Yu)和龚(Gong)(2020c 年)。开放复合域适应。见计算机视觉与模式识别会议(CVPR)。

Liu, Z., Miao, Z., Zhan, X., Wang, J., Gong, B., & Yu, S. X. (2019). Large-scale long-tailed recognition in an open world. In CVPR.

刘(Liu)、苗(Miao)、詹(Zhan)、王(Wang)、龚(Gong)和余(Yu)(2019 年)。开放世界中的大规模长尾识别。见计算机视觉与模式识别会议(CVPR)。

Loureiro, A., Torgo, L., & Soares, C. (2004). Outlier detection using clustering methods: A data cleaning application. In Proceedings of KDNet symposium on knowledge-based systems.

洛雷罗(Loureiro)、托尔戈(Torgo)和索阿雷斯(Soares)(2004 年)。使用聚类方法进行离群值检测:一种数据清理应用。见基于知识系统的 KDNet 研讨会论文集。

Lu, F., Zhu, K., Zhai, W., Zheng, K., & Cao, Y. (2023). Uncertainty-aware optimal transport for semantically coherent out-of-distribution detection. In Proceedings of the IEEE/CVF conference on computer vision and pattern recognition (pp. 3282-3291).

陆(Lu)、朱(Zhu)、翟(Zhai)、郑(Zheng)和曹(Cao)(2023 年)。用于语义连贯分布外检测的不确定性感知最优传输。见电气与电子工程师协会/计算机视觉基金会计算机视觉与模式识别会议论文集(第 3282 - 3291 页)。

Lu, F., Zhu, K., Zheng, K., Zhai, W., & Cao, Y. (2023). Likelihood-aware semantic alignment for full-spectrum out-of-distribution detection, arXiv preprint arXiv:2312.01732

陆(Lu)、朱(Zhu)、郑(Zheng)、翟(Zhai)和曹(Cao)(2023 年)。用于全谱分布外检测的似然感知语义对齐，预印本 arXiv:2312.01732

Mackay, D. J. C. (1992). Bayesian methods for adaptive models. PhD thesis, California Institute of Technology.

麦凯(Mackay)(1992 年)。自适应模型的贝叶斯方法。博士论文，加州理工学院。

Maddox, W. J., Izmailov, P., Garipov, T., Vetrov, D. P., & Wilson, A. G. (2019). A simple baseline for Bayesian uncertainty in deep learning. Advances in Neural Information Processing Systems, 32, 13153-13164.

马多克斯(Maddox)、伊斯梅洛夫(Izmailov)、加里波夫(Garipov)、维特罗夫(Vetrov)和威尔逊(Wilson)(2019 年)。深度学习中贝叶斯不确定性的简单基线。《神经信息处理系统进展》，32，13153 - 13164。

Madry, A., Makelov, A., Schmidt, L., Tsipras, D., & Vladu, A. (2018). Towards deep learning models resistant to adversarial attacks, ${ICLR}$ .

马德里(Madry)、马凯洛夫(Makelov)、施密特(Schmidt)、齐普拉斯(Tsipras)和弗拉杜(Vladu)(2018 年)。迈向抗对抗攻击的深度学习模型，${ICLR}$。

Mahdavi, A., & Carvalho, M. (2021). A survey on open set recognition, arXiv preprint arXiv:2109.00893

马赫达维(Mahdavi)和卡瓦略(Carvalho)(2021 年)。开放集识别综述，预印本 arXiv:2109.00893

Malinin, A., & Gales, M. (2018). Predictive uncertainty estimation via prior networks. In NeurIPS.

马利宁(Malinin)和盖尔斯(Gales)(2018 年)。通过先验网络进行预测不确定性估计。见神经信息处理系统大会(NeurIPS)。

Malinin, A., & Gales, M. (2019). Reverse kl-divergence training of prior networks: Improved uncertainty and adversarial robustness. In NeurIPS.

马利宁(Malinin)和盖尔斯(Gales)(2019 年)。先验网络的反向 KL 散度训练:改进的不确定性和对抗鲁棒性。见神经信息处理系统大会(NeurIPS)。

Markou, M., & Singh, S. (2003a). Novelty detection: A review-part 1: Statistical approaches. Signal Processing, 83, 2481-97.

马尔库(Markou)和辛格(Singh)(2003a 年)。新奇性检测:综述——第一部分:统计方法。《信号处理》，83，2481 - 2497。

Markou, M., & Singh, S. (2003b). Novelty detection: A review-part 2: Neural network based approaches. Signal Processing, 83, 2499- 2521.

马尔库(Markou)，M.，& 辛格(Singh)，S.(2003b)。新奇检测:综述 - 第二部分:基于神经网络的方法。《信号处理》(Signal Processing)，83，2499 - 2521。

Masana, M., Ruiz, I., Serrat, J., van de Weijer, J., & Lopez, A. M. (2018). Metric learning for novelty and anomaly detection. In ${BMVC}$ .

马萨纳(Masana)，M.，鲁伊斯(Ruiz)，I.，塞拉特(Serrat)，J.，范德韦杰尔(van de Weijer)，J.，& 洛佩斯(Lopez)，A. M.(2018)。用于新奇和异常检测的度量学习。见 ${BMVC}$。

Meinke, A., & Hein, M. (2019). Towards neural networks that provably know when they don't know, arXiv preprint arXiv:1909.12180

迈因克(Meinke)，A.，& 海因(Hein)，M.(2019)。迈向可证明知道自己未知情况的神经网络，arXiv预印本 arXiv:1909.12180

Miljković, D. (2010). Review of novelty detection methods. In MIPRO. Ming, Y., Cai, Z., Gu, J., Sun, Y., Li, W., & Li, Y. (2022a). Delving into out-of-distribution detection with vision-language representations.

米尔约科维奇(Miljković)，D.(2010)。新奇检测方法综述。见MIPRO。明(Ming)，Y.，蔡(Cai)，Z.，顾(Gu)，J.，孙(Sun)，Y.，李(Li)，W.，& 李(Li)，Y.(2022a)。利用视觉 - 语言表征深入研究分布外检测。

Advances in Neural Information Processing Systems, 35, 35087- 35102.

《神经信息处理系统进展》(Advances in Neural Information Processing Systems)，35，35087 - 35102。

Ming, Y., Fan, Y., & Li, Y. (2022b). Poem: Out-of-distribution detection with posterior sampling. In ${ICML}$ .

明(Ming)，Y.，范(Fan)，Y.，& 李(Li)，Y.(2022b)。诗歌:通过后验采样进行分布外检测。见 ${ICML}$。

Ming, Y., & Li, Y. (2023). How does fine-tuning impact out-of-distribution detection for vision-language models? In ${IJCV}$ .

明(Ming)，Y.，& 李(Li)，Y.(2023)。微调如何影响视觉 - 语言模型的分布外检测？见 ${IJCV}$。

Ming, Y., Sun, Y., Dia, O., & Li, Y. (2023). Cider: Exploiting hyperspherical embeddings for out-of-distribution detection. In ICLR.

明(Ming)，Y.，孙(Sun)，Y.，迪亚(Dia)，O.，& 李(Li)，Y.(2023)。Cider:利用超球面嵌入进行分布外检测。见ICLR。

Ming, Y., Yin, H., & Li, Y. (2022c). On the impact of spurious correlation for out-of-distribution detection. In AAAI.

明(Ming)，Y.，尹(Yin)，H.，& 李(Li)，Y.(2022c)。虚假相关性对分布外检测的影响。见AAAI。

Mingqiang, Z., Hui, H., & Qian, W. (2012). A graph-based clustering algorithm for anomaly intrusion detection. In International conference on Computer Science & Education (ICCSE).

明强(Mingqiang)，Z.，辉(Hui)，H.，& 钱(Qian)，W.(2012)。一种基于图的异常入侵检测聚类算法。见国际计算机科学与教育会议(ICCSE)。

Miyai, A., Yang, J., Zhang, J., Ming, Y., Yu, Q., Irie, G., Li, Y., Li, H., Liu, Z., & Aizawa, K. (2024). Unsolvable problem detection: Evaluating trustworthiness of vision language models. arXiv preprint, arXiv:2403.20331

宫井(Miyai)，A.，杨(Yang)，J.，张(Zhang)，J.，明(Ming)，Y.，余(Yu)，Q.，入江(Irie)，G.，李(Li)，Y.，李(Li)，H.，刘(Liu)，Z.，& 相泽(Aizawa)，K.(2024)。不可解问题检测:评估视觉语言模型的可信度。arXiv预印本，arXiv:2403.20331

Miyai, A., Yu, Q., Irie, G., & Aizawa, K. (2023a). Can pre-trained networks detect familiar out-of-distribution data? arXiv preprint arXiv:2310.00847

宫井(Miyai)，A.，余(Yu)，Q.，入江(Irie)，G.，& 相泽(Aizawa)，K.(2023a)。预训练网络能否检测熟悉的分布外数据？arXiv预印本 arXiv:2310.00847

Miyai, A., Yu, Q., Irie, G., & Aizawa, K. (2023b). Locoop: Few-shot out-of-distribution detection via prompt learning, arXiv preprint arXiv:2306.01293

宫井(Miyai)，A.，余(Yu)，Q.，入江(Irie)，G.，& 相泽(Aizawa)，K.(2023b)。Locoop:通过提示学习进行少样本分布外检测，arXiv预印本 arXiv:2306.01293

Mo, X., Monga, V., Bala, R., & Fan, Z. (2013). Adaptive sparse representations for video anomaly detection. IEEE Transactions on Circuits and Systems for Video Technology, 24(4), 631-45.

莫(Mo)，X.，蒙加(Monga)，V.，巴拉(Bala)，R.，& 范(Fan)，Z.(2013)。用于视频异常检测的自适应稀疏表征。《IEEE电路与系统视频技术汇刊》(IEEE Transactions on Circuits and Systems for Video Technology)，24(4)，631 - 45。

Mohseni, S., Pitale, M., Yadawa, J., & Wang, Z. (2020). Self-supervised learning for generalizable out-of-distribution detection. In AAAI.

莫赫森尼(Mohseni)，S.，皮塔尔(Pitale)，M.，亚达瓦(Yadawa)，J.，& 王(Wang)，Z.(2020)。用于可泛化分布外检测的自监督学习。见AAAI。

Mohseni, S., Wang, H., Yu, Z., Xiao, C., Wang, Z., & Yadawa, J. (2021). Practical machine learning safety: A survey and primer. arXiv preprint, arXiv:2106.04823

莫赫森尼(Mohseni)，S.，王(Wang)，H.，余(Yu)，Z.，肖(Xiao)，C.，王(Wang)，Z.，& 亚达瓦(Yadawa)，J.(2021)。实用机器学习安全:综述与入门。arXiv预印本，arXiv:2106.04823

Morteza, P., & Li, Y. (2022). Provable guarantees for understanding out-of-distribution detection. In ${AAAI}$ .

莫尔塔扎(Morteza)，P.，& 李(Li)，Y.(2022)。理解分布外检测的可证明保证。见${AAAI}$。

Muhlenbach, F., Lallich, S., & Zighed, D. A. (2004). Identifying and handling mislabelled instances. Journal of Intelligent Information Systems, 22, 89-109.

米伦巴赫(Muhlenbach)，F.，拉利希(Lallich)，S.，& 齐格德(Zighed)，D. A.(2004)。识别和处理错误标记的实例。《智能信息系统杂志》，22，89 - 109。

Münz, G., Li, S., & Carle, G. (2007). Traffic anomaly detection using k-means clustering. In GI/ITG workshop MMBnet.

明茨(Münz)，G.，李(Li)，S.，& 卡尔(Carle)，G.(2007)。使用k - 均值聚类进行流量异常检测。见德国信息学会/德国电信技术协会(GI/ITG)MMBnet研讨会。

Nalisnick, E., Matsukawa, A., Teh, Y. W., Gorur, D., & Lakshmi-narayanan, B. (2018). Do deep generative models know what they don't know? In NeurIPS.

纳利斯尼克(Nalisnick)，E.，松川(Matsukawa)，A.， Teh，Y. W.，戈鲁尔(Gorur)，D.，& 拉克什米 - 纳拉亚南(Lakshmi - narayanan)，B.(2018)。深度生成模型知道它们不知道什么吗？见神经信息处理系统大会(NeurIPS)。

Nandy, J., Hsu, W., & Lee, M. L. (2020). Towards maximizing the representation gap between in-domain & out-of-distribution examples. In NeurIPS.

南迪(Nandy)，J.，许(Hsu)，W.，& 李(Lee)，M. L.(2020)。朝着最大化域内和分布外示例之间的表示差距迈进。见神经信息处理系统大会(NeurIPS)。

Neal, L., Olson, M., Fern, X., Wong, W.-K., & Li, F. (2018). Open set learning with counterfactual images. In ${ECCV}$ .

尼尔(Neal)，L.，奥尔森(Olson)，M.，费恩(Fern)，X.，黄(Wong)，W. - K.，& 李(Li)，F.(2018)。使用反事实图像进行开放集学习。见${ECCV}$。

Neal, R. M. (2012). Bayesian learning for neural networks.

尼尔(Neal)，R. M.(2012)。神经网络的贝叶斯学习。

Netzer, Y., Wang, T., Coates, A., Bissacco, A., Wu, B., & Ng, A. Y. (2011). Reading digits in natural images with unsupervised feature learning.

内策尔(Netzer)，Y.，王(Wang)，T.，科茨(Coates)，A.，比萨科(Bissacco)，A.，吴(Wu)，B.，& 吴恩达(Ng)，A. Y.(2011)。通过无监督特征学习读取自然图像中的数字。

Ngiam, J., Chen, Z., Koh, P. W., & Ng, A. Y. (2011). Learning deep energy models. In ${ICML}$ .

尼亚姆(Ngiam)，J.，陈(Chen)，Z.， Koh，P. W.，& 吴恩达(Ng)，A. Y.(2011)。学习深度能量模型。见${ICML}$。

Nguyen, A., Yosinski, J., & Clune, J. (2015). Deep neural networks are easily fooled: High confidence predictions for unrecognizable images. In ${CVPR}$ .

阮(Nguyen)，A.，约辛斯基(Yosinski)，J.，& 克卢恩(Clune)，J.(2015)。深度神经网络很容易被愚弄:对无法识别的图像的高置信度预测。见${CVPR}$。

Nguyen, D. T., Lou, Z., Klar, M., & Brox, T. (2019). Anomaly detection with multiple-hypotheses predictions. In ${ICML}$ .

阮(Nguyen)，D. T.，娄(Lou)，Z.，克拉尔(Klar)，M.，& 布罗克斯(Brox)，T.(2019)。使用多假设预测进行异常检测。见${ICML}$。

Nguyen, D. T., Mummadi, C. K., Ngo, T. P. N., Nguyen, T. H. P., Beggel, L., & Brox, T. (2020). Self: Learning to filter noisy labels with self-ensembling. In ${ICLR}$ .

阮(Nguyen)，D. T.，穆马迪(Mummadi)，C. K.，吴(Ngo)，T. P. N.，阮(Nguyen)，T. H. P.，贝格尔(Beggel)，L.，& 布罗克斯(Brox)，T.(2020)。自我:通过自集成学习过滤噪声标签。见${ICLR}$。

Nguyen, V. D. (2022). Out-of-distribution detection for lidar-based 3d object detection, Master's thesis, University of Waterloo.

阮(Nguyen)，V. D.(2022)。基于激光雷达的3D目标检测的分布外检测，硕士论文，滑铁卢大学。

Nie, J., Zhang, Y., Fang, Z., Liu, T., Han, B., & Tian, X. (2023). Out-of-distribution detection with negative prompts. In The twelfth international conference on learning representations.

聂(Nie)，J.，张(Zhang)，Y.，方(Fang)，Z.，刘(Liu)，T.，韩(Han)，B.，& 田(Tian)，X.(2023)。使用负提示进行分布外检测。见第十二届国际学习表征会议。

Nixon, K. A., Aimale, V., & Rowe, R. K. (2008). Spoof detection schemes. In Handbook of biometrics.

尼克松(Nixon)，K. A.，艾马勒(Aimale)，V.，& 罗(Rowe)，R. K.(2008)。欺骗检测方案。见《生物识别手册》。

Noble, C. C., & Cook, D. J. (2003). Graph-based anomaly detection. In

诺布尔(Noble)，C. C.，& 库克(Cook)，D. J.(2003)。基于图的异常检测。见

SIGKDD.

Orair, G. H., Teixeira, C. H., Meira, W., Jr., Wang, Y., & Parthasarathy, S. (2010). Distance-based outlier detection: consolidation and renewed bearing. In Proceedings of the VLDB endowment.

奥拉伊尔(Orair, G. H.)、特谢拉(Teixeira, C. H.)、小梅拉(Meira, W., Jr.)、王(Wang, Y.)和帕塔萨拉蒂(Parthasarathy, S.)(2010 年)。基于距离的离群点检测:整合与新视角。收录于《VLDB 捐赠会议论文集》。

Osawa, K., Swaroop, S., Jain, A., Eschenhagen, R., Turner, R. E., Yokota, R., & Khan, M. E. (2019). Practical deep learning with Bayesian principles. In NeurIPS.

大泽(Osawa, K.)、斯瓦鲁普(Swaroop, S.)、贾因(Jain, A.)、埃申哈根(Eschenhagen, R.)、特纳(Turner, R. E.)、横田(Yokota, R.)和汗(Khan, M. E.)(2019 年)。基于贝叶斯原理的实用深度学习。收录于神经信息处理系统大会(NeurIPS)。

Oza, P., & Patel, V. M. (2019). C2ae: Class conditioned auto-encoder for open-set recognition. In ${CVPR}$ .

奥扎(Oza, P.)和帕特尔(Patel, V. M.)(2019 年)。C2ae:用于开放集识别的类别条件自编码器。收录于${CVPR}$。

Panareda Busto, P., & Gall, J. (2017). Open set domain adaptation. In ${ICCV}$ .

帕纳雷达·布斯托(Panareda Busto, P.)和加尔(Gall, J.)(2017 年)。开放集领域自适应。收录于${ICCV}$。

Pang, G., Shen, C., Cao, L., & Hengel, A. V. D. (2020). Deep learning for anomaly detection: A review, arXiv preprint arXiv:2007.02500

庞(Pang, G.)、沈(Shen, C.)、曹(Cao, L.)和范登·亨格尔(Hengel, A. V. D.)(2020 年)。用于异常检测的深度学习:综述，预印本 arXiv:2007.02500

Papadopoulos, A.-A., Rajati, M. R., Shaikh, N., & Wang, J. (2021). Outlier exposure with confidence control for out-of-distribution detection. Neurocomputing, 441, 138-150.

帕帕多普洛斯(Papadopoulos, A.-A.)、拉贾蒂(Rajati, M. R.)、谢赫(Shaikh, N.)和王(Wang, J.)(2021 年)。用于分布外检测的带置信度控制的离群点暴露。《神经计算》，441 卷，138 - 150 页。

Park, H., Noh, J., & Ham, B. (2020). Learning memory-guided normality for anomaly detection. In ${CVPR}$ .

朴(Park, H.)、诺(Noh, J.)和哈姆(Ham, B.)(2020 年)。为异常检测学习记忆引导的正常性。收录于${CVPR}$。

Park, J., Chai, J. C. L., Yoon, J., & Teoh, A. B. J. (2023a). Understanding the feature norm for out-of-distribution detection. In Proceedings of the IEEE/CVF international conference on computer vision (pp. 1557-1567).

朴(Park, J.)、柴(Chai, J. C. L.)、尹(Yoon, J.)和张(Teoh, A. B. J.)(2023a)。理解用于分布外检测的特征范数。收录于电气与电子工程师协会/计算机视觉基金会国际计算机视觉会议论文集(第 1557 - 1567 页)。

Park, J., Jung, Y. G., & Teoh, A. B. J. (2023b). Nearest neighbor guidance for out-of-distribution detection. In Proceedings of the IEEE/CVF international conference on computer vision (pp. 1686-1695).

朴(Park, J.)、郑(Jung, Y. G.)和张(Teoh, A. B. J.)(2023b)。用于分布外检测的最近邻引导。收录于电气与电子工程师协会/计算机视觉基金会国际计算机视觉会议论文集(第 1686 - 1695 页)。

Parmar, J., Chouhan, S., Raychoudhury, V., & Rathore, S. (2023). Open-world machine learning: Applications, challenges, and opportunities. ACM Computing Surveys, 55(10), 1-37.

帕尔马(Parmar, J.)、乔汉(Chouhan, S.)、雷乔杜里(Raychoudhury, V.)和拉托雷(Rathore, S.)(2023 年)。开放世界机器学习:应用、挑战与机遇。《ACM 计算调查》，55(10)，1 - 37 页。

Parzen, E. (1962). On estimation of a probability density function and mode. The Annals of Mathematical Statistics, 33, 1065-1076.

帕尔森(Parzen, E.)(1962 年)。关于概率密度函数和众数的估计。《数理统计年鉴》，33 卷，1065 - 1076 页。

Patel, K., Han, H., & Jain, A. K. (2016). Secure face unlock: Spoof detection on smartphones. IEEE Transactions on Information Forensics and Security, 11, 2268-2283.

帕特尔(Patel, K.)、韩(Han, H.)和贾因(Jain, A. K.)(2016 年)。安全面部解锁:智能手机上的欺骗检测。《电气与电子工程师协会信息取证与安全汇刊》，11 卷，2268 - 2283 页。

Pathak, D., Agrawal, P., Efros, A. A., & Darrell, T. (2017). Curiosity-driven exploration by self-supervised prediction. In ICML.

帕塔克(Pathak, D.)、阿格拉瓦尔(Agrawal, P.)、埃弗罗斯(Efros, A. A.)和达雷尔(Darrell, T.)(2017 年)。通过自监督预测进行好奇心驱动的探索。收录于国际机器学习会议(ICML)。

Perera, P., Morariu, V. I., Jain, R., Manjunatha, V., Wigington, C., Ordonez, V., & Patel, V. M. (2020). Generative-discriminative feature representations for open-set recognition. In CVPR.

佩雷拉(Perera, P.)、莫拉里乌(Morariu, V. I.)、贾因(Jain, R.)、曼朱纳塔(Manjunatha, V.)、威金顿(Wigington, C.)、奥尔多涅斯(Ordonez, V.)和帕特尔(Patel, V. M.)(2020 年)。用于开放集识别的生成 - 判别特征表示。收录于计算机视觉与模式识别会议(CVPR)。

Perera, P., Nallapati, R., & Xiang, B. (2019). Ocgan: One-class novelty detection using gans with constrained latent representations. In ${CVPR}$ .

佩雷拉(Perera, P.)、纳拉帕蒂(Nallapati, R.)和向(Xiang, B.)(2019 年)。Ocgan:使用具有受限潜在表示的生成对抗网络进行单类新奇检测。收录于${CVPR}$。

Perera, P., & Patel, V. M. (2019). Deep transfer learning for multiple class novelty detection. In ${CVPR}$ .

佩雷拉(Perera, P.)和帕特尔(Patel, V. M.)(2019 年)。用于多类新奇检测的深度迁移学习。收录于${CVPR}$。

Peterson, C., & Hartman, E. (1989). Explorations of the mean field theory learning algorithm. Neural Networks, 2, 475-494.

彼得森(Peterson)，C.，& 哈特曼(Hartman)，E.(1989)。对平均场理论学习算法的探索。《神经网络》(Neural Networks)，2，475 - 494。

Pidhorskyi, S., Almohsen, R., Adjeroh, D. A., & Doretto, G. (2018). Generative probabilistic novelty detection with adversarial autoen-coders. In NeurIPS.

皮德霍尔斯基(Pidhorskyi)，S.，阿尔莫森(Almohsen)，R.，阿杰罗(Adjeroh)，D. A.，& 多雷托(Doretto)，G.(2018)。使用对抗自编码器进行生成概率新奇检测。发表于神经信息处理系统大会(NeurIPS)。

Pimentel, M. A., Clifton, D. A., Clifton, L., & Tarassenko, L. (2014). A review of novelty detection. Signal Processing, 99, 215-249.

皮门特尔(Pimentel)，M. A.，克利夫顿(Clifton)，D. A.，克利夫顿(Clifton)，L.，& 塔拉森科(Tarassenko)，L.(2014)。新奇检测综述。《信号处理》(Signal Processing)，99，215 - 249。

Pleiss, G., Souza, A., Kim, J., Li, B., & Weinberger, K. Q. (2019). Neural network out-of-distribution detection for regression tasks.

普莱斯(Pleiss)，G.，苏扎(Souza)，A.，金(Kim)，J.，李(Li)，B.，& 温伯格(Weinberger)，K. Q.(2019)。用于回归任务的神经网络分布外检测。

Polatkan, G., Jafarpour, S., Brasoveanu, A., Hughes, S., & Daubechies, I. (2009). Detection of forgery in paintings using supervised learning. In ${ICIP}$ .

波拉坎(Polatkan)，G.，贾法普尔(Jafarpour)，S.，布拉索韦亚努(Brasoveanu)，A.，休斯(Hughes)，S.，& 多贝西(Daubechies)，I.(2009)。使用监督学习检测绘画伪造。发表于${ICIP}$。

Powers, D. M. (2020). Evaluation: From precision, recall and f-measure to roc, informedness, markedness and correlation. In JMLT.

鲍尔斯(Powers)，D. M.(2020)。评估:从精确率、召回率和F值到受试者工作特征曲线(ROC)、信息性、显著性和相关性。发表于《机器学习技术杂志》(JMLT)。

Qui nonero-Candela, J., Sugiyama, M., Lawrence, N. D., & Schwaighofer, A. (2009). Dataset shift in machine learning. MIT Press.

基诺内罗 - 坎德拉(Qui nonero - Candela)，J.，杉山(Sugiyama)，M.，劳伦斯(Lawrence)，N. D.，& 施韦格霍费尔(Schwaighofer)，A.(2009)。机器学习中的数据集偏移。麻省理工学院出版社(MIT Press)。

Radford, A., Kim, J.W., Hallacy, C., Ramesh, A., Goh, G., Agarwal, S., Sastry, G., Askell, A., Mishkin, P., Clark, J., & Krueger, G.

拉德福德(Radford)，A.，金(Kim)，J. W.，哈拉西(Hallacy)，C.，拉梅什(Ramesh)，A.，戈(Goh)，G.，阿加瓦尔(Agarwal)，S.，萨斯特里(Sastry)，G.，阿斯凯尔(Askell)，A.，米什金(Mishkin)，P.，克拉克(Clark)，J.，& 克鲁格(Krueger)，G.

(2021). Learning transferable visual models from natural language supervision. In ${ICML}$ .

(2021). 从自然语言监督中学习可迁移的视觉模型。发表于${ICML}$。

Redner, R. A., & Walker, H. F. (1984). Mixture densities, maximum likelihood and the em algorithm. SIAM Review, 26(2), 195-239.

雷德纳(Redner)，R. A.，& 沃克(Walker)，H. F.(1984)。混合密度、最大似然和期望最大化(EM)算法。《工业与应用数学学会评论》(SIAM Review)，26(2)，195 - 239。

Ren, J., Fort, S., Liu, J., Roy, A. G., Padhy, S., & Lakshminarayanan, B. (2021). A simple fix to Mahalanobis distance for improving near-ood detection, arXiv preprint arXiv:2106.09022

任(Ren)，J.，福特(Fort)，S.，刘(Liu)，J.，罗伊(Roy)，A. G.，帕迪(Padhy)，S.，& 拉克什米纳拉亚南(Lakshminarayanan)，B.(2021)。对马氏距离的一个简单修正以改进近分布外检测，预印本arXiv:2106.09022

Ren, J., Liu, P.J., Fertig, E., Snoek, J., Poplin, R., DePristo, M. A., Dillon, J. V., & Lakshminarayanan, B. (2019). Likelihood ratios for out-of-distribution detection. In NeurIPS.

任(Ren)，J.，刘(Liu)，P. J.，费蒂格(Fertig)，E.，斯诺克(Snoek)，J.，波普林(Poplin)，R.，德普里斯特(DePristo)，M. A.，狄龙(Dillon)，J. V.，& 拉克什米纳拉亚南(Lakshminarayanan)，B.(2019)。用于分布外检测的似然比。发表于神经信息处理系统大会(NeurIPS)。

Rezende, D., & Mohamed, S. (2015). Variational inference with normalizing flows. In ${ICML}$ .

雷曾德(Rezende)，D.，& 穆罕默德(Mohamed)，S.(2015)。使用归一化流的变分推断。发表于${ICML}$。

Rudd, E. M., Jain, L. P., Scheirer, W. J., & Boult, T. E. (2017). The extreme value machine. IEEE Transactions on Pattern Analysis and Machine Intelligence, 40(3), 762-768.

鲁德(Rudd)，E. M.，贾因(Jain)，L. P.，谢勒(Scheirer)，W. J.，& 博尔特(Boult)，T. E.(2017)。极值机。《电气与电子工程师协会模式分析与机器智能汇刊》(IEEE Transactions on Pattern Analysis and Machine Intelligence)，40(3)，762 - 768。

Ruff, L., Kauffmann, J. R., Vandermeulen, R. A., Montavon, G., Samek, W., Kloft, M., Dietterich, T. G., & Müller, K.-R. (2021). A unifying review of deep and shallow anomaly detection. In Proceedings of the IEEE.

鲁夫(Ruff)，L.，考夫曼(Kauffmann)，J. R.，范德梅伦(Vandermeulen)，R. A.，蒙塔冯(Montavon)，G.，萨梅克(Samek)，W.，克洛夫特(Kloft)，M.，迪特里希(Dietterich)，T. G.，& 米勒(Müller)，K. - R.(2021)。深度和浅层异常检测的统一综述。发表于电气与电子工程师协会会议论文集(Proceedings of the IEEE)。

Ruff, L., Vandermeulen, R., Goernitz, N., Deecke, L., Siddiqui, S. A., Binder, A., Müller, E., & Kloft, M. (2018). Deep one-class classification. In ${ICML}$ .

鲁夫(Ruff)，L.，范德梅伦(Vandermeulen)，R.，戈尔尼茨(Goernitz)，N.，德克(Deecke)，L.，西迪基(Siddiqui)，S. A.，宾德(Binder)，A.，米勒(Müller)，E.，& 克洛夫特(Kloft)，M.(2018)。深度一类分类。发表于${ICML}$。

Ruff, L., Vandermeulen, R. A., Görnitz, N., Binder, A., Müller, K.-R. Müller, E., & Kloft, M. (2020). Deep semi-supervised anomaly detection. In ${ICLR}$ .

鲁夫(Ruff, L.)、范德梅伦(Vandermeulen, R. A.)、戈尔尼茨(Görnitz, N.)、宾德(Binder, A.)、米勒(Müller, K.-R.)、米勒(Müller, E.)和克洛夫特(Kloft, M.)(2020 年)。深度半监督异常检测。见${ICLR}$。

Sabokrou, M., Khalooei, M., Fathy, M., & Adeli, E. (2018). Adversar-ially learned one-class classifier for novelty detection. In CVPR.

萨博克罗(Sabokrou, M.)、哈洛埃(Khalooei, M.)、法西(Fathy, M.)和阿德利(Adeli, E.)(2018 年)。用于新奇检测的对抗学习单类分类器。见计算机视觉与模式识别会议(CVPR)。

Salehi, M., Mirzaei, H., Hendrycks, D., Li, Y., Rohban, M. H., & Sabokrou, M. (2021). A unified survey on anomaly, novelty, open-set, and out-of-distribution detection: Solutions and future challenges, arXiv preprint arXiv:2110.14051

萨利希(Salehi, M.)、米尔扎伊(Mirzaei, H.)、亨德里克斯(Hendrycks, D.)、李(Li, Y.)、罗汉(Rohban, M. H.)和萨博克罗(Sabokrou, M.)(2021 年)。异常、新奇、开放集和分布外检测的统一综述:解决方案和未来挑战，预印本 arXiv:2110.14051

Sastry, C. S., & Oore, S. (2019). Detecting out-of-distribution examples with in-distribution examples and gram matrices. In NeurIPS-W.

萨斯特里(Sastry, C. S.)和奥雷(Oore, S.)(2019 年)。使用分布内示例和格拉姆矩阵检测分布外示例。见神经信息处理系统研讨会(NeurIPS - W)。

Sastry, C. S., & Oore, S. (2020). Detecting out-of-distribution examples with gram matrices. In ${ICML}$ .

萨斯特里(Sastry, C. S.)和奥雷(Oore, S.)(2020 年)。使用格拉姆矩阵检测分布外示例。见${ICML}$。

Scheirer, W. J., de Rezende Rocha, A., Sapkota, A., & Boult, T. E. (2013). Toward open set recognition. In TPAMI.

谢勒(Scheirer, W. J.)、德雷森德·罗查(de Rezende Rocha, A.)、萨普科塔(Sapkota, A.)和博尔特(Boult, T. E.)(2013 年)。迈向开放集识别。见《模式分析与机器智能汇刊》(TPAMI)。

Scheirer, W. J., Jain, L. P., & Boult, T. E. (2014). Probability models for open set recognition. In TPAMI.

谢勒(Scheirer, W. J.)、贾因(Jain, L. P.)和博尔特(Boult, T. E.)(2014 年)。开放集识别的概率模型。见《模式分析与机器智能汇刊》(TPAMI)。

Schlachter, P., Liao, Y., & Yang, B. (2019). Open-set recognition using intra-class splitting. In EUSIPCO.

施拉赫特(Schlachter, P.)、廖(Liao, Y.)和杨(Yang, B.)(2019 年)。使用类内分割的开放集识别。见欧洲信号处理会议(EUSIPCO)。

Sedlmeier, A., Gabor, T., Phan, T., Belzner, L., & Linnhoff-Popien, C. (2019). Uncertainty-based out-of-distribution detection in deep reinforcement learning, arXiv preprint arXiv:1901.02219

塞德迈尔(Sedlmeier, A.)、加博尔(Gabor, T.)、潘(Phan, T.)、贝尔兹纳(Belzner, L.)和林霍夫 - 波皮恩(Linnhoff - Popien, C.)(2019 年)。深度强化学习中基于不确定性的分布外检测，预印本 arXiv:1901.02219

Serrà, J., Álvarez, D., Gómez, V., Slizovskaia, O., Núnez, J. F., & Luque, J. (2020). Input complexity and out-of-distribution detection with likelihood-based generative models.

塞拉(Serrà, J.)、阿尔瓦雷斯(Álvarez, D.)、戈麦斯(Gómez, V.)、斯利佐夫斯卡娅(Slizovskaia, O.)、努涅斯(Núnez, J. F.)和卢克(Luque, J.)(2020 年)。基于似然的生成模型的输入复杂度和分布外检测。

Shafaei, A., Schmidt, M., & Little, J. J. (2019). A less biased evaluation of out-of-distribution sample detectors. In ${BMVC}$ .

沙法伊(Shafaei, A.)、施密特(Schmidt, M.)和利特尔(Little, J. J.)(2019 年)。对分布外样本检测器的偏差较小的评估。见${BMVC}$。

Shafer, G., & Vovk, V. (2008). A tutorial on conformal prediction. Journal of Machine Learning Research, 9(3), 66.

谢弗(Shafer, G.)和沃夫克(Vovk, V.)(2008 年)。共形预测教程。《机器学习研究杂志》，9(3)，66。

Shalev, G., Adi, Y., & Keshet, J. (2018). Out-of-distribution detection using multiple semantic label representations. In NeurIPS.

沙莱夫(Shalev, G.)、阿迪(Adi, Y.)和凯舍特(Keshet, J.)(2018 年)。使用多种语义标签表示进行分布外检测。见神经信息处理系统大会(NeurIPS)。

Shalev, G., Shalev, G.-L., & Keshet, J. (2022). A baseline for detecting out-of-distribution examples in image captioning. arXiv preprint, arXiv:2207.05418

沙莱夫(Shalev, G.)、沙莱夫(Shalev, G.-L.)和凯舍特(Keshet, J.)(2022 年)。图像描述中检测分布外示例的基线。预印本，arXiv:2207.05418

Shao, R., Perera, P., Yuen, P. C., & Patel, V. M. (2020). Open-set adversarial defense. In ${ECCV}$ .

邵(Shao, R.)、佩雷拉(Perera, P.)、袁(Yuen, P. C.)和帕特尔(Patel, V. M.)(2020 年)。开放集对抗防御。见${ECCV}$。

Shu, Y., Cao, Z., Wang, C., Wang, J., & Long, M. (2021). Open domain generalization with domain-augmented meta-learning. In CVPR.

舒(Shu, Y.)、曹(Cao, Z.)、王(Wang, C.)、王(Wang, J.)和龙(Long, M.)(2021 年)。使用域增强元学习的开放域泛化。见计算机视觉与模式识别会议(CVPR)。

Shu, Y., Shi, Y., Wang, Y., Huang, T., & Tian, Y. (2020). p-odn: Prototype-based open deep network for open set recognition. Scientific Reports, 10, 7146.

舒，Y.，施，Y.，王，Y.，黄，T.，& 田，Y.(2020)。p - odn:用于开放集识别的基于原型的开放深度网络。《科学报告》，10，7146。

Smith, R. L. (1990). Extreme value theory. Handbook of Applicable Mathematics, 7, 18.

史密斯，R. L.(1990)。极值理论。《应用数学手册》，7，18。

Sorio, E., Bartoli, A., Davanzo, G., & Medvet, E. (2010). Open world

索里奥，E.，巴尔托利，A.，达万佐，G.，& 梅德韦特，E.(2010)。开放世界

classification of printed invoices. In Proceedings of the 10th ACM symposium on document engineering.

印刷发票的分类。见第10届ACM文档工程研讨会会议记录。

Sricharan, K., & Srivastava, A. (2018). Building robust classifiers through generation of confident out of distribution examples. In NeurIPS-W.

斯里查兰，K.，& 斯里瓦斯塔瓦，A.(2018)。通过生成可信的分布外示例构建鲁棒分类器。见神经信息处理系统研讨会(NeurIPS - W)。

Sugiyama, M., & Borgwardt, K. (2013). Rapid distance-based outlier detection via sampling. In NIPS.

杉山，M.，& 博格瓦尔特，K.(2013)。通过采样实现基于距离的快速离群点检测。见神经信息处理系统大会(NIPS)。

Sun, X., Ding, H., Zhang, C., Lin, G., & Ling, K.-V. (2021a). M2iosr: Maximal mutual information open set recognition, arXiv preprint arXiv:2108.02373

孙，X.，丁，H.，张，C.，林，G.，& 凌，K. - V.(2021a)。M2iosr:最大互信息开放集识别，预印本arXiv:2108.02373

Sun, X., Yang, Z., Zhang, C., Ling, K.-V., & Peng, G. (2020). Conditional Gaussian distribution learning for open set recognition. In ${CVPR}$ .

孙，X.，杨，Z.，张，C.，凌，K. - V.，& 彭，G.(2020)。用于开放集识别的条件高斯分布学习。见${CVPR}$。

Sun, Y., Guo, C., & Li, Y. (2021b). React: Out-of-distribution detection with rectified activations. In NeurIPS.

孙，Y.，郭，C.，& 李，Y.(2021b)。React:使用校正激活进行分布外检测。见神经信息处理系统大会(NeurIPS)。

Sun, Y., & Li, Y. (2022). Dice: Leveraging sparsification for out-of-distribution detection. In ${ECCV}$ .

孙，Y.，& 李，Y.(2022)。Dice:利用稀疏化进行分布外检测。见${ECCV}$。

Sun, Y., Ming, Y., Zhu, X., & Li, Y. (2022). Out-of-distribution detection with deep nearest neighbors. In ${ICML}$ .

孙，Y.，明，Y.，朱，X.，& 李，Y.(2022)。使用深度最近邻进行分布外检测。见${ICML}$。

Syarif, I., Prugel-Bennett, A., & Wills, G. (2012). Unsupervised clustering approach for network anomaly detection. In International conference on networked digital technologies.

西亚里夫，I.，普鲁格尔 - 贝内特，A.，& 威尔斯，G.(2012)。用于网络异常检测的无监督聚类方法。见网络数字技术国际会议。

Tack, J., Mo, S., Jeong, J., & Shin, J. (2020). Csi: Novelty detection via contrastive learning on distributionally shifted instances. In NeurIPS.

塔克，J.，莫，S.，郑，J.，& 申，J.(2020)。Csi:通过对分布偏移实例进行对比学习进行新奇性检测。见神经信息处理系统大会(NeurIPS)。

Tao, L., Du, X., Zhu, X., & Li, Y. (2023). Non-parametric outlier synthesis. In ${ICLR}$ .

陶，L.，杜，X.，朱，X.，& 李，Y.(2023)。非参数离群点合成。见${ICLR}$。

Tariq, M. I., Memon, N. A., Ahmed, S., Tayyaba, S., Mushtaq, M. T., Mian, N. A., Imran, M., & Ashraf, M. W. (2020). A review of deep learning security and privacy defensive techniques. Mobile Information Systems, 2020, 1-8.

塔里格，M. I.，梅蒙，N. A.，艾哈迈德，S.，泰亚巴，S.，穆什塔克，M. T.，米安，N. A.，伊姆兰，M.，& 阿什拉夫，M. W.(2020)。深度学习安全与隐私防御技术综述。《移动信息系统》，2020，1 - 8。

Tax, D. M. J. (2002). One-class classification: Concept learning in the absence of counter-examples.

塔克斯，D. M. J.(2002)。一类分类:在没有反例的情况下进行概念学习。

Techapanurak, E., Suganuma, M., & Okatani, T. (2020). Hyperparameter-free out-of-distribution detection using cosine similarity. In ${ACCV}$ .

泰查帕努拉克(Techapanurak)，E.，菅沼(Suganuma)，M.，及冈谷(Okatani)，T.(2020)。使用余弦相似度的无超参数分布外检测。见${ACCV}$。

Thulasidasan, S., Chennupati, G., Bilmes, J., Bhattacharya, T., & Michalak, S. (2019). On mixup training: Improved calibration and predictive uncertainty for deep neural networks. In NeurIPS.

图拉萨迪桑(Thulasidasan)，S.，钱努帕蒂(Chennupati)，G.，比尔梅斯(Bilmes)，J.，巴塔查里亚(Bhattacharya)，T.，及米查拉克(Michalak)，S.(2019)。关于混合训练:提高深度神经网络的校准和预测不确定性。见神经信息处理系统大会(NeurIPS)。

Thulasidasan, S., Thapa, S., Dhaubhadel, S., Chennupati, G., Bhat-tacharya, T., & Bilmes, J. (2021). An effective baseline for robustness to distributional shift, arXiv preprint arXiv:2105.07107

图拉萨迪桑(Thulasidasan)，S.，塔帕(Thapa)，S.，多布哈德尔(Dhaubhadel)，S.，钱努帕蒂(Chennupati)，G.，巴塔查里亚(Bhat - tacharya)，T.，及比尔梅斯(Bilmes)，J.(2021)。应对分布偏移鲁棒性的有效基线，预印本arXiv:2105.07107

Tian, J., Azarian, M. H., & Pecht, M. (2014). Anomaly detection using self-organizing maps-based k-nearest neighbor algorithm. In ${PHM}$ society European conference.

田(Tian)，J.，阿扎里安(Azarian)，M. H.，及佩希特(Pecht)，M.(2014)。使用基于自组织映射的k近邻算法进行异常检测。见${PHM}$协会欧洲会议。

Tian, K., Zhou, S., Fan, J., & Guan, J. (2019). Learning competitive and discriminative reconstructions for anomaly detection. In AAAI.

田(Tian)，K.，周(Zhou)，S.，范(Fan)，J.，及关(Guan)，J.(2019)。学习用于异常检测的竞争性和判别性重建。见美国人工智能协会会议(AAAI)。

Torralba, A., Fergus, R., & Freeman, W. T. (2008). 80 million tiny images: A large data set for nonparametric object and scene recognition. In ${TPAMI}$ .

托拉尔巴(Torralba)，A.，弗格斯(Fergus)，R.，及弗里曼(Freeman)，W. T.(2008)。八千万张小图像:用于非参数对象和场景识别的大型数据集。见${TPAMI}$。

Turcotte, M., Moore, J., Heard, N., & McPhall, A. (2016). Poisson factorization for peer-based anomaly detection. In IEEE conference on intelligence and security informatics (ISI).

图尔科特(Turcotte)，M.，摩尔(Moore)，J.，赫德(Heard)，N.，及麦克法尔(McPhall)，A.(2016)。基于同行的异常检测的泊松因子分解。见电气与电子工程师协会智能与安全信息学会议(IEEE ISI)。

Van Amersfoort, J., Smith, L., Teh, Y. W., & Gal, Y. (2020). Uncertainty estimation using a single deep deterministic neural network. In ${ICML}$ .

范·阿默斯福特(Van Amersfoort)，J.，史密斯(Smith)，L.， Teh，Y. W.，及加尔(Gal)，Y.(2020)。使用单个深度确定性神经网络进行不确定性估计。见${ICML}$。

Van den Broeck, J., Argeseanu Cunningham, S., Eeckels, R., & Herbst, K. (2005). Data cleaning: Detecting, diagnosing, and editing data abnormalities. PLoS Medicine, 2, 267.

范登·布罗克(Van den Broeck)，J.，阿格塞亚努·坎宁安(Argeseanu Cunningham)，S.，埃克尔斯(Eeckels)，R.，及赫布斯特(Herbst)，K.(2005)。数据清理:检测、诊断和编辑数据异常。《公共科学图书馆·医学》，2，267。

Van Oord, A., Kalchbrenner, N., & Kavukcuoglu, K. (2016). Pixel recurrent neural networks. In ${ICML}$ .

范·奥尔德(Van Oord)，A.，卡尔赫布伦纳(Kalchbrenner)，N.，及卡武库奥卢(Kavukcuoglu)，K.(2016)。像素循环神经网络。见${ICML}$。

Van Ryzin, J. (1973). A histogram method of density estimation. Communications in Statistics-Theory and Methods, 2,493-506.

范·赖津(Van Ryzin)，J.(1973)。一种密度估计的直方图方法。《统计学通讯 - 理论与方法》，2，493 - 506。

Vaze, S., Han, K., Vedaldi, A., & Zisserman, A. (2022a). Generalized category discovery. In ${CVPR}$ .

瓦兹(Vaze)，S.，韩(Han)，K.，韦尔迪耶(Vedaldi)，A.，及齐斯曼(Zisserman)，A.(2022a)。广义类别发现。见${CVPR}$。

Vaze, S., Han, K., Vedaldi, A., & Zisserman, A. (2022b). Open-set recognition: A good closed-set classifier is all you need. In ICLR.

瓦兹(Vaze)，S.，韩(Han)，K.，韦尔迪耶(Vedaldi)，A.，及齐斯曼(Zisserman)，A.(2022b)。开放集识别:你只需要一个好的封闭集分类器。见国际学习表征会议(ICLR)。

Vernekar, S., Gaurav, A., Abdelzad, V., Denouden, T., Salay, R., & Czarnecki, K. (2019). Out-of-distribution detection in classifiers

韦尔内卡尔(Vernekar)，S.，高拉夫(Gaurav)，A.，阿卜杜勒扎德(Abdelzad)，V.，德努登(Denouden)，T.，萨莱(Salay)，R.，及恰尔内茨基(Czarnecki)，K.(2019)。分类器中的分布外检测

via generation. In NeurIPS-W.

通过生成方法。见神经信息处理系统大会研讨会(NeurIPS - W)。

Vinyals, O., Ewalds, T., Bartunov, S., Georgiev, P., Vezhnevets, A. S., Yeo, M., Makhzani, A., Küttler, H., Agapiou, J., Schrittwieser, J., & Quan, J. (2017). Starcraft II: A new challenge for reinforcement learning, arXiv preprint arXiv:1708.04782

维尼亚尔斯(Vinyals)，O.，埃瓦尔德斯(Ewalds)，T.，巴尔图诺夫(Bartunov)，S.，格奥尔基耶夫(Georgiev)，P.，韦日涅韦茨(Vezhnevets)，A. S.，杨(Yeo)，M.，马赫扎尼(Makhzani)，A.，库特勒(Küttler)，H.，阿加皮乌(Agapiou)，J.，施里特维泽(Schrittwieser)，J.，及权(Quan)，J.(2017)。《星际争霸II》:强化学习的新挑战，预印本arXiv:1708.04782

Vyas, A., Jammalamadaka, N., Zhu, X., Das, D., Kaul, B., & Willke, T. L. (2018). Out-of-distribution detection using an ensemble of self supervised leave-out classifiers. In ${ECCV}$ .

维亚斯(Vyas)，A.，贾马拉马德卡(Jammalamadaka)，N.，朱(Zhu)，X.，达斯(Das)，D.，考尔(Kaul)，B.，& 威尔克(Willke)，T. L.(2018)。使用自监督留一分类器集成进行分布外检测。见${ECCV}$。

Wang, H., Bah, M. J., & Hammad, M. (2019a). Progress in outlier detection techniques: A survey. IEEE Access, 7, 107964-108000.

王(Wang)，H.，巴赫(Bah)，M. J.，& 哈马德(Hammad)，M.(2019a)。离群值检测技术的进展:综述。《IEEE接入》，7，107964 - 108000。

Wang, H., Li, Y., Yao, H., & Li, X. (2023a). Clipn for zero-shot ood detection: Teaching clip to say no. In Proceedings of the IEEE/CVF international conference on computer vision (pp. 1802-1812).

王(Wang)，H.，李(Li)，Y.，姚(Yao)，H.，& 李(Li)，X.(2023a)。用于零样本分布外检测的Clipn:教会Clip说“不”。见《IEEE/CVF国际计算机视觉会议论文集》(第1802 - 1812页)。

Wang, H., Li, Z., Feng, L., & Zhang, W. (2022a). Vim: Out-of-distribution with virtual-logit matching. In Proceedings of the IEEE/CVF conference on computer vision and pattern recognition.

王(Wang)，H.，李(Li)，Z.，冯(Feng)，L.，& 张(Zhang)，W.(2022a)。Vim:基于虚拟对数匹配的分布外检测。见《IEEE/CVF计算机视觉与模式识别会议论文集》。

Wang, H., Liu, W., Bocchieri, A., & Li, Y. (2021). Can multi-label classification networks know what they don't know? NeurIPS, 34, 29074-29087.

王(Wang)，H.，刘(Liu)，W.，博基耶里(Bocchieri)，A.，& 李(Li)，Y.(2021)。多标签分类网络能知道它们不知道的东西吗？《神经信息处理系统大会》，34，29074 - 29087。

Wang, H., Wu, X., Huang, Z., & Xing, E. P. (2020). High-frequency component helps explain the generalization of convolutional neural networks. In ${CVPR}$ .

王(Wang)，H.，吴(Wu)，X.，黄(Huang)，Z.，& 邢(Xing)，E. P.(2020)。高频分量有助于解释卷积神经网络的泛化能力。见${CVPR}$。

Wang, M., & Deng, W. (2018). Deep visual domain adaptation: A survey. Neurocomputing, 312, 135-153.

王(Wang)，M.，& 邓(Deng)，W.(2018)。深度视觉领域自适应:综述。《神经计算》，312，135 - 153。

Wang, Q., Fang, Z., Zhang, Y., Liu, F., Li, Y., & Han, B. (2023b). Learning to augment distributions for out-of-distribution detection. Advances in Neural Information Processing Systems, 36, 66.

王(Wang)，Q.，方(Fang)，Z.，张(Zhang)，Y.，刘(Liu)，F.，李(Li)，Y.，& 韩(Han)，B.(2023b)。为分布外检测学习增强分布。《神经信息处理系统进展》，36，66。

Wang, Q., Liu, F., Zhang, Y., Zhang, J., Gong, C., Liu, T., & Han, B. (2022b). Watermarking for out-of-distribution detection. In NeurIPS.

王(Wang)，Q.，刘(Liu)，F.，张(Zhang)，Y.，张(Zhang)，J.，龚(Gong)，C.，刘(Liu)，T.，& 韩(Han)，B.(2022b)。用于分布外检测的水印技术。见《神经信息处理系统大会》。

Wang, Q., Ye, J., Liu, F., Dai, Q., Kalander, M., Liu, T., Hao, J., & Han, B. (2023c). Out-of-distribution detection with implicit outlier transformation.

王(Wang)，Q.，叶(Ye)，J.，刘(Liu)，F.，戴(Dai)，Q.，卡兰德(Kalander)，M.，刘(Liu)，T.，郝(Hao)，J.，& 韩(Han)，B.(2023c)。基于隐式离群值变换的分布外检测。

Wang, W., Zheng, V. W., Yu, H., & Miao, C. (2019b). A survey of zero-shot learning: Settings, methods, and applications. In TIST.

王(Wang)，W.，郑(Zheng)，V. W.，余(Yu)，H.，& 苗(Miao)，C.(2019b)。零样本学习综述:设置、方法和应用。见《ACM智能系统与技术汇刊》(TIST)。

Wang, Y., Li, B., Che, T., Zhou, K., Liu, Z., & Li, D. (2021). Energy-based open-world uncertainty modeling for confidence calibration. In ${ICCV}$ .

王(Wang)，Y.，李(Li)，B.，车(Che)，T.，周(Zhou)，K.，刘(Liu)，Z.，& 李(Li)，D.(2021)。基于能量的开放世界不确定性建模用于置信度校准。见${ICCV}$。

Wang, Y., Liu, W., Ma, X., Bailey, J., Zha, H., Song, L., & Xia, S.-T. (2018). Iterative learning with open-set noisy labels. In CVPR.

王(Wang)，Y.，刘(Liu)，W.，马(Ma)，X.，贝利(Bailey)，J.，查(Zha)，H.，宋(Song)，L.，& 夏(Xia)，S.-T.(2018)。使用开放集噪声标签进行迭代学习。见《计算机视觉与模式识别会议》(CVPR)。

Wei, H., Xie, R., Cheng, H., Feng, L., An, B., & Li, Y. (2022). Mitigating neural network overconfidence with logit normalization. In ${ICML}$ .

魏(Wei)，H.，谢(Xie)，R.，程(Cheng)，H.，冯(Feng)，L.，安(An)，B.，& 李(Li)，Y.(2022)。通过对数归一化减轻神经网络的过度自信。见${ICML}$。

Welling, M., & Teh, Y. W. (2011). Bayesian learning via stochastic gradient Langevin dynamics. In ${ICML}$ .

韦林(Welling)，M.，&  Teh，Y. W.(2011)。通过随机梯度朗之万动力学进行贝叶斯学习。见${ICML}$。

Wen, D., Han, H., & Jain, A. K. (2015). Face spoof detection with image distortion analysis. IEEE Transactions on Information Forensics and Security, 10, 746-761.

温(Wen)，D.，韩(Han)，H.，& 贾因(Jain)，A. K.(2015)。基于图像失真分析的人脸欺骗检测。《IEEE信息取证与安全汇刊》，10，746 - 761。

Wenzel, F., Roth, K., Veeling, B. S., Swiatkowski, J., Tran, L., Mandt, S., Snoek, J., Salimans, T., Jenatton, R., & Nowozin, S. (2020). How good is the Bayes posterior in deep neural networks really? In ${ICML}$ .

温泽尔(Wenzel, F.)、罗斯(Roth, K.)、维林(Veeling, B. S.)、斯维亚托夫斯基(Swiatkowski, J.)、陈(Tran, L.)、曼特(Mandt, S.)、斯诺克(Snoek, J.)、萨利曼斯(Salimans, T.)、热纳通(Jenatton, R.)和诺沃津(Nowozin, S.)(2020 年)。深度神经网络中的贝叶斯后验到底有多好？见${ICML}$。

Wettschereck, D. (1994). A study of distance-based machine learning algorithms.

韦特舍雷克(Wettschereck, D.)(1994 年)。基于距离的机器学习算法研究。

Wikipedia contributors. (2021). Outlier from Wikipedia, the free encyclopedia. Retrieved August 12, 2021

维基百科贡献者(2021 年)。来自免费百科全书维基百科的离群值。2021 年 8 月 12 日检索

Wu, X., Lu, J., Fang, Z., & Zhang, G. (2023). Meta ood learning for continuously adaptive ood detection. In Proceedings of the IEEE/CVF international conference on computer vision (pp. 19353-19364).

吴(Wu, X.)、陆(Lu, J.)、方(Fang, Z.)和张(Zhang, G.)(2023 年)。用于连续自适应分布外检测的元分布外学习。见《电气与电子工程师协会/计算机视觉基金会国际计算机视觉会议论文集》(第 19353 - 19364 页)。

Wu, Z.-F., Wei, T., Jiang, J., Mao, C., Tang, M., & Li, Y.-F. (2021). Ngc: A unified framework for learning with open-world noisy data. In ${ICCV}$ .

吴(Wu, Z.-F.)、魏(Wei, T.)、江(Jiang, J.)、毛(Mao, C.)、唐(Tang, M.)和李(Li, Y.-F.)(2021 年)。Ngc:一个用于开放世界噪声数据学习的统一框架。见${ICCV}$。

Xia, Y., Cao, X., Wen, F., Hua, G., & Sun, J. (2015). Learning discriminative reconstructions for unsupervised outlier removal. In ${CVPR}$ .

夏(Xia, Y.)、曹(Cao, X.)、文(Wen, F.)、华(Hua, G.)和孙(Sun, J.)(2015 年)。学习用于无监督离群值去除的判别性重建。见${CVPR}$。

Xiao, T., Zhang, C., & Zha, H. (2015). Learning to detect anomalies in surveillance video. IEEE Signal Processing Letters, 22, 1477- 1481.

肖(Xiao, T.)、张(Zhang, C.)和查(Zha, H.)(2015 年)。学习检测监控视频中的异常。《电气与电子工程师协会信号处理快报》，22 卷，1477 - 1481 页。

Xiao, Y., Wang, H., Xu, W., & Zhou, J. (2013). L1 norm based kpca for novelty detection. Pattern Recognition, 46, 389-396.

肖(Xiao, Y.)、王(Wang, H.)、徐(Xu, W.)和周(Zhou, J.)(2013 年)。基于 L1 范数的核主成分分析用于新奇性检测。《模式识别》，46 卷，389 - 396 页。

Xiao, Z., Yan, Q., & Amit, Y. (2020). Likelihood regret: An out-of-distribution detection score for variational auto-encoder. In NeurIPS.

肖(Xiao, Z.)、严(Yan, Q.)和阿米特(Amit, Y.)(2020 年)。似然遗憾:变分自编码器的分布外检测分数。见神经信息处理系统大会(NeurIPS)。

Xie, M., Hu, J., & Tian, B. (2012). Histogram-based online anomaly detection in hierarchical wireless sensor networks. In ICTSPCC.

谢(Xie, M.)、胡(Hu, J.)和田(Tian, B.)(2012 年)。分层无线传感器网络中基于直方图的在线异常检测。见信息与通信技术系统与产品控制会议(ICTSPCC)。

Xu, H., Liu, B., Shu, L., & Yu, P. (2019). Open-world learning and application to product classification. In ${WWW}$ .

徐(Xu, H.)、刘(Liu, B.)、舒(Shu, L.)和余(Yu, P.)(2019 年)。开放世界学习及其在产品分类中的应用。见${WWW}$。

Yan, X., Zhang, H., Xu, X., Hu, X., & Heng, P.-A. (2021). Learning semantic context from normal samples for unsupervised anomaly detection. In ${AAAI}$ .

严(Yan, X.)、张(Zhang, H.)、徐(Xu, X.)、胡(Hu, X.)和亨(Heng, P.-A.)(2021 年)。从正常样本中学习语义上下文用于无监督异常检测。见${AAAI}$。

Yang, J., Chen, W., Feng, L., Yan, X., Zheng, H., & Zhang, W. (2020a). Webly supervised image classification with metadata: Automatic noisy label correction via visual-semantic graph. In ACM multimedia.

杨(Yang, J.)、陈(Chen, W.)、冯(Feng, L.)、严(Yan, X.)、郑(Zheng, H.)和张(Zhang, W.)(2020a)。利用元数据进行网络监督图像分类:通过视觉 - 语义图自动纠正噪声标签。见美国计算机协会多媒体会议(ACM multimedia)。

Yang, J., Feng, L., Chen, W., Yan, X., Zheng, H., Luo, P., & Zhang, W. (2020b). Webly supervised image classification with self-contained confidence. In ${ECCV}$ .

杨(Yang, J.)、冯(Feng, L.)、陈(Chen, W.)、严(Yan, X.)、郑(Zheng, H.)、罗(Luo, P.)和张(Zhang, W.)(2020b)。具有自包含置信度的网络监督图像分类。见${ECCV}$。

Yang, J., Wang, H., Feng, L., Yan, X., Zheng, H., Zhang, W., & Liu, Z. (2021). Semantically coherent out-of-distribution detection. In ${ICCV}$ .

杨(Yang, J.)、王(Wang, H.)、冯(Feng, L.)、严(Yan, X.)、郑(Zheng, H.)、张(Zhang, W.)和刘(Liu, Z.)(2021 年)。语义连贯的分布外检测。见${ICCV}$。

Yang, J., Wang, P., Zou, D., Zhou, Z., Ding, K., Peng, W., Wang, H., Chen, G., Li, B., Sun, Y., Du, X., Zhou, K., Zhang, W., Hendrycks, D., Li, Y., & Liu, Z. (2022a). Openood: Benchmarking generalized out-of-distribution detection. In NeurIPS.

杨(Yang, J.)、王(Wang, P.)、邹(Zou, D.)、周(Zhou, Z.)、丁(Ding, K.)、彭(Peng, W.)、王(Wang, H.)、陈(Chen, G.)、李(Li, B.)、孙(Sun, Y.)、杜(Du, X.)、周(Zhou, K.)、张(Zhang, W.)、亨德里克斯(Hendrycks, D.)、李(Li, Y.)和刘(Liu, Z.)(2022a)。Openood:广义分布外检测基准测试。见神经信息处理系统大会(NeurIPS)。

Yang, J., Zhou, K., & Liu, Z. (2022b). Full-spectrum out-of-distribution detection, arXiv preprint arXiv:2204.05306

杨(Yang)、周(Zhou)和刘(Liu)(2022b)。全谱分布外检测，arXiv预印本arXiv:2204.05306

Yang, P., Baracchi, D., Ni, R., Zhao, Y., Argenti, F., & Piva, A. (2020c). A survey of deep learning-based source image forensics. Journal of Imaging, 6, 66.

杨(Yang)、巴拉奇(Baracchi)、倪(Ni)、赵(Zhao)、阿尔真蒂(Argenti)和皮瓦(Piva)(2020c)。基于深度学习的源图像取证综述。《成像杂志》，6，66。

Yang, X., Latecki, L. J., & Pokrajac, D. (2009). Outlier detection with globally optimal exemplar-based gmm. In SIAM.

杨(Yang)、拉特茨基(Latecki)和波克拉亚茨(Pokrajac)(2009)。基于全局最优范例的高斯混合模型的离群点检测。发表于美国工业与应用数学学会(SIAM)会议。

Yang, Y., Gao, R., & Xu, Q. (2022c). Out-of-distribution detection with semantic mismatch under masking. In ECCV.

杨(Yang)、高(Gao)和徐(Xu)(2022c)。掩码下基于语义不匹配的分布外检测。发表于欧洲计算机视觉会议(ECCV)。

Yang, Z., Li, L., Lin, K., Wang, J., Lin, C.-C., Liu, Z., & Wang, L. (2023). The dawn of lmms Preliminary explorations with gpt-4v (ision). arXiv preprint, arXiv:2309.17421

杨(Yang)、李(Li)、林(Lin)、王(Wang)、林(Lin)、刘(Liu)和王(Wang)(2023)。大型多模态模型(LMMs)的曙光——基于GPT - 4V(ision)的初步探索。arXiv预印本，arXiv:2309.17421

Yoshihashi, R., Shao, W., Kawakami, R., You, S., Iida, M., & Nae-mura, T. (2019). Classification-reconstruction learning for open-set recognition. In ${CVPR}$ .

吉桥(Yoshihashi)、邵(Shao)、川上(Kawakami)、尤(You)、饭田(Iida)和中村(Nae - mura)(2019)。用于开放集识别的分类 - 重建学习。发表于${CVPR}$。

Yu, Q., & Aizawa, K. (2019). Unsupervised out-of-distribution detection by maximum classifier discrepancy. In ${ICCV}$ .

余(Yu)和相泽(Aizawa)(2019)。基于最大分类器差异的无监督分布外检测。发表于${ICCV}$。

Yue, Z., Wang, T., Sun, Q., Hua, X.-S., & Zhang, H. (2021). Counterfactual zero-shot and open-set visual recognition. In CVPR.

岳(Yue)、王(Wang)、孙(Sun)、华(Hua)和张(Zhang)(2021)。反事实零样本和开放集视觉识别。发表于计算机视觉与模式识别会议(CVPR)。

Yun, S., Han, D., Oh, S. J., Chun, S., Choe, J., & Yoo, Y. (2019). Cutmix: Regularization strategy to train strong classifiers with localizable features. In ${CVPR}$ .

尹(Yun)、韩(Han)、吴(Oh)、春(Chun)、崔(Choe)和柳(Yoo)(2019)。Cutmix:一种使用可定位特征训练强分类器的正则化策略。发表于${CVPR}$。

Zaeemzadeh, A., Bisagno, N., Sambugaro, Z., Conci, N., Rahnavard, N., & Shah, M. (2021). Out-of-distribution detection using union of 1-dimensional subspaces. In CVPR.

扎伊姆扎德(Zaeemzadeh)、比萨尼奥(Bisagno)、桑布加罗(Sambugaro)、孔奇(Conci)、拉赫纳瓦尔(Rahnavard)和沙阿(Shah)(2021)。使用一维子空间并集的分布外检测。发表于计算机视觉与模式识别会议(CVPR)。

Zenati, H., Foo, C. S., Lecouat, B., Manek, G., & Chandrasekhar, V. R. (2018). Efficient gan-based anomaly detection. In ICLR-W.

泽纳蒂(Zenati)、傅(Foo)、勒库阿(Lecouat)、马内克(Manek)和钱德拉塞卡尔(Chandrasekhar)(2018)。基于生成对抗网络(GAN)的高效异常检测。发表于国际学习表征会议研讨会(ICLR - W)。

Zhai, S., Cheng, Y., Lu, W., & Zhang, Z. (2016). Deep structured energy based models for anomaly detection. In ${ICML}$ .

翟(Zhai)、程(Cheng)、陆(Lu)和张(Zhang)(2016)。基于深度结构化能量模型的异常检测。发表于${ICML}$。

Zhang, B., & Zuo, W. (2008). Learning from positive and unlabeled examples: A survey. In International symposiums on information processing.

张(Zhang)和左(Zuo)(2008)。从正例和无标签示例中学习:综述。发表于国际信息处理研讨会。

Zhang, H., Li, A., Guo, J., & Guo, Y. (2020). Hybrid models for open set recognition. In ${ECCV}$ .

张(Zhang)、李(Li)、郭(Guo)和郭(Guo)(2020)。用于开放集识别的混合模型。发表于${ECCV}$。

Zhang, H., & Patel, V. M. (2016). Sparse representation-based open set recognition. In TPAMI.

张(Zhang)和帕特尔(Patel)(2016)。基于稀疏表示的开放集识别。发表于《模式分析与机器智能汇刊》(TPAMI)。

Zhang, J., Fu, Q., Chen, X., Du, L., Li, Z., Wang, G., Han, S., & Zhang, D. (2023a). Out-of-distribution detection based on in-distribution data patterns memorization with modern Hopfield energy. In ${ICLR}$ .

张(Zhang)、傅(Fu)、陈(Chen)、杜(Du)、李(Li)、王(Wang)、韩(Han)和张(Zhang)(2023a)。基于现代霍普菲尔德能量的分布内数据模式记忆的分布外检测。发表于${ICLR}$。

Zhang, J., Inkawhich, N., Linderman, R., Chen, Y., & Li, H. (2023b). Mixture outlier exposure: Towards out-of-distribution detection in fine-grained environments. In Proceedings of the IEEE/CVF winter conference on applications of computer vision (WACV) (pp. 5531-5540).

张(Zhang)、英卡维奇(Inkawhich)、林德曼(Linderman)、陈(Chen)和李(Li)(2023b)。混合离群值暴露:实现细粒度环境中的分布外检测。见《电气与电子工程师协会/计算机视觉基金会冬季计算机视觉应用会议(WACV)论文集》(第5531 - 5540页)。

Zhang, J., Yang, J., Wang, P., Wang, H., Lin, Y., Zhang, H., Sun, Y., Du, X., Zhou, K., Zhang, W., Li, Y., Liu, Z., Chen, Y., & Li, H. (2023c). Openood v1.5: Enhanced benchmark for out-of-distribution detection. arXiv preprint, arXiv:2306.09301

张(Zhang)、杨(Yang)、王(Wang)、王(Wang)、林(Lin)、张(Zhang)、孙(Sun)、杜(Du)、周(Zhou)、张(Zhang)、李(Li)、刘(Liu)、陈(Chen)和李(Li)(2023c)。Openood v1.5:增强的分布外检测基准。预印本，arXiv:2306.09301

Zhang, L., Goldstein, M., & Ranganath, R. (2021). Understanding failures in out-of-distribution detection with deep generative models. In ${ICML}$ .

张(Zhang)、戈尔茨坦(Goldstein)和兰加纳特(Ranganath)(2021)。理解深度生成模型在分布外检测中的失败原因。见${ICML}$。

Zhao, B., & Han, K. (2021). Novel visual category discovery with dual ranking statistics and mutual knowledge distillation. In NeurIPS.

赵(Zhao)和韩(Han)(2021)。利用双重排序统计和相互知识蒸馏进行新型视觉类别发现。见《神经信息处理系统大会(NeurIPS)》。

Zheng, H., Wang, Q., Fang, Z., Xia, X., Liu, F., Liu, T., & Han, B. (2023). Out-of-distribution detection learning with unreliable out-of-distribution sources. In NeurIPS.

郑(Zheng)、王(Wang)、方(Fang)、夏(Xia)、刘(Liu)、刘(Liu)和韩(Han)(2023)。利用不可靠的分布外源进行分布外检测学习。见《神经信息处理系统大会(NeurIPS)》。

Zhou, B., Lapedriza, A., Khosla, A., Oliva, A., & Torralba, A. (2017). Places: A 10 million image database for scene recognition. IEEE Transactions on Pattern Analysis and Machine Intelligence, 40, 1452-1464.

周(Zhou)、拉佩德里萨(Lapedriza)、科斯拉(Khosla)、奥利瓦(Oliva)和托拉尔巴(Torralba)(2017)。Places:用于场景识别的千万图像数据库。《电气与电子工程师协会模式分析与机器智能汇刊》，40，1452 - 1464。

Zhou, C., Neubig, G., Gu, J., Diab, M., Guzman, P., Zettlemoyer, L., & Ghazvininejad, M. (2020). Detecting hallucinated content in conditional neural sequence generation. In ${ACL}$ .

周(Zhou)、纽比格(Neubig)、顾(Gu)、迪亚布(Diab)、古兹曼(Guzman)、泽特尔莫耶(Zettlemoyer)和加兹维尼内贾德(Ghazvininejad)(2020)。检测条件神经序列生成中的幻觉内容。见${ACL}$。

Zhou, D.-W., Ye, H.-J., & Zhan, D.-C. (2021a). Learning placeholders for open-set recognition. In ${CVPR}$ .

周(Zhou)、叶(Ye)和詹(Zhan)(2021a)。学习用于开放集识别的占位符。见${CVPR}$。

Zhou, K., Liu, Z., Qiao, Y., Xiang, T., & Loy, C. C. (2021b). Domain generalization: A survey, arXiv preprint arXiv:2103.02503

周(Zhou)、刘(Liu)、乔(Qiao)、向(Xiang)和洛伊(Loy)(2021b)。领域泛化:综述，预印本arXiv:2103.02503

Zhou, K., Yang, J., Loy, C. C., & Liu, Z. (2022a). Learning to prompt for vision-language models. In International Journal of Computer Vision (IJCV).

周(Zhou)、杨(Yang)、洛伊(Loy)和刘(Liu)(2022a)。学习为视觉 - 语言模型设置提示。见《国际计算机视觉杂志(IJCV)》。

Zhou, K., Yang, J., Loy, C. C., & Liu, Z. (2022b). Conditional prompt learning for vision-language models. In IEEE/CVF conference on computer vision and pattern recognition (CVPR).

周(Zhou)、杨(Yang)、洛伊(Loy)和刘(Liu)(2022b)。视觉 - 语言模型的条件提示学习。见《电气与电子工程师协会/计算机视觉基金会计算机视觉与模式识别会议(CVPR)》。

Zhou, Y. (2022). Rethinking reconstruction autoencoder-based out-of-distribution detection. In ${CVPR}$ .

周(Zhou)(2022)。重新思考基于重构自编码器的分布外检测。见${CVPR}$。

Zimmerer, D., Full, P. M., Isensee, F., Jäger, P., Adler, T., Petersen, J., Köhler, G., Ross, T., Reinke, A., Kascenas, A., & Jensen, B. S. (2022). Mood 2020: A public benchmark for out-of-distribution detection and localization on medical images. IEEE Transactions on Medical Imaging, 41, 2728-2738.

齐默勒(Zimmerer)、富尔(Full)、伊森塞(Isensee)、耶格(Jäger)、阿德勒(Adler)、彼得森(Petersen)、克勒(Köhler)、罗斯(Ross)、赖因克(Reinke)、卡斯塞纳斯(Kascenas)和詹森(Jensen)(2022)。Mood 2020:医学图像分布外检测和定位的公共基准。《电气与电子工程师协会医学成像汇刊》，41，2728 - 2738。

Zisselman, E., & Tamar, A. (2020). Deep residual flow for out of distribution detection. In ${CVPR}$ .

齐塞尔曼(Zisselman)和塔马尔(Tamar)(2020)。用于分布外检测的深度残差流。见${CVPR}$。

Zong, B., Song, Q., Min, M. R., Cheng, W., Lumezanu, C., Cho, D., & Chen, H. (2018). Deep autoencoding Gaussian mixture model for unsupervised anomaly detection. In ICLR.

宗(Zong)、宋(Song)、闵(Min)、程(Cheng)、卢梅扎努(Lumezanu)、赵(Cho)和陈(Chen)(2018)。用于无监督异常检测的深度自编码高斯混合模型。见《国际学习表征会议(ICLR)》。

Publisher's Note Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations.

出版者说明:施普林格·自然在已发表地图的管辖权主张和机构隶属关系方面保持中立。

Springer Nature or its licensor (e.g. a society or other partner) holds exclusive rights to this article under a publishing agreement with the author(s) or other rightsholder(s); author self-archiving of the accepted manuscript version of this article is solely governed by the terms of such publishing agreement and applicable law.

施普林格·自然集团(Springer Nature)或其授权方(如某个学会或其他合作伙伴)根据与作者或其他版权持有者签订的出版协议，对本文享有独家权利；作者自行存档本文的录用稿件版本仅受该出版协议条款和适用法律的约束。