# Domain Generalization: A Survey

# 领域泛化:综述

Kaiyang Zhou, Ziwei Liu, Yu Qiao, Tao Xiang, and Chen Change Loy

周开阳、刘子微、乔宇、向涛和罗平

Abstract-Generalization to out-of-distribution (OOD) data is a capability natural to humans yet challenging for machines to reproduce. This is because most learning algorithms strongly rely on the i.i.d. assumption on source/target data, which is often violate in practice due to domain shift. Domain generalization (DG) aims to achieve OOD generalization by using only source data for model learning. Over the last ten years, research in DG has made great progress, leading to a broad spectrum of methodologies, e.g., those based on domain alignment, meta-learning, data augmentation, or ensemble learning, to name a few; DG has also been studied in various application areas including computer vision, speech recognition, natural language processing, medical imaging, and reinforcement learning. In this paper, for the first time a comprehensive literature review in DG is provided to summarize the developments over the past decade. Specifically, we first cover the background by formally defining DG and relating it to other relevant fields like domain adaptation and transfer learning. Then, we conduct a thorough review into existing methods and theories. Finally, we conclude this survey with insights and discussions on future research directions.

摘要——对分布外(OOD)数据进行泛化是人类天生具备的能力，但机器要实现这一点却颇具挑战。这是因为大多数学习算法严重依赖源/目标数据的独立同分布(i.i.d.)假设，而在实际应用中，由于领域偏移，这一假设常常被打破。领域泛化(DG)旨在仅使用源数据进行模型学习，从而实现分布外泛化。在过去十年中，领域泛化的研究取得了巨大进展，催生了广泛的方法，例如基于领域对齐、元学习、数据增强或集成学习等方法；领域泛化也在包括计算机视觉、语音识别、自然语言处理、医学成像和强化学习等多个应用领域得到了研究。本文首次对领域泛化进行了全面的文献综述，总结了过去十年的发展。具体而言，我们首先通过正式定义领域泛化并将其与领域自适应和迁移学习等相关领域联系起来，介绍了研究背景。然后，我们对现有方法和理论进行了深入的回顾。最后，我们对未来的研究方向进行了展望和讨论，总结了本综述。

Index Terms-Out-of-Distribution Generalization, Domain Shift, Model Robustness, Machine Learning

关键词——分布外泛化、领域偏移、模型鲁棒性、机器学习

## 1 INTRODUCTION

## 1 引言

IF an image classifier was trained on photo images, would it work on sketch images? What if a car detector trained using urban images is tested in rural environments? Is it possible to deploy a semantic segmentation model trained using sunny images under rainy or snowy weather conditions? Can a health status classifier trained using one patient's electrocardiogram data be used to diagnose another patient's health status? Answers to all these questions depend on how well the machine learning models can deal with one common problem, namely the domain shift problem. Such a problem refers to the distribution shift between a set of training (source) data and a set of test (target) data [1], [2], [3], [4], [5].

如果一个图像分类器是在照片图像上训练的，它在素描图像上是否能正常工作？如果一个使用城市图像训练的汽车检测器在农村环境中进行测试，结果会如何？是否可以将使用晴天图像训练的语义分割模型应用于雨天或雪天的天气条件下？使用一名患者的心电图数据训练的健康状态分类器能否用于诊断另一名患者的健康状态？所有这些问题的答案都取决于机器学习模型处理一个常见问题的能力，即领域偏移问题。这个问题指的是一组训练(源)数据和一组测试(目标)数据之间的分布偏移 [1]、[2]、[3]、[4]、[5]。

Most statistical learning algorithms strongly rely on an over-simplified assumption, that is, the source and target data are independent and identically distributed (i.i.d.), while ignoring out-of-distribution (OOD) scenarios commonly encountered in practice. This means that they are not designed with the domain shift problem in mind, and as a consequence, a learning agent trained only with source data will typically suffer significant performance drops on an OOD target domain.

大多数统计学习算法严重依赖一个过于简化的假设，即源数据和目标数据是独立同分布(i.i.d.)的，而忽略了实际应用中常见的分布外(OOD)场景。这意味着它们在设计时没有考虑到领域偏移问题，因此，仅使用源数据训练的学习代理在分布外的目标领域上通常会出现显著的性能下降。

The domain shift problem has seriously impeded large-scale deployments of machine learning models. One might be curious if recent advances in deep neural networks [6], [7], known as deep learning [8], can mitigate this problem. Studies in [2], [9], [10] suggest that deep learning models' performance degrades significantly on OOD datasets, even with just small variations in the data generating process. This highlights the fact that the successes achieved by deep learning so far have been largely driven by supervised learning with large-scale annotated datasets like ImageNet [11]— again, relying on the i.i.d. assumption.

领域偏移问题严重阻碍了机器学习模型的大规模部署。有人可能会好奇，近年来被称为深度学习 [8] 的深度神经网络 [6]、[7] 的进展是否能缓解这个问题。文献 [2]、[9]、[10] 的研究表明，即使数据生成过程只有微小的变化，深度学习模型在分布外数据集上的性能也会显著下降。这凸显了一个事实，即到目前为止，深度学习取得的成功在很大程度上是由使用像 ImageNet [11] 这样的大规模标注数据集进行监督学习推动的——同样依赖于独立同分布假设。

Research on how to deal with domain shift has been extensively conducted in the literature. A straightforward solution to bypass the OOD data issue is to collect some data from the target domain to adapt a source-domain-trained model. Indeed, this domain adaptation (DA) problem has received much attention [12], [13], [14], [15], [16], [17], [18]. However, DA relies on a strong assumption that target data is accessible for model adaptation, which does not always hold in practice.

关于如何处理领域偏移的研究在文献中已有广泛开展。绕过分布外数据问题的一个直接解决方案是从目标领域收集一些数据，以调整在源领域训练的模型。实际上，这个领域自适应(DA)问题已经受到了广泛关注 [12]、[13]、[14]、[15]、[16]、[17]、[18]。然而，领域自适应依赖于一个很强的假设，即目标数据可用于模型调整，而这在实际应用中并不总是成立。

In many applications, target data is difficult to obtain or even unknown before deploying the model. For example, in biomedical applications where domain shift occurs between different patients' data, it is impractical to collect each new patient's data in advance [19]; in traffic scene semantic segmentation it is infeasible to collect data capturing all different scenes and under all possible weather conditions [20]; when dealing with data stream, the model is also required to be intrinsically generalizable [21].

在许多应用中，目标数据在模型部署之前很难获取，甚至是未知的。例如，在生物医学应用中，不同患者的数据之间会出现领域偏移，提前收集每个新患者的数据是不切实际的 [19]；在交通场景语义分割中，收集涵盖所有不同场景和所有可能天气条件的数据是不可行的 [20]；在处理数据流时，模型也需要具备内在的泛化能力 [21]。

To overcome the domain shift problem, as well as the absence of target data, the problem of domain generalization (DG) was introduced [22]. Specifically, the goal in DG is to learn a model using data from a single or multiple related but distinct source domains in such a way that the model can generalize well to any OOD target domain.

为了克服领域偏移问题以及目标数据缺失的问题，领域泛化(DG)问题被提出 [22]。具体而言，领域泛化的目标是使用来自单个或多个相关但不同的源领域的数据来学习一个模型，使得该模型能够很好地泛化到任何分布外的目标领域。

Since the first formal introduction in 2011 by Blanchard et al. [22], a plethora of methods have been developed to tackle the OOD generalization issue [23], [24], [25], [26], [27], [28], [29], [30]. This includes methods based on aligning source domain distributions for domain-invariant representation learning [31], [32], exposing the model to domain shift during training via meta-learning [33], [34], and augmenting data with domain synthesis [35], [36], to name a few. From the application point of view, DG has not only been studied in computer vision like object recognition [37], [38], semantic segmentation [20], [39] and person re-identification [23], [35], but also in other domains such as speech recognition [40], natural language processing [34], medical imaging [41], [42], and reinforcement learning [23].

自2011年布兰查德(Blanchard)等人[22]首次正式提出以来，已经开发出了大量方法来解决分布外泛化(OOD generalization)问题[23]、[24]、[25]、[26]、[27]、[28]、[29]、[30]。这包括基于对齐源域分布以进行领域不变表示学习的方法[31]、[32]，通过元学习在训练期间让模型经历领域偏移的方法[33]、[34]，以及通过领域合成来扩充数据的方法[35]、[36]等等。从应用的角度来看，领域泛化(DG)不仅在计算机视觉领域得到了研究，如目标识别[37]、[38]、语义分割[20]、[39]和行人重识别[23]、[35]，还在其他领域有所涉及，如语音识别[40]、自然语言处理[34]、医学成像[41]、[42]和强化学习[23]。

---

- K. Zhou, Z. Liu and C.C. Loy are with the S-Lab, Nanyang Technological University, Singapore. E-mail: \{kaiyang.zhou, ziwei.liu, ccloy\}@ntu.edu.sg.

- 周凯阳(K. Zhou)、刘子微(Z. Liu)和罗平(C.C. Loy)就职于新加坡南洋理工大学S-Lab。电子邮件:\{kaiyang.zhou, ziwei.liu, ccloy\}@ntu.edu.sg。

- Y. Qiao is with Shenzhen Institute of Advanced Technology, Chinese Academy of Sciences, China, and also with Shanghai AI Lab, Shanghai, China. E-mail: yu.qiao@siat.ac.cn.

- 乔宇(Y. Qiao)就职于中国科学院深圳先进技术研究院，同时也就职于中国上海人工智能实验室。电子邮件:yu.qiao@siat.ac.cn。

- T. Xiang is with the Centre for Vision Speech and Signal Processing, University of Surrey, Guildford, UK. E-mail: t.xiang@surrey.ac.uk.

- 向涛(T. Xiang)就职于英国吉尔福德萨里大学视觉、语音与信号处理中心。电子邮件:t.xiang@surrey.ac.uk。

---

In this survey, we aim to provide a timely and comprehensive literature review to summarize, mainly from the technical perspective, the learning algorithms developed over the last decade, and provide insights on potential directions for future research. 2 BACKGROUND

在本综述中，我们旨在提供一份及时且全面的文献综述，主要从技术角度总结过去十年中开发的学习算法，并为未来的研究方向提供见解。2 背景

### 2.1 A Brief History of Domain Generalization

### 2.1 领域泛化简史

The domain generalization (DG) problem was first formally introduced by Blanchard et al. [22] as a machine learning problem, while the term domain generalization was later coined by Muandet et al. [19]. Unlike other related learning problems such as domain adaptation or transfer learning, DG considers the scenarios where target data is inaccessible during model learning. In [22], the motivation behind DG originates from a medical application called automatic gating of flow cytometry data. The objective is to design algorithms to automate the process of classifying cells in patients' blood samples based on different properties, e.g., to distinguish between lymphocytes and non-lymphocytes. Such a technology is crucial in facilitating the diagnosis of the health of patients since manual gating is extremely time-consuming and requires domain-specific expertise. However, due to distribution shift between different patients' data, a classifier learned using data from historic patients does not generalize to new patients, and meanwhile, collecting new data for model fine-tuning is impractical, thus motivating research on the DG problem.

领域泛化(DG)问题最初由布兰查德(Blanchard)等人[22]作为一个机器学习问题正式提出，而“领域泛化”这一术语后来由穆安代特(Muandet)等人[19]提出。与其他相关学习问题(如领域自适应或迁移学习)不同，领域泛化考虑的是在模型学习期间无法获取目标数据的场景。在文献[22]中，领域泛化的动机源于一个名为流式细胞术数据自动门控的医学应用。其目标是设计算法，根据不同属性自动对患者血液样本中的细胞进行分类，例如区分淋巴细胞和非淋巴细胞。由于手动门控极其耗时且需要特定领域的专业知识，因此这项技术对于促进患者健康诊断至关重要。然而，由于不同患者数据之间存在分布偏移，使用历史患者数据学习得到的分类器无法推广到新患者，同时，收集新数据进行模型微调也不切实际，因此引发了对领域泛化问题的研究。

In computer vision, a seminal work done by Torralba and Efros [43] raised attention on the cross-domain generalization issue. They performed a thorough investigation into the cross-dataset generalization performance of object recognition models using six popular benchmark datasets. Their findings suggested that dataset biases, which are difficult to avoid, can lead to poor generalization performance. For example, as shown in [43], a person classifier trained on Caltech101 [44] obtained a very low accuracy (11.8%) on La-belMe [45], though its same-dataset performance was near-perfect (99.6%). Following [43], Khosla et al. [46] targeted the cross-dataset generalization problem in classification and detection tasks, and proposed to learn domain-specific bias vectors and domain-agnostic weight vectors based on support vector machine (SVM) classifiers.

在计算机视觉领域，托拉尔巴(Torralba)和埃弗罗斯(Efros)[43]的开创性工作引起了人们对跨领域泛化问题的关注。他们使用六个流行的基准数据集，对目标识别模型的跨数据集泛化性能进行了全面研究。他们的研究结果表明，难以避免的数据集偏差会导致泛化性能不佳。例如，如文献[43]所示，在Caltech101数据集[44]上训练的行人分类器在LabelMe数据集[45]上的准确率非常低(11.8%)，尽管其在同一数据集上的性能几乎完美(99.6%)。在文献[43]之后，科斯拉(Khosla)等人[46]针对分类和检测任务中的跨数据集泛化问题，提出基于支持向量机(SVM)分类器学习特定领域的偏差向量和领域无关的权重向量。

### 2.2 Problem Definition

### 2.2 问题定义

We first introduce some notations that will be used throughout this survey. Let $\mathcal{X}$ be the input (feature) space and $\mathcal{Y}$ the target (label) space, a domain is defined as a joint distribution ${P}_{XY}$ on $\mathcal{X} \times  \mathcal{Y}{.}^{1}$ For a specific domain ${P}_{XY}$ , we refer to ${P}_{X}$ as the marginal distribution on $X,{P}_{Y \mid  X}$ the posterior distribution of $Y$ given $X$ , and ${P}_{X \mid  Y}$ the class-conditional distribution of $X$ given $Y$ .

我们首先介绍一些本综述中会一直使用的符号。设$\mathcal{X}$为输入(特征)空间，$\mathcal{Y}$为目标(标签)空间，一个领域定义为$\mathcal{X} \times  \mathcal{Y}{.}^{1}$上的联合分布${P}_{XY}$。对于特定领域${P}_{XY}$，我们将${P}_{X}$称为$X,{P}_{Y \mid  X}$上的边缘分布，$Y$给定$X$的后验分布，以及$X$给定$Y$的类条件分布。

In the context of DG, we have access to $K$ similar but distinct source domains $\mathcal{S} = {\left\{  {S}_{k} = \left\{  \left( {x}^{\left( k\right) },{y}^{\left( k\right) }\right) \right\}  \right\}  }_{k = 1}^{K}$ , each associated with a joint distribution ${P}_{XY}^{\left( k\right) }$ . Note that ${P}_{XY}^{\left( k\right) } \neq$ ${P}_{XY}^{\left( {k}^{\prime }\right) }$ with $k \neq  {k}^{\prime }$ and $k,{k}^{\prime } \in  \{ 1,\ldots , K\}$ . The goal of DG is to learn a predictive model $f : \mathcal{X} \rightarrow  \mathcal{Y}$ using only source domain data such that the prediction error on an unseen target domain $\mathcal{T} = \left\{  {x}^{\mathcal{T}}\right\}$ is minimized. The corresponding joint distribution of the target domain $\mathcal{T}$ is denoted by ${P}_{XY}^{\mathcal{T}}$ . Also, ${P}_{XY}^{\mathcal{T}} \neq  {P}_{XY}^{\left( k\right) },\forall k \in  \{ 1,\ldots , K\}$ .

在领域泛化(Domain Generalization，DG)的背景下，我们可以获取 $K$ 个相似但不同的源领域 $\mathcal{S} = {\left\{  {S}_{k} = \left\{  \left( {x}^{\left( k\right) },{y}^{\left( k\right) }\right) \right\}  \right\}  }_{k = 1}^{K}$，每个源领域都与一个联合分布 ${P}_{XY}^{\left( k\right) }$ 相关联。请注意，${P}_{XY}^{\left( k\right) } \neq$ ${P}_{XY}^{\left( {k}^{\prime }\right) }$，其中 $k \neq  {k}^{\prime }$ 且 $k,{k}^{\prime } \in  \{ 1,\ldots , K\}$。领域泛化的目标是仅使用源领域数据学习一个预测模型 $f : \mathcal{X} \rightarrow  \mathcal{Y}$，使得在一个未见过的目标领域 $\mathcal{T} = \left\{  {x}^{\mathcal{T}}\right\}$ 上的预测误差最小化。目标领域 $\mathcal{T}$ 对应的联合分布用 ${P}_{XY}^{\mathcal{T}}$ 表示。此外，${P}_{XY}^{\mathcal{T}} \neq  {P}_{XY}^{\left( k\right) },\forall k \in  \{ 1,\ldots , K\}$。

Multi-Source DG DG has typically been studied under two different settings, namely multi-source DG and single-source DG. The majority of research has been dedicated to the multi-source setting, which assumes multiple distinct but relevant domains are available (i.e., $K > 1$ ). As stated in [22], the original motivation for studying DG is to leverage multi-source data to learn representations that are invariant to different marginal distributions. This makes sense because without having access to the target data, it is challenging for a source-learned model to generalize well. As such, using multiple domains allows a model to discover stable patterns across source domains, which generalize better to unseen domains.

多源领域泛化 领域泛化通常在两种不同的设置下进行研究，即多源领域泛化和单源领域泛化。大多数研究都致力于多源设置，该设置假设存在多个不同但相关的领域(即 $K > 1$)。正如文献 [22] 中所述，研究领域泛化的最初动机是利用多源数据来学习对不同边缘分布不变的表示。这是有道理的，因为在无法获取目标数据的情况下，一个从源数据学习的模型很难实现良好的泛化。因此，使用多个领域可以让模型发现源领域之间的稳定模式，从而更好地泛化到未见过的领域。

Single-Source DG In contrast, the single-source setting assumes training data is homogeneous, i.e., they are sampled from a single domain $\left( {K = 1}\right)$ . This problem is closely related to the topic of OOD robustness [9], [47], [48], which investigates model robustness under image corruptions. Essentially, single-source DG methods do not require domain labels for learning and thus they are applicable to multi-source scenarios as well. In fact, most existing methods able to solve single-source DG do not distinguish themselves as a single- or a multi-source approach, but rather a more generic solution to OOD generalization, with experiments covering both single- and multi-source datasets [49], [50], [51], [52].

单源领域泛化 相比之下，单源设置假设训练数据是同质的，即它们是从单个领域 $\left( {K = 1}\right)$ 中采样得到的。这个问题与分布外(Out-of-Distribution，OOD)鲁棒性的主题密切相关 [9]、[47]、[48]，该主题研究模型在图像损坏情况下的鲁棒性。本质上，单源领域泛化方法在学习时不需要领域标签，因此它们也适用于多源场景。事实上，大多数现有的能够解决单源领域泛化问题的方法并不将自己区分为单源或多源方法，而是将其作为一种更通用的分布外泛化解决方案，相关实验涵盖了单源和多源数据集 [49]、[50]、[51]、[52]。

### 2.3 Datasets and Applications

### 2.3 数据集与应用

DG has been studied across many application areas including computer vision, speech recognition, medical imaging, and so on. Table 1 summarizes the commonly used datasets based on different applications. Below we briefly discuss their basics.

领域泛化已经在许多应用领域得到了研究，包括计算机视觉、语音识别、医学成像等等。表 1 总结了基于不同应用的常用数据集。下面我们简要讨论它们的基本情况。

Handwritten Digit Recognition The commonly used digit datasets include MNIST [54], MNIST-M [15], SVHN [55], and SYN [15]. In general, these datasets differ in font style, stroke color, and background. MNIST contains images of handwritten digits. MNIST-M mixes MNIST's images with random color patches. SVHN comprises images of street view house numbers while SYN is a synthetic dataset. See Fig. 1(a) for some example images. Rotation has also been exploited to synthesize domain shift [53].

手写数字识别 常用的数字数据集包括 MNIST [54]、MNIST - M [15]、SVHN [55] 和 SYN [15]。一般来说，这些数据集在字体样式、笔画颜色和背景方面有所不同。MNIST 包含手写数字的图像。MNIST - M 将 MNIST 的图像与随机颜色块混合。SVHN 包含街景房屋号码的图像，而 SYN 是一个合成数据集。一些示例图像见图 1(a)。旋转也被用于合成领域偏移 [53]。

Object Recognition has been the most common task in DG where the domain shift varies substantially across different datasets. In VLCS [56] and Office-31 [12], the domain shift is mainly caused by changes in environments or viewpoints. As exemplified in Fig. 1(b), the scenes in VLCS vary from urban to rural areas and the viewpoints are often biased toward either a side-view or a non-canonical view. Image style changes have also been commonly studied, such as PACS [37] (see Fig. 1(c)), OfficeHome [59], Domain-Net [60], and ImageNet-Sketch [51]. Other types of domain shift include synthetic-vs-real [56], artificial corruptions [9], and data sources [67]. Action Recognition Learning generalizable representations is also crucial for video understanding like action recognition. IXMAS [68] has been widely used as a cross-view action recognition benchmark [31], [94], which contains action videos collected from five different views. In addition to view changes, different subjects or environments (like indoor vs outdoor) can also create domain shift and lead to model failures.

目标识别一直是领域泛化(DG)中最常见的任务，在不同的数据集中，领域偏移存在显著差异。在VLCS [56]和Office - 31 [12]数据集中，领域偏移主要由环境或视角的变化引起。如图1(b)所示，VLCS数据集中的场景从城市地区到农村地区各不相同，并且视角通常偏向侧视图或非标准视图。图像风格的变化也经常被研究，例如PACS [37](见图1(c))、OfficeHome [59]、Domain - Net [60]和ImageNet - Sketch [51]。其他类型的领域偏移包括合成数据与真实数据的差异[56]、人为损坏[9]以及数据源的不同[67]。动作识别学习具有泛化能力的表征对于视频理解(如动作识别)也至关重要。IXMAS [68]已被广泛用作跨视角动作识别基准[31, 94]，其中包含从五个不同视角收集的动作视频。除了视角变化外，不同的主体或环境(如室内与室外)也会造成领域偏移，导致模型失效。

---

1. We use ${P}_{XY}$ and $P\left( {X, Y}\right)$ interchangeably.

1. 我们可以互换使用${P}_{XY}$和$P\left( {X, Y}\right)$。

---

TABLE 1

Commonly used domain generalization datasets (categorized mainly based on applications).

常用的领域泛化数据集(主要根据应用进行分类)。

<table><tr><td/><td>#samples</td><td>#domains</td><td>Characterization of domain shift</td></tr><tr><td colspan="4">Handwritten digit recognition</td></tr><tr><td>- Rotated MNIST [53]</td><td>70,000</td><td>6</td><td>Rotations (0, 15, 30, 45, 60 & 75)</td></tr><tr><td>- Digits-DG [35]</td><td>24,000</td><td>4</td><td>MNIST [54], MNIST-M [15], SVHN [55], SYN [15]</td></tr><tr><td colspan="4">Object recognition</td></tr><tr><td>- VLCS [56]</td><td>10,729</td><td>4</td><td>Caltech101 [44], LabelMe [45], PASCAL [57], SUN09 [58]</td></tr><tr><td>- Office-31 [12]</td><td>4,652</td><td>3</td><td>Amazon, webcam, dslr</td></tr><tr><td>- OfficeHome [59]</td><td>15,588</td><td>4</td><td>Art, clipart, product, real</td></tr><tr><td>- PACS [37]</td><td>9,991</td><td>4</td><td>Photo, art, cartoon, sketch</td></tr><tr><td>- DomainNet [60]</td><td>586,575</td><td>6</td><td>Clipart, infograph, painting, quickdraw, real, sketch</td></tr><tr><td>- miniDomainNet [61]</td><td>140,006</td><td>4</td><td>Clipart, painting, real, sketch</td></tr><tr><td>- ImageNet-Sketch [51]</td><td>50,000</td><td>2</td><td>Real vs sketch images</td></tr><tr><td>- VisDA-17 [62]</td><td>280,157</td><td>2</td><td>Synthetic vs real images</td></tr><tr><td>- CIFAR-10-C [9]</td><td>60,000</td><td>-</td><td>Artificial corruptions</td></tr><tr><td>- CIFAR-100-C [9]</td><td>60,000</td><td>-</td><td>Artificial corruptions</td></tr><tr><td>- ImageNet-C [9]</td><td>≈1.3M</td><td>-</td><td>Artificial corruptions</td></tr><tr><td>- ImageNet-R [63]</td><td>30k</td><td>-</td><td>Image style changes</td></tr><tr><td>- ImageNet-A [64]</td><td>7,500</td><td>-</td><td>Naturally adversarial examples</td></tr><tr><td>- TerraInc [65]</td><td>24,788</td><td>4</td><td>Geographical locations</td></tr><tr><td>- NICO++ [66]</td><td>232.4k</td><td>10</td><td>Contexts (e.g., grass, water, winter, indoor, outdoor)</td></tr><tr><td>- Visual Decathlon [67]</td><td>1,659,142</td><td>10</td><td>Data sources (10 datasets)</td></tr><tr><td colspan="4">Action recognition</td></tr><tr><td>- IXMAS [68]</td><td>1,650</td><td>5</td><td>5 camera views, 10 subjects (see [31])</td></tr><tr><td>- UCF-HMDB [69], [70]</td><td>3,809</td><td>2</td><td>Data sources (2 datasets) (see [71])</td></tr><tr><td colspan="4">Semantic segmentation</td></tr><tr><td>- SYNTHIA [72]</td><td>2,700</td><td>15</td><td>4 locations, 5 weather conditions (see [73])</td></tr><tr><td>- GTA5-Cityscapes [74], [75]</td><td>29,966</td><td>2</td><td>Synthetic vs real images</td></tr><tr><td colspan="4">Person re-identification</td></tr><tr><td>- Market-Duke [76], [77]</td><td>69,079</td><td>2</td><td>Camera views, cities, streets, etc.</td></tr><tr><td colspan="4">Face recognition</td></tr><tr><td>- Face [78]</td><td>>5M</td><td>9</td><td>Data sources (9 datasets)</td></tr><tr><td colspan="4">Face anti-spoofing</td></tr><tr><td>- COMI [79], [80], [81], [82]</td><td>≈8,500</td><td>4</td><td>Data sources (4 datasets)</td></tr><tr><td colspan="4">Speech recognition</td></tr><tr><td>- Google Speech Command [83]</td><td>65k</td><td>1,888</td><td>Speakers</td></tr><tr><td colspan="4">Sentiment classification</td></tr><tr><td>- Amazon Reviews [84]</td><td>>340k</td><td>4</td><td>Books, DVD, electronics, kitchen appliances</td></tr><tr><td colspan="4">WILDS [85] (only show 3 out of 10 datasets here)</td></tr><tr><td>- Camelyon17-WILDS [86]</td><td>455,954</td><td>5</td><td>Hospitals</td></tr><tr><td>- FMoW-WILDS [87]</td><td>523,846</td><td>80</td><td>Time, geographical regions</td></tr><tr><td>- iWildCam-WILDS [88]</td><td>203,029</td><td>323</td><td>Camera traps</td></tr><tr><td colspan="4">Medical imaging</td></tr><tr><td>- Multi-site Prostate MRI Segmentation [42]</td><td>116</td><td>6</td><td>Clinical centers</td></tr><tr><td>- Chest X-rays [89]</td><td>-</td><td>3</td><td>Data sources (NIH [90], ChexPert [91], RSNA)</td></tr><tr><td colspan="4">Reinforcement learning</td></tr><tr><td>- Coinrun [92]</td><td>-</td><td>-</td><td>Scenes, difficulty levels</td></tr><tr><td>- OpenAI Procgen Benchmark [93]</td><td>-</td><td>-</td><td>States, scenes, rewards, difficulty levels</td></tr></table>

<table><tbody><tr><td></td><td>样本数量</td><td>领域数量</td><td>领域偏移的特征描述</td></tr><tr><td colspan="4">手写数字识别</td></tr><tr><td>- 旋转MNIST数据集 [53]</td><td>70,000</td><td>6</td><td>旋转角度 (0、15、30、45、60 和 75度)</td></tr><tr><td>- 数字领域泛化数据集(Digits-DG) [35]</td><td>24,000</td><td>4</td><td>MNIST数据集 [54]、MNIST-M数据集 [15]、街景门牌号数据集(SVHN) [55]、合成数据集(SYN) [15]</td></tr><tr><td colspan="4">目标识别</td></tr><tr><td>- VLCS数据集 [56]</td><td>10,729</td><td>4</td><td>加州理工101图像数据集(Caltech101) [44]、LabelMe数据集 [45]、PASCAL数据集 [57]、SUN09数据集 [58]</td></tr><tr><td>- Office-31数据集 [12]</td><td>4,652</td><td>3</td><td>亚马逊、网络摄像头、数码单反相机</td></tr><tr><td>- OfficeHome数据集 [59]</td><td>15,588</td><td>4</td><td>艺术、剪贴画、产品、真实场景</td></tr><tr><td>- PACS数据集 [37]</td><td>9,991</td><td>4</td><td>照片、艺术画、卡通、素描</td></tr><tr><td>- DomainNet数据集 [60]</td><td>586,575</td><td>6</td><td>剪贴画、信息图、绘画、快速绘图、真实场景、素描</td></tr><tr><td>- 迷你DomainNet数据集 [61]</td><td>140,006</td><td>4</td><td>剪贴画、绘画、真实场景、素描</td></tr><tr><td>- ImageNet素描数据集 [51]</td><td>50,000</td><td>2</td><td>真实图像与素描图像</td></tr><tr><td>- VisDA-17数据集 [62]</td><td>280,157</td><td>2</td><td>合成图像与真实图像</td></tr><tr><td>- CIFAR-10-C数据集 [9]</td><td>60,000</td><td>-</td><td>人为损坏</td></tr><tr><td>- CIFAR-100-C数据集 [9]</td><td>60,000</td><td>-</td><td>人为损坏</td></tr><tr><td>- ImageNet-C数据集 [9]</td><td>约130万</td><td>-</td><td>人为损坏</td></tr><tr><td>- ImageNet-R数据集 [63]</td><td>30k</td><td>-</td><td>图像风格变化</td></tr><tr><td>- ImageNet-A数据集 [64]</td><td>7,500</td><td>-</td><td>自然对抗样本</td></tr><tr><td>- TerraInc数据集 [65]</td><td>24,788</td><td>4</td><td>地理位置</td></tr><tr><td>- NICO++数据集 [66]</td><td>232.4k</td><td>10</td><td>上下文(例如，草地、水、冬季、室内、室外)</td></tr><tr><td>- 视觉十项全能数据集 [67]</td><td>1,659,142</td><td>10</td><td>数据来源(10个数据集)</td></tr><tr><td colspan="4">动作识别</td></tr><tr><td>- IXMAS数据集 [68]</td><td>1,650</td><td>5</td><td>5个摄像头视角，10个受试者(见 [31])</td></tr><tr><td>- UCF-HMDB数据集 [69]、[70]</td><td>3,809</td><td>2</td><td>数据来源(2个数据集)(见 [71])</td></tr><tr><td colspan="4">语义分割</td></tr><tr><td>- SYNTHIA数据集 [72]</td><td>2,700</td><td>15</td><td>4个地点，5种天气条件(见 [73])</td></tr><tr><td>- GTA5 - 城市景观数据集 [74]、[75]</td><td>29,966</td><td>2</td><td>合成图像与真实图像</td></tr><tr><td colspan="4">行人重识别</td></tr><tr><td>- Market - Duke数据集 [76]、[77]</td><td>69,079</td><td>2</td><td>摄像头视角、城市、街道等</td></tr><tr><td colspan="4">人脸识别</td></tr><tr><td>- 人脸数据集 [78]</td><td>>5M</td><td>9</td><td>数据来源(9个数据集)</td></tr><tr><td colspan="4">人脸反欺骗</td></tr><tr><td>- COMI数据集 [79]、[80]、[81]、[82]</td><td>约8500</td><td>4</td><td>数据来源(4个数据集)</td></tr><tr><td colspan="4">语音识别</td></tr><tr><td>- 谷歌语音命令数据集 [83]</td><td>65k</td><td>1,888</td><td>说话人</td></tr><tr><td colspan="4">情感分类</td></tr><tr><td>- 亚马逊评论数据集 [84]</td><td>>340k</td><td>4</td><td>书籍、DVD、电子产品、厨房电器</td></tr><tr><td colspan="4">WILDS数据集 [85](此处仅展示10个数据集中的3个)</td></tr><tr><td>- 卡米利恩17 - WILDS数据集 [86]</td><td>455,954</td><td>5</td><td>医院</td></tr><tr><td>- 功能地图 - WILDS数据集 [87]</td><td>523,846</td><td>80</td><td>时间、地理区域</td></tr><tr><td>- 野生相机 - WILDS数据集 [88]</td><td>203,029</td><td>323</td><td>相机陷阱</td></tr><tr><td colspan="4">医学影像</td></tr><tr><td>- 多站点前列腺磁共振成像分割数据集 [42]</td><td>116</td><td>6</td><td>临床中心</td></tr><tr><td>- 胸部X光片 [89]</td><td>-</td><td>3</td><td>数据来源(美国国立卫生研究院 [90]、ChexPert数据集 [91]、美国放射学会)</td></tr><tr><td colspan="4">强化学习</td></tr><tr><td>- 硬币奔跑游戏 [92]</td><td>-</td><td>-</td><td>场景、难度等级</td></tr><tr><td>- OpenAI过程生成基准测试 [93]</td><td>-</td><td>-</td><td>状态、场景、奖励、难度等级</td></tr></tbody></table>

Semantic Segmentation is critical to autonomous driving. Though this task has been greatly advanced by deep neural networks, the performance is still far from being satisfactory when deploying trained deep models in novel scenarios, such as new cities or unseen weather conditions [95]. Since it is impractical to collect data covering all possible scenarios, DG is pivotal in facilitating large-scale deployment of semantic segmentation systems. The SYNTHIA dataset [72] contains synthetic images of different locations under different weather conditions. Generalization from GTA5 [74] to real image datasets like Cityscapes [75] has also been extensively studied [96].

语义分割(Semantic Segmentation)对自动驾驶至关重要。尽管深度神经网络已极大推动了这项任务的发展，但在将训练好的深度模型部署到新场景(如陌生城市或未见的天气条件)时，其性能仍远不能令人满意 [95]。由于收集涵盖所有可能场景的数据并不现实，因此领域泛化(Domain Generalization，DG)对于促进语义分割系统的大规模部署至关重要。SYNTHIA 数据集 [72] 包含不同天气条件下不同地点的合成图像。从 GTA5 [74] 到像 Cityscapes [75] 这样的真实图像数据集的泛化也得到了广泛研究 [96]。

4

![0195d149-280f-7e81-bc6e-e908e6b9148e_3_170_112_1458_321_0.jpg](images/0195d149-280f-7e81-bc6e-e908e6b9148e_3_170_112_1458_321_0.jpg)

Fig. 1. Example images from three domain generalization benchmarks manifesting different types of domain shift. In (a), the domain shift mainly corresponds to changes in font style, color and background. In (b), dataset-specific biases are clear, which are caused by changes in environment/scene and viewpoint. In (c), image style changes are the main reason for domain shift.

图 1. 来自三个领域泛化基准的示例图像，展示了不同类型的领域偏移。在 (a) 中，领域偏移主要对应于字体样式、颜色和背景的变化。在 (b) 中，特定数据集的偏差很明显，这是由环境/场景和视角的变化引起的。在 (c) 中，图像风格的变化是领域偏移的主要原因。

Person Re-Identification (Re-ID) plays a key role in security and surveillance applications. Person re-ID is essentially an instance retrieval task, aiming to match people across disjoint camera views (each seen as a distinct domain). Most existing methods in re-ID [97], [98], [99], [100], [101] have been focused on the same-dataset setting, i.e., training and test are done on the same set of camera views, with performance almost reaching saturation. Recently, cross-dataset re-ID [102], [103], [104] has gained much attention: the objective is to generalize a model from source camera views to unseen target camera views, a more challenging but realistic setting. The domain shift often occurs in image resolution, viewpoint, lighting condition, background, etc.

行人重识别(Person Re-Identification，Re-ID)在安全和监控应用中起着关键作用。行人重识别本质上是一个实例检索任务，旨在跨不相交的相机视角(每个视角视为一个不同的领域)匹配行人。现有的大多数行人重识别方法 [97]、[98]、[99]、[100]、[101] 都集中在同数据集设置上，即训练和测试在同一组相机视角上进行，性能几乎达到饱和。最近，跨数据集行人重识别 [102]、[103]、[104] 受到了广泛关注:目标是将模型从源相机视角泛化到未见的目标相机视角，这是一个更具挑战性但更现实的设置。领域偏移通常发生在图像分辨率、视角、光照条件、背景等方面。

Face Recognition has witnessed significant advances driven by deep learning in recent years [105], [106], [107]. However, several studies [78] have suggested that deep models trained even on large-scale datasets like MS-Celeb- $1\mathrm{M}\left\lbrack  {108}\right\rbrack$ suffer substantial performance drops when deployed in new datasets with previously unseen domains, such as low resolution [109], [110], [111], large variations in illumination/occlusion/head pose [112], [113], [114], or drastically different viewpoints [115].

近年来，在深度学习的推动下，人脸识别(Face Recognition)取得了显著进展 [105]、[106]、[107]。然而，多项研究 [78] 表明，即使在像 MS-Celeb- $1\mathrm{M}\left\lbrack  {108}\right\rbrack$ 这样的大规模数据集上训练的深度模型，在部署到具有先前未见领域的新数据集时，性能也会大幅下降，例如低分辨率 [109]、[110]、[111]，光照/遮挡/头部姿态的大幅变化 [112]、[113]、[114]，或截然不同的视角 [115]。

Face Anti-Spoofing aims to prevent face recognition systems from being attacked using fake faces [116], such as printed photos, videos or 3D masks. Conventional face anti-spoofing methods do not take into account distribution shift, making them vulnerable to unseen attack types [117]. There is no specifically designed DG dataset for this task. A common practice is to combine several face anti-spoofing datasets for model training and do evaluation on an unseen dataset, e.g., using CASIA-MFSD [79], Oulu-NPU [80] and MSU-MFSD [81] as the sources and Idiap Replay-Attack [82] as the target.

人脸反欺骗(Face Anti-Spoofing)旨在防止人脸识别系统受到使用假人脸(如打印照片、视频或 3D 面具)的攻击 [116]。传统的人脸反欺骗方法没有考虑分布偏移，这使得它们容易受到未见攻击类型的影响 [117]。目前没有专门为这项任务设计的领域泛化数据集。常见的做法是将几个人脸反欺骗数据集组合起来进行模型训练，并在一个未见的数据集上进行评估，例如，使用 CASIA - MFSD [79]、Oulu - NPU [80] 和 MSU - MFSD [81] 作为源数据集，Idiap Replay - Attack [82] 作为目标数据集。

Speech Recognition Since people speak differently (e.g., different tones or pitches) it is natural to regard each speaker as a domain [40]. The commonly used dataset is Google Speech Command [83], which consists of 1,888 domains (speakers) and around 65,000 samples.

语音识别(Speech Recognition)由于人们说话方式不同(如不同的语调或音高)，自然可以将每个说话者视为一个领域 [40]。常用的数据集是 Google 语音命令数据集 [83]，它由 1888 个领域(说话者)和约 65000 个样本组成。

Sentiment Classification is a common task studied in natural language processing, which aims to classify opinions in texts as either positive or negative (hence a binary classification problem) [34]. Amazon Reviews [84] contains reviews for four categories (domains) of products: books, DVD, electronics and kitchen appliances.

情感分类(Sentiment Classification)是自然语言处理中研究的常见任务，旨在将文本中的观点分类为积极或消极(因此是一个二分类问题)[34]。亚马逊评论数据集 [84] 包含四类(领域)产品的评论:书籍、DVD、电子产品和厨房电器。

The WILDS Benchmark has been recently introduced, with a goal to study distribution shift faced in the wild [85]. The benchmark contains a total of ten datasets, which cover a wide range of pattern recognition tasks, such as animal classification, cancer detection, molecule classification, and satellite imaging. Table 1 shows three datasets from WILDS that have been commonly used by the DG community [118], [119], [120].

WILDS 基准最近被引入，旨在研究现实世界中面临的分布偏移 [85]。该基准总共包含十个数据集，涵盖了广泛的模式识别任务，如动物分类、癌症检测、分子分类和卫星成像。表 1 展示了 WILDS 中被领域泛化社区常用的三个数据集 [118]、[119]、[120]。

Medical Imaging DG is also critical to medical imaging where domain shift is often related to variations in clinical centers or patients [42], [121]. Two commonly used medical imaging datasets are Multi-site Prostate MRI Segmentation [42] and Chest X-rays [89], each containing data aggregated from multiple clinical centers with domain shift caused by, e.g., different scanners or acquisition protocols.

医学影像领域泛化(Medical Imaging DG)在医学影像中也至关重要，其中领域偏移通常与临床中心或患者的差异有关 [42]、[121]。两个常用的医学影像数据集是多站点前列腺 MRI 分割数据集 [42] 和胸部 X 光数据集 [89]，每个数据集都包含从多个临床中心汇总的数据，领域偏移由不同的扫描仪或采集协议等因素引起。

Reinforcement Learning (RL) has a dramatically different paradigm than supervised or unsupervised learning: RL aims to maximize rewards obtained through continuous interactions with an environment. Generalization in RL has been a critical issue where agents or policies learned in a training environment often suffer from overfitting and hence generalize poorly to unseen environments [92], [122], [123], [124]. Domain shift in RL is mostly associated with environmental changes, such as different scenes, states, or even rewards. There is a large body of work focused on improving generalization in RL. We refer readers to [125] for a more comprehensive survey in the topic of generalizable RL.

强化学习(Reinforcement Learning，RL)与监督学习或无监督学习有着截然不同的范式:强化学习旨在通过与环境的持续交互来最大化所获得的奖励。强化学习中的泛化一直是一个关键问题，在训练环境中学习到的智能体或策略往往会出现过拟合问题，因此在未见过的环境中泛化能力较差 [92]、[122]、[123]、[124]。强化学习中的领域偏移大多与环境变化有关，例如不同的场景、状态甚至奖励。有大量的工作致力于提高强化学习的泛化能力。关于可泛化强化学习这一主题的更全面综述，我们建议读者参考 [125]。

### 2.4 Evaluation

### 2.4 评估

Evaluation of DG algorithms often follows the leave-one-domain-out rule [37]: given a dataset containing at least two distinct domains, one or multiple of them are used as source domain(s) for model training while the rest are treated as target domain(s); a model learned from the source domain(s) is directly tested in the target domain(s) without any form of adaptation. Two problem scenarios have been studied: single- vs multi-source DG. It is worth noting that some datasets contain label shift, meaning that the label space between source and target changes (termed heterogeneous DG [38]). For instance, in the problem of person re-ID, identities between training and test are different; in this case the source-learned representation is directly used for image matching.

领域泛化(DG)算法的评估通常遵循留一领域法规则 [37]:给定一个包含至少两个不同领域的数据集，其中一个或多个领域用作模型训练的源领域，而其余领域则视为目标领域；从源领域学习到的模型在目标领域中直接进行测试，无需进行任何形式的调整。目前已经研究了两种问题场景:单源领域泛化与多源领域泛化。值得注意的是，一些数据集存在标签偏移，这意味着源领域和目标领域之间的标签空间发生了变化(称为异构领域泛化 [38])。例如，在行人重识别问题中，训练集和测试集的身份不同；在这种情况下，从源领域学习到的特征表示直接用于图像匹配。

TABLE 2

Comparison between domain generalization and its related topics.

领域泛化与其相关主题的比较。

<table><tr><td rowspan="2"/><td colspan="2">$K$</td><td colspan="2">${P}_{XY}^{\mathcal{S}}$ vs ${P}_{XY}^{\mathcal{T}}$</td><td colspan="2">${\mathcal{Y}}_{S}$ vs ${\mathcal{Y}}_{T}$</td><td rowspan="2">Access to ${P}_{X}^{\mathcal{T}}$ ?</td></tr><tr><td>$= 1$</td><td>> 1</td><td>-</td><td>≠</td><td>-</td><td>≠</td></tr><tr><td>Supervised Learning</td><td>✓</td><td/><td>✓</td><td/><td>✓</td><td/><td/></tr><tr><td>Multi-Task Learning</td><td/><td>✓</td><td>✓</td><td/><td>✓</td><td/><td/></tr><tr><td>Transfer Learning</td><td>✓</td><td>✓</td><td/><td>✓</td><td/><td>✓</td><td>✓</td></tr><tr><td>Zero-Shot Learning</td><td>✓</td><td/><td/><td>✓</td><td/><td>✓</td><td/></tr><tr><td>Domain Adaptation</td><td>✓</td><td>✓</td><td/><td>✓</td><td>✓</td><td>✓</td><td>✓</td></tr><tr><td>Test-Time Training</td><td>✓</td><td>✓</td><td/><td>✓</td><td>✓</td><td/><td>✓</td></tr><tr><td>Domain Generalization</td><td>✓</td><td>✓</td><td/><td>✓</td><td>✓</td><td>✓</td><td/></tr></table>

<table><tbody><tr><td rowspan="2"></td><td colspan="2">$K$</td><td colspan="2">${P}_{XY}^{\mathcal{S}}$ 与 ${P}_{XY}^{\mathcal{T}}$ 对比</td><td colspan="2">${\mathcal{Y}}_{S}$ 与 ${\mathcal{Y}}_{T}$ 对比</td><td rowspan="2">能否访问 ${P}_{X}^{\mathcal{T}}$ ？</td></tr><tr><td>$= 1$</td><td>> 1</td><td>-</td><td>≠</td><td>-</td><td>≠</td></tr><tr><td>监督学习(Supervised Learning)</td><td>✓</td><td></td><td>✓</td><td></td><td>✓</td><td></td><td></td></tr><tr><td>多任务学习(Multi-Task Learning)</td><td></td><td>✓</td><td>✓</td><td></td><td>✓</td><td></td><td></td></tr><tr><td>迁移学习(Transfer Learning)</td><td>✓</td><td>✓</td><td></td><td>✓</td><td></td><td>✓</td><td>✓</td></tr><tr><td>零样本学习(Zero-Shot Learning)</td><td>✓</td><td></td><td></td><td>✓</td><td></td><td>✓</td><td></td></tr><tr><td>领域自适应(Domain Adaptation)</td><td>✓</td><td>✓</td><td></td><td>✓</td><td>✓</td><td>✓</td><td>✓</td></tr><tr><td>测试时训练(Test-Time Training)</td><td>✓</td><td>✓</td><td></td><td>✓</td><td>✓</td><td></td><td>✓</td></tr><tr><td>领域泛化(Domain Generalization)</td><td>✓</td><td>✓</td><td></td><td>✓</td><td>✓</td><td>✓</td><td></td></tr></tbody></table>

$K$ : number of source domains/tasks. ${P}_{XV}^{S/T}$ : source/target joint distribution. ${\mathcal{Y}}_{S/T}$ : source/target label space. ${P}_{X}^{T}$ : target marginal. $\dagger$ : Limited in quantities. like a single example or mini-batch.

$K$ :源域/任务的数量。${P}_{XV}^{S/T}$ :源/目标联合分布。${\mathcal{Y}}_{S/T}$ :源/目标标签空间。${P}_{X}^{T}$ :目标边缘分布。$\dagger$ :数量有限，例如单个示例或小批量。

Evaluation Metrics Two metrics have been commonly adopted, namely average and worst-case performance. The former concerns about the average performance in held-out domains, which is used in most domain shift scenarios. In contrast, the latter focuses on the worst performance among held-out domains, which is often used in the case of subpopulation shift [126] and has been widely adopted by the causal inference community [127] as well as some datasets in the WILDS benchmark [85].

评估指标 通常采用两种指标，即平均性能和最坏情况性能。前者关注在保留域中的平均性能，这在大多数域偏移场景中使用。相比之下，后者关注保留域中的最差性能，这常用于子群体偏移的情况 [126]，并且也被因果推理界 [127] 以及 WILDS 基准测试中的一些数据集 [85] 广泛采用。

Model Selection concerns about which model (checkpoint), architecture or hyper-parameters to choose for evaluation, which has recently been identified by [128] as a crucial step in the evaluation pipeline. As summarized in [128], there are three model selection criteria: i) Training-domain validation, which holds out a subset of training data for model selection; ii) Leave-one-domain-out validation, which keeps one source domain for model selection; iii) Test-domain validation (oracle), which performs model selection using a random subset of test domain data. As suggested by [128], the last criterion would lead to overly optimistic or pessimistic results and thus should be used with care. Another important lesson from [128] is that specially designed DG methods often perform similarly with the plain model (known as Empirical Risk Minimization) when using larger neural networks and an extensive search of hyper-parameters. Therefore, it is suggested that future evaluation should cover different neural network architectures and ensure comparison is made using the same model selection criterion.

模型选择 关注选择哪个模型(检查点)、架构或超参数进行评估，最近 [128] 已将其确定为评估流程中的关键步骤。正如 [128] 所总结的，有三种模型选择标准:i) 训练域验证，即留出一部分训练数据用于模型选择；ii) 留一域验证，即保留一个源域用于模型选择；iii) 测试域验证(神谕)，即使用测试域数据的随机子集进行模型选择。正如 [128] 所建议的，最后一种标准会导致过于乐观或悲观的结果，因此应谨慎使用。从 [128] 中得到的另一个重要经验是，当使用更大的神经网络并广泛搜索超参数时，专门设计的域泛化(DG)方法通常与普通模型(即经验风险最小化)表现相似。因此，建议未来的评估应涵盖不同的神经网络架构，并确保使用相同的模型选择标准进行比较。

### 2.5 Related Topics

### 2.5 相关主题

In this section, we discuss the relations between DG and its related topics, and clarify their differences. See Table 2 for an overview.

在本节中，我们讨论域泛化(DG)与其相关主题之间的关系，并阐明它们的差异。概述见表 2。

Supervised Learning generally aims to learn an input-output mapping by minimizing the following risk: ${\mathbb{E}}_{\left( {x, y}\right)  \sim  {\widehat{P}}_{XY}}\ell \left( {f\left( x\right) , y}\right)$ , where ${\widehat{P}}_{XY}$ denotes the empirical distribution rather than the real data distribution ${P}_{XY}$ , which is inaccessible. The hope is that once the loss is minimized, the learned model can work well on data generated from ${P}_{XY}$ , which heavily relies on the i.i.d. assumption. The crucial difference between SL and DG is that in the latter training and test data is drawn from different distributions, thus violating the i.i.d. assumption. DG is arguably a more practical setting in real-world applications [43].

监督学习 通常旨在通过最小化以下风险来学习输入 - 输出映射:${\mathbb{E}}_{\left( {x, y}\right)  \sim  {\widehat{P}}_{XY}}\ell \left( {f\left( x\right) , y}\right)$ ，其中 ${\widehat{P}}_{XY}$ 表示经验分布，而非无法获取的真实数据分布 ${P}_{XY}$ 。希望一旦损失最小化，所学习的模型就能在从 ${P}_{XY}$ 生成的数据上表现良好，这在很大程度上依赖于独立同分布(i.i.d.)假设。监督学习(SL)和域泛化(DG)的关键区别在于，在后者中，训练数据和测试数据来自不同的分布，从而违反了独立同分布假设。可以说，域泛化在现实世界应用中是一种更实际的设置 [43]。

Multi-Task Learning (MTL) The goal of MTL is to simultaneously learn multiple related tasks $\left( {K > 1}\right)$ using a single model [129], [130], [131], [132], [133]. As shown in Table 2, MTL aims to make a model perform well on the same set of tasks that the model was trained on $\left( {{\mathcal{Y}}_{S} = {\mathcal{Y}}_{T}}\right)$ , whereas DG aims to generalize a model to unseen data distributions $\left( {{P}_{XY}^{\mathcal{S}} \neq  {P}_{XY}^{\mathcal{T}}}\right)$ . Though being different in terms of the problem setup, the MTL paradigm has been exploited in some DG methods, notably for those based on self-supervised learning [49], [134], [135]. Intuitively, MTL benefits from the effect of regularization brought by parameter sharing [129], which may in part explain why the MTL paradigm works for DG.

多任务学习(MTL) 多任务学习的目标是使用单个模型同时学习多个相关任务 $\left( {K > 1}\right)$ [129]、[130]、[131]、[132]、[133]。如表 2 所示，多任务学习旨在使模型在其训练的同一组任务 $\left( {{\mathcal{Y}}_{S} = {\mathcal{Y}}_{T}}\right)$ 上表现良好，而域泛化旨在将模型推广到未见的数据分布 $\left( {{P}_{XY}^{\mathcal{S}} \neq  {P}_{XY}^{\mathcal{T}}}\right)$ 。尽管在问题设置方面有所不同，但多任务学习范式已在一些域泛化方法中得到应用，特别是那些基于自监督学习的方法 [49]、[134]、[135]。直观地说，多任务学习受益于参数共享带来的正则化效果 [129]，这在一定程度上可以解释为什么多任务学习范式适用于域泛化。

Transfer Learning (TL) aims to transfer the knowledge learned from one (or multiple) problem/domain/task to a different but related one [136]. A well-known TL example in contemporary deep learning is fine-tuning: first pretrain deep neural networks on large-scale datasets, such as ImageNet [11] for vision models or BooksCorpus [137] for language models; then fine-tune them on downstream tasks [138]. Given that pre-trained deep features are highly transferable, as shown in several studies [139], [140], a couple of recent DG works [141], [142] have researched how to preserve the transferable features learned via large-scale pre-training when learning new knowledge from source synthetic data for synthetic-to-real applications. As shown in Table 2, a key difference between TL and DG lies in whether the target data is used. In TL, the target data is required for model fine-tuning for new downstream tasks, whereas in DG we assume to have no access to the target data, thus focusing more on model generalization. Nonetheless, TL and DG share some similarities: the target distribution in both TL and DG is different from the source distribution; in terms of label space, TL mainly concerns disjoint label space, whereas DG considers both cases, i.e., same label space for homogeneous DG and disjoint label space for heterogeneous DG.

迁移学习(Transfer Learning，TL)旨在将从一个(或多个)问题/领域/任务中学到的知识迁移到另一个不同但相关的问题/领域/任务中 [136]。当代深度学习中一个著名的迁移学习示例是微调:首先在大规模数据集上预训练深度神经网络，例如用于视觉模型的 ImageNet 数据集 [11] 或用于语言模型的 BooksCorpus 语料库 [137]；然后在下游任务上对其进行微调 [138]。正如多项研究 [139]、[140] 所示，预训练的深度特征具有高度可迁移性，因此近期有几项领域泛化(Domain Generalization，DG)工作 [141]、[142] 研究了在从源合成数据中学习新知识以实现从合成到真实的应用时，如何保留通过大规模预训练学到的可迁移特征。如表 2 所示，迁移学习和领域泛化的一个关键区别在于是否使用目标数据。在迁移学习中，模型针对新的下游任务进行微调时需要目标数据，而在领域泛化中，我们假设无法获取目标数据，因此更侧重于模型的泛化能力。尽管如此，迁移学习和领域泛化仍有一些相似之处:两者的目标分布都与源分布不同；在标签空间方面，迁移学习主要关注不相交的标签空间，而领域泛化则考虑两种情况，即同质领域泛化的相同标签空间和异质领域泛化的不相交标签空间。

Zero-Shot Learning (ZSL) is related to DG in the sense that the goal in both problems is to deal with unseen distributions. Differently, distribution shift in ZSL is mainly caused by label space changes [143],[144],[145], i.e., ${P}_{Y}^{\mathcal{T}} \neq$ ${P}_{Y}^{\mathcal{S}}$ , since the task is to recognize new classes, except for generalized ZSL [146] which considers both new and old classes at test time; while in DG, domain shift mostly results from covariate shift [19], i.e., only the marginal distribution changes $\left( {{P}_{X}^{\mathcal{T}} \neq  {P}_{X}^{\mathcal{S}}}\right)  \cdot  {}^{2}$ To recognize unseen classes in ZSL, a common practice is to learn a mapping between the input image space and the attribute space [148] since the label space is disjoint between training and test data. Interestingly, attributes have also been exploited in DG for learning domain-generalizable representations [149].

零样本学习(Zero-Shot Learning，ZSL)与领域泛化相关，因为这两个问题的目标都是处理未见分布。不同的是，零样本学习中的分布偏移主要由标签空间变化引起 [143]、[144]、[145]，即 ${P}_{Y}^{\mathcal{T}} \neq$ ${P}_{Y}^{\mathcal{S}}$，因为该任务是识别新类别，不过广义零样本学习 [146] 在测试时会同时考虑新类别和旧类别；而在领域泛化中，领域偏移主要由协变量偏移导致 [19]，即仅边缘分布发生变化 $\left( {{P}_{X}^{\mathcal{T}} \neq  {P}_{X}^{\mathcal{S}}}\right)  \cdot  {}^{2}$。为了在零样本学习中识别未见类别，常见的做法是学习输入图像空间和属性空间之间的映射 [148]，因为训练数据和测试数据的标签空间不相交。有趣的是，属性也被用于领域泛化中以学习领域可泛化的表示 [149]。

Domain Adaptation (DA) is the closest topic to DG and has been extensively studied in the literature [13], [14], [15], [16], [17], [95], [150], [151], [152], [153]. Both DA and DG aim to tackle the domain shift problem (i.e., ${P}_{XY}^{\mathcal{S}} \neq  {P}_{XY}^{\mathcal{T}}$ ) encountered in new test environments. Differently, DA assumes the availability of sparsely labeled [154] or unlabeled [150] target data for model adaptation, hence having access to the marginal ${P}_{X}^{\mathcal{T}}$ . Though there exist different variants of DA where some methods do not explicitly use target data during training, such as zero-shot DA [155] that exploits task-irrelevant but target domain-relevant data (equivalent to accessing the marginal), their main idea remains unchanged, i.e., to leverage additional data that expose information related to the target domain. As shown in Table 2, research in DA shares some commonalities with DG, such as single- [150] and multi-source [60] DA, and heterogeneous DA [17], [156], [157], [158].

领域自适应(Domain Adaptation，DA)是与领域泛化最接近的主题，相关文献对此进行了广泛研究 [13]、[14]、[15]、[16]、[17]、[95]、[150]、[151]、[152]、[153]。领域自适应和领域泛化都旨在解决在新测试环境中遇到的领域偏移问题(即 ${P}_{XY}^{\mathcal{S}} \neq  {P}_{XY}^{\mathcal{T}}$)。不同的是，领域自适应假设可以获取稀疏标注 [154] 或未标注 [150] 的目标数据用于模型自适应，因此可以获取边缘分布 ${P}_{X}^{\mathcal{T}}$。尽管存在不同变体的领域自适应方法，其中一些方法在训练期间不会显式使用目标数据，例如零样本领域自适应 [155] 利用与任务无关但与目标领域相关的数据(相当于获取边缘分布)，但其主要思想保持不变，即利用能够揭示与目标领域相关信息的额外数据。如表 2 所示，领域自适应的研究与领域泛化有一些共同点，例如单源 [150] 和多源 [60] 领域自适应，以及异质领域自适应 [17]、[156]、[157]、[158]。

Test-Time Training (TTT) also called test-time adaptation [159], blurs the boundary between DA and DG. As shown in Table 2, TTT is related to both DA and DG because TTT also deals with the domain shift problem. One one hand, TTT (mostly) bears a resemblance with source-free DA [160]-both assume source data is inaccessible after model training. On the other hand, TTT differs from DA in that only a single [161] or mini-batch [162] test data is used for model tuning, which is often done in an online manner [163] and of course, without human supervision. It is also worth mentioning that datasets used in the TTT community largely overlap with those in DG, such as CIFAR-C [9] and ImageNet-C [9]. In terms of performance, TTT likely outperforms DG [162] due to the use of test data for parameter update, but is limited to scenarios where deployment devices have sufficient compute power. Moreover, TTT might not fit realtime applications if the tuning time is too "long."

测试时训练(Test-Time Training，TTT)也称为测试时自适应 [159]，它模糊了领域自适应和领域泛化之间的界限。如表 2 所示，测试时训练与领域自适应和领域泛化都相关，因为它也处理领域偏移问题。一方面，测试时训练(大多数情况下)与无源领域自适应 [160] 相似——两者都假设模型训练后无法获取源数据。另一方面，测试时训练与领域自适应的不同之处在于，仅使用单个 [161] 或小批量 [162] 测试数据进行模型调优，这通常以在线方式进行 [163]，并且当然无需人工监督。值得一提的是，测试时训练领域使用的数据集与领域泛化使用的数据集有很大重叠，例如 CIFAR - C [9] 和 ImageNet - C [9]。在性能方面，由于使用测试数据进行参数更新，测试时训练可能优于领域泛化 [162]，但仅限于部署设备具有足够计算能力的场景。此外，如果调优时间太“长”，测试时训练可能不适合实时应用。

## 3 Methodologies: A Survey

## 3 方法综述

Numerous domain generalization (DG) methods have been proposed in the past ten years, and the majority of them are designed for multi-source DG, despite some methods not explicitly requiring domain labels for learning and thus suitable for single-source DG as well. In this section, we categorize existing DG methods into several groups based on their methodologies and motivations behind their design. Within each group, we further discuss different variants and indicate whether domain labels are required for learning to differentiate their uses-those requiring domain labels can only be applied to multi-source DG while those not requiring domain labels are applicable to both single- and multi-source DG. See Table 3 for an overview.

在过去十年中，人们提出了众多领域泛化(Domain Generalization，DG)方法，其中大多数是为多源领域泛化设计的，尽管有些方法在学习时并不明确需要领域标签，因此也适用于单源领域泛化。在本节中，我们根据现有领域泛化方法的方法论和设计动机将其分为几类。在每一类中，我们进一步讨论不同的变体，并指出学习时是否需要领域标签，以区分它们的用途——需要领域标签的方法只能应用于多源领域泛化，而不需要领域标签的方法则适用于单源和多源领域泛化。概述见表3。

![0195d149-280f-7e81-bc6e-e908e6b9148e_5_977_120_612_457_0.jpg](images/0195d149-280f-7e81-bc6e-e908e6b9148e_5_977_120_612_457_0.jpg)

Fig. 2. Domain alignment is commonly applied to a pair of source domains, either in the feature space (orange arrows) or the classifier's output (green arrows), or both.

图2. 领域对齐通常应用于一对源领域，可在特征空间(橙色箭头)、分类器输出(绿色箭头)或两者同时进行。

### 3.1 Domain Alignment

### 3.1 领域对齐

Most existing DG approaches belong to the category of domain alignment [19], [31], [32], [117], [169], [172], where the central idea is to minimize the difference among source domains for learning domain-invariant representations (see Fig. 2). The motivation is straightforward: features that are invariant to the source domain shift should also be robust to any unseen target domain shift. Domain alignment has been applied in many DG applications, e.g., object recognition [32], [53], action recognition [31], face anti-spoofing [117], [178], and medical imaging analysis [173], [180]. Domain labels are required for domain alignment methods.

大多数现有的领域泛化方法属于领域对齐类别 [19]、[31]、[32]、[117]、[169]、[172]，其核心思想是最小化源领域之间的差异，以学习领域不变表示(见图2)。其动机很直接:对源领域变化保持不变的特征，也应该对任何未见过的目标领域变化具有鲁棒性。领域对齐已应用于许多领域泛化应用中，例如目标识别 [32]、[53]、动作识别 [31]、人脸反欺骗 [117]、[178] 和医学影像分析 [173]、[180]。领域对齐方法需要领域标签。

To measure the distance between distributions and thereby achieve alignment, there are a wide variety of statistical distance metrics for us to borrow, such as the simple ${\ell }_{2}$ distance, $f$ -divergences, or the more sophisticated Wasserstein distance [217]. However, designing an effective domain alignment method is a non-trivial task because one needs to consider what to align and how to align. In the following sections, we analyze the existing alignment-based DG methods from these two aspects.

为了测量分布之间的距离并实现对齐，我们可以借鉴各种各样的统计距离度量，例如简单的 ${\ell }_{2}$ 距离、$f$ 散度，或者更复杂的 Wasserstein 距离 [217]。然而，设计一种有效的领域对齐方法并非易事，因为需要考虑对齐什么以及如何对齐。在接下来的章节中，我们将从这两个方面分析现有的基于对齐的领域泛化方法。

#### 3.1.1 What to Align

#### 3.1.1 对齐什么

Recall that a domain is modeled by a joint distribution $P\left( {X, Y}\right)$ (see $§{2.2}$ for the background), we can decompose it into

回顾一下，一个领域由联合分布 $P\left( {X, Y}\right)$ 建模(背景信息见 $§{2.2}$)，我们可以将其分解为

$$
P\left( {X, Y}\right)  = P\left( {Y \mid  X}\right) P\left( X\right) , \tag{1}
$$

$$
= P\left( {X \mid  Y}\right) P\left( Y\right) \text{.} \tag{2}
$$

A common assumption in DG is that distribution shift only occurs in the marginal $P\left( X\right)$ while the posterior $P\left( {Y \mid  X}\right)$ remains relatively stable [19] (see Eq. (1)). Therefore, numerous domain alignment methods have been focused on aligning the marginal distributions of source domains [19], [31], [164], [165].

领域泛化中的一个常见假设是，分布变化仅发生在边缘分布 $P\left( X\right)$ 上，而后验分布 $P\left( {Y \mid  X}\right)$ 保持相对稳定 [19](见公式 (1))。因此，许多领域对齐方法都专注于对齐源领域的边缘分布 [19]、[31]、[164]、[165]。

---

2. It is worth mentioning that a recent ZSL work [147] has studied ZSL+DG, i.e., distribution shift occurs in both ${P}_{Y}$ and ${P}_{X}$ , which is analogous to heterogeneous DG.

2. 值得一提的是，最近的一项零样本学习(Zero-Shot Learning，ZSL)工作 [147] 研究了零样本学习 + 领域泛化(ZSL+DG)，即分布变化同时发生在 ${P}_{Y}$ 和 ${P}_{X}$ 上，这类似于异构领域泛化。

---

TABLE 3

Categorization of domain generalization (DG) methods.

领域泛化(DG)方法的分类。

<table><tr><td/><td>Domain labels</td><td>References</td></tr><tr><td colspan="3">Domain Alignment (§ 3.1)</td></tr><tr><td>- Minimizing Moments</td><td>✓</td><td>[19], [164], [165], [166], [167], [168]</td></tr><tr><td>- Minimizing Contrastive Loss</td><td>✓</td><td>[169], [170], [171]</td></tr><tr><td>- Minimizing the KL Divergence</td><td>✓</td><td>[172], [173]</td></tr><tr><td>- Minimizing Maximum Mean Discrepancy</td><td>✓</td><td>[31]</td></tr><tr><td>- Domain-Adversarial Learning</td><td>✓</td><td>[32], [117], [174], [175], [176], [177], [178], [179], [180], [181]</td></tr><tr><td>Meta-Learning (§3.2)</td><td>✓</td><td>[33], [34], [38], [42], [94], [103], [104], [121], [182], [183], [184], [185]</td></tr><tr><td colspan="3">Data Augmentation (§3.3)</td></tr><tr><td>- Image Transformations</td><td>✘</td><td>[39], [78], [186], [187], [188]</td></tr><tr><td>- Task-Adversarial Gradients</td><td>✘</td><td>[73], [189], [190]</td></tr><tr><td>- Domain-Adversarial Gradients</td><td>✓</td><td>[40]</td></tr><tr><td>- Random Augmentation Networks</td><td>✘</td><td>[191]</td></tr><tr><td>- Off-the-Shelf Style Transfer Models</td><td>✓</td><td>[20], [29], [192], [193]</td></tr><tr><td>- Learnable Augmentation Networks</td><td>✓</td><td>[35], [36], [194]</td></tr><tr><td>- Feature-Based Augmentation</td><td>✓</td><td>[23], [28], [147]</td></tr><tr><td colspan="3">Ensemble Learning (§3.4)</td></tr><tr><td>- Exemplar-SVMs</td><td>✘</td><td>[195], [196], [197]</td></tr><tr><td>- Domain-Specific Neural Networks</td><td>✓</td><td>[61], [198], [199], [200], [201]</td></tr><tr><td>- Domain-Specific Batch Normalization</td><td>✓</td><td>[41], [202], [203], [204]</td></tr><tr><td>- Weight Averaging</td><td>✘</td><td>[205]</td></tr><tr><td colspan="3">Self-Supervised Learning (§3.5)</td></tr><tr><td>- Single Pretext Task</td><td>✘</td><td>[49], [53], [134], [206]</td></tr><tr><td>- Multiple Pretext Tasks</td><td>✘</td><td>[50], [135]</td></tr><tr><td colspan="3">Learning Disentangled Representations (§ 3.6)</td></tr><tr><td>- Decomposition</td><td>✓</td><td>[37], [46], [207], [208]</td></tr><tr><td>- Generative Modeling</td><td>✓</td><td>[209], [210]</td></tr><tr><td>Regularization Strategies (§ 3.7)</td><td>✘</td><td>[51], [52]</td></tr><tr><td colspan="3">Reinforcement Learning (§ 3.8)</td></tr><tr><td>- Data augmentation</td><td>✘</td><td>[23], [123], [211], [212], [213], [214]</td></tr><tr><td>- Self-Supervision</td><td>✘</td><td>[215], [216]</td></tr></table>

<table><tbody><tr><td></td><td>领域标签</td><td>参考文献</td></tr><tr><td colspan="3">领域对齐(§ 3.1)</td></tr><tr><td>- 最小化矩</td><td>✓</td><td>[19], [164], [165], [166], [167], [168]</td></tr><tr><td>- 最小化对比损失</td><td>✓</td><td>[169], [170], [171]</td></tr><tr><td>- 最小化KL散度</td><td>✓</td><td>[172], [173]</td></tr><tr><td>- 最小化最大均值差异</td><td>✓</td><td>[31]</td></tr><tr><td>- 领域对抗学习</td><td>✓</td><td>[32], [117], [174], [175], [176], [177], [178], [179], [180], [181]</td></tr><tr><td>元学习(§3.2)</td><td>✓</td><td>[33], [34], [38], [42], [94], [103], [104], [121], [182], [183], [184], [185]</td></tr><tr><td colspan="3">数据增强(§3.3)</td></tr><tr><td>- 图像变换</td><td>✘</td><td>[39], [78], [186], [187], [188]</td></tr><tr><td>- 任务对抗梯度</td><td>✘</td><td>[73], [189], [190]</td></tr><tr><td>- 领域对抗梯度</td><td>✓</td><td>[40]</td></tr><tr><td>- 随机增强网络</td><td>✘</td><td>[191]</td></tr><tr><td>- 现成的风格迁移模型</td><td>✓</td><td>[20], [29], [192], [193]</td></tr><tr><td>- 可学习的增强网络</td><td>✓</td><td>[35], [36], [194]</td></tr><tr><td>- 基于特征的增强</td><td>✓</td><td>[23], [28], [147]</td></tr><tr><td colspan="3">集成学习(§3.4)</td></tr><tr><td>- 示例支持向量机(Exemplar-SVMs)</td><td>✘</td><td>[195], [196], [197]</td></tr><tr><td>- 特定领域的神经网络</td><td>✓</td><td>[61], [198], [199], [200], [201]</td></tr><tr><td>- 特定领域的批量归一化</td><td>✓</td><td>[41], [202], [203], [204]</td></tr><tr><td>- 权重平均</td><td>✘</td><td>[205]</td></tr><tr><td colspan="3">自监督学习(§3.5)</td></tr><tr><td>- 单一前置任务</td><td>✘</td><td>[49], [53], [134], [206]</td></tr><tr><td>- 多个前置任务</td><td>✘</td><td>[50], [135]</td></tr><tr><td colspan="3">学习解纠缠表示(§ 3.6)</td></tr><tr><td>- 分解</td><td>✓</td><td>[37], [46], [207], [208]</td></tr><tr><td>- 生成式建模</td><td>✓</td><td>[209], [210]</td></tr><tr><td>正则化策略(§ 3.7)</td><td>✘</td><td>[51], [52]</td></tr><tr><td colspan="3">强化学习(§ 3.8)</td></tr><tr><td>- 数据增强</td><td>✘</td><td>[23], [123], [211], [212], [213], [214]</td></tr><tr><td>- 自监督</td><td>✘</td><td>[215], [216]</td></tr></tbody></table>

Note that methods requiring domain labels can only be applied to multi-source DG while those not requiring domain labels are applicable to both multi- and single-source DG.

请注意，需要领域标签的方法只能应用于多源领域泛化(Domain Generalization，DG)，而那些不需要领域标签的方法则适用于多源和单源领域泛化。

From a causal learning perspective [218], it is valid to align $P\left( X\right)$ only when $X$ is the cause of $Y$ . In this case, $P\left( {Y \mid  X}\right)$ is not coupled with $P\left( X\right)$ and thus remains stable when $P\left( X\right)$ varies. However, it is also possible that $Y$ is the cause of $X$ , and as a result, shift in $P\left( X\right)$ will also affect $P\left( {Y \mid  X}\right)$ . Therefore, some domain alignment methods [32], [166], [168] proposed to instead align the class-conditional $P\left( {X \mid  Y}\right)$ , assuming that $P\left( Y\right)$ does not change (see Eq. (2)). For example, Li et al. [166] learned a feature transformation by minimizing for all classes the variance of class-conditional distributions across source domains. To allow $P\left( Y\right)$ to change along with $P\left( {X \mid  Y}\right)$ , i.e., heterogeneous DG, Hu et al. [168] relaxed the assumption made in [166] by removing the minimization constraint on marginal distributions and proposed several discrepancy measures to learn generalizable features.

从因果学习的角度来看 [218]，只有当 $X$ 是 $Y$ 的原因时，对齐 $P\left( X\right)$ 才是有效的。在这种情况下，$P\left( {Y \mid  X}\right)$ 与 $P\left( X\right)$ 不耦合，因此当 $P\left( X\right)$ 变化时，$P\left( {Y \mid  X}\right)$ 保持稳定。然而，也有可能 $Y$ 是 $X$ 的原因，结果是，$P\left( X\right)$ 的变化也会影响 $P\left( {Y \mid  X}\right)$。因此，一些领域对齐方法 [32]、[166]、[168] 提出改为对齐类条件 $P\left( {X \mid  Y}\right)$，假设 $P\left( Y\right)$ 不变(见公式 (2))。例如，Li 等人 [166] 通过最小化所有类在源领域上的类条件分布的方差来学习特征变换。为了允许 $P\left( Y\right)$ 随 $P\left( {X \mid  Y}\right)$ 变化，即异构领域泛化，Hu 等人 [168] 通过去除对边缘分布的最小化约束，放宽了 [166] 中所做的假设，并提出了几种差异度量来学习可泛化的特征。

Since the posterior $P\left( {Y \mid  X}\right)$ is what we need at test time, Wang et al. [172] introduced hypothesis invariant representations, which are obtained by directly aligning the posteriors within each class regardless of domains via the Kullback-Leibler (KL) divergence.

由于后验 $P\left( {Y \mid  X}\right)$ 是我们在测试时所需要的，Wang 等人 [172] 引入了假设不变表示，这些表示是通过 Kullback-Leibler(KL)散度直接对齐每个类内的后验得到的，而不考虑领域。

#### 3.1.2 How to Align

#### 3.1.2 如何对齐

Having discussed what to align in the previous section, here we turn to the exact techniques used in the DG literature for distribution alignment.

在上一节讨论了对齐什么之后，这里我们转向领域泛化文献中用于分布对齐的具体技术。

Minimizing Moments Moments are parameters used to measure a distribution, such as mean (1st-order moment) and variance (2nd-order moment) calculated over a population. Therefore, to achieve invariance between source domains, one can learn a mapping function (e.g., a simple projection matrix [165] or a complex non-linear function modeled by deep neural networks [167]) with an objective of minimizing the moments of the transformed features between source domains, in terms of variance [19], [164] or both mean and variance [165], [166], [167], [168].

最小化矩 矩是用于衡量分布的参数，例如在总体上计算的均值(一阶矩)和方差(二阶矩)。因此，为了实现源领域之间的不变性，可以学习一个映射函数(例如，一个简单的投影矩阵 [165] 或由深度神经网络建模的复杂非线性函数 [167])，其目标是最小化源领域之间变换后特征的矩，包括方差 [19]、[164] 或均值和方差 [165]、[166]、[167]、[168]。

Minimizing Contrastive Loss is another option for reducing distribution mismatch [169], [170], [171], which takes into account the semantic labels. There are two key design principles. The first is about how to construct the anchor group, the positive group (same class as the anchor but from different domains) and the negative group (different class than the anchor). The second is about the formulation of the distance function (e.g., using ${\ell }_{2}$ [169] or softmax [171]). The objective is to pull together the anchor and the positive groups, while push away the anchor and the negative groups.

最小化对比损失 最小化对比损失是减少分布不匹配的另一种选择 [169]、[170]、[171]，它考虑了语义标签。有两个关键的设计原则。第一个是关于如何构建锚定组、正样本组(与锚定样本属于同一类但来自不同领域)和负样本组(与锚定样本属于不同类)。第二个是关于距离函数的公式化(例如，使用 ${\ell }_{2}$ [169] 或 softmax [171])。目标是拉近锚定组和正样本组，同时推远锚定组和负样本组。

Minimizing the KL Divergence As a commonly used distribution divergence measure, the KL divergence has also been employed for domain alignment [172], [173]. In [172], domain-agnostic posteriors within each class are aligned via the KL divergence. In [173], the KL divergence is used to force all source domain features to be aligned with a Gaussian distribution.

最小化 KL 散度 作为一种常用的分布散度度量，KL 散度也被用于领域对齐 [172]、[173]。在 [172] 中，通过 KL 散度对齐每个类内与领域无关的后验。在 [173] 中，使用 KL 散度迫使所有源领域特征与高斯分布对齐。

Minimizing Maximum Mean Discrepancy (MMD) The MMD distance [219] measures the divergence between two probability distributions by first mapping instances to a reproducing kernel Hilbert space (RKHS) and then computing the distance based on their mean. Using the autoencoder architecture, Li et al. [31] minimized the MMD distance between source domain distributions on the hidden-layer features, and meanwhile, forced the feature distributions to be similar to a prior distribution via adversarial learning [220].

最小化最大均值差异(MMD) 最大均值差异(MMD)距离 [219] 通过首先将实例映射到再生核希尔伯特空间(RKHS)，然后基于它们的均值计算距离来衡量两个概率分布之间的差异。使用自编码器架构，Li 等人 [31] 最小化了隐藏层特征上源领域分布之间的 MMD 距离，同时，通过对抗学习 [220] 迫使特征分布与先验分布相似。

Domain-Adversarial Learning Different from explicit distance measures like the MMD, adversarial learning [220] formulates the distribution minimization problem through a minimax two-player game. Initially proposed by Goodfel-low et al. [220], adversarial learning was used to train a generative model, which takes as input random noises and generates photorealistic images. This is achieved by learning a discriminator to distinguish between real and the generated fake images (i.e., minimizing the binary classification loss), while encouraging the generator to fool the discriminator (i.e., maximizing the binary classification loss). In particular, the authors in [220] theoretically justified that generative adversarial learning is equivalent to minimizing the Jensen-Shannon divergence between the real distribution and the generated distribution. Therefore, it is natural to use adversarial learning for distribution alignment, which has already been extensively studied in the domain adaptation area for aligning the source-target distributions [15], [221], [222], [223].

领域对抗学习 与最大均值差异(MMD)等显式距离度量不同，对抗学习 [220] 通过一个极小极大的二人博弈来表述分布最小化问题。对抗学习最初由古德费洛(Goodfellow)等人 [220] 提出，用于训练生成模型，该模型以随机噪声为输入，生成逼真的图像。这是通过学习一个判别器来区分真实图像和生成的虚假图像(即最小化二元分类损失)，同时鼓励生成器欺骗判别器(即最大化二元分类损失)来实现的。特别地，文献 [220] 的作者从理论上证明了生成对抗学习等价于最小化真实分布和生成分布之间的詹森 - 香农散度(Jensen - Shannon divergence)。因此，自然可以使用对抗学习进行分布对齐，这在领域自适应领域已经被广泛研究，用于对齐源域和目标域的分布 [15]、[221]、[222]、[223]。

In DG, adversarial learning is performed between source domains to learn source domain-agnostic features that are expected to work in novel domains [32], [117], [174], [175], [176]. Simply speaking, the learning objective is to make features confuse a domain discriminator, which can be implemented as a multi-class domain discriminator [177], [179], [180], or a binary domain discriminator in a per-domain basis [32], [117]. Typically, the learning steps alternate between the feature generator and the domain discriminator(s) [32]. However, one can simplify the process to achieve singlestep update by using the gradient-reversal layer [15] to flip the sign of the gradients back-propagated from the domain discriminator(s) [178].

在领域泛化(DG)中，在源域之间进行对抗学习，以学习期望在新领域中有效的源域无关特征 [32]、[117]、[174]、[175]、[176]。简单来说，学习目标是让特征使领域判别器产生混淆，领域判别器可以实现为多类领域判别器 [177]、[179]、[180]，或者基于每个领域的二元领域判别器 [32]、[117]。通常，学习步骤在特征生成器和领域判别器之间交替进行 [32]。然而，通过使用梯度反转层 [15] 翻转从领域判别器反向传播的梯度符号，可以简化过程以实现单步更新 [178]。

To enhance domain alignment, researchers have also combined domain-adversarial learning with explicit distance measures like moments minimization [174], or with some regularization constraints such as entropy [181].

为了增强领域对齐，研究人员还将领域对抗学习与显式距离度量(如矩最小化 [174])或一些正则化约束(如熵 [181])相结合。

Multi-Task Learning has also been explored for domain alignment [53], [206]. Different from directly minimizing the distribution divergence, MTL facilitates the learning of generic features by parameter sharing [129]. This is easy to understand: in order to simultaneously deal with different tasks the features have to be generic enough. In [53], the authors proposed a denoising autoencoder architecture (later employed in [206]) where the encoder is shared but the decoder is split into domain-specific branches, each connected to a reconstruction task. The model was trained with two objectives, one being self-domain reconstruction while the other being cross-domain reconstruction, which aim to force the hidden representations to be as generic as possible.

多任务学习(MTL)也被用于领域对齐 [53]、[206]。与直接最小化分布差异不同，多任务学习通过参数共享促进通用特征的学习 [129]。这很容易理解:为了同时处理不同的任务，特征必须足够通用。在文献 [53] 中，作者提出了一种去噪自动编码器架构(后来在文献 [206] 中被采用)，其中编码器是共享的，但解码器被拆分为特定领域的分支，每个分支连接到一个重建任务。该模型以两个目标进行训练，一个是自领域重建，另一个是跨领域重建，旨在迫使隐藏表示尽可能通用。

![0195d149-280f-7e81-bc6e-e908e6b9148e_7_921_122_741_408_0.jpg](images/0195d149-280f-7e81-bc6e-e908e6b9148e_7_921_122_741_408_0.jpg)

Fig. 3. A commonly used meta-learning paradigm [33] in domain generalization. The source domains (i.e., art, photo and cartoon from PACS [37]) are divided into disjoint meta-source and meta-target domains. The outer learning, which simulates domain shift using the meta-target data, back-propagates the gradients all the way back to the base parameters such that the model learned by the inner algorithm with the meta-source data improves the outer objective. The red arrows in this figure denote the gradient flow through the second-order differentiation.

图 3. 领域泛化中常用的元学习范式 [33]。源域(即来自 PACS [37] 的艺术、照片和卡通)被划分为不相交的元源域和元目标域。外部学习使用元目标数据模拟领域偏移，将梯度一直反向传播到基础参数，使得内部算法使用元源数据学习的模型能够改善外部目标。图中的红色箭头表示通过二阶微分的梯度流。

Domain alignment is still a popular research direction in DG. This idea has also been extensively studied in the domain adaptation (DA) literature [15], [16], [151], [224], [225], but with a rigorous theoretical support [3]. In particular, the DA theory introduced in [3] suggested that minimizing the distribution divergence between source and target has a huge impact on lowering the upper-bound of the target error. However, in DG we cannot access the target data and therefore, the alignment is performed only among source domains. This inevitably raises a question of whether a representation learned to be invariant to source domain shift is guaranteed to generalize to an unseen domain shift in the target data. To solve this concern, one can focus on developing novel theories to explain how alignment in source domains improves generalization in unseen domains.

领域对齐仍然是领域泛化中的一个热门研究方向。这个想法在领域自适应(DA)文献 [15]、[16]、[151]、[224]、[225] 中也得到了广泛研究，并且有严格的理论支持 [3]。特别地，文献 [3] 中引入的领域自适应理论表明，最小化源域和目标域之间的分布差异对降低目标误差的上界有巨大影响。然而，在领域泛化中，我们无法访问目标数据，因此，对齐仅在源域之间进行。这不可避免地引发了一个问题:学习到的对源域偏移不变的表示是否能保证泛化到目标数据中未见的领域偏移。为了解决这个问题，可以专注于开发新的理论来解释源域中的对齐如何提高在未见领域中的泛化能力。

### 3.2 Meta-Learning

### 3.2 元学习

Meta-learning has been a fast growing area with applications to many machine learning and computer vision problems [33], [42], [94], [103], [226]. Also known as learning-to-learning, meta-learning aims to learn from episodes sampled from related tasks to benefit future learning (see [227] for a comprehensive survey on meta-learning). The meta-learning paper most related to DG is MAML [226], which divides training data into meta-train and meta-test sets, and trains a model using the meta-train set in such a way to improve the performance on the meta-test set. The MAML-style training usually involves a second-order differentiation through the update of the base model, thus posing issues on efficiency and memory consumption for large neural network models [227]. In [226], MAML was used for parameter initialization, i.e., to learn an initialization state that is only a few gradient steps away from the solution to the target task.

元学习是一个快速发展的领域，应用于许多机器学习和计算机视觉问题 [33]、[42]、[94]、[103]、[226]。元学习也被称为“学习如何学习”，旨在从相关任务中采样的情节中学习，以利于未来的学习(有关元学习的全面综述，请参阅 [227])。与领域泛化最相关的元学习论文是模型无关元学习(MAML) [226]，它将训练数据分为元训练集和元测试集，并使用元训练集训练模型，以提高在元测试集上的性能。MAML 风格的训练通常涉及通过基础模型的更新进行二阶微分，因此对于大型神经网络模型会带来效率和内存消耗方面的问题 [227]。在文献 [226] 中，MAML 用于参数初始化，即学习一个初始化状态，该状态与目标任务的解仅相差几个梯度步骤。

The motivation behind applying meta-learning to DG is to expose a model to domain shift during training with a hope that the model can better deal with domain shift in unseen domains. Existing meta-learning DG methods can only be applied to multi-source DG where domain labels are provided.

将元学习应用于领域泛化(DG)的动机是在训练过程中让模型经历领域偏移，希望模型能够更好地处理未知领域中的领域偏移。现有的元学习领域泛化方法仅适用于提供了领域标签的多源领域泛化问题。

There are two components that need to be carefully designed, namely episodes and meta-representation. Specifically, episodes construction concerns how each episode should be constructed using available samples, while meta-representation answers the question of what to meta-learn.

有两个组件需要精心设计，即情节(episodes)和元表示(meta - representation)。具体而言，情节构建关注如何使用可用样本构建每个情节，而元表示则回答了元学习的内容是什么这一问题。

Episodes Construction Most existing meta-learning-based DG methods [34], [38], [42], [103], [104], [121], [182], [183], [184] followed the learning paradigm proposed in [33]-which is the first method applying meta-learning to DG. Specifically, source domains are divided into nonoverlapping meta-source and meta-target domains to simulate domain shift. The learning objective is to update a model using the meta-source domain(s) in such a way that the test error on the meta-target domain can be reduced, which is often achieved by bi-level optimization. See Fig. 3 for a graphical representation.

情节构建 大多数现有的基于元学习的领域泛化方法[34]、[38]、[42]、[103]、[104]、[121]、[182]、[183]、[184]遵循了文献[33]中提出的学习范式，这是首个将元学习应用于领域泛化的方法。具体来说，源领域被划分为不重叠的元源领域和元目标领域，以模拟领域偏移。学习目标是使用元源领域更新模型，从而降低模型在元目标领域上的测试误差，这通常通过双层优化来实现。图形表示见图3。

Meta-Representation is a term defined in [227] to represent the model parameters that are meta-learned. Most deep learning methods meta-learned the entire neural network models [33], [121], [182]. Balaji et al. [34] instead proposed to meta-learn the regularization parameters. In [183], a stochastic neural network is meta-learned to handle uncertainty. In [42], an MRI segmentation model is meta-learned, along with two shape-aware losses to ensure compactness and smoothness in the segmentation results. Batch normalization layers are meta-learned in [103], [104], [184] to cope with the training-test discrepancy in CNN feature statistics.

元表示是文献[227]中定义的一个术语，用于表示经过元学习得到的模型参数。大多数深度学习方法对整个神经网络模型进行元学习[33]、[121]、[182]。Balaji等人[34]则提出对正则化参数进行元学习。在文献[183]中，对一个随机神经网络进行元学习以处理不确定性。在文献[42]中，对一个磁共振成像(MRI)分割模型进行元学习，并结合两个形状感知损失，以确保分割结果的紧凑性和光滑性。在文献[103]、[104]、[184]中，对批量归一化层进行元学习，以应对卷积神经网络(CNN)特征统计量在训练和测试阶段的差异。

Overall, meta-learning is a promising direction to work on given its effectiveness in not only DG but also a wide range of applications like few-shot classification [226], object detection [228] and image generation [229]. However, meta-learning in DG still suffers the same issue with that in domain alignment-a representation is only learned to be robust under source domain shift (simulated by meta-source and meta-target domains). Such an issue could be aggravated if the source domains are limited in terms of diversity. As observed from recent work [35], [205], both meta-learning and domain alignment methods are under-performed by methods based on directly augmenting the source training data-a topic that will be visited later. One might alleviate the generalization issue in meta-learning, as well as in domain alignment, by combining them with data augmentation. Moreover, advances may also be achieved by designing novel meta-learning algorithms in terms of meta-representation, meta-optimizer, and/or meta-objective. ${}^{3}$

总体而言，鉴于元学习不仅在领域泛化中有效，而且在少样本分类[226]、目标检测[228]和图像生成[229]等广泛应用中也很有效，它是一个值得研究的有前景的方向。然而，领域泛化中的元学习仍然存在与领域对齐相同的问题——所学习到的表示仅在源领域偏移(由元源领域和元目标领域模拟)下具有鲁棒性。如果源领域的多样性有限，这个问题可能会更加严重。从近期的研究[35]、[205]可以看出，基于直接增强源训练数据的方法的性能优于元学习和领域对齐方法，这一主题将在后面讨论。可以通过将元学习和领域对齐与数据增强相结合来缓解它们的泛化问题。此外，还可以通过在元表示、元优化器和/或元目标方面设计新颖的元学习算法来取得进展。${}^{3}$

### 3.3 Data Augmentation

### 3.3 数据增强

Data augmentation has been a common practice to regularize the training of machine learning models to avoid over-fitting and improve generalization [230], which is particularly important for over-parameterized deep neural networks. The basic idea in data augmentation is to augment the original(x, y)pairs with new $\left( {A\left( x\right) , y}\right)$ pairs where $A\left( \cdot \right)$ denotes a transformation, which is typically label-preserving. Not surprisingly, given the advantages of data augmentation, it has been extensively studied in DG where $A\left( \cdot \right)$ is usually seen as a way of simulating domain shift and the design of $A\left( \cdot \right)$ is key to performance.

数据增强是一种常用的方法，用于规范机器学习模型的训练，以避免过拟合并提高泛化能力[230]，这对于参数过多的深度神经网络尤为重要。数据增强的基本思想是用新的$\left( {A\left( x\right) , y}\right)$对来扩充原始的(x, y)对，其中$A\left( \cdot \right)$表示一种变换，通常是保持标签不变的变换。鉴于数据增强的优势，它在领域泛化中得到了广泛研究，这并不奇怪，其中$A\left( \cdot \right)$通常被视为模拟领域偏移的一种方式，$A\left( \cdot \right)$的设计对性能至关重要。

Based on how $A\left( \cdot \right)$ is formulated, data augmentation methods generally fall into four groups. See Fig. 4 for an overview. Below we provide more detailed reviews, with a more fine-grained categorization where adversarial gradients are divided into task-adversarial gradients and domain-adversarial gradients; and model-based augmentation is further split into three sub-groups: random augmentation networks, off-the-shelf style transfer models, and learnable augmentation networks.

根据$A\left( \cdot \right)$的构建方式，数据增强方法通常可分为四类。总体情况见图4。下面我们将提供更详细的综述，并进行更细粒度的分类，其中对抗梯度分为任务对抗梯度和领域对抗梯度；基于模型的增强进一步分为三个子类别:随机增强网络、现成的风格迁移模型和可学习的增强网络。

Image Transformations This type of approach exploits traditional image transformations, such as random flip, rotation and color augmentation. Fig. 5 visualizes some effects of transformations. Though using image transformations does not require domain labels during learning, the selection of transformations is usually problem-specific. For example, for object recognition where image style changes are the main domain shift, one can choose transformations that are more related to color intensity changes, such as brightness, contrast and solarize in Fig. 5. To avoid manual picking, one can design a searching mechanism to search for the optimal set of transformations that best fit the target problem. An example is [39] where the authors proposed an evolution-based searching algorithm and used a worst-case formulation to make the transformed images deviate as much as possible from the original image distribution. One can also select transformations according to the specific downstream task. For instance, [78] addressed the universal feature learning problem in face recognition by synthesizing meaningful variations such as lowering image resolution, adding occlusions and changing head poses.

图像变换 这种方法利用传统的图像变换，如随机翻转、旋转和颜色增强。图5展示了一些变换效果。虽然在学习过程中使用图像变换不需要领域标签，但变换的选择通常是针对具体问题的。例如，对于图像风格变化是主要领域偏移的目标识别任务，可以选择与颜色强度变化更相关的变换，如图5中的亮度、对比度和曝光过度效果。为避免手动选择，可以设计一种搜索机制来寻找最适合目标问题的最优变换集。例如文献[39]中，作者提出了一种基于进化的搜索算法，并使用最坏情况公式使变换后的图像尽可能偏离原始图像分布。也可以根据具体的下游任务选择变换。例如，文献[78]通过合成有意义的变化，如降低图像分辨率、添加遮挡和改变头部姿势，解决了人脸识别中的通用特征学习问题。

Traditional image transformations have been shown very effective in dealing with domain shift in medical images [186], [187], [188]. This makes sense because image transformations can well simulate changes in color and geometry caused by device-related domain shift, such as using different types of scanners in different medical centers. However, image transformations can be limited in some applications as they might cause label shift, such as digit recognition or optical character recognition where the horizontal/vertical flip operation is infeasible. Therefore, transformations should be carefully chosen to not conflict with the downstream task.

传统的图像变换在处理医学图像中的领域偏移方面已被证明非常有效[186]、[187]、[188]。这是合理的，因为图像变换可以很好地模拟由设备相关的领域偏移引起的颜色和几何形状变化，例如不同医疗中心使用不同类型的扫描仪。然而，图像变换在某些应用中可能会受到限制，因为它们可能会导致标签偏移，例如数字识别或光学字符识别，其中水平/垂直翻转操作是不可行的。因此，应谨慎选择变换，以避免与下游任务冲突。

Task-Adversarial Gradients Inspired by adversarial attacks [231], [232], several data augmentation methods are based on using adversarial gradients obtained from the task classifier to perturb the input images [73], [189], [190]. In doing so, the original data distribution is expanded, allowing the model to learn more generalizable features. Though this type of approach is often developed for tackling single-source DG, the idea can also be directly applied to multi-source scenarios.

任务对抗梯度 受对抗攻击[231]、[232]的启发，几种数据增强方法基于使用从任务分类器获得的对抗梯度来扰动输入图像[73]、[189]、[190]。这样做可以扩展原始数据分布，使模型能够学习更具泛化性的特征。虽然这种方法通常是为解决单源领域泛化问题而开发的，但该思想也可以直接应用于多源场景。

![0195d149-280f-7e81-bc6e-e908e6b9148e_9_236_119_1356_387_0.jpg](images/0195d149-280f-7e81-bc6e-e908e6b9148e_9_236_119_1356_387_0.jpg)

Fig. 4. Based on the formulation of the transformation $A\left( \cdot \right)$ , existing data augmentation methods can be categorized into four groups. a) The first group enhances the generalization of the classifier $f$ by applying hand-engineered image transformations like random crop or color augmentation to simulating domain shift. b) The second group is based on adversarial gradients obtained from either a category classifier $\left( {h = f}\right)$ or a domain classifier. c) The third group models $A\left( \cdot \right)$ using neural networks, such as random CNNs [191], an off-the-shelf style transfer model [29], or a learnable image generator [35]. d) The final group injects perturbation into intermediate features in the task model.

图4. 根据变换$A\left( \cdot \right)$的公式，现有的数据增强方法可以分为四类。a) 第一类通过应用手工设计的图像变换(如随机裁剪或颜色增强)来模拟领域偏移，从而增强分类器$f$的泛化能力。b) 第二类基于从类别分类器$\left( {h = f}\right)$或领域分类器获得的对抗梯度。c) 第三类使用神经网络对$A\left( \cdot \right)$进行建模，如随机卷积神经网络[191]、现成的风格迁移模型[29]或可学习的图像生成器[35]。d) 最后一类将扰动注入到任务模型的中间特征中。

![0195d149-280f-7e81-bc6e-e908e6b9148e_9_226_717_572_363_0.jpg](images/0195d149-280f-7e81-bc6e-e908e6b9148e_9_226_717_572_363_0.jpg)

Fig. 5. Common image transformations used as data augmentation in domain generalization [39], [186], [187], [188].

图5. 在领域泛化中用作数据增强的常见图像变换[39]、[186]、[187]、[188]。

Domain-Adversarial Gradients When it comes to multi-source DG where domain labels are provided, one can exploit domain-adversarial gradients to synthesize domain-agnostic images. For instance, [40] trained a domain classifier and used its adversarial gradients to perturb the input images. Intuitively, by learning with domain-agnostic images, the task model is allowed to learn more domain-invariant patterns.

领域对抗梯度 对于提供了领域标签的多源领域泛化问题，可以利用领域对抗梯度来合成领域无关的图像。例如，文献[40]训练了一个领域分类器，并使用其对抗梯度来扰动输入图像。直观地说，通过使用领域无关的图像进行学习，任务模型可以学习到更多领域不变的模式。

Since adversarial gradients-based perturbation is purposefully designed to be visually imperceptible [231], methods based on adversarial gradients are often criticized for not being able to simulate real-world domain shift, which is much more complicated than salt-and-pepper noise [36]. Furthermore, the computational cost is often doubled in these methods because the forward and backward passes need to be computed twice, which could pose serious efficiency issues for large neural networks. Below we discuss model-based methods that formulate the transformation $A\left( \cdot \right)$ using neural networks and can produce more diverse visual effects.

由于基于对抗梯度的扰动被特意设计为在视觉上不可察觉[231]，基于对抗梯度的方法经常被批评无法模拟现实世界中的领域偏移，而现实世界的领域偏移比椒盐噪声要复杂得多[36]。此外，这些方法的计算成本通常会翻倍，因为前向和反向传播需要计算两次，这可能会给大型神经网络带来严重的效率问题。下面我们将讨论基于模型的方法，这些方法使用神经网络来构建变换$A\left( \cdot \right)$，并可以产生更多样化的视觉效果。

Random Augmentation Networks RandConv [191] is based on the idea of using randomly initialized, single-layer convolutioinal neural network to transform the input images to "novel domains." Since the weights are randomly sampled from a Gaussian distribution at each iteration and no learning is performed, the transformed images mainly contain random color distortions, which do not contain meaningful variations and are best to be mixed with the original images before passing to the task network.

随机增强网络 RandConv[191]基于使用随机初始化的单层卷积神经网络将输入图像转换到“新领域”的思想。由于权重在每次迭代时从高斯分布中随机采样，并且不进行学习，变换后的图像主要包含随机的颜色失真，不包含有意义的变化，最好在输入到任务网络之前与原始图像混合。

Off-the-Shelf Style Transfer Models Taking advantage of the advances in style transfer [233], several DG methods [29], [192], [193] use off-the-shelf style transfer models like AdaIN [233] to represent $A\left( \cdot \right)$ , which essentially maps images from one source domain to another for data augmentation. Instead of transferring image styles between source domains, one can exploit external styles to further diversify the source training data [20]. Though these methods do not need to train the style transfer component, they still need domain labels for domain translation.

现成的风格迁移模型 利用风格迁移方面的进展[233]，几种领域泛化(DG)方法[29]、[192]、[193]使用像自适应实例归一化(AdaIN)[233]这样的现成风格迁移模型来表示$A\left( \cdot \right)$，该模型本质上是将图像从一个源领域映射到另一个源领域以进行数据增强。除了在源领域之间进行图像风格迁移之外，还可以利用外部风格来进一步使源训练数据多样化[20]。尽管这些方法不需要训练风格迁移组件，但它们仍然需要领域标签来进行领域转换。

Learnable Augmentation Networks This group of methods aims to learn augmentation neural networks to synthesize new domains [35], [36], [194]. In [36], [194], domain-agnostic images are generated by maximizing the domain classification loss with respect to the image generator. In [35], pseudo-novel domains are synthesized by maximizing for each source domain the domain distance measured by optimal transport [217] between the original and synthetic images.

可学习的增强网络 这类方法旨在学习增强神经网络以合成新的领域[35]、[36]、[194]。在文献[36]、[194]中，通过最大化图像生成器的领域分类损失来生成与领域无关的图像。在文献[35]中，通过最大化每个源领域中原始图像和合成图像之间由最优传输[217]测量的领域距离来合成伪新领域。

Feature-Based Augmentation Though the above learnable augmentation models have shown promising results, their efficiency is a main concern as they need to train heavy image-to-image translation models. Another line of research focuses on feature-level augmentation [23], [28], [147]. Motivated by the observation that image styles are captured in CNN feature statistics, MixStyle [23], [28] achieves style augmentation by mixing CNN feature statistics between instances of different domains. In [147], Mixup [234] is applied to mixing instances of different domains in both pixel and feature space.

基于特征的增强 尽管上述可学习的增强模型已经显示出了有前景的结果，但由于它们需要训练复杂的图像到图像的翻译模型，其效率是一个主要问题。另一类研究专注于特征级别的增强[23]、[28]、[147]。受卷积神经网络(CNN)特征统计能够捕捉图像风格这一观察结果的启发，混合风格(MixStyle)[23]、[28]通过混合不同领域实例之间的CNN特征统计来实现风格增强。在文献[147]中，混合(Mixup)[234]被应用于在像素和特征空间中混合不同领域的实例。

### 3.4 Ensemble Learning

### 3.4 集成学习

As an extensively studied topic in machine learning research, ensemble learning [235] typically learns multiple copies of the same model with different initialization weights or using different splits of training data, and uses their ensemble for prediction. Such a simple technique has been shown very effective in boosting the performance of a single model across a wide range of applications [6], [7], [236].

作为机器学习研究中广泛研究的一个主题，集成学习[235]通常使用不同的初始化权重或不同的训练数据划分来学习同一模型的多个副本，并使用它们的集成进行预测。这种简单的技术已被证明在广泛的应用中能够有效提升单个模型的性能[6]、[7]、[236]。

Exemplar-SVMs are a collection of SVM classifiers, each learned using one positive instance and all negative instances [237]. As the ensemble of such exemplar SVMs have shown excellent generalization performance on the object detection task in [237], Xu et al. [195] have extended exemplar-SVMs to DG. In particular, given a test sample the top-K exemplar classifiers that give the highest prediction scores (hence more confident) are selected for ensemble prediction. Such an idea of learning exemplar classifiers was also investigated in [196], [197] for DG.

示例支持向量机(Exemplar - SVMs)是一组支持向量机(SVM)分类器，每个分类器使用一个正实例和所有负实例进行学习[237]。由于这种示例SVM的集成在文献[237]的目标检测任务中显示出了出色的泛化性能，徐等人[195]将示例SVM扩展到了领域泛化(DG)。具体来说，对于一个测试样本，选择给出最高预测分数(因此更有信心)的前K个示例分类器进行集成预测。这种学习示例分类器的思想也在文献[196]、[197]中针对领域泛化进行了研究。

Domain-Specific Neural Networks Since CNNs excel at discriminative feature learning [7], it is natural to replace hand-engineered SVM classifiers with CNN-based models for ensemble learning. A common practice is to learn domain-specific neural networks, each specializing in a source domain [61], [198]. Rather than learning an independent CNN for each source domain [198], it is more efficient, and makes more sense as well, to share between source domains some shallow layers [61], which capture generic features [139]. Another question is how to compute the prediction. One can simply use the ensemble prediction averaged over all individuals with equal weights (e.g., [61], [199]). Alternatively, weighted averaging can be adopted where the weights are estimated by, for example, a source domain classifier aiming to measure the similarity of the target sample to each source domain [201]. Also, the weights can be used to determine the most confident candidate whose output will serve for final prediction [200].

特定领域的神经网络 由于卷积神经网络(CNNs)在判别性特征学习方面表现出色[7]，自然可以用基于CNN的模型来替代手工设计的SVM分类器进行集成学习。一种常见的做法是学习特定领域的神经网络，每个网络专门针对一个源领域[61]、[198]。与为每个源领域学习一个独立的CNN[198]不同，在源领域之间共享一些浅层(这些浅层捕捉通用特征[139])更为高效，也更有意义[61]。另一个问题是如何计算预测结果。可以简单地使用对所有个体进行等权重平均的集成预测(例如[61]、[199])。或者，可以采用加权平均，其中权重例如由一个源领域分类器来估计，该分类器旨在测量目标样本与每个源领域的相似度[201]。此外，权重还可以用于确定最有信心的候选者，其输出将用于最终预测[200]。

Domain-Specific Batch Normalization In batch normalization (BN) [238], the statistics are computed on-the-fly during training and their moving averages are stored in buffers for inference. Since the statistics typically vary in different source domains, one could argue that mixing statistics of multiple source domains is detrimental to learning generalizable representations. One solution is to use domain-specific BNs [202], [204], one for each source domain for collecting domain-specific statistics. This is equivalent to constructing domain-specific classifiers but with parameter sharing for most parts of a model except the normalization layers. Such a design was later adopted in [41] for dealing with MRI segmentation. In [203], the domain-specific predictions are aggregated using as weights the distance between a test data's instance-level feature statistics and the source domain BN statistics.

特定领域的批量归一化 在批量归一化(BN)[238]中，统计量在训练期间实时计算，并且它们的移动平均值存储在缓冲区中用于推理。由于统计量通常在不同的源领域中有所不同，有人可能会认为混合多个源领域的统计量不利于学习可泛化的表示。一种解决方案是使用特定领域的BN[202]、[204]，每个源领域使用一个BN来收集特定领域的统计量。这相当于构建特定领域的分类器，但除了归一化层之外，模型的大部分部分共享参数。这种设计后来在文献[41]中被用于处理磁共振成像(MRI)分割。在文献[203]中，使用测试数据的实例级特征统计与源领域BN统计之间的距离作为权重来聚合特定领域的预测结果。

Weight Averaging aggregates model weights at different time steps during training to form a single model at test time [239]. Unlike explicit ensemble learning where multiple models (or model parts) need to be trained, weight averaging is a more efficient solution as the model only needs to be trained once. In [205], the authors have demonstrated that weight averaging can greatly improve model robustness under domain shift. In fact, such a technique is orthogonal to many other DG approaches and can be applied as a postprocessing method to further boost the DG performance.

权重平均 在训练期间的不同时间步聚合模型权重，以便在测试时形成单个模型[239]。与需要训练多个模型(或模型部分)的显式集成学习不同，权重平均是一种更高效的解决方案，因为模型只需要训练一次。在文献[205]中，作者证明了权重平均可以大大提高模型在领域偏移下的鲁棒性。实际上，这种技术与许多其他领域泛化方法是正交的，可以作为一种后处理方法来进一步提升领域泛化性能。

### 3.5 Self-Supervised Learning

### 3.5 自监督学习

Self-supervised learning is often referred to as learning with free labels generated from data itself (see [242] for a comprehensive survey on self-supervised learning). In computer vision, this can be achieved by teaching a model to predict the transformations applied to the image data, such as the shuffling order of patch-shuffled images [240] or rotation degrees [241]. See Fig. 6 for illustrations.

自监督学习通常指利用从数据本身生成的免费标签进行学习(有关自监督学习的全面综述请参阅[242])。在计算机视觉领域，这可以通过训练模型来预测应用于图像数据的变换来实现，例如图像块打乱后的打乱顺序[240]或旋转角度[241]。具体示例见图6。

![0195d149-280f-7e81-bc6e-e908e6b9148e_10_909_117_755_331_0.jpg](images/0195d149-280f-7e81-bc6e-e908e6b9148e_10_909_117_755_331_0.jpg)

Fig. 6. Common pretext tasks used for self-supervised learning in domain generalization. One can use a single pretext task, like solving Jigsaw puzzles [240] or predicting rotations [241], or combine multiple pretext tasks in a multi-task learning fashion.

图6. 领域泛化中用于自监督学习的常见前置任务。可以使用单个前置任务，如解决拼图难题[240]或预测旋转角度[241]，也可以以多任务学习的方式组合多个前置任务。

So why can self-supervised learning improve DG? An intuitive explanation is that solving pretext tasks allows a model to learn generic features regardless of the target task, and hence less over-fitting to domain-specific biases [49]. An obvious advantage of self-supervised learning is that it can be applied to both single- and multi-source scenarios without requiring any domain labels.

那么，为什么自监督学习可以提升领域泛化(DG)能力呢？一个直观的解释是，解决前置任务可以让模型学习到与目标任务无关的通用特征，从而减少对特定领域偏差的过拟合[49]。自监督学习的一个明显优势是，它可以应用于单源和多源场景，且无需任何领域标签。

Single Pretext Task In addition to using the standard classification loss, Carlucci et al. [49] taught a neural network to solve the Jigsaw puzzles problem [240], hoping that the network can learn regularities that are more generalizable across domains. Similarly, Wang et al. [134] used the Jigsaw solving task as an intrinsic supervision, together with an extrinsic supervision implemented using metric learning. Reconstruction has also been investigated for DG, such as learning an autoencoder to reconstruct image pixels/features [53], [206].

单一前置任务 除了使用标准的分类损失外，Carlucci等人[49]训练了一个神经网络来解决拼图难题[240]，希望该网络能够学习到在不同领域更具泛化性的规律。类似地，Wang等人[134]将解决拼图任务作为一种内在监督，同时结合使用度量学习实现的外在监督。重建方法也被用于领域泛化研究，例如学习一个自动编码器来重建图像像素/特征[53]、[206]。

Multiple Pretext Tasks It is also possible to combine multiple pretext tasks. In [50], the authors combined two pretext tasks, namely solving Jigsaw puzzles and predicting rotations. In [135], three pretext tasks are combined, namely reconstructing the Gabor filter's response, predicting rotations, and predicting feature cluster assignments [243]. Overall, using multiple pretext tasks gives a better performance than using a single pretext task, as shown in [50].

多个前置任务 也可以将多个前置任务组合起来。在文献[50]中，作者将两个前置任务结合起来，即解决拼图难题和预测旋转角度。在文献[135]中，组合了三个前置任务，即重建Gabor滤波器的响应、预测旋转角度和预测特征聚类分配[243]。总体而言，如文献[50]所示，使用多个前置任务比使用单个前置任务能取得更好的性能。

Currently, these self-supervised learning-based DG methods have only been evaluated on the object recognition task. It is still unclear whether they will work on a wider range of OOD generalization tasks, which would be interesting to investigate in future work. Another concerns are that in general none of the existing pretext tasks is universal, and that the selection of pretext tasks is problem-specific. For instance, when the target domain shift is related to rotations, the model learned with the rotation prediction task will capture rotation-sensitive information, which is harmful to generalization.

目前，这些基于自监督学习的领域泛化方法仅在目标识别任务上进行了评估。尚不清楚它们是否能在更广泛的分布外(OOD)泛化任务中发挥作用，这值得在未来的工作中进行研究。另一个问题是，一般来说，现有的前置任务都不具有通用性，并且前置任务的选择是针对具体问题的。例如，当目标领域的变化与旋转有关时，通过旋转预测任务学习的模型会捕捉到对旋转敏感的信息，这对泛化是有害的。

Recent state-of-the-art self-supervised learning methods [244], [245] are mostly based on combining contrastive learning with data augmentation. The key idea is to pull together the same instance (image) undergone different transformations (e.g., random flip and color distortion) while push away different instances to learn instance-aware representations. Different from predicting transformations such as rotation, contrastive learning aims to learn transformation-invariant representations. Future work can explore whether invariances learned via contrastive learning can better adapt to OOD data.

最近的先进自监督学习方法[244]、[245]大多基于将对比学习与数据增强相结合。其核心思想是将经过不同变换(如随机翻转和颜色失真)的同一实例(图像)拉近，同时将不同实例推开，以学习实例感知表示。与预测旋转等变换不同，对比学习旨在学习对变换不变的表示。未来的工作可以探索通过对比学习学到的不变性是否能更好地适应分布外数据。

### 3.6 Learning Disentangled Representations

### 3.6 学习解纠缠表示

Instead of forcing the entire model or features to be domain-invariant, which is challenging, one can relax this constraint by allowing some parts to be domain-specific, essentially learning disentangled representations. The existing approaches falling into this group are either based on decomposition [37], [46], [207], [208] or generative modeling [209], [210], both requiring domain labels for feature disentanglement.

由于强制整个模型或特征具有领域不变性具有挑战性，因此可以放宽这一约束，允许某些部分具有领域特异性，本质上是学习解纠缠表示。属于这一类的现有方法要么基于分解[37]、[46]、[207]、[208]，要么基于生成式建模[209]、[210]，这两种方法都需要领域标签来进行特征解纠缠。

Decomposition An intuitive way to achieve disentangled representation learning is to decompose a model into two parts, one being domain-specific while the other being domain-agnostic. Based on SVMs, Khosla et al. [46] decomposed a classifier into domain-specific biases and domain-agnostic weights, and only kept the latter when dealing with unseen domains. This approach was later extended to neural networks in [37]. One can also design domain-specific modules such as in [207] where domain-specific binary masks are imposed on the final feature vector to distinguish between domain-specific and domain-invariant components. Another solution is to apply low-rank decomposition to a model's weight matrices in order to identify common features that are more generalizable [208].

分解 实现解纠缠表示学习的一种直观方法是将模型分解为两部分，一部分具有领域特异性，另一部分具有领域无关性。基于支持向量机(SVM)，Khosla等人[46]将分类器分解为特定领域的偏差和领域无关的权重，并在处理未知领域时只保留后者。这种方法后来在文献[37]中扩展到了神经网络。也可以设计特定领域的模块，例如在文献[207]中，将特定领域的二进制掩码应用于最终特征向量，以区分特定领域和领域不变的组件。另一种解决方案是对模型的权重矩阵进行低秩分解，以识别更具泛化性的公共特征[208]。

Generative Modeling has been a powerful tool for learning disentangled representations [246]. In [209], a variational autoencoder (VAE) is utilized to learn three independent latent subspaces for class, domain and object, respectively. In [210], two separate encoders are learned in an adversarial way to capture identity and domain information respectively for cross-domain face anti-spoofing.

生成式建模一直是学习解纠缠表示的有力工具[246]。在文献[209]中，利用变分自动编码器(VAE)分别学习用于类别、领域和对象的三个独立潜在子空间。在文献[210]中，以对抗的方式学习两个独立的编码器，分别用于捕捉跨领域人脸反欺骗的身份信息和领域信息。

### 3.7 Regularization Strategies

### 3.7 正则化策略

Some approaches focus on regularization strategies designed based on some heuristics. Wang et al. [51] argued that generalizable features should capture the global structure/shape of objects rather than relying on local patches/textures, and therefore proposed to suppress the predictive power of auxiliary patch-wise CNNs (maximizing their classification errors), implemented as a stack of $1 \times  1$ convolution layers. With a similar motivation, Huang et al. [52] iteratively masked out over-dominant features with large gradients, thus forcing the model to rely more on the remaining features. These methods do not require domain labels for learning, and are orthogonal to other DG methods like those based on domain alignment [117], [169] and data augmentation [23], [35], [39]. Therefore, one could potentially combine them to improve the performance in practice.

一些方法专注于基于启发式设计的正则化策略。Wang等人[51]认为，具有泛化能力的特征应该捕捉物体的全局结构/形状，而不是依赖于局部块/纹理，因此提出抑制辅助逐块卷积神经网络(CNN)的预测能力(最大化其分类误差)，该网络实现为一个由$1 \times  1$卷积层组成的堆栈。出于类似的动机，Huang等人[52]迭代地屏蔽掉具有大梯度的过度主导特征，从而迫使模型更多地依赖于其余特征。这些方法在学习过程中不需要领域标签，并且与其他领域泛化(DG)方法(如基于领域对齐[117]、[169]和数据增强[23]、[35]、[39]的方法)是正交的。因此，在实践中可以潜在地将它们结合起来以提高性能。

### 3.8 Reinforcement Learning

### 3.8 强化学习

Domain shift in reinforcement learning (RL) not only occurs in visual appearance (color/style changes, etc.) but also in other aspects like dynamics (transition function) or rewards (e.g., gravity/friction changes) [125]. For visual domain shift, many of the DG methods surveyed above seem applicable for RL, such as data augmentation methods [23], [214], but not for the latter that requires more problem-specific designs. Below we briefly discuss some representative generalization methods developed for RL. Please refer to [125] for a more comprehensive survey.

强化学习(RL)中的领域偏移不仅发生在视觉外观(颜色/风格变化等)方面，还发生在其他方面，如动态特性(转移函数)或奖励(例如，重力/摩擦力变化)[125]。对于视觉领域偏移，上述调查的许多领域泛化方法似乎适用于强化学习，如数据增强方法[23]、[214]，但对于后者(动态特性或奖励方面的偏移)则需要更多针对特定问题的设计。下面我们简要讨论一些为强化学习开发的代表性泛化方法。更全面的综述请参考[125]。

Data Augmentation The main idea is to augment the visual signal sent to an RL agent to make it more domain-generalizable. A common approach is to use label-preserving transformations [123], [211], [212] like color jittering or Cutout [247]. One can also implement the concept of domain randomization [213], which visually randomizes an environment through, e.g., computer simulators [213] or random neural networks [214]. When convolutional neural networks are used, one can adopt the MixStyle [23] approach discussed in Sec. 3.3 to create "novel" domains in the feature space.

数据增强 主要思想是增强发送给强化学习智能体的视觉信号，使其更具领域泛化能力。一种常见的方法是使用保持标签不变的变换[123]、[211]、[212]，如颜色抖动或Cutout[247]。还可以实现领域随机化的概念[213]，即通过例如计算机模拟器[213]或随机神经网络[214]在视觉上对环境进行随机化。当使用卷积神经网络时，可以采用第3.3节中讨论的MixStyle[23]方法在特征空间中创建“新颖”的领域。

Self-Supervision Combining RL with self-supervised learning, which does not require manual labels, has also been explored. The general pipeline is to augment an RL model with auxiliary loss(es). For instance, Yarats et al. [215] proposed a reconstruction loss based on auto-encoders; Laskin et al. [216] combined RL with an unsupervised contrastive learning loss.

自监督学习 将强化学习与无需手动标签的自监督学习相结合也得到了探索。一般的流程是为强化学习模型添加辅助损失。例如，Yarats等人[215]提出了基于自编码器的重建损失；Laskin等人[216]将强化学习与无监督对比学习损失相结合。

## 4 THEORIES

## 4 理论

Unlike domain adaptation in which plenty of learning bounds with theoretical guarantees have been proposed [248], bounding the risk for domain generalization (DG) is challenging due to the absence of target data. Nonetheless, some attempts have been made to address this problem, which are briefly reviewed in this section.

与领域自适应不同，领域自适应已经提出了许多具有理论保证的学习界[248]，由于缺乏目标数据，界定领域泛化(DG)的风险具有挑战性。尽管如此，已经有人尝试解决这个问题，本节将简要回顾这些尝试。

Most existing theoretical studies are subject to specific model classes, such as kernel methods [5], [19], [168], [249], or have strong assumptions that cannot be simply applied to broader DG methods. In [173], the latent feature space of all possible domains (including both source and target) is assumed to have a linear dependency, meaning that each domain is a linear combination of other domains. Based on the linear dependency assumption, a rank regularization method is proposed and combined with a distribution alignment method. In [175], source domains are assumed to form a convex hull so that minimizing the maximum pairwise distance within the source domains would lead to a decrease in the distance between any two domains in the convex hull. In [250], DG is cast into an online game where a player (model) minimizes the risk for a "new" distribution presented by an adversary at each time-step. In [251], proxy measures that correlate well with "true" OOD generalization are investigated.

大多数现有的理论研究都针对特定的模型类别，如核方法[5]、[19]、[168]、[249]，或者有很强的假设，不能简单地应用于更广泛的领域泛化方法。在文献[173]中，假设所有可能领域(包括源领域和目标领域)的潜在特征空间具有线性相关性，这意味着每个领域都是其他领域的线性组合。基于线性相关性假设，提出了一种秩正则化方法，并将其与分布对齐方法相结合。在文献[175]中，假设源领域形成一个凸包，因此最小化源领域内的最大成对距离将导致凸包内任意两个领域之间的距离减小。在文献[250]中，领域泛化被建模为一个在线游戏，其中玩家(模型)在每个时间步最小化对手提出的“新”分布的风险。在文献[251]中，研究了与“真实”分布外泛化有良好相关性的代理度量。

More recently, there are a couple of emerging studies [252], [253] that aim to provide more generic bounds, with more relaxed assumptions, for DG. In [252], feature distribution is quantified by two terms: i) a variation term measuring the stability of feature representations across domains; ii) an informativeness term indicating the discriminativeness of feature representations (i.e., how well they can be used to distinguish different classes). Then, the error on unseen domains is bounded by an expansion function based on the variation term, subject to the learnability of feature representations measured using the informativeness term.

最近，有几项新兴研究[252]、[253]旨在为领域泛化提供更通用的界，且假设条件更为宽松。在文献[252]中，特征分布由两个项来量化:i) 一个变化项，用于衡量特征表示在不同领域之间的稳定性；ii) 一个信息性项，用于表示特征表示的区分能力(即它们区分不同类别的能力)。然后，未见过领域上的误差由一个基于变化项的扩展函数界定，同时受使用信息性项衡量的特征表示可学习性的约束。

In [253], the generalization gap is bounded in terms of the model's Rademacher complexity, suggesting that a lower model complexity with strong regularization can improve generalization in unseen domains-which echoes the findings in [128]: properly regularized Empirical Risk Minimization with leave-one-domain-out cross-validation is a strong DG baseline.

在文献[253]中，泛化差距根据模型的拉德马赫复杂度进行界定，这表明具有强正则化的较低模型复杂度可以提高在未见过领域上的泛化能力——这与文献[128]的发现相呼应:采用留一领域交叉验证的适当正则化经验风险最小化是一种强大的领域泛化基线方法。

## 5 FUTURE RESEARCH DIRECTIONS

## 5 未来研究方向

So far we have covered the background on domain generalization (DG) in $§2$ -knowing what DG is about and how DG is typically evaluated under different settings/datasets-as well as gone though the existing methodologies developed over the last decade in $§3$ . The following questions would naturally arise: i) Has DG been solved? ii) If not, how far are we from solving DG?

到目前为止，我们已经介绍了$§2$中领域泛化(Domain Generalization，DG)的背景知识——了解DG是什么以及在不同设置/数据集下通常如何评估DG——还回顾了过去十年在$§3$中发展起来的现有方法。自然会产生以下问题:i) DG问题是否已经得到解决？ii) 如果没有，我们距离解决DG问题还有多远？

The answer is of course not-DG is a very challenging problem and is far from being solved. In this section, we aim to share some insights on future research directions, pointing out what have been missed in the current research and discussing what are worth exploring to further this field. Specifically, we discuss potential directions from three perspectives: model (§ 5.1), learning (§ 5.2), and benchmarks (§5.3).

答案当然是否定的——DG是一个极具挑战性的问题，远未得到解决。在本节中，我们旨在分享一些关于未来研究方向的见解，指出当前研究中被忽视的方面，并探讨哪些方面值得进一步探索以推动该领域的发展。具体而言，我们从三个角度讨论潜在的研究方向:模型(§ 5.1)、学习(§ 5.2)和基准测试(§5.3)。

### 5.1 Model Architecture

### 5.1 模型架构

Dynamic Architectures The weights in a convolutional neural network (CNN), which serve as feature detectors, are normally fixed once learned from source domains. This may result in the representational power of a CNN model restricted to the seen domains while generalizing poorly when the image statistics in an unseen domain are significantly different. One potential solution is to develop dynamic architectures [254], e.g., with weights conditioned on the input [255]. The key is to make neural networks' parameters (either partly or entirely) dependent on the input while ensuring that the model size is not too large to harm the efficiency. Dynamic architectures such as dynamic filter networks [255] and conditional convolutions [256] have been shown effective on generic visual recognition tasks like classification and segmentation. It would be interesting to see whether such a flexible architecture can be used to cope with domain shift in DG.

动态架构 卷积神经网络(Convolutional Neural Network，CNN)中的权重作为特征检测器，一旦从源领域学习得到后通常是固定的。这可能导致CNN模型的表征能力局限于已见领域，而当未见领域的图像统计特征显著不同时，泛化能力较差。一种潜在的解决方案是开发动态架构[254]，例如，使权重依赖于输入[255]。关键在于让神经网络的参数(部分或全部)依赖于输入，同时确保模型规模不会过大而影响效率。像动态滤波器网络[255]和条件卷积[256]这样的动态架构，已被证明在分类和分割等通用视觉识别任务中是有效的。看看这种灵活的架构是否可用于应对DG中的领域偏移，将是一件有趣的事情。

Adaptive Normalization Layers Normalization layers [238], [257], [258] have been a core building block in contemporary neural networks. Following [259], a general formulation for different normalization layers can be written as $\gamma \frac{x - \mu }{\sigma } + \beta$ , where $\mu$ and $\sigma$ denote mean and variance respectively; $\gamma$ and $\beta$ are learnable scaling and shift parameters respectively. Typically, $\left( {\mu ,\sigma }\right)$ are computed on-the-fly during training but are saved in buffers using their moving averages for inference. Regardless of whether they are computed within each instance or based on a mini-batch, they can only represent the distribution of training data. The affine transformation parameters, i.e., $\gamma$ and $\beta$ , are also learned for source data only. Therefore, a normalization layer's parameters are not guaranteed to work well under domain shift in unseen test data. It would be a promising direction to investigate how to make these parameters adaptive to unseen domains [260].

自适应归一化层 归一化层[238]、[257]、[258]一直是当代神经网络的核心组成部分。根据文献[259]，不同归一化层的通用公式可以写成$\gamma \frac{x - \mu }{\sigma } + \beta$，其中$\mu$和$\sigma$分别表示均值和方差；$\gamma$和$\beta$分别是可学习的缩放和偏移参数。通常，$\left( {\mu ,\sigma }\right)$在训练过程中实时计算，但在推理时使用其移动平均值保存在缓冲区中。无论它们是在每个实例内计算还是基于小批量计算，它们都只能表示训练数据的分布。仿射变换参数，即$\gamma$和$\beta$，也仅针对源数据进行学习。因此，不能保证归一化层的参数在未见测试数据的领域偏移情况下能良好工作。研究如何使这些参数适应未见领域将是一个有前景的研究方向[260]。

### 5.2 Learning

### 5.2 学习

Learning without Domain Labels Most existing methods leveraged domain labels in their models. However, in real-world applications it is possible that domain labels are difficult to obtain, e.g., web images crawled from the Internet are taken by arbitrary users with arbitrary domain characteristics and thus the domain labels are extremely difficult to define [197]. In such scenarios where domain labels are missing, many top-performing DG approaches are not viable any more or the performance deteriorates [118]. Though this topic has been studied in the past (e.g., [23], [177], [261]), methods that can deal with the absence of domain labels are still scarce and noncompetitive with methods that utilize domain labels. Considering that learning without domain labels is much more efficient and scalable, we encourage more future work to tackle this topic. We also suggest future work that uses domain labels evaluate the ability of functioning without proper domain labels-if applicable-like the random grouping experiment done in [118].

无领域标签学习 大多数现有方法在其模型中利用了领域标签。然而，在现实应用中，领域标签可能难以获取，例如，从互联网上爬取的网络图像是由具有任意领域特征的任意用户拍摄的，因此领域标签极难定义[197]。在这种缺少领域标签的场景中，许多表现优异的DG方法不再可行，或者性能会下降[118]。尽管过去已经对这个主题进行了研究(例如，[23]、[177]、[261])，但能够处理领域标签缺失问题的方法仍然很少，并且与利用领域标签的方法相比缺乏竞争力。考虑到无领域标签学习更高效且可扩展性更强，我们鼓励未来开展更多工作来解决这个问题。我们还建议未来使用领域标签的工作评估在没有合适领域标签的情况下的工作能力(如果适用)，就像文献[118]中进行的随机分组实验那样。

Learning to Synthesize Novel Domains The DG performance can greatly benefit from increasing the diversity of source domains. This is also confirmed in a recent work [262] where the authors emphasized the importance of having diverse training distributions to out-of-distribution (OOD) generalization. However, in practice it is impossible to collect training data that cover all possible domains. As such, learning to synthesize novel domains can be a potential solution. Though this idea has been roughly explored in a couple of recent DG works [23], [35], the results still have much room for improvements.

学习合成新领域 增加源领域的多样性可以极大地提高DG性能。最近的一项工作[262]也证实了这一点，该工作的作者强调了拥有多样化的训练分布对于分布外(Out-of-Distribution，OOD)泛化的重要性。然而，在实践中，不可能收集涵盖所有可能领域的训练数据。因此，学习合成新领域可能是一个潜在的解决方案。尽管最近有几项DG工作[23]、[35]大致探索了这个想法，但结果仍有很大的改进空间。

Avoiding Learning Shortcut Shortcut learning can be interpreted as a problem of learning "easy" representations that can perform well on training data but are irrelevant to the task [263]. For example, given the task of distinguishing between digits blended with different colors, a neural network might be biased toward recognizing colors rather than the digit shapes during training, thus leading to poor generalization on unseen data [264]. Such a problem can be intensified on multi-source data in DG as each source domain typically contains its own domain-specific bias. As a consequence, a DG model might simply learn to memorize the domain-specific biases, such as image styles [37], when tasked to differentiate between instances from different domains. The shortcut learning problem has been overlooked in DG.

避免学习捷径 捷径学习可以被解释为学习“简单”表征的问题，这些表征在训练数据上表现良好，但与任务无关 [263]。例如，给定区分混合了不同颜色的数字的任务，神经网络在训练过程中可能会偏向于识别颜色而不是数字形状，从而导致在未见数据上的泛化能力较差 [264]。在领域泛化(DG)的多源数据中，这个问题可能会加剧，因为每个源领域通常都包含其特定领域的偏差。因此，当要求区分来自不同领域的实例时，DG 模型可能只是简单地学习记忆特定领域的偏差，如图像风格 [37]。捷径学习问题在 DG 中一直被忽视。

Causal Representation Learning Currently, the common pipeline used in DG, as well as in many other fields, for representation learning is to learn a mapping $P\left( {Y \mid  X}\right)$ by sampling data from the marginal distribution $P\left( X\right)$ with an objective to match the joint distribution $P\left( {X, Y}\right)  =$ $P\left( {Y \mid  X}\right) P\left( X\right)$ (typically via maximum likelihood optimization). However, the learned representations have turned out to be lacking in the ability to adapt to OOD data [265]. A potential solution is to model the underlying causal variables (e.g., by autoencoder [265]) which cannot be directly observed but are much more stable and robust under distribution shift. This is closely related to the topic of causal representation learning, a recent trend in the machine learning community [266].

因果表征学习 目前，DG 以及许多其他领域中用于表征学习的常见流程是通过从边缘分布 $P\left( X\right)$ 中采样数据来学习一个映射 $P\left( {Y \mid  X}\right)$，目标是匹配联合分布 $P\left( {X, Y}\right)  =$ $P\left( {Y \mid  X}\right) P\left( X\right)$(通常通过最大似然优化)。然而，事实证明，所学习到的表征缺乏适应分布外(OOD)数据的能力 [265]。一个潜在的解决方案是对潜在的因果变量进行建模(例如，通过自编码器 [265])，这些变量无法直接观察到，但在分布变化下更加稳定和鲁棒。这与因果表征学习这一主题密切相关，因果表征学习是机器学习社区最近的一个趋势 [266]。

Exploiting Side Information Side information (sometimes called meta-data) has been commonly used to boost the performance of a pattern recognition system. For example, depth information obtained from RGB-D sensors can be used alongside RGB images to improve the performance of, e.g., generic object detection [267] or human detection [268]. In DG, there exist a few works that utilize side information, such as attribute labels [149] or object segmentation masks [269]. In terms of attributes, they could be more generalizable because they capture mid- to low-level visual cues like colors, shapes and stripes, which are shared among different objects and less sensitive to domain biases [149]. Notably, attributes have been widely used in zero-shot learning to recognize unseen classes [143], [148]. In contrast, features learned for discrimination are usually too specific to objects, such as dog ears and human faces as found in top-layer CNN features [270], which are more likely to capture domain biases and hence less transferable between tasks [139].

利用辅助信息 辅助信息(有时称为元数据)通常用于提高模式识别系统的性能。例如，从 RGB - D 传感器获得的深度信息可以与 RGB 图像一起使用，以提高例如通用目标检测 [267] 或人体检测 [268] 的性能。在 DG 中，有一些工作利用了辅助信息，如属性标签 [149] 或目标分割掩码 [269]。就属性而言，它们可能具有更强的泛化能力，因为它们捕捉到了中低级别的视觉线索，如颜色、形状和条纹，这些线索在不同目标之间是共享的，并且对领域偏差不太敏感 [149]。值得注意的是，属性已被广泛用于零样本学习中以识别未见类别 [143]、[148]。相比之下，为区分而学习的特征通常对目标过于特定，如在卷积神经网络(CNN)顶层特征中发现的狗耳朵和人脸 [270]，这些特征更有可能捕捉到领域偏差，因此在不同任务之间的可迁移性较差 [139]。

Transfer Learning A couple of recent works [141], [142] have focused on the transfer learning perspective when designing DG methods for synthetic-to-real applications. Given a model pre-trained on large real datasets like Im-ageNet [11], the main goal is to learn new knowledge that is useful to the downstream task from synthetic data, and in the meantime, to maintain the knowledge on real images that was acquired from pre-training. Such a setting is closely related to learning-without-forgetting (LwF) [271]. In particular, a technique used in [141] was borrowed from LwF [271], i.e., minimizing the divergence between the new model's output and the old model's output to avoid erasing the pre-trained knowledge. Synthetic-to-real transfer learning is a realistic and practical setting but research in this direction has been less explored for DG.

迁移学习 最近的一些工作 [141]、[142] 在为合成到真实应用设计 DG 方法时关注了迁移学习的视角。给定一个在像 ImageNet [11] 这样的大型真实数据集上预训练的模型，主要目标是从合成数据中学习对下游任务有用的新知识，同时保留从预训练中获得的关于真实图像的知识。这种设置与无遗忘学习(LwF)[271] 密切相关。特别是，[141] 中使用的一种技术借鉴自 LwF [271]，即最小化新模型输出与旧模型输出之间的差异，以避免抹去预训练的知识。合成到真实的迁移学习是一种现实且实用的设置，但在 DG 领域，这方面的研究还较少。

Semi-Supervised Domain Generalization Most existing DG research assumes data collected from each source domain are fully annotated so the proposed methods are purely based on supervised learning, which are unable to cope with unlabeled data. However, in practice the size of labeled data could well be limited due to high annotation cost, but collecting abundant unlabeled data is much easier and cheaper. This leads to a more realistic and practical setting termed semi-supervised domain generalization [28], [29], [272], [273], [274], which has recently picked up attention from the DG community. In [29], pseudo-labels are assigned to unlabeled source data and an off-the-shelf style transfer model is used to augment the domain space. In [28], feature statistics are mixed between labeled and pseudo-labeled source data for data augmentation. Since designing data-efficient, and yet generalizable learning systems is essential for practical applications, we believe semi-supervised domain generalizable is worth investigating for future work.

半监督领域泛化 大多数现有的 DG 研究假设从每个源领域收集的数据都有完整的标注，因此所提出的方法完全基于监督学习，无法处理未标注的数据。然而，在实践中，由于标注成本高，标注数据的规模可能非常有限，但收集大量未标注数据则更加容易和廉价。这导致了一种更现实和实用的设置，称为半监督领域泛化 [28]、[29]、[272]、[273]、[274]，最近受到了 DG 社区的关注。在 [29] 中，为未标注的源数据分配伪标签，并使用现成的风格迁移模型来扩充领域空间。在 [28] 中，在标注的和伪标注的源数据之间混合特征统计信息以进行数据增强。由于设计数据高效且具有泛化能力的学习系统对于实际应用至关重要，我们认为半监督领域泛化值得在未来的工作中进行研究。

Open Domain Generalization is a recently introduced problem setting [27] where a model is learned from heterogeneous source domains with different label sets (with overlaps) and deployed in unseen domains for recognizing known classes while being able to reject unknown classes. This problem setting is related to existing heterogeneous DG [35], [94] but focuses on classification applications and emphasizes the ability to detect (reject) unknown classes, which is often studied in open-set recognition [275]. In [27], a variant of Mixup [234] is proposed for data augmentation at both feature and label level, and a confidence threshold is used to reject test samples that likely belong to unknown classes.

开放域泛化(Open Domain Generalization)是最近提出的一种问题设定 [27]，在该设定中，模型从具有不同标签集(存在重叠)的异构源域中学习，并部署在未见域中，用于识别已知类别，同时能够拒绝未知类别。这种问题设定与现有的异构域泛化(heterogeneous DG)[35]、[94] 相关，但专注于分类应用，并强调检测(拒绝)未知类别的能力，这在开放集识别(open-set recognition)中经常被研究 [275]。在文献 [27] 中，提出了一种混合增强(Mixup)[234] 的变体，用于在特征和标签层面进行数据增强，并使用置信度阈值来拒绝可能属于未知类别的测试样本。

### 5.3 Benchmarks

### 5.3 基准测试

Incremental Learning + DG Most existing research on DG implicitly assumes that source domains are fixed and a model needs to be learned only once. However, in practice, it might well be the case that source domains are incrementally introduced, thus requiring incremental learning [276]. For instance, in cross-dataset person re-identification we might well have access to, say only two datasets at the beginning for model learning, e.g., Market1501 [76] and DukeMTMC-reID [77], but later another dataset comes in, e.g., CUHK03 [277], which increases the number of source datasets from two to three. In this case, several problems need to be addressed, such as i) how to efficiently fine-tune the model on the new dataset without training from scratch using all available datasets, ii) how to make sure the model does not over-fit the new dataset and forget the previously learned knowledge, and iii) will the new dataset be beneficial or detrimental to the DG performance on the target domain.

增量学习 + 域泛化 现有的大多数关于域泛化(DG)的研究都隐含地假设源域是固定的，并且模型只需要学习一次。然而，在实践中，很可能会出现源域是逐步引入的情况，因此需要进行增量学习 [276]。例如，在跨数据集行人重识别任务中，一开始我们可能只能访问两个数据集来进行模型学习，比如 Market1501 [76] 和 DukeMTMC-reID [77]，但后来又有另一个数据集加入，比如 CUHK03 [277]，这使得源数据集的数量从两个增加到了三个。在这种情况下，需要解决几个问题，例如:i) 如何在不使用所有可用数据集从头开始训练的情况下，有效地在新数据集上微调模型；ii) 如何确保模型不会过拟合新数据集并遗忘之前学到的知识；iii) 新数据集对目标域上的域泛化性能是有益还是有害。

Heterogeneous Domain Shift The current DG datasets mainly contain homogeneous domain shift, which means the source-source and source-target shifts are highly correlated with each other. For example, on PACS [37] the source-source domain shift and the source-target domain shift are both related to image style changes; on Rotated MNIST [53] rotation is the only cause of domain shift. However, in real-world scenarios the target domain shift is unpredictable and less likely to be correlated with the source domain shift, e.g., the source domains might be photo, art and sketch but the target domain might be images of novel viewpoints; or the source domains contain digit images with different rotations but the target domain images might be in a different font style or background. Such a setting, which we call heterogeneous domain shift, has never been brought up but is critical to practical applications.

异构域偏移 当前的域泛化(DG)数据集主要包含同构域偏移，这意味着源 - 源和源 - 目标偏移之间高度相关。例如，在 PACS [37] 数据集上，源 - 源域偏移和源 - 目标域偏移都与图像风格变化有关；在旋转 MNIST [53] 数据集中，旋转是域偏移的唯一原因。然而，在现实场景中，目标域偏移是不可预测的，并且不太可能与源域偏移相关。例如，源域可能是照片、艺术作品和素描，但目标域可能是具有新颖视角的图像；或者源域包含不同旋转角度的数字图像，但目标域图像可能具有不同的字体风格或背景。我们将这种设定称为异构域偏移，这种情况从未被提出过，但对实际应用至关重要。

## 6 CONCLUSION

## 6 结论

Domain generalization has been studied over a decade, with numerous methods developed in the literature across various application areas. Given the importance of domain generalization to the development of AI, it is imperative to make it clear that i) how this topic relates to neighboring fields like domain adaptation, ii) how domain generalization is typically evaluated and benchmarked, and crucially, iii) what the progress is in domain generalization. This timely and up-to-date survey answers these questions and we hope it can inspire future work to advance the field.

域泛化已经研究了十多年，文献中针对各个应用领域开发了众多方法。鉴于域泛化对人工智能发展的重要性，有必要明确以下几点:i) 该主题与领域自适应等相邻领域的关系；ii) 如何对域泛化进行典型的评估和基准测试；以及至关重要的是，iii) 域泛化取得了哪些进展。这份及时且最新的综述回答了这些问题，我们希望它能激发未来的工作，推动该领域的发展。

Acknowledgements This work is supported by NTU NAP, MOE AcRF Tier 2 (T2EP20221-0033), and under the RIE2020 Industry Alignment Fund - Industry Collaboration Projects (IAF-ICP) Funding Initiative, as well as cash and in-kind contribution from the industry partner(s). This work is also supported by National Natural Science Foundation of China (61876176, U1713208); the National Key Research and Development Program of China (No. 2020YFC2004800); Science and Technology Service Network Initiative of Chinese Academy of Sciences (KFJ-STS-QYZX-092); the Shanghai Committee of Science and Technology, China (Grant No. 20DZ1100800).

致谢 本工作得到了南洋理工大学(NTU)学术休假计划(NAP)、新加坡教育部学术研究基金二级项目(MOE AcRF Tier 2，T2EP20221 - 0033)的支持，以及在 2020 年研究、创新与企业计划(RIE2020)行业对接基金 - 行业合作项目(IAF - ICP)资助倡议下的支持，同时还得到了行业合作伙伴的现金和实物捐赠。本工作还得到了中国国家自然科学基金(61876176，U1713208)、中国国家重点研发计划(No. 2020YFC2004800)、中国科学院科技服务网络计划(KFJ - STS - QYZX - 092)、中国上海市科学技术委员会(Grant No. 20DZ1100800)的支持。

## REFERENCES

## 参考文献

[1] J. G. Moreno-Torres, T. Raeder, R. Alaiz-Rodríguez, N. V. Chawla, and F. Herrera, "A unifying view on dataset shift in classification," PR, 2012.

[1] J. G. Moreno - Torres、T. Raeder、R. Alaiz - Rodríguez、N. V. Chawla 和 F. Herrera，“分类中数据集偏移的统一观点”，《模式识别》(PR)，2012 年。

[2] B. Recht, R. Roelofs, L. Schmidt, and V. Shankar, "Do imagenet classifiers generalize to imagenet?" in ICML, 2019.

[2] B. Recht、R. Roelofs、L. Schmidt 和 V. Shankar，“ImageNet 分类器能否泛化到 ImageNet？”，发表于 2019 年国际机器学习会议(ICML)。

[3] S. Ben-David, J. Blitzer, K. Crammer, A. Kulesza, F. Pereira, and J. W. Vaughan, "A theory of learning from different domains," ${ML},{2010}$ .

[3] S. Ben - David、J. Blitzer、K. Crammer、A. Kulesza、F. Pereira 和 J. W. Vaughan，“不同领域学习的理论”，${ML},{2010}$。

[4] R. Taori, A. Dave, V. Shankar, N. Carlini, B. Recht, and L. Schmidt, "Measuring robustness to natural distribution shifts in image classification," in NeurIPS, 2020.

[4] R. Taori、A. Dave、V. Shankar、N. Carlini、B. Recht 和 L. Schmidt，“衡量图像分类中对自然分布偏移的鲁棒性”，发表于 2020 年神经信息处理系统大会(NeurIPS)。

[5] G. Blanchard, A. A. Deshmukh, U. Dogan, G. Lee, and C. Scott, "Domain generalization by marginal transfer learning," JMLR, 2021.

[5] G. 布兰查德(G. Blanchard)、A. A. 德什穆克(A. A. Deshmukh)、U. 多根(U. Dogan)、G. 李(G. Lee)和 C. 斯科特(C. Scott)，《通过边缘迁移学习实现领域泛化》，《机器学习研究杂志》(JMLR)，2021 年。

[6] K. He, X. Zhang, S. Ren, and J. Sun, "Deep residual learning for image recognition," in CVPR, 2016.

[6] 何恺明(K. He)、张祥雨(X. Zhang)、任少卿(S. Ren)和孙剑(J. Sun)，《用于图像识别的深度残差学习》，发表于 2016 年的计算机视觉与模式识别会议(CVPR)。

[7] A. Krizhevsky, I. Sutskever, and G. E. Hinton, "Imagenet classification with deep convolutional neural networks," in NeurIPS, 2012.

[7] A. 克里兹维茨基(A. Krizhevsky)、I. 苏斯克维(I. Sutskever)和 G. E. 辛顿(G. E. Hinton)，《使用深度卷积神经网络进行 ImageNet 图像分类》，发表于 2012 年的神经信息处理系统大会(NeurIPS)。

[8] Y. LeCun, Y. Bengio, and G. Hinton, "Deep learning," Nature, 2015.

[8] Y. 勒昆(Y. LeCun)、Y. 本吉奥(Y. Bengio)和 G. 辛顿(G. Hinton)，《深度学习》，《自然》(Nature)杂志，2015 年。

[9] D. Hendrycks and T. Dietterich, "Benchmarking neural network robustness to common corruptions and perturbations," in ICLR, 2019.

[9] D. 亨德里克斯(D. Hendrycks)和 T. 迪特里希(T. Dietterich)，《对常见损坏和扰动的神经网络鲁棒性进行基准测试》，发表于 2019 年的国际学习表征会议(ICLR)。

[10] J. Yang, K. Zhou, Y. Li, and Z. Liu, "Generalized out-of-distribution detection: A survey," arXiv preprint arXiv:2110.11334, 2021.

[10] 杨(Yang)、周(Zhou)、李(Li)和刘(Liu)，“广义分布外检测:综述”，预印本 arXiv:2110.11334，2021年。

[11] J. Deng, W. Dong, R. Socher, L.-J. Li, K. Li, and L. Fei-Fei, "Imagenet: A large-scale hierarchical image database," in CVPR, 2009.

[11] 邓(Deng)、董(Dong)、索切尔(Socher)、李(Li)、李(Li)和李菲菲(Fei-Fei)，“ImageNet:大规模分层图像数据库”，发表于2009年的计算机视觉与模式识别会议(CVPR)。

[12] K. Saenko, B. Kulis, M. Fritz, and T. Darrell, "Adapting visual category models to new domains," in ECCV, 2010.

[12] 塞恩科(Saenko)、库利斯(Kulis)、弗里茨(Fritz)和达雷尔(Darrell)，“将视觉类别模型适配到新领域”，发表于2010年的欧洲计算机视觉会议(ECCV)。

[13] Z. Lu, Y. Yang, X. Zhu, C. Liu, Y.-Z. Song, and T. Xiang, "Stochastic classifiers for unsupervised domain adaptation," in CVPR, 2020.

[13] 卢(Lu)、杨(Yang)、朱(Zhu)、刘(Liu)、宋(Song)和向(Xiang)，“用于无监督领域自适应的随机分类器”，发表于2020年的计算机视觉与模式识别会议(CVPR)。

[14] K. Saito, K. Watanabe, Y. Ushiku, and T. Harada, "Maximum classifier discrepancy for unsupervised domain adaptation," in CVPR, 2018.

[14] 斋藤(Saito)、渡边(Watanabe)、牛久(Ushiku)和原田(Harada)，“无监督领域自适应的最大分类器差异”，发表于2018年的计算机视觉与模式识别会议(CVPR)。

[15] Y. Ganin and V. S. Lempitsky, "Unsupervised domain adaptation by backpropagation," in ICML, 2015.

[15] 加宁(Ganin)和伦皮茨基(Lempitsky)，“通过反向传播进行无监督领域自适应”，发表于2015年的国际机器学习会议(ICML)。

[16] M. Long, Y. Cao, J. Wang, and M. I. Jordan, "Learning transferable features with deep adaptation networks," in ICML, 2015.

[16] 龙(Long)、曹(Cao)、王(Wang)和乔丹(Jordan)，“使用深度自适应网络学习可迁移特征”，发表于2015年的国际机器学习会议(ICML)。

[17] Z. Liu, Z. Miao, X. Pan, X. Zhan, D. Lin, S. X. Yu, and B. Gong, "Open compound domain adaptation," in CVPR, 2020.

[17] 刘(Liu)、苗(Miao)、潘(Pan)、詹(Zhan)、林(Lin)、余(Yu)和龚(Gong)，“开放复合领域自适应”，发表于2020年的计算机视觉与模式识别会议(CVPR)。

[18] B. Li, Y. Wang, S. Zhang, D. Li, T. Darrell, K. Keutzer, and H. Zhao, "Learning invariant representations and risks for semi-supervised domain adaptation," in CVPR, 2021.

[18] 李(Li)、王(Wang)、张(Zhang)、李(Li)、达雷尔(Darrell)、科伊策(Keutzer)和赵(Zhao)，“半监督领域自适应的学习不变表示和风险”，发表于2021年的计算机视觉与模式识别会议(CVPR)。

[19] K. Muandet, D. Balduzzi, and B. Scholkopf, "Domain generalization via invariant feature representation," in ICML, 2013.

[19] 穆安代特(Muandet)、巴尔杜齐(Balduzzi)和肖尔科普夫(Scholkopf)，“通过不变特征表示进行领域泛化”，发表于2013年的国际机器学习会议(ICML)。

[20] X. Yue, Y. Zhang, S. Zhao, A. Sangiovanni-Vincentelli, K. Keutzer, and B. Gong, "Domain randomization and pyramid consistency: Simulation-to-real generalization without accessing target domain data," in ICCV, 2019.

[20] 岳(Yue)、张(Zhang)、赵(Zhao)、桑乔万尼 - 文森泰利(Sangiovanni-Vincentelli)、科伊策(Keutzer)和龚(Gong)，“领域随机化和金字塔一致性:无需访问目标领域数据的模拟到真实泛化”，发表于2019年的国际计算机视觉会议(ICCV)。

[21] R. Volpi, D. Larlus, and G. Rogez, "Continual adaptation of visual representations via domain randomization and meta-learning," in CVPR, 2021.

[21] 沃尔皮(Volpi)、拉尔卢斯(Larlus)和罗热(Rogez)，“通过领域随机化和元学习对视觉表示进行持续自适应”，发表于2021年的计算机视觉与模式识别会议(CVPR)。

[22] G. Blanchard, G. Lee, and C. Scott, "Generalizing from several related classification tasks to a new unlabeled sample," in NeurIPS, 2011.

[22] 布兰查德(Blanchard)、李(Lee)和斯科特(Scott)，“从多个相关分类任务泛化到新的未标记样本”，发表于2011年的神经信息处理系统大会(NeurIPS)。

[23] K. Zhou, Y. Yang, Y. Qiao, and T. Xiang, "Domain generalization with mixstyle," in ICLR, 2021.

[23] 周(Zhou)、杨(Yang)、乔(Qiao)和向(Xiang)，“使用MixStyle进行领域泛化”，发表于2021年的国际学习表征会议(ICLR)。

[24] X. Fan, Q. Wang, J. Ke, F. Yang, B. Gong, and M. Zhou, "Adversar-

[24] 范(Fan)、王(Wang)、柯(Ke)、杨(Yang)、龚(Gong)和周(Zhou)，“对抗性

ially adaptive normalization for single domain generalization," in ${CVPR},{2021}$ .

自适应归一化用于单领域泛化”，发表于 ${CVPR},{2021}$ 。

[25] X. Zhang, P. Cui, R. Xu, L. Zhou, Y. He, and Z. Shen, "Deep stable learning for out-of-distribution generalization," in CVPR, 2021.

[25] 张X(X. Zhang)、崔P(P. Cui)、徐R(R. Xu)、周L(L. Zhou)、何Y(Y. He)和沈Z(Z. Shen)，“用于分布外泛化的深度稳定学习”，发表于2021年的计算机视觉与模式识别会议(CVPR)。

[26] P. Pandey, M. Raman, S. Varambally, and P. AP, "Domain generalization via inference-time label-preserving target projections," in CVPR, 2021.

[26] 潘迪P(P. Pandey)、拉曼M(M. Raman)、瓦兰巴利S(S. Varambally)和AP P(P. AP)，“通过推理时保留标签的目标投影实现领域泛化”，发表于2021年的计算机视觉与模式识别会议(CVPR)。

[27] Y. Shu, Z. Cao, C. Wang, J. Wang, and M. Long, "Open domain generalization with domain-augmented meta-learning," in CVPR, 2021.

[27] 舒Y(Y. Shu)、曹Z(Z. Cao)、王C(C. Wang)、王J(J. Wang)和龙M(M. Long)，“基于领域增强元学习的开放领域泛化”，发表于2021年的计算机视觉与模式识别会议(CVPR)。

[28] K. Zhou, Y. Yang, Y. Qiao, and T. Xiang, "Mixstyle neural networks for domain generalization and adaptation," arXiv:2107.02053, 2021.

[28] 周K(K. Zhou)、杨Y(Y. Yang)、乔Y(Y. Qiao)和向T(T. Xiang)，“用于领域泛化和适应的混合风格神经网络”，预印本arXiv:2107.02053，2021年。

[29] K. Zhou, C. C. Loy, and Z. Liu, "Semi-supervised domain generalization with stochastic stylematch," arXiv preprint arXiv:2106.00592, 2021.

[29] 周K(K. Zhou)、洛伊C. C.(C. C. Loy)和刘Z(Z. Liu)，“基于随机风格匹配的半监督领域泛化”，预印本arXiv:2106.00592，2021年。

[30] J. Cha, S. Chun, K. Lee, H.-C. Cho, S. Park, Y. Lee, and S. Park, "Swad: Domain generalization by seeking flat minima," NeurIPS, 2021.

[30] 查J(J. Cha)、春S(S. Chun)、李K(K. Lee)、赵H.-C.(H.-C. Cho)、朴S(S. Park)、李Y(Y. Lee)和朴S(S. Park)，“Swad:通过寻找平坦极小值实现领域泛化”，发表于2021年的神经信息处理系统大会(NeurIPS)。

[31] H. Li, S. Jialin Pan, S. Wang, and A. C. Kot, "Domain generalization with adversarial feature learning," in CVPR, 2018.

[31] 李H(H. Li)、潘S. Jialin(S. Jialin Pan)、王S(S. Wang)和科特A. C.(A. C. Kot)，“基于对抗特征学习的领域泛化”，发表于2018年的计算机视觉与模式识别会议(CVPR)。

[32] Y. Li, X. Tiana, M. Gong, Y. Liu, T. Liu, K. Zhang, and D. Tao, "Deep domain generalization via conditional invariant adversarial networks," in ECCV, 2018.

[32] 李Y(Y. Li)、蒂安娜X(X. Tiana)、龚M(M. Gong)、刘Y(Y. Liu)、刘T(T. Liu)、张K(K. Zhang)和陶D(D. Tao)，“通过条件不变对抗网络实现深度领域泛化”，发表于2018年的欧洲计算机视觉会议(ECCV)。

[33] D. Li, Y. Yang, Y.-Z. Song, and T. M. Hospedales, "Learning to generalize: Meta-learning for domain generalization," in AAAI, 2018.

[33] 李D(D. Li)、杨Y(Y. Yang)、宋Y.-Z.(Y.-Z. Song)和霍斯佩代尔斯T. M.(T. M. Hospedales)，“学习泛化:用于领域泛化的元学习”，发表于2018年的美国人工智能协会会议(AAAI)。

[34] Y. Balaji, S. Sankaranarayanan, and R. Chellappa, "Metareg: Towards domain generalization using meta-regularization," in NeurIPS, 2018.

[34] 巴拉吉Y(Y. Balaji)、桑卡兰纳拉亚南S(S. Sankaranarayanan)和切拉帕R(R. Chellappa)，“元正则化:使用元正则化实现领域泛化”，发表于2018年的神经信息处理系统大会(NeurIPS)。

[35] K. Zhou, Y. Yang, T. Hospedales, and T. Xiang, "Learning to generate novel domains for domain generalization," in ECCV, 2020.

[35] 周K(K. Zhou)、杨Y(Y. Yang)、霍斯佩代尔斯T.(T. Hospedales)和向T(T. Xiang)，“学习为领域泛化生成新领域”，发表于2020年的欧洲计算机视觉会议(ECCV)。

[36] K. Zhou, Y. Yang, T. M. Hospedales, and T. Xiang, "Deep domain-adversarial image generation for domain generalisation." in ${AAAI},{2020}$ .

[36] 周K(K. Zhou)、杨Y(Y. Yang)、霍斯佩代尔斯T. M.(T. M. Hospedales)和向T(T. Xiang)，“用于领域泛化的深度领域对抗图像生成”，发表于${AAAI},{2020}$ 。

[37] D. Li, Y. Yang, Y.-Z. Song, and T. M. Hospedales, "Deeper, broader and artier domain generalization," in ICCV, 2017.

[37] 李D(D. Li)、杨Y(Y. Yang)、宋Y.-Z.(Y.-Z. Song)和霍斯佩代尔斯T. M.(T. M. Hospedales)，“更深、更广、更具艺术性的领域泛化”，发表于2017年的国际计算机视觉会议(ICCV)。

[38] Y. Li, Y. Yang, W. Zhou, and T. Hospedales, "Feature-critic networks for heterogeneous domain generalization," in ICML, 2019.

[38] 李Y(Y. Li)、杨Y(Y. Yang)、周W(W. Zhou)和霍斯佩代尔斯T.(T. Hospedales)，“用于异构领域泛化的特征评判网络”，发表于2019年的国际机器学习会议(ICML)。

[39] R. Volpi and V. Murino, "Addressing model vulnerability to distributional shifts over image transformation sets," in ICCV, 2019.

[39] 沃尔皮R(R. Volpi)和穆里诺V(V. Murino)，“解决模型在图像变换集上对分布偏移的脆弱性问题”，发表于2019年的国际计算机视觉会议(ICCV)。

[40] S. Shankar, V. Piratla, S. Chakrabarti, S. Chaudhuri, P. Jyothi, and S. Sarawagi, "Generalizing across domains via cross-gradient training," in ICLR, 2018.

[40] 尚卡尔S(S. Shankar)、皮拉特V(V. Piratla)、查克拉巴蒂S(S. Chakrabarti)、乔杜里S(S. Chaudhuri)、乔蒂P(P. Jyothi)和萨拉瓦吉S(S. Sarawagi)，“通过交叉梯度训练实现跨领域泛化”，发表于2018年的国际学习表征会议(ICLR)。

[41] Q. Liu, Q. Dou, L. Yu, and P. A. Heng, "Ms-net: Multi-site network for improving prostate segmentation with heterogeneous mri data," TMI, 2020.

[41] 刘奇(Q. Liu)、窦强(Q. Dou)、于磊(L. Yu)和彭安迪(P. A. Heng)，“Ms-net:用于利用异构磁共振成像(MRI)数据改进前列腺分割的多站点网络”，《医学成像汇刊》(TMI)，2020年。

[42] Q. Liu, Q. Dou, and P.-A. Heng, "Shape-aware meta-learning for generalizing prostate mri segmentation to unseen domains," in MICCAI, 2020.

[42] 刘奇(Q. Liu)、窦强(Q. Dou)和彭安迪(P.-A. Heng)，“用于将前列腺MRI分割推广到未见领域的形状感知元学习”，发表于《医学图像计算与计算机辅助干预国际会议》(MICCAI)，2020年。

[43] A. Torralba and A. A. Efros, "Unbiased look at dataset bias," in CVPR, 2011.

[43] 亚历克斯·托拉尔巴(A. Torralba)和亚历山大·A·埃弗罗斯(A. A. Efros)，“对数据集偏差的公正审视”，发表于《计算机视觉与模式识别会议》(CVPR)，2011年。

[44] L. Fei-Fei, R. Fergus, and P. Perona, "Learning generative visual models from few training examples: An incremental bayesian approach tested on 101 object categories," in CVPR-W, 2004.

[44] 李菲菲(L. Fei-Fei)、罗伯·费格斯(R. Fergus)和皮埃特罗·佩罗纳(P. Perona)，“从少量训练示例中学习生成式视觉模型:在101个目标类别上测试的增量贝叶斯方法”，发表于《计算机视觉与模式识别研讨会》(CVPR - W)，2004年。

[45] B. C. Russell, A. Torralba, K. P. Murphy, and W. T. Freeman, "Labelme: a database and web-based tool for image annotation," IJCV, 2008.

[45] 布莱恩·C·拉塞尔(B. C. Russell)、亚历克斯·托拉尔巴(A. Torralba)、凯文·P·墨菲(K. P. Murphy)和威廉·T·弗里曼(W. T. Freeman)，“Labelme:一个用于图像标注的数据库和基于网络的工具”，《国际计算机视觉杂志》(IJCV)，2008年。

[46] A. Khosla, T. Zhou, T. Malisiewicz, A. Efros, and A. Torralba, "Undoing the damage of dataset bias," in ECCV, 2012.

[46] 阿迪亚·科斯拉(A. Khosla)、周涛(T. Zhou)、托马斯·马利塞维奇(T. Malisiewicz)、亚历山大·埃弗罗斯(A. Efros)和亚历克斯·托拉尔巴(A. Torralba)，“消除数据集偏差的影响”，发表于《欧洲计算机视觉会议》(ECCV)，2012年。

[47] D. Hendrycks, N. Mu, E. D. Cubuk, B. Zoph, J. Gilmer, and B. Lakshminarayanan, "Augmix: A simple data processing method to improve robustness and uncertainty," in ICLR, 2020.

[47] 丹·亨德里克斯(D. Hendrycks)、倪墨(N. Mu)、伊恩·J·古布克(E. D. Cubuk)、巴雷特·佐夫(B. Zoph)、贾斯汀·吉尔默(J. Gilmer)和巴拉吉·拉克什米纳拉亚南(B. Lakshminarayanan)，“Augmix:一种提高鲁棒性和不确定性的简单数据处理方法”，发表于《国际学习表征会议》(ICLR)，2020年。

[48] Z. Tang, Y. Gao, Y. Zhu, Z. Zhang, M. Li, and D. Metaxas, "Selfnorm and crossnorm for out-of-distribution robustness," arXiv preprint arXiv:2102.02811, 2021.

[48] 唐志远(Z. Tang)、高宇(Y. Gao)、朱宇(Y. Zhu)、张泽(Z. Zhang)、李明(M. Li)和迪米特里斯·N·梅塔克萨斯(D. Metaxas)，“用于分布外鲁棒性的自归一化和交叉归一化”，预印本arXiv:2102.02811，2021年。

[49] F. M. Carlucci, A. D'Innocente, S. Bucci, B. Caputo, and T. Tom-masi, "Domain generalization by solving jigsaw puzzles," in CVPR, 2019.

[49] 法比奥·M·卡尔卢奇(F. M. Carlucci)、安东尼奥·迪诺森特(A. D'Innocente)、斯特凡诺·布奇(S. Bucci)、芭芭拉·卡普托(B. Caputo)和托马索·托马西(T. Tom - masi)，“通过解决拼图难题实现领域泛化”，发表于《计算机视觉与模式识别会议》(CVPR)，2019年。

[50] S. Bucci, A. D'Innocente, Y. Liao, F. M. Carlucci, B. Caputo, and T. Tommasi, "Self-supervised learning across domains," arXiv preprint arXiv:2007.12368, 2020.

[50] 斯特凡诺·布奇(S. Bucci)、安东尼奥·迪诺森特(A. D'Innocente)、廖宇(Y. Liao)、法比奥·M·卡尔卢奇(F. M. Carlucci)、芭芭拉·卡普托(B. Caputo)和托马索·托马西(T. Tommasi)，“跨领域的自监督学习”，预印本arXiv:2007.12368，2020年。

[51] H. Wang, Z. He, Z. C. Lipton, and E. P. Xing, "Learning robust representations by projecting superficial statistics out," in ICLR,

[51] 王浩(H. Wang)、何泽(Z. He)、扎卡里·C·利普顿(Z. C. Lipton)和邢波(E. P. Xing)，“通过排除表面统计信息学习鲁棒表示”，发表于《国际学习表征会议》(ICLR)

2019.

[52] Z. Huang, H. Wang, E. P. Xing, and D. Huang, "Self-challenging improves cross-domain generalization," in ECCV, 2020.

[52] 黄震(Z. Huang)、王浩(H. Wang)、邢波(E. P. Xing)和黄迪(D. Huang)，“自我挑战提高跨领域泛化能力”，发表于《欧洲计算机视觉会议》(ECCV)，2020年。

[53] M. Ghifary, W. B. Kleijn, M. Zhang, and D. Balduzzi, "Domain generalization for object recognition with multi-task autoen-coders," in ICCV, 2015.

[53] 穆罕默德·吉法里(M. Ghifary)、威廉·B·克莱因(W. B. Kleijn)、张铭(M. Zhang)和达维德·巴尔杜齐(D. Balduzzi)，“使用多任务自动编码器进行目标识别的领域泛化”，发表于《国际计算机视觉会议》(ICCV)，2015年。

[54] Y. LeCun, L. Bottou, Y. Bengio, and P. Haffner, "Gradient-based learning applied to document recognition," in IEEE, 1998.

[54] 杨立昆(Y. LeCun)、莱昂·博托(L. Bottou)、约书亚·本吉奥(Y. Bengio)和帕特里克·哈弗纳(P. Haffner)，“基于梯度的学习在文档识别中的应用”，发表于《电气与电子工程师协会汇刊》(IEEE)，1998年。

[55] Y. Netzer, T. Wang, A. Coates, A. Bissacco, B. Wu, and A. Y. $\mathrm{{Ng}}$ ,"Reading digits in natural images with unsupervised feature learning," in NeurIPS-W, 2011.

[55] 亚尼夫·内策尔(Y. Netzer)、王涛(T. Wang)、亚当·科茨(A. Coates)、安德烈亚·比萨科(A. Bissacco)、吴波(B. Wu)和吴恩达(A. Y. $\mathrm{{Ng}}$ )，“通过无监督特征学习识别自然图像中的数字”，发表于《神经信息处理系统研讨会》(NeurIPS - W)，2011年。

[56] C. Fang, Y. Xu, and D. N. Rockmore, "Unbiased metric learning: On the utilization of multiple datasets and web images for softening bias," in ICCV, 2013.

[56] 方超(C. Fang)、徐阳(Y. Xu)和丹尼尔·N·洛克莫尔(D. N. Rockmore)，“无偏度量学习:利用多个数据集和网络图像减轻偏差”，发表于《国际计算机视觉会议》(ICCV)，2013年。

[57] M. Everingham, L. Van Gool, C. K. Williams, J. Winn, and A. Zisserman, "The pascal visual object classes (voc) challenge," IJCV, 2010.

[57] M. 埃弗林厄姆(M. Everingham)、L. 范古尔(L. Van Gool)、C. K. 威廉姆斯(C. K. Williams)、J. 温(J. Winn)和 A. 齐斯曼(A. Zisserman)，《Pascal视觉对象类(Pascal Visual Object Classes，VOC)挑战赛》，《国际计算机视觉杂志》(IJCV)，2010年。

[58] J. Xiao, J. Hays, K. A. Ehinger, A. Oliva, and A. Torralba, "Sun database: Large-scale scene recognition from abbey to zoo," in CVPR, 2010.

[58] J. 肖(J. Xiao)、J. 海斯(J. Hays)、K. A. 埃辛格(K. A. Ehinger)、A. 奥利瓦(A. Oliva)和 A. 托拉尔巴(A. Torralba)，《SUN数据库:从修道院到动物园的大规模场景识别》，发表于2010年的计算机视觉与模式识别会议(CVPR)。

[59] H. Venkateswara, J. Eusebio, S. Chakraborty, and S. Pan-chanathan, "Deep hashing network for unsupervised domain adaptation," in CVPR, 2017.

[59] H. 文卡特斯瓦拉(H. Venkateswara)、J. 尤塞比奥(J. Eusebio)、S. 查克拉博蒂(S. Chakraborty)和 S. 潘查纳坦(S. Pan-chanathan)，《用于无监督域适应的深度哈希网络》，发表于2017年的计算机视觉与模式识别会议(CVPR)。

[60] X. Peng, Q. Bai, X. Xia, Z. Huang, K. Saenko, and B. Wang, "Moment matching for multi-source domain adaptation," in ICCV, 2019.

[60] 彭翔(X. Peng)、白强(Q. Bai)、夏鑫(X. Xia)、黄震(Z. Huang)、K. 塞内科(K. Saenko)和王博(B. Wang)，《多源域适应的矩匹配方法》，发表于2019年的国际计算机视觉会议(ICCV)。

[61] K. Zhou, Y. Yang, Y. Qiao, and T. Xiang, "Domain adaptive ensemble learning," arXiv preprint arXiv:2003.07325, 2020.

[61] 周恺(K. Zhou)、杨毅(Y. Yang)、乔宇(Y. Qiao)和向涛(T. Xiang)，《域自适应集成学习》，预印本arXiv:2003.07325，2020年。

[62] X. Peng, B. Usman, N. Kaushik, J. Hoffman, D. Wang, and K. Saenko, "Visda: The visual domain adaptation challenge," arXiv preprint arXiv:1710.06924, 2017.

[62] 彭翔(X. Peng)、B. 乌斯曼(B. Usman)、N. 考希克(N. Kaushik)、J. 霍夫曼(J. Hoffman)、王迪(D. Wang)和 K. 塞内科(K. Saenko)，《Visda:视觉域适应挑战赛》，预印本arXiv:1710.06924，2017年。

[63] D. Hendrycks, S. Basart, N. Mu, S. Kadavath, F. Wang, E. Dorundo, R. Desai, T. Zhu, S. Parajuli, M. Guo et al., "The many faces of robustness: A critical analysis of out-of-distribution generalization," in ICCV, 2021.

[63] D. 亨德里克斯(D. Hendrycks)、S. 巴萨特(S. Basart)、N. 穆(N. Mu)、S. 卡达瓦思(S. Kadavath)、王峰(F. Wang)、E. 多伦多(E. Dorundo)、R. 德赛(R. Desai)、T. 朱(T. Zhu)、S. 帕拉朱利(S. Parajuli)、郭明(M. Guo)等人，《鲁棒性的多面性:对分布外泛化的批判性分析》，发表于2021年的国际计算机视觉会议(ICCV)。

[64] D. Hendrycks, K. Zhao, S. Basart, J. Steinhardt, and D. Song, "Natural adversarial examples," in CVPR, 2021.

[64] D. 亨德里克斯(D. Hendrycks)、赵凯(K. Zhao)、S. 巴萨特(S. Basart)、J. 斯坦哈特(J. Steinhardt)和 D. 宋(D. Song)，《自然对抗样本》，发表于2021年的计算机视觉与模式识别会议(CVPR)。

[65] S. Beery, G. Van Horn, and P. Perona, "Recognition in terra incognita," in ECCV, 2018.

[65] S. 比里(S. Beery)、G. 范霍恩(G. Van Horn)和 P. 佩罗纳(P. Perona)，《未知领域的识别》，发表于2018年的欧洲计算机视觉会议(ECCV)。

[66] X. Zhang, L. Zhou, R. Xu, P. Cui, Z. Shen, and H. Liu, "Nico++: Towards better benchmarking for domain generalization," arXiv preprint arXiv:2204.08040, 2022.

[66] 张翔(X. Zhang)、周亮(L. Zhou)、徐锐(R. Xu)、崔鹏(P. Cui)、沈泽(Z. Shen)和刘浩(H. Liu)，《Nico++:迈向更好的域泛化基准》，预印本arXiv:2204.08040，2022年。

[67] S.-A. Rebuffi, H. Bilen, and A. Vedaldi, "Learning multiple visual domains with residual adapters," in NeurIPS, 2017.

[67] S.-A. 雷比菲(S.-A. Rebuffi)、H. 比伦(H. Bilen)和 A. 韦尔迪耶(A. Vedaldi)，《使用残差适配器学习多个视觉域》，发表于2017年的神经信息处理系统大会(NeurIPS)。

[68] D. Weinland, R. Ronfard, and E. Boyer, "Free viewpoint action recognition using motion history volumes," CVIU, 2006.

[68] D. 温兰德(D. Weinland)、R. 龙法尔(R. Ronfard)和 E. 博耶(E. Boyer)，《使用运动历史体进行自由视角动作识别》，《计算机视觉与图像理解》(CVIU)，2006年。

[69] K. Soomro, A. R. Zamir, and M. Shah, "Ucf101: A dataset of 101 human actions classes from videos in the wild," arXiv preprint arXiv:1212.0402, 2012.

[69] K. 苏姆罗(K. Soomro)、A. R. 扎米尔(A. R. Zamir)和 M. 沙阿(M. Shah)，《Ucf101:一个包含101个人类动作类别的野外视频数据集》，预印本arXiv:1212.0402，2012年。

[70] H. Kuehne, H. Jhuang, E. Garrote, T. Poggio, and T. Serre, "Hmdb: a large video database for human motion recognition," in ICCV, 2011.

[70] H. 库恩(H. Kuehne)、H. 黄(H. Jhuang)、E. 加罗特(E. Garrote)、T. 波吉奥(T. Poggio)和 T. 塞尔(T. Serre)，《HMDB:一个用于人类动作识别的大型视频数据库》，发表于2011年的国际计算机视觉会议(ICCV)。

[71] Z. Yao, Y. Wang, X. Du, M. Long, and J. Wang, "Adversarial pyramid network for video domain generalization," arXiv preprint arXiv:1912.03716, 2019.

[71] 姚智(Z. Yao)、王宇(Y. Wang)、杜鑫(X. Du)、龙明盛(M. Long)和王军(J. Wang)，《用于视频域泛化的对抗金字塔网络》，预印本arXiv:1912.03716，2019年。

[72] G. Ros, L. Sellart, J. Materzynska, D. Vazquez, and A. M. Lopez, "The synthia dataset: A large collection of synthetic images for semantic segmentation of urban scenes," in CVPR, 2016.

[72] G. 罗斯(G. Ros)、L. 塞拉特(L. Sellart)、J. 马泰津斯卡(J. Materzynska)、D. 巴斯克斯(D. Vazquez)和 A. M. 洛佩斯(A. M. Lopez)，《Synthia数据集:一个用于城市场景语义分割的大型合成图像集合》，发表于2016年的计算机视觉与模式识别会议(CVPR)。

[73] R. Volpi, H. Namkoong, O. Sener, J. Duchi, V. Murino, and S. Savarese, "Generalizing to unseen domains via adversarial data augmentation," in NeurIPS, 2018.

[73] R. 沃尔皮(R. Volpi)、H. 南孔(H. Namkoong)、O. 森纳(O. Sener)、J. 杜奇(J. Duchi)、V. 穆里诺(V. Murino)和 S. 萨瓦雷塞(S. Savarese)，《通过对抗性数据增强泛化到未见领域》，发表于神经信息处理系统大会(NeurIPS)，2018 年。

[74] S. R. Richter, V. Vineet, S. Roth, and V. Koltun, "Playing for data: Ground truth from computer games," in ECCV, 2016.

[74] S. R. 里希特(S. R. Richter)、V. 维尼特(V. Vineet)、S. 罗斯(S. Roth)和 V. 科尔图恩(V. Koltun)，《为数据而玩:来自电脑游戏的真实数据》，发表于欧洲计算机视觉大会(ECCV)，2016 年。

[75] M. Cordts, M. Omran, S. Ramos, T. Rehfeld, M. Enzweiler, R. Benenson, U. Franke, S. Roth, and B. Schiele, "The cityscapes dataset for semantic urban scene understanding," in CVPR, 2016.

[75] M. 科尔特斯(M. Cordts)、M. 奥姆兰(M. Omran)、S. 拉莫斯(S. Ramos)、T. 雷菲尔德(T. Rehfeld)、M. 恩茨韦勒(M. Enzweiler)、R. 贝嫩森(R. Benenson)、U. 弗兰克(U. Franke)、S. 罗斯(S. Roth)和 B. 席勒(B. Schiele)，《用于语义城市场景理解的城市景观数据集》，发表于计算机视觉与模式识别会议(CVPR)，2016 年。

[76] L. Zheng, L. Shen, L. Tian, S. Wang, J. Wang, and Q. Tian, "Scalable person re-identification: A benchmark," in ICCV, 2015.

[76] 郑磊(L. Zheng)、沈立(L. Shen)、田力(L. Tian)、王硕(S. Wang)、王军(J. Wang)和田奇(Q. Tian)，《可扩展的行人重识别:一个基准》，发表于国际计算机视觉大会(ICCV)，2015 年。

[77] E. Ristani, F. Solera, R. Zou, R. Cucchiara, and C. Tomasi, "Performance measures and a data set for multi-target, multi-camera tracking," in ECCV, 2016.

[77] E. 里斯塔尼(E. Ristani)、F. 索莱拉(F. Solera)、邹锐(R. Zou)、R. 库奇亚拉(R. Cucchiara)和 C. 托马西(C. Tomasi)，《多目标、多摄像头跟踪的性能指标和数据集》，发表于欧洲计算机视觉大会(ECCV)，2016 年。

[78] Y. Shi, X. Yu, K. Sohn, M. Chandraker, and A. K. Jain, "Towards universal representation learning for deep face recognition," in CVPR, 2020.

[78] 施扬(Y. Shi)、于翔(X. Yu)、K. 孙(K. Sohn)、M. 钱德拉克尔(M. Chandraker)和 A. K. 贾因(A. K. Jain)，《迈向深度人脸识别的通用表示学习》，发表于计算机视觉与模式识别会议(CVPR)，2020 年。

[79] Z. Zhang, J. Yan, S. Liu, Z. Lei, D. Yi, and S. Z. Li, "A face antispoofing database with diverse attacks," in ICB, 2012.

[79] 张智(Z. Zhang)、闫杰(J. Yan)、刘帅(S. Liu)、雷政(Z. Lei)、易东(D. Yi)和李圣泽(S. Z. Li)，《一个具有多样化攻击的人脸反欺骗数据库》，发表于国际人脸检测与识别会议(ICB)，2012 年。

[80] Z. Boulkenafet, J. Komulainen, L. Li, X. Feng, and A. Hadid,

[80] Z. 布尔克纳费特(Z. Boulkenafet)、J. 科穆拉宁(J. Komulainen)、李磊(L. Li)、冯鑫(X. Feng)和 A. 哈迪德(A. Hadid)

"Oulu-npu: A mobile face presentation attack database with real-world variations," in FG, 2017.

《奥卢 - 北卡罗来纳大学(Oulu - NPU):一个具有真实世界变化的移动人脸呈现攻击数据库》，发表于人脸与手势识别会议(FG)，2017 年。

[81] D. Wen, H. Han, and A. K. Jain, "Face spoof detection with image distortion analysis," TIFS, 2015.

[81] 温迪(D. Wen)、韩浩(H. Han)和 A. K. 贾因(A. K. Jain)，《基于图像失真分析的人脸欺骗检测》，发表于《信息取证与安全学报》(TIFS)，2015 年。

[82] I. Chingovska, A. Anjos, and S. Marcel, "On the effectiveness of local binary patterns in face anti-spoofing," in BIOSIG, 2012.

[82] I. 钦戈夫斯卡(I. Chingovska)、A. 安若斯(A. Anjos)和 S. 马塞尔(S. Marcel)，《局部二值模式在人脸反欺骗中的有效性研究》，发表于生物特征识别系统国际会议(BIOSIG)，2012 年。

[83] T. Sainath and C. Parada, "Convolutional neural networks for small-footprint keyword spotting," 2015.

[83] T. 赛纳特(T. Sainath)和 C. 帕拉达(C. Parada)，《用于小尺寸关键词检测的卷积神经网络》，2015 年。

[84] J. Blitzer, R. McDonald, and F. Pereira, "Domain adaptation with structural correspondence learning," in EMNLP, 2006.

[84] J. 布利策(J. Blitzer)、R. 麦克唐纳(R. McDonald)和 F. 佩雷拉(F. Pereira)，《通过结构对应学习进行领域自适应》，发表于自然语言处理经验方法会议(EMNLP)，2006 年。

[85] P. W. Koh, S. Sagawa, H. Marklund, S. M. Xie, M. Zhang, A. Balsubramani, W. Hu, M. Yasunaga, R. L. Phillips, S. Beery, J. Leskovec, A. Kundaje, E. Pierson, S. Levine, C. Finn, and P. Liang, "Wilds: A benchmark of in-the-wild distribution shifts," arXiv preprint arXiv:2012.07421, 2020.

[85] P. W. 科赫(P. W. Koh)、S. 萨加瓦(S. Sagawa)、H. 马克伦德(H. Marklund)、S. M. 谢(S. M. Xie)、张铭(M. Zhang)、A. 巴尔苏布拉马尼(A. Balsubramani)、胡伟(W. Hu)、安部康弘(M. Yasunaga)、R. L. 菲利普斯(R. L. Phillips)、S. 贝里(S. Beery)、J. 莱斯科维茨(J. Leskovec)、A. 昆达杰(A. Kundaje)、E. 皮尔森(E. Pierson)、S. 莱文(S. Levine)、C. 芬恩(C. Finn)和梁鹏(P. Liang)，《WILDS:一个野外分布偏移的基准》，预印本 arXiv:2012.07421，2020 年。

[86] P. Bandi, O. Geessink, Q. Manson, M. Van Dijk, M. Balkenhol, M. Hermsen, B. E. Bejnordi, B. Lee, K. Paeng, A. Zhong et al., "From detection of individual metastases to classification of lymph node status at the patient level: the camelyon17 challenge," TMI, 2018.

[86] P. 班迪(P. Bandi)、O. 格斯辛克(O. Geessink)、Q. 曼森(Q. Manson)、M. 范迪克(M. Van Dijk)、M. 巴尔肯霍尔(M. Balkenhol)、M. 赫姆森(M. Hermsen)、B. E. 贝约尔迪(B. E. Bejnordi)、李博(B. Lee)、彭凯(K. Paeng)、钟安(A. Zhong)等，《从单个转移灶检测到患者层面淋巴结状态分类:Camelyon17 挑战赛》，发表于《医学成像学报》(TMI)，2018 年。

[87] G. Christie, N. Fendley, J. Wilson, and R. Mukherjee, "Functional map of the world," in CVPR, 2018.

[87] G. 克里斯蒂(G. Christie)、N. 芬德利(N. Fendley)、J. 威尔逊(J. Wilson)和 R. 穆克吉(R. Mukherjee)，《世界功能地图》，发表于计算机视觉与模式识别会议(CVPR)，2018 年。

[88] S. Beery, E. Cole, and A. Gjoka, "The iwildcam 2020 competition dataset," arXiv preprint arXiv:2004.10340, 2020.

[88] S. 贝里(S. Beery)、E. 科尔(E. Cole)和 A. 乔卡(A. Gjoka)，《2020 年 iwildcam 竞赛数据集》，预印本 arXiv:2004.10340，2020 年。

[89] D. Mahajan, S. Tople, and A. Sharma, "Domain generalization using causal matching," in ICML, 2021.

[89] D. 马哈詹(D. Mahajan)、S. 托普尔(S. Tople)和 A. 夏尔马(A. Sharma)，《使用因果匹配进行领域泛化》，发表于 2021 年国际机器学习会议(ICML)。

[90] X. Wang, Y. Peng, L. Lu, Z. Lu, M. Bagheri, and R. M. Summers, "Chestx-ray8: Hospital-scale chest x-ray database and benchmarks on weakly-supervised classification and localization of common thorax disease," in CVPR, 2017.

[90] 王 X(X. Wang)、彭 Y(Y. Peng)、卢 L(L. Lu)、卢 Z(Z. Lu)、巴盖里 M(M. Bagheri)和萨默斯 R. M(R. M. Summers)，《Chestx - ray8:医院规模的胸部 X 光数据库以及常见胸部疾病弱监督分类和定位基准》，发表于 2017 年计算机视觉与模式识别会议(CVPR)。

[91] J. Irvin, P. Rajpurkar, M. Ko, Y. Yu, S. Ciurea-Ilcus, C. Chute, H. Marklund, B. Haghgoo, R. Ball, K. Shpanskaya et al., "Chex-pert: A large chest radiograph dataset with uncertainty labels and expert comparison," in AAAI, 2019.

[91] J. 欧文(J. Irvin)、P. 拉杰普尔卡(P. Rajpurkar)、M. 科(M. Ko)、于 Y(Y. Yu)、S. 丘雷亚 - 伊尔库斯(S. Ciurea - Ilcus)、C. 丘特(C. Chute)、H. 马克伦德(H. Marklund)、B. 哈格古(B. Haghgoo)、R. 鲍尔(R. Ball)、K. 什潘斯卡娅(K. Shpanskaya)等人，《Chex - pert:一个带有不确定标签和专家对比的大型胸部X光片数据集》，发表于 2019 年美国人工智能协会会议(AAAI)。

[92] K. Cobbe, O. Klimov, C. Hesse, T. Kim, and J. Schulman, "Quantifying generalization in reinforcement learning," in ICML, 2019.

[92] K. 科布(K. Cobbe)、O. 克利莫夫(O. Klimov)、C. 黑塞(C. Hesse)、金 T(T. Kim)和 J. 舒尔曼(J. Schulman)，《量化强化学习中的泛化能力》，发表于 2019 年国际机器学习会议(ICML)。

[93] K. Cobbe, C. Hesse, J. Hilton, and J. Schulman, "Leveraging procedural generation to benchmark reinforcement learning," in ICML, 2020.

[93] K. 科布(K. Cobbe)、C. 黑塞(C. Hesse)、J. 希尔顿(J. Hilton)和 J. 舒尔曼(J. Schulman)，《利用程序生成对强化学习进行基准测试》，发表于 2020 年国际机器学习会议(ICML)。

[94] D. Li, J. Zhang, Y. Yang, C. Liu, Y.-Z. Song, and T. M. Hospedales, "Episodic training for domain generalization," in ICCV, 2019.

[94] 李 D(D. Li)、张 J(J. Zhang)、杨 Y(Y. Yang)、刘 C(C. Liu)、宋 Y - Z(Y. - Z. Song)和霍斯佩代尔斯 T. M(T. M. Hospedales)，《用于领域泛化的情节训练》，发表于 2019 年国际计算机视觉会议(ICCV)。

[95] J. Hoffman, E. Tzeng, T. Park, J.-Y. Zhu, P. Isola, K. Saenko, A. Efros, and T. Darrell, "Cycada: Cycle-consistent adversarial domain adaptation," in ICML, 2018.

[95] J. 霍夫曼(J. Hoffman)、E. 曾(E. Tzeng)、T. 帕克(T. Park)、朱 J - Y(J. - Y. Zhu)、P. 伊索拉(P. Isola)、K. 塞内科(K. Saenko)、A. 埃弗罗斯(A. Efros)和 T. 达雷尔(T. Darrell)，《Cycada:循环一致的对抗性领域自适应》，发表于 2018 年国际机器学习会议(ICML)。

[96] R. Gong, W. Li, Y. Chen, and L. Van Gool, "Dlow: Domain flow for adaptation and generalization," in CVPR, 2019.

[96] 龚 R(R. Gong)、李 W(W. Li)、陈 Y(Y. Chen)和范古尔 L(L. Van Gool)，《Dlow:用于自适应和泛化的领域流》，发表于 2019 年计算机视觉与模式识别会议(CVPR)。

[97] Y. Sun, L. Zheng, Y. Li, Y. Yang, Q. Tian, and S. Wang, "Learning part-based convolutional features for person re-identification," TPAMI, 2019.

[97] 孙 Y(Y. Sun)、郑 L(L. Zheng)、李 Y(Y. Li)、杨 Y(Y. Yang)、田 Q(Q. Tian)和王 S(S. Wang)，《学习基于部件的卷积特征用于行人重识别》，发表于《模式分析与机器智能汇刊》(TPAMI)，2019 年。

[98] W. Li, X. Zhu, and S. Gong, "Scalable person re-identification by harmonious attention," IJCV, 2019.

[98] 李 W(W. Li)、朱 X(X. Zhu)和龚 S(S. Gong)，《通过和谐注意力实现可扩展的行人重识别》，发表于《国际计算机视觉杂志》(IJCV)，2019 年。

[99] T. Chen, S. Ding, J. Xie, Y. Yuan, W. Chen, Y. Yang, Z. Ren, and Z. Wang, "Abd-net: Attentive but diverse person reidentification," in ICCV, 2019.

[99] 陈 T(T. Chen)、丁 S(S. Ding)、谢 J(J. Xie)、袁 Y(Y. Yuan)、陈 W(W. Chen)、杨 Y(Y. Yang)、任 Z(Z. Ren)和王 Z(Z. Wang)，《Abd - net:专注且多样化的行人重识别》，发表于 2019 年国际计算机视觉会议(ICCV)。

[100] K. Zhou, Y. Yang, A. Cavallaro, and T. Xiang, "Omni-scale feature learning for person re-identification," in ICCV, 2019.

[100] 周 K(K. Zhou)、杨 Y(Y. Yang)、卡瓦拉罗 A(A. Cavallaro)和向 T(T. Xiang)，《用于行人重识别的全尺度特征学习》，发表于 2019 年国际计算机视觉会议(ICCV)。

[101] X. Chang, T. M. Hospedales, and T. Xiang, "Multi-level factorisa-tion net for person re-identification," in CVPR, 2018.

[101] 张 X(X. Chang)、霍斯佩代尔斯 T. M(T. M. Hospedales)和向 T(T. Xiang)，《用于行人重识别的多级分解网络》，发表于 2018 年计算机视觉与模式识别会议(CVPR)。

[102] K. Zhou, Y. Yang, A. Cavallaro, and T. Xiang, "Learning generalisable omni-scale representations for person re-identification," TPAMI, 2021.

[102] 周 K(K. Zhou)、杨 Y(Y. Yang)、卡瓦拉罗 A(A. Cavallaro)和向 T(T. Xiang)，《学习可泛化的全尺度表示用于行人重识别》，发表于《模式分析与机器智能汇刊》(TPAMI)，2021 年。

[103] Y. Zhao, Z. Zhong, F. Yang, Z. Luo, Y. Lin, S. Li, and N. Sebe, "Learning to generalize unseen domains via memory-based multi-source meta-learning for person re-identification," in CVPR, 2021.

[103] 赵 Y(Y. Zhao)、钟 Z(Z. Zhong)、杨 F(F. Yang)、罗 Z(Z. Luo)、林 Y(Y. Lin)、李 S(S. Li)和塞贝 N(N. Sebe)，《通过基于记忆的多源元学习学习泛化到未见领域用于行人重识别》，发表于 2021 年计算机视觉与模式识别会议(CVPR)。

[104] S. Choi, T. Kim, M. Jeong, H. Park, and C. Kim, "Meta batch-instance normalization for generalizable person reidentification," arXiv preprint arXiv:2011.14670, 2020.

[104] S. Choi、T. Kim、M. Jeong、H. Park和C. Kim，“用于可泛化行人重识别的元批量实例归一化(Meta batch-instance normalization for generalizable person reidentification)”，arXiv预印本arXiv:2011.14670，2020年。

[105] Y. Taigman, M. Yang, M. Ranzato, and L. Wolf, "Deepface: Closing the gap to human-level performance in face verification," in CVPR, 2014.

[105] Y. Taigman、M. Yang、M. Ranzato和L. Wolf，“深度人脸:缩小人脸验证与人类水平性能的差距(Deepface: Closing the gap to human-level performance in face verification)”，发表于2014年计算机视觉与模式识别会议(CVPR)。

[106] Y. Sun, X. Wang, and X. Tang, "Deep learning face representation from predicting 10,000 classes," in CVPR, 2014.

[106] Y. Sun、X. Wang和X. Tang，“通过预测一万个类别进行深度学习人脸表征(Deep learning face representation from predicting 10,000 classes)”，发表于2014年计算机视觉与模式识别会议(CVPR)。

[107] Y. Wen, K. Zhang, Z. Li, and Y. Qiao, "A discriminative feature learning approach for deep face recognition," in ECCV,2016.

[107] Y. Wen、K. Zhang、Z. Li和Y. Qiao，“一种用于深度人脸识别的判别式特征学习方法(A discriminative feature learning approach for deep face recognition)”，发表于2016年欧洲计算机视觉会议(ECCV)。

[108] Y. Guo, L. Zhang, Y. Hu, X. He, and J. Gao, "Ms-celeb-1m:

[108] Y. Guo、L. Zhang、Y. Hu、X. He和J. Gao，“MS-Celeb-1M:

A dataset and benchmark for large-scale face recognition," in ECCV, 2016.

大规模人脸识别的数据集与基准(A dataset and benchmark for large-scale face recognition)”，发表于2016年欧洲计算机视觉会议(ECCV)。

[109] L. Wolf, T. Hassner, and I. Maoz, "Face recognition in unconstrained videos with matched background similarity," in CVPR, 2011.

[109] L. Wolf、T. Hassner和I. Maoz，“利用匹配背景相似度进行无约束视频中的人脸识别(Face recognition in unconstrained videos with matched background similarity)”，发表于2011年计算机视觉与模式识别会议(CVPR)。

[110] N. D. Kalka, B. Maze, J. A. Duncan, K. O'Connor, S. Elliott, K. Hebert, J. Bryan, and A. K. Jain, "Ijb-s: Iarpa janus surveillance video benchmark," in BTAS, 2018.

[110] N. D. Kalka、B. Maze、J. A. Duncan、K. O'Connor、S. Elliott、K. Hebert、J. Bryan和A. K. Jain，“IJB-S:IARPA雅努斯监控视频基准(Ijb-s: Iarpa janus surveillance video benchmark)”，发表于2018年生物特征识别理论、应用与系统国际会议(BTAS)。

[111] Z. Cheng, X. Zhu, and S. Gong, "Low-resolution face recognition," in ACCV, 2018.

[111] Z. Cheng、X. Zhu和S. Gong，“低分辨率人脸识别(Low-resolution face recognition)”，发表于2018年亚洲计算机视觉会议(ACCV)。

[112] B. F. Klare, B. Klein, E. Taborsky, A. Blanton, J. Cheney, K. Allen, P. Grother, A. Mah, and A. K. Jain, "Pushing the frontiers of unconstrained face detection and recognition: Iarpa janus benchmark a," in CVPR, 2015.

[112] B. F. Klare、B. Klein、E. Taborsky、A. Blanton、J. Cheney、K. Allen、P. Grother、A. Mah和A. K. Jain，“突破无约束人脸检测与识别的前沿:IARPA雅努斯基准A(Pushing the frontiers of unconstrained face detection and recognition: Iarpa janus benchmark a)”，发表于2015年计算机视觉与模式识别会议(CVPR)。

[113] B. Maze, J. Adams, J. A. Duncan, N. Kalka, T. Miller, C. Otto, A. K. Jain, W. T. Niggel, J. Anderson, J. Cheney et al., "Iarpa janus benchmark-c: Face dataset and protocol," in ICB, 2018.

[113] B. Maze、J. Adams、J. A. Duncan、N. Kalka、T. Miller、C. Otto、A. K. Jain、W. T. Niggel、J. Anderson、J. Cheney等人，“IARPA雅努斯基准C:人脸数据集与协议(Iarpa janus benchmark-c: Face dataset and protocol)”，发表于2018年国际生物特征识别会议(ICB)。

[114] S. Sengupta, J.-C. Chen, C. Castillo, V. M. Patel, R. Chellappa, and D. W. Jacobs, "Frontal to profile face verification in the wild," in WACV, 2016.

[114] S. Sengupta、J.-C. Chen、C. Castillo、V. M. Patel、R. Chellappa和D. W. Jacobs，“野外正面到侧面人脸验证(Frontal to profile face verification in the wild)”，发表于2016年冬季计算机视觉应用会议(WACV)。

[115] I. Kemelmacher-Shlizerman, S. M. Seitz, D. Miller, and E. Brossard, "The megaface benchmark: 1 million faces for recognition at scale," in CVPR, 2016.

[115] I. Kemelmacher-Shlizerman、S. M. Seitz、D. Miller和E. Brossard，“百万人脸基准:用于大规模识别的一百万个面孔(The megaface benchmark: 1 million faces for recognition at scale)”，发表于2016年计算机视觉与模式识别会议(CVPR)。

[116] J. Yang, Z. Lei, and S. Z. Li, "Learn convolutional neural network for face anti-spoofing," arXiv preprint arXiv:1408.5601, 2014.

[116] J. Yang、Z. Lei和S. Z. Li，“学习卷积神经网络用于人脸反欺骗(Learn convolutional neural network for face anti-spoofing)”，arXiv预印本arXiv:1408.5601，2014年。

[117] R. Shao, X. Lan, J. Li, and P. C. Yuen, "Multi-adversarial discriminative deep domain generalization for face presentation attack detection," in CVPR, 2019.

[117] R. Shao、X. Lan、J. Li和P. C. Yuen，“用于人脸呈现攻击检测的多对抗判别式深度领域泛化(Multi-adversarial discriminative deep domain generalization for face presentation attack detection)”，发表于2019年计算机视觉与模式识别会议(CVPR)。

[118] Y. Shi, J. Seely, P. H. Torr, N. Siddharth, A. Hannun, N. Usunier, and G. Synnaeve, "Gradient matching for domain generalization," arXiv preprint arXiv:2104.09937, 2021.

[118] Y. Shi、J. Seely、P. H. Torr、N. Siddharth、A. Hannun、N. Usunier和G. Synnaeve，“用于领域泛化的梯度匹配(Gradient matching for domain generalization)”，arXiv预印本arXiv:2104.09937，2021年。

[119] A. Robey, G. J. Pappas, and H. Hassani, "Model-based domain generalization," NeurIPS, 2021.

[119] A. 罗比(Robey)、G. J. 帕帕斯(Pappas)和 H. 哈萨尼(Hassani)，《基于模型的领域泛化》，神经信息处理系统大会(NeurIPS)，2021 年。

[120] H. Yao, Y. Wang, S. Li, L. Zhang, W. Liang, J. Zou, and C. Finn, "Improving out-of-distribution robustness via selective augmentation," arXiv preprint arXiv:2201.00299, 2022.

[120] H. 姚(Yao)、Y. 王(Wang)、S. 李(Li)、L. 张(Zhang)、W. 梁(Liang)、J. 邹(Zou)和 C. 芬恩(Finn)，《通过选择性增强提高分布外鲁棒性》，预印本 arXiv:2201.00299，2022 年。

[121] Q. Dou, D. C. Castro, K. Kamnitsas, and B. Glocker, "Domain generalization via model-agnostic learning of semantic features," in NeurIPS, 2019.

[121] Q. 窦(Dou)、D. C. 卡斯特罗(Castro)、K. 卡姆尼察斯(Kamnitsas)和 B. 格洛克(Glocker)，《通过语义特征的模型无关学习实现领域泛化》，神经信息处理系统大会(NeurIPS)，2019 年。

[122] B. Mazoure, I. Kostrikov, O. Nachum, and J. Tompson, "Improving zero-shot generalization in offline reinforcement learning using generalized similarity functions," arXiv preprint arXiv:2111.14629, 2021.

[122] B. 马祖尔(Mazoure)、I. 科斯特里科夫(Kostrikov)、O. 纳楚姆(Nachum)和 J. 汤普森(Tompson)，《使用广义相似性函数提高离线强化学习中的零样本泛化能力》，预印本 arXiv:2111.14629，2021 年。

[123] N. Hansen and X. Wang, "Generalization in reinforcement learning by soft data augmentation," in ICRA, 2021.

[123] N. 汉森(Hansen)和 X. 王(Wang)，《通过软数据增强实现强化学习中的泛化》，国际机器人与自动化会议(ICRA)，2021 年。

[124] M. Deitke, W. Han, A. Herrasti, A. Kembhavi, E. Kolve, R. Mot-taghi, J. Salvador, D. Schwenk, E. VanderBilt, M. Wallingford et al., "Robothor: An open simulation-to-real embodied ai platform," in CVPR, 2020.

[124] M. 戴特克(Deitke)、W. 韩(Han)、A. 赫拉斯特(Herrasti)、A. 肯巴维(Kembhavi)、E. 科尔夫(Kolve)、R. 莫塔吉(Mot-taghi)、J. 萨尔瓦多(Salvador)、D. 施文克(Schwenk)、E. 范德比尔(VanderBilt)、M. 沃林福德(Wallingford)等人，《Robothor:一个开放的从模拟到现实的具身人工智能平台》，计算机视觉与模式识别会议(CVPR)，2020 年。

[125] R. Kirk, A. Zhang, E. Grefenstette, and T. Rocktäschel, "A survey of generalisation in deep reinforcement learning," arXiv preprint arXiv:2111.09794, 2021.

[125] R. 柯克(Kirk)、A. 张(Zhang)、E. 格雷芬施泰特(Grefenstette)和 T. 罗克塔舍尔(Rocktäschel)，《深度强化学习中的泛化综述》，预印本 arXiv:2111.09794，2021 年。

[126] S. Sagawa, P. W. Koh, T. B. Hashimoto, and P. Liang, "Distri-butionally robust neural networks for group shifts: On the importance of regularization for worst-case generalization," arXiv preprint arXiv:1911.08731, 2019.

[126] S. 萨加瓦(Sagawa)、P. W. 科(Koh)、T. B. 桥本(Hashimoto)和 P. 梁(Liang)，《用于群体偏移的分布鲁棒神经网络:正则化对最坏情况泛化的重要性》，预印本 arXiv:1911.08731，2019 年。

[127] D. Krueger, E. Caballero, J.-H. Jacobsen, A. Zhang, J. Binas, D. Zhang, R. Le Priol, and A. Courville, "Out-of-distribution generalization via risk extrapolation (rex)," in ICML, 2021.

[127] D. 克鲁格(Krueger)、E. 卡瓦列罗(Caballero)、J.-H. 雅各布森(Jacobsen)、A. 张(Zhang)、J. 比纳斯(Binas)、D. 张(Zhang)、R. 勒普里奥(Le Priol)和 A. 库尔维尔(Courville)，《通过风险外推(rex)实现分布外泛化》，国际机器学习会议(ICML)，2021 年。

[128] I. Gulrajani and D. Lopez-Paz, "In search of lost domain generalization," arXiv preprint arXiv:2007.01434, 2020.

[128] I. 古拉贾尼(Gulrajani)和 D. 洛佩斯 - 帕斯(Lopez - Paz)，《寻找失落的领域泛化》，预印本 arXiv:2007.01434，2020 年。

[129] Y. Yang and T. Hospedales, "Deep multi-task representation learning: A tensor factorisation approach," in ICLR, 2017.

[129] Y. 杨(Yang)和 T. 霍斯佩代尔斯(Hospedales)，《深度多任务表示学习:一种张量分解方法》，国际学习表征会议(ICLR)，2017 年。

[130] A. Mallya, D. Davis, and S. Lazebnik, "Piggyback: Adapting a single network to multiple tasks by learning to mask weights," in ${ECCV},{2018}$ .

[130] A. 马利亚(Mallya)、D. 戴维斯(Davis)和 S. 拉泽布尼克(Lazebnik)，《搭载:通过学习掩码权重使单个网络适应多个任务》，见 ${ECCV},{2018}$ 。

[131] S. Liu, E. Johns, and A. J. Davison, "End-to-end multi-task learning with attention," in CVPR, 2019.

[131] S. 刘(Liu)、E. 约翰斯(Johns)和 A. J. 戴维森(Davison)，《基于注意力的端到端多任务学习》，计算机视觉与模式识别会议(CVPR)，2019 年。

[132] P. Guo, C.-Y. Lee, and D. Ulbricht, "Learning to branch for multitask learning," in ICML, 2020.

[132] P. 郭(Guo)、C.-Y. 李(Lee)和 D. 乌尔布里希特(Ulbricht)，《为多任务学习学习分支》，国际机器学习会议(ICML)，2020 年。

[133] X. Sun, R. Panda, R. Feris, and K. Saenko, "Adashare: Learning what to share for efficient deep multi-task learning," in NeurIPS, 2020.

[133] X. 孙(Sun)、R. 潘达(Panda)、R. 费里斯(Feris)和 K. 萨内科(Saenko)，《Adashare:学习共享内容以实现高效深度多任务学习》，神经信息处理系统大会(NeurIPS)，2020 年。

[134] S. Wang, L. Yu, C. Li, C.-W. Fu, and P.-A. Heng, "Learning from extrinsic and intrinsic supervisions for domain generalization," in ${ECCV},{2020}$ .

[134] S. 王(Wang)、L. 余(Yu)、C. 李(Li)、C.-W. 傅(Fu)和 P.-A. 恒(Heng)，《从外在和内在监督中学习以实现领域泛化》，见 ${ECCV},{2020}$ 。

[135] I. Albuquerque, N. Naik, J. Li, N. Keskar, and R. Socher, "Improving out-of-distribution generalization via multi-task self-supervised pretraining," arXiv preprint arXiv:2003.13525, 2020.

[135] I. 阿尔伯克基(Albuquerque)、N. 奈克(Naik)、J. 李(Li)、N. 凯斯卡尔(Keskar)和 R. 索切尔(Socher)，“通过多任务自监督预训练提高分布外泛化能力”，预印本 arXiv:2003.13525，2020 年。

[136] S. J. Pan and Q. Yang, "A survey on transfer learning," TKDE, 2009.

[136] S. J. 潘(Pan)和 Q. 杨(Yang)，“迁移学习综述”，《知识与数据工程学报》(TKDE)，2009 年。

[137] Y. Zhu, R. Kiros, R. Zemel, R. Salakhutdinov, R. Urtasun, A. Tor-ralba, and S. Fidler, "Aligning books and movies: Towards story-like visual explanations by watching movies and reading books," in ${ICCV},{2015}$ .

[137] Y. 朱(Zhu)、R. 基罗斯(Kiros)、R. 泽梅尔(Zemel)、R. 萨拉胡丁诺夫(Salakhutdinov)、R. 乌尔塔松(Urtasun)、A. 托拉尔巴(Torralba)和 S. 菲德勒(Fidler)，“使书籍与电影对齐:通过观看电影和阅读书籍实现类似故事的视觉解释”，见 ${ICCV},{2015}$。

[138] R. Girshick, J. Donahue, T. Darrell, and J. Malik, "Rich feature hierarchies for accurate object detection and semantic segmentation," in CVPR, 2014.

[138] R. 吉尔希克(Girshick)、J. 多纳休(Donahue)、T. 达雷尔(Darrell)和 J. 马利克(Malik)，“用于精确目标检测和语义分割的丰富特征层次结构”，见计算机视觉与模式识别会议(CVPR)，2014 年。

[139] J. Yosinski, J. Clune, Y. Bengio, and H. Lipson, "How transferable are features in deep neural networks?" in NeurIPS, 2014.

[139] J. 约辛斯基(Yosinski)、J. 克鲁恩(Clune)、Y. 本吉奥(Bengio)和 H. 利普森(Lipson)，“深度神经网络中的特征可迁移性如何？”，见神经信息处理系统大会(NeurIPS)，2014 年。

[140] J. Donahue, Y. Jia, O. Vinyals, J. Hoffman, N. Zhang, E. Tzeng, and T. Darrell, "Decaf: A deep convolutional activation feature for generic visual recognition," in ICML, 2014.

[140] J. 多纳休(Donahue)、Y. 贾(Jia)、O. 维尼亚尔斯(Vinyals)、J. 霍夫曼(Hoffman)、N. 张(Zhang)、E. 曾(Tzeng)和 T. 达雷尔(Darrell)，“Decaf:用于通用视觉识别的深度卷积激活特征”，见国际机器学习会议(ICML)，2014 年。

[141] W. Chen, Z. Yu, Z. Wang, and A. Anandkumar, "Automated synthetic-to-real generalization," in ICML, 2020.

[141] W. 陈(Chen)、Z. 余(Yu)、Z. 王(Wang)和 A. 阿南德库马尔(Anandkumar)，“自动化合成到真实的泛化”，见国际机器学习会议(ICML)，2020 年。

[142] W. Chen, Z. Yu, S. D. Mello, S. Liu, J. M. Alvarez, Z. Wang, and A. Anandkumar, "Contrastive syn-to-real generalization," in ICLR, 2021.

[142] W. 陈(Chen)、Z. 余(Yu)、S. D. 梅洛(Mello)、S. 刘(Liu)、J. M. 阿尔瓦雷斯(Alvarez)、Z. 王(Wang)和 A. 阿南德库马尔(Anandkumar)，“对比式合成到真实的泛化”，见国际学习表征会议(ICLR)，2021 年。

[143] C. H. Lampert, H. Nickisch, and S. Harmeling, "Attribute-based classification for zero-shot visual object categorization," TPAMI, 2014.

[143] C. H. 兰佩特(Lampert)、H. 尼基施(Nickisch)和 S. 哈梅林(Harmeling)，“基于属性的分类用于零样本视觉目标分类”，《模式分析与机器智能汇刊》(TPAMI)，2014 年。

[144] K. Zhou, J. Yang, C. C. Loy, and Z. Liu, "Learning to prompt for vision-language models," arXiv preprint arXiv:2109.01134, 2021.

[144] K. 周(Zhou)、J. 杨(Yang)、C. C. 洛伊(Loy)和 Z. 刘(Liu)，“学习为视觉 - 语言模型设计提示”，预印本 arXiv:2109.01134，2021 年。

[145] ——, “Conditional prompt learning for vision-language models,” in CVPR, 2022.

[145] ——，“视觉 - 语言模型的条件提示学习”，见计算机视觉与模式识别会议(CVPR)，2022 年。

[146] W.-L. Chao, S. Changpinyo, B. Gong, and F. Sha, "An empirical study and analysis of generalized zero-shot learning for object recognition in the wild," in ECCV, 2016.

[146] W.-L. 赵(Chao)、S. 张品耀(Changpinyo)、B. 龚(Gong)和 F. 沙(Sha)，“野外目标识别的广义零样本学习的实证研究与分析”，见欧洲计算机视觉会议(ECCV)，2016 年。

[147] M. Mancini, Z. Akata, E. Ricci, and B. Caputo, "Towards recognizing unseen categories in unseen domains," in ECCV, 2020.

[147] M. 曼奇尼(Mancini)、Z. 阿卡塔(Akata)、E. 里奇(Ricci)和 B. 卡普托(Caputo)，“迈向在未见领域中识别未见类别”，见欧洲计算机视觉会议(ECCV)，2020 年。

[148] Y. Xian, C. H. Lampert, B. Schiele, and Z. Akata, "Zero-shot learning-a comprehensive evaluation of the good, the bad and the ugly," TPAMI, 2018.

[148] Y. 西安(Xian)、C. H. 兰佩特(Lampert)、B. 席勒(Schiele)和 Z. 阿卡塔(Akata)，“零样本学习——对好坏丑的全面评估”，《模式分析与机器智能汇刊》(TPAMI)，2018 年。

[149] C. Gan, T. Yang, and B. Gong, "Learning attributes equals multi-source domain generalization," in CVPR, 2016.

[149] C. 甘(Gan)、T. 杨(Yang)和 B. 龚(Gong)，“学习属性等同于多源领域泛化”，见计算机视觉与模式识别会议(CVPR)，2016 年。

[150] B. Gong, Y. Shi, F. Sha, and K. Grauman, "Geodesic flow kernel for unsupervised domain adaptation," in CVPR, 2012.

[150] B. 龚(Gong)、Y. 施(Shi)、F. 沙(Sha)和 K. 格劳曼(Grauman)，“用于无监督领域自适应的测地流核”，见计算机视觉与模式识别会议(CVPR)，2012 年。

[151] M. Long, H. Zhu, J. Wang, and M. I. Jordan, "Unsupervised domain adaptation with residual transfer networks," in NeurIPS, 2016.

[151] M. 朗(M. Long)、H. 朱(H. Zhu)、J. 王(J. Wang)和 M. I. 乔丹(M. I. Jordan)，《基于残差转移网络的无监督领域自适应》，发表于神经信息处理系统大会(NeurIPS)，2016 年。

[152] Y. Balaji, R. Chellappa, and S. Feizi, "Normalized wasserstein for mixture distributions with applications in adversarial learning and domain adaptation," in ICCV, 2019.

[152] Y. 巴拉吉(Y. Balaji)、R. 切拉帕(R. Chellappa)和 S. 费齐(S. Feizi)，《用于混合分布的归一化瓦瑟斯坦距离及其在对抗学习和领域自适应中的应用》，发表于国际计算机视觉大会(ICCV)，2019 年。

[153] G. Kang, L. Jiang, Y. Yang, and A. G. Hauptmann, "Contrastive adaptation network for unsupervised domain adaptation," in CVPR, 2019.

[153] G. 康(G. Kang)、L. 江(L. Jiang)、Y. 杨(Y. Yang)和 A. G. 豪普特曼(A. G. Hauptmann)，《用于无监督领域自适应的对比自适应网络》，发表于计算机视觉与模式识别会议(CVPR)，2019 年。

[154] B. Kulis, K. Saenko, and T. Darrell, "What you saw is not what you get: Domain adaptation using asymmetric kernel transforms," in CVPR, 2011.

[154] B. 库利斯(B. Kulis)、K. 萨内科(K. Saenko)和 T. 达雷尔(T. Darrell)，《所见非所得:使用非对称核变换的领域自适应》，发表于计算机视觉与模式识别会议(CVPR)，2011 年。

[155] K.-C. Peng, Z. Wu, and J. Ernst, "Zero-shot deep domain adaptation," in ECCV, 2018.

[155] 彭(K.-C. Peng)、吴(Z. Wu)和恩斯特(J. Ernst)，《零样本深度领域自适应》，发表于欧洲计算机视觉大会(ECCV)，2018 年。

[156] P. Panareda Busto and J. Gall, "Open set domain adaptation," in ICCV, 2017.

[156] P. 帕纳雷达·布斯托(P. Panareda Busto)和 J. 加尔(J. Gall)，《开放集领域自适应》，发表于国际计算机视觉大会(ICCV)，2017 年。

[157] Z. Cao, L. Ma, M. Long, and J. Wang, "Partial adversarial domain adaptation," in ECCV, 2018.

[157] 曹(Z. Cao)、马(L. Ma)、朗(M. Long)和王(J. Wang)，《部分对抗领域自适应》，发表于欧洲计算机视觉大会(ECCV)，2018 年。

[158] K. You, M. Long, Z. Cao, J. Wang, and M. I. Jordan, "Universal domain adaptation," in CVPR, 2019.

[158] 尤(K. You)、朗(M. Long)、曹(Z. Cao)、王(J. Wang)和 M. I. 乔丹(M. I. Jordan)，《通用领域自适应》，发表于计算机视觉与模式识别会议(CVPR)，2019 年。

[159] D. Wang, E. Shelhamer, S. Liu, B. Olshausen, and T. Darrell, "Tent: Fully test-time adaptation by entropy minimization," arXiv preprint arXiv:2006.10726, 2020.

[159] 王(D. Wang)、E. 谢尔哈默(E. Shelhamer)、刘(S. Liu)、B. 奥尔绍森(B. Olshausen)和 T. 达雷尔(T. Darrell)，《Tent:通过熵最小化实现完全测试时自适应》，预印本 arXiv:2006.10726，2020 年。

[160] J. N. Kundu, N. Venkat, R. V. Babu et al., "Universal source-free domain adaptation," in CVPR, 2020.

[160] J. N. 昆杜(J. N. Kundu)、N. 文卡特(N. Venkat)、R. V. 巴布(R. V. Babu)等人，《通用无源领域自适应》，发表于计算机视觉与模式识别会议(CVPR)，2020 年。

[161] M. Zhang, S. Levine, and C. Finn, "Memo: Test time robustness via adaptation and augmentation," arXiv preprint arXiv:2110.09506, 2021.

[161] 张(M. Zhang)、S. 莱文(S. Levine)和 C. 芬恩(C. Finn)，《Memo:通过自适应和增强实现测试时鲁棒性》，预印本 arXiv:2110.09506，2021 年。

[162] Y. Iwasawa and Y. Matsuo, "Test-time classifier adjustment module for model-agnostic domain generalization," NeurIPS, 2021.

[162] 岩泽(Y. Iwasawa)和松尾(Y. Matsuo)，《用于模型无关领域泛化的测试时分类器调整模块》，神经信息处理系统大会(NeurIPS)，2021 年。

[163] Y. Sun, X. Wang, Z. Liu, J. Miller, A. Efros, and M. Hardt, "Test-time training with self-supervision for generalization under distribution shifts," in ICML, 2020.

[163] 孙(Y. Sun)、王(X. Wang)、刘(Z. Liu)、J. 米勒(J. Miller)、A. 埃弗罗斯(A. Efros)和 M. 哈特(M. Hardt)，《在分布偏移下通过自监督进行测试时训练以实现泛化》，发表于国际机器学习会议(ICML)，2020 年。

[164] S. Erfani, M. Baktashmotlagh, M. Moshtaghi, X. Nguyen, C. Leckie, J. Bailey, and R. Kotagiri, "Robust domain generali-

[164] S. 埃尔法尼(S. Erfani)、M. 巴克塔什莫特拉格(M. Baktashmotlagh)、M. 莫什塔吉(M. Moshtaghi)、阮(X. Nguyen)、C. 莱基(C. Leckie)、J. 贝利(J. Bailey)和 R. 科塔吉里(R. Kotagiri)，《通过强制分布不变性实现鲁棒领域泛化

sation by enforcing distribution invariance," in IJCAI, 2016.

》，发表于国际人工智能联合会议(IJCAI)，2016 年。

[165] M. Ghifary, D. Balduzzi, W. B. Kleijn, and M. Zhang, "Scatter component analysis: A unified framework for domain adaptation and domain generalization," TPAMI, 2017.

[165] M. 吉法里(M. Ghifary)、D. 巴尔杜齐(D. Balduzzi)、W. B. 克莱因(W. B. Kleijn)和张(M. Zhang)，《散度分量分析:领域自适应和领域泛化的统一框架》，《模式分析与机器智能汇刊》(TPAMI)，2017 年。

[166] Y. Li, M. Gong, X. Tian, T. Liu, and D. Tao, "Domain generalization via conditional invariant representations," in AAAI, 2018.

[166] 李(Y. Li)、龚(M. Gong)、田(X. Tian)、刘(T. Liu)和陶(D. Tao)，《通过条件不变表示实现领域泛化》，发表于2018年的AAAI会议。

[167] X. Jin, C. Lan, W. Zeng, and Z. Chen, "Feature alignment and restoration for domain generalization and adaptation," arXiv preprint arXiv:2006.12009, 2020.

[167] 金(X. Jin)、兰(C. Lan)、曾(W. Zeng)和陈(Z. Chen)，《用于领域泛化和适应的特征对齐与恢复》，预印本arXiv:2006.12009，2020年。

[168] S. Hu, K. Zhang, Z. Chen, and L. Chan, "Domain generalization via multidomain discriminant analysis," in UAI, 2020.

[168] 胡(S. Hu)、张(K. Zhang)、陈(Z. Chen)和陈(L. Chan)，《通过多领域判别分析实现领域泛化》，发表于2020年的UAI会议。

[169] S. Motiian, M. Piccirilli, D. A. Adjeroh, and G. Doretto, "Unified deep supervised domain adaptation and generalization," in ICCV, 2017.

[169] 莫蒂安(S. Motiian)、皮西里利(M. Piccirilli)、阿杰罗(D. A. Adjeroh)和多雷托(G. Doretto)，《统一的深度监督领域适应与泛化》，发表于2017年的ICCV会议。

[170] C. Yoon, G. Hamarneh, and R. Garbi, "Generalizable feature learning in the presence of data bias and domain class imbalance with application to skin lesion classification," in MICCAI, 2019.

[170] 尹(C. Yoon)、哈马内(G. Hamarneh)和加尔比(R. Garbi)，《存在数据偏差和领域类别不平衡情况下的可泛化特征学习及其在皮肤病变分类中的应用》，发表于2019年的MICCAI会议。

[171] D. Mahajan, S. Tople, and A. Sharma, "Domain generalization using causal matching," arXiv preprint arXiv:2006.07500, 2020.

[171] 马哈詹(D. Mahajan)、托普尔(S. Tople)和夏尔马(A. Sharma)，《使用因果匹配实现领域泛化》，预印本arXiv:2006.07500，2020年。

[172] Z. Wang, M. Loog, and J. van Gemert, "Respecting domain relations: Hypothesis invariance for domain generalization," arXiv preprint arXiv:2010.07591, 2020.

[172] 王(Z. Wang)、洛格(M. Loog)和范格默特(J. van Gemert)，《尊重领域关系:领域泛化的假设不变性》，预印本arXiv:2010.07591，2020年。

[173] H. Li, Y. Wang, R. Wan, S. Wang, T.-Q. Li, and A. C. Kot, "Domain generalization for medical imaging classification with linear-dependency regularization," in NeurIPS, 2020.

[173] 李(H. Li)、王(Y. Wang)、万(R. Wan)、王(S. Wang)、李(T.-Q. Li)和科特(A. C. Kot)，《通过线性依赖正则化实现医学图像分类的领域泛化》，发表于2020年的NeurIPS会议。

[174] M. M. Rahman, C. Fookes, M. Baktashmotlagh, and S. Sridharan, "Correlation-aware adversarial domain adaptation and generalization," PR, 2020.

[174] 拉赫曼(M. M. Rahman)、富克斯(C. Fookes)、巴克塔什莫特拉格(M. Baktashmotlagh)和斯里达尔南(S. Sridharan)，《相关感知对抗领域适应与泛化》，发表于2020年的PR期刊。

[175] I. Albuquerque, J. Monteiro, M. Darvishi, T. H. Falk, and I. Mitliagkas, "Generalizing to unseen domains via distribution matching," arXiv preprint arXiv:1911.00804, 2019.

[175] 阿尔布克尔克(I. Albuquerque)、蒙泰罗(J. Monteiro)、达维希(M. Darvishi)、福尔克(T. H. Falk)和米特利亚加斯(I. Mitliagkas)，《通过分布匹配泛化到未见领域》，预印本arXiv:1911.00804，2019年。

[176] Z. Deng, F. Ding, C. Dwork, R. Hong, G. Parmigiani, P. Patil, and P. Sur, "Representation via representations: Domain generalization via adversarially learned invariant representations," arXiv preprint arXiv:2006.11478, 2020.

[176] 邓(Z. Deng)、丁(F. Ding)、德沃克(C. Dwork)、洪(R. Hong)、帕尔米贾尼(G. Parmigiani)、帕蒂尔(P. Patil)和苏尔(P. Sur)，《通过表示实现表示:通过对抗学习的不变表示实现领域泛化》，预印本arXiv:2006.11478，2020年。

[177] T. Matsuura and T. Harada, "Domain generalization using a mixture of multiple latent domains," in AAAI, 2020.

[177] 松浦(T. Matsuura)和原田(T. Harada)，《使用多个潜在领域的混合实现领域泛化》，发表于2020年的AAAI会议。

[178] Y. Jia, J. Zhang, S. Shan, and X. Chen, "Single-side domain generalization for face anti-spoofing," in CVPR, 2020.

[178] 贾(Y. Jia)、张(J. Zhang)、单(S. Shan)和陈(X. Chen)，《用于人脸反欺骗的单边领域泛化》，发表于2020年的CVPR会议。

[179] K. Akuzawa, Y. Iwasawa, and Y. Matsuo, "Adversarial invariant feature learning with accuracy constraint for domain generalization," in ECMLPKDD, 2019.

[179] 阿久泽(K. Akuzawa)、岩泽(Y. Iwasawa)和松尾(Y. Matsuo)，《具有精度约束的对抗不变特征学习用于领域泛化》，发表于2019年的ECMLPKDD会议。

[180] S. Aslani, V. Murino, M. Dayan, R. Tam, D. Sona, and G. Hamarneh, "Scanner invariant multiple sclerosis lesion segmentation from mri," in ISBI, 2020.

[180] 阿斯兰尼(S. Aslani)、穆里诺(V. Murino)、戴扬(M. Dayan)、谭(R. Tam)、索纳(D. Sona)和哈马内(G. Hamarneh)，《从MRI中进行扫描仪不变的多发性硬化病变分割》，发表于2020年的ISBI会议。

[181] S. Zhao, M. Gong, T. Liu, H. Fu, and D. Tao, "Domain generalization via entropy regularization," in NeurIPS, 2020.

[181] 赵(S. Zhao)、龚(M. Gong)、刘(T. Liu)、傅(H. Fu)和陶(D. Tao)，《通过熵正则化实现领域泛化》，发表于2020年的NeurIPS会议。

[182] D. Li, Y. Yang, Y.-Z. Song, and T. Hospedales, "Sequential learning for domain generalization," in ECCV-W, 2020.

[182] 李(D. Li)、杨(Y. Yang)、宋(Y.-Z. Song)和霍斯佩代尔斯(T. Hospedales)，《用于领域泛化的序列学习》，发表于2020年欧洲计算机视觉大会研讨会(ECCV-W)。

[183] Y. Du, J. Xu, H. Xiong, Q. Qiu, X. Zhen, C. G. Snoek, and L. Shao, "Learning to learn with variational information bottleneck for domain generalization," in ECCV, 2020.

[183] 杜(Y. Du)、徐(J. Xu)、熊(H. Xiong)、邱(Q. Qiu)、甄(X. Zhen)、斯诺克(C. G. Snoek)和邵(L. Shao)，《利用变分信息瓶颈进行领域泛化的元学习》，发表于2020年欧洲计算机视觉大会(ECCV)。

[184] Y. Du, X. Zhen, L. Shao, and C. G. M. Snoek, "Metanorm: Learning to normalize few-shot batches across domains," in ICLR, 2021.

[184] 杜(Y. Du)、甄(X. Zhen)、邵(L. Shao)和斯诺克(C. G. M. Snoek)，《元归一化:学习跨领域对少样本批次进行归一化》，发表于2021年国际学习表征会议(ICLR)。

[185] B. Wang, M. Lapata, and I. Titov, "Meta-learning for domain generalization in semantic parsing," arXiv preprint arXiv:2010.11988, 2020.

[185] 王(B. Wang)、拉帕塔(M. Lapata)和季托夫(I. Titov)，《语义解析中用于领域泛化的元学习》，预印本arXiv:2010.11988，2020年。

[186] S. Otálora, M. Atzori, V. Andrearczyk, A. Khan, and H. Müller, "Staining invariant features for improving generalization of deep convolutional neural networks in computational pathology," Frontiers in bioengineering and biotechnology, 2019.

[186] 奥塔洛拉(S. Otálora)、阿佐里(M. Atzori)、安德烈亚尔齐克(V. Andrearczyk)、汗(A. Khan)和米勒(H. Müller)，《用于提高计算病理学中深度卷积神经网络泛化能力的染色不变特征》，发表于《生物工程与生物技术前沿》(Frontiers in bioengineering and biotechnology)，2019年。

[187] C. Chen, W. Bai, R. H. Davies, A. N. Bhuva, C. H. Manisty, J. B. Augusto, J. C. Moon, N. Aung, A. M. Lee, M. M. Sanghvi et al., "Improving the generalizability of convolutional neural network-based segmentation on cmr images," Frontiers in cardiovascular medicine, 2020.

[187] 陈(C. Chen)、白(W. Bai)、戴维斯(R. H. Davies)、布瓦(A. N. Bhuva)、马尼斯特(C. H. Manisty)、奥古斯托(J. B. Augusto)、穆恩(J. C. Moon)、昂(N. Aung)、李(A. M. Lee)、桑格维(M. M. Sanghvi)等，《提高基于卷积神经网络的心脏磁共振图像分割的泛化能力》，发表于《心血管医学前沿》(Frontiers in cardiovascular medicine)，2020年。

[188] L. Zhang, X. Wang, D. Yang, T. Sanford, S. Harmon, B. Turkbey, B. J. Wood, H. Roth, A. Myronenko, D. Xu et al., "Generalizing deep learning for medical image segmentation to unseen domains via deep stacked transformation," TMI, 2020.

[188] 张(L. Zhang)、王(X. Wang)、杨(D. Yang)、桑福德(T. Sanford)、哈蒙(S. Harmon)、特克贝(B. Turkbey)、伍德(B. J. Wood)、罗斯(H. Roth)、米罗年科(A. Myronenko)、徐(D. Xu)等，《通过深度堆叠变换将医学图像分割的深度学习泛化到未见领域》，发表于《医学成像汇刊》(TMI)，2020年。

[189] F. Qiao, L. Zhao, and X. Peng, "Learning to learn single domain generalization," in CVPR, 2020.

[189] 乔(F. Qiao)、赵(L. Zhao)和彭(X. Peng)，《学习单领域泛化》，发表于2020年计算机视觉与模式识别会议(CVPR)。

[190] A. Sinha, H. Namkoong, R. Volpi, and J. Duchi, "Certifying some distributional robustness with principled adversarial training," arXiv preprint arXiv:1710.10571, 2017.

[190] 辛哈(A. Sinha)、南孔(H. Namkoong)、沃尔皮(R. Volpi)和杜奇(J. Duchi)，《通过原则性对抗训练证明某些分布鲁棒性》，预印本arXiv:1710.10571，2017年。

[191] Z. Xu, D. Liu, J. Yang, C. Raffel, and M. Niethammer, "Robust and generalizable visual representation learning via random convolutions," in ICLR, 2021.

[191] 徐(Z. Xu)、刘(D. Liu)、杨(J. Yang)、拉菲尔(C. Raffel)和尼瑟默(M. Niethammer)，《通过随机卷积进行鲁棒且可泛化的视觉表征学习》，发表于2021年国际学习表征会议(ICLR)。

[192] N. Somavarapu, C.-Y. Ma, and Z. Kira, "Frustratingly simple domain generalization via image stylization," arXiv preprint arXiv:2006.11207, 2020.

[192] 索马瓦拉普(N. Somavarapu)、马(C.-Y. Ma)和基拉(Z. Kira)，《通过图像风格化实现令人沮丧的简单领域泛化》，预印本arXiv:2006.11207，2020年。

[193] F. C. Borlino, A. D'Innocente, and T. Tommasi, "Rethinking domain generalization baselines," arXiv preprint arXiv:2101.09060, 2021.

[193] 博利诺(F. C. Borlino)、迪诺森特(A. D'Innocente)和托马西(T. Tommasi)，《重新思考领域泛化基线》，预印本arXiv:2101.09060，2021年。

[194] F. M. Carlucci, P. Russo, T. Tommasi, and B. Caputo, "Hallucinating agnostic images to generalize across domains." in ICCV-W, 2019.

[194] 卡尔卢奇(F. M. Carlucci)、鲁索(P. Russo)、托马西(T. Tommasi)和卡普托(B. Caputo)，《生成不可知图像以实现跨领域泛化》，发表于2019年国际计算机视觉大会研讨会(ICCV-W)。

[195] Z. Xu, W. Li, L. Niu, and D. Xu, "Exploiting low-rank structure from latent domains for domain generalization," in ECCV,2014.

[195] 徐(Z. Xu)、李(W. Li)、牛(L. Niu)和徐(D. Xu)，《从潜在领域中挖掘低秩结构以实现领域泛化》，发表于2014年欧洲计算机视觉大会(ECCV)。

[196] L. Niu, W. Li, and D. Xu, "Multi-view domain generalization for visual recognition," in ICCV, 2015.

[196] 牛(L. Niu)、李(W. Li)和徐(D. Xu)，《用于视觉识别的多视图领域泛化》，发表于2015年国际计算机视觉大会(ICCV)。

[197] —, "Visual recognition by learning from web data: A weakly supervised domain generalization approach," in CVPR, 2015.

[197] —，《通过从网络数据中学习进行视觉识别:一种弱监督领域泛化方法》，发表于2015年计算机视觉与模式识别会议(CVPR)。

[198] Z. Ding and Y. Fu, "Deep domain generalization with structured low-rank constraint," TIP, 2017.

[198] 丁泽(Z. Ding)和傅宇(Y. Fu)，“具有结构化低秩约束的深度领域泛化”，《IEEE 图像处理汇刊》(TIP)，2017 年。

[199] A. D'Innocente and B. Caputo, "Domain generalization with domain-specific aggregation modules," in GCPR, 2018.

[199] A. D'Innocente 和 B. 卡普托(B. Caputo)，“使用特定领域聚合模块的领域泛化”，发表于 2018 年德国模式识别会议(GCPR)。

[200] M. Mancini, S. R. Bulo, B. Caputo, and E. Ricci, "Best sources forward: domain generalization through source-specific nets," in ICIP, 2018.

[200] M. 曼奇尼(M. Mancini)、S. R. 布洛(S. R. Bulo)、B. 卡普托(B. Caputo)和 E. 里奇(E. Ricci)，“最佳源向前:通过特定源网络实现领域泛化”，发表于 2018 年国际图像处理会议(ICIP)。

[201] S. Wang, L. Yu, K. Li, X. Yang, C.-W. Fu, and P.-A. Heng, "Dofe: Domain-oriented feature embedding for generalizable fundus image segmentation on unseen datasets," TMI, 2020.

[201] 王硕(S. Wang)、于磊(L. Yu)、李凯(K. Li)、杨晓(X. Yang)、傅传伟(C.-W. Fu)和彭安恒(P.-A. Heng)，“DOFE:用于在未见数据集上进行可泛化眼底图像分割的面向领域特征嵌入”，《IEEE 医学成像汇刊》(TMI)，2020 年。

[202] S. Seo, Y. Suh, D. Kim, J. Han, and B. Han, "Learning to optimize domain specific normalization for domain generalization," in ECCV, 2020.

[202] S. 徐(S. Seo)、Y. 徐(Y. Suh)、D. 金(D. Kim)、J. 韩(J. Han)和 B. 韩(B. Han)，“学习优化特定领域归一化以实现领域泛化”，发表于 2020 年欧洲计算机视觉会议(ECCV)。

[203] M. Segù, A. Tonioni, and F. Tombari, "Batch normalization embeddings for deep domain generalization," arXiv preprint arXiv:2011.12672, 2020.

[203] M. 塞古(M. Segù)、A. 托尼奥尼(A. Tonioni)和 F. 通巴里(F. Tombari)，“用于深度领域泛化的批量归一化嵌入”，预印本 arXiv:2011.12672，2020 年。

[204] M. Mancini, S. R. Bulo, B. Caputo, and E. Ricci, "Robust place categorization with deep domain generalization," RA-L, 2018.

[204] M. 曼奇尼(M. Mancini)、S. R. 布洛(S. R. Bulo)、B. 卡普托(B. Caputo)和 E. 里奇(E. Ricci)，“基于深度领域泛化的鲁棒场所分类”，《IEEE 机器人与自动化快报》(RA - L)，2018 年。

[205] J. Cha, H. Cho, K. Lee, S. Park, Y. Lee, and S. Park, "Domain generalization needs stochastic weight averaging for robustness on domain shifts," arXiv preprint arXiv:2102.08604, 2021.

[205] J. 查(J. Cha)、H. 赵(H. Cho)、K. 李(K. Lee)、S. 朴(S. Park)、Y. 李(Y. Lee)和 S. 朴(S. Park)，“领域泛化需要随机权重平均以应对领域偏移的鲁棒性”，预印本 arXiv:2102.08604，2021 年。

[206] U. Maniyar, A. A. Deshmukh, U. Dogan, and V. N. Balasubrama-nian, "Zero shot domain generalization," in BMVC, 2020.

[206] U. 马尼耶尔(U. Maniyar)、A. A. 德什穆克(A. A. Deshmukh)、U. 多根(U. Dogan)和 V. N. 巴拉苏布拉马尼亚姆(V. N. Balasubrama - nian)，“零样本领域泛化”，发表于 2020 年英国机器视觉会议(BMVC)。

[207] P. Chattopadhyay, Y. Balaji, and J. Hoffman, "Learning to balance specificity and invariance for in and out of domain generalization," in ECCV, 2020.

[207] P. 查托帕德亚(P. Chattopadhyay)、Y. 巴拉吉(Y. Balaji)和 J. 霍夫曼(J. Hoffman)，“学习平衡特异性和不变性以实现领域内和领域外泛化”，发表于 2020 年欧洲计算机视觉会议(ECCV)。

[208] V. Piratla, P. Netrapalli, and S. Sarawagi, "Efficient domain generalization via common-specific low-rank decomposition," in ICML, 2020.

[208] V. 皮拉特(V. Piratla)、P. 内特拉帕利(P. Netrapalli)和 S. 萨拉瓦吉(S. Sarawagi)，“通过通用 - 特定低秩分解实现高效领域泛化”，发表于 2020 年国际机器学习会议(ICML)。

[209] M. Ilse, J. M. Tomczak, C. Louizos, and M. Welling, "Diva: Domain invariant variational autoencoder," in ICLR-W, 2019.

[209] M. 伊尔塞(M. Ilse)、J. M. 托姆恰克(J. M. Tomczak)、C. 路易佐斯(C. Louizos)和 M. 韦林(M. Welling)，“DIVA:领域不变变分自编码器”，发表于 2019 年国际学习表征会议研讨会(ICLR - W)。

[210] G. Wang, H. Han, S. Shan, and X. Chen, "Cross-domain face presentation attack detection via multi-domain disentangled representation learning," in CVPR, 2020.

[210] 王戈(G. Wang)、韩浩(H. Han)、单珊(S. Shan)和陈曦(X. Chen)，“通过多领域解纠缠表示学习进行跨领域人脸呈现攻击检测”，发表于 2020 年计算机视觉与模式识别会议(CVPR)。

[211] M. Laskin, K. Lee, A. Stooke, L. Pinto, P. Abbeel, and A. Srinivas, "Reinforcement learning with augmented data," NeurIPS, 2020.

[211] M. 拉斯金(M. Laskin)、K. 李(K. Lee)、A. 斯托克(A. Stooke)、L. 平托(L. Pinto)、P. 阿贝贝尔(P. Abbeel)和 A. 斯里尼瓦斯(A. Srinivas)，“使用增强数据的强化学习”，神经信息处理系统大会(NeurIPS)，2020 年。

[212] I. Kostrikov, D. Yarats, and R. Fergus, "Image augmentation is all you need: Regularizing deep reinforcement learning from pixels," arXiv preprint arXiv:2004.13649, 2020.

[212] I. 科斯德里科夫(I. Kostrikov)、D. 亚拉茨(D. Yarats)和 R. 弗格斯(R. Fergus)，“图像增强就是你所需要的:从像素正则化深度强化学习”，预印本 arXiv:2004.13649，2020 年。

[213] J. Tobin, R. Fong, A. Ray, J. Schneider, W. Zaremba, and P. Abbeel, "Domain randomization for transferring deep neural networks from simulation to the real world," in IROS, 2017.

[213] J. 托宾(J. Tobin)、R. 方(R. Fong)、A. 雷(A. Ray)、J. 施耐德(J. Schneider)、W. 扎雷巴(W. Zaremba)和 P. 阿贝贝尔(P. Abbeel)，“用于将深度神经网络从模拟转移到现实世界的领域随机化”，发表于 2017 年智能机器人与系统国际会议(IROS)。

[214] K. Lee, K. Lee, J. Shin, and H. Lee, "Network randomization: A simple technique for generalization in deep reinforcement learning," arXiv preprint arXiv:1910.05396, 2019.

[214] 李(K. Lee)、李(K. Lee)、申(J. Shin)和李(H. Lee)，《网络随机化:深度强化学习中一种简单的泛化技术》，预印本 arXiv:1910.05396，2019年。

[215] D. Yarats, A. Zhang, I. Kostrikov, B. Amos, J. Pineau, and R. Fergus, "Improving sample efficiency in model-free reinforcement learning from images," in AAAI, 2021.

[215] 亚拉茨(D. Yarats)、张(A. Zhang)、科斯德里科夫(I. Kostrikov)、阿莫斯(B. Amos)、皮诺(J. Pineau)和弗格斯(R. Fergus)，《提高基于图像的无模型强化学习的样本效率》，发表于AAAI会议，2021年。

[216] M. Laskin, A. Srinivas, and P. Abbeel, "Curl: Contrastive unsupervised representations for reinforcement learning," in ICML, 2020.

[216] 拉斯金(M. Laskin)、斯里尼瓦斯(A. Srinivas)和阿比尔(P. Abbeel)，《Curl:用于强化学习的对比无监督表示》，发表于ICML会议，2020年。

[217] C. Villani, Optimal transport: old and new. Springer Science & Business Media, 2008.

[217] 维拉尼(C. Villani)，《最优传输:旧与新》，施普林格科学与商业媒体出版社，2008年。

[218] B. Schölkopf, D. Janzing, J. Peters, E. Sgouritsa, K. Zhang, and J. Mooij, "On causal and anticausal learning," in ICML, 2012.

[218] 肖尔科普夫(B. Schölkopf)、扬津(D. Janzing)、彼得斯(J. Peters)、斯古里察(E. Sgouritsa)、张(K. Zhang)和莫伊(J. Mooij)，《关于因果和反因果学习》，发表于ICML会议，2012年。

[219] A. Gretton, K. M. Borgwardt, M. J. Rasch, B. Schölkopf, and A. Smola, "A kernel two-sample test," JMLR, 2012.

[219] 格雷顿(A. Gretton)、博格瓦尔特(K. M. Borgwardt)、拉施(M. J. Rasch)、肖尔科普夫(B. Schölkopf)和斯莫拉(A. Smola)，《核双样本检验》，《机器学习研究杂志》(JMLR)，2012年。

[220] I. Goodfellow, J. Pouget-Abadie, M. Mirza, B. Xu, D. Warde-Farley, S. Ozair, A. Courville, and Y. Bengio, "Generative adversarial nets," in NeurIPS, 2014.

[220] 古德费洛(I. Goodfellow)、普热-阿巴迪(J. Pouget - Abadie)、米尔扎(M. Mirza)、徐(B. Xu)、沃德 - 法利(D. Warde - Farley)、奥扎尔(S. Ozair)、库尔维尔(A. Courville)和本吉奥(Y. Bengio)，《生成对抗网络》，发表于NeurIPS会议，2014年。

[221] E. Tzeng, J. Hoffman, K. Saenko, and T. Darrell, "Adversarial discriminative domain adaptation," in CVPR, 2017.

[221] 曾(E. Tzeng)、霍夫曼(J. Hoffman)、塞内科(K. Saenko)和达雷尔(T. Darrell)，《对抗性判别域适应》，发表于CVPR会议，2017年。

[222] W. Zhang, W. Ouyang, W. Li, and D. Xu, "Collaborative and adversarial network for unsupervised domain adaptation," in CVPR, 2018.

[222] 张(W. Zhang)、欧阳(W. Ouyang)、李(W. Li)和徐(D. Xu)，《用于无监督域适应的协作与对抗网络》，发表于CVPR会议，2018年。

[223] M. Long, Z. Cao, J. Wang, and M. I. Jordan, "Conditional adversarial domain adaptation," in NeurIPS, 2018.

[223] 龙(M. Long)、曹(Z. Cao)、王(J. Wang)和乔丹(M. I. Jordan)，《条件对抗域适应》，发表于NeurIPS会议，2018年。

[224] C.-Y. Lee, T. Batra, M. H. Baig, and D. Ulbricht, "Sliced wasser-stein discrepancy for unsupervised domain adaptation," in CVPR, 2019.

[224] 李(C. - Y. Lee)、巴特拉(T. Batra)、拜格(M. H. Baig)和乌尔布里希特(D. Ulbricht)，《用于无监督域适应的切片瓦瑟斯坦差异》，发表于CVPR会议，2019年。

[225] Y. Ganin, E. Ustinova, H. Ajakan, P. Germain, H. Larochelle, F. Laviolette, M. Marchand, and V. Lempitsky, "Domain-adversarial training of neural networks," JMLR, 2016.

[225] 加宁(Y. Ganin)、乌斯蒂诺娃(E. Ustinova)、阿贾坎(H. Ajakan)、热尔曼(P. Germain)、拉罗谢尔(H. Larochelle)、拉维奥莱特(F. Laviolette)、马尔尚(M. Marchand)和伦皮茨基(V. Lempitsky)，《神经网络的域对抗训练》，《机器学习研究杂志》(JMLR)，2016年。

[226] C. Finn, P. Abbeel, and S. Levine, "Model-agnostic meta-learning for fast adaptation of deep networks," in ICML, 2017.

[226] 芬恩(C. Finn)、阿比尔(P. Abbeel)和莱文(S. Levine)，《用于深度网络快速适应的模型无关元学习》，发表于ICML会议，2017年。

[227] T. Hospedales, A. Antoniou, P. Micaelli, and A. Storkey, "Meta-learning in neural networks: A survey," arXiv preprint arXiv:2004.05439, 2020.

[227] 霍斯佩代尔斯(T. Hospedales)、安东尼奥(A. Antoniou)、米卡埃利(P. Micaelli)和斯托基(A. Storkey)，《神经网络中的元学习:综述》，预印本 arXiv:2004.05439，2020年。

[228] J.-M. Perez-Rua, X. Zhu, T. M. Hospedales, and T. Xiang, "Incremental few-shot object detection," in CVPR, 2020.

[228] 佩雷斯 - 鲁阿(J. - M. Perez - Rua)、朱(X. Zhu)、霍斯佩代尔斯(T. M. Hospedales)和向(T. Xiang)，《增量式少样本目标检测》，发表于CVPR会议，2020年。

[229] J. Gordon, J. Bronskill, M. Bauer, S. Nowozin, and R. E. Turner, "Meta-learning probabilistic inference for prediction," in ICLR, 2019.

[229] 戈登(J. Gordon)、布龙斯基尔(J. Bronskill)、鲍尔(M. Bauer)、诺沃津(S. Nowozin)和特纳(R. E. Turner)，《用于预测的元学习概率推理》，发表于ICLR会议，2019年。

[230] I. Goodfellow, Y. Bengio, and A. Courville, Deep Learning. MIT Press, 2016.

[230] I. 古德费洛(I. Goodfellow)、Y. 本吉奥(Y. Bengio)和 A. 库尔维尔(A. Courville)，《深度学习》(Deep Learning)。麻省理工学院出版社(MIT Press)，2016 年。

[231] I. J. Goodfellow, J. Shlens, and C. Szegedy, "Explaining and harnessing adversarial examples," in ICLR, 2015.

[231] I. J. 古德费洛(I. J. Goodfellow)、J. 什伦斯(J. Shlens)和 C. 塞格迪(C. Szegedy)，“解释和利用对抗样本”("Explaining and harnessing adversarial examples")，发表于 2015 年国际学习表征会议(ICLR)。

[232] C. Szegedy, W. Zaremba, I. Sutskever, J. Bruna, D. Erhan, I. J. Goodfellow, and R. Fergus, "Intriguing properties of neural networks," in ICLR, 2014.

[232] C. 塞格迪(C. Szegedy)、W. 扎雷巴(W. Zaremba)、I. 苏茨克维(I. Sutskever)、J. 布鲁纳(J. Bruna)、D. 埃尔汉(D. Erhan)、I. J. 古德费洛(I. J. Goodfellow)和 R. 费格斯(R. Fergus)，“神经网络的有趣特性”("Intriguing properties of neural networks")，发表于 2014 年国际学习表征会议(ICLR)。

[233] X. Huang and S. Belongie, "Arbitrary style transfer in real-time with adaptive instance normalization," in ICCV, 2017.

[233] X. 黄(X. Huang)和 S. 贝隆吉(S. Belongie)，“基于自适应实例归一化的实时任意风格迁移”("Arbitrary style transfer in real - time with adaptive instance normalization")，发表于 2017 年国际计算机视觉大会(ICCV)。

[234] H. Zhang, M. Cisse, Y. N. Dauphin, and D. Lopez-Paz, "mixup: Beyond empirical risk minimization," in ICLR, 2018.

[234] H. 张(H. Zhang)、M. 西塞(M. Cisse)、Y. N. 多芬(Y. N. Dauphin)和 D. 洛佩斯 - 帕斯(D. Lopez - Paz)，“mixup:超越经验风险最小化”("mixup: Beyond empirical risk minimization")，发表于 2018 年国际学习表征会议(ICLR)。

[235] Z.-H. Zhou, Ensemble methods: foundations and algorithms. Chapman and Hall/CRC, 2012.

[235] 周志华(Z.-H. Zhou)，《集成学习方法:基础与算法》(Ensemble methods: foundations and algorithms)。查普曼与霍尔出版社/CRC 出版社(Chapman and Hall/CRC)，2012 年。

[236] C. Szegedy, W. Liu, Y. Jia, P. Sermanet, S. Reed, D. Anguelov, D. Erhan, V. Vanhoucke, and A. Rabinovich, "Going deeper with convolutions," in CVPR, 2015.

[236] C. 塞格迪(C. Szegedy)、W. 刘(W. Liu)、Y. 贾(Y. Jia)、P. 塞尔马内特(P. Sermanet)、S. 里德(S. Reed)、D. 安古洛夫(D. Anguelov)、D. 埃尔汉(D. Erhan)、V. 范霍克(V. Vanhoucke)和 A. 拉宾诺维奇(A. Rabinovich)，“卷积神经网络的深度探索”("Going deeper with convolutions")，发表于 2015 年计算机视觉与模式识别会议(CVPR)。

[237] T. Malisiewicz, A. Gupta, and A. A. Efros, "Ensemble of exemplar-svms for object detection and beyond," in ICCV,2011.

[237] T. 马利塞维奇(T. Malisiewicz)、A. 古普塔(A. Gupta)和 A. A. 埃弗罗斯(A. A. Efros)，“用于目标检测及其他任务的样本支持向量机集成”("Ensemble of exemplar - svms for object detection and beyond")，发表于 2011 年国际计算机视觉大会(ICCV)。

[238] S. Ioffe and C. Szegedy, "Batch normalization: Accelerating deep network training by reducing internal covariate shift," in ICML, 2015.

[238] S. 伊夫(S. Ioffe)和 C. 塞格迪(C. Szegedy)，“批量归一化:通过减少内部协变量偏移加速深度网络训练”("Batch normalization: Accelerating deep network training by reducing internal covariate shift")，发表于 2015 年国际机器学习会议(ICML)。

[239] P. Izmailov, D. Podoprikhin, T. Garipov, D. Vetrov, and A. G. Wilson, "Averaging weights leads to wider optima and better generalization," in UAI, 2018.

[239] P. 伊兹马伊洛夫(P. Izmailov)、D. 波多普里欣(D. Podoprikhin)、T. 加里波夫(T. Garipov)、D. 维特罗夫(D. Vetrov)和 A. G. 威尔逊(A. G. Wilson)，“权重平均导致更宽的最优解和更好的泛化能力”("Averaging weights leads to wider optima and better generalization")，发表于 2018 年人工智能不确定性会议(UAI)。

[240] M. Noroozi and P. Favaro, "Unsupervised learning of visual representations by solving jigsaw puzzles," in ECCV,2016.

[240] M. 诺鲁齐(M. Noroozi)和 P. 法瓦罗(P. Favaro)，“通过解决拼图游戏进行视觉表征的无监督学习”("Unsupervised learning of visual representations by solving jigsaw puzzles")，发表于 2016 年欧洲计算机视觉大会(ECCV)。

[241] S. Gidaris, P. Singh, and N. Komodakis, "Unsupervised representation learning by predicting image rotations," in ICLR, 2018.

[241] S. 吉达里斯(S. Gidaris)、P. 辛格(P. Singh)和 N. 科莫达基斯(N. Komodakis)，“通过预测图像旋转进行无监督表征学习”("Unsupervised representation learning by predicting image rotations")，发表于 2018 年国际学习表征会议(ICLR)。

[242] L. Jing and Y. Tian, "Self-supervised visual feature learning with deep neural networks: A survey," TPAMI, 2020.

[242] 荆琳(L. Jing)和田永红(Y. Tian)，“基于深度神经网络的自监督视觉特征学习综述”("Self - supervised visual feature learning with deep neural networks: A survey")，发表于《模式分析与机器智能汇刊》(TPAMI)，2020 年。

[243] M. Caron, P. Bojanowski, A. Joulin, and M. Douze, "Deep clustering for unsupervised learning of visual features," in ECCV, 2018.

[243] M. 卡龙(M. Caron)、P. 博亚诺夫斯基(P. Bojanowski)、A. 茹林(A. Joulin)和 M. 杜泽(M. Douze)，“用于视觉特征无监督学习的深度聚类”("Deep clustering for unsupervised learning of visual features")，发表于 2018 年欧洲计算机视觉大会(ECCV)。

[244] K. He, H. Fan, Y. Wu, S. Xie, and R. Girshick, "Momentum contrast for unsupervised visual representation learning," in CVPR, 2020.

[244] 何恺明(K. He)、范浩强(H. Fan)、吴育昕(Y. Wu)、谢赛宁(S. Xie)和 Ross Girshick(R. Girshick)，“用于无监督视觉表征学习的动量对比”("Momentum contrast for unsupervised visual representation learning")，发表于 2020 年计算机视觉与模式识别会议(CVPR)。

[245] J.-B. Grill, F. Strub, F. Altché, C. Tallec, P. H. Richemond, E. Buchatskaya, C. Doersch, B. A. Pires, Z. D. Guo, M. G. Azar et al., "Bootstrap your own latent: A new approach to self-supervised learning," in NeurIPS, 2020.

[245] J.-B. 格里尔(J.-B. Grill)、F. 斯特鲁布(F. Strub)、F. 阿尔切(F. Altché)、C. 塔莱克(C. Tallec)、P. H. 里什蒙(P. H. Richemond)、E. 布查茨卡娅(E. Buchatskaya)、C. 多尔施(C. Doersch)、B. A. 皮雷斯(B. A. Pires)、Z. D. 郭(Z. D. Guo)、M. G. 阿扎尔(M. G. Azar)等人，“自举自身潜在表征:一种自监督学习的新方法”("Bootstrap your own latent: A new approach to self - supervised learning")，发表于 2020 年神经信息处理系统大会(NeurIPS)。

[246] X. Chen, Y. Duan, R. Houthooft, J. Schulman, I. Sutskever, and P. Abbeel, "Infogan: Interpretable representation learning by information maximizing generative adversarial nets," in NeurIPS, 2016.

[246] 陈X(X. Chen)、段Y(Y. Duan)、胡特霍夫特R(R. Houthooft)、舒尔曼J(J. Schulman)、苏茨克维I(I. Sutskever)和阿比尔P(P. Abbeel)，《信息生成对抗网络(InfoGAN):通过信息最大化生成对抗网络进行可解释的表征学习》，发表于神经信息处理系统大会(NeurIPS)，2016年。

[247] T. DeVries and G. W. Taylor, "Improved regularization of convolutional neural networks with cutout," arXiv preprint arXiv:1708.04552, 2017.

[247] 德弗里斯T(T. DeVries)和泰勒G. W(G. W. Taylor)，《使用Cutout改进卷积神经网络的正则化》，预印本arXiv:1708.04552，2017年。

[248] I. Redko, E. Morvant, A. Habrard, M. Sebban, and Y. Bennani, "A survey on domain adaptation theory: learning bounds and theoretical guarantees," arXiv preprint arXiv:2004.11829, 2020.

[248] 雷德科I(I. Redko)、莫尔万特E(E. Morvant)、哈布拉德A(A. Habrard)、塞班M(M. Sebban)和贝纳尼Y(Y. Bennani)，《领域自适应理论综述:学习边界和理论保证》，预印本arXiv:2004.11829，2020年。

[249] A. A. Deshmukh, Y. Lei, S. Sharma, U. Dogan, J. W. Cutler, and C. Scott, "A generalization error bound for multi-class domain generalization," arXiv preprint arXiv:1905.10392, 2019.

[249] 德什穆克A. A(A. A. Deshmukh)、雷Y(Y. Lei)、夏尔马S(S. Sharma)、多根U(U. Dogan)、卡特勒J. W(J. W. Cutler)和斯科特C(C. Scott)，《多类领域泛化的泛化误差界》，预印本arXiv:1905.10392，2019年。

[250] E. Rosenfeld, P. Ravikumar, and A. Risteski, "An online learning approach to interpolation and extrapolation in domain generalization," in AISTATS, 2022.

[250] 罗森菲尔德E(E. Rosenfeld)、拉维库马尔P(P. Ravikumar)和里斯泰斯基A(A. Risteski)，《领域泛化中插值和外推的在线学习方法》，发表于人工智能与统计会议(AISTATS)，2022年。

[251] R. Vedantam, D. Lopez-Paz, and D. J. Schwab, "An empirical investigation of domain generalization with empirical risk minimizers," NeurIPS, 2021.

[251] 维丹塔姆R(R. Vedantam)、洛佩斯 - 帕斯D(D. Lopez - Paz)和施瓦布D. J(D. J. Schwab)，《基于经验风险最小化器的领域泛化的实证研究》，神经信息处理系统大会(NeurIPS)，2021年。

[252] H. Ye, C. Xie, T. Cai, R. Li, Z. Li, and L. Wang, "Towards a theoretical framework of out-of-distribution generalization," NeurIPS, 2021.

[252] 叶H(H. Ye)、谢C(C. Xie)、蔡T(T. Cai)、李R(R. Li)、李Z(Z. Li)和王L(L. Wang)，《迈向分布外泛化的理论框架》，神经信息处理系统大会(NeurIPS)，2021年。

[253] D. Li, H. Gouk, and T. Hospedales, "Finding lost dg: Explaining domain generalization via model complexity," arXiv preprint arXiv:2202.00563, 2022.

[253] 李D(D. Li)、古克H(H. Gouk)和霍斯佩代尔斯T(T. Hospedales)，《寻找失落的领域泛化(DG):通过模型复杂度解释领域泛化》，预印本arXiv:2202.00563，2022年。

[254] Y. Han, G. Huang, S. Song, L. Yang, H. Wang, and Y. Wang, "Dynamic neural networks: A survey," arXiv preprint arXiv:2102.04906, 2021.

[254] 韩Y(Y. Han)、黄G(G. Huang)、宋S(S. Song)、杨L(L. Yang)、王H(H. Wang)和王Y(Y. Wang)，《动态神经网络综述》，预印本arXiv:2102.04906，2021年。

[255] X. Jia, B. De Brabandere, T. Tuytelaars, and L. Van Gool, "Dynamic filter networks," in NeurIPS, 2016.

[255] 贾X(X. Jia)、德布拉班德雷B(B. De Brabandere)、蒂特拉尔斯T(T. Tuytelaars)和范古尔L(L. Van Gool)，《动态滤波器网络》，发表于神经信息处理系统大会(NeurIPS)，2016年。

[256] B. Yang, G. Bender, Q. V. Le, and J. Ngiam, "Condconv: Conditionally parameterized convolutions for efficient inference," in NeurIPS, 2019.

[256] 杨B(B. Yang)、本德G(G. Bender)、勒Q. V(Q. V. Le)和尼亚姆J(J. Ngiam)，《条件卷积(CondConv):用于高效推理的条件参数化卷积》，发表于神经信息处理系统大会(NeurIPS)，2019年。

[257] D. Ulyanov, A. Vedaldi, and V. Lempitsky, "Instance normalization: The missing ingredient for fast stylization," arXiv:1607.08022, 2016.

[257] 乌利亚诺夫D(D. Ulyanov)、韦尔迪耶A(A. Vedaldi)和伦皮茨基V(V. Lempitsky)，《实例归一化:快速风格化缺失的要素》，预印本arXiv:1607.08022，2016年。

[258] J. L. Ba, J. R. Kiros, and G. E. Hinton, "Layer normalization," arXiv preprint arXiv:1607.06450, 2016.

[258] 巴J. L(J. L. Ba)、基罗斯J. R(J. R. Kiros)和辛顿G. E(G. E. Hinton)，《层归一化》，预印本arXiv:1607.06450，2016年。

[259] P. Luo, J. Ren, Z. Peng, R. Zhang, and J. Li, "Differentiable learning-to-normalize via switchable normalization," in ICLR, 2019.

[259] 罗P(P. Luo)、任J(J. Ren)、彭Z(Z. Peng)、张R(R. Zhang)和李J(J. Li)，《通过可切换归一化进行可微的归一化学习》，发表于国际学习表征会议(ICLR)，2019年。

[260] T. Park, M.-Y. Liu, T.-C. Wang, and J.-Y. Zhu, "Semantic image synthesis with spatially-adaptive normalization," in CVPR, 2019.

[260] 朴T(T. Park)、刘M - Y(M. - Y. Liu)、王T - C(T. - C. Wang)和朱J - Y(J. - Y. Zhu)，《基于空间自适应归一化的语义图像合成》，发表于计算机视觉与模式识别会议(CVPR)，2019年。

[261] L. Deecke, T. Hospedales, and H. Bilen, "Latent domain learning with dynamic residual adapters," arXiv preprint arXiv:2006.00996, 2020.

[261] 德克L(L. Deecke)、霍斯佩代尔斯T(T. Hospedales)和比伦H(H. Bilen)，《使用动态残差适配器的潜在领域学习》，预印本arXiv:2006.00996，2020年。

[262] K. Xu, M. Zhang, J. Li, S. S. Du, K.-I. Kawarabayashi, and S. Jegelka, "How neural networks extrapolate: From feedforward to graph neural networks," in ICLR, 2021.

[262] 徐(Xu)、张(Zhang)、李(Li)、杜(Du)、河原林(Kawarabayashi)和杰格尔卡(Jegelka)，“神经网络如何外推:从前馈网络到图神经网络”，发表于《国际学习表征会议》(ICLR)，2021年。

[263] R. Geirhos, J.-H. Jacobsen, C. Michaelis, R. Zemel, W. Brendel, M. Bethge, and F. A. Wichmann, "Shortcut learning in deep neural networks," Nature Machine Intelligence, 2020.

[263] 盖尔霍斯(Geirhos)、雅各布森(Jacobsen)、米夏埃利斯(Michaelis)、泽梅尔(Zemel)、布伦德尔(Brendel)、贝格(Bethge)和维希曼(Wichmann)，“深度神经网络中的捷径学习”，发表于《自然机器智能》(Nature Machine Intelligence)，2020年。

[264] B. Kim, H. Kim, K. Kim, S. Kim, and J. Kim, "Learning not to learn: Training deep neural networks with biased data," in CVPR, 2019.

[264] 金(Kim)、金(Kim)、金(Kim)、金(Kim)和金(Kim)，“学习不学习:用有偏差的数据训练深度神经网络”，发表于《计算机视觉与模式识别会议》(CVPR)，2019年。

[265] Y. Bengio, T. Deleu, N. Rahaman, R. Ke, S. Lachapelle, O. Bi-laniuk, A. Goyal, and C. Pal, "A meta-transfer objective for learning to disentangle causal mechanisms," arXiv preprint arXiv:1901.10912, 2019.

[265] 本吉奥(Bengio)、德勒(Deleu)、拉哈曼(Rahaman)、柯(Ke)、拉夏佩勒(Lachapelle)、比拉纽克(Bilaniuk)、戈亚尔(Goyal)和帕尔(Pal)，“用于学习解开因果机制的元转移目标”，预印本发表于arXiv:1901.10912，2019年。

[266] B. Scholkopf, F. Locatello, S. Bauer, N. R. Ke, N. Kalchbrenner, A. Goyal, and Y. Bengio, "Towards causal representation learning," arXiv preprint arXiv:2102.11107, 2021.

[266] 肖尔科普夫(Scholkopf)、洛卡特洛(Locatello)、鲍尔(Bauer)、柯(Ke)、卡尔克布伦纳(Kalchbrenner)、戈亚尔(Goyal)和本吉奥(Bengio)，“迈向因果表征学习”，预印本发表于arXiv:2102.11107，2021年。

[267] J. Hoffman, S. Gupta, and T. Darrell, "Learning with side information through modality hallucination," in CVPR, 2016.

[267] 霍夫曼(Hoffman)、古普塔(Gupta)和达雷尔(Darrell)，“通过模态幻觉利用侧面信息进行学习”，发表于《计算机视觉与模式识别会议》(CVPR)，2016年。

[268] K. Zhou, A. Paiement, and M. Mirmehdi, "Detecting humans in rgb-d data with cnns," in MVA, 2017.

[268] 周(Zhou)、帕耶芒(Paiement)和米尔梅赫迪(Mirmehdi)，“用卷积神经网络(CNN)在RGB - D数据中检测人体”，发表于《机器视觉应用会议》(MVA)，2017年。

[269] A. Zunino, S. A. Bargal, R. Volpi, M. Sameki, J. Zhang, S. Sclaroff, V. Murino, and K. Saenko, "Explainable deep classification models for domain generalization," arXiv preprint arXiv:2003.06498, 2020.

[269] 祖尼诺(Zunino)、巴尔加尔(Bargal)、沃尔皮(Volpi)、萨梅基(Sameki)、张(Zhang)、斯克拉罗夫(Sclaroff)、穆里诺(Murino)和塞内科(Saenko)，“用于领域泛化的可解释深度分类模型”，预印本发表于arXiv:2003.06498，2020年。

[270] M. D. Zeiler and R. Fergus, "Visualizing and understanding convolutional networks," in ECCV, 2014.

[270] 齐勒(Zeiler)和弗格斯(Fergus)，“可视化和理解卷积网络”，发表于《欧洲计算机视觉会议》(ECCV)，2014年。

[271] Z. Li and D. Hoiem, "Learning without forgetting," TPAMI, 2017.

[271] 李(Li)和霍耶姆(Hoiem)，“学习而不忘却”，发表于《模式分析与机器智能汇刊》(TPAMI)，2017年。

[272] H. Sharifi-Noghabi, H. Asghari, N. Mehrasa, and M. Ester, "Domain generalization via semi-supervised meta learning," arXiv preprint arXiv:2009.12658, 2020.

[272] 沙里菲 - 诺加比(Sharifi - Noghabi)、阿斯加里(Asghari)、梅拉萨(Mehrasa)和埃斯特(Ester)，“通过半监督元学习实现领域泛化”，预印本发表于arXiv:2009.12658，2020年。

[273] X. Liu, S. Thermos, A. O'Neil, and S. A. Tsaftaris, "Semi-supervised meta-learning with disentanglement for domain-generalised medical image segmentation," in MICCAI, 2021.

[273] 刘(Liu)、塞尔莫斯(Thermos)、奥尼尔(O'Neil)和察夫塔里斯(Tsaftaris)，“用于领域泛化医学图像分割的带解缠的半监督元学习”，发表于《医学图像计算与计算机辅助干预会议》(MICCAI)，2021年。

[274] X. Liu, S. Thermos, P. Sanchez, A. Q. O'Neil, and S. A. Tsaftaris, "vmfnet: Compositionality meets domain-generalised segmentation," in MICCAI, 2022.

[274] 刘(Liu)、塞尔莫斯(Thermos)、桑切斯(Sanchez)、奥尼尔(O'Neil)和察夫塔里斯(Tsaftaris)，“vmfnet:组合性与领域泛化分割的结合”，发表于《医学图像计算与计算机辅助干预会议》(MICCAI)，2022年。

[275] C. Geng, S.-j. Huang, and S. Chen, "Recent advances in open set recognition: A survey," TPAMI, 2020.

[275] 耿(Geng)、黄(Huang)和陈(Chen)，“开放集识别的最新进展:综述”，发表于《模式分析与机器智能汇刊》(TPAMI)，2020年。

[276] Y. Wu, Y. Chen, L. Wang, Y. Ye, Z. Liu, Y. Guo, and Y. Fu, "Large scale incremental learning," in CVPR, 2019.

[276] 吴(Wu)、陈(Chen)、王(Wang)、叶(Ye)、刘(Liu)、郭(Guo)和傅(Fu)，“大规模增量学习”，发表于《计算机视觉与模式识别会议》(CVPR)，2019年。

[277] W. Li, R. Zhao, T. Xiao, and X. Wang, "Deepreid: Deep filter pairing neural network for person re-identification," in CVPR, 2014.

[277] 李(Li)、赵(Zhao)、肖(Xiao)和王(Wang)，“Deepreid:用于行人重识别的深度滤波器配对神经网络”，发表于《计算机视觉与模式识别会议》(CVPR)，2014年。

![0195d149-280f-7e81-bc6e-e908e6b9148e_19_139_373_215_276_0.jpg](images/0195d149-280f-7e81-bc6e-e908e6b9148e_19_139_373_215_276_0.jpg)

Kaiyang Zhou received the PhD degree in Computer Science from the University of Surrey, UK, in 2020. He is currently a Research Fellow at Nanyang Technological University, Singapore. His research lies at the intersection of machine learning and computer vision. His papers have been published at major journals and conferences in relevant fields, such as TPAMI, IJCV, ICLR, AAAI, CVPR, ICCV, and ECCV. According to Google Scholar, his papers have been cited more than 1,600 times, with h-index at 14 . He serves/served as an Area Chair/Senior Program Committee Member for BMVC (2022) and AAAI (2023), and a reviewer for top-tier journals and conferences including TPAMI, ICLR, NeurIPS, ICML, CVPR, ICCV, ECCV, etc.

周开阳于2020年从英国萨里大学(University of Surrey)获得计算机科学博士学位。他目前是新加坡南洋理工大学的研究员。他的研究领域处于机器学习和计算机视觉的交叉点。他的论文已发表在相关领域的主要期刊和会议上，如《模式分析与机器智能汇刊》(TPAMI)、《国际计算机视觉杂志》(IJCV)、国际学习表征会议(ICLR)、美国人工智能协会会议(AAAI)、计算机视觉与模式识别会议(CVPR)、国际计算机视觉会议(ICCV)和欧洲计算机视觉会议(ECCV)等。根据谷歌学术，他的论文被引用超过1600次，h指数为14。他担任过英国机器视觉会议(BMVC，2022年)和美国人工智能协会会议(AAAI，2023年)的领域主席/高级程序委员会成员，也是包括《模式分析与机器智能汇刊》(TPAMI)、国际学习表征会议(ICLR)、神经信息处理系统大会(NeurIPS)、国际机器学习会议(ICML)、计算机视觉与模式识别会议(CVPR)、国际计算机视觉会议(ICCV)、欧洲计算机视觉会议(ECCV)等顶级期刊和会议的审稿人。

![0195d149-280f-7e81-bc6e-e908e6b9148e_19_135_898_223_249_0.jpg](images/0195d149-280f-7e81-bc6e-e908e6b9148e_19_135_898_223_249_0.jpg)

Ziwei Liu is currently an Assistant Professor at Nanyang Technological University, Singapore. Previously, he was a senior research fellow at the Chinese University of Hong Kong and a postdoctoral researcher at University of California, Berkeley. Ziwei received his PhD from the Chinese University of Hong Kong. His research revolves around computer vision, machine learning and computer graphics. He has published extensively on top-tier conferences and journals in relevant fields, including CVPR, ICCV, ECCV, NeurIPS, ICLR, ICML, TPAMI, TOG and Nature - Machine Intelligence. He is the recipient of Microsoft Young Fellowship, Hong Kong PhD Fellowship, ICCV Young Researcher Award and HKSTP Best Paper Award. He also serves as an Area Chair of ICCV, NeurIPS and AAAI.

刘子微目前是新加坡南洋理工大学的助理教授。此前，他是香港中文大学的高级研究员，也是加州大学伯克利分校的博士后研究员。刘子微从香港中文大学获得博士学位。他的研究围绕计算机视觉、机器学习和计算机图形学展开。他在相关领域的顶级会议和期刊上发表了大量论文，包括计算机视觉与模式识别会议(CVPR)、国际计算机视觉会议(ICCV)、欧洲计算机视觉会议(ECCV)、神经信息处理系统大会(NeurIPS)、国际学习表征会议(ICLR)、国际机器学习会议(ICML)、《模式分析与机器智能汇刊》(TPAMI)、《计算机图形学汇刊》(TOG)和《自然 - 机器智能》(Nature - Machine Intelligence)。他获得过微软青年学者奖学金、香港博士研究生奖学金、国际计算机视觉会议青年研究者奖和香港科技园最佳论文奖。他还担任国际计算机视觉会议(ICCV)、神经信息处理系统大会(NeurIPS)和美国人工智能协会会议(AAAI)的领域主席。

![0195d149-280f-7e81-bc6e-e908e6b9148e_19_148_1398_194_269_0.jpg](images/0195d149-280f-7e81-bc6e-e908e6b9148e_19_148_1398_194_269_0.jpg)

Yu Qiao is a professor with Shanghai Al Laboratory and the Shenzhen Institutes of Advanced Technology (SIAT), the Chinese Academy of Sciences. His research interests include computer vision, deep learning, and bioinformation. He has published more than 300 papers in international journals and conferences, including T-PAMI, IJCV, T-IP, T-SP, CVPR, ICCV, etc. His H-index is 72 , with 35,000 citations in Google scholar. He is the recipient of the distinguished paper award in AAAI 2021. His group achieved the first runner-up at the ImageNet Large Scale Visual Recognition Challenge 2015 in scene recognition, and was the winner at the ActivityNet Large Scale Activity Recognition Challenge 2016 in video classification. He served as the program chair of IEEE ICIST 2014.

乔宇是上海人工智能实验室和中国科学院深圳先进技术研究院(SIAT)的教授。他的研究兴趣包括计算机视觉、深度学习和生物信息学。他在国际期刊和会议上发表了300多篇论文，包括《模式分析与机器智能汇刊》(T - PAMI)、《国际计算机视觉杂志》(IJCV)、《图像处理汇刊》(T - IP)、《信号处理汇刊》(T - SP)、计算机视觉与模式识别会议(CVPR)、国际计算机视觉会议(ICCV)等。他的h指数为72，谷歌学术引用次数达35000次。他获得过2021年美国人工智能协会会议杰出论文奖。他的团队在2015年ImageNet大规模视觉识别挑战赛的场景识别任务中获得亚军，并在2016年ActivityNet大规模活动识别挑战赛的视频分类任务中获胜。他曾担任2014年IEEE智能科学与技术国际会议(ICIST)的程序主席。

![0195d149-280f-7e81-bc6e-e908e6b9148e_19_133_1898_226_272_0.jpg](images/0195d149-280f-7e81-bc6e-e908e6b9148e_19_133_1898_226_272_0.jpg)

Tao Xiang received the Ph.D. degree in electrical and computer engineering from the National University of Singapore in 2002. He is currently a full professor in the Department of Electrical and Electronic Engineering, University of Surrey and a Research Scientist Manager at Meta AI. His research interests include computer vision and machine learning. He has published over 200 papers in international journals and conferences with over ${28}\mathrm{\;K}$ citations.

向涛于2002年从新加坡国立大学获得电气与计算机工程博士学位。他目前是萨里大学电气与电子工程系的正教授，也是Meta AI的研究科学家经理。他的研究兴趣包括计算机视觉和机器学习。他在国际期刊和会议上发表了200多篇论文，引用次数超过${28}\mathrm{\;K}$次。

![0195d149-280f-7e81-bc6e-e908e6b9148e_19_910_131_224_267_0.jpg](images/0195d149-280f-7e81-bc6e-e908e6b9148e_19_910_131_224_267_0.jpg)

Chen Change Loy (Senior Member, IEEE) received the PhD degree in computer science from the Queen Mary University of London, in 2010. He is an associate professor with the School of Computer Science and Engineering, Nanyang Technological University. Prior to joining NTU, he served as a research assistant professor with the Department of Information Engineering, The Chinese University of Hong Kong, from 2013 to 2018. His research interests include computer vision and deep learning with a focus on image/video restoration and enhancement, generative tasks, and representation learning. He serves as an Associate Editor of the International Journal of Computer Vision (IJCV) and IEEE Transactions on Pattern Analysis and Machine Intelligence (TPAMI). He also serves/served as an Area Chair of ICCV 2021, CVPR (2021, 2019), ECCV (2022, 2018), AAAI (2021-2023), and BMVC (2018-2021).

罗智泉(IEEE高级会员)于2010年从伦敦玛丽女王大学获得计算机科学博士学位。他是南洋理工大学计算机科学与工程学院的副教授。在加入南洋理工大学之前，他于2013年至2018年担任香港中文大学信息工程系的研究助理教授。他的研究兴趣包括计算机视觉和深度学习，重点是图像/视频恢复与增强、生成任务和表征学习。他担任《国际计算机视觉杂志》(IJCV)和《IEEE模式分析与机器智能汇刊》(TPAMI)的副主编。他还担任过2021年国际计算机视觉会议(ICCV)、计算机视觉与模式识别会议(CVPR，2021年、2019年)、欧洲计算机视觉会议(ECCV，2022年、2018年)、美国人工智能协会会议(AAAI，2021 - 2023年)和英国机器视觉会议(BMVC，2018 - 2021年)的领域主席。