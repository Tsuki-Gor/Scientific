# Attribute-Based Classification for Zero-Shot Visual Object Categorization

# 基于属性的零样本视觉目标分类

Christoph H. Lampert, Hannes Nickisch, and Stefan Harmeling

克里斯托夫·H·兰佩特(Christoph H. Lampert)、汉斯·尼克施(Hannes Nickisch)和斯特凡·哈梅林(Stefan Harmeling)

Abstract-We study the problem of object recognition for categories for which we have no training examples, a task also called zero-data or zero-shot learning. This situation has hardly been studied in computer vision research, even though it occurs frequently; the world contains tens of thousands of different object classes, and image collections have been formed and suitably annotated for only a few of them. To tackle the problem, we introduce attribute-based classification: Objects are identified based on a high-level description that is phrased in terms of semantic attributes, such as the object's color or shape. Because the identification of each such property transcends the specific learning task at hand, the attribute classifiers can be prelearned independently, for example, from existing image data sets unrelated to the current task. Afterward, new classes can be detected based on their attribute representation, without the need for a new training phase. In this paper, we also introduce a new data set, Animals with Attributes, of over 30,000 images of 50 animal classes, annotated with 85 semantic attributes. Extensive experiments on this and two more data sets show that attribute-based classification indeed is able to categorize images without access to any training images of the target classes.

摘要 — 我们研究了针对没有训练样本的类别进行目标识别的问题，这一任务也被称为零数据或零样本学习。尽管这种情况经常出现，但在计算机视觉研究中却很少被探讨；世界上存在数以万计的不同目标类别，而图像集仅针对其中少数类别进行了构建和适当标注。为了解决这个问题，我们引入了基于属性的分类方法:目标基于用语义属性(如目标的颜色或形状)表述的高级描述来识别。由于对每个此类属性的识别超越了当前特定的学习任务，因此属性分类器可以独立预学习，例如，从与当前任务无关的现有图像数据集中学习。之后，无需新的训练阶段，就可以基于新类别的属性表示来检测它们。在本文中，我们还引入了一个新的数据集“带属性的动物”(Animals with Attributes)，其中包含50种动物类别的3万多张图像，并标注了85个语义属性。在这个数据集以及另外两个数据集上进行的大量实验表明，基于属性的分类方法确实能够在不访问目标类别的任何训练图像的情况下对图像进行分类。

Index Terms-Object recognition, vision and scene understanding

关键词 — 目标识别、视觉与场景理解

## 1 INTRODUCTION

## 1 引言

T${}^{1}$ HE field of object recognition in natural images has made tremendous progress over the last decade. For specific object classes, in particular faces, pedestrians, and vehicles, reliable and efficient detectors are available, based on the combination of powerful low-level features, such as SIFT [1] or HoG [2], with modern machine learning techniques, such as support vector machines (SVMs) [3], [4] or boosting [5]. However, to achieve good classification accuracy, these systems require a lot of manually labeled training data, typically several thousand example images for each class to be learned.

T${}^{1}$ 在过去十年中，自然图像中的目标识别领域取得了巨大进展。对于特定的目标类别，特别是人脸、行人和车辆，基于强大的低级特征(如SIFT [1] 或HoG [2])与现代机器学习技术(如支持向量机(SVMs) [3]、[4] 或提升算法 [5])的结合，已经有了可靠且高效的检测器。然而，为了实现良好的分类准确率，这些系统需要大量手动标注的训练数据，通常每个要学习的类别需要数千张示例图像。

While building recognition systems this way is feasible for categories of large common or commercial interest, one cannot expect it to solve object recognition for all natural categories. It has been estimated that humans distinguish between approximately 30,000 basic object categories [6], and many more subordinate ones, such as different breeds of dogs or different car models [7]. It has even been argued that there are infinitely many potentially relevant categorization tasks because humans can create new categories on the fly, for example, "things to bring to a camping trip" [8]. Training conventional object detectors for all these would require millions or billions of well-labeled training images and is likely out of reach for many years, if it is possible at all. Therefore, numerous techniques for reducing the number of necessary training images have been developed, some of which we will discuss in Section 3. However, all of these techniques still require at least some labeled training examples to detect future object instances.

虽然以这种方式构建识别系统对于具有广泛公共或商业利益的类别是可行的，但不能期望它能解决所有自然类别的目标识别问题。据估计，人类能够区分大约30000种基本目标类别 [6]，以及更多的子类别，如不同品种的狗或不同的汽车型号 [7]。甚至有人认为，存在无限多个潜在相关的分类任务，因为人类可以即时创建新的类别，例如“露营旅行要带的东西” [8]。为所有这些类别训练传统的目标检测器需要数百万甚至数十亿张标注良好的训练图像，即使有可能，在未来许多年内也可能无法实现。因此，已经开发了许多减少所需训练图像数量的技术，其中一些我们将在第3节中讨论。然而，所有这些技术仍然至少需要一些标注的训练示例来检测未来的目标实例。

Human learning works differently: Although humans can, of course, learn and generalize well from examples, they are also capable of identifying completely new classes when provided with a high-level description. For example, from the phrase "eight-sided red traffic sign with white writing," we will be able to detect stop signs, and when looking for "large gray animals with long trunks," we will reliably identify elephants. In this work, which extends our original publication [9], we build on this observation and propose a system that is able to classify objects from a list of high-level semantically meaningful properties that we call attributes. The attributes serve as an intermediate layer in a classifier cascade and they enable the system to recognize object classes for which it had not seen a single training example.

人类的学习方式不同:当然，人类可以从示例中很好地学习和泛化，但当提供高级描述时，他们也能够识别全新的类别。例如，根据“带有白色文字的八边形红色交通标志”这一描述，我们能够识别停车标志；当寻找“长着长鼻子的大型灰色动物”时，我们能够可靠地识别大象。在这项扩展了我们原论文 [9] 的工作中，我们基于这一观察结果，提出了一个系统，该系统能够根据我们称为属性的高级语义有意义属性列表对目标进行分类。这些属性在分类器级联中充当中间层，使系统能够识别它从未见过一个训练示例的目标类别。

Clearly, a large number of potential attributes exist and collecting separate training material to learn an ordinary classifier for each of them would be as tedious as doing so for all object classes. Therefore, one of our main contributions in this work is to show how, instead of creating a separate training set for each attribute, we can exploit the fact that meaningful high-level concepts transcend class boundaries. To learn such attributes, we can make use of existing training data by merging images of several object classes. To learn, for example, the attribute striped, we can use images of zebras, bees, and tigers. For the attribute yellow, zebras would not be included, but bees and tigers would still prove useful, possibly together with canary birds. It is this possibility to obtain knowledge about attributes from different object classes and, vice versa, the fact that each attribute can be used for the detection of many object classes that makes our proposed learning method statistically efficient.

显然，存在大量潜在的属性，为每个属性收集单独的训练材料来学习一个普通的分类器，就像为所有目标类别这样做一样繁琐。因此，我们在这项工作中的主要贡献之一是展示如何不针对每个属性创建单独的训练集，而是利用有意义的高级概念超越类别界限这一事实。为了学习这些属性，我们可以通过合并多个目标类别的图像来利用现有的训练数据。例如，为了学习“有条纹的”这一属性，我们可以使用斑马、蜜蜂和老虎的图像。对于“黄色的”这一属性，斑马的图像不会被纳入，但蜜蜂和老虎的图像可能仍然有用，可能还可以加上金丝雀的图像。正是这种从不同目标类别获取属性知识的可能性，以及反之每个属性可用于检测许多目标类别的事实，使得我们提出的学习方法在统计上是高效的。

. Downloaded on March 26,2025 at 13:20:16 UTC from IEEE Xplore. Restrictions apply.

. 于2025年3月26日13:20:16 UTC从IEEE Xplore下载。适用限制条款。

Published by the IEEE Computer Society

由IEEE计算机协会出版

---

- C.H. Lampert is with the Institute of Science and Technology Austria, Am Campus 1, Klosterneuburg 3400, Austria. E-mail: chl@ist.ac.at.

- C.H. 兰珀特(C.H. Lampert)就职于奥地利科技学院(Institute of Science and Technology Austria)，地址为奥地利克洛斯特新堡市校园1号(Am Campus 1, Klosterneuburg 3400, Austria)。电子邮件:chl@ist.ac.at。

- H. Nickisch is with Philips Research, Röntgenstrasse 24-26, 22335 Hamburg, Germany. E-mail: hannes@nickisch.org.

- H. 尼克施(H. Nickisch)就职于飞利浦研究院(Philips Research)，地址为德国汉堡市伦琴街24 - 26号(Röntgenstrasse 24 - 26, 22335 Hamburg, Germany)。电子邮件:hannes@nickisch.org。

- S. Harmeling is with the Max Planck Institute for Intelligent Systems, 72076 Tübingen, Germany. E-mail: stefan.harmeling@tuebingen.mpg.de.

- S. 哈梅林(S. Harmeling)就职于马克斯·普朗克智能系统研究所(Max Planck Institute for Intelligent Systems)，地址为德国图宾根市72076(72076 Tübingen, Germany)。电子邮件:stefan.harmeling@tuebingen.mpg.de。

Manuscript received 5 Sept. 2012; revised 15 Mar. 2013; accepted 12 July 2013; published online 29 July 2013.

稿件于2012年9月5日收到；2013年3月15日修订；2013年7月12日接受；2013年7月29日在线发表。

Recommended for acceptance by D. Forsyth.

由D. 福赛思(D. Forsyth)推荐接受。

For information on obtaining reprints of this article, please send e-mail to: tpami@computer.org, and reference IEEECS Log Number TPAMI-2012-09-0701. Digital Object Identifier no. 10.1109/TPAMI.2013.140.

如需获取本文的重印本信息，请发送电子邮件至:tpami@computer.org，并注明IEEE计算机协会日志编号TPAMI - 2012 - 09 - 0701。数字对象标识符:10.1109/TPAMI.2013.140。

Authorized licensed use limited to: JILIN UNIVERSITY. Downloaded or 0162-8828/14/\$31.00 © 2014 IEEE

授权许可使用仅限于:吉林大学。下载或0162 - 8828/14/\$31.00 © 2014 电气与电子工程师协会(IEEE)

---

## 2 INFORMATION TRANSFER BY ATTRIBUTE SHARING

## 2 通过属性共享进行信息传递

We begin by formalizing the problem and our intuition from the previous section that the use of attributes allows us to transfer information between object classes. We first define the exact situation of our interest:

我们首先将问题形式化，并基于上一节的直觉，即属性的使用使我们能够在对象类别之间传递信息。我们首先定义我们感兴趣的具体情况:

Learning with disjoint training and test classes. Let $\mathcal{X}$ be an arbitrary feature space and let $\mathcal{Y} = \left\{  {{y}_{1},\ldots ,{y}_{K}}\right\}$ and $\mathcal{Z} =$ $\left\{  {{z}_{1},\ldots ,{z}_{L}}\right\}$ be sets of object categories, also called classes. The task of learning with disjoint training and test classes is to construct a classifier $f : \mathcal{X} \rightarrow  \mathcal{Z}$ by making use of training examples $\left( {{x}_{1},{l}_{1}}\right) ,\ldots ,\left( {{x}_{n},{l}_{n}}\right)  \subset  \mathcal{X} \times  \mathcal{Y}$ even if $\mathcal{Y} \cap  \mathcal{Z} = \varnothing {}^{1}$

使用不相交的训练和测试类别进行学习。设$\mathcal{X}$为任意特征空间，设$\mathcal{Y} = \left\{  {{y}_{1},\ldots ,{y}_{K}}\right\}$和$\mathcal{Z} =$ $\left\{  {{z}_{1},\ldots ,{z}_{L}}\right\}$为对象类别集合，也称为类。使用不相交的训练和测试类别进行学习的任务是，即使$\mathcal{Y} \cap  \mathcal{Z} = \varnothing {}^{1}$，也要利用训练示例$\left( {{x}_{1},{l}_{1}}\right) ,\ldots ,\left( {{x}_{n},{l}_{n}}\right)  \subset  \mathcal{X} \times  \mathcal{Y}$构建分类器$f : \mathcal{X} \rightarrow  \mathcal{Z}$。

Fig. 2a illustrates graphically why this task cannot be solved by ordinary multiclass classification: Standard classifiers learn one parameter vector (or other representation) ${\alpha }_{k}$ for each training class ${y}_{1},\ldots ,{y}_{K}$ . Because the classes ${z}_{1},\ldots ,{z}_{L}$ are not present during the training step, no parameter vector can be derived for them, and it is impossible to make predictions about these classes for future samples.

图2a以图形方式说明了为什么普通的多类分类无法解决此任务:标准分类器为每个训练类${y}_{1},\ldots ,{y}_{K}$学习一个参数向量(或其他表示)${\alpha }_{k}$。由于类${z}_{1},\ldots ,{z}_{L}$在训练步骤中不存在，因此无法为它们导出参数向量，也无法对未来样本的这些类进行预测。

To make predictions about classes for which no training data are available, one needs to introduce a coupling between the classes in $\mathcal{Y}$ and $\mathcal{Z}$ . Since no training data for the unobserved classes are available, this coupling cannot be learned from samples, but it has to be inserted into the system by human effort. Preferably, the amount of human effort to specify new classes should be small because otherwise collecting and labeling training samples might be a simpler solution.

为了对没有训练数据的类进行预测，需要在$\mathcal{Y}$和$\mathcal{Z}$中的类之间引入一种耦合。由于没有未观察到的类的训练数据，这种耦合不能从样本中学习，而必须由人工插入到系统中。最好，指定新类所需的人工工作量应较小，因为否则收集和标记训练样本可能是一种更简单的解决方案。

### 2.1 Attribute-Based Classification

### 2.1 基于属性的分类

We propose a solution for learning with disjoint training and test classes by introducing a small set of high-level semantic attributes that can be specified either on a per-class or on a per-image level. While we currently have no formal definition of what should count as an attribute, in the rest of the manuscript, we rely on the following characterization.

我们通过引入一小套高级语义属性，为使用不相交的训练和测试类别进行学习提出了一种解决方案，这些属性可以在每个类或每个图像的级别上指定。虽然我们目前没有对什么应算作属性给出正式定义，但在本文的其余部分，我们依赖于以下特征描述。

Attributes. We call a property of an object an attribute, if a human has the ability to decide whether the property is present or not for a certain object. ${}^{2}$

属性。如果人类能够判断某个对象是否具有某个属性，我们就称该对象的这个属性为属性。${}^{2}$

Attributes are typically nameable properties, for example, the color of an object, or the presence or absence of a certain body part. Note that the definition allows properties that are not directly visible but related to visual information, such as an animal's natural habitat. Fig. 1 shows examples of classes and attributes.

属性通常是可命名的属性，例如，对象的颜色，或某个身体部位的存在与否。请注意，该定义允许那些并非直接可见但与视觉信息相关的属性，例如动物的自然栖息地。图1显示了类和属性的示例。

An important distinction between attributes and arbitrary features is the aspect of semantics: Humans associate a meaning with a given attribute name. This allows them to create annotation directly in form of attribute values, which can then be used by the computer. Ordinary image features, on the other hand, are typically computable, but they lack the human interpretability.

属性和任意特征之间的一个重要区别在于语义方面:人类会将给定的属性名称与某种含义关联起来。这使得他们能够直接以属性值的形式创建注释，然后计算机可以使用这些注释。另一方面，普通的图像特征通常是可计算的，但缺乏人类可解释性。

![0195d2b2-ac8c-7630-a76c-75ecc68f9592_1_868_144_758_641_0.jpg](images/0195d2b2-ac8c-7630-a76c-75ecc68f9592_1_868_144_758_641_0.jpg)

Fig. 1. Examples from the Animals with Attributes: object classes with per-class attribute annotation.

图1. 动物属性数据集的示例:带有按类别属性注释的对象类别。

It is possible to assign attributes on a per-image basis, or on a per-class basis. The latter is particularly helpful, since it allows the creation of attribute annotation for a new classes with minimal effort. To make use of such attribute annotation, we propose attribute-based classification.

可以基于每张图像或每个类别来分配属性。后者特别有用，因为它允许以最小的工作量为新类别创建属性注释。为了利用此类属性注释，我们提出了基于属性的分类方法。

Attribute-based classification. Assume the situation of learning with disjoint training and test classes. If for each class $z \in  \mathcal{Z}$ and $y \in  \mathcal{Y}$ , an attribute representation ${a}^{z},{a}^{y} \in  \mathcal{A}$ is available, then we can learn a nontrivial classifier $\alpha  : \mathcal{X} \rightarrow$ $\mathcal{Z}$ by transferring information between $\mathcal{Y}$ and $\mathcal{Z}$ through $\mathcal{A}$ .

基于属性的分类。假设存在训练类和测试类不相交的学习情况。如果对于每个类别$z \in  \mathcal{Z}$和$y \in  \mathcal{Y}$，都有一个属性表示${a}^{z},{a}^{y} \in  \mathcal{A}$可用，那么我们可以通过$\mathcal{A}$在$\mathcal{Y}$和$\mathcal{Z}$之间传递信息，从而学习一个非平凡的分类器$\alpha  : \mathcal{X} \rightarrow$ $\mathcal{Z}$。

In the rest of this paper, we will demonstrate that attribute-based classification indeed offers a solution to the problem of learning with disjoint training and test classes, and how it can be practically used for object classification. For this, we introduce and compare two generic methods to integrate attributes into multiclass classification.

在本文的其余部分，我们将证明基于属性的分类确实为训练类和测试类不相交的学习问题提供了解决方案，以及如何将其实际应用于对象分类。为此，我们介绍并比较了两种将属性集成到多类分类中的通用方法。

Direct attribute prediction (DAP), illustrated in Fig. 2b, uses an in-between layer of attribute variables to decouple the images from the layer of labels. During training, the output class label of each sample induces a deterministic labeling of the attribute layer. Consequently, any supervised learning method can be used to learn per-attribute parameters ${\beta }_{m}$ . At test time, these allow the prediction of attribute values for each test sample, from which the test class labels are inferred. Note that the classes during testing can differ from the classes used for training, as long as the coupling attribute layer is determined in a way that does not require a training phase.

直接属性预测(DAP)，如图2b所示，使用属性变量的中间层将图像与标签层解耦。在训练期间，每个样本的输出类别标签会对属性层进行确定性标记。因此，可以使用任何监督学习方法来学习每个属性的参数${\beta }_{m}$。在测试时，这些参数允许为每个测试样本预测属性值，并由此推断出测试类别标签。请注意，测试期间的类别可以与训练时使用的类别不同，只要耦合属性层的确定方式不需要训练阶段即可。

Indirect attribute prediction (IAP), depicted in Fig. 2c, also uses the attributes to transfer knowledge between classes, but the attributes form a connecting layer between two layers of labels: one for classes that are known at training time and one for classes that are not. The training phase of IAP consists of learning a classifier for each training class, as it would be the case in ordinary multiclass classification. At test time, the predictions for all training classes induce a labeling of the attribute layer, from which a labeling over the test classes is inferred.

间接属性预测(IAP)，如图2c所示，也使用属性在类别之间传递知识，但属性形成了两个标签层之间的连接层:一个用于训练时已知的类别，另一个用于未知的类别。IAP的训练阶段包括为每个训练类别学习一个分类器，就像普通的多类分类那样。在测试时，所有训练类别的预测结果会对属性层进行标记，并由此推断出测试类别的标记。

---

1. It is not necessary for $\mathcal{Y}$ and $\mathcal{Z}$ to be disjoint for the problems described to occur, $\mathcal{Z} \nsubseteq  \mathcal{Y}$ is sufficient. However, for the sake of clarity, we only treat the case of disjoint class sets in this work.

1. 对于所描述的问题，$\mathcal{Y}$和$\mathcal{Z}$不需要不相交，$\mathcal{Z} \nsubseteq  \mathcal{Y}$就足够了。然而，为了清晰起见，在本文中我们只处理类别集不相交的情况。

2. In this manuscript, we only consider binary-valued attributes. More general forms of attributes have already appeared in the literature; see Section 3.

2. 在本文中，我们只考虑二值属性。更一般形式的属性已经在文献中出现过；详见第3节。

---

![0195d2b2-ac8c-7630-a76c-75ecc68f9592_2_98_141_1505_477_0.jpg](images/0195d2b2-ac8c-7630-a76c-75ecc68f9592_2_98_141_1505_477_0.jpg)

Fig. 2. Graphical representation of the proposed across-class learning task: Dark gray nodes are always observed; light gray nodes are observed only during training. White nodes are never observed but must be inferred. An ordinary, flat, multiclass classifier (left) learns one parameter set ${\alpha }_{k}$ for each training class. It cannot generalize to classes ${\left( {z}_{l}\right) }_{l = 1,\ldots , L}$ that are not part of the training set. In an attribute-based classifier (middle) with fixed class-attribute relations (thick lines), training labels ${\left( {y}_{k}\right) }_{k = 1\ldots K}$ imply training values for the attributes ${\left( {a}_{m}\right) }_{m = 1\ldots M}$ , from which parameters ${\beta }_{m}$ are learned. At test time, attribute values can directly be inferred, and these imply output class label even for previously unseen classes. A multiclass-based attribute classifier (right) combines both ideas: Multiclass parameters ${\alpha }_{k}$ are learned for each training class. At test time, the posterior distribution of the training class labels induces a distribution over the labels of unseen classes by means of the class-attribute relationship.

图2. 所提出的跨类别学习任务的图形表示:深灰色节点始终可观测；浅灰色节点仅在训练期间可观测。白色节点从未被观测到，但必须进行推断。普通的扁平多类分类器(左)为每个训练类别学习一组参数${\alpha }_{k}$。它无法推广到不属于训练集的类别${\left( {z}_{l}\right) }_{l = 1,\ldots , L}$。在具有固定类别 - 属性关系(粗线)的基于属性的分类器(中)中，训练标签${\left( {y}_{k}\right) }_{k = 1\ldots K}$意味着属性${\left( {a}_{m}\right) }_{m = 1\ldots M}$的训练值，从中学习参数${\beta }_{m}$。在测试时，可以直接推断出属性值，即使对于以前未见过的类别，这些属性值也能暗示输出类别标签。基于多类的属性分类器(右)结合了这两种思想:为每个训练类别学习多类参数${\alpha }_{k}$。在测试时，训练类别标签的后验分布通过类别 - 属性关系在未见过的类别标签上诱导出一个分布。

The major difference between both approaches lies in the relationship between training classes and test classes. Directly learning the attributes results in a network where all classes are treated equally. When class labels are inferred at test time, the decision for all classes is based only on the attribute layer. We can expect it, therefore, to also handle the situation where training and test classes are not disjoint. In contrast, when predicting the attribute values indirectly, the training classes occur also at test time as an intermediate feature layer. On the one hand, this can introduce a bias, if training classes are also potential output classes during testing. On the other hand, one can argue that deriving the attribute layer from the label layer instead of from the samples will act as a regularization step that creates only sensible attribute combinations and, therefore, makes the system more robust. In the following, we will develop realizations for both methods and benchmark their performance.

这两种方法的主要区别在于训练类别和测试类别之间的关系。直接学习属性会得到一个所有类别都被平等对待的网络。在测试时推断类别标签时，所有类别的决策仅基于属性层。因此，我们可以预期它也能处理训练类别和测试类别不互斥的情况。相比之下，当间接预测属性值时，训练类别在测试时也会作为中间特征层出现。一方面，如果训练类别在测试期间也是潜在的输出类别，这可能会引入偏差。另一方面，有人可能会认为，从标签层而不是从样本中推导出属性层将起到正则化的作用，只会创建合理的属性组合，从而使系统更加稳健。接下来，我们将为这两种方法开发实现方案并对它们的性能进行基准测试。

### 2.2 A Probabilistic Realization

### 2.2 概率实现

Both classification methods, DAP and IAP, are essentially metastrategies that can be realized by combining existing learning tools: a supervised classifier or regressor for the image-attribute or image-class prediction with a parameter-free inference method to channel the information through the attribute layer. In the following, we use a probabilistic model that reflects the graphical structures in Figs. 2b and 2c. For simplicity, we assume that all attributes have binary values such that the attribute representation $a = \left( {{a}_{1},\ldots ,}\right.$ ${a}_{M}$ ) for any class are fixed-length binary vectors. Continuous attributes can, in principle, be handled in the same way by using regression instead of classification. A generalization to relative attributes [10] or variable length descriptions should also be possible, but lies beyond the scope of this paper.

两种分类方法，直接属性预测(DAP)和间接属性预测(IAP)，本质上都是元策略，可以通过结合现有的学习工具来实现:一个用于图像 - 属性或图像 - 类别预测的有监督分类器或回归器，以及一个无参数推理方法，用于通过属性层传递信息。接下来，我们使用一个反映图2b和2c中图形结构的概率模型。为简单起见，我们假设所有属性都具有二进制值，这样任何类别的属性表示 $a = \left( {{a}_{1},\ldots ,}\right.$ ${a}_{M}$ 是固定长度的二进制向量。原则上，连续属性可以通过使用回归而不是分类以相同的方式处理。对相对属性 [10] 或可变长度描述的推广也应该是可能的，但超出了本文的范围。

#### 2.2.1 Direct Attribute Prediction

#### 2.2.1 直接属性预测

For DAP, we start by learning probabilistic classifiers for each attribute ${a}_{m}$ . As training samples, we can use all images from all training classes, as labels, we use either

对于直接属性预测(DAP)，我们首先为每个属性 ${a}_{m}$ 学习概率分类器。作为训练样本，我们可以使用所有训练类别的所有图像，作为标签，我们可以使用

${}^{\prime }$ Authorized licensed use limited to: JILIN UNIVERSITY. Downloaded on March 26,2025 at 13:20:16 UTC from IEEE Xplore. Restrictions apply. per-image attribute annotations, if available, or we infer the labels from the entry of the attribute vector corresponding to the sample’s label, i.e., all samples of class $y$ have the binary label ${a}_{m}^{y}$ . The trained classifiers provide us with estimates of $p\left( {{a}_{m} \mid  x}\right)$ , from which we form a model for the complete image-attribute layer as $p\left( {a \mid  x}\right)  = \mathop{\prod }\limits_{{m = 1}}^{M}p\left( {{a}_{m} \mid  x}\right)$ . At test time, we assume that every class $z$ induces its attribute vector ${a}^{z}$ in a deterministic way, i.e., $p\left( {a \mid  z}\right)  =$ $\left\lbrack  \left\lbrack  {a = {a}^{z}}\right\rbrack  \right\rbrack$ , where we have made use of Iverson’s bracket notation [11]: $\left\lbrack  \left\lbrack  P\right\rbrack  \right\rbrack   = 1$ if the condition $P$ is true and it is 0 otherwise. By applying Bayes’ rule, we obtain $p\left( {z \mid  a}\right)  =$ $\frac{p\left( z\right) }{p\left( {a}^{z}\right) }\left\lbrack  \left\lbrack  {a = {a}^{z}}\right\rbrack  \right\rbrack$ as the representation of the attribute-class layer. Combining both layers, we can calculate the posterior of a test class given an image:

${}^{\prime }$ 授权许可使用仅限于:吉林大学。于2025年3月26日13:20:16 UTC从IEEE Xplore下载。适用限制。如果有逐图像属性注释，我们就使用这些注释；否则，我们从对应于样本标签的属性向量条目中推断标签，即，类别 $y$ 的所有样本都具有二进制标签 ${a}_{m}^{y}$ 。训练好的分类器为我们提供了 $p\left( {{a}_{m} \mid  x}\right)$ 的估计值，我们据此为完整的图像 - 属性层构建一个模型 $p\left( {a \mid  x}\right)  = \mathop{\prod }\limits_{{m = 1}}^{M}p\left( {{a}_{m} \mid  x}\right)$ 。在测试时，我们假设每个类别 $z$ 以确定性的方式诱导其属性向量 ${a}^{z}$ ，即 $p\left( {a \mid  z}\right)  =$ $\left\lbrack  \left\lbrack  {a = {a}^{z}}\right\rbrack  \right\rbrack$ ，这里我们使用了艾弗森括号表示法 [11]:如果条件 $P$ 为真，则 $\left\lbrack  \left\lbrack  P\right\rbrack  \right\rbrack   = 1$ 为1，否则为0。通过应用贝叶斯法则，我们得到 $p\left( {z \mid  a}\right)  =$ $\frac{p\left( z\right) }{p\left( {a}^{z}\right) }\left\lbrack  \left\lbrack  {a = {a}^{z}}\right\rbrack  \right\rbrack$ 作为属性 - 类别层的表示。结合这两层，我们可以计算给定图像下测试类别的后验概率:

$$
p\left( {z \mid  x}\right)  = \mathop{\sum }\limits_{{a \in  \{ 0,1{\} }^{M}}}p\left( {z \mid  a}\right) p\left( {a \mid  x}\right)  = \frac{p\left( z\right) }{p\left( {a}^{z}\right) }\mathop{\prod }\limits_{{m = 1}}^{M}p\left( {{a}_{m}^{z} \mid  x}\right) . \tag{1}
$$

In the absence of more specific knowledge, we assume identical test class priors, which allows us to ignore the factor $p\left( z\right)$ in the following. For the factor $p\left( a\right)$ , we assume a factorial distribution $p\left( a\right)  = \mathop{\prod }\limits_{{m = 1}}^{M}p\left( {a}_{m}\right)$ , using the empirical means $p\left( {a}_{m}\right)  = \frac{1}{K}\mathop{\sum }\limits_{{k = 1}}^{K}{a}_{m}^{{y}_{k}}$ over the training classes as attribute priors. ${}^{3}$ As decision rule $f : \mathcal{X} \rightarrow  \mathcal{Z}$ that assigns the best output class from all test classes ${z}_{1},\ldots ,{z}_{L}$ to a test sample $x$ , we then use MAP prediction:

在缺乏更具体的知识的情况下，我们假设测试类先验概率相同，这使得我们在接下来可以忽略因子$p\left( z\right)$。对于因子$p\left( a\right)$，我们假设其为因子分布$p\left( a\right)  = \mathop{\prod }\limits_{{m = 1}}^{M}p\left( {a}_{m}\right)$，使用训练类上的经验均值$p\left( {a}_{m}\right)  = \frac{1}{K}\mathop{\sum }\limits_{{k = 1}}^{K}{a}_{m}^{{y}_{k}}$作为属性先验概率。${}^{3}$ 作为决策规则$f : \mathcal{X} \rightarrow  \mathcal{Z}$，它将所有测试类${z}_{1},\ldots ,{z}_{L}$中最佳的输出类分配给测试样本$x$，然后我们使用最大后验(MAP)预测:

$$
f\left( x\right)  = \mathop{\operatorname{argmax}}\limits_{{l = 1,\ldots , L}}p\left( {z = l \mid  x}\right)  = \mathop{\operatorname{argmax}}\limits_{{l = 1,\ldots , L}}\mathop{\prod }\limits_{{m = 1}}^{M}\frac{p\left( {{a}_{m}^{{z}_{l}} \mid  x}\right) }{p\left( {a}_{m}^{{z}_{l}}\right) }. \tag{2}
$$

#### 2.2.2 Indirect Attribute Prediction

#### 2.2.2 间接属性预测

To realize IAP, we only modify the image-attribute stage: As a first step, we learn a probabilistic multiclass classifier estimating $p\left( {{y}_{k} \mid  x}\right)$ for each training classes ${y}_{k}, k = 1,\ldots , K$ . As for DAP, we assume a deterministic dependence between attributes and classes, setting $p\left( {{a}_{m} \mid  y}\right)  = \left\lbrack  \left\lbrack  {{a}_{m} = {a}_{m}^{y}}\right\rbrack  \right\rbrack$ . The combination of both steps yields

为了实现间接属性预测(IAP)，我们仅修改图像 - 属性阶段:第一步，我们为每个训练类${y}_{k}, k = 1,\ldots , K$学习一个概率多类分类器来估计$p\left( {{y}_{k} \mid  x}\right)$。对于直接属性预测(DAP)，我们假设属性和类之间存在确定性依赖关系，设置$p\left( {{a}_{m} \mid  y}\right)  = \left\lbrack  \left\lbrack  {{a}_{m} = {a}_{m}^{y}}\right\rbrack  \right\rbrack$。这两个步骤的结合产生

$$
p\left( {{a}_{m} \mid  x}\right)  = \mathop{\sum }\limits_{{k = 1}}^{K}p\left( {{a}_{m} \mid  {y}_{k}}\right) p\left( {{y}_{k} \mid  x}\right) , \tag{3}
$$

---

3. In practice, the prior $p\left( a\right)$ is not crucial to the procedure and setting $p\left( {a}_{m}\right)  = \frac{1}{2}$ yields comparable results.

3. 在实践中，先验概率$p\left( a\right)$对该过程并不关键，设置$p\left( {a}_{m}\right)  = \frac{1}{2}$可得到相当的结果。

---

so in comparison to DAP, we only perform an additional matrix-vector multiplication after evaluating the classifiers. With the estimate of $p\left( {a \mid  x}\right)$ obtained from (3) we proceed in the same way as in for DAP, i.e., we classify test samples using (2).

因此，与直接属性预测(DAP)相比，我们在评估分类器后仅进行一次额外的矩阵 - 向量乘法。利用从(3)中得到的$p\left( {a \mid  x}\right)$的估计值，我们按照与直接属性预测(DAP)相同的方式进行，即使用(2)对测试样本进行分类。

## 3 RELATED WORK

## 3 相关工作

Multilayer or cascaded classifiers have a long tradition in pattern recognition and computer vision: multilayer percep-trons [12], decision trees [13], mixtures of experts [14], and boosting [15] are prominent examples of classification systems built as feed-forward architectures with several stages. Multiclass classifiers are also often constructed as layers of binary decisions from which the final output is inferred, for example, [16], [17]. These methods differ in their training methodologies, but they share the goal of decomposing a difficult classification problem into a collection of simpler ones. However, their emphasis lies on the classification performance in a fully supervised scenario, so the methods are not capable of generalizing across class boundaries.

多层或级联分类器在模式识别和计算机视觉领域有着悠久的传统:多层感知器[12]、决策树[13]、专家混合模型[14]和提升算法[15]是构建为具有多个阶段的前馈架构的分类系统的突出示例。多类分类器也常常构建为一系列二元决策层，最终输出由此推断得出，例如[16]、[17]。这些方法的训练方法各不相同，但它们的共同目标是将一个困难的分类问题分解为一系列更简单的问题。然而，它们的重点在于全监督场景下的分类性能，因此这些方法无法跨类边界进行泛化。

Especially in the area of computer vision, multilayered classification systems have been constructed, in which intermediate layers have interpretable properties: Artificial neural networks or deep belief networks have been shown to learn interpretable filters, but these are typically restricted to low-level properties, such as edge and corner detectors [18]. Popular local feature descriptors, such as SIFT [1] or HoG [2], can be seen as hand-crafted stages in a feed-forward architecture that transform an image from the pixel domain into a representation invariant to noninformative image variations. Similarly, image segmentation has been formulated as an unsupervised method to extract contours that are discriminative for object classes [19]. Such preprocessing steps are generic in the sense that they still allow the subsequent detection of arbitrary object classes. However, the basic elements, local image descriptors or segments shapes, alone are not reliable enough indicators of generic visual object classes, unless they are used as input to a subsequent statistical learning step.

特别是在计算机视觉领域，已经构建了多层分类系统，其中中间层具有可解释的属性:人工神经网络或深度信念网络已被证明能够学习可解释的滤波器，但这些通常仅限于低级属性，如边缘和角点检测器[18]。流行的局部特征描述符，如尺度不变特征变换(SIFT)[1]或方向梯度直方图(HoG)[2]，可以看作是前馈架构中手工设计的阶段，它们将图像从像素域转换为对无信息图像变化具有不变性的表示。类似地，图像分割已被表述为一种无监督方法，用于提取对目标类别具有判别性的轮廓[19]。从某种意义上说，这些预处理步骤是通用的，因为它们仍然允许后续检测任意目标类别。然而，基本元素、局部图像描述符或分割形状本身不足以可靠地指示通用视觉目标类别，除非将它们用作后续统计学习步骤的输入。

On a higher level of abstraction, pictorial structures [20], the constellation model [21], and recent discriminatively trained deformable part models [22] are examples of the many methods that recognize objects in images by detecting discriminative parts. In principle, humans can give descriptions of object classes in terms of such parts, for example, arms or wheels. However, it is a difficult problem to build a system that learns to detect exactly the parts described. Instead, the above methods identify parts in an unsupervised way during training, which often reduces the parts to reproducible patterns of local feature points, not to units with a semantic meaning. In general, parts learned this way do not generalize across class boundaries.

在更高的抽象层面上，图形结构[20]、星座模型[21]以及最近经过判别式训练的可变形部件模型[22]是许多通过检测具有判别性的部件来识别图像中目标的方法的示例。原则上，人类可以用这些部件来描述目标类别，例如手臂或轮子。然而，构建一个能够精确学习检测所描述部件的系统是一个难题。相反，上述方法在训练过程中以无监督的方式识别部件，这通常会将部件简化为局部特征点的可重复模式，而不是具有语义意义的单元。一般来说，以这种方式学习到的部件无法跨类边界进行泛化。

### 3.1 Sharing Information between Classes

### 3.1 类间信息共享

The aspect of sharing information between classes has attracted the attention of many researchers. A common idea is to construct multiclass classifiers in a cascaded way. By making similar classes share large parts of their decision paths, fewer classification functions need to be learned, thereby increasing the system's prediction speed [23]. Similarly, one can reduce the number of feature calculations by actively selecting low-level features that help discrimination for many classes simultaneously [24]. Combinations of both approaches are also possible [25].

类间信息共享这一方面吸引了许多研究人员的关注。一个常见的思路是以级联的方式构建多类分类器。通过让相似的类共享其决策路径的大部分，需要学习的分类函数就会减少，从而提高系统的预测速度 [23]。同样地，通过主动选择能同时帮助区分多个类别的低级特征，可以减少特征计算的数量 [24]。这两种方法也可以结合使用 [25]。

In contrast, interclass transfer does not aim at higher speed, but at better generalization performance, typically for object classes with only few available training instances. From known object classes, one infers prior distributions over the expected intraclass variance in terms of distortions [26] or shapes and appearances [27]. Alternatively, features that are known to be discriminative for some classes can be reused and adapted to support the detection of new classes [28]. To our knowledge, no previous approach allows the direct incorporation of human prior knowledge. Also, all above methods require at least some training examples of the target classes and cannot handle completely new objects.

相比之下，类间迁移的目标不是提高速度，而是提高泛化性能，通常针对只有少量可用训练实例的对象类。从已知的对象类中，可以推断出关于预期类内方差在变形 [26] 或形状和外观 [27] 方面的先验分布。或者，已知对某些类有区分性的特征可以被复用并调整以支持新类别的检测 [28]。据我们所知，之前没有方法允许直接纳入人类先验知识。此外，上述所有方法都至少需要目标类别的一些训练示例，并且无法处理全新的对象。

A notable exception is [29] that, like DAP and IAP, aims at classification with disjoint train and test set. It assumes that each class has a description vector, which can be used to transfer between classes. However, because these description vectors do not necessarily have a semantic meaning, they cannot be obtained from human prior knowledge. Instead, an additional data source is needed to create them, for example, data samples in a different representation.

一个值得注意的例外是文献 [29]，它与 DAP 和 IAP 一样，旨在使用不相交的训练集和测试集进行分类。它假设每个类都有一个描述向量，可用于类间迁移。然而，由于这些描述向量不一定具有语义含义，因此无法从人类先验知识中获取。相反，需要一个额外的数据源来创建它们，例如，不同表示形式的数据样本。

### 3.2 Predicting Semantic Attributes

### 3.2 预测语义属性

A second relevant line of related work is the prediction of high-level semantic attributes for images. Prior work in the area of computer vision has mainly studied elementary properties, such as colors and geometric patterns [30], [31], [32], achieving high accuracy by developing task-specific features and representations. In the field of multimedia retrieval, similar tasks occur. For example, the TRECVID contest [33] contains a task of high-level feature extraction, which consists of predicting semantic concepts, in particular scene types, for example, outdoor, urban, and high-level actions, for example, sports. It has been shown that by combining searches for several such attributes, one can build more powerful retrieval database mechanisms, for example, of faces [34], [35].

相关工作的第二条相关路线是预测图像的高级语义属性。计算机视觉领域的先前工作主要研究了基本属性，如颜色和几何图案 [30]、[31]、[32]，通过开发特定任务的特征和表示实现了高精度。在多媒体检索领域，也会出现类似的任务。例如，TRECVID 竞赛 [33] 包含一个高级特征提取任务，该任务包括预测语义概念，特别是场景类型，如户外、城市，以及高级动作，如体育。研究表明，通过组合对多个此类属性的搜索，可以构建更强大的检索数据库机制，例如人脸检索机制 [34]、[35]。

Instead of relying on manually defined attributes, it has recently been proposed to identify attributes automatically. Parikh and Grauman [36] introduced a semiautomatic technique for this that combines classifier outputs with human feedback. Sharmanska et al. [37] propose an unsupervised technique for augmenting existing attribute representations with additional nonsemantic binary features to make them more discriminative. It has also been shown that new attributes can be found by text mining [38], [39], [40], and that object classes themselves can act as attributes for other tasks [41]. Berg et al. [40] showed that instead of predicting only the presence or absence of an attribute, their occurrence can also be localized within the Authorized licensed use limited to: JILIN UNIVERSITY. Downloaded on March 26,2025 at 13:20:16 UTC from IEEE Xplore. Restrictions apply. image. Other alternative models for predicting attributes from images include conditional random fields [42], and probabilistic topic models [43]. Scheirer et al. [44] introduced an alternative technique for turning the output of attribute classifiers into probability estimates based on extremal value theory. The concept that attributes are properties of single images has also been generalized: Parikh and Grauman [10] introduced relative attributes, which encode a comparison between two images instead of specifying an absolute property, for example, is larger than, instead of is large.

最近有人提出不依赖手动定义的属性，而是自动识别属性。帕里克(Parikh)和格劳曼(Grauman)[36] 为此引入了一种半自动技术，该技术将分类器输出与人类反馈相结合。沙曼斯卡(Sharmanska)等人 [37] 提出了一种无监督技术，用于用额外的非语义二进制特征增强现有的属性表示，使其更具区分性。研究还表明，可以通过文本挖掘找到新的属性 [38]、[39]、[40]，并且对象类本身可以作为其他任务的属性 [41]。伯格(Berg)等人 [40] 表明，除了预测属性的存在与否，还可以在图像中定位属性的出现位置。其他从图像中预测属性的替代模型包括条件随机场 [42] 和概率主题模型 [43]。谢勒(Scheirer)等人 [44] 引入了一种基于极值理论将属性分类器的输出转换为概率估计的替代技术。属性是单个图像的属性这一概念也得到了推广:帕里克和格劳曼 [10] 引入了相对属性，它编码了两幅图像之间的比较，而不是指定绝对属性，例如“比……大”，而不是“大”。

TABLE 1

Animal Classes of the Animals with Attributes Data Set

动物属性数据集的动物类别

<table><tr><td>skunk</td><td>polar bear</td><td>beaver</td><td>giraffe</td><td>leopard</td></tr><tr><td>lion</td><td>killer whale</td><td>bobcat</td><td>wolf</td><td>pig</td></tr><tr><td>fox</td><td>grizzly bear</td><td>collie</td><td>tiger</td><td>hippopotamus</td></tr><tr><td>ox</td><td>chihuahua</td><td>otter</td><td>COW</td><td>seal</td></tr><tr><td>mole</td><td>dalmatian</td><td>antelope</td><td>weasel</td><td>persian cat</td></tr><tr><td>sheep</td><td>spider monkey</td><td>hamster</td><td>mouse</td><td>chimpanzee</td></tr><tr><td>horse</td><td>blue whale</td><td>squirrel</td><td>buffalo</td><td>rat</td></tr><tr><td>bat</td><td>siamese cat</td><td>elephant</td><td>moose</td><td>humpback whale</td></tr><tr><td>zebra</td><td>rhinoceros</td><td>rabbit</td><td>walrus</td><td>giant panda</td></tr><tr><td>deer</td><td>german shepherd</td><td>dolphin</td><td>gorilla</td><td>raccoon</td></tr></table>

<table><tbody><tr><td>臭鼬</td><td>北极熊</td><td>河狸</td><td>长颈鹿</td><td>豹</td></tr><tr><td>狮子</td><td>虎鲸</td><td>短尾猫</td><td>狼</td><td>猪</td></tr><tr><td>狐狸</td><td>灰熊</td><td>柯利牧羊犬</td><td>老虎</td><td>河马</td></tr><tr><td>公牛</td><td>吉娃娃犬</td><td>水獭</td><td>奶牛</td><td>海豹</td></tr><tr><td>鼹鼠</td><td>斑点狗</td><td>羚羊</td><td>鼬</td><td>波斯猫</td></tr><tr><td>绵羊</td><td>蜘蛛猴</td><td>仓鼠</td><td>老鼠</td><td>黑猩猩</td></tr><tr><td>马</td><td>蓝鲸</td><td>松鼠</td><td>水牛</td><td>大鼠</td></tr><tr><td>蝙蝠</td><td>暹罗猫</td><td>大象</td><td>驼鹿</td><td>座头鲸</td></tr><tr><td>斑马</td><td>犀牛</td><td>兔子</td><td>海象</td><td>大熊猫</td></tr><tr><td>鹿</td><td>德国牧羊犬</td><td>海豚</td><td>大猩猩</td><td>浣熊</td></tr></tbody></table>

The 40 classes of the first four columns are used for training, the 10 classes of the last column (in italics) are the test classes.

前四列的40个类别用于训练，最后一列(斜体)的10个类别为测试类别。

### 3.3 Other Uses of Semantic Attributes

### 3.3 语义属性的其他用途

In parallel to our original work [9], Farhadi et al. [45] introduced the concept of predicting high-level semantic attributes of objects with the objective of being able to describe objects, even if their class membership is unknown.

与我们的原始工作[9]并行，法尔哈迪(Farhadi)等人[45]引入了预测对象高级语义属性的概念，其目标是即使对象的类别归属未知，也能够对其进行描述。

Numerous follow-up papers have explored even more applications of attributes in computer vision tasks, for example, for scene classification [46], face verification [35], action recognition [47], and surveillance [48]. Rohrbach et al. [49] performed an in-depth analysis of attribute-based classification for transfer learning. Kulkarni et al. [50] used attribute predictions in combination with object detection and techniques from natural language processing to automatically create descriptions of images in natural language of images. Attributes have also been suggested as feedback mechanisms to improve image retrieval [51] and categorization [52].

众多后续论文探索了属性在计算机视觉任务中的更多应用，例如，用于场景分类[46]、人脸验证[35]、动作识别[47]和监控[48]。罗尔巴赫(Rohrbach)等人[49]对基于属性的分类进行了深入分析以用于迁移学习。古尔卡尼(Kulkarni)等人[50]将属性预测与对象检测以及自然语言处理技术相结合，以自动用自然语言创建图像描述。属性也被提议作为反馈机制来改进图像检索[51]和分类[52]。

### 3.4 Related Work Outside of Computer Science

### 3.4 计算机科学之外的相关工作

In comparison to computer science, cognitive science research started much earlier to study the relations between object recognition and attributes. Typical questions in the field are how human judgements are influenced by characteristic object attributes [53], [54], and how the human performance in object detection tasks depends on the presence or absence of object properties and contextual cues [55]. Since one of our goals is to integrate human knowledge into a computer vision task, we would like to benefit from the prior work in this field, at least as a source of high-quality data that, so far, cannot be obtained by an automatic process. In the following section, we describe a data set of animal images that allows us to leverage established class-attribute association data from the cognitive science research community. Authorized licensed use limited fo: JILIN UNIVERSITY. Downloaded on March 26,2025 at 13:20:16 UTC from IEEE Xplore. Restrictions apply.

与计算机科学相比，认知科学研究更早开始研究对象识别与属性之间的关系。该领域的典型问题包括人类判断如何受到对象特征属性的影响[53]、[54]，以及人类在对象检测任务中的表现如何取决于对象属性和上下文线索的有无[55]。由于我们的目标之一是将人类知识融入计算机视觉任务，我们希望从该领域的先前工作中受益，至少将其作为高质量数据的来源，到目前为止，这些数据无法通过自动过程获得。在下一节中，我们将描述一个动物图像数据集，该数据集使我们能够利用认知科学研究界已有的类别 - 属性关联数据。授权许可使用仅限于:吉林大学。于2025年3月26日13:20:16 UTC从IEEE Xplore下载。适用限制。

TABLE 2

Eighty-Five Semantic Attributes of the

八十五种语义属性的

Animals with Attributes Data Set in Short Form

动物属性数据集(简写形式)

<table><tr><td>black white blue brown gray orange red yellow patches spots stripes furry hairless big small</td><td>toughskin bulbous lean flippers hands hooves longleg pads paws longneck chewteeth meatteeth buckteeth strainteeth quadrapedal</td><td>tail horns claws tusks smelly flies hops swims tunnels walks fast slow strong weak muscle</td><td>bipedal active inactive nocturnal hibernate agility fish meat plankton vegetation insects forager grazer hunter scavenger</td><td>stalker skimmer cave fierce arctic coastal desert bush plains forest fields jungle tree ocean ground</td><td>mountains water newworld oldworld timid smart group solitary nestspot domestic</td></tr></table>

<table><tbody><tr><td>黑色 白色 蓝色 棕色 灰色 橙色 红色 黄色 斑块 斑点 条纹 有毛的 无毛的 大的 小的</td><td>硬皮 圆胖的 瘦的 鳍状肢 手 蹄 长腿 肉垫 爪子 长颈 咀嚼齿 食肉齿 龅牙 裂齿 四足行走的</td><td>尾巴 角 爪子 獠牙 有臭味的 苍蝇 跳跃 游泳 挖洞 行走 快的 慢的 强壮的 虚弱的 肌肉</td><td>双足行走的 活跃的 不活跃的 夜行性的 冬眠 敏捷 鱼类 肉类 浮游生物 植物 昆虫 觅食者 食草动物 猎手 食腐动物</td><td>潜伏者 掠过者 洞穴 凶猛的 北极的 沿海的 沙漠 灌木丛 平原 森林 田野 丛林 树木 海洋 地面</td><td>山脉 水 新世界 旧世界 胆小的 聪明的 群居的 独居的 巢穴地点 家养的</td></tr></tbody></table>

Longer forms given to human subject for annotation were complete phrases, such as has flippers, eats plankton, or lives in water.

提供给人类受试者进行标注的较长形式是完整的短语，例如“有鳍状肢”、“吃浮游生物”或“生活在水中”。

## 4 The Animals with Attributes (AwA) DATA SET

## 4 动物属性(AwA)数据集

In the early 1990s, Osherson et al. [56] collected judgements from human subjects on the "relative strength of association" between 85 semantic attributes and 48 mammals. Kemp et al. [57] later added two more classes and their attributes for a total of ${50} \times  {85}$ class-attribute associations. ${}^{4}$ The full list of classes and attributes can be found in Tables 1 and 2. Besides the original continuous-valued matrix, also a binary version was created by thresholding the original matrix at its overall mean value; see Fig. 3 for excerpts from both matrices. Note that because of the data collection process, the data are not completely error free. For example, contrary to what is specified in the binary matrix, panda bears do not have buck teeth, and walruses do have tails.

20世纪90年代初，奥舍森(Osherson)等人[56]收集了人类受试者对85种语义属性与48种哺乳动物之间“相对关联强度”的判断。坎普(Kemp)等人[57]后来又增加了两个类别及其属性，总共有${50} \times  {85}$个类别 - 属性关联。${}^{4}$ 完整的类别和属性列表可在表1和表2中找到。除了原始的连续值矩阵外，还通过将原始矩阵在其总体均值处进行阈值处理创建了一个二进制版本；图3展示了两个矩阵的节选。请注意，由于数据收集过程的原因，数据并非完全无误差。例如，与二进制矩阵中规定的情况相反，熊猫没有龅牙，而海象有尾巴。

Our goal in creating the Animals with Attributes data set ${}^{5}$ was to make this attribute-matrix accessible for computer vision experiments. We collected images by querying the image search engines of Google, Microsoft, Yahoo, and Flickr for each of the 50 animals classes. We manually removed outliers and duplicates as well as images in which the target animals were not in prominent enough view to be recognizable. The remaining image set has 30,475 images, where the minimum number of images for any class is 92 (mole) and the maximum is 1,168 (collie). Fig. 1 shows exemplary images and their attribute annotation.

我们创建动物属性数据集${}^{5}$的目标是使这个属性矩阵可用于计算机视觉实验。我们通过在谷歌、微软、雅虎和Flickr的图像搜索引擎中查询50个动物类别中的每一个来收集图像。我们手动移除了离群值、重复项以及目标动物在图像中不够突出难以识别的图像。剩余的图像集有30475张图像，其中任何类别的最少图像数量为92张(鼹鼠)，最多为1168张(柯利犬)。图1展示了示例图像及其属性标注。

To facilitate use by researchers from outside of computer vision, and to increase the reproducibility of results, we provide precomputed feature vectors for all images of the data set. The representations were chosen to reflect different aspects of the images (color, texture, shape), and to allow easy use with off-the-shelf classifiers: HSV color histograms, SIFT [1], rgSIFT [58], PHOG [59], SURF [60], and local self-similarity histograms [61]. The color histograms and PHOG feature vectors are extracted separately for all 21 cells of a three-level spatial pyramids $\left( {1 \times  1,2 \times  2,4 \times  4}\right)$ . For each cell, 128-dimensional color histograms are extracted and concatenated to form a 2,688-dimensional feature vector. For PHOG, the same pyramid is used, but with 12-dimensional base histograms in each cell. The other feature vectors each are bag-of-visual-words histograms obtained from quantizing the original descriptors with 2,000-element codebooks that were obtained by $k$ -means clustering on 250,000 element subsets of the descriptors.

为了方便计算机视觉领域之外的研究人员使用，并提高结果的可重复性，我们为数据集中的所有图像提供了预计算的特征向量。这些表示方式旨在反映图像的不同方面(颜色、纹理、形状)，并便于与现成的分类器一起使用:HSV颜色直方图、SIFT[1]、rgSIFT[58]、PHOG[59]、SURF[60]和局部自相似性直方图[61]。颜色直方图和PHOG特征向量是为三级空间金字塔$\left( {1 \times  1,2 \times  2,4 \times  4}\right)$的所有21个单元分别提取的。对于每个单元，提取128维的颜色直方图并连接起来形成一个2688维的特征向量。对于PHOG，使用相同的金字塔，但每个单元中有12维的基础直方图。其他特征向量都是视觉词袋直方图，这些直方图是通过使用2000元素的码本对原始描述符进行量化得到的，这些码本是通过对描述符的250000元素子集进行$k$ - 均值聚类得到的。

---

4. http://www.psy.cmu.edu/~ckemp/code/irm.html.

4. http://www.psy.cmu.edu/~ckemp/code/irm.html.

5. http://www.ist.ac.at/~chl/AwA/.

5. http://www.ist.ac.at/~chl/AwA/.

---

![0195d2b2-ac8c-7630-a76c-75ecc68f9592_5_103_142_1498_357_0.jpg](images/0195d2b2-ac8c-7630-a76c-75ecc68f9592_5_103_142_1498_357_0.jpg)

Fig. 3. Real-valued (left) and binary-valued (right) class-attribute matrices of the Animals with Attributes data set. Shown are ${13} \times  {33}$ excerpts of the complete ${50} \times  {85}$ matrices.

图3. 动物属性数据集的实值(左)和二进制值(右)类别 - 属性矩阵。展示的是完整${50} \times  {85}$矩阵的${13} \times  {33}$节选。

We define a fixed split of the data set into 40 classes (24,295 images) to be used for training, and 10 classes (6,180 images) to be used for testing; see Table 1. This split was not done randomly, but much of the diversity of the animals in the data set (water/land-based, wild/domestic, etc.) is reflected in the training as well as in the test set of classes. The assignments were based only on the class names and before any experiments were performed, so in particular, the split was not designed for best zero-shot classification performance. Random train-test splits of similar characteristics can be created by fivefold cross validation (CV) over the classes.

我们将数据集固定划分为40个类别(24295张图像)用于训练，10个类别(6180张图像)用于测试；见表1。这种划分不是随机进行的，但数据集中动物的大部分多样性(水生/陆生、野生/家养等)都反映在训练集和测试集中。分配仅基于类别名称，并且是在进行任何实验之前完成的，因此，特别是，这种划分并非为了实现最佳的零样本分类性能而设计。可以通过对类别进行五折交叉验证(CV)来创建具有相似特征的随机训练 - 测试划分。

## 5 Other Data Sets for Attribute-Based CLASSIFICATION

## 5 其他基于属性分类的数据集

Besides the Animals with Attributes data set, we also perform experiments on two other data sets of natural images for which attribute annotations have been released. We briefly summarize their characteristics here. An overview is also provided in Table 3.

除了动物属性数据集之外，我们还对另外两个已发布属性标注的自然图像数据集进行了实验。我们在此简要总结它们的特征。表3也提供了一个概述。

### 5.1 aPascal-aYahoo

### 5.1 aPascal - aYahoo

The aPascal-aYahoo data set ${}^{6}$ was introduced by Farhadi et al. [45]. It consists of a 12,695-image subset of the PASCAL VOC 2008 data set ${}^{7}$ and 2,644 images that were collected using the Yahoo image search engine. The PASCAL part serves as training data, and the Yahoo part as test data. Both sets have disjoint classes (20 classes for PASCAL, 12 for Yahoo), so learning with disjoint training and test classes is unavoidable. Attribute annotation is available on the image level: Each image has been annotated with 64 binary attribute that characterize shape, material, and the presence of important parts of the visible object. As image representation, we rely on the precomputed color, texture, edge orientation, and HoG features that the authors of [45] extracted from the objects' bounding boxes (as provided by the PASCAL VOC annotation) and released as part of the data set.

aPascal - aYahoo数据集${}^{6}$由法尔哈迪(Farhadi)等人[45]引入。它由PASCAL VOC 2008数据集${}^{7}$中的12695张图像子集和使用雅虎(Yahoo)图像搜索引擎收集的2644张图像组成。PASCAL部分用作训练数据，雅虎部分用作测试数据。这两个集合的类别不相交(PASCAL有20个类别，雅虎有12个类别)，因此不可避免地要进行训练和测试类别不相交的学习。属性标注在图像级别可用:每张图像都用64个二元属性进行了标注，这些属性描述了可见对象的形状、材质和重要部分的存在情况。作为图像表示，我们依赖于[45]的作者从对象的边界框(由PASCAL VOC标注提供)中提取并作为数据集一部分发布的预计算颜色、纹理、边缘方向和梯度方向直方图(HoG)特征。

### 5.2 SUN Attributes

### 5.2 SUN属性

The SUN Attributes ${}^{8}$ data set was introduced by Patterson and Hays [46]. It is a subset of the SUN Database [62] for fine-grained scene categorization and consists of 14,340 images from 717 classes (20 images per class). Each image is annotated with 102 binary attributes that describe the scenes' material and surface properties as well as lighting conditions, functions, affordances, and general image layout. For our experiments, we rely on the feature vectors that are provided by the authors of [46] as part of the data set. These consists of GIST, HOG, self-similarity, and geometric color histograms.

SUN属性${}^{8}$数据集由帕特森(Patterson)和海斯(Hays)[46]引入。它是用于细粒度场景分类的SUN数据库[62]的一个子集，由来自717个类别的14340张图像组成(每个类别20张图像)。每张图像都用102个二元属性进行了标注，这些属性描述了场景的材质和表面属性，以及光照条件、功能、可供性和一般图像布局。在我们的实验中，我们依赖于[46]的作者作为数据集一部分提供的特征向量。这些特征向量包括全局特征描述符(GIST)、梯度方向直方图(HOG)、自相似性和几何颜色直方图。

## 6 EXPERIMENTAL EVALUATION

## 6 实验评估

In this section, we perform an experimental evaluation of the DAP and the IAP model on the Animals with Attributes data set as well as the other data sets described above.

在本节中，我们对具有属性的动物数据集以及上述其他数据集上的直接属性预测(DAP)模型和间接属性预测(IAP)模型进行实验评估。

Since our goal is the categorization of classes for which no training samples are available, we always use training and test set with disjoint class structure.

由于我们的目标是对没有训练样本的类别进行分类，因此我们始终使用类别结构不相交的训练集和测试集。

For DAP, we train one nonlinear support vector machine for each binary attributes, ${a}_{1},\ldots ,{a}_{M}$ . In each case, we use 90 percent of the images of the training classes for training, with binary labels for the attribute, which are either obtained from the class-attribute matrix by assigning each image the attribute value of its class, or by per-image attribute annotation, where available. We use the remaining 10 percent of training images to estimate the parameters of a sigmoid curve for Platt scaling, to convert the SVM outputs into probability estimates [63].

对于直接属性预测(DAP)，我们为每个二元属性训练一个非线性支持向量机${a}_{1},\ldots ,{a}_{M}$。在每种情况下，我们使用训练类别的90%的图像进行训练，并使用属性的二元标签，这些标签要么通过为每张图像分配其所属类别的属性值从类别 - 属性矩阵中获得，要么在可用的情况下通过逐图像属性标注获得。我们使用剩余的10%的训练图像来估计用于普拉特缩放(Platt scaling)的S形曲线的参数，以将支持向量机(SVM)的输出转换为概率估计[63]。

At test time, we apply the trained SVMs with Platt scaling to each test image and make test class predictions using (2).

在测试时，我们将经过普拉特缩放的训练好的支持向量机应用于每个测试图像，并使用公式(2)进行测试类别的预测。

For IAP, we train one-versus-rest SVMs for each training class, again using a 90/10 percent split for training of the decision functions, and of the sigmoid coefficients for Platt scaling. At test time, we predict a vector of class probabilities for each test image. We ${L}^{1}$ -normalize this vector such that we can interpret it as a posterior distribution over the training classes. We then use (3) to predict attribute values, from which we obtain test class predictions by (2) as above. 8. http://cs.brown.edu/~gen/sunattributes.html.

对于间接属性预测(IAP)，我们为每个训练类别训练一对多的支持向量机，同样使用90/10的比例来训练决策函数和用于普拉特缩放的S形系数。在测试时，我们为每个测试图像预测一个类别概率向量。我们对这个向量进行${L}^{1}$归一化，以便将其解释为训练类别上的后验分布。然后，我们使用公式(3)预测属性值，并通过上述公式(2)从中获得测试类别的预测。8. http://cs.brown.edu/~gen/sunattributes.html。

TABLE 3

Characteristics of Data Sets with Attribute Annotation: Animals with Attributes [9], aPascal/aYahoo (aP/aY) [45], SUN Attributes (SUN) [46]

带有属性标注的数据集的特征:具有属性的动物数据集[9]、aPascal/aYahoo(aP/aY)数据集[45]、SUN属性(SUN)数据集[46]

<table><tr><td>Dataset</td><td>AwA</td><td>aP/aY</td><td>SUN</td></tr><tr><td>#Images</td><td>30475</td><td>15339</td><td>14340</td></tr><tr><td>#Classes</td><td>50</td><td>32</td><td>717</td></tr><tr><td>#Attributes</td><td>85</td><td>64</td><td>102</td></tr><tr><td>Annotation Level</td><td>per class</td><td>per image</td><td>per image</td></tr><tr><td>Annotation Type (real-</td><td>both</td><td>binary</td><td>binary</td></tr><tr><td>valued or binary)</td><td/><td/><td/></tr></table>

<table><tbody><tr><td>数据集</td><td>AwA</td><td>aP/aY</td><td>SUN</td></tr><tr><td>图像数量</td><td>30475</td><td>15339</td><td>14340</td></tr><tr><td>类别数量</td><td>50</td><td>32</td><td>717</td></tr><tr><td>属性数量</td><td>85</td><td>64</td><td>102</td></tr><tr><td>标注级别</td><td>每类</td><td>每张图像</td><td>每张图像</td></tr><tr><td>标注类型(实值 -</td><td>两者皆有</td><td>二进制</td><td>二进制</td></tr><tr><td>实值或二进制)</td><td></td><td></td><td></td></tr></tbody></table>

### 6.1 SVM Kernels and Model Selection

### 6.1 支持向量机核函数与模型选择

To achieve optimal performance of the SVM classifiers, we use established kernel functions and perform thorough model selection. All SVMs are trained with linearly combined ${\chi }^{2}$ -kernels: For any $D$ -dimensional feature vectors, $h\left( x\right)  \in$ ${\mathbb{R}}^{D}$ and $h\left( \bar{x}\right)  \in  {\mathbb{R}}^{D}$ , of images $x$ and $\bar{x}$ , we set $k\left( {x,\bar{x}}\right)  =$ $\exp \left( {-\gamma {\chi }^{2}\left( {h\left( x\right) , h\left( \bar{x}\right) }\right) }\right)$ with ${\chi }^{2}\left( {h,\bar{h}}\right)  = \mathop{\sum }\limits_{{i = 1}}^{D}\frac{{\left( {h}_{i} - {\bar{h}}_{i}\right) }^{2}}{{h}_{i} + {h}_{i}}$ . For DAP, the bandwidth parameter $\gamma$ is selected in the following way: For each attribute, we perform fivefold cross validation, computing the receiver operating characteristic (ROC) curve of each predictor and averaging the areas under the curves (AUCs) over the attributes. The result is a single mean attrAUC score for any value of the bandwidth. We perform this estimation for $\bar{\gamma } = {c\gamma } \in  \{ {0.01},{0.03},{0.1},{0.3},1,3,{10}\}$ , where $c = \frac{1}{{n}^{2}}\mathop{\sum }\limits_{{i, j = 1}}^{n}{\chi }^{2}\left( {h\left( {x}_{i}\right) , h\left( {x}_{j}\right) }\right)$ , i.e., we parameterize $\gamma$ relative to the average ${\chi }^{2}$ -distance of all points in the training set. $\bar{\gamma } = 3$ was consistently found as best value.

为实现支持向量机(SVM)分类器的最优性能，我们采用已有的核函数并进行全面的模型选择。所有支持向量机均使用线性组合的${\chi }^{2}$核进行训练:对于图像$x$和$\bar{x}$的任意$D$维特征向量$h\left( x\right)  \in$ ${\mathbb{R}}^{D}$和$h\left( \bar{x}\right)  \in  {\mathbb{R}}^{D}$，我们设定$k\left( {x,\bar{x}}\right)  =$ $\exp \left( {-\gamma {\chi }^{2}\left( {h\left( x\right) , h\left( \bar{x}\right) }\right) }\right)$，其中${\chi }^{2}\left( {h,\bar{h}}\right)  = \mathop{\sum }\limits_{{i = 1}}^{D}\frac{{\left( {h}_{i} - {\bar{h}}_{i}\right) }^{2}}{{h}_{i} + {h}_{i}}$。对于判别式属性预测(DAP)，带宽参数$\gamma$按以下方式选择:对于每个属性，我们进行五折交叉验证，计算每个预测器的受试者工作特征(ROC)曲线，并对各属性的曲线下面积(AUC)求平均值。对于任意带宽值，结果是一个单一的平均属性AUC得分。我们对$\bar{\gamma } = {c\gamma } \in  \{ {0.01},{0.03},{0.1},{0.3},1,3,{10}\}$进行此估计，其中$c = \frac{1}{{n}^{2}}\mathop{\sum }\limits_{{i, j = 1}}^{n}{\chi }^{2}\left( {h\left( {x}_{i}\right) , h\left( {x}_{j}\right) }\right)$，即我们相对于训练集中所有点的平均${\chi }^{2}$距离对$\gamma$进行参数化。$\bar{\gamma } = 3$始终被认为是最佳值。

Given $L$ different feature functions, ${h}_{1},\ldots ,{h}_{K}$ , we obtain $L$ kernel functions ${k}_{1},\ldots ,{k}_{L}$ , and we use their unnormalized sum as the final SVM kernel, $k\left( {x,\bar{x}}\right)  = \mathop{\sum }\limits_{{l = 1}}^{L}{k}_{l}\left( {x,\bar{x}}\right)$ . Once we fixed the kernel, we identify the SVMs $C$ parameter among the values $\{ {0.01},{0.03},{0.1},\ldots ,{30},{100},3,{000},1,{000}\}$ in an analogous procedure. We perform fivefold cross validation for each attribute, and we pick $C$ that achieves the highest mean attrAUC. Note that we use the same $C$ values for all attribute classifiers. Technically, this would not be necessary, but we prefer it to avoid large scaling differences between the SVM outputs of different attribute predictors. Also, one can expect the optimal $C$ values to not vary strongly between different attributes, because all classifiers use the same kernel matrix and differ only in their label annotation.

给定$L$个不同的特征函数${h}_{1},\ldots ,{h}_{K}$，我们得到$L$个核函数${k}_{1},\ldots ,{k}_{L}$，并使用它们的未归一化和作为最终的支持向量机核$k\left( {x,\bar{x}}\right)  = \mathop{\sum }\limits_{{l = 1}}^{L}{k}_{l}\left( {x,\bar{x}}\right)$。一旦确定了核函数，我们以类似的过程在值$\{ {0.01},{0.03},{0.1},\ldots ,{30},{100},3,{000},1,{000}\}$中确定支持向量机的$C$参数。我们对每个属性进行五折交叉验证，并选择能实现最高平均属性AUC的$C$。请注意，我们对所有属性分类器使用相同的$C$值。从技术上讲，这并非必要，但我们更倾向于此，以避免不同属性预测器的支持向量机输出之间出现较大的尺度差异。此外，可以预期不同属性的最优$C$值不会有太大变化，因为所有分类器使用相同的核矩阵，仅在标签注释上有所不同。

For IAP, we use the same kernel as for DAP and determine $C$ using fivefold cross validation similar to the procedure one described above, except that we use the mean area under the ROC curve of class predictions (mean classAUC) as selection criterion.

对于图像属性预测(IAP)，我们使用与判别式属性预测(DAP)相同的核函数，并使用类似于上述过程的五折交叉验证来确定$C$，不同之处在于我们使用类别预测的ROC曲线下的平均面积(平均类别AUC)作为选择标准。

### 6.2 Results

### 6.2 结果

We use the above-described procedures to train DAP and IAP models for all data sets. For DAP, where applicable, we use both per-image or per-class annotation to find out whether the time-consuming per-image annotation is necessary. For the data set with per-image attribute annotation, we create class-attribute matrices by averaging all attribute vectors of each class and thresholding the resulting real-valued matrix at its global mean value. Besides experiments with fixed train/test splits of classes, we also perform experiments with random class split using fivefold cross validation for Animals with Attributes (i.e., 40 training classes, 10 test classes), and 10 -fold cross validation for SUN Attributes (approximately ${637} \pm  1$ classes for training and ${70} \pm  1$ classes for testing). We measure the quality of the prediction steps in terms of normalized multiclass accuracy (MC acc.) on the test set (the mean of the diagonal of the confusion matrix). We also report areas under the ROC curve for each test class $z$ and attribute $a$ , when their posterior probabilities $p\left( {z \mid  x}\right)$ and $p\left( {a \mid  x}\right)$ , respectively, are treated as ranking measures over all test images.

我们使用上述程序为所有数据集训练直接属性预测(DAP)和间接属性预测(IAP)模型。对于DAP，在适用的情况下，我们同时使用逐图像或逐类别注释，以确定耗时的逐图像注释是否必要。对于具有逐图像属性注释的数据集，我们通过对每个类别的所有属性向量求平均值，并将所得的实值矩阵在其全局平均值处进行阈值处理，来创建类别 - 属性矩阵。除了使用固定的训练/测试类别划分进行实验外，我们还对“带属性的动物”数据集(Animals with Attributes，即40个训练类别，10个测试类别)使用五折交叉验证，对“太阳属性”数据集(SUN Attributes，大约${637} \pm  1$个类别用于训练，${70} \pm  1$个类别用于测试)使用十折交叉验证，进行随机类别划分的实验。我们根据测试集上的归一化多类别准确率(MC acc.，即混淆矩阵对角线的平均值)来衡量预测步骤的质量。当将每个测试类别的后验概率$p\left( {z \mid  x}\right)$和每个属性的后验概率$p\left( {a \mid  x}\right)$分别视为所有测试图像的排序指标时，我们还报告每个测试类别$z$和属性$a$的ROC曲线下面积。

![0195d2b2-ac8c-7630-a76c-75ecc68f9592_6_881_147_738_426_0.jpg](images/0195d2b2-ac8c-7630-a76c-75ecc68f9592_6_881_147_738_426_0.jpg)

Fig. 4. Confusion matrices between 10 test classes of the Animals with Attributes data set. Left: Indirect attribute prediction. Right: Direct attributes prediction.

图4. “带属性的动物”数据集的10个测试类别之间的混淆矩阵。左:间接属性预测。右:直接属性预测。

In the following, we show detailed results for Animals with Attributes and summaries of the results for the other data sets.

接下来，我们展示“带属性的动物”数据集的详细结果以及其他数据集结果的总结。

#### 6.2.1 Results—Animals with Attributes

#### 6.2.1 结果 —— 带属性的动物

The Animals with Attributes data set comes only with per-class annotation, so there are two models to compare: per-class DAP and per-class IAP. Fig. 4 shows the resulting confusion matrices for both methods. The class-normalized multiclass accuracy can be read off from the mean value of the diagonal as 41.4 percent for DAP and 42.2 percent for IAP. While the results are not as high as a supervised method could achieve, it nevertheless clearly proves our original claim about attribute-based classification: By sharing information via an attribute layer, it is possible to classify images of classes for which we had no training examples. As a baseline, we compare against a zero-shot classifier, where for each test class, we identify the most similar training class and predict using a classifier for it trained on all training data. We use two different methods to define the similarity between the classes' attribute representations: Hamming distance or cross correlation. As it turns out, both variants make almost identical decisions, resulting in multiclass accuracies of 30.7 and 30.8 percent. This is clearly better than chance performance, but below the results of DAP and IAP.

“带属性的动物”数据集仅提供了逐类别注释，因此有两个模型可供比较:逐类别DAP和逐类别IAP。图4显示了这两种方法得到的混淆矩阵。从对角线的平均值可以读出，类别归一化的多类别准确率对于DAP为41.4%，对于IAP为42.2%。虽然这些结果不如有监督方法所能达到的那么高，但它仍然清楚地证明了我们最初关于基于属性的分类的主张:通过属性层共享信息，有可能对我们没有训练示例的类别图像进行分类。作为基线，我们与零样本分类器进行比较，对于每个测试类别，我们找出最相似的训练类别，并使用在所有训练数据上训练的该类别分类器进行预测。我们使用两种不同的方法来定义类别属性表示之间的相似度:汉明距离或互相关。结果表明，这两种变体做出的决策几乎相同，多类别准确率分别为30.7%和30.8%。这明显优于随机猜测的表现，但低于DAP和IAP的结果。

Using random class splits instead of the predefined one, we obtain slightly lower multiclass accuracies of ${34.8}/{44.8}/$ ${34.7}/{35.1}/{36.3}$ percent (average 37.1 percent) for DAP, and ${33.4}/{42.8}/{27.3}/{31.9}/{35.3}$ percent (average 34.1 percent) for IAP. Again, the baselines achieve clearly lower results: ${32.4}/{31.9}/{28.1}/{25.3}/{20.9}$ percent (average 27.7 percent) for the cross-correlation version, and 33.0/29.0/28.4/25.3/ 20.9 percent (average 27.3 percent) for the version based on Hamming distance.

使用随机类别划分而不是预定义的划分，我们得到DAP的多类别准确率略低，为${34.8}/{44.8}/$${34.7}/{35.1}/{36.3}$%(平均37.1%)，IAP为${33.4}/{42.8}/{27.3}/{31.9}/{35.3}$%(平均34.1%)。同样，基线的结果明显更低:互相关版本为${32.4}/{31.9}/{28.1}/{25.3}/{20.9}$%(平均27.7%)，基于汉明距离的版本为33.0/29.0/28.4/25.3/20.9%(平均27.3%)。

TABLE 4

Numeric Results on the Animals with Attributes Data Set in Percent: Multiclass Accuracy for DAP, IAP,

“带属性的动物”数据集的数值结果(百分比):DAP、IAP的多类别准确率

Class-Transfer Classifier Using Cross Correlation (CT-cc) or Hamming Distance (CT-H) of Class Attributes, and Chance Performance (rnd)

使用类别属性的互相关(CT - cc)或汉明距离(CT - H)的类别迁移分类器，以及随机猜测表现(rnd)

(a) default train/test class split

(a) 默认的训练/测试类别划分

<table><tr><td>method</td><td>DAP</td><td>IAP</td><td>CT-cc</td><td>CT-H</td><td>rnd</td></tr><tr><td>MC acc.</td><td>41.4</td><td>42.2</td><td>${30.7} \pm  {0.2}$</td><td>${30.8} \pm  {0.2}$</td><td>10.0</td></tr><tr><td>classAUC</td><td>81.4</td><td>80.0</td><td>73.4</td><td>73.4</td><td>50.0</td></tr><tr><td>attrAUC</td><td>72.8</td><td>72.1</td><td>-</td><td>-</td><td>50.0</td></tr></table>

<table><tbody><tr><td>方法</td><td>直接属性预测(DAP)</td><td>间接属性预测(IAP)</td><td>类别树 - 类别分类(CT - cc)</td><td>类别树 - 层次结构(CT - H)</td><td>随机(rnd)</td></tr><tr><td>蒙特卡罗准确率(MC acc.)</td><td>41.4</td><td>42.2</td><td>${30.7} \pm  {0.2}$</td><td>${30.8} \pm  {0.2}$</td><td>10.0</td></tr><tr><td>类别曲线下面积(classAUC)</td><td>81.4</td><td>80.0</td><td>73.4</td><td>73.4</td><td>50.0</td></tr><tr><td>属性曲线下面积(attrAUC)</td><td>72.8</td><td>72.1</td><td>-</td><td>-</td><td>50.0</td></tr></tbody></table>

(b) five random splits (mean $\pm$ std.dev.)

(b) 五次随机分割(均值 $\pm$ 标准差)

<table><tr><td>method</td><td>DAP</td><td>IAP</td><td>CT-cc</td><td>CT-H</td><td>rnd</td></tr><tr><td>MC acc.</td><td>37.1±3.9</td><td>34.1±5.1</td><td>${27.7} \pm  {4.3}$</td><td>27.3±4.0</td><td>10.0</td></tr><tr><td>classAUC</td><td>${80.4} \pm  {3.1}$</td><td>76.3±5.5</td><td>72.4±2.7</td><td>72.8±3.1</td><td>50.0</td></tr><tr><td>attrAUC</td><td>${70.7} \pm  {3.5}$</td><td>${69.7} \pm  {3.8}$</td><td>-</td><td>-</td><td>50.0</td></tr></table>

<table><tbody><tr><td>方法</td><td>动态属性预测(DAP)</td><td>初始属性预测(IAP)</td><td>基于上下文的对比聚类(CT - cc)</td><td>基于上下文的层次聚类(CT - H)</td><td>随机(rnd)</td></tr><tr><td>蒙特卡罗准确率(MC acc.)</td><td>37.1±3.9</td><td>34.1±5.1</td><td>${27.7} \pm  {4.3}$</td><td>27.3±4.0</td><td>10.0</td></tr><tr><td>类别曲线下面积(classAUC)</td><td>${80.4} \pm  {3.1}$</td><td>76.3±5.5</td><td>72.4±2.7</td><td>72.8±3.1</td><td>50.0</td></tr><tr><td>属性曲线下面积(attrAUC)</td><td>${70.7} \pm  {3.5}$</td><td>${69.7} \pm  {3.8}$</td><td>-</td><td>-</td><td>50.0</td></tr></tbody></table>

The quantitative results for all method are summarized in Table 4. One can see that the differences between the two approaches, DAP and IAP, are relatively small. One might see a slight overall advantage for DAP, but as the large variance between class splits is rather high, this could also be explained by random fluctuations. To avoid redundancy, we give detailed results only for the DAP model in the rest of this section.

所有方法的定量结果总结在表4中。可以看出，两种方法(直接属性预测法(DAP)和间接属性预测法(IAP))之间的差异相对较小。可能会发现DAP总体上略有优势，但由于类别划分之间的方差相当大，这也可能是由随机波动造成的。为避免冗余，在本节的其余部分，我们仅给出DAP模型的详细结果。

Another measure of prediction performance besides multiclass accuracy is how well the predicted posterior probability of any of the test classes can be used to retrieve images of this class from the set of all test images. We evaluate this by plotting the corresponding ROC curves in Fig. 5 and report their AUC. One can see that for all classes, reasonable classifiers have been learned with AUCs clearly higher than the chance level 0.5 . With an AUC of 0.99 , the performance for humpback whale is even on par of what we can expect to achieve with fully supervised learning techniques. Fig. 6 shows the five images with highest posterior score for each test class, therefore allowing to judge the quality of a hypothetical image retrieval system based on (1). One can see that the rankings for humpback whales, leopards, and hippopotamuses are very reliable. Confusions that occur are typically between animals classes with similar characteristics, such as a whale mistaken for a seal, or a racoon mistaken for a rat.

除多类别准确率之外，预测性能的另一个衡量指标是，任何测试类别的预测后验概率能在多大程度上用于从所有测试图像集中检索该类别的图像。我们通过在图5中绘制相应的受试者工作特征(ROC)曲线来评估这一点，并报告其曲线下面积(AUC)。可以看到，对于所有类别，都学习到了合理的分类器，其AUC明显高于随机水平0.5。座头鲸的AUC为0.99，其性能甚至与我们使用全监督学习技术所能达到的水平相当。图6显示了每个测试类别中后验得分最高的五张图像，因此可以据此判断基于公式(1)的假设图像检索系统的质量。可以看到，座头鲸、豹和河马的排名非常可靠。出现的混淆通常发生在具有相似特征的动物类别之间，例如，鲸鱼被误认为海豹，或者浣熊被误认为老鼠。

![0195d2b2-ac8c-7630-a76c-75ecc68f9592_7_891_147_710_390_0.jpg](images/0195d2b2-ac8c-7630-a76c-75ecc68f9592_7_891_147_710_390_0.jpg)

Fig. 5. Retrieval performance of attribute-based classification (DAP method): ROC curves and area under curve for the 10 Animals with Attributes test classes.

图5. 基于属性的分类(DAP方法)的检索性能:10个动物属性测试类别的ROC曲线和曲线下面积。

Because all classifiers base their decisions on the same learned attribute classifiers, one can presume that the easier classes are characterized either by more distinctive attribute vectors or by attributes that are easier to learn from visual data. We believe that the first explanation is not correct, since the matrix of pairwise distances between attribute vectors does not resemble the confusion matrices in Table 4.

由于所有分类器都基于相同的学习属性分类器做出决策，因此可以推测，较容易分类的类别要么具有更独特的属性向量，要么具有更容易从视觉数据中学习的属性。我们认为第一种解释是不正确的，因为属性向量之间的成对距离矩阵与表4中的混淆矩阵并不相似。

We, therefore, analyze the quality of the individual attribute predictors in more detail. Fig. 7 summarizes their quality in terms of the area under the ROC curve (attrAUC). Missing entries indicate that all images in the test set coincided in their value for this attribute, so no ROC curve can be computed. Fig. 8 shows, for a selection of attributes, the five images of highest posterior score within the test set.

因此，我们更详细地分析各个属性预测器的质量。图7根据ROC曲线下面积(attrAUC)总结了它们的质量。缺失的条目表示测试集中所有图像在该属性上的值都相同，因此无法计算ROC曲线。图8显示了对于选定的属性，测试集中后验得分最高的五张图像。

![0195d2b2-ac8c-7630-a76c-75ecc68f9592_7_106_1446_1493_732_0.jpg](images/0195d2b2-ac8c-7630-a76c-75ecc68f9592_7_106_1446_1493_732_0.jpg)

Fig. 6. Highest ranking results for each test class in the Animals with Attributes data set. Classes with unique characteristics are identified well, for example, humpback whales and leopards. Confusions occur between visually similar categories, for example, pigs and hippopotamuses. Authorized licensed use limited to: JILIN UNIVERSITY. Downloaded on March 26,2025 at 13:20:16 UTC from IEEE Xplore. Restrictions apply.

图6. 动物属性数据集中每个测试类别的最高排名结果。具有独特特征的类别识别效果良好，例如座头鲸和豹。视觉上相似的类别之间会出现混淆，例如猪和河马。授权许可使用仅限于:吉林大学。于2025年3月26日13:20:16 UTC从IEEE Xplore下载。适用限制条款。

![0195d2b2-ac8c-7630-a76c-75ecc68f9592_8_105_142_1498_395_0.jpg](images/0195d2b2-ac8c-7630-a76c-75ecc68f9592_8_105_142_1498_395_0.jpg)

Fig. 7. Quality of individual attribute predictors (trained on train classes, tested on test classes), as measured by the area under the ROC curve. Attributes without entries have constant values for all test classes, so their ROC curve cannot be computed.

图7. 各个属性预测器的质量(在训练类别上训练，在测试类别上测试)，通过ROC曲线下面积衡量。没有条目的属性在所有测试类别中具有恒定值，因此无法计算其ROC曲线。

On average, attributes can be predicted clearly better than random (the average AUC is 72.4 percent, whereas random prediction would have 50 percent). However, the variance within the predictions is large, ranging from near perfect prediction, for example, for is yellow and eats plankton, to essentially random performance, for example, on has buckteeth or is timid. Contrary to what one might expect, attributes that refer to visual properties are not automatically predicted more accurately than others. For example, is blue is identified reliably, but is brown is not. Overall good performance is also achieved on several attributes that describe body parts, such as has paws, or the natural habitat lives in trees, and even on nonvisual properties like, such as, is smelly. There are two explanations for this effect: On the one hand, attributes that are clearly visual, such as colors, can still be hard to predict from a global image representation because they typically reflect information that is localized within only the object region. On the other hand, nonvisual attributes can often still be predicted from image information because they occur correlated with visual properties, for example, characteristic texture. It is known that the integration of such contextual information can improve the accuracy of visual classifiers, for example, road regions helps the detection of cars. However, it remains to be seen if this effect will be sufficient for purely nonvisual attributes, or whether it would be better in the long run to replace nonvisual attributes by the visual counterparts they are correlated with.

平均而言，属性的预测效果明显优于随机预测(平均AUC为72.4%，而随机预测的AUC为50%)。然而，预测结果的方差很大，从近乎完美的预测(例如，“是黄色的”和“吃浮游生物”)到基本随机的性能(例如，“有龅牙”或“胆小”)。与人们的预期相反，涉及视觉属性的属性并不一定比其他属性预测得更准确。例如，“是蓝色的”能被可靠识别，但“是棕色的”则不能。在描述身体部位的几个属性(如“有爪子”)、自然栖息地(如“生活在树上”)，甚至非视觉属性(如“有臭味”)上也取得了总体良好的性能。这种效果有两个解释:一方面，明显的视觉属性(如颜色)仍然很难从全局图像表示中预测，因为它们通常反映的是仅存在于对象区域内的局部信息。另一方面，非视觉属性通常仍然可以从图像信息中预测，因为它们与视觉属性(如特征纹理)相关。众所周知，整合此类上下文信息可以提高视觉分类器的准确性，例如，道路区域有助于汽车的检测。然而，这种效果对于纯粹的非视觉属性是否足够，或者从长远来看，用与之相关的视觉属性替代非视觉属性是否更好，仍有待观察。

Another interesting observation is that the system learned to correctly predict attributes such as is big and is small, which are ultimately defined only by context. While this is desirable in our setup, where the context is consistent, it also suggests that the learned attribute predictors themselves are context dependent and cannot be expected to generalize to object classes very different from the training classes.

另一个有趣的观察结果是，该系统学会了正确预测诸如“大的”和“小的”等最终仅由上下文定义的属性。虽然在我们上下文一致的设置中这是理想的，但这也表明学习到的属性预测器本身依赖于上下文，不能期望它们能推广到与训练类别非常不同的对象类别。

![0195d2b2-ac8c-7630-a76c-75ecc68f9592_8_109_1418_1486_780_0.jpg](images/0195d2b2-ac8c-7630-a76c-75ecc68f9592_8_109_1418_1486_780_0.jpg)

Fig. 8. Highest ranking results for a selection of attribute predictors (see Section 6.2) learned by DAP on the Animals with Attributes data set. Authorized licensed use limited to: JILIN UNIVERSITY. Downloaded on March 26,2025 at 13:20:16 UTC from IEEE Xplore. Restrictions apply.

图8. DAP在动物属性数据集上学习到的一组属性预测器(参见6.2节)的最高排名结果。授权许可使用仅限于:吉林大学。于2025年3月26日13:20:16 UTC从IEEE Xplore下载。适用限制条款。

TABLE 5

Numeric Results on the aPascal/aYahoo and the SUN Attributes Data Sets in Percent: DAP with Per-Image Annotation (DAP-I), DAP with Per-Class Annotation (DAP-C), IAP, Class-Transfer

aPascal/aYahoo和SUN属性数据集上的数值结果(百分比):带逐图像注释的DAP(DAP - I)、带逐类注释的DAP(DAP - C)、IAP、类别迁移

Classifier (CT-H), and Chance Performance (rnd)

分类器(CT - H)和随机性能(rnd)

(a) aPascal-aYahoo, default train/test split

(a)aPascal - aYahoo，默认训练/测试划分

<table><tr><td>method</td><td>DAP-I</td><td>DAP-C</td><td>IAP</td><td>CT-H</td><td>rnd</td></tr><tr><td>MC acc.</td><td>16.8</td><td>19.1</td><td>16.9</td><td>${16.7} \pm  {0.5}$</td><td>8.3</td></tr><tr><td>classAUC</td><td>76.9</td><td>76.5</td><td>75.4</td><td>64.2</td><td>50.0</td></tr><tr><td>attrAUC</td><td>70.6</td><td>73.7</td><td>73.1</td><td>-</td><td>50.0</td></tr></table>

<table><tbody><tr><td>方法</td><td>动态属性预测 - I(DAP - I)</td><td>动态属性预测 - C(DAP - C)</td><td>增量属性预测(IAP)</td><td>基于上下文的分层方法(CT - H)</td><td>随机(rnd)</td></tr><tr><td>蒙特卡罗准确率(MC acc.)</td><td>16.8</td><td>19.1</td><td>16.9</td><td>${16.7} \pm  {0.5}$</td><td>8.3</td></tr><tr><td>类别曲线下面积(classAUC)</td><td>76.9</td><td>76.5</td><td>75.4</td><td>64.2</td><td>50.0</td></tr><tr><td>属性曲线下面积(attrAUC)</td><td>70.6</td><td>73.7</td><td>73.1</td><td>-</td><td>50.0</td></tr></tbody></table>

(b) SUN Attributes, ten splits (mean±std.dev.)

(b) 太阳属性(SUN Attributes)，十次分割(均值±标准差)

<table><tr><td>method</td><td>DAP-I</td><td>DAP-C</td><td>IAP</td><td>CT-H</td><td>rnd</td></tr><tr><td>MC acc.</td><td>${18.1} \pm  {1.2}$</td><td>${22.2} \pm  {1.6}$</td><td>${18.0} \pm  {1.5}$</td><td>${12.9} \pm  {1.3}$</td><td>1.4</td></tr><tr><td>level2 acc.</td><td>${40.2} \pm  {2.1}$</td><td>${46.6} \pm  {1.7}$</td><td>${41.1} \pm  {2.1}$</td><td>${32.6} \pm  {2.0}$</td><td>6.2</td></tr><tr><td>level1 acc.</td><td>74.2±4.0</td><td>${85.7} \pm  {2.1}$</td><td>${82.1} \pm  {2.5}$</td><td>74.2±2.0</td><td>33.3</td></tr><tr><td>class mAUC</td><td>90.5±0.7</td><td>92.3±0.7</td><td>${87.9} \pm  {0.7}$</td><td>77.1±0.0</td><td>50.0</td></tr><tr><td>attrAUC</td><td>${82.0} \pm  {0.6}$</td><td>${83.9} \pm  {0.8}$</td><td>${82.7} \pm  {0.8}$</td><td>-</td><td>50.0</td></tr></table>

<table><tbody><tr><td>方法</td><td>动态属性预测 - I(DAP - I)</td><td>动态属性预测 - C(DAP - C)</td><td>增量属性预测(IAP)</td><td>对比学习 - H(CT - H)</td><td>随机(rnd)</td></tr><tr><td>蒙特卡罗准确率(MC acc.)</td><td>${18.1} \pm  {1.2}$</td><td>${22.2} \pm  {1.6}$</td><td>${18.0} \pm  {1.5}$</td><td>${12.9} \pm  {1.3}$</td><td>1.4</td></tr><tr><td>二级准确率(level2 acc.)</td><td>${40.2} \pm  {2.1}$</td><td>${46.6} \pm  {1.7}$</td><td>${41.1} \pm  {2.1}$</td><td>${32.6} \pm  {2.0}$</td><td>6.2</td></tr><tr><td>一级准确率(level1 acc.)</td><td>74.2±4.0</td><td>${85.7} \pm  {2.1}$</td><td>${82.1} \pm  {2.5}$</td><td>74.2±2.0</td><td>33.3</td></tr><tr><td>类别平均曲线下面积(class mAUC)</td><td>90.5±0.7</td><td>92.3±0.7</td><td>${87.9} \pm  {0.7}$</td><td>77.1±0.0</td><td>50.0</td></tr><tr><td>属性曲线下面积(attrAUC)</td><td>${82.0} \pm  {0.6}$</td><td>${83.9} \pm  {0.8}$</td><td>${82.7} \pm  {0.8}$</td><td>-</td><td>50.0</td></tr></tbody></table>

#### 6.2.2 Results—Other Data Sets

#### 6.2.2 结果——其他数据集

We performed the same evaluation as for the Animals with Attributes data set also for the other data sets. Since these data sets have per-image attribute annotation in addition to per-class attribute annotation, we obtain results for two variants of DAP: trained with per-image labels and trained with per-class labels. In both cases, test time inference is done with per-class labels, since we still assume that no examples of the test classes are available. As additional baseline, we use the class transferred classifier as in Section 6.2.1. Since both variants perform almost identically, we report only results for the one based on Hamming distance. The results are summarized in Tables 5a and 5b.

我们对其他数据集也进行了与动物属性数据集相同的评估。由于这些数据集除了有每类属性注释外，还有每张图像的属性注释，因此我们得到了判别式属性预测(DAP，Discriminative Attribute Prediction)两种变体的结果:一种是使用每张图像的标签进行训练，另一种是使用每类标签进行训练。在这两种情况下，测试时的推理都使用每类标签，因为我们仍然假设没有测试类的示例可用。作为额外的基线，我们使用了6.2.1节中的类别迁移分类器。由于这两种变体的表现几乎相同，我们仅报告基于汉明距离的那一种的结果。结果总结在表5a和表5b中。

For the SUN data set, we measure the classification performance based on the three-level SUN hierarchy suggested in [62]. At test time, the ground truth label and the predicted class label each corresponds to one path in the hierarchy (or multiple paths, since the hierarchy is not a tree, but a directed acyclic graph). A prediction is considered correct at a certain level, if both paths run through a common node in that level. At the third level, each class is a separate leaf, so level-3 accuracy is identical to the unnormalized multiclass accuracy, which coincides with the diagonal of the confusion matrix in this case, since all classes have the same number of images. However, at levels 1 and 2, semantically similar classes are mapped to the same node, and confusions between these classes are, therefore, disregarded. Note that the values obtained for the SUN data set are not directly comparable to earlier supervised work using these data. Because we split the data into disjoint train (90 percent) and test classes (10 percent), fewer classes of the data set are present at test time.

对于SUN数据集，我们根据文献[62]中提出的三级SUN层次结构来衡量分类性能。在测试时，真实标签和预测的类别标签各自对应层次结构中的一条路径(或多条路径，因为该层次结构不是树，而是有向无环图)。如果两条路径在某一层次上经过一个公共节点，则认为该预测在该层次上是正确的。在第三层，每个类别都是一个单独的叶子节点，因此三级准确率与未归一化的多类别准确率相同，在这种情况下，这与混淆矩阵的对角线一致，因为所有类别具有相同数量的图像。然而，在第一层和第二层，语义相似的类别被映射到同一个节点，因此这些类别之间的混淆被忽略。请注意，从SUN数据集获得的值与早期使用这些数据的有监督工作的结果不能直接比较。因为我们将数据划分为不相交的训练类(90%)和测试类(10%)，所以在测试时数据集中的类别更少。

The results for both data sets confirm our observations from the Animals with Attributes data set. DAP (both variants) as well as IAP achieves far better than random performance in terms of multiclass accuracy, mean per-class AUC, and mean per-attribute AUC, and also better than the Hamming distance-based baseline classifier.

两个数据集的结果证实了我们从动物属性数据集得到的观察结果。判别式属性预测(两种变体)以及归纳式属性预测(IAP，Inductive Attribute Prediction)在多类别准确率、平均每类曲线下面积(AUC，Area Under the Curve)和平均每属性曲线下面积方面的表现都远好于随机预测，并且也优于基于汉明距离的基线分类器。

A more surprising observation is that per-image attribute annotation, as it is available for the aPascal and SUN Attributes data sets, does not improve the prediction accuracy compared to the per-class annotation, which is much easier to create. We currently do not have Authorized licensed use limited to: JILIN UNIVERSITY. Downloaded on March 26,2025 at 13:20:16 UTC from IEEE Xplore. Restrictions apply. a definite explanation for this. However, two additional observations suggest that the reason might be a bias-variance effect: First, per-image attribute annotation does not follow class boundaries, so its mutual information of the ground truth attribute annotation with the class labels is lower than for per-class annotation (see Table 6). Second, the visual learning tasks defined by per-image annotation do not seem easier learnable than the per-class counterparts, as indicated by the reduced mean attribute AUC in Tables $4,5\mathrm{a}$ , and $5\mathrm{\;b}$ . Likely this is because per-class annotation is correlated with many other visual properties in the images and therefore often easy to predict, whereas per-image annotation singles out the actual attribute in question.

一个更令人惊讶的观察结果是，对于aPascal和SUN属性数据集可用的每张图像的属性注释，与更容易创建的每类注释相比，并没有提高预测准确率。目前我们没有明确的解释。然而，另外两个观察结果表明原因可能是偏差 - 方差效应:首先，每张图像的属性注释不遵循类别边界，因此其真实属性注释与类别标签的互信息低于每类注释(见表6)。其次，由每张图像注释定义的视觉学习任务似乎并不比每类注释对应的任务更容易学习，如表$4,5\mathrm{a}$和表$5\mathrm{\;b}$中平均属性曲线下面积的降低所示。这可能是因为每类注释与图像中的许多其他视觉属性相关，因此通常容易预测，而每张图像的注释则突出了所讨论的实际属性。

TABLE 6

Mean Mutual Information between Individual Attributes and Class Labels with Per-Class or Per-Image Annotation

每类或每张图像注释下单个属性与类别标签之间的平均互信息

<table><tr><td>Dataset</td><td>per class</td><td>per image</td></tr><tr><td>Animals with Attributes</td><td>0.736</td><td>-</td></tr><tr><td>aPascal-aYahoo</td><td>0.532</td><td>0.245</td></tr><tr><td>SUN Attributes</td><td>0.671</td><td>0.211</td></tr></table>

<table><tbody><tr><td>数据集</td><td>每类</td><td>每张图像</td></tr><tr><td>带属性的动物数据集(Animals with Attributes)</td><td>0.736</td><td>-</td></tr><tr><td>aPascal - aYahoo</td><td>0.532</td><td>0.245</td></tr><tr><td>太阳属性数据集(SUN Attributes)</td><td>0.671</td><td>0.211</td></tr></tbody></table>

In combination, we expect the per-image annotation to lead to less bias in the training problem, therefore having the potential for better attribute classifiers given enough data. However, because of the harder learning problem, the resulting classifiers have higher variance when trained on a fixed amount of data. We take the results as a sign that the second effect is currently the dominant source of errors. We plan to explore this hypothesis in future work by studying the learning curves of attribute learning with per-class and per-image annotation for varying amounts of training data.

综合来看，我们预计逐图像标注(per - image annotation)会减少训练问题中的偏差，因此在有足够数据的情况下，有可能得到更好的属性分类器。然而，由于学习问题更具挑战性，当在固定数量的数据上进行训练时，得到的分类器具有更高的方差。我们将这些结果视为目前第二种效应是主要误差来源的一个迹象。我们计划在未来的工作中，通过研究使用逐类标注(per - class annotation)和逐图像标注对不同数量的训练数据进行属性学习的学习曲线，来探索这一假设。

There is also a second, more empirical, explanation: Per-class training of attribute classifiers resembles recent work on discriminatively learned image representations, such as classemes [64]. These have been found to work well for image categorization tasks, even for categories that are not part of the classemes set. A similar effect might hold for per-class trained attribute representations: Even if their interpretation as semantic image properties is not as straightforward as for classifiers trained with per-image annotation, they might simply lead to a good image representation.

还有第二种更具实证性的解释:属性分类器的逐类训练(per - class training)类似于最近关于判别式学习图像表示的工作，例如类元(classemes)[64]。人们发现这些方法在图像分类任务中表现良好，即使对于不属于类元集合的类别也是如此。类似的效果可能也适用于逐类训练的属性表示:即使它们作为语义图像属性的解释不像使用逐图像标注训练的分类器那样直接，但它们可能只是会产生一种良好的图像表示。

#### 6.2.3 Comparison to the Supervised Setup

#### 6.2.3 与有监督设置的比较

Besides the relative comparison of the different methods to each other, we also try to highlight how DAP and IAP perform on an absolute scale. We, therefore, compare our method to ordinary multiclass classification with a small number of training examples. For each test class, we randomly pick a fixed number of training examples and use them to train a one-versus-rest multiclass SVM, which we evaluate using the remaining images of the test classes. The kernel function and parameters are the same as for the IAP model. Fig. 7 summarizes the results in form of the mean over 10 such splits. For an easier comparison, we also repeat the range of values that zero-shot with DAP or IAP achieved (see Tables 4, 5a, and 5b).

除了对不同方法进行相对比较之外，我们还试图强调 DAP 和 IAP 在绝对尺度上的表现。因此，我们将我们的方法与使用少量训练示例的普通多类分类进行比较。对于每个测试类别，我们随机选择固定数量的训练示例，并使用它们来训练一个一对多的多类支持向量机(SVM)，我们使用测试类别的其余图像对其进行评估。核函数和参数与 IAP 模型相同。图 7 以 10 次这样的分割的平均值的形式总结了结果。为了便于比较，我们还重复列出了使用 DAP 或 IAP 进行零样本学习所达到的值的范围(见表 4、表 5a 和表 5b)。

By comparing the last column to the others, one sees that on the Animals with Attributes data set, attribute-based classification achieves results on par with supervised training with 10-15 training examples per test class, i.e., 100- 150 training images in total. On the aPascal, the attribute representations perform worse. Their results are comparable to supervised training with at most one example per class, if judged by multiclass accuracy, and two to three examples per class, if judged by mean classAUC. On the SUN data set, approximately two examples per class (142 total) are necessary for equal mean class accuracy, and 5-10 examples per class (355 to 710 total) for equal mean AUC. Note, however, that all the above comparisons may overestimate the power of the supervised classifiers: In a realistic setup with so few training examples, model selection is problematic, whereas to create Table 7, we just reused the parameters obtained by thorough model selection for the IAP model.

通过将最后一列与其他列进行比较，可以看出，在“Animals with Attributes”数据集上，基于属性的分类所取得的结果与每个测试类别使用 10 - 15 个训练示例(即总共 100 - 150 个训练图像)的有监督训练相当。在 aPascal 数据集上，属性表示的表现较差。如果以多类准确率来评判，它们的结果与每个类别最多使用一个示例的有监督训练相当；如果以平均类别 AUC 来评判，则与每个类别使用两到三个示例的有监督训练相当。在 SUN 数据集上，要达到相同的平均类别准确率，每个类别大约需要两个示例(总共 142 个)；要达到相同的平均 AUC，每个类别需要 5 - 10 个示例(总共 355 到 710 个)。然而，需要注意的是，上述所有比较可能高估了有监督分类器的能力:在训练示例如此少的现实设置中，模型选择是有问题的，而在创建表 7 时，我们只是重复使用了通过对 IAP 模型进行全面模型选择而获得的参数。

TABLE 7

Numeric Results of One-versus-Rest Multiclass SVMs Trained with $n \in  \{ 1,2,3,4,5,{10},{15},{20}\}$ Training Examples from

使用来自每个测试类别的 $n \in  \{ 1,2,3,4,5,{10},{15},{20}\}$ 个训练示例训练的一对多多类支持向量机的数值结果

Each Test Class in Comparison to the Results Achieved by Zero-Shot Learning with DAP and IAP (in Percent)

与使用 DAP 和 IAP 进行零样本学习所取得的结果的比较(百分比)

(a) mean class accuracy (b) mean classAUC

(a) 平均类别准确率 (b) 平均类别 AUC

<table><tr><td/><td>$n = 1$</td><td>2</td><td>3</td><td>4</td><td>5</td><td>10</td><td>15</td><td>20</td><td>zero-shot</td></tr><tr><td>AwA (def.)</td><td>23.6</td><td>26.2</td><td>29.9</td><td>32.7</td><td>34.0</td><td>39.9</td><td>42.9</td><td>45.4</td><td>41.4-42.2</td></tr><tr><td>AwA (5-CV)</td><td>20.1</td><td>23.4</td><td>26.3</td><td>27.7</td><td>29.7</td><td>35.7</td><td>39.8</td><td>40.6</td><td>34.1-37.1</td></tr><tr><td>aP/aY</td><td>22.6</td><td>29.6</td><td>33.9</td><td>38.1</td><td>40.0</td><td>48.5</td><td>50.7</td><td>57.1</td><td>16.9-19.1</td></tr><tr><td>SUN</td><td>13.1</td><td>18.6</td><td>22.7</td><td>25.8</td><td>28.5</td><td>36.8</td><td>-</td><td>-</td><td>18.0-22.2</td></tr></table>

<table><tbody><tr><td></td><td>$n = 1$</td><td>2</td><td>3</td><td>4</td><td>5</td><td>10</td><td>15</td><td>20</td><td>零样本(zero-shot)</td></tr><tr><td>动物属性数据集(AwA)(定义)</td><td>23.6</td><td>26.2</td><td>29.9</td><td>32.7</td><td>34.0</td><td>39.9</td><td>42.9</td><td>45.4</td><td>41.4-42.2</td></tr><tr><td>动物属性数据集(AwA)(五折交叉验证)</td><td>20.1</td><td>23.4</td><td>26.3</td><td>27.7</td><td>29.7</td><td>35.7</td><td>39.8</td><td>40.6</td><td>34.1-37.1</td></tr><tr><td>属性预测值/属性真实值(aP/aY)</td><td>22.6</td><td>29.6</td><td>33.9</td><td>38.1</td><td>40.0</td><td>48.5</td><td>50.7</td><td>57.1</td><td>16.9-19.1</td></tr><tr><td>场景理解数据集(SUN)</td><td>13.1</td><td>18.6</td><td>22.7</td><td>25.8</td><td>28.5</td><td>36.8</td><td>-</td><td>-</td><td>18.0-22.2</td></tr></tbody></table>

<table><tr><td/><td>$n = 1$</td><td>2</td><td>3</td><td>4</td><td>5</td><td>10</td><td>15</td><td>20</td><td>zero-shot</td></tr><tr><td>AwA (def.)</td><td>67.4</td><td>72.4</td><td>74.0</td><td>75.5</td><td>76.6</td><td>81.2</td><td>82.6</td><td>84.1</td><td>80.0-81.4</td></tr><tr><td>AwA (5-CV)</td><td>63.8</td><td>67.0</td><td>69.9</td><td>71.3</td><td>72.7</td><td>77.6</td><td>80.5</td><td>82.1</td><td>76.3-80.4</td></tr><tr><td>aP/aY</td><td>68.7</td><td>74.2</td><td>76.2</td><td>79.3</td><td>80.4</td><td>85.3</td><td>86.0</td><td>89.2</td><td>75.4-76.9</td></tr><tr><td>SUN</td><td>76.9</td><td>82.2</td><td>84.9</td><td>86.9</td><td>88.1</td><td>91.3</td><td>-</td><td>-</td><td>87.9-92.3</td></tr></table>

<table><tbody><tr><td></td><td>$n = 1$</td><td>2</td><td>3</td><td>4</td><td>5</td><td>10</td><td>15</td><td>20</td><td>零样本(zero-shot)</td></tr><tr><td>动物属性数据集(AwA)(定义)</td><td>67.4</td><td>72.4</td><td>74.0</td><td>75.5</td><td>76.6</td><td>81.2</td><td>82.6</td><td>84.1</td><td>80.0-81.4</td></tr><tr><td>动物属性数据集(AwA)(五折交叉验证)</td><td>63.8</td><td>67.0</td><td>69.9</td><td>71.3</td><td>72.7</td><td>77.6</td><td>80.5</td><td>82.1</td><td>76.3-80.4</td></tr><tr><td>属性预测值/属性真实值(aP/aY)</td><td>68.7</td><td>74.2</td><td>76.2</td><td>79.3</td><td>80.4</td><td>85.3</td><td>86.0</td><td>89.2</td><td>75.4-76.9</td></tr><tr><td>场景理解数据集(SUN)</td><td>76.9</td><td>82.2</td><td>84.9</td><td>86.9</td><td>88.1</td><td>91.3</td><td>-</td><td>-</td><td>87.9-92.3</td></tr></tbody></table>

Interpreting the low performance on the aPascal-aYahoo data set, one has to take the background of this data set into account. Its attributes were selected to provide additional information about object classes, not to discriminate between them. While the resulting attribute set is comparably difficult to learn (see Table 5(a)), each attribute on average contains less information about the class labels (see Table 6), mainly because several of the attributes are meaningful only for a small subset of the categories. We conclude from this that attributes that are useful to describe objects from different categories are not automatically also useful to distinguish between the categories, a fact that should be taken into account in the future creation of attribute annotation for image data sets.

在解释aPascal - aYahoo数据集上的低性能时，必须考虑该数据集的背景。其属性的选择是为了提供有关对象类别的额外信息，而不是用于区分它们。虽然由此产生的属性集相对较难学习(见表5(a))，但平均而言，每个属性包含的关于类别标签的信息较少(见表6)，这主要是因为有几个属性仅对一小部分类别有意义。由此我们得出结论，对描述不同类别的对象有用的属性，并不一定对区分这些类别也有用，在未来为图像数据集创建属性注释时应考虑到这一事实。

Overall, we do not think that the experiments we presented are sufficient to make a definite statement about the quality of attribute-based versus supervised classification. However, we believe that the results confirm the intuition that a larger ratio of attributes to classes improves the prediction performance. However, not only the number of attributes matters, but also how informative the chosen attributes are about the classes.

总体而言，我们认为我们所展示的实验不足以对基于属性的分类与有监督分类的质量做出明确的论断。然而，我们相信这些结果证实了一种直觉，即属性与类别的比例越大，预测性能越好。不过，不仅属性的数量很重要，所选属性对于类别所包含的信息量也很重要。

## 7 CONCLUSION

## 7 结论

In this paper, we introduced learning with disjoint training and test classes. It formalizes the problem of learning an object classification systems for classes for which no training images are available. We proposed two methods Authorized licensed use limited to: JILiN UNIVERSITY. Downloaded on March 26,2025 at 13:20:16 UTC from IEEE Xplore. Restrictions apply. for attribute-based classification that solve this problem by transferring information between classes. In both cases, the transfer is achieved by an intermediate representation that consists of high-level semantic attributes that provide a fast and simple way to include human knowledge into the system. To predict the attribute level, we either rely on classifiers trained directly on attribute annotation (DAP), or we infer the attribute layer from classifiers trained to identify other classes (indirect attribute prediction). Once trained, the system can detect new object categories, if a suitable characterization in terms of attributes is available for them, and it does not require retraining.

在本文中，我们介绍了使用不相交的训练和测试类别进行学习的方法。它将为没有可用训练图像的类别学习对象分类系统的问题进行了形式化。我们提出了两种基于属性的分类方法(授权许可使用仅限于:吉林大学。于2025年3月26日13:20:16 UTC从IEEE Xplore下载。适用限制条款)，这些方法通过在类别之间传递信息来解决这个问题。在这两种情况下，信息传递都是通过一种中间表示来实现的，这种中间表示由高级语义属性组成，为将人类知识融入系统提供了一种快速而简单的方法。为了预测属性级别，我们要么依赖直接在属性注释上训练的分类器(直接属性预测，DAP)，要么从为识别其他类别而训练的分类器中推断属性层(间接属性预测)。一旦训练完成，如果对于新的对象类别有合适的基于属性的特征描述，系统就可以检测这些新的对象类别，并且不需要重新训练。

As a second contribution, we introduced the Animals with Attributes data set: It consists of over 30,000 images with precomputed reference features for 50 animal classes, for which a semantic attribute annotation is available that has been used in earlier cognitive science work. We hope that this data set will foster research and serve as a testbed for attribute-based classification.

作为第二项贡献，我们引入了“带属性的动物”(Animals with Attributes)数据集:它包含超过30,000张图像，这些图像为50个动物类别预先计算了参考特征，并且有语义属性注释，这些注释曾在早期的认知科学研究中使用过。我们希望这个数据集能够促进相关研究，并作为基于属性的分类的测试平台。

### 7.1 Open Questions and Future Work

### 7.1 开放问题与未来工作

Despite the promising results of the proposed system, several questions remain open and require future work. For example, the assumption of disjoint training and test classes is clearly artificial. It has been observed, for example, in [65], that existing methods, including DAP and IAP, do not work well if this assumption is violated, since their decisions become biased toward the previously seen classes. In the supervised scenario, methods to overcome this limitation have been suggested, for example, [66], [67], but a unified framework that includes the possibility of zero-shot learning is still missing.

尽管所提出的系统取得了有希望的结果，但仍有几个问题悬而未决，需要未来的研究。例如，训练和测试类别不相交的假设显然是人为设定的。例如，在文献[65]中观察到，如果违反了这个假设，包括直接属性预测(DAP)和间接属性预测(IAP)在内的现有方法效果不佳，因为它们的决策会偏向于之前见过的类别。在有监督的场景中，已经有人提出了克服这一限制的方法，例如文献[66]、[67]，但仍然缺少一个包含零样本学习可能性的统一框架。

A related open problem is how zero-shot learning can be unified with supervised learning when a small number of labeled training examples are available. While some work in this direction exists (see our discussion in Section 3), we believe that it will also be able to extend DAP and IAP for this for purpose. For example, one could make use of their probabilistic formulation to define an attribute-based prior that is combined with a likelihood term derived from the training examples.

一个相关的开放问题是，当有少量带标签的训练示例可用时，如何将零样本学习与有监督学习统一起来。虽然在这个方向上已经有了一些工作(见第3节的讨论)，但我们相信也能够为了这个目的扩展直接属性预测(DAP)和间接属性预测(IAP)方法。例如，可以利用它们的概率公式来定义一个基于属性的先验，该先验与从训练示例中导出的似然项相结合。

Beyond the specific task of multiclass classification, there are many other open questions that will need to be tackled if we want to make true progress in solving the grand tasks of computer vision: How do we handle the problem that many object categories are rare? How can we build object recognition systems that adapt and incorporate new categories that they encounter? How can we integrate human knowledge about the visual world besides specifying training examples? We believe that attribute-based classification will be able to help in answering at least some of these questions.

除了多类别分类的具体任务之外，如果我们想在解决计算机视觉的重大任务上取得真正的进展，还有许多其他开放问题需要解决:我们如何处理许多对象类别很少见的问题？我们如何构建能够适应并纳入新遇到的类别的对象识别系统？除了指定训练示例之外，我们如何整合人类关于视觉世界的知识？我们相信基于属性的分类至少能够帮助回答其中的一些问题。

## ACKNOWLEDGMENTS

## 致谢

This work was in part funded by the European Research Council under the European Union's Seventh Framework Programme (FP7/2007-2013)/ERC grant agreement no 308036. The authors would like to thank Charles Kemp for providing the Osherson/Wilkie class-attribute matrix and Jens Weidmann for his help on creating the Animals with Attributes data set.

这项工作部分由欧洲研究理事会在欧盟第七框架计划(FP7/2007 - 2013)/欧洲研究理事会(ERC)资助协议编号308036下提供资金支持。作者们要感谢查尔斯·坎普(Charles Kemp)提供奥舍森/威尔基(Osherson/Wilkie)类别 - 属性矩阵，以及延斯·魏德曼(Jens Weidmann)在创建“带属性的动物”(Animals with Attributes)数据集方面提供的帮助。

## REFERENCES

## 参考文献

[1] D.G. Lowe, "Distinctive Image Features from Scale-Invariant Keypoints," Int'l J. Computer Vision, vol. 60, no. 2, pp. 91-110, 2004.

[1] D.G. 洛(D.G. Lowe)，“尺度不变关键点的独特图像特征”，《国际计算机视觉杂志》，第60卷，第2期，第91 - 110页，2004年。

[2] N. Dalal and B. Triggs, "Histograms of Oriented Gradients for

[2] N. 达拉尔(N. Dalal)和B. 特里格斯(B. Triggs)，“用于

Human Detection," Proc. IEEE Conf. Computer Vision and Pattern Recognition (CVPR), 2005.

人体检测的方向梯度直方图”，《电气与电子工程师协会计算机视觉与模式识别会议(CVPR)论文集》，2005年。

[3] B. Schölkopf and A.J. Smola, Learning with Kernels. MIT Press, 2002.

[3] B. 肖尔科普夫(B. Schölkopf)和A.J. 斯莫拉(A.J. Smola)，《核方法学习》。麻省理工学院出版社，2002年。

[4] C.H. Lampert, "Kernel Methods in Computer Vision," Foundations and Trends in Computer Graphics and Vision, vol. 4, no. 3, pp. 193- 285, 2009.

[4] C.H. 兰珀特(C.H. Lampert)，《计算机视觉中的核方法》，《计算机图形与视觉基础与趋势》，第4卷，第3期，第193 - 285页，2009年。

[5] R.E. Schapire and Y. Freund, Boosting: Foundations and Algorithms. MIT Press, 2012.

[5] R.E. 沙皮尔(R.E. Schapire)和Y. 弗罗因德(Y. Freund)，《提升算法:基础与算法》，麻省理工学院出版社，2012年。

[6] I. Biederman, "Recognition by Components: A Theory of Human Image Understanding," Psychological Rev., vol. 94, no. 2, pp. 115- 147, 1987.

[6] I. 比德曼(I. Biederman)，《基于组件的识别:人类图像理解理论》，《心理学评论》，第94卷，第2期，第115 - 147页，1987年。

[7] B. Yao, A. Khosla, and L. Fei-Fei, "Combining Randomization and Discrimination for Fine-Grained Image Categorization," Proc. IEEE Conf. Computer Vision and Pattern Recognition (CVPR), 2011.

[7] B. 姚(B. Yao)、A. 科斯拉(A. Khosla)和L. 费菲(L. Fei - Fei)，《结合随机化与判别进行细粒度图像分类》，《电气与电子工程师协会计算机视觉与模式识别会议论文集》(CVPR)，2011年。

[8] G.L. Murphy, The Big Book of Concepts. MIT Press, 2004.

[8] G.L. 墨菲(G.L. Murphy)，《概念大百科》，麻省理工学院出版社，2004年。

[9] C.H. Lampert, H. Nickisch, and S. Harmeling, "Learning to Detect Unseen Object Classes by Between-Class Attribute Transfer," Proc. IEEE Conf. Computer Vision and Pattern Recognition (CVPR), 2009.

[9] C.H. 兰珀特(C.H. Lampert)、H. 尼克施(H. Nickisch)和S. 哈梅林(S. Harmeling)，《通过类间属性转移学习检测未见物体类别》，《电气与电子工程师协会计算机视觉与模式识别会议论文集》(CVPR)，2009年。

[10] D. Parikh and K. Grauman, "Relative Attributes," Proc. IEEE Int'l Conf. Computer Vision (ICCV), 2011.

[10] D. 帕里克(D. Parikh)和K. 格劳曼(K. Grauman)，《相对属性》，《电气与电子工程师协会国际计算机视觉会议论文集》(ICCV)，2011年。

[11] D.E. Knuth, "Two Notes on Notation," Am. Math. Monthly, vol. 99, no. 5, pp. 403-422, 1992.

[11] D.E. 克努斯(D.E. Knuth)，《关于符号的两点注记》，《美国数学月刊》，第99卷，第5期，第403 - 422页，1992年。

[12] D.E. Rumelhart, G.E. Hinton, and R.J. Williams, "Learning Internal Representations by Error Propagation," Parallel Distributed Processing, MIT Press, 1986.

[12] D.E. 鲁梅尔哈特(D.E. Rumelhart)、G.E. 辛顿(G.E. Hinton)和R.J. 威廉姆斯(R.J. Williams)，《通过误差传播学习内部表示》，《并行分布式处理》，麻省理工学院出版社，1986年。

[13] L. Breiman, J.J. Friedman, R.A. Olshen, and C.J. Stone, Classification and Regression Trees. Wadsworth, 1984.

[13] L. 布雷曼(L. Breiman)、J.J. 弗里德曼(J.J. Friedman)、R.A. 奥尔申(R.A. Olshen)和C.J. 斯通(C.J. Stone)，《分类与回归树》，沃兹沃思出版社，1984年。

[14] M.I. Jordan and R.A. Jacobs, "Hierarchical Mixtures of Experts and the EM Algorithm," Neural Computation, vol. 6, no. 2, pp. 181- 214, 1994.

[14] M.I. 乔丹(M.I. Jordan)和R.A. 雅各布斯(R.A. Jacobs)，《专家分层混合模型与期望最大化算法》，《神经计算》，第6卷，第2期，第181 - 214页，1994年。

[15] Y. Freund and R.E. Schapire, "A Decision-Theoretic Generalization of On-Line Learning and an Application to Boosting," J. Computer and System Sciences, vol. 55, no. 1, pp. 119-139, 1997.

[15] Y. 弗罗因德(Y. Freund)和R.E. 沙皮尔(R.E. Schapire)，《在线学习的决策理论推广及其在提升算法中的应用》，《计算机与系统科学杂志》，第55卷，第1期，第119 - 139页，1997年。

[16] T.G. Dietterich and G. Bakiri, "Solving Multiclass Learning Problems via Error-Correcting Output Codes," J. Artificial Intelligence Research, vol. 2, pp. 263-286, 1995.

[16] T.G. 迪特里希(T.G. Dietterich)和G. 巴基里(G. Bakiri)，《通过纠错输出码解决多类学习问题》，《人工智能研究杂志》，第2卷，第263 - 286页，1995年。

[17] R. Rifkin and A. Klautau, "In Defense of One-vs-All Classification," J. Machine Learning Research, vol. 5, pp. 101-141, 2004.

[17] R. 里夫金(R. Rifkin)和A. 克劳陶(A. Klautau)，《为一对多分类辩护》，《机器学习研究杂志》，第5卷，第101 - 141页，2004年。

[18] M. Ranzato, F.J. Huang, Y.-L. Boureau, and Y. LeCun, "Unsupervised Learning of Invariant Feature Hierarchies with Applications to Object Recognition," Proc. IEEE Conf. Computer Vision and Pattern Recognition (CVPR), 2007.

[18] M. 兰扎托(M. Ranzato)、F.J. 黄(F.J. Huang)、Y. - L. 布雷奥(Y. - L. Boureau)和Y. 勒昆(Y. LeCun)，《具有不变特征层次结构的无监督学习及其在物体识别中的应用》，《电气与电子工程师协会计算机视觉与模式识别会议论文集》(CVPR)，2007年。

[19] J. Winn and N. Jojic, "LOCUS: Learning Object Classes with Unsupervised Segmentation," Proc. IEEE Int'l Conf. Computer Vision (ICCV), vol. 1, 2005.

[19] J. 温(J. Winn)和N. 约伊西奇(N. Jojic)，《LOCUS:通过无监督分割学习物体类别》，《电气与电子工程师协会国际计算机视觉会议论文集》(ICCV)，第1卷，2005年。

[20] M.A. Fischler and R.A. Elschlager, "The Representation and Matching of Pictorial Structures," IEEE Trans. Computers, vol. 22, no. 1, pp. 67-92, Jan. 1973.

[20] M.A. 菲施勒(Fischler)和 R.A. 埃尔施拉格(Elschlager)，《图像结构的表示与匹配》，《电气与电子工程师协会计算机汇刊》(IEEE Trans. Computers)，第 22 卷，第 1 期，第 67 - 92 页，1973 年 1 月。

[21] R. Fergus, P. Perona, and A. Zisserman, "Object Class Recognition by Unsupervised Scale-Invariant Learning," Proc. IEEE Conf. Computer Vision and Pattern Recognition (CVPR), 2003.

[21] R. 弗格斯(Fergus)、P. 佩罗纳(Perona)和 A. 齐斯曼(Zisserman)，《通过无监督尺度不变学习进行目标类别识别》，《电气与电子工程师协会计算机视觉与模式识别会议论文集》(Proc. IEEE Conf. Computer Vision and Pattern Recognition (CVPR))，2003 年。

[22] P.F. Felzenszwalb, D. McAllester, and D. Ramanan, "A Discriminatively Trained, Multiscale, Deformable Part Model," Proc. IEEE Conf. Computer Vision and Pattern Recognition (CVPR), 2008.

[22] P.F. 费尔曾斯瓦尔布(Felzenszwalb)、D. 麦卡利斯特(McAllester)和 D. 拉马南(Ramanan)，《一种经过判别式训练的多尺度可变形部件模型》，《电气与电子工程师协会计算机视觉与模式识别会议论文集》(Proc. IEEE Conf. Computer Vision and Pattern Recognition (CVPR))，2008 年。

[23] J.C. Platt, N. Cristianini, and J. Shawe-Taylor, "Large Margin DAGs for Multiclass Classification," Proc. Advances in Neural Information Processing Systems (NIPS), 1999.

[23] J.C. 普拉特(Platt)、N. 克里斯蒂亚尼尼(Cristianini)和 J. 肖韦 - 泰勒(Shawe - Taylor)，《用于多类分类的大间隔有向无环图》，《神经信息处理系统进展会议论文集》(Proc. Advances in Neural Information Processing Systems (NIPS))，1999 年。

[24] A. Torralba and K.P. Murphy, "Sharing Visual Features for Multiclass and Multiview Object Detection," IEEE Trans. Pattern Analysis and Machine Intelligence, vol. 29, no. 5, pp. 854-869, May 2007.

[24] A. 托拉尔巴(Torralba)和 K.P. 墨菲(Murphy)，《用于多类和多视图目标检测的视觉特征共享》，《电气与电子工程师协会模式分析与机器智能汇刊》(IEEE Trans. Pattern Analysis and Machine Intelligence)，第 29 卷，第 5 期，第 854 - 869 页，2007 年 5 月。

[25] P. Zehnder, E.K. Meier, and L.J.V. Gool, "An Efficient Shared Multi-Class Detection Cascade," Proc. British Machine Vision Conf. (BMVC), 2008.

[25] P. 曾德(Zehnder)、E.K. 迈尔(Meier)和 L.J.V. 古尔(Gool)，《一种高效的共享多类检测级联》，《英国机器视觉会议论文集》(Proc. British Machine Vision Conf. (BMVC))，2008 年。

[26] E. Miller, N. Matsakis, and P. Viola, "Learning from One Example through Shared Densities on Transforms," Proc. IEEE Conf. Computer Vision and Pattern Recognition (CVPR), 2000.

[26] E. 米勒(Miller)、N. 马塔斯基斯(Matsakis)和 P. 维奥拉(Viola)，《通过变换上的共享密度从单个示例中学习》，《电气与电子工程师协会计算机视觉与模式识别会议论文集》(Proc. IEEE Conf. Computer Vision and Pattern Recognition (CVPR))，2000 年。

[27] F.F. Li, R. Fergus, and P. Perona, "One-Shot Learning of Object Categories," IEEE Trans. Pattern Analysis and Machine Intelligence, vol. 28, no. 4, pp. 594-611, Apr. 2006.

[27] F.F. 李(Li)、R. 弗格斯(Fergus)和 P. 佩罗纳(Perona)，《目标类别的一次性学习》，《电气与电子工程师协会模式分析与机器智能汇刊》(IEEE Trans. Pattern Analysis and Machine Intelligence)，第 28 卷，第 4 期，第 594 - 611 页，2006 年 4 月。

[28] E. Bart and S. Ullman, "Cross-Generalization: Learning Novel Classes from a Single Example by Feature Replacement," Proc. IEEE Conf. Computer Vision and Pattern Recognition (CVPR), 2005.

[28] E. 巴特(Bart)和 S. 厄尔曼(Ullman)，《交叉泛化:通过特征替换从单个示例中学习新类别》，《电气与电子工程师协会计算机视觉与模式识别会议论文集》(Proc. IEEE Conf. Computer Vision and Pattern Recognition (CVPR))，2005 年。

[29] H. Larochelle, D. Erhan, and Y. Bengio, "Zero-Data Learning of New Tasks," Proc. 23rd Nat'l Conf. Artificial Intelligence, vol. 1, no. 2, pp. 646-651, 2008.

[29] H. 拉罗谢尔(Larochelle)、D. 埃尔汗(Erhan)和 Y. 本吉奥(Bengio)，《新任务的零数据学习》，《第 23 届全国人工智能会议论文集》(Proc. 23rd Nat'l Conf. Artificial Intelligence)，第 1 卷，第 2 期，第 646 - 651 页，2008 年。

[30] K. Yanai and K. Barnard, "Image Region Entropy: A Measure of

[30] K. 矢内(Yanai)和 K. 巴纳德(Barnard)，《图像区域熵:一种衡量

Visualness of Web Images Associated with One Concept," Proc. 13th Ann. ACM Int'l Conf. Multimedia, pp. 419-422, 2005.

与一个概念相关的网络图像视觉性的指标》，《第 13 届年度美国计算机协会国际多媒体会议论文集》(Proc. 13th Ann. ACM Int'l Conf. Multimedia)，第 419 - 422 页，2005 年。

[31] J. Van De Weijer, C. Schmid, J. Verbeek, and D. Larlus, "Learning Color Names for Real-World Applications," IEEE Trans. Image Processing, vol. 18, no. 7, pp. 1512-1523, July 2009.

[31] J. 范德韦杰尔(Van De Weijer)、C. 施密德(Schmid)、J. 韦贝克(Verbeek)和 D. 拉卢斯(Larlus)，《为现实世界应用学习颜色名称》，《电气与电子工程师协会图像处理汇刊》(IEEE Trans. Image Processing)，第 18 卷，第 7 期，第 1512 - 1523 页，2009 年 7 月。

[32] V. Ferrari and A. Zisserman, "Learning Visual Attributes," Proc. Advances in Neural Information Processing Systems (NIPS), 2008.

[32] V. 法拉利(Ferrari)和 A. 齐斯曼(Zisserman)，《学习视觉属性》，《神经信息处理系统进展会议论文集》(Proc. Advances in Neural Information Processing Systems (NIPS))，2008 年。

[33] A.F. Smeaton, P. Over, and W. Kraaij, "Evaluation Campaigns and TRECVid," Proc. Eighth ACM Int'l Workshop Multimedia Information Retrieval, 2006.

[33] A.F. 斯米顿(Smeaton)、P. 奥弗(Over)和 W. 克拉伊杰(Kraaij)，《评估活动与视频检索评测(TRECVid)》，《第 8 届美国计算机协会国际多媒体信息检索研讨会论文集》(Proc. Eighth ACM Int'l Workshop Multimedia Information Retrieval)，2006 年。

[34] N. Kumar, P.N. Belhumeur, and S.K. Nayar, "Facetracer: A Search Engine for Large Collections of Images with Faces," Proc. European Conf. Computer Vision (ECCV), 2008.

[34] N. 库马尔(Kumar)、P.N. 贝尔休默尔(Belhumeur)和 S.K. 纳亚尔(Nayar)，《面部追踪器:一种用于大规模人脸图像集合的搜索引擎》，《欧洲计算机视觉会议论文集》(Proc. European Conf. Computer Vision (ECCV))，2008 年。

[35] N. Kumar, A. Berg, P. Belhumeur, and S. Nayar, "Describable Visual Attributes for Face Verification and Image Search," IEEE Trans. Pattern Analysis and Machine Intelligence, vol. 33, no. 10, pp. 1962-1977, Oct. 2011.

[35] N. 库马尔(N. Kumar)、A. 伯格(A. Berg)、P. 贝尔休默(P. Belhumeur)和 S. 纳亚尔(S. Nayar)，《用于人脸验证和图像搜索的可描述视觉属性》，《电气与电子工程师协会模式分析与机器智能汇刊》，第 33 卷，第 10 期，第 1962 - 1977 页，2011 年 10 月。

[36] D. Parikh and K. Grauman, "Interactively Building a Discriminative Vocabulary of Nameable Attributes," Proc. IEEE Conf. Computer Vision and Pattern Recognition (CVPR), pp. 1681-1688, 2011.

[36] D. 帕里克(D. Parikh)和 K. 格劳曼(K. Grauman)，《交互式构建可命名属性的区分性词汇表》，《电气与电子工程师协会计算机视觉与模式识别会议论文集》(CVPR)，第 1681 - 1688 页，2011 年。

[37] V. Sharmanska, N. Quadrianto, and C.H. Lampert, "Augmented Attribute Representations" Proc. European Conf. Computer Vision (ECCV), 2012.

[37] V. 沙曼斯卡(V. Sharmanska)、N. 夸德里安托(N. Quadrianto)和 C.H. 兰佩特(C.H. Lampert)，《增强属性表示》，《欧洲计算机视觉会议论文集》(ECCV)，2012 年。

[38] K. Yanai and K. Barnard, "Image Region Entropy: A Measure of 'Visualness' of Web Images Associated with One Concept," Proc. 13th Ann. ACM Int'l Conf. Multimedia, 2005.

[38] K. 矢内(K. Yanai)和 K. 巴纳德(K. Barnard)，《图像区域熵:与一个概念相关的网络图像的“视觉性”度量》，《第 13 届年度美国计算机协会国际多媒体会议论文集》，2005 年。

[39] J. Wang, K. Markert, and M. Everingham, "Learning Models for Object Recognition from Natural Language Descriptions," Proc. British Machine Vision Conf. (BMVC), 2009.

[39] J. 王(J. Wang)、K. 马克特(K. Markert)和 M. 埃弗里ingham(M. Everingham)，《从自然语言描述中学习目标识别模型》，《英国机器视觉会议论文集》(BMVC)，2009 年。

[40] T.L. Berg, A.C. Berg, and J. Shih, "Automatic Attribute Discovery and Characterization from Noisy Web Images," Proc. European Conf. Computer Vision (ECCV), 2010.

[40] T.L. 伯格(T.L. Berg)、A.C. 伯格(A.C. Berg)和 J. 施(J. Shih)，《从嘈杂的网络图像中自动发现和表征属性》，《欧洲计算机视觉会议论文集》(ECCV)，2010 年。

[41] L.J. Li, H. Su, Y. Lim, and L. Fei-Fei, "Objects as Attributes for Scene Classification," Proc. First Int'l Workshop Parts and Attributes at European Conf. Computer Vision, 2010.

[41] L.J. 李(L.J. Li)、H. 苏(H. Su)、Y. 林(Y. Lim)和 L. 费菲(L. Fei - Fei)，《将物体作为场景分类的属性》，《欧洲计算机视觉会议第一届国际部件与属性研讨会论文集》，2010 年。

[42] Y. Wang and G. Mori, "A Discriminative Latent Model of Object Classes and Attributes," Proc. European Conf. Computer Vision (ECCV), pp. 155-168, 2010.

[42] Y. 王(Y. Wang)和 G. 森(G. Mori)，《目标类别和属性的区分性潜在模型》，《欧洲计算机视觉会议论文集》(ECCV)，第 155 - 168 页，2010 年。

[43] X. Yu and Y. Aloimonos, "Attribute-Based Transfer Learning for Object Categorization with Zero/One Training Example," Proc. European Conf. Computer Vision (ECCV), pp. 127-140, 2010.

[43] X. 余(X. Yu)和 Y. 阿洛伊莫诺斯(Y. Aloimonos)，《基于属性的零/单训练示例目标分类迁移学习》，《欧洲计算机视觉会议论文集》(ECCV)，第 127 - 140 页，2010 年。

[44] W.J. Scheirer, N. Kumar, P.N. Belhumeur, and T.E. Boult, "Multi-Attribute Spaces: Calibration for Attribute Fusion and Similarity Search," Proc. IEEE Conf. Computer Vision and Pattern Recognition (CVPR), 2012.

[44] W.J. 谢勒(W.J. Scheirer)、N. 库马尔(N. Kumar)、P.N. 贝尔休默(P.N. Belhumeur)和 T.E. 博尔特(T.E. Boult)，《多属性空间:属性融合和相似性搜索的校准》，《电气与电子工程师协会计算机视觉与模式识别会议论文集》(CVPR)，2012 年。

[45] A. Farhadi, I. Endres, D. Hoiem, and D. Forsyth, "Describing Objects by their Attributes," Proc. IEEE Conf. Computer Vision and Pattern Recognition (CVPR), 2009.

[45] A. 法尔哈迪(A. Farhadi)、I. 恩德斯(I. Endres)、D. 霍耶姆(D. Hoiem)和 D. 福赛思(D. Forsyth)，《通过属性描述物体》，《电气与电子工程师协会计算机视觉与模式识别会议论文集》(CVPR)，2009 年。

[46] G. Patterson and J. Hays, "SUN Attribute Database: Discovering, Annotating, and Recognizing Scene Attributes," Proc. IEEE Conf. Computer Vision and Pattern Recognition (CVPR), 2012.

[46] G. 帕特森(G. Patterson)和 J. 海斯(J. Hays)，《SUN 属性数据库:发现、标注和识别场景属性》，《电气与电子工程师协会计算机视觉与模式识别会议论文集》(CVPR)，2012 年。

[47] J. Liu, B. Kuipers, and S. Savarese, "Recognizing Human Actions by Attributes," Proc. IEEE Conf. Computer Vision and Pattern Recognition (CVPR), 2011.

[47] J. 刘(J. Liu)、B. 库伊佩斯(B. Kuipers)和 S. 萨瓦雷塞(S. Savarese)，《通过属性识别人类动作》，《电气与电子工程师协会计算机视觉与模式识别会议论文集》(CVPR)，2011 年。

[48] R. Feris, B. Siddiquie, Y. Zhai, J. Petterson, L. Brown, and S. Pankanti, "Attribute-Based Vehicle Search in Crowded Surveillance Videos," Proc. ACM Int'l Conf. Multimedia Retrieval (ICMR), article 18, 2011.

[48] R. 费里斯(R. Feris)、B. 西迪基(B. Siddiquie)、Y. 翟(Y. Zhai)、J. 彼得森(J. Petterson)、L. 布朗(L. Brown)和 S. 潘坎蒂(S. Pankanti)，《拥挤监控视频中基于属性的车辆搜索》，《美国计算机协会国际多媒体检索会议论文集》(ICMR)，文章编号 18，2011 年。

[49] M. Rohrbach, M. Stark, G. Szarvas, I. Gurevych, and B. Schiele, "What Helps Where-and Why? Semantic Relatedness for Knowledge Transfer," Proc. IEEE Conf. Computer Vision and Pattern Recognition (CVPR), 2010.

[49] M. 罗尔巴赫(M. Rohrbach)、M. 斯塔克(M. Stark)、G. 萨尔瓦斯(G. Szarvas)、I. 古雷维奇(I. Gurevych)和 B. 席勒(B. Schiele)，《什么在何处有帮助以及为什么？知识转移的语义相关性》，《电气与电子工程师协会计算机视觉与模式识别会议论文集》(CVPR)，2010 年。

[50] G. Kulkarni, V. Premraj, S. Dhar, S. Li, Y. Choi, A.C. Berg, and T.L. Berg, "Baby Talk: Understanding and Generating Simple Image Descriptions," Proc. IEEE Conf. Computer Vision and Pattern Recognition (CVPR), pp. 1601-1608, 2011.

[50] G. 库尔卡尼(G. Kulkarni)、V. 普雷姆拉吉(V. Premraj)、S. 达尔(S. Dhar)、S. 李(S. Li)、Y. 崔(Y. Choi)、A.C. 伯格(A.C. Berg)和 T.L. 伯格(T.L. Berg)，《婴儿语言:理解和生成简单图像描述》，《电气与电子工程师协会计算机视觉与模式识别会议论文集》(CVPR)，第 1601 - 1608 页，2011 年。

[51] A. Kovashka, D. Parikh, and K. Grauman, "Whittlesearch: Image Search with Relative Attribute Feedback," Proc. IEEE Conf. Computer Vision and Pattern Recognition (CVPR), 2012.

[51] A. 科瓦什卡(A. Kovashka)、D. 帕里克(D. Parikh)和 K. 格劳曼(K. Grauman)，《细粒度搜索:基于相对属性反馈的图像搜索》("Whittlesearch: Image Search with Relative Attribute Feedback")，《电气与电子工程师协会计算机视觉与模式识别会议论文集》(Proc. IEEE Conf. Computer Vision and Pattern Recognition (CVPR))，2012 年。

[52] A. Parkash and D. Parikh, "Attributes for Classifier Feedback," Proc. European Conf. Computer Vision (ECCV), 2012.

[52] A. 帕卡什(A. Parkash)和 D. 帕里克(D. Parikh)，《用于分类器反馈的属性》("Attributes for Classifier Feedback")，《欧洲计算机视觉会议论文集》(Proc. European Conf. Computer Vision (ECCV))，2012 年。

[53] D. Osherson, E.E. Smith, T.S. Myers, E. Shafir, and M. Stob, "Extrapolating Human Probability Judgment," Theory and Decision, vol. 36, no. 2, pp. 103-129, 1994.

[53] D. 奥舍尔森(D. Osherson)、E.E. 史密斯(E.E. Smith)、T.S. 迈尔斯(T.S. Myers)、E. 沙菲尔(E. Shafir)和 M. 斯托布(M. Stob)，《推断人类概率判断》("Extrapolating Human Probability Judgment")，《理论与决策》(Theory and Decision)，第 36 卷，第 2 期，第 103 - 129 页，1994 年。

[54] S.A. Sloman, "Feature-Based Induction," Cognitive Psychology, vol. 25, pp. 231-280, 1993.

[54] S.A. 斯洛曼(S.A. Sloman)，《基于特征的归纳》("Feature-Based Induction")，《认知心理学》(Cognitive Psychology)，第 25 卷，第 231 - 280 页，1993 年。

[55] T. Hansen, M. Olkkonen, S. Walter, and K.R. Gegenfurtner, "Memory Modulates Color Appearance," Nature Neuroscience, vol. 9, pp. 1367-1368, 2006.

[55] T. 汉森(T. Hansen)、M. 奥尔科宁(M. Olkkonen)、S. 沃尔特(S. Walter)和 K.R. 格根富特纳(K.R. Gegenfurtner)，《记忆调节颜色外观》("Memory Modulates Color Appearance")，《自然神经科学》(Nature Neuroscience)，第 9 卷，第 1367 - 1368 页，2006 年。

[56] D.N. Osherson, J. Stern, O. Wilkie, M. Stob, and E.E. Smith, "Default Probability," Cognitive Science, vol. 15, no. 2, pp. 251-269, 1991.

[56] D.N. 奥舍尔森(D.N. Osherson)、J. 斯特恩(J. Stern)、O. 威尔基(O. Wilkie)、M. 斯托布(M. Stob)和 E.E. 史密斯(E.E. Smith)，《默认概率》("Default Probability")，《认知科学》(Cognitive Science)，第 15 卷，第 2 期，第 251 - 269 页，1991 年。

[57] C. Kemp, J.B. Tenenbaum, T.L. Griffiths, T. Yamada, and N. Ueda, "Learning Systems of Concepts with an Infinite Relational Model," Proc. Nat'l Conf. Artificial Intelligence (AAAI), 2006.

[57] C. 肯普(C. Kemp)、J.B. 特南鲍姆(J.B. Tenenbaum)、T.L. 格里菲思(T.L. Griffiths)、T. 山田(T. Yamada)和 N. 上田(N. Ueda)，《使用无限关系模型学习概念系统》("Learning Systems of Concepts with an Infinite Relational Model")，《美国人工智能协会会议论文集》(Proc. Nat'l Conf. Artificial Intelligence (AAAI))，2006 年。

[58] K.E.A. van de Sande, T. Gevers, and C.G.M. Snoek, "Evaluation of Color Descriptors for Object and Scene Recognition," Proc. IEEE Conf. Computer Vision and Pattern Recognition (CVPR), 2008.

[58] K.E.A. 范德桑德(K.E.A. van de Sande)、T. 赫弗斯(T. Gevers)和 C.G.M. 斯诺克(C.G.M. Snoek)，《用于物体和场景识别的颜色描述符评估》("Evaluation of Color Descriptors for Object and Scene Recognition")，《电气与电子工程师协会计算机视觉与模式识别会议论文集》(Proc. IEEE Conf. Computer Vision and Pattern Recognition (CVPR))，2008 年。

[59] A. Bosch, A. Zisserman, and X. Muñoz, "Representing Shape with a Spatial Pyramid Kernel," Proc. Int'l Conf. Content-Based Image and Video Retrieval (CIVR), 2007.

[59] A. 博施(A. Bosch)、A. 齐斯曼(A. Zisserman)和 X. 穆尼奥斯(X. Muñoz)，《使用空间金字塔核表示形状》("Representing Shape with a Spatial Pyramid Kernel")，《国际基于内容的图像和视频检索会议论文集》(Proc. Int'l Conf. Content-Based Image and Video Retrieval (CIVR))，2007 年。

[60] H. Bay, A. Ess, T. Tuytelaars, and L.J.V. Gool, "Speeded-Up Robust Features (SURF)," Computer Vision and Image Understanding, vol. 110, no. 3, pp. 346-359, 2008.

[60] H. 贝(H. Bay)、A. 埃斯(A. Ess)、T. 蒂耶特拉尔斯(T. Tuytelaars)和 L.J.V. 古尔(L.J.V. Gool)，《加速稳健特征(SURF)》("Speeded-Up Robust Features (SURF)")，《计算机视觉与图像理解》(Computer Vision and Image Understanding)，第 110 卷，第 3 期，第 346 - 359 页，2008 年。

[61] E. Shechtman and M. Irani, "Matching Local Self-Similarities across Images and Videos," Proc. IEEE Conf. Computer Vision and Pattern Recognition (CVPR), 2007.

[61] E. 谢赫特曼(E. Shechtman)和 M. 伊拉尼(M. Irani)，《跨图像和视频匹配局部自相似性》("Matching Local Self-Similarities across Images and Videos")，《电气与电子工程师协会计算机视觉与模式识别会议论文集》(Proc. IEEE Conf. Computer Vision and Pattern Recognition (CVPR))，2007 年。

[62] J. Xiao, J. Hays, K.A. Ehinger, A. Oliva, and A. Torralba, "SUN Database: Large-Scale Scene Recognition from Abbey to Zoo," Proc. IEEE Conf. Computer Vision and Pattern Recognition (CVPR), pp. 3485-3492, 2010.

[62] J. 肖(J. Xiao)、J. 海斯(J. Hays)、K.A. 埃辛格(K.A. Ehinger)、A. 奥利瓦(A. Oliva)和 A. 托拉尔巴(A. Torralba)，《SUN 数据库:从修道院到动物园的大规模场景识别》("SUN Database: Large-Scale Scene Recognition from Abbey to Zoo")，《电气与电子工程师协会计算机视觉与模式识别会议论文集》(Proc. IEEE Conf. Computer Vision and Pattern Recognition (CVPR))，第 3485 - 3492 页，2010 年。

[63] J.C. Platt, "Probabilities for SV Machines," Advances in Large Margin Classifiers. MIT Press, 2000.

[63] J.C. 普拉特(J.C. Platt)，《支持向量机的概率》("Probabilities for SV Machines")，《大间隔分类器进展》(Advances in Large Margin Classifiers)。麻省理工学院出版社，2000 年。

[64] L. Torresani, M. Szummer, and A. Fitzgibbon, "Efficient Object Category Recognition Using Classemes," Proc. European Conf. Computer Vision (ECCV), pp. 776-789, Sept. 2010.

[64] L. 托雷萨尼(L. Torresani)、M. 苏默(M. Szummer)和 A. 菲茨吉本(A. Fitzgibbon)，《使用类元进行高效物体类别识别》("Efficient Object Category Recognition Using Classemes")，《欧洲计算机视觉会议论文集》(Proc. European Conf. Computer Vision (ECCV))，第 776 - 789 页，2010 年 9 月。

[65] K.D. Tang, M.F. Tappen, R. Sukthankar, and C.H. Lampert, "Optimizing One-Shot Recognition with Micro-Set Learning," Proc. IEEE Conf. Computer Vision and Pattern Recognition (CVPR), 2010.

[65] K.D. 唐(K.D. Tang)、M.F. 塔彭(M.F. Tappen)、R. 苏克坦卡尔(R. Sukthankar)和 C.H. 兰佩特(C.H. Lampert)，《通过微集学习优化一次性识别》("Optimizing One-Shot Recognition with Micro-Set Learning")，《电气与电子工程师协会计算机视觉与模式识别会议论文集》(Proc. IEEE Conf. Computer Vision and Pattern Recognition (CVPR))，2010 年。

[66] W.J. Scheirer, A. Rocha, A. Sapkota, and T.E. Boult, "Toward Open Set Recognition," IEEE Trans. Pattern Analysis and Machine Intelligence, vol. 35, no. 7, pp. 1757-1772, July 2013.

[66] W.J. 谢勒(W.J. Scheirer)、A. 罗查(A. Rocha)、A. 萨普科塔(A. Sapkota)和 T.E. 博尔特(T.E. Boult)，《迈向开放集识别》("Toward Open Set Recognition")，《电气与电子工程师协会模式分析与机器智能汇刊》(IEEE Trans. Pattern Analysis and Machine Intelligence)，第 35 卷，第 7 期，第 1757 - 1772 页，2013 年 7 月。

[67] T. Tommasi, N. Quadrianto, B. Caputo, and C.H. Lampert, "Beyond Data Set Bias: Multi-Task Unaligned Shared Knowledge Transfer," Proc. Asian Conf. Computer Vision (ACCV), 2012.

[67] T. 托马西(T. Tommasi)、N. 夸德里安托(N. Quadrianto)、B. 卡普托(B. Caputo)和 C.H. 兰佩特(C.H. Lampert)，《超越数据集偏差:多任务未对齐共享知识迁移》，《亚洲计算机视觉会议论文集》(ACCV)，2012 年。

![0195d2b2-ac8c-7630-a76c-75ecc68f9592_12_70_1431_234_278_0.jpg](images/0195d2b2-ac8c-7630-a76c-75ecc68f9592_12_70_1431_234_278_0.jpg)

Christoph H. Lampert received the PhD degree in mathematics from the University of Bonn in 2003. He was a senior researcher at the German Research Center for Artificial Intelligence in Kaiserslautern and a senior research scientist at the Max Planck Institute for Biological Cybernetics in Tübingen. He is currently an assistant professor at the Institute of Science and Technology Austria, where he heads a research group for computer vision and machine learning. He has received several international and national awards for his research, including the Best Paper Prize of CVPR 2008 and Best Student Paper Award of ECCV 2008. In 2012, he was awarded an ERC Starting Grant by the European Research Council. He is an associate editor of the IEEE Transactions on Pattern Analysis and Machine Intelligence and an action editor for the Journal of Machine Learning Research.

克里斯托夫·H·兰佩特(Christoph H. Lampert)于 2003 年在波恩大学(University of Bonn)获得数学博士学位。他曾是凯泽斯劳滕德国人工智能研究中心的高级研究员，以及图宾根马克斯·普朗克生物控制论研究所的高级研究科学家。他目前是奥地利科学技术研究所的助理教授，领导着一个计算机视觉和机器学习研究小组。他的研究获得了多项国际和国内奖项，包括 2008 年计算机视觉与模式识别会议(CVPR)最佳论文奖和 2008 年欧洲计算机视觉会议(ECCV)最佳学生论文奖。2012 年，他获得了欧洲研究理事会的欧洲研究理事会启动基金。他是《电气与电子工程师协会模式分析与机器智能汇刊》(IEEE Transactions on Pattern Analysis and Machine Intelligence)的副主编，以及《机器学习研究杂志》(Journal of Machine Learning Research)的行动编辑。

![0195d2b2-ac8c-7630-a76c-75ecc68f9592_12_866_132_226_274_0.jpg](images/0195d2b2-ac8c-7630-a76c-75ecc68f9592_12_866_132_226_274_0.jpg)

Hannes Nickisch received degrees from the Université de Nantes, France, in 2004, and the Technical University Berlin, Germany, in 2006. During his PhD work at the Max Planck Institute for Biological Cybernetics, Tübingen, Germany, he worked on large-scale approximate Bayesian inference and magnetic resonance image reconstruction. Since 2011, he has been with Philips Research, Hamburg, Germany. His research interests include medical image processing, machine learning, and biophysical modeling.

汉内斯·尼克施(Hannes Nickisch)于 2004 年在法国南特大学(Université de Nantes)获得学位，并于 2006 年在德国柏林工业大学(Technical University Berlin)获得学位。在德国图宾根马克斯·普朗克生物控制论研究所攻读博士期间，他致力于大规模近似贝叶斯推理和磁共振图像重建的研究。自 2011 年以来，他一直在德国汉堡的飞利浦研究中心工作。他的研究兴趣包括医学图像处理、机器学习和生物物理建模。

![0195d2b2-ac8c-7630-a76c-75ecc68f9592_12_866_454_224_280_0.jpg](images/0195d2b2-ac8c-7630-a76c-75ecc68f9592_12_866_454_224_280_0.jpg)

Stefan Harmeling studied mathematics and logic at the University of Münster (Dipl Math 1998) and computer science with an emphasis on artificial intelligence at Stanford University (MSc 2000). During his doctoral studies, he was a member of Prof. Klaus-Robert Müller's research group at the Fraunhofer Institute FIRST (Dr rer nat 2004). Thereafter, he was a Marie Curie fellow at the University of Edinburgh from 2005 to 2007, before joining the Max Planck Institute for Biological Cybernetics/Intelligent Systems. He is currently a senior research scientist in Prof. Bernhard Schölkopf's Department of Empirical Inference at the Max Planck Institute for Intelligent Systems (formerly Biological Cybernetics). His research interests include machine learning, image processing, computational photography, and probabilistic inference. In 2011, he received the DAGM Paper Prize, and in 2012 the Günter Petzow Prize for outstanding work at the Max Planck Institute for Intelligent Systems.

斯特凡·哈梅林(Stefan Harmeling)在明斯特大学(University of Münster)学习数学和逻辑学(1998 年获得数学文凭)，并在斯坦福大学(Stanford University)重点学习计算机科学中的人工智能(2000 年获得理学硕士学位)。在攻读博士学位期间，他是弗劳恩霍夫 FIRST 研究所克劳斯 - 罗伯特·米勒(Klaus - Robert Müller)教授研究小组的成员(2004 年获得自然科学博士学位)。此后，他于 2005 年至 2007 年在爱丁堡大学担任玛丽·居里研究员，之后加入马克斯·普朗克生物控制论/智能系统研究所。他目前是马克斯·普朗克智能系统研究所(前身为生物控制论研究所)伯恩哈德·朔尔科普夫(Bernhard Schölkopf)教授实证推理系的高级研究科学家。他的研究兴趣包括机器学习、图像处理、计算摄影和概率推理。2011 年，他获得了德国模式识别协会(DAGM)论文奖，2012 年获得了马克斯·普朗克智能系统研究所的京特·佩措夫奖(Günter Petzow Prize)，以表彰他的杰出工作。

$\vartriangleright$ For more information on this or any other computing topic, please visit our Digital Library at www.computer.org/publications/dlib.

$\vartriangleright$ 有关此或任何其他计算主题的更多信息，请访问我们的数字图书馆:www.computer.org/publications/dlib。