# The SUN Attribute Database: Beyond Categories for Deeper Scene Understanding

# SUN属性数据库:超越类别，实现更深层次的场景理解

Genevieve Patterson - Chen Xu - Hang Su - James Hays

Genevieve Patterson - 陈旭 - 苏航 - James Hays

Abstract In this paper we present the first large-scale scene attribute database. First, we perform crowdsourced human studies to find a taxonomy of 102 discriminative attributes. We discover attributes related to materials, surface properties, lighting, affordances, and spatial layout. Next, we build the "SUN attribute database" on top of the diverse SUN categorical database. We use crowdsourcing to annotate attributes for 14,340 images from 707 scene categories. We perform numerous experiments to study the interplay between scene attributes and scene categories. We train and evaluate attribute classifiers and then study the feasibility of attributes as an intermediate scene representation for scene classification, zero shot learning, automatic image captioning, semantic image search, and parsing natural images. We show that when used as features for these tasks, low dimensional scene attributes can compete with or improve on the state of the art performance. The experiments suggest that scene attributes are an effective low-dimensional feature for capturing high-level context and semantics in scenes.

摘要 本文首次提出了大规模场景属性数据库。首先，我们通过众包人类研究确定了102个区分性属性的分类法。我们发现了与材料、表面特性、光照、可供性(affordances)和空间布局相关的属性。接着，我们基于多样化的SUN类别数据库构建了“SUN属性数据库”。通过众包方式为来自707个场景类别的14,340张图像标注属性。我们进行了大量实验，研究场景属性与场景类别之间的相互作用。我们训练并评估了属性分类器，随后探讨了属性作为场景分类、零样本学习、自动图像描述、语义图像搜索和自然图像解析的中间场景表示的可行性。实验表明，作为这些任务的特征时，低维场景属性能够与最先进性能相媲美或有所提升。实验结果表明，场景属性是捕捉场景中高级上下文和语义的有效低维特征。

Keywords Scene understanding - Crowdsourcing - Attributes - Image captioning - Scene parsing

关键词 场景理解 - 众包 - 属性 - 图像描述 - 场景解析

## 1 Introduction

## 1 引言

Scene representations are vital to enabling many data-driven graphics and vision applications. There is important research on low-level representations of scenes (i.e. visual features) such as the gist descriptor (Oliva and Torralba 2001) or spatial pyramid (Lazebnik et al. 2006), but there has been little investigation into high-level representations of scenes (e.g. attributes or categories). The standard category-based recognition paradigm has gone largely unchallenged. In this paper, we explore a new, attribute-based representation of scenes.

场景表示对于实现许多数据驱动的图形和视觉应用至关重要。已有重要研究关注场景的低级表示(即视觉特征)，如gist描述符(Oliva和Torralba 2001)或空间金字塔(Lazebnik等 2006)，但对场景的高级表示(如属性或类别)研究较少。基于类别的标准识别范式基本未被挑战。本文探讨了一种新的基于属性的场景表示。

Traditionally, computer vision algorithms describe visual phenomena (e.g. objects, faces, actions, scenes, etc.) by giving each instance a categorical label (e.g. cat, Halle Berry, drinking, downtown street, etc.). For scenes, this model has several significant issues, visualized in Fig. 1: (1) the extent of scene understanding achievable is quite shallow-there is no way to express interesting intra-category variations. (2) The space of scenes is continuous, so hard partitioning creates numerous ambiguous boundary cases. ${}^{1}$ (3) Images often simultaneously exhibit characteristics of multiple distinct scene categories. (4) A categorical representation cannot generalize to types of scenes which were not seen during training.

传统上，计算机视觉算法通过为每个实例赋予类别标签(如猫、Halle Berry、饮酒、城市街道等)来描述视觉现象(如物体、人脸、动作、场景等)。对于场景，这种模型存在几个显著问题，如图1所示:(1)场景理解的深度有限——无法表达类别内的有趣变化。(2)场景空间是连续的，硬划分导致大量模糊边界情况。${}^{1}$(3)图像常同时呈现多个不同场景类别的特征。(4)类别表示无法推广到训练时未见过的场景类型。

An attribute-based representation of scenes would address these problems by expressing variation within a scene category. Scenes would have a multi-variate attribute representation instead of simply a binary category membership. Scene types not seen at training time could also be identified by a canonical set of scene attributes in a zero-shot learning manner.

基于属性的场景表示通过表达场景类别内的变化来解决这些问题。场景将拥有多变量属性表示，而非简单的二元类别归属。训练时未见的场景类型也可通过一组典型场景属性以零样本学习方式识别。

In the past several years there has been interest in attribute-based representations of objects (Ferrari and Zisserman 2008; Farhadi et al. 2009; Lampert et al. 2009; Farhadi et al. 2010a; Endres et al. 2010; Berg et al. 2010; Russakovsky and Fei-Fei 2010; Su et al. 2010), faces (Kumar et al. 2009), and actions (Yao et al. 2011; Liu et al. 2011b) as an alternative or complement to category-based representations. However, there has been only limited exploration of attribute-based representations for scenes, even though scenes are uniquely poorly served by categorical representations. For example, an object usually has unambiguous membership in one category. One rarely observes issue 2 (e.g. this object is on the boundary between sheep and horse) or issue 3 (e.g. this object is both a potted plant and a television).

近年来，属性表示作为类别表示的替代或补充，已在物体(Ferrari和Zisserman 2008；Farhadi等 2009；Lampert等 2009；Farhadi等 2010a；Endres等 2010；Berg等 2010；Russakovsky和Fei-Fei 2010；Su等 2010)、人脸(Kumar等 2009)和动作(Yao等 2011；Liu等 2011b)领域引起关注。然而，场景的属性表示探索有限，尽管场景对类别表示的适应性尤差。例如，物体通常明确属于某一类别，较少出现问题2(如该物体处于绵羊与马的边界)或问题3(如该物体同时是盆栽和电视)。

---

${}^{1}$ Individual attribute presence might be ambiguous in certain scenes, just like category membership can be ambiguous. Scenes only have one category label, though, and the larger the number of categories the more ambiguous the membership is. However, with over one hundred scene attributes in our taxonomy, several attributes may be strongly present, offering a description of that scene that has more context than simply the scene category label. This also enables an attribute-based representation to make finer-grain distinctions about which which components or characteristics of the scene are ambiguous or obvious.

${}^{1}$ 某些场景中单个属性的存在可能模糊，就像类别归属可能模糊一样。但场景仅有一个类别标签，类别数量越多，归属越模糊。然而，在我们超过一百个场景属性的分类法中，多个属性可能强烈存在，提供比单一场景类别标签更丰富的上下文描述。这也使基于属性的表示能够更细致地区分场景中哪些组成部分或特征是模糊的或明显的。

G. Patterson $\left( \square \right)  \cdot  \mathrm{C}.\mathrm{{Xu}} \cdot  \mathrm{H}.\mathrm{{Su}} \cdot  \mathrm{J}.\mathrm{{Hays}}$

G. Patterson $\left( \square \right)  \cdot  \mathrm{C}.\mathrm{{Xu}} \cdot  \mathrm{H}.\mathrm{{Su}} \cdot  \mathrm{J}.\mathrm{{Hays}}$

Department of Computer Science, Brown University, 115 Waterman St., Providence, RI 02912, USA

美国罗德岛普罗维登斯，布朗大学计算机科学系，Waterman街115号，邮编02912

e-mail: gen@cs.brown.edu

电子邮件:gen@cs.brown.edu

---

![bo_d1c3uev7aajc7389qf6g_1_151_154_698_436_0.jpg](images/bo_d1c3uev7aajc7389qf6g_1_151_154_698_436_0.jpg)

Fig. 1 Visualization of a hypothetical space of scenes embedded in 2D and partitioned by categories. Categorical scene representations have several potential shortcomings: (1) important intra-class variations such as the dramatic differences between four 'village' scenes can not be captured, (2) hard partitions break up the continuous transitions between many scene types such as 'forest' and 'savanna', (3) an image can depict multiple, independent categories such as 'beach' and 'village', and (4) it is difficult to reason about unseen categories, whereas attribute-based representations lend themselves towards zero-shot learning (Parikh and Grauman 2011b)

图1 假设的场景空间可视化，该空间嵌入于二维中并按类别划分。类别场景表示存在若干潜在缺陷:(1) 重要的类内变异，如四个“村庄”场景之间的显著差异，无法被捕捉；(2) 硬性划分打断了许多场景类型之间的连续过渡，如“森林”和“稀树草原”；(3) 一张图像可能同时描绘多个独立类别，如“海滩”和“村庄”；(4) 难以推理未见过的类别，而基于属性的表示则有利于零样本学习(Parikh 和 Grauman 2011b)。

In the domain of scenes, an attribute-based representation might describe an image with 'concrete', 'shopping', 'natural lighting', 'glossy', and 'stressful' in contrast to a categorical label such as 'store'. Figure 2 visualizes the space of scenes partitioned by attributes rather than categories. Note, the attributes do not follow category boundaries. Indeed, that is one of the appeals of attributes-they can describe intra-class variation (e.g. a canyon might have water or it might not) and inter-class relationships (e.g. both a canyon and a beach could have water). As stated by Ferrari and Zisserman (2008), "recognition of attributes can complement category-level recognition and therefore improve the degree to which machines perceive visual objects".

在场景领域，基于属性的表示可能用“混凝土”、“购物”、“自然光照”、“光滑”和“紧张”等词描述一张图像，而非使用“商店”等类别标签。图2展示了按属性而非类别划分的场景空间。注意，属性并不遵循类别边界。事实上，这正是属性的魅力之一——它们可以描述类内变异(例如峡谷可能有水也可能没有)和类间关系(例如峡谷和海滩都可能有水)。正如 Ferrari 和 Zisserman(2008)所述，“属性识别可以补充类别级识别，从而提升机器对视觉对象的感知能力”。

A small set of scene attributes were explored in Oliva and Torralba's seminal 'gist' paper (Oliva and Torralba 2001) and follow-up work (Oliva and Torralba 2002). Eight ‘spatial envelope' attributes were found by having participants manually partition a database of eight scene categories. These attributes such as openness, perspective, and depth were predicted based on the gist representation. Greene and Oliva show that these global scene attributes are predictive of human performance on a rapid basic-level scene categorization task. Greene and Oliva (2009) argue that global attributes of the type we examine here are important for human perception, saying, "rapid categorization of natural scenes may not be mediated primarily though objects and parts, but also through global properties of structure and affordance."

Oliva 和 Torralba 在其开创性的“gist”论文(Oliva 和 Torralba 2001)及后续工作(Oliva 和 Torralba 2002)中探讨了一小组场景属性。通过让参与者手动划分包含八个场景类别的数据库，发现了八个“空间包络”属性。这些属性如开放性、透视和深度，基于gist表示进行预测。Greene 和 Oliva 证明这些全局场景属性能预测人类在快速基础级场景分类任务中的表现。Greene 和 Oliva(2009)认为，我们这里考察的全局属性对人类感知至关重要，指出“自然场景的快速分类可能不仅依赖于对象和部件，还依赖于结构和可供性(affordance)的全局属性”。

![bo_d1c3uev7aajc7389qf6g_1_900_152_705_538_0.jpg](images/bo_d1c3uev7aajc7389qf6g_1_900_152_705_538_0.jpg)

Fig. 2 Hypothetical space of scenes partitioned by attributes rather than categories. In reality, this space is much higher dimensional and there are not clean boundaries between attribute presence and absence

图2 按属性而非类别划分的假设场景空间。实际上，该空间维度更高，且属性存在与否之间没有明确边界。

Russakovsky and Fei-Fei identify the need to discover visual attributes that generalize between categories in Rus-sakovsky and Fei-Fei (2010). Using a subset of the categories from ImageNet, Russakovsky and Fei-Fei show that attributes can both discriminate between unique examples of a category and allow sets of categories to be grouped by common attributes. In Russakovsky and Fei-Fei (2010) attributes were mined from the WordNet definitions of categories. The attribute discovery method described in this paper outlines how attributes can be identified directly by human users. In the end we discover a larger set of attributes, including attributes that would be either too common or too rare to be typically included in the definition of categories.

Russakovsky 和 Fei-Fei 在 Russakovsky 和 Fei-Fei(2010)中指出了发现能跨类别泛化的视觉属性的必要性。利用 ImageNet 的部分类别，Russakovsky 和 Fei-Fei 展示了属性既能区分类别中的独特实例，也能使类别集合按共有属性分组。在 Russakovsky 和 Fei-Fei(2010)中，属性是从类别的 WordNet 定义中挖掘的。本文描述的属性发现方法则阐明了如何由人类用户直接识别属性。最终我们发现了更多属性，包括那些通常因过于常见或过于罕见而不被纳入类别定义的属性。

More recently, Parikh and Grauman (Parikh and Grau-man 2011a) argue for 'relative' rather than binary attributes. They demonstrate results on the eight category outdoor scene database, but their training data is limited-they do not have per-scene attribute labels and instead provide attribute labels at the category level (e.g. all highway scenes should be more 'natural' than all street scenes). This undermines one of the potential advantages of attribute-based representations-the ability to describe intra-class variation. In this paper we discover, annotate, and recognize 15 times as many attributes using a database spanning 90 times as many categories where every scene has independent attribute labels.

最近，Parikh 和 Grauman(Parikh 和 Grauman 2011a)主张使用“相对”属性而非二元属性。他们在八类别户外场景数据库上展示了结果，但训练数据有限——他们没有每个场景的属性标签，而是在类别层面提供属性标签(例如所有高速公路场景应比所有街道场景更“自然”)。这削弱了基于属性表示的一个潜在优势——描述类内变异的能力。本文利用涵盖90倍类别数量的数据库，发现、标注并识别了15倍数量的属性，每个场景均有独立的属性标签。

Lampert et al. demonstrate how attributes can be used to classify unseen categories (Lampert et al. 2009). Lampert et al. show that attribute classifiers can be learned independent of category, then later test images can be classified as part of an unseen category with the simple knowledge of the expected attributes of the unseen category. This opens the door for classification of new categories without using training examples to learn those unseen categories. We demonstrate in Sect. 6.1 the performance of our scene attributes for zero-shot learning by classifying test images from all of the categories in our dataset without training classifiers for those scene categories.

Lampert 等人展示了如何利用属性对未见类别进行分类(Lampert 等人 2009)。他们表明属性分类器可以独立于类别进行学习，随后测试图像可凭借对未见类别预期属性的简单了解被分类为该类别。这为无需训练样本即可分类新类别开辟了道路。我们在第6.1节展示了利用场景属性进行零样本学习的性能，通过对数据集中所有类别的测试图像进行分类，而无需为这些场景类别训练分类器。

### 1.1 Paper Outline

### 1.1 论文结构

This paper describes the creation and verification of our SUN attribute database in the spirit of analogous database creation efforts such as ImageNet (Deng et al. 2009), LabelMe (Russell et al. 2008), and Tiny Images (Torralba et al. 2008). First, we derive a taxonomy of more than 100 scene attributes from crowd-sourced experiments (Sect. 2). Next, we use crowd-sourcing to construct our attribute-labeled dataset on top of a significant subset of the SUN database (Xiao et al. 2010) spanning more than 700 categories and 14,000 images (Sect. 3). We visualize the distribution of scenes in attribute space (Sect. 4). The work in these sections largely appears in a previous publication (Patterson and Hays 2012). Section 5 contains significantly expanded work, and Sects. 6 and 7 are previously unpublished novel experiments.

本文介绍了我们SUN属性数据库的创建与验证，借鉴了类似数据库创建工作的精神，如ImageNet(Deng等，2009)、LabelMe(Russell等，2008)和Tiny Images(Torralba等，2008)。首先，我们通过众包实验(第2节)推导出超过100种场景属性的分类体系。接着，我们利用众包在SUN数据库(Xiao等，2010)中一个重要子集上构建了带属性标签的数据集，涵盖700多个类别和14,000张图像(第3节)。我们在属性空间中可视化了场景的分布(第4节)。这些章节的工作大部分已发表于先前的文献(Patterson和Hays，2012)。第5节包含了显著扩展的内容，第6和第7节则是此前未发表的新颖实验。

In order to use scene attributes for vision tasks, we train and test classifiers for predicting attributes (Sect. 5). We demonstrate the output of these classifiers on novel images. Furthermore, in Sect. 6 we explore the use of scene attributes for scene classification and the zeroshot learning of scene categories. We compare how scene classifiers derived using scene attributes confuse scene categories to how human respondents confuse categories.

为了将场景属性应用于视觉任务，我们训练并测试了用于预测属性的分类器(第5节)。我们展示了这些分类器在新图像上的输出。此外，在第6节中，我们探讨了场景属性在场景分类和零样本学习(zero-shot learning)场景类别中的应用。我们比较了基于场景属性的场景分类器与人类受试者在混淆场景类别时的表现差异。

The final section of the paper experiments with using scene attributes for challenging scene understanding tasks. We use attributes as features in the pipelines for the tasks of scene parsing (Sect. 7.1) and automatic image captioning (Sect. 7.2). We also investigate image retrieval with image descriptors derived from attributes (Sect. 7.3).

论文的最后一节实验了使用场景属性解决具有挑战性的场景理解任务。我们将属性作为特征，应用于场景解析(第7.1节)和自动图像描述(第7.2节)的流程中。我们还研究了基于属性派生的图像描述符进行图像检索的效果(第7.3节)。

## 2 Building a Taxonomy of Scene Attributes from Human Descriptions

## 2 从人类描述构建场景属性分类体系

Our first task is to establish a taxonomy of scene attributes for further study. The space of attributes is effectively infinite but the majority of possible attributes (e.g., "Was this photo taken on a Tuesday", "Does this scene contain air?") are not interesting. We are interested in finding discriminative attributes which are likely to distinguish scenes from each other (not necessarily along categorical boundaries). We limit ourselves to global, binary attributes. This limitation is primarily economic—we collect millions of labels and annotating binary attributes is more efficient than annotating real-valued or relative attributes. None-the-less, by averaging the binary labels from multiple annotators we produce a real-valued confidence for each attribute.

我们的首要任务是建立一个场景属性的分类体系以供进一步研究。属性空间实际上是无限的，但大多数可能的属性(例如，“这张照片是在星期二拍摄的吗”，“这个场景中有空气吗？”)并不具备研究价值。我们关注的是能够区分不同场景的判别性属性(不一定是沿类别边界)。我们限定为全局的二元属性。这一限制主要出于经济考虑——我们收集了数百万标签，标注二元属性比标注实值或相对属性更高效。尽管如此，通过对多个标注者的二元标签取平均，我们为每个属性生成了实值置信度。

To determine which attributes are most relevant for describing scenes we perform open-ended image description tasks on Amazon Mechanical Turk (AMT). First we establish a set of 'probe' images for which we will collect descriptions. There is one probe image for every category, selected for its canonical appearance. We want a set of images which is maximally diverse and representative of the space of scenes. For this reason the probe images are the images which human participants found to be most typical of 707 SUN dataset categories (Ehinger et al. 2011).

为了确定哪些属性最适合描述场景，我们在亚马逊机械土耳其人平台(Amazon Mechanical Turk，AMT)上执行了开放式图像描述任务。首先，我们确定了一组“探针”图像，用于收集描述。每个类别对应一张探针图像，选取其典型外观。我们希望这组图像在场景空间中具有最大多样性和代表性。因此，探针图像是人类参与者认为最具代表性的707个SUN数据集类别的典型图像(Ehinger等，2011)。

We first ask AMT workers to provide text descriptions of the individual probe images. From thousands of such tasks (hereafter HITs, for human intelligence tasks) it emerges that people tend to describe scenes with five types of attributes: (1) materials (e.g. cement, vegetation), (2) surface properties (e.g. rusty) (3) functions or affordances (e.g. playing, cooking), (4) spatial envelope attributes (e.g. enclosed, symmetric), and (5) object presence (e.g. cars, chairs).

我们首先要求AMT工人对单个探针图像提供文本描述。通过数千次此类任务(以下简称HITs，即人类智能任务)，发现人们倾向于用五类属性描述场景:(1)材料(如水泥、植被)，(2)表面特性(如生锈)，(3)功能或可供性(如玩耍、烹饪)，(4)空间包络属性(如封闭、对称)，以及(5)物体存在(如汽车、椅子)。

Within these broad categories we focus on discriminative attributes. To find such attributes we develop a simplified, crowd-sourced version of the 'splitting task' used by Oliva and Torralba (2001). We show AMT workers two groups of scenes and ask them to list attributes of each type (material, surface property, affordance, spatial envelope, and object) that are present in one group but not the other. The images that make up these groups are typical scenes from distinct, random categories. In the simplest case, with only one scene in each set, we found that participants would focus on trivial, happenstance objects or attributes (e.g. 'treadmill' or 'yellow shirt'). Such attributes would not be broadly useful for describing other scenes. At the other extreme, with many category prototypes in each set, it is rare that any attribute would be shared by one set and absent from the other. We found that having two random scene prototypes in each set elicited a diverse, broadly applicable set of attributes.

在这些大类中，我们聚焦于判别性属性。为寻找此类属性，我们开发了Oliva和Torralba(2001)使用的“分割任务”的简化众包版本。我们向AMT工人展示两组场景，要求他们列出每类属性(材料、表面特性、可供性、空间包络和物体)中存在于一组但不在另一组的属性。这些组由不同随机类别的典型场景组成。最简单的情况是每组只有一个场景，发现参与者会关注琐碎的偶然物体或属性(如“跑步机”或“黄色衬衫”)，这些属性对描述其他场景帮助不大。极端情况下，每组包含许多类别原型时，很少有属性能在一组中存在而另一组缺失。我们发现每组包含两个随机场景原型时，能激发出多样且广泛适用的属性集合。

Figure 3 shows an example interface. The attribute gathering task was repeated over 6000 times. From the thousands of raw discriminative attributes reported by participants we manually collapse nearly synonymous responses (e.g. dirt and soil) into single attributes. We omit attributes related to aesthetics rather than scene content. For this study we also omit the object presence attributes from further discussion because prediction of object presence, i.e. object classification, has been thoroughly investigated (Additionally, the SUN database already has dense object labels for most scenes). Our participants did not report all of the spatial envelope attributes found by Oliva and Torralba (2001), so we manually add binary versions of those attributes so that our taxonomy is a superset of prior work. In total, we find 38 material, 11 surface property, 36 function, and 17 spatial envelope attributes. Attributes which were reported in $< 1\%$ of trials were discarded (Fig. 4). ${}^{2}$

图3展示了一个示例界面。属性收集任务重复进行了6000多次。我们从参与者报告的数千个原始判别属性中，手动合并了几乎同义的响应(例如dirt和soil)为单一属性。我们省略了与美学相关而非场景内容相关的属性。对于本研究，我们还省略了对象存在属性的进一步讨论，因为对象存在的预测，即对象分类，已被深入研究(此外，SUN数据库对大多数场景已有密集的对象标签)。我们的参与者未报告Oliva和Torralba(2001)发现的所有空间包络属性，因此我们手动添加了这些属性的二元版本，使我们的分类法成为先前工作的超集。总计，我们发现了38种材料属性、11种表面属性、36种功能属性和17种空间包络属性。在$< 1\%$的试验中报告的属性被丢弃(图4)。${}^{2}$

![bo_d1c3uev7aajc7389qf6g_3_241_158_516_217_0.jpg](images/bo_d1c3uev7aajc7389qf6g_3_241_158_516_217_0.jpg)

Fig. 3 Mechanical Turk interface for discovering discriminative attributes

图3 用于发现判别属性的Mechanical Turk界面

![bo_d1c3uev7aajc7389qf6g_3_146_489_707_358_0.jpg](images/bo_d1c3uev7aajc7389qf6g_3_146_489_707_358_0.jpg)

Fig. 4 Scene attributes. A word cloud of all the scene attributes where the area of the word is proportional to its popularity in the dataset

图4 场景属性。所有场景属性的词云，词的面积与其在数据集中的流行度成正比

## 3 Building the SUN Attribute Database

## 3 构建SUN属性数据库

With our taxonomy of attributes finalized we create the first large-scale database of attribute-labeled scenes. We build the SUN attribute database on top of the existing SUN categorical database (Xiao et al. 2010) for two reasons: (1) to study the interplay between attribute-based and category-based representations and (2) to ensure a diversity of scenes. We annotate 20 scenes from each of the 717 SUN categories. Of the full SUN database, which has over 900 categories, only 717 contain at least 20 instances. Our goal is to collect ground truth annotations for all of the 102 attributes for each scene in our dataset. In total we gather more than four million labels. This necessitates a crowdsourced annotation strategy and we once again utilize AMT.

在确定了我们的属性分类法后，我们创建了第一个大规模属性标注场景数据库。我们基于现有的SUN分类数据库(Xiao等，2010)构建SUN属性数据库，原因有二:(1)研究基于属性和基于类别的表示之间的相互作用；(2)确保场景的多样性。我们从717个SUN类别中的每个类别标注20个场景。整个SUN数据库包含900多个类别，只有717个类别至少包含20个实例。我们的目标是为数据集中每个场景收集所有102个属性的真实标注。总共收集了超过四百万个标签。这需要众包标注策略，我们再次利用了AMT。

![bo_d1c3uev7aajc7389qf6g_3_905_153_700_729_0.jpg](images/bo_d1c3uev7aajc7389qf6g_3_905_153_700_729_0.jpg)

Fig. 5 Annotation interface for AMT workers. The particular attribute being labeled is prominently shown and defined. Example scenes which contain the attribute are shown. The worker can not scroll these definitions or instructions off of their screen. When workers mouse over a thumbnail a large version appears in the preview window in the top right corner

图5 AMT工人的标注界面。当前标注的属性被突出显示并定义。显示包含该属性的示例场景。工人无法将这些定义或说明滚动出屏幕。当工人鼠标悬停在缩略图上时，右上角预览窗口会显示该图的大图

### 3.1 The Attribute Annotation Task

### 3.1 属性标注任务

The primary difficulty of using a large, non-expert workforce is ensuring that the collected labels are accurate while keeping the annotation process fast and economical (Sorokin and Forsyth 2008). From an economic perspective, we want to have as many images labeled as possible for the lowest price. From a quality perspective, we want workers to easily and accurately label images. We find that particular UI design decisions and worker instructions significantly impacted throughput and quality of results. After several iterations, we choose a design where workers are presented with a grid of 4 dozen images and are asked to consider only a single attribute at a time. Workers are asked to click on images which exhibit the attribute in question. Before working on our HITs, potential annotators are required to pass a quiz covering the fundamentals of attribute identification and image labeling. The quiz asked users to select the correct definition of an attribute after they were shown the definition and example pictures. Users were also graded on how many images they could identify containing a given attribute. The quiz closely resembled the attribute labeling task. An example of our HIT user interface is shown in Fig. 5.

使用大规模非专业劳动力的主要难点是确保收集的标签准确，同时保持标注过程快速且经济(Sorokin和Forsyth 2008)。从经济角度看，我们希望以最低成本标注尽可能多的图像。从质量角度看，我们希望工人能够轻松且准确地标注图像。我们发现特定的界面设计决策和工人指导显著影响了产出效率和结果质量。经过多次迭代，我们选择了一个设计:工人面对一个包含48张图像的网格，每次只考虑单一属性。工人被要求点击展示该属性的图像。在开始我们的HIT任务前，潜在标注者需通过一项涵盖属性识别和图像标注基础的测验。测验要求用户在看到定义和示例图片后选择属性的正确定义。用户还根据能识别出多少包含该属性的图像进行评分。测验与属性标注任务高度相似。我们的HIT用户界面示例如图5所示。

Even after the careful construction of the annotation interface and initial worker screening, many workers' annotations are unreasonable. We use several techniques to filter out bad workers and then cultivate a pool of trusted workers:

即使在精心设计标注界面和初步筛选工人后，许多工人的标注仍不合理。我们采用多种技术过滤不良工人，并培养一批可信工人:

---

2 Word cloud made using the software available at www.wordle.net by Jonathan Feinberg.

2 词云由Jonathan Feinberg使用www.wordle.net提供的软件制作。

---

![bo_d1c3uev7aajc7389qf6g_4_403_157_948_463_0.jpg](images/bo_d1c3uev7aajc7389qf6g_4_403_157_948_463_0.jpg)

Fig. 6 These plots visualize our criteria for identifying suspicious workers to grade. a shows the heavy-tailed distribution of worker contributions to the database. The top workers spent hundreds of hours on our HITs. The red line in plot $\mathbf{b}$ demarcates the average work time across all workers, and the blue lines mark the positive and negative standard deviation from the mean. Work time statistics are particularly useful from identifying scam workers as they typically rush to finish HITs (Color figure online)

图6 这些图展示了我们识别可疑工人评分的标准。a图显示了工人对数据库贡献的重尾分布。顶尖工人在我们的HIT任务上花费了数百小时。图中红线表示所有工人的平均工作时间，蓝线标示均值的正负标准差。工作时间统计对于识别欺诈工人尤为有用，因为他们通常急于完成HIT任务(彩色图在线)

### 3.2 Filtering Bad Workers

### 3.2 过滤不良工人

Deciding whether or not an attribute is present in a scene image is sometimes an ambiguous task. This ambiguity combined with the financial incentive to work quickly leads to sloppy annotation from some workers. In order to filter out those workers who performed poorly, we flag HITs which are outliers with respect to annotation time or labeling frequency. Some attributes, such as 'ice' or 'fire', rarely appear and are visually obvious and thus those HITs can be completed quickly. Other attributes, such as 'man-made' or 'natural light', occur in more than half of all scenes thus the expected completion time per HIT is higher. Any worker whose average number of labels or work time for a given attribute is greater or less than than one standard deviation away from the average for all workers is added to a list of workers to manually review. This way workers who are randomly labeling images and workers who may have been confused by the task are both caught. Workers who clicked images randomly finished faster than workers who considered each image on the HIT. We review by hand a fraction of the HITs for each suspicious worker as well as a random sampling of non-suspicious workers. Any worker whose annotations are clearly wrong is added to a blacklist. They are paid for their time, but none of their labels become part of the final dataset.

判断场景图像中某个属性是否存在有时是一项模糊的任务。这种模糊性加上快速完成工作的经济激励，导致部分工人标注马虎。为了筛除表现不佳的工人，我们标记那些在标注时间或标注频率上属于异常值的HIT。一些属性，如“冰”或“火”，出现频率低且视觉上明显，因此这些HIT可以快速完成。其他属性，如“人造”或“自然光”，出现在超过一半的场景中，因此每个HIT的预期完成时间较长。任何工人在某一属性上的平均标注数量或工作时间超过或低于所有工人平均值一个标准差的，都会被加入人工复审名单。这样既能发现随机标注图像的工人，也能发现可能对任务感到困惑的工人。随机点击图像的工人完成速度快于认真考虑每张图像的工人。我们手工复审每个可疑工人的部分HIT，以及部分非可疑工人的随机样本。任何标注明显错误的工人都会被加入黑名单。他们会获得报酬，但其标注不会纳入最终数据集。

### 3.3 Cultivating Good Workers

### 3.3 培养优秀工人

The pay per HIT is initially $\$ {0.03}$ but increases to $\$ {0.05}$ plus ${10}\%$ bonus after workers have a proven track record of accuracy. The net result of our filtering and bonus scheme is that we cultivate a pool of trained, efficient, and accurate annotators as emphasized by Chen and Dolan (2011). In general, worker accuracy rose over time and we omit over one million early annotations from the final dataset. Worker accuracy improved over time as the workers who did not follow instructions were culled from the pool of workers who were offered the opportunity to complete HITs.

每个HIT的初始报酬为$\$ {0.03}$，但在工人证明其准确性后，报酬提升至$\$ {0.05}$加上${10}\%$的奖金。我们的筛选和奖金机制最终培养出一批训练有素、高效且准确的标注员，正如Chen和Dolan(2011)所强调的。总体而言，工人准确率随时间提升，我们从最终数据集中剔除了超过一百万条早期标注。随着不遵守指令的工人被淘汰，工人准确率逐渐提高，剩余工人获得继续完成HIT的机会。

After labeling the entire dataset once with the general AMT population, we identify a smaller group of 38 trusted workers out of the $\sim  {800}$ who participated. We repeat the labeling process two more times using only these trusted workers. We repeat the labeling process in order to obtain consensus as the presence of some of the scene attributes may be a subjective decision. No worker is allowed to label the same image for the same attribute more than once. The idea of finding and heavily utilizing good workers is in contrast to the "wisdom of the crowds" crowdsourcing strategy where consensus outweighs expertise. Our choice to utilize only workers who give higher quality labels is supported by recent research such as (Lasecki et al. 2011) where good workers were shown to be faster and more accurate than the average of many workers. Figure 6 shows the contributions of all workers to our database.

在使用普通AMT人群对整个数据集进行一次标注后，我们从参与的$\sim  {800}$人中筛选出38名可信工人。随后仅使用这些可信工人重复标注过程两次。重复标注旨在获得共识，因为某些场景属性的存在可能具有主观性。禁止任何工人对同一图像的同一属性进行多次标注。寻找并大量使用优秀工人的策略，与“群体智慧”众包策略形成对比，后者更重视共识而非专业性。我们选择仅使用提供高质量标注的工人，这一做法得到了如Lasecki等人(2011)等近期研究的支持，研究表明优秀工人比多数工人的平均水平更快且更准确。图6展示了所有工人对我们数据库的贡献。

Figure 7 qualitatively shows the result of our annotation process. To quantitatively assess accuracy we manually grade $\sim  {600}$ random positive and $\sim  {600}$ random negative AMT annotations in the database. The population of labels in the dataset is not even ( $8\% /{92}\%$ positive/negative). This does not seem to be an artifact of our interface (which defaults to negative), but rather it seems that scene attributes follow a heavy-tailed distribution with a few being very common (e.g. 'natural') and most being rare (e.g. 'wire').

图7定性展示了我们的标注过程结果。为定量评估准确性，我们手工评估了数据库中$\sim  {600}$个随机正面和$\sim  {600}$个随机负面AMT标注。数据集中标签的分布不均($8\% /{92}\%$正面/负面)。这似乎不是界面设计的结果(界面默认负面)，而是场景属性呈重尾分布，少数属性非常常见(如“自然”)，大多数属性较为罕见(如“电线”)。

We graded equal numbers of positive and negative labels to understand if there was a disparity in accuracy between them. For both types of annotation, we find $\sim  {93}\%$ of labels to be reasonable, which means that we as experts would agree with the annotation.

我们评估了等量的正面和负面标签，以了解两者准确率是否存在差异。对于两种类型的标注，我们发现$\sim  {93}\%$的标签是合理的，意味着作为专家我们会同意该标注。

![bo_d1c3uev7aajc7389qf6g_5_154_150_1454_824_0.jpg](images/bo_d1c3uev7aajc7389qf6g_5_154_150_1454_824_0.jpg)

Fig. 7 The images in the table above are grouped by the number of positive labels (votes) they received from AMT workers. From left to right the visual presence of each attribute increases. AMT workers are instructed to positively label an image if the functional attribute is likely to occur in that image, not just if it is actually occurring. For material, surface property, or spatial envelope attributes, workers were instructed to positively label images only if the attribute is present

图7 上表中的图像按AMT工人给予的正面标签(投票)数量分组。从左到右，每个属性的视觉存在感逐渐增强。AMT工人被指示，如果功能性属性可能出现在图像中，则应给予正面标注，而不仅仅是实际出现。对于材质、表面属性或空间包络属性，工人被指示仅在属性实际存在时给予正面标注。

In the following sections, our experiments rely on the consensus of multiple annotators rather than individual annotations. This increases the accuracy of our labels. For each of our 102 attributes, we manually grade 5 scenes where the consensus was positive ( 2 or 3 votes) and likewise for negative ( 0 votes). We find that if 2 out of 3 annotations agree on a positive label, that label is reasonable $\sim  {95}\%$ of the time. Many attributes are very rare, and there would be a significant loss in the population of the rare attributes if consensus was defined as $3/3$ positive labels. Allowing for $2/3$ positive labels to be the consensus standard increases the population of rare attributes without degrading the quality of the labels.

在以下各节中，我们的实验依赖于多位标注者的共识，而非单个标注。这提高了标签的准确性。对于我们102个属性中的每一个，我们手动评估了5个共识为正面(2或3票)和5个共识为负面(0票)的场景。我们发现，如果3个标注中有2个同意为正面标签，则该标签在$\sim  {95}\%$的时间内是合理的。许多属性非常罕见，如果将共识定义为$3/3$个正面标签，罕见属性的样本数量将大幅减少。允许$2/3$个正面标签作为共识标准，可以在不降低标签质量的前提下增加罕见属性的样本数量。

## 4 Exploring Scenes in Attribute Space

## 4 在属性空间中探索场景

Now that we have a database of attribute-labeled scenes we can attempt to visualize that space of attributes. In Fig. 8 we show all 14,340 of our scenes projected onto two dimensions by t-SNE dimensionality reduction (Van der Maaten and Hinton 2008). We sample several points in this space to show the types of scenes present as well as the nearest neighbors to those scenes in attribute space. For this analysis the distance between scenes is simply the Euclidean distance between their real-valued, 102-dimensional attribute vectors.

现在我们拥有了一个带属性标签的场景数据库，可以尝试可视化该属性空间。在图8中，我们展示了通过t-SNE降维(Van der Maaten和Hinton 2008)将全部14,340个场景投影到二维空间的结果。我们在该空间中采样若干点，展示存在的场景类型及这些场景在属性空间中的最近邻。对于本分析，场景间的距离即为它们102维实值属性向量的欧氏距离。

To better understand where images with different attributes live in attribute space, Fig. 9 illustrates where dataset images that contain different attributes live in this 2D version of the attribute feature space.

为了更好地理解具有不同属性的图像在属性空间中的分布，图9展示了包含不同属性的数据集图像在该二维属性特征空间中的位置。

Figure 10 shows the distribution of images from 15 scene categories in attribute space. The particular scene categories were chosen to be close to those categories in the 15 scene benchmark (Lazebnik et al. 2006). In this low dimensional visualization, many of the categories have considerable overlap (e.g. bedroom with living room, street with highway, city with skyscraper). This is reasonable because these overlapping categories share affordances, materials, and layouts. With the full 102 dimensional attribute representation, these scenes could still be differentiated and we examine this task in Sect. 6.

图10展示了15个场景类别的图像在属性空间中的分布。这些特定场景类别选取接近15场景基准(Lazebnik等，2006)中的类别。在这个低维可视化中，许多类别存在较大重叠(例如卧室与客厅，街道与高速公路，城市与摩天大楼)。这是合理的，因为这些重叠类别共享功能、材料和布局。利用完整的102维属性表示，这些场景仍可区分，我们将在第6节中探讨该任务。

## 5 Recognizing Scene Attributes

## 5 场景属性识别

A motivation for creating the SUN Attribute dataset is to enable deeper understanding of scenes. For scene attributes to be useful they need to be machine recognizable. To assess the difficulty of scene attribute recognition we perform experiments using the features and kernels which achieve state of the art category recognition on the SUN database. In Xiao et al. (2010) show that a combination of several scene descriptors results in a significantly more powerful classifier than any individual feature. Accordingly, our classifiers use a combination of kernels generated from gist, HOG $2 \times  2$ , self-similarity, and geometric context color histogram features [see (Xiao et al. 2010) for feature and kernel details]. These four features were chosen because they are each individually powerful and because they can describe distinct visual phenomena.

创建SUN属性数据集的动机是实现对场景的更深入理解。为了使场景属性有用，它们需要能够被机器识别。为评估场景属性识别的难度，我们使用在SUN数据库上实现最先进类别识别的特征和核函数进行实验。Xiao等(2010)表明，结合多种场景描述符能显著提升分类器性能，优于任何单一特征。因此，我们的分类器采用由gist、HOG$2 \times  2$、自相似性和几何上下文颜色直方图特征生成的核函数组合[详见(Xiao等，2010)关于特征和核函数的细节]。选择这四种特征是因为它们各自强大且能描述不同的视觉现象。

![bo_d1c3uev7aajc7389qf6g_6_237_156_1278_847_0.jpg](images/bo_d1c3uev7aajc7389qf6g_6_237_156_1278_847_0.jpg)

Fig. 8 2D visualization of the SUN Attribute dataset. Each image in the dataset is represented by the projection of its 102-dimensional attribute feature vector onto two dimensions using t-Distributed Stochastic Neighbor Embedding (Van der Maaten and Hinton 2008). There are groups of nearest neighbors, each designated by a color. Interestingly, while the nearest-neighbor scenes in attribute space are semantically very similar, for most of these examples (underwater_ocean, abbey, coast, ice skating rink, field_wild, bistro, office) none of the nearest neighbors actually fall in the same SUN database category. The colored border lines delineate the approximate separation of images with and without the attribute associated with the border. Figure best viewed in color (Color figure online)

图8 SUN属性数据集的二维可视化。数据集中每张图像由其102维属性特征向量通过t-分布随机邻域嵌入(Van der Maaten和Hinton 2008)投影到二维空间表示。存在若干最近邻群组，每组以不同颜色标示。有趣的是，虽然属性空间中的最近邻场景语义非常相似，但对于大多数示例(如水下海洋、修道院、海岸、溜冰场、野外田野、小酒馆、办公室)，其最近邻实际上并不属于SUN数据库中的同一类别。彩色边框线划分了带有或不带有边框所示属性的图像的大致分界。建议彩色查看(彩色图在线)

![bo_d1c3uev7aajc7389qf6g_6_146_1257_1465_444_0.jpg](images/bo_d1c3uev7aajc7389qf6g_6_146_1257_1465_444_0.jpg)

Fig. 9 Distributions of scenes with the given attribute. This set of reduced dimensionality plots highlights the populations of images with the listed attributes. Grey points are images that do not contain the given attribute. The boldness of the colored points is proportional to the amount of votes given for that attribute in an image, e.g. darkest colored points have 3 votes. 'Enclosed area' and 'open area' seem to

图9 具有给定属性的场景分布。这组降维图突出显示了带有所列属性的图像群体。灰色点表示不含该属性的图像。彩色点的粗细与该图像中该属性的投票数成正比，例如最深色点有3票。“封闭区域”和“开放区域”似乎

have a strong effect on the layout of scenes in "attribute space". As one might hope, they generally occupy mutual exclusive areas. It is interesting to note that 'sailing/boating' occurs in two distinct regions which correspond to open water scenes and harbor scenes (Color figure online)

对“属性空间”中场景布局有显著影响。正如预期，它们通常占据互斥区域。有趣的是，“航行/划船”出现在两个不同区域，分别对应开放水域场景和港口场景(彩色图在线)

![bo_d1c3uev7aajc7389qf6g_7_146_152_706_694_0.jpg](images/bo_d1c3uev7aajc7389qf6g_7_146_152_706_694_0.jpg)

Fig. 10 Location of member images of 15 scene categories in attribute space. Figure best viewed in color (Color figure online)

图10 15个场景类别成员图像在属性空间中的位置。建议彩色查看(彩色图在线)

### 5.1 How Hard is it to Recognize Attributes?

### 5.1 识别属性有多难？

To recognize attributes in images, we create an individual classifier for each attribute using random splits of the SUN Attribute dataset for training and testing data. Note that our training and test splits are scene category agnostic-for the purpose of this section we simply have a pool of 14,340 images with varying attributes. We treat an attribute as present if it receives at least two votes, i.e. consensus is established, and absent if it receives zero votes. As shown in Fig. 7, images with a single vote tend to be in a transition state between the attribute being present or absent so they are excluded from these experiments.

为了识别图像中的属性，我们为每个属性创建了一个独立的分类器，使用SUN属性数据集的随机划分作为训练和测试数据。注意，我们的训练和测试划分不考虑场景类别——在本节中，我们仅有一个包含14,340张具有不同属性的图像池。我们将属性视为存在，当且仅当它获得至少两个投票，即达成共识；若投票为零，则视为不存在。如图7所示，获得单票的图像往往处于属性存在与不存在的过渡状态，因此在这些实验中被排除。

We train and evaluate independent classifiers for each attribute. Correlation between attributes could make 'multi-label' classification methods advantageous, but we choose to predict attributes independently. For each attribute we wish to recognize, we first evaluate SVM classifiers trained independently on each of our four features. We report their performance in Fig. 11. To train a classifier which uses all features, we construct a combined kernel from a linear combination of individual feature kernels. Each classifier is trained on 300 images and tested on 50 images and AP is computed over five random splits. Each classifier's train and test sets are half positive and half negative even though most attributes are sparse (i.e. usually absent). We fix the positive to negative ratio so that we can compare the intrinsic difficulty of recognizing each attribute without being influenced by attribute popularity.

我们为每个属性训练并评估独立的分类器。属性之间的相关性可能使“多标签”分类方法更具优势，但我们选择独立预测属性。对于每个希望识别的属性，我们首先评估在四种特征上独立训练的支持向量机(SVM)分类器。其性能如图11所示。为了训练使用所有特征的分类器，我们通过线性组合各个特征核构建了一个组合核。每个分类器在300张图像上训练，在50张图像上测试，平均精度(AP)通过五次随机划分计算。每个分类器的训练和测试集均为正负样本各半，尽管大多数属性较为稀疏(即通常不存在)。我们固定正负样本比例，以便比较识别各属性的内在难度，而不受属性流行度影响。

Figure 11 shows that the combined classifier outperforms any individual feature. Not all attributes are equally easy to recognize Fig. 12a plots the average precision for each attribute's combined feature SVM. It is clear from Fig. 12a that certain attributes, especially some surface properties and spatial envelope attributes, are particularly difficult to recognize with our global image features.

图11显示，组合分类器优于任何单一特征分类器。并非所有属性都同样容易识别，图12a绘制了每个属性组合特征SVM的平均精度。从图12a可以明显看出，某些属性，尤其是一些表面属性和空间包络属性，使用我们的全局图像特征识别起来特别困难。

![bo_d1c3uev7aajc7389qf6g_7_904_156_700_547_0.jpg](images/bo_d1c3uev7aajc7389qf6g_7_904_156_700_547_0.jpg)

Fig. 11 Average Precision values averaged for all attributes. The combined feature classifier is more accurate than any individual feature classifier. Average Precision steadily increases with more training data

图11 所有属性的平均精度值平均。组合特征分类器比任何单一特征分类器更准确。随着训练数据增多，平均精度稳步提升。

Figure 12a evaluates attribute recognition with fixed proportions of positive and negative examples. However, some attributes are vastly more popular than others in the real world. To evaluate attribute recognition under more realistic conditions, and to make use of as much training data as the SUN attribute database affords us, we train classifiers on 90% of the dataset and test on the remaining ${10}\%$ . This means that some attributes (e.g. 'natural' will have thousands of positive examples, and others e.g. 'smoke' will have barely 100 ). Likewise, chance is different for each attribute because the test sets are similarly skewed. The train and test instances for each attribute vary slightly because some images have confident labels for certain attributes and ambiguous labels for others and again we only use scenes with confident ground truth labels for each particular attribute classifier. Figure 12b shows the AP scores for these large scale classifiers.

图12a在固定正负样本比例下评估属性识别。然而，现实中某些属性远比其他属性更为常见。为了在更真实的条件下评估属性识别，并充分利用SUN属性数据库提供的训练数据，我们使用90%的数据集训练分类器，剩余部分测试${10}\%$。这意味着某些属性(如“自然”)有数千个正样本，而其他属性(如“烟雾”)仅有不到100个。同样，由于测试集分布偏斜，每个属性的随机准确率也不同。每个属性的训练和测试实例略有不同，因为部分图像对某些属性标签明确，而对其他属性标签模糊，我们仅使用对特定属性具有明确真实标签的场景。图12b展示了这些大规模分类器的AP得分。

For these classifiers, we averaged the kernels from each feature. With the larger training set, there was no observed benefit to weighting individual feature kernels differently. Figure ${12}\mathrm{\;b}$ demonstrates how more popular attributes are easier to recognize, as expected. Overall, the average AP scores for different types of attributes are similar-functions/affordances (AP 0.44), materials (AP 0.51 ), surface properties (AP 0.50 ), and spatial envelope (AP 0.62).

对于这些分类器，我们对各特征的核进行了平均。使用更大的训练集时，未观察到对单个特征核加权有益。图${12}\mathrm{\;b}$展示了更流行的属性识别更容易，符合预期。总体而言，不同类型属性的平均AP得分相近——功能/用途(AP 0.44)、材料(AP 0.51)、表面属性(AP 0.50)和空间包络(AP 0.62)。

![bo_d1c3uev7aajc7389qf6g_8_160_147_1440_1173_0.jpg](images/bo_d1c3uev7aajc7389qf6g_8_160_147_1440_1173_0.jpg)

Fig. 12 a 300 training/50 test examples; training and testing sets have a balance positive to negative example ratio. The AP of chance selection is marked by the red line. AP scores are often high even when the visual manifestation of such attributes are subtle. This plot show that it is possible to recognize global scene attributes. Attributes that occur fewer than 350 times in the dataset were not included in this plot. b ${90}\%$ of the dataset for training/10% for test. All of the scene attributes are included in this plot. Chance is different for every attribute as they appear with variable frequency in nature. Note that the most difficult to recognize attributes are also the rarest. Many attributes that are not strongly visual such as 'studying', 'spectating', or 'farming' are nonetheless relatively easy to recognize. Average precision for attribute classifiers

图12a 300个训练/50个测试样本；训练和测试集正负样本比例平衡。随机选择的AP由红线标示。即使属性的视觉表现细微，AP得分通常也较高。该图表明识别全局场景属性是可行的。数据集中出现次数少于350次的属性未包含在此图中。b 使用数据集的${90}\%$进行训练/10%进行测试。此图包含所有场景属性。由于属性在自然界中出现频率不同，随机准确率因属性而异。注意，最难识别的属性也是最稀有的。许多非强视觉属性如“学习”、“观赛”或“耕作”仍相对容易识别。属性分类器的平均精度。

The classifiers used for Fig. 12b and the code used to generate them are publicly available. ${}^{3}$ The attribute classifiers trained on ${90}\%$ of the SUN Attribute dataset are employed in all further experiments in this paper.

用于图12b的分类器及生成它们的代码已公开。${}^{3}$基于SUN属性数据集${90}\%$训练的属性分类器被用于本文后续所有实验。

### 5.2 Attribute Classifiers in the Wild

### 5.2 野外属性分类器

We show qualitative results of our attribute classifiers in Fig. 13. Our attribute classifiers perform well at recognizing attributes in a variety of contexts. Most of the attributes with strong confidence are indeed present in the images. Likewise, the lowest confidence attributes are clearly not present. It is particularly interesting that function/affordance attributes and surface property attributes are often recognized with stronger confidence than other types of attributes even though functions and surface properties are complex concepts that may not be easy to define visually. For example the golf course test image in Fig. 13 shows that our classifiers can successfully identify such abstract concepts as 'sports' and 'competing' for a golf course, which is visually quite similar to places where no sports would occur. Abstract concepts such as 'praying' and 'aged/worn' are also recognized correctly in both the abbey and mosque scenes in Fig. 13. Figure 14 shows several cases where the most confidently detected attributes are incorrect.

我们在图13中展示了属性分类器的定性结果。我们的属性分类器在多种情境下对属性的识别表现良好。大多数置信度较高的属性确实存在于图像中。同样，置信度最低的属性显然不存在。特别有趣的是，功能/可供性(affordance)属性和表面特性属性通常比其他类型的属性识别得更有信心，尽管功能和表面特性是复杂的概念，视觉上不易定义。例如，图13中的高尔夫球场测试图像显示我们的分类器能够成功识别诸如“运动”和“竞赛”等抽象概念，而高尔夫球场在视觉上与不进行运动的场所非常相似。图13中的修道院和清真寺场景中，“祈祷”和“陈旧/磨损”等抽象概念也被正确识别。图14展示了若干置信度最高但识别错误的属性案例。

---

${}^{3}$ SUN Attribute Classifiers along with the full SUN Attribute dataset and associated code are available at www.cs.brown.edu/~gen/ sunattributes.html.

${}^{3}$ SUN属性分类器及完整的SUN属性数据集和相关代码可在 www.cs.brown.edu/~gen/sunattributes.html 获取。

---

<table><tr><td>Test Scene Images</td><td>Detected Attributes</td></tr><tr><td/><td>Most Confident Attributes: vegetation, open area, sunny, sports, natural light, no horizon, foliage, competing, rail- ing, natural Least Confident Attributes: studying, gaming, fire, carpet, tiles, smoke, medical, cleaning, sterile, marble</td></tr><tr><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_9.jpg?x=151&y=389&w=281&h=203&r=0"/> </td><td>Most Confident Attributes: shrubbery, flowers, camping, rugged scene, hik- ing, dirt/soil, leaves, natural light, vegetation, rock/stone Least Confident Attributes: shingles, ice, railroad, cleaning, marble, sterile, smoke, gaming, tiles, medical</td></tr><tr><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_9.jpg?x=157&y=609&w=274&h=191&r=0"/> </td><td>Most Confident Attributes: eating, so- cializing, waiting in line, cloth, shop- ping, reading, stressful, congregating, man-made, plastic Least Confident Attributes: gaming, running water, tiles, railroad, waves/ surf, building, fire, bathing, ice, smoke</td></tr><tr><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_9.jpg?x=152&y=840&w=280&h=211&r=0"/> </td><td>Most Confident Attributes: vertical components, vacationing, natural light, shingles, man-made, praying, symmetrical, semi-enclosed area, aged/ worn, brick Least Confident Attributes: railroad, ice, scary, medical, shopping, tiles, cleaning, sterile, digging, gaming</td></tr><tr><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_9.jpg?x=152&y=1083&w=281&h=194&r=0"/> </td><td>Most Confident Attributes: vertical components, brick, natural light, praying, vacationing, man-made, pavement, sunny, open area, rusty Least Confident Attributes: ice, smoke, bathing, marble, vinyl, cleaning, fire, tires, gaming, sterile</td></tr></table>

<table><tbody><tr><td>测试场景图像</td><td>检测到的属性</td></tr><tr><td></td><td>最有信心的属性:植被、开阔区域、晴朗、运动、自然光、无地平线、树叶、竞争、栏杆、自然 最无信心的属性:学习、游戏、火、地毯、瓷砖、烟雾、医疗、清洁、无菌、大理石</td></tr><tr><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_9.jpg?x=151&y=389&w=281&h=203&r=0"/> </td><td>最有信心的属性:灌木丛、花卉、露营、崎岖场景、徒步、泥土/土壤、树叶、自然光、植被、岩石/石头 最无信心的属性:瓦片、冰、铁路、清洁、大理石、无菌、烟雾、游戏、瓷砖、医疗</td></tr><tr><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_9.jpg?x=157&y=609&w=274&h=191&r=0"/> </td><td>最有信心的属性:进食、社交、排队、布料、购物、阅读、压力大、聚集、人造、塑料 最无信心的属性:游戏、流水、瓷砖、铁路、波浪/冲浪、建筑、火、洗澡、冰、烟雾</td></tr><tr><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_9.jpg?x=152&y=840&w=280&h=211&r=0"/> </td><td>最有信心的属性:垂直构件、度假、自然光、瓦片、人造、祈祷、对称、半封闭区域、陈旧/磨损、砖块 最无信心的属性:铁路、冰、恐怖、医疗、购物、瓷砖、清洁、无菌、挖掘、游戏</td></tr><tr><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_9.jpg?x=152&y=1083&w=281&h=194&r=0"/> </td><td>最有信心的属性:垂直构件、砖块、自然光、祈祷、度假、人造、人行道、晴朗、开阔区域、生锈 最无信心的属性:冰、烟雾、洗澡、大理石、乙烯基、清洁、火、轮胎、游戏、无菌</td></tr></tbody></table>

Fig. 13 Attribute detection. For each query, the most confidently recognized attributes (green) are indeed present in the test images, and the least confidently recognized attributes (red) are either the visual opposite of what is in the image or they are irrelevant to the image (Color figure online)

图13 属性检测。对于每个查询，最有信心识别的属性(绿色)确实出现在测试图像中，而最不自信识别的属性(红色)要么是图像中视觉上的相反，要么与图像无关(彩色图在线)

In earlier attribute work where the attributes were discovered on smaller datasets, attributes had the problem of being strongly correlated with each other (Farhadi et al. 2009). This is less of an issue with the SUN Attribute dataset because the dataset is larger and attributes are observed in many different contexts. For instance, attributes such as "golf" and "grass" are correlated with each other, as they should be. But the correlation is not so high that a "golf" classifier can simply learn the "grass" visual concept, because the dataset contains thousands of training examples where "grass" is present but "golf" is not possible. However, some of our attributes, specifically those related to vegetation, do seem overly correlated with each other because the concepts are not semantically distinct enough.

在早期的属性研究中，由于属性是在较小的数据集上发现的，属性之间存在强相关性的问题(Farhadi 等，2009)。在SUN属性数据集中，这一问题较少，因为数据集更大，属性在许多不同的上下文中被观察到。例如，“高尔夫”(golf)和“草地”(grass)这两个属性是相关的，这是合理的。但相关性并不高到“高尔夫”分类器可以简单地学习“草地”的视觉概念，因为数据集中包含数千个训练样本，其中“草地”存在但“不可能有高尔夫”。然而，我们的一些属性，特别是与植被相关的属性，确实显得过于相关，因为这些概念在语义上区分度不够。

Figure 15 shows the most confident classifications in our test set for various attributes. Many of the false positives, highlighted in red, are reasonable from a visual similarity point of view. 'Cold', 'moist/damp', and 'eating' all have false positives that could be reasonably considered to be confusing. 'Stressful' and 'vacationing' have false positives that could be subjectively judged to be correct-a crowded subway car could be stressful, and the New Mexico desert could be a lovely vacation spot.

图15展示了我们测试集中各种属性的最有信心分类结果。许多假阳性(红色标出)从视觉相似性的角度来看是合理的。“寒冷”、“潮湿/湿润”和“进食”都有可能被合理认为是混淆的假阳性。“压力大”和“度假”这两个属性的假阳性可以主观判断为正确——拥挤的地铁车厢可能令人感到压力大，新墨西哥沙漠可能是一个美丽的度假胜地。

<table><tr><td>Test Images</td><td>Detected Attributes</td></tr><tr><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_9.jpg?x=906&y=191&w=297&h=198&r=0"/> </td><td>Most Confident Attributes: swim- ming, asphalt, open area, sports, sunbathing, natural light, diving, still water, exercise, soothing Least Confident Attributes: tiles, smoke, ice, sterile, praying, marble, railroad, cleaning, medical activity, gaming</td></tr><tr><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_9.jpg?x=910&y=416&w=291&h=198&r=0"/> </td><td>Most Confident Attributes: cold, con- crete, snow, sand, stressful, aged/ worn, dry, climbing, rugged scene, rock/stone Least Confident Attributes: medical activity, spectating, marble, cleaning, waves/ surf, railroad, gaming, build- ing, shopping, tiles</td></tr><tr><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_9.jpg?x=918&y=655&w=276&h=349&r=0"/> </td><td>Most Confident Attributes: carpet, enclosed area no horizon, elec- tric/indoor lighting, concrete, glossy, cloth, working, dry, rubber/ plastic Least Confident Attributes: trees, ocean, digging, open area, scary, smoke, ice, railroad, constructing/ building, waves/ surf</td></tr></table>

<table><tbody><tr><td>测试图像</td><td>检测到的属性</td></tr><tr><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_9.jpg?x=906&y=191&w=297&h=198&r=0"/> </td><td>最有信心的属性:游泳、沥青、开阔区域、运动、日光浴、自然光、潜水、静水、锻炼、舒缓 最无信心的属性:瓷砖、烟雾、冰、无菌、祈祷、大理石、铁路、清洁、医疗活动、游戏</td></tr><tr><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_9.jpg?x=910&y=416&w=291&h=198&r=0"/> </td><td>最有信心的属性:寒冷、混凝土、雪、沙、压力大、陈旧/磨损、干燥、攀爬、崎岖场景、岩石/石头 最无信心的属性:医疗活动、观赛、大理石、清洁、波浪/冲浪、铁路、游戏、建筑、购物、瓷砖</td></tr><tr><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_9.jpg?x=918&y=655&w=276&h=349&r=0"/> </td><td>最有信心的属性:地毯、封闭区域无地平线、电动/室内照明、混凝土、有光泽、布料、工作、干燥、橡胶/塑料 最无信心的属性:树木、海洋、挖掘、开阔区域、恐怖、烟雾、冰、铁路、建筑/施工、波浪/冲浪</td></tr></tbody></table>

Fig. 14 Failure cases. In the top image, it seems the smooth, blue regions of the car appear to have created false positive detections of 'swimming', 'diving', and 'still water'. The bottom images, unlike all of our training data, is a close-up object view rather than a scene with spatial extent. The attribute classifiers seem to interpret the cat as a mountain landscape and the potato chips bag as several different materials 'carpet', 'concrete', 'glossy', and 'cloth'

图14 失败案例。顶部图像中，汽车光滑的蓝色区域似乎导致了“游泳”、“潜水”和“静水”的误报。底部图像与我们所有训练数据不同，是一个特写物体视角，而非具有空间范围的场景。属性分类器似乎将猫误判为山地景观，将薯片袋误判为多种不同材质“地毯”、“混凝土”、“光滑”和“布料”。

### 5.3 Correlation of Attributes and Scene Categories

### 5.3 属性与场景类别的相关性

To better understand the relationships between categories and attributes, Table 1 lists a number of examples from the SUN 397 categories with the attribute that is most strongly correlated with each category.

为了更好地理解类别与属性之间的关系，表1列出了SUN 397类别中与每个类别最强相关的属性示例。

The correlation between the scene category and the attribute feature of an input image is calculated using Pearson's correlation. We calculate correlation between the predicted attribute feature vectors for 50 examples from each of the SUN 397 categories and a feature vectors that indicate the category membership of the example images.

场景类别与输入图像属性特征之间的相关性通过皮尔逊相关系数计算。我们计算了SUN 397每个类别50个样本的预测属性特征向量与表示类别归属的特征向量之间的相关性。

![bo_d1c3uev7aajc7389qf6g_10_145_158_702_1376_0.jpg](images/bo_d1c3uev7aajc7389qf6g_10_145_158_702_1376_0.jpg)

Fig. 15 Top 5 most confident detections in test set. For each attribute, the top five detections from the test set are shown. Images boxed in green are true positives, and red are false positives. Examples of false positives, such as the 'praying' examples, show how attributes are identified in images that arguably contain the attribute, but human annotators disagreed about the attribute's presence; in this case the false positives were a sacristy, which is a room for the storage of religious items, and a cathedral pictured at a distance. The false positive for 'glass' also contain glass, although photographed under glancing illumination, which may have caused the human annotators to mislabel it. For several of the examples, all of the top 5 detections are true positives. The detections for 'brick', 'metal', and 'competing' demonstrate the ability of attribute classifiers to recognize the presence of attributes in scenes that are quite visually dissimilar. For 'brick' and 'metal' even the kinds of bricks and metals shown are differ greatly in type, age, and use case. Figure best viewed in color (Color figure online)

图15 测试集中置信度最高的前五个检测结果。每个属性展示测试集中置信度最高的五个检测。绿色框为真阳性，红色框为假阳性。假阳性示例，如“祈祷”，展示了属性在图像中被识别的情况，这些图像中可能包含该属性，但人工标注者对属性是否存在存在分歧；此处假阳性为圣器室(用于存放宗教物品的房间)和远景中的大教堂。“玻璃”假阳性图像中也含有玻璃，但因斜射光照可能导致人工标注错误。部分属性的前五个检测均为真阳性。“砖块”、“金属”和“竞争”属性的检测展示了属性分类器识别视觉差异较大场景中属性的能力。对于“砖块”和“金属”，即使砖块和金属的种类、年代和用途差异很大。图中彩色显示效果最佳(彩色图在线)。

Table 1 has many interesting examples where an attribute is strongly correlated with visually dissimilar but semantically related categories, such as 'praying' for both the indoor and outdoor church categories. Even attributes that are quite abstract concepts, such as 'socializing' and 'stressful', are the most strongly correlated attributes for 'pub/indoor' and 'cockpit', respectfully. Scene attributes capture information that is intrinsic to the nature of scenes and how humans interact with them.

表1中有许多有趣的例子，属性与视觉差异较大但语义相关的类别强相关，例如“祈祷”属性同时与室内和室外教堂类别强相关。即使是较为抽象的概念属性，如“社交”和“紧张”，分别是“酒吧/室内”和“驾驶舱”类别最强相关的属性。场景属性捕捉了场景本质及人类与之交互的信息。

## 6 Predicting Scene Categories from Attributes

## 6 从属性预测场景类别

In this section we measure how well we can predict scene category from attributes. While the goal of this paper and our database is not necessarily to improve the task of scene categorization, this analysis does give some insight into the interplay between scene categories and scene attributes.

本节中我们评估从属性预测场景类别的效果。虽然本文及数据库的目标不一定是提升场景分类任务，但该分析有助于理解场景类别与场景属性之间的相互关系。

Attributes allow for the exploration of scenes using information that is complementary to the category labels of those scenes. Because attributes are powerful descriptors of scenes, they can also be used as a feature to predict scene categories. To the best of our knowledge these experiments are the first to explore the use of attributes as features for scene classification. As with objects (Lampert et al. 2009), attributes also offer the opportunity to learn new scene categories without using any training examples for the new categories. This "zero-shot" learning for scenes will also be explored.

属性允许利用与场景类别标签互补的信息来探索场景。由于属性是场景的强描述符，也可用作预测场景类别的特征。据我们所知，这些实验首次探讨了将属性用作场景分类特征。与物体分类(Lampert等，2009)类似，属性还提供了无需新类别训练样本即可学习新场景类别的可能性。本文也将探讨这种“零样本”学习(zero-shot learning)场景。

We evaluate the task of classifying all 397 categories of the SUN 397 dataset (Xiao et al. 2010) using our 102 attribute classifiers as an intermediate representation. We compare this to scene recognition using recent low-level features. We also compare to classifiers trained with ground-truth attributes to derive a scene classification upper bound for our attribute taxonomy. Finally, we evaluate zero-shot learning scenarios where an oracle provides attribute distributions for all categories and we use our classifiers to estimate attributes for query instances.

我们使用102个属性分类器作为中间表示，评估对SUN 397数据集(Xiao等，2010)中所有397个类别的分类任务。并与使用近期低级特征的场景识别方法进行比较。还与使用真实属性训练的分类器比较，以推导属性分类体系的场景分类上限。最后评估零样本学习场景，其中由oracle提供所有类别的属性分布，我们用分类器估计查询实例的属性。

One hundred binary attributes alone could potentially predict membership in 397 categories if the attributes were (1) independent and (2) consistent within each category, but neither of these are true. Many of the attributes are correlated (e.g. farming and open area) and there is significant attribute variation within categories. Furthermore, many groups of SUN database scenes would require very specific attributes to distinguish them (e.g. forest/needleleaf and forest/broadleaf), so it would likely take several hundred attributes to very accurately predict scene categories.

仅凭100个二元属性理论上可预测397个类别的归属，前提是属性(1)相互独立且(2)在每个类别内一致，但这两点均不成立。许多属性相关(如“农耕”和“开阔区域”)，且类别内属性变化显著。此外，SUN数据库中许多场景组需要非常具体的属性来区分(如针叶林与阔叶林)，因此可能需要数百个属性才能非常准确地预测场景类别。

Table 1 Most correlated attributes

表1 最相关属性

<table><tr><td>Category</td><td>Most corr. attribute</td><td>Pearson's corr. coef</td></tr><tr><td>Airport terminal</td><td>Socializing</td><td>0.051</td></tr><tr><td>Art studio</td><td>Cluttered space</td><td>0.039</td></tr><tr><td>Assembly line</td><td>Working</td><td>0.055</td></tr><tr><td>Athletic field/outdoor</td><td>Playing</td><td>0.116</td></tr><tr><td>Auditorium</td><td>Spectating</td><td>0.096</td></tr><tr><td>Ball pit</td><td>Rubber/plastic</td><td>0.149</td></tr><tr><td>Baseball field</td><td>Sports</td><td>0.088</td></tr><tr><td>Basilica</td><td>Praying</td><td>0.101</td></tr><tr><td>Basketball court/outdoor</td><td>Exercise</td><td>0.074</td></tr><tr><td>Bathroom</td><td>Cleaning</td><td>0.092</td></tr><tr><td>Bayou</td><td>Still water</td><td>0.092</td></tr><tr><td>Bedroom</td><td>Carpet</td><td>0.054</td></tr><tr><td>Biology laboratory</td><td>Research</td><td>0.053</td></tr><tr><td>Bistro/indoor</td><td>Eating</td><td>0.055</td></tr><tr><td>Bookstore</td><td>Shopping</td><td>0.079</td></tr><tr><td>Bowling alley</td><td>Competing</td><td>0.055</td></tr><tr><td>Boxing ring</td><td>Spectating</td><td>0.049</td></tr><tr><td>Campsite</td><td>Camping</td><td>0.053</td></tr><tr><td>Canal/natural</td><td>Still water</td><td>0.080</td></tr><tr><td>Canal/urban</td><td>Sailing/boating</td><td>0.038</td></tr><tr><td>Canyon</td><td>Rugged scene</td><td>0.110</td></tr><tr><td>Car interior/backseat</td><td>Matte</td><td>0.079</td></tr><tr><td>Car interior/frontseat</td><td>Matte</td><td>0.098</td></tr><tr><td>Casino/indoor</td><td>Gaming</td><td>0.070</td></tr><tr><td>Catacomb</td><td>Digging</td><td>0.081</td></tr><tr><td>Chemistry lab</td><td>Research</td><td>0.067</td></tr><tr><td>Chicken coop/indoor</td><td>Dirty</td><td>0.039</td></tr><tr><td>Chicken coop/outdoor</td><td>Fencing</td><td>0.045</td></tr><tr><td>Cathedral/indoor</td><td>Praying</td><td>0.148</td></tr><tr><td>Church/outdoor</td><td>Praying</td><td>0.088</td></tr><tr><td>Classroom</td><td>Studying/learning</td><td>0.070</td></tr><tr><td>Clothing store</td><td>Cloth</td><td>0.063</td></tr><tr><td>Cockpit</td><td>Stressful</td><td>0.048</td></tr><tr><td>Construction site</td><td>Constructing/building</td><td>0.041</td></tr><tr><td>Corn field</td><td>Farming</td><td>0.111</td></tr><tr><td>Cottage garden</td><td>Flowers</td><td>0.106</td></tr><tr><td>Dentists office</td><td>Medical activity</td><td>0.070</td></tr><tr><td>Dining room</td><td>Eating</td><td>0.064</td></tr><tr><td>Electrical substation</td><td>Wire</td><td>0.054</td></tr><tr><td>Factory/indoor</td><td>Working</td><td>0.047</td></tr><tr><td>Fastfood restaurant</td><td>Waiting in line</td><td>0.057</td></tr><tr><td>Fire escape</td><td>Railing</td><td>0.051</td></tr><tr><td>Forest path</td><td>Hiking</td><td>0.111</td></tr><tr><td>Forest road</td><td>Foliage</td><td>0.095</td></tr><tr><td>Fountain</td><td>Running water</td><td>0.041</td></tr><tr><td>Ice skating rink/indoor</td><td>Sports</td><td>0.058</td></tr><tr><td>Ice skating rink/outdoor</td><td>Cold</td><td>0.065</td></tr></table>

<table><tbody><tr><td>类别</td><td>相关性最高的属性</td><td>皮尔逊相关系数</td></tr><tr><td>机场航站楼</td><td>社交</td><td>0.051</td></tr><tr><td>艺术工作室</td><td>杂乱空间</td><td>0.039</td></tr><tr><td>装配线</td><td>工作中</td><td>0.055</td></tr><tr><td>运动场/户外</td><td>玩耍</td><td>0.116</td></tr><tr><td>礼堂</td><td>观赛</td><td>0.096</td></tr><tr><td>球坑</td><td>橡胶/塑料</td><td>0.149</td></tr><tr><td>棒球场</td><td>体育运动</td><td>0.088</td></tr><tr><td>大教堂</td><td>祈祷</td><td>0.101</td></tr><tr><td>篮球场/户外</td><td>锻炼</td><td>0.074</td></tr><tr><td>浴室</td><td>清洁</td><td>0.092</td></tr><tr><td>沼泽湾</td><td>静水</td><td>0.092</td></tr><tr><td>卧室</td><td>地毯</td><td>0.054</td></tr><tr><td>生物实验室</td><td>研究</td><td>0.053</td></tr><tr><td>小酒馆/室内</td><td>用餐</td><td>0.055</td></tr><tr><td>书店</td><td>购物</td><td>0.079</td></tr><tr><td>保龄球馆</td><td>比赛</td><td>0.055</td></tr><tr><td>拳击场</td><td>观赛</td><td>0.049</td></tr><tr><td>露营地</td><td>露营</td><td>0.053</td></tr><tr><td>运河/自然</td><td>静水</td><td>0.080</td></tr><tr><td>运河/城市</td><td>帆船/划船</td><td>0.038</td></tr><tr><td>峡谷</td><td>崎岖场景</td><td>0.110</td></tr><tr><td>汽车内饰/后座</td><td>哑光</td><td>0.079</td></tr><tr><td>汽车内饰/前座</td><td>哑光</td><td>0.098</td></tr><tr><td>赌场/室内</td><td>游戏</td><td>0.070</td></tr><tr><td>地下墓穴</td><td>挖掘</td><td>0.081</td></tr><tr><td>化学实验室</td><td>研究</td><td>0.067</td></tr><tr><td>鸡舍/室内</td><td>肮脏</td><td>0.039</td></tr><tr><td>鸡舍/户外</td><td>击剑</td><td>0.045</td></tr><tr><td>大教堂/室内</td><td>祈祷</td><td>0.148</td></tr><tr><td>教堂/户外</td><td>祈祷</td><td>0.088</td></tr><tr><td>教室</td><td>学习</td><td>0.070</td></tr><tr><td>服装店</td><td>布料</td><td>0.063</td></tr><tr><td>驾驶舱</td><td>压力大</td><td>0.048</td></tr><tr><td>建筑工地</td><td>建筑/建造</td><td>0.041</td></tr><tr><td>玉米田</td><td>农业</td><td>0.111</td></tr><tr><td>乡村花园</td><td>花卉</td><td>0.106</td></tr><tr><td>牙科诊所</td><td>医疗活动</td><td>0.070</td></tr><tr><td>餐厅</td><td>用餐</td><td>0.064</td></tr><tr><td>电力变电站</td><td>电线</td><td>0.054</td></tr><tr><td>工厂/室内</td><td>工作中</td><td>0.047</td></tr><tr><td>快餐店</td><td>排队等待</td><td>0.057</td></tr><tr><td>消防逃生通道</td><td>栏杆</td><td>0.051</td></tr><tr><td>森林小径</td><td>徒步旅行</td><td>0.111</td></tr><tr><td>林间道路</td><td>树叶</td><td>0.095</td></tr><tr><td>喷泉</td><td>流水</td><td>0.041</td></tr><tr><td>室内溜冰场</td><td>体育运动</td><td>0.058</td></tr><tr><td>室外溜冰场</td><td>寒冷</td><td>0.065</td></tr></tbody></table>

Table 1 continued

表1续

<table><tr><td>Category</td><td>Most corr. attribute</td><td>Pearson's corr. coeff.</td></tr><tr><td>Iceberg</td><td>Ocean</td><td>0.148</td></tr><tr><td>Lecture room</td><td>Studying/learning</td><td>0.080</td></tr><tr><td>Mosque/indoor</td><td>Cloth</td><td>0.060</td></tr><tr><td>Mosque/outdoor</td><td>Praying</td><td>0.066</td></tr><tr><td>Operating room</td><td>Sterile</td><td>0.058</td></tr><tr><td>Palace</td><td>Vacationing</td><td>0.045</td></tr><tr><td>Poolroom/establishment</td><td>Gaming</td><td>0.068</td></tr><tr><td>Poolroom/home</td><td>Gaming</td><td>0.075</td></tr><tr><td>Power plant/outdoor</td><td>Smoke</td><td>0.074</td></tr><tr><td>Pub/indoor</td><td>Socializing</td><td>0.065</td></tr><tr><td>Restaurant</td><td>Eating</td><td>0.088</td></tr><tr><td>Restaurant kitchen</td><td>Working</td><td>0.058</td></tr><tr><td>Stadium/football</td><td>Spectating</td><td>0.132</td></tr><tr><td>Subway station/platform</td><td>Railroad</td><td>0.052</td></tr><tr><td>Underwater/coral reef</td><td>Diving</td><td>0.165</td></tr><tr><td>Volcano</td><td>Fire</td><td>0.122</td></tr><tr><td>Wheat field</td><td>Farming</td><td>0.133</td></tr></table>

<table><tbody><tr><td>类别</td><td>最相关属性</td><td>皮尔逊相关系数(Pearson's corr. coeff.)</td></tr><tr><td>冰山</td><td>海洋</td><td>0.148</td></tr><tr><td>教室</td><td>学习</td><td>0.080</td></tr><tr><td>清真寺/室内</td><td>布料</td><td>0.060</td></tr><tr><td>清真寺/室外</td><td>祈祷</td><td>0.066</td></tr><tr><td>手术室</td><td>无菌</td><td>0.058</td></tr><tr><td>宫殿</td><td>度假</td><td>0.045</td></tr><tr><td>台球室/场所</td><td>游戏</td><td>0.068</td></tr><tr><td>台球室/家中</td><td>游戏</td><td>0.075</td></tr><tr><td>发电厂/室外</td><td>烟雾</td><td>0.074</td></tr><tr><td>酒吧/室内</td><td>社交</td><td>0.065</td></tr><tr><td>餐厅</td><td>用餐</td><td>0.088</td></tr><tr><td>餐厅厨房</td><td>工作</td><td>0.058</td></tr><tr><td>体育场/足球</td><td>观赛</td><td>0.132</td></tr><tr><td>地铁站/站台</td><td>铁路</td><td>0.052</td></tr><tr><td>水下/珊瑚礁</td><td>潜水</td><td>0.165</td></tr><tr><td>火山</td><td>火灾</td><td>0.122</td></tr><tr><td>麦田</td><td>农业</td><td>0.133</td></tr></tbody></table>

A sampling of scene categories from the SUN 397 dataset listed with their most correlated attribute

SUN 397数据集中场景类别的抽样及其最相关属性列表

### 6.1 Scene Classification

### 6.1 场景分类

#### 6.1.1 Attributes as Features for Scene Classification

#### 6.1.1 作为场景分类特征的属性

Although our attributes were discovered in order to understand natural scenes more deeply than by simply knowing their scene categories, scene classification remains a challenging and interesting task. As a scene classification baseline, we train one-vs-all non-linear SVMs with the same low level features used to predict attributes. Figure 16 compares this with various classifiers which instead operate on attributes as an intermediate representation.

尽管我们的属性是为了比单纯了解场景类别更深入地理解自然场景而发现的，场景分类仍然是一项具有挑战性且有趣的任务。作为场景分类的基线，我们使用与预测属性相同的低级特征训练一对多非线性支持向量机(SVM)。图16将其与以属性作为中间表示的各种分类器进行了比较。

The simplest way to use scene attributes as an intermediate representation is to run our attribute classifiers on the scene classification training instances and train one-vs-all SVMs in the resulting 102 dimensional space. This "predicted attribute feature" performs better than three of the low-level features, but worse than the HoG $2 \times  2$ feature. ${}^{4}$

使用场景属性作为中间表示的最简单方法是对场景分类训练样本运行我们的属性分类器，并在得到的102维空间中训练一对多SVM。这种“预测属性特征”表现优于三种低级特征，但不及HoG $2 \times  2$ 特征。${}^{4}$

It is important to note that the low-level features live in spaces that may have thousands of dimensions, while the attribute feature is only 102-dimensional. Partly for this reason, the attribute-based scene classifier seems to benefit less from additional training data than the low level features. This makes sense, because lower dimensional features have limited expressive capacity and because the attribute distribution for a given category isn't expected to be especially complex (this is, in fact, a motivation for zero-shot learning or easy knowledge transfer between observed and unobserved categories).

需要注意的是，低级特征存在于可能有数千维的空间中，而属性特征仅为102维。部分原因是如此，基于属性的场景分类器似乎比低级特征从额外训练数据中获益较少。这是合理的，因为低维特征的表达能力有限，且给定类别的属性分布预计不会特别复杂(这实际上也是零样本学习或观察类别与未观察类别之间知识迁移的动机)。

---

4 The images in the SUN Attribute dataset were originally taken from the whole SUN dataset, which includes more than 900 scene categories. Thus, some portion of the SUN Attribute images also appear in the SUN 397 dataset, which is also a subset of the full SUN dataset. The scene classifiers using low-level and predicted attribute features were trained and tested on the SUN397 dataset minus any overlapping images from the SUN Attribute dataset to avoid testing scene classification on the same images used to train attribute classifiers.

4 SUN属性数据集中的图像最初取自整个SUN数据集，该数据集包含900多个场景类别。因此，部分SUN属性图像也出现在SUN 397数据集中，后者也是完整SUN数据集的一个子集。使用低级和预测属性特征的场景分类器在SUN397数据集中训练和测试，剔除了与SUN属性数据集重叠的图像，以避免在训练属性分类器时使用的相同图像上测试场景分类。

---

![bo_d1c3uev7aajc7389qf6g_12_145_154_709_750_0.jpg](images/bo_d1c3uev7aajc7389qf6g_12_145_154_709_750_0.jpg)

Fig. 16 Scene category recognition rate versus number of training examples. Classification tested on the SUN 397 dataset (Xiao et al. 2010). Images that occur in both the SUN 397 and SUN attribute datasets were omitted from the training and test sets of the above classifiers. Each trend line plots the scene classification accuracy of the associated feature. All predicted features use the same test/train sets, and results averaged over several random test/train splits. When combined with the 4 low-level features originally used in the attribute classifiers, the 'attributes' feature clearly improves performance over a scene classifier that only uses low-level features. This further supports our claim that attributes are encoding important contextual knowledge. Classification accuracy using 15 different low-level features (the same features used in Xiao et al.) plus attribute features at 50 training examples is ${40.22}\%$ , slightly beating the ${38.0}\%$ accuracy reported in Xiao et al. (2010). The ground truth attribute feature is trained and tested on 10 random splits of the SUN Attribute dataset. Thus the number of test examples available for the ground truth feature are $\left( {{20} - {n}_{\text{train }}}\right)$ , where ${n}_{\text{train }}$ is the number of training examples. As the number of training examples increases, the ground truth feature trend line is less representative of actual performance as the test set is increasingly small. Using ground truth attributes as a feature gives an upper bound on what attribute features could possibly contribute to scene classification. Figure best viewed in color (Color figure online)

图16 场景类别识别率与训练样本数量的关系。分类测试基于SUN 397数据集(Xiao等，2010)。同时出现在SUN 397和SUN属性数据集的图像被从上述分类器的训练和测试集中剔除。每条趋势线绘制了相关特征的场景分类准确率。所有预测特征使用相同的测试/训练集，结果为多次随机测试/训练划分的平均值。当与属性分类器中最初使用的4种低级特征结合时，“属性”特征明显提升了仅使用低级特征的场景分类器的性能。这进一步支持了我们的观点，即属性编码了重要的上下文知识。使用15种不同低级特征(与Xiao等人使用的相同特征)加上属性特征，在50个训练样本时的分类准确率为${40.22}\%$，略高于Xiao等人(2010)报告的${38.0}\%$准确率。真实属性特征在SUN属性数据集的10次随机划分上训练和测试。因此，真实属性特征可用的测试样本数为$\left( {{20} - {n}_{\text{train }}}\right)$，其中${n}_{\text{train }}$为训练样本数。随着训练样本数增加，真实属性特征的趋势线因测试集逐渐缩小而不再代表实际性能。使用真实属性作为特征为属性特征对场景分类可能贡献的性能提供了上限。图表建议彩色查看(彩色图在线)。

The performance of a scene classifier that uses 15 canonical low-level features plus attributes is ${40.22}\%$ . The 15 features used were HoG $2 \times  2$ , geometric texton histograms, self-similarity measure, dense SIFT, local binary patterns, texton histograms, gist, the first nearest neighbor, LBP HF feature, sparse SIFT histograms, geometric color histograms, color histograms, geometric classification map, straight line histograms, and tiny image feature Xiao et al. (2010). This improves on the ${38}\%$ highest accuracy reported in Xiao et al., which uses these 15 features combined without attributes. Scene classification with attributes falls short of the more recent features suggested by Sanchez et al. which acheive 47 % average accuracy (Sanchez et al. 2013). The performances of scene classifiers trained on each low-level feature and attributes separately are shown in Fig. 16.

使用15种典型低级特征加属性的场景分类器性能为${40.22}\%$。这15种特征包括HoG $2 \times  2$、几何纹理元直方图、自相似度度量、密集SIFT、局部二值模式、纹理元直方图、gist、第一近邻、LBP HF特征、稀疏SIFT直方图、几何颜色直方图、颜色直方图、几何分类图、直线直方图和微型图像特征(Xiao等，2010)。这优于Xiao等人报告的最高准确率${38}\%$，后者使用这15种特征组合但未加属性。带属性的场景分类性能不及Sanchez等人提出的更近期特征，后者达到47%的平均准确率(Sanchez等，2013)。图16展示了分别基于每种低级特征和属性训练的场景分类器性能。

It is also important to remember that attribute classification itself is a difficult task. If it were possible to perfectly predict attributes, scene classification performance would jump dramatically. We estimate an upper bound for scene classification with our attribute taxonomy by training and testing on the ground truth attribute annotations for each scene category. As shown in Fig. 16, such a classifier outperforms the best low-level feature by a huge margin 25 versus 15% accuracy with 10 training examples per category. ${}^{5}$

同样重要的是要记住，属性分类本身就是一项困难的任务。如果能够完美预测属性，场景分类的性能将大幅提升。我们通过在每个场景类别的真实属性注释上训练和测试，估计了使用我们属性分类法进行场景分类的上限。如图16所示，这样的分类器以每类10个训练样本的条件下，准确率达到25%，远超最佳低级特征的15%。${}^{5}$

#### 6.1.2 Learning to Recognize Scenes Without Visual Examples

#### 6.1.2 无视觉样本的场景识别学习

In zero-shot learning, a classifier is presented (by some oracle) a ground truth distribution of attributes for a given category rather than any visual examples. Test images are classified as the category whose oracle-annotated feature vector is the nearest neighbor in feature space to the test images' features.

在零样本学习中，分类器由某个“神谕”提供给定类别的真实属性分布，而非任何视觉样本。测试图像被分类为其特征空间中与测试图像特征最邻近的、由神谕注释的类别特征向量所属的类别。

Canonical definitions of zero-shot learning use an intermediate feature space to generalize important concepts shared by categories (Lampert et al. 2009; Palatucci et al. 2009). Lampert et al. uses an attribute representation to enable knowledge transfer between seen and unseen categories, and Palatucci et al. uses phonemes. In these zero-shot learning scenarios, it is prohibitively difficult or expensive to collect low-level feature examples of an exhaustive set of categories. The use of oracle features for those unseen categories is a way to identify them without collecting enough examples to train a classifier.

零样本学习的经典定义使用中间特征空间来泛化类别间共享的重要概念(Lampert等，2009；Palatucci等，2009)。Lampert等人使用属性表示实现已见类别与未见类别间的知识迁移，Palatucci等人则使用音素。在这些零样本学习场景中，收集涵盖所有类别的低级特征样本极其困难或昂贵。对未见类别使用神谕特征是一种无需收集足够样本训练分类器即可识别它们的方法。

The goal of zero-shot learning is to learn a classifier $f : \mathcal{X} \rightarrow  \mathcal{Z}$ for a label set $\mathcal{Z}$ , where some categories in $\mathcal{Z}$ were not seen during training. This is accomplished by learning two transfer functions, $g : \mathcal{X} \rightarrow  \mathcal{A}$ and $h : \mathcal{A} \rightarrow  \mathcal{Z}$ . The set $\mathcal{A}$ is an intermediate feature space like attributes or phonemes. Some oracle provides the labels for the unseen categories in $\mathcal{Z}$ using the feature space of $\mathcal{A}$ . In traditional zero-shot learning experiments, instances from the unseen categories in $\mathcal{Z}$ are not used to learn the transfer function $g : \mathcal{X} \rightarrow  \mathcal{A}$ . This makes sense if obtaining examples of the unseen categories is difficult as in Lampert et al. (2009), Palatucci et al. (2009).

零样本学习的目标是学习一个标签集$\mathcal{Z}$的分类器$f : \mathcal{X} \rightarrow  \mathcal{Z}$，其中$\mathcal{Z}$中的部分类别在训练时未出现。通过学习两个迁移函数$g : \mathcal{X} \rightarrow  \mathcal{A}$和$h : \mathcal{A} \rightarrow  \mathcal{Z}$实现此目标。集合$\mathcal{A}$是一个中间特征空间，如属性或音素。某个神谕使用$\mathcal{A}$的特征空间为$\mathcal{Z}$中未见类别提供标签。在传统零样本学习实验中，未见类别的实例不会用于学习迁移函数$g : \mathcal{X} \rightarrow  \mathcal{A}$。如果获取未见类别样本困难，如Lampert等(2009)、Palatucci等(2009)所述，这种做法是合理的。

---

${}^{5}$ Because ground truth attributes were collected on the SUN Attribute set of images, the classifiers using the ground truth attributes directly as features were trained and tested on the SUN Attribute dataset.

${}^{5}$ 由于真实属性是在SUN属性图像集上收集的，直接使用真实属性作为特征的分类器在SUN属性数据集上进行了训练和测试。

---

![bo_d1c3uev7aajc7389qf6g_13_146_156_709_389_0.jpg](images/bo_d1c3uev7aajc7389qf6g_13_146_156_709_389_0.jpg)

Fig. 17 Scene category recognition without visual examples. The 'attributes averaged per category' feature is calculated by averaging the predicted attribute features of all of the training instances of a given scene category in the SUN 397 dataset. Test instances are evaluated by selecting the nearest neighbor scene category feature, and taking that scene category's label

图17 无视觉样本的场景类别识别。“按类别平均属性”特征通过对SUN 397数据集中某场景类别所有训练实例的预测属性特征取平均计算得出。测试实例通过选择最近邻的场景类别特征并采用该类别标签进行评估。

Because we already had a nearly exhaustive set of scene categories in the SUN Attribute dataset, the attribute classifiers were trained using images that belonged to categories that were held out during the "zero-shot" testing of the transfer function $h : \mathcal{A} \rightarrow  \mathcal{Z}$ . In our "zero-shot" experiment, all of the possible scene category labels in $\mathcal{Z}$ were held out. The experiments conducted using scene attributes as features in this subsection are an expanded version of traditional zero-shot learning, and we have maintained that term to support the demonstration of how a scene category can be identified by it's typical attributes only, without any visual examples of the category. The entire "zero-shot" classification pipeline in this section never involved showing the classifier a visual training example of any scene category. The classifier gets an oracle feature listing the typical attributes of each of the 397 categories.

由于我们已拥有SUN属性数据集中几乎完整的场景类别集合，属性分类器使用了在迁移函数$h : \mathcal{A} \rightarrow  \mathcal{Z}$“零样本”测试中被排除的类别的图像进行训练。在我们的“零样本”实验中，$\mathcal{Z}$中的所有可能场景类别标签均被排除。本小节中使用场景属性作为特征的实验是传统零样本学习的扩展版本，我们保留该术语以展示如何仅凭典型属性识别场景类别，而无需任何该类别的视觉样本。本节的整个“零样本”分类流程从未向分类器展示任何场景类别的视觉训练样本。分类器仅获得一个神谕特征，列出397个类别的典型属性。

Our goal is to show that given some reasonable estimate of a scene's attributes it is possible to estimate the scene category without using the low-level features to classify the query image. Scene attributes are correlated with scene categories, and query scenes can be successfully classified if only their attributes are known. In this sense our experiment is similar to, but more stringent than canonical knowledge transfer experiments such as in Rohrbach et al. because the scene category labels were not used to help learn the mapping from pixel-features to attributes (Rohrbach et al. 2011).

我们的目标是展示，给定对场景属性的合理估计，可以在不使用低级特征对查询图像进行分类的情况下估计场景类别。场景属性与场景类别相关联，若仅知其属性，查询场景也能被成功分类。从这个意义上说，我们的实验与Rohrbach等人的经典知识迁移实验类似，但更为严格，因为场景类别标签未被用于辅助学习从像素特征到属性的映射(Rohrbach等，2011)。

Despite the low number of training examples (397, one oracle feature per category, for zero-shot features vs. $n \times  {397}$ for pixel-level features), the zero-shot classifier shown in Fig. 17 performs about as well as the gist descriptor. It does, however, perform significantly worse than the attribute-based classifier trained on $n$ examples of predicted attributes shown in Fig. 16. Averaging the attributes into a single "characteristic attribute vector" for each category is quite lossy. In some ways, this supports the argument that there is significant and interesting intra-category variation of scene attributes.

尽管训练样本数量较少(397个，每个类别一个oracle特征，用于零样本特征，而像素级特征则为$n \times  {397}$)，图17所示的零样本分类器表现与gist描述符相当。然而，其性能明显不及图16中基于属性的分类器，该分类器在$n$个预测属性样本上训练。将属性平均为每个类别的单一“特征属性向量”会造成较大信息损失。在某种程度上，这支持了场景属性存在显著且有趣的类别内变异的观点。

![bo_d1c3uev7aajc7389qf6g_13_905_152_700_408_0.jpg](images/bo_d1c3uev7aajc7389qf6g_13_905_152_700_408_0.jpg)

Fig. 18 Comparison to human confusions. Using the human scene classification confusions from Xiao et al. (2010), we report how often the large incorrect (i.e. off-diagonal) confusion is the same for a given feature and the human classifiers

图18 与人类混淆的比较。利用Xiao等人(2010)的人类场景分类混淆数据，我们报告了给定特征与人类分类器在大规模错误(即非对角线)混淆上的一致频率。

### 6.2 Predicting Human Confusions

### 6.2 预测人类混淆

Scene classification is a challenging task, even for humans. In the previous sections, we show that attributes do not always out-perform low-level features at scene classification. Figure 18 shows the performance of several features at another challenging task-predicting human confusions for scene classification on the SUN 397 dataset. At this task, attributes perform slightly better than any other feature.

场景分类是一项具有挑战性的任务，即使对人类也是如此。在前述章节中，我们展示了属性并不总是优于低级特征进行场景分类。图18展示了多种特征在另一项挑战性任务——预测SUN 397数据集上人类场景分类混淆——中的表现。在此任务中，属性的表现略优于其他任何特征。

We compare the confusions between features and humans using the scene classification confusion matrices for each feature. The human classification confusion for the SUN 397 dataset is reported in Xiao et al. (2010). We determined that a feature classifier and the humans had the same confusion if the largest off-diagonal elements of the corresponding rows of their confusion matrices were the same, e.g. both the attribute classifier and the human respondents confused 'bayou' for 'swamp'.

我们利用每种特征的场景分类混淆矩阵比较特征与人类的混淆。SUN 397数据集的人类分类混淆由Xiao等人(2010)报告。我们判定若特征分类器与人类在其混淆矩阵对应行的最大非对角元素相同，则认为两者混淆一致，例如属性分类器和人类受访者都将“bayou”误判为“swamp”。

In Xiao et al. (2010), the low-level features that performed the best for scene classification also performed the best at predicting human confusions. Here we demonstrate that although predicted attributes do not perform as well as HoG $2 \times  2$ features at scene classification, they are indeed better at predicting human confusions.

在Xiao等人(2010)中，表现最佳的低级特征在场景分类和预测人类混淆方面均表现最佳。本文展示，尽管预测属性在场景分类上不及HoG$2 \times  2$特征，但在预测人类混淆方面确实更优。

This result supports the conclusions of Greene and Oliva (2009). Attributes, which capture global image concepts like structure and affordance, may be closer to the representations humans use to do rapid categorization of scenes than low-level image features by themselves.

该结果支持Greene和Oliva(2009)的结论。属性捕捉了诸如结构和可供性等全局图像概念，可能比单纯的低级图像特征更接近人类用于快速场景分类的表征。

## 7 Image Retrieval Applications with Attribute-Based Representations

## 7 基于属性表示的图像检索应用

Thus far we have introduced the SUN Attribute dataset and we have measured how well attributes can be recognized based on typical global image features. We have also used predicted attributes as an intermediate representation for scene classification and zero shot learning. An appealing property of attributes as an intermediate, low-dimensional representation is that distances in attribute space tend to be more meaningful than distances in the high-dimensional, low-level feature spaces from which those attributes were predicted. For example, with the SUN 397 database, the best combination of features gets ${38}\%$ scene classification accuracy with a non-linear SVM, but those same features get only 13% accuracy with a nearest neighbor classifier. Strong supervision is required to harness global image descriptors for recognition tasks and this is a problem for the numerous highly data-driven recognition tasks which rely on unsupervised image retrieval (or "scene matching") is at the start of the pipeline. In this section we demonstrate three tasks in which we have replaced (or augmented) typical global image features with attribute-based representations (1) scene parsing (2) image captioning and (3) text-based image retrieval. In all of these applications, the attribute representation for image retrieval is the 102 dimensional real-valued confidences from the classifiers in Sect. 5.

迄今为止，我们介绍了SUN属性数据集，并评估了基于典型全局图像特征的属性识别效果。我们还将预测属性用作场景分类和零样本学习的中间表示。属性作为一种中间的低维表示的一个吸引人特性是，属性空间中的距离往往比从中预测这些属性的高维低级特征空间中的距离更具意义。例如，在SUN 397数据库中，最佳特征组合通过非线性SVM获得${38}\%$的场景分类准确率，但同样的特征用最近邻分类器仅能达到13%的准确率。强监督是利用全局图像描述符进行识别任务的前提，而这对于依赖无监督图像检索(或“场景匹配”)作为流程起点的众多高度数据驱动识别任务来说是一个问题。在本节中，我们展示了三个任务，在这些任务中我们用基于属性的表示替代(或增强)了典型的全局图像特征:(1)场景解析(2)图像描述生成(3)基于文本的图像检索。在所有这些应用中，图像检索的属性表示是第5节分类器输出的102维实值置信度。

### 7.1 Scene Parsing with Attribute-Based Scene Retrieval

### 7.1 基于属性的场景检索进行场景解析

Scene parsing is the task of segmenting and recognizing all objects and surfaces in an image. Categorical labels can be assigned to either each pixel or each region (e.g. super-pixel) of the input image, giving a thorough interpretation of the scene content. Most methods proposed for this problem require a generative or discriminative model to be trained for each category, and thus only work with a handful of predefined categories (Gould et al. 2009; He et al. 2004; Hoiem et al. 2007; Ladický et al. 2010; Malisiewicz and Efros 2008; Rabinovich et al. 2007; Shotton et al. 2008, 2006; Socher et al. 2011). The training process can be very time-consuming and must be done in advance. Even worse, the entire training has to be repeated whenever new training images or class labels are added to the dataset. Recently, several nonparametric, data-driven approaches have been proposed for the scene parsing problem (Liu et al. 2011; Tighe and Lazebnik 2013; Eigen and Fergus 2012). These approaches require no training in advance. They can easily scale to hundreds of categories and have the potential to work with Internet-scale, continuously growing datasets like LabelMe (Russell et al. 2008).

场景解析是对图像中所有物体和表面进行分割和识别的任务。可以为输入图像的每个像素或每个区域(例如超像素)分配类别标签，从而对场景内容进行全面解释。针对该问题提出的大多数方法都需要为每个类别训练生成式或判别式模型，因此仅适用于少量预定义类别(Gould 等，2009；He 等，2004；Hoiem 等，2007；Ladický 等，2010；Malisiewicz 和 Efros，2008；Rabinovich 等，2007；Shotton 等，2008，2006；Socher 等，2011)。训练过程非常耗时，且必须提前完成。更糟糕的是，每当向数据集中添加新的训练图像或类别标签时，整个训练过程都必须重新进行。近年来，针对场景解析问题提出了若干非参数、数据驱动的方法(Liu 等，2011；Tighe 和 Lazebnik，2013；Eigen 和 Fergus，2012)。这些方法无需提前训练，能够轻松扩展到数百个类别，并有潜力应用于如 LabelMe(Russell 等，2008)这样互联网规模、持续增长的数据集。

In this section we show how well we can improve data-driven scene parsing by adopting scene attributes. Tighe and Lazebnik investigate nonparametric, data-driven scene parsing and achieve state-of-the-art performance (Tighe and Lazebnik 2013). We follow their system pipeline and show that by simply adding scene attributes as one of the features used for scene representation we can achieve significant performance gains.

本节展示了通过采用场景属性，如何有效提升数据驱动的场景解析性能。Tighe 和 Lazebnik 研究了非参数、数据驱动的场景解析方法，并取得了最先进的性能(Tighe 和 Lazebnik，2013)。我们遵循他们的系统流程，展示了仅通过将场景属性作为场景表示的特征之一，即可实现显著的性能提升。

#### 7.1.1 System Pipeline

#### 7.1.1 系统流程

The first step in parsing a query image is to find a retrieval set of images similar to the query image. The purpose of finding this subset of training images is to expedite the parsing system and at the same time throw away irrelevant information which otherwise can be confusing. In Tighe and Lazebnik (2013), three types of global image features are used in this step: gist, spatial pyramid, and color histogram. For each feature type, Tighe and Lazebnik sort all the training images in increasing order of Euclidean distance from the query image. They take the minimum rank accross all feature types for each training image and then sort the minimum ranks in increasing order to get a ranking among the training images for the query image. The top ranking $K$ images are used as the retrieval set.

解析查询图像的第一步是找到与查询图像相似的检索图像集。寻找这部分训练图像的目的是加快解析系统的速度，同时剔除可能导致混淆的无关信息。在 Tighe 和 Lazebnik(2013)中，此步骤使用了三种全局图像特征:gist、空间金字塔和颜色直方图。对于每种特征类型，Tighe 和 Lazebnik 按欧氏距离从小到大对所有训练图像进行排序。然后对每个训练图像取所有特征类型中的最小排名，再将这些最小排名按升序排序，从而获得查询图像对应的训练图像排名。排名靠前的$K$张图像被用作检索集。

After building the retrieval set, the query image and the retrieval set images are segmented into superpixels. Each superpixel is then described using 20 different features. A detailed list of these features can be found in Table 1 in Tighe and Lazebnik (2013). For each superpixel in the query image, nearest-neighbor superpixels in the retrieval set are found according to the 20 features for that superpixel. A likelihood score is then computed for each class based on the nearest-neighbor matches.

构建检索集后，将查询图像及检索集图像分割成超像素。每个超像素使用20种不同的特征进行描述。详细特征列表见 Tighe 和 Lazebnik(2013)中的表1。对于查询图像中的每个超像素，根据该超像素的20个特征在检索集中找到最近邻超像素。然后基于最近邻匹配计算每个类别的似然得分。

In the last step, we can simply assign the class with the highest likelihood score to each superpixel in the query image, or use Markov Random Field (MRF) framework to further incorporate pairwise co-occurrence information learned from training dataset. As in Eigen and Fergus (2012), we report the performance without using the MRF layer in this paper so differences in local classification performance can be observed more clearly.

最后一步，可以简单地将似然得分最高的类别分配给查询图像中的每个超像素，或者使用马尔可夫随机场(MRF)框架进一步结合从训练数据集中学习到的成对共现信息。与 Eigen 和 Fergus(2012)类似，本文报告的性能未使用 MRF 层，以便更清晰地观察局部分类性能的差异。

#### 7.1.2 Scene Attributes as Global Features

#### 7.1.2 作为全局特征的场景属性

Our goal in investigating scene parsing is to characterize how well our scene attributes work as a scene representation for image retrieval. Thus, we keep the system in Tighe and Lazebnik (2013) unchanged except for using scene attributes as global image features, either by themselves or in conjunction with the low-level features used in the original system.

我们研究场景解析的目标是评估场景属性作为图像检索场景表示的效果。因此，除使用场景属性作为全局图像特征(单独使用或与原系统中的低级特征结合)外，保持 Tighe 和 Lazebnik(2013)系统不变。

The dataset we use for this experiment is the SIFT-Flow dataset (Liu et al. 2011). It is composed of 2,688 annotated images from LabelMe and has 33 semantic labels. Since the class frequencies are highly unbalanced, we report both per-pixel classification rate and per-class rate, which is the average of the per-pixel rates over all classes. We also report the performance of an "optimal retrieval set", which uses ground-truth class labels instead of global features to find similar scenes for the query image. This retrieval set is called Maximum Histogram Intersection. It is found by ranking training images according to the class histogram intersections they have with the query image. This optimal retrieval set is meant to be a performance upper bound and should provide an insight into how much room for improvement there is in the image retrieval step.

本实验使用的数据集是 SIFT-Flow 数据集(Liu 等，2011)，由来自 LabelMe 的2,688张带注释图像组成，包含33个语义标签。由于类别频率极度不平衡，我们报告了每像素分类率和每类别分类率(即所有类别每像素分类率的平均值)。我们还报告了“最优检索集”的性能，该检索集使用真实类别标签而非全局特征来寻找与查询图像相似的场景。该检索集称为最大直方图交集，通过根据训练图像与查询图像类别直方图的交集大小进行排序获得。该最优检索集旨在作为性能上限，帮助了解图像检索步骤的改进空间。

![bo_d1c3uev7aajc7389qf6g_15_144_155_706_665_0.jpg](images/bo_d1c3uev7aajc7389qf6g_15_144_155_706_665_0.jpg)

Fig. 19 Evaluation of using our scene attributes as a global feature for scene parsing on the SIFT-Flow dataset. The $x$ -axis shows mean per-class classification rate and the $y$ -axis shows per-pixel classification rate. The plots show the impact of using different retrieval set sizes $K$ ranging from 10 to 800 . The closer a line gets to the top-right corner of the space (regardless of the value of $K$ ), the better the retrieval method. The blue plot shows the result of using gist (G), spatial pyramid (SP), and color histogram(CH)together as scene descriptors for finding retrieval sets (Tighe and Lazebnik 2013). Using scene attributes alone improves the per-pixel rates while the per-class rates are similar. Using scene attributes together with the previous three features increases both the per-pixel rates and the per-class rates. Maximum histogram intersection is the upper bound we get by finding retrieval set using ground-truth labels of the query image (Color figure online)

图19 使用我们的场景属性作为全局特征在SIFT-Flow数据集上进行场景解析的评估。$x$轴表示每类平均分类率，$y$轴表示每像素分类率。图中展示了使用不同检索集大小$K$(从10到800)的影响。线条越接近空间的右上角(无论$K$的值如何)，检索方法越好。蓝色曲线显示了将gist(G)、空间金字塔(SP)和颜色直方图(CH)作为场景描述符联合用于检索集查找的结果(Tighe和Lazebnik 2013)。仅使用场景属性提高了每像素分类率，而每类分类率相似。将场景属性与前三种特征结合使用，既提高了每像素分类率，也提高了每类分类率。最大直方图交集是通过使用查询图像的真实标签找到检索集所能达到的上限(彩色图在线)。

Figure 19 shows the performance comparison among different global features. As we can see from the result, using only scene attributes as global features we get higher per-pixel rates than (Tighe and Lazebnik 2013), which uses three global features $\left( {\mathrm{G} + \mathrm{{SP}} + \mathrm{{CH}}}\right)$ , while getting similar per-class rates. When combining our scene attributes with those three global features (Attributes+G+SP+CH), both the per-pixel rates and the per-class rates increase significantly [73.4, ${29.8}\% \left( {K = {200}}\right)$ vs. ${76.2},{33.0}\% \left( {K = {100}}\right)$ ]. Considering the compact size of our scene attributes, 102 dimensions compared with the 5184-dimension $\mathrm{G} + \mathrm{{SP}} + \mathrm{{CH}}$ , this result supports the hypothesis that scene attributes are a compact and useful high-level scene representation. It is also worth noting that adding more features beyond this point does not necessarily improve the performance because all features, including weak ones, contribute equally to the found retrieval sets. For instance, by using all 12 features from (Xiao et al. 2010) together with the scene attributes, the per-pixel rate and the per-class rate drop to 74.6 and ${30.4}\%$ respectively $\left( {K = {100}}\right)$ .

图19展示了不同全局特征之间的性能比较。从结果可以看出，仅使用场景属性作为全局特征，我们获得的每像素分类率高于使用三种全局特征$\left( {\mathrm{G} + \mathrm{{SP}} + \mathrm{{CH}}}\right)$的(Tighe和Lazebnik 2013)，而每类分类率相近。当将我们的场景属性与这三种全局特征(Attributes+G+SP+CH)结合时，每像素分类率和每类分类率均显著提升[73.4，${29.8}\% \left( {K = {200}}\right)$对比${76.2},{33.0}\% \left( {K = {100}}\right)$]。考虑到我们的场景属性维度紧凑，仅102维，而对比的特征为5184维$\mathrm{G} + \mathrm{{SP}} + \mathrm{{CH}}$，该结果支持场景属性是一种紧凑且有用的高层场景表示的假设。值得注意的是，超过此点添加更多特征不一定提升性能，因为所有特征(包括弱特征)对找到的检索集贡献均等。例如，将(Xiao等，2010)中的全部12个特征与场景属性一起使用时，每像素分类率和每类分类率分别下降到74.6和${30.4}\%$$\left( {K = {100}}\right)$。

### 7.2 Data-Driven Image Captioning with Attribute-Based Scene Retrieval

### 7.2 基于属性的场景检索驱动的数据驱动图像描述生成

In the previous subsection we showed that attribute-based image retrieval can lead to improved scene parsing performance. Here we take an analagous approach-modifying the image retrieval stage of data-driven pipeline-for the task of image captioning. There has been significant recent interest in generating natural language descriptions of photographs (Kulkarni et al. 2013; Farhadi et al. 2010b). These techniques are typically quite complex: they recognize various visual concepts such as objects, materials, scene types, and the spatial relationship among these entities, and then generate plausible natural language sentences based on this scene understanding. However, the "Im2text" (Ordonez et al. 2011) method offers a simple data-driven alternative. Instead of trying to achieve deep scene understanding and then link visual entities to natural language entities, Im2text simply tries to find a similar scene in a large database and then "steals" the existing caption in its entirety. Because the success of Im2text depends entirely on its ability to find similar scenes (which hopefully have similar captions), we use it to evaluate attribute-based scene representations.

在前一小节中，我们展示了基于属性的图像检索能够提升场景解析性能。这里我们采用类似的方法——修改数据驱动流程中的图像检索阶段——用于图像描述生成任务。近年来，生成照片的自然语言描述引起了广泛关注(Kulkarni等，2013；Farhadi等，2010b)。这些技术通常较为复杂:它们识别各种视觉概念，如物体、材质、场景类型及其空间关系，然后基于场景理解生成合理的自然语言句子。然而，“Im2text”(Ordonez等，2011)方法提供了一种简单的数据驱动替代方案。它不试图实现深度场景理解并将视觉实体映射到自然语言实体，而是直接在大型数据库中寻找相似场景，然后“借用”其完整的已有描述。由于Im2text的成功完全依赖于其找到相似场景(且这些场景应有相似描述)的能力，我们用它来评估基于属性的场景表示。

In its simplest form, Im2text uses the gist and tiny image descriptors (Torralba et al. 2008) as the global features for image retrieval. On top of this baseline, Im2text also examines "content matching" in which the retrieved scenes are re-ranked according to overlap of recognized objects, "stuff", people, and scene types. In Table 2, top we compare to the "baseline" Im2text by replacing the high dimensional global image features with our 102 dimensional predicted attributes. As in Im2text, the experiments are carried out by retrieving scenes from the SBU Captioned Photo Dataset ${}^{6}$ which contains 1 million Flickr images with captions. Image captioning performance is quantified as the similarity between a ground truth caption and a predicted caption according to BLEU score (Papineni et al. 2002). As used in Im2text, the BLEU score is the proportion of words in the captions which are the same. This corresponds to the "unigram precision" BLEU score which does not consider the ordering of words. Stricter forms of BLEU also measure "n-gram precision" which considers how many word sequences of length $n$ are shared between sentences. The ambiguity of the BLEU score has been criticized in the literature, and despite its technical shortcomings we use it here in order to compare to previous methods. By using attributes instead of the baseline Im2text image features we see small gains in captioning performance - from average BLEU of 0.109 with gist and tiny images to 0.114 with predicted attributes. However, the content matching approach in Im2text which re-ranks similar scenes based on deeper scene understanding still exceeds both global matching schemes with an average BLEU of 0.126 .

在最简单的形式中，Im2text 使用 gist 和 tiny image 描述符(Torralba 等，2008)作为图像检索的全局特征。在此基线之上，Im2text 还考察了“内容匹配”，即根据识别出的物体、“stuff”、人物和场景类型的重叠对检索到的场景进行重新排序。在表2顶部，我们通过用我们预测的102维属性替换高维全局图像特征，比较了“基线”Im2text。如同 Im2text，实验通过从包含100万张带有标题的 Flickr 图片的 SBU Captioned Photo Dataset ${}^{6}$ 中检索场景进行。图像描述性能通过 BLEU 分数(Papineni 等，2002)量化，衡量真实标题与预测标题之间的相似度。正如 Im2text 中使用的，BLEU 分数是标题中相同词汇的比例，对应于“不考虑词序的单词精确度(unigram precision)”的 BLEU 分数。更严格的 BLEU 形式还测量“n-gram 精确度”，考虑句子间共享的长度为 $n$ 的词序列数量。BLEU 分数的歧义性在文献中受到批评，尽管存在技术缺陷，我们仍使用它以便与先前方法进行比较。通过使用属性替代基线 Im2text 图像特征，我们观察到描述性能的小幅提升——从使用 gist 和 tiny image 的平均 BLEU 0.109 提升到使用预测属性的 0.114。然而，Im2text 中基于更深层场景理解对相似场景重新排序的内容匹配方法，仍以平均 BLEU 0.126 超过了两种全局匹配方案。

---

${}^{6}$ http://dsl1.cewit.stonybrook.edu/vicente/py/website/search

${}^{6}$ http://dsl1.cewit.stonybrook.edu/vicente/py/website/search

---

Table 2 Global matching BLEU score comparison between baseline features and attributes on ${10}\mathrm{K},{100}\mathrm{\;K}$ and $1\mathrm{M}$ dataset, ${10}\mathrm{K} * ,{100}\mathrm{K} *$ and $1{\mathrm{M}}^{ * }$ are the dataset results with caption preprocessing

表2 基线特征与属性在 ${10}\mathrm{K},{100}\mathrm{\;K}$ 和 $1\mathrm{M}$ 数据集上的全局匹配 BLEU 分数比较，${10}\mathrm{K} * ,{100}\mathrm{K} *$ 和 $1{\mathrm{M}}^{ * }$ 是经过标题预处理的数据集结果

<table><tr><td/><td>10K</td><td>100K</td><td>1M</td></tr><tr><td>Gist + tiny image</td><td>${0.0869} \pm  {0.002}$</td><td>${0.0999} \pm  {0.009}$</td><td>${0.1094} \pm  {0.0047}$</td></tr><tr><td>Attributes</td><td>${0.0934} \pm  {0.01}$</td><td>${0.1058} \pm  {0.015}$</td><td>${0.1140} \pm  {0.0199}$</td></tr><tr><td>Chance</td><td>0.086</td><td/><td/></tr><tr><td/><td>10K*</td><td>100K*</td><td>1M*</td></tr><tr><td>Gist + tiny image</td><td>${0.02} \pm  {0.006}$</td><td>${0.0255} \pm  {0.0079}$</td><td>${0.0398} \pm  {0.0122}$</td></tr><tr><td>Attributes</td><td>${0.0298} \pm  {0.0052}$</td><td>${0.0366} \pm  {0.01320.0551} \pm  {0.025}$</td><td/></tr><tr><td>Chance</td><td>0.0144</td><td/><td/></tr></table>

<table><tbody><tr><td></td><td>10K</td><td>100K</td><td>1M</td></tr><tr><td>摘要 + 小图像</td><td>${0.0869} \pm  {0.002}$</td><td>${0.0999} \pm  {0.009}$</td><td>${0.1094} \pm  {0.0047}$</td></tr><tr><td>属性</td><td>${0.0934} \pm  {0.01}$</td><td>${0.1058} \pm  {0.015}$</td><td>${0.1140} \pm  {0.0199}$</td></tr><tr><td>机会</td><td>0.086</td><td></td><td></td></tr><tr><td></td><td>10K*</td><td>100K*</td><td>1M*</td></tr><tr><td>摘要 + 小图像</td><td>${0.02} \pm  {0.006}$</td><td>${0.0255} \pm  {0.0079}$</td><td>${0.0398} \pm  {0.0122}$</td></tr><tr><td>属性</td><td>${0.0298} \pm  {0.0052}$</td><td>${0.0366} \pm  {0.01320.0551} \pm  {0.025}$</td><td></td></tr><tr><td>机会</td><td>0.0144</td><td></td><td></td></tr></tbody></table>

Removing stop words, punctuations, stemming, all lower case

去除停用词、标点符号、词干提取，全部小写

In the course of the experiments, we noticed that "chance" performance, in which a random caption is taken from the database for each query, was surprisingly competitive with the retrieval methods (average BLEU of .086). We believe this is because the unigram BLEU score rewards matched words such as "the" and "a" just as much as more content descriptive terms such as "forest" and "baby" and this obscures the differences between the retrieval methods. In Table 2, bottom we measure performance when we perform three operations to try and make the caption evaluation more rigorous: (1) stemming captions to root words, e.g. "run", "ran", "running" and "runs" are stemmed to "run". (2) converting all words to lower case and (3) removing frequent "stop words" such as articles and prepositions. While steps 1 and 2 make it easier for captions to match under the BLEU criteria, step 3 dramatically decreases performance. Chance performance drops by a factor of 6 to .014 . The difference between attributes and the baseline global image features is more pronounced under this scheme-0.055versus 0.040, respectively. These numbers are quite low in absolute terms because the captions in the Im2text database are exceedingly diverse, even for very similar scenes. Figure 20 shows example retrieval results where scene attributes lead to better matching scenes than the baseline features (gist + tiny images). For these examples, the captions obtained using attributes get higher BLEU scores than the captions from the baseline features.

在实验过程中，我们注意到“随机”表现，即为每个查询从数据库中随机选取一个标题，其表现竟然与检索方法相当接近(平均BLEU为0.086)。我们认为这是因为一元BLEU分数对匹配词如“the”和“a”的奖励与对更具内容描述性的词如“forest”(森林)和“baby”(婴儿)一样，这掩盖了检索方法之间的差异。在表2底部，我们测量了通过三种操作使标题评估更严格时的表现:(1)对标题进行词干提取，如“run”、“ran”、“running”和“runs”都被提取为“run”；(2)将所有单词转换为小写；(3)去除频繁出现的“停用词”，如冠词和介词。步骤1和2使标题在BLEU标准下更易匹配，而步骤3则显著降低了表现。随机表现下降了6倍，降至0.014。在此方案下，属性与基线全局图像特征之间的差异更为明显，分别为0.055和0.040。这些数值在绝对值上较低，因为Im2text数据库中的标题极为多样，即使是非常相似的场景。图20展示了使用场景属性比基线特征(gist + tiny images)获得更好匹配场景的检索示例。在这些示例中，使用属性获得的标题比基线特征的标题获得了更高的BLEU分数。

![bo_d1c3uev7aajc7389qf6g_16_905_149_700_735_0.jpg](images/bo_d1c3uev7aajc7389qf6g_16_905_149_700_735_0.jpg)

Fig. 20 Attribute search versus Im2Text baseline. Example image retrieval results that show how scene attributes can provide more relevant results than the Im2Text baseline

图20 属性搜索与Im2Text基线。示例图像检索结果展示了场景属性如何提供比Im2Text基线更相关的结果

### 7.3 Text-Based Image Retrieval with Scene Attributes

### 7.3 基于文本的图像检索与场景属性

In the previous subsection we address generating captions from images and here we address the inverse task-retrieving images most relevant to a text query. There has been recent work on directly using attributes to search image collections (Kumar et al. 2011; Siddiquie et al. 2011; Kovashka et al. 2012; Scheirer et al. 2012) but here we investigate the longstanding problem of query-by-text, as in typical search engines. Therefore we first focus on learning a mapping from text keywords to attributes and then perform image retrieval in the 102 dimensional predicted attribute space. While the observed correlations between attributes and keywords are interesting and the retrieval results are promising, we do not claim that this application represents the state of the art in text-based image retrieval. Instead we offer a qualitative comparison to the most common image retrieval baseline tf-idf (term frequency-inverse document frequency) weighted comparisons of query keywords to captions.

在前一小节中我们讨论了从图像生成标题，这里我们讨论逆向任务——检索与文本查询最相关的图像。近期已有直接使用属性搜索图像集合的工作(Kumar等，2011；Siddiquie等，2011；Kovashka等，2012；Scheirer等，2012)，但这里我们探讨长期存在的文本查询问题，如典型搜索引擎所用。因此，我们首先关注从文本关键词到属性的映射学习，然后在102维预测属性空间中进行图像检索。虽然观察到的属性与关键词之间的相关性有趣且检索结果令人鼓舞，但我们并不声称该应用代表了基于文本的图像检索的最先进水平。相反，我们提供了与最常用的图像检索基线——基于tf-idf(词频-逆文档频率)加权的查询关键词与标题比较——的定性对比。

#### 7.3.1 Attribute and Word Correlation

#### 7.3.1 属性与词语相关性

To link keyword queries to our scene attribute representation, we measure the correlation of individual scene attributes and words with a method inspired the co-occurrence model of Hironobu et al. (1999). Hironobu et al. (1999) counts the number of co-occurrences of image patch features and caption keywords to find correlations between keywords and features. We discover the correspondence of attributes and keywords by counting the number of times that a given attribute and keyword appear in the same image.

为了将关键词查询与我们的场景属性表示关联起来，我们采用受Hironobu等(1999)共现模型启发的方法，测量单个场景属性与词语的相关性。Hironobu等(1999)通过统计图像块特征与标题关键词的共现次数，发现关键词与特征之间的相关性。我们通过统计给定属性与关键词在同一图像中出现的次数，发现属性与关键词的对应关系。

Table 3 Examples of top correlated words for attributes

表3 属性对应的高相关词示例

<table><tr><td>Attr.</td><td>Sail./boat.</td><td>Driving</td><td>Eating</td><td>Railroad</td><td>Camping</td></tr><tr><td rowspan="20">Top 20 correlated words</td><td>Cruis</td><td>Sand</td><td>Bar</td><td>Moon</td><td>Grass</td></tr><tr><td>Harbor</td><td>Road</td><td>Cabinet</td><td>Railwai</td><td>Pastur</td></tr><tr><td>Ocean</td><td>Sidewalk</td><td>Desk</td><td>Lit</td><td>Field</td></tr><tr><td>Sail</td><td>Lane</td><td>Kitchen</td><td>Exposur</td><td>Forest</td></tr><tr><td>Swim</td><td>Dune</td><td>Oven</td><td>Harbour</td><td>Landscap</td></tr><tr><td>Boat</td><td>Highwai</td><td>Tv</td><td>Track</td><td>Fallen</td></tr><tr><td>Dock</td><td>Moon</td><td>Een</td><td>Southern</td><td>Lone</td></tr><tr><td>Sunset</td><td>Traffic</td><td>Shelf</td><td>Train</td><td>Hidden</td></tr><tr><td>Sky</td><td>Canyon</td><td>Breakfast</td><td>Mother</td><td>Hill</td></tr><tr><td>Airplan</td><td>Track</td><td>Dine</td><td>Star</td><td>Flow</td></tr><tr><td>Beach</td><td>Wind</td><td>Tabl</td><td>Light</td><td>Stream</td></tr><tr><td>Sea</td><td>Order</td><td>Ceil</td><td>Tank</td><td>Canyon</td></tr><tr><td>Coast</td><td>Cross</td><td>Candl</td><td>Traffic</td><td>Oak</td></tr><tr><td>Wave</td><td>Bridg</td><td>Lit</td><td>Night</td><td>Trail</td></tr><tr><td>Ski</td><td>Cabl</td><td>Sunris</td><td>Glow</td><td>Distanc</td></tr><tr><td>Clear</td><td>Ga</td><td>Chocol</td><td>Pass</td><td>Road</td></tr><tr><td>Lake</td><td>Drive</td><td>Second</td><td>Shadow</td><td>Camp</td></tr><tr><td>Ship</td><td>Fallen</td><td>Room</td><td>Salt</td><td>Creek</td></tr><tr><td>Moon</td><td>Colorado</td><td>Bathroom</td><td>Site</td><td>Grow</td></tr><tr><td>Sunris</td><td>Toward</td><td>Cherri</td><td>Wing</td><td>Wind</td></tr></table>

<table><tbody><tr><td>属性</td><td>帆船/小船</td><td>驾驶</td><td>吃饭</td><td>铁路</td><td>露营</td></tr><tr><td rowspan="20">前20个相关词</td><td>巡航</td><td>沙子</td><td>酒吧</td><td>月亮</td><td>草</td></tr><tr><td>港口</td><td>道路</td><td>橱柜</td><td>铁路</td><td>牧场</td></tr><tr><td>海洋</td><td>人行道</td><td>书桌</td><td>点亮</td><td>田野</td></tr><tr><td>帆</td><td>车道</td><td>厨房</td><td>暴露</td><td>森林</td></tr><tr><td>游泳</td><td>沙丘</td><td>烤箱</td><td>港湾</td><td>风景</td></tr><tr><td>船</td><td>高速公路</td><td>电视</td><td>轨道</td><td>倒下的</td></tr><tr><td>码头</td><td>月亮</td><td>一个</td><td>南方的</td><td>孤独的</td></tr><tr><td>日落</td><td>交通</td><td>架子</td><td>火车</td><td>隐藏的</td></tr><tr><td>天空</td><td>峡谷</td><td>早餐</td><td>母亲</td><td>山丘</td></tr><tr><td>飞机</td><td>轨道</td><td>用餐</td><td>星星</td><td>流动</td></tr><tr><td>海滩</td><td>风</td><td>桌子</td><td>光</td><td>小溪</td></tr><tr><td>海</td><td>顺序</td><td>天花板</td><td>坦克</td><td>峡谷</td></tr><tr><td>海岸</td><td>穿越</td><td>蜡烛</td><td>交通</td><td>橡树</td></tr><tr><td>波浪</td><td>桥</td><td>点亮</td><td>夜晚</td><td>小径</td></tr><tr><td>滑雪</td><td>电缆</td><td>日出</td><td>光辉</td><td>远方</td></tr><tr><td>晴朗</td><td>门</td><td>巧克力</td><td>通行</td><td>道路</td></tr><tr><td>湖</td><td>驾驶</td><td>第二</td><td>影子</td><td>营地</td></tr><tr><td>船</td><td>倒下的</td><td>房间</td><td>盐</td><td>小溪</td></tr><tr><td>月亮</td><td>科罗拉多</td><td>浴室</td><td>地点</td><td>生长</td></tr><tr><td>日出</td><td>朝向</td><td>樱桃</td><td>翅膀</td><td>风</td></tr></tbody></table>

Words are stemmed

词干提取

We use the 10,000 images and captions from Im2text dataset as our training set. We only consider the 1,000 most common words in the Im2text dataset as keywords. Let $n$ be the size of image dataset. We create an $n$ -long vector ${W}_{i}$ , for each word ${w}_{i}$ and an $n$ -long vector ${A}_{j}$ for each attribute ${a}_{j}$ . The $k$ th element of ${W}_{i}$ indicates if the word ${w}_{i}$ exists in the caption of the $k$ th example in the dataset. Similarly the $k$ th element of ${A}_{j}$ indicates if the attribute ${a}_{i}$ exists in the image of the $k$ th example in the dataset. For these experiments, an attribute exists in an image if the SVM classifier's confidence is above -0.75 . This threshold is set fairly low so that the attribute detections are not overly sparse.

我们使用Im2text数据集中的10,000张图像及其标题作为训练集。我们仅考虑Im2text数据集中最常见的1,000个词作为关键词。设$n$为图像数据集的大小。我们为每个词${w}_{i}$创建一个长度为$n$的向量${W}_{i}$，为每个属性${a}_{j}$创建一个长度为$n$的向量${A}_{j}$。${W}_{i}$的第$k$个元素表示词${w}_{i}$是否出现在数据集中第$k$个样本的标题中。同理，${A}_{j}$的第$k$个元素表示属性${a}_{i}$是否存在于数据集中第$k$个样本的图像中。对于这些实验，如果支持向量机(SVM)分类器的置信度高于-0.75，则认为属性存在于图像中。该阈值设置较低，以避免属性检测过于稀疏。

We use a binary-idf, binary-inverse document frequency, style weighting for word vectors and tf-idf, term frequency-inverse document frequency, style weighting for attribute vectors. In detail, if ${w}_{i}$ exists in the caption of the $k$ th example, the weight of the $k$ th element in ${W}_{i}$ is set to be $1/{f}_{w}$ , where ${f}_{w}$ is the inverse document frequency of ${w}_{i}$ ; otherwise the weight is zero. Similarly, if ${a}_{j}$ exists in the image of the $k$ th example, the weight of the $k$ th element in ${A}_{j}$ is set to be $\operatorname{conf}/{f}_{a}$ , where $\operatorname{conf}$ is the scene attribute confidence score passed through a sigmoid, and ${f}_{a}$ is the inverse document frequency of ${a}_{j}$ ; otherwise the weight is zero. Finally, the correlation between word ${w}_{i}$ and attribute ${a}_{j}$ is simply the inner product of ${W}_{i}$ and ${A}_{j};{C}_{ij} = {W}_{i} * {A}_{j}$ .

我们对词向量采用二元逆文档频率(binary-idf)加权，对属性向量采用词频-逆文档频率(tf-idf)加权。具体来说，如果${w}_{i}$出现在第$k$个样本的标题中，则${W}_{i}$中第$k$个元素的权重设为$1/{f}_{w}$，其中${f}_{w}$是${w}_{i}$的逆文档频率；否则权重为零。同理，如果${a}_{j}$存在于第$k$个样本的图像中，则${A}_{j}$中第$k$个元素的权重设为$\operatorname{conf}/{f}_{a}$，其中$\operatorname{conf}$是通过sigmoid函数处理后的场景属性置信度分数，${f}_{a}$是${a}_{j}$的逆文档频率；否则权重为零。最后，词${w}_{i}$与属性${a}_{j}$之间的相关性即为${W}_{i}$与${A}_{j};{C}_{ij} = {W}_{i} * {A}_{j}$的内积。

Table 4 Examples of top correlated attributes for words

表4 词语与其最高相关属性示例

<table><tr><td>Words</td><td>Kitchen</td><td>Mountain</td></tr><tr><td rowspan="10">Top 10 correlated attr.</td><td>Tiles</td><td>Far-away horizon</td></tr><tr><td>Enclosed area</td><td>Hiking</td></tr><tr><td>Cleaning</td><td>Camping</td></tr><tr><td>Reading</td><td>Natural</td></tr><tr><td>Wood (not part of a tree)</td><td>Foliage</td></tr><tr><td>Glossy</td><td>Vegetation</td></tr><tr><td>Electric/indoor lighting</td><td>Trees</td></tr><tr><td>Glass</td><td>Rugged scene</td></tr><tr><td>Eating</td><td>Shrubbery</td></tr><tr><td>Studying/learning</td><td>Leaves</td></tr><tr><td>Words</td><td>Beach</td><td>Dress</td></tr><tr><td rowspan="10">Top 10 correlated attr.</td><td>Ocean</td><td>Cloth</td></tr><tr><td>Far-away horizon</td><td>Medical activity</td></tr><tr><td>Sand</td><td>Enclosed area</td></tr><tr><td>Waves/surf</td><td>Paper</td></tr><tr><td>Sunbathing</td><td>No horizon</td></tr><tr><td>Sailing/boating</td><td>Sterile</td></tr><tr><td>Diving</td><td>Research</td></tr><tr><td>Swimming</td><td>Electric/indoor lighting</td></tr><tr><td>Still water</td><td>Stressful</td></tr><tr><td>Open area</td><td>Man-made</td></tr></table>

<table><tbody><tr><td>词语</td><td>厨房</td><td>山</td></tr><tr><td rowspan="10">前十相关属性</td><td>瓷砖</td><td>遥远的地平线</td></tr><tr><td>封闭区域</td><td>徒步</td></tr><tr><td>清洁</td><td>露营</td></tr><tr><td>阅读</td><td>自然的</td></tr><tr><td>木材(非树木部分)</td><td>叶子</td></tr><tr><td>有光泽的</td><td>植被</td></tr><tr><td>电灯/室内照明</td><td>树木</td></tr><tr><td>玻璃</td><td>崎岖的场景</td></tr><tr><td>吃饭</td><td>灌木丛</td></tr><tr><td>学习</td><td>树叶</td></tr><tr><td>词语</td><td>海滩</td><td>连衣裙</td></tr><tr><td rowspan="10">前十相关属性</td><td>海洋</td><td>布料</td></tr><tr><td>遥远的地平线</td><td>医疗活动</td></tr><tr><td>沙子</td><td>封闭区域</td></tr><tr><td>波浪/冲浪</td><td>纸张</td></tr><tr><td>日光浴</td><td>无地平线</td></tr><tr><td>航行/划船</td><td>无菌的</td></tr><tr><td>潜水</td><td>研究</td></tr><tr><td>游泳</td><td>电灯/室内照明</td></tr><tr><td>静水</td><td>压力大</td></tr><tr><td>开放区域</td><td>人造的</td></tr></tbody></table>

Binary-idf is very similar to tf-idf. The difference between the two is that for binary a word is counted only one for the document it appears in.The number of times the word appears in the document is not considered. If a word appears in one document, the binary-idf value will be 1/(inverse document frequency), otherwise the value is zero. Binary-idf can suppress some words that have little semantic meaning in terms of our scene attributes but appear often in the document. For example, the words "nice", "like" may appear more times than "sky" does in one document, but they are less informative and less related to our scene attributes.

Binary-idf与tf-idf非常相似。两者的区别在于binary中，一个词在文档中只计数一次，不考虑该词在文档中出现的次数。如果一个词出现在某个文档中，binary-idf的值为1/(逆文档频率)，否则值为零。Binary-idf可以抑制一些在我们的场景属性中语义意义较小但在文档中频繁出现的词。例如，“nice”、“like”这些词在某个文档中出现次数可能多于“sky”，但它们的信息量较低，与我们的场景属性关联较弱。

Table 3 shows top correlated words for attributes and Table 4 shows top correlated attributes for words. We find that attributes predicted by our classifiers have high correlation with text words. The correlations tend to be quite reasonable, e.g. for the attribute 'sailing/boating' the most correlated keywords are 'cruise', 'harbor', 'ocean', 'sail', 'swim', etc. Note some words are transformed because of stemming.

表3展示了属性的最高相关词，表4展示了词的最高相关属性。我们发现分类器预测的属性与文本词汇高度相关。这些相关性通常相当合理，例如对于属性“sailing/boating(航行/划船)”，最相关的关键词是“cruise(游轮)”、“harbor(港口)”、“ocean(海洋)”、“sail(航行)”、“swim(游泳)”等。注意有些词因词干提取而发生了变化。

<table><tr><td colspan="6">Attribute Top Returns</td></tr><tr><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_18.jpg?x=168&y=293&w=49&h=71&r=0"/> </td><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_18.jpg?x=266&y=238&w=193&h=143&r=0"/>  Great egret against the glorious blue sky.</td><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_18.jpg?x=549&y=236&w=163&h=116&r=0"/>  That grove of trees on the right half of the hori- zon is the forest around Wendi's parent's home.</td><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_18.jpg?x=832&y=238&w=161&h=117&r=0"/>  Great cloud formation over the mountains in Rocky Mountain Na- tional Park. 2008</td><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_18.jpg?x=1077&y=236&w=216&h=139&r=0"/>  Little pine tree in the big heath.</td><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_18.jpg?x=1388&y=237&w=143&h=103&r=0"/>  A battle in the sky. Stormy black rain clouds versus the dry hot white desert clouds.</td></tr><tr><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_18.jpg?x=169&y=462&w=54&h=159&r=0"/> </td><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_18.jpg?x=285&y=442&w=159&h=118&r=0"/>  flying birds with the beautiful overcast sky colored by the sun- rise</td><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_18.jpg?x=555&y=442&w=100&h=116&r=0"/>  I just loved the pink of this boat against the blue of the sky and the clouds.</td><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_18.jpg?x=837&y=442&w=153&h=99&r=0"/>  Taken in Mount. Bro- mo some time ago, when the sky is so blue and the cloud is so great.</td><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_18.jpg?x=1058&y=444&w=254&h=163&r=0"/>  castle in the clouds</td><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_18.jpg?x=1377&y=442&w=161&h=118&r=0"/>  The sun breaks through a cloud and illuminates a ship near the Golden Gate Bridge.</td></tr><tr><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_18.jpg?x=170&y=685&w=47&h=124&r=0"/> </td><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_18.jpg?x=282&y=647&w=164&h=124&r=0"/>  A stalk of brilliant yel- low and orange flowers in the mountains of Oa- xaca, Mexico.</td><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_18.jpg?x=557&y=648&w=162&h=123&r=0"/>  A little pink flower showing its beauty - Canon S5IS in Manual Mode</td><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_18.jpg?x=838&y=648&w=147&h=109&r=0"/>  I was standing over a railing, cursing the fact I didn't bring along my telephoto lense. Or a bottle of water.</td><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_18.jpg?x=1081&y=646&w=209&h=178&r=0"/>  Little pink in the flower</td><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_18.jpg?x=1361&y=650&w=196&h=146&r=0"/>  This was all over my pine tree it was really pretty.</td></tr><tr><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_18.jpg?x=173&y=913&w=44&h=67&r=0"/> </td><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_18.jpg?x=293&y=854&w=90&h=102&r=0"/>  tle green haired girl dressed up in that awesome clown out- fit!! Those boots were amazing!</td><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_18.jpg?x=528&y=852&w=145&h=172&r=0"/>  red rose in sunlight v</td><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_18.jpg?x=803&y=852&w=222&h=147&r=0"/>  Big new flower on new plant in the backyard.</td><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_18.jpg?x=1108&y=854&w=154&h=102&r=0"/>  olive oil in a dish on a piece of glass on tres- tles, coloured card on the floor lit by a halo- gen desk lamp...enjoy</td><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_18.jpg?x=1356&y=851&w=211&h=157&r=0"/>  Large dog at bar in Grand Lake</td></tr><tr><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_18.jpg?x=171&y=1069&w=47&h=176&r=0"/> </td><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_18.jpg?x=251&y=1059&w=225&h=154&r=0"/>  Cloud curtain over Table Mountain</td><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_18.jpg?x=536&y=1061&w=203&h=152&r=0"/>  Incredibly blue sky over Montserrat</td><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_18.jpg?x=836&y=1063&w=152&h=109&r=0"/>  The lighthouse is on the rock in the distance, the shore and obscuring most of the rock.</td><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_18.jpg?x=1048&y=1065&w=273&h=157&r=0"/>  Still little water in the river</td><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_18.jpg?x=1385&y=1060&w=150&h=110&r=0"/>  A beautiful view from the microwave tower 30, 2006.</td></tr><tr><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_18.jpg?x=183&y=1268&w=32&h=192&r=0"/> </td><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_18.jpg?x=254&y=1266&w=220&h=146&r=0"/>  in the airplane flying to chicago, 7/07</td><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_18.jpg?x=549&y=1268&w=178&h=113&r=0"/>  Mt. Rainier right before sunrise (5:30am). Note the blue sky that early in the morning.</td><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_18.jpg?x=824&y=1268&w=178&h=131&r=0"/>  looking out over the en- trance to ruby bowl on blackcomb mountain</td><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_18.jpg?x=1101&y=1266&w=170&h=121&r=0"/>  Drinking water after the spruce trap field on the traverse over Boundary to Iroquois from Algonquin</td><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_18.jpg?x=1372&y=1267&w=97&h=119&r=0"/>  A picture of a mountain during a train ride, taken by my sister Elizabeth, some- where near Anchorage.</td></tr><tr><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_18.jpg?x=174&y=1531&w=48&h=103&r=0"/> </td><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_18.jpg?x=254&y=1473&w=220&h=142&r=0"/>  an unlit candle in a frosty glass</td><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_18.jpg?x=543&y=1470&w=192&h=102&r=0"/>  Yvette makes her own heart. The red line in the back is a car that went past. Cool!</td><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_18.jpg?x=818&y=1474&w=188&h=125&r=0"/>  High contrast strong or- ange rose against a black background.</td><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_18.jpg?x=1099&y=1470&w=176&h=117&r=0"/>  we had to ask for beer in plastic cups at strike! bowling bar in Mel- bourne</td><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_18.jpg?x=1361&y=1469&w=183&h=117&r=0"/>  ghoOoOoOoOost driver! I was packing the car for move in day tomorrow(!) and no- ticed this in my mirror</td></tr></table>

<table><tbody><tr><td colspan="6">属性最高回报</td></tr><tr><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_18.jpg?x=168&y=293&w=49&h=71&r=0"/> </td><td><img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_18.jpg?x=266&y=238&w=193&h=143&r=0"/>  蓝天映衬下的苍鹭。</td><td><img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_18.jpg?x=549&y=236&w=163&h=116&r=0"/>  地平线右半边那片树林是温迪父母家的森林。</td><td><img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_18.jpg?x=832&y=238&w=161&h=117&r=0"/>  洛矶山国家公园山脉上空壮观的云层形成。2008年</td><td><img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_18.jpg?x=1077&y=236&w=216&h=139&r=0"/>  大石南地上的小松树。</td><td><img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_18.jpg?x=1388&y=237&w=143&h=103&r=0"/>  天空中的一场战斗。暴风雨般的黑色雨云与干燥炎热的白色沙漠云对峙。</td></tr><tr><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_18.jpg?x=169&y=462&w=54&h=159&r=0"/> </td><td><img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_18.jpg?x=285&y=442&w=159&h=118&r=0"/>  飞翔的鸟儿与被日出染色的美丽阴天天空。</td><td><img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_18.jpg?x=555&y=442&w=100&h=116&r=0"/>  我特别喜欢这艘船的粉色，与天空和云朵的蓝色形成鲜明对比。</td><td><img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_18.jpg?x=837&y=442&w=153&h=99&r=0"/>  这是前些时候在布罗莫山拍摄的，天空湛蓝，云朵壮丽。</td><td><img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_18.jpg?x=1058&y=444&w=254&h=163&r=0"/>  云中的城堡</td><td><img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_18.jpg?x=1377&y=442&w=161&h=118&r=0"/>  太阳穿透云层，照亮了金门大桥附近的一艘船。</td></tr><tr><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_18.jpg?x=170&y=685&w=47&h=124&r=0"/> </td><td><img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_18.jpg?x=282&y=647&w=164&h=124&r=0"/>  墨西哥瓦哈卡山区一枝鲜艳的黄橙色花朵。</td><td><img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_18.jpg?x=557&y=648&w=162&h=123&r=0"/>  一朵小粉花展现它的美丽——佳能S5IS手动模式拍摄</td><td><img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_18.jpg?x=838&y=648&w=147&h=109&r=0"/>  我站在栏杆上，懊恼没带长焦镜头，或者一瓶水。</td><td><img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_18.jpg?x=1081&y=646&w=209&h=178&r=0"/>  花中的一点粉色</td><td><img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_18.jpg?x=1361&y=650&w=196&h=146&r=0"/>  这满满都是我的松树，真的很漂亮。</td></tr><tr><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_18.jpg?x=173&y=913&w=44&h=67&r=0"/> </td><td><img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_18.jpg?x=293&y=854&w=90&h=102&r=0"/>  那个穿着超酷小丑服装的绿发女孩！！那些靴子真棒！</td><td><img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_18.jpg?x=528&y=852&w=145&h=172&r=0"/>  阳光下的红玫瑰</td><td><img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_18.jpg?x=803&y=852&w=222&h=147&r=0"/>  后院新植物上的大新花朵。</td><td><img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_18.jpg?x=1108&y=854&w=154&h=102&r=0"/>  橄榄油放在玻璃片上的盘子里，支架上，地板上的彩色卡片被卤素台灯照亮……享受吧</td><td><img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_18.jpg?x=1356&y=851&w=211&h=157&r=0"/>  大湖酒吧里的大狗</td></tr><tr><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_18.jpg?x=171&y=1069&w=47&h=176&r=0"/> </td><td><img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_18.jpg?x=251&y=1059&w=225&h=154&r=0"/>  桌山上的云幕</td><td><img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_18.jpg?x=536&y=1061&w=203&h=152&r=0"/>  蒙特塞拉特(Montserrat)上空极其蔚蓝的天空</td><td><img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_18.jpg?x=836&y=1063&w=152&h=109&r=0"/>  灯塔在远处的岩石上，海岸线遮挡了大部分岩石。</td><td><img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_18.jpg?x=1048&y=1065&w=273&h=157&r=0"/>  河里水仍然很少</td><td><img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_18.jpg?x=1385&y=1060&w=150&h=110&r=0"/>  2006年30日，从微波塔上看到的美丽景色。</td></tr><tr><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_18.jpg?x=183&y=1268&w=32&h=192&r=0"/> </td><td><img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_18.jpg?x=254&y=1266&w=220&h=146&r=0"/>  7月7日，飞往芝加哥的飞机上</td><td><img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_18.jpg?x=549&y=1268&w=178&h=113&r=0"/>  日出前的雷尼尔山(Mt. Rainier)(凌晨5:30)。注意那时的蓝天。</td><td><img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_18.jpg?x=824&y=1268&w=178&h=131&r=0"/>  俯瞰黑梳山(Blackcomb Mountain)红宝碗(Ruby Bowl)入口</td><td><img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_18.jpg?x=1101&y=1266&w=170&h=121&r=0"/>  在穿越边界到伊洛魁斯(Iroquois)途中，经过云杉陷阱地带后喝水，起点是阿尔冈昆(Algonquin)</td><td><img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_18.jpg?x=1372&y=1267&w=97&h=119&r=0"/>  火车上拍摄的山景照片，我姐姐伊丽莎白(Elizabeth)拍摄，地点在安克雷奇(Anchorage)附近某处。</td></tr><tr><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_18.jpg?x=174&y=1531&w=48&h=103&r=0"/> </td><td><img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_18.jpg?x=254&y=1473&w=220&h=142&r=0"/>  一个未点燃的蜡烛放在冰冷的玻璃杯中</td><td><img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_18.jpg?x=543&y=1470&w=192&h=102&r=0"/>  伊薇特创造了她自己的心。背景中的红线是一辆驶过的汽车。真酷！</td><td><img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_18.jpg?x=818&y=1474&w=188&h=125&r=0"/>  高对比度的鲜橙色玫瑰映衬在黑色背景上。</td><td><img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_18.jpg?x=1099&y=1470&w=176&h=117&r=0"/>  我们在墨尔本的Strike!保龄球吧不得不用塑料杯买啤酒</td><td><img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_18.jpg?x=1361&y=1469&w=183&h=117&r=0"/>  鬼魂司机！我正在为明天的搬家日打包汽车，镜子里突然看到这个</td></tr></tbody></table>

Fig. 21 Attribute based image retrieval results on $1\mathrm{M}\mathrm{{Im}}2\mathrm{{text}}$ dataset. IDF method (Fig. 22) uses the captions exclusively. These search terms Although the captions are shown here for completeness, our text-based image retrieval method did not see them at query time, whereas the TF-were selected for variety and breadth. We believe they are representative of results from our attribute based image retrieval pipeline generally

图21 基于属性的图像检索结果，使用$1\mathrm{M}\mathrm{{Im}}2\mathrm{{text}}$数据集。IDF方法(图22)仅使用了标题。虽然这里为了完整性展示了标题，但我们的基于文本的图像检索方法在查询时并未使用它们，而TF-选择这些搜索词是为了多样性和广度。我们认为它们能够代表我们基于属性的图像检索流程的一般结果。

#### 7.3.2 Word-to-Attribute Correlation Applied to Image Retrieval

#### 7.3.2 词汇与属性相关性在图像检索中的应用

Now that we can relate keywords to attributes, we apply the word-to-attribute correlation scores to the image retrieval task. Our text-based image retrieval approach is content-based because it does not rely on text metadata (captions) for the database images at query time. For example, if user inputs a text query "sky", we hope to map that text to its corresponding visual features (via attributes), such as blue background, clustered clouds and horizon line, and retrieve images which contain those visual features.

既然我们能够将关键词与属性关联起来，就将词汇与属性的相关性分数应用于图像检索任务。我们的基于文本的图像检索方法是基于内容的，因为它在查询时不依赖于数据库图像的文本元数据(标题)。例如，如果用户输入文本查询“天空”，我们希望将该文本映射到其对应的视觉特征(通过属性)，如蓝色背景、成簇的云朵和地平线，并检索包含这些视觉特征的图像。

<table><tr><td/><td/><td/><td>tf-idf Top Returns</td><td/><td/></tr><tr><td/><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_19.jpg?x=238&y=236&w=253&h=171&r=0"/>  aeroplane in sky</td><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_19.jpg?x=554&y=232&w=156&h=170&r=0"/>  aeroplane in sky</td><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_19.jpg?x=792&y=230&w=241&h=179&r=0"/>  hen in tha sky con</td><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_19.jpg?x=1065&y=233&w=243&h=177&r=0"/>  sunflower in sky</td><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_19.jpg?x=1325&y=232&w=275&h=167&r=0"/>  aeroplane in sky</td></tr><tr><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_19.jpg?x=173&y=463&w=47&h=157&r=0"/> </td><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_19.jpg?x=240&y=444&w=250&h=164&r=0"/>  sunlit tree in dark sky</td><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_19.jpg?x=524&y=444&w=228&h=168&r=0"/>  tree in dark sky</td><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_19.jpg?x=832&y=441&w=139&h=162&r=0"/>  dark sky in water</td><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_19.jpg?x=1048&y=440&w=264&h=173&r=0"/>  Dark sky over Opera house</td><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_19.jpg?x=1346&y=439&w=238&h=177&r=0"/>  dark sky by my house</td></tr><tr><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_19.jpg?x=173&y=685&w=43&h=124&r=0"/> </td><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_19.jpg?x=276&y=647&w=170&h=161&r=0"/>  flower mug in aqua</td><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_19.jpg?x=512&y=644&w=252&h=168&r=0"/>  flower in mug</td><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_19.jpg?x=797&y=646&w=232&h=170&r=0"/>  furry bee in flower</td><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_19.jpg?x=1062&y=645&w=253&h=168&r=0"/>  pony in flowers</td><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_19.jpg?x=1364&y=644&w=183&h=128&r=0"/>  Hummingbird hawk moth trapped in oenothera flower</td></tr><tr><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_19.jpg?x=175&y=912&w=41&h=68&r=0"/> </td><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_19.jpg?x=273&y=850&w=184&h=180&r=0"/>  feathered in red</td><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_19.jpg?x=540&y=851&w=156&h=130&r=0"/>  aa IMG_4580girl in red feathered headdress Car- nival Loule2010</td><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_19.jpg?x=785&y=851&w=254&h=176&r=0"/>  pavement in red</td><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_19.jpg?x=1069&y=850&w=231&h=170&r=0"/>  coach purse in red - \$75</td><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_19.jpg?x=1351&y=848&w=231&h=172&r=0"/>  Teo in red futon</td></tr><tr><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_19.jpg?x=175&y=1069&w=43&h=176&r=0"/> </td><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_19.jpg?x=262&y=1059&w=122&h=148&r=0"/>  Fish-like moth in Tennes- see mountains</td><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_19.jpg?x=540&y=1059&w=197&h=144&r=0"/>  piglet in karkonosze mountains</td><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_19.jpg?x=808&y=1056&w=187&h=130&r=0"/>  mountains in obudu cattle ranchTitle/caption credit: Amadioha</td><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_19.jpg?x=1077&y=1056&w=124&h=157&r=0"/>  open-air classroom in the mountains</td><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_19.jpg?x=1340&y=1055&w=115&h=154&r=0"/>  A juvenile mountain gorilla in Bwindi</td></tr><tr><td/><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_19.jpg?x=232&y=1261&w=234&h=145&r=0"/>  My house with snow capped mountains in the distance...</td><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_19.jpg?x=509&y=1263&w=125&h=165&r=0"/>  Snow mountain in the sky</td><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_19.jpg?x=802&y=1260&w=218&h=145&r=0"/>  a snow bridge over a mountain waterfall</td><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_19.jpg?x=1073&y=1261&w=229&h=139&r=0"/>  a lake on the snow mountain in Daocheng</td><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_19.jpg?x=1370&y=1261&w=179&h=132&r=0"/>  snow reveals the struc- ture of the sedimentary rocks in the mountains</td></tr><tr><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_19.jpg?x=175&y=1530&w=44&h=103&r=0"/> </td><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_19.jpg?x=240&y=1469&w=246&h=163&r=0"/>  Night in the tree house</td><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_19.jpg?x=522&y=1470&w=230&h=170&r=0"/>  night in the tree house</td><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_19.jpg?x=812&y=1466&w=203&h=150&r=0"/>  night in the tree house 7 – steve</td><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_19.jpg?x=1057&y=1468&w=260&h=165&r=0"/>  tree house by night</td><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_19.jpg?x=1370&y=1468&w=106&h=128&r=0"/>  A house is illuminated by a streetlight at night in Saigon, Vietnam.</td></tr></table>

<table><tbody><tr><td></td><td></td><td></td><td>tf-idf 最高返回结果</td><td></td><td></td></tr><tr><td></td><td><img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_19.jpg?x=238&y=236&w=253&h=171&r=0"/> 天空中的飞机</td><td><img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_19.jpg?x=554&y=232&w=156&h=170&r=0"/> 天空中的飞机</td><td><img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_19.jpg?x=792&y=230&w=241&h=179&r=0"/> 天空中的母鸡</td><td><img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_19.jpg?x=1065&y=233&w=243&h=177&r=0"/> 天空中的向日葵</td><td><img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_19.jpg?x=1325&y=232&w=275&h=167&r=0"/> 天空中的飞机</td></tr><tr><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_19.jpg?x=173&y=463&w=47&h=157&r=0"/> </td><td><img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_19.jpg?x=240&y=444&w=250&h=164&r=0"/> 黑暗天空中阳光照耀的树</td><td><img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_19.jpg?x=524&y=444&w=228&h=168&r=0"/> 黑暗天空中的树</td><td><img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_19.jpg?x=832&y=441&w=139&h=162&r=0"/> 水中的黑暗天空</td><td><img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_19.jpg?x=1048&y=440&w=264&h=173&r=0"/> 歌剧院上空的黑暗天空</td><td><img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_19.jpg?x=1346&y=439&w=238&h=177&r=0"/> 我家旁的黑暗天空</td></tr><tr><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_19.jpg?x=173&y=685&w=43&h=124&r=0"/> </td><td><img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_19.jpg?x=276&y=647&w=170&h=161&r=0"/> 水绿色杯中的花</td><td><img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_19.jpg?x=512&y=644&w=252&h=168&r=0"/> 杯子里的花</td><td><img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_19.jpg?x=797&y=646&w=232&h=170&r=0"/> 花中的毛茸茸蜜蜂</td><td><img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_19.jpg?x=1062&y=645&w=253&h=168&r=0"/> 花丛中的小马</td><td><img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_19.jpg?x=1364&y=644&w=183&h=128&r=0"/> 被困在月见草花中的蜂鸟鹰蛾</td></tr><tr><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_19.jpg?x=175&y=912&w=41&h=68&r=0"/> </td><td><img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_19.jpg?x=273&y=850&w=184&h=180&r=0"/> 红色羽毛装饰</td><td><img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_19.jpg?x=540&y=851&w=156&h=130&r=0"/> aa IMG_4580 穿红色羽毛头饰的女孩，2010年卢莱狂欢节</td><td><img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_19.jpg?x=785&y=851&w=254&h=176&r=0"/> 红色的人行道</td><td><img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_19.jpg?x=1069&y=850&w=231&h=170&r=0"/> 红色Coach(蔻驰)手提包 - 75美元</td><td><img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_19.jpg?x=1351&y=848&w=231&h=172&r=0"/> 红色榻榻米上的Teo</td></tr><tr><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_19.jpg?x=175&y=1069&w=43&h=176&r=0"/> </td><td><img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_19.jpg?x=262&y=1059&w=122&h=148&r=0"/> 田纳西山脉中的鱼形蛾</td><td><img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_19.jpg?x=540&y=1059&w=197&h=144&r=0"/> 卡尔科诺谢山脉中的小猪</td><td><img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_19.jpg?x=808&y=1056&w=187&h=130&r=0"/> 奥布杜牛场的山脉 标题/图片来源:Amadioha</td><td><img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_19.jpg?x=1077&y=1056&w=124&h=157&r=0"/> 山中的露天教室</td><td><img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_19.jpg?x=1340&y=1055&w=115&h=154&r=0"/> 布温迪的幼年山地大猩猩</td></tr><tr><td></td><td><img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_19.jpg?x=232&y=1261&w=234&h=145&r=0"/> 我家，远处是积雪覆盖的群山……</td><td><img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_19.jpg?x=509&y=1263&w=125&h=165&r=0"/> 天空中的雪山</td><td><img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_19.jpg?x=802&y=1260&w=218&h=145&r=0"/> 山间瀑布上的雪桥</td><td><img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_19.jpg?x=1073&y=1261&w=229&h=139&r=0"/> 道成雪山上的湖泊</td><td><img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_19.jpg?x=1370&y=1261&w=179&h=132&r=0"/> 积雪显露出山中沉积岩的结构</td></tr><tr><td> <img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_19.jpg?x=175&y=1530&w=44&h=103&r=0"/> </td><td><img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_19.jpg?x=240&y=1469&w=246&h=163&r=0"/> 树屋之夜</td><td><img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_19.jpg?x=522&y=1470&w=230&h=170&r=0"/> 树屋之夜</td><td><img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_19.jpg?x=812&y=1466&w=203&h=150&r=0"/> 树屋之夜7 – 史蒂夫</td><td><img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_19.jpg?x=1057&y=1468&w=260&h=165&r=0"/> 夜晚的树屋</td><td><img src="https://cdn.noedgeai.com/bo_d1c3uev7aajc7389qf6g_19.jpg?x=1370&y=1468&w=106&h=128&r=0"/>越南西贡夜晚，一盏路灯照亮了一栋房子。</td></tr></tbody></table>

Fig. 22 Tf-idf based image retrieval results on $1\mathrm{M}\mathrm{{Im}}2$ text dataset

图22 基于Tf-idf的$1\mathrm{M}\mathrm{{Im}}2$文本数据集图像检索结果

Given the query text, we break the text into words. Let ${T}_{\text{query }}$ be the vector of query word indices. These indices are the positions of the query words in the list of 1,000 most common caption words. We use ${T}_{\text{query }}$ and word-attribute correlation we have obtained to create a "target" scene attributes representation. Each word ${w}_{i}$ has a vector of correlations ${C}_{i} =  < {c}_{i,1},\ldots ,{c}_{i, j},\ldots ,{c}_{i,{102}} >$ , where each element ${c}_{i, j}$ is the correlation of word ${w}_{i}$ and attribute ${a}_{j}$ . The target scene attribute representation is defined as the average of correlation vectors of the words in the query,

给定查询文本，我们将文本拆分成单词。设${T}_{\text{query }}$为查询单词索引向量。这些索引是查询单词在1000个最常见标题词列表中的位置。我们利用${T}_{\text{query }}$和已获得的词-属性相关性来创建“目标”场景属性表示。每个单词${w}_{i}$都有一个相关性向量${C}_{i} =  < {c}_{i,1},\ldots ,{c}_{i, j},\ldots ,{c}_{i,{102}} >$，其中每个元素${c}_{i, j}$是单词${w}_{i}$与属性${a}_{j}$的相关性。目标场景属性表示定义为查询中单词相关性向量的平均值，

$$
{F}_{\text{target }} = \frac{1}{N}\mathop{\sum }\limits_{{k = 1}}^{N}{C}_{{T}_{\text{query }, k}} \tag{1}
$$

where $\mathrm{N}$ is the length of ${T}_{query}$ , and ${T}_{{query}, k}$ is the $k$ th element of ${T}_{query}$ , the index of the $k$ th query word in common words list. We consider the same word multiple times if it appears multiple times in the caption.

其中$\mathrm{N}$是${T}_{query}$的长度，${T}_{{query}, k}$是${T}_{query}$的第$k$个元素，即第$k$个查询单词在常用词列表中的索引。如果同一单词在标题中出现多次，则多次计入。

We then learn multi-linear regressions to map target scene attributes to predicted scene attributes, which are the output feature vectors of attributes classifiers. In the training dataset, for each image, we know both its target attributes and predicted attributes. We then learn the regression to map from those attributes in the target representation to ${a}_{j}$ in the predicted representation. Finally, we search for the nearest neighbors of the query's predicted attribute representation in the test dataset.

然后我们学习多线性回归，将目标场景属性映射到预测场景属性，后者是属性分类器的输出特征向量。在训练数据集中，对于每张图像，我们同时知道其目标属性和预测属性。接着我们学习回归，将目标表示中的属性映射到预测表示中的${a}_{j}$。最后，我们在测试数据集中搜索查询预测属性表示的最近邻。

#### 7.3.3 Experiments

#### 7.3.3 实验

For testing we search 90,000 captioned images from the Im2text dataset. We compare our method to tf-idf based retrieval because it is a widely used baseline method for text-based image retrieval. Figures 21 and 22 show the results of both methods separately. From the results, we can see that attribute-based image retrieval gives very promising search results. For most search results returned by attribute-based method, the target specified by the query text are the dominant visual concept in the retrieved images. However, that is not the case for tf-idf based method. For example, for the "flower" query, the five images returned by the attribute-based method all depict flowers, while the dominant objects in images returned by the tf-idf based method contain a mug, pony and bee. Our method also has some success with multiple keyword queries. For the queries "snow mountain" and "dark sky" most of the retrieved scenes have the correct semantics. These qualitative results again reinforce the idea that the 102 dimensional scene attributes are surprisingly expressive given their compact size and that our attribute classifiers are reliable enough to support other image understanding applications.

测试时，我们从Im2text数据集中搜索9万张带标题的图像。我们将方法与基于tf-idf的检索进行比较，因为后者是文本图像检索中广泛使用的基线方法。图21和图22分别展示了两种方法的结果。从结果看，基于属性的图像检索表现出非常有前景的搜索效果。对于大多数基于属性方法返回的搜索结果，查询文本指定的目标是检索图像中的主要视觉概念。但基于tf-idf的方法则不然。例如，对于“flower”查询，基于属性方法返回的五张图像均描绘了花，而基于tf-idf方法返回的图像中主要对象包含杯子、小马和蜜蜂。我们的方法在多关键词查询上也取得了一定成功。对于“snow mountain”和“dark sky”查询，大多数检索场景语义正确。这些定性结果再次强化了102维场景属性在紧凑尺寸下表现出的惊人表达力，以及我们的属性分类器足够可靠，能够支持其他图像理解应用。

## 8 Discussion

## 8 讨论

In this paper, we use crowdsourcing to generate a taxonomy of scene attributes and then annotate more than ten thousand images with individual attribute labels. In order to promote the trustworthy responses from the Mechanical Turk users we employ several simple yet effective techniques for quality control. We explore the space of our discovered scene attributes, revealing the interplay between attributes and scene categories. We measure how well our scene attributes can be recognized and how well predicted attributes work as an intermediate representation for zero shot learning and image retrieval tasks.

本文利用众包生成了场景属性分类法，并为一万多张图像标注了单独的属性标签。为了促进Mechanical Turk用户的可信响应，我们采用了几种简单而有效的质量控制技术。我们探索了发现的场景属性空间，揭示了属性与场景类别之间的相互作用。我们评估了场景属性的识别效果，以及预测属性作为零样本学习和图像检索任务中间表示的表现。

### 8.1 Future Work

### 8.1 未来工作

Scene attributes are a fertile, unexplored recognition domain. Many attributes are visually quite subtle and nearly all scene descriptors in the literature were developed for the task of scene categorization and may not be the optimal descriptors for attribute recognition. Even though all of our attribute labels are global, many attributes have clear spatial support (materials) while others may not (functions and affor-dances). Techniques from weakly supervised object recognition might have success at discovering the spatial support of our global attributes where applicable. Classification methods which exploit the correlation between attributes might also improve accuracy when recognizing attributes simultaneously. We hope that the scale and variety of our dataset will enable many future explorations in the exciting space of visual attributes.

场景属性是一个富有潜力且未被充分探索的识别领域。许多属性在视觉上相当细微，且文献中几乎所有场景描述符均为场景分类任务开发，可能并非属性识别的最优描述符。尽管我们的所有属性标签均为全局标签，许多属性具有明确的空间支持(如材质)，而其他属性则可能没有(如功能和可供性)。弱监督目标识别技术或许能成功发现适用的全局属性的空间支持。利用属性间相关性的分类方法也可能在同时识别属性时提高准确率。我们希望数据集的规模和多样性能促进未来在视觉属性这一激动人心领域的诸多探索。

Acknowledgments We thank Vazheh Moussavi (Brown Univ.) for his insights and contributions in the data annotation process. Genevieve Patterson is supported by the Department of Defense (DoD) through the National Defense Science & Engineering Graduate Fellowship (NDSEG) Program. This work is also funded by NSF CAREER Award 1149853 to James Hays.

致谢 感谢Vazheh Moussavi(布朗大学)在数据标注过程中的见解和贡献。Genevieve Patterson获得国防部(DoD)国家防御科学与工程研究生奖学金(NDSEG)项目支持。本工作还得到了NSF CAREER奖1149853(James Hays)的资助。

## Appendix: Scene Attributes

## 附录:场景属性

See Appendix Table 5. References

见附录表5。参考文献

Table 5 Complete list of discovered scene attributes

表5 发现的完整场景属性列表

<table><tr><td colspan="2">Scene attributes</td></tr><tr><td colspan="2">Functions/affordances</td></tr><tr><td>Sailing/boating</td><td>Driving</td></tr><tr><td>Biking</td><td>Transporting things or people</td></tr><tr><td>Sunbathing</td><td>Vacationing/touring</td></tr><tr><td>Hiking</td><td>Climbing</td></tr><tr><td>Camping</td><td>Reading</td></tr><tr><td>Studying/learning</td><td>Teaching/training</td></tr><tr><td>Research</td><td>Diving</td></tr><tr><td>Swimming</td><td>Bathing</td></tr><tr><td>Eating</td><td>Cleaning</td></tr><tr><td>Socializing</td><td>Congregating</td></tr><tr><td>Waiting in line/queuing</td><td>Competing</td></tr><tr><td>Sports</td><td>Exercise</td></tr><tr><td>Playing</td><td>Gaming</td></tr><tr><td>Spectating/being in an audience</td><td>Farming</td></tr><tr><td>Constructing/building</td><td>Shopping</td></tr><tr><td>Medical activity</td><td>Working</td></tr><tr><td>Using tools</td><td>Digging</td></tr><tr><td>Conducting business</td><td>Praying</td></tr></table>

<table><tbody><tr><td colspan="2">场景属性</td></tr><tr><td colspan="2">功能/用途</td></tr><tr><td>航海/划船</td><td>驾驶</td></tr><tr><td>骑行</td><td>运输物品或人员</td></tr><tr><td>日光浴</td><td>度假/旅游</td></tr><tr><td>徒步</td><td>攀岩</td></tr><tr><td>露营</td><td>阅读</td></tr><tr><td>学习</td><td>教学/培训</td></tr><tr><td>研究</td><td>潜水</td></tr><tr><td>游泳</td><td>洗澡</td></tr><tr><td>进食</td><td>清洁</td></tr><tr><td>社交</td><td>聚集</td></tr><tr><td>排队等待</td><td>竞赛</td></tr><tr><td>体育运动</td><td>锻炼</td></tr><tr><td>玩耍</td><td>游戏</td></tr><tr><td>观赛/观众</td><td>农业</td></tr><tr><td>建筑/施工</td><td>购物</td></tr><tr><td>医疗活动</td><td>工作</td></tr><tr><td>使用工具</td><td>挖掘</td></tr><tr><td>经商</td><td>祈祷</td></tr></tbody></table>

Table 5 continued

表5续

<table><tr><td colspan="2">Materials</td></tr><tr><td>Fencing</td><td>Railing</td></tr><tr><td>Wire</td><td>Railroad</td></tr><tr><td>Trees</td><td>Grass</td></tr><tr><td>Vegetation</td><td>Shrubbery</td></tr><tr><td>Foliage</td><td>Leaves</td></tr><tr><td>Flowers</td><td>Asphalt</td></tr><tr><td>Pavement</td><td>Shingles</td></tr><tr><td>Carpet</td><td>Brick</td></tr><tr><td>Tiles</td><td>Concrete</td></tr><tr><td>Metal</td><td>Paper</td></tr><tr><td>Wood (not part of a tree)</td><td>Vinyl/linoleum</td></tr><tr><td>Pubber/plastic</td><td>Cloth</td></tr><tr><td>Sand</td><td>Rock/stone</td></tr><tr><td>Dirt/soil</td><td>Marble</td></tr><tr><td>Glass</td><td>Waves/surf</td></tr><tr><td>Ocean</td><td>Running water</td></tr><tr><td>Still water</td><td>Ice</td></tr><tr><td>Snow</td><td>Clouds</td></tr><tr><td>Smoke</td><td>Fire</td></tr><tr><td colspan="2">Surface properties/lighting</td></tr><tr><td>Natural light</td><td>Direct sun/sunny</td></tr><tr><td>Electric/indoor lighting</td><td>Aged/worn</td></tr><tr><td>Glossy</td><td>Matte</td></tr><tr><td>Sterile</td><td>Moist/damp</td></tr><tr><td>Dry</td><td>Dirty</td></tr><tr><td>Rusty</td><td>Warm</td></tr><tr><td>Cold</td><td/></tr><tr><td colspan="2">Spatial envelope</td></tr><tr><td>Natural</td><td>Man-made</td></tr><tr><td>Open area</td><td>Semi-enclosed area</td></tr><tr><td>Enclosed area</td><td>Far-away horizon</td></tr><tr><td>No horizon</td><td>Rugged scene</td></tr><tr><td>Mostly vertical components</td><td>Mostly horizontal components</td></tr><tr><td>Symmetrical</td><td>Cluttered space</td></tr><tr><td>Scary</td><td>Soothing</td></tr><tr><td colspan="2">Stressful</td></tr></table>

<table><tbody><tr><td colspan="2">材料</td></tr><tr><td>围栏</td><td>栏杆</td></tr><tr><td>铁丝</td><td>铁路</td></tr><tr><td>树木</td><td>草</td></tr><tr><td>植被</td><td>灌木丛</td></tr><tr><td>叶子</td><td>树叶</td></tr><tr><td>花朵</td><td>沥青</td></tr><tr><td>人行道</td><td>瓦片</td></tr><tr><td>地毯</td><td>砖块</td></tr><tr><td>瓷砖</td><td>混凝土</td></tr><tr><td>金属</td><td>纸张</td></tr><tr><td>木材(非树木部分)</td><td>乙烯基/油毡</td></tr><tr><td>橡胶/塑料</td><td>布料</td></tr><tr><td>沙子</td><td>岩石/石头</td></tr><tr><td>泥土/土壤</td><td>大理石</td></tr><tr><td>玻璃</td><td>波浪/海浪</td></tr><tr><td>海洋</td><td>流动的水</td></tr><tr><td>静止的水</td><td>冰</td></tr><tr><td>雪</td><td>云</td></tr><tr><td>烟雾</td><td>火焰</td></tr><tr><td colspan="2">表面特性/光照</td></tr><tr><td>自然光</td><td>直射阳光/晴朗</td></tr><tr><td>电灯/室内照明</td><td>陈旧/磨损</td></tr><tr><td>光滑</td><td>哑光</td></tr><tr><td>无菌</td><td>潮湿</td></tr><tr><td>干燥</td><td>肮脏</td></tr><tr><td>生锈</td><td>温暖</td></tr><tr><td>寒冷</td><td></td></tr><tr><td colspan="2">空间包络</td></tr><tr><td>自然的</td><td>人造的</td></tr><tr><td>开阔区域</td><td>半封闭区域</td></tr><tr><td>封闭区域</td><td>远处地平线</td></tr><tr><td>无地平线</td><td>崎岖场景</td></tr><tr><td>主要为垂直构件</td><td>主要为水平构件</td></tr><tr><td>对称的</td><td>杂乱的空间</td></tr><tr><td>可怕的</td><td>令人舒缓的</td></tr><tr><td colspan="2">紧张的</td></tr></tbody></table>

Berg, T., Berg, a, & Shih, J. (2010). Automatic attribute discovery and characterization from noisy web data. ECCV, 6311, 663-676.

Berg, T., Berg, a, & Shih, J. (2010). 从噪声网络数据中自动发现和表征属性。ECCV, 6311, 663-676。

Chen, D., & Dolan, W. (2011). Building a persistent workforce on mechanical turk for multilingual data collection. In The 3rd human computation workshop (HCOMP).

Chen, D., & Dolan, W. (2011). 在Mechanical Turk上构建持久的多语言数据收集劳动力。发表于第三届人类计算研讨会(HCOMP)。

Deng, J., Dong, W., Socher, R., Li, LJ., Li, K., & Fei-Fei, L. (2009). ImageNet: A large-scale hierarchical image database. In CVPR.

Deng, J., Dong, W., Socher, R., Li, LJ., Li, K., & Fei-Fei, L. (2009). ImageNet:一个大规模分层图像数据库。发表于CVPR。

Ehinger, KA., Xiao, J., Torralba, A., & Oliva, A. (2011). Estimating scene typicality from human ratings and image features. In 33rd annual conference of the cognitive science society.

Ehinger, KA., Xiao, J., Torralba, A., & Oliva, A. (2011). 基于人类评分和图像特征估计场景典型性。发表于第33届认知科学学会年会。

Eigen, D., & Fergus, R. (2012). Nonparametric image parsing using adaptive neighbor sets. In Computer vision and pattern recognition (CVPR), 2012 IEEE Conference on (pp. 2799-2806). doi:10.1109/ CVPR.2012.6248004.

Eigen, D., & Fergus, R. (2012). 使用自适应邻域集的非参数图像解析。发表于2012年IEEE计算机视觉与模式识别会议(CVPR)，第2799-2806页。doi:10.1109/CVPR.2012.6248004。

Endres, I., Farhadi, A., Hoiem, D., & Forsyth, D. (2010). The benefits and challenges of collecting richer object annotations. In ${ACVHL}$ 2010 (in conjunction with CVPR).

Endres, I., Farhadi, A., Hoiem, D., & Forsyth, D. (2010). 收集更丰富的对象标注的益处与挑战。发表于${ACVHL}$ 2010(与CVPR联合举办)。

Farhadi, A., Endres, I., Hoiem, D., & Forsyth, D. (2009). Describing objects by their attributes. In ${CVPR}$ .

Farhadi, A., Endres, I., Hoiem, D., & Forsyth, D. (2009). 通过属性描述对象。发表于${CVPR}$。

Farhadi, A., Endres, I., & Hoiem, D. (2010a). Attribute-centric recognition for cross-category generalization. In ${CVPR}$ .

Farhadi, A., Endres, I., & Hoiem, D. (2010a). 基于属性的跨类别泛化识别。发表于${CVPR}$。

Farhadi, A., Hejrati, M., Sadeghi, MA., Young, P., Rashtchian1, C., Hockenmaier, J., & Forsyth, DA. (2010b) Every picture tells a story: Generating sentences from images. In Proc ECCV.

Farhadi, A., Hejrati, M., Sadeghi, MA., Young, P., Rashtchian1, C., Hockenmaier, J., & Forsyth, DA. (2010b) 每张图片都讲述一个故事:从图像生成句子。发表于ECCV会议论文集。

Ferrari, V., & Zisserman, A. (2008). Learning visual attributes. NIPS 2007

Ferrari, V., & Zisserman, A. (2008). 学习视觉属性。NIPS 2007。

Gould, S., Fulton, R., & Koller, D. (2009). Decomposing a scene into geometric and semantically consistent regions. In Computer vision, 2009 IEEE 12th International Conference on (pp. 1-8). doi:10.1109/ ICCV.2009.5459211.

Gould, S., Fulton, R., & Koller, D. (2009). 将场景分解为几何和语义一致的区域。发表于2009年IEEE第12届国际计算机视觉会议(ICCV)，第1-8页。doi:10.1109/ICCV.2009.5459211。

Greene, M., & Oliva, A. (2009). Recognition of natural scenes from global properties: Seeing the forest without representing the trees. Cognitive Psychology, 58(2), 137-176.

Greene, M., & Oliva, A. (2009). 基于全局属性的自然场景识别:不描绘树木而见森林。认知心理学，58(2), 137-176。

He, X., Zemel, R., & Carreira-Perpinan, M. (2004). Multiscale conditional random fields for image labeling. In Computer vision and pattern recognition, 2004. CVPR 2004. Proceedings of the 2004 IEEE computer society conference on (Vol. 2, pp. II-695-II-702). doi:10. 1109/CVPR.2004.1315232.

He, X., Zemel, R., & Carreira-Perpinan, M. (2004). 用于图像标注的多尺度条件随机场。发表于2004年IEEE计算机视觉与模式识别会议(CVPR 2004)，第2卷，II-695-II-702页。doi:10.1109/CVPR.2004.1315232。

Hironobu, YM., Takahashi, H., & Oka, R. (1999). Image-to-word transformation based on dividing and vector quantizing images with words. In Boltzmann machines, neural networks, (pp. 405409).

Hironobu, YM., Takahashi, H., & Oka, R. (1999). 基于图像与词语的划分和矢量量化的图像到词语转换。发表于玻尔兹曼机与神经网络，405-409页。

Hoiem, D., Efros, A. A., & Hebert, M. (2007). Recovering surface layout from an image. International Journal of Computer Vision, 75(1), 151-172.

Hoiem, D., Efros, A. A., & Hebert, M. (2007). 从图像恢复表面布局。国际计算机视觉杂志，75(1), 151-172。

Kovashka, A., Parikh, D., & Grauman, K. (2012). Whittlesearch: Image search with relative attribute feedback. In The IEEE conference on computer vision and pattern recognition (CVPR).

Kovashka, A., Parikh, D., & Grauman, K. (2012). Whittlesearch:基于相对属性反馈的图像搜索。发表于IEEE计算机视觉与模式识别会议(CVPR)。

Kulkarni, G., Premraj, V., Ordonez, V., Dhar, S., Li, S., Choi, Y., Berg, AC., & Berg, TL. (2013). Babytalk: Understanding and generating simple image descriptions. In IEEE transactions on pattern analysis and machine intelligence (TPAMI).

Kulkarni, G., Premraj, V., Ordonez, V., Dhar, S., Li, S., Choi, Y., Berg, AC., & Berg, TL. (2013). Babytalk:理解与生成简单图像描述。发表于IEEE模式分析与机器智能汇刊(TPAMI)。

Kumar, N., Berg, A., Belhumeur, P., & Nayar, S. (2009). Attribute and simile classifiers for face verification. In ${ICCV}$ .

Kumar, N., Berg, A., Belhumeur, P., & Nayar, S. (2009). 用于人脸验证的属性和明喻分类器。发表于${ICCV}$ 。

Kumar, N., Berg, AC., Belhumeur, PN., & Nayar, SK. (2011). Describable visual attributes for face verification and image search. In IEEE transactions on pattern analysis and machine intelligence (PAMI).

Kumar, N., Berg, AC., Belhumeur, PN., & Nayar, SK. (2011). 可描述视觉属性用于人脸验证和图像检索。发表于IEEE模式分析与机器智能汇刊(PAMI)。

Ladicky, L., Sturgess, P., Alahari, K., Russell, C., & Torr, PH. (2010). What, where and how many? combining object detectors and crfs. In Computer vision-ECCV 2010, Springer (pp. 424-437).

Ladicky, L., Sturgess, P., Alahari, K., Russell, C., & Torr, PH. (2010). 什么、在哪里以及多少？结合目标检测器与条件随机场(CRFs)。发表于计算机视觉-ECCV 2010，Springer(第424-437页)。

Lampert, CH., Nickisch, H., & Harmeling, S. (2009). Learning to detect unseen object classes by between-class attribute transfer. In CVPR.

Lampert, CH., Nickisch, H., & Harmeling, S. (2009). 通过类间属性迁移学习检测未见过的目标类别。发表于CVPR。

Lasecki, M., White, M., & Bigham, K. (2011). Real-time crowd control of existing interfaces. In UIST.

Lasecki, M., White, M., & Bigham, K. (2011). 现有界面的实时人群控制。发表于UIST。

Lazebnik, S., Schmid, C., & Ponce, J. (2006). Beyond bags of features: Spatial pyramid matching for recognizing natural scene categories. In ${CVPR}$ .

Lazebnik, S., Schmid, C., & Ponce, J. (2006). 超越特征袋:用于识别自然场景类别的空间金字塔匹配。发表于${CVPR}$ 。

Liu, C., Yuen, J., & Torralba, A. (2011a). Nonparametric scene parsing via label transfer. IEEE Transactions on Pattern Analysis and Machine Intelligence, 33(12), 2368-2382.

Liu, C., Yuen, J., & Torralba, A. (2011a). 通过标签转移的非参数场景解析。IEEE模式分析与机器智能汇刊，33(12)，2368-2382。

Liu, J., Kuipers, B., & Savarese, S. (2011b). Recognizing human actions by Attributes. In ${CVPR}$ .

Liu, J., Kuipers, B., & Savarese, S. (2011b). 通过属性识别人类动作。发表于${CVPR}$ 。

Van der Maaten, L., & Hinton, G. (2008). Visualizing data using t-sne. Journal of Machine Learning Research, 9(2579-2605), 85.

Van der Maaten, L., & Hinton, G. (2008). 使用t-SNE进行数据可视化。机器学习研究杂志，9(2579-2605)，85。

Malisiewicz, T., & Efros, AA. (2008). Recognition by association via learning per-exemplar distances. In Computer vision and pattern recognition, 2008. CVPR 2008. IEEE Conference on, IEEE (pp. 1- 8).

Malisiewicz, T., & Efros, AA. (2008). 通过学习每个样本间距的关联识别。发表于计算机视觉与模式识别，2008年CVPR会议，IEEE(第1-8页)。

Oliva, A., & Torralba, A. (2001). Modeling the shape of the scene: A holistic representation of the spatial envelope. IJCV, 42(3), 145-175.

Oliva, A., & Torralba, A. (2001). 场景形状建模:空间包络的整体表示。国际计算机视觉杂志(IJCV)，42(3)，145-175。

Oliva, A., & Torralba, A. (2002). Scene-centered description from spatial envelope properties. In 2nd Wworkshop on biologically motivated computer vision (BMCV).

Oliva, A., & Torralba, A. (2002). 基于空间包络属性的场景中心描述。发表于第二届生物启发计算机视觉研讨会(BMCV)。

Ordonez, V., Kulkarni, G.,& Berg, TL. (2011). Im2text: Describing images using 1 million captioned photographs. In Neural information processing systems (NIPS).

Ordonez, V., Kulkarni, G.,& Berg, TL. (2011). Im2text:利用100万带标题照片描述图像。发表于神经信息处理系统会议(NIPS)。

Palatucci, M., Pomerleau, D., Hinton, GE., & Mitchell, TM. (2009). Zero-shot learning with semantic output codes. In Advances in neural information processing systems (pp. 1410-1418).

Palatucci, M., Pomerleau, D., Hinton, GE., & Mitchell, TM. (2009). 使用语义输出码的零样本学习。发表于神经信息处理系统进展(第1410-1418页)。

Papineni, K., Roukos, S., Ward, T., & Zhu, WJ. (2002). Bleu: A method for automatic evaluation of machine translation. In Proceedings of the 40th annual meeting on association for computational linguistics, association for computational linguistics, Stroudsburg, PA, USA, ACL (pp. 311-318). doi:10.3115/1073083.1073135.

Papineni, K., Roukos, S., Ward, T., & Zhu, WJ. (2002). BLEU:一种自动评估机器翻译的方法。发表于第40届计算语言学协会年会论文集，计算语言学协会，宾夕法尼亚州斯特劳兹堡，ACL(第311-318页)。doi:10.3115/1073083.1073135。

Parikh, D., & Grauman, K. (2011a). Interactively building a discriminative vocabulary of nameable attributes. In ${CVPR}$ .

Parikh, D., & Grauman, K. (2011a). 交互式构建可命名属性的判别词汇表。In ${CVPR}$ .

Parikh, D., & Grauman, K. (2011b) Relative attributes. In CCV.

Parikh, D., & Grauman, K. (2011b) 相对属性。In CCV.

Patterson, G., & Hays, J. (2012). Sun attribute database: Discovering, annotating, and recognizing scene attributes. In Proceeding of the 25th conference on computer vision and pattern recognition (CVPR).

Patterson, G., & Hays, J. (2012). SUN属性数据库:发现、标注与识别场景属性。发表于第25届计算机视觉与模式识别会议(CVPR)论文集。

Rabinovich, A., Vedaldi, A., Galleguillos, C., Wiewiora, E., & Belongie, S. (2007). Objects in context. In Computer vision, 2007. ICCV 2007. IEEE 11th international conference on (pp. 1-8). doi:10.1109/ICCV. 2007.4408986.

Rabinovich, A., Vedaldi, A., Galleguillos, C., Wiewiora, E., & Belongie, S. (2007). 上下文中的物体。发表于2007年计算机视觉国际会议(ICCV 2007)，IEEE第11届国际会议论文集(第1-8页)。doi:10.1109/ICCV.2007.4408986。

Rohrbach, M., Stark, M., & Schiele, B. (2011). Evaluating knowledge transfer and zero-shot learning in a large-scale setting. In Computer vision and pattern recognition (CVPR), 2011 IEEE conference on IEEE (pp. 1641-1648).

Rohrbach, M., Stark, M., & Schiele, B. (2011). 在大规模环境下评估知识迁移与零样本学习。发表于2011年IEEE计算机视觉与模式识别会议(CVPR)，IEEE会议论文集(第1641-1648页)。

Russakovsky, O., & Fei-Fei, L. (2010). Attribute learning in largescale datasets. In ECCV 2010 workshop on parts and attributes.

Russakovsky, O., & Fei-Fei, L. (2010). 大规模数据集中的属性学习。发表于ECCV 2010零件与属性研讨会。

Russell, B. C., Torralba, A., Murphy, K. P., & Freeman, W. T. (2008). Labelme: A database and web-based tool for image annotation. International Journal of Computer Vision, 77(1), 157-173.

Russell, B. C., Torralba, A., Murphy, K. P., & Freeman, W. T. (2008). LabelMe:一个用于图像标注的数据库及基于网络的工具。国际计算机视觉杂志，77(1)，157-173。

Sanchez, J., Perronnin, F., Mensink, T., & Verbeek, J. (2013). Image classification with the fisher vector: Theory and practice. International Journal of Computer Vision, 105(3), 222-245.

Sanchez, J., Perronnin, F., Mensink, T., & Verbeek, J. (2013). 使用Fisher向量进行图像分类:理论与实践。国际计算机视觉杂志，105(3)，222-245。

Scheirer, WJ., Kumar, N., Belhumeur, PN., & Boult, TE. (2012). Multi-attribute spaces: Calibration for attribute fusion and similarity search. In The IEEE conference on computer vision and pattern recognition (CVPR).

Scheirer, WJ., Kumar, N., Belhumeur, PN., & Boult, TE. (2012). 多属性空间:属性融合与相似性搜索的校准。发表于IEEE计算机视觉与模式识别会议(CVPR)。

Shotton, J., Winn, J., Rother, C., & Criminisi, A. (2006). Textonboost: Joint appearance, shape and context modeling for multi-class object recognition and segmentation. In Proceedings of the 9th European conference on computer vision. Berlin: Springer, ECCV'06 (pp. 1- 15). doi:10.1007/11744023_1.

Shotton, J., Winn, J., Rother, C., & Criminisi, A. (2006). TextonBoost:联合外观、形状与上下文建模用于多类别物体识别与分割。发表于第9届欧洲计算机视觉会议(ECCV'06)，柏林:Springer，第1-15页。doi:10.1007/11744023_1。

Shotton, J., Johnson, M., & Cipolla, R. (2008). Semantic texton forests for image categorization and segmentation. In Computer vision and pattern recognition, 2008. CVPR 2008. IEEE Conference on (pp. 1-8). doi:10.1109/CVPR.2008.4587503.

Shotton, J., Johnson, M., & Cipolla, R. (2008). 语义Texton森林用于图像分类与分割。发表于2008年计算机视觉与模式识别会议(CVPR 2008)，IEEE会议论文集(第1-8页)。doi:10.1109/CVPR.2008.4587503。

Siddiquie, B., Feris, RS., & Davis, LS. (2011). Image ranking and retrieval based on multi-attribute queries. In The IEEE conference on computer vision and pattern recognition (CVPR).

Siddiquie, B., Feris, RS., & Davis, LS. (2011). 基于多属性查询的图像排序与检索。发表于IEEE计算机视觉与模式识别会议(CVPR)。

Socher, R., Lin, CC., Ng, AY., & Manning, CD. (2011). Parsing natural scenes and natural language with recursive neural networks. In Proceedings of the 26th international conference on machine learning (ICML) Vol. 2, p. 7).

Socher, R., Lin, CC., Ng, AY., & Manning, CD. (2011). 使用递归神经网络解析自然场景与自然语言。发表于第26届国际机器学习会议(ICML)论文集，第2卷，第7页。

Sorokin, A., & Forsyth, D. (2008). Utility data annotation with amazon mechanical turk. In First IEEE workshop on internet vision at CVPR 08.

Sorokin, A., & Forsyth, D. (2008). 利用亚马逊Mechanical Turk进行实用数据标注。发表于CVPR 08首届IEEE互联网视觉研讨会。

Su, Y., Allan, M., & Jurie, F. (2010). Improving object classification using semantic attributes. In ${BMVC}$ .

Su, Y., Allan, M., & Jurie, F. (2010). 利用语义属性提升物体分类性能。In ${BMVC}$ .

Tighe, J., & Lazebnik, S. (2013). Superparsing. International Journal of Computer Vision, 101, 329-349. doi:10.1007/s11263-012-0574-z.

Tighe, J., & Lazebnik, S. (2013). 超级解析(Superparsing)。国际计算机视觉杂志，101，329-349。doi:10.1007/s11263-012-0574-z。

Torralba, A., Fergus, R., & Freeman, W. T. (2008a). 80 Million tiny images: A large data set for nonparametric object and scene recognition. IEEE Transactions on Pattern Analysis and Machine Intelligence, 30(11), 1958-1970.

Torralba, A., Fergus, R., & Freeman, W. T. (2008a). 8000万微小图像:用于非参数对象和场景识别的大型数据集。IEEE模式分析与机器智能汇刊，30(11)，1958-1970。

Torralba, A., Fergus, R., & Freeman, W. T. (2008b). 80 Million tiny images: A large dataset for non-parametric object and scene recognition. IEEE Transactions on Pattern Analysis and Machine Intelligence, 30(8), 1371-1384.

Torralba, A., Fergus, R., & Freeman, W. T. (2008b). 8000万微小图像:用于非参数对象和场景识别的大型数据集。IEEE模式分析与机器智能汇刊，30(8)，1371-1384。

Xiao, J., Hays, J., Ehinger, K., Oliva, A., & Torralba, A. (2010). SUN database: Large-scale scene recognition from abbey to zoo. In CVPR.

Xiao, J., Hays, J., Ehinger, K., Oliva, A., & Torralba, A. (2010). SUN数据库:从修道院到动物园的大规模场景识别。发表于CVPR会议。

Yao, B., Jiang, X., Khosla, A., Lin, AL., Guibas, L., & Fei-Fei, L. (2011). Human action recognition by learning bases of action attributes and parts. In ${ICCV}$ .

Yao, B., Jiang, X., Khosla, A., Lin, AL., Guibas, L., & Fei-Fei, L. (2011). 通过学习动作属性和部件的基来识别人类动作。发表于${ICCV}$。