# Context-Conditional Adaptation for Recognizing Unseen Classes in Unseen Domains

# 用于识别未知领域中未知类别的上下文条件适应

Puneet Mangla ${}^{*1}$ , Shivam Chandhok ${}^{*2}$ ,

Puneet Mangla ${}^{*1}$ , Shivam Chandhok ${}^{*2}$ ,

Vineeth N Balasubramanian ${}^{1}$ and Fahad Shahbaz Khan ${}^{2}$

Vineeth N Balasubramanian ${}^{1}$ 和 Fahad Shahbaz Khan ${}^{2}$

${}^{1}$ Department of Computer Science, Indian Institute of Technology, Hyderabad

${}^{1}$ 印度理工学院海得拉巴计算机科学系

${}^{2}$ Mohamed bin Zayed University of Artificial Intelligence

${}^{2}$ 穆罕默德·本·扎耶德人工智能大学

pmangla261@gmail.com, shivam.chandhok@mbzuai.ac.ae, vineethnb@cse.iith.ac.in.

pmangla261@gmail.com, shivam.chandhok@mbzuai.ac.ae, vineethnb@cse.iith.ac.in.

fahad.khan@mbzuai.ac.ae

## Abstract

## 摘要

Recent progress towards designing models that can generalize to unseen domains (i.e domain generalization) or unseen classes (i.e zero-shot learning) has embarked interest towards building models that can tackle both domain-shift and semantic shift simultaneously (i.e zero-shot domain generalization). For models to generalize to unseen classes in unseen domains, it is crucial to learn feature representation that preserves class-level (domain-invariant) as well as domain-specific information. Motivated from the success of generative zero-shot approaches, we propose a feature generative framework integrated with a COntext COnditional Adaptive (COCOA) Batch-Normalization to seamlessly integrate class-level semantic and domain-specific information. The generated visual features better capture the underlying data distribution enabling us to generalize to unseen classes and domains at test-time. We thoroughly evaluate and analyse our approach on established large-scale benchmark - DomainNet and demonstrate promising performance over baselines and state-of-art methods.

近年来，设计能够泛化到未知领域(即领域泛化)或未知类别(即零样本学习)的模型取得了进展，激发了构建能够同时应对领域偏移和语义偏移的模型(即零样本领域泛化)的兴趣。为了使模型能够泛化到未知领域中的未知类别，关键在于学习既保留类别级别(领域不变)信息又包含领域特定信息的特征表示。受生成式零样本方法成功的启发，我们提出了一个特征生成框架，集成了上下文条件自适应(COntext COnditional Adaptive，COCOA)批归一化，以无缝融合类别级语义和领域特定信息。生成的视觉特征更好地捕捉了潜在数据分布，使我们能够在测试时泛化到未知类别和领域。我们在权威大规模基准数据集DomainNet上对该方法进行了全面评估和分析，展示了相较基线和最先进方法的优异性能。

## 1 Introduction

## 1 引言

The dependence of deep learning models on large amounts of data and supervision creates a bottleneck and hinders their utilization in practical scenarios. There is thus a need to equip deep learning models with the ability to generalize to unseen domains or classes at test-time using data from other related domains or classes (where data is abundant).

深度学习模型对大量数据和监督的依赖形成瓶颈，限制了其在实际场景中的应用。因此，亟需赋予深度学习模型在测试时利用其他相关领域或类别(数据丰富)数据泛化到未知领域或类别的能力。

There has been great interest and corresponding efforts in recent years towards tackling domain shift (a.k.a Domain Generalization) [Yang and Gao, 2013; Muandet et al., 2013; Xu et al., 2014; Li et al., 2017; Ghifary et al., 2015; Li et al., 2018b; Carlucci et al., 2019; Li et al., 2018a; Li et al., 2019a] and semantic shift (a.k.a Zero-Shot Learning) [Reed et al., 2016; Frome et al., 2013; Wan et al., 2019; Kodirov et al., 2015; Zhang et al., 2017] separately. However, applications in the real world do not guarantee that only one of them will occur - there is a need to make systems robust to the domain and semantic shifts simultaneously. The problem of tackling domain shift and semantic shift together, as considered herein, can be grouped as the Zero-Shot Domain Generalization (which we call ZSLDG) problem setting [Mancini et al., 2020; Maniyar et al., 2020]. In ZSLDG, the model has access to a set of seen classes from multiple source domains and has to generalize to unseen classes in unseen target domains at test time. Note that this problem of recognizing unseen classes in unseen domains (ZSLDG) is much more challenging than tackling zero-shot learning (ZSL) or domain generalization (DG) separately [Mancini et al., 2020] and growingly relevant as deep learning models get reused across domains. A recent approach, CuMix [Mancini et al., 2020], proposed a methodology that mixes up multiple source domains and categories available during training to simulate semantic and domain shift at test time. This work also established a benchmark dataset, DomainNet, for the ZSLDG problem setting with an evaluation protocol, which we follow in this work for a fair comparison.

近年来，针对领域偏移(又称领域泛化)[Yang and Gao, 2013; Muandet et al., 2013; Xu et al., 2014; Li et al., 2017; Ghifary et al., 2015; Li et al., 2018b; Carlucci et al., 2019; Li et al., 2018a; Li et al., 2019a]和语义偏移(又称零样本学习)[Reed et al., 2016; Frome et al., 2013; Wan et al., 2019; Kodirov et al., 2015; Zhang et al., 2017]分别进行了大量研究和努力。然而，现实应用中并不保证只会发生其中之一——系统需要同时对领域和语义偏移具备鲁棒性。本文所考虑的同时应对领域偏移和语义偏移的问题，可归类为零样本领域泛化(Zero-Shot Domain Generalization，简称ZSLDG)问题设置[Mancini et al., 2020; Maniyar et al., 2020]。在ZSLDG中，模型可访问来自多个源领域的一组已见类别，需在测试时泛化到未知目标领域中的未知类别。需注意，识别未知领域中未知类别(ZSLDG)的问题远比单独处理零样本学习(ZSL)或领域泛化(DG)更具挑战性[Mancini et al., 2020]，且随着深度学习模型跨领域复用，其重要性日益凸显。近期方法CuMix[Mancini et al., 2020]提出了一种在训练时混合多个源领域和类别以模拟测试时语义和领域偏移的方法。该工作还建立了ZSLDG问题设置的基准数据集DomainNet及评估协议，我们在本文中遵循该协议以实现公平比较。

Feature generation methods [Xian et al., 2018; Ni et al., 2019; Schonfeld et al., 2019; Mishra et al., 2018; Felix et al., 2018; Huang et al., 2019; Keshari et al., 2020; Narayan et al., 2020; Chandhok and Balasubramanian, 2021; Shen et al., 2020] have recently shown significant promise in traditional zero-shot or few-shot learning settings and are among the state-of-the-art today for such problems. However, these approaches assume that the source domains (during training) and the target domain (during testing) are the same and thus aim to generate features that only address semantic shift. They rely on the assumption that the visual-semantic relationship learned during training will generalize to unseen classes at test-time. However, there is no guarantee that this holds for images in novel domains unseen during training [Mancini et al., 2020]. Thus, when used for addressing ZSLDG, the aforementioned methods lead to suboptimal performance.

特征生成方法[Xian 等, 2018; Ni 等, 2019; Schonfeld 等, 2019; Mishra 等, 2018; Felix 等, 2018; Huang 等, 2019; Keshari 等, 2020; Narayan 等, 2020; Chandhok 和 Balasubramanian, 2021; Shen 等, 2020] 最近在传统的零样本学习(zero-shot learning, ZSL)或少样本学习(few-shot learning)场景中表现出显著潜力，且目前是此类问题的最先进方法之一。然而，这些方法假设训练时的源域和测试时的目标域相同，因此仅旨在生成解决语义偏移(semantic shift)的特征。它们依赖于训练期间学习到的视觉-语义关系能够推广到测试时未见过的类别的假设。然而，对于训练时未见过的新域中的图像，这一假设并无保证[Mancini 等, 2020]。因此，当用于解决零样本学习领域泛化(ZSLDG)问题时，上述方法表现不佳。

To tackle domain shift at test-time, it is important to generate feature representations that encode both class level (domain-invariant) and domain-specific information [Chat-topadhyay et al., 2020; Seo et al., 2020]. Thus we conjecture that generating features that are consistent with only class-level semantics is not sufficient for addressing ZSLDG. However, encoding domain-specific information along with class information in generated features is not straightforward [Mancini et al., 2020]. Drawing inspiration from these observations, we propose a unified generative framework that uses COntext COnditional Adaptive (COCOA) Batch-Normalization to seamlessly integrate semantic and domain information to generate visual features of unseen classes in unseen domains. Depending on the setting, "context" can qualify as domain (for DG), semantics (for ZSL), or both (in case of ZSLDG). Since this work primarily deals with the ZSLDG setting, 'context' in this work refers to both domain and semantic information. We perform experiments and analysis on standard ZSLDG benchmark: DomainNet and demonstrate that our proposed methodology provides state-of-the-art performance for the ZSLDG setting and is able to encode both semantic and domain-specific information to generate features, thus capturing the given context better. To the best of our knowledge, this is the first generative approach to address the ZSLDG problem setting.

为了解决测试时的域偏移问题，生成同时编码类别级别(域不变)和域特定信息的特征表示非常重要[Chattopadhyay 等, 2020; Seo 等, 2020]。因此，我们推测仅生成与类别级语义一致的特征不足以解决ZSLDG问题。然而，在生成的特征中同时编码域特定信息和类别信息并非易事[Mancini 等, 2020]。基于这些观察，我们提出了一个统一的生成框架，采用上下文条件自适应(COntext COnditional Adaptive, COCOA)批归一化(Batch-Normalization)方法，能够无缝整合语义和域信息，以生成未见类别在未见域中的视觉特征。根据具体设置，“上下文”可以指域(用于域泛化，DG)、语义(用于零样本学习，ZSL)或两者兼具(ZSLDG情形)。鉴于本工作主要针对ZSLDG设置，文中“上下文”指代域和语义信息。我们在标准ZSLDG基准DomainNet上进行了实验和分析，结果表明所提方法在ZSLDG设置中实现了最先进的性能，能够编码语义和域特定信息以生成特征，从而更好地捕捉给定上下文。据我们所知，这是首个针对ZSLDG问题提出的生成式方法。

---

*Equal Contribution

*同等贡献

---

## 2 COCOA: Proposed Methodology

## 2 COCOA:提出的方法

Our goal is to train a classifier $\mathcal{C}$ which can tackle domain-shift as well as semantic shift simultaneously and recognize unseen classes in unseen domains at test-time. Let ${S}^{\bar{T}r} =$ $\left\{  {\left( {\mathbf{x}, y,{\mathbf{a}}_{y}^{s}, d}\right)  \mid  \mathbf{x} \in  \mathcal{X}, y \in  {\mathcal{Y}}^{s},{\mathbf{a}}_{y}^{s} \in  \mathcal{A}, d \in  {\mathcal{D}}^{s}}\right\}$ denote the training set, where $\mathbf{x}$ is a seen class image in the visual space(X)with corresponding label $y$ from a set of seen class labels ${\mathcal{Y}}^{s}$ . ${\mathbf{a}}_{y}^{s}$ denotes the class-specific semantic representation for seen classes. We assume access to domain labels $d$ for a set of source domains ${\mathcal{D}}^{s}$ with cardinality $K$ . The test-set is denoted by ${S}^{Ts} = \left\{  {\left( {\mathbf{x}, y,{\mathbf{a}}_{y}^{u}, d}\right)  \mid  \mathbf{x} \in  \mathcal{X}, y \in  {\mathcal{Y}}^{u},{\mathbf{a}}_{y}^{u} \in  }\right.$ $\left. {\mathcal{A}, d \in  {\mathcal{D}}^{u}}\right\}$ where ${\mathcal{Y}}^{u}$ is the set of labels for unseen classes and ${\mathcal{D}}^{u}$ represents the set of unseen target domains. Note that standard zero-shot setting (tackles only semantic-shift) complies with the condition ${\mathcal{Y}}^{s} \cap  {\mathcal{Y}}^{u} \equiv  \varnothing$ and ${\mathcal{D}}^{s} \equiv  {\mathcal{D}}^{u}$ . The standard DG setting (tackles only domain-shift), on the other hand, works under the condition ${\mathcal{Y}}^{s} \equiv  {\mathcal{Y}}^{u}$ and ${\mathcal{D}}^{s} \cap  {\mathcal{D}}^{u} \equiv  \varnothing$ . In this work, our goal is to address the challenging ZSLDG setting where ${\mathcal{Y}}^{s} \cap  {\mathcal{Y}}^{u} \equiv  \varnothing$ and ${\mathcal{D}}^{s} \cap  {\mathcal{D}}^{u} \equiv  \varnothing$ .

我们的目标是训练一个分类器$\mathcal{C}$，能够同时应对领域偏移(domain-shift)和语义偏移(semantic shift)，并在测试时识别未见过的类别和未见过的领域。设${S}^{\bar{T}r} =$ $\left\{  {\left( {\mathbf{x}, y,{\mathbf{a}}_{y}^{s}, d}\right)  \mid  \mathbf{x} \in  \mathcal{X}, y \in  {\mathcal{Y}}^{s},{\mathbf{a}}_{y}^{s} \in  \mathcal{A}, d \in  {\mathcal{D}}^{s}}\right\}$为训练集，其中$\mathbf{x}$是视觉空间(X)中一个已见类别的图像，具有来自已见类别标签集合${\mathcal{Y}}^{s}$的对应标签$y$。${\mathbf{a}}_{y}^{s}$表示已见类别的类别特定语义表示。我们假设可以访问一组源领域${\mathcal{D}}^{s}$的领域标签$d$，其基数为$K$。测试集记为${S}^{Ts} = \left\{  {\left( {\mathbf{x}, y,{\mathbf{a}}_{y}^{u}, d}\right)  \mid  \mathbf{x} \in  \mathcal{X}, y \in  {\mathcal{Y}}^{u},{\mathbf{a}}_{y}^{u} \in  }\right.$ $\left. {\mathcal{A}, d \in  {\mathcal{D}}^{u}}\right\}$，其中${\mathcal{Y}}^{u}$是未见类别的标签集合，${\mathcal{D}}^{u}$表示未见目标领域集合。注意，标准零样本学习(Zero-Shot Learning，ZSL)设置(仅处理语义偏移)满足条件${\mathcal{Y}}^{s} \cap  {\mathcal{Y}}^{u} \equiv  \varnothing$和${\mathcal{D}}^{s} \equiv  {\mathcal{D}}^{u}$。而标准领域泛化(Domain Generalization，DG)设置(仅处理领域偏移)则在条件${\mathcal{Y}}^{s} \equiv  {\mathcal{Y}}^{u}$和${\mathcal{D}}^{s} \cap  {\mathcal{D}}^{u} \equiv  \varnothing$下工作。在本工作中，我们的目标是解决具有挑战性的ZSLDG设置，即满足条件${\mathcal{Y}}^{s} \cap  {\mathcal{Y}}^{u} \equiv  \varnothing$和${\mathcal{D}}^{s} \cap  {\mathcal{D}}^{u} \equiv  \varnothing$。

Our overall framework to address ZSLDG is summarized in Fig 1. We employ a three-stage pipeline, which we describe below.

我们解决ZSLDG问题的整体框架总结如图1所示。我们采用了一个三阶段流程，具体描述如下。

### 2.1 Generalizable Feature Extraction

### 2.1 可泛化特征提取

We extract visual features $\mathbf{f}$ that encode discriminative class-level cues (domain-invariant) as well as domain-specific information by training a visual encoder $f\left( \text{.}\right) ,{whichi}\;{isthen}$ used to train a semantic projector $p\left( \text{.}\right) .{Boththesemodules}$ are trained with images from all source domains available. The visual encoder and the semantic projector are trained to minimize the following loss:

我们提取视觉特征$\mathbf{f}$，该特征编码了判别性的类别级线索(领域不变)以及领域特定信息，通过训练视觉编码器$f\left( \text{.}\right) ,{whichi}\;{isthen}$，用于训练语义投影器$p\left( \text{.}\right) .{Boththesemodules}$，这些均使用所有可用源领域的图像进行训练。视觉编码器和语义投影器的训练目标是最小化以下损失:

$$
{\mathcal{L}}_{AGG} = {\mathbb{E}}_{\left( {\mathbf{x}, y}\right)  \sim  {S}^{Tr}}\left\lbrack  {{\mathcal{L}}_{CE}\left( {{\mathbf{a}}^{T}p\left( {f\left( \mathbf{x}\right) }\right) , y}\right) }\right\rbrack   + \mathcal{R}\left( \mathbf{f}\right)  \tag{1}
$$

where ${\mathcal{L}}_{CE}$ is standard cross-entropy loss and a $=$ $\left\lbrack  {{\mathbf{a}}_{1}^{s},\ldots ,{\mathbf{a}}_{\left| {\mathcal{Y}}^{s}\right| }^{s}}\right\rbrack  .\mathcal{R}\left( \mathbf{f}\right)$ denotes the regularization loss term. which is used to further improve the visual features and enhance their generalizability by regulating the amount of class-level semantic and domain-specific information in the features $\mathbf{f}$ . The regularizer block primarily uses rotation prediction (viz. providing a rotated image as input, and predicting rotation angle).

其中${\mathcal{L}}_{CE}$是标准的交叉熵损失，$=$ $\left\lbrack  {{\mathbf{a}}_{1}^{s},\ldots ,{\mathbf{a}}_{\left| {\mathcal{Y}}^{s}\right| }^{s}}\right\rbrack  .\mathcal{R}\left( \mathbf{f}\right)$表示正则化损失项，用于通过调节特征$\mathbf{f}$中类别级语义信息和领域特定信息的量，进一步提升视觉特征的质量和泛化能力。正则化模块主要采用旋转预测(即输入旋转后的图像，预测旋转角度)。

### 2.2 Generative Module

### 2.2 生成模块

We learn a generative model which comprises of a generator $G : \mathcal{Z} \times  \mathcal{A} \times  \mathcal{D} \rightarrow  \mathcal{F}$ and a projection discriminator [Miyato and Koyama, 2018] (which uses a projection layer to incorporate conditional information into the discriminator) $D : \mathcal{F} \times  \mathcal{A} \times  \mathcal{D} \rightarrow  \mathbb{R}$ as shown in Fig 1. We represent this discriminator as $D = {D}_{l} \circ  {D}_{f}$ ( $\circ$ denotes composition) where ${D}_{f}$ is discriminator’s last feature layer and ${D}_{l}$ is the final linear layer. Both the generator and the projection discriminator are conditioned through a Context Conditional Adaptive (COCOA) Batch-Normalization module, which provides class-specific and domain-specific modulation at various stages during the generation process. Modulating the feature information by such semantic and domain-specific embeddings helps to integrate respective information into the features, thereby enabling better generalization. We use the available (seen) semantic attributes ${\mathbf{a}}_{y}^{s}$ that capture class-level characteristics, for encoding semantic information. However, such a representation that encodes domain information is not present for individual source domains. We hence define learnable (randomly initialized and optimized during training) domain embedding matrices ${\mathcal{E}}_{\text{gen }} = \left\{  {{\mathbf{e}}_{1}^{\text{gen }},{\mathbf{e}}_{2}^{\text{gen }},{\mathbf{e}}_{3}^{\text{gen }}\ldots ,{\mathbf{e}}_{K}^{\text{gen }}}\right\}$ and ${\mathcal{E}}_{\text{disc }} = \left\{  {{\mathbf{e}}_{1}^{\text{disc }},{\mathbf{e}}_{2}^{\text{disc }},{\mathbf{e}}_{3}^{\text{disc }}\ldots {\mathbf{e}}_{K}^{\text{disc }}}\right\}$ for the generator and the discriminator respectively.

我们学习一个生成模型，该模型包括一个生成器$G : \mathcal{Z} \times  \mathcal{A} \times  \mathcal{D} \rightarrow  \mathcal{F}$和一个投影判别器[Miyato and Koyama, 2018](该判别器使用投影层将条件信息融入判别器中)$D : \mathcal{F} \times  \mathcal{A} \times  \mathcal{D} \rightarrow  \mathbb{R}$，如图1所示。我们将该判别器表示为$D = {D}_{l} \circ  {D}_{f}$($\circ$表示组合)，其中${D}_{f}$是判别器的最后特征层，${D}_{l}$是最终的线性层。生成器和投影判别器均通过上下文条件自适应(Context Conditional Adaptive，COCOA)批归一化模块进行条件控制，该模块在生成过程的各个阶段提供类别特定和域特定的调制。通过这种语义和域特定嵌入对特征信息进行调制，有助于将相应信息整合到特征中，从而实现更好的泛化能力。我们使用可用的(已见)语义属性${\mathbf{a}}_{y}^{s}$来编码语义信息，这些属性捕捉了类别级特征。然而，对于单个源域，并不存在编码域信息的此类表示。因此，我们为生成器和判别器分别定义了可学习的(随机初始化并在训练中优化)域嵌入矩阵${\mathcal{E}}_{\text{gen }} = \left\{  {{\mathbf{e}}_{1}^{\text{gen }},{\mathbf{e}}_{2}^{\text{gen }},{\mathbf{e}}_{3}^{\text{gen }}\ldots ,{\mathbf{e}}_{K}^{\text{gen }}}\right\}$和${\mathcal{E}}_{\text{disc }} = \left\{  {{\mathbf{e}}_{1}^{\text{disc }},{\mathbf{e}}_{2}^{\text{disc }},{\mathbf{e}}_{3}^{\text{disc }}\ldots {\mathbf{e}}_{K}^{\text{disc }}}\right\}$。

The generator $G$ takes in noise $\mathbf{z} \in  \mathcal{Z}$ and a context vector $\mathbf{c}$ , and outputs visual features $\widehat{\mathbf{f}} \in  \mathcal{F}$ . The context vector c, which is the concatenation of class-level semantic attribute ${\mathbf{a}}_{y}^{s}$ and domain-specific embedding ${\mathbf{e}}_{i}^{\text{gen }}$ , is provided as input to a BatchNorm estimator network ${B}_{gen}^{l} : \mathcal{A} \times  \mathcal{D} \rightarrow  {\mathcal{R}}^{2 \times  h}(h$ is the dimension of layer $l$ activation vectors) which outputs batchnorm paramaters, ${\gamma }_{gen}^{l}$ and ${\beta }_{gen}^{l}$ for the $l$ -th layer. Similarly, the discriminator’s feature extractor ${D}_{f}\left( \text{.}\right) {hasasep} -$ arate BatchNorm estimator network ${B}_{\text{disc }}^{l} : \mathcal{D} \rightarrow  {\mathcal{R}}^{2 \times  h}$ to enable domain-specific context modulation of its batchnorm parameters, ${\gamma }_{\text{disc }}^{l},{\beta }_{\text{disc }}^{l}$ as shown in Fig 1.

生成器$G$接收噪声$\mathbf{z} \in  \mathcal{Z}$和上下文向量$\mathbf{c}$，并输出视觉特征$\widehat{\mathbf{f}} \in  \mathcal{F}$。上下文向量c是类别级语义属性${\mathbf{a}}_{y}^{s}$与域特定嵌入${\mathbf{e}}_{i}^{\text{gen }}$的拼接，作为输入提供给批归一化估计网络${B}_{gen}^{l} : \mathcal{A} \times  \mathcal{D} \rightarrow  {\mathcal{R}}^{2 \times  h}(h$($l$是第$l$层激活向量的维度)，该网络输出第$l$层的批归一化参数${\gamma }_{gen}^{l}$和${\beta }_{gen}^{l}$。类似地，判别器的特征提取器${D}_{f}\left( \text{.}\right) {hasasep} -$配备了独立的批归一化估计网络${B}_{\text{disc }}^{l} : \mathcal{D} \rightarrow  {\mathcal{R}}^{2 \times  h}$，以实现其批归一化参数的域特定上下文调制${\gamma }_{\text{disc }}^{l},{\beta }_{\text{disc }}^{l}$，如图1所示。

Formally, let ${\mathbf{f}}_{\text{gen }}^{l}$ and ${\mathbf{f}}_{\text{disc }}^{l}$ denote feature activations belonging to domain $d$ and semantic attribute ${\mathbf{a}}_{y}^{s}$ , at $l$ -th layer of generator $G$ and discriminator $D$ respectively. We modulate ${\mathbf{f}}_{\text{gen }}^{l}$ and ${\mathbf{f}}_{\text{disc }}^{l}$ individually using Context Conditional Adaptive Batch-Normalization as follows:

形式上，设${\mathbf{f}}_{\text{gen }}^{l}$和${\mathbf{f}}_{\text{disc }}^{l}$分别表示生成器$G$和判别器$D$第$l$层中属于域$d$和语义属性${\mathbf{a}}_{y}^{s}$的特征激活。我们使用上下文条件自适应批归一化分别对${\mathbf{f}}_{\text{gen }}^{l}$和${\mathbf{f}}_{\text{disc }}^{l}$进行调制，具体如下:

${\gamma }_{gen}^{l},{\beta }_{gen}^{l} \leftarrow  {B}_{gen}^{l}\left( \mathbf{c}\right) ,{\mathbf{f}}_{gen}^{l + 1} \leftarrow  {\gamma }_{gen}^{l} \cdot  \frac{{\mathbf{f}}_{gen}^{l} - {\mu }_{gen}^{l}}{\sqrt{{\left( {\sigma }_{gen}^{l}\right) }^{2} + \epsilon }} + {\beta }_{gen}^{l}$

where $\mathbf{c} = \left\lbrack  {{\mathbf{a}}_{y}^{s},{\mathbf{e}}_{d}^{gen}}\right\rbrack$

其中 $\mathbf{c} = \left\lbrack  {{\mathbf{a}}_{y}^{s},{\mathbf{e}}_{d}^{gen}}\right\rbrack$

$$
{\gamma }_{disc}^{l},{\beta }_{disc}^{l} \leftarrow  {B}_{disc}^{l}\left( {\mathbf{e}}_{d}^{disc}\right) ,{\mathbf{f}}_{disc}^{l + 1} \leftarrow  {\gamma }_{disc}^{l} \cdot  \frac{{\mathbf{f}}_{disc}^{l} - {\mu }_{disc}^{l}}{\sqrt{{\left( {\sigma }_{disc}^{l}\right) }^{2} + \epsilon }} + {\beta }_{disc}^{l}
$$

(2)

Here, $\left( {{\mu }_{\text{gen }}^{l},{\left( {\sigma }_{\text{gen }}^{l}\right) }^{2}}\right)$ and $\left( {{\mu }_{\text{disc }}^{l},{\left( {\sigma }_{\text{disc }}^{l}\right) }^{2}}\right)$ are the mean and variance of activations of the mini-batch (also used to update running statistics) containing ${\mathbf{f}}_{\text{gen }}^{l}$ and ${\mathbf{f}}_{\text{disc }}^{l}$ respectively. $\mathbf{c}$ denotes the context vector composed of semantic and domain embeddings and $\left\lbrack  {\cdot , \cdot  }\right\rbrack$ denotes the concatenation operation.

这里，$\left( {{\mu }_{\text{gen }}^{l},{\left( {\sigma }_{\text{gen }}^{l}\right) }^{2}}\right)$ 和 $\left( {{\mu }_{\text{disc }}^{l},{\left( {\sigma }_{\text{disc }}^{l}\right) }^{2}}\right)$ 分别是包含 ${\mathbf{f}}_{\text{gen }}^{l}$ 和 ${\mathbf{f}}_{\text{disc }}^{l}$ 的小批量激活的均值和方差(也用于更新运行统计数据)。$\mathbf{c}$ 表示由语义和领域嵌入组成的上下文向量，$\left\lbrack  {\cdot , \cdot  }\right\rbrack$ 表示拼接操作。

Finally, the generator and discriminator are trained to optimize the adversarial loss given by:

最后，生成器和判别器被训练以优化由下式给出的对抗损失:

$$
{\mathcal{L}}_{D} = {\mathbb{E}}_{\left( {\mathbf{x},{\mathbf{a}}_{y}^{s}, d}\right)  \sim  {S}^{Tr}}\left\lbrack  {\max \left( {0,1 - D\left( {f\left( \mathbf{x}\right) ,{\mathbf{a}}_{y}^{s},{\mathbf{e}}_{d}^{\text{disc }}}\right) }\right) }\right\rbrack   \tag{3}
$$

$$
+ {\mathbb{E}}_{y \sim  {\mathcal{Y}}^{s}, d \sim  {\mathcal{D}}^{s},\mathbf{z} \sim  \mathcal{Z}}\left\lbrack  {\max \left( {0,1 + D\left( {\widehat{\mathbf{f}},{\mathbf{a}}_{y}^{s},{\mathbf{e}}_{d}^{\text{disc }}}\right) }\right) }\right\rbrack
$$

$$
{\mathcal{L}}_{G} = {\mathbb{E}}_{y \sim  {\mathcal{Y}}^{s}, d \sim  {\mathcal{D}}^{s},\mathbf{z} \sim  \mathcal{Z}}\lbrack  - D\left( {\widehat{\mathbf{f}},{\mathbf{a}}_{y}^{s},{\mathbf{e}}_{d}^{\text{disc }}}\right)  \tag{4}
$$

$$
+ {\lambda }_{G} \cdot  {\mathcal{L}}_{CE}\left( {{\mathbf{a}}^{T}p\left( \widehat{\mathbf{f}}\right) , y}\right) \rbrack
$$

![bo_d1c3qt77aajc7389qeug_2_154_152_1491_382_0.jpg](images/bo_d1c3qt77aajc7389qeug_2_154_152_1491_382_0.jpg)

Figure 1: The proposed pipeline consists of three stages: (1) Generalizable Feature Extraction; (2) Generative Module; and (3) Recognition and Inference. The first stage trains a visual backbone $f\left( \text{.}\right)$ to extract visual feature $\mathbf{f}$ that encodes discriminative class-level (domain-invariant) and domain-specific information. The second stage learns a generative model $G$ which uses COntext COnditioned Adaptive (COCOA) batch-normalization layers to fuse and integrate semantic and domain-specific information into the generated features $\widehat{\mathbf{f}}$ . Lastly, the third stage generates visual features for unseen classes across domains and trains a softmax classifier

图1:所提管线包括三个阶段:(1)可泛化特征提取；(2)生成模块；(3)识别与推断。第一阶段训练视觉骨干网络 $f\left( \text{.}\right)$ 以提取编码判别性类别级(领域不变)和领域特定信息的视觉特征 $\mathbf{f}$。第二阶段学习生成模型 $G$，该模型使用上下文条件自适应(COntext COnditioned Adaptive，COCOA)批归一化层将语义和领域特定信息融合并整合到生成特征 $\widehat{\mathbf{f}}$ 中。最后，第三阶段为跨领域的未见类别生成视觉特征，并训练softmax分类器。

where $D\left( {\mathbf{f},\mathbf{a},\mathbf{e}}\right)  = {\mathbf{a}}^{T}{D}_{f}\left( {\mathbf{f},\mathbf{e}}\right)  + {D}_{l}\left( {{D}_{f}\left( {\mathbf{f},\mathbf{e}}\right) }\right)$ is the projection term, $\widehat{\mathbf{f}} = G\left( {\mathbf{z},\mathbf{c}}\right)$ denotes generated feature. The second term, ${\mathcal{L}}_{CE}\left( {{\mathbf{a}}^{T}p\left( \widehat{\mathbf{f}}\right) , y}\right)$ in ${\mathcal{L}}_{G}$ ensures that the generated features have discriminative properties ( ${\lambda }_{G}$ is a hyperparameter). $p\left( \text{.}\right) {isthesemanticprojectorthatwastrainedintheprevious}$ stage.

其中 $D\left( {\mathbf{f},\mathbf{a},\mathbf{e}}\right)  = {\mathbf{a}}^{T}{D}_{f}\left( {\mathbf{f},\mathbf{e}}\right)  + {D}_{l}\left( {{D}_{f}\left( {\mathbf{f},\mathbf{e}}\right) }\right)$ 是投影项，$\widehat{\mathbf{f}} = G\left( {\mathbf{z},\mathbf{c}}\right)$ 表示生成的特征。第二项 ${\mathcal{L}}_{CE}\left( {{\mathbf{a}}^{T}p\left( \widehat{\mathbf{f}}\right) , y}\right)$ 在 ${\mathcal{L}}_{G}$ 中确保生成的特征具有判别性(${\lambda }_{G}$ 是超参数)。$p\left( \text{.}\right) {isthesemanticprojectorthatwastrainedintheprevious}$ 阶段。

### 2.3 Recognition and Inference

### 2.3 识别与推断

We freeze the generator and aim to synthesize visual features for unseen classes across different domains, which are then used to train classifier $\mathcal{C}$ . To this end, we concatenate the domain embeddings ${\mathbf{e}}_{i}^{\text{gen }},\left( {i \in  {\mathcal{D}}^{s}}\right)$ of the source domains from matrix ${\mathcal{E}}_{\text{gen }}$ (learned end-to-end with the generative model) and the semantic attributes/representations of unseen classes ${\mathbf{a}}_{y}^{u}$ to get the context vector $\mathbf{c}$ , which in turn is input to the trained batchnorm predictor network ${B}_{gen}^{l}$ . The output batch-norm parameters $\left( {{\gamma }_{gen}^{l},{\beta }_{gen}^{l}}\right)$ are used in the batchnorm layers of the pre-trained generator to generate features $\widehat{\mathbf{f}}$ . This enables us to generate features that are consistent with unseen class semantics and also encode domain information from individual source domains in the training set. After obtaining batch-norm parameters, the new set of unseen class features are generated as follows:

我们冻结生成器，旨在为跨不同领域的未见类别合成视觉特征，随后用于训练分类器 $\mathcal{C}$。为此，我们将源领域的领域嵌入 ${\mathbf{e}}_{i}^{\text{gen }},\left( {i \in  {\mathcal{D}}^{s}}\right)$(来自矩阵 ${\mathcal{E}}_{\text{gen }}$，与生成模型端到端学习)与未见类别的语义属性/表示 ${\mathbf{a}}_{y}^{u}$ 拼接，得到上下文向量 $\mathbf{c}$，该向量作为输入传入训练好的批归一化预测网络 ${B}_{gen}^{l}$。输出的批归一化参数 $\left( {{\gamma }_{gen}^{l},{\beta }_{gen}^{l}}\right)$ 用于预训练生成器的批归一化层以生成特征 $\widehat{\mathbf{f}}$。这使我们能够生成与未见类别语义一致且编码训练集中各个源领域信息的特征。获得批归一化参数后，新的未见类别特征集按如下方式生成:

$$
{\widehat{\mathbf{f}}}_{n} = G\left( {{\mathbf{z}}_{n},\mathbf{c}}\right)  \tag{5}
$$

$$
\text{where}\mathbf{c} = \left\lbrack  {{\mathbf{a}}_{{y}_{n}}^{u},{\mathbf{e}}_{n}^{gen}}\right\rbrack  ,{\mathbf{z}}_{n} \sim  \mathcal{Z},{y}_{n} \sim  {\mathcal{Y}}^{u},{\mathbf{e}}_{n}^{gen} \sim  {\mathcal{E}}_{\text{gen }}
$$

To improve generalization to new domains at test-time and make the classifier domain-agnostic, we synthesize embed-dings of newer domains by interpolating the learned embed-dings of the source domains via a mix-up operation.

为了在测试时提高对新领域的泛化能力并使分类器领域无关，我们通过混合操作插值源领域的已学嵌入，合成新领域的嵌入。

$$
{\mathcal{E}}_{\text{interp }}^{\text{gen }} = \lambda  \cdot  {\mathbf{e}}_{i}^{\text{gen }} + \left( {1 - \lambda }\right)  \cdot  {\mathbf{e}}_{j}^{\text{gen }}\text{ where }i, j \sim  {\mathcal{D}}^{s},\lambda  \sim  \mathcal{U}\left\lbrack  {0,1}\right\rbrack
$$

(6)where ${\mathbf{e}}_{i}^{\text{gen }}$ and ${\mathbf{e}}_{j}^{\text{gen }}$ refer to the domain embeddings of $i$ -th and $j$ -th source domains. The unseen class features generated using interpolated domain embeddings ${\mathcal{F}}_{\text{int }}^{u} =$ ${\left\{  \left( {\widehat{\mathbf{f}}}_{\text{int }}^{n},{y}_{n}\right) \right\}  }_{n = 1}^{N}$ are generated as follows:

其中${\mathbf{e}}_{i}^{\text{gen }}$和${\mathbf{e}}_{j}^{\text{gen }}$分别指代第$i$个和第$j$个源域的域嵌入。使用插值域嵌入生成的未见类别特征${\mathcal{F}}_{\text{int }}^{u} =$${\left\{  \left( {\widehat{\mathbf{f}}}_{\text{int }}^{n},{y}_{n}\right) \right\}  }_{n = 1}^{N}$生成方式如下:

$$
{\widehat{\mathbf{f}}}_{\text{int }}^{n} = G\left( {{\mathbf{z}}_{n},{\mathbf{c}}_{\text{interp. }}}\right) \text{ where }{\mathbf{c}}_{\text{interp. }} = \left\lbrack  {{\mathbf{a}}_{{y}_{n}}^{u},{\mathbf{e}}_{\text{interp. }}^{\text{gen }}}\right\rbrack  , \tag{7}
$$

$$
{\mathbf{z}}_{n} \sim  \mathcal{Z},{y}_{n} \sim  {\mathcal{Y}}^{u},{\mathbf{e}}_{\text{interp }}^{\text{gen }} \sim  {\mathcal{E}}_{\text{interp }}^{\text{gen }}
$$

<table><tr><td colspan="2">$\mathbf{{Method}}$</td><td colspan="5">Target Domain</td><td rowspan="2">Avg.</td></tr><tr><td>DG</td><td>ZSL</td><td>clipart</td><td>infograph</td><td>painting</td><td>quickdraw</td><td>sketch</td></tr><tr><td rowspan="3">-</td><td>DEVISE</td><td>20.1</td><td>11.7</td><td>17.6</td><td>6.1</td><td>16.7</td><td>14.4</td></tr><tr><td>ALE</td><td>22.7</td><td>12.7</td><td>20.2</td><td>6.8</td><td>18.5</td><td>16.2</td></tr><tr><td>SPNet</td><td>26.0</td><td>16.9</td><td>23.8</td><td>8.2</td><td>21.8</td><td>19.4</td></tr><tr><td rowspan="3">DANN</td><td>DEVISE</td><td>20.5</td><td>10.4</td><td>16.4</td><td>7.1</td><td>15.1</td><td>13.9</td></tr><tr><td>ALE</td><td>21.2</td><td>12.5</td><td>19.7</td><td>7.4</td><td>17.9</td><td>15.7</td></tr><tr><td>SPNet</td><td>25.9</td><td>15.8</td><td>24.1</td><td>8.4</td><td>21.3</td><td>19.1</td></tr><tr><td rowspan="3">EpiFCR</td><td>DEVISE</td><td>21.6</td><td>13.9</td><td>19.3</td><td>7.3</td><td>17.2</td><td>15.9</td></tr><tr><td>ALE</td><td>23.2</td><td>14.1</td><td>21.4</td><td>7.8</td><td>20.9</td><td>17.5</td></tr><tr><td>SPNet</td><td>26.4</td><td>16.7</td><td>24.6</td><td>9.2</td><td>23.2</td><td>20.0</td></tr><tr><td colspan="2">Mixup-img-only</td><td>25.2</td><td>16.3</td><td>24.4</td><td>8.7</td><td>21.7</td><td>19.2</td></tr><tr><td colspan="2">Mixup-two-level</td><td>26.6</td><td>17</td><td>25.3</td><td>8.8</td><td>21.9</td><td>19.9</td></tr><tr><td colspan="2">CuMix</td><td>27.6</td><td>17.8</td><td>25.5</td><td>9.9</td><td>22.6</td><td>20.7</td></tr><tr><td colspan="2">f-clsWGAN</td><td>20.0</td><td>13.3</td><td>20.5</td><td>6.6</td><td>14.9</td><td>15.1</td></tr><tr><td colspan="2">CuMix + f-clsWGAN</td><td>27.3</td><td>17.9</td><td>26.5</td><td>11.2</td><td>24.8</td><td>21.5</td></tr><tr><td colspan="2">ROT + f-clsWGAN</td><td>27.5</td><td>17.4</td><td>26.4</td><td>11.4</td><td>24.6</td><td>21.4</td></tr><tr><td colspan="2">${\mathrm{{COCOA}}}_{AGG}$</td><td>27.6</td><td>17.1</td><td>25.7</td><td>11.8</td><td>23.7</td><td>21.2</td></tr><tr><td colspan="2">${COCOA}_{ROT}$</td><td>28.9</td><td>18.2</td><td>27.1</td><td>13.1</td><td>25.7</td><td>22.6</td></tr></table>

<table><tbody><tr><td colspan="2">$\mathbf{{Method}}$</td><td colspan="5">目标域</td><td rowspan="2">平均</td></tr><tr><td>域泛化(DG)</td><td>零样本学习(ZSL)</td><td>剪贴画</td><td>信息图</td><td>绘画</td><td>快速绘图</td><td>素描</td></tr><tr><td rowspan="3">-</td><td>DEVISE</td><td>20.1</td><td>11.7</td><td>17.6</td><td>6.1</td><td>16.7</td><td>14.4</td></tr><tr><td>ALE</td><td>22.7</td><td>12.7</td><td>20.2</td><td>6.8</td><td>18.5</td><td>16.2</td></tr><tr><td>SPNet</td><td>26.0</td><td>16.9</td><td>23.8</td><td>8.2</td><td>21.8</td><td>19.4</td></tr><tr><td rowspan="3">DANN</td><td>DEVISE</td><td>20.5</td><td>10.4</td><td>16.4</td><td>7.1</td><td>15.1</td><td>13.9</td></tr><tr><td>ALE</td><td>21.2</td><td>12.5</td><td>19.7</td><td>7.4</td><td>17.9</td><td>15.7</td></tr><tr><td>SPNet</td><td>25.9</td><td>15.8</td><td>24.1</td><td>8.4</td><td>21.3</td><td>19.1</td></tr><tr><td rowspan="3">EpiFCR</td><td>DEVISE</td><td>21.6</td><td>13.9</td><td>19.3</td><td>7.3</td><td>17.2</td><td>15.9</td></tr><tr><td>ALE</td><td>23.2</td><td>14.1</td><td>21.4</td><td>7.8</td><td>20.9</td><td>17.5</td></tr><tr><td>SPNet</td><td>26.4</td><td>16.7</td><td>24.6</td><td>9.2</td><td>23.2</td><td>20.0</td></tr><tr><td colspan="2">仅图像混合(Mixup-img-only)</td><td>25.2</td><td>16.3</td><td>24.4</td><td>8.7</td><td>21.7</td><td>19.2</td></tr><tr><td colspan="2">两级混合(Mixup-two-level)</td><td>26.6</td><td>17</td><td>25.3</td><td>8.8</td><td>21.9</td><td>19.9</td></tr><tr><td colspan="2">CuMix</td><td>27.6</td><td>17.8</td><td>25.5</td><td>9.9</td><td>22.6</td><td>20.7</td></tr><tr><td colspan="2">f-clsWGAN</td><td>20.0</td><td>13.3</td><td>20.5</td><td>6.6</td><td>14.9</td><td>15.1</td></tr><tr><td colspan="2">CuMix + f-clsWGAN</td><td>27.3</td><td>17.9</td><td>26.5</td><td>11.2</td><td>24.8</td><td>21.5</td></tr><tr><td colspan="2">ROT + f-clsWGAN</td><td>27.5</td><td>17.4</td><td>26.4</td><td>11.4</td><td>24.6</td><td>21.4</td></tr><tr><td colspan="2">${\mathrm{{COCOA}}}_{AGG}$</td><td>27.6</td><td>17.1</td><td>25.7</td><td>11.8</td><td>23.7</td><td>21.2</td></tr><tr><td colspan="2">${COCOA}_{ROT}$</td><td>28.9</td><td>18.2</td><td>27.1</td><td>13.1</td><td>25.7</td><td>22.6</td></tr></tbody></table>

Table 1: Performance comparison with established baselines and state-of-art methods for ZSLDG problem setting on benchmark Do-mainNet dataset. For fair comparison, all reported results follow the backbones, protocol and splits as established in CuMix. Best results are highlighted in bold and second best results are underlined.

表1:在基准DomainNet数据集上，针对ZSLDG问题设置，与既有基线和最先进方法的性能比较。为保证公平比较，所有报告结果均遵循CuMix中确立的骨干网络、协议和划分。最佳结果以粗体显示，次优结果加下划线。

Next, we train a MLP softmax classifier, $\mathcal{C}\left( \text{.}\right) {onthegenerated}$ multi-domain unseen class features dataset ${\mathcal{F}}_{\text{int }}^{u}$ by minimizing: ${\mathcal{L}}_{CLS} = {\mathbb{E}}_{\left( {{\widehat{\mathbf{f}}}_{\text{int }}, y}\right)  \sim  {\mathcal{F}}_{\text{int }}^{u}}\left\lbrack  {{\mathcal{L}}_{CE}\left( {\mathcal{C}\left( {\widehat{\mathbf{f}}}_{\text{int }}\right) , y}\right) }\right\rbrack$

接下来，我们训练一个MLP softmax分类器，$\mathcal{C}\left( \text{.}\right) {onthegenerated}$ 多域未见类别特征数据集 ${\mathcal{F}}_{\text{int }}^{u}$ 通过最小化:${\mathcal{L}}_{CLS} = {\mathbb{E}}_{\left( {{\widehat{\mathbf{f}}}_{\text{int }}, y}\right)  \sim  {\mathcal{F}}_{\text{int }}^{u}}\left\lbrack  {{\mathcal{L}}_{CE}\left( {\mathcal{C}\left( {\widehat{\mathbf{f}}}_{\text{int }}\right) , y}\right) }\right\rbrack$

Classifying image at test time. At test-time, given a test image ${\mathbf{x}}_{\text{test }}$ , we first pass it through the visual encoder $f\left( \text{.}\right)$ to get the discriminative feature representation ${\mathbf{f}}_{\text{test }} = f\left( \mathbf{x}\right)$ . Next we pass this feature representation to the classifier to get the final prediction $\widehat{y} = \arg \mathop{\max }\limits_{{y \in  {\mathcal{Y}}^{u}}}\mathcal{C}\left( {\mathbf{f}}_{\text{test }}\right) \left\lbrack  y\right\rbrack$

测试时的图像分类。在测试阶段，给定测试图像${\mathbf{x}}_{\text{test }}$，我们首先通过视觉编码器$f\left( \text{.}\right)$获取判别特征表示${\mathbf{f}}_{\text{test }} = f\left( \mathbf{x}\right)$。接着将该特征表示传入分类器，得到最终预测结果$\widehat{y} = \arg \mathop{\max }\limits_{{y \in  {\mathcal{Y}}^{u}}}\mathcal{C}\left( {\mathbf{f}}_{\text{test }}\right) \left\lbrack  y\right\rbrack$

## 3 Experiments and Results

## 3 实验与结果

DomainNet Dataset: DomainNet is the only established, diverse large-scale, coarse-grained dataset for ZSLDG [Mancini et al., 2020] with images belonging to 345 different categories divided into 6 different domains i.e painting, real, clipart, infograph, quickdraw and sketch. We follow the seen-unseen class training-testing splits and protocol as established in [Mancini et al., 2020] where we train on 5 domains and test on the left-out domain. Also, following [Mancini et al., 2020], we use word2vec representations [Mikolov et al., 2013] as the semantic representations for class labels. For feature extractor $f\left( \text{.}\right) ,$ we choose a Resnet-50 architecture similar to [Mancini et al., 2020].

DomainNet数据集:DomainNet是唯一已建立的、多样化的大规模粗粒度ZSLDG(零样本领域泛化)数据集[Mancini et al., 2020]，包含345个不同类别的图像，分为6个不同领域，即绘画、真实、剪贴画、信息图、快速绘图和素描。我们遵循[Mancini et al., 2020]中确立的见类-未见类训练测试划分和协议，在5个领域上训练，在剩余领域上测试。同样，按照[Mancini et al., 2020]，我们使用word2vec表示[Mikolov et al., 2013]作为类别标签的语义表示。特征提取器$f\left( \text{.}\right) ,$选择与[Mancini et al., 2020]类似的Resnet-50架构。

Baselines. We compare our approach with simpler baselines established in [Mancini et al., 2020] which include ZSL methods like SPNet [Xian et al., 2019], DeViSE [Frome et al., 2013], ALE [Akata et al., 2013] and their coupling with wellknown DG methods (DANN [Ganin et al., 2016], EpiFCR [Li et al., 2019b]). We also compare with SOTA ZSLDG method, CuMix [Mancini et al., 2020] as well as its variants: (1) Mixup-img-only where mixup is done only at image level without curriculum; (2) Mixup-two-level where mixup is applied at both feature and image level without curriculum. We also establish Feature generation baselines which include f-clsWGAN [Xian et al., 2018] (standard ZSL only approach) and its combination with visual backbone trained using CuMix [Mancini et al.,2020] methodology (CuMix + f-clsWGAN) and self-supervised rotation [Gidaris et al., 2018] feature extraction method (ROT + f-clsWGAN).

基线方法。我们将所提方法与[Mancini et al., 2020]中确立的较简单基线进行比较，这些基线包括ZSL方法如SPNet [Xian et al., 2019]、DeViSE [Frome et al., 2013]、ALE [Akata et al., 2013]及其与知名领域泛化方法(DANN [Ganin et al., 2016]、EpiFCR [Li et al., 2019b])的结合。我们还比较了最先进的ZSLDG方法CuMix [Mancini et al., 2020]及其变体:(1)仅图像级Mixup，即仅在图像层面进行混合且无课程学习；(2)双层Mixup，即在特征和图像层面均进行混合且无课程学习。我们还建立了特征生成基线，包括f-clsWGAN [Xian et al., 2018](标准ZSL方法)及其与采用CuMix [Mancini et al., 2020]方法训练的视觉骨干网络结合(CuMix + f-clsWGAN)和自监督旋转特征提取方法[ Gidaris et al., 2018](ROT + f-clsWGAN)。

Results on DomainNet Benchmark. Table 1 shows the performance comparison of our method with the aforementioned baselines. We observe that a simple classification-based feature extraction (using only ${\mathcal{L}}_{\mathcal{{AGG}}}$ ) without any regularization when coupled with our generative module i.e ${COCOA}_{AGG}$ is able to outperform the current state-of-the-art, CuMix [Mancini et al., 2020]. In addition, when we use rotation prediction as a a regularizing auxiliary task [Gidaris et al.,2018] (referred as ${\mathrm{{COCOA}}}_{ROT}$ ), we observe that it achieves the best performance on all domains individually as well as on average (with significant improvement especially on hard domains like quickdraw where there is large domain shift encountered at test-time), thus outperforming [Mancini et al., 2020] by a margin of about 2% average across domains (which corresponds to a ${10}\%$ relative increase). We believe this is because the auxiliary task enables better representation learning. Also, we observe that combining generative ZSL baselines like f-clsWGAN [Xian et al., 2018] with different visual backbones including CuMix results in inferior average performance when compared with our approach.

DomainNet基准测试结果。表1展示了我们方法与上述基线方法的性能对比。我们观察到，简单的基于分类的特征提取(仅使用${\mathcal{L}}_{\mathcal{{AGG}}}$)且不进行任何正则化，结合我们的生成模块即${COCOA}_{AGG}$，能够超越当前最先进的方法CuMix [Mancini et al., 2020]。此外，当我们使用旋转预测作为正则化辅助任务[Gidaris et al.,2018](称为${\mathrm{{COCOA}}}_{ROT}$)时，观察到其在所有单独领域以及平均表现上均达到最佳性能(尤其在测试时遇到大域偏移的困难领域如quickdraw上有显著提升)，从而平均超越[Mancini et al., 2020]约2%的幅度(对应${10}\%$的相对提升)。我们认为这是因为辅助任务促进了更好的表示学习。同时，我们观察到将生成式零样本学习(ZSL)基线如f-clsWGAN [Xian et al., 2018]与包括CuMix在内的不同视觉骨干网络结合时，平均性能不及我们的方法。

Component-wise Ablation Study. Table 2 shows the component-wise performance for our method ${\mathrm{{COCOA}}}_{ROT}$ on DomainNet dataset, following [Mancini et al., 2020].

组件消融研究。表2展示了我们方法${\mathrm{{COCOA}}}_{ROT}$在DomainNet数据集上的组件性能，参照[Mancini et al., 2020]。

- ${S1}$ corresponds to the performance of the feature extractor $f\left( \text{.}\right) {trainedusingusingrotationpredictionasaregularizer}$ (without generative stage 2).

- ${S1}$对应特征提取器$f\left( \text{.}\right) {trainedusingusingrotationpredictionasaregularizer}$的性能(不含生成阶段2)。

- ${S2}$ corresponds to the performance achieved by learning a generator $G$ without using domain embeddings as an input. Specifically, this implies that the BatchNorm estimator networks ${B}_{gen}^{l}$ is given only the class-level semantic attribute as input i.e context vector $\mathbf{c} = {\mathbf{a}}_{y}^{s}$ .

- ${S2}$对应通过学习生成器$G$且不使用域嵌入作为输入时的性能。具体而言，这意味着BatchNorm估计网络${B}_{gen}^{l}$仅以类级语义属性即上下文向量$\mathbf{c} = {\mathbf{a}}_{y}^{s}$作为输入。

- ${S3}$ denotes the use of ${S2}$ , with domain embeddings as an additional input in the context vector provided to ${B}_{gen}^{l}$ i.e $\mathbf{c} = \left\lbrack  {{\mathbf{a}}_{y}^{s},{\mathbf{e}}_{d}^{gen}}\right\rbrack$ , without the use of interpolated domain embeddings ${\mathcal{E}}_{\text{interp }}^{\text{gen }}$ (Eqn 5) and S4 denotes our complete model with the use of interpolated domain embeddings ${\mathcal{E}}_{\text{interp }}^{\text{gen }}$ to generate features. Note that ${S2},{S3}$ and ${S4}$ follow the inference mechanism described in Sec 2.3.

- ${S3}$表示使用${S2}$，将域嵌入作为上下文向量中提供给${B}_{gen}^{l}$的额外输入即$\mathbf{c} = \left\lbrack  {{\mathbf{a}}_{y}^{s},{\mathbf{e}}_{d}^{gen}}\right\rbrack$，但不使用插值域嵌入${\mathcal{E}}_{\text{interp }}^{\text{gen }}$(公式5)，S4表示我们完整模型，使用插值域嵌入${\mathcal{E}}_{\text{interp }}^{\text{gen }}$生成特征。注意，${S2},{S3}$和${S4}$遵循第2.3节描述的推理机制。

From Table 2, we observe that ${S4}$ (proposed approach), which exploits the generative pipeline, semantic and domain embeddings as well as their mixing, achieves the best performance. This corroborates our hypothesis that conditioning on

从表2中我们观察到，${S4}$(所提方法)利用生成管线、语义和域嵌入及其混合，达到了最佳性能。这验证了我们的假设，即条件化于

<table><tr><td>Variant</td><td>Clipart</td><td>Infograph</td><td>Painting</td><td>Quickdraw</td><td>Sketch</td><td>Avg</td></tr><tr><td>${S1}$</td><td>27.5</td><td>17.8</td><td>25.4</td><td>9.57</td><td>22.5</td><td>20.54</td></tr><tr><td>${S2}$</td><td>27.67</td><td>17.36</td><td>27.08</td><td>11.57</td><td>24.97</td><td>21.716</td></tr><tr><td>${S3}$</td><td>28.5</td><td>17.6</td><td>26.8</td><td>12.7</td><td>25.48</td><td>22.2</td></tr><tr><td>${S4}$</td><td>28.9</td><td>18.2</td><td>27.1</td><td>13.1</td><td>25.7</td><td>22.6</td></tr></table>

<table><tbody><tr><td>变体</td><td>剪贴画</td><td>信息图</td><td>绘画</td><td>速写</td><td>素描</td><td>平均值</td></tr><tr><td>${S1}$</td><td>27.5</td><td>17.8</td><td>25.4</td><td>9.57</td><td>22.5</td><td>20.54</td></tr><tr><td>${S2}$</td><td>27.67</td><td>17.36</td><td>27.08</td><td>11.57</td><td>24.97</td><td>21.716</td></tr><tr><td>${S3}$</td><td>28.5</td><td>17.6</td><td>26.8</td><td>12.7</td><td>25.48</td><td>22.2</td></tr><tr><td>${S4}$</td><td>28.9</td><td>18.2</td><td>27.1</td><td>13.1</td><td>25.7</td><td>22.6</td></tr></tbody></table>

Table 2: Ablation study for different components of our framework on DomainNet dataset

表2:我们框架中不同组件在DomainNet数据集上的消融研究

both domain and semantic embeddings enables the classifier to discriminate between the distribution of features $\mathbf{f}$ better by encoding both domain-specific and class-level information in generated features $\widehat{\mathbf{f}}$ . Furthermore, training the final classifier on features generated by interpolating source domain embed-dings (i.e ${S4}$ ) further improves performance by alleviating the bias towards source domains.

域嵌入和语义嵌入的结合使分类器能够更好地区分特征的分布$\mathbf{f}$，通过在生成的特征中编码域特定信息和类别级信息$\widehat{\mathbf{f}}$。此外，在通过插值源域嵌入(即${S4}$)生成的特征上训练最终分类器，进一步缓解了对源域的偏差，从而提升了性能。

Visualization of Generated Features. We sample semantic attributes ${\mathbf{a}}_{y}^{u}$ for randomly selected unseen classes and use domain embeddings (learned end-to-end) of the five source domains (Real, Infograph, Quickdraw, Clipart, Sketch) used during training. We individually visualize the features generated of each unseen class using only semantic embed-dings/context i.e $\mathbf{c} = {\mathbf{a}}_{y}^{u}$ (Fig 2, Row 1) and concatenation of both semantic and domain embeddings/context i.e $\mathbf{c} = \left\lbrack  {{\mathbf{a}}_{y}^{u},{\mathbf{e}}_{d}^{\text{gen }}}\right\rbrack$ (Fig 2, Row 2) when estimating the batch-norm parameters of the generator. We notice that conditioning the batchnorm parameters on both semantic and domain context (Fig 2, Row 2) enables the model to better captures the modes of the original data distribution. It can be seen that the model can better retain domain-specific variance (associated with the five source domains) within a specific class cluster when both semantic and domain embeddings are used (Fig 2, Row 2), compared to the case where only semantic context is used (Fig 2, Row 1)

生成特征的可视化。我们为随机选取的未见类别采样语义属性${\mathbf{a}}_{y}^{u}$，并使用训练过程中学习的五个源域(Real、Infograph、Quickdraw、Clipart、Sketch)的域嵌入(端到端学习)。我们分别可视化仅使用语义嵌入/上下文(即$\mathbf{c} = {\mathbf{a}}_{y}^{u}$，图2第1行)和语义与域嵌入/上下文拼接(即$\mathbf{c} = \left\lbrack  {{\mathbf{a}}_{y}^{u},{\mathbf{e}}_{d}^{\text{gen }}}\right\rbrack$，图2第2行)时生成的每个未见类别的特征，用于估计生成器的批归一化参数。我们注意到，将批归一化参数条件化于语义和域上下文(图2第2行)使模型更好地捕捉了原始数据分布的模式。可以看出，当同时使用语义和域嵌入时(图2第2行)，模型能更好地保留特定类别簇内与五个源域相关的域特异性变异，相较于仅使用语义上下文的情况(图2第1行)表现更优。

## 4 Conclusion

## 4 结论

In this work, we propose a unified generative framework for the ZSLDG setting that uses context conditional batch-normalization to integrate class-level and domain-specific information into generated visual features, thereby enabling better generalization at test time. Through experiments, we demonstrate superior performance over established baselines and SOTA. Our proposed approach can be seamlessly integrated into other generative frameworks like VAEs, Flows, etc. which is left for future work.

本文提出了一个统一的生成框架，针对零样本领域泛化(ZSLDG)设置，利用上下文条件批归一化将类别级和域特定信息整合到生成的视觉特征中，从而在测试时实现更好的泛化能力。通过实验，我们展示了优于现有基线和最先进方法(SOTA)的性能。我们的方法可以无缝集成到其他生成框架中，如变分自编码器(VAEs)、流模型(Flows)等，未来工作将探索这一方向。

## References

## 参考文献

[Akata et al., 2013] Zeynep Akata, Florent Perronnin, Zaid Harchaoui, and Cordelia Schmid. Label-embedding for attribute-based classification. In Proceedings of the IEEE Conference on Computer Vision and Pattern Recognition, pages 819-826, 2013.

[Akata et al., 2013] Zeynep Akata, Florent Perronnin, Zaid Harchaoui, and Cordelia Schmid. 基于属性的分类的标签嵌入。发表于IEEE计算机视觉与模式识别会议论文集，页码819-826，2013年。

![bo_d1c3qt77aajc7389qeug_3_919_1695_726_230_0.jpg](images/bo_d1c3qt77aajc7389qeug_3_919_1695_726_230_0.jpg)

Figure 2: Individual t-SNE visualization of synthesized image features by COCOA for randomly selected unseen classes (Giraffe, Watermelon, Helicopter, Rainbow, Skyscraper) using only semantic context (Row 1) and both domain-semantic context (Row 2).

图2:COCOA对随机选取的未见类别(长颈鹿、西瓜、直升机、彩虹、摩天大楼)合成图像特征的单独t-SNE可视化，分别使用仅语义上下文(第1行)和域-语义上下文(第2行)。

[Carlucci et al., 2019] Fabio Maria Carlucci, Antonio D'Innocente, Silvia Bucci, B. Caputo, and T. Tommasi. Domain generalization by solving jigsaw puzzles. 2019 IEEE/CVF Conference on Computer Vision and Pattern Recognition (CVPR), pages 2224-2233, 2019.

[Carlucci et al., 2019] Fabio Maria Carlucci, Antonio D'Innocente, Silvia Bucci, B. Caputo, and T. Tommasi. 通过拼图解决方案实现域泛化。2019年IEEE/CVF计算机视觉与模式识别会议(CVPR)，页码2224-2233，2019年。

[Chandhok and Balasubramanian, 2021] Shivam Chandhok and V. Balasubramanian. Two-level adversarial visual-semantic coupling for generalized zero-shot learning. WACV, 2021.

[Chandhok and Balasubramanian, 2021] Shivam Chandhok和V. Balasubramanian. 用于广义零样本学习的两级对抗视觉-语义耦合。WACV，2021年。

[Chattopadhyay et al., 2020] Prithvijit Chattopadhyay, Y. Balaji, and Judy Hoffman. Learning to balance specificity and invariance for in and out of domain generalization. volume abs/2008.12839, 2020.

[Chattopadhyay et al., 2020] Prithvijit Chattopadhyay, Y. Balaji, 和Judy Hoffman. 学习平衡域内和域外泛化的特异性与不变性。预印本abs/2008.12839，2020年。

[Felix et al., 2018] Rafael Felix, Vijay BG Kumar, Ian Reid, and Gustavo Carneiro. Multi-modal cycle-consistent generalized zero-shot learning. In Proceedings of the European Conference on Computer Vision, 2018.

[Felix et al., 2018] Rafael Felix, Vijay BG Kumar, Ian Reid, 和Gustavo Carneiro. 多模态循环一致性广义零样本学习。发表于欧洲计算机视觉会议，2018年。

[Frome et al., 2013] Andrea Frome, Greg S Corrado, Jon Shlens, Samy Bengio, Jeff Dean, Marc'Aurelio Ranzato, and Tomas Mikolov. Devise: A deep visual-semantic embedding model. In Advances in neural information processing systems, pages 2121-2129, 2013.

[Frome et al., 2013] Andrea Frome, Greg S Corrado, Jon Shlens, Samy Bengio, Jeff Dean, Marc'Aurelio Ranzato, 和Tomas Mikolov. Devise:一种深度视觉-语义嵌入模型。发表于神经信息处理系统进展，页码2121-2129，2013年。

[Ganin et al., 2016] Yaroslav Ganin, Evgeniya Ustinova, Hana Ajakan, Pascal Germain, Hugo Larochelle, François Laviolette, Mario Marchand, and Victor Lempitsky. Domain-adversarial training of neural networks. The Journal of Machine Learning Research, 17(1):2096-2030, 2016.

[Ganin 等, 2016] Yaroslav Ganin, Evgeniya Ustinova, Hana Ajakan, Pascal Germain, Hugo Larochelle, François Laviolette, Mario Marchand 和 Victor Lempitsky. 神经网络的领域对抗训练. 机器学习研究杂志(The Journal of Machine Learning Research), 17(1):2096-2030, 2016.

[Ghifary et al., 2015] Muhammad Ghifary, W. Kleijn, M. Zhang, and D. Balduzzi. Domain generalization for object recognition with multi-task autoencoders. 2015 IEEE International Conference on Computer Vision (ICCV), pages 2551-2559, 2015.

[Ghifary 等, 2015] Muhammad Ghifary, W. Kleijn, M. Zhang 和 D. Balduzzi. 利用多任务自编码器进行目标识别的领域泛化. 2015年IEEE国际计算机视觉大会(ICCV), 页2551-2559, 2015.

[Gidaris et al., 2018] Spyros Gidaris, Praveer Singh, and Nikos Komodakis. Unsupervised representation learning by predicting image rotations. ArXiv, abs/1803.07728, 2018.

[Gidaris 等, 2018] Spyros Gidaris, Praveer Singh 和 Nikos Komodakis. 通过预测图像旋转进行无监督表示学习. ArXiv, abs/1803.07728, 2018.

[Huang et al., 2019] He Huang, Changhu Wang, Philip S Yu, and Chang-Dong Wang. Generative dual adversarial network for generalized zero-shot learning. CVPR, 2019.

[Huang 等, 2019] He Huang, Changhu Wang, Philip S Yu 和 Chang-Dong Wang. 用于广义零样本学习的生成式双重对抗网络. CVPR, 2019.

[Keshari et al., 2020] Rohit Keshari, Richa Singh, and Mayank Vatsa. Generalized zero-shot learning via overcomplete distribution. CVPR, 2020.

[Keshari 等, 2020] Rohit Keshari, Richa Singh 和 Mayank Vatsa. 通过过完备分布实现广义零样本学习. CVPR, 2020.

[Kodirov et al., 2015] Elyor Kodirov, Tao Xiang, Zhenyong Fu, and S. Gong. Unsupervised domain adaptation for zero-shot learning. 2015 IEEE International Conference on Computer Vision (ICCV), pages 2452-2460, 2015.

[Kodirov 等, 2015] Elyor Kodirov, Tao Xiang, Zhenyong Fu 和 S. Gong. 用于零样本学习的无监督领域适应. 2015年IEEE国际计算机视觉大会(ICCV), 页2452-2460, 2015.

[Li et al., 2017] Da Li, Yongxin Yang, Yi-Zhe Song, and Timothy M. Hospedales. Deeper, broader and artier domain generalization. 2017 IEEE International Conference on Computer Vision (ICCV), pages 5543-5551, 2017.

[Li 等, 2017] Da Li, Yongxin Yang, Yi-Zhe Song 和 Timothy M. Hospedales. 更深、更广、更艺术化的领域泛化. 2017年IEEE国际计算机视觉大会(ICCV), 页5543-5551, 2017.

[Li et al., 2018a] Da Li, Yongxin Yang, Yi-Zhe Song, and Timothy M. Hospedales. Learning to generalize: Meta-learning for domain generalization. In ${AAAI},{2018}$ .

[Li 等, 2018a] Da Li, Yongxin Yang, Yi-Zhe Song 和 Timothy M. Hospedales. 学习泛化:领域泛化的元学习. In ${AAAI},{2018}$ .

[Li et al., 2018b] Haoliang Li, Sinno Jialin Pan, S. Wang, and A. Kot. Domain generalization with adversarial feature learning. 2018 IEEE/CVF Conference on Computer Vision and Pattern Recognition, pages 5400-5409, 2018.

[Li 等, 2018b] Haoliang Li, Sinno Jialin Pan, S. Wang 和 A. Kot. 通过对抗特征学习实现领域泛化. 2018年IEEE/CVF计算机视觉与模式识别会议, 页5400-5409, 2018.

[Li et al., 2019a] Da Li, J. Zhang, Yongxin Yang, Cong Liu, Yi-Zhe Song, and Timothy M. Hospedales. Episodic training for domain generalization. 2019 IEEE/CVF International Conference on Computer Vision (ICCV), pages 1446-1455, 2019.

[Li 等, 2019a] Da Li, J. Zhang, Yongxin Yang, Cong Liu, Yi-Zhe Song 和 Timothy M. Hospedales. 用于领域泛化的情景训练. 2019年IEEE/CVF国际计算机视觉大会(ICCV), 页1446-1455, 2019.

[Li et al., 2019b] Da Li, Jianshu Zhang, Yongxin Yang, Cong Liu, Yi-Zhe Song, and Timothy M Hospedales. Episodic training for domain generalization. In Proceedings of the IEEE International Conference on Computer Vision, pages 1446-1455, 2019.

[Li 等, 2019b] Da Li, Jianshu Zhang, Yongxin Yang, Cong Liu, Yi-Zhe Song 和 Timothy M Hospedales. 用于领域泛化的情景训练. 载于IEEE国际计算机视觉大会论文集, 页1446-1455, 2019.

[Mancini et al., 2020] Massimiliano Mancini, Zeynep Akata, E. Ricci, and Barbara Caputo. Towards recognizing unseen categories in unseen domains. In ${ECCV}$ , 2020.

[Mancini 等, 2020] Massimiliano Mancini, Zeynep Akata, E. Ricci 和 Barbara Caputo. 迈向识别未知领域中的未知类别. In ${ECCV}$ , 2020.

[Maniyar et al., 2020] Udit Maniyar, K. J. Joseph, A. Desh-mukh, Ü. Dogan, and V. Balasubramanian. Zero-shot domain generalization. ArXiv, abs/2008.07443, 2020.

[Maniyar 等, 2020] Udit Maniyar, K. J. Joseph, A. Desh-mukh, Ü. Dogan 和 V. Balasubramanian. 零样本领域泛化. ArXiv, abs/2008.07443, 2020.

[Mikolov et al., 2013] Tomas Mikolov, Kai Chen, Greg S. Corrado, and Jeffrey Dean. Efficient estimation of word representations in vector space, 2013.

[Mikolov 等, 2013] Tomas Mikolov, Kai Chen, Greg S. Corrado 和 Jeffrey Dean. 向量空间中词表示的高效估计, 2013.

[Mishra et al., 2018] Ashish Mishra, Shiva Krishna Reddy, Anurag Mittal, and Hema A Murthy. A generative model for zero shot learning using conditional variational autoen-coders. CVPRW, 2018.

[Mishra 等, 2018] Ashish Mishra, Shiva Krishna Reddy, Anurag Mittal 和 Hema A Murthy. 使用条件变分自编码器的零样本学习生成模型. CVPRW, 2018.

[Miyato and Koyama, 2018] Takeru Miyato and Masanori Koyama. cGANs with projection discriminator. In International Conference on Learning Representations, 2018.

[Miyato 和 Koyama, 2018] Takeru Miyato 和 Masanori Koyama. 带投影判别器的条件生成对抗网络(cGANs). 国际学习表征会议, 2018.

[Muandet et al., 2013] Krikamol Muandet, D. Balduzzi, and B. Schölkopf. Domain generalization via invariant feature representation. ArXiv, abs/1301.2115, 2013.

[Muandet 等, 2013] Krikamol Muandet, D. Balduzzi 和 B. Schölkopf. 通过不变特征表示实现领域泛化。ArXiv, abs/1301.2115, 2013.

[Narayan et al., 2020] Sanath Narayan, A. Gupta, F. Khan, Cees G. M. Snoek, and L. Shao. Latent embedding feedback and discriminative features for zero-shot classification. ArXiv, abs/2003.07833, 2020.

[Narayan 等, 2020] Sanath Narayan, A. Gupta, F. Khan, Cees G. M. Snoek 和 L. Shao. 用于零样本分类的潜在嵌入反馈和判别特征。ArXiv, abs/2003.07833, 2020.

[Ni et al., 2019] Jian Ni, Shanghang Zhang, and Haiyong Xie. Dual adversarial semantics-consistent network for generalized zero-shot learning. NeurIPS, 2019.

[Ni 等, 2019] Jian Ni, Shanghang Zhang 和 Haiyong Xie. 用于广义零样本学习的双重对抗语义一致网络。NeurIPS, 2019.

[Reed et al., 2016] Scott E. Reed, Zeynep Akata, H. Lee, and B. Schiele. Learning deep representations of fine-grained visual descriptions. 2016 IEEE Conference on Computer Vision and Pattern Recognition (CVPR), pages 49-58, 2016.

[Reed 等, 2016] Scott E. Reed, Zeynep Akata, H. Lee 和 B. Schiele. 学习细粒度视觉描述的深度表示。2016 年 IEEE 计算机视觉与模式识别会议 (CVPR), 页 49-58, 2016.

[Schonfeld et al., 2019] Edgar Schonfeld, Sayna Ebrahimi, Samarth Sinha, Trevor Darrell, and Zeynep Akata. Generalized zero-and few-shot learning via aligned variational autoencoders. CVPR, 2019.

[Schonfeld 等, 2019] Edgar Schonfeld, Sayna Ebrahimi, Samarth Sinha, Trevor Darrell 和 Zeynep Akata. 通过对齐变分自编码器实现广义零样本和少样本学习。CVPR, 2019.

[Seo et al., 2020] Seonguk Seo, Yumin Suh, D. Kim, Jong-woo Han, and B. Han. Learning to optimize domain specific normalization for domain generalization. 2020.

[Seo 等, 2020] Seonguk Seo, Yumin Suh, D. Kim, Jong-woo Han 和 B. Han. 学习优化领域特定归一化以实现领域泛化。2020.

[Shen et al., 2020] Yuming Shen, J. Qin, and L. Huang. Invertible zero-shot recognition flows. In ${ECCV},{2020}$ .

[Shen 等, 2020] Yuming Shen, J. Qin 和 L. Huang. 可逆零样本识别流。In ${ECCV},{2020}$ .

[Wan et al., 2019] Ziyu Wan, Dongdong Chen, Y. Li, Xing-guang Yan, Junge Zhang, Y. Yu, and Jing Liao. Transduc-tive zero-shot learning with visual structure constraint. In NeurIPS, 2019.

[Wan 等, 2019] Ziyu Wan, Dongdong Chen, Y. Li, Xing-guang Yan, Junge Zhang, Y. Yu 和 Jing Liao. 具有视觉结构约束的传导式零样本学习。In NeurIPS, 2019.

[Xian et al., 2018] Yongqin Xian, Tobias Lorenz, Bernt Schiele, , and Zeynep Akata. Feature generating networks for zero-shot learning. CVPR, 2018.

[Xian 等, 2018] Yongqin Xian, Tobias Lorenz, Bernt Schiele 和 Zeynep Akata. 用于零样本学习的特征生成网络。CVPR, 2018.

[Xian et al., 2019] Yongqin Xian, Subhabrata Choudhury, Yang He, Bernt Schiele, and Zeynep Akata. Semantic projection network for zero-and few-label semantic segmentation. In Proceedings of the IEEE Conference on Computer Vision and Pattern Recognition, pages 8256-8265, 2019.

[Xian 等, 2019] Yongqin Xian, Subhabrata Choudhury, Yang He, Bernt Schiele 和 Zeynep Akata. 用于零样本和少标签语义分割的语义投影网络。发表于 IEEE 计算机视觉与模式识别会议论文集, 页 8256-8265, 2019.

[Xu et al., 2014] Zheng Xu, W. Li, Li Niu, and Dong Xu. Exploiting low-rank structure from latent domains for domain generalization. In ${ECCV},{2014}$ .

[Xu 等, 2014] Zheng Xu, W. Li, Li Niu 和 Dong Xu. 利用潜在领域的低秩结构实现领域泛化。In ${ECCV},{2014}$ .

[Yang and Gao, 2013] P. Yang and Wei Gao. Multi-view discriminant transfer learning. In IJCAI, 2013.

[Yang 和 Gao, 2013] P. Yang 和 Wei Gao. 多视角判别迁移学习。In IJCAI, 2013.

[Zhang et al., 2017] L. Zhang, Tao Xiang, and S. Gong. Learning a deep embedding model for zero-shot learning. 2017 IEEE Conference on Computer Vision and Pattern Recognition (CVPR), pages 3010-3019, 2017.

[Zhang 等, 2017] L. Zhang, Tao Xiang 和 S. Gong. 学习用于零样本学习的深度嵌入模型。2017 年 IEEE 计算机视觉与模式识别会议 (CVPR), 页 3010-3019, 2017.