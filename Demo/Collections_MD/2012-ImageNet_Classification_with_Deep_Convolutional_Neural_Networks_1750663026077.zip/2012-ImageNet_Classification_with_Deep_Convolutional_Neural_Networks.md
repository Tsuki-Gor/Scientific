# ImageNet Classification with Deep Convolutional Neural Networks

# 使用深度卷积神经网络进行ImageNet分类

Alex Krizhevsky

Alex Krizhevsky

University of Toronto

多伦多大学

kriz@cs.utoronto.ca

Ilya Sutskever

Ilya Sutskever

University of Toronto

多伦多大学

ilya@cs.utoronto.ca

Geoffrey E. Hinton

Geoffrey E. Hinton

University of Toronto

多伦多大学

hinton@cs.utoronto.ca

## Abstract

## 摘要

We trained a large, deep convolutional neural network to classify the 1.2 million high-resolution images in the ImageNet LSVRC-2010 contest into the 1000 different classes. On the test data, we achieved top-1 and top-5 error rates of 37.5% and 17.0% which is considerably better than the previous state-of-the-art. The neural network, which has 60 million parameters and 650,000 neurons, consists of five convolutional layers, some of which are followed by max-pooling layers, and three fully-connected layers with a final 1000-way softmax. To make training faster, we used non-saturating neurons and a very efficient GPU implementation of the convolution operation. To reduce overfitting in the fully-connected layers we employed a recently-developed regularization method called "dropout" that proved to be very effective. We also entered a variant of this model in the ILSVRC-2012 competition and achieved a winning top-5 test error rate of 15.3%, compared to 26.2% achieved by the second-best entry.

我们训练了一个大型深度卷积神经网络(Convolutional Neural Network, CNN)，用于将ImageNet LSVRC-2010竞赛中的120万张高分辨率图像分类为1000个不同类别。在测试数据上，我们实现了37.5%的top-1错误率和17.0%的top-5错误率，显著优于之前的最先进水平。该神经网络拥有6000万个参数和65万个神经元，由五个卷积层组成，其中部分卷积层后接最大池化层(max-pooling)，以及三个全连接层，最终通过1000类的softmax输出。为了加快训练速度，我们采用了非饱和神经元和高效的GPU卷积操作实现。为减少全连接层的过拟合，我们采用了一种新近开发的正则化方法“dropout”，效果显著。我们还将该模型的一个变体参加了ILSVRC-2012竞赛，取得了15.3%的top-5测试错误率，远优于第二名的26.2%。

## 1 Introduction

## 1 引言

Current approaches to object recognition make essential use of machine learning methods. To improve their performance, we can collect larger datasets, learn more powerful models, and use better techniques for preventing overfitting. Until recently, datasets of labeled images were relatively small - on the order of tens of thousands of images (e.g., NORB [16], Caltech-101/256 [8, 9], and CIFAR-10/100 [12]). Simple recognition tasks can be solved quite well with datasets of this size, especially if they are augmented with label-preserving transformations. For example, the current-best error rate on the MNIST digit-recognition task (<0.3%) approaches human performance [4]. But objects in realistic settings exhibit considerable variability, so to learn to recognize them it is necessary to use much larger training sets. And indeed, the shortcomings of small image datasets have been widely recognized (e.g., Pinto et al. [21]), but it has only recently become possible to collect labeled datasets with millions of images. The new larger datasets include LabelMe [23], which consists of hundreds of thousands of fully-segmented images, and ImageNet [6], which consists of over 15 million labeled high-resolution images in over 22,000 categories.

当前的目标识别方法本质上依赖于机器学习技术。为了提升性能，我们可以收集更大规模的数据集，学习更强大的模型，并采用更有效的防止过拟合的技术。直到最近，带标签的图像数据集规模相对较小——大约几万张图像(例如，NORB [16]、Caltech-101/256 [8, 9] 和 CIFAR-10/100 [12])。对于简单的识别任务，这样规模的数据集配合保持标签不变的变换增强，已经能取得较好效果。例如，当前MNIST数字识别任务的最佳错误率低于0.3%，接近人类水平[4]。但现实场景中的物体具有较大变异性，因此要学会识别它们，必须使用更大规模的训练集。小规模图像数据集的不足已被广泛认识(如Pinto等[21])，而且直到最近才有可能收集到包含数百万张图像的带标签数据集。新兴的大型数据集包括LabelMe [23]，包含数十万张完全分割的图像，以及ImageNet [6]，包含超过1500万张带标签的高分辨率图像，涵盖22000多个类别。

To learn about thousands of objects from millions of images, we need a model with a large learning capacity. However, the immense complexity of the object recognition task means that this problem cannot be specified even by a dataset as large as ImageNet, so our model should also have lots of prior knowledge to compensate for all the data we don't have. Convolutional neural networks (CNNs) constitute one such class of models [16, 11, 13, 18, 15, 22, 26]. Their capacity can be controlled by varying their depth and breadth, and they also make strong and mostly correct assumptions about the nature of images (namely, stationarity of statistics and locality of pixel dependencies). Thus, compared to standard feedforward neural networks with similarly-sized layers, CNNs have much fewer connections and parameters and so they are easier to train, while their theoretically-best performance is likely to be only slightly worse. Despite the attractive qualities of CNNs, and despite the relative efficiency of their local architecture, they have still been prohibitively expensive to apply in large scale to high-resolution images. Luckily, current GPUs, paired with a highly-optimized implementation of 2D convolution, are powerful enough to facilitate the training of interestingly-large CNNs, and recent datasets such as ImageNet contain enough labeled examples to train such models without severe overfitting.

为了从数百万张图像中学习数千个物体类别，我们需要一个具有大容量学习能力的模型。然而，目标识别任务的极大复杂性意味着即使是像ImageNet这样的大型数据集也无法完全定义该问题，因此我们的模型还应具备大量先验知识，以弥补数据的不足。卷积神经网络(CNN)就是这样一类模型[16, 11, 13, 18, 15, 22, 26]。其容量可以通过调整深度和宽度来控制，同时它们对图像的本质做出了强且大多正确的假设(即统计的平稳性和像素依赖的局部性)。因此，与具有相似规模层数的标准前馈神经网络相比，CNN的连接和参数更少，更易训练，而其理论上的最佳性能可能仅略逊一筹。尽管CNN具有诸多优点，且其局部架构相对高效，但在高分辨率图像上大规模应用仍然代价高昂。幸运的是，当前GPU结合高度优化的二维卷积实现，足以支持训练较大规模的CNN，而像ImageNet这样的新数据集也提供了足够的带标签样本，避免了严重的过拟合问题。

The specific contributions of this paper are as follows: we trained one of the largest convolutional neural networks to date on the subsets of ImageNet used in the ILSVRC-2010 and ILSVRC-2012 competitions [2] and achieved by far the best results ever reported on these datasets. We wrote a highly-optimized GPU implementation of $2\mathrm{D}$ convolution and all the other operations inherent in training convolutional neural networks, which we make available publicly ${}^{1}$ . Our network contains a number of new and unusual features which improve its performance and reduce its training time, which are detailed in Section 3. The size of our network made overfitting a significant problem, even with 1.2 million labeled training examples, so we used several effective techniques for preventing overfitting, which are described in Section 4. Our final network contains five convolutional and three fully-connected layers, and this depth seems to be important: we found that removing any convolutional layer (each of which contains no more than 1% of the model's parameters) resulted in inferior performance.

本文的具体贡献如下:我们在ILSVRC-2010和ILSVRC-2012竞赛中使用的ImageNet子集上训练了迄今为止最大的卷积神经网络之一，并在这些数据集上取得了迄今为止最好的结果。我们编写了一个高度优化的GPU实现，涵盖了$2\mathrm{D}$卷积及训练卷积神经网络所需的所有其他操作，并公开提供了该实现${}^{1}$。我们的网络包含许多新颖且不寻常的特性，这些特性提升了性能并缩短了训练时间，具体内容详见第3节。由于网络规模庞大，即使拥有120万标注训练样本，过拟合仍是一个显著问题，因此我们采用了几种有效的防止过拟合技术，详见第4节。最终网络包含五个卷积层和三个全连接层，这种深度似乎至关重要:我们发现移除任何一个卷积层(每层参数不超过模型总参数的1%)都会导致性能下降。

In the end, the network's size is limited mainly by the amount of memory available on current GPUs and by the amount of training time that we are willing to tolerate. Our network takes between five and six days to train on two GTX 580 3GB GPUs. All of our experiments suggest that our results can be improved simply by waiting for faster GPUs and bigger datasets to become available.

最终，网络的规模主要受限于当前GPU的内存容量以及我们愿意接受的训练时间。我们的网络在两块GTX 580 3GB GPU上训练需要五到六天。所有实验表明，随着更快GPU和更大数据集的出现，我们的结果有望进一步提升。

## 2 The Dataset

## 2 数据集

ImageNet is a dataset of over 15 million labeled high-resolution images belonging to roughly 22,000 categories. The images were collected from the web and labeled by human labelers using Amazon's Mechanical Turk crowd-sourcing tool. Starting in 2010, as part of the Pascal Visual Object Challenge, an annual competition called the ImageNet Large-Scale Visual Recognition Challenge (ILSVRC) has been held. ILSVRC uses a subset of ImageNet with roughly 1000 images in each of 1000 categories. In all, there are roughly 1.2 million training images, 50,000 validation images, and 150,000 testing images.

ImageNet是一个包含超过1500万张高分辨率标注图像的数据集，涵盖约22000个类别。图像来自网络，由使用亚马逊Mechanical Turk众包工具的人类标注者标注。自2010年起，作为Pascal视觉对象挑战赛的一部分，每年举办一次名为ImageNet大规模视觉识别挑战赛(ILSVRC)。ILSVRC使用ImageNet的一个子集，每个类别约有1000张图像。总体上，训练集约有120万张图像，验证集5万张，测试集15万张。

ILSVRC-2010 is the only version of ILSVRC for which the test set labels are available, so this is the version on which we performed most of our experiments. Since we also entered our model in the ILSVRC-2012 competition, in Section 6 we report our results on this version of the dataset as well, for which test set labels are unavailable. On ImageNet, it is customary to report two error rates: top-1 and top-5, where the top-5 error rate is the fraction of test images for which the correct label is not among the five labels considered most probable by the model.

ILSVRC-2010是唯一一个测试集标签公开的ILSVRC版本，因此我们的大部分实验均基于该版本。由于我们也参加了ILSVRC-2012竞赛，第6节中报告了该版本的数据集结果，测试集标签不可用。在ImageNet上，通常报告两种错误率:top-1和top-5，其中top-5错误率指模型预测的五个最可能标签中不包含正确标签的测试图像比例。

ImageNet consists of variable-resolution images, while our system requires a constant input dimensionality. Therefore, we down-sampled the images to a fixed resolution of ${256} \times  {256}$ . Given a rectangular image, we first rescaled the image such that the shorter side was of length 256, and then cropped out the central ${256} \times  {256}$ patch from the resulting image. We did not pre-process the images in any other way, except for subtracting the mean activity over the training set from each pixel. So we trained our network on the (centered) raw RGB values of the pixels.

ImageNet包含分辨率不一的图像，而我们的系统要求输入维度固定。因此，我们将图像下采样至固定分辨率${256} \times  {256}$。对于矩形图像，首先将其短边缩放至256像素，然后从缩放后的图像中裁剪出中心的${256} \times  {256}$区域。除从每个像素中减去训练集的均值外，我们未对图像做其他预处理。因此，我们的网络训练使用的是像素的(中心裁剪的)原始RGB值。

## 3 The Architecture

## 3 网络结构

The architecture of our network is summarized in Figure 2. It contains eight learned layers — five convolutional and three fully-connected. Below, we describe some of the novel or unusual features of our network's architecture. Sections 3.1-3.4 are sorted according to our estimation of their importance, with the most important first.

我们网络的结构在图2中进行了总结。它包含八个可学习层——五个卷积层和三个全连接层。下面介绍网络结构中一些新颖或不寻常的特性。第3.1至3.4节按照我们对其重要性的估计排序，最重要的排在前面。

---

${}^{1}$ http://code.google.com/p/cuda-convnet/

${}^{1}$ http://code.google.com/p/cuda-convnet/

---

### 3.1 ReLU Nonlinearity

### 3.1 ReLU非线性激活

The standard way to model a neuron’s output $f$ as a function of its input $x$ is with $f\left( x\right)  = \tanh \left( x\right)$ or $f\left( x\right)  = {\left( 1 + {e}^{-x}\right) }^{-1}$ . In terms of training time with gradient descent, these saturating nonlinearities are much slower than the non-saturating nonlinearity $f\left( x\right)  = \max \left( {0, x}\right)$ . Following Nair and Hinton [20], we refer to neurons with this nonlinearity as Rectified Linear Units (ReLUs). Deep convolutional neural networks with ReLUs train several times faster than their equivalents with tanh units. This is demonstrated in Figure 1, which shows the number of iterations required to reach ${25}\%$ training error on the CIFAR-10 dataset for a particular four-layer convolutional network. This plot shows that we would not have been able to experiment with such large neural networks for this work if we had used traditional saturating neuron models.

将神经元输出$f$作为其输入$x$的函数进行建模的标准方法是使用$f\left( x\right)  = \tanh \left( x\right)$或$f\left( x\right)  = {\left( 1 + {e}^{-x}\right) }^{-1}$。在使用梯度下降训练时，这些饱和非线性函数的训练速度远慢于非饱和非线性函数$f\left( x\right)  = \max \left( {0, x}\right)$。遵循Nair和Hinton [20]的做法，我们将采用此非线性的神经元称为修正线性单元(Rectified Linear Units，ReLUs)。采用ReLUs的深度卷积神经网络训练速度比使用tanh单元的同类网络快数倍。如图1所示，图中展示了在CIFAR-10数据集上，某四层卷积网络达到${25}\%$训练误差所需的迭代次数。该图表明，如果我们使用传统的饱和神经元模型，就无法在本研究中尝试如此大型的神经网络。

We are not the first to consider alternatives to traditional neuron models in CNNs. For example, Jarrett et al. [11] claim that the nonlinearity $f\left( x\right)  = \left| {\tanh \left( x\right) }\right|$ works particularly well with their type of contrast normalization followed by local average pooling on the Caltech-101 dataset. However, on this dataset the primary concern is preventing overfitting, so the effect they are observing is different from the accelerated ability to fit the training set which we report when using ReLUs. Faster learning has a great influence on the performance of large models trained on large datasets.

我们并非首个在卷积神经网络(CNN)中考虑传统神经元模型替代方案的研究者。例如，Jarrett等人[11]声称非线性函数$f\left( x\right)  = \left| {\tanh \left( x\right) }\right|$在其采用的对比度归一化后接局部平均池化的Caltech-101数据集上表现尤为出色。然而，在该数据集上，主要关注点是防止过拟合，因此他们观察到的效果与我们使用ReLUs时报告的加速拟合训练集能力不同。更快的学习速度对在大规模数据集上训练的大型模型性能有显著影响。

![bo_d1c3mmbef24c73d2ojqg_2_974_350_510_420_0.jpg](images/bo_d1c3mmbef24c73d2ojqg_2_974_350_510_420_0.jpg)

Figure 1: A four-layer convolutional neural network with ReLUs (solid line) reaches a 25% training error rate on CIFAR-10 six times faster than an equivalent network with tanh neurons (dashed line). The learning rates for each network were chosen independently to make training as fast as possible. No regularization of any kind was employed. The magnitude of the effect demonstrated here varies with network architecture, but networks with ReLUs consistently learn several times faster than equivalents with saturating neurons.

图1:采用ReLUs的四层卷积神经网络(实线)在CIFAR-10数据集上达到25%的训练误差率，其速度是采用tanh神经元的等效网络(虚线)的六倍。每个网络的学习率均独立选择，以实现尽可能快的训练速度。未采用任何形式的正则化。此处展示的效果大小随网络架构变化，但采用ReLUs的网络始终比采用饱和神经元的等效网络学习速度快数倍。

### 3.2 Training on Multiple GPUs

### 3.2 多GPU训练

A single GTX 580 GPU has only 3GB of memory, which limits the maximum size of the networks that can be trained on it. It turns out that 1.2 million training examples are enough to train networks which are too big to fit on one GPU. Therefore we spread the net across two GPUs. Current GPUs are particularly well-suited to cross-GPU parallelization, as they are able to read from and write to one another's memory directly, without going through host machine memory. The parallelization scheme that we employ essentially puts half of the kernels (or neurons) on each GPU, with one additional trick: the GPUs communicate only in certain layers. This means that, for example, the kernels of layer 3 take input from all kernel maps in layer 2. However, kernels in layer 4 take input only from those kernel maps in layer 3 which reside on the same GPU. Choosing the pattern of connectivity is a problem for cross-validation, but this allows us to precisely tune the amount of communication until it is an acceptable fraction of the amount of computation.

单个GTX 580 GPU仅有3GB内存，限制了可训练网络的最大规模。事实证明，120万个训练样本足以训练无法容纳于单个GPU的大型网络。因此，我们将网络分布在两块GPU上。当前GPU特别适合跨GPU并行化，因为它们能够直接读写彼此的内存，无需经过主机内存。我们采用的并行方案基本上将一半的卷积核(或神经元)放在每个GPU上，并采用一个额外技巧:GPU之间仅在特定层进行通信。例如，第三层的卷积核接收第二层所有卷积核图的输入，但第四层的卷积核仅接收同一GPU上第三层卷积核图的输入。连接模式的选择是交叉验证的问题，但这使我们能够精确调节通信量，直到其成为计算量的可接受比例。

The resultant architecture is somewhat similar to that of the "columnar" CNN employed by Cireşan et al. [5], except that our columns are not independent (see Figure 2). This scheme reduces our top-1 and top-5 error rates by 1.7% and 1.2%, respectively, as compared with a net with half as many kernels in each convolutional layer trained on one GPU. The two-GPU net takes slightly less time to train than the one-GPU net ${}^{2}$ .

所得架构与Cireşan等人[5]采用的“柱状”卷积神经网络有些相似，但我们的柱状结构并非独立(见图2)。与在单GPU上训练、每个卷积层卷积核数量减半的网络相比，该方案分别将我们的top-1和top-5错误率降低了1.7%和1.2%。两GPU网络的训练时间略少于单GPU网络${}^{2}$。

---

${}^{2}$ The one-GPU net actually has the same number of kernels as the two-GPU net in the final convolutional layer. This is because most of the net's parameters are in the first fully-connected layer, which takes the last convolutional layer as input. So to make the two nets have approximately the same number of parameters, we did not halve the size of the final convolutional layer (nor the fully-conneced layers which follow). Therefore this comparison is biased in favor of the one-GPU net, since it is bigger than "half the size" of the two-GPU net.

${}^{2}$ 单GPU网络在最后一层卷积层的卷积核数量实际上与两GPU网络相同。这是因为网络的大部分参数集中在第一全连接层，该层以最后一卷积层为输入。为了使两个网络参数数量大致相同，我们没有将最后一卷积层(及其后续全连接层)的规模减半。因此，此比较对单GPU网络有利，因为它比两GPU网络的“半规模”要大。

---

### 3.3 Local Response Normalization

### 3.3 局部响应归一化

ReLUs have the desirable property that they do not require input normalization to prevent them from saturating. If at least some training examples produce a positive input to a ReLU, learning will happen in that neuron. However, we still find that the following local normalization scheme aids generalization. Denoting by ${a}_{x, y}^{i}$ the activity of a neuron computed by applying kernel $i$ at position (x, y)and then applying the ReLU nonlinearity, the response-normalized activity ${b}_{x, y}^{i}$ is given by the expression

ReLU具有一个理想的特性，即它们不需要输入归一化来防止饱和。如果至少有一些训练样本对ReLU产生正输入，该神经元就会发生学习。然而，我们仍然发现以下局部归一化方案有助于泛化。记${a}_{x, y}^{i}$为通过在位置(x, y)应用核$i$后再应用ReLU非线性计算得到的神经元活动，响应归一化后的活动${b}_{x, y}^{i}$由下式给出

$$
{b}_{x, y}^{i} = {a}_{x, y}^{i}/{\left( k + \alpha \mathop{\sum }\limits_{{j = \max \left( {0, i - n/2}\right) }}^{{\min \left( {N - 1, i + n/2}\right) }}{\left( {a}_{x, y}^{j}\right) }^{2}\right) }^{\beta }
$$

where the sum runs over $n$ "adjacent" kernel maps at the same spatial position, and $N$ is the total number of kernels in the layer. The ordering of the kernel maps is of course arbitrary and determined before training begins. This sort of response normalization implements a form of lateral inhibition inspired by the type found in real neurons, creating competition for big activities amongst neuron outputs computed using different kernels. The constants $k, n,\alpha$ , and $\beta$ are hyper-parameters whose values are determined using a validation set; we used $k = 2, n = 5,\alpha  = {10}^{-4}$ , and $\beta  = {0.75}$ . We applied this normalization after applying the ReLU nonlinearity in certain layers (see Section 3.5).

其中求和在同一空间位置的$n$“相邻”核映射上进行，$N$是该层中核的总数。核映射的顺序当然是任意的，并在训练开始前确定。这种响应归一化实现了一种受真实神经元中发现的侧抑制启发的机制，在使用不同核计算的神经元输出之间产生对大活动的竞争。常数$k, n,\alpha$和$\beta$是超参数，其值通过验证集确定；我们使用了$k = 2, n = 5,\alpha  = {10}^{-4}$和$\beta  = {0.75}$。我们在某些层中(见第3.5节)在应用ReLU非线性后应用了这种归一化。

This scheme bears some resemblance to the local contrast normalization scheme of Jarrett et al. [11], but ours would be more correctly termed "brightness normalization", since we do not subtract the mean activity. Response normalization reduces our top-1 and top-5 error rates by 1.4% and 1.2%, respectively. We also verified the effectiveness of this scheme on the CIFAR-10 dataset: a four-layer CNN achieved a 13% test error rate without normalization and 11% with normalization ${}^{3}$ .

该方案与Jarrett等人[11]提出的局部对比度归一化方案有些相似，但我们的方法更准确地称为“亮度归一化”，因为我们没有减去平均活动。响应归一化分别将我们的top-1和top-5错误率降低了1.4%和1.2%。我们还验证了该方案在CIFAR-10数据集上的有效性:一个四层卷积神经网络在未归一化时测试错误率为13%，归一化后为11%${}^{3}$。

### 3.4 Overlapping Pooling

### 3.4 重叠池化

Pooling layers in CNNs summarize the outputs of neighboring groups of neurons in the same kernel map. Traditionally, the neighborhoods summarized by adjacent pooling units do not overlap (e.g., $\left\lbrack  {{17},{11},4}\right\rbrack  )$ . To be more precise, a pooling layer can be thought of as consisting of a grid of pooling units spaced $s$ pixels apart, each summarizing a neighborhood of size $z \times  z$ centered at the location of the pooling unit. If we set $s = z$ , we obtain traditional local pooling as commonly employed in CNNs. If we set $s < z$ , we obtain overlapping pooling. This is what we use throughout our network, with $s = 2$ and $z = 3$ . This scheme reduces the top-1 and top-5 error rates by 0.4% and ${0.3}\%$ , respectively, as compared with the non-overlapping scheme $s = 2, z = 2$ , which produces output of equivalent dimensions. We generally observe during training that models with overlapping pooling find it slightly more difficult to overfit.

CNN中的池化层总结同一核映射中相邻神经元组的输出。传统上，相邻池化单元总结的邻域不重叠(例如，$\left\lbrack  {{17},{11},4}\right\rbrack  )$。更准确地说，池化层可以被视为由间隔为$s$像素的池化单元网格组成，每个单元总结以该单元位置为中心、大小为$z \times  z$的邻域。如果设置$s = z$，则得到CNN中常用的传统局部池化。如果设置$s < z$，则得到重叠池化。这是我们在整个网络中使用的方案，参数为$s = 2$和$z = 3$。与产生等效维度输出的非重叠方案$s = 2, z = 2$相比，该方案分别将top-1和top-5错误率降低了0.4%和${0.3}\%$。我们通常观察到，在训练过程中，采用重叠池化的模型稍微更难过拟合。

### 3.5 Overall Architecture

### 3.5 整体架构

Now we are ready to describe the overall architecture of our CNN. As depicted in Figure 2, the net contains eight layers with weights; the first five are convolutional and the remaining three are fully-connected. The output of the last fully-connected layer is fed to a 1000-way softmax which produces a distribution over the 1000 class labels. Our network maximizes the multinomial logistic regression objective, which is equivalent to maximizing the average across training cases of the log-probability of the correct label under the prediction distribution.

现在我们准备描述我们CNN的整体架构。如图2所示，网络包含八个带权重的层；前五层为卷积层，后面三层为全连接层。最后一个全连接层的输出输入到一个1000类的softmax，产生对1000个类别标签的分布。我们的网络最大化多项式逻辑回归目标，即最大化训练样本中正确标签在预测分布下对数概率的平均值。

The kernels of the second, fourth, and fifth convolutional layers are connected only to those kernel maps in the previous layer which reside on the same GPU (see Figure 2). The kernels of the third convolutional layer are connected to all kernel maps in the second layer. The neurons in the fully-connected layers are connected to all neurons in the previous layer. Response-normalization layers follow the first and second convolutional layers. Max-pooling layers, of the kind described in Section 3.4, follow both response-normalization layers as well as the fifth convolutional layer. The ReLU non-linearity is applied to the output of every convolutional and fully-connected layer.

第二、第四和第五卷积层的核仅连接到前一层中位于同一GPU上的核映射(见图2)。第三卷积层的核连接到第二层的所有核映射。全连接层的神经元连接到前一层的所有神经元。响应归一化层位于第一和第二卷积层之后。最大池化层(如第3.4节所述)位于两个响应归一化层之后以及第五卷积层之后。ReLU非线性应用于每个卷积层和全连接层的输出。

The first convolutional layer filters the ${224} \times  {224} \times  3$ input image with 96 kernels of size ${11} \times  {11} \times  3$ with a stride of 4 pixels (this is the distance between the receptive field centers of neighboring neurons in a kernel map). The second convolutional layer takes as input the (response-normalized and pooled) output of the first convolutional layer and filters it with 256 kernels of size $5 \times  5 \times  {48}$ . The third, fourth, and fifth convolutional layers are connected to one another without any intervening pooling or normalization layers. The third convolutional layer has 384 kernels of size $3 \times  3 \times$ 256 connected to the (normalized, pooled) outputs of the second convolutional layer. The fourth convolutional layer has 384 kernels of size $3 \times  3 \times  {192}$ , and the fifth convolutional layer has 256 kernels of size $3 \times  3 \times  {192}$ . The fully-connected layers have 4096 neurons each.

第一卷积层使用96个大小为${11} \times  {11} \times  3$的卷积核以4像素的步幅(即卷积核映射中相邻神经元感受野中心之间的距离)对${224} \times  {224} \times  3$输入图像进行滤波。第二卷积层以第一卷积层的(响应归一化和池化后的)输出为输入，使用256个大小为$5 \times  5 \times  {48}$的卷积核进行滤波。第三、第四和第五卷积层相互连接，中间没有任何池化或归一化层。第三卷积层有384个大小为$3 \times  3 \times$的卷积核，连接到第二卷积层的(归一化、池化后)输出。第四卷积层有384个大小为$3 \times  3 \times  {192}$的卷积核，第五卷积层有256个大小为$3 \times  3 \times  {192}$的卷积核。全连接层各有4096个神经元。

---

${}^{3}$ We cannot describe this network in detail due to space constraints, but it is specified precisely by the code and parameter files provided here: http://code.google.com/p/cuda-convnet/.

${}^{3}$ 由于篇幅限制，我们无法详细描述该网络，但其代码和参数文件已在此处精确指定:http://code.google.com/p/cuda-convnet/。

---

![bo_d1c3mmbef24c73d2ojqg_4_304_230_1187_381_0.jpg](images/bo_d1c3mmbef24c73d2ojqg_4_304_230_1187_381_0.jpg)

Figure 2: An illustration of the architecture of our CNN, explicitly showing the delineation of responsibilities between the two GPUs. One GPU runs the layer-parts at the top of the figure while the other runs the layer-parts at the bottom. The GPUs communicate only at certain layers. The network's input is 150,528-dimensional, and the number of neurons in the network’s remaining layers is given by 253,440-186,624-64,896-64,896-43,264- 4096-4096-1000.

图2:我们卷积神经网络(CNN)架构的示意图，明确显示了两块GPU之间的职责划分。一块GPU运行图中上方的层部分，另一块GPU运行下方的层部分。GPU仅在某些层进行通信。网络输入维度为150,528，网络其余层的神经元数量依次为253,440-186,624-64,896-64,896-43,264-4096-4096-1000。

## 4 Reducing Overfitting

## 4 减少过拟合

Our neural network architecture has 60 million parameters. Although the 1000 classes of ILSVRC make each training example impose 10 bits of constraint on the mapping from image to label, this turns out to be insufficient to learn so many parameters without considerable overfitting. Below, we describe the two primary ways in which we combat overfitting.

我们的神经网络架构拥有6000万个参数。尽管ILSVRC的1000个类别使每个训练样本对图像到标签的映射施加了10比特的约束，但这仍不足以在不产生大量过拟合的情况下学习如此多的参数。下面我们描述两种主要的抗过拟合方法。

### 4.1 Data Augmentation

### 4.1 数据增强

The easiest and most common method to reduce overfitting on image data is to artificially enlarge the dataset using label-preserving transformations (e.g., $\left\lbrack  {{25},4,5}\right\rbrack  )$ . We employ two distinct forms of data augmentation, both of which allow transformed images to be produced from the original images with very little computation, so the transformed images do not need to be stored on disk. In our implementation, the transformed images are generated in Python code on the CPU while the GPU is training on the previous batch of images. So these data augmentation schemes are, in effect, computationally free.

减少图像数据过拟合最简单且最常用的方法是使用保持标签不变的变换人工扩大数据集(例如$\left\lbrack  {{25},4,5}\right\rbrack  )$)。我们采用两种不同形式的数据增强，这两种方法都能通过极少的计算从原始图像生成变换图像，因此无需将变换后的图像存储到磁盘。在我们的实现中，变换图像由CPU上的Python代码生成，同时GPU在训练上一批图像。因此，这些数据增强方案实际上是计算上免费的。

The first form of data augmentation consists of generating image translations and horizontal reflections. We do this by extracting random ${224} \times  {224}$ patches (and their horizontal reflections) from the ${256} \times  {256}$ images and training our network on these extracted patches ${}^{4}$ . This increases the size of our training set by a factor of 2048, though the resulting training examples are, of course, highly interdependent. Without this scheme, our network suffers from substantial overfitting, which would have forced us to use much smaller networks. At test time, the network makes a prediction by extracting five ${224} \times  {224}$ patches (the four corner patches and the center patch) as well as their horizontal reflections (hence ten patches in all), and averaging the predictions made by the network's softmax layer on the ten patches.

第一种数据增强形式是生成图像平移和水平翻转。我们通过从${256} \times  {256}$图像中随机提取${224} \times  {224}$补丁(及其水平翻转)并用这些提取的补丁训练网络${}^{4}$。这使训练集规模增加了2048倍，尽管生成的训练样本高度相关。没有此方案，我们的网络会严重过拟合，迫使我们使用更小的网络。测试时，网络通过提取五个${224} \times  {224}$补丁(四个角落补丁和中心补丁)及其水平翻转(共十个补丁)，并对网络softmax层对这十个补丁的预测结果取平均来进行预测。

The second form of data augmentation consists of altering the intensities of the RGB channels in training images. Specifically, we perform PCA on the set of RGB pixel values throughout the ImageNet training set. To each training image, we add multiples of the found principal components, with magnitudes proportional to the corresponding eigenvalues times a random variable drawn from a Gaussian with mean zero and standard deviation 0.1 . Therefore to each RGB image pixel ${I}_{xy} =$ ${\left\lbrack  {I}_{xy}^{R},{I}_{xy}^{G},{I}_{xy}^{B}\right\rbrack  }^{T}$ we add the following quantity:

第二种数据增强形式是改变训练图像中RGB通道的强度。具体地，我们对整个ImageNet训练集的RGB像素值集合进行主成分分析(PCA)。对每张训练图像，我们添加主成分的倍数，幅度与对应特征值乘以从均值为零、标准差为0.1的高斯分布中抽取的随机变量成正比。因此，对每个RGB图像像素${I}_{xy} =$ ${\left\lbrack  {I}_{xy}^{R},{I}_{xy}^{G},{I}_{xy}^{B}\right\rbrack  }^{T}$我们添加以下量:

$$
\left\lbrack  {{\mathbf{p}}_{1},{\mathbf{p}}_{2},{\mathbf{p}}_{3}}\right\rbrack  {\left\lbrack  {\alpha }_{1}{\lambda }_{1},{\alpha }_{2}{\lambda }_{2},{\alpha }_{3}{\lambda }_{3}\right\rbrack  }^{T}
$$

---

${}^{4}$ This is the reason why the input images in Figure 2 are ${224} \times  {224} \times  3$ -dimensional.

${}^{4}$ 这就是图2中输入图像维度为${224} \times  {224} \times  3$的原因。

---

where ${\mathbf{p}}_{i}$ and ${\lambda }_{i}$ are $i$ th eigenvector and eigenvalue of the $3 \times  3$ covariance matrix of RGB pixel values, respectively, and ${\alpha }_{i}$ is the aforementioned random variable. Each ${\alpha }_{i}$ is drawn only once for all the pixels of a particular training image until that image is used for training again, at which point it is re-drawn. This scheme approximately captures an important property of natural images, namely, that object identity is invariant to changes in the intensity and color of the illumination. This scheme reduces the top-1 error rate by over 1%.

其中${\mathbf{p}}_{i}$和${\lambda }_{i}$分别是RGB像素值$3 \times  3$协方差矩阵的第$i$个特征向量和特征值，${\alpha }_{i}$是上述随机变量。每个${\alpha }_{i}$在特定训练图像的所有像素中只抽取一次，直到该图像再次用于训练时才重新抽取。该方案大致捕捉了自然图像的一个重要特性，即物体身份对照明强度和颜色变化具有不变性。该方案将top-1错误率降低了超过1%。

### 4.2 Dropout

### 4.2 Dropout(随机失活)

Combining the predictions of many different models is a very successful way to reduce test errors $\left\lbrack  {1,3}\right\rbrack$ , but it appears to be too expensive for big neural networks that already take several days to train. There is, however, a very efficient version of model combination that only costs about a factor of two during training. The recently-introduced technique, called "dropout" [10], consists of setting to zero the output of each hidden neuron with probability 0.5 . The neurons which are "dropped out" in this way do not contribute to the forward pass and do not participate in back-propagation. So every time an input is presented, the neural network samples a different architecture, but all these architectures share weights. This technique reduces complex co-adaptations of neurons, since a neuron cannot rely on the presence of particular other neurons. It is, therefore, forced to learn more robust features that are useful in conjunction with many different random subsets of the other neurons. At test time, we use all the neurons but multiply their outputs by 0.5 , which is a reasonable approximation to taking the geometric mean of the predictive distributions produced by the exponentially-many dropout networks.

结合多个不同模型的预测是减少测试误差的非常有效的方法$\left\lbrack  {1,3}\right\rbrack$，但对于已经需要数天训练的大型神经网络来说，似乎代价过高。然而，有一种非常高效的模型组合方法，在训练时仅增加约两倍的计算量。最近提出的技术称为“dropout”[10]，其核心是以0.5的概率将每个隐藏神经元的输出置零。被“失活”的神经元不参与前向传播，也不参与反向传播。因此，每次输入时，神经网络都会采样一个不同的结构，但所有这些结构共享权重。该技术减少了神经元之间复杂的共适应关系，因为神经元不能依赖特定其他神经元的存在。因此，它被迫学习更鲁棒的特征，这些特征在与许多不同随机子集的其他神经元结合时都有效。测试时，我们使用所有神经元，但将它们的输出乘以0.5，这合理地近似了指数级多个dropout网络预测分布的几何平均。

We use dropout in the first two fully-connected layers of Figure 2. Without dropout, our network exhibits substantial overfitting. Dropout roughly doubles the number of iterations required to converge.

我们在图2的前两个全连接层中使用了dropout。没有dropout时，我们的网络表现出明显的过拟合。dropout大致使收敛所需的迭代次数翻倍。

## 5 Details of learning

## 5 学习细节

![bo_d1c3mmbef24c73d2ojqg_5_1013_1250_472_190_0.jpg](images/bo_d1c3mmbef24c73d2ojqg_5_1013_1250_472_190_0.jpg)

Figure 3: 96 convolutional kernels of size ${11} \times  {11} \times  3$ learned by the first convolutional layer on the ${224} \times  {224} \times  3$ input images. The top 48 kernels were learned on GPU 1 while the bottom 48 kernels were learned on GPU 2. See Section 6.1 for details.

图3:第一卷积层在${224} \times  {224} \times  3$输入图像上学习到的96个大小为${11} \times  {11} \times  3$的卷积核。上方48个卷积核是在GPU 1上学习的，下方48个卷积核是在GPU 2上学习的。详情见第6.1节。

We trained our models using stochastic gradient descent with a batch size of 128 examples, momentum of 0.9, and weight decay of 0.0005 . We found that this small amount of weight decay was important for the model to learn. In other words, weight decay here is not merely a regularizer: it reduces the model's training error. The update rule for weight $w$ was

我们使用批量大小为128的随机梯度下降训练模型，动量为0.9，权重衰减为0.0005。我们发现这小量的权重衰减对模型学习非常重要。换言之，这里的权重衰减不仅仅是正则化器:它降低了模型的训练误差。权重$w$的更新规则为

$$
{v}_{i + 1} \mathrel{\text{:=}} {0.9} \cdot  {v}_{i} - {0.0005} \cdot  \epsilon  \cdot  {w}_{i} - \epsilon  \cdot  {\left\langle  {\left. \frac{\partial L}{\partial w}\right| }_{{w}_{i}}\right\rangle  }_{{D}_{i}}
$$

$$
{w}_{i + 1} \mathrel{\text{:=}} {w}_{i} + {v}_{i + 1}
$$

where $i$ is the iteration index, $v$ is the momentum variable, $\epsilon$ is the learning rate, and ${\left\langle  {\left. \frac{\partial L}{\partial w}\right| }_{{w}_{i}}\right\rangle  }_{{D}_{i}}$ is the average over the $i$ th batch ${D}_{i}$ of the derivative of the objective with respect to $w$ , evaluated at ${w}_{i}$ .

其中$i$是迭代索引，$v$是动量变量，$\epsilon$是学习率，${\left\langle  {\left. \frac{\partial L}{\partial w}\right| }_{{w}_{i}}\right\rangle  }_{{D}_{i}}$是第$i$批次中目标函数关于$w$的导数的平均值，计算于${w}_{i}$处。

We initialized the weights in each layer from a zero-mean Gaussian distribution with standard deviation 0.01 . We initialized the neuron biases in the second, fourth, and fifth convolutional layers, as well as in the fully-connected hidden layers, with the constant 1 . This initialization accelerates the early stages of learning by providing the ReLUs with positive inputs. We initialized the neuron biases in the remaining layers with the constant 0 .

我们将每层的权重初始化为均值为零、标准差为0.01的高斯分布。我们将第二、第四和第五卷积层以及全连接隐藏层的神经元偏置初始化为常数1。此初始化通过为ReLU提供正输入，加速了学习的早期阶段。其余层的神经元偏置初始化为常数0。

We used an equal learning rate for all layers, which we adjusted manually throughout training. The heuristic which we followed was to divide the learning rate by 10 when the validation error rate stopped improving with the current learning rate. The learning rate was initialized at 0.01 and reduced three times prior to termination. We trained the network for roughly 90 cycles through the training set of 1.2 million images, which took five to six days on two NVIDIA GTX 580 3GB GPUs.

我们对所有层使用相同的学习率，并在训练过程中手动调整。我们遵循的启发式方法是，当验证误差率在当前学习率下不再改善时，将学习率除以10。学习率初始为0.01，训练过程中共降低三次后终止。我们对包含120万张图像的训练集进行了约90个周期的训练，耗时五到六天，使用两块NVIDIA GTX 580 3GB GPU。

## 6 Results

## 6 结果

Our results on ILSVRC-2010 are summarized in Table 1. Our network achieves top-1 and top-5 test set error rates of $\mathbf{{37.5}\% }$ and $\mathbf{{17.0}}{\% }^{5}$ . The best performance achieved during the ILSVRC- 2010 competition was ${47.1}\%$ and ${28.2}\%$ with an approach that averages the predictions produced from six sparse-coding models trained on different features [2], and since then the best published results are 45.7% and 25.7% with an approach that averages the predictions of two classifiers trained on Fisher Vectors (FVs) computed from two types of densely-sampled features [24].

我们在ILSVRC-2010上的结果总结于表1。我们的网络在测试集上实现了$\mathbf{{37.5}\% }$的top-1错误率和$\mathbf{{17.0}}{\% }^{5}$的top-5错误率。ILSVRC-2010竞赛期间取得的最佳表现是${47.1}\%$和${28.2}\%$，该方法通过对六个基于不同特征训练的稀疏编码模型(sparse-coding models)预测结果进行平均[2]。此后，最佳公开结果为45.7%和25.7%，该方法对两个基于两种密集采样特征计算的Fisher向量(Fisher Vectors, FVs)训练的分类器预测结果进行平均[24]。

We also entered our model in the ILSVRC-2012 competition and report our results in Table 2. Since the ILSVRC-2012 test set labels are not publicly available, we cannot report test error rates for all the models that we tried. In the remainder of this paragraph, we use validation and test error rates interchangeably because in our experience they do not differ by more than 0.1% (see Table 2). The CNN described in this paper achieves a top-5 error rate of ${18.2}\%$ . Averaging the predictions of five similar CNNs gives an error rate of ${16.4}\%$ . Training one CNN, with an extra sixth convolutional layer over the last pooling layer, to classify the entire ImageNet Fall 2011 release (15M images, 22K categories), and then "fine-tuning" it on ILSVRC-2012 gives an error rate of 16.6%. Averaging the predictions of two CNNs that were pre-trained on the entire Fall 2011 release with the aforementioned five CNNs gives an error rate of 15.3%. The second-best contest entry achieved an error rate of ${26.2}\%$ with an approach that averages the predictions of several classifiers trained on FVs computed from different types of densely-sampled features [7].

我们还将模型提交至ILSVRC-2012竞赛，结果见表2。由于ILSVRC-2012测试集标签未公开，我们无法报告所有尝试模型的测试错误率。以下段落中，验证集和测试集错误率可互换使用，因为根据我们的经验，两者差异不超过0.1%(见表2)。本文描述的卷积神经网络(CNN)实现了${18.2}\%$的top-5错误率。对五个类似CNN的预测结果取平均，错误率为${16.4}\%$。训练一个在最后池化层上增加第六个卷积层的CNN，用于分类整个ImageNet 2011年秋季发布的数据集(1500万张图像，22000个类别)，然后在ILSVRC-2012上进行“微调”，错误率为16.6%。将两个在整个2011年秋季发布数据集上预训练的CNN与上述五个CNN的预测结果平均，错误率为15.3%。第二名参赛作品采用对多个基于不同密集采样特征计算的Fisher向量训练的分类器预测结果进行平均的方法，错误率为${26.2}\%$[7]。

<table><tr><td>Model</td><td>Top-1</td><td>Top-5</td></tr><tr><td>Sparse coding [2]</td><td>47.1%</td><td>28.2%</td></tr><tr><td>SIFT + FVs [24]</td><td>45.7%</td><td>25.7%</td></tr><tr><td>CNN</td><td>37.5%</td><td>17.0%</td></tr></table>

<table><tbody><tr><td>模型</td><td>Top-1</td><td>Top-5</td></tr><tr><td>稀疏编码 [2]</td><td>47.1%</td><td>28.2%</td></tr><tr><td>SIFT + FVs [24]</td><td>45.7%</td><td>25.7%</td></tr><tr><td>卷积神经网络(CNN)</td><td>37.5%</td><td>17.0%</td></tr></tbody></table>

Table 1: Comparison of results on ILSVRC- 2010 test set. In italics are best results achieved by others.

表1:ILSVRC-2010测试集结果比较。斜体字为其他人取得的最佳结果。

Finally, we also report our error rates on the Fall 2009 version of ImageNet with 10,184 categories and 8.9 million images. On this dataset we follow the convention in the literature of using half of the images for training and half for testing. Since there is no established test set, our split necessarily differs from the splits used by previous authors, but this does not affect the results appreciably. Our top-1 and top-5 error rates on this dataset are ${67.4}\%$ and 40.9%, attained by the net described above but with an additional, sixth convolutional layer over the last pooling layer. The best published results on this dataset are 78.1% and 60.9% [19].

最后，我们还报告了在2009年秋季版本的ImageNet(包含10,184个类别和890万张图像)上的错误率。在该数据集上，我们遵循文献中的惯例，使用一半图像进行训练，另一半进行测试。由于没有既定的测试集，我们的划分必然与之前作者使用的划分不同，但这对结果影响不大。我们在该数据集上的top-1和top-5错误率分别为${67.4}\%$和40.9%，该结果由上述网络实现，但在最后的池化层上增加了第六个卷积层。该数据集上已发表的最佳结果为78.1%和60.9%[19]。

<table><tr><td>Model</td><td>Top-1 (val)</td><td>Top-5 (val)</td><td>Top-5 (test)</td></tr><tr><td>SIFT + FVs [7]</td><td>-</td><td>-</td><td>26.2%</td></tr><tr><td>1 CNN</td><td>40.7%</td><td>18.2%</td><td>-</td></tr><tr><td>5 CNNs</td><td>38.1%</td><td>16.4%</td><td>16.4%</td></tr><tr><td>1 CNN*</td><td>39.0%</td><td>16.6%</td><td>-</td></tr><tr><td>7 CNNs*</td><td>36.7%</td><td>15.4%</td><td>15.3%</td></tr></table>

<table><tbody><tr><td>模型</td><td>Top-1(验证)</td><td>Top-5(验证)</td><td>Top-5(测试)</td></tr><tr><td>SIFT + FVs [7]</td><td>-</td><td>-</td><td>26.2%</td></tr><tr><td>1 个卷积神经网络(CNN)</td><td>40.7%</td><td>18.2%</td><td>-</td></tr><tr><td>5 个卷积神经网络(CNN)</td><td>38.1%</td><td>16.4%</td><td>16.4%</td></tr><tr><td>1 个卷积神经网络(CNN)*</td><td>39.0%</td><td>16.6%</td><td>-</td></tr><tr><td>7 个卷积神经网络(CNN)*</td><td>36.7%</td><td>15.4%</td><td>15.3%</td></tr></tbody></table>

Table 2: Comparison of error rates on ILSVRC-2012 validation and test sets. In italics are best results achieved by others. Models with an asterisk* were "pre-trained" to classify the entire ImageNet 2011 Fall release. See Section 6 for details.

表2:ILSVRC-2012验证集和测试集上的错误率比较。斜体字为其他人取得的最佳结果。带星号*的模型是“预训练”以分类整个ImageNet 2011秋季版本。详情见第6节。

### 6.1 Qualitative Evaluations

### 6.1 定性评估

Figure 3 shows the convolutional kernels learned by the network's two data-connected layers. The network has learned a variety of frequency- and orientation-selective kernels, as well as various colored blobs. Notice the specialization exhibited by the two GPUs, a result of the restricted connectivity described in Section 3.5. The kernels on GPU 1 are largely color-agnostic, while the kernels on on GPU 2 are largely color-specific. This kind of specialization occurs during every run and is independent of any particular random weight initialization (modulo a renumbering of the GPUs). In the left panel of Figure 4 we qualitatively assess what the network has learned by computing its top-5 predictions on eight test images. Notice that even off-center objects, such as the mite in the top-left, can be recognized by the net. Most of the top-5 labels appear reasonable. For example, only other types of cat are considered plausible labels for the leopard. In some cases (grille, cherry) there is genuine ambiguity about the intended focus of the photograph.

图3展示了网络两个数据连接层学习到的卷积核。网络学习了多种频率和方向选择性的卷积核，以及各种彩色斑点。注意两个GPU表现出的专门化，这是第3.5节中描述的受限连接性的结果。GPU 1上的卷积核大多对颜色不敏感，而GPU 2上的卷积核则大多对颜色敏感。这种专门化在每次运行中都会出现，与特定的随机权重初始化无关(仅GPU编号可能不同)。图4左侧面板通过计算网络对八张测试图像的前五预测，定性评估网络所学内容。注意即使是偏离中心的物体，如左上角的螨虫，网络也能识别。大多数前五标签看起来合理。例如，只有其他类型的猫被认为是豹的合理标签。在某些情况下(格栅、樱桃)，对照片的焦点存在真正的歧义。

---

${}^{5}$ The error rates without averaging predictions over ten patches as described in Section 4.1 are 39.0% and 18.3%.

${}^{5}$ 未按照第4.1节描述对十个补丁的预测进行平均时的错误率分别为39.0%和18.3%。

---

![bo_d1c3mmbef24c73d2ojqg_7_312_231_1172_457_0.jpg](images/bo_d1c3mmbef24c73d2ojqg_7_312_231_1172_457_0.jpg)

Figure 4: (Left) Eight ILSVRC-2010 test images and the five labels considered most probable by our model. The correct label is written under each image, and the probability assigned to the correct label is also shown with a red bar (if it happens to be in the top 5). (Right) Five ILSVRC-2010 test images in the first column. The remaining columns show the six training images that produce feature vectors in the last hidden layer with the smallest Euclidean distance from the feature vector for the test image.

图4:(左)八张ILSVRC-2010测试图像及模型认为最可能的五个标签。每张图像下方写有正确标签，且正确标签的概率用红色条表示(如果它在前五名内)。(右)第一列为五张ILSVRC-2010测试图像。其余列显示六张训练图像，这些训练图像在最后隐藏层的特征向量与测试图像的特征向量欧氏距离最小。

Another way to probe the network's visual knowledge is to consider the feature activations induced by an image at the last, 4096-dimensional hidden layer. If two images produce feature activation vectors with a small Euclidean separation, we can say that the higher levels of the neural network consider them to be similar. Figure 4 shows five images from the test set and the six images from the training set that are most similar to each of them according to this measure. Notice that at the pixel level, the retrieved training images are generally not close in L2 to the query images in the first column. For example, the retrieved dogs and elephants appear in a variety of poses. We present the results for many more test images in the supplementary material.

另一种探查网络视觉知识的方法是考虑图像在最后一个4096维隐藏层激活的特征。如果两张图像产生的特征激活向量欧氏距离较小，我们可以说神经网络的高层认为它们相似。图4展示了测试集中五张图像及根据此度量与它们最相似的六张训练图像。注意在像素层面，检索到的训练图像通常与第一列的查询图像在L2距离上并不接近。例如，检索到的狗和大象呈现多种姿态。更多测试图像的结果见补充材料。

Computing similarity by using Euclidean distance between two 4096-dimensional, real-valued vectors is inefficient, but it could be made efficient by training an auto-encoder to compress these vectors to short binary codes. This should produce a much better image retrieval method than applying auto-encoders to the raw pixels [14], which does not make use of image labels and hence has a tendency to retrieve images with similar patterns of edges, whether or not they are semantically similar.

通过计算两个4096维实值向量的欧氏距离来衡量相似性效率较低，但可以通过训练自编码器将这些向量压缩为短二进制码来提高效率。这应当比直接对原始像素应用自编码器[14]产生更好的图像检索方法，后者未利用图像标签，因此倾向于检索具有相似边缘模式的图像，无论它们是否语义相似。

## 7 Discussion

## 7 讨论

Our results show that a large, deep convolutional neural network is capable of achieving record-breaking results on a highly challenging dataset using purely supervised learning. It is notable that our network's performance degrades if a single convolutional layer is removed. For example, removing any of the middle layers results in a loss of about $2\%$ for the top-1 performance of the network. So the depth really is important for achieving our results.

我们的结果表明，一个大型深度卷积神经网络能够通过纯监督学习，在极具挑战性的数据集上取得破纪录的成绩。值得注意的是，如果移除任一卷积层，网络性能会下降。例如，移除任何中间层都会导致网络top-1性能下降约$2\%$。因此，深度对于实现我们的结果确实至关重要。

To simplify our experiments, we did not use any unsupervised pre-training even though we expect that it will help, especially if we obtain enough computational power to significantly increase the size of the network without obtaining a corresponding increase in the amount of labeled data. Thus far, our results have improved as we have made our network larger and trained it longer but we still have many orders of magnitude to go in order to match the infero-temporal pathway of the human visual system. Ultimately we would like to use very large and deep convolutional nets on video sequences where the temporal structure provides very helpful information that is missing or far less obvious in static images. References

为简化实验，我们未使用任何无监督预训练，尽管我们预计这会有所帮助，尤其是在获得足够计算能力以显著扩大网络规模但标注数据量未相应增加的情况下。迄今为止，随着网络规模的增大和训练时间的延长，我们的结果不断提升，但要达到人类视觉系统下颞通路的水平，我们仍有多个数量级的差距。最终，我们希望在视频序列上使用非常大且深的卷积网络，其中时间结构提供了静态图像中缺失或不明显的有用信息。参考文献

[1] R.M. Bell and Y. Koren. Lessons from the netflix prize challenge. ACM SIGKDD Explorations Newsletter, 9(2):75-79, 2007.

[1] R.M. Bell 和 Y. Koren. Netflix奖挑战的经验教训。ACM SIGKDD探索通讯，9(2):75-79, 2007。

[2] A. Berg, J. Deng, and L. Fei-Fei. Large scale visual recognition challenge 2010. www.image-net.org/challenges. 2010.

[2] A. Berg, J. Deng 和 L. Fei-Fei. 大规模视觉识别挑战2010。www.image-net.org/challenges. 2010。

[3] L. Breiman. Random forests. Machine learning, 45(1):5-32, 2001.

[3] L. Breiman. 随机森林。机器学习，45(1):5-32, 2001。

[4] D. Cireşan, U. Meier, and J. Schmidhuber. Multi-column deep neural networks for image classification. Arxiv preprint arXiv:1202.2745, 2012.

[4] D. Cireşan, U. Meier, 和 J. Schmidhuber. 用于图像分类的多列深度神经网络。Arxiv预印本 arXiv:1202.2745, 2012。

[5] D.C. Cireşan, U. Meier, J. Masci, L.M. Gambardella, and J. Schmidhuber. High-performance neural networks for visual object classification. Arxiv preprint arXiv:1102.0183, 2011.

[5] D.C. Cireşan, U. Meier, J. Masci, L.M. Gambardella, 和 J. Schmidhuber. 用于视觉对象分类的高性能神经网络。Arxiv预印本 arXiv:1102.0183, 2011。

[6] J. Deng, W. Dong, R. Socher, L.-J. Li, K. Li, and L. Fei-Fei. ImageNet: A Large-Scale Hierarchical Image Database. In CVPR09, 2009.

[6] J. Deng, W. Dong, R. Socher, L.-J. Li, K. Li, 和 L. Fei-Fei. ImageNet(图像网络):一个大规模分层图像数据库。发表于CVPR09, 2009。

[7] J. Deng, A. Berg, S. Satheesh, H. Su, A. Khosla, and L. Fei-Fei. ILSVRC-2012, 2012. URL http://www.image-net.org/challenges/LSVRC/2012/.

[7] J. Deng, A. Berg, S. Satheesh, H. Su, A. Khosla, 和 L. Fei-Fei. ILSVRC-2012, 2012。网址 http://www.image-net.org/challenges/LSVRC/2012/。

[8] L. Fei-Fei, R. Fergus, and P. Perona. Learning generative visual models from few training examples: An incremental bayesian approach tested on 101 object categories. Computer Vision and Image Understanding, 106(1):59-70, 2007.

[8] L. Fei-Fei, R. Fergus, 和 P. Perona. 从少量训练样本学习生成视觉模型:一种增量贝叶斯方法，在101个对象类别上测试。计算机视觉与图像理解, 106(1):59-70, 2007。

[9] G. Griffin, A. Holub, and P. Perona. Caltech-256 object category dataset. Technical Report 7694, California Institute of Technology, 2007. URL http://authors.library.caltech.edu/7694.

[9] G. Griffin, A. Holub, 和 P. Perona. Caltech-256对象类别数据集。加州理工学院技术报告7694, 2007。网址 http://authors.library.caltech.edu/7694。

[10] G.E. Hinton, N. Srivastava, A. Krizhevsky, I. Sutskever, and R.R. Salakhutdinov. Improving neural networks by preventing co-adaptation of feature detectors. arXiv preprint arXiv:1207.0580, 2012.

[10] G.E. Hinton, N. Srivastava, A. Krizhevsky, I. Sutskever, 和 R.R. Salakhutdinov. 通过防止特征检测器的协同适应来改进神经网络。arXiv预印本 arXiv:1207.0580, 2012。

[11] K. Jarrett, K. Kavukcuoglu, M. A. Ranzato, and Y. LeCun. What is the best multi-stage architecture for object recognition? In International Conference on Computer Vision, pages 2146-2153. IEEE, 2009.

[11] K. Jarrett, K. Kavukcuoglu, M. A. Ranzato, 和 Y. LeCun. 物体识别的最佳多阶段架构是什么？发表于国际计算机视觉会议, 页2146-2153。IEEE, 2009。

[12] A. Krizhevsky. Learning multiple layers of features from tiny images. Master's thesis, Department of Computer Science, University of Toronto, 2009.

[12] A. Krizhevsky. 从微小图像中学习多层特征。多伦多大学计算机科学系硕士论文, 2009。

[13] A. Krizhevsky. Convolutional deep belief networks on cifar-10. Unpublished manuscript, 2010.

[13] A. Krizhevsky. CIFAR-10上的卷积深度置信网络。未发表手稿, 2010。

[14] A. Krizhevsky and G.E. Hinton. Using very deep autoencoders for content-based image retrieval. In ESANN, 2011.

[14] A. Krizhevsky 和 G.E. Hinton. 使用非常深的自编码器进行基于内容的图像检索。发表于ESANN, 2011。

[15] Y. Le Cun, B. Boser, J.S. Denker, D. Henderson, R.E. Howard, W. Hubbard, L.D. Jackel, et al. Handwritten digit recognition with a back-propagation network. In Advances in neural information processing systems, 1990.

[15] Y. Le Cun, B. Boser, J.S. Denker, D. Henderson, R.E. Howard, W. Hubbard, L.D. Jackel 等. 使用反向传播网络进行手写数字识别。发表于神经信息处理系统进展, 1990。

[16] Y. LeCun, F.J. Huang, and L. Bottou. Learning methods for generic object recognition with invariance to pose and lighting. In Computer Vision and Pattern Recognition, 2004. CVPR 2004. Proceedings of the 2004 IEEE Computer Society Conference on, volume 2, pages II-97. IEEE, 2004.

[16] Y. LeCun, F.J. Huang, 和 L. Bottou. 具有姿态和光照不变性的通用物体识别学习方法。发表于计算机视觉与模式识别会议, 2004。CVPR 2004。IEEE计算机学会会议论文集，第2卷，页II-97。IEEE, 2004。

[17] Y. LeCun, K. Kavukcuoglu, and C. Farabet. Convolutional networks and applications in vision. In Circuits and Systems (ISCAS), Proceedings of 2010 IEEE International Symposium on, pages 253-256. IEEE, 2010.

[17] Y. LeCun, K. Kavukcuoglu, 和 C. Farabet. 卷积网络及其在视觉中的应用。发表于2010年IEEE国际电路与系统研讨会(ISCAS)论文集，页253-256。IEEE, 2010。

[18] H. Lee, R. Grosse, R. Ranganath, and A.Y. Ng. Convolutional deep belief networks for scalable unsupervised learning of hierarchical representations. In Proceedings of the 26th Annual International Conference on Machine Learning, pages 609-616. ACM, 2009.

[18] H. Lee, R. Grosse, R. Ranganath, 和 A.Y. Ng. 用于可扩展无监督层次表示学习的卷积深度置信网络。发表于第26届国际机器学习大会论文集，页609-616。ACM, 2009。

[19] T. Mensink, J. Verbeek, F. Perronnin, and G. Csurka. Metric Learning for Large Scale Image Classification: Generalizing to New Classes at Near-Zero Cost. In ECCV - European Conference on Computer Vision, Florence, Italy, October 2012.

[19] T. Mensink, J. Verbeek, F. Perronnin, 和 G. Csurka. 大规模图像分类的度量学习:以近零成本推广到新类别。发表于ECCV - 欧洲计算机视觉大会，意大利佛罗伦萨，2012年10月。

[20] V. Nair and G. E. Hinton. Rectified linear units improve restricted boltzmann machines. In Proc. 27th International Conference on Machine Learning, 2010.

[20] V. Nair 和 G. E. Hinton. 修正线性单元(Rectified Linear Units)提升受限玻尔兹曼机(Restricted Boltzmann Machines)的性能。发表于第27届国际机器学习大会论文集，2010年。

[21] N. Pinto, D.D. Cox, and J.J. DiCarlo. Why is real-world visual object recognition hard? PLoS computational biology, 4(1):e27, 2008.

[21] N. Pinto, D.D. Cox 和 J.J. DiCarlo. 为什么现实世界中的视觉物体识别如此困难？《PLoS计算生物学》，4(1):e27，2008年。

[22] N. Pinto, D. Doukhan, J.J. DiCarlo, and D.D. Cox. A high-throughput screening approach to discovering good forms of biologically inspired visual representation. PLoS computational biology, 5(11):e1000579, 2009.

[22] N. Pinto, D. Doukhan, J.J. DiCarlo 和 D.D. Cox. 一种高通量筛选方法用于发现良好的生物启发视觉表示形式。《PLoS计算生物学》，5(11):e1000579，2009年。

[23] B.C. Russell, A. Torralba, K.P. Murphy, and W.T. Freeman. Labelme: a database and web-based tool for image annotation. International journal of computer vision, 77(1):157-173, 2008.

[23] B.C. Russell, A. Torralba, K.P. Murphy 和 W.T. Freeman. Labelme:一个用于图像标注的数据库及基于网络的工具。《国际计算机视觉杂志》，77(1):157-173，2008年。

[24] J. Sánchez and F. Perronnin. High-dimensional signature compression for large-scale image classification. In Computer Vision and Pattern Recognition (CVPR), 2011 IEEE Conference on, pages 1665-1672. IEEE, 2011.

[24] J. Sánchez 和 F. Perronnin. 用于大规模图像分类的高维特征压缩。发表于2011年IEEE计算机视觉与模式识别会议(CVPR)，页1665-1672。IEEE，2011年。

[25] P.Y. Simard, D. Steinkraus, and J.C. Platt. Best practices for convolutional neural networks applied to visual document analysis. In Proceedings of the Seventh International Conference on Document Analysis and Recognition, volume 2, pages 958-962, 2003.

[25] P.Y. Simard, D. Steinkraus 和 J.C. Platt. 应用于视觉文档分析的卷积神经网络最佳实践。发表于第七届国际文档分析与识别会议论文集，第2卷，页958-962，2003年。

[26] S.C. Turaga, J.F. Murray, V. Jain, F. Roth, M. Helmstaedter, K. Briggman, W. Denk, and H.S. Seung. Convolutional networks can learn to generate affinity graphs for image segmentation. Neural Computation, 22(2):511-538, 2010.

[26] S.C. Turaga, J.F. Murray, V. Jain, F. Roth, M. Helmstaedter, K. Briggman, W. Denk 和 H.S. Seung. 卷积网络能够学习生成用于图像分割的亲和图。神经计算，22(2):511-538，2010年。