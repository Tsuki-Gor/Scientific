# Logic Tensor Networks: Deep Learning and Logical Reasoning from Data and Knowledge*

# 逻辑张量网络:基于数据和知识的深度学习与逻辑推理*

Luciano Serafini ${}^{1}$ and Artur d’Avila Garcez ${}^{2}$

卢西亚诺·塞拉菲尼 ${}^{1}$ 和阿图尔·达维拉·加尔塞斯 ${}^{2}$

${}^{1}$ Fondazione Bruno Kessler, Trento, Italy, serafini@fbk.eu ${}^{2}$ City University London, UK, a.garcez@city.ac.uk

${}^{1}$ 意大利特伦托布鲁诺·凯斯勒基金会，serafini@fbk.eu ${}^{2}$ 英国伦敦城市大学，a.garcez@city.ac.uk

Abstract. We propose Logic Tensor Networks: a uniform framework for integrating automatic learning and reasoning. A logic formalism called Real Logic is defined on a first-order language whereby formulas have truth-value in the interval $\left\lbrack  {0,1}\right\rbrack$ and semantics defined concretely on the domain of real numbers. Logical constants are interpreted as feature vectors of real numbers. Real Logic promotes a well-founded integration of deductive reasoning on a knowledge-base and efficient data-driven relational machine learning. We show how Real Logic can be implemented in deep Tensor Neural Networks with the use of Google's TEN-SORFLOW ${}^{\mathrm{{TM}}}$ primitives. The paper concludes with experiments applying Logic Tensor Networks on a simple but representative example of knowledge completion.

摘要。我们提出了逻辑张量网络:一个用于集成自动学习和推理的统一框架。一种称为实逻辑(Real Logic)的逻辑形式体系是在一阶语言上定义的，由此公式在区间 $\left\lbrack  {0,1}\right\rbrack$ 内具有真值，并且语义在实数域上具体定义。逻辑常量被解释为实数的特征向量。实逻辑促进了基于知识库的演绎推理与高效的数据驱动关系型机器学习的合理集成。我们展示了如何使用谷歌的张量流(TENSORFLOW)${}^{\mathrm{{TM}}}$ 原语在深度张量神经网络中实现实逻辑。本文最后通过在一个简单但具有代表性的知识补全示例上应用逻辑张量网络进行了实验。

Keywords: Knowledge Representation, Relational Learning, Tensor Networks, Neural-Symbolic Computation, Data-driven Knowledge Completion.

关键词:知识表示、关系型学习、张量网络、神经符号计算、数据驱动的知识补全。

## 1 Introduction

## 1 引言

The recent availability of large-scale data combining multiple data modalities, such as image, text, audio and sensor data, has opened up various research and commercial opportunities, underpinned by machine learning methods and techniques [5,12, 17, 18]. In particular, recent work in machine learning has sought to combine logical services, such as knowledge completion, approximate inference, and goal-directed reasoning with data-driven statistical and neural network-based approaches. We argue that there are great possibilities for improving the current state of the art in machine learning and artificial intelligence (AI) thought the principled combination of knowledge representation, reasoning and learning. Guha's recent position paper [15] is a case in point, as it advocates a new model theory for real-valued numbers. In this paper, we take inspiration from such recent work in AI, but also less recent work in the area of neural-symbolic integration $\left\lbrack  {8,{10},{11}}\right\rbrack$ and in semantic attachment and symbol grounding [4] to achieve a vector-based representation which can be shown adequate for integrating machine learning and reasoning in a principled way.

最近，结合多种数据模态(如图像、文本、音频和传感器数据)的大规模数据的可用性，在机器学习方法和技术的支持下，开辟了各种研究和商业机会 [5,12, 17, 18]。特别是，机器学习领域的近期工作试图将逻辑服务(如知识补全、近似推理和目标导向推理)与数据驱动的统计和基于神经网络的方法相结合。我们认为，通过知识表示、推理和学习的原则性结合，在改进机器学习和人工智能(AI)的当前技术水平方面存在巨大的可能性。古哈最近的立场文件 [15] 就是一个很好的例子，因为它倡导了一种针对实数值的新模型理论。在本文中，我们从人工智能领域的这些近期工作中获得灵感，同时也借鉴了神经符号集成 $\left\lbrack  {8,{10},{11}}\right\rbrack$ 以及语义附着和符号接地 [4] 领域不太近期的工作，以实现一种基于向量的表示，这种表示可以被证明足以以原则性的方式集成机器学习和推理。

---

* The first author acknowledges the Mobility Program of FBK, for supporting a long term visit at City University London. He also acknowledges NVIDIA Corporation for supporting this research with the donation of a GPU.

* 第一作者感谢布鲁诺·凯斯勒基金会的流动计划，该计划支持他在伦敦城市大学进行长期访问。他还感谢英伟达公司捐赠 GPU 支持这项研究。

---

This paper proposes a framework called Logic Tensor Networks (LTN) which integrates learning based on tensor networks [26] with reasoning using first-order many-valued logic [6], all implemented in TENSORFLOW ${}^{\mathrm{{TM}}}$ [13]. This enables, for the first time, a range of knowledge-based tasks using rich knowledge representation in first-order logic (FOL) to be combined with efficient data-driven machine learning based on the manipulation of real-valued vectors ${}^{1}$ . Given data available in the form of real-valued vectors, logical soft and hard constraints and relations which apply to certain subsets of the vectors can be specified compactly in first-order logic. Reasoning about such constraints can help improve learning, and learning from new data can revise such constraints thus modifying reasoning. An adequate vector-based representation of the logic, first proposed in this paper, enables the above integration of learning and reasoning, as detailed in what follows.

本文提出了一个名为逻辑张量网络(LTN)的框架，该框架将基于张量网络 [26] 的学习与使用一阶多值逻辑 [6] 的推理相结合，所有这些都在张量流(TENSORFLOW)${}^{\mathrm{{TM}}}$ [13] 中实现。这首次使得一系列使用一阶逻辑(FOL)丰富知识表示的基于知识的任务能够与基于实值向量操作的高效数据驱动机器学习相结合 ${}^{1}$。给定以实值向量形式提供的数据，可以用一阶逻辑简洁地指定适用于向量某些子集的逻辑软约束和硬约束以及关系。对这些约束进行推理有助于改进学习，而从新数据中学习可以修正这些约束，从而改变推理。本文首次提出的一种合适的基于向量的逻辑表示，实现了上述学习和推理的集成，具体细节如下。

We are interested in providing a computationally adequate approach to implementing learning and reasoning [28] in an integrated way within an idealized agent. This agent has to manage knowledge about an unbounded, possibly infinite, set of objects $O = \left\{  {{o}_{1},{o}_{2},\ldots }\right\}$ . Some of the objects are associated with a set of quantitative attributes, represented by an $n$ -tuple of real values $\mathcal{G}\left( {o}_{i}\right)  \in  {\mathbb{R}}^{n}$ , which we call grounding. For example, a person may have a grounding into a 4-tuple containing some numerical representation of the person's name, her height, weight, and number of friends in some social network. Object tuples can participate in a set of relations $\mathcal{R} = \left\{  {{R}_{1},\ldots ,{R}_{k}}\right\}$ , with ${R}_{i} \subseteq  {O}^{\alpha \left( {R}_{i}\right) }$ , where $\alpha \left( {R}_{i}\right)$ denotes the arity of relation ${R}_{i}$ . We presuppose the existence of a latent (unknown) relation between the above numerical properties, i.e. groundings, and partial relational structure $\mathcal{R}$ on $O$ . Starting from this partial knowledge, an agent is required to: (i) infer new knowledge about the relational structure on the objects of $O$ ; (ii) predict the numerical properties or the class of the objects in $O$ .

我们感兴趣的是，在一个理想化的智能体中以集成的方式提供一种计算上可行的方法来实现学习和推理 [28]。这个智能体必须管理关于一组无界的、可能无限的对象 $O = \left\{  {{o}_{1},{o}_{2},\ldots }\right\}$ 的知识。其中一些对象与一组定量属性相关联，这些属性由一个 $n$ 元实值组 $\mathcal{G}\left( {o}_{i}\right)  \in  {\mathbb{R}}^{n}$ 表示，我们称之为基础表示(grounding)。例如，一个人可能有一个 4 元组的基础表示，其中包含该人的姓名、身高、体重以及在某个社交网络中的朋友数量的数值表示。对象元组可以参与一组关系 $\mathcal{R} = \left\{  {{R}_{1},\ldots ,{R}_{k}}\right\}$，其中 ${R}_{i} \subseteq  {O}^{\alpha \left( {R}_{i}\right) }$，这里 $\alpha \left( {R}_{i}\right)$ 表示关系 ${R}_{i}$ 的元数。我们假设上述数值属性(即基础表示)与 $O$ 上的部分关系结构 $\mathcal{R}$ 之间存在一种潜在(未知)的关系。基于这种部分知识，智能体需要:(i)推断关于 $O$ 中对象的关系结构的新知识；(ii)预测 $O$ 中对象的数值属性或类别。

Classes and relations are not normally independent. For example, it may be the case that if an object $x$ is of class $C, C\left( x\right)$ , and it is related to another object $y$ through relation $R\left( {x, y}\right)$ then this other object $y$ should be in the same class $C\left( y\right)$ . In logic: $\forall x\exists y\left( {\left( {C\left( x\right)  \land  R\left( {x, y}\right) }\right)  \rightarrow  C\left( y\right) }\right)$ . Whether or not $C\left( y\right)$ holds will depend on the application: through reasoning, one may derive $C\left( y\right)$ where otherwise there might not have been evidence of $C\left( y\right)$ from training examples only; through learning, one may need to revise such a conclusion once examples to the contrary become available. The vectorial representation proposed in this paper permits both reasoning and learning as exemplified above and detailed in the next section.

类别和关系通常并非相互独立。例如，可能会出现这样的情况:如果一个对象 $x$ 属于类别 $C, C\left( x\right)$，并且它通过关系 $R\left( {x, y}\right)$ 与另一个对象 $y$ 相关联，那么这个另一个对象 $y$ 应该属于同一类别 $C\left( y\right)$。用逻辑表示为:$\forall x\exists y\left( {\left( {C\left( x\right)  \land  R\left( {x, y}\right) }\right)  \rightarrow  C\left( y\right) }\right)$。$C\left( y\right)$ 是否成立将取决于具体应用:通过推理，人们可能推导出 $C\left( y\right)$，而仅从训练示例中可能没有 $C\left( y\right)$ 的证据；通过学习，一旦有相反的示例出现，可能需要修正这样的结论。本文提出的向量表示法允许进行上述推理和学习，下一节将详细说明。

The above forms of reasoning and learning are integrated in a unifying framework, implemented within tensor networks, and exemplified in relational domains combining data and relational knowledge about the objects. It is expected that, through an adequate integration of numerical properties and relational knowledge, differently from the immediate related literature $\left\lbrack  {9,2,1}\right\rbrack$ , the framework introduced in this paper will be capable of combining in an effective way first-order logical inference on open domains with efficient relational multi-class learning using tensor networks.

上述推理和学习形式在一个统一的框架中进行集成，该框架在张量网络中实现，并在结合对象数据和关系知识的关系领域中进行了示例展示。预计通过对数值属性和关系知识的适当集成，与直接相关的文献 $\left\lbrack  {9,2,1}\right\rbrack$ 不同，本文引入的框架将能够有效地将开放域上的一阶逻辑推理与使用张量网络的高效关系多类别学习相结合。

The main contribution of this paper is two-fold. It introduces a novel framework for the integration of learning and reasoning which can take advantage of the representational power of (multi-valued) first-order logic, and it instantiates the framework using tensor networks into an efficient implementation which shows that the proposed vector-based representation of the logic offers an adequate mapping between symbols and their real-world manifestations, which is appropriate for both rich inference and learning from examples.

本文的主要贡献有两个方面。它引入了一个用于集成学习和推理的新颖框架，该框架可以利用(多值)一阶逻辑的表示能力；并且使用张量网络将该框架实例化为一个高效的实现，这表明所提出的基于向量的逻辑表示法在符号与其现实世界表现之间提供了一种合适的映射，适用于丰富的推理和从示例中学习。

---

${}^{1}$ In practice, FOL reasoning including function symbols is approximated through the usual iterative deepening of clause depth.

${}^{1}$ 在实践中，包括函数符号的一阶逻辑(FOL)推理是通过通常的子句深度迭代加深来近似实现的。

---

The paper is organized as follows. In Section 2, we define Real Logic. In Section 3 , we propose the Learning-as-Inference framework. In Section 4, we instantiate the framework by showing how Real Logic can be implemented in deep Tensor Neural Networks leading to Logic Tensor Networks (LTN). Section 5 contains an example of how LTN handles knowledge completion using (possibly inconsistent) data and knowledge from the well-known smokers and friends experiment. Section 6 concludes the paper and discusses directions for future work.

本文的组织如下。在第 2 节中，我们定义实逻辑(Real Logic)。在第 3 节中，我们提出“学习即推理”(Learning-as-Inference)框架。在第 4 节中，我们通过展示如何在深度张量神经网络中实现实逻辑，从而得到逻辑张量网络(Logic Tensor Networks，LTN)来实例化该框架。第 5 节包含一个示例，展示了 LTN 如何使用(可能不一致的)数据和来自著名的吸烟者与朋友实验的知识来处理知识补全。第 6 节对本文进行总结，并讨论未来的研究方向。

## 2 Real Logic

## 2 实逻辑

We start from a first order language $\mathcal{L}$ , whose signature contains a set $\mathcal{C}$ of constant symbols, a set $\mathcal{F}$ of functional symbols, and a set $\mathcal{P}$ of predicate symbols. The sentences of $\mathcal{L}$ are used to express relational knowledge, e.g. the atomic formula $R\left( {{o}_{1},{o}_{2}}\right)$ states that objects ${o}_{1}$ and ${o}_{2}$ are related to each other through binary relation $R;\forall {xy}.(R\left( {x, y}\right)  \rightarrow$ $R\left( {y, x}\right) )$ states that $R$ is a symmetric relation, where $x$ and $y$ are variables; $\exists y.R\left( {{o}_{1}, y}\right)$ states that there is an (unknown) object which is related to object ${o}_{1}$ through $R$ . For simplicity, without loss of generality, we assume that all logical sentences of $\mathcal{L}$ are in prenex conjunctive, skolemised normal form [16], e.g. a sentence $\forall x\left( {A\left( x\right)  \rightarrow  \exists {yR}\left( {x, y}\right) }\right)$ is transformed into an equivalent clause $\neg A\left( x\right)  \vee  R\left( {x, f\left( x\right) }\right)$ , where $f$ is a new function symbol.

我们从一阶语言$\mathcal{L}$开始，其符号集包含一组常量符号$\mathcal{C}$、一组函数符号$\mathcal{F}$和一组谓词符号$\mathcal{P}$。$\mathcal{L}$的句子用于表达关系知识，例如，原子公式$R\left( {{o}_{1},{o}_{2}}\right)$表示对象${o}_{1}$和${o}_{2}$通过二元关系$R;\forall {xy}.(R\left( {x, y}\right)  \rightarrow$相互关联；$R\left( {y, x}\right) )$表示$R$是一个对称关系，其中$x$和$y$是变量；$\exists y.R\left( {{o}_{1}, y}\right)$表示存在一个(未知的)对象通过$R$与对象${o}_{1}$相关联。为简单起见，不失一般性，我们假设$\mathcal{L}$的所有逻辑句子都采用前束合取斯科伦范式[16]，例如，句子$\forall x\left( {A\left( x\right)  \rightarrow  \exists {yR}\left( {x, y}\right) }\right)$被转换为等价子句$\neg A\left( x\right)  \vee  R\left( {x, f\left( x\right) }\right)$，其中$f$是一个新的函数符号。

As for the semantics of $\mathcal{L}$ , we deviate from the standard abstract semantics of FOL, and we propose a concrete semantics with sentences interpreted as tuples of real numbers. To emphasise the fact that $\mathcal{L}$ is interpreted in a "real" world, we use the term (semantic) grounding, denoted by $\mathcal{G}$ , instead of the more standard interpretation ${}^{2}$ .

至于$\mathcal{L}$的语义，我们偏离了一阶逻辑(FOL)的标准抽象语义，并提出了一种具体语义，将句子解释为实数元组。为了强调$\mathcal{L}$是在“真实”世界中解释的这一事实，我们使用术语(语义)基化(grounding)，用$\mathcal{G}$表示，而不是更标准的解释${}^{2}$。

- $\mathcal{G}$ associates an $n$ -tuple of real numbers $\mathcal{G}\left( t\right)$ to any closed term $t$ of $\mathcal{L}$ ; intuitively $\mathcal{G}\left( t\right)$ is the set of numeric features of the object denoted by $t$ .

- $\mathcal{G}$将一个$n$元实数元组$\mathcal{G}\left( t\right)$与$\mathcal{L}$的任何闭项$t$相关联；直观地说，$\mathcal{G}\left( t\right)$是由$t$表示的对象的数值特征集。

- $\mathcal{G}$ associates a real number in the interval $\left\lbrack  {0,1}\right\rbrack$ to each clause $\phi$ of $\mathcal{L}$ . Intuitively, $\mathcal{G}\left( \phi \right)$ represents one’s confidence in the truth of $\phi$ ; the higher the value, the higher the confidence.

- $\mathcal{G}$将区间$\left\lbrack  {0,1}\right\rbrack$内的一个实数与$\mathcal{L}$的每个子句$\phi$相关联。直观地说，$\mathcal{G}\left( \phi \right)$表示某人对子句$\phi$为真的置信度；值越高，置信度越高。

A grounding is specified only for the elements of the signature of $\mathcal{L}$ . The grounding of terms and clauses is defined inductively, as follows.

仅为$\mathcal{L}$的符号集元素指定基化。项和子句的基化按如下方式归纳定义。

Definition 1. A grounding $\mathcal{G}$ for a first order language $\mathcal{L}$ is a function from the signature of $\mathcal{L}$ to the real numbers that satisfies the following conditions:

定义1. 一阶语言$\mathcal{L}$的基化$\mathcal{G}$是一个从$\mathcal{L}$的符号集到实数的函数，它满足以下条件:

1. $\mathcal{G}\left( c\right)  \in  {\mathbb{R}}^{n}$ for every constant symbol $c \in  \mathcal{C}$ ;

1. 对于每个常量符号$c \in  \mathcal{C}$，有$\mathcal{G}\left( c\right)  \in  {\mathbb{R}}^{n}$；

2. $\mathcal{G}\left( f\right)  \in  {\mathbb{R}}^{n \cdot  \alpha \left( f\right) } \rightarrow  {\mathbb{R}}^{n}$ for every $f \in  \mathcal{F}$ ;

2. 对于每个$f \in  \mathcal{F}$，有$\mathcal{G}\left( f\right)  \in  {\mathbb{R}}^{n \cdot  \alpha \left( f\right) } \rightarrow  {\mathbb{R}}^{n}$；

---

${}^{2}$ In logic, the term "grounding" indicates the operation of replacing the variables of a term/formula with constants. To avoid confusion, we use the term "instantiation" for this.

${}^{2}$在逻辑学中，术语“基化(grounding)”表示用常量替换项/公式中的变量的操作。为避免混淆，我们使用术语“实例化(instantiation)”来表示这一操作。

---

3. $\mathcal{G}\left( P\right)  \in  {\mathbb{R}}^{n \cdot  \alpha \left( R\right) } \rightarrow  \left\lbrack  {0,1}\right\rbrack$ for every $P \in  \mathcal{P}$ ;

3. 对于每个$P \in  \mathcal{P}$，有$\mathcal{G}\left( P\right)  \in  {\mathbb{R}}^{n \cdot  \alpha \left( R\right) } \rightarrow  \left\lbrack  {0,1}\right\rbrack$；

A grounding $\mathcal{G}$ is inductively extended to all the closed terms and clauses, as follows:

一个基化 $\mathcal{G}$ 按如下方式归纳扩展到所有闭项和子句:

$$
\mathcal{G}\left( {f\left( {{t}_{1},\ldots ,{t}_{m}}\right) }\right)  = \mathcal{G}\left( f\right) \left( {\mathcal{G}\left( {t}_{1}\right) ,\ldots ,\mathcal{G}\left( {t}_{m}\right) }\right)
$$

$$
\mathcal{G}\left( {P\left( {{t}_{1},\ldots ,{t}_{m}}\right) }\right)  = \mathcal{G}\left( P\right) \left( {\mathcal{G}\left( {t}_{1}\right) ,\ldots ,\mathcal{G}\left( {t}_{m}\right) }\right)
$$

$$
\mathcal{G}\left( {\neg P\left( {{t}_{1},\ldots ,{t}_{m}}\right) }\right)  = 1 - \mathcal{G}\left( {P\left( {{t}_{1},\ldots ,{t}_{m}}\right) }\right)
$$

$$
\mathcal{G}\left( {{\phi }_{1} \vee  \cdots  \vee  {\phi }_{k}}\right)  = \mu \left( {\mathcal{G}\left( {\phi }_{1}\right) ,\ldots ,\mathcal{G}\left( {\phi }_{k}\right) }\right)
$$

where $\mu$ is an s-norm operator, also known as a t-co-norm operator (i.e. the dual of some t-norm operator). ${}^{3}$

其中 $\mu$ 是一个 s - 范数算子，也称为 t - 余范数算子(即某个 t - 范数算子的对偶)。 ${}^{3}$

Example 1. Suppose that $O = \left\{  {{o}_{1},{o}_{2},{o}_{3}}\right\}$ is a set of documents defined on a finite dictionary $D = \left\{  {{w}_{1},\ldots ,{w}_{n}}\right\}$ of $n$ words. Let $\mathcal{L}$ be the language that contains the binary function symbol $\operatorname{concat}\left( {x, y}\right)$ denoting the document resulting from the concatenation of documents $x$ with $y$ . Let $\mathcal{L}$ contain also the binary predicate ${Sim}$ which is supposed to be true if document $x$ is deemed to be similar to document $y$ . An example of grounding is the one that associates to each document its bag-of-words vector [7]. As a consequence, a natural grounding of the concat function would be the sum of the vectors, and of the Sim predicate, the cosine similarity between the vectors. More formally:

示例 1. 假设 $O = \left\{  {{o}_{1},{o}_{2},{o}_{3}}\right\}$ 是在一个由 $n$ 个单词组成的有限词典 $D = \left\{  {{w}_{1},\ldots ,{w}_{n}}\right\}$ 上定义的一组文档。设 $\mathcal{L}$ 是一种语言，它包含二元函数符号 $\operatorname{concat}\left( {x, y}\right)$，该符号表示将文档 $x$ 与 $y$ 连接后得到的文档。设 $\mathcal{L}$ 还包含二元谓词 ${Sim}$，如果认为文档 $x$ 与文档 $y$ 相似，则该谓词为真。一个基化的例子是将每个文档与其词袋向量关联起来 [7]。因此，concat 函数的自然基化是向量的和，而 Sim 谓词的自然基化是向量之间的余弦相似度。更正式地说:

$- \mathcal{G}\left( {o}_{i}\right)  = \left\langle  {{n}_{{w}_{1}}^{{o}_{i}},\ldots ,{n}_{{w}_{n}}^{{o}_{i}}}\right\rangle$ , where ${n}_{w}^{d}$ is the number of occurrences of word $w$ in document $d$ ;

$- \mathcal{G}\left( {o}_{i}\right)  = \left\langle  {{n}_{{w}_{1}}^{{o}_{i}},\ldots ,{n}_{{w}_{n}}^{{o}_{i}}}\right\rangle$，其中 ${n}_{w}^{d}$ 是单词 $w$ 在文档 $d$ 中出现的次数；

- if $\mathbf{v},\mathbf{u} \in  {\mathbb{R}}^{n},\mathcal{G}\left( \text{concat}\right) \left( {\mathbf{u},\mathbf{v}}\right)  = \mathbf{u} + \mathbf{v}$ ;

- 如果 $\mathbf{v},\mathbf{u} \in  {\mathbb{R}}^{n},\mathcal{G}\left( \text{concat}\right) \left( {\mathbf{u},\mathbf{v}}\right)  = \mathbf{u} + \mathbf{v}$；

- if $\mathbf{v},\mathbf{u} \in  {\mathbb{R}}^{n},\mathcal{G}\left( \operatorname{Sim}\right) \left( {\mathbf{u},\mathbf{v}}\right)  = \frac{\mathbf{u} \cdot  \mathbf{v}}{\parallel \mathbf{u}\parallel \parallel \mathbf{v}\parallel }$ .

- 如果 $\mathbf{v},\mathbf{u} \in  {\mathbb{R}}^{n},\mathcal{G}\left( \operatorname{Sim}\right) \left( {\mathbf{u},\mathbf{v}}\right)  = \frac{\mathbf{u} \cdot  \mathbf{v}}{\parallel \mathbf{u}\parallel \parallel \mathbf{v}\parallel }$。

For instance, if the three documents are ${o}_{1} =$ "John studies logic and plays football", ${o}_{2}$ $=$ "Mary plays football and logic games", ${o}_{3} =$ " John and Mary play football and study logic together", and $W = \{$ John, Mary, and, football, game, logic, play, study, together $\}$ then the following are examples of the grounding of terms, atomic formulas and clauses.

例如，如果三个文档分别是 ${o}_{1} =$ “约翰学习逻辑学并踢足球”， ${o}_{2}$ $=$ “玛丽踢足球并玩逻辑游戏”， ${o}_{3} =$ “约翰和玛丽一起踢足球并学习逻辑学”，并且 $W = \{$ 约翰、玛丽、和、足球、游戏、逻辑、玩、学习、一起 $\}$，那么以下是项、原子公式和子句基化的例子。

$$
\mathcal{G}\left( {o}_{1}\right)  = \langle 1,0,1,1,0,1,1,1,0\rangle
$$

$$
\mathcal{G}\left( {o}_{2}\right)  = \langle 0,1,1,1,1,1,1,0,0\rangle
$$

$$
\mathcal{G}\left( {o}_{3}\right)  = \langle 1,1,2,1,0,1,1,1,1\rangle
$$

$$
\mathcal{G}\left( {\operatorname{concat}\left( {{o}_{1},{o}_{2}}\right) }\right)  = \mathcal{G}\left( {o}_{1}\right)  + \mathcal{G}\left( {o}_{2}\right)  = \langle 1,1,2,2,1,2,2,1,0\rangle
$$

$$
\mathcal{G}\left( {\operatorname{Sim}\left( {\operatorname{concat}\left( {{o}_{1},{o}_{2}}\right) ,{o}_{3}}\right)  = \frac{\mathcal{G}\left( {\operatorname{concat}\left( {{o}_{1},{o}_{2}}\right) }\right)  \cdot  \mathcal{G}\left( {o}_{3}\right) }{\begin{Vmatrix}{\mathcal{G}\left( {\operatorname{concat}\left( {{o}_{1},{o}_{2}}\right) }\right) }\end{Vmatrix} \cdot  \begin{Vmatrix}{\mathcal{G}\left( {o}_{3}\right) }\end{Vmatrix} \cdot  }\frac{13}{14.83} \approx  {0.88}}\right.
$$

$$
\mathcal{G}\left( {\operatorname{Sim}\left( {{o}_{1},{o}_{3}}\right)  \vee  \operatorname{Sim}\left( {{o}_{2},{o}_{3}}\right) }\right)  = {\mu }_{\max }\left( {\mathcal{G}\left( {\operatorname{Sim}\left( {{o}_{1},{o}_{3}}\right) ,\mathcal{G}\left( {\operatorname{Sim}\left( {{o}_{2},{o}_{3}}\right) }\right) }\right. }\right.
$$

---

$$
\approx  \max \left( {{0.86},{0.73}}\right)  = {0.86}
$$

${}^{3}$ Examples of t-norms which can be chosen here are Lukasiewicz, product, and Gödel. Lukasiewicz s-norm is defined as ${\mu }_{Luk}\left( {x, y}\right)  = \min \left( {x + y,1}\right)$ ; Product s-norm is defined as ${\mu }_{Pr}\left( {x, y}\right)  = x + y - x \cdot  y$ ; Gödel s-norm is defined as ${\mu }_{\max }\left( {x, y}\right)  = \max \left( {x, y}\right)$ .

${}^{3}$ 这里可以选择的 t - 范数的例子有卢卡西维茨(Lukasiewicz)、乘积和哥德尔(Gödel)。卢卡西维茨 s - 范数定义为 ${\mu }_{Luk}\left( {x, y}\right)  = \min \left( {x + y,1}\right)$；乘积 s - 范数定义为 ${\mu }_{Pr}\left( {x, y}\right)  = x + y - x \cdot  y$；哥德尔 s - 范数定义为 ${\mu }_{\max }\left( {x, y}\right)  = \max \left( {x, y}\right)$。

---

## 3 Learning as approximate satisfiability

## 3 作为近似可满足性的学习

We start by defining ground theory and their satisfiability.

我们首先定义基理论及其可满足性。

Definition 2 (Satisfiability). Let $\phi$ be a closed clause in $\mathcal{L},\mathcal{G}$ a grounding, and $v \leq$ $w \in  \left\lbrack  {0,1}\right\rbrack$ . We say that $\mathcal{G}$ satisfies $\phi$ in the confidence interval $\left\lbrack  {v, w}\right\rbrack$ , written $\mathcal{G}{ \vDash  }_{v}^{w}\phi$ , if $v \leq  \mathcal{G}\left( \phi \right)  \leq  w$ .

定义 2(可满足性)。设 $\phi$ 是 $\mathcal{L},\mathcal{G}$ 中的一个闭子句， $v \leq$ $w \in  \left\lbrack  {0,1}\right\rbrack$。我们称 $\mathcal{G}$ 在置信区间 $\left\lbrack  {v, w}\right\rbrack$ 内满足 $\phi$，记为 $\mathcal{G}{ \vDash  }_{v}^{w}\phi$，如果 $v \leq  \mathcal{G}\left( \phi \right)  \leq  w$。

A partial grounding, denoted by $\widehat{\mathcal{G}}$ , is a grounding that is defined on a subset of the signature of $\mathcal{L}$ . A grounded theory is a set of clauses in the language of $\mathcal{L}$ and partial grounding $\widehat{\mathcal{G}}$ .

部分基(用 $\widehat{\mathcal{G}}$ 表示)是在 $\mathcal{L}$ 的签名子集上定义的基。基理论是 $\mathcal{L}$ 语言和部分基 $\widehat{\mathcal{G}}$ 中的一组子句。

Definition 3 (Grounded Theory). A grounded theory (GT) is a pair $\langle \mathcal{K},\widehat{\mathcal{G}}\rangle$ where $\mathcal{K}$ is a set of pairs $\langle \left\lbrack  {v, w}\right\rbrack  ,\phi \left( \mathbf{x}\right) \rangle$ , where $\phi \left( \mathbf{x}\right)$ is a clause of $\mathcal{L}$ containing the set $\mathbf{x}$ of free variables, and $\left\lbrack  {v, w}\right\rbrack   \subseteq  \left\lbrack  {0,1}\right\rbrack$ is an interval contained in $\left\lbrack  {0,1}\right\rbrack$ , and $\mathcal{G}$ is a partial grounding.

定义 3(基理论)。基理论(GT)是一个对 $\langle \mathcal{K},\widehat{\mathcal{G}}\rangle$，其中 $\mathcal{K}$ 是一组对 $\langle \left\lbrack  {v, w}\right\rbrack  ,\phi \left( \mathbf{x}\right) \rangle$，其中 $\phi \left( \mathbf{x}\right)$ 是 $\mathcal{L}$ 中包含自由变量集合 $\mathbf{x}$ 的子句，$\left\lbrack  {v, w}\right\rbrack   \subseteq  \left\lbrack  {0,1}\right\rbrack$ 是包含在 $\left\lbrack  {0,1}\right\rbrack$ 中的区间，$\mathcal{G}$ 是部分基。

Definition 4 (Satisfiability of a Grounded Theory). A GT $\langle \mathcal{K},\widehat{\mathcal{G}}\rangle$ is satisfiabile if there exists a grounding $\mathcal{G}$ , which extends $\widehat{\mathcal{G}}$ such that for all $\langle \left\lbrack  {v, w}\right\rbrack  ,\phi \left( \mathbf{x}\right) \rangle  \in  \mathcal{K}$ and any tuple $\mathbf{t}$ of closed terms, $\mathcal{G}{ \vDash  }_{v}^{w}\phi \left( \mathbf{t}\right)$ .

定义 4(基理论的可满足性)。如果存在一个基 $\mathcal{G}$ 扩展了 $\widehat{\mathcal{G}}$，使得对于所有 $\langle \left\lbrack  {v, w}\right\rbrack  ,\phi \left( \mathbf{x}\right) \rangle  \in  \mathcal{K}$ 和任何闭项元组 $\mathbf{t}$，都有 $\mathcal{G}{ \vDash  }_{v}^{w}\phi \left( \mathbf{t}\right)$，则 GT $\langle \mathcal{K},\widehat{\mathcal{G}}\rangle$ 是可满足的。

From the previous definiiton it follows that checking if a GT $\langle \mathcal{K},\widehat{\mathcal{G}}\rangle$ is satisfiable amounts to seaching for an extension of the partial grounding $\widehat{\mathcal{G}}$ in the space of all possible groundings, such that all the instantiations of the clauses in $\mathcal{K}$ are satisfied w.r.t. the specified interval. Clearly this is unfeasible from a practical point of view. As is usual, we must restrict both the space of grounding and clause instantiations. Let us consider each in turn: To check satisfiability on a subset of all the functions on real numbers, recall that a grounding should capture a latent correlation between the quantitative attributes of an object and its relational properties ${}^{4}$ . In particular, we are interested in searching within a specific class of functions, in this paper based on tensor networks, although other family of functions can be considered. To limit the number of clause instantiations, which in general might be infinite since $\mathcal{L}$ admits function symbols, the usual approach is to consider the instantiations of each clause up to a certain depth [3].

从前面的定义可以得出，检查 GT $\langle \mathcal{K},\widehat{\mathcal{G}}\rangle$ 是否可满足相当于在所有可能的基的空间中搜索部分基 $\widehat{\mathcal{G}}$ 的扩展，使得 $\mathcal{K}$ 中子句的所有实例化都相对于指定区间得到满足。显然，从实际角度来看，这是不可行的。像往常一样，我们必须限制基的空间和子句实例化。让我们依次考虑每个方面:为了检查实数上所有函数的一个子集的可满足性，回想一下，基应该捕捉对象的定量属性与其关系属性 ${}^{4}$ 之间的潜在相关性。特别是，我们有兴趣在特定的函数类中进行搜索，在本文中是基于张量网络的函数类，不过也可以考虑其他函数族。为了限制子句实例化的数量(由于 $\mathcal{L}$ 允许函数符号，一般来说可能是无限的)，通常的方法是考虑每个子句到一定深度的实例化 [3]。

When a grounded theory $\langle \mathcal{K},\widehat{\mathcal{G}}\rangle$ is inconsitent, that is, there is no grounding $\mathcal{G}$ that satisfies it, we are interested in finding a grounding which satisfies as much as possible of $\langle \mathcal{K},\widehat{\mathcal{G}}\rangle$ . For any $\langle \left\lbrack  {v, w}\right\rbrack  ,\phi \rangle  \in  \mathcal{K}$ we want to find a grounding $\mathcal{G}$ that minimizes the satisfiability error. An error occurs when a grounding $\mathcal{G}$ assigns a value $\mathcal{G}\left( \phi \right)$ to a clause $\phi$ which is outside the interval $\left\lbrack  {v, w}\right\rbrack$ prescribed by $\mathcal{K}$ . The measure of this error can be defined as the minimal distance between the points in the interval $\left\lbrack  {v, w}\right\rbrack$ and $\mathcal{G}\left( \phi \right)$ :

当基理论 $\langle \mathcal{K},\widehat{\mathcal{G}}\rangle$ 不一致时，即不存在满足它的基 $\mathcal{G}$，我们有兴趣找到一个尽可能满足 $\langle \mathcal{K},\widehat{\mathcal{G}}\rangle$ 的基。对于任何 $\langle \left\lbrack  {v, w}\right\rbrack  ,\phi \rangle  \in  \mathcal{K}$，我们希望找到一个基 $\mathcal{G}$ 来最小化可满足性误差。当基 $\mathcal{G}$ 给子句 $\phi$ 分配的值 $\mathcal{G}\left( \phi \right)$ 超出了 $\mathcal{K}$ 规定的区间 $\left\lbrack  {v, w}\right\rbrack$ 时，就会出现误差。这个误差的度量可以定义为区间 $\left\lbrack  {v, w}\right\rbrack$ 中的点与 $\mathcal{G}\left( \phi \right)$ 之间的最小距离:

$$
\operatorname{Loss}\left( {\mathcal{G},\langle \left\lbrack  {v, w}\right\rbrack  ,\phi \rangle }\right)  = \left| {x - \mathcal{G}\left( \phi \right) }\right| , v \leq  x \leq  w \tag{1}
$$

Notice that if $\mathcal{G}\left( \phi \right)  \in  \left\lbrack  {v, w}\right\rbrack  ,\operatorname{Loss}\left( {\mathcal{G},\phi }\right)  = 0$ .

注意，如果 $\mathcal{G}\left( \phi \right)  \in  \left\lbrack  {v, w}\right\rbrack  ,\operatorname{Loss}\left( {\mathcal{G},\phi }\right)  = 0$ 。

---

${}^{4}$ For example, whether a document is classified as from the field of Artificial Intelligence (AI) depends on its bag-of-words grounding. If the language $\mathcal{L}$ contains the unary predicate ${AI}\left( x\right)$ standing for " $x$ is a paper about AI" then the grounding of ${AI}\left( x\right)$ , which is a function from bag-of-words vectors to $\left\lbrack  {0,1}\right\rbrack$ , should assign values close to 1 to the vectors which are close semantically to ${AI}$ . Furthermore, if two vectors are similar (e.g. according to the cosine similarity measure) then their grounding should be similar.

${}^{4}$ 例如，一个文档是否被归类为来自人工智能(Artificial Intelligence，AI)领域取决于它的词袋基础。如果语言 $\mathcal{L}$ 包含表示“ $x$ 是一篇关于人工智能的论文”的一元谓词 ${AI}\left( x\right)$ ，那么 ${AI}\left( x\right)$ 的基础(它是一个从词袋向量到 $\left\lbrack  {0,1}\right\rbrack$ 的函数)应该将接近 1 的值分配给在语义上接近 ${AI}$ 的向量。此外，如果两个向量相似(例如，根据余弦相似度度量)，那么它们的基础也应该相似。

---

The above gives rise to the following definition of approximate satisfiability w.r.t. a family $\mathbb{G}$ of grounding functions on the language $\mathcal{L}$ .

上述内容引出了关于语言 $\mathcal{L}$ 上的一族基础函数 $\mathbb{G}$ 的近似可满足性的如下定义。

Definition 5 (Approximate satisfiability). Let $\langle \mathcal{K},\widehat{\mathcal{G}}\rangle$ be a grounded theory and ${\mathcal{K}}_{0}$ a finite subset of the instantiations of the clauses in $\mathcal{K}$ , i.e.

定义 5(近似可满足性)。设 $\langle \mathcal{K},\widehat{\mathcal{G}}\rangle$ 是一个基础理论， ${\mathcal{K}}_{0}$ 是 $\mathcal{K}$ 中子句实例化的一个有限子集，即

$$
{K}_{0} \subseteq  \{ \langle \left\lbrack  {v, w}\right\rbrack  ,\phi \left( \mathbf{t}\right) \rangle \}  \mid  \langle \left\lbrack  {v, w}\right\rbrack  ,\phi \left( \mathbf{x}\right) \rangle  \in  \mathcal{K}\text{and}\mathbf{t}\text{is any}n\text{-tuple of closed terms.}\}
$$

Let $\mathbb{G}$ be a family of grounding functions. We define the best satisfiability problem as the problem of finding an extensions ${\mathcal{G}}^{ * }$ of $\widehat{\mathcal{G}}$ in $\mathbb{G}$ that minimizes the satisfiability error on the set ${\mathcal{K}}_{0}$ , that is:

设 $\mathbb{G}$ 是一族基础函数。我们将最佳可满足性问题定义为在 $\mathbb{G}$ 中找到 $\widehat{\mathcal{G}}$ 的一个扩展 ${\mathcal{G}}^{ * }$ ，使得集合 ${\mathcal{K}}_{0}$ 上的可满足性误差最小，即:

$$
{\mathcal{G}}^{ * } = \mathop{\operatorname{argmin}}\limits_{{\widehat{\mathcal{G}} \subseteq  \mathcal{G} \in  \mathbb{G}}}\mathop{\sum }\limits_{{\langle \left\lbrack  {v, w}\right\rbrack  ,\phi \left( \mathbf{t}\right) \rangle  \in  {\mathcal{K}}_{0}}}\operatorname{Loss}\left( {\mathcal{G},\langle \left\lbrack  {v, w}\right\rbrack  ,\phi \left( \mathbf{t}\right) \rangle }\right)
$$

## 4 Implementing Real Logic in Tensor Networks

## 4 在张量网络中实现实逻辑

Specific instances of Real Logic can be obtained by selectiong the space $\mathbb{G}$ of ground-ings and the specific s-norm for the interpretation of disjunction. In this section, we describe a realization of real logic where $\mathbb{G}$ is the space of real tensor transformations of order $k$ (where $k$ is a parameter). In this space, function symbols are interpreted as linear transformations. More precisely, if $f$ is a function symbol of arity $m$ and ${\mathbf{v}}_{1},\ldots ,{\mathbf{v}}_{m} \in  {\mathbb{R}}^{n}$ are real vectors corresponding to the grounding of $m$ terms then $\mathcal{G}\left( f\right) \left( {{\mathbf{v}}_{1},\ldots ,{\mathbf{v}}_{m}}\right)$ can be written as:

实逻辑的具体实例可以通过选择基础空间 $\mathbb{G}$ 和用于解释析取的特定 s - 范数来获得。在本节中，我们描述实逻辑的一种实现，其中 $\mathbb{G}$ 是 $k$ 阶实张量变换的空间(其中 $k$ 是一个参数)。在这个空间中，函数符号被解释为线性变换。更准确地说，如果 $f$ 是一个元数为 $m$ 的函数符号，并且 ${\mathbf{v}}_{1},\ldots ,{\mathbf{v}}_{m} \in  {\mathbb{R}}^{n}$ 是对应于 $m$ 个项的基础的实向量，那么 $\mathcal{G}\left( f\right) \left( {{\mathbf{v}}_{1},\ldots ,{\mathbf{v}}_{m}}\right)$ 可以写成:

$$
\mathcal{G}\left( f\right) \left( {{\mathbf{v}}_{1},\ldots ,{\mathbf{v}}_{m}}\right)  = {M}_{f}\mathbf{v} + {N}_{f}
$$

for some $n \times  {mn}$ matrix ${M}_{f}$ and $n$ -vector ${N}_{f}$ , where $\mathbf{v} = \left\langle  {{\mathbf{v}}_{1},\ldots ,{\mathbf{v}}_{n}}\right\rangle$ .

对于某个 $n \times  {mn}$ 矩阵 ${M}_{f}$ 和 $n$ - 向量 ${N}_{f}$ ，其中 $\mathbf{v} = \left\langle  {{\mathbf{v}}_{1},\ldots ,{\mathbf{v}}_{n}}\right\rangle$ 。

The grounding of $m$ -ary predicate $P,\mathcal{G}\left( P\right)$ , is defined as a generalization of the neural tensor network [26] (which has been shown effective at knowledge compilation in the presence of simple logical constraints), as a function from ${\mathbb{R}}^{mn}$ to $\left\lbrack  {0,1}\right\rbrack$ , as follows:

$m$ 元谓词 $P,\mathcal{G}\left( P\right)$ 的基础被定义为神经张量网络 [26] 的推广(已证明在存在简单逻辑约束的情况下，神经张量网络在知识编译方面是有效的)，它是一个从 ${\mathbb{R}}^{mn}$ 到 $\left\lbrack  {0,1}\right\rbrack$ 的函数，如下所示:

$$
\mathcal{G}\left( P\right)  = \sigma \left( {{u}_{P}^{T}\tanh \left( {{\mathbf{v}}^{T}{W}_{P}^{\left\lbrack  1 : k\right\rbrack  }\mathbf{v} + {V}_{P}\mathbf{v} + {B}_{P}}\right) }\right)  \tag{2}
$$

where ${W}_{P}^{\left\lbrack  1 : k\right\rbrack  }$ is a 3-D tensor in ${\mathbb{R}}^{{mn} \times  {mn} \times  k},{V}_{P}$ is a matrix in ${\mathbb{R}}^{k \times  {mn}}$ , and ${B}_{P}$ is a vector in ${\mathbb{R}}^{k}$ , and $\sigma$ is the sigmoid function. With this encoding, the grounding (i.e. truth-value) of a clause can be determined by a neural network which first computes the grounding of the literals contained in the clause, and then combines them using the specific s-norm. An example of tensor network for $\neg P\left( {x, y}\right)  \rightarrow  A\left( y\right)$ is shown in Figure 1. This architecture is a generalization of the structure proposed in [26], that has been shown rather effective for the task of knowledge compilation, also in presence of simple logical constraints. In the above tensor network formulation, ${W}_{ * },{V}_{ * },{B}_{ * }$ and ${u}_{ * }$ with $*  \in  \{ P, A\}$ are parameters to be learned by minimizing the loss function or, equivalently, to maximize the satisfiability of the clause $P\left( {x, y}\right)  \rightarrow  A\left( y\right)$ .

其中 ${W}_{P}^{\left\lbrack  1 : k\right\rbrack  }$ 是 ${\mathbb{R}}^{{mn} \times  {mn} \times  k},{V}_{P}$ 中的一个三维张量，${\mathbb{R}}^{k \times  {mn}}$ 中的 ${B}_{P}$ 是一个矩阵，${\mathbb{R}}^{k}$ 中的 $\sigma$ 是一个向量，并且 $\sigma$ 是Sigmoid函数。通过这种编码，子句的真值(即真值赋值)可以由一个神经网络确定，该网络首先计算子句中包含的文字的真值，然后使用特定的S-范数将它们组合起来。图1展示了 $\neg P\left( {x, y}\right)  \rightarrow  A\left( y\right)$ 的张量网络示例。这种架构是文献[26]中提出的结构的推广，该结构已被证明在知识编译任务中相当有效，即使存在简单的逻辑约束也是如此。在上述张量网络公式中，${W}_{ * },{V}_{ * },{B}_{ * }$ 和 ${u}_{ * }$ 以及 $*  \in  \{ P, A\}$ 是需要通过最小化损失函数来学习的参数，或者等效地，是为了最大化子句 $P\left( {x, y}\right)  \rightarrow  A\left( y\right)$ 的可满足性。

![0195da4f-cb6f-7676-bd4c-8994c03045a9_6_455_326_893_570_0.jpg](images/0195da4f-cb6f-7676-bd4c-8994c03045a9_6_455_326_893_570_0.jpg)

Fig. 1. Tensor net for $P\left( {x, y}\right)  \rightarrow  A\left( y\right)$ , with $\mathcal{G}\left( x\right)  = \mathbf{v}$ and $\mathcal{G}\left( y\right)  = \mathbf{u}$ and $k = 2$ .

图1. $P\left( {x, y}\right)  \rightarrow  A\left( y\right)$ 的张量网络，其中 $\mathcal{G}\left( x\right)  = \mathbf{v}$、$\mathcal{G}\left( y\right)  = \mathbf{u}$ 和 $k = 2$。

## 5 An Example of Knowledge Completion

## 5 知识补全示例

Logic Tensor Networks have been implemented as a Python library called 1tn using Google’s TENSORFLOW ${}^{\mathrm{{TM}}}$ . To test our idea, in this section we use the well-known friends and smokers ${}^{5}$ example [24] to illustrate the task of knowledge completion in ltn. There are 14 people divided into two groups $\{ a, b,\ldots , h\}$ and $\{ i, j,\ldots , n\}$ . Within each group of people we have complete knowledge of their smoking habits. In the first group, we have complete knowledge of who has and does not have cancer. In the second group, this is not known for any of the persons. Knowledge about the friendship relation is complete within each group only if symmetry of friendship is assumed. Otherwise, it is imcomplete in that it may be known that, e.g., $a$ is a friend of $b$ , but not known whether $b$ is a friend of $a$ . Finally, there is also general knowledge about smoking, friendship and cancer, namely, that smoking causes cancer, friendship is normally a symmetric and anti-reflexive relation, everyone has a friend, and that smoking propagates (either actively or passively) among friends. All this knowledge can be represented by the knowledge-bases shown in Figure 2.

逻辑张量网络已被实现为一个名为1tn的Python库，使用了谷歌的TensorFlow ${}^{\mathrm{{TM}}}$。为了验证我们的想法，在本节中，我们使用著名的朋友与吸烟者 ${}^{5}$ 示例[24]来说明逻辑张量网络(ltn)中的知识补全任务。有14个人被分为两组 $\{ a, b,\ldots , h\}$ 和 $\{ i, j,\ldots , n\}$。在每组人中，我们对他们的吸烟习惯有完整的了解。在第一组中，我们对谁患有癌症和谁未患癌症有完整的了解。在第二组中，对于任何一个人是否患有癌症都不清楚。只有在假设友谊具有对称性的情况下，每组内关于友谊关系的知识才是完整的。否则，这种知识是不完整的，例如，可能知道 $a$ 是 $b$ 的朋友，但不知道 $b$ 是否是 $a$ 的朋友。最后，还有关于吸烟、友谊和癌症的一般知识，即吸烟会导致癌症，友谊通常是一种对称且非自反的关系，每个人都有朋友，并且吸烟(主动或被动)会在朋友之间传播。所有这些知识都可以由图2所示的知识库表示。

The facts contained in the knowledge-bases should have different degrees of truth, and this is not known. Otherwise, the combined knowledge-base would be inconsistent (it would deduce e.g. $S\left( b\right)$ and $\neg S\left( b\right)$ ). Our main task is to complete the knowledge-base (KB), that is: (i) find the degree of truth of the facts contained in KB, (ii) find a truth-value for all the missing facts, e.g. $C\left( i\right)$ ,(iii) find the grounding of each constant symbol $a,\ldots , n.{}^{6}$ To answer (i)-(iii), we use 1tn to find a grounding that best approximates the complete KB. We start by assuming that all the facts contained in the knowledge-base are true (i.e. have degree of truth 1). To show the role of background knolwedge in the learning-inference process, we run two experiments. In the first (exp1), we seek to complete a KB consisting of only factual knowledge: ${\mathcal{K}}_{exp1} =$ ${\mathcal{K}}_{a\ldots h}^{SFC} \cup  {\mathcal{K}}_{i\ldots n}^{SF}$ . In the second (exp1), we also include background knowledge, that is: ${\mathcal{K}}_{exp2} = {\mathcal{K}}_{exp1} \cup  {\mathcal{K}}^{SFC}$ .

知识库中包含的事实应该具有不同程度的真实性，但这一点并不明确。否则，合并后的知识库将是不一致的(例如，它会推导出$S\left( b\right)$和$\neg S\left( b\right)$)。我们的主要任务是完善知识库(KB)，即:(i)找出知识库中事实的真实程度；(ii)为所有缺失的事实(例如$C\left( i\right)$)找到一个真值；(iii)找出每个常量符号$a,\ldots , n.{}^{6}$的基。为了回答(i) - (iii)，我们使用1tn来找到一个最接近完整知识库的基。我们首先假设知识库中包含的所有事实都是真实的(即真实程度为1)。为了展示背景知识在学习 - 推理过程中的作用，我们进行了两个实验。在第一个实验(exp1)中，我们试图完善一个仅由事实性知识组成的知识库:${\mathcal{K}}_{exp1} =$ ${\mathcal{K}}_{a\ldots h}^{SFC} \cup  {\mathcal{K}}_{i\ldots n}^{SF}$。在第二个实验(exp1)中，我们还纳入了背景知识，即:${\mathcal{K}}_{exp2} = {\mathcal{K}}_{exp1} \cup  {\mathcal{K}}^{SFC}$。

---

${}^{5}$ Normally, a probabilistic approach is taken to solve this problem, and one that requires instantiating all clauses to remove variables, essentially turning the problem into a propositional one; 1th takes a different approach.

${}^{5}$通常，会采用概率方法来解决这个问题，这种方法需要实例化所有子句以消除变量，本质上是将问题转化为命题问题；1th采用了不同的方法。

${}^{6}$ Notice how no grounding is provided about the signature of the knowledge-base.

${}^{6}$注意，关于知识库的签名没有提供任何基。

---

![0195da4f-cb6f-7676-bd4c-8994c03045a9_7_408_334_993_568_0.jpg](images/0195da4f-cb6f-7676-bd4c-8994c03045a9_7_408_334_993_568_0.jpg)

Fig. 2. Knowledge-bases for the friends-and-smokers example.

图2. 朋友与吸烟者示例的知识库。

We confgure the network as follows: each constant (i.e. person) can have up to 30 real-valued features. We set the number of layers $k$ in the tensor network to 10, and the regularization parameter ${}^{7}\lambda  = {1}^{-{10}}$ . For the purpose of illustration, we use the Lukasiewicz t-norm with s-norm $\mu \left( {a, b}\right)  = \min \left( {1, a + b}\right)$ , and use the harmonic mean as aggregation operator. An estimation of the optimal grounding is obtained after 5,000 runs of the RMSProp learning algorithm [27] available in TENSORFLOW ${}^{\mathrm{{TM}}}$ .

我们按如下方式配置网络:每个常量(即人)最多可以有30个实值特征。我们将张量网络中的层数$k$设置为10，并设置正则化参数${}^{7}\lambda  = {1}^{-{10}}$。为了便于说明，我们使用具有s - 范数$\mu \left( {a, b}\right)  = \min \left( {1, a + b}\right)$的卢卡西维茨t - 范数，并使用调和平均数作为聚合算子。在TENSORFLOW ${}^{\mathrm{{TM}}}$中可用的RMSProp学习算法[27]运行5000次后，得到了最优基的估计值。

The results of the two experiments are reported in Table 1. For readability, we use boldface for truth-values greater than 0.5 . The truth-values of the facts listed in a knowledge-base are highlighted with the same background color of the knowledge-base in Figure 2. The values with white background are the result of the knowledge completion produced by the LTN learning-inference procedure. To evaluate the quality of the results, one has to check whether (i) the truth-values of the facts listed in a KB are indeed close to 1.0, and (ii) the truth-values associated with knowledge completion correspond to expectation. An initial analysis shows that the LTN associated with ${\mathcal{K}}_{\text{exp1 }}$ produces the same facts as ${\mathcal{K}}_{exp1}$ itself. In other words, the LTN fits the data. However, the LTN also learns to infer additional positive and negative facts about $F$ and $C$ not derivable from ${\mathcal{K}}_{exp1}$ by pure logical reasoning; for example: $F\left( {c, b}\right) , F\left( {g, b}\right)$ and $\neg F\left( {b, a}\right)$ . These facts are derived by exploiting similarities between the groundings of Table 1. the constants generated by the LTN. For instance, $\mathcal{G}\left( c\right)$ and $\mathcal{G}\left( g\right)$ happen to present a high cosine similarity measure. As a result, facts about the friendship relations of $c$ affect the friendship relations of $g$ and vice-versa, for instance $F\left( {c, b}\right)$ and $F\left( {g, b}\right)$ . The level of satisfiability associated with ${\mathcal{K}}_{exp1} \approx  1$ , which indicates that ${\mathcal{K}}_{exp1}$ is classically satisfiable.

两个实验的结果报告于表1。为便于阅读，我们对大于0.5的真值使用粗体表示。知识库中列出的事实的真值在图2中以与知识库相同的背景颜色突出显示。白色背景的值是通过模糊逻辑张量网络(LTN)学习推理过程进行知识补全的结果。为评估结果的质量，需要检查:(i)知识库中列出的事实的真值是否确实接近1.0；(ii)与知识补全相关的真值是否符合预期。初步分析表明，与${\mathcal{K}}_{\text{exp1 }}$相关联的模糊逻辑张量网络(LTN)产生的事实与${\mathcal{K}}_{exp1}$本身产生的事实相同。换句话说，模糊逻辑张量网络(LTN)拟合了数据。然而，模糊逻辑张量网络(LTN)还学会推断关于$F$和$C$的额外正事实和负事实，这些事实无法通过纯逻辑推理从${\mathcal{K}}_{exp1}$中推导得出；例如:$F\left( {c, b}\right) , F\left( {g, b}\right)$和$\neg F\left( {b, a}\right)$。这些事实是通过利用表1的基元(groundings)之间的相似性推导得出的，即模糊逻辑张量网络(LTN)生成的常量。例如，$\mathcal{G}\left( c\right)$和$\mathcal{G}\left( g\right)$恰好呈现出较高的余弦相似度度量。因此，关于$c$的友谊关系的事实会影响$g$的友谊关系，反之亦然，例如$F\left( {c, b}\right)$和$F\left( {g, b}\right)$。与${\mathcal{K}}_{exp1} \approx  1$相关联的可满足性水平表明${\mathcal{K}}_{exp1}$在经典意义上是可满足的。

---

${}^{7}$ A smoothing factor $\lambda \parallel \mathbf{\Omega }{\parallel }_{2}^{2}$ is added to the loss function to create a preference for learned parameters with a lower absolute value.

${}^{7}$ 一个平滑因子$\lambda \parallel \mathbf{\Omega }{\parallel }_{2}^{2}$被添加到损失函数中，以使得学习到的参数更倾向于具有较低的绝对值。

---

<table><tr><td rowspan="2"/><td rowspan="2">$S$</td><td rowspan="2">$C$</td><td colspan="8">$F$</td></tr><tr><td>$a$</td><td>$b$</td><td>$C$</td><td>$d$</td><td>e</td><td>$f$</td><td>$g$</td><td>$h$</td></tr><tr><td>$a$</td><td>1.00</td><td>1.00</td><td>0.00</td><td>1.00</td><td>0.00</td><td>0.00</td><td>1.00</td><td>1.00</td><td>1.00</td><td>0.00</td></tr><tr><td>$b$</td><td>0.00</td><td>0.00</td><td>0.00</td><td>0.00</td><td>1.00</td><td>0.00</td><td>0.00</td><td>0.00</td><td>0.00</td><td>0.00</td></tr><tr><td>$C$</td><td>0.00</td><td>0.00</td><td>0.00</td><td>0.82</td><td>0.00</td><td>1.00</td><td>0.00</td><td>0.00</td><td>0.00</td><td>0.00</td></tr><tr><td>$d$</td><td>0.00</td><td>0.00</td><td>0.00</td><td>0.00</td><td>0.06</td><td>0.00</td><td>0.00</td><td>0.00</td><td>0.00</td><td>0.00</td></tr><tr><td>$e$</td><td>1.00</td><td>1.00</td><td>0.00</td><td>0.33</td><td>0.21</td><td>0.00</td><td>0.00</td><td>1.00</td><td>0.00</td><td>0.00</td></tr><tr><td>$f$</td><td>1.00</td><td>0.00</td><td>0.00</td><td>0.00</td><td>0.05</td><td>0.00</td><td>0.00</td><td>0.00</td><td>0.00</td><td>0.00</td></tr><tr><td>$g$</td><td>1.00</td><td>0.00</td><td>0.03</td><td>1.00</td><td>1.00</td><td>1.00</td><td>0.11</td><td>1.00</td><td>0.00</td><td>1.00</td></tr><tr><td>$h$</td><td>0.00</td><td>0.00</td><td>0.00</td><td>0.23</td><td>0.01</td><td>0.14</td><td>0.00</td><td>0.02</td><td>0.00</td><td>0.00</td></tr></table>

<table><tr><td rowspan="2"/><td rowspan="2">$S$</td><td rowspan="2">$C$</td><td colspan="8">$F$</td></tr><tr><td>$a$</td><td>$b$</td><td>$C$</td><td>$d$</td><td>e</td><td>$f$</td><td>$g$</td><td>$h$</td></tr><tr><td>$a$</td><td>1.00</td><td>1.00</td><td>0.00</td><td>1.00</td><td>0.00</td><td>0.00</td><td>1.00</td><td>1.00</td><td>1.00</td><td>0.00</td></tr><tr><td>$b$</td><td>0.00</td><td>0.00</td><td>0.00</td><td>0.00</td><td>1.00</td><td>0.00</td><td>0.00</td><td>0.00</td><td>0.00</td><td>0.00</td></tr><tr><td>$C$</td><td>0.00</td><td>0.00</td><td>0.00</td><td>0.82</td><td>0.00</td><td>1.00</td><td>0.00</td><td>0.00</td><td>0.00</td><td>0.00</td></tr><tr><td>$d$</td><td>0.00</td><td>0.00</td><td>0.00</td><td>0.00</td><td>0.06</td><td>0.00</td><td>0.00</td><td>0.00</td><td>0.00</td><td>0.00</td></tr><tr><td>$e$</td><td>1.00</td><td>1.00</td><td>0.00</td><td>0.33</td><td>0.21</td><td>0.00</td><td>0.00</td><td>1.00</td><td>0.00</td><td>0.00</td></tr><tr><td>$f$</td><td>1.00</td><td>0.00</td><td>0.00</td><td>0.00</td><td>0.05</td><td>0.00</td><td>0.00</td><td>0.00</td><td>0.00</td><td>0.00</td></tr><tr><td>$g$</td><td>1.00</td><td>0.00</td><td>0.03</td><td>1.00</td><td>1.00</td><td>1.00</td><td>0.11</td><td>1.00</td><td>0.00</td><td>1.00</td></tr><tr><td>$h$</td><td>0.00</td><td>0.00</td><td>0.00</td><td>0.23</td><td>0.01</td><td>0.14</td><td>0.00</td><td>0.02</td><td>0.00</td><td>0.00</td></tr></table>

<table><tr><td rowspan="2"/><td rowspan="2">$S$</td><td rowspan="2">$C$</td><td colspan="6">$F$</td></tr><tr><td>$i$</td><td>$j$</td><td>$k$</td><td>$l$</td><td>$m$</td><td>$n$</td></tr><tr><td>$i$</td><td>1.00</td><td>0.00</td><td>0.00</td><td>1.00</td><td>0.00</td><td>0.00</td><td>1.00</td><td>0.00</td></tr><tr><td>$j$</td><td>0.00</td><td>0.00</td><td>0.00</td><td>0.00</td><td>0.00</td><td>0.00</td><td>0.00</td><td>0.00</td></tr><tr><td>$k$</td><td>0.00</td><td>0.00</td><td>0.10</td><td>1.00</td><td>0.00</td><td>1.00</td><td>0.00</td><td>0.00</td></tr><tr><td>$l$</td><td>0.00</td><td>0.00</td><td>0.00</td><td>0.02</td><td>0.00</td><td>0.00</td><td>0.00</td><td>0.00</td></tr><tr><td>$m$</td><td>0.00</td><td>0.03</td><td>1.00</td><td>1.00</td><td>0.12</td><td>1.00</td><td>0.00</td><td>1.00</td></tr><tr><td>$n$</td><td>1.00</td><td>0.01</td><td>0.00</td><td>0.98</td><td>0.00</td><td>0.01</td><td>0.02</td><td>0.00</td></tr></table>

<table><tr><td rowspan="2"/><td rowspan="2">$S$</td><td rowspan="2">$C$</td><td colspan="6">$F$</td></tr><tr><td>$i$</td><td>$j$</td><td>$k$</td><td>$l$</td><td>$m$</td><td>$n$</td></tr><tr><td>$i$</td><td>1.00</td><td>0.00</td><td>0.00</td><td>1.00</td><td>0.00</td><td>0.00</td><td>1.00</td><td>0.00</td></tr><tr><td>$j$</td><td>0.00</td><td>0.00</td><td>0.00</td><td>0.00</td><td>0.00</td><td>0.00</td><td>0.00</td><td>0.00</td></tr><tr><td>$k$</td><td>0.00</td><td>0.00</td><td>0.10</td><td>1.00</td><td>0.00</td><td>1.00</td><td>0.00</td><td>0.00</td></tr><tr><td>$l$</td><td>0.00</td><td>0.00</td><td>0.00</td><td>0.02</td><td>0.00</td><td>0.00</td><td>0.00</td><td>0.00</td></tr><tr><td>$m$</td><td>0.00</td><td>0.03</td><td>1.00</td><td>1.00</td><td>0.12</td><td>1.00</td><td>0.00</td><td>1.00</td></tr><tr><td>$n$</td><td>1.00</td><td>0.01</td><td>0.00</td><td>0.98</td><td>0.00</td><td>0.01</td><td>0.02</td><td>0.00</td></tr></table>

Learning and reasoning on ${\mathcal{K}}_{exp1} = {\mathcal{K}}_{a\ldots h}^{SFC} \cup  {\mathcal{K}}_{i\ldots n}^{SF}$ Learning and reasoning on ${\mathcal{K}}_{exp2} = {\mathcal{K}}_{a\ldots h}^{SFC} \cup  {\mathcal{K}}_{i\ldots n}^{SF} \cup  {\mathcal{K}}^{SFC}$

关于${\mathcal{K}}_{exp1} = {\mathcal{K}}_{a\ldots h}^{SFC} \cup  {\mathcal{K}}_{i\ldots n}^{SF}$的学习与推理 关于${\mathcal{K}}_{exp2} = {\mathcal{K}}_{a\ldots h}^{SFC} \cup  {\mathcal{K}}_{i\ldots n}^{SF} \cup  {\mathcal{K}}^{SFC}$的学习与推理

<table><tr><td rowspan="2"/><td rowspan="2">$S$</td><td rowspan="2">$C$</td><td colspan="8">$F$</td></tr><tr><td>$a$</td><td>$b$</td><td>$C$</td><td>$d$</td><td>e</td><td>$f$</td><td>$g$</td><td>$h$</td></tr><tr><td>$a$</td><td>0.84</td><td>0.87</td><td>0.02</td><td>0.95</td><td>0.01</td><td>0.03</td><td>0.93</td><td>0.97</td><td>0.98</td><td>0.01</td></tr><tr><td>$b$</td><td>0.13</td><td>0.16</td><td>0.45</td><td>0.01</td><td>0.97</td><td>0.04</td><td>0.02</td><td>0.03</td><td>0.06</td><td>0.03</td></tr><tr><td>$C$</td><td>0.13</td><td>0.15</td><td>0.02</td><td>0.94</td><td>0.11</td><td>0.99</td><td>0.03</td><td>0.16</td><td>0.15</td><td>0.15</td></tr><tr><td>$d$</td><td>0.14</td><td>0.15</td><td>0.01</td><td>0.06</td><td>0.88</td><td>0.08</td><td>0.01</td><td>0.03</td><td>0.07</td><td>0.02</td></tr><tr><td>$e$</td><td>0.84</td><td>0.85</td><td>0.32</td><td>0.06</td><td>0.05</td><td>0.03</td><td>0.04</td><td>0.97</td><td>0.07</td><td>0.06</td></tr><tr><td>$f$</td><td>0.81</td><td>0.19</td><td>0.34</td><td>0.11</td><td>0.08</td><td>0.04</td><td>0.42</td><td>0.08</td><td>0.06</td><td>0.05</td></tr><tr><td>$g$</td><td>0.82</td><td>0.19</td><td>0.81</td><td>0.26</td><td>0.19</td><td>0.30</td><td>0.06</td><td>0.28</td><td>0.00</td><td>0.94</td></tr><tr><td>$h$</td><td>0.14</td><td>0.17</td><td>0.05</td><td>0.25</td><td>0.26</td><td>0.16</td><td>0.20</td><td>0.14</td><td>0.72</td><td>0.01</td></tr></table>

<table><tr><td rowspan="2"/><td rowspan="2">$S$</td><td rowspan="2">$C$</td><td colspan="8">$F$</td></tr><tr><td>$a$</td><td>$b$</td><td>$C$</td><td>$d$</td><td>e</td><td>$f$</td><td>$g$</td><td>$h$</td></tr><tr><td>$a$</td><td>0.84</td><td>0.87</td><td>0.02</td><td>0.95</td><td>0.01</td><td>0.03</td><td>0.93</td><td>0.97</td><td>0.98</td><td>0.01</td></tr><tr><td>$b$</td><td>0.13</td><td>0.16</td><td>0.45</td><td>0.01</td><td>0.97</td><td>0.04</td><td>0.02</td><td>0.03</td><td>0.06</td><td>0.03</td></tr><tr><td>$C$</td><td>0.13</td><td>0.15</td><td>0.02</td><td>0.94</td><td>0.11</td><td>0.99</td><td>0.03</td><td>0.16</td><td>0.15</td><td>0.15</td></tr><tr><td>$d$</td><td>0.14</td><td>0.15</td><td>0.01</td><td>0.06</td><td>0.88</td><td>0.08</td><td>0.01</td><td>0.03</td><td>0.07</td><td>0.02</td></tr><tr><td>$e$</td><td>0.84</td><td>0.85</td><td>0.32</td><td>0.06</td><td>0.05</td><td>0.03</td><td>0.04</td><td>0.97</td><td>0.07</td><td>0.06</td></tr><tr><td>$f$</td><td>0.81</td><td>0.19</td><td>0.34</td><td>0.11</td><td>0.08</td><td>0.04</td><td>0.42</td><td>0.08</td><td>0.06</td><td>0.05</td></tr><tr><td>$g$</td><td>0.82</td><td>0.19</td><td>0.81</td><td>0.26</td><td>0.19</td><td>0.30</td><td>0.06</td><td>0.28</td><td>0.00</td><td>0.94</td></tr><tr><td>$h$</td><td>0.14</td><td>0.17</td><td>0.05</td><td>0.25</td><td>0.26</td><td>0.16</td><td>0.20</td><td>0.14</td><td>0.72</td><td>0.01</td></tr></table>

<table><tr><td rowspan="2"/><td rowspan="2">$S$</td><td rowspan="2">$C$</td><td colspan="6">$F$</td></tr><tr><td>$i$</td><td>$j$</td><td>$k$</td><td>$l$</td><td>$m$</td><td>$n$</td></tr><tr><td>$i$</td><td>0.83</td><td>0.86</td><td>0.02</td><td>0.91</td><td>0.01</td><td>0.03</td><td>0.97</td><td>0.01</td></tr><tr><td>$j$</td><td>0.19</td><td>0.22</td><td>0.73</td><td>0.03</td><td>0.00</td><td>0.04</td><td>0.02</td><td>0.05</td></tr><tr><td>$k$</td><td>0.14</td><td>0.34</td><td>0.17</td><td>0.07</td><td>0.04</td><td>0.97</td><td>0.04</td><td>0.02</td></tr><tr><td>$l$</td><td>0.16</td><td>0.19</td><td>0.11</td><td>0.12</td><td>0.15</td><td>0.06</td><td>0.05</td><td>0.03</td></tr><tr><td>$m$</td><td>0.14</td><td>0.17</td><td>0.96</td><td>0.07</td><td>0.02</td><td>0.11</td><td>0.00</td><td>0.92</td></tr><tr><td>$n$</td><td>0.84</td><td>0.86</td><td>0.13</td><td>0.28</td><td>0.01</td><td>0.24</td><td>0.69</td><td>0.02</td></tr></table>

<table><tr><td rowspan="2"/><td rowspan="2">$S$</td><td rowspan="2">$C$</td><td colspan="6">$F$</td></tr><tr><td>$i$</td><td>$j$</td><td>$k$</td><td>$l$</td><td>$m$</td><td>$n$</td></tr><tr><td>$i$</td><td>0.83</td><td>0.86</td><td>0.02</td><td>0.91</td><td>0.01</td><td>0.03</td><td>0.97</td><td>0.01</td></tr><tr><td>$j$</td><td>0.19</td><td>0.22</td><td>0.73</td><td>0.03</td><td>0.00</td><td>0.04</td><td>0.02</td><td>0.05</td></tr><tr><td>$k$</td><td>0.14</td><td>0.34</td><td>0.17</td><td>0.07</td><td>0.04</td><td>0.97</td><td>0.04</td><td>0.02</td></tr><tr><td>$l$</td><td>0.16</td><td>0.19</td><td>0.11</td><td>0.12</td><td>0.15</td><td>0.06</td><td>0.05</td><td>0.03</td></tr><tr><td>$m$</td><td>0.14</td><td>0.17</td><td>0.96</td><td>0.07</td><td>0.02</td><td>0.11</td><td>0.00</td><td>0.92</td></tr><tr><td>$n$</td><td>0.84</td><td>0.86</td><td>0.13</td><td>0.28</td><td>0.01</td><td>0.24</td><td>0.69</td><td>0.02</td></tr></table>

<table><tr><td/><td colspan="2">$a,\ldots , h, i,\ldots , n$</td></tr><tr><td>$\forall x\neg F\left( {x, x}\right)$</td><td colspan="2">0.98</td></tr><tr><td>$\forall {xy}\left( {F\left( {x, y}\right)  \rightarrow  F\left( {y, x}\right) }\right)$</td><td>0.90</td><td>0.90</td></tr><tr><td>$\forall x\left( {S\left( x\right)  \rightarrow  C\left( x\right) }\right)$</td><td colspan="2">0.77</td></tr><tr><td>$\forall x\left( {S\left( x\right)  \land  F\left( {x, y}\right)  \rightarrow  S\left( y\right) }\right)$</td><td>0.96</td><td>0.92</td></tr><tr><td>$\forall x\exists y\left( {F\left( {x, y}\right) }\right)$</td><td colspan="2">1.0</td></tr></table>

<table><tr><td/><td colspan="2">$a,\ldots , h, i,\ldots , n$</td></tr><tr><td>$\forall x\neg F\left( {x, x}\right)$</td><td colspan="2">0.98</td></tr><tr><td>$\forall {xy}\left( {F\left( {x, y}\right)  \rightarrow  F\left( {y, x}\right) }\right)$</td><td>0.90</td><td>0.90</td></tr><tr><td>$\forall x\left( {S\left( x\right)  \rightarrow  C\left( x\right) }\right)$</td><td colspan="2">0.77</td></tr><tr><td>$\forall x\left( {S\left( x\right)  \land  F\left( {x, y}\right)  \rightarrow  S\left( y\right) }\right)$</td><td>0.96</td><td>0.92</td></tr><tr><td>$\forall x\exists y\left( {F\left( {x, y}\right) }\right)$</td><td colspan="2">1.0</td></tr></table>

The results of the second experiment show that more facts can be learned with the inclusion of background knowledge. For example, the LTN now predicts that $C\left( i\right)$ and $C\left( n\right)$ are true. Similarly, from the symmetry of the friendship relation, the LTN concludes that $m$ is a friend of $i$ , as expected. In fact, all the axioms in the generic background knowledge ${\mathcal{K}}^{SFC}$ are satisfied with a degree of satisfiability higher than ${90}\%$ , apart from the smoking causes cancer axiom - which is responsible for the classical inconsistency since in the data $f$ and $g$ smoke and do not have cancer -, which has a degree of satisfiability of ${77}\%$ .

第二个实验的结果表明，加入背景知识后可以学习到更多事实。例如，现在模糊逻辑张量网络(LTN)预测$C\left( i\right)$和$C\left( n\right)$为真。同样，根据友谊关系的对称性，模糊逻辑张量网络得出$m$是$i$的朋友，这与预期相符。事实上，通用背景知识${\mathcal{K}}^{SFC}$中的所有公理的可满足度都高于${90}\%$，除了“吸烟导致癌症”这一公理——由于在数据中$f$和$g$吸烟但没有患癌症，该公理导致了经典的不一致性——其可满足度为${77}\%$。

## 6 Related work

## 6 相关工作

In his recent note, [15], Guha advocates the need for a new model theory for distributed representations (such as those based on embeddings). The note sketches a proposal, where terms and (binary) predicates are all interpreted as points/vectors in an $n$ -dimensional real space. The computation of the truth-value of the atomic formulae $P\left( {{t}_{1},\ldots ,{t}_{n}}\right)$ is obtained by comparing the projections of the vector associated to each ${t}_{i}$ with that associated to ${P}_{i}$ . Real logic shares with [15] the idea that terms must be interpreted in a geometric space. It has, however, a different (and more general) interpretation of functions and predicate symbols. Real logic is more general because the semantics proposed in [15] can be implemented within an ${1tn}$ with a single layer $\left( {k = 1}\right)$ , since the operation of projection and comparison necessary to compute the truth-value of $P\left( {{t}_{1},\ldots ,{t}_{m}}\right)$ can be encoded within an ${nm} \times  {nm}$ matrix $W$ with the constraint that ${\left\langle  \mathcal{G}\left( {t}_{1}\right) ,\ldots ,\mathcal{G}\left( {t}_{n}\right) \right\rangle  }^{T}W\left\langle  {\mathcal{G}\left( {t}_{1}\right) ,\ldots ,\mathcal{G}\left( {t}_{n}\right) }\right\rangle   \leq  \delta$ , which can be encoded easily in 1tn.

在他最近的论文[15]中，古哈(Guha)主张需要为分布式表示(如基于嵌入的表示)建立一种新的模型理论。该论文勾勒了一个提案，其中项和(二元)谓词都被解释为$n$维实数空间中的点/向量。原子公式$P\left( {{t}_{1},\ldots ,{t}_{n}}\right)$的真值计算是通过比较与每个${t}_{i}$相关联的向量和与${P}_{i}$相关联的向量的投影来实现的。实逻辑与文献[15]有一个共同的观点，即项必须在几何空间中进行解释。然而，它对函数和谓词符号有不同(且更通用)的解释。实逻辑更通用，因为文献[15]中提出的语义可以在具有单层$\left( {k = 1}\right)$的${1tn}$中实现，因为计算$P\left( {{t}_{1},\ldots ,{t}_{m}}\right)$真值所需的投影和比较操作可以编码在一个${nm} \times  {nm}$矩阵$W$中，且满足约束条件${\left\langle  \mathcal{G}\left( {t}_{1}\right) ,\ldots ,\mathcal{G}\left( {t}_{n}\right) \right\rangle  }^{T}W\left\langle  {\mathcal{G}\left( {t}_{1}\right) ,\ldots ,\mathcal{G}\left( {t}_{n}\right) }\right\rangle   \leq  \delta$，这可以很容易地在模糊逻辑张量网络(1tn)中编码。

Real logic is orthogonal to the approach taken by (Hybrid) Markov Logic Networks (MLNs) and its variations [24, 29, 22]. In MLNs, the level of truth of a formula is determined by the number of models that satisfy the formula: the more models, the higher the degree of truth. Hybrid MLNs introduce a dependency from the real features associated to constants, which is given, and not learned. In real logic, instead, the level of truth of a complex formula is determined by (fuzzy) logical reasoning, and the relations between the features of different objects is learned through error minimization. Another difference is that MLNs work under the closed world assumption, while Real Logic is open domain. Much work has been done also on neuro-fuzzy approaches [19]. These are essentially propositional while real logic is first-order.

实逻辑与(混合)马尔可夫逻辑网络(MLN)及其变体所采用的方法[24, 29, 22]是正交的。在马尔可夫逻辑网络中，一个公式的真值水平由满足该公式的模型数量决定:模型越多，真值程度越高。混合马尔可夫逻辑网络引入了对与常量相关联的实特征的依赖，这些特征是给定的，而不是学习得到的。相反，在实逻辑中，一个复杂公式的真值水平由(模糊)逻辑推理决定，不同对象特征之间的关系通过误差最小化来学习。另一个区别是，马尔可夫逻辑网络在封闭世界假设下工作，而实逻辑是开放域的。在神经模糊方法方面也做了很多工作[19]。这些方法本质上是命题逻辑的，而实逻辑是一阶逻辑的。

Bayesian logic (BLOG) [20] is open domain, and in this respect similar to real logic and LTNs. But, instead of taking an explicit probabilistic approach, LTNs draw from the efficient approach used by tensor networks for knowledge graphs, as already discussed. LTNs can have a probabilistic interpretation but this is not a requirement. Other statistical AI and probabilistic approaches such as lifted inference fall into this category, including probabilistic variations of inductive logic programming (ILP) [23], which are normally restricted to Horn clauses. Metainterpretive ILP [21], together with BLOG, seem closer to LTNs in what concerns the knowledge representation language, but do not explore the benefits of tensor networks for computational efficiency.

贝叶斯逻辑(BLOG)[20]是开放域的，在这方面与实逻辑和模糊逻辑张量网络(LTN)类似。但是，模糊逻辑张量网络不是采用显式的概率方法，而是借鉴了张量网络用于知识图谱的高效方法，如前所述。模糊逻辑张量网络可以有概率解释，但这不是必需的。其他统计人工智能和概率方法，如提升推理，都属于这一类别，包括归纳逻辑编程(ILP)的概率变体[23]，这些方法通常局限于霍恩子句。元解释归纳逻辑编程(Metainterpretive ILP)[21]与贝叶斯逻辑(BLOG)在知识表示语言方面似乎更接近模糊逻辑张量网络，但没有探索张量网络在计算效率方面的优势。

An approach for embedding logical knowledge onto data for the purpose of relational learning, similar to Real Logic, is presented in [25]. Real Logic and [25] share the idea of interpreting a logical alphabet in an $n$ -dimensional real space. Terminologically, the term "grounding" in Real Logic corresponds to "embeddings" in [25]. However, there are several differences. First, [25] uses function-free langauges, while we provide also groundings for functional symbols. Second, the model used to compute the truth-values of atomic formulas adopted in [25] is a special case of the more general model proposed in this paper (as described in Eq. (2)). Finally, the semantics of the universal and existential quantifiers adopted in [25] is based on the closed-world assumption (CWA), i.e. universally (respectively, existentially) quantified formulas are reduced to the finite conjunctions (respectively, disjunctions) of all of their possible instantiations; Real Logic does not make the CWA. Furthermore, Real Logic does not assume a specific t-norm.

文献[25]提出了一种为关系学习将逻辑知识嵌入数据的方法，这与实逻辑(Real Logic)类似。实逻辑和文献[25]都有在$n$维实数空间中解释逻辑字母表的想法。从术语上讲，实逻辑中的“基化(grounding)”对应于文献[25]中的“嵌入(embeddings)”。然而，两者存在一些差异。首先，文献[25]使用无函数语言，而我们也为函数符号提供基化。其次，文献[25]中用于计算原子公式真值的模型是本文提出的更通用模型的一个特例(如公式(2)所述)。最后，文献[25]中采用的全称量词和存在量词的语义基于封闭世界假设(CWA)，即全称(分别地，存在)量化公式被简化为其所有可能实例的有限合取(分别地，析取)；实逻辑不做封闭世界假设。此外，实逻辑不假定特定的t-模。

As in [11], LTN is a framework for learning in the presence of logical constraints. LTNs share with [11] the idea that logical constraints and training examples can be treated uniformly as supervisions of a learning algorithm. LTN introduces two novelties: first, in LTN existential quantifiers are not grounded into a finite disjunction, but are scolemized. In other words, CWA is not required, and existentially quantified formulas can be satisfied by "new individuals". Second, LTN allows one to generate data for prediction. For instance, if a grounded theory contains the formula $\forall x\exists {yR}\left( {x, y}\right)$ , LTN generates a real function (corresponding to the grounding of the Skolem function introduced by the formula) which for every vector $\mathbf{v}$ returns the feature vector $f\left( \mathbf{v}\right)$ , which can be intuitively interpreted as being the set of features of a typical object which takes part in relation $R$ with the object having features equal to $\mathbf{v}$ .

与文献[11]一样，逻辑张量网络(LTN)是一个在逻辑约束下进行学习的框架。逻辑张量网络与文献[11]有相同的观点，即逻辑约束和训练示例可以统一视为学习算法的监督信息。逻辑张量网络引入了两个创新点:首先，在逻辑张量网络中，存在量词不被基化为有限析取，而是进行斯科伦化(scolemized)。换句话说，不需要封闭世界假设，存在量化公式可以由“新个体”满足。其次，逻辑张量网络允许为预测生成数据。例如，如果一个基化理论包含公式$\forall x\exists {yR}\left( {x, y}\right)$，逻辑张量网络会生成一个实函数(对应于该公式引入的斯科伦函数的基化)，对于每个向量$\mathbf{v}$，该函数返回特征向量$f\left( \mathbf{v}\right)$，这可以直观地解释为与特征等于$\mathbf{v}$的对象参与关系$R$的典型对象的特征集。

Finally, related work in the domain of neural-symbolic computing and neural network fibring [10] has sought to combine neural networks with ILP to gain efficiency [14] and other forms of knowledge representation, such as propositional modal logic and logic programming. The above are more tightly-coupled approaches. In contrast, LTNs use a richer FOL language, exploit the benefits of knowledge compilation and tensor networks within a more loosely- coupled approach, and might even offer an adequate representation of equality in logic. Experimental evaluations and comparison with other neural-symbolic approaches are desirable though, including the latest developments in the field, a good snapshot of which can be found in [1].

最后，神经符号计算和神经网络纤维化领域的相关工作[10]试图将神经网络与归纳逻辑编程(ILP)相结合以提高效率[14]，并结合其他形式的知识表示，如命题模态逻辑和逻辑编程。上述是更紧密耦合的方法。相比之下，逻辑张量网络使用更丰富的一阶逻辑(FOL)语言，在更松散耦合的方法中利用知识编译和张量网络的优势，甚至可能在逻辑中提供对相等性的充分表示。不过，进行实验评估并与其他神经符号方法进行比较是很有必要的，包括该领域的最新进展，文献[1]对此有很好的概述。

## 7 Conclusion and future work

## 7 结论与未来工作

We have proposed Real Logic: a uniform framework for learning and reasoning. Approximate satisfiability is defined as a learning task with both knowledge and data being mapped onto real-valued vectors. With an inference-as-learning approach, relational knowledge constraints and state-of-the-art data-driven approaches can be integrated. We showed how real logic can be implemented in deep tensor networks, which we call Logic Tensor Networks (LTNs), and applied efficiently to knowledge completion and data prediction tasks. As future work, we will make the implementation of LTN available in TENSORFLOW ${}^{\mathrm{{TM}}}$ and apply it to large-scale experiments and relational learning benchmarks for comparison with statistical relational learning, neural-symbolic computing, and (probabilistic) inductive logic programming approaches.

我们提出了实逻辑:一个用于学习和推理的统一框架。近似可满足性被定义为一个学习任务，其中知识和数据都被映射到实值向量上。通过将推理作为学习的方法，可以将关系知识约束和最先进的数据驱动方法集成起来。我们展示了如何在深度张量网络中实现实逻辑，我们将其称为逻辑张量网络(LTNs)，并将其有效地应用于知识补全和数据预测任务。作为未来的工作，我们将在TensorFlow ${}^{\mathrm{{TM}}}$中提供逻辑张量网络的实现，并将其应用于大规模实验和关系学习基准测试，以与统计关系学习、神经符号计算和(概率)归纳逻辑编程方法进行比较。

## References

## 参考文献

1. Cognitive Computation: Integrating Neural and Symbolic Approaches, Workshop at NIPS 2015, Montreal, Canada, April 2016. CEUR-WS 1583.

1. 认知计算:整合神经和符号方法，2015年神经信息处理系统大会(NIPS)研讨会，加拿大蒙特利尔，2016年4月。CEUR-WS 1583。

2. Knowledge Representation and Reasoning: Integrating Symbolic and Neural Approaches, AAAI Spring Symposium, Stanford University, CA, USA, March 2015.

2. 知识表示与推理:整合符号和神经方法，美国人工智能协会(AAAI)春季研讨会，美国加利福尼亚州斯坦福大学，2015年3月。

3. Dimitris Achlioptas. Random satisfiability. In Handbook of Satisfiability, pages 245-270. 2009.

3. 迪米特里斯·阿赫利奥普塔斯(Dimitris Achlioptas)。随机可满足性。《可满足性手册》，第245 - 270页。2009年。

4. Leon Barrett, Jerome Feldman, and Liam MacDermed. A (somewhat) new solution to the variable binding problem. Neural Computation, 20(9):2361-2378, 2008.

4. 利昂·巴雷特(Leon Barrett)、杰罗姆·费尔德曼(Jerome Feldman)和利亚姆·麦克德米德(Liam MacDermed)。变量绑定问题的(某种程度上)新解决方案。《神经计算》，20(9):2361 - 2378，2008年。

5. Yoshua Bengio. Learning deep architectures for ai. Found. Trends Mach. Learn., 2(1):1-127, January 2009.

5. 约书亚·本吉奥(Yoshua Bengio)。为人工智能学习深度架构。《机器学习基础与趋势》，2(1):1 - 127，2009年1月。

6. M. Bergmann. An Introduction to Many-Valued and Fuzzy Logic: Semantics, Algebras, and Derivation Systems. Cambridge University Press, 2008.

6. M. 伯格曼(M. Bergmann)。《多值和模糊逻辑导论:语义、代数和推导系统》。剑桥大学出版社，2008年。

7. David M. Blei, Andrew Y. Ng, and Michael I. Jordan. Latent dirichlet allocation. J. Mach. Learn. Res., 3:993-1022, March 2003.

7. 大卫·M·布莱(David M. Blei)、安德鲁·Y·吴(Andrew Y. Ng)和迈克尔·I·乔丹(Michael I. Jordan)。潜在狄利克雷分配(Latent dirichlet allocation)。《机器学习研究杂志》(J. Mach. Learn. Res.)，3:993 - 1022，2003年3月。

8. Léon Bottou. From machine learning to machine reasoning. Technical report, arXiv.1102.1808, February 2011.

8. 莱昂·博托(Léon Bottou)。从机器学习到机器推理(From machine learning to machine reasoning)。技术报告，arXiv.1102.1808，2011年2月。

9. Artur S. d'Avila Garcez, Marco Gori, Pascal Hitzler, and Luís C. Lamb. Neural-symbolic learning and reasoning (dagstuhl seminar 14381). Dagstuhl Reports, 4(9):50-84, 2014.

9. 阿图尔·S·达维拉·加尔塞斯(Artur S. d'Avila Garcez)、马尔科·戈里(Marco Gori)、帕斯卡尔·希茨勒(Pascal Hitzler)和路易斯·C·兰姆(Luís C. Lamb)。神经符号学习与推理(Neural - symbolic learning and reasoning)(达格斯图尔研讨会14381)。《达格斯图尔报告》(Dagstuhl Reports)，4(9):50 - 84，2014年。

10. Artur S. d'Avila Garcez, Luís C. Lamb, and Dov M. Gabbay. Neural-Symbolic Cognitive Reasoning. Cognitive Technologies. Springer, 2009.

10. 阿图尔·S·达维拉·加尔塞斯(Artur S. d'Avila Garcez)、路易斯·C·兰姆(Luís C. Lamb)和多夫·M·加贝(Dov M. Gabbay)。《神经符号认知推理》(Neural - Symbolic Cognitive Reasoning)。认知技术(Cognitive Technologies)。施普林格出版社(Springer)，2009年。

11. Michelangelo Diligenti, Marco Gori, Marco Maggini, and Leonardo Rigutini. Bridging logic and kernel machines. Machine Learning, 86(1):57-88, 2012.

11. 米开朗基罗·迪利根蒂(Michelangelo Diligenti)、马尔科·戈里(Marco Gori)、马尔科·马吉尼(Marco Maggini)和莱昂纳多·里古蒂尼(Leonardo Rigutini)。连接逻辑与核机器(Bridging logic and kernel machines)。《机器学习》(Machine Learning)，86(1):57 - 88，2012年。

12. David Silver et al. Mastering the game of go with deep neural networks and tree search. Nature, 529:484-503, 2016.

12. 大卫·西尔弗(David Silver)等人。利用深度神经网络和树搜索掌握围棋游戏(Mastering the game of go with deep neural networks and tree search)。《自然》(Nature)，529:484 - 503，2016年。

13. Martín Abadi et al. TensorFlow: Large-scale machine learning on heterogeneous systems, 2015. Software available from tensorflow.org.

13. 马丁·阿巴迪(Martín Abadi)等人。《TensorFlow:异构系统上的大规模机器学习》(TensorFlow: Large - scale machine learning on heterogeneous systems)，2015年。软件可从tensorflow.org获取。

14. Manoel V. M. França, Gerson Zaverucha, and Artur S. d'Avila Garcez. Fast relational learning using bottom clause propositionalization with artificial neural networks. Machine Learning, 94(1):81-104, 2014.

14. 马诺埃尔·V·M·弗兰萨(Manoel V. M. França)、格尔森·扎韦鲁查(Gerson Zaverucha)和阿图尔·S·达维拉·加尔塞斯(Artur S. d'Avila Garcez)。使用带有人工神经网络的底部子句命题化进行快速关系学习(Fast relational learning using bottom clause propositionalization with artificial neural networks)。《机器学习》(Machine Learning)，94(1):81 - 104，2014年。

15. Ramanathan Guha. Towards a model theory for distributed representations. In 2015 AAAI Spring Symposium Series, 2015.

15. 拉马纳坦·古哈(Ramanathan Guha)。迈向分布式表示的模型理论(Towards a model theory for distributed representations)。收录于2015年美国人工智能协会春季研讨会系列(2015 AAAI Spring Symposium Series)，2015年。

16. Michael Huth and Mark Ryan. Logic in Computer Science: Modelling and Reasoning About Systems. Cambridge University Press, New York, NY, USA, 2004.

16. 迈克尔·胡思(Michael Huth)和马克·瑞安(Mark Ryan)。《计算机科学中的逻辑:系统建模与推理》(Logic in Computer Science: Modelling and Reasoning About Systems)。剑桥大学出版社(Cambridge University Press)，美国纽约州纽约市，2004年。

17. Jeffrey O. Kephart and David M. Chess. The vision of autonomic computing. Computer, 36(1):41-50, January 2003.

17. 杰弗里·O·凯法特(Jeffrey O. Kephart)和大卫·M·切斯(David M. Chess)。自主计算的愿景(The vision of autonomic computing)。《计算机》(Computer)，36(1):41 - 50，2003年1月。

18. Douwe Kiela and Léon Bottou. Learning image embeddings using convolutional neural networks for improved multi-modal semantics. In Proceedings of EMNLP 2014, Doha, Qatar, 2014.

18. 杜韦·基拉(Douwe Kiela)和莱昂·博托(Léon Bottou)。使用卷积神经网络学习图像嵌入以改善多模态语义(Learning image embeddings using convolutional neural networks for improved multi - modal semantics)。收录于2014年自然语言处理经验方法会议论文集(Proceedings of EMNLP 2014)，卡塔尔多哈，2014年。

19. Bart Kosko. Neural Networks and Fuzzy Systems: A Dynamical Systems Approach to Machine Intelligence. Prentice-Hall, Inc., Upper Saddle River, NJ, USA, 1992.

19. 巴特·科斯克(Bart Kosko)。《神经网络与模糊系统:机器智能的动态系统方法》(Neural Networks and Fuzzy Systems: A Dynamical Systems Approach to Machine Intelligence)。普伦蒂斯 - 霍尔出版社(Prentice - Hall, Inc.)，美国新泽西州上萨德尔河，1992年。

20. Brian Milch, Bhaskara Marthi, Stuart J. Russell, David Sontag, Daniel L. Ong, and Andrey Kolobov. BLOG: probabilistic models with unknown objects. In IJCAI-05, Proceedings of the Nineteenth International Joint Conference on Artificial Intelligence, Edinburgh, Scotland, UK, July 30-August 5, 2005, pages 1352-1359, 2005.

20. 布赖恩·米尔奇(Brian Milch)、巴斯卡拉·马尔蒂(Bhaskara Marthi)、斯图尔特·J·拉塞尔(Stuart J. Russell)、大卫·桑塔格(David Sontag)、丹尼尔·L·翁(Daniel L. Ong)和安德烈·科洛博夫(Andrey Kolobov)。BLOG:具有未知对象的概率模型(BLOG: probabilistic models with unknown objects)。收录于2005年第十九届国际人工智能联合会议论文集(IJCAI - 05, Proceedings of the Nineteenth International Joint Conference on Artificial Intelligence)，英国苏格兰爱丁堡，2005年7月30日 - 8月5日，第1352 - 1359页，2005年。

21. Stephen H. Muggleton, Dianhuan Lin, and Alireza Tamaddoni-Nezhad. Meta-interpretive learning of higher-order dyadic datalog: predicate invention revisited. Machine Learning, 100(1):49-73, 2015.

21. 斯蒂芬·H·马格利顿(Stephen H. Muggleton)、林典焕(Dianhuan Lin)和阿里雷扎·塔马多尼 - 内扎德(Alireza Tamaddoni - Nezhad)。高阶二元Datalog的元解释学习:谓词发明再探讨(Meta - interpretive learning of higher - order dyadic datalog: predicate invention revisited)。《机器学习》(Machine Learning)，100(1):49 - 73，2015年。

22. Aniruddh Nath and Pedro M. Domingos. Learning relational sum-product networks. In Proceedings of the Twenty-Ninth AAAI Conference on Artificial Intelligence, January 25-30, 2015, Austin, Texas, USA., pages 2878-2886, 2015.

22. 阿尼尔鲁德·纳特(Aniruddh Nath)和佩德罗·M·多明戈斯(Pedro M. Domingos)。学习关系和积网络(Learning relational sum - product networks)。收录于2015年第二十九届美国人工智能协会会议论文集(Proceedings of the Twenty - Ninth AAAI Conference on Artificial Intelligence)，2015年1月25 - 30日，美国德克萨斯州奥斯汀，第2878 - 2886页，2015年。

23. Luc De Raedt, Kristian Kersting, Sriraam Natarajan, and David Poole. Statistical Relational Artificial Intelligence: Logic, Probability, and Computation. Synthesis Lectures on Artificial Intelligence and Machine Learning. Morgan & Claypool Publishers, 2016.

23. 卢克·德·雷德特(Luc De Raedt)、克里斯蒂安·克尔斯廷(Kristian Kersting)、斯里拉姆·纳塔拉詹(Sriraam Natarajan)和大卫·普尔(David Poole)。《统计关系人工智能:逻辑、概率与计算》(Statistical Relational Artificial Intelligence: Logic, Probability, and Computation)。人工智能与机器学习综合讲座(Synthesis Lectures on Artificial Intelligence and Machine Learning)。摩根与克莱普尔出版社(Morgan & Claypool Publishers)，2016年。

24. Matthew Richardson and Pedro Domingos. Markov logic networks. Mach. Learn., 62(1- 2):107-136, February 2006.

24. 马修·理查森(Matthew Richardson)和佩德罗·多明戈斯(Pedro Domingos)。马尔可夫逻辑网络(Markov logic networks)。《机器学习》(Mach. Learn.)，62(1 - 2):107 - 136，2006年2月。

25. Tim Rocktaschel, Sameer Singh, and Sebastian Riedel. Injecting logical background knowledge into embeddings for relation extraction. In Annual Conference of the North American Chapter of the Association for Computational Linguistics (NAACL), June 2015.

25. 蒂姆·罗克塔舍尔(Tim Rocktaschel)、萨米尔·辛格(Sameer Singh)和塞巴斯蒂安·里德尔(Sebastian Riedel)。将逻辑背景知识融入关系抽取的嵌入表示中。发表于2015年6月的北美计算语言学协会年会(Annual Conference of the North American Chapter of the Association for Computational Linguistics, NAACL)。

26. Richard Socher, Danqi Chen, Christopher D. Manning, and Andrew Y. Ng. Reasoning With Neural Tensor Networks For Knowledge Base Completion. In Advances in Neural Information Processing Systems 26. 2013.

26. 理查德·索切尔(Richard Socher)、陈丹琦(Danqi Chen)、克里斯托弗·D·曼宁(Christopher D. Manning)和吴恩达(Andrew Y. Ng)。使用神经张量网络进行知识库补全推理。发表于《神经信息处理系统进展26》(Advances in Neural Information Processing Systems 26)，2013年。

27. T. Tieleman and G. Hinton. Lecture 6.5 - RMSProp, COURSERA: Neural networks for machine learning. Technical report, 2012.

27. T·蒂勒曼(T. Tieleman)和G·辛顿(G. Hinton)。第6.5讲 - RMSProp，课程:机器学习神经网络。技术报告，2012年。

28. Leslie G. Valiant. Robust logics. In Proceedings of the Thirty-first Annual ACM Symposium on Theory of Computing, STOC '99, pages 642-651, New York, NY, USA, 1999. ACM.

28. 莱斯利·G·瓦利安特(Leslie G. Valiant)。鲁棒逻辑(Robust logics)。发表于1999年美国纽约举行的第三十一届ACM计算理论研讨会(Proceedings of the Thirty - first Annual ACM Symposium on Theory of Computing, STOC '99)，第642 - 651页。美国计算机协会(ACM)，1999年。

29. Jue Wang and Pedro M. Domingos. Hybrid markov logic networks. In Proceedings of the Twenty-Third AAAI Conference on Artificial Intelligence, AAAI 2008, Chicago, Illinois, USA, July 13-17, 2008, pages 1106-1111, 2008.

29. 王珏(Jue Wang)和佩德罗·M·多明戈斯(Pedro M. Domingos)。混合马尔可夫逻辑网络(Hybrid markov logic networks)。发表于2008年7月13 - 17日在美国伊利诺伊州芝加哥举行的第二十三届AAAI人工智能会议(Proceedings of the Twenty - Third AAAI Conference on Artificial Intelligence, AAAI 2008)，第1106 - 1111页，2008年。