# CLIP the Gap: A Single Domain Generalization Approach for Object Detection# 填补空白：针对对象检测的单域泛化方法

Vidit Vidit ${}^{1}{\text{Martin Engilberge}}^{1}{\text{Mathieu Salzmann}}^{1,2}$

Vidit Vidit ${}^{1}{\text{Martin Engilberge}}^{1}{\text{Mathieu Salzmann}}^{1,2}$

CVLab, EPFL ${}^{1}$, ClearSpace ${\mathrm{{SA}}}^{2}$

CVLab, EPFL ${}^{1}$, ClearSpace ${\mathrm{{SA}}}^{2}$

firstname.lastname@epfl.ch

## Abstract

## 摘要

Single Domain Generalization (SDG) tackles the problem of training a model on a single source domain so that it generalizes to any unseen target domain. While this has been well studied for image classification, the literature on SDG object detection remains almost non-existent. To address the challenges of simultaneously learning robust object localization and representation, we propose to leverage a pre-trained vision-language model to introduce semantic domain concepts via textual prompts. We achieve this via a semantic augmentation strategy acting on the features extracted by the detector backbone, as well as a text-based classification loss. Our experiments evidence the benefits of our approach, outperforming by ${10}\%$ the only existing SDG object detection method, Single-DGOD [49], on their own diverse weather-driving benchmark.

单域泛化（SDG）解决了在单一源域上训练模型，使其泛化到任何未见过的目标域的问题。尽管这在图像分类方面已经得到了广泛研究，但在SDG对象检测方面的文献几乎不存在。为了解决同时学习鲁棒对象定位和表示的挑战，我们提出利用预训练的视觉-语言模型，通过文本提示引入语义域概念。我们通过在检测器主干提取的特征上实施语义增强策略，以及基于文本的分类损失来实现这一点。我们的实验证明了我们方法的优势，比现有的唯一一种SDG对象检测方法Single-DGOD [49]在其自己的多样化天气驾驶基准上表现更优 ${10}\%$。

## 1. Introduction

## 1. 引言

As for most machine learning models, the performance of object detectors degrades when the test data distribution deviates from the training data one. Domain adaptation techniques $\left\lbrack {3,5,8,{30},{41},{43}}\right\rbrack$ try to alleviate this problem by learning domain invariant features between a source and a known target domain. In practice, however, it is not always possible to obtain target data, even unlabeled, precluding the use of such techniques. Domain generalization tackles this by seeking to learn representations that generalize to any target domain. While early approaches $\left\lbrack {1,{10},{25},{26},{28},{47},{57}}\right\rbrack$ focused on the scenario where multiple source domains are available during training, many recent methods tackle the more challenging, yet more realistic, case of Single Domain Generalization (SDG), aiming to learn to generalize from a single source dataset. While this has been well studied for image classification $\left\lbrack {{13},{35},{45},{48},{56}}\right\rbrack$, it remains a nascent topic in object detection. To the best of our knowledge, a single existing approach, Single-DGOD [49], uses disentanglement and self-distillation [22] to learn domain-invariant features.

对于大多数机器学习模型来说，当测试数据分布与训练数据分布不一致时，目标检测器的性能会下降。域自适应技术 $\left\lbrack {3,5,8,{30},{41},{43}}\right\rbrack$ 试图通过学习源域和已知目标域之间的域不变特征来缓解这个问题。然而在实际操作中，往往无法获得目标数据，即使是未标记的，这也阻碍了这些技术的使用。域泛化通过寻求学习能够泛化到任何目标域的表征来解决这一问题。虽然早期的方法 $\left\lbrack {1,{10},{25},{26},{28},{47},{57}}\right\rbrack$ 专注于在训练期间有多个源域可用的情况，但许多最近的方法解决了更具挑战性，也更现实的单域泛化（SDG）案例，旨在从单个源数据集中学习泛化。尽管这在图像分类 $\left\lbrack {{13},{35},{45},{48},{56}}\right\rbrack$ 中已经得到了广泛研究，但在目标检测中仍然是一个新兴话题。据我们所知，现有的唯一方法，Single-DGOD [49]，使用解耦和自蒸馏 [22] 来学习域不变特征。

In this paper, we introduce a fundamentally different approach to SDG for object detection. To this end, we build on two observations: (i) Unsupervised/self-supervised pretraining facilitates the transfer of a model to new tasks $\lbrack 2$ , 4, 18]; (ii) Exploiting language supervision to train vision models allows them to generalize more easily to new categories and concepts $\left\lbrack {9,{36}}\right\rbrack$ . Inspired by this, we therefore propose to leverage a self-supervised vision-language model, CLIP [36], to guide the training of an object detector so that it generalizes to unseen target domains. Since the visual CLIP representation has been jointly learned with the textual one, we transfer text-based domain variations to the image representation during training, thus increasing the diversity of the source data.

在本文中，我们为对象检测的SDG引入了一种根本不同的方法。为此，我们基于两个观察： (i) 无监督/自监督预训练促进了模型转移到新任务 $\lbrack 2$ ，4, 18]； (ii) 利用语言监督训练视觉模型使它们更容易泛化到新的类别和概念 $\left\lbrack {9,{36}}\right\rbrack$ 。受到这一点的启发，我们因此提议利用自监督视觉语言模型，CLIP [36]，来指导对象检测器的训练，使其能够泛化到未见过的目标域。由于视觉CLIP表征是与文本表征联合学习的，我们在训练期间将基于文本的域变化转移到图像表征上，从而增加了源数据的多样性。

![0192367a-4b8f-7f32-ba78-beeff5704357_0_169551.jpg](images/0192367a-4b8f-7f32-ba78-beeff5704357_0_169551.jpg)

Figure 1. Semantic Augmentation: We compare the PCA projections of CLIP [36] image embeddings obtained in two different manners: (Top) The embeddings were directly obtained from the real images from 5 domains corresponding to different weather conditions. (Bottom) The embeddings were obtained from the day images only and modified with our semantic augmentation strategy based on text prompts to reflect the other 4 domains. Note that the relative positions of the clusters in the bottom plot resembles that of the top one, showing that our augmentations let us generalize to different target domains. The principal components used are the same for both the figures.

图1. 语义增强：我们比较了通过两种不同方式获得的CLIP [36] 图像嵌入的PCA投影：（顶部）嵌入直接来自与不同天气条件对应的5个域的实时图像。（底部）嵌入仅来自白天图像，并通过基于文本提示的我们的语义增强策略进行修改以反映其他4个域。请注意，底部图中簇的相对位置与顶部图中的相似，表明我们的增强方法使我们能够泛化到不同的目标域。两个图形中使用的主成分是相同的。

Specifically, we define textual prompts describing potential target domain concepts, such as weather and daytime variations for road scene understanding, and use these prompts to perform semantic augmentations of the images. These augmentations, however, are done in feature space, not in image space, which is facilitated by the joint image-text CLIP latent space. This is illustrated in Fig. 1, which shows that, even though we did not use any target data for semantic augmentation, the resulting augmented embed-dings reflect the distributions of the true image embeddings from different target domains.

具体来说，我们定义了描述潜在目标域概念的文本提示，例如用于道路场景理解的天气和白天变化，并使用这些提示对图像进行语义增强。然而，这些增强是在特征空间中进行的，而不是在图像空间中，这是由联合图像-文本CLIP潜在空间实现的。这在图1中有所说明，该图显示，尽管我们没有使用任何目标数据来进行语义增强，但得到的增强嵌入反映了来自不同目标域的真实图像嵌入的分布。

We show the effectiveness of our method on the SDG driving dataset of [49], which reflects a practical scenario where the training (source) images were captured on a clear day whereas the test (target) ones were acquired in rainy, foggy, night, and dusk conditions. Our experiments demonstrate the benefits of our approach over the Single-DGOD [49] one.

我们在[49]的SDG驾驶数据集上展示了我们方法的有效性，该数据集反映了一个实际场景，其中训练（源）图像是在晴朗的日子里捕获的，而测试（目标）图像则是在雨天、雾天、夜晚和黄昏条件下获取的。我们的实验证明了我们的方法相对于Single-DGOD [49]的优越性。

To summarize our contributions, we employ a vision-language model to improve the generalizability of an object detector; during training, we introduce domain concepts via text-prompts to augment the diversity of the learned image features and make them more robust to an unseen target domain. This enables us to achieve state-of-the-art results on the diverse weather SDG driving benchmark of [49].

总结我们的贡献，我们采用了一个视觉-语言模型来提高对象检测器的泛化性；在训练过程中，我们通过文本提示引入域概念来增强学习到的图像特征的多样性，并使它们对未见过的目标域更加鲁棒。这使我们能够在[49]的多样化天气SDG驾驶基准上取得最先进的结果。

## 2. Related Work

## 2. 相关工作

Domain Adaptation for Object Detection. Domain adaptation methods seek to align the source domain distribution to a particular target domain. To bridge the global and instance-level domain gaps, $\left\lbrack {3,5,{41},{43}}\right\rbrack$ learn feature alignment via [15] adversarial training; [58] and [46] utilize category-level centroids and attention maps, respectively, to better align instances in the two domains; $\left\lbrack {8,{30}}\right\rbrack$ generate pseudo-labels in the target domain and use them for target-aware training. Domain adaptation, however, assumes that images from the target domain are available during training. In contrast, domain generalization aims to learn models that generalize to domains that were not seen at all during training. Below, we focus on the domain generalization methods that, as us, use a single source domain to do so.

领域自适应对象检测。领域自适应方法旨在将源领域分布与特定目标领域对齐。为了弥合全局和实例级别的领域差距，$\left\lbrack {3,5,{41},{43}}\right\rbrack$ 通过对抗训练学习特征对齐；[58] 和 [46] 分别利用类别级质心和注意力图来更好地对齐两个领域中的实例；$\left\lbrack {8,{30}}\right\rbrack$ 在目标领域生成伪标签并用于目标感知训练。然而，领域自适应假设在训练期间可以使用目标领域的图像。相比之下，领域泛化旨在学习能够泛化到训练期间完全没有见过的领域的模型。下面，我们关注的是使用单一源领域进行领域泛化的方法。

Single Domain Generalization (SDG). Several image classification works $\left\lbrack {{13},{35},{45},{48},{56}}\right\rbrack$ have proposed strategies to improve the performance on unseen domains while training on a single source domain. In particular, $\left\lbrack {{35},{45},{48}}\right\rbrack$ introduce data augmentation strategies where diverse input images are generated via adversarial training; [13, 56] propose normalization techniques to adapt the feature distribution to unseen domains. While SDG has been reasonably well studied for image classification, the case of object detection remains largely unexplored, and poses additional challenges related to the need to further localize the objects of interest. This was recently tackled by Single-DGOD [49] with an approach relying on learning domain-specific and domain-invariant features. Specifically, this was achieved by exploiting contrastive learning to disentangle the features and self-distillation [22] to further improve the network's generalizability. Here, we introduce a fundamentally different approach that leverages the CLIP [36] pre-trained model and semantically augments the data using textual prompts. As will be shown by our results, our method outperforms the state-of-the-art Single-DGOD [49].

单一领域泛化（SDG）。一些图像分类工作$\left\lbrack {{13},{35},{45},{48},{56}}\right\rbrack$提出了在单一源领域训练时提高未见领域性能的策略。特别是$\left\lbrack {{35},{45},{48}}\right\rbrack$引入了数据增强策略，通过对抗训练生成多样化的输入图像；[13, 56]提出了归一化技术以适应未见领域的特征分布。尽管SDG在图像分类方面已经得到了相当充分的研究，但在对象检测方面仍然在很大程度上未被探索，并且带来了需要进一步定位感兴趣对象的其他挑战。最近，Single-DGOD [49] 通过依赖学习领域特定和领域不变特征的方法解决了这个问题。具体来说，这是通过利用对比学习来分离特征和自蒸馏[22]来进一步提高网络的泛化性实现的。在这里，我们引入了一种本质上不同的方法，它利用了CLIP [36] 预训练模型，并通过文本提示语义增强数据。正如我们的结果所示，我们的方法优于最先进的Single-DGOD [49]。

Vision-Language Models. Jointly learning a representation of images and text has been studied in many works [9, ${11},{12},{14},{24},{27},{36},{55}\rbrack$ . They use image-text pairs to train visual-semantic embeddings which can be used not only for image classification, captioning or retrieval but also for zero-shot prediction on unseen labels. VirTex [9] relies on image-caption-based pre-training to learn a rich visual embedding from a small amount of data. CLIP [36] proposes a scalable contrastive pre-training method for joint text and image feature learning. CLIP leverages a corpus of 400 million image-text pairs and a large language model [37] to learn a joint embedding space, which was shown to have superior zero-shot learning ability on classification tasks. The image-text-based training is also useful for Open Vocabulary Detection (OVD) [53], where the objects are detected using arbitrary textual descriptions. To address this task, [53] train their own visual-semantic representation, whereas $\left\lbrack {{16},{39}}\right\rbrack$ employ CLIP embeddings. Recently, $\left\lbrack {{29},{54}}\right\rbrack$ introduced a phrase-grounding-based pre-training for better OVD and zero-shot object detection. In contrast to these works, whose objective is to generalize to novel categories or objects, we seek to generalize to new domains depicting the same object categories as the source one.

视觉-语言模型。在许多作品中研究了图像和文本的联合学习表示[9, ${11},{12},{14},{24},{27},{36},{55}\rbrack$。他们使用图像-文本对来训练视觉-语义嵌入，这些嵌入不仅可以用于图像分类、配字或检索，还可以用于在未见过的标签上进行零样本预测。VirTex [9] 依赖于基于图像-配字的预训练来从少量数据中学习丰富的视觉嵌入。CLIP [36] 提出了一种可扩展的对比预训练方法，用于联合文本和图像特征学习。CLIP 利用了一个包含4亿个图像-文本对的语料库和一个大型语言模型 [37] 来学习一个联合嵌入空间，该空间在分类任务上显示出优越的零样本学习能力。基于图像-文本的训练对于开放词汇检测（OVD）[53] 也很有用，其中对象使用任意文本描述进行检测。为了解决这个任务，[53] 训练他们自己的视觉-语义表示，而 $\left\lbrack {{16},{39}}\right\rbrack$ 则使用CLIP嵌入。最近，$\left\lbrack {{29},{54}}\right\rbrack$ 引入了一种基于短语定位的预训练，以更好地进行OVD和零样本目标检测。与这些旨在推广到新类别或对象的作品不同，我们试图推广到描绘与源类别相同对象类别的新域。

## 3. Method

## 3. 方法

Let us now introduce our approach to exploiting a vision-language model for single-domain generalization in object detection. Below, we first present our semantic augmentation strategy aiming to facilitate generalization to new domains. We then describe the architecture and training strategy for our object detector.

现在我们来介绍我们的方法，利用视觉-语言模型进行单域泛化在目标检测中。下面，我们首先介绍我们的语义增强策略，旨在促进对新域的泛化。然后，我们描述我们的目标检测器的架构和训练策略。

![0192367a-4b8f-7f32-ba78-beeff5704357_2_938781.jpg](images/0192367a-4b8f-7f32-ba78-beeff5704357_2_938781.jpg)

Figure 2. Our Approach: (Left) We first estimate a set of semantic augmentations $\mathcal{A}$ using a set of textual domain prompts $\left\{ {{\mathcal{P}}^{t},{p}^{s}}\right\}$ and source domain images. The goal of these semantic augmentations is to translate source domain image embeddings to the domain specified by the prompts. We can do this because of the CLIP's joint embedding space and its ability to encode semantic relationships via algebraic operations. ${\mathcal{L}}_{\text{opt }}$ is minimized w.r.t $\mathcal{A}$ over random image crops of the same size as CLIP [36]. (Right) The optimized semantic augmentations are used to train our modified detector which minimizes a text-based classification loss ${\mathcal{L}}_{\text{clip-t }}$ . Here, we train with the full image and add a randomly sampled ${\mathcal{A}}_{j}$ after average pooling. This pooling operation allows us to use $\mathcal{A}$ on extracted feature maps of the arbitrary-sized image. We initialize the detector with the pre-trained CLIP [36] $\mathcal{V}$ and $\mathcal{T}$ encoders to leverage their general representations.

图 2. 我们的方法：(左) 我们首先使用一组文本领域提示 $\mathcal{A}$ 和源领域图像估计一组语义增强 $\left\{ {{\mathcal{P}}^{t},{p}^{s}}\right\}$。这些语义增强的目标是将源领域图像嵌入转换为由提示指定的领域。我们能够做到这一点是因为 CLIP 的联合嵌入空间及其通过代数运算编码语义关系的能力。 ${\mathcal{L}}_{\text{opt }}$ 是关于与 CLIP [36] 同尺寸的随机图像裁剪的 $\mathcal{A}$ 最小化。 (右) 优化的语义增强被用于训练我们修改后的检测器，该检测器最小化基于文本的分类损失 ${\mathcal{L}}_{\text{clip-t }}$。在这里，我们使用完整的图像，并在平均池化后添加一个随机采样的 ${\mathcal{A}}_{j}$。这种池化操作允许我们在任意大小图像提取的特征图上使用 $\mathcal{A}$。我们使用预训练的 CLIP [36] $\mathcal{V}$ 和 $\mathcal{T}$ 编码器初始化检测器，以利用它们的一般表示。

## 3.1. Semantic Augmentation

## 3.1. 语义增强

In SDG, we have access to images from only a single domain. To enable generalization, we seek to learn object representations that are robust to domain shifts. Here, we do so by introducing such shifts while training the model on the source data. Specifically, we exploit CLIP's joint representation to estimate shifts in the visual domain using textual prompts, as illustrated in Fig. 1. This corresponds to the optimization step shown in the left portion of Fig. 2.

在 SDG 中，我们只能访问来自单一领域的图像。为了实现泛化，我们寻求学习对领域转换具有鲁棒性的对象表示。在这里，我们在训练模型时引入这样的转换。具体来说，我们利用 CLIP 的联合表示，使用文本提示估计视觉领域的转换，如图 1 所示。这对应于图 2 左部分所示的优化步骤。

Formally, let $\mathcal{T}$ denote CLIP’s text encoder and $\mathcal{V}$ its image one. For reasons that will become clear later, we further split $\mathcal{V}$ into a feature extractor ${\mathcal{V}}^{a}$ and a projector to the embedding space ${\mathcal{V}}^{b}$ . The CLIP [36] model is trained to bring image features closer to their textual captions. In essence, this means that, for an image $\mathcal{I}$ and a corresponding prompt $p$, it seeks to minimize the distance between ${\mathcal{V}}^{b}\left( {{\mathcal{V}}^{a}\left( I\right) }\right)$ and $\mathcal{T}\left( p\right)$ .

形式上，令 $\mathcal{T}$ 表示 CLIP 的文本编码器，$\mathcal{V}$ 表示其图像编码器。出于稍后将会明了的原因，我们进一步将 $\mathcal{V}$ 分割为一个特征提取器 ${\mathcal{V}}^{a}$ 和一个到嵌入空间的投影器 ${\mathcal{V}}^{b}$。CLIP [36] 模型被训练以使图像特征更接近其文本标题。本质上，这意味着对于一张图像 $\mathcal{I}$ 和相应的提示 $p$，它试图最小化 ${\mathcal{V}}^{b}\left( {{\mathcal{V}}^{a}\left( I\right) }\right)$ 和 $\mathcal{T}\left( p\right)$ 之间的距离。

A useful property of the text embedding space is that algebraic operations can be used to estimate semantically related concepts. Word2Vec [31] had demonstrated such a learned relationship (e.g. king-man+woman approaches the word representation of queen). Such a relationship exists with CLIP embeddings as well [38].

文本嵌入空间的一个有用属性是，代数运算可以用来估计语义上相关的概念。Word2Vec [31] 已经证明了这样的学习关系（例如，king-man+woman 接近于 queen 的词表示）。这样的关系在 CLIP 嵌入中同样存在 [38]。

To exploit this for SDG, we define a generic textual prompt ${p}^{s}$ related to the source domain, such as An image taken during the day, and a set of prompts ${\mathcal{P}}^{t} =$ ${\left\{ {p}_{j}^{t}\right\} }_{1}^{M}$ encompassing variations that can be expected to occur in different target domains, e.g, describing different weather conditions or times of the day. Our objective then is to define augmentations $\left\{ {\mathcal{A}}_{j}\right\}$ of the features extracted from a source image such that the shift incurred by ${\mathcal{A}}_{j}$ corresponds to the semantic difference between ${p}^{s}$ and ${p}_{j}^{t}$ .

为了利用这一点来实现 SDG，我们定义了一个与源域相关的通用文本提示 ${p}^{s}$，例如“白天拍摄的照片”，以及一组涵盖在不同目标域中可能出现的变化的提示 ${\mathcal{P}}^{t} =$ ${\left\{ {p}_{j}^{t}\right\} }_{1}^{M}$，例如描述不同的天气条件或一天中的不同时间。我们的目标然后是定义源图像提取特征的增强 $\left\{ {\mathcal{A}}_{j}\right\}$，使得 ${\mathcal{A}}_{j}$ 引起的迁移对应于 ${p}^{s}$ 和 ${p}_{j}^{t}$ 之间的语义差异。

To achieve this, we first compute the embeddings ${q}^{s} =$ $\mathcal{T}\left( {p}^{s}\right)$ and ${q}_{j}^{t} = \mathcal{T}\left( {p}_{j}^{t}\right)$ of the textual prompt. We then take multiple random crops from a source image. For each such crop ${\mathcal{I}}_{\text{crop }}$, we create a target image embedding

为了实现这一点，我们首先计算文本提示的嵌入 ${q}^{s} =$ $\mathcal{T}\left( {p}^{s}\right)$ 和 ${q}_{j}^{t} = \mathcal{T}\left( {p}_{j}^{t}\right)$。然后我们从源图像中裁剪多个随机块。对于每个这样的块 ${\mathcal{I}}_{\text{crop }}$，我们创建一个目标图像嵌入

$$
{z}_{j}^{ * } = z + \frac{{q}_{j}^{t} - {q}^{s}}{{\begin{Vmatrix}{q}_{j}^{t} - {q}^{s}\end{Vmatrix}}_{2}}, \tag{1}
$$

where $z = \mathcal{V}\left( {\mathcal{I}}_{\text{crop }}\right)$ . We then search for an augmentation ${\mathcal{A}}_{j} \in {\mathbb{R}}^{H \times W \times C}$ such that

其中 $z = \mathcal{V}\left( {\mathcal{I}}_{\text{crop }}\right)$。然后我们寻找一个增强 ${\mathcal{A}}_{j} \in {\mathbb{R}}^{H \times W \times C}$ 使得

$$
{\bar{z}}_{j} = {\mathcal{V}}^{b}\left( {{\mathcal{V}}^{a}\left( {\mathcal{I}}_{\text{crop }}\right) + {\mathcal{A}}_{j}}\right) \tag{2}
$$

is as similar as possible to ${z}_{j}^{ * }$, which we measure with the cosine similarity. Ultimately, we estimate the augmentations ${\left\{ {\mathcal{A}}_{j}\right\} }_{1}^{M}$ through an optimization process using only source domain images. Specifically, we minimize the loss function

与 ${z}_{j}^{ * }$ 尽可能相似，我们使用余弦相似度来衡量。最终，我们通过仅使用源域图像的优化过程来估计增强 ${\left\{ {\mathcal{A}}_{j}\right\} }_{1}^{M}$ 。具体来说，我们最小化损失函数

$$
{\mathcal{L}}_{\text{opt }} = \mathop{\sum }\limits_{{\mathcal{I}}_{\text{crop }}}\mathop{\sum }\limits_{j}\mathcal{D}\left( {{z}_{j}^{ * },{\bar{z}}_{j}}\right) + {\begin{Vmatrix}{\bar{z}}_{j} - z\end{Vmatrix}}_{1} \tag{3}
$$

where

其中

$$
\mathcal{D}\left( {a, b}\right) = 1 - \frac{a - b}{\parallel a - b{\parallel }_{2}} \tag{4}
$$

is the cosine distance. The loss also includes an ${l}_{1}$ regularizer that prevents the embeddings from deviating too far from their initial values, so as to preserve the image content.

是余弦距离。损失函数还包括一个 ${l}_{1}$ 正则化项，防止嵌入向量偏离其初始值太远，从而保留图像内容。

As the objective is to estimate the meaningful feature augmentation while preserving the original CLIP pretraining, we keep the image crop size the same as the original CLIP training. Note that the optimization of the augmentations is done once in an offline stage, and we then use the resulting augmentations to train our detector.

由于目标是估计有意义的特征增强的同时保留原始 CLIP 预训练，我们保持图像裁剪大小与原始 CLIP 训练相同。请注意，增强的优化是在离线阶段完成一次，然后我们使用得到的增强来训练我们的检测器。

![0192367a-4b8f-7f32-ba78-beeff5704357_3_652683.jpg](images/0192367a-4b8f-7f32-ba78-beeff5704357_3_652683.jpg)

Figure 3. Diverse Weather Dataset [49]: Day-Clear acts as our source domain while the other weather condition are our target domains. In these domains, the objects' appearance drastically changes from the Day-Clear scenario. As we do not utilize any target domain images, learning generalizable features on source images is crucial for the SDG task.

图 3. 多样化天气数据集 [49]：白天晴朗作为我们的源域，而其他天气条件是我们的目标域。在这些域中，物体的外观与白天晴朗场景相比有显著变化。由于我们没有使用任何目标域图像，因此在源图像上学习可泛化的特征对于 SDG 任务至关重要。

## 3.2. Architecture

## 3.2. 架构

Let us now describe our detector architecture. As shown in the right portion of Fig. 2, it follows a standard Faster-RCNN [40] structure but departs from it in two ways. First, to exploit the augmentations optimized as discussed in the previous section, we initialize the blocks before and after the ROI align one with the corresponding ${\mathcal{V}}^{a}$ and ${\mathcal{V}}^{b}$ modules of the ResNet-based trained CLIP model. Second, to further leverage the vision-language model, we incorporate a text-based classifier in our model's head. Note that, in contrast to OVD $\left\lbrack {{16},{39}}\right\rbrack$ where a text-based classifier is used to handle novel categories, we employ it to keep the image features close to the pre-trained joint embedding space.

现在我们来描述我们的检测器架构。如图 2 右部分所示，它遵循标准的 Faster-RCNN [40] 结构，但在两个方面有所不同。首先，为了利用前一部分讨论中优化的增强，我们在 ROI 对齐之前和之后的块中使用与基于 ResNet 训练的 CLIP 模型的相应 ${\mathcal{V}}^{a}$ 和 ${\mathcal{V}}^{b}$ 模块进行初始化。其次，为了进一步利用视觉-语言模型，我们在模型头部加入了一个基于文本的分类器。请注意，与 OVD $\left\lbrack {{16},{39}}\right\rbrack$ 不同，后者使用基于文本的分类器来处理新颖类别，我们则是用它来保持图像特征接近预训练的联合嵌入空间。

Specifically, we define textual prompts that represent the individual categories we seek to detect, and extract corresponding embeddings $\mathcal{Q} \in {\mathbb{R}}^{\left( {K + 1}\right) \times {D}_{\text{clip }}}$, for $K$ categories and the background class, using the text encoder $\mathcal{T}$ . For a candidate image region $r$ proposed by the Region Proposal Network(RPN) [40], we then compute the cosine similarities between the text embeddings $\mathcal{Q}$ and the features ${\mathcal{F}}_{r} \in {\mathbb{R}}^{{D}_{\text{clip }}}$ obtained by projection to the embedding space using ${\mathcal{V}}^{b}$ after ROI-Align [19] and the text embeddings $\mathcal{Q}$ . These cosine similarities, $\operatorname{sim}\left( {{\mathcal{F}}_{r},\mathcal{Q}}\right) \in {\mathbb{R}}^{K + 1}$, act as log-its to the softmax based cross-entropy loss

具体来说，我们定义了表示我们希望检测的各个类别的文本提示，并使用文本编码器 $\mathcal{Q} \in {\mathbb{R}}^{\left( {K + 1}\right) \times {D}_{\text{clip }}}$ 提取相应的嵌入向量 $K$ ，用于 $\mathcal{T}$ 类别和背景类别。对于区域建议网络（RPN）[40] 提出的候选图像区域 $r$ ，我们接着计算文本嵌入向量 $\mathcal{Q}$ 与通过 ${\mathcal{V}}^{b}$ 在 ROI-Align [19] 之后投影到嵌入空间中得到的特征 ${\mathcal{F}}_{r} \in {\mathbb{R}}^{{D}_{\text{clip }}}$ 之间的余弦相似度 $\operatorname{sim}\left( {{\mathcal{F}}_{r},\mathcal{Q}}\right) \in {\mathbb{R}}^{K + 1}$ 。这些余弦相似度作为对数几率，用于基于softmax的交叉熵损失。

$$
{\mathcal{L}}_{\text{clip-t }} = \mathop{\sum }\limits_{r}{\mathcal{L}}_{CE}\left( \frac{{e}^{\operatorname{sim}\left( {{\mathcal{F}}_{r},{\mathcal{Q}}_{k}}\right) }}{\mathop{\sum }\limits_{{k = 0}}^{K}{e}^{\operatorname{sim}\left( {{\mathcal{F}}_{r},{\mathcal{Q}}_{k}}\right) }}\right) . \tag{5}
$$

Similarly to [36], we formulate prompts of the form a photo of a \{category name\} to obtain our text embeddings.

与 [36] 类似，我们制定了形如“一张 {类别名称} 的照片”的提示，以获得我们的文本嵌入向量。

## 3.3. Training with Augmentation

## 3.3. 增量训练

Following the standard detector training [40], we use the full image as our input. This subsequently increases the output feature map size of ${\mathcal{V}}^{a}$, hence we use average pooling operation and obtain channel-wise augmentations which can work for arbitrary-sized feature maps. The training of our modified object detector with the semantic augmentations is as follows, first, we randomly sample an augmentation ${\mathcal{A}}_{j}$ from the full set and collapse its spatial dimension using average pooling. We then add the resulting vector to every element in the feature map extracted by ${\mathcal{V}}^{a}$ . In practice, we apply augmentations to a batch with a probability $\theta$ .

在遵循标准检测器训练 [40] 的基础上，我们将整个图像作为输入。这随后增加了 ${\mathcal{V}}^{a}$ 输出特征图的尺寸，因此我们使用平均池操作并获取通道增强，这些增强可以适用于任意大小的特征图。我们的改进对象检测器使用语义增强进行训练的方式如下：首先，我们从完整集合中随机采样一个增强 ${\mathcal{A}}_{j}$ 并使用平均池操作折叠其空间维度。然后，我们将得到的向量添加到由 ${\mathcal{V}}^{a}$ 提取的特征图中的每个元素。在实践中，我们以概率 $\theta$ 应用增强。

The detector is then trained with the loss

检测器随后使用以下损失进行训练：

$$
{\mathcal{L}}_{\text{det }} = {\mathcal{L}}_{\text{rpn }} + {\mathcal{L}}_{\text{reg }} + {\mathcal{L}}_{\text{clip-t }} \tag{6}
$$

which combines the ${\mathcal{L}}_{\text{clip-t }}$ loss of Eq. (5) with the standard RPN and regression losses [40]. During inference, we use the detector without any augmentation of the feature maps.

该损失结合了方程式（5）中的 ${\mathcal{L}}_{\text{clip-t }}$ 损失与标准 RPN 和回归损失 [40]。在推理过程中，我们不使用特征图的任何增强。

## 4. Experiments

## 4. 实验

## 4.1. Experimental setup

## 4.1. 实实验设置

Datasets. To evaluate our model, we use the same datasets as [49]. They include five sets, each containing images with different weather conditions: daytime sunny, night clear, dusk rainy, night rainy, and daytime foggy. The images have been selected from three primary datasets, Berkeley Deep Drive 100K (BBD-100K) [52], Cityscapes [7] and Adverse-Weather [17]. Additionally, rainy images are rendered by [50], and some of the foggy images are synthetically generated from [42]. Our model is trained on the daytime sunny scenes, consisting of 19,395 training images, the remaining 8,313 daytime sunny images are used for validation and model selection. The four other weather conditions are only used during testing. They consist of 26,158 images of clear night scenes, 3501 images of rainy scenes at dusk, 2494 images of rainy scenes at night, and 3775 images of foggy scenes during daytime. All the datasets contain bounding box annotations for the objects bus, bike, car; motorbike, person, rider and truck. Fig. 3 shows examples from this dataset.

数据集。为了评估我们的模型，我们使用了与 [49] 相同的数据集。它们包括五个集合，每个集合包含不同天气条件下的图像：白天晴朗、夜晚晴朗、黄昏雨天、夜晚雨天和白天雾天。这些图像是从三个主要数据集中选取的，分别是伯克利深度驾驶 100K（BBD-100K）[52]、Cityscapes [7] 和 Adverse-Weather [17]。此外，雨天图像是由 [50] 渲染的，部分雾天图像是通过 [42] 合成生成的。我们的模型在白天晴朗场景上进行训练，包括 19,395 张训练图像，剩余的 8,313 张白天晴朗图像用于验证和模型选择。其他四种天气条件仅在测试时使用。它们包括 26,158 张夜晚晴朗场景的图像、3,501 张黄昏雨天的图像、2,494 张夜晚雨天的图像和 3,775 张白天雾天的图像。所有数据集都包含对象 bus、bike、car；motorbike、person、rider 和 truck 的边界框注释。图 3 展示了此数据集的示例。

Metric. In all our experiments, we use the Mean Average Precision (mAP) as our metric. Specifically, following [49], we report the mAP@0.5, which considers a prediction as a true positive if it matches the ground-truth label and has an intersection over union (IOU) score of more than 0.5 with the ground-truth bounding box.

指标。在所有实验中，我们使用平均精度均值（mAP）作为我们的指标。具体来说，遵循 [49]，我们报告 mAP@0.5，如果预测结果与真实标签匹配并且与真实边界框的交并比（IOU）得分超过 0.5，则将其视为真正例。

![0192367a-4b8f-7f32-ba78-beeff5704357_4_812260.jpg](images/0192367a-4b8f-7f32-ba78-beeff5704357_4_812260.jpg)

Figure 4. Qualitative Results. We visualize the predictions of the detectors trained only with day-clear images. (Top) FasterRCNN [40] predictions. (Bottom) The predictions with our approach. Night-Clear and Night-Rainy contain scenes that are taken under low light conditions. Due to this, the appearance of the object is obscure and deviates from the daytime case. FasterRCNN fails to detect most of the objects. As shown in the Night-Clear, it misclassifies a car to bus. By contrast, we can still detect car under such a big shift. For Dusk-Rainy scenes, the rain pattern on the windscreen and the wet ground causes an appearance shift. As shown FasterRCNN fails to detect several cars and misclassifies person on the bottom-left.

图4. 定性结果。我们可视化仅使用白天晴朗图像训练的检测器的预测结果。（顶部）FasterRCNN [40] 的预测。（底部）使用我们方法的预测。Night-Clear 和 Night-Rainy 包含在低光条件下拍摄的场景。因此，物体的外观模糊，与白天情况不同。FasterRCNN 无法检测到大多数物体。如在 Night-Clear 中所示，它将一辆车错误分类为公交车。相比之下，我们仍然可以在这种大的变化下检测到汽车。对于 Dusk-Rainy 场景，挡风玻璃上的雨模式和湿地面导致了外观的变化。如所示，FasterRCNN 无法检测到几辆车，并将左下角的人错误分类。

![0192367a-4b8f-7f32-ba78-beeff5704357_4_382380.jpg](images/0192367a-4b8f-7f32-ba78-beeff5704357_4_382380.jpg)

Figure 5. Qualitative Results. In the foggy scenes, the objects further away w.r.t the camera are more obscure than the near ones. Due to this FasterRCNN (Top) struggles to detect them. car and person missed by FasterRCNN are successfully recovered by our approach (Bottom).

图5. 定性结果。在雾天场景中，相对于相机更远处的物体比近处的物体更模糊。因此，FasterRCNN（顶部）很难检测到它们。FasterRCNN 错过的汽车和人可以通过我们的方法（底部）成功恢复。

## 4.2. Implementation Details

## 4.2. 实施细节

We use the Detectron2 [51] implementation of Faster-RCNN with a ResNet101 [20] backbone. We initialize the detector with CLIP [36] pre-trained weights, where ResNet convolution blocks 1-3 act as ${\mathcal{V}}^{a}$, and block-4 along with the CLIP attention pooling act as ${\mathcal{V}}^{b}$ . This follows from the standard FasterRCNN implementation with ResNet backbone.

我们使用了 Detectron2 [51] 实现的带有 ResNet101 [20] 主干的 Faster-RCNN。我们使用 CLIP [36] 预训练权重初始化检测器，其中 ResNet 卷积块 1-3 作为 ${\mathcal{V}}^{a}$，块-4 以及 CLIP 注意力池化作为 ${\mathcal{V}}^{b}$。这遵循了带有 ResNet 主干的标准 FasterRCNN 实现。

Optimization Step. As the benchmark dataset evaluates the method on different weather conditions, we cu-rated a list of domain prompts ${\mathcal{P}}^{t}$ matching the concept weather. To this end, we take all the hyponyms of the term weather from WordNet [44] and generate their text embeddings using the CLIP text encoder $\mathcal{T}$ . We prune away the words whose cosine similarity with the term weather is lower than 0.5 . Additionally, we filter out the words that are not in the top ${10}\mathrm{k}$ frequent words in GloVe wordlist [34]. After combining the synonyms, we get to a list of six words: snow, fog, cloudy, rain, stormy, sunshine. We remove sunshine as it corresponds to our source domain concept. Furthermore, we consider three times of the day: day, night, evening. This lets us generate $M = {15}$ prompts using the template an image taken on a \{weather\} \{time of the day\}. We use an image taken during the day as the source domain prompt ${p}^{s}$ . We provide more details in our supplementary material.

优化步骤。由于基准数据集在不同的天气条件下评估方法，我们整理了一份与天气概念相匹配的领域提示词列表 ${\mathcal{P}}^{t}$。为此，我们从WordNet [44] 中获取了“天气”这一术语的所有下义词，并使用CLIP文本编码器 $\mathcal{T}$ 生成它们的文本嵌入。我们移除了与“天气”这一术语余弦相似度低于0.5的词。此外，我们还过滤掉了不在GloVe词表 [34] 中最常见的前 ${10}\mathrm{k}$ 个词。合并同义词后，我们得到了六个词的列表：雪、雾、多云、雨、暴风雨、阳光。我们移除了“阳光”，因为它对应于我们的源领域概念。此外，我们还考虑了一天中的三个时间段：白天、夜晚、傍晚。这让我们能够使用模板“在一天中的某个时间段 [weather] 拍摄的图片”生成 $M = {15}$ 提示。我们使用白天拍摄的图片作为源领域提示 ${p}^{s}$。我们在补充材料中提供了更多细节。

To optimize the augmentations with these prompts, we generated random crops from the source images and resized them to ${224} \times {224}$ pixels. The resulting output feature map of ${\mathcal{V}}^{a}$ and ${\mathcal{A}}_{j}$ are in ${\mathbb{R}}^{{14} \times {14} \times {1024}}$ . We initialize ${\mathcal{A}}_{j}\forall 1 \geq j \geq M$ with zeros and train it using the Adam [23] optimizer while keeping the CLIP encoder, $\mathcal{V}$ and $\mathcal{T}$, frozen. Optimization was done for 1000 iterations with a learning rate of 0.01 .

为了优化这些提示的增强效果，我们从源图像中生成随机裁剪，并将它们调整到 ${224} \times {224}$ 像素。得到的输出特征图 ${\mathcal{V}}^{a}$ 和 ${\mathcal{A}}_{j}$ 位于 ${\mathbb{R}}^{{14} \times {14} \times {1024}}$ 中。我们使用零值初始化 ${\mathcal{A}}_{j}\forall 1 \geq j \geq M$ 并使用Adam [23] 优化器进行训练，同时保持CLIP编码器 $\mathcal{V}$ 和 $\mathcal{T}$ 不变。优化进行了1000次迭代，学习率为0.01。

Detector Training with Augmentation. When training the detector, the input image is resized to ${600} \times {1067}$ and $\mathcal{V}$ and $\mathcal{T}$ are initialized with CLIP pre-trained weights. While $\mathcal{T}$ is kept frozen during the training, the ResNet blocks 3- 4 and attention pooling of $\mathcal{V}$, along with the other Faster-RCNN learnable blocks, are trained with Stochastic Gradient Descent (SGD) for 100k iterations. We train with a learning rate of $1{e}^{-3}$, scaled down by a factor of 0.1 after ${40}\mathrm{k}$ iterations. We use a batch size of 4 and apply ${\mathcal{A}}_{j}$ to the features with probability $\theta = {0.5}$ . We also use random horizontal flipping augmentation as in Single-DGOD [49]. ${D}_{\text{clip }}$ is set to 512 as in [36] and background class is initialized by zeros in $\mathcal{Q}$ . All of our training was done on a single NVIDIA A100 GPU. Our code will be made public upon acceptance.

检测器训练与增强。在训练检测器时，输入图像被调整大小为 ${600} \times {1067}$，$\mathcal{V}$ 和 $\mathcal{T}$ 使用 CLIP 预训练权重初始化。在训练过程中，$\mathcal{T}$ 保持冻结，而 ResNet 块 3-4 和 $\mathcal{V}$ 的注意力池化，以及其他 Faster-RCNN 可学习块，使用随机梯度下降（SGD）进行 100k 次迭代训练。我们使用的学习率为 $1{e}^{-3}$，在 ${40}\mathrm{k}$ 次迭代后缩小 0.1 倍。我们使用批量大小为 4，并以 $\theta = {0.5}$ 的概率对特征应用 ${\mathcal{A}}_{j}$。我们还使用随机水平翻转增强，如同 Single-DGOD [49] 中所示。${D}_{\text{clip }}$ 设置为 512，如同 [36] 中所示，背景类在 $\mathcal{Q}$ 中初始化为零。我们所有的训练都是在单个 NVIDIA A100 GPU 上完成的。我们的代码将在论文被接受后公开。

<table><thead><tr><th rowspan="2">Method</th><th colspan="5">mAP</th></tr><tr><th>Day Clear</th><th>Night Clear</th><th>Dusk Rainy</th><th>Night Rainy</th><th>Day Foggy</th></tr></thead><tr><td>FR [40]</td><td>48.1</td><td>34.4</td><td>26.0</td><td>12.4</td><td>32.0</td></tr><tr><td>SW [33]</td><td>50.6</td><td>33.4</td><td>26.3</td><td>13.7</td><td>30.8</td></tr><tr><td>IBN-Net [32]</td><td>49.7</td><td>32.1</td><td>26.1</td><td>14.3</td><td>29.6</td></tr><tr><td>IterNorm [21]</td><td>43.9</td><td>29.6</td><td>22.8</td><td>12.6</td><td>28.4</td></tr><tr><td>ISW [6]</td><td>51.3</td><td>33.2</td><td>25.9</td><td>14.1</td><td>31.8</td></tr><tr><td>S-DGOD [49]</td><td>56.1</td><td>36.6</td><td>28.2</td><td>16.6</td><td>33.5</td></tr><tr><td>Ours</td><td>51.3</td><td>36.9</td><td>32.3</td><td>18.7</td><td>38.5</td></tr></table>

Table 1. Single domain generalization results. We show consistent improvements across all the target domains. S-DGOD boosts the source domain results, but at the cost of reduced generalization ability. By contrast, our approach is robust to domain changes. The numbers for S-DGOD, SW, IBN-Net, IterNorm, ISW are taken from [49].

表 1。单一域泛化结果。我们在所有目标域上展示了持续的改进。S-DGOD 提升了源域结果，但牺牲了泛化能力。相比之下，我们的方法对域变化具有鲁棒性。S-DGOD、SW、IBN-Net、IterNorm、ISW 的数值取自 [49]。

## 4.3. Comparison with the State of the Art

## 4.3. 与现有技术水平比较

We compare our method trained with semantic augmentations against the state-of-the-art Single-DGOD [49]. Similar to them, we also show comparisons with feature normalization methods, SW [33], IBN-Net [32], IterNorm [21], and ISW [6]. These methods improve network generalization by using better feature normalization. We additionally report the performance of FasterRCNN (FR) initialized with ImageNet pre-trained weights. For the SDG task, we evaluate the generalization performance on unseen target domains, hence we compare the mAP scores on the out-of-domain datasets: day-foggy, night-rainy, dusk-rainy, and night-clear.

我们将我们的方法（经过语义增强训练）与最先进的Single-DGOD [49]进行了比较。与它们类似，我们还展示了与特征归一化方法，SW [33]、IBN-Net [32]、IterNorm [21]和ISW [6]的比较。这些方法通过使用更好的特征归一化来提高网络的泛化能力。我们还额外报告了使用ImageNet预训练权重初始化的FasterRCNN (FR)的性能。对于SDG任务，我们在未见过的目标域上评估泛化性能，因此我们比较了在域外数据集上的mAP得分：白天-雾天、夜晚-雨天、黄昏-雨天和夜晚-晴朗。

Our approach of combining CLIP pre-training and semantic augmentation outperforms the baselines on all of the target domains. Tab. 1 shows a consistent improvement in all domains with close to ${15}\%$ improvement on day-foggy and dusk-rainy compared to Single-DGOD. In the challenging scenario with Night conditions, we improve by ${12.6}\%$ on night-rainy while being comparable with Single-DGOD on night-clear. On the source domain, both our method and Single-DGOD are better than the FR baseline. However, while Single-DGOD gains improvement at the cost of losing out for domain generalization, we improve on both the source and target domains. The failure of feature normalization baselines suggests a large domain gap between the source and target domains. Fig. 4 and Fig. 5 provide a qualitative results on different weather-datasets.

我们结合CLIP预训练和语义增强的方法在所有目标域上都超过了基线。表1显示了在所有域上的一致改进，与Single-DGOD相比，在白天-雾天和黄昏-雨天接近 ${15}\%$ 的改进。在具有挑战性的夜晚条件下，我们在夜晚-雨天提高了 ${12.6}\%$，而在夜晚-晴朗与Single-DGOD相当。在源域上，我们的方法和Single-DGOD都优于FR基线。然而，Single-DGOD在域泛化上付出了代价，而我们则在源域和目标域上都取得了改进。特征归一化基线的失败表明源域和目标域之间存在很大的域差距。图4和图5提供了不同天气数据集上的定性结果。

<table><tr><td rowspan="2">Method</td><th colspan="7">AP</th><th>mAP</th></tr><tr><td>Bus</td><td>Bike</td><td>Car</td><td>Motor</td><td>Person</td><td>Rider</td><td>Truck</td><td>All</td></tr><tr><td>FR [40]</td><td>28.1</td><td>29.7</td><td>49.7</td><td>26.3</td><td>33.2</td><td>35.5</td><td>21.5</td><td>32.0</td></tr><tr><td>S-DGOD [49]</td><td>32.9</td><td>28.0</td><td>48.8</td><td>29.8</td><td>32.5</td><td>38.2</td><td>24.1</td><td>33.5</td></tr><tr><td>Ours</td><td>36.1</td><td>34.3</td><td>58.0</td><td>33.1</td><td>39.0</td><td>43.9</td><td>25.1</td><td>38.5</td></tr></table>

Table 2. Per-class results on Daytime Clear to Day Foggy. Our method consistently performs better on all categories for the difficult foggy domain. This shows that CLIP initialization and our semantic augmentations improve the detector's generalizability.

表2。白天晴朗到白天雾天的每个类别的结果。我们的方法在困难的雾天域上始终在所有类别上表现更好。这表明CLIP初始化和我们的语义增强提高了检测器的泛化性。

<table><thead><tr><th rowspan="2">Method</th><th colspan="7">AP</th><th>mAP</th></tr><tr><th>Bus</th><th>Bike</th><th>Car</th><th>Motor</th><th>Person</th><th>Rider</th><th>Truck</th><th>All</th></tr></thead><tr><td>FR [40]</td><td>28.5</td><td>20.3</td><td>58.2</td><td>6.5</td><td>23.4</td><td>11.3</td><td>33.9</td><td>26.0</td></tr><tr><td>S-DGOD [49]</td><td>37.1</td><td>19.6</td><td>50.9</td><td>13.4</td><td>19.7</td><td>16.3</td><td>40.7</td><td>28.2</td></tr><tr><td>Ours</td><td>37.8</td><td>22.8</td><td>60.7</td><td>16.8</td><td>26.8</td><td>18.7</td><td>42.4</td><td>32.3</td></tr></table>

Table 3. Per-class results on Daytime Clear to Dusk Rainy. Our approach generalizes to rainy road conditions along with the low light conditions of the dusk hours. The car category sees the biggest improvement, but we nonetheless also boost the performance of all the other classes.

表3. 白天晴朗到黄昏雨天条件下的各类别结果。我们的方法能够泛化到雨天道路条件以及黄昏时段的低光环境。在车辆类别上我们看到了最大的改进，但我们也同样提升了其他所有类别的性能。

In the remainder of this section, we discuss the per-class results on the individual target domains.

在本节的其余部分，我们讨论各个目标域的逐类别结果。

Daytime Clear to Day Foggy. The object appearance drastically changes in the foggy images compared to the day-clear scenario. As shown in Tab. 2, our method brings in a large improvement for the car, person, and bike categories, while still being consistently better than Single-DGOD and FR on the others.

白天晴朗到白天雾天。与白天晴朗场景相比，雾天图像中的物体外观发生了巨大变化。如表2所示，我们的方法为车辆、行人和自行车类别带来了很大的改进，同时在其他类别上仍然一致性地优于Single-DGOD和FR。

Daytime Clear to Dusk Rainy. Dusk Rainy scenes reflect a low light condition and along with the rainy pattern. The image distribution is thus further away from the daytime clear images. As shown in Tab. 3, our method improves the AP of each class, with the biggest improvement in the car and person categories. Since we leverage CLIP pre-training and bring in concepts such as rain/cloudy/stormy and evening/night hours through our semantic augmentation, the learnt detector generalizes better.

白天晴朗到黄昏雨天。黄昏雨天的场景反映了低光条件和雨天的模式。因此，图像分布与白天晴朗图像相去更远。如表3所示，我们的方法提高了每个类别的AP值，车辆和行人类别改进最大。由于我们利用了CLIP预训练，并通过我们的语义增强引入了雨/多云/暴风雨和黄昏/夜晚时段的概念，学到的检测器泛化得更好。

<table><thead><tr><th rowspan="2">Method</th><th colspan="7">AP</th><th>mAP</th></tr><tr><th>Bus</th><th>Bike</th><th>Car</th><th>Motor</th><th>Person</th><th>Rider</th><th>Truck</th><th>All</th></tr></thead><tr><td>FR [40]</td><td>34.7</td><td>32.0</td><td>56.6</td><td>13.6</td><td>37.4</td><td>27.6</td><td>38.6</td><td>34.4</td></tr><tr><td>S-DGOD [49]</td><td>40.6</td><td>35.1</td><td>50.7</td><td>19.7</td><td>34.7</td><td>32.1</td><td>43.4</td><td>36.6</td></tr><tr><td>Ours</td><td>37.7</td><td>34.3</td><td>58.0</td><td>19.2</td><td>37.6</td><td>28.5</td><td>42.9</td><td>36.9</td></tr></table>

Table 4. Per-class results on Daytime Clear to Night Clear. While being comparable to S-DGOD on most of the categories, we improve on car and person.

表4. 白天晴朗到夜晚晴朗条件下的逐类别结果。虽然在大多数类别上与S-DGOD相当，但我们对车辆和行人类别进行了改进。

<table><thead><tr><th rowspan="2">Method</th><th colspan="7">AP</th><th>mAP</th></tr><tr><th>Bus</th><th>Bike</th><th>Car</th><th>Motor</th><th>Person</th><th>Rider</th><th>Truck</th><th>All</th></tr></thead><tr><td>FR [40]</td><td>16.8</td><td>6.9</td><td>26.3</td><td>0.6</td><td>11.6</td><td>9.4</td><td>15.4</td><td>12.4</td></tr><tr><td>S-DGOD [49]</td><td>24.4</td><td>11.6</td><td>29.5</td><td>9.8</td><td>10.5</td><td>11.4</td><td>19.2</td><td>16.6</td></tr><tr><td>Ours</td><td>28.6</td><td>12.1</td><td>36.1</td><td>9.2</td><td>12.3</td><td>9.6</td><td>22.9</td><td>18.7</td></tr></table>

Table 5. Per-class results on Daytime Clear to Night Rainy. This dataset presents the most challenging scenario, where the low light and rainy conditions obscure the objects. We still perform better than the baseline on most of the categories.

表5. 白天晴朗到夜晚雨天条件下的逐类别结果。这个数据集呈现了最具挑战性的场景，低光和雨天条件使物体变得模糊。我们仍然在大多数类别上表现得比基线要好。

Daytime Clear to Night Clear. The Night Clear dataset shows a challenging night driving scene under severe low-light conditions. In Tab. 4, we show that while being comparable to Single-DGOD, we bring in a larger improvement in the car and person categories. Night scenes are particularly challenging as the low light condition leads to more confusion among visually closer categories such as bus and truck.

白天晴朗转夜间晴朗。夜间晴朗数据集展示了在严重低光条件下的夜间驾驶场景。在表4中，我们显示，虽然与Single-DGOD相当，但我们为车辆和人员类别带来了更大的改进。夜间场景尤其具有挑战性，因为低光条件导致视觉上更接近的类别（如公交车和卡车）之间更容易混淆。

Daytime Clear to Night Rainy. This is the most challenging scenario where dark night conditions are exacerbated by patterns occurring due to rain. Tab. 5 shows consistent improvement by our approach for most of the classes. The car class sees the biggest improvement with an increase in AP of more than ${22}\%$ compared to Single-DGOD. The lower performance of the class rider can be attributed to an increase in the confusion between the visually similar person and rider classes under adverse conditions.

白天晴朗转夜间雨天。这是最具挑战性的场景，其中暗夜条件因雨水产生的模式而加剧。表5显示，我们的方法在大多数类别上都有持续的改进。车辆类别看到了最大的改进，AP值比Single-DGOD增加了超过 ${22}\%$。类别骑行者的性能较低可以归因于在不利条件下视觉上相似的骑行者类别和人员类别之间的混淆增加。

## 4.4. Ablation Study

## 4.4. 抽象研究

To understand how each element of the proposed method contributes to the overall performance, we conduct an ablation study. We test five individual components of our model. Specifically, we remove semantic augmentation, replace CLIP attention pooling in ${\mathcal{V}}^{b}$ with average pooling, replace ${\mathcal{L}}_{\text{clip-t }}$ with the FasterRCNN classification loss, and change the weight initialization from the CLIP model to an ImageNet classification model. Removing those five components turns our model back into the standard Faster-RCNN. The ablation study results are provided in Tab. 6 and discussed below.

为了了解所提出方法的每个元素如何贡献于整体性能，我们进行了一项抽象研究。我们测试了模型的五个独立组成部分。具体来说，我们移除了语义增强，将 ${\mathcal{V}}^{b}$ 中的CLIP注意力池化替换为平均池化，将 ${\mathcal{L}}_{\text{clip-t }}$ 替换为FasterRCNN分类损失，并将权重初始化从CLIP模型改为ImageNet分类模型。移除这五个组件将我们的模型恢复为标准的Faster-RCNN。抽象研究的结果在表6中提供，并将在下面讨论。

CLIP initialization. When the FasterRCNN backbone $\mathcal{V}$ is initialized with CLIP pre-trained weights, the model performance consistently increases both in the in-domain and out-of-domain scenarios, as shown in the second row of Tab. 6. This setting itself already outperforms Single-DGOD (penultimate row of Tab. 1). This goes to show that, for the generalization task, model weight initialization plays a crucial role. We further improve this performance with semantic augmentations.

CLIP初始化。当FasterRCNN主干 $\mathcal{V}$ 使用CLIP预训练权重进行初始化时，模型性能在表6的第二行所示，无论是在域内还是域外场景中都一致提高。这个设置本身就超过了Single-DGOD（表1倒数第二行）。这表明，对于泛化任务，模型权重初始化起着关键作用。我们通过语义增强进一步改进了这种性能。

Attention pooling and ${\mathcal{L}}_{\text{clip-t }}$ . Next we test the impact of the text-embedding-based loss ${\mathcal{L}}_{\text{clip-t }}$ for classification. As visible in the third row of Tab. 6, when combined with CLIP initialization, it improves the generalization performance for the rainy scenarios, but degrades it for the other ones. Replacing average pooling in ${\mathcal{V}}^{b}$ with CLIP attention pooling helps to mitigate the detrimental effect of ${\mathcal{L}}_{\text{clip-t }}$ and exhibits consistent improvement on all datasets.

注意力池化以及 ${\mathcal{L}}_{\text{clip-t }}$ 。接下来我们测试基于文本嵌入的损失 ${\mathcal{L}}_{\text{clip-t }}$ 对分类的影响。如表格6的第三行所示，当与CLIP初始化结合时，它提高了在雨天场景下的泛化性能，但在其他情况下降低了性能。将 ${\mathcal{V}}^{b}$ 中的平均池化替换为CLIP注意力池化有助于缓解 ${\mathcal{L}}_{\text{clip-t }}$ 的不利影响，并在所有数据集上表现出一致的改进。

Semantic augmentation. Finally, adding semantic augmentation gives us the best results, as shown in the last row of Tab. 6. Exposing the visual encoder $\mathcal{V}$ to targeted semantic augmentations helps the overall model to better generalize when exposed to new domains sharing similarity with the augmentations.

语义增强。最后，如表格6最后一行所示，添加语义增强给出了最佳结果。将视觉编码器 $\mathcal{V}$ 暴露于针对性的语义增强有助于模型在遇到与新增强相似的新领域时更好地泛化。

## 4.5. Additional Analyses

## 4.5. 额外分析

Study of semantic augmentation. Our proposed method involves translating feature maps by semantic augmentations learned using plausible domain prompts. To further study the utility of our approach, we replace the augmentation strategy in our training pipeline with (a) no-aug: no augmentation; (b) random: $\mathcal{A}$ is initialized with a normal distribution; (c) clip-random: we define ${\mathcal{P}}^{t}$ with concepts that are not specific to weather. We generate prompts with a template an image of $\{$ word $\}$, where the words are desert, ocean, forest, and mountain. Tab. 7 illustrates the importance of the semantics in our augmentation strategy. The random augmentation performs worse than the no-aug strategy. clip-random is comparable to no-aug and doesn't show any consistent trend but is mostly better than random. Our semantic augmentation strategy provides a consistent improvement over no-aug because the translations are performed with prompts from the relevant weather concept.

语义增强研究。我们提出的方法涉及通过使用可信领域提示学习的语义增强来转换特征图。为了进一步研究我们方法的有效性，我们将训练管道中的增强策略替换为：(a) 无增强：不进行增强；(b) 随机：$\mathcal{A}$ 使用正态分布初始化；(c) clip随机：我们定义 ${\mathcal{P}}^{t}$ 为与天气无关的概念。我们使用模板生成提示语，例如“一张 $\{$ 单词 $\}$ 的图片”，其中单词包括沙漠、海洋、森林和山脉。表格7说明了我们的增强策略中语义的重要性。随机增强的性能低于无增强策略。clip随机与无增强相当，没有显示出任何一致的趋势，但大多数情况下优于随机。我们的语义增强策略在无增强的基础上提供了持续的改进，因为转换是通过相关天气概念的提示进行的。

<table><thead><tr><th colspan="4" rowspan="2">Model Component</th><th colspan="5">mAP</th></tr><tr><th colspan="2">Source</th><th colspan="3">Target</th></tr><tr><th>CLIP init</th><th>${\mathcal{L}}_{{clip} - t}$</th><th>Attn. Pool</th><th>Sem. Aug</th><th>Day Clear</th><th>Night Clear</th><th>Dusk Rainy</th><th>Night Rainy</th><th>Day Foggy</th></tr></thead><tr><td></td><td></td><td></td><td></td><td>48.1</td><td>34.4</td><td>26.0</td><td>12.4</td><td>32.0</td></tr><tr><td>$\checkmark$</td><td></td><td></td><td></td><td>51.2</td><td>37.0</td><td>31.0</td><td>15.7</td><td>37.5</td></tr><tr><td>$\checkmark$</td><td>$\checkmark$</td><td></td><td></td><td>50.7</td><td>36.0</td><td>31.3</td><td>16.3</td><td>36.9</td></tr><tr><td>$\checkmark$</td><td>$\checkmark$</td><td>$\checkmark$</td><td></td><td>51.0</td><td>35.9</td><td>31.3</td><td>16.7</td><td>37.7</td></tr><tr><td>$\checkmark$</td><td>$\checkmark$</td><td>$\checkmark$</td><td>$\checkmark$</td><td>51.3</td><td>36.9</td><td>32.3</td><td>18.7</td><td>38.5</td></tr></table>

Table 6. Ablation study. We study the influence of five different components of our approach: the backbone weight initialization strategy, the classification loss, the attention pooling, and the semantic augmentation. When those five components are removed (first row of the table) the model is equivalent to the standard FasterRCNN. Initializing the detector with CLIP weights (second row) largely improves the generalization performance; on its own it already outperforms Single-DGOD (penultimate row of Tab. 1) on most of the datasets, hence suggesting that CLIP has better generalizability than ImageNet pre-trained weights. Combining this with the text embedding-based loss ${\mathcal{L}}_{\text{clip-t }}$ (third row) improves the results on the challenging scenarios of dusk rainy and night rainy, but has a detrimental effect for the other weather conditions. Adding attention pooling to the architecture (fourth row) helps to mitigate these detrimental effects as it brings the visual features closer to the joint embedding space. Finally, the best results are obtained when the semantic augmentation is added (last row), greatly helping with adverse weather, rainy and foggy, scenarios.

表6. 抽象研究。我们研究了方法中五个不同组成部分的影响：主干网络权重初始化策略、分类损失、注意力池化以及语义增强。当这五个组成部分被移除（表格的第一行）时，模型等同于标准的FasterRCNN。用CLIP权重初始化检测器（第二行）大大提高了泛化性能；单独使用它已经超过了大多数数据集上的Single-DGOD（表1倒数第二行），因此表明CLIP比ImageNet预训练权重具有更好的泛化性。将这种初始化与基于文本嵌入的损失${\mathcal{L}}_{\text{clip-t }}$（第三行）结合，在黄昏雨和夜晚雨的挑战性场景中提高了结果，但对其他天气条件产生了不利影响。在架构中添加注意力池化（第四行）有助于缓解这些不利影响，因为它使视觉特征更接近联合嵌入空间。最后，当添加了语义增强（最后一行）时，获得了最佳结果，这在恶劣天气、雨和雾的场景中大大提高了效果。

<table><thead><tr><th rowspan="2">Aug. Type</th><th colspan="5">mAP</th></tr><tr><th>Day Clear</th><th>Night Clear</th><th>Dusk Rainy</th><th>Night Rainy</th><th>Day Foggy</th></tr></thead><tr><td>no-aug.</td><td>51.0</td><td>35.9</td><td>31.3</td><td>16.7</td><td>37.7</td></tr><tr><td>random</td><td>51.2</td><td>36.0</td><td>30.4</td><td>15.3</td><td>37.3</td></tr><tr><td>clip-random</td><td>51.5</td><td>36.4</td><td>30.2</td><td>15.9</td><td>37.9</td></tr><tr><td>Ours w/ seg.aug</td><td>51.3</td><td>36.9</td><td>32.3</td><td>18.7</td><td>38.5</td></tr></table>

Table 7. Semantic Augmentation. Our semantic augmentation consistently outperforms other augmentation strategies. While random augmentations are worse than no-aug., clip-random is comparable to no-aug.. Only when we give relevant prompts, there is a consistent improvement across datasets.

表7. 语义增强。我们的语义增强策略始终优于其他增强策略。虽然随机增强比不增强差，但clip-random与不增强相当。只有当我们给出相关提示时，各个数据集上才会有一致的改进。

## 5. Limitations

## 5. 局限性

Our method augments visual features using textual prompts. To generate these prompts, it is assumed that some information about the domain gap is known. In our experiments, we assumed that the domain gap was due to changes in weather and daytime conditions. In practice, we only used the word weather and time of the day to derive all the prompts used in our augmentation; nonetheless, some extra information was used. In most applications, however, the domain gap can be known in advance, and providing a few keywords characterizing it shouldn't be an issue. In the rare cases where no information can be known, our approach still has the potential to be used by using multiple broad concept keywords such as weather, ambiance, or location.

我们的方法通过使用文本提示增强视觉特征。为了生成这些提示，假设已知一些关于领域差异的信息。在我们的实验中，我们假设领域差异是由于天气和白天条件的变化造成的。实际上，我们仅使用了“天气”和“一天中的时间”这两个词来推导出我们增强中使用的所有提示；尽管如此，还是使用了一些额外信息。然而，在大多数应用中，领域差异可以提前得知，提供一些描述它的关键词应该不是问题。在极少数情况下，如果没有已知信息，我们的方法仍然可以通过使用多个广泛的概念关键词（如天气、环境或位置）来使用。

## 6. Conclusion

## 6. 结论

We have proposed an approach to improving the generalization of object detectors on unseen target domains. Our approach fundamentally departs from existing method by leveraging a pre-trained vision-language model, CLIP, to help the detector to generalize. Specifically, we have exploited textual prompts to develop a semantic augmentation strategy that alters image embeddings so that they reflect potential target domains, and to design a text-based image classifier. We have shown that our approach outperforms the state of the art on four adverse-weather target datasets. In future work, we plan to extend our approach to learning the prompts to further improve generalization.

我们提出了一种改进对象检测器在未见过的目标领域泛化能力的方法。我们的方法本质上与现有方法不同，通过利用预训练的视觉语言模型CLIP来帮助检测器泛化。具体来说，我们利用文本提示开发了一种语义增强策略，改变了图像嵌入，使它们反映潜在的目标领域，并设计了一种基于文本的图像分类器。我们已经证明，我们的方法在四个恶劣天气的目标数据集上优于现有技术水平。在未来的工作中，我们计划扩展我们的方法来学习提示，以进一步改进泛化能力。

Acknowledgment: This work was funded in part by the Swiss National Science Foundation and the Swiss Innovation Agency (Innosuisse) via the BRIDGE Discovery grant 40B2-0 194729.

致谢：这项工作得到了瑞士国家科学基金会和瑞士创新机构（Innosuisse）通过BRIDGE探索项目40B2-0 194729的部分资助。

## References

## 参考文献

[1] Yogesh Balaji, Swami Sankaranarayanan, and Rama Chel-lappa. Metareg: Towards domain generalization using meta-regularization. Advances in neural information processing systems, 31, 2018. 1

[2] Mathilde Caron, Hugo Touvron, Ishan Misra, Hervé Jégou, Julien Mairal, Piotr Bojanowski, and Armand Joulin. Emerging properties in self-supervised vision transformers. In Proceedings of the IEEE/CVF International Conference on Computer Vision, pages 9650-9660, 2021. 1

[3] Chaoqi Chen, Zebiao Zheng, Xinghao Ding, Yue Huang, and Qi Dou. Harmonizing transferability and discriminability for adapting object detectors. In Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition, pages 8869-8878, 2020. 1, 2

[4] Xinlei Chen and Kaiming He. Exploring simple siamese representation learning. In Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition, pages 15750-15758, 2021. 1

[5] Yuhua Chen, Wen Li, Christos Sakaridis, Dengxin Dai, and Luc Van Gool. Domain adaptive faster r-cnn for object detection in the wild. In Proceedings of the IEEE conference on computer vision and pattern recognition, pages 3339-3348, 2018. 1, 2

[6] Sungha Choi, Sanghun Jung, Huiwon Yun, Joanne T Kim, Seungryong Kim, and Jaegul Choo. Robustnet: Improving domain generalization in urban-scene segmentation via instance selective whitening. In Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition, pages 11580-11590, 2021. 6

[7] Marius Cordts, Mohamed Omran, Sebastian Ramos, Timo Rehfeld, Markus Enzweiler, Rodrigo Benenson, Uwe Franke, Stefan Roth, and Bernt Schiele. The cityscapes dataset for semantic urban scene understanding. In Proceedings of the IEEE conference on computer vision and pattern recognition, pages 3213-3223, 2016. 4

[8] Jinhong Deng, Wen Li, Yuhua Chen, and Lixin Duan. Unbiased mean teacher for cross-domain object detection. In Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition, pages 4091-4101, 2021. 1, 2

[9] Karan Desai and Justin Johnson. Virtex: Learning visual representations from textual annotations. In Proceedings of the IEEE/CVF conference on computer vision and pattern recognition, pages 11162-11173, 2021. 2

[10] Qi Dou, Daniel Coelho de Castro, Konstantinos Kamnitsas, and Ben Glocker. Domain generalization via model-agnostic learning of semantic features. Advances in Neural Information Processing Systems, 32, 2019. 1

[11] Martin Engilberge, Louis Chevallier, Patrick Pérez, and Matthieu Cord. Finding beans in burgers: Deep semantic-visual embedding with localization. In Proceedings of the IEEE Conference on Computer Vision and Pattern Recognition, pages 3984-3993, 2018. 2

[12] Fartash Faghri, David J Fleet, Jamie Ryan Kiros, and Sanja Fidler. Vse++: Improving visual-semantic embeddings with hard negatives. arXiv preprint arXiv:1707.05612, 2017. 2

[13] Xinjie Fan, Qifei Wang, Junjie Ke, Feng Yang, Boqing Gong, and Mingyuan Zhou. Adversarially adaptive normalization for single domain generalization. In Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition, pages 8208-8217, 2021. 1, 2

[14] Andrea Frome, Greg S Corrado, Jon Shlens, Samy Bengio, Jeff Dean, Marc'Aurelio Ranzato, and Tomas Mikolov. Devise: A deep visual-semantic embedding model. Advances in neural information processing systems, 26, 2013. 2

[15] Yaroslav Ganin, Evgeniya Ustinova, Hana Ajakan, Pascal Germain, Hugo Larochelle, François Laviolette, Mario Marchand, and Victor Lempitsky. Domain-adversarial training of neural networks. The journal of machine learning research, 17(1):2096-2030, 2016. 2

[16] Xiuye Gu, Tsung-Yi Lin, Weicheng Kuo, and Yin Cui. Open-vocabulary object detection via vision and language knowledge distillation. arXiv preprint arXiv:2104.13921, 2021. 2, 4

[17] Mahmoud Hassaballah, Mourad A Kenk, Khan Muhammad, and Shervin Minaee. Vehicle detection and tracking in adverse weather using a deep learning framework. IEEE transactions on intelligent transportation systems, 22(7):4230- 4242, 2020. 4

[18] Kaiming He, Haoqi Fan, Yuxin Wu, Saining Xie, and Ross Girshick. Momentum contrast for unsupervised visual representation learning. In Proceedings of the IEEE/CVF conference on computer vision and pattern recognition, pages 9729-9738, 2020. 1

[19] Kaiming He, Georgia Gkioxari, Piotr Dollár, and Ross Gir-shick. Mask r-cnn. In Proceedings of the IEEE international conference on computer vision, pages 2961-2969, 2017. 4

[20] Kaiming He, Xiangyu Zhang, Shaoqing Ren, and Jian Sun. Deep residual learning for image recognition. In Proceedings of the IEEE conference on computer vision and pattern recognition, pages 770-778, 2016. 5

[21] Lei Huang, Yi Zhou, Fan Zhu, Li Liu, and Ling Shao. Iterative normalization: Beyond standardization towards efficient whitening. In Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition, pages 4874-4883, 2019. 6

[22] Kyungyul Kim, ByeongMoon Ji, Doyoung Yoon, and Sangheum Hwang. Self-knowledge distillation: A simple way for better generalization. arXiv preprint arXiv:2006.12000, 3, 2020. 1, 2

[23] Diederik P Kingma and Jimmy Ba. Adam: A method for stochastic optimization. arXiv preprint arXiv:1412.6980, 2014. 5

[24] Ryan Kiros, Ruslan Salakhutdinov, and Richard S Zemel. Unifying visual-semantic embeddings with multimodal neural language models. arXiv preprint arXiv:1411.2539, 2014. 2

[25] Da Li, Yongxin Yang, Yi-Zhe Song, and Timothy Hospedales. Learning to generalize: Meta-learning for domain generalization. In Proceedings of the AAAI conference on artificial intelligence, volume 32, 2018. 1

[26] Da Li, Jianshu Zhang, Yongxin Yang, Cong Liu, Yi-Zhe Song, and Timothy M Hospedales. Episodic training for domain generalization. In Proceedings of the IEEE/CVF International Conference on Computer Vision, pages 1446-1455, 2019. 1

[27] Gen Li, Nan Duan, Yuejian Fang, Ming Gong, Daxin Jiang, and Ming Zhou. Unicoder-vl: A universal encoder for vision and language by cross-modal pre-training. arxiv e-prints, page. arXiv preprint arXiv:1908.06066, 2019. 2

[28] Haoliang Li, Sinno Jialin Pan, Shiqi Wang, and Alex C Kot. Domain generalization with adversarial feature learning. In Proceedings of the IEEE conference on computer vision and pattern recognition, pages 5400-5409, 2018. 1

[29] Liunian Harold Li, Pengchuan Zhang, Haotian Zhang, Jian-wei Yang, Chunyuan Li, Yiwu Zhong, Lijuan Wang, Lu Yuan, Lei Zhang, Jenq-Neng Hwang, et al. Grounded language-image pre-training. In Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition, pages 10965-10975, 2022. 2

[30] Yu-Jhe Li, Xiaoliang Dai, Chih-Yao Ma, Yen-Cheng Liu, Kan Chen, Bichen Wu, Zijian He, Kris Kitani, and Peter Va-jda. Cross-domain adaptive teacher for object detection. In IEEE Conference on Computer Vision and Pattern Recognition (CVPR), 2022. 1, 2

[31] Tomas Mikolov, Kai Chen, Greg Corrado, and Jeffrey Dean. Efficient estimation of word representations in vector space. arXiv preprint arXiv:1301.3781, 2013. 3

[32] Xingang Pan, Ping Luo, Jianping Shi, and Xiaoou Tang. Two at once: Enhancing learning and generalization capacities via ibn-net. In Proceedings of the European Conference on Computer Vision (ECCV), pages 464-479, 2018. 6

[33] Xingang Pan, Xiaohang Zhan, Jianping Shi, Xiaoou Tang, and Ping Luo. Switchable whitening for deep representation learning. In Proceedings of the IEEE/CVF International Conference on Computer Vision, pages 1863-1871, 2019. 6

[34] Jeffrey Pennington, Richard Socher, and Christopher D Manning. Glove: Global vectors for word representation. In Proceedings of the 2014 conference on empirical methods in natural language processing (EMNLP), pages 1532-1543, 2014. 5

[35] Fengchun Qiao, Long Zhao, and Xi Peng. Learning to learn single domain generalization. In Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition, pages 12556-12565, 2020. 1, 2

[36] Alec Radford, Jong Wook Kim, Chris Hallacy, Aditya Ramesh, Gabriel Goh, Sandhini Agarwal, Girish Sastry, Amanda Askell, Pamela Mishkin, Jack Clark, et al. Learning transferable visual models from natural language supervision. In International Conference on Machine Learning, pages 8748-8763. PMLR, 2021. 1, 2, 3, 4, 5, 6

[37] Alec Radford, Jeffrey Wu, Rewon Child, David Luan, Dario Amodei, Ilya Sutskever, et al. Language models are unsupervised multitask learners. OpenAI blog, 1(8):9, 2019. 2

[38] Aditya Ramesh, Prafulla Dhariwal, Alex Nichol, Casey Chu, and Mark Chen. Hierarchical text-conditional image generation with clip latents. arXiv preprint arXiv:2204.06125, 2022. 3

[39] Hanoona Rasheed, Muhammad Maaz, Muhammad Uzair Khattak, Salman Khan, and Fahad Shahbaz Khan. Bridging the gap between object and image-level representations for open-vocabulary detection. arXiv preprint arXiv:2207.03482, 2022. 2, 4

[40] Shaoqing Ren, Kaiming He, Ross Girshick, and Jian Sun. Faster r-cnn: towards real-time object detection with region proposal networks. IEEE transactions on pattern analysis and machine intelligence, 39(6):1137-1149, 2016. 4, 5, 6, 7

[41] Kuniaki Saito, Yoshitaka Ushiku, Tatsuya Harada, and Kate Saenko. Strong-weak distribution alignment for adaptive object detection. In Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition, pages 6956- 6965, 2019. 1, 2

[42] Christos Sakaridis, Dengxin Dai, and Luc Van Gool. Semantic foggy scene understanding with synthetic data. International Journal of Computer Vision, 126(9):973-992, 2018. 4

[43] Zhiqiang Shen, Harsh Maheshwari, Weichen Yao, and Mar-ios Savvides. Scl: Towards accurate domain adaptive object detection via gradient detach based stacked complementary losses. arXiv preprint arXiv:1911.02559, 2019. 1, 2

[44] Princeton University. About wordnet. https:// wordnet.princeton.edu, 2010. 5

[45] Riccardo Volpi, Hongseok Namkoong, Ozan Sener, John C Duchi, Vittorio Murino, and Silvio Savarese. Generalizing to unseen domains via adversarial data augmentation. Advances in neural information processing systems, 31, 2018. 1, 2

[46] Vibashan VS, Vikram Gupta, Poojan Oza, Vishwanath A Sindagi, and Vishal M Patel. Mega-cda: Memory guided attention for category-aware unsupervised domain adaptive object detection. In Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition, pages 4516-4526, 2021. 2

[47] Xudong Wang, Zhaowei Cai, Dashan Gao, and Nuno Vas-concelos. Towards universal object detection by domain attention. In Proceedings of the IEEE/CVF conference on computer vision and pattern recognition, pages 7289-7298, 2019. 1

[48] Zijian Wang, Yadan Luo, Ruihong Qiu, Zi Huang, and Mahsa Baktashmotlagh. Learning to diversify for single domain generalization. In Proceedings of the IEEE/CVF International Conference on Computer Vision, pages 834-843, 2021. 1, 2

[49] Aming Wu and Cheng Deng. Single-domain generalized object detection in urban scene via cyclic-disentangled self-distillation. In Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition, pages 847-856, 2022. $1,2,4,6,7$

[50] Aming Wu, Rui Liu, Yahong Han, Linchao Zhu, and Yi Yang. Vector-decomposed disentanglement for domain-invariant object detection. In Proceedings of the IEEE/CVF International Conference on Computer Vision, pages 9342- 9351, 2021. 4

[51] Yuxin Wu, Alexander Kirillov, Francisco Massa, Wan-Yen Lo, and Ross Girshick. Detectron2. https://github. com/facebookresearch/detectron2, 2019. 5

[52] Fisher Yu, Haofeng Chen, Xin Wang, Wenqi Xian, Yingying Chen, Fangchen Liu, Vashisht Madhavan, and Trevor Darrell. Bdd100k: A diverse driving dataset for heterogeneous multitask learning. In Proceedings of the IEEE/CVF conference on computer vision and pattern recognition, pages 2636-2645, 2020. 4

[53] Alireza Zareian, Kevin Dela Rosa, Derek Hao Hu, and Shih-Fu Chang. Open-vocabulary object detection using captions. In Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition, pages 14393-14402, 2021. 2

[54] Haotian Zhang, Pengchuan Zhang, Xiaowei Hu, Yen-Chun Chen, Liunian Harold Li, Xiyang Dai, Lijuan Wang, Lu Yuan, Jenq-Neng Hwang, and Jianfeng Gao. Glipv2: Unifying localization and vision-language understanding. arXiv preprint arXiv:2206.05836, 2022. 2

[55] Yuhao Zhang, Hang Jiang, Yasuhide Miura, Christopher D Manning, and Curtis P Langlotz. Contrastive learning of medical visual representations from paired images and text. arXiv preprint arXiv:2010.00747, 2020. 2

[56] Yabin Zhang, Minghan Li, Ruihuang Li, Kui Jia, and Lei Zhang. Exact feature distribution matching for arbitrary style transfer and domain generalization. In Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition, pages 8035-8045, 2022. 1, 2

[57] Shanshan Zhao, Mingming Gong, Tongliang Liu, Huan Fu, and Dacheng Tao. Domain generalization via entropy regularization. Advances in Neural Information Processing Systems, 33:16096-16107, 2020. 1

[58] Xinge Zhu, Jiangmiao Pang, Ceyuan Yang, Jianping Shi, and Dahua Lin. Adapting object detectors via selective cross-domain alignment. In Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition, pages 687-696, 2019. 2